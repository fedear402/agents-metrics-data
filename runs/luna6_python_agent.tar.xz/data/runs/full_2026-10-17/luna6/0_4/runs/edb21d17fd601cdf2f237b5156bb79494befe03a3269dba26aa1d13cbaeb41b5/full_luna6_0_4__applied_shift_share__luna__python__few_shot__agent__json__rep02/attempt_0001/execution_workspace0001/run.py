import json
import numpy as np
import pandas as pd


def weighted_mean(values, weights):
    return np.sum(weights * values) / np.sum(weights)


def shock_iv(dependent, endogenous, instrument, masses):
    """Weighted just-identified IV with intercept and analytic-weight HC1 SE."""
    n = len(masses)
    regressors = np.column_stack((np.ones(n), endogenous))
    instruments = np.column_stack((np.ones(n), instrument))
    cross = instruments.T @ (masses[:, None] * regressors)
    beta = np.linalg.solve(cross, instruments.T @ (masses * dependent))
    residual = dependent - regressors @ beta
    scores = instruments * (masses * residual)[:, None]
    inverse = np.linalg.inv(cross)
    covariance = (n / (n - 2)) * inverse @ (scores.T @ scores) @ inverse.T
    return float(beta[1]), float(np.sqrt(covariance[1, 1]))


df = pd.read_csv('input.csv')
required = ['region_id', 'industry_id', 'share', 'shock', 'region_weight', 'x', 'y']
if list(df.columns) != required:
    raise ValueError(f'Unexpected columns: {list(df.columns)}')
if df[required].isna().any().any():
    raise ValueError('Input has missing required values')

# Region-level values repeat on region-industry rows. Keep one row per region.
regions = df.drop_duplicates('region_id').set_index('region_id').sort_index()
if regions.index.duplicated().any():
    raise ValueError('Duplicate region rows after deduplication')
e = regions['region_weight'].to_numpy(dtype=float, copy=True)
e /= e.sum()

# Check repeated regional values and industry shocks, then build complete matrices.
for col in ['region_weight', 'x', 'y']:
    if df.groupby('region_id')[col].nunique().max() != 1:
        raise ValueError(f'{col} varies within region')
if df.groupby('industry_id')['shock'].nunique().max() != 1:
    raise ValueError('shock varies within industry')
share_sums = df.groupby('region_id')['share'].sum().reindex(regions.index).to_numpy()
if not np.allclose(share_sums, 1.0, atol=1e-8):
    raise ValueError('Baseline shares do not sum to one within every region')

share = df.pivot(index='region_id', columns='industry_id', values='share').reindex(regions.index)
if share.isna().any().any():
    raise ValueError('Missing region-industry pair in share matrix')
industries = share.columns
shock_by_industry = df.drop_duplicates('industry_id').set_index('industry_id')['shock'].reindex(industries).to_numpy(float)
S = share.to_numpy(float)

x = regions['x'].to_numpy(float)
y = regions['y'].to_numpy(float)
z = S @ shock_by_industry
# Regional weighted 2SLS and first stage, each with an intercept.
x0 = x - np.sum(e * x)
y0 = y - np.sum(e * y)
z0 = z - np.sum(e * z)
regional_effect = np.sum(e * z0 * y0) / np.sum(e * z0 * x0)
regional_first_stage = np.sum(e * z0 * x0) / np.sum(e * z0 * z0)

# Shock-level aggregation of each weighted-centered regional residual.
masses = e @ S
if np.any(masses <= 0):
    raise ValueError('Each industry must have positive exposure mass')
xbar = (S.T @ (e * x0)) / masses
ybar = (S.T @ (e * y0)) / masses
zbar = (S.T @ (e * z0)) / masses
n_industries = len(industries)
effect, effect_se = shock_iv(ybar, xbar, shock_by_industry, masses)
first_stage, first_stage_se = shock_iv(xbar, zbar, shock_by_industry, masses)
effective_shocks = float(1.0 / np.sum(masses ** 2))

# Identity checks: weighted shock-level IV slopes equal regional IV slopes.
if not np.allclose([effect, first_stage], [regional_effect, regional_first_stage], rtol=1e-9, atol=1e-10):
    raise AssertionError('Shock-level slopes do not match regional IV identities')

output = {
    'task_id': 'applied_shift_share',
    'platform': 'python',
    'estimates': [
        {'term': 'effect', 'estimate': effect, 'se': effect_se, 'n_obs': n_industries},
        {'term': 'first_stage', 'estimate': first_stage, 'se': first_stage_se, 'n_obs': n_industries},
        {'term': 'effective_shocks', 'estimate': effective_shocks, 'se': None, 'n_obs': n_industries},
    ],
    'method_metadata': {
        'estimator': 'Weighted regional 2SLS; BHJ shock-level aggregation with intercept',
        'vcov': f'Industry-level analytic-weight HC1, structural IV residuals, N/(N-2), N={n_industries}',
    },
    'diagnostics': {},
}
with open('result.json', 'w') as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
