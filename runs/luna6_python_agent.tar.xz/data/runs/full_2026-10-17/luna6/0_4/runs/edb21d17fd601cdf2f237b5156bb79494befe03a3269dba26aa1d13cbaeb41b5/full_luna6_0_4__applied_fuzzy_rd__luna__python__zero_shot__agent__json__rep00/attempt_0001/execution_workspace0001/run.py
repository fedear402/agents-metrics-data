import json
import numpy as np
import pandas as pd


def main():
    df = pd.read_csv("input.csv")
    sample = df.loc[df["score"].abs() < 1].copy()
    x = sample["score"].to_numpy(dtype=float)
    right = (x >= 0).astype(float)
    w = 1.0 - np.abs(x)
    # One common design matrix gives the same local-linear fit for both outcomes.
    X = np.column_stack([np.ones(len(x)), right, x, right * x])
    bread = np.linalg.inv(X.T @ (w[:, None] * X))
    outcomes = sample[["earnings", "participated"]].to_numpy(dtype=float)
    beta = bread @ X.T @ (w[:, None] * outcomes)
    residuals = outcomes - X @ beta
    # HC0 covariance uses each observation's weighted design score, with shared cross-outcome scores.
    # Cross-outcome meat terms preserve covariance of the two jump estimates.
    score_rows = (X * w[:, None])[:, :, None] * residuals[:, None, :]
    joint_meat = np.einsum("iak, ibl->akbl", score_rows, score_rows)
    joint_bread = np.kron(bread, np.eye(2))
    joint_cov = joint_bread @ joint_meat.reshape(8, 8) @ joint_bread.T
    jumps = beta[1, :]
    rf, fs = jumps
    cov_jumps = joint_cov[np.ix_([2, 3], [2, 3])]
    te = rf / fs
    grad = np.array([1.0 / fs, -rf / (fs * fs)])
    te_var = float(grad @ cov_jumps @ grad)
    rows = [
        {"term": "treatment_effect", "estimate": float(te), "se": float(np.sqrt(max(te_var, 0.0))), "n_obs": int(len(sample))},
        {"term": "reduced_form", "estimate": float(rf), "se": float(np.sqrt(joint_cov[2, 2])), "n_obs": int(len(sample))},
        {"term": "first_stage", "estimate": float(fs), "se": float(np.sqrt(joint_cov[3, 3])), "n_obs": int(len(sample))},
    ]
    result = {
        "task_id": "applied_fuzzy_rd",
        "platform": "python",
        "estimates": rows,
        "method_metadata": {"estimator": "Fuzzy RD local-linear WLS, triangular weights, cutoff 0, bandwidth 1", "vcov": "HC0 sandwich; delta method with joint reduced-form/first-stage covariance; fixed bandwidth and weights"},
        "diagnostics": {},
    }
    with open("result.json", "w") as f:
        json.dump(result, f, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
