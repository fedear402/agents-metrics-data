import json
import pandas as pd
from scipy import stats

# Read the supplied outcome and group labels without transforming either variable.
data = pd.read_csv("./input.csv")
analysis = data[["group", "y"]].dropna()
groups = [part["y"].to_numpy() for _, part in analysis.groupby("group", sort=True)]
n_obs = int(len(analysis))
k = len(groups)

F, p_value = stats.f_oneway(*groups)
df_num = k - 1
df_den = n_obs - k

out = {
    "task_id": "anova_oneway",
    "platform": "python",
    "estimates": [
        {"term": "F", "estimate": float(F), "se": None, "n_obs": n_obs},
        {"term": "df_num", "estimate": float(df_num), "se": None, "n_obs": n_obs},
        {"term": "df_den", "estimate": float(df_den), "se": None, "n_obs": n_obs},
        {"term": "p_value", "estimate": float(p_value), "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {"estimator": "One-way ANOVA", "vcov": "none"},
    "diagnostics": {},
}
with open("result.json", "w") as f:
    json.dump(out, f, indent=2)
