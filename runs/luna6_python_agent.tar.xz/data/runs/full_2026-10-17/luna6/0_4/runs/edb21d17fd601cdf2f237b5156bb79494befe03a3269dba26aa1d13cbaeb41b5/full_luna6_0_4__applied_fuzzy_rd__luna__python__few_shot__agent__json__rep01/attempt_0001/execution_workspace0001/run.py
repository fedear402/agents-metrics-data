import json
import numpy as np
import pandas as pd

TASK_ID = "applied_fuzzy_rd"


def fit_local_linear(data):
    score = data["score"].to_numpy(dtype=float)
    weight = 1.0 - np.abs(score)
    right = (score >= 0).astype(float)
    # Common parameterization: separate intercepts and slopes by side.
    X = np.column_stack([
        1.0 - right,
        (1.0 - right) * score,
        right,
        right * score,
    ])
    Y = data[["earnings", "participated"]].to_numpy(dtype=float)
    bread = np.linalg.inv(X.T @ (weight[:, None] * X))
    beta = bread @ X.T @ (weight[:, None] * Y)
    residual = Y - X @ beta
    # right-limit minus left-limit; intercepts are the first and third coefficients.
    contrast = np.array([-1.0, 0.0, 1.0, 0.0])
    jumps = contrast @ beta
    loading = weight * (X @ bread @ contrast)
    influence = loading[:, None] * residual
    joint_cov = influence.T @ influence
    return jumps, joint_cov


def main():
    data = pd.read_csv("input.csv")
    sample = data.loc[data["score"].abs() < 1.0].copy()
    if sample.empty:
        raise ValueError("No observations inside the specified bandwidth")
    if not set(sample["participated"].unique()).issubset({0, 1}):
        raise ValueError("participated must contain only 0 and 1")
    jumps, joint = fit_local_linear(sample)
    reduced_form, first_stage = jumps
    treatment_effect = reduced_form / first_stage
    gradient = np.array([1.0 / first_stage, -reduced_form / first_stage**2])
    ratio_variance = float(gradient @ joint @ gradient)
    rows = [
        {"term": "treatment_effect", "estimate": float(treatment_effect),
         "se": float(np.sqrt(ratio_variance)), "n_obs": int(len(sample))},
        {"term": "reduced_form", "estimate": float(reduced_form),
         "se": float(np.sqrt(joint[0, 0])), "n_obs": int(len(sample))},
        {"term": "first_stage", "estimate": float(first_stage),
         "se": float(np.sqrt(joint[1, 1])), "n_obs": int(len(sample))},
    ]
    output = {
        "task_id": TASK_ID,
        "platform": "python",
        "estimates": rows,
        "method_metadata": {
            "estimator": "weighted separate local-linear fuzzy regression discontinuity; triangular weights; bandwidth 1",
            "vcov": "joint HC0 sandwich; fixed bandwidth and weights; delta method for ratio; no degrees-of-freedom correction",
        },
        "diagnostics": {},
    }
    with open("result.json", "w") as stream:
        json.dump(output, stream, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
