import json
import numpy as np
import pandas as pd

TASK_ID = "applied_fuzzy_rd"


def main():
    df = pd.read_csv("input.csv")
    required = {"id", "score", "participated", "earnings"}
    if not required.issubset(df.columns):
        raise ValueError(f"Missing columns: {required - set(df.columns)}")

    # Strict bandwidth rule from the task.
    sample = df.loc[df["score"].abs() < 1].copy()
    score = sample["score"].to_numpy(dtype=float)
    right = (score >= 0).astype(float)
    weight = 1 - np.abs(score)

    # Piecewise local linear regression: separate intercept and slope per side.
    # At score zero, the two side intercept coefficients give the discontinuity.
    x = np.column_stack([
        np.ones(len(sample)), right,
        score * (1 - right), score * right,
    ])
    y = sample[["earnings", "participated"]].to_numpy(dtype=float)
    xtwx = x.T @ (weight[:, None] * x)
    bread = np.linalg.inv(xtwx)
    beta = bread @ x.T @ (weight[:, None] * y)
    resid = y - x @ beta

    # Right-limit minus left-limit, selected by coefficient contrast [0, 1, 0, 0].
    contrast = np.array([0., 1., 0., 0.])
    jumps = contrast @ beta
    # HC0 sandwich for both outcomes, retaining the observation-level cross-product.
    loading = weight * (x @ bread @ contrast)
    influence = loading[:, None] * resid
    joint_cov = influence.T @ influence

    reduced_form, first_stage = jumps
    treatment_effect = reduced_form / first_stage
    gradient = np.array([1 / first_stage, -reduced_form / first_stage**2])
    ratio_var = float(gradient @ joint_cov @ gradient)
    if ratio_var < 0 and ratio_var > -1e-12:
        ratio_var = 0.0
    ratio_se = float(np.sqrt(ratio_var))
    n_obs = int(len(sample))

    output = {
        "task_id": TASK_ID,
        "platform": "python",
        "estimates": [
            {"term": "treatment_effect", "estimate": float(treatment_effect), "se": ratio_se, "n_obs": n_obs},
            {"term": "reduced_form", "estimate": float(reduced_form), "se": float(np.sqrt(joint_cov[0, 0])), "n_obs": n_obs},
            {"term": "first_stage", "estimate": float(first_stage), "se": float(np.sqrt(joint_cov[1, 1])), "n_obs": n_obs},
        ],
        "method_metadata": {
            "estimator": "Weighted piecewise local-linear fuzzy RD; triangular kernel; bandwidth 1; right limit minus left limit",
            "vcov": "HC0 sandwich with joint outcome covariance; delta method for ratio; no degrees-of-freedom correction",
        },
        "diagnostics": {},
    }
    with open("result.json", "w") as stream:
        json.dump(output, stream, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
