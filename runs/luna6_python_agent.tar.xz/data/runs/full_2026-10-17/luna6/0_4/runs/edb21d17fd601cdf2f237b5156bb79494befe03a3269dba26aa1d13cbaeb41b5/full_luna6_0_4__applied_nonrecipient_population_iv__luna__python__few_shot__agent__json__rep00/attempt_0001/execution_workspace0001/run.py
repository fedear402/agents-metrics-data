import json
import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS

households = pd.read_csv('households.csv')
census = pd.read_csv('census.csv')

# Retain all nonrecipient households in both village treatment statuses.
d = households.loc[households['recipient'].eq(0)].copy()
assert set(d['eligible'].unique()).issubset({0, 1})
assert (d['weight'] > 0).all()

# Saturated eligibility-group construction, with no additional intercept.
d['ineligible'] = 1 - d['eligible']
d['exog_ineligible'] = d['ineligible']
d['exog_eligible'] = d['eligible']
d['baseline_ineligible'] = d['baseline'] * d['ineligible']
d['baseline_eligible'] = d['baseline'] * d['eligible']
d['dose_ineligible'] = d['dose'] * d['ineligible']
d['dose_eligible'] = d['dose'] * d['eligible']
d['instrument_ineligible'] = d['instrument'] * d['ineligible']
d['instrument_eligible'] = d['instrument'] * d['eligible']

exog = d[['exog_ineligible', 'exog_eligible', 'baseline_ineligible', 'baseline_eligible']]
endog = d[['dose_ineligible', 'dose_eligible']]
# IV2SLS adds exogenous regressors to excluded instruments internally.
instruments = d[['instrument_ineligible', 'instrument_eligible']]
fit = IV2SLS(d['outcome'], exog, endog, instruments, weights=d['weight']).fit()

n_obs = int(len(d))
group_effects = {}
for eligible, term, name in [
    (0, 'dose_ineligible', 'ineligible_effect'),
    (1, 'dose_eligible', 'eligible_nonrecipient_effect'),
]:
    group = d.loc[d['eligible'].eq(eligible)]
    slope = float(fit.params[term])
    mean_dose = float(np.average(group['dose'], weights=group['weight']))
    group_effects[name] = slope * mean_dose

pop_weights = census.set_index('eligible')['nonrecipient_population']
assert set(pop_weights.index) == {0, 1}
population_effect = float(np.average(
    [group_effects['ineligible_effect'], group_effects['eligible_nonrecipient_effect']],
    weights=[pop_weights.loc[0], pop_weights.loc[1]],
))

result = {
    'task_id': 'applied_nonrecipient_population_iv',
    'platform': 'python',
    'estimates': [
        {'term': 'ineligible_effect', 'estimate': group_effects['ineligible_effect'], 'se': None, 'n_obs': n_obs},
        {'term': 'eligible_nonrecipient_effect', 'estimate': group_effects['eligible_nonrecipient_effect'], 'se': None, 'n_obs': n_obs},
        {'term': 'population_effect', 'estimate': population_effect, 'se': None, 'n_obs': n_obs},
    ],
    'method_metadata': {
        'estimator': 'weighted 2SLS (IV2SLS)',
        'sample': 'all households with recipient=0, including both village treatment statuses',
        'dependent_variable': 'outcome',
        'endogenous_columns': ['dose*(1-eligible)', 'dose*eligible'],
        'exogenous_columns': ['1-eligible', 'eligible', 'baseline*(1-eligible)', 'baseline*eligible'],
        'instrument_columns': ['1-eligible', 'eligible', 'baseline*(1-eligible)', 'baseline*eligible', 'instrument*(1-eligible)', 'instrument*eligible'],
        'regression_weight': 'weight',
        'within_group_effect': 'fitted dose slope times household-weighted mean dose in that eligibility group',
        'counterfactual': 'dose=0 for every retained household; attribution is a stated synthetic convention',
        'population_aggregation_weight': 'census.nonrecipient_population, used only for final between-group aggregation',
    },
    'diagnostics': {
        'n_obs': n_obs,
        'nonrecipient_rows_by_eligible': {str(k): int(v) for k, v in d.groupby('eligible').size().items()},
        'group_slopes': {
            'ineligible': float(fit.params['dose_ineligible']),
            'eligible': float(fit.params['dose_eligible']),
        },
        'weighted_mean_dose': {
            'ineligible': float(np.average(d.loc[d.eligible.eq(0), 'dose'], weights=d.loc[d.eligible.eq(0), 'weight'])),
            'eligible': float(np.average(d.loc[d.eligible.eq(1), 'dose'], weights=d.loc[d.eligible.eq(1), 'weight'])),
        },
        'census_nonrecipient_population': {str(int(k)): int(v) for k, v in pop_weights.items()},
    },
}

with open('result.json', 'w') as f:
    json.dump(result, f, indent=2, allow_nan=False)
