import json
import numpy as np
import pandas as pd

# Load and order the observed trading sessions before constructing changes and lags.
data = pd.read_csv('input.csv', parse_dates=['date'])
required = ['date', 'sales', 'vix']
if list(data.columns) != required:
    raise ValueError(f'Expected columns {required}, found {list(data.columns)}')
data = data.sort_values('date').reset_index(drop=True)
if data[required].isna().any().any() or (data[['sales', 'vix']] <= 0).any().any():
    raise ValueError('Input values must be complete and sales and vix must be positive')
if data['date'].duplicated().any():
    raise ValueError('Dates must be unique')

data['vix_change'] = np.log(data['vix']).diff()
for j in range(1, 16):
    data[f'lag_{j}'] = data['vix_change'].shift(j)
data['log_sales'] = np.log(data['sales'])
cols = [f'lag_{j}' for j in range(1, 16)]
sample = data.dropna(subset=['log_sales', *cols]).copy()
N = len(sample)
X = np.column_stack([np.ones(N), sample[cols].to_numpy()])
y = sample['log_sales'].to_numpy()
# OLS estimates and chronological regression-sample residual scores.
beta = np.linalg.lstsq(X, y, rcond=None)[0]
resid = y - X @ beta
scores = X * resid[:, None]
# Bartlett Newey-West meat, with the requested maximum lag.
meat = scores.T @ scores
for j in range(1, 16):
    weight = 1 - j / 16
    cross = scores[j:].T @ scores[:-j]
    meat += weight * (cross + cross.T)
bread = np.linalg.inv(X.T @ X)
cov = (N / (N - 16)) * bread @ meat @ bread

contrast = np.r_[0.0, np.ones(15)]
rows = [
    {'term': 'cumulative_response', 'estimate': float(contrast @ beta), 'se': float(np.sqrt(contrast @ cov @ contrast)), 'n_obs': int(N)},
    {'term': 'lag_1', 'estimate': float(beta[1]), 'se': float(np.sqrt(cov[1, 1])), 'n_obs': int(N)},
    {'term': 'lag_15', 'estimate': float(beta[15]), 'se': float(np.sqrt(cov[15, 15])), 'n_obs': int(N)},
]
out = {
    'task_id': 'applied_cumulative_hac',
    'platform': 'python',
    'estimates': rows,
    'method_metadata': {'estimator': 'OLS with intercept and 15 lagged log-VIX changes', 'vcov': 'Newey-West HAC, Bartlett max lag 15, finite-sample correction N/(N-16)'},
    'diagnostics': {'input_rows': int(len(data)), 'regression_n_obs': int(N), 'regression_lags': 15, 'hac_max_lag': 15, 'parameter_count': int(X.shape[1]), 'first_sample_date': sample['date'].iloc[0].strftime('%Y-%m-%d'), 'last_sample_date': sample['date'].iloc[-1].strftime('%Y-%m-%d')}
}
with open('result.json', 'w') as f:
    json.dump(out, f, indent=2, allow_nan=False)
