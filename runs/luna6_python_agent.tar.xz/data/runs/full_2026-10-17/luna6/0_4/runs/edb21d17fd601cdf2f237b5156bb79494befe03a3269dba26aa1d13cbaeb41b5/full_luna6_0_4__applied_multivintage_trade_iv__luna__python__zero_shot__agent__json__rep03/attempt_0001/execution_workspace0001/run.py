import json
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
crosswalk = pd.read_csv(ROOT / 'crosswalk.csv')
trade = pd.read_csv(ROOT / 'trade.csv')
areas = pd.read_csv(ROOT / 'areas.csv')
employment = pd.read_csv(ROOT / 'employment.csv')
outcomes = pd.read_csv(ROOT / 'outcomes.csv')

# Join all trade rows to the supplied industry crosswalk.
trade = trade.merge(crosswalk, on='code', how='inner', validate='many_to_one')
industries = crosswalk['industry'].tolist()
assert len(set(industries)) == 4 and crosswalk['code'].is_unique
assert not trade.duplicated(['period', 'industry']).any()

# Complete omitted area-industry cells as zero, separately by vintage.
keys = areas[['area', 'period', 'vintage', 'total_employment', 'population']].drop_duplicates()
full = keys[['area', 'period', 'vintage']].merge(
    pd.DataFrame({'industry': industries}), how='cross')
employment_full = full.merge(
    employment, on=['area', 'period', 'vintage', 'industry'], how='left', validate='many_to_one')
employment_full['employment'] = employment_full['employment'].fillna(0)

# National denominators sum employment across every supplied area, by period and vintage.
national = employment_full.groupby(['period', 'vintage', 'industry'], as_index=False)['employment'].sum()

trade_long = trade.melt(
    id_vars=['period', 'industry', 'price_index', 'years'],
    value_vars=['us_change', 'other_change'], var_name='flow', value_name='trade_change')
trade_long['vintage'] = trade_long['flow'].map({'us_change': 'base', 'other_change': 'early'})
trade_long['trade_per_worker_scale'] = (
    trade_long['trade_change'] / (trade_long['price_index'] / 100) / 1000
    * (10 / trade_long['years']))

# For each vintage, multiply the area industry share by real trade change per national worker.
exp = employment_full.merge(
    national.rename(columns={'employment': 'national_employment'}),
    on=['period', 'vintage', 'industry'], validate='many_to_one')
exp = exp.merge(
    keys[['area', 'period', 'vintage', 'total_employment']],
    on=['area', 'period', 'vintage'], suffixes=('', '_key'), validate='many_to_one')
# The duplicate total field originates from the complete-cell key; use it as the area denominator.
exp = exp.merge(trade_long[['period', 'industry', 'vintage', 'trade_per_worker_scale']],
                on=['period', 'industry', 'vintage'], validate='many_to_one')
exp['component'] = (exp['employment'] / exp['total_employment']
                    * exp['trade_per_worker_scale'] / exp['national_employment'])
exposure = exp.groupby(['area', 'period', 'vintage'], as_index=False)['component'].sum()
exposure = exposure.pivot(index=['area', 'period'], columns='vintage', values='component').reset_index()
exposure = exposure.rename(columns={'base': 'x', 'early': 'z'})

base_weights = areas.loc[areas.vintage == 'base', ['area', 'period', 'population']]
est = outcomes.merge(exposure, on=['area', 'period'], how='inner', validate='many_to_one')
est = est.merge(base_weights, on=['area', 'period'], how='inner', validate='many_to_one')
periods = sorted(est['period'].unique())
assert len(est) == 72
est['period_indicator'] = (est['period'] == periods[1]).astype(float)

# Weighted 2SLS: regress each endogenous and exogenous regressor on all instruments,
# then solve the weighted projected normal equations.
y = est['change_pp'].to_numpy(float)
X = np.column_stack([np.ones(len(est)), est['period_indicator'], est['control'], est['x']])
Q = np.column_stack([np.ones(len(est)), est['period_indicator'], est['control'], est['z']])
w = est['population'].to_numpy(float)
sqrtw = np.sqrt(w)
Xw, Qw, yw = X * sqrtw[:, None], Q * sqrtw[:, None], y * sqrtw
Pq_X = Qw @ np.linalg.solve(Qw.T @ Qw, Qw.T @ Xw)
Pq_y = Qw @ np.linalg.solve(Qw.T @ Qw, Qw.T @ yw)
beta = np.linalg.solve(Xw.T @ Pq_X, Xw.T @ Pq_y)

lookup = est.set_index(['area', 'period'])
results = [
    {'term': 'iv_slope', 'estimate': float(beta[3]), 'se': None, 'n_obs': 72},
    {'term': 'exposure_area0_period0', 'estimate': float(lookup.loc[(0, periods[0]), 'x']), 'se': None, 'n_obs': 72},
    {'term': 'exposure_area0_period1', 'estimate': float(lookup.loc[(0, periods[1]), 'x']), 'se': None, 'n_obs': 72},
    {'term': 'instrument_area0_period0', 'estimate': float(lookup.loc[(0, periods[0]), 'z']), 'se': None, 'n_obs': 72},
]

# Independent checks: direct weighted 2SLS formula using unprojected cross-products,
# and direct component sum for each reported exposure.
A = X.T @ (w[:, None] * Q) @ np.linalg.solve(Q.T @ (w[:, None] * Q), Q.T @ (w[:, None] * X))
b = X.T @ (w[:, None] * Q) @ np.linalg.solve(Q.T @ (w[:, None] * Q), Q.T @ (w * y))
beta_direct = np.linalg.solve(A, b)
assert np.allclose(beta, beta_direct, rtol=1e-11, atol=1e-11)
for area, period, vintage, reported in [
    (0, periods[0], 'base', results[1]['estimate']),
    (0, periods[1], 'base', results[2]['estimate']),
    (0, periods[0], 'early', results[3]['estimate']),
]:
    rows = exp[(exp.area == area) & (exp.period == period) & (exp.vintage == vintage)]
    direct = sum(r.employment / r.total_employment * r.trade_per_worker_scale / r.national_employment
                 for r in rows.itertuples())
    assert np.isclose(direct, reported, rtol=1e-12, atol=1e-12)

output = {
    'task_id': 'applied_multivintage_trade_iv',
    'platform': 'python',
    'estimates': results,
    'method_metadata': {
        'estimator': 'population-weighted 2SLS',
        'outcome': 'change_pp',
        'regressors': ['intercept', 'period_indicator', 'control', 'x'],
        'instrument_set': ['intercept', 'period_indicator', 'control', 'z'],
        'weight': 'base-vintage population',
        'exposure_units': 'thousands of real dollars per worker per decade',
        'n_obs': 72,
    },
    'diagnostics': {
        'n_obs': 72,
        'n_areas': int(est['area'].nunique()),
        'n_periods': int(est['period'].nunique()),
        'n_industries': int(len(set(industries))),
        'missing_cells_filled_with_zero': int(len(full) - len(employment)),
        'independent_2sls_formula_agrees': True,
        'reported_exposures_recomputed_from_components': True,
    },
}
with (ROOT / 'result.json').open('w') as f:
    json.dump(output, f, indent=2, allow_nan=False)
print(json.dumps(output, indent=2))
