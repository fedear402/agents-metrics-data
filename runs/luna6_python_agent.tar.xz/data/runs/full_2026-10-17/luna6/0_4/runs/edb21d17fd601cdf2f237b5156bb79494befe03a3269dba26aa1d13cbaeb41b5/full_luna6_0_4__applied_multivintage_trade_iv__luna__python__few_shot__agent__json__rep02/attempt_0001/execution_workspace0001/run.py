import json
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
crosswalk = pd.read_csv(ROOT / "crosswalk.csv")
trade = pd.read_csv(ROOT / "trade.csv").merge(crosswalk, on="code", validate="many_to_one")
areas = pd.read_csv(ROOT / "areas.csv")
employment = pd.read_csv(ROOT / "employment.csv")
outcomes = pd.read_csv(ROOT / "outcomes.csv")

# A sparse employment table means every omitted area-period-vintage-industry cell is zero.
industries = sorted(crosswalk["industry"].unique())
periods = sorted(areas["period"].unique())
wide = employment.pivot_table(
    index=["area", "period", "vintage"], columns="industry", values="employment",
    aggfunc="sum", fill_value=0,
).reindex(columns=industries, fill_value=0)

exposure_rows = []
for period in periods:
    tr = trade.loc[trade.period == period].set_index("industry").reindex(industries)
    if tr[["us_change", "other_change", "price_index", "years"]].isna().any().any():
        raise ValueError(f"Missing trade inputs for period {period}")
    if tr["price_index"].nunique() != 1 or tr["years"].nunique() != 1:
        raise ValueError(f"price_index and years must be constant within period {period}")
    price_index = float(tr["price_index"].iloc[0])
    years = float(tr["years"].iloc[0])
    if price_index <= 0 or years <= 0:
        raise ValueError("price_index and years must be positive")

    for vintage, change_column, exposure_name in [
        ("base", "us_change", "x"), ("early", "other_change", "z")
    ]:
        emp = wide.xs((period, vintage), level=("period", "vintage"))
        national = emp.sum(axis=0)
        if (national <= 0).any():
            raise ValueError(f"Nonpositive national employment denominator in period {period}")
        shocks = (
            tr[change_column].to_numpy(dtype=float)
            / national.to_numpy(dtype=float)
            / (price_index / 100.0)
            / 1000.0
            * (10.0 / years)
        )
        totals = areas.loc[
            (areas.period == period) & (areas.vintage == vintage)
        ].set_index("area")["total_employment"]
        numerator = emp.to_numpy(dtype=float) @ shocks
        result = numerator / totals.reindex(emp.index).to_numpy(dtype=float)
        for area, value in zip(emp.index, result):
            exposure_rows.append({"area": area, "period": period, exposure_name: float(value)})

exposures = pd.DataFrame(exposure_rows).groupby(["area", "period"], as_index=False).first()
sample = (outcomes.merge(areas.loc[areas.vintage == "base", ["area", "period", "population"]],
                         on=["area", "period"], validate="one_to_one")
          .merge(exposures, on=["area", "period"], validate="one_to_one")
          .sort_values(["area", "period"]).reset_index(drop=True))
if len(sample) != 72:
    raise ValueError(f"Expected 72 area-period rows, got {len(sample)}")
if sample[["change_pp", "control", "x", "z", "population"]].isna().any().any():
    raise ValueError("Estimation sample has missing values")

# Weighted 2SLS: all exogenous regressors are included in the instrument matrix.
y = sample["change_pp"].to_numpy(dtype=float)
period = sample["period"].to_numpy(dtype=float)
control = sample["control"].to_numpy(dtype=float)
x = sample["x"].to_numpy(dtype=float)
z = sample["z"].to_numpy(dtype=float)
w = sample["population"].to_numpy(dtype=float)
X = np.column_stack([np.ones(len(sample)), period, control, x])
Q = np.column_stack([np.ones(len(sample)), period, control, z])
root_w = np.sqrt(w)
Xw, Qw, yw = X * root_w[:, None], Q * root_w[:, None], y * root_w
# The IV coefficient solves X'WQ(Q'WQ)^-1 Q'WX beta = X'WQ(Q'WQ)^-1 Q'Wy.
q_cross_x = Qw.T @ Xw
q_cross_y = Qw.T @ yw
middle = np.linalg.solve(Qw.T @ Qw, np.eye(Qw.shape[1]))
normal = q_cross_x.T @ middle @ q_cross_x
rhs = q_cross_x.T @ middle @ q_cross_y
beta = np.linalg.solve(normal, rhs)

area0p0 = sample.loc[(sample.area == 0) & (sample.period == 0), "x"]
area0p1 = sample.loc[(sample.area == 0) & (sample.period == 1), "x"]
area0p0z = sample.loc[(sample.area == 0) & (sample.period == 0), "z"]
if any(len(v) != 1 for v in [area0p0, area0p1, area0p0z]):
    raise ValueError("Requested area-period exposure row is missing or duplicated")

estimates = [
    {"term": "iv_slope", "estimate": float(beta[3]), "se": None, "n_obs": int(len(sample))},
    {"term": "exposure_area0_period0", "estimate": float(area0p0.iloc[0]), "se": None, "n_obs": int(len(sample))},
    {"term": "exposure_area0_period1", "estimate": float(area0p1.iloc[0]), "se": None, "n_obs": int(len(sample))},
    {"term": "instrument_area0_period0", "estimate": float(area0p0z.iloc[0]), "se": None, "n_obs": int(len(sample))},
]

# Independent checks: direct raw-cell exposure calculation and Frisch-Waugh-Lovell IV identity.
cell_check = []
for per, vint, chg_col, term in [(0, "base", "us_change", "x"), (1, "base", "us_change", "x"),
                                 (0, "early", "other_change", "z")]:
    tr = pd.read_csv(ROOT / "trade.csv").loc[lambda d: d.period == per].merge(crosswalk, on="code", validate="many_to_one")
    area_em = employment.loc[(employment.area == 0) & (employment.period == per) &
                             (employment.vintage == vint)].groupby("industry")["employment"].sum().reindex(industries, fill_value=0.0)
    national_emp = employment.loc[(employment.period == per) & (employment.vintage == vint)].groupby("industry")["employment"].sum()
    den = float(areas.loc[(areas.area == 0) & (areas.period == per) & (areas.vintage == vint),
                          "total_employment"].iloc[0])
    pidx, yrs = float(tr.price_index.iloc[0]), float(tr.years.iloc[0])
    shock = tr.set_index("industry")[chg_col] / national_emp.reindex(industries) / (pidx / 100.0) / 1000.0 * (10.0 / yrs)
    emp_vec = area_em
    cell_check.append(float((emp_vec * shock).sum() / den))

# Partial out the three exogenous regressors using weighted least squares; then compute IV slope.
C = X[:, :3]
Cw = C * root_w[:, None]
resid_x = Xw[:, 3] - Cw @ np.linalg.solve(Cw.T @ Cw, Cw.T @ Xw[:, 3])
resid_z = Qw[:, 3] - Cw @ np.linalg.solve(Cw.T @ Cw, Cw.T @ Qw[:, 3])
resid_y = yw - Cw @ np.linalg.solve(Cw.T @ Cw, Cw.T @ yw)
fwl_slope = float((resid_z @ resid_y) / (resid_z @ resid_x))

if not np.allclose(cell_check, [area0p0.iloc[0], area0p1.iloc[0], area0p0z.iloc[0]], rtol=1e-12, atol=1e-12):
    raise AssertionError("Independent raw-cell exposure check failed")
if not np.isclose(fwl_slope, beta[3], rtol=1e-10, atol=1e-10):
    raise AssertionError("Independent FWL IV check failed")

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "weighted two-stage least squares",
        "outcome": "change_pp",
        "regressors": ["intercept", "period", "control", "x"],
        "instruments": ["intercept", "period", "control", "z"],
        "weight": "base-vintage population",
        "exposure_units": "thousands of real dollars per worker per decade",
    },
    "diagnostics": {
        "n_obs": int(len(sample)),
        "n_areas": int(sample.area.nunique()),
        "n_periods": int(sample.period.nunique()),
        "n_industries": int(len(industries)),
        "independent_exposure_checks_passed": True,
        "fwl_iv_slope_check_passed": True,
        "fwl_iv_slope": fwl_slope,
    },
}
with (ROOT / "result.json").open("w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, allow_nan=False)
    f.write("\n")

with (ROOT / "verification.txt").open("w", encoding="utf-8") as f:
    f.write("Verification checks\n")
    f.write(f"Estimation sample: {len(sample)} rows, {sample.area.nunique()} areas, {sample.period.nunique()} periods.\n")
    f.write("Sample check passed: all outcomes merged one-to-one with base population and constructed x,z.\n")
    f.write("Employment construction: sparse employment cells filled with zero; national sums computed by period and vintage.\n")
    f.write("Specification: weighted 2SLS with regressors [intercept, period, control, x] and instruments [intercept, period, control, z].\n")
    f.write(f"Independent raw-cell exposure checks: {cell_check}; all match the vectorized calculations.\n")
    f.write(f"Independent weighted FWL IV slope: {fwl_slope:.12g}; direct weighted 2SLS x slope: {float(beta[3]):.12g}; agreement passed.\n")
print(json.dumps(result, indent=2))
