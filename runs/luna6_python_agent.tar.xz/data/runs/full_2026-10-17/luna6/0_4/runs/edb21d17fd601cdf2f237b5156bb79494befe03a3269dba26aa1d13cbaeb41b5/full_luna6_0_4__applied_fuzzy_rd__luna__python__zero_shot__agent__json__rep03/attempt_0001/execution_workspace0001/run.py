import json
import numpy as np
import pandas as pd

DATA = "input.csv"
OUT = "result.json"

df = pd.read_csv(DATA)
required = {"id", "score", "participated", "earnings"}
if not required.issubset(df.columns):
    raise ValueError(f"Missing columns: {required - set(df.columns)}")

sample = df.loc[df["score"].abs() < 1].copy()
s = sample["score"].to_numpy(dtype=float)
w = 1.0 - np.abs(s)
right = (s >= 0).astype(float)
# Separate local linear regressions with side-specific intercepts and slopes.
X = np.column_stack([1 - right, (1 - right) * s, right, right * s])
if len(sample) == 0 or np.any(w <= 0):
    raise ValueError("Empty sample or invalid triangular weights")

Y = sample[["earnings", "participated"]].to_numpy(dtype=float)
W = np.diag(w)
XtWX = X.T @ W @ X
bread = np.linalg.inv(XtWX)
beta = bread @ X.T @ W @ Y
resid = Y - X @ beta
# HC0 sandwich, with the same design and weights for both outcomes.
meat = X.T @ ((w ** 2)[:, None] * (resid ** 2))
# Joint covariance of coefficients: outcomes share design, weights, observations.
# For each observation, score vector is x_i*w_i*(earnings residual, participation residual).
# Equivalent full covariance across 8 coefficients, in outcome-major order.
score = np.concatenate([X * (w * resid[:, 0])[:, None], X * (w * resid[:, 1])[:, None]], axis=1)
V_joint = np.kron(np.eye(2), bread) @ (score.T @ score) @ np.kron(np.eye(2), bread)

# Coefficient order: left intercept, left slope, right intercept, right slope.
# Right-limit minus left-limit is the difference in intercepts.
c = np.array([-1., 0., 1., 0.])
rf = float(c @ beta[:, 0])
fs = float(c @ beta[:, 1])
V_rf_fs = np.array([[c @ V_joint[:4, :4] @ c, c @ V_joint[:4, 4:] @ c],
                     [c @ V_joint[4:, :4] @ c, c @ V_joint[4:, 4:] @ c]])
ratio = rf / fs
# Gradient in (reduced form, first stage) order.
grad = np.array([1.0 / fs, -rf / (fs ** 2)])
var_ratio = float(grad @ V_rf_fs @ grad)

n = int(len(sample))
estimates = [
    {"term": "treatment_effect", "estimate": ratio, "se": float(np.sqrt(max(var_ratio, 0.0))), "n_obs": n},
    {"term": "reduced_form", "estimate": rf, "se": float(np.sqrt(max(V_rf_fs[0, 0], 0.0))), "n_obs": n},
    {"term": "first_stage", "estimate": fs, "se": float(np.sqrt(max(V_rf_fs[1, 1], 0.0))), "n_obs": n},
]
result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "Weighted local-linear fuzzy regression discontinuity; cutoff=0, bandwidth=1, triangular weights; separate side intercepts and slopes",
        "vcov": "HC0 sandwich with fixed weights; treatment effect delta method using joint reduced-form and first-stage covariance",
    },
    "diagnostics": {},
}
with open(OUT, "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, allow_nan=False)
