import json
import pandas as pd
from scipy import stats

DATA_PATH = "./input.csv"
OUTPUT_PATH = "./result.json"


def main():
    data = pd.read_csv(DATA_PATH)
    required = {"group", "y"}
    if not required.issubset(data.columns):
        raise ValueError(f"Required columns are missing: {required - set(data.columns)}")
    sample = data[["group", "y"]].dropna()
    groups = [part["y"].to_numpy(dtype=float) for _, part in sample.groupby("group", sort=True)]
    if len(groups) < 2 or any(len(g) == 0 for g in groups):
        raise ValueError("One-way ANOVA requires at least two nonempty groups")

    result = stats.f_oneway(*groups)
    n_obs = int(len(sample))
    n_groups = len(groups)
    df_num = n_groups - 1
    df_den = n_obs - n_groups
    estimates = [
        {"term": "F", "estimate": float(result.statistic), "se": None, "n_obs": n_obs},
        {"term": "df_num", "estimate": float(df_num), "se": None, "n_obs": n_obs},
        {"term": "df_den", "estimate": float(df_den), "se": None, "n_obs": n_obs},
        {"term": "p_value", "estimate": float(result.pvalue), "se": None, "n_obs": n_obs},
    ]
    output = {
        "task_id": "anova_oneway",
        "platform": "python",
        "estimates": estimates,
        "method_metadata": {"estimator": "Classical one-way ANOVA", "vcov": "Pooled within-group variance (classical homoskedastic ANOVA)"},
        "diagnostics": {"n_obs": n_obs, "n_groups": n_groups},
    }
    with open(OUTPUT_PATH, "w", encoding="utf-8") as stream:
        json.dump(output, stream, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
