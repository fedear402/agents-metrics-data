import json
from pathlib import Path

import pandas as pd
from scipy import stats
import statsmodels.api as sm
from statsmodels.formula.api import ols


def main():
    data = pd.read_csv(Path(__file__).with_name("input.csv"))
    if list(data.columns) != ["group", "y"]:
        raise ValueError("Expected columns: group, y")
    sample = data[["group", "y"]].dropna()
    groups = [part["y"].to_numpy() for _, part in sample.groupby("group", sort=True)]
    if len(groups) < 2:
        raise ValueError("One-way ANOVA requires at least two groups")

    model = ols("y ~ C(group)", data=sample).fit()
    table = sm.stats.anova_lm(model, typ=2)
    row = table.loc["C(group)"]
    f_stat = float(row["F"])
    df_num = float(row["df"])
    df_den = float(table.loc["Residual", "df"])
    p_value = float(row["PR(>F)"])
    n_obs = int(len(sample))

    estimates = [
        {"term": term, "estimate": estimate, "se": None, "n_obs": n_obs}
        for term, estimate in [
            ("F", f_stat),
            ("df_num", df_num),
            ("df_den", df_den),
            ("p_value", p_value),
        ]
    ]
    result = {
        "task_id": "anova_oneway",
        "platform": "python",
        "estimates": estimates,
        "method_metadata": {
            "estimator": "one-way ANOVA via OLS with categorical group indicator",
            "vcov": "classical homoskedastic ANOVA",
        },
        "diagnostics": {},
    }
    with Path(__file__).with_name("result.json").open("w") as output:
        json.dump(result, output, indent=2, allow_nan=False)

    # Independent check: compute between- and within-group sums of squares directly.
    grand_mean = sample["y"].mean()
    ss_between = sum(len(g) * (g.mean() - grand_mean) ** 2 for g in (sample.loc[sample.group == label, "y"] for label in sample.group.unique()))
    ss_within = sum(((g - g.mean()) ** 2).sum() for g in groups)
    f_direct = (ss_between / df_num) / (ss_within / df_den)
    p_direct = stats.f.sf(f_direct, df_num, df_den)
    if not (abs(f_stat - f_direct) < 1e-10 and abs(p_value - p_direct) < 1e-12):
        raise ArithmeticError("Independent sums-of-squares check failed")
    print(f"n_rows={len(data)} n_used={n_obs} n_dropped={len(data)-n_obs} groups={len(groups)}")
    print(f"statsmodels_F={f_stat:.12g} direct_F={f_direct:.12g}")
    print(f"df_num={df_num:.12g} df_den={df_den:.12g}")
    print(f"statsmodels_p={p_value:.12g} direct_p={p_direct:.12g}")


if __name__ == "__main__":
    main()
