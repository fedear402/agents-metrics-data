import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

DATA = 'input.csv'
OUT = 'result.json'

df = pd.read_csv(DATA, parse_dates=['date']).sort_values('date').reset_index(drop=True)
df['dlog_vix'] = np.log(df['vix']).diff()
for k in range(1, 16):
    df[f'lag_{k}'] = df['dlog_vix'].shift(k)
df['log_sales'] = np.log(df['sales'])
reg = df.dropna(subset=['log_sales'] + [f'lag_{k}' for k in range(1, 16)]).copy()
xcols = [f'lag_{k}' for k in range(1, 16)]
X = sm.add_constant(reg[xcols], has_constant='add')
fit = sm.OLS(reg['log_sales'], X).fit()
N = len(reg)
# Explicit Bartlett HAC meat with lag zero through 15, then finite-sample factor.
u = np.asarray(fit.resid)
xa = np.asarray(X)
score = xa * u[:, None]
meat = score.T @ score
for j in range(1, 16):
    weight = 1 - j / 16
    gamma = score[j:].T @ score[:-j]
    meat += weight * (gamma + gamma.T)
inv_xx = np.linalg.inv(xa.T @ xa)
cov = inv_xx @ meat @ inv_xx * (N / (N - 16))
beta = np.asarray(fit.params)

# Sum of lag coefficients and full covariance-based SE.
cum_vec = np.zeros(len(beta))
for k in range(1, 16):
    cum_vec[X.columns.get_loc(f'lag_{k}')] = 1.0
estimates = [
    ('cumulative_response', float(cum_vec @ beta), float(np.sqrt(cum_vec @ cov @ cum_vec))),
    ('lag_1', float(fit.params['lag_1']), float(np.sqrt(cov[X.columns.get_loc('lag_1'), X.columns.get_loc('lag_1')]))),
    ('lag_15', float(fit.params['lag_15']), float(np.sqrt(cov[X.columns.get_loc('lag_15'), X.columns.get_loc('lag_15')]))),
]
result = {
    'task_id': 'applied_cumulative_hac',
    'platform': 'python',
    'estimates': [
        {'term': name, 'estimate': estimate, 'se': se, 'n_obs': N}
        for name, estimate, se in estimates
    ],
    'method_metadata': {
        'estimator': 'OLS of log(sales) on intercept and 15 lags of first differences of log(vix)',
        'vcov': 'Newey-West HAC, Bartlett weights, max lag 15, multiplied by N/(N-16)',
    },
    'diagnostics': {},
}
with open(OUT, 'w') as f:
    json.dump(result, f, indent=2, allow_nan=False)
