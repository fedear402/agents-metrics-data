import json
import numpy as np
import pandas as pd

h = pd.read_csv('households.csv')
c = pd.read_csv('census.csv')

# Keep all nonrecipient households, irrespective of village treatment status.
s = h.loc[h['recipient'].eq(0)].copy()
g0 = 1 - s['eligible'].to_numpy(dtype=float)
g1 = s['eligible'].to_numpy(dtype=float)
dose = s['dose'].to_numpy(dtype=float)
z = s['instrument'].to_numpy(dtype=float)
b = s['baseline'].to_numpy(dtype=float)
w = s['weight'].to_numpy(dtype=float)
y = s['outcome'].to_numpy(dtype=float)

# The specified design has no additional intercept.
X = np.column_stack([dose * g0, dose * g1,
                     g0, g1, b * g0, b * g1])
Q = np.column_stack([g0, g1, b * g0, b * g1,
                     z * g0, z * g1])
WQ = w[:, None] * Q
WX = w[:, None] * X
# Weighted 2SLS: (X'WQ (Q'WQ)^-1 Q'WX)^-1 X'WQ (Q'WQ)^-1 Q'Wy.
q_w_q = Q.T @ WQ
q_w_x = Q.T @ WX
q_w_y = Q.T @ (w * y)
coef = np.linalg.solve(q_w_x.T @ np.linalg.solve(q_w_q, q_w_x),
                       q_w_x.T @ np.linalg.solve(q_w_q, q_w_y))

slope0, slope1 = coef[:2]
mean_dose0 = np.average(dose[g0 == 1], weights=w[g0 == 1])
mean_dose1 = np.average(dose[g1 == 1], weights=w[g1 == 1])
effect0 = slope0 * mean_dose0
effect1 = slope1 * mean_dose1
pop = c.set_index('eligible')['nonrecipient_population']
pop_effect = (effect0 * int(pop.loc[0]) + effect1 * int(pop.loc[1])) / (int(pop.loc[0]) + int(pop.loc[1]))
n = int(len(s))

result = {
    'task_id': 'applied_nonrecipient_population_iv',
    'platform': 'python',
    'estimates': [
        {'term': 'ineligible_effect', 'estimate': float(effect0), 'se': None, 'n_obs': n},
        {'term': 'eligible_nonrecipient_effect', 'estimate': float(effect1), 'se': None, 'n_obs': n},
        {'term': 'population_effect', 'estimate': float(pop_effect), 'se': None, 'n_obs': n},
    ],
    'method_metadata': {
        'estimator': 'weighted 2SLS',
        'weight': 'weight',
        'endogenous_columns': ['dose*(1-eligible)', 'dose*eligible'],
        'exogenous_columns': ['1-eligible', 'eligible', 'baseline*(1-eligible)', 'baseline*eligible'],
        'instrument_columns': ['1-eligible', 'eligible', 'baseline*(1-eligible)', 'baseline*eligible', 'instrument*(1-eligible)', 'instrument*eligible'],
        'additional_intercept': False,
        'counterfactual': 'dose set to zero for every retained household; attribution is a stated synthetic convention',
        'within_group_dose_mean': 'household-weighted mean using weight',
        'population_aggregation_weights': 'nonrecipient_population from census.csv only',
    },
    'diagnostics': {
        'n_obs': n,
        'n_ineligible': int((s['eligible'] == 0).sum()),
        'n_eligible': int((s['eligible'] == 1).sum()),
        'ineligible_dose_slope': float(slope0),
        'eligible_dose_slope': float(slope1),
        'ineligible_weighted_mean_dose': float(mean_dose0),
        'eligible_weighted_mean_dose': float(mean_dose1),
        'census_nonrecipient_population_ineligible': int(pop.loc[0]),
        'census_nonrecipient_population_eligible': int(pop.loc[1]),
        'weighted_2sls_rank': int(np.linalg.matrix_rank(q_w_x)),
    },
}
with open('result.json', 'w') as f:
    json.dump(result, f, indent=2)
