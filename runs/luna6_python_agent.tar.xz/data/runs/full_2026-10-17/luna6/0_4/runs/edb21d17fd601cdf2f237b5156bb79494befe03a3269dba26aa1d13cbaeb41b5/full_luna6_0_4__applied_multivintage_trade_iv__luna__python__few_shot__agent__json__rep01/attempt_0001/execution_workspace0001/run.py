import json
from pathlib import Path
import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS

root = Path(__file__).resolve().parent
crosswalk = pd.read_csv(root / 'crosswalk.csv')
trade = pd.read_csv(root / 'trade.csv')
areas = pd.read_csv(root / 'areas.csv')
employment = pd.read_csv(root / 'employment.csv')
outcomes = pd.read_csv(root / 'outcomes.csv')

trade = trade.merge(crosswalk, on='code', how='inner', validate='many_to_one')
assert len(trade) == 4 * trade['period'].nunique()
assert trade.groupby(['period', 'industry']).size().eq(1).all()
assert areas.groupby(['area', 'period', 'vintage']).size().eq(1).all()

# Complete omitted area-industry cells with zero, then calculate national denominators
# separately by period and vintage from all supplied areas.
periods = sorted(areas['period'].unique())
area_ids = sorted(areas['area'].unique())
industries = sorted(crosswalk['industry'].unique())
assert len(industries) == 4
full = pd.MultiIndex.from_product([area_ids, periods, ['base', 'early'], industries],
                                  names=['area', 'period', 'vintage', 'industry']).to_frame(index=False)
employment_full = full.merge(employment, on=['area','period','vintage','industry'], how='left', validate='one_to_one')
employment_full['employment'] = employment_full['employment'].fillna(0.0)
assert (employment_full['employment'] >= 0).all()

national = employment_full.groupby(['period','vintage','industry'], as_index=False)['employment'].sum().rename(columns={'employment':'national_employment'})
base_areas = areas.loc[areas.vintage.eq('base')].copy()
early_areas = areas.loc[areas.vintage.eq('early')].copy()
assert len(base_areas) == len(areas) // 2

joined = employment_full.merge(national, on=['period','vintage','industry'], validate='many_to_one')
joined = joined.merge(trade, on=['period','industry'], validate='many_to_one')
joined = joined.merge(areas[['area','period','vintage','total_employment']], on=['area','period','vintage'], validate='many_to_one')
joined['trade_change'] = np.where(joined.vintage.eq('base'), joined.us_change, joined.other_change)
joined['exposure_part'] = (joined.employment / joined.total_employment) * (joined.trade_change / joined.national_employment) / (joined.price_index / 100.0) / 1000.0 * (10.0 / joined.years)
exposures = joined.groupby(['area','period','vintage'], as_index=False)['exposure_part'].sum().rename(columns={'exposure_part':'exposure'})
exposures = exposures.pivot(index=['area','period'], columns='vintage', values='exposure').reset_index().rename(columns={'base':'x','early':'z'})

sample = outcomes.merge(exposures, on=['area','period'], how='inner', validate='one_to_one')
sample = sample.merge(base_areas[['area','period','population']], on=['area','period'], how='inner', validate='one_to_one')
assert len(sample) == 72
assert sample[['change_pp','control','x','z','population']].notna().all().all()

period_dummies = pd.get_dummies(sample['period'], prefix='period', drop_first=True, dtype=float)
exog = pd.concat([pd.Series(1.0, index=sample.index, name='intercept'), period_dummies, sample['control']], axis=1).astype(float)
fit = IV2SLS(sample['change_pp'].astype(float), exog, sample[['x']].astype(float),
             sample[['z']].astype(float), weights=sample['population'].astype(float)).fit()

estimates = [
    {'term':'iv_slope','estimate':float(fit.params['x']),'se':None,'n_obs':72},
    {'term':'exposure_area0_period0','estimate':float(sample.loc[(sample.area==0)&(sample.period==0),'x'].iloc[0]),'se':None,'n_obs':72},
    {'term':'exposure_area0_period1','estimate':float(sample.loc[(sample.area==0)&(sample.period==1),'x'].iloc[0]),'se':None,'n_obs':72},
    {'term':'instrument_area0_period0','estimate':float(sample.loc[(sample.area==0)&(sample.period==0),'z'].iloc[0]),'se':None,'n_obs':72},
]
result = {
    'task_id':'applied_multivintage_trade_iv',
    'platform':'python',
    'estimates':estimates,
    'method_metadata':{'estimator':'weighted 2SLS','dependent_variable':'change_pp','endogenous_regressor':'x','excluded_instrument':'z','exogenous_regressors':['intercept','period','control'],'exogenous_instruments':['intercept','period','control'],'weight':'base-vintage population','n_obs':72},
    'diagnostics':{'n_obs':int(len(sample)),'n_areas':int(sample.area.nunique()),'n_periods':int(sample.period.nunique()),'n_industries':int(len(industries))}
}
with (root / 'result.json').open('w') as f:
    json.dump(result, f, indent=2, allow_nan=False)

# Independent numerical check: IV coefficient from weighted Frisch-Waugh-Lovell
# residualization and the single-instrument weighted moment ratio.
w = sample.population.to_numpy(float)
rootw = np.sqrt(w)
X0 = exog.to_numpy(float)
# Weighted projection on all exogenous columns, then residualize x, z, and y.
A = X0 * rootw[:, None]
Q, _ = np.linalg.qr(A, mode='reduced')
def residual(v):
    vw = np.asarray(v, float) * rootw
    return vw - Q @ (Q.T @ vw)
rx, rz, ry = (residual(sample[c].to_numpy(float)) for c in ['x','z','change_pp'])
independent_beta = float((rz @ ry) / (rz @ rx))
assert np.isclose(independent_beta, float(fit.params['x']), rtol=1e-10, atol=1e-10)
# Every period-industry national denominator equals direct aggregation over the full area grid.
direct_nat = employment_full.groupby(['period','vintage','industry'])['employment'].sum()
assert np.allclose(direct_nat.to_numpy(), national.set_index(['period','vintage','industry']).loc[direct_nat.index,'national_employment'].to_numpy())
print(json.dumps({'iv_slope':float(fit.params['x']), 'independent_iv_slope':independent_beta, 'n_obs':len(sample), 'estimates':estimates}, indent=2))
