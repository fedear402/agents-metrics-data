import json
import numpy as np
import pandas as pd

DATA = pd.read_csv('input.csv')
sample = DATA.loc[DATA['score'].abs() < 1].copy()
sample['weight'] = 1.0 - sample['score'].abs()
sample['right'] = (sample['score'] >= 0).astype(float)
sample['running_left'] = sample['score'] * (1.0 - sample['right'])
sample['running_right'] = sample['score'] * sample['right']
X = np.column_stack([
    np.ones(len(sample)), sample['right'].to_numpy(),
    sample['running_left'].to_numpy(), sample['running_right'].to_numpy()
])
w = sample['weight'].to_numpy()
W = np.diag(w)
bread = np.linalg.inv(X.T @ W @ X)
contrast = np.array([0., 1., 0., 0.])

outcomes = sample[['earnings', 'participated']].to_numpy(dtype=float)
beta = bread @ X.T @ W @ outcomes
resid = outcomes - X @ beta
jumps = contrast @ beta
# HC0 sandwich, with fixed weighted least squares weights.
loading = w * (X @ bread @ contrast)
influences = loading[:, None] * resid
joint_cov = influences.T @ influences
rf, fs = jumps
ratio = rf / fs
gradient = np.array([1.0 / fs, -rf / fs**2])
ratio_se = float(np.sqrt(gradient @ joint_cov @ gradient))
n = int(len(sample))
rows = [
    {'term': 'treatment_effect', 'estimate': float(ratio), 'se': ratio_se, 'n_obs': n},
    {'term': 'reduced_form', 'estimate': float(rf), 'se': float(np.sqrt(joint_cov[0, 0])), 'n_obs': n},
    {'term': 'first_stage', 'estimate': float(fs), 'se': float(np.sqrt(joint_cov[1, 1])), 'n_obs': n},
]
result = {
    'task_id': 'applied_fuzzy_rd',
    'platform': 'python',
    'estimates': rows,
    'method_metadata': {
        'estimator': 'weighted local-linear fuzzy regression discontinuity; triangular weights; separate intercepts and slopes',
        'vcov': 'HC0 sandwich; fixed bandwidth and weights; joint covariance with delta method'
    },
    'diagnostics': {}
}
with open('result.json', 'w') as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
