import json
import numpy as np
import pandas as pd


def shock_iv(dependent, endogenous, instrument, mass):
    """Weighted just-identified IV with intercept and HC1 sandwich SE."""
    n = len(mass)
    regressors = np.column_stack((np.ones(n), endogenous))
    instruments = np.column_stack((np.ones(n), instrument))
    cross = instruments.T @ (mass[:, None] * regressors)
    beta = np.linalg.solve(cross, instruments.T @ (mass * dependent))
    residual = dependent - regressors @ beta
    scores = instruments * (mass * residual)[:, None]
    inv_cross = np.linalg.inv(cross)
    covariance = (n / (n - 2)) * inv_cross @ (scores.T @ scores) @ inv_cross.T
    return float(beta[1]), float(np.sqrt(covariance[1, 1])), residual


df = pd.read_csv('input.csv')
required = {'region_id', 'industry_id', 'share', 'shock', 'region_weight', 'x', 'y'}
if set(df.columns) != required:
    raise ValueError(f'Unexpected columns: {list(df.columns)}')
# One record per region-industry pair and region-level fields repeated within region.
if df.duplicated(['region_id', 'industry_id']).any():
    raise ValueError('Duplicate region-industry pairs found')
for col in ['region_weight', 'x', 'y']:
    if (df.groupby('region_id')[col].nunique() != 1).any():
        raise ValueError(f'{col} varies within region')
if (df.groupby('industry_id')['shock'].nunique() != 1).any():
    raise ValueError('shock varies within industry')

regions = df[['region_id', 'region_weight', 'x', 'y']].drop_duplicates('region_id').copy()
regions = regions.sort_values('region_id').reset_index(drop=True)
e = regions.region_weight.to_numpy(dtype=float, copy=True)
e /= e.sum()
industry_ids = np.sort(df.industry_id.unique())
N = len(industry_ids)

# Aggregate baseline shares and constant industry shocks to region level.
shares = df.pivot(index='region_id', columns='industry_id', values='share').reindex(
    index=regions.region_id, columns=industry_ids, fill_value=0.0
).fillna(0.0).to_numpy(float)
shock_by_industry = df.drop_duplicates('industry_id').set_index('industry_id')['shock'].reindex(industry_ids).to_numpy(float)
if not np.allclose(shares.sum(axis=1), 1.0, rtol=1e-8, atol=1e-10):
    raise ValueError('Baseline shares do not sum to one within each region')
z = shares @ shock_by_industry
x = regions.x.to_numpy(float)
y = regions.y.to_numpy(float)

# Regional weighted IV and first-stage slopes.
def weighted_slope(a, b, weights):
    a0 = a - np.dot(weights, a)
    b0 = b - np.dot(weights, b)
    return float(np.dot(weights, a0 * b0) / np.dot(weights, b0 * b0))

regional_effect = weighted_slope(y, z, e) / weighted_slope(x, z, e)
regional_first_stage = weighted_slope(x, z, e)

# Center all regional variables before exposure aggregation.
y0 = y - np.dot(e, y)
x0 = x - np.dot(e, x)
z0 = z - np.dot(e, z)
industry_shares = shares.T @ e
if np.any(industry_shares <= 0):
    raise ValueError('Every included industry must have positive exposure mass')

def aggregate(v0):
    return (shares.T @ (e * v0)) / industry_shares

ybar = aggregate(y0)
xbar = aggregate(x0)
zbar = aggregate(z0)
if not np.allclose(industry_shares @ ybar, 0.0, atol=1e-10):
    raise AssertionError('Weighted exposure aggregates do not preserve centering')

# Structural effect: ybar on xbar, instrument xbar with external shock.
effect, effect_se, _ = shock_iv(ybar, xbar, shock_by_industry, industry_shares)
# Relevance: xbar on zbar, instrument zbar with external shock.
first_stage, first_stage_se, _ = shock_iv(xbar, zbar, shock_by_industry, industry_shares)
effective_shocks = float(1.0 / np.sum(industry_shares ** 2))

# Independent checks: regional 2SLS and first-stage moment identities.
if not np.allclose([effect, first_stage], [regional_effect, regional_first_stage], rtol=1e-9, atol=1e-10):
    raise AssertionError('Shock-level slopes do not match regional weighted IV slopes')
# Verify estimated slopes also solve the corresponding weighted shock-level IV moments.
for dep, endog, slope in [(ybar, xbar, effect), (xbar, zbar, first_stage)]:
    resid = dep - (np.average(dep, weights=industry_shares) + slope * endog)
    moment = np.column_stack((np.ones(N), shock_by_industry)).T @ (industry_shares * resid)
    if not np.allclose(moment, 0.0, atol=1e-9):
        raise AssertionError('Shock-level IV moment condition failed')

output = {
    'task_id': 'applied_shift_share',
    'platform': 'python',
    'estimates': [
        {'term': 'effect', 'estimate': effect, 'se': effect_se, 'n_obs': int(N)},
        {'term': 'first_stage', 'estimate': first_stage, 'se': first_stage_se, 'n_obs': int(N)},
        {'term': 'effective_shocks', 'estimate': effective_shocks, 'se': None, 'n_obs': int(N)},
    ],
    'method_metadata': {'estimator': 'weighted regional 2SLS with BHJ shock-level aggregation',
                        'vcov': 'shock-level analytic-weight HC1, structural IV residuals'},
    'diagnostics': {},
}
with open('result.json', 'w') as stream:
    json.dump(output, stream, indent=2, allow_nan=False)

with open('verification.txt', 'w') as stream:
    stream.write(f'Regions used: {len(regions)}; industries used: {N}; region-industry rows: {len(df)}.\n')
    stream.write(f'All {len(regions)} regional share sums equal one within tolerance; fields are constant at required levels.\n')
    stream.write(f'Regional weights normalized once over regions; sum={e.sum():.16g}.\n')
    stream.write(f'Exposure masses positive; sum={industry_shares.sum():.16g}; effective_shocks={effective_shocks:.12g}.\n')
    stream.write(f'Independent slope check: shock-level effect={effect:.12g}, regional IV effect={regional_effect:.12g}.\n')
    stream.write(f'Independent relevance check: shock-level slope={first_stage:.12g}, regional first-stage={regional_first_stage:.12g}.\n')
    stream.write('Shock-level weighted IV moment conditions verified for both regressions. HC1 uses N/(N-2), analytic weights once in scores, and structural IV residuals.\n')
    stream.write(f'Final standard errors: effect={effect_se:.12g}; first_stage={first_stage_se:.12g}.\n')
