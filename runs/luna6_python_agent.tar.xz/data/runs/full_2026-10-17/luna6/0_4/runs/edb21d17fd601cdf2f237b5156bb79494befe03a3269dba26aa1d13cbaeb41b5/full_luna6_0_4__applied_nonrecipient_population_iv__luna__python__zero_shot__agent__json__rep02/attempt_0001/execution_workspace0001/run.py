import json
import numpy as np
import pandas as pd

h = pd.read_csv('households.csv')
c = pd.read_csv('census.csv')

# Retain every nonrecipient household, independent of village treatment status.
d = h.loc[h['recipient'].eq(0)].copy().reset_index(drop=True)
assert set(d['eligible'].unique()).issubset({0, 1})
assert len(d) > 0

e = d['eligible'].to_numpy(dtype=float)
z = d['instrument'].to_numpy(dtype=float)
dose = d['dose'].to_numpy(dtype=float)
b = d['baseline'].to_numpy(dtype=float)
y = d['outcome'].to_numpy(dtype=float)
w = d['weight'].to_numpy(dtype=float)
assert np.all(w > 0)

# Four group-specific included regressors; no additional intercept.
X = np.column_stack((1-e, e, b*(1-e), b*e))
D = np.column_stack((dose*(1-e), dose*e))
Q = np.column_stack((z*(1-e), z*e))
Z = np.column_stack((X, Q))

# Weighted 2SLS: (X'W Pz X)^-1 X'W Pz y, with Pz based on Z'WZ.
# Compute by weighted least squares projections to avoid forming the n by n matrix.
sqrt_w = np.sqrt(w)
Zw, Xw, yw = Z*sqrt_w[:, None], np.column_stack((X, D))*sqrt_w[:, None], y*sqrt_w
coef_z, *_ = np.linalg.lstsq(Zw, Xw, rcond=None)
Xhat_w = Zw @ coef_z
coef_y, *_ = np.linalg.lstsq(Zw, yw, rcond=None)
yhat_w = Zw @ coef_y
normal = Xhat_w.T @ Xhat_w
rhs = Xhat_w.T @ yw
beta = np.linalg.solve(normal, rhs)

# Coefficient order: intercept-like group indicators, group baselines, group dose slopes.
slope_ineligible, slope_eligible = beta[4], beta[5]
means = {}
effects = {}
for g, label in ((0, 'ineligible_effect'), (1, 'eligible_nonrecipient_effect')):
    mask = e == g
    means[g] = float(np.average(dose[mask], weights=w[mask]))
    effects[label] = float(beta[4+g] * means[g])

census = c.set_index('eligible')['nonrecipient_population']
assert set(census.index) == {0, 1}
population_effect = float(sum(effects[label] * float(census.loc[g]) for g, label in ((0, 'ineligible_effect'), (1, 'eligible_nonrecipient_effect'))) / float(census.sum()))

estimates = [
    {'term': 'ineligible_effect', 'estimate': effects['ineligible_effect'], 'se': None, 'n_obs': int(len(d))},
    {'term': 'eligible_nonrecipient_effect', 'estimate': effects['eligible_nonrecipient_effect'], 'se': None, 'n_obs': int(len(d))},
    {'term': 'population_effect', 'estimate': population_effect, 'se': None, 'n_obs': int(len(d))},
]

# Independent check: weighted 2SLS coefficients satisfy projected-regressor
# normal equations Xhat' (yw - Xw beta) = 0. Check group dose moments separately.
resid_w = yw - Xw @ beta
moment_error = Xhat_w.T @ resid_w
assert np.max(np.abs(moment_error)) < 1e-8
# Confirm the fitted 2SLS solution from explicit weighted projection matrices in
# instrument space, using a second linear-algebra identity (QR projection).
qmat, _ = np.linalg.qr(Zw, mode='reduced')
proj_X = qmat @ (qmat.T @ Xw)
proj_y = qmat @ (qmat.T @ yw)
beta_check = np.linalg.lstsq(proj_X, proj_y, rcond=None)[0]
assert np.allclose(beta, beta_check, rtol=1e-10, atol=1e-10)

metadata = {
    'estimator': 'weighted two-stage least squares',
    'sample': 'all household rows with recipient == 0, across both treated statuses',
    'endogenous_columns': ['dose*(1-eligible)', 'dose*eligible'],
    'exogenous_columns': ['1-eligible', 'eligible', 'baseline*(1-eligible)', 'baseline*eligible'],
    'instrument_columns': ['1-eligible', 'eligible', 'baseline*(1-eligible)', 'baseline*eligible', 'instrument*(1-eligible)', 'instrument*eligible'],
    'weight': 'weight',
    'counterfactual': 'dose set to zero for every retained household',
    'attribution_convention': 'group effect equals fitted group dose slope times household-weighted mean dose; attribution to zero-dose counterfactual is a stated synthetic convention',
    'aggregation_weights': 'nonrecipient_population from census.csv, used only for final between-group average',
}
diagnostics = {
    'n_obs': int(len(d)),
    'eligible_group_n_obs': {str(g): int(np.sum(e == g)) for g in (0, 1)},
    'retained_treated_status_counts': {str(k): int(v) for k, v in d['treated'].value_counts().sort_index().items()},
    'weighted_mean_dose': {str(g): means[g] for g in (0, 1)},
    'dose_slopes': {'ineligible': float(slope_ineligible), 'eligible': float(slope_eligible)},
    'census_nonrecipient_population': {str(g): int(census.loc[g]) for g in (0, 1)},
    'weighted_2sls_normal_equation_max_abs_error': float(np.max(np.abs(moment_error))),
    'independent_qr_projection_check_max_abs_difference': float(np.max(np.abs(beta-beta_check))),
}
with open('result.json', 'w') as f:
    json.dump({'task_id': 'applied_nonrecipient_population_iv', 'platform': 'python', 'estimates': estimates, 'method_metadata': metadata, 'diagnostics': diagnostics}, f, indent=2)
