import json
import numpy as np
import pandas as pd

h = pd.read_csv('households.csv')
c = pd.read_csv('census.csv')
d = h.loc[h['recipient'].eq(0)].copy()

eligible = d['eligible'].to_numpy(dtype=float)
ineligible = 1.0 - eligible
dose = d['dose'].to_numpy(dtype=float)
instrument = d['instrument'].to_numpy(dtype=float)
baseline = d['baseline'].to_numpy(dtype=float)
y = d['outcome'].to_numpy(dtype=float)
w = d['weight'].to_numpy(dtype=float)

# The instrument matrix contains the four exogenous columns and two
# eligibility-specific excluded instruments. No additional intercept is added.
X = np.column_stack([
    ineligible,
    eligible,
    baseline * ineligible,
    baseline * eligible,
    dose * ineligible,
    dose * eligible,
])
Z = np.column_stack([
    ineligible,
    eligible,
    baseline * ineligible,
    baseline * eligible,
    instrument * ineligible,
    instrument * eligible,
])

# Weighted 2SLS: (X'WZ (Z'WZ)^-1 Z'WX)^-1 X'WZ (Z'WZ)^-1 Z'Wy.
ZWZ = Z.T @ (w[:, None] * Z)
ZWX = Z.T @ (w[:, None] * X)
ZWy = Z.T @ (w * y)
coef = np.linalg.solve(ZWX.T @ np.linalg.solve(ZWZ, ZWX),
                       ZWX.T @ np.linalg.solve(ZWZ, ZWy))

# Independent equivalent calculation via weighted projection onto instrument space.
# Pz_w applies the projection in whitened coordinates, yielding the same 2SLS fit.
sqrt_w = np.sqrt(w)
Zw = sqrt_w[:, None] * Z
Xw = sqrt_w[:, None] * X
yw = sqrt_w * y
Q, _ = np.linalg.qr(Zw, mode='reduced')
coef_projection = np.linalg.lstsq(Q.T @ Xw, Q.T @ yw, rcond=None)[0]
if not np.allclose(coef, coef_projection, rtol=1e-10, atol=1e-10):
    raise ArithmeticError('Independent weighted projection check failed')

means = {}
for group, mask in [('ineligible', ineligible == 1), ('eligible', eligible == 1)]:
    means[group] = float(np.average(dose[mask], weights=w[mask]))

ineligible_effect = float(coef[4] * means['ineligible'])
eligible_effect = float(coef[5] * means['eligible'])
pop = c.set_index('eligible')['nonrecipient_population']
population_effect = float((ineligible_effect * int(pop.loc[0]) +
                           eligible_effect * int(pop.loc[1])) /
                          (int(pop.loc[0]) + int(pop.loc[1])))

n_obs = int(len(d))

# Additional identity check for the census-weighted aggregation.
weighted_identity = (0.84 * ineligible_effect) + (0.16 * eligible_effect)
if not np.isclose(population_effect, weighted_identity, rtol=0, atol=1e-14):
    raise ArithmeticError('Population aggregation identity check failed')

result = {
    'task_id': 'applied_nonrecipient_population_iv',
    'platform': 'python',
    'estimates': [
        {'term': 'ineligible_effect', 'estimate': ineligible_effect, 'se': None, 'n_obs': n_obs},
        {'term': 'eligible_nonrecipient_effect', 'estimate': eligible_effect, 'se': None, 'n_obs': n_obs},
        {'term': 'population_effect', 'estimate': population_effect, 'se': None, 'n_obs': n_obs},
    ],
    'method_metadata': {
        'estimator': 'weighted 2SLS',
        'estimation_sample': 'all household rows with recipient=0',
        'endogenous_columns': ['dose*(1-eligible)', 'dose*eligible'],
        'exogenous_columns': ['1-eligible', 'eligible', 'baseline*(1-eligible)', 'baseline*eligible'],
        'instruments': ['1-eligible', 'eligible', 'baseline*(1-eligible)', 'baseline*eligible', 'instrument*(1-eligible)', 'instrument*eligible'],
        'weight': 'weight',
        'within_group_dose_mean': 'household-weighted mean dose among retained observations',
        'counterfactual': 'dose set to zero for every retained household; attribution is a stated synthetic convention',
        'population_weights': 'nonrecipient_population from census.csv; used only for final between-group aggregation',
        'no_additional_intercept': True,
    },
    'diagnostics': {
        'household_rows_total': int(len(h)),
        'recipient_zero_rows': n_obs,
        'retained_ineligible_rows': int(np.sum(ineligible == 1)),
        'retained_eligible_rows': int(np.sum(eligible == 1)),
        'weighted_mean_dose_ineligible': means['ineligible'],
        'weighted_mean_dose_eligible': means['eligible'],
        'ineligible_dose_slope': float(coef[4]),
        'eligible_dose_slope': float(coef[5]),
        'census_nonrecipient_population_ineligible': int(pop.loc[0]),
        'census_nonrecipient_population_eligible': int(pop.loc[1]),
        'independent_weighted_projection_check_max_abs_coefficient_difference': float(np.max(np.abs(coef - coef_projection))),
    },
}
with open('result.json', 'w') as f:
    json.dump(result, f, indent=2, allow_nan=False)
