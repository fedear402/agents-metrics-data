import json
import pandas as pd
from scipy import stats

# Read the supplied outcome and grouping variable without altering either.
data = pd.read_csv("input.csv")
if not {"group", "y"}.issubset(data.columns):
    raise ValueError("input.csv must contain columns 'group' and 'y'")
work = data[["group", "y"]].dropna()
groups = [part["y"].to_numpy() for _, part in work.groupby("group", sort=True)]
if len(groups) < 2 or any(len(g) == 0 for g in groups):
    raise ValueError("One-way ANOVA requires at least two nonempty groups")

f_stat, p_value = stats.f_oneway(*groups)
n_obs = int(len(work))
df_num = int(len(groups) - 1)
df_den = int(n_obs - len(groups))

out = {
    "task_id": "anova_oneway",
    "platform": "python",
    "estimates": [
        {"term": "F", "estimate": float(f_stat), "se": None, "n_obs": n_obs},
        {"term": "df_num", "estimate": float(df_num), "se": None, "n_obs": n_obs},
        {"term": "df_den", "estimate": float(df_den), "se": None, "n_obs": n_obs},
        {"term": "p_value", "estimate": float(p_value), "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {"estimator": "One-way ANOVA", "vcov": "classical pooled within-group variance"},
    "diagnostics": {},
}
with open("result.json", "w") as f:
    json.dump(out, f, indent=2)
