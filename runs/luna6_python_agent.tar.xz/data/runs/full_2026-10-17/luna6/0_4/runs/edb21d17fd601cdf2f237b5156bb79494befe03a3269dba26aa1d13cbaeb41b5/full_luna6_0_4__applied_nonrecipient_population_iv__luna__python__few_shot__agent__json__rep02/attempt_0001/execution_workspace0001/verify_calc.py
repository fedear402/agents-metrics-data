import json
import numpy as np
import pandas as pd
h=pd.read_csv('households.csv'); c=pd.read_csv('census.csv'); s=h[h.recipient.eq(0)].copy()
e=s.eligible.to_numpy(float); d=s.dose.to_numpy(float); z=s.instrument.to_numpy(float); b=s.baseline.to_numpy(float); y=s.outcome.to_numpy(float); w=s.weight.to_numpy(float)
X=np.column_stack([1-e,e,b*(1-e),b*e,d*(1-e),d*e])
Z=np.column_stack([1-e,e,b*(1-e),b*e,z*(1-e),z*e])
root=np.sqrt(w)
Xw=X*root[:,None]; Zw=Z*root[:,None]; yw=y*root
# Independent 2SLS formula: beta=(X'P_Z X)^-1 X'P_Z y, using weighted matrices.
Q,_=np.linalg.qr(Zw, mode='reduced')
beta=np.linalg.solve(Xw.T@Q@Q.T@Xw, Xw.T@Q@Q.T@yw)
mean0=np.average(s.loc[s.eligible.eq(0),'dose'],weights=s.loc[s.eligible.eq(0),'weight'])
mean1=np.average(s.loc[s.eligible.eq(1),'dose'],weights=s.loc[s.eligible.eq(1),'weight'])
effect0=beta[4]*mean0; effect1=beta[5]*mean1
pop=np.average([effect0,effect1],weights=c.sort_values('eligible').nonrecipient_population.to_numpy())
res=json.load(open('result.json')); est={x['term']:x['estimate'] for x in res['estimates']}
assert len(s)==300
assert np.linalg.matrix_rank(Z)==6
assert np.allclose(beta[4],res['diagnostics']['group_slopes']['ineligible'],rtol=1e-11,atol=1e-11)
assert np.allclose(beta[5],res['diagnostics']['group_slopes']['eligible'],rtol=1e-11,atol=1e-11)
assert np.allclose(effect0,est['ineligible_effect'],rtol=1e-11,atol=1e-11)
assert np.allclose(effect1,est['eligible_nonrecipient_effect'],rtol=1e-11,atol=1e-11)
assert np.allclose(pop,est['population_effect'],rtol=1e-11,atol=1e-11)
print('Independent weighted matrix 2SLS slopes:',repr(beta[4]),repr(beta[5]))
print('Independent group effects:',repr(effect0),repr(effect1))
print('Independent census-weighted effect:',repr(pop))
print('Sample:',len(s),'rows; eligibility counts:',s.groupby('eligible').size().to_dict())
print('Instrument/exogenous matrix rank:',np.linalg.matrix_rank(Z),'of',Z.shape[1])
