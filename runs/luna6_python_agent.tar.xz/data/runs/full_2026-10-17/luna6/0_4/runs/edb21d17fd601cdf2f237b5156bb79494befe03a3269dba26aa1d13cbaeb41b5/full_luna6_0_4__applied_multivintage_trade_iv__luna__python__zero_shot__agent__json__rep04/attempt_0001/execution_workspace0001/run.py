import json
import pandas as pd
import numpy as np

crosswalk = pd.read_csv('crosswalk.csv')
trade = pd.read_csv('trade.csv')
areas = pd.read_csv('areas.csv')
employment = pd.read_csv('employment.csv')
outcomes = pd.read_csv('outcomes.csv')

# Map each trade code to one industry and aggregate national employment
# over every supplied area for each period, vintage, and industry.
trade = trade.merge(crosswalk, on='code', how='left', validate='many_to_one')
assert trade['industry'].notna().all()
assert crosswalk['industry'].nunique() == 4
assert trade.groupby(['period', 'industry']).size().eq(1).all()

# Merge the area data and area-industry employment for numerator shares.
base_area = areas[areas.vintage.eq('base')].copy()
early_area = areas[areas.vintage.eq('early')].copy()
area_base_emp = employment[employment.vintage.eq('base')][['area', 'period', 'industry', 'employment']]
area_early_emp = employment[employment.vintage.eq('early')][['area', 'period', 'industry', 'employment']]
# Full area x industry grid, so omitted cells explicitly contribute zero.
industries = sorted(crosswalk.industry.unique())
keys = base_area[['area', 'period', 'total_employment', 'population']].merge(pd.DataFrame({'industry': industries}), how='cross')
grid = keys.merge(area_base_emp, on=['area', 'period', 'industry'], how='left').rename(columns={'employment':'base_area_emp'})
grid = grid.merge(area_early_emp, on=['area', 'period', 'industry'], how='left').rename(columns={'employment':'early_area_emp'})
grid[['base_area_emp','early_area_emp']] = grid[['base_area_emp','early_area_emp']].fillna(0)

# Construct national industry denominators from all areas by period and vintage.
# Complete missing cells before summing, which is equivalent to zero-filling.
nat = employment.groupby(['period','vintage','industry']).employment.sum().unstack('vintage', fill_value=0).reset_index()
assert (nat[['base','early']] > 0).all().all()
terms = grid.merge(nat, on=['period','industry'], validate='many_to_one')
terms = terms.merge(trade, on=['period','industry'], validate='many_to_one', suffixes=('', '_trade'))
# Trade table attaches by mapped industry, one row per period-industry.
terms['x_component'] = (terms.base_area_emp / terms.total_employment) * terms.us_change / terms.base / (terms.price_index / 100) / 1000 * (10 / terms.years)
terms['z_component'] = (terms.early_area_emp / terms.total_employment) * terms.other_change / terms.early / (terms.price_index / 100) / 1000 * (10 / terms.years)
exposure = terms.groupby(['area','period'], as_index=False).agg(x=('x_component','sum'), z=('z_component','sum'))

sample = outcomes.merge(exposure, on=['area','period'], validate='one_to_one').merge(base_area[['area','period','population']], on=['area','period'], validate='one_to_one')
assert len(sample) == 72
assert sample[['x','z','control','change_pp','population']].notna().all().all()

# Weighted 2SLS: regressors [intercept, period, control, x],
# instruments [intercept, period, control, z], weights=base population.
Y = sample.change_pp.to_numpy(float)
X = np.column_stack([np.ones(len(sample)), sample.period.to_numpy(float), sample.control.to_numpy(float), sample.x.to_numpy(float)])
Q = np.column_stack([np.ones(len(sample)), sample.period.to_numpy(float), sample.control.to_numpy(float), sample.z.to_numpy(float)])
w = sample.population.to_numpy(float)
rootw = np.sqrt(w)
Xw, Qw, Yw = X * rootw[:,None], Q * rootw[:,None], Y * rootw
# Stable weighted 2SLS via weighted projection of X on instruments.
PqX = Qw @ np.linalg.solve(Qw.T @ Qw, Qw.T @ Xw)
beta = np.linalg.solve(PqX.T @ PqX, PqX.T @ Yw)

result = {
    'task_id': 'applied_multivintage_trade_iv',
    'platform': 'python',
    'estimates': [
        {'term':'iv_slope', 'estimate':float(beta[3]), 'se':None, 'n_obs':72},
        {'term':'exposure_area0_period0', 'estimate':float(exposure.query('area == 0 and period == 0').x.iloc[0]), 'se':None, 'n_obs':72},
        {'term':'exposure_area0_period1', 'estimate':float(exposure.query('area == 0 and period == 1').x.iloc[0]), 'se':None, 'n_obs':72},
        {'term':'instrument_area0_period0', 'estimate':float(exposure.query('area == 0 and period == 0').z.iloc[0]), 'se':None, 'n_obs':72},
    ],
    'method_metadata': {
        'estimator':'population-weighted 2SLS',
        'outcome':'change_pp',
        'regressors':['intercept','period','control','x'],
        'instruments':['intercept','period','control','z'],
        'weight':'base-vintage population',
        'industries':4,
        'n_obs':72,
    },
    'diagnostics': {
        'n_area_period_rows':int(len(sample)),
        'periods':sorted(sample.period.unique().tolist()),
        'areas_per_period':sample.groupby('period').area.nunique().to_dict(),
        'national_employment_denominators_positive':True,
        'all_exposure_values_finite':bool(np.isfinite(exposure[['x','z']].to_numpy()).all()),
    },
}
with open('result.json','w') as f:
    json.dump(result, f, indent=2, allow_nan=False)

# Keep the principal objects available for reproducible verification.
