import json
import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS

crosswalk = pd.read_csv('crosswalk.csv')
trade = pd.read_csv('trade.csv').merge(crosswalk, on='code', how='inner', validate='many_to_one')
areas = pd.read_csv('areas.csv')
employment = pd.read_csv('employment.csv')
outcomes = pd.read_csv('outcomes.csv')

# Validate the task's one-row-per-period-industry trade structure.
assert not trade.duplicated(['period', 'industry']).any()
assert areas.query("vintage == 'base'").groupby(['area','period']).size().eq(1).all()
assert areas.query("vintage == 'early'").groupby(['area','period']).size().eq(1).all()

periods = sorted(trade.period.unique())
exposures = []
for period in periods:
    tr = trade[trade.period == period].set_index('industry')
    for vintage, change_col, out_col in [('base','us_change','x'), ('early','other_change','z')]:
        emp = employment[(employment.period == period) & (employment.vintage == vintage)]
        totals = areas[(areas.period == period) & (areas.vintage == vintage)].set_index('area').total_employment
        # Build a complete area x industry grid; omitted cells are zero.
        grid = emp.pivot(index='area', columns='industry', values='employment').reindex(
            index=totals.index, columns=sorted(crosswalk.industry.unique()), fill_value=0
        ).fillna(0)
        nat = grid.sum(axis=0)
        assert (nat > 0).all()
        change = tr[change_col].reindex(grid.columns)
        price = float(tr.price_index.iloc[0])
        years = float(tr.years.iloc[0])
        shock = change / nat / (price / 100) / 1000 * (10 / years)
        value = grid.mul(shock, axis=1).sum(axis=1) / totals
        exposures.append(value.rename(out_col).rename_axis('area').reset_index().assign(period=period))
x = pd.concat([d for d in exposures if 'x' in d], ignore_index=True)
z = pd.concat([d for d in exposures if 'z' in d], ignore_index=True)
reg = outcomes.merge(x, on=['area','period'], validate='one_to_one').merge(z, on=['area','period'], validate='one_to_one')
base_pop = areas[areas.vintage == 'base'][['area','period','population']]
reg = reg.merge(base_pop, on=['area','period'], validate='one_to_one').sort_values(['period','area']).reset_index(drop=True)
assert len(reg) == 72

period_indicator = (reg.period == periods[1]).astype(float)
exog = pd.DataFrame({'intercept':1.0, 'period':period_indicator, 'control':reg.control})
fit = IV2SLS(reg.change_pp, exog, reg[['x']], reg[['z']], weights=reg.population).fit()

result = {
    'task_id': 'applied_multivintage_trade_iv',
    'platform': 'python',
    'estimates': [
        {'term':'iv_slope','estimate':float(fit.params['x']),'se':None,'n_obs':72},
        {'term':'exposure_area0_period0','estimate':float(reg.query('area == 0 and period == 0').x.iloc[0]),'se':None,'n_obs':72},
        {'term':'exposure_area0_period1','estimate':float(reg.query('area == 0 and period == 1').x.iloc[0]),'se':None,'n_obs':72},
        {'term':'instrument_area0_period0','estimate':float(reg.query('area == 0 and period == 0').z.iloc[0]),'se':None,'n_obs':72},
    ],
    'method_metadata': {'estimator':'weighted 2SLS','dependent_variable':'change_pp','endogenous_regressor':'x','excluded_instrument':'z','exogenous_regressors':['intercept','period','control'],'instruments':['z','intercept','period','control'],'weight':'base-vintage population'},
    'diagnostics': {'n_obs':72,'sample_rows':int(len(reg))}
}
with open('result.json','w') as f:
    json.dump(result, f, indent=2)

print(json.dumps(result, indent=2))

# Independent numerical verification: direct matrix 2SLS with WLS whitening.
Y = reg.change_pp.to_numpy(float)
X = np.column_stack([exog.to_numpy(float), reg.x.to_numpy(float)])
Q = np.column_stack([exog.to_numpy(float), reg.z.to_numpy(float)])
wroot = np.sqrt(reg.population.to_numpy(float))
Xw, Qw, Yw = X * wroot[:, None], Q * wroot[:, None], Y * wroot
Pq_x = Qw @ np.linalg.solve(Qw.T @ Qw, Qw.T @ Xw)
beta_manual = np.linalg.solve(Xw.T @ Pq_x, Xw.T @ (Qw @ np.linalg.solve(Qw.T @ Qw, Qw.T @ Yw)))
assert np.isclose(beta_manual[-1], fit.params['x'], rtol=1e-12, atol=1e-12)
# Identity check: every industry's national denominator equals the sum of all area cells.
for period in periods:
    for vintage in ('base','early'):
        cells = employment[(employment.period == period) & (employment.vintage == vintage)]
        complete = cells.pivot(index='area', columns='industry', values='employment').reindex(
            index=areas[(areas.period == period) & (areas.vintage == vintage)].area,
            columns=sorted(crosswalk.industry.unique()), fill_value=0).fillna(0)
        assert np.allclose(complete.sum(axis=0).to_numpy(), cells.groupby('industry').employment.sum().reindex(complete.columns, fill_value=0).to_numpy())

with open('verification.txt','w') as f:
    f.write('Verification checks\n')
    f.write(f'Estimation sample rows: {len(reg)}; expected 72: {len(reg) == 72}.\n')
    f.write(f'Unique area-period rows: {reg.groupby(["area", "period"]).ngroups}; duplicate check passed.\n')
    f.write('Employment construction: zero-filled four-industry grids; national totals checked against sums of supplied cells for all periods and vintages.\n')
    f.write('Exposure calculation: area 0 period 0 x = %.12f; period 1 x = %.12f; period 0 z = %.12f.\n' % (reg.query('area == 0 and period == 0').x.iloc[0], reg.query('area == 0 and period == 1').x.iloc[0], reg.query('area == 0 and period == 0').z.iloc[0]))
    f.write(f'Estimator: linearmodels weighted 2SLS; exogenous regressors are automatically included in instruments.\n')
    f.write(f'Independent whitened-matrix 2SLS x coefficient: {beta_manual[-1]:.12f}; linearmodels: {fit.params["x"]:.12f}; agreement: {np.isclose(beta_manual[-1], fit.params["x"], rtol=1e-12, atol=1e-12)}.\n')
