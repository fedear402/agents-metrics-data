import json
import numpy as np
import pandas as pd
import statsmodels.api as sm


def main():
    df = pd.read_csv('input.csv', parse_dates=['date']).sort_values('date').reset_index(drop=True)
    if list(df.columns) != ['date', 'sales', 'vix']:
        raise ValueError('Unexpected input columns')
    df['dlog_vix'] = np.log(df['vix']).diff()
    lag_cols = []
    for j in range(1, 16):
        name = f'lag_{j}'
        df[name] = df['dlog_vix'].shift(j)
        lag_cols.append(name)
    sample = df.dropna(subset=['sales', *lag_cols]).copy()
    y = np.log(sample['sales'].to_numpy())
    X = sm.add_constant(sample[lag_cols].to_numpy(), has_constant='add')
    fit = sm.OLS(y, X).fit()
    n = len(y)

    # Bartlett HAC, with the task's specified finite-sample multiplier.
    resid = fit.resid
    score = X * resid[:, None]
    meat = score.T @ score
    for j in range(1, 16):
        weight = 1.0 - j / 16.0
        cross = score[j:].T @ score[:-j]
        meat += weight * (cross + cross.T)
    bread = np.linalg.inv(X.T @ X)
    cov = bread @ meat @ bread * (n / (n - 16))

    beta = fit.params
    cumulative = float(beta[1:].sum())
    cumulative_var = float(cov[1:, 1:].sum())
    result = {
        'task_id': 'applied_cumulative_hac',
        'platform': 'python',
        'estimates': [
            {'term': 'cumulative_response', 'estimate': cumulative, 'se': float(np.sqrt(max(cumulative_var, 0.0))), 'n_obs': int(n)},
            {'term': 'lag_1', 'estimate': float(beta[1]), 'se': float(np.sqrt(cov[1, 1])), 'n_obs': int(n)},
            {'term': 'lag_15', 'estimate': float(beta[15]), 'se': float(np.sqrt(cov[15, 15])), 'n_obs': int(n)},
        ],
        'method_metadata': {
            'estimator': 'OLS of log(sales) on intercept and lags 1-15 of first difference of log(vix)',
            'vcov': 'Newey-West HAC, Bartlett weights through lag 15, covariance multiplied by N/(N-16)',
        },
        'diagnostics': {'sample_start': str(sample['date'].iloc[0].date()), 'sample_end': str(sample['date'].iloc[-1].date())},
    }
    with open('result.json', 'w') as f:
        json.dump(result, f, indent=2, allow_nan=False)


if __name__ == '__main__':
    main()
