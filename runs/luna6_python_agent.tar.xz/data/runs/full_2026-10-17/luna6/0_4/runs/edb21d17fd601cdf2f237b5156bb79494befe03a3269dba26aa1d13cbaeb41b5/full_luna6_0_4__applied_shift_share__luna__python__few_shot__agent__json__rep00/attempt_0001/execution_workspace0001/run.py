import json
import numpy as np
import pandas as pd


def shock_iv(dependent, endogenous, instrument, weights):
    """Weighted IV with an intercept and HC1 sandwich using structural residuals."""
    n = len(weights)
    regressors = np.column_stack((np.ones(n), endogenous))
    instruments = np.column_stack((np.ones(n), instrument))
    cross = instruments.T @ (weights[:, None] * regressors)
    inv_cross = np.linalg.inv(cross)
    beta = inv_cross @ (instruments.T @ (weights * dependent))
    residual = dependent - regressors @ beta
    scores = instruments * (weights * residual)[:, None]
    covariance = (n / (n - 2)) * inv_cross @ (scores.T @ scores) @ inv_cross.T
    return float(beta[1]), float(np.sqrt(covariance[1, 1]))


def main():
    df = pd.read_csv('input.csv')
    # Check region-level variables and industry shocks are repeated consistently.
    for col in ('region_weight', 'x', 'y'):
        if (df.groupby('region_id')[col].nunique() != 1).any():
            raise ValueError(f'{col} varies within region')
    if (df.groupby('industry_id')['shock'].nunique() != 1).any():
        raise ValueError('shock varies within industry')

    regions = df.drop_duplicates('region_id').set_index('region_id')
    regions = regions[['region_weight', 'x', 'y']].copy()
    regions['e'] = regions.region_weight / regions.region_weight.sum()
    shares = df.pivot(index='region_id', columns='industry_id', values='share').fillna(0.0)
    shocks = df.drop_duplicates('industry_id').set_index('industry_id')['shock'].reindex(shares.columns)
    if shares.isna().any().any() or shocks.isna().any():
        raise ValueError('Missing share or shock in region-industry data')
    if not np.allclose(shares.sum(axis=1).to_numpy(), 1.0, rtol=1e-8, atol=1e-10):
        raise ValueError('Baseline shares do not sum to one within region')

    e = regions['e'].to_numpy()
    x = regions['x'].to_numpy()
    y = regions['y'].to_numpy()
    z = shares.to_numpy() @ shocks.to_numpy()
    # Center all regional variables with the normalized regional weights.
    x0 = x - e @ x
    y0 = y - e @ y
    z0 = z - e @ z
    share_array = shares.to_numpy()
    mass = e @ share_array

    def aggregate(v0):
        return (share_array.T @ (e * v0)) / mass

    xbar, ybar, zbar = aggregate(x0), aggregate(y0), aggregate(z0)
    shock_values = shocks.to_numpy()
    n_industries = len(shock_values)
    if n_industries <= 2:
        raise ValueError('HC1 convention requires more than two industries')

    effect, effect_se = shock_iv(ybar, xbar, shock_values, mass)
    first_stage, first_stage_se = shock_iv(xbar, zbar, shock_values, mass)

    # Independent identity checks: shock-level slopes must equal their regional weighted IV slopes.
    regional_effect = (e @ (z0 * y0)) / (e @ (z0 * x0))
    regional_first_stage = (e @ (z0 * x0)) / (e @ (z0 * z0))
    if not np.allclose([effect, first_stage], [regional_effect, regional_first_stage], rtol=1e-9, atol=1e-10):
        raise AssertionError('Shock-level and regional slopes do not agree')
    if not np.isclose(mass.sum(), 1.0, rtol=1e-10, atol=1e-10):
        raise AssertionError('Industry exposure masses do not sum to one')

    output = {
        'task_id': 'applied_shift_share',
        'platform': 'python',
        'estimates': [
            {'term': 'effect', 'estimate': effect, 'se': effect_se, 'n_obs': n_industries},
            {'term': 'first_stage', 'estimate': first_stage, 'se': first_stage_se, 'n_obs': n_industries},
            {'term': 'effective_shocks', 'estimate': float(1.0 / np.sum(mass ** 2)), 'se': None, 'n_obs': n_industries},
        ],
        'method_metadata': {
            'estimator': 'regional weighted 2SLS; BHJ shock-level weighted IV aggregation',
            'vcov': 'shock-level HC1 sandwich with structural IV residuals and analytic weights',
        },
        'diagnostics': {},
    }
    with open('result.json', 'w') as stream:
        json.dump(output, stream, indent=2, allow_nan=False)

    print(f'regions={len(regions)}, industries={n_industries}, rows={len(df)}')
    print(f'max share-sum error={np.max(np.abs(shares.sum(axis=1).to_numpy()-1)):.3g}')
    print(f'effect identity difference={effect-regional_effect:.3g}')
    print(f'first-stage identity difference={first_stage-regional_first_stage:.3g}')
    print(f'exposure mass sum={mass.sum():.15g}')
    print(json.dumps(output, indent=2))


if __name__ == '__main__':
    main()
