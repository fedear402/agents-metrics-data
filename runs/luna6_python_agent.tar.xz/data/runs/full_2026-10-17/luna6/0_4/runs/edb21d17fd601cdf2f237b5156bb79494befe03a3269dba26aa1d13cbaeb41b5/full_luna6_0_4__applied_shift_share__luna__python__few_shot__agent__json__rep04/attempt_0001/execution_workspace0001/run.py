import json
import numpy as np
import pandas as pd


def shock_iv(dependent, endogenous, instrument, mass):
    """Weighted just-identified IV with intercept and HC1 sandwich covariance."""
    n = len(mass)
    regressors = np.column_stack((np.ones(n), endogenous))
    instruments = np.column_stack((np.ones(n), instrument))
    cross = instruments.T @ (mass[:, None] * regressors)
    beta = np.linalg.solve(cross, instruments.T @ (mass * dependent))
    residual = dependent - regressors @ beta
    scores = instruments * (mass * residual)[:, None]
    inv_cross = np.linalg.inv(cross)
    covariance = (n / (n - 2)) * inv_cross @ (scores.T @ scores) @ inv_cross.T
    return float(beta[1]), float(np.sqrt(covariance[1, 1]))


df = pd.read_csv("input.csv")
required = {"region_id", "industry_id", "share", "shock", "region_weight", "x", "y"}
if set(df.columns) != required:
    raise ValueError(f"Unexpected columns: {list(df.columns)}")
if df[list(required)].isna().any().any():
    raise ValueError("Input has missing values")

# Verify region-level variables repeat, industry shock is constant, and shares sum to one.
region_cols = ["region_weight", "x", "y"]
if (df.groupby("region_id")[region_cols].nunique() > 1).any().any():
    raise ValueError("Regional variables vary within region")
if (df.groupby("industry_id")["shock"].nunique() > 1).any():
    raise ValueError("Shock varies within industry")
share_sums = df.groupby("region_id")["share"].sum().to_numpy()
if not np.allclose(share_sums, 1.0, atol=1e-8, rtol=1e-8):
    raise ValueError("Baseline shares do not sum to one within region")

regions = df.drop_duplicates("region_id").set_index("region_id").sort_index()
industries = np.sort(df["industry_id"].unique())
region_ids = regions.index.to_numpy()
weights = regions["region_weight"].to_numpy(dtype=float)
e = weights / weights.sum()

# Construct regional exposure from the full region-industry share matrix.
wide_share = df.pivot(index="region_id", columns="industry_id", values="share").reindex(
    index=region_ids, columns=industries
)
wide_shock = df.drop_duplicates("industry_id").set_index("industry_id")["shock"].reindex(industries).to_numpy(dtype=float)
shares = wide_share.to_numpy(dtype=float)
if not np.isfinite(shares).all():
    raise ValueError("Missing region-industry rows in share matrix")
z = shares @ wide_shock
x = regions["x"].to_numpy(dtype=float)
y = regions["y"].to_numpy(dtype=float)

# Weighted regional centering, followed by exposure-weighted shock-level aggregation.
regional = np.column_stack((y, x, z))
centered = regional - e @ regional
mass = e @ shares
if np.any(mass <= 0):
    raise ValueError("Every industry must have positive aggregate exposure")
aggregated = (shares.T @ (e[:, None] * centered)) / mass[:, None]
ybar, xbar, zbar = aggregated.T
n_industries = len(industries)

# Structural effect: xbar is endogenous, shock is the excluded instrument.
effect, effect_se = shock_iv(ybar, xbar, wide_shock, mass)
# Relevance: zbar is endogenous, shock is the excluded instrument.
first_stage, first_stage_se = shock_iv(xbar, zbar, wide_shock, mass)
effective_shocks = float(1.0 / np.sum(mass ** 2))

# Regional identities independently check the two slopes.
regional_effect = float(np.sum(e * centered[:, 2] * centered[:, 0]) /
                        np.sum(e * centered[:, 2] * centered[:, 1]))
regional_first_stage = float(np.sum(e * centered[:, 2] * centered[:, 1]) /
                              np.sum(e * centered[:, 2] ** 2))
if not np.allclose([effect, first_stage], [regional_effect, regional_first_stage], rtol=1e-9, atol=1e-10):
    raise AssertionError("Shock-level and regional slope identities failed")

output = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": effect, "se": effect_se, "n_obs": n_industries},
        {"term": "first_stage", "estimate": first_stage, "se": first_stage_se, "n_obs": n_industries},
        {"term": "effective_shocks", "estimate": effective_shocks, "se": None, "n_obs": n_industries},
    ],
    "method_metadata": {
        "estimator": "Weighted regional 2SLS with Borusyak-Hull-Jaravel shock-level aggregation",
        "vcov": "Shock-level HC1 sandwich with structural IV residuals and analytic weights; N/(N-2); no clustering",
    },
    "diagnostics": {},
}
with open("result.json", "w") as f:
    json.dump(output, f, indent=2, allow_nan=False)
