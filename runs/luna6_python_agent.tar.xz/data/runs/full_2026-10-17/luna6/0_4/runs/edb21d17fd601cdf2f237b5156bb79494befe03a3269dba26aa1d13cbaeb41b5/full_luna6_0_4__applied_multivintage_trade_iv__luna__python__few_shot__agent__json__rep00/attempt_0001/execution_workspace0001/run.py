import json
import numpy as np
import pandas as pd

crosswalk = pd.read_csv('crosswalk.csv')
trade = pd.read_csv('trade.csv')
areas = pd.read_csv('areas.csv')
employment = pd.read_csv('employment.csv')
outcomes = pd.read_csv('outcomes.csv')

# Map each nominal trade row to its industry and keep one row per period-industry.
trade = trade.merge(crosswalk[['code', 'industry']], on='code', how='left', validate='many_to_one')
assert trade['industry'].notna().all()
assert not trade.duplicated(['period', 'industry']).any()
assert areas.groupby(['area', 'period'])['vintage'].nunique().eq(2).all()

# Join industry employment to trade codes and aggregate nationally by period/vintage.
employment = employment.merge(crosswalk[['industry']].drop_duplicates(), on='industry', how='left', validate='many_to_one')
assert employment['industry'].notna().all()
national = employment.groupby(['period', 'vintage', 'industry'], as_index=False)['employment'].sum()
assert (national['employment'] > 0).all()

# Build complete area x industry rows. Missing employment cells have value zero.
base = areas.loc[areas.vintage.eq('base'), ['area', 'period', 'total_employment', 'population']].copy()
early = areas.loc[areas.vintage.eq('early'), ['area', 'period', 'total_employment']].copy()
industry_ids = crosswalk['industry'].unique()
area_vintages = areas[['area', 'period', 'vintage']].drop_duplicates()
area_industries = area_vintages.merge(pd.DataFrame({'industry': industry_ids}), how='cross')
area_industries = area_industries.merge(employment[['area','period','vintage','industry','employment']],
                                        on=['area','period','vintage','industry'], how='left', validate='one_to_one')
area_industries['employment'] = area_industries['employment'].fillna(0.0)

trade_by_industry = trade[['period','industry','us_change','other_change','price_index','years']]
area_industries = area_industries.merge(trade_by_industry, on=['period','industry'], how='left', validate='many_to_one')
area_industries = area_industries.merge(national.rename(columns={'employment':'national_employment'}),
                                        on=['period','vintage','industry'], how='left', validate='many_to_one')
assert area_industries[['us_change','other_change','price_index','years','national_employment']].notna().all().all()
assert (area_industries['national_employment'] > 0).all()
area_industries['x_part'] = (area_industries['employment'] / area_industries['national_employment']
                             * area_industries['us_change'] / (area_industries['price_index']/100)
                             / 1000 * (10/area_industries['years']))
area_industries['z_part'] = (area_industries['employment'] / area_industries['national_employment']
                             * area_industries['other_change'] / (area_industries['price_index']/100)
                             / 1000 * (10/area_industries['years']))
exposure = area_industries.groupby(['area','period','vintage'], as_index=False)[['x_part','z_part']].sum()
x = exposure.loc[exposure.vintage.eq('base'), ['area','period','x_part']].rename(columns={'x_part':'x'})
z = exposure.loc[exposure.vintage.eq('early'), ['area','period','z_part']].rename(columns={'z_part':'z'})

sample = (outcomes.merge(base[['area','period','population']], on=['area','period'], how='inner', validate='one_to_one')
          .merge(x, on=['area','period'], how='inner', validate='one_to_one')
          .merge(z, on=['area','period'], how='inner', validate='one_to_one'))
sample['period'] = sample['period'].astype(float)
assert len(sample) == 72
assert sample[['change_pp','control','population','x','z']].notna().all().all()

# Weighted 2SLS: regress each endogenous regressor on all exogenous variables and z,
# then use the weighted projection in the structural regression.
y = sample['change_pp'].to_numpy(float)
w = sample['population'].to_numpy(float)
X = np.column_stack([np.ones(len(sample)), sample['period'].to_numpy(float), sample['control'].to_numpy(float), sample['x'].to_numpy(float)])
Q = np.column_stack([np.ones(len(sample)), sample['period'].to_numpy(float), sample['control'].to_numpy(float), sample['z'].to_numpy(float)])
sqrtw = np.sqrt(w)
Qw, Xw, yw = Q * sqrtw[:, None], X * sqrtw[:, None], y * sqrtw
PqX = Qw @ np.linalg.solve(Qw.T @ Qw, Qw.T @ Xw)
Pqy = Qw @ np.linalg.solve(Qw.T @ Qw, Qw.T @ yw)
beta = np.linalg.solve(Xw.T @ PqX, Xw.T @ Pqy)

estimates = [
    {'term':'iv_slope', 'estimate':float(beta[3]), 'se':None, 'n_obs':72},
    {'term':'exposure_area0_period0', 'estimate':float(sample.loc[(sample.area == 0) & (sample.period == 0), 'x'].iloc[0]), 'se':None, 'n_obs':72},
    {'term':'exposure_area0_period1', 'estimate':float(sample.loc[(sample.area == 0) & (sample.period == 1), 'x'].iloc[0]), 'se':None, 'n_obs':72},
    {'term':'instrument_area0_period0', 'estimate':float(sample.loc[(sample.area == 0) & (sample.period == 0), 'z'].iloc[0]), 'se':None, 'n_obs':72},
]
result = {
    'task_id':'applied_multivintage_trade_iv',
    'platform':'python',
    'estimates':estimates,
    'method_metadata':{
        'estimator':'weighted 2SLS',
        'dependent_variable':'change_pp',
        'exogenous_regressors':['intercept','period','control'],
        'endogenous_regressor':'x',
        'excluded_instrument':'z',
        'included_instruments':['intercept','period','control','z'],
        'weight':'base-vintage population',
        'exposure_units':'thousands of real dollars per worker per decade'
    },
    'diagnostics':{'n_obs':72, 'n_areas':36, 'n_periods':2, 'n_industries':4}
}
with open('result.json','w') as f:
    json.dump(result, f, indent=2, allow_nan=False)
print(json.dumps(result, indent=2))
