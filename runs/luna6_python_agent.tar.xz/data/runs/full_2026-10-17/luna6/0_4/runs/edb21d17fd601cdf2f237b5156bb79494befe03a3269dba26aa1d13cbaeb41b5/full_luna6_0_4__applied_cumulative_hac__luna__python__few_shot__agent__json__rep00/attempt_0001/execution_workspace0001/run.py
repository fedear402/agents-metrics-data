import json
import numpy as np
import pandas as pd

# Read and sort observed trading rows before building the change and its lags.
df = pd.read_csv('input.csv', parse_dates=['date']).sort_values('date').reset_index(drop=True)
if list(pd.read_csv('input.csv', nrows=0).columns) != ['date', 'sales', 'vix']:
    raise ValueError('Unexpected CSV columns')
if df[['sales', 'vix']].isna().any().any() or (df[['sales', 'vix']] <= 0).any().any():
    raise ValueError('sales and vix must be observed and positive')
df['log_sales'] = np.log(df['sales'])
df['vix_change'] = np.log(df['vix']).diff()
for j in range(1, 16):
    df[f'lag_{j}'] = df['vix_change'].shift(j)
sample = df.dropna(subset=['log_sales'] + [f'lag_{j}' for j in range(1, 16)]).copy()
N = len(sample)
X = np.column_stack([np.ones(N)] + [sample[f'lag_{j}'].to_numpy() for j in range(1, 16)])
y = sample['log_sales'].to_numpy()
beta = np.linalg.lstsq(X, y, rcond=None)[0]
u = y - X @ beta
scores = X * u[:, None]
meat = scores.T @ scores
for j in range(1, 16):
    weight = 1 - j / 16
    cross = scores[j:].T @ scores[:-j]
    meat += weight * (cross + cross.T)
bread = np.linalg.inv(X.T @ X)
# Newey-West Bartlett HAC with the task-specified N/(N-16) finite-sample factor.
cov = (N / (N - 16)) * (bread @ meat @ bread)
contrast = np.r_[0.0, np.ones(15)]
rows = [
    {'term': 'cumulative_response', 'estimate': float(contrast @ beta), 'se': float(np.sqrt(contrast @ cov @ contrast)), 'n_obs': int(N)},
    {'term': 'lag_1', 'estimate': float(beta[1]), 'se': float(np.sqrt(cov[1, 1])), 'n_obs': int(N)},
    {'term': 'lag_15', 'estimate': float(beta[15]), 'se': float(np.sqrt(cov[15, 15])), 'n_obs': int(N)},
]
result = {
    'task_id': 'applied_cumulative_hac',
    'platform': 'python',
    'estimates': rows,
    'method_metadata': {'estimator': 'OLS on log(sales) and lags 1-15 of first differences of log(vix)', 'vcov': 'Newey-West HAC, Bartlett max lag 15, finite-sample factor N/(N-16)'},
    'diagnostics': {},
}
with open('result.json', 'w') as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
