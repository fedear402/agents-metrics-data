import json
import pandas as pd
from scipy import stats
import statsmodels.api as sm
import statsmodels.formula.api as smf

# Load only the supplied outcome and grouping variables.
data = pd.read_csv('./input.csv')
if list(data.columns) != ['group', 'y']:
    raise ValueError('Expected columns: group, y')
data = data[['group', 'y']].dropna()

# One-way fixed-effects ANOVA from the standard linear model.
fit = smf.ols('y ~ C(group)', data=data).fit()
table = sm.stats.anova_lm(fit, typ=2)
row = table.loc['C(group)']
resid = table.loc['Residual']
n = int(fit.nobs)
vals = [float(row['F']), float(row['df']), float(resid['df']), float(row['PR(>F)'])]
terms = ['F', 'df_num', 'df_den', 'p_value']
result = {
    'task_id': 'anova_oneway',
    'platform': 'python',
    'estimates': [
        {'term': term, 'estimate': val, 'se': None, 'n_obs': n}
        for term, val in zip(terms, vals)
    ],
    'method_metadata': {'estimator': 'One-way ANOVA via OLS with categorical group', 'vcov': 'Classical homoskedastic ANOVA'},
    'diagnostics': {}
}
with open('result.json', 'w', encoding='utf-8') as f:
    json.dump(result, f, indent=2, allow_nan=False)

# Independent check from between/within group sums of squares and F survival function.
groups = [g['y'].to_numpy() for _, g in data.groupby('group', sort=False)]
k = len(groups)
grand = data['y'].mean()
ss_between = sum(len(a) * (a.mean() - grand) ** 2 for a in groups)
ss_within = sum(((a - a.mean()) ** 2).sum() for a in groups)
df_num = k - 1
df_den = n - k
f_check = (ss_between / df_num) / (ss_within / df_den)
p_check = stats.f.sf(f_check, df_num, df_den)
print(f'n={n}, groups={k}, df_num={df_num}, df_den={df_den}')
print(f'ANOVA F={vals[0]:.12g}, p={vals[3]:.12g}')
print(f'SS identity check F={f_check:.12g}, p={p_check:.12g}')
if not (abs(vals[0] - f_check) < 1e-10 and abs(vals[3] - p_check) < 1e-12):
    raise ArithmeticError('Independent ANOVA check failed')
