import json
import numpy as np
import pandas as pd


def wls_iv_hc1(y, x, q, w):
    """IV with intercept, endogenous x, excluded instrument q, analytic weights."""
    y = np.asarray(y, dtype=float)
    x = np.asarray(x, dtype=float)
    q = np.asarray(q, dtype=float)
    w = np.asarray(w, dtype=float)
    D = np.column_stack((np.ones(len(y)), x))
    Q = np.column_stack((np.ones(len(y)), q))
    A = D.T @ (w[:, None] * Q)
    b = Q.T @ (w * y)
    beta = np.linalg.solve(A, b)
    u = y - D @ beta
    # HC1 sandwich for IV, using structural residuals and analytic weights.
    bread_l = np.linalg.inv(A)
    bread_r = np.linalg.inv(A.T)
    meat = Q.T @ ((w * u)[:, None] ** 2 * Q)
    n = len(y)
    cov = (n / (n - 2)) * bread_l @ meat @ bread_r
    return beta, np.sqrt(np.diag(cov))


df = pd.read_csv("input.csv")
required = ["region_id", "industry_id", "share", "shock", "region_weight", "x", "y"]
if list(df.columns) != required:
    raise ValueError(f"Unexpected columns: {list(df.columns)}")
# One record per region for normalization; region-level fields must be constant.
region = df.drop_duplicates("region_id").set_index("region_id").sort_index()
for col in ["region_weight", "x", "y"]:
    if (df.groupby("region_id")[col].nunique(dropna=False) > 1).any():
        raise ValueError(f"{col} varies within region")
e = region.region_weight.to_numpy(dtype=float)
e = e / e.sum()
region = region.copy()
region["e"] = e
# Each industry has a single shock value.
if (df.groupby("industry_id").shock.nunique(dropna=False) > 1).any():
    raise ValueError("shock varies within industry")
# Regional instrument from all region-industry pairs.
df = df.merge(region[["e"]], left_on="region_id", right_index=True, validate="many_to_one")
df["exposure_shock"] = df.share * df.shock
z = df.groupby("region_id").exposure_shock.sum().reindex(region.index).to_numpy()
# Weighted regional means and centered regional variables.
R = region[["x", "y", "e"]].copy()
R["z"] = z
for v in ["y", "x", "z"]:
    R[v + "0"] = R[v] - np.sum(R.e * R[v])
# Aggregate centered variables by industry, using s_n = sum_r e_r share_rn.
ag = df.assign(
    wy=df.e * df.share * df.region_id.map(R.y0),
    wx=df.e * df.share * df.region_id.map(R.x0),
    wz=df.e * df.share * df.region_id.map(R.z0),
).groupby("industry_id", sort=True).agg(
    s=("share", lambda a: 0.0), # replaced below from e-weighted share
    wy=("wy", "sum"), wx=("wx", "sum"), wz=("wz", "sum"),
)
# Calculate exposure mass directly and preserve all industries in the file.
s = df.assign(es=df.e * df.share).groupby("industry_id", sort=True).es.sum()
ag["s"] = s
if (ag.s <= 0).any():
    raise ValueError("Industry exposure weights must be positive")
for v in ["y", "x", "z"]:
    ag[v + "bar"] = ag["w" + v] / ag.s
shocks = df.groupby("industry_id", sort=True).shock.first()
N = len(ag)
if N <= 2:
    raise ValueError("HC1 convention requires more than two industries")
# Effect: shock-level IV, xbar instrumented by shock.
beta_effect, se_effect = wls_iv_hc1(ag.ybar, ag.xbar, shocks.reindex(ag.index), ag.s)
# First stage: shock-level IV, zbar instrumented by shock.
beta_fs, se_fs = wls_iv_hc1(ag.xbar, ag.zbar, shocks.reindex(ag.index), ag.s)
effective = 1.0 / np.sum(ag.s.to_numpy() ** 2)

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": float(beta_effect[1]), "se": float(se_effect[1]), "n_obs": int(N)},
        {"term": "first_stage", "estimate": float(beta_fs[1]), "se": float(se_fs[1]), "n_obs": int(N)},
        {"term": "effective_shocks", "estimate": float(effective), "se": None, "n_obs": int(N)},
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS with intercept; BHJ shock-level aggregation; analytic exposure weights",
        "vcov": "shock-level heteroskedastic-robust HC1, structural IV residuals, no clustering",
    },
    "diagnostics": {},
}
with open("result.json", "w") as f:
    json.dump(result, f, indent=2, allow_nan=False)

# Independent identity checks: regional 2SLS equals shock-level IV; similarly for first stage.
# Regional weighted 2SLS is the just-identified weighted covariance ratio after centering.
def regional_slope(a, b):
    return np.sum(R.e * R[a + "0"] * R[b + "0"]) / np.sum(R.e * R[a + "0"] * R["z0"])
regional_effect = np.sum(R.e * R["z0"] * R["y0"]) / np.sum(R.e * R["z0"] * R["x0"])
regional_fs = np.sum(R.e * R["z0"] * R["x0"]) / np.sum(R.e * R["z0"] ** 2)
# For the shock-level calculations, the IV slope is the weighted covariance ratio.
shock_effect = np.sum(ag.s * shocks.reindex(ag.index) * ag.ybar) / np.sum(ag.s * shocks.reindex(ag.index) * ag.xbar)
shock_fs = np.sum(ag.s * shocks.reindex(ag.index) * ag.xbar) / np.sum(ag.s * shocks.reindex(ag.index) * ag.zbar)
checks = {
    "regions": int(len(R)), "region_industry_rows": int(len(df)), "industries": int(N),
    "region_weight_sum_normalized": float(R.e.sum()),
    "max_share_sum_error": float((df.groupby("region_id").share.sum() - 1).abs().max()),
    "effect_regional_identity": float(regional_effect), "effect_shock_level": float(beta_effect[1]),
    "effect_identity_abs_diff": float(abs(regional_effect - beta_effect[1])),
    "first_stage_regional_identity": float(regional_fs), "first_stage_shock_level": float(beta_fs[1]),
    "first_stage_identity_abs_diff": float(abs(regional_fs - beta_fs[1])),
    "effect_covariance_ratio_check": float(shock_effect),
    "first_stage_covariance_ratio_check": float(shock_fs),
    "effective_shocks_check": float(1 / np.sum(ag.s.to_numpy() ** 2)),
}
with open("verification.txt", "w") as f:
    f.write("Verification checks\n")
    for k, v in checks.items():
        f.write(f"{k}: {v:.12g}\n" if isinstance(v, (float, np.floating)) else f"{k}: {v}\n")
    f.write("\nThe independent regional centered-2SLS covariance ratios match the shock-level IV slopes.\n")
    f.write("The shock-level slopes also match the weighted covariance-ratio identity for just-identified IV.\n")
