import json

import numpy as np
import pandas as pd


def main():
    data = pd.read_csv("input.csv", parse_dates=["date"])
    data = data.sort_values("date").reset_index(drop=True)
    data["vol_change"] = np.log(data["vix"]).diff()
    data["log_sales"] = np.log(data["sales"])
    lag_names = []
    for lag in range(1, 16):
        name = f"lag_{lag}"
        data[name] = data["vol_change"].shift(lag)
        lag_names.append(name)

    sample = data.dropna(subset=["log_sales", *lag_names]).copy()
    y = sample["log_sales"].to_numpy(dtype=float)
    x = np.column_stack([np.ones(len(sample)), sample[lag_names].to_numpy(dtype=float)])
    n, p = x.shape
    beta = np.linalg.lstsq(x, y, rcond=None)[0]
    residual = y - x @ beta

    # Bartlett Newey-West HAC meat, with chronological regression-sample scores.
    scores = x * residual[:, None]
    meat = scores.T @ scores
    for j in range(1, 16):
        weight = 1.0 - j / 16.0
        cross = scores[j:].T @ scores[:-j]
        meat += weight * (cross + cross.T)
    bread = np.linalg.inv(x.T @ x)
    covariance = (n / (n - 16)) * bread @ meat @ bread
    covariance = (covariance + covariance.T) / 2.0

    sum_contrast = np.r_[0.0, np.ones(15)]
    output = {
        "task_id": "applied_cumulative_hac",
        "platform": "python",
        "estimates": [
            {
                "term": "cumulative_response",
                "estimate": float(sum_contrast @ beta),
                "se": float(np.sqrt(sum_contrast @ covariance @ sum_contrast)),
                "n_obs": int(n),
            },
            {"term": "lag_1", "estimate": float(beta[1]), "se": float(np.sqrt(covariance[1, 1])), "n_obs": int(n)},
            {"term": "lag_15", "estimate": float(beta[15]), "se": float(np.sqrt(covariance[15, 15])), "n_obs": int(n)},
        ],
        "method_metadata": {
            "estimator": "OLS of log(sales) on intercept and 15 observed-row lags of first differences of log(vix)",
            "vcov": "Newey-West HAC, Bartlett maximum lag 15, finite-sample multiplier N/(N-16)",
        },
        "diagnostics": {},
    }
    with open("result.json", "w") as stream:
        json.dump(output, stream, indent=2, allow_nan=False)

    # Independent numerical checks: statsmodels HAC and linearity of OLS fitted values.
    import statsmodels.api as sm

    fitted = sm.OLS(y, x).fit()
    hac = fitted.get_robustcov_results(cov_type="HAC", maxlags=15, use_correction=False,
                                       kernel="bartlett")
    sm_cov = hac.cov_params() * (n / (n - p))
    np.testing.assert_allclose(beta, fitted.params, rtol=1e-10, atol=1e-12)
    np.testing.assert_allclose(covariance, sm_cov, rtol=1e-9, atol=1e-12)
    np.testing.assert_allclose(float(sum_contrast @ beta), float(beta[1:].sum()), rtol=1e-12)
    np.testing.assert_allclose(float(sum_contrast @ covariance @ sum_contrast),
                               float(np.ones(15) @ covariance[1:, 1:] @ np.ones(15)), rtol=1e-12)
    with open("verification.txt", "w") as stream:
        stream.write(f"Rows after date sort: {len(data)}\n")
        stream.write(f"First usable sorted row: {int(sample.index[0]) + 1}\n")
        stream.write(f"Regression sample N: {n}; coefficients p: {p}; N/(N-16): {n/(n-16):.12g}\n")
        stream.write("Construction: log(vix) first difference, then observed-row lags 1-15; log(sales) outcome.\n")
        stream.write("Independent check: statsmodels OLS coefficients and Bartlett HAC covariance agree within stated tolerances.\n")
        stream.write("Identity check: cumulative estimate equals sum of lag coefficients; variance equals 1' V_lags 1.\n")
        stream.write(f"Cumulative estimate: {output['estimates'][0]['estimate']:.12g}; SE: {output['estimates'][0]['se']:.12g}\n")


if __name__ == "__main__":
    main()
