import json
import numpy as np
import pandas as pd

crosswalk = pd.read_csv('crosswalk.csv')
trade = pd.read_csv('trade.csv')
areas = pd.read_csv('areas.csv')
employment = pd.read_csv('employment.csv')
outcomes = pd.read_csv('outcomes.csv')

assert crosswalk['industry'].nunique() == 4
assert crosswalk['code'].is_unique
assert not employment.duplicated(['area', 'period', 'vintage', 'industry']).any()
trade = trade.merge(crosswalk, on='code', how='left', validate='many_to_one')
assert trade['industry'].notna().all()
assert trade.groupby('period')['industry'].nunique().eq(4).all()
assert trade.groupby('period')['price_index'].nunique().eq(1).all()
assert trade.groupby('period')['years'].nunique().eq(1).all()

# Add zero employment rows for each supplied area-period-vintage and industry cell.
area_periods = areas[['area', 'period']].drop_duplicates()
area_periods = area_periods.merge(
    pd.DataFrame({'vintage': ['base', 'early']}), how='cross')
industry_cells = pd.DataFrame({'industry': sorted(crosswalk.industry.unique())})
all_cells = area_periods.merge(industry_cells, how='cross')
emp_full = all_cells.merge(
    employment, on=['area', 'period', 'vintage', 'industry'],
    how='left', validate='one_to_one')
emp_full['employment'] = emp_full['employment'].fillna(0)

# Sum employment over all supplied areas for each period, vintage, and industry.
national = emp_full.groupby(
    ['period', 'vintage', 'industry'], as_index=False)['employment'].sum()
assert (national['employment'] > 0).all()
trade_period = trade[['period', 'industry', 'us_change', 'other_change', 'price_index', 'years']]

def make_exposure(vintage, flow, term):
    local = emp_full.loc[emp_full.vintage.eq(vintage)].merge(
        areas.loc[areas.vintage.eq(vintage),
                  ['area', 'period', 'vintage', 'total_employment']],
        on=['area', 'period', 'vintage'], how='left', validate='many_to_one')
    local = local.merge(
        national.loc[national.vintage.eq(vintage)],
        on=['period', 'vintage', 'industry'], how='left', validate='many_to_one',
        suffixes=('_area', '_national'))
    local = local.merge(trade_period, on=['period', 'industry'], how='left', validate='many_to_one')
    local[term] = (
        (local.employment_area / local.total_employment)
        * (local[flow] / local.employment_national)
        / (local.price_index / 100) / 1000 * (10 / local.years)
    )
    return local.groupby(['area', 'period'], as_index=False)[term].sum()

x = make_exposure('base', 'us_change', 'x')
z = make_exposure('early', 'other_change', 'z')
sample = outcomes.merge(x, on=['area', 'period'], how='inner', validate='one_to_one')
sample = sample.merge(z, on=['area', 'period'], how='inner', validate='one_to_one')
sample = sample.merge(
    areas.loc[areas.vintage.eq('base'), ['area', 'period', 'population']],
    on=['area', 'period'], how='inner', validate='one_to_one')
assert len(sample) == 72
assert sample[['change_pp', 'control', 'x', 'z', 'population']].notna().all().all()

# Weighted 2SLS uses all exogenous regressors as instruments for themselves.
y = sample.change_pp.to_numpy(dtype=float)
w = sample.population.to_numpy(dtype=float)
X = np.column_stack([np.ones(len(sample)), sample.period, sample.control, sample.x])
Q = np.column_stack([np.ones(len(sample)), sample.period, sample.control, sample.z])
Qw = Q * np.sqrt(w)[:, None]
Xw = X * np.sqrt(w)[:, None]
yw = y * np.sqrt(w)
projection_coef = np.linalg.solve(Qw.T @ Qw, Qw.T @ Xw)
projected_Xw = Qw @ projection_coef
projected_yw = Qw @ np.linalg.solve(Qw.T @ Qw, Qw.T @ yw)
beta = np.linalg.solve(projected_Xw.T @ projected_Xw, projected_Xw.T @ projected_yw)

# Check the 2SLS coefficient using the weighted cross-product formula.
B = Q.T @ (w[:, None] * Q)
A = X.T @ (w[:, None] * Q)
rhs = X.T @ (w * y)
beta_crossproduct = np.linalg.solve(A @ np.linalg.solve(B, A.T), A @ np.linalg.solve(B, Q.T @ (w * y)))
assert np.allclose(beta, beta_crossproduct, rtol=1e-10, atol=1e-10)

x00 = x.loc[(x.area == 0) & (x.period == 0), 'x'].iloc[0]
x01 = x.loc[(x.area == 0) & (x.period == 1), 'x'].iloc[0]
z00 = z.loc[(z.area == 0) & (z.period == 0), 'z'].iloc[0]
estimates = [
    {'term': 'iv_slope', 'estimate': float(beta[3]), 'se': None, 'n_obs': 72},
    {'term': 'exposure_area0_period0', 'estimate': float(x00), 'se': None, 'n_obs': 72},
    {'term': 'exposure_area0_period1', 'estimate': float(x01), 'se': None, 'n_obs': 72},
    {'term': 'instrument_area0_period0', 'estimate': float(z00), 'se': None, 'n_obs': 72},
]
result = {
    'task_id': 'applied_multivintage_trade_iv',
    'platform': 'python',
    'estimates': estimates,
    'method_metadata': {
        'estimator': 'weighted two-stage least squares',
        'regressors': ['intercept', 'period', 'control', 'x'],
        'instruments': ['intercept', 'period', 'control', 'z'],
        'weight': 'base-vintage population',
        'exposure_units': 'thousands of real dollars per worker per decade',
        'outcome_units': 'decadal percentage-point change',
        'uncertainty': 'se set to null as requested',
    },
    'diagnostics': {'n_obs': 72, 'area_period_rows': int(len(sample)), 'industries': 4},
}
with open('result.json', 'w') as output_file:
    json.dump(result, output_file, indent=2)
