import json
import numpy as np
import pandas as pd

DATA = 'input.csv'
OUT = 'result.json'

# Local linear RD at zero, restricted to the open bandwidth and triangular weights.
df = pd.read_csv(DATA)
required = {'id', 'score', 'participated', 'earnings'}
if not required.issubset(df.columns):
    raise ValueError(f'Missing columns: {required - set(df.columns)}')
inside = df.loc[df['score'].abs() < 1].copy()
x = inside['score'].to_numpy(dtype=float)
d = (x >= 0).astype(float)
w = 1.0 - np.abs(x)
# Separate intercept and slope by side: columns are left intercept/slope, right intercept/slope.
X = np.column_stack(((1-d), (1-d)*x, d, d*x))
Y = inside[['earnings', 'participated']].to_numpy(dtype=float)

# WLS point estimates and joint HC0 sandwich covariance, using identical rows/weights.
xtwx = X.T @ (w[:, None] * X)
inv = np.linalg.inv(xtwx)
beta = inv @ (X.T @ (w[:, None] * Y))
resid = Y - X @ beta
bread = inv
# Per-observation score outer products preserve covariance across both outcomes.
meat_joint = np.zeros((X.shape[1]*Y.shape[1], X.shape[1]*Y.shape[1]))
# Parameter order is outcome-major: all earnings coefficients, then participation.
for i in range(len(inside)):
    score_i = np.concatenate([X[i] * (w[i] * resid[i, j]) for j in range(Y.shape[1])])
    meat_joint += np.outer(score_i, score_i)
B = np.kron(np.eye(Y.shape[1]), bread)
vcov_joint = B @ meat_joint @ B.T

# Discontinuity = right intercept minus left intercept, for earnings then participation.
contrast = np.array([-1., 0., 1., 0.])
rf = float(contrast @ beta[:, 0])
fs = float(contrast @ beta[:, 1])
# Gradient in outcome-major coefficient order, including the covariance between outcomes.
grad = np.concatenate([contrast / fs, -rf * contrast / (fs**2)])
ratio = rf / fs
var_rf = float(contrast @ vcov_joint[:4, :4] @ contrast)
var_fs = float(contrast @ vcov_joint[4:, 4:] @ contrast)
var_ratio = float(grad @ vcov_joint @ grad)

def se(v):
    return float(np.sqrt(max(0.0, v)))

n = int(len(inside))
result = {
    'task_id': 'applied_fuzzy_rd',
    'platform': 'python',
    'estimates': [
        {'term': 'treatment_effect', 'estimate': float(ratio), 'se': se(var_ratio), 'n_obs': n},
        {'term': 'reduced_form', 'estimate': rf, 'se': se(var_rf), 'n_obs': n},
        {'term': 'first_stage', 'estimate': fs, 'se': se(var_fs), 'n_obs': n},
    ],
    'method_metadata': {
        'estimator': 'Fuzzy RD local linear WLS; cutoff=0; bandwidth=1; triangular weights; separate slopes',
        'vcov': 'HC0 sandwich; joint outcome covariance; delta method for ratio; no df correction',
    },
    'diagnostics': {},
}
with open(OUT, 'w', encoding='utf-8') as f:
    json.dump(result, f, indent=2, allow_nan=False)
