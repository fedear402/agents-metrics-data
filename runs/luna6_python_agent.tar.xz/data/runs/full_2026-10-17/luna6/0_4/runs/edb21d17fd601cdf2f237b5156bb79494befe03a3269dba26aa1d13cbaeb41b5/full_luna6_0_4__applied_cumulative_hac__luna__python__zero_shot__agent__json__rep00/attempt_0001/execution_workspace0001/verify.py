import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
from statsmodels.stats.sandwich_covariance import cov_hac

df = pd.read_csv('input.csv', parse_dates=['date']).sort_values('date').reset_index(drop=True)
df['dx'] = np.log(df.vix).diff()
for j in range(1, 16):
    df[f'l{j}'] = df.dx.shift(j)
s = df.dropna(subset=[f'l{j}' for j in range(1, 16)])
X = sm.add_constant(s[[f'l{j}' for j in range(1, 16)]].to_numpy())
y = np.log(s.sales.to_numpy())
fit = sm.OLS(y, X).fit()
# Independent implementation: statsmodels HAC with Bartlett kernel and requested correction.
V = cov_hac(fit, nlags=15, use_correction=False) * len(y) / (len(y) - 16)
with open('result.json') as f:
    out = json.load(f)
nests = out['estimates']
assert len(s) == 704
assert np.allclose(fit.params[1:].sum(), nests[0]['estimate'], rtol=1e-12, atol=1e-12)
assert np.allclose(np.sqrt(np.ones(15) @ V[1:, 1:] @ np.ones(15)), nests[0]['se'], rtol=1e-12, atol=1e-12)
assert np.allclose(np.sqrt(V[1, 1]), nests[1]['se'], rtol=1e-12, atol=1e-12)
assert np.allclose(np.sqrt(V[15, 15]), nests[2]['se'], rtol=1e-12, atol=1e-12)
print('n_obs:', len(s))
print('sample dates:', s.date.iloc[0].date(), 'to', s.date.iloc[-1].date())
print('sum of coefficients:', fit.params[1:].sum())
print('cumulative SE from full covariance:', np.sqrt(np.ones(15) @ V[1:, 1:] @ np.ones(15)))
print('Independent statsmodels HAC check: all estimates and SEs match.')
