import json
import numpy as np
import pandas as pd


def weighted_iv(y, x, z, w):
    """IV with intercept; return slope and structural HC1 standard error."""
    y = np.asarray(y, dtype=float)
    x = np.asarray(x, dtype=float)
    z = np.asarray(z, dtype=float)
    w = np.asarray(w, dtype=float)
    # Instrument matrix and regressor matrix both contain an intercept.
    Z = np.column_stack((np.ones(len(y)), z))
    X = np.column_stack((np.ones(len(y)), x))
    zwz = Z.T @ (w[:, None] * Z)
    xwz = X.T @ (w[:, None] * Z)
    zwy = Z.T @ (w * y)
    beta = np.linalg.solve(xwz @ np.linalg.solve(zwz, xwz.T), xwz @ np.linalg.solve(zwz, zwy))
    resid = y - X @ beta
    bread = np.linalg.inv(xwz @ np.linalg.solve(zwz, xwz.T))
    # HC0 sandwich from structural residuals and analytic weights.
    # The observation-level influence map is bread times X' W P_Z.
    pzw = Z @ np.linalg.solve(zwz, Z.T * w)
    influence = bread @ (X.T @ (w[:, None] * pzw))
    cov = influence @ np.diag(resid ** 2) @ influence.T
    n = len(y)
    cov *= n / (n - X.shape[1])
    return float(beta[1]), float(np.sqrt(cov[1, 1]))


def main():
    df = pd.read_csv('input.csv')
    # Collapse repeated regional variables and weights to exactly one row per region.
    regions = df[['region_id', 'region_weight', 'x', 'y']].drop_duplicates('region_id').copy()
    if len(regions) != df.region_id.nunique():
        raise ValueError('Could not form one unique regional row.')
    regions['e'] = regions.region_weight / regions.region_weight.sum()
    # Retain all region-industry rows, including zero/negligible shares.
    z_by_region = df.assign(share_shock=df.share * df.shock).groupby('region_id', sort=False).share_shock.sum()
    regions['z'] = regions.region_id.map(z_by_region)
    means = {v: np.sum(regions.e * regions[v]) for v in ['y', 'x', 'z']}
    for v in ['y', 'x', 'z']:
        regions[v + '0'] = regions[v] - means[v]
    # Industry exposure and exposure-weighted regional residual aggregates.
    merged = df.merge(regions[['region_id', 'e', 'y0', 'x0', 'z0']], on='region_id', validate='many_to_one')
    merged['ew_share'] = merged.e * merged.share
    grouped = merged.groupby('industry_id', sort=True)
    ind = grouped.ew_share.sum().rename('s').to_frame()
    for v in ['y0', 'x0', 'z0']:
        ind[v + 'bar'] = grouped.apply(lambda g: np.sum(g.ew_share * g[v]) / np.sum(g.ew_share), include_groups=False)
    # Shock is constant within industry. Verify and take one observation per industry.
    shocks = df.groupby('industry_id', sort=True).shock.nunique()
    if (shocks != 1).any():
        raise ValueError('shock varies within industry.')
    ind['shock'] = df.groupby('industry_id', sort=True).shock.first()
    n = len(ind)
    if n <= 2:
        raise ValueError('HC1 requires more than two industries.')
    effect, effect_se = weighted_iv(ind.y0bar, ind.x0bar, ind.shock, ind.s)
    first, first_se = weighted_iv(ind.x0bar, ind.z0bar, ind.shock, ind.s)
    effective = float(1.0 / np.sum(ind.s.to_numpy() ** 2))
    result = {
        'task_id': 'applied_shift_share',
        'platform': 'python',
        'estimates': [
            {'term': 'effect', 'estimate': effect, 'se': effect_se, 'n_obs': n},
            {'term': 'first_stage', 'estimate': first, 'se': first_se, 'n_obs': n},
            {'term': 'effective_shocks', 'estimate': effective, 'se': None, 'n_obs': n},
        ],
        'method_metadata': {'estimator': 'weighted 2SLS; Borusyak-Hull-Jaravel shock-level aggregation', 'vcov': 'shock-level HC1, structural IV residuals, analytic weights, no clustering'},
        'diagnostics': {},
    }
    with open('result.json', 'w') as f:
        json.dump(result, f, indent=2, allow_nan=False)

if __name__ == '__main__':
    main()
