import json
import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS

h = pd.read_csv('households.csv')
c = pd.read_csv('census.csv')
d = h.loc[h['recipient'].eq(0)].copy()
assert d['eligible'].isin([0, 1]).all()
assert len(d) > 0

# Construct the two group-specific endogenous regressors, exogenous terms,
# and excluded instruments. No additional intercept is included.
d['ineligible'] = 1 - d['eligible']
d['dose_ineligible'] = d['dose'] * d['ineligible']
d['dose_eligible'] = d['dose'] * d['eligible']
d['base_ineligible'] = d['baseline'] * d['ineligible']
d['base_eligible'] = d['baseline'] * d['eligible']
d['inst_ineligible'] = d['instrument'] * d['ineligible']
d['inst_eligible'] = d['instrument'] * d['eligible']
exog = d[['ineligible', 'eligible', 'base_ineligible', 'base_eligible']]
endog = d[['dose_ineligible', 'dose_eligible']]
instruments = d[['inst_ineligible', 'inst_eligible']]
fit = IV2SLS(d['outcome'], exog, endog, instruments, weights=d['weight']).fit()

beta0 = float(fit.params['dose_ineligible'])
beta1 = float(fit.params['dose_eligible'])
means = d.groupby('eligible').apply(lambda g: np.average(g['dose'], weights=g['weight']), include_groups=False)
effect0 = beta0 * float(means.loc[0])
effect1 = beta1 * float(means.loc[1])
pop = c.set_index('eligible')['nonrecipient_population']
pop_effect = float(np.average([effect0, effect1], weights=[pop.loc[0], pop.loc[1]]))
n = int(len(d))

result = {
    'task_id': 'applied_nonrecipient_population_iv',
    'platform': 'python',
    'estimates': [
        {'term': 'ineligible_effect', 'estimate': effect0, 'se': None, 'n_obs': n},
        {'term': 'eligible_nonrecipient_effect', 'estimate': effect1, 'se': None, 'n_obs': n},
        {'term': 'population_effect', 'estimate': pop_effect, 'se': None, 'n_obs': n},
    ],
    'method_metadata': {
        'estimator': 'weighted 2SLS',
        'weight': 'weight',
        'sample': 'all households with recipient=0',
        'counterfactual': 'dose set to zero for every retained household; attribution is a stated synthetic convention',
        'within_group_effect': 'group dose slope times household-weighted mean dose',
        'population_aggregation': 'nonrecipient_population from census.csv; used only for final between-group weighting',
        'group_slopes': {'ineligible': beta0, 'eligible': beta1},
        'group_weighted_mean_dose': {'ineligible': float(means.loc[0]), 'eligible': float(means.loc[1])},
    },
    'diagnostics': {
        'n_obs': n,
        'n_ineligible': int((d['eligible'] == 0).sum()),
        'n_eligible': int((d['eligible'] == 1).sum()),
        'census_nonrecipient_population': {'ineligible': int(pop.loc[0]), 'eligible': int(pop.loc[1])},
        'census_weight_sum': int(pop.loc[0] + pop.loc[1]),
    },
}
with open('result.json', 'w') as f:
    json.dump(result, f, indent=2, allow_nan=False)
