import json
import pandas as pd
from scipy import stats

# Read the supplied analysis sample and keep rows with both required fields.
data = pd.read_csv("./input.csv")
data = data[["group", "y"]].dropna()
groups = [part["y"].to_numpy() for _, part in data.groupby("group", sort=True)]

f_stat, p_value = stats.f_oneway(*groups)
n_obs = int(len(data))
df_num = int(len(groups) - 1)
df_den = int(n_obs - len(groups))

out = {
    "task_id": "anova_oneway",
    "platform": "python",
    "estimates": [
        {"term": "F", "estimate": float(f_stat), "se": None, "n_obs": n_obs},
        {"term": "df_num", "estimate": float(df_num), "se": None, "n_obs": n_obs},
        {"term": "df_den", "estimate": float(df_den), "se": None, "n_obs": n_obs},
        {"term": "p_value", "estimate": float(p_value), "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {"estimator": "One-way ANOVA", "vcov": "classical pooled within-group variance"},
    "diagnostics": {},
}
with open("result.json", "w") as f:
    json.dump(out, f)
