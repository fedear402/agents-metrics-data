import json
import numpy as np
import pandas as pd

h = pd.read_csv('households.csv')
c = pd.read_csv('census.csv')
# Retain all nonrecipients, regardless of village treatment status.
s = h.loc[h['recipient'].eq(0)].copy()
e = s['eligible'].to_numpy(dtype=float)
d = s['dose'].to_numpy(dtype=float)
z = s['instrument'].to_numpy(dtype=float)
b = s['baseline'].to_numpy(dtype=float)
w = s['weight'].to_numpy(dtype=float)
y = s['outcome'].to_numpy(dtype=float)

# No additional intercept: group indicators provide the two constants.
one_minus_e = 1.0 - e
X = np.column_stack([one_minus_e, e, b * one_minus_e, b * e,
                     d * one_minus_e, d * e])
Q = np.column_stack([one_minus_e, e, b * one_minus_e, b * e,
                     z * one_minus_e, z * e])
# Weighted 2SLS: solve the instrument-projected normal equations.
WQ = w[:, None] * Q
G = Q.T @ WQ
Pwy = WQ @ np.linalg.solve(G, Q.T @ (w * y))
Pwx = WQ @ np.linalg.solve(G, Q.T @ (w[:, None] * X))
beta = np.linalg.solve(X.T @ Pwx, X.T @ Pwy)

slopes = {0: float(beta[4]), 1: float(beta[5])}
means = {}
effects = {}
for g in (0, 1):
    mask = s['eligible'].to_numpy() == g
    means[g] = float(np.average(d[mask], weights=w[mask]))
    effects[g] = slopes[g] * means[g]

pop = c.set_index('eligible')['nonrecipient_population']
population_effect = (effects[0] * int(pop.loc[0]) + effects[1] * int(pop.loc[1])) / (int(pop.loc[0]) + int(pop.loc[1]))
n = int(len(s))
estimates = [
    {'term': 'ineligible_effect', 'estimate': effects[0], 'se': None, 'n_obs': n},
    {'term': 'eligible_nonrecipient_effect', 'estimate': effects[1], 'se': None, 'n_obs': n},
    {'term': 'population_effect', 'estimate': float(population_effect), 'se': None, 'n_obs': n},
]
result = {
    'task_id': 'applied_nonrecipient_population_iv',
    'platform': 'python',
    'estimates': estimates,
    'method_metadata': {
        'estimator': 'weighted 2SLS',
        'weight': 'weight column used as regression weight',
        'endogenous_columns': ['dose*(1-eligible)', 'dose*eligible'],
        'exogenous_columns': ['1-eligible', 'eligible', 'baseline*(1-eligible)', 'baseline*eligible'],
        'instrument_columns': ['1-eligible', 'eligible', 'baseline*(1-eligible)', 'baseline*eligible', 'instrument*(1-eligible)', 'instrument*eligible'],
        'counterfactual_convention': 'Synthetic attribution sets dose to zero for every retained household; each group effect is its fitted dose slope times its household-weighted mean dose.',
        'population_weights': 'nonrecipient_population from census.csv; used only for final between-group aggregation',
    },
    'diagnostics': {
        'n_nonrecipient_rows': n,
        'n_treated_nonrecipients': int(((s['treated'] == 1)).sum()),
        'n_control_nonrecipients': int(((s['treated'] == 0)).sum()),
        'n_ineligible_nonrecipients': int((s['eligible'] == 0).sum()),
        'n_eligible_nonrecipients': int((s['eligible'] == 1).sum()),
        'group_weighted_mean_dose': {'ineligible': means[0], 'eligible': means[1]},
        'fitted_dose_slopes': {'ineligible': slopes[0], 'eligible': slopes[1]},
        'census_nonrecipient_population': {'ineligible': int(pop.loc[0]), 'eligible': int(pop.loc[1])},
    },
}
with open('result.json', 'w') as f:
    json.dump(result, f, indent=2, allow_nan=False)
