import json
import numpy as np
import pandas as pd
from scipy import stats

# Read the supplied estimation sample and retain complete group and outcome rows.
data = pd.read_csv('./input.csv')
data = data.loc[:, ['group', 'y']].dropna()
n_obs = int(len(data))

# One-way ANOVA: between-group mean square divided by within-group mean square.
groups = [part['y'].to_numpy(dtype=float) for _, part in data.groupby('group', sort=True)]
k = len(groups)
if k < 2 or n_obs <= k:
    raise ValueError('ANOVA requires at least two groups and positive residual degrees of freedom.')

f_stat, p_value = stats.f_oneway(*groups)
df_num = k - 1
df_den = n_obs - k

out = {
    'task_id': 'anova_oneway',
    'platform': 'python',
    'estimates': [
        {'term': 'F', 'estimate': float(f_stat), 'se': None, 'n_obs': n_obs},
        {'term': 'df_num', 'estimate': float(df_num), 'se': None, 'n_obs': n_obs},
        {'term': 'df_den', 'estimate': float(df_den), 'se': None, 'n_obs': n_obs},
        {'term': 'p_value', 'estimate': float(p_value), 'se': None, 'n_obs': n_obs},
    ],
    'method_metadata': {'estimator': 'One-way ANOVA', 'vcov': 'classical pooled within-group variance'},
    'diagnostics': {},
}
with open('result.json', 'w') as f:
    json.dump(out, f, indent=2)
