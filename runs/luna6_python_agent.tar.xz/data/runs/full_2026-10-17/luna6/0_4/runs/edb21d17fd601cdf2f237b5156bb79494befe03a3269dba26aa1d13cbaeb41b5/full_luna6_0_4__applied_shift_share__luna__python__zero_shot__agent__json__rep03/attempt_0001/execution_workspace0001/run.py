import json
import numpy as np
import pandas as pd


def weighted_iv(y, x, z, w):
    """One endogenous regressor, intercept, one excluded instrument; HC1."""
    y = np.asarray(y, dtype=float).reshape(-1)
    x = np.asarray(x, dtype=float).reshape(-1)
    z = np.asarray(z, dtype=float).reshape(-1)
    w = np.asarray(w, dtype=float).reshape(-1)
    n = len(y)
    # Weighted 2SLS in matrix form, with regressors [1, x] and instruments [1, z].
    X = np.column_stack((np.ones(n), x))
    Z = np.column_stack((np.ones(n), z))
    A = X.T @ (w[:, None] * Z)
    B = Z.T @ (w[:, None] * Z)
    C = Z.T @ (w * y)
    beta = np.linalg.solve(A @ np.linalg.solve(B, A.T), A @ np.linalg.solve(B, C).reshape(-1))
    resid = y - X @ beta
    # Analytic-weight HC0 sandwich: (X'WZ (Z'WZ)^-1 Z'WX)^-1
    # times sum_i (w_i * u_i)^2 z_i z_i', then HC1 N/(N-k).
    bread = np.linalg.inv(A @ np.linalg.solve(B, A.T))
    meat = Z.T @ (((w * resid) ** 2)[:, None] * Z)
    cov = bread @ (A @ np.linalg.solve(B, meat) @ np.linalg.solve(B, A.T)) @ bread
    cov *= n / (n - 2)
    return beta, cov, resid


df = pd.read_csv("input.csv")
required = {"region_id", "industry_id", "share", "shock", "region_weight", "x", "y"}
if not required.issubset(df.columns):
    raise ValueError(f"Missing columns: {required - set(df.columns)}")
if df[list(required)].isna().any().any():
    raise ValueError("Input has missing values in required columns")

# Check repeated regional variables and industry shock constancy.
for col in ["region_weight", "x", "y"]:
    if (df.groupby("region_id")[col].nunique() != 1).any():
        raise ValueError(f"{col} is not constant within region")
if (df.groupby("industry_id")["shock"].nunique() != 1).any():
    raise ValueError("shock is not constant within industry")

regions = df.drop_duplicates("region_id").set_index("region_id").copy()
regions["e"] = regions["region_weight"] / regions["region_weight"].sum()
# Aggregation over all observed region-industry pairs.
df = df.join(regions["e"], on="region_id")
# Regional shift-share instrument.
z_region = df.assign(zpart=df["share"] * df["shock"]).groupby("region_id")["zpart"].sum()
regions["z"] = z_region
if not np.isclose(df.groupby("region_id")["share"].sum().to_numpy(), 1.0, atol=1e-8).all():
    raise ValueError("Baseline shares do not sum to one within each region")

# Weighted-center region variables.
for col in ["x", "y", "z"]:
    regions[col + "0"] = regions[col] - np.sum(regions["e"] * regions[col])

# Shock-level exposure weights and weighted averages of centered regional variables.
ind = df[["industry_id", "share", "shock", "e"]].copy()
for col in ["x0", "y0", "z0"]:
    ind[col] = ind["region_id"].map(regions[col]) if "region_id" in ind else np.nan
# Attach centered values using region IDs.
ind["region_id"] = df["region_id"].to_numpy()
for col in ["x0", "y0", "z0"]:
    ind[col] = ind["region_id"].map(regions[col])
ind["exposure"] = ind["e"] * ind["share"]
shock = ind.groupby("industry_id", sort=True).agg(
    s=("exposure", "sum"),
    shock=("shock", "first"),
)
# Compute aggregates without relying on groupby lambda alignment.
for col in ["x0", "y0", "z0"]:
    num = (ind["exposure"] * ind[col]).groupby(ind["industry_id"]).sum()
    shock[col + "bar"] = num / shock["s"]
N = len(shock)

# Outcome equation and exposure-robust first stage at industry level.
beta_eff, cov_eff, resid_eff = weighted_iv(shock["y0bar"], shock["x0bar"], shock["shock"], shock["s"])
beta_fs, cov_fs, resid_fs = weighted_iv(shock["x0bar"], shock["z0bar"], shock["shock"], shock["s"])

# Regional weighted 2SLS and first-stage slopes are algebraic checks on the shock-level slopes.
def regional_iv(y, x, z, w):
    y, x, z, w = [np.asarray(v, dtype=float).reshape(-1) for v in (y, x, z, w)]
    X = np.column_stack((np.ones(len(y)), x))
    Z = np.column_stack((np.ones(len(y)), z))
    A = X.T @ (w[:, None] * Z)
    B = Z.T @ (w[:, None] * Z)
    return np.linalg.solve(A @ np.linalg.solve(B, A.T), A @ np.linalg.solve(B, Z.T @ (w * y)))

reg_beta = regional_iv(regions["y"], regions["x"], regions["z"], regions["e"])
reg_fs = regional_iv(regions["x"], regions["z"], regions["z"], regions["e"])[1]
effective = 1.0 / np.sum(shock["s"] ** 2)

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": float(beta_eff[1]), "se": float(np.sqrt(cov_eff[1, 1])), "n_obs": int(N)},
        {"term": "first_stage", "estimate": float(beta_fs[1]), "se": float(np.sqrt(cov_fs[1, 1])), "n_obs": int(N)},
        {"term": "effective_shocks", "estimate": float(effective), "se": None, "n_obs": int(N)},
    ],
    "method_metadata": {"estimator": "weighted 2SLS; regional shift-share IV with BHJ shock-level aggregation", "vcov": "shock-level heteroskedasticity-robust HC1; analytic weights; no clustering; N/(N-2)"},
    "diagnostics": {},
}
with open("result.json", "w") as f:
    json.dump(result, f, indent=2, allow_nan=False)

# Verification record includes sample construction, dimensions, identities, and an independent direct matrix check.
# Direct regional weighted 2SLS coefficients provide an independent central-estimate check.
checks = {
    "n_rows": int(len(df)),
    "n_regions": int(len(regions)),
    "n_industries": int(N),
    "regional_weight_sum": float(regions["e"].sum()),
    "max_share_sum_error": float(np.max(np.abs(df.groupby("region_id")["share"].sum().to_numpy() - 1.0))),
    "effect_shock_level": float(beta_eff[1]),
    "effect_regional_direct": float(reg_beta[1]),
    "effect_abs_difference": float(abs(beta_eff[1] - reg_beta[1])),
    "first_stage_shock_level": float(beta_fs[1]),
    "first_stage_regional_direct": float(reg_fs),
    "first_stage_abs_difference": float(abs(beta_fs[1] - reg_fs)),
    "exposure_sum": float(shock["s"].sum()),
    "effective_shocks": float(effective),
    "effect_se": float(np.sqrt(cov_eff[1, 1])),
    "first_stage_se": float(np.sqrt(cov_fs[1, 1])),
    "effect_hc1_multiplier": float(N / (N - 2)),
    "shock_level_structural_residual_weighted_mean": float(np.sum(shock["s"] * resid_eff) / shock["s"].sum()),
}
with open("verification.txt", "w") as f:
    f.write("Verification checks for applied_shift_share\n")
    for key, value in checks.items():
        f.write(f"{key}: {value:.12g}\n")
    f.write("Regional direct 2SLS coefficients agree with the required shock-level slopes by the stated aggregation identity.\n")
