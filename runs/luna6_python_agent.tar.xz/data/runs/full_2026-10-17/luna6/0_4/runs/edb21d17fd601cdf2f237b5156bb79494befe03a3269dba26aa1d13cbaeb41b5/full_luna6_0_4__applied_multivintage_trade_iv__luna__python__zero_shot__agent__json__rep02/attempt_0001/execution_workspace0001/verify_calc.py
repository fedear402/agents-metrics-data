import numpy as np, pandas as pd
C=pd.read_csv('crosswalk.csv');T=pd.read_csv('trade.csv').merge(C,on='code');A=pd.read_csv('areas.csv');E=pd.read_csv('employment.csv');O=pd.read_csv('outcomes.csv')
# Direct loop calculation, independently from the production exposure merges.
assert not E.duplicated(['area','period','vintage','industry']).any()
assert E.groupby(['period','vintage','industry']).employment.sum().gt(0).all()
def exposures(vintage, flow):
 d={}
 for p in sorted(A.period.unique()):
  for area in sorted(A.area.unique()):
   ar=A[(A.area==area)&(A.period==p)&(A.vintage==vintage)].iloc[0]; value=0.0
   for j in C.industry:
    local=E[(E.area==area)&(E.period==p)&(E.vintage==vintage)&(E.industry==j)]
    emp=float(local.employment.sum())
    den=float(E[(E.period==p)&(E.vintage==vintage)&(E.industry==j)].employment.sum())
    t=T[(T.period==p)&(T.industry==j)].iloc[0]
    value+=(emp/ar.total_employment)*(t[flow]/den)/(t.price_index/100)/1000*(10/t.years)
   d[(area,p)]=value
 return d
x=exposures('base','us_change');z=exposures('early','other_change')
s=O.merge(A[A.vintage=='base'][['area','period','population']],on=['area','period'])
s['x']=[x[(r.area,r.period)] for r in s.itertuples()];s['z']=[z[(r.area,r.period)] for r in s.itertuples()]
w=s.population.to_numpy(float);X=np.column_stack([np.ones(len(s)),s.period,s.control,s.x]);Q=np.column_stack([np.ones(len(s)),s.period,s.control,s.z]);y=s.change_pp.to_numpy()
Qw=Q*np.sqrt(w)[:,None];Xw=X*np.sqrt(w)[:,None];yw=y*np.sqrt(w)
u,sv,vh=np.linalg.svd(Qw,full_matrices=False);basis=u[:,:np.linalg.matrix_rank(Qw)];Xp=basis@(basis.T@Xw);yp=basis@(basis.T@yw);b=np.linalg.lstsq(Xp,yp,rcond=None)[0]
print('obs',len(s),'instrument_rank',np.linalg.matrix_rank(Qw))
print('iv_slope',format(b[3],'.16g'))
print('x00',format(x[(0,0)],'.16g'),'x01',format(x[(0,1)],'.16g'),'z00',format(z[(0,0)],'.16g'))
