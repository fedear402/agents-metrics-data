import json
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
crosswalk = pd.read_csv(ROOT / 'crosswalk.csv')
trade = pd.read_csv(ROOT / 'trade.csv')
areas = pd.read_csv(ROOT / 'areas.csv')
employment = pd.read_csv(ROOT / 'employment.csv')
outcomes = pd.read_csv(ROOT / 'outcomes.csv')

assert crosswalk['code'].is_unique
assert trade.groupby('period')['code'].nunique().eq(4).all()
assert trade.groupby('period').size().eq(4).all()
assert crosswalk.groupby('code')['industry'].nunique().eq(1).all()
trade = trade.merge(crosswalk, on='code', how='left', validate='many_to_one')
assert trade['industry'].notna().all()

# Complete omitted area-industry cells as zero for both vintages.
industries = sorted(crosswalk['industry'].unique())
keys = areas[['area', 'period', 'vintage']].merge(
    pd.DataFrame({'industry': industries}), how='cross')
employment = keys.merge(employment, on=['area','period','vintage','industry'], how='left', validate='one_to_one')
employment['employment'] = employment['employment'].fillna(0)
assert len(employment) == len(areas) * len(industries)

# Join each employment vintage to the matching area-period denominator and calculate national sums.
employment = employment.merge(
    areas[['area','period','vintage','total_employment']],
    on=['area','period','vintage'], validate='many_to_one')
national = employment.groupby(['period','vintage','industry'], as_index=False)['employment'].sum()
assert (national['employment'] > 0).all()

base = employment[employment.vintage.eq('base')].merge(
    national[national.vintage.eq('base')].drop(columns='vintage'),
    on=['period','industry'], validate='many_to_one', suffixes=('', '_national'))
early = employment[employment.vintage.eq('early')].merge(
    national[national.vintage.eq('early')].drop(columns='vintage'),
    on=['period','industry'], validate='many_to_one', suffixes=('', '_national'))

# Merge trade by period and industry after applying the code crosswalk.
def exposure_frame(emp, amount):
    d = emp.merge(trade[['period','industry',amount,'price_index','years']],
                  on=['period','industry'], validate='many_to_one')
    # Convert nominal dollars to thousands of real dollars, then annual interval to decade scale.
    d['component'] = (d['employment'] / d['total_employment']
                      * d[amount] / d['employment_national']
                      / (d['price_index'] / 100) / 1000 * (10 / d['years']))
    return d.groupby(['area','period'], as_index=False)['component'].sum()

x = exposure_frame(base, 'us_change').rename(columns={'component':'x'})
z = exposure_frame(early, 'other_change').rename(columns={'component':'z'})
reg = (outcomes.merge(areas[areas.vintage.eq('base')][['area','period','population']],
                      on=['area','period'], validate='one_to_one')
       .merge(x, on=['area','period'], validate='one_to_one')
       .merge(z, on=['area','period'], validate='one_to_one')
       .sort_values(['area','period']).reset_index(drop=True))
assert len(reg) == 72
assert reg[['change_pp','control','population','x','z']].notna().all().all()

# Weighted 2SLS: regress x on all exogenous variables and z, then regress y on exogenous variables and fitted x.
# This is algebraically equivalent to the weighted IV moment estimator using Z'WZ.
y = reg['change_pp'].to_numpy(dtype=float)
xv = reg['x'].to_numpy(dtype=float)
zv = reg['z'].to_numpy(dtype=float)
w = reg['population'].to_numpy(dtype=float)
period = reg['period'].to_numpy(dtype=float)
control = reg['control'].to_numpy(dtype=float)
X = np.column_stack([np.ones(len(reg)), period, control, xv])
Q = np.column_stack([np.ones(len(reg)), period, control, zv])
rootw = np.sqrt(w)
Xw, Qw, yw = X * rootw[:,None], Q * rootw[:,None], y * rootw
# Weighted 2SLS coefficient, via weighted projection of each structural regressor on instruments.
coef_first = np.linalg.lstsq(Qw, Xw, rcond=None)[0]
Xhatw = Qw @ coef_first
beta = np.linalg.lstsq(Xhatw, yw, rcond=None)[0]

# Independent central calculation: direct IV normal-equation identity (X'WQ)(Q'WQ)^-1(Q'Wy).
G = Q.T @ (w[:,None] * Q)
H = X.T @ (w[:,None] * Q)
q = Q.T @ (w * y)
beta_direct = np.linalg.solve(H @ np.linalg.solve(G, H.T), H @ np.linalg.solve(G, q))
assert np.allclose(beta, beta_direct, rtol=1e-10, atol=1e-10)

x0 = x[(x.area == 0)].set_index('period')['x']
z00 = z[(z.area == 0) & (z.period == 0)]['z'].iloc[0]
result = {
    'task_id': 'applied_multivintage_trade_iv',
    'platform': 'python',
    'estimates': [
        {'term':'iv_slope','estimate':float(beta[3]),'se':None,'n_obs':72},
        {'term':'exposure_area0_period0','estimate':float(x0.loc[0]),'se':None,'n_obs':72},
        {'term':'exposure_area0_period1','estimate':float(x0.loc[1]),'se':None,'n_obs':72},
        {'term':'instrument_area0_period0','estimate':float(z00),'se':None,'n_obs':72},
    ],
    'method_metadata': {
        'estimator':'Weighted two-stage least squares',
        'structural_regressors':['intercept','period','control','x'],
        'instruments':['intercept','period','control','z'],
        'weight':'base-vintage population',
        'exposure_units':'thousands of real dollars per worker per decade',
        'outcome_units':'decadal percentage-point change',
        'uncertainty':'Not requested; standard errors set to null'
    },
    'diagnostics': {
        'n_obs':int(len(reg)),
        'n_areas':int(reg['area'].nunique()),
        'n_periods':int(reg['period'].nunique()),
        'industries':int(len(industries)),
        'all_area_period_rows_complete':True,
        'weighted_2sls_direct_identity_max_abs_diff':float(np.max(np.abs(beta-beta_direct))),
        'first_stage_rank':int(np.linalg.matrix_rank(Qw)),
        'structural_rank':int(np.linalg.matrix_rank(Xhatw)),
    }
}
with open(ROOT / 'result.json','w') as f:
    json.dump(result, f, indent=2, allow_nan=False)

# Save compact verification record for the required independent checks.
with open(ROOT / 'verification.txt','w') as f:
    f.write('Estimation sample: 72 unique area-period rows (36 areas x 2 periods), all outcome/exposure/instrument/weight values present.\n')
    f.write('Construction: completed omitted area-industry cells with zero; checked four industry rows per period and positive national denominators.\n')
    f.write('Estimator: weighted 2SLS with base-vintage population weights, structural columns [1, period, control, x], instruments [1, period, control, z].\n')
    f.write(f'Independent calculation: direct weighted IV normal-equation identity vs weighted projected-regressor calculation; max absolute coefficient difference {np.max(np.abs(beta-beta_direct)):.12g}.\n')
    f.write(f'Ranks: instrument matrix {np.linalg.matrix_rank(Qw)}, projected structural matrix {np.linalg.matrix_rank(Xhatw)}.\n')
print(json.dumps(result, indent=2))
