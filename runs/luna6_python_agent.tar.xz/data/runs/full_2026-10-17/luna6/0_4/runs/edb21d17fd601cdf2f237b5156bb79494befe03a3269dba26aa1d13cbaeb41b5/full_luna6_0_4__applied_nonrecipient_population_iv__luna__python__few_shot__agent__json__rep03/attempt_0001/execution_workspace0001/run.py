import json
import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS

households = pd.read_csv('households.csv')
census = pd.read_csv('census.csv')

# Retain every household that did not receive the transfer.
h = households.loc[households['recipient'].eq(0)].copy()
h['ineligible'] = 1 - h['eligible']
h['dose_ineligible'] = h['dose'] * h['ineligible']
h['dose_eligible'] = h['dose'] * h['eligible']
h['baseline_ineligible'] = h['baseline'] * h['ineligible']
h['baseline_eligible'] = h['baseline'] * h['eligible']
h['instrument_ineligible'] = h['instrument'] * h['ineligible']
h['instrument_eligible'] = h['instrument'] * h['eligible']

exog = h[['ineligible', 'eligible', 'baseline_ineligible', 'baseline_eligible']]
endog = h[['dose_ineligible', 'dose_eligible']]
# linearmodels takes excluded instruments here and adds exog internally.
excluded_instruments = h[['instrument_ineligible', 'instrument_eligible']]
fit = IV2SLS(h['outcome'], exog, endog, excluded_instruments, weights=h['weight']).fit()

slopes = {
    0: float(fit.params['dose_ineligible']),
    1: float(fit.params['dose_eligible']),
}
means = {
    g: float(np.average(h.loc[h['eligible'].eq(g), 'dose'],
                        weights=h.loc[h['eligible'].eq(g), 'weight']))
    for g in (0, 1)
}
effects = {g: slopes[g] * means[g] for g in (0, 1)}
pop_weights = census.set_index('eligible')['nonrecipient_population']
population_effect = float(np.average([effects[0], effects[1]],
                                     weights=[pop_weights.loc[0], pop_weights.loc[1]]))
n_obs = int(len(h))

result = {
    'task_id': 'applied_nonrecipient_population_iv',
    'platform': 'python',
    'estimates': [
        {'term': 'ineligible_effect', 'estimate': float(effects[0]), 'se': None, 'n_obs': n_obs},
        {'term': 'eligible_nonrecipient_effect', 'estimate': float(effects[1]), 'se': None, 'n_obs': n_obs},
        {'term': 'population_effect', 'estimate': population_effect, 'se': None, 'n_obs': n_obs},
    ],
    'method_metadata': {
        'estimator': 'weighted 2SLS',
        'weight': 'weight',
        'retained_sample': 'all households with recipient=0, across both village treatment statuses',
        'endogenous_columns': ['dose*(1-eligible)', 'dose*eligible'],
        'exogenous_columns': ['1-eligible', 'eligible', 'baseline*(1-eligible)', 'baseline*eligible'],
        'instrument_columns': ['1-eligible', 'eligible', 'baseline*(1-eligible)', 'baseline*eligible',
                              'instrument*(1-eligible)', 'instrument*eligible'],
        'group_mean_dose': 'household-weighted mean among retained observations in each eligibility group',
        'counterfactual': 'dose set to zero for every retained household; attribution is a stated synthetic convention',
        'population_weights': 'nonrecipient_population from census.csv; used only for final aggregation',
        'n_obs_definition': 'number of nonrecipient household rows used in estimation',
        'standard_errors': None,
    },
    'diagnostics': {
        'n_obs': n_obs,
        'group_n_obs': {str(g): int(h['eligible'].eq(g).sum()) for g in (0, 1)},
        'group_weighted_mean_dose': {str(g): means[g] for g in (0, 1)},
        'group_dose_slopes': {str(g): slopes[g] for g in (0, 1)},
        'group_effect_identity_check': {str(g): float(slopes[g] * means[g] - effects[g]) for g in (0, 1)},
        'population_weights': {str(g): int(pop_weights.loc[g]) for g in (0, 1)},
        'population_identity_check': float(population_effect - (pop_weights.loc[0] * effects[0] + pop_weights.loc[1] * effects[1]) / (pop_weights.loc[0] + pop_weights.loc[1])),
    },
}
with open('result.json', 'w') as f:
    json.dump(result, f, indent=2)
    f.write('\n')
