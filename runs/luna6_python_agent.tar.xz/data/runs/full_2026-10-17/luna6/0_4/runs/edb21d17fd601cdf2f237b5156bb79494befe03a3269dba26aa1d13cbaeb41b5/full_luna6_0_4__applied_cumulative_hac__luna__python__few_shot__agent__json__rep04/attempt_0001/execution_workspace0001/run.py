import json
import numpy as np
import pandas as pd

# Read and order the observed trading rows before constructing changes and lags.
data = pd.read_csv('input.csv', parse_dates=['date'])
if list(data.columns) != ['date', 'sales', 'vix']:
    raise ValueError('Unexpected CSV columns')
data = data.sort_values('date').reset_index(drop=True)
data['log_sales'] = np.log(data['sales'])
data['vix_change'] = np.log(data['vix']).diff()
for j in range(1, 16):
    data[f'lag_{j}'] = data['vix_change'].shift(j)
sample = data.dropna(subset=['log_sales'] + [f'lag_{j}' for j in range(1, 16)]).copy()
N = len(sample)
X = np.column_stack([np.ones(N)] + [sample[f'lag_{j}'].to_numpy() for j in range(1, 16)])
y = sample['log_sales'].to_numpy()
beta = np.linalg.lstsq(X, y, rcond=None)[0]
u = y - X @ beta

# Bartlett Newey-West covariance on chronological regression-sample scores.
scores = X * u[:, None]
meat = scores.T @ scores
for j in range(1, 16):
    w = 1.0 - j / 16.0
    gamma = scores[j:].T @ scores[:-j]
    meat += w * (gamma + gamma.T)
bread = np.linalg.inv(X.T @ X)
cov = (N / (N - 16)) * bread @ meat @ bread

contrast = np.r_[0.0, np.ones(15)]
rows = [
    {'term': 'cumulative_response', 'estimate': float(contrast @ beta), 'se': float(np.sqrt(contrast @ cov @ contrast)), 'n_obs': int(N)},
    {'term': 'lag_1', 'estimate': float(beta[1]), 'se': float(np.sqrt(cov[1, 1])), 'n_obs': int(N)},
    {'term': 'lag_15', 'estimate': float(beta[15]), 'se': float(np.sqrt(cov[15, 15])), 'n_obs': int(N)},
]
output = {
    'task_id': 'applied_cumulative_hac',
    'platform': 'python',
    'estimates': rows,
    'method_metadata': {'estimator': 'OLS with intercept and 15 lagged log-VIX changes', 'vcov': 'Newey-West HAC, Bartlett max lag 15, covariance scaled by N/(N-16)'},
    'diagnostics': {},
}
with open('result.json', 'w') as f:
    json.dump(output, f, indent=2, allow_nan=False)
