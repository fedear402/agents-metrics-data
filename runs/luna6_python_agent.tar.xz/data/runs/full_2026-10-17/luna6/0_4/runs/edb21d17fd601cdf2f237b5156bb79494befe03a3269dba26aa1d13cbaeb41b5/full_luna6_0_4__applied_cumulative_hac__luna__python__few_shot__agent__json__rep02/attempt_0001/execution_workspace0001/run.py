import json
import numpy as np
import pandas as pd

# Load and sort observed trading rows before constructing log changes and lags.
data = pd.read_csv("input.csv", parse_dates=["date"])
data = data.sort_values("date").reset_index(drop=True)
data["log_sales"] = np.log(data["sales"])
data["vix_change"] = np.log(data["vix"]).diff()
lag_names = [f"lag_{j}" for j in range(1, 16)]
for j, name in enumerate(lag_names, start=1):
    data[name] = data["vix_change"].shift(j)
sample = data.dropna(subset=["log_sales", *lag_names]).copy()
N = len(sample)
X = np.column_stack([np.ones(N), sample[lag_names].to_numpy()])
y = sample["log_sales"].to_numpy()
beta = np.linalg.lstsq(X, y, rcond=None)[0]
resid = y - X @ beta

# Bartlett Newey-West covariance, with the specified finite-sample correction.
scores = X * resid[:, None]
meat = scores.T @ scores
max_lag = 15
for j in range(1, max_lag + 1):
    weight = 1 - j / 16
    gamma = scores[j:].T @ scores[:-j]
    meat += weight * (gamma + gamma.T)
bread = np.linalg.inv(X.T @ X)
cov = (N / (N - 16)) * bread @ meat @ bread

contrast = np.r_[0.0, np.ones(15)]
terms = [
    ("cumulative_response", float(contrast @ beta), float(np.sqrt(contrast @ cov @ contrast))),
    ("lag_1", float(beta[1]), float(np.sqrt(cov[1, 1]))),
    ("lag_15", float(beta[15]), float(np.sqrt(cov[15, 15]))),
]
output = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {"term": name, "estimate": estimate, "se": se, "n_obs": N}
        for name, estimate, se in terms
    ],
    "method_metadata": {
        "estimator": "OLS with intercept and 15 observed-row lags of first differences in log(vix)",
        "vcov": "Newey-West HAC, Bartlett max lag 15, N/(N-16) correction",
    },
    "diagnostics": {},
}
with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
