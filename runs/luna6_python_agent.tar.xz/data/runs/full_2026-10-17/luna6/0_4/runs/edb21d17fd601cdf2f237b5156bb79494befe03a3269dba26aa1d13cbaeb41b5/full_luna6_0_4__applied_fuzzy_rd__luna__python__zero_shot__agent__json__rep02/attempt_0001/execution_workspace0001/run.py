import json
import numpy as np
import pandas as pd

DATA = 'input.csv'
OUT = 'result.json'

df = pd.read_csv(DATA)
required = {'id', 'score', 'participated', 'earnings'}
if not required.issubset(df.columns):
    raise ValueError(f'Missing columns: {required - set(df.columns)}')

# Strict bandwidth as specified; triangular weights are fixed at the cutoff.
sample = df.loc[df['score'].abs() < 1].copy()
sample['right'] = (sample['score'] >= 0).astype(float)
sample['weight'] = 1 - sample['score'].abs()
sample['x_left'] = sample['score'] * (1 - sample['right'])
sample['x_right'] = sample['score'] * sample['right']

# Common weighted design: separate intercepts and slopes on either side.
X = np.column_stack([
    np.ones(len(sample)) * (1 - sample['right']),
    np.ones(len(sample)) * sample['right'],
    sample['x_left'],
    sample['x_right'],
])
w = sample['weight'].to_numpy(float)
Y = sample[['earnings', 'participated']].to_numpy(float)
A = X.T @ (w[:, None] * X)
A_inv = np.linalg.inv(A)
beta = A_inv @ X.T @ (w[:, None] * Y)
# HC0 sandwich for fixed WLS weights: (X'WX)^-1 X'W diag(e^2) W X (X'WX)^-1.
resid = Y - X @ beta
# Cross-outcome covariance is needed for the delta method.
# Build covariance blocks Cov(beta outcome a, beta outcome b), with same design for each outcome.
cov_blocks = np.empty((2, 2, 4, 4))
for a in range(2):
    for b in range(2):
        cross_meat = X.T @ ((w ** 2 * resid[:, a] * resid[:, b])[:, None] * X)
        cov_blocks[a, b] = A_inv @ cross_meat @ A_inv

# Intercepts are first two coefficients; right minus left.
c = np.array([-1.0, 1.0, 0.0, 0.0])
tau_y = float(c @ beta[:, 0])
tau_d = float(c @ beta[:, 1])
C = np.array([[c @ cov_blocks[a, b] @ c for b in range(2)] for a in range(2)])
ratio = tau_y / tau_d
ratio_grad = np.array([1.0 / tau_d, -tau_y / (tau_d ** 2)])
ratio_var = float(ratio_grad @ C @ ratio_grad)

estimates = [
    {'term': 'treatment_effect', 'estimate': ratio, 'se': float(np.sqrt(max(ratio_var, 0.0))), 'n_obs': int(len(sample))},
    {'term': 'reduced_form', 'estimate': tau_y, 'se': float(np.sqrt(max(C[0, 0], 0.0))), 'n_obs': int(len(sample))},
    {'term': 'first_stage', 'estimate': tau_d, 'se': float(np.sqrt(max(C[1, 1], 0.0))), 'n_obs': int(len(sample))},
]
result = {
    'task_id': 'applied_fuzzy_rd',
    'platform': 'python',
    'estimates': estimates,
    'method_metadata': {
        'estimator': 'Fuzzy RD local-linear WLS; cutoff 0; bandwidth 1; triangular weights; separate slopes; abs(score) < 1',
        'vcov': 'HC0 sandwich with fixed triangular weights; delta method uses joint covariance of reduced form and first stage',
    },
    'diagnostics': {},
}
with open(OUT, 'w', encoding='utf-8') as f:
    json.dump(result, f, indent=2, allow_nan=False)

# Independent numerical check: scalar weighted HC0 fits for each outcome and the
# difference-in-means intercept contrast from explicit weighted regression matrices.
checks = []
for j, name in enumerate(['earnings', 'participated']):
    bj = np.linalg.solve(A, X.T @ (w * Y[:, j]))
    rj = Y[:, j] - X @ bj
    vj = A_inv @ (X.T @ (((w * rj) ** 2)[:, None] * X)) @ A_inv
    checks.append((float(c @ bj), float(np.sqrt(c @ vj @ c))))
if not np.allclose(checks[0][0], tau_y, rtol=1e-11, atol=1e-11):
    raise AssertionError('Independent reduced-form calculation differs')
if not np.allclose(checks[1][0], tau_d, rtol=1e-11, atol=1e-11):
    raise AssertionError('Independent first-stage calculation differs')
# Verify the cross-equation HC0 covariance by direct observation-level score products.
score_y = (X * (w * resid[:, 0])[:, None]) @ A_inv
score_d = (X * (w * resid[:, 1])[:, None]) @ A_inv
cross_direct = float((score_y @ c) @ (score_d @ c))
if not np.allclose(cross_direct, C[0, 1], rtol=1e-11, atol=1e-11):
    raise AssertionError('Independent cross-covariance calculation differs')
print(json.dumps({'n_obs': len(sample), 'inside_left': int((sample.score < 0).sum()), 'inside_right': int((sample.score >= 0).sum()), 'reduced_form': tau_y, 'first_stage': tau_d, 'treatment_effect': ratio, 'covariance_rf_fs': float(C[0, 1]), 'independent_scalar_checks': checks, 'independent_cross_covariance': cross_direct}, indent=2))
