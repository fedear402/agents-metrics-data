import json
import numpy as np
import pandas as pd

from linearmodels.iv import IV2SLS


crosswalk = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv").merge(crosswalk, on="code", how="left", validate="many_to_one")
areas = pd.read_csv("areas.csv")
employment = pd.read_csv("employment.csv")
outcomes = pd.read_csv("outcomes.csv")

if trade["industry"].isna().any():
    raise ValueError("A trade code has no crosswalk entry")

key = ["area", "period", "vintage", "industry"]
if employment.duplicated(key).any():
    raise ValueError("Duplicate area-period-vintage-industry employment rows")

exposure_rows = []
for period, p_areas in areas.groupby("period", sort=True):
    p_trade = trade.loc[trade.period == period]
    price_index = p_trade.price_index.unique()
    years = p_trade.years.unique()
    if len(price_index) != 1 or len(years) != 1:
        raise ValueError("Price index and years must be constant within period")
    for vintage, change_col in [("base", "us_change"), ("early", "other_change")]:
        emp = employment.loc[(employment.period == period) & (employment.vintage == vintage)]
        # Aggregate by industry across every supplied area before merging with local employment.
        national = emp.groupby("industry").employment.sum()
        local = p_areas.loc[p_areas.vintage == vintage, ["area", "total_employment"]].merge(
            emp, on="area", how="left", validate="one_to_many"
        )
        local["employment"] = local["employment"].fillna(0.0)
        local = local.merge(p_trade[["industry", change_col]], on="industry", how="left", validate="many_to_one")
        local["national_employment"] = local.industry.map(national)
        local["component"] = (
            local.employment / local.total_employment
            * local[change_col] / local.national_employment
            / (float(price_index[0]) / 100.0) / 1000.0
            * (10.0 / float(years[0]))
        )
        exp = local.groupby("area").component.sum()
        for area, value in exp.items():
            exposure_rows.append({"area": area, "period": period, "vintage": vintage, "exposure": value})

exposures = pd.DataFrame(exposure_rows).pivot(index=["area", "period"], columns="vintage", values="exposure").reset_index()
exposures = exposures.rename(columns={"base": "x", "early": "z"})
sample = outcomes.merge(exposures, on=["area", "period"], how="inner", validate="one_to_one")
sample = sample.merge(
    areas.loc[areas.vintage == "base", ["area", "period", "population"]],
    on=["area", "period"], how="inner", validate="one_to_one",
)
sample["period_regressor"] = sample.period
if len(sample) != 72 or sample[["change_pp", "control", "x", "z", "population"]].isna().any().any():
    raise ValueError("Estimation sample failed required size or completeness check")

fit = IV2SLS(
    dependent=sample.change_pp,
    exog=sample[["period_regressor", "control"]].assign(intercept=1.0)[["intercept", "period_regressor", "control"]],
    endog=sample[["x"]],
    instruments=sample[["z"]],
    weights=sample.population,
).fit()

estimates = [
    {"term": "iv_slope", "estimate": float(fit.params["x"]), "se": None, "n_obs": 72},
    {"term": "exposure_area0_period0", "estimate": float(exposures.query("area == 0 and period == 0").x.iloc[0]), "se": None, "n_obs": 72},
    {"term": "exposure_area0_period1", "estimate": float(exposures.query("area == 0 and period == 1").x.iloc[0]), "se": None, "n_obs": 72},
    {"term": "instrument_area0_period0", "estimate": float(exposures.query("area == 0 and period == 0").z.iloc[0]), "se": None, "n_obs": 72},
]
result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "dependent_variable": "change_pp",
        "exogenous_regressors": ["intercept", "period", "control"],
        "endogenous_regressor": "x",
        "excluded_instrument": "z",
        "weight": "base-vintage population",
        "n_obs": 72,
    },
    "diagnostics": {
        "n_area_period_rows": int(len(sample)),
        "n_periods": int(sample.period.nunique()),
        "n_areas": int(sample.area.nunique()),
        "employment_cells_zero_filled": True,
        "all_requested_estimates_finite": bool(np.isfinite([e["estimate"] for e in estimates]).all()),
    },
}
with open("result.json", "w") as f:
    json.dump(result, f, indent=2, allow_nan=False)
    f.write("\n")
