import json
import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS

h = pd.read_csv('households.csv')
c = pd.read_csv('census.csv')
# Retain every household that did not receive the transfer.
s = h.loc[h['recipient'].eq(0)].copy()
e = s['eligible'].to_numpy(dtype=float)
dose = s['dose'].to_numpy(dtype=float)
z = s['instrument'].to_numpy(dtype=float)
b = s['baseline'].to_numpy(dtype=float)
w = s['weight'].to_numpy(dtype=float)

# Four specified exogenous columns, with no additional intercept.
exog = pd.DataFrame({
    'ineligible': 1-e,
    'eligible': e,
    'baseline_ineligible': b*(1-e),
    'baseline_eligible': b*e,
})
endog = pd.DataFrame({
    'dose_ineligible': dose*(1-e),
    'dose_eligible': dose*e,
})
excluded = pd.DataFrame({
    'instrument_ineligible': z*(1-e),
    'instrument_eligible': z*e,
})
fit = IV2SLS(s['outcome'], exog, endog, excluded, weights=w).fit()

means = s.groupby('eligible').apply(lambda g: np.average(g['dose'], weights=g['weight']), include_groups=False)
slopes = fit.params
ineligible_effect = float(slopes['dose_ineligible'] * means.loc[0])
eligible_nonrecipient_effect = float(slopes['dose_eligible'] * means.loc[1])
counts = c.set_index('eligible')['nonrecipient_population']
population_effect = float(np.average(
    [ineligible_effect, eligible_nonrecipient_effect],
    weights=[counts.loc[0], counts.loc[1]],
))

n = int(len(s))
result = {
    'task_id': 'applied_nonrecipient_population_iv',
    'platform': 'python',
    'estimates': [
        {'term': 'ineligible_effect', 'estimate': ineligible_effect, 'se': None, 'n_obs': n},
        {'term': 'eligible_nonrecipient_effect', 'estimate': eligible_nonrecipient_effect, 'se': None, 'n_obs': n},
        {'term': 'population_effect', 'estimate': population_effect, 'se': None, 'n_obs': n},
    ],
    'method_metadata': {
        'estimator': 'weighted 2SLS',
        'weight': 'weight',
        'endogenous_columns': ['dose*(1-eligible)', 'dose*eligible'],
        'exogenous_columns': ['1-eligible', 'eligible', 'baseline*(1-eligible)', 'baseline*eligible'],
        'instrument_columns': ['1-eligible', 'eligible', 'baseline*(1-eligible)', 'baseline*eligible', 'instrument*(1-eligible)', 'instrument*eligible'],
        'counterfactual': 'dose set to zero for every retained household; attribution is a stated synthetic convention',
        'group_mean_dose': 'household-weighted mean within eligibility group',
        'population_weights': 'census nonrecipient_population, used only for final group aggregation',
    },
    'diagnostics': {
        'n_obs': n,
        'nonrecipient_rows': n,
        'group_slopes': {'ineligible': float(slopes['dose_ineligible']), 'eligible': float(slopes['dose_eligible'])},
        'group_weighted_mean_dose': {'ineligible': float(means.loc[0]), 'eligible': float(means.loc[1])},
        'nonrecipient_population': {'ineligible': int(counts.loc[0]), 'eligible': int(counts.loc[1])},
    },
}
with open('result.json', 'w') as f:
    json.dump(result, f, indent=2, allow_nan=False)
