import json

import pandas as pd
from scipy import stats


data = pd.read_csv("./input.csv")
sample = data[["group", "y"]].dropna()
groups = [values["y"].to_numpy() for _, values in sample.groupby("group", sort=True)]

if len(groups) < 2:
    raise ValueError("One-way ANOVA requires at least two groups.")

f_stat, p_value = stats.f_oneway(*groups)
n_obs = len(sample)
df_num = len(groups) - 1
df_den = n_obs - len(groups)

out = {
    "task_id": "anova_oneway",
    "platform": "python",
    "estimates": [
        {"term": "F", "estimate": float(f_stat), "se": None, "n_obs": n_obs},
        {"term": "df_num", "estimate": float(df_num), "se": None, "n_obs": n_obs},
        {"term": "df_den", "estimate": float(df_den), "se": None, "n_obs": n_obs},
        {"term": "p_value", "estimate": float(p_value), "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {"estimator": "One-way ANOVA", "vcov": "classical pooled within-group variance"},
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(out, f, indent=2)
