import csv
import json
from collections import defaultdict
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parent

def read(name):
    with (ROOT / name).open(newline='') as f:
        return list(csv.DictReader(f))

crosswalk = {r['code']: r['industry'] for r in read('crosswalk.csv')}
trade_rows = read('trade.csv')
areas_rows = read('areas.csv')
employment_rows = read('employment.csv')
outcomes_rows = read('outcomes.csv')

# Index employment cells, with omitted cells represented by zero when read below.
emp = defaultdict(float)
national = defaultdict(float)
for r in employment_rows:
    key = (int(r['area']), int(r['period']), r['vintage'], r['industry'])
    value = float(r['employment'])
    emp[key] += value
    national[(int(r['period']), r['vintage'], r['industry'])] += value

area_meta = {(int(r['area']), int(r['period']), r['vintage']): r for r in areas_rows}
trade = defaultdict(dict)
for r in trade_rows:
    industry = crosswalk[r['code']]
    period = int(r['period'])
    # Within-period constants and one row per industry are stated in the task.
    trade[period][industry] = {
        'us_change': float(r['us_change']),
        'other_change': float(r['other_change']),
        'price_index': float(r['price_index']),
        'years': float(r['years']),
    }

periods = sorted({int(r['period']) for r in outcomes_rows})
areas = sorted({int(r['area']) for r in outcomes_rows})
industries = sorted(set(crosswalk.values()), key=lambda s: int(s))

exposure = {}
instrument = {}
for area in areas:
    for period in periods:
        for label, vintage, flow, target in [('x', 'base', 'us_change', exposure),
                                              ('z', 'early', 'other_change', instrument)]:
            meta = area_meta[(area, period, vintage)]
            total = float(meta['total_employment'])
            value = 0.0
            for industry in industries:
                share = emp[(area, period, vintage, industry)] / total
                national_base = national[(period, vintage, industry)]
                t = trade[period][industry]
                value += share * (t[flow] / national_base) / (t['price_index'] / 100.0) / 1000.0 * (10.0 / t['years'])
            target[(area, period)] = value

outcome_by_key = {(int(r['area']), int(r['period'])): r for r in outcomes_rows}
keys = [(area, period) for period in periods for area in areas]
y = np.array([float(outcome_by_key[k]['change_pp']) for k in keys], dtype=float)
X = np.column_stack([
    np.ones(len(keys)),
    np.array([float(k[1]) for k in keys]),
    np.array([float(outcome_by_key[k]['control']) for k in keys]),
    np.array([exposure[k] for k in keys]),
])
Z = X.copy()
Z[:, 3] = np.array([instrument[k] for k in keys])
w = np.array([float(area_meta[(a, p, 'base')]['population']) for a, p in keys])

# Weighted 2SLS, with all exogenous regressors included as instruments.
# Weighted 2SLS from the weighted instrument projection matrix.
rootw = np.sqrt(w)
Zw = Z * rootw[:, None]
Xw = X * rootw[:, None]
yw = y * rootw
G = Zw.T @ Zw
B = Xw.T @ Zw @ np.linalg.solve(G, Zw.T @ Xw)
b = Xw.T @ Zw @ np.linalg.solve(G, Zw.T @ yw)
beta = np.linalg.solve(B, b)

# Independent equivalent calculation: weighted projection onto instrument space,
# then weighted least squares using the projected regressors.
rootw = np.sqrt(w)
Zw = Z * rootw[:, None]
Xw = X * rootw[:, None]
yw = y * rootw
PZXw = Zw @ np.linalg.solve(Zw.T @ Zw, Zw.T @ Xw)
beta_projected = np.linalg.lstsq(PZXw, yw, rcond=None)[0]

if len(keys) != 72:
    raise ValueError(f'Expected 72 area-period rows, got {len(keys)}')
if not np.allclose(beta, beta_projected, rtol=1e-9, atol=1e-9):
    raise ArithmeticError(f'Weighted 2SLS forms do not agree: {beta} vs {beta_projected}')

estimates = [
    {'term': 'iv_slope', 'estimate': float(beta[3]), 'se': None, 'n_obs': int(len(keys))},
    {'term': 'exposure_area0_period0', 'estimate': float(exposure[(0, 0)]), 'se': None, 'n_obs': int(len(keys))},
    {'term': 'exposure_area0_period1', 'estimate': float(exposure[(0, 1)]), 'se': None, 'n_obs': int(len(keys))},
    {'term': 'instrument_area0_period0', 'estimate': float(instrument[(0, 0)]), 'se': None, 'n_obs': int(len(keys))},
]
result = {
    'task_id': 'applied_multivintage_trade_iv',
    'platform': 'python',
    'estimates': estimates,
    'method_metadata': {
        'estimator': 'Weighted 2SLS',
        'outcome': 'change_pp',
        'regressors': ['intercept', 'period', 'control', 'x'],
        'instruments': ['intercept', 'period', 'control', 'z'],
        'weight': 'base-vintage population',
        'exposure_units': 'thousands of real dollars per worker per decade',
        'uncertainty': 'Not requested; se is null',
    },
    'diagnostics': {
        'n_obs': int(len(keys)),
        'n_areas': int(len(areas)),
        'n_periods': int(len(periods)),
        'n_industries': int(len(industries)),
        'weighted_2sls_identity_max_abs_diff': float(np.max(np.abs(beta - beta_projected))),
        'all_72_keys_unique': len(set(keys)) == 72,
        'industry_employment_denominators_positive': all(national[(p, v, i)] > 0 for p in periods for v in ['base', 'early'] for i in industries),
    },
}
with (ROOT / 'result.json').open('w') as f:
    json.dump(result, f, indent=2, allow_nan=False)

with (ROOT / 'verification.txt').open('w') as f:
    f.write('Verification checks for applied_multivintage_trade_iv\n')
    f.write(f'CSV dimensions: {len(crosswalk)} crosswalk codes, {len(trade_rows)} trade rows, {len(areas_rows)} area-vintage rows, {len(employment_rows)} employment rows, {len(outcomes_rows)} outcomes.\n')
    f.write(f'Estimation sample: {len(keys)} unique area-period rows ({len(areas)} areas x {len(periods)} periods), matching the task target of 72.\n')
    f.write('Construction: joined trade.code through crosswalk.code; omitted employment cells read as zero; national denominators summed across supplied areas by period, vintage, and industry.\n')
    f.write('Estimator: weighted 2SLS with population weights and instruments [intercept, period, control, z].\n')
    f.write(f'Independent numerical check: weighted IV moment equation and weighted projected-regressor least squares agree; maximum coefficient difference = {np.max(np.abs(beta-beta_projected)):.16g}.\n')
    f.write('Checks: all required national industry employment denominators are positive; each area-period key appears once.\n')
    for item in estimates:
        f.write(f"{item['term']} = {item['estimate']:.16g}\n")
