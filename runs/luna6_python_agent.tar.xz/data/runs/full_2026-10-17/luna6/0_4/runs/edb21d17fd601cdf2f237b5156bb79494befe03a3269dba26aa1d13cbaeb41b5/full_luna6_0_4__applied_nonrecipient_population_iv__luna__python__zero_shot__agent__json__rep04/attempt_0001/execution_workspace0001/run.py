import json
import numpy as np
import pandas as pd

# Read the task's two source files.
hh = pd.read_csv('households.csv')
census = pd.read_csv('census.csv')

# Retain every nonrecipient household, including both village treatment statuses.
d = hh.loc[hh['recipient'].eq(0)].copy()
e = d['eligible'].to_numpy(dtype=float)
ne = 1.0 - e
z = d['instrument'].to_numpy(dtype=float)
dose = d['dose'].to_numpy(dtype=float)
baseline = d['baseline'].to_numpy(dtype=float)
y = d['outcome'].to_numpy(dtype=float)
w = d['weight'].to_numpy(dtype=float)

# Weighted 2SLS: project the full structural regressor matrix on the stated
# instrument matrix using WLS, then estimate the structural equation by WLS.
X = np.column_stack([ne, e, baseline * ne, baseline * e,
                     dose * ne, dose * e])
Q = np.column_stack([ne, e, baseline * ne, baseline * e,
                     z * ne, z * e])
root_w = np.sqrt(w)
Qw = Q * root_w[:, None]
Xw = X * root_w[:, None]
yw = y * root_w
# QR least squares avoids explicit inversion of the first-stage normal matrix.
coef_first, *_ = np.linalg.lstsq(Qw, Xw, rcond=None)
Xhat_w = Qw @ coef_first
beta, *_ = np.linalg.lstsq(Xhat_w, yw, rcond=None)

n_obs = int(len(d))
# X columns 4 and 5 are the group-specific dose slopes.
weighted_mean_dose_ineligible = float(np.average(dose[e == 0], weights=w[e == 0]))
weighted_mean_dose_eligible = float(np.average(dose[e == 1], weights=w[e == 1]))
ineligible_effect = float(beta[4] * weighted_mean_dose_ineligible)
eligible_nonrecipient_effect = float(beta[5] * weighted_mean_dose_eligible)

# Census counts enter only as final between-group population weights.
pop = census.set_index('eligible')['nonrecipient_population']
pop0 = int(pop.loc[0])
pop1 = int(pop.loc[1])
population_effect = float((pop0 * ineligible_effect + pop1 * eligible_nonrecipient_effect) / (pop0 + pop1))

result = {
    'task_id': 'applied_nonrecipient_population_iv',
    'platform': 'python',
    'estimates': [
        {'term': 'ineligible_effect', 'estimate': ineligible_effect, 'se': None, 'n_obs': n_obs},
        {'term': 'eligible_nonrecipient_effect', 'estimate': eligible_nonrecipient_effect, 'se': None, 'n_obs': n_obs},
        {'term': 'population_effect', 'estimate': population_effect, 'se': None, 'n_obs': n_obs},
    ],
    'method_metadata': {
        'estimator': 'weighted 2SLS',
        'sample': 'all household rows with recipient=0',
        'endogenous_columns': ['dose*(1-eligible)', 'dose*eligible'],
        'exogenous_columns': ['1-eligible', 'eligible', 'baseline*(1-eligible)', 'baseline*eligible'],
        'instrument_columns': ['1-eligible', 'eligible', 'baseline*(1-eligible)', 'baseline*eligible', 'instrument*(1-eligible)', 'instrument*eligible'],
        'regression_weight': 'weight',
        'group_effect': 'fitted dose slope times household-weighted mean dose among retained observations in group',
        'counterfactual': 'dose set to zero for every retained household; attribution is a stated synthetic convention',
        'population_aggregation': 'census nonrecipient_population used only for final between-group weights',
        'group_dose_slopes': {'ineligible': float(beta[4]), 'eligible_nonrecipient': float(beta[5])},
        'group_weighted_mean_dose': {'ineligible': weighted_mean_dose_ineligible, 'eligible_nonrecipient': weighted_mean_dose_eligible},
        'census_counts': {'ineligible': pop0, 'eligible': pop1},
    },
    'diagnostics': {
        'n_obs': n_obs,
        'retained_nonrecipient_rows_by_eligible': {str(int(k)): int(v) for k, v in d.groupby('eligible').size().items()},
        'retained_treated_rows_by_treated_status': {str(int(k)): int(v) for k, v in d.groupby('treated').size().items()},
        'weight_sum_by_eligible': {str(int(k)): float(v) for k, v in d.groupby('eligible')['weight'].sum().items()},
        'weighted_2sls_rank': int(np.linalg.matrix_rank(Xhat_w)),
        'weighted_2sls_columns': int(X.shape[1]),
    },
}
with open('result.json', 'w') as f:
    json.dump(result, f, indent=2, allow_nan=False)
