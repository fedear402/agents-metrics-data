import json
import pandas as pd
from scipy import stats

DATA_PATH = "./input.csv"
OUTPUT_PATH = "./result.json"

df = pd.read_csv(DATA_PATH)
if not {"group", "y"}.issubset(df.columns):
    raise ValueError("input.csv must contain group and y columns")
data = df[["group", "y"]].dropna()
groups = [g["y"].to_numpy() for _, g in data.groupby("group", sort=True)]
if len(groups) < 2:
    raise ValueError("One-way ANOVA requires at least two groups")

f_stat, p_value = stats.f_oneway(*groups)
k = len(groups)
n = len(data)
df_num = k - 1
df_den = n - k
estimates = [
    {"term": "F", "estimate": float(f_stat), "se": None, "n_obs": int(n)},
    {"term": "df_num", "estimate": float(df_num), "se": None, "n_obs": int(n)},
    {"term": "df_den", "estimate": float(df_den), "se": None, "n_obs": int(n)},
    {"term": "p_value", "estimate": float(p_value), "se": None, "n_obs": int(n)},
]
result = {
    "task_id": "anova_oneway",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {"estimator": "classical one-way ANOVA", "vcov": "pooled within-group variance"},
    "diagnostics": {},
}
with open(OUTPUT_PATH, "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, allow_nan=False)
