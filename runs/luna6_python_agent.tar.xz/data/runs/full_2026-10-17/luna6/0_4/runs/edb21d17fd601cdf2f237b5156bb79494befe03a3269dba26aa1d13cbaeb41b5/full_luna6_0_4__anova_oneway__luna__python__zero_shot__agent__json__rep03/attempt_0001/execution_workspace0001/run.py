import json
import pandas as pd
from scipy.stats import f_oneway
import statsmodels.api as sm
from statsmodels.formula.api import ols

DATA_PATH = './input.csv'
RESULT_PATH = './result.json'

# Keep only the variables required by the stated one-way ANOVA.
data = pd.read_csv(DATA_PATH, usecols=['group', 'y'])
data = data.dropna(subset=['group', 'y'])
groups = [part['y'].to_numpy() for _, part in data.groupby('group', sort=True)]
if len(groups) < 2:
    raise ValueError('One-way ANOVA requires at least two observed groups.')

# Classical one-way ANOVA via the linear model; residuals use the pooled within-group variance.
model = ols('y ~ C(group)', data=data).fit()
table = sm.stats.anova_lm(model, typ=2)
row = table.loc['C(group)']
F = float(row['F'])
df_num = float(row['df'])
df_den = float(table.loc['Residual', 'df'])
p_value = float(row['PR(>F)'])
n_obs = int(len(data))

result = {
    'task_id': 'anova_oneway',
    'platform': 'python',
    'estimates': [
        {'term': 'F', 'estimate': F, 'se': None, 'n_obs': n_obs},
        {'term': 'df_num', 'estimate': df_num, 'se': None, 'n_obs': n_obs},
        {'term': 'df_den', 'estimate': df_den, 'se': None, 'n_obs': n_obs},
        {'term': 'p_value', 'estimate': p_value, 'se': None, 'n_obs': n_obs},
    ],
    'method_metadata': {
        'estimator': 'classical one-way ANOVA (OLS; pooled within-group variance)',
        'vcov': 'classical homoskedastic ANOVA; no separate covariance estimate',
    },
    'diagnostics': {},
}
with open(RESULT_PATH, 'w', encoding='utf-8') as f:
    json.dump(result, f, indent=2, allow_nan=False)
