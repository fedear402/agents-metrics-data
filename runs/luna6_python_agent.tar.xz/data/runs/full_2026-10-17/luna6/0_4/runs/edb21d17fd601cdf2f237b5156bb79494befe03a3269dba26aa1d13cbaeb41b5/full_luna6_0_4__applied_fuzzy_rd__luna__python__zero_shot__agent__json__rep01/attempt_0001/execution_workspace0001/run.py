import json
import numpy as np
import pandas as pd


def local_linear_discontinuity(x, y, w):
    """Fit side-specific weighted local linear regressions and return HC0 results."""
    right = (x >= 0).astype(float)
    # Separate intercepts and slopes: [left intercept, left slope,
    # right intercept, right slope].
    design = np.column_stack((1.0 - right, (1.0 - right) * x, right, right * x))
    sqrt_w = np.sqrt(w)
    xw = design * sqrt_w[:, None]
    yw = y * sqrt_w
    bread = np.linalg.inv(xw.T @ xw)
    beta = bread @ (xw.T @ yw)
    residual = y - design @ beta
    # HC0 sandwich for WLS with fixed analytic weights.
    scores = design * (w * residual)[:, None]
    covariance = bread @ (scores.T @ scores) @ bread
    # Right-limit minus left-limit, evaluated at score zero.
    contrast = np.array([-1.0, 0.0, 1.0, 0.0])
    return float(contrast @ beta), float(contrast @ covariance @ contrast), beta, covariance


def main():
    data = pd.read_csv("input.csv")
    sample = data.loc[data["score"].abs() < 1].copy()
    x = sample["score"].to_numpy(dtype=float)
    weights = 1.0 - np.abs(x)
    n_obs = int(len(sample))

    reduced_form, var_rf, beta_y, cov_y = local_linear_discontinuity(
        x, sample["earnings"].to_numpy(dtype=float), weights
    )
    first_stage, var_fs, beta_d, cov_d = local_linear_discontinuity(
        x, sample["participated"].to_numpy(dtype=float), weights
    )

    # With identical regressors and weights, the cross-equation HC0 covariance
    # is the sandwich using earnings residual times participation residual.
    right = (x >= 0).astype(float)
    design = np.column_stack((1.0 - right, (1.0 - right) * x, right, right * x))
    bread = np.linalg.inv((design * weights[:, None]).T @ design)
    ry = sample["earnings"].to_numpy(dtype=float) - design @ beta_y
    rd = sample["participated"].to_numpy(dtype=float) - design @ beta_d
    cross_scores = design * (weights**2 * ry * rd)[:, None]
    cov_cross = bread @ (design.T @ cross_scores) @ bread
    contrast = np.array([-1.0, 0.0, 1.0, 0.0])
    cov_rf_fs = float(contrast @ cov_cross @ contrast)

    treatment_effect = reduced_form / first_stage
    # Delta method for RF / FS, retaining covariance between estimates.
    var_te = (
        var_rf / first_stage**2
        + reduced_form**2 * var_fs / first_stage**4
        - 2.0 * reduced_form * cov_rf_fs / first_stage**3
    )
    se_te = float(np.sqrt(max(var_te, 0.0)))

    result = {
        "task_id": "applied_fuzzy_rd",
        "platform": "python",
        "estimates": [
            {"term": "treatment_effect", "estimate": treatment_effect, "se": se_te, "n_obs": n_obs},
            {"term": "reduced_form", "estimate": reduced_form, "se": float(np.sqrt(max(var_rf, 0.0))), "n_obs": n_obs},
            {"term": "first_stage", "estimate": first_stage, "se": float(np.sqrt(max(var_fs, 0.0))), "n_obs": n_obs},
        ],
        "method_metadata": {
            "estimator": "Fuzzy RD, separate weighted local-linear regressions, triangular kernel, bandwidth 1, cutoff 0",
            "vcov": "HC0 sandwich for weighted least squares; treatment effect delta method with joint cross-equation covariance; no degrees-of-freedom correction",
        },
        "diagnostics": {},
    }
    with open("result.json", "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2, allow_nan=False)
        f.write("\n")


if __name__ == "__main__":
    main()
