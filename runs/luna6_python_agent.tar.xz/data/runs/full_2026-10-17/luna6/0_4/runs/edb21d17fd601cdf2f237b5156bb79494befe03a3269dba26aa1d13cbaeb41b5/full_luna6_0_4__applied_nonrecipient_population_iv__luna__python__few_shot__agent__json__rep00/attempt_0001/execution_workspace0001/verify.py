import json
import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS

h = pd.read_csv('households.csv')
c = pd.read_csv('census.csv')
d = h.loc[h.recipient.eq(0)].copy()
assert len(d) == 300
assert d.groupby('eligible').size().to_dict() == {0: 120, 1: 180}
assert set(d.treated.unique()) == {0, 1}

# Independent weighted 2SLS identity: solve the weighted projection of Y
# onto [X, D] using the weighted instrument projection P_Z, Z=[X, Q].
d['g0'] = 1 - d.eligible
d['g1'] = d.eligible
X = np.column_stack([d.g0, d.g1, d.baseline*d.g0, d.baseline*d.g1])
D = np.column_stack([d.dose*d.g0, d.dose*d.g1])
Q = np.column_stack([d.instrument*d.g0, d.instrument*d.g1])
Z = np.column_stack([X, Q])
y = d.outcome.to_numpy()
w = d.weight.to_numpy()
sw = np.sqrt(w)
Zw, yw = Z*sw[:, None], y*sw
Dw, Xw = D*sw[:, None], X*sw[:, None]
# Weighted least squares projections by QR-backed least squares.
PZ_X = Zw @ np.linalg.lstsq(Zw, Xw, rcond=None)[0]
PZ_D = Zw @ np.linalg.lstsq(Zw, Dw, rcond=None)[0]
PZ_y = Zw @ np.linalg.lstsq(Zw, yw, rcond=None)[0]
A = np.column_stack([Xw, Dw])
PA = np.column_stack([PZ_X, PZ_D])
beta = np.linalg.solve(A.T @ PA, A.T @ PZ_y)
slopes_independent = beta[-2:]

out = json.load(open('result.json'))
reported_slopes = np.array([out['diagnostics']['group_slopes']['ineligible'], out['diagnostics']['group_slopes']['eligible']])
np.testing.assert_allclose(slopes_independent, reported_slopes, rtol=1e-11, atol=1e-11)

# Check group-effect and census-weight aggregation identities directly.
means = np.array([np.average(d.loc[d.eligible.eq(g), 'dose'], weights=d.loc[d.eligible.eq(g), 'weight']) for g in [0,1]])
effects = slopes_independent * means
np.testing.assert_allclose(effects, [x['estimate'] for x in out['estimates'][:2]], rtol=1e-11, atol=1e-11)
pops = c.sort_values('eligible').nonrecipient_population.to_numpy()
aggregate = float(np.average(effects, weights=pops))
np.testing.assert_allclose(aggregate, out['estimates'][2]['estimate'], rtol=1e-11, atol=1e-11)
assert all(x['n_obs'] == 300 and x['se'] is None for x in out['estimates'])
print({'independent_slopes': slopes_independent.tolist(), 'group_effects': effects.tolist(), 'population_effect': aggregate, 'n_obs': len(d)})
