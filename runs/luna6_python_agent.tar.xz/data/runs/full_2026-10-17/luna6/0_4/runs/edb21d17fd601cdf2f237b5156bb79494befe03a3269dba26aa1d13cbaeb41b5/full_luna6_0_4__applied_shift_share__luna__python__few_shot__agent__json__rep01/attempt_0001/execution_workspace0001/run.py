import json
import numpy as np
import pandas as pd


def weighted_shock_iv(dependent, endogenous, instrument, mass, shocks):
    """Weighted just-identified IV with an intercept and HC1 sandwich SE."""
    n = len(mass)
    regressors = np.column_stack((np.ones(n), endogenous))
    instruments = np.column_stack((np.ones(n), instrument))
    cross = instruments.T @ (mass[:, None] * regressors)
    beta = np.linalg.solve(cross, instruments.T @ (mass * dependent))
    residual = dependent - regressors @ beta
    scores = instruments * (mass * residual)[:, None]
    inverse = np.linalg.inv(cross)
    covariance = (n / (n - 2)) * inverse @ (scores.T @ scores) @ inverse.T
    return float(beta[1]), float(np.sqrt(covariance[1, 1]))


df = pd.read_csv("input.csv")
required = {"region_id", "industry_id", "share", "shock", "region_weight", "x", "y"}
if not required.issubset(df.columns):
    raise ValueError(f"Missing columns: {sorted(required - set(df.columns))}")

# Confirm region-level variables repeat consistently and industry shocks are constant.
for col in ["region_weight", "x", "y"]:
    if (df.groupby("region_id")[col].nunique() != 1).any():
        raise ValueError(f"{col} does not repeat consistently within region")
if (df.groupby("industry_id")["shock"].nunique() != 1).any():
    raise ValueError("shock is not constant within industry")

regions = df.drop_duplicates("region_id").set_index("region_id").sort_index()
industries = df.drop_duplicates("industry_id").set_index("industry_id").sort_index()
region_ids = regions.index
industry_ids = industries.index
R, N = len(region_ids), len(industry_ids)
if N <= 2:
    raise ValueError("HC1 multiplier requires more than two industries")

# Build a complete region-by-industry share matrix, with absent pairs set to zero.
share = df.pivot(index="region_id", columns="industry_id", values="share").reindex(index=region_ids, columns=industry_ids).fillna(0.0).to_numpy(float)
if not np.allclose(share.sum(axis=1), 1.0, rtol=1e-8, atol=1e-10):
    raise ValueError("Baseline shares do not sum to one within each region")
weights = regions["region_weight"].to_numpy(float)
e = weights / weights.sum()
shocks = industries.loc[industry_ids, "shock"].to_numpy(float)
x = regions["x"].to_numpy(float)
y = regions["y"].to_numpy(float)
z = share @ shocks

# Regional weighted 2SLS and first-stage slopes, with intercepts.
def regional_slope(dep, endog, instr):
    d = dep - e @ dep
    a = endog - e @ endog
    q = instr - e @ instr
    return float(np.sum(e * q * d) / np.sum(e * q * a))

effect_regional = regional_slope(y, x, z)
first_regional = regional_slope(x, z, z)

# Weighted demeaning precedes exposure aggregation.
y0 = y - e @ y
x0 = x - e @ x
z0 = z - e @ z
mass = e @ share
if np.any(mass <= 0):
    raise ValueError("Every included industry must have positive exposure mass")

def aggregate(v0):
    return (share.T @ (e * v0)) / mass

ybar, xbar, zbar = aggregate(y0), aggregate(x0), aggregate(z0)

# Shock-level IV estimates and structural-residual HC1 standard errors.
effect, effect_se = weighted_shock_iv(ybar, xbar, shocks, mass, shocks)
first_stage, first_se = weighted_shock_iv(xbar, zbar, shocks, mass, shocks)

# Independent checks: shock-level slopes must equal their regional counterparts.
if not np.allclose([effect, first_stage], [effect_regional, first_regional], rtol=1e-9, atol=1e-10):
    raise AssertionError("Shock-level and regional slopes do not match")
if not np.allclose(mass @ ybar, 0.0, atol=1e-10) or not np.allclose(mass @ xbar, 0.0, atol=1e-10) or not np.allclose(mass @ zbar, 0.0, atol=1e-10):
    raise AssertionError("Exposure-aggregated residuals are not weighted-centered")
effective_shocks = float(1.0 / np.sum(mass ** 2))

output = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": effect, "se": effect_se, "n_obs": N},
        {"term": "first_stage", "estimate": first_stage, "se": first_se, "n_obs": N},
        {"term": "effective_shocks", "estimate": effective_shocks, "se": None, "n_obs": N},
    ],
    "method_metadata": {
        "estimator": "weighted regional 2SLS with Borusyak-Hull-Jaravel shock-level IV aggregation",
        "vcov": "shock-level HC1 sandwich with analytic exposure weights and structural IV residuals",
    },
    "diagnostics": {},
}
with open("result.json", "w") as f:
    json.dump(output, f, indent=2, allow_nan=False)

print(f"regions={R}, industries={N}, region_industry_rows={len(df)}")
print(f"effect: regional={effect_regional:.12g}, shock={effect:.12g}, SE={effect_se:.12g}")
print(f"first_stage: regional={first_regional:.12g}, shock={first_stage:.12g}, SE={first_se:.12g}")
print(f"effective_shocks={effective_shocks:.12g}")
