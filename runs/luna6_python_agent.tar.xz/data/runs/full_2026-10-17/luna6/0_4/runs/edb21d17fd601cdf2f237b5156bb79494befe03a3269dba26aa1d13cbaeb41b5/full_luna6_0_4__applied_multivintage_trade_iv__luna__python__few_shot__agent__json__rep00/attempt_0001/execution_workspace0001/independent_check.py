# Independent checks using explicit arrays and the weighted Frisch-Waugh-Lovell identity.
import numpy as np
import pandas as pd

cw = pd.read_csv('crosswalk.csv').set_index('code')['industry'].to_dict()
tr = pd.read_csv('trade.csv')
ar = pd.read_csv('areas.csv')
em = pd.read_csv('employment.csv')
out = pd.read_csv('outcomes.csv')
periods = sorted(ar.period.unique())
areas = sorted(ar.area.unique())
industries = sorted(set(cw.values()))
E = {(r.area, r.period, r.vintage, r.industry): r.employment for r in em.itertuples()}
T = {(r.area,r.period,r.vintage): r.total_employment for r in ar.itertuples()}
P = {(r.area,r.period):r.population for r in ar[ar.vintage.eq('base')].itertuples()}
trd = {(r.period,cw[r.code]):r for r in tr.itertuples()}
values = {}
for period in periods:
    for vintage in ('base','early'):
        nat = {j:sum(E.get((a,period,vintage,j),0.0) for a in areas) for j in industries}
        assert all(v > 0 for v in nat.values())
        for area in areas:
            total = T[(area,period,vintage)]
            xx = zz = 0.0
            for j in industries:
                row = trd[(period,j)]
                emp = E.get((area,period,vintage,j),0.0)
                factor = emp / nat[j] / (row.price_index / 100) / 1000 * (10 / row.years)
                xx += factor * row.us_change
                zz += factor * row.other_change
            values[(area,period,vintage)] = (xx,zz)

# Explicit weighted residualization on intercept, period, and control.
d = out.merge(ar[ar.vintage.eq('base')][['area','period','population']],on=['area','period'],validate='one_to_one')
d['x'] = [values[(a,p,'base')][0] for a,p in zip(d.area,d.period)]
d['z'] = [values[(a,p,'early')][1] for a,p in zip(d.area,d.period)]
y=d.change_pp.to_numpy(); x=d.x.to_numpy(); z=d.z.to_numpy(); w=d.population.to_numpy()
A=np.column_stack([np.ones(len(d)),d.period.to_numpy(),d.control.to_numpy()])
def residualize(v):
    coef=np.linalg.solve(A.T@(w[:,None]*A), A.T@(w*v))
    return v-A@coef
xr,zr,yr=residualize(x),residualize(z),residualize(y)
beta_fwl=np.sum(w*zr*yr)/np.sum(w*zr*xr)
assert len(d)==72
assert np.isclose(beta_fwl,-0.0004172344398156243,rtol=1e-12,atol=1e-15)
assert np.isclose(values[(0,0,'base')][0],54218.44414076932,rtol=1e-12)
assert np.isclose(values[(0,1,'base')][0],79004.6557106687,rtol=1e-12)
assert np.isclose(values[(0,0,'early')][1],45036.23173098189,rtol=1e-12)
print({'n_obs':len(d),'area0_p0_x':values[(0,0,'base')][0], 'area0_p1_x':values[(0,1,'base')][0], 'area0_p0_z':values[(0,0,'early')][1], 'iv_slope_fwl':beta_fwl})
