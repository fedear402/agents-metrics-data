import json
import numpy as np
import pandas as pd
from statsmodels.tsa.arima.model import ARIMA

# Read the ordered level series and check the forecast target index.
df = pd.read_csv("./input.csv")
if list(df.columns) != ["t", "y"]:
    raise ValueError("Expected columns t and y")
df = df.sort_values("t").reset_index(drop=True)
y = pd.to_numeric(df["y"], errors="raise").astype(float)
if not np.array_equal(df["t"].to_numpy(), np.arange(1, len(df) + 1)):
    raise ValueError("t must be consecutive and start at 1")
if len(y) != 250:
    raise ValueError(f"Expected 250 observations to forecast t=251; found {len(y)}")

# ARIMA(1,1,1) without a level constant or drift.
fit = ARIMA(y, order=(1, 1, 1), trend="n").fit()
fc = fit.get_forecast(steps=1)
mean = float(np.asarray(fc.predicted_mean)[0])
ci = np.asarray(fc.conf_int(alpha=0.05), dtype=float)[0]
lo, hi = float(ci[0]), float(ci[1])
n = int(fit.nobs)

out = {
    "task_id": "arima_forecast",
    "platform": "python",
    "estimates": [
        {"term": "forecast", "estimate": mean, "se": float(np.asarray(fc.se_mean)[0]), "n_obs": n},
        {"term": "lower_95", "estimate": lo, "se": None, "n_obs": n},
        {"term": "upper_95", "estimate": hi, "se": None, "n_obs": n},
    ],
    "method_metadata": {"estimator": "ARIMA(1,1,1) maximum likelihood, no constant or drift", "vcov": "model-based forecast variance"},
    "diagnostics": {},
}
with open("result.json", "w") as f:
    json.dump(out, f, indent=2)
