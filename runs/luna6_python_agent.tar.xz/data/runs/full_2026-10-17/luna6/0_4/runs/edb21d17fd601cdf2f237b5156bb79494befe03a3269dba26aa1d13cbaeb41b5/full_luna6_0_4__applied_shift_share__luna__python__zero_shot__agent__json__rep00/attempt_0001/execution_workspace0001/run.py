import json
import numpy as np
import pandas as pd


def weighted_mean(x, w):
    return np.sum(w * x) / np.sum(w)


def shock_level_iv(y, x, q, weight):
    """Weighted just-identified IV, with structural HC1 variance."""
    y = np.asarray(y, dtype=float)
    x = np.asarray(x, dtype=float)
    q = np.asarray(q, dtype=float)
    w = np.asarray(weight, dtype=float)
    n = len(y)
    # Weighted intercept projection followed by IV slope from the centered moments.
    xm = weighted_mean(x, w)
    ym = weighted_mean(y, w)
    qm = weighted_mean(q, w)
    xc, yc, qc = x - xm, y - ym, q - qm
    denom = np.sum(w * qc * xc)
    beta = np.sum(w * qc * yc) / denom
    alpha = ym - beta * xm
    resid = y - alpha - beta * x
    # HC1 sandwich: (X'WZ (Z'WZ)^-1 Z'WX)^-1 ... using instrument matrix [1,q].
    Z = np.column_stack([np.ones(n), q])
    X = np.column_stack([np.ones(n), x])
    bread_core = Z.T @ (w[:, None] * X)
    # just-identified IV meat computed from observation score z_i*w_i*u_i
    # sandwich covariance = A^-1 [sum w_i^2 u_i^2 z_i z_i'] A^-T,
    # where A = Z' W X. Analytic weights as specified.
    meat = Z.T @ ((w * resid)[:, None] ** 2 * Z)
    invA = np.linalg.inv(bread_core)
    cov = invA @ meat @ invA.T * (n / (n - 2))
    return float(beta), float(np.sqrt(cov[1, 1])), resid


df = pd.read_csv('input.csv')
required = {'region_id', 'industry_id', 'share', 'shock', 'region_weight', 'x', 'y'}
if set(df.columns) != required:
    raise ValueError(f'Unexpected columns: {df.columns.tolist()}')

# Validate region-level repeated fields and industry-level shocks.
for c in ['region_weight', 'x', 'y']:
    if df.groupby('region_id')[c].nunique(dropna=False).max() != 1:
        raise ValueError(f'{c} is not constant within region')
if df.groupby('industry_id')['shock'].nunique(dropna=False).max() != 1:
    raise ValueError('shock is not constant within industry')

regions = df.drop_duplicates('region_id').set_index('region_id').sort_index()
weights = regions['region_weight'].astype(float)
e = weights / weights.sum()
R = regions.index

# Include all observed region-industry pairs and aggregate exposures by industry.
p = df.copy()
p['e'] = p['region_id'].map(e)
p['ewshare'] = p['e'] * p['share']
# Regional shift-share instrument.
z = p.assign(contrib=p['share'] * p['shock']).groupby('region_id')['contrib'].sum().reindex(R)
reg = regions[['x', 'y']].astype(float).copy()
reg['z'] = z.astype(float)
# Weighted demeaning of all three regional variables.
means = {c: weighted_mean(reg[c].to_numpy(), e.reindex(R).to_numpy()) for c in ['y', 'x', 'z']}
for c in ['y', 'x', 'z']:
    reg[c + '0'] = reg[c] - means[c]

# Aggregate weighted exposure and demeaned regional variables to industries.
industry = p.groupby('industry_id').agg(
    s=('ewshare', 'sum'),
    shock=('shock', 'first'),
).sort_index()
for c in ['y', 'x', 'z']:
    numer = p.assign(v=p['ewshare'] * p['region_id'].map(reg[c + '0'])).groupby('industry_id')['v'].sum()
    industry[c + 'bar'] = numer.reindex(industry.index) / industry['s']
if (industry['s'] <= 0).any() or industry[['ybar', 'xbar', 'zbar', 'shock']].isna().any().any():
    raise ValueError('Invalid industry aggregation')

N = len(industry)
if N <= 2:
    raise ValueError('At least three industries are required for HC1')

# Regional 2SLS slope and exposure-robust shock-level HC1 uncertainty.
effect, effect_se, _ = shock_level_iv(industry['ybar'], industry['xbar'], industry['shock'], industry['s'])
# First stage: regional x on z. Equivalent shock-level IV uses zbar as endogenous,
# instrumented by shock, and xbar as the outcome.
first_stage, first_stage_se, _ = shock_level_iv(industry['xbar'], industry['zbar'], industry['shock'], industry['s'])
effective_shocks = 1.0 / np.sum(industry['s'].to_numpy() ** 2)

# Independent numerical checks: fit regional weighted 2SLS using explicit matrix algebra,
# and verify both slopes equal their shock-level counterparts.
reg_w = e.reindex(R).to_numpy()
X = np.column_stack([np.ones(len(R)), reg['x'].to_numpy()])
Z = np.column_stack([np.ones(len(R)), reg['z'].to_numpy()])
Y = reg['y'].to_numpy()
A = Z.T @ (reg_w[:, None] * X)
regional_beta = np.linalg.solve(A, Z.T @ (reg_w * Y))[1]
Xfs = np.column_stack([np.ones(len(R)), reg['z'].to_numpy()])
regional_fs = np.linalg.solve(Xfs.T @ (reg_w[:, None] * Xfs), Xfs.T @ (reg_w * reg['x'].to_numpy()))[1]
if not np.isclose(effect, regional_beta, rtol=1e-9, atol=1e-10):
    raise AssertionError(f'Effect identity failed: shock={effect}, regional={regional_beta}')
if not np.isclose(first_stage, regional_fs, rtol=1e-9, atol=1e-10):
    raise AssertionError(f'First-stage identity failed: shock={first_stage}, regional={regional_fs}')
if not np.isclose(industry['s'].sum(), 1.0, rtol=1e-10, atol=1e-10):
    raise AssertionError('Industry exposure weights do not sum to one')

result = {
    'task_id': 'applied_shift_share',
    'platform': 'python',
    'estimates': [
        {'term': 'effect', 'estimate': effect, 'se': effect_se, 'n_obs': int(N)},
        {'term': 'first_stage', 'estimate': first_stage, 'se': first_stage_se, 'n_obs': int(N)},
        {'term': 'effective_shocks', 'estimate': float(effective_shocks), 'se': None, 'n_obs': int(N)},
    ],
    'method_metadata': {
        'estimator': 'weighted 2SLS with regional exposure construction and shock-level aggregation',
        'vcov': 'shock-level heteroskedastic-robust HC1, structural IV residuals, analytic weights, no clustering; multiplier N/(N-2)',
    },
    'diagnostics': {},
}
with open('result.json', 'w') as f:
    json.dump(result, f, indent=2, allow_nan=False)

# Save concise check evidence for review.
with open('verification.txt', 'w') as f:
    f.write(f'Regions: {len(R)}; region-industry rows: {len(df)}; industries: {N}.\n')
    f.write(f'Regional weights normalized once from one row per region; sum(e)={e.sum():.16g}.\n')
    f.write(f'Baseline shares checked by aggregation; weighted industry exposure sum(s)={industry["s"].sum():.16g}.\n')
    f.write(f'All region repeats and industry-constant shocks checked.\n')
    f.write(f'Independent matrix 2SLS effect={regional_beta:.12g}; shock-level effect={effect:.12g}; difference={effect-regional_beta:.3g}.\n')
    f.write(f'Independent regional WLS first stage={regional_fs:.12g}; shock-level IV first stage={first_stage:.12g}; difference={first_stage-regional_fs:.3g}.\n')
    f.write(f'HC1 standard errors use structural IV residuals and multiplier {N}/({N}-2)={N/(N-2):.12g}.\n')
