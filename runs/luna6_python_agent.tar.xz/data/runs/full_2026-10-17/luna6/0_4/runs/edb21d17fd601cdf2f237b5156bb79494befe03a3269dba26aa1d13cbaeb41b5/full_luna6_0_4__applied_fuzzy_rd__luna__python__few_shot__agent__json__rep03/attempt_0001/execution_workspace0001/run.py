import json

import numpy as np
import pandas as pd


TASK_ID = "applied_fuzzy_rd"


def main():
    data = pd.read_csv("input.csv")
    sample = data.loc[data["score"].abs() < 1].copy()
    x = sample["score"].to_numpy(dtype=float)
    right = (x >= 0).astype(float)
    weights = 1.0 - np.abs(x)

    # Separate local-linear intercepts and slopes on the two sides.
    design = np.column_stack(
        [1.0 - right, (1.0 - right) * x, right, right * x]
    )
    outcomes = sample[["earnings", "participated"]].to_numpy(dtype=float)
    bread = np.linalg.inv(design.T @ (weights[:, None] * design))
    beta = bread @ design.T @ (weights[:, None] * outcomes)
    residuals = outcomes - design @ beta

    # The intercept contrast is right limit minus left limit.
    contrast = np.array([-1.0, 0.0, 1.0, 0.0])
    jumps = contrast @ beta
    loading = weights * (design @ bread @ contrast)
    influence = loading[:, None] * residuals
    joint_covariance = influence.T @ influence

    reduced_form, first_stage = jumps
    treatment_effect = reduced_form / first_stage
    gradient = np.array([1.0 / first_stage, -reduced_form / first_stage**2])
    treatment_variance = gradient @ joint_covariance @ gradient

    rows = [
        {
            "term": "treatment_effect",
            "estimate": float(treatment_effect),
            "se": float(np.sqrt(treatment_variance)),
            "n_obs": int(len(sample)),
        },
        {
            "term": "reduced_form",
            "estimate": float(reduced_form),
            "se": float(np.sqrt(joint_covariance[0, 0])),
            "n_obs": int(len(sample)),
        },
        {
            "term": "first_stage",
            "estimate": float(first_stage),
            "se": float(np.sqrt(joint_covariance[1, 1])),
            "n_obs": int(len(sample)),
        },
    ]
    output = {
        "task_id": TASK_ID,
        "platform": "python",
        "estimates": rows,
        "method_metadata": {
            "estimator": "triangular-weighted local-linear fuzzy regression discontinuity",
            "vcov": "joint HC0 sandwich; fixed bandwidth and weights; no degrees-of-freedom correction",
        },
        "diagnostics": {},
    }
    with open("result.json", "w") as stream:
        json.dump(output, stream, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
