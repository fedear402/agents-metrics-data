import json
import numpy as np
import pandas as pd

INPUT = "input.csv"
OUTPUT = "result.json"

def weighted_mean(values, weights):
    return float(np.sum(weights * values) / np.sum(weights))

def weighted_iv_hc1(y, x, q, instrument, weights):
    """One endogenous regressor, intercept, one excluded instrument; analytic weights."""
    y = np.asarray(y, dtype=float)
    x = np.asarray(x, dtype=float)
    q = np.asarray(q, dtype=float)
    inst = np.asarray(instrument, dtype=float)
    w = np.asarray(weights, dtype=float)
    n = len(y)
    # X includes intercept and endogenous regressor; Z includes intercept and instrument.
    X = np.column_stack((np.ones(n), x))
    Z = np.column_stack((np.ones(n), inst))
    WZ = Z * w[:, None]
    middle = Z.T @ WZ
    cross = X.T @ WZ
    A = cross @ np.linalg.solve(middle, cross.T)
    beta = np.linalg.solve(A, cross @ np.linalg.solve(middle, Z.T @ (w * y)))
    resid = y - X @ beta
    # HC1 sandwich, using analytic weights: meat = sum_i w_i^2 z_i z_i' u_i^2.
    bread = np.linalg.inv(A)
    score = (w * resid)[:, None] * Z
    meat = cross @ np.linalg.solve(middle, score.T @ score) @ cross.T
    cov = bread @ meat @ bread
    cov *= n / (n - 2)
    return beta, cov, resid

def main():
    df = pd.read_csv(INPUT)
    required = {"region_id", "industry_id", "share", "shock", "region_weight", "x", "y"}
    if set(df.columns) != required:
        raise ValueError(f"Unexpected columns: {list(df.columns)}")
    if df.duplicated(["region_id", "industry_id"]).any():
        raise ValueError("Duplicate region-industry rows")

    # One observation per region defines normalized regional weights and regional data.
    regions = df.groupby("region_id", sort=False).agg(
        region_weight=("region_weight", "first"), x=("x", "first"), y=("y", "first")
    )
    for col in ("region_weight", "x", "y"):
        if (df.groupby("region_id")[col].nunique() > 1).any():
            raise ValueError(f"{col} varies within region")
    e = regions.region_weight.to_numpy(dtype=float, copy=True)
    e /= e.sum()
    regions = regions.copy()
    regions["e"] = e

    # Shares and shocks are attached to each regional industry row.
    if (df.groupby("region_id").share.sum().sub(1).abs() > 1e-8).any():
        raise ValueError("Baseline shares do not sum to one within each region")
    if (df.groupby("industry_id").shock.nunique() > 1).any():
        raise ValueError("Shock varies within industry")
    df = df.join(regions["e"], on="region_id")
    z_by_region = df.assign(exposure=df.share * df.shock).groupby("region_id").exposure.sum()
    regions["z"] = z_by_region
    r = regions.reset_index()
    w = r.e.to_numpy()

    # Regional weighted IV effect: instrument x with shift-share z.
    regional_beta, _, _ = weighted_iv_hc1(r.y, r.x, r.x, r.z, w)
    # Center each regional variable using normalized e weights.
    centered = {}
    for v in ("y", "x", "z"):
        centered[v] = r[v].to_numpy() - weighted_mean(r[v].to_numpy(), w)

    # Shock-level aggregates and analytic weights s_n.
    work = df[["industry_id", "shock", "share", "e", "region_id"]].copy()
    work = work.merge(r[["region_id", "x", "y", "z"]], on="region_id", validate="many_to_one")
    work["x0"] = work.x.to_numpy() - weighted_mean(r.x.to_numpy(), w)
    work["y0"] = work.y.to_numpy() - weighted_mean(r.y.to_numpy(), w)
    work["z0"] = work.z.to_numpy() - weighted_mean(r.z.to_numpy(), w)
    work["es"] = work.e * work.share
    work["esx"] = work.es * work.x0
    work["esy"] = work.es * work.y0
    work["esz"] = work.es * work.z0
    agg = work.groupby("industry_id", sort=True).agg(
        s=("es", "sum"), shock=("shock", "first"), sx=("esx", "sum"), sy=("esy", "sum"), sz=("esz", "sum")
    )
    if (agg.s <= 0).any():
        raise ValueError("Industry with nonpositive exposure weight")
    agg["xbar"] = agg.sx / agg.s
    agg["ybar"] = agg.sy / agg.s
    agg["zbar"] = agg.sz / agg.s
    N = len(agg)

    effect_beta, effect_cov, _ = weighted_iv_hc1(
        agg.ybar, agg.xbar, agg.xbar, agg.shock, agg.s
    )
    first_beta, first_cov, _ = weighted_iv_hc1(
        agg.xbar, agg.zbar, agg.zbar, agg.shock, agg.s
    )
    effective = float(1.0 / np.sum(agg.s.to_numpy() ** 2))

    # Regional 2SLS slope identity check, using weighted centered scalar moments.
    z = r.z.to_numpy(); x = r.x.to_numpy(); y = r.y.to_numpy()
    x0 = x - np.sum(w*x); y0 = y - np.sum(w*y); z0 = z - np.sum(w*z)
    regional_slope_moment = float(np.sum(w*z0*y0) / np.sum(w*z0*x0))
    first_regional_slope = float(np.sum(w*z0*x0) / np.sum(w*z0*z0))
    if not np.isclose(effect_beta[1], regional_slope_moment, rtol=1e-9, atol=1e-10):
        raise AssertionError("Shock-level effect does not equal regional weighted 2SLS")
    if not np.isclose(first_beta[1], first_regional_slope, rtol=1e-9, atol=1e-10):
        raise AssertionError("Shock-level first stage does not equal regional first stage")
    if not np.isclose(regional_beta[1], effect_beta[1], rtol=1e-9, atol=1e-10):
        raise AssertionError("Direct regional IV and shock-level IV differ")

    estimates = [
        {"term": "effect", "estimate": float(effect_beta[1]), "se": float(np.sqrt(effect_cov[1,1])), "n_obs": N},
        {"term": "first_stage", "estimate": float(first_beta[1]), "se": float(np.sqrt(first_cov[1,1])), "n_obs": N},
        {"term": "effective_shocks", "estimate": effective, "se": None, "n_obs": N},
    ]
    result = {
        "task_id": "applied_shift_share",
        "platform": "python",
        "estimates": estimates,
        "method_metadata": {
            "estimator": "weighted 2SLS with shock-level exposure aggregation; analytic weights s_n",
            "vcov": "shock-level heteroskedasticity-robust HC1, no clustering; N/(N-2) multiplier",
        },
        "diagnostics": {},
    }
    with open(OUTPUT, "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2, allow_nan=False)

    with open("verification.txt", "w", encoding="utf-8") as f:
        f.write(f"Input rows: {len(df)}; regions: {len(r)}; industries: {N}.\n")
        f.write(f"Regional weights normalized once per region; sum(e)={w.sum():.16g}.\n")
        f.write(f"Maximum absolute deviation of regional shares from one: {df.groupby('region_id').share.sum().sub(1).abs().max():.3g}.\n")
        f.write(f"Industry shock constancy and within-region repetition checks passed.\n")
        f.write(f"Independent identity: regional weighted IV moment slope={regional_slope_moment:.12g}; shock-level IV slope={effect_beta[1]:.12g}; absolute difference={abs(regional_slope_moment-effect_beta[1]):.3g}.\n")
        f.write(f"First-stage identity: regional weighted slope={first_regional_slope:.12g}; shock-level IV slope={first_beta[1]:.12g}; absolute difference={abs(first_regional_slope-first_beta[1]):.3g}.\n")
        f.write(f"HC1 multiplier: {N}/({N}-2)={N/(N-2):.12g}; effect SE={np.sqrt(effect_cov[1,1]):.12g}; first-stage SE={np.sqrt(first_cov[1,1]):.12g}.\n")
        f.write(f"Effective shocks: 1/sum(s_n^2)={effective:.12g}; sum(s_n)={agg.s.sum():.16g}.\n")

if __name__ == "__main__":
    main()
