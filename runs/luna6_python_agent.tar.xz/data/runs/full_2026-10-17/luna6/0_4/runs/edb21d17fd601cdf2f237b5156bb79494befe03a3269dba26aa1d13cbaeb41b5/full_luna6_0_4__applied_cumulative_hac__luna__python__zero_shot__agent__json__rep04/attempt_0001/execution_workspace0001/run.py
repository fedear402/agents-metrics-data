import json
import numpy as np
import pandas as pd
import statsmodels.api as sm


def main():
    df = pd.read_csv('input.csv', parse_dates=['date']).sort_values('date').reset_index(drop=True)
    df['dlog_vix'] = np.log(df['vix']).diff()
    df['log_sales'] = np.log(df['sales'])
    lag_names = []
    for j in range(1, 16):
        name = f'lag_{j}'
        df[name] = df['dlog_vix'].shift(j)
        lag_names.append(name)
    sample = df.dropna(subset=['log_sales'] + lag_names)
    X = sm.add_constant(sample[lag_names], has_constant='add')
    y = sample['log_sales']
    fit = sm.OLS(y, X).fit()
    n = len(sample)
    # Bartlett Newey-West HAC, max lag 15, finite-sample multiplier specified by task.
    hac_cov = np.asarray(sm.stats.sandwich_covariance.cov_hac(fit, nlags=15, use_correction=False))
    hac_cov *= n / (n - 16)
    beta = np.asarray(fit.params)
    names = list(X.columns)
    idx = {name: names.index(name) for name in names}
    w = np.zeros(len(names))
    for name in lag_names:
        w[idx[name]] = 1.0
    estimates = [
        ('cumulative_response', float(w @ beta), float(np.sqrt(w @ hac_cov @ w))),
        ('lag_1', float(beta[idx['lag_1']]), float(np.sqrt(hac_cov[idx['lag_1'], idx['lag_1']]))),
        ('lag_15', float(beta[idx['lag_15']]), float(np.sqrt(hac_cov[idx['lag_15'], idx['lag_15']]))),
    ]
    payload = {
        'task_id': 'applied_cumulative_hac',
        'platform': 'python',
        'estimates': [{'term': term, 'estimate': est, 'se': se, 'n_obs': int(n)} for term, est, se in estimates],
        'method_metadata': {
            'estimator': 'OLS of log(sales) on intercept and trading-observation lags 1-15 of first difference of log(vix)',
            'vcov': 'Newey-West HAC, Bartlett weights, maximum lag 15, multiplied by N/(N-16)',
        },
        'diagnostics': {},
    }
    with open('result.json', 'w') as f:
        json.dump(payload, f, indent=2, allow_nan=False)


if __name__ == '__main__':
    main()
