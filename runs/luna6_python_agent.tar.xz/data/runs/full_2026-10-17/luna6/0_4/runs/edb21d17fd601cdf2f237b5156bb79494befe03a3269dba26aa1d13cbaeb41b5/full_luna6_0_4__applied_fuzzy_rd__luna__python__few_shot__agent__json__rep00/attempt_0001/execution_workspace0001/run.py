import json
import numpy as np
import pandas as pd

TASK_ID = "applied_fuzzy_rd"

df = pd.read_csv("input.csv")
sample = df.loc[df["score"].abs() < 1].copy()
n = len(sample)
s = sample["score"].to_numpy(dtype=float)
y = sample[["earnings", "participated"]].to_numpy(dtype=float)
w = 1.0 - np.abs(s)
right = (s >= 0).astype(float)
# Common local-linear design: intercept and centered score on each side.
X = np.column_stack([1.0 - right, (1.0 - right) * s, right, right * s])
# Solve the weighted normal equations for the two outcome regressions.
xtwx = X.T @ (w[:, None] * X)
bread = np.linalg.inv(xtwx)
beta = bread @ (X.T @ (w[:, None] * y))
resid = y - X @ beta
# Right-limit minus left-limit is the difference of side intercepts.
c = np.array([-1.0, 0.0, 1.0, 0.0])
disc = c @ beta
# HC0 sandwich, with analytic weights treated as fixed in WLS.
# Form coefficient-influence contributions separately for each outcome.
# Each row has four design elements and two outcome residuals.
loading = w * (X @ bread @ c)
influence = loading[:, None] * resid
joint = influence.T @ influence
rf, fs = disc
ratio = rf / fs
grad = np.array([1.0 / fs, -rf / (fs * fs)])
ratio_var = float(grad @ joint @ grad)
if ratio_var < 0 and ratio_var > -1e-12:
    ratio_var = 0.0
rows = [
    {"term": "treatment_effect", "estimate": float(ratio), "se": float(np.sqrt(ratio_var)), "n_obs": int(n)},
    {"term": "reduced_form", "estimate": float(rf), "se": float(np.sqrt(joint[0, 0])), "n_obs": int(n)},
    {"term": "first_stage", "estimate": float(fs), "se": float(np.sqrt(joint[1, 1])), "n_obs": int(n)},
]
output = {
    "task_id": TASK_ID,
    "platform": "python",
    "estimates": rows,
    "method_metadata": {"estimator": "triangular-weighted local-linear fuzzy RD; separate slopes by side", "vcov": "HC0 sandwich, fixed weights, no degrees-of-freedom correction; joint delta method"},
    "diagnostics": {},
}
with open("result.json", "w") as f:
    json.dump(output, f, indent=2, allow_nan=False)
