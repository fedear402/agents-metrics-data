import json
import numpy as np
import pandas as pd
import statsmodels.api as sm


def main():
    df = pd.read_csv('input.csv', parse_dates=['date']).sort_values('date').reset_index(drop=True)
    dlog_vix = np.log(df['vix']).diff()
    y = np.log(df['sales'])
    design = pd.DataFrame({'lag_' + str(k): dlog_vix.shift(k) for k in range(1, 16)})
    design.insert(0, 'const', 1.0)
    sample = pd.concat([y.rename('log_sales'), design], axis=1).dropna()
    y_sample = sample.pop('log_sales')
    X = sample
    fit = sm.OLS(y_sample, X).fit()
    n = len(sample)
    # Bartlett Newey-West meat with max lag 15, then finite-sample multiplier.
    resid = np.asarray(fit.resid)
    x = np.asarray(X)
    score = x * resid[:, None]
    meat = score.T @ score
    for j in range(1, 16):
        gamma = score[j:].T @ score[:-j]
        meat += (1 - j / 16) * (gamma + gamma.T)
    bread = np.linalg.inv(x.T @ x)
    cov = bread @ meat @ bread * (n / (n - 16))
    params = np.asarray(fit.params)
    ix = {name: i for i, name in enumerate(X.columns)}
    weights = np.zeros(len(params))
    for j in range(1, 16):
        weights[ix[f'lag_{j}']] = 1
    rows = []
    for term, est, w in [
        ('cumulative_response', float(weights @ params), weights),
        ('lag_1', float(params[ix['lag_1']]), np.eye(len(params))[ix['lag_1']]),
        ('lag_15', float(params[ix['lag_15']]), np.eye(len(params))[ix['lag_15']]),
    ]:
        se = float(np.sqrt(w @ cov @ w))
        rows.append({'term': term, 'estimate': est, 'se': se, 'n_obs': n})
    result = {
        'task_id': 'applied_cumulative_hac',
        'platform': 'python',
        'estimates': rows,
        'method_metadata': {
            'estimator': 'OLS of log(sales) on intercept and trading-observation lags 1-15 of first-differenced log(vix)',
            'vcov': 'Newey-West HAC, Bartlett max lag 15, finite-sample multiplier N/(N-16)',
        },
        'diagnostics': {},
    }
    with open('result.json', 'w') as f:
        json.dump(result, f, indent=2, allow_nan=False)


if __name__ == '__main__':
    main()
