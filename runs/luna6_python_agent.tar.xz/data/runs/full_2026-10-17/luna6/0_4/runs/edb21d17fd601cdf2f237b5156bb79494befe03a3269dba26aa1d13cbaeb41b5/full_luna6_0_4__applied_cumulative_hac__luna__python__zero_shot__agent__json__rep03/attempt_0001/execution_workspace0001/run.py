import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

INPUT = 'input.csv'
OUTPUT = 'result.json'

df = pd.read_csv(INPUT, parse_dates=['date']).sort_values('date').reset_index(drop=True)
assert list(df.columns) == ['date', 'sales', 'vix']
assert (df[['sales', 'vix']] > 0).all().all()
dv = np.log(df['vix']).diff()
y = np.log(df['sales'])
X = pd.DataFrame({f'lag_{j}': dv.shift(j) for j in range(1, 16)})
reg = pd.concat([y.rename('log_sales'), X], axis=1).dropna()
Y = reg['log_sales'].to_numpy()
Xm = sm.add_constant(reg.drop(columns='log_sales').to_numpy())
n = len(Y)
fit = sm.OLS(Y, Xm).fit()

# Bartlett Newey-West covariance, explicitly calculated from OLS score vectors.
u = fit.resid
scores = Xm * u[:, None]
meat = scores.T @ scores
for j in range(1, 16):
    gamma = scores[j:].T @ scores[:-j]
    weight = 1.0 - j / 16.0
    meat += weight * (gamma + gamma.T)
bread = np.linalg.inv(Xm.T @ Xm)
vcov_manual = bread @ meat @ bread * (n / (n - 16))

# Independent central check: statsmodels HAC with the same maximum lag, kernel,
# and finite-sample correction. Compare the full covariance matrices.
hac = fit.get_robustcov_results(cov_type='HAC', maxlags=15, kernel='bartlett', use_correction=True)
vcov_sm = hac.cov_params()
assert np.allclose(vcov_manual, vcov_sm, rtol=1e-9, atol=1e-12)

beta = fit.params
V = vcov_manual
cum_vector = np.r_[0.0, np.ones(15)]
items = [
    ('cumulative_response', float(cum_vector @ beta), float(np.sqrt(cum_vector @ V @ cum_vector))),
    ('lag_1', float(beta[1]), float(np.sqrt(V[1, 1]))),
    ('lag_15', float(beta[15]), float(np.sqrt(V[15, 15]))),
]
result = {
    'task_id': 'applied_cumulative_hac',
    'platform': 'python',
    'estimates': [{'term': term, 'estimate': est, 'se': se, 'n_obs': int(n)} for term, est, se in items],
    'method_metadata': {
        'estimator': 'OLS: log(sales) on intercept and lags 1-15 of first difference of log(vix)',
        'vcov': 'Newey-West HAC, Bartlett weights, max lag 15, multiplied by N/(N-16)'
    },
    'diagnostics': {}
}
with open(OUTPUT, 'w', encoding='utf-8') as f:
    json.dump(result, f, indent=2, allow_nan=False)
