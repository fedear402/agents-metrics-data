import json
import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS

h = pd.read_csv('households.csv')
c = pd.read_csv('census.csv')
d = h.loc[h['recipient'].eq(0)].copy()
assert len(d) > 0
z0 = 1 - d['eligible']
z1 = d['eligible']
exog = pd.DataFrame({
    'ineligible': z0,
    'eligible': z1,
    'baseline_ineligible': d['baseline'] * z0,
    'baseline_eligible': d['baseline'] * z1,
}, index=d.index)
endog = pd.DataFrame({
    'dose_ineligible': d['dose'] * z0,
    'dose_eligible': d['dose'] * z1,
}, index=d.index)
excluded = pd.DataFrame({
    'instrument_ineligible': d['instrument'] * z0,
    'instrument_eligible': d['instrument'] * z1,
}, index=d.index)
fit = IV2SLS(d['outcome'], exog, endog, excluded, weights=d['weight']).fit()
slopes = fit.params
means = d.groupby('eligible').apply(lambda g: np.average(g['dose'], weights=g['weight']), include_groups=False)
effects = {
    0: float(slopes['dose_ineligible'] * means.loc[0]),
    1: float(slopes['dose_eligible'] * means.loc[1]),
}
pop = c.set_index('eligible')['nonrecipient_population']
pop_effect = float(np.average([effects[0], effects[1]], weights=[pop.loc[0], pop.loc[1]]))
results = [
    {'term': 'ineligible_effect', 'estimate': effects[0], 'se': None, 'n_obs': int(len(d))},
    {'term': 'eligible_nonrecipient_effect', 'estimate': effects[1], 'se': None, 'n_obs': int(len(d))},
    {'term': 'population_effect', 'estimate': pop_effect, 'se': None, 'n_obs': int(len(d))},
]
output = {
    'task_id': 'applied_nonrecipient_population_iv',
    'platform': 'python',
    'estimates': results,
    'method_metadata': {
        'estimator': 'weighted 2SLS',
        'sample': 'all household rows with recipient=0, across both village treatment statuses',
        'dependent_variable': 'outcome',
        'endogenous_columns': ['dose*(1-eligible)', 'dose*eligible'],
        'exogenous_columns': ['1-eligible', 'eligible', 'baseline*(1-eligible)', 'baseline*eligible'],
        'instruments': 'four exogenous columns plus instrument*(1-eligible) and instrument*eligible',
        'weight': 'weight',
        'counterfactual': 'dose set to zero for every retained household; stated synthetic convention',
        'group_mean_dose': 'household-weighted mean dose within eligibility group',
        'population_weights': 'census nonrecipient_population, used only for final aggregation',
        'group_slopes': {'ineligible': float(slopes['dose_ineligible']), 'eligible': float(slopes['dose_eligible'])},
        'group_weighted_mean_dose': {'ineligible': float(means.loc[0]), 'eligible': float(means.loc[1])},
    },
    'diagnostics': {
        'n_obs': int(len(d)),
        'recipient_values_in_sample': sorted(d['recipient'].unique().astype(int).tolist()),
        'treated_values_in_sample': sorted(d['treated'].unique().astype(int).tolist()),
        'eligibility_group_counts': {str(int(k)): int(v) for k, v in d['eligible'].value_counts().sort_index().items()},
        'census_nonrecipient_population': {str(int(k)): int(v) for k, v in pop.items()},
    },
}
with open('result.json', 'w') as f:
    json.dump(output, f, indent=2, allow_nan=False)
