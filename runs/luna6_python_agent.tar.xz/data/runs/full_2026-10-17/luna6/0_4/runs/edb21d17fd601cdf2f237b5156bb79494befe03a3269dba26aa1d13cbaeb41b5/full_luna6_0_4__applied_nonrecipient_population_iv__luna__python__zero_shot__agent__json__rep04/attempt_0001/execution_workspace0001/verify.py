import json
import numpy as np
import pandas as pd

h = pd.read_csv('households.csv')
c = pd.read_csv('census.csv')
d = h[h.recipient == 0].copy()
e = d.eligible.to_numpy(float)
ni = 1-e
X = np.column_stack([ni,e,d.baseline*ni,d.baseline*e,d.dose*ni,d.dose*e])
Q = np.column_stack([ni,e,d.baseline*ni,d.baseline*e,d.instrument*ni,d.instrument*e])
y = d.outcome.to_numpy(float)
w = d.weight.to_numpy(float)
# Independent IV moment identity: beta=(X'WQ (Q'WQ)^-1 Q'WX)^-1 X'WQ (Q'WQ)^-1 Q'Wy.
# Solve the symmetric normal equations without the first-stage projection used in run.py.
A = Q.T @ (w[:,None] * Q)
B = X.T @ (w[:,None] * Q)
g = Q.T @ (w * y)
C = B @ np.linalg.solve(A, B.T)
rhs = B @ np.linalg.solve(A, g)
beta_iv = np.linalg.solve(C, rhs)
with open('result.json') as f:
    res=json.load(f)
slopes=res['method_metadata']['group_dose_slopes']
assert len(d)==300
assert int((d.eligible==0).sum())==120 and int((d.eligible==1).sum())==180
assert int((d.treated==0).sum())==240 and int((d.treated==1).sum())==60
np.testing.assert_allclose(beta_iv[4],slopes['ineligible'],rtol=1e-11,atol=1e-11)
np.testing.assert_allclose(beta_iv[5],slopes['eligible_nonrecipient'],rtol=1e-11,atol=1e-11)
# Check effects equal slope times weighted mean dose, and census-only aggregation identity.
for term, group in [('ineligible_effect',0),('eligible_nonrecipient_effect',1)]:
    dd=d[d.eligible==group]
    mean=np.average(dd.dose,weights=dd.weight)
    slope=beta_iv[4 if group==0 else 5]
    np.testing.assert_allclose(res['estimates'][group]['estimate'],slope*mean,rtol=1e-12,atol=1e-12)
pop=c.set_index('eligible').nonrecipient_population
expected=(pop.loc[0]*res['estimates'][0]['estimate']+pop.loc[1]*res['estimates'][1]['estimate'])/pop.sum()
np.testing.assert_allclose(res['estimates'][2]['estimate'],expected,rtol=1e-12,atol=1e-12)
print('Independent IV-moment coefficient check passed.')
print('retained rows:',len(d),'group counts:',d.groupby('eligible').size().to_dict(),'treated-status counts:',d.groupby('treated').size().to_dict())
print('IV group slopes:',repr(beta_iv[4]),repr(beta_iv[5]))
print('population aggregation:',repr(expected))
