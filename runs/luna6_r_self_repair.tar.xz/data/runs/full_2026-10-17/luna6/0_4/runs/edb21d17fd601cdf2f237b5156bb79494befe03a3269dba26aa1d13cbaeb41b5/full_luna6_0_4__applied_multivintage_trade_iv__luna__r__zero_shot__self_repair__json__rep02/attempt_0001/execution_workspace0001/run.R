library(jsonlite)

crosswalk <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
trade <- read.csv("trade.csv", stringsAsFactors = FALSE)
areas <- read.csv("areas.csv", stringsAsFactors = FALSE)
employment <- read.csv("employment.csv", stringsAsFactors = FALSE)
outcomes <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

trade <- merge(trade, crosswalk, by = "code", sort = FALSE)

build_exposure <- function(area_rows, employment_rows, trade_rows,
                           employment_vintage, trade_change) {
  # National employment is summed over all supplied areas for each
  # period, vintage, and industry. Omitted area-industry cells are zero.
  national <- aggregate(
    employment ~ period + industry,
    data = employment_rows[
      employment_rows$vintage == employment_vintage, , drop = FALSE
    ],
    FUN = sum
  )

  area_industry <- merge(
    area_rows[, c("area", "period", "total_employment"), drop = FALSE],
    employment_rows[
      employment_rows$vintage == employment_vintage,
      c("area", "period", "industry", "employment"),
      drop = FALSE
    ],
    by = c("area", "period"),
    all.x = TRUE,
    sort = FALSE
  )
  area_industry$employment[is.na(area_industry$employment)] <- 0

  trade_period <- unique(trade_rows[
    , c("period", "industry", trade_change, "price_index", "years"),
    drop = FALSE
  ])
  names(trade_period)[names(trade_period) == trade_change] <- "trade_change"

  calc <- merge(area_industry, national, by = c("period", "industry"),
                suffixes = c("_area", "_national"), sort = FALSE)
  calc <- merge(calc, trade_period, by = c("period", "industry"), sort = FALSE)

  calc$component <-
    (calc$employment / calc$total_employment) *
    (calc$trade_change / calc$employment_national) /
    (calc$price_index / 100) / 1000 * (10 / calc$years)

  aggregate(component ~ area + period, data = calc, FUN = sum)
}

x <- build_exposure(areas, employment, trade, "base", "us_change")
z <- build_exposure(areas, employment, trade, "early", "other_change")

sample <- merge(
  areas[areas$vintage == "base",
        c("area", "period", "population"), drop = FALSE],
  outcomes,
  by = c("area", "period"),
  sort = FALSE
)
sample <- merge(sample, x, by = c("area", "period"), sort = FALSE)
sample <- merge(sample, z, by = c("area", "period"), sort = FALSE)
names(sample)[names(sample) == "component.x"] <- "x"
names(sample)[names(sample) == "component.y"] <- "z"

sample$period_term <- as.numeric(as.factor(sample$period)) - 1

# Weighted 2SLS: regress x on all exogenous variables and z, then
# regress the outcome on the exogenous variables and fitted x.
first_stage <- lm(
  x ~ period_term + control + z,
  data = sample,
  weights = population
)
sample$x_fitted <- fitted(first_stage)

second_stage <- lm(
  change_pp ~ period_term + control + x_fitted,
  data = sample,
  weights = population
)
iv_slope <- unname(coef(second_stage)["x_fitted"])

area0_x <- x[x$area == 0, ]
area0_z <- z[z$area == 0, ]

estimates <- list(
  list(term = "iv_slope", estimate = iv_slope, se = NULL, n_obs = 72L),
  list(
    term = "exposure_area0_period0",
    estimate = area0_x$component[area0_x$period == 0],
    se = NULL, n_obs = 72L
  ),
  list(
    term = "exposure_area0_period1",
    estimate = area0_x$component[area0_x$period == 1],
    se = NULL, n_obs = 72L
  ),
  list(
    term = "instrument_area0_period0",
    estimate = area0_z$component[area0_z$period == 0],
    se = NULL, n_obs = 72L
  )
)

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "weighted_two_stage_least_squares",
    outcome = "change_pp",
    endogenous_regressor = "x",
    excluded_instrument = "z",
    exogenous_regressors = c("intercept", "period", "control"),
    weight = "base_vintage_population",
    exposure_units = "thousands of real dollars per worker per decade"
  ),
  diagnostics = list(n_obs = 72L)
)

write_json(result, "result.json", auto_unbox = TRUE, digits = 17, null = "null")
