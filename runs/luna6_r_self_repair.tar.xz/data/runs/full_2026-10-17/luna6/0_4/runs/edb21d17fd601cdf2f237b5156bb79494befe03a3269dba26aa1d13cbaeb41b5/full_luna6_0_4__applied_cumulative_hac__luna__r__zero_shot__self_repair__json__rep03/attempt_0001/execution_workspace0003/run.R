data <- read.csv("input.csv", stringsAsFactors = FALSE)

if (!all(c("date", "sales", "vix") %in% names(data))) {
  stop("input.csv must contain date, sales, and vix columns.")
}
if (any(!is.finite(data$sales)) || any(data$sales <= 0) ||
    any(!is.finite(data$vix)) || any(data$vix <= 0)) {
  stop("sales and vix must contain finite positive values.")
}

data$date <- as.Date(data$date)
data <- data[order(data$date), , drop = FALSE]
n <- nrow(data)
if (n <= 16L) stop("At least 17 observations are required.")

delta_log_vix <- c(NA_real_, diff(log(data$vix)))
log_sales <- log(data$sales)

# At row t, lag j is the volatility change observed at t-j.
rows <- seq.int(17L, n)
y <- log_sales[rows]
X <- cbind(intercept = 1)
for (j in 1:15) {
  X <- cbind(X, delta_log_vix[rows - j])
  colnames(X)[ncol(X)] <- paste0("lag_", j)
}

# Keep only observations with a complete outcome and lag set.
complete <- is.finite(y) & apply(is.finite(X), 1L, all)
y <- y[complete]
X <- X[complete, , drop = FALSE]
N <- length(y)
if (N <= 16L) stop("The complete regression sample must contain more than 16 observations.")

fit <- lm.fit(x = X, y = y)
if (anyNA(fit$coefficients)) stop("The regression design matrix is rank deficient.")
beta <- fit$coefficients
resid <- fit$residuals

bread <- solve(crossprod(X))
scores <- X * resid
meat <- crossprod(scores)

for (j in 1:15) {
  weight <- 1 - j / 16
  cross <- crossprod(
    scores[(j + 1):N, , drop = FALSE],
    scores[1:(N - j), , drop = FALSE]
  )
  meat <- meat + weight * (cross + t(cross))
}

vcov_nw <- (N / (N - 16)) * bread %*% meat %*% bread

make_estimate <- function(term, weights) {
  estimate <- sum(weights * beta)
  variance <- drop(t(weights) %*% vcov_nw %*% weights)
  list(
    term = term,
    estimate = unname(estimate),
    se = unname(sqrt(max(variance, 0))),
    n_obs = as.integer(N)
  )
}

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    make_estimate("cumulative_response", c(0, rep(1, 15))),
    make_estimate("lag_1", c(0, 1, rep(0, 14))),
    make_estimate("lag_15", c(0, rep(0, 14), 1))
  ),
  method_metadata = list(
    estimator = "OLS of log(sales) on an intercept and lags 1 through 15 of first differences of log(vix)",
    vcov = "Newey-West HAC with Bartlett weights, maximum lag 15, multiplied by N/(N-16)"
  ),
  diagnostics = list()
)

if (!requireNamespace("jsonlite", quietly = TRUE)) {
  stop("The jsonlite package is required to write result.json.")
}
jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = 15, pretty = TRUE)
