library(jsonlite)

crosswalk <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
trade <- read.csv("trade.csv", stringsAsFactors = FALSE)
areas <- read.csv("areas.csv", stringsAsFactors = FALSE)
employment <- read.csv("employment.csv", stringsAsFactors = FALSE)
outcomes <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

# Attach each trade code to its industry.
trade <- merge(trade, crosswalk, by = "code", sort = FALSE)

build_exposure <- function(area_rows, employment_rows, trade_rows,
                           employment_vintage, trade_change) {
  # Fill omitted employment cells with zero across all areas and industries.
  industries <- unique(crosswalk$industry)
  grid <- merge(
    area_rows[, c("area", "period", "total_employment"), drop = FALSE],
    data.frame(industry = industries),
    by = NULL
  )

  vintage_employment <- employment_rows[
    employment_rows$vintage == employment_vintage,
    c("area", "period", "industry", "employment"),
    drop = FALSE
  ]
  area_industry <- merge(
    grid, vintage_employment,
    by = c("area", "period", "industry"),
    all.x = TRUE,
    sort = FALSE
  )
  area_industry$employment[is.na(area_industry$employment)] <- 0

  # Sum employment across every supplied area, by period, vintage, and industry.
  national <- aggregate(
    employment ~ period + industry,
    data = area_industry,
    FUN = sum
  )
  names(national)[names(national) == "employment"] <- "national_employment"

  # Each period and industry has one trade row.
  trade_period <- trade_rows[
    , c("period", "industry", trade_change, "price_index", "years"),
    drop = FALSE
  ]
  names(trade_period)[names(trade_period) == trade_change] <- "trade_change"

  calc <- merge(
    area_industry, national,
    by = c("period", "industry"),
    sort = FALSE
  )
  calc <- merge(
    calc, trade_period,
    by = c("period", "industry"),
    sort = FALSE
  )

  calc$component <-
    (calc$employment / calc$total_employment) *
    (calc$trade_change / calc$national_employment) /
    (calc$price_index / 100) / 1000 * (10 / calc$years)

  aggregate(component ~ area + period, data = calc, FUN = sum)
}

x <- build_exposure(areas, employment, trade, "base", "us_change")
z <- build_exposure(areas, employment, trade, "early", "other_change")

sample <- merge(
  areas[
    areas$vintage == "base",
    c("area", "period", "population"),
    drop = FALSE
  ],
  outcomes,
  by = c("area", "period"),
  sort = FALSE
)
sample <- merge(sample, x, by = c("area", "period"), sort = FALSE)
names(sample)[names(sample) == "component"] <- "x"
sample <- merge(sample, z, by = c("area", "period"), sort = FALSE)
names(sample)[names(sample) == "component"] <- "z"

# Use a numeric period indicator with period 0 as the reference.
sample$period_term <- as.numeric(as.character(sample$period))

# Weighted 2SLS. The first stage includes every exogenous regressor
# and the excluded instrument.
first_stage <- lm(
  x ~ period_term + control + z,
  data = sample,
  weights = population
)
sample$x_fitted <- fitted(first_stage)

second_stage <- lm(
  change_pp ~ period_term + control + x_fitted,
  data = sample,
  weights = population
)
iv_slope <- unname(coef(second_stage)["x_fitted"])

area0_x <- x[x$area == 0, , drop = FALSE]
area0_z <- z[z$area == 0, , drop = FALSE]

estimates <- list(
  list(
    term = "iv_slope",
    estimate = iv_slope,
    se = NULL,
    n_obs = 72L
  ),
  list(
    term = "exposure_area0_period0",
    estimate = area0_x$component[area0_x$period == 0],
    se = NULL,
    n_obs = 72L
  ),
  list(
    term = "exposure_area0_period1",
    estimate = area0_x$component[area0_x$period == 1],
    se = NULL,
    n_obs = 72L
  ),
  list(
    term = "instrument_area0_period0",
    estimate = area0_z$component[area0_z$period == 0],
    se = NULL,
    n_obs = 72L
  )
)

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "weighted_two_stage_least_squares",
    outcome = "change_pp",
    endogenous_regressor = "x",
    excluded_instrument = "z",
    exogenous_regressors = c("intercept", "period", "control"),
    weight = "base_vintage_population",
    exposure_units = "thousands of real dollars per worker per decade"
  ),
  diagnostics = list(n_obs = 72L)
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  digits = 17,
  null = "null"
)
