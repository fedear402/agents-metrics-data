data <- read.csv("input.csv", stringsAsFactors = FALSE)
data$date <- as.Date(data$date)
data <- data[order(data$date), ]

delta_log_vix <- diff(log(data$vix))
log_sales <- log(data$sales)

n <- nrow(data)
first_row <- 17L
rows <- first_row:n
y <- log_sales[rows]

X <- cbind(intercept = 1)
for (j in 1:15) {
  X <- cbind(X, delta_log_vix[rows - j])
  colnames(X)[ncol(X)] <- paste0("lag_", j)
}

fit <- lm.fit(x = X, y = y)
beta <- fit$coefficients
resid <- fit$residuals
N <- length(y)

bread <- solve(crossprod(X))
meat <- matrix(0, ncol(X), ncol(X))
for (j in 0:15) {
  weight <- if (j == 0) 1 else 1 - j / 16
  if (j == 0) {
    meat <- meat + weight * crossprod(X * resid)
  } else {
    cross <- crossprod(X[(j + 1):N, , drop = FALSE] * resid[(j + 1):N],
                       X[1:(N - j), , drop = FALSE] * resid[1:(N - j)])
    meat <- meat + weight * (cross + t(cross))
  }
}
vcov_nw <- (N / (N - 16)) * bread %*% meat %*% bread

cumulative_weights <- rep(0, length(beta))
cumulative_weights[2:16] <- 1
terms <- list(
  list(term = "cumulative_response", weights = cumulative_weights),
  list(term = "lag_1", weights = replace(rep(0, length(beta)), 2, 1)),
  list(term = "lag_15", weights = replace(rep(0, length(beta)), 16, 1))
)

estimates <- lapply(terms, function(item) {
  w <- item$weights
  list(
    term = item$term,
    estimate = unname(sum(w * beta)),
    se = unname(sqrt(drop(t(w) %*% vcov_nw %*% w))),
    n_obs = as.integer(N)
  )
})

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "OLS of log(sales) on intercept and lags 1 through 15 of first differences of log(vix)",
    vcov = "Newey-West HAC with Bartlett weights, maximum lag 15, multiplied by N/(N-16)"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = 15, pretty = TRUE)
