dat <- read.csv("./input.csv")
if (!"y" %in% names(dat)) stop("input.csv must contain a y column")

y <- as.numeric(dat$y)
if (length(y) < 1L || any(!is.finite(y))) stop("y must contain finite observations")

fit <- stats::arima(
  y,
  order = c(1L, 1L, 1L),
  include.mean = FALSE,
  method = "ML"
)

pred <- stats::predict(fit, n.ahead = 1L)
forecast <- as.numeric(pred$pred[1L])
se <- as.numeric(pred$se[1L])
z <- stats::qnorm(0.975)

estimates <- list(
  list(term = "forecast", estimate = forecast, se = se, n_obs = length(y)),
  list(term = "lower_95", estimate = forecast - z * se, se = se, n_obs = length(y)),
  list(term = "upper_95", estimate = forecast + z * se, se = se, n_obs = length(y))
)

result <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "ARIMA(1,1,1) maximum likelihood, no constant or drift",
    vcov = "Model-based one-step-ahead prediction variance"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE, null = "null")
