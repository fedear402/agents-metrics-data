library(jsonlite)

crosswalk <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
trade <- read.csv("trade.csv", stringsAsFactors = FALSE)
areas <- read.csv("areas.csv", stringsAsFactors = FALSE)
employment <- read.csv("employment.csv", stringsAsFactors = FALSE)
outcomes <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

# Attach each trade code to its single industry.
trade <- merge(trade, crosswalk, by = "code", all = FALSE, sort = FALSE)

# Sum employment across all supplied areas for each period, vintage, and industry.
national <- aggregate(
  employment ~ period + vintage + industry,
  data = employment,
  FUN = sum
)

make_exposure <- function(vintage, trade_change, output_name) {
  area_rows <- areas[
    areas$vintage == vintage,
    c("area", "period", "total_employment")
  ]

  # Include every area-industry cell. Omitted cells have zero employment.
  cells <- merge(
    area_rows,
    data.frame(industry = unique(crosswalk$industry)),
    by = NULL
  )
  observed <- employment[
    employment$vintage == vintage,
    c("area", "period", "industry", "employment")
  ]
  cells <- merge(
    cells, observed,
    by = c("area", "period", "industry"),
    all.x = TRUE,
    sort = FALSE
  )
  cells$employment[is.na(cells$employment)] <- 0

  nat <- national[national$vintage == vintage, ]
  names(nat)[names(nat) == "employment"] <- "national_employment"

  # The crosswalk is joined to trade by code before these period-industry rows
  # are attached to the employment cells.
  trade_rows <- trade[
    , c("period", "industry", trade_change, "price_index", "years")
  ]

  d <- merge(cells, nat[, c("period", "industry", "national_employment")],
             by = c("period", "industry"), all.x = TRUE, sort = FALSE)
  d <- merge(d, trade_rows, by = c("period", "industry"),
             all.x = TRUE, sort = FALSE)

  d$component <-
    (d$employment / d$total_employment) *
    (d[[trade_change]] / d$national_employment) /
    (d$price_index / 100) / 1000 * (10 / d$years)

  result <- aggregate(component ~ area + period, data = d, FUN = sum)
  names(result)[names(result) == "component"] <- output_name
  result
}

x_data <- make_exposure("base", "us_change", "x")
z_data <- make_exposure("early", "other_change", "z")

est <- merge(
  areas[areas$vintage == "base", c("area", "period", "population")],
  x_data,
  by = c("area", "period"),
  all = FALSE
)
est <- merge(est, z_data, by = c("area", "period"), all = FALSE)
est <- merge(est, outcomes, by = c("area", "period"), all = FALSE)

# Identify the two periods in their order in the supplied area data.
period_levels <- unique(areas$period)
period_levels <- period_levels[!is.na(period_levels)]
est$period_indicator <- as.integer(
  match(est$period, period_levels) == 2L
)

X <- model.matrix(~ period_indicator + control + x, data = est)
Z <- model.matrix(~ period_indicator + control + z, data = est)
sqrt_w <- sqrt(est$population)

Xw <- X * sqrt_w
Zw <- Z * sqrt_w
yw <- est$change_pp * sqrt_w

# Weighted 2SLS using all exogenous regressors as instruments.
X_projected <- qr.fitted(qr(Zw), Xw)
beta <- solve(crossprod(Xw, X_projected), crossprod(X_projected, yw))
iv_slope <- unname(beta[which(colnames(X) == "x")])

area0 <- unique(areas$area)[1]
period0 <- period_levels[1]
period1 <- period_levels[2]

exposure_area0_period0 <- est$x[est$area == area0 & est$period == period0][1]
exposure_area0_period1 <- est$x[est$area == area0 & est$period == period1][1]
instrument_area0_period0 <- est$z[est$area == area0 & est$period == period0][1]

n_obs <- 72L
estimates <- list(
  list(term = "iv_slope", estimate = unname(iv_slope), se = NULL, n_obs = n_obs),
  list(term = "exposure_area0_period0", estimate = unname(exposure_area0_period0), se = NULL, n_obs = n_obs),
  list(term = "exposure_area0_period1", estimate = unname(exposure_area0_period1), se = NULL, n_obs = n_obs),
  list(term = "instrument_area0_period0", estimate = unname(instrument_area0_period0), se = NULL, n_obs = n_obs)
)

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "weighted_2sls",
    outcome = "change_pp",
    endogenous_regressor = "x",
    excluded_instrument = "z",
    exogenous_regressors = c("intercept", "period", "control"),
    regression_weight = "base-vintage population",
    exposure_units = "thousands of real dollars per worker per decade"
  ),
  diagnostics = list(n_obs = n_obs)
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  digits = 15,
  null = "null"
)
