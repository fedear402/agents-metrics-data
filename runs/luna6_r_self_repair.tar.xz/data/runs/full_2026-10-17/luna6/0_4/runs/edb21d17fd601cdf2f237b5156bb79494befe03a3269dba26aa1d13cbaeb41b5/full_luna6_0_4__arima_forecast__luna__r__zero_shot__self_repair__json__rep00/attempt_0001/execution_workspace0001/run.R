data <- read.csv("./input.csv")
stopifnot("y" %in% names(data), length(data$y) > 0L)

fit <- stats::arima(
  data$y,
  order = c(1L, 1L, 1L),
  include.mean = FALSE,
  method = "ML"
)

prediction <- stats::predict(fit, n.ahead = 1L)
forecast <- as.numeric(prediction$pred[1L])
se <- as.numeric(prediction$se[1L])
critical <- stats::qnorm(0.975)

estimates <- list(
  list(term = "forecast", estimate = forecast, se = se, n_obs = length(data$y)),
  list(term = "lower_95", estimate = forecast - critical * se, se = NULL, n_obs = length(data$y)),
  list(term = "upper_95", estimate = forecast + critical * se, se = NULL, n_obs = length(data$y))
)

result <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "ARIMA(1,1,1) maximum likelihood, no constant or drift",
    vcov = "Model-based one-step-ahead forecast variance"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = 15, pretty = TRUE)
