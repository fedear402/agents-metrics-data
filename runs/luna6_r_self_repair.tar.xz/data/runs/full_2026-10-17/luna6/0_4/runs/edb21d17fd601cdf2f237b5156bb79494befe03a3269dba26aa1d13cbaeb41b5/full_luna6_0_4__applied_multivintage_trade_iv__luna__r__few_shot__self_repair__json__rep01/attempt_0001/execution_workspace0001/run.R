library(jsonlite)

crosswalk <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
trade <- read.csv("trade.csv", stringsAsFactors = FALSE)
areas <- read.csv("areas.csv", stringsAsFactors = FALSE)
employment <- read.csv("employment.csv", stringsAsFactors = FALSE)
outcomes <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

trade <- merge(trade, crosswalk, by = "code", all.x = TRUE, sort = FALSE)

# Complete omitted area-industry employment cells with zero.
keys <- unique(areas[c("area", "period", "vintage")])
industries <- unique(crosswalk$industry)
grid <- merge(keys, data.frame(industry = industries), all = TRUE)
emp <- merge(grid, employment,
             by = c("area", "period", "vintage", "industry"),
             all.x = TRUE, sort = FALSE)
emp$employment[is.na(emp$employment)] <- 0

national <- aggregate(employment ~ period + vintage + industry, emp, sum)
names(national)[names(national) == "employment"] <- "national_employment"

make_exposure <- function(vintage, change_column) {
  e <- emp[emp$vintage == vintage, ]
  e <- merge(e, national[national$vintage == vintage, ],
             by = c("period", "vintage", "industry"), all.x = TRUE)
  t <- trade[c("period", "industry", change_column, "price_index", "years")]
  names(t)[names(t) == change_column] <- "trade_change"
  e <- merge(e, t, by = c("period", "industry"), all.x = TRUE)
  a <- areas[areas$vintage == vintage,
             c("area", "period", "total_employment")]
  e <- merge(e, a, by = c("area", "period"), all.x = TRUE)
  e$component <- (e$employment / e$total_employment) *
    (e$trade_change / e$national_employment) /
    (e$price_index / 100) / 1000 * (10 / e$years)
  aggregate(component ~ area + period, e, sum)
}

x <- make_exposure("base", "us_change")
z <- make_exposure("early", "other_change")
names(x)[3] <- "x"
names(z)[3] <- "z"

dat <- merge(outcomes, x, by = c("area", "period"), all = FALSE)
dat <- merge(dat, z, by = c("area", "period"), all = FALSE)
base_population <- areas[areas$vintage == "base",
                         c("area", "period", "population")]
dat <- merge(dat, base_population, by = c("area", "period"), all = FALSE)

dat$period_numeric <- as.numeric(as.factor(dat$period))
W <- diag(dat$population)
X <- cbind(intercept = 1, period = dat$period_numeric,
           control = dat$control, x = dat$x)
Z <- cbind(intercept = 1, period = dat$period_numeric,
           control = dat$control, z = dat$z)
y <- dat$change_pp

# Weighted 2SLS, with all exogenous regressors included as instruments.
sw <- sqrt(dat$population)
Xw <- X * sw
Zw <- Z * sw
yw <- y * sw
PZX <- Zw %*% solve(crossprod(Zw), crossprod(Zw, Xw))
beta <- solve(crossprod(Xw, PZX), crossprod(Xw, Zw) %*%
                solve(crossprod(Zw), crossprod(Zw, yw)))
iv_slope <- as.numeric(beta[ncol(X)])

area0 <- sort(unique(dat$area))[1]
periods <- sort(unique(dat$period))
x0 <- x[x$area == area0, ]
z0 <- z[z$area == area0, ]

estimates <- list(
  list(term = "iv_slope", estimate = iv_slope, se = NULL, n_obs = 72L),
  list(term = "exposure_area0_period0",
       estimate = x0$x[match(periods[1], x0$period)], se = NULL, n_obs = 72L),
  list(term = "exposure_area0_period1",
       estimate = x0$x[match(periods[2], x0$period)], se = NULL, n_obs = 72L),
  list(term = "instrument_area0_period0",
       estimate = z0$z[match(periods[1], z0$period)], se = NULL, n_obs = 72L)
)

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "weighted two-stage least squares",
    outcome = "change_pp",
    endogenous_regressor = "x",
    excluded_instrument = "z",
    exogenous_regressors = c("intercept", "period", "control"),
    weight = "base-vintage population",
    exposure_units = "thousands of real dollars per worker per decade"
  ),
  diagnostics = list(n_obs = 72L)
)

write_json(result, "result.json", auto_unbox = TRUE, digits = 16, pretty = TRUE)
