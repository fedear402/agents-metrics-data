library(forecast)
library(jsonlite)

dat <- read.csv("./input.csv")
y <- as.numeric(dat$y)

if (!length(y) || any(!is.finite(y))) {
  stop("Column y must contain finite numeric values.")
}

fit <- forecast::Arima(
  ts(y),
  order = c(1, 1, 1),
  include.mean = FALSE,
  include.drift = FALSE,
  method = "ML"
)

fc <- forecast::forecast(fit, h = 1, level = 95)
n <- length(y)

forecast_value <- unname(as.numeric(fc$mean[1]))
lower_value <- unname(as.numeric(fc$lower[1, 1]))
upper_value <- unname(as.numeric(fc$upper[1, 1]))

# Derive the prediction standard error from the two-sided 95% interval.
prediction_se <- (upper_value - lower_value) / (2 * qnorm(0.975))

out <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = list(
    list(term = "forecast", estimate = forecast_value, se = prediction_se, n_obs = n),
    list(term = "lower_95", estimate = lower_value, se = prediction_se, n_obs = n),
    list(term = "upper_95", estimate = upper_value, se = prediction_se, n_obs = n)
  ),
  method_metadata = list(
    estimator = "ARIMA(1,1,1) by maximum likelihood, no constant or drift",
    vcov = "95% prediction interval from forecast package"
  ),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "./result.json", auto_unbox = TRUE, na = "null", digits = 15)
