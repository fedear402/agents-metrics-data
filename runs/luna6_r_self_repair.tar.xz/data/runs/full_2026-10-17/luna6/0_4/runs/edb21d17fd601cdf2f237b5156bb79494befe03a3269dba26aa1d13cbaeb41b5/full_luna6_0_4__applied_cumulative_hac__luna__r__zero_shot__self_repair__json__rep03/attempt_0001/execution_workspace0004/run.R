data <- read.csv("input.csv", stringsAsFactors = FALSE)

required <- c("date", "sales", "vix")
if (!all(required %in% names(data))) {
  stop("input.csv must contain date, sales, and vix columns.")
}
if (any(!is.finite(data$sales)) || any(data$sales <= 0) ||
    any(!is.finite(data$vix)) || any(data$vix <= 0)) {
  stop("sales and vix must contain finite positive values.")
}

data$date <- as.Date(data$date)
if (anyNA(data$date)) stop("All dates must be valid.")
data <- data[order(data$date), , drop = FALSE]

n <- nrow(data)
if (n <= 16L) stop("At least 17 observations are required.")

delta_log_vix <- c(NA_real_, diff(log(data$vix)))
log_sales <- log(data$sales)

# Build one row for each outcome with 15 preceding trading observations.
rows <- seq.int(17L, n)
y_all <- log_sales[rows]
X_all <- matrix(NA_real_, nrow = length(rows), ncol = 16L)
colnames(X_all) <- c("intercept", paste0("lag_", 1:15))
X_all[, 1L] <- 1

for (j in 1:15) {
  X_all[, j + 1L] <- delta_log_vix[rows - j]
}

complete <- is.finite(y_all) & apply(is.finite(X_all), 1L, all)
y <- y_all[complete]
X <- X_all[complete, , drop = FALSE]
N <- length(y)

if (N <= 16L) {
  stop("The complete regression sample must contain more than 16 observations.")
}

fit <- lm.fit(x = X, y = y)
if (anyNA(fit$coefficients)) stop("The regression design matrix is rank deficient.")

beta <- fit$coefficients
resid <- fit$residuals
bread <- solve(crossprod(X))
scores <- X * resid
meat <- crossprod(scores)

for (j in 1:15) {
  weight <- 1 - j / 16
  cross <- crossprod(
    scores[(j + 1L):N, , drop = FALSE],
    scores[1L:(N - j), , drop = FALSE]
  )
  meat <- meat + weight * (cross + t(cross))
}

vcov_nw <- (N / (N - 16)) * bread %*% meat %*% bread

make_estimate <- function(term, weights) {
  estimate <- sum(weights * beta)
  variance <- drop(t(weights) %*% vcov_nw %*% weights)
  list(
    term = term,
    estimate = unname(estimate),
    se = unname(sqrt(max(variance, 0))),
    n_obs = as.integer(N)
  )
}

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    make_estimate("cumulative_response", c(0, rep(1, 15))),
    make_estimate("lag_1", c(0, 1, rep(0, 14))),
    make_estimate("lag_15", c(0, rep(0, 14), 1))
  ),
  method_metadata = list(
    estimator = "OLS of log(sales) on an intercept and lags 1 through 15 of first differences of log(vix)",
    vcov = "Newey-West HAC with Bartlett weights, maximum lag 15, multiplied by N/(N-16)"
  ),
  diagnostics = list()
)

if (!requireNamespace("jsonlite", quietly = TRUE)) {
  stop("The jsonlite package is required to write result.json.")
}
jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = 15, pretty = TRUE)
