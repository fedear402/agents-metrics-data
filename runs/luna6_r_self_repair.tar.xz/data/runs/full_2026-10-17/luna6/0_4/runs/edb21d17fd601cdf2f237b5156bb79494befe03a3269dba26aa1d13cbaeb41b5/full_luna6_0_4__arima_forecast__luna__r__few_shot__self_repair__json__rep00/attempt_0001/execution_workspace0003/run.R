library(forecast)
library(jsonlite)

dat <- read.csv("./input.csv")
y <- as.numeric(dat$y)
y <- y[is.finite(y)]
n <- length(y)

if (n < 3L) stop("At least three finite observations are required.")

fit <- forecast::Arima(
  y,
  order = c(1, 1, 1),
  include.mean = FALSE,
  include.drift = FALSE,
  method = "ML"
)
pred <- forecast::forecast(fit, h = 1, level = 95)

forecast_value <- as.numeric(pred$mean[1])
forecast_se <- sqrt(as.numeric(pred$var[1]))
lower_value <- forecast_value - qnorm(0.975) * forecast_se
upper_value <- forecast_value + qnorm(0.975) * forecast_se

out <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = list(
    list(term = "forecast", estimate = forecast_value,
         se = forecast_se, n_obs = n),
    list(term = "lower_95", estimate = lower_value,
         se = NA_real_, n_obs = n),
    list(term = "upper_95", estimate = upper_value,
         se = NA_real_, n_obs = n)
  ),
  method_metadata = list(
    estimator = "ARIMA(1,1,1) maximum likelihood, no constant or drift",
    vcov = "One-step forecast variance from fitted ARIMA model"
  ),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "result.json", auto_unbox = TRUE, na = "null", digits = 15)
