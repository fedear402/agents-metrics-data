dat <- read.csv("input.csv", stringsAsFactors = FALSE)

# Use one observation per region to define normalized regional weights.
regions <- dat[!duplicated(dat$region_id), c("region_id", "region_weight", "x", "y")]
regions$e <- regions$region_weight / sum(regions$region_weight)

# Keep all region-industry rows and attach each region's normalized weight.
d <- merge(dat, regions[, c("region_id", "e")], by = "region_id", sort = FALSE)

# Regional shift-share instrument and weighted-mean residuals.
z_reg <- aggregate(share * shock ~ region_id, data = d, FUN = sum)
names(z_reg)[2] <- "z"
regions <- merge(regions, z_reg, by = "region_id", sort = FALSE)

wmean <- function(v, w) sum(w * v) / sum(w)
regions$y0 <- regions$y - wmean(regions$y, regions$e)
regions$x0 <- regions$x - wmean(regions$x, regions$e)
regions$z0 <- regions$z - wmean(regions$z, regions$e)

# Industry exposure weights and exposure-weighted aggregates.
d <- merge(d, regions[, c("region_id", "y0", "x0", "z0")],
           by = "region_id", sort = FALSE)
d$weighted_share <- d$e * d$share
industry <- aggregate(
  cbind(weighted_share,
        weighted_share * y0,
        weighted_share * x0,
        weighted_share * z0) ~ industry_id + shock,
  data = d, FUN = sum
)
names(industry) <- c("industry_id", "shock", "s", "sum_y", "sum_x", "sum_z")
industry$ybar <- industry$sum_y / industry$s
industry$xbar <- industry$sum_x / industry$s
industry$zbar <- industry$sum_z / industry$s
N <- nrow(industry)

# Weighted shock-level IV slope and structural residual HC1 standard error.
iv_slope_hc1 <- function(outcome, endogenous, instrument, weights) {
  X <- cbind(1, endogenous)
  Z <- cbind(1, instrument)
  W <- diag(weights)
  A <- solve(t(X) %*% W %*% Z) %*% t(X) %*% W %*% Z
  # The expression above is the projection coefficient matrix for the
  # exactly identified model; use the standard IV sandwich form.
  bread <- solve(t(X) %*% W %*% Z)
  beta <- bread %*% t(X) %*% W %*% outcome
  residual <- as.vector(outcome - X %*% beta)
  score <- Z * as.vector(weights * residual)
  meat <- t(X) %*% W %*% Z %*% solve(t(Z) %*% W %*% Z) %*%
    t(score) %*% score %*%
    solve(t(Z) %*% W %*% Z) %*% t(Z) %*% W %*% X
  vc <- bread %*% meat %*% t(bread) * N / (N - 2)
  c(estimate = beta[2], se = sqrt(vc[2, 2]))
}

effect <- iv_slope_hc1(industry$ybar, industry$xbar,
                       industry$shock, industry$s)
first_stage <- iv_slope_hc1(industry$xbar, industry$zbar,
                            industry$shock, industry$s)
effective_shocks <- 1 / sum(industry$s^2)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = unname(effect["estimate"]),
         se = unname(effect["se"]), n_obs = N),
    list(term = "first_stage", estimate = unname(first_stage["estimate"]),
         se = unname(first_stage["se"]), n_obs = N),
    list(term = "effective_shocks", estimate = effective_shocks,
         se = NULL, n_obs = N)
  ),
  method_metadata = list(
    estimator = "weighted_2sls_with_Borusyak_Hull_Jaravel_shock_level_aggregation",
    vcov = "shock_level_heteroskedastic_HC1_analytic_weights_no_clustering"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = 15,
                     null = "null", pretty = TRUE)
