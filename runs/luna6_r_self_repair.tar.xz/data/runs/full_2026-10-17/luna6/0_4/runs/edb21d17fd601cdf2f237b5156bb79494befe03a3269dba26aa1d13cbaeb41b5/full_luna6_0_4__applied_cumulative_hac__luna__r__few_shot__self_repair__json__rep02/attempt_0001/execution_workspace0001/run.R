library(jsonlite)

data <- read.csv("input.csv", stringsAsFactors = FALSE)
data$date <- as.Date(data$date)
data <- data[order(data$date), ]

log_vix <- log(data$vix)
vol_change <- c(NA_real_, diff(log_vix))
log_sales <- log(data$sales)

n <- nrow(data)
for (j in 1:15) {
  data[[paste0("lag_", j)]] <- c(rep(NA_real_, j + 1), vol_change[seq_len(n - j - 1)])
}

regressors <- paste0("lag_", 1:15)
sample <- data[complete.cases(data[, c("log_sales", regressors)]), ]
fit <- lm(log_sales ~ ., data = sample[, c("log_sales", regressors)])

X <- model.matrix(fit)
beta <- coef(fit)
residuals <- residuals(fit)
N <- nrow(X)
p <- ncol(X)

scores <- X * residuals
meat <- crossprod(scores)
hac_lags <- 15L

for (j in seq_len(hac_lags)) {
  lag_product <- crossprod(
    scores[(j + 1):N, , drop = FALSE],
    scores[1:(N - j), , drop = FALSE]
  )
  weight <- 1 - j / 16
  meat <- meat + weight * (lag_product + t(lag_product))
}

bread <- solve(crossprod(X))
covariance <- (N / (N - 16)) * bread %*% meat %*% bread

contrast <- c(0, rep(1, 15))
cumulative_response <- sum(contrast * beta)
cumulative_se <- sqrt(drop(t(contrast) %*% covariance %*% contrast))

row <- function(term, estimate, se) {
  list(
    term = term,
    estimate = unname(as.numeric(estimate)),
    se = unname(as.numeric(se)),
    n_obs = as.integer(N)
  )
}

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    row("cumulative_response", cumulative_response, cumulative_se),
    row("lag_1", beta["lag_1"], sqrt(covariance["lag_1", "lag_1"])),
    row("lag_15", beta["lag_15"], sqrt(covariance["lag_15", "lag_15"]))
  ),
  method_metadata = list(
    estimator = "OLS with 15 lags of first differences in log(vix)",
    vcov = "Newey-West HAC, Bartlett maximum lag 15, covariance correction N/(N-16)"
  ),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
