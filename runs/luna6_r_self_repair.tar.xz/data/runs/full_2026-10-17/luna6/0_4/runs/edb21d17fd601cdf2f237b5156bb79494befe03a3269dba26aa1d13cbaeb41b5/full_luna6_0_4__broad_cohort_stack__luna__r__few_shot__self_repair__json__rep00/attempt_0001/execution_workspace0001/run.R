library(jsonlite)

d <- read.csv("input.csv")

cohorts <- c(3, 5, 7)
terms <- c("att_g3", "att_g5", "att_g7")
estimates <- numeric(length(cohorts))
treated_counts <- integer(length(cohorts))
row_counts <- integer(length(cohorts))

for (i in seq_along(cohorts)) {
  c <- cohorts[i]
  window <- (c - 2):(c + 2)

  eligible <- d[d$g == c | d$g == 0 | d$g > c + 2, ]
  complete_ids <- names(which(table(factor(
    eligible$id[eligible$time %in% window],
    levels = unique(eligible$id)
  )) == length(window)))

  comparison <- eligible[
    eligible$id %in% complete_ids & eligible$time %in% window,
  ]
  comparison$did <- as.numeric(comparison$g == c & comparison$time >= c)

  estimates[i] <- unname(coef(lm(
    y ~ did + factor(id) + factor(time),
    data = comparison
  ))["did"])
  treated_counts[i] <- length(unique(comparison$id[comparison$g == c]))
  row_counts[i] <- nrow(comparison)
}

weighted_estimate <- weighted.mean(estimates, treated_counts)

out <- list(
  task_id = "broad_cohort_stack",
  platform = "r",
  estimates = list(
    list(term = terms[1], estimate = estimates[1], se = NULL, n_obs = row_counts[1]),
    list(term = terms[2], estimate = estimates[2], se = NULL, n_obs = row_counts[2]),
    list(term = terms[3], estimate = estimates[3], se = NULL, n_obs = row_counts[3]),
    list(term = "att_weighted", estimate = weighted_estimate, se = NULL,
         n_obs = sum(row_counts))
  ),
  method_metadata = list(),
  diagnostics = list()
)

write_json(out, "result.json", auto_unbox = TRUE, null = "null", digits = 16)
