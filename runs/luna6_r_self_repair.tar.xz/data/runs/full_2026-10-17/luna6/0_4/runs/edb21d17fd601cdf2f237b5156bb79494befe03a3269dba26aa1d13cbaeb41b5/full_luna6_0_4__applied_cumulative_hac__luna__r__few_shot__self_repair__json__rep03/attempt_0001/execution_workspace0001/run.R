library(jsonlite)

data <- read.csv("input.csv", stringsAsFactors = FALSE)
data$date <- as.Date(data$date)
data <- data[order(data$date), ]

log_vix <- log(data$vix)
vol_change <- c(NA_real_, diff(log_vix))
log_sales <- log(data$sales)

n <- nrow(data)
lag_matrix <- sapply(1:15, function(j) {
  c(rep(NA_real_, j), vol_change[seq_len(n - j)])
})
colnames(lag_matrix) <- paste0("lag_", 1:15)

regression_data <- data.frame(log_sales = log_sales, lag_matrix)
sample <- regression_data[complete.cases(regression_data), ]
fit <- lm(log_sales ~ ., data = sample)

X <- model.matrix(fit)
beta <- coef(fit)
N <- nrow(X)
p <- ncol(X)
scores <- X * residuals(fit)

hac_lags <- 15
meat <- crossprod(scores)
for (j in seq_len(hac_lags)) {
  lag_product <- crossprod(
    scores[(j + 1):N, , drop = FALSE],
    scores[1:(N - j), , drop = FALSE]
  )
  weight <- 1 - j / 16
  meat <- meat + weight * (lag_product + t(lag_product))
}

bread <- solve(crossprod(X))
covariance <- (N / (N - 16)) * bread %*% meat %*% bread

lag_indices <- match(paste0("lag_", 1:15), names(beta))
contrast <- rep(0, length(beta))
contrast[lag_indices] <- 1

cumulative_response <- sum(beta[lag_indices])
cumulative_se <- sqrt(drop(t(contrast) %*% covariance %*% contrast))

rows <- list(
  list(
    term = "cumulative_response",
    estimate = unname(as.numeric(cumulative_response)),
    se = unname(as.numeric(cumulative_se)),
    n_obs = as.integer(N)
  ),
  list(
    term = "lag_1",
    estimate = unname(as.numeric(beta["lag_1"])),
    se = unname(as.numeric(sqrt(covariance["lag_1", "lag_1"]))),
    n_obs = as.integer(N)
  ),
  list(
    term = "lag_15",
    estimate = unname(as.numeric(beta["lag_15"])),
    se = unname(as.numeric(sqrt(covariance["lag_15", "lag_15"]))),
    n_obs = as.integer(N)
  )
)

write_json(
  list(
    task_id = "applied_cumulative_hac",
    platform = "r",
    estimates = rows,
    method_metadata = list(
      estimator = "OLS with 15 observed-row lags of first differences in log(VIX)",
      vcov = "Newey-West HAC, Bartlett maximum lag 15, finite-sample correction N/(N-16)"
    ),
    diagnostics = list()
  ),
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
