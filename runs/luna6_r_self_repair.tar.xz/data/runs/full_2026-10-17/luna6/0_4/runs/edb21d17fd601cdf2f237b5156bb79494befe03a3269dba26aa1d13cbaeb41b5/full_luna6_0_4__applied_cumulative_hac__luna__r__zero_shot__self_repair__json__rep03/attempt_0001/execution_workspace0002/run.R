data <- read.csv("input.csv", stringsAsFactors = FALSE)
data$date <- as.Date(data$date)
data <- data[order(data$date), ]

log_sales <- log(data$sales)
delta_log_vix <- c(NA_real_, diff(log(data$vix)))

# Row t uses volatility changes from observations t-1 through t-15.
first_row <- 17L
rows <- seq.int(first_row, nrow(data))
y <- log_sales[rows]

X <- cbind(intercept = 1)
for (j in 1:15) {
  X <- cbind(X, delta_log_vix[rows - j])
  colnames(X)[ncol(X)] <- paste0("lag_", j)
}

fit <- lm.fit(x = X, y = y)
beta <- fit$coefficients
resid <- fit$residuals
N <- length(y)

bread <- solve(crossprod(X))
scores <- X * resid
meat <- crossprod(scores)

for (j in 1:15) {
  weight <- 1 - j / 16
  cross <- crossprod(
    scores[(j + 1):N, , drop = FALSE],
    scores[1:(N - j), , drop = FALSE]
  )
  meat <- meat + weight * (cross + t(cross))
}

vcov_nw <- (N / (N - 16)) * bread %*% meat %*% bread

cumulative_weights <- c(0, rep(1, 15))
lag1_weights <- c(0, 1, rep(0, 14))
lag15_weights <- c(0, rep(0, 14), 1)

make_estimate <- function(term, weights) {
  list(
    term = term,
    estimate = unname(sum(weights * beta)),
    se = unname(sqrt(drop(t(weights) %*% vcov_nw %*% weights))),
    n_obs = as.integer(N)
  )
}

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    make_estimate("cumulative_response", cumulative_weights),
    make_estimate("lag_1", lag1_weights),
    make_estimate("lag_15", lag15_weights)
  ),
  method_metadata = list(
    estimator = "OLS of log(sales) on an intercept and lags 1 through 15 of first differences of log(vix)",
    vcov = "Newey-West HAC with Bartlett weights, maximum lag 15, multiplied by N/(N-16)"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = 15, pretty = TRUE)
