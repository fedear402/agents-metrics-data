library(jsonlite)

dat <- read.csv("input.csv", stringsAsFactors = FALSE)

required <- c("region_id", "industry_id", "share", "shock",
              "region_weight", "x", "y")
if (!all(required %in% names(dat))) {
  stop("input.csv is missing required columns")
}

# Keep one record per region for regional variables and weights.
region_rows <- !duplicated(dat$region_id)
regions <- dat[region_rows, c("region_id", "region_weight", "x", "y")]
if (anyDuplicated(dat$region_id) && anyDuplicated(dat$region_id[region_rows])) {
  stop("Could not form unique regional records")
}
regions$e <- regions$region_weight / sum(regions$region_weight)

# Check that repeated regional variables are constant within region.
for (nm in c("region_weight", "x", "y")) {
  spread <- tapply(dat[[nm]], dat$region_id, function(v) max(v) - min(v))
  if (any(!is.finite(spread)) || any(spread > 1e-10)) {
    stop(paste(nm, "is not constant within region"))
  }
}

# Check that shocks are constant within industry.
shock_spread <- tapply(dat$shock, dat$industry_id, function(v) max(v) - min(v))
if (any(!is.finite(shock_spread)) || any(shock_spread > 1e-10)) {
  stop("shock is not constant within industry")
}

# Construct the regional instrument from the region-industry shares.
z_by_region <- aggregate(share * shock ~ region_id, data = dat, FUN = sum)
names(z_by_region)[2] <- "z"
regions <- merge(regions, z_by_region, by = "region_id", sort = FALSE)

wmean <- function(v, w) sum(w * v) / sum(w)
regions$y0 <- regions$y - wmean(regions$y, regions$e)
regions$x0 <- regions$x - wmean(regions$x, regions$e)
regions$z0 <- regions$z - wmean(regions$z, regions$e)

# Attach normalized region weights and centered variables to each exposure.
dat <- merge(dat, regions[, c("region_id", "e", "y0", "x0", "z0")],
             by = "region_id", sort = FALSE)

# Aggregate centered regional residuals to industry exposure means.
dat$weighted_share <- dat$e * dat$share
industry <- aggregate(
  cbind(weighted_share, weighted_share * dat$y0,
        weighted_share * dat$x0, weighted_share * dat$z0) ~ industry_id,
  data = dat, FUN = sum
)
names(industry) <- c("industry_id", "s", "wy", "wx", "wz")
industry$ybar <- industry$wy / industry$s
industry$xbar <- industry$wx / industry$s
industry$zbar <- industry$wz / industry$s
industry <- merge(industry,
                  unique(dat[, c("industry_id", "shock")]),
                  by = "industry_id", sort = FALSE)

N <- nrow(industry)
if (N <= 2L) stop("At least three industries are required for HC1 variance")

# Weighted IV with an intercept, analytic weights, and structural residuals.
shock_iv <- function(dependent, endogenous, instrument, weights) {
  X <- cbind(1, endogenous)
  Q <- cbind(1, instrument)
  A <- crossprod(Q, weights * X)
  b <- solve(A, crossprod(Q, weights * dependent))
  residual <- drop(dependent - X %*% b)
  scores <- Q * (weights * residual)
  Ainv <- solve(A)
  V <- (N / (N - 2)) * Ainv %*% crossprod(scores) %*% t(Ainv)
  c(estimate = b[2], se = sqrt(V[2, 2]))
}

effect <- shock_iv(industry$ybar, industry$xbar,
                   industry$shock, industry$s)
first_stage <- shock_iv(industry$xbar, industry$zbar,
                        industry$shock, industry$s)

effective_shocks <- 1 / sum(industry$s^2)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = unname(effect["estimate"]),
         se = unname(effect["se"]), n_obs = as.integer(N)),
    list(term = "first_stage", estimate = unname(first_stage["estimate"]),
         se = unname(first_stage["se"]), n_obs = as.integer(N)),
    list(term = "effective_shocks", estimate = effective_shocks,
         se = NULL, n_obs = as.integer(N))
  ),
  method_metadata = list(
    estimator = "Weighted 2SLS with Borusyak-Hull-Jaravel shock-level aggregation",
    vcov = "Shock-level HC1 with structural IV residuals and analytic weights"
  ),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null",
           digits = 16, pretty = TRUE)
