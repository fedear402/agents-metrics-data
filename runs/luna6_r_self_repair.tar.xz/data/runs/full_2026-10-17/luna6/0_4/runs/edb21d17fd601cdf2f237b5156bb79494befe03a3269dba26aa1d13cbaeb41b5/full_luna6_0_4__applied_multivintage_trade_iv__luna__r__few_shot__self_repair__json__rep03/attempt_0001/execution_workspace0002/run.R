library(jsonlite)

crosswalk <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
trade <- read.csv("trade.csv", stringsAsFactors = FALSE)
areas <- read.csv("areas.csv", stringsAsFactors = FALSE)
employment_raw <- read.csv("employment.csv", stringsAsFactors = FALSE)
outcomes <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

# Join each trade code to its industry. Each period-industry has one trade row.
trade <- merge(trade, crosswalk, by = "code", all = FALSE)
trade <- trade[!duplicated(trade[c("period", "industry")]), ]

industries <- unique(crosswalk$industry)

# Map observed employment codes to industries, then sum any rows that map to
# the same area-period-vintage-industry cell.
employment <- merge(employment_raw, crosswalk,
                    by.x = "industry", by.y = "industry", all = FALSE)
employment <- aggregate(
  employment ~ area + period + vintage + industry,
  data = employment,
  FUN = sum
)

make_exposure <- function(vintage, change_column) {
  area_periods <- unique(areas[areas$vintage == vintage,
                               c("area", "period")])
  totals <- areas[areas$vintage == vintage,
                  c("area", "period", "total_employment")]

  # Complete the area-period-industry grid so omitted employment cells equal 0.
  grid <- merge(area_periods, data.frame(industry = industries), by = NULL)
  observed <- employment[employment$vintage == vintage,
                         c("area", "period", "industry", "employment")]
  cells <- merge(grid, observed,
                 by = c("area", "period", "industry"), all.x = TRUE)
  cells$employment[is.na(cells$employment)] <- 0

  # National denominators are sums across all supplied areas, by period and
  # industry. Include zero cells through the completed grid.
  national <- aggregate(
    employment ~ period + industry,
    data = cells,
    FUN = sum
  )
  names(national)[3] <- "national_employment"

  tr <- trade[c("period", "industry", change_column, "price_index", "years")]
  names(tr)[3] <- "trade_change"

  components <- merge(cells, tr, by = c("period", "industry"), all = FALSE)
  components <- merge(components, national,
                      by = c("period", "industry"), all = FALSE)

  components$component <-
    (components$employment / components$national_employment) *
    (components$trade_change / (components$price_index / 100)) /
    1000 * (10 / components$years)

  sums <- aggregate(component ~ area + period,
                    data = components, FUN = sum)
  sums <- merge(sums, totals, by = c("area", "period"), all = FALSE)
  sums$exposure <- sums$component / sums$total_employment
  sums[c("area", "period", "exposure")]
}

x <- make_exposure("base", "us_change")
z <- make_exposure("early", "other_change")
names(x)[3] <- "x"
names(z)[3] <- "z"

base_weights <- areas[areas$vintage == "base",
                      c("area", "period", "population")]

reg <- merge(outcomes, base_weights, by = c("area", "period"), all = FALSE)
reg <- merge(reg, x, by = c("area", "period"), all = FALSE)
reg <- merge(reg, z, by = c("area", "period"), all = FALSE)

period_values <- sort(unique(reg$period))
reg$period_indicator <- as.integer(reg$period == period_values[2])

# Weighted 2SLS. Instruments include every exogenous regressor and z.
X <- model.matrix(~ period_indicator + control + x, data = reg)
Z <- model.matrix(~ period_indicator + control + z, data = reg)
sqrt_w <- sqrt(reg$population)
Xw <- X * sqrt_w
Zw <- Z * sqrt_w
yw <- reg$change_pp * sqrt_w

projected_X <- qr.fitted(qr(Zw), Xw)
projected_y <- qr.fitted(qr(Zw), yw)
beta <- solve(crossprod(Xw, projected_X),
              crossprod(Xw, projected_y))
iv_slope <- as.numeric(beta[which(colnames(X) == "x")])

area0_period0 <- reg[reg$area == 0 & reg$period == period_values[1], ]
area0_period1 <- reg[reg$area == 0 & reg$period == period_values[2], ]

n_obs <- 72L
result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = list(
    list(term = "iv_slope", estimate = iv_slope, se = NULL, n_obs = n_obs),
    list(term = "exposure_area0_period0",
         estimate = area0_period0$x[1], se = NULL, n_obs = n_obs),
    list(term = "exposure_area0_period1",
         estimate = area0_period1$x[1], se = NULL, n_obs = n_obs),
    list(term = "instrument_area0_period0",
         estimate = area0_period0$z[1], se = NULL, n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "weighted two-stage least squares",
    outcome = "change_pp",
    endogenous_regressor = "x",
    excluded_instrument = "z",
    exogenous_regressors = c("intercept", "period_indicator", "control"),
    weight = "base-vintage population",
    exposure_units = "thousands of real dollars per worker per decade"
  ),
  diagnostics = list(n_obs = n_obs)
)

write_json(result, "result.json", auto_unbox = TRUE, digits = 15, pretty = TRUE)
