data <- read.csv("./input.csv")
data$group <- as.factor(data$group)

fit <- aov(y ~ group, data = data)
anova_table <- summary(fit)[[1]]

f_stat <- anova_table[["F value"]][1]
df_num <- anova_table[["Df"]][1]
df_den <- anova_table[["Df"]][2]
p_value <- anova_table[["Pr(>F)"]][1]
n_obs <- nobs(fit)

estimates <- data.frame(
  term = c("F", "df_num", "df_den", "p_value"),
  estimate = c(f_stat, df_num, df_den, p_value),
  se = c(NA_real_, NA_real_, NA_real_, NA_real_),
  n_obs = rep(as.integer(n_obs), 4)
)

result <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = lapply(seq_len(nrow(estimates)), function(i) {
    list(
      term = estimates$term[i],
      estimate = estimates$estimate[i],
      se = NULL,
      n_obs = estimates$n_obs[i]
    )
  }),
  method_metadata = list(
    estimator = "One-way ANOVA",
    vcov = "Classical ANOVA"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = 15, null = "null")
