library(jsonlite)

data <- read.csv("input.csv", stringsAsFactors = FALSE)
data$date <- as.Date(data$date)
data <- data[order(data$date), ]

dlog_vix <- c(NA_real_, diff(log(data$vix)))
log_sales <- log(data$sales)

n <- nrow(data)
lag_matrix <- sapply(1:15, function(j) {
  c(rep(NA_real_, j), dlog_vix[seq_len(n - j)])
})
colnames(lag_matrix) <- paste0("lag_", 1:15)

regression_data <- data.frame(log_sales = log_sales, lag_matrix)
sample <- regression_data[complete.cases(regression_data), ]
fit <- lm(log_sales ~ ., data = sample)

X <- model.matrix(fit)
residuals <- residuals(fit)
N <- nrow(X)
p <- ncol(X)
scores <- X * residuals

hac_lags <- 15
meat <- crossprod(scores)
for (j in seq_len(hac_lags)) {
  lag_product <- crossprod(
    scores[(j + 1):N, , drop = FALSE],
    scores[1:(N - j), , drop = FALSE]
  )
  meat <- meat + (1 - j / 16) * (lag_product + t(lag_product))
}

bread <- solve(crossprod(X))
covariance <- (N / (N - 16)) * bread %*% meat %*% bread
coefficients <- coef(fit)

contrast <- c(0, rep(1, 15))
cumulative <- sum(contrast * coefficients)
cumulative_se <- sqrt(drop(t(contrast) %*% covariance %*% contrast))

row <- function(term, estimate, se) {
  list(
    term = term,
    estimate = unname(as.numeric(estimate)),
    se = unname(as.numeric(se)),
    n_obs = as.integer(N)
  )
}

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    row("cumulative_response", cumulative, cumulative_se),
    row("lag_1", coefficients["lag_1"], sqrt(covariance["lag_1", "lag_1"])),
    row("lag_15", coefficients["lag_15"], sqrt(covariance["lag_15", "lag_15"]))
  ),
  method_metadata = list(
    estimator = "OLS with 15 lagged log volatility changes",
    vcov = "Newey-West HAC, Bartlett maximum lag 15, correction N/(N-16)"
  ),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, digits = 16, pretty = TRUE)
