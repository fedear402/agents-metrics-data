library(AER)
library(sandwich)

d <- read.csv("input.csv")

# Collapse the repeated regional variables to one row per region.
regions <- unique(d[c("region_id", "region_weight", "x", "y")])
regions <- regions[order(regions$region_id), ]
regions$e <- regions$region_weight / sum(regions$region_weight)

# Build regional shift-share exposure using all region-industry rows.
z_by_region <- aggregate(
  share * shock ~ region_id,
  data = d,
  FUN = sum
)
names(z_by_region)[2] <- "z"
regions <- merge(regions, z_by_region, by = "region_id", sort = FALSE)

# Remove weighted regional means.
weighted_mean <- function(v, w) sum(w * v) / sum(w)
regions$y0 <- regions$y - weighted_mean(regions$y, regions$e)
regions$x0 <- regions$x - weighted_mean(regions$x, regions$e)
regions$z0 <- regions$z - weighted_mean(regions$z, regions$e)

# Aggregate residuals and regional exposure weights to industries.
industry <- aggregate(
  cbind(
    s = regions$e[match(d$region_id, regions$region_id)] * d$share,
    y_num = regions$e[match(d$region_id, regions$region_id)] * d$share *
      regions$y0[match(d$region_id, regions$region_id)],
    x_num = regions$e[match(d$region_id, regions$region_id)] * d$share *
      regions$x0[match(d$region_id, regions$region_id)],
    z_num = regions$e[match(d$region_id, regions$region_id)] * d$share *
      regions$z0[match(d$region_id, regions$region_id)]
  ),
  by = list(industry_id = d$industry_id, shock = d$shock),
  FUN = sum
)

industry <- industry[industry$s > 0, ]
industry$ybar <- industry$y_num / industry$s
industry$xbar <- industry$x_num / industry$s
industry$zbar <- industry$z_num / industry$s
N <- nrow(industry)

# Shock-level IV estimates with analytic exposure weights and HC1 covariance.
effect_fit <- AER::ivreg(ybar ~ xbar | shock, data = industry, weights = s)
effect_vcov <- sandwich::vcovHC(effect_fit, type = "HC1")
effect <- unname(coef(effect_fit)["xbar"])
effect_se <- sqrt(effect_vcov["xbar", "xbar"])

first_fit <- AER::ivreg(xbar ~ zbar | shock, data = industry, weights = s)
first_vcov <- sandwich::vcovHC(first_fit, type = "HC1")
first_stage <- unname(coef(first_fit)["zbar"])
first_se <- sqrt(first_vcov["zbar", "zbar"])

effective_shocks <- 1 / sum(industry$s^2)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = effect, se = effect_se, n_obs = N),
    list(term = "first_stage", estimate = first_stage, se = first_se, n_obs = N),
    list(term = "effective_shocks", estimate = effective_shocks, se = NULL, n_obs = N)
  ),
  method_metadata = list(
    estimator = "Regional weighted 2SLS with Borusyak-Hull-Jaravel shock-level aggregation",
    vcov = "Shock-level analytic-weight HC1 heteroskedasticity-robust covariance, multiplier N/(N-2)"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = 15, null = "null")
