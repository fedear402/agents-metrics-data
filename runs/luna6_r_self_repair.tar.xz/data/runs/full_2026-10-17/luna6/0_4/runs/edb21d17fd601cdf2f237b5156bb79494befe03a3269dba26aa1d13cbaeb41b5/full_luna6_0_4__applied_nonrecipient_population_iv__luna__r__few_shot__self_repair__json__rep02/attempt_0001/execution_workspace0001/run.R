suppressPackageStartupMessages(library(jsonlite))

households <- read.csv("households.csv")
census <- read.csv("census.csv")

d <- subset(households, recipient == 0)
n_obs <- as.integer(nrow(d))

eligible <- d$eligible
ineligible <- 1 - eligible

X <- cbind(
  ineligible = ineligible,
  eligible = eligible,
  baseline_ineligible = d$baseline * ineligible,
  baseline_eligible = d$baseline * eligible,
  dose_ineligible = d$dose * ineligible,
  dose_eligible = d$dose * eligible
)

Z <- cbind(
  ineligible = ineligible,
  eligible = eligible,
  baseline_ineligible = d$baseline * ineligible,
  baseline_eligible = d$baseline * eligible,
  instrument_ineligible = d$instrument * ineligible,
  instrument_eligible = d$instrument * eligible
)

w_sqrt <- sqrt(d$weight)
Xw <- X * w_sqrt
Zw <- Z * w_sqrt
yw <- d$outcome * w_sqrt

projected_X <- qr.fitted(qr(Zw), Xw)
beta <- as.numeric(qr.coef(qr(projected_X), yw))
names(beta) <- colnames(X)

mean_dose_ineligible <- weighted.mean(d$dose[ineligible == 1], d$weight[ineligible == 1])
mean_dose_eligible <- weighted.mean(d$dose[eligible == 1], d$weight[eligible == 1])

ineligible_effect <- unname(beta["dose_ineligible"] * mean_dose_ineligible)
eligible_nonrecipient_effect <- unname(beta["dose_eligible"] * mean_dose_eligible)

census_weights <- census$nonrecipient_population[
  match(c(0, 1), census$eligible)
]
population_effect <- weighted.mean(
  c(ineligible_effect, eligible_nonrecipient_effect),
  census_weights
)

estimates <- list(
  list(term = "ineligible_effect", estimate = ineligible_effect, se = NULL, n_obs = n_obs),
  list(term = "eligible_nonrecipient_effect", estimate = eligible_nonrecipient_effect, se = NULL, n_obs = n_obs),
  list(term = "population_effect", estimate = population_effect, se = NULL, n_obs = n_obs)
)

result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    method = "Weighted 2SLS",
    sample = "All households with recipient equal to zero",
    endogenous_columns = c("dose*(1-eligible)", "dose*eligible"),
    exogenous_columns = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"),
    instruments = c(
      "1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible",
      "instrument*(1-eligible)", "instrument*eligible"
    ),
    counterfactual = "Set dose to zero for every retained household",
    effect_convention = "Each group effect equals its fitted dose slope times its weighted mean dose"
  ),
  diagnostics = list(
    n_obs = n_obs,
    census_group_counts = as.list(setNames(
      as.integer(census_weights),
      c("ineligible", "eligible")
    )),
    attribution_convention = "Attribution to a zero-dose counterfactual is a stated synthetic convention"
  )
)

write_json(result, "result.json", auto_unbox = TRUE, digits = 12, null = "null", pretty = TRUE)
