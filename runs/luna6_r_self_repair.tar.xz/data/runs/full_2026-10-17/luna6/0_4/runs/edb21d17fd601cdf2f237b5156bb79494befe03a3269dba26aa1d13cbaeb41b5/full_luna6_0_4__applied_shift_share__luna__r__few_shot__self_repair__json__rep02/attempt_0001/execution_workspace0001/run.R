library(jsonlite)

dat <- read.csv("input.csv", stringsAsFactors = FALSE)

required <- c("region_id", "industry_id", "share", "shock",
              "region_weight", "x", "y")
if (!all(required %in% names(dat))) stop("input.csv is missing required columns")

region_ids <- unique(dat$region_id)
industry_ids <- unique(dat$industry_id)

# Use one row per region to normalize regional weights and read regional values.
region_data <- dat[match(region_ids, dat$region_id),
                   c("region_id", "region_weight", "x", "y")]
e <- region_data$region_weight / sum(region_data$region_weight)

# Build the region by industry share matrix and verify shocks are industry-specific.
shares <- matrix(0, nrow = length(region_ids), ncol = length(industry_ids),
                 dimnames = list(as.character(region_ids), as.character(industry_ids)))
row_index <- match(dat$region_id, region_ids)
col_index <- match(dat$industry_id, industry_ids)
shares[cbind(row_index, col_index)] <- dat$share

shock_by_industry <- vapply(industry_ids, function(id) {
  vals <- unique(dat$shock[dat$industry_id == id])
  if (length(vals) != 1L) stop("shock must be constant within industry")
  vals
}, numeric(1))

if (any(abs(rowSums(shares) - 1) > 1e-8)) {
  stop("baseline employment shares must sum to one within each region")
}

z <- drop(shares %*% shock_by_industry)
regional <- cbind(y = region_data$y, x = region_data$x, z = z)
regional_means <- drop(crossprod(e, regional))
regional0 <- sweep(regional, 2, regional_means, FUN = "-")

industry_mass <- drop(crossprod(e, shares))
if (any(industry_mass <= 0)) stop("each included industry must have positive exposure mass")

aggregate_residual <- function(v0) {
  drop(crossprod(shares, e * v0)) / industry_mass
}

ybar <- aggregate_residual(regional0[, "y"])
xbar <- aggregate_residual(regional0[, "x"])
zbar <- aggregate_residual(regional0[, "z"])

# Weighted IV with an intercept. Compute HC1 from structural IV residuals.
shock_iv <- function(dependent, endogenous, instrument, weights, n_industries) {
  X <- cbind(intercept = 1, endogenous = endogenous)
  Q <- cbind(intercept = 1, instrument = instrument)

  cross <- crossprod(Q, weights * X)
  beta <- solve(cross, crossprod(Q, weights * dependent))
  residual <- drop(dependent - X %*% beta)

  scores <- Q * (weights * residual)
  inverse <- solve(cross)
  covariance <- (n_industries / (n_industries - 2)) *
    inverse %*% crossprod(scores) %*% t(inverse)

  c(slope = beta[2], se = sqrt(covariance[2, 2]))
}

n_industries <- length(industry_ids)
if (n_industries <= 2L) stop("HC1 variance requires more than two industries")

effect <- shock_iv(ybar, xbar, shock_by_industry,
                   industry_mass, n_industries)
first_stage <- shock_iv(xbar, zbar, shock_by_industry,
                        industry_mass, n_industries)

effective_shocks <- 1 / sum(industry_mass^2)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = unname(effect["slope"]),
         se = unname(effect["se"]), n_obs = as.integer(n_industries)),
    list(term = "first_stage", estimate = unname(first_stage["slope"]),
         se = unname(first_stage["se"]), n_obs = as.integer(n_industries)),
    list(term = "effective_shocks", estimate = unname(effective_shocks),
         se = NULL, n_obs = as.integer(n_industries))
  ),
  method_metadata = list(
    estimator = "Weighted 2SLS with Borusyak-Hull-Jaravel shock-level aggregation",
    vcov = "Shock-level HC1 with structural IV residuals and analytic weights"
  ),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null",
           digits = 16, pretty = TRUE)
