households <- read.csv("households.csv")
census <- read.csv("census.csv")

d <- subset(households, recipient == 0)
n_obs <- nrow(d)

eligible <- d$eligible
ineligible <- 1 - eligible

X <- cbind(
  ineligible,
  eligible,
  d$baseline * ineligible,
  d$baseline * eligible,
  d$dose * ineligible,
  d$dose * eligible
)

Z <- cbind(
  ineligible,
  eligible,
  d$baseline * ineligible,
  d$baseline * eligible,
  d$instrument * ineligible,
  d$instrument * eligible
)

sqrt_weight <- sqrt(d$weight)
Xw <- X * sqrt_weight
Zw <- Z * sqrt_weight
yw <- d$outcome * sqrt_weight

projected_X <- qr.fitted(qr(Zw), Xw)
coefficients <- qr.coef(qr(projected_X), yw)
dose_slopes <- coefficients[5:6]

mean_dose <- vapply(0:1, function(group) {
  rows <- d$eligible == group
  weighted.mean(d$dose[rows], d$weight[rows])
}, numeric(1))

group_effects <- dose_slopes * mean_dose
population_counts <- census$nonrecipient_population[
  match(0:1, census$eligible)
]
population_effect <- weighted.mean(group_effects, population_counts)

estimates <- list(
  list(term = "ineligible_effect", estimate = unname(group_effects[1]),
       se = NULL, n_obs = as.integer(n_obs)),
  list(term = "eligible_nonrecipient_effect", estimate = unname(group_effects[2]),
       se = NULL, n_obs = as.integer(n_obs)),
  list(term = "population_effect", estimate = unname(population_effect),
       se = NULL, n_obs = as.integer(n_obs))
)

result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "weighted 2SLS",
    sample = "All households with recipient equal to zero",
    endogenous_columns = c("dose*(1-eligible)", "dose*eligible"),
    exogenous_columns = c(
      "1-eligible", "eligible",
      "baseline*(1-eligible)", "baseline*eligible"
    ),
    instruments = c(
      "1-eligible", "eligible",
      "baseline*(1-eligible)", "baseline*eligible",
      "instrument*(1-eligible)", "instrument*eligible"
    ),
    group_effect_definition =
      "Fitted group dose slope multiplied by the household-weighted mean dose in that group",
    counterfactual =
      "Synthetic convention: set dose to zero for every retained household",
    census_use = "Census counts determine only the final between-group weights"
  ),
  diagnostics = list(
    n_obs = as.integer(n_obs),
    retained_households = as.integer(n_obs)
  )
)

jsonlite::write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  digits = 15,
  pretty = TRUE,
  null = "null"
)
