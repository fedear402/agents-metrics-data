d <- read.csv("input.csv")

region_cols <- c("region_id", "region_weight", "x", "y")
regions <- unique(d[region_cols])
regions <- regions[order(regions$region_id), ]
e <- regions$region_weight / sum(regions$region_weight)

regions$z <- vapply(regions$region_id, function(r) {
  rows <- d[d$region_id == r, ]
  sum(rows$share * rows$shock)
}, numeric(1))

weighted_demean <- function(v, w) v - sum(w * v) / sum(w)
regions$y0 <- weighted_demean(regions$y, e)
regions$x0 <- weighted_demean(regions$x, e)
regions$z0 <- weighted_demean(regions$z, e)

industries <- sort(unique(d$industry_id))
shock_data <- data.frame(industry_id = industries)
shock_data$shock <- vapply(industries, function(n) {
  unique(d$shock[d$industry_id == n])[1]
}, numeric(1))
shock_data$s <- vapply(industries, function(n) {
  sum(e[match(unique(d$region_id[d$industry_id == n]), regions$region_id)] *
        d$share[d$industry_id == n])
}, numeric(1))

aggregate_residual <- function(v0) {
  vapply(industries, function(n) {
    rows <- d[d$industry_id == n, ]
    ri <- match(rows$region_id, regions$region_id)
    sum(e[ri] * rows$share * v0[ri]) / shock_data$s[match(n, industries)]
  }, numeric(1))
}
shock_data$ybar <- aggregate_residual(regions$y0)
shock_data$xbar <- aggregate_residual(regions$x0)
shock_data$zbar <- aggregate_residual(regions$z0)

weighted_iv_hc1 <- function(data, outcome, endogenous, instrument, weights) {
  # Weighted 2SLS with one endogenous regressor, an intercept, and one instrument.
  w <- weights / sum(weights)
  X <- cbind(1, data[[endogenous]])
  Z <- cbind(1, data[[instrument]])
  y <- data[[outcome]]
  A <- crossprod(Z, Z * w)
  B <- crossprod(Z, X * w)
  beta <- solve(B, solve(A, crossprod(Z, y * w)))
  resid <- as.vector(y - X %*% beta)
  bread <- solve(crossprod(B, solve(A, B)))
  score <- Z * as.vector(w * resid)
  meat <- crossprod(score)
  # HC1 correction for the number of shock-level observations.
  vc <- bread %*% crossprod(B, solve(A, meat %*% solve(A, B))) %*% bread
  # Equivalent direct sandwich in the weighted 2SLS moment space.
  G <- crossprod(Z, X * w)
  H <- crossprod(Z, Z * w)
  middle <- solve(H) %*% crossprod(Z, diag(w) %*% diag(resid^2) %*% diag(w) %*% Z) %*% solve(H)
  v <- solve(G %*% solve(H) %*% t(G)) %*% G %*% solve(H) %*% middle %*%
       solve(H) %*% t(G) %*% solve(G %*% solve(H) %*% t(G))
  # Use the analytic-weight HC1 sandwich, with structural IV residuals.
  vcov_hc1 <- v * nrow(data) / (nrow(data) - 2)
  list(beta = as.vector(beta), vcov = vcov_hc1)
}

# Equivalent shock-level regressions use the stated analytic weights.
fit_effect <- weighted_iv_hc1(shock_data, "ybar", "xbar", "shock", shock_data$s)
fit_first <- weighted_iv_hc1(shock_data, "xbar", "zbar", "shock", shock_data$s)

N <- nrow(shock_data)
effective_shocks <- 1 / sum(shock_data$s^2)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = fit_effect$beta[2],
         se = sqrt(fit_effect$vcov[2, 2]), n_obs = N),
    list(term = "first_stage", estimate = fit_first$beta[2],
         se = sqrt(fit_first$vcov[2, 2]), n_obs = N),
    list(term = "effective_shocks", estimate = effective_shocks,
         se = NULL, n_obs = N)
  ),
  method_metadata = list(
    estimator = "Weighted 2SLS with intercept; Borusyak-Hull-Jaravel shock-level aggregation",
    vcov = "Shock-level structural-residual analytic-weight HC1, no clustering"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = 16, null = "null")
