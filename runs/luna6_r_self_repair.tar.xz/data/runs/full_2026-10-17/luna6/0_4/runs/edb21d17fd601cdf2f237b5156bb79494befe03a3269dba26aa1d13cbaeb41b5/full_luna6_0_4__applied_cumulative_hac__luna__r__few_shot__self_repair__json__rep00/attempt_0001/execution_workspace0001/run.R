library(jsonlite)

data <- read.csv("input.csv", stringsAsFactors = FALSE)
data$date <- as.Date(data$date)
data <- data[order(data$date), ]

log_vix <- log(data$vix)
vol_change <- c(NA_real_, diff(log_vix))
log_sales <- log(data$sales)

n <- nrow(data)
max_lag <- 15L
changes <- lapply(seq_len(max_lag), function(j) {
  c(rep(NA_real_, j + 1L), vol_change[seq_len(n - j - 1L)])
})
names(changes) <- paste0("lag_", seq_len(max_lag))

reg_data <- data.frame(log_sales = log_sales, changes, check.names = FALSE)
sample <- reg_data[complete.cases(reg_data), ]
fit <- lm(log_sales ~ ., data = sample)
X <- model.matrix(fit)
residuals <- residuals(fit)
N <- nrow(X)
p <- ncol(X)

scores <- X * residuals
meat <- crossprod(scores)
for (j in seq_len(max_lag)) {
  lag_product <- crossprod(
    scores[(j + 1L):N, , drop = FALSE],
    scores[seq_len(N - j), , drop = FALSE]
  )
  weight <- 1 - j / 16
  meat <- meat + weight * (lag_product + t(lag_product))
}
bread <- solve(crossprod(X))
covariance <- (N / (N - 16)) * bread %*% meat %*% bread

coefficients <- coef(fit)
contrast <- c(0, rep(1, max_lag))
cumulative_response <- sum(contrast * coefficients)
cumulative_se <- sqrt(drop(t(contrast) %*% covariance %*% contrast))

rows <- list(
  list(term = "cumulative_response",
       estimate = unname(as.numeric(cumulative_response)),
       se = unname(as.numeric(cumulative_se)), n_obs = as.integer(N)),
  list(term = "lag_1",
       estimate = unname(as.numeric(coefficients["lag_1"])),
       se = unname(as.numeric(sqrt(covariance["lag_1", "lag_1"]))),
       n_obs = as.integer(N)),
  list(term = "lag_15",
       estimate = unname(as.numeric(coefficients["lag_15"])),
       se = unname(as.numeric(sqrt(covariance["lag_15", "lag_15"]))),
       n_obs = as.integer(N))
)

write_json(
  list(
    task_id = "applied_cumulative_hac",
    platform = "r",
    estimates = rows,
    method_metadata = list(
      estimator = "OLS with intercept and 15 trading-observation lags of log VIX changes",
      vcov = "Newey-West HAC, Bartlett maximum lag 15, finite-sample correction N/(N-16)"
    ),
    diagnostics = list()
  ),
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
