households <- read.csv("households.csv")
census <- read.csv("census.csv")

d <- subset(households, recipient == 0)
n_obs <- nrow(d)

eligible <- d$eligible
dose_ineligible <- d$dose * (1 - eligible)
dose_eligible <- d$dose * eligible

X <- cbind(
  ineligible = 1 - eligible,
  eligible = eligible,
  baseline_ineligible = d$baseline * (1 - eligible),
  baseline_eligible = d$baseline * eligible,
  dose_ineligible = dose_ineligible,
  dose_eligible = dose_eligible
)

Z <- cbind(
  ineligible = 1 - eligible,
  eligible = eligible,
  baseline_ineligible = d$baseline * (1 - eligible),
  baseline_eligible = d$baseline * eligible,
  instrument_ineligible = d$instrument * (1 - eligible),
  instrument_eligible = d$instrument * eligible
)

sqrt_weight <- sqrt(d$weight)
X_weighted <- X * sqrt_weight
Z_weighted <- Z * sqrt_weight
y_weighted <- d$outcome * sqrt_weight

projected_X <- qr.fitted(qr(Z_weighted), X_weighted)
iv_coefficients <- qr.coef(qr(projected_X), y_weighted)
slope_ineligible <- unname(iv_coefficients["dose_ineligible"])
slope_eligible <- unname(iv_coefficients["dose_eligible"])

mean_dose_ineligible <- weighted.mean(
  d$dose[eligible == 0],
  d$weight[eligible == 0]
)
mean_dose_eligible <- weighted.mean(
  d$dose[eligible == 1],
  d$weight[eligible == 1]
)

ineligible_effect <- slope_ineligible * mean_dose_ineligible
eligible_nonrecipient_effect <- slope_eligible * mean_dose_eligible

census_weights <- census$nonrecipient_population[
  match(c(0, 1), census$eligible)
]
population_effect <- weighted.mean(
  c(ineligible_effect, eligible_nonrecipient_effect),
  census_weights
)

estimates <- list(
  list(term = "ineligible_effect", estimate = unname(ineligible_effect),
       se = NULL, n_obs = as.integer(n_obs)),
  list(term = "eligible_nonrecipient_effect",
       estimate = unname(eligible_nonrecipient_effect),
       se = NULL, n_obs = as.integer(n_obs)),
  list(term = "population_effect", estimate = unname(population_effect),
       se = NULL, n_obs = as.integer(n_obs))
)

result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    method = "Weighted 2SLS with eligibility-specific dose slopes",
    exogenous_columns = c(
      "1-eligible", "eligible",
      "baseline*(1-eligible)", "baseline*eligible"
    ),
    endogenous_columns = c(
      "dose*(1-eligible)", "dose*eligible"
    ),
    excluded_instruments = c(
      "instrument*(1-eligible)", "instrument*eligible"
    ),
    effect_convention =
      "Each group effect is its fitted dose slope times its weighted mean dose; attribution to a zero-dose counterfactual is a synthetic convention.",
    aggregation =
      "Census nonrecipient counts determine only the final between-group weights."
  ),
  diagnostics = list(
    n_obs = as.integer(n_obs),
    recipient_filter = 0L,
    census_count_total = sum(census$nonrecipient_population)
  )
)

jsonlite::write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  pretty = TRUE,
  digits = 15,
  null = "null"
)
