d <- read.csv("input.csv")
n <- nrow(d)

# Restricted model: y - beta*endog on intercept and x.
ry <- residuals(lm(y ~ x, data = d))
rd <- residuals(lm(endog ~ x, data = d))

# Unrestricted model adds both excluded instruments.
full_y <- lm(y ~ x + z1 + z2, data = d)
full_d <- lm(endog ~ x + z1 + z2, data = d)
uy <- residuals(full_y)
ud <- residuals(full_d)

q <- 2L
df <- n - 4L
critical <- qf(0.95, q, df)
k <- q * critical / df

A <- sum(rd^2) - (1 + k) * sum(ud^2)
B <- -2 * (sum(ry * rd) - (1 + k) * sum(uy * ud))
C <- sum(ry^2) - (1 + k) * sum(uy^2)

disc <- B^2 - 4 * A * C
if (!is.finite(disc) || disc < 0 || abs(A) < .Machine$double.eps) {
  stop("Expected two finite boundary points.")
}
bounds <- sort(c((-B - sqrt(disc)) / (2 * A),
                 (-B + sqrt(disc)) / (2 * A)))

accepts <- function(beta) A * beta^2 + B * beta + C <= 0

transformed_one <- d$y - d$endog
restricted_one <- lm(transformed_one ~ x, data = d)
full_one <- lm(transformed_one ~ x + z1 + z2, data = d)
ar_f_at_one <- ((deviance(restricted_one) - deviance(full_one)) / q) /
  (deviance(full_one) / df)

rows <- list(
  list(term = "boundary_low", estimate = unname(bounds[1]), se = NULL, n_obs = n),
  list(term = "boundary_high", estimate = unname(bounds[2]), se = NULL, n_obs = n),
  list(term = "accepts_zero", estimate = as.integer(accepts(0)), se = NULL, n_obs = n),
  list(term = "unbounded", estimate = as.integer(A < 0), se = NULL, n_obs = n),
  list(term = "ar_f_at_one", estimate = unname(ar_f_at_one), se = NULL, n_obs = n)
)

jsonlite::write_json(
  list(
    task_id = "broad_ar_confidence_set",
    platform = "r",
    estimates = rows,
    method_metadata = list(
      estimator = "Anderson-Rubin confidence set by inversion of homoskedastic joint F test",
      vcov = "Conventional homoskedastic"
    ),
    diagnostics = list()
  ),
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
