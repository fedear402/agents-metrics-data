d <- read.csv("input.csv")

required <- c("y", "endog", "x", "z1", "z2")
if (!all(required %in% names(d))) stop("input.csv is missing required columns")
if (any(!complete.cases(d[required]))) stop("Required columns contain missing values")

n <- nrow(d)
q <- 2L
df <- n - 4L
if (df <= 0L) stop("Insufficient residual degrees of freedom")

critical <- qf(0.95, df1 = q, df2 = df)
k <- q * critical / df

# Residualize against the included regressors: intercept and x.
W <- model.matrix(~ x, data = d)
resid_on_W <- function(v) qr.resid(qr(W), v)

ry <- resid_on_W(d$y)
rd <- resid_on_W(d$endog)

# Add z1 and z2 to the included regressors for the unrestricted fit.
U <- model.matrix(~ x + z1 + z2, data = d)
uy <- qr.resid(qr(U), d$y)
ud <- qr.resid(qr(U), d$endog)

A <- sum(rd^2) - (1 + k) * sum(ud^2)
B <- -2 * (sum(ry * rd) - (1 + k) * sum(uy * ud))
C <- sum(ry^2) - (1 + k) * sum(uy^2)

disc <- B^2 - 4 * A * C
if (!is.finite(A) || !is.finite(B) || !is.finite(C) ||
    abs(A) < 1e-12 || disc <= 0) {
  stop("The AR confidence set does not have two distinct finite boundaries")
}

bounds <- sort(c((-B - sqrt(disc)) / (2 * A),
                 (-B + sqrt(disc)) / (2 * A)))

accepts <- function(beta) A * beta^2 + B * beta + C <= 0
unbounded <- as.integer(A < 0)

# Compute the joint F statistic at beta = 1 by comparing restricted and
# unrestricted residual sums of squares in the regression of y - endog.
v1 <- d$y - d$endog
ssr_r <- sum(resid_on_W(v1)^2)
ssr_u <- sum(qr.resid(qr(U), v1)^2)
f_one <- ((ssr_r - ssr_u) / q) / (ssr_u / df)

rows <- list(
  list(term = "boundary_low", estimate = unname(bounds[1]), se = NULL, n_obs = n),
  list(term = "boundary_high", estimate = unname(bounds[2]), se = NULL, n_obs = n),
  list(term = "accepts_zero", estimate = as.integer(accepts(0)), se = NULL, n_obs = n),
  list(term = "unbounded", estimate = unbounded, se = NULL, n_obs = n),
  list(term = "ar_f_at_one", estimate = unname(f_one), se = NULL, n_obs = n)
)

jsonlite::write_json(
  list(
    task_id = "broad_ar_confidence_set",
    platform = "r",
    estimates = rows,
    method_metadata = list(
      estimator = "Anderson-Rubin inversion with homoskedastic joint F test",
      vcov = "Conventional homoskedastic"
    ),
    diagnostics = list(
      numerator_df = q,
      denominator_df = df,
      critical_value = critical,
      quadratic_A = A,
      quadratic_B = B,
      quadratic_C = C,
      discriminant = disc
    )
  ),
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
