dat <- read.csv("./input.csv")
if (!"y" %in% names(dat)) stop("input.csv must contain column y")

y <- as.numeric(dat$y)
if (anyNA(y) || length(y) < 3L) stop("y must contain at least three non-missing observations")

fit <- stats::arima(
  y,
  order = c(1, 1, 1),
  include.mean = FALSE,
  method = "ML"
)

fc <- stats::predict(fit, n.ahead = 1L)
forecast <- as.numeric(fc$pred[1L])
se <- as.numeric(fc$se[1L])
z <- stats::qnorm(0.975)

estimates <- list(
  list(term = "forecast", estimate = forecast, se = se, n_obs = length(y)),
  list(term = "lower_95", estimate = forecast - z * se, se = NULL, n_obs = length(y)),
  list(term = "upper_95", estimate = forecast + z * se, se = NULL, n_obs = length(y))
)

result <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = estimates,
  method_metadata = list(estimator = "ARIMA(1,1,1) maximum likelihood, no constant or drift", vcov = "Model-based one-step-ahead forecast variance"),
  diagnostics = list(log_likelihood = as.numeric(stats::logLik(fit)))
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = 15, na = "null")
