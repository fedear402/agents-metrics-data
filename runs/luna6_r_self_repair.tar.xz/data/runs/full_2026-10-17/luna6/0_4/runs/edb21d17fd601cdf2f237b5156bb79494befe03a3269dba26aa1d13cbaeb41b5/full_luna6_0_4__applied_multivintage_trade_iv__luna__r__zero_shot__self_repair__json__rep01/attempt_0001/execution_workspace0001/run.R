library(jsonlite)

crosswalk <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
trade <- read.csv("trade.csv", stringsAsFactors = FALSE)
areas <- read.csv("areas.csv", stringsAsFactors = FALSE)
employment <- read.csv("employment.csv", stringsAsFactors = FALSE)
outcomes <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

trade <- merge(trade, crosswalk, by = "code", all.x = TRUE, sort = FALSE)

make_exposure <- function(area_row, period_trade, emp_data, area_data,
                          employment_vintage, change_column) {
  area <- area_row$area
  period <- area_row$period

  period_areas <- area_data[
    area_data$period == period & area_data$vintage == employment_vintage, ,
    drop = FALSE
  ]
  period_emp <- emp_data[
    emp_data$period == period & emp_data$vintage == employment_vintage, ,
    drop = FALSE
  ]

  value <- 0
  for (i in seq_len(nrow(period_trade))) {
    industry <- period_trade$industry[i]
    national_base <- sum(
      period_emp$employment[period_emp$industry == industry],
      na.rm = TRUE
    )
    area_industry <- sum(
      period_emp$employment[
        period_emp$area == area & period_emp$industry == industry
      ],
      na.rm = TRUE
    )
    area_total <- area_row$total_employment
    price <- period_trade$price_index[i]
    years <- period_trade$years[i]
    trade_change <- period_trade[[change_column]][i]

    value <- value +
      (area_industry / area_total) *
      (trade_change / national_base) /
      (price / 100) / 1000 * (10 / years)
  }
  value
}

base_areas <- areas[areas$vintage == "base", , drop = FALSE]
early_areas <- areas[areas$vintage == "early", , drop = FALSE]

base_areas$x <- NA_real_
base_areas$z <- NA_real_

for (i in seq_len(nrow(base_areas))) {
  p_trade <- trade[trade$period == base_areas$period[i], , drop = FALSE]
  base_areas$x[i] <- make_exposure(
    base_areas[i, ], p_trade, employment, areas, "base", "us_change"
  )
  early_row <- early_areas[
    early_areas$area == base_areas$area[i] &
      early_areas$period == base_areas$period[i], ,
    drop = FALSE
  ]
  base_areas$z[i] <- make_exposure(
    early_row[1, ], p_trade, employment, areas, "early", "other_change"
  )
}

data <- merge(
  base_areas, outcomes,
  by = c("area", "period"),
  all = FALSE,
  sort = FALSE
)
data$period_indicator <- as.numeric(data$period == sort(unique(data$period))[2])

# Weighted 2SLS: regress x on all exogenous regressors and z, then use
# the fitted exposure in the weighted outcome regression.
w <- data$population
exogenous <- model.matrix(~ period_indicator + control, data = data)
instrument_matrix <- cbind(exogenous, z = data$z)
weighted_fit <- function(y, X, weights) {
  solve(crossprod(X, X * weights), crossprod(X, y * weights))
}
first_stage <- weighted_fit(data$x, instrument_matrix, w)
x_hat <- as.vector(instrument_matrix %*% first_stage)
second_stage_matrix <- cbind(exogenous, x = x_hat)
second_stage <- weighted_fit(data$change_pp, second_stage_matrix, w)
iv_slope <- unname(second_stage[ncol(second_stage)])

area0_period0 <- data$x[data$area == 0 & data$period == sort(unique(data$period))[1]]
area0_period1 <- data$x[data$area == 0 & data$period == sort(unique(data$period))[2]]
instrument_area0_period0 <- data$z[data$area == 0 & data$period == sort(unique(data$period))[1]]

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = list(
    list(term = "iv_slope", estimate = as.numeric(iv_slope), se = NULL, n_obs = 72L),
    list(term = "exposure_area0_period0", estimate = as.numeric(area0_period0), se = NULL, n_obs = 72L),
    list(term = "exposure_area0_period1", estimate = as.numeric(area0_period1), se = NULL, n_obs = 72L),
    list(term = "instrument_area0_period0", estimate = as.numeric(instrument_area0_period0), se = NULL, n_obs = 72L)
  ),
  method_metadata = list(
    estimator = "population-weighted two-stage least squares",
    outcome = "change_pp",
    endogenous_regressor = "x",
    instrument = "z",
    exogenous_regressors = c("intercept", "period", "control"),
    weight = "base-vintage population",
    exposure_units = "thousands of real dollars per worker per decade"
  ),
  diagnostics = list(n_obs = 72L)
)

write_json(result, "result.json", auto_unbox = TRUE, digits = 17, null = "null")
