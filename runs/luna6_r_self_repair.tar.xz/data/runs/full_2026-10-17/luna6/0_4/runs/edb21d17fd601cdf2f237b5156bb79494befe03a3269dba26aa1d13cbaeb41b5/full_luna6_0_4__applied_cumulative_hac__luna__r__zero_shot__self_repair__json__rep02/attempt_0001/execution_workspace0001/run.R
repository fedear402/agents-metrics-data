dat <- read.csv("input.csv", stringsAsFactors = FALSE)
dat$date <- as.Date(dat$date)
dat <- dat[order(dat$date), ]

dlog_vix <- diff(log(dat$vix))
log_sales <- log(dat$sales)

n <- length(log_sales)
lag_matrix <- sapply(1:15, function(k) {
  c(rep(NA_real_, k + 1L), dlog_vix[seq_len(n - k - 1L)])
})
colnames(lag_matrix) <- paste0("lag_", 1:15)

reg_data <- data.frame(log_sales = log_sales, lag_matrix)
reg_data <- reg_data[complete.cases(reg_data), ]
fit <- lm(log_sales ~ ., data = reg_data)

X <- model.matrix(fit)
u <- residuals(fit)
N <- nrow(X)
bread <- solve(crossprod(X))
scores <- X * as.numeric(u)
meat <- crossprod(scores)

max_lag <- 15L
for (j in seq_len(max_lag)) {
  weight <- 1 - j / 16
  gamma <- crossprod(scores[(j + 1L):N, , drop = FALSE],
                     scores[seq_len(N - j), , drop = FALSE])
  meat <- meat + weight * (gamma + t(gamma))
}

vcov_nw <- (N / (N - 16)) * bread %*% meat %*% bread
coefs <- coef(fit)
cum_weights <- setNames(rep(0, length(coefs)), names(coefs))
cum_weights[paste0("lag_", 1:15)] <- 1

estimates <- list(
  list(term = "cumulative_response",
       estimate = unname(sum(coefs[paste0("lag_", 1:15)])),
       se = unname(sqrt(drop(t(cum_weights) %*% vcov_nw %*% cum_weights))),
       n_obs = as.integer(N)),
  list(term = "lag_1",
       estimate = unname(coefs["lag_1"]),
       se = unname(sqrt(vcov_nw["lag_1", "lag_1"])),
       n_obs = as.integer(N)),
  list(term = "lag_15",
       estimate = unname(coefs["lag_15"]),
       se = unname(sqrt(vcov_nw["lag_15", "lag_15"])),
       n_obs = as.integer(N))
)

if (requireNamespace("jsonlite", quietly = TRUE)) {
  jsonlite::write_json(
    list(
      task_id = "applied_cumulative_hac",
      platform = "r",
      estimates = estimates,
      method_metadata = list(
        estimator = "OLS of log(sales) on intercept and lags 1 through 15 of first differences in log(vix)",
        vcov = "Newey-West HAC, Bartlett weights, maximum lag 15, covariance scaled by N/(N-16)"
      ),
      diagnostics = list()
    ),
    "result.json", auto_unbox = TRUE, digits = 16, na = "null"
  )
} else {
  stop("The jsonlite package is required to write result.json.")
}
