library(jsonlite)

data <- read.csv("input.csv", stringsAsFactors = FALSE)
data$date <- as.Date(data$date)
data <- data[order(data$date), ]

log_vix <- log(data$vix)
volatility_change <- c(NA_real_, diff(log_vix))
log_sales <- log(data$sales)

n <- nrow(data)
lagged_changes <- sapply(1:15, function(j) {
  c(rep(NA_real_, j), volatility_change[seq_len(n - j)])
})
colnames(lagged_changes) <- paste0("lag_", 1:15)

regression_data <- data.frame(log_sales = log_sales, lagged_changes)
sample <- regression_data[complete.cases(regression_data), ]

fit <- lm(log_sales ~ ., data = sample)
X <- model.matrix(fit)
beta <- coef(fit)
N <- nrow(X)
p <- ncol(X)

scores <- X * as.numeric(residuals(fit))
meat <- crossprod(scores)
for (j in 1:15) {
  lag_product <- crossprod(
    scores[(j + 1):N, , drop = FALSE],
    scores[1:(N - j), , drop = FALSE]
  )
  meat <- meat + (1 - j / 16) * (lag_product + t(lag_product))
}

bread <- solve(crossprod(X))
covariance <- (N / (N - 16)) * bread %*% meat %*% bread

contrast <- c(0, rep(1, 15))
cumulative_response <- sum(contrast * beta)
cumulative_se <- sqrt(drop(t(contrast) %*% covariance %*% contrast))

estimates <- list(
  list(term = "cumulative_response",
       estimate = unname(as.numeric(cumulative_response)),
       se = unname(as.numeric(cumulative_se)), n_obs = as.integer(N)),
  list(term = "lag_1",
       estimate = unname(as.numeric(beta["lag_1"])),
       se = unname(as.numeric(sqrt(covariance["lag_1", "lag_1"]))),
       n_obs = as.integer(N)),
  list(term = "lag_15",
       estimate = unname(as.numeric(beta["lag_15"])),
       se = unname(as.numeric(sqrt(covariance["lag_15", "lag_15"]))),
       n_obs = as.integer(N))
)

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "OLS with 15 observed-row lags of log volatility changes",
    vcov = "Bartlett Newey-West HAC, maximum lag 15, finite-sample correction N/(N-16)"
  ),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, digits = 16, pretty = TRUE)
