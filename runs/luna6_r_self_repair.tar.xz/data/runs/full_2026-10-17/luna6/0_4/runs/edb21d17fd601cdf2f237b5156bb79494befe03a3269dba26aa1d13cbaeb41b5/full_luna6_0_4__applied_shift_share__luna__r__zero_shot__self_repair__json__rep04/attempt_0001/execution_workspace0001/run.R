dat <- read.csv("input.csv", check.names = FALSE)

required <- c("region_id", "industry_id", "share", "shock",
              "region_weight", "x", "y")
if (!all(required %in% names(dat))) stop("input.csv is missing required columns")

# Reduce to one row per region and industry, and verify region-level values.
key <- paste(dat$region_id, dat$industry_id, sep = "\r")
d <- dat[!duplicated(key), required]
regions <- unique(d$region_id)

same_within_region <- function(v) {
  all(vapply(split(v, d$region_id), function(a) length(unique(a)) == 1L,
             logical(1)))
}
if (!all(vapply(c("region_weight", "x", "y"), function(nm) {
  same_within_region(d[[nm]])
}, logical(1)))) {
  stop("region_weight, x, and y must be constant within region")
}
if (!all(vapply(split(d$shock, d$industry_id), function(a) {
  length(unique(a)) == 1L
}, logical(1)))) stop("shock must be constant within industry")

# Make the region and industry arrays explicit.
rdat <- d[!duplicated(d$region_id),
          c("region_id", "region_weight", "x", "y")]
rdat <- rdat[match(regions, rdat$region_id), ]
rdat$e <- rdat$region_weight / sum(rdat$region_weight)

industries <- unique(d$industry_id)
shocks <- d$shock[match(industries, d$industry_id)]
S <- matrix(0, nrow = length(regions), ncol = length(industries),
            dimnames = list(as.character(regions), as.character(industries)))
ri <- match(d$region_id, regions)
ni <- match(d$industry_id, industries)
S[cbind(ri, ni)] <- d$share

if (any(abs(rowSums(S) - 1) > 1e-8)) stop("shares must sum to one by region")

e <- rdat$e
x <- rdat$x
y <- rdat$y
z <- drop(S %*% shocks)

weighted_center <- function(v) v - sum(e * v)
x0 <- weighted_center(x)
y0 <- weighted_center(y)
z0 <- weighted_center(z)

s <- drop(crossprod(e, S))
aggregate_residual <- function(v0) {
  drop(crossprod(e * v0, S)) / s
}
xbar <- aggregate_residual(x0)
ybar <- aggregate_residual(y0)
zbar <- aggregate_residual(z0)

N <- length(industries)
if (N <= 2L) stop("at least three industries are required for HC1")

# Shock-level analytic-weight IV and its HC1 structural-residual variance.
shock_iv <- function(outcome, endogenous, instrument) {
  X <- cbind("(Intercept)" = 1, endogenous = endogenous)
  Q <- cbind("(Intercept)" = 1, instrument = instrument)
  WQ <- Q * s
  A <- crossprod(Q, X * s)
  b <- solve(A, crossprod(Q, outcome * s))
  residual <- drop(outcome - X %*% b)
  meat <- crossprod(Q, Q * (s^2 * residual^2))
  bread <- solve(A)
  V <- (N / (N - 2)) * bread %*% meat %*% t(bread)
  list(slope = unname(b[2]), se = sqrt(V[2, 2]))
}

effect <- shock_iv(ybar, xbar, shocks)
first_stage <- shock_iv(xbar, zbar, shocks)
effective_shocks <- 1 / sum(s^2)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = effect$slope, se = effect$se, n_obs = N),
    list(term = "first_stage", estimate = first_stage$slope,
         se = first_stage$se, n_obs = N),
    list(term = "effective_shocks", estimate = effective_shocks,
         se = NULL, n_obs = N)
  ),
  method_metadata = list(
    estimator = "Borusyak-Hull-Jaravel shock-level weighted IV",
    vcov = "analytic-weight structural-residual HC1, multiplier N/(N-2)"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE,
                     digits = 15, null = "null")
