library(jsonlite)

crosswalk <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
trade <- read.csv("trade.csv", stringsAsFactors = FALSE)
areas <- read.csv("areas.csv", stringsAsFactors = FALSE)
employment <- read.csv("employment.csv", stringsAsFactors = FALSE)
outcomes <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

trade <- merge(trade, crosswalk, by = "code", all.x = TRUE, sort = FALSE)

make_exposure <- function(vintage, trade_change) {
  a <- areas[areas$vintage == vintage, ]
  e <- employment[employment$vintage == vintage, ]

  national <- aggregate(
    employment ~ period + industry,
    data = e,
    FUN = sum
  )
  names(national)[names(national) == "employment"] <- "national_employment"

  e <- merge(e, national, by = c("period", "industry"), all.x = TRUE)
  e <- merge(
    e,
    a[, c("area", "period", "vintage", "total_employment")],
    by = c("area", "period", "vintage"),
    all.x = TRUE
  )
  e <- merge(
    e,
    trade[, c("period", "industry", trade_change, "price_index", "years")],
    by = c("period", "industry"),
    all.x = TRUE
  )

  e$component <- (e$employment / e$total_employment) *
    (e[[trade_change]] / e$national_employment) *
    (e$price_index / 100)^-1 / 1000 * (10 / e$years)

  aggregate(component ~ area + period, data = e, FUN = sum)
}

x <- make_exposure("base", "us_change")
z <- make_exposure("early", "other_change")

x$period <- as.character(x$period)
z$period <- as.character(z$period)
areas$period <- as.character(areas$period)
outcomes$period <- as.character(outcomes$period)

dat <- merge(outcomes, x, by = c("area", "period"), all.x = TRUE)
names(dat)[names(dat) == "component"] <- "x"
dat <- merge(dat, z, by = c("area", "period"), all.x = TRUE)
names(dat)[names(dat) == "component"] <- "z"
dat <- merge(
  dat,
  areas[areas$vintage == "base", c("area", "period", "population")],
  by = c("area", "period"),
  all.x = TRUE
)

dat$period_num <- as.numeric(factor(dat$period)) - 1
n_obs <- 72L

fit <- AER::ivreg(
  change_pp ~ period_num + control + x |
    period_num + control + z,
  data = dat,
  weights = population
)

coef_x <- unname(coef(fit)["x"])

get_value <- function(df, variable, area_value, period_value) {
  df[[variable]][df$area == area_value & df$period == as.character(period_value)][1]
}

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = list(
    list(term = "iv_slope", estimate = as.numeric(coef_x), se = NULL),
    list(term = "exposure_area0_period0",
         estimate = as.numeric(get_value(dat, "x", 0, 0)), se = NULL),
    list(term = "exposure_area0_period1",
         estimate = as.numeric(get_value(dat, "x", 0, 1)), se = NULL),
    list(term = "instrument_area0_period0",
         estimate = as.numeric(get_value(dat, "z", 0, 0)), se = NULL)
  ),
  n_obs = n_obs,
  method_metadata = list(
    estimator = "population-weighted 2SLS",
    instrument = "z",
    endogenous_regressor = "x",
    exogenous_regressors = c("intercept", "period", "control"),
    exposure_units = "thousands of real dollars per worker per decade",
    trade_change_units = "nominal dollars over the stated interval"
  ),
  diagnostics = list(
    sample_count = n_obs,
    area_period_rows = nrow(dat),
    instrument_rank = qr(model.matrix(~ period_num + control + z, data = dat))$rank
  )
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 17)
