library(jsonlite)

dat <- read.csv("input.csv")
keep <- abs(dat$score) < 1
d <- dat[keep, ]
n <- nrow(d)

x <- d$score
right <- as.numeric(x >= 0)
w <- 1 - abs(x)

# Separate local-linear regressions with side-specific intercepts and slopes.
X <- cbind(
  left_intercept = 1 - right,
  left_slope = x * (1 - right),
  right_intercept = right,
  right_slope = x * right
)

bread <- solve(crossprod(X, w * X))
fit_y <- drop(bread %*% crossprod(X, w * d$earnings))
fit_p <- drop(bread %*% crossprod(X, w * d$participated))

contrast <- c(-1, 0, 1, 0)
reduced_form <- sum(contrast * fit_y)
first_stage <- sum(contrast * fit_p)

# HC0 joint covariance for the two discontinuity estimates.
resid_y <- d$earnings - drop(X %*% fit_y)
resid_p <- d$participated - drop(X %*% fit_p)
loading <- drop(X %*% bread %*% contrast)
influence <- cbind(loading * resid_y, loading * resid_p)
joint_cov <- crossprod(influence)

treatment_effect <- reduced_form / first_stage
gradient <- c(1 / first_stage, -reduced_form / first_stage^2)
treatment_se <- sqrt(drop(t(gradient) %*% joint_cov %*% gradient))

row <- function(term, estimate, se) {
  list(term = term, estimate = unname(as.numeric(estimate)),
       se = unname(as.numeric(se)), n_obs = as.integer(n))
}

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    row("treatment_effect", treatment_effect, treatment_se),
    row("reduced_form", reduced_form, sqrt(joint_cov[1, 1])),
    row("first_stage", first_stage, sqrt(joint_cov[2, 2]))
  ),
  method_metadata = list(
    estimator = "Triangular-weighted local-linear fuzzy regression discontinuity",
    vcov = "HC0; joint covariance with delta-method standard error"
  ),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null",
           digits = 16, pretty = TRUE)
