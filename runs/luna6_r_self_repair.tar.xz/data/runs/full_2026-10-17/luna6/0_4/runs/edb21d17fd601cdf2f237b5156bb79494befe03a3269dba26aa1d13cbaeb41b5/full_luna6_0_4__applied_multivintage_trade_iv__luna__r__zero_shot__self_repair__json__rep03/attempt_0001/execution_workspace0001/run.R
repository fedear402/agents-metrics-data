library(jsonlite)

crosswalk <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
trade <- read.csv("trade.csv", stringsAsFactors = FALSE)
areas <- read.csv("areas.csv", stringsAsFactors = FALSE)
employment <- read.csv("employment.csv", stringsAsFactors = FALSE)
outcomes <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

trade <- merge(trade, crosswalk, by = "code", all = FALSE, sort = FALSE)

make_exposure <- function(vintage, change_name, output_name) {
  emp <- merge(
    areas[areas$vintage == vintage, c("area", "period", "total_employment")],
    employment[employment$vintage == vintage, c("area", "period", "industry", "employment")],
    by = c("area", "period"),
    all.x = TRUE,
    sort = FALSE
  )
  emp$employment[is.na(emp$employment)] <- 0

  national <- aggregate(
    employment ~ period + industry,
    data = emp,
    FUN = sum
  )
  names(national)[names(national) == "employment"] <- "national_employment"

  emp <- merge(emp, national, by = c("period", "industry"), all.x = TRUE, sort = FALSE)
  emp <- merge(emp, trade, by = c("period", "industry"), all.x = TRUE, sort = FALSE)

  emp$component <- (emp$employment / emp$total_employment) *
    (emp[[change_name]] / emp$national_employment) /
    (emp$price_index / 100) / 1000 * (10 / emp$years)

  result <- aggregate(component ~ area + period, data = emp, FUN = sum)
  names(result)[names(result) == "component"] <- output_name
  result
}

x <- make_exposure("base", "us_change", "x")
z <- make_exposure("early", "other_change", "z")

data <- merge(areas[areas$vintage == "base", c("area", "period", "population")],
              outcomes, by = c("area", "period"), all = FALSE, sort = FALSE)
data <- merge(data, x, by = c("area", "period"), all = FALSE, sort = FALSE)
data <- merge(data, z, by = c("area", "period"), all = FALSE, sort = FALSE)

data$period_reg <- as.numeric(as.factor(data$period))
data <- data[order(data$area, data$period), ]

# Weighted 2SLS: all exogenous regressors instrument themselves, and z instruments x.
W <- diag(data$population)
X <- cbind(intercept = 1, period = data$period_reg, control = data$control, x = data$x)
Z <- cbind(intercept = 1, period = data$period_reg, control = data$control, z = data$z)
A <- solve(crossprod(Z, W %*% Z)) %*% crossprod(Z, W %*% X)
beta <- solve(crossprod(X, W %*% Z %*% A)) %*%
  crossprod(X, W %*% Z %*% A, data$change_pp)

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = list(
    list(term = "iv_slope", estimate = unname(beta[4, 1]), se = NULL, n_obs = 72L),
    list(term = "exposure_area0_period0",
         estimate = x$x[x$area == 0 & x$period == 0], se = NULL, n_obs = 72L),
    list(term = "exposure_area0_period1",
         estimate = x$x[x$area == 0 & x$period == 1], se = NULL, n_obs = 72L),
    list(term = "instrument_area0_period0",
         estimate = z$z[z$area == 0 & z$period == 0], se = NULL, n_obs = 72L)
  ),
  method_metadata = list(
    estimator = "population-weighted two-stage least squares",
    outcome = "change_pp",
    endogenous_regressor = "x",
    excluded_instrument = "z",
    included_exogenous_regressors = c("intercept", "period", "control"),
    weights = "base-vintage population",
    exposure_units = "thousands of real dollars per worker per decade",
    sample_definition = "all 72 area-period observations"
  ),
  diagnostics = list(n_obs = 72L)
)

write_json(result, "result.json", auto_unbox = TRUE, digits = 16, na = "null")
