library(jsonlite)

crosswalk <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
trade <- read.csv("trade.csv", stringsAsFactors = FALSE)
areas <- read.csv("areas.csv", stringsAsFactors = FALSE)
employment <- read.csv("employment.csv", stringsAsFactors = FALSE)
outcomes <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

trade <- merge(trade, crosswalk, by = "code", all.x = TRUE, sort = FALSE)

build_exposure <- function(vintage, change_column) {
  e <- employment[employment$vintage == vintage, ]
  a <- areas[areas$vintage == vintage, ]

  national <- aggregate(employment ~ period + industry, data = e, FUN = sum)
  names(national)[names(national) == "employment"] <- "national_employment"

  e <- merge(e, a[, c("area", "period", "vintage", "total_employment")],
             by = c("area", "period", "vintage"), all = TRUE, sort = FALSE)
  e <- merge(e, national, by = c("period", "industry"), all.x = TRUE, sort = FALSE)
  e$share <- e$employment / e$total_employment

  t <- trade[, c("period", "industry", change_column, "price_index", "years")]
  names(t)[names(t) == change_column] <- "trade_change"
  e <- merge(e, t, by = c("period", "industry"), all.x = TRUE, sort = FALSE)

  e$component <- e$share * (e$trade_change / e$national_employment) /
    (e$price_index / 100) / 1000 * (10 / e$years)

  aggregate(component ~ area + period, data = e, FUN = sum)
}

x <- build_exposure("base", "us_change")
names(x)[names(x) == "component"] <- "x"

z <- build_exposure("early", "other_change")
names(z)[names(z) == "component"] <- "z"

dat <- merge(outcomes, x, by = c("area", "period"), all = FALSE)
dat <- merge(dat, z, by = c("area", "period"), all = FALSE)
dat <- merge(dat, areas[areas$vintage == "base",
                        c("area", "period", "population")],
             by = c("area", "period"), all = FALSE)

dat$period_indicator <- as.integer(dat$period == sort(unique(dat$period))[2])

# Weighted 2SLS via weighted projection of x on all exogenous regressors and z.
Xexo <- model.matrix(~ period_indicator + control, data = dat)
Z <- cbind(Xexo, z = dat$z)
Wsqrt <- sqrt(dat$population)
fit_first <- lm.wfit(x = Z * Wsqrt, y = dat$x * Wsqrt,
                     w = rep(1, nrow(dat)))
x_hat <- as.vector(Z %*% fit_first$coefficients)
Xsecond <- cbind(Xexo, x = x_hat)
fit_second <- lm.wfit(x = Xsecond * Wsqrt, y = dat$change_pp * Wsqrt,
                      w = rep(1, nrow(dat)))

# Recover the coefficient on the instrumented exposure.
iv_slope <- unname(fit_second$coefficients[ncol(Xsecond)])

periods <- sort(unique(dat$period))
area0_p0 <- dat$x[dat$area == 0 & dat$period == periods[1]]
area0_p1 <- dat$x[dat$area == 0 & dat$period == periods[2]]
instrument_area0_p0 <- dat$z[dat$area == 0 & dat$period == periods[1]]

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = list(
    list(term = "iv_slope", estimate = as.numeric(iv_slope), se = NULL,
         n_obs = 72L),
    list(term = "exposure_area0_period0", estimate = as.numeric(area0_p0),
         se = NULL, n_obs = 72L),
    list(term = "exposure_area0_period1", estimate = as.numeric(area0_p1),
         se = NULL, n_obs = 72L),
    list(term = "instrument_area0_period0",
         estimate = as.numeric(instrument_area0_p0), se = NULL, n_obs = 72L)
  ),
  method_metadata = list(
    estimator = "weighted_2sls",
    outcome = "change_pp",
    endogenous_regressor = "x",
    excluded_instrument = "z",
    exogenous_regressors = c("intercept", "period_indicator", "control"),
    regression_weight = "base-vintage population",
    exposure_units = "thousands of real dollars per worker per decade"
  ),
  diagnostics = list(n_obs = 72L)
)

write_json(result, "result.json", auto_unbox = TRUE, digits = 17, null = "null")
