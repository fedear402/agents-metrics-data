library(jsonlite)

households <- read.csv("households.csv")
census <- read.csv("census.csv")

required_household_columns <- c(
  "eligible", "recipient", "instrument", "dose", "baseline", "weight", "outcome"
)
required_census_columns <- c("eligible", "nonrecipient_population")

if (!all(required_household_columns %in% names(households))) {
  stop("households.csv is missing required columns.")
}
if (!all(required_census_columns %in% names(census))) {
  stop("census.csv is missing required columns.")
}

dat <- households[households$recipient == 0, , drop = FALSE]
n_obs <- nrow(dat)
if (n_obs == 0L) stop("No nonrecipient household observations are available.")

numeric_columns <- c("eligible", "instrument", "dose", "baseline", "weight", "outcome")
if (any(!vapply(dat[numeric_columns], function(x) all(is.finite(x)), logical(1)))) {
  stop("Retained household data must be finite.")
}
if (any(!dat$eligible %in% c(0, 1))) stop("eligible must contain only zero or one.")
if (any(dat$weight <= 0)) stop("Estimation weights must be positive.")

ineligible <- 1 - dat$eligible
eligible <- dat$eligible
w <- dat$weight
y <- dat$outcome

endogenous <- cbind(
  dose_ineligible = dat$dose * ineligible,
  dose_eligible = dat$dose * eligible
)
exogenous <- cbind(
  ineligible = ineligible,
  eligible = eligible,
  baseline_ineligible = dat$baseline * ineligible,
  baseline_eligible = dat$baseline * eligible
)
instruments <- cbind(
  exogenous,
  instrument_ineligible = dat$instrument * ineligible,
  instrument_eligible = dat$instrument * eligible
)
x <- cbind(exogenous, endogenous)

# Weighted 2SLS using the specified instrument matrix, with no added intercept.
sqrt_w <- sqrt(w)
z_w <- instruments * sqrt_w
x_w <- x * sqrt_w
y_w <- y * sqrt_w

qz <- qr(z_w)
if (qz$rank < ncol(z_w)) stop("Weighted instrument matrix is rank deficient.")
x_projected <- qr.fitted(qz, x_w)

normal_matrix <- crossprod(x_projected, x_projected)
if (qr(normal_matrix)$rank < ncol(normal_matrix)) {
  stop("Weighted 2SLS system is rank deficient.")
}
beta <- solve(normal_matrix, crossprod(x_projected, y_w))
names(beta) <- colnames(x)

group_mean_dose <- function(group_indicator) {
  keep <- group_indicator == 1
  if (!any(keep)) stop("A retained eligibility group has no observations.")
  sum(dat$dose[keep] * w[keep]) / sum(w[keep])
}

ineligible_effect <- unname(beta["dose_ineligible"]) * group_mean_dose(ineligible)
eligible_nonrecipient_effect <- unname(beta["dose_eligible"]) * group_mean_dose(eligible)

population <- census$nonrecipient_population[match(c(0, 1), census$eligible)]
if (length(population) != 2L || anyNA(population) ||
    any(!is.finite(population)) || any(population < 0) || sum(population) <= 0) {
  stop("Census must provide valid nonrecipient population counts for both groups.")
}
population_effect <- (
  ineligible_effect * population[1] +
    eligible_nonrecipient_effect * population[2]
) / sum(population)

effects <- c(
  ineligible_effect = ineligible_effect,
  eligible_nonrecipient_effect = eligible_nonrecipient_effect,
  population_effect = population_effect
)
if (any(!is.finite(effects))) stop("At least one requested estimate is not finite.")

estimates <- lapply(names(effects), function(term) {
  list(
    term = term,
    estimate = unname(as.numeric(effects[[term]])),
    se = NULL,
    n_obs = as.integer(n_obs)
  )
})

result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "weighted 2SLS",
    sample = "All household rows with recipient equal to zero, including both village treatment statuses.",
    endogenous_columns = c("dose*(1-eligible)", "dose*eligible"),
    exogenous_columns = c(
      "1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"
    ),
    instrument_columns = c(
      "1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible",
      "instrument*(1-eligible)", "instrument*eligible"
    ),
    intercept = "No additional intercept.",
    regression_weight = "weight",
    within_group_dose_average = "Household-weighted mean dose among retained observations in each eligibility group.",
    counterfactual = "Dose set to zero for every retained household.",
    attribution_convention = "Attribution to the zero-dose counterfactual is a stated synthetic convention.",
    population_aggregation = "Census nonrecipient_population counts are used only for final between-group weighting."
  ),
  diagnostics = list(
    n_obs = as.integer(n_obs),
    se_status = "Standard errors are null, as requested."
  )
)

write_json(result, "result.json", auto_unbox = TRUE, digits = 17, na = "null")
