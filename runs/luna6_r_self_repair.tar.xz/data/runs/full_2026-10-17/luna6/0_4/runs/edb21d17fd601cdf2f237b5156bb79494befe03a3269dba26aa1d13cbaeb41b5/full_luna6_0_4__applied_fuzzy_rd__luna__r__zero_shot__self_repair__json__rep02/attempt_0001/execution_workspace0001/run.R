d <- read.csv("input.csv")
d <- d[abs(d$score) < 1, ]
n <- nrow(d)

x <- d$score
z <- as.numeric(x >= 0)
w <- 1 - abs(x)
X <- cbind(1, z, x, z * x)

fit <- function(y) {
  q <- qr(X * sqrt(w))
  coef <- qr.coef(q, y * sqrt(w))
  resid <- y - drop(X %*% coef)
  bread <- solve(crossprod(X, X * w))
  meat <- crossprod(X, X * (w^2 * resid^2))
  V <- bread %*% meat %*% bread
  list(discontinuity = coef[2], variance = V[2, 2], covariance_row = V[2, ])
}

earn <- fit(d$earnings)
part <- fit(d$participated)

rf <- earn$discontinuity
fs <- part$discontinuity
te <- rf / fs

# Joint HC0 covariance of reduced form and first stage, using identical rows and weights.
joint_meat <- crossprod(
  X,
  X * (w^2 * earn_resid_part <- (d$earnings - drop(X %*% qr.coef(qr(X * sqrt(w)), d$earnings * sqrt(w)))) *
       (d$participated - drop(X %*% qr.coef(qr(X * sqrt(w)), d$participated * sqrt(w)))))
)
bread <- solve(crossprod(X, X * w))
cov_rf_fs <- (bread %*% joint_meat %*% bread)[2, 2]

se_rf <- sqrt(earn$variance)
se_fs <- sqrt(part$variance)
se_te <- sqrt(earn$variance / fs^2 + rf^2 * part$variance / fs^4 -
              2 * rf * cov_rf_fs / fs^3)

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = te, se = se_te, n_obs = n),
    list(term = "reduced_form", estimate = rf, se = se_rf, n_obs = n),
    list(term = "first_stage", estimate = fs, se = se_fs, n_obs = n)
  ),
  method_metadata = list(
    estimator = "Fuzzy RD local linear regression with triangular weights and bandwidth 1",
    vcov = "HC0 sandwich; delta method using joint covariance"
  ),
  diagnostics = list()
)
jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = 15, na = "null")
