households <- read.csv("households.csv")
census <- read.csv("census.csv")

d <- subset(households, recipient == 0)
d$eligible0 <- 1 - d$eligible
d$dose_ineligible <- d$dose * d$eligible0
d$dose_eligible <- d$dose * d$eligible
d$baseline_ineligible <- d$baseline * d$eligible0
d$baseline_eligible <- d$baseline * d$eligible
d$instrument_ineligible <- d$instrument * d$eligible0
d$instrument_eligible <- d$instrument * d$eligible

X <- cbind(
  eligible0 = d$eligible0,
  eligible = d$eligible,
  baseline_ineligible = d$baseline_ineligible,
  baseline_eligible = d$baseline_eligible,
  dose_ineligible = d$dose_ineligible,
  dose_eligible = d$dose_eligible
)
Z <- cbind(
  eligible0 = d$eligible0,
  eligible = d$eligible,
  baseline_ineligible = d$baseline_ineligible,
  baseline_eligible = d$baseline_eligible,
  instrument_ineligible = d$instrument_ineligible,
  instrument_eligible = d$instrument_eligible
)

sqrt_w <- sqrt(d$weight)
Xw <- X * sqrt_w
Zw <- Z * sqrt_w
yw <- d$outcome * sqrt_w

projected_X <- qr.fitted(qr(Zw), Xw)
beta <- as.numeric(qr.coef(qr(projected_X), yw))
names(beta) <- colnames(X)

mean_dose_ineligible <- weighted.mean(d$dose[d$eligible == 0], d$weight[d$eligible == 0])
mean_dose_eligible <- weighted.mean(d$dose[d$eligible == 1], d$weight[d$eligible == 1])

ineligible_effect <- beta["dose_ineligible"] * mean_dose_ineligible
eligible_nonrecipient_effect <- beta["dose_eligible"] * mean_dose_eligible

census_weights <- census$nonrecipient_population[
  match(c(0, 1), census$eligible)
]
population_effect <- weighted.mean(
  c(ineligible_effect, eligible_nonrecipient_effect),
  census_weights
)

n_obs <- as.integer(nrow(d))
estimates <- list(
  list(term = "ineligible_effect", estimate = unname(ineligible_effect), se = NULL, n_obs = n_obs),
  list(term = "eligible_nonrecipient_effect", estimate = unname(eligible_nonrecipient_effect), se = NULL, n_obs = n_obs),
  list(term = "population_effect", estimate = unname(population_effect), se = NULL, n_obs = n_obs)
)

jsonlite::write_json(
  list(
    task_id = "applied_nonrecipient_population_iv",
    platform = "r",
    estimates = estimates,
    method_metadata = list(
      method = "Weighted 2SLS",
      sample = "All households with recipient equal to zero",
      counterfactual = "Dose set to zero for every retained household; attribution is a synthetic convention",
      aggregation = "Census nonrecipient population counts are used only for final between-group weighting"
    ),
    diagnostics = list(
      n_obs = n_obs,
      ineligible_weighted_mean_dose = unname(mean_dose_ineligible),
      eligible_weighted_mean_dose = unname(mean_dose_eligible),
      ineligible_dose_slope = unname(beta["dose_ineligible"]),
      eligible_dose_slope = unname(beta["dose_eligible"])
    )
  ),
  "result.json",
  auto_unbox = TRUE,
  digits = 17,
  null = "null"
)
