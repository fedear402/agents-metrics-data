dat <- read.csv("input.csv")
n <- nrow(dat)
critical <- qf(0.95, df1 = 2, df2 = n - 4)

ar_stat <- function(beta) {
  fit <- lm(I(y - beta * endog) ~ x + z1 + z2, data = dat)
  full_rss <- sum(residuals(fit)^2)
  restricted <- lm(I(y - beta * endog) ~ x, data = dat)
  restricted_rss <- sum(residuals(restricted)^2)
  ((restricted_rss - full_rss) / 2) / (full_rss / (n - 4))
}

# The AR statistic is a ratio of quadratic forms in beta. Its boundary
# equation is quadratic, so solve it directly over the full real line.
rss_difference <- function(beta) {
  fit <- lm(I(y - beta * endog) ~ x + z1 + z2, data = dat)
  restricted <- lm(I(y - beta * endog) ~ x, data = dat)
  sum(residuals(restricted)^2) - sum(residuals(fit)^2)
}

# Evaluate the quadratic boundary equation at three points and recover
# its coefficients without using a bounded search grid.
g <- function(beta) {
  fit <- lm(I(y - beta * endog) ~ x + z1 + z2, data = dat)
  rss <- sum(residuals(fit)^2)
  critical * rss / (n - 4) - rss_difference(beta) / 2
}

g0 <- g(0)
gp <- g(1)
gm <- g(-1)
a <- (gp + gm) / 2 - g0
b <- (gp - gm) / 2
c <- g0
roots <- sort(Re(polyroot(c(c, b, a))))
boundary_low <- roots[1]
boundary_high <- roots[2]

estimates <- list(
  list(term = "boundary_low", estimate = boundary_low, se = NULL, n_obs = n),
  list(term = "boundary_high", estimate = boundary_high, se = NULL, n_obs = n),
  list(term = "accepts_zero", estimate = as.numeric(ar_stat(0) <= critical), se = NULL, n_obs = n),
  list(term = "unbounded", estimate = 0, se = NULL, n_obs = n),
  list(term = "ar_f_at_one", estimate = ar_stat(1), se = NULL, n_obs = n)
)

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "Anderson-Rubin test inversion with conventional homoskedastic joint F test",
    vcov = "Conventional homoskedastic"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 15)
