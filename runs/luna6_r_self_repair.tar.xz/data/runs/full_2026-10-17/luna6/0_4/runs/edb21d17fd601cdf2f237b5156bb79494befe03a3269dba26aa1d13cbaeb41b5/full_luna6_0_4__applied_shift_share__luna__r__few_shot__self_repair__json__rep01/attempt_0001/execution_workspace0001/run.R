library(jsonlite)

dat <- read.csv("input.csv", stringsAsFactors = FALSE)

# Use one observation per region to normalize regional weights.
region_rows <- !duplicated(dat$region_id)
regions <- dat[region_rows, c("region_id", "region_weight", "x", "y")]
regions <- regions[order(regions$region_id), ]
e <- regions$region_weight / sum(regions$region_weight)

region_ids <- as.character(regions$region_id)
industry_ids <- sort(unique(as.character(dat$industry_id)))
N <- length(industry_ids)

share_mat <- matrix(
  0,
  nrow = length(region_ids),
  ncol = N,
  dimnames = list(region_ids, industry_ids)
)
shock <- numeric(N)
names(shock) <- industry_ids

for (j in seq_along(industry_ids)) {
  ind <- industry_ids[j]
  rows <- as.character(dat$industry_id) == ind
  shock[j] <- dat$shock[which(rows)[1]]
  for (i in seq_along(region_ids)) {
    match_row <- rows & as.character(dat$region_id) == region_ids[i]
    if (any(match_row)) share_mat[i, j] <- sum(dat$share[match_row])
  }
}

x <- regions$x
y <- regions$y
z <- drop(share_mat %*% shock)

weighted_center <- function(v) v - sum(e * v)
y0 <- weighted_center(y)
x0 <- weighted_center(x)
z0 <- weighted_center(z)

mass <- drop(crossprod(e, share_mat))
ybar <- drop(crossprod(share_mat, e * y0)) / mass
xbar <- drop(crossprod(share_mat, e * x0)) / mass
zbar <- drop(crossprod(share_mat, e * z0)) / mass

shock_iv <- function(dependent, endogenous) {
  # Weighted 2SLS with an intercept, using shock as the excluded instrument.
  Z <- cbind(1, shock)
  X <- cbind(1, endogenous)
  W <- diag(mass)
  A <- crossprod(X, W %*% Z)
  B <- crossprod(Z, W %*% Z)
  beta <- solve(A %*% solve(B) %*% t(A),
                A %*% solve(B) %*% crossprod(Z, mass * dependent))

  residual <- drop(dependent - X %*% beta)
  scores <- Z * (mass * residual)
  bread <- solve(A %*% solve(B) %*% t(A))
  meat <- crossprod(scores)
  covariance <- (N / (N - 2)) * bread %*% A %*% solve(B) %*%
    meat %*% solve(B) %*% t(A) %*% bread

  c(slope = beta[2], se = sqrt(covariance[2, 2]))
}

effect <- shock_iv(ybar, xbar)
first_stage <- shock_iv(xbar, zbar)
effective_shocks <- 1 / sum(mass^2)

out <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = unname(effect["slope"]),
         se = unname(effect["se"]), n_obs = as.integer(N)),
    list(term = "first_stage", estimate = unname(first_stage["slope"]),
         se = unname(first_stage["se"]), n_obs = as.integer(N)),
    list(term = "effective_shocks", estimate = unname(effective_shocks),
         se = NULL, n_obs = as.integer(N))
  ),
  method_metadata = list(
    estimator = "Regional weighted 2SLS with shock-level weighted IV aggregation",
    vcov = "Shock-level structural-residual HC1, analytic weights, no clustering"
  ),
  diagnostics = list()
)

write_json(out, "result.json", auto_unbox = TRUE, null = "null",
           digits = 16, pretty = TRUE)
