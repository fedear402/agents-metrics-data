library(jsonlite)

dat <- read.csv("input.csv")
inside <- abs(dat$score) < 1
d <- dat[inside, ]
n <- nrow(d)

x <- d$score
right <- as.numeric(x >= 0)
w <- 1 - abs(x)

# Separate local-linear fits, expressed as a common weighted regression.
X <- cbind(
  left_intercept = 1 - right,
  left_slope = (1 - right) * x,
  right_intercept = right,
  right_slope = right * x
)

bread <- solve(crossprod(X, w * X))
fit <- function(y) {
  beta <- drop(bread %*% crossprod(X, w * y))
  resid <- y - drop(X %*% beta)
  meat <- crossprod(X, (w * resid) * X)
  list(beta = beta, vcov = bread %*% meat %*% bread)
}

fy <- fit(d$earnings)
fp <- fit(d$participated)
contrast <- c(-1, 0, 1, 0)

jumps <- c(
  reduced_form = sum(contrast * fy$beta),
  first_stage = sum(contrast * fp$beta)
)

# Joint HC0 covariance from observation-level coefficient contributions.
cy <- w * drop(X %*% bread %*% contrast) * (d$earnings - drop(X %*% fy$beta))
cp <- w * drop(X %*% bread %*% contrast) * (d$participated - drop(X %*% fp$beta))
joint <- crossprod(cbind(cy, cp))

ratio <- jumps["reduced_form"] / jumps["first_stage"]
gradient <- c(1 / jumps["first_stage"],
              -jumps["reduced_form"] / jumps["first_stage"]^2)
ratio_se <- sqrt(drop(t(gradient) %*% joint %*% gradient))

rows <- list(
  list(term = "treatment_effect", estimate = unname(ratio),
       se = unname(ratio_se), n_obs = as.integer(n)),
  list(term = "reduced_form", estimate = unname(jumps["reduced_form"]),
       se = sqrt(joint[1, 1]), n_obs = as.integer(n)),
  list(term = "first_stage", estimate = unname(jumps["first_stage"]),
       se = sqrt(joint[2, 2]), n_obs = as.integer(n))
)

write_json(
  list(
    task_id = "applied_fuzzy_rd",
    platform = "r",
    estimates = rows,
    method_metadata = list(
      estimator = "weighted local-linear fuzzy regression discontinuity",
      vcov = "HC0 sandwich; fixed triangular weights; joint delta method"
    ),
    diagnostics = list()
  ),
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
