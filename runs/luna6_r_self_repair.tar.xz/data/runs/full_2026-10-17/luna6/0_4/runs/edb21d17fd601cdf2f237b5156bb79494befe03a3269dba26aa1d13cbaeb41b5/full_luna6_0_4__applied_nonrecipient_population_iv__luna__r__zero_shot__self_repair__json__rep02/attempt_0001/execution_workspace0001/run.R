library(jsonlite)

households <- read.csv("households.csv", stringsAsFactors = FALSE)
census <- read.csv("census.csv", stringsAsFactors = FALSE)

dat <- households[households$recipient == 0, , drop = FALSE]
n_obs <- as.integer(nrow(dat))

ineligible <- 1 - dat$eligible
eligible <- dat$eligible
dose_ineligible <- dat$dose * ineligible
dose_eligible <- dat$dose * eligible

X <- cbind(
  ineligible = ineligible,
  eligible = eligible,
  baseline_ineligible = dat$baseline * ineligible,
  baseline_eligible = dat$baseline * eligible,
  dose_ineligible = dose_ineligible,
  dose_eligible = dose_eligible
)
Z <- cbind(
  ineligible = ineligible,
  eligible = eligible,
  baseline_ineligible = dat$baseline * ineligible,
  baseline_eligible = dat$baseline * eligible,
  instrument_ineligible = dat$instrument * ineligible,
  instrument_eligible = dat$instrument * eligible
)

W <- diag(dat$weight)
bread <- solve(crossprod(X, W %*% Z) %*% solve(crossprod(Z, W %*% Z)) %*% crossprod(Z, W %*% X))
beta <- bread %*% crossprod(X, W %*% Z) %*%
  solve(crossprod(Z, W %*% Z)) %*%
  crossprod(Z, W %*% dat$outcome)

dose_slope_ineligible <- as.numeric(beta["dose_ineligible", 1])
dose_slope_eligible <- as.numeric(beta["dose_eligible", 1])

mean_dose_ineligible <- weighted.mean(dat$dose[dat$eligible == 0], dat$weight[dat$eligible == 0])
mean_dose_eligible <- weighted.mean(dat$dose[dat$eligible == 1], dat$weight[dat$eligible == 1])

ineligible_effect <- dose_slope_ineligible * mean_dose_ineligible
eligible_nonrecipient_effect <- dose_slope_eligible * mean_dose_eligible

population <- census$nonrecipient_population[match(c(0, 1), census$eligible)]
population_effect <- (ineligible_effect * population[1] +
  eligible_nonrecipient_effect * population[2]) / sum(population)

estimates <- list(
  list(term = "ineligible_effect", estimate = ineligible_effect, se = NULL, n_obs = n_obs),
  list(term = "eligible_nonrecipient_effect", estimate = eligible_nonrecipient_effect, se = NULL, n_obs = n_obs),
  list(term = "population_effect", estimate = population_effect, se = NULL, n_obs = n_obs)
)

result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "weighted_2sls",
    regression_weight = "weight",
    retained_sample = "recipient == 0",
    endogenous_columns = c("dose*(1-eligible)", "dose*eligible"),
    exogenous_columns = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"),
    instrument_columns = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible",
      "instrument*(1-eligible)", "instrument*eligible"),
    intercept = FALSE,
    counterfactual = "dose set to zero for every retained household",
    attribution_convention = "synthetic convention",
    group_effect_definition = "fitted dose slope times household-weighted mean dose among retained group observations",
    population_aggregation = "census nonrecipient_population weights; census used only for final between-group aggregation"
  ),
  diagnostics = list(
    n_obs = n_obs,
    retained_household_rows = n_obs
  )
)

write_json(result, "result.json", auto_unbox = TRUE, digits = 17, null = "null")
