task_id <- "applied_nonrecipient_population_iv"

households <- read.csv("households.csv")
census <- read.csv("census.csv")

# Retain every household that did not receive the transfer.
d <- households[households$recipient == 0, , drop = FALSE]
n_obs <- as.integer(nrow(d))

e0 <- 1 - d$eligible
e1 <- d$eligible

X_exog <- cbind(
  intercept_ineligible = e0,
  intercept_eligible = e1,
  baseline_ineligible = d$baseline * e0,
  baseline_eligible = d$baseline * e1
)
X_endog <- cbind(
  dose_ineligible = d$dose * e0,
  dose_eligible = d$dose * e1
)
X <- cbind(X_exog, X_endog)

Z <- cbind(
  X_exog,
  instrument_ineligible = d$instrument * e0,
  instrument_eligible = d$instrument * e1
)

# Apply regression weights, then estimate the weighted 2SLS coefficients.
w_sqrt <- sqrt(d$weight)
X_w <- X * w_sqrt
Z_w <- Z * w_sqrt
y_w <- d$outcome * w_sqrt

X_hat <- qr.fitted(qr(Z_w), X_w)
beta <- as.numeric(qr.solve(crossprod(X_hat), crossprod(X_hat, y_w)))
names(beta) <- colnames(X)

group_mean_dose <- vapply(0:1, function(g) {
  keep <- d$eligible == g
  sum(d$dose[keep] * d$weight[keep]) / sum(d$weight[keep])
}, numeric(1))

ineligible_effect <- unname(beta["dose_ineligible"] * group_mean_dose[1])
eligible_nonrecipient_effect <-
  unname(beta["dose_eligible"] * group_mean_dose[2])

census_weights <- census$nonrecipient_population[
  match(0:1, census$eligible)
]
population_effect <- (
  ineligible_effect * census_weights[1] +
    eligible_nonrecipient_effect * census_weights[2]
) / sum(census_weights)

estimates <- list(
  list(
    term = "ineligible_effect",
    estimate = ineligible_effect,
    se = NULL,
    n_obs = n_obs
  ),
  list(
    term = "eligible_nonrecipient_effect",
    estimate = eligible_nonrecipient_effect,
    se = NULL,
    n_obs = n_obs
  ),
  list(
    term = "population_effect",
    estimate = population_effect,
    se = NULL,
    n_obs = n_obs
  )
)

result <- list(
  task_id = task_id,
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    method = "Weighted 2SLS",
    retained_sample = "All households with recipient equal to zero",
    endogenous_columns = c("dose*(1-eligible)", "dose*eligible"),
    exogenous_columns = c(
      "1-eligible", "eligible",
      "baseline*(1-eligible)", "baseline*eligible"
    ),
    instruments = c(
      "1-eligible", "eligible",
      "baseline*(1-eligible)", "baseline*eligible",
      "instrument*(1-eligible)", "instrument*eligible"
    ),
    group_effect_definition =
      "Fitted dose slope times the household-weighted mean dose in the group",
    counterfactual =
      "Synthetic convention: dose is set to zero for every retained household",
    population_aggregation =
      "Census nonrecipient_population counts determine only final group weights"
  ),
  diagnostics = list(
    n_obs = n_obs,
    census_counts_used = as.list(census_weights)
  )
)

jsonlite::write_json(
  result,
  path = "result.json",
  auto_unbox = TRUE,
  digits = 16,
  null = "null",
  pretty = TRUE
)
