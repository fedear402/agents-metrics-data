data <- read.csv("./input.csv")
data$group <- as.factor(data$group)

fit <- aov(y ~ group, data = data)
anova_table <- summary(fit)[[1]]

f_stat <- anova_table[["F value"]][1]
df_num <- anova_table[["Df"]][1]
df_den <- anova_table[["Df"]][2]
p_value <- anova_table[["Pr(>F)"]][1]
n_obs <- nobs(fit)

result <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = list(
    list(term = "F", estimate = unname(f_stat), se = NULL, n_obs = n_obs),
    list(term = "df_num", estimate = unname(df_num), se = NULL, n_obs = n_obs),
    list(term = "df_den", estimate = unname(df_den), se = NULL, n_obs = n_obs),
    list(term = "p_value", estimate = unname(p_value), se = NULL, n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "one-way ANOVA",
    vcov = "classical ANOVA"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, path = "result.json", auto_unbox = TRUE, digits = 15, na = "null")
