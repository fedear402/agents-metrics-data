data <- read.csv("input.csv", stringsAsFactors = FALSE)
data$date <- as.Date(data$date)
data <- data[order(data$date), ]

log_vix <- log(data$vix)
delta_log_vix <- c(NA_real_, diff(log_vix))
log_sales <- log(data$sales)

n <- nrow(data)
first_row <- 17L
rows <- seq.int(first_row, n)

reg_data <- data.frame(log_sales = log_sales[rows])
for (j in 1:15) {
  reg_data[[paste0("lag_", j)]] <- delta_log_vix[rows - j]
}
reg_data <- reg_data[complete.cases(reg_data), ]

fit <- lm(log_sales ~ ., data = reg_data)
X <- model.matrix(fit)
u <- residuals(fit)
N <- nrow(X)
bread <- solve(crossprod(X))

# Newey-West covariance with Bartlett weights and maximum lag 15.
meat <- crossprod(X * u)
for (j in 1:15) {
  weight <- 1 - j / 16
  cross_lag <- crossprod(
    X[(j + 1):N, , drop = FALSE] * u[(j + 1):N],
    X[1:(N - j), , drop = FALSE] * u[1:(N - j)]
  )
  meat <- meat + weight * (cross_lag + t(cross_lag))
}
vcov_nw <- (N / (N - 16)) * bread %*% meat %*% bread

coef_fit <- coef(fit)
coef_names <- names(coef_fit)
lag1_name <- "lag_1"
lag15_name <- "lag_15"

sum_vector <- rep(0, length(coef_fit))
names(sum_vector) <- coef_names
sum_vector[paste0("lag_", 1:15)] <- 1

cumulative_estimate <- sum(coef_fit[paste0("lag_", 1:15)])
cumulative_se <- sqrt(drop(t(sum_vector) %*% vcov_nw %*% sum_vector))

estimates <- list(
  list(
    term = "cumulative_response",
    estimate = unname(cumulative_estimate),
    se = unname(cumulative_se),
    n_obs = as.integer(N)
  ),
  list(
    term = "lag_1",
    estimate = unname(coef_fit[lag1_name]),
    se = unname(sqrt(vcov_nw[lag1_name, lag1_name])),
    n_obs = as.integer(N)
  ),
  list(
    term = "lag_15",
    estimate = unname(coef_fit[lag15_name]),
    se = unname(sqrt(vcov_nw[lag15_name, lag15_name])),
    n_obs = as.integer(N)
  )
)

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "OLS of log(sales) on intercept and lags 1-15 of first differences of log(vix)",
    vcov = "Newey-West HAC, maximum lag 15, Bartlett weights, scaled by N/(N-16)"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = 15, pretty = TRUE, null = "null")
