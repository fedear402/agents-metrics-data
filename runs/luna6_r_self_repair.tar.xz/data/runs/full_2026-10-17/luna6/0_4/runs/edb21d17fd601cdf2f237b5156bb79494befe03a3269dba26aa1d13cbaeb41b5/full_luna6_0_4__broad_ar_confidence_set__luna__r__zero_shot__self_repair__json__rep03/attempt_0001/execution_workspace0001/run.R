d <- read.csv("input.csv")
n <- nrow(d)
df2 <- n - 4
crit <- qf(0.95, df1 = 2, df2 = df2)

# The excluded-instrument coefficients in the regression of y - beta*endog
# on intercept, x, z1, and z2 are affine functions of beta.
W <- model.matrix(~ x + z1 + z2, data = d)
M <- diag(n) - W %*% solve(crossprod(W), t(W))
Q <- cbind(d$z1, d$z2)
A <- solve(crossprod(Q, M %*% Q), crossprod(Q, M %*% cbind(d$y, d$endog)))
a <- A[, 1]
b <- A[, 2]

# F(beta) = (n - 4) * q(beta)' [Q'MQ] q(beta) / (2 * RSS(beta)),
# where q(beta) contains the fitted excluded-instrument coefficients.
# Obtain the denominator RSS from the full regression residuals.
rss <- function(beta) {
  r <- d$y - beta * d$endog
  fit <- lm.fit(W, r)
  sum(fit$residuals^2)
}
ar_f <- function(beta) {
  q <- a - beta * b
  rss0 <- rss(beta)
  ((n - 4) * drop(crossprod(q, crossprod(Q, M %*% Q) %*% q))) / (2 * rss0)
}

# The equality F(beta) = critical value is a quadratic equation.
# Evaluate it at three points and recover its coefficients.
g <- function(beta) {
  q <- a - beta * b
  rss0 <- rss(beta)
  (n - 4) * drop(crossprod(q, crossprod(Q, M %*% Q) %*% q)) -
    2 * crit * rss0
}
g0 <- g(0)
gp <- g(1)
gm <- g(-1)
c2 <- (gp + gm - 2 * g0) / 2
c1 <- (gp - gm) / 2
roots <- sort(Re(polyroot(c(g0, c1, c2))))
boundary_low <- roots[1]
boundary_high <- roots[2]

# Determine membership directly from the test inequality.
accepts_zero <- as.integer(ar_f(0) <= crit)
# The leading coefficient of F(beta) at either tail is compared to its
# limiting threshold; equality is not accepted at arbitrarily large beta.
tail_q <- b
tail_rss <- rss(1) # replaced below by the quadratic leading coefficient
r0 <- rss(0)
rp <- rss(1)
rm <- rss(-1)
rss2 <- (rp + rm - 2 * r0) / 2
tail_ratio <- (n - 4) * drop(crossprod(tail_q, crossprod(Q, M %*% Q) %*% tail_q)) /
  (2 * rss2)
unbounded <- as.integer(tail_ratio < crit)

estimates <- data.frame(
  term = c("boundary_low", "boundary_high", "accepts_zero", "unbounded", "ar_f_at_one"),
  estimate = c(boundary_low, boundary_high, accepts_zero, unbounded, ar_f(1)),
  se = rep(NA_real_, 5),
  n_obs = rep(n, 5)
)
out <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = lapply(seq_len(nrow(estimates)), function(i) {
    list(
      term = estimates$term[i],
      estimate = estimates$estimate[i],
      se = NULL,
      n_obs = estimates$n_obs[i]
    )
  }),
  method_metadata = list(
    estimator = "Anderson-Rubin confidence set by inversion of the homoskedastic joint F test for z1 and z2",
    vcov = "Conventional homoskedastic F test"
  ),
  diagnostics = list()
)
jsonlite::write_json(out, "result.json", auto_unbox = TRUE, pretty = TRUE, na = "null")
