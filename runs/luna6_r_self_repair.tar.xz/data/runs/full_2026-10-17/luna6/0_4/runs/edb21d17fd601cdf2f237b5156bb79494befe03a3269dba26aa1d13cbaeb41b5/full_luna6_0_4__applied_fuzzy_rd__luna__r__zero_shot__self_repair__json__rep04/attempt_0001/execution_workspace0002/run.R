dat <- read.csv("input.csv")
dat <- dat[abs(dat$score) < 1, , drop = FALSE]
n_obs <- nrow(dat)

x <- dat$score
w <- 1 - abs(x)
right <- as.numeric(x >= 0)
design <- cbind(intercept = 1, right = right, score = x, right_score = right * x)

# Weighted least squares with HC0 covariance. The coefficient on right is
# the right limit minus the left limit at the cutoff.
fit_hc0 <- function(y) {
  xtwx <- crossprod(design, design * w)
  bread <- solve(xtwx)
  beta <- as.vector(bread %*% crossprod(design, w * y))
  resid <- as.vector(y - design %*% beta)
  meat <- crossprod(design, design * (w^2 * resid^2))
  vcov <- bread %*% meat %*% bread
  list(beta = beta, vcov = vcov, resid = resid)
}

rf <- fit_hc0(dat$earnings)
fs <- fit_hc0(dat$participated)

reduced_form <- rf$beta[2]
first_stage <- fs$beta[2]
treatment_effect <- reduced_form / first_stage

# Joint HC0 covariance of the two discontinuity estimates, using shared
# observations, design, and weights.
cross_meat <- crossprod(design, design * (w^2 * rf$resid * fs$resid))
cross_vcov <- solve(crossprod(design, design * w)) %*%
  cross_meat %*%
  solve(crossprod(design, design * w))
cov_rf_fs <- cross_vcov[2, 2]

se_rf <- sqrt(rf$vcov[2, 2])
se_fs <- sqrt(fs$vcov[2, 2])
var_te <- (se_rf^2 / first_stage^2) +
  (reduced_form^2 * se_fs^2 / first_stage^4) -
  (2 * reduced_form * cov_rf_fs / first_stage^3)
se_te <- sqrt(max(0, var_te))

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = treatment_effect, se = se_te, n_obs = as.integer(n_obs)),
    list(term = "reduced_form", estimate = reduced_form, se = se_rf, n_obs = as.integer(n_obs)),
    list(term = "first_stage", estimate = first_stage, se = se_fs, n_obs = as.integer(n_obs))
  ),
  method_metadata = list(
    estimator = "Fuzzy RD local linear WLS with triangular weights, cutoff 0, bandwidth 1",
    vcov = "HC0 sandwich; fixed bandwidth and weights; delta method with joint covariance"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = 15, na = "null")
