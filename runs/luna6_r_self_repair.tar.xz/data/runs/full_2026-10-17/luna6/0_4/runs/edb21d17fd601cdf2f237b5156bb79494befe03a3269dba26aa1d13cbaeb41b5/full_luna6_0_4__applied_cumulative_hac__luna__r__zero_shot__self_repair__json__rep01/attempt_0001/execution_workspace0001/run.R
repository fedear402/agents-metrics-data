data <- read.csv("input.csv", stringsAsFactors = FALSE)
data$date <- as.Date(data$date)
data <- data[order(data$date), ]

data$log_sales <- log(data$sales)
data$delta_log_vix <- c(NA_real_, diff(log(data$vix)))

for (j in 1:15) {
  data[[paste0("lag_", j)]] <- c(rep(NA_real_, j), head(data$delta_log_vix, -j))
}

reg_data <- data[complete.cases(data[, c("log_sales", paste0("lag_", 1:15))]), ]
n_obs <- nrow(reg_data)

fit <- lm(log_sales ~ ., data = reg_data[, c("log_sales", paste0("lag_", 1:15))])
X <- model.matrix(fit)
u <- residuals(fit)
bread <- solve(crossprod(X))

# Newey-West meat with Bartlett weights and maximum lag 15.
score <- X * as.numeric(u)
meat <- crossprod(score)
for (j in 1:15) {
  weight <- 1 - j / 16
  gamma <- crossprod(score[(j + 1):n_obs, , drop = FALSE],
                     score[1:(n_obs - j), , drop = FALSE])
  meat <- meat + weight * (gamma + t(gamma))
}

vcov_hac <- (n_obs / (n_obs - 16)) * bread %*% meat %*% bread
coefs <- coef(fit)
cum_weights <- rep(0, length(coefs))
names(cum_weights) <- names(coefs)
cum_weights[paste0("lag_", 1:15)] <- 1

cumulative_response <- sum(coefs[paste0("lag_", 1:15)])
cumulative_se <- sqrt(drop(t(cum_weights) %*% vcov_hac %*% cum_weights))

estimates <- list(
  list(term = "cumulative_response",
       estimate = unname(cumulative_response),
       se = unname(cumulative_se),
       n_obs = as.integer(n_obs)),
  list(term = "lag_1",
       estimate = unname(coefs["lag_1"]),
       se = unname(sqrt(vcov_hac["lag_1", "lag_1"])),
       n_obs = as.integer(n_obs)),
  list(term = "lag_15",
       estimate = unname(coefs["lag_15"]),
       se = unname(sqrt(vcov_hac["lag_15", "lag_15"])),
       n_obs = as.integer(n_obs))
)

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "OLS of log(sales) on intercept and lags 1-15 of first differences of log(vix)",
    vcov = "Newey-West HAC, Bartlett weights, maximum lag 15, covariance scaled by N/(N-16)"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = 15, null = "null")
