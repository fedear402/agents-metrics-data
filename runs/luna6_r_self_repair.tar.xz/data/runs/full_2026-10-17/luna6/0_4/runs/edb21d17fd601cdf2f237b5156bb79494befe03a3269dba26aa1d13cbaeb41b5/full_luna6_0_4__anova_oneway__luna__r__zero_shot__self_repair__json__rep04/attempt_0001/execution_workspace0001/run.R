data <- read.csv("./input.csv")

fit <- aov(y ~ factor(group), data = data)
tab <- summary(fit)[[1]]

estimates <- list(
  list(term = "F", estimate = unname(tab[1, "F value"]), se = NULL, n_obs = nrow(data)),
  list(term = "df_num", estimate = unname(tab[1, "Df"]), se = NULL, n_obs = nrow(data)),
  list(term = "df_den", estimate = unname(tab[2, "Df"]), se = NULL, n_obs = nrow(data)),
  list(term = "p_value", estimate = unname(tab[1, "Pr(>F)"]), se = NULL, n_obs = nrow(data))
)

result <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = estimates,
  method_metadata = list(estimator = "one-way ANOVA", vcov = "classical ANOVA"),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = NA, null = "null", pretty = TRUE)
