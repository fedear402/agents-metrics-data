data <- read.csv("input.csv", stringsAsFactors = FALSE)
data$date <- as.Date(data$date)
data <- data[order(data$date), ]

dlog_vix <- c(NA_real_, diff(log(data$vix)))
log_sales <- log(data$sales)

n <- nrow(data)
last <- n
first <- 17L

y <- log_sales[first:last]
x <- sapply(1:15, function(k) dlog_vix[(first:last) - k])
colnames(x) <- paste0("lag_", 1:15)

reg_data <- data.frame(y = y, x, check.names = FALSE)
fit <- lm(y ~ ., data = reg_data)

N <- nrow(reg_data)
X <- model.matrix(fit)
u <- residuals(fit)
bread <- solve(crossprod(X))
scores <- X * as.numeric(u)
meat <- crossprod(scores)

for (j in 1:15) {
  weight <- 1 - j / 16
  gamma <- crossprod(scores[(j + 1):N, , drop = FALSE],
                     scores[1:(N - j), , drop = FALSE])
  meat <- meat + weight * (gamma + t(gamma))
}

vcov_nw <- (N / (N - 16)) * bread %*% meat %*% bread
b <- coef(fit)

cum_weights <- rep(0, length(b))
names(cum_weights) <- names(b)
cum_weights[paste0("lag_", 1:15)] <- 1

estimates <- list(
  list(term = "cumulative_response",
       estimate = unname(sum(b[paste0("lag_", 1:15)])),
       se = unname(sqrt(drop(t(cum_weights) %*% vcov_nw %*% cum_weights))),
       n_obs = as.integer(N)),
  list(term = "lag_1",
       estimate = unname(b["lag_1"]),
       se = unname(sqrt(vcov_nw["lag_1", "lag_1"])),
       n_obs = as.integer(N)),
  list(term = "lag_15",
       estimate = unname(b["lag_15"]),
       se = unname(sqrt(vcov_nw["lag_15", "lag_15"])),
       n_obs = as.integer(N))
)

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "OLS of log sales on intercept and lags 1 through 15 of first differences in log VIX",
    vcov = "Newey-West HAC with Bartlett weights, maximum lag 15, multiplied by N/(N-16)"
  ),
  diagnostics = list()
)

if (!requireNamespace("jsonlite", quietly = TRUE)) {
  stop("The jsonlite package is required to write result.json")
}
jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = 16, null = "null")
