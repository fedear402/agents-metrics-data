library(jsonlite)

dat <- read.csv("./input.csv")
fit <- aov(y ~ group, data = dat)
tab <- summary(fit)[[1]]

f_stat <- unname(tab["group", "F value"])
df_num <- unname(tab["group", "Df"])
df_den <- unname(tab["Residuals", "Df"])
p_value <- unname(tab["group", "Pr(>F)"])
n <- nrow(dat)

out <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = list(
    list(term = "F", estimate = f_stat, se = NULL, n_obs = n),
    list(term = "df_num", estimate = df_num, se = NULL, n_obs = n),
    list(term = "df_den", estimate = df_den, se = NULL, n_obs = n),
    list(term = "p_value", estimate = p_value, se = NULL, n_obs = n)
  ),
  method_metadata = list(
    estimator = "One-way ANOVA",
    vcov = "Classical ANOVA variance"
  ),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "./result.json", auto_unbox = TRUE, na = "null", digits = 16)
