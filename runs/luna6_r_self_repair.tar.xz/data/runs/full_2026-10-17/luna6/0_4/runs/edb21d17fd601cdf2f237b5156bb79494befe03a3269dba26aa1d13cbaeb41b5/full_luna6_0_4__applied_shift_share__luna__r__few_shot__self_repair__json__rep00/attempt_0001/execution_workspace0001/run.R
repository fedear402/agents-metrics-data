library(jsonlite)

dat <- read.csv("input.csv")

# Use one observation per region to normalize weights and retain regional data.
region_rows <- !duplicated(dat$region_id)
regions <- dat[region_rows, c("region_id", "region_weight", "x", "y")]
regions$e <- regions$region_weight / sum(regions$region_weight)

# Build the regional instrument from baseline shares and industry shocks.
shock_by_industry <- tapply(dat$shock, dat$industry_id, function(v) {
  if (length(unique(v)) != 1L) stop("shock must be constant within industry")
  v[1L]
})
dat$shock_n <- unname(shock_by_industry[as.character(dat$industry_id)])
dat$z_part <- dat$share * dat$shock_n
z_by_region <- aggregate(z_part ~ region_id, data = dat, sum)
regions$z <- z_by_region$z_part[match(regions$region_id, z_by_region$region_id)]

# Center regional variables using normalized regional weights.
weighted_mean <- function(v, w) sum(w * v)
regions$y0 <- regions$y - weighted_mean(regions$y, regions$e)
regions$x0 <- regions$x - weighted_mean(regions$x, regions$e)
regions$z0 <- regions$z - weighted_mean(regions$z, regions$e)

# Aggregate centered variables to industry exposures.
dat$e <- regions$e[match(dat$region_id, regions$region_id)]
dat$x0 <- regions$x0[match(dat$region_id, regions$region_id)]
dat$y0 <- regions$y0[match(dat$region_id, regions$region_id)]
dat$z0 <- regions$z0[match(dat$region_id, regions$region_id)]
dat$exposure <- dat$e * dat$share

industry <- aggregate(
  cbind(exposure, x_num = exposure * dat$x0,
        y_num = exposure * dat$y0, z_num = exposure * dat$z0) ~ industry_id,
  data = dat, FUN = sum
)
industry$shock <- unname(shock_by_industry[as.character(industry$industry_id)])
industry$xbar <- industry$x_num / industry$exposure
industry$ybar <- industry$y_num / industry$exposure
industry$zbar <- industry$z_num / industry$exposure

# Shock-level weighted IV with an intercept and analytic weights.
shock_iv <- function(outcome, endogenous, instrument, weights) {
  X <- cbind(1, endogenous)
  Z <- cbind(1, instrument)
  A <- crossprod(Z, weights * X)
  beta <- solve(A, crossprod(Z, weights * outcome))
  residual <- drop(outcome - X %*% beta)
  score <- Z * as.vector(weights * residual)
  Ainv <- solve(A)
  n <- length(outcome)
  variance <- (n / (n - 2)) * Ainv %*% crossprod(score) %*% t(Ainv)
  c(slope = beta[2L], se = sqrt(variance[2L, 2L]))
}

N <- nrow(industry)
effect <- shock_iv(industry$ybar, industry$xbar, industry$shock, industry$exposure)
first_stage <- shock_iv(industry$xbar, industry$zbar, industry$shock, industry$exposure)
effective_shocks <- 1 / sum(industry$exposure^2)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = unname(effect["slope"]),
         se = unname(effect["se"]), n_obs = as.integer(N)),
    list(term = "first_stage", estimate = unname(first_stage["slope"]),
         se = unname(first_stage["se"]), n_obs = as.integer(N)),
    list(term = "effective_shocks", estimate = unname(effective_shocks),
         se = NULL, n_obs = as.integer(N))
  ),
  method_metadata = list(
    estimator = "weighted regional 2SLS with equivalent shock-level IV aggregation",
    vcov = "shock-level HC1, analytic weights, structural IV residuals"
  ),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null",
           digits = 16, pretty = TRUE)
