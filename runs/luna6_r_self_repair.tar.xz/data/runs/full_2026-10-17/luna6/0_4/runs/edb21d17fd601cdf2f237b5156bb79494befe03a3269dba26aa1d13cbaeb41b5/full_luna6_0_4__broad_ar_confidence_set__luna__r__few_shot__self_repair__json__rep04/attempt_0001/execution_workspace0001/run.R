d <- read.csv("input.csv")
n <- nrow(d)
q <- 2L
df <- n - 4L
critical <- qf(0.95, q, df)
k <- q * critical / df

fit_resid <- function(response, regressors) {
  residuals(lm(response ~ ., data = data.frame(response, regressors)))
}

# Project each variable onto the included regressors: intercept and x.
W <- model.matrix(~ x, data = d)
resid_on_W <- function(v) qr.resid(qr(W), v)

ry <- resid_on_W(d$y)
rd <- resid_on_W(d$endog)
Z <- cbind(resid_on_W(d$z1), resid_on_W(d$z2))

# Restricted SSR uses y - beta*endog on the intercept and x.
# Unrestricted SSR also projects onto z1 and z2.
ssr_restricted <- function(beta) sum((ry - beta * rd)^2)
ssr_unrestricted <- function(beta) {
  r <- ry - beta * rd
  sum(qr.resid(qr(Z), r)^2)
}

# Form the quadratic acceptance inequality:
# SSR_R - (1 + q*critical/df) * SSR_U <= 0.
# Compute its coefficients by evaluating the quadratic at 0, 1, and -1.
g <- function(beta) {
  ssr_restricted(beta) - (1 + k) * ssr_unrestricted(beta)
}
C <- g(0)
A <- (g(1) + g(-1) - 2 * C) / 2
B <- (g(1) - g(-1)) / 2

disc <- B^2 - 4 * A * C
if (disc < 0 && disc > -1e-10) disc <- 0
if (abs(A) < 1e-12 || disc < 0) stop("Expected two finite boundary points.")

bounds <- sort(c((-B - sqrt(disc)) / (2 * A),
                 (-B + sqrt(disc)) / (2 * A)))
accepts <- function(beta) A * beta^2 + B * beta + C <= 0

ar_f <- function(beta) {
  r <- d$y - beta * d$endog
  restricted <- lm(r ~ x, data = d)
  unrestricted <- lm(r ~ x + z1 + z2, data = d)
  ((deviance(restricted) - deviance(unrestricted)) / q) /
    (deviance(unrestricted) / df)
}

rows <- list(
  list(term = "boundary_low", estimate = unname(bounds[1]), se = NULL, n_obs = n),
  list(term = "boundary_high", estimate = unname(bounds[2]), se = NULL, n_obs = n),
  list(term = "accepts_zero", estimate = as.integer(accepts(0)), se = NULL, n_obs = n),
  list(term = "unbounded", estimate = as.integer(A < 0), se = NULL, n_obs = n),
  list(term = "ar_f_at_one", estimate = unname(ar_f(1)), se = NULL, n_obs = n)
)

jsonlite::write_json(
  list(
    task_id = "broad_ar_confidence_set",
    platform = "r",
    estimates = rows,
    method_metadata = list(
      estimator = "Anderson-Rubin inversion, homoskedastic joint F test",
      vcov = "conventional homoskedastic"
    ),
    diagnostics = list()
  ),
  "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE
)
