library(jsonlite)

households <- read.csv("households.csv")
census <- read.csv("census.csv")

retained <- households[households$recipient == 0, , drop = FALSE]

if (nrow(retained) == 0L) {
  stop("No nonrecipient households are available.")
}
if (any(!is.finite(retained$weight)) || any(retained$weight <= 0)) {
  stop("Estimation weights must be finite and positive.")
}
if (any(!retained$eligible %in% c(0, 1))) {
  stop("Eligibility must be coded as zero or one.")
}

ineligible <- 1 - retained$eligible
eligible <- retained$eligible

x <- cbind(
  ineligible = ineligible,
  eligible = eligible,
  baseline_ineligible = retained$baseline * ineligible,
  baseline_eligible = retained$baseline * eligible
)
endogenous <- cbind(
  dose_ineligible = retained$dose * ineligible,
  dose_eligible = retained$dose * eligible
)
z <- cbind(
  x,
  instrument_ineligible = retained$instrument * ineligible,
  instrument_eligible = retained$instrument * eligible
)

# Weighted 2SLS: project all included regressors onto the specified
# instrument matrix, then estimate the outcome equation with the fitted values.
sqrt_weight <- sqrt(retained$weight)
zw <- z * sqrt_weight
xendow <- cbind(x, endogenous) * sqrt_weight
yw <- retained$outcome * sqrt_weight

qz <- qr(zw)
if (qz$rank < ncol(zw)) {
  stop("The specified instrument matrix is rank deficient.")
}
projected <- qr.fitted(qz, xendow)
fit <- lm.fit(projected, yw)
if (fit$rank < ncol(xendow)) {
  stop("The weighted 2SLS equation is rank deficient.")
}

beta <- fit$coefficients
dose_slope_ineligible <- unname(beta["dose_ineligible"])
dose_slope_eligible <- unname(beta["dose_eligible"])

weighted_mean_dose <- function(group) {
  keep <- group == 1
  if (!any(keep)) {
    stop("A retained eligibility group has no observations.")
  }
  weighted.mean(retained$dose[keep], retained$weight[keep])
}

ineligible_effect <- dose_slope_ineligible * weighted_mean_dose(ineligible)
eligible_nonrecipient_effect <- dose_slope_eligible * weighted_mean_dose(eligible)

population <- census$nonrecipient_population[match(c(0, 1), census$eligible)]
if (length(population) != 2L || anyNA(population) ||
    any(!is.finite(population)) || any(population < 0) || sum(population) <= 0) {
  stop("Census must provide nonnegative nonrecipient populations for both groups.")
}

population_effect <- (
  ineligible_effect * population[1] +
    eligible_nonrecipient_effect * population[2]
) / sum(population)

n_obs <- as.integer(nrow(retained))

result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = list(
    list(term = "ineligible_effect", estimate = unname(ineligible_effect),
         se = NULL, n_obs = n_obs),
    list(term = "eligible_nonrecipient_effect",
         estimate = unname(eligible_nonrecipient_effect),
         se = NULL, n_obs = n_obs),
    list(term = "population_effect", estimate = unname(population_effect),
         se = NULL, n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "weighted 2SLS",
    sample = "all household rows with recipient equal to zero",
    endogenous_columns = c("dose*(1-eligible)", "dose*eligible"),
    exogenous_columns = c(
      "1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"
    ),
    instrument_columns = c(
      "1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible",
      "instrument*(1-eligible)", "instrument*eligible"
    ),
    regression_weight = "weight",
    intercept = "No additional intercept",
    within_group_mean = "Household-weighted mean dose among retained observations",
    counterfactual = "Synthetic convention: set dose to zero for every retained household",
    population_aggregation = "Census nonrecipient_population used only for final group weights"
  ),
  diagnostics = list(
    n_obs = n_obs,
    retained_nonrecipient_household_rows = n_obs
  )
)

write_json(result, "result.json", auto_unbox = TRUE, digits = 17, na = "null")
