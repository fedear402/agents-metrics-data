files <- list()
files[["households.csv"]] <- read.csv("households.csv")
files[["census.csv"]] <- read.csv("census.csv")

task_id <- "applied_nonrecipient_population_iv"
d <- subset(files[["households.csv"]], recipient == 0)
census <- files[["census.csv"]]

# Build the two eligibility-specific endogenous regressors and instruments.
e0 <- 1 - d$eligible
e1 <- d$eligible
X_exog <- cbind(
  ineligible = e0,
  eligible = e1,
  baseline_ineligible = d$baseline * e0,
  baseline_eligible = d$baseline * e1
)
X_endog <- cbind(
  dose_ineligible = d$dose * e0,
  dose_eligible = d$dose * e1
)
Z_excluded <- cbind(
  instrument_ineligible = d$instrument * e0,
  instrument_eligible = d$instrument * e1
)

w_sqrt <- sqrt(d$weight)
X <- cbind(X_exog, X_endog) * w_sqrt
Z <- cbind(X_exog, Z_excluded) * w_sqrt
y <- d$outcome * w_sqrt

# Weighted 2SLS: project all regressors onto the full instrument matrix.
Z_qr <- qr(Z)
X_hat <- qr.fitted(Z_qr, X)
beta <- as.numeric(qr.coef(qr(X_hat), y))
names(beta) <- colnames(X)

mean_dose <- vapply(0:1, function(g) {
  a <- d[d$eligible == g, , drop = FALSE]
  weighted.mean(a$dose, a$weight)
}, numeric(1))

group_effects <- c(
  ineligible_effect = beta["dose_ineligible"] * mean_dose[1],
  eligible_nonrecipient_effect = beta["dose_eligible"] * mean_dose[2]
)
census_weights <- census$nonrecipient_population[
  match(0:1, census$eligible)
]
population_effect <- weighted.mean(group_effects, census_weights)

n_obs <- as.integer(nrow(d))
estimates <- list(
  list(term = "ineligible_effect",
       estimate = unname(group_effects["ineligible_effect"]),
       se = NULL, n_obs = n_obs),
  list(term = "eligible_nonrecipient_effect",
       estimate = unname(group_effects["eligible_nonrecipient_effect"]),
       se = NULL, n_obs = n_obs),
  list(term = "population_effect",
       estimate = unname(population_effect),
       se = NULL, n_obs = n_obs)
)

result <- list(
  task_id = task_id,
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    method = "Weighted 2SLS with eligibility-specific dose slopes",
    retained_sample = "All households with recipient equal to zero",
    endogenous_columns = c("dose*(1-eligible)", "dose*eligible"),
    exogenous_columns = c(
      "1-eligible", "eligible",
      "baseline*(1-eligible)", "baseline*eligible"
    ),
    instruments = c(
      "1-eligible", "eligible",
      "baseline*(1-eligible)", "baseline*eligible",
      "instrument*(1-eligible)", "instrument*eligible"
    ),
    group_effect_definition =
      "Fitted group dose slope multiplied by the household-weighted mean dose in that group",
    counterfactual =
      "Synthetic convention: dose is set to zero for every retained household",
    population_aggregation =
      "Census nonrecipient_population counts determine only the final between-group weights"
  ),
  diagnostics = list(
    n_obs = n_obs,
    retained_households = n_obs,
    census_counts_used = as.list(census_weights)
  )
)

jsonlite::write_json(
  result,
  path = "result.json",
  auto_unbox = TRUE,
  digits = 16,
  null = "null",
  pretty = TRUE
)
