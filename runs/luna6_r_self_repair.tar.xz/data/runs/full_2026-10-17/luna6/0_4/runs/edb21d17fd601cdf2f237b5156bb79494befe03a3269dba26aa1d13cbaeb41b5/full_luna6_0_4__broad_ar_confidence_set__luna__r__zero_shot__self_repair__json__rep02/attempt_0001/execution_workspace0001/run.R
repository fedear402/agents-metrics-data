d <- read.csv("input.csv")
n <- nrow(d)
critical <- qf(0.95, df1 = 2, df2 = n - 4)

# Residualize against the intercept and included exogenous regressor x.
W <- model.matrix(~ x, data = d)
M <- diag(n) - W %*% solve(crossprod(W), t(W))
Z <- as.matrix(d[, c("z1", "z2")])
Zr <- M %*% Z

# The excluded-instrument Wald quadratic is a ratio of quadratic
# polynomials in beta. Its threshold crossings give the full-line
# confidence-set boundaries without a bounded grid search.
A <- crossprod(Zr)
solve_A <- solve(A)
yr <- as.vector(M %*% d$y)
endr <- as.vector(M %*% d$endog)
qform <- function(v) drop(crossprod(v, Zr %*% solve_A %*% crossprod(Zr, v)))

# F(beta) = (n - 4)/2 * qform(y - beta*endog) /
#           (RSS(beta) - qform(y - beta*endog)).
rss <- function(v) sum(v^2)
poly_q <- c(qform(yr), -2 * drop(crossprod(yr, Zr %*% solve_A %*% crossprod(Zr, endr))),
            qform(endr))
poly_rss <- c(rss(yr), -2 * sum(yr * endr), rss(endr))
scale_f <- 2 * critical / (n - 4)
coef <- scale_f * poly_rss - (1 + scale_f) * poly_q
roots <- sort(Re(polyroot(rev(coef))))
roots <- roots[abs(Im(polyroot(rev(coef)))) < 1e-7]

f_ar <- function(beta) {
  v <- yr - beta * endr
  q <- qform(v)
  (n - 4) / 2 * q / (rss(v) - q)
}
boundary_low <- roots[1]
boundary_high <- roots[length(roots)]
accepts_zero <- as.integer(f_ar(0) <= critical)
unbounded <- as.integer((n - 4) / 2 * poly_q[3] /
                         (poly_rss[3] - poly_q[3]) <= critical)

estimates <- data.frame(
  term = c("boundary_low", "boundary_high", "accepts_zero", "unbounded", "ar_f_at_one"),
  estimate = c(boundary_low, boundary_high, accepts_zero, unbounded, f_ar(1)),
  se = rep(NA_real_, 5),
  n_obs = rep(n, 5)
)
estimates$se <- NULL
estimates$se <- I(rep(list(NULL), 5))
out <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = lapply(seq_len(nrow(estimates)), function(i) {
    list(term = estimates$term[i], estimate = estimates$estimate[i],
         se = NULL, n_obs = estimates$n_obs[i])
  }),
  method_metadata = list(
    estimator = "Anderson-Rubin test inversion using conventional homoskedastic joint F test",
    vcov = "Conventional homoskedastic"
  ),
  diagnostics = list()
)
jsonlite::write_json(out, "result.json", auto_unbox = TRUE, null = "null", digits = 15)
