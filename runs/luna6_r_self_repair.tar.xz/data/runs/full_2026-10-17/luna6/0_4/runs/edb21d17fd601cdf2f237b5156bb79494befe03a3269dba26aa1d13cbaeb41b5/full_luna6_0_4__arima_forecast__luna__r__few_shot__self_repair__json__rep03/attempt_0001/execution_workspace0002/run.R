library(forecast)
library(jsonlite)

data <- read.csv("./input.csv")
y <- as.numeric(data$y)

fit <- forecast::Arima(
  y,
  order = c(1, 1, 1),
  include.mean = FALSE,
  include.drift = FALSE,
  method = "ML"
)
fc <- forecast::forecast(fit, h = 1, level = 95)

n <- length(y)
forecast_value <- unname(fc$mean[1])
lower_value <- unname(fc$lower[1, 1])
upper_value <- unname(fc$upper[1, 1])

out <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = list(
    list(
      term = "forecast",
      estimate = forecast_value,
      se = (upper_value - lower_value) / (2 * qnorm(0.975)),
      n_obs = n
    ),
    list(term = "lower_95", estimate = lower_value, se = 0, n_obs = n),
    list(term = "upper_95", estimate = upper_value, se = 0, n_obs = n)
  ),
  method_metadata = list(
    estimator = "ARIMA(1,1,1) maximum likelihood without constant or drift",
    vcov = "Prediction interval from fitted ARIMA model"
  ),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "result.json", auto_unbox = TRUE, digits = 15, na = "null")
