library(jsonlite)

households <- read.csv("households.csv")
census <- read.csv("census.csv")

# Retain every household that did not receive the transfer.
dat <- households[households$recipient == 0, , drop = FALSE]
n_obs <- nrow(dat)

# Construct the specified endogenous, exogenous, and instrument columns.
ineligible <- 1 - dat$eligible
eligible <- dat$eligible

X <- cbind(
  ineligible = ineligible,
  eligible = eligible,
  baseline_ineligible = dat$baseline * ineligible,
  baseline_eligible = dat$baseline * eligible
)

D <- cbind(
  dose_ineligible = dat$dose * ineligible,
  dose_eligible = dat$dose * eligible
)

Z <- cbind(
  X,
  instrument_ineligible = dat$instrument * ineligible,
  instrument_eligible = dat$instrument * eligible
)

y <- dat$outcome
w <- dat$weight

# Weighted 2SLS: project all regressors on the instruments, then fit the
# weighted outcome regression using the projected regressors.
sqrt_w <- sqrt(w)
Zw <- Z * sqrt_w
X2 <- cbind(X, D)
X2w <- X2 * sqrt_w
yw <- y * sqrt_w

projected_X2w <- Zw %*% solve(crossprod(Zw), crossprod(Zw, X2w))
beta <- solve(crossprod(projected_X2w), crossprod(projected_X2w, yw))
beta <- as.vector(beta)

dose_ineligible_slope <- beta[ ncol(X) + 1L]
dose_eligible_slope <- beta[ ncol(X) + 2L]

weighted_mean <- function(x, weight) sum(x * weight) / sum(weight)

ineligible_rows <- dat$eligible == 0
eligible_rows <- dat$eligible == 1

ineligible_effect <- dose_ineligible_slope *
  weighted_mean(dat$dose[ineligible_rows], w[ineligible_rows])
eligible_nonrecipient_effect <- dose_eligible_slope *
  weighted_mean(dat$dose[eligible_rows], w[eligible_rows])

# Census counts are used only for the final between-group aggregation.
population_ineligible <- census$nonrecipient_population[census$eligible == 0]
population_eligible <- census$nonrecipient_population[census$eligible == 1]
population_effect <- (
  ineligible_effect * population_ineligible +
    eligible_nonrecipient_effect * population_eligible
) / (population_ineligible + population_eligible)

estimates <- list(
  list(term = "ineligible_effect", estimate = unname(ineligible_effect),
       se = NULL, n_obs = as.integer(n_obs)),
  list(term = "eligible_nonrecipient_effect",
       estimate = unname(eligible_nonrecipient_effect),
       se = NULL, n_obs = as.integer(n_obs)),
  list(term = "population_effect", estimate = unname(population_effect),
       se = NULL, n_obs = as.integer(n_obs))
)

result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "weighted 2SLS",
    sample = "All household rows with recipient == 0, including both village treatment statuses",
    endogenous_columns = c("dose*(1-eligible)", "dose*eligible"),
    exogenous_columns = c(
      "1-eligible", "eligible",
      "baseline*(1-eligible)", "baseline*eligible"
    ),
    instrument_columns = c(
      "1-eligible", "eligible",
      "baseline*(1-eligible)", "baseline*eligible",
      "instrument*(1-eligible)", "instrument*eligible"
    ),
    regression_weight = "weight",
    group_effect = "Fitted dose slope times the household-weighted mean dose among retained households in that eligibility group",
    counterfactual = "Dose is set to zero for every retained household; attribution is a stated synthetic convention",
    census_use = "nonrecipient_population determines only the final between-group weights"
  ),
  diagnostics = list(
    n_obs = as.integer(n_obs),
    counterfactual_convention = "Synthetic attribution to the zero-dose counterfactual"
  )
)

write_json(result, "result.json", auto_unbox = TRUE, pretty = TRUE, null = "null", digits = 17)
