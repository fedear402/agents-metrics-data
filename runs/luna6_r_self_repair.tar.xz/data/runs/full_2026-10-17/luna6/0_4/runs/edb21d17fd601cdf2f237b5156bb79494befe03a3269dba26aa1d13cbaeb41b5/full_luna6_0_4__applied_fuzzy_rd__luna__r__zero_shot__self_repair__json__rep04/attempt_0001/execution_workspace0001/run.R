dat <- read.csv("input.csv")
dat <- dat[abs(dat$score) < 1, ]
n_obs <- nrow(dat)

x <- dat$score
right <- as.numeric(x >= 0)
w <- 1 - abs(x)
design <- cbind(1, right, x, right * x)

fit_hc0 <- function(y) {
  xtwx <- crossprod(design, design * w)
  bread <- solve(xtwx)
  beta <- bread %*% crossprod(design, w * y)
  resid <- as.vector(y - design %*% beta)
  meat <- crossprod(design, design * (w^2 * resid^2))
  vcov <- bread %*% meat %*% bread
  list(beta = as.vector(beta), vcov = vcov)
}

rf <- fit_hc0(dat$earnings)
fs <- fit_hc0(dat$participated)

reduced_form <- rf$beta[2]
first_stage <- fs$beta[2]
treatment_effect <- reduced_form / first_stage

# Joint HC0 covariance, using the same observations and design for both outcomes.
cross_meat <- crossprod(design, design * (w^2 * rf$resid^2))
