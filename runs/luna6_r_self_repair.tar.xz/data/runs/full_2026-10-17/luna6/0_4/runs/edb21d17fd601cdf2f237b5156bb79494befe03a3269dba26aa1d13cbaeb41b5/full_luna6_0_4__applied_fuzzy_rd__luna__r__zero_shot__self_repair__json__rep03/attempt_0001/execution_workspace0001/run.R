dat <- read.csv("input.csv")
dat <- dat[abs(dat$score) < 1, ]
dat$weight <- 1 - abs(dat$score)
dat$right <- as.integer(dat$score >= 0)
dat$score_right <- dat$score * dat$right
dat$score_left <- dat$score * (1 - dat$right)

fit_discontinuity <- function(y) {
  fit <- lm(y ~ right + score_left + score_right, data = dat, weights = weight)
  coef(fit)[["right"]]
}

outcome_fit <- lm(earnings ~ right + score_left + score_right,
                  data = dat, weights = weight)
participation_fit <- lm(participated ~ right + score_left + score_right,
                        data = dat, weights = weight)

reduced_form <- coef(outcome_fit)[["right"]]
first_stage <- coef(participation_fit)[["right"]]
treatment_effect <- reduced_form / first_stage

X <- model.matrix(outcome_fit)
w <- dat$weight
bread <- solve(crossprod(X, w * X))
resid_y <- residuals(outcome_fit)
resid_d <- residuals(participation_fit)

score_y <- X * as.numeric(w * resid_y)
score_d <- X * as.numeric(w * resid_d)
meat_yy <- crossprod(score_y)
meat_dd <- crossprod(score_d)
meat_yd <- crossprod(score_y, score_d)

V_yy <- bread %*% meat_yy %*% bread
V_dd <- bread %*% meat_dd %*% bread
V_yd <- bread %*% meat_yd %*% bread

idx <- which(names(coef(outcome_fit)) == "right")
var_rf <- V_yy[idx, idx]
var_fs <- V_dd[idx, idx]
cov_rf_fs <- V_yd[idx, idx]

se_rf <- sqrt(var_rf)
se_fs <- sqrt(var_fs)
var_te <- var_rf / first_stage^2 +
  reduced_form^2 * var_fs / first_stage^4 -
  2 * reduced_form * cov_rf_fs / first_stage^3
se_te <- sqrt(max(0, var_te))

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = treatment_effect,
         se = se_te, n_obs = nrow(dat)),
    list(term = "reduced_form", estimate = reduced_form,
         se = se_rf, n_obs = nrow(dat)),
    list(term = "first_stage", estimate = first_stage,
         se = se_fs, n_obs = nrow(dat))
  ),
  method_metadata = list(
    estimator = "weighted local-linear fuzzy regression discontinuity",
    vcov = "HC0 sandwich; fixed triangular weights; joint delta method"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = 15,
                     na = "null")
