library(jsonlite)

d <- read.csv("input.csv")

cohorts <- c(3, 5, 7)
terms <- c("att_g3", "att_g5", "att_g7")
estimates <- numeric(length(cohorts))
row_counts <- integer(length(cohorts))
treated_counts <- integer(length(cohorts))

for (i in seq_along(cohorts)) {
  c <- cohorts[i]
  window <- (c - 2):(c + 2)

  eligible <- d[d$g == c | d$g == 0 | d$g > c + 2, ]
  eligible <- eligible[eligible$time %in% window, ]

  times_by_unit <- split(eligible$time, eligible$id)
  balanced_ids <- names(Filter(
    function(times) all(window %in% times),
    times_by_unit
  ))

  comp <- eligible[eligible$id %in% balanced_ids, ]
  comp$did <- as.numeric(comp$g == c & comp$time >= c)

  estimates[i] <- unname(coef(lm(
    y ~ did + factor(id) + factor(time),
    data = comp
  ))["did"])
  row_counts[i] <- nrow(comp)
  treated_counts[i] <- length(unique(comp$id[comp$g == c]))
}

weighted_estimate <- weighted.mean(estimates, treated_counts)

out <- list(
  task_id = "broad_cohort_stack",
  platform = "r",
  estimates = c(
    lapply(seq_along(cohorts), function(i) {
      list(
        term = terms[i],
        estimate = estimates[i],
        se = NULL,
        n_obs = row_counts[i]
      )
    }),
    list(list(
      term = "att_weighted",
      estimate = weighted_estimate,
      se = NULL,
      n_obs = sum(row_counts)
    ))
  ),
  method_metadata = list(),
  diagnostics = list()
)

jsonlite::write_json(
  out,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16
)
