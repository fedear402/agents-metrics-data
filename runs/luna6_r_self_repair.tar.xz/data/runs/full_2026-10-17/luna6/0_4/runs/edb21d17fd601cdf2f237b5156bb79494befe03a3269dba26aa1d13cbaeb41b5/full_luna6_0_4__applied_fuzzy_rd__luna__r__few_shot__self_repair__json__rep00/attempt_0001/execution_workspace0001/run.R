library(jsonlite)

dat <- read.csv("input.csv")
inside <- abs(dat$score) < 1
d <- dat[inside, ]
n <- nrow(d)

x <- d$score
right <- as.numeric(x >= 0)
w <- 1 - abs(x)

# Separate local-linear regressions, with side-specific intercepts and slopes.
X <- cbind(left_intercept = 1 - right,
           left_slope = (1 - right) * x,
           right_intercept = right,
           right_slope = right * x)

bread <- solve(crossprod(X, w * X))
Y <- cbind(earnings = d$earnings, participated = d$participated)
beta <- bread %*% crossprod(X, w * Y)
resid <- Y - X %*% beta

# Right limit minus left limit for each outcome.
contrast <- c(-1, 0, 1, 0)
jumps <- drop(contrast %*% beta)

# HC0 joint covariance, using the same observations and fixed weights.
loading <- drop(X %*% bread %*% contrast)
influence <- (w * loading) * resid
joint_cov <- crossprod(influence)

rf <- jumps[1]
fs <- jumps[2]
ratio <- rf / fs
gradient <- c(1 / fs, -rf / fs^2)
ratio_se <- sqrt(drop(t(gradient) %*% joint_cov %*% gradient))

row <- function(term, estimate, se) {
  list(term = term, estimate = unname(as.numeric(estimate)),
       se = unname(as.numeric(se)), n_obs = as.integer(n))
}

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    row("treatment_effect", ratio, ratio_se),
    row("reduced_form", rf, sqrt(joint_cov[1, 1])),
    row("first_stage", fs, sqrt(joint_cov[2, 2]))
  ),
  method_metadata = list(
    estimator = "weighted local-linear fuzzy regression discontinuity",
    vcov = "HC0 sandwich; fixed triangular weights; joint delta method"
  ),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null",
           digits = 16, pretty = TRUE)
