files <- c("crosswalk.csv", "trade.csv", "areas.csv", "employment.csv", "outcomes.csv")
data <- setNames(lapply(files, read.csv, stringsAsFactors = FALSE), files)

crosswalk <- data[["crosswalk.csv"]]
trade <- merge(data[["trade.csv"]], crosswalk, by = "code", all.x = TRUE, sort = FALSE)
areas <- data[["areas.csv"]]
employment <- data[["employment.csv"]]
outcomes <- data[["outcomes.csv"]]

stopifnot(!anyNA(trade$industry), !anyDuplicated(crosswalk$code))
stopifnot(!anyDuplicated(trade[c("period", "industry")]))
stopifnot(all(areas$vintage %in% c("base", "early")))

industries <- unique(crosswalk$industry)
periods <- unique(areas$period)

make_exposure <- function(period_value, vintage, trade_column) {
  area_rows <- areas[areas$period == period_value & areas$vintage == vintage, ]
  emp <- employment[
    employment$period == period_value & employment$vintage == vintage,
    c("area", "industry", "employment")
  ]

  national <- aggregate(employment ~ industry, data = emp, FUN = sum)
  national_lookup <- setNames(national$employment, national$industry)

  trade_period <- trade[trade$period == period_value, ]
  trade_lookup <- setNames(trade_period[[trade_column]], trade_period$industry)
  trade_lookup <- trade_lookup[industries]

  result <- numeric(nrow(area_rows))
  for (i in seq_len(nrow(area_rows))) {
    area_emp <- emp[emp$area == area_rows$area[i], ]
    area_lookup <- setNames(area_emp$employment, area_emp$industry)
    shares <- vapply(industries, function(industry) {
      value <- area_lookup[industry]
      if (is.na(value)) 0 else value
    }, numeric(1)) / area_rows$total_employment[i]

    national_values <- unname(national_lookup[industries])
    stopifnot(all(is.finite(national_values)), all(national_values > 0))
    stopifnot(all(is.finite(trade_lookup)))

    result[i] <- sum(
      shares * trade_lookup / national_values
    ) / (area_rows$price_index[i] / 100) / 1000 *
      (10 / area_rows$years[i])
  }
  data.frame(
    area = area_rows$area,
    period = area_rows$period,
    exposure = result
  )
}

exposure_base <- do.call(rbind, lapply(periods, make_exposure,
                                       vintage = "base",
                                       trade_column = "us_change"))
exposure_early <- do.call(rbind, lapply(periods, make_exposure,
                                        vintage = "early",
                                        trade_column = "other_change"))

names(exposure_base)[3] <- "x"
names(exposure_early)[3] <- "z"

regression_data <- merge(outcomes, exposure_base, by = c("area", "period"))
regression_data <- merge(regression_data, exposure_early, by = c("area", "period"))
area_weights <- unique(areas[areas$vintage == "base",
                             c("area", "period", "population")])
regression_data <- merge(regression_data, area_weights, by = c("area", "period"))

stopifnot(nrow(regression_data) == 72L)
regression_data$period_term <- as.numeric(factor(regression_data$period)) - 1
regression_data <- regression_data[order(regression_data$area, regression_data$period), ]

y <- regression_data$change_pp
w_sqrt <- sqrt(regression_data$population)
X <- cbind(
  intercept = 1,
  period = regression_data$period_term,
  control = regression_data$control,
  x = regression_data$x
)
Z <- cbind(
  intercept = 1,
  period = regression_data$period_term,
  control = regression_data$control,
  z = regression_data$z
)

Xw <- X * w_sqrt
Zw <- Z * w_sqrt
yw <- y * w_sqrt
projected_X <- qr.fitted(qr(Zw), Xw)
beta <- as.numeric(qr.coef(qr(projected_X), yw))
iv_slope <- beta[match("x", colnames(X))]

area0 <- regression_data[regression_data$area == 0, ]
stopifnot(all(periods %in% area0$period))

estimates <- list(
  list(term = "iv_slope", estimate = unname(iv_slope), se = NULL, n_obs = 72L),
  list(
    term = "exposure_area0_period0",
    estimate = unname(regression_data$x[regression_data$area == 0 &
                                          regression_data$period == periods[1]]),
    se = NULL,
    n_obs = 72L
  ),
  list(
    term = "exposure_area0_period1",
    estimate = unname(regression_data$x[regression_data$area == 0 &
                                          regression_data$period == periods[2]]),
    se = NULL,
    n_obs = 72L
  ),
  list(
    term = "instrument_area0_period0",
    estimate = unname(regression_data$z[regression_data$area == 0 &
                                          regression_data$period == periods[1]]),
    se = NULL,
    n_obs = 72L
  )
)

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    method = "weighted two-stage least squares",
    outcome = "change_pp",
    regressors = c("intercept", "period", "control", "x"),
    instruments = c("intercept", "period", "control", "z"),
    weight = "base-vintage population",
    exposure_units = "thousands of real dollars per worker per decade"
  ),
  diagnostics = list(n_obs = 72L)
)

jsonlite::write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  digits = 16,
  null = "null",
  pretty = TRUE
)
