library(forecast)
library(jsonlite)

dat <- read.csv("./input.csv")
y <- as.numeric(dat$y)

fit <- forecast::Arima(
  ts(y),
  order = c(1, 1, 1),
  include.mean = FALSE,
  include.drift = FALSE,
  method = "ML"
)

fc <- forecast::forecast(fit, h = 1, level = 95)
n <- length(y)

out <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = list(
    list(term = "forecast", estimate = unname(fc$mean[1]), se = NA_real_, n_obs = n),
    list(term = "lower_95", estimate = unname(fc$lower[1, 1]), se = NA_real_, n_obs = n),
    list(term = "upper_95", estimate = unname(fc$upper[1, 1]), se = NA_real_, n_obs = n)
  ),
  method_metadata = list(
    estimator = "ARIMA(1,1,1) by maximum likelihood, no constant or drift",
    vcov = "95% prediction interval from forecast package"
  ),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "./result.json", auto_unbox = TRUE, na = "null", digits = 15)
