files <- c(
  "crosswalk.csv",
  "trade.csv",
  "areas.csv",
  "employment.csv",
  "outcomes.csv"
)
data <- setNames(
  lapply(files, read.csv, stringsAsFactors = FALSE, check.names = FALSE),
  files
)

crosswalk <- data[["crosswalk.csv"]]
trade <- merge(data[["trade.csv"]], crosswalk, by = "code", all.x = TRUE)
areas <- data[["areas.csv"]]
employment <- data[["employment.csv"]]
outcomes <- data[["outcomes.csv"]]

stopifnot(!anyNA(trade$industry), !anyDuplicated(crosswalk$code))
stopifnot(!anyDuplicated(trade[c("period", "industry")]))
stopifnot(!anyDuplicated(areas[c("area", "period", "vintage")]))
stopifnot(!anyDuplicated(employment[c("area", "period", "vintage", "industry")]))
stopifnot(all(areas$vintage %in% c("base", "early")))

industries <- unique(crosswalk$industry)
periods <- sort(unique(areas$period))

make_exposure <- function(period_value, vintage, trade_column) {
  area_rows <- areas[
    areas$period == period_value & areas$vintage == vintage,
    ,
    drop = FALSE
  ]
  emp <- employment[
    employment$period == period_value & employment$vintage == vintage,
    c("area", "industry", "employment"),
    drop = FALSE
  ]

  national <- tapply(emp$employment, emp$industry, sum)
  trade_period <- trade[trade$period == period_value, , drop = FALSE]
  trade_lookup <- setNames(trade_period[[trade_column]], trade_period$industry)

  national_values <- national[as.character(industries)]
  trade_values <- trade_lookup[as.character(industries)]
  stopifnot(
    length(national_values) == length(industries),
    all(is.finite(national_values)),
    all(national_values > 0),
    length(trade_values) == length(industries),
    all(is.finite(trade_values))
  )

  result <- numeric(nrow(area_rows))
  for (i in seq_len(nrow(area_rows))) {
    area_emp <- emp[emp$area == area_rows$area[i], , drop = FALSE]
    area_lookup <- setNames(area_emp$employment, as.character(area_emp$industry))
    area_values <- area_lookup[as.character(industries)]
    area_values[is.na(area_values)] <- 0

    result[i] <- sum(
      (area_values / area_rows$total_employment[i]) *
        (trade_values / national_values)
    ) / (area_rows$price_index[i] / 100) / 1000 *
      (10 / area_rows$years[i])
  }

  data.frame(
    area = area_rows$area,
    period = area_rows$period,
    exposure = result
  )
}

exposure_base <- do.call(
  rbind,
  lapply(periods, make_exposure,
         vintage = "base", trade_column = "us_change")
)
exposure_early <- do.call(
  rbind,
  lapply(periods, make_exposure,
         vintage = "early", trade_column = "other_change")
)
names(exposure_base)[3] <- "x"
names(exposure_early)[3] <- "z"

regression_data <- merge(outcomes, exposure_base, by = c("area", "period"))
regression_data <- merge(regression_data, exposure_early, by = c("area", "period"))
base_weights <- unique(
  areas[areas$vintage == "base", c("area", "period", "population")]
)
regression_data <- merge(
  regression_data, base_weights, by = c("area", "period")
)

stopifnot(nrow(regression_data) == 72L)
regression_data$period_term <- as.numeric(
  factor(regression_data$period, levels = periods)
) - 1
regression_data <- regression_data[
  order(regression_data$area, regression_data$period),
  ,
  drop = FALSE
]

sqrt_weight <- sqrt(regression_data$population)
X <- cbind(
  intercept = 1,
  period = regression_data$period_term,
  control = regression_data$control,
  x = regression_data$x
)
Z <- cbind(
  intercept = 1,
  period = regression_data$period_term,
  control = regression_data$control,
  z = regression_data$z
)

Xw <- X * sqrt_weight
Zw <- Z * sqrt_weight
yw <- regression_data$change_pp * sqrt_weight
projected_X <- qr.fitted(qr(Zw), Xw)
beta <- qr.coef(qr(projected_X), yw)
iv_slope <- unname(beta["x"])

get_value <- function(column, period_value) {
  rows <- regression_data[
    regression_data$area == 0 & regression_data$period == period_value,
    column,
    drop = TRUE
  ]
  stopifnot(length(rows) == 1L, is.finite(rows))
  unname(rows)
}

n_obs <- 72L
estimates <- list(
  list(term = "iv_slope", estimate = iv_slope, se = NULL, n_obs = n_obs),
  list(
    term = "exposure_area0_period0",
    estimate = get_value("x", periods[1]),
    se = NULL,
    n_obs = n_obs
  ),
  list(
    term = "exposure_area0_period1",
    estimate = get_value("x", periods[2]),
    se = NULL,
    n_obs = n_obs
  ),
  list(
    term = "instrument_area0_period0",
    estimate = get_value("z", periods[1]),
    se = NULL,
    n_obs = n_obs
  )
)

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    method = "weighted two-stage least squares",
    outcome = "change_pp",
    regressors = c("intercept", "period", "control", "x"),
    instruments = c("intercept", "period", "control", "z"),
    weight = "base-vintage population",
    exposure_units = "thousands of real dollars per worker per decade"
  ),
  diagnostics = list(n_obs = n_obs)
)

jsonlite::write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  digits = 16,
  null = "null",
  pretty = TRUE
)
