dat <- read.csv("./input.csv")
y <- dat$y

fit <- stats::arima(
  y,
  order = c(1, 1, 1),
  include.mean = FALSE,
  method = "ML"
)

pred <- predict(fit, n.ahead = 1)
forecast <- as.numeric(pred$pred[1])
se <- as.numeric(pred$se[1])
lower <- forecast - stats::qnorm(0.975) * se
upper <- forecast + stats::qnorm(0.975) * se
n <- length(y)

result <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = list(
    list(term = "forecast", estimate = forecast, se = se, n_obs = n),
    list(term = "lower_95", estimate = lower, se = se, n_obs = n),
    list(term = "upper_95", estimate = upper, se = se, n_obs = n)
  ),
  method_metadata = list(
    estimator = "Gaussian maximum-likelihood ARIMA(1,1,1) without constant or drift",
    vcov = "Model-based one-step-ahead prediction variance"
  ),
  diagnostics = list()
)

jsonlite::write_json(
  result,
  path = "result.json",
  auto_unbox = TRUE,
  digits = NA,
  pretty = TRUE,
  null = "null"
)
