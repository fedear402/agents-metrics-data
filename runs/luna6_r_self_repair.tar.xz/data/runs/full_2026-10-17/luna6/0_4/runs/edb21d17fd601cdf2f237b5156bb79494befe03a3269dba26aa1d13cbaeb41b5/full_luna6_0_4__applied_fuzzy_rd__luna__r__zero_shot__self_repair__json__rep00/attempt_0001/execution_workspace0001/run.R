dat <- read.csv("input.csv")

d <- dat[abs(dat$score) < 1, ]
w <- 1 - abs(d$score)
n <- nrow(d)

right <- as.numeric(d$score >= 0)
x_left <- d$score * (1 - right)
x_right <- d$score * right
X <- cbind(intercept = 1, left_slope = x_left, right_slope = x_right)

fit_hc0 <- function(y) {
  bread <- solve(crossprod(X, w * X))
  beta <- bread %*% crossprod(X, w * y)
  residual <- as.numeric(y - X %*% beta)
  meat <- crossprod(X, (w * residual) * X)
  V <- bread %*% meat %*% bread
  list(beta = as.numeric(beta), V = V)
}

earnings_fit <- fit_hc0(d$earnings)
participation_fit <- fit_hc0(d$participated)

# The intercept is the fitted limit on each side, so its coefficient
# is the right-limit minus left-limit discontinuity.
rf <- earnings_fit$beta[1]
fs <- participation_fit$beta[1]

# Joint HC0 covariance of the two intercept discontinuity estimates.
bread <- solve(crossprod(X, w * X))
u_y <- as.numeric(d$earnings - X %*% earnings_fit$beta)
u_d <- as.numeric(d$participated - X %*% participation_fit$beta)
cov_y_d <- bread %*% crossprod(X, (w^2 * u_y * u_d) * X) %*% bread
cov_rf_fs <- cov_y_d[1, 1]

te <- rf / fs
var_te <- (earnings_fit$V[1, 1] / fs^2) +
  (rf^2 * participation_fit$V[1, 1] / fs^4) -
  (2 * rf * cov_rf_fs / fs^3)
se_te <- sqrt(max(0, var_te))

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = te, se = se_te, n_obs = n),
    list(term = "reduced_form", estimate = rf, se = sqrt(earnings_fit$V[1, 1]), n_obs = n),
    list(term = "first_stage", estimate = fs, se = sqrt(participation_fit$V[1, 1]), n_obs = n)
  ),
  method_metadata = list(
    estimator = "Fuzzy local-linear regression discontinuity with triangular weights",
    vcov = "HC0 sandwich; fixed bandwidth and weights; delta method with joint covariance"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE)
