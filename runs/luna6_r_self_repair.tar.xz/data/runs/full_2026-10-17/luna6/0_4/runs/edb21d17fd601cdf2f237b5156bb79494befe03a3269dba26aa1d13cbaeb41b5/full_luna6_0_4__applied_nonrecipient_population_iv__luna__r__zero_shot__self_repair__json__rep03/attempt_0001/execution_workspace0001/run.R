library(jsonlite)

households <- read.csv("households.csv", stringsAsFactors = FALSE)
census <- read.csv("census.csv", stringsAsFactors = FALSE)

# Retain every household that did not receive the transfer.
dat <- households[households$recipient == 0, , drop = FALSE]
n_obs <- nrow(dat)

ineligible <- 1 - dat$eligible
eligible <- dat$eligible

# Construct the specified exogenous regressors, endogenous regressors,
# and instruments. The four exogenous columns include the only intercept.
X <- cbind(
  ineligible = ineligible,
  eligible = eligible,
  baseline_ineligible = dat$baseline * ineligible,
  baseline_eligible = dat$baseline * eligible
)

D <- cbind(
  dose_ineligible = dat$dose * ineligible,
  dose_eligible = dat$dose * eligible
)

Z <- cbind(
  ineligible = ineligible,
  eligible = eligible,
  baseline_ineligible = dat$baseline * ineligible,
  baseline_eligible = dat$baseline * eligible,
  instrument_ineligible = dat$instrument * ineligible,
  instrument_eligible = dat$instrument * eligible
)

y <- dat$outcome
w <- dat$weight

# Weighted 2SLS: project all regressors onto the instrument space using
# weighted least squares, then regress the outcome on the projected columns.
weighted_project <- function(A, Z, w) {
  crossprod(Z, Z * w) |> solve(crossprod(Z, A * w))
}

Rmat <- weighted_project(cbind(X, D), Z, w)
projected <- Z %*% Rmat
bread <- solve(crossprod(projected, projected * w))
beta <- bread %*% crossprod(projected, y * w)
names(beta) <- c(colnames(X), colnames(D))

dose_ineligible <- unname(beta["dose_ineligible"])
dose_eligible <- unname(beta["dose_eligible"])

weighted_mean <- function(x, w) sum(x * w) / sum(w)
mean_dose_ineligible <- weighted_mean(dat$dose[ineligible == 1], w[ineligible == 1])
mean_dose_eligible <- weighted_mean(dat$dose[eligible == 1], w[eligible == 1])

ineligible_effect <- dose_ineligible * mean_dose_ineligible
eligible_nonrecipient_effect <- dose_eligible * mean_dose_eligible

pop_ineligible <- census$nonrecipient_population[census$eligible == 0]
pop_eligible <- census$nonrecipient_population[census$eligible == 1]
if (length(pop_ineligible) != 1L || length(pop_eligible) != 1L) {
  stop("census.csv must contain one population count for each eligibility group")
}

population_effect <- (
  ineligible_effect * pop_ineligible +
    eligible_nonrecipient_effect * pop_eligible
) / (pop_ineligible + pop_eligible)

estimates <- list(
  list(term = "ineligible_effect", estimate = as.numeric(ineligible_effect),
       se = NULL, n_obs = as.integer(n_obs)),
  list(term = "eligible_nonrecipient_effect",
       estimate = as.numeric(eligible_nonrecipient_effect),
       se = NULL, n_obs = as.integer(n_obs)),
  list(term = "population_effect", estimate = as.numeric(population_effect),
       se = NULL, n_obs = as.integer(n_obs))
)

result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "Weighted 2SLS",
    retained_sample = "All household rows with recipient == 0",
    endogenous_columns = c("dose*(1-eligible)", "dose*eligible"),
    exogenous_columns = c(
      "1-eligible", "eligible",
      "baseline*(1-eligible)", "baseline*eligible"
    ),
    instrument_columns = c(
      "1-eligible", "eligible",
      "baseline*(1-eligible)", "baseline*eligible",
      "instrument*(1-eligible)", "instrument*eligible"
    ),
    counterfactual = "Set dose to zero for every retained household",
    attribution_convention = paste(
      "Attribution to a zero-dose counterfactual is a stated synthetic convention."
    ),
    group_effect = paste(
      "Fitted group dose slope multiplied by the household-weighted mean dose",
      "among retained observations in that group."
    ),
    population_aggregation = paste(
      "Census nonrecipient_population counts determine only the final",
      "between-group weights."
    )
  ),
  diagnostics = list(n_obs = as.integer(n_obs))
)

write_json(result, "result.json", auto_unbox = TRUE, digits = 17, na = "null")
