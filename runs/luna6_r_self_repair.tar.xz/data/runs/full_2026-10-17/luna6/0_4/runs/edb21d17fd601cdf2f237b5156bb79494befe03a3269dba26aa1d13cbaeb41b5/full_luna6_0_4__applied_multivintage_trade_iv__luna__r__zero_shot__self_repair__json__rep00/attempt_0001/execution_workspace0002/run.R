library(jsonlite)

crosswalk <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
trade <- read.csv("trade.csv", stringsAsFactors = FALSE)
areas <- read.csv("areas.csv", stringsAsFactors = FALSE)
employment <- read.csv("employment.csv", stringsAsFactors = FALSE)
outcomes <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

# Keep identifiers in a common type for all joins.
crosswalk$code <- as.character(crosswalk$code)
trade$code <- as.character(trade$code)
crosswalk$industry <- as.character(crosswalk$industry)
employment$industry <- as.character(employment$industry)
areas$area <- as.character(areas$area)
employment$area <- as.character(employment$area)
outcomes$area <- as.character(outcomes$area)
areas$period <- as.character(areas$period)
employment$period <- as.character(employment$period)
trade$period <- as.character(trade$period)
outcomes$period <- as.character(outcomes$period)

trade <- merge(trade, crosswalk, by = "code", all.x = TRUE, sort = FALSE)

make_exposure <- function(vintage, trade_change) {
  a <- areas[areas$vintage == vintage, , drop = FALSE]
  e <- employment[employment$vintage == vintage, , drop = FALSE]

  # Build the complete area-industry grid. Omitted employment cells are zero.
  grid <- merge(
    a[, c("area", "period", "vintage", "total_employment")],
    unique(crosswalk["industry"]),
    by = NULL
  )
  e <- merge(
    grid,
    e[, c("area", "period", "vintage", "industry", "employment")],
    by = c("area", "period", "vintage", "industry"),
    all.x = TRUE,
    sort = FALSE
  )
  e$employment[is.na(e$employment)] <- 0

  national <- aggregate(
    employment ~ period + industry,
    data = e,
    FUN = sum
  )
  names(national)[names(national) == "employment"] <- "national_employment"

  e <- merge(e, national, by = c("period", "industry"), all.x = TRUE, sort = FALSE)
  e <- merge(
    e,
    trade[, c("period", "industry", trade_change, "price_index", "years")],
    by = c("period", "industry"),
    all.x = TRUE,
    sort = FALSE
  )

  e$component <- (e$employment / e$total_employment) *
    (e[[trade_change]] / e$national_employment) *
    (100 / e$price_index) / 1000 * (10 / e$years)

  aggregate(component ~ area + period, data = e, FUN = sum)
}

x <- make_exposure("base", "us_change")
z <- make_exposure("early", "other_change")
names(x)[names(x) == "component"] <- "x"
names(z)[names(z) == "component"] <- "z"

dat <- merge(outcomes, x, by = c("area", "period"), all.x = TRUE, sort = FALSE)
dat <- merge(dat, z, by = c("area", "period"), all.x = TRUE, sort = FALSE)
base_population <- areas[
  areas$vintage == "base",
  c("area", "period", "population"),
  drop = FALSE
]
dat <- merge(dat, base_population, by = c("area", "period"), all.x = TRUE, sort = FALSE)

# Encode the two periods as a numeric indicator.
period_levels <- sort(unique(dat$period))
dat$period_num <- match(dat$period, period_levels) - 1L
n_obs <- 72L

# Weighted 2SLS via weighted projections, with intercept, period, and control
# included in both the structural equation and instrument set.
X <- model.matrix(~ period_num + control + x, data = dat)
Z <- model.matrix(~ period_num + control + z, data = dat)
W <- diag(dat$population)
A <- crossprod(Z, W %*% X)
b <- crossprod(Z, W %*% dat$change_pp)
beta <- solve(A, b)
coef_x <- unname(beta[match("x", colnames(X)), 1])

get_value <- function(df, variable, area_value, period_value) {
  idx <- df$area == as.character(area_value) &
    df$period == as.character(period_value)
  as.numeric(df[[variable]][which(idx)[1]])
}

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = list(
    list(term = "iv_slope", estimate = as.numeric(coef_x), se = NULL, n_obs = 72L),
    list(term = "exposure_area0_period0",
         estimate = get_value(dat, "x", 0, 0), se = NULL, n_obs = 72L),
    list(term = "exposure_area0_period1",
         estimate = get_value(dat, "x", 0, 1), se = NULL, n_obs = 72L),
    list(term = "instrument_area0_period0",
         estimate = get_value(dat, "z", 0, 0), se = NULL, n_obs = 72L)
  ),
  n_obs = 72L,
  method_metadata = list(
    estimator = "population-weighted 2SLS",
    instrument = "z",
    endogenous_regressor = "x",
    exogenous_regressors = c("intercept", "period", "control"),
    exposure_units = "thousands of real dollars per worker per decade",
    trade_change_units = "nominal dollars over the stated interval"
  ),
  diagnostics = list(
    sample_count = 72L,
    area_period_rows = as.integer(nrow(dat)),
    instrument_rank = as.integer(qr(Z)$rank)
  )
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 17)
