library(jsonlite)

households <- read.csv("households.csv")
census <- read.csv("census.csv")

required_household_columns <- c(
  "eligible", "recipient", "instrument", "dose", "baseline", "weight", "outcome"
)
required_census_columns <- c("eligible", "nonrecipient_population")

if (!all(required_household_columns %in% names(households))) {
  stop("households.csv is missing required columns.")
}
if (!all(required_census_columns %in% names(census))) {
  stop("census.csv is missing required columns.")
}
if (any(!is.finite(households$weight)) || any(households$weight <= 0)) {
  stop("All estimation weights must be finite and positive.")
}

dat <- households[households$recipient == 0, , drop = FALSE]
n_obs <- nrow(dat)
if (n_obs == 0L) stop("No nonrecipient household observations are available.")

ineligible <- 1 - dat$eligible
eligible <- dat$eligible

endogenous <- cbind(
  dose_ineligible = dat$dose * ineligible,
  dose_eligible = dat$dose * eligible
)
exogenous <- cbind(
  ineligible = ineligible,
  eligible = eligible,
  baseline_ineligible = dat$baseline * ineligible,
  baseline_eligible = dat$baseline * eligible
)
instruments <- cbind(
  exogenous,
  instrument_ineligible = dat$instrument * ineligible,
  instrument_eligible = dat$instrument * eligible
)

x <- cbind(exogenous, endogenous)
w <- dat$weight
y <- dat$outcome

# Weighted 2SLS: project all regressors onto the specified instrument space,
# then solve the weighted second-stage normal equations.
sqrt_w <- sqrt(w)
weighted_instruments <- instruments * sqrt_w
weighted_x <- x * sqrt_w
weighted_y <- y * sqrt_w

q <- qr(weighted_instruments)
if (q$rank < ncol(instruments)) stop("The weighted instrument matrix is rank deficient.")
projected_x <- qr.fitted(q, weighted_x)
projected_y <- qr.fitted(q, weighted_y)

normal_matrix <- crossprod(weighted_x, projected_x)
if (qr(normal_matrix)$rank < ncol(normal_matrix)) {
  stop("The weighted 2SLS normal equations are rank deficient.")
}
beta <- solve(normal_matrix, crossprod(projected_x, weighted_y))

mean_dose <- function(group) {
  idx <- group == 1
  sum(dat$dose[idx] * w[idx]) / sum(w[idx])
}

ineligible_effect <- unname(beta["dose_ineligible"]) * mean_dose(ineligible)
eligible_nonrecipient_effect <- unname(beta["dose_eligible"]) * mean_dose(eligible)

population <- census$nonrecipient_population[match(c(0, 1), census$eligible)]
if (length(population) != 2L || anyNA(population) ||
    any(!is.finite(population)) || any(population < 0) || sum(population) <= 0) {
  stop("Census must provide valid nonrecipient population counts for both groups.")
}
population_effect <- (
  ineligible_effect * population[1] +
    eligible_nonrecipient_effect * population[2]
) / sum(population)

estimates <- list(
  list(term = "ineligible_effect", estimate = as.numeric(ineligible_effect),
       se = NULL, n_obs = as.integer(n_obs)),
  list(term = "eligible_nonrecipient_effect",
       estimate = as.numeric(eligible_nonrecipient_effect),
       se = NULL, n_obs = as.integer(n_obs)),
  list(term = "population_effect", estimate = as.numeric(population_effect),
       se = NULL, n_obs = as.integer(n_obs))
)

result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "weighted 2SLS",
    sample = "All household rows with recipient equal to zero, including both village treatment statuses.",
    endogenous_columns = c("dose*(1-eligible)", "dose*eligible"),
    exogenous_columns = c(
      "1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"
    ),
    instrument_columns = c(
      "1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible",
      "instrument*(1-eligible)", "instrument*eligible"
    ),
    intercept = "No additional intercept.",
    regression_weight = "weight",
    within_group_dose_average = "Household-weighted mean dose among retained observations in each eligibility group.",
    counterfactual = "Dose set to zero for every retained household.",
    attribution_convention = "Attribution to the zero-dose counterfactual is a stated synthetic convention.",
    population_aggregation = "Census nonrecipient_population counts are used only to average the two group effects."
  ),
  diagnostics = list(
    n_obs = as.integer(n_obs),
    se_status = "Standard errors are reported as null, as requested."
  )
)

write_json(result, "result.json", auto_unbox = TRUE, digits = 17, na = "null")
