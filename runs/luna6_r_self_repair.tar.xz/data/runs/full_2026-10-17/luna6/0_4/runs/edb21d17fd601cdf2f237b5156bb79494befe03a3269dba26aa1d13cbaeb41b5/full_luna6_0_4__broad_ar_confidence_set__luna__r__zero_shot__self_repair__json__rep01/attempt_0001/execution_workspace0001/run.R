d <- read.csv("input.csv")
n <- nrow(d)
critical <- qf(0.95, df1 = 2, df2 = n - 4)

# The tested instrument coefficients are linear in beta. Their Wald
# quadratic form yields a quadratic inequality F(beta) <= critical.
X <- model.matrix(~ x + z1 + z2, data = d)
M <- diag(n) - X %*% solve(crossprod(X), t(X))
Z <- as.matrix(d[, c("z1", "z2")])
Q <- crossprod(Z, M %*% Z)
A <- solve(Q)
endog <- d$endog
y <- d$y

# In the residualized instrument coordinates, the tested coefficients
# are proportional to crossprod(Z, M %*% (y - beta * endog)).
v0 <- crossprod(Z, M %*% y)
v1 <- crossprod(Z, M %*% endog)
scale <- n / (2 * critical)

qa <- as.numeric(scale * crossprod(v1, A %*% v1))
qb <- as.numeric(-2 * scale * crossprod(v0, A %*% v1))
qc <- as.numeric(scale * crossprod(v0, A %*% v0) - 1)

roots <- sort(Re(polyroot(c(qc, qb, qa))))
boundary_low <- roots[1]
boundary_high <- roots[2]

ar_f <- function(beta) {
  r <- y - beta * endog
  fit <- lm(r ~ x + z1 + z2, data = d)
  rss_full <- sum(resid(fit)^2)
  fit_restricted <- lm(r ~ x, data = d)
  rss_restricted <- sum(resid(fit_restricted)^2)
  ((rss_restricted - rss_full) / 2) / (rss_full / (n - 4))
}

estimates <- c(
  boundary_low = boundary_low,
  boundary_high = boundary_high,
  accepts_zero = as.numeric(ar_f(0) <= critical),
  unbounded = 0,
  ar_f_at_one = ar_f(1)
)

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = lapply(names(estimates), function(term) {
    list(term = term, estimate = unname(estimates[[term]]),
         se = NULL, n_obs = as.integer(n))
  }),
  method_metadata = list(
    estimator = "Anderson-Rubin test inversion using conventional homoskedastic joint F test",
    vcov = "Conventional homoskedastic"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = 15, null = "null")
