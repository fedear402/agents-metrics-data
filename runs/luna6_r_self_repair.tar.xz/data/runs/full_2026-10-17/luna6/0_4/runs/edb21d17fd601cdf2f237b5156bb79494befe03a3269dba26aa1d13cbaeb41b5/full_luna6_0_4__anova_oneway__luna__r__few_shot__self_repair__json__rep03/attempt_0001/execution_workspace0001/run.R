library(jsonlite)

data <- read.csv("./input.csv")
fit <- aov(y ~ factor(group), data = data)
anova_table <- summary(fit)[[1]]

f_stat <- anova_table[["F value"]][1]
df_num <- anova_table[["Df"]][1]
df_den <- anova_table[["Df"]][2]
p_value <- anova_table[["Pr(>F)"]][1]
n <- nrow(data)

out <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = list(
    list(term = "F", estimate = unname(f_stat), se = NULL, n_obs = n),
    list(term = "df_num", estimate = unname(df_num), se = NULL, n_obs = n),
    list(term = "df_den", estimate = unname(df_den), se = NULL, n_obs = n),
    list(term = "p_value", estimate = unname(p_value), se = NULL, n_obs = n)
  ),
  method_metadata = list(
    estimator = "One-way ANOVA",
    vcov = "Classical homoskedastic ANOVA"
  ),
  diagnostics = list()
)

write_json(out, "result.json", auto_unbox = TRUE, na = "null", digits = 15)
