files <- c(
  "crosswalk.csv",
  "trade.csv",
  "areas.csv",
  "employment.csv",
  "outcomes.csv"
)

missing_files <- files[!file.exists(files)]
if (length(missing_files) > 0L) {
  stop("Missing required files: ", paste(missing_files, collapse = ", "))
}

crosswalk <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
trade <- read.csv("trade.csv", stringsAsFactors = FALSE)
areas <- read.csv("areas.csv", stringsAsFactors = FALSE)
employment <- read.csv("employment.csv", stringsAsFactors = FALSE)
outcomes <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

trade <- merge(trade, crosswalk, by = "code", all.x = TRUE, sort = FALSE)
if (anyNA(trade$industry)) {
  stop("Each trade code must map to an industry.")
}

national <- aggregate(
  employment ~ period + vintage + industry,
  data = employment,
  FUN = sum
)

trade_periods <- unique(trade[c("period", "price_index", "years")])

make_exposure <- function(vintage, change_column) {
  area_data <- areas[areas$vintage == vintage, ]
  emp <- employment[employment$vintage == vintage, ]

  joined <- merge(
    area_data,
    emp,
    by = c("area", "period", "vintage"),
    all.x = TRUE,
    sort = FALSE
  )
  joined$employment[is.na(joined$employment)] <- 0

  joined <- merge(
    joined,
    trade[c("period", "industry", change_column)],
    by = c("period", "industry"),
    all.x = TRUE,
    sort = FALSE
  )
  joined <- merge(
    joined,
    national[national$vintage == vintage, c("period", "industry", "employment")],
    by = c("period", "industry"),
    all.x = TRUE,
    sort = FALSE,
    suffixes = c("_area", "_national")
  )
  joined <- merge(joined, trade_periods, by = "period", all.x = TRUE, sort = FALSE)

  if (anyNA(joined[[change_column]]) || anyNA(joined$employment_national)) {
    stop("Trade changes and national employment denominators must be available.")
  }

  joined$contribution <- (
    joined$employment_area / joined$total_employment
  ) * (
    joined[[change_column]] / joined$employment_national
  ) / (joined$price_index / 100) / 1000 * (10 / joined$years)

  aggregate(contribution ~ area + period, data = joined, FUN = sum)
}

x <- make_exposure("base", "us_change")
z <- make_exposure("early", "other_change")

regression_data <- merge(
  outcomes,
  areas[areas$vintage == "base", c("area", "period", "population")],
  by = c("area", "period"),
  all = FALSE,
  sort = FALSE
)
regression_data <- merge(
  regression_data,
  x,
  by = c("area", "period"),
  all = FALSE,
  sort = FALSE
)
regression_data <- merge(
  regression_data,
  z,
  by = c("area", "period"),
  all = FALSE,
  sort = FALSE,
  suffixes = c("_x", "_z")
)

names(regression_data)[names(regression_data) == "contribution_x"] <- "x"
names(regression_data)[names(regression_data) == "contribution_z"] <- "z"

if (nrow(regression_data) != 72L) {
  stop("Expected exactly 72 area-period estimation rows.")
}

weighted_2sls <- function(data) {
  w_sqrt <- sqrt(data$population)
  exogenous <- model.matrix(~ period + control, data = data)
  endogenous <- data$x
  instruments <- cbind(exogenous, z = data$z)
  regressors <- cbind(exogenous, x = endogenous)

  weighted_instruments <- instruments * w_sqrt
  weighted_regressors <- regressors * w_sqrt
  weighted_outcome <- data$change_pp * w_sqrt

  projected_regressors <- qr.fitted(qr(weighted_instruments), weighted_regressors)
  coefficients <- qr.coef(qr(projected_regressors), weighted_outcome)
  unname(coefficients["x"])
}

iv_slope <- weighted_2sls(regression_data)

area0_period0_x <- regression_data$x[
  regression_data$area == 0 & regression_data$period == 0
]
area0_period1_x <- regression_data$x[
  regression_data$area == 0 & regression_data$period == 1
]
area0_period0_z <- regression_data$z[
  regression_data$area == 0 & regression_data$period == 0
]

if (length(area0_period0_x) != 1L ||
    length(area0_period1_x) != 1L ||
    length(area0_period0_z) != 1L) {
  stop("Could not identify the requested area-period exposures.")
}

estimates <- list(
  list(term = "iv_slope", estimate = iv_slope, se = NULL, n_obs = 72L),
  list(term = "exposure_area0_period0", estimate = area0_period0_x, se = NULL, n_obs = 72L),
  list(term = "exposure_area0_period1", estimate = area0_period1_x, se = NULL, n_obs = 72L),
  list(term = "instrument_area0_period0", estimate = area0_period0_z, se = NULL, n_obs = 72L)
)

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    method = "population-weighted 2SLS",
    outcome = "change_pp",
    endogenous_regressor = "x",
    excluded_instrument = "z",
    included_exogenous = c("intercept", "period", "control"),
    exposure_units = "thousands of real dollars per worker per decade",
    national_employment_denominator = "sum of area-industry employment by period and vintage",
    omitted_employment_cells = 0
  ),
  diagnostics = list(n_obs = 72L)
)

jsonlite::write_json(
  result,
  path = "result.json",
  auto_unbox = TRUE,
  digits = 16,
  null = "null",
  pretty = TRUE
)
