d <- read.csv("input.csv")
n <- nrow(d)

# Residualize variables on the included regressors: intercept and x.
W <- model.matrix(~ x, data = d)
resid_on_W <- function(v) qr.resid(qr(W), v)

ry <- resid_on_W(d$y)
rd <- resid_on_W(d$endog)
Z <- cbind(resid_on_W(d$z1), resid_on_W(d$z2))

# Joint excluded-instrument test has q = 2 and denominator df = n - 4.
q <- 2L
df <- n - 4L
critical <- qf(0.95, df1 = q, df2 = df)

# Restricted and unrestricted residual sums of squares for y - beta*endog.
# SSR_R - (1 + q*critical/df)*SSR_U <= 0 defines the acceptance set.
k <- q * critical / df
uz <- qr.resid(qr(cbind(W, d$z1, d$z2)), d$y)
ud <- qr.resid(qr(cbind(W, d$z1, d$z2)), d$endog)
A <- sum(rd^2) - (1 + k) * sum(ud^2)
B <- -2 * (sum(ry * rd) - (1 + k) * sum(uz * ud))
C <- sum(ry^2) - (1 + k) * sum(uz^2)

disc <- B^2 - 4 * A * C
if (!is.finite(disc) || disc < 0 || abs(A) < 1e-12) {
  stop("The data do not yield two finite distinct Anderson-Rubin boundaries.")
}
bounds <- sort(c((-B - sqrt(disc)) / (2 * A),
                 (-B + sqrt(disc)) / (2 * A)))

accepts <- function(beta) A * beta^2 + B * beta + C <= 0
ar_f_at_one <- ((sum((ry - rd)^2) - sum((uz - ud)^2)) / q) /
  (sum((uz - ud)^2) / df)

rows <- list(
  list(term = "boundary_low", estimate = unname(bounds[1]), se = NULL, n_obs = n),
  list(term = "boundary_high", estimate = unname(bounds[2]), se = NULL, n_obs = n),
  list(term = "accepts_zero", estimate = as.integer(accepts(0)), se = NULL, n_obs = n),
  list(term = "unbounded", estimate = as.integer(A < 0), se = NULL, n_obs = n),
  list(term = "ar_f_at_one", estimate = unname(ar_f_at_one), se = NULL, n_obs = n)
)

jsonlite::write_json(
  list(
    task_id = "broad_ar_confidence_set",
    platform = "r",
    estimates = rows,
    method_metadata = list(
      estimator = "Anderson-Rubin inversion, homoskedastic joint F test",
      vcov = "Conventional homoskedastic"
    ),
    diagnostics = list()
  ),
  "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE
)
