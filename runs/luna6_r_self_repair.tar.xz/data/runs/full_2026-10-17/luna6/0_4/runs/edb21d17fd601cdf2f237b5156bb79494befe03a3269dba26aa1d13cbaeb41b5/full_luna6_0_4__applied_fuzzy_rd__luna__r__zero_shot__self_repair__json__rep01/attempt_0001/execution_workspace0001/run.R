d <- read.csv("input.csv")
d <- d[abs(d$score) < 1, ]
d$weight <- 1 - abs(d$score)
d$right <- as.integer(d$score >= 0)
d$x_right <- d$score * d$right
d$x_left <- d$score * (1 - d$right)

fit_rd <- function(y) {
  lm(y ~ right + x_left + x_right, data = d, weights = weight)
}

fit_y <- fit_rd(d$earnings)
fit_p <- fit_rd(d$participated)

b_y <- coef(fit_y)["right"]
b_p <- coef(fit_p)["right"]

# HC0 covariance for stacked outcomes, retaining cross-outcome covariance.
X <- model.matrix(fit_y)
w <- d$weight
bread <- solve(crossprod(X, X * w))
res_y <- residuals(fit_y)
res_p <- residuals(fit_p)
score_y <- X * as.numeric(w * res_y)
score_p <- X * as.numeric(w * res_p)
meat_yy <- crossprod(score_y)
meat_pp <- crossprod(score_p)
meat_yp <- crossprod(score_y, score_p)
V_yy <- bread %*% meat_yy %*% bread
V_pp <- bread %*% meat_pp %*% bread
V_yp <- bread %*% meat_yp %*% bread
j <- match("right", colnames(X))
var_y <- V_yy[j, j]
var_p <- V_pp[j, j]
cov_yp <- V_yp[j, j]

tau <- b_y / b_p
se_tau <- sqrt(var_y / b_p^2 + b_y^2 * var_p / b_p^4 -
                 2 * b_y * cov_yp / b_p^3)

out <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = unname(tau),
         se = unname(se_tau), n_obs = nrow(d)),
    list(term = "reduced_form", estimate = unname(b_y),
         se = sqrt(var_y), n_obs = nrow(d)),
    list(term = "first_stage", estimate = unname(b_p),
         se = sqrt(var_p), n_obs = nrow(d))
  ),
  method_metadata = list(
    estimator = "Weighted local-linear fuzzy regression discontinuity; triangular weights; bandwidth 1",
    vcov = "HC0, no degrees-of-freedom correction; delta method using joint covariance"
  ),
  diagnostics = list()
)
jsonlite::write_json(out, "result.json", auto_unbox = TRUE, digits = 15, na = "null")
