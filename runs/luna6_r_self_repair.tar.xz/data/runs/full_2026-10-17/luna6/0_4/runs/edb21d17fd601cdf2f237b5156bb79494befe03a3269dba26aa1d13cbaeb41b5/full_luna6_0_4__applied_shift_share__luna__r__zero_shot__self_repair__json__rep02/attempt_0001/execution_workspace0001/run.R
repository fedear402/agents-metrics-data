d <- read.csv("input.csv")

# Retain one regional record for regional weights and outcomes.
r <- d[!duplicated(d$region_id), c("region_id", "region_weight", "x", "y")]
r <- r[order(r$region_id), ]
e <- r$region_weight / sum(r$region_weight)

# Construct each region's shift-share instrument using all region-industry rows.
z_by_region <- aggregate(share * shock ~ region_id, data = d, FUN = sum)
names(z_by_region)[2] <- "z"
r <- merge(r, z_by_region, by = "region_id", sort = FALSE)
r <- r[match(unique(d$region_id), r$region_id), ]
e <- r$region_weight / sum(r$region_weight)

weighted_mean <- function(v, w) sum(w * v) / sum(w)
y0 <- r$y - weighted_mean(r$y, e)
x0 <- r$x - weighted_mean(r$x, e)
z0 <- r$z - weighted_mean(r$z, e)

# Aggregate region residuals to industry using analytic exposure weights.
industries <- unique(d$industry_id)
s <- vapply(industries, function(n) {
  idx <- d$industry_id == n
  sum(e[match(d$region_id[idx], r$region_id)] * d$share[idx])
}, numeric(1))

aggregate_residual <- function(v0) {
  vapply(seq_along(industries), function(j) {
    idx <- d$industry_id == industries[j]
    w <- e[match(d$region_id[idx], r$region_id)] * d$share[idx]
    sum(w * v0[match(d$region_id[idx], r$region_id)]) / s[j]
  }, numeric(1))
}

ybar <- aggregate_residual(y0)
xbar <- aggregate_residual(x0)
zbar <- aggregate_residual(z0)
shock_n <- vapply(industries, function(n) unique(d$shock[d$industry_id == n])[1], numeric(1))

# Weighted IV slope and HC1 standard error from structural residuals.
iv_hc1 <- function(y, endogenous, instrument, weights) {
  X <- cbind(1, endogenous)
  Z <- cbind(1, instrument)
  W <- diag(weights)
  A <- solve(crossprod(Z, W %*% X))
  beta <- A %*% crossprod(Z, W %*% y)
  u <- as.vector(y - X %*% beta)
  meat <- crossprod(Z, (weights * u^2) * Z)
  bread <- A %*% meat %*% t(A)
  V <- bread * length(y) / (length(y) - ncol(X))
  list(beta = as.vector(beta), se = sqrt(diag(V)))
}

N <- length(industries)
effect_fit <- iv_hc1(ybar, xbar, shock_n, s)
first_fit <- iv_hc1(xbar, zbar, shock_n, s)

out <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = effect_fit$beta[2], se = effect_fit$se[2], n_obs = N),
    list(term = "first_stage", estimate = first_fit$beta[2], se = first_fit$se[2], n_obs = N),
    list(term = "effective_shocks", estimate = 1 / sum(s^2), se = NULL, n_obs = N)
  ),
  method_metadata = list(
    estimator = "Borusyak-Hull-Jaravel shock-level weighted 2SLS",
    vcov = "shock-level analytic-weight HC1, structural IV residuals, no clustering"
  ),
  diagnostics = list()
)
jsonlite::write_json(out, "result.json", auto_unbox = TRUE, digits = 16, na = "null")
