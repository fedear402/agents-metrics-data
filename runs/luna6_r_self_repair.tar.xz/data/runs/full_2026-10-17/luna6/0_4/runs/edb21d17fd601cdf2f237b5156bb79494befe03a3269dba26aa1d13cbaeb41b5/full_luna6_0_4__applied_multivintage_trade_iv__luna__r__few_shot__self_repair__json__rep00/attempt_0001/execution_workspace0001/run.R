library(jsonlite)

crosswalk <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
trade <- read.csv("trade.csv", stringsAsFactors = FALSE)
areas <- read.csv("areas.csv", stringsAsFactors = FALSE)
employment <- read.csv("employment.csv", stringsAsFactors = FALSE)
outcomes <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

trade <- merge(trade, crosswalk, by = "code", all = FALSE)

# Sum area-industry employment across all supplied areas for each period,
# vintage, and industry. Omitted employment cells contribute zero.
national <- aggregate(
  employment ~ period + vintage + industry,
  data = employment,
  FUN = sum
)

make_exposure <- function(vintage, trade_change) {
  area_data <- areas[areas$vintage == vintage, ]
  nat <- national[national$vintage == vintage, ]
  merged <- merge(
    employment[employment$vintage == vintage, ],
    trade,
    by = c("period"),
    all = FALSE
  )
  merged <- merge(merged, nat, by = c("period", "vintage", "industry"),
                  all.x = TRUE, suffixes = c("", ".national"))
  merged <- merge(
    merged,
    area_data[, c("area", "period", "total_employment", "population")],
    by = c("area", "period"),
    all.x = TRUE
  )

  change <- merged[[trade_change]]
  merged$component <- (
    (merged$employment / merged$total_employment) *
      (change / merged$employment.national) /
      (merged$price_index / 100) / 1000 * (10 / merged$years)
  )

  result <- aggregate(
    component ~ area + period,
    data = merged,
    FUN = sum
  )
  names(result)[names(result) == "component"] <- if (vintage == "base") "x" else "z"
  result
}

# Construct employment-by-industry cells, adding zero rows where a cell is absent.
make_cells <- function(vintage) {
  a <- areas[areas$vintage == vintage, c("area", "period", "total_employment")]
  i <- unique(crosswalk$industry)
  grid <- merge(a, data.frame(industry = i), by = NULL)
  e <- employment[employment$vintage == vintage, c("area", "period", "industry", "employment")]
  merge(grid, e, by = c("area", "period", "industry"), all.x = TRUE)
}

# Calculate exposures by joining each industry cell to its period-specific trade row
# and national industry employment denominator.
make_exposure <- function(vintage, trade_change) {
  a <- areas[areas$vintage == vintage, c("area", "period", "total_employment")]
  cells <- make_cells(vintage)
  nat <- national[national$vintage == vintage, c("period", "industry", "employment")]
  names(nat)[names(nat) == "employment"] <- "national_employment"

  d <- merge(cells, nat, by = c("period", "industry"), all.x = TRUE)
  t <- trade[, c("period", "industry", trade_change, "price_index", "years")]
  d <- merge(d, t, by = c("period", "industry"), all.x = TRUE)
  d <- merge(d, a, by = c("area", "period"), all.x = TRUE)
  d$employment[is.na(d$employment)] <- 0

  d$component <- (d$employment / d$total_employment) *
    (d[[trade_change]] / d$national_employment) /
    (d$price_index / 100) / 1000 * (10 / d$years)

  ans <- aggregate(component ~ area + period, d, sum)
  names(ans)[names(ans) == "component"] <- if (vintage == "base") "x" else "z"
  ans
}

x_data <- make_exposure("base", "us_change")
z_data <- make_exposure("early", "other_change")

# Use base-vintage area-period records and attach early-vintage exposure.
base_areas <- areas[areas$vintage == "base", ]
est <- merge(base_areas, x_data, by = c("area", "period"), all = TRUE)
est <- merge(est, z_data, by = c("area", "period"), all = TRUE)
est <- merge(est, outcomes, by = c("area", "period"), all = TRUE)

est$period_indicator <- as.numeric(as.factor(est$period)) - 1
X <- model.matrix(~ period_indicator + control + x, data = est)
Z <- model.matrix(~ period_indicator + control + z, data = est)
w <- est$population

# Weighted 2SLS: project every regressor onto the full instrument matrix,
# then regress the outcome on the projected regressors.
sqrt_w <- sqrt(w)
Xw <- X * sqrt_w
Zw <- Z * sqrt_w
yw <- est$change_pp * sqrt_w
Xhat <- qr.fitted(qr(Zw), Xw)
beta <- solve(crossprod(Xw, Xhat), crossprod(Xhat, yw))
iv_slope <- as.numeric(beta[ncol(X)])

period_levels <- unique(est$period)
period0 <- period_levels[1]
period1 <- period_levels[2]
area0 <- unique(est$area)[1]

exposure_area0_period0 <- est$x[est$area == area0 & est$period == period0][1]
exposure_area0_period1 <- est$x[est$area == area0 & est$period == period1][1]
instrument_area0_period0 <- est$z[est$area == area0 & est$period == period0][1]

estimates <- list(
  list(term = "iv_slope", estimate = iv_slope, se = NULL, n_obs = 72L),
  list(term = "exposure_area0_period0", estimate = exposure_area0_period0, se = NULL, n_obs = 72L),
  list(term = "exposure_area0_period1", estimate = exposure_area0_period1, se = NULL, n_obs = 72L),
  list(term = "instrument_area0_period0", estimate = instrument_area0_period0, se = NULL, n_obs = 72L)
)

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "weighted_2sls",
    outcome = "change_pp",
    endogenous_regressor = "x",
    excluded_instrument = "z",
    exogenous_regressors = c("intercept", "period", "control"),
    regression_weight = "base-vintage population",
    exposure_units = "thousands of real dollars per worker per decade"
  ),
  diagnostics = list(n_obs = 72L)
)

write_json(result, "result.json", auto_unbox = TRUE, digits = 15, null = "null")
