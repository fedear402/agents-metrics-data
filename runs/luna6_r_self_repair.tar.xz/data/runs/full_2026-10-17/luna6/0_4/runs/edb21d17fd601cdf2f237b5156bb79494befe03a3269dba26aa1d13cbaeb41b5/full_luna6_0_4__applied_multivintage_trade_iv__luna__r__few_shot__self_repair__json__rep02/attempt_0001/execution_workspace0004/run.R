files <- c(
  "crosswalk.csv",
  "trade.csv",
  "areas.csv",
  "employment.csv",
  "outcomes.csv"
)

data <- setNames(
  lapply(files, read.csv, stringsAsFactors = FALSE, check.names = FALSE),
  files
)

crosswalk <- data[["crosswalk.csv"]]
trade <- merge(data[["trade.csv"]], crosswalk, by = "code", all.x = TRUE)
areas <- data[["areas.csv"]]
employment <- data[["employment.csv"]]
outcomes <- data[["outcomes.csv"]]

stopifnot(
  !anyNA(trade$industry),
  !anyDuplicated(crosswalk$code),
  !anyDuplicated(trade[c("period", "industry")]),
  !anyDuplicated(areas[c("area", "period", "vintage")]),
  !anyDuplicated(employment[c("area", "period", "vintage", "industry")]),
  all(areas$vintage %in% c("base", "early"))
)

industries <- as.character(unique(crosswalk$industry))
periods <- sort(unique(areas$period))

make_exposure <- function(period_value, vintage, trade_column) {
  area_rows <- areas[
    areas$period == period_value & areas$vintage == vintage,
    ,
    drop = FALSE
  ]
  emp <- employment[
    employment$period == period_value & employment$vintage == vintage,
    ,
    drop = FALSE
  ]
  trade_period <- trade[trade$period == period_value, , drop = FALSE]

  area_keys <- as.character(area_rows$area)
  area_industry <- expand.grid(
    area_key = area_keys,
    industry_key = industries,
    stringsAsFactors = FALSE
  )
  emp$area_key <- as.character(emp$area)
  emp$industry_key <- as.character(emp$industry)
  emp_key <- paste(emp$area_key, emp$industry_key, sep = "\r")
  grid_key <- paste(area_industry$area_key, area_industry$industry_key, sep = "\r")

  match_index <- match(grid_key, emp_key)
  area_industry$employment <- 0
  present <- !is.na(match_index)
  area_industry$employment[present] <- emp$employment[match_index[present]]

  national <- vapply(
    industries,
    function(industry_key) {
      sum(area_industry$employment[area_industry$industry_key == industry_key])
    },
    numeric(1)
  )

  trade_lookup <- setNames(
    trade_period[[trade_column]],
    as.character(trade_period$industry)
  )
  trade_values <- unname(trade_lookup[industries])

  stopifnot(
    all(is.finite(national)),
    all(national > 0),
    length(trade_values) == length(industries),
    all(is.finite(trade_values)),
    all(is.finite(area_rows$total_employment)),
    all(area_rows$total_employment > 0),
    all(is.finite(area_rows$price_index)),
    all(is.finite(area_rows$years))
  )

  result <- numeric(nrow(area_rows))
  for (i in seq_len(nrow(area_rows))) {
    area_match <- area_industry$area_key == as.character(area_rows$area[i])
    area_values <- area_industry$employment[area_match]
    names(area_values) <- area_industry$industry_key[area_match]
    area_values <- area_values[industries]

    result[i] <- sum(
      (area_values / area_rows$total_employment[i]) *
        (trade_values / national)
    ) /
      (area_rows$price_index[i] / 100) /
      1000 *
      (10 / area_rows$years[i])
  }

  data.frame(
    area = area_rows$area,
    period = area_rows$period,
    exposure = result
  )
}

exposure_base <- do.call(
  rbind,
  lapply(periods, make_exposure, vintage = "base", trade_column = "us_change")
)
names(exposure_base)[3] <- "x"

exposure_early <- do.call(
  rbind,
  lapply(periods, make_exposure, vintage = "early", trade_column = "other_change")
)
names(exposure_early)[3] <- "z"

regression_data <- merge(outcomes, exposure_base, by = c("area", "period"))
regression_data <- merge(regression_data, exposure_early, by = c("area", "period"))

base_weights <- areas[
  areas$vintage == "base",
  c("area", "period", "population"),
  drop = FALSE
]
regression_data <- merge(
  regression_data,
  base_weights,
  by = c("area", "period")
)

stopifnot(nrow(regression_data) == 72L)

regression_data$period_term <- as.numeric(
  factor(regression_data$period, levels = periods)
) - 1

regression_data <- regression_data[
  order(regression_data$area, regression_data$period),
  ,
  drop = FALSE
]

sqrt_weight <- sqrt(regression_data$population)
X <- cbind(
  intercept = 1,
  period = regression_data$period_term,
  control = regression_data$control,
  x = regression_data$x
)
Z <- cbind(
  intercept = 1,
  period = regression_data$period_term,
  control = regression_data$control,
  z = regression_data$z
)

Xw <- X * sqrt_weight
Zw <- Z * sqrt_weight
yw <- regression_data$change_pp * sqrt_weight
projected_X <- qr.fitted(qr(Zw), Xw)
beta <- qr.coef(qr(projected_X), yw)
iv_slope <- unname(beta["x"])

get_value <- function(column, period_value) {
  rows <- regression_data[
    as.character(regression_data$area) == "0" &
      regression_data$period == period_value,
    column,
    drop = TRUE
  ]
  stopifnot(length(rows) == 1L, is.finite(rows))
  unname(rows)
}

n_obs <- 72L
estimates <- list(
  list(term = "iv_slope", estimate = iv_slope, se = NULL, n_obs = n_obs),
  list(
    term = "exposure_area0_period0",
    estimate = get_value("x", periods[1]),
    se = NULL,
    n_obs = n_obs
  ),
  list(
    term = "exposure_area0_period1",
    estimate = get_value("x", periods[2]),
    se = NULL,
    n_obs = n_obs
  ),
  list(
    term = "instrument_area0_period0",
    estimate = get_value("z", periods[1]),
    se = NULL,
    n_obs = n_obs
  )
)

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    method = "weighted two-stage least squares",
    outcome = "change_pp",
    regressors = c("intercept", "period", "control", "x"),
    instruments = c("intercept", "period", "control", "z"),
    weight = "base-vintage population",
    exposure_units = "thousands of real dollars per worker per decade"
  ),
  diagnostics = list(n_obs = n_obs)
)

jsonlite::write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  digits = 16,
  null = "null",
  pretty = TRUE
)
