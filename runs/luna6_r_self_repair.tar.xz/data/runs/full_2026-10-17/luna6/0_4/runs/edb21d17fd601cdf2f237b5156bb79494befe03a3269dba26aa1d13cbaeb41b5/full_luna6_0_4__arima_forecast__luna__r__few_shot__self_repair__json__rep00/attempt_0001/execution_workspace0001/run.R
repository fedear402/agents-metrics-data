library(forecast)
library(jsonlite)

dat <- read.csv("./input.csv")
y <- as.numeric(dat$y)

fit <- Arima(y, order = c(1, 1, 1), include.mean = FALSE,
             include.drift = FALSE, method = "ML")
pred <- forecast(fit, h = 1, level = 95)

n <- length(y)
out <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = list(
    list(term = "forecast", estimate = unname(pred$mean[1]),
         se = unname(pred$se[1]), n_obs = n),
    list(term = "lower_95", estimate = unname(pred$lower[1, "95%"]),
         se = NA_real_, n_obs = n),
    list(term = "upper_95", estimate = unname(pred$upper[1, "95%"]),
         se = NA_real_, n_obs = n)
  ),
  method_metadata = list(
    estimator = "ARIMA(1,1,1) maximum likelihood, no constant or drift",
    vcov = "Prediction interval based on fitted ARIMA model"
  ),
  diagnostics = structure(list(), names = character(0))
)
write_json(out, "result.json", auto_unbox = TRUE, na = "null", digits = 15)
