data <- read.csv("./input.csv")
if (!"y" %in% names(data)) stop("input.csv must contain a column named y")
y <- data$y
if (!is.numeric(y) || anyNA(y) || length(y) < 2L) {
  stop("y must be a numeric series with at least two non-missing observations")
}

fit <- stats::arima(y, order = c(1, 1, 1), include.mean = FALSE, method = "ML")
pred <- stats::predict(fit, n.ahead = 1L)
forecast <- as.numeric(pred$pred[1L])
se <- as.numeric(pred$se[1L])
lower_95 <- forecast - stats::qnorm(0.975) * se
upper_95 <- forecast + stats::qnorm(0.975) * se

result <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = list(
    list(term = "forecast", estimate = forecast, se = se, n_obs = length(y)),
    list(term = "lower_95", estimate = lower_95, se = NULL, n_obs = length(y)),
    list(term = "upper_95", estimate = upper_95, se = NULL, n_obs = length(y))
  ),
  method_metadata = list(
    estimator = "Gaussian maximum-likelihood ARIMA(1,1,1) for y, with no constant or drift",
    vcov = "Model-based one-step-ahead forecast variance"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "./result.json", auto_unbox = TRUE, digits = 16, na = "null")
