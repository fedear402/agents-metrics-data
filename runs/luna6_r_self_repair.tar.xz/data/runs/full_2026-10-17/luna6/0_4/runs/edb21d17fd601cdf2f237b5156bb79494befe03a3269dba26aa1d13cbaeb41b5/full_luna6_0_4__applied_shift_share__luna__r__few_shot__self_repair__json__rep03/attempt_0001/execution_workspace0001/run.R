library(jsonlite)

dat <- read.csv("input.csv", stringsAsFactors = FALSE)

required <- c("region_id", "industry_id", "share", "shock",
              "region_weight", "x", "y")
if (!all(required %in% names(dat))) {
  stop("input.csv is missing one or more required columns")
}
if (anyNA(dat[required])) stop("Required data contain missing values")

region_id <- unique(dat$region_id)
industry_id <- unique(dat$industry_id)

region_values <- function(variable) {
  values <- split(dat[[variable]], dat$region_id)
  if (any(vapply(values, function(v) length(unique(v)) != 1L, logical(1)))) {
    stop(paste(variable, "must be constant within region"))
  }
  vapply(region_id, function(id) values[[as.character(id)]][1], numeric(1))
}

region_weight <- region_values("region_weight")
x <- region_values("x")
y <- region_values("y")

e <- region_weight / sum(region_weight)
if (any(!is.finite(e)) || any(e < 0)) stop("Invalid regional weights")

share_matrix <- matrix(0, nrow = length(region_id), ncol = length(industry_id),
                       dimnames = list(as.character(region_id),
                                       as.character(industry_id)))
industry_shock <- numeric(length(industry_id))
names(industry_shock) <- as.character(industry_id)

for (j in seq_along(industry_id)) {
  rows <- dat[dat$industry_id == industry_id[j], , drop = FALSE]
  if (length(unique(rows$shock)) != 1L) {
    stop("shock must be constant within industry")
  }
  industry_shock[j] <- rows$shock[1]
  for (i in seq_along(region_id)) {
    share_matrix[i, j] <- sum(rows$share[rows$region_id == region_id[i]])
  }
}

if (any(abs(rowSums(share_matrix) - 1) > 1e-8)) {
  stop("Industry shares must sum to one within each region")
}

z <- drop(share_matrix %*% industry_shock)
weighted_center <- function(v) v - sum(e * v)
y0 <- weighted_center(y)
x0 <- weighted_center(x)
z0 <- weighted_center(z)

s <- drop(crossprod(e, share_matrix))
if (any(s <= 0)) stop("Every industry must have positive exposure mass")

aggregate_residual <- function(v0) {
  drop(crossprod(share_matrix, e * v0)) / s
}

ybar <- aggregate_residual(y0)
xbar <- aggregate_residual(x0)
zbar <- aggregate_residual(z0)

shock_iv <- function(dependent, endogenous, instrument) {
  n <- length(dependent)
  if (n <= 2L) stop("At least three industries are required for HC1")
  W <- cbind(1, instrument)
  Q <- cbind(1, endogenous)
  A <- crossprod(W, s * Q)
  beta <- solve(A, crossprod(W, s * dependent))
  residual <- drop(dependent - Q %*% beta)
  scores <- W * (s * residual)
  Ainv <- solve(A)
  covariance <- (n / (n - 2)) * Ainv %*% crossprod(scores) %*% t(Ainv)
  c(estimate = beta[2], se = sqrt(covariance[2, 2]))
}

effect <- shock_iv(ybar, xbar, industry_shock)
first_stage <- shock_iv(xbar, zbar, industry_shock)
effective_shocks <- 1 / sum(s^2)
n <- length(industry_id)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = unname(effect["estimate"]),
         se = unname(effect["se"]), n_obs = n),
    list(term = "first_stage", estimate = unname(first_stage["estimate"]),
         se = unname(first_stage["se"]), n_obs = n),
    list(term = "effective_shocks", estimate = effective_shocks,
         se = NULL, n_obs = n)
  ),
  method_metadata = list(
    estimator = "Weighted regional 2SLS with Borusyak-Hull-Jaravel shock-level IV aggregation",
    vcov = "Shock-level heteroskedasticity-robust HC1 using structural IV residuals and analytic exposure weights"
  ),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16,
           pretty = TRUE)
