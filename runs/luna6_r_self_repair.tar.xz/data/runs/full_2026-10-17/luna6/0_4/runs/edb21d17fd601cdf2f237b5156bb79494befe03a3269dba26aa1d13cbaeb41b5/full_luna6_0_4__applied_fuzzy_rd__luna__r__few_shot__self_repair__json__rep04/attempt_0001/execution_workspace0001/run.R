library(jsonlite)

data <- read.csv("input.csv")
inside <- abs(data$score) < 1
d <- data[inside, ]
n <- nrow(d)

x <- d$score
right <- as.numeric(x >= 0)
X <- cbind(left_intercept = 1 - right,
           left_slope = (1 - right) * x,
           right_intercept = right,
           right_slope = right * x)
w <- 1 - abs(x)
bread <- solve(crossprod(X, w * X))

Y <- cbind(earnings = d$earnings,
           participated = d$participated)
beta <- bread %*% crossprod(X, w * Y)
residuals <- Y - X %*% beta

contrast <- c(-1, 0, 1, 0)
discontinuities <- drop(contrast %*% beta)

loading <- w * drop(X %*% bread %*% contrast)
influence <- loading * residuals
joint_vcov <- crossprod(influence)
ses <- sqrt(diag(joint_vcov))

reduced_form <- discontinuities[1]
first_stage <- discontinuities[2]
treatment_effect <- reduced_form / first_stage
gradient <- c(1 / first_stage, -reduced_form / first_stage^2)
treatment_se <- sqrt(drop(t(gradient) %*% joint_vcov %*% gradient))

row <- function(term, estimate, se) {
  list(term = term, estimate = unname(as.numeric(estimate)),
       se = unname(as.numeric(se)), n_obs = as.integer(n))
}

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    row("treatment_effect", treatment_effect, treatment_se),
    row("reduced_form", reduced_form, ses[1]),
    row("first_stage", first_stage, ses[2])
  ),
  method_metadata = list(
    estimator = "Weighted local-linear fuzzy regression discontinuity; triangular kernel; bandwidth 1",
    vcov = "Joint HC0 sandwich covariance; fixed bandwidth and weights; no degrees-of-freedom correction"
  ),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null",
           digits = 16, pretty = TRUE)
