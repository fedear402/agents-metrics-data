library(jsonlite)

crosswalk <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
trade <- read.csv("trade.csv", stringsAsFactors = FALSE)
areas <- read.csv("areas.csv", stringsAsFactors = FALSE)
employment <- read.csv("employment.csv", stringsAsFactors = FALSE)
outcomes <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

trade <- merge(trade, crosswalk, by = "code", all = FALSE)
industries <- unique(crosswalk$industry)

make_exposure <- function(vintage, change_column) {
  emp <- employment[employment$vintage == vintage, ]
  area_keys <- unique(areas[c("area", "period", "vintage")])
  area_keys <- area_keys[area_keys$vintage == vintage, c("area", "period")]

  totals <- areas[areas$vintage == vintage,
                  c("area", "period", "total_employment")]
  names(totals)[3] <- "total_employment"

  national <- aggregate(
    employment ~ period + industry,
    data = merge(emp, crosswalk, by = "industry", all = FALSE),
    FUN = sum
  )
  names(national)[3] <- "national_employment"

  tr <- trade[c("period", "industry", change_column, "price_index", "years")]
  names(tr)[3] <- "trade_change"
  dat <- merge(emp, tr, by = c("period", "industry"), all = FALSE)
  dat <- merge(dat, national, by = c("period", "industry"), all.x = TRUE)
  dat$component <- (dat$employment / dat$national_employment) *
    (dat$trade_change / (dat$price_index / 100)) / 1000 *
    (10 / dat$years)

  sums <- aggregate(component ~ area + period, data = dat, FUN = sum)
  sums <- merge(sums, totals, by = c("area", "period"), all.x = TRUE)
  sums$exposure <- sums$component / sums$total_employment
  sums[c("area", "period", "exposure")]
}

# Fill omitted area-industry cells with zero by summing observed cells over
# the complete set of industries for each area-period.
complete_employment <- function(vintage) {
  keys <- areas[areas$vintage == vintage, c("area", "period")]
  grid <- merge(keys, data.frame(industry = industries), by = NULL)
  observed <- employment[employment$vintage == vintage,
                         c("area", "period", "industry", "employment")]
  merged <- merge(grid, observed,
                  by = c("area", "period", "industry"), all.x = TRUE)
  merged$employment[is.na(merged$employment)] <- 0
  merged
}

employment <- rbind(complete_employment("base"),
                    complete_employment("early"))

x <- make_exposure("base", "us_change")
z <- make_exposure("early", "other_change")
names(x)[3] <- "x"
names(z)[3] <- "z"

reg <- merge(outcomes, areas[areas$vintage == "base",
                             c("area", "period", "population")],
             by = c("area", "period"), all = FALSE)
reg <- merge(reg, x, by = c("area", "period"), all = FALSE)
reg <- merge(reg, z, by = c("area", "period"), all = FALSE)
reg <- merge(reg, trade[c("period", "price_index")],
             by = "period", all.x = TRUE)
reg <- reg[!duplicated(reg[c("area", "period")]), ]

period_values <- sort(unique(reg$period))
reg$period_indicator <- as.integer(reg$period == period_values[2])

X <- model.matrix(~ period_indicator + control + x, data = reg)
Z <- model.matrix(~ period_indicator + control + z, data = reg)
sqrt_w <- sqrt(reg$population)
Xw <- X * sqrt_w
Zw <- Z * sqrt_w
yw <- reg$change_pp * sqrt_w

PZ_X <- qr.fitted(qr(Zw), Xw)
PZ_y <- qr.fitted(qr(Zw), yw)
beta <- solve(crossprod(Xw, PZ_X), crossprod(Xw, PZ_y))
iv_slope <- as.numeric(beta[which(colnames(X) == "x")])

area0 <- reg[reg$area == 0, ]
area0 <- area0[order(area0$period), ]

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = list(
    list(term = "iv_slope", estimate = iv_slope, se = NULL, n_obs = 72L),
    list(term = "exposure_area0_period0",
         estimate = area0$x[match(period_values[1], area0$period)],
         se = NULL, n_obs = 72L),
    list(term = "exposure_area0_period1",
         estimate = area0$x[match(period_values[2], area0$period)],
         se = NULL, n_obs = 72L),
    list(term = "instrument_area0_period0",
         estimate = area0$z[match(period_values[1], area0$period)],
         se = NULL, n_obs = 72L)
  ),
  method_metadata = list(
    estimator = "weighted two-stage least squares",
    outcome = "change_pp",
    endogenous_regressor = "x",
    excluded_instrument = "z",
    exogenous_regressors = c("intercept", "period_indicator", "control"),
    weight = "base-vintage population",
    exposure_units = "thousands of real dollars per worker per decade"
  ),
  diagnostics = list(n_obs = 72L)
)

write_json(result, "result.json", auto_unbox = TRUE, digits = 15, pretty = TRUE)
