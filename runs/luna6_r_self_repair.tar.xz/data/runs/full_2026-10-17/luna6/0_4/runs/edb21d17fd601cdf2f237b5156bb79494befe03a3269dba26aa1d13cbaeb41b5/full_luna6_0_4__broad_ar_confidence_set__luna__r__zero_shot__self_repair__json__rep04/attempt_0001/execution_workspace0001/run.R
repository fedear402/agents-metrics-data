dat <- read.csv("input.csv")
n <- nrow(dat)

critical <- qf(0.95, df1 = 2, df2 = n - 4)

ar_f <- function(beta) {
  fit <- lm(I(y - beta * endog) ~ x + z1 + z2, data = dat)
  an <- anova(fit)
  rss_restricted <- sum(resid(lm(I(y - beta * endog) ~ x, data = dat))^2)
  rss_full <- sum(resid(fit)^2)
  ((rss_restricted - rss_full) / 2) / (rss_full / (n - 4))
}

# The residualized instrument coefficients are affine in beta. Their
# joint Wald numerator is therefore a quadratic, and the boundary equation
# is a quadratic as well.
full_design <- model.matrix(~ x + z1 + z2, data = dat)
restricted_design <- model.matrix(~ x, data = dat)
y_res <- qr.resid(qr(restricted_design), dat$y)
endog_res <- qr.resid(qr(restricted_design), dat$endog)
z_res <- qr.resid(qr(restricted_design), cbind(dat$z1, dat$z2))

# Equivalently, fit the full model at beta=0 and beta=1 to obtain the
# instrument coefficient vector and its change with beta.
fit0 <- lm(y ~ x + z1 + z2, data = dat)
fit1 <- lm(I(y - endog) ~ x + z1 + z2, data = dat)
idx <- match(c("z1", "z2"), names(coef(fit0)))
b0 <- coef(fit0)[idx]
b1 <- coef(fit1)[idx] - b0

# For each beta, F = (RSS_restricted - RSS_full)/2 divided by
# RSS_full/(n-4). Construct RSS values from the corresponding regressions.
rss_full <- function(beta) {
  sum(resid(lm(I(y - beta * endog) ~ x + z1 + z2, data = dat))^2)
}
rss_restricted <- function(beta) {
  sum(resid(lm(I(y - beta * endog) ~ x, data = dat))^2)
}

# Solve the boundary condition using its exact quadratic form:
# RSS_restricted = (1 + 2*critical/(n-4)) * RSS_full.
qfun <- function(beta) {
  rss_restricted(beta) -
    (1 + 2 * critical / (n - 4)) * rss_full(beta)
}
qcoef <- vapply(c(0, 1, -1), qfun, numeric(1))
c0 <- qcoef[1]
c2 <- (qcoef[2] + qcoef[3] - 2 * c0) / 2
c1 <- (qcoef[2] - qcoef[3]) / 2
roots <- polyroot(c(c0, c1, c2))
roots <- Re(roots[abs(Im(roots)) < 1e-8])
roots <- sort(roots)

boundary_low <- roots[1]
boundary_high <- roots[length(roots)]
accepts_zero <- as.integer(ar_f(0) <= critical)
unbounded <- 0L
ar_f_at_one <- ar_f(1)

estimates <- list(
  list(term = "boundary_low", estimate = boundary_low, se = NULL, n_obs = n),
  list(term = "boundary_high", estimate = boundary_high, se = NULL, n_obs = n),
  list(term = "accepts_zero", estimate = accepts_zero, se = NULL, n_obs = n),
  list(term = "unbounded", estimate = unbounded, se = NULL, n_obs = n),
  list(term = "ar_f_at_one", estimate = ar_f_at_one, se = NULL, n_obs = n)
)

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "Anderson-Rubin confidence set by inversion of the homoskedastic joint F test",
    vcov = "Conventional homoskedastic"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16)
