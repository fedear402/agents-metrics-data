library(jsonlite)

data <- read.csv("input.csv", stringsAsFactors = FALSE)
data$date <- as.Date(data$date)
data <- data[order(data$date), ]

log_vix <- log(data$vix)
vol_change <- c(NA_real_, diff(log_vix))
log_sales <- log(data$sales)
n <- nrow(data)

# At observation t, lag_j is the volatility change at t-j.
lag_data <- as.data.frame(
  setNames(
    lapply(1:15, function(j) c(rep(NA_real_, j + 1L), vol_change[seq_len(n - j - 1L)])),
    paste0("lag_", 1:15)
  )
)
regression_data <- data.frame(log_sales = log_sales, lag_data)
regressors <- paste0("lag_", 1:15)
sample <- regression_data[complete.cases(regression_data), , drop = FALSE]

fit <- lm(log_sales ~ ., data = sample)
X <- model.matrix(fit)
beta <- coef(fit)
N <- nrow(X)
p <- ncol(X)

scores <- X * as.numeric(residuals(fit))
meat <- crossprod(scores)

for (j in 1:15) {
  lag_product <- crossprod(
    scores[(j + 1L):N, , drop = FALSE],
    scores[1:(N - j), , drop = FALSE]
  )
  meat <- meat + (1 - j / 16) * (lag_product + t(lag_product))
}

bread <- solve(crossprod(X))
covariance <- (N / (N - 16)) * bread %*% meat %*% bread
contrast <- c(0, rep(1, 15))

cumulative_response <- sum(contrast * beta)
cumulative_se <- sqrt(drop(t(contrast) %*% covariance %*% contrast))

row <- function(term, estimate, se) {
  list(
    term = term,
    estimate = unname(as.numeric(estimate)),
    se = unname(as.numeric(se)),
    n_obs = as.integer(N)
  )
}

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    row("cumulative_response", cumulative_response, cumulative_se),
    row("lag_1", beta["lag_1"], sqrt(covariance["lag_1", "lag_1"])),
    row("lag_15", beta["lag_15"], sqrt(covariance["lag_15", "lag_15"]))
  ),
  method_metadata = list(
    estimator = "OLS with 15 lags of first differences in log(vix)",
    vcov = "Newey-West HAC with Bartlett weights, maximum lag 15, and correction N/(N-16)"
  ),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
