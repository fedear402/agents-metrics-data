import json
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("input.csv")

# Keep one regional record for regional variables and normalize weights once.
regions = df[["region_id", "region_weight", "x", "y"]].drop_duplicates("region_id").copy()
regions["e"] = regions["region_weight"] / regions["region_weight"].sum()

# Construct the shift-share instrument from all region-industry observations.
df = df.merge(regions[["region_id", "e"]], on="region_id", how="left")
df["share_shock"] = df["share"] * df["shock"]
z = df.groupby("region_id", as_index=False)["share_shock"].sum().rename(
    columns={"share_shock": "z"}
)
regions = regions.merge(z, on="region_id", how="left")

# Weighted demean regional variables.
for var in ["y", "x", "z"]:
    regions[f"{var}0"] = regions[var] - (regions["e"] * regions[var]).sum()

# Aggregate residuals to the industry shock level.
df = df.merge(regions[["region_id", "e", "y0", "x0", "z0"]], on="region_id", how="left")
df["weighted_share"] = df["e"] * df["share"]
industry = df.groupby("industry_id", as_index=False).agg(
    s=("weighted_share", "sum"),
    shock=("shock", "first"),
    y_sum=("weighted_share", lambda v: 0.0),
)
for var in ["y0", "x0", "z0"]:
    df[f"{var}_weighted_share"] = df["weighted_share"] * df[var]
    agg = df.groupby("industry_id")[f"{var}_weighted_share"].sum()
    industry = industry.merge(agg.rename(f"{var}_sum"), on="industry_id", how="left")
    industry[f"{var}bar"] = industry[f"{var}_sum"] / industry["s"]

N = len(industry)
weights = industry["s"].to_numpy()

# Shock-level IV slope and structural-residual HC1 standard error.
def weighted_iv(endog, exog, instrument, weights):
    endog = pd.Series(endog).to_numpy()
    exog = pd.DataFrame(exog).to_numpy()
    instrument = pd.DataFrame(instrument).to_numpy()
    root_w = weights ** 0.5
    xw = exog * root_w[:, None]
    zw = instrument * root_w[:, None]
    yw = endog * root_w
    beta = pd.linalg.lstsq(zw, xw, rcond=None)[0] if False else None
    # 2SLS using weighted least squares projections.
    projection = zw @ pd.linalg.pinv(zw.T @ zw) @ zw.T
    beta = pd.linalg.pinv(xw.T @ projection @ xw) @ (xw.T @ projection @ yw)
    residual = endog - exog @ beta
    bread = pd.linalg.pinv(xw.T @ projection @ xw)
    meat = xw.T @ projection @ (np.diag(weights * residual**2)) @ projection @ xw
    covariance = bread @ meat @ bread * (len(endog) / (len(endog) - 2))
    return beta, covariance

import numpy as np

# Effect: ybar on intercept and xbar, instrumented by intercept and shock.
effect_beta, effect_cov = weighted_iv(
    industry["y0bar"],
    np.column_stack([np.ones(N), industry["x0bar"]]),
    np.column_stack([np.ones(N), industry["shock"]]),
    weights,
)

# First stage: xbar on intercept and zbar, instrumented by intercept and shock.
first_beta, first_cov = weighted_iv(
    industry["x0bar"],
    np.column_stack([np.ones(N), industry["z0bar"]]),
    np.column_stack([np.ones(N), industry["shock"]]),
    weights,
)

effective_shocks = 1.0 / np.sum(industry["s"].to_numpy() ** 2)

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {
            "term": "effect",
            "estimate": float(effect_beta[1]),
            "se": float(np.sqrt(effect_cov[1, 1])),
            "n_obs": int(N),
        },
        {
            "term": "first_stage",
            "estimate": float(first_beta[1]),
            "se": float(np.sqrt(first_cov[1, 1])),
            "n_obs": int(N),
        },
        {
            "term": "effective_shocks",
            "estimate": float(effective_shocks),
            "se": None,
            "n_obs": int(N),
        },
    ],
    "method_metadata": {
        "estimator": "Borusyak-Hull-Jaravel shock-level weighted 2SLS",
        "vcov": "heteroskedasticity-robust HC1, analytic weights, no clustering",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2)
