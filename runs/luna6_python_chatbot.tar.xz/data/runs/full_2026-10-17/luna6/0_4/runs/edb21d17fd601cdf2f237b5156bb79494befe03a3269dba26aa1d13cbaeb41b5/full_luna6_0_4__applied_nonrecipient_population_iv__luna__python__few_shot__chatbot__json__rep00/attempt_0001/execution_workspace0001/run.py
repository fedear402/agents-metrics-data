import json
import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS

households = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

d = households.loc[households["recipient"] == 0].copy()
n_obs = int(len(d))

eligible = d["eligible"].astype(float)
ineligible = 1.0 - eligible

exog = pd.DataFrame(
    {
        "ineligible": ineligible,
        "eligible": eligible,
        "baseline_ineligible": d["baseline"] * ineligible,
        "baseline_eligible": d["baseline"] * eligible,
    },
    index=d.index,
)
endog = pd.DataFrame(
    {
        "dose_ineligible": d["dose"] * ineligible,
        "dose_eligible": d["dose"] * eligible,
    },
    index=d.index,
)
instruments = pd.DataFrame(
    {
        **exog.to_dict(orient="series"),
        "instrument_ineligible": d["instrument"] * ineligible,
        "instrument_eligible": d["instrument"] * eligible,
    },
    index=d.index,
)

fit = IV2SLS(
    dependent=d["outcome"],
    exog=exog,
    endog=endog,
    instruments=instruments[[
        "ineligible",
        "eligible",
        "baseline_ineligible",
        "baseline_eligible",
        "instrument_ineligible",
        "instrument_eligible",
    ]],
    weights=d["weight"],
).fit()

ineligible_slope = float(fit.params["dose_ineligible"])
eligible_slope = float(fit.params["dose_eligible"])

ineligible_rows = d["eligible"] == 0
eligible_rows = d["eligible"] == 1
ineligible_mean_dose = float(
    np.average(d.loc[ineligible_rows, "dose"], weights=d.loc[ineligible_rows, "weight"])
)
eligible_mean_dose = float(
    np.average(d.loc[eligible_rows, "dose"], weights=d.loc[eligible_rows, "weight"])
)

ineligible_effect = ineligible_slope * ineligible_mean_dose
eligible_nonrecipient_effect = eligible_slope * eligible_mean_dose

population_weights = (
    census.set_index("eligible")["nonrecipient_population"]
    .reindex([0, 1])
    .to_numpy(dtype=float)
)
population_effect = float(
    np.average(
        [ineligible_effect, eligible_nonrecipient_effect],
        weights=population_weights,
    )
)

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "ineligible_effect",
            "estimate": float(ineligible_effect),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "eligible_nonrecipient_effect",
            "estimate": float(eligible_nonrecipient_effect),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "population_effect",
            "estimate": population_effect,
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "dependent_variable": "outcome",
        "sample_restriction": "recipient == 0",
        "endogenous_variables": [
            "dose*(1-eligible)",
            "dose*eligible",
        ],
        "exogenous_variables": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
        ],
        "instruments": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
            "instrument*(1-eligible)",
            "instrument*eligible",
        ],
        "regression_weight": "weight",
        "within_group_dose_average_weight": "weight",
        "counterfactual": "dose set to zero for every retained household",
        "attribution_convention": "synthetic zero-dose counterfactual",
        "population_aggregation_weights": "census nonrecipient_population by eligibility",
        "census_used_for_estimation": False,
    },
    "diagnostics": {
        "n_obs": n_obs,
        "retained_household_rows": n_obs,
        "ineligible_slope": ineligible_slope,
        "eligible_slope": eligible_slope,
        "ineligible_weighted_mean_dose": ineligible_mean_dose,
        "eligible_weighted_mean_dose": eligible_mean_dose,
        "ineligible_group_effect_check": float(ineligible_slope * ineligible_mean_dose),
        "eligible_group_effect_check": float(eligible_slope * eligible_mean_dose),
        "census_nonrecipient_population": {
            "ineligible": float(population_weights[0]),
            "eligible": float(population_weights[1]),
        },
    },
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, allow_nan=False)
