import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("input.csv")

# Collapse repeated region-level variables to one observation per region.
regions = df[["region_id", "region_weight", "x", "y"]].drop_duplicates("region_id").copy()
regions["e"] = regions["region_weight"] / regions["region_weight"].sum()

# Construct the regional shift-share instrument.
df["exposure_shock"] = df["share"] * df["shock"]
z = df.groupby("region_id", as_index=False)["exposure_shock"].sum().rename(
    columns={"exposure_shock": "z"}
)
regions = regions.merge(z, on="region_id", validate="one_to_one")

# Remove e-weighted regional means.
for variable in ("y", "x", "z"):
    mean = np.sum(regions["e"] * regions[variable])
    regions[f"{variable}0"] = regions[variable] - mean

# Aggregate residuals to industry level using weighted employment exposure.
work = df[["region_id", "industry_id", "share"]].merge(
    regions[["region_id", "e", "y0", "x0", "z0"]],
    on="region_id",
    validate="many_to_one",
)
work["weighted_share"] = work["e"] * work["share"]
industry = work.groupby("industry_id").agg(
    s=("weighted_share", "sum"),
    y_num=("weighted_share", lambda a: 0.0),
)
# Compute weighted sums directly for each residual.
for variable in ("y0", "x0", "z0"):
    work[f"{variable}_num"] = work["weighted_share"] * work[variable]
    sums = work.groupby("industry_id")[f"{variable}_num"].sum()
    industry[variable] = sums / industry["s"]

industry = industry.join(
    df.groupby("industry_id")["shock"].first().rename("shock"),
    how="left",
)
industry = industry.loc[industry["s"] > 0].copy()
N = len(industry)
weights = industry["s"].to_numpy()

def weighted_iv_hc1(y, endogenous, instrument):
    """One-endogenous-regressor weighted 2SLS with structural-residual HC1."""
    y = np.asarray(y, dtype=float)
    endogenous = np.asarray(endogenous, dtype=float)
    instrument = np.asarray(instrument, dtype=float)
    w = weights
    Z = np.column_stack([np.ones(len(y)), instrument])
    X = np.column_stack([np.ones(len(y)), endogenous])

    zwz = Z.T @ (w[:, None] * Z)
    xwz = X.T @ (w[:, None] * Z)
    wy = Z.T @ (w * y)
    beta = np.linalg.solve(xwz @ np.linalg.solve(zwz, xwz.T), xwz @ np.linalg.solve(zwz, wy))
    residual = y - X @ beta

    bread = np.linalg.inv(xwz @ np.linalg.solve(zwz, xwz.T))
    meat = np.zeros((2, 2))
    for i in range(len(y)):
        zi = Z[i]
        xi = X[i]
        score_map = xi * w[i] * residual[i]
        projected = bread @ score_map
        meat += np.outer(projected, projected)
    cov = meat * (N / (N - 2))
    return float(beta[1]), float(np.sqrt(cov[1, 1]))

effect, effect_se = weighted_iv_hc1(
    industry["y0"], industry["x0"], industry["shock"]
)
first_stage, first_stage_se = weighted_iv_hc1(
    industry["x0"], industry["z0"], industry["shock"]
)
effective_shocks = 1.0 / np.sum(weights**2)

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {
            "term": "effect",
            "estimate": effect,
            "se": effect_se,
            "n_obs": int(N),
        },
        {
            "term": "first_stage",
            "estimate": first_stage,
            "se": first_stage_se,
            "n_obs": int(N),
        },
        {
            "term": "effective_shocks",
            "estimate": float(effective_shocks),
            "se": None,
            "n_obs": int(N),
        },
    ],
    "method_metadata": {
        "estimator": "regional weighted 2SLS with Borusyak-Hull-Jaravel shock-level aggregation",
        "vcov": "shock-level structural-residual analytic-weight HC1, multiplier N/(N-2), no clustering",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, allow_nan=False)
