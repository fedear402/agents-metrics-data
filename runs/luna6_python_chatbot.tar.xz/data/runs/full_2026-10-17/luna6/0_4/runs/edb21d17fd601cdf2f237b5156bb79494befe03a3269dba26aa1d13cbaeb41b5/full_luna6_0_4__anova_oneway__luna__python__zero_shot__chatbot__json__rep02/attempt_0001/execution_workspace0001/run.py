import json

import pandas as pd
from scipy import stats

data = pd.read_csv("./input.csv")
groups = [g["y"].dropna().to_numpy() for _, g in data.groupby("group", dropna=True)]

if len(groups) < 2:
    raise ValueError("One-way ANOVA requires at least two groups.")

n_obs = sum(len(group) for group in groups)
df_num = len(groups) - 1
df_den = n_obs - len(groups)

if any(len(group) == 0 for group in groups) or df_den <= 0:
    raise ValueError("One-way ANOVA requires observations in each group and positive residual degrees of freedom.")

result = stats.f_oneway(*groups)
f_stat = float(result.statistic)
p_value = float(result.pvalue)

output = {
    "task_id": "anova_oneway",
    "platform": "python",
    "estimates": [
        {"term": "F", "estimate": f_stat, "se": None, "n_obs": int(n_obs)},
        {"term": "df_num", "estimate": float(df_num), "se": None, "n_obs": int(n_obs)},
        {"term": "df_den", "estimate": float(df_den), "se": None, "n_obs": int(n_obs)},
        {"term": "p_value", "estimate": p_value, "se": None, "n_obs": int(n_obs)},
    ],
    "method_metadata": {
        "estimator": "One-way ANOVA",
        "vcov": "Classical homoskedastic ANOVA",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(output, f, indent=2, allow_nan=False)
