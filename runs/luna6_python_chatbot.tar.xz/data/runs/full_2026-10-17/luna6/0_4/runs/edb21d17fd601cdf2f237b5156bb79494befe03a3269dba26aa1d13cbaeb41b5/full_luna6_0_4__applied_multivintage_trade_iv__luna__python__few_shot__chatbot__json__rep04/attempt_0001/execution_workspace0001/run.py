import json
import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS

crosswalk = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv")
areas = pd.read_csv("areas.csv")
employment = pd.read_csv("employment.csv")
outcomes = pd.read_csv("outcomes.csv")

trade = trade.merge(crosswalk[["code", "industry"]], on="code", how="left", validate="many_to_one")
if trade["industry"].isna().any():
    raise ValueError("Every trade code must map to an industry.")

# Omitted area-industry cells are zero. Sum duplicate rows, if any, before filling.
employment = (
    employment.groupby(["area", "period", "vintage", "industry"], as_index=False)["employment"]
    .sum()
)

exposures = []
for period, period_trade in trade.groupby("period", sort=False):
    if period_trade["price_index"].nunique() != 1 or period_trade["years"].nunique() != 1:
        raise ValueError("price_index and years must be constant within period.")

    price_index = float(period_trade["price_index"].iloc[0])
    years = float(period_trade["years"].iloc[0])
    period_areas = areas[areas["period"] == period].copy()

    for vintage, change_column in (("base", "us_change"), ("early", "other_change")):
        area_rows = period_areas[period_areas["vintage"] == vintage].copy()
        if area_rows["area"].duplicated().any():
            raise ValueError("Expected one area row per period and vintage.")

        emp = employment[
            (employment["period"] == period) & (employment["vintage"] == vintage)
        ].merge(crosswalk[["code", "industry"]], on="industry", how="right")
        # Build employment totals by industry across all supplied areas.
        national = (
            employment[
                (employment["period"] == period) & (employment["vintage"] == vintage)
            ]
            .groupby("industry")["employment"]
            .sum()
        )

        changes = period_trade.set_index("industry")[change_column]
        shock = changes / national.reindex(changes.index)
        shock = shock / (price_index / 100.0) / 1000.0 * (10.0 / years)

        area_emp = employment[
            (employment["period"] == period) & (employment["vintage"] == vintage)
        ]
        wide = area_emp.pivot_table(
            index="area", columns="industry", values="employment", aggfunc="sum", fill_value=0
        )
        for industry in shock.index:
            if industry not in wide.columns:
                wide[industry] = 0.0
        numerator = wide.reindex(columns=shock.index, fill_value=0).mul(shock, axis=1).sum(axis=1)
        area_rows = area_rows.set_index("area")
        area_rows["exposure"] = numerator.reindex(area_rows.index, fill_value=0) / area_rows["total_employment"]
        area_rows = area_rows.reset_index()
        area_rows["vintage"] = vintage
        exposures.append(area_rows[["area", "period", "vintage", "exposure"]])

exposures = pd.concat(exposures, ignore_index=True)
x = exposures[exposures["vintage"] == "base"].rename(columns={"exposure": "x"})[
    ["area", "period", "x"]
]
z = exposures[exposures["vintage"] == "early"].rename(columns={"exposure": "z"})[
    ["area", "period", "z"]
]

panel = (
    outcomes.merge(x, on=["area", "period"], how="inner", validate="one_to_one")
    .merge(z, on=["area", "period"], how="inner", validate="one_to_one")
    .merge(
        areas[areas["vintage"] == "base"][["area", "period", "population"]],
        on=["area", "period"],
        how="inner",
        validate="one_to_one",
    )
)

if len(panel) != 72:
    raise ValueError(f"Expected 72 area-period observations, found {len(panel)}.")

period_values = pd.get_dummies(panel["period"], drop_first=True, dtype=float)
period_values.columns = [f"period_{i}" for i in range(period_values.shape[1])]
exog = pd.concat(
    [
        pd.Series(1.0, index=panel.index, name="intercept"),
        period_values,
        panel["control"].astype(float).rename("control"),
    ],
    axis=1,
)
fit = IV2SLS(
    dependent=panel["change_pp"].astype(float),
    exog=exog,
    endog=panel[["x"]].astype(float),
    instruments=panel[["z"]].astype(float),
    weights=panel["population"].astype(float),
).fit()

area0 = panel[panel["area"] == 0]
periods = list(pd.unique(panel["period"]))
if len(periods) < 2:
    raise ValueError("Expected at least two periods.")
period0, period1 = periods[0], periods[1]

estimates = [
    {"term": "iv_slope", "estimate": float(fit.params["x"]), "se": None, "n_obs": 72},
    {
        "term": "exposure_area0_period0",
        "estimate": float(area0.loc[area0["period"] == period0, "x"].iloc[0]),
        "se": None,
        "n_obs": 72,
    },
    {
        "term": "exposure_area0_period1",
        "estimate": float(area0.loc[area0["period"] == period1, "x"].iloc[0]),
        "se": None,
        "n_obs": 72,
    },
    {
        "term": "instrument_area0_period0",
        "estimate": float(area0.loc[area0["period"] == period0, "z"].iloc[0]),
        "se": None,
        "n_obs": 72,
    },
]

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "Weighted 2SLS",
        "dependent_variable": "change_pp",
        "endogenous_regressor": "x",
        "excluded_instrument": "z",
        "exogenous_regressors": list(exog.columns),
        "exogenous_instruments_included": True,
        "weight": "base-vintage population",
        "exposure_units": "thousands of real dollars per worker per decade",
    },
    "diagnostics": {"n_obs": 72},
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, allow_nan=False)
