import json
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("input.csv")
df["date"] = pd.to_datetime(df["date"])
df = df.sort_values("date").reset_index(drop=True)

df["delta_log_vix"] = df["vix"].apply(lambda x: __import__("math").log(x)).diff()
for lag in range(1, 16):
    df[f"lag_{lag}"] = df["delta_log_vix"].shift(lag)

df["log_sales"] = df["sales"].apply(lambda x: __import__("math").log(x))
reg = df.dropna(subset=[f"lag_{lag}" for lag in range(1, 16)] + ["log_sales"]).copy()

lag_cols = [f"lag_{lag}" for lag in range(1, 16)]
X = sm.add_constant(reg[lag_cols])
y = reg["log_sales"]
fit = sm.OLS(y, X).fit()

n_obs = int(len(reg))
max_lag = 15
resid = fit.resid.to_numpy()
x = X.to_numpy()
bread = __import__("numpy").linalg.inv(x.T @ x)
scores = x * resid[:, None]

meat = scores.T @ scores
for j in range(1, max_lag + 1):
    weight = 1.0 - j / 16.0
    cross = scores[j:].T @ scores[:-j]
    meat += weight * (cross + cross.T)

cov = bread @ meat @ bread
cov *= n_obs / (n_obs - 16)

params = fit.params.to_numpy()
lag_sum = float(params[1:].sum())
sum_vector = __import__("numpy").array([0.0] + [1.0] * 15)
cumulative_se = float(__import__("numpy").sqrt(sum_vector @ cov @ sum_vector))

estimates = [
    {
        "term": "cumulative_response",
        "estimate": lag_sum,
        "se": cumulative_se,
        "n_obs": n_obs,
    },
    {
        "term": "lag_1",
        "estimate": float(fit.params["lag_1"]),
        "se": float(__import__("numpy").sqrt(cov[1, 1])),
        "n_obs": n_obs,
    },
    {
        "term": "lag_15",
        "estimate": float(fit.params["lag_15"]),
        "se": float(__import__("numpy").sqrt(cov[15, 15])),
        "n_obs": n_obs,
    },
]

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "OLS of log(sales) on intercept and lags 1 through 15 of the first difference of log(vix)",
        "vcov": "Newey-West HAC with maximum lag 15, Bartlett weights 1-j/16, and finite-sample multiplier N/(N-16)",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, allow_nan=False)
