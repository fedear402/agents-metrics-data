import json
import numpy as np
import pandas as pd

crosswalk = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv")
areas = pd.read_csv("areas.csv")
employment = pd.read_csv("employment.csv")
outcomes = pd.read_csv("outcomes.csv")

trade = trade.merge(crosswalk, on="code", how="inner", validate="many_to_one")

# Sum employment across all supplied areas for each period, vintage, and industry.
national = (
    employment.groupby(["period", "vintage", "industry"], as_index=False)["employment"]
    .sum()
    .rename(columns={"employment": "national_employment"})
)

# Fill omitted area-industry cells with zero by completing the supplied area,
# period, vintage, and industry combinations.
industries = sorted(crosswalk["industry"].unique())
area_vintages = areas[["area", "period", "vintage"]].drop_duplicates()
grid = area_vintages.assign(_key=1).merge(
    pd.DataFrame({"industry": industries, "_key": 1}), on="_key"
).drop(columns="_key")
employment_full = grid.merge(
    employment,
    on=["area", "period", "vintage", "industry"],
    how="left",
    validate="one_to_one",
)
employment_full["employment"] = employment_full["employment"].fillna(0)

def build_exposure(area_vintage, trade_change, exposure_name):
    frame = (
        employment_full.loc[employment_full["vintage"] == area_vintage]
        .merge(
            areas.loc[areas["vintage"] == area_vintage],
            on=["area", "period", "vintage"],
            how="inner",
            validate="many_to_one",
            suffixes=("", "_area"),
        )
        .merge(national, on=["period", "vintage", "industry"], how="inner")
        .merge(
            trade[["period", "industry", trade_change, "price_index", "years"]],
            on=["period", "industry"],
            how="inner",
            validate="many_to_one",
        )
    )
    frame["_component"] = (
        (frame["employment"] / frame["total_employment"])
        * (frame[trade_change] / frame["national_employment"])
        / (frame["price_index"] / 100.0)
        / 1000.0
        * (10.0 / frame["years"])
    )
    return frame.groupby(["area", "period"], as_index=False)["_component"].sum().rename(
        columns={"_component": exposure_name}
    )

x = build_exposure("base", "us_change", "x")
z = build_exposure("early", "other_change", "z")

# Form the 72 area-period estimation rows.
base_area = areas.loc[areas["vintage"] == "base", ["area", "period", "population"]]
data = (
    outcomes.merge(base_area, on=["area", "period"], how="inner", validate="one_to_one")
    .merge(x, on=["area", "period"], how="inner", validate="one_to_one")
    .merge(z, on=["area", "period"], how="inner", validate="one_to_one")
    .sort_values(["area", "period"])
    .reset_index(drop=True)
)

period_values = sorted(data["period"].unique())
data["period_indicator"] = (data["period"] == period_values[1]).astype(float)

# Weighted 2SLS: regress each endogenous/exogenous regressor on all instruments
# using population weights, then estimate the weighted second-stage equation.
Y = data["change_pp"].to_numpy(dtype=float)
X = np.column_stack(
    [
        np.ones(len(data)),
        data["period_indicator"].to_numpy(dtype=float),
        data["control"].to_numpy(dtype=float),
        data["x"].to_numpy(dtype=float),
    ]
)
Z = np.column_stack(
    [
        np.ones(len(data)),
        data["period_indicator"].to_numpy(dtype=float),
        data["control"].to_numpy(dtype=float),
        data["z"].to_numpy(dtype=float),
    ]
)
weights = data["population"].to_numpy(dtype=float)
sqrt_w = np.sqrt(weights)

Z_w = Z * sqrt_w[:, None]
X_w = X * sqrt_w[:, None]
Y_w = Y * sqrt_w

projection_coef = np.linalg.lstsq(Z_w, X_w, rcond=None)[0]
X_hat_w = Z_w @ projection_coef
beta = np.linalg.lstsq(X_hat_w, Y_w, rcond=None)[0]

area0 = data.loc[data["area"] == 0].set_index("period")
period0, period1 = period_values[0], period_values[1]

estimates = [
    {"term": "iv_slope", "estimate": float(beta[3]), "se": None, "n_obs": 72},
    {
        "term": "exposure_area0_period0",
        "estimate": float(area0.loc[period0, "x"]),
        "se": None,
        "n_obs": 72,
    },
    {
        "term": "exposure_area0_period1",
        "estimate": float(area0.loc[period1, "x"]),
        "se": None,
        "n_obs": 72,
    },
    {
        "term": "instrument_area0_period0",
        "estimate": float(area0.loc[period0, "z"]),
        "se": None,
        "n_obs": 72,
    },
]

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "weighted two-stage least squares",
        "outcome": "change_pp",
        "regressors": ["intercept", "period", "control", "x"],
        "instruments": ["intercept", "period", "control", "z"],
        "weight": "base-vintage population",
        "exposure_units": "thousands of real dollars per worker per decade",
    },
    "diagnostics": {
        "n_obs": int(len(data)),
        "industries": int(len(industries)),
        "area_period_rows": int(len(data)),
    },
}

with open("result.json", "w", encoding="utf-8") as output_file:
    json.dump(result, output_file, indent=2, allow_nan=False)
