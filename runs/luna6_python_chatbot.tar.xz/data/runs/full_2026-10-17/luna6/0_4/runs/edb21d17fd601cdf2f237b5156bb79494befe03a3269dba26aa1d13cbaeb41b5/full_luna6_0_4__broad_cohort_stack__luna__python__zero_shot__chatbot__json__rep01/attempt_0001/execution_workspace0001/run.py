import json
import pandas as pd
from linearmodels.panel import PanelOLS

df = pd.read_csv("input.csv")

estimates = []
cohort_results = []

for cohort in (3, 5, 7):
    window = list(range(cohort - 2, cohort + 3))
    eligible = df[
        (df["g"] == cohort)
        | (df["g"] == 0)
        | (df["g"] > cohort + 2)
    ]
    sample = eligible[eligible["time"].isin(window)].copy()

    complete_units = (
        sample.groupby("id")["time"]
        .nunique()
        .loc[lambda counts: counts == len(window)]
        .index
    )
    sample = sample[sample["id"].isin(complete_units)].copy()
    sample["did"] = (
        (sample["g"] == cohort) & (sample["time"] >= cohort)
    ).astype(int)

    panel = sample.set_index(["id", "time"])
    model = PanelOLS(
        panel["y"],
        panel[["did"]],
        entity_effects=True,
        time_effects=True,
    )
    result = model.fit()

    coefficient = float(result.params["did"])
    treated_units = sample.loc[sample["g"] == cohort, "id"].nunique()
    row_count = len(sample)

    estimates.append({
        "term": f"att_g{cohort}",
        "estimate": coefficient,
        "se": None,
        "n_obs": row_count,
    })
    cohort_results.append((coefficient, treated_units, row_count))

weighted_estimate = sum(
    coefficient * treated_units
    for coefficient, treated_units, _ in cohort_results
) / sum(treated_units for _, treated_units, _ in cohort_results)

estimates.append({
    "term": "att_weighted",
    "estimate": float(weighted_estimate),
    "se": None,
    "n_obs": sum(row_count for _, _, row_count in cohort_results),
})

output = {
    "task_id": "broad_cohort_stack",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {},
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(output, file, indent=2)
