import json

import pandas as pd
from statsmodels.tsa.arima.model import ARIMA

data = pd.read_csv("./input.csv")
y = data["y"].astype(float)

model = ARIMA(
    y,
    order=(1, 1, 1),
    trend="n",
    enforce_stationarity=True,
    enforce_invertibility=True,
)
fit = model.fit()

prediction = fit.get_forecast(steps=1)
forecast = float(prediction.predicted_mean.iloc[0])
interval = prediction.conf_int(alpha=0.05)
lower_95 = float(interval.iloc[0, 0])
upper_95 = float(interval.iloc[0, 1])
n_obs = int(y.notna().sum())

result = {
    "task_id": "arima_forecast",
    "platform": "python",
    "estimates": [
        {"term": "forecast", "estimate": forecast, "se": None, "n_obs": n_obs},
        {"term": "lower_95", "estimate": lower_95, "se": None, "n_obs": n_obs},
        {"term": "upper_95", "estimate": upper_95, "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "ARIMA(1,1,1) maximum likelihood, no constant or drift",
        "vcov": "95% prediction interval from fitted state-space forecast",
    },
    "diagnostics": {},
}

with open("./result.json", "w", encoding="utf-8") as file:
    json.dump(result, file, indent=2)
