import json

import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df = df.loc[df["score"].abs() < 1].copy()
n_obs = int(len(df))

score = df["score"].to_numpy(dtype=float)
right = (score >= 0).astype(float)
weights = 1.0 - np.abs(score)

# Separate local-linear regressions with side-specific intercepts and slopes.
design = np.column_stack(
    [
        np.ones(n_obs),
        right,
        score * (1.0 - right),
        score * right,
    ]
)
sqrt_weights = np.sqrt(weights)
weighted_design = design * sqrt_weights[:, None]
bread = np.linalg.inv(weighted_design.T @ weighted_design)

def fit_rd_outcome(outcome):
    y = np.asarray(outcome, dtype=float)
    beta = bread @ (weighted_design.T @ (sqrt_weights * y))
    residuals = y - design @ beta
    # HC0 covariance for weighted least squares, with the fixed analytic weights.
    scores = design * (weights * residuals)[:, None]
    covariance = bread @ (scores.T @ scores) @ bread
    discontinuity = float(beta[1])
    variance = float(covariance[1, 1])
    return discontinuity, covariance, variance

reduced_form, cov_y, var_y = fit_rd_outcome(df["earnings"])
first_stage, cov_d, var_d = fit_rd_outcome(df["participated"])

# Joint HC0 covariance across outcomes, preserving cross-equation covariance.
y = df["earnings"].to_numpy(dtype=float)
d = df["participated"].to_numpy(dtype=float)
beta_y = bread @ (weighted_design.T @ (sqrt_weights * y))
beta_d = bread @ (weighted_design.T @ (sqrt_weights * d))
resid_y = y - design @ beta_y
resid_d = d - design @ beta_d
cross_scores = design * (weights * resid_y)[:, None]
cross_scores_d = design * (weights * resid_d)[:, None]
joint_cov = bread @ (cross_scores.T @ cross_scores_d) @ bread
cov_rf_fs = float(joint_cov[1, 1])

treatment_effect = reduced_form / first_stage
gradient_rf = 1.0 / first_stage
gradient_fs = -reduced_form / (first_stage ** 2)
variance_te = (
    gradient_rf ** 2 * var_y
    + gradient_fs ** 2 * var_d
    + 2.0 * gradient_rf * gradient_fs * cov_rf_fs
)
se_te = float(np.sqrt(max(variance_te, 0.0)))

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {
            "term": "treatment_effect",
            "estimate": float(treatment_effect),
            "se": se_te,
            "n_obs": n_obs,
        },
        {
            "term": "reduced_form",
            "estimate": float(reduced_form),
            "se": float(np.sqrt(max(var_y, 0.0))),
            "n_obs": n_obs,
        },
        {
            "term": "first_stage",
            "estimate": float(first_stage),
            "se": float(np.sqrt(max(var_d, 0.0))),
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "triangular-kernel fuzzy regression discontinuity, local linear",
        "vcov": "HC0 sandwich with joint cross-outcome covariance; fixed bandwidth and weights",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output_file:
    json.dump(result, output_file, indent=2, allow_nan=False)
