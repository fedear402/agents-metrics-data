import json

import numpy as np
import pandas as pd
from scipy.stats import f

data = pd.read_csv("input.csv")
y = data["y"].to_numpy(dtype=float)
endog = data["endog"].to_numpy(dtype=float)
controls = np.column_stack(
    [np.ones(len(data)), data["x"].to_numpy(dtype=float)]
)
excluded = data[["z1", "z2"]].to_numpy(dtype=float)
restricted = np.column_stack([controls, excluded])

n = len(data)
q = excluded.shape[1]
df = n - restricted.shape[1]
critical = f.ppf(0.95, q, df)


def residualize(values, design):
    return values - design @ np.linalg.lstsq(design, values, rcond=None)[0]


ry = residualize(y, controls)
rd = residualize(endog, controls)
uy = residualize(y, restricted)
ud = residualize(endog, restricted)

k = q * critical / df
A = rd @ rd - (1 + k) * (ud @ ud)
B = -2 * (ry @ rd - (1 + k) * (uy @ ud))
C = ry @ ry - (1 + k) * (uy @ uy)

discriminant = B * B - 4 * A * C
if abs(A) < 1e-12 or discriminant < 0:
    raise ValueError("The confidence-set boundary is degenerate.")

roots = np.sort(np.roots([A, B, C]).real)
boundary_low, boundary_high = roots
unbounded = int(A < 0)
accepts_zero = int(C <= 0)


def ar_f(beta):
    residual_restricted = residualize(y - beta * endog, controls)
    residual_unrestricted = residualize(y - beta * endog, restricted)
    ssr_r = residual_restricted @ residual_restricted
    ssr_u = residual_unrestricted @ residual_unrestricted
    return ((ssr_r - ssr_u) / q) / (ssr_u / df)


rows = [
    {"term": "boundary_low", "estimate": float(boundary_low), "se": None, "n_obs": n},
    {"term": "boundary_high", "estimate": float(boundary_high), "se": None, "n_obs": n},
    {"term": "accepts_zero", "estimate": accepts_zero, "se": None, "n_obs": n},
    {"term": "unbounded", "estimate": unbounded, "se": None, "n_obs": n},
    {"term": "ar_f_at_one", "estimate": float(ar_f(1.0)), "se": None, "n_obs": n},
]

with open("result.json", "w") as stream:
    json.dump(
        {
            "task_id": "broad_ar_confidence_set",
            "platform": "python",
            "estimates": rows,
            "method_metadata": {
                "estimator": "Anderson-Rubin confidence set by inversion of the homoskedastic joint F test for z1 and z2",
                "vcov": "conventional homoskedastic",
            },
            "diagnostics": {},
        },
        stream,
        indent=2,
        allow_nan=False,
    )
