import json

import numpy as np
import pandas as pd
from scipy.stats import f

data = pd.read_csv("input.csv")
n = len(data)

y = data["y"].to_numpy(dtype=float)
endog = data["endog"].to_numpy(dtype=float)
controls = np.column_stack(
    [np.ones(n), data["x"].to_numpy(dtype=float)]
)
excluded = np.column_stack(
    [data["z1"].to_numpy(dtype=float), data["z2"].to_numpy(dtype=float)]
)

restricted = controls
unrestricted = np.column_stack([controls, excluded])
q = 2
df = n - unrestricted.shape[1]
critical = f.ppf(0.95, q, df)
k = q * critical / df


def residual(values, design):
    return values - design @ np.linalg.lstsq(design, values, rcond=None)[0]


ry = residual(y, restricted)
rd = residual(endog, restricted)
uy = residual(y, unrestricted)
ud = residual(endog, unrestricted)

# The AR acceptance condition is A*beta^2 + B*beta + C <= 0.
A = rd @ rd - (1 + k) * (ud @ ud)
B = -2 * (ry @ rd - (1 + k) * (uy @ ud))
C = ry @ ry - (1 + k) * (uy @ uy)

discriminant = B * B - 4 * A * C
if abs(A) < 1e-12 or discriminant < 0:
    raise ValueError("The AR inequality does not have two finite boundaries.")

boundaries = np.sort(np.roots([A, B, C]).real)


def accepts(beta):
    return A * beta * beta + B * beta + C <= 0


def ar_f(beta):
    value = y - beta * endog
    residual_restricted = residual(value, restricted)
    residual_unrestricted = residual(value, unrestricted)
    ssr_restricted = residual_restricted @ residual_restricted
    ssr_unrestricted = residual_unrestricted @ residual_unrestricted
    return (
        (ssr_restricted - ssr_unrestricted) / q
    ) / (ssr_unrestricted / df)


rows = [
    {"term": "boundary_low", "estimate": float(boundaries[0]), "se": None, "n_obs": n},
    {"term": "boundary_high", "estimate": float(boundaries[1]), "se": None, "n_obs": n},
    {"term": "accepts_zero", "estimate": int(accepts(0.0)), "se": None, "n_obs": n},
    {"term": "unbounded", "estimate": int(A < 0), "se": None, "n_obs": n},
    {"term": "ar_f_at_one", "estimate": float(ar_f(1.0)), "se": None, "n_obs": n},
]

with open("result.json", "w") as stream:
    json.dump(
        {
            "task_id": "broad_ar_confidence_set",
            "platform": "python",
            "estimates": rows,
            "method_metadata": {
                "estimator": "Anderson-Rubin confidence set by inversion of the homoskedastic joint F test",
                "vcov": "conventional homoskedastic",
            },
            "diagnostics": {},
        },
        stream,
        indent=2,
        allow_nan=False,
    )
