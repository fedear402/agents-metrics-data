import json

import numpy as np
import pandas as pd
from scipy.stats import f

data = pd.read_csv("input.csv")
n = len(data)

# Frisch-Waugh-Lovell residualization of y and endog on the included
# regressors (intercept and x).
W = np.column_stack([np.ones(n), data["x"].to_numpy(dtype=float)])
y = data["y"].to_numpy(dtype=float)
endog = data["endog"].to_numpy(dtype=float)
z = data[["z1", "z2"]].to_numpy(dtype=float)

q, _ = np.linalg.qr(W, mode="reduced")
y_r = y - q @ (q.T @ y)
d_r = endog - q @ (q.T @ endog)
z_r = z - q @ (q.T @ z)

# Joint excluded-instrument F statistic at candidate beta:
# explained sum of squares from projecting (y - beta*endog) on residualized
# instruments, divided by 2, then divided by unrestricted residual variance.
gram_inv = np.linalg.inv(z_r.T @ z_r)
m = z_r.T @ y_r
v = z_r.T @ d_r
yy = float(y_r @ y_r)
dd = float(d_r @ d_r)
yd = float(y_r @ d_r)
df_num = 2
df_den = n - 4
critical = float(f.ppf(0.95, df_num, df_den))

# F(beta) <= critical is equivalent to a quadratic inequality:
# (n-4)*SSR_restricted(beta) - critical*2*SSR_unrestricted(beta) <= 0.
# The unrestricted residual sum of squares equals the residualized outcome
# sum of squares minus its projection on the two instruments.
a = yy - float(m.T @ gram_inv @ m)
b = yd - float(m.T @ gram_inv @ v)
c = dd - float(v.T @ gram_inv @ v)
qa = df_den * c - critical * df_num * c
qb = -2.0 * df_den * b + 2.0 * critical * df_num * b
qc = df_den * a - critical * df_num * a

roots = np.roots([qa, qb, qc])
real_roots = sorted(float(root.real) for root in roots if abs(root.imag) < 1e-8)
if len(real_roots) != 2:
    raise RuntimeError("Expected two finite real Anderson-Rubin boundaries.")

boundary_low, boundary_high = real_roots

def ar_f(beta):
    r = y_r - beta * d_r
    total_ss = float(r @ r)
    explained_ss = float((z_r.T @ r).T @ gram_inv @ (z_r.T @ r))
    unrestricted_ss = total_ss - explained_ss
    if unrestricted_ss <= 0:
        return float("inf")
    return (explained_ss / df_num) / (unrestricted_ss / df_den)

accepts_zero = int(ar_f(0.0) <= critical)
unbounded = int(qa < 0)

estimates = [
    ("boundary_low", boundary_low),
    ("boundary_high", boundary_high),
    ("accepts_zero", float(accepts_zero)),
    ("unbounded", float(unbounded)),
    ("ar_f_at_one", ar_f(1.0)),
]

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": [
        {"term": term, "estimate": float(value), "se": None, "n_obs": n}
        for term, value in estimates
    ],
    "method_metadata": {
        "estimator": "Anderson-Rubin confidence set by inversion of the homoskedastic joint F test for z1 and z2",
        "vcov": "conventional homoskedastic"
    },
    "diagnostics": {}
}

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output, indent=2)
