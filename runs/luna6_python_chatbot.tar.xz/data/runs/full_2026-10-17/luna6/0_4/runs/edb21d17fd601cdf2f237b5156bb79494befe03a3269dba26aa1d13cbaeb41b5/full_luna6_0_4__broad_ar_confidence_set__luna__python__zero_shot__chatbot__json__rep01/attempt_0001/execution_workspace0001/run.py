import json
import numpy as np
import pandas as pd
from scipy.stats import f

data = pd.read_csv("input.csv")
n = len(data)
if n != 240:
    raise ValueError(f"Expected 240 rows, found {n}")

y = data["y"].to_numpy(dtype=float)
endog = data["endog"].to_numpy(dtype=float)
x = data["x"].to_numpy(dtype=float)
z = data[["z1", "z2"]].to_numpy(dtype=float)

# By the Frisch-Waugh-Lovell theorem, residualize y, endog, and z1/z2
# against the included intercept and x. The joint instrument test then
# depends on the two-dimensional projection of y - beta*endog.
included = np.column_stack((np.ones(n), x))
residual_maker = np.eye(n) - included @ np.linalg.solve(included.T @ included, included.T)
yr = residual_maker @ y
dr = residual_maker @ endog
zr = residual_maker @ z

zz_inv = np.linalg.inv(zr.T @ zr)
projection = zr @ zz_inv @ zr.T
m = n - 4
critical = f.ppf(0.95, 2, m)

# For each beta, F(beta) = m/2 * q(beta)/(SSE(beta)), where
# q is the explained sum of squares from the excluded instruments.
# Invert F(beta) <= critical as a quadratic inequality.
a = float(yr @ projection @ yr)
b = float(yr @ projection @ dr)
c = float(dr @ projection @ dr)

s0 = float(yr @ yr)
s1 = float(yr @ dr)
s2 = float(dr @ dr)

scale = m / (2.0 * critical)
coef2 = scale * c - (dr @ dr)
coef1 = -2.0 * scale * b + 2.0 * s1
coef0 = scale * a - s0

roots = np.roots([coef2, coef1, coef0])
real_roots = sorted(float(r.real) for r in roots if abs(r.imag) < 1e-8)
if len(real_roots) != 2:
    raise ValueError(f"Expected two finite real boundary points, found {real_roots}")

boundary_low, boundary_high = real_roots

def ar_f(beta):
    response = yr - beta * dr
    fitted_ss = float(response @ projection @ response)
    residual_ss = float(response @ response - fitted_ss)
    return (fitted_ss / 2.0) / (residual_ss / m)

estimates = [
    {"term": "boundary_low", "estimate": boundary_low, "se": None, "n_obs": n},
    {"term": "boundary_high", "estimate": boundary_high, "se": None, "n_obs": n},
    {"term": "accepts_zero", "estimate": float(ar_f(0.0) <= critical), "se": None, "n_obs": n},
    {"term": "unbounded", "estimate": 0.0, "se": None, "n_obs": n},
    {"term": "ar_f_at_one", "estimate": float(ar_f(1.0)), "se": None, "n_obs": n},
]

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "Anderson-Rubin test inversion using the conventional homoskedastic joint F test",
        "vcov": "conventional homoskedastic"
    },
    "diagnostics": {}
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file, indent=2, allow_nan=False)
