import json
import numpy as np
import pandas as pd

data = pd.read_csv("./input.csv")
cohorts = [3, 5, 7]
results = []
treated_counts = []
row_counts = []

for cohort in cohorts:
    window = list(range(cohort - 2, cohort + 3))
    eligible = data[
        (data["g"] == cohort)
        | (data["g"] == 0)
        | (data["g"] > cohort + 2)
    ]
    balanced_ids = (
        eligible.groupby("id")["time"]
        .apply(lambda times: set(window).issubset(set(times)))
    )
    retained_ids = balanced_ids[balanced_ids].index
    sample = eligible[
        eligible["id"].isin(retained_ids) & eligible["time"].isin(window)
    ].copy()

    sample["did"] = (
        (sample["g"] == cohort) & (sample["time"] >= cohort)
    ).astype(float)

    unit_fe = pd.get_dummies(sample["id"], drop_first=True, dtype=float)
    time_fe = pd.get_dummies(sample["time"], drop_first=True, dtype=float)
    design = np.column_stack([
        np.ones(len(sample)),
        sample["did"].to_numpy(),
        unit_fe.to_numpy(),
        time_fe.to_numpy(),
    ])
    coefficient = np.linalg.lstsq(
        design, sample["y"].to_numpy(dtype=float), rcond=None
    )[0][1]

    results.append(float(coefficient))
    treated_counts.append(int(sample.loc[sample["g"] == cohort, "id"].nunique()))
    row_counts.append(int(len(sample)))

weighted = float(np.average(results, weights=treated_counts))

estimates = [
    {
        "term": f"att_g{cohort}",
        "estimate": estimate,
        "se": None,
        "n_obs": rows,
    }
    for cohort, estimate, rows in zip(cohorts, results, row_counts)
]
estimates.append({
    "term": "att_weighted",
    "estimate": weighted,
    "se": None,
    "n_obs": sum(row_counts),
})

output = {
    "task_id": "broad_cohort_stack",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {},
    "diagnostics": {},
}
with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
