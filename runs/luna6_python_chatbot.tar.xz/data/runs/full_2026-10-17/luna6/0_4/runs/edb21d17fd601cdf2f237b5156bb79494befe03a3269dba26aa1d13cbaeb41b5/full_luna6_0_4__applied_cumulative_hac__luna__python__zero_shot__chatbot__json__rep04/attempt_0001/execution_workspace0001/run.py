import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("input.csv", parse_dates=["date"])
df = df.sort_values("date").reset_index(drop=True)

df["delta_log_vix"] = np.log(df["vix"]).diff()
for lag in range(1, 16):
    df[f"lag_{lag}"] = df["delta_log_vix"].shift(lag)

reg = df.dropna(subset=["sales", *[f"lag_{lag}" for lag in range(1, 16)]]).copy()
y = np.log(reg["sales"].to_numpy())
lag_cols = [f"lag_{lag}" for lag in range(1, 16)]
X = sm.add_constant(reg[lag_cols].to_numpy())
fit = sm.OLS(y, X).fit()

n_obs = len(reg)
k = X.shape[1]
resid = fit.resid
scores = X * resid[:, None]

# Bartlett-weighted Newey-West covariance, with maximum lag 15.
meat = scores.T @ scores
for j in range(1, 16):
    weight = 1.0 - j / 16.0
    cross = scores[j:].T @ scores[:-j]
    meat += weight * (cross + cross.T)

bread = np.linalg.inv(X.T @ X)
cov = bread @ meat @ bread
cov *= n_obs / (n_obs - 16)

beta = fit.params
cum_weights = np.r_[0.0, np.ones(15)]
estimates = [
    {
        "term": "cumulative_response",
        "estimate": float(cum_weights @ beta),
        "se": float(np.sqrt(cum_weights @ cov @ cum_weights)),
        "n_obs": int(n_obs),
    },
    {
        "term": "lag_1",
        "estimate": float(beta[1]),
        "se": float(np.sqrt(cov[1, 1])),
        "n_obs": int(n_obs),
    },
    {
        "term": "lag_15",
        "estimate": float(beta[15]),
        "se": float(np.sqrt(cov[15, 15])),
        "n_obs": int(n_obs),
    },
]

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "OLS of log(sales) on an intercept and trading-observation lags 1 through 15 of first differences in log(vix)",
        "vcov": "Newey-West HAC with Bartlett weights, maximum lag 15, and N/(N-16) finite-sample multiplier",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, allow_nan=False)
