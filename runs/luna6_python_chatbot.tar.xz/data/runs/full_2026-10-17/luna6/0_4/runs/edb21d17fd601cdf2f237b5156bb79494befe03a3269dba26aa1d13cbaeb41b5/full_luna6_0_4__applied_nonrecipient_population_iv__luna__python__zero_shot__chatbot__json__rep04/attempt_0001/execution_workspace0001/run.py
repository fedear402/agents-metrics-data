import json
import numpy as np
import pandas as pd

households = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

# Retain every household that did not receive the transfer.
data = households.loc[households["recipient"] == 0].copy()
n_obs = int(len(data))

eligible = data["eligible"].to_numpy(dtype=float)
ineligible = 1.0 - eligible
dose = data["dose"].to_numpy(dtype=float)
instrument = data["instrument"].to_numpy(dtype=float)
baseline = data["baseline"].to_numpy(dtype=float)
weights = data["weight"].to_numpy(dtype=float)
outcome = data["outcome"].to_numpy(dtype=float)

# Two endogenous dose columns and four included exogenous columns.
endogenous = np.column_stack((dose * ineligible, dose * eligible))
exogenous = np.column_stack(
    (
        ineligible,
        eligible,
        baseline * ineligible,
        baseline * eligible,
    )
)
instruments = np.column_stack(
    (
        exogenous,
        instrument * ineligible,
        instrument * eligible,
    )
)

# Weighted 2SLS: project the full regressor matrix onto the instrument space.
regressors = np.column_stack((exogenous, endogenous))
sqrt_weights = np.sqrt(weights)
weighted_instruments = instruments * sqrt_weights[:, None]
weighted_regressors = regressors * sqrt_weights[:, None]
weighted_outcome = outcome * sqrt_weights

projection_coefficients = np.linalg.lstsq(
    weighted_instruments, weighted_regressors, rcond=None
)[0]
projected_regressors = weighted_instruments @ projection_coefficients

normal_matrix = weighted_regressors.T @ projected_regressors
rhs = projected_regressors.T @ weighted_outcome
coefficients = np.linalg.solve(normal_matrix, rhs)

# The two dose coefficients follow the four included exogenous coefficients.
ineligible_slope = float(coefficients[4])
eligible_slope = float(coefficients[5])

ineligible_mean_dose = float(
    np.average(dose[eligible == 0], weights=weights[eligible == 0])
)
eligible_mean_dose = float(
    np.average(dose[eligible == 1], weights=weights[eligible == 1])
)

ineligible_effect = ineligible_slope * ineligible_mean_dose
eligible_nonrecipient_effect = eligible_slope * eligible_mean_dose

# Census counts are used only for the final between-group aggregation.
population = census.set_index("eligible")["nonrecipient_population"]
ineligible_population = float(population.loc[0])
eligible_population = float(population.loc[1])
population_effect = (
    ineligible_population * ineligible_effect
    + eligible_population * eligible_nonrecipient_effect
) / (ineligible_population + eligible_population)

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "ineligible_effect",
            "estimate": float(ineligible_effect),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "eligible_nonrecipient_effect",
            "estimate": float(eligible_nonrecipient_effect),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "population_effect",
            "estimate": float(population_effect),
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "weighted_2sls",
        "sample": "all households with recipient equal to zero",
        "endogenous_columns": [
            "dose*(1-eligible)",
            "dose*eligible",
        ],
        "exogenous_columns": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
        ],
        "instrument_columns": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
            "instrument*(1-eligible)",
            "instrument*eligible",
        ],
        "regression_weight": "weight",
        "within_group_dose_average": "household-weighted using weight",
        "counterfactual": "dose set to zero for every retained household",
        "attribution_convention": "synthetic convention",
        "population_aggregation_weight": "nonrecipient_population from census.csv",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "n_ineligible_nonrecipients": int((eligible == 0).sum()),
        "n_eligible_nonrecipients": int((eligible == 1).sum()),
        "ineligible_weighted_mean_dose": ineligible_mean_dose,
        "eligible_weighted_mean_dose": eligible_mean_dose,
        "ineligible_dose_slope": ineligible_slope,
        "eligible_dose_slope": eligible_slope,
    },
}

with open("result.json", "w", encoding="utf-8") as result_file:
    json.dump(result, result_file, indent=2, allow_nan=False)
