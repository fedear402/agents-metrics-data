import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
sample = df.loc[df["score"].abs() < 1].copy()
score = sample["score"].to_numpy(dtype=float)
right = (score >= 0).astype(float)
weights = 1.0 - np.abs(score)

# Separate weighted local-linear regressions on either side of the cutoff.
design = np.column_stack(
    [
        np.ones(len(sample)),
        right,
        score * (1.0 - right),
        score * right,
    ]
)
bread = np.linalg.inv(design.T @ (weights[:, None] * design))
residual_maker = bread @ (design.T * weights)
outcomes = sample[["earnings", "participated"]].to_numpy(dtype=float)
coefficients = residual_maker @ outcomes
residuals = outcomes - design @ coefficients

# Joint HC0 covariance for all coefficients and both outcomes, allowing
# earnings and participation residuals to covary within each observation.
meat = np.zeros((design.shape[1] * 2, design.shape[1] * 2))
for i in range(len(sample)):
    xw = design[i] * weights[i]
    score_i = np.concatenate(
        [xw * residuals[i, 0], xw * residuals[i, 1]]
    )
    meat += np.outer(score_i, score_i)

joint_bread = np.kron(np.eye(2), bread)
joint_cov = joint_bread @ meat @ joint_bread.T

# Coefficient ordering is earnings coefficients, then participation coefficients.
jump = np.array([0.0, 1.0, 0.0, 0.0])
reduced_form = float(jump @ coefficients[:, 0])
first_stage = float(jump @ coefficients[:, 1])
cov_rf_fs = float(
    jump @ joint_cov[:4, 4:] @ jump
)
var_rf = float(jump @ joint_cov[:4, :4] @ jump)
var_fs = float(jump @ joint_cov[4:, 4:] @ jump)

treatment_effect = reduced_form / first_stage
gradient = np.array([1.0 / first_stage, -reduced_form / (first_stage**2)])
ratio_cov = np.array([[var_rf, cov_rf_fs], [cov_rf_fs, var_fs]])
ratio_var = float(gradient @ ratio_cov @ gradient)

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {
            "term": "treatment_effect",
            "estimate": treatment_effect,
            "se": float(np.sqrt(max(ratio_var, 0.0))),
            "n_obs": int(len(sample)),
        },
        {
            "term": "reduced_form",
            "estimate": reduced_form,
            "se": float(np.sqrt(max(var_rf, 0.0))),
            "n_obs": int(len(sample)),
        },
        {
            "term": "first_stage",
            "estimate": first_stage,
            "se": float(np.sqrt(max(var_fs, 0.0))),
            "n_obs": int(len(sample)),
        },
    ],
    "method_metadata": {
        "estimator": "Fuzzy RD with separate weighted local-linear fits and triangular weights",
        "vcov": "Joint heteroskedasticity-robust HC0 covariance; no degrees-of-freedom correction",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, allow_nan=False)
