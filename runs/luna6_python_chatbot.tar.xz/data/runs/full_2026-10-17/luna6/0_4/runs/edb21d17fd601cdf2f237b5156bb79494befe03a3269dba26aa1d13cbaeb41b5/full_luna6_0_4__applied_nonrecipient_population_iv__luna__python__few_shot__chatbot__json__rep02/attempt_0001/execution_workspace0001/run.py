import json

import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS

households = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

# Retain every nonrecipient household, including ineligible households in
# both village treatment statuses.
d = households.loc[households["recipient"] == 0].copy()
e = d["eligible"].astype(float)
ne = 1.0 - e

exog = pd.DataFrame(
    {
        "ineligible": ne,
        "eligible": e,
        "baseline_ineligible": d["baseline"] * ne,
        "baseline_eligible": d["baseline"] * e,
    },
    index=d.index,
)
endog = pd.DataFrame(
    {
        "dose_ineligible": d["dose"] * ne,
        "dose_eligible": d["dose"] * e,
    },
    index=d.index,
)
instruments = pd.DataFrame(
    {
        **exog.to_dict(orient="series"),
        "instrument_ineligible": d["instrument"] * ne,
        "instrument_eligible": d["instrument"] * e,
    },
    index=d.index,
)

fit = IV2SLS(
    dependent=d["outcome"],
    exog=exog,
    endog=endog,
    instruments=instruments,
    weights=d["weight"],
).fit()

ineligible_mean_dose = np.average(
    d.loc[d["eligible"] == 0, "dose"],
    weights=d.loc[d["eligible"] == 0, "weight"],
)
eligible_mean_dose = np.average(
    d.loc[d["eligible"] == 1, "dose"],
    weights=d.loc[d["eligible"] == 1, "weight"],
)

ineligible_effect = float(fit.params["dose_ineligible"] * ineligible_mean_dose)
eligible_nonrecipient_effect = float(
    fit.params["dose_eligible"] * eligible_mean_dose
)

population_weights = (
    census.set_index("eligible")["nonrecipient_population"]
    .reindex([0, 1])
    .to_numpy(dtype=float)
)
population_effect = float(
    np.average(
        [ineligible_effect, eligible_nonrecipient_effect],
        weights=population_weights,
    )
)

n_obs = int(len(d))
result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "ineligible_effect",
            "estimate": ineligible_effect,
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "eligible_nonrecipient_effect",
            "estimate": eligible_nonrecipient_effect,
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "population_effect",
            "estimate": population_effect,
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "weight_column": "weight",
        "counterfactual": "Set dose to zero for every retained nonrecipient household.",
        "attribution_convention": "Synthetic convention attributing the fitted dose effect to a zero-dose counterfactual.",
        "population_aggregation": "Census nonrecipient_population weights for eligible groups 0 and 1; used only for final aggregation.",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "n_ineligible_nonrecipients": int((d["eligible"] == 0).sum()),
        "n_eligible_nonrecipients": int((d["eligible"] == 1).sum()),
        "ineligible_dose_slope": float(fit.params["dose_ineligible"]),
        "eligible_dose_slope": float(fit.params["dose_eligible"]),
        "ineligible_weighted_mean_dose": float(ineligible_mean_dose),
        "eligible_weighted_mean_dose": float(eligible_mean_dose),
    },
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, allow_nan=False)
