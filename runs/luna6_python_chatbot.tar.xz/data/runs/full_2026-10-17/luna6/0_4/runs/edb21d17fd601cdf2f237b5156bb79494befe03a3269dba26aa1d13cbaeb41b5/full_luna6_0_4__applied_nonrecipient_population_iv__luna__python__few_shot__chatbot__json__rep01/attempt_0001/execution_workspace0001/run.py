import json
import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS

households = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

d = households.loc[households["recipient"] == 0].copy()
d["ineligible"] = 1 - d["eligible"]
d["dose_ineligible"] = d["dose"] * d["ineligible"]
d["dose_eligible"] = d["dose"] * d["eligible"]
d["baseline_ineligible"] = d["baseline"] * d["ineligible"]
d["baseline_eligible"] = d["baseline"] * d["eligible"]
d["instrument_ineligible"] = d["instrument"] * d["ineligible"]
d["instrument_eligible"] = d["instrument"] * d["eligible"]

exog = d[
    ["ineligible", "eligible", "baseline_ineligible", "baseline_eligible"]
]
endog = d[["dose_ineligible", "dose_eligible"]]
instruments = d[
    [
        "ineligible",
        "eligible",
        "baseline_ineligible",
        "baseline_eligible",
        "instrument_ineligible",
        "instrument_eligible",
    ]
]

fit = IV2SLS(
    dependent=d["outcome"],
    exog=exog,
    endog=endog,
    instruments=instruments,
    weights=d["weight"],
).fit()

n_obs = int(len(d))
slopes = {
    0: float(fit.params["dose_ineligible"]),
    1: float(fit.params["dose_eligible"]),
}
effects = {}
for eligible in (0, 1):
    group = d.loc[d["eligible"] == eligible]
    mean_dose = np.average(group["dose"], weights=group["weight"])
    effects[eligible] = slopes[eligible] * float(mean_dose)

population_weights = (
    census.set_index("eligible")["nonrecipient_population"]
)
population_effect = float(
    np.average(
        [effects[0], effects[1]],
        weights=[
            population_weights.loc[0],
            population_weights.loc[1],
        ],
    )
)

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "ineligible_effect",
            "estimate": effects[0],
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "eligible_nonrecipient_effect",
            "estimate": effects[1],
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "population_effect",
            "estimate": population_effect,
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "counterfactual": "synthetic convention: set dose to zero for every retained household",
        "retained_sample": "all household rows with recipient=0, including both village treatment statuses",
        "group_effect": "fitted group dose slope times that group's household-weighted mean dose",
        "population_aggregation": "census nonrecipient_population weights; census totals used only for final between-group aggregation",
        "regression_weight": "weight",
        "exogenous_columns": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
        ],
        "endogenous_columns": [
            "dose*(1-eligible)",
            "dose*eligible",
        ],
        "instrument_columns": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
            "instrument*(1-eligible)",
            "instrument*eligible",
        ],
        "additional_intercept": False,
    },
    "diagnostics": {
        "n_obs": n_obs,
        "n_obs_by_eligibility": {
            "ineligible": int((d["eligible"] == 0).sum()),
            "eligible": int((d["eligible"] == 1).sum()),
        },
        "standard_errors": None,
    },
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, allow_nan=False)
