import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
data = df.loc[df["score"].abs() < 1].copy()

score = data["score"].to_numpy(dtype=float)
right = (score >= 0).astype(float)
x = np.column_stack([np.ones(len(data)), right, score, right * score])
weights = 1 - np.abs(score)
sqrt_weights = np.sqrt(weights)
xw = x * sqrt_weights[:, None]

# The coefficient on right is the right-minus-left discontinuity at zero.
bread = np.linalg.inv(xw.T @ xw)
residuals = {}
estimates = {}
covariances = {}

for outcome in ("earnings", "participated"):
    y = data[outcome].to_numpy(dtype=float)
    beta = bread @ (xw.T @ (y * sqrt_weights))
    resid = y - x @ beta
    meat = x.T @ ((weights * resid**2)[:, None] * x)
    covariance = bread @ meat @ bread
    estimates[outcome] = float(beta[1])
    covariances[outcome] = covariance
    residuals[outcome] = resid

reduced_form = estimates["earnings"]
first_stage = estimates["participated"]
treatment_effect = reduced_form / first_stage

# HC0 covariance between the two fitted outcome discontinuities, using
# the same observations and weights.
earnings_resid = residuals["earnings"]
participation_resid = residuals["participated"]
meat_cross = x.T @ (
    (weights * earnings_resid * participation_resid)[:, None] * x
)
cov_cross = bread @ meat_cross @ bread
cov_rf_fs = float(cov_cross[1, 1])

se_reduced_form = float(np.sqrt(covariances["earnings"][1, 1]))
se_first_stage = float(np.sqrt(covariances["participated"][1, 1]))

gradient_rf = 1.0 / first_stage
gradient_fs = -reduced_form / (first_stage**2)
variance_treatment = (
    gradient_rf**2 * covariances["earnings"][1, 1]
    + gradient_fs**2 * covariances["participated"][1, 1]
    + 2 * gradient_rf * gradient_fs * cov_rf_fs
)
se_treatment = float(np.sqrt(max(variance_treatment, 0.0)))
n_obs = int(len(data))

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {
            "term": "treatment_effect",
            "estimate": treatment_effect,
            "se": se_treatment,
            "n_obs": n_obs,
        },
        {
            "term": "reduced_form",
            "estimate": reduced_form,
            "se": se_reduced_form,
            "n_obs": n_obs,
        },
        {
            "term": "first_stage",
            "estimate": first_stage,
            "se": se_first_stage,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "Fuzzy local-linear RD with cutoff 0, bandwidth 1, triangular weights, and separate side-specific slopes",
        "vcov": "HC0 sandwich covariance; fixed bandwidth and weights; delta method uses joint covariance",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, allow_nan=False)
