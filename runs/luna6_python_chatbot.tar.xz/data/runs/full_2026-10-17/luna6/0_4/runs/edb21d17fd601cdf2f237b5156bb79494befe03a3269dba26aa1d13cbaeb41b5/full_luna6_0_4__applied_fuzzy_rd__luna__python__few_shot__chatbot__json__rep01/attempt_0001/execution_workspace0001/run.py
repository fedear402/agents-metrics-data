import json
import pandas as pd
import numpy as np

df = pd.read_csv("input.csv")
sample = df.loc[df["score"].abs() < 1].copy()

score = sample["score"].to_numpy(dtype=float)
participated = sample["participated"].to_numpy(dtype=float)
earnings = sample["earnings"].to_numpy(dtype=float)
n_obs = len(sample)

# Separate local-linear regressions on each side, with triangular weights.
right = (score >= 0).astype(float)
left = 1.0 - right
weights = 1.0 - np.abs(score)

design = np.column_stack([
    left,
    left * score,
    right,
    right * score,
])
bread = np.linalg.inv(design.T @ (weights[:, None] * design))

outcomes = np.column_stack([earnings, participated])
coefficients = bread @ design.T @ (weights[:, None] * outcomes)
residuals = outcomes - design @ coefficients

# HC0 covariance for both outcomes, retaining their same-observation covariance.
weighted_design = design * weights[:, None]
influence = (bread @ weighted_design.T).T[:, [2, 0]] * residuals
joint_covariance = influence.T @ influence

reduced_form = float(coefficients[2, 0] - coefficients[0, 0])
first_stage = float(coefficients[2, 1] - coefficients[0, 1])
treatment_effect = reduced_form / first_stage

# Select the right-minus-left intercept contrast for each outcome.
contrast = np.array([-1.0, 0.0, 1.0, 0.0])
loading = weights[:, None] * (design @ bread @ contrast)
joint_covariance = (loading * residuals).T @ (loading * residuals)

gradient = np.array([1.0 / first_stage, -reduced_form / first_stage**2])
treatment_effect_se = float(np.sqrt(gradient @ joint_covariance @ gradient))

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {
            "term": "treatment_effect",
            "estimate": treatment_effect,
            "se": treatment_effect_se,
            "n_obs": n_obs,
        },
        {
            "term": "reduced_form",
            "estimate": reduced_form,
            "se": float(np.sqrt(joint_covariance[0, 0])),
            "n_obs": n_obs,
        },
        {
            "term": "first_stage",
            "estimate": first_stage,
            "se": float(np.sqrt(joint_covariance[1, 1])),
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "Triangular-weighted separate local-linear fuzzy regression discontinuity",
        "vcov": "HC0, joint covariance from common observations, no degrees-of-freedom correction",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
