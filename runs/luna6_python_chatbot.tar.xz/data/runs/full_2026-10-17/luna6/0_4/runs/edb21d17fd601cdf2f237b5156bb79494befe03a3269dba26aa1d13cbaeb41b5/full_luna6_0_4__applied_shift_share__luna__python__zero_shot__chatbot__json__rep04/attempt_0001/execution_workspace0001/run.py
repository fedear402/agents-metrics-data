import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("input.csv")

# Reduce the repeated regional variables and weights to one observation per region.
regions = df.groupby("region_id", sort=False).agg(
    region_weight=("region_weight", "first"),
    x=("x", "first"),
    y=("y", "first"),
)
e = regions["region_weight"].to_numpy(dtype=float)
e = e / e.sum()

# Construct regional shift-share exposure using all region-industry rows.
df["weighted_exposure"] = df["share"] * df["shock"]
z_by_region = df.groupby("region_id", sort=False)["weighted_exposure"].sum()
regions["z"] = z_by_region.reindex(regions.index).to_numpy(dtype=float)

# Center regional variables at their regional-weighted means.
for variable in ("y", "x", "z"):
    values = regions[variable].to_numpy(dtype=float)
    regions[variable + "0"] = values - np.dot(e, values)

# Aggregate centered regional residuals to industry-level observations.
industry = df[["industry_id", "shock", "region_id", "share"]].copy()
industry = industry.merge(
    regions[["y0", "x0", "z0"]].reset_index(),
    on="region_id",
    how="left",
    validate="many_to_one",
)
industry["weighted_share"] = (
    industry["share"] * industry["region_id"].map(pd.Series(e, index=regions.index))
)

grouped = industry.groupby("industry_id", sort=False)
s = grouped["weighted_share"].sum()
shock = grouped["shock"].first()
aggregates = {}
for variable in ("y0", "x0", "z0"):
    numerator = grouped.apply(
        lambda g: np.sum(g["weighted_share"].to_numpy() * g[variable].to_numpy())
    )
    aggregates[variable + "_bar"] = numerator / s

shock_data = pd.DataFrame(
    {
        "s": s,
        "shock": shock,
        **aggregates,
    }
).dropna()

N = len(shock_data)
weights = shock_data["s"].to_numpy(dtype=float)
shock_values = shock_data["shock"].to_numpy(dtype=float)

# With centered regional variables, the shock-level weighted IV includes
# an intercept and uses shock as the excluded instrument.
def shock_level_iv(outcome, endogenous):
    exog = sm.add_constant(shock_data[endogenous].to_numpy(dtype=float))
    instrument = sm.add_constant(shock_values)
    fit = sm.WLS(
        shock_data[outcome].to_numpy(dtype=float),
        exog,
        weights=weights,
    ).fit()
    # 2SLS point estimate and HC1 sandwich covariance, using analytic weights.
    xmat = exog
    zmat = instrument
    wmat = np.diag(weights)
    bread = np.linalg.inv(xmat.T @ wmat @ zmat @ np.linalg.inv(zmat.T @ wmat @ zmat) @ zmat.T @ wmat @ xmat)
    projection = xmat @ bread @ xmat.T @ wmat @ zmat @ np.linalg.inv(zmat.T @ wmat @ zmat) @ zmat.T @ wmat
    beta = bread @ xmat.T @ wmat @ zmat @ np.linalg.inv(zmat.T @ wmat @ zmat) @ zmat.T @ wmat @ shock_data[outcome].to_numpy(dtype=float)
    residual = shock_data[outcome].to_numpy(dtype=float) - xmat @ beta
    meat = xmat.T @ wmat @ zmat @ np.linalg.inv(zmat.T @ wmat @ zmat) @ zmat.T @ np.diag(residual**2) @ zmat @ np.linalg.inv(zmat.T @ wmat @ zmat) @ zmat.T @ wmat @ xmat
    cov = bread @ meat @ bread * (N / (N - 2))
    return float(beta[1]), float(np.sqrt(cov[1, 1]))

effect, effect_se = shock_level_iv("y0_bar", "x0_bar")

# First-stage coefficient is the shock-level IV regression of xbar on zbar,
# instrumenting zbar with the industry shock.
first_exog = sm.add_constant(shock_data["z0_bar"].to_numpy(dtype=float))
first_instrument = sm.add_constant(shock_values)
first_y = shock_data["x0_bar"].to_numpy(dtype=float)
first_w = np.diag(weights)
first_bread = np.linalg.inv(
    first_exog.T @ first_w @ first_instrument
    @ np.linalg.inv(first_instrument.T @ first_w @ first_instrument)
    @ first_instrument.T @ first_w @ first_exog
)
first_beta = (
    first_bread
    @ first_exog.T
    @ first_w
    @ first_instrument
    @ np.linalg.inv(first_instrument.T @ first_w @ first_instrument)
    @ first_instrument.T
    @ first_w
    @ first_y
)
first_resid = first_y - first_exog @ first_beta
first_meat = (
    first_exog.T
    @ first_w
    @ first_instrument
    @ np.linalg.inv(first_instrument.T @ first_w @ first_instrument)
    @ first_instrument.T
    @ np.diag(first_resid**2)
    @ first_instrument
    @ np.linalg.inv(first_instrument.T @ first_w @ first_instrument)
    @ first_instrument.T
    @ first_w
    @ first_exog
)
first_cov = first_bread @ first_meat @ first_bread * (N / (N - 2))
first_stage = float(first_beta[1])
first_stage_se = float(np.sqrt(first_cov[1, 1]))

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": effect, "se": effect_se, "n_obs": int(N)},
        {
            "term": "first_stage",
            "estimate": first_stage,
            "se": first_stage_se,
            "n_obs": int(N),
        },
        {
            "term": "effective_shocks",
            "estimate": float(1.0 / np.sum((weights / weights.sum()) ** 2)),
            "se": None,
            "n_obs": int(N),
        },
    ],
    "method_metadata": {
        "estimator": "Borusyak-Hull-Jaravel shock-level weighted 2SLS",
        "vcov": "shock-level heteroskedastic-robust HC1, analytic weights, no clustering",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, allow_nan=False)
