import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("input.csv")

# Reduce to one row per region for regional variables and weights.
regions = df[["region_id", "region_weight", "x", "y"]].drop_duplicates("region_id").copy()
regions["e"] = regions["region_weight"] / regions["region_weight"].sum()

# Build the regional shift-share instrument from all region-industry rows.
df["share_shock"] = df["share"] * df["shock"]
z = df.groupby("region_id", sort=False)["share_shock"].sum().rename("z")
regions = regions.merge(z, on="region_id", how="inner", validate="one_to_one")

# Center each regional variable using normalized regional weights.
for variable in ("y", "x", "z"):
    regions[f"{variable}0"] = regions[variable] - np.sum(
        regions["e"] * regions[variable]
    )

# Industry shock-level exposure weights and aggregated residual variables.
df = df.merge(
    regions[["region_id", "e", "y0", "x0", "z0"]],
    on="region_id",
    how="inner",
    validate="many_to_one",
)
df["weighted_share"] = df["e"] * df["share"]
industry = (
    df.groupby("industry_id", sort=False)
    .apply(
        lambda g: pd.Series(
            {
                "s": g["weighted_share"].sum(),
                "shock": g["shock"].iloc[0],
                "ybar_num": np.sum(g["weighted_share"] * g["y0"]),
                "xbar_num": np.sum(g["weighted_share"] * g["x0"]),
                "zbar_num": np.sum(g["weighted_share"] * g["z0"]),
            }
        ),
        include_groups=False,
    )
    .reset_index()
)

industry["ybar"] = industry["ybar_num"] / industry["s"]
industry["xbar"] = industry["xbar_num"] / industry["s"]
industry["zbar"] = industry["zbar_num"] / industry["s"]

n_industries = len(industry)
weights = industry["s"].to_numpy()
shock = industry["shock"].to_numpy()
ybar = industry["ybar"].to_numpy()
xbar = industry["xbar"].to_numpy()
zbar = industry["zbar"].to_numpy()

# Shock-level IV with an intercept and analytic exposure weights.
def iv_slope_and_hc1(y, endogenous, instrument):
    exog = sm.add_constant(endogenous, has_constant="add")
    inst = sm.add_constant(instrument, has_constant="add")
    fit = sm.WLS(y, exog, weights=weights).fit()
    # 2SLS coefficient and structural residual.
    projected_exog = sm.WLS(inst, exog, weights=weights).fit().fittedvalues
    # Use the instrument matrix to form the weighted 2SLS estimator.
    w = weights
    xmat = exog
    zmat = inst
    bread = np.linalg.inv(xmat.T @ (w[:, None] * zmat) @ np.linalg.inv(zmat.T @ (w[:, None] * zmat)) @ zmat.T @ (w[:, None] * xmat))
    beta = bread @ (xmat.T @ (w[:, None] * zmat) @ np.linalg.inv(zmat.T @ (w[:, None] * zmat)) @ zmat.T @ (w * y))
    resid = y - xmat @ beta

    # HC1 sandwich for analytic weights, using structural IV residuals.
    middle = zmat.T @ ((w**2 * resid**2)[:, None] * zmat)
    a = xmat.T @ (w[:, None] * zmat)
    qinv = np.linalg.inv(zmat.T @ (w[:, None] * zmat))
    cov = bread @ (a @ qinv @ middle @ qinv @ a.T) @ bread
    cov *= n_industries / (n_industries - 2)
    return float(beta[1]), float(np.sqrt(cov[1, 1]))

effect, effect_se = iv_slope_and_hc1(ybar, xbar, shock)
first_stage, first_stage_se = iv_slope_and_hc1(xbar, zbar, shock)
effective_shocks = float(1.0 / np.sum(weights**2))

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {
            "term": "effect",
            "estimate": effect,
            "se": effect_se,
            "n_obs": n_industries,
        },
        {
            "term": "first_stage",
            "estimate": first_stage,
            "se": first_stage_se,
            "n_obs": n_industries,
        },
        {
            "term": "effective_shocks",
            "estimate": effective_shocks,
            "se": None,
            "n_obs": n_industries,
        },
    ],
    "method_metadata": {
        "estimator": "Shock-level weighted 2SLS with industry shocks as instruments",
        "vcov": "HC1 heteroskedasticity-robust, analytic weights, structural IV residuals, multiplier N/(N-2)",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, allow_nan=False)
