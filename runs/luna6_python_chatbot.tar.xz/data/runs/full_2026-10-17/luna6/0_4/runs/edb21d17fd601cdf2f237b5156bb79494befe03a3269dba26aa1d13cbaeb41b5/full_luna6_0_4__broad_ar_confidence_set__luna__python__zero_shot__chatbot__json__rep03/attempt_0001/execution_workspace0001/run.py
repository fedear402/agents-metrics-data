import json

import numpy as np
import pandas as pd
from scipy.stats import f
import statsmodels.api as sm

data = pd.read_csv("input.csv")
n = len(data)

y = data["y"].to_numpy(dtype=float)
endog = data["endog"].to_numpy(dtype=float)
x = data["x"].to_numpy(dtype=float)
z = data[["z1", "z2"]].to_numpy(dtype=float)

# The unrestricted regression includes intercept, x, and both instruments.
base = sm.add_constant(np.column_stack([x, z]), has_constant="add")
critical = f.ppf(0.95, 2, n - 4)

def ar_f(beta):
    outcome = y - beta * endog
    fit = sm.OLS(outcome, base).fit()
    return float(fit.f_test("x1 = 0, x2 = 0").fvalue)

# F(beta) is a quadratic divided by a positive quadratic residual scale.
# Obtain the two roots of F(beta) - critical = 0 from evaluations at 0, 1, -1.
f0 = ar_f(0.0)
fp = ar_f(1.0)
fm = ar_f(-1.0)
# The OLS numerator sum of squares for the excluded instruments is quadratic.
# Recover its coefficients from the F values, since the denominator uses the
# same residual degrees of freedom and the restricted residual sum of squares.
# Compute the joint-test numerator directly by Frisch-Waugh-Lovell residualization.
controls = sm.add_constant(x, has_constant="add")
resid_y = sm.OLS(y, controls).fit().resid
resid_d = sm.OLS(endog, controls).fit().resid
resid_z = sm.OLS(z, controls).fit().resid
qmat = resid_z.T @ resid_z
coef_y = np.linalg.solve(qmat, resid_z.T @ resid_y)
coef_d = np.linalg.solve(qmat, resid_z.T @ resid_d)

# Restricted residuals after projecting on controls and instruments.
full_y_resid = sm.OLS(y, base).fit().resid
full_d_resid = sm.OLS(endog, base).fit().resid
# Residual sum of squares for y - beta*endog is quadratic in beta.
rss_a = float(full_d_resid @ full_d_resid)
rss_b = float(-2.0 * (full_y_resid @ full_d_resid))
rss_c = float(full_y_resid @ full_y_resid)

# Explained sum of squares attributable to the two excluded instruments.
num_a = float(coef_d @ qmat @ coef_d)
num_b = float(-2.0 * (coef_y @ qmat @ coef_d))
num_c = float(coef_y @ qmat @ coef_y)

# F = (numerator / 2) / (RSS / (n - 4)).
poly = np.array([
    num_a - critical * 2.0 * rss_a / (n - 4),
    num_b - critical * 2.0 * rss_b / (n - 4),
    num_c - critical * 2.0 * rss_c / (n - 4),
], dtype=float)
roots = np.roots(poly)
real_roots = np.sort(roots.real[np.isclose(roots.imag, 0.0, atol=1e-9)])
boundary_low, boundary_high = map(float, real_roots)

accepts_zero = int(ar_f(0.0) <= critical)
unbounded = int(poly[0] <= 0.0)
estimates = [
    {"term": "boundary_low", "estimate": boundary_low, "se": None, "n_obs": n},
    {"term": "boundary_high", "estimate": boundary_high, "se": None, "n_obs": n},
    {"term": "accepts_zero", "estimate": float(accepts_zero), "se": None, "n_obs": n},
    {"term": "unbounded", "estimate": float(unbounded), "se": None, "n_obs": n},
    {"term": "ar_f_at_one", "estimate": fp, "se": None, "n_obs": n},
]

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "Anderson-Rubin test inversion using homoskedastic joint F test",
        "vcov": "conventional homoskedastic"
    },
    "diagnostics": {}
}

with open("result.json", "w", encoding="utf-8") as outfile:
    json.dump(result, outfile, indent=2, allow_nan=False)
