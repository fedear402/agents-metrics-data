import json
import pandas as pd
from scipy.linalg import lstsq

df = pd.read_csv("./input.csv")
estimates = []
weighted_sum = 0.0
treated_weights = 0

for cohort in (3, 5, 7):
    window = list(range(cohort - 2, cohort + 3))
    eligible = df[
        (df["g"] == cohort)
        | (df["g"] == 0)
        | (df["g"] > cohort + 2)
    ]
    sample = eligible[eligible["time"].isin(window)].copy()

    balanced_ids = (
        sample.groupby("id")["time"]
        .nunique()
        .loc[lambda counts: counts == 5]
        .index
    )
    sample = sample[sample["id"].isin(balanced_ids)].copy()

    sample["did"] = (
        (sample["g"] == cohort) & (sample["time"] >= cohort)
    ).astype(float)

    design = pd.concat(
        [
            sample[["did"]].reset_index(drop=True),
            pd.get_dummies(sample["id"], drop_first=True, dtype=float).reset_index(drop=True),
            pd.get_dummies(sample["time"], drop_first=True, dtype=float).reset_index(drop=True),
        ],
        axis=1,
    )
    coef = lstsq(
        design.to_numpy(dtype=float),
        sample["y"].to_numpy(dtype=float),
        cond=None,
        lapack_driver="gelsy",
    )[0][0]

    treated_count = sample.loc[sample["g"] == cohort, "id"].nunique()
    weighted_sum += coef * treated_count
    treated_weights += treated_count

    estimates.append(
        {
            "term": f"att_g{cohort}",
            "estimate": float(coef),
            "se": None,
            "n_obs": int(len(sample)),
        }
    )

estimates.append(
    {
        "term": "att_weighted",
        "estimate": float(weighted_sum / treated_weights),
        "se": None,
        "n_obs": int(sum(row["n_obs"] for row in estimates)),
    }
)

result = {
    "task_id": "broad_cohort_stack",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {},
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file, indent=2)
