import json

import numpy as np
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("input.csv")
df["date"] = pd.to_datetime(df["date"])
df = df.sort_values("date").reset_index(drop=True)

df["dlog_vix"] = np.log(df["vix"]).diff()
for lag in range(1, 16):
    df[f"lag_{lag}"] = df["dlog_vix"].shift(lag)

df["log_sales"] = np.log(df["sales"])
lag_names = [f"lag_{lag}" for lag in range(1, 16)]
sample = df.dropna(subset=["log_sales", *lag_names])

y = sample["log_sales"]
X = sm.add_constant(sample[lag_names])
fit = sm.OLS(y, X).fit()

n_obs = len(sample)
cov = np.asarray(
    sm.stats.sandwich_covariance.cov_hac(
        fit, nlags=15, weights_func=lambda max_lag: 1 - np.arange(max_lag + 1) / 16
    )
)
cov *= n_obs / (n_obs - 16)

params = fit.params
lag_indices = [list(fit.params.index).index(name) for name in lag_names]
cumulative_estimate = float(params[lag_names].sum())
cumulative_variance = float(cov[np.ix_(lag_indices, lag_indices)].sum())
cumulative_se = float(np.sqrt(max(cumulative_variance, 0.0)))

estimates = [
    {
        "term": "cumulative_response",
        "estimate": cumulative_estimate,
        "se": cumulative_se,
        "n_obs": n_obs,
    },
    {
        "term": "lag_1",
        "estimate": float(params["lag_1"]),
        "se": float(np.sqrt(max(cov[list(fit.params.index).index("lag_1"), list(fit.params.index).index("lag_1")], 0.0))),
        "n_obs": n_obs,
    },
    {
        "term": "lag_15",
        "estimate": float(params["lag_15"]),
        "se": float(np.sqrt(max(cov[list(fit.params.index).index("lag_15"), list(fit.params.index).index("lag_15")], 0.0))),
        "n_obs": n_obs,
    },
]

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "OLS of log(sales) on an intercept and lags 1 through 15 of first differences in log(vix)",
        "vcov": "Newey-West HAC, maximum lag 15, Bartlett weights 1-j/16, multiplied by N/(N-16)",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2)
