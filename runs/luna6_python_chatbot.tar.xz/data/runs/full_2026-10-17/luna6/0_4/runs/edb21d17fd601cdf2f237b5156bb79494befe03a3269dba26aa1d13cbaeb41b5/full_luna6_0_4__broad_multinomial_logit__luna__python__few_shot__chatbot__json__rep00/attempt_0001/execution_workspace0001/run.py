import json

import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy.special import softmax

data = pd.read_csv("input.csv")
y = data["y"].astype(int)
outcomes = [0, 1, 2]
if sorted(y.unique().tolist()) != outcomes:
    raise ValueError("y must contain outcomes 0, 1, and 2")

X = sm.add_constant(data[["x", "z"]], has_constant="add")
fit = sm.MNLogit(y, X).fit(method="newton", disp=False, tol=1e-12, maxiter=200)

# Statsmodels parameter columns enumerate nonbase outcomes in sorted order.
nonbase = outcomes[1:]
params = fit.params.copy()
ses = fit.bse.copy()
params.columns = nonbase
ses.columns = nonbase

prob_cat2_zero = float(
    softmax(np.array([0.0, params.loc["const", 1], params.loc["const", 2]]))[2]
)
n_obs = int(len(data))

estimates = [
    {"term": "x_cat1", "estimate": float(params.loc["x", 1]), "se": float(ses.loc["x", 1]), "n_obs": n_obs},
    {"term": "z_cat1", "estimate": float(params.loc["z", 1]), "se": float(ses.loc["z", 1]), "n_obs": n_obs},
    {"term": "x_cat2", "estimate": float(params.loc["x", 2]), "se": float(ses.loc["x", 2]), "n_obs": n_obs},
    {"term": "z_cat2", "estimate": float(params.loc["z", 2]), "se": float(ses.loc["z", 2]), "n_obs": n_obs},
    {"term": "prob_cat2_zero", "estimate": prob_cat2_zero, "se": None, "n_obs": n_obs},
]

result = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "multinomial logit maximum likelihood",
        "vcov": "conventional observed-information covariance",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
