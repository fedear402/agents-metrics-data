import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy.stats import f

df = pd.read_csv("input.csv")
y = df["y"].to_numpy(dtype=float)
endog = df["endog"].to_numpy(dtype=float)
x = df["x"].to_numpy(dtype=float)
z1 = df["z1"].to_numpy(dtype=float)
z2 = df["z2"].to_numpy(dtype=float)

n = len(df)
critical = f.ppf(0.95, 2, n - 4)

# Regress each transformed outcome on the same full-rank design.
design = sm.add_constant(pd.DataFrame({"x": x, "z1": z1, "z2": z2}))
fit_y = sm.OLS(y, design).fit()
fit_endog = sm.OLS(endog, design).fit()

# The joint instrument test is a quadratic function of beta:
# (b_y - beta*b_endog)' Cov(b_y - beta*b_endog)^(-1)
# (b_y - beta*b_endog) / (2 * MSE(beta)).
# Build the residualized instrument space to evaluate this function.
X = design.to_numpy()
q, _ = np.linalg.qr(X, mode="reduced")
resid_y = y - q @ (q.T @ y)
resid_endog = endog - q @ (q.T @ endog)
# Fit on the restricted design (intercept and x) to obtain the partial
# instrument coefficients and their joint covariance.
restricted = sm.add_constant(pd.DataFrame({"x": x})).to_numpy()
full = X
# Use the conventional nested-model F statistic directly. It equals the
# joint F test for z1 and z2 in the unrestricted regression.
def ar_f(beta):
    outcome = y - beta * endog
    unrestricted = sm.OLS(outcome, full).fit()
    restricted_fit = sm.OLS(outcome, restricted).fit()
    ssr_restricted = float(restricted_fit.ssr)
    ssr_unrestricted = float(unrestricted.ssr)
    return ((ssr_restricted - ssr_unrestricted) / 2.0) / (
        ssr_unrestricted / (n - 4)
    )

# The inequality F(beta) <= critical is equivalent to a quadratic
# inequality. Recover its coefficients from three evaluations, then solve
# exactly for the real-line boundaries.
f0 = ar_f(0.0)
fp = ar_f(1.0)
fm = ar_f(-1.0)
# Cross-multiply by the unrestricted residual sum of squares, which is
# quadratic in beta. Evaluate the equivalent numerator polynomial:
def g(beta):
    outcome = y - beta * endog
    u = sm.OLS(outcome, full).fit()
    r = sm.OLS(outcome, restricted).fit()
    return (float(r.ssr - u.ssr) * (n - 4) / 2.0) - critical * float(u.ssr)

g0, gp, gm = g(0.0), g(1.0), g(-1.0)
a = (gp + gm - 2.0 * g0) / 2.0
b = (gp - gm) / 2.0
c = g0
roots = np.roots([a, b, c])
real_roots = sorted(float(r.real) for r in roots if abs(r.imag) < 1e-8)
if len(real_roots) != 2:
    raise RuntimeError("Expected two finite Anderson-Rubin boundaries.")

boundary_low, boundary_high = real_roots
accepts_zero = int(ar_f(0.0) <= critical)
unbounded = int(a <= 0.0)

estimates = [
    {"term": "boundary_low", "estimate": boundary_low, "se": None, "n_obs": n},
    {"term": "boundary_high", "estimate": boundary_high, "se": None, "n_obs": n},
    {"term": "accepts_zero", "estimate": float(accepts_zero), "se": None, "n_obs": n},
    {"term": "unbounded", "estimate": float(unbounded), "se": None, "n_obs": n},
    {"term": "ar_f_at_one", "estimate": float(fp), "se": None, "n_obs": n},
]

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "Anderson-Rubin inversion using conventional homoskedastic joint F test",
        "vcov": "conventional homoskedastic OLS covariance",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as f_out:
    json.dump(result, f_out, indent=2, allow_nan=False)
