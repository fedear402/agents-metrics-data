import json
import pandas as pd
from linearmodels.panel import PanelOLS

df = pd.read_csv("./input.csv")

cohorts = [3, 5, 7]
estimates = []
weighted_sum = 0.0
treated_weights = 0

for cohort in cohorts:
    window = list(range(cohort - 2, cohort + 3))
    eligible = df[
        (df["g"] == cohort)
        | (df["g"] == 0)
        | (df["g"] > cohort + 2)
    ]
    eligible = eligible[eligible["time"].isin(window)]

    complete_ids = (
        eligible.groupby("id")["time"]
        .nunique()
        .loc[lambda counts: counts == 5]
        .index
    )
    sample = eligible[eligible["id"].isin(complete_ids)].copy()
    sample["did"] = (
        (sample["g"] == cohort) & (sample["time"] >= cohort)
    ).astype(int)

    panel = sample.set_index(["id", "time"])
    model = PanelOLS(
        panel["y"],
        panel[["did"]],
        entity_effects=True,
        time_effects=True,
    )
    result = model.fit()

    term = f"att_g{cohort}"
    coefficient = float(result.params["did"])
    treated_units = sample.loc[sample["g"] == cohort, "id"].nunique()

    estimates.append(
        {
            "term": term,
            "estimate": coefficient,
            "se": None,
            "n_obs": int(len(sample)),
        }
    )
    weighted_sum += coefficient * treated_units
    treated_weights += treated_units

estimates.append(
    {
        "term": "att_weighted",
        "estimate": weighted_sum / treated_weights,
        "se": None,
        "n_obs": sum(row["n_obs"] for row in estimates),
    }
)

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(
        {
            "task_id": "broad_cohort_stack",
            "platform": "python",
            "estimates": estimates,
            "method_metadata": {},
            "diagnostics": {},
        },
        output,
        indent=2,
    )
