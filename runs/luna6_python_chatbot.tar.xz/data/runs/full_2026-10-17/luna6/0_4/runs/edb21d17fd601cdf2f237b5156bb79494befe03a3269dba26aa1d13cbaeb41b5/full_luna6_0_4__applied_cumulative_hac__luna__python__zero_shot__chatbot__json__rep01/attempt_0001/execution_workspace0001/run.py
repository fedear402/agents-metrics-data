import json
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("input.csv", parse_dates=["date"])
df = df.sort_values("date").reset_index(drop=True)

df["dlog_vix"] = df["vix"].apply(__import__("math").log).diff()
for lag in range(1, 16):
    df[f"lag_{lag}"] = df["dlog_vix"].shift(lag)

df["log_sales"] = df["sales"].apply(__import__("math").log)
regressors = [f"lag_{lag}" for lag in range(1, 16)]
sample = df.dropna(subset=["log_sales"] + regressors)

y = sample["log_sales"]
X = sm.add_constant(sample[regressors])
fit = sm.OLS(y, X).fit()

n_obs = len(sample)
hac_cov = sm.stats.sandwich_covariance.cov_hac(
    fit, nlags=15, weights_func=sm.stats.sandwich_covariance.weights_bartlett
)
hac_cov *= n_obs / (n_obs - 16)

params = fit.params
terms = regressors
cumulative_estimate = float(params[terms].sum())
cumulative_weights = pd.Series(0.0, index=params.index)
cumulative_weights[terms] = 1.0
cumulative_se = float(
    (cumulative_weights.to_numpy() @ hac_cov @ cumulative_weights.to_numpy()) ** 0.5
)

estimates = [
    {
        "term": "cumulative_response",
        "estimate": cumulative_estimate,
        "se": cumulative_se,
        "n_obs": n_obs,
    },
    {
        "term": "lag_1",
        "estimate": float(params["lag_1"]),
        "se": float(hac_cov[X.columns.get_loc("lag_1"), X.columns.get_loc("lag_1")] ** 0.5),
        "n_obs": n_obs,
    },
    {
        "term": "lag_15",
        "estimate": float(params["lag_15"]),
        "se": float(hac_cov[X.columns.get_loc("lag_15"), X.columns.get_loc("lag_15")] ** 0.5),
        "n_obs": n_obs,
    },
]

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "OLS of log(sales) on an intercept and lags 1 through 15 of first differences in log(vix)",
        "vcov": "Newey-West HAC with Bartlett weights through lag 15, multiplied by N/(N-16)",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, allow_nan=False)
