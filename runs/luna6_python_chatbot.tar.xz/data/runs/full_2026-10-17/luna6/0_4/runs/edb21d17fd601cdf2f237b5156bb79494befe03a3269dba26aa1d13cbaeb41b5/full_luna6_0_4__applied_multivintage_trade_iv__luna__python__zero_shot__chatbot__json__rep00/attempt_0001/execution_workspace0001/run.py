import json
import numpy as np
import pandas as pd

crosswalk = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv")
areas = pd.read_csv("areas.csv")
employment = pd.read_csv("employment.csv")
outcomes = pd.read_csv("outcomes.csv")

trade = trade.merge(crosswalk[["code", "industry"]], on="code", how="inner", validate="many_to_one")

# Fill omitted area-industry cells with zero over the industries present in the crosswalk.
industries = crosswalk["industry"].drop_duplicates().tolist()
employment = employment.set_index(["area", "period", "vintage", "industry"])["employment"]
area_keys = areas[["area", "period", "vintage"]].drop_duplicates()
full_index = pd.MultiIndex.from_product(
    [
        area_keys["area"].unique(),
        area_keys["period"].unique(),
        ["base", "early"],
        industries,
    ],
    names=["area", "period", "vintage", "industry"],
)
employment = employment.reindex(full_index, fill_value=0).rename("employment").reset_index()

# National denominators sum employment across every supplied area, by period and vintage.
national = employment.groupby(["period", "vintage", "industry"], as_index=False)["employment"].sum()
area_employment = employment.merge(
    areas[["area", "period", "vintage", "total_employment"]],
    on=["area", "period", "vintage"],
    how="inner",
    validate="many_to_one",
)
area_employment = area_employment.merge(
    national, on=["period", "vintage", "industry"], how="left", suffixes=("", "_national"),
    validate="many_to_one",
)
area_employment["share"] = area_employment["employment"] / area_employment["total_employment"]

trade["trade_factor_x"] = (
    trade["us_change"] / trade["price_index"] * 100.0 / trade["years"] * 10.0 / 1000.0
)
trade["trade_factor_z"] = (
    trade["other_change"] / trade["price_index"] * 100.0 / trade["years"] * 10.0 / 1000.0
)

base = area_employment[area_employment["vintage"] == "base"].merge(
    trade[["period", "industry", "trade_factor_x"]],
    on=["period", "industry"],
    how="inner",
    validate="many_to_one",
)
base["x_component"] = (
    base["share"] * base["trade_factor_x"] / base["employment_national"]
)
x = base.groupby(["area", "period"], as_index=False)["x_component"].sum().rename(
    columns={"x_component": "x"}
)

early = area_employment[area_employment["vintage"] == "early"].merge(
    trade[["period", "industry", "trade_factor_z"]],
    on=["period", "industry"],
    how="inner",
    validate="many_to_one",
)
early["z_component"] = (
    early["share"] * early["trade_factor_z"] / early["employment_national"]
)
z = early.groupby(["area", "period"], as_index=False)["z_component"].sum().rename(
    columns={"z_component": "z"}
)

reg = (
    outcomes.merge(x, on=["area", "period"], how="inner", validate="one_to_one")
    .merge(z, on=["area", "period"], how="inner", validate="one_to_one")
    .merge(
        areas[(areas["vintage"] == "base")][["area", "period", "population"]],
        on=["area", "period"],
        how="inner",
        validate="one_to_one",
    )
)
reg["period_indicator"] = (reg["period"] == sorted(reg["period"].unique())[1]).astype(float)

# Weighted 2SLS: project x on all exogenous regressors and z, then regress y
# on the exogenous regressors and the projected x, using population weights.
y = reg["change_pp"].to_numpy(dtype=float)
x_endog = reg["x"].to_numpy(dtype=float)
w = reg["population"].to_numpy(dtype=float)
exog = np.column_stack(
    [
        np.ones(len(reg)),
        reg["period_indicator"].to_numpy(dtype=float),
        reg["control"].to_numpy(dtype=float),
    ]
)
instruments = np.column_stack([exog, reg["z"].to_numpy(dtype=float)])
sqrt_w = np.sqrt(w)
zw = instruments * sqrt_w[:, None]
xw = np.column_stack([exog, x_endog]) * sqrt_w[:, None]
yw = y * sqrt_w

# Weighted projection onto the full instrument matrix.
projected = zw @ np.linalg.lstsq(zw, xw, rcond=None)[0]
beta = np.linalg.lstsq(projected, yw, rcond=None)[0]
iv_slope = float(beta[-1])

area0 = reg[reg["area"] == 0].set_index("period")
periods = sorted(reg["period"].unique())
exposure_area0_period0 = float(area0.loc[periods[0], "x"])
exposure_area0_period1 = float(area0.loc[periods[1], "x"])
instrument_area0_period0 = float(area0.loc[periods[0], "z"])

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [
        {"term": "iv_slope", "estimate": iv_slope, "se": None, "n_obs": 72},
        {
            "term": "exposure_area0_period0",
            "estimate": exposure_area0_period0,
            "se": None,
            "n_obs": 72,
        },
        {
            "term": "exposure_area0_period1",
            "estimate": exposure_area0_period1,
            "se": None,
            "n_obs": 72,
        },
        {
            "term": "instrument_area0_period0",
            "estimate": instrument_area0_period0,
            "se": None,
            "n_obs": 72,
        },
    ],
    "method_metadata": {
        "estimator": "weighted two-stage least squares",
        "outcome": "change_pp",
        "endogenous_regressor": "x",
        "excluded_instrument": "z",
        "exogenous_regressors_and_instruments": [
            "intercept",
            "period",
            "control",
        ],
        "weight": "base-vintage population",
        "exposure_units": "thousands of real dollars per worker per decade",
    },
    "diagnostics": {
        "n_obs": 72,
        "area_period_rows": int(len(reg)),
        "industry_count": int(len(industries)),
    },
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, allow_nan=False)
