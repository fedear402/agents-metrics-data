import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")

region = df.groupby("region_id", sort=False).first()
region_weight = region["region_weight"].to_numpy(dtype=float)
e = region_weight / region_weight.sum()

region_ids = region.index
region_position = {rid: i for i, rid in enumerate(region_ids)}
industry_ids = pd.Index(df["industry_id"].drop_duplicates())
industry_position = {iid: i for i, iid in enumerate(industry_ids)}

r = df["region_id"].map(region_position).to_numpy()
n = df["industry_id"].map(industry_position).to_numpy()
shares = df["share"].to_numpy(dtype=float)
shock_by_industry = (
    df[["industry_id", "shock"]].drop_duplicates("industry_id")
    .set_index("industry_id").reindex(industry_ids)["shock"].to_numpy(dtype=float)
)

R = len(region_ids)
N = len(industry_ids)

exposure = np.zeros((R, N), dtype=float)
np.add.at(exposure, (r, n), shares)

x = region["x"].to_numpy(dtype=float)
y = region["y"].to_numpy(dtype=float)
z = exposure @ shock_by_industry

def weighted_center(v):
    return v - np.dot(e, v)

y0 = weighted_center(y)
x0 = weighted_center(x)
z0 = weighted_center(z)

s = e @ exposure
def aggregate(v0):
    numerator = exposure.T @ (e * v0)
    return numerator / s

ybar = aggregate(y0)
xbar = aggregate(x0)
zbar = aggregate(z0)

def shock_level_iv(dependent, endogenous):
    regressors = np.column_stack((np.ones(N), endogenous))
    instruments = np.column_stack((np.ones(N), shock_by_industry))
    weighted_cross = instruments.T @ (s[:, None] * regressors)
    beta = np.linalg.solve(weighted_cross, instruments.T @ (s * dependent))

    residual = dependent - regressors @ beta
    scores = instruments * (s * residual)[:, None]
    inverse = np.linalg.inv(weighted_cross)
    covariance = (N / (N - 2)) * inverse @ (scores.T @ scores) @ inverse.T

    return float(beta[1]), float(np.sqrt(covariance[1, 1]))

effect, effect_se = shock_level_iv(ybar, xbar)
first_stage, first_stage_se = shock_level_iv(xbar, zbar)
effective_shocks = float(1.0 / np.sum(s ** 2))

output = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": effect, "se": effect_se, "n_obs": N},
        {"term": "first_stage", "estimate": first_stage, "se": first_stage_se, "n_obs": N},
        {"term": "effective_shocks", "estimate": effective_shocks, "se": None, "n_obs": N},
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS with Borusyak-Hull-Jaravel shock-level aggregation",
        "vcov": "shock-level HC1 with structural IV residuals and analytic exposure weights",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
