import json
import numpy as np
import pandas as pd

data = pd.read_csv("input.csv")

# Use one row per region to normalize regional weights and recover regional values.
regions = data.drop_duplicates("region_id").copy()
region_weight = regions["region_weight"].to_numpy(dtype=float)
e = region_weight / region_weight.sum()

region_ids = regions["region_id"].to_numpy()
industries = pd.Index(data["industry_id"].drop_duplicates())
N = len(industries)

# Align the region-industry data into matrices.
share_matrix = (
    data.pivot(index="region_id", columns="industry_id", values="share")
    .reindex(index=region_ids, columns=industries)
    .to_numpy(dtype=float)
)
shock_by_industry = (
    data.drop_duplicates("industry_id")
    .set_index("industry_id")["shock"]
    .reindex(industries)
    .to_numpy(dtype=float)
)

x = regions["x"].to_numpy(dtype=float)
y = regions["y"].to_numpy(dtype=float)
z = share_matrix @ shock_by_industry

# Center all regional variables using the normalized weights.
y0 = y - np.dot(e, y)
x0 = x - np.dot(e, x)
z0 = z - np.dot(e, z)

# Aggregate centered variables to industry level.
mass = e @ share_matrix
aggregated = np.column_stack([
    (share_matrix.T @ (e * y0)) / mass,
    (share_matrix.T @ (e * x0)) / mass,
    (share_matrix.T @ (e * z0)) / mass,
])

def shock_level_iv(dependent, endogenous):
    """Weighted IV slope and HC1 SE with a constant and structural residuals."""
    regressors = np.column_stack([np.ones(N), endogenous])
    instruments = np.column_stack([np.ones(N), shock_by_industry])
    cross = instruments.T @ (mass[:, None] * regressors)
    beta = np.linalg.solve(cross, instruments.T @ (mass * dependent))
    residual = dependent - regressors @ beta
    scores = instruments * (mass * residual)[:, None]
    inverse = np.linalg.inv(cross)
    covariance = (N / (N - 2)) * inverse @ (scores.T @ scores) @ inverse.T
    return float(beta[1]), float(np.sqrt(covariance[1, 1]))

effect, effect_se = shock_level_iv(aggregated[:, 0], aggregated[:, 1])
first_stage, first_stage_se = shock_level_iv(aggregated[:, 1], aggregated[:, 2])
effective_shocks = float(1.0 / np.sum(mass**2))

output = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": effect, "se": effect_se, "n_obs": int(N)},
        {"term": "first_stage", "estimate": first_stage, "se": first_stage_se, "n_obs": int(N)},
        {"term": "effective_shocks", "estimate": effective_shocks, "se": None, "n_obs": int(N)},
    ],
    "method_metadata": {
        "estimator": "weighted regional 2SLS with equivalent shock-level IV aggregation",
        "vcov": "shock-level HC1 with structural IV residuals and analytic weights",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
