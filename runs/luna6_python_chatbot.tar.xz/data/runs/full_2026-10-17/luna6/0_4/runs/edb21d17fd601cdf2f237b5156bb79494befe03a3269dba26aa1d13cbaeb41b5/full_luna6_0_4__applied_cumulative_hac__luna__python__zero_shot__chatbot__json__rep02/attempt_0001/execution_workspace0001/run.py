import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("input.csv", parse_dates=["date"])
df = df.sort_values("date").reset_index(drop=True)

df["dlog_vix"] = np.log(df["vix"]).diff()
for lag in range(1, 16):
    df[f"lag_{lag}"] = df["dlog_vix"].shift(lag)

df["log_sales"] = np.log(df["sales"])
regression_df = df.dropna(subset=["log_sales"] + [f"lag_{lag}" for lag in range(1, 16)])

y = regression_df["log_sales"]
X = sm.add_constant(regression_df[[f"lag_{lag}" for lag in range(1, 16)]])
model = sm.OLS(y, X).fit()

n_obs = int(len(regression_df))
hac_cov = np.asarray(
    sm.stats.sandwich_covariance.cov_hac(
        model,
        nlags=15,
        weights_func=lambda max_lag: 1.0 - np.arange(max_lag + 1) / 16.0,
        use_correction=False,
    )
)
hac_cov *= n_obs / (n_obs - 16)

params = model.params
lag_names = [f"lag_{lag}" for lag in range(1, 16)]
cumulative_estimate = float(params[lag_names].sum())
cumulative_variance = float(hac_cov[1:, 1:].sum())
cumulative_se = float(np.sqrt(max(cumulative_variance, 0.0)))

estimates = [
    {
        "term": "cumulative_response",
        "estimate": cumulative_estimate,
        "se": cumulative_se,
        "n_obs": n_obs,
    },
    {
        "term": "lag_1",
        "estimate": float(params["lag_1"]),
        "se": float(np.sqrt(max(float(hac_cov[X.columns.get_loc("lag_1"), X.columns.get_loc("lag_1")]), 0.0))),
        "n_obs": n_obs,
    },
    {
        "term": "lag_15",
        "estimate": float(params["lag_15"]),
        "se": float(np.sqrt(max(float(hac_cov[X.columns.get_loc("lag_15"), X.columns.get_loc("lag_15")]), 0.0))),
        "n_obs": n_obs,
    },
]

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "OLS of log(sales) on intercept and lags 1 through 15 of first differences in log(vix)",
        "vcov": "Newey-West HAC with Bartlett weights through lag 15, multiplied by N/(N-16)",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, allow_nan=False)
