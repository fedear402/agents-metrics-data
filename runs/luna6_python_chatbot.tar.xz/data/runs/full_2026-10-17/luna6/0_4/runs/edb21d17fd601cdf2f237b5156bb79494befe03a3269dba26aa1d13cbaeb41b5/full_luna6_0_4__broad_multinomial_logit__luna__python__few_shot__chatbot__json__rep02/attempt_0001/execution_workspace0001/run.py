import json

import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy.special import softmax

data = pd.read_csv("input.csv")
y = data["y"].astype(int)
outcomes = [0, 1, 2]
if sorted(y.unique().tolist()) != outcomes:
    raise ValueError("y must contain outcomes 0, 1, and 2.")

X = sm.add_constant(data[["x", "z"]], has_constant="add")
fit = sm.MNLogit(y, X).fit(disp=False, tol=1e-12, maxiter=1000)

# MNLogit parameter columns follow the sorted nonbase outcome order.
nonbase = outcomes[1:]
params = fit.params.copy()
errors = fit.bse.copy()
params.columns = nonbase
errors.columns = nonbase

n_obs = int(len(data))
rows = []
for term, covariate, outcome in [
    ("x_cat1", "x", 1),
    ("z_cat1", "z", 1),
    ("x_cat2", "x", 2),
    ("z_cat2", "z", 2),
]:
    rows.append({
        "term": term,
        "estimate": float(params.loc[covariate, outcome]),
        "se": float(errors.loc[covariate, outcome]),
        "n_obs": n_obs,
    })

zero_indices = np.array([
    0.0,
    float(params.loc["const", 1]),
    float(params.loc["const", 2]),
])
prob_cat2_zero = float(softmax(zero_indices)[2])
rows.append({
    "term": "prob_cat2_zero",
    "estimate": prob_cat2_zero,
    "se": None,
    "n_obs": n_obs,
})

result = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": rows,
    "method_metadata": {
        "estimator": "multinomial logit maximum likelihood",
        "vcov": "conventional observed-information",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
