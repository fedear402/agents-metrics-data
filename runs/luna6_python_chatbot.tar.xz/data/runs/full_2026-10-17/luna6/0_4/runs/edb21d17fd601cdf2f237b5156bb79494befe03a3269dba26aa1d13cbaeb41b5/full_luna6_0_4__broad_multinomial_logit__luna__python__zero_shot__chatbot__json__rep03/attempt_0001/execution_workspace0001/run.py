import json
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("input.csv")
n_obs = int(len(df))

X = sm.add_constant(df[["x", "z"]], has_constant="add")
model = sm.MNLogit(df["y"], X)
result = model.fit(method="newton", disp=False)

# Statsmodels uses outcome 0 as the reference category when outcomes are
# ordered 0, 1, 2. Parameter columns correspond to outcomes 1 and 2.
params = result.params
ses = result.bse

prob_cat2_zero = float(result.predict(pd.DataFrame({
    "const": [1.0],
    "x": [0.0],
    "z": [0.0],
}))[2].iloc[0])

estimates = [
    {"term": "x_cat1", "estimate": float(params.loc["x", 0]), "se": float(ses.loc["x", 0]), "n_obs": n_obs},
    {"term": "z_cat1", "estimate": float(params.loc["z", 0]), "se": float(ses.loc["z", 0]), "n_obs": n_obs},
    {"term": "x_cat2", "estimate": float(params.loc["x", 1]), "se": float(ses.loc["x", 1]), "n_obs": n_obs},
    {"term": "z_cat2", "estimate": float(params.loc["z", 1]), "se": float(ses.loc["z", 1]), "n_obs": n_obs},
    {"term": "prob_cat2_zero", "estimate": prob_cat2_zero, "se": None, "n_obs": n_obs},
]

output = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "Maximum likelihood multinomial logit",
        "vcov": "Conventional observed-information covariance matrix",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(output, f, indent=2)
