import json
from pathlib import Path

import numpy as np
import pandas as pd


def main():
    crosswalk = pd.read_csv("crosswalk.csv")
    trade = pd.read_csv("trade.csv")
    areas = pd.read_csv("areas.csv")
    employment = pd.read_csv("employment.csv")
    outcomes = pd.read_csv("outcomes.csv")

    trade = trade.merge(crosswalk[["code", "industry"]], on="code", how="left", validate="many_to_one")

    area_keys = areas[["area", "period", "vintage", "total_employment", "population"]]
    emp = employment.merge(area_keys, on=["area", "period", "vintage"], how="left", validate="many_to_one")
    emp = emp.merge(crosswalk[["industry"]].drop_duplicates(), on="industry", how="inner")

    periods = trade["period"].drop_duplicates().tolist()
    exposure_rows = []

    for period in periods:
        period_trade = trade.loc[trade["period"] == period].copy()
        price_index = period_trade["price_index"].drop_duplicates().item()
        years = period_trade["years"].drop_duplicates().item()

        for vintage, change_column in (("base", "us_change"), ("early", "other_change")):
            period_emp = emp.loc[(emp["period"] == period) & (emp["vintage"] == vintage)]
            national = period_emp.groupby("industry")["employment"].sum()

            changes = period_trade.set_index("industry")[change_column]
            shocks = (
                changes / national
                / (price_index / 100.0)
                / 1000.0
                * (10.0 / years)
            )

            area_emp = period_emp.pivot_table(
                index="area",
                columns="industry",
                values="employment",
                aggfunc="sum",
                fill_value=0.0,
            )
            all_industries = sorted(crosswalk["industry"].unique())
            area_emp = area_emp.reindex(columns=all_industries, fill_value=0.0)
            shocks = shocks.reindex(all_industries)

            totals = areas.loc[
                (areas["period"] == period) & (areas["vintage"] == vintage)
            ].set_index("area")["total_employment"]
            area_emp = area_emp.reindex(totals.index, fill_value=0.0)
            exposure = area_emp.mul(shocks, axis=1).sum(axis=1) / totals

            for area, value in exposure.items():
                exposure_rows.append(
                    {
                        "area": area,
                        "period": period,
                        "vintage": vintage,
                        "exposure": float(value),
                    }
                )

    exposure_df = pd.DataFrame(exposure_rows)
    x = exposure_df.loc[exposure_df["vintage"] == "base", ["area", "period", "exposure"]].rename(
        columns={"exposure": "x"}
    )
    z = exposure_df.loc[exposure_df["vintage"] == "early", ["area", "period", "exposure"]].rename(
        columns={"exposure": "z"}
    )

    data = (
        outcomes.merge(x, on=["area", "period"], how="inner", validate="one_to_one")
        .merge(z, on=["area", "period"], how="inner", validate="one_to_one")
        .merge(
            areas.loc[areas["vintage"] == "base", ["area", "period", "population"]],
            on=["area", "period"],
            how="inner",
            validate="one_to_one",
        )
        .merge(
            areas.loc[areas["vintage"] == "base", ["area", "period", "total_employment"]],
            on=["area", "period"],
            how="inner",
            validate="one_to_one",
        )
    )

    period_values = sorted(data["period"].unique())
    period_indicator = (data["period"] == period_values[-1]).astype(float).to_numpy()
    exog = np.column_stack(
        [
            np.ones(len(data)),
            period_indicator,
            data["control"].to_numpy(dtype=float),
        ]
    )
    x_vec = data["x"].to_numpy(dtype=float)
    z_vec = data["z"].to_numpy(dtype=float)
    y = data["change_pp"].to_numpy(dtype=float)
    w = data["population"].to_numpy(dtype=float)

    sqrt_w = np.sqrt(w)
    exog_w = exog * sqrt_w[:, None]
    x_w = x_vec * sqrt_w
    z_w = z_vec * sqrt_w
    y_w = y * sqrt_w

    instrument_matrix = np.column_stack([exog_w, z_w])
    regressors = np.column_stack([exog_w, x_w])

    projected_regressors = instrument_matrix @ np.linalg.solve(
        instrument_matrix.T @ instrument_matrix,
        instrument_matrix.T @ regressors,
    )
    beta = np.linalg.solve(
        projected_regressors.T @ projected_regressors,
        projected_regressors.T @ y_w,
    )
    iv_slope = float(beta[-1])

    lookup = data.set_index(["area", "period"])
    period0, period1 = period_values[0], period_values[1]

    estimates = [
        {"term": "iv_slope", "estimate": iv_slope, "se": None, "n_obs": 72},
        {
            "term": "exposure_area0_period0",
            "estimate": float(lookup.loc[(0, period0), "x"]),
            "se": None,
            "n_obs": 72,
        },
        {
            "term": "exposure_area0_period1",
            "estimate": float(lookup.loc[(0, period1), "x"]),
            "se": None,
            "n_obs": 72,
        },
        {
            "term": "instrument_area0_period0",
            "estimate": float(lookup.loc[(0, period0), "z"]),
            "se": None,
            "n_obs": 72,
        },
    ]

    result = {
        "task_id": "applied_multivintage_trade_iv",
        "platform": "python",
        "estimates": estimates,
        "method_metadata": {
            "estimator": "weighted two-stage least squares",
            "outcome": "change_pp",
            "regressors": ["intercept", "period", "control", "x"],
            "instruments": ["intercept", "period", "control", "z"],
            "weight": "base-vintage population",
            "n_obs": 72,
        },
        "diagnostics": {
            "n_obs": int(len(data)),
            "area_period_rows": int(data[["area", "period"]].drop_duplicates().shape[0]),
        },
    }

    with Path("result.json").open("w", encoding="utf-8") as f:
        json.dump(result, f, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
