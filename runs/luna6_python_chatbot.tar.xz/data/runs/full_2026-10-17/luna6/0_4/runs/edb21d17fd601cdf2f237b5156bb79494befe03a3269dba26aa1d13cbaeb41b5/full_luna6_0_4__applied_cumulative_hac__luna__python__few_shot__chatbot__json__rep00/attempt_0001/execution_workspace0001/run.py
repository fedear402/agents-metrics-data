import json

import numpy as np
import pandas as pd

data = pd.read_csv("input.csv", parse_dates=["date"])
data = data.sort_values("date").reset_index(drop=True)

data["log_vix"] = np.log(data["vix"])
data["vix_change"] = data["log_vix"].diff()
data["log_sales"] = np.log(data["sales"])

lag_columns = []
for lag in range(1, 16):
    column = f"lag_{lag}"
    data[column] = data["vix_change"].shift(lag)
    lag_columns.append(column)

sample = data.dropna(subset=["log_sales"] + lag_columns)
N = len(sample)

X = np.column_stack(
    [np.ones(N)] + [sample[column].to_numpy() for column in lag_columns]
)
y = sample["log_sales"].to_numpy()

coefficients = np.linalg.lstsq(X, y, rcond=None)[0]
residuals = y - X @ coefficients

# Bartlett Newey-West covariance with maximum lag 15.
scores = X * residuals[:, None]
meat = scores.T @ scores
hac_lags = 15
for j in range(1, hac_lags + 1):
    weight = 1 - j / 16
    lag_product = scores[j:].T @ scores[:-j]
    meat += weight * (lag_product + lag_product.T)

bread = np.linalg.inv(X.T @ X)
parameter_count = X.shape[1]
covariance = (N / (N - parameter_count)) * bread @ meat @ bread

contrast = np.zeros(parameter_count)
contrast[1:] = 1.0
cumulative_estimate = float(contrast @ coefficients)
cumulative_se = float(np.sqrt(contrast @ covariance @ contrast))

rows = [
    {
        "term": "cumulative_response",
        "estimate": cumulative_estimate,
        "se": cumulative_se,
        "n_obs": N,
    },
    {
        "term": "lag_1",
        "estimate": float(coefficients[1]),
        "se": float(np.sqrt(covariance[1, 1])),
        "n_obs": N,
    },
    {
        "term": "lag_15",
        "estimate": float(coefficients[15]),
        "se": float(np.sqrt(covariance[15, 15])),
        "n_obs": N,
    },
]

output = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": rows,
    "method_metadata": {
        "estimator": "OLS with intercept and 15 lagged log-vix changes",
        "vcov": "Newey-West HAC, Bartlett weights, maximum lag 15, correction N/(N-16)",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
