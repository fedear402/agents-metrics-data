import json
import pandas as pd
import statsmodels.api as sm

data = pd.read_csv("input.csv")
n_obs = int(len(data))

X = sm.add_constant(data[["x", "z"]], has_constant="add")
model = sm.MNLogit(data["y"], X)
result = model.fit(method="newton", disp=False, maxiter=200)

params = result.params
ses = result.bse

# With 0 as the base outcome, statsmodels reports the non-base
# outcome equations in ascending outcome order.
estimates = []
for term, outcome, predictor in [
    ("x_cat1", 1, "x"),
    ("z_cat1", 1, "z"),
    ("x_cat2", 2, "x"),
    ("z_cat2", 2, "z"),
]:
    estimates.append({
        "term": term,
        "estimate": float(params.loc[predictor, outcome]),
        "se": float(ses.loc[predictor, outcome]),
        "n_obs": n_obs,
    })

zero_row = pd.DataFrame({"const": [1.0], "x": [0.0], "z": [0.0]})
prob_cat2_zero = float(result.predict(zero_row).iloc[0, 2])
estimates.append({
    "term": "prob_cat2_zero",
    "estimate": prob_cat2_zero,
    "se": None,
    "n_obs": n_obs,
})

output = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "Multinomial logit maximum likelihood",
        "vcov": "Conventional observed-information covariance matrix",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(output, f, indent=2)
