import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")

# Keep one observation per region for regional values and weights.
regions = df[["region_id", "region_weight", "x", "y"]].drop_duplicates("region_id")
regions = regions.set_index("region_id")
region_ids = regions.index
e = regions["region_weight"].to_numpy(dtype=float)
e = e / e.sum()

shares = df.pivot(index="region_id", columns="industry_id", values="share").reindex(region_ids)
shocks = df.drop_duplicates("industry_id").set_index("industry_id")["shock"]
shares = shares.reindex(columns=shocks.index)
shares = shares.to_numpy(dtype=float)
shock = shocks.to_numpy(dtype=float)

x = regions["x"].to_numpy(dtype=float)
y = regions["y"].to_numpy(dtype=float)
z = shares @ shock

# Weighted 2SLS with an intercept and one instrument.
def weighted_iv_slope_se(dependent, endogenous, instrument, weights, n_obs):
    regressors = np.column_stack((np.ones(n_obs), endogenous))
    instruments = np.column_stack((np.ones(n_obs), instrument))

    cross = instruments.T @ (weights[:, None] * regressors)
    beta = np.linalg.solve(cross, instruments.T @ (weights * dependent))
    residual = dependent - regressors @ beta

    scores = instruments * (weights * residual)[:, None]
    inverse = np.linalg.inv(cross)
    hc1 = n_obs / (n_obs - 2)
    covariance = hc1 * inverse @ (scores.T @ scores) @ inverse.T
    return float(beta[1]), float(np.sqrt(covariance[1, 1]))

# Center regional variables using the normalized regional weights.
y0 = y - np.sum(e * y)
x0 = x - np.sum(e * x)
z0 = z - np.sum(e * z)

industry_mass = e @ shares
keep = industry_mass > 0
industry_mass = industry_mass[keep]
shares = shares[:, keep]
shock = shock[keep]
n_industries = len(industry_mass)

def aggregate_centered(values):
    return (shares.T @ (e * values)) / industry_mass

ybar = aggregate_centered(y0)
xbar = aggregate_centered(x0)
zbar = aggregate_centered(z0)

effect, effect_se = weighted_iv_slope_se(
    ybar, xbar, shock, industry_mass, n_industries
)
first_stage, first_stage_se = weighted_iv_slope_se(
    xbar, zbar, shock, industry_mass, n_industries
)
effective_shocks = float(1.0 / np.sum(industry_mass**2))

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": effect, "se": effect_se, "n_obs": n_industries},
        {"term": "first_stage", "estimate": first_stage, "se": first_stage_se, "n_obs": n_industries},
        {"term": "effective_shocks", "estimate": effective_shocks, "se": None, "n_obs": n_industries},
    ],
    "method_metadata": {
        "estimator": "weighted regional 2SLS with Borusyak-Hull-Jaravel shock-level aggregation",
        "vcov": "shock-level HC1 using structural IV residuals and analytic weights",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
