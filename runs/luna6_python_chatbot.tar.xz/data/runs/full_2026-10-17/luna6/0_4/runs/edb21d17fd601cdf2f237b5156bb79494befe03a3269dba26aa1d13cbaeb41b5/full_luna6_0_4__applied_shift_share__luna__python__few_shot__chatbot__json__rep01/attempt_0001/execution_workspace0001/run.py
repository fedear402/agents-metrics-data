import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")

# Use one row per region to normalize weights and collect regional variables.
regions = df.drop_duplicates("region_id").copy()
region_weights = regions["region_weight"].to_numpy(dtype=float)
e = region_weights / region_weights.sum()

# Build the shift-share instrument from region-industry rows.
shock_by_industry = df.groupby("industry_id")["shock"].first()
df["shock_value"] = df["industry_id"].map(shock_by_industry)
df["instrument_component"] = df["share"] * df["shock_value"]
z_by_region = df.groupby("region_id")["instrument_component"].sum()

regions["z"] = regions["region_id"].map(z_by_region).to_numpy(dtype=float)
y = regions["y"].to_numpy(dtype=float)
x = regions["x"].to_numpy(dtype=float)
z = regions["z"].to_numpy(dtype=float)

# Center all regional variables using normalized regional weights.
y0 = y - np.sum(e * y)
x0 = x - np.sum(e * x)
z0 = z - np.sum(e * z)

# Aggregate centered variables to industry exposure cells.
industries = pd.Index(shock_by_industry.index)
share_matrix = (
    df.pivot_table(
        index="region_id",
        columns="industry_id",
        values="share",
        aggfunc="first",
    )
    .reindex(index=regions["region_id"], columns=industries)
    .to_numpy(dtype=float)
)

mass = e @ share_matrix
if np.any(mass <= 0):
    raise ValueError("Each included industry must have positive exposure mass.")

def aggregate(v0):
    return (share_matrix.T @ (e * v0)) / mass

ybar = aggregate(y0)
xbar = aggregate(x0)
zbar = aggregate(z0)
shock = shock_by_industry.reindex(industries).to_numpy(dtype=float)
n_industries = len(industries)

def shock_level_iv(dependent, endogenous, instrument):
    # Weighted IV with an intercept. The instrument matrix is [1, shock].
    regressors = np.column_stack((np.ones(n_industries), endogenous))
    instruments = np.column_stack((np.ones(n_industries), instrument))
    weighted_cross = instruments.T @ (mass[:, None] * regressors)
    beta = np.linalg.solve(
        weighted_cross,
        instruments.T @ (mass * dependent),
    )

    # Structural IV residuals and HC1 analytic-weight sandwich covariance.
    residual = dependent - regressors @ beta
    scores = instruments * (mass * residual)[:, None]
    inverse = np.linalg.inv(weighted_cross)
    hc1 = n_industries / (n_industries - 2)
    covariance = hc1 * inverse @ (scores.T @ scores) @ inverse.T
    return float(beta[1]), float(np.sqrt(covariance[1, 1]))

effect, effect_se = shock_level_iv(ybar, xbar, shock)
first_stage, first_stage_se = shock_level_iv(xbar, zbar, shock)
effective_shocks = float(1.0 / np.sum(mass**2))

output = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {
            "term": "effect",
            "estimate": effect,
            "se": effect_se,
            "n_obs": n_industries,
        },
        {
            "term": "first_stage",
            "estimate": first_stage,
            "se": first_stage_se,
            "n_obs": n_industries,
        },
        {
            "term": "effective_shocks",
            "estimate": effective_shocks,
            "se": None,
            "n_obs": n_industries,
        },
    ],
    "method_metadata": {
        "estimator": "weighted regional 2SLS with shock-level IV aggregation",
        "vcov": "shock-level HC1 with structural IV residuals and analytic weights",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
