import json
from pathlib import Path

import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS


def main():
    crosswalk = pd.read_csv("crosswalk.csv")
    trade = pd.read_csv("trade.csv")
    areas = pd.read_csv("areas.csv")
    employment = pd.read_csv("employment.csv")
    outcomes = pd.read_csv("outcomes.csv")

    trade = trade.merge(crosswalk, on="code", how="left", validate="many_to_one")

    # Each trade code maps to one industry, with one trade row per industry-period.
    trade = trade.drop_duplicates()
    if trade.duplicated(["period", "industry"]).any():
        raise ValueError("Each period-industry pair must have one trade row.")

    area_periods = areas[["area", "period"]].drop_duplicates()
    base_areas = areas.loc[areas["vintage"] == "base"].copy()
    early_areas = areas.loc[areas["vintage"] == "early"].copy()

    def exposure_for_vintage(vintage_areas, vintage, change_column):
        emp = employment.loc[employment["vintage"] == vintage].copy()
        frame = (
            area_periods.merge(
                vintage_areas[["area", "period", "total_employment"]],
                on=["area", "period"],
                how="left",
                validate="one_to_one",
            )
            .merge(
                emp[["area", "period", "industry", "employment"]],
                on=["area", "period"],
                how="left",
            )
            .merge(
                trade[["period", "industry", change_column, "price_index", "years"]],
                on=["period", "industry"],
                how="left",
                validate="many_to_one",
            )
        )
        frame["employment"] = frame["employment"].fillna(0.0)
        frame["national_employment"] = frame.groupby(
            ["period", "industry"]
        )["employment"].transform("sum")
        frame["contribution"] = (
            (frame["employment"] / frame["total_employment"])
            * (
                frame[change_column]
                / frame["national_employment"]
                / (frame["price_index"] / 100.0)
                / 1000.0
                * (10.0 / frame["years"])
            )
        )
        return frame.groupby(["area", "period"], as_index=False)["contribution"].sum()

    x = exposure_for_vintage(base_areas, "base", "us_change").rename(
        columns={"contribution": "x"}
    )
    z = exposure_for_vintage(early_areas, "early", "other_change").rename(
        columns={"contribution": "z"}
    )

    sample = (
        outcomes.merge(
            base_areas[["area", "period", "population"]],
            on=["area", "period"],
            how="inner",
            validate="one_to_one",
        )
        .merge(x, on=["area", "period"], how="inner", validate="one_to_one")
        .merge(z, on=["area", "period"], how="inner", validate="one_to_one")
    )

    exog = pd.DataFrame(
        {
            "intercept": np.ones(len(sample)),
            "period": pd.factorize(sample["period"], sort=True)[0].astype(float),
            "control": sample["control"].astype(float),
        },
        index=sample.index,
    )
    fit = IV2SLS(
        dependent=sample["change_pp"].astype(float),
        exog=exog,
        endog=sample[["x"]].astype(float),
        instruments=sample[["z"]].astype(float),
        weights=sample["population"].astype(float),
    ).fit()

    area0 = sample.loc[sample["area"] == 0].sort_values("period")
    if len(sample) != 72 or len(area0) < 2:
        raise ValueError("Expected 72 area-period rows and two periods for area 0.")

    estimates = [
        {"term": "iv_slope", "estimate": float(fit.params["x"]), "se": None, "n_obs": 72},
        {
            "term": "exposure_area0_period0",
            "estimate": float(area0.iloc[0]["x"]),
            "se": None,
            "n_obs": 72,
        },
        {
            "term": "exposure_area0_period1",
            "estimate": float(area0.iloc[1]["x"]),
            "se": None,
            "n_obs": 72,
        },
        {
            "term": "instrument_area0_period0",
            "estimate": float(area0.iloc[0]["z"]),
            "se": None,
            "n_obs": 72,
        },
    ]

    result = {
        "task_id": "applied_multivintage_trade_iv",
        "platform": "python",
        "estimates": estimates,
        "method_metadata": {
            "estimator": "weighted 2SLS",
            "outcome": "change_pp",
            "endogenous_regressor": "x",
            "excluded_instrument": "z",
            "exogenous_regressors": ["intercept", "period", "control"],
            "exogenous_instruments": ["intercept", "period", "control"],
            "weight": "base-vintage population",
            "exposure_units": "thousands of real dollars per worker per decade",
        },
        "diagnostics": {"n_obs": 72},
    }

    with Path("result.json").open("w", encoding="utf-8") as f:
        json.dump(result, f, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
