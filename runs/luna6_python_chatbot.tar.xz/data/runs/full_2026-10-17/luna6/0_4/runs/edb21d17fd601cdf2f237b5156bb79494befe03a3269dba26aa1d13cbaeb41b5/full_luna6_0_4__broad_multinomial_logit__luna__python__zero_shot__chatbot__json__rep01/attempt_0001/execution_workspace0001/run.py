import json
import pandas as pd
import statsmodels.api as sm

data = pd.read_csv("input.csv")
n_obs = int(len(data))

X = sm.add_constant(data[["x", "z"]], has_constant="add")
model = sm.MNLogit(data["y"], X)
result = model.fit(method="newton", maxiter=1000, disp=False)

params = result.params
standard_errors = result.bse

# Statsmodels uses outcome 0 as the reference category and labels
# the remaining parameter columns by outcome.
estimates = []
for term, outcome, parameter_name in [
    ("x_cat1", 1, "x"),
    ("z_cat1", 1, "z"),
    ("x_cat2", 2, "x"),
    ("z_cat2", 2, "z"),
]:
    column = outcome
    if column not in params.columns:
        column = params.columns[outcome - 1]
    estimates.append({
        "term": term,
        "estimate": float(params.loc[parameter_name, column]),
        "se": float(standard_errors.loc[parameter_name, column]),
        "n_obs": n_obs,
    })

zero_design = pd.DataFrame({"const": [1.0], "x": [0.0], "z": [0.0]})
prob_cat2_zero = float(result.predict(zero_design)[0, 2])
estimates.append({
    "term": "prob_cat2_zero",
    "estimate": prob_cat2_zero,
    "se": None,
    "n_obs": n_obs,
})

output = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "Multinomial logit maximum likelihood",
        "vcov": "Conventional observed-information covariance",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(output, file, indent=2)
