import json
import numpy as np
import pandas as pd

data = pd.read_csv("./input.csv")
cohorts = [3, 5, 7]
results = []
treated_counts = []
row_counts = []
coefficients = []

for cohort in cohorts:
    window_times = list(range(cohort - 2, cohort + 3))
    eligible = (
        (data["g"] == cohort)
        | (data["g"] == 0)
        | (data["g"] > cohort + 2)
    )
    sample = data.loc[
        eligible & data["time"].isin(window_times)
    ].copy()

    observed_times = sample.groupby("id")["time"].agg(set)
    retained_ids = observed_times[
        observed_times.apply(lambda times: set(window_times).issubset(times))
    ].index
    sample = sample[sample["id"].isin(retained_ids)].copy()

    sample["did"] = (
        (sample["g"] == cohort) & (sample["time"] >= cohort)
    ).astype(float)

    unit_effects = pd.get_dummies(
        sample["id"], drop_first=True, dtype=float
    ).to_numpy()
    time_effects = pd.get_dummies(
        sample["time"], drop_first=True, dtype=float
    ).to_numpy()
    design = np.column_stack([
        np.ones(len(sample)),
        sample["did"].to_numpy(),
        unit_effects,
        time_effects,
    ])
    coefficient = np.linalg.lstsq(
        design, sample["y"].to_numpy(), rcond=None
    )[0][1]

    treated_count = sample.loc[
        sample["g"] == cohort, "id"
    ].nunique()
    row_count = len(sample)

    coefficients.append(float(coefficient))
    treated_counts.append(treated_count)
    row_counts.append(row_count)
    results.append({
        "term": f"att_g{cohort}",
        "estimate": float(coefficient),
        "se": None,
        "n_obs": int(row_count),
    })

weighted = float(np.average(coefficients, weights=treated_counts))
results.append({
    "term": "att_weighted",
    "estimate": weighted,
    "se": None,
    "n_obs": int(sum(row_counts)),
})

output = {
    "task_id": "broad_cohort_stack",
    "platform": "python",
    "estimates": results,
    "method_metadata": {},
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
