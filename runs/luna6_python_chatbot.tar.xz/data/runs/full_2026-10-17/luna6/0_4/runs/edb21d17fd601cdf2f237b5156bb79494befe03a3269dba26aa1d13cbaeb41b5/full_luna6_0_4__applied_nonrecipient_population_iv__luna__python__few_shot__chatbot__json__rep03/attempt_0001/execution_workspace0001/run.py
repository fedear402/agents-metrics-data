import json
import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS

households = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

d = households.loc[households["recipient"] == 0].copy()
d["intercept_ineligible"] = 1 - d["eligible"]
d["intercept_eligible"] = d["eligible"]
d["baseline_ineligible"] = d["baseline"] * (1 - d["eligible"])
d["baseline_eligible"] = d["baseline"] * d["eligible"]
d["dose_ineligible"] = d["dose"] * (1 - d["eligible"])
d["dose_eligible"] = d["dose"] * d["eligible"]
d["instrument_ineligible"] = d["instrument"] * (1 - d["eligible"])
d["instrument_eligible"] = d["instrument"] * d["eligible"]

exog = d[
    [
        "intercept_ineligible",
        "intercept_eligible",
        "baseline_ineligible",
        "baseline_eligible",
    ]
]
endog = d[["dose_ineligible", "dose_eligible"]]
instruments = d[
    [
        "instrument_ineligible",
        "instrument_eligible",
    ]
]

fit = IV2SLS(
    dependent=d["outcome"],
    exog=exog,
    endog=endog,
    instruments=instruments,
    weights=d["weight"],
).fit()

ineligible_slope = float(fit.params["dose_ineligible"])
eligible_slope = float(fit.params["dose_eligible"])

group_effects = {}
for eligible, term in [
    (0, "ineligible_effect"),
    (1, "eligible_nonrecipient_effect"),
]:
    group = d.loc[d["eligible"] == eligible]
    weighted_mean_dose = np.average(group["dose"], weights=group["weight"])
    group_effects[term] = float(
        (ineligible_slope if eligible == 0 else eligible_slope)
        * weighted_mean_dose
    )

population_weights = census.set_index("eligible")["nonrecipient_population"]
population_effect = float(
    np.average(
        [group_effects["ineligible_effect"], group_effects["eligible_nonrecipient_effect"]],
        weights=[
            population_weights.loc[0],
            population_weights.loc[1],
        ],
    )
)

n_obs = int(len(d))
result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "ineligible_effect",
            "estimate": group_effects["ineligible_effect"],
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "eligible_nonrecipient_effect",
            "estimate": group_effects["eligible_nonrecipient_effect"],
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "population_effect",
            "estimate": population_effect,
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "counterfactual": "dose set to zero for every retained nonrecipient household",
        "attribution_convention": "synthetic zero-dose counterfactual",
        "within_group_effect": "fitted dose slope multiplied by household-weighted mean dose",
        "population_aggregation": "nonrecipient_population census counts",
    },
    "diagnostics": {
        "sample": "all household rows with recipient equal to zero",
        "n_obs": n_obs,
    },
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, allow_nan=False)
