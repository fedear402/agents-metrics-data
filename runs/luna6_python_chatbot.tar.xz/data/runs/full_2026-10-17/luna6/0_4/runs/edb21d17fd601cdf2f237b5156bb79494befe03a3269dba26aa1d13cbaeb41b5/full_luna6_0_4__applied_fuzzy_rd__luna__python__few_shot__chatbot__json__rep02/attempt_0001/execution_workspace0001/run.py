import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
inside = df.loc[df["score"].abs() < 1].copy()
n_obs = len(inside)

score = inside["score"].to_numpy(dtype=float)
right = (score >= 0).astype(float)
weights = 1 - np.abs(score)

# Separate local-linear regressions on the two sides, with side-specific intercepts and slopes.
X = np.column_stack([
    1 - right,
    (1 - right) * score,
    right,
    right * score,
])
bread = np.linalg.inv(X.T @ (weights[:, None] * X))
loading = bread @ (X.T * weights)

def discontinuity_and_influence(outcome):
    y = inside[outcome].to_numpy(dtype=float)
    beta = loading @ y
    residual = y - X @ beta
    contrast = np.array([-1.0, 0.0, 1.0, 0.0])
    estimate = float(contrast @ beta)
    influence = (contrast @ bread) @ (X.T * weights)
    influence = influence * residual
    return estimate, influence

reduced_form, influence_rf = discontinuity_and_influence("earnings")
first_stage, influence_fs = discontinuity_and_influence("participated")

joint_covariance = np.array([
    [influence_rf @ influence_rf, influence_rf @ influence_fs],
    [influence_fs @ influence_rf, influence_fs @ influence_fs],
])

treatment_effect = reduced_form / first_stage
gradient = np.array([1.0 / first_stage, -reduced_form / first_stage**2])
treatment_variance = gradient @ joint_covariance @ gradient

estimates = [
    {
        "term": "treatment_effect",
        "estimate": float(treatment_effect),
        "se": float(np.sqrt(max(treatment_variance, 0.0))),
        "n_obs": int(n_obs),
    },
    {
        "term": "reduced_form",
        "estimate": float(reduced_form),
        "se": float(np.sqrt(max(joint_covariance[0, 0], 0.0))),
        "n_obs": int(n_obs),
    },
    {
        "term": "first_stage",
        "estimate": float(first_stage),
        "se": float(np.sqrt(max(joint_covariance[1, 1], 0.0))),
        "n_obs": int(n_obs),
    },
]

output = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "local_linear_fuzzy_regression_discontinuity_triangular_weights_bandwidth_1",
        "vcov": "HC0_no_degrees_of_freedom_correction_joint_delta_method",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
