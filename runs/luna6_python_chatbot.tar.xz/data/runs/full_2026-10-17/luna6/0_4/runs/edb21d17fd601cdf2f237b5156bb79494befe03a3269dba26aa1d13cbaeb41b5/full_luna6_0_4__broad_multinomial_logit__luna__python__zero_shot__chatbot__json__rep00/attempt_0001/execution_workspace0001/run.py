import json
import pandas as pd
import statsmodels.api as sm

data = pd.read_csv("input.csv")
n_obs = len(data)

X = sm.add_constant(data[["x", "z"]], has_constant="add")
model = sm.MNLogit(data["y"], X)
result = model.fit(method="newton", disp=False)

params = result.params
ses = result.bse

# With outcomes coded 0, 1, 2, statsmodels uses 0 as the base outcome
# and orders the non-base parameter columns as 1, then 2.
p_cat2_zero = float(result.predict(pd.DataFrame({
    "const": [1.0],
    "x": [0.0],
    "z": [0.0],
}))[2].iloc[0])

estimates = [
    {"term": "x_cat1", "estimate": float(params.loc["x", 0]), "se": float(ses.loc["x", 0]), "n_obs": n_obs},
    {"term": "z_cat1", "estimate": float(params.loc["z", 0]), "se": float(ses.loc["z", 0]), "n_obs": n_obs},
    {"term": "x_cat2", "estimate": float(params.loc["x", 1]), "se": float(ses.loc["x", 1]), "n_obs": n_obs},
    {"term": "z_cat2", "estimate": float(params.loc["z", 1]), "se": float(ses.loc["z", 1]), "n_obs": n_obs},
    {"term": "prob_cat2_zero", "estimate": p_cat2_zero, "se": None, "n_obs": n_obs},
]

output = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "Multinomial logit maximum likelihood",
        "vcov": "Conventional observed-information covariance matrix",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(output, f, indent=2, allow_nan=False)
