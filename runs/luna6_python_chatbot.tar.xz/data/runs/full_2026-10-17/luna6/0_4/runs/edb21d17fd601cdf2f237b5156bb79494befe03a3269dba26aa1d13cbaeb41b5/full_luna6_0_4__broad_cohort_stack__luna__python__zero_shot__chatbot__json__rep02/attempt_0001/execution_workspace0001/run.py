import json
import numpy as np
import pandas as pd

data = pd.read_csv("input.csv")
cohorts = [3, 5, 7]
estimates = []
treated_counts = []
row_counts = []

for cohort in cohorts:
    times = list(range(cohort - 2, cohort + 3))
    eligible = data[
        (data["g"] == cohort)
        | (data["g"] == 0)
        | (data["g"] > cohort + 2)
    ]
    sample = eligible[eligible["time"].isin(times)].copy()

    observed_times = sample.groupby("id")["time"].nunique()
    balanced_ids = observed_times[observed_times == 5].index
    sample = sample[sample["id"].isin(balanced_ids)].copy()

    sample["did"] = (
        (sample["g"] == cohort) & (sample["time"] >= cohort)
    ).astype(float)

    # Absorb unit and calendar-time fixed effects by double demeaning.
    y = sample["y"].astype(float)
    y_tilde = (
        y
        - sample.groupby("id")["y"].transform("mean")
        - sample.groupby("time")["y"].transform("mean")
        + y.mean()
    )
    d = sample["did"]
    d_tilde = (
        d
        - sample.groupby("id")["did"].transform("mean")
        - sample.groupby("time")["did"].transform("mean")
        + d.mean()
    )

    estimate = float((d_tilde * y_tilde).sum() / (d_tilde ** 2).sum())
    treated_count = int(sample.loc[sample["g"] == cohort, "id"].nunique())
    row_count = int(len(sample))

    estimates.append(estimate)
    treated_counts.append(treated_count)
    row_counts.append(row_count)

weighted_estimate = float(
    np.average(estimates, weights=treated_counts)
)

result = {
    "task_id": "broad_cohort_stack",
    "platform": "python",
    "estimates": [
        {
            "term": f"att_g{cohort}",
            "estimate": estimate,
            "se": None,
            "n_obs": row_count,
        }
        for cohort, estimate, row_count in zip(cohorts, estimates, row_counts)
    ]
    + [
        {
            "term": "att_weighted",
            "estimate": weighted_estimate,
            "se": None,
            "n_obs": sum(row_counts),
        }
    ],
    "method_metadata": {},
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output_file:
    json.dump(result, output_file, indent=2)
