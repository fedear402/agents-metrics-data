import json

import numpy as np
import pandas as pd

data = pd.read_csv("input.csv", parse_dates=["date"])
data = data.sort_values("date").reset_index(drop=True)

data["vix_change"] = np.log(data["vix"]).diff()
for lag in range(1, 16):
    data[f"lag_{lag}"] = data["vix_change"].shift(lag)

sample = data.dropna(subset=["sales"] + [f"lag_{lag}" for lag in range(1, 16)])
N = len(sample)

X = np.column_stack(
    [np.ones(N)] + [sample[f"lag_{lag}"].to_numpy() for lag in range(1, 16)]
)
y = np.log(sample["sales"].to_numpy())

coefficients = np.linalg.lstsq(X, y, rcond=None)[0]
residuals = y - X @ coefficients
scores = X * residuals[:, None]

meat = scores.T @ scores
for j in range(1, 16):
    weight = 1 - j / 16
    lag_product = scores[j:].T @ scores[:-j]
    meat += weight * (lag_product + lag_product.T)

bread = np.linalg.inv(X.T @ X)
covariance = (N / (N - 16)) * bread @ meat @ bread

cumulative_contrast = np.r_[0.0, np.ones(15)]
rows = [
    {
        "term": "cumulative_response",
        "estimate": float(cumulative_contrast @ coefficients),
        "se": float(np.sqrt(cumulative_contrast @ covariance @ cumulative_contrast)),
        "n_obs": int(N),
    },
    {
        "term": "lag_1",
        "estimate": float(coefficients[1]),
        "se": float(np.sqrt(covariance[1, 1])),
        "n_obs": int(N),
    },
    {
        "term": "lag_15",
        "estimate": float(coefficients[15]),
        "se": float(np.sqrt(covariance[15, 15])),
        "n_obs": int(N),
    },
]

output = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": rows,
    "method_metadata": {
        "estimator": "OLS with intercept and 15 lags of log VIX first differences",
        "vcov": "Newey-West HAC, Bartlett maximum lag 15, correction N/(N-16)",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
