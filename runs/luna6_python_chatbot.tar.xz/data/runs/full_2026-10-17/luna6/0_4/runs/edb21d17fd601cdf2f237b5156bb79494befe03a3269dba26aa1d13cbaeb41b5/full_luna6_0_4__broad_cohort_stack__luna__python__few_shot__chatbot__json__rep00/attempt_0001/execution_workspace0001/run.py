import json

import numpy as np
import pandas as pd

data = pd.read_csv("input.csv")
estimates = []
treated_counts = []
row_counts = []

for cohort in (3, 5, 7):
    window = list(range(cohort - 2, cohort + 3))
    eligible = data[
        (data["g"] == cohort)
        | (data["g"] == 0)
        | (data["g"] > cohort + 2)
    ]
    eligible = eligible[eligible["time"].isin(window)]

    balanced_ids = (
        eligible.groupby("id")["time"]
        .apply(lambda times: set(times) == set(window))
    )
    retained_ids = balanced_ids[balanced_ids].index
    comparison = eligible[eligible["id"].isin(retained_ids)].copy()

    comparison["did"] = (
        (comparison["g"] == cohort) & (comparison["time"] >= cohort)
    ).astype(float)

    unit_fe = pd.get_dummies(comparison["id"], drop_first=True, dtype=float)
    time_fe = pd.get_dummies(comparison["time"], drop_first=True, dtype=float)
    design = np.column_stack(
        [
            np.ones(len(comparison)),
            comparison["did"].to_numpy(dtype=float),
            unit_fe.to_numpy(dtype=float),
            time_fe.to_numpy(dtype=float),
        ]
    )
    coefficient = np.linalg.lstsq(
        design, comparison["y"].to_numpy(dtype=float), rcond=None
    )[0][1]

    treated_count = comparison.loc[
        comparison["g"] == cohort, "id"
    ].nunique()
    row_count = len(comparison)

    estimates.append(
        {
            "term": f"att_g{cohort}",
            "estimate": float(coefficient),
            "se": None,
            "n_obs": int(row_count),
        }
    )
    treated_counts.append(treated_count)
    row_counts.append(row_count)

weighted_estimate = float(
    np.average(
        [row["estimate"] for row in estimates],
        weights=treated_counts,
    )
)

estimates.append(
    {
        "term": "att_weighted",
        "estimate": weighted_estimate,
        "se": None,
        "n_obs": int(sum(row_counts)),
    }
)

result = {
    "task_id": "broad_cohort_stack",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {},
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
