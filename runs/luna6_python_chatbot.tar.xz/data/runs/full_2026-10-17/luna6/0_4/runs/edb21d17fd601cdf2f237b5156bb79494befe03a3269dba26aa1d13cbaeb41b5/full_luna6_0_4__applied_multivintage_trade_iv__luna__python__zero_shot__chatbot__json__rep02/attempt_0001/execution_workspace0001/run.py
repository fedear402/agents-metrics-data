import json
import numpy as np
import pandas as pd

crosswalk = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv")
areas = pd.read_csv("areas.csv")
employment = pd.read_csv("employment.csv")
outcomes = pd.read_csv("outcomes.csv")

trade = trade.merge(crosswalk, on="code", how="inner", validate="many_to_one")

# Fill omitted area-industry cells with zero after constructing the full
# area-period-vintage-industry grid.
industries = crosswalk["industry"].drop_duplicates().tolist()
grid = areas[["area", "period", "vintage"]].drop_duplicates().merge(
    pd.DataFrame({"industry": industries}), how="cross"
)
emp = grid.merge(
    employment,
    on=["area", "period", "vintage", "industry"],
    how="left",
    validate="one_to_one",
)
emp["employment"] = emp["employment"].fillna(0.0)

# National industry employment is summed across every supplied area.
national = (
    emp.groupby(["period", "vintage", "industry"], as_index=False)["employment"]
    .sum()
    .rename(columns={"employment": "national_employment"})
)

def make_exposure(area_vintage, trade_change):
    area_emp = emp.loc[emp["vintage"].eq(area_vintage)].merge(
        areas.loc[areas["vintage"].eq(area_vintage),
                  ["area", "period", "vintage", "total_employment"]],
        on=["area", "period", "vintage"],
        how="left",
        validate="many_to_one",
    )
    frame = (
        area_emp.merge(national, on=["period", "vintage", "industry"], validate="many_to_one")
        .merge(trade[["period", "industry", trade_change, "price_index", "years"]],
               on=["period", "industry"], how="inner", validate="many_to_one")
    )
    frame["component"] = (
        (frame["employment"] / frame["total_employment"])
        * (frame[trade_change] / frame["national_employment"])
        / (frame["price_index"] / 100.0)
        / 1000.0
        * (10.0 / frame["years"])
    )
    return frame.groupby(["area", "period"], as_index=False)["component"].sum()

x = make_exposure("base", "us_change").rename(columns={"component": "x"})
z = make_exposure("early", "other_change").rename(columns={"component": "z"})

reg = (
    outcomes.merge(x, on=["area", "period"], validate="one_to_one")
    .merge(z, on=["area", "period"], validate="one_to_one")
    .merge(
        areas.loc[areas["vintage"].eq("base"),
                  ["area", "period", "population"]],
        on=["area", "period"],
        validate="one_to_one",
    )
)

period_values = sorted(reg["period"].unique())
if len(period_values) != 2:
    raise ValueError("Expected exactly two periods.")
reg["period_indicator"] = reg["period"].eq(period_values[1]).astype(float)

# Weighted 2SLS: regress the weighted outcome and regressors on the weighted
# instrument matrix, then solve the resulting IV normal equations.
y = reg["change_pp"].to_numpy(dtype=float)
X = np.column_stack([
    np.ones(len(reg)),
    reg["period_indicator"].to_numpy(dtype=float),
    reg["control"].to_numpy(dtype=float),
    reg["x"].to_numpy(dtype=float),
])
Z = np.column_stack([
    np.ones(len(reg)),
    reg["period_indicator"].to_numpy(dtype=float),
    reg["control"].to_numpy(dtype=float),
    reg["z"].to_numpy(dtype=float),
])
w = reg["population"].to_numpy(dtype=float)
sqrt_w = np.sqrt(w)
Xw = X * sqrt_w[:, None]
Zw = Z * sqrt_w[:, None]
yw = y * sqrt_w

beta = np.linalg.solve(Zw.T @ Xw, Zw.T @ yw)
iv_slope = float(beta[3])

def lookup(frame, column, area, period):
    value = frame.loc[(frame["area"] == area) & (frame["period"] == period), column]
    if len(value) != 1:
        raise ValueError(f"Expected one {column} value for area={area}, period={period}.")
    return float(value.iloc[0])

area0 = sorted(reg["area"].unique())[0]
period0, period1 = period_values

estimates = [
    {"term": "iv_slope", "estimate": iv_slope, "se": None, "n_obs": 72},
    {"term": "exposure_area0_period0",
     "estimate": lookup(reg, "x", area0, period0), "se": None, "n_obs": 72},
    {"term": "exposure_area0_period1",
     "estimate": lookup(reg, "x", area0, period1), "se": None, "n_obs": 72},
    {"term": "instrument_area0_period0",
     "estimate": lookup(reg, "z", area0, period0), "se": None, "n_obs": 72},
]

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "weighted_two_stage_least_squares",
        "outcome": "change_pp",
        "regressors": ["intercept", "period", "control", "x"],
        "instruments": ["intercept", "period", "control", "z"],
        "weight": "base-vintage population",
        "exposure_units": "thousands of real dollars per worker per decade",
        "missing_area_industry_employment": "zero",
        "national_employment_denominator": "sum across all supplied areas by period, vintage, and industry",
    },
    "diagnostics": {
        "n_obs": 72,
        "n_industries": 4,
        "periods": [str(period0), str(period1)],
    },
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, allow_nan=False)
