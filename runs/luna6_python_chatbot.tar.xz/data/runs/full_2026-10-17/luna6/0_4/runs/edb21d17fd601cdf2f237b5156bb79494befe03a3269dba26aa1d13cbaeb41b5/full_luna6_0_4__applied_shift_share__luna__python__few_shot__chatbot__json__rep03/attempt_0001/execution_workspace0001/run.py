import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")

# Use one row per region for region-level variables and weights.
regions = df[["region_id", "region_weight", "x", "y"]].drop_duplicates("region_id")
e = regions["region_weight"].to_numpy(dtype=float)
e /= e.sum()

region_ids = regions["region_id"].to_numpy()
industry_ids = pd.Index(df["industry_id"].drop_duplicates())
region_index = pd.Index(region_ids)
industry_index = industry_ids

shares = (
    df.pivot(index="region_id", columns="industry_id", values="share")
    .reindex(index=region_index, columns=industry_index)
    .to_numpy(dtype=float)
)
shocks = (
    df[["industry_id", "shock"]]
    .drop_duplicates("industry_id")
    .set_index("industry_id")
    .reindex(industry_index)["shock"]
    .to_numpy(dtype=float)
)

x = regions["x"].to_numpy(dtype=float)
y = regions["y"].to_numpy(dtype=float)
z = shares @ shocks

def weighted_slope(dependent, endogenous, instrument, weights):
    dependent = dependent - np.sum(weights * dependent)
    endogenous = endogenous - np.sum(weights * endogenous)
    instrument = instrument - np.sum(weights * instrument)
    return np.sum(weights * instrument * dependent) / np.sum(weights * instrument * endogenous)

effect = weighted_slope(y, x, z, e)
first_stage = weighted_slope(x, z, z, e)

# Shock-level exposure masses and weighted residual aggregates.
mass = e @ shares
y0 = y - np.sum(e * y)
x0 = x - np.sum(e * x)
z0 = z - np.sum(e * z)

ybar = (shares.T @ (e * y0)) / mass
xbar = (shares.T @ (e * x0)) / mass
zbar = (shares.T @ (e * z0)) / mass

n_industries = len(industry_index)

def shock_iv_se(dependent, endogenous):
    # Weighted IV with an intercept, using industry shocks as the instrument.
    regressors = np.column_stack([np.ones(n_industries), endogenous])
    instruments = np.column_stack([np.ones(n_industries), shocks])
    cross = instruments.T @ (mass[:, None] * regressors)
    beta = np.linalg.solve(cross, instruments.T @ (mass * dependent))
    residual = dependent - regressors @ beta

    scores = instruments * (mass * residual)[:, None]
    inverse = np.linalg.inv(cross)
    hc1 = n_industries / (n_industries - 2)
    covariance = hc1 * inverse @ (scores.T @ scores) @ inverse.T
    return float(beta[1]), float(np.sqrt(covariance[1, 1]))

effect_shock, effect_se = shock_iv_se(ybar, xbar)
first_stage_shock, first_stage_se = shock_iv_se(xbar, zbar)

if not np.allclose([effect, first_stage], [effect_shock, first_stage_shock]):
    raise ValueError("Shock-level IV slopes do not match regional weighted slopes.")

output = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {
            "term": "effect",
            "estimate": effect,
            "se": effect_se,
            "n_obs": n_industries,
        },
        {
            "term": "first_stage",
            "estimate": first_stage,
            "se": first_stage_se,
            "n_obs": n_industries,
        },
        {
            "term": "effective_shocks",
            "estimate": float(1.0 / np.sum(mass**2)),
            "se": None,
            "n_obs": n_industries,
        },
    ],
    "method_metadata": {
        "estimator": "weighted regional 2SLS with Borusyak-Hull-Jaravel shock-level aggregation",
        "vcov": "shock-level HC1 using structural IV residuals and analytic exposure weights",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
