import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")

data = df.loc[df["score"].abs() < 1, ["score", "participated", "earnings"]].copy()
n_obs = int(len(data))

score = data["score"].to_numpy(dtype=float)
right = (score >= 0).astype(float)
weights = 1.0 - np.abs(score)

# Separate local-linear fits with side-specific intercepts and slopes.
design = np.column_stack([
    right,
    1.0 - right,
    right * score,
    (1.0 - right) * score,
])
sqrt_w = np.sqrt(weights)
weighted_design = design * sqrt_w[:, None]
bread = np.linalg.inv(weighted_design.T @ weighted_design)

outcomes = data[["earnings", "participated"]].to_numpy(dtype=float)
weighted_outcomes = outcomes * sqrt_w[:, None]
coef = bread @ weighted_design.T @ weighted_outcomes

# The right-limit minus left-limit discontinuity is the difference in intercepts.
contrast = np.array([1.0, -1.0, 0.0, 0.0])
discontinuities = contrast @ coef

# Joint HC0 covariance across both outcomes, using their same-observation residuals.
residuals = outcomes - design @ coef
scores_by_obs = design * (weights[:, None] * residuals)
meat = scores_by_obs.T @ scores_by_obs
joint_vcov = np.kron(np.eye(2), bread @ meat @ bread.T)

# Extract covariance matrix for the earnings and participation discontinuities.
contrast_both = np.kron(np.eye(2), contrast)
disc_vcov = contrast_both @ joint_vcov @ contrast_both.T

reduced_form = float(discontinuities[0])
first_stage = float(discontinuities[1])
treatment_effect = reduced_form / first_stage

# Delta-method variance for RF / FS, retaining their covariance.
gradient = np.array([1.0 / first_stage, -reduced_form / (first_stage ** 2)])
treatment_variance = float(gradient @ disc_vcov @ gradient)
reduced_form_se = float(np.sqrt(max(disc_vcov[0, 0], 0.0)))
first_stage_se = float(np.sqrt(max(disc_vcov[1, 1], 0.0)))
treatment_effect_se = float(np.sqrt(max(treatment_variance, 0.0)))

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {
            "term": "treatment_effect",
            "estimate": treatment_effect,
            "se": treatment_effect_se,
            "n_obs": n_obs,
        },
        {
            "term": "reduced_form",
            "estimate": reduced_form,
            "se": reduced_form_se,
            "n_obs": n_obs,
        },
        {
            "term": "first_stage",
            "estimate": first_stage,
            "se": first_stage_se,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "Fuzzy local-linear regression discontinuity; cutoff 0, bandwidth 1, triangular weights",
        "vcov": "HC0 sandwich; delta method with joint covariance of discontinuities",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, allow_nan=False)
