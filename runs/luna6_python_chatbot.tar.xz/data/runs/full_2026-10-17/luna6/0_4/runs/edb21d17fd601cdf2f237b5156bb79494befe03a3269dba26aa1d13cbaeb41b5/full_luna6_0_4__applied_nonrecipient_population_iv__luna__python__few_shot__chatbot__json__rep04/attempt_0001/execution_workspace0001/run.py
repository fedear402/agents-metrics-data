import json
import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS

households = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

d = households.loc[households["recipient"] == 0].copy()
n_obs = int(len(d))

eligible = d["eligible"].astype(float)
ineligible = 1.0 - eligible

exog = pd.DataFrame(
    {
        "ineligible": ineligible,
        "eligible": eligible,
        "baseline_ineligible": d["baseline"] * ineligible,
        "baseline_eligible": d["baseline"] * eligible,
    },
    index=d.index,
)
endog = pd.DataFrame(
    {
        "dose_ineligible": d["dose"] * ineligible,
        "dose_eligible": d["dose"] * eligible,
    },
    index=d.index,
)
instruments = exog.assign(
    instrument_ineligible=d["instrument"] * ineligible,
    instrument_eligible=d["instrument"] * eligible,
)

fit = IV2SLS(
    dependent=d["outcome"],
    exog=exog,
    endog=endog,
    instruments=instruments,
    weights=d["weight"],
).fit()

ineligible_slope = float(fit.params["dose_ineligible"])
eligible_slope = float(fit.params["dose_eligible"])

ineligible_rows = d["eligible"] == 0
eligible_rows = d["eligible"] == 1
ineligible_mean_dose = float(
    np.average(d.loc[ineligible_rows, "dose"], weights=d.loc[ineligible_rows, "weight"])
)
eligible_mean_dose = float(
    np.average(d.loc[eligible_rows, "dose"], weights=d.loc[eligible_rows, "weight"])
)

ineligible_effect = ineligible_slope * ineligible_mean_dose
eligible_nonrecipient_effect = eligible_slope * eligible_mean_dose

census_weights = census.set_index("eligible")["nonrecipient_population"]
group_weights = np.array(
    [census_weights.loc[0], census_weights.loc[1]], dtype=float
)
population_effect = float(
    np.average(
        [ineligible_effect, eligible_nonrecipient_effect],
        weights=group_weights,
    )
)

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "ineligible_effect",
            "estimate": float(ineligible_effect),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "eligible_nonrecipient_effect",
            "estimate": float(eligible_nonrecipient_effect),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "population_effect",
            "estimate": population_effect,
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "dependent_variable": "outcome",
        "sample": "all households with recipient == 0",
        "endogenous_columns": [
            "dose*(1-eligible)",
            "dose*eligible",
        ],
        "exogenous_columns": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
        ],
        "excluded_instruments": [
            "instrument*(1-eligible)",
            "instrument*eligible",
        ],
        "weight_column": "weight",
        "group_effect_formula": "fitted group dose slope times household-weighted mean dose among retained group observations",
        "population_aggregation_weights": "census nonrecipient_population by eligibility group",
        "counterfactual": "dose set to zero for every retained household; attribution is a stated synthetic convention",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "ineligible_n_obs": int(ineligible_rows.sum()),
        "eligible_nonrecipient_n_obs": int(eligible_rows.sum()),
        "ineligible_dose_slope": ineligible_slope,
        "eligible_dose_slope": eligible_slope,
        "ineligible_weighted_mean_dose": ineligible_mean_dose,
        "eligible_weighted_mean_dose": eligible_mean_dose,
        "ineligible_nonrecipient_population": int(census_weights.loc[0]),
        "eligible_nonrecipient_population": int(census_weights.loc[1]),
    },
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, allow_nan=False)
