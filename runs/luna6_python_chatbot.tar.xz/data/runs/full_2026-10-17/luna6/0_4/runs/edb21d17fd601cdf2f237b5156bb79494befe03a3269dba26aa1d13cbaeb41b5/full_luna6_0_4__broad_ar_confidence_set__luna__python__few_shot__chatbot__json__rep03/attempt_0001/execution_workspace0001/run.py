import json

import numpy as np
import pandas as pd
from scipy.stats import f

data = pd.read_csv("input.csv")
y = data["y"].to_numpy(dtype=float)
endog = data["endog"].to_numpy(dtype=float)
controls = np.column_stack([np.ones(len(data)), data["x"].to_numpy(dtype=float)])
excluded = data[["z1", "z2"]].to_numpy(dtype=float)
restricted = np.column_stack([controls, excluded])

n = len(data)
q = 2
df = n - restricted.shape[1]
critical = f.ppf(0.95, q, df)
k = q * critical / df


def residual(values, design):
    return values - design @ np.linalg.lstsq(design, values, rcond=None)[0]


ry = residual(y, controls)
rd = residual(endog, controls)
uy = residual(y, restricted)
ud = residual(endog, restricted)

# The inverted joint F test is equivalent to a quadratic inequality.
A = rd @ rd - (1.0 + k) * (ud @ ud)
B = -2.0 * (ry @ rd - (1.0 + k) * (uy @ ud))
C = ry @ ry - (1.0 + k) * (uy @ uy)

discriminant = B * B - 4.0 * A * C
if abs(A) < 1e-12 or discriminant < 0:
    raise ValueError("Expected two finite Anderson-Rubin boundaries.")

boundaries = np.sort(np.roots([A, B, C]).real)


def accepts(beta):
    return A * beta * beta + B * beta + C <= 0.0


def ar_f(beta):
    response = y - beta * endog
    r = residual(response, controls)
    u = residual(response, restricted)
    return ((r @ r - u @ u) / q) / ((u @ u) / df)


rows = [
    {"term": "boundary_low", "estimate": float(boundaries[0]), "se": None, "n_obs": n},
    {"term": "boundary_high", "estimate": float(boundaries[1]), "se": None, "n_obs": n},
    {"term": "accepts_zero", "estimate": int(accepts(0.0)), "se": None, "n_obs": n},
    {"term": "unbounded", "estimate": int(A < 0.0), "se": None, "n_obs": n},
    {"term": "ar_f_at_one", "estimate": float(ar_f(1.0)), "se": None, "n_obs": n},
]

with open("result.json", "w") as stream:
    json.dump(
        {
            "task_id": "broad_ar_confidence_set",
            "platform": "python",
            "estimates": rows,
            "method_metadata": {
                "estimator": "Anderson-Rubin confidence set via homoskedastic joint F inversion",
                "vcov": "conventional homoskedastic",
            },
            "diagnostics": {},
        },
        stream,
        indent=2,
        allow_nan=False,
    )
