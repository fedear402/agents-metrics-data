import json

import numpy as np
import pandas as pd


households = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

data = households.loc[households["recipient"] == 0].copy()
eligible = data["eligible"].to_numpy(dtype=float)
ineligible = 1.0 - eligible
dose = data["dose"].to_numpy(dtype=float)
instrument = data["instrument"].to_numpy(dtype=float)
baseline = data["baseline"].to_numpy(dtype=float)
weight = data["weight"].to_numpy(dtype=float)
outcome = data["outcome"].to_numpy(dtype=float)

# Regressors: four exogenous columns and two endogenous dose interactions.
exogenous = np.column_stack(
    [
        ineligible,
        eligible,
        baseline * ineligible,
        baseline * eligible,
    ]
)
endogenous = np.column_stack([dose * ineligible, dose * eligible])
x = np.column_stack([exogenous, endogenous])

# Instruments: the exogenous columns plus the two excluded interactions.
z = np.column_stack(
    [
        exogenous,
        instrument * ineligible,
        instrument * eligible,
    ]
)

# Weighted 2SLS: solve the weighted instrument projection, then the
# weighted structural normal equations.
sqrt_weight = np.sqrt(weight)
zw = z * sqrt_weight[:, None]
xw = x * sqrt_weight[:, None]
yw = outcome * sqrt_weight

projection_coefficients = np.linalg.lstsq(zw, xw, rcond=None)[0]
projected_xw = zw @ projection_coefficients
beta = np.linalg.lstsq(projected_xw.T @ xw, projected_xw.T @ yw, rcond=None)[0]

slopes = beta[-2:]
group_effects = {}
for group, indicator, slope in [
    ("ineligible", ineligible, slopes[0]),
    ("eligible_nonrecipient", eligible, slopes[1]),
]:
    group_weight = weight * indicator
    weighted_mean_dose = np.sum(group_weight * dose) / np.sum(group_weight)
    group_effects[group] = float(slope * weighted_mean_dose)

population = census.set_index("eligible")["nonrecipient_population"]
population_ineligible = float(population.loc[0])
population_eligible = float(population.loc[1])
population_effect = (
    population_ineligible * group_effects["ineligible"]
    + population_eligible * group_effects["eligible_nonrecipient"]
) / (population_ineligible + population_eligible)

n_obs = int(len(data))
result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "ineligible_effect",
            "estimate": group_effects["ineligible"],
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "eligible_nonrecipient_effect",
            "estimate": group_effects["eligible_nonrecipient"],
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "population_effect",
            "estimate": float(population_effect),
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "sample": "all household rows with recipient=0",
        "counterfactual": "dose set to zero for every retained household; attribution is a stated synthetic convention",
        "regressors": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
            "dose*(1-eligible)",
            "dose*eligible",
        ],
        "instruments": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
            "instrument*(1-eligible)",
            "instrument*eligible",
        ],
        "weight_column": "weight",
        "group_effect": "fitted dose slope times household-weighted mean dose among retained observations in that group",
        "population_aggregation": "weighted by nonrecipient_population from census.csv",
        "census_use": "final between-group aggregation only",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "retained_households": n_obs,
        "ineligible_retained_rows": int(np.sum(ineligible)),
        "eligible_nonrecipient_retained_rows": int(np.sum(eligible)),
    },
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file, indent=2, allow_nan=False)
