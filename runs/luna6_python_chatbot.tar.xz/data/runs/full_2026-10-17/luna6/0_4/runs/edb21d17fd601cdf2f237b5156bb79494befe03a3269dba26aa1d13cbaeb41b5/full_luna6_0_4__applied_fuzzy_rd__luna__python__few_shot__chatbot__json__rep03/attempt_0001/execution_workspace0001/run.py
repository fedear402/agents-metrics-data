import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
sample = df.loc[df["score"].abs() < 1].copy()

score = sample["score"].to_numpy(dtype=float)
right = (score >= 0).astype(float)
weights = 1.0 - np.abs(score)

# Separate local-linear slopes with side-specific intercepts.
X = np.column_stack([
    1.0 - right,
    (1.0 - right) * score,
    right,
    right * score,
])
bread = np.linalg.inv(X.T @ (weights[:, None] * X))
contrast = np.array([-1.0, 0.0, 1.0, 0.0])

outcomes = sample[["earnings", "participated"]].to_numpy(dtype=float)
coefficients = bread @ X.T @ (weights[:, None] * outcomes)
residuals = outcomes - X @ coefficients

jumps = contrast @ coefficients
loading = weights * (X @ bread @ contrast)
influence = loading[:, None] * residuals
joint_covariance = influence.T @ influence

reduced_form, first_stage = jumps
treatment_effect = reduced_form / first_stage
gradient = np.array([
    1.0 / first_stage,
    -reduced_form / (first_stage ** 2),
])
treatment_effect_se = np.sqrt(gradient @ joint_covariance @ gradient)

n_obs = int(len(sample))
estimates = [
    {
        "term": "treatment_effect",
        "estimate": float(treatment_effect),
        "se": float(treatment_effect_se),
        "n_obs": n_obs,
    },
    {
        "term": "reduced_form",
        "estimate": float(reduced_form),
        "se": float(np.sqrt(joint_covariance[0, 0])),
        "n_obs": n_obs,
    },
    {
        "term": "first_stage",
        "estimate": float(first_stage),
        "se": float(np.sqrt(joint_covariance[1, 1])),
        "n_obs": n_obs,
    },
]

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "triangular_weighted_local_linear_fuzzy_regression_discontinuity",
        "vcov": "heteroskedasticity_robust_HC0",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
