import json
import numpy as np
import pandas as pd
from scipy.stats import f

data = pd.read_csv("input.csv")
y = data["y"].to_numpy(dtype=float)
endog = data["endog"].to_numpy(dtype=float)
controls = np.column_stack([np.ones(len(data)), data["x"].to_numpy(dtype=float)])
instruments = np.column_stack([
    controls,
    data["z1"].to_numpy(dtype=float),
    data["z2"].to_numpy(dtype=float),
])

n = len(data)
q = 2
df = n - 4
critical = f.ppf(0.95, q, df)

def residual(values, design):
    return values - design @ np.linalg.lstsq(design, values, rcond=None)[0]

ry = residual(y, controls)
rd = residual(endog, controls)
uy = residual(y, instruments)
ud = residual(endog, instruments)

k = q * critical / df
A = rd @ rd - (1 + k) * (ud @ ud)
B = -2 * (ry @ rd - (1 + k) * (uy @ ud))
C = ry @ ry - (1 + k) * (uy @ uy)

discriminant = B * B - 4 * A * C
if abs(A) < 1e-12 or discriminant < 0:
    raise ValueError("The Anderson-Rubin set does not have two finite boundary points.")

roots = np.sort(np.roots([A, B, C]).real)
boundary_low, boundary_high = roots
accepts_zero = int(C <= 0)
unbounded = int(A < 0)

def direct_f(beta):
    restricted = residual(y - beta * endog, controls)
    unrestricted = residual(y - beta * endog, instruments)
    ssr_r = restricted @ restricted
    ssr_u = unrestricted @ unrestricted
    return ((ssr_r - ssr_u) / q) / (ssr_u / df)

rows = [
    {"term": "boundary_low", "estimate": float(boundary_low), "se": None, "n_obs": n},
    {"term": "boundary_high", "estimate": float(boundary_high), "se": None, "n_obs": n},
    {"term": "accepts_zero", "estimate": accepts_zero, "se": None, "n_obs": n},
    {"term": "unbounded", "estimate": unbounded, "se": None, "n_obs": n},
    {"term": "ar_f_at_one", "estimate": float(direct_f(1.0)), "se": None, "n_obs": n},
]

with open("result.json", "w") as stream:
    json.dump(
        {
            "task_id": "broad_ar_confidence_set",
            "platform": "python",
            "estimates": rows,
            "method_metadata": {
                "estimator": "Anderson-Rubin confidence set inversion",
                "vcov": "conventional homoskedastic joint F test",
            },
            "diagnostics": {},
        },
        stream,
        indent=2,
        allow_nan=False,
    )
