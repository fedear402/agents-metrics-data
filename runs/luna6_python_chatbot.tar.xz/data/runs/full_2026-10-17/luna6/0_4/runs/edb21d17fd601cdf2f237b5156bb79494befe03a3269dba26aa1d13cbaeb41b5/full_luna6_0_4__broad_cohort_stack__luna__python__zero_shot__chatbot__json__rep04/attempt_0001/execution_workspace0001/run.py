import json
import pandas as pd
from linearmodels.panel import PanelOLS

df = pd.read_csv("./input.csv")
estimates = []
weighted_sum = 0.0
treated_weights = 0

for cohort in (3, 5, 7):
    window = list(range(cohort - 2, cohort + 3))
    eligible = df[
        df["g"].eq(cohort)
        | df["g"].eq(0)
        | df["g"].gt(cohort + 2)
    ]
    sample = eligible[eligible["time"].isin(window)].copy()

    complete_ids = (
        sample.groupby("id")["time"]
        .nunique()
        .loc[lambda counts: counts.eq(5)]
        .index
    )
    sample = sample[sample["id"].isin(complete_ids)].copy()
    sample["did"] = (
        sample["g"].eq(cohort) & sample["time"].ge(cohort)
    ).astype(int)

    panel = sample.set_index(["id", "time"])
    result = PanelOLS(
        panel["y"],
        panel[["did"]],
        entity_effects=True,
        time_effects=True,
    ).fit()

    coefficient = float(result.params["did"])
    treated_count = int(sample.loc[sample["g"].eq(cohort), "id"].nunique())
    estimates.append({
        "term": f"att_g{cohort}",
        "estimate": coefficient,
        "se": None,
        "n_obs": int(len(sample)),
    })
    weighted_sum += coefficient * treated_count
    treated_weights += treated_count

estimates.append({
    "term": "att_weighted",
    "estimate": weighted_sum / treated_weights,
    "se": None,
    "n_obs": sum(row["n_obs"] for row in estimates),
})

with open("result.json", "w", encoding="utf-8") as output:
    json.dump({
        "task_id": "broad_cohort_stack",
        "platform": "python",
        "estimates": estimates,
        "method_metadata": {},
        "diagnostics": {},
    }, output, indent=2)
