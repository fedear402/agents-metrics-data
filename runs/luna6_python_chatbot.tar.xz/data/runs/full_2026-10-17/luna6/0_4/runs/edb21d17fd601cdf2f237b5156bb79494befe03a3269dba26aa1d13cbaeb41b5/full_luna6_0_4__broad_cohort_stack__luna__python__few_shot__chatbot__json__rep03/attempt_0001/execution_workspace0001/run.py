import json

import numpy as np
import pandas as pd

data = pd.read_csv("./input.csv")
results = []
treated_counts = []
row_counts = []

for cohort in (3, 5, 7):
    window = list(range(cohort - 2, cohort + 3))
    eligible = data[
        (data["g"] == cohort)
        | (data["g"] == 0)
        | (data["g"] > cohort + 2)
    ]
    eligible = eligible[eligible["time"].isin(window)]

    balanced_ids = eligible.groupby("id")["time"].nunique()
    retained_ids = balanced_ids[balanced_ids == len(window)].index
    comparison = eligible[eligible["id"].isin(retained_ids)].copy()

    comparison["did"] = (
        (comparison["g"] == cohort) & (comparison["time"] >= cohort)
    ).astype(float)

    design = pd.concat(
        [
            comparison[["did"]].reset_index(drop=True),
            pd.get_dummies(comparison["id"], drop_first=True, dtype=float).reset_index(drop=True),
            pd.get_dummies(comparison["time"], drop_first=True, dtype=float).reset_index(drop=True),
        ],
        axis=1,
    )
    design.insert(0, "intercept", 1.0)

    coefficient = np.linalg.lstsq(
        design.to_numpy(dtype=float),
        comparison["y"].to_numpy(dtype=float),
        rcond=None,
    )[0][1]

    n_obs = len(comparison)
    treated_count = comparison.loc[comparison["g"] == cohort, "id"].nunique()
    results.append((f"att_g{cohort}", float(coefficient), n_obs))
    treated_counts.append(treated_count)
    row_counts.append(n_obs)

weighted_estimate = sum(
    estimate * treated_count
    for (_, estimate, _), treated_count in zip(results, treated_counts)
) / sum(treated_counts)

estimates = [
    {
        "term": term,
        "estimate": estimate,
        "se": None,
        "n_obs": n_obs,
    }
    for term, estimate, n_obs in results
]
estimates.append(
    {
        "term": "att_weighted",
        "estimate": float(weighted_estimate),
        "se": None,
        "n_obs": int(sum(row_counts)),
    }
)

output = {
    "task_id": "broad_cohort_stack",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {},
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
