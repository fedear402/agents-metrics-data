import json

import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy.special import softmax

data = pd.read_csv("input.csv")
n_obs = len(data)

outcomes = [0, 1, 2]
y = data["y"].astype(int)
if not np.array_equal(np.sort(y.unique()), outcomes):
    raise ValueError("y must contain outcomes 0, 1, and 2.")

X = sm.add_constant(data[["x", "z"]], has_constant="add")
fit = sm.MNLogit(y, X).fit(method="newton", disp=False, tol=1e-12, maxiter=200)

# MNLogit parameter columns enumerate nonbase outcomes in ascending order.
nonbase = [1, 2]
params = fit.params.copy()
bse = fit.bse.copy()
params.columns = nonbase
bse.columns = nonbase

probability_cat2_zero = float(
    softmax(
        np.array(
            [
                0.0,
                params.loc["const", 1],
                params.loc["const", 2],
            ],
            dtype=float,
        )
    )[2]
)

rows = [
    {"term": "x_cat1", "estimate": float(params.loc["x", 1]), "se": float(bse.loc["x", 1]), "n_obs": n_obs},
    {"term": "z_cat1", "estimate": float(params.loc["z", 1]), "se": float(bse.loc["z", 1]), "n_obs": n_obs},
    {"term": "x_cat2", "estimate": float(params.loc["x", 2]), "se": float(bse.loc["x", 2]), "n_obs": n_obs},
    {"term": "z_cat2", "estimate": float(params.loc["z", 2]), "se": float(bse.loc["z", 2]), "n_obs": n_obs},
    {"term": "prob_cat2_zero", "estimate": probability_cat2_zero, "se": None, "n_obs": n_obs},
]

result = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": rows,
    "method_metadata": {
        "estimator": "multinomial logit maximum likelihood",
        "vcov": "conventional observed-information",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
