import json
import pandas as pd
import statsmodels.api as sm

data = pd.read_csv("input.csv")

# Collapse repeated regional values and normalize regional weights once per region.
regions = data[
    ["region_id", "region_weight", "x", "y"]
].drop_duplicates("region_id").copy()
regions["e"] = regions["region_weight"] / regions["region_weight"].sum()

# Keep one row per region-industry pair, then construct regional exposure.
pairs = data[["region_id", "industry_id", "share", "shock"]].drop_duplicates(
    ["region_id", "industry_id"]
)
wide = pairs.pivot(index="region_id", columns="industry_id", values="share").fillna(0.0)
shock_by_industry = pairs.drop_duplicates("industry_id").set_index("industry_id")["shock"]
wide = wide.reindex(columns=shock_by_industry.index, fill_value=0.0)
z = wide.dot(shock_by_industry)

regions = regions.set_index("region_id")
regions["z"] = z.reindex(regions.index)

# Regional weighted first-stage slope.
first_stage_reg = sm.WLS(
    regions["x"], sm.add_constant(regions["z"]), weights=regions["e"]
).fit()
first_stage_estimate = float(first_stage_reg.params["z"])

# Remove regional weighted means.
for variable in ["y", "x", "z"]:
    regions[f"{variable}0"] = regions[variable] - (
        regions["e"] * regions[variable]
    ).sum()

# Shock-level exposure weights and residual aggregates.
shares = wide.reindex(index=regions.index).fillna(0.0)
weighted_shares = shares.mul(regions["e"], axis=0)
s = weighted_shares.sum(axis=0)
valid = s > 0
s = s[valid]
industries = s.index
shock = shock_by_industry.reindex(industries)

aggregates = {}
for variable in ["y", "x", "z"]:
    aggregates[variable] = (
        weighted_shares[industries]
        .mul(regions[f"{variable}0"], axis=0)
        .sum(axis=0)
        .div(s)
    )

shock_data = pd.DataFrame(
    {
        "s": s,
        "shock": shock,
        "ybar": aggregates["y"],
        "xbar": aggregates["x"],
        "zbar": aggregates["z"],
    }
).dropna()

n_industries = len(shock_data)

# Shock-level IV with analytic exposure weights and HC1 variance.
def shock_level_iv(outcome, endogenous):
    exog = sm.add_constant(shock_data[endogenous])
    instrument = sm.add_constant(shock_data["shock"])
    model = sm.WLS(
        shock_data[outcome], exog, weights=shock_data["s"]
    ).fit()
    first = sm.WLS(
        shock_data[endogenous], instrument, weights=shock_data["s"]
    ).fit()
    residual = shock_data[outcome] - model.predict(exog)
    # Equivalent to the one-endogenous-regressor IV sandwich using the
    # structural residual and the shock as the excluded instrument.
    w = shock_data["s"].to_numpy()
    q = shock_data["shock"].to_numpy()
    x_end = shock_data[endogenous].to_numpy()
    xmat = sm.add_constant(x_end)
    zmat = sm.add_constant(q)
    wmat = w[:, None]
    bread = __import__("numpy").linalg.inv(xmat.T @ (wmat * zmat))
    score = zmat * (w * residual.to_numpy())[:, None]
    meat = score.T @ score
    cov = bread @ meat @ bread.T
    cov *= n_industries / (n_industries - 2)
    return float(model.params[endogenous]), float(__import__("numpy").sqrt(cov[1, 1]))

effect_estimate, effect_se = shock_level_iv("ybar", "xbar")

# For the exposure-robust first-stage SE, IV-regress xbar on zbar,
# instrumenting zbar with the industry shock.
first_stage_iv_estimate, first_stage_se = shock_level_iv("xbar", "zbar")

effective_shocks = float(1.0 / (shock_data["s"] ** 2).sum())

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {
            "term": "effect",
            "estimate": effect_estimate,
            "se": effect_se,
            "n_obs": n_industries,
        },
        {
            "term": "first_stage",
            "estimate": first_stage_estimate,
            "se": first_stage_se,
            "n_obs": n_industries,
        },
        {
            "term": "effective_shocks",
            "estimate": effective_shocks,
            "se": None,
            "n_obs": n_industries,
        },
    ],
    "method_metadata": {
        "estimator": "Weighted 2SLS with region weights normalized once per region; BHJ shock-level IV",
        "vcov": "Shock-level heteroskedasticity-robust HC1, analytic exposure weights, no clustering",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output_file:
    json.dump(result, output_file, ensure_ascii=False, indent=2)
