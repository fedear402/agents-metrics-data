import json

import numpy as np
import pandas as pd
from scipy.stats import f
import statsmodels.api as sm

data = pd.read_csv("input.csv")
y = data["y"].to_numpy(dtype=float)
endog = data["endog"].to_numpy(dtype=float)
x = data["x"].to_numpy(dtype=float)
z1 = data["z1"].to_numpy(dtype=float)
z2 = data["z2"].to_numpy(dtype=float)

n_obs = len(data)
critical = f.ppf(0.95, 2, n_obs - 4)

# The unrestricted regression has intercept, x, z1, and z2.
design = sm.add_constant(np.column_stack((x, z1, z2)), has_constant="add")
restricted_cols = [0, 1]  # intercept and x
excluded_cols = [2, 3]    # z1 and z2

def ar_f(beta):
    model = sm.OLS(y - beta * endog, design).fit()
    return float(model.f_test(
        (np.eye(design.shape[1])[excluded_cols]).tolist()
    ).fvalue)

# The conventional joint F statistic is a quadratic in beta. Evaluate it at
# three points to recover that quadratic and solve F(beta) = critical exactly.
f0 = ar_f(0.0)
fp = ar_f(1.0)
fm = ar_f(-1.0)
a = (fp + fm - 2.0 * f0) / 2.0
b = (fp - fm) / 2.0
c = f0 - critical

roots = np.roots([a, b, c])
real_roots = sorted(float(root.real) for root in roots if abs(root.imag) < 1e-8)
if len(real_roots) != 2:
    raise RuntimeError("Expected two finite Anderson-Rubin boundary points.")

boundary_low, boundary_high = real_roots
accepts_zero = int(f0 <= critical)
unbounded = int(a <= 0.0)

estimates = [
    {"term": "boundary_low", "estimate": boundary_low, "se": None, "n_obs": n_obs},
    {"term": "boundary_high", "estimate": boundary_high, "se": None, "n_obs": n_obs},
    {"term": "accepts_zero", "estimate": float(accepts_zero), "se": None, "n_obs": n_obs},
    {"term": "unbounded", "estimate": float(unbounded), "se": None, "n_obs": n_obs},
    {"term": "ar_f_at_one", "estimate": fp, "se": None, "n_obs": n_obs},
]

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "Anderson-Rubin confidence set by inversion of conventional homoskedastic joint F test",
        "vcov": "conventional homoskedastic"
    },
    "diagnostics": {}
}

with open("result.json", "w", encoding="utf-8") as output_file:
    json.dump(result, output_file, indent=2)
