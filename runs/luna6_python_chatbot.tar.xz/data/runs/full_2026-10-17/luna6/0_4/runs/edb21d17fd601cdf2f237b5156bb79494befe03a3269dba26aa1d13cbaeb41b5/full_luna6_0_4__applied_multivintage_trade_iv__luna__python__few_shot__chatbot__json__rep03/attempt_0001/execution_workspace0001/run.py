import json
from pathlib import Path

import pandas as pd
from linearmodels.iv import IV2SLS

# Read and combine all supplied data files.
crosswalk = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv")
areas = pd.read_csv("areas.csv")
employment = pd.read_csv("employment.csv")
outcomes = pd.read_csv("outcomes.csv")

trade = trade.merge(crosswalk, on="code", how="inner", validate="many_to_one")

# Add omitted area-industry cells as zero, then calculate national employment
# separately for each period, vintage, and industry.
employment = employment.merge(
    areas[["area", "period", "vintage", "total_employment"]],
    on=["area", "period", "vintage"],
    how="inner",
    validate="many_to_one",
)
area_period_vintages = areas[["area", "period", "vintage"]].drop_duplicates()
industries = crosswalk[["industry"]].drop_duplicates()
grid = area_period_vintages.merge(industries, how="cross")
employment = grid.merge(
    employment[
        ["area", "period", "vintage", "industry", "employment", "total_employment"]
    ],
    on=["area", "period", "vintage", "industry"],
    how="left",
    validate="one_to_one",
)
employment["employment"] = employment["employment"].fillna(0.0)

national = (
    employment.groupby(["period", "vintage", "industry"], as_index=False)["employment"]
    .sum()
    .rename(columns={"employment": "national_employment"})
)
employment = employment.merge(
    national,
    on=["period", "vintage", "industry"],
    how="left",
    validate="many_to_one",
)

# Attach each period's trade shocks and calculate base and early exposures.
period_data = employment.merge(
    trade[["period", "industry", "us_change", "other_change", "price_index", "years"]],
    on=["period", "industry"],
    how="inner",
    validate="many_to_one",
)
period_data["base_term"] = (
    period_data["employment"]
    / period_data["total_employment"]
    * period_data["us_change"]
    / period_data["national_employment"].where(
        period_data["vintage"].eq("base")
    )
    / (period_data["price_index"] / 100.0)
    / 1000.0
    * (10.0 / period_data["years"])
)
period_data["early_term"] = (
    period_data["employment"]
    / period_data["total_employment"]
    * period_data["other_change"]
    / period_data["national_employment"].where(
        period_data["vintage"].eq("early")
    )
    / (period_data["price_index"] / 100.0)
    / 1000.0
    * (10.0 / period_data["years"])
)

# Denominators and employment shares use the corresponding vintage.
base = period_data.loc[period_data["vintage"].eq("base")].copy()
base["x_term"] = (
    base["employment"]
    / base["total_employment"]
    * base["us_change"]
    / base["national_employment"]
    / (base["price_index"] / 100.0)
    / 1000.0
    * (10.0 / base["years"])
)
early = period_data.loc[period_data["vintage"].eq("early")].copy()
early["z_term"] = (
    early["employment"]
    / early["total_employment"]
    * early["other_change"]
    / early["national_employment"]
    / (early["price_index"] / 100.0)
    / 1000.0
    * (10.0 / early["years"])
)

exposures = (
    base.groupby(["area", "period"], as_index=False)["x_term"]
    .sum()
    .rename(columns={"x_term": "x"})
    .merge(
        early.groupby(["area", "period"], as_index=False)["z_term"]
        .sum()
        .rename(columns={"z_term": "z"}),
        on=["area", "period"],
        how="inner",
        validate="one_to_one",
    )
)

# Build the 72 area-period estimation rows and fit weighted 2SLS.
data = outcomes.merge(
    exposures, on=["area", "period"], how="inner", validate="one_to_one"
).merge(
    areas.loc[areas["vintage"].eq("base"), ["area", "period", "population"]],
    on=["area", "period"],
    how="inner",
    validate="one_to_one",
)
data = data.sort_values(["area", "period"]).reset_index(drop=True)
data["intercept"] = 1.0

fit = IV2SLS(
    dependent=data["change_pp"],
    exog=data[["intercept", "period", "control"]],
    endog=data[["x"]],
    instruments=data[["z"]],
    weights=data["population"],
).fit()

area0 = data.loc[data["area"].eq(0)].set_index("period")
result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [
        {"term": "iv_slope", "estimate": float(fit.params["x"]), "se": None, "n_obs": 72},
        {
            "term": "exposure_area0_period0",
            "estimate": float(area0.loc[0, "x"]),
            "se": None,
            "n_obs": 72,
        },
        {
            "term": "exposure_area0_period1",
            "estimate": float(area0.loc[1, "x"]),
            "se": None,
            "n_obs": 72,
        },
        {
            "term": "instrument_area0_period0",
            "estimate": float(area0.loc[0, "z"]),
            "se": None,
            "n_obs": 72,
        },
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "dependent_variable": "change_pp",
        "endogenous_variable": "x",
        "excluded_instrument": "z",
        "included_exogenous": ["intercept", "period", "control"],
        "included_exogenous_instruments": ["intercept", "period", "control"],
        "weight": "base-vintage population",
        "exposure_units": "thousands of real dollars per worker per decade",
    },
    "diagnostics": {"n_obs": 72},
}

with Path("result.json").open("w", encoding="utf-8") as file:
    json.dump(result, file, indent=2)
