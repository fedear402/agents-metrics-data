import csv
import json
from collections import defaultdict

import numpy as np


def read_csv(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


crosswalk_rows = read_csv("crosswalk.csv")
trade_rows = read_csv("trade.csv")
area_rows = read_csv("areas.csv")
employment_rows = read_csv("employment.csv")
outcome_rows = read_csv("outcomes.csv")

industry_by_code = {row["code"]: row["industry"] for row in crosswalk_rows}

trade = {}
for row in trade_rows:
    period = row["period"]
    trade[(period, row["code"])] = {
        "us_change": float(row["us_change"]),
        "other_change": float(row["other_change"]),
        "price_index": float(row["price_index"]),
        "years": float(row["years"]),
    }

area_data = {}
for row in area_rows:
    area_data[(row["area"], row["period"], row["vintage"])] = row
    if row["vintage"] == "base":
        area_data[(row["area"], row["period"], "population")] = float(row["population"])

employment = defaultdict(float)
for row in employment_rows:
    employment[(row["area"], row["period"], row["vintage"], row["industry"])] += float(
        row["employment"]
    )

periods = sorted({row["period"] for row in area_rows})
areas = sorted({row["area"] for row in area_rows}, key=lambda value: int(value))
industries = sorted(set(industry_by_code.values()))

national = defaultdict(float)
for area in areas:
    for period in periods:
        for industry in industries:
            for vintage in ("base", "early"):
                national[(period, vintage, industry)] += employment[
                    (area, period, vintage, industry)
                ]

trade_by_industry = {}
for (period, code), row in trade.items():
    industry = industry_by_code[code]
    trade_by_industry[(period, industry)] = row

exposure = {}
instrument = {}
for area in areas:
    for period in periods:
        base_row = area_data[(area, period, "base")]
        early_row = area_data[(area, period, "early")]
        base_total = float(base_row["total_employment"])
        early_total = float(early_row["total_employment"])
        x = 0.0
        z = 0.0

        for industry in industries:
            trade_row = trade_by_industry[(period, industry)]
            price_factor = trade_row["price_index"] / 100.0
            scale = (10.0 / trade_row["years"]) / 1000.0

            base_share = employment[(area, period, "base", industry)] / base_total
            base_national = national[(period, "base", industry)]
            x += (
                base_share
                * (trade_row["us_change"] / base_national)
                / price_factor
                * scale
            )

            early_share = employment[(area, period, "early", industry)] / early_total
            early_national = national[(period, "early", industry)]
            z += (
                early_share
                * (trade_row["other_change"] / early_national)
                / price_factor
                * scale
            )

        exposure[(area, period)] = x
        instrument[(area, period)] = z

outcomes = {
    (row["area"], row["period"]): {
        "control": float(row["control"]),
        "change_pp": float(row["change_pp"]),
    }
    for row in outcome_rows
}

rows = []
for area in areas:
    for period_index, period in enumerate(periods):
        outcome = outcomes[(area, period)]
        rows.append(
            {
                "area": area,
                "period": period,
                "period_indicator": float(period_index),
                "control": outcome["control"],
                "y": outcome["change_pp"],
                "x": exposure[(area, period)],
                "z": instrument[(area, period)],
                "weight": area_data[(area, period, "population")],
            }
        )

y = np.array([row["y"] for row in rows], dtype=float)
x_endogenous = np.array([row["x"] for row in rows], dtype=float)
z_excluded = np.array([row["z"] for row in rows], dtype=float)
weights = np.array([row["weight"] for row in rows], dtype=float)

# The structural regressors and instruments include the same exogenous columns.
exogenous = np.column_stack(
    [
        np.ones(len(rows)),
        np.array([row["period_indicator"] for row in rows], dtype=float),
        np.array([row["control"] for row in rows], dtype=float),
    ]
)
regressors = np.column_stack([exogenous, x_endogenous])
instruments = np.column_stack([exogenous, z_excluded])

sqrt_weights = np.sqrt(weights)
weighted_instruments = instruments * sqrt_weights[:, None]
weighted_regressors = regressors * sqrt_weights[:, None]
weighted_y = y * sqrt_weights

projection_coefficients = np.linalg.lstsq(
    weighted_instruments, weighted_regressors, rcond=None
)[0]
projected_regressors = instruments @ projection_coefficients
weighted_projected_regressors = projected_regressors * sqrt_weights[:, None]

iv_coefficients = np.linalg.lstsq(
    weighted_projected_regressors, weighted_y, rcond=None
)[0]

area0 = areas[0]
period0, period1 = periods[0], periods[1]

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [
        {"term": "iv_slope", "estimate": float(iv_coefficients[-1]), "se": None, "n_obs": 72},
        {
            "term": "exposure_area0_period0",
            "estimate": float(exposure[(area0, period0)]),
            "se": None,
            "n_obs": 72,
        },
        {
            "term": "exposure_area0_period1",
            "estimate": float(exposure[(area0, period1)]),
            "se": None,
            "n_obs": 72,
        },
        {
            "term": "instrument_area0_period0",
            "estimate": float(instrument[(area0, period0)]),
            "se": None,
            "n_obs": 72,
        },
    ],
    "method_metadata": {
        "estimator": "weighted_2sls",
        "outcome": "change_pp",
        "endogenous_regressor": "x",
        "excluded_instrument": "z",
        "exogenous_regressors": ["intercept", "period", "control"],
        "weights": "base_vintage_population",
        "exposure_units": "thousands_of_real_dollars_per_worker_per_decade",
        "periods": periods,
        "industries": industries,
    },
    "diagnostics": {
        "n_obs": 72,
        "n_areas": len(areas),
        "n_periods": len(periods),
        "n_industries": len(industries),
    },
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, allow_nan=False)
