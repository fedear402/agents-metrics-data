import json
import numpy as np
import pandas as pd

households = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

data = households.loc[households["recipient"] == 0].copy()
n_obs = int(len(data))

eligible = data["eligible"].to_numpy(dtype=float)
ineligible = 1.0 - eligible
dose = data["dose"].to_numpy(dtype=float)
instrument = data["instrument"].to_numpy(dtype=float)
baseline = data["baseline"].to_numpy(dtype=float)
weight = data["weight"].to_numpy(dtype=float)
outcome = data["outcome"].to_numpy(dtype=float)

# The structural regressors include the two eligibility-group dose slopes.
endogenous = np.column_stack((dose * ineligible, dose * eligible))
exogenous = np.column_stack(
    (ineligible, eligible, baseline * ineligible, baseline * eligible)
)
instruments = np.column_stack(
    (
        exogenous,
        instrument * ineligible,
        instrument * eligible,
    )
)
regressors = np.column_stack((exogenous, endogenous))

sqrt_weight = np.sqrt(weight)
xw = regressors * sqrt_weight[:, None]
yw = outcome * sqrt_weight
zw = instruments * sqrt_weight[:, None]

# Weighted 2SLS: project all structural regressors on the full instrument set.
projection_coef = np.linalg.lstsq(zw, xw, rcond=None)[0]
xhat = zw @ projection_coef
beta = np.linalg.lstsq(xw.T @ xhat, xw.T @ yw, rcond=None)[0]

ineligible_slope = float(beta[4])
eligible_slope = float(beta[5])

def weighted_mean(values, weights):
    return float(np.sum(values * weights) / np.sum(weights))

ineligible_mask = eligible == 0
eligible_mask = eligible == 1

ineligible_mean_dose = weighted_mean(dose[ineligible_mask], weight[ineligible_mask])
eligible_mean_dose = weighted_mean(dose[eligible_mask], weight[eligible_mask])

ineligible_effect = ineligible_slope * ineligible_mean_dose
eligible_nonrecipient_effect = eligible_slope * eligible_mean_dose

population = census.groupby("eligible")["nonrecipient_population"].sum()
ineligible_population = float(population.loc[0])
eligible_population = float(population.loc[1])
population_effect = (
    ineligible_effect * ineligible_population
    + eligible_nonrecipient_effect * eligible_population
) / (ineligible_population + eligible_population)

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "ineligible_effect",
            "estimate": float(ineligible_effect),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "eligible_nonrecipient_effect",
            "estimate": float(eligible_nonrecipient_effect),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "population_effect",
            "estimate": float(population_effect),
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "sample": "all household rows with recipient=0",
        "endogenous_columns": [
            "dose*(1-eligible)",
            "dose*eligible",
        ],
        "exogenous_columns": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
        ],
        "instrument_columns": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
            "instrument*(1-eligible)",
            "instrument*eligible",
        ],
        "regression_weight": "weight",
        "within_group_dose_average_weight": "weight",
        "counterfactual": "dose is set to zero for every retained household",
        "attribution_convention": (
            "The fitted dose slope times the weighted mean dose is attributed "
            "to the zero-dose counterfactual as a synthetic convention."
        ),
        "population_aggregation_weight": "census nonrecipient_population",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "ineligible_n_obs": int(np.sum(ineligible_mask)),
        "eligible_n_obs": int(np.sum(eligible_mask)),
        "ineligible_weighted_mean_dose": ineligible_mean_dose,
        "eligible_weighted_mean_dose": eligible_mean_dose,
        "ineligible_dose_slope": ineligible_slope,
        "eligible_dose_slope": eligible_slope,
        "ineligible_nonrecipient_population": int(ineligible_population),
        "eligible_nonrecipient_population": int(eligible_population),
    },
}

with open("result.json", "w", encoding="utf-8") as output_file:
    json.dump(result, output_file, indent=2, allow_nan=False)
