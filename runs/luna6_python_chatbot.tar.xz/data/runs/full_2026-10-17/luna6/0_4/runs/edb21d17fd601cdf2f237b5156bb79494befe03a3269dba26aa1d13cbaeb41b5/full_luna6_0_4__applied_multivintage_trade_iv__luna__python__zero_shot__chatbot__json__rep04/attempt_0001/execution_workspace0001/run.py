import json
import numpy as np
import pandas as pd

crosswalk = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv")
areas = pd.read_csv("areas.csv")
employment = pd.read_csv("employment.csv")
outcomes = pd.read_csv("outcomes.csv")

trade = trade.merge(crosswalk, on="code", how="inner", validate="many_to_one")

# Each trade code maps to one industry, and each industry has one trade row
# within each period.
trade_industry = trade[
    ["period", "industry", "us_change", "other_change", "price_index", "years"]
].copy()

# Include omitted area-industry cells as zero employment.
area_industry = (
    areas[["area", "period", "vintage", "total_employment"]]
    .merge(
        employment[["area", "period", "vintage", "industry", "employment"]],
        on=["area", "period", "vintage"],
        how="left",
    )
)
area_industry["employment"] = area_industry["employment"].fillna(0.0)

# National denominators sum employment across all supplied areas by period,
# vintage, and industry.
national = (
    area_industry.groupby(["period", "vintage", "industry"], as_index=False)
    ["employment"].sum()
    .rename(columns={"employment": "national_employment"})
)

# Construct one exposure per area and period from the requested vintage and
# trade-change series.
exposure_parts = []
for vintage, change_column, result_column in [
    ("base", "us_change", "x"),
    ("early", "other_change", "z"),
]:
    cells = area_industry.loc[area_industry["vintage"] == vintage].merge(
        national.loc[national["vintage"] == vintage],
        on=["period", "vintage", "industry"],
        how="left",
        validate="many_to_one",
    )
    cells = cells.merge(
        trade_industry[["period", "industry", change_column, "price_index", "years"]],
        on=["period", "industry"],
        how="left",
        validate="many_to_one",
    )
    cells["component"] = (
        (cells["employment"] / cells["total_employment"])
        * (cells[change_column] / cells["national_employment"])
        / (cells["price_index"] / 100.0)
        / 1000.0
        * (10.0 / cells["years"])
    )
    exposure_parts.append(
        cells.groupby(["area", "period"], as_index=False)["component"]
        .sum()
        .rename(columns={"component": result_column})
    )

exposures = exposure_parts[0].merge(
    exposure_parts[1], on=["area", "period"], how="inner", validate="one_to_one"
)

# Use the base-vintage population as the regression weight.
base_population = (
    areas.loc[areas["vintage"] == "base", ["area", "period", "population"]]
    .drop_duplicates(["area", "period"])
)
data = (
    outcomes.merge(exposures, on=["area", "period"], how="inner", validate="one_to_one")
    .merge(base_population, on=["area", "period"], how="inner", validate="one_to_one")
)
data["period_indicator"] = (data["period"] == sorted(data["period"].unique())[1]).astype(float)

# Weighted 2SLS: regress each variable on the full instrument matrix using
# square-root population weights, then use the projected regressors in WLS.
y = data["change_pp"].to_numpy(dtype=float)
x_reg = np.column_stack(
    [
        np.ones(len(data)),
        data["period_indicator"].to_numpy(dtype=float),
        data["control"].to_numpy(dtype=float),
        data["x"].to_numpy(dtype=float),
    ]
)
z_inst = np.column_stack(
    [
        np.ones(len(data)),
        data["period_indicator"].to_numpy(dtype=float),
        data["control"].to_numpy(dtype=float),
        data["z"].to_numpy(dtype=float),
    ]
)
weights = data["population"].to_numpy(dtype=float)
sqrt_weights = np.sqrt(weights)

zw = z_inst * sqrt_weights[:, None]
xw = x_reg * sqrt_weights[:, None]
yw = y * sqrt_weights

projection_coefficients = np.linalg.lstsq(zw, xw, rcond=None)[0]
x_projected_weighted = zw @ projection_coefficients
iv_coefficients = np.linalg.lstsq(x_projected_weighted, yw, rcond=None)[0]

area0_period0 = exposures.loc[
    (exposures["area"] == 0) & (exposures["period"] == sorted(data["period"].unique())[0]),
    "x",
].iloc[0]
area0_period1 = exposures.loc[
    (exposures["area"] == 0) & (exposures["period"] == sorted(data["period"].unique())[1]),
    "x",
].iloc[0]
area0_instrument_period0 = exposures.loc[
    (exposures["area"] == 0) & (exposures["period"] == sorted(data["period"].unique())[0]),
    "z",
].iloc[0]

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [
        {"term": "iv_slope", "estimate": float(iv_coefficients[3]), "se": None, "n_obs": 72},
        {"term": "exposure_area0_period0", "estimate": float(area0_period0), "se": None, "n_obs": 72},
        {"term": "exposure_area0_period1", "estimate": float(area0_period1), "se": None, "n_obs": 72},
        {"term": "instrument_area0_period0", "estimate": float(area0_instrument_period0), "se": None, "n_obs": 72},
    ],
    "method_metadata": {
        "estimator": "weighted_two_stage_least_squares",
        "outcome": "change_pp",
        "endogenous_regressor": "x",
        "excluded_instrument": "z",
        "included_exogenous_regressors": ["intercept", "period_indicator", "control"],
        "instruments": ["intercept", "period_indicator", "control", "z"],
        "weight": "base_vintage_population",
        "exposure_units": "thousands of real dollars per worker per decade",
    },
    "diagnostics": {
        "n_obs": 72,
        "area_period_rows": int(len(data)),
        "industries": int(crosswalk["industry"].nunique()),
    },
}

with open("result.json", "w", encoding="utf-8") as output_file:
    json.dump(result, output_file, indent=2, allow_nan=False)
