import json
import numpy as np
import pandas as pd

households = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

# Keep every household that did not receive the transfer.
data = households.loc[households["recipient"] == 0].copy()
n_obs = int(len(data))

eligible = data["eligible"].to_numpy(dtype=float)
ineligible = 1.0 - eligible
dose = data["dose"].to_numpy(dtype=float)
instrument = data["instrument"].to_numpy(dtype=float)
baseline = data["baseline"].to_numpy(dtype=float)
weight = data["weight"].to_numpy(dtype=float)
outcome = data["outcome"].to_numpy(dtype=float)

# The four exogenous regressors include the group indicators. No extra
# intercept is included.
exogenous = np.column_stack(
    [
        ineligible,
        eligible,
        baseline * ineligible,
        baseline * eligible,
    ]
)
endogenous = np.column_stack([dose * ineligible, dose * eligible])
instruments = np.column_stack(
    [
        exogenous,
        instrument * ineligible,
        instrument * eligible,
    ]
)
regressors = np.column_stack([exogenous, endogenous])

# Weighted 2SLS: (X'WZ (Z'WZ)^-1 Z'WX)^-1 X'WZ (Z'WZ)^-1 Z'Wy.
sqrt_weight = np.sqrt(weight)
z_weighted = instruments * sqrt_weight[:, None]
x_weighted = regressors * sqrt_weight[:, None]
y_weighted = outcome * sqrt_weight

projection_rhs = np.linalg.solve(
    z_weighted.T @ z_weighted,
    z_weighted.T @ x_weighted,
)
projection_y = np.linalg.solve(
    z_weighted.T @ z_weighted,
    z_weighted.T @ y_weighted,
)
beta = np.linalg.solve(
    x_weighted.T @ z_weighted @ projection_rhs,
    x_weighted.T @ z_weighted @ projection_y,
)

ineligible_slope = float(beta[-2])
eligible_slope = float(beta[-1])

ineligible_rows = eligible == 0
eligible_rows = eligible == 1

ineligible_mean_dose = float(
    np.average(dose[ineligible_rows], weights=weight[ineligible_rows])
)
eligible_mean_dose = float(
    np.average(dose[eligible_rows], weights=weight[eligible_rows])
)

ineligible_effect = ineligible_slope * ineligible_mean_dose
eligible_nonrecipient_effect = eligible_slope * eligible_mean_dose

# Census counts are used only to aggregate the two within-group effects.
population = census.set_index("eligible")["nonrecipient_population"]
ineligible_population = float(population.loc[0])
eligible_population = float(population.loc[1])
population_effect = (
    ineligible_population * ineligible_effect
    + eligible_population * eligible_nonrecipient_effect
) / (ineligible_population + eligible_population)

estimates = [
    {
        "term": "ineligible_effect",
        "estimate": float(ineligible_effect),
        "se": None,
        "n_obs": n_obs,
    },
    {
        "term": "eligible_nonrecipient_effect",
        "estimate": float(eligible_nonrecipient_effect),
        "se": None,
        "n_obs": n_obs,
    },
    {
        "term": "population_effect",
        "estimate": float(population_effect),
        "se": None,
        "n_obs": n_obs,
    },
]

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "sample_rule": "recipient == 0",
        "endogenous_columns": [
            "dose*(1-eligible)",
            "dose*eligible",
        ],
        "exogenous_columns": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
        ],
        "instrument_columns": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
            "instrument*(1-eligible)",
            "instrument*eligible",
        ],
        "weight_column": "weight",
        "counterfactual": "Set dose to zero for every retained household; attribution is a stated synthetic convention.",
        "group_effect_rule": "Fitted dose slope multiplied by the household-weighted mean dose among retained observations in that eligibility group.",
        "population_aggregation": "Weighted by nonrecipient_population from census.csv; census totals are used only for final between-group weights.",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "ineligible_n_obs": int(ineligible_rows.sum()),
        "eligible_n_obs": int(eligible_rows.sum()),
    },
}

with open("result.json", "w", encoding="utf-8") as output_file:
    json.dump(result, output_file, indent=2, allow_nan=False)
