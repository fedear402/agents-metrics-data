import json

import numpy as np
import pandas as pd


def main():
    data = pd.read_csv("input.csv")
    sample = data.loc[data["score"].abs() < 1].copy()
    n_obs = int(len(sample))

    x = sample["score"].to_numpy(dtype=float)
    right = (x >= 0).astype(float)
    weights = 1.0 - np.abs(x)

    # Separate local-linear fits on each side, with an intercept per side.
    design = np.column_stack(
        [
            1.0 - right,
            (1.0 - right) * x,
            right,
            right * x,
        ]
    )
    weighted_design = design * np.sqrt(weights)[:, None]
    bread = np.linalg.inv(weighted_design.T @ weighted_design)

    def fit_discontinuity(outcome):
        y = sample[outcome].to_numpy(dtype=float)
        beta = bread @ (design.T @ (weights * y))
        residuals = y - design @ beta

        # HC0 covariance for weighted least squares, treating weights as fixed.
        score = design * (weights * residuals)[:, None]
        covariance = bread @ (score.T @ score) @ bread
        discontinuity = beta[2] - beta[0]
        contrast = np.array([-1.0, 0.0, 1.0, 0.0])
        variance = float(contrast @ covariance @ contrast)
        return float(discontinuity), variance, covariance

    reduced_form, var_rf, cov_rf = fit_discontinuity("earnings")
    first_stage, var_fs, cov_fs = fit_discontinuity("participated")

    treatment_effect = reduced_form / first_stage
    ratio_gradient = np.array(
        [1.0 / first_stage, -reduced_form / (first_stage**2)]
    )
    joint_cov = np.array(
        [
            [var_rf, cov_rf[0, 0] - cov_rf[0, 2] - cov_rf[2, 0] + cov_rf[2, 2]],
            [cov_rf[0, 0] - cov_rf[0, 2] - cov_rf[2, 0] + cov_rf[2, 2], var_fs],
        ]
    )
    # The off-diagonal is the HC0 covariance of the two discontinuities.
    cross_score = (
        design
        * (weights * (
            sample["earnings"].to_numpy(dtype=float) - design @ (
                bread @ (design.T @ (weights * sample["earnings"].to_numpy(dtype=float)))
            )
        ))
        .__mul__(
            weights * (
                sample["participated"].to_numpy(dtype=float) - design @ (
                    bread @ (design.T @ (weights * sample["participated"].to_numpy(dtype=float)))
                )
            )
        )[:, None]
    )
    cross_cov = bread @ (cross_score.T @ design) @ bread
    cross_discontinuity_cov = float(
        np.array([-1.0, 0.0, 1.0, 0.0])
        @ cross_cov
        @ np.array([-1.0, 0.0, 1.0, 0.0])
    )
    joint_cov[0, 1] = cross_discontinuity_cov
    joint_cov[1, 0] = cross_discontinuity_cov

    ratio_variance = float(ratio_gradient @ joint_cov @ ratio_gradient)
    treatment_se = float(np.sqrt(max(ratio_variance, 0.0)))

    estimates = [
        {
            "term": "treatment_effect",
            "estimate": treatment_effect,
            "se": treatment_se,
            "n_obs": n_obs,
        },
        {
            "term": "reduced_form",
            "estimate": reduced_form,
            "se": float(np.sqrt(max(var_rf, 0.0))),
            "n_obs": n_obs,
        },
        {
            "term": "first_stage",
            "estimate": first_stage,
            "se": float(np.sqrt(max(var_fs, 0.0))),
            "n_obs": n_obs,
        },
    ]

    result = {
        "task_id": "applied_fuzzy_rd",
        "platform": "python",
        "estimates": estimates,
        "method_metadata": {
            "estimator": "Fuzzy RD with separate weighted local-linear fits; cutoff=0, bandwidth=1, triangular weights",
            "vcov": "HC0 sandwich covariance; fixed bandwidth and weights; delta method with joint covariance",
        },
        "diagnostics": {},
    }

    with open("result.json", "w", encoding="utf-8") as file:
        json.dump(result, file, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
