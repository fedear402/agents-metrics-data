import json

import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS

crosswalk = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv")
areas = pd.read_csv("areas.csv")
employment = pd.read_csv("employment.csv")
outcomes = pd.read_csv("outcomes.csv")

trade = trade.merge(crosswalk[["code", "industry"]], on="code", how="inner", validate="many_to_one")

# Fill omitted area-industry cells with zero and calculate national totals
# separately for each period and employment vintage.
area_periods = areas[["area", "period"]].drop_duplicates()
industries = crosswalk["industry"].drop_duplicates()
vintages = ["base", "early"]
grid = (
    area_periods.assign(_key=1)
    .merge(pd.DataFrame({"industry": industries, "_key": 1}), on="_key")
    .merge(pd.DataFrame({"vintage": vintages, "_key": 1}), on="_key")
    .drop(columns="_key")
)
emp = grid.merge(
    employment,
    on=["area", "period", "vintage", "industry"],
    how="left",
    validate="one_to_one",
)
emp["employment"] = emp["employment"].fillna(0.0)
emp["national_employment"] = emp.groupby(
    ["period", "vintage", "industry"]
)["employment"].transform("sum")

# Trade has one row per industry and period. Join each area's employment
# shares and the corresponding trade shocks.
long = emp.merge(
    trade[["period", "industry", "us_change", "other_change", "price_index", "years"]],
    on=["period", "industry"],
    how="inner",
    validate="many_to_one",
)
long["trade_change"] = np.where(
    long["vintage"].eq("base"), long["us_change"], long["other_change"]
)
long["shock"] = (
    long["trade_change"]
    / long["national_employment"]
    / (long["price_index"] / 100.0)
    / 1000.0
    * (10.0 / long["years"])
)
long["share"] = long["employment"] / long["total_employment"].where(
    long["vintage"].eq("base")
)
# Use the matching vintage's area total employment for each exposure.
totals = areas[["area", "period", "vintage", "total_employment"]]
long = long.drop(columns=["total_employment"]).merge(
    totals, on=["area", "period", "vintage"], how="left", validate="many_to_one"
)
long["share"] = long["employment"] / long["total_employment"]
exposure = (
    long.assign(contribution=long["share"] * long["shock"])
    .groupby(["area", "period", "vintage"], as_index=False)["contribution"]
    .sum()
    .pivot(index=["area", "period"], columns="vintage", values="contribution")
    .reset_index()
    .rename(columns={"base": "x", "early": "z"})
)

data = outcomes.merge(exposure, on=["area", "period"], how="inner", validate="one_to_one")
data = data.merge(
    areas.loc[areas["vintage"].eq("base"), ["area", "period", "population"]],
    on=["area", "period"],
    how="inner",
    validate="one_to_one",
)

period_values = sorted(data["period"].unique())
if len(period_values) != 2:
    raise ValueError("Expected two periods.")
data["period_indicator"] = data["period"].eq(period_values[1]).astype(float)

exog = pd.DataFrame(
    {
        "intercept": 1.0,
        "period": data["period_indicator"].to_numpy(),
        "control": data["control"].to_numpy(),
    },
    index=data.index,
)
endog = data[["x"]]
instruments = pd.concat([exog, data[["z"]]], axis=1)

fit = IV2SLS(
    dependent=data["change_pp"],
    exog=exog,
    endog=endog,
    instruments=instruments,
    weights=data["population"],
).fit()

area0_period0 = data.loc[
    data["area"].eq(0) & data["period"].eq(period_values[0]), "x"
].iloc[0]
area0_period1 = data.loc[
    data["area"].eq(0) & data["period"].eq(period_values[1]), "x"
].iloc[0]
instrument_area0_period0 = data.loc[
    data["area"].eq(0) & data["period"].eq(period_values[0]), "z"
].iloc[0]

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [
        {"term": "iv_slope", "estimate": float(fit.params["x"]), "se": None, "n_obs": 72},
        {
            "term": "exposure_area0_period0",
            "estimate": float(area0_period0),
            "se": None,
            "n_obs": 72,
        },
        {
            "term": "exposure_area0_period1",
            "estimate": float(area0_period1),
            "se": None,
            "n_obs": 72,
        },
        {
            "term": "instrument_area0_period0",
            "estimate": float(instrument_area0_period0),
            "se": None,
            "n_obs": 72,
        },
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "dependent_variable": "change_pp",
        "endogenous_regressor": "x",
        "excluded_instrument": "z",
        "exogenous_regressors": ["intercept", "period", "control"],
        "instruments": ["intercept", "period", "control", "z"],
        "weight": "base-vintage population",
        "exposure_units": "thousands of real dollars per worker per decade",
    },
    "diagnostics": {"n_obs": 72},
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2)
