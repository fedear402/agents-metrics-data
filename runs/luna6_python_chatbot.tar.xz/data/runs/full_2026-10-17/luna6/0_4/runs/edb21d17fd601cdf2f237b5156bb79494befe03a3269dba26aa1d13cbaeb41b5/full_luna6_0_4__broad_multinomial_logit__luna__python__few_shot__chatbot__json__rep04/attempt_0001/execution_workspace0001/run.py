import json

import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy.special import softmax

data = pd.read_csv("input.csv")
y = data["y"].astype(int)
outcomes = [0, 1, 2]
if sorted(y.unique().tolist()) != outcomes:
    raise ValueError("Expected outcomes 0, 1, and 2.")

X = sm.add_constant(data[["x", "z"]], has_constant="add")
fit = sm.MNLogit(y, X).fit(disp=False, method="newton", tol=1e-12, maxiter=1000)

# Statsmodels parameter columns enumerate nonbase outcomes in ascending order.
coefficients = fit.params.copy()
standard_errors = fit.bse.copy()
coefficients.columns = outcomes[1:]
standard_errors.columns = outcomes[1:]

zero_input = pd.DataFrame({"const": [1.0], "x": [0.0], "z": [0.0]})
probabilities = np.asarray(fit.predict(zero_input))[0]
probability_cat2 = float(probabilities[outcomes.index(2)])

# Check the fitted probabilities against the softmax of all three indices.
indices = np.array([
    0.0,
    coefficients.loc["const", 1],
    coefficients.loc["const", 2],
], dtype=float)
if not np.allclose(probabilities, softmax(indices)) or not np.isclose(probabilities.sum(), 1.0):
    raise RuntimeError("Predicted probabilities failed validation.")

n_obs = int(len(data))
rows = [
    {"term": "x_cat1", "estimate": float(coefficients.loc["x", 1]), "se": float(standard_errors.loc["x", 1]), "n_obs": n_obs},
    {"term": "z_cat1", "estimate": float(coefficients.loc["z", 1]), "se": float(standard_errors.loc["z", 1]), "n_obs": n_obs},
    {"term": "x_cat2", "estimate": float(coefficients.loc["x", 2]), "se": float(standard_errors.loc["x", 2]), "n_obs": n_obs},
    {"term": "z_cat2", "estimate": float(coefficients.loc["z", 2]), "se": float(standard_errors.loc["z", 2]), "n_obs": n_obs},
    {"term": "prob_cat2_zero", "estimate": probability_cat2, "se": None, "n_obs": n_obs},
]

result = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": rows,
    "method_metadata": {
        "estimator": "Maximum-likelihood multinomial logit",
        "vcov": "Conventional observed-information covariance matrix",
    },
    "diagnostics": {},
}
with open("result.json", "w", encoding="utf-8") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
