import json
import numpy as np
import pandas as pd

households = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

sample = households.loc[households["recipient"].eq(0)].copy()
n_obs = int(len(sample))

eligible = sample["eligible"].to_numpy(dtype=float)
ineligible = 1.0 - eligible
dose = sample["dose"].to_numpy(dtype=float)
instrument = sample["instrument"].to_numpy(dtype=float)
baseline = sample["baseline"].to_numpy(dtype=float)
weight = sample["weight"].to_numpy(dtype=float)
outcome = sample["outcome"].to_numpy(dtype=float)

# Exogenous regressors, including the group indicators and group-specific baseline.
X = np.column_stack(
    [
        ineligible,
        eligible,
        baseline * ineligible,
        baseline * eligible,
    ]
)

# Endogenous regressors: group-specific dose.
D = np.column_stack([dose * ineligible, dose * eligible])
R = np.column_stack([X, D])

# Instruments: all exogenous regressors and group-specific excluded instruments.
Z = np.column_stack(
    [
        X,
        instrument * ineligible,
        instrument * eligible,
    ]
)

sqrt_weight = np.sqrt(weight)
Xw = X * sqrt_weight[:, None]
Dw = D * sqrt_weight[:, None]
Zw = Z * sqrt_weight[:, None]
yw = outcome * sqrt_weight

# Weighted 2SLS: project every regressor onto the instrument space, then
# estimate the structural equation using the projected regressors.
projection_coef = np.linalg.lstsq(Zw, np.column_stack([Xw, Dw]), rcond=None)[0]
projected_Rw = Zw @ projection_coef
beta = np.linalg.lstsq(projected_Rw, yw, rcond=None)[0]

ineligible_slope = float(beta[4])
eligible_slope = float(beta[5])

ineligible_mask = eligible == 0
eligible_mask = eligible == 1
ineligible_mean_dose = float(
    np.average(dose[ineligible_mask], weights=weight[ineligible_mask])
)
eligible_mean_dose = float(
    np.average(dose[eligible_mask], weights=weight[eligible_mask])
)

ineligible_effect = ineligible_slope * ineligible_mean_dose
eligible_nonrecipient_effect = eligible_slope * eligible_mean_dose

population_by_group = census.set_index("eligible")["nonrecipient_population"]
ineligible_population = float(population_by_group.loc[0])
eligible_population = float(population_by_group.loc[1])
population_effect = (
    ineligible_population * ineligible_effect
    + eligible_population * eligible_nonrecipient_effect
) / (ineligible_population + eligible_population)

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "ineligible_effect",
            "estimate": float(ineligible_effect),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "eligible_nonrecipient_effect",
            "estimate": float(eligible_nonrecipient_effect),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "population_effect",
            "estimate": float(population_effect),
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "weight_column": "weight",
        "retained_sample": "recipient == 0",
        "endogenous_columns": [
            "dose*(1-eligible)",
            "dose*eligible",
        ],
        "exogenous_columns": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
        ],
        "instrument_columns": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
            "instrument*(1-eligible)",
            "instrument*eligible",
        ],
        "intercept": "No additional intercept",
        "within_group_dose_mean": "Household-weighted mean among retained observations",
        "counterfactual": "Set dose to zero for every retained household",
        "attribution_convention": "Synthetic convention",
        "between_group_weights": "nonrecipient_population from census.csv",
        "n_obs_definition": "Number of retained nonrecipient household rows used in estimation",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "ineligible_household_rows": int(ineligible_mask.sum()),
        "eligible_nonrecipient_household_rows": int(eligible_mask.sum()),
        "ineligible_weighted_mean_dose": ineligible_mean_dose,
        "eligible_weighted_mean_dose": eligible_mean_dose,
        "ineligible_dose_slope": ineligible_slope,
        "eligible_dose_slope": eligible_slope,
        "ineligible_nonrecipient_population": int(ineligible_population),
        "eligible_nonrecipient_population": int(eligible_population),
    },
}

with open("result.json", "w", encoding="utf-8") as output_file:
    json.dump(result, output_file, indent=2, allow_nan=False)
    output_file.write("\n")
