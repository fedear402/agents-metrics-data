import json
import pandas as pd
import numpy as np

data = pd.read_csv("./input.csv")
results = []
treated_counts = []
row_counts = []
cohort_estimates = []

for cohort in (3, 5, 7):
    window = list(range(cohort - 2, cohort + 3))
    eligible = data[
        (data["g"] == cohort)
        | (data["g"] == 0)
        | (data["g"] > cohort + 2)
    ]
    comparison = eligible[eligible["time"].isin(window)]

    balanced_ids = (
        comparison.groupby("id")["time"]
        .nunique()
        .loc[lambda counts: counts == len(window)]
        .index
    )
    sample = comparison[comparison["id"].isin(balanced_ids)].copy()
    sample["did"] = (
        (sample["g"] == cohort) & (sample["time"] >= cohort)
    ).astype(float)

    design = pd.concat(
        [
            sample[["did"]].reset_index(drop=True),
            pd.get_dummies(sample["id"], drop_first=True, dtype=float).reset_index(drop=True),
            pd.get_dummies(sample["time"], drop_first=True, dtype=float).reset_index(drop=True),
        ],
        axis=1,
    )
    design.insert(0, "intercept", 1.0)
    coefficient = np.linalg.lstsq(
        design.to_numpy(dtype=float),
        sample["y"].to_numpy(dtype=float),
        rcond=None,
    )[0][1]

    retained_treated = sample.loc[sample["g"] == cohort, "id"].nunique()
    n_obs = len(sample)
    cohort_estimates.append(float(coefficient))
    treated_counts.append(int(retained_treated))
    row_counts.append(int(n_obs))
    results.append(
        {
            "term": f"att_g{cohort}",
            "estimate": float(coefficient),
            "se": None,
            "n_obs": n_obs,
        }
    )

weighted = float(np.average(cohort_estimates, weights=treated_counts))
results.append(
    {
        "term": "att_weighted",
        "estimate": weighted,
        "se": None,
        "n_obs": int(sum(row_counts)),
    }
)

output = {
    "task_id": "broad_cohort_stack",
    "platform": "python",
    "estimates": results,
    "method_metadata": {},
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
