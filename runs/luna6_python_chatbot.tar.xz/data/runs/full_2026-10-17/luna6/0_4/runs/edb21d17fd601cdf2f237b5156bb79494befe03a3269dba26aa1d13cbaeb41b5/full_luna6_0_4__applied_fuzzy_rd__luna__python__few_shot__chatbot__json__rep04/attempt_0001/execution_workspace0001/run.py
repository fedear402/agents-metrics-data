import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
inside = df.loc[df["score"].abs() < 1].copy()
n_obs = len(inside)

score = inside["score"].to_numpy(dtype=float)
right = (score >= 0).astype(float)
weights = 1 - np.abs(score)

# Separate local-linear fits with side-specific intercepts and slopes.
X = np.column_stack([
    1 - right,
    (1 - right) * score,
    right,
    right * score,
])
bread = np.linalg.inv(X.T @ (weights[:, None] * X))
loading = bread @ X.T
coefficients = loading @ (weights[:, None] * inside[["earnings", "participated"]].to_numpy(dtype=float))

# Right limit minus left limit.
contrast = np.array([-1.0, 0.0, 1.0, 0.0])
discontinuities = contrast @ coefficients

residuals = inside[["earnings", "participated"]].to_numpy(dtype=float) - X @ coefficients
influence = (weights[:, None] * (X @ bread @ contrast)[:, None]) * residuals
joint_covariance = influence.T @ influence

reduced_form, first_stage = discontinuities
treatment_effect = reduced_form / first_stage
gradient = np.array([1.0 / first_stage, -reduced_form / first_stage**2])
treatment_effect_se = float(np.sqrt(gradient @ joint_covariance @ gradient))

estimates = [
    {
        "term": "treatment_effect",
        "estimate": float(treatment_effect),
        "se": treatment_effect_se,
        "n_obs": int(n_obs),
    },
    {
        "term": "reduced_form",
        "estimate": float(reduced_form),
        "se": float(np.sqrt(joint_covariance[0, 0])),
        "n_obs": int(n_obs),
    },
    {
        "term": "first_stage",
        "estimate": float(first_stage),
        "se": float(np.sqrt(joint_covariance[1, 1])),
        "n_obs": int(n_obs),
    },
]

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "triangular-weighted local-linear fuzzy regression discontinuity",
        "vcov": "HC0, fixed bandwidth and weights, no degrees-of-freedom correction",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
