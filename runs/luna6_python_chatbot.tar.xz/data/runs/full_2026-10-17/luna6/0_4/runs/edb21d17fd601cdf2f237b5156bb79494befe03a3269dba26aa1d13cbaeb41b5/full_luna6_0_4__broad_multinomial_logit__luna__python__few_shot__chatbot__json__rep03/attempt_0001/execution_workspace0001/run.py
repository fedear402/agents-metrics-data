import json

import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy.special import softmax

data = pd.read_csv("input.csv")
outcomes = [0, 1, 2]
y = data["y"].astype(int)
X = data[["x", "z"]].astype(float).copy()
X.insert(0, "const", 1.0)

fit = sm.MNLogit(y, X).fit(disp=False, method="newton", tol=1e-10, maxiter=200)

# Statsmodels parameter columns enumerate the nonbase outcomes in order.
coefficients = fit.params.copy()
standard_errors = fit.bse.copy()
coefficients.columns = outcomes[1:]
standard_errors.columns = outcomes[1:]

at_zero = pd.DataFrame({"const": [1.0], "x": [0.0], "z": [0.0]})
probabilities = np.asarray(fit.predict(at_zero))[0]
prob_cat2_zero = float(probabilities[outcomes.index(2)])

# Check the fitted probability against the three outcome indices.
indices = [0.0]
for outcome in outcomes[1:]:
    indices.append(float(coefficients.loc["const", outcome]))
manual_probabilities = softmax(indices)
assert np.allclose(probabilities, manual_probabilities)

n_obs = int(len(data))
estimates = [
    {"term": "x_cat1", "estimate": float(coefficients.loc["x", 1]), "se": float(standard_errors.loc["x", 1]), "n_obs": n_obs},
    {"term": "z_cat1", "estimate": float(coefficients.loc["z", 1]), "se": float(standard_errors.loc["z", 1]), "n_obs": n_obs},
    {"term": "x_cat2", "estimate": float(coefficients.loc["x", 2]), "se": float(standard_errors.loc["x", 2]), "n_obs": n_obs},
    {"term": "z_cat2", "estimate": float(coefficients.loc["z", 2]), "se": float(standard_errors.loc["z", 2]), "n_obs": n_obs},
    {"term": "prob_cat2_zero", "estimate": prob_cat2_zero, "se": None, "n_obs": n_obs},
]

result = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "multinomial logit maximum likelihood",
        "vcov": "conventional observed-information covariance",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
