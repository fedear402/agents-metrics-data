import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
sample = df.loc[df["score"].abs() < 1].copy()

score = sample["score"].to_numpy(dtype=float)
right = (score >= 0).astype(float)
weights = 1.0 - np.abs(score)

# Separate local-linear slopes and intercepts on each side.
X = np.column_stack([
    np.ones(len(sample)),
    right,
    score * (1.0 - right),
    score * right,
])
Y = sample[["earnings", "participated"]].to_numpy(dtype=float)

bread = np.linalg.inv(X.T @ (weights[:, None] * X))
coefficients = bread @ X.T @ (weights[:, None] * Y)
residuals = Y - X @ coefficients

# The right-minus-left limit is the coefficient on the right-side indicator.
contrast = np.array([0.0, 1.0, 0.0, 0.0])
jumps = contrast @ coefficients
loading = weights * (X @ bread @ contrast)
influence = loading[:, None] * residuals
joint_covariance = influence.T @ influence

reduced_form, first_stage = jumps
gradient = np.array([
    1.0 / first_stage,
    -reduced_form / (first_stage ** 2),
])
treatment_effect = reduced_form / first_stage
treatment_effect_se = float(np.sqrt(gradient @ joint_covariance @ gradient))

n_obs = int(len(sample))
estimates = [
    {
        "term": "treatment_effect",
        "estimate": float(treatment_effect),
        "se": treatment_effect_se,
        "n_obs": n_obs,
    },
    {
        "term": "reduced_form",
        "estimate": float(reduced_form),
        "se": float(np.sqrt(joint_covariance[0, 0])),
        "n_obs": n_obs,
    },
    {
        "term": "first_stage",
        "estimate": float(first_stage),
        "se": float(np.sqrt(joint_covariance[1, 1])),
        "n_obs": n_obs,
    },
]

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "weighted local-linear fuzzy regression discontinuity; triangular weights; bandwidth 1",
        "vcov": "HC0 sandwich covariance; delta method for treatment effect",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
