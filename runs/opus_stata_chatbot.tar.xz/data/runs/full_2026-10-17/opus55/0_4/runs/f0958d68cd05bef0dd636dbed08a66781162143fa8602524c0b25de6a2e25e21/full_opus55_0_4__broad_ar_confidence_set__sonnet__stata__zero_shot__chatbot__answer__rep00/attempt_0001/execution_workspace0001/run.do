version 14
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear case(lower)
keep if !missing(y, endog, x, z1, z2)

mata:
    Y  = st_data(., "y")
    D  = st_data(., "endog")
    n  = rows(Y)
    W  = (J(n,1,1), st_data(., "x"))
    Z  = st_data(., ("z1","z2"))
    MW = I(n) - W*invsym(W'W)*W'
    Zt = MW*Z
    P  = Zt*invsym(Zt'Zt)*Zt'
    Mf = MW - P
    k  = 2
    df = n - 4
    c  = invF(k, df, 0.95)
    A  = (df/k)*P - c*Mf
    a  = D'A*D
    bb = Y'A*D
    cc = Y'A*Y
    disc = bb^2 - a*cc
    r1 = (bb - sqrt(disc))/a
    r2 = (bb + sqrt(disc))/a
    lo = min((r1,r2))
    hi = max((r1,r2))
    // q(b)=cc-2b*bb+b^2*a ; accept if q<=0
    acc0 = (cc <= 0)
    unb  = (a < 0) | (a == 0)
    u1 = Y - D
    f1 = ((u1'P*u1)/k) / ((u1'Mf*u1)/df)
    st_numscalar("lo", lo)
    st_numscalar("hi", hi)
    st_numscalar("acc0", acc0)
    st_numscalar("unb", unb)
    st_numscalar("f1", f1)
    st_numscalar("nobs", n)
end

display "ANSWER: boundary_low estimate=" %21.12f lo " se=" "." " n_obs=" %12.0f nobs
display "ANSWER: boundary_high estimate=" %21.12f hi " se=" "." " n_obs=" %12.0f nobs
display "ANSWER: accepts_zero estimate=" %21.12f acc0 " se=" "." " n_obs=" %12.0f nobs
display "ANSWER: unbounded estimate=" %21.12f unb " se=" "." " n_obs=" %12.0f nobs
display "ANSWER: ar_f_at_one estimate=" %21.12f f1 " se=" "." " n_obs=" %12.0f nobs
