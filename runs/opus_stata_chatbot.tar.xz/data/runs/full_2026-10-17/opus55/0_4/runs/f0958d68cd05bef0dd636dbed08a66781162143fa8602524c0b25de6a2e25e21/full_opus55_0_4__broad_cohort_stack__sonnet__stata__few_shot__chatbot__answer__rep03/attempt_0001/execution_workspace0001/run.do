clear all
set more off
set type double

tempfile base
import delimited using "./input.csv", clear varnames(1)
save `base'

local cohorts 3 5 7
local sumw = 0
local sumwb = 0
local sumn = 0
foreach c of local cohorts {
    use `base', clear
    keep if time>=`c'-2 & time<=`c'+2
    keep if g==`c' | g==0 | g>`c'+2
    keep if !missing(y)
    bysort id: gen long _nt=_N
    keep if _nt==5
    drop _nt
    gen byte did=(g==`c' & time>=`c')
    quietly regress y did i.id i.time
    scalar b`c'=_b[did]
    scalar n`c'=e(N)
    quietly count if g==`c'
    scalar w`c'=r(N)/5
    local sumw = `sumw' + w`c'
    local sumwb = `sumwb' + w`c'*b`c'
    local sumn = `sumn' + n`c'
}
scalar attw = `sumwb'/`sumw'
display "ANSWER: att_g3 estimate=" %24.16g b3
display "ANSWER: att_g5 estimate=" %24.16g b5
display "ANSWER: att_g7 estimate=" %24.16g b7
display "ANSWER: att_weighted estimate=" %24.16g attw
exit, clear
