clear all
set more off
set linesize 255
import delimited using "./input.csv", clear
quietly count
scalar N = r(N)

mata:
st_view(D=., ., ("y","endog","x","z1","z2"))
n = rows(D)
X = J(n,1,1), D[,3]
Z = D[,4..5]
Mx = I(n) - X*invsym(X'X)*X'
ay = Mx*D[,1]
w  = Mx*D[,2]
Zt = Mx*Z
P  = Zt*invsym(Zt'Zt)*Zt'
cv = invF(2, n-4, 0.95)
k  = (n-4)/2 + cv
A  = k*P - cv*I(n)
q2 = w'*A*w
q1 = -2*(ay'*A*w)
q0 = ay'*A*ay
disc = q1^2 - 4*q2*q0
r1 = (-q1 - sqrt(disc))/(2*q2)
r2 = (-q1 + sqrt(disc))/(2*q2)
lo = min((r1,r2))
hi = max((r1,r2))
unb = (q2 < 0)
// F statistic function
u0 = ay
F0 = (u0'*P*u0/2)/((u0'*u0 - u0'*P*u0)/(n-4))
u1 = ay - w
F1 = (u1'*P*u1/2)/((u1'*u1 - u1'*P*u1)/(n-4))
st_numscalar("lo", lo)
st_numscalar("hi", hi)
st_numscalar("unb", unb)
st_numscalar("acc0", F0 <= cv)
st_numscalar("F1", F1)
end

display "ANSWER: boundary_low estimate=" %21.12f lo " se=. n_obs=" %12.0f N
display "ANSWER: boundary_high estimate=" %21.12f hi " se=. n_obs=" %12.0f N
display "ANSWER: accepts_zero estimate=" %21.12f acc0 " se=. n_obs=" %12.0f N
display "ANSWER: unbounded estimate=" %21.12f unb " se=. n_obs=" %12.0f N
display "ANSWER: ar_f_at_one estimate=" %21.12f F1 " se=. n_obs=" %12.0f N
