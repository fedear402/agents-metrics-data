clear all
set more off
set linesize 255

import delimited using "./input.csv", clear varnames(1)
sort t
tsset t

arima y, arima(1,1,1) noconstant vce(oim)
scalar nobs = e(N)

quietly summarize t
scalar tmax = r(max)
tsappend, add(1)

predict double yf, y
predict double fmse, mse

quietly summarize yf if t == tmax + 1
scalar fc = r(mean)
quietly summarize fmse if t == tmax + 1
scalar fse = sqrt(r(mean))

scalar z = invnormal(0.975)
scalar lo = fc - z*fse
scalar hi = fc + z*fse

display "ANSWER: forecast estimate=" %21.12f fc " se=" %21.12f fse " n_obs=" %12.0f nobs
display "ANSWER: lower_95 estimate=" %21.12f lo " se=." " n_obs=" %12.0f nobs
display "ANSWER: upper_95 estimate=" %21.12f hi " se=." " n_obs=" %12.0f nobs
