version 14
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear varnames(1)
destring t y, replace force
sort t
tsset t

* ARIMA(1,1,1), no constant/drift, maximum likelihood
arima y, arima(1,1,1) noconstant
local nobs = e(N)

* Extend the time index by one period for the one-step-ahead forecast
tsappend, add(1)
quietly summarize t
local tmax = r(max)

* One-step-ahead forecast in levels and its MSE
predict double yhat_lev, y
predict double fmse, mse

quietly summarize yhat_lev if t == `tmax'
scalar fc = r(mean)
quietly summarize fmse if t == `tmax'
scalar fse = sqrt(r(mean))

scalar z = invnormal(0.975)
scalar lo = fc - z*fse
scalar hi = fc + z*fse

display "Forecast target t = " `tmax'
display "ANSWER: forecast estimate=" %21.12f fc " se=" %21.12f fse " n_obs=" %12.0f `nobs'
display "ANSWER: lower_95 estimate=" %21.12f lo " se=. n_obs=" %12.0f `nobs'
display "ANSWER: upper_95 estimate=" %21.12f hi " se=. n_obs=" %12.0f `nobs'
