clear all
set more off

import delimited using "census.csv", clear varnames(1)
keep eligible nonrecipient_population
tempfile cen
save `cen'
quietly summarize nonrecipient_population if eligible==0
scalar pop0 = r(sum)
quietly summarize nonrecipient_population if eligible==1
scalar pop1 = r(sum)

import delimited using "households.csv", clear varnames(1)
keep if recipient==0
drop if missing(outcome, dose, instrument, baseline, weight, eligible)

gen double inel = 1 - eligible
gen double el = eligible
gen double d0 = dose*inel
gen double d1 = dose*el
gen double b0 = baseline*inel
gen double b1 = baseline*el
gen double z0 = instrument*inel
gen double z1 = instrument*el

ivregress 2sls outcome inel el b0 b1 (d0 d1 = z0 z1) [aweight=weight], noconstant
scalar s0 = _b[d0]
scalar s1 = _b[d1]
scalar N = e(N)

quietly summarize dose [aweight=weight] if eligible==0 & e(sample)
scalar m0 = r(mean)
quietly summarize dose [aweight=weight] if eligible==1 & e(sample)
scalar m1 = r(mean)

scalar eff0 = s0*m0
scalar eff1 = s1*m1
scalar effp = (pop0*eff0 + pop1*eff1)/(pop0+pop1)

display "ANSWER: ineligible_effect estimate=" %20.12g eff0 " se=NA n_obs=" %12.0f N
display "ANSWER: eligible_nonrecipient_effect estimate=" %20.12g eff1 " se=NA n_obs=" %12.0f N
display "ANSWER: population_effect estimate=" %20.12g effp " se=NA n_obs=" %12.0f N
