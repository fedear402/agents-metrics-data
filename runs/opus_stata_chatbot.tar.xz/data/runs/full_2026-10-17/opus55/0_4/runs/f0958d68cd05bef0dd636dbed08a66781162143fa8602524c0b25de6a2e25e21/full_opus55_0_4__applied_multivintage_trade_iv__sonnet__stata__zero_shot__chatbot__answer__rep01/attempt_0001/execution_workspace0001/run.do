clear all
set more off

* Crosswalk
import delimited using "crosswalk.csv", clear varnames(1) stringcols(_all)
replace code = strtrim(code)
replace industry = strtrim(industry)
duplicates drop code, force
tempfile cw
save `cw'
keep industry
duplicates drop
tempfile inds
save `inds'

* Trade
import delimited using "trade.csv", clear varnames(1) stringcols(2)
replace code = strtrim(code)
merge m:1 code using `cw', keep(match) nogenerate
collapse (sum) us_change other_change (mean) price_index years, by(period industry)
tempfile tr
save `tr'

* Employment
import delimited using "employment.csv", clear varnames(1) stringcols(3 4)
replace vintage = lower(strtrim(vintage))
replace industry = strtrim(industry)
collapse (sum) employment, by(area period vintage industry)
tempfile emp
save `emp'

* Areas
import delimited using "areas.csv", clear varnames(1) stringcols(3)
replace vintage = lower(strtrim(vintage))
preserve
keep if vintage == "base"
keep area period population
duplicates drop area period, force
tempfile pop
save `pop'
restore
keep area period vintage total_employment
duplicates drop area period vintage, force
cross using `inds'
merge 1:1 area period vintage industry using `emp', keep(master match) nogenerate
replace employment = 0 if missing(employment)

bysort period vintage industry: egen double nat = total(employment)
merge m:1 period industry using `tr', keep(master match) nogenerate

gen double chg = cond(vintage == "base", us_change, other_change)
gen double term = (employment/total_employment) * (chg/nat) / (price_index/100) / 1000 * (10/years)
collapse (sum) term, by(area period vintage)
gen byte isbase = vintage == "base"
drop vintage
reshape wide term, i(area period) j(isbase)
rename term1 x
rename term0 z

merge 1:1 area period using `pop', keep(master match) nogenerate
tempfile ex
save `ex'

import delimited using "outcomes.csv", clear varnames(1)
merge 1:1 area period using `ex', keep(match) nogenerate

ivregress 2sls change_pp period control (x = z) [aweight=population]
local b = _b[x]
local n = e(N)

quietly summarize x if area == 0 & period == 0
local x0 = r(mean)
quietly summarize x if area == 0 & period == 1
local x1 = r(mean)
quietly summarize z if area == 0 & period == 0
local z0 = r(mean)

di "ANSWER: iv_slope estimate=" %20.12g `b' " se=NA n_obs=" `n'
di "ANSWER: exposure_area0_period0 estimate=" %20.12g `x0' " se=NA n_obs=" `n'
di "ANSWER: exposure_area0_period1 estimate=" %20.12g `x1' " se=NA n_obs=" `n'
di "ANSWER: instrument_area0_period0 estimate=" %20.12g `z0' " se=NA n_obs=" `n'
