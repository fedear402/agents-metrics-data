clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

* Regional weights normalized once using one observation per region
bysort region_id (industry_id): gen byte firstr = (_n == 1)
quietly summarize region_weight if firstr
gen double e = region_weight / r(sum)

* Shift-share instrument
gen double ss = share * shock
bysort region_id: egen double z = total(ss)

* e-weighted regional means and residuals
foreach v in y x z {
    quietly summarize `v' [aw=e] if firstr
    gen double `v'0 = `v' - r(mean)
}

* Regional 2SLS and first-stage slopes
gen double t_zy = e*z0*y0 if firstr
gen double t_zx = e*z0*x0 if firstr
gen double t_zz = e*z0*z0 if firstr
quietly summarize t_zy
scalar Szy = r(sum)
quietly summarize t_zx
scalar Szx = r(sum)
quietly summarize t_zz
scalar Szz = r(sum)
scalar b_effect = Szy / Szx
scalar b_fs = Szx / Szz

* Shock-level aggregation
gen double w = e*share
gen double wy = w*y0
gen double wx = w*x0
gen double wz = w*z0
collapse (sum) s=w wy wx wz (mean) shock, by(industry_id)
drop if s <= 0 | missing(s)
gen double ybar = wy/s
gen double xbar = wx/s
gen double zbar = wz/s
quietly count
scalar N = r(N)

* Weighted mean of shock (weights s)
quietly summarize shock [aw=s]
gen double gd = shock - r(mean)

capture program drop shockiv
program define shockiv, rclass
    args o d
    quietly summarize `o' [aw=s]
    scalar om = r(mean)
    quietly summarize `d' [aw=s]
    scalar dm = r(mean)
    tempvar a b u m
    gen double `a' = s*gd*(`o'-om)
    gen double `b' = s*gd*(`d'-dm)
    quietly summarize `a'
    scalar num = r(sum)
    quietly summarize `b'
    scalar den = r(sum)
    scalar beta = num/den
    scalar alpha = om - beta*dm
    gen double `u' = `o' - alpha - beta*`d'
    gen double `m' = (s*gd*`u')^2
    quietly summarize `m'
    return scalar beta = beta
    return scalar se = sqrt(r(sum)/(den^2) * N/(N-2))
end

shockiv ybar xbar
scalar b_eff_shock = r(beta)
scalar se_effect = r(se)

shockiv xbar zbar
scalar se_fs = r(se)

gen double s2 = s^2
quietly summarize s2
scalar eff_shocks = 1/r(sum)

display "check shock-level slope=" %21.12f b_eff_shock
display "ANSWER: effect estimate=" %21.12f b_effect " se=" %21.12f se_effect " n_obs=" %12.0f N
display "ANSWER: first_stage estimate=" %21.12f b_fs " se=" %21.12f se_fs " n_obs=" %12.0f N
display "ANSWER: effective_shocks estimate=" %21.12f eff_shocks " se=. n_obs=" %12.0f N
