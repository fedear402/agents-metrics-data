version 19.0
clear all
set more off
set linesize 255
import delimited using "./input.csv", clear varnames(1)
destring region_id industry_id share shock region_weight x y, replace force
sort region_id industry_id
mata:
rid=st_data(., "region_id")
iid=st_data(., "industry_id")
sh=st_data(., "share")
sk=st_data(., "shock")
rw=st_data(., "region_weight")
xv=st_data(., "x")
yv=st_data(., "y")
ru=uniqrows(rid)
iu=uniqrows(iid)
R=rows(ru)
N=rows(iu)
S=J(R,N,0)
shock=J(N,1,.)
w=J(R,1,.)
X=J(R,1,.)
Y=J(R,1,.)
for (k=1;k<=rows(rid);k++) {
    r=selectindex(ru:==rid[k])[1]
    n=selectindex(iu:==iid[k])[1]
    S[r,n]=S[r,n]+sh[k]
    shock[n]=sk[k]
    w[r]=rw[k]
    X[r]=xv[k]
    Y[r]=yv[k]
}
e=w/sum(w)
z=S*shock
regional=(Y,X,z)
centered=regional:-e'*regional
mass=S'*e
aggregated=(S'*(e:*centered)):/mass
est=J(2,2,.)
for (eq=1;eq<=2;eq++) {
    dep=aggregated[,eq]
    endo=aggregated[,eq+1]
    Xr=(J(N,1,1),endo)
    Zr=(J(N,1,1),shock)
    inv=luinv(Zr'*(mass:*Xr))
    b=inv*Zr'*(mass:*dep)
    u=dep-Xr*b
    sc=Zr:*(mass:*u)
    V=N/(N-2)*inv*(sc'*sc)*inv'
    est[eq,]=(b[2],sqrt(V[2,2]))
}
st_numscalar("b1",est[1,1])
st_numscalar("s1",est[1,2])
st_numscalar("b2",est[2,1])
st_numscalar("s2",est[2,2])
st_numscalar("eff",1/sum(mass:^2))
st_numscalar("nn",N)
end
display "ANSWER: effect estimate=" %21.12f b1 " se=" %21.12f s1 " n_obs=" %12.0f nn
display "ANSWER: first_stage estimate=" %21.12f b2 " se=" %21.12f s2 " n_obs=" %12.0f nn
display "ANSWER: effective_shocks estimate=" %21.12f eff " se=. n_obs=" %12.0f nn
