clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

keep if abs(score) < 1 & !missing(score, participated, earnings)
gen double w = 1 - abs(score)
gen double d = (score >= 0)
gen double ds = d*score
gen double cons = 1

mata:
    X  = st_data(., ("cons","d","score","ds"))
    w  = st_data(., "w")
    y1 = st_data(., "earnings")
    y2 = st_data(., "participated")
    n  = rows(X)
    XWX = quadcross(X, w, X)
    A   = invsym(XWX)
    b1  = A * quadcross(X, w, y1)
    b2  = A * quadcross(X, w, y2)
    e1  = y1 - X*b1
    e2  = y2 - X*b2
    S1 = X :* (w :* e1)
    S2 = X :* (w :* e2)
    IF1 = S1 * A
    IF2 = S2 * A
    V11 = quadcross(IF1, IF1)
    V22 = quadcross(IF2, IF2)
    V12 = quadcross(IF1, IF2)
    rf  = b1[2]
    fs  = b2[2]
    vrf = V11[2,2]
    vfs = V22[2,2]
    cov = V12[2,2]
    te  = rf/fs
    g   = (1/fs, -rf/(fs^2))
    Vj  = (vrf, cov \ cov, vfs)
    vte = g * Vj * g'
    st_numscalar("rf", rf)
    st_numscalar("fs", fs)
    st_numscalar("te", te)
    st_numscalar("se_rf", sqrt(vrf))
    st_numscalar("se_fs", sqrt(vfs))
    st_numscalar("se_te", sqrt(vte))
    st_numscalar("nobs", n)
end

display "ANSWER: treatment_effect estimate=" %21.12f te " se=" %21.12f se_te " n_obs=" %12.0f nobs
display "ANSWER: reduced_form estimate=" %21.12f rf " se=" %21.12f se_rf " n_obs=" %12.0f nobs
display "ANSWER: first_stage estimate=" %21.12f fs " se=" %21.12f se_fs " n_obs=" %12.0f nobs
