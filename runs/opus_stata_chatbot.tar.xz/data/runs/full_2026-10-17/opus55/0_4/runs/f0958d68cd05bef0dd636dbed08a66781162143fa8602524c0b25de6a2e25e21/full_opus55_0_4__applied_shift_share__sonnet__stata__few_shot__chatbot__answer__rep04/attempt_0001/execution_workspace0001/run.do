version 19.0
clear all
set more off
set linesize 255

import delimited "./input.csv", clear varnames(1)

sort region_id industry_id

* Build region and industry indices
egen long rix = group(region_id)
egen long nix = group(industry_id)
quietly summarize rix
local R = r(max)
quietly summarize nix
local N = r(max)

mata:
    rix   = st_data(., "rix")
    nix   = st_data(., "nix")
    sh    = st_data(., "share")
    shk   = st_data(., "shock")
    rw    = st_data(., "region_weight")
    xv    = st_data(., "x")
    yv    = st_data(., "y")
    R = strtoreal(st_local("R"))
    N = strtoreal(st_local("N"))

    S = J(R, N, 0)
    shock = J(N, 1, .)
    w = J(R, 1, .)
    x = J(R, 1, .)
    y = J(R, 1, .)
    for (i = 1; i <= rows(rix); i++) {
        S[rix[i], nix[i]] = S[rix[i], nix[i]] + sh[i]
        shock[nix[i]] = shk[i]
        w[rix[i]] = rw[i]
        x[rix[i]] = xv[i]
        y[rix[i]] = yv[i]
    }
    e = w / sum(w)
    z = S * shock

    regional = (y, x, z)
    centered = regional :- e' * regional
    mass = S' * e
    aggregated = (S' * (e :* centered)) :/ mass

    est = J(2, 2, .)
    for (eq = 1; eq <= 2; eq++) {
        dep = aggregated[, eq]
        endo = aggregated[, eq + 1]
        X = (J(N, 1, 1), endo)
        Z = (J(N, 1, 1), shock)
        cross = Z' * (mass :* X)
        inv = luinv(cross)
        b = inv * Z' * (mass :* dep)
        u = dep - X * b
        sc = Z :* (mass :* u)
        V = N / (N - 2) * inv * (sc' * sc) * inv'
        est[eq, ] = (b[2], sqrt(V[2, 2]))
    }

    reg_effect = sum(e :* centered[,3] :* centered[,1]) / sum(e :* centered[,3] :* centered[,2])
    reg_fs = sum(e :* centered[,3] :* centered[,2]) / sum(e :* centered[,3] :^ 2)

    st_numscalar("b_eff", reg_effect)
    st_numscalar("se_eff", est[1, 2])
    st_numscalar("b_fs", reg_fs)
    st_numscalar("se_fs", est[2, 2])
    st_numscalar("eff_n", 1 / sum(mass :^ 2))
    st_numscalar("nind", N)
    st_numscalar("chk", max(abs(est[, 1] - (reg_effect \ reg_fs))))
end

display "check diff = " chk

display "ANSWER: effect estimate=" %21.12f b_eff " se=" %21.12f se_eff " n_obs=" %12.0f nind
display "ANSWER: first_stage estimate=" %21.12f b_fs " se=" %21.12f se_fs " n_obs=" %12.0f nind
display "ANSWER: effective_shocks estimate=" %21.12f eff_n " se=. n_obs=" %12.0f nind
