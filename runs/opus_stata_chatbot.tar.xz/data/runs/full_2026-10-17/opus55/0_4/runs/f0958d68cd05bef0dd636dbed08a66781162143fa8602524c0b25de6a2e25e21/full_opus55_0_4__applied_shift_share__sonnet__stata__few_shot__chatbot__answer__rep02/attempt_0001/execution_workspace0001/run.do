version 19.0
clear all
set more off
set linesize 255
import delimited using "./input.csv", clear varnames(1)
sort region_id industry_id
egen long rgrp = group(region_id)
egen long igrp = group(industry_id)
quietly summarize rgrp
local R = r(max)
quietly summarize igrp
local N = r(max)
mata:
rg = st_data(., "rgrp")
ig = st_data(., "igrp")
sh = st_data(., "share")
sk = st_data(., "shock")
rw = st_data(., "region_weight")
xv = st_data(., "x")
yv = st_data(., "y")
R = strtoreal(st_local("R"))
N = strtoreal(st_local("N"))
S = J(R,N,0)
shock = J(N,1,.)
w = J(R,1,.)
x = J(R,1,.)
y = J(R,1,.)
for (i=1;i<=rows(rg);i++) {
    S[rg[i],ig[i]] = S[rg[i],ig[i]] + sh[i]
    shock[ig[i]] = sk[i]
    w[rg[i]] = rw[i]
    x[rg[i]] = xv[i]
    y[rg[i]] = yv[i]
}
e = w/sum(w)
z = S*shock
regional = (y,x,z)
centered = regional :- e'*regional
mass = S'*e
aggregated = (S'*(e:*centered)):/mass
est = J(2,2,.)
for (eq=1;eq<=2;eq++) {
    dep = aggregated[,eq]
    endo = aggregated[,eq+1]
    X = (J(N,1,1),endo)
    Z = (J(N,1,1),shock)
    inv = luinv(Z'*(mass:*X))
    b = inv*Z'*(mass:*dep)
    res = dep - X*b
    sc = Z:*(mass:*res)
    V = N/(N-2)*inv*(sc'*sc)*inv'
    est[eq,] = (b[2],sqrt(V[2,2]))
}
st_numscalar("b1",est[1,1]); st_numscalar("s1",est[1,2])
st_numscalar("b2",est[2,1]); st_numscalar("s2",est[2,2])
st_numscalar("eff",1/sum(mass:^2))
st_numscalar("nn",N)
end
display "ANSWER: effect estimate=" %21.12f b1 " se=" %21.12f s1 " n_obs=" %12.0f nn
display "ANSWER: first_stage estimate=" %21.12f b2 " se=" %21.12f s2 " n_obs=" %12.0f nn
display "ANSWER: effective_shocks estimate=" %21.12f eff " se=. n_obs=" %12.0f nn
