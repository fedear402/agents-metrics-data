version 19.0
clear all
set more off
set linesize 255
import delimited using "./input.csv", clear varnames(1)
sort region_id industry_id
preserve
keep region_id region_weight x y
bysort region_id: keep if _n==1
sort region_id
tempfile reg
save `reg'
restore
preserve
keep industry_id shock
bysort industry_id: keep if _n==1
sort industry_id
tempfile ind
save `ind'
restore
keep region_id industry_id share
egen long rid = group(region_id)
egen long iid = group(industry_id)
quietly summarize rid
local R = r(max)
quietly summarize iid
local N = r(max)
mata: S = J(`R',`N',0)
mata: st_view(V=., ., ("rid","iid","share"))
mata: for (i=1;i<=rows(V);i++) S[V[i,1],V[i,2]] = S[V[i,1],V[i,2]] + V[i,3]
use `reg', clear
mata: W = st_data(., "region_weight"); X = st_data(., "x"); Y = st_data(., "y")
use `ind', clear
mata: G = st_data(., "shock")
mata:
e = W/sum(W)
Z = S*G
reg = (Y, X, Z)
c = reg :- e'*reg
s = S'*e
agg = (S'*(e:*c)):/s
Nn = rows(G)
est = J(2,2,.)
for (k=1;k<=2;k++) {
    dep = agg[,k]
    en = agg[,k+1]
    Rg = (J(Nn,1,1), en)
    In = (J(Nn,1,1), G)
    inv = luinv(In'*(s:*Rg))
    b = inv*In'*(s:*dep)
    u = dep - Rg*b
    sc = In:*(s:*u)
    V = Nn/(Nn-2)*inv*(sc'*sc)*inv'
    est[k,] = (b[2], sqrt(V[2,2]))
}
st_numscalar("b1", est[1,1]); st_numscalar("se1", est[1,2])
st_numscalar("b2", est[2,1]); st_numscalar("se2", est[2,2])
st_numscalar("eff", 1/sum(s:^2)); st_numscalar("NN", Nn)
end
display "ANSWER: effect estimate=" %21.12f b1 " se=" %21.12f se1 " n_obs=" %12.0f NN
display "ANSWER: first_stage estimate=" %21.12f b2 " se=" %21.12f se2 " n_obs=" %12.0f NN
display "ANSWER: effective_shocks estimate=" %21.12f eff " se=. n_obs=" %12.0f NN
