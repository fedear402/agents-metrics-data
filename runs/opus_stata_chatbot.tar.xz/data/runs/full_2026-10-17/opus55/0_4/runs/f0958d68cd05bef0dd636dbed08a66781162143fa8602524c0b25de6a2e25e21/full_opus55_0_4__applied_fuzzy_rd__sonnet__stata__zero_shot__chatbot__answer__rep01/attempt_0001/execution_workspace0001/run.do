clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

keep if abs(score) < 1 & !missing(score, participated, earnings)
gen double w = 1 - abs(score)
gen double D = (score >= 0)
gen double Dscore = D*score
gen double one = 1

mata:
X = st_data(., ("one","D","score","Dscore"))
y = st_data(., "earnings")
d = st_data(., "participated")
w = st_data(., "w")
n = rows(X)
XWX = quadcross(X, w, X)
A = invsym(XWX)
by = A*quadcross(X, w, y)
bd = A*quadcross(X, w, d)
ey = y - X*by
ed = d - X*bd
Sy = X :* (w:*ey)
Sd = X :* (w:*ed)
Vyy = A*quadcross(Sy,Sy)*A
Vdd = A*quadcross(Sd,Sd)*A
Vyd = A*quadcross(Sy,Sd)*A
rf = by[2]
fs = bd[2]
vrf = Vyy[2,2]
vfs = Vdd[2,2]
crf = Vyd[2,2]
te = rf/fs
g1 = 1/fs
g2 = -rf/(fs^2)
vte = g1^2*vrf + g2^2*vfs + 2*g1*g2*crf
st_numscalar("rf", rf)
st_numscalar("fs", fs)
st_numscalar("te", te)
st_numscalar("serf", sqrt(vrf))
st_numscalar("sefs", sqrt(vfs))
st_numscalar("sete", sqrt(vte))
st_numscalar("nobs", n)
end

display "ANSWER: treatment_effect estimate=" %21.12f te " se=" %21.12f sete " n_obs=" %12.0f nobs
display "ANSWER: reduced_form estimate=" %21.12f rf " se=" %21.12f serf " n_obs=" %12.0f nobs
display "ANSWER: first_stage estimate=" %21.12f fs " se=" %21.12f sefs " n_obs=" %12.0f nobs
