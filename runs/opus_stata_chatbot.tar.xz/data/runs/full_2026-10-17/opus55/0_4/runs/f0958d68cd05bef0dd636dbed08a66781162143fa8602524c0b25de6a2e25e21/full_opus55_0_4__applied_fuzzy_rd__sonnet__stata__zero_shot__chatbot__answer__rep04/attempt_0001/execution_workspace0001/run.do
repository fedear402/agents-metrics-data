version 14
clear all
set more off
set linesize 255

import delimited "./input.csv", clear varnames(1)

keep if abs(score) < 1 & !missing(score, participated, earnings)
gen double w = 1 - abs(score)
gen double right = (score >= 0)
gen double rs = right*score
gen double cons = 1

mata:
    X  = st_data(., ("cons","right","score","rs"))
    w  = st_data(., "w")
    y  = st_data(., "earnings")
    d  = st_data(., "participated")
    n  = rows(X)
    XWX  = cross(X, w, X)
    iXWX = invsym(XWX)
    by = iXWX * cross(X, w, y)
    bd = iXWX * cross(X, w, d)
    ey = y - X*by
    ed = d - X*bd
    Vyy = iXWX * cross(X, (w:^2):*(ey:^2), X) * iXWX
    Vdd = iXWX * cross(X, (w:^2):*(ed:^2), X) * iXWX
    Vyd = iXWX * cross(X, (w:^2):*(ey:*ed), X) * iXWX
    rf = by[2]
    fs = bd[2]
    vrf = Vyy[2,2]
    vfs = Vdd[2,2]
    cov = Vyd[2,2]
    te = rf/fs
    g = (1/fs, -rf/(fs^2))
    V = (vrf, cov \ cov, vfs)
    vte = g*V*g'
    st_numscalar("rf", rf)
    st_numscalar("fs", fs)
    st_numscalar("te", te)
    st_numscalar("se_rf", sqrt(vrf))
    st_numscalar("se_fs", sqrt(vfs))
    st_numscalar("se_te", sqrt(vte))
    st_numscalar("nobs", n)
end

display "ANSWER: treatment_effect estimate=" %21.12f te " se=" %21.12f se_te " n_obs=" %12.0f nobs
display "ANSWER: reduced_form estimate=" %21.12f rf " se=" %21.12f se_rf " n_obs=" %12.0f nobs
display "ANSWER: first_stage estimate=" %21.12f fs " se=" %21.12f se_fs " n_obs=" %12.0f nobs
