clear all
set more off
set linesize 255
import delimited using "./input.csv", clear varnames(1)
capture confirm string variable group
if !_rc {
    encode group, gen(group_id)
}
else {
    gen group_id = group
}
capture confirm string variable y
if !_rc {
    destring y, replace force
}
drop if missing(y) | missing(group_id)
oneway y group_id
scalar Fst = r(F)
scalar dfn = r(df_m)
scalar dfd = r(df_r)
scalar nobs = r(N)
scalar pv = Ftail(dfn, dfd, Fst)
display "ANSWER: F estimate=" %21.12f Fst " se=. n_obs=" %12.0f nobs
display "ANSWER: df_num estimate=" %21.12f dfn " se=. n_obs=" %12.0f nobs
display "ANSWER: df_den estimate=" %21.12f dfd " se=. n_obs=" %12.0f nobs
display "ANSWER: p_value estimate=" %21.12f pv " se=. n_obs=" %12.0f nobs
