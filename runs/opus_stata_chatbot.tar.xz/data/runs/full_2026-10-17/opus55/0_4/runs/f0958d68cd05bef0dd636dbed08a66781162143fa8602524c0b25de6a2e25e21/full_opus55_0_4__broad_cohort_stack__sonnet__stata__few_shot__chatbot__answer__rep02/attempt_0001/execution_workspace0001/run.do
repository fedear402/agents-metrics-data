clear all
set more off
set type double

local wsum = 0
local nsum = 0
local rsum = 0

foreach c in 3 5 7 {
    import delimited using "./input.csv", clear varnames(1)
    keep if time >= `c'-2 & time <= `c'+2
    keep if g == `c' | g == 0 | g > `c'+2
    drop if missing(y)
    bysort id: gen int nobs_ = _N
    keep if nobs_ == 5
    drop nobs_
    gen byte did = (g == `c' & time >= `c')
    quietly regress y did i.id i.time
    scalar att`c' = _b[did]
    scalar rows`c' = e(N)
    egen byte tag_ = tag(id)
    quietly count if tag_ & g == `c'
    scalar ntr`c' = r(N)
    local wsum = `wsum' + ntr`c' * att`c'
    local nsum = `nsum' + ntr`c'
    local rsum = `rsum' + rows`c'
}

scalar attw = `wsum' / `nsum'

display "ANSWER: att_g3 estimate=" %24.16g att3
display "ANSWER: att_g5 estimate=" %24.16g att5
display "ANSWER: att_g7 estimate=" %24.16g att7
display "ANSWER: att_weighted estimate=" %24.16g attw
exit, clear
