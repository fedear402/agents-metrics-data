clear all
set more off
set linesize 255

import delimited using "./input.csv", clear varnames(1)

keep if abs(score) < 1 & !missing(score, participated, earnings)
gen double w = 1 - abs(score)
gen double d = (score >= 0)
gen double ds = d*score

quietly count
scalar N = r(N)

* Bread: X'WX (constant appended last by matrix accum)
matrix accum A = d score ds [iweight=w]
matrix Ainv = invsym(A)

* Coefficients
matrix vecaccum by = earnings d score ds [iweight=w]
matrix vecaccum bp = participated d score ds [iweight=w]
matrix bY = Ainv * by'
matrix bP = Ainv * bp'

scalar rf = bY[1,1]
scalar fs = bP[1,1]

* Residuals
gen double eY = earnings - (bY[1,1]*d + bY[2,1]*score + bY[3,1]*ds + bY[4,1])
gen double eP = participated - (bP[1,1]*d + bP[2,1]*score + bP[3,1]*ds + bP[4,1])

gen double wYY = w^2*eY*eY
gen double wPP = w^2*eP*eP
gen double wYP = w^2*eY*eP

matrix accum MYY = d score ds [iweight=wYY]
matrix accum MPP = d score ds [iweight=wPP]
matrix accum MYP = d score ds [iweight=wYP]

matrix VYY = Ainv*MYY*Ainv
matrix VPP = Ainv*MPP*Ainv
matrix VYP = Ainv*MYP*Ainv

scalar vrf = VYY[1,1]
scalar vfs = VPP[1,1]
scalar cov = VYP[1,1]

scalar se_rf = sqrt(vrf)
scalar se_fs = sqrt(vfs)

scalar te = rf/fs
scalar g1 = 1/fs
scalar g2 = -rf/(fs^2)
scalar se_te = sqrt(g1^2*vrf + g2^2*vfs + 2*g1*g2*cov)

display "ANSWER: treatment_effect estimate=" %21.12f te " se=" %21.12f se_te " n_obs=" %12.0f N
display "ANSWER: reduced_form estimate=" %21.12f rf " se=" %21.12f se_rf " n_obs=" %12.0f N
display "ANSWER: first_stage estimate=" %21.12f fs " se=" %21.12f se_fs " n_obs=" %12.0f N
