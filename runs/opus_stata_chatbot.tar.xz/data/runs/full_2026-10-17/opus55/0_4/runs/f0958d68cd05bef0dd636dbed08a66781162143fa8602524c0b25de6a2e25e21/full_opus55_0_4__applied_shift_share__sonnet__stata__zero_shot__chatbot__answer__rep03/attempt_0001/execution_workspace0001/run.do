clear all
set more off
set linesize 255

import delimited using "./input.csv", clear varnames(1)

* Regional weights normalized once using one observation per region
bysort region_id: gen byte rtag = (_n == 1)
quietly summarize region_weight if rtag
gen double e = region_weight / r(sum)

* Shift-share instrument
gen double sz = share * shock
bysort region_id: egen double z = total(sz)

* Demean using e-weighted regional means
foreach v in y x z {
    quietly summarize `v' [aw=e] if rtag
    gen double `v'0 = `v' - r(mean)
}

* Shock-level aggregation
gen double w = e * share
foreach v in y x z {
    gen double wv_`v' = w * `v'0
}
collapse (sum) s=w wy=wv_y wx=wv_x wz=wv_z (mean) shock, by(industry_id)
drop if s <= 0 | missing(s)
gen double ybar = wy / s
gen double xbar = wx / s
gen double zbar = wz / s

mata:
void bhj_iv(string scalar yv, string scalar xv, string scalar gv, string scalar wv, string scalar pre)
{
    real colvector y, x, g, w, u, b
    real matrix X, Z, A, Ainv, M, V
    real scalar N
    y = st_data(., yv)
    x = st_data(., xv)
    g = st_data(., gv)
    w = st_data(., wv)
    N = rows(y)
    X = J(N,1,1), x
    Z = J(N,1,1), g
    A = Z' * (w :* X)
    Ainv = luinv(A)
    b = Ainv * (Z' * (w :* y))
    u = y - X * b
    M = Z' * ((w:^2 :* u:^2) :* Z)
    V = (N/(N-2)) * Ainv * M * Ainv'
    st_numscalar(pre + "_b", b[2])
    st_numscalar(pre + "_se", sqrt(V[2,2]))
    st_numscalar(pre + "_n", N)
}
end

mata: bhj_iv("ybar", "xbar", "shock", "s", "eff")
mata: bhj_iv("xbar", "zbar", "shock", "s", "fs")

gen double s2 = s^2
quietly summarize s2
scalar effshocks = 1 / r(sum)
scalar nind = _N

display "ANSWER: effect estimate=" %21.12f eff_b " se=" %21.12f eff_se " n_obs=" %12.0f eff_n
display "ANSWER: first_stage estimate=" %21.12f fs_b " se=" %21.12f fs_se " n_obs=" %12.0f fs_n
display "ANSWER: effective_shocks estimate=" %21.12f effshocks " se=. n_obs=" %12.0f nind
