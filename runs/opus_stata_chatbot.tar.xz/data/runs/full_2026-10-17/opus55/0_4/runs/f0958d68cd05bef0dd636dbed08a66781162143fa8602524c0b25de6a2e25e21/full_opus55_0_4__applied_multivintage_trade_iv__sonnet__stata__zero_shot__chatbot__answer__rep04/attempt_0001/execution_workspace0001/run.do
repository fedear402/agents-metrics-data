clear all
set more off

* Crosswalk and the list of industries
import delimited using "crosswalk.csv", clear varnames(1)
tempfile cw inds trade areas emp
save `cw'
keep industry
duplicates drop
save `inds'

* Trade data mapped to industries
import delimited using "trade.csv", clear varnames(1)
merge m:1 code using `cw', keep(match) nogen
keep period industry us_change other_change price_index years
save `trade'

* Area keys
import delimited using "areas.csv", clear varnames(1)
capture confirm string variable vintage
if _rc tostring vintage, replace
replace vintage = strtrim(lower(vintage))
save `areas'

* Employment
import delimited using "employment.csv", clear varnames(1)
capture confirm string variable vintage
if _rc tostring vintage, replace
replace vintage = strtrim(lower(vintage))
collapse (sum) employment, by(area period vintage industry)
save `emp'

* Full grid: every area-period-vintage times every industry; missing cells are zero
use `areas', clear
keep area period vintage total_employment
cross using `inds'
merge 1:1 area period vintage industry using `emp', keep(master match) nogen
replace employment = 0 if missing(employment)

* National industry employment within period and vintage
bysort period vintage industry: egen double nat = total(employment)

merge m:1 period industry using `trade', keep(match) nogen

gen double chg = cond(vintage=="base", us_change, other_change)
gen double term = (employment/total_employment)*(chg/nat)/(price_index/100)/1000*(10/years)
collapse (sum) term, by(area period vintage)
gen str5 v = cond(vintage=="base","x","z")
drop vintage
reshape wide term, i(area period) j(v) string
rename termx x
rename termz z

* Base-vintage population
preserve
use `areas', clear
keep if vintage=="base"
keep area period population
tempfile pop
save `pop'
restore
merge 1:1 area period using `pop', keep(match) nogen

* Outcomes
preserve
import delimited using "outcomes.csv", clear varnames(1)
tempfile out
save `out'
restore
merge 1:1 area period using `out', keep(match) nogen

ivregress 2sls change_pp period control (x = z) [aweight=population]
scalar b = _b[x]
scalar n = e(N)

sort area period
quietly summarize x if area==0 & period==0
scalar x00 = r(mean)
quietly summarize x if area==0 & period==1
scalar x01 = r(mean)
quietly summarize z if area==0 & period==0
scalar z00 = r(mean)

di "ANSWER: iv_slope estimate=" %20.12g b " se=NA n_obs=" n
di "ANSWER: exposure_area0_period0 estimate=" %20.12g x00 " se=NA n_obs=" n
di "ANSWER: exposure_area0_period1 estimate=" %20.12g x01 " se=NA n_obs=" n
di "ANSWER: instrument_area0_period0 estimate=" %20.12g z00 " se=NA n_obs=" n
