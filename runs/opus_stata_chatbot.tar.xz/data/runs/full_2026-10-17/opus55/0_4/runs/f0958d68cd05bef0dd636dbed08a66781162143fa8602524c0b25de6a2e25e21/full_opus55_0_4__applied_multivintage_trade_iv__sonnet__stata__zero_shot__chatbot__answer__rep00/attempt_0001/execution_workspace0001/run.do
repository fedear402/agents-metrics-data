clear all
set more off

* crosswalk
import delimited using "crosswalk.csv", clear varnames(1) stringcols(_all)
replace code = strtrim(code)
replace industry = strtrim(industry)
duplicates drop code, force
tempfile cw ind
save `cw'
keep industry
duplicates drop
save `ind'

* trade
import delimited using "trade.csv", clear varnames(1) stringcols(2)
replace code = strtrim(code)
merge m:1 code using `cw', keep(match) nogen
collapse (sum) us_change other_change (mean) price_index years, by(period industry)
tempfile tr
save `tr'

* employment
import delimited using "employment.csv", clear varnames(1)
capture confirm string variable industry
if _rc tostring industry, replace
replace industry = strtrim(industry)
replace vintage = lower(strtrim(vintage))
collapse (sum) employment, by(area period vintage industry)
tempfile emp
save `emp'

* areas
import delimited using "areas.csv", clear varnames(1)
replace vintage = lower(strtrim(vintage))
tempfile ar
save `ar'
preserve
keep if vintage=="base"
keep area period population
rename population pop
duplicates drop area period, force
tempfile popf
save `popf'
restore

* full grid
cross using `ind'
merge 1:1 area period vintage industry using `emp', keep(master match) nogen
replace employment = 0 if missing(employment)
bysort period vintage industry: egen nat = total(employment)
merge m:1 period industry using `tr', keep(master match) nogen

gen double chg = cond(vintage=="base", us_change, other_change)
gen double term = (employment/total_employment)*(chg/nat)/(price_index/100)/1000*(10/years)
collapse (sum) term, by(area period vintage)
gen v = cond(vintage=="base","x","z")
drop vintage
reshape wide term, i(area period) j(v) string
rename termx x
rename termz z

merge 1:1 area period using `popf', keep(master match) nogen
tempfile ex
save `ex'

import delimited using "outcomes.csv", clear varnames(1)
merge 1:1 area period using `ex', keep(match) nogen

ivregress 2sls change_pp period control (x = z) [aweight=pop]
local b = _b[x]
local n = e(N)

sort area period
quietly su x if area==0 & period==0
local x0 = r(mean)
quietly su x if area==0 & period==1
local x1 = r(mean)
quietly su z if area==0 & period==0
local z0 = r(mean)

di "ANSWER: iv_slope estimate=" %20.12g `b' " se=NA n_obs=" `n'
di "ANSWER: exposure_area0_period0 estimate=" %20.12g `x0' " se=NA n_obs=" `n'
di "ANSWER: exposure_area0_period1 estimate=" %20.12g `x1' " se=NA n_obs=" `n'
di "ANSWER: instrument_area0_period0 estimate=" %20.12g `z0' " se=NA n_obs=" `n'
