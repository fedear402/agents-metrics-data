clear all
set more off
set type double

* crosswalk
import delimited using "crosswalk.csv", clear stringcols(_all)
rename code code_s
rename industry industry_s
tempfile cw
save `cw'

* trade
import delimited using "trade.csv", clear stringcols(2)
rename code code_s
merge m:1 code_s using `cw', keep(match) nogen
destring industry_s, gen(industry) force
destring period, replace force
keep period industry us_change other_change price_index years
tempfile tr
save `tr'

* employment: fill zeros
import delimited using "employment.csv", clear
replace vintage = strtrim(lower(vintage))
keep area period vintage industry employment
fillin area period vintage industry
replace employment = 0 if missing(employment)
drop _fillin
bysort period vintage industry: egen double national = total(employment)
tempfile emp
save `emp'

* areas
import delimited using "areas.csv", clear
replace vintage = strtrim(lower(vintage))
tempfile ar
save `ar'

use `emp', clear
merge m:1 area period vintage using `ar', keep(match) nogen keepusing(total_employment)
merge m:1 period industry using `tr', keep(match) nogen
gen double cb = employment/total_employment*us_change/national/(price_index/100)/1000*(10/years) if vintage=="base"
gen double ce = employment/total_employment*other_change/national/(price_index/100)/1000*(10/years) if vintage=="early"
collapse (sum) x=cb z=ce, by(area period)
tempfile xz
save `xz'

use `ar', clear
keep if vintage=="base"
keep area period population
merge 1:1 area period using `xz', keep(match) nogen
tempfile pz
save `pz'

import delimited using "outcomes.csv", clear
merge 1:1 area period using `pz', keep(match) nogen

ivregress 2sls change_pp period control (x = z) [aw=population]
local b = _b[x]
local n = e(N)

sum x if area==0 & period==0, meanonly
local x0 = r(mean)
sum x if area==0 & period==1, meanonly
local x1 = r(mean)
sum z if area==0 & period==0, meanonly
local z0 = r(mean)

display "ANSWER: iv_slope estimate=" %24.16g `b' " se=NA n_obs=" `n'
display "ANSWER: exposure_area0_period0 estimate=" %24.16g `x0' " se=NA n_obs=" `n'
display "ANSWER: exposure_area0_period1 estimate=" %24.16g `x1' " se=NA n_obs=" `n'
display "ANSWER: instrument_area0_period0 estimate=" %24.16g `z0' " se=NA n_obs=" `n'
