clear all
set more off
set linesize 255
import delimited using "./input.csv", clear
quietly count
local n = r(N)

* partial out intercept and x
foreach v in y endog z1 z2 {
    quietly regress `v' x
    quietly predict double r_`v', resid
}

mata:
    U  = st_data(., "r_y")
    V  = st_data(., "r_endog")
    Z  = st_data(., ("r_z1","r_z2"))
    n  = rows(U)
    PU = Z*invsym(Z'Z)*(Z'U)
    PV = Z*invsym(Z'Z)*(Z'V)
    a0 = U'PU;  a1 = U'PV;  a2 = V'PV
    c0 = U'U - a0;  c1 = U'V - a1;  c2 = V'V - a2
    k  = invF(2, n-4, 0.95)
    q  = 2*k/(n-4)
    A  = a2 - q*c2
    B  = -2*(a1 - q*c1)
    C  = a0 - q*c0
    disc = B^2 - 4*A*C
    r1 = (-B - sqrt(disc))/(2*A)
    r2 = (-B + sqrt(disc))/(2*A)
    st_numscalar("blo", min((r1,r2)))
    st_numscalar("bhi", max((r1,r2)))
    st_numscalar("acc0", C <= 0)
    st_numscalar("unb", A < 0)
    st_numscalar("disc", disc)
end

* AR F at beta = 1
gen double ytil = y - 1*endog
quietly regress ytil x z1 z2
quietly test z1 z2
scalar f1 = r(F)

display "disc = " disc
display "ANSWER: boundary_low estimate=" %21.12f blo " se=. n_obs=" %12.0f `n'
display "ANSWER: boundary_high estimate=" %21.12f bhi " se=. n_obs=" %12.0f `n'
display "ANSWER: accepts_zero estimate=" %21.12f acc0 " se=. n_obs=" %12.0f `n'
display "ANSWER: unbounded estimate=" %21.12f unb " se=. n_obs=" %12.0f `n'
display "ANSWER: ar_f_at_one estimate=" %21.12f f1 " se=. n_obs=" %12.0f `n'
