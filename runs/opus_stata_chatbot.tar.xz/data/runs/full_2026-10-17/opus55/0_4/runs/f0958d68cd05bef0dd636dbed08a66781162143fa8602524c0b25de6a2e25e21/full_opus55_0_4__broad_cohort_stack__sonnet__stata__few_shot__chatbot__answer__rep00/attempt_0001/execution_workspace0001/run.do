clear all
set more off
set type double

local totw = 0
local wsum = 0
local totn = 0
foreach c in 3 5 7 {
    import delimited using "./input.csv", clear case(preserve)
    keep if time>=`c'-2 & time<=`c'+2
    keep if g==`c' | g==0 | g>`c'+2
    drop if missing(y)
    bysort id: gen int nobs=_N
    keep if nobs==5
    gen byte did=(g==`c' & time>=`c')
    quietly regress y did i.id i.time
    scalar att`c'=_b[did]
    local n`c'=e(N)
    quietly egen byte tag=tag(id)
    quietly count if tag & g==`c'
    local w`c'=r(N)
    local wsum = `wsum' + `w`c''*att`c'
    local totw = `totw' + `w`c''
    local totn = `totn' + `n`c''
}
scalar attw = `wsum'/`totw'
display "ANSWER: att_g3 estimate=" %24.16g att3
display "ANSWER: att_g5 estimate=" %24.16g att5
display "ANSWER: att_g7 estimate=" %24.16g att7
display "ANSWER: att_weighted estimate=" %24.16g attw
exit, clear
