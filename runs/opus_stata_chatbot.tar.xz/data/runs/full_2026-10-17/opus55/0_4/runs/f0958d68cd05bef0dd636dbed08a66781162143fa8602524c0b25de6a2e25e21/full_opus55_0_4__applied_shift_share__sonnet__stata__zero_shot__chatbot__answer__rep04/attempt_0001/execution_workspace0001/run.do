clear all
set more off
set linesize 255

import delimited using "./input.csv", clear varnames(1)

* Region-level normalized weights (one observation per region)
egen byte rtag = tag(region_id)
quietly summarize region_weight if rtag
scalar Wtot = r(sum)
gen double e = region_weight / Wtot

* Shift-share instrument
gen double sz = share * shock
bysort region_id: egen double z = total(sz)

* e-weighted regional means, using one row per region
foreach v in y x z {
    quietly summarize `v' [aw=e] if rtag
    gen double `v'0 = `v' - r(mean)
}

* Shock-level aggregation
gen double w  = e * share
gen double wy = w * y0
gen double wx = w * x0
gen double wz = w * z0
collapse (sum) s=w wy wx wz (mean) shock, by(industry_id)
gen double ybar = wy / s
gen double xbar = wx / s
gen double zbar = wz / s

mata:
void ivhc1(string scalar yv, string scalar xv, string scalar zv, string scalar wv, string scalar bn, string scalar sen)
{
    real colvector y, x, g, w, u, b
    real matrix X, Z, A, Ai, M, V
    real scalar N
    y = st_data(., yv); x = st_data(., xv); g = st_data(., zv); w = st_data(., wv)
    N = rows(y)
    X = (J(N,1,1), x)
    Z = (J(N,1,1), g)
    A = Z' * (w :* X)
    Ai = luinv(A)
    b = Ai * (Z' * (w :* y))
    u = y - X * b
    M = (Z :* (w :* u))' * (Z :* (w :* u))
    V = (N/(N-2)) * Ai * M * Ai'
    st_numscalar(bn, b[2])
    st_numscalar(sen, sqrt(V[2,2]))
}
end

mata: ivhc1("ybar", "xbar", "shock", "s", "b_eff", "se_eff")
mata: ivhc1("xbar", "zbar", "shock", "s", "b_fs", "se_fs")

gen double s2 = s^2
quietly summarize s2
scalar eff_shocks = 1 / r(sum)
scalar Nind = _N

display "ANSWER: effect estimate=" %21.12f b_eff " se=" %21.12f se_eff " n_obs=" %12.0f Nind
display "ANSWER: first_stage estimate=" %21.12f b_fs " se=" %21.12f se_fs " n_obs=" %12.0f Nind
display "ANSWER: effective_shocks estimate=" %21.12f eff_shocks " se=. n_obs=" %12.0f Nind
