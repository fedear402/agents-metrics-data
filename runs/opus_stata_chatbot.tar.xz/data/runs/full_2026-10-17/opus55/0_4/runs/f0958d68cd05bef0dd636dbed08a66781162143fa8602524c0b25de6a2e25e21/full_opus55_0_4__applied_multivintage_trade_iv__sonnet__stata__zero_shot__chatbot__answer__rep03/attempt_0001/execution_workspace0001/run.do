clear all
set more off

* crosswalk
import delimited using "crosswalk.csv", clear stringcols(_all)
replace code = strtrim(code)
replace industry = strtrim(industry)
duplicates drop code, force
tempfile cw
save `cw'

* trade
import delimited using "trade.csv", clear stringcols(2)
replace code = strtrim(code)
merge m:1 code using `cw', keep(match) nogen
keep period industry us_change other_change price_index years
tempfile tr
save `tr'

* industries list
use `cw', clear
keep industry
duplicates drop
tempfile ind
save `ind'

* areas
import delimited using "areas.csv", clear
capture tostring vintage, replace
replace vintage = lower(strtrim(vintage))
tempfile ar
save `ar'

* employment
import delimited using "employment.csv", clear stringcols(4)
capture tostring vintage, replace
replace vintage = lower(strtrim(vintage))
replace industry = strtrim(industry)
collapse (sum) employment, by(area period vintage industry)
tempfile em
save `em'

* full grid
use `ar', clear
keep area period vintage total_employment
cross using `ind'
merge 1:1 area period vintage industry using `em', keep(master match) nogen
replace employment = 0 if missing(employment)

bysort period vintage industry: egen double natemp = total(employment)
merge m:1 period industry using `tr', keep(master match) nogen

gen double chg = cond(vintage=="base", us_change, other_change)
gen double term = (employment/total_employment)*(chg/natemp)/(price_index/100)/1000*(10/years)
collapse (sum) expo = term, by(area period vintage)

gen double x_ = expo if vintage=="base"
gen double z_ = expo if vintage=="early"
collapse (max) x = x_ z = z_, by(area period)
tempfile ex
save `ex'

* population (base vintage)
use `ar', clear
keep if vintage=="base"
keep area period population
duplicates drop area period, force
tempfile pop
save `pop'

import delimited using "outcomes.csv", clear
merge 1:1 area period using `ex', keep(match) nogen
merge 1:1 area period using `pop', keep(match) nogen

capture confirm numeric variable period
if _rc {
    encode period, gen(period_n)
    drop period
    rename period_n period
}

ivregress 2sls change_pp period control (x = z) [aw=population]
local b = _b[x]
local n = e(N)

quietly summarize x if area==0 & period==0
local x0 = r(mean)
quietly summarize x if area==0 & period==1
local x1 = r(mean)
quietly summarize z if area==0 & period==0
local z0 = r(mean)

display "ANSWER: iv_slope estimate=" %20.12g `b' " se=NA n_obs=" `n'
display "ANSWER: exposure_area0_period0 estimate=" %20.12g `x0' " se=NA n_obs=" `n'
display "ANSWER: exposure_area0_period1 estimate=" %20.12g `x1' " se=NA n_obs=" `n'
display "ANSWER: instrument_area0_period0 estimate=" %20.12g `z0' " se=NA n_obs=" `n'
