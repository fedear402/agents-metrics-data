clear all
set more off
set type double

* crosswalk
import delimited using "crosswalk.csv", clear varnames(1)
tostring code, replace force
replace code = strtrim(code)
tostring industry, replace force
replace industry = strtrim(industry)
keep code industry
tempfile cw
save `cw'

* industries list
keep industry
duplicates drop
tempfile inds
save `inds'

* trade
import delimited using "trade.csv", clear varnames(1)
tostring code, replace force
replace code = strtrim(code)
merge m:1 code using `cw', keep(match) nogenerate
keep period industry us_change other_change price_index years
tempfile tr
save `tr'

* areas
import delimited using "areas.csv", clear varnames(1)
tostring vintage, replace force
replace vintage = lower(strtrim(vintage))
tempfile ar
save `ar'
preserve
keep if vintage=="base"
keep area period population
tempfile pop
save `pop'
restore

* employment
import delimited using "employment.csv", clear varnames(1)
tostring vintage, replace force
replace vintage = lower(strtrim(vintage))
tostring industry, replace force
replace industry = strtrim(industry)
collapse (sum) employment, by(area period vintage industry)
tempfile em
save `em'

* full grid
use `ar', clear
keep area period vintage total_employment
cross using `inds'
merge 1:1 area period vintage industry using `em', keep(master match) nogenerate
replace employment = 0 if missing(employment)

bysort period vintage industry: egen double national = total(employment)
merge m:1 period industry using `tr', keep(match) nogenerate

gen double chg = cond(vintage=="base", us_change, other_change)
gen double term = (employment/total_employment)*(chg/national)/(price_index/100)/1000*(10/years)
collapse (sum) term, by(area period vintage)
gen v = cond(vintage=="base","x","z")
drop vintage
reshape wide term, i(area period) j(v) string
rename termx x
rename termz z

merge 1:1 area period using `pop', keep(match) nogenerate
tempfile ex
save `ex'

import delimited using "outcomes.csv", clear varnames(1)
merge 1:1 area period using `ex', keep(match) nogenerate

ivregress 2sls change_pp period control (x = z) [aw=population]
local b = _b[x]
local n = e(N)

sort area period
quietly summarize period
local p0 = r(min)
local p1 = r(max)
quietly summarize x if area==0 & period==`p0'
local x0 = r(mean)
quietly summarize x if area==0 & period==`p1'
local x1 = r(mean)
quietly summarize z if area==0 & period==`p0'
local z0 = r(mean)

display "ANSWER: iv_slope estimate=" %24.16g `b' " se=NA n_obs=" `n'
display "ANSWER: exposure_area0_period0 estimate=" %24.16g `x0' " se=NA n_obs=" `n'
display "ANSWER: exposure_area0_period1 estimate=" %24.16g `x1' " se=NA n_obs=" `n'
display "ANSWER: instrument_area0_period0 estimate=" %24.16g `z0' " se=NA n_obs=" `n'
