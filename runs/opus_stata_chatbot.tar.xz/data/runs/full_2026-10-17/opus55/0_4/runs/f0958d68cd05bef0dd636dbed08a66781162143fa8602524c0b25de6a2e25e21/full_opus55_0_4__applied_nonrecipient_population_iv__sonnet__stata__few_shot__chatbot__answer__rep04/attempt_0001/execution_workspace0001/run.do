clear all
set more off
set type double
import delimited using "households.csv", clear varnames(1)
keep if recipient==0
gen double inel = 1-eligible
gen double el = eligible
gen double d0 = dose*inel
gen double d1 = dose*el
gen double b0x = baseline*inel
gen double b1x = baseline*el
gen double z0 = instrument*inel
gen double z1 = instrument*el
ivregress 2sls outcome inel el b0x b1x (d0 d1 = z0 z1) [aw=weight], noconstant
scalar s0=_b[d0]
scalar s1=_b[d1]
count if eligible==0 & e(sample)
scalar c0=r(N)
count if eligible==1 & e(sample)
scalar c1=r(N)
scalar ntot=c0+c1
summarize dose [aw=weight] if eligible==0 & e(sample), meanonly
scalar e0=s0*r(mean)
summarize dose [aw=weight] if eligible==1 & e(sample), meanonly
scalar e1=s1*r(mean)
import delimited using "census.csv", clear varnames(1)
summarize nonrecipient_population if eligible==0, meanonly
scalar n0=r(sum)
summarize nonrecipient_population if eligible==1, meanonly
scalar n1=r(sum)
scalar pe=(e0*n0+e1*n1)/(n0+n1)
display "ANSWER: ineligible_effect estimate=" %24.16g e0 " se=NA n_obs=" %12.0f c0
display "ANSWER: eligible_nonrecipient_effect estimate=" %24.16g e1 " se=NA n_obs=" %12.0f c1
display "ANSWER: population_effect estimate=" %24.16g pe " se=NA n_obs=" %12.0f ntot
