clear all
set more off
set type double

local wsum = 0
local wtot = 0
local ntot = 0

foreach c in 3 5 7 {
    import delimited using "./input.csv", clear varnames(1)
    keep if time>=`c'-2 & time<=`c'+2
    keep if g==`c' | g==0 | g>`c'+2
    drop if missing(y)
    bysort id: gen int _nt=_N
    keep if _nt==5
    drop _nt
    gen byte did=(g==`c' & time>=`c')
    quietly regress y did i.id i.time
    scalar att`c'=_b[did]
    scalar n`c'=e(N)
    quietly egen byte _tag=tag(id) if g==`c'
    quietly count if _tag==1
    scalar w`c'=r(N)
    local wsum = `wsum' + w`c'*att`c'
    local wtot = `wtot' + w`c'
    local ntot = `ntot' + n`c'
}

scalar attw = `wsum'/`wtot'

display "ANSWER: att_g3 estimate=" %24.16g att3
display "ANSWER: att_g5 estimate=" %24.16g att5
display "ANSWER: att_g7 estimate=" %24.16g att7
display "ANSWER: att_weighted estimate=" %24.16g attw
exit, clear
