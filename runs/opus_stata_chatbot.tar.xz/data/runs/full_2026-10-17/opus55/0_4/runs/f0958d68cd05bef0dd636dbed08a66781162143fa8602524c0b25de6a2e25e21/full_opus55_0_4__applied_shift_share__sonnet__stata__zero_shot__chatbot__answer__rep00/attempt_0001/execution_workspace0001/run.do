clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

* Regional weights normalized once using one observation per region
bysort region_id (industry_id): gen byte rtag = (_n == 1)
quietly summarize region_weight if rtag
gen double e = region_weight / r(sum)

* Shift-share instrument
gen double sz = share * shock
bysort region_id: egen double z = total(sz)

* Regional 2SLS and first stage (point estimates)
quietly ivregress 2sls y (x = z) [aw = e] if rtag
scalar b_effect = _b[x]
quietly regress x z [aw = e] if rtag
scalar b_first = _b[z]

* Demean using e-weighted regional means
foreach v in y x z {
    quietly summarize `v' [aw = e] if rtag
    gen double `v'0 = `v' - r(mean)
}

* Shock-level aggregation
gen double w  = e * share
gen double wy = w * y0
gen double wx = w * x0
gen double wz = w * z0
collapse (sum) s = w wy wx wz (mean) shock, by(industry_id)
keep if s > 0 & !missing(s)
gen double ybar = wy / s
gen double xbar = wx / s
gen double zbar = wz / s
scalar N_ind = _N

* Effect: shock-level IV with HC1
quietly ivregress 2sls ybar (xbar = shock) [aw = s], vce(robust) small
scalar b_effect_sl = _b[xbar]
scalar se_effect = _se[xbar]

* First stage: shock-level IV of xbar on zbar instrumented by shock
quietly ivregress 2sls xbar (zbar = shock) [aw = s], vce(robust) small
scalar b_first_sl = _b[zbar]
scalar se_first = _se[zbar]

* Effective number of shocks
gen double s2 = s^2
quietly summarize s2
scalar eff_shocks = 1 / r(sum)

display "Check: regional slope " %21.12f b_effect " shock-level slope " %21.12f b_effect_sl
display "Check: regional FS " %21.12f b_first " shock-level FS " %21.12f b_first_sl

display "ANSWER: effect estimate=" %21.12f b_effect " se=" %21.12f se_effect " n_obs=" %12.0f N_ind
display "ANSWER: first_stage estimate=" %21.12f b_first " se=" %21.12f se_first " n_obs=" %12.0f N_ind
display "ANSWER: effective_shocks estimate=" %21.12f eff_shocks " se=. n_obs=" %12.0f N_ind
