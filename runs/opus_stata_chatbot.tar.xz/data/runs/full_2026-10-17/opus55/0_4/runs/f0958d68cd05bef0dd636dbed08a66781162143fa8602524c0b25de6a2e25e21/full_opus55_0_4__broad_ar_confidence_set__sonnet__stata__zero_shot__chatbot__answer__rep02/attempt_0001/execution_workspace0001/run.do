clear all
set more off
set linesize 255

import delimited using "./input.csv", clear
keep if !missing(y, endog, x, z1, z2)
local n = _N

* Residualize on intercept and x
foreach v in y endog z1 z2 {
    quietly regress `v' x
    quietly predict double r_`v', residuals
}

* Cross products of W-residualized variables
quietly matrix accum A = r_y r_endog, noconstant
scalar Syy = A[1,1]
scalar Syd = A[1,2]
scalar Sdd = A[2,2]

* Projection of residualized y and endog on residualized instruments
quietly regress r_y r_z1 r_z2, noconstant
quietly predict double py, xb
quietly regress r_endog r_z1 r_z2, noconstant
quietly predict double pd, xb
quietly matrix accum B = py pd, noconstant
scalar Pyy = B[1,1]
scalar Pyd = B[1,2]
scalar Pdd = B[2,2]

scalar dfd = `n' - 4
scalar cc = invFtail(2, dfd, 0.05)
scalar mult = dfd + 2*cc

* Accept iff qa*b^2 + qb*b + qk <= 0
scalar qa = mult*Pdd - 2*cc*Sdd
scalar qb = -2*(mult*Pyd - 2*cc*Syd)
scalar qk = mult*Pyy - 2*cc*Syy

scalar disc = qb^2 - 4*qa*qk
scalar r1 = (-qb - sqrt(disc))/(2*qa)
scalar r2 = (-qb + sqrt(disc))/(2*qa)
scalar blow = min(r1, r2)
scalar bhigh = max(r1, r2)

scalar acc0 = (qk <= 0)
scalar unb = (qa <= 0)

* AR F statistic at beta = 1
gen double ytil1 = y - 1*endog
quietly regress ytil1 x z1 z2
quietly test z1 z2
scalar f1 = r(F)

display "ANSWER: boundary_low estimate=" %21.12f blow " se=" "." " n_obs=" %12.0f `n'
display "ANSWER: boundary_high estimate=" %21.12f bhigh " se=" "." " n_obs=" %12.0f `n'
display "ANSWER: accepts_zero estimate=" %21.12f acc0 " se=" "." " n_obs=" %12.0f `n'
display "ANSWER: unbounded estimate=" %21.12f unb " se=" "." " n_obs=" %12.0f `n'
display "ANSWER: ar_f_at_one estimate=" %21.12f f1 " se=" "." " n_obs=" %12.0f `n'
