clear all
set more off
set type double

* Crosswalk
import delimited using "crosswalk.csv", clear varnames(1) case(lower)
tostring code, replace force
replace code = trim(code)
keep code industry
duplicates drop
tempfile cw ind tr emp
save `cw'
keep industry
duplicates drop
save `ind'

* Trade joined to industries
import delimited using "trade.csv", clear varnames(1) case(lower)
tostring code, replace force
replace code = trim(code)
merge m:1 code using `cw', keep(match) nogen
keep period industry us_change other_change price_index years
save `tr'

* Employment
import delimited using "employment.csv", clear varnames(1) case(lower)
replace vintage = lower(trim(vintage))
collapse (sum) employment, by(area period vintage industry)
save `emp'

* Areas x industries grid, zero-fill missing cells
import delimited using "areas.csv", clear varnames(1) case(lower)
replace vintage = lower(trim(vintage))
keep area period vintage total_employment population
cross using `ind'
merge 1:1 area period vintage industry using `emp', keep(master match) nogen
replace employment = 0 if missing(employment)

* National industry employment within period and vintage
bysort period vintage industry: egen double nat = total(employment)

merge m:1 period industry using `tr', keep(master match) nogen

gen double chg = cond(vintage=="base", us_change, other_change)
gen double t = (employment/total_employment)*(chg/nat)/(price_index/100)/1000*(10/years)
gen double popb = cond(vintage=="base", population, .)

collapse (sum) t (max) popb, by(area period vintage)
bysort area period: egen double x = max(cond(vintage=="base", t, .))
bysort area period: egen double z = max(cond(vintage=="early", t, .))
bysort area period: egen double pop = max(popb)
keep if vintage=="base"
keep area period x z pop

tempfile ex
save `ex'
import delimited using "outcomes.csv", clear varnames(1) case(lower)
keep area period control change_pp
merge 1:1 area period using `ex', keep(match) nogen

ivregress 2sls change_pp period control (x = z) [aw=pop]
local b = _b[x]
local n = e(N)

sum x if area==0 & period==0, meanonly
local x0 = r(mean)
sum x if area==0 & period==1, meanonly
local x1 = r(mean)
sum z if area==0 & period==0, meanonly
local z0 = r(mean)

display "ANSWER: iv_slope estimate=" %24.16g `b' " se=NA n_obs=" `n'
display "ANSWER: exposure_area0_period0 estimate=" %24.16g `x0' " se=NA n_obs=" `n'
display "ANSWER: exposure_area0_period1 estimate=" %24.16g `x1' " se=NA n_obs=" `n'
display "ANSWER: instrument_area0_period0 estimate=" %24.16g `z0' " se=NA n_obs=" `n'
