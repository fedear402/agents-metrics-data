clear all
set more off
set type double

* crosswalk
import delimited using "crosswalk.csv", clear stringcols(_all)
replace code=strtrim(code)
replace industry=strtrim(industry)
duplicates drop code, force
tempfile cw inds trd ar emp
save `cw'
keep industry
duplicates drop
save `inds'

* trade
import delimited using "trade.csv", clear stringcols(2)
replace code=strtrim(code)
merge m:1 code using `cw', keep(match) nogen
keep period industry us_change other_change price_index years
save `trd'

* areas
import delimited using "areas.csv", clear
capture confirm string variable vintage
if _rc tostring vintage, replace
replace vintage=lower(strtrim(vintage))
save `ar'

* employment
import delimited using "employment.csv", clear
capture confirm string variable vintage
if _rc tostring vintage, replace
replace vintage=lower(strtrim(vintage))
capture confirm string variable industry
if _rc tostring industry, replace
replace industry=strtrim(industry)
collapse (sum) employment, by(area period vintage industry)
save `emp'

* full grid
use `ar', clear
keep area period vintage
duplicates drop
cross using `inds'
merge 1:1 area period vintage industry using `emp', keep(master match) nogen
replace employment=0 if missing(employment)
bysort period vintage industry: egen double nat=total(employment)
merge m:1 area period vintage using `ar', keepusing(total_employment) keep(match) nogen
merge m:1 period industry using `trd', keep(match) nogen
gen double chg=cond(vintage=="base", us_change, other_change)
gen double contrib=(employment/total_employment)*(chg/nat)/(price_index/100)/1000*(10/years)
collapse (sum) contrib, by(area period vintage)
gen v=cond(vintage=="base","x","z")
drop vintage
reshape wide contrib, i(area period) j(v) string
rename contribx x
rename contribz z

* weights
preserve
use `ar', clear
keep if vintage=="base"
keep area period population
duplicates drop area period, force
tempfile pop
save `pop'
restore
merge 1:1 area period using `pop', keep(match) nogen

* outcomes
preserve
import delimited using "outcomes.csv", clear
tempfile out
save `out'
restore
merge 1:1 area period using `out', keep(match) nogen

ivregress 2sls change_pp period control (x=z) [aw=population]
local b=_b[x]
local n=e(N)

sort area period
summarize x if area==0 & period==0, meanonly
local x0=r(mean)
summarize x if area==0 & period==1, meanonly
local x1=r(mean)
summarize z if area==0 & period==0, meanonly
local z0=r(mean)

display "ANSWER: iv_slope estimate=" %24.16g `b' " se=NA n_obs=" `n'
display "ANSWER: exposure_area0_period0 estimate=" %24.16g `x0' " se=NA n_obs=" `n'
display "ANSWER: exposure_area0_period1 estimate=" %24.16g `x1' " se=NA n_obs=" `n'
display "ANSWER: instrument_area0_period0 estimate=" %24.16g `z0' " se=NA n_obs=" `n'
