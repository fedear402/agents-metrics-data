version 14
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear
sort t
tsset t

arima y, arima(1,1,1) noconstant
scalar nobs = e(N)

tsappend, add(1)
predict double yhat, y
predict double mse_d, mse

quietly summarize t
scalar tmax = r(max)
quietly summarize yhat if t == tmax
scalar fc = r(mean)
quietly summarize mse_d if t == tmax
scalar fse = sqrt(r(mean))

scalar z = invnormal(0.975)
scalar lo = fc - z*fse
scalar hi = fc + z*fse

display "ANSWER: forecast estimate=" %21.12f fc " se=" %21.12f fse " n_obs=" %12.0f nobs
display "ANSWER: lower_95 estimate=" %21.12f lo " se=" "." " n_obs=" %12.0f nobs
display "ANSWER: upper_95 estimate=" %21.12f hi " se=" "." " n_obs=" %12.0f nobs
