clear all
set more off
set linesize 255
import delimited using "./input.csv", clear
mata:
    st_view(V=., ., ("y","endog","x","z1","z2"))
    y = V[,1]; d = V[,2]; n = rows(V)
    one = J(n,1,1)
    X = (one, V[,3])
    W = (X, V[,4..5])
    MX = I(n) - X*invsym(X'X)*X'
    MW = I(n) - W*invsym(W'W)*W'
    Xyy = y'MX*y; Xyd = y'MX*d; Xdd = d'MX*d
    Wyy = y'MW*y; Wyd = y'MW*d; Wdd = d'MW*d
    cv = invF(2, n-4, 0.95)
    k = 2*cv/(n-4)
    a  = (Xdd-Wdd) - k*Wdd
    b  = -2*((Xyd-Wyd) - k*Wyd)
    c0 = (Xyy-Wyy) - k*Wyy
    disc = b^2 - 4*a*c0
    r1 = (-b - sqrt(disc))/(2*a)
    r2 = (-b + sqrt(disc))/(2*a)
    lo = min((r1,r2)); hi = max((r1,r2))
    unb = (a < 0)
    acc0 = (c0 <= 0)
    N1 = (Xyy-2*Xyd+Xdd) - (Wyy-2*Wyd+Wdd)
    D1 = Wyy-2*Wyd+Wdd
    f1 = (N1/2)/(D1/(n-4))
    st_numscalar("lo", lo); st_numscalar("hi", hi)
    st_numscalar("unb", unb); st_numscalar("acc0", acc0)
    st_numscalar("f1", f1); st_numscalar("nobs", n)
end
display "ANSWER: boundary_low estimate=" %21.12f lo " se=. n_obs=" %12.0f nobs
display "ANSWER: boundary_high estimate=" %21.12f hi " se=. n_obs=" %12.0f nobs
display "ANSWER: accepts_zero estimate=" %21.12f acc0 " se=. n_obs=" %12.0f nobs
display "ANSWER: unbounded estimate=" %21.12f unb " se=. n_obs=" %12.0f nobs
display "ANSWER: ar_f_at_one estimate=" %21.12f f1 " se=. n_obs=" %12.0f nobs
