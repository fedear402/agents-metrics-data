version 19.0
clear all
set more off
set linesize 255
import delimited using "./input.csv", clear varnames(1)
keep if abs(score)<1 & !missing(score, participated, earnings)
gen double w = 1-abs(score)
gen double above = score>=0
gen double s_above = score*above
quietly count
local n = r(N)
mata:
s=st_data(.,"score")
a=st_data(.,"above")
sa=st_data(.,"s_above")
w=st_data(.,"w")
Y=st_data(.,("earnings","participated"))
X=(J(rows(Y),1,1),s,a,sa)
bread=invsym(X'*(w:*X))
b=bread*X'*(w:*Y)
r=Y-X*b
c=(0\0\1\0)
j=c'*b
load=w:*(X*bread*c)
inf=load:*r
V=inf'*inf
g=(1/j[2]\-j[1]/j[2]^2)
st_numscalar("rf",j[1])
st_numscalar("fs",j[2])
st_numscalar("rf_se",sqrt(V[1,1]))
st_numscalar("fs_se",sqrt(V[2,2]))
st_numscalar("te",j[1]/j[2])
st_numscalar("te_se",sqrt(g'*V*g))
end
display "ANSWER: treatment_effect estimate=" %21.12f te " se=" %21.12f te_se " n_obs=" %12.0f `n'
display "ANSWER: reduced_form estimate=" %21.12f rf " se=" %21.12f rf_se " n_obs=" %12.0f `n'
display "ANSWER: first_stage estimate=" %21.12f fs " se=" %21.12f fs_se " n_obs=" %12.0f `n'
