version 19.0
clear all
set more off
set linesize 255
import delimited using "./input.csv", clear varnames(1)
capture confirm numeric variable date
if _rc {
    generate double day=date(date,"YMD")
}
else {
    generate double day=date
}
sort day
generate long observation=_n
tsset observation
generate double log_vix=log(vix)
generate double vix_change=D.log_vix
generate double log_sales=log(sales)
local regs ""
forvalues k=1/15 {
    generate double change_lag`k'=L`k'.vix_change
    local regs "`regs' change_lag`k'"
}
keep if !missing(log_sales `regs')
mata:
X=(J(st_nobs(),1,1),st_data(.,tokens(st_local("regs"))))
y=st_data(.,"log_sales")
b=qrsolve(X,y)
e=y-X*b
N=rows(X)
p=cols(X)
s=X:*e
L=15
meat=s'*s
for (j=1;j<=L;j++) {
    lp=s[|j+1,1\N,p|]'*s[|1,1\N-j,p|]
    meat=meat+(1-j/(L+1))*(lp+lp')
}
bread=invsym(X'*X)
V=N/(N-p)*bread*meat*bread
c=(0\J(15,1,1))
cum=c'*b
cumse=sqrt(c'*V*c)
printf("ANSWER: cumulative_response estimate=%21.15g se=%21.15g n_obs=%12.0f\n",cum,cumse,N)
printf("ANSWER: lag_1 estimate=%21.15g se=%21.15g n_obs=%12.0f\n",b[2],sqrt(V[2,2]),N)
printf("ANSWER: lag_15 estimate=%21.15g se=%21.15g n_obs=%12.0f\n",b[16],sqrt(V[16,16]),N)
end
