version 19.0
clear all
set more off
set linesize 255
import delimited using "./input.csv", clear varnames(1)
sort region_id industry_id
mata:
R = st_data(., "region_id")
I = st_data(., "industry_id")
sh = st_data(., "share")
shk = st_data(., "shock")
w = st_data(., "region_weight")
xv = st_data(., "x")
yv = st_data(., "y")
ureg = uniqrows(R)
uind = uniqrows(I)
nr = rows(ureg)
ni = rows(uind)
S = J(nr, ni, 0)
g = J(ni, 1, .)
e = J(nr, 1, .)
x = J(nr, 1, .)
y = J(nr, 1, .)
for (k=1; k<=rows(R); k++) {
    r = selectindex(ureg:==R[k])
    n = selectindex(uind:==I[k])
    S[r,n] = S[r,n] + sh[k]
    g[n] = shk[k]
    e[r] = w[k]
    x[r] = xv[k]
    y[r] = yv[k]
}
e = e/sum(e)
z = S*g
reg = (y, x, z)
c = reg :- e'*reg
s = S'*e
agg = (S'*(e:*c)):/s
N = ni
est = J(2,2,.)
for (q=1; q<=2; q++) {
    dep = agg[,q]
    X = (J(N,1,1), agg[,q+1])
    Z = (J(N,1,1), g)
    inv = luinv(Z'*(s:*X))
    b = inv*Z'*(s:*dep)
    u = dep - X*b
    sc = Z:*(s:*u)
    V = N/(N-2)*inv*(sc'*sc)*inv'
    est[q,] = (b[2], sqrt(V[2,2]))
}
st_numscalar("b1", est[1,1]); st_numscalar("se1", est[1,2])
st_numscalar("b2", est[2,1]); st_numscalar("se2", est[2,2])
st_numscalar("effs", 1/sum(s:^2))
st_numscalar("nn", N)
end
display "ANSWER: effect estimate=" %21.12f b1 " se=" %21.12f se1 " n_obs=" %12.0f nn
display "ANSWER: first_stage estimate=" %21.12f b2 " se=" %21.12f se2 " n_obs=" %12.0f nn
display "ANSWER: effective_shocks estimate=" %21.12f effs " se=. n_obs=" %12.0f nn
