clear all
set more off
import delimited using "census.csv", clear varnames(1)
keep eligible nonrecipient_population
collapse (sum) nonrecipient_population, by(eligible)
tempfile cen
save `cen'
quietly su nonrecipient_population if eligible==0
scalar P0 = r(sum)
quietly su nonrecipient_population if eligible==1
scalar P1 = r(sum)

import delimited using "households.csv", clear varnames(1)
keep if recipient==0
drop if missing(outcome, dose, instrument, baseline, weight, eligible)
gen double ie = 1-eligible
gen double el = eligible
gen double d0 = dose*ie
gen double d1 = dose*el
gen double b0 = baseline*ie
gen double b1 = baseline*el
gen double z0 = instrument*ie
gen double z1 = instrument*el
ivregress 2sls outcome ie el b0 b1 (d0 d1 = z0 z1) [aweight=weight], noconstant
scalar s0 = _b[d0]
scalar s1 = _b[d1]
local N = e(N)
quietly su dose [aweight=weight] if eligible==0
scalar m0 = r(mean)
quietly su dose [aweight=weight] if eligible==1
scalar m1 = r(mean)
scalar e0 = s0*m0
scalar e1 = s1*m1
scalar ep = (P0*e0 + P1*e1)/(P0+P1)
di "ANSWER: ineligible_effect estimate=" %20.12g e0 " se=NA n_obs=" `N'
di "ANSWER: eligible_nonrecipient_effect estimate=" %20.12g e1 " se=NA n_obs=" `N'
di "ANSWER: population_effect estimate=" %20.12g ep " se=NA n_obs=" `N'
