clear all
set more off
set linesize 255
set type double
import delimited using "./input.csv", clear
keep if !missing(y, endog, x, z1, z2)
quietly count
scalar nobs = r(N)
quietly regress y x
predict double ry, residuals
quietly regress endog x
predict double rd, residuals
quietly regress y x z1 z2
predict double uy, residuals
scalar df = e(df_r)
quietly regress endog x z1 z2
predict double ud, residuals
scalar q = 2
scalar critical = invFtail(q, df, .05)
scalar k = q*critical/df
mata:
ry=st_data(.,"ry"); rd=st_data(.,"rd")
uy=st_data(.,"uy"); ud=st_data(.,"ud")
k=st_numscalar("k"); q=st_numscalar("q"); df=st_numscalar("df")
A=quadcross(rd,rd)-(1+k)*quadcross(ud,ud)
B=-2*(quadcross(ry,rd)-(1+k)*quadcross(uy,ud))
C=quadcross(ry,ry)-(1+k)*quadcross(uy,uy)
disc=B^2-4*A*C
assert(abs(A)>1e-12 & disc>0)
bounds=sort(((-B-sqrt(disc))/(2*A)\(-B+sqrt(disc))/(2*A)),1)
st_numscalar("low",bounds[1]); st_numscalar("high",bounds[2])
st_numscalar("unbounded",A<0); st_numscalar("accepts_zero",C<=0)
er=ry-rd; eu=uy-ud
ssrR=quadcross(er,er); ssrU=quadcross(eu,eu)
st_numscalar("f1",((ssrR-ssrU)/q)/(ssrU/df))
end
display "ANSWER: boundary_low estimate=" %21.12f (low) " se=." " n_obs=" %12.0f (nobs)
display "ANSWER: boundary_high estimate=" %21.12f (high) " se=." " n_obs=" %12.0f (nobs)
display "ANSWER: accepts_zero estimate=" %21.12f (accepts_zero) " se=." " n_obs=" %12.0f (nobs)
display "ANSWER: unbounded estimate=" %21.12f (unbounded) " se=." " n_obs=" %12.0f (nobs)
display "ANSWER: ar_f_at_one estimate=" %21.12f (f1) " se=." " n_obs=" %12.0f (nobs)
