clear all
set more off
set linesize 255

import delimited using "./input.csv", clear
sort t
tsset t

* ARIMA(1,1,1) by ML with no constant/drift
arima y, arima(1,1,1) noconstant
local nobs = e(N)

* extend the sample by one period to t = 251
tsappend, add(1)

* one-step-ahead forecast in levels and its MSE
predict double yhat, y
predict double fmse, mse

quietly summarize t
local tmax = r(max)
quietly summarize yhat if t == `tmax'
scalar fc = r(mean)
quietly summarize fmse if t == `tmax'
scalar fse = sqrt(r(mean))

scalar z = invnormal(0.975)
scalar lo = fc - z*fse
scalar hi = fc + z*fse

display "Forecast target t = " `tmax'
display "ANSWER: forecast estimate=" %21.12f fc " se=" %21.12f fse " n_obs=" %12.0f `nobs'
display "ANSWER: lower_95 estimate=" %21.12f lo " se=" "." " n_obs=" %12.0f `nobs'
display "ANSWER: upper_95 estimate=" %21.12f hi " se=" "." " n_obs=" %12.0f `nobs'
