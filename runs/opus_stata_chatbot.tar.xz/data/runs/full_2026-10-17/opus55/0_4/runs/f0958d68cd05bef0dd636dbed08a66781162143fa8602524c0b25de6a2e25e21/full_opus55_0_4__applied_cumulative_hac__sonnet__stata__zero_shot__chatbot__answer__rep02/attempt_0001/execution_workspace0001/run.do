clear all
set more off
set linesize 255

import delimited "./input.csv", clear varnames(1)

capture confirm string variable date
if _rc == 0 {
    gen double d = date(date, "YMD")
    capture assert !missing(d)
    if _rc {
        replace d = date(date, "MDY") if missing(d)
    }
    capture assert !missing(d)
    if _rc {
        replace d = date(date, "DMY") if missing(d)
    }
}
else {
    gen double d = date
}
sort d
gen long t = _n
tsset t

gen double lsales = ln(sales)
gen double dlvix = ln(vix) - ln(L.vix)

newey lsales L(1/15).dlvix, lag(15)
scalar nobs = e(N)

scalar b1 = _b[L1.dlvix]
scalar se1 = _se[L1.dlvix]
scalar b15 = _b[L15.dlvix]
scalar se15 = _se[L15.dlvix]

lincom L1.dlvix + L2.dlvix + L3.dlvix + L4.dlvix + L5.dlvix + L6.dlvix + L7.dlvix + L8.dlvix + L9.dlvix + L10.dlvix + L11.dlvix + L12.dlvix + L13.dlvix + L14.dlvix + L15.dlvix
scalar cr = r(estimate)
scalar cr_se = r(se)

display "ANSWER: cumulative_response estimate=" %21.12f cr " se=" %21.12f cr_se " n_obs=" %12.0f nobs
display "ANSWER: lag_1 estimate=" %21.12f b1 " se=" %21.12f se1 " n_obs=" %12.0f nobs
display "ANSWER: lag_15 estimate=" %21.12f b15 " se=" %21.12f se15 " n_obs=" %12.0f nobs
