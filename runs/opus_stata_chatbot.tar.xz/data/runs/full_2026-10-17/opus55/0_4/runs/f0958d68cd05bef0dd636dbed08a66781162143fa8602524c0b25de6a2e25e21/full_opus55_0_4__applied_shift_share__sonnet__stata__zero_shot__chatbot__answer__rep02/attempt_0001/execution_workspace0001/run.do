clear all
set more off
set linesize 255

import delimited "./input.csv", clear varnames(1)

* One observation per region for weight normalization
bysort region_id (industry_id): gen byte firstr = (_n == 1)
quietly summarize region_weight if firstr
scalar sumw = r(sum)
gen double e = region_weight / sumw

* Shift-share instrument
gen double sz = share * shock
bysort region_id: egen double z = total(sz)

* Regional weighted 2SLS (point estimate)
quietly ivregress 2sls y (x = z) [aw = e] if firstr
scalar b_effect = _b[x]

* Regional first stage (point estimate)
quietly regress x z [aw = e] if firstr
scalar b_fs = _b[z]

* e-weighted regional demeaning
foreach v in y x z {
    quietly summarize `v' [aw = e] if firstr
    gen double `v'0 = `v' - r(mean)
}

* Shock-level aggregation
gen double w  = e * share
gen double wy = w * y0
gen double wx = w * x0
gen double wz = w * z0
collapse (sum) s = w wy wx wz (mean) shock, by(industry_id)
keep if s > 0
gen double ybar = wy / s
gen double xbar = wx / s
gen double zbar = wz / s

quietly count
scalar N_ind = r(N)

* Effect: shock-level IV, HC1 with N/(N-2)
quietly ivregress 2sls ybar (xbar = shock) [aw = s], vce(robust) small
scalar b_effect_sl = _b[xbar]
scalar se_effect = _se[xbar]

* First stage: shock-level IV of xbar on zbar instrumented by shock
quietly ivregress 2sls xbar (zbar = shock) [aw = s], vce(robust) small
scalar b_fs_sl = _b[zbar]
scalar se_fs = _se[zbar]

* Effective number of shocks
gen double s2 = s^2
quietly summarize s2
scalar eff_shocks = 1 / r(sum)

display "Check: regional effect=" %21.12f b_effect " shock-level=" %21.12f b_effect_sl
display "Check: regional first stage=" %21.12f b_fs " shock-level=" %21.12f b_fs_sl

display "ANSWER: effect estimate=" %21.12f b_effect " se=" %21.12f se_effect " n_obs=" %12.0f N_ind
display "ANSWER: first_stage estimate=" %21.12f b_fs " se=" %21.12f se_fs " n_obs=" %12.0f N_ind
display "ANSWER: effective_shocks estimate=" %21.12f eff_shocks " se=. n_obs=" %12.0f N_ind
