clear all
set more off
set linesize 255

import delimited using "./input.csv", clear varnames(1)

capture confirm string variable group
if !_rc {
    replace group = strtrim(group)
    drop if group == ""
    encode group, gen(group_id)
}
else {
    drop if missing(group)
    gen group_id = group
}

capture confirm string variable y
if !_rc {
    destring y, replace force
}
drop if missing(y)

oneway y group_id

scalar F_stat = r(F)
scalar df_num = r(df_m)
scalar df_den = r(df_r)
scalar n_obs  = r(N)
scalar p_val  = Ftail(df_num, df_den, F_stat)

display "ANSWER: F estimate=" %21.12f F_stat " se=. n_obs=" %12.0f n_obs
display "ANSWER: df_num estimate=" %21.12f df_num " se=. n_obs=" %12.0f n_obs
display "ANSWER: df_den estimate=" %21.12f df_den " se=. n_obs=" %12.0f n_obs
display "ANSWER: p_value estimate=" %21.12f p_val " se=. n_obs=" %12.0f n_obs
