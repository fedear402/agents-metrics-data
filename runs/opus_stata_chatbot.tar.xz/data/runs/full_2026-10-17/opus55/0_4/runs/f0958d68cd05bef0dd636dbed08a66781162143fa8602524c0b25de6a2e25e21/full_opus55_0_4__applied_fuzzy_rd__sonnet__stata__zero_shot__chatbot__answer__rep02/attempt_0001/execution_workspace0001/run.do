clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

keep if abs(score) < 1 & !missing(score, participated, earnings)
gen double w = 1 - abs(score)
gen double d = (score >= 0)
gen double ds = d * score
gen double cons = 1

mata:
    X  = st_data(., ("cons", "d", "score", "ds"))
    y  = st_data(., "earnings")
    t  = st_data(., "participated")
    w  = st_data(., "w")
    n  = rows(X)
    XW = X :* w
    B  = invsym(cross(XW, X))
    by = B * cross(XW, y)
    bt = B * cross(XW, t)
    ey = y - X * by
    et = t - X * bt
    Uy = X :* (w :* ey)
    Ut = X :* (w :* et)
    Vyy = B * cross(Uy, Uy) * B
    Vtt = B * cross(Ut, Ut) * B
    Vyt = B * cross(Uy, Ut) * B
    rf  = by[2]
    fs  = bt[2]
    vrf = Vyy[2,2]
    vfs = Vtt[2,2]
    cov = Vyt[2,2]
    te  = rf / fs
    g   = (1/fs, -rf/(fs^2))
    V   = (vrf, cov \ cov, vfs)
    vte = g * V * g'
    st_numscalar("rf", rf)
    st_numscalar("fs", fs)
    st_numscalar("te", te)
    st_numscalar("se_rf", sqrt(vrf))
    st_numscalar("se_fs", sqrt(vfs))
    st_numscalar("se_te", sqrt(vte))
    st_numscalar("nobs", n)
end

display "ANSWER: treatment_effect estimate=" %21.12f te " se=" %21.12f se_te " n_obs=" %12.0f nobs
display "ANSWER: reduced_form estimate=" %21.12f rf " se=" %21.12f se_rf " n_obs=" %12.0f nobs
display "ANSWER: first_stage estimate=" %21.12f fs " se=" %21.12f se_fs " n_obs=" %12.0f nobs
