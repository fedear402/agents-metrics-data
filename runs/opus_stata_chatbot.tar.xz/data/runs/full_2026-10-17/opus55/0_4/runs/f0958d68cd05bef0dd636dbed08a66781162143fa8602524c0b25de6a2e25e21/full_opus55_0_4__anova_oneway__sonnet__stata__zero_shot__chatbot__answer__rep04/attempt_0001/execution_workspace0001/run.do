version 14
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear varnames(1)

* group may be string or numeric; create numeric grouping variable
capture confirm string variable group
if _rc == 0 {
    encode group, gen(grp)
}
else {
    gen grp = group
}

capture confirm numeric variable y
if _rc != 0 {
    destring y, replace force
}

keep if !missing(y) & !missing(grp)

oneway y grp

scalar Fstat = r(F)
scalar dfn = r(df_m)
scalar dfd = r(df_r)
scalar nobs = r(N)
scalar pval = Ftail(dfn, dfd, Fstat)

display "ANSWER: F estimate=" %21.12f Fstat " se=." " n_obs=" %12.0f nobs
display "ANSWER: df_num estimate=" %21.12f dfn " se=." " n_obs=" %12.0f nobs
display "ANSWER: df_den estimate=" %21.12f dfd " se=." " n_obs=" %12.0f nobs
display "ANSWER: p_value estimate=" %21.12f pval " se=." " n_obs=" %12.0f nobs
