clear all
set more off

* crosswalk
import delimited using "crosswalk.csv", clear varnames(1) stringcols(_all)
replace code = strtrim(code)
replace industry = strtrim(industry)
keep code industry
duplicates drop
tempfile cw inds
save `cw'
keep industry
duplicates drop
save `inds'

* trade
import delimited using "trade.csv", clear varnames(1) stringcols(2)
replace code = strtrim(code)
merge m:1 code using `cw', keep(match) nogenerate
keep period industry us_change other_change price_index years
tempfile tr
save `tr'

* areas
import delimited using "areas.csv", clear varnames(1)
replace vintage = lower(strtrim(vintage))
tempfile ar
save `ar'
preserve
keep if vintage=="base"
keep area period population
tempfile pop
save `pop'
restore

* employment grid
keep area period vintage total_employment
cross using `inds'
tempfile grid
save `grid'

import delimited using "employment.csv", clear varnames(1) stringcols(4)
replace vintage = lower(strtrim(vintage))
replace industry = strtrim(industry)
collapse (sum) employment, by(area period vintage industry)
merge 1:1 area period vintage industry using `grid', keep(match using) nogenerate
replace employment = 0 if missing(employment)

bysort period vintage industry: egen double nat = total(employment)
merge m:1 period industry using `tr', keep(match) nogenerate

gen double chg = cond(vintage=="base", us_change, other_change)
gen double term = (employment/total_employment)*(chg/nat)/(price_index/100)/1000*(10/years)
collapse (sum) term, by(area period vintage)
gen v = cond(vintage=="base","x","z")
drop vintage
reshape wide term, i(area period) j(v) string
rename termx x
rename termz z

merge 1:1 area period using `pop', keep(match) nogenerate
tempfile ex
save `ex'

import delimited using "outcomes.csv", clear varnames(1)
merge 1:1 area period using `ex', keep(match) nogenerate

ivregress 2sls change_pp period control (x = z) [aweight=population]
local b = _b[x]
local n = e(N)

sum x if area==0 & period==0, meanonly
local x0 = r(mean)
sum x if area==0 & period==1, meanonly
local x1 = r(mean)
sum z if area==0 & period==0, meanonly
local z0 = r(mean)

di "ANSWER: iv_slope estimate=" %20.12g `b' " se=NA n_obs=" `n'
di "ANSWER: exposure_area0_period0 estimate=" %20.12g `x0' " se=NA n_obs=" `n'
di "ANSWER: exposure_area0_period1 estimate=" %20.12g `x1' " se=NA n_obs=" `n'
di "ANSWER: instrument_area0_period0 estimate=" %20.12g `z0' " se=NA n_obs=" `n'
