clear
set linesize 255
import delimited using "./input.csv", clear varnames(1)
capture confirm string variable group
if _rc == 0 {
    encode group, gen(group_n)
}
else {
    gen group_n = group
}
capture confirm string variable y
if _rc == 0 {
    destring y, replace force
}
drop if missing(y) | missing(group_n)
oneway y group_n
scalar Fv = r(F)
scalar dfn = r(df_m)
scalar dfd = r(df_r)
scalar nn = r(N)
scalar pv = Ftail(dfn, dfd, Fv)
display "ANSWER: F estimate=" %21.12f Fv " se=. n_obs=" %12.0f nn
display "ANSWER: df_num estimate=" %21.12f dfn " se=. n_obs=" %12.0f nn
display "ANSWER: df_den estimate=" %21.12f dfd " se=. n_obs=" %12.0f nn
display "ANSWER: p_value estimate=" %21.12f pv " se=. n_obs=" %12.0f nn
