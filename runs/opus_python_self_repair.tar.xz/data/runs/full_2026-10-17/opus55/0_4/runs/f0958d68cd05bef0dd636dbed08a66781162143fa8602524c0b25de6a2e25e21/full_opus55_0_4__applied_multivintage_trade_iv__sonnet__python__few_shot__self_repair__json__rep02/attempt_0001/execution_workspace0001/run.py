import json
import numpy as np
import pandas as pd

S = str
cw = pd.read_csv("crosswalk.csv", dtype={"code": S, "industry": S})
tr = pd.read_csv("trade.csv", dtype={"code": S, "period": S})
ar = pd.read_csv("areas.csv", dtype={"area": S, "period": S, "vintage": S})
em = pd.read_csv("employment.csv", dtype={"area": S, "period": S, "vintage": S, "industry": S})
oc = pd.read_csv("outcomes.csv", dtype={"area": S, "period": S})
for d in (cw, tr, ar, em, oc):
    for c in d.columns:
        if d[c].dtype == object:
            d[c] = d[c].str.strip()
ar["vintage"] = ar["vintage"].str.lower()
em["vintage"] = em["vintage"].str.lower()

tr = tr.merge(cw[["code", "industry"]], on="code", how="inner")
inds = sorted(cw["industry"].unique())
periods = sorted(oc["period"].unique())

grid = ar[["area", "period", "vintage"]].drop_duplicates()
e = em.groupby(["area", "period", "vintage", "industry"])["employment"].sum().unstack("industry")
e = e.reindex(columns=inds).fillna(0.0)
e = grid.set_index(["area", "period", "vintage"]).join(e).fillna(0.0)
e = e[inds]

def exposure(vint, col):
    out = {}
    for p in periods:
        t = tr[tr["period"] == p].set_index("industry")
        price = float(t["price_index"].iloc[0]); yrs = float(t["years"].iloc[0])
        chg = t[col].reindex(inds).fillna(0.0).astype(float).values
        sub = e.xs((p, vint), level=("period", "vintage"))
        nat = sub.sum(axis=0).values
        shock = chg / nat / (price / 100.0) / 1000.0 * (10.0 / yrs)
        tot = ar[(ar["period"] == p) & (ar["vintage"] == vint)].set_index("area")["total_employment"].astype(float)
        val = sub.values @ shock
        s = pd.Series(val, index=sub.index) / tot.reindex(sub.index)
        for a, v in s.items():
            out[(a, p)] = v
    return out

xd = exposure("base", "us_change")
zd = exposure("early", "other_change")
pop = ar[ar["vintage"] == "base"].groupby(["area", "period"])["population"].first()

df = oc.copy()
df["x"] = [xd.get((a, p), np.nan) for a, p in zip(df["area"], df["period"])]
df["z"] = [zd.get((a, p), np.nan) for a, p in zip(df["area"], df["period"])]
df["w"] = [pop.get((a, p), np.nan) for a, p in zip(df["area"], df["period"])]
pn = pd.to_numeric(df["period"], errors="coerce")
if pn.isna().any():
    pn = pd.Series(pd.factorize(df["period"], sort=True)[0], index=df.index).astype(float)
df["pnum"] = pn.astype(float)
df = df.dropna(subset=["x", "z", "w", "change_pp", "control", "pnum"])

n = len(df)
y = df["change_pp"].astype(float).values
ex = np.column_stack([np.ones(n), df["pnum"].values, df["control"].astype(float).values])
X = np.column_stack([ex, df["x"].values])
Z = np.column_stack([ex, df["z"].values])
sw = np.sqrt(df["w"].astype(float).values)
Xw, Zw, yw = X * sw[:, None], Z * sw[:, None], y * sw
Pz = Zw @ np.linalg.pinv(Zw.T @ Zw) @ Zw.T
beta = np.linalg.solve(Xw.T @ Pz @ Xw, Xw.T @ Pz @ yw)
fs = np.linalg.lstsq(Zw, Xw[:, -1], rcond=None)[0]

a0 = sorted(df["area"].unique(), key=lambda s: (pd.to_numeric(s, errors="coerce"), s))[0]
a0 = "0" if ("0", periods[0]) in xd else a0
p0, p1 = periods[0], periods[1] if len(periods) > 1 else periods[0]

def est(t, v):
    return {"term": t, "estimate": float(v), "se": None, "n_obs": int(n)}

res = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [
        est("iv_slope", beta[-1]),
        est("exposure_area0_period0", xd[(a0, p0)]),
        est("exposure_area0_period1", xd[(a0, p1)]),
        est("instrument_area0_period0", zd[(a0, p0)]),
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS (manual numpy)",
        "regressors": ["intercept", "period", "control", "x"],
        "instruments": ["intercept", "period", "control", "z"],
        "weights": "base-vintage population",
    },
    "diagnostics": {
        "n_obs": int(n),
        "coefficients": [float(b) for b in beta],
        "first_stage_z_coef": float(fs[-1]),
        "periods": list(map(str, periods)),
    },
}
with open("result.json", "w") as f:
    json.dump(res, f, indent=2)
