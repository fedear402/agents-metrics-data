import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df["region_id"] = df["region_id"].astype(str)
df["industry_id"] = df["industry_id"].astype(str)

regions = sorted(df["region_id"].unique())
industries = sorted(df["industry_id"].unique())

reg = df.groupby("region_id").agg(region_weight=("region_weight", "first"),
                                  x=("x", "first"), y=("y", "first")).loc[regions]
shock = df.groupby("industry_id")["shock"].first().loc[industries].to_numpy(float)

shares = (df.pivot_table(index="region_id", columns="industry_id", values="share",
                         aggfunc="sum").reindex(index=regions, columns=industries)
          .fillna(0.0).to_numpy(float))

e = reg["region_weight"].to_numpy(float)
e = e / e.sum()
x = reg["x"].to_numpy(float)
y = reg["y"].to_numpy(float)
z = shares @ shock

regional = np.column_stack([y, x, z])
centered = regional - e @ regional
s = e @ shares
keep = s > 0
agg = (shares.T @ (e[:, None] * centered))[keep] / s[keep][:, None]
s_k = s[keep]
g_k = shock[keep]
N = int(keep.sum())


def shock_iv(dep, endog):
    X = np.column_stack([np.ones(N), endog])
    Z = np.column_stack([np.ones(N), g_k])
    cross = Z.T @ (s_k[:, None] * X)
    beta = np.linalg.solve(cross, Z.T @ (s_k * dep))
    resid = dep - X @ beta
    scores = Z * (s_k * resid)[:, None]
    inv = np.linalg.inv(cross)
    cov = (N / (N - 2)) * inv @ (scores.T @ scores) @ inv.T
    return float(beta[1]), float(np.sqrt(cov[1, 1]))


effect, effect_se = shock_iv(agg[:, 0], agg[:, 1])
fs, fs_se = shock_iv(agg[:, 1], agg[:, 2])

y0, x0, z0 = centered[:, 0], centered[:, 1], centered[:, 2]
reg_effect = np.sum(e * z0 * y0) / np.sum(e * z0 * x0)
reg_fs = np.sum(e * z0 * x0) / np.sum(e * z0 ** 2)

eff_shocks = float(1.0 / np.sum(s ** 2))

out = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": float(reg_effect), "se": effect_se, "n_obs": N},
        {"term": "first_stage", "estimate": float(reg_fs), "se": fs_se, "n_obs": N},
        {"term": "effective_shocks", "estimate": eff_shocks, "se": None, "n_obs": N},
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS with shift-share instrument; BHJ shock-level equivalent IV",
        "vcov": "shock-level HC1 (N/(N-2)), structural IV residuals, analytic weights s_n",
    },
    "diagnostics": {
        "shock_level_effect": effect,
        "shock_level_first_stage": fs,
        "n_regions": len(regions),
    },
}
with open("result.json", "w") as f:
    json.dump(out, f, indent=2, allow_nan=False)
