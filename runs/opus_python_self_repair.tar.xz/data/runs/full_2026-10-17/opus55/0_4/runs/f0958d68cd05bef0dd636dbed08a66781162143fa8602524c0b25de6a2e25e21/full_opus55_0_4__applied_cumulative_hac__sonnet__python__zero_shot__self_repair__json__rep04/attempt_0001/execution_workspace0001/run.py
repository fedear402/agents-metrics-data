import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df["date"] = pd.to_datetime(df["date"])
df = df.sort_values("date").reset_index(drop=True)

df["ly"] = np.log(df["sales"].astype(float))
df["dv"] = np.log(df["vix"].astype(float)).diff()
L = 15
cols = []
for j in range(1, L + 1):
    c = f"lag_{j}"
    df[c] = df["dv"].shift(j)
    cols.append(c)

d = df.dropna(subset=["ly"] + cols).reset_index(drop=True)
y = d["ly"].to_numpy()
X = np.column_stack([np.ones(len(d))] + [d[c].to_numpy() for c in cols])
N, K = X.shape

XtX_inv = np.linalg.inv(X.T @ X)
beta = XtX_inv @ (X.T @ y)
u = y - X @ beta

g = X * u[:, None]
S = g.T @ g
for j in range(1, L + 1):
    w = 1.0 - j / (L + 1.0)
    G = g[j:].T @ g[:-j]
    S += w * (G + G.T)
V = XtX_inv @ S @ XtX_inv
V *= N / (N - K)

a = np.zeros(K)
a[1:] = 1.0
cum = float(a @ beta)
cum_se = float(np.sqrt(a @ V @ a))

res = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {"term": "cumulative_response", "estimate": cum, "se": cum_se, "n_obs": int(N)},
        {"term": "lag_1", "estimate": float(beta[1]), "se": float(np.sqrt(V[1, 1])), "n_obs": int(N)},
        {"term": "lag_15", "estimate": float(beta[15]), "se": float(np.sqrt(V[15, 15])), "n_obs": int(N)},
    ],
    "method_metadata": {
        "estimator": "OLS of log(sales) on intercept and lags 1-15 of dlog(vix)",
        "vcov": "Newey-West HAC, maxlag 15, Bartlett weights 1-j/16, scaled by N/(N-16)",
    },
    "diagnostics": {},
}
with open("result.json", "w") as f:
    json.dump(res, f, indent=2)
