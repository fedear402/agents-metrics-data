import json
import numpy as np
import pandas as pd
from scipy import stats

df = pd.read_csv("input.csv")
df = df[["y", "endog", "x", "z1", "z2"]].dropna()
n = len(df)
y = df["y"].to_numpy(float)
d = df["endog"].to_numpy(float)
one = np.ones(n)
W = np.column_stack([one, df["x"].to_numpy(float)])
Z = np.column_stack([W, df["z1"].to_numpy(float), df["z2"].to_numpy(float)])

def resid(X, v):
    b, *_ = np.linalg.lstsq(X, v, rcond=None)
    return v - X @ b

ryW, rdW = resid(W, y), resid(W, d)
ryZ, rdZ = resid(Z, y), resid(Z, d)

df2 = n - 4
crit = stats.f.ppf(0.95, 2, df2)
k = 2.0 * crit / df2

def q(a1, b1, a2, b2):
    # v'(M_W - M_Z - k M_Z)w = v'M_W w - (1+k) v'M_Z w
    return a1 @ b1 - (1 + k) * (a2 @ b2)

Qyy = q(ryW, ryW, ryZ, ryZ)
Qyd = q(ryW, rdW, ryZ, rdZ)
Qdd = q(rdW, rdW, rdZ, rdZ)
# accept iff a*b^2 + bb*b + c <= 0
a, bb, c = Qdd, -2 * Qyd, Qyy

def ar_f(beta):
    uW = ryW - beta * rdW
    uZ = ryZ - beta * rdZ
    rss_r, rss_u = uW @ uW, uZ @ uZ
    return ((rss_r - rss_u) / 2.0) / (rss_u / df2)

disc = bb * bb - 4 * a * c
roots = []
if disc >= 0 and a != 0:
    s = np.sqrt(disc)
    roots = sorted([(-bb - s) / (2 * a), (-bb + s) / (2 * a)])
low = float(roots[0]) if roots else float("nan")
high = float(roots[1]) if roots else float("nan")
unbounded = 1 if a <= 0 else 0
accepts_zero = 1 if ar_f(0.0) <= crit else 0
f1 = float(ar_f(1.0))

def row(t, e):
    return {"term": t, "estimate": float(e), "se": None, "n_obs": int(n)}

res = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": [
        row("boundary_low", low),
        row("boundary_high", high),
        row("accepts_zero", accepts_zero),
        row("unbounded", unbounded),
        row("ar_f_at_one", f1),
    ],
    "method_metadata": {"estimator": "Anderson-Rubin test inversion (analytic quadratic)",
                        "vcov": "homoskedastic F(2, n-4)"},
    "diagnostics": {"f_crit": float(crit), "quad_a": float(a), "quad_b": float(bb),
                    "quad_c": float(c), "disjoint": int(a < 0 and disc > 0)},
}
with open("result.json", "w") as f:
    json.dump(res, f, indent=2)
