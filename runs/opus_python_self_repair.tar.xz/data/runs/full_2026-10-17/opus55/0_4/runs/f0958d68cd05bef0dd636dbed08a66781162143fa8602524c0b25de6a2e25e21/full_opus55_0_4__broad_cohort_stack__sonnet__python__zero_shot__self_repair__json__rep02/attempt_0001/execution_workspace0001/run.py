import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df = df.dropna(subset=["id", "time", "g"])

results = []
weights = []
ests = []
nobs_total = 0

for c in [3, 5, 7]:
    times = list(range(c - 2, c + 3))
    d = df[df["time"].isin(times)]
    d = d[(d["g"] == c) | (d["g"] == 0) | (d["g"] > c + 2)].copy()
    d = d.dropna(subset=["y"])
    cnt = d.groupby("id")["time"].nunique()
    keep = cnt[cnt == len(times)].index
    d = d[d["id"].isin(keep)].copy()
    d["did"] = ((d["g"] == c) & (d["time"] >= c)).astype(float)

    # two-way FE regression via dummies
    U = pd.get_dummies(d["id"].astype(str), prefix="u", drop_first=False, dtype=float)
    T = pd.get_dummies(d["time"].astype(int).astype(str), prefix="t", drop_first=True, dtype=float)
    X = np.column_stack([d["did"].values, U.values, T.values])
    yv = d["y"].values.astype(float)
    beta, *_ = np.linalg.lstsq(X, yv, rcond=None)
    att = float(beta[0])

    n_obs = int(len(d))
    n_treated = int(d.loc[d["g"] == c, "id"].nunique())
    results.append({"term": f"att_g{c}", "estimate": att, "se": None, "n_obs": n_obs})
    weights.append(n_treated)
    ests.append(att)
    nobs_total += n_obs

w = np.array(weights, dtype=float)
att_w = float(np.sum(w * np.array(ests)) / np.sum(w))
results.append({"term": "att_weighted", "estimate": att_w, "se": None, "n_obs": int(nobs_total)})

out = {
    "task_id": "broad_cohort_stack",
    "platform": "python",
    "estimates": results,
    "method_metadata": {
        "method": "cohort-specific balanced-window TWFE DiD, treated-unit weighted average",
        "cohorts": [3, 5, 7],
    },
    "diagnostics": {
        "treated_units": {f"g{c}": int(n) for c, n in zip([3, 5, 7], weights)},
    },
}

with open("result.json", "w") as f:
    json.dump(out, f, indent=2)
