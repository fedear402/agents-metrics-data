import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df = df.dropna(subset=["score", "participated", "earnings"])
df = df[np.abs(df["score"]) < 1].copy()

s = df["score"].to_numpy(dtype=float)
d = df["participated"].to_numpy(dtype=float)
y = df["earnings"].to_numpy(dtype=float)
w = 1.0 - np.abs(s)
right = (s >= 0).astype(float)
n = len(df)

# Design: intercept, right-side jump, left slope, slope change on right
X = np.column_stack([np.ones(n), right, s, right * s])
XtWX = X.T @ (X * w[:, None])
bread = np.linalg.inv(XtWX)

def wls(v):
    b = bread @ (X.T @ (w * v))
    return b, v - X @ b

by, ey = wls(y)
bd, ed = wls(d)

def meat(e1, e2):
    return (X * (w * e1)[:, None]).T @ (X * (w * e2)[:, None])

V_yy = bread @ meat(ey, ey) @ bread
V_dd = bread @ meat(ed, ed) @ bread
V_yd = bread @ meat(ey, ed) @ bread

rf, fs = by[1], bd[1]
var_rf, var_fs, cov_rf_fs = V_yy[1, 1], V_dd[1, 1], V_yd[1, 1]
te = rf / fs
g = np.array([1.0 / fs, -rf / fs ** 2])
Sigma = np.array([[var_rf, cov_rf_fs], [cov_rf_fs, var_fs]])
var_te = float(g @ Sigma @ g)

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": float(te), "se": float(np.sqrt(var_te)), "n_obs": int(n)},
        {"term": "reduced_form", "estimate": float(rf), "se": float(np.sqrt(var_rf)), "n_obs": int(n)},
        {"term": "first_stage", "estimate": float(fs), "se": float(np.sqrt(var_fs)), "n_obs": int(n)},
    ],
    "method_metadata": {
        "estimator": "fuzzy RD, local linear with separate slopes, triangular kernel, bandwidth 1, cutoff 0; ratio of reduced form to first stage",
        "vcov": "HC0 sandwich, joint covariance of reduced form and first stage; delta method for ratio",
    },
    "diagnostics": {
        "n_left": int((right == 0).sum()),
        "n_right": int((right == 1).sum()),
        "cov_reduced_form_first_stage": float(cov_rf_fs),
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
