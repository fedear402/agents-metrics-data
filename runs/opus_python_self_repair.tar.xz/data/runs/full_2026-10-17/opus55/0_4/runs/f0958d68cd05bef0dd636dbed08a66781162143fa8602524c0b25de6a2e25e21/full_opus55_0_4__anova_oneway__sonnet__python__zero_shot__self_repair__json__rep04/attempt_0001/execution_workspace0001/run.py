import json
import numpy as np
import pandas as pd
from scipy import stats

df = pd.read_csv("./input.csv")
n_raw = len(df)
df = df[["group", "y"]].copy()
df["y"] = pd.to_numeric(df["y"], errors="coerce")
df = df.dropna(subset=["group", "y"])
df["group"] = df["group"].astype(str).str.strip()
df = df[df["group"] != ""]

groups = [g["y"].to_numpy(dtype=float) for _, g in df.groupby("group", sort=True)]
k = len(groups)
n = int(sum(len(g) for g in groups))

grand = df["y"].mean()
ssb = float(sum(len(g) * (g.mean() - grand) ** 2 for g in groups))
ssw = float(sum(((g - g.mean()) ** 2).sum() for g in groups))
df_num = k - 1
df_den = n - k
msb = ssb / df_num if df_num > 0 else float("nan")
msw = ssw / df_den if df_den > 0 else float("nan")
F = msb / msw if msw and msw > 0 else float("nan")
p = float(stats.f.sf(F, df_num, df_den)) if np.isfinite(F) else float("nan")

# cross-check with scipy
try:
    F_sp, p_sp = stats.f_oneway(*groups)
    F_sp, p_sp = float(F_sp), float(p_sp)
except Exception:
    F_sp, p_sp = None, None

# Levene test as diagnostic
try:
    lev_stat, lev_p = stats.levene(*groups, center="median")
    lev_stat, lev_p = float(lev_stat), float(lev_p)
except Exception:
    lev_stat, lev_p = None, None

def clean(x):
    return None if x is None or not np.isfinite(x) else float(x)

result = {
    "task_id": "anova_oneway",
    "platform": "python",
    "estimates": [
        {"term": "F", "estimate": clean(F), "se": None, "n_obs": n},
        {"term": "df_num", "estimate": float(df_num), "se": None, "n_obs": n},
        {"term": "df_den", "estimate": float(df_den), "se": None, "n_obs": n},
        {"term": "p_value", "estimate": clean(p), "se": None, "n_obs": n},
    ],
    "method_metadata": {
        "estimator": "one-way ANOVA (classical, equal variances assumed)",
        "vcov": "homoskedastic (pooled within-group variance)",
    },
    "diagnostics": {
        "n_rows_raw": int(n_raw),
        "n_rows_dropped": int(n_raw - n),
        "n_groups": int(k),
        "group_sizes": {str(name): int(len(g)) for name, g in df.groupby("group", sort=True)["y"]},
        "ss_between": ssb,
        "ss_within": ssw,
        "scipy_F": clean(F_sp) if F_sp is not None else None,
        "scipy_p": clean(p_sp) if p_sp is not None else None,
        "levene_median_stat": clean(lev_stat) if lev_stat is not None else None,
        "levene_median_p": clean(lev_p) if lev_p is not None else None,
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
