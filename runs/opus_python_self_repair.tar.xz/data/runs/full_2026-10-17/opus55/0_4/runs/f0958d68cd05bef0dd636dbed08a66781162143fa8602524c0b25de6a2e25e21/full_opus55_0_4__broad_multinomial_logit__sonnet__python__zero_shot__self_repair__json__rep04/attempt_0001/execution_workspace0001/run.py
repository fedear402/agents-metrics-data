import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("input.csv")
n_full = int(len(df))
d = df[["y", "x", "z"]].dropna().copy()
d["y"] = d["y"].astype(int)

X = sm.add_constant(d[["x", "z"]], has_constant="add")
model = sm.MNLogit(d["y"], X)
res = model.fit(method="newton", maxiter=200, disp=False)
if not res.mle_retvals.get("converged", True):
    res = model.fit(method="bfgs", maxiter=5000, disp=False)

params = res.params  # columns correspond to outcomes 1, 2 (base 0)
bse = res.bse
cols = list(params.columns)
# map column index to outcome labels
cats = sorted(d["y"].unique())
nonbase = [c for c in cats if c != 0]
colmap = {nonbase[i]: cols[i] for i in range(len(cols))}

def g(tbl, var, cat):
    return float(tbl.loc[var, colmap[cat]])

xb1 = g(params, "const", 1)
xb2 = g(params, "const", 2)
denom = 1.0 + np.exp(xb1) + np.exp(xb2)
p2 = float(np.exp(xb2) / denom)

est = []
for term, var, cat in [("x_cat1", "x", 1), ("z_cat1", "z", 1),
                       ("x_cat2", "x", 2), ("z_cat2", "z", 2)]:
    est.append({"term": term, "estimate": g(params, var, cat),
                "se": g(bse, var, cat), "n_obs": n_full})
est.append({"term": "prob_cat2_zero", "estimate": p2, "se": None, "n_obs": n_full})

out = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": est,
    "method_metadata": {"estimator": "statsmodels MNLogit maximum likelihood, base outcome 0",
                        "vcov": "observed information (inverse negative Hessian)"},
    "diagnostics": {"converged": bool(res.mle_retvals.get("converged", True)),
                    "llf": float(res.llf), "n_used": int(res.nobs)},
}
with open("result.json", "w") as f:
    json.dump(out, f, indent=2)
