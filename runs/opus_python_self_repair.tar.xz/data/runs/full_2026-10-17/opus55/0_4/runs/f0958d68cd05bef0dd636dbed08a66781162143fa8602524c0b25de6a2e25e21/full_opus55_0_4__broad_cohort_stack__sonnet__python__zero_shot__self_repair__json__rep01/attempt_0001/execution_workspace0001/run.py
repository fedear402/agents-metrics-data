import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df = df[["id", "time", "g", "y"]].copy()

estimates = []
atts = {}
weights = {}
nobs_total = 0
diag = {}

for c in (3, 5, 7):
    times = list(range(c - 2, c + 3))
    sub = df[df["time"].isin(times)]
    sub = sub[(sub["g"] == c) | (sub["g"] == 0) | (sub["g"] > c + 2)]
    cnt = sub.groupby("id")["time"].nunique()
    keep = cnt[cnt == len(times)].index
    sub = sub[sub["id"].isin(keep)].copy()
    sub = sub.dropna(subset=["y"])
    sub["did"] = ((sub["g"] == c) & (sub["time"] >= c)).astype(float)

    uid = pd.get_dummies(sub["id"].astype(str), prefix="u", drop_first=True, dtype=float)
    tfe = pd.get_dummies(sub["time"].astype(str), prefix="t", drop_first=True, dtype=float)
    X = np.column_stack([np.ones(len(sub)), sub["did"].values, uid.values, tfe.values])
    yv = sub["y"].values.astype(float)
    beta, *_ = np.linalg.lstsq(X, yv, rcond=None)
    att = float(beta[1])

    n_treated = int(sub.loc[sub["g"] == c, "id"].nunique())
    n_obs = int(len(sub))
    atts[c] = att
    weights[c] = n_treated
    nobs_total += n_obs
    diag[f"g{c}"] = {
        "n_treated_units": n_treated,
        "n_control_units": int(sub.loc[sub["g"] != c, "id"].nunique()),
        "n_obs": n_obs,
    }
    estimates.append({"term": f"att_g{c}", "estimate": att, "se": None, "n_obs": n_obs})

wsum = sum(weights.values())
att_w = float(sum(atts[c] * weights[c] for c in atts) / wsum) if wsum > 0 else float("nan")
estimates.append({"term": "att_weighted", "estimate": att_w, "se": None, "n_obs": int(nobs_total)})

result = {
    "task_id": "broad_cohort_stack",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "method": "cohort-specific TWFE DiD with unit and time FE, balanced 5-period windows",
        "weights": "number of retained treated units per cohort",
    },
    "diagnostics": diag,
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
