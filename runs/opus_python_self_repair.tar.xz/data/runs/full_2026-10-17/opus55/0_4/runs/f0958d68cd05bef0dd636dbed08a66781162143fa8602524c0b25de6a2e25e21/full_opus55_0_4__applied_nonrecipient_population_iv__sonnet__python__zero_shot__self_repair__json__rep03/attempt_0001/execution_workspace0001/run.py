import json
import numpy as np
import pandas as pd

hh = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

d = hh[hh["recipient"] == 0].copy()
d = d.dropna(subset=["eligible", "instrument", "dose", "baseline", "weight", "outcome"])
d = d[d["weight"] > 0]
n_obs = int(len(d))

e = d["eligible"].astype(float).values
ne = 1.0 - e
dose = d["dose"].astype(float).values
base = d["baseline"].astype(float).values
z = d["instrument"].astype(float).values
w = d["weight"].astype(float).values
y = d["outcome"].astype(float).values

X = np.column_stack([dose * ne, dose * e, ne, e, base * ne, base * e])
Z = np.column_stack([ne, e, base * ne, base * e, z * ne, z * e])

sw = np.sqrt(w)
Xw = X * sw[:, None]
Zw = Z * sw[:, None]
yw = y * sw

# First stage projection
pi, *_ = np.linalg.lstsq(Zw, Xw, rcond=None)
Xhat = Zw @ pi
beta, *_ = np.linalg.lstsq(Xhat, yw, rcond=None)

b_ine, b_el = float(beta[0]), float(beta[1])

m0 = e == 0
m1 = e == 1
mean_dose_ine = float(np.sum(w[m0] * dose[m0]) / np.sum(w[m0]))
mean_dose_el = float(np.sum(w[m1] * dose[m1]) / np.sum(w[m1]))

eff_ine = b_ine * mean_dose_ine
eff_el = b_el * mean_dose_el

pop0 = float(census.loc[census["eligible"] == 0, "nonrecipient_population"].sum())
pop1 = float(census.loc[census["eligible"] == 1, "nonrecipient_population"].sum())
pop_eff = (pop0 * eff_ine + pop1 * eff_el) / (pop0 + pop1)

def r(v):
    return float(f"{v:.15g}")

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {"term": "ineligible_effect", "estimate": r(eff_ine), "se": None, "n_obs": n_obs},
        {"term": "eligible_nonrecipient_effect", "estimate": r(eff_el), "se": None, "n_obs": n_obs},
        {"term": "population_effect", "estimate": r(pop_eff), "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "sample": "recipient == 0",
        "endogenous": ["dose*(1-eligible)", "dose*eligible"],
        "exogenous": ["1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"],
        "excluded_instruments": ["instrument*(1-eligible)", "instrument*eligible"],
        "weights": "weight",
        "counterfactual": "dose set to zero for all retained households (synthetic convention)",
        "aggregation": "census nonrecipient_population weights",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "n_ineligible": int(m0.sum()),
        "n_eligible": int(m1.sum()),
        "dose_slope_ineligible": r(b_ine),
        "dose_slope_eligible": r(b_el),
        "weighted_mean_dose_ineligible": r(mean_dose_ine),
        "weighted_mean_dose_eligible": r(mean_dose_el),
        "census_pop_ineligible": r(pop0),
        "census_pop_eligible": r(pop1),
        "coefficients": [r(v) for v in beta],
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
