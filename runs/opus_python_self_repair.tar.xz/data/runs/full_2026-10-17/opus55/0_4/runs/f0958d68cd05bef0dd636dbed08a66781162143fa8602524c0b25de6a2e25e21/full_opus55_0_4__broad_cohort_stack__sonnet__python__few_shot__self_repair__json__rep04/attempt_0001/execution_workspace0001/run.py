import json
import numpy as np
import pandas as pd

df = pd.read_csv('input.csv')
df = df.dropna(subset=['id', 'time', 'g'])
df['time'] = df['time'].astype(int)
df['g'] = df['g'].astype(int)

cohorts = [3, 5, 7]
results = {}
diagnostics = {}

for c in cohorts:
    window = list(range(c - 2, c + 3))
    sub = df[df['time'].isin(window)]
    sub = sub[(sub['g'] == c) | (sub['g'] == 0) | (sub['g'] > c + 2)]
    counts = sub.groupby('id')['time'].nunique()
    keep_ids = counts[counts == len(window)].index
    sub = sub[sub['id'].isin(keep_ids)].copy()
    sub = sub.dropna(subset=['y'])
    sub = sub.sort_values(['id', 'time']).reset_index(drop=True)

    did = ((sub['g'] == c) & (sub['time'] >= c)).astype(float).to_numpy()
    # An intercept accompanies one omitted category in each fixed-effect set.
    design = np.column_stack([
        np.ones(len(sub)), did,
        pd.get_dummies(sub['id'], drop_first=True, dtype=float).to_numpy(),
        pd.get_dummies(sub['time'], drop_first=True, dtype=float).to_numpy(),
    ])
    coef = np.linalg.lstsq(design, sub['y'].to_numpy(dtype=float), rcond=None)[0]

    n_treated = int(sub.loc[sub['g'] == c, 'id'].nunique())
    n_control = int(sub.loc[sub['g'] != c, 'id'].nunique())
    results[c] = {'att': float(coef[1]), 'n_obs': int(len(sub)), 'n_treated': n_treated}
    diagnostics[f'g{c}'] = {
        'retained_treated_units': n_treated,
        'retained_control_units': n_control,
        'rows': int(len(sub)),
        'design_rank': int(np.linalg.matrix_rank(design)),
        'design_columns': int(design.shape[1]),
    }

weights = np.array([results[c]['n_treated'] for c in cohorts], dtype=float)
atts = np.array([results[c]['att'] for c in cohorts])
att_weighted = float(np.sum(weights * atts) / np.sum(weights))
total_rows = int(sum(results[c]['n_obs'] for c in cohorts))

estimates = [
    {'term': f'att_g{c}', 'estimate': results[c]['att'], 'se': None, 'n_obs': results[c]['n_obs']}
    for c in cohorts
]
estimates.append({'term': 'att_weighted', 'estimate': att_weighted, 'se': None, 'n_obs': total_rows})

output = {
    'task_id': 'broad_cohort_stack',
    'platform': 'python',
    'estimates': estimates,
    'method_metadata': {
        'estimator': 'separate cohort-specific two-way fixed effects regressions',
        'window': 'c-2 through c+2',
        'controls': 'g==0 or g>c+2',
        'balance': 'units observed at all five window times, per cohort',
        'aggregation': 'weighted by retained treated units',
    },
    'diagnostics': diagnostics,
}

with open('result.json', 'w') as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
