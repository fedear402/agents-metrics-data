import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df["region_id"] = df["region_id"].astype(str)
df["industry_id"] = df["industry_id"].astype(str)

reg = df.groupby("region_id", sort=True).agg(
    region_weight=("region_weight", "first"), x=("x", "first"), y=("y", "first")
)
reg["e"] = reg["region_weight"] / reg["region_weight"].sum()

df["ss"] = df["share"] * df["shock"]
reg["z"] = df.groupby("region_id")["ss"].sum().reindex(reg.index).fillna(0.0)

e = reg["e"].values
def wmean(v):
    return np.sum(e * v) / np.sum(e)

for v in ["y", "x", "z"]:
    reg[v + "0"] = reg[v] - wmean(reg[v].values)

# Regional estimates
def wiv(yv, xv, zv, w):
    X = np.column_stack([np.ones_like(xv), xv])
    Z = np.column_stack([np.ones_like(zv), zv])
    W = w
    ZWX = Z.T @ (X * W[:, None])
    ZWy = Z.T @ (yv * W)
    b = np.linalg.solve(ZWX, ZWy)
    return b, X, Z

b_reg, _, _ = wiv(reg["y"].values, reg["x"].values, reg["z"].values, e)
fs_reg, _, _ = wiv(reg["x"].values, reg["z"].values, reg["z"].values, e)

# Shock-level aggregation
m = df.merge(reg[["e", "y0", "x0", "z0"]], left_on="region_id", right_index=True)
m["es"] = m["e"] * m["share"]
for v in ["y0", "x0", "z0"]:
    m["es_" + v] = m["es"] * m[v]
ind = m.groupby("industry_id").agg(
    s=("es", "sum"), shock=("shock", "first"),
    ey=("es_y0", "sum"), ex=("es_x0", "sum"), ez=("es_z0", "sum"),
)
ind = ind[ind["s"] > 0]
s = ind["s"].values
ybar = ind["ey"].values / s
xbar = ind["ex"].values / s
zbar = ind["ez"].values / s
g = ind["shock"].values
N = len(ind)

def iv_hc1(yv, xv, zv, w):
    b, X, Z = wiv(yv, xv, zv, w)
    u = yv - X @ b
    A = Z.T @ (X * w[:, None])
    Ainv = np.linalg.inv(A)
    meat = (Z * (w * u)[:, None]).T @ (Z * (w * u)[:, None])
    V = Ainv @ meat @ Ainv.T * len(yv) / (len(yv) - 2)
    return b, np.sqrt(np.diag(V))

b_s, se_s = iv_hc1(ybar, xbar, g, s)
f_s, sef_s = iv_hc1(xbar, zbar, g, s)

eff = 1.0 / np.sum(s ** 2)

out = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": float(b_reg[1]), "se": float(se_s[1]), "n_obs": int(N)},
        {"term": "first_stage", "estimate": float(fs_reg[1]), "se": float(sef_s[1]), "n_obs": int(N)},
        {"term": "effective_shocks", "estimate": float(eff), "se": None, "n_obs": int(N)},
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS shift-share (BHJ shock-level equivalence)",
        "vcov": "shock-level HC1, N/(N-2), structural IV residuals, analytic weights s_n",
    },
    "diagnostics": {
        "shock_level_effect_slope": float(b_s[1]),
        "shock_level_first_stage_slope": float(f_s[1]),
        "n_regions": int(len(reg)),
    },
}
with open("result.json", "w") as f:
    json.dump(out, f, indent=2)
