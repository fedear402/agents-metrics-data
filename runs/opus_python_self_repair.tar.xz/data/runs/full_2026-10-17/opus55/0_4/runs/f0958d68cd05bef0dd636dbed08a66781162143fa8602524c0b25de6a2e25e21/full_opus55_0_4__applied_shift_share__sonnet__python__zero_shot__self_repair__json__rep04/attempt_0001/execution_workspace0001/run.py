import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")

reg = df.groupby("region_id", sort=True).agg(
    region_weight=("region_weight", "first"), x=("x", "first"), y=("y", "first")
)
reg["e"] = reg["region_weight"] / reg["region_weight"].sum()
df = df.copy()
df["shock"] = df["shock"].astype(float)
df["sz"] = df["share"] * df["shock"]
reg["z"] = df.groupby("region_id")["sz"].sum().reindex(reg.index)

e = reg["e"].values
for v in ["x", "y", "z"]:
    m = np.sum(e * reg[v].values) / e.sum()
    reg[v + "0"] = reg[v] - m


def wiv(yv, xv, zv, w):
    X = np.column_stack([np.ones_like(xv), xv])
    Z = np.column_stack([np.ones_like(zv), zv])
    W = w
    ZWX = Z.T @ (W[:, None] * X)
    ZWy = Z.T @ (W * yv)
    b = np.linalg.solve(ZWX, ZWy)
    return b, X, Z


def wiv_hc1(yv, xv, zv, w):
    b, X, Z = wiv(yv, xv, zv, w)
    u = yv - X @ b
    n, k = X.shape
    ZWX_inv = np.linalg.inv(Z.T @ (w[:, None] * X))
    meat = (Z * (w * u)[:, None]).T @ (Z * (w * u)[:, None])
    V = ZWX_inv @ meat @ ZWX_inv.T * n / (n - k)
    return b, np.sqrt(np.diag(V))


# Regional estimates
b_reg, _, _ = wiv(reg["y"].values, reg["x"].values, reg["z"].values, e)
b_fs, _, _ = wiv(reg["x"].values, reg["z"].values, reg["z"].values, e)

# Shock-level aggregation
d = df.merge(reg[["e", "x0", "y0", "z0"]], left_on="region_id", right_index=True)
d["es"] = d["e"] * d["share"]
for v in ["x0", "y0", "z0"]:
    d["w_" + v] = d["es"] * d[v]
g = d.groupby("industry_id", sort=True).agg(
    s=("es", "sum"), shock=("shock", "first"),
    wx=("w_x0", "sum"), wy=("w_y0", "sum"), wz=("w_z0", "sum"),
)
g = g[g["s"] > 0]
g["xbar"] = g["wx"] / g["s"]
g["ybar"] = g["wy"] / g["s"]
g["zbar"] = g["wz"] / g["s"]
N = len(g)
s = g["s"].values
g_shock = g["shock"].values

b_e, se_e = wiv_hc1(g["ybar"].values, g["xbar"].values, g_shock, s)
b_f, se_f = wiv_hc1(g["xbar"].values, g["zbar"].values, g_shock, s)

eff = 1.0 / np.sum(s ** 2)

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": float(b_reg[1]), "se": float(se_e[1]), "n_obs": int(N)},
        {"term": "first_stage", "estimate": float(b_fs[1]), "se": float(se_f[1]), "n_obs": int(N)},
        {"term": "effective_shocks", "estimate": float(eff), "se": None, "n_obs": int(N)},
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS with shift-share instrument; BHJ shock-level equivalent IV",
        "vcov": "shock-level HC1 (N/(N-2)), analytic weights s_n, structural IV residuals",
    },
    "diagnostics": {
        "shock_level_effect_slope": float(b_e[1]),
        "shock_level_first_stage_slope": float(b_f[1]),
        "n_regions": int(len(reg)),
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
