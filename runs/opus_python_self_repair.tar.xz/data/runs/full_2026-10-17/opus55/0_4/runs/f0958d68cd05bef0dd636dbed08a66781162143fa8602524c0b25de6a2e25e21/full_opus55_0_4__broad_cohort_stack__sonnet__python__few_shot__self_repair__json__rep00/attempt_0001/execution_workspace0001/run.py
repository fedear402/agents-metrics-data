import json
import numpy as np
import pandas as pd

df = pd.read_csv('input.csv')
df = df.drop_duplicates(subset=['id', 'time'])

results = {}
for c in (3, 5, 7):
    times = list(range(c - 2, c + 3))
    unit_g = df.groupby('id')['g'].first()
    elig_ids = unit_g[(unit_g == c) | (unit_g == 0) | (unit_g > c + 2)].index
    sub = df[df['id'].isin(elig_ids) & df['time'].isin(times)].copy()
    counts = sub.groupby('id')['time'].nunique()
    keep_ids = counts[counts == len(times)].index
    sub = sub[sub['id'].isin(keep_ids)].sort_values(['id', 'time']).reset_index(drop=True)
    sub['did'] = ((sub['g'] == c) & (sub['time'] >= c)).astype(float)
    X = np.column_stack([
        np.ones(len(sub)), sub['did'].values,
        pd.get_dummies(sub['id'], drop_first=True, dtype=float).values,
        pd.get_dummies(sub['time'], drop_first=True, dtype=float).values,
    ])
    beta = np.linalg.lstsq(X, sub['y'].values.astype(float), rcond=None)[0]
    n_treated = int(sub.loc[sub['g'] == c, 'id'].nunique())
    results[c] = (float(beta[1]), int(len(sub)), n_treated)

estimates = []
for c in (3, 5, 7):
    est, n, _ = results[c]
    estimates.append({'term': f'att_g{c}', 'estimate': est, 'se': None, 'n_obs': n})

w = np.array([results[c][2] for c in (3, 5, 7)], dtype=float)
a = np.array([results[c][0] for c in (3, 5, 7)])
att_w = float(np.sum(w * a) / np.sum(w))
estimates.append({'term': 'att_weighted', 'estimate': att_w, 'se': None,
                  'n_obs': int(sum(results[c][1] for c in (3, 5, 7)))})

output = {
    'task_id': 'broad_cohort_stack',
    'platform': 'python',
    'estimates': estimates,
    'method_metadata': {},
    'diagnostics': {f'treated_units_g{c}': results[c][2] for c in (3, 5, 7)},
}
with open('result.json', 'w') as f:
    json.dump(output, f, indent=2, allow_nan=False)
