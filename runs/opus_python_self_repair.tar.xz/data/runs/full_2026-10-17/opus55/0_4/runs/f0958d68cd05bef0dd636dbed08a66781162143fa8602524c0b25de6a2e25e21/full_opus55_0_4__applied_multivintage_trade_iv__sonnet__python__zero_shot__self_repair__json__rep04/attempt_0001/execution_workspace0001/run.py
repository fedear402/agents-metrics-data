import json
import numpy as np
import pandas as pd

cw = pd.read_csv("crosswalk.csv")
tr = pd.read_csv("trade.csv")
ar = pd.read_csv("areas.csv")
em = pd.read_csv("employment.csv")
oc = pd.read_csv("outcomes.csv")

for d in (cw, tr):
    d["code"] = d["code"].astype(str).str.strip()
for d in (cw, em):
    d["industry"] = d["industry"].astype(str).str.strip()
for d in (ar, em):
    d["vintage"] = d["vintage"].astype(str).str.strip().str.lower()

tr = tr.merge(cw, on="code", how="inner")
tr = tr.groupby(["period", "industry"], as_index=False).agg(
    us_change=("us_change", "sum"), other_change=("other_change", "sum"),
    price_index=("price_index", "first"), years=("years", "first"))
inds = sorted(cw["industry"].unique())

areas_list = sorted(ar["area"].unique())
periods = sorted(oc["period"].unique())


def exposure(vintage, chg):
    e = em[em["vintage"] == vintage].groupby(["area", "period", "industry"])["employment"].sum()
    idx = pd.MultiIndex.from_product([areas_list, periods, inds], names=["area", "period", "industry"])
    e = e.reindex(idx, fill_value=0.0).reset_index()
    nat = e.groupby(["period", "industry"])["employment"].sum().rename("nat").reset_index()
    tot = ar[ar["vintage"] == vintage][["area", "period", "total_employment"]]
    e = e.merge(nat, on=["period", "industry"]).merge(tot, on=["area", "period"]).merge(
        tr, on=["period", "industry"], how="left")
    e[chg] = e[chg].fillna(0.0)
    e["v"] = (e["employment"] / e["total_employment"]) * (e[chg] / e["nat"]) / (
        e["price_index"] / 100.0) / 1000.0 * (10.0 / e["years"])
    e["v"] = e["v"].fillna(0.0)
    return e.groupby(["area", "period"])["v"].sum()


x = exposure("base", "us_change").rename("x").reset_index()
z = exposure("early", "other_change").rename("z").reset_index()
pop = ar[ar["vintage"] == "base"][["area", "period", "population"]]
df = oc.merge(x, on=["area", "period"]).merge(z, on=["area", "period"]).merge(pop, on=["area", "period"])
df = df.sort_values(["area", "period"]).reset_index(drop=True)

n = len(df)
y = df["change_pp"].to_numpy(float)
w = df["population"].to_numpy(float)
X = np.column_stack([np.ones(n), df["period"].astype(float), df["control"].astype(float), df["x"]])
Z = np.column_stack([np.ones(n), df["period"].astype(float), df["control"].astype(float), df["z"]])
sw = np.sqrt(w)
Xw, Zw, yw = X * sw[:, None], Z * sw[:, None], y * sw
Pz = Zw @ np.linalg.pinv(Zw.T @ Zw) @ Zw.T
beta = np.linalg.solve(Xw.T @ Pz @ Xw, Xw.T @ Pz @ yw)


def get(dfv, col, a, p):
    r = dfv[(dfv["area"] == a) & (dfv["period"] == p)]
    return float(r[col].iloc[0]) if len(r) else None


a0 = areas_list[0] if 0 not in areas_list else 0
p0, p1 = periods[0], periods[1] if len(periods) > 1 else periods[0]
if 0 in periods:
    p0 = 0
if 1 in periods:
    p1 = 1

est = {
    "iv_slope": float(beta[3]),
    "exposure_area0_period0": get(df, "x", a0, p0),
    "exposure_area0_period1": get(df, "x", a0, p1),
    "instrument_area0_period0": get(df, "z", a0, p0),
}
out = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [{"term": k, "estimate": v, "se": None, "n_obs": int(n)} for k, v in est.items()],
    "method_metadata": {"estimator": "weighted 2SLS", "weights": "base population",
                        "exogenous": ["intercept", "period", "control"],
                        "endogenous": "x", "instrument": "z"},
    "diagnostics": {"n_obs": int(n), "coefficients": [float(b) for b in beta],
                    "n_industries": len(inds)},
}
with open("result.json", "w") as f:
    json.dump(out, f, indent=2)
