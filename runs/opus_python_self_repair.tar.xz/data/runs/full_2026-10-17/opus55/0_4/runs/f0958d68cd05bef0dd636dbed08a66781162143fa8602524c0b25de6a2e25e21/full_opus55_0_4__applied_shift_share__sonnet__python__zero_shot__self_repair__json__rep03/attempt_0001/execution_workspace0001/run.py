import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")

reg = df.groupby("region_id").agg(region_weight=("region_weight", "first"),
                                  x=("x", "first"), y=("y", "first")).reset_index()
reg["e"] = reg["region_weight"] / reg["region_weight"].sum()

df["sz"] = df["share"] * df["shock"]
z = df.groupby("region_id")["sz"].sum().rename("z").reset_index()
reg = reg.merge(z, on="region_id")

e = reg["e"].values


def wiv(yv, xv, zv, w):
    n = len(yv)
    X = np.column_stack([np.ones(n), xv])
    Z = np.column_stack([np.ones(n), zv])
    A = Z.T @ (w[:, None] * X)
    b = np.linalg.solve(A, Z.T @ (w * yv))
    u = yv - X @ b
    Ainv = np.linalg.inv(A)
    meat = (Z * (w * u)[:, None]).T @ (Z * (w * u)[:, None])
    V = Ainv @ meat @ Ainv.T * n / (n - 2)
    return b, V


b_reg, _ = wiv(reg["y"].values, reg["x"].values, reg["z"].values, e)
b_fs_reg, _ = wiv(reg["x"].values, reg["z"].values, reg["z"].values, e)

for v in ["y", "x", "z"]:
    reg[v + "0"] = reg[v] - np.sum(e * reg[v].values)

d = df[["region_id", "industry_id", "share", "shock"]].merge(
    reg[["region_id", "e", "y0", "x0", "z0"]], on="region_id")
d["es"] = d["e"] * d["share"]
for v in ["y0", "x0", "z0"]:
    d["es_" + v] = d["es"] * d[v]

ind = d.groupby("industry_id").agg(s=("es", "sum"), shock=("shock", "first"),
                                   sy=("es_y0", "sum"), sx=("es_x0", "sum"),
                                   sz=("es_z0", "sum")).reset_index()
ind = ind[ind["s"] > 0].copy()
ind["ybar"] = ind["sy"] / ind["s"]
ind["xbar"] = ind["sx"] / ind["s"]
ind["zbar"] = ind["sz"] / ind["s"]
N = len(ind)
s = ind["s"].values
g = ind["shock"].values

b_eff, V_eff = wiv(ind["ybar"].values, ind["xbar"].values, g, s)
b_fs, V_fs = wiv(ind["xbar"].values, ind["zbar"].values, g, s)

eff_shocks = 1.0 / np.sum(ind["s"].values ** 2)

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": float(b_reg[1]),
         "se": float(np.sqrt(V_eff[1, 1])), "n_obs": int(N)},
        {"term": "first_stage", "estimate": float(b_fs_reg[1]),
         "se": float(np.sqrt(V_fs[1, 1])), "n_obs": int(N)},
        {"term": "effective_shocks", "estimate": float(eff_shocks),
         "se": None, "n_obs": int(N)},
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS with shift-share instrument; BHJ shock-level equivalent IV",
        "vcov": "shock-level HC1 (N/(N-2)), structural IV residuals, analytic weights s_n",
    },
    "diagnostics": {
        "shock_level_effect_slope": float(b_eff[1]),
        "shock_level_first_stage_slope": float(b_fs[1]),
        "n_regions": int(len(reg)),
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
