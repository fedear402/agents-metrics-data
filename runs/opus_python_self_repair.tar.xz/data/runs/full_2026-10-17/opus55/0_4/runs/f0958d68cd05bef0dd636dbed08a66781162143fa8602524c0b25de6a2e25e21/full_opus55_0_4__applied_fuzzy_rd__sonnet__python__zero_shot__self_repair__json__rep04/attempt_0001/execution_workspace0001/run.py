import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df = df[["score", "participated", "earnings"]].apply(pd.to_numeric, errors="coerce").dropna()
d = df[np.abs(df["score"]) < 1].copy()
s = d["score"].to_numpy(float)
w = 1.0 - np.abs(s)
r = (s >= 0).astype(float)
n = len(d)

# Columns: intercept, right indicator, score, right*score -> coefficient on r is the jump
X = np.column_stack([np.ones(n), r, s, r * s])
y_e = d["earnings"].to_numpy(float)
y_p = d["participated"].to_numpy(float)

XtWX = X.T @ (X * w[:, None])
bread = np.linalg.inv(XtWX)

def fit(y):
    b = bread @ (X.T @ (w * y))
    return b, y - X @ b

b_e, e_e = fit(y_e)
b_p, e_p = fit(y_p)

def cov(ea, eb):
    Ua = X * (w * ea)[:, None]
    Ub = X * (w * eb)[:, None]
    return bread @ (Ua.T @ Ub) @ bread

k = 1
V_ee = cov(e_e, e_e)[k, k]
V_pp = cov(e_p, e_p)[k, k]
V_ep = cov(e_e, e_p)[k, k]

rf = float(b_e[k])
fs = float(b_p[k])
te = rf / fs
g = np.array([1.0 / fs, -rf / fs**2])
V = np.array([[V_ee, V_ep], [V_ep, V_pp]])
se_te = float(np.sqrt(g @ V @ g))

out = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": float(te), "se": se_te, "n_obs": int(n)},
        {"term": "reduced_form", "estimate": rf, "se": float(np.sqrt(V_ee)), "n_obs": int(n)},
        {"term": "first_stage", "estimate": fs, "se": float(np.sqrt(V_pp)), "n_obs": int(n)},
    ],
    "method_metadata": {
        "estimator": "fuzzy RD, local linear, triangular kernel, h=1, separate slopes; Wald ratio",
        "vcov": "HC0 joint sandwich, delta method with covariance",
    },
    "diagnostics": {"cov_rf_fs": float(V_ep), "n_left": int((r == 0).sum()), "n_right": int((r == 1).sum())},
}
with open("result.json", "w") as f:
    json.dump(out, f, indent=2)
