import json
import numpy as np
import pandas as pd
from scipy import stats

df = pd.read_csv("input.csv")
n = len(df)
y = df["y"].to_numpy(float)
e = df["endog"].to_numpy(float)
W = np.column_stack([np.ones(n), df["x"].to_numpy(float)])
Z = np.column_stack([W, df["z1"].to_numpy(float), df["z2"].to_numpy(float)])

def resid(X, v):
    b, *_ = np.linalg.lstsq(X, v, rcond=None)
    return v - X @ b

yr, er = resid(W, y), resid(W, e)
yu, eu = resid(Z, y), resid(Z, e)
dfd = n - 4
c = stats.f.ppf(0.95, 2, dfd)

def F(b):
    rr = yr - b * er
    ru = yu - b * eu
    rssr, rssu = rr @ rr, ru @ ru
    return ((rssr - rssu) / 2) / (rssu / dfd)

# (rssr - rssu)*dfd - 2c*rssu <= 0  -> A b^2 + B b + C <= 0
def comps(a1, a2):
    return (yr @ yr - yu @ yu) * a1 - a2 * (yu @ yu), None
Pyy = yr @ yr - yu @ yu
Pye = yr @ er - yu @ eu
Pee = er @ er - eu @ eu
Qyy, Qye, Qee = yu @ yu, yu @ eu, eu @ eu
k = 2 * c
A = dfd * Pee - k * Qee
B = -2 * (dfd * Pye - k * Qye)
C = dfd * Pyy - k * Qyy

disc = B * B - 4 * A * C
if disc >= 0 and A != 0:
    r = np.sort(np.roots([A, B, C]).real)
    lo, hi = float(r[0]), float(r[1])
else:
    lo, hi = float("nan"), float("nan")

def accept(b):
    return F(b) <= c

unbounded = 1 if A <= 0 else 0
accepts_zero = 1 if accept(0.0) else 0
f1 = float(F(1.0))

res = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": [
        {"term": "boundary_low", "estimate": lo, "se": None, "n_obs": n},
        {"term": "boundary_high", "estimate": hi, "se": None, "n_obs": n},
        {"term": "accepts_zero", "estimate": float(accepts_zero), "se": None, "n_obs": n},
        {"term": "unbounded", "estimate": float(unbounded), "se": None, "n_obs": n},
        {"term": "ar_f_at_one", "estimate": f1, "se": None, "n_obs": n},
    ],
    "method_metadata": {"estimator": "Anderson-Rubin test inversion (analytic quadratic)",
                        "vcov": "homoskedastic F(2, n-4)"},
    "diagnostics": {"quad_A": float(A), "quad_B": float(B), "quad_C": float(C),
                    "crit": float(c), "disjoint": int(A < 0 and disc > 0)},
}
with open("result.json", "w") as f:
    json.dump(res, f, indent=2)
