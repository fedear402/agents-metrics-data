import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("input.csv")
n_full = int(len(df))
d = df[["y", "x", "z"]].dropna().copy()
d["y"] = d["y"].astype(int)

X = sm.add_constant(d[["x", "z"]], has_constant="add")
model = sm.MNLogit(d["y"], X)
res = model.fit(method="newton", maxiter=200, disp=False)
if not res.mle_retvals.get("converged", True):
    res = model.fit(method="bfgs", maxiter=5000, disp=False)

params = res.params
bse = res.bse
cols = list(params.columns)
outcomes = sorted(d["y"].unique())
nonbase = [o for o in outcomes if o != 0]
colmap = {o: cols[i] for i, o in enumerate(nonbase)}

def g(tab, var, cat):
    return float(tab.loc[var, colmap[cat]])

# Predicted probability at x=0, z=0
eta = {o: float(params.loc["const", colmap[o]]) for o in nonbase}
denom = 1.0 + sum(np.exp(v) for v in eta.values())
prob2 = float(np.exp(eta[2]) / denom)

estimates = []
for cat in (1, 2):
    for var in ("x", "z"):
        estimates.append({
            "term": f"{var}_cat{cat}",
            "estimate": g(params, var, cat),
            "se": g(bse, var, cat),
            "n_obs": n_full,
        })
# reorder to required order
order = ["x_cat1", "z_cat1", "x_cat2", "z_cat2"]
estimates = sorted(estimates, key=lambda e: order.index(e["term"]))
estimates.append({"term": "prob_cat2_zero", "estimate": prob2, "se": None, "n_obs": n_full})

out = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "statsmodels MNLogit maximum likelihood, base outcome 0",
        "vcov": "observed information (inverse Hessian)",
    },
    "diagnostics": {
        "n_used": int(res.nobs),
        "loglik": float(res.llf),
        "converged": bool(res.mle_retvals.get("converged", True)),
    },
}
with open("result.json", "w") as f:
    json.dump(out, f, indent=2)
