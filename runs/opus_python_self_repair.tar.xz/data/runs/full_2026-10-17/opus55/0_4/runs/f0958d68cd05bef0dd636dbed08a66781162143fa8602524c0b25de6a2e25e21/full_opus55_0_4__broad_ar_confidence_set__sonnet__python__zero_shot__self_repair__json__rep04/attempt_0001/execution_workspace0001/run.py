import json
import numpy as np
import pandas as pd
from scipy import stats

df = pd.read_csv("input.csv")
df = df[["y", "endog", "x", "z1", "z2"]].dropna()
n = len(df)
y = df["y"].to_numpy(float)
e = df["endog"].to_numpy(float)
W = np.column_stack([np.ones(n), df["x"].to_numpy(float)])
X = np.column_stack([W, df["z1"].to_numpy(float), df["z2"].to_numpy(float)])

def resid_maker(A):
    Q, _ = np.linalg.qr(A)
    return lambda v: v - Q @ (Q.T @ v)

MW = resid_maker(W)
MX = resid_maker(X)
yW, eW = MW(y), MW(e)
yX, eX = MX(y), MX(e)

dfd = n - 4
crit = stats.f.ppf(0.95, 2, dfd)
k = 1.0 + 2.0 * crit / dfd

def ar_f(b):
    ur = yW - b * eW
    uu = yX - b * eX
    rr, ru = ur @ ur, uu @ uu
    return ((rr - ru) / 2.0) / (ru / dfd)

# Acceptance: RSS_r - k*RSS_u <= 0, a quadratic in beta
a = eW @ eW - k * (eX @ eX)
B = -2.0 * (eW @ yW - k * (eX @ yX))
C = yW @ yW - k * (yX @ yX)
Qf = lambda b: a * b * b + B * b + C

disc = B * B - 4 * a * C
if disc >= 0 and a != 0:
    r = np.sort(np.roots([a, B, C]).real)
    low, high = float(r[0]), float(r[1])
else:
    low, high = float("nan"), float("nan")

accepts_zero = 1.0 if ar_f(0.0) <= crit else 0.0
unbounded = 1.0 if a < 0 or (a == 0) else 0.0
if disc < 0 and a < 0:
    unbounded = 1.0

est = [
    ("boundary_low", low),
    ("boundary_high", high),
    ("accepts_zero", accepts_zero),
    ("unbounded", unbounded),
    ("ar_f_at_one", float(ar_f(1.0))),
]
out = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": [{"term": t, "estimate": (None if np.isnan(v) else float(v)),
                   "se": None, "n_obs": int(n)} for t, v in est],
    "method_metadata": {"estimator": "Anderson-Rubin test inversion (analytic quadratic)",
                        "vcov": "homoskedastic"},
    "diagnostics": {"f_crit": float(crit), "quad_a": float(a), "quad_b": float(B),
                    "quad_c": float(C)},
}
with open("result.json", "w") as f:
    json.dump(out, f, indent=2)
