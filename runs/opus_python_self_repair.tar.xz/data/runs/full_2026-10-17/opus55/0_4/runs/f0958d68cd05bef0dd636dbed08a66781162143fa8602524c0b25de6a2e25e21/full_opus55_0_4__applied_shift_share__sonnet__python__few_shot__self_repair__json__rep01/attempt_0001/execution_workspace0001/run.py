import json
import numpy as np
import pandas as pd

df = pd.read_csv('input.csv')
regions = df.groupby('region_id', sort=True).first()[['region_weight', 'x', 'y']]
region_ids = regions.index.values
shocks = df.groupby('industry_id', sort=True)['shock'].first()
industry_ids = shocks.index.values
shock = shocks.values.astype(float)

S = (df.pivot_table(index='region_id', columns='industry_id', values='share',
                    aggfunc='sum', fill_value=0.0)
       .reindex(index=region_ids, columns=industry_ids, fill_value=0.0).values)

e = regions['region_weight'].values.astype(float)
e = e / e.sum()
x = regions['x'].values.astype(float)
y = regions['y'].values.astype(float)
z = S @ shock

regional = np.column_stack([y, x, z])
centered = regional - e @ regional
mass = e @ S
keep = mass > 0
Sk = S[:, keep]
mass_k = mass[keep]
shock_k = shock[keep]
aggregated = (Sk.T @ (e[:, None] * centered)) / mass_k[:, None]
N = len(shock_k)


def shock_iv(dependent, endogenous):
    X = np.column_stack([np.ones(N), endogenous])
    Z = np.column_stack([np.ones(N), shock_k])
    cross = Z.T @ (mass_k[:, None] * X)
    beta = np.linalg.solve(cross, Z.T @ (mass_k * dependent))
    resid = dependent - X @ beta
    scores = Z * (mass_k * resid)[:, None]
    inv = np.linalg.inv(cross)
    cov = (N / (N - 2)) * inv @ (scores.T @ scores) @ inv.T
    return float(beta[1]), float(np.sqrt(cov[1, 1]))


effect_sl, effect_se = shock_iv(aggregated[:, 0], aggregated[:, 1])
fs_sl, fs_se = shock_iv(aggregated[:, 1], aggregated[:, 2])

y0, x0, z0 = centered[:, 0], centered[:, 1], centered[:, 2]
effect = float(np.sum(e * z0 * y0) / np.sum(e * z0 * x0))
first_stage = float(np.sum(e * z0 * x0) / np.sum(e * z0 ** 2))
eff_shocks = float(1.0 / np.sum(mass ** 2))

output = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": effect, "se": effect_se, "n_obs": int(N)},
        {"term": "first_stage", "estimate": first_stage, "se": fs_se, "n_obs": int(N)},
        {"term": "effective_shocks", "estimate": eff_shocks, "se": None, "n_obs": int(N)},
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS with shift-share instrument; BHJ shock-level equivalent IV",
        "vcov": "shock-level HC1 (N/(N-2)), structural IV residuals, analytic weights s_n",
    },
    "diagnostics": {
        "shock_level_effect": effect_sl,
        "shock_level_first_stage": fs_sl,
        "n_regions": int(len(region_ids)),
    },
}
with open('result.json', 'w') as f:
    json.dump(output, f, indent=2, allow_nan=False)
