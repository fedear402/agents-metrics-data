import json
import numpy as np
import pandas as pd

df = pd.read_csv('input.csv')
df = df.drop_duplicates(subset=['id', 'time'])

results = []
total_rows = 0
weighted_sum = 0.0
weight_total = 0
for c in (3, 5, 7):
    window = list(range(c - 2, c + 3))
    sub = df[df['time'].isin(window)]
    sub = sub[(sub['g'] == c) | (sub['g'] == 0) | (sub['g'] > c + 2)]
    counts = sub.groupby('id')['time'].nunique()
    keep_ids = counts[counts == len(window)].index
    sub = sub[sub['id'].isin(keep_ids)].copy()
    sub = sub.sort_values(['id', 'time']).reset_index(drop=True)
    did = ((sub['g'] == c) & (sub['time'] >= c)).astype(float).to_numpy()
    # An intercept accompanies one omitted category in each fixed-effect set.
    design = np.column_stack([
        np.ones(len(sub)), did,
        pd.get_dummies(sub['id'], drop_first=True, dtype=float).to_numpy(),
        pd.get_dummies(sub['time'], drop_first=True, dtype=float).to_numpy(),
    ])
    coef = np.linalg.lstsq(design, sub['y'].to_numpy(dtype=float), rcond=None)[0][1]
    n_treated = int(sub.loc[sub['g'] == c, 'id'].nunique())
    n_rows = int(len(sub))
    results.append({'term': f'att_g{c}', 'estimate': float(coef), 'se': None, 'n_obs': n_rows})
    total_rows += n_rows
    weighted_sum += coef * n_treated
    weight_total += n_treated

results.append({'term': 'att_weighted', 'estimate': float(weighted_sum / weight_total),
                'se': None, 'n_obs': int(total_rows)})

output = {
    'task_id': 'broad_cohort_stack',
    'platform': 'python',
    'estimates': results,
    'method_metadata': {},
    'diagnostics': {},
}
with open('result.json', 'w') as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
