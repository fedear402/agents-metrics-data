import json
import numpy as np
import pandas as pd

h = pd.read_csv("households.csv")
c = pd.read_csv("census.csv")
d = h[h["recipient"] == 0].copy()
d = d.dropna(subset=["eligible", "dose", "instrument", "baseline", "weight", "outcome"])
e = d["eligible"].astype(float).values
ne = 1.0 - e
dose = d["dose"].astype(float).values
z = d["instrument"].astype(float).values
b = d["baseline"].astype(float).values
y = d["outcome"].astype(float).values
w = d["weight"].astype(float).values

X_exog = np.column_stack([ne, e, b * ne, b * e])
X_endog = np.column_stack([dose * ne, dose * e])
X = np.column_stack([X_exog, X_endog])
Z = np.column_stack([X_exog, z * ne, z * e])

sw = np.sqrt(w)
Xw = X * sw[:, None]
Zw = Z * sw[:, None]
yw = y * sw
Pi = np.linalg.lstsq(Zw, Xw, rcond=None)[0]
Xhat = Zw @ Pi
beta = np.linalg.solve(Xhat.T @ Xw, Xhat.T @ yw)
slope_ne, slope_e = beta[4], beta[5]

m0 = e == 0
m1 = e == 1
mean0 = np.average(dose[m0], weights=w[m0])
mean1 = np.average(dose[m1], weights=w[m1])
eff0 = float(slope_ne * mean0)
eff1 = float(slope_e * mean1)

pop = c.set_index(c["eligible"].astype(int))["nonrecipient_population"].astype(float)
p0, p1 = float(pop.loc[0]), float(pop.loc[1])
popeff = float((p0 * eff0 + p1 * eff1) / (p0 + p1))

n = int(len(d))
res = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {"term": "ineligible_effect", "estimate": eff0, "se": None, "n_obs": n},
        {"term": "eligible_nonrecipient_effect", "estimate": eff1, "se": None, "n_obs": n},
        {"term": "population_effect", "estimate": popeff, "se": None, "n_obs": n},
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS, fully interacted by eligibility, no extra intercept",
        "sample": "recipient == 0",
        "counterfactual": "dose = 0 for all retained households",
        "aggregation_weights": "census nonrecipient_population",
    },
    "diagnostics": {
        "slope_ineligible": float(slope_ne),
        "slope_eligible": float(slope_e),
        "weighted_mean_dose_ineligible": float(mean0),
        "weighted_mean_dose_eligible": float(mean1),
        "n_ineligible": int(m0.sum()),
        "n_eligible": int(m1.sum()),
        "pop_ineligible": p0,
        "pop_eligible": p1,
        "coefficients": [float(v) for v in beta],
    },
}
with open("result.json", "w") as f:
    json.dump(res, f, indent=2)
print(json.dumps(res, indent=2))
