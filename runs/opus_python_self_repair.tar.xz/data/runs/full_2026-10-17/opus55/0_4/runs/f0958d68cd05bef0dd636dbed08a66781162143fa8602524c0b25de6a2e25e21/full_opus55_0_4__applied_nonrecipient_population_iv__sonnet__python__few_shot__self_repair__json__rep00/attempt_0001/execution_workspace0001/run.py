import json
import numpy as np
import pandas as pd

hh = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

d = hh[hh["recipient"] == 0].copy()
d = d.dropna(subset=["eligible", "dose", "instrument", "baseline", "weight", "outcome"])
d["eligible"] = d["eligible"].astype(int)
e = d["eligible"].to_numpy(float)
ne = 1.0 - e
dose = d["dose"].to_numpy(float)
base = d["baseline"].to_numpy(float)
inst = d["instrument"].to_numpy(float)
w = d["weight"].to_numpy(float)
y = d["outcome"].to_numpy(float)

X_exog = np.column_stack([ne, e, base * ne, base * e])
X_endog = np.column_stack([dose * ne, dose * e])
X = np.column_stack([X_exog, X_endog])
Z = np.column_stack([X_exog, inst * ne, inst * e])

sw = np.sqrt(w)
Xw = X * sw[:, None]
Zw = Z * sw[:, None]
yw = y * sw
# first stage projection
coef_fs, *_ = np.linalg.lstsq(Zw, Xw, rcond=None)
Xhat = Zw @ coef_fs
beta = np.linalg.solve(Xhat.T @ Xw, Xhat.T @ yw)
b_ne, b_e = beta[4], beta[5]

m0 = d["eligible"] == 0
m1 = d["eligible"] == 1
mean0 = float(np.average(dose[m0.to_numpy()], weights=w[m0.to_numpy()]))
mean1 = float(np.average(dose[m1.to_numpy()], weights=w[m1.to_numpy()]))
eff0 = float(b_ne * mean0)
eff1 = float(b_e * mean1)

census["eligible"] = census["eligible"].astype(int)
pop0 = float(census.loc[census["eligible"] == 0, "nonrecipient_population"].sum())
pop1 = float(census.loc[census["eligible"] == 1, "nonrecipient_population"].sum())
pop_eff = float((pop0 * eff0 + pop1 * eff1) / (pop0 + pop1))

n = int(len(d))
result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {"term": "ineligible_effect", "estimate": eff0, "se": None, "n_obs": n},
        {"term": "eligible_nonrecipient_effect", "estimate": eff1, "se": None, "n_obs": n},
        {"term": "population_effect", "estimate": pop_eff, "se": None, "n_obs": n},
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS (numpy)",
        "sample": "recipient == 0",
        "endogenous": ["dose*(1-eligible)", "dose*eligible"],
        "exogenous": ["1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"],
        "excluded_instruments": ["instrument*(1-eligible)", "instrument*eligible"],
        "weights": "weight",
        "group_effect": "dose slope times weight-weighted mean dose within group",
        "aggregation": "census nonrecipient_population weights",
        "counterfactual": "dose = 0 for all retained households (synthetic convention)",
    },
    "diagnostics": {
        "slope_ineligible": float(b_ne),
        "slope_eligible": float(b_e),
        "weighted_mean_dose_ineligible": mean0,
        "weighted_mean_dose_eligible": mean1,
        "n_ineligible": int(m0.sum()),
        "n_eligible_nonrecipient": int(m1.sum()),
        "census_pop_ineligible": pop0,
        "census_pop_eligible": pop1,
        "coefficients": [float(b) for b in beta],
    },
}
with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))
