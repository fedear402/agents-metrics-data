import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df = df.dropna(subset=["id", "time", "g"])
df["g"] = df["g"].astype(int)
df["time"] = df["time"].astype(int)

results = []
weights = []
nobs_total = 0
diag = {}

for c in [3, 5, 7]:
    times = list(range(c - 2, c + 3))
    sub = df[df["time"].isin(times)]
    sub = sub[(sub["g"] == c) | (sub["g"] == 0) | (sub["g"] > c + 2)]
    cnt = sub.groupby("id")["time"].nunique()
    keep = cnt[cnt == len(times)].index
    sub = sub[sub["id"].isin(keep)].copy()
    sub = sub.dropna(subset=["y"])
    sub["did"] = ((sub["g"] == c) & (sub["time"] >= c)).astype(float)

    # two-way within transformation via dummies (small problem)
    U = pd.get_dummies(sub["id"].astype(str), drop_first=False).astype(float)
    T = pd.get_dummies(sub["time"].astype(str), drop_first=True).astype(float)
    X = np.column_stack([sub["did"].values, U.values, T.values])
    beta, *_ = np.linalg.lstsq(X, sub["y"].values.astype(float), rcond=None)
    att = float(beta[0])

    n_obs = int(len(sub))
    n_treated = int(sub.loc[sub["g"] == c, "id"].nunique())
    results.append({"term": f"att_g{c}", "estimate": att, "se": None, "n_obs": n_obs})
    weights.append(n_treated)
    nobs_total += n_obs
    diag[f"g{c}"] = {
        "n_units": int(sub["id"].nunique()),
        "n_treated_units": n_treated,
        "n_obs": n_obs,
    }

w = np.array(weights, dtype=float)
ests = np.array([r["estimate"] for r in results])
att_w = float(np.sum(w * ests) / np.sum(w))
results.append({"term": "att_weighted", "estimate": att_w, "se": None, "n_obs": int(nobs_total)})

out = {
    "task_id": "broad_cohort_stack",
    "platform": "python",
    "estimates": results,
    "method_metadata": {
        "method": "cohort-specific TWFE DiD, window c-2..c+2, balanced per cohort",
        "weights": "number of retained treated units",
    },
    "diagnostics": diag,
}

with open("result.json", "w") as f:
    json.dump(out, f, indent=2)
