import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")

regions = sorted(df["region_id"].unique())
industries = sorted(df["industry_id"].unique())
R, N = len(regions), len(industries)
ridx = {r: i for i, r in enumerate(regions)}
nidx = {n: j for j, n in enumerate(industries)}

shares = np.zeros((R, N))
for r, n, s in zip(df["region_id"], df["industry_id"], df["share"]):
    shares[ridx[r], nidx[n]] += s

shock = df.groupby("industry_id")["shock"].first().reindex(industries).to_numpy(float)
reg = df.groupby("region_id")[["region_weight", "x", "y"]].first().reindex(regions)
w = reg["region_weight"].to_numpy(float)
e = w / w.sum()
x = reg["x"].to_numpy(float)
y = reg["y"].to_numpy(float)
z = shares @ shock

regional = np.column_stack([y, x, z])
centered = regional - e @ regional
mass = e @ shares
keep = mass > 0
mass_k = mass[keep]
shares_k = shares[:, keep]
shock_k = shock[keep]
Nk = int(keep.sum())
aggregated = (shares_k.T @ (e[:, None] * centered)) / mass_k[:, None]


def shock_iv(dep, endog):
    X = np.column_stack([np.ones(Nk), endog])
    Z = np.column_stack([np.ones(Nk), shock_k])
    cross = Z.T @ (mass_k[:, None] * X)
    beta = np.linalg.solve(cross, Z.T @ (mass_k * dep))
    resid = dep - X @ beta
    scores = Z * (mass_k * resid)[:, None]
    inv = np.linalg.inv(cross)
    cov = (Nk / (Nk - 2)) * inv @ (scores.T @ scores) @ inv.T
    return float(beta[1]), float(np.sqrt(cov[1, 1]))


effect, effect_se = shock_iv(aggregated[:, 0], aggregated[:, 1])
fs, fs_se = shock_iv(aggregated[:, 1], aggregated[:, 2])

y0, x0, z0 = centered[:, 0], centered[:, 1], centered[:, 2]
reg_effect = float(np.sum(e * z0 * y0) / np.sum(e * z0 * x0))
reg_fs = float(np.sum(e * z0 * x0) / np.sum(e * z0 ** 2))

eff_shocks = float(1.0 / np.sum(mass ** 2))

output = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": reg_effect, "se": effect_se, "n_obs": Nk},
        {"term": "first_stage", "estimate": reg_fs, "se": fs_se, "n_obs": Nk},
        {"term": "effective_shocks", "estimate": eff_shocks, "se": None, "n_obs": Nk},
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS shift-share; BHJ shock-level equivalent IV",
        "vcov": "shock-level HC1 (N/(N-2)), structural IV residuals, analytic weights s_n",
    },
    "diagnostics": {
        "shock_level_effect": effect,
        "shock_level_first_stage": fs,
        "n_regions": R,
        "n_industries": N,
    },
}
with open("result.json", "w") as f:
    json.dump(output, f, indent=2, allow_nan=False)
