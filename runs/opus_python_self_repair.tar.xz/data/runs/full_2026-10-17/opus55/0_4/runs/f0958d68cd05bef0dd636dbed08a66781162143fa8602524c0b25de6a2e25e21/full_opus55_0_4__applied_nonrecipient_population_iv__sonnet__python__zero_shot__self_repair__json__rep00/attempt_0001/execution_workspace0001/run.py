import json
import numpy as np
import pandas as pd

hh = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

df = hh[hh["recipient"] == 0].copy()
for c in ["eligible", "instrument", "dose", "baseline", "weight", "outcome"]:
    df[c] = pd.to_numeric(df[c], errors="coerce")
df = df.dropna(subset=["eligible", "instrument", "dose", "baseline", "weight", "outcome"])
df = df[df["weight"] > 0]
df["eligible"] = df["eligible"].astype(int)

e = df["eligible"].values.astype(float)
ne = 1.0 - e
d = df["dose"].values
b = df["baseline"].values
z = df["instrument"].values
y = df["outcome"].values
w = df["weight"].values
n = len(df)

X = np.column_stack([d * ne, d * e, ne, e, b * ne, b * e])
Z = np.column_stack([ne, e, b * ne, b * e, z * ne, z * e])

sw = np.sqrt(w)
Xw = X * sw[:, None]
Zw = Z * sw[:, None]
yw = y * sw
ZtZ_inv = np.linalg.pinv(Zw.T @ Zw)
Pz_X = Zw @ (ZtZ_inv @ (Zw.T @ Xw))
beta = np.linalg.solve(Pz_X.T @ Xw, Pz_X.T @ yw)

def wmean(mask):
    return float(np.sum(w[mask] * d[mask]) / np.sum(w[mask]))

m0 = e == 0
m1 = e == 1
mean0 = wmean(m0)
mean1 = wmean(m1)
eff0 = float(beta[0] * mean0)
eff1 = float(beta[1] * mean1)

census["eligible"] = pd.to_numeric(census["eligible"]).astype(int)
cg = census.groupby("eligible")["nonrecipient_population"].sum()
p0 = float(cg.get(0, 0.0))
p1 = float(cg.get(1, 0.0))
pop_eff = (p0 * eff0 + p1 * eff1) / (p0 + p1)

def est(term, val):
    return {"term": term, "estimate": float(val), "se": None, "n_obs": int(n)}

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        est("ineligible_effect", eff0),
        est("eligible_nonrecipient_effect", eff1),
        est("population_effect", pop_eff),
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "sample": "recipient == 0 (all nonrecipient households, both village treatment statuses)",
        "endogenous": ["dose*(1-eligible)", "dose*eligible"],
        "exogenous": ["1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"],
        "excluded_instruments": ["instrument*(1-eligible)", "instrument*eligible"],
        "weights": "weight",
        "group_effect": "dose slope times weight-weighted mean dose in group (zero-dose counterfactual, synthetic convention)",
        "aggregation": "census nonrecipient_population weights",
    },
    "diagnostics": {
        "n_obs": int(n),
        "n_ineligible": int(m0.sum()),
        "n_eligible_nonrecipient": int(m1.sum()),
        "beta": [float(v) for v in beta],
        "slope_ineligible": float(beta[0]),
        "slope_eligible": float(beta[1]),
        "mean_dose_ineligible": mean0,
        "mean_dose_eligible": mean1,
        "census_pop_ineligible": p0,
        "census_pop_eligible": p1,
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
