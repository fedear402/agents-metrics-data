import json
import numpy as np
import pandas as pd
from scipy.stats import f

data = pd.read_csv('input.csv')
y = data['y'].to_numpy(float)
endog = data['endog'].to_numpy(float)
n = len(y)
controls = np.column_stack([np.ones(n), data['x'].to_numpy(float)])
excluded = data[['z1', 'z2']].to_numpy(float)
full = np.column_stack([controls, excluded])
q = excluded.shape[1]
df = n - full.shape[1]


def residual(v, design):
    return v - design @ np.linalg.lstsq(design, v, rcond=None)[0]


ry, rd = residual(y, controls), residual(endog, controls)
uy, ud = residual(y, full), residual(endog, full)
critical = f.ppf(.95, q, df)
k = q * critical / df
A = rd @ rd - (1 + k) * (ud @ ud)
B = -2 * (ry @ rd - (1 + k) * (uy @ ud))
C = ry @ ry - (1 + k) * (uy @ uy)


def accepts(beta):
    return A * beta * beta + B * beta + C <= 0


def direct_F(beta):
    r = residual(y - beta * endog, controls)
    u = residual(y - beta * endog, full)
    return ((r @ r - u @ u) / q) / ((u @ u) / df)


discriminant = B * B - 4 * A * C
if abs(A) > 1e-12 and discriminant > 0:
    sq = np.sqrt(discriminant)
    boundaries = np.sort([(-B - sq) / (2 * A), (-B + sq) / (2 * A)])
    low, high = float(boundaries[0]), float(boundaries[1])
    unbounded = int(A < 0)
elif abs(A) <= 1e-12 and abs(B) > 0:
    low = high = float(-C / B)
    unbounded = 1
else:
    low = high = float('nan')
    unbounded = int(A < 0)

rows = [
    {'term': 'boundary_low', 'estimate': low, 'se': None, 'n_obs': n},
    {'term': 'boundary_high', 'estimate': high, 'se': None, 'n_obs': n},
    {'term': 'accepts_zero', 'estimate': float(int(accepts(0.))), 'se': None, 'n_obs': n},
    {'term': 'unbounded', 'estimate': float(unbounded), 'se': None, 'n_obs': n},
    {'term': 'ar_f_at_one', 'estimate': float(direct_F(1.)), 'se': None, 'n_obs': n},
]
out = {
    'task_id': 'broad_ar_confidence_set',
    'platform': 'python',
    'estimates': rows,
    'method_metadata': {'estimator': 'Anderson-Rubin test inversion (analytic quadratic)',
                        'vcov': 'homoskedastic F'},
    'diagnostics': {'A': float(A), 'B': float(B), 'C': float(C),
                    'critical': float(critical), 'df_num': q, 'df_den': df},
}
with open('result.json', 'w') as stream:
    json.dump(out, stream, indent=2)
