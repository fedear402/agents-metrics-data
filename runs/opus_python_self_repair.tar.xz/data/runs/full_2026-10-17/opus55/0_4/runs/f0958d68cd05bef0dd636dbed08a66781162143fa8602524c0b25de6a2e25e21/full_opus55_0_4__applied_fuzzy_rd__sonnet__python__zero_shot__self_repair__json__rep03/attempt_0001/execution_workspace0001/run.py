import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df = df.dropna(subset=["score", "participated", "earnings"])
s = df["score"].astype(float).to_numpy()
mask = np.abs(s) < 1
d = df.loc[mask]
s = d["score"].astype(float).to_numpy()
y = d["earnings"].astype(float).to_numpy()
p = d["participated"].astype(float).to_numpy()
w = 1 - np.abs(s)
D = (s >= 0).astype(float)
X = np.column_stack([np.ones_like(s), D, s, D * s])
n = len(s)

Xw = X * w[:, None]
A = X.T @ Xw
Ainv = np.linalg.inv(A)
by = Ainv @ (Xw.T @ y)
bp = Ainv @ (Xw.T @ p)
ey = y - X @ by
ep = p - X @ bp

gy = Xw * ey[:, None]
gp = Xw * ep[:, None]
Vyy = Ainv @ (gy.T @ gy) @ Ainv
Vpp = Ainv @ (gp.T @ gp) @ Ainv
Vyp = Ainv @ (gy.T @ gp) @ Ainv

rf = by[1]
fs = bp[1]
var_rf = Vyy[1, 1]
var_fs = Vpp[1, 1]
cov = Vyp[1, 1]
te = rf / fs
g = np.array([1 / fs, -rf / fs**2])
V = np.array([[var_rf, cov], [cov, var_fs]])
se_te = float(np.sqrt(g @ V @ g))

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": float(te), "se": se_te, "n_obs": int(n)},
        {"term": "reduced_form", "estimate": float(rf), "se": float(np.sqrt(var_rf)), "n_obs": int(n)},
        {"term": "first_stage", "estimate": float(fs), "se": float(np.sqrt(var_fs)), "n_obs": int(n)},
    ],
    "method_metadata": {
        "estimator": "fuzzy RD, local linear, triangular kernel, bandwidth 1, cutoff 0, ratio of WLS discontinuities",
        "vcov": "HC0 sandwich, joint covariance of reduced form and first stage, delta method for ratio",
    },
    "diagnostics": {"cov_rf_fs": float(cov)},
}
with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
