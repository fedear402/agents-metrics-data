import json
import numpy as np
import pandas as pd
from scipy.stats import f

df_in = pd.read_csv('input.csv')
y = df_in['y'].to_numpy(float)
d = df_in['endog'].to_numpy(float)
x = df_in['x'].to_numpy(float)
z1 = df_in['z1'].to_numpy(float)
z2 = df_in['z2'].to_numpy(float)
n = len(y)

controls = np.column_stack([np.ones(n), x])
full = np.column_stack([controls, z1, z2])
q = 2
dfree = n - full.shape[1]

def residual(v, design):
    return v - design @ np.linalg.lstsq(design, v, rcond=None)[0]

ry, rd = residual(y, controls), residual(d, controls)
uy, ud = residual(y, full), residual(d, full)
critical = f.ppf(0.95, q, dfree)
k = q * critical / dfree
A = rd @ rd - (1 + k) * (ud @ ud)
B = -2 * (ry @ rd - (1 + k) * (uy @ ud))
C = ry @ ry - (1 + k) * (uy @ uy)

def direct_F(beta):
    r = residual(y - beta * d, controls)
    u = residual(y - beta * d, full)
    return ((r @ r - u @ u) / q) / ((u @ u) / dfree)

def accepts(beta):
    return A * beta * beta + B * beta + C <= 0

disc = B * B - 4 * A * C
if abs(A) > 1e-12 and disc > 0:
    roots = np.sort(np.roots([A, B, C]).real)
    low, high = float(roots[0]), float(roots[1])
    unbounded = int(A < 0)
elif abs(A) <= 1e-12 and abs(B) > 0:
    r = -C / B
    low = high = float(r)
    unbounded = 1
else:
    low = high = float('nan')
    unbounded = int(A < 0)

rows = [
    {'term': 'boundary_low', 'estimate': low, 'se': None, 'n_obs': n},
    {'term': 'boundary_high', 'estimate': high, 'se': None, 'n_obs': n},
    {'term': 'accepts_zero', 'estimate': float(int(accepts(0.0))), 'se': None, 'n_obs': n},
    {'term': 'unbounded', 'estimate': float(unbounded), 'se': None, 'n_obs': n},
    {'term': 'ar_f_at_one', 'estimate': float(direct_F(1.0)), 'se': None, 'n_obs': n},
]

out = {
    'task_id': 'broad_ar_confidence_set',
    'platform': 'python',
    'estimates': rows,
    'method_metadata': {'estimator': 'Anderson-Rubin test inversion (analytic quadratic)',
                        'vcov': 'homoskedastic'},
    'diagnostics': {'A': float(A), 'B': float(B), 'C': float(C),
                    'critical': float(critical), 'df_num': q, 'df_den': dfree},
}
with open('result.json', 'w') as fh:
    json.dump(out, fh, indent=2)
