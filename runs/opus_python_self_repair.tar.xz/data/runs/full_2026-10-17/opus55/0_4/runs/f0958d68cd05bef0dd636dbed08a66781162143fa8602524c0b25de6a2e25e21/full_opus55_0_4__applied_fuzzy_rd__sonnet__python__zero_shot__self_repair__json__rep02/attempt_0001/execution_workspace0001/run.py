import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df = df[["score", "participated", "earnings"]].dropna()
d = df[np.abs(df["score"]) < 1].copy()

s = d["score"].to_numpy(dtype=float)
w = 1.0 - np.abs(s)
D = (s >= 0).astype(float)
X = np.column_stack([np.ones_like(s), D, s, D * s])
y = d["earnings"].to_numpy(dtype=float)
t = d["participated"].to_numpy(dtype=float)
n = len(s)

XtWX = X.T @ (X * w[:, None])
bread = np.linalg.inv(XtWX)

def fit(v):
    b = bread @ (X.T @ (w * v))
    e = v - X @ b
    return b, e

by, ey = fit(y)
bt, et = fit(t)

# Influence functions for each coefficient vector (HC0, no df correction)
IFy = (X * (w * ey)[:, None]) @ bread  # n x k
IFt = (X * (w * et)[:, None]) @ bread

j = 1
gy = IFy[:, j]
gt = IFt[:, j]
var_rf = float(gy @ gy)
var_fs = float(gt @ gt)
cov = float(gy @ gt)

rf = float(by[j])
fs = float(bt[j])
te = rf / fs

grad = np.array([1.0 / fs, -rf / fs ** 2])
V = np.array([[var_rf, cov], [cov, var_fs]])
se_te = float(np.sqrt(grad @ V @ grad))

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": te, "se": se_te, "n_obs": int(n)},
        {"term": "reduced_form", "estimate": rf, "se": float(np.sqrt(var_rf)), "n_obs": int(n)},
        {"term": "first_stage", "estimate": fs, "se": float(np.sqrt(var_fs)), "n_obs": int(n)},
    ],
    "method_metadata": {
        "estimator": "fuzzy RD, local linear, triangular kernel, h=1, cutoff 0, separate slopes; Wald ratio",
        "vcov": "HC0 sandwich, joint covariance of RF and FS, delta method for ratio",
    },
    "diagnostics": {
        "cov_rf_fs": cov,
        "n_left": int((D == 0).sum()),
        "n_right": int((D == 1).sum()),
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
