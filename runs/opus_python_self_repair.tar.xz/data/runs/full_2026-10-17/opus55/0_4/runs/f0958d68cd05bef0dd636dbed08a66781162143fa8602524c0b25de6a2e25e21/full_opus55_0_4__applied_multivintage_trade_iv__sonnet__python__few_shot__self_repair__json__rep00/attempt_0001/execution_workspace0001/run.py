import json
import numpy as np
import pandas as pd

def s(series):
    return series.astype(str).str.strip()

cw = pd.read_csv("crosswalk.csv", dtype=str)
trade = pd.read_csv("trade.csv", dtype={"code": str})
areas = pd.read_csv("areas.csv")
emp = pd.read_csv("employment.csv")
out = pd.read_csv("outcomes.csv")

cw["code"] = s(cw["code"]); cw["industry"] = s(cw["industry"])
trade["code"] = s(trade["code"])
trade = trade.merge(cw, on="code", how="inner")
for d in (areas, emp):
    d["vintage"] = s(d["vintage"]).str.lower()
emp["industry"] = s(emp["industry"])
for d in (trade, areas, emp, out):
    d["period"] = s(d["period"])
    if "area" in d:
        d["area"] = s(d["area"])

industries = sorted(cw["industry"].unique())
emp = emp[emp["industry"].isin(industries)]
emp["employment"] = pd.to_numeric(emp["employment"], errors="coerce").fillna(0.0)
emp = emp.groupby(["area", "period", "vintage", "industry"], as_index=False)["employment"].sum()

def build(vintage, change_col, name):
    a = areas[areas["vintage"] == vintage][["area", "period", "total_employment"]].drop_duplicates(["area", "period"])
    e = emp[emp["vintage"] == vintage]
    grid = a[["area", "period"]].merge(pd.DataFrame({"industry": industries}), how="cross")
    grid = grid.merge(e[["area", "period", "industry", "employment"]],
                      on=["area", "period", "industry"], how="left")
    grid["employment"] = grid["employment"].fillna(0.0)
    nat = grid.groupby(["period", "industry"], as_index=False)["employment"].sum().rename(columns={"employment": "nat"})
    grid = grid.merge(nat, on=["period", "industry"])
    grid = grid.merge(trade[["period", "industry", change_col, "price_index", "years"]],
                      on=["period", "industry"], how="inner")
    grid["shock"] = grid[change_col] / grid["nat"] / (grid["price_index"] / 100.0) / 1000.0 * (10.0 / grid["years"])
    grid["c"] = grid["employment"] * grid["shock"]
    r = grid.groupby(["area", "period"], as_index=False)["c"].sum().merge(a, on=["area", "period"])
    r[name] = r["c"] / r["total_employment"]
    return r[["area", "period", name]]

xdf = build("base", "us_change", "x")
zdf = build("early", "other_change", "z")
pop = areas[areas["vintage"] == "base"][["area", "period", "population"]].drop_duplicates(["area", "period"])
df = out.merge(xdf, on=["area", "period"]).merge(zdf, on=["area", "period"]).merge(pop, on=["area", "period"])
df = df.dropna(subset=["change_pp", "control", "x", "z", "population"])

per = pd.to_numeric(df["period"]).values.astype(float)
n = len(df)
X = np.column_stack([np.ones(n), per, df["control"].values.astype(float), df["x"].values])
Z = np.column_stack([np.ones(n), per, df["control"].values.astype(float), df["z"].values])
y = df["change_pp"].values.astype(float)
sw = np.sqrt(df["population"].values.astype(float))
Xs, Zs, ys = X * sw[:, None], Z * sw[:, None], y * sw
Xhat = Zs @ np.linalg.lstsq(Zs, Xs, rcond=None)[0]
beta = np.linalg.solve(Xhat.T @ Xs, Xhat.T @ ys)

def get(d, col, area, period):
    m = d[(d["area"] == area) & (pd.to_numeric(d["period"]) == period)]
    return float(m[col].iloc[0])

a0 = sorted(df["area"].unique(), key=lambda v: float(v) if v.replace('.', '', 1).lstrip('-').isdigit() else v)[0]
a0 = "0" if (df["area"] == "0").any() else a0

est = {
    "iv_slope": float(beta[3]),
    "exposure_area0_period0": get(xdf, "x", a0, 0),
    "exposure_area0_period1": get(xdf, "x", a0, 1),
    "instrument_area0_period0": get(zdf, "z", a0, 0),
}
res = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [{"term": k, "estimate": float(f"{v:.15g}"), "se": None, "n_obs": int(n)} for k, v in est.items()],
    "method_metadata": {"estimator": "weighted 2SLS (manual numpy)", "weights": "base-vintage population",
                        "exogenous": ["intercept", "period", "control"], "endogenous": "x", "instrument": "z"},
    "diagnostics": {"n_obs": int(n), "coefficients": [float(b) for b in beta]},
}
with open("result.json", "w") as f:
    json.dump(res, f, indent=2)
