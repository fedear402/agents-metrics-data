import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df["date"] = pd.to_datetime(df["date"])
df = df.sort_values("date").reset_index(drop=True)

df["lsales"] = np.log(df["sales"].astype(float))
df["dlvix"] = np.log(df["vix"].astype(float)).diff()

L = 15
lag_cols = []
for k in range(1, L + 1):
    c = f"lag_{k}"
    df[c] = df["dlvix"].shift(k)
    lag_cols.append(c)

d = df[["lsales"] + lag_cols].dropna().reset_index(drop=True)
y = d["lsales"].to_numpy(dtype=float)
X = np.column_stack([np.ones(len(d))] + [d[c].to_numpy(dtype=float) for c in lag_cols])
N, K = X.shape

XtX_inv = np.linalg.inv(X.T @ X)
beta = XtX_inv @ (X.T @ y)
u = y - X @ beta

g = X * u[:, None]
S = g.T @ g
for j in range(1, L + 1):
    w = 1.0 - j / (L + 1.0)
    G = g[j:].T @ g[:-j]
    S += w * (G + G.T)

V = XtX_inv @ S @ XtX_inv
V *= N / (N - K)

r = np.zeros(K)
r[1:] = 1.0
cum = float(r @ beta)
cum_se = float(np.sqrt(r @ V @ r))

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {"term": "cumulative_response", "estimate": cum, "se": cum_se, "n_obs": int(N)},
        {"term": "lag_1", "estimate": float(beta[1]), "se": float(np.sqrt(V[1, 1])), "n_obs": int(N)},
        {"term": "lag_15", "estimate": float(beta[15]), "se": float(np.sqrt(V[15, 15])), "n_obs": int(N)},
    ],
    "method_metadata": {
        "estimator": "OLS of log(sales) on intercept and lags 1-15 of diff(log(vix))",
        "vcov": "Newey-West HAC, maxlag 15, Bartlett weights 1-j/16, scaled by N/(N-16)",
    },
    "diagnostics": {"n_params": int(K)},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
