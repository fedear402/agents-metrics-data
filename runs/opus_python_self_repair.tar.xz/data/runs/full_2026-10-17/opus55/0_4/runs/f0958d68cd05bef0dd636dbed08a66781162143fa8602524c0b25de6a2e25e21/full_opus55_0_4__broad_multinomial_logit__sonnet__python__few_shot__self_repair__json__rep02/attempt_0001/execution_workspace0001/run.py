import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy.special import softmax

df = pd.read_csv("input.csv")
n_full = int(len(df))
d = df[["y", "x", "z"]].dropna().copy()
d["y"] = d["y"].astype(int)

outcomes = sorted(d["y"].unique().tolist())
assert outcomes == [0, 1, 2], outcomes

X = pd.DataFrame({"const": np.ones(len(d)), "x": d["x"].to_numpy(float), "z": d["z"].to_numpy(float)})
yv = d["y"].to_numpy()
fit = sm.MNLogit(yv, X).fit(method="newton", disp=False, maxiter=200, tol=1e-12)

# Parameter columns enumerate nonbase outcomes 1 and 2 in order.
coefs = fit.params.copy()
ses = fit.bse.copy()
assert coefs.shape[1] == 2
coefs.columns = [1, 2]
ses.columns = [1, 2]

eta = np.r_[0.0, coefs.loc["const", 1], coefs.loc["const", 2]]
p0 = softmax(eta)
pred = np.asarray(fit.predict(pd.DataFrame({"const": [1.0], "x": [0.0], "z": [0.0]})))[0]
assert np.allclose(pred, p0)

def row(term, est, se):
    return {"term": term, "estimate": float(est),
            "se": None if se is None else float(se), "n_obs": n_full}

estimates = [
    row("x_cat1", coefs.loc["x", 1], ses.loc["x", 1]),
    row("z_cat1", coefs.loc["z", 1], ses.loc["z", 1]),
    row("x_cat2", coefs.loc["x", 2], ses.loc["x", 2]),
    row("z_cat2", coefs.loc["z", 2], ses.loc["z", 2]),
    row("prob_cat2_zero", p0[2], None),
]

out = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {"estimator": "multinomial logit MLE (statsmodels MNLogit), base outcome 0",
                        "vcov": "observed information (inverse Hessian)"},
    "diagnostics": {"converged": bool(fit.mle_retvals.get("converged", True)),
                    "llf": float(fit.llf), "n_used": int(len(d))},
}
with open("result.json", "w") as f:
    json.dump(out, f, indent=2, allow_nan=False)
