import json
import numpy as np
import pandas as pd
from scipy import stats

df = pd.read_csv("input.csv")
n = len(df)
y = df["y"].to_numpy(float)
e = df["endog"].to_numpy(float)
W = np.column_stack([np.ones(n), df["x"].to_numpy(float)])
Z = np.column_stack([W, df["z1"].to_numpy(float), df["z2"].to_numpy(float)])

def resid(M, v):
    b, *_ = np.linalg.lstsq(M, v, rcond=None)
    return v - M @ b

dfd = n - 4
crit = stats.f.ppf(0.95, 2, dfd)
k = 2 * crit / dfd

ryW, reW = resid(W, y), resid(W, e)
ryZ, reZ = resid(Z, y), resid(Z, e)

def Q(a_w, b_w, a_z, b_z):
    num = a_w @ b_w - a_z @ b_z  # a'(M_W - M_Z)b
    den = a_z @ b_z              # a'M_Z b
    return num - k * den

Ayy = Q(ryW, ryW, ryZ, ryZ)
Aye = Q(ryW, reW, ryZ, reZ)
Aee = Q(reW, reW, reZ, reZ)

def F(b):
    uw = ryW - b * reW
    uz = ryZ - b * reZ
    rssr, rssu = uw @ uw, uz @ uz
    return ((rssr - rssu) / 2) / (rssu / dfd)

# acceptance: Aee b^2 - 2 Aye b + Ayy <= 0
disc = Aye**2 - Aee * Ayy
roots = []
if disc > 0 and Aee != 0:
    s = np.sqrt(disc)
    roots = sorted([(Aye - s) / Aee, (Aye + s) / Aee])
lo = float(roots[0]) if roots else float("nan")
hi = float(roots[1]) if roots else float("nan")

accepts_zero = 1.0 if F(0.0) <= crit else 0.0
unbounded = 1.0 if Aee < 0 or (Aee == 0 and True) else 0.0
if Aee > 0:
    unbounded = 0.0

out = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": [
        {"term": "boundary_low", "estimate": lo, "se": None, "n_obs": n},
        {"term": "boundary_high", "estimate": hi, "se": None, "n_obs": n},
        {"term": "accepts_zero", "estimate": accepts_zero, "se": None, "n_obs": n},
        {"term": "unbounded", "estimate": unbounded, "se": None, "n_obs": n},
        {"term": "ar_f_at_one", "estimate": float(F(1.0)), "se": None, "n_obs": n},
    ],
    "method_metadata": {"estimator": "Anderson-Rubin test inversion (analytic quadratic)",
                        "vcov": "homoskedastic F(2, n-4)"},
    "diagnostics": {"f_crit": float(crit), "quad_a": float(Aee), "quad_b": float(-2 * Aye),
                    "quad_c": float(Ayy)},
}
with open("result.json", "w") as f:
    json.dump(out, f, indent=2)
