import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df["date"] = pd.to_datetime(df["date"])
df = df.sort_values("date").reset_index(drop=True)
df["ly"] = np.log(df["sales"].astype(float))
df["dv"] = np.log(df["vix"].astype(float)).diff()
L = 15
cols = []
for k in range(1, L + 1):
    c = f"lag_{k}"
    df[c] = df["dv"].shift(k)
    cols.append(c)
d = df.dropna(subset=["ly"] + cols).reset_index(drop=True)
y = d["ly"].to_numpy()
X = np.column_stack([np.ones(len(d))] + [d[c].to_numpy() for c in cols])
N, K = X.shape
XtX_inv = np.linalg.inv(X.T @ X)
b = XtX_inv @ X.T @ y
e = y - X @ b
u = X * e[:, None]
S = u.T @ u
for j in range(1, L + 1):
    w = 1 - j / (L + 1)
    G = u[j:].T @ u[:-j]
    S += w * (G + G.T)
V = XtX_inv @ S @ XtX_inv * (N / (N - K))
se = np.sqrt(np.diag(V))
g = np.zeros(K); g[1:] = 1
cum = float(g @ b)
cum_se = float(np.sqrt(g @ V @ g))
res = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {"term": "cumulative_response", "estimate": cum, "se": cum_se, "n_obs": int(N)},
        {"term": "lag_1", "estimate": float(b[1]), "se": float(se[1]), "n_obs": int(N)},
        {"term": "lag_15", "estimate": float(b[15]), "se": float(se[15]), "n_obs": int(N)},
    ],
    "method_metadata": {"estimator": "OLS distributed lag of log(sales) on lags 1-15 of dlog(vix)",
                        "vcov": "Newey-West HAC, Bartlett, maxlag 15, scaled N/(N-16)"},
    "diagnostics": {},
}
with open("result.json", "w") as f:
    json.dump(res, f, indent=2)
