import json
import numpy as np
import pandas as pd

cw = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv")
areas = pd.read_csv("areas.csv")
emp = pd.read_csv("employment.csv")
out = pd.read_csv("outcomes.csv")

for d in (areas, emp):
    d["vintage"] = d["vintage"].astype(str).str.strip().str.lower()
cw["code"] = cw["code"].astype(str).str.strip()
trade["code"] = trade["code"].astype(str).str.strip()
cw["industry"] = cw["industry"].astype(str).str.strip()
emp["industry"] = emp["industry"].astype(str).str.strip()

tr = trade.merge(cw, on="code", how="inner")
industries = sorted(cw["industry"].unique())
area_ids = sorted(areas["area"].unique())
periods = sorted(areas["period"].unique())

def exposure(vintage, change_col):
    res = {}
    e = emp[emp["vintage"] == vintage]
    a = areas[areas["vintage"] == vintage]
    for p in periods:
        ep = e[e["period"] == p].groupby(["area", "industry"])["employment"].sum().unstack(fill_value=0.0)
        ep = ep.reindex(index=area_ids, columns=industries, fill_value=0.0).fillna(0.0)
        national = ep.sum(axis=0)
        tp = tr[tr["period"] == p].set_index("industry").reindex(industries)
        price = float(tp["price_index"].iloc[0])
        yrs = float(tp["years"].iloc[0])
        shock = tp[change_col].astype(float) / national / (price / 100) / 1000 * (10 / yrs)
        tot = a[a["period"] == p].set_index("area")["total_employment"].reindex(area_ids).astype(float)
        val = ep.values @ shock.values / tot.values
        for ar, v in zip(area_ids, val):
            res[(ar, p)] = float(v)
    return res

xd = exposure("base", "us_change")
zd = exposure("early", "other_change")

pop = areas[areas["vintage"] == "base"][["area", "period", "population"]]
df = out.merge(pop, on=["area", "period"], how="inner")
df["x"] = [xd[(a, p)] for a, p in zip(df["area"], df["period"])]
df["z"] = [zd[(a, p)] for a, p in zip(df["area"], df["period"])]
df = df.dropna(subset=["change_pp", "control", "population", "x", "z"])

per = pd.to_numeric(df["period"], errors="coerce")
if per.isna().any():
    per = pd.Series(pd.factorize(df["period"], sort=True)[0], index=df.index)
n = len(df)
const = np.ones(n)
X = np.column_stack([const, per.values.astype(float), df["control"].values.astype(float), df["x"].values])
Z = np.column_stack([const, per.values.astype(float), df["control"].values.astype(float), df["z"].values])
y = df["change_pp"].values.astype(float)
w = df["population"].values.astype(float)

ZW = Z.T * w
Pz = np.linalg.solve(ZW @ Z, ZW @ X)
Xh = Z @ Pz
beta = np.linalg.solve((Xh.T * w) @ X, (Xh.T * w) @ y)
iv_slope = float(beta[-1])

a0 = area_ids[0] if 0 not in area_ids else 0
ests = {
    "iv_slope": iv_slope,
    "exposure_area0_period0": xd[(a0, periods[0])],
    "exposure_area0_period1": xd[(a0, periods[1])],
    "instrument_area0_period0": zd[(a0, periods[0])],
}
result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [{"term": k, "estimate": float(v), "se": None, "n_obs": int(n)} for k, v in ests.items()],
    "method_metadata": {
        "estimator": "weighted 2SLS (manual)",
        "exogenous": ["intercept", "period", "control"],
        "endogenous": "x", "instrument": "z", "weights": "base-vintage population",
    },
    "diagnostics": {"n_obs": int(n), "n_industries": len(industries), "periods": [str(p) for p in periods],
                    "coefficients": [float(b) for b in beta]},
}
with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(ests))
