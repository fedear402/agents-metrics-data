import json
import numpy as np
import pandas as pd

hh = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

d = hh[hh["recipient"] == 0].copy()
for c in ["eligible", "instrument", "dose", "baseline", "weight", "outcome"]:
    d[c] = pd.to_numeric(d[c], errors="coerce")
d = d.dropna(subset=["eligible", "instrument", "dose", "baseline", "weight", "outcome"])
d = d[d["weight"] > 0]
n_obs = int(len(d))

e = d["eligible"].to_numpy(float)
ne = 1.0 - e
dose = d["dose"].to_numpy(float)
base = d["baseline"].to_numpy(float)
inst = d["instrument"].to_numpy(float)
w = d["weight"].to_numpy(float)
y = d["outcome"].to_numpy(float)

exog = np.column_stack([ne, e, base * ne, base * e])
endog = np.column_stack([dose * ne, dose * e])
X = np.column_stack([endog, exog])
Z = np.column_stack([exog, inst * ne, inst * e])

sw = np.sqrt(w)
Xw = X * sw[:, None]
Zw = Z * sw[:, None]
yw = y * sw
# first stage projection
pi, *_ = np.linalg.lstsq(Zw, Xw, rcond=None)
Xhat = Zw @ pi
beta = np.linalg.solve(Xhat.T @ Xw, Xhat.T @ yw)
b_ne, b_e = float(beta[0]), float(beta[1])

m0 = e == 0
m1 = e == 1
mean_dose0 = float(np.sum(w[m0] * dose[m0]) / np.sum(w[m0]))
mean_dose1 = float(np.sum(w[m1] * dose[m1]) / np.sum(w[m1]))
eff0 = b_ne * mean_dose0
eff1 = b_e * mean_dose1

census["eligible"] = pd.to_numeric(census["eligible"])
pop0 = float(census.loc[census["eligible"] == 0, "nonrecipient_population"].astype(float).sum())
pop1 = float(census.loc[census["eligible"] == 1, "nonrecipient_population"].astype(float).sum())
pop_eff = (pop0 * eff0 + pop1 * eff1) / (pop0 + pop1)

fs_rank = int(np.linalg.matrix_rank(Zw))
result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {"term": "ineligible_effect", "estimate": float(eff0), "se": None, "n_obs": n_obs},
        {"term": "eligible_nonrecipient_effect", "estimate": float(eff1), "se": None, "n_obs": n_obs},
        {"term": "population_effect", "estimate": float(pop_eff), "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS, group-specific intercepts, no common intercept",
        "endogenous": ["dose*(1-eligible)", "dose*eligible"],
        "exogenous": ["1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"],
        "excluded_instruments": ["instrument*(1-eligible)", "instrument*eligible"],
        "sample": "recipient == 0 (all nonrecipients, both village treatment statuses)",
        "counterfactual": "dose set to zero for every retained household (synthetic convention)",
        "aggregation": "census nonrecipient_population weights between groups",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "n_ineligible": int(m0.sum()),
        "n_eligible_nonrecipient": int(m1.sum()),
        "dose_slope_ineligible": b_ne,
        "dose_slope_eligible": b_e,
        "weighted_mean_dose_ineligible": mean_dose0,
        "weighted_mean_dose_eligible": mean_dose1,
        "census_pop_ineligible": pop0,
        "census_pop_eligible": pop1,
        "instrument_matrix_rank": fs_rank,
        "coefficients": [float(b) for b in beta],
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
