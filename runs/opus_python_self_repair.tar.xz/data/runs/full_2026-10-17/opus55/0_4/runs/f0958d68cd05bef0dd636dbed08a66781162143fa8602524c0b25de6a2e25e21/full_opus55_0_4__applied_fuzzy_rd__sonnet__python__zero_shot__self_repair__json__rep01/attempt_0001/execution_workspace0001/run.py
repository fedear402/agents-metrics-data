import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df = df[["score", "participated", "earnings"]].dropna()
df = df[np.abs(df["score"]) < 1].copy()
s = df["score"].to_numpy(float)
d = df["participated"].to_numpy(float)
y = df["earnings"].to_numpy(float)
w = 1 - np.abs(s)
r = (s >= 0).astype(float)
n = len(s)

# intercept, right indicator, slope, right*slope
X = np.column_stack([np.ones(n), r, s, r * s])
XtWX_inv = np.linalg.inv(X.T @ (X * w[:, None]))

def fit(v):
    b = XtWX_inv @ (X.T @ (w * v))
    return b, v - X @ b

by, ey = fit(y)
bd, ed = fit(d)

def cov(e1, e2):
    meat = (X * (w * e1)[:, None]).T @ (X * (w * e2)[:, None])
    return XtWX_inv @ meat @ XtWX_inv

Vyy = cov(ey, ey)[1, 1]
Vdd = cov(ed, ed)[1, 1]
Vyd = cov(ey, ed)[1, 1]

rf = by[1]
fs = bd[1]
te = rf / fs
g = np.array([1 / fs, -rf / fs**2])
V = np.array([[Vyy, Vyd], [Vyd, Vdd]])
se_te = float(np.sqrt(g @ V @ g))

res = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": float(te), "se": se_te, "n_obs": int(n)},
        {"term": "reduced_form", "estimate": float(rf), "se": float(np.sqrt(Vyy)), "n_obs": int(n)},
        {"term": "first_stage", "estimate": float(fs), "se": float(np.sqrt(Vdd)), "n_obs": int(n)},
    ],
    "method_metadata": {
        "estimator": "fuzzy RD, local linear, triangular kernel, h=1, cutoff 0, Wald ratio",
        "vcov": "HC0 sandwich, joint covariance, delta method",
    },
    "diagnostics": {"cov_rf_fs": float(Vyd), "n_left": int((r == 0).sum()), "n_right": int((r == 1).sum())},
}
with open("result.json", "w") as f:
    json.dump(res, f, indent=2)
