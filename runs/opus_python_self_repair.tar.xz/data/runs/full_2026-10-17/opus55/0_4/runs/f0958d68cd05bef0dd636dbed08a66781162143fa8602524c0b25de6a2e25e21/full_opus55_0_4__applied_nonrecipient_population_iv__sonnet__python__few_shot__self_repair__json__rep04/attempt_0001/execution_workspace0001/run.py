import json
import numpy as np
import pandas as pd

h = pd.read_csv("households.csv")
c = pd.read_csv("census.csv")
d = h[h["recipient"] == 0].copy()
d = d.dropna(subset=["eligible", "dose", "instrument", "baseline", "weight", "outcome"]).reset_index(drop=True)
e = d["eligible"].astype(float).values
ne = 1.0 - e
dose = d["dose"].astype(float).values
base = d["baseline"].astype(float).values
z = d["instrument"].astype(float).values
w = d["weight"].astype(float).values
y = d["outcome"].astype(float).values

X_exog = np.column_stack([ne, e, base * ne, base * e])
X_endog = np.column_stack([dose * ne, dose * e])
X = np.column_stack([X_endog, X_exog])
Z = np.column_stack([X_exog, z * ne, z * e])

sw = np.sqrt(w)
Xw, Zw, yw = X * sw[:, None], Z * sw[:, None], y * sw
PzX = Zw @ np.linalg.lstsq(Zw, Xw, rcond=None)[0]
beta = np.linalg.solve(PzX.T @ Xw, PzX.T @ yw)
slope_ne, slope_e = float(beta[0]), float(beta[1])

m0 = e == 0
m1 = e == 1
mean0 = float(np.average(dose[m0], weights=w[m0]))
mean1 = float(np.average(dose[m1], weights=w[m1]))
eff0 = slope_ne * mean0
eff1 = slope_e * mean1

c = c.copy()
c["eligible"] = c["eligible"].astype(int)
pop0 = float(c.loc[c["eligible"] == 0, "nonrecipient_population"].sum())
pop1 = float(c.loc[c["eligible"] == 1, "nonrecipient_population"].sum())
pop_eff = (eff0 * pop0 + eff1 * pop1) / (pop0 + pop1)

n = int(len(d))
result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {"term": "ineligible_effect", "estimate": float(eff0), "se": None, "n_obs": n},
        {"term": "eligible_nonrecipient_effect", "estimate": float(eff1), "se": None, "n_obs": n},
        {"term": "population_effect", "estimate": float(pop_eff), "se": None, "n_obs": n},
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS (pooled, group-interacted, no common intercept)",
        "sample": "recipient == 0",
        "endogenous": ["dose*(1-eligible)", "dose*eligible"],
        "exogenous": ["1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"],
        "excluded_instruments": ["instrument*(1-eligible)", "instrument*eligible"],
        "weights": "weight",
        "effect_definition": "dose slope times household-weighted mean dose within group; zero-dose counterfactual",
        "aggregation": "census nonrecipient_population weights",
    },
    "diagnostics": {
        "n_ineligible": int(m0.sum()),
        "n_eligible_nonrecipient": int(m1.sum()),
        "slope_ineligible": slope_ne,
        "slope_eligible_nonrecipient": slope_e,
        "weighted_mean_dose_ineligible": mean0,
        "weighted_mean_dose_eligible_nonrecipient": mean1,
        "population_ineligible": pop0,
        "population_eligible_nonrecipient": pop1,
        "coefficients": [float(b) for b in beta],
    },
}
with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))
