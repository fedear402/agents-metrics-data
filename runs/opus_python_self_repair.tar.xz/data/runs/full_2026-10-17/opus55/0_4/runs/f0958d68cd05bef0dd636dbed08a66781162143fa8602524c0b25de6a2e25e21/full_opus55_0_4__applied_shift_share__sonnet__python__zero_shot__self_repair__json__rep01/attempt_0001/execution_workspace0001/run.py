import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")

reg = df.groupby("region_id", sort=True).agg(
    region_weight=("region_weight", "first"), x=("x", "first"), y=("y", "first")
)
reg["e"] = reg["region_weight"] / reg["region_weight"].sum()

df = df.copy()
df["sg"] = df["share"] * df["shock"]
reg["z"] = df.groupby("region_id")["sg"].sum().reindex(reg.index).fillna(0.0)

e = reg["e"].values


def wiv(y, x, z, w):
    X = np.column_stack([np.ones_like(x), x])
    Z = np.column_stack([np.ones_like(z), z])
    ZWX = Z.T @ (w[:, None] * X)
    ZWy = Z.T @ (w * y)
    b = np.linalg.solve(ZWX, ZWy)
    return b, X, Z


# Regional estimates
b_reg, _, _ = wiv(reg["y"].values, reg["x"].values, reg["z"].values, e)
b_fs, _, _ = wiv(reg["x"].values, reg["z"].values, reg["z"].values, e)

# Demean
for v in ["y", "x", "z"]:
    reg[v + "0"] = reg[v] - np.sum(e * reg[v].values)

d = df.merge(reg[["e", "y0", "x0", "z0"]], left_on="region_id", right_index=True)
d["es"] = d["e"] * d["share"]
for v in ["y0", "x0", "z0"]:
    d["w_" + v] = d["es"] * d[v]
ind = d.groupby("industry_id", sort=True).agg(
    s=("es", "sum"), shock=("shock", "first"),
    wy=("w_y0", "sum"), wx=("w_x0", "sum"), wz=("w_z0", "sum"),
)
ind = ind[ind["s"] > 0].copy()
ind["ybar"] = ind["wy"] / ind["s"]
ind["xbar"] = ind["wx"] / ind["s"]
ind["zbar"] = ind["wz"] / ind["s"]
N = len(ind)
s = ind["s"].values
g = ind["shock"].values


def shock_iv_hc1(yv, xv, gv, w):
    b, X, Z = wiv(yv, xv, gv, w)
    u = yv - X @ b
    A = np.linalg.inv(Z.T @ (w[:, None] * X))
    meat = (Z * (w * u)[:, None]).T @ (Z * (w * u)[:, None])
    V = A @ meat @ A.T * N / (N - 2)
    return b, np.sqrt(V[1, 1])


b_e, se_e = shock_iv_hc1(ind["ybar"].values, ind["xbar"].values, g, s)
b_f, se_f = shock_iv_hc1(ind["xbar"].values, ind["zbar"].values, g, s)

eff = 1.0 / np.sum(s ** 2)

out = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": float(b_reg[1]), "se": float(se_e), "n_obs": int(N)},
        {"term": "first_stage", "estimate": float(b_fs[1]), "se": float(se_f), "n_obs": int(N)},
        {"term": "effective_shocks", "estimate": float(eff), "se": None, "n_obs": int(N)},
    ],
    "method_metadata": {
        "estimator": "weighted shift-share 2SLS with BHJ shock-level aggregation",
        "vcov": "shock-level HC1 (N/(N-2)), structural IV residuals, analytic weights s_n",
    },
    "diagnostics": {
        "shock_level_slope_effect": float(b_e[1]),
        "shock_level_slope_first_stage": float(b_f[1]),
        "n_regions": int(len(reg)),
    },
}

with open("result.json", "w") as f:
    json.dump(out, f, indent=2)
