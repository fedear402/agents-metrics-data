import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("input.csv")
n_full = int(len(df))
d = df[["y", "x", "z"]].dropna().copy()
d["y"] = d["y"].astype(int)

X = sm.add_constant(d[["x", "z"]], has_constant="add")
model = sm.MNLogit(d["y"], X)
res = model.fit(method="newton", maxiter=200, disp=False)

# Columns of params correspond to sorted non-base outcomes (base = smallest = 0)
outcomes = sorted(d["y"].unique())
params = res.params
bse = res.bse
col1 = list(outcomes).index(1) - 1
col2 = list(outcomes).index(2) - 1

def get(term, col):
    return float(params.iloc[:, col][term]), float(bse.iloc[:, col][term])

x1, sx1 = get("x", col1)
z1, sz1 = get("z", col1)
x2, sx2 = get("x", col2)
z2, sz2 = get("z", col2)

c1 = float(params.iloc[:, col1]["const"])
c2 = float(params.iloc[:, col2]["const"])
p2 = float(np.exp(c2) / (1.0 + np.exp(c1) + np.exp(c2)))

out = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": [
        {"term": "x_cat1", "estimate": x1, "se": sx1, "n_obs": n_full},
        {"term": "z_cat1", "estimate": z1, "se": sz1, "n_obs": n_full},
        {"term": "x_cat2", "estimate": x2, "se": sx2, "n_obs": n_full},
        {"term": "z_cat2", "estimate": z2, "se": sz2, "n_obs": n_full},
        {"term": "prob_cat2_zero", "estimate": p2, "se": None, "n_obs": n_full},
    ],
    "method_metadata": {
        "estimator": "multinomial logit MLE (statsmodels MNLogit), base outcome 0",
        "vcov": "observed information (inverse Hessian)",
    },
    "diagnostics": {
        "converged": bool(res.mle_retvals.get("converged", True)),
        "llf": float(res.llf),
        "n_used": int(res.nobs),
    },
}

with open("result.json", "w") as f:
    json.dump(out, f, indent=2)
