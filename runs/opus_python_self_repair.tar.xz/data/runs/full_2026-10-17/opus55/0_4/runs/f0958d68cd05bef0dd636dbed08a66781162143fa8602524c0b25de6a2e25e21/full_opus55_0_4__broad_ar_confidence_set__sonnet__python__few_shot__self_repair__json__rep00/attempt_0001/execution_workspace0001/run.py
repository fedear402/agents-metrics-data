import json
import numpy as np
import pandas as pd
from scipy.stats import f

df_in = pd.read_csv('input.csv')
cols = ['y', 'endog', 'x', 'z1', 'z2']
df_in = df_in[cols].dropna()
y = df_in['y'].to_numpy(float)
d = df_in['endog'].to_numpy(float)
n = len(y)
controls = np.column_stack([np.ones(n), df_in['x'].to_numpy(float)])
excluded = df_in[['z1', 'z2']].to_numpy(float)
full = np.column_stack([controls, excluded])
q = excluded.shape[1]
dof = n - full.shape[1]


def residual(v, design):
    return v - design @ np.linalg.lstsq(design, v, rcond=None)[0]


ry, rd = residual(y, controls), residual(d, controls)
uy, ud = residual(y, full), residual(d, full)
critical = f.ppf(0.95, q, dof)
k = q * critical / dof
A = rd @ rd - (1 + k) * (ud @ ud)
B = -2 * (ry @ rd - (1 + k) * (uy @ ud))
C = ry @ ry - (1 + k) * (uy @ uy)


def direct_F(beta):
    r = residual(y - beta * d, controls)
    u = residual(y - beta * d, full)
    return ((r @ r - u @ u) / q) / ((u @ u) / dof)


def accepts(beta):
    return direct_F(beta) <= critical


disc = B * B - 4 * A * C
scale = max(abs(A), abs(B), abs(C), 1e-300)
if abs(A) > 1e-12 * scale and disc > 0:
    sq = np.sqrt(disc)
    r1, r2 = (-B - sq) / (2 * A), (-B + sq) / (2 * A)
    lo, hi = float(min(r1, r2)), float(max(r1, r2))
    unbounded = int(A < 0)
elif abs(A) <= 1e-12 * scale and abs(B) > 0:
    lo = hi = float(-C / B)
    unbounded = 1
else:
    lo = hi = float('nan')
    unbounded = int(A < 0)

accepts_zero = int(accepts(0.0))
f_one = float(direct_F(1.0))


def clean(v):
    return None if v is None or not np.isfinite(v) else float(v)


rows = [
    {'term': 'boundary_low', 'estimate': clean(lo), 'se': None, 'n_obs': int(n)},
    {'term': 'boundary_high', 'estimate': clean(hi), 'se': None, 'n_obs': int(n)},
    {'term': 'accepts_zero', 'estimate': float(accepts_zero), 'se': None, 'n_obs': int(n)},
    {'term': 'unbounded', 'estimate': float(unbounded), 'se': None, 'n_obs': int(n)},
    {'term': 'ar_f_at_one', 'estimate': f_one, 'se': None, 'n_obs': int(n)},
]
out = {
    'task_id': 'broad_ar_confidence_set',
    'platform': 'python',
    'estimates': rows,
    'method_metadata': {'estimator': 'Anderson-Rubin test inversion (analytic quadratic)',
                        'vcov': 'homoskedastic'},
    'diagnostics': {'A': float(A), 'B': float(B), 'C': float(C),
                    'discriminant': float(disc), 'critical': float(critical),
                    'df_num': int(q), 'df_den': int(dof)},
}
with open('result.json', 'w') as fh:
    json.dump(out, fh, indent=2, allow_nan=False)
