import json
import numpy as np
import pandas as pd

hh = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

d = hh[hh["recipient"] == 0].copy()
d = d.dropna(subset=["eligible", "instrument", "dose", "baseline", "weight", "outcome"])
d = d[d["weight"] > 0]
n = int(len(d))

e = d["eligible"].astype(float).values
ne = 1.0 - e
dose = d["dose"].astype(float).values
base = d["baseline"].astype(float).values
z = d["instrument"].astype(float).values
w = d["weight"].astype(float).values
y = d["outcome"].astype(float).values

X = np.column_stack([dose * ne, dose * e, ne, e, base * ne, base * e])
Z = np.column_stack([ne, e, base * ne, base * e, z * ne, z * e])

sw = np.sqrt(w)
Xw = X * sw[:, None]
Zw = Z * sw[:, None]
yw = y * sw

# First stage projection, then second stage
coef_fs, *_ = np.linalg.lstsq(Zw, Xw, rcond=None)
Xhat = Zw @ coef_fs
beta, *_ = np.linalg.lstsq(Xhat, yw, rcond=None)
# equivalent exact 2SLS formula
A = Xw.T @ Zw @ np.linalg.pinv(Zw.T @ Zw)
beta = np.linalg.solve(A @ Zw.T @ Xw, A @ Zw.T @ yw)

b0, b1 = float(beta[0]), float(beta[1])
m0 = ne.astype(bool)
m1 = e.astype(bool)
md0 = float(np.sum(w[m0] * dose[m0]) / np.sum(w[m0]))
md1 = float(np.sum(w[m1] * dose[m1]) / np.sum(w[m1]))
eff0 = b0 * md0
eff1 = b1 * md1

census = census.copy()
census["eligible"] = census["eligible"].astype(int)
pop = census.groupby("eligible")["nonrecipient_population"].sum()
p0 = float(pop.get(0, 0.0))
p1 = float(pop.get(1, 0.0))
pop_eff = (p0 * eff0 + p1 * eff1) / (p0 + p1)

res = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {"term": "ineligible_effect", "estimate": float(eff0), "se": None, "n_obs": n},
        {"term": "eligible_nonrecipient_effect", "estimate": float(eff1), "se": None, "n_obs": n},
        {"term": "population_effect", "estimate": float(pop_eff), "se": None, "n_obs": n},
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS, group-interacted, no common intercept",
        "endogenous": ["dose*(1-eligible)", "dose*eligible"],
        "exogenous": ["1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"],
        "excluded_instruments": ["instrument*(1-eligible)", "instrument*eligible"],
        "weights": "weight",
        "sample": "recipient==0",
        "counterfactual": "dose set to zero for all retained households (synthetic convention)",
        "aggregation": "census nonrecipient_population weights",
    },
    "diagnostics": {
        "dose_slope_ineligible": b0,
        "dose_slope_eligible": b1,
        "weighted_mean_dose_ineligible": md0,
        "weighted_mean_dose_eligible": md1,
        "n_ineligible": int(m0.sum()),
        "n_eligible": int(m1.sum()),
        "census_pop_ineligible": p0,
        "census_pop_eligible": p1,
        "coefficients": [float(v) for v in beta],
    },
}

with open("result.json", "w") as f:
    json.dump(res, f, indent=2)
