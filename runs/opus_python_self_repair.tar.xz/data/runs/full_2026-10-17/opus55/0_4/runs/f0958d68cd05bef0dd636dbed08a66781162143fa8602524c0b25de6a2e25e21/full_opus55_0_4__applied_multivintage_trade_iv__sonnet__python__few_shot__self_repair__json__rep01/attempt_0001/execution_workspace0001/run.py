import json
import numpy as np
import pandas as pd

def rd(name):
    df = pd.read_csv(name, dtype=str)
    df.columns = [c.strip() for c in df.columns]
    for c in df.columns:
        df[c] = df[c].str.strip()
    return df

cw = rd("crosswalk.csv")
tr = rd("trade.csv")
ar = rd("areas.csv")
em = rd("employment.csv")
oc = rd("outcomes.csv")

for d in (ar, em):
    d["vintage"] = d["vintage"].str.lower()
for c in ["us_change", "other_change", "price_index", "years"]:
    tr[c] = tr[c].astype(float)
ar["total_employment"] = ar["total_employment"].astype(float)
ar["population"] = pd.to_numeric(ar["population"], errors="coerce")
em["employment"] = em["employment"].astype(float).fillna(0.0)
oc["control"] = oc["control"].astype(float)
oc["change_pp"] = oc["change_pp"].astype(float)

tr = tr.merge(cw[["code", "industry"]], on="code", how="left")
industries = sorted(set(cw["industry"]))
areas = sorted(set(ar["area"]) | set(em["area"]) | set(oc["area"]))
periods = sorted(set(oc["period"]))

def exposure(vintage, change_col):
    out = {}
    for p in periods:
        e = em[(em["period"] == p) & (em["vintage"] == vintage)]
        piv = e.pivot_table(index="area", columns="industry", values="employment",
                            aggfunc="sum", fill_value=0.0)
        piv = piv.reindex(index=areas, columns=industries, fill_value=0.0).fillna(0.0)
        nat = piv.sum(axis=0)
        t = tr[tr["period"] == p].set_index("industry").reindex(industries)
        shock = (t[change_col] / nat / (t["price_index"] / 100.0) / 1000.0
                 * (10.0 / t["years"]))
        tot = ar[(ar["period"] == p) & (ar["vintage"] == vintage)].set_index("area")["total_employment"]
        vals = piv.values @ shock.values.astype(float)
        for a, v in zip(areas, vals):
            out[(a, p)] = v / tot.get(a, np.nan)
    return out

xd = exposure("base", "us_change")
zd = exposure("early", "other_change")

df = oc.copy()
df["x"] = [xd[(a, p)] for a, p in zip(df["area"], df["period"])]
df["z"] = [zd[(a, p)] for a, p in zip(df["area"], df["period"])]
pop = ar[ar["vintage"] == "base"][["area", "period", "population"]]
df = df.merge(pop, on=["area", "period"], how="left")
pn = pd.to_numeric(df["period"], errors="coerce")
if pn.isna().any():
    pn = pd.Series(pd.factorize(df["period"], sort=True)[0], index=df.index).astype(float)
df["period_num"] = pn.astype(float)
df = df.dropna(subset=["change_pp", "x", "z", "control", "population", "period_num"])

n = len(df)
y = df["change_pp"].values
X = np.column_stack([np.ones(n), df["period_num"].values, df["control"].values, df["x"].values])
Z = np.column_stack([np.ones(n), df["period_num"].values, df["control"].values, df["z"].values])
w = df["population"].values.astype(float)
ZW = Z.T * w
Xh = Z @ np.linalg.solve(ZW @ Z, ZW @ X)
XhW = Xh.T * w
beta = np.linalg.solve(XhW @ X, XhW @ y)

a0 = areas[0] if "0" not in areas else "0"
p0, p1 = periods[0], periods[1] if len(periods) > 1 else periods[0]

est = {
    "iv_slope": float(beta[3]),
    "exposure_area0_period0": float(xd[(a0, p0)]),
    "exposure_area0_period1": float(xd[(a0, p1)]),
    "instrument_area0_period0": float(zd[(a0, p0)]),
}
res = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [{"term": k, "estimate": v, "se": None, "n_obs": int(n)} for k, v in est.items()],
    "method_metadata": {
        "estimator": "weighted 2SLS (manual numpy)",
        "weights": "base-vintage population",
        "exogenous": ["intercept", "period", "control"],
        "endogenous": "x", "instrument": "z",
    },
    "diagnostics": {
        "n_obs": int(n),
        "coefficients": [float(b) for b in beta],
        "periods": periods,
        "n_industries": len(industries),
    },
}
with open("result.json", "w") as f:
    json.dump(res, f, indent=2)
