import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")

reg = df.groupby("region_id", sort=True).first()[["region_weight", "x", "y"]]
reg["e"] = reg["region_weight"] / reg["region_weight"].sum()

S = df.pivot_table(index="region_id", columns="industry_id", values="share",
                   aggfunc="sum", fill_value=0.0).reindex(index=reg.index).fillna(0.0)
shock = df.groupby("industry_id")["shock"].first().reindex(S.columns)

z = S.values @ shock.values
reg["z"] = z
e = reg["e"].values

def wmean(v):
    return np.sum(e * v)

x = reg["x"].values
y = reg["y"].values
x0 = x - wmean(x)
y0 = y - wmean(y)
z0 = z - wmean(z)

beta_effect_reg = np.sum(e * z0 * y0) / np.sum(e * z0 * x0)
beta_fs_reg = np.sum(e * z0 * x0) / np.sum(e * z0 * z0)

Sm = S.values
es = e[:, None] * Sm
s_n = es.sum(axis=0)
keep = s_n > 0
s = s_n[keep]
g = shock.values[keep]

def agg(v0):
    return (es[:, keep] * v0[:, None]).sum(axis=0) / s

ybar, xbar, zbar = agg(y0), agg(x0), agg(z0)
N = len(s)

def wiv(dep, endog, inst, w):
    X = np.column_stack([np.ones_like(endog), endog])
    Z = np.column_stack([np.ones_like(inst), inst])
    ZWX = Z.T @ (w[:, None] * X)
    b = np.linalg.solve(ZWX, Z.T @ (w * dep))
    u = dep - X @ b
    meat = (Z * (w * u)[:, None]).T @ (Z * (w * u)[:, None])
    A = np.linalg.inv(ZWX)
    V = A @ meat @ A.T * len(dep) / (len(dep) - 2)
    return b[1], float(np.sqrt(V[1, 1]))

b_eff, se_eff = wiv(ybar, xbar, g, s)
b_fs, se_fs = wiv(xbar, zbar, g, s)

eff_shocks = 1.0 / np.sum(s ** 2)

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": float(beta_effect_reg), "se": se_eff, "n_obs": int(N)},
        {"term": "first_stage", "estimate": float(beta_fs_reg), "se": se_fs, "n_obs": int(N)},
        {"term": "effective_shocks", "estimate": float(eff_shocks), "se": None, "n_obs": int(N)},
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS with shift-share instrument; BHJ shock-level equivalent IV",
        "vcov": "shock-level HC1 (N/(N-2)), structural IV residuals, analytic weights s_n",
    },
    "diagnostics": {
        "shock_level_effect_slope": float(b_eff),
        "shock_level_first_stage_slope": float(b_fs),
        "n_regions": int(len(reg)),
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
