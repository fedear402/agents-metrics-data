import json
import numpy as np
import pandas as pd
from scipy import stats

df = pd.read_csv("./input.csv")
df = df[["group", "y"]].copy()
df["y"] = pd.to_numeric(df["y"], errors="coerce")
df = df.dropna(subset=["group", "y"])
df["group"] = df["group"].astype(str).str.strip()
df = df[df["group"] != ""]

groups = [g["y"].to_numpy(dtype=float) for _, g in df.groupby("group")]
groups = [g for g in groups if len(g) > 0]
n = int(sum(len(g) for g in groups))
k = len(groups)

grand = df["y"].mean()
ssb = sum(len(g) * (g.mean() - grand) ** 2 for g in groups)
ssw = sum(((g - g.mean()) ** 2).sum() for g in groups)
df_num = k - 1
df_den = n - k
F = (ssb / df_num) / (ssw / df_den) if df_den > 0 and ssw > 0 else float("nan")
p = float(stats.f.sf(F, df_num, df_den)) if np.isfinite(F) else float("nan")

def num(x):
    x = float(x)
    return x if np.isfinite(x) else None

result = {
    "task_id": "anova_oneway",
    "platform": "python",
    "estimates": [
        {"term": "F", "estimate": num(F), "se": None, "n_obs": n},
        {"term": "df_num", "estimate": float(df_num), "se": None, "n_obs": n},
        {"term": "df_den", "estimate": float(df_den), "se": None, "n_obs": n},
        {"term": "p_value", "estimate": num(p), "se": None, "n_obs": n},
    ],
    "method_metadata": {"estimator": "one-way ANOVA (classical F test, equal variances)", "vcov": "classical"},
    "diagnostics": {
        "n_groups": k,
        "group_sizes": {str(name): int(len(g)) for name, g in df.groupby("group")},
        "ss_between": num(ssb),
        "ss_within": num(ssw),
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
