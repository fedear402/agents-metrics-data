import json
import numpy as np
import pandas as pd

cw = pd.read_csv("crosswalk.csv")
tr = pd.read_csv("trade.csv")
ar = pd.read_csv("areas.csv")
em = pd.read_csv("employment.csv")
oc = pd.read_csv("outcomes.csv")

for d in (cw, tr):
    d["code"] = d["code"].astype(str).str.strip()
for d in (ar, em, oc):
    d["vintage"] = d["vintage"].astype(str).str.strip().str.lower() if "vintage" in d else None
cw["industry"] = cw["industry"].astype(str).str.strip()
em["industry"] = em["industry"].astype(str).str.strip()

tr = tr.merge(cw, on="code", how="inner")
industries = sorted(cw["industry"].unique())
areas = sorted(ar["area"].unique())
periods = sorted(tr["period"].unique())

em = em.groupby(["area", "period", "vintage", "industry"], as_index=False)["employment"].sum()


def exposure(vintage, change_col):
    out = {}
    e = em[em["vintage"] == vintage]
    a = ar[ar["vintage"] == vintage].set_index(["area", "period"])
    for p in periods:
        tp = tr[tr["period"] == p].set_index("industry")
        ep = e[e["period"] == p]
        grid = ep.pivot_table(index="area", columns="industry", values="employment",
                              aggfunc="sum").reindex(index=areas, columns=industries).fillna(0.0)
        nat = grid.sum(axis=0)
        for i in areas:
            tot = a.loc[(i, p), "total_employment"]
            s = 0.0
            for j in industries:
                r = tp.loc[j]
                s += (grid.loc[i, j] / tot) * (r[change_col] / nat[j]) / (r["price_index"] / 100) / 1000 * (10 / r["years"])
            out[(i, p)] = s
    return out


X = exposure("base", "us_change")
Z = exposure("early", "other_change")

df = oc.copy()
df["x"] = [X[(a, p)] for a, p in zip(df["area"], df["period"])]
df["z"] = [Z[(a, p)] for a, p in zip(df["area"], df["period"])]
pop = ar[ar["vintage"] == "base"][["area", "period", "population"]]
df = df.merge(pop, on=["area", "period"], how="left").dropna(subset=["change_pp", "control", "x", "z", "population"])

y = df["change_pp"].to_numpy(float)
w = df["population"].to_numpy(float)
one = np.ones(len(df))
Xm = np.column_stack([one, df["period"].astype(float), df["control"].astype(float), df["x"]])
Zm = np.column_stack([one, df["period"].astype(float), df["control"].astype(float), df["z"]])
sw = np.sqrt(w)
Xw, Zw, yw = Xm * sw[:, None], Zm * sw[:, None], y * sw
Pz = Zw @ np.linalg.pinv(Zw.T @ Zw) @ Zw.T
beta = np.linalg.solve(Xw.T @ Pz @ Xw, Xw.T @ Pz @ yw)
n = int(len(df))

fs = np.linalg.lstsq(Zw, Xw[:, 3], rcond=None)[0]

est = [
    ("iv_slope", float(beta[3])),
    ("exposure_area0_period0", float(X[(areas[0], periods[0])])),
    ("exposure_area0_period1", float(X[(areas[0], periods[1])])),
    ("instrument_area0_period0", float(Z[(areas[0], periods[0])])),
]
res = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [{"term": t, "estimate": v, "se": None, "n_obs": n} for t, v in est],
    "method_metadata": {"estimator": "weighted 2SLS", "weights": "base population",
                        "exogenous": ["intercept", "period", "control"], "instrument": "z"},
    "diagnostics": {"n_obs": n, "coefficients": [float(b) for b in beta],
                    "first_stage_z_coef": float(fs[3])},
}
with open("result.json", "w") as f:
    json.dump(res, f, indent=2)
