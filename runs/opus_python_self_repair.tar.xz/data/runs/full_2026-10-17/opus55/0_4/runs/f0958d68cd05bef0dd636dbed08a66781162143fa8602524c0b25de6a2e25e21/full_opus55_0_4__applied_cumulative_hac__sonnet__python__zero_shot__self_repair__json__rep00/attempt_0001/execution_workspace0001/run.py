import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df["date"] = pd.to_datetime(df["date"])
df = df.sort_values("date").reset_index(drop=True)

df["y"] = np.log(df["sales"])
df["dlv"] = np.log(df["vix"]).diff()
L = 15
names = []
for j in range(1, L + 1):
    c = f"lag_{j}"
    df[c] = df["dlv"].shift(j)
    names.append(c)

d = df.dropna(subset=["y"] + names).reset_index(drop=True)
y = d["y"].to_numpy(float)
X = np.column_stack([np.ones(len(d))] + [d[c].to_numpy(float) for c in names])
N, k = X.shape

XtX_inv = np.linalg.inv(X.T @ X)
beta = XtX_inv @ (X.T @ y)
u = y - X @ beta
S = X * u[:, None]
Omega = S.T @ S
for j in range(1, L + 1):
    w = 1.0 - j / (L + 1.0)
    G = S[j:].T @ S[:-j]
    Omega += w * (G + G.T)
V = XtX_inv @ Omega @ XtX_inv * (N / (N - (L + 1)))

r = np.zeros(k)
r[1:] = 1.0
cum = float(r @ beta)
cum_se = float(np.sqrt(r @ V @ r))

res = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {"term": "cumulative_response", "estimate": cum, "se": cum_se, "n_obs": int(N)},
        {"term": "lag_1", "estimate": float(beta[1]), "se": float(np.sqrt(V[1, 1])), "n_obs": int(N)},
        {"term": "lag_15", "estimate": float(beta[15]), "se": float(np.sqrt(V[15, 15])), "n_obs": int(N)},
    ],
    "method_metadata": {
        "estimator": "OLS of log(sales) on intercept and lags 1-15 of dlog(vix)",
        "vcov": "Newey-West HAC, maxlag 15, Bartlett weights 1-j/16, scaled by N/(N-16)",
    },
    "diagnostics": {},
}
with open("result.json", "w") as f:
    json.dump(res, f, indent=2)
