import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df["region_id"] = df["region_id"].astype(str)
df["industry_id"] = df["industry_id"].astype(str)

regions = df.drop_duplicates("region_id").set_index("region_id")[["region_weight", "x", "y"]]
region_ids = list(regions.index)
industries = sorted(df["industry_id"].unique())

shares = (df.pivot_table(index="region_id", columns="industry_id", values="share",
                         aggfunc="sum", fill_value=0.0)
          .reindex(index=region_ids, columns=industries, fill_value=0.0).to_numpy(float))
shock = df.groupby("industry_id")["shock"].first().reindex(industries).to_numpy(float)

e = regions["region_weight"].to_numpy(float)
e = e / e.sum()
x = regions["x"].to_numpy(float)
y = regions["y"].to_numpy(float)
z = shares @ shock

regional = np.column_stack([y, x, z])
centered = regional - e @ regional
mass = e @ shares
keep = mass > 0
agg = (shares.T @ (e[:, None] * centered))[keep] / mass[keep][:, None]
m = mass[keep]
g = shock[keep]
N = int(keep.sum())


def shock_iv(dep, endog):
    X = np.column_stack([np.ones(N), endog])
    Z = np.column_stack([np.ones(N), g])
    cross = Z.T @ (m[:, None] * X)
    beta = np.linalg.solve(cross, Z.T @ (m * dep))
    resid = dep - X @ beta
    scores = Z * (m * resid)[:, None]
    inv = np.linalg.inv(cross)
    cov = (N / (N - 2)) * inv @ (scores.T @ scores) @ inv.T
    return float(beta[1]), float(np.sqrt(cov[1, 1]))


effect, effect_se = shock_iv(agg[:, 0], agg[:, 1])
fs, fs_se = shock_iv(agg[:, 1], agg[:, 2])

reg_effect = np.sum(e * centered[:, 2] * centered[:, 0]) / np.sum(e * centered[:, 2] * centered[:, 1])
reg_fs = np.sum(e * centered[:, 2] * centered[:, 1]) / np.sum(e * centered[:, 2] ** 2)

eff_shocks = float(1.0 / np.sum(mass ** 2))

output = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": float(reg_effect), "se": effect_se, "n_obs": N},
        {"term": "first_stage", "estimate": float(reg_fs), "se": fs_se, "n_obs": N},
        {"term": "effective_shocks", "estimate": eff_shocks, "se": None, "n_obs": N},
    ],
    "method_metadata": {
        "estimator": "weighted shift-share 2SLS with BHJ shock-level equivalent IV",
        "vcov": "shock-level HC1 (N/(N-2)), structural IV residuals, analytic weights s_n",
    },
    "diagnostics": {
        "shock_level_effect": effect,
        "shock_level_first_stage": fs,
        "n_regions": len(region_ids),
    },
}
with open("result.json", "w") as f:
    json.dump(output, f, indent=2, allow_nan=False)
