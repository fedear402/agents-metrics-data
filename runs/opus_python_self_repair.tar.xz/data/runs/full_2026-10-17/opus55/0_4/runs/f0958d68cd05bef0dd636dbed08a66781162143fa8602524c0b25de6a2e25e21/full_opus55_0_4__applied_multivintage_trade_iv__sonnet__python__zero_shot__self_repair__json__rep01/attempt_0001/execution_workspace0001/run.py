import json
import numpy as np
import pandas as pd

cw = pd.read_csv("crosswalk.csv")
tr = pd.read_csv("trade.csv")
ar = pd.read_csv("areas.csv")
em = pd.read_csv("employment.csv")
out = pd.read_csv("outcomes.csv")

for d in (cw, tr):
    d["code"] = d["code"].astype(str).str.strip()
for d in (ar, em):
    d["vintage"] = d["vintage"].astype(str).str.strip().str.lower()
cw["industry"] = cw["industry"].astype(str).str.strip()
em["industry"] = em["industry"].astype(str).str.strip()

tr = tr.merge(cw, on="code", how="inner")
industries = sorted(cw["industry"].unique())
periods = sorted(ar["period"].unique())
areas = sorted(ar["area"].unique())


def exposure(vintage, change_col):
    a = ar[ar["vintage"] == vintage][["area", "period", "total_employment"]]
    e = em[em["vintage"] == vintage].groupby(["area", "period", "industry"], as_index=False)["employment"].sum()
    grid = pd.MultiIndex.from_product([areas, periods, industries], names=["area", "period", "industry"]).to_frame(index=False)
    g = grid.merge(e, on=["area", "period", "industry"], how="left")
    g["employment"] = g["employment"].fillna(0.0)
    nat = g.groupby(["period", "industry"], as_index=False)["employment"].sum().rename(columns={"employment": "nat"})
    g = g.merge(nat, on=["period", "industry"])
    t = tr.groupby(["period", "industry"], as_index=False).agg(
        chg=(change_col, "sum"), price_index=("price_index", "first"), years=("years", "first"))
    g = g.merge(t, on=["period", "industry"], how="left")
    g["chg"] = g["chg"].fillna(0.0)
    g = g.merge(a, on=["area", "period"])
    g["c"] = (g["employment"] / g["total_employment"]) * (g["chg"] / g["nat"]) \
        / (g["price_index"] / 100.0) / 1000.0 * (10.0 / g["years"])
    return g.groupby(["area", "period"], as_index=False)["c"].sum()

x = exposure("base", "us_change").rename(columns={"c": "x"})
z = exposure("early", "other_change").rename(columns={"c": "z"})
pop = ar[ar["vintage"] == "base"][["area", "period", "population"]]

df = out.merge(x, on=["area", "period"]).merge(z, on=["area", "period"]).merge(pop, on=["area", "period"])
df = df.sort_values(["area", "period"]).reset_index(drop=True)

n = len(df)
y = df["change_pp"].to_numpy(float)
X = np.column_stack([np.ones(n), df["period"].astype(float), df["control"].astype(float), df["x"]])
Z = np.column_stack([np.ones(n), df["period"].astype(float), df["control"].astype(float), df["z"]])
w = df["population"].to_numpy(float)
sw = np.sqrt(w)
Xw, Zw, yw = X * sw[:, None], Z * sw[:, None], y * sw
Pz_X = Zw @ np.linalg.lstsq(Zw, Xw, rcond=None)[0]
beta = np.linalg.solve(Pz_X.T @ Xw, Pz_X.T @ yw)

def get(col, a, p):
    r = df[(df["area"] == a) & (df["period"] == p)]
    return float(r[col].iloc[0])

a0 = areas[0]
p0, p1 = periods[0], periods[1]
est = {
    "iv_slope": float(beta[3]),
    "exposure_area0_period0": get("x", a0, p0),
    "exposure_area0_period1": get("x", a0, p1),
    "instrument_area0_period0": get("z", a0, p0),
}
result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [{"term": k, "estimate": v, "se": None, "n_obs": int(n)} for k, v in est.items()],
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "weights": "base-vintage population",
        "exogenous": ["intercept", "period", "control"],
        "endogenous": "x", "instrument": "z",
    },
    "diagnostics": {"n_obs": int(n), "n_industries": len(industries),
                    "coefficients": [float(b) for b in beta]},
}
with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
