import json
import numpy as np
import pandas as pd

hh = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

d = hh[hh["recipient"] == 0].copy()
d = d.dropna(subset=["eligible", "dose", "instrument", "baseline", "weight", "outcome"])
d["eligible"] = d["eligible"].astype(int)
e = d["eligible"].to_numpy(dtype=float)
ne = 1.0 - e
dose = d["dose"].to_numpy(dtype=float)
base = d["baseline"].to_numpy(dtype=float)
inst = d["instrument"].to_numpy(dtype=float)
w = d["weight"].to_numpy(dtype=float)
y = d["outcome"].to_numpy(dtype=float)

X_exog = np.column_stack([ne, e, base * ne, base * e])
X_endog = np.column_stack([dose * ne, dose * e])
X = np.column_stack([X_endog, X_exog])
Z = np.column_stack([X_exog, inst * ne, inst * e])

sw = np.sqrt(w)
Xw = X * sw[:, None]
Zw = Z * sw[:, None]
yw = y * sw
# 2SLS: first stage projection
coef_fs, *_ = np.linalg.lstsq(Zw, Xw, rcond=None)
Xhat = Zw @ coef_fs
beta = np.linalg.solve(Xhat.T @ Xw, Xhat.T @ yw)
slope_inel, slope_elig = float(beta[0]), float(beta[1])

mask0 = e == 0
mask1 = e == 1
mdose0 = float(np.average(dose[mask0], weights=w[mask0]))
mdose1 = float(np.average(dose[mask1], weights=w[mask1]))
eff0 = slope_inel * mdose0
eff1 = slope_elig * mdose1

census["eligible"] = census["eligible"].astype(int)
pop = census.groupby("eligible")["nonrecipient_population"].sum()
p0, p1 = float(pop.loc[0]), float(pop.loc[1])
pop_eff = (p0 * eff0 + p1 * eff1) / (p0 + p1)

n = int(len(d))
res = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {"term": "ineligible_effect", "estimate": float(eff0), "se": None, "n_obs": n},
        {"term": "eligible_nonrecipient_effect", "estimate": float(eff1), "se": None, "n_obs": n},
        {"term": "population_effect", "estimate": float(pop_eff), "se": None, "n_obs": n},
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS, group-interacted, no common intercept",
        "endogenous": ["dose*(1-eligible)", "dose*eligible"],
        "exogenous": ["1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"],
        "excluded_instruments": ["instrument*(1-eligible)", "instrument*eligible"],
        "weights": "weight",
        "sample": "recipient==0",
        "counterfactual": "dose=0 for all retained households (synthetic convention)",
        "aggregation": "census nonrecipient_population weights",
    },
    "diagnostics": {
        "slope_ineligible": slope_inel,
        "slope_eligible": slope_elig,
        "weighted_mean_dose_ineligible": mdose0,
        "weighted_mean_dose_eligible": mdose1,
        "n_ineligible": int(mask0.sum()),
        "n_eligible": int(mask1.sum()),
        "population_ineligible": p0,
        "population_eligible": p1,
        "coefficients": [float(b) for b in beta],
    },
}
with open("result.json", "w") as f:
    json.dump(res, f, indent=2)
