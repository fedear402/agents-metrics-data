import json
import numpy as np
import pandas as pd

h = pd.read_csv("households.csv")
c = pd.read_csv("census.csv")

d = h[h["recipient"] == 0].copy().reset_index(drop=True)
n = int(len(d))
e = d["eligible"].astype(float).values
ne = 1.0 - e
dose = d["dose"].astype(float).values
base = d["baseline"].astype(float).values
z = d["instrument"].astype(float).values
w = d["weight"].astype(float).values
y = d["outcome"].astype(float).values

exog = np.column_stack([ne, e, base * ne, base * e])
endog = np.column_stack([dose * ne, dose * e])
X = np.column_stack([endog, exog])
Z = np.column_stack([exog, z * ne, z * e])

sw = np.sqrt(w)
Xw = X * sw[:, None]
Zw = Z * sw[:, None]
yw = y * sw
# Weighted 2SLS: first stage projection then second stage
Pi, *_ = np.linalg.lstsq(Zw, Xw, rcond=None)
Xhat = Zw @ Pi
beta = np.linalg.solve(Xhat.T @ Xw, Xhat.T @ yw)
slope_inel, slope_elig = float(beta[0]), float(beta[1])

m0 = e == 0
m1 = e == 1
mean_dose0 = float(np.average(dose[m0], weights=w[m0]))
mean_dose1 = float(np.average(dose[m1], weights=w[m1]))
eff0 = slope_inel * mean_dose0
eff1 = slope_elig * mean_dose1

pop0 = float(c.loc[c["eligible"] == 0, "nonrecipient_population"].sum())
pop1 = float(c.loc[c["eligible"] == 1, "nonrecipient_population"].sum())
pop_eff = float((eff0 * pop0 + eff1 * pop1) / (pop0 + pop1))

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {"term": "ineligible_effect", "estimate": float(eff0), "se": None, "n_obs": n},
        {"term": "eligible_nonrecipient_effect", "estimate": float(eff1), "se": None, "n_obs": n},
        {"term": "population_effect", "estimate": pop_eff, "se": None, "n_obs": n},
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS (numpy), group-interacted, no common intercept",
        "sample": "recipient == 0",
        "endogenous": ["dose*(1-eligible)", "dose*eligible"],
        "exogenous": ["1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"],
        "excluded_instruments": ["instrument*(1-eligible)", "instrument*eligible"],
        "weights": "weight",
        "effect_definition": "dose slope times household-weighted mean dose within group; zero-dose counterfactual (synthetic convention)",
        "aggregation": "census nonrecipient_population weights",
    },
    "diagnostics": {
        "n_obs": n,
        "n_ineligible": int(m0.sum()),
        "n_eligible_nonrecipient": int(m1.sum()),
        "slope_ineligible": slope_inel,
        "slope_eligible_nonrecipient": slope_elig,
        "weighted_mean_dose_ineligible": mean_dose0,
        "weighted_mean_dose_eligible_nonrecipient": mean_dose1,
        "census_pop_ineligible": pop0,
        "census_pop_eligible_nonrecipient": pop1,
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
