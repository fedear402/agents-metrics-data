import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("input.csv")
n_full = int(len(df))
d = df[["y", "x", "z"]].dropna().copy()
d["y"] = d["y"].astype(int)

X = sm.add_constant(d[["x", "z"]], has_constant="add")
model = sm.MNLogit(d["y"], X)
res = model.fit(method="newton", maxiter=200, disp=False)
try:
    res2 = model.fit(start_params=res.params.values, method="bfgs", maxiter=2000, disp=False)
    if res2.llf > res.llf + 1e-10:
        res = res2
except Exception:
    pass

params = np.asarray(res.params)  # shape (k, J-1), columns for outcomes 1, 2
bse = np.asarray(res.bse)
cols = list(X.columns)
ix, iz, ic = cols.index("x"), cols.index("z"), cols.index("const")

# map columns to outcome labels (base 0 is first sorted category)
cats = sorted(d["y"].unique())
others = [c for c in cats if c != cats[0]]
j1 = others.index(1)
j2 = others.index(2)

eta = np.array([0.0] + [params[ic, j] for j in range(params.shape[1])])
p = np.exp(eta - eta.max())
p = p / p.sum()
prob2 = float(p[1 + j2])

def ent(term, est, se):
    return {"term": term, "estimate": float(est),
            "se": None if se is None else float(se), "n_obs": n_full}

result = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": [
        ent("x_cat1", params[ix, j1], bse[ix, j1]),
        ent("z_cat1", params[iz, j1], bse[iz, j1]),
        ent("x_cat2", params[ix, j2], bse[ix, j2]),
        ent("z_cat2", params[iz, j2], bse[iz, j2]),
        ent("prob_cat2_zero", prob2, None),
    ],
    "method_metadata": {"estimator": "multinomial logit MLE (statsmodels MNLogit), base outcome 0",
                        "vcov": "observed information (inverse Hessian)"},
    "diagnostics": {"converged": bool(res.mle_retvals.get("converged", True)),
                    "llf": float(res.llf), "n_used": int(len(d))},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
