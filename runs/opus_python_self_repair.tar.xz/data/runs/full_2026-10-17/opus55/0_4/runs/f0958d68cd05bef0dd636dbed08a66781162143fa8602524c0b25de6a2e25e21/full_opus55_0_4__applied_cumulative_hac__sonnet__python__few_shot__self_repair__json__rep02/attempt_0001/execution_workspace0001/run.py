import json
import numpy as np
import pandas as pd

data = pd.read_csv("input.csv")
data["date"] = pd.to_datetime(data["date"])
data = data.sort_values("date").reset_index(drop=True)
data["vix_change"] = np.log(data["vix"]).diff()
data["log_sales"] = np.log(data["sales"])

n_lags = 15
lag_cols = []
for k in range(1, n_lags + 1):
    col = f"change_lag{k}"
    data[col] = data["vix_change"].shift(k)
    lag_cols.append(col)

sample = data.dropna(subset=["log_sales"] + lag_cols)
N = len(sample)
X = np.column_stack([np.ones(N)] + [sample[c].to_numpy() for c in lag_cols])
y = sample["log_sales"].to_numpy()
coefficients = np.linalg.lstsq(X, y, rcond=None)[0]
residuals = y - X @ coefficients

scores = X * residuals[:, None]
hac_lags = 15
meat = scores.T @ scores
for j in range(1, hac_lags + 1):
    weight = 1 - j / (hac_lags + 1)
    lag_product = scores[j:].T @ scores[:-j]
    meat += weight * (lag_product + lag_product.T)
bread = np.linalg.inv(X.T @ X)
p = X.shape[1]
covariance = (N / (N - p)) * bread @ meat @ bread

contrast = np.zeros(p)
contrast[1:] = 1.0
cumulative = float(contrast @ coefficients)
cumulative_se = float(np.sqrt(contrast @ covariance @ contrast))

rows = [
    {"term": "cumulative_response", "estimate": cumulative, "se": cumulative_se, "n_obs": int(N)},
    {"term": "lag_1", "estimate": float(coefficients[1]), "se": float(np.sqrt(covariance[1, 1])), "n_obs": int(N)},
    {"term": "lag_15", "estimate": float(coefficients[15]), "se": float(np.sqrt(covariance[15, 15])), "n_obs": int(N)},
]
output = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": rows,
    "method_metadata": {
        "estimator": "OLS of log(sales) on intercept and lags 1-15 of dlog(vix)",
        "vcov": "Newey-West Bartlett, maxlag 15, scaled by N/(N-16)",
    },
    "diagnostics": {},
}
with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
