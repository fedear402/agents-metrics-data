import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy.special import softmax

df = pd.read_csv("input.csv")
n_full = int(len(df))
d = df[["y", "x", "z"]].dropna()
y = d["y"].astype(int).to_numpy()
outcomes = sorted(np.unique(y).tolist())
assert outcomes == [0, 1, 2]
X = pd.DataFrame({"const": np.ones(len(d)), "x": d["x"].to_numpy(dtype=float),
                  "z": d["z"].to_numpy(dtype=float)})
fit = sm.MNLogit(y, X).fit(disp=False, method="newton", maxiter=200, tol=1e-10)
coef = fit.params.copy()
se = fit.bse.copy()
assert coef.shape[1] == 2
coef.columns = [1, 2]
se.columns = [1, 2]

eta = np.r_[0.0, coef.loc["const", 1], coef.loc["const", 2]]
p = softmax(eta)
pred = np.asarray(fit.predict(pd.DataFrame({"const": [1.0], "x": [0.0], "z": [0.0]})))[0]
assert np.allclose(p, pred)

def row(term, est, s):
    return {"term": term, "estimate": float(est),
            "se": None if s is None else float(s), "n_obs": n_full}

out = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": [
        row("x_cat1", coef.loc["x", 1], se.loc["x", 1]),
        row("z_cat1", coef.loc["z", 1], se.loc["z", 1]),
        row("x_cat2", coef.loc["x", 2], se.loc["x", 2]),
        row("z_cat2", coef.loc["z", 2], se.loc["z", 2]),
        row("prob_cat2_zero", p[2], None),
    ],
    "method_metadata": {"estimator": "multinomial logit MLE (statsmodels MNLogit), base outcome 0",
                        "vcov": "observed information (inverse Hessian)"},
    "diagnostics": {"converged": bool(fit.mle_retvals.get("converged", True)),
                    "llf": float(fit.llf), "n_used": int(len(d))},
}
with open("result.json", "w") as f:
    json.dump(out, f, indent=2, allow_nan=False)
