import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df = df.drop_duplicates(subset=["id", "time"])

results = []
atts = []
weights = []
total_n = 0

for c in (3, 5, 7):
    times = list(range(c - 2, c + 3))
    sub = df[df["time"].isin(times)]
    sub = sub[(sub["g"] == c) | (sub["g"] == 0) | (sub["g"] > c + 2)]
    sub = sub.dropna(subset=["y"])
    counts = sub.groupby("id")["time"].nunique()
    keep = counts[counts == len(times)].index
    sub = sub[sub["id"].isin(keep)].copy()
    sub["did"] = ((sub["g"] == c) & (sub["time"] >= c)).astype(float)

    # Two-way within transformation (balanced panel -> exact)
    y = sub["y"].astype(float)
    d = sub["did"]
    def demean(v):
        um = v.groupby(sub["id"]).transform("mean")
        tm = v.groupby(sub["time"]).transform("mean")
        return v - um - tm + v.mean()
    yt = demean(y).values
    dt = demean(d).values
    att = float(np.dot(dt, yt) / np.dot(dt, dt))

    n_obs = int(len(sub))
    n_treated = int(sub.loc[sub["g"] == c, "id"].nunique())
    atts.append(att)
    weights.append(n_treated)
    total_n += n_obs
    results.append({"term": f"att_g{c}", "estimate": att, "se": None, "n_obs": n_obs})

w = np.array(weights, dtype=float)
att_w = float(np.dot(w, np.array(atts)) / w.sum())
results.append({"term": "att_weighted", "estimate": att_w, "se": None, "n_obs": int(total_n)})

out = {
    "task_id": "broad_cohort_stack",
    "platform": "python",
    "estimates": results,
    "method_metadata": {
        "estimator": "cohort-specific TWFE DiD with unit and time FE",
        "window": "c-2..c+2",
        "weights": "retained treated units per cohort",
    },
    "diagnostics": {"treated_units": {f"g{c}": n for c, n in zip((3, 5, 7), weights)}},
}

with open("result.json", "w") as f:
    json.dump(out, f, indent=2)
