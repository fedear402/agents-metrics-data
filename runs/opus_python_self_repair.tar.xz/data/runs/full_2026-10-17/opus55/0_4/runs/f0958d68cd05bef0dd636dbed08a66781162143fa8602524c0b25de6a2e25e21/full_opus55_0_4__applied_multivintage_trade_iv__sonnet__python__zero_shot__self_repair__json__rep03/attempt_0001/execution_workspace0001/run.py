import json
import numpy as np
import pandas as pd

cw = pd.read_csv("crosswalk.csv")
tr = pd.read_csv("trade.csv")
ar = pd.read_csv("areas.csv")
em = pd.read_csv("employment.csv")
oc = pd.read_csv("outcomes.csv")

for d in (cw, tr):
    d["code"] = d["code"].astype(str).str.strip()
for d in (ar, em):
    d["vintage"] = d["vintage"].astype(str).str.strip().str.lower()

tr = tr.merge(cw, on="code", how="left")
areas = sorted(ar["area"].unique())
periods = sorted(tr["period"].unique())
inds = sorted(cw["industry"].unique())

def exposure(vintage, change_col):
    rows = []
    e = em[em["vintage"] == vintage]
    a = ar[ar["vintage"] == vintage]
    for p in periods:
        idx = pd.MultiIndex.from_product([areas, inds], names=["area", "industry"])
        ep = (e[e["period"] == p].groupby(["area", "industry"])["employment"].sum()
              .reindex(idx, fill_value=0.0).unstack("industry"))
        nat = ep.sum(axis=0)
        tp = tr[tr["period"] == p].set_index("industry")
        price = tp["price_index"].iloc[0]
        yrs = tp["years"].iloc[0]
        chg = tp[change_col].reindex(inds).fillna(0.0)
        tot = a[a["period"] == p].set_index("area")["total_employment"].reindex(areas)
        share = ep.div(tot, axis=0)
        val = (share * (chg / nat)).sum(axis=1) / (price / 100.0) / 1000.0 * (10.0 / yrs)
        for ai in areas:
            rows.append((ai, p, float(val.loc[ai])))
    return pd.DataFrame(rows, columns=["area", "period", vintage])

X = exposure("base", "us_change").rename(columns={"base": "x"})
Z = exposure("early", "other_change").rename(columns={"early": "z"})
pop = ar[ar["vintage"] == "base"][["area", "period", "population"]]

df = oc.merge(X, on=["area", "period"]).merge(Z, on=["area", "period"]).merge(pop, on=["area", "period"])
df = df.dropna(subset=["change_pp", "control", "x", "z", "population"])

n = len(df)
y = df["change_pp"].values.astype(float)
one = np.ones(n)
Xm = np.column_stack([one, df["period"].values.astype(float), df["control"].values.astype(float), df["x"].values])
Zm = np.column_stack([one, df["period"].values.astype(float), df["control"].values.astype(float), df["z"].values])
w = df["population"].values.astype(float)
sw = np.sqrt(w)
Xw, Zw, yw = Xm * sw[:, None], Zm * sw[:, None], y * sw
Pz = Zw @ np.linalg.pinv(Zw.T @ Zw) @ Zw.T
beta = np.linalg.solve(Xw.T @ Pz @ Xw, Xw.T @ Pz @ yw)

def get(d, col, a, p):
    return float(d[(d["area"] == a) & (d["period"] == p)][col].iloc[0])

a0 = areas[0] if 0 not in areas else 0
p0, p1 = periods[0], periods[1]
est = {
    "iv_slope": float(beta[3]),
    "exposure_area0_period0": get(X, "x", a0, p0),
    "exposure_area0_period1": get(X, "x", a0, p1),
    "instrument_area0_period0": get(Z, "z", a0, p0),
}
res = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [{"term": k, "estimate": float(f"{v:.15g}"), "se": None, "n_obs": int(n)} for k, v in est.items()],
    "method_metadata": {"estimator": "weighted 2SLS", "weights": "base-vintage population",
                        "instruments": ["intercept", "period", "control", "z"]},
    "diagnostics": {"n_obs": int(n), "coefficients": [float(b) for b in beta],
                    "n_areas": len(areas), "periods": [str(p) for p in periods]},
}
with open("result.json", "w") as f:
    json.dump(res, f, indent=2)
