import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("input.csv")
n_full = int(len(df))
d = df[["y", "x", "z"]].dropna().copy()
d["y"] = d["y"].astype(int)

X = sm.add_constant(d[["x", "z"]], has_constant="add")
model = sm.MNLogit(d["y"], X)
res = model.fit(method="newton", maxiter=200, disp=False)
try:
    res2 = model.fit(start_params=res.params.values.ravel(order="F"), method="bfgs", maxiter=0, disp=False)
except Exception:
    pass

params = res.params  # columns correspond to non-base outcomes in sorted order
bse = res.bse
cats = sorted(d["y"].unique())
# columns index 0 -> cats[1], 1 -> cats[2]
col1 = cats.index(1) - 1
col2 = cats.index(2) - 1

def get(df_, row, col):
    return float(df_.iloc[:, col].loc[row])

b = params.values
eta1 = b[0, col1]
eta2 = b[0, col2]
denom = 1.0 + np.exp(eta1) + np.exp(eta2)
p2 = float(np.exp(eta2) / denom)

estimates = [
    {"term": "x_cat1", "estimate": get(params, "x", col1), "se": get(bse, "x", col1), "n_obs": n_full},
    {"term": "z_cat1", "estimate": get(params, "z", col1), "se": get(bse, "z", col1), "n_obs": n_full},
    {"term": "x_cat2", "estimate": get(params, "x", col2), "se": get(bse, "x", col2), "n_obs": n_full},
    {"term": "z_cat2", "estimate": get(params, "z", col2), "se": get(bse, "z", col2), "n_obs": n_full},
    {"term": "prob_cat2_zero", "estimate": p2, "se": None, "n_obs": n_full},
]

out = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "statsmodels MNLogit maximum likelihood, base outcome 0",
        "vcov": "inverse observed information (Hessian)",
    },
    "diagnostics": {
        "converged": bool(res.mle_retvals.get("converged", True)),
        "loglik": float(res.llf),
        "n_used": int(res.nobs),
    },
}

with open("result.json", "w") as f:
    json.dump(out, f, indent=2)
