import json
import numpy as np
import pandas as pd

cw = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv")
areas = pd.read_csv("areas.csv")
emp = pd.read_csv("employment.csv")
out = pd.read_csv("outcomes.csv")

for d in (cw, trade, areas, emp, out):
    for c in ("vintage", "code", "industry"):
        if c in d.columns:
            d[c] = d[c].astype(str).str.strip()
    if "vintage" in d.columns:
        d["vintage"] = d["vintage"].str.lower()

tr = trade.merge(cw, on="code", how="inner")
industries = sorted(cw["industry"].unique())

# full grid of area-period-vintage-industry, missing = 0
ap = areas[["area", "period", "vintage"]].drop_duplicates()
grid = ap.assign(_k=1).merge(pd.DataFrame({"industry": industries, "_k": 1}), on="_k").drop(columns="_k")
e = emp.groupby(["area", "period", "vintage", "industry"], as_index=False)["employment"].sum()
grid = grid.merge(e, on=["area", "period", "vintage", "industry"], how="left")
grid["employment"] = grid["employment"].fillna(0.0)

nat = grid.groupby(["period", "vintage", "industry"], as_index=False)["employment"].sum().rename(columns={"employment": "national"})
grid = grid.merge(nat, on=["period", "vintage", "industry"])
grid = grid.merge(areas[["area", "period", "vintage", "total_employment"]], on=["area", "period", "vintage"])
grid = grid.merge(tr[["period", "industry", "us_change", "other_change", "price_index", "years"]],
                  on=["period", "industry"], how="left")

def build(vint, chg, name):
    g = grid[grid["vintage"] == vint].copy()
    g[name] = (g["employment"] / g["total_employment"]) * (g[chg] / g["national"]) \
        / (g["price_index"] / 100.0) / 1000.0 * (10.0 / g["years"])
    return g.groupby(["area", "period"], as_index=False)[name].sum()

x = build("base", "us_change", "x")
z = build("early", "other_change", "z")
pop = areas[areas["vintage"] == "base"][["area", "period", "population"]]

df = out.merge(x, on=["area", "period"]).merge(z, on=["area", "period"]).merge(pop, on=["area", "period"])
df = df.sort_values(["period", "area"]).reset_index(drop=True)

per = pd.to_numeric(df["period"], errors="coerce")
if per.isna().any():
    per = pd.Series(pd.factorize(df["period"], sort=True)[0], index=df.index)
y = df["change_pp"].to_numpy(float)
W = np.column_stack([np.ones(len(df)), per.to_numpy(float), df["control"].to_numpy(float)])
X = np.column_stack([W, df["x"].to_numpy(float)])
Z = np.column_stack([W, df["z"].to_numpy(float)])
w = df["population"].to_numpy(float)
sw = np.sqrt(w)
Xw, Zw, yw = X * sw[:, None], Z * sw[:, None], y * sw
Pz = Zw @ np.linalg.solve(Zw.T @ Zw, Zw.T @ Xw)
beta = np.linalg.solve(Pz.T @ Xw, Pz.T @ yw)

def get(df_, col, a, p):
    r = df_[(df_["area"].astype(str) == str(a)) & (df_["period"].astype(str) == str(p))]
    return float(r[col].iloc[0])

n = int(len(df))
est = {
    "iv_slope": float(beta[-1]),
    "exposure_area0_period0": get(x, "x", 0, 0),
    "exposure_area0_period1": get(x, "x", 0, 1),
    "instrument_area0_period0": get(z, "z", 0, 0),
}
res = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [{"term": k, "estimate": float(f"{v:.15g}"), "se": None, "n_obs": n} for k, v in est.items()],
    "method_metadata": {
        "estimator": "weighted 2SLS (numpy)",
        "weights": "base-vintage population",
        "exogenous": ["intercept", "period", "control"],
        "endogenous": "x", "instrument": "z",
        "national_denominator": "sum across supplied areas within period and vintage",
    },
    "diagnostics": {
        "n_obs": n,
        "n_industries": len(industries),
        "coefficients": [float(b) for b in beta],
    },
}
with open("result.json", "w") as f:
    json.dump(res, f, indent=2)
