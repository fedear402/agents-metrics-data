import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df = df[["score", "participated", "earnings"]].apply(pd.to_numeric, errors="coerce").dropna()
d = df[np.abs(df["score"]) < 1].copy()
x = d["score"].to_numpy(float)
w = 1 - np.abs(x)
right = (x >= 0).astype(float)
n = len(d)

X = np.column_stack([np.ones(n), right, x, right * x])
Y = np.column_stack([d["earnings"].to_numpy(float), d["participated"].to_numpy(float)])
bread = np.linalg.inv(X.T @ (w[:, None] * X))
coef = bread @ X.T @ (w[:, None] * Y)
resid = Y - X @ coef
# Coefficient on the right-side indicator is right limit minus left limit at zero.
contrast = np.array([0., 1., 0., 0.])
jumps = contrast @ coef
loading = w * (X @ bread @ contrast)
infl = loading[:, None] * resid
joint = infl.T @ infl
rf, fs = jumps
te = rf / fs
grad = np.array([1 / fs, -rf / fs**2])
te_se = float(np.sqrt(grad @ joint @ grad))

out = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": float(te), "se": te_se, "n_obs": int(n)},
        {"term": "reduced_form", "estimate": float(rf), "se": float(np.sqrt(joint[0, 0])), "n_obs": int(n)},
        {"term": "first_stage", "estimate": float(fs), "se": float(np.sqrt(joint[1, 1])), "n_obs": int(n)},
    ],
    "method_metadata": {
        "estimator": "fuzzy RD, local linear, triangular kernel, h=1, separate slopes, ratio of jumps",
        "vcov": "HC0 joint sandwich, delta method with covariance, no bias correction",
    },
    "diagnostics": {"rf_fs_covariance": float(joint[0, 1])},
}
with open("result.json", "w") as f:
    json.dump(out, f, indent=2, allow_nan=False)
