import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
regions = np.sort(df["region_id"].unique())
industries = np.sort(df["industry_id"].unique())

reg = df.groupby("region_id")[["region_weight", "x", "y"]].first().reindex(regions)
S = (df.pivot_table(index="region_id", columns="industry_id", values="share",
                    aggfunc="sum", fill_value=0.0)
       .reindex(index=regions, columns=industries, fill_value=0.0).to_numpy(float))
shock = df.groupby("industry_id")["shock"].first().reindex(industries).to_numpy(float)

e = reg["region_weight"].to_numpy(float)
e = e / e.sum()
x = reg["x"].to_numpy(float)
y = reg["y"].to_numpy(float)
z = S @ shock

R = np.column_stack([y, x, z])
C = R - e @ R
s = e @ S
N = len(industries)
keep = s > 0
agg = np.zeros((N, 3))
agg[keep] = (S[:, keep].T @ (e[:, None] * C)) / s[keep][:, None]


def shock_iv(dep, endog):
    X = np.column_stack([np.ones(N), endog])
    Z = np.column_stack([np.ones(N), shock])
    cross = Z.T @ (s[:, None] * X)
    beta = np.linalg.solve(cross, Z.T @ (s * dep))
    resid = dep - X @ beta
    sc = Z * (s * resid)[:, None]
    inv = np.linalg.inv(cross)
    V = (N / (N - 2)) * inv @ (sc.T @ sc) @ inv.T
    return float(beta[1]), float(np.sqrt(V[1, 1]))


effect, effect_se = shock_iv(agg[:, 0], agg[:, 1])
fs, fs_se = shock_iv(agg[:, 1], agg[:, 2])

reg_effect = np.sum(e * C[:, 2] * C[:, 0]) / np.sum(e * C[:, 2] * C[:, 1])
reg_fs = np.sum(e * C[:, 2] * C[:, 1]) / np.sum(e * C[:, 2] ** 2)
eff_shocks = float(1.0 / np.sum(s ** 2))

out = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": float(reg_effect), "se": effect_se, "n_obs": int(N)},
        {"term": "first_stage", "estimate": float(reg_fs), "se": fs_se, "n_obs": int(N)},
        {"term": "effective_shocks", "estimate": eff_shocks, "se": None, "n_obs": int(N)},
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS with shift-share instrument; BHJ shock-level equivalent IV",
        "vcov": "shock-level HC1 (N/(N-2)), structural IV residuals, s_n analytic weights",
    },
    "diagnostics": {
        "shock_level_effect": effect,
        "shock_level_first_stage": fs,
        "n_regions": int(len(regions)),
    },
}
with open("result.json", "w") as f:
    json.dump(out, f, indent=2, allow_nan=False)
