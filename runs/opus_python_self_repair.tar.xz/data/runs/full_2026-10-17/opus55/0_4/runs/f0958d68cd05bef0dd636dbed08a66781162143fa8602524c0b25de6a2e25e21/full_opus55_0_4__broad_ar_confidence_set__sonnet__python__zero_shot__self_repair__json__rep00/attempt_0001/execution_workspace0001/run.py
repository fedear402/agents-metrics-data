import json
import numpy as np
import pandas as pd
from scipy import stats

df = pd.read_csv("input.csv")
df = df[["y", "endog", "x", "z1", "z2"]].dropna()
n = len(df)
y = df["y"].to_numpy(float)
e = df["endog"].to_numpy(float)
W = np.column_stack([np.ones(n), df["x"].to_numpy(float)])
Z = df[["z1", "z2"]].to_numpy(float)
X = np.column_stack([W, Z])

def resid_maker(M):
    pinv = np.linalg.pinv(M)
    return lambda v: v - M @ (pinv @ v)

rW = resid_maker(W)
rX = resid_maker(X)
k = 2
dfd = n - 4
crit = stats.f.ppf(0.95, k, dfd)
c = k * crit / dfd

# Quadratic form Q(u) = u'(M_W - M_X)u - c * u'M_X u
def bil(a, b):
    ra_w, rb_w = rW(a), rW(b)
    ra_x, rb_x = rX(a), rX(b)
    return (ra_w @ rb_w - ra_x @ rb_x) - c * (ra_x @ rb_x)

a2 = bil(e, e)
a1 = -2.0 * bil(y, e)
a0 = bil(y, y)

def ar_f(b):
    u = y - b * e
    ru_w, ru_x = rW(u), rX(u)
    rss_r, rss_u = ru_w @ ru_w, ru_x @ ru_x
    return ((rss_r - rss_u) / k) / (rss_u / dfd)

disc = a1 ** 2 - 4 * a2 * a0
roots = []
if disc >= 0 and abs(a2) > 0:
    s = np.sqrt(disc)
    roots = sorted([(-a1 - s) / (2 * a2), (-a1 + s) / (2 * a2)])
low = float(roots[0]) if roots else None
high = float(roots[1]) if roots else None

accepts_zero = 1 if ar_f(0.0) <= crit else 0
unbounded = 1 if a2 < 0 or (a2 == 0) else 0

res = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": [
        {"term": "boundary_low", "estimate": low, "se": None, "n_obs": int(n)},
        {"term": "boundary_high", "estimate": high, "se": None, "n_obs": int(n)},
        {"term": "accepts_zero", "estimate": float(accepts_zero), "se": None, "n_obs": int(n)},
        {"term": "unbounded", "estimate": float(unbounded), "se": None, "n_obs": int(n)},
        {"term": "ar_f_at_one", "estimate": float(ar_f(1.0)), "se": None, "n_obs": int(n)},
    ],
    "method_metadata": {"estimator": "Anderson-Rubin test inversion (analytic quadratic)",
                        "vcov": "homoskedastic F(2, n-4)"},
    "diagnostics": {"f_crit": float(crit), "quad_a2": float(a2), "quad_a1": float(a1),
                    "quad_a0": float(a0), "discriminant": float(disc)},
}
with open("result.json", "w") as f:
    json.dump(res, f, indent=2)
