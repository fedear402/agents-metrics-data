import json
import numpy as np
import pandas as pd

hh = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

df = hh[hh["recipient"] == 0].copy()
df = df.dropna(subset=["eligible", "instrument", "dose", "baseline", "weight", "outcome"])
df["eligible"] = df["eligible"].astype(int)
n = int(len(df))

e = df["eligible"].to_numpy(float)
ne = 1.0 - e
d = df["dose"].to_numpy(float)
b = df["baseline"].to_numpy(float)
z = df["instrument"].to_numpy(float)
w = df["weight"].to_numpy(float)
y = df["outcome"].to_numpy(float)

X = np.column_stack([d * ne, d * e, ne, e, b * ne, b * e])
Z = np.column_stack([ne, e, b * ne, b * e, z * ne, z * e])

sw = np.sqrt(w)
Xw = X * sw[:, None]
Zw = Z * sw[:, None]
yw = y * sw

# First stage projection, then second stage
coef_fs, *_ = np.linalg.lstsq(Zw, Xw, rcond=None)
Xhat = Zw @ coef_fs
beta = np.linalg.solve(Xhat.T @ Xw, Xhat.T @ yw)

slope_inel, slope_el = float(beta[0]), float(beta[1])

m0 = e == 0
m1 = e == 1
mean_d0 = float(np.sum(w[m0] * d[m0]) / np.sum(w[m0]))
mean_d1 = float(np.sum(w[m1] * d[m1]) / np.sum(w[m1]))

eff0 = slope_inel * mean_d0
eff1 = slope_el * mean_d1

census = census.copy()
census["eligible"] = census["eligible"].astype(int)
pop = census.groupby("eligible")["nonrecipient_population"].sum()
p0 = float(pop.get(0, 0.0))
p1 = float(pop.get(1, 0.0))
pop_eff = (p0 * eff0 + p1 * eff1) / (p0 + p1)

def est(term, val):
    return {"term": term, "estimate": float(f"{val:.15g}"), "se": None, "n_obs": n}

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        est("ineligible_effect", eff0),
        est("eligible_nonrecipient_effect", eff1),
        est("population_effect", pop_eff),
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "sample": "recipient == 0 (all nonrecipients, both village treatment statuses)",
        "endogenous": ["dose*(1-eligible)", "dose*eligible"],
        "exogenous": ["1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"],
        "excluded_instruments": ["instrument*(1-eligible)", "instrument*eligible"],
        "intercept": "none beyond group indicators",
        "weights": "weight",
        "group_effect": "dose slope times weighted mean dose within group (zero-dose counterfactual, synthetic convention)",
        "aggregation": "census nonrecipient_population weights",
    },
    "diagnostics": {
        "n_obs": n,
        "n_ineligible": int(m0.sum()),
        "n_eligible": int(m1.sum()),
        "slope_ineligible": slope_inel,
        "slope_eligible": slope_el,
        "weighted_mean_dose_ineligible": mean_d0,
        "weighted_mean_dose_eligible": mean_d1,
        "census_pop_ineligible": p0,
        "census_pop_eligible": p1,
        "coefficients": [float(v) for v in beta],
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
