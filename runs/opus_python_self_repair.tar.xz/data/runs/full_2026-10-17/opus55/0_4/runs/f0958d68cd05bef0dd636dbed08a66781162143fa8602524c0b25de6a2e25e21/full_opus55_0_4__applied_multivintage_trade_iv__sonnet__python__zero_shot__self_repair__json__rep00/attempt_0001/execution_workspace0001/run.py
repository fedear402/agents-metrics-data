import json
import numpy as np
import pandas as pd

cw = pd.read_csv("crosswalk.csv")
tr = pd.read_csv("trade.csv")
ar = pd.read_csv("areas.csv")
em = pd.read_csv("employment.csv")
oc = pd.read_csv("outcomes.csv")

for d in (cw, tr):
    d["code"] = d["code"].astype(str).str.strip()
for d in (ar, em, oc):
    d["vintage"] = d["vintage"].astype(str).str.strip().str.lower() if "vintage" in d else None
cw["industry"] = cw["industry"].astype(str).str.strip()
em["industry"] = em["industry"].astype(str).str.strip()

tr = tr.merge(cw[["code", "industry"]], on="code", how="inner")
industries = sorted(cw["industry"].unique())

areas_list = sorted(ar["area"].unique())
periods = sorted(tr["period"].unique())

# full grid of area-period-vintage-industry, missing = 0
grid = pd.MultiIndex.from_product(
    [areas_list, periods, ["base", "early"], industries],
    names=["area", "period", "vintage", "industry"]).to_frame(index=False)
emg = em.groupby(["area", "period", "vintage", "industry"], as_index=False)["employment"].sum()
grid = grid.merge(emg, on=["area", "period", "vintage", "industry"], how="left")
grid["employment"] = grid["employment"].fillna(0.0)

nat = grid.groupby(["period", "vintage", "industry"], as_index=False)["employment"].sum() \
    .rename(columns={"employment": "nat_emp"})
grid = grid.merge(nat, on=["period", "vintage", "industry"])
tot = ar[["area", "period", "vintage", "total_employment"]]
grid = grid.merge(tot, on=["area", "period", "vintage"], how="left")
grid = grid.merge(tr[["period", "industry", "us_change", "other_change", "price_index", "years"]],
                  on=["period", "industry"], how="left")

def comp(vint, chg):
    g = grid[grid["vintage"] == vint].copy()
    g["c"] = (g["employment"] / g["total_employment"]) * (g[chg] / g["nat_emp"]) \
        / (g["price_index"] / 100.0) / 1000.0 * (10.0 / g["years"])
    return g.groupby(["area", "period"], as_index=False)["c"].sum()

x = comp("base", "us_change").rename(columns={"c": "x"})
z = comp("early", "other_change").rename(columns={"c": "z"})
pop = ar[ar["vintage"] == "base"][["area", "period", "population"]]

df = oc.drop(columns=[c for c in ["vintage"] if c in oc]).merge(x, on=["area", "period"]) \
    .merge(z, on=["area", "period"]).merge(pop, on=["area", "period"])
df = df.sort_values(["area", "period"]).reset_index(drop=True)

y = df["change_pp"].to_numpy(float)
w = df["population"].to_numpy(float)
n = len(df)
one = np.ones(n)
X = np.column_stack([one, df["period"].astype(float), df["control"].astype(float), df["x"]])
Z = np.column_stack([one, df["period"].astype(float), df["control"].astype(float), df["z"]])
sw = np.sqrt(w)
Xw, Zw, yw = X * sw[:, None], Z * sw[:, None], y * sw
Pz = Zw @ np.linalg.pinv(Zw.T @ Zw) @ Zw.T
beta = np.linalg.solve(Xw.T @ Pz @ Xw, Xw.T @ Pz @ yw)

def get(a, p, col):
    return float(df.loc[(df["area"] == a) & (df["period"] == p), col].iloc[0])

a0 = areas_list[0] if 0 not in areas_list else 0
p0, p1 = periods[0], periods[1]
est = {
    "iv_slope": float(beta[3]),
    "exposure_area0_period0": get(a0, p0, "x"),
    "exposure_area0_period1": get(a0, p1, "x"),
    "instrument_area0_period0": get(a0, p0, "z"),
}
fs = np.linalg.lstsq(Zw, Xw[:, 3], rcond=None)[0]
out = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [{"term": k, "estimate": float(f"{v:.15g}"), "se": None, "n_obs": int(n)}
                  for k, v in est.items()],
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "weights": "base-vintage population",
        "exogenous": ["intercept", "period", "control"],
        "endogenous": "x", "instrument": "z",
        "missing_cells": "zero",
        "national_denominator": "sum across supplied areas within period and vintage",
    },
    "diagnostics": {
        "n_obs": int(n),
        "n_industries": len(industries),
        "coefficients": [float(b) for b in beta],
        "first_stage_z_coef": float(fs[3]),
    },
}
with open("result.json", "w") as f:
    json.dump(out, f, indent=2)
