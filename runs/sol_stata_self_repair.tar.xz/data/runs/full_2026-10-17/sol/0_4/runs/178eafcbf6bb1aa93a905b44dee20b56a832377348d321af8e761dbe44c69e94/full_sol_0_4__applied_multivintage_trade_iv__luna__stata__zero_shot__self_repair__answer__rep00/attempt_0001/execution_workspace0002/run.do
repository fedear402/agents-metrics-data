clear all
set more off

tempfile crosswalk industries trade employment outcomes

import delimited "crosswalk.csv", clear
isid code
save `crosswalk'

keep industry
duplicates drop
assert _N == 4
save `industries'

import delimited "trade.csv", clear
merge m:1 code using `crosswalk', assert(match) nogen
isid period industry
keep period industry us_change other_change price_index years
save `trade'

import delimited "employment.csv", clear
isid area period vintage industry
save `employment'

import delimited "outcomes.csv", clear
isid area period
save `outcomes'

import delimited "areas.csv", clear
isid area period vintage
cross using `industries'

merge 1:1 area period vintage industry using `employment', assert(master match) nogen
replace employment = 0 if missing(employment)

bysort period vintage industry: egen double national_employment = total(employment)
assert national_employment > 0

merge m:1 period industry using `trade', assert(match) nogen

gen double x_part = 0
replace x_part = (employment / total_employment) * ///
    (us_change / national_employment) / (price_index / 100) / 1000 * ///
    (10 / years) if vintage == "base"

gen double z_part = 0
replace z_part = (employment / total_employment) * ///
    (other_change / national_employment) / (price_index / 100) / 1000 * ///
    (10 / years) if vintage == "early"

gen double weight = population if vintage == "base"
collapse (sum) x_part z_part (max) weight, by(area period)
rename x_part x
rename z_part z

merge 1:1 area period using `outcomes', assert(match) nogen
isid area period
assert _N == 72

quietly ivregress 2sls change_pp period control (x = z) [aw=weight]
assert e(N) == 72
scalar iv_slope = _b[x]

quietly summarize x if area == 0 & period == 0, meanonly
assert r(N) == 1
scalar exposure_area0_period0 = r(mean)

quietly summarize x if area == 0 & period == 1, meanonly
assert r(N) == 1
scalar exposure_area0_period1 = r(mean)

quietly summarize z if area == 0 & period == 0, meanonly
assert r(N) == 1
scalar instrument_area0_period0 = r(mean)

display "ANSWER: iv_slope estimate=" %21.12g scalar(iv_slope) " se=NA n_obs=72"
display "ANSWER: exposure_area0_period0 estimate=" %21.12g scalar(exposure_area0_period0) " se=NA n_obs=72"
display "ANSWER: exposure_area0_period1 estimate=" %21.12g scalar(exposure_area0_period1) " se=NA n_obs=72"
display "ANSWER: instrument_area0_period0 estimate=" %21.12g scalar(instrument_area0_period0) " se=NA n_obs=72"
