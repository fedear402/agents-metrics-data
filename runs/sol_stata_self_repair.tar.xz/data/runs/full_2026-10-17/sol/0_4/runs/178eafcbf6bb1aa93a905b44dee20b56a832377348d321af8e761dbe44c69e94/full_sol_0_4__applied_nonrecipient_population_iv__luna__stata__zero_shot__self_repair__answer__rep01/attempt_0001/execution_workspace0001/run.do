clear all
set more off

import delimited "households.csv", clear
keep if recipient == 0

generate double ineligible      = 1 - eligible
generate double base_ineligible = baseline * ineligible
generate double base_eligible   = baseline * eligible
generate double dose_ineligible = dose * ineligible
generate double dose_eligible   = dose * eligible
generate double iv_ineligible   = instrument * ineligible
generate double iv_eligible     = instrument * eligible

ivregress 2sls outcome ///
    ineligible eligible base_ineligible base_eligible ///
    (dose_ineligible dose_eligible = iv_ineligible iv_eligible) ///
    [aw=weight], noconstant

scalar n_obs = e(N)
generate byte estimation_sample = e(sample)

quietly summarize dose [aw=weight] if estimation_sample & eligible == 0
scalar ineligible_effect = _b[dose_ineligible] * r(mean)

quietly summarize dose [aw=weight] if estimation_sample & eligible == 1
scalar eligible_nonrecipient_effect = _b[dose_eligible] * r(mean)

import delimited "census.csv", clear
quietly summarize nonrecipient_population if eligible == 0
scalar population_ineligible = r(sum)
quietly summarize nonrecipient_population if eligible == 1
scalar population_eligible = r(sum)

scalar population_effect = ///
    (population_ineligible * ineligible_effect + ///
     population_eligible * eligible_nonrecipient_effect) / ///
    (population_ineligible + population_eligible)

display "ANSWER: ineligible_effect estimate=" ///
    %21.16g ineligible_effect " se=NA n_obs=" %12.0f n_obs
display "ANSWER: eligible_nonrecipient_effect estimate=" ///
    %21.16g eligible_nonrecipient_effect " se=NA n_obs=" %12.0f n_obs
display "ANSWER: population_effect estimate=" ///
    %21.16g population_effect " se=NA n_obs=" %12.0f n_obs
