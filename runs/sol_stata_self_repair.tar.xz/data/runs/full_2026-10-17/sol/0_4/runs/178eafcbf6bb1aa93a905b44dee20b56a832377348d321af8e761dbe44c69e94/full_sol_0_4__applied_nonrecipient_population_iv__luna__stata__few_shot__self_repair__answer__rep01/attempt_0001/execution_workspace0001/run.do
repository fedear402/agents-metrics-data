clear all
set more off
set type double

import delimited "households.csv", clear varnames(1)
keep if recipient == 0

count
local n_obs = r(N)

generate double ineligible = 1 - eligible
generate double dose0 = dose * ineligible
generate double dose1 = dose * eligible
generate double baseline0 = baseline * ineligible
generate double baseline1 = baseline * eligible
generate double instrument0 = instrument * ineligible
generate double instrument1 = instrument * eligible

ivregress 2sls outcome ineligible eligible baseline0 baseline1 ///
    (dose0 dose1 = instrument0 instrument1) [aw=weight], noconstant

scalar slope0 = _b[dose0]
scalar slope1 = _b[dose1]

summarize dose [aw=weight] if eligible == 0, meanonly
scalar effect0 = slope0 * r(mean)

summarize dose [aw=weight] if eligible == 1, meanonly
scalar effect1 = slope1 * r(mean)

preserve
import delimited "census.csv", clear varnames(1)

quietly summarize nonrecipient_population if eligible == 0, meanonly
scalar population0 = r(sum)

quietly summarize nonrecipient_population if eligible == 1, meanonly
scalar population1 = r(sum)
restore

scalar population_effect = ///
    (effect0 * population0 + effect1 * population1) / ///
    (population0 + population1)

display "ANSWER: ineligible_effect estimate=" %24.16g (effect0) ///
    " se=NA n_obs=" `n_obs'
display "ANSWER: eligible_nonrecipient_effect estimate=" %24.16g (effect1) ///
    " se=NA n_obs=" `n_obs'
display "ANSWER: population_effect estimate=" %24.16g (population_effect) ///
    " se=NA n_obs=" `n_obs'
