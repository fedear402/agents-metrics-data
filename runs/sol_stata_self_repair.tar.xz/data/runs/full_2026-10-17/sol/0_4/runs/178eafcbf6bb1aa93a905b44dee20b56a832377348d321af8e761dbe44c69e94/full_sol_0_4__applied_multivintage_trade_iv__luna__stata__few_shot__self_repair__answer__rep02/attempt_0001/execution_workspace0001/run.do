clear all
set more off
set type double

tempfile crosswalk industries trade areas employment basepop

import delimited "crosswalk.csv", clear varnames(1)
save `crosswalk'
keep industry
duplicates drop
gen byte join_key = 1
save `industries'

import delimited "trade.csv", clear varnames(1)
merge m:1 code using `crosswalk', assert(match) keep(match) nogen
save `trade'

import delimited "employment.csv", clear varnames(1)
save `employment'

import delimited "areas.csv", clear varnames(1)
save `areas'
keep if vintage == "base"
keep area period population
isid area period
save `basepop'

use `areas', clear
gen byte join_key = 1
joinby join_key using `industries'
drop join_key
merge 1:1 area period vintage industry using `employment', keep(master match) nogen
replace employment = 0 if missing(employment)

bysort period vintage industry: egen double national_employment = total(employment)
merge m:1 period industry using `trade', assert(match) keep(match) nogen

gen double xpart = (employment / total_employment) * ///
    (us_change / national_employment) / (price_index / 100) / 1000 * ///
    (10 / years) if vintage == "base"
gen double zpart = (employment / total_employment) * ///
    (other_change / national_employment) / (price_index / 100) / 1000 * ///
    (10 / years) if vintage == "early"

collapse (sum) x=xpart z=zpart, by(area period)
merge 1:1 area period using `basepop', assert(match) keep(match) nogen

import delimited "outcomes.csv", clear varnames(1)
merge 1:1 area period using `basepop', assert(match) keep(match) nogen
tempfile outcomes
save `outcomes'

use `areas', clear
gen byte join_key = 1
joinby join_key using `industries'
drop join_key
merge 1:1 area period vintage industry using `employment', keep(master match) nogen
replace employment = 0 if missing(employment)
bysort period vintage industry: egen double national_employment = total(employment)
merge m:1 period industry using `trade', assert(match) keep(match) nogen
gen double xpart = (employment / total_employment) * ///
    (us_change / national_employment) / (price_index / 100) / 1000 * ///
    (10 / years) if vintage == "base"
gen double zpart = (employment / total_employment) * ///
    (other_change / national_employment) / (price_index / 100) / 1000 * ///
    (10 / years) if vintage == "early"
collapse (sum) x=xpart z=zpart, by(area period)
merge 1:1 area period using `outcomes', assert(match) keep(match) nogen

ivregress 2sls change_pp period control (x = z) [aw=population]
scalar iv_slope = _b[x]

quietly summarize x if area == 0 & period == 0, meanonly
scalar exposure_area0_period0 = r(mean)
quietly summarize x if area == 0 & period == 1, meanonly
scalar exposure_area0_period1 = r(mean)
quietly summarize z if area == 0 & period == 0, meanonly
scalar instrument_area0_period0 = r(mean)

display "ANSWER: iv_slope estimate=" %24.16g iv_slope " se=NA n_obs=72"
display "ANSWER: exposure_area0_period0 estimate=" %24.16g exposure_area0_period0 " se=NA n_obs=72"
display "ANSWER: exposure_area0_period1 estimate=" %24.16g exposure_area0_period1 " se=NA n_obs=72"
display "ANSWER: instrument_area0_period0 estimate=" %24.16g instrument_area0_period0 " se=NA n_obs=72"
