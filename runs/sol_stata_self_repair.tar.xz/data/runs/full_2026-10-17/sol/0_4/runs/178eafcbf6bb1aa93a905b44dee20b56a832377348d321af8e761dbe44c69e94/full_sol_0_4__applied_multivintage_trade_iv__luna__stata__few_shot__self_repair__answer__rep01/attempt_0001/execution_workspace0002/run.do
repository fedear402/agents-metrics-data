clear all
set more off
set type double

tempfile crosswalk trade areas exposure outcomes

import delimited "crosswalk.csv", clear varnames(1)
save `crosswalk'

import delimited "trade.csv", clear varnames(1)
merge m:1 code using `crosswalk', keep(match) nogen
save `trade'

import delimited "areas.csv", clear varnames(1)
save `areas'

import delimited "outcomes.csv", clear varnames(1)
save `outcomes'

import delimited "employment.csv", clear varnames(1)
merge m:1 area period vintage using `areas', keep(match) nogen
bysort period vintage industry: egen double national_employment = total(employment)
merge m:1 period industry using `trade', keep(match) nogen

gen double xpart = 0
replace xpart = (employment/total_employment) * ///
    (us_change/national_employment) / (price_index/100) / 1000 * ///
    (10/years) if vintage == "base"

gen double zpart = 0
replace zpart = (employment/total_employment) * ///
    (other_change/national_employment) / (price_index/100) / 1000 * ///
    (10/years) if vintage == "early"

collapse (sum) xpart zpart, by(area period)
rename xpart x
rename zpart z
save `exposure'

use `areas', clear
keep if vintage == "base"
keep area period population
rename population weight

merge 1:1 area period using `exposure', nogen
replace x = 0 if missing(x)
replace z = 0 if missing(z)
merge 1:1 area period using `outcomes', nogen

ivregress 2sls change_pp period control (x = z) [aw=weight]
assert e(N) == 72
scalar iv_slope = _b[x]

quietly summarize x if area == 0 & period == 0, meanonly
scalar exposure_area0_period0 = r(mean)
quietly summarize x if area == 0 & period == 1, meanonly
scalar exposure_area0_period1 = r(mean)
quietly summarize z if area == 0 & period == 0, meanonly
scalar instrument_area0_period0 = r(mean)

display "ANSWER: iv_slope estimate=" %24.16g scalar(iv_slope) " se=NA n_obs=72"
display "ANSWER: exposure_area0_period0 estimate=" %24.16g scalar(exposure_area0_period0) " se=NA n_obs=72"
display "ANSWER: exposure_area0_period1 estimate=" %24.16g scalar(exposure_area0_period1) " se=NA n_obs=72"
display "ANSWER: instrument_area0_period0 estimate=" %24.16g scalar(instrument_area0_period0) " se=NA n_obs=72"
