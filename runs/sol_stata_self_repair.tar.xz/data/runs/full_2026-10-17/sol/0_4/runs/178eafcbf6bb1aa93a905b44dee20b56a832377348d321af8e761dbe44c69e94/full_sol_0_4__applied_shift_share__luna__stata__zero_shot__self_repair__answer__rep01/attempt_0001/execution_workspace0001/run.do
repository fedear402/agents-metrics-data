clear all
set more off
set linesize 255

import delimited "./input.csv", clear

egen byte region_tag = tag(region_id)
generate double tagged_weight = region_weight if region_tag
egen double weight_total = total(tagged_weight)
generate double e = region_weight / weight_total

generate double share_shock = share * shock
bysort region_id: egen double z = total(share_shock)

generate double tagged_y = e * y if region_tag
generate double tagged_x = e * x if region_tag
generate double tagged_z = e * z if region_tag

egen double mean_y = total(tagged_y)
egen double mean_x = total(tagged_x)
egen double mean_z = total(tagged_z)

generate double y0 = y - mean_y
generate double x0 = x - mean_x
generate double z0 = z - mean_z

generate double exposure = e * share
generate double exposure_y = exposure * y0
generate double exposure_x = exposure * x0
generate double exposure_z = exposure * z0

collapse (sum) s=exposure sum_y=exposure_y sum_x=exposure_x ///
    sum_z=exposure_z (first) shock, by(industry_id)

generate double ybar = sum_y / s
generate double xbar = sum_x / s
generate double zbar = sum_z / s

quietly count
scalar N = r(N)

quietly ivregress 2sls ybar (xbar = shock) [aw=s]
scalar effect = _b[xbar]

quietly ivregress 2sls xbar (zbar = shock) [aw=s]
scalar first_stage = _b[zbar]

generate double weighted_shock = s * shock
egen double mean_shock = total(weighted_shock)
generate double centered_shock = shock - mean_shock

generate double effect_residual = ybar - effect * xbar
generate double stage_residual = xbar - first_stage * zbar
generate double effect_den_term = s * centered_shock * xbar
generate double stage_den_term = s * centered_shock * zbar
generate double effect_var_term = ///
    (s * centered_shock * effect_residual)^2
generate double stage_var_term = ///
    (s * centered_shock * stage_residual)^2

egen double effect_den = total(effect_den_term)
egen double stage_den = total(stage_den_term)
egen double effect_var_sum = total(effect_var_term)
egen double stage_var_sum = total(stage_var_term)

scalar effect_se = sqrt((N / (N - 2)) * ///
    effect_var_sum[1] / effect_den[1]^2)
scalar first_stage_se = sqrt((N / (N - 2)) * ///
    stage_var_sum[1] / stage_den[1]^2)

generate double s_squared = s^2
egen double sum_s_squared = total(s_squared)
scalar effective_shocks = 1 / sum_s_squared[1]

display "ANSWER: effect estimate=" %21.12f effect ///
    " se=" %21.12f effect_se " n_obs=" %12.0f N
display "ANSWER: first_stage estimate=" %21.12f first_stage ///
    " se=" %21.12f first_stage_se " n_obs=" %12.0f N
display "ANSWER: effective_shocks estimate=" %21.12f effective_shocks ///
    " se=. n_obs=" %12.0f N
