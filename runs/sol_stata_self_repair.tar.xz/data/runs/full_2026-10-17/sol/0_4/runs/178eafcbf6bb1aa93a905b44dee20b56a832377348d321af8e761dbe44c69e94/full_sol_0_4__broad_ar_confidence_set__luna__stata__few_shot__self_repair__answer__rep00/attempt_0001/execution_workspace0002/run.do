clear all
set more off
set linesize 255
set type double

import delimited using "./input.csv", clear
local n = _N

quietly regress y x
predict double ry, residuals
quietly regress endog x
predict double rd, residuals

quietly regress y x z1 z2
predict double uy, residuals
quietly regress endog x z1 z2
predict double ud, residuals

scalar df = `n' - 4
scalar critical = invFtail(2, df, .05)
scalar k = 2 * critical / df

mata:
    ry = st_data(., "ry")
    rd = st_data(., "rd")
    uy = st_data(., "uy")
    ud = st_data(., "ud")
    k = st_numscalar("k")
    df = st_numscalar("df")

    A = quadcross(rd, rd) - (1+k)*quadcross(ud, ud)
    B = -2*(quadcross(ry, rd) - (1+k)*quadcross(uy, ud))
    C = quadcross(ry, ry) - (1+k)*quadcross(uy, uy)

    discriminant = B^2 - 4*A*C
    bounds = sort(((-B-sqrt(discriminant))/(2*A) \ (-B+sqrt(discriminant))/(2*A)), 1)

    ssr_r_one = quadcross(ry-rd, ry-rd)
    ssr_u_one = quadcross(uy-ud, uy-ud)
    f_one = ((ssr_r_one-ssr_u_one)/2)/(ssr_u_one/df)

    st_numscalar("boundary_low", bounds[1])
    st_numscalar("boundary_high", bounds[2])
    st_numscalar("accepts_zero", C<=0)
    st_numscalar("unbounded", A<0)
    st_numscalar("ar_f_at_one", f_one)
end

display "ANSWER: boundary_low estimate=" %21.15g (boundary_low) " se=. n_obs=" %12.0f (`n')
display "ANSWER: boundary_high estimate=" %21.15g (boundary_high) " se=. n_obs=" %12.0f (`n')
display "ANSWER: accepts_zero estimate=" %21.15g (accepts_zero) " se=. n_obs=" %12.0f (`n')
display "ANSWER: unbounded estimate=" %21.15g (unbounded) " se=. n_obs=" %12.0f (`n')
display "ANSWER: ar_f_at_one estimate=" %21.15g (ar_f_at_one) " se=. n_obs=" %12.0f (`n')
