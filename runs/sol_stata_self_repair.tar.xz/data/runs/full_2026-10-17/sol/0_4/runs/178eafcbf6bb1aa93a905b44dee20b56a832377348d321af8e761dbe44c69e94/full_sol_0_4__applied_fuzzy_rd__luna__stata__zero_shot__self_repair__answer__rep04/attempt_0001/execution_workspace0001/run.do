clear all
set more off
set linesize 255

import delimited "./input.csv", clear
keep if !missing(score, participated, earnings) & abs(score) < 1

generate double right = score >= 0
generate double left_slope = score * (1 - right)
generate double right_slope = score * right
generate double weight = 1 - abs(score)

mata:
    X = (J(st_nobs(), 1, 1), st_data(., "right"), ///
         st_data(., "left_slope"), st_data(., "right_slope"))
    w = st_data(., "weight")
    y = st_data(., "earnings")
    d = st_data(., "participated")

    A = invsym(quadcross(X, w, X))
    by = A * quadcross(X, w, y)
    bd = A * quadcross(X, w, d)

    uy = y - X * by
    ud = d - X * bd
    h = (X * A[, 2]) :* w

    rf = by[2]
    fs = bd[2]
    var_rf = sum((h :* uy) :^ 2)
    var_fs = sum((h :* ud) :^ 2)
    cov_rf_fs = sum((h :* uy) :* (h :* ud))

    st_numscalar("reduced_form", rf)
    st_numscalar("first_stage", fs)
    st_numscalar("reduced_form_se", sqrt(var_rf))
    st_numscalar("first_stage_se", sqrt(var_fs))

    if (fs == 0) {
        st_numscalar("treatment_effect", .)
        st_numscalar("treatment_effect_se", .)
    }
    else {
        st_numscalar("treatment_effect", rf / fs)
        v = var_rf / fs^2 + rf^2 * var_fs / fs^4 ///
            - 2 * rf * cov_rf_fs / fs^3
        st_numscalar("treatment_effect_se", sqrt(max((0, v))))
    }
end

display "ANSWER: treatment_effect estimate=" %21.12f treatment_effect ///
    " se=" %21.12f treatment_effect_se " n_obs=" %12.0f _N
display "ANSWER: reduced_form estimate=" %21.12f reduced_form ///
    " se=" %21.12f reduced_form_se " n_obs=" %12.0f _N
display "ANSWER: first_stage estimate=" %21.12f first_stage ///
    " se=" %21.12f first_stage_se " n_obs=" %12.0f _N
