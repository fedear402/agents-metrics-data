clear all
set more off
set linesize 255

import delimited using "./input.csv", clear
sort date

generate double ln_sales = ln(sales)
generate double dln_vix = ln(vix) - ln(vix[_n-1])

forvalues k = 1/15 {
    generate double lag_`k' = dln_vix[_n-`k']
}

regress ln_sales lag_1-lag_15
generate byte used = e(sample)

mata:
    X = st_data(., tokens("lag_1 lag_2 lag_3 lag_4 lag_5 lag_6 lag_7 lag_8 lag_9 lag_10 lag_11 lag_12 lag_13 lag_14 lag_15"), "used")
    y = st_data(., "ln_sales", "used")
    N = rows(X)
    X = X, J(N, 1, 1)

    b = st_matrix("e(b)")'
    u = y - X*b
    Z = X :* (u*J(1, cols(X), 1))

    S = Z'Z
    for (j=1; j<=15; j++) {
        G = Z[(j+1)..N,]' * Z[1..(N-j),]
        S = S + (1-j/16)*(G+G')
    }

    Q = invsym(X'X)
    V = (N/(N-16))*Q*S*Q

    c = J(1, 15, 1), 0
    st_numscalar("cumulative_est", sum(b[1..15]))
    st_numscalar("cumulative_se", sqrt(c*V*c'))
    st_numscalar("lag1_est", b[1])
    st_numscalar("lag1_se", sqrt(V[1,1]))
    st_numscalar("lag15_est", b[15])
    st_numscalar("lag15_se", sqrt(V[15,15]))
    st_numscalar("n_used", N)
end

display "ANSWER: cumulative_response estimate=" %21.12f scalar(cumulative_est) " se=" %21.12f scalar(cumulative_se) " n_obs=" %12.0f scalar(n_used)
display "ANSWER: lag_1 estimate=" %21.12f scalar(lag1_est) " se=" %21.12f scalar(lag1_se) " n_obs=" %12.0f scalar(n_used)
display "ANSWER: lag_15 estimate=" %21.12f scalar(lag15_est) " se=" %21.12f scalar(lag15_se) " n_obs=" %12.0f scalar(n_used)
