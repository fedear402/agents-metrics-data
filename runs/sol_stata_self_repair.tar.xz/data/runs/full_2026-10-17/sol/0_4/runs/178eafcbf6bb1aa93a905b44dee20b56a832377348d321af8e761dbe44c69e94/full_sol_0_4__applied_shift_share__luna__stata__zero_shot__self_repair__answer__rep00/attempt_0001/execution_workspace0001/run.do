set more off
set linesize 255
import delimited "./input.csv", clear

bysort region_id: egen double z = total(share * shock)
egen byte region_tag = tag(region_id)
quietly summarize region_weight if region_tag, meanonly
scalar total_weight = r(sum)
generate double e = region_weight / total_weight

foreach v in y x z {
    quietly summarize `v' [aw=e] if region_tag, meanonly
    generate double `v'0 = `v' - r(mean)
}

generate double es = e * share
foreach v in y x z {
    generate double es_`v' = es * `v'0
}

collapse (sum) s=es sy=es_y sx=es_x sz=es_z (first) shock, by(industry_id)
generate double ybar = sy / s
generate double xbar = sx / s
generate double zbar = sz / s

quietly count
scalar N = r(N)

quietly ivregress 2sls ybar (xbar = shock) [aw=s], vce(robust)
scalar effect = _b[xbar]
scalar effect_se = _se[xbar] * sqrt((N - 1) / (N - 2))

quietly ivregress 2sls xbar (zbar = shock) [aw=s], vce(robust)
scalar first_stage = _b[zbar]
scalar first_stage_se = _se[zbar] * sqrt((N - 1) / (N - 2))

generate double s_squared = s^2
quietly summarize s_squared, meanonly
scalar effective_shocks = 1 / r(sum)

display "ANSWER: effect estimate=" %21.12f effect " se=" %21.12f effect_se " n_obs=" %12.0f N
display "ANSWER: first_stage estimate=" %21.12f first_stage " se=" %21.12f first_stage_se " n_obs=" %12.0f N
display "ANSWER: effective_shocks estimate=" %21.12f effective_shocks " se=. n_obs=" %12.0f N
