clear all
set more off

tempfile crosswalk trade areas employment national outcomes exposures basepop

import delimited "crosswalk.csv", clear varnames(1)
save `crosswalk'

import delimited "trade.csv", clear varnames(1)
merge m:1 code using `crosswalk', assert(match) nogen
save `trade'

import delimited "areas.csv", clear varnames(1)
save `areas'

preserve
keep if vintage == "base"
keep area period population
rename population base_population
save `basepop'
restore

import delimited "employment.csv", clear varnames(1)
collapse (sum) employment, by(period vintage industry)
rename employment national_employment
save `national'

import delimited "employment.csv", clear varnames(1)
merge m:1 area period vintage using `areas', assert(match) nogen
merge m:1 period vintage industry using `national', assert(match) nogen
merge m:1 period industry using `trade', assert(match) nogen

gen double contribution = .
replace contribution = (employment / total_employment) * ///
    (us_change / national_employment) / (price_index / 100) / 1000 * ///
    (10 / years) if vintage == "base"
replace contribution = (employment / total_employment) * ///
    (other_change / national_employment) / (price_index / 100) / 1000 * ///
    (10 / years) if vintage == "early"

collapse (sum) contribution, by(area period vintage)
reshape wide contribution, i(area period) j(vintage) string
rename contributionbase x
rename contributionearly z
save `exposures'

import delimited "outcomes.csv", clear varnames(1)
merge 1:1 area period using `exposures', assert(match) nogen
merge 1:1 area period using `basepop', assert(match) nogen

ivregress 2sls change_pp period control (x = z) [aw=base_population]
scalar iv_slope = _b[x]

quietly summarize x if area == 0 & period == 0, meanonly
scalar exposure_area0_period0 = r(mean)
quietly summarize x if area == 0 & period == 1, meanonly
scalar exposure_area0_period1 = r(mean)
quietly summarize z if area == 0 & period == 0, meanonly
scalar instrument_area0_period0 = r(mean)

display "ANSWER: iv_slope estimate=" %21.12g iv_slope " se=NA n_obs=72"
display "ANSWER: exposure_area0_period0 estimate=" %21.12g exposure_area0_period0 " se=NA n_obs=72"
display "ANSWER: exposure_area0_period1 estimate=" %21.12g exposure_area0_period1 " se=NA n_obs=72"
display "ANSWER: instrument_area0_period0 estimate=" %21.12g instrument_area0_period0 " se=NA n_obs=72"
