set more off
set linesize 255

import delimited using "./input.csv", clear

* Keep one observation per region to normalize regional weights.
bysort region_id: gen byte region_first = (_n == 1)
quietly summarize region_weight if region_first, meanonly
gen double e = region_weight / r(sum)

* Construct the regional shift-share instrument.
gen double exposure = share * shock
bysort region_id: egen double z = total(exposure)

* Compute weighted regional means using one observation per region.
foreach v in y x z {
    gen double weighted_`v' = e * `v' if region_first
    quietly summarize weighted_`v', meanonly
    gen double `v'0 = `v' - r(sum)
}

* Aggregate demeaned variables to the industry level.
gen double exposure_weight = e * share
foreach v in y x z {
    gen double aggregate_`v' = exposure_weight * `v'0
}

collapse (sum) s=exposure_weight aggregate_y aggregate_x aggregate_z ///
    (firstnm) shock, by(industry_id)

gen double ybar = aggregate_y / s
gen double xbar = aggregate_x / s
gen double zbar = aggregate_z / s

quietly count
scalar N = r(N)

* Shock-level IV slopes equal the corresponding regional weighted slopes.
* Robust IV variance uses structural residuals and analytic weights.
quietly ivregress 2sls ybar (xbar = shock) [aweight=s], vce(robust)
scalar effect = _b[xbar]
scalar effect_se = _se[xbar] * sqrt((N - 2) / (N - 1))

quietly ivregress 2sls xbar (zbar = shock) [aweight=s], vce(robust)
scalar first_stage = _b[zbar]
scalar first_stage_se = _se[zbar] * sqrt((N - 2) / (N - 1))

gen double s_squared = s^2
quietly summarize s_squared, meanonly
scalar effective_shocks = 1 / r(sum)

display "ANSWER: effect estimate=" %21.12f effect " se=" %21.12f effect_se " n_obs=" %12.0f N
display "ANSWER: first_stage estimate=" %21.12f first_stage " se=" %21.12f first_stage_se " n_obs=" %12.0f N
display "ANSWER: effective_shocks estimate=" %21.12f effective_shocks " se=. n_obs=" %12.0f N
