clear all
set more off

tempfile crosswalk_data trade_data employment_data outcome_data

import delimited "crosswalk.csv", clear
isid code
save "`crosswalk_data'"

import delimited "trade.csv", clear
merge m:1 code using "`crosswalk_data'", assert(match) nogen
isid period industry
save "`trade_data'"

import delimited "employment.csv", clear
isid area period vintage industry
save "`employment_data'"

import delimited "outcomes.csv", clear
isid area period
save "`outcome_data'"

import delimited "areas.csv", clear
isid area period vintage
joinby period using "`trade_data'"

merge 1:1 area period vintage industry using "`employment_data'", ///
    keep(master match) nogen
replace employment = 0 if missing(employment)

bysort period vintage industry: egen double national_employment = total(employment)
assert national_employment > 0

gen double exposure = ///
    (employment / total_employment) * ///
    (cond(vintage == "base", us_change, other_change) / national_employment) * ///
    (100 / price_index) / 1000 * (10 / years)

collapse (sum) exposure (firstnm) population, by(area period vintage)
reshape wide exposure population, i(area period) j(vintage) string
rename exposurebase x
rename exposureearly z

merge 1:1 area period using "`outcome_data'", assert(match) nogen
assert !missing(change_pp, period, control, x, z, populationbase)
count
assert r(N) == 72

quietly summarize x if area == 0 & period == 0, meanonly
assert r(N) == 1
scalar exposure_00 = r(mean)

quietly summarize x if area == 0 & period == 1, meanonly
assert r(N) == 1
scalar exposure_01 = r(mean)

quietly summarize z if area == 0 & period == 0, meanonly
assert r(N) == 1
scalar instrument_00 = r(mean)

quietly ivregress 2sls change_pp period control (x = z) [aw = populationbase]
assert e(N) == 72
scalar iv_slope = _b[x]

display "ANSWER: iv_slope estimate=" strtrim(string(iv_slope, "%24.16g")) " se=NA n_obs=72"
display "ANSWER: exposure_area0_period0 estimate=" strtrim(string(exposure_00, "%24.16g")) " se=NA n_obs=72"
display "ANSWER: exposure_area0_period1 estimate=" strtrim(string(exposure_01, "%24.16g")) " se=NA n_obs=72"
display "ANSWER: instrument_area0_period0 estimate=" strtrim(string(instrument_00, "%24.16g")) " se=NA n_obs=72"
