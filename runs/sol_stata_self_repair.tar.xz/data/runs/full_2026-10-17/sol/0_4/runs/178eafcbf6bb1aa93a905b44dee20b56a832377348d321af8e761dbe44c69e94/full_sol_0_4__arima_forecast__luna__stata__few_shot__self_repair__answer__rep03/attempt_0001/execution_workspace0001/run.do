clear all
set more off
set linesize 255

import delimited "./input.csv", clear
tsset t

quietly arima y, arima(1,1,1) noconstant
local n_obs = e(N)

tsappend, add(1)
quietly predict double y_forecast, y dynamic(251)
quietly predict double forecast_mse, mse dynamic(251)

quietly summarize y_forecast if t == 251, meanonly
scalar forecast = r(mean)
quietly summarize forecast_mse if t == 251, meanonly
scalar forecast_se = sqrt(r(mean))
scalar lower_95 = forecast - invnormal(.975)*forecast_se
scalar upper_95 = forecast + invnormal(.975)*forecast_se

display "ANSWER: forecast estimate=" %21.12f forecast " se=" %21.12f forecast_se " n_obs=" %12.0f `n_obs'
display "ANSWER: lower_95 estimate=" %21.12f lower_95 " se=. n_obs=" %12.0f `n_obs'
display "ANSWER: upper_95 estimate=" %21.12f upper_95 " se=. n_obs=" %12.0f `n_obs'
