version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear
egen long region_num = group(region_id)
egen long industry_num = group(industry_id)

mata:
    d = st_data(., ("region_num", "industry_num", "share", "shock", "region_weight", "x", "y"))
    R = max(d[,1])
    N = max(d[,2])

    S = J(R, N, 0)
    g = J(N, 1, .)
    w = J(R, 1, .)
    x = J(R, 1, .)
    y = J(R, 1, .)

    for (i = 1; i <= rows(d); i++) {
        r = d[i,1]
        n = d[i,2]
        S[r,n] = d[i,3]
        g[n] = d[i,4]
        w[r] = d[i,5]
        x[r] = d[i,6]
        y[r] = d[i,7]
    }

    e = w / sum(w)
    z = S * g
    regional = (y, x, z)
    centered = regional :- e' * regional

    mass = S' * e
    aggregated = (S' * (e :* centered)) :/ mass

    effect_regional = sum(e :* centered[,3] :* centered[,1]) / ///
        sum(e :* centered[,3] :* centered[,2])
    first_stage_regional = sum(e :* centered[,3] :* centered[,2]) / ///
        sum(e :* centered[,3] :^ 2)

    slopes = J(2, 1, .)
    ses = J(2, 1, .)
    instruments = (J(N,1,1), g)

    for (k = 1; k <= 2; k++) {
        dependent = aggregated[,k]
        endogenous = aggregated[,k+1]
        regressors = (J(N,1,1), endogenous)

        inverse = luinv(instruments' * (mass :* regressors))
        beta = inverse * instruments' * (mass :* dependent)
        residual = dependent - regressors * beta
        scores = instruments :* (mass :* residual)

        covariance = N/(N-2) * inverse * (scores' * scores) * inverse'
        slopes[k] = beta[2]
        ses[k] = sqrt(covariance[2,2])
    }

    assert(max(abs(slopes - (effect_regional \ first_stage_regional))) < 1e-10)

    st_numscalar("effect_est", effect_regional)
    st_numscalar("effect_se", ses[1])
    st_numscalar("first_stage_est", first_stage_regional)
    st_numscalar("first_stage_se", ses[2])
    st_numscalar("effective_shocks_est", 1/sum(mass:^2))
    st_numscalar("industry_count", N)
end

display "ANSWER: effect estimate=" %21.12f effect_est ///
    " se=" %21.12f effect_se " n_obs=" %12.0f industry_count
display "ANSWER: first_stage estimate=" %21.12f first_stage_est ///
    " se=" %21.12f first_stage_se " n_obs=" %12.0f industry_count
display "ANSWER: effective_shocks estimate=" %21.12f effective_shocks_est ///
    " se=. n_obs=" %12.0f industry_count
