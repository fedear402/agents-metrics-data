set more off
set linesize 255

import delimited using "./input.csv", clear

bysort region_id: gen byte region_tag = (_n == 1)
egen double total_region_weight = total(cond(region_tag, region_weight, 0))
gen double e = region_weight / total_region_weight

bysort region_id: egen double z = total(share * shock)

egen double mean_y = total(cond(region_tag, e * y, 0))
egen double mean_x = total(cond(region_tag, e * x, 0))
egen double mean_z = total(cond(region_tag, e * z, 0))

gen double y0 = y - mean_y
gen double x0 = x - mean_x
gen double z0 = z - mean_z

gen double exposure = e * share
gen double exposure_y = exposure * y0
gen double exposure_x = exposure * x0
gen double exposure_z = exposure * z0

collapse (sum) s=exposure exposure_y exposure_x exposure_z ///
    (firstnm) shock, by(industry_id)

gen double ybar = exposure_y / s
gen double xbar = exposure_x / s
gen double zbar = exposure_z / s

scalar N = _N

egen double mean_shock = total(s * shock)
egen double mean_ybar = total(s * ybar)
egen double mean_xbar = total(s * xbar)
egen double mean_zbar = total(s * zbar)

gen double gc = shock - mean_shock
gen double yc = ybar - mean_ybar
gen double xc = xbar - mean_xbar
gen double zc = zbar - mean_zbar

egen double cov_gy = total(s * gc * yc)
egen double cov_gx = total(s * gc * xc)
egen double cov_gz = total(s * gc * zc)

scalar effect = cov_gy[1] / cov_gx[1]
scalar first_stage = cov_gx[1] / cov_gz[1]

gen double effect_residual = yc - effect * xc
gen double first_stage_residual = xc - first_stage * zc

egen double effect_meat = total((s * gc * effect_residual)^2)
egen double first_stage_meat = total((s * gc * first_stage_residual)^2)
egen double sum_s_squared = total(s^2)

scalar effect_se = sqrt((N / (N - 2)) * effect_meat[1] / cov_gx[1]^2)
scalar first_stage_se = sqrt((N / (N - 2)) * first_stage_meat[1] / cov_gz[1]^2)
scalar effective_shocks = 1 / sum_s_squared[1]

display "ANSWER: effect estimate=" %21.12f effect " se=" %21.12f effect_se " n_obs=" %12.0f N
display "ANSWER: first_stage estimate=" %21.12f first_stage " se=" %21.12f first_stage_se " n_obs=" %12.0f N
display "ANSWER: effective_shocks estimate=" %21.12f effective_shocks " se=. n_obs=" %12.0f N
