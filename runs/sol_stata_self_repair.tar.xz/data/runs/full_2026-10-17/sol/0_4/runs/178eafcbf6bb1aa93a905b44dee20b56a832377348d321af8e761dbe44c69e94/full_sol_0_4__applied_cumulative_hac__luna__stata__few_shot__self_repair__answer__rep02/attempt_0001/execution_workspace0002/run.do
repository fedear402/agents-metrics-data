version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear
generate double day = date(date, "YMD")
sort day
generate long observation = _n
tsset observation

generate double log_sales = log(sales)
generate double log_vix = log(vix)
generate double vix_change = D.log_vix

local regressors
forvalues k = 1/15 {
    generate double change_lag`k' = L`k'.vix_change
    local regressors `regressors' change_lag`k'
}

keep if !missing(log_sales)
forvalues k = 1/15 {
    keep if !missing(change_lag`k')
}

mata:
X = (J(st_nobs(), 1, 1), st_data(., tokens(st_local("regressors"))))
y = st_data(., "log_sales")
b = qrsolve(X, y)
N = rows(X)
p = cols(X)
u = y - X*b
scores = X :* u

meat = scores' * scores
for (j = 1; j <= 15; j++) {
    lag_product = scores[|j+1,1\N,p|]' * scores[|1,1\N-j,p|]
    meat = meat + (1-j/16) * (lag_product + lag_product')
}
bread = invsym(X' * X)
V = (N/(N-p)) * bread * meat * bread

contrast = (0 \ J(15,1,1))
cumulative = contrast' * b
cumulative_se = sqrt(contrast' * V * contrast)

printf("ANSWER: cumulative_response estimate=%21.15g se=%21.15g n_obs=%12.0f\n", cumulative, cumulative_se, N)
printf("ANSWER: lag_1 estimate=%21.15g se=%21.15g n_obs=%12.0f\n", b[2], sqrt(V[2,2]), N)
printf("ANSWER: lag_15 estimate=%21.15g se=%21.15g n_obs=%12.0f\n", b[16], sqrt(V[16,16]), N)
end
