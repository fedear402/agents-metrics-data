version 19.0
clear all
set more off
set linesize 255

import delimited "./input.csv", clear
egen long region_num = group(region_id)
egen long industry_num = group(industry_id)

mata:
    data = st_data(., ("region_num", "industry_num", "share", "shock", ///
        "region_weight", "x", "y"))

    R = max(data[,1])
    N = max(data[,2])
    shares = J(R, N, 0)
    shocks = J(N, 1, .)
    weights = J(R, 1, .)
    x = J(R, 1, .)
    y = J(R, 1, .)

    for (i = 1; i <= rows(data); i++) {
        r = data[i,1]
        n = data[i,2]
        shares[r,n] = data[i,3]
        shocks[n] = data[i,4]
        weights[r] = data[i,5]
        x[r] = data[i,6]
        y[r] = data[i,7]
    }

    e = weights / sum(weights)
    z = shares * shocks
    regional = (y, x, z)
    centered = regional :- e' * regional

    mass = shares' * e
    aggregated = (shares' * (e :* centered)) :/ mass

    results = J(2, 2, .)
    for (equation = 1; equation <= 2; equation++) {
        dependent = aggregated[,equation]
        regressor = aggregated[,equation+1]
        X = (J(N,1,1), regressor)
        Z = (J(N,1,1), shocks)

        inverse = luinv(Z' * (mass :* X))
        beta = inverse * Z' * (mass :* dependent)
        residual = dependent - X * beta
        scores = Z :* (mass :* residual)
        variance = (N / (N-2)) * inverse * (scores' * scores) * inverse'

        results[equation,] = (beta[2], sqrt(variance[2,2]))
    }

    st_numscalar("effect_est", results[1,1])
    st_numscalar("effect_se", results[1,2])
    st_numscalar("first_est", results[2,1])
    st_numscalar("first_se", results[2,2])
    st_numscalar("effective_est", 1 / sum(mass:^2))
    st_numscalar("industry_count", N)
end

display "ANSWER: effect estimate=" %21.12f effect_est ///
    " se=" %21.12f effect_se " n_obs=" %12.0f industry_count
display "ANSWER: first_stage estimate=" %21.12f first_est ///
    " se=" %21.12f first_se " n_obs=" %12.0f industry_count
display "ANSWER: effective_shocks estimate=" %21.12f effective_est ///
    " se=. n_obs=" %12.0f industry_count
