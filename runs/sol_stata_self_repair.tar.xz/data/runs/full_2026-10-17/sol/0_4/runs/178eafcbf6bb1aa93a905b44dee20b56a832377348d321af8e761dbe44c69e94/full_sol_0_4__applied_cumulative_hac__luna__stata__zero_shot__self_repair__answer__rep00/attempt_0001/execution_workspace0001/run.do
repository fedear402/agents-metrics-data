set more off
set linesize 255

import delimited "./input.csv", clear

capture confirm string variable date
if !_rc {
    generate double trading_date = daily(date, "YMD")
    sort trading_date
}
else {
    sort date
}

generate double log_sales = ln(sales)
generate double dlog_vix = ln(vix) - ln(vix[_n-1])

forvalues k = 1/15 {
    generate double lag_`k' = dlog_vix[_n-`k']
}

regress log_sales lag_1-lag_15
generate byte regression_sample = e(sample)

mata:
    vars = tokens("lag_1 lag_2 lag_3 lag_4 lag_5 lag_6 lag_7 lag_8 lag_9 lag_10 lag_11 lag_12 lag_13 lag_14 lag_15")
    Z = st_data(., vars, "regression_sample")
    y = st_data(., "log_sales", "regression_sample")
    N = rows(y)
    X = (J(N, 1, 1), Z)
    b = st_matrix("e(b)")'
    u = y - X*b
    Xu = X :* (u*J(1, cols(X), 1))

    S = Xu'Xu
    for (j=1; j<=15; j++) {
        G = Xu[(j+1)..N, .]' * Xu[1..(N-j), .]
        S = S + (1-j/16)*(G+G')
    }

    Q = invsym(X'X)
    V = (N/(N-16))*Q*S*Q
    c = (0, J(1, 15, 1))

    st_numscalar("answer_n", N)
    st_numscalar("answer_cumulative", sum(b[2..16]))
    st_numscalar("answer_cumulative_se", sqrt(c*V*c'))
    st_numscalar("answer_lag_1", b[2])
    st_numscalar("answer_lag_1_se", sqrt(V[2,2]))
    st_numscalar("answer_lag_15", b[16])
    st_numscalar("answer_lag_15_se", sqrt(V[16,16]))
end

display "ANSWER: cumulative_response estimate=" %21.12f answer_cumulative " se=" %21.12f answer_cumulative_se " n_obs=" %12.0f answer_n
display "ANSWER: lag_1 estimate=" %21.12f answer_lag_1 " se=" %21.12f answer_lag_1_se " n_obs=" %12.0f answer_n
display "ANSWER: lag_15 estimate=" %21.12f answer_lag_15 " se=" %21.12f answer_lag_15_se " n_obs=" %12.0f answer_n
