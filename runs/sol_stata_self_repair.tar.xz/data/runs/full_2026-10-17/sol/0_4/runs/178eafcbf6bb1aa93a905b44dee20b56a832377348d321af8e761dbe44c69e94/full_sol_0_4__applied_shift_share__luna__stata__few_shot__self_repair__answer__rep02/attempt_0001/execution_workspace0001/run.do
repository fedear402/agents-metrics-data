version 19.0
clear all
set more off
set linesize 255

import delimited "./input.csv", clear

mata:
region = st_data(., "region_id")
industry = st_data(., "industry_id")
share = st_data(., "share")
shock_row = st_data(., "shock")
weight_row = st_data(., "region_weight")
x_row = st_data(., "x")
y_row = st_data(., "y")

regions = uniqrows(sort(region, 1))
industries = uniqrows(sort(industry, 1))
R = rows(regions)
N = rows(industries)

S = J(R, N, 0)
w = J(R, 1, .)
x = J(R, 1, .)
y = J(R, 1, .)
g = J(N, 1, .)

for (i = 1; i <= rows(region); i++) {
    r = selectindex(regions :== region[i])[1]
    n = selectindex(industries :== industry[i])[1]
    S[r,n] = share[i]
    w[r] = weight_row[i]
    x[r] = x_row[i]
    y[r] = y_row[i]
    g[n] = shock_row[i]
}

e = w / sum(w)
z = S * g
V = (y, x, z)
V0 = V :- J(R, 1, 1) * (e' * V)

s = S' * e
Vbar = (S' * (e :* V0)) :/ s
A = (J(N, 1, 1), g)
effect_regressors = (J(N, 1, 1), Vbar[,2])
first_regressors = (J(N, 1, 1), Vbar[,3])

results = J(2, 2, .)
for (k = 1; k <= 2; k++) {
    if (k == 1) {
        dependent = Vbar[,1]
        regressors = effect_regressors
    }
    else {
        dependent = Vbar[,2]
        regressors = first_regressors
    }

    inverse = luinv(A' * (s :* regressors))
    beta = inverse * (A' * (s :* dependent))
    residual = dependent - regressors * beta
    scores = A :* (s :* residual)
    covariance = (N / (N - 2)) * inverse * (scores' * scores) * inverse'
    results[k,] = (beta[2], sqrt(covariance[2,2]))
}

st_numscalar("effect_est", results[1,1])
st_numscalar("effect_se", results[1,2])
st_numscalar("first_est", results[2,1])
st_numscalar("first_se", results[2,2])
st_numscalar("effective_est", 1 / sum(s:^2))
st_numscalar("industry_count", N)
end

display "ANSWER: effect estimate=" %21.12f scalar(effect_est) " se=" %21.12f scalar(effect_se) " n_obs=" %12.0f scalar(industry_count)
display "ANSWER: first_stage estimate=" %21.12f scalar(first_est) " se=" %21.12f scalar(first_se) " n_obs=" %12.0f scalar(industry_count)
display "ANSWER: effective_shocks estimate=" %21.12f scalar(effective_est) " se=. n_obs=" %12.0f scalar(industry_count)
