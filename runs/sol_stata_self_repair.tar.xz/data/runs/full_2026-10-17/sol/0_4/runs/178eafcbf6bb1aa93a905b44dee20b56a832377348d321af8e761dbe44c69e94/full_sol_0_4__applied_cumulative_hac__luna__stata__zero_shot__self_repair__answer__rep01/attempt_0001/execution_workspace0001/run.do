set linesize 255
import delimited using "./input.csv", clear

sort date
generate double log_sales = ln(sales)
generate double dlog_vix = ln(vix) - ln(vix[_n-1])

forvalues k = 1/15 {
    generate double x`k' = dlog_vix[_n-`k']
}

regress log_sales x1-x15
generate byte sample_used = e(sample)
predict double residual if sample_used, residual

mata:
    X = J(sum(st_data(., "sample_used")), 1, 1), ///
        st_data(., tokens("x1 x2 x3 x4 x5 x6 x7 x8 x9 x10 x11 x12 x13 x14 x15"), "sample_used")
    u = st_data(., "residual", "sample_used")
    N = rows(X)
    S = X :* (u * J(1, 16, 1))
    M = quadcross(S, S)

    for (j = 1; j <= 15; j++) {
        C = quadcross(S[|j+1,1 \ N,16|], S[|1,1 \ N-j,16|])
        M = M + (1 - j/16) * (C + C')
    }

    Q = invsym(quadcross(X, X))
    V = (N/(N-16)) * Q * M * Q
    b = st_matrix("e(b)")

    st_numscalar("cumulative_response", sum(b[1,2..16]))
    st_numscalar("cumulative_se", sqrt(sum(V[|2,2 \ 16,16|])))
    st_numscalar("lag_1", b[1,2])
    st_numscalar("lag_1_se", sqrt(V[2,2]))
    st_numscalar("lag_15", b[1,16])
    st_numscalar("lag_15_se", sqrt(V[16,16]))
    st_numscalar("n_obs", N)
end

display "ANSWER: cumulative_response estimate=" %21.12f cumulative_response " se=" %21.12f cumulative_se " n_obs=" %12.0f n_obs
display "ANSWER: lag_1 estimate=" %21.12f lag_1 " se=" %21.12f lag_1_se " n_obs=" %12.0f n_obs
display "ANSWER: lag_15 estimate=" %21.12f lag_15 " se=" %21.12f lag_15_se " n_obs=" %12.0f n_obs
