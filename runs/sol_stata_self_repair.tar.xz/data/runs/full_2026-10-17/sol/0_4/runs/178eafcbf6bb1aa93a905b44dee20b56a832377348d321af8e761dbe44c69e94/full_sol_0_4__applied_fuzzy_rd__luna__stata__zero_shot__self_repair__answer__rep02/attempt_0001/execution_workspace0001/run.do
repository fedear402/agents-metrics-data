clear all
set more off
set linesize 255

import delimited "./input.csv", clear
keep if abs(score) < 1

mata:
    D = st_data(., ("score", "participated", "earnings"))
    s = D[,1]
    w = 1 :- abs(s)
    r = s :>= 0
    X = (J(rows(s), 1, 1), r, s, s :* r)
    Y = (D[,3], D[,2])

    Ainv = invsym(quadcross(X, w, X))
    B = Ainv * quadcross(X, w, Y)
    E = Y - X * B

    h = X * Ainv[,2]
    psi_y = w :* h :* E[,1]
    psi_d = w :* h :* E[,2]

    rf = B[2,1]
    fs = B[2,2]
    v_rf = quadcross(psi_y, psi_y)
    v_fs = quadcross(psi_d, psi_d)
    cov_rf_fs = quadcross(psi_y, psi_d)

    te = rf / fs
    v_te = v_rf / fs^2 + rf^2 * v_fs / fs^4 - 2 * rf * cov_rf_fs / fs^3

    st_numscalar("reduced_form", rf)
    st_numscalar("first_stage", fs)
    st_numscalar("treatment_effect", te)
    st_numscalar("se_reduced_form", sqrt(max((0, v_rf))))
    st_numscalar("se_first_stage", sqrt(max((0, v_fs))))
    st_numscalar("se_treatment_effect", sqrt(max((0, v_te))))
    st_numscalar("n_obs", rows(s))
end

display "ANSWER: treatment_effect estimate=" %21.12f treatment_effect " se=" %21.12f se_treatment_effect " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f reduced_form " se=" %21.12f se_reduced_form " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f first_stage " se=" %21.12f se_first_stage " n_obs=" %12.0f n_obs
