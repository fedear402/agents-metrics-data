version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear varnames(1)
generate double day = date(date, "YMD")
sort day
generate long observation = _n
tsset observation

generate double log_sales = log(sales)
generate double log_vix = log(vix)
generate double vix_change = D.log_vix

local regressors
forvalues k = 1/15 {
    generate double lag_`k' = L`k'.vix_change
    local regressors `regressors' lag_`k'
}

keep if !missing(log_sales)
foreach variable of local regressors {
    keep if !missing(`variable')
}

mata:
X = (J(st_nobs(), 1, 1), st_data(., tokens(st_local("regressors"))))
y = st_data(., "log_sales")
b = qrsolve(X, y)
N = rows(X)
p = cols(X)
scores = X :* (y - X*b)

meat = scores' * scores
for (j = 1; j <= 15; j++) {
    lag_product = scores[|j+1,1 \ N,p|]' * scores[|1,1 \ N-j,p|]
    meat = meat + (1 - j/16) * (lag_product + lag_product')
}
bread = invsym(X' * X)
V = (N/(N-p)) * bread * meat * bread

c = (0 \ J(15, 1, 1))
cumulative_est = c' * b
cumulative_var = c' * V * c
st_numscalar("cumulative_est", cumulative_est[1,1])
st_numscalar("cumulative_se", sqrt(cumulative_var[1,1]))
st_numscalar("lag1_est", b[2])
st_numscalar("lag1_se", sqrt(V[2,2]))
st_numscalar("lag15_est", b[16])
st_numscalar("lag15_se", sqrt(V[16,16]))
st_numscalar("sample_n", N)
end

display "ANSWER: cumulative_response estimate=" %21.12f scalar(cumulative_est) " se=" %21.12f scalar(cumulative_se) " n_obs=" %12.0f scalar(sample_n)
display "ANSWER: lag_1 estimate=" %21.12f scalar(lag1_est) " se=" %21.12f scalar(lag1_se) " n_obs=" %12.0f scalar(sample_n)
display "ANSWER: lag_15 estimate=" %21.12f scalar(lag15_est) " se=" %21.12f scalar(lag15_se) " n_obs=" %12.0f scalar(sample_n)
