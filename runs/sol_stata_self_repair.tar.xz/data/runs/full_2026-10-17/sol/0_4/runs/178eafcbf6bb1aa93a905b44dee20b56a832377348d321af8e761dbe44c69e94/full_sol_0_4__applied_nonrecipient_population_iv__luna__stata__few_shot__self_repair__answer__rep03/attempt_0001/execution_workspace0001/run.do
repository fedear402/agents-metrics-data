clear all
set more off
set type double

import delimited "households.csv", clear varnames(1)
keep if recipient == 0
local n_obs = _N

generate double ineligible = 1 - eligible
generate double dose0 = dose * ineligible
generate double dose1 = dose * eligible
generate double baseline0 = baseline * ineligible
generate double baseline1 = baseline * eligible
generate double instrument0 = instrument * ineligible
generate double instrument1 = instrument * eligible

quietly ivregress 2sls outcome ineligible eligible baseline0 baseline1 ///
    (dose0 dose1 = instrument0 instrument1) [aw=weight], noconstant

scalar slope0 = _b[dose0]
scalar slope1 = _b[dose1]

quietly summarize dose [aw=weight] if eligible == 0, meanonly
scalar ineligible_effect = slope0 * r(mean)

quietly summarize dose [aw=weight] if eligible == 1, meanonly
scalar eligible_nonrecipient_effect = slope1 * r(mean)

import delimited "census.csv", clear varnames(1)
collapse (sum) nonrecipient_population, by(eligible)

quietly summarize nonrecipient_population if eligible == 0, meanonly
scalar population0 = r(mean)

quietly summarize nonrecipient_population if eligible == 1, meanonly
scalar population1 = r(mean)

scalar population_effect = ///
    (population0 * ineligible_effect + ///
     population1 * eligible_nonrecipient_effect) / ///
    (population0 + population1)

display "ANSWER: ineligible_effect estimate=" ///
    %24.16g (ineligible_effect) " se=NA n_obs=" `n_obs'
display "ANSWER: eligible_nonrecipient_effect estimate=" ///
    %24.16g (eligible_nonrecipient_effect) " se=NA n_obs=" `n_obs'
display "ANSWER: population_effect estimate=" ///
    %24.16g (population_effect) " se=NA n_obs=" `n_obs'
