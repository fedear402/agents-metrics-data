version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear
generate double day = daily(date, "YMD")
sort day
generate long observation = _n
tsset observation

generate double log_sales = ln(sales)
generate double log_vix = ln(vix)
generate double vix_change = D.log_vix
forvalues j = 1/15 {
    generate double change_lag`j' = L`j'.vix_change
}

local regressors
forvalues j = 1/15 {
    local regressors `regressors' change_lag`j'
}
keep if !missing(log_sales, `regressors')

mata:
N = st_nobs()
X = J(N, 1, 1), st_data(., tokens(st_local("regressors")))
y = st_data(., "log_sales")
b = qrsolve(X, y)
u = y - X*b
scores = X :* u
p = cols(X)

meat = scores'*scores
for (j = 1; j <= 15; j++) {
    cross = scores[|j+1,1 \ N,p|]' * scores[|1,1 \ N-j,p|]
    meat = meat + (1-j/16)*(cross+cross')
}
bread = invsym(X'*X)
V = (N/(N-p))*bread*meat*bread

contrast = (0 \ J(15,1,1))
st_numscalar("cumulative_est", (contrast'*b)[1,1])
st_numscalar("cumulative_se", sqrt((contrast'*V*contrast)[1,1]))
st_numscalar("lag1_est", b[2])
st_numscalar("lag1_se", sqrt(V[2,2]))
st_numscalar("lag15_est", b[16])
st_numscalar("lag15_se", sqrt(V[16,16]))
st_numscalar("n_obs", N)
end

display "ANSWER: cumulative_response estimate=" %21.12f scalar(cumulative_est) " se=" %21.12f scalar(cumulative_se) " n_obs=" %12.0f scalar(n_obs)
display "ANSWER: lag_1 estimate=" %21.12f scalar(lag1_est) " se=" %21.12f scalar(lag1_se) " n_obs=" %12.0f scalar(n_obs)
display "ANSWER: lag_15 estimate=" %21.12f scalar(lag15_est) " se=" %21.12f scalar(lag15_se) " n_obs=" %12.0f scalar(n_obs)
