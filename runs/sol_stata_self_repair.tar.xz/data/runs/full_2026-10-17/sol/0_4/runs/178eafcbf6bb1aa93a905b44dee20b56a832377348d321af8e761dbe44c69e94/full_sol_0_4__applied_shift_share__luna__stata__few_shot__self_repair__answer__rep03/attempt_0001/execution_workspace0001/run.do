version 19.0
clear all
set more off
set linesize 255

import delimited "./input.csv", clear

isid region_id industry_id
bysort region_id: assert region_weight == region_weight[1]
bysort region_id: assert x == x[1]
bysort region_id: assert y == y[1]
bysort industry_id: assert shock == shock[1]

bysort region_id: generate byte region_once = (_n == 1)
quietly summarize region_weight if region_once, meanonly
scalar total_weight = r(sum)
assert total_weight > 0
generate double e = region_weight / total_weight

bysort region_id: egen double z = total(share * shock)

quietly summarize y [aw=e] if region_once, meanonly
scalar mean_y = r(mean)
quietly summarize x [aw=e] if region_once, meanonly
scalar mean_x = r(mean)
quietly summarize z [aw=e] if region_once, meanonly
scalar mean_z = r(mean)

generate double y0 = y - mean_y
generate double x0 = x - mean_x
generate double z0 = z - mean_z

generate double exposure = e * share
generate double ey = exposure * y0
generate double ex = exposure * x0
generate double ez = exposure * z0

collapse (sum) s=exposure sum_y=ey sum_x=ex sum_z=ez ///
    (first) shock, by(industry_id)

assert s > 0
generate double ybar = sum_y / s
generate double xbar = sum_x / s
generate double zbar = sum_z / s

mata:
    S = st_data(., "s")
    G = st_data(., "shock")
    Y = st_data(., "ybar")
    X = st_data(., "xbar")
    Z = st_data(., "zbar")
    N = rows(S)

    if (N <= 2) _error(3498)

    H = (J(N,1,1), G)
    R = (J(N,1,1), X)
    Q = (J(N,1,1), Z)

    A = luinv(H' * (S :* R))
    B = A * H' * (S :* Y)
    U = Y - R * B
    C = H :* (S :* U)
    V = (N/(N-2)) * A * (C' * C) * A'

    A1 = luinv(H' * (S :* Q))
    B1 = A1 * H' * (S :* X)
    U1 = X - Q * B1
    C1 = H :* (S :* U1)
    V1 = (N/(N-2)) * A1 * (C1' * C1) * A1'

    st_numscalar("effect", B[2])
    st_numscalar("effect_se", sqrt(V[2,2]))
    st_numscalar("first_stage", B1[2])
    st_numscalar("first_stage_se", sqrt(V1[2,2]))
    st_numscalar("effective_shocks", 1/sum(S:^2))
    st_numscalar("industry_count", N)
end

display "ANSWER: effect estimate=" %21.12f effect ///
    " se=" %21.12f effect_se " n_obs=" %12.0f industry_count
display "ANSWER: first_stage estimate=" %21.12f first_stage ///
    " se=" %21.12f first_stage_se " n_obs=" %12.0f industry_count
display "ANSWER: effective_shocks estimate=" %21.12f effective_shocks ///
    " se=. n_obs=" %12.0f industry_count
