clear all
set more off
set linesize 255
set type double

import delimited using "./input.csv", clear
local n = _N
assert `n' == 240
local q = 2
local df = `n' - 4

quietly regress y x
predict double ry, residuals
quietly regress endog x
predict double rd, residuals

quietly regress y x z1 z2
predict double uy, residuals
quietly regress endog x z1 z2
predict double ud, residuals

scalar critical = invFtail(`q', `df', .05)
scalar k = `q' * critical / `df'

mata:
    ry = st_data(., "ry")
    rd = st_data(., "rd")
    uy = st_data(., "uy")
    ud = st_data(., "ud")
    k = st_numscalar("k")

    A = quadcross(rd, rd) - (1+k)*quadcross(ud, ud)
    B = -2*(quadcross(ry, rd) - (1+k)*quadcross(uy, ud))
    C = quadcross(ry, ry) - (1+k)*quadcross(uy, uy))

    discriminant = B^2 - 4*A*C
    assert(A != 0 & discriminant > 0)
    roots = sort(((-B-sqrt(discriminant))/(2*A) \ ///
                  (-B+sqrt(discriminant))/(2*A)), 1)

    restricted_at_one = quadcross(ry-rd, ry-rd)
    unrestricted_at_one = quadcross(uy-ud, uy-ud)

    st_numscalar("boundary_low", roots[1])
    st_numscalar("boundary_high", roots[2])
    st_numscalar("accepts_zero", C <= 0)
    st_numscalar("unbounded", A < 0)
    st_numscalar("ar_f_at_one", ///
        ((restricted_at_one-unrestricted_at_one)/2) / ///
        (unrestricted_at_one/st_numscalar("df_scalar")))
end

display "ANSWER: boundary_low estimate=" %21.15g (boundary_low) " se=. n_obs=" %12.0f (`n')
display "ANSWER: boundary_high estimate=" %21.15g (boundary_high) " se=. n_obs=" %12.0f (`n')
display "ANSWER: accepts_zero estimate=" %21.15g (accepts_zero) " se=. n_obs=" %12.0f (`n')
display "ANSWER: unbounded estimate=" %21.15g (unbounded) " se=. n_obs=" %12.0f (`n')
display "ANSWER: ar_f_at_one estimate=" %21.15g (ar_f_at_one) " se=. n_obs=" %12.0f (`n')
