clear all
set more off
set linesize 255

import delimited "./input.csv", clear
sort t
tsset t

arima y, arima(1,1,1) noconstant
scalar n_obs = e(N)

tsappend, add(1)
predict double y_forecast, y dynamic(251)
predict double forecast_mse, mse dynamic(251)

scalar forecast = y_forecast[_N]
scalar forecast_se = sqrt(forecast_mse[_N])
scalar lower_95 = forecast - invnormal(.975)*forecast_se
scalar upper_95 = forecast + invnormal(.975)*forecast_se

display "ANSWER: forecast estimate=" %21.12f forecast " se=" %21.12f forecast_se " n_obs=" %12.0f n_obs
display "ANSWER: lower_95 estimate=" %21.12f lower_95 " se=. n_obs=" %12.0f n_obs
display "ANSWER: upper_95 estimate=" %21.12f upper_95 " se=. n_obs=" %12.0f n_obs
