clear all
set more off

tempfile crosswalk trade employment national exposures

import delimited "crosswalk.csv", clear varnames(1)
save `crosswalk'

import delimited "trade.csv", clear varnames(1)
merge m:1 code using `crosswalk', assert(match) nogen
save `trade'

import delimited "employment.csv", clear varnames(1)
save `employment'
collapse (sum) national_employment=employment, by(period vintage industry)
save `national'

import delimited "areas.csv", clear varnames(1)
joinby period using `trade'
merge m:1 area period vintage industry using `employment', nogen
replace employment = 0 if missing(employment)
merge m:1 period vintage industry using `national', assert(match) nogen

generate double contribution = ///
    (employment / total_employment) * ///
    (cond(vintage == "base", us_change, other_change) / national_employment) / ///
    (price_index / 100) / 1000 * (10 / years)

generate double x_part = cond(vintage == "base", contribution, 0)
generate double z_part = cond(vintage == "early", contribution, 0)
generate double reg_weight = population if vintage == "base"

collapse (sum) x=x_part z=z_part reg_weight, by(area period)
save `exposures'

import delimited "outcomes.csv", clear varnames(1)
merge 1:1 area period using `exposures', assert(match) nogen

quietly summarize x if area == 0 & period == 0, meanonly
scalar exposure_area0_period0 = r(mean)
quietly summarize x if area == 0 & period == 1, meanonly
scalar exposure_area0_period1 = r(mean)
quietly summarize z if area == 0 & period == 0, meanonly
scalar instrument_area0_period0 = r(mean)

quietly ivregress 2sls change_pp period control (x = z) [aw=reg_weight]
scalar iv_slope = _b[x]

display "ANSWER: iv_slope estimate=" %24.15g iv_slope " se=NA n_obs=72"
display "ANSWER: exposure_area0_period0 estimate=" %24.15g exposure_area0_period0 " se=NA n_obs=72"
display "ANSWER: exposure_area0_period1 estimate=" %24.15g exposure_area0_period1 " se=NA n_obs=72"
display "ANSWER: instrument_area0_period0 estimate=" %24.15g instrument_area0_period0 " se=NA n_obs=72"
