version 19.0
clear all
set more off
set linesize 255

import delimited "./input.csv", clear
egen long region_index = group(region_id)
egen long industry_index = group(industry_id)

mata:
region = st_data(., "region_index")
industry = st_data(., "industry_index")
share = st_data(., "share")
industry_shock = st_data(., "shock")
region_weight = st_data(., "region_weight")
x = st_data(., "x")
y = st_data(., "y")

R = max(region)
N = max(industry)
S = J(R, N, 0)
g = J(N, 1, .)
w = J(R, 1, .)
xr = J(R, 1, .)
yr = J(R, 1, .)

for (i = 1; i <= rows(region); i++) {
    r = region[i]
    n = industry[i]
    S[r,n] = share[i]
    g[n] = industry_shock[i]
    w[r] = region_weight[i]
    xr[r] = x[i]
    yr[r] = y[i]
}

e = w / sum(w)
z = S*g
regional = (yr, xr, z)
centered = regional :- J(R,1,1)*(e'*regional)

mass = S'*e
aggregated = (S'*(e:*centered)) :/ mass
instruments = (J(N,1,1), g)

estimates = J(2,2,.)
for (equation = 1; equation <= 2; equation++) {
    dependent = aggregated[,equation]
    endogenous = aggregated[,equation+1]
    regressors = (J(N,1,1), endogenous)

    cross = instruments'*(mass:*regressors)
    inverse = luinv(cross)
    beta = inverse*instruments'*(mass:*dependent)
    residual = dependent - regressors*beta
    scores = instruments:*(mass:*residual)
    covariance = (N/(N-2))*inverse*(scores'*scores)*inverse'

    estimates[equation,] = (beta[2], sqrt(covariance[2,2]))
}

st_numscalar("effect_estimate", estimates[1,1])
st_numscalar("effect_se", estimates[1,2])
st_numscalar("first_stage_estimate", estimates[2,1])
st_numscalar("first_stage_se", estimates[2,2])
st_numscalar("effective_shocks_estimate", 1/sum(mass:^2))
st_numscalar("industry_count", N)
end

display "ANSWER: effect estimate=" %21.12f effect_estimate " se=" %21.12f effect_se " n_obs=" %12.0f industry_count
display "ANSWER: first_stage estimate=" %21.12f first_stage_estimate " se=" %21.12f first_stage_se " n_obs=" %12.0f industry_count
display "ANSWER: effective_shocks estimate=" %21.12f effective_shocks_estimate " se=. n_obs=" %12.0f industry_count
