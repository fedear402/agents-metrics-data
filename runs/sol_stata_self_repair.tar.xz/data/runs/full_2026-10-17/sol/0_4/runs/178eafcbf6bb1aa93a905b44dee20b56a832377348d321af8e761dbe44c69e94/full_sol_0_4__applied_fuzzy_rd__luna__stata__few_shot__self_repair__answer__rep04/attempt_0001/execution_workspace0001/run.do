version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

mata:
score = st_data(., "score")
Y = st_data(., ("earnings", "participated"))
keep = abs(score) :< 1
score = select(score, keep)
Y = select(Y, keep)

n = rows(score)
right = score :>= 0
w = 1 :- abs(score)
X = (J(n, 1, 1), right, score, right :* score)
contrast = (0 \ 1 \ 0 \ 0)

bread = invsym(X' * (w :* X))
beta = bread * X' * (w :* Y)
residuals = Y - X * beta
jumps = contrast' * beta

loading = w :* (X * bread * contrast)
influence = loading :* residuals
joint = influence' * influence

reduced_form = jumps[1]
first_stage = jumps[2]
if (first_stage != 0) {
    treatment_effect = reduced_form / first_stage
    gradient = (1 / first_stage \ -reduced_form / first_stage^2)
    treatment_se = sqrt(gradient' * joint * gradient)
}
else {
    treatment_effect = .
    treatment_se = .
}

st_numscalar("rd_n", n)
st_numscalar("rd_rf", reduced_form)
st_numscalar("rd_rf_se", sqrt(joint[1,1]))
st_numscalar("rd_fs", first_stage)
st_numscalar("rd_fs_se", sqrt(joint[2,2]))
st_numscalar("rd_te", treatment_effect)
st_numscalar("rd_te_se", treatment_se)
end

display "ANSWER: treatment_effect estimate=" %21.12f rd_te " se=" %21.12f rd_te_se " n_obs=" %12.0f rd_n
display "ANSWER: reduced_form estimate=" %21.12f rd_rf " se=" %21.12f rd_rf_se " n_obs=" %12.0f rd_n
display "ANSWER: first_stage estimate=" %21.12f rd_fs " se=" %21.12f rd_fs_se " n_obs=" %12.0f rd_n
