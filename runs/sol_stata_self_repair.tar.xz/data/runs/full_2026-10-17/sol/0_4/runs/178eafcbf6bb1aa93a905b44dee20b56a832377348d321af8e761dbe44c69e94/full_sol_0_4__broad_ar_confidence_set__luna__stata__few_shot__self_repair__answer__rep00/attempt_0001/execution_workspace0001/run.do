clear all
set more off
set linesize 255
set type double

import delimited using "./input.csv", clear
local n = _N

quietly regress y x
predict double ry, residuals
quietly regress endog x
predict double rd, residuals

quietly regress y x z1 z2
predict double uy, residuals
quietly regress endog x z1 z2
predict double ud, residuals

scalar df = `n' - 4
scalar critical = invFtail(2, df, .05)
scalar k = 2 * critical / df

mata:
    ry = st_data(., "ry")
    rd = st_data(., "rd")
    uy = st_data(., "uy")
    ud = st_data(., "ud")
    k = st_numscalar("k")

    A = quadcross(rd, rd) - (1+k)*quadcross(ud, ud)
    B = -2*(quadcross(ry, rd) - (1+k)*quadcross(uy, ud))
    C = quadcross(ry, ry) - (1+k)*quadcross(uy, uy))
end
