version 19.0
clear all
set more off
set linesize 255

import delimited "./input.csv", clear
keep if !missing(score, participated, earnings) & abs(score) < 1

generate double right = score >= 0
generate double score_left = score * (1 - right)
generate double score_right = score * right
generate double weight = 1 - abs(score)
count
scalar n_obs = r(N)

mata:
    X = st_data(., ("right", "score_left", "score_right"))
    X = (J(rows(X), 1, 1), X)
    Y = st_data(., ("earnings", "participated"))
    w = st_data(., "weight")

    bread = invsym(X' * (w :* X))
    coefficients = bread * X' * (w :* Y)
    residuals = Y - X * coefficients

    contrast = (0 \ 1 \ 0 \ 0)
    jumps = contrast' * coefficients
    loading = w :* (X * bread * contrast)
    influence = loading :* residuals
    joint = influence' * influence

    gradient = (1 / jumps[2] \ -jumps[1] / jumps[2]^2)
    treatment_effect = jumps[1] / jumps[2]
    treatment_se = sqrt(gradient' * joint * gradient)

    st_numscalar("reduced_form", jumps[1])
    st_numscalar("reduced_form_se", sqrt(joint[1,1]))
    st_numscalar("first_stage", jumps[2])
    st_numscalar("first_stage_se", sqrt(joint[2,2]))
    st_numscalar("treatment_effect", treatment_effect)
    st_numscalar("treatment_effect_se", treatment_se)
end

display "ANSWER: treatment_effect estimate=" %21.12f treatment_effect " se=" %21.12f treatment_effect_se " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f reduced_form " se=" %21.12f reduced_form_se " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f first_stage " se=" %21.12f first_stage_se " n_obs=" %12.0f n_obs
