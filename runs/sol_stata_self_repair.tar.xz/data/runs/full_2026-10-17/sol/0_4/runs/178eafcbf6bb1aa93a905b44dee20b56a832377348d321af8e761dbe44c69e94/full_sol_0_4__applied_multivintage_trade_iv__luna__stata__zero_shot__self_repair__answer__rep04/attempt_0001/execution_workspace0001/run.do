clear all
set more off

tempfile trade_industry industries national cells

import delimited "crosswalk.csv", clear
isid code
tempfile crosswalk
save `crosswalk'

keep industry
duplicates drop
save `industries'

import delimited "trade.csv", clear
merge m:1 code using `crosswalk', assert(match) nogen
isid period industry
save `trade_industry'

import delimited "areas.csv", clear
isid area period vintage
cross using `industries'
merge 1:1 area period vintage industry using "employment.csv", ///
    keep(master match) nogen
replace employment = 0 if missing(employment)
save `cells'

preserve
collapse (sum) national_employment=employment, by(period vintage industry)
assert national_employment > 0
save `national'
restore

merge m:1 period vintage industry using `national', assert(match) nogen
merge m:1 period industry using `trade_industry', assert(match) nogen

generate double exposure = ///
    (employment / total_employment) * ///
    (cond(vintage == "base", us_change, other_change) / national_employment) / ///
    (price_index / 100) / 1000 * (10 / years)

collapse (sum) exposure (max) population, by(area period vintage)
reshape wide exposure population, i(area period) j(vintage) string

merge 1:1 area period using "outcomes.csv", assert(match) nogen
assert _N == 72

quietly summarize exposurebase if area == 0 & period == 0, meanonly
scalar x00 = r(mean)
quietly summarize exposurebase if area == 0 & period == 1, meanonly
scalar x01 = r(mean)
quietly summarize exposureearly if area == 0 & period == 0, meanonly
scalar z00 = r(mean)

ivregress 2sls change_pp period control ///
    (exposurebase = exposureearly) [aweight = populationbase]
assert e(N) == 72
scalar slope = _b[exposurebase]

display "ANSWER: iv_slope estimate=" ///
    strtrim(string(slope, "%24.15g")) " se=NA n_obs=72"
display "ANSWER: exposure_area0_period0 estimate=" ///
    strtrim(string(x00, "%24.15g")) " se=NA n_obs=72"
display "ANSWER: exposure_area0_period1 estimate=" ///
    strtrim(string(x01, "%24.15g")) " se=NA n_obs=72"
display "ANSWER: instrument_area0_period0 estimate=" ///
    strtrim(string(z00, "%24.15g")) " se=NA n_obs=72"
