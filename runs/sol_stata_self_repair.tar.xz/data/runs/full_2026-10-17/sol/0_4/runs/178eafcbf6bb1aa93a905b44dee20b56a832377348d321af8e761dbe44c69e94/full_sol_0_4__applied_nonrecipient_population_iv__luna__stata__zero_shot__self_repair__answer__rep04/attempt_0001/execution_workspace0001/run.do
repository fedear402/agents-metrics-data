clear all
set more off

import delimited "households.csv", clear varnames(1)
keep if recipient == 0

generate byte ineligible = 1 - eligible
generate double dose_ineligible = dose * ineligible
generate double dose_eligible = dose * eligible
generate double baseline_ineligible = baseline * ineligible
generate double baseline_eligible = baseline * eligible
generate double instrument_ineligible = instrument * ineligible
generate double instrument_eligible = instrument * eligible

ivregress 2sls outcome ///
    ineligible eligible baseline_ineligible baseline_eligible ///
    (dose_ineligible dose_eligible = instrument_ineligible instrument_eligible) ///
    [aweight=weight], noconstant

local n_obs = e(N)
scalar slope_ineligible = _b[dose_ineligible]
scalar slope_eligible = _b[dose_eligible]

quietly summarize dose [aweight=weight] if eligible == 0, meanonly
scalar ineligible_effect = slope_ineligible * r(mean)

quietly summarize dose [aweight=weight] if eligible == 1, meanonly
scalar eligible_nonrecipient_effect = slope_eligible * r(mean)

import delimited "census.csv", clear varnames(1)

quietly egen double population_ineligible = total(cond(eligible == 0, nonrecipient_population, 0))
quietly egen double population_eligible = total(cond(eligible == 1, nonrecipient_population, 0))

scalar population_effect = ///
    (population_ineligible[1] * ineligible_effect + ///
     population_eligible[1] * eligible_nonrecipient_effect) / ///
    (population_ineligible[1] + population_eligible[1])

display "ANSWER: ineligible_effect estimate=" ///
    %21.16g scalar(ineligible_effect) " se=NA n_obs=`n_obs'"
display "ANSWER: eligible_nonrecipient_effect estimate=" ///
    %21.16g scalar(eligible_nonrecipient_effect) " se=NA n_obs=`n_obs'"
display "ANSWER: population_effect estimate=" ///
    %21.16g scalar(population_effect) " se=NA n_obs=`n_obs'"
