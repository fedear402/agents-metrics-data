clear all
set more off

import delimited "census.csv", clear varnames(1)
quietly summarize nonrecipient_population if eligible == 0, meanonly
scalar pop0 = r(sum)
quietly summarize nonrecipient_population if eligible == 1, meanonly
scalar pop1 = r(sum)

import delimited "households.csv", clear varnames(1)
keep if recipient == 0

generate double g0 = 1 - eligible
generate double g1 = eligible
generate double b0 = baseline * g0
generate double b1 = baseline * g1
generate double d0 = dose * g0
generate double d1 = dose * g1
generate double z0 = instrument * g0
generate double z1 = instrument * g1

quietly ivregress 2sls outcome g0 g1 b0 b1 ///
    (d0 d1 = z0 z1) [aweight=weight], noconstant
scalar n = e(N)
generate byte estimation_sample = e(sample)

quietly summarize dose [aweight=weight] if estimation_sample & eligible == 0, meanonly
scalar effect0 = _b[d0] * r(mean)

quietly summarize dose [aweight=weight] if estimation_sample & eligible == 1, meanonly
scalar effect1 = _b[d1] * r(mean)

scalar population_effect = (pop0 * effect0 + pop1 * effect1) / (pop0 + pop1)

display "ANSWER: ineligible_effect estimate=" strtrim(strofreal(effect0, "%21.14g")) ///
    " se=NA n_obs=" strtrim(strofreal(n, "%20.0f"))
display "ANSWER: eligible_nonrecipient_effect estimate=" strtrim(strofreal(effect1, "%21.14g")) ///
    " se=NA n_obs=" strtrim(strofreal(n, "%20.0f"))
display "ANSWER: population_effect estimate=" strtrim(strofreal(population_effect, "%21.14g")) ///
    " se=NA n_obs=" strtrim(strofreal(n, "%20.0f"))
