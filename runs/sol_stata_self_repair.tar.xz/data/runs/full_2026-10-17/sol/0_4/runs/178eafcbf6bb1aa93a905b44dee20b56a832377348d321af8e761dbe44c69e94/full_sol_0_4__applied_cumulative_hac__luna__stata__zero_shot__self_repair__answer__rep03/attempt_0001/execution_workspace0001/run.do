set linesize 255
import delimited "./input.csv", clear
sort date

generate double ln_sales = ln(sales)
generate double ln_vix = ln(vix)
generate double dln_vix = ln_vix - ln_vix[_n-1]

local lagvars
forvalues l = 1/15 {
    generate double dvix_l`l' = dln_vix[_n-`l']
    local lagvars `lagvars' dvix_l`l'
}

quietly regress ln_sales `lagvars'
generate byte regsample = e(sample)
scalar n_obs = e(N)

mata:
    X = J(st_numscalar("n_obs"), 1, 1), st_data(., tokens(st_local("lagvars")), "regsample")
    y = st_data(., "ln_sales", "regsample")
    b = st_matrix("e(b)")'
    u = y - X*b
    N = rows(X)
    Z = X :* (u * J(1, cols(X), 1))
    S = quadcross(Z, Z)

    for (j=1; j<=15; j++) {
        G = quadcross(Z[(j+1)..N, .], Z[1..(N-j), .])
        S = S + (1-j/16)*(G+G')
    }

    Qinv = invsym(quadcross(X, X))
    V = (N/(N-16))*Qinv*S*Qinv
    c = (0, J(1, 15, 1))'
    st_numscalar("se_cumulative", sqrt(c'*V*c))
    st_numscalar("se_lag_1", sqrt(V[2,2]))
    st_numscalar("se_lag_15", sqrt(V[16,16]))
end

scalar cumulative_response = 0
forvalues l = 1/15 {
    scalar cumulative_response = cumulative_response + _b[dvix_l`l']
}

display "ANSWER: cumulative_response estimate=" %21.12f cumulative_response " se=" %21.12f se_cumulative " n_obs=" %12.0f n_obs
display "ANSWER: lag_1 estimate=" %21.12f _b[dvix_l1] " se=" %21.12f se_lag_1 " n_obs=" %12.0f n_obs
display "ANSWER: lag_15 estimate=" %21.12f _b[dvix_l15] " se=" %21.12f se_lag_15 " n_obs=" %12.0f n_obs
