clear all
set more off
set linesize 255

import delimited using "./input.csv", clear
keep if abs(score) < 1

generate double weight = 1 - abs(score)
generate double right = score >= 0
generate double left_slope = score * (1 - right)
generate double right_slope = score * right

mata:
    X = st_data(., ("right", "left_slope", "right_slope"))
    X = (J(rows(X), 1, 1), X)
    w = st_data(., "weight")
    Y = st_data(., ("earnings", "participated"))

    Ainv = invsym(quadcross(X, w, X))
    B = Ainv * quadcross(X, w, Y)
    U = Y - X * B

    Vyy = Ainv * quadcross(X, (w:^2) :* (U[,1]:^2), X) * Ainv
    Vdd = Ainv * quadcross(X, (w:^2) :* (U[,2]:^2), X) * Ainv
    Vyd = Ainv * quadcross(X, (w:^2) :* (U[,1]:*U[,2]), X) * Ainv

    rf = B[2,1]
    fs = B[2,2]
    te = rf / fs
    var_te = Vyy[2,2]/(fs^2) + (rf^2)*Vdd[2,2]/(fs^4) - 2*rf*Vyd[2,2]/(fs^3)

    st_numscalar("reduced_form", rf)
    st_numscalar("first_stage", fs)
    st_numscalar("treatment_effect", te)
    st_numscalar("se_reduced_form", sqrt(Vyy[2,2]))
    st_numscalar("se_first_stage", sqrt(Vdd[2,2]))
    st_numscalar("se_treatment_effect", sqrt(var_te))
    st_numscalar("n_obs", rows(X))
end

display "ANSWER: treatment_effect estimate=" %21.12f treatment_effect " se=" %21.12f se_treatment_effect " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f reduced_form " se=" %21.12f se_reduced_form " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f first_stage " se=" %21.12f se_first_stage " n_obs=" %12.0f n_obs
