clear all
set more off

import delimited "households.csv", clear

keep if recipient == 0

generate double ineligible = 1 - eligible
generate double dose_ineligible = dose * ineligible
generate double dose_eligible = dose * eligible
generate double baseline_ineligible = baseline * ineligible
generate double baseline_eligible = baseline * eligible
generate double instrument_ineligible = instrument * ineligible
generate double instrument_eligible = instrument * eligible

quietly ivregress 2sls outcome ///
    ineligible eligible baseline_ineligible baseline_eligible ///
    (dose_ineligible dose_eligible = instrument_ineligible instrument_eligible) ///
    [aweight=weight], noconstant

scalar n_obs = e(N)
scalar slope_ineligible = _b[dose_ineligible]
scalar slope_eligible = _b[dose_eligible]
generate byte estimation_sample = e(sample)

quietly summarize dose [aweight=weight] if estimation_sample & eligible == 0, meanonly
scalar ineligible_effect = slope_ineligible * r(mean)

quietly summarize dose [aweight=weight] if estimation_sample & eligible == 1, meanonly
scalar eligible_nonrecipient_effect = slope_eligible * r(mean)

import delimited "census.csv", clear

quietly summarize nonrecipient_population if eligible == 0, meanonly
scalar population_ineligible = r(sum)

quietly summarize nonrecipient_population if eligible == 1, meanonly
scalar population_eligible = r(sum)

scalar population_effect = ///
    (population_ineligible * ineligible_effect + ///
     population_eligible * eligible_nonrecipient_effect) / ///
    (population_ineligible + population_eligible)

display "ANSWER: ineligible_effect estimate=" %22.15g ineligible_effect ///
    " se=NA n_obs=" %12.0f n_obs
display "ANSWER: eligible_nonrecipient_effect estimate=" %22.15g eligible_nonrecipient_effect ///
    " se=NA n_obs=" %12.0f n_obs
display "ANSWER: population_effect estimate=" %22.15g population_effect ///
    " se=NA n_obs=" %12.0f n_obs
