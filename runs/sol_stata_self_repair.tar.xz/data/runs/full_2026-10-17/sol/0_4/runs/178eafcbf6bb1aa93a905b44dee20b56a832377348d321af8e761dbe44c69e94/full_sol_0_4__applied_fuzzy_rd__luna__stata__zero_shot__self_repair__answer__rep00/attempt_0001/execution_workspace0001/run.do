clear all
set more off
set linesize 255

import delimited "./input.csv", clear
keep if !missing(score, participated, earnings) & abs(score) < 1

generate double weight = 1 - abs(score)
generate byte right = score >= 0
generate double right_score = right * score
quietly count
scalar n_obs = r(N)

mata:
    x = st_data(., ("score", "right", "right_score"))
    X = (J(rows(x), 1, 1), x)
    w = st_data(., "weight")
    y = st_data(., "earnings")
    p = st_data(., "participated")

    bread = invsym(X' * (X :* w))
    by = bread * (X' * (y :* w))
    bp = bread * (X' * (p :* w))
    ey = y - X * by
    ep = p - X * bp

    sy = X :* (w :* ey)
    sp = X :* (w :* ep)
    vyy = bread * (sy' * sy) * bread
    vpp = bread * (sp' * sp) * bread
    vyp = bread * (sy' * sp) * bread

    rf = by[3]
    fs = bp[3]
    st_numscalar("reduced_form", rf)
    st_numscalar("first_stage", fs)
    st_numscalar("reduced_form_se", sqrt(vyy[3, 3]))
    st_numscalar("first_stage_se", sqrt(vpp[3, 3]))

    if (fs != 0) {
        st_numscalar("treatment_effect", rf / fs)
        vte = vyy[3, 3] / fs^2 + rf^2 * vpp[3, 3] / fs^4 - 2 * rf * vyp[3, 3] / fs^3
        st_numscalar("treatment_effect_se", sqrt(max((0, vte))))
    }
    else {
        st_numscalar("treatment_effect", .)
        st_numscalar("treatment_effect_se", .)
    }
end

display "ANSWER: treatment_effect estimate=" %21.12f treatment_effect " se=" %21.12f treatment_effect_se " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f reduced_form " se=" %21.12f reduced_form_se " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f first_stage " se=" %21.12f first_stage_se " n_obs=" %12.0f n_obs
