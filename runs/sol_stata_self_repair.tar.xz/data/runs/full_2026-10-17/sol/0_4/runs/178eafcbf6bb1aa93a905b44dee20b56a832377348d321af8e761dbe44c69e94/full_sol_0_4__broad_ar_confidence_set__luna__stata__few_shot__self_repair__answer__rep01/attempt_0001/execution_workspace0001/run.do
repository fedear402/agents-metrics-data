clear all
set more off
set linesize 255
set type double

import delimited using "./input.csv", clear
quietly count
scalar n = r(N)

* Restricted residuals after projecting on the intercept and x.
quietly regress y x
predict double ry, residuals
quietly regress endog x
predict double rd, residuals

* Unrestricted residuals after adding both excluded instruments.
quietly regress y x z1 z2
predict double uy, residuals
quietly regress endog x z1 z2
predict double ud, residuals

scalar df = n - 4
scalar critical = invFtail(2, df, 0.05)
scalar k = 2 * critical / df

mata:
    ry = st_data(., "ry")
    rd = st_data(., "rd")
    uy = st_data(., "uy")
    ud = st_data(., "ud")
    k = st_numscalar("k")
    df = st_numscalar("df")

    rr0 = quadcross(ry, ry)
    rr1 = quadcross(ry, rd)
    rr2 = quadcross(rd, rd)
    uu0 = quadcross(uy, uy)
    uu1 = quadcross(uy, ud)
    uu2 = quadcross(ud, ud)

    A = rr2 - (1+k)*uu2
    B = -2*(rr1 - (1+k)*uu1)
    C = rr0 - (1+k)*uu0
    roots = sort(((-B-sqrt(B^2-4*A*C))/(2*A) \ ///
                  (-B+sqrt(B^2-4*A*C))/(2*A)), 1)

    ssr_r_one = rr0 - 2*rr1 + rr2
    ssr_u_one = uu0 - 2*uu1 + uu2
    f_one = ((ssr_r_one-ssr_u_one)/2)/(ssr_u_one/df)

    st_numscalar("boundary_low", roots[1])
    st_numscalar("boundary_high", roots[2])
    st_numscalar("accepts_zero", C<=0)
    st_numscalar("unbounded", A<0)
    st_numscalar("ar_f_at_one", f_one)
end

display "ANSWER: boundary_low estimate=" %21.15g (boundary_low) " se=. n_obs=" %12.0f (n)
display "ANSWER: boundary_high estimate=" %21.15g (boundary_high) " se=. n_obs=" %12.0f (n)
display "ANSWER: accepts_zero estimate=" %21.15g (accepts_zero) " se=. n_obs=" %12.0f (n)
display "ANSWER: unbounded estimate=" %21.15g (unbounded) " se=. n_obs=" %12.0f (n)
display "ANSWER: ar_f_at_one estimate=" %21.15g (ar_f_at_one) " se=. n_obs=" %12.0f (n)
