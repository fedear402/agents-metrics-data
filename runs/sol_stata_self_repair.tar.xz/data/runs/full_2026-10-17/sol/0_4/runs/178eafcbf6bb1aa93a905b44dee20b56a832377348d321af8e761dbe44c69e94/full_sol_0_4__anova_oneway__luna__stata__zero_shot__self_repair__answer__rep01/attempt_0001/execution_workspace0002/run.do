clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

anova y group

scalar answer_f = e(F)
scalar answer_df_num = e(df_m)
scalar answer_df_den = e(df_r)
scalar answer_p = Ftail(answer_df_num, answer_df_den, answer_f)
scalar answer_n = e(N)

display "ANSWER: F estimate=" %21.12f answer_f " se=. n_obs=" %12.0f answer_n
display "ANSWER: df_num estimate=" %21.12f answer_df_num " se=. n_obs=" %12.0f answer_n
display "ANSWER: df_den estimate=" %21.12f answer_df_den " se=. n_obs=" %12.0f answer_n
display "ANSWER: p_value estimate=" %21.12f answer_p " se=. n_obs=" %12.0f answer_n
