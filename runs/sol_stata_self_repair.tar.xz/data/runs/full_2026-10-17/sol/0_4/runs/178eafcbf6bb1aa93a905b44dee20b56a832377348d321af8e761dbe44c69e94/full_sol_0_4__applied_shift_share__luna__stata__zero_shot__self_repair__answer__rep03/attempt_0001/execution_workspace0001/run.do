set linesize 255
import delimited "./input.csv", clear

egen byte region_tag = tag(region_id)
egen double weight_total = total(cond(region_tag, region_weight, 0))
generate double e = region_weight / weight_total

generate double share_shock = share * shock
bysort region_id: egen double z = total(share_shock)

egen double y_mean = total(cond(region_tag, e*y, 0))
egen double x_mean = total(cond(region_tag, e*x, 0))
egen double z_mean = total(cond(region_tag, e*z, 0))

generate double y0 = y - y_mean
generate double x0 = x - x_mean
generate double z0 = z - z_mean

generate double s_part = e*share
generate double y_part = s_part*y0
generate double x_part = s_part*x0
generate double z_part = s_part*z0

collapse (sum) s=s_part y_part x_part z_part (firstnm) shock, by(industry_id)
count
scalar N = r(N)

generate double ybar = y_part/s
generate double xbar = x_part/s
generate double zbar = z_part/s

egen double sum_s = total(s)
generate double sg = s*shock
generate double sy = s*ybar
generate double sx = s*xbar
generate double sz = s*zbar
egen double sum_sg = total(sg)
egen double sum_sy = total(sy)
egen double sum_sx = total(sx)
egen double sum_sz = total(sz)

scalar g_mean = sum_sg[1]/sum_s[1]
scalar ybar_mean = sum_sy[1]/sum_s[1]
scalar xbar_mean = sum_sx[1]/sum_s[1]
scalar zbar_mean = sum_sz[1]/sum_s[1]

generate double g_center = shock - g_mean
generate double effect_num_part = s*g_center*(ybar-ybar_mean)
generate double effect_den_part = s*g_center*(xbar-xbar_mean)
generate double stage_den_part = s*g_center*(zbar-zbar_mean)

egen double effect_num = total(effect_num_part)
egen double effect_den = total(effect_den_part)
egen double stage_den = total(stage_den_part)

scalar effect = effect_num[1]/effect_den[1]
scalar first_stage = effect_den[1]/stage_den[1]

generate double effect_resid = ybar-ybar_mean-effect*(xbar-xbar_mean)
generate double stage_resid = xbar-xbar_mean-first_stage*(zbar-zbar_mean)
generate double effect_var_part = (s*g_center*effect_resid)^2
generate double stage_var_part = (s*g_center*stage_resid)^2
egen double effect_var_sum = total(effect_var_part)
egen double stage_var_sum = total(stage_var_part)

scalar effect_se = sqrt((N/(N-2))*effect_var_sum[1]/(effect_den[1]^2))
scalar first_stage_se = sqrt((N/(N-2))*stage_var_sum[1]/(stage_den[1]^2))

generate double s_squared = s^2
egen double sum_s_squared = total(s_squared)
scalar effective_shocks = 1/sum_s_squared[1]

display "ANSWER: effect estimate=" %21.12f effect " se=" %21.12f effect_se " n_obs=" %12.0f N
display "ANSWER: first_stage estimate=" %21.12f first_stage " se=" %21.12f first_stage_se " n_obs=" %12.0f N
display "ANSWER: effective_shocks estimate=" %21.12f effective_shocks " se=. n_obs=" %12.0f N
