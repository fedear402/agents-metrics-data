clear all
set more off
set type double

import delimited "households.csv", clear varnames(1)
keep if recipient == 0
count
scalar n_obs = r(N)

generate double g0 = 1 - eligible
generate double g1 = eligible
generate double base0 = baseline * g0
generate double base1 = baseline * g1
generate double dose0 = dose * g0
generate double dose1 = dose * g1
generate double inst0 = instrument * g0
generate double inst1 = instrument * g1

ivregress 2sls outcome g0 g1 base0 base1 ///
    (dose0 dose1 = inst0 inst1) [aw=weight], noconstant

scalar slope0 = _b[dose0]
scalar slope1 = _b[dose1]

summarize dose [aw=weight] if eligible == 0, meanonly
scalar ineligible_effect = slope0 * r(mean)

summarize dose [aw=weight] if eligible == 1, meanonly
scalar eligible_nonrecipient_effect = slope1 * r(mean)

import delimited "census.csv", clear varnames(1)
summarize nonrecipient_population if eligible == 0, meanonly
scalar population0 = r(mean)
summarize nonrecipient_population if eligible == 1, meanonly
scalar population1 = r(mean)

scalar population_effect = ///
    (ineligible_effect * population0 + ///
     eligible_nonrecipient_effect * population1) / ///
    (population0 + population1)

display "ANSWER: ineligible_effect estimate=" ///
    %24.16g (ineligible_effect) " se=NA n_obs=" %12.0f (n_obs)
display "ANSWER: eligible_nonrecipient_effect estimate=" ///
    %24.16g (eligible_nonrecipient_effect) " se=NA n_obs=" %12.0f (n_obs)
display "ANSWER: population_effect estimate=" ///
    %24.16g (population_effect) " se=NA n_obs=" %12.0f (n_obs)
