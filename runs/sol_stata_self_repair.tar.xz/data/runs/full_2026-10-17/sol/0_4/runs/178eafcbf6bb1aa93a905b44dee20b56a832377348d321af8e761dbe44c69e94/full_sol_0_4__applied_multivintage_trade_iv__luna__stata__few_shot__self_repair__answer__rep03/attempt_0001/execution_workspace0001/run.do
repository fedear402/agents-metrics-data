clear all
set more off
set type double

tempfile trade_ind areas_all area_base area_early emp_full national exposures outcomes_data

import delimited "crosswalk.csv", clear varnames(1)
isid code
save "`c(tmpdir)'/crosswalk_task.dta", replace

import delimited "trade.csv", clear varnames(1)
merge m:1 code using "`c(tmpdir)'/crosswalk_task.dta", assert(match) nogen
isid period industry
save `trade_ind'

import delimited "areas.csv", clear varnames(1)
isid area period vintage
save `areas_all'

keep if vintage == "base"
rename total_employment base_total
rename population base_population
drop vintage
isid area period
save `area_base'

use `areas_all', clear
keep if vintage == "early"
rename total_employment early_total
drop population vintage
isid area period
save `area_early'

import delimited "employment.csv", clear varnames(1)
isid area period vintage industry
save `emp_full'

use `areas_all', clear
keep area period vintage
cross using "`c(tmpdir)'/crosswalk_task.dta"
keep area period vintage industry
duplicates drop
merge 1:1 area period vintage industry using `emp_full', nogen
replace employment = 0 if missing(employment)
bysort period vintage industry: egen double national_employment = total(employment)
reshape wide employment national_employment, i(area period industry) j(vintage) string
merge m:1 period industry using `trade_ind', assert(match) nogen
merge m:1 area period using `area_base', assert(match) nogen
merge m:1 area period using `area_early', assert(match) nogen

gen double x_part = (employmentbase / base_total) * ///
    (us_change / national_employmentbase) / ///
    (price_index / 100) / 1000 * (10 / years)
gen double z_part = (employmentearly / early_total) * ///
    (other_change / national_employmentearly) / ///
    (price_index / 100) / 1000 * (10 / years)
collapse (sum) x=x_part z=z_part (first) base_population, by(area period)
save `exposures'

import delimited "outcomes.csv", clear varnames(1)
isid area period
merge 1:1 area period using `exposures', assert(match) nogen
assert _N == 72

quietly summarize x if area == 0 & period == 0, meanonly
scalar exposure_area0_period0 = r(mean)
quietly summarize x if area == 0 & period == 1, meanonly
scalar exposure_area0_period1 = r(mean)
quietly summarize z if area == 0 & period == 0, meanonly
scalar instrument_area0_period0 = r(mean)

ivregress 2sls change_pp period control (x = z) [aw=base_population]
assert e(N) == 72
scalar iv_slope = _b[x]

display "ANSWER: iv_slope estimate=" %24.16g iv_slope " se=NA n_obs=72"
display "ANSWER: exposure_area0_period0 estimate=" %24.16g exposure_area0_period0 " se=NA n_obs=72"
display "ANSWER: exposure_area0_period1 estimate=" %24.16g exposure_area0_period1 " se=NA n_obs=72"
display "ANSWER: instrument_area0_period0 estimate=" %24.16g instrument_area0_period0 " se=NA n_obs=72"
