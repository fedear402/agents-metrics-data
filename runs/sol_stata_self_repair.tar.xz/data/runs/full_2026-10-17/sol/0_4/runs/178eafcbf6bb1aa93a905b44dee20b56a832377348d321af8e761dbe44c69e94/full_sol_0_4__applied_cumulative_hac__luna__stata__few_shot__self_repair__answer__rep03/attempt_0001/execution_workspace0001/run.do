version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear
generate double day = date(date, "YMD")
sort day
generate long observation = _n
tsset observation

generate double log_sales = log(sales)
generate double log_vix = log(vix)
generate double vix_change = D.log_vix

forvalues k = 1/15 {
    generate double change_lag`k' = L`k'.vix_change
}

keep if !missing(log_sales, change_lag1-change_lag15)

mata:
    X = J(st_nobs(), 1, 1)
    for (k = 1; k <= 15; k++) {
        X = (X, st_data(., "change_lag" + strofreal(k)))
    }
    y = st_data(., "log_sales")
    b = qrsolve(X, y)
    N = rows(X)
    p = cols(X)
    scores = X :* (y - X*b)

    meat = scores' * scores
    for (j = 1; j <= 15; j++) {
        lag_product = scores[|j+1,1 \ N,p|]' * scores[|1,1 \ N-j,p|]
        meat = meat + (1 - j/16) * (lag_product + lag_product')
    }

    bread = invsym(X' * X)
    V = (N/(N-p)) * bread * meat * bread
    contrast = (0 \ J(15,1,1))

    st_numscalar("answer_cumulative", (contrast' * b)[1,1])
    st_numscalar("answer_cumulative_se", sqrt((contrast' * V * contrast)[1,1]))
    st_numscalar("answer_lag1", b[2,1])
    st_numscalar("answer_lag1_se", sqrt(V[2,2]))
    st_numscalar("answer_lag15", b[16,1])
    st_numscalar("answer_lag15_se", sqrt(V[16,16]))
    st_numscalar("answer_n", N)
end

display "ANSWER: cumulative_response estimate=" %21.12f answer_cumulative " se=" %21.12f answer_cumulative_se " n_obs=" %12.0f answer_n
display "ANSWER: lag_1 estimate=" %21.12f answer_lag1 " se=" %21.12f answer_lag1_se " n_obs=" %12.0f answer_n
display "ANSWER: lag_15 estimate=" %21.12f answer_lag15 " se=" %21.12f answer_lag15_se " n_obs=" %12.0f answer_n
