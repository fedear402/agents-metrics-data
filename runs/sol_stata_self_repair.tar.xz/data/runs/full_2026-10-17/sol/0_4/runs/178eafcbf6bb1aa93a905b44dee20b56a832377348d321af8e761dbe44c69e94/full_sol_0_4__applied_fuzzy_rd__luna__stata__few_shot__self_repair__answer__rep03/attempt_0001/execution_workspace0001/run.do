version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear
keep if abs(score) < 1
generate double weight = 1 - abs(score)
generate byte right = score >= 0

mata:
score = st_data(., "score")
right = st_data(., "right")
w = st_data(., "weight")
Y = st_data(., ("earnings", "participated"))
X = (J(rows(score), 1, 1), right, score, score:*right)

bread = invsym(X' * (w:*X))
coefficients = bread * X' * (w:*Y)
residuals = Y - X*coefficients

// The right-minus-left limit is the coefficient on right.
contrast = (0\1\0\0)
jumps = contrast' * coefficients
loading = w:*(X*bread*contrast)
influence = loading:*residuals
joint = influence' * influence

treatment = .
treatment_se = .
if (jumps[2] != 0) {
    treatment = jumps[1]/jumps[2]
    gradient = (1/jumps[2]\-jumps[1]/jumps[2]^2)
    treatment_se = sqrt(gradient' * joint * gradient)
}

st_numscalar("treatment_effect", treatment)
st_numscalar("treatment_effect_se", treatment_se)
st_numscalar("reduced_form", jumps[1])
st_numscalar("reduced_form_se", sqrt(joint[1,1]))
st_numscalar("first_stage", jumps[2])
st_numscalar("first_stage_se", sqrt(joint[2,2]))
st_numscalar("n_obs", rows(Y))
end

display "ANSWER: treatment_effect estimate=" %21.12f scalar(treatment_effect) " se=" %21.12f scalar(treatment_effect_se) " n_obs=" %12.0f scalar(n_obs)
display "ANSWER: reduced_form estimate=" %21.12f scalar(reduced_form) " se=" %21.12f scalar(reduced_form_se) " n_obs=" %12.0f scalar(n_obs)
display "ANSWER: first_stage estimate=" %21.12f scalar(first_stage) " se=" %21.12f scalar(first_stage_se) " n_obs=" %12.0f scalar(n_obs)
