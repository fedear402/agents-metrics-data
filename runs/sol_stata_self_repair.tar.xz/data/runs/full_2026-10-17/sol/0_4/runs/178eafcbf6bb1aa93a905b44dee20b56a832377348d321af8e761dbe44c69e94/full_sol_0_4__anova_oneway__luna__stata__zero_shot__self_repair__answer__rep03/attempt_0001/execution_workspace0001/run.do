clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

quietly anova y group
scalar answer_F = e(F)
scalar answer_df_num = e(df_m)
scalar answer_df_den = e(df_r)
scalar answer_p_value = Ftail(answer_df_num, answer_df_den, answer_F)
scalar answer_n = e(N)

display "ANSWER: F estimate=" %21.12f answer_F " se=. n_obs=" %12.0f answer_n
display "ANSWER: df_num estimate=" %21.12f answer_df_num " se=. n_obs=" %12.0f answer_n
display "ANSWER: df_den estimate=" %21.12f answer_df_den " se=. n_obs=" %12.0f answer_n
display "ANSWER: p_value estimate=" %21.12f answer_p_value " se=. n_obs=" %12.0f answer_n
