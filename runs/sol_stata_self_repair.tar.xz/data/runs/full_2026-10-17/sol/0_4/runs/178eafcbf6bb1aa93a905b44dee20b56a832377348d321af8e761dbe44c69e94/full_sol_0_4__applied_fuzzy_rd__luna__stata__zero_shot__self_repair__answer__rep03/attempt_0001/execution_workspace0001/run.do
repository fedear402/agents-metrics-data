clear all
set more off
set linesize 255

import delimited using "./input.csv", clear
keep if !missing(score, participated, earnings) & abs(score) < 1

generate double weight = 1 - abs(score)
generate byte right = score >= 0

mata:
    x = st_data(., "score")
    r = st_data(., "right")
    w = st_data(., "weight")
    y = st_data(., "earnings")
    d = st_data(., "participated")

    X = (J(rows(x), 1, 1), x, r, x :* r)
    A = invsym(quadcross(X, w, X))

    by = A * quadcross(X, w, y)
    bd = A * quadcross(X, w, d)
    uy = y - X * by
    ud = d - X * bd

    influence = w :* (X * A[, 3])
    var_y = sum((influence :* uy) :^ 2)
    var_d = sum((influence :* ud) :^ 2)
    cov_yd = sum((influence :* uy) :* (influence :* ud))

    rf = by[3]
    fs = bd[3]
    effect = rf / fs
    var_effect = var_y / fs^2 + rf^2 * var_d / fs^4 - 2 * rf * cov_yd / fs^3

    st_numscalar("reduced_form", rf)
    st_numscalar("first_stage", fs)
    st_numscalar("treatment_effect", effect)
    st_numscalar("se_reduced_form", sqrt(max((0, var_y))))
    st_numscalar("se_first_stage", sqrt(max((0, var_d))))
    st_numscalar("se_treatment_effect", sqrt(max((0, var_effect))))
end

local n_obs = _N
display "ANSWER: treatment_effect estimate=" %21.12f treatment_effect " se=" %21.12f se_treatment_effect " n_obs=" %12.0f `n_obs'
display "ANSWER: reduced_form estimate=" %21.12f reduced_form " se=" %21.12f se_reduced_form " n_obs=" %12.0f `n_obs'
display "ANSWER: first_stage estimate=" %21.12f first_stage " se=" %21.12f se_first_stage " n_obs=" %12.0f `n_obs'
