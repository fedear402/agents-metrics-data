clear all
set more off
set type double

tempfile crosswalk trade industries areas employment exposure

import delimited "crosswalk.csv", clear
save `crosswalk'
keep industry
duplicates drop
save `industries'

import delimited "trade.csv", clear
merge m:1 code using `crosswalk', assert(match) nogen
save `trade'

import delimited "areas.csv", clear
save `areas'

import delimited "employment.csv", clear
save `employment'

use `areas', clear
cross using `industries'
merge 1:1 area period vintage industry using `employment', ///
    keep(master match) nogen
replace employment = 0 if missing(employment)

bysort period vintage industry: egen double national_employment = total(employment)
merge m:1 period industry using `trade', assert(match) nogen

gen double contribution = ///
    (employment / total_employment) * ///
    (cond(vintage == "base", us_change, other_change) / national_employment) / ///
    (price_index / 100) / 1000 * (10 / years)

gen double x_part = contribution if vintage == "base"
gen double z_part = contribution if vintage == "early"
collapse (sum) x_part z_part, by(area period)
rename x_part x
rename z_part z
save `exposure'

use `areas', clear
keep if vintage == "base"
keep area period population
merge 1:1 area period using `exposure', assert(match) nogen

import delimited "outcomes.csv", clear
tempfile outcomes
save `outcomes'

use `areas', clear
keep if vintage == "base"
keep area period population
merge 1:1 area period using `exposure', assert(match) nogen
merge 1:1 area period using `outcomes', assert(match) nogen

quietly summarize x if area == 0 & period == 0, meanonly
scalar exposure_area0_period0 = r(mean)
quietly summarize x if area == 0 & period == 1, meanonly
scalar exposure_area0_period1 = r(mean)
quietly summarize z if area == 0 & period == 0, meanonly
scalar instrument_area0_period0 = r(mean)

quietly ivregress 2sls change_pp period control (x = z) [aw = population]
scalar iv_slope = _b[x]
local n_obs = e(N)

display "ANSWER: iv_slope estimate=" %21.12g scalar(iv_slope) " se=NA n_obs=`n_obs'"
display "ANSWER: exposure_area0_period0 estimate=" %21.12g scalar(exposure_area0_period0) " se=NA n_obs=`n_obs'"
display "ANSWER: exposure_area0_period1 estimate=" %21.12g scalar(exposure_area0_period1) " se=NA n_obs=`n_obs'"
display "ANSWER: instrument_area0_period0 estimate=" %21.12g scalar(instrument_area0_period0) " se=NA n_obs=`n_obs'"
