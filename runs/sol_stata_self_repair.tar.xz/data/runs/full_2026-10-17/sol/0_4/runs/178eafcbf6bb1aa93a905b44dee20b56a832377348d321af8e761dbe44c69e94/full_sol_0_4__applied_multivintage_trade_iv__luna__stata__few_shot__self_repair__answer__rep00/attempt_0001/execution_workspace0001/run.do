clear all
set more off
set type double

tempfile crosswalk trade areas industries employment outcomes base_population

import delimited "crosswalk.csv", clear varnames(1)
isid code
save `crosswalk'

keep industry
duplicates drop
assert _N == 4
save `industries'

import delimited "trade.csv", clear varnames(1)
merge m:1 code using `crosswalk', assert(match) nogen
isid period industry
save `trade'

import delimited "areas.csv", clear varnames(1)
isid area period vintage
save `areas'

keep if vintage == "base"
keep area period population
rename population weight
isid area period
save `base_population'

import delimited "employment.csv", clear varnames(1)
isid area period vintage industry
save `employment'

import delimited "outcomes.csv", clear varnames(1)
isid area period
save `outcomes'

use `areas', clear
cross using `industries'
merge 1:1 area period vintage industry using `employment', assert(master match) nogen
replace employment = 0 if missing(employment)

bysort period vintage industry: egen double national_employment = total(employment)
assert national_employment > 0

merge m:1 period industry using `trade', assert(match) nogen

gen double exposure_component = ///
    (employment / total_employment) * ///
    (cond(vintage == "base", us_change, other_change) / national_employment) / ///
    (price_index / 100) / 1000 * (10 / years)

collapse (sum) exposure_component, by(area period vintage)
reshape wide exposure_component, i(area period) j(vintage) string
rename exposure_componentbase x
rename exposure_componentearly z

merge 1:1 area period using `base_population', assert(match) nogen
merge 1:1 area period using `outcomes', assert(match) nogen
assert _N == 72

quietly summarize x if area == 0 & period == 0, meanonly
scalar exposure_area0_period0 = r(mean)
quietly summarize x if area == 0 & period == 1, meanonly
scalar exposure_area0_period1 = r(mean)
quietly summarize z if area == 0 & period == 0, meanonly
scalar instrument_area0_period0 = r(mean)

ivregress 2sls change_pp period control (x = z) [aw = weight]
scalar iv_slope = _b[x]

display "ANSWER: iv_slope estimate=" %24.16g scalar(iv_slope) " se=NA n_obs=72"
display "ANSWER: exposure_area0_period0 estimate=" %24.16g scalar(exposure_area0_period0) " se=NA n_obs=72"
display "ANSWER: exposure_area0_period1 estimate=" %24.16g scalar(exposure_area0_period1) " se=NA n_obs=72"
display "ANSWER: instrument_area0_period0 estimate=" %24.16g scalar(instrument_area0_period0) " se=NA n_obs=72"
