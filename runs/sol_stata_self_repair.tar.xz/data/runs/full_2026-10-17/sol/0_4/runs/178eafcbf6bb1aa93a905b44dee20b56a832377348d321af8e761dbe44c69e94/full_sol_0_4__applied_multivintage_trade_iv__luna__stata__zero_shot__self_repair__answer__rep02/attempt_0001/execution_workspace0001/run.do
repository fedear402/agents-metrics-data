clear all
set more off

tempfile trade_data employment_data

import delimited "crosswalk.csv", clear
isid code
save "`trade_data'"

import delimited "trade.csv", clear
merge m:1 code using "`trade_data'", assert(match) nogen
isid period industry
save "`trade_data'"

import delimited "employment.csv", clear
isid area period vintage industry
save "`employment_data'"

import delimited "areas.csv", clear
isid area period vintage
joinby period using "`trade_data'"

merge 1:1 area period vintage industry using "`employment_data'", ///
    keep(master match) nogen
replace employment = 0 if missing(employment)

bysort period vintage industry: egen double national_employment = total(employment)

gen double exposure = ///
    (employment / total_employment) * ///
    (cond(vintage == "base", us_change, other_change) / national_employment) * ///
    (100 / price_index) / 1000 * (10 / years)

collapse (sum) exposure (firstnm) population, by(area period vintage)
reshape wide exposure population, i(area period) j(vintage) string
rename exposurebase x
rename exposureearly z

import delimited "outcomes.csv", clear
isid area period
tempfile outcome_data
save "`outcome_data'"

import delimited "areas.csv", clear
keep area period
duplicates drop
tempfile area_periods
save "`area_periods'"

* Recover the constructed exposure data from the steps above.
* Rebuild it here so the script remains independent of stored session data.
import delimited "areas.csv", clear
joinby period using "`trade_data'"
merge 1:1 area period vintage industry using "`employment_data'", ///
    keep(master match) nogen
replace employment = 0 if missing(employment)
bysort period vintage industry: egen double national_employment = total(employment)
gen double exposure = ///
    (employment / total_employment) * ///
    (cond(vintage == "base", us_change, other_change) / national_employment) * ///
    (100 / price_index) / 1000 * (10 / years)
collapse (sum) exposure (firstnm) population, by(area period vintage)
reshape wide exposure population, i(area period) j(vintage) string
rename exposurebase x
rename exposureearly z

merge 1:1 area period using "`outcome_data'", assert(match) nogen
assert !missing(change_pp, period, control, x, z, populationbase)
count
assert r(N) == 72

quietly summarize x if area == 0 & period == 0, meanonly
scalar exposure_00 = r(mean)
quietly summarize x if area == 0 & period == 1, meanonly
scalar exposure_01 = r(mean)
quietly summarize z if area == 0 & period == 0, meanonly
scalar instrument_00 = r(mean)

ivregress 2sls change_pp period control (x = z) [aw = populationbase]
assert e(N) == 72
scalar iv_slope = _b[x]

display "ANSWER: iv_slope estimate=" %24.16g (iv_slope) " se=NA n_obs=72"
display "ANSWER: exposure_area0_period0 estimate=" %24.16g (exposure_00) " se=NA n_obs=72"
display "ANSWER: exposure_area0_period1 estimate=" %24.16g (exposure_01) " se=NA n_obs=72"
display "ANSWER: instrument_area0_period0 estimate=" %24.16g (instrument_00) " se=NA n_obs=72"
