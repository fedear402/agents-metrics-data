version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear
generate double day = date(date, "YMD")
sort day
generate long observation = _n
tsset observation

generate double log_sales = log(sales)
generate double log_vix = log(vix)
generate double vix_change = D.log_vix

forvalues k = 1/15 {
    generate double change_lag`k' = L`k'.vix_change
}

local regressors
forvalues k = 1/15 {
    local regressors `regressors' change_lag`k'
}
keep if !missing(log_sales, `regressors')

mata:
N = st_nobs()
p = 16
X = (J(N, 1, 1), st_data(., tokens(st_local("regressors"))))
y = st_data(., "log_sales")
b = qrsolve(X, y)
u = y - X*b
scores = X :* u

meat = scores'*scores
for (j=1; j<=15; j++) {
    lag_product = scores[|j+1,1\N,p|]' * scores[|1,1\N-j,p|]
    meat = meat + (1-j/16) * (lag_product + lag_product')
}
bread = invsym(X'*X)
V = (N/(N-p)) * bread * meat * bread

c = (0 \ J(15,1,1))
st_numscalar("result_cumulative", (c'*b)[1,1])
st_numscalar("se_cumulative", sqrt((c'*V*c)[1,1]))
st_numscalar("result_lag1", b[2,1])
st_numscalar("se_lag1", sqrt(V[2,2]))
st_numscalar("result_lag15", b[16,1])
st_numscalar("se_lag15", sqrt(V[16,16]))
st_numscalar("result_n", N)
end

display "ANSWER: cumulative_response estimate=" %21.15g result_cumulative " se=" %21.15g se_cumulative " n_obs=" %12.0f result_n
display "ANSWER: lag_1 estimate=" %21.15g result_lag1 " se=" %21.15g se_lag1 " n_obs=" %12.0f result_n
display "ANSWER: lag_15 estimate=" %21.15g result_lag15 " se=" %21.15g se_lag15 " n_obs=" %12.0f result_n
