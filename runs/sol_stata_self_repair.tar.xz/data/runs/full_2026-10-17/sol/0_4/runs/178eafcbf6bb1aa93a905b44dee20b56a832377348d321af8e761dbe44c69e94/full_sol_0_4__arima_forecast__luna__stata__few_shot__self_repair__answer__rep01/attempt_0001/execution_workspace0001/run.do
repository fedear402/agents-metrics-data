clear all
set more off
set linesize 255

import delimited using "./input.csv", clear
tsset t

arima y, arima(1,1,1) noconstant
scalar n_est = e(N)

tsappend, add(1)
predict double y_forecast, y dynamic(251)
predict double forecast_mse, mse dynamic(251)

scalar fc = y_forecast[_N]
scalar fc_se = sqrt(forecast_mse[_N])
scalar lower = fc - invnormal(0.975)*fc_se
scalar upper = fc + invnormal(0.975)*fc_se

display "ANSWER: forecast estimate=" %21.12f fc " se=" %21.12f fc_se " n_obs=" %12.0f n_est
display "ANSWER: lower_95 estimate=" %21.12f lower " se=. n_obs=" %12.0f n_est
display "ANSWER: upper_95 estimate=" %21.12f upper " se=. n_obs=" %12.0f n_est
