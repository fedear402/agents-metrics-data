set linesize 255
import delimited using "./input.csv", clear

sort date
generate long trading_obs = _n
tsset trading_obs

generate double log_sales = ln(sales)
generate double log_vix = ln(vix)
generate double dlog_vix = D.log_vix

forvalues j = 1/15 {
    generate double lag_`j' = L`j'.dlog_vix
}

regress log_sales lag_1-lag_15
scalar n_obs = e(N)
generate byte reg_sample = e(sample)
predict double residual if reg_sample, residuals

mata:
    X = J(st_numscalar("n_obs"), 1, 1), ///
        st_data(., tokens("lag_1 lag_2 lag_3 lag_4 lag_5 lag_6 lag_7 lag_8 lag_9 lag_10 lag_11 lag_12 lag_13 lag_14 lag_15"), "reg_sample")
    u = st_data(., "residual", "reg_sample")
    S = X :* u
    N = rows(X)
    meat = S' * S
    for (j = 1; j <= 15; j++) {
        cross = S[(j+1)..N,]' * S[1..(N-j),]
        meat = meat + (1 - j/16) * (cross + cross')
    }
    bread = invsym(X' * X)
    V = (N / (N - 16)) * bread * meat * bread
    st_numscalar("se_cumulative", sqrt(sum(V[|2,2 \ 16,16|])))
    st_numscalar("se_lag_1", sqrt(V[2,2]))
    st_numscalar("se_lag_15", sqrt(V[16,16]))
end

scalar cumulative_response = 0
forvalues j = 1/15 {
    scalar cumulative_response = cumulative_response + _b[lag_`j']
}
scalar estimate_lag_1 = _b[lag_1]
scalar estimate_lag_15 = _b[lag_15]

display "ANSWER: cumulative_response estimate=" %21.12f cumulative_response " se=" %21.12f se_cumulative " n_obs=" %12.0f n_obs
display "ANSWER: lag_1 estimate=" %21.12f estimate_lag_1 " se=" %21.12f se_lag_1 " n_obs=" %12.0f n_obs
display "ANSWER: lag_15 estimate=" %21.12f estimate_lag_15 " se=" %21.12f se_lag_15 " n_obs=" %12.0f n_obs
