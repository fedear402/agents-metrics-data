version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear
generate double day = date(date, "YMD")
sort day
generate long observation = _n
tsset observation

generate double log_sales = log(sales)
generate double log_vix = log(vix)
generate double vix_change = D.log_vix

forvalues k = 1/15 {
    generate double change_lag`k' = L`k'.vix_change
}

keep if !missing(log_sales, change_lag1-change_lag15)

mata:
lagvars = tokens("change_lag1 change_lag2 change_lag3 change_lag4 change_lag5 change_lag6 change_lag7 change_lag8 change_lag9 change_lag10 change_lag11 change_lag12 change_lag13 change_lag14 change_lag15")
N = st_nobs()
X = (J(N, 1, 1), st_data(., lagvars))
p = cols(X)
y = st_data(., "log_sales")
b = qrsolve(X, y)
u = y - X*b
scores = X :* u

meat = scores'*scores
for (j = 1; j <= 15; j++) {
    lag_product = scores[|j+1,1 \ N,p|]' * scores[|1,1 \ N-j,p|]
    meat = meat + (1-j/16) * (lag_product + lag_product')
}

bread = invsym(X'*X)
V = (N/(N-p)) * bread * meat * bread
contrast = (0 \ J(15,1,1))
cumulative = contrast'*b
cumulative_variance = contrast'*V*contrast

st_numscalar("cumulative_response", cumulative[1,1])
st_numscalar("cumulative_se", sqrt(cumulative_variance[1,1]))
st_numscalar("lag_1", b[2,1])
st_numscalar("lag_1_se", sqrt(V[2,2]))
st_numscalar("lag_15", b[16,1])
st_numscalar("lag_15_se", sqrt(V[16,16]))
st_numscalar("n_obs", N)
end

display "ANSWER: cumulative_response estimate=" %21.12f scalar(cumulative_response) " se=" %21.12f scalar(cumulative_se) " n_obs=" %12.0f scalar(n_obs)
display "ANSWER: lag_1 estimate=" %21.12f scalar(lag_1) " se=" %21.12f scalar(lag_1_se) " n_obs=" %12.0f scalar(n_obs)
display "ANSWER: lag_15 estimate=" %21.12f scalar(lag_15) " se=" %21.12f scalar(lag_15_se) " n_obs=" %12.0f scalar(n_obs)
