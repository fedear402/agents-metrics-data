clear all
set more off
set linesize 255

import delimited using "input.csv", clear varnames(1) asdouble
keep if !missing(y, group)
count
scalar n_anova = r(N)

oneway y group
scalar F_anova = r(F)
scalar df_num_anova = r(df_m)
scalar df_den_anova = r(df_r)
scalar p_anova = Ftail(df_num_anova, df_den_anova, F_anova)

display "ANSWER: F estimate=" %21.12f F_anova " se=. n_obs=" %12.0f n_anova
display "ANSWER: df_num estimate=" %21.12f df_num_anova " se=. n_obs=" %12.0f n_anova
display "ANSWER: df_den estimate=" %21.12f df_den_anova " se=. n_obs=" %12.0f n_anova
display "ANSWER: p_value estimate=" %21.12f p_anova " se=. n_obs=" %12.0f n_anova
