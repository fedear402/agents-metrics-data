clear all
set more off
set linesize 255

import delimited using "input.csv", clear varnames(1) asdouble
anova y group

scalar n_obs = e(N)
scalar f_stat = e(F)
scalar df_num = e(df_m)
scalar df_den = e(df_r)
scalar p_value = Ftail(df_num, df_den, f_stat)

display "ANSWER: F estimate=" %21.12f f_stat " se=. n_obs=" %12.0f n_obs
display "ANSWER: df_num estimate=" %21.12f df_num " se=. n_obs=" %12.0f n_obs
display "ANSWER: df_den estimate=" %21.12f df_den " se=. n_obs=" %12.0f n_obs
display "ANSWER: p_value estimate=" %21.12f p_value " se=. n_obs=" %12.0f n_obs
