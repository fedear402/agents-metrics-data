clear all
set more off
set linesize 255
import delimited using "./input.csv", clear
keep if !missing(score, participated, earnings) & abs(score) < 1
generate double w = 1 - abs(score)
generate double right = score >= 0
generate double right_score = right * score
generate double constant = 1

mata:
X = st_data(., tokens("constant score right right_score"))
w = st_data(., "w")
y = st_data(., "earnings")
d = st_data(., "participated")
N = rows(X)
A = invsym(quadcross(X, w, X))
by = A * quadcross(X, w, y)
bd = A * quadcross(X, w, d)
ey = y - X*by
ed = d - X*bd
Vy = A * quadcross(X, (w:^2):*(ey:^2), X) * A
Vd = A * quadcross(X, (w:^2):*(ed:^2), X) * A
Cyd = A * quadcross(X, (w:^2):*(ey:*ed), X) * A
rf = by[3]
fs = bd[3]
te = rf / fs
se_rf = sqrt(Vy[3,3])
se_fs = sqrt(Vd[3,3])
se_te = sqrt(Vy[3,3]/fs^2 + rf^2*Vd[3,3]/fs^4 - 2*rf*Cyd[3,3]/fs^3)
st_numscalar("rf", rf)
st_numscalar("fs", fs)
st_numscalar("te", te)
st_numscalar("se_rf", se_rf)
st_numscalar("se_fs", se_fs)
st_numscalar("se_te", se_te)
st_numscalar("n_obs", N)
end

display "ANSWER: treatment_effect estimate=" %21.12f scalar(te) " se=" %21.12f scalar(se_te) " n_obs=" %12.0f scalar(n_obs)
display "ANSWER: reduced_form estimate=" %21.12f scalar(rf) " se=" %21.12f scalar(se_rf) " n_obs=" %12.0f scalar(n_obs)
display "ANSWER: first_stage estimate=" %21.12f scalar(fs) " se=" %21.12f scalar(se_fs) " n_obs=" %12.0f scalar(n_obs)
