clear all
set more off
capture log close
log using run.log, text replace

tempfile industries crosswalk trade areas employ full nationals outcomes

import delimited crosswalk.csv, clear varnames(1)
isid code
save `crosswalk'
keep industry
duplicates drop
isid industry
save `industries'

import delimited trade.csv, clear varnames(1)
merge m:1 code using `crosswalk'
assert _merge == 3
drop _merge code
isid period industry
save `trade'

import delimited areas.csv, clear varnames(1)
isid area period vintage
save `areas'

import delimited employment.csv, clear varnames(1)
isid area period vintage industry
save `employ'

use `areas', clear
cross using `industries'
merge 1:1 area period vintage industry using `employ'
assert _merge != 2
replace employment = 0 if _merge == 1
drop _merge
save `full'

collapse (sum) national_employment=employment, by(period vintage industry)
assert national_employment > 0
save `nationals'

use `full', clear
merge m:1 period vintage industry using `nationals', assert(match) nogen
merge m:1 period industry using `trade', assert(match) nogen
gen double trade_change = cond(vintage == "base", us_change, other_change)
gen double contribution = (employment / total_employment) * ///
    (trade_change / national_employment) / (price_index / 100) / 1000 * (10 / years)
collapse (sum) exposure=contribution (firstnm) population, by(area period vintage)
reshape wide exposure population, i(area period) j(vintage) string
rename exposurebase x
rename exposureearly z
tempfile exposure_final
save `exposure_final'
import delimited outcomes.csv, clear varnames(1)
isid area period
save `outcomes'
use `exposure_final', clear
merge 1:1 area period using `outcomes', assert(match) nogen
assert _N == 72
assert !missing(x,z,change_pp,control,period,populationbase)

quietly summarize x if area == 0 & period == 0, meanonly
scalar x00 = r(mean)
quietly summarize x if area == 0 & period == 1, meanonly
scalar x01 = r(mean)
quietly summarize z if area == 0 & period == 0, meanonly
scalar z00 = r(mean)

ivregress 2sls change_pp period control (x = z) [aw=populationbase]
scalar slope = _b[x]
local line1 "ANSWER: iv_slope estimate=`=strtrim(strofreal(slope, "%21.12g"))' se=NA n_obs=72"
local line2 "ANSWER: exposure_area0_period0 estimate=`=strtrim(strofreal(x00, "%21.12g"))' se=NA n_obs=72"
local line3 "ANSWER: exposure_area0_period1 estimate=`=strtrim(strofreal(x01, "%21.12g"))' se=NA n_obs=72"
local line4 "ANSWER: instrument_area0_period0 estimate=`=strtrim(strofreal(z00, "%21.12g"))' se=NA n_obs=72"
display "`line1'"
display "`line2'"
display "`line3'"
display "`line4'"
file open answer using answer.txt, write replace
file write answer "`line1'" _n "`line2'" _n "`line3'" _n "`line4'" _n
file close answer
log close
