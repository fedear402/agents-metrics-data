clear all
set more off
set linesize 255
set type double

* Attach each trade code to its single industry.
import delimited using crosswalk.csv, clear varnames(1)
isid code
tempfile cross trade areas emp industries outcomes
save `cross'
import delimited using trade.csv, clear varnames(1)
merge m:1 code using `cross', assert(match) nogen
isid period industry
save `trade'
keep industry
 duplicates drop
isid industry
save `industries'

import delimited using areas.csv, clear varnames(1)
isid area period vintage
save `areas'
import delimited using employment.csv, clear varnames(1)
isid area period vintage industry
save `emp'
import delimited using outcomes.csv, clear varnames(1)
isid area period
save `outcomes'

* Complete the four-industry grid. Omitted employment cells have value zero.
use `areas', clear
cross using `industries'
merge 1:1 area period vintage industry using `emp', keep(master match) nogen
replace employment=0 if missing(employment)
bysort period vintage industry: egen double national_employment=total(employment)
assert national_employment>0
merge m:1 period industry using `trade', assert(match) nogen

gen double component=(employment/total_employment)*(cond(vintage=="base",us_change,other_change)/national_employment)/(price_index/100)/1000*(10/years)
collapse (sum) exposure=component (firstnm) total_employment population, by(area period vintage)
reshape wide exposure total_employment population, i(area period) j(vintage) string
rename exposurebase x
rename exposureearly z
merge 1:1 area period using `outcomes', assert(match) nogen
assert !missing(change_pp,period,control,x,z,populationbase)
count
assert r(N)==72
ivregress 2sls change_pp period control (x=z) [aw=populationbase]
assert e(N)==72
scalar iv_slope=_b[x]
quietly summarize x if area==0 & period==0, meanonly
assert r(N)==1
scalar x00=r(mean)
quietly summarize x if area==0 & period==1, meanonly
assert r(N)==1
scalar x01=r(mean)
quietly summarize z if area==0 & period==0, meanonly
assert r(N)==1
scalar z00=r(mean)
display "ANSWER: iv_slope estimate=" %24.16g iv_slope " se=NA n_obs=72"
display "ANSWER: exposure_area0_period0 estimate=" %24.16g x00 " se=NA n_obs=72"
display "ANSWER: exposure_area0_period1 estimate=" %24.16g x01 " se=NA n_obs=72"
display "ANSWER: instrument_area0_period0 estimate=" %24.16g z00 " se=NA n_obs=72"
exit, clear
