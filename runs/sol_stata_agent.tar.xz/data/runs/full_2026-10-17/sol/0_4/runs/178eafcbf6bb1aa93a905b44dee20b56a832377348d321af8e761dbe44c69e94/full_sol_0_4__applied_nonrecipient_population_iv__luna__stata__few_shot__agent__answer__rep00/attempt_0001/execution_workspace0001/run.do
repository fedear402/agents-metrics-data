clear all
set more off
set type double
import delimited using "households.csv", clear varnames(1) numericcols(_all)
keep if recipient == 0
assert inlist(eligible, 0, 1)
assert weight > 0
count
scalar n_obs = r(N)
generate double g0 = 1 - eligible
generate double g1 = eligible
generate double b0 = baseline*g0
generate double b1 = baseline*g1
generate double d0 = dose*g0
generate double d1 = dose*g1
generate double z0 = instrument*g0
generate double z1 = instrument*g1
ivregress 2sls outcome g0 g1 b0 b1 (d0 d1 = z0 z1) [aw=weight], noconstant
assert e(N) == n_obs
scalar slope0 = _b[d0]
scalar slope1 = _b[d1]
summarize dose [aw=weight] if eligible == 0, meanonly
scalar effect0 = slope0*r(mean)
summarize dose [aw=weight] if eligible == 1, meanonly
scalar effect1 = slope1*r(mean)
preserve
import delimited using "census.csv", clear varnames(1) numericcols(_all)
assert _N == 2
assert inlist(eligible, 0, 1)
assert nonrecipient_population > 0
summarize nonrecipient_population if eligible == 0, meanonly
scalar pop0 = r(mean)
summarize nonrecipient_population if eligible == 1, meanonly
scalar pop1 = r(mean)
restore
scalar population_effect = (effect0*pop0 + effect1*pop1)/(pop0+pop1)
display "ANSWER: ineligible_effect estimate=" strtrim(string(effect0, "%21.15g")) " se=NA n_obs=" strtrim(string(n_obs, "%9.0f"))
display "ANSWER: eligible_nonrecipient_effect estimate=" strtrim(string(effect1, "%21.15g")) " se=NA n_obs=" strtrim(string(n_obs, "%9.0f"))
display "ANSWER: population_effect estimate=" strtrim(string(population_effect, "%21.15g")) " se=NA n_obs=" strtrim(string(n_obs, "%9.0f"))
exit, clear
