clear all
set more off
set linesize 255
import delimited using "./input.csv", clear asdouble
sort date

generate double log_sales = ln(sales)
generate double log_vix = ln(vix)
generate double dlog_vix = log_vix - log_vix[_n-1]
forvalues j = 1/15 {
    generate double lag_`j' = dlog_vix[_n-`j']
}

regress log_sales lag_1-lag_15
scalar N = e(N)
generate byte estimation_sample = e(sample)

mata:
    X = J(st_numscalar("N"), 1, 1), st_data(., tokens("lag_1 lag_2 lag_3 lag_4 lag_5 lag_6 lag_7 lag_8 lag_9 lag_10 lag_11 lag_12 lag_13 lag_14 lag_15"), "estimation_sample")
    y = st_data(., "log_sales", "estimation_sample")
    b = qrsolve(X, y)
    u = y - X*b
    n = rows(X)
    S = (X :* u)' * (X :* u)
    for (j=1; j<=15; j++) {
        C = (X[(j+1)..n,] :* u[(j+1)..n])' * (X[1..(n-j),] :* u[1..(n-j)])
        S = S + (1-j/16)*(C+C')
    }
    A = invsym(X'X)
    V = (n/(n-16))*A*S*A
    c = (0 \ J(15,1,1))
    st_numscalar("cumulative_est", c'*b)
    st_numscalar("cumulative_se", sqrt(c'*V*c))
    st_numscalar("lag1_est", b[2])
    st_numscalar("lag1_se", sqrt(V[2,2]))
    st_numscalar("lag15_est", b[16])
    st_numscalar("lag15_se", sqrt(V[16,16]))
end

display "ANSWER: cumulative_response estimate=" %21.12f cumulative_est " se=" %21.12f cumulative_se " n_obs=" %12.0f N
display "ANSWER: lag_1 estimate=" %21.12f lag1_est " se=" %21.12f lag1_se " n_obs=" %12.0f N
display "ANSWER: lag_15 estimate=" %21.12f lag15_est " se=" %21.12f lag15_se " n_obs=" %12.0f N
