clear all
set more off
set linesize 255
import delimited using "./input.csv", clear asdouble
keep if !missing(score, participated, earnings) & abs(score) < 1
generate double weight = 1 - abs(score)
generate double right = score >= 0
generate double left_score = score * (1 - right)
generate double right_score = score * right
generate double constant = 1

mata:
X = st_data(., ("constant", "right", "left_score", "right_score"))
Y = st_data(., ("earnings", "participated"))
w = st_data(., "weight")
n = rows(X)
A = invsym(quadcross(X, w, X))
B = A * quadcross(X, w, Y)
U = Y - X * B
S = J(2, 2, 0)
for (i=1; i<=n; i++) {
    h = w[i]^2 * (X[i,.] * A[,2])^2
    S = S + h * (U[i,.]' * U[i,.])
}
rf = B[2,1]
fs = B[2,2]
te = rf / fs
g = (1/fs \ -rf/fs^2)
st_numscalar("n_obs", n)
st_numscalar("reduced_form", rf)
st_numscalar("first_stage", fs)
st_numscalar("treatment_effect", te)
st_numscalar("se_rf", sqrt(S[1,1]))
st_numscalar("se_fs", sqrt(S[2,2]))
st_numscalar("se_te", sqrt(g' * S * g))
end

display "ANSWER: treatment_effect estimate=" %21.12f treatment_effect " se=" %21.12f se_te " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f reduced_form " se=" %21.12f se_rf " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f first_stage " se=" %21.12f se_fs " n_obs=" %12.0f n_obs
