clear all
set more off
set type double

import delimited using crosswalk.csv, clear varnames(1)
isid code
save crosswalk.dta, replace

import delimited using trade.csv, clear varnames(1)
merge m:1 code using crosswalk.dta, assert(match) nogen
isid period industry
bysort period: assert price_index == price_index[1] & years == years[1]
expand 2
bysort period industry: gen str5 vintage = cond(_n==1,"base","early")
rename us_change focal_change
rename other_change instrument_change
save trade_vintage.dta, replace

import delimited using employment.csv, clear varnames(1)
isid area period vintage industry
save employment.dta, replace
collapse (sum) national_employment=employment, by(period vintage industry)
assert national_employment > 0
merge 1:1 period vintage industry using trade_vintage.dta, assert(match) nogen
save national_trade.dta, replace

import delimited using areas.csv, clear varnames(1)
isid area period vintage
joinby period vintage using national_trade.dta
merge 1:1 area period vintage industry using employment.dta, assert(master match) nogen
replace employment=0 if missing(employment)
gen double trade_change=cond(vintage=="base", focal_change, instrument_change)
gen double component=(employment/total_employment)*(trade_change/national_employment)/(price_index/100)/1000*(10/years)
collapse (sum) exposure=component (firstnm) population, by(area period vintage)
reshape wide exposure population, i(area period) j(vintage) string
rename exposurebase x
rename exposureearly z

save exposures.dta, replace

import delimited using outcomes.csv, clear varnames(1)
isid area period
merge 1:1 area period using exposures.dta, assert(match) nogen
assert !missing(change_pp,period,control,x,z,populationbase)
count
assert r(N)==72
quietly summarize x if area==0 & period==0, meanonly
scalar x00=r(mean)
quietly summarize x if area==0 & period==1, meanonly
scalar x01=r(mean)
quietly summarize z if area==0 & period==0, meanonly
scalar z00=r(mean)
ivregress 2sls change_pp period control (x=z) [aw=populationbase]
assert e(N)==72
scalar slope=_b[x]
file open answer using answers.txt, write replace
file write answer "ANSWER: iv_slope estimate=" %21.12g (slope) " se=NA n_obs=72" _n
file write answer "ANSWER: exposure_area0_period0 estimate=" %21.12g (x00) " se=NA n_obs=72" _n
file write answer "ANSWER: exposure_area0_period1 estimate=" %21.12g (x01) " se=NA n_obs=72" _n
file write answer "ANSWER: instrument_area0_period0 estimate=" %21.12g (z00) " se=NA n_obs=72" _n
file close answer
