version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear
generate double day = date(date, "YMD")
assert !missing(day, sales, vix)
assert sales > 0 & vix > 0
sort day
assert day > day[_n-1] if _n > 1

generate double log_sales = log(sales)
generate double log_vix = log(vix)
forvalues k = 1/15 {
    generate double lag_`k' = log_vix[_n-`k'] - log_vix[_n-`k'-1]
}
egen byte missing_lag = rowmiss(lag_1-lag_15)
keep if missing_lag == 0 & !missing(log_sales)

mata:
X = J(st_nobs(), 1, 1)
for (k = 1; k <= 15; k++) X = (X, st_data(., sprintf("lag_%g", k)))
y = st_data(., "log_sales")
b = qrsolve(X, y)
N = rows(X)
p = cols(X)
u = y - X*b
scores = X :* u
meat = scores' * scores
for (j = 1; j <= 15; j++) {
    product = scores[|j+1,1\N,p|]' * scores[|1,1\N-j,p|]
    meat = meat + (1-j/16) * (product + product')
}
bread = invsym(X'*X)
V = (N/(N-p)) * bread * meat * bread
c = (0 \ J(15,1,1))
st_numscalar("response", c'*b)
st_numscalar("response_se", sqrt(c'*V*c))
st_numscalar("lag1_est", b[2])
st_numscalar("lag1_se", sqrt(V[2,2]))
st_numscalar("lag15_est", b[16])
st_numscalar("lag15_se", sqrt(V[16,16]))
st_numscalar("n_used", N)
end

display "ANSWER: cumulative_response estimate=" %21.12f scalar(response) " se=" %21.12f scalar(response_se) " n_obs=" %12.0f scalar(n_used)
display "ANSWER: lag_1 estimate=" %21.12f scalar(lag1_est) " se=" %21.12f scalar(lag1_se) " n_obs=" %12.0f scalar(n_used)
display "ANSWER: lag_15 estimate=" %21.12f scalar(lag15_est) " se=" %21.12f scalar(lag15_se) " n_obs=" %12.0f scalar(n_used)
