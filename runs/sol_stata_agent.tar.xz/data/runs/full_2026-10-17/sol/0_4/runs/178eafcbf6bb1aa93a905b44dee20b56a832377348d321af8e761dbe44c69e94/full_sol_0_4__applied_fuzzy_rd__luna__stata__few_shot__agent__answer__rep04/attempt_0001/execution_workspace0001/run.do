version 19.0
clear all
set more off
set linesize 255
import delimited using "./input.csv", clear asdouble
keep if abs(score) < 1
generate byte right = score >= 0
generate double weight = 1 - abs(score)
count
scalar n_obs = r(N)

mata:
s = st_data(., "score")
r = st_data(., "right")
w = st_data(., "weight")
Y = st_data(., ("earnings", "participated"))
X = (1 :- r, (1 :- r) :* s, r, r :* s)
c = (-1 \ 0 \ 1 \ 0)
bread = invsym(X' * (w :* X))
B = bread * X' * (w :* Y)
e = Y - X * B
jumps = c' * B
loading = w :* (X * bread * c)
influence = loading :* e
joint = influence' * influence
gradient = (1 / jumps[2] \ -jumps[1] / jumps[2]^2)
st_numscalar("reduced_form", jumps[1])
st_numscalar("first_stage", jumps[2])
st_numscalar("treatment_effect", jumps[1] / jumps[2])
st_numscalar("reduced_form_se", sqrt(joint[1,1]))
st_numscalar("first_stage_se", sqrt(joint[2,2]))
st_numscalar("treatment_effect_se", sqrt(gradient' * joint * gradient))
end

display "ANSWER: treatment_effect estimate=" %21.12f treatment_effect " se=" %21.12f treatment_effect_se " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f reduced_form " se=" %21.12f reduced_form_se " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f first_stage " se=" %21.12f first_stage_se " n_obs=" %12.0f n_obs
