version 17.0
clear all
set more off
set linesize 255
import delimited using "./input.csv", clear varnames(1) asdouble
keep if !missing(score, earnings, participated) & abs(score) < 1
generate double weight = 1 - abs(score)
generate double right = score >= 0
generate double slope_left = score * (score < 0)
generate double slope_right = score * (score >= 0)
quietly count
scalar n_obs = r(N)

mata:
X = st_data(., ("right", "slope_left", "slope_right"))
X = J(rows(X), 1, 1), X
Y = st_data(., ("earnings", "participated"))
w = st_data(., "weight")
WX = X :* w
bread = invsym(X' * WX)
B = bread * (WX' * Y)
U = Y - X * B
influence = (WX * bread[,2])
rf = B[2,1]
fs = B[2,2]
v_rf = sum((influence :* U[,1]):^2)
v_fs = sum((influence :* U[,2]):^2)
cov_rf_fs = sum((influence :* U[,1]) :* (influence :* U[,2]))
te = rf / fs
v_te = v_rf / fs^2 + rf^2 * v_fs / fs^4 - 2 * rf * cov_rf_fs / fs^3
st_numscalar("reduced_form", rf)
st_numscalar("first_stage", fs)
st_numscalar("treatment_effect", te)
st_numscalar("se_reduced_form", sqrt(v_rf))
st_numscalar("se_first_stage", sqrt(v_fs))
st_numscalar("se_treatment_effect", sqrt(v_te))
st_numscalar("cov_rf_fs", cov_rf_fs)
end

display "ANSWER: treatment_effect estimate=" %21.12f treatment_effect " se=" %21.12f se_treatment_effect " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f reduced_form " se=" %21.12f se_reduced_form " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f first_stage " se=" %21.12f se_first_stage " n_obs=" %12.0f n_obs
