clear all
set more off
set linesize 255

import delimited using "./input.csv", clear asdouble
generate double trading_date = date(date, "YMD")
assert !missing(trading_date)
sort trading_date
generate double log_sales = ln(sales)
generate double log_vix = ln(vix)
generate double change_vix = log_vix - log_vix[_n-1] if _n > 1
forvalues j = 1/15 {
    generate double lag_`j' = change_vix[_n-`j'] if _n > `j'
}

local regressors
forvalues j = 1/15 {
    local regressors "`regressors' lag_`j'"
}
keep if !missing(log_sales)
forvalues j = 1/15 {
    keep if !missing(lag_`j')
}
regress log_sales `regressors'
scalar n_reg = e(N)
assert n_reg == _N

mata:
    X = J(st_nobs(), 1, 1), st_data(., tokens(st_local("regressors")))
    y = st_data(., "log_sales")
    b_stata = st_matrix("e(b)")
    beta = (b_stata[1,16], b_stata[1,1..15])'
    N = rows(X)
    u = y - X*beta
    G = X :* u
    S = G' * G
    for (j=1; j<=15; j++) {
        A = G[(j+1)::N, .]
        B = G[1::(N-j), .]
        S = S + (1-j/16) * (A'*B + B'*A)
    }
    Q = invsym(X'*X)
    V = (N/(N-16)) * Q*S*Q
    st_matrix("V_NW", V)
end

matrix b = e(b)
matrix V = V_NW
scalar cumulative_response = 0
forvalues j = 1/15 {
    scalar cumulative_response = cumulative_response + b[1,`j']
}
scalar cumulative_variance = 0
forvalues i = 2/16 {
    forvalues j = 2/16 {
        scalar cumulative_variance = cumulative_variance + V[`i',`j']
    }
}
scalar cumulative_se = sqrt(cumulative_variance)
scalar lag_1_estimate = b[1,1]
scalar lag_1_se = sqrt(V[2,2])
scalar lag_15_estimate = b[1,15]
scalar lag_15_se = sqrt(V[16,16])

display "ANSWER: cumulative_response estimate=" %21.12f cumulative_response " se=" %21.12f cumulative_se " n_obs=" %12.0f n_reg
display "ANSWER: lag_1 estimate=" %21.12f lag_1_estimate " se=" %21.12f lag_1_se " n_obs=" %12.0f n_reg
display "ANSWER: lag_15 estimate=" %21.12f lag_15_estimate " se=" %21.12f lag_15_se " n_obs=" %12.0f n_reg
