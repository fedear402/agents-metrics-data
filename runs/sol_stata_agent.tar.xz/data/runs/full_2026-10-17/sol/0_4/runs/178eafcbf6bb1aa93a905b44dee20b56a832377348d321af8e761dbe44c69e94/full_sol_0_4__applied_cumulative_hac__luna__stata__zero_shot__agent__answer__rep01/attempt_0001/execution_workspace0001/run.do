set more off
set linesize 255
import delimited using "./input.csv", clear varnames(1) asdouble
gen double trading_date = date(date, "YMD")
format trading_date %td
sort trading_date
gen double log_sales = ln(sales)
gen double log_vix = ln(vix)
gen double dlog_vix = log_vix - log_vix[_n-1]
forvalues k = 1/15 {
    gen double lag_`k' = dlog_vix[_n-`k']
}
regress log_sales lag_1-lag_15
scalar sample_n = e(N)
gen byte in_sample = e(sample)
predict double residual if e(sample), resid

mata:
X = st_data(., ("lag_1", "lag_2", "lag_3", "lag_4", "lag_5", "lag_6", "lag_7", "lag_8", "lag_9", "lag_10", "lag_11", "lag_12", "lag_13", "lag_14", "lag_15"), "in_sample")
X = X, J(rows(X), 1, 1)
u = st_data(., "residual", "in_sample")
N = rows(X)
Z = X :* u
S = quadcross(Z, Z)
for (j=1; j<=15; j++) {
    C = quadcross(Z[(j+1)..N,.], Z[1..(N-j),.])
    S = S + (1-j/16) * (C + C')
}
XXi = invsym(quadcross(X, X))
V = (N/(N-16)) * XXi * S * XXi
w = (J(15, 1, 1) \ 0)
st_numscalar("se_cumulative", sqrt(w' * V * w))
st_numscalar("se_lag_1", sqrt(V[1,1]))
st_numscalar("se_lag_15", sqrt(V[15,15]))
end

scalar cumulative_response = 0
forvalues k = 1/15 {
    scalar cumulative_response = cumulative_response + _b[lag_`k']
}
display "ANSWER: cumulative_response estimate=" %21.12f cumulative_response " se=" %21.12f se_cumulative " n_obs=" %12.0f sample_n
display "ANSWER: lag_1 estimate=" %21.12f _b[lag_1] " se=" %21.12f se_lag_1 " n_obs=" %12.0f sample_n
display "ANSWER: lag_15 estimate=" %21.12f _b[lag_15] " se=" %21.12f se_lag_15 " n_obs=" %12.0f sample_n
