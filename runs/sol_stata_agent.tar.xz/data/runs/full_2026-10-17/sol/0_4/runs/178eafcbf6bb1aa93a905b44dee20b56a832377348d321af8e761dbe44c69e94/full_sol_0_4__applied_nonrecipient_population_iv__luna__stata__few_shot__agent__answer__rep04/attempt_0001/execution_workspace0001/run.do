clear all
set more off
set linesize 255

set type double
import delimited using households.csv, clear varnames(1) case(preserve)
keep if recipient == 0
assert inlist(eligible,0,1)
assert weight > 0
count
scalar n_obs = r(N)
generate double g0 = 1-eligible
generate double g1 = eligible
generate double x0 = baseline*g0
generate double x1 = baseline*g1
generate double d0 = dose*g0
generate double d1 = dose*g1
generate double z0 = instrument*g0
generate double z1 = instrument*g1
ivregress 2sls outcome g0 g1 x0 x1 (d0 d1 = z0 z1) [aw=weight], noconstant
scalar b0 = _b[d0]
scalar b1 = _b[d1]
quietly summarize dose [aw=weight] if eligible == 0, meanonly
scalar e0 = b0*r(mean)
quietly summarize dose [aw=weight] if eligible == 1, meanonly
scalar e1 = b1*r(mean)
import delimited using census.csv, clear varnames(1) case(preserve)
assert inlist(eligible,0,1)
assert nonrecipient_population >= 0
quietly summarize nonrecipient_population if eligible == 0, meanonly
scalar n0 = r(sum)
quietly summarize nonrecipient_population if eligible == 1, meanonly
scalar n1 = r(sum)
scalar ep = (e0*n0+e1*n1)/(n0+n1)
display "ANSWER: ineligible_effect estimate=" %24.16g (e0) " se=NA n_obs=" %9.0f (n_obs)
display "ANSWER: eligible_nonrecipient_effect estimate=" %24.16g (e1) " se=NA n_obs=" %9.0f (n_obs)
display "ANSWER: population_effect estimate=" %24.16g (ep) " se=NA n_obs=" %9.0f (n_obs)
exit, clear
