clear all
set more off
set linesize 255
import delimited using "./input.csv", clear
sort date
gen long trading_index = _n
tsset trading_index
gen double log_sales = ln(sales)
gen double log_vix = ln(vix)
gen double dlog_vix = D.log_vix
forvalues k = 1/15 {
    gen double lag_`k' = L`k'.dlog_vix
}
regress log_sales lag_1-lag_15
scalar N = e(N)
scalar b1 = _b[lag_1]
scalar b15 = _b[lag_15]
gen byte regression_sample = e(sample)
mata:
    X = st_data(., ("lag_1", "lag_2", "lag_3", "lag_4", "lag_5", "lag_6", "lag_7", "lag_8", "lag_9", "lag_10", "lag_11", "lag_12", "lag_13", "lag_14", "lag_15"), "regression_sample")
    X = J(rows(X), 1, 1), X
    y = st_data(., "log_sales", "regression_sample")
    n = rows(X)
    b = qrsolve(X, y)
    u = y - X*b
    G = X :* u
    S = G'G
    for (j=1; j<=15; j++) {
        C = G[(j+1)..n,]' * G[1..(n-j),]
        S = S + (1-j/16)*(C+C')
    }
    V = (n/(n-16))*invsym(X'X)*S*invsym(X'X)
    a = (0 \ J(15,1,1))
    st_numscalar("cumulative_response", sum(b[2..16]))
    st_numscalar("se_cumulative", sqrt(a'*V*a))
    st_numscalar("se_lag1", sqrt(V[2,2]))
    st_numscalar("se_lag15", sqrt(V[16,16]))
end
display "ANSWER: cumulative_response estimate=" %21.12f cumulative_response " se=" %21.12f se_cumulative " n_obs=" %12.0f N
display "ANSWER: lag_1 estimate=" %21.12f b1 " se=" %21.12f se_lag1 " n_obs=" %12.0f N
display "ANSWER: lag_15 estimate=" %21.12f b15 " se=" %21.12f se_lag15 " n_obs=" %12.0f N
