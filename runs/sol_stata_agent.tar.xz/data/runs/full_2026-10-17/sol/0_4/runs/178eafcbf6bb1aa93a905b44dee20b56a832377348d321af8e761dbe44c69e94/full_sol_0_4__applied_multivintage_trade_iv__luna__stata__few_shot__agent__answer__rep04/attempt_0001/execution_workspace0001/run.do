clear all
set more off
set type double

import delimited using crosswalk.csv, clear varnames(1)
isid code
tempfile cross
save `cross'

import delimited using trade.csv, clear varnames(1)
merge m:1 code using `cross', assert(match) nogen
isid period industry
tempfile trade
save `trade'

import delimited using employment.csv, clear varnames(1)
isid area period vintage industry
preserve
collapse (sum) national_employment=employment, by(period vintage industry)
tempfile national
save `national'
restore
tempfile employment
save `employment'

import delimited using outcomes.csv, clear varnames(1)
isid area period
tempfile outcomes
save `outcomes'

import delimited using areas.csv, clear varnames(1)
isid area period vintage
joinby period using `trade'
merge 1:1 area period vintage industry using `employment', keep(master match) nogen
replace employment=0 if missing(employment)
merge m:1 period vintage industry using `national', assert(match) nogen
assert national_employment>0
assert total_employment>0
assert price_index>0 & years>0

gen double contribution=employment/total_employment/(price_index/100)/1000*(10/years)
gen double x_part=contribution*us_change/national_employment if vintage=="base"
gen double z_part=contribution*other_change/national_employment if vintage=="early"
gen double base_population=population if vintage=="base"
collapse (sum) x=x_part z=z_part (max) base_population, by(area period)
isid area period
assert _N==72
merge 1:1 area period using `outcomes', assert(match) nogen
assert !missing(change_pp, control, period, x, z, base_population)
assert base_population>0
quietly ivregress 2sls change_pp period control (x=z) [aw=base_population]
assert e(N)==72
local slope=_b[x]
quietly summarize x if area==0 & period==0, meanonly
assert r(N)==1
local x00=r(mean)
quietly summarize x if area==0 & period==1, meanonly
assert r(N)==1
local x01=r(mean)
quietly summarize z if area==0 & period==0, meanonly
assert r(N)==1
local z00=r(mean)
display "ANSWER: iv_slope estimate=" %21.14g `slope' " se=NA n_obs=72"
display "ANSWER: exposure_area0_period0 estimate=" %21.14g `x00' " se=NA n_obs=72"
display "ANSWER: exposure_area0_period1 estimate=" %21.14g `x01' " se=NA n_obs=72"
display "ANSWER: instrument_area0_period0 estimate=" %21.14g `z00' " se=NA n_obs=72"
exit, clear
