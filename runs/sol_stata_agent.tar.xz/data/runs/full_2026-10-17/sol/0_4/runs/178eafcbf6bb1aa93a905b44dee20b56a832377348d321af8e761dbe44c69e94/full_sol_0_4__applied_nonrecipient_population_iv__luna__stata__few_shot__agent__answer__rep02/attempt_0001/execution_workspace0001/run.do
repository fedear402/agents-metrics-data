clear all
set more off
set type double
capture log close
log using run.log, text replace

import delimited using households.csv, clear varnames(1) numericcols(_all)
keep if recipient == 0
count
scalar n_obs = r(N)
assert inlist(eligible, 0, 1)
assert weight > 0 & !missing(weight)

generate double ineligible = 1 - eligible
generate double dose0 = dose * ineligible
generate double dose1 = dose * eligible
generate double baseline0 = baseline * ineligible
generate double baseline1 = baseline * eligible
generate double instrument0 = instrument * ineligible
generate double instrument1 = instrument * eligible

ivregress 2sls outcome ineligible eligible baseline0 baseline1 ///
    (dose0 dose1 = instrument0 instrument1) [aw=weight], noconstant
scalar slope0 = _b[dose0]
scalar slope1 = _b[dose1]
summarize dose [aw=weight] if eligible == 0, meanonly
scalar ineligible_effect = slope0 * r(mean)
summarize dose [aw=weight] if eligible == 1, meanonly
scalar eligible_nonrecipient_effect = slope1 * r(mean)

import delimited using census.csv, clear varnames(1) numericcols(_all)
assert inlist(eligible, 0, 1)
assert nonrecipient_population > 0 & !missing(nonrecipient_population)
isid eligible
quietly summarize nonrecipient_population if eligible == 0, meanonly
scalar population0 = r(mean)
quietly summarize nonrecipient_population if eligible == 1, meanonly
scalar population1 = r(mean)
scalar population_effect = (population0 * ineligible_effect + ///
    population1 * eligible_nonrecipient_effect) / (population0 + population1)

display "ANSWER: ineligible_effect estimate=" strtrim(string(ineligible_effect, "%24.16g")) " se=NA n_obs=" strtrim(string(n_obs, "%9.0f"))
display "ANSWER: eligible_nonrecipient_effect estimate=" strtrim(string(eligible_nonrecipient_effect, "%24.16g")) " se=NA n_obs=" strtrim(string(n_obs, "%9.0f"))
display "ANSWER: population_effect estimate=" strtrim(string(population_effect, "%24.16g")) " se=NA n_obs=" strtrim(string(n_obs, "%9.0f"))

file open answers using output.txt, write replace
file write answers "ANSWER: ineligible_effect estimate=" (strtrim(string(ineligible_effect, "%24.16g"))) " se=NA n_obs=" (strtrim(string(n_obs, "%9.0f"))) _n
file write answers "ANSWER: eligible_nonrecipient_effect estimate=" (strtrim(string(eligible_nonrecipient_effect, "%24.16g"))) " se=NA n_obs=" (strtrim(string(n_obs, "%9.0f"))) _n
file write answers "ANSWER: population_effect estimate=" (strtrim(string(population_effect, "%24.16g"))) " se=NA n_obs=" (strtrim(string(n_obs, "%9.0f"))) _n
file close answers
log close
exit, clear
