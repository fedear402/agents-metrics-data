d <- read.csv('input.csv')
stopifnot(nrow(d) == 1200, all(!is.na(d[,c('score','earnings','participated')])))
d <- d[abs(d$score) < 1, ]
stopifnot(nrow(d) == 598, all(d$score > -1 & d$score < 1))
side <- function(s) {
  z <- d[if (s == 'left') d$score < 0 else d$score >= 0, ]
  x <- z$score; w <- 1 - abs(x)
  sw <- sum(w); sx <- sum(w*x); sxx <- sum(w*x*x); den <- sw*sxx - sx*sx
  intercept_weights <- w * (sxx - sx*x) / den
  y <- as.matrix(z[,c('earnings','participated')])
  intercept <- as.vector(crossprod(intercept_weights, y))
  slope <- as.vector(crossprod(w*(sw*x-sx)/den, y))
  residual <- y - matrix(rep(intercept, each=length(x)), nrow=length(x)) - outer(x, slope)
  list(n=nrow(z), intercept=intercept, inf=residual*intercept_weights)
}
l <- side('left'); r <- side('right')
disc <- r$intercept-l$intercept
V <- crossprod(r$inf)+crossprod(l$inf)
te <- disc[1]/disc[2]
g <- c(1/disc[2], -disc[1]/disc[2]^2)
cat(sprintf('n_left=%d n_right=%d n_total=%d\n', l$n, r$n, nrow(d)))
cat(sprintf('reduced_form=%.12f se=%.12f\n', disc[1], sqrt(V[1,1])))
cat(sprintf('first_stage=%.12f se=%.12f\n', disc[2], sqrt(V[2,2])))
cat(sprintf('covariance=%.12f\n', V[1,2]))
cat(sprintf('treatment_effect=%.12f se=%.12f\n', te, sqrt(drop(t(g)%*%V%*%g))))
