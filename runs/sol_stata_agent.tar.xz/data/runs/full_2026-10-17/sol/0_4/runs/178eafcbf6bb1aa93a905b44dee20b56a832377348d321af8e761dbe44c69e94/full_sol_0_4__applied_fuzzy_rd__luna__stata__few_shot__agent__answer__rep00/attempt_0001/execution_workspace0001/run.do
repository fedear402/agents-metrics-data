version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear varnames(1) asdouble
keep if abs(score) < 1
generate double right = score >= 0
generate double right_score = right * score
generate double weight = 1 - abs(score)
count
scalar n_obs = r(N)

mata:
X = (J(st_nobs(), 1, 1), st_data(., "right"), st_data(., "score"), st_data(., "right_score"))
Y = st_data(., ("earnings", "participated"))
w = st_data(., "weight")
bread = invsym(X' * (w :* X))
B = bread * X' * (w :* Y)
U = Y - X * B
contrast = (0 \ 1 \ 0 \ 0)
jumps = contrast' * B
loading = w :* (X * bread * contrast)
contributions = loading :* U
V = contributions' * contributions
gradient = (1 / jumps[2] \ -jumps[1] / jumps[2]^2)
st_numscalar("reduced_form", jumps[1])
st_numscalar("first_stage", jumps[2])
st_numscalar("treatment_effect", jumps[1] / jumps[2])
st_numscalar("reduced_form_se", sqrt(V[1,1]))
st_numscalar("first_stage_se", sqrt(V[2,2]))
st_numscalar("treatment_effect_se", sqrt(gradient' * V * gradient))
st_numscalar("jump_covariance", V[1,2])
end

display "ANSWER: treatment_effect estimate=" %21.12f treatment_effect " se=" %21.12f treatment_effect_se " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f reduced_form " se=" %21.12f reduced_form_se " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f first_stage " se=" %21.12f first_stage_se " n_obs=" %12.0f n_obs
