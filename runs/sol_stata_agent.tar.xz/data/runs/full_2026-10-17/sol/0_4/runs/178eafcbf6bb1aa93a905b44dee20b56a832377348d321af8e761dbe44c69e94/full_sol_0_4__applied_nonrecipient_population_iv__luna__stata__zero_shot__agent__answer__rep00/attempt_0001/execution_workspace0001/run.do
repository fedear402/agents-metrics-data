clear all
set more off
set linesize 255
import delimited using "households.csv", clear varnames(1) asdouble
keep if recipient == 0
assert inlist(eligible, 0, 1)
assert weight > 0
assert !missing(dose, baseline, instrument, outcome, weight, eligible)
generate double ineligible = 1 - eligible
generate double base_ineligible = baseline * ineligible
generate double base_eligible = baseline * eligible
generate double dose_ineligible = dose * ineligible
generate double dose_eligible = dose * eligible
generate double inst_ineligible = instrument * ineligible
generate double inst_eligible = instrument * eligible
ivregress 2sls outcome ineligible eligible base_ineligible base_eligible (dose_ineligible dose_eligible = inst_ineligible inst_eligible) [aw=weight], noconstant
assert e(N) == _N
local nobs = e(N)
quietly summarize dose [aw=weight] if e(sample) & eligible == 0, meanonly
scalar effect0 = _b[dose_ineligible] * r(mean)
quietly summarize dose [aw=weight] if e(sample) & eligible == 1, meanonly
scalar effect1 = _b[dose_eligible] * r(mean)
preserve
import delimited using "census.csv", clear varnames(1) asdouble
assert _N == 2
assert inlist(eligible, 0, 1)
quietly summarize nonrecipient_population if eligible == 0, meanonly
scalar pop0 = r(mean)
quietly summarize nonrecipient_population if eligible == 1, meanonly
scalar pop1 = r(mean)
restore
scalar effectpop = (pop0 * effect0 + pop1 * effect1) / (pop0 + pop1)
display "ANSWER: ineligible_effect estimate=" %21.12g effect0 " se=NA n_obs=" %9.0f `nobs'
display "ANSWER: eligible_nonrecipient_effect estimate=" %21.12g effect1 " se=NA n_obs=" %9.0f `nobs'
display "ANSWER: population_effect estimate=" %21.12g effectpop " se=NA n_obs=" %9.0f `nobs'
