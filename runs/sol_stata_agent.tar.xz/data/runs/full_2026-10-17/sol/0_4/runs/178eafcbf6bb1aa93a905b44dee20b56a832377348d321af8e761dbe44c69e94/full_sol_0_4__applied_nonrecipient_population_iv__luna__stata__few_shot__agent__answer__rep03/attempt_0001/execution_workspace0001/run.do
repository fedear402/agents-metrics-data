clear all
set more off
set type double
set linesize 255

import delimited using "households.csv", clear varnames(1)
keep if recipient == 0
assert inlist(eligible, 0, 1)
assert weight > 0
count
scalar N = r(N)
generate double g0 = 1 - eligible
generate double g1 = eligible
generate double b0 = baseline*g0
generate double b1 = baseline*g1
generate double d0 = dose*g0
generate double d1 = dose*g1
generate double z0 = instrument*g0
generate double z1 = instrument*g1
ivregress 2sls outcome g0 g1 b0 b1 (d0 d1 = z0 z1) [aw=weight], noconstant
assert e(N) == N
scalar beta0 = _b[d0]
scalar beta1 = _b[d1]
summarize dose [aw=weight] if eligible == 0, meanonly
scalar effect0 = beta0*r(mean)
summarize dose [aw=weight] if eligible == 1, meanonly
scalar effect1 = beta1*r(mean)
import delimited using "census.csv", clear varnames(1)
assert _N == 2
summarize nonrecipient_population if eligible == 0, meanonly
scalar pop0 = r(mean)
summarize nonrecipient_population if eligible == 1, meanonly
scalar pop1 = r(mean)
scalar effectpop = (pop0*effect0 + pop1*effect1)/(pop0 + pop1)
display "ANSWER: ineligible_effect estimate=" %24.16g effect0 " se=NA n_obs=" %8.0f N
display "ANSWER: eligible_nonrecipient_effect estimate=" %24.16g effect1 " se=NA n_obs=" %8.0f N
display "ANSWER: population_effect estimate=" %24.16g effectpop " se=NA n_obs=" %8.0f N
exit, clear
