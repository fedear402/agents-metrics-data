version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear asdouble
keep if !missing(score, participated, earnings) & abs(score)<1
generate double right = score>=0
generate double right_score = right*score
generate double weight = 1-abs(score)

mata:
X = (J(st_nobs(),1,1), st_data(.,"right"), st_data(.,"score"), st_data(.,"right_score"))
w = st_data(.,"weight")
Y = st_data(.,("earnings","participated"))
B = invsym(X'*(w:*X))*X'*(w:*Y)
E = Y-X*B
c = (0\1\0\0)
jump = c'*B
loading = w:*(X*invsym(X'*(w:*X))*c)
influence = loading:*E
V = influence'*influence
g = (1/jump[2]\-jump[1]/jump[2]^2)
st_numscalar("rf",jump[1])
st_numscalar("fs",jump[2])
st_numscalar("te",jump[1]/jump[2])
st_numscalar("rf_se",sqrt(V[1,1]))
st_numscalar("fs_se",sqrt(V[2,2]))
st_numscalar("te_se",sqrt(g'*V*g))
st_numscalar("n",rows(Y))
end

display "ANSWER: treatment_effect estimate=" %21.12f te " se=" %21.12f te_se " n_obs=" %12.0f n
display "ANSWER: reduced_form estimate=" %21.12f rf " se=" %21.12f rf_se " n_obs=" %12.0f n
display "ANSWER: first_stage estimate=" %21.12f fs " se=" %21.12f fs_se " n_obs=" %12.0f n
