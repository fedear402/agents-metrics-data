import csv
import numpy as np
with open('households.csv', newline='') as f:
    rows = [r for r in csv.DictReader(f) if int(r['recipient']) == 0]
assert len(rows) == 300
results = []
for group in (0, 1):
    part = [r for r in rows if int(r['eligible']) == group]
    w = np.array([float(r['weight']) for r in part])
    dose = np.array([float(r['dose']) for r in part])
    baseline = np.array([float(r['baseline']) for r in part])
    instrument = np.array([float(r['instrument']) for r in part])
    y = np.array([float(r['outcome']) for r in part])
    x = np.column_stack((np.ones(len(part)), baseline, dose))
    z = np.column_stack((np.ones(len(part)), baseline, instrument))
    beta = np.linalg.solve(z.T @ (w[:, None] * x), z.T @ (w * y))
    effect = beta[-1] * np.average(dose, weights=w)
    results.append(effect)
    print(group, len(part), beta[-1], np.average(dose, weights=w), effect)
with open('census.csv', newline='') as f:
    pop = {int(r['eligible']): int(r['nonrecipient_population']) for r in csv.DictReader(f)}
print('population', (results[0]*pop[0]+results[1]*pop[1])/(pop[0]+pop[1]))
