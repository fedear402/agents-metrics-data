clear all
set more off
set linesize 255
set type double

import delimited using "crosswalk.csv", clear varnames(1)
isid code
tempfile crosswalk trade areas employment
save `crosswalk'

import delimited using "trade.csv", clear varnames(1)
merge m:1 code using `crosswalk', assert(match) nogen
isid period industry
keep period industry us_change other_change price_index years
save `trade'

import delimited using "areas.csv", clear varnames(1)
isid area period vintage
save `areas'

import delimited using "employment.csv", clear varnames(1)
isid area period vintage industry
save `employment'

use `areas', clear
joinby period using `trade'
merge 1:1 area period vintage industry using `employment', assert(master match) nogen
replace employment = 0 if missing(employment)
bysort period vintage industry: egen double national_employment = total(employment)
assert national_employment > 0
gen double contribution = .
replace contribution = (employment/total_employment)*(us_change/national_employment)/(price_index/100)/1000*(10/years) if vintage == "base"
replace contribution = (employment/total_employment)*(other_change/national_employment)/(price_index/100)/1000*(10/years) if vintage == "early"
collapse (sum) exposure=contribution (firstnm) population, by(area period vintage)
reshape wide exposure population, i(area period) j(vintage) string
rename exposurebase x
rename exposureearly z
rename populationbase weight
keep area period x z weight
tempfile exposures
save `exposures'

import delimited using "outcomes.csv", clear varnames(1)
isid area period
merge 1:1 area period using `exposures', assert(match) nogen
assert !missing(change_pp, period, control, x, z, weight)
assert weight > 0
count
assert r(N) == 72

quietly summarize x if area == 0 & period == 0, meanonly
scalar x00 = r(mean)
quietly summarize x if area == 0 & period == 1, meanonly
scalar x01 = r(mean)
quietly summarize z if area == 0 & period == 0, meanonly
scalar z00 = r(mean)

ivregress 2sls change_pp period control (x = z) [aw=weight]
assert e(N) == 72
scalar iv_slope = _b[x]
quietly regress x period control z [aw=weight]
predict double fitted_x, xb
quietly regress change_pp period control fitted_x [aw=weight]
assert abs(_b[fitted_x] - iv_slope) < 1e-10
display "CHECK: independent fitted-value 2SLS slope=" %24.16g _b[fitted_x]
display "ANSWER: iv_slope estimate=" %24.16g iv_slope " se=NA n_obs=72"
display "ANSWER: exposure_area0_period0 estimate=" %24.16g x00 " se=NA n_obs=72"
display "ANSWER: exposure_area0_period1 estimate=" %24.16g x01 " se=NA n_obs=72"
display "ANSWER: instrument_area0_period0 estimate=" %24.16g z00 " se=NA n_obs=72"
exit, clear
