version 19.0
clear all
set more off
set linesize 255
import delimited using "./input.csv", clear

generate double trading_date = date(date, "YMD")
assert !missing(trading_date, sales, vix)
assert sales > 0 & vix > 0
sort trading_date
generate long observation = _n
tsset observation
generate double log_sales = log(sales)
generate double log_vix = log(vix)
generate double vix_change = D.log_vix
forvalues j = 1/15 {
    generate double lag_`j' = L`j'.vix_change
}
keep if !missing(log_sales, lag_1, lag_2, lag_3, lag_4, lag_5, lag_6, lag_7, lag_8, lag_9, lag_10, lag_11, lag_12, lag_13, lag_14, lag_15)

mata:
N = st_nobs()
p = 16
X = J(N,p,1)
for (j=1; j<=15; j++) X[,j+1] = st_data(.,sprintf("lag_%g",j))
y = st_data(.,"log_sales")
b = qrsolve(X,y)
e = y-X*b
scores = X:*e
meat = scores'*scores
for (j=1; j<=15; j++) {
    cross = scores[|j+1,1\N,p|]'*scores[|1,1\N-j,p|]
    meat = meat + (1-j/16)*(cross+cross')
}
bread = invsym(X'*X)
V = (N/(N-p))*bread*meat*bread
c = (0\J(15,1,1))
st_numscalar("n_obs",N)
st_numscalar("cumulative_response",(c'*b)[1,1])
st_numscalar("cumulative_se",sqrt((c'*V*c)[1,1]))
st_numscalar("lag_1_estimate",b[2])
st_numscalar("lag_1_se",sqrt(V[2,2]))
st_numscalar("lag_15_estimate",b[16])
st_numscalar("lag_15_se",sqrt(V[16,16]))
end

display "ANSWER: cumulative_response estimate=" %21.15g cumulative_response " se=" %21.15g cumulative_se " n_obs=" %12.0f n_obs
display "ANSWER: lag_1 estimate=" %21.15g lag_1_estimate " se=" %21.15g lag_1_se " n_obs=" %12.0f n_obs
display "ANSWER: lag_15 estimate=" %21.15g lag_15_estimate " se=" %21.15g lag_15_se " n_obs=" %12.0f n_obs
