clear all
set more off
set linesize 200

import delimited using "households.csv", clear varnames(1) asdouble
keep if recipient == 0
assert inlist(eligible, 0, 1)
assert weight > 0
count
local n_obs = r(N)

generate double ineligible = 1 - eligible
generate double dose_ineligible = dose * ineligible
generate double dose_eligible = dose * eligible
generate double baseline_ineligible = baseline * ineligible
generate double baseline_eligible = baseline * eligible
generate double instrument_ineligible = instrument * ineligible
generate double instrument_eligible = instrument * eligible

ivregress 2sls outcome ineligible eligible baseline_ineligible baseline_eligible ///
    (dose_ineligible dose_eligible = instrument_ineligible instrument_eligible) ///
    [aweight=weight], noconstant
assert e(N) == `n_obs'
scalar slope_ineligible = _b[dose_ineligible]
scalar slope_eligible = _b[dose_eligible]

quietly summarize dose [aweight=weight] if eligible == 0, meanonly
scalar effect_ineligible = slope_ineligible * r(mean)
quietly summarize dose [aweight=weight] if eligible == 1, meanonly
scalar effect_eligible = slope_eligible * r(mean)

preserve
import delimited using "census.csv", clear varnames(1) asdouble
assert inlist(eligible, 0, 1)
assert nonrecipient_population > 0
quietly summarize nonrecipient_population if eligible == 0, meanonly
assert r(N) == 1
scalar population_ineligible = r(mean)
quietly summarize nonrecipient_population if eligible == 1, meanonly
assert r(N) == 1
scalar population_eligible = r(mean)
restore
scalar effect_population = (population_ineligible * effect_ineligible + ///
    population_eligible * effect_eligible) / (population_ineligible + population_eligible)

file open answers using "answers.txt", write replace
local estimate1 : display %21.12g scalar(effect_ineligible)
local estimate2 : display %21.12g scalar(effect_eligible)
local estimate3 : display %21.12g scalar(effect_population)
local estimate1 = strtrim("`estimate1'")
local estimate2 = strtrim("`estimate2'")
local estimate3 = strtrim("`estimate3'")
display as result "ANSWER: ineligible_effect estimate=`estimate1' se=NA n_obs=`n_obs'"
display as result "ANSWER: eligible_nonrecipient_effect estimate=`estimate2' se=NA n_obs=`n_obs'"
display as result "ANSWER: population_effect estimate=`estimate3' se=NA n_obs=`n_obs'"
file write answers "ANSWER: ineligible_effect estimate=`estimate1' se=NA n_obs=`n_obs'" _n
file write answers "ANSWER: eligible_nonrecipient_effect estimate=`estimate2' se=NA n_obs=`n_obs'" _n
file write answers "ANSWER: population_effect estimate=`estimate3' se=NA n_obs=`n_obs'" _n
file close answers
