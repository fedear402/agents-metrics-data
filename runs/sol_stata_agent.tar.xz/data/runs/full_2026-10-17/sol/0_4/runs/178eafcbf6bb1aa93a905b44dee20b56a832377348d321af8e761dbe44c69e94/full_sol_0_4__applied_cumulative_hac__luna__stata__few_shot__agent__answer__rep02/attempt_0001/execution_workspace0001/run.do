version 19.0
clear all
set more off
set linesize 255
import delimited using "./input.csv", clear varnames(1) asdouble
generate double day = date(date, "YMD")
assert !missing(day, sales, vix)
assert sales > 0 & vix > 0
sort day
generate long trading_observation = _n
tsset trading_observation
generate double log_sales = log(sales)
generate double log_vix = log(vix)
generate double vix_change = D.log_vix
forvalues k = 1/15 {
    generate double lag_`k' = L`k'.vix_change
}
unab lagvars : lag_1-lag_15
egen byte missing_count = rowmiss(log_sales `lagvars')
keep if missing_count == 0
mata:
X = (J(st_nobs(), 1, 1), st_data(., tokens("`lagvars'")))
y = st_data(., "log_sales")
b = qrsolve(X, y)
u = y - X*b
N = rows(X)
p = cols(X)
S = X :* u
M = S'*S
for (j=1; j<=15; j++) {
    C = S[|j+1,1\N,p|]' * S[|1,1\N-j,p|]
    M = M + (1-j/16)*(C+C')
}
B = invsym(X'*X)
V = (N/(N-p))*B*M*B
c = (0 \ J(15,1,1))
st_numscalar("answer_cumulative", c'*b)
st_numscalar("se_cumulative", sqrt(c'*V*c))
st_numscalar("answer_lag1", b[2])
st_numscalar("se_lag1", sqrt(V[2,2]))
st_numscalar("answer_lag15", b[16])
st_numscalar("se_lag15", sqrt(V[16,16]))
st_numscalar("answer_n", N)
end
display "ANSWER: cumulative_response estimate=" %21.12f scalar(answer_cumulative) " se=" %21.12f scalar(se_cumulative) " n_obs=" %12.0f scalar(answer_n)
display "ANSWER: lag_1 estimate=" %21.12f scalar(answer_lag1) " se=" %21.12f scalar(se_lag1) " n_obs=" %12.0f scalar(answer_n)
display "ANSWER: lag_15 estimate=" %21.12f scalar(answer_lag15) " se=" %21.12f scalar(se_lag15) " n_obs=" %12.0f scalar(answer_n)
