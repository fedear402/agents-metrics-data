clear all
set more off
set type double

tempfile areas crosswalk industries cells trade exposures baseareas

import delimited "areas.csv", clear varnames(1)
isid area period vintage
save `areas'

import delimited "crosswalk.csv", clear varnames(1)
isid code
save `crosswalk'
keep industry
duplicates drop
assert _N == 4
save `industries'

import delimited "employment.csv", clear varnames(1)
isid area period vintage industry
save `cells'

import delimited "trade.csv", clear varnames(1)
isid period code
merge m:1 code using `crosswalk', assert(match) nogen
isid period industry
save `trade'

use `areas', clear
cross using `industries'
merge 1:1 area period vintage industry using `cells', assert(master match) nogen
replace employment = 0 if missing(employment)
bysort period vintage industry: egen double national_employment = total(employment)
assert national_employment > 0
merge m:1 period industry using `trade', assert(match) nogen
gen double contribution = (employment / total_employment) * ///
    (cond(vintage == "base", us_change, other_change) / national_employment) / ///
    (price_index / 100) / 1000 * (10 / years)
collapse (sum) exposure = contribution, by(area period vintage)
reshape wide exposure, i(area period) j(vintage) string
rename exposurebase x
rename exposureearly z
save `exposures'

use `areas', clear
keep if vintage == "base"
keep area period population
save `baseareas'

import delimited "outcomes.csv", clear varnames(1)
isid area period
merge 1:1 area period using `baseareas', assert(match) nogen
merge 1:1 area period using `exposures', assert(match) nogen
assert _N == 72
assert !missing(change_pp, period, control, x, z, population)
ivregress 2sls change_pp period control (x = z) [aw = population]
assert e(N) == 72
scalar iv_slope = _b[x]
quietly summarize x if area == 0 & period == 0, meanonly
assert r(N) == 1
scalar exposure_area0_period0 = r(mean)
quietly summarize x if area == 0 & period == 1, meanonly
assert r(N) == 1
scalar exposure_area0_period1 = r(mean)
quietly summarize z if area == 0 & period == 0, meanonly
assert r(N) == 1
scalar instrument_area0_period0 = r(mean)
display "ANSWER: iv_slope estimate=" %21.12g iv_slope " se=NA n_obs=72"
display "ANSWER: exposure_area0_period0 estimate=" %21.12g exposure_area0_period0 " se=NA n_obs=72"
display "ANSWER: exposure_area0_period1 estimate=" %21.12g exposure_area0_period1 " se=NA n_obs=72"
display "ANSWER: instrument_area0_period0 estimate=" %21.12g instrument_area0_period0 " se=NA n_obs=72"
