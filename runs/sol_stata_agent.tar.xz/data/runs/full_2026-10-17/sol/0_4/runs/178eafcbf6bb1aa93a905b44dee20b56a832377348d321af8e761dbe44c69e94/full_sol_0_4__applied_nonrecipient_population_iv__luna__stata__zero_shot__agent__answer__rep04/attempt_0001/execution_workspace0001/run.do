clear all
set more off
set linesize 255
import delimited using households.csv, clear varnames(1) asdouble
keep if recipient == 0
assert inlist(eligible, 0, 1)
assert weight > 0 & !missing(weight, dose, baseline, instrument, outcome)

generate double g0 = 1 - eligible
generate double g1 = eligible
generate double b0 = baseline * g0
generate double b1 = baseline * g1
generate double d0 = dose * g0
generate double d1 = dose * g1
generate double z0 = instrument * g0
generate double z1 = instrument * g1

quietly summarize dose [aw=weight] if eligible == 0, meanonly
scalar mean0 = r(mean)
quietly summarize dose [aw=weight] if eligible == 1, meanonly
scalar mean1 = r(mean)

ivregress 2sls outcome g0 g1 b0 b1 (d0 d1 = z0 z1) [aw=weight], noconstant
scalar n_used = e(N)
assert n_used == _N
scalar effect0 = _b[d0] * mean0
scalar effect1 = _b[d1] * mean1

preserve
import delimited using census.csv, clear varnames(1) asdouble
assert _N == 2
quietly summarize nonrecipient_population if eligible == 0, meanonly
scalar pop0 = r(mean)
quietly summarize nonrecipient_population if eligible == 1, meanonly
scalar pop1 = r(mean)
restore
scalar effectpop = (pop0 * effect0 + pop1 * effect1) / (pop0 + pop1)

display "ANSWER: ineligible_effect estimate=" %21.12g effect0 " se=NA n_obs=" %10.0f n_used
display "ANSWER: eligible_nonrecipient_effect estimate=" %21.12g effect1 " se=NA n_obs=" %10.0f n_used
display "ANSWER: population_effect estimate=" %21.12g effectpop " se=NA n_obs=" %10.0f n_used
