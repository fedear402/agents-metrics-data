clear all
set more off
set linesize 255
set type double

import delimited using "./input.csv", clear
assert !missing(score, participated, earnings)
keep if abs(score) < 1
generate byte right = score >= 0
generate double right_score = right * score
generate double weight = 1 - abs(score)

mata:
    X = (J(st_nobs(), 1, 1), st_data(., "right"), st_data(., "score"), st_data(., "right_score"))
    w = st_data(., "weight")
    y = st_data(., "earnings")
    d = st_data(., "participated")
    A = invsym(quadcross(X, w, X))
    by = A * quadcross(X, w, y)
    bd = A * quadcross(X, w, d)
    uy = y - X * by
    ud = d - X * bd
    wy = w :* uy
    wd = w :* ud
    Vyy = A * quadcross(X, wy :^ 2, X) * A
    Vdd = A * quadcross(X, wd :^ 2, X) * A
    Vyd = A * quadcross(X, wy :* wd, X) * A
    rf = by[2]
    fs = bd[2]
    vrf = Vyy[2,2]
    vfs = Vdd[2,2]
    crf_fs = Vyd[2,2]
    st_numscalar("reduced_form", rf)
    st_numscalar("first_stage", fs)
    st_numscalar("treatment_effect", rf / fs)
    st_numscalar("reduced_form_se", sqrt(vrf))
    st_numscalar("first_stage_se", sqrt(vfs))
    st_numscalar("treatment_effect_se", sqrt(vrf / fs^2 + rf^2 * vfs / fs^4 - 2 * rf * crf_fs / fs^3))
    st_numscalar("n_obs", rows(X))
end

display "ANSWER: treatment_effect estimate=" %21.12f scalar(treatment_effect) " se=" %21.12f scalar(treatment_effect_se) " n_obs=" %12.0f scalar(n_obs)
display "ANSWER: reduced_form estimate=" %21.12f scalar(reduced_form) " se=" %21.12f scalar(reduced_form_se) " n_obs=" %12.0f scalar(n_obs)
display "ANSWER: first_stage estimate=" %21.12f scalar(first_stage) " se=" %21.12f scalar(first_stage_se) " n_obs=" %12.0f scalar(n_obs)
