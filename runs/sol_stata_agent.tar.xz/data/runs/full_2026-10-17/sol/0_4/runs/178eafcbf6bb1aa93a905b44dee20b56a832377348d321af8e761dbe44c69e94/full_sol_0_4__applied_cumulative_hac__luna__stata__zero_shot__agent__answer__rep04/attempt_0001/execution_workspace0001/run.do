clear all
set more off
set linesize 255
import delimited using "./input.csv", clear asdouble
generate double trading_date = daily(date, "YMD")
format trading_date %td
sort trading_date
generate long trading_index = _n
tsset trading_index
generate double ln_sales = ln(sales)
generate double ln_vix = ln(vix)
generate double d_ln_vix = D.ln_vix
forvalues j = 1/15 {
    generate double dv_l`j' = L`j'.d_ln_vix
}
regress ln_sales dv_l1-dv_l15
generate byte sample = e(sample)
scalar n_reg = e(N)
predict double uhat if sample, residuals

mata:
    vars = tokens("dv_l1 dv_l2 dv_l3 dv_l4 dv_l5 dv_l6 dv_l7 dv_l8 dv_l9 dv_l10 dv_l11 dv_l12 dv_l13 dv_l14 dv_l15")
    Z = st_data(., vars, "sample")
    N = rows(Z)
    X = (Z, J(N, 1, 1))
    u = st_data(., "uhat", "sample")
    bread = invsym(cross(X, X))
    meat = cross(X :* u, X :* u)
    for (j=1; j<=15; j++) {
        G = cross(X[(j+1)..N,.] :* u[(j+1)..N], X[1..(N-j),.] :* u[1..(N-j)])
        meat = meat + (1-j/16)*(G+G')
    }
    V = (N/(N-16))*bread*meat*bread
    b = st_matrix("e(b)")'
    c = (J(15,1,1) \ 0)
    st_numscalar("cum_est", c'b)
    st_numscalar("cum_se", sqrt(c'V*c))
    st_numscalar("lag1_est", b[1])
    st_numscalar("lag1_se", sqrt(V[1,1]))
    st_numscalar("lag15_est", b[15])
    st_numscalar("lag15_se", sqrt(V[15,15]))
end

display "ANSWER: cumulative_response estimate=" %21.12f cum_est " se=" %21.12f cum_se " n_obs=" %12.0f n_reg
display "ANSWER: lag_1 estimate=" %21.12f lag1_est " se=" %21.12f lag1_se " n_obs=" %12.0f n_reg
display "ANSWER: lag_15 estimate=" %21.12f lag15_est " se=" %21.12f lag15_se " n_obs=" %12.0f n_reg
