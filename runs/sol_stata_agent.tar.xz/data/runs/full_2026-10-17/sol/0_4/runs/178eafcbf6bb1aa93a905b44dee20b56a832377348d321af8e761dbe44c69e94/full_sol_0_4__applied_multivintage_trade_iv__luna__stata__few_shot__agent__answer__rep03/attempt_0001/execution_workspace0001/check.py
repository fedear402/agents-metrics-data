import csv
from collections import defaultdict
import numpy as np

def read(name):
    with open(name, newline='') as f:
        return list(csv.DictReader(f))
industry = {r['code']: int(r['industry']) for r in read('crosswalk.csv')}
trade = {(int(r['period']), industry[r['code']]): r for r in read('trade.csv')}
areas = {(int(r['area']), int(r['period']), r['vintage']): r for r in read('areas.csv')}
emp = defaultdict(float)
national = defaultdict(float)
for r in read('employment.csv'):
    a, p, v, j = int(r['area']), int(r['period']), r['vintage'], int(r['industry'])
    value = float(r['employment'])
    emp[a,p,v,j] = value
    national[p,v,j] += value
outcomes = {(int(r['area']), int(r['period'])): r for r in read('outcomes.csv')}
rows=[]
for (a,p), outcome in sorted(outcomes.items()):
    values=[]
    for vintage, change in [('base','us_change'),('early','other_change')]:
        total=float(areas[a,p,vintage]['total_employment'])
        exposure=sum(emp[a,p,vintage,j]/total * float(trade[p,j][change])/national[p,vintage,j] / (float(trade[p,j]['price_index'])/100) /1000 * (10/float(trade[p,j]['years'])) for j in range(4))
        values.append(exposure)
    rows.append((a,p,values[0],values[1],float(outcome['control']),float(outcome['change_pp']),float(areas[a,p,'base']['population'])))
assert len(rows)==72
A=np.array([[1,r[1],r[4]] for r in rows])
x=np.array([r[2] for r in rows]); z=np.array([r[3] for r in rows]); y=np.array([r[5] for r in rows]); w=np.array([r[6] for r in rows])
# Weighted Frisch-Waugh-Lovell identity for the just-identified IV slope.
xr=x-A@np.linalg.solve(A.T@(w[:,None]*A),A.T@(w*x))
zr=z-A@np.linalg.solve(A.T@(w[:,None]*A),A.T@(w*z))
yr=y-A@np.linalg.solve(A.T@(w[:,None]*A),A.T@(w*y))
slope=np.sum(w*zr*yr)/np.sum(w*zr*xr)
print('independent_iv_slope',format(slope,'.16g'))
for a,p in [(0,0),(0,1)]:
    r=next(r for r in rows if r[0]==a and r[1]==p)
    print('area',a,'period',p,'x',format(r[2],'.16g'),'z',format(r[3],'.16g'))
print('rows',len(rows),'positive_weights',all(r[6]>0 for r in rows))
