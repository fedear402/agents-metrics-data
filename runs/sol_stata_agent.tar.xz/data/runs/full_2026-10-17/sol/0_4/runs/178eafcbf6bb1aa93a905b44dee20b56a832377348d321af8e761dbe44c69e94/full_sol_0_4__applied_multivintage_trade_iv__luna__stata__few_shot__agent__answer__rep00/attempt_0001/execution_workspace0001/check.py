import csv
from collections import defaultdict

def rows(path):
    with open(path, newline='') as f:
        return list(csv.DictReader(f))
industry = {r['code']: int(r['industry']) for r in rows('crosswalk.csv')}
trade = {(int(r['period']), industry[r['code']]): r for r in rows('trade.csv')}
areas = {(int(r['area']),int(r['period']),r['vintage']):r for r in rows('areas.csv')}
emp = {(int(r['area']),int(r['period']),r['vintage'],int(r['industry'])):float(r['employment']) for r in rows('employment.csv')}
nat=defaultdict(float)
for (a,p,v,j),e in emp.items(): nat[p,v,j]+=e
exposure={}
for (a,p,v),r in areas.items():
    exposure[a,p,v]=sum(emp.get((a,p,v,j),0.0)/float(r['total_employment'])*float(trade[p,j]['us_change' if v=='base' else 'other_change'])/nat[p,v,j]/(float(trade[p,j]['price_index'])/100)/1000*(10/float(trade[p,j]['years'])) for j in range(4))
obs=[]
for r in rows('outcomes.csv'):
    a,p=int(r['area']),int(r['period'])
    obs.append((float(areas[a,p,'base']['population']),[1.0,float(p),float(r['control']),exposure[a,p,'early']],[1.0,float(p),float(r['control']),exposure[a,p,'base']],float(r['change_pp'])))
assert len(obs)==72
A=[[sum(w*q[i]*h[j] for w,q,h,y in obs) for j in range(4)] for i in range(4)]
b=[sum(w*q[i]*y for w,q,h,y in obs) for i in range(4)]
for k in range(4):
    u=max(range(k,4),key=lambda i:abs(A[i][k])); A[k],A[u]=A[u],A[k]; b[k],b[u]=b[u],b[k]
    t=A[k][k]
    for j in range(k,4):A[k][j]/=t
    b[k]/=t
    for i in range(4):
        if i!=k:
            t=A[i][k]
            for j in range(k,4): A[i][j]-=t*A[k][j]
            b[i]-=t*b[k]
print('n_obs',len(obs))
print('iv_slope',format(b[3],'.16g'))
for a,p,v in [(0,0,'base'),(0,1,'base'),(0,0,'early')]: print('exposure',a,p,v,format(exposure[a,p,v],'.16g'))
