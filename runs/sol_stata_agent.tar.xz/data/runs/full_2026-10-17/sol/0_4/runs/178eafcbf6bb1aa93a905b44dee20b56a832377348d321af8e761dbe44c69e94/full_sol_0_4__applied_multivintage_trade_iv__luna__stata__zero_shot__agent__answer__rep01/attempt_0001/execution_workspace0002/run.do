clear all
set more off
set type double
cd "/private/tmp/prospective_task_7_d2dwjc"

import delimited using crosswalk.csv, clear varnames(1)
isid code
tempfile cross trade areas emp outcomes
save `cross'
import delimited using trade.csv, clear varnames(1)
merge m:1 code using `cross', assert(match) nogen
isid period industry
save `trade'
import delimited using areas.csv, clear varnames(1)
isid area period vintage
save `areas'
import delimited using employment.csv, clear varnames(1)
isid area period vintage industry
save `emp'
import delimited using outcomes.csv, clear varnames(1)
isid area period
save `outcomes'

use `areas', clear
joinby period using `trade'
merge 1:1 area period vintage industry using `emp', keep(master match) nogen
replace employment = 0 if missing(employment)
bysort period vintage industry: egen national_employment = total(employment)
assert national_employment > 0
gen double component = (employment/total_employment) * (us_change/national_employment) / (price_index/100) / 1000 * (10/years) if vintage == "base"
replace component = (employment/total_employment) * (other_change/national_employment) / (price_index/100) / 1000 * (10/years) if vintage == "early"
gen double xpart = component if vintage == "base"
gen double zpart = component if vintage == "early"
gen double weightpart = population if vintage == "base"
collapse (sum) x=xpart z=zpart weight=weightpart, by(area period)
merge 1:1 area period using `outcomes', assert(match) nogen
assert _N == 72
assert !missing(x,z,weight,change_pp,control,period)
assert weight > 0
ivregress 2sls change_pp period control (x = z) [aw=weight]
assert e(N) == 72
scalar iv_slope = _b[x]
summarize x if area == 0 & period == 0, meanonly
scalar exposure_area0_period0 = r(mean)
summarize x if area == 0 & period == 1, meanonly
scalar exposure_area0_period1 = r(mean)
summarize z if area == 0 & period == 0, meanonly
scalar instrument_area0_period0 = r(mean)
file open out using requested_output.txt, write replace
file write out "ANSWER: iv_slope estimate=" %21.12g (scalar(iv_slope)) " se=NA n_obs=72" _n
file write out "ANSWER: exposure_area0_period0 estimate=" %21.12g (scalar(exposure_area0_period0)) " se=NA n_obs=72" _n
file write out "ANSWER: exposure_area0_period1 estimate=" %21.12g (scalar(exposure_area0_period1)) " se=NA n_obs=72" _n
file write out "ANSWER: instrument_area0_period0 estimate=" %21.12g (scalar(instrument_area0_period0)) " se=NA n_obs=72" _n
file close out
