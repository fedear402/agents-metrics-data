clear all
set more off
set linesize 255
set type double
import delimited using "input.csv", clear varnames(1)

quietly count if !missing(y, group)
scalar n_obs = r(N)
quietly oneway y group
scalar F_stat = r(F)
scalar df_num = r(df_m)
scalar df_den = r(df_r)
scalar p_value = Ftail(df_num, df_den, F_stat)

display "ANSWER: F estimate=" %21.12f F_stat " se=. n_obs=" %12.0f n_obs
display "ANSWER: df_num estimate=" %21.12f df_num " se=. n_obs=" %12.0f n_obs
display "ANSWER: df_den estimate=" %21.12f df_den " se=. n_obs=" %12.0f n_obs
display "ANSWER: p_value estimate=" %21.12f p_value " se=. n_obs=" %12.0f n_obs
