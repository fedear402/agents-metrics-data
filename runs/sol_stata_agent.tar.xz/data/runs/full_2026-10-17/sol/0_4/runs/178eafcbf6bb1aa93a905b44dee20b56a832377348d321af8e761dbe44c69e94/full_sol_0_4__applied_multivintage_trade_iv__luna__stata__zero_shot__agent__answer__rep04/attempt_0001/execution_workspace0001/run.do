clear all
set more off
set linesize 200

import delimited using crosswalk.csv, clear varnames(1) stringcols(_all)
destring industry, replace
isid code
tempfile cross trade areas employment national
save `cross'

import delimited using trade.csv, clear varnames(1) asdouble
merge m:1 code using `cross', assert(match) nogen
isid period industry
save `trade'

import delimited using areas.csv, clear varnames(1) asdouble
isid area period vintage
save `areas'

import delimited using employment.csv, clear varnames(1) asdouble
isid area period vintage industry
save `employment'

* All supplied areas and all four industries define the employment cells.
use `areas', clear
joinby period using `trade'
keep area period vintage total_employment population industry us_change other_change price_index years
merge 1:1 area period vintage industry using `employment', keep(master match) nogen
replace employment = 0 if missing(employment)
tempfile cells
save `cells'

collapse (sum) national_employment=employment, by(period vintage industry)
assert national_employment > 0
save `national'

use `cells', clear
merge m:1 period vintage industry using `national', assert(match) nogen
generate double term = (employment/total_employment) * ///
    (cond(vintage=="base",us_change,other_change)/national_employment) / ///
    (price_index/100) / 1000 * (10/years)
collapse (sum) exposure=term (firstnm) population, by(area period vintage)
reshape wide exposure population, i(area period) j(vintage) string
assert populationbase > 0

tempfile exposures
save `exposures'

import delimited using outcomes.csv, clear varnames(1) asdouble
isid area period
merge 1:1 area period using `exposures', assert(match) nogen
assert !missing(change_pp,period,control,exposurebase,exposureearly,populationbase)
count
assert r(N)==72
rename exposurebase x
rename exposureearly z

ivregress 2sls change_pp period control (x=z) [aw=populationbase]
assert e(N)==72
local slope : display %21.12f _b[x]
quietly summarize x if area==0 & period==0, meanonly
local x0 : display %21.12f r(mean)
quietly summarize x if area==0 & period==1, meanonly
local x1 : display %21.12f r(mean)
quietly summarize z if area==0 & period==0, meanonly
local z0 : display %21.12f r(mean)
display "ANSWER: iv_slope estimate=" strtrim("`slope'") " se=NA n_obs=72"
display "ANSWER: exposure_area0_period0 estimate=" strtrim("`x0'") " se=NA n_obs=72"
display "ANSWER: exposure_area0_period1 estimate=" strtrim("`x1'") " se=NA n_obs=72"
display "ANSWER: instrument_area0_period0 estimate=" strtrim("`z0'") " se=NA n_obs=72"
