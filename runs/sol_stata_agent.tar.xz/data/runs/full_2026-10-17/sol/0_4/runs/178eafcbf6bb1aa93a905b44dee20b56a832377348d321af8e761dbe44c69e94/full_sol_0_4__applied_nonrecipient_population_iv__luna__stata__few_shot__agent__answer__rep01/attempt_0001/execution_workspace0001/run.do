clear all
set more off
set type double
set linesize 255

import delimited using "households.csv", clear varnames(1)
keep if recipient == 0

generate double g0 = 1 - eligible
generate double g1 = eligible
generate double b0 = baseline * g0
generate double b1 = baseline * g1
generate double d0 = dose * g0
generate double d1 = dose * g1
generate double z0 = instrument * g0
generate double z1 = instrument * g1

ivregress 2sls outcome g0 g1 b0 b1 (d0 d1 = z0 z1) [aw=weight], noconstant
scalar n_obs = e(N)
scalar slope0 = _b[d0]
scalar slope1 = _b[d1]

quietly summarize dose [aw=weight] if g0 == 1 & e(sample), meanonly
scalar effect0 = slope0 * r(mean)
quietly summarize dose [aw=weight] if g1 == 1 & e(sample), meanonly
scalar effect1 = slope1 * r(mean)

import delimited using "census.csv", clear varnames(1)
quietly summarize nonrecipient_population if eligible == 0, meanonly
scalar pop0 = r(mean)
quietly summarize nonrecipient_population if eligible == 1, meanonly
scalar pop1 = r(mean)
scalar effect_all = (effect0 * pop0 + effect1 * pop1) / (pop0 + pop1)

display "ANSWER: ineligible_effect estimate=" %20.16g (effect0) " se=NA n_obs=" %5.0f (n_obs)
display "ANSWER: eligible_nonrecipient_effect estimate=" %20.16g (effect1) " se=NA n_obs=" %5.0f (n_obs)
display "ANSWER: population_effect estimate=" %20.16g (effect_all) " se=NA n_obs=" %5.0f (n_obs)
exit, clear
