clear all
set more off
set linesize 255

import delimited using households.csv, clear varnames(1) asdouble
keep if recipient == 0
assert inlist(eligible, 0, 1)
assert weight > 0

generate double x0 = 1 - eligible
generate double x1 = eligible
generate double b0 = baseline * x0
generate double b1 = baseline * x1
generate double d0 = dose * x0
generate double d1 = dose * x1
generate double z0 = instrument * x0
generate double z1 = instrument * x1

ivregress 2sls outcome x0 x1 b0 b1 (d0 d1 = z0 z1) [aweight=weight], noconstant
scalar n_used = e(N)
scalar slope0 = _b[d0]
scalar slope1 = _b[d1]
quietly summarize dose [aweight=weight] if eligible == 0, meanonly
scalar mean0 = r(mean)
quietly summarize dose [aweight=weight] if eligible == 1, meanonly
scalar mean1 = r(mean)
scalar effect0 = slope0 * mean0
scalar effect1 = slope1 * mean1

preserve
import delimited using census.csv, clear varnames(1) asdouble
assert inlist(eligible, 0, 1)
isid eligible
quietly summarize nonrecipient_population if eligible == 0, meanonly
scalar pop0 = r(mean)
quietly summarize nonrecipient_population if eligible == 1, meanonly
scalar pop1 = r(mean)
restore
scalar effectpop = (pop0 * effect0 + pop1 * effect1) / (pop0 + pop1)
display as text "ANSWER: ineligible_effect estimate=" as result %21.12g effect0 as text " se=NA n_obs=" as result %8.0f n_used
display as text "ANSWER: eligible_nonrecipient_effect estimate=" as result %21.12g effect1 as text " se=NA n_obs=" as result %8.0f n_used
display as text "ANSWER: population_effect estimate=" as result %21.12g effectpop as text " se=NA n_obs=" as result %8.0f n_used
