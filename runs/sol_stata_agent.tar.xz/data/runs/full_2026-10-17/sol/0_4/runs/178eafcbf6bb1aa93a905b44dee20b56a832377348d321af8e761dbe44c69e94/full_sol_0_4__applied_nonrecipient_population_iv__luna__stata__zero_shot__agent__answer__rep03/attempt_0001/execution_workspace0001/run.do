clear all
set more off
import delimited using "households.csv", clear varnames(1) asdouble
keep if recipient == 0
assert inlist(eligible, 0, 1)
assert weight > 0
gen double ineligible = 1 - eligible
gen double baseline_ineligible = baseline * ineligible
gen double baseline_eligible = baseline * eligible
gen double dose_ineligible = dose * ineligible
gen double dose_eligible = dose * eligible
gen double instrument_ineligible = instrument * ineligible
gen double instrument_eligible = instrument * eligible

ivregress 2sls outcome ineligible eligible baseline_ineligible baseline_eligible ///
    (dose_ineligible dose_eligible = instrument_ineligible instrument_eligible) ///
    [aweight=weight], noconstant
local n_obs = e(N)
scalar slope_ineligible = _b[dose_ineligible]
scalar slope_eligible = _b[dose_eligible]
quietly summarize dose [aweight=weight] if eligible == 0, meanonly
scalar effect_ineligible = slope_ineligible * r(mean)
quietly summarize dose [aweight=weight] if eligible == 1, meanonly
scalar effect_eligible = slope_eligible * r(mean)

preserve
import delimited using "census.csv", clear varnames(1) asdouble
assert inlist(eligible, 0, 1)
quietly summarize nonrecipient_population if eligible == 0, meanonly
scalar pop_ineligible = r(sum)
quietly summarize nonrecipient_population if eligible == 1, meanonly
scalar pop_eligible = r(sum)
restore
scalar effect_population = (pop_ineligible * effect_ineligible + ///
    pop_eligible * effect_eligible) / (pop_ineligible + pop_eligible)

display "ANSWER: ineligible_effect estimate=" strtrim(string(effect_ineligible, "%21.12g")) " se=NA n_obs=" `n_obs'
display "ANSWER: eligible_nonrecipient_effect estimate=" strtrim(string(effect_eligible, "%21.12g")) " se=NA n_obs=" `n_obs'
display "ANSWER: population_effect estimate=" strtrim(string(effect_population, "%21.12g")) " se=NA n_obs=" `n_obs'
