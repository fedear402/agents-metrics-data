import csv
from collections import defaultdict

def rows(name):
    with open(name, newline='') as f: return list(csv.DictReader(f))
lookup={r['code']:int(r['industry']) for r in rows('crosswalk.csv')}
trade={(int(r['period']),lookup[r['code']]):r for r in rows('trade.csv')}
areas={(int(r['area']),int(r['period']),r['vintage']):r for r in rows('areas.csv')}
emp=defaultdict(float)
nat=defaultdict(float)
for r in rows('employment.csv'):
    a,p,v,j=int(r['area']),int(r['period']),r['vintage'],int(r['industry'])
    emp[a,p,v,j]=float(r['employment']);nat[p,v,j]+=float(r['employment'])
ex={}
for (a,p,v),ar in areas.items():
    ex[a,p,v]=sum(emp[a,p,v,j]/float(ar['total_employment'])*float(trade[p,j]['us_change' if v=='base' else 'other_change'])/nat[p,v,j]/(float(trade[p,j]['price_index'])/100)/1000*(10/float(trade[p,j]['years'])) for j in range(4))
obs=[]
for r in rows('outcomes.csv'):
    a,p=int(r['area']),int(r['period'])
    obs.append((float(r['change_pp']),[1.,float(p),float(r['control']),ex[a,p,'base']],[1.,float(p),float(r['control']),ex[a,p,'early']],float(areas[a,p,'base']['population'])))
assert len(obs)==72
A=[[sum(w*z[i]*x[j] for y,x,z,w in obs) for j in range(4)] for i in range(4)]
b=[sum(w*z[i]*y for y,x,z,w in obs) for i in range(4)]
for k in range(4):
    q=max(range(k,4),key=lambda i:abs(A[i][k]));A[k],A[q]=A[q],A[k];b[k],b[q]=b[q],b[k]
    t=A[k][k];A[k]=[v/t for v in A[k]];b[k]/=t
    for i in range(4):
        if i!=k:
            t=A[i][k];A[i]=[A[i][j]-t*A[k][j] for j in range(4)];b[i]-=t*b[k]
print('n',len(obs),'slope',format(b[3],'.12g'),'x00',format(ex[0,0,'base'],'.12g'),'x01',format(ex[0,1,'base'],'.12g'),'z00',format(ex[0,0,'early'],'.12g'))
