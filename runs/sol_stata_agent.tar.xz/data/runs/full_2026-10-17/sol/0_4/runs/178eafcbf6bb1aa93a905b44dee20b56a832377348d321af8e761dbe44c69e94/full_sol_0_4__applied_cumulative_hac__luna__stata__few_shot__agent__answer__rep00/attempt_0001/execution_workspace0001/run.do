version 19.0
clear all
set more off
set linesize 255
import delimited "./input.csv", clear asdouble

generate double trading_day = date(date, "YMD")
assert !missing(trading_day, sales, vix)
assert sales > 0 & vix > 0
sort trading_day
isid trading_day
generate long trading_observation = _n
tsset trading_observation

generate double log_sales = log(sales)
generate double log_vix = log(vix)
generate double vix_change = D.log_vix
forvalues j = 1/15 {
    generate double lag_`j' = L`j'.vix_change
}
keep if !missing(log_sales, lag_1, lag_15)
assert _N == 704

mata:
names = tokens("lag_1 lag_2 lag_3 lag_4 lag_5 lag_6 lag_7 lag_8 lag_9 lag_10 lag_11 lag_12 lag_13 lag_14 lag_15")
X = (J(st_nobs(), 1, 1), st_data(., names))
y = st_data(., "log_sales")
N = rows(X)
p = cols(X)
b = qrsolve(X, y)
u = y - X*b
scores = X :* u
meat = scores' * scores
for (j=1; j<=15; j++) {
    cross = scores[|j+1,1 \ N,p|]' * scores[|1,1 \ N-j,p|]
    meat = meat + (1-j/16) * (cross + cross')
}
bread = invsym(X' * X)
V = (N/(N-p)) * bread * meat * bread
c = (0 \ J(15,1,1))
estimate = c' * b
standard_error = sqrt(c' * V * c)
printf("ANSWER: cumulative_response estimate=%21.15g se=%21.15g n_obs=%12.0f\n", estimate, standard_error, N)
printf("ANSWER: lag_1 estimate=%21.15g se=%21.15g n_obs=%12.0f\n", b[2], sqrt(V[2,2]), N)
printf("ANSWER: lag_15 estimate=%21.15g se=%21.15g n_obs=%12.0f\n", b[16], sqrt(V[16,16]), N)
end
