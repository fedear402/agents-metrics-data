clear all
set more off
import delimited using "./input.csv", clear
sort date
gen long t=_n
tsset t
gen double y=ln(sales)
gen double lv=ln(vix)
gen double d=D.lv
forvalues k=1/15 {
    gen double x`k'=L`k'.d
}
newey y x1-x15, lag(15)
lincom x1+x2+x3+x4+x5+x6+x7+x8+x9+x10+x11+x12+x13+x14+x15
