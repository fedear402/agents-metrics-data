version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear varnames(1)
generate double day = date(date, "YMD")
assert !missing(day, sales, vix)
assert sales > 0 & vix > 0
sort day
assert day > day[_n-1] if _n > 1
generate double log_sales = log(sales)
generate double log_vix = log(vix)
generate double vix_change = log_vix - log_vix[_n-1] if _n > 1
forvalues k = 1/15 {
    generate double lag_`k' = vix_change[_n-`k'] if _n > `k'
}
local complete "log_sales"
forvalues k = 1/15 {
    local complete "`complete' lag_`k'"
}
egen byte missing_count = rowmiss(`complete')
keep if missing_count == 0

mata:
X = (J(st_nobs(), 1, 1), st_data(., "lag_1"))
for (k=2; k<=15; k++) X = (X, st_data(., sprintf("lag_%g", k)))
y = st_data(., "log_sales")
b = qrsolve(X, y)
N = rows(X)
p = cols(X)
u = y-X*b
S = X :* u
M = S'*S
for (j=1; j<=15; j++) {
    A = S[|j+1,1\N,p|]' * S[|1,1\N-j,p|]
    M = M + (1-j/16)*(A+A')
}
B = invsym(X'*X)
V = (N/(N-p))*B*M*B
c = (0\J(15,1,1))
st_numscalar("answer_n", N)
st_numscalar("answer_cum", c'*b)
st_numscalar("answer_cum_se", sqrt(c'*V*c))
st_numscalar("answer_lag1", b[2])
st_numscalar("answer_lag1_se", sqrt(V[2,2]))
st_numscalar("answer_lag15", b[16])
st_numscalar("answer_lag15_se", sqrt(V[16,16]))
end

display "ANSWER: cumulative_response estimate=" %21.12f scalar(answer_cum) " se=" %21.12f scalar(answer_cum_se) " n_obs=" %12.0f scalar(answer_n)
display "ANSWER: lag_1 estimate=" %21.12f scalar(answer_lag1) " se=" %21.12f scalar(answer_lag1_se) " n_obs=" %12.0f scalar(answer_n)
display "ANSWER: lag_15 estimate=" %21.12f scalar(answer_lag15) " se=" %21.12f scalar(answer_lag15_se) " n_obs=" %12.0f scalar(answer_n)
