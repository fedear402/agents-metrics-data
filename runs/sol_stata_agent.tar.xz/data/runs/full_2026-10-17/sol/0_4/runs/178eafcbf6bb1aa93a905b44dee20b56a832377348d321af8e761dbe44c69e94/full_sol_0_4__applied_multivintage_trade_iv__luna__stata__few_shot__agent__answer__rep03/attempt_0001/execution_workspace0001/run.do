clear all
set more off
set linesize 255
set type double

tempfile crosswalk_data industries trade_data employment_data outcomes_data

import delimited using crosswalk.csv, clear varnames(1)
isid code
save `crosswalk_data'
keep industry
duplicates drop
isid industry
save `industries'

import delimited using trade.csv, clear varnames(1)
merge m:1 code using `crosswalk_data', assert(match) nogen
isid period industry
save `trade_data'

import delimited using employment.csv, clear varnames(1)
isid area period vintage industry
save `employment_data'

import delimited using outcomes.csv, clear varnames(1)
isid area period
save `outcomes_data'

import delimited using areas.csv, clear varnames(1)
isid area period vintage
cross using `industries'
merge 1:1 area period vintage industry using `employment_data', assert(master match) nogen
replace employment = 0 if missing(employment)
by period vintage industry, sort: egen double national_employment = total(employment)
assert national_employment > 0
merge m:1 period industry using `trade_data', assert(match) nogen

gen double xpart = (employment/total_employment)*(us_change/national_employment) ///
    /(price_index/100)/1000*(10/years) if vintage == "base"
gen double zpart = (employment/total_employment)*(other_change/national_employment) ///
    /(price_index/100)/1000*(10/years) if vintage == "early"
gen double regression_weight = population if vintage == "base"
collapse (sum) x=xpart z=zpart (max) regression_weight, by(area period)
merge 1:1 area period using `outcomes_data', assert(match) nogen
isid area period
assert _N == 72
assert !missing(change_pp, period, control, x, z, regression_weight)

quietly ivregress 2sls change_pp period control (x=z) [aw=regression_weight]
assert e(N) == 72
scalar iv_slope = _b[x]
quietly summarize x if area == 0 & period == 0, meanonly
assert r(N) == 1
scalar exposure_area0_period0 = r(mean)
quietly summarize x if area == 0 & period == 1, meanonly
assert r(N) == 1
scalar exposure_area0_period1 = r(mean)
quietly summarize z if area == 0 & period == 0, meanonly
assert r(N) == 1
scalar instrument_area0_period0 = r(mean)

display "ANSWER: iv_slope estimate=" %24.16g iv_slope " se=NA n_obs=72"
display "ANSWER: exposure_area0_period0 estimate=" %24.16g exposure_area0_period0 " se=NA n_obs=72"
display "ANSWER: exposure_area0_period1 estimate=" %24.16g exposure_area0_period1 " se=NA n_obs=72"
display "ANSWER: instrument_area0_period0 estimate=" %24.16g instrument_area0_period0 " se=NA n_obs=72"
exit, clear
