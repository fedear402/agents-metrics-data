version 19.0
clear all
set more off
set linesize 255
import delimited using "./input.csv", clear
keep if !missing(score, participated, earnings) & abs(score)<1
generate double right = score >= 0
generate double left_score = score*(1-right)
generate double right_score = score*right
generate double weight = 1-abs(score)
mata:
    X = (J(st_nobs(),1,1), st_data(.,"right"), st_data(.,"left_score"), st_data(.,"right_score"))
    Y = st_data(.,("earnings","participated"))
    w = st_data(.,"weight")
    bread = invsym(X'*(w:*X))
    B = bread*X'*(w:*Y)
    E = Y-X*B
    c = (0\1\0\0)
    jumps = c'*B
    influence = (w:*(X*bread*c)):*E
    V = influence'*influence
    gradient = (1/jumps[2]\-jumps[1]/jumps[2]^2)
    st_numscalar("rf",jumps[1])
    st_numscalar("fs",jumps[2])
    st_numscalar("te",jumps[1]/jumps[2])
    st_numscalar("rfse",sqrt(V[1,1]))
    st_numscalar("fsse",sqrt(V[2,2]))
    st_numscalar("tese",sqrt(gradient'*V*gradient))
    st_numscalar("n",rows(Y))
end
display "ANSWER: treatment_effect estimate=" %21.12f te " se=" %21.12f tese " n_obs=" %12.0f n
display "ANSWER: reduced_form estimate=" %21.12f rf " se=" %21.12f rfse " n_obs=" %12.0f n
display "ANSWER: first_stage estimate=" %21.12f fs " se=" %21.12f fsse " n_obs=" %12.0f n
