import csv
import numpy as np

with open('households.csv', newline='') as source:
    rows = [r for r in csv.DictReader(source) if int(r['recipient']) == 0]
assert len(rows) == 300
assert {int(r['treated']) for r in rows if int(r['eligible']) == 0} == {0, 1}

x, z, y, w = [], [], [], []
for r in rows:
    e = int(r['eligible'])
    g0, g1 = 1 - e, e
    b, d, iv = (float(r[k]) for k in ('baseline', 'dose', 'instrument'))
    x.append([g0, g1, b*g0, b*g1, d*g0, d*g1])
    z.append([g0, g1, b*g0, b*g1, iv*g0, iv*g1])
    y.append(float(r['outcome']))
    w.append(float(r['weight']))
x, z, y, w = map(np.asarray, (x, z, y, w))
beta = np.linalg.solve(z.T @ (w[:, None] * x), z.T @ (w * y))
means = []
for e in (0, 1):
    group = np.asarray([int(r['eligible']) == e for r in rows])
    means.append(np.average(np.asarray([float(r['dose']) for r in rows])[group], weights=w[group]))
effects = np.asarray([beta[4] * means[0], beta[5] * means[1]])
with open('census.csv', newline='') as source:
    census = {int(r['eligible']): int(r['nonrecipient_population']) for r in csv.DictReader(source)}
population = np.average(effects, weights=[census[0], census[1]])
print('n_obs', len(rows))
print('ineligible treated statuses', sorted({int(r['treated']) for r in rows if int(r['eligible']) == 0}))
print('slopes', beta[4:])
print('weighted mean doses', means)
print('effects', effects, population)
print('moment residual maximum', np.max(np.abs(z.T @ (w * (y - x @ beta)))))
