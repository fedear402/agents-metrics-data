clear all
set more off
set linesize 255
import delimited using "./input.csv", clear asdouble
keep if abs(score) < 1
generate double weight = 1 - abs(score)
generate byte right = score >= 0
generate byte left = score < 0
generate double right_score = right * score
generate double left_score = left * score

mata:
X = st_data(., ("left", "right", "left_score", "right_score"))
w = st_data(., "weight")
y = st_data(., "earnings")
d = st_data(., "participated")
Ainv = invsym(quadcross(X, w, X))
by = Ainv * quadcross(X, w, y)
bd = Ainv * quadcross(X, w, d)
c = (-1, 1, 0, 0)'
ey = y - X * by
ed = d - X * bd
h = (X * Ainv * c) :* w
rf = c' * by
fs = c' * bd
vyy = sum((h :* ey):^2)
vdd = sum((h :* ed):^2)
vyd = sum((h :* ey) :* (h :* ed))
te = rf / fs
vte = vyy / fs^2 + rf^2 * vdd / fs^4 - 2 * rf * vyd / fs^3
st_numscalar("reduced_form", rf)
st_numscalar("first_stage", fs)
st_numscalar("treatment_effect", te)
st_numscalar("se_reduced_form", sqrt(vyy))
st_numscalar("se_first_stage", sqrt(vdd))
st_numscalar("se_treatment_effect", sqrt(vte))
st_numscalar("n_obs", rows(X))
end

display "ANSWER: treatment_effect estimate=" %21.12f scalar(treatment_effect) " se=" %21.12f scalar(se_treatment_effect) " n_obs=" %12.0f scalar(n_obs)
display "ANSWER: reduced_form estimate=" %21.12f scalar(reduced_form) " se=" %21.12f scalar(se_reduced_form) " n_obs=" %12.0f scalar(n_obs)
display "ANSWER: first_stage estimate=" %21.12f scalar(first_stage) " se=" %21.12f scalar(se_first_stage) " n_obs=" %12.0f scalar(n_obs)
