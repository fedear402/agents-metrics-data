import csv
import numpy as np

with open('households.csv', newline='') as file:
    rows = [r for r in csv.DictReader(file) if int(r['recipient']) == 0]
assert len(rows) == 300
assert {int(r['treated']) for r in rows if int(r['eligible']) == 0} == {0, 1}
effects = []
for group in (0, 1):
    subset = [r for r in rows if int(r['eligible']) == group]
    w = np.array([float(r['weight']) for r in subset])
    y = np.array([float(r['outcome']) for r in subset])
    d = np.array([float(r['dose']) for r in subset])
    z = np.array([float(r['instrument']) for r in subset])
    baseline = np.array([float(r['baseline']) for r in subset])
    X = np.column_stack((np.ones(len(subset)), baseline))
    yr = y - X @ np.linalg.solve(X.T @ (w[:, None] * X), X.T @ (w * y))
    dr = d - X @ np.linalg.solve(X.T @ (w[:, None] * X), X.T @ (w * d))
    zr = z - X @ np.linalg.solve(X.T @ (w[:, None] * X), X.T @ (w * z))
    slope = np.dot(w * zr, yr) / np.dot(w * zr, dr)
    mean = np.dot(w, d) / sum(w)
    effects.append(slope * mean)
    print(f'group={group} rows={len(subset)} slope={slope:.12g} weighted_mean_dose={mean:.12g} effect={effects[-1]:.12g}')
with open('census.csv', newline='') as file:
    pops = {int(r['eligible']): int(r['nonrecipient_population']) for r in csv.DictReader(file)}
print(f'population_effect={(pops[0]*effects[0]+pops[1]*effects[1])/sum(pops.values()):.12g}')
