clear all
set more off
set type double

import delimited using crosswalk.csv, clear varnames(1)
isid code
save crosswalk_tmp.dta, replace

import delimited using trade.csv, clear varnames(1)
merge m:1 code using crosswalk_tmp.dta, assert(match) nogen
isid period industry
save trade_tmp.dta, replace
keep period industry
save industry_tmp.dta, replace

import delimited using employment.csv, clear varnames(1)
isid area period vintage industry
save employment_tmp.dta, replace

import delimited using areas.csv, clear varnames(1)
isid area period vintage
joinby period using industry_tmp.dta
merge 1:1 area period vintage industry using employment_tmp.dta, assert(master match) nogen
replace employment=0 if missing(employment)
bysort period vintage industry: egen double national_employment=total(employment)
assert national_employment>0
merge m:1 period industry using trade_tmp.dta, assert(match) nogen

* Trade changes are dollars. Divide by 1000 for thousands of dollars.
gen double base_part=0
gen double early_part=0
replace base_part=(employment/total_employment)*(us_change/national_employment)/(price_index/100)/1000*(10/years) if vintage=="base"
replace early_part=(employment/total_employment)*(other_change/national_employment)/(price_index/100)/1000*(10/years) if vintage=="early"
collapse (sum) x=base_part z=early_part, by(area period)
isid area period
save exposures_tmp.dta, replace

import delimited using outcomes.csv, clear varnames(1)
isid area period
merge 1:1 area period using exposures_tmp.dta, assert(match) nogen
rename change_pp outcome
save outcome_tmp.dta, replace

import delimited using areas.csv, clear varnames(1)
keep if vintage=="base"
keep area period population
merge 1:1 area period using outcome_tmp.dta, assert(match) nogen
assert !missing(outcome, period, control, x, z, population)
assert population>0
count
assert r(N)==72
ivregress 2sls outcome period control (x=z) [aw=population]
assert e(N)==72
scalar iv_slope=_b[x]
quietly summarize x if area==0 & period==0, meanonly
assert r(N)==1
scalar x00=r(mean)
quietly summarize x if area==0 & period==1, meanonly
assert r(N)==1
scalar x01=r(mean)
quietly summarize z if area==0 & period==0, meanonly
assert r(N)==1
scalar z00=r(mean)
local iv_text = strtrim(string(iv_slope,"%22.14g"))
local x00_text = strtrim(string(x00,"%22.14g"))
local x01_text = strtrim(string(x01,"%22.14g"))
local z00_text = strtrim(string(z00,"%22.14g"))
file open answers using requested_output.txt, write replace
file write answers "ANSWER: iv_slope estimate=" "`iv_text'" " se=NA n_obs=72" _n
file write answers "ANSWER: exposure_area0_period0 estimate=" "`x00_text'" " se=NA n_obs=72" _n
file write answers "ANSWER: exposure_area0_period1 estimate=" "`x01_text'" " se=NA n_obs=72" _n
file write answers "ANSWER: instrument_area0_period0 estimate=" "`z00_text'" " se=NA n_obs=72" _n
file close answers
exit, clear
