import csv, math
import numpy as np
rows=list(csv.DictReader(open('input.csv')))
rows.sort(key=lambda r:r['date'])
N0=len(rows)
y=np.array([math.log(float(r['sales'])) for r in rows])
x=np.array([math.log(float(r['vix'])) for r in rows])
dx=np.r_[np.nan,np.diff(x)]
# lag_j at observation t is dlogvix at t-j, using zero-based row indices
L=np.column_stack([np.r_[np.full(j+1,np.nan),dx[:N0-j-1]] for j in range(1,16)])
ok=np.isfinite(y)&np.isfinite(L).all(axis=1)
Y=y[ok]; D=L[ok]; X=np.column_stack([np.ones(len(Y)),D]); n=len(Y)
b=np.linalg.solve(X.T@X,X.T@Y); u=Y-X@b
S=np.zeros((16,16))
for h in range(16):
 w=1-h/16
 for t in range(n-h):
  S+=w*u[t]*u[t+h]*np.outer(X[t],X[t+h])
  if h: S+=w*u[t+h]*u[t]*np.outer(X[t+h],X[t])
V=np.linalg.solve(X.T@X,S)@np.linalg.inv(X.T@X)*n/(n-16)
print('n', n, 'first_date', rows[np.where(ok)[0][0]]['date'], 'last_date', rows[np.where(ok)[0][-1]]['date'])
print('b_cum',b[1:].sum(),'b1',b[1],'b15',b[15])
print('se_cum',np.sqrt(V[1:,1:].sum()),'se1',np.sqrt(V[1,1]),'se15',np.sqrt(V[15,15]))
