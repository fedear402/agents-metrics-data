clear all
set more off
set type double

import delimited using "households.csv", clear
keep if recipient == 0
count
local n_obs = r(N)

generate double ineligible = 1 - eligible
generate double dose_ineligible = dose * ineligible
generate double dose_eligible = dose * eligible
generate double baseline_ineligible = baseline * ineligible
generate double baseline_eligible = baseline * eligible
generate double instrument_ineligible = instrument * ineligible
generate double instrument_eligible = instrument * eligible

ivregress 2sls outcome ineligible eligible baseline_ineligible baseline_eligible ///
    (dose_ineligible dose_eligible = instrument_ineligible instrument_eligible) [aw=weight], noconstant

scalar b0 = _b[dose_ineligible]
scalar b1 = _b[dose_eligible]
summarize dose [aw=weight] if eligible == 0, meanonly
scalar e0 = b0 * r(mean)
summarize dose [aw=weight] if eligible == 1, meanonly
scalar e1 = b1 * r(mean)

import delimited using "census.csv", clear
summarize nonrecipient_population if eligible == 0, meanonly
scalar n0 = r(mean)
summarize nonrecipient_population if eligible == 1, meanonly
scalar n1 = r(mean)
scalar epop = (e0*n0 + e1*n1)/(n0+n1)

display "ANSWER: ineligible_effect estimate=" %24.16g (e0) " se=NA n_obs=" %9.0f (`n_obs')
file open answer using "answers.txt", write text replace
file write answer "ANSWER: ineligible_effect estimate=" %24.16g (e0) " se=NA n_obs=" %9.0f (`n_obs') _n
display "ANSWER: eligible_nonrecipient_effect estimate=" %24.16g (e1) " se=NA n_obs=" %9.0f (`n_obs')
file write answer "ANSWER: eligible_nonrecipient_effect estimate=" %24.16g (e1) " se=NA n_obs=" %9.0f (`n_obs') _n
display "ANSWER: population_effect estimate=" %24.16g (epop) " se=NA n_obs=" %9.0f (`n_obs')
file write answer "ANSWER: population_effect estimate=" %24.16g (epop) " se=NA n_obs=" %9.0f (`n_obs') _n
file close answer
