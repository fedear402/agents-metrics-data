clear all
set more off
set linesize 255
import delimited using "./input.csv", clear

gen double stata_date = date(date, "YMD")
format stata_date %td
sort stata_date
assert !missing(stata_date, sales, vix)
assert sales > 0 & vix > 0

gen double log_sales = ln(sales)
gen double dlog_vix = ln(vix) - ln(vix[_n-1])
forvalues j = 1/15 {
    gen double lag_`j' = dlog_vix[_n-`j']
}
regress log_sales lag_1-lag_15
scalar n = e(N)
scalar b1 = _b[lag_1]
scalar b15 = _b[lag_15]
scalar se1 = .
scalar se15 = .
scalar cum = 0
forvalues j = 1/15 {
    scalar cum = cum + _b[lag_`j']
}

* Bartlett HAC covariance from OLS residual scores, with bandwidth 15.
predict double uh, resid
mkmat lag_1-lag_15 if e(sample), matrix(Z)
mkmat uh if e(sample), matrix(U)
mata:
    z = st_matrix("Z")
    X = J(rows(z), 1, 1), z
    u = st_matrix("U")
    n = rows(X)
    S = quadcross(X, X :* u)
    for (j=1; j<=15; j++) {
        w = 1 - j/16
        G = X[|j+1,1 \ n,cols(X)|]
        H = X[|1,1 \ n-j,cols(X)|]
        gu = u[|j+1,1 \ n,1|]
        hu = u[|1,1 \ n-j,1|]
        S = S + w * (quadcross(G :* gu, H :* hu) + quadcross(H :* hu, G :* gu))
    }
    XXinv = invsym(quadcross(X,X))
    Vhac = (n/(n-16)) * XXinv * S * XXinv
    c = J(1,16,0)
    c[1,2..16] = J(1,15,1)
    secum = sqrt(c*Vhac*c')
    se1 = sqrt(Vhac[2,2])
    se15 = sqrt(Vhac[16,16])
    st_numscalar("secum", secum)
    st_numscalar("se1", se1)
    st_numscalar("se15", se15)
    st_numscalar("v11", Vhac[2,2])
    st_numscalar("v15", Vhac[16,16])
    st_matrix("Vhac_stata", Vhac)
end

scalar se1 = sqrt(0.001329...)
scalar se15 = sqrt(v15)

display "ANSWER: cumulative_response estimate=" %21.12f cum " se=" %21.12f secum " n_obs=" %12.0f n
display "ANSWER: lag_1 estimate=" %21.12f b1 " se=" %21.12f se1 " n_obs=" %12.0f n
display "ANSWER: lag_15 estimate=" %21.12f b15 " se=" %21.12f se15 " n_obs=" %12.0f n
