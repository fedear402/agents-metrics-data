clear all
set more off
set linesize 255
import delimited using "./input.csv", clear
keep if abs(score) < 1
gen byte right = score >= 0
gen double x = score
gen double xr = score*right
gen double w = 1-abs(score)
count
scalar N = r(N)

mata:
X = st_data(., ("right","x","xr"))
w = st_data(., "w")
y = st_data(., ("earnings","participated"))
W = diag(w)
A = invsym(X' * W * X)
B = A * X' * W * y
U = y-X*B
M1 = X' * diag((w:^2):*(U[,1]:^2)) * X
M2 = X' * diag((w:^2):*(U[,2]:^2)) * X
M12 = X' * diag((w:^2):*(U[,1]:*U[,2])) * X
V1 = A*M1*A
V2 = A*M2*A
C12 = A*M12*A
st_numscalar("rf", B[1,1])
st_numscalar("fs", B[1,2])
st_numscalar("vrf", V1[1,1])
st_numscalar("vfs", V2[1,1])
st_numscalar("crf_fs", C12[1,1])
end

scalar te = rf/fs
scalar se_rf = sqrt(vrf)
scalar se_fs = sqrt(vfs)
scalar se_te = sqrt(vrf/(fs^2) + (rf^2)*vfs/(fs^4) - 2*rf*crf_fs/(fs^3))
display "ANSWER: treatment_effect estimate=" %21.12f te " se=" %21.12f se_te " n_obs=" %12.0f N
display "ANSWER: reduced_form estimate=" %21.12f rf " se=" %21.12f se_rf " n_obs=" %12.0f N
display "ANSWER: first_stage estimate=" %21.12f fs " se=" %21.12f se_fs " n_obs=" %12.0f N
