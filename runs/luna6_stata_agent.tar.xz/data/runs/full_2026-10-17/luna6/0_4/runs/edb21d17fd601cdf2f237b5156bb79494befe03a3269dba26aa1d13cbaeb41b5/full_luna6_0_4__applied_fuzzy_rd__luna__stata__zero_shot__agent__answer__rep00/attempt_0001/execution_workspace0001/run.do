clear all
set more off
set linesize 255
import delimited using "./input.csv", clear
keep if abs(score) < 1
gen double weight = 1 - abs(score)
gen double right = score >= 0
gen double x_left = score * (1-right)
gen double x_right = score * right
count
scalar N = r(N)

* Estimate each outcome with the same weighted, side-specific local-linear model.
regress earnings right x_left x_right [aw=weight], nocons vce(robust)
scalar rf = _b[right]
scalar var_rf = _se[right]^2
regress participated right x_left x_right [aw=weight], nocons vce(robust)
scalar fs = _b[right]
scalar var_fs = _se[right]^2

* Joint HC0 covariance of the two intercept discontinuities.
* For analytic weights, regress uses normalized weighted least squares; HC0 is
* the sandwich with observation scores (weight*x*residual) and no df correction.
* Compute cross-covariance from both outcome residual vectors and the shared design.
quietly regress earnings right x_left x_right [aw=weight], nocons
* Build the joint sandwich explicitly from the common design and residuals.
predict double ry, residuals
quietly regress participated right x_left x_right [aw=weight], nocons
predict double rd, residuals

mata:
    X = st_data(., ("right", "x_left", "x_right"))
    w = st_data(., "weight")
    uy = st_data(., "ry")
    ud = st_data(., "rd")
    /* aweights rescale all weights by a common factor; it cancels in HC0. */
    A = invsym(quadcross(X, X :* w))
    Sy = X :* (w :* uy)
    Sd = X :* (w :* ud)
    C = A * (Sy' * Sd) * A
    Vy = A * (Sy' * Sy) * A
    Vd = A * (Sd' * Sd) * A
    st_numscalar("cov_rf_fs", C[1,1])
    st_numscalar("var_rf", Vy[1,1])
    st_numscalar("var_fs", Vd[1,1])
end

scalar se_rf = sqrt(var_rf)
scalar se_fs = sqrt(var_fs)
scalar tau = rf/fs
scalar var_tau = (var_rf/(fs^2)) + ((rf^2)*var_fs/(fs^4)) - (2*rf*cov_rf_fs/(fs^3))
scalar se_tau = sqrt(var_tau)
display "ANSWER: treatment_effect estimate=" %21.12f tau " se=" %21.12f se_tau " n_obs=" %12.0f N
display "ANSWER: reduced_form estimate=" %21.12f rf " se=" %21.12f se_rf " n_obs=" %12.0f N
display "ANSWER: first_stage estimate=" %21.12f fs " se=" %21.12f se_fs " n_obs=" %12.0f N
