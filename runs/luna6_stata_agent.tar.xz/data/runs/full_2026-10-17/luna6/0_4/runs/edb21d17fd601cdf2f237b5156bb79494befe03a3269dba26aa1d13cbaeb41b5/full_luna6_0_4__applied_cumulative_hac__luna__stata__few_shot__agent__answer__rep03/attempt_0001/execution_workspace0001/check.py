import csv, math
import numpy as np
rows=sorted(csv.DictReader(open('input.csv')), key=lambda r:r['date'])
v=np.log(np.array([float(r['vix']) for r in rows])); yall=np.log(np.array([float(r['sales']) for r in rows])); z=np.diff(v)
# For outcomes at zero-based rows 16..719, lag j is change ending at row t-j.
t=np.arange(16,len(rows)); Y=yall[t]; X=np.column_stack([np.ones(len(t)),*[z[t-j] for j in range(1,16)]])
b=np.linalg.lstsq(X,Y,rcond=None)[0]; e=Y-X@b; S=X*e[:,None]; M=S.T@S
for j in range(1,16):
    G=S[j:].T@S[:-j]; M+=(1-j/16)*(G+G.T)
Q=np.linalg.inv(X.T@X); V=(len(Y)/(len(Y)-16))*Q@M@Q
c=np.r_[0,np.ones(15)]
print('n',len(Y),'cum',c@b,'cumse',math.sqrt(c@V@c),'lag1',b[1],math.sqrt(V[1,1]),'lag15',b[15],math.sqrt(V[15,15]))
print('row17 x first/last',X[0,1],X[0,15])
