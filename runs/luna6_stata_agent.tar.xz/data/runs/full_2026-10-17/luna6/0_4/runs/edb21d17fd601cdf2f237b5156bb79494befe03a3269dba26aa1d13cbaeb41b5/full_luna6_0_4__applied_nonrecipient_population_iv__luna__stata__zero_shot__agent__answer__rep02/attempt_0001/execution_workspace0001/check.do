clear all
set more off
import delimited using "households.csv", clear
keep if recipient==0
generate byte u=1-eligible
generate double d0=dose*u
generate double d1=dose*eligible
generate double b0=baseline*u
generate double b1=baseline*eligible
generate double z0=instrument*u
generate double z1=instrument*eligible
ivregress 2sls outcome u eligible b0 b1 (d0 d1 = u eligible b0 b1 z0 z1) [aw=weight], noconstant
display "B0 " %24.16g _b[d0]
display "B1 " %24.16g _b[d1]
quietly summarize dose [aw=weight] if eligible==0
display "M0 " %24.16g r(mean)
quietly summarize dose [aw=weight] if eligible==1
display "M1 " %24.16g r(mean)
