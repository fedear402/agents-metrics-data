version 19.0
clear all
set more off
set linesize 255
import delimited using "./input.csv", clear
keep if abs(score) < 1
gen double w = 1 - abs(score)
gen byte right = score >= 0
gen double x_left = score * (1-right)
gen double x_right = score * right
count
scalar N = r(N)
* Common design: intercept, right indicator, and side-specific score slopes.
* Right-indicator coefficient is the right-minus-left discontinuity.
regress earnings right x_left x_right [aw=w], vce(ols)
scalar rf = _b[right]
scalar var_rf = e(V)[2,2]
regress participated right x_left x_right [aw=w], vce(ols)
scalar fs = _b[right]
scalar var_fs = e(V)[2,2]
* HC0 covariance is formed from the shared weighted estimating contributions.
mata:
X=(J(st_nobs(),1,1),st_data(.,"right"),st_data(.,"x_left"),st_data(.,"x_right"))
w=st_data(.,"w")
Y=st_data(.,("earnings","participated"))
B=invsym(X'*(w:*X))*X'*(w:*Y)
E=Y-X*B
bread=invsym(X'*(w:*X))
C=J(2,2,0)
for (i=1; i<=rows(Y); i++) {
  q=(bread*X[i,.]')*(w[i]*E[i,.])
  C=C+q'*q
}
st_matrix("C",C)
end
scalar var_rf = C[1,1]
scalar var_fs = C[2,2]
scalar cov_rf_fs = C[1,2]
scalar te = rf/fs
scalar grad_rf = 1/fs
scalar grad_fs = -rf/(fs^2)
scalar var_te = grad_rf^2*var_rf + grad_fs^2*var_fs + 2*grad_rf*grad_fs*cov_rf_fs
scalar se_rf=sqrt(var_rf)
scalar se_fs=sqrt(var_fs)
scalar se_te=sqrt(var_te)
display "ANSWER: treatment_effect estimate=" %21.12f te " se=" %21.12f se_te " n_obs=" %12.0f N
display "ANSWER: reduced_form estimate=" %21.12f rf " se=" %21.12f se_rf " n_obs=" %12.0f N
display "ANSWER: first_stage estimate=" %21.12f fs " se=" %21.12f se_fs " n_obs=" %12.0f N
