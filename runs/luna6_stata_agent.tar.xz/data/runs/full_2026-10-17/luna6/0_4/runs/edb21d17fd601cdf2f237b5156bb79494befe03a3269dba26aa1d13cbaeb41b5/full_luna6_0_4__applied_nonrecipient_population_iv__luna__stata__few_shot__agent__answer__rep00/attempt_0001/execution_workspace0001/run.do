clear all
set more off
set type double

import delimited using "households.csv", clear
keep if recipient == 0

* Construct eligibility-specific endogenous regressors and instruments.
generate double ineligible = 1 - eligible
generate double dose_ineligible = dose * ineligible
generate double dose_eligible = dose * eligible
generate double baseline_ineligible = baseline * ineligible
generate double baseline_eligible = baseline * eligible
generate double instrument_ineligible = instrument * ineligible
generate double instrument_eligible = instrument * eligible

* The four exogenous columns are included as their own instruments.
quietly ivregress 2sls outcome ineligible eligible baseline_ineligible baseline_eligible ///
    (dose_ineligible dose_eligible = instrument_ineligible instrument_eligible) [aw=weight], noconstant

scalar beta0 = _b[dose_ineligible]
scalar beta1 = _b[dose_eligible]
quietly summarize dose [aw=weight] if eligible == 0, meanonly
scalar mean_dose0 = r(mean)
quietly summarize dose [aw=weight] if eligible == 1, meanonly
scalar mean_dose1 = r(mean)
scalar ineligible_effect = beta0 * mean_dose0
scalar eligible_nonrecipient_effect = beta1 * mean_dose1

local n = _N
import delimited using "census.csv", clear
quietly summarize nonrecipient_population if eligible == 0, meanonly
scalar pop0 = r(mean)
quietly summarize nonrecipient_population if eligible == 1, meanonly
scalar pop1 = r(mean)
scalar population_effect = (ineligible_effect * pop0 + eligible_nonrecipient_effect * pop1) / (pop0 + pop1)

display "ANSWER: ineligible_effect estimate=" %24.16g (ineligible_effect) " se=NA n_obs=`n'"
display "ANSWER: eligible_nonrecipient_effect estimate=" %24.16g (eligible_nonrecipient_effect) " se=NA n_obs=`n'"
display "ANSWER: population_effect estimate=" %24.16g (population_effect) " se=NA n_obs=`n'"
