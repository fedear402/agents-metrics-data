import csv
import numpy as np

rows = []
with open('input.csv', newline='') as f:
    for r in csv.DictReader(f):
        x = float(r['score'])
        if abs(x) < 1:
            rows.append((x, float(r['participated']), float(r['earnings']), 1-abs(x)))
a = np.asarray(rows)
x, d, y, w = a.T
right = (x >= 0).astype(float)
X = np.column_stack([np.ones(len(x)), right, x, x*right])
C = np.array([0., 1., 0., 0.])
B = np.linalg.inv(X.T @ (w[:, None]*X))
nests, residuals = [], []
for outcome in (y, d):
    beta = B @ X.T @ (w*outcome)
    u = outcome - X @ beta
    # HC0 WLS sandwich, with fixed analytic weights.
    V = B @ (X.T @ ((w*w*u*u)[:, None]*X)) @ B
    nests.append(float(C @ beta))
    residuals.append(u)
    print(f'estimate={C @ beta:.12f} se={np.sqrt(C @ V @ C):.12f}')
meat_cross = X.T @ ((w*w*residuals[0]*residuals[1])[:, None]*X)
Vcross = B @ meat_cross @ B
cov = float(C @ Vcross @ C)
rf, fs = nests
var_rf = float(C @ (B @ (X.T @ ((w*w*residuals[0]**2)[:, None]*X)) @ B) @ C)
var_fs = float(C @ (B @ (X.T @ ((w*w*residuals[1]**2)[:, None]*X)) @ B) @ C)
var_te = var_rf/fs**2 + rf**2*var_fs/fs**4 - 2*rf*cov/fs**3
print(f'n_obs={len(a)} reduced_form={rf:.12f} first_stage={fs:.12f}')
print(f'ratio={rf/fs:.12f} covariance={cov:.12f} delta_se={np.sqrt(var_te):.12f}')
# Identity check: joint HC0 variance must equal the variance of the linearized ratio influence.
grad = np.array([1/fs, -rf/fs**2])
Vjoint = np.array([[var_rf, cov], [cov, var_fs]])
print(f'identity_delta_se={np.sqrt(grad @ Vjoint @ grad):.12f}')
