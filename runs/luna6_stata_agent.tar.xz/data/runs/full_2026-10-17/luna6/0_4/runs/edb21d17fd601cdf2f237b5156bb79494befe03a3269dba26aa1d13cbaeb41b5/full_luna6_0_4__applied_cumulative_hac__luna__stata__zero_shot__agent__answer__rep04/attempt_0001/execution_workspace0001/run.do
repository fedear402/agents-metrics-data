clear all
set more off
set linesize 255
import delimited using "./input.csv", clear
sort date
gen double dlogvix = ln(vix) - ln(vix[_n-1])
forvalues j = 1/15 {
    local shift = `j' + 1
    gen double lag_`j' = dlogvix[_n-`shift']
}
gen double logsales = ln(sales)
regress logsales lag_1-lag_15
scalar n = e(N)
matrix b = e(b)
matrix list b
gen byte sample = e(sample)
keep if sample
predict double residual, resid
mkmat lag_1-lag_15, matrix(D)
matrix X = J(n,1,1), D
mata:
    XX = st_matrix("X")
    uu = st_data(., "residual")
    n = rows(XX)
    S = J(cols(XX), cols(XX), 0)
    for (h=0; h<=15; h++) {
        w = 1-h/16
        for (t=1; t<=n-h; t++) {
            S = S + w*uu[t]*uu[t+h]*XX[t,.]' * XX[t+h,.]
            if (h>0) S = S + w*uu[t+h]*uu[t]*XX[t+h,.]' * XX[t,.]
        }
    }
    B = invsym(XX'XX)
    V = B*S*B*n/(n-16)
    st_matrix("Vnw", V)
end
scalar cum = 0
forvalues j = 1/15 {
    scalar cum = cum + b[1,`j']
}
scalar cumvar = 0
forvalues a = 2/16 {
    forvalues c = 2/16 {
        scalar cumvar = cumvar + Vnw[`a',`c']
    }
}
scalar se_cum = sqrt(cumvar)
scalar se1 = sqrt(Vnw[2,2])
scalar se15 = sqrt(Vnw[16,16])
display "ANSWER: cumulative_response estimate=" %21.12f cum " se=" %21.12f se_cum " n_obs=" %12.0f n
display "ANSWER: lag_1 estimate=" %21.12f b[1,1] " se=" %21.12f se1 " n_obs=" %12.0f n
display "ANSWER: lag_15 estimate=" %21.12f b[1,15] " se=" %21.12f se15 " n_obs=" %12.0f n
