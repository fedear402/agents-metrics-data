clear all
set more off
capture log close
log using "stata.log", text replace

* Build area-industry employment shares, retaining zero cells.
import delimited using "areas.csv", clear
keep if vintage == "base" | vintage == "early"
tempfile area base early emp cross trade nat panel
save `area'

import delimited using "employment.csv", clear
save `emp'
import delimited using "crosswalk.csv", clear
* Crosswalk joins trade codes to industries; employment already uses industry IDs.
save `cross'
import delimited using "trade.csv", clear
merge m:1 code using `cross', assert(match) nogen
save `trade'

* Complete employment matrix to represent omitted cells as zero.
use `area', clear
keep area period vintage
expand 4
bysort area period vintage: gen industry = _n - 1
merge 1:1 area period vintage industry using `emp', keep(master match) nogen
replace employment = 0 if missing(employment)
save `emp', replace

* Calculate national employment by period, vintage, and industry.
collapse (sum) national_employment=employment, by(period vintage industry)
save `nat'

* Shares and trade exposure components, separately for base and early vintages.
use `emp', clear
merge m:1 period vintage industry using `nat', assert(match) nogen
merge m:1 area period vintage using `area', keepusing(total_employment) assert(match) nogen
keep if vintage == "base" | vintage == "early"
gen share = employment / total_employment
save `panel'

* Build focal and instrument exposure components from stated interval units.
use `trade', clear
gen focal = us_change / (price_index / 100.0) / 1000 * (10 / years)
gen instrument = other_change / (price_index / 100.0) / 1000 * (10 / years)
keep period industry focal instrument
save `trade', replace

use `panel', clear
merge m:1 period industry using `trade', assert(match) nogen
gen tx = share * focal / national_employment if vintage == "base"
gen tz = share * instrument / national_employment if vintage == "early"
collapse (sum) x=tx (sum) z=tz, by(area period)
tempfile exposure
save `exposure'

import delimited using "outcomes.csv", clear
merge 1:1 area period using `exposure', assert(match) nogen
preserve
use `area', clear
keep if vintage == "base"
keep area period population
tempfile basepop
save `basepop'
restore
merge 1:1 area period using `basepop', assert(match) nogen
assert _N == 72
assert !missing(change_pp, control, x, z, population)

* Weighted 2SLS: intercept, period, and control are included instruments.
ivregress 2sls change_pp period control (x = z) [pweight=population], vce(robust)
scalar b_x = _b[x]
quietly summarize x if area==0 & period==0, meanonly
quietly summarize x if area==0 & period==0, meanonly
scalar x00 = r(mean)
quietly summarize x if area==0 & period==1, meanonly
scalar x01 = r(mean)
quietly summarize z if area==0 & period==0, meanonly
scalar z00 = r(mean)

file open out using "requested_output.txt", write text replace
file write out "ANSWER: iv_slope estimate=" %21.12g (b_x) " se=NA n_obs=72" _n
file write out "ANSWER: exposure_area0_period0 estimate=" %21.12g (x00) " se=NA n_obs=72" _n
file write out "ANSWER: exposure_area0_period1 estimate=" %21.12g (x01) " se=NA n_obs=72" _n
file write out "ANSWER: instrument_area0_period0 estimate=" %21.12g (z00) " se=NA n_obs=72" _n
file close out
log close
