clear all
set more off
set type double
import delimited using "households.csv", clear varnames(1)
keep if recipient == 0
count
scalar n_obs = r(N)
generate double elig0 = 1 - eligible
generate double elig1 = eligible
generate double dose0 = dose * elig0
generate double dose1 = dose * elig1
generate double base0 = baseline * elig0
generate double base1 = baseline * elig1
generate double inst0 = instrument * elig0
generate double inst1 = instrument * elig1
ivregress 2sls outcome elig0 elig1 base0 base1 (dose0 dose1 = inst0 inst1) [aw=weight], noconstant
scalar b0 = _b[dose0]
scalar b1 = _b[dose1]
summarize dose [aw=weight] if eligible == 0, meanonly
scalar mean0 = r(mean)
summarize dose [aw=weight] if eligible == 1, meanonly
scalar mean1 = r(mean)
scalar ineligible_effect = b0 * mean0
scalar eligible_nonrecipient_effect = b1 * mean1
import delimited using "census.csv", clear varnames(1)
summarize nonrecipient_population if eligible == 0, meanonly
scalar n0 = r(mean)
summarize nonrecipient_population if eligible == 1, meanonly
scalar n1 = r(mean)
scalar population_effect = (ineligible_effect*n0 + eligible_nonrecipient_effect*n1)/(n0+n1)
display "ANSWER: ineligible_effect estimate=" %24.16g ineligible_effect " se=NA n_obs=" %10.0f n_obs
display "ANSWER: eligible_nonrecipient_effect estimate=" %24.16g eligible_nonrecipient_effect " se=NA n_obs=" %10.0f n_obs
display "ANSWER: population_effect estimate=" %24.16g population_effect " se=NA n_obs=" %10.0f n_obs
