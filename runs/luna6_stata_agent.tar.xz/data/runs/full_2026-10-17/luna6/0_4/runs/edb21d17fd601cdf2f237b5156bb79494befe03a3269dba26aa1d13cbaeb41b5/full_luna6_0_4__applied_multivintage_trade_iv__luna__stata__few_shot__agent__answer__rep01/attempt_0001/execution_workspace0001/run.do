clear all
set more off
set type double

import delimited using "crosswalk.csv", clear varnames(1) stringcols(1)
tempfile crosswalk
save `crosswalk'
import delimited using "trade.csv", clear varnames(1) stringcols(1)
destring period, replace
merge m:1 code using `crosswalk', assert(match) nogen
isid period industry
tempfile trade_ind
save `trade_ind'

import delimited using "employment.csv", clear varnames(1) stringcols(3)
collapse (sum) employment, by(period vintage industry)
reshape wide employment, i(period industry) j(vintage) string
rename employmentbase base_industry
rename employmentearly early_industry
tempfile national
save `national'

* Keep area denominators and employment totals from the areas file.
import delimited using "areas.csv", clear varnames(1) stringcols(3)
reshape wide total_employment population, i(area period) j(vintage) string
rename total_employmentbase base_total
rename total_employmentearly early_total
rename populationbase population_base
keep area period base_total early_total population_base
tempfile area_totals
save `area_totals'

* Build a complete area-period-industry grid, then set omitted cells to zero.
import delimited using "areas.csv", clear varnames(1) stringcols(3)
keep area period
duplicates drop
expand 4
bysort area period: gen industry = _n-1
tempfile grid
save `grid'
import delimited using "employment.csv", clear varnames(1) stringcols(3)
reshape wide employment, i(area period industry) j(vintage) string
merge 1:1 area period industry using `grid', assert(match using) nogen
replace employmentbase = 0 if missing(employmentbase)
replace employmentearly = 0 if missing(employmentearly)
rename employmentbase base_emp
rename employmentearly early_emp
merge m:1 area period using `area_totals', assert(match) nogen
merge m:1 period industry using `national', assert(match) nogen
merge m:1 period industry using `trade_ind', assert(match) nogen

gen double xpart = (base_emp/base_total)*(us_change/base_industry)/(price_index/100)/1000*(10/years)
gen double zpart = (early_emp/early_total)*(other_change/early_industry)/(price_index/100)/1000*(10/years)
collapse (sum) x=xpart z=zpart, by(area period)
tempfile exposure
save `exposure'

import delimited using "outcomes.csv", clear varnames(1)
merge 1:1 area period using `exposure', assert(match) nogen
merge 1:1 area period using `area_totals', assert(match) nogen
isid area period
count
assert r(N)==72
ivregress 2sls change_pp period control (x=z) [aw=population_base]
scalar nobs=e(N)
display "ANSWER: iv_slope estimate=" %24.16g _b[x] " se=NA n_obs=" %3.0f nobs
quietly summarize x if area==0 & period==0, meanonly
display "ANSWER: exposure_area0_period0 estimate=" %24.16g r(mean) " se=NA n_obs=" %3.0f nobs
quietly summarize x if area==0 & period==1, meanonly
display "ANSWER: exposure_area0_period1 estimate=" %24.16g r(mean) " se=NA n_obs=" %3.0f nobs
quietly summarize z if area==0 & period==0, meanonly
display "ANSWER: instrument_area0_period0 estimate=" %24.16g r(mean) " se=NA n_obs=" %3.0f nobs
exit, clear
