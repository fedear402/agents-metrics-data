import csv
from collections import defaultdict
import numpy as np

def read(name):
    with open(name, newline='') as f: return list(csv.DictReader(f))
areas=read('areas.csv'); emp=read('employment.csv'); cross=read('crosswalk.csv'); trade=read('trade.csv'); outcomes=read('outcomes.csv')
industry={r['code']:int(r['industry']) for r in cross}
tr={}
for r in trade:
    j=industry[r['code']]; p=int(r['period']); scale=100/(float(r['price_index']))/1000*10/float(r['years'])
    tr[p,j]=(float(r['us_change'])*scale,float(r['other_change'])*scale)
area_info={(int(r['area']),int(r['period']),r['vintage']):r for r in areas}
e={(int(r['area']),int(r['period']),r['vintage'],int(r['industry'])):float(r['employment']) for r in emp}
N=defaultdict(float)
for (a,p,v,j),val in e.items(): N[p,v,j]+=val
exp={}
for a in range(36):
 for p in range(2):
  for v in ('base','early'):
   total=float(area_info[a,p,v]['total_employment']); x=z=0.
   for j in range(4):
    empval=e.get((a,p,v,j),0.)
    tt=tr[p,j]
    x += empval/total*tt[0]/N[p,v,j]
    z += empval/total*tt[1]/N[p,v,j]
   exp[a,p,v]=(x,z)
y={ (int(r['area']),int(r['period'])):float(r['change_pp']) for r in outcomes }
c={ (int(r['area']),int(r['period'])):float(r['control']) for r in outcomes }
pop={(int(r['area']),int(r['period'])):float(r['population']) for r in areas if r['vintage']=='base'}
rows=sorted(y)
X=np.array([[1.,float(p),c[a,p],exp[a,p,'base'][0]] for a,p in rows])
Z=np.array([[1.,float(p),c[a,p],exp[a,p,'early'][1]] for a,p in rows])
yv=np.array([y[k] for k in rows]); w=np.array([pop[k] for k in rows])
WZ=Z*w[:,None]; A=X.T@WZ@np.linalg.solve(Z.T@WZ,Z.T@(X*w[:,None]))
b=X.T@WZ@np.linalg.solve(Z.T@WZ,Z.T@(yv*w))
beta=np.linalg.solve(A,b)
print('rows',len(rows),'unique area-period',len(set(rows)))
print('iv_slope',format(beta[3],'.16g'))
print('exposure_area0_period0',format(exp[0,0,'base'][0],'.16g'))
print('exposure_area0_period1',format(exp[0,1,'base'][0],'.16g'))
print('instrument_area0_period0',format(exp[0,0,'early'][1],'.16g'))
# Algebraic identity: 2SLS equals OLS of weighted projected X on projected y.
PZ=Z@np.linalg.solve(Z.T@(w[:,None]*Z),Z.T*w)
# Compare direct generalized 2SLS normal equations above with alternative compact expression.
Xp=PZ@X; yp=PZ@yv
beta2=np.linalg.solve(X.T@(w[:,None]*Xp),X.T@(w*yp))
print('identity_max_abs_diff',format(np.max(np.abs(beta-beta2)),'.3g'))
