import csv
from collections import defaultdict
import numpy as np

def read(name):
    with open(name, newline="") as f:
        return list(csv.DictReader(f))

crosswalk = {r["code"]: int(r["industry"]) for r in read("crosswalk.csv")}
areas = read("areas.csv")
employment = read("employment.csv")
trade = read("trade.csv")
outcomes = read("outcomes.csv")

area_rows = {(int(r["area"]), int(r["period"]), r["vintage"]): r for r in areas}
emp = defaultdict(float)
national = defaultdict(float)
for r in employment:
    key = (int(r["area"]), int(r["period"]), r["vintage"], int(r["industry"]))
    emp[key] += float(r["employment"])
    national[(int(r["period"]), r["vintage"], int(r["industry"]))] += float(r["employment"])

trade_by = {}
for r in trade:
    code = r["code"]
    industry = crosswalk[code]
    trade_by[(int(r["period"]), industry)] = r

exposure = {}
for area in range(36):
    for period in range(2):
        base = area_rows[(area, period, "base")]
        early = area_rows[(area, period, "early")]
        x = z = 0.0
        for industry in range(4):
            t = trade_by[(period, industry)]
            years = float(t["years"])
            price = float(t["price_index"])
            nb = national[(period, "base", industry)]
            ne = national[(period, "early", industry)]
            eb = emp[(area, period, "base", industry)]
            ee = emp[(area, period, "early", industry)]
            x += (eb / nb) * float(t["us_change"]) / float(base["total_employment"]) \
                 / (price / 100) / 1000 * (10 / years)
            z += (ee / ne) * float(t["other_change"]) / float(early["total_employment"]) \
                 / (price / 100) / 1000 * (10 / years)
        exposure[(area, period)] = (x, z)

outcome_by = {(int(r["area"]), int(r["period"])): r for r in outcomes}
rows = sorted(outcome_by)
assert len(rows) == 72
assert len({crosswalk[c] for c in crosswalk}) == 4
assert len(trade_by) == 8

y = np.array([float(outcome_by[k]["change_pp"]) for k in rows])
x = np.array([exposure[k][0] for k in rows])
z = np.array([exposure[k][1] for k in rows])
period = np.array([k[1] for k in rows], dtype=float)
control = np.array([float(outcome_by[k]["control"]) for k in rows])
w = np.array([float(area_rows[(k[0], k[1], "base")]["population"]) for k in rows])
q = np.column_stack([np.ones(len(rows)), period, control])
X = np.column_stack([q, x])
H = np.column_stack([q, z])
W = np.diag(w)
beta = np.linalg.solve(X.T @ W @ H @ np.linalg.solve(H.T @ W @ H, H.T @ W @ X),
                      X.T @ W @ H @ np.linalg.solve(H.T @ W @ H, H.T @ W @ y))

print(f"n_obs={len(rows)}")
print(f"iv_slope={beta[-1]:.16g}")
print(f"exposure_area0_period0={exposure[(0,0)][0]:.16g}")
print(f"exposure_area0_period1={exposure[(0,1)][0]:.16g}")
print(f"instrument_area0_period0={exposure[(0,0)][1]:.16g}")
