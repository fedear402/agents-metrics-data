clear all
set more off
import delimited using "households.csv", clear
keep if recipient == 0
gen byte ineligible = 1 - eligible
gen double dose_ineligible = dose * ineligible
gen double dose_eligible = dose * eligible
gen double base_ineligible = baseline * ineligible
gen double base_eligible = baseline * eligible
gen double inst_ineligible = instrument * ineligible
gen double inst_eligible = instrument * eligible
local n = _N
ivregress 2sls outcome ineligible eligible base_ineligible base_eligible (dose_ineligible dose_eligible = ineligible eligible base_ineligible base_eligible inst_ineligible inst_eligible) [aw=weight], noconstant
scalar b0 = _b[dose_ineligible]
scalar b1 = _b[dose_eligible]
quietly summarize dose [aw=weight] if eligible == 0
scalar m0 = r(mean)
quietly summarize dose [aw=weight] if eligible == 1
scalar m1 = r(mean)
scalar e0 = b0*m0
scalar e1 = b1*m1
scalar pop = (8400*e0 + 1600*e1)/(8400+1600)
display "ANSWER: ineligible_effect estimate=" %21.15g e0 " se=NA n_obs=" %9.0f `n'
display "ANSWER: eligible_nonrecipient_effect estimate=" %21.15g e1 " se=NA n_obs=" %9.0f `n'
display "ANSWER: population_effect estimate=" %21.15g pop " se=NA n_obs=" %9.0f `n'
