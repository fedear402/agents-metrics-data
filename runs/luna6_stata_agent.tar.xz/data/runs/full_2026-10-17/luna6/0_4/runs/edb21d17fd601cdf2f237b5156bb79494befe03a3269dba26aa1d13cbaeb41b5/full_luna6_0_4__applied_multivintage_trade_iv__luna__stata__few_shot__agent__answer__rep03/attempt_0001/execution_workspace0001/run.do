clear all
set more off
set type double

import delimited using "crosswalk.csv", clear
isid code
save crosswalk.dta, replace

import delimited using "trade.csv", clear
merge m:1 code using crosswalk.dta, nogen assert(match)
isid period industry
tempfile trade
save `trade'

* Save area data in Stata format for merging.
import delimited using "areas.csv", clear
save areas.dta, replace

* Merge employment and trade information.
import delimited using "employment.csv", clear
merge m:1 area period vintage using areas.dta, keepusing(total_employment population) nogen assert(match)
merge m:1 period industry using `trade', keepusing(us_change other_change price_index years) nogen assert(match)

* Calculate national industry employment, then sum the four exposure terms.
bysort period vintage industry: egen double national_emp = total(employment)
gen double xpart = (employment/total_employment)*(us_change/national_emp)/(price_index/100)/1000*(10/years)
gen double zpart = (employment/total_employment)*(other_change/national_emp)/(price_index/100)/1000*(10/years)
collapse (sum) x=xpart z=zpart, by(area period vintage)
reshape wide x z, i(area period) j(vintage) string
rename xbase x
rename zearly z
keep area period x z
tempfile exposures
save `exposures'

use areas.dta, clear
keep if vintage=="base"
keep area period population
isid area period
import delimited using "outcomes.csv", clear
save outcomes.dta, replace
use areas.dta, clear
keep if vintage=="base"
keep area period population
merge 1:1 area period using outcomes.dta, nogen assert(match)
merge 1:1 area period using `exposures', nogen assert(match)
count
local n = r(N)

ivregress 2sls change_pp (x=z) i.period control [aw=population]
display "ANSWER: iv_slope estimate=" %24.16g _b[x] " se=NA n_obs=`n'"
summarize x if area==0 & period==0, meanonly
display "ANSWER: exposure_area0_period0 estimate=" %24.16g r(mean) " se=NA n_obs=`n'"
summarize x if area==0 & period==1, meanonly
display "ANSWER: exposure_area0_period1 estimate=" %24.16g r(mean) " se=NA n_obs=`n'"
summarize z if area==0 & period==0, meanonly
display "ANSWER: instrument_area0_period0 estimate=" %24.16g r(mean) " se=NA n_obs=`n'"
