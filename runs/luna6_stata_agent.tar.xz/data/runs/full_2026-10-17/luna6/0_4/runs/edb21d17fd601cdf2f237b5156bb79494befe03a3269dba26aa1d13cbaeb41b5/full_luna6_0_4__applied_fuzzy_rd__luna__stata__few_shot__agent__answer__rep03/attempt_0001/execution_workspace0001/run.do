version 19.0
clear all
set more off
set linesize 255
import delimited using "./input.csv", clear
keep if abs(score) < 1
gen double weight = 1 - abs(score)
gen byte right = score >= 0
gen double xleft = score * (1 - right)
gen double xright = score * right

* Common local-linear design: intercept, right-side shift, and side-specific slopes.
mata:
Y = st_data(., ("earnings", "participated"))
X = st_data(., ("right", "score"))
// Replace with explicit design [1, right, score-left, score-right].
r = st_data(., "right")
s = st_data(., "score")
w = st_data(., "weight")
D = (J(rows(s),1,1), r, s:*(1:-r), s:*r)
W = diag(w)
B = invsym(D'*(w:*D))
C = B*D'*(w:*Y)
e = Y-D*C
// HC0 covariance for both outcomes; extract common right-minus-left intercept.
G = (0,1,0,0)
loading = w:*(D*B*G')
IF = loading:*e
V = IF'*IF
j = G*C
red = j[1]
fs = j[2]
grad = (1/fs \ -red/(fs^2))
te = red/fs
se_red = sqrt(V[1,1])
se_fs = sqrt(V[2,2])
se_te = sqrt(grad'*V*grad)
st_numscalar("red", red)
st_numscalar("fs", fs)
st_numscalar("te", te)
st_numscalar("se_red", se_red)
st_numscalar("se_fs", se_fs)
st_numscalar("se_te", se_te)
end
quietly count
display "ANSWER: treatment_effect estimate=" %21.12f scalar(te) " se=" %21.12f scalar(se_te) " n_obs=" %12.0f r(N)
display "ANSWER: reduced_form estimate=" %21.12f scalar(red) " se=" %21.12f scalar(se_red) " n_obs=" %12.0f r(N)
display "ANSWER: first_stage estimate=" %21.12f scalar(fs) " se=" %21.12f scalar(se_fs) " n_obs=" %12.0f r(N)
