d <- read.csv('input.csv', stringsAsFactors=FALSE)
d$date <- as.Date(d$date)
d <- d[order(d$date),]
d$dx <- c(NA, diff(log(d$vix)))
for (j in 1:15) d[[paste0('lag_',j)]] <- d$dx[match(seq_len(nrow(d))-j, seq_len(nrow(d)))]
d$y <- log(d$sales)
vars <- paste0('lag_',1:15)
ok <- complete.cases(d[,c('y',vars)])
D <- as.matrix(d[ok,vars]); Y <- d$y[ok]; n <- length(Y)
X <- cbind(1,D); b <- solve(crossprod(X),crossprod(X,Y))
u <- as.vector(Y-X%*%b)
meat <- matrix(0,ncol(X),ncol(X))
for(h in 0:15) {
  w <- if(h==0) 1 else 1-h/16
  for(t in seq_len(n-h)) {
    meat <- meat + w*u[t]*u[t+h]*tcrossprod(X[t,],X[t+h,])
    if(h>0) meat <- meat + w*u[t+h]*u[t]*tcrossprod(X[t+h,],X[t,])
  }
}
V <- solve(crossprod(X))%*%meat%*%solve(crossprod(X))*n/(n-16)
cat('n=',n,' cum=',sum(b[2:16]),' lag1=',b[2],' lag15=',b[16],'\n')
cat('se cum=',sqrt(sum(V[2:16,2:16])),' se1=',sqrt(V[2,2]),' se15=',sqrt(V[16,16]),'\n')
