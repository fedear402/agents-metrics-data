clear all
set more off
cd "/private/tmp/prospective_task_zsjui0vt"

* Join trade codes to the industry crosswalk.
import delimited using crosswalk.csv, clear
save cw.dta, replace
import delimited using trade.csv, clear
merge m:1 code using cw.dta, nogen assert(match)
rename industry industry_id
rename industry_id industry
save tr.dta, replace

* Complete omitted employment cells with zero.
import delimited using areas.csv, clear
keep area period vintage total_employment population
save ar.dta, replace
import delimited using employment.csv, clear
keep area period vintage industry employment
save emp.dta, replace
use ar.dta, clear
expand 4
bysort area period vintage: gen industry = _n - 1
merge 1:1 area period vintage industry using emp.dta, nogen
replace employment = 0 if missing(employment)

* National denominators sum employment over all areas within period, vintage, industry.
bysort period vintage industry: egen national_emp = total(employment)
merge m:1 period industry using tr.dta, keepusing(us_change other_change price_index years) nogen

* Keep one row per area-period-vintage for each measure.
gen base_part = (employment/total_employment) * (us_change/national_emp) / (price_index/100) / 1000 * (10/years) if vintage=="base"
gen early_part = (employment/total_employment) * (other_change/national_emp) / (price_index/100) / 1000 * (10/years) if vintage=="early"
preserve
keep if vintage=="early"
collapse (sum) z=early_part, by(area period)
save ztemp.dta, replace
restore
keep if vintage=="base"
collapse (sum) x=base_part (first) population, by(area period)
merge 1:1 area period using ztemp.dta, nogen assert(match)
save exposure.dta, replace

* Join outcome and control; estimate weighted 2SLS with all exogenous variables as instruments.
import delimited using outcomes.csv, clear
merge 1:1 area period using exposure.dta, nogen assert(match)
assert _N==72
ivregress 2sls change_pp (x=z) i.period control [aw=population], vce(robust)
estimates store iv
scalar b_x = _b[x]
scalar n = e(N)

quietly summarize x if area==0 & period==0, meanonly
scalar x00 = r(mean)
quietly summarize x if area==0 & period==1, meanonly
scalar x01 = r(mean)
* z uses early employment with other-country trade changes. Compute from complete panel.
* Instrument value is retained from the early-vintage calculation.

* Save requested output.
file open outf using "output.txt", write replace
file write outf "ANSWER: iv_slope estimate=" %21.15g (b_x) " se=NA n_obs=" %8.0f (n) _n
file write outf "ANSWER: exposure_area0_period0 estimate=" %21.15g (x00) " se=NA n_obs=" %8.0f (n) _n
file write outf "ANSWER: exposure_area0_period1 estimate=" %21.15g (x01) " se=NA n_obs=" %8.0f (n) _n
quietly summarize z if area==0 & period==0, meanonly
scalar z00 = r(mean)
file write outf "ANSWER: instrument_area0_period0 estimate=" %21.15g (z00) " se=NA n_obs=" %8.0f (n) _n
file close outf
