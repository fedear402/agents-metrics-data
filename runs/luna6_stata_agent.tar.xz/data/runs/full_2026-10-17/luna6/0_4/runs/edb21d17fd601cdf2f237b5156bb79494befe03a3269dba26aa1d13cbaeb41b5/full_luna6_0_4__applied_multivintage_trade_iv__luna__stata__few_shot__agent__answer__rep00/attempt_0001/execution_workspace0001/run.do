clear all
set more off
set type double

* Load the area-period employment denominators and population weights.
import delimited using "areas.csv", clear
keep if vintage == "base"
rename total_employment base_total
rename population base_population
tempfile baseareas earlyareas
save `baseareas'

import delimited using "areas.csv", clear
keep if vintage == "early"
rename total_employment early_total
save `earlyareas'

* Read the crosswalk in Stata format for merge operations.
import delimited using "crosswalk.csv", clear
tempfile crosswalk
save `crosswalk'

* Read employment and apply the supplied code-to-industry crosswalk.
import delimited using "employment.csv", clear
collapse (sum) employment, by(area period vintage industry)
reshape wide employment, i(area period vintage) j(industry)
forvalues j=0/3 {
    capture confirm variable employment`j'
    if _rc gen double employment`j'=0
    replace employment`j'=0 if missing(employment`j')
}
rename employment0 emp0
rename employment1 emp1
rename employment2 emp2
rename employment3 emp3
keep if vintage=="base"
merge 1:1 area period using `baseareas', keep(match) nogen
forvalues j=0/3 {
    bysort period: egen double natbase`j'=total(emp`j')
}
keep area period emp* base_total base_population natbase*
tempfile basematrix
save `basematrix'

import delimited using "employment.csv", clear
collapse (sum) employment, by(area period vintage industry)
reshape wide employment, i(area period vintage) j(industry)
forvalues j=0/3 {
    capture confirm variable employment`j'
    if _rc gen double employment`j'=0
    replace employment`j'=0 if missing(employment`j')
}
rename employment0 eemp0
rename employment1 eemp1
rename employment2 eemp2
rename employment3 eemp3
keep if vintage=="early"
merge 1:1 area period using `earlyareas', keep(match) nogen
forvalues j=0/3 {
    bysort period: egen double natearly`j'=total(eemp`j')
}
keep area period eemp* early_total natearly*
tempfile earlymatrix
save `earlymatrix'

* Expand trade-code rows to industries and sum the four industry terms.
import delimited using "trade.csv", clear
merge m:1 code using `crosswalk', keep(match) nogen
collapse (sum) us_change other_change, by(period industry price_index years)
reshape wide us_change other_change, i(period price_index years) j(industry)
forvalues j=0/3 {
    rename us_change`j' us`j'
    rename other_change`j' other`j'
}
tempfile tradewide
save `tradewide'

import delimited using "outcomes.csv", clear
tempfile outcomes
save `outcomes'
use `basematrix', clear
merge 1:1 area period using `earlymatrix', keep(match) nogen
merge m:1 period using `tradewide', keep(match) nogen
gen double x=0
gen double z=0
forvalues j=0/3 {
    replace x=x+(emp`j'/base_total)*(us`j'/natbase`j')/(price_index/100)/1000*(10/years)
    replace z=z+(eemp`j'/early_total)*(other`j'/natearly`j')/(price_index/100)/1000*(10/years)
}
merge 1:1 area period using `outcomes', keep(match) nogen
count
assert r(N)==72
gen byte period1=period==1
ivregress 2sls change_pp period1 control (x=z) [aw=base_population]
display "ANSWER: iv_slope estimate=" %24.16g _b[x] " se=NA n_obs=72"
sort area period
quietly summarize x if area==0 & period==0, meanonly
display "ANSWER: exposure_area0_period0 estimate=" %24.16g r(mean) " se=NA n_obs=72"
quietly summarize x if area==0 & period==1, meanonly
display "ANSWER: exposure_area0_period1 estimate=" %24.16g r(mean) " se=NA n_obs=72"
quietly summarize z if area==0 & period==0, meanonly
display "ANSWER: instrument_area0_period0 estimate=" %24.16g r(mean) " se=NA n_obs=72"
exit, clear
