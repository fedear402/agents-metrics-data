clear all
set more off
set linesize 255
import delimited using "./input.csv", clear
keep if abs(score) < 1
gen double weight = 1 - abs(score)
gen byte right = score >= 0
gen double xright = score * right
count
scalar N = r(N)

* Weighted least squares coefficients for side-specific intercepts and slopes.
quietly regress earnings right score xright [aw=weight]
matrix b_y = e(b)'
scalar rf = b_y[1,1]
predict double u_y, resid
quietly regress participated right score xright [aw=weight]
matrix b_d = e(b)'
scalar fs = b_d[1,1]
predict double u_d, resid

* Compute the joint HC0 covariance with fixed analytic triangular weights.
mata:
    st_view(s=., ., ("score", "weight"))
    n = rows(s)
    z = (s[,1]:>=0)
    X = (J(n,1,1), z, s[,1], s[,1]:*z)
    w = s[,2]
    B = invsym(X' * diag(w) * X)
    uy = st_data(., "u_y")
    ud = st_data(., "u_d")
    My = X' * diag(w:^2 :* uy:^2) * X
    Md = X' * diag(w:^2 :* ud:^2) * X
    Myd = X' * diag(w:^2 :* uy :* ud) * X
    Vy = B * My * B
    Vd = B * Md * B
    Vyd = B * Myd * B
    C = (0,1,0,0)
    st_numscalar("var_rf", (C * Vy * C')[1,1])
    st_numscalar("var_fs", (C * Vd * C')[1,1])
    st_numscalar("cov_rf_fs", (C * Vyd * C')[1,1])
end
scalar se_rf = sqrt(var_rf)
scalar se_fs = sqrt(var_fs)
scalar te = rf/fs
scalar var_te = var_rf/(fs^2) + (rf^2)*var_fs/(fs^4) - 2*rf*cov_rf_fs/(fs^3)
scalar se_te = sqrt(var_te)

display "ANSWER: treatment_effect estimate=" %21.12f te " se=" %21.12f se_te " n_obs=" %12.0f N
display "ANSWER: reduced_form estimate=" %21.12f rf " se=" %21.12f se_rf " n_obs=" %12.0f N
display "ANSWER: first_stage estimate=" %21.12f fs " se=" %21.12f se_fs " n_obs=" %12.0f N
