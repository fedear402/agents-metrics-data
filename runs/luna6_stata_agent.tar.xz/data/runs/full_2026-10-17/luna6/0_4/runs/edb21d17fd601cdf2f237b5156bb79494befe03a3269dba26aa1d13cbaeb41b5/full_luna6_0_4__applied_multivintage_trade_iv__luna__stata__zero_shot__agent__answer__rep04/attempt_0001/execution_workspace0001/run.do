clear all
set more off
import delimited using "crosswalk.csv", clear
 tempfile cw
 save `cw'
import delimited using "trade.csv", clear
 merge m:1 code using `cw', nogen assert(match)
 tempfile tr
 save `tr'
import delimited using "employment.csv", clear
 tempfile emp
 save `emp'
import delimited using "areas.csv", clear
 keep if vintage=="base"
 tempfile base
 save `base'
import delimited using "areas.csv", clear
 keep if vintage=="early"
 tempfile early
 save `early'
* Collapse industry employment then merge to full area-period x industry grid.
use `base', clear
 keep area period total_employment population
 tempfile basearea
 save `basearea'
use `early', clear
 keep area period total_employment
 tempfile earlyarea
 save `earlyarea'
use `emp', clear
 keep if vintage=="base"
 collapse (sum) employment, by(area period industry)
 tempfile eb
 save `eb'
use `emp', clear
 keep if vintage=="early"
 collapse (sum) employment, by(area period industry)
 tempfile ee
 save `ee'
* Build base rows from every observed base area-period and each of four industries.
use `basearea', clear
 expand 4
 bysort area period: gen industry=_n-1
 merge 1:1 area period industry using `eb', nogen
 replace employment=0 if missing(employment)
 rename employment base_emp
 tempfile gridb
 save `gridb'
use `earlyarea', clear
 expand 4
 bysort area period: gen industry=_n-1
 merge 1:1 area period industry using `ee', nogen
 replace employment=0 if missing(employment)
 rename employment early_emp
 tempfile gride
 save `gride'
use `gridb', clear
 merge 1:1 area period industry using `gride', nogen
* The task uses the base-vintage area total as the denominator for both x and z.
merge m:1 area period using `basearea', keepusing(total_employment) nogen update replace
* Attach trade by industry-period.
merge m:1 period industry using `tr', nogen assert(match)
* National industry employment, within period and vintage.
bys period industry: egen nat_base=total(base_emp)
bys period industry: egen nat_early=total(early_emp)
gen termx=(base_emp/total_employment)*(us_change/nat_base)/(price_index/100)/1000*(10/years)
gen termz=(early_emp/total_employment)*(other_change/nat_early)/(price_index/100)/1000*(10/years)
collapse (sum) x=termx z=termz, by(area period)
tempfile exp
save `exp'
use `basearea', clear
keep area period population
merge 1:1 area period using `exp', nogen
 tempfile regexp
 save `regexp'
import delimited using "outcomes.csv", clear
 merge 1:1 area period using `regexp', nogen assert(match)
count
local n=r(N)
assert `n'==72
ivregress 2sls change_pp control i.period (x=z) [aw=population]
display "ANSWER: iv_slope estimate=" %21.15g _b[x] " se=NA n_obs=" `n'
quietly summarize x if area==0 & period==0, meanonly
display "ANSWER: exposure_area0_period0 estimate=" %21.15g r(mean) " se=NA n_obs=" `n'
quietly summarize x if area==0 & period==1, meanonly
display "ANSWER: exposure_area0_period1 estimate=" %21.15g r(mean) " se=NA n_obs=" `n'
quietly summarize z if area==0 & period==0, meanonly
display "ANSWER: instrument_area0_period0 estimate=" %21.15g r(mean) " se=NA n_obs=" `n'
