clear all
set more off
set type double

* Build a complete area-period-industry grid. Missing employment is zero.
import delimited using "crosswalk.csv", clear varnames(1) stringcols(1)
tempfile crosswalk
save `crosswalk'

import delimited using "employment.csv", clear varnames(1) stringcols(3)
tempfile employment
save `employment'

import delimited using "areas.csv", clear varnames(1) stringcols(3)
keep if vintage=="base"
rename total_employment base_total
rename population population
tempfile baseareas
save `baseareas'

import delimited using "areas.csv", clear varnames(1) stringcols(3)
keep if vintage=="early"
rename total_employment early_total
keep area period early_total
tempfile earlyareas
save `earlyareas'

use `baseareas', clear
merge 1:1 area period using `earlyareas', assert(match) nogen
tempfile area_period
save `area_period'

* Employment by vintage in wide form, then attach industry identifiers.
use `employment', clear
reshape wide employment, i(area period industry) j(vintage) string
rename employmentbase base_emp
rename employmentearly early_emp
replace base_emp=0 if missing(base_emp)
replace early_emp=0 if missing(early_emp)
tempfile empwide
save `empwide'

* National denominators sum over all supplied areas for each period and industry.
preserve
collapse (sum) national_base=base_emp national_early=early_emp, by(period industry)
tempfile national
save `national'
restore

* Attach the unique trade row for each period and industry.
import delimited using "trade.csv", clear varnames(1) stringcols(2)
merge m:1 code using `crosswalk', assert(match) nogen
isid period industry
merge 1:1 period industry using `national', assert(match) nogen
tempfile shocks
save `shocks'

use `empwide', clear
merge m:1 period industry using `shocks', assert(match) nogen
merge m:1 area period using `area_period', assert(match) nogen
gen double part_x=(base_emp/national_base)*(us_change)/base_total/(price_index/100)/1000*(10/years)
gen double part_z=(early_emp/national_early)*(other_change)/early_total/(price_index/100)/1000*(10/years)
collapse (sum) x=part_x z=part_z, by(area period)
tempfile exposure
save `exposure'

import delimited using "outcomes.csv", clear varnames(1)
tempfile outcome_data
save `outcome_data'

use `area_period', clear
merge 1:1 area period using `exposure', assert(match) nogen
merge 1:1 area period using `outcome_data', assert(match) nogen
isid area period
count
assert r(N)==72
quietly summarize x if area==0 & period==0, meanonly
scalar exp00=r(mean)
quietly summarize x if area==0 & period==1, meanonly
scalar exp01=r(mean)
quietly summarize z if area==0 & period==0, meanonly
scalar inst00=r(mean)
ivregress 2sls change_pp period control (x=z) [aw=population]
scalar slope=_b[x]
file open answer using "answer.txt", write replace
file write answer "ANSWER: iv_slope estimate=" %24.16g (slope) " se=NA n_obs=72" _n
file write answer "ANSWER: exposure_area0_period0 estimate=" %24.16g (exp00) " se=NA n_obs=72" _n
file write answer "ANSWER: exposure_area0_period1 estimate=" %24.16g (exp01) " se=NA n_obs=72" _n
file write answer "ANSWER: instrument_area0_period0 estimate=" %24.16g (inst00) " se=NA n_obs=72" _n
file close answer
exit, clear
