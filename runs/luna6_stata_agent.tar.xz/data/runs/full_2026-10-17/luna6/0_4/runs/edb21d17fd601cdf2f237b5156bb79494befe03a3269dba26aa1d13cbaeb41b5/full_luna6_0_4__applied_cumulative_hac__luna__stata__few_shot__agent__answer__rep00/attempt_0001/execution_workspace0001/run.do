version 19.0
clear all
set more off
set linesize 255
import delimited using "./input.csv", clear

generate double day = date(date, "YMD")
format day %td
sort day
generate int observation = _n
tsset observation

generate double log_sales = ln(sales)
generate double log_vix = ln(vix)
generate double vix_change = D.log_vix
forvalues j = 1/15 {
    generate double change_lag`j' = L`j'.vix_change
}

keep if !missing(log_sales, change_lag1-change_lag15)
regress log_sales change_lag1-change_lag15
scalar n_obs = e(N)
scalar p = 16
mata:
X = (J(st_nobs(),1,1), st_data(.,("change_lag1-change_lag15")))
y = st_data(.,"log_sales")
b = qrsolve(X,y)
e = y-X*b
N = rows(X)
p = cols(X)
s = X:*e
L = 15
meat = s'*s
for (j=1; j<=L; j++) {
    cross = s[|j+1,1\N,p|]'*s[|1,1\N-j,p|]
    meat = meat + (1-j/16)*(cross+cross')
}
bread = invsym(X'*X)
V = N/(N-16)*bread*meat*bread
c = J(16,1,1)
c[1]=0
cum = c'*b
cumse = sqrt(c'*V*c)
st_numscalar("cum",cum)
st_numscalar("cumse",cumse)
st_numscalar("lag1",b[2])
st_numscalar("lag1se",sqrt(V[2,2]))
st_numscalar("lag15",b[16])
st_numscalar("lag15se",sqrt(V[16,16]))
end

display "ANSWER: cumulative_response estimate=" %21.12f scalar(cum) " se=" %21.12f scalar(cumse) " n_obs=" %12.0f scalar(n_obs)
display "ANSWER: lag_1 estimate=" %21.12f scalar(lag1) " se=" %21.12f scalar(lag1se) " n_obs=" %12.0f scalar(n_obs)
display "ANSWER: lag_15 estimate=" %21.12f scalar(lag15) " se=" %21.12f scalar(lag15se) " n_obs=" %12.0f scalar(n_obs)
