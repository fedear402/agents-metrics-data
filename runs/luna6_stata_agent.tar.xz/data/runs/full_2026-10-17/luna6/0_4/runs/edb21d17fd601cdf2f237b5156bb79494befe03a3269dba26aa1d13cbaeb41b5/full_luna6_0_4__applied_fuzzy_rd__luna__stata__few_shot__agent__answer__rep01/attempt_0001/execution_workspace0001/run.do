version 19.0
clear all
set more off
set linesize 255

import delimited "./input.csv", clear

keep if abs(score) < 1
generate double weight = 1 - abs(score)
generate double right = (score >= 0)
generate double x_left = score * (1 - right)
generate double x_right = score * right
generate double constant = 1
mkmat constant x_left right x_right, matrix(X)
mkmat earnings participated, matrix(Y)
mkmat weight, matrix(W)

mata:
X = st_matrix("X")
Y = st_matrix("Y")
w = st_matrix("W")
W = diag(w)
bread = invsym(X' * W * X)
b = bread * X' * W * Y
u = Y - X * b
// Right limit minus left limit for both outcomes.
C = (-1, 0, 1, 0)
d = C * b
// HC0 covariance for the coefficient vector, using weighted score rows.
score_e = (w :* X) :* u[,1]
score_p = (w :* X) :* u[,2]
Vbe = bread * (score_e' * score_e) * bread
Vbp = bread * (score_p' * score_p) * bread
Vbep = bread * (score_e' * score_p) * bread
// The two discontinuities use the same observations, so retain cross-covariance.
Vd = (C * Vbe * C', C * Vbep * C' \ C * Vbep' * C', C * Vbp * C')
grad = (d[2] \ -d[1] / (d[2]^2))
Vjoint = Vd
ratio = d[1] / d[2]
ratio_se = sqrt(grad' * Vjoint * grad)
st_numscalar("rf", d[1])
st_numscalar("fs", d[2])
st_numscalar("rf_se", sqrt(Vd[1,1]))
st_numscalar("fs_se", sqrt(Vd[2,2]))
st_numscalar("te", ratio)
st_numscalar("te_se", ratio_se)
st_numscalar("n_obs", rows(X))
end

display "ANSWER: treatment_effect estimate=" %21.12f scalar(te) " se=" %21.12f scalar(te_se) " n_obs=" %12.0f scalar(n_obs)
display "ANSWER: reduced_form estimate=" %21.12f scalar(rf) " se=" %21.12f scalar(rf_se) " n_obs=" %12.0f scalar(n_obs)
display "ANSWER: first_stage estimate=" %21.12f scalar(fs) " se=" %21.12f scalar(fs_se) " n_obs=" %12.0f scalar(n_obs)
