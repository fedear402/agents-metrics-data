clear all
set more off
set linesize 255
import delimited using "./input.csv", clear
sort date
gen double ln_sales = ln(sales)
gen double dln_vix = ln(vix) - ln(vix[_n-1])
forvalues j = 1/15 {
    gen double lag_`j' = dln_vix[_n-`j']
}
gen long obsno = _n
tsset obsno
regress ln_sales lag_1-lag_15
scalar N = e(N)
matrix b = e(b)
predict double resid if e(sample), resid
mkmat lag_1-lag_15 if e(sample), matrix(Z0)
mkmat resid if e(sample), matrix(U)
matrix Z0 = Z0, J(rowsof(Z0),1,1)
mata:
    X = st_matrix("Z0")
    u = st_matrix("U")
    n = rows(X)
    bread = invsym(X' * X)
    meat = J(cols(X), cols(X), 0)
    for (h=0; h<=15; h++) {
        w = 1 - h/16
        for (t=h+1; t<=n; t++) {
            gt = X[t,.]' * u[t,1]
            if (h==0) meat = meat + w * gt * gt'
            else {
                gh = X[t-h,.]' * u[t-h,1]
                meat = meat + w * (gt*gh' + gh*gt')
            }
        }
    }
    st_matrix("Vnw", (n/(n-16)) * bread * meat * bread)
end
scalar csum = 0
forvalues j = 1/15 {
    scalar csum = csum + b[1,`j']
}
matrix ones = J(1,15,1)
matrix Cv = ones*Vnw[1..15,1..15]*ones'
scalar secum = sqrt(Cv[1,1])
scalar se1 = sqrt(Vnw[1,1])
scalar se15 = sqrt(Vnw[15,15])
display "ANSWER: cumulative_response estimate=" %21.12f csum " se=" %21.12f secum " n_obs=" %12.0f N
display "ANSWER: lag_1 estimate=" %21.12f b[1,1] " se=" %21.12f se1 " n_obs=" %12.0f N
display "ANSWER: lag_15 estimate=" %21.12f b[1,15] " se=" %21.12f se15 " n_obs=" %12.0f N
