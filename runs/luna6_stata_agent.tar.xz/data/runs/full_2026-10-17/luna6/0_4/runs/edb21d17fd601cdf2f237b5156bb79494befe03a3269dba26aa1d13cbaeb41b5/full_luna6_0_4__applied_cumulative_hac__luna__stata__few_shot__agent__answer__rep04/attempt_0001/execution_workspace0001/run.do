version 19.0
clear all
set more off
set linesize 255
import delimited using "./input.csv", clear

generate double day = date(date, "YMD")
format day %td
sort day
generate int observation = _n
tsset observation

generate double log_sales = ln(sales)
generate double log_vix = ln(vix)
generate double vix_change = D.log_vix
forvalues j = 1/15 {
    generate double lag_`j' = L`j'.vix_change
}
keep if !missing(log_sales, lag_1, lag_2, lag_3, lag_4, lag_5, lag_6, lag_7, lag_8, lag_9, lag_10, lag_11, lag_12, lag_13, lag_14, lag_15)

mata:
X=(J(st_nobs(),1,1),st_data(.,("lag_1","lag_2","lag_3","lag_4","lag_5","lag_6","lag_7","lag_8","lag_9","lag_10","lag_11","lag_12","lag_13","lag_14","lag_15")))
y=st_data(.,"log_sales")
b=qrsolve(X,y)
e=y-X*b
N=rows(X)
p=cols(X)
s=X:*e
L=15
meat=s'*s
for (j=1;j<=L;j++) {
    g=s[|j+1,1\N,p|]'*s[|1,1\N-j,p|]
    meat=meat+(1-j/16)*(g+g')
}
bread=invsym(X'*X)
V=(N/(N-16))*bread*meat*bread
c=J(16,1,1)
c[1]=0
sum_b=c'*b
sum_se=sqrt(c'*V*c)
st_numscalar("cumulative_est",sum_b)
st_numscalar("cumulative_se",sum_se)
st_numscalar("lag1_est",b[2])
st_numscalar("lag1_se",sqrt(V[2,2]))
st_numscalar("lag15_est",b[16])
st_numscalar("lag15_se",sqrt(V[16,16]))
st_numscalar("n_est",N)
end

display "ANSWER: cumulative_response estimate=" %21.12f scalar(cumulative_est) " se=" %21.12f scalar(cumulative_se) " n_obs=" %12.0f scalar(n_est)
display "ANSWER: lag_1 estimate=" %21.12f scalar(lag1_est) " se=" %21.12f scalar(lag1_se) " n_obs=" %12.0f scalar(n_est)
display "ANSWER: lag_15 estimate=" %21.12f scalar(lag15_est) " se=" %21.12f scalar(lag15_se) " n_obs=" %12.0f scalar(n_est)
