clear all
set more off
import delimited using "households.csv", clear
keep if recipient == 0
gen byte g0 = 1 - eligible
gen byte g1 = eligible
gen double b0 = baseline * g0
gen double b1 = baseline * g1
gen double d0 = dose * g0
gen double d1 = dose * g1
gen double z0 = instrument * g0
gen double z1 = instrument * g1
quietly count
scalar N = r(N)
quietly ivregress 2sls outcome g0 g1 b0 b1 (d0 d1 = z0 z1) [aw=weight], noconstant
scalar slope0 = _b[d0]
scalar slope1 = _b[d1]
quietly summarize dose [aw=weight] if eligible == 0
scalar mean0 = r(mean)
quietly summarize dose [aw=weight] if eligible == 1
scalar mean1 = r(mean)
* Synthetic attribution convention: compare fitted group effect with dose set to zero.
scalar effect0 = slope0 * mean0
scalar effect1 = slope1 * mean1
import delimited using "census.csv", clear
quietly summarize nonrecipient_population if eligible == 0
scalar pop0 = r(mean)
quietly summarize nonrecipient_population if eligible == 1
scalar pop1 = r(mean)
scalar pop_effect = (effect0 * pop0 + effect1 * pop1) / (pop0 + pop1)
display "ineligible_effect estimate=" %21.15g effect0 " se=NA n_obs=" %9.0f N
display "eligible_nonrecipient_effect estimate=" %21.15g effect1 " se=NA n_obs=" %9.0f N
display "population_effect estimate=" %21.15g pop_effect " se=NA n_obs=" %9.0f N
