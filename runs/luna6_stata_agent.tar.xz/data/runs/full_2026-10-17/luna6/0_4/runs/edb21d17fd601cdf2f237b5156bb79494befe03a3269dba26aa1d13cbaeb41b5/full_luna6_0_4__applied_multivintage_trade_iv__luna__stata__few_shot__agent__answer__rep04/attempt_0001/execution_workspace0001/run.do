clear all
set more off
set linesize 200
set type double

import delimited using "crosswalk.csv", clear
isid code
tempfile crosswalk
save `crosswalk'

import delimited using "trade.csv", clear
merge m:1 code using `crosswalk', assert(match) nogen
isid period industry
tempfile trade
save `trade'

import delimited using "areas.csv", clear
keep if vintage=="base"
rename total_employment base_total
rename population base_population
tempfile base
save `base'
import delimited using "areas.csv", clear
keep if vintage=="early"
rename total_employment early_total
merge 1:1 area period using `base', assert(match) nogen
tempfile area
save `area'
import delimited using "outcomes.csv", clear
tempfile outcomes
save `outcomes'

import delimited using "employment.csv", clear
collapse (sum) employment, by(area period vintage industry)
reshape wide employment, i(area period industry) j(vintage) string
rename employmentbase base_emp
rename employmentearly early_emp
tempfile emp
save `emp'

* Build complete area-period-industry grid. Missing employment cells are zero.
use `area', clear
merge 1:1 area period using `outcomes', assert(match) nogen
expand 4
gen industry=_n
bysort area period: replace industry=_n-1
merge 1:1 area period industry using `emp', nogen
replace base_emp=0 if missing(base_emp)
replace early_emp=0 if missing(early_emp)

* National denominators by period and vintage.
bysort period industry: egen double nat_base=total(base_emp)
bysort period industry: egen double nat_early=total(early_emp)
merge m:1 period industry using `trade', keep(match) nogen

gen double xpart=(base_emp/base_total)*(us_change/nat_base)/(price_index/100)/1000*(10/years)
gen double zpart=(early_emp/early_total)*(other_change/nat_early)/(price_index/100)/1000*(10/years)
collapse (sum) x=xpart z=zpart (first) base_population control change_pp, by(area period)
isid area period
count
assert r(N)==72
local n=r(N)

ivregress 2sls change_pp i.period control (x=z) [aw=base_population]
display "ANSWER: iv_slope estimate=" %24.16g _b[x] " se=NA n_obs=" `n'
quietly summarize x if area==0 & period==0, meanonly
display "ANSWER: exposure_area0_period0 estimate=" %24.16g r(mean) " se=NA n_obs=" `n'
quietly summarize x if area==0 & period==1, meanonly
display "ANSWER: exposure_area0_period1 estimate=" %24.16g r(mean) " se=NA n_obs=" `n'
quietly summarize z if area==0 & period==0, meanonly
display "ANSWER: instrument_area0_period0 estimate=" %24.16g r(mean) " se=NA n_obs=" `n'
exit, clear
