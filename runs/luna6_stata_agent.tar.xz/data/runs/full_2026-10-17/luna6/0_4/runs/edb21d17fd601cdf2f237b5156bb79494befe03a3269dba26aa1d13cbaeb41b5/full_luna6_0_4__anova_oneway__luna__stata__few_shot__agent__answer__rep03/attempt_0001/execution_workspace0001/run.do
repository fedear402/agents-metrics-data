clear all
set more off
set linesize 255
import delimited using "./input.csv", clear
oneway y group
scalar Fval = r(F)
scalar dnum = r(df_m)
scalar dden = r(df_r)
scalar pval = Ftail(dnum, dden, Fval)
scalar Nval = _N
display "ANSWER: F estimate=" %21.12f Fval " se=. n_obs=" %12.0f Nval
display "ANSWER: df_num estimate=" %21.12f dnum " se=. n_obs=" %12.0f Nval
display "ANSWER: df_den estimate=" %21.12f dden " se=. n_obs=" %12.0f Nval
display "ANSWER: p_value estimate=" %21.12f pval " se=. n_obs=" %12.0f Nval
