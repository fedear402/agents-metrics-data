clear all
set more off
set linesize 255
import delimited using "./input.csv", clear

* Parse dates and order consecutive trading observations.
gen double trade_date = daily(date, "YMD")
format trade_date %td
sort trade_date
gen long trading_obs = _n
tsset trading_obs

* First difference of log volatility, then lags 1 through 15.
gen double dlog_vix = ln(vix) - ln(vix[_n-1])
forvalues j = 1/15 {
    gen double lag_`j' = dlog_vix[_n-`j']
}
gen double log_sales = ln(sales)

* Use only rows with a complete set of lagged volatility changes.
regress log_sales lag_1 lag_2 lag_3 lag_4 lag_5 lag_6 lag_7 lag_8 lag_9 lag_10 lag_11 lag_12 lag_13 lag_14 lag_15 if !missing(lag_1, lag_2, lag_3, lag_4, lag_5, lag_6, lag_7, lag_8, lag_9, lag_10, lag_11, lag_12, lag_13, lag_14, lag_15)
scalar n_sample = e(N)
matrix b = e(b)
matrix V = e(V)

* Newey-West covariance: Bartlett weights, maximum lag 15, finite-sample scale.
* Regressor score rows are x_t times OLS residuals; lagged cross-products use
* the stated 1-j/16 weights. The intercept is included in every score row.
predict double resid, residuals
forvalues i = 1/16 {
    if `i' == 1 {
        gen double score_`i' = resid if e(sample)
    }
    else {
        local kk = `i' - 1
        gen double score_`i' = resid * lag_`kk' if e(sample)
    }
}
mkmat score_1-score_16 if e(sample), matrix(scoremat)
matrix S = scoremat' * scoremat
forvalues h = 1/15 {
    local weight = 1 - `h'/16
    matrix G = J(16,16,0)
    forvalues t = `=`h'+1'/`=n_sample' {
        local t0 = `t' - `h'
        forvalues i = 1/16 {
            forvalues j = 1/16 {
                matrix G[`i',`j'] = G[`i',`j'] + scoremat[`t',`i'] * scoremat[`t0',`j']
            }
        }
    }
    matrix S = S + `weight' * (G + G')
}
newey log_sales lag_1 lag_2 lag_3 lag_4 lag_5 lag_6 lag_7 lag_8 lag_9 lag_10 lag_11 lag_12 lag_13 lag_14 lag_15 if !missing(lag_1, lag_2, lag_3, lag_4, lag_5, lag_6, lag_7, lag_8, lag_9, lag_10, lag_11, lag_12, lag_13, lag_14, lag_15), lag(15)
matrix Vnw = (n_sample/(n_sample-16)) * e(V)

scalar cum_est = 0
scalar cum_var = 0
matrix C = J(1,16,0)
forvalues k = 1/15 {
    local kk = `k' + 1
    matrix C[1,`kk'] = 1
}
scalar cum_est = 0
forvalues k = 1/15 {
    scalar cum_est = cum_est + b[1,`=`k'+1']
}
matrix cv = C * Vnw * C'
scalar cum_var = cv[1,1]
scalar cum_se = sqrt(cum_var)
scalar lag1_est = b[1,2]
scalar lag1_se = sqrt(Vnw[2,2])
scalar lag15_est = b[1,16]
scalar lag15_se = sqrt(Vnw[16,16])

display "ANSWER: cumulative_response estimate=" %21.12f cum_est " se=" %21.12f cum_se " n_obs=" %12.0f n_sample
display "ANSWER: lag_1 estimate=" %21.12f lag1_est " se=" %21.12f lag1_se " n_obs=" %12.0f n_sample
display "ANSWER: lag_15 estimate=" %21.12f lag15_est " se=" %21.12f lag15_se " n_obs=" %12.0f n_sample
