clear all
set more off
set linesize 255
import delimited using "./input.csv", clear

* Keep the estimation sample explicit for the reported observation count.
keep if !missing(y, group)
quietly oneway y group
tempname f df_num df_den p n
scalar `f' = r(F)
scalar `df_num' = r(df_m)
scalar `df_den' = r(df_r)
scalar `p' = Ftail(r(df_m), r(df_r), r(F))
scalar `n' = r(N)

display "ANSWER: F estimate=" %21.12f scalar(`f') " se=. n_obs=" %12.0f scalar(`n')
display "ANSWER: df_num estimate=" %21.12f scalar(`df_num') " se=. n_obs=" %12.0f scalar(`n')
display "ANSWER: df_den estimate=" %21.12f scalar(`df_den') " se=. n_obs=" %12.0f scalar(`n')
display "ANSWER: p_value estimate=" %21.12f scalar(`p') " se=. n_obs=" %12.0f scalar(`n')
