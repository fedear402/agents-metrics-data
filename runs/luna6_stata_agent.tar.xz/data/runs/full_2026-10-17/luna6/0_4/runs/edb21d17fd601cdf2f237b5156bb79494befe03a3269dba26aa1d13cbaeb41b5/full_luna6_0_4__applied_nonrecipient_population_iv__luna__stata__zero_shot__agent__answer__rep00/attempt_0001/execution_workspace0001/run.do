clear all
set more off
import delimited using "households.csv", clear
keep if recipient == 0
gen byte ineligible = 1 - eligible
gen double dose_ineligible = dose * ineligible
gen double dose_eligible = dose * eligible
gen double baseline_ineligible = baseline * ineligible
gen double baseline_eligible = baseline * eligible
gen double instrument_ineligible = instrument * ineligible
gen double instrument_eligible = instrument * eligible
count
local n = r(N)
quietly ivregress 2sls outcome ineligible eligible baseline_ineligible baseline_eligible (dose_ineligible dose_eligible = instrument_ineligible instrument_eligible) [aweight=weight], noconstant
matrix b = e(b)
local slope0 = b[1, "dose_ineligible"]
local slope1 = b[1, "dose_eligible"]
quietly summarize dose [aweight=weight] if eligible == 0
local mean0 = r(mean)
quietly summarize dose [aweight=weight] if eligible == 1
local mean1 = r(mean)
local eff0 = `slope0' * `mean0'
local eff1 = `slope1' * `mean1'
local pop = (`eff0' * 8400 + `eff1' * 1600) / 10000
display "ANSWER: ineligible_effect estimate=" %21.14g `eff0' " se=NA n_obs=" `n'
display "ANSWER: eligible_nonrecipient_effect estimate=" %21.14g `eff1' " se=NA n_obs=" `n'
display "ANSWER: population_effect estimate=" %21.14g `pop' " se=NA n_obs=" `n'
