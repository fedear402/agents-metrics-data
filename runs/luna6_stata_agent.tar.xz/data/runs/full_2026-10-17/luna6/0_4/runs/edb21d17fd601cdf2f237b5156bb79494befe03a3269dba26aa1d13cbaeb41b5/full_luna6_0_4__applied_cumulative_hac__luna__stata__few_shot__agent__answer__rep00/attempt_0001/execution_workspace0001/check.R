d <- read.csv('input.csv')
d$date <- as.Date(d$date)
d <- d[order(d$date),]
z <- diff(log(d$vix))
y <- log(d$sales)[-1]
idx <- 16:length(y)
X <- cbind(1, sapply(1:15, function(j) z[idx-j]))
Y <- y[idx]
b <- solve(crossprod(X),crossprod(X,Y))[,1]
e <- Y-X%*%b
N <- nrow(X); p <- ncol(X); scores <- X*as.vector(e)
meat <- crossprod(scores)
for(j in 1:15) {g <- crossprod(scores[(j+1):N,,drop=FALSE],scores[1:(N-j),,drop=FALSE]); meat <- meat+(1-j/16)*(g+t(g))}
V <- N/(N-p)*solve(crossprod(X))%*%meat%*%solve(crossprod(X))
c <- c(0,rep(1,15))
cat(sprintf('n=%d rows=%d first_date=%s last_date=%s\n',N,nrow(d),d$date[1],d$date[nrow(d)]))
cat(sprintf('sum=%.12f sum_se=%.12f lag1=%.12f lag1_se=%.12f lag15=%.12f lag15_se=%.12f\n',sum(b[-1]),sqrt(drop(t(c)%*%V%*%c)),b[2],sqrt(V[2,2]),b[16],sqrt(V[16,16])))
cat(sprintf('ols_sum=%.12f identity=%.12f\n',sum(b[-1]),drop(t(c)%*%b)))
