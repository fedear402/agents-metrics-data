clear all
set more off
version 18
cd "/private/tmp/prospective_task_7p0nsxm9"
capture log close
log using "results.txt", text replace

import delimited using "crosswalk.csv", clear varnames(1) stringcols(1)
tempfile crosswalk
save `crosswalk'
import delimited using "trade.csv", clear varnames(1) stringcols(2)
merge m:1 code using `crosswalk', assert(match) nogen
gen double focal_trade=us_change/(price_index/100)/1000*(10/years)
gen double other_trade=other_change/(price_index/100)/1000*(10/years)
keep period industry focal_trade other_trade
tempfile trade
save `trade'

import delimited using "employment.csv", clear varnames(1)
tempfile empobs
save `empobs'
import delimited using "areas.csv", clear varnames(1) stringcols(3)
keep area period vintage total_employment
duplicates drop
tempfile area_totals
save `area_totals'
keep area period vintage
expand 4
bysort area period vintage: gen industry=_n-1
merge 1:1 area period vintage industry using `empobs', nogen
replace employment=0 if missing(employment)
tempfile empfull
save `empfull'

collapse (sum) national_emp=employment, by(period vintage industry)
tempfile national
save `national'

use `empfull', clear
merge m:1 period vintage industry using `national', assert(match) nogen
merge m:1 period industry using `trade', assert(match) nogen
merge m:1 area period vintage using `area_totals', assert(match) nogen
gen double focal_part=(employment/total_employment)*focal_trade/national_emp
gen double other_part=(employment/total_employment)*other_trade/national_emp
collapse (sum) exposure=focal_part instrument=other_part, by(area period vintage)
keep if vintage=="base" | vintage=="early"
reshape wide exposure instrument, i(area period) j(vintage) string
rename exposurebase x
rename instrumentearly z
keep area period x z
tempfile exposures
save `exposures'

import delimited using "outcomes.csv", clear varnames(1)
merge 1:1 area period using `exposures', assert(match) nogen
tempfile panel
save `panel'

import delimited using "areas.csv", clear varnames(1) stringcols(3)
keep if vintage=="base"
keep area period population
merge 1:1 area period using `panel', assert(match) nogen
gen byte period1=(period==1)
count
assert r(N)==72

* Weighted 2SLS: intercept, period, control, and x; instrument x with z.
ivregress 2sls change_pp period1 control (x=z) [aweight=population]
scalar slope=_b[x]
quietly summarize x if area==0 & period==0, meanonly
scalar exp00=r(mean)
quietly summarize x if area==0 & period==1, meanonly
scalar exp01=r(mean)
quietly summarize z if area==0 & period==0, meanonly
scalar inst00=r(mean)
display as text "ANSWER: iv_slope estimate=" %24.16g scalar(slope) " se=NA n_obs=72"
display as text "ANSWER: exposure_area0_period0 estimate=" %24.16g scalar(exp00) " se=NA n_obs=72"
display as text "ANSWER: exposure_area0_period1 estimate=" %24.16g scalar(exp01) " se=NA n_obs=72"
display as text "ANSWER: instrument_area0_period0 estimate=" %24.16g scalar(inst00) " se=NA n_obs=72"
log close
