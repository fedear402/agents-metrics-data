clear all
set more off
set linesize 255
import delimited "./input.csv", clear

oneway y group
scalar anova_F = r(F)
scalar anova_df_num = r(df_m)
scalar anova_df_den = r(df_r)
scalar anova_n = r(N)
scalar anova_p = Ftail(anova_df_num, anova_df_den, anova_F)

display "ANSWER: F estimate=" %21.12f anova_F " se=. n_obs=" %12.0f anova_n
display "ANSWER: df_num estimate=" %21.12f anova_df_num " se=. n_obs=" %12.0f anova_n
display "ANSWER: df_den estimate=" %21.12f anova_df_den " se=. n_obs=" %12.0f anova_n
display "ANSWER: p_value estimate=" %21.12f anova_p " se=. n_obs=" %12.0f anova_n
