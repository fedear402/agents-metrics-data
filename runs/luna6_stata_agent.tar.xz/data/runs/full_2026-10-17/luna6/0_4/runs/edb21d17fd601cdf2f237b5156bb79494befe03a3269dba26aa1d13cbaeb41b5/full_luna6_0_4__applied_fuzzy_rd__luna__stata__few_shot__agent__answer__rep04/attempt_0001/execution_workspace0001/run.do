version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear
keep if abs(score) < 1
gen double weight = 1 - abs(score)
gen double right = score >= 0
gen double slope_left = score * (1 - right)
gen double slope_right = score * right

mata:
X = (J(rows(st_data(.,"score")),1,1), st_data(.,"right"), st_data(.,"slope_left"), st_data(.,"slope_right"))
w = st_data(.,"weight")
Y = st_data(.,("earnings","participated"))
n = rows(Y)
bread = invsym(X' * (w :* X))
b = bread * X' * (w :* Y)
u = Y - X*b
// Right-minus-left intercept jump, with side-specific local-linear slopes.
c = ( -1 \ 1 \ 0 \ 0 )
jump = c' * b
loading = w :* (X * bread * c)
IF = loading :* u
V = IF' * IF
grad = (1/jump[2] \ -jump[1]/(jump[2]^2))
ratio = jump[1]/jump[2]
ratio_se = sqrt(grad' * V * grad)
st_numscalar("N", n)
st_numscalar("rf", jump[1])
st_numscalar("fs", jump[2])
st_numscalar("rfse", sqrt(V[1,1]))
st_numscalar("fsse", sqrt(V[2,2]))
st_numscalar("te", ratio)
st_numscalar("tese", ratio_se)
end

display "ANSWER: treatment_effect estimate=" %21.12f scalar(te) " se=" %21.12f scalar(tese) " n_obs=" %12.0f scalar(N)
display "ANSWER: reduced_form estimate=" %21.12f scalar(rf) " se=" %21.12f scalar(rfse) " n_obs=" %12.0f scalar(N)
display "ANSWER: first_stage estimate=" %21.12f scalar(fs) " se=" %21.12f scalar(fsse) " n_obs=" %12.0f scalar(N)
