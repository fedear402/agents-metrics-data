version 19.0
clear all
set more off
set linesize 255
import delimited using "./input.csv", clear

generate double day = date(date, "YMD")
format day %td
sort day
generate long observation = _n
tsset observation

generate double log_vix = ln(vix)
generate double vix_change = D.log_vix
generate double log_sales = ln(sales)
forvalues j = 1/15 {
    generate double change_lag`j' = vix_change[_n-`j']
}
keep if !missing(log_sales, change_lag1-change_lag15)
mata:
X = J(st_nobs(),16,1)
for (j=1; j<=15; j++) X[.,j+1] = st_data(.,"change_lag"+strofreal(j))
y = st_data(.,"log_sales")
b = qrsolve(X,y)
u = y-X*b
N = rows(X)
p = cols(X)
scores = X:*u
meat = scores'*scores
for (j=1; j<=15; j++) {
    g = scores[|j+1,1\N,p|]'*scores[|1,1\N-j,p|]
    meat = meat + (1-j/16)*(g+g')
}
bread = invsym(X'*X)
V = (N/(N-16))*bread*meat*bread
c = J(p,1,1)
c[1]=0
cum = c'*b
cumse = sqrt(c'*V*c)
st_numscalar("cum",cum)
st_numscalar("cumse",cumse)
st_numscalar("b1",b[2])
st_numscalar("se1",sqrt(V[2,2]))
st_numscalar("b15",b[16])
st_numscalar("se15",sqrt(V[16,16]))
st_numscalar("nobs",N)
end
display "ANSWER: cumulative_response estimate=" %21.12f scalar(cum) " se=" %21.12f scalar(cumse) " n_obs=" %12.0f scalar(nobs)
display "ANSWER: lag_1 estimate=" %21.12f scalar(b1) " se=" %21.12f scalar(se1) " n_obs=" %12.0f scalar(nobs)
display "ANSWER: lag_15 estimate=" %21.12f scalar(b15) " se=" %21.12f scalar(se15) " n_obs=" %12.0f scalar(nobs)
