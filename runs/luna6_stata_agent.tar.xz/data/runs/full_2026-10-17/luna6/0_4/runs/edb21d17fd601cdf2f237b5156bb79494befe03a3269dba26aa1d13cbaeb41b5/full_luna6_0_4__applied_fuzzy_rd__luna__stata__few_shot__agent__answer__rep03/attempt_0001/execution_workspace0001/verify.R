d <- read.csv('input.csv')
d <- d[abs(d$score) < 1,]
s <- d$score; w <- 1-abs(s); r <- as.numeric(s>=0)
X <- cbind(1,r,s*(1-r),s*r)
Y <- cbind(d$earnings,d$participated)
A <- crossprod(X, X*w)
coef <- solve(A, crossprod(X,Y*w))
e <- Y-X%*%coef
cvec <- c(0,1,0,0)
loading <- as.vector(w * X %*% solve(A,cvec))
V <- crossprod(e*loading)
j <- as.vector(crossprod(cvec,coef))
g <- c(1/j[2],-j[1]/j[2]^2)
cat(sprintf('n=%d\nreduced_form=%.12f se=%.12f\nfirst_stage=%.12f se=%.12f\ntreatment_effect=%.12f se=%.12f\ncovariance=%.12f\n',nrow(d),j[1],sqrt(V[1,1]),j[2],sqrt(V[2,2]),j[1]/j[2],sqrt(drop(t(g)%*%V%*%g)),V[1,2]))
# Independent HC0 sandwich identity, using score sums and the bread matrix.
for(k in 1:2) {
 u <- e[,k]
 meat <- crossprod(X*(w*u))
 v <- drop(t(cvec) %*% solve(A, meat) %*% solve(A, cvec))
 stopifnot(abs(v-V[k,k]) < 1e-12)
}
