clear all
set more off
version 18

* Import and validate the code-to-industry mapping.
import delimited using "crosswalk.csv", clear
isid code
save "_crosswalk.dta", replace

* Join trade codes and retain one record per period and industry.
import delimited using "trade.csv", clear
merge m:1 code using "_crosswalk.dta", assert(match) nogen
isid period industry
tempfile trade national
save `trade'

* Sum employment nationally by period, vintage, and industry.
import delimited using "employment.csv", clear
collapse (sum) employment, by(period vintage industry)
rename employment national_emp
save `national'

* Create a complete area-period-vintage-industry grid. Omitted cells are zero.
import delimited using "areas.csv", clear
keep area period vintage total_employment population
isid area period vintage
tempfile area_vintages
save `area_vintages'

import delimited using "crosswalk.csv", clear
keep industry
duplicates drop
isid industry
tempfile industries
save `industries'

import delimited using "employment.csv", clear
isid area period vintage industry
save "_employment.dta", replace
use `area_vintages', clear
cross using `industries'
merge 1:1 area period vintage industry using "_employment.dta", keep(master match) nogen
replace employment = 0 if missing(employment)
merge m:1 period vintage industry using `national', assert(match) nogen
merge m:1 period industry using `trade', assert(match) nogen

* Exposure contribution: employment share times trade shock per national worker,
* deflated to real dollars, converted to thousands, and annualized per decade.
gen double xpart = (employment/total_employment) * (us_change/national_emp) / (price_index/100) / 1000 * (10/years)
gen double zpart = (employment/total_employment) * (other_change/national_emp) / (price_index/100) / 1000 * (10/years)
collapse (sum) x=xpart z=zpart, by(area period vintage population)
reshape wide x z, i(area period) j(vintage) string
rename xbase x
rename zearly z
keep area period population x z
isid area period
save "_exposures.dta", replace

* Merge outcomes and use base-vintage population as analytic frequency weight.
import delimited using "outcomes.csv", clear
merge 1:1 area period using "_exposures.dta", assert(match) nogen
count
assert r(N)==72
gen byte period1 = period==1
ivregress 2sls change_pp period1 control (x=z) [aw=population], vce(unadjusted)
scalar b_iv = _b[x]

* Report requested estimates, each with the task's 72-row sample count.
preserve
keep if area==0
sort period
quietly summarize x if period==0
scalar e00 = r(mean)
quietly summarize x if period==1
scalar e01 = r(mean)
quietly summarize z if period==0
scalar i00 = r(mean)
restore

display "ANSWER: iv_slope estimate=" %21.15g b_iv " se=NA n_obs=72"
display "ANSWER: exposure_area0_period0 estimate=" %21.15g e00 " se=NA n_obs=72"
display "ANSWER: exposure_area0_period1 estimate=" %21.15g e01 " se=NA n_obs=72"
display "ANSWER: instrument_area0_period0 estimate=" %21.15g i00 " se=NA n_obs=72"
