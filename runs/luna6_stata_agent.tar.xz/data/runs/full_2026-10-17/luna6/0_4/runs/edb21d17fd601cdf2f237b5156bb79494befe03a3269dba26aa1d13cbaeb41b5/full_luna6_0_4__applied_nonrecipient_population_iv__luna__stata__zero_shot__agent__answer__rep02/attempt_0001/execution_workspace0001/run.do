clear all
set more off
version 18.0

import delimited using "households.csv", clear
keep if recipient == 0
generate byte ineligible = 1 - eligible
generate double dose0 = dose * ineligible
generate double dose1 = dose * eligible
generate double base0 = baseline * ineligible
generate double base1 = baseline * eligible
generate double inst0 = instrument * ineligible
generate double inst1 = instrument * eligible

count
local n_obs = r(N)

ivregress 2sls outcome ineligible eligible base0 base1 ///
    (dose0 dose1 = ineligible eligible base0 base1 inst0 inst1) ///
    [aw=weight], noconstant

scalar b_ineligible = _b[dose0]
scalar b_eligible = _b[dose1]
quietly summarize dose [aw=weight] if eligible == 0
scalar mean_dose_ineligible = r(mean)
quietly summarize dose [aw=weight] if eligible == 1
scalar mean_dose_eligible = r(mean)

scalar ineligible_effect = b_ineligible * mean_dose_ineligible
scalar eligible_nonrecipient_effect = b_eligible * mean_dose_eligible
scalar population_effect = (8400 * ineligible_effect + 1600 * eligible_nonrecipient_effect) / (8400 + 1600)

display as text "ANSWER: ineligible_effect estimate=" %24.16g ineligible_effect " se=NA n_obs=" %9.0f `n_obs'
display as text "ANSWER: eligible_nonrecipient_effect estimate=" %24.16g eligible_nonrecipient_effect " se=NA n_obs=" %9.0f `n_obs'
display as text "ANSWER: population_effect estimate=" %24.16g population_effect " se=NA n_obs=" %9.0f `n_obs'
