d <- read.csv('households.csv')
d <- subset(d, recipient == 0)
stopifnot(nrow(d) == 300L, all(d$weight > 0), all(d$eligible %in% 0:1))
N <- nrow(d)
G <- cbind(1-d$eligible, d$eligible)
X <- cbind(G, d$baseline*(1-d$eligible), d$baseline*d$eligible)
D <- cbind(d$dose*(1-d$eligible), d$dose*d$eligible)
Z <- cbind(X, d$instrument*(1-d$eligible), d$instrument*d$eligible)
W <- diag(d$weight)
# Weighted 2SLS via weighted projection onto instrument columns.
A <- crossprod(Z, W %*% Z)
PZWD <- Z %*% solve(A, crossprod(Z, W %*% D))
PZWX <- Z %*% solve(A, crossprod(Z, W %*% X))
PZWY <- Z %*% solve(A, crossprod(Z, W %*% d$outcome))
B <- cbind(D, X)
BP <- cbind(PZWD, PZWX)
beta <- solve(crossprod(B, W %*% cbind(PZWD, PZWX)), crossprod(B, W %*% PZWY))
slope <- beta[1:2,1]
means <- sapply(0:1, function(g) weighted.mean(d$dose[d$eligible==g], d$weight[d$eligible==g]))
eff <- slope * means
pop <- sum(eff*c(8400,1600))/10000
cat(sprintf('R independent check: n=%d slopes=%.12g,%.12g means=%.12g,%.12g effects=%.12g,%.12g population=%.12g\n', N,slope[1],slope[2],means[1],means[2],eff[1],eff[2],pop))
