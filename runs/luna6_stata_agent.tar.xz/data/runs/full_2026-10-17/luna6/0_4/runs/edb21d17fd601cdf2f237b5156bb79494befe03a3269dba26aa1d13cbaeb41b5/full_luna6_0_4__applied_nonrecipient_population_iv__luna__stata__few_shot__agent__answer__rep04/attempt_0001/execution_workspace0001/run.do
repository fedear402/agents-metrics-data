clear all
set more off
set type double

import delimited using "households.csv", clear
keep if recipient == 0
count
local n_obs = r(N)

generate double g0 = 1 - eligible
generate double g1 = eligible
generate double dose0 = dose * g0
generate double dose1 = dose * g1
generate double base0 = baseline * g0
generate double base1 = baseline * g1
generate double inst0 = instrument * g0
generate double inst1 = instrument * g1

ivregress 2sls outcome g0 g1 base0 base1 ///
    (dose0 dose1 = g0 g1 base0 base1 inst0 inst1) [aw=weight], noconstant

scalar b0 = _b[dose0]
scalar b1 = _b[dose1]
quietly summarize dose [aw=weight] if eligible == 0, meanonly
scalar e0 = b0 * r(mean)
quietly summarize dose [aw=weight] if eligible == 1, meanonly
scalar e1 = b1 * r(mean)

import delimited using "census.csv", clear
quietly summarize nonrecipient_population if eligible == 0, meanonly
scalar n0 = r(mean)
quietly summarize nonrecipient_population if eligible == 1, meanonly
scalar n1 = r(mean)
scalar epop = (e0*n0 + e1*n1)/(n0+n1)

display "ANSWER: ineligible_effect estimate=" %24.16g (e0) " se=NA n_obs=" %9.0f (`n_obs')
display "ANSWER: eligible_nonrecipient_effect estimate=" %24.16g (e1) " se=NA n_obs=" %9.0f (`n_obs')
display "ANSWER: population_effect estimate=" %24.16g (epop) " se=NA n_obs=" %9.0f (`n_obs')
exit, clear
