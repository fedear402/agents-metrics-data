import pandas as pd
import numpy as np

cross = pd.read_csv('crosswalk.csv')
trade = pd.read_csv('trade.csv').merge(cross, on='code', validate='many_to_one')
areas = pd.read_csv('areas.csv')
employment = pd.read_csv('employment.csv')
outcomes = pd.read_csv('outcomes.csv')
assert len(outcomes) == 72
assert cross.industry.nunique() == 4
assert trade.groupby(['period','industry']).size().eq(1).all()

nat = employment.groupby(['period','vintage','industry'], as_index=False).employment.sum().rename(columns={'employment':'national_emp'})
grid = areas.merge(cross[['industry']].drop_duplicates(), how='cross')
grid = grid.merge(employment, on=['area','period','vintage','industry'], how='left', validate='one_to_one')
grid['employment'] = grid.employment.fillna(0)
grid = grid.merge(nat, on=['period','vintage','industry'], validate='many_to_one')
grid = grid.merge(trade.drop(columns='code'), on=['period','industry'], validate='many_to_one')
assert (grid.national_emp > 0).all()
for shock, dest in [('us_change','x'),('other_change','z')]:
    grid[dest] = (grid.employment/grid.total_employment)*(grid[shock]/grid.national_emp)/(grid.price_index/100)/1000*(10/grid.years)
exp = grid.groupby(['area','period','vintage'])[['x','z']].sum().unstack('vintage')
x = exp['x']['base'].rename('x')
z = exp['z']['early'].rename('z')
dat = outcomes.merge(pd.concat([x,z],axis=1).reset_index(), on=['area','period'], validate='one_to_one').merge(areas.query("vintage=='base'") [['area','period','population']], on=['area','period'], validate='one_to_one')
assert dat[['x','z']].notna().all().all() and len(dat)==72

# Weighted 2SLS: solve the weighted projection onto all instruments, then regress y on fitted regressors.
Y = dat.change_pp.to_numpy()
X = np.column_stack([np.ones(len(dat)), dat.period.eq(1).astype(float), dat.control, dat.x])
Q = np.column_stack([np.ones(len(dat)), dat.period.eq(1).astype(float), dat.control, dat.z])
w = dat.population.to_numpy(dtype=float)
WQ = Q * w[:,None]
P_X = Q @ np.linalg.solve(Q.T @ WQ, WQ.T @ X)
P_Y = Q @ np.linalg.solve(Q.T @ WQ, WQ.T @ Y)
beta = np.linalg.solve(X.T @ (w[:,None]*P_X), X.T @ (w*P_Y))

lookup = dat.set_index(['area','period'])
print('rows', len(dat))
print('x', beta[-1])
print('area0p0x', lookup.loc[(0,0),'x'])
print('area0p1x', lookup.loc[(0,1),'x'])
print('area0p0z', lookup.loc[(0,0),'z'])
# Verify the 2SLS identity using the weighted residualized instrument and endogenous regressor.
A = X[:,:3]
# Weighted partial-out projection onto exogenous columns.
resx = X[:,-1] - A @ np.linalg.solve(A.T @ (w[:,None]*A), A.T @ (w*X[:,-1]))
resz = dat.z.to_numpy() - A @ np.linalg.solve(A.T @ (w[:,None]*A), A.T @ (w*dat.z.to_numpy()))
resy = Y - A @ np.linalg.solve(A.T @ (w[:,None]*A), A.T @ (w*Y))
wald = np.sum(w*resz*resy)/np.sum(w*resz*resx)
print('partialled_ratio', wald)
assert abs(beta[-1]-wald) < 1e-9
