clear all
set more off
set linesize 255
import delimited "./input.csv", clear
keep if abs(score) < 1
gen double w = 1 - abs(score)
gen byte right = score >= 0
gen double xright = score * right
gen double xleft = score * (1-right)

* Jointly estimate both outcomes using the same local-linear design.
* HC0 covariance is based on the weighted least-squares score and bread.
* Stata analytic weights produce the WLS point estimates; obtain robust HC0
* covariance via explicit matrix calculations without df correction.
quietly count
scalar N = r(N)

* Design columns: left intercept, left slope, right intercept, right slope.
gen double lconst = 1-right
gen double rconst = right
mkmat earnings participated lconst xleft rconst xright w, matrix(M)

mata:
M = st_matrix("M")
y1 = M[,1]
y2 = M[,2]
X = (M[,3], M[,4], M[,5], M[,6])
w = M[,7]
W = diag(w)
A = invsym(X' * W * X)
b1 = A * X' * W * y1
b2 = A * X' * W * y2
u1 = y1 - X*b1
u2 = y2 - X*b2
S11 = X' * diag(w:^2 :* u1:^2) * X
S22 = X' * diag(w:^2 :* u2:^2) * X
S12 = X' * diag(w:^2 :* u1 :* u2) * X
V11 = A*S11*A
V22 = A*S22*A
V12 = A*S12*A
c = (-1,0,1,0)
rf = c*b1
fs = c*b2
vrf = c*V11*c'
vfs = c*V22*c'
covrf_fs = c*V12*c'
te = rf/fs
vte = vrf/(fs^2) + (rf^2)*vfs/(fs^4) - 2*rf*covrf_fs/(fs^3)
st_numscalar("rf",rf)
st_numscalar("fs",fs)
st_numscalar("te",te)
st_numscalar("serf",sqrt(vrf))
st_numscalar("sefs",sqrt(vfs))
st_numscalar("sete",sqrt(vte))
end

display "ANSWER: treatment_effect estimate=" %21.12f te " se=" %21.12f sete " n_obs=" %12.0f N
display "ANSWER: reduced_form estimate=" %21.12f rf " se=" %21.12f serf " n_obs=" %12.0f N
display "ANSWER: first_stage estimate=" %21.12f fs " se=" %21.12f sefs " n_obs=" %12.0f N
