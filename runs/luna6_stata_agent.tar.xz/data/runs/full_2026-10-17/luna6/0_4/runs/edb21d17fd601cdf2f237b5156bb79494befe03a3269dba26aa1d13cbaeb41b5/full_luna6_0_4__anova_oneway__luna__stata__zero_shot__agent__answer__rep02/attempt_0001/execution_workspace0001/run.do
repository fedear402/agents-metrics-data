clear all
set more off
set linesize 255
import delimited using "./input.csv", clear
quietly summarize y
scalar grand_mean = r(mean)
scalar N_value = r(N)
quietly levelsof group, local(groups)
scalar k_value = 0
scalar ss_between = 0
foreach g of local groups {
    quietly summarize y if group == `g'
    scalar k_value = k_value + 1
    scalar ss_between = ss_between + r(N) * (r(mean) - grand_mean)^2
}
scalar df_num_value = k_value - 1
scalar df_den_value = N_value - k_value
scalar ss_within = 0
foreach g of local groups {
    quietly summarize y if group == `g'
    scalar group_mean = r(mean)
    quietly generate double sq_dev = (y - group_mean)^2 if group == `g'
    quietly summarize sq_dev, meanonly
    scalar ss_within = ss_within + r(sum)
    drop sq_dev
}
scalar F_value = (ss_between / df_num_value) / (ss_within / df_den_value)
scalar p_value_result = Ftail(df_num_value, df_den_value, F_value)
display "ANSWER: F estimate=" %21.12f F_value " se=" %21.12f . " n_obs=" %12.0f N_value
display "ANSWER: df_num estimate=" %21.12f df_num_value " se=" %21.12f . " n_obs=" %12.0f N_value
display "ANSWER: df_den estimate=" %21.12f df_den_value " se=" %21.12f . " n_obs=" %12.0f N_value
display "ANSWER: p_value estimate=" %21.12f p_value_result " se=" %21.12f . " n_obs=" %12.0f N_value
