clear all
set more off
set linesize 255
import delimited using "./input.csv", clear
keep if abs(score) < 1
count
scalar n_obs = r(N)
gen byte right = score >= 0
gen double x_right = score * right
gen double weight = 1 - abs(score)

* Common design: separate intercepts and slopes on each side.
mata:
    st_view(score=., ., "score")
    st_view(right=., ., "right")
    st_view(xright=., ., "x_right")
    st_view(w=., ., "weight")
    st_view(y=., ., "earnings")
    st_view(d=., ., "participated")
    X = (1 :- right, right, score :* (1 :- right), xright)
    W = diag(w)
    A = invsym(X' * W * X)
    B = A * X' * W
    Y = (y, d)
    beta = B * Y
    resid = Y - X * beta
    Vjoint = J(8,8,0)
    V11 = J(4,4,0)
    V12 = J(4,4,0)
    V22 = J(4,4,0)
    for (i=1; i<=rows(X); i++) {
        xi = X[i,.]'
        ui = resid[i,.]'
        h = w[i]^2 * (A * (xi * xi') * A)
        V11 = V11 + h * (ui[1]^2)
        V12 = V12 + h * (ui[1] * ui[2])
        V22 = V22 + h * (ui[2]^2)
    }
    q = (-1,1,0,0)'
    rf = beta[2,1] - beta[1,1]
    fs = beta[2,2] - beta[1,2]
    vrf = q' * V11 * q
    vfs = q' * V22 * q
    covrf_fs = q' * V12 * q
    te = rf/fs
    vte = vrf/(fs^2) + (rf^2)*vfs/(fs^4) - 2*rf*covrf_fs/(fs^3)
    st_numscalar("rf", rf)
    st_numscalar("fs", fs)
    st_numscalar("te", te)
    st_numscalar("se_rf", sqrt(vrf))
    st_numscalar("se_fs", sqrt(vfs))
    st_numscalar("se_te", sqrt(vte))
end

display "ANSWER: treatment_effect estimate=" %21.12f scalar(te) " se=" %21.12f scalar(se_te) " n_obs=" %12.0f scalar(n_obs)
display "ANSWER: reduced_form estimate=" %21.12f scalar(rf) " se=" %21.12f scalar(se_rf) " n_obs=" %12.0f scalar(n_obs)
display "ANSWER: first_stage estimate=" %21.12f scalar(fs) " se=" %21.12f scalar(se_fs) " n_obs=" %12.0f scalar(n_obs)
