clear all
set more off
set type double
import delimited using "households.csv", clear
keep if recipient == 0
gen double dose0 = dose*(1-eligible)
gen double dose1 = dose*eligible
gen double ex0 = 1-eligible
gen double ex1 = eligible
gen double base0 = baseline*(1-eligible)
gen double base1 = baseline*eligible
gen double inst0 = instrument*(1-eligible)
gen double inst1 = instrument*eligible
count
local n = r(N)
ivregress 2sls outcome ex0 ex1 base0 base1 (dose0 dose1 = inst0 inst1) [aw=weight], noconstant
scalar b0 = _b[dose0]
scalar b1 = _b[dose1]
summarize dose [aw=weight] if eligible==0, meanonly
scalar e0 = b0*r(mean)
summarize dose [aw=weight] if eligible==1, meanonly
scalar e1 = b1*r(mean)
import delimited using "census.csv", clear
summarize nonrecipient_population if eligible==0, meanonly
scalar n0 = r(mean)
summarize nonrecipient_population if eligible==1, meanonly
scalar n1 = r(mean)
scalar ep = (e0*n0+e1*n1)/(n0+n1)
display "ANSWER: ineligible_effect estimate=" %24.16g e0 " se=NA n_obs=" `n'
display "ANSWER: eligible_nonrecipient_effect estimate=" %24.16g e1 " se=NA n_obs=" `n'
display "ANSWER: population_effect estimate=" %24.16g ep " se=NA n_obs=" `n'
exit, clear
