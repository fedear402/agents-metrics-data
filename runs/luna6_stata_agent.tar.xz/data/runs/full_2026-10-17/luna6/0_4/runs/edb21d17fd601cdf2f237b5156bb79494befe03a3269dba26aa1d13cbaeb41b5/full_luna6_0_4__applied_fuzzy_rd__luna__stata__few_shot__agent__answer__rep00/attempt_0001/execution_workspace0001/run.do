version 19.0
clear all
set more off
set linesize 255
import delimited using "./input.csv", clear

keep if abs(score) < 1
count
scalar n_obs = r(N)
generate double weight = 1 - abs(score)
generate double right = score >= 0
generate double score_left = score * (score < 0)
generate double score_right = score * (score >= 0)

* Fit both outcomes on the same weighted local-linear design.
* Recover the joint HC0 covariance from the same weighted design and residuals.
* Aweights in Stata yield the conventional WLS HC0 sandwich in this case.
mata:
    X = st_data(., ("right", "score_left", "score_right"))
    X = (J(rows(X), 1, 1), X)
    w = st_data(., "weight")
    Y = st_data(., ("earnings", "participated"))
    bread = invsym(X' * (w :* X))
    B = bread * X' * (w :* Y)
    E = Y - X * B
    // Both discontinuities are the right-side intercept coefficients.
    C = (0, 1, 0, 0)
    jumps = C * B
    loading = w :* (X * bread * C')
    influence = loading :* E
    V = influence' * influence
    st_numscalar("rf", jumps[1,1])
    st_numscalar("fs", jumps[1,2])
    st_numscalar("rfvar", V[1,1])
    st_numscalar("fsvar", V[2,2])
    st_numscalar("rffs_cov", V[1,2])
end

scalar reduced_form = rf
scalar reduced_form_se = sqrt(rfvar)
scalar first_stage = fs
scalar first_stage_se = sqrt(fsvar)
scalar treatment_effect = reduced_form / first_stage
scalar ratio_gradient_rf = 1 / first_stage
scalar ratio_gradient_fs = -reduced_form / (first_stage^2)
scalar treatment_var = ratio_gradient_rf^2 * rfvar + ratio_gradient_fs^2 * fsvar + 2 * ratio_gradient_rf * ratio_gradient_fs * rffs_cov
scalar treatment_se = sqrt(treatment_var)

display "ANSWER: treatment_effect estimate=" %21.12f treatment_effect " se=" %21.12f treatment_se " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f reduced_form " se=" %21.12f reduced_form_se " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f first_stage " se=" %21.12f first_stage_se " n_obs=" %12.0f n_obs
