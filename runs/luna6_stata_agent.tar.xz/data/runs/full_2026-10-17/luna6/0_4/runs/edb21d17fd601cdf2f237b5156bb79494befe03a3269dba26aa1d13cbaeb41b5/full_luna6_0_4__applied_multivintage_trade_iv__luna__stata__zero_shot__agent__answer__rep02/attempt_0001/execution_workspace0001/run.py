import csv
import numpy as np
from collections import defaultdict

def rows(path):
    with open(path, newline='') as f: return list(csv.DictReader(f))

a=rows('areas.csv'); e=rows('employment.csv'); t=rows('trade.csv'); c=rows('crosswalk.csv'); o=rows('outcomes.csv')
cw={r['code']:int(r['industry']) for r in c}
trade={(int(r['period']),cw[r['code']]):r for r in t}
em={(int(r['area']),int(r['period']),r['vintage'],int(r['industry'])):int(r['employment']) for r in e}
area={(int(r['area']),int(r['period']),r['vintage']):r for r in a}
nat=defaultdict(int)
for (ar,p,v,j),val in em.items(): nat[p,v,j]+=val
# Missing cells are zero. Use total employment for each matching vintage.
X={}; Z={}
for ar in range(36):
 for p in range(2):
  for v, dest, tradevar in [('base',X,'us_change'),('early',Z,'other_change')]:
   ag=area[ar,p,v]; total=float(ag['total_employment']); val=0.
   for j in range(4):
    tr=trade[p,j]
    val+=(em.get((ar,p,v,j),0)/total)*(float(tr[tradevar])/nat[p,v,j])/(float(tr['price_index'])/100)/1000*(10/float(tr['years']))
   dest[ar,p]=val
# Weighted 2SLS: regress y on [constant, period, control, x], instrument x with z; exogenous columns instrument themselves.
Y=[]; W=[]; Q=[]; ZM=[]
for r in o:
 ar,p=int(r['area']),int(r['period']); ag=area[ar,p,'base']
 Y.append(float(r['change_pp'])); W.append(float(ag['population']))
 ex=[1.,float(p),float(r['control'])]
 Q.append(ex+[X[ar,p]])
 ZM.append(ex+[Z[ar,p]])
Y=np.array(Y); W=np.array(W); Q=np.array(Q); ZM=np.array(ZM)
# Weighted 2SLS formula (Z'WZ)^-1 etc.
A=ZM.T@(W[:,None]*ZM)
B=ZM.T@(W[:,None]*Q)
C=ZM.T@(W*Y)
beta=np.linalg.solve(B.T@np.linalg.solve(A,B),B.T@np.linalg.solve(A,C))
print('independent_iv_slope',format(beta[3],'.15g'))
print('independent_exposure00',format(X[0,0],'.15g'))
print('independent_exposure01',format(X[0,1],'.15g'))
print('independent_instrument00',format(Z[0,0],'.15g'))
