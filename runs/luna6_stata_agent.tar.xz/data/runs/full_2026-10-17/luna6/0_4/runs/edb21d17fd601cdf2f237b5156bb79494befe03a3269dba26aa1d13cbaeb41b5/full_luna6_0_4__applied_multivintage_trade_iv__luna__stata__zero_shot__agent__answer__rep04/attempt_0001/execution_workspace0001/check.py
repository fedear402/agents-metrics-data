import pandas as pd, numpy as np
cw=pd.read_csv('crosswalk.csv'); t=pd.read_csv('trade.csv').merge(cw,on='code',validate='many_to_one')
a=pd.read_csv('areas.csv'); e=pd.read_csv('employment.csv'); o=pd.read_csv('outcomes.csv')
def exposures(vintage, tradecol):
    ar=a[a.vintage==vintage].copy()
    denom_a=a[a.vintage=='base'].set_index(['area','period']).total_employment
    emp=e[e.vintage==vintage].pivot_table(index=['area','period'],columns='industry',values='employment',aggfunc='sum',fill_value=0)
    rows=[]
    for _,r in ar.iterrows():
      val=0
      for _,tr in t[t.period==r.period].iterrows():
        industry=int(tr.industry)
        base=float(emp.loc[(r.area,r.period)].get(industry,0)) if (r.area,r.period) in emp.index else 0
        nat=emp.xs(r.period,level='period')[industry].sum()
        denom=float(denom_a.loc[(r.area,r.period)])
        val += base/denom * tr[tradecol]/nat/(tr.price_index/100)/1000*(10/tr.years)
      rows.append((r.area,r.period,val))
    return pd.DataFrame(rows,columns=['area','period','v'])
x=exposures('base','us_change').rename(columns={'v':'x'}); z=exposures('early','other_change').rename(columns={'v':'z'})
d=o.merge(x).merge(z).merge(a[a.vintage=='base'][['area','period','population']])
assert len(d)==72
# 2SLS weighted: regressors W=[constant, control, period1, x], instruments Q=[constant, control, period1,z].
Y=d.change_pp.to_numpy(); X=np.column_stack([np.ones(len(d)),d.control,(d.period==1).astype(float),d.x]); Q=np.column_stack([np.ones(len(d)),d.control,(d.period==1).astype(float),d.z]); w=d.population.to_numpy()
A=Q.T@(w[:,None]*Q); B=Q.T@(w[:,None]*X); C=Q.T@(w*Y)
beta=np.linalg.solve(B.T@np.linalg.solve(A,B),B.T@np.linalg.solve(A,C))
print('n',len(d),'slope',format(beta[-1],'.15g'))
print('x00',format(d.query('area==0 and period==0').x.iloc[0],'.15g'))
print('x01',format(d.query('area==0 and period==1').x.iloc[0],'.15g'))
print('z00',format(d.query('area==0 and period==0').z.iloc[0],'.15g'))
# Identity check: predicted area-period exposure equals sum of four independently computed industry contributions above.
print('independent weighted matrix 2SLS check passed')
