clear all
set more off
set linesize 255
import delimited using "./input.csv", clear

gen double date_num = daily(date, "YMD")
format date_num %td
sort date_num

gen double log_sales = ln(sales)
gen double log_vix = ln(vix)
gen double dlog_vix = log_vix - log_vix[_n-1]

forvalues j = 1/15 {
    gen double lag_`j' = dlog_vix[_n-`j']
}

regress log_sales lag_1-lag_15
scalar N = e(N)
scalar bsum = 0
keep if !missing(log_sales, lag_1-lag_15)
forvalues j = 1/15 {
    scalar bsum = bsum + _b[lag_`j']
}

mata:
    st_view(y=., ., "log_sales")
    st_view(Xall=., ., (8..22))
    X = J(rows(y),1,1), Xall
    yy = y
    n = rows(X)
    b = invsym(X'X)*X'yy
    u = yy-X*b
    S = J(cols(X),cols(X),0)
    for (t=1; t<=n; t++) {
        q = X[t,.]'*u[t]
        S = S + q*q'
    }
    for (j=1; j<=15; j++) {
        w = 1-j/16
        for (t=j+1; t<=n; t++) {
            qt = X[t,.]'*u[t]
            qs = X[t-j,.]'*u[t-j]
            S = S + w*(qt*qs' + qs*qt')
        }
    }
    V = invsym(X'X)*S*invsym(X'X)*(n/(n-16))
    c = J(1,16,0)
    c[1,2..16] = J(1,15,1)
    st_numscalar("se_cum", sqrt(c*V*c'))
    st_numscalar("se_l1", sqrt(V[2,2]))
    st_numscalar("se_l15", sqrt(V[16,16]))
    st_numscalar("mata_n", n)
end

display "ANSWER: cumulative_response estimate=" %21.12f bsum " se=" %21.12f se_cum " n_obs=" %12.0f mata_n
display "ANSWER: lag_1 estimate=" %21.12f _b[lag_1] " se=" %21.12f se_l1 " n_obs=" %12.0f mata_n
display "ANSWER: lag_15 estimate=" %21.12f _b[lag_15] " se=" %21.12f se_l15 " n_obs=" %12.0f mata_n
