import json
import numpy as np
import pandas as pd

df = pd.read_csv('input.csv')

# Normalize weights using one obs per region
regions = df.drop_duplicates('region_id')[['region_id', 'region_weight']].copy()
regions['e'] = regions['region_weight'] / regions['region_weight'].sum()
df = df.merge(regions[['region_id', 'e']], on='region_id')

# Regional-level data
reg = df.drop_duplicates('region_id')[['region_id', 'e', 'x', 'y']].copy()
# Compute z_r = sum_n share_rn * shock_n
z_r = df.groupby('region_id').apply(lambda g: (g['share'] * g['shock']).sum()).reset_index()
z_r.columns = ['region_id', 'z']
reg = reg.merge(z_r, on='region_id')
e = reg['e'].values
x = reg['x'].values
y = reg['y'].values
z = reg['z'].values

# Subtract weighted means
x0 = x - np.dot(e, x)
y0 = y - np.dot(e, y)
z0 = z - np.dot(e, z)

# Industry-level aggregation
industries = df['industry_id'].unique()
N = len(industries)

# s_n = sum_r e_r * share_rn
# vbar_n = sum_r e_r * share_rn * v0_r / s_n

# Map region e, x0, y0, z0 back to df rows
reg_map = reg.set_index('region_id')[['e', 'x', 'y', 'z']].copy()
reg_map['x0'] = x0
reg_map['y0'] = y0
reg_map['z0'] = z0

df2 = df.merge(reg_map[['x0','y0','z0']].rename_axis('region_id').reset_index(), on='region_id')
df2 = df2.merge(reg_map[['e']].rename_axis('region_id').reset_index(), on='region_id', suffixes=('','_dup'))
# e already in df2 from earlier merge

def agg_industry(df2, industries):
    results = []
    for ind in industries:
        mask = df2['industry_id'] == ind
        sub = df2[mask]
        shock_val = sub['shock'].iloc[0]
        s_n = (sub['e'] * sub['share']).sum()
        xbar = (sub['e'] * sub['share'] * sub['x0']).sum() / s_n
        ybar = (sub['e'] * sub['share'] * sub['y0']).sum() / s_n
        zbar = (sub['e'] * sub['share'] * sub['z0']).sum() / s_n
        results.append({'industry_id': ind, 'shock': shock_val, 's': s_n, 'xbar': xbar, 'ybar': ybar, 'zbar': zbar})
    return pd.DataFrame(results)

agg = agg_industry(df2, industries)
s = agg['s'].values
shock = agg['shock'].values
xbar = agg['xbar'].values
ybar = agg['ybar'].values
zbar = agg['zbar'].values

def shock_iv(dependent, endogenous, instrument, weights, N):
    regressors = np.column_stack([np.ones(N), endogenous])
    instruments = np.column_stack([np.ones(N), instrument])
    cross = instruments.T @ (weights[:,None] * regressors)
    beta = np.linalg.solve(cross, instruments.T @ (weights * dependent))
    residual = dependent - regressors @ beta
    scores = instruments * (weights * residual)[:,None]
    inverse = np.linalg.inv(cross)
    hc1 = N / (N - 2)
    covariance = hc1 * inverse @ (scores.T @ scores) @ inverse.T
    return float(beta[1]), float(np.sqrt(covariance[1,1]))

# Effect: shock-level IV of ybar on xbar, instrument=shock, weights=s
effect, effect_se = shock_iv(ybar, xbar, shock, s, N)

# First stage: shock-level IV of xbar on zbar, instrument=shock, weights=s
first_stage, first_stage_se = shock_iv(xbar, zbar, shock, s, N)

# Effective shocks
effective_shocks = float(1.0 / np.sum(s**2))

output = {
    'task_id': 'applied_shift_share',
    'platform': 'python',
    'estimates': [
        {'term': 'effect', 'estimate': effect, 'se': effect_se, 'n_obs': N},
        {'term': 'first_stage', 'estimate': first_stage, 'se': first_stage_se, 'n_obs': N},
        {'term': 'effective_shocks', 'estimate': effective_shocks, 'se': None, 'n_obs': N}
    ],
    'method_metadata': {'estimator': 'shift_share_2SLS_BHJ', 'vcov': 'shock_level_HC1'},
    'diagnostics': {}
}

with open('result.json', 'w') as f:
    json.dump(output, f, indent=2, allow_nan=False)
