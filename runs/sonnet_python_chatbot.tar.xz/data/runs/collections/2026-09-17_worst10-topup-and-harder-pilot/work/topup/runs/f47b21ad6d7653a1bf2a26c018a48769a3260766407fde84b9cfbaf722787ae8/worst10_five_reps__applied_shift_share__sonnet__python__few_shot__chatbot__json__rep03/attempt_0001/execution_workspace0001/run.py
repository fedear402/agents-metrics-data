import json
import numpy as np
import pandas as pd

df = pd.read_csv('input.csv')

# One obs per region for weights
regions = df.drop_duplicates('region_id')[['region_id', 'region_weight', 'x', 'y']].copy()
regions['e'] = regions['region_weight'] / regions['region_weight'].sum()

# Merge weights back
df = df.merge(regions[['region_id', 'e']], on='region_id')

# Compute shift-share instrument per region
df['z'] = df['share'] * df['shock']
region_z = df.groupby('region_id')['z'].sum().reset_index().rename(columns={'z': 'z_r'})
regions = regions.merge(region_z, on='region_id')

e = regions['e'].values
x_r = regions['x'].values
y_r = regions['y'].values
z_r = regions['z_r'].values

# Weighted means
x_mean = e @ x_r
y_mean = e @ y_r
z_mean = e @ z_r

# Centered
x0 = x_r - x_mean
y0 = y_r - y_mean
z0 = z_r - z_mean

# Industry-level aggregation
industries = df['industry_id'].unique()
industry_ids = sorted(industries)

df_ind = df.set_index('industry_id')

s_n = {}
ybar_n = {}
xbar_n = {}
zbar_n = {}
shock_n = {}

# Map region to centered values
region_map = regions.set_index('region_id')
e_map = region_map['e']
x0_map = region_map['x'].values - x_mean
y0_map = region_map['y'].values - y_mean
z0_map = region_map['z_r'].values - z_mean

region_ids = region_map.index.values
x0_dict = dict(zip(region_ids, x0_map))
y0_dict = dict(zip(region_ids, y0_map))
z0_dict = dict(zip(region_ids, z0_map))
e_dict = dict(zip(region_ids, e_map))

for ind in industry_ids:
    sub = df[df['industry_id'] == ind]
    e_sub = sub['region_id'].map(e_dict).values
    share_sub = sub['share'].values
    sn = np.sum(e_sub * share_sub)
    s_n[ind] = sn
    
    x0_sub = sub['region_id'].map(x0_dict).values
    y0_sub = sub['region_id'].map(y0_dict).values
    z0_sub = sub['region_id'].map(z0_dict).values
    
    xbar_n[ind] = np.sum(e_sub * share_sub * x0_sub) / sn
    ybar_n[ind] = np.sum(e_sub * share_sub * y0_sub) / sn
    zbar_n[ind] = np.sum(e_sub * share_sub * z0_sub) / sn
    shock_n[ind] = sub['shock'].iloc[0]

s_arr = np.array([s_n[ind] for ind in industry_ids])
ybar_arr = np.array([ybar_n[ind] for ind in industry_ids])
xbar_arr = np.array([xbar_n[ind] for ind in industry_ids])
zbar_arr = np.array([zbar_n[ind] for ind in industry_ids])
shock_arr = np.array([shock_n[ind] for ind in industry_ids])

N = len(industry_ids)

def shock_iv(dependent, endogenous, instrument, weights):
    regressors = np.column_stack([np.ones(N), endogenous])
    instruments = np.column_stack([np.ones(N), instrument])
    W = weights
    cross = instruments.T @ (W[:,None] * regressors)
    beta = np.linalg.solve(cross, instruments.T @ (W * dependent))
    residual = dependent - regressors @ beta
    scores = instruments * (W * residual)[:,None]
    inverse = np.linalg.inv(cross)
    hc1 = N / (N - 2)
    covariance = hc1 * inverse @ (scores.T @ scores) @ inverse.T
    return float(beta[1]), float(np.sqrt(covariance[1, 1]))

effect, effect_se = shock_iv(ybar_arr, xbar_arr, shock_arr, s_arr)
first_stage, first_stage_se = shock_iv(xbar_arr, zbar_arr, shock_arr, s_arr)

effective_shocks = float(1.0 / np.sum(s_arr**2))

output = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": effect, "se": effect_se, "n_obs": N},
        {"term": "first_stage", "estimate": first_stage, "se": first_stage_se, "n_obs": N},
        {"term": "effective_shocks", "estimate": effective_shocks, "se": None, "n_obs": N}
    ],
    "method_metadata": {"estimator": "2SLS shift-share BHJ", "vcov": "HC1 shock-level"},
    "diagnostics": {}
}

with open('result.json', 'w') as f:
    json.dump(output, f, indent=2, allow_nan=False)
