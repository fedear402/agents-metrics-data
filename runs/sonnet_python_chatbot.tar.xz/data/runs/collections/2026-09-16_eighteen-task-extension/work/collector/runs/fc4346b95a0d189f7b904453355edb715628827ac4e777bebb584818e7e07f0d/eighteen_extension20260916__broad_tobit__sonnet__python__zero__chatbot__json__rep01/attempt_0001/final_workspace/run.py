import pandas as pd
import numpy as np
from scipy import stats
from scipy.optimize import minimize
import json

df = pd.read_csv('./input.csv')
y = df['y'].values
x = df['x'].values
z = df['z'].values
n = len(df)

X = np.column_stack([np.ones(n), x, z])

def neg_log_likelihood(params):
    beta = params[:3]
    log_sigma = params[3]
    sigma = np.exp(log_sigma)
    
    mu = X @ beta
    
    censored = (y == 0)
    uncensored = ~censored
    
    ll = 0.0
    if uncensored.any():
        ll += np.sum(stats.norm.logpdf(y[uncensored], loc=mu[uncensored], scale=sigma))
    if censored.any():
        ll += np.sum(stats.norm.logcdf(0, loc=mu[censored], scale=sigma))
    
    return -ll

# Initial values via OLS on uncensored
from numpy.linalg import lstsq
uncensored_mask = y > 0
beta_init = lstsq(X[uncensored_mask], y[uncensored_mask], rcond=None)[0]
sigma_init = np.std(y[uncensored_mask] - X[uncensored_mask] @ beta_init)
params_init = np.append(beta_init, np.log(sigma_init))

result = minimize(neg_log_likelihood, params_init, method='BFGS',
                  options={'maxiter': 10000, 'gtol': 1e-8})

params_opt = result.x
hess_inv = result.hess_inv

# Standard errors from observed information (numerical Hessian)
from scipy.optimize import approx_fprime

def hessian(f, x0, eps=1e-5):
    n = len(x0)
    H = np.zeros((n, n))
    for i in range(n):
        def grad_i(x):
            return approx_fprime(x, f, eps)[i]
        H[i] = approx_fprime(x0, grad_i, eps)
    return H

H = hessian(neg_log_likelihood, params_opt)
cov = np.linalg.inv(H)
se = np.sqrt(np.diag(cov))

beta_opt = params_opt[:3]
log_sigma_opt = params_opt[3]
sigma_opt = np.exp(log_sigma_opt)

# SE for sigma via delta method: se_sigma = sigma * se_log_sigma
se_sigma = sigma_opt * se[3]

estimates = [
    {"term": "const", "estimate": float(beta_opt[0]), "se": float(se[0]), "n_obs": n},
    {"term": "x", "estimate": float(beta_opt[1]), "se": float(se[1]), "n_obs": n},
    {"term": "z", "estimate": float(beta_opt[2]), "se": float(se[2]), "n_obs": n},
    {"term": "sigma", "estimate": float(sigma_opt), "se": None, "n_obs": n},
]

output = {
    "task_id": "broad_tobit",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "Tobit MLE (homoskedastic Gaussian, left-censored at 0)",
        "vcov": "observed information (numerical Hessian)"
    },
    "diagnostics": {}
}

with open('./result.json', 'w') as f:
    json.dump(output, f, indent=2)

print("Done. Results written to result.json")
print(f"const={beta_opt[0]:.6f}, x={beta_opt[1]:.6f}, z={beta_opt[2]:.6f}, sigma={sigma_opt:.6f}")
