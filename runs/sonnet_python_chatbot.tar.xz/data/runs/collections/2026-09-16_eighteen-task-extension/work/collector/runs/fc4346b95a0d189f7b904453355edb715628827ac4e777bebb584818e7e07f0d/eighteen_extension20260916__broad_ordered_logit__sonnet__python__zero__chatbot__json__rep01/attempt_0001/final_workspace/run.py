import pandas as pd
import numpy as np
import statsmodels.api as sm
from scipy import stats
import json

df = pd.read_csv('./input.csv')

# Fit ordered logit model
model = sm.MNLogit  # We'll use OrderedModel instead
from statsmodels.miscmodels.ordinal_model import OrderedModel

mod = OrderedModel(df['y'], df[['x', 'z']], distr='logistic')
res = mod.fit(method='bfgs', disp=False)

n_obs = int(len(df))

# Extract coefficients and standard errors
params = res.params
bse = res.bse

x_est = float(params['x'])
x_se = float(bse['x'])
z_est = float(params['z'])
z_se = float(bse['z'])

# Compute prob_high: P(y=3 | x=1, z=0)
# For ordered logit with categories 1,2,3:
# P(y=3) = 1 - P(y<=2) = 1 - logistic(cutpoint_2 - x*beta_x - z*beta_z)
# cutpoints in statsmodels OrderedModel are named '1/2' and '2/3'
cutpoint_names = [p for p in params.index if '/' in str(p)]
# params layout: covariates first, then thresholds
# thresholds are stored as transformed (log) values in statsmodels
# Use predict method instead

# Create a single observation dataframe
x_pred = pd.DataFrame({'x': [1.0], 'z': [0.0]})
pred_probs = res.predict(x_pred)
# pred_probs is array of shape (1, 3) for categories 1, 2, 3
prob_high = float(pred_probs[0, 2])  # P(y=3)

result = {
    "task_id": "broad_ordered_logit",
    "platform": "python",
    "estimates": [
        {"term": "x", "estimate": x_est, "se": x_se, "n_obs": n_obs},
        {"term": "z", "estimate": z_est, "se": z_se, "n_obs": n_obs},
        {"term": "prob_high", "estimate": prob_high, "se": None, "n_obs": n_obs}
    ],
    "method_metadata": {
        "estimator": "OrderedLogit_MLE",
        "vcov": "observed_information"
    },
    "diagnostics": {}
}

with open('./result.json', 'w') as f:
    json.dump(result, f, indent=2)

print("Done. Results written to result.json")
print(f"x: {x_est:.6f} (se={x_se:.6f})")
print(f"z: {z_est:.6f} (se={z_se:.6f})")
print(f"prob_high: {prob_high:.6f}")
