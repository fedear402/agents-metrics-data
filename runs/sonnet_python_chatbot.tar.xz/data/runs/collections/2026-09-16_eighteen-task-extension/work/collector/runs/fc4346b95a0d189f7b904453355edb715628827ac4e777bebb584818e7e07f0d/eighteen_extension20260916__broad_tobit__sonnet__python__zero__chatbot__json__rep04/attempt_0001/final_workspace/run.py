import pandas as pd
import numpy as np
from scipy import optimize
from scipy.stats import norm
import json

df = pd.read_csv("input.csv")
y = df["y"].values
x = df["x"].values
z = df["z"].values
n = len(y)

X = np.column_stack([np.ones(n), x, z])

def neg_log_likelihood(params):
    beta = params[:3]
    log_sigma = params[3]
    sigma = np.exp(log_sigma)
    
    xb = X @ beta
    
    ll = np.where(
        y <= 0,
        np.log(norm.cdf(-xb / sigma)),
        np.log(norm.pdf((y - xb) / sigma) / sigma)
    )
    return -np.sum(ll)

# Initial values from OLS on uncensored
mask = y > 0
from numpy.linalg import lstsq
beta0, _, _, _ = lstsq(X[mask], y[mask], rcond=None)
sigma0 = np.std(y[mask] - X[mask] @ beta0)
params0 = np.append(beta0, np.log(sigma0))

result = optimize.minimize(
    neg_log_likelihood,
    params0,
    method="BFGS",
    options={"maxiter": 10000, "gtol": 1e-8}
)

params_hat = result.x
hess_inv = result.hess_inv

# Delta method for sigma: sigma = exp(log_sigma)
# se(sigma) via delta method: se(log_sigma) * sigma
# But task says se=null for sigma, so skip

beta_hat = params_hat[:3]
log_sigma_hat = params_hat[3]
sigma_hat = np.exp(log_sigma_hat)

# Standard errors from hessian inverse (BFGS approximation)
se_all = np.sqrt(np.diag(hess_inv))
se_beta = se_all[:3]

# Use numerical hessian for more accurate SEs
from scipy.optimize import approx_fprime

def hessian_numerical(f, x0, eps=1e-5):
    n = len(x0)
    H = np.zeros((n, n))
    for i in range(n):
        def fi(xp):
            return approx_fprime(xp, f, eps)[i]
        H[i] = approx_fprime(x0, fi, eps)
    return H

H = hessian_numerical(neg_log_likelihood, params_hat)
cov = np.linalg.inv(H)
se_numerical = np.sqrt(np.diag(cov))
se_beta_numerical = se_numerical[:3]

estimates = [
    {"term": "const", "estimate": float(beta_hat[0]), "se": float(se_beta_numerical[0]), "n_obs": n},
    {"term": "x", "estimate": float(beta_hat[1]), "se": float(se_beta_numerical[1]), "n_obs": n},
    {"term": "z", "estimate": float(beta_hat[2]), "se": float(se_beta_numerical[2]), "n_obs": n},
    {"term": "sigma", "estimate": float(sigma_hat), "se": None, "n_obs": n},
]

output = {
    "task_id": "broad_tobit",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "MLE Tobit (homoskedastic Gaussian, left-censored at 0)",
        "vcov": "observed information (numerical Hessian)"
    },
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(output, f, indent=2)

print("Done. result.json written.")
