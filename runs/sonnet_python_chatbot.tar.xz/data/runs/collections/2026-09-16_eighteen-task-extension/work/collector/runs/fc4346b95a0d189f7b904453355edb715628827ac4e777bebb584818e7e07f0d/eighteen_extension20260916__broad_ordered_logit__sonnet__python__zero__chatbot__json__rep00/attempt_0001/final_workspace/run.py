import pandas as pd
import numpy as np
import json
from scipy import stats
from scipy.optimize import minimize

df = pd.read_csv('./input.csv')
n_obs = len(df)

y = df['y'].values
x = df['x'].values
z = df['z'].values

X = np.column_stack([x, z])

def ordered_logit_nll(params):
    beta = params[:2]
    c1, c2 = params[2], params[3]
    
    xb = X @ beta
    
    p1 = 1 / (1 + np.exp(-(c1 - xb)))
    p2 = 1 / (1 + np.exp(-(c2 - xb)))
    
    prob1 = p1
    prob2 = p2 - p1
    prob3 = 1 - p2
    
    prob1 = np.clip(prob1, 1e-15, 1-1e-15)
    prob2 = np.clip(prob2, 1e-15, 1-1e-15)
    prob3 = np.clip(prob3, 1e-15, 1-1e-15)
    
    ll = np.where(y==1, np.log(prob1), np.where(y==2, np.log(prob2), np.log(prob3)))
    return -np.sum(ll)

init_params = np.array([0.0, 0.0, -0.5, 0.5])
result = minimize(ordered_logit_nll, init_params, method='BFGS', options={'maxiter': 10000, 'gtol': 1e-8})

params_hat = result.x
hess_inv = result.hess_inv
se = np.sqrt(np.diag(hess_inv))

beta_x = params_hat[0]
beta_z = params_hat[1]
c1 = params_hat[2]
c2 = params_hat[3]

se_x = se[0]
se_z = se[1]

xb_pred = beta_x * 1 + beta_z * 0
p2_pred = 1 / (1 + np.exp(-(c2 - xb_pred)))
prob_high = 1 - p2_pred

output = {
    "task_id": "broad_ordered_logit",
    "platform": "python",
    "estimates": [
        {"term": "x", "estimate": float(beta_x), "se": float(se_x), "n_obs": n_obs},
        {"term": "z", "estimate": float(beta_z), "se": float(se_z), "n_obs": n_obs},
        {"term": "prob_high", "estimate": float(prob_high), "se": None, "n_obs": n_obs}
    ],
    "method_metadata": {
        "estimator": "ordered_logit_mle",
        "vcov": "observed_information_bfgs_inverse"
    },
    "diagnostics": {}
}

with open('./result.json', 'w') as f:
    json.dump(output, f, indent=2)

print("Done. Parameters:", params_hat)
print("SEs:", se)
print("prob_high:", prob_high)
