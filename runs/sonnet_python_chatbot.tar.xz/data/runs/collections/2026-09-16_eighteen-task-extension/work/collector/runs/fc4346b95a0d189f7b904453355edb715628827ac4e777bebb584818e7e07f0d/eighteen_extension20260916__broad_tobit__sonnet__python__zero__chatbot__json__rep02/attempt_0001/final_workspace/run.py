import pandas as pd
import numpy as np
from scipy import stats
from scipy.optimize import minimize
import json

df = pd.read_csv("input.csv")
y = df["y"].values
x = df["x"].values
z = df["z"].values
n = len(y)

X = np.column_stack([np.ones(n), x, z])

def neg_log_likelihood(params):
    beta = params[:3]
    log_sigma = params[3]
    sigma = np.exp(log_sigma)
    
    mu = X @ beta
    
    ll = np.where(
        y > 0,
        stats.norm.logpdf(y, loc=mu, scale=sigma),
        stats.norm.logcdf(0, loc=mu, scale=sigma)
    )
    return -np.sum(ll)

beta_init = np.linalg.lstsq(X, y, rcond=None)[0]
sigma_init = np.std(y - X @ beta_init)
params_init = np.append(beta_init, np.log(max(sigma_init, 0.1)))

result = minimize(neg_log_likelihood, params_init, method="BFGS",
                  options={"maxiter": 10000, "gtol": 1e-8})

params_opt = result.x
hess_inv = result.hess_inv

# Standard errors from inverse Hessian (BFGS approximation)
# For observed information, recompute via numerical Hessian
from scipy.optimize import approx_fprime

def hessian_numerical(f, x0, eps=1e-5):
    n = len(x0)
    H = np.zeros((n, n))
    for i in range(n):
        def grad_i(x):
            return approx_fprime(x, f, eps)[i]
        H[i] = approx_fprime(x0, grad_i, eps)
    return H

H = hessian_numerical(neg_log_likelihood, params_opt)
cov = np.linalg.inv(H)
se_all = np.sqrt(np.diag(cov))

beta_opt = params_opt[:3]
log_sigma_opt = params_opt[3]
sigma_opt = np.exp(log_sigma_opt)

# Delta method for sigma SE
# sigma = exp(log_sigma), d(sigma)/d(log_sigma) = sigma
se_log_sigma = se_all[3]
se_sigma = sigma_opt * se_log_sigma

estimates = [
    {"term": "const", "estimate": float(beta_opt[0]), "se": float(se_all[0]), "n_obs": n},
    {"term": "x",     "estimate": float(beta_opt[1]), "se": float(se_all[1]), "n_obs": n},
    {"term": "z",     "estimate": float(beta_opt[2]), "se": float(se_all[2]), "n_obs": n},
    {"term": "sigma", "estimate": float(sigma_opt),   "se": None,             "n_obs": n},
]

output = {
    "task_id": "broad_tobit",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "MLE Tobit (left-censored at 0)",
        "vcov": "observed information (numerical Hessian)"
    },
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(output, f, indent=2)

print("Done. Results written to result.json")
