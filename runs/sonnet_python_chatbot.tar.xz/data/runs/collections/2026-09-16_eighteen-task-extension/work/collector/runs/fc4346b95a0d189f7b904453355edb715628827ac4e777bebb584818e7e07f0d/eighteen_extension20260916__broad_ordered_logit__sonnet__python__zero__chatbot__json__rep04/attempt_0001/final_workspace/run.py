import pandas as pd
import numpy as np
import statsmodels.formula.api as smf
from statsmodels.miscmodels.ordinal_model import OrderedModel
import json

df = pd.read_csv("input.csv")
n_obs = len(df)

df["y"] = pd.Categorical(df["y"], categories=[1, 2, 3], ordered=True)

model = OrderedModel(df["y"], df[["x", "z"]], distr="logit")
result = model.fit(method="bfgs", disp=False)

x_est = result.params["x"]
z_est = result.params["z"]
x_se = result.bse["x"]
z_se = result.bse["z"]

# Fitted probability of category 3 for x=1, z=0
# OrderedModel params: first entries are covariates, last are cutpoints (as log-increments)
# P(Y=3) = 1 - logistic(cutpoint2 - x_est*1 - z_est*0)
# cutpoints in OrderedModel are stored as thresholds
# result.model.transform_threshold_params gives actual cutpoints
thresholds = result.model.transform_threshold_params(result.params)
# thresholds has len(categories)-1 = 2 entries

from scipy.special import expit

xb = x_est * 1 + z_est * 0
# P(Y <= 2) = expit(thresholds[1] - xb)
# P(Y = 3) = 1 - P(Y <= 2)
prob_high = 1 - expit(thresholds[1] - xb)

output = {
    "task_id": "broad_ordered_logit",
    "platform": "python",
    "estimates": [
        {"term": "x", "estimate": float(x_est), "se": float(x_se), "n_obs": n_obs},
        {"term": "z", "estimate": float(z_est), "se": float(z_se), "n_obs": n_obs},
        {"term": "prob_high", "estimate": float(prob_high), "se": None, "n_obs": n_obs}
    ],
    "method_metadata": {
        "estimator": "OrderedLogit_MLE",
        "vcov": "observed_information"
    },
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(output, f, indent=2)
