import pandas as pd
import numpy as np
import json
from scipy.optimize import minimize
from scipy.stats import norm

df = pd.read_csv('./input.csv')
y = df['y'].values
x = df['x'].values
z = df['z'].values
n_obs = len(df)

# Ordered logit via statsmodels
from statsmodels.miscmodels.ordinal_model import OrderedModel

model = OrderedModel(y, df[['x', 'z']], distr='logit')
result = model.fit(method='bfgs', disp=False)

# Extract coefficients
params = result.params
# statsmodels OrderedModel: first params are covariates, then thresholds
x_coef = params['x']
z_coef = params['z']
x_se = result.bse['x']
z_se = result.bse['z']

# Fitted probability of category 3 (highest) for x=1, z=0
# P(Y=3) = 1 - logistic(cutpoint2 - x*beta_x - z*beta_z)
# statsmodels uses threshold params named like '1/2' and '2/3'
threshold_names = [n for n in params.index if n not in ['x', 'z']]
threshold_names_sorted = sorted(threshold_names)

# For ordered logit: P(Y <= k) = logistic(cut_k - X*beta)
# P(Y = 3) = 1 - P(Y <= 2) = 1 - logistic(cut2 - x*bx - z*bz)
# The thresholds in statsmodels are on the logit scale

def logistic(v):
    return 1.0 / (1.0 + np.exp(-v))

# Get threshold values
cut1 = params[threshold_names_sorted[0]]
cut2 = params[threshold_names_sorted[1]]

# Linear predictor for x=1, z=0
lp = x_coef * 1 + z_coef * 0

# P(Y=3) = 1 - P(Y<=2) = 1 - logistic(cut2 - lp)
prob_high = 1.0 - logistic(cut2 - lp)

output = {
    "task_id": "broad_ordered_logit",
    "platform": "python",
    "estimates": [
        {"term": "x", "estimate": float(x_coef), "se": float(x_se), "n_obs": n_obs},
        {"term": "z", "estimate": float(z_coef), "se": float(z_se), "n_obs": n_obs},
        {"term": "prob_high", "estimate": float(prob_high), "se": None, "n_obs": n_obs}
    ],
    "method_metadata": {
        "estimator": "OrderedLogit_MLE",
        "vcov": "observed_information"
    },
    "diagnostics": {}
}

with open('./result.json', 'w') as f:
    json.dump(output, f, indent=2)
