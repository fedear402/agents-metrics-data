import pandas as pd
import numpy as np
from scipy import stats
from scipy.optimize import minimize
import json

df = pd.read_csv('./input.csv')
y = df['y'].values
x = df['x'].values
z = df['z'].values
n = len(y)

X = np.column_stack([np.ones(n), x, z])

def neg_log_likelihood(params):
    beta = params[:3]
    log_sigma = params[3]
    sigma = np.exp(log_sigma)
    
    mu = X @ beta
    censored = (y == 0)
    uncensored = ~censored
    
    ll = np.zeros(n)
    if uncensored.any():
        ll[uncensored] = stats.norm.logpdf(y[uncensored], loc=mu[uncensored], scale=sigma)
    if censored.any():
        ll[censored] = stats.norm.logcdf(0, loc=mu[censored], scale=sigma)
    
    return -np.sum(ll)

# Initial values via OLS
from numpy.linalg import lstsq
beta0, _, _, _ = lstsq(X, y, rcond=None)
sigma0 = np.std(y - X @ beta0)
params0 = np.append(beta0, np.log(max(sigma0, 1e-6)))

result = minimize(neg_log_likelihood, params0, method='BFGS',
                  options={'maxiter': 10000, 'gtol': 1e-8})

params_hat = result.x
hess_inv = result.hess_inv
se_all = np.sqrt(np.diag(hess_inv))

beta_hat = params_hat[:3]
log_sigma_hat = params_hat[3]
sigma_hat = np.exp(log_sigma_hat)

se_const = se_all[0]
se_x = se_all[1]
se_z = se_all[2]

estimates = [
    {"term": "const", "estimate": float(beta_hat[0]), "se": float(se_const), "n_obs": n},
    {"term": "x", "estimate": float(beta_hat[1]), "se": float(se_x), "n_obs": n},
    {"term": "z", "estimate": float(beta_hat[2]), "se": float(se_z), "n_obs": n},
    {"term": "sigma", "estimate": float(sigma_hat), "se": None, "n_obs": n},
]

output = {
    "task_id": "broad_tobit",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "Tobit MLE (homoskedastic Gaussian, left-censored at 0)",
        "vcov": "observed-information (BFGS inverse Hessian)"
    },
    "diagnostics": {}
}

with open('./result.json', 'w') as f:
    json.dump(output, f, indent=2)

print("Done. result.json written.")
