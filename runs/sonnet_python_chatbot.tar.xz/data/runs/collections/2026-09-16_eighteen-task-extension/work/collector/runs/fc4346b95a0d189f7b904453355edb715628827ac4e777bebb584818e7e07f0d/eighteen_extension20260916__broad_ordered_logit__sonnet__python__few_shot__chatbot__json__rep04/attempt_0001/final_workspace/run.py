import json
import numpy as np
import pandas as pd
from scipy.special import expit
from statsmodels.miscmodels.ordinal_model import OrderedModel

df = pd.read_csv('input.csv')
n = len(df)

y = df['y'].values
X = df[['x', 'z']].values

model = OrderedModel(y, X, distr='logit')
fit = model.fit(method='bfgs', disp=False, gtol=1e-8)

x_slope = fit.params[0]
z_slope = fit.params[1]
x_se = fit.bse[0]
z_se = fit.bse[1]

prob_high = model.predict(fit.params, exog=np.array([[1.0, 0.0]]))[0, 2]

estimates = [
    {'term': 'x', 'estimate': float(x_slope), 'se': float(x_se), 'n_obs': n},
    {'term': 'z', 'estimate': float(z_slope), 'se': float(z_se), 'n_obs': n},
    {'term': 'prob_high', 'estimate': float(prob_high), 'se': None, 'n_obs': n},
]

result = {
    'task_id': 'broad_ordered_logit',
    'platform': 'python',
    'estimates': estimates,
    'method_metadata': {'estimator': 'OrderedModel_logit_BFGS', 'vcov': 'observed_information'},
    'diagnostics': {}
}

with open('result.json', 'w') as f:
    json.dump(result, f, indent=2, allow_nan=False)
