import pandas as pd
import numpy as np
import json
from statsmodels.miscmodels.ordinal_model import OrderedModel

df = pd.read_csv('input.csv')
df['y'] = df['y'].astype(int)

model = OrderedModel(df['y'], df[['x', 'z']], distr='logit')
result = model.fit(method='bfgs', disp=False)

params = result.params
bse = result.bse

x_est = params['x']
x_se = bse['x']
z_est = params['z']
z_se = bse['z']

n_obs = len(df)

# Compute prob_high (P(y=3)) for x=1, z=0
# OrderedModel with logistic: P(y=k) using thresholds
# params includes covariate coefficients and cutpoints (as log-increments)
# Get the thresholds
thresholds = result.model.transform_threshold_params(params)
# thresholds are the actual cut points c1, c2
# P(y <= k) = logistic(c_k - X*beta)
# P(y=3) = 1 - P(y<=2) = 1 - logistic(c2 - x*beta_x - z*beta_z)

beta_x = params['x']
beta_z = params['z']

xb = beta_x * 1 + beta_z * 0

from scipy.special import expit
# thresholds from transform_threshold_params
# For ordered logit in statsmodels, thresholds are [c1, c2]
c1, c2 = thresholds[0], thresholds[1]

prob_high = 1 - expit(c2 - xb)

output = {
    "task_id": "broad_ordered_logit",
    "platform": "python",
    "estimates": [
        {"term": "x", "estimate": float(x_est), "se": float(x_se), "n_obs": n_obs},
        {"term": "z", "estimate": float(z_est), "se": float(z_se), "n_obs": n_obs},
        {"term": "prob_high", "estimate": float(prob_high), "se": None, "n_obs": n_obs}
    ],
    "method_metadata": {
        "estimator": "OrderedLogit_MLE",
        "vcov": "observed_information"
    },
    "diagnostics": {}
}

with open('result.json', 'w') as f:
    json.dump(output, f, indent=2)
