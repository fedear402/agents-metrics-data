import pandas as pd
import numpy as np
import json
from statsmodels.discrete.discrete_model import MNLogit

df = pd.read_csv('./input.csv')
n_obs = len(df)

y = df['y']
X = pd.DataFrame({'const': 1.0, 'x': df['x'], 'z': df['z']})

model = MNLogit(y, X)
result = model.fit(method='newton', maxiter=200, disp=False)

# params shape: (k_vars, k_outcomes-1), columns are outcomes 1, 2
params = result.params
bse = result.bse

x_cat1 = float(params.loc['x', 1])
z_cat1 = float(params.loc['z', 1])
x_cat2 = float(params.loc['x', 2])
z_cat2 = float(params.loc['z', 2])

se_x_cat1 = float(bse.loc['x', 1])
se_z_cat1 = float(bse.loc['z', 1])
se_x_cat2 = float(bse.loc['x', 2])
se_z_cat2 = float(bse.loc['z', 2])

# fitted probability of outcome 2 at x=0, z=0
x0 = pd.DataFrame({'const': [1.0], 'x': [0.0], 'z': [0.0]})
pred = result.predict(x0)
prob_cat2_zero = float(pred[0][2])

estimates = [
    {"term": "x_cat1", "estimate": x_cat1, "se": se_x_cat1, "n_obs": n_obs},
    {"term": "z_cat1", "estimate": z_cat1, "se": se_z_cat1, "n_obs": n_obs},
    {"term": "x_cat2", "estimate": x_cat2, "se": se_x_cat2, "n_obs": n_obs},
    {"term": "z_cat2", "estimate": z_cat2, "se": se_z_cat2, "n_obs": n_obs},
    {"term": "prob_cat2_zero", "estimate": prob_cat2_zero, "se": None, "n_obs": n_obs},
]

output = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "MNLogit",
        "vcov": "observed_information"
    },
    "diagnostics": {}
}

with open('./result.json', 'w') as f:
    json.dump(output, f, indent=2)
