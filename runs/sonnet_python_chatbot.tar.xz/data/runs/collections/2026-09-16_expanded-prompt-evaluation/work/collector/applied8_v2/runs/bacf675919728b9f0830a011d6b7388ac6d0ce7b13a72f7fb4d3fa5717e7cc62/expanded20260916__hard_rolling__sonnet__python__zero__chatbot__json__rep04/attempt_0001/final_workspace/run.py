import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

df = pd.read_csv("input.csv")
df = df.sort_values("time").reset_index(drop=True)
y = df["y"].values

forecasts = {}
for f in range(101, 251):
    window = y[f-100:f-1]  # indices f-100 to f-2 (0-based), values y_(f-99) to y_(f-1)
    # Actually: y_(f-100),...,y_(f-1) are 100 values
    # Regression pairs: s = f-99,...,f-1 (99 pairs)
    # y_s = a + b*y_(s-1)
    # s goes from f-99 to f-1 => y_s indices (0-based): f-99-1=f-100 to f-1-1=f-2
    # y_(s-1) indices: f-100-1=f-101 to f-2-1=f-3... wait let me reconsider
    
    # time is 1-indexed, array is 0-indexed: y[i] = y_(i+1)
    # f is forecast time (1-indexed)
    # We use y_(f-100),...,y_(f-1) as the window (100 values)
    # Array indices: f-100-1=f-101 to f-1-1=f-2 (0-based)
    # Regression: y_s = a + b*y_(s-1) for s=f-99,...,f-1 (99 pairs)
    # y_s array index: s-1 = f-99-1=f-100 to f-1-1=f-2
    # y_(s-1) array index: s-2 = f-99-2=f-101 to f-1-2=f-3
    
    Y = y[f-100:f-1]   # y_s values, indices f-100 to f-2 (0-based), 99 values
    X = y[f-101:f-2]   # y_(s-1) values, indices f-101 to f-3 (0-based), 99 values
    
    X_const = sm.add_constant(X)
    model = sm.OLS(Y, X_const).fit()
    a_hat, b_hat = model.params
    
    y_prev = y[f-2]  # y_(f-1), 0-based index f-1-1=f-2
    forecast = a_hat + b_hat * y_prev
    forecasts[f] = forecast

actuals = {f: y[f-1] for f in range(101, 251)}  # y_f, 0-based index f-1
rmse = np.sqrt(sum((actuals[f] - forecasts[f])**2 for f in range(101, 251)) / 150)

result = {
    "task_id": "hard_rolling",
    "platform": "python",
    "estimates": [
        {"term": "rmse", "estimate": float(rmse), "se": None, "n_obs": 150},
        {"term": "forecast_101", "estimate": float(forecasts[101]), "se": None, "n_obs": 99},
        {"term": "forecast_150", "estimate": float(forecasts[150]), "se": None, "n_obs": 99},
        {"term": "forecast_200", "estimate": float(forecasts[200]), "se": None, "n_obs": 99},
        {"term": "forecast_250", "estimate": float(forecasts[250]), "se": None, "n_obs": 99},
    ],
    "method_metadata": {"estimator": "OLS AR(1) rolling", "vcov": "none"},
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
