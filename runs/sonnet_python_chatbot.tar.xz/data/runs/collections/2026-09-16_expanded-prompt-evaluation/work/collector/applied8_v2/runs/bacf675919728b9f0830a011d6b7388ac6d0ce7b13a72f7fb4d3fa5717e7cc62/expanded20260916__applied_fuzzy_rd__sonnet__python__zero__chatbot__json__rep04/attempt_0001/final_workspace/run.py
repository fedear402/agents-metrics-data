import pandas as pd
import numpy as np
import json
from statsmodels.regression.linear_model import WLS, OLS

df = pd.read_csv('input.csv')
df.columns = df.columns.str.strip()

bw = 1.0
mask = np.abs(df['score']) < bw
data = df[mask].copy()

n_obs = len(data)
score = data['score'].values
weights = 1 - np.abs(score)
above = (score >= 0).astype(float)

X = np.column_stack([
    np.ones(n_obs),
    above,
    score,
    score * above
])

def wls_hc0(y, X, w):
    W = np.diag(w)
    XtW = X.T @ W
    XtWX = XtW @ X
    XtWX_inv = np.linalg.inv(XtWX)
    beta = XtWX_inv @ XtW @ y
    yhat = X @ beta
    resid = y - yhat
    # HC0: sandwich with weighted residuals
    # Score: w_i * x_i * e_i
    scores = (w * resid)[:, None] * X
    meat = scores.T @ scores
    cov = XtWX_inv @ meat @ XtWX_inv
    return beta, cov

y_earn = data['earnings'].values
y_part = data['participated'].values

beta_earn, cov_earn = wls_hc0(y_earn, X, weights)
beta_part, cov_part = wls_hc0(y_part, X, weights)

# Discontinuity is coefficient on 'above' (index 1)
rf_est = beta_earn[1]
fs_est = beta_part[1]
rf_se = np.sqrt(cov_earn[1, 1])
fs_se = np.sqrt(cov_part[1, 1])

# For delta method of treatment_effect = rf / fs, need joint cov
# Stack both systems: need cross-covariance between rf and fs estimates
# Both use same X and weights, so use joint sandwich
W = weights
XtW = X.T * W
XtWX = XtW @ X
XtWX_inv = np.linalg.inv(XtWX)

resid_earn = y_earn - X @ beta_earn
resid_part = y_part - X @ beta_part

# Cross-covariance: E[score_earn * score_part^T]
scores_earn = (W * resid_earn)[:, None] * X
scores_part = (W * resid_part)[:, None] * X
cross_meat = scores_earn.T @ scores_part
cov_cross = XtWX_inv @ cross_meat @ XtWX_inv

# cov(rf, fs) = cov_cross[1,1]
cov_rf_fs = cov_cross[1, 1]

# Delta method: te = rf/fs
# var(te) = (1/fs)^2 * var(rf) + (rf/fs^2)^2 * var(fs) - 2*(rf/fs^3)*cov(rf,fs)
te_est = rf_est / fs_est
var_te = (1/fs_est)**2 * cov_earn[1,1] + (rf_est/fs_est**2)**2 * cov_part[1,1] - 2*(rf_est/fs_est**3)*cov_rf_fs
te_se = np.sqrt(var_te)

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": float(te_est), "se": float(te_se), "n_obs": n_obs},
        {"term": "reduced_form", "estimate": float(rf_est), "se": float(rf_se), "n_obs": n_obs},
        {"term": "first_stage", "estimate": float(fs_est), "se": float(fs_se), "n_obs": n_obs}
    ],
    "method_metadata": {
        "estimator": "fuzzy_rd_local_linear_triangular",
        "vcov": "HC0"
    },
    "diagnostics": {}
}

with open('result.json', 'w') as f:
    json.dump(result, f, indent=2)
