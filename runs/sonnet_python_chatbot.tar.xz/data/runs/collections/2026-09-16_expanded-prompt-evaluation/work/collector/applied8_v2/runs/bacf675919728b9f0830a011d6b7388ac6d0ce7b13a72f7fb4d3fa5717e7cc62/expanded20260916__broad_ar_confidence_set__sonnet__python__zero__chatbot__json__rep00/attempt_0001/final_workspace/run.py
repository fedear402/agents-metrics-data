import pandas as pd
import numpy as np
from scipy import stats
import json

df = pd.read_csv('./input.csv')
n = len(df)
y = df['y'].values
endog = df['endog'].values
x = df['x'].values
z1 = df['z1'].values
z2 = df['z2'].values

# Critical value: F(2, n-4) at 95%
dof1 = 2
dof2 = n - 4
f_crit = stats.f.ppf(0.95, dof1, dof2)

def ar_f_stat(beta):
    y_adj = y - beta * endog
    X = np.column_stack([np.ones(n), x, z1, z2])
    # OLS
    XtX = X.T @ X
    Xty = X.T @ y_adj
    coef = np.linalg.solve(XtX, Xty)
    resid = y_adj - X @ coef
    
    # Restricted model (z1, z2 excluded): intercept + x only
    X_r = np.column_stack([np.ones(n), x])
    XtX_r = X_r.T @ X_r
    Xty_r = X_r.T @ y_adj
    coef_r = np.linalg.solve(XtX_r, Xty_r)
    resid_r = y_adj - X_r @ coef_r
    
    RSS_r = resid_r @ resid_r
    RSS_u = resid @ resid
    
    F = ((RSS_r - RSS_u) / dof1) / (RSS_u / dof2)
    return F

# The AR confidence set is where F(beta) <= f_crit
# F(beta) is a quadratic function of beta, so we solve F(beta) = f_crit
# to find boundary points

# Express F(beta) analytically as quadratic in beta
# y_adj = y - beta*endog
# Let's derive the quadratic form

# For the unrestricted model with X = [1, x, z1, z2]:
# RSS_u(beta) = ||M_X (y - beta*endog)||^2 where M_X = I - X(X'X)^{-1}X'
# For restricted model with X_r = [1, x]:
# RSS_r(beta) = ||M_Xr (y - beta*endog)||^2

X_full = np.column_stack([np.ones(n), x, z1, z2])
X_rest = np.column_stack([np.ones(n), x])

# Projection matrices
def hat_matrix(X):
    Q, R = np.linalg.qr(X)
    return Q @ Q.T

H_full = hat_matrix(X_full)
H_rest = hat_matrix(X_rest)

M_full = np.eye(n) - H_full
M_rest = np.eye(n) - H_rest

# y_adj = y - beta*endog
# RSS_u = (y - beta*endog)' M_full (y - beta*endog)
#       = y'M_full y - 2*beta * endog'M_full y + beta^2 * endog'M_full endog
# Similarly for RSS_r

My_full = M_full @ y
Me_full = M_full @ endog
My_rest = M_rest @ y
Me_rest = M_rest @ endog

a_u = endog @ Me_full  # coef of beta^2 in RSS_u
b_u = -2 * (endog @ My_full)  # coef of beta in RSS_u
c_u = y @ My_full  # constant in RSS_u

a_r = endog @ Me_rest
b_r = -2 * (endog @ My_rest)
c_r = y @ My_rest

# RSS_u(beta) = a_u*beta^2 + b_u*beta + c_u
# RSS_r(beta) = a_r*beta^2 + b_r*beta + c_r

# F(beta) = ((RSS_r - RSS_u)/dof1) / (RSS_u/dof2)
#         = (dof2/dof1) * (RSS_r - RSS_u) / RSS_u

# F(beta) = f_crit means:
# (dof2/dof1) * (RSS_r - RSS_u) / RSS_u = f_crit
# dof2*(RSS_r - RSS_u) = f_crit * dof1 * RSS_u
# dof2*RSS_r - dof2*RSS_u = f_crit*dof1*RSS_u
# dof2*RSS_r = (dof2 + f_crit*dof1)*RSS_u

# Let k = f_crit * dof1 / dof2 = f_crit * 2 / (n-4)
# Then: RSS_r - RSS_u = k * RSS_u => RSS_r = (1+k)*RSS_u
# Or: RSS_r - (1+k)*RSS_u = 0

# Quadratic in beta:
# (a_r - (1+k)*a_u)*beta^2 + (b_r - (1+k)*b_u)*beta + (c_r - (1+k)*c_u) = 0

k = f_crit * dof1 / dof2

A = a_r - (1 + k) * a_u
B = b_r - (1 + k) * b_u
C = c_r - (1 + k) * c_u

discriminant = B**2 - 4*A*C

print(f"A={A}, B={B}, C={C}, discriminant={discriminant}")
print(f"f_crit={f_crit}, k={k}")

# Verify with numerical function
ar_at_1 = ar_f_stat(1.0)
print(f"AR F at beta=1: {ar_at_1}")

if discriminant < 0:
    if A > 0:
        # Parabola opens up, always above f_crit => empty set
        boundary_low = np.nan
        boundary_high = np.nan
        accepts_zero = 0
        unbounded = 0
    else:
        # A < 0, parabola opens down, always below f_crit => entire real line
        boundary_low = np.nan
        boundary_high = np.nan
        accepts_zero = 1
        unbounded = 1
else:
    beta1 = (-B - np.sqrt(discriminant)) / (2 * A)
    beta2 = (-B + np.sqrt(discriminant)) / (2 * A)
    boundary_low = min(beta1, beta2)
    boundary_high = max(beta1, beta2)
    
    if A > 0:
        # Parabola opens up: F <= f_crit between roots (connected interval)
        unbounded = 0
        f_zero = ar_f_stat(0.0)
        accepts_zero = 1 if f_zero <= f_crit else 0
    else:
        # A < 0: parabola opens down: F <= f_crit outside the roots (two tails => unbounded)
        unbounded = 1
        f_zero = ar_f_stat(0.0)
        accepts_zero = 1 if f_zero <= f_crit else 0

print(f"boundary_low={boundary_low}, boundary_high={boundary_high}")
print(f"accepts_zero={accepts_zero}, unbounded={unbounded}")

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": [
        {"term": "boundary_low", "estimate": float(boundary_low), "se": None, "n_obs": n},
        {"term": "boundary_high", "estimate": float(boundary_high), "se": None, "n_obs": n},
        {"term": "accepts_zero", "estimate": float(accepts_zero), "se": None, "n_obs": n},
        {"term": "unbounded", "estimate": float(unbounded), "se": None, "n_obs": n},
        {"term": "ar_f_at_one", "estimate": float(ar_at_1), "se": None, "n_obs": n}
    ],
    "method_metadata": {
        "estimator": "Anderson-Rubin test inversion",
        "vcov": "homoskedastic"
    },
    "diagnostics": {}
}

with open('result.json', 'w') as f:
    json.dump(result, f, indent=2)

print("Done. result.json written.")
