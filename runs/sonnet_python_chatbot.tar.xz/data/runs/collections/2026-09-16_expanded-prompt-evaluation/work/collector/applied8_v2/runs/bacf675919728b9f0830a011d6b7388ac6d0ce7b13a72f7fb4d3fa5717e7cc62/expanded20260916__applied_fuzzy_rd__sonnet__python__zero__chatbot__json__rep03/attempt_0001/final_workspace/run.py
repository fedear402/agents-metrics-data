import pandas as pd
import numpy as np
import json
from statsmodels.regression.linear_model import OLS, WLS

df = pd.read_csv('input.csv')
df.columns = df.columns.str.strip()

bw = 1.0
mask = np.abs(df['score']) < bw
df = df[mask].copy()
n_obs = len(df)

df['weight'] = 1 - np.abs(df['score'])
df['D'] = (df['score'] >= 0).astype(float)
df['score_left'] = df['score'] * (1 - df['D'])
df['score_right'] = df['score'] * df['D']

X = np.column_stack([
    np.ones(n_obs),
    df['D'].values,
    df['score_left'].values,
    df['score_right'].values
])

W = np.diag(df['weight'].values)
w = df['weight'].values

def wls_hc0(X, y, w):
    Xw = X * w[:, None]
    XtWX = Xw.T @ X
    XtWX_inv = np.linalg.inv(XtWX)
    beta = XtWX_inv @ (Xw.T @ y)
    resid = y - X @ beta
    # HC0: sandwich with w^2 * e^2
    meat = (Xw * resid[:, None]).T @ (Xw * resid[:, None])
    vcov = XtWX_inv @ meat @ XtWX_inv
    return beta, vcov

y_earn = df['earnings'].values
y_part = df['participated'].values

beta_earn, vcov_earn = wls_hc0(X, y_earn, w)
beta_part, vcov_part = wls_hc0(X, y_part, w)

# Discontinuity is coefficient on D (index 1)
rf_est = beta_earn[1]
fs_est = beta_part[1]
rf_se = np.sqrt(vcov_earn[1, 1])
fs_se = np.sqrt(vcov_part[1, 1])

# Joint covariance for delta method
# Need cov(rf, fs) from joint estimation
# Use cross-product of influence functions
Xw = X * w[:, None]
XtWX_earn_inv = np.linalg.inv(Xw.T @ X)
XtWX_part_inv = np.linalg.inv(Xw.T @ X)  # same X

resid_earn = y_earn - X @ beta_earn
resid_part = y_part - X @ beta_part

# Influence functions for the D coefficient (index 1)
inf_earn = (Xw * resid_earn[:, None]) @ XtWX_earn_inv[:, 1]
inf_part = (Xw * resid_part[:, None]) @ XtWX_part_inv[:, 1]

cov_rf_fs = np.sum(inf_earn * inf_part)

# Delta method for ratio te = rf / fs
# Var(te) = (1/fs)^2 * Var(rf) + (rf/fs^2)^2 * Var(fs) - 2*(rf/fs^3)*Cov(rf,fs)
te_est = rf_est / fs_est
var_te = (vcov_earn[1, 1] / fs_est**2
          + (rf_est**2 * vcov_part[1, 1]) / fs_est**4
          - 2 * rf_est * cov_rf_fs / fs_est**3)
te_se = np.sqrt(var_te)

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": float(te_est), "se": float(te_se), "n_obs": int(n_obs)},
        {"term": "reduced_form", "estimate": float(rf_est), "se": float(rf_se), "n_obs": int(n_obs)},
        {"term": "first_stage", "estimate": float(fs_est), "se": float(fs_se), "n_obs": int(n_obs)}
    ],
    "method_metadata": {
        "estimator": "fuzzy_rd_local_linear_triangular_kernel",
        "vcov": "HC0"
    },
    "diagnostics": {}
}

with open('result.json', 'w') as f:
    json.dump(result, f, indent=2)
