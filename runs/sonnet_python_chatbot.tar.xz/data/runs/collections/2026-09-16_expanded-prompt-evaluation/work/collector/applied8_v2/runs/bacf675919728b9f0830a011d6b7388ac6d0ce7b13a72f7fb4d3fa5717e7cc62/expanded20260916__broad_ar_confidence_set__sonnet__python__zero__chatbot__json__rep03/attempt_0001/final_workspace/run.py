import pandas as pd
import numpy as np
from scipy import stats
import json

df = pd.read_csv('./input.csv')
n = len(df)
y = df['y'].values
endog = df['endog'].values
x = df['x'].values
z1 = df['z1'].values
z2 = df['z2'].values

# Critical value: F(2, n-4) at 95th percentile
df1, df2 = 2, n - 4
f_crit = stats.f.ppf(0.95, df1, df2)

def ar_f_stat(beta):
    # Construct dependent variable
    y_star = y - beta * endog
    # Regress y_star on intercept, x, z1, z2
    X_full = np.column_stack([np.ones(n), x, z1, z2])
    X_restricted = np.column_stack([np.ones(n), x])
    
    # Full model
    b_full, _, _, _ = np.linalg.lstsq(X_full, y_star, rcond=None)
    resid_full = y_star - X_full @ b_full
    rss_full = np.dot(resid_full, resid_full)
    
    # Restricted model (no z1, z2)
    b_restr, _, _, _ = np.linalg.lstsq(X_restricted, y_star, rcond=None)
    resid_restr = y_star - X_restricted @ b_restr
    rss_restr = np.dot(resid_restr, resid_restr)
    
    # F statistic
    f_stat = ((rss_restr - rss_full) / df1) / (rss_full / df2)
    return f_stat

# The AR F statistic as a function of beta is a quadratic in beta.
# F(beta) = [(RSS_r(beta) - RSS_f(beta))/2] / [RSS_f(beta)/(n-4)]
# 
# Let's derive analytically. y_star = y - beta*endog
# RSS_f(beta) = ||M_full * y_star||^2 where M_full is the annihilator of X_full
# RSS_r(beta) = ||M_restr * y_star||^2
# 
# y_star = y - beta*endog, so:
# M*y_star = M*y - beta*M*endog
# 
# RSS_f = (M_f*y - beta*M_f*endog)'(M_f*y - beta*M_f*endog)
#       = a - 2b*beta + c*beta^2
# where a = (M_f*y)'(M_f*y), b = (M_f*y)'(M_f*endog), c = (M_f*endog)'(M_f*endog)
#
# Similarly for RSS_r

X_full = np.column_stack([np.ones(n), x, z1, z2])
X_restr = np.column_stack([np.ones(n), x])

# Projection matrices (compute residuals directly)
def residuals(X, v):
    b, _, _, _ = np.linalg.lstsq(X, v, rcond=None)
    return v - X @ b

Mf_y = residuals(X_full, y)
Mf_e = residuals(X_full, endog)
Mr_y = residuals(X_restr, y)
Mr_e = residuals(X_restr, endog)

# RSS_f(beta) = ||Mf_y - beta*Mf_e||^2
af = np.dot(Mf_y, Mf_y)
bf = np.dot(Mf_y, Mf_e)
cf = np.dot(Mf_e, Mf_e)

# RSS_r(beta) = ||Mr_y - beta*Mr_e||^2
ar = np.dot(Mr_y, Mr_y)
br = np.dot(Mr_y, Mr_e)
cr = np.dot(Mr_e, Mr_e)

# RSS_r - RSS_f = (ar - af) - 2*(br - bf)*beta + (cr - cf)*beta^2
# F(beta) = [(ar-af) - 2*(br-bf)*beta + (cr-cf)*beta^2] / 2 / [RSS_f(beta)/(n-4)]
# F(beta) <= f_crit iff:
# [(ar-af) - 2*(br-bf)*beta + (cr-cf)*beta^2] * (n-4) <= 2 * f_crit * (af - 2*bf*beta + cf*beta^2)
# Rearranging:
# [(n-4)*(cr-cf) - 2*f_crit*cf]*beta^2 
# - 2*[(n-4)*(br-bf) - 2*f_crit*(-bf)*(-1)... wait let me be careful

# F <= f_crit
# Numerator = (ar-af) - 2*(br-bf)*beta + (cr-cf)*beta^2
# Denominator = af - 2*bf*beta + cf*beta^2  (= RSS_f/(n-4) * (n-4), this is RSS_f)
# Wait: F = [num/2] / [RSS_f/(n-4)] = num*(n-4) / (2*RSS_f)
# F <= f_crit
# num*(n-4) <= 2*f_crit*RSS_f
# [(ar-af) - 2*(br-bf)*beta + (cr-cf)*beta^2]*(n-4) <= 2*f_crit*(af - 2*bf*beta + cf*beta^2)
# 
# A*beta^2 + B*beta + C <= 0
# where:
# A = (cr-cf)*(n-4) - 2*f_crit*cf
# B = -2*(br-bf)*(n-4) + 2*f_crit*2*bf = -2*(br-bf)*(n-4) + 4*f_crit*bf
# C = (ar-af)*(n-4) - 2*f_crit*af

A = (cr - cf) * df2 - 2 * f_crit * cf
B = -2 * (br - bf) * df2 + 4 * f_crit * bf
C = (ar - af) * df2 - 2 * f_crit * af

discriminant = B**2 - 4*A*C

# Find roots
if discriminant < 0:
    # No real roots - either always accepted or never accepted
    boundary_low = None
    boundary_high = None
    if A > 0:
        # Parabola opens up, no intersection - never <= 0, set is empty
        unbounded = 0
        accepts_zero = 0
    else:
        # Parabola opens down or is always <= 0
        unbounded = 1
        # check at 0
        accepts_zero = 1 if C <= 0 else 0
else:
    sqrt_disc = np.sqrt(discriminant)
    root1 = (-B - sqrt_disc) / (2 * A)
    root2 = (-B + sqrt_disc) / (2 * A)
    r_low = min(root1, root2)
    r_high = max(root1, root2)
    
    boundary_low = r_low
    boundary_high = r_high
    
    if A > 0:
        # Parabola opens up: inequality holds BETWEEN roots [r_low, r_high]
        unbounded = 0
        # zero in set if r_low <= 0 <= r_high
        accepts_zero = 1 if r_low <= 0 <= r_high else 0
    else:
        # A < 0: Parabola opens down: inequality holds OUTSIDE roots
        # Set is (-inf, r_low] union [r_high, +inf) - unbounded
        unbounded = 1
        # zero in set if 0 <= r_low or 0 >= r_high
        accepts_zero = 1 if (0 <= r_low or 0 >= r_high) else 0

# F stat at beta=1
f_at_one = ar_f_stat(1.0)

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": [
        {"term": "boundary_low", "estimate": float(boundary_low), "se": None, "n_obs": n},
        {"term": "boundary_high", "estimate": float(boundary_high), "se": None, "n_obs": n},
        {"term": "accepts_zero", "estimate": float(accepts_zero), "se": None, "n_obs": n},
        {"term": "unbounded", "estimate": float(unbounded), "se": None, "n_obs": n},
        {"term": "ar_f_at_one", "estimate": float(f_at_one), "se": None, "n_obs": n}
    ],
    "method_metadata": {
        "estimator": "Anderson-Rubin confidence set via F-test inversion",
        "vcov": "homoskedastic"
    },
    "diagnostics": {}
}

with open('./result.json', 'w') as f:
    json.dump(result, f, indent=2)

print("Done. boundary_low =", boundary_low, "boundary_high =", boundary_high)
print("accepts_zero =", accepts_zero, "unbounded =", unbounded)
print("ar_f_at_one =", f_at_one)
