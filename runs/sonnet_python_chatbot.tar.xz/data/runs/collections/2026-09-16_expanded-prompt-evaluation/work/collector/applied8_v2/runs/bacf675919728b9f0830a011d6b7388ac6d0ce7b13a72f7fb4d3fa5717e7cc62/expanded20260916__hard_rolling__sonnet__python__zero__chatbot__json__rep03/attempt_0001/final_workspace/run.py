import pandas as pd
import numpy as np
import json
import statsmodels.api as sm

df = pd.read_csv('input.csv')
df = df.sort_values('time').reset_index(drop=True)
y = df['y'].values

forecasts = {}
for f in range(101, 251):
    window = y[f-100:f-1]  # indices f-100 to f-2 (0-based), values y_(f-99) to y_(f-1)
    # Actually need y_(f-100),...,y_(f-1) as the window of 100 observed levels
    # Regression pairs: s = f-99,...,f-1 (99 pairs)
    # y_s = a + b*y_(s-1)
    # s ranges from f-99 to f-1
    # y_(s-1) ranges from y_(f-100) to y_(f-2)
    # y_s ranges from y_(f-99) to y_(f-1)
    
    # 0-based indices: time t corresponds to index t-1
    # y_(f-100) is at index f-101, y_(f-1) is at index f-2
    # y_s for s=f-99 is at index f-100, y_(f-1) is at index f-2
    
    X_vals = y[f-101:f-1]   # y_(f-100) to y_(f-2), length 99
    Y_vals = y[f-100:f-1]   # y_(f-99)  to y_(f-1), length 99
    
    X = sm.add_constant(X_vals)
    model = sm.OLS(Y_vals, X).fit()
    a_hat, b_hat = model.params
    
    y_prev = y[f-2]  # y_(f-1) at 0-based index f-2... wait
    # y_(f-1): time f-1, 0-based index f-2
    # But for forecast of y_f: a_hat + b_hat * y_(f-1)
    y_last = y[f-2]  # y_(f-1)
    forecasts[f] = a_hat + b_hat * y_last

actuals = {f: y[f-1] for f in range(101, 251)}  # y_f at 0-based index f-1

rmse = np.sqrt(sum((actuals[f] - forecasts[f])**2 for f in range(101, 251)) / 150)

result = {
    "task_id": "hard_rolling",
    "platform": "python",
    "estimates": [
        {"term": "rmse", "estimate": float(rmse), "se": None, "n_obs": 150},
        {"term": "forecast_101", "estimate": float(forecasts[101]), "se": None, "n_obs": 99},
        {"term": "forecast_150", "estimate": float(forecasts[150]), "se": None, "n_obs": 99},
        {"term": "forecast_200", "estimate": float(forecasts[200]), "se": None, "n_obs": 99},
        {"term": "forecast_250", "estimate": float(forecasts[250]), "se": None, "n_obs": 99},
    ],
    "method_metadata": {"estimator": "OLS AR(1) rolling", "vcov": "null"},
    "diagnostics": {}
}

with open('result.json', 'w') as fh:
    json.dump(result, fh, indent=2)
