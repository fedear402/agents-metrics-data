import pandas as pd
import numpy as np
from scipy import stats
import json

df = pd.read_csv('input.csv')
n = len(df)
y = df['y'].values
endog = df['endog'].values
x = df['x'].values
z1 = df['z1'].values
z2 = df['z2'].values

# Critical value for F(2, n-4) at 95%
df1 = 2
df2 = n - 4
f_crit = stats.f.ppf(0.95, df1, df2)

def ar_f_stat(beta):
    y_adj = y - beta * endog
    X = np.column_stack([np.ones(n), x, z1, z2])
    # OLS
    XtX = X.T @ X
    Xty = X.T @ y_adj
    coef = np.linalg.solve(XtX, Xty)
    resid = y_adj - X @ coef
    s2 = resid @ resid / (n - 4)
    
    # F test for z1 and z2 coefficients (indices 2 and 3)
    # Restricted model: only intercept and x
    X_r = np.column_stack([np.ones(n), x])
    XtX_r = X_r.T @ X_r
    Xty_r = X_r.T @ y_adj
    coef_r = np.linalg.solve(XtX_r, Xty_r)
    resid_r = y_adj - X_r @ coef_r
    
    RSS_r = resid_r @ resid_r
    RSS_u = resid @ resid
    
    F = ((RSS_r - RSS_u) / df1) / (RSS_u / df2)
    return F

# The AR confidence set: F(beta) <= f_crit
# F(beta) is a quadratic function in beta, find roots of F(beta) = f_crit

# Let's express F analytically as quadratic in beta
# y_adj = y - beta*endog
# We need to find where F = f_crit

# Use numerical approach: scan and then refine
# F(beta) is a rational function (actually quadratic ratio) in beta
# Let's find the roots analytically

# F(beta) = [(RSS_r(beta) - RSS_u(beta))/2] / [RSS_u(beta)/(n-4)]
# Both RSS_r and RSS_u are quadratic in beta
# So F(beta) = f_crit is a quadratic equation

# Let's compute coefficients
# y_adj = y - beta*endog = A + beta*B where A=y, B=-endog

# For unrestricted: X = [1, x, z1, z2]
X_u = np.column_stack([np.ones(n), x, z1, z2])
X_r = np.column_stack([np.ones(n), x])

# Hat matrices
H_u = X_u @ np.linalg.solve(X_u.T @ X_u, X_u.T)
H_r = X_r @ np.linalg.solve(X_r.T @ X_r, X_r.T)
M_u = np.eye(n) - H_u
M_r = np.eye(n) - H_r

A = y
B = -endog

# RSS_u(beta) = (A + beta*B)' M_u (A + beta*B)
#             = A'M_u A + 2*beta * A'M_u B + beta^2 * B'M_u B
au = A @ M_u @ A
bu = 2 * A @ M_u @ B
cu = B @ M_u @ B

# RSS_r(beta) similarly
ar_ = A @ M_r @ A
br_ = 2 * A @ M_r @ B
cr_ = B @ M_r @ B

# F(beta) = [(RSS_r - RSS_u)/2] / [RSS_u/(n-4)]
# = (n-4)/2 * (RSS_r - RSS_u) / RSS_u

# F(beta) = f_crit
# (n-4)/2 * (RSS_r - RSS_u) = f_crit * RSS_u
# (n-4)/2 * RSS_r - (n-4)/2 * RSS_u = f_crit * RSS_u
# (n-4)/2 * RSS_r = [f_crit + (n-4)/2] * RSS_u

# Let k = (n-4)/2
k = df2 / 2.0

# k * (ar_ + br_*beta + cr_*beta^2) = (f_crit + k) * (au + bu*beta + cu*beta^2)
# Rearranging:
# [k*cr_ - (f_crit+k)*cu] * beta^2 + [k*br_ - (f_crit+k)*bu] * beta + [k*ar_ - (f_crit+k)*au] = 0

a_coef = k * cr_ - (f_crit + k) * cu
b_coef = k * br_ - (f_crit + k) * bu
c_coef = k * ar_ - (f_crit + k) * au

discriminant = b_coef**2 - 4 * a_coef * c_coef

ar_f_one = ar_f_stat(1.0)

if discriminant < 0:
    # No real roots - either always inside or always outside
    f_at_zero = ar_f_stat(0.0)
    if f_at_zero <= f_crit:
        # Always inside - unbounded
        boundary_low = np.nan
        boundary_high = np.nan
        accepts_zero = 1
        unbounded = 1
    else:
        # Always outside - empty set
        boundary_low = np.nan
        boundary_high = np.nan
        accepts_zero = 0
        unbounded = 0
else:
    root1 = (-b_coef - np.sqrt(discriminant)) / (2 * a_coef)
    root2 = (-b_coef + np.sqrt(discriminant)) / (2 * a_coef)
    
    boundary_low = min(root1, root2)
    boundary_high = max(root1, root2)
    
    # Check if set is bounded interval [low, high] or unbounded (complement)
    # Test a point inside
    mid = (boundary_low + boundary_high) / 2
    f_mid = ar_f_stat(mid)
    
    if f_mid <= f_crit:
        # Bounded interval
        unbounded = 0
        accepts_zero = 1 if (0 >= boundary_low and 0 <= boundary_high) else 0
    else:
        # Disjoint: (-inf, low] U [high, inf)
        unbounded = 1
        accepts_zero = 1 if (0 <= boundary_low or 0 >= boundary_high) else 0

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": [
        {"term": "boundary_low", "estimate": float(boundary_low), "se": None, "n_obs": n},
        {"term": "boundary_high", "estimate": float(boundary_high), "se": None, "n_obs": n},
        {"term": "accepts_zero", "estimate": float(accepts_zero), "se": None, "n_obs": n},
        {"term": "unbounded", "estimate": float(unbounded), "se": None, "n_obs": n},
        {"term": "ar_f_at_one", "estimate": float(ar_f_one), "se": None, "n_obs": n}
    ],
    "method_metadata": {
        "estimator": "Anderson-Rubin confidence set via F-test inversion",
        "vcov": "homoskedastic"
    },
    "diagnostics": {}
}

with open('result.json', 'w') as f:
    json.dump(result, f, indent=2)

print("Done. boundary_low:", boundary_low, "boundary_high:", boundary_high)
print("accepts_zero:", accepts_zero, "unbounded:", unbounded)
print("ar_f_at_one:", ar_f_one)
