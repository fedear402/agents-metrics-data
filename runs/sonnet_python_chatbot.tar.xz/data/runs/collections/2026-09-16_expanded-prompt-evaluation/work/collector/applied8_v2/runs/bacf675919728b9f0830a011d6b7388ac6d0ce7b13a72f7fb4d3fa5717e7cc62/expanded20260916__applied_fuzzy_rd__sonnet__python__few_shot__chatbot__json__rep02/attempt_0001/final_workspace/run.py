import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df.columns = df.columns.str.strip()

bw = 1.0
mask = df["score"].abs() < bw
df = df[mask].copy()
n_obs = len(df)

score = df["score"].values
weights = 1 - np.abs(score)
above = (score >= 0).astype(float)

X = np.column_stack([
    np.ones(n_obs),
    above,
    score,
    above * score
])

Y = np.column_stack([df["earnings"].values, df["participated"].values])

W = np.diag(weights)
XtW = X.T @ W
bread = np.linalg.inv(XtW @ X)
coefficients = bread @ XtW @ Y

residuals = Y - X @ coefficients

contrast = np.array([0., 1., 0., 0.])
jumps = contrast @ coefficients

loading = weights * (X @ bread @ contrast)
influence = loading[:, None] * residuals
joint = influence.T @ influence

earnings_jump, participation_jump = jumps
gradient = np.array([1.0 / participation_jump, -earnings_jump / participation_jump**2])
treatment_se = np.sqrt(gradient @ joint @ gradient)

rows = [
    {"term": "treatment_effect", "estimate": float(earnings_jump / participation_jump), "se": float(treatment_se), "n_obs": n_obs},
    {"term": "reduced_form", "estimate": float(earnings_jump), "se": float(np.sqrt(joint[0, 0])), "n_obs": n_obs},
    {"term": "first_stage", "estimate": float(participation_jump), "se": float(np.sqrt(joint[1, 1])), "n_obs": n_obs},
]

output = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": rows,
    "method_metadata": {
        "estimator": "fuzzy_rd_local_linear_triangular",
        "vcov": "HC0"
    },
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(output, f, indent=2, allow_nan=False)
