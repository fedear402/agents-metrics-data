import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

df = pd.read_csv('input.csv').sort_values('time').reset_index(drop=True)
y = df['y'].values

forecasts = {}
for f_idx in range(100, 250):  # f=101 to 250, 0-indexed: 100 to 249
    window = y[f_idx-100:f_idx]  # y_(f-100) to y_(f-1), 100 values
    y_dep = window[1:]    # s=f-99,...,f-1 => indices 1..99, 99 values
    y_lag = window[:-1]   # y_(s-1), 99 values
    X = sm.add_constant(y_lag)
    model = sm.OLS(y_dep, X).fit()
    a, b = model.params
    forecast = a + b * window[-1]
    f_time = f_idx + 1  # 1-indexed time
    forecasts[f_time] = forecast

actuals = {int(df['time'].iloc[i]): y[i] for i in range(len(y))}
sse = sum((actuals[f] - forecasts[f])**2 for f in range(101, 251))
rmse = np.sqrt(sse / 150)

result = {
    "task_id": "hard_rolling",
    "platform": "python",
    "estimates": [
        {"term": "rmse", "estimate": float(rmse), "se": None, "n_obs": 150},
        {"term": "forecast_101", "estimate": float(forecasts[101]), "se": None, "n_obs": 99},
        {"term": "forecast_150", "estimate": float(forecasts[150]), "se": None, "n_obs": 99},
        {"term": "forecast_200", "estimate": float(forecasts[200]), "se": None, "n_obs": 99},
        {"term": "forecast_250", "estimate": float(forecasts[250]), "se": None, "n_obs": 99},
    ],
    "method_metadata": {"estimator": "OLS AR(1) rolling", "vcov": "null"},
    "diagnostics": {}
}

with open('result.json', 'w') as f:
    json.dump(result, f, indent=2)
