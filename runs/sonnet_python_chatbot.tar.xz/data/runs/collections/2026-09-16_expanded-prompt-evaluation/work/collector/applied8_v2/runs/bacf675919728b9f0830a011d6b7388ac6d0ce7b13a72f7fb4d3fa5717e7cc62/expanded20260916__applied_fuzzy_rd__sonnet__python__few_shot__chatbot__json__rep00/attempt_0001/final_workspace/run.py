import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df.columns = df.columns.str.strip()

mask = df["score"].abs() < 1
df = df[mask].copy()
n_obs = len(df)

score = df["score"].values
weights = 1 - np.abs(score)
above = (score >= 0).astype(float)

X = np.column_stack([
    np.ones(n_obs),
    above,
    score,
    above * score
])

Y = np.column_stack([df["earnings"].values, df["participated"].values])

W = np.diag(weights)
XtW = X.T * weights
XtWX = XtW @ X
bread = np.linalg.inv(XtWX)
coefficients = bread @ XtW @ Y

residuals = Y - X @ coefficients

contrast = np.array([0., 1., 0., 0.])
jumps = contrast @ coefficients

loading = weights * (X @ bread @ contrast)
influence = loading[:, None] * residuals
joint = influence.T @ influence

reduced_form_jump = jumps[0]
first_stage_jump = jumps[1]
treatment_effect = reduced_form_jump / first_stage_jump

gradient = np.array([1 / first_stage_jump, -reduced_form_jump / first_stage_jump**2])
te_se = np.sqrt(gradient @ joint @ gradient)

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": float(treatment_effect), "se": float(te_se), "n_obs": n_obs},
        {"term": "reduced_form", "estimate": float(reduced_form_jump), "se": float(np.sqrt(joint[0, 0])), "n_obs": n_obs},
        {"term": "first_stage", "estimate": float(first_stage_jump), "se": float(np.sqrt(joint[1, 1])), "n_obs": n_obs},
    ],
    "method_metadata": {"estimator": "fuzzy_rd_local_linear", "vcov": "HC0"},
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2, allow_nan=False)
