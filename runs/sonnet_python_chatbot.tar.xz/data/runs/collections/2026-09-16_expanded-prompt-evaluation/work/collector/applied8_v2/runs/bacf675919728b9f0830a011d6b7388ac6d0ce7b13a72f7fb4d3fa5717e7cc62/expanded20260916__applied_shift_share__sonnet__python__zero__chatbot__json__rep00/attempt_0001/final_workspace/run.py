import pandas as pd
import numpy as np
import json

df = pd.read_csv('input.csv')

# One obs per region
regions = df.drop_duplicates('region_id')[['region_id', 'region_weight', 'x', 'y']].copy()
regions['e_r'] = regions['region_weight'] / regions['region_weight'].sum()

# Construct shift-share instrument z_r = sum_n share_rn * shock_n
shock_map = df.drop_duplicates('industry_id').set_index('industry_id')['shock']
df['share_shock'] = df['share'] * df['shock']
z_r = df.groupby('region_id')['share_shock'].sum().reset_index().rename(columns={'share_shock': 'z'})
regions = regions.merge(z_r, on='region_id')

# Weighted 2SLS at regional level
e = regions['e_r'].values
x = regions['x'].values
y = regions['y'].values
z = regions['z'].values

# Weighted means
xm = np.sum(e * x)
ym = np.sum(e * y)
zm = np.sum(e * z)

# Demeaned
x0 = x - xm
y0 = y - ym
z0 = z - zm

# 2SLS slope: beta = (z0' W x0)^{-1} (z0' W y0) with W = diag(e)
beta_2sls = np.sum(e * z0 * y0) / np.sum(e * z0 * x0)

# First stage slope
beta_fs = np.sum(e * z0 * x0) / np.sum(e * z0 * z0)

# Industry-level aggregation for exposure-robust SE
industries = df['industry_id'].unique()
N = len(industries)

# s_n = sum_r e_r * share_rn
# Map e_r to df
region_e = regions.set_index('region_id')['e_r']
df['e_r'] = df['region_id'].map(region_e)

# Map demeaned variables to df
region_x0 = regions.set_index('region_id')[['x', 'y', 'z']].copy()
region_x0['x0'] = x0
region_x0['y0'] = y0
region_x0['z0'] = z0
df['x0'] = df['region_id'].map(region_x0['x0'])
df['y0'] = df['region_id'].map(region_x0['y0'])
df['z0'] = df['region_id'].map(region_x0['z0'])

df['e_share'] = df['e_r'] * df['share']

s_n = df.groupby('industry_id')['e_share'].sum()

# vbar_n = sum_r e_r * share_rn * v0_r / s_n
for col in ['x0', 'y0', 'z0']:
    df[f'e_share_{col}'] = df['e_r'] * df['share'] * df[col]

agg = df.groupby('industry_id').agg(
    s_n=('e_share', 'sum'),
    ex0=('e_share_x0', 'sum'),
    ey0=('e_share_y0', 'sum'),
    ez0=('e_share_z0', 'sum'),
    shock=('shock', 'first')
).reset_index()

agg['xbar'] = agg['ex0'] / agg['s_n']
agg['ybar'] = agg['ey0'] / agg['s_n']
agg['zbar'] = agg['ez0'] / agg['s_n']

s = agg['s_n'].values
shock_n = agg['shock'].values
xbar = agg['xbar'].values
ybar = agg['ybar'].values
zbar = agg['zbar'].values

# Shock-level IV: ybar ~ xbar, instrument xbar with shock_n, weights s_n
# slope = sum_n s_n * shock_n * ybar_n / sum_n s_n * shock_n * xbar_n
# (with intercept, but shock_n and xbar_n need demeaning by s_n-weighted mean)

sm = np.sum(s * shock_n) / np.sum(s)
xbarm = np.sum(s * xbar) / np.sum(s)
ybarm = np.sum(s * ybar) / np.sum(s)
zbarm = np.sum(s * zbar) / np.sum(s)

shock0 = shock_n - sm
xbar0 = xbar - xbarm
ybar0 = ybar - ybarm
zbar0 = zbar - zbarm

# IV slope for effect: instrument xbar with shock, weight s
beta_iv_effect = np.sum(s * shock0 * ybar0) / np.sum(s * shock0 * xbar0)

# HC1 SE for effect
# Structural residuals: uhat_n = ybar0_n - beta * xbar0_n
uhat = ybar0 - beta_iv_effect * xbar0

# IV score: s_n * shock0_n * uhat_n
score = s * shock0 * uhat
denom = np.sum(s * shock0 * xbar0)

# Sandwich variance with HC1: N/(N-2) * sum(score^2) / denom^2
var_effect = (N / (N - 2)) * np.sum(score**2) / denom**2
se_effect = np.sqrt(var_effect)

# First stage shock-level IV: xbar ~ zbar, instrument zbar with shock_n, weights s_n
# Here zbar is endogenous regressor, shock_n is instrument
beta_fs_shock = np.sum(s * shock0 * xbar0) / np.sum(s * shock0 * zbar0)

# Structural residuals for first stage: vhat_n = xbar0_n - beta_fs_shock * zbar0_n
vhat = xbar0 - beta_fs_shock * zbar0

score_fs = s * shock0 * vhat
denom_fs = np.sum(s * shock0 * zbar0)

var_fs = (N / (N - 2)) * np.sum(score_fs**2) / denom_fs**2
se_fs = np.sqrt(var_fs)

# Effective shocks
effective_shocks = 1.0 / np.sum(s**2)

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": float(beta_iv_effect), "se": float(se_effect), "n_obs": int(N)},
        {"term": "first_stage", "estimate": float(beta_fs_shock), "se": float(se_fs), "n_obs": int(N)},
        {"term": "effective_shocks", "estimate": float(effective_shocks), "se": None, "n_obs": int(N)}
    ],
    "method_metadata": {
        "estimator": "shift_share_2SLS_BHJ",
        "vcov": "exposure_robust_HC1"
    },
    "diagnostics": {}
}

with open('result.json', 'w') as f:
    json.dump(result, f, indent=2)
