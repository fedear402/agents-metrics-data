import pandas as pd
import numpy as np
import json
from statsmodels.regression.linear_model import OLS, WLS

df = pd.read_csv('input.csv')
df.columns = df.columns.str.strip()

bw = 1.0
mask = np.abs(df['score']) < bw
data = df[mask].copy()
n_obs = len(data)

data['w'] = 1 - np.abs(data['score'])
data['above'] = (data['score'] >= 0).astype(float)
data['score_above'] = data['score'] * data['above']
data['score_below'] = data['score'] * (1 - data['above'])

X = np.column_stack([
    np.ones(n_obs),
    data['above'].values,
    data['score_below'].values,
    data['score_above'].values
])

W = np.diag(data['w'].values)
w = data['w'].values

def wls_hc0(X, y, w):
    Xw = X * w[:, None]
    XwX = Xw.T @ X
    XwX_inv = np.linalg.inv(XwX)
    beta = XwX_inv @ (Xw.T @ y)
    resid = y - X @ beta
    # HC0: meat = X'W diag(e^2) WX
    we = w * resid
    meat = (Xw * resid[:, None]).T @ (Xw * resid[:, None])
    vcov = XwX_inv @ meat @ XwX_inv
    return beta, vcov

y_earn = data['earnings'].values
y_part = data['participated'].values

beta_earn, vcov_earn = wls_hc0(X, y_earn, w)
beta_part, vcov_part = wls_hc0(X, y_part, w)

# Discontinuity is coefficient on 'above' (index 1)
rf_est = beta_earn[1]
rf_se = np.sqrt(vcov_earn[1, 1])

fs_est = beta_part[1]
fs_se = np.sqrt(vcov_part[1, 1])

# Delta method for ratio: te = rf / fs
# Need joint covariance of (rf, fs)
# Stack the two regressions and compute joint sandwich
Xw = X * w[:, None]
XwX = Xw.T @ X
XwX_inv = np.linalg.inv(XwX)

resid_earn = y_earn - X @ beta_earn
resid_part = y_part - X @ beta_part

# Joint meat for cross-covariance
# cov(beta_earn[1], beta_part[1]) via joint sandwich
# meat_cross = sum_i (Xw_i * e_earn_i) (Xw_i * e_part_i)'
meat_cross = (Xw * resid_earn[:, None]).T @ (Xw * resid_part[:, None])
vcov_cross = XwX_inv @ meat_cross @ XwX_inv

cov_rf_fs = vcov_cross[1, 1]

# Delta method: te = rf/fs
# d(te)/d(rf) = 1/fs, d(te)/d(fs) = -rf/fs^2
te_est = rf_est / fs_est
grad = np.array([1.0 / fs_est, -rf_est / fs_est**2])
var_te = (grad[0]**2 * vcov_earn[1,1] +
          grad[1]**2 * vcov_part[1,1] +
          2 * grad[0] * grad[1] * cov_rf_fs)
te_se = np.sqrt(var_te)

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": float(te_est), "se": float(te_se), "n_obs": int(n_obs)},
        {"term": "reduced_form", "estimate": float(rf_est), "se": float(rf_se), "n_obs": int(n_obs)},
        {"term": "first_stage", "estimate": float(fs_est), "se": float(fs_se), "n_obs": int(n_obs)}
    ],
    "method_metadata": {
        "estimator": "fuzzy_rd_local_linear_triangular",
        "vcov": "HC0"
    },
    "diagnostics": {}
}

with open('result.json', 'w') as f:
    json.dump(result, f, indent=2)
