import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

df = pd.read_csv('input.csv')
df = df.sort_values('time').reset_index(drop=True)
y = df['y'].values

forecasts = {}
for f in range(101, 251):
    window = y[f-100:f-1]  # y_(f-100) to y_(f-2), indices f-100 to f-2
    # s ranges from f-99 to f-1
    # y_s = a + b*y_(s-1)
    # pairs: (y_(f-99), y_(f-100)), ..., (y_(f-1), y_(f-2))
    y_dep = y[f-99:f]    # y_(f-99) to y_(f-1), 99 values
    y_lag = y[f-100:f-1] # y_(f-100) to y_(f-2), 99 values
    X = sm.add_constant(y_lag)
    model = sm.OLS(y_dep, X).fit()
    a_hat, b_hat = model.params
    forecast = a_hat + b_hat * y[f-1]
    forecasts[f] = forecast

actual = {f: y[f-1] for f in range(101, 251)}  # y[f-1] is y_f (0-indexed, time=f means index f-1)

rmse = np.sqrt(sum((actual[f] - forecasts[f])**2 for f in range(101, 251)) / 150)

result = {
    "task_id": "hard_rolling",
    "platform": "python",
    "estimates": [
        {"term": "rmse", "estimate": float(rmse), "se": None, "n_obs": 150},
        {"term": "forecast_101", "estimate": float(forecasts[101]), "se": None, "n_obs": 99},
        {"term": "forecast_150", "estimate": float(forecasts[150]), "se": None, "n_obs": 99},
        {"term": "forecast_200", "estimate": float(forecasts[200]), "se": None, "n_obs": 99},
        {"term": "forecast_250", "estimate": float(forecasts[250]), "se": None, "n_obs": 99},
    ],
    "method_metadata": {"estimator": "OLS AR(1) rolling", "vcov": "null"},
    "diagnostics": {}
}

with open('result.json', 'w') as f:
    json.dump(result, f, indent=2)
