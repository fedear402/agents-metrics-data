import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df.columns = df.columns.str.strip()

bw = 1.0
mask = np.abs(df["score"]) < bw
df = df[mask].copy()
n_obs = len(df)

score = df["score"].values
weights = 1.0 - np.abs(score)
above = (score >= 0).astype(float)

X = np.column_stack([
    np.ones(n_obs),
    above,
    score,
    above * score
])

Y = np.column_stack([df["earnings"].values, df["participated"].values])

W = weights
WX = W[:, None] * X
bread = np.linalg.inv(X.T @ WX)
coefs = bread @ (WX.T @ Y)

residuals = Y - X @ coefs

# contrast for right minus left limit at cutoff (score=0):
# right limit: [1,1,0,0], left limit: [1,0,0,0], difference: [0,1,0,0]
contrast = np.array([0., 1., 0., 0.])
jumps = contrast @ coefs  # shape (2,)

loading = W * (X @ bread @ contrast)
influence = loading[:, None] * residuals
joint = influence.T @ influence

reduced_form_est = float(jumps[0])
first_stage_est = float(jumps[1])

reduced_form_se = float(np.sqrt(joint[0, 0]))
first_stage_se = float(np.sqrt(joint[1, 1]))

ratio = reduced_form_est / first_stage_est
grad = np.array([1.0 / first_stage_est, -reduced_form_est / first_stage_est**2])
ratio_se = float(np.sqrt(grad @ joint @ grad))

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": ratio, "se": ratio_se, "n_obs": n_obs},
        {"term": "reduced_form", "estimate": reduced_form_est, "se": reduced_form_se, "n_obs": n_obs},
        {"term": "first_stage", "estimate": first_stage_est, "se": first_stage_se, "n_obs": n_obs},
    ],
    "method_metadata": {"estimator": "fuzzy_rd_local_linear", "vcov": "HC0"},
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2, allow_nan=False)
