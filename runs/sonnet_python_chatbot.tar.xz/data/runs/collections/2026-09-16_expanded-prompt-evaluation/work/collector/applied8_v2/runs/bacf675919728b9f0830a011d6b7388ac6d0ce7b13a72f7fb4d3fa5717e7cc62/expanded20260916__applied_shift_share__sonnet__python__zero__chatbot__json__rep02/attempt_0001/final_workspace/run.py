import pandas as pd
import numpy as np
import json

df = pd.read_csv('input.csv')

# One obs per region
regions = df.drop_duplicates('region_id')[['region_id', 'region_weight', 'x', 'y']].copy()
regions['e_r'] = regions['region_weight'] / regions['region_weight'].sum()

# Construct instrument z_r = sum_n share_rn * shock_n
z = df.groupby('region_id').apply(lambda g: (g['share'] * g['shock']).sum()).rename('z')
regions = regions.join(z, on='region_id')

# Normalize weights
e = regions.set_index('region_id')['e_r']
x_r = regions.set_index('region_id')['x']
y_r = regions.set_index('region_id')['y']
z_r = regions.set_index('region_id')['z']

# Weighted means
def wmean(v, w):
    return (v * w).sum()

x_mean = wmean(x_r, e)
y_mean = wmean(y_r, e)
z_mean = wmean(z_r, e)

x0 = x_r - x_mean
y0 = y_r - y_mean
z0 = z_r - z_mean

# Regional 2SLS slope: cov(z0,y0,w) / cov(z0,x0,w)
def wcov(a, b, w):
    return (w * a * b).sum()

beta_2sls = wcov(z0, y0, e) / wcov(z0, x0, e)

# First stage slope
beta_fs = wcov(z0, x0, e) / wcov(z0, z0, e)

# Industry-level aggregation
# s_n = sum_r e_r * share_rn
df2 = df.merge(e.rename('e_r'), left_on='region_id', right_index=True)
df2 = df2.merge(x0.rename('x0'), left_on='region_id', right_index=True)
df2 = df2.merge(y0.rename('y0'), left_on='region_id', right_index=True)
df2 = df2.merge(z0.rename('z0'), left_on='region_id', right_index=True)

df2['e_share'] = df2['e_r'] * df2['share']

ind = df2.groupby('industry_id').agg(
    s_n=('e_share', 'sum'),
    shock=('shock', 'first'),
    xbar_num=('e_share', lambda g: (g * df2.loc[g.index, 'x0']).sum()),
    ybar_num=('e_share', lambda g: (g * df2.loc[g.index, 'y0']).sum()),
    zbar_num=('e_share', lambda g: (g * df2.loc[g.index, 'z0']).sum()),
).reset_index()

# Fix aggregation - need to compute weighted sums properly
ind2 = df2.groupby('industry_id').apply(lambda g: pd.Series({
    's_n': g['e_share'].sum(),
    'shock': g['shock'].iloc[0],
    'xbar_num': (g['e_share'] * g['x0']).sum(),
    'ybar_num': (g['e_share'] * g['y0']).sum(),
    'zbar_num': (g['e_share'] * g['z0']).sum(),
})).reset_index()

ind2['xbar'] = ind2['xbar_num'] / ind2['s_n']
ind2['ybar'] = ind2['ybar_num'] / ind2['s_n']
ind2['zbar'] = ind2['zbar_num'] / ind2['s_n']

s = ind2['s_n'].values
shock = ind2['shock'].values
xbar = ind2['xbar'].values
ybar = ind2['ybar'].values
zbar = ind2['zbar'].values

N = len(ind2)

# Shock-level IV for effect: regress ybar on xbar, instrument xbar with shock, weights s_n
# First stage of shock-level: xbar on shock
def wls_slope_intercept(y, x, w):
    W = np.diag(w)
    X = np.column_stack([np.ones(len(x)), x])
    XtW = X.T @ W
    beta = np.linalg.solve(XtW @ X, XtW @ y)
    return beta

# IV slope using shock as instrument for xbar (2SLS = IV here since just-identified)
# First stage: xbar ~ intercept + shock, weights s
fs_coef = wls_slope_intercept(xbar, shock, s)
xbar_hat = fs_coef[0] + fs_coef[1] * shock

# Second stage: ybar ~ intercept + xbar_hat, weights s (but use structural residuals)
iv_coef_effect = wls_slope_intercept(ybar, xbar_hat, s)
# iv slope equals beta_2sls
slope_effect = iv_coef_effect[1]

# Structural residuals for effect
resid_effect = ybar - iv_coef_effect[0] - slope_effect * xbar

# HC1 SE for effect
# X instrument matrix for projection
Z_mat = np.column_stack([np.ones(N), shock])
X_mat = np.column_stack([np.ones(N), xbar])
sw = s

Xhat = Z_mat @ np.linalg.solve(Z_mat.T @ np.diag(sw) @ Z_mat, Z_mat.T @ np.diag(sw) @ X_mat)

# Sandwich: (Xhat'W X)^{-1} Xhat'W diag(e^2) W Xhat (Xhat'W X)^{-1} * N/(N-2)
WX = np.diag(sw) @ X_mat
WXhat = np.diag(sw) @ Xhat

bread = np.linalg.inv(Xhat.T @ WX)
meat = Xhat.T @ np.diag(sw * resid_effect**2) @ Xhat
V_effect = bread @ meat @ bread * N / (N - 2)
se_effect = np.sqrt(V_effect[1, 1])

# First stage shock-level IV: xbar on zbar, instrument zbar with shock, weights s
fs2_coef_stage1 = wls_slope_intercept(zbar, shock, s)
zbar_hat = fs2_coef_stage1[0] + fs2_coef_stage1[1] * shock

fs2_coef = wls_slope_intercept(xbar, zbar_hat, s)
slope_fs = fs2_coef[1]

resid_fs = xbar - fs2_coef[0] - slope_fs * zbar

Z_mat2 = np.column_stack([np.ones(N), shock])
X_mat2 = np.column_stack([np.ones(N), zbar])

Xhat2 = Z_mat2 @ np.linalg.solve(Z_mat2.T @ np.diag(sw) @ Z_mat2, Z_mat2.T @ np.diag(sw) @ X_mat2)

bread2 = np.linalg.inv(Xhat2.T @ np.diag(sw) @ X_mat2)
meat2 = Xhat2.T @ np.diag(sw * resid_fs**2) @ Xhat2
V_fs = bread2 @ meat2 @ bread2 * N / (N - 2)
se_fs = np.sqrt(V_fs[1, 1])

# Effective shocks
effective_shocks = 1.0 / (s**2).sum()

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": float(slope_effect), "se": float(se_effect), "n_obs": int(N)},
        {"term": "first_stage", "estimate": float(slope_fs), "se": float(se_fs), "n_obs": int(N)},
        {"term": "effective_shocks", "estimate": float(effective_shocks), "se": None, "n_obs": int(N)},
    ],
    "method_metadata": {
        "estimator": "2SLS shift-share with Borusyak-Hull-Jaravel exposure-robust SE",
        "vcov": "HC1 shock-level"
    },
    "diagnostics": {}
}

with open('result.json', 'w') as f:
    json.dump(result, f, indent=2)

print(json.dumps(result, indent=2))
