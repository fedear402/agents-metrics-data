import pandas as pd
import numpy as np
import json
from statsmodels.regression.linear_model import WLS, OLS

df = pd.read_csv('input.csv')
df.columns = df.columns.str.strip()

bw = 1.0
mask = df['score'].abs() < bw
data = df[mask].copy()
n_obs = len(data)

data['w'] = 1 - data['score'].abs()
data['above'] = (data['score'] >= 0).astype(float)
data['score_above'] = data['score'] * data['above']
data['score_below'] = data['score'] * (1 - data['above'])

X = np.column_stack([
    np.ones(n_obs),
    data['above'].values,
    data['score_below'].values,
    data['score_above'].values,
])

W = np.diag(data['w'].values)
w = data['w'].values

y_earn = data['earnings'].values
y_part = data['participated'].values

def wls_fit_hc0(X, y, w):
    Xw = X * w[:, None]
    XtWX = Xw.T @ X
    XtWX_inv = np.linalg.inv(XtWX)
    beta = XtWX_inv @ (Xw.T @ y)
    resid = y - X @ beta
    # HC0 sandwich
    meat = (Xw * resid[:, None]).T @ (Xw * resid[:, None])
    # Wait, need to be careful: sandwich is (X'WX)^{-1} * sum(w_i^2 * e_i^2 * x_i x_i') * (X'WX)^{-1}
    # But with fixed weights, the score is w_i * x_i * e_i
    scores = (w[:, None] * X) * resid[:, None]
    meat = scores.T @ scores
    vcov = XtWX_inv @ meat @ XtWX_inv
    return beta, vcov

beta_earn, vcov_earn = wls_fit_hc0(X, y_earn, w)
beta_part, vcov_part = wls_fit_hc0(X, y_part, w)

# Discontinuity is coefficient on 'above' (index 1)
rf_est = beta_earn[1]
fs_est = beta_part[1]
rf_se = np.sqrt(vcov_earn[1, 1])
fs_se = np.sqrt(vcov_part[1, 1])

# Delta method for treatment_effect = rf / fs
# Need joint covariance of (rf, fs)
# Stack the two regressions and compute joint sandwich
# rf = beta_earn[1], fs = beta_part[1]
# They use the same X and w, so cross-covariance:
Xw = X * w[:, None]
XtWX = Xw.T @ X
XtWX_inv = np.linalg.inv(XtWX)

resid_earn = y_earn - X @ beta_earn
resid_part = y_part - X @ beta_part

scores_earn = (w[:, None] * X) * resid_earn[:, None]
scores_part = (w[:, None] * X) * resid_part[:, None]

meat_cross = scores_earn.T @ scores_part
vcov_cross = XtWX_inv @ meat_cross @ XtWX_inv

cov_rf_fs = vcov_cross[1, 1]

# Delta method: te = rf/fs
# var(te) = (1/fs)^2 * var(rf) + (rf/fs^2)^2 * var(fs) - 2*(rf/fs^3)*cov(rf,fs)
te_est = rf_est / fs_est
var_rf = vcov_earn[1, 1]
var_fs = vcov_part[1, 1]

var_te = (1/fs_est)**2 * var_rf + (rf_est/fs_est**2)**2 * var_fs - 2*(rf_est/fs_est**3)*cov_rf_fs
te_se = np.sqrt(var_te)

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": float(te_est), "se": float(te_se), "n_obs": int(n_obs)},
        {"term": "reduced_form", "estimate": float(rf_est), "se": float(rf_se), "n_obs": int(n_obs)},
        {"term": "first_stage", "estimate": float(fs_est), "se": float(fs_se), "n_obs": int(n_obs)},
    ],
    "method_metadata": {
        "estimator": "fuzzy_rd_local_linear_triangular",
        "vcov": "HC0"
    },
    "diagnostics": {}
}

with open('result.json', 'w') as f:
    json.dump(result, f, indent=2)

print(json.dumps(result, indent=2))
