import pandas as pd
import numpy as np
import json

df = pd.read_csv('input.csv')

# One obs per region
regions = df.drop_duplicates('region_id')[['region_id', 'region_weight', 'x', 'y']].copy()
regions['e_r'] = regions['region_weight'] / regions['region_weight'].sum()

# Construct instrument z_r = sum_n share_rn * shock_n
shock_map = df.drop_duplicates('industry_id').set_index('industry_id')['shock']
df['share_shock'] = df['share'] * df['shock']
z_r = df.groupby('region_id')['share_shock'].sum().reset_index().rename(columns={'share_shock': 'z'})
regions = regions.merge(z_r, on='region_id')

e = regions['e_r'].values
x = regions['x'].values
y = regions['y'].values
z = regions['z'].values

# Weighted means
xbar = np.dot(e, x)
ybar = np.dot(e, y)
zbar = np.dot(e, z)

x0 = x - xbar
y0 = y - ybar
z0 = z - zbar

# 2SLS slope: beta = sum(e*z0*y0) / sum(e*z0*x0)
beta_2sls = np.dot(e, z0 * y0) / np.dot(e, z0 * x0)

# First stage slope
beta_fs = np.dot(e, z0 * x0) / np.dot(e, z0 * z0)

# Industries
industries = df['industry_id'].unique()
N = len(industries)

# s_n = sum_r e_r * share_rn
region_e = regions.set_index('region_id')['e_r'].to_dict()
region_x0 = regions.set_index('region_id')['x'].to_dict()
region_y0 = regions.set_index('region_id')['y'].to_dict()
region_z0 = regions.set_index('region_id')['z'].to_dict()

# Map e_r to df
df['e_r'] = df['region_id'].map(region_e)
df['x0'] = df['x'] - xbar
df['y0'] = df['y'] - ybar
df['z0'] = df['z'].map(lambda r: r) if False else df['region_id'].map({rid: zv - zbar for rid, zv in zip(regions['region_id'], regions['z'])})

# Recompute x0, y0, z0 properly
regions_indexed = regions.set_index('region_id')
df['x0'] = df['region_id'].map(regions_indexed['x']) - xbar
df['y0'] = df['region_id'].map(regions_indexed['y']) - ybar
df['z0'] = df['region_id'].map(regions_indexed['z']) - zbar

# s_n
df['e_share'] = df['e_r'] * df['share']
s_n = df.groupby('industry_id')['e_share'].sum()

# vbar_n for each variable
df['e_share_x0'] = df['e_r'] * df['share'] * df['x0']
df['e_share_y0'] = df['e_r'] * df['share'] * df['y0']
df['e_share_z0'] = df['e_r'] * df['share'] * df['z0']

xbar_n = df.groupby('industry_id')['e_share_x0'].sum() / s_n
ybar_n = df.groupby('industry_id')['e_share_y0'].sum() / s_n
zbar_n = df.groupby('industry_id')['e_share_z0'].sum() / s_n
shock_n = df.drop_duplicates('industry_id').set_index('industry_id')['shock']

# Align
idx = s_n.index
s = s_n.loc[idx].values
xb = xbar_n.loc[idx].values
yb = ybar_n.loc[idx].values
zb = zbar_n.loc[idx].values
sh = shock_n.loc[idx].values

# Shock-level IV for effect: y ~ x, instrument x with shock, weight s
# IV slope = sum(s*sh*yb) / sum(s*sh*xb)  [after demeaning intercept]
# With intercept, demean by s-weighted mean
def s_wmean(v, w):
    return np.dot(w, v) / w.sum()

sh_mean = s_wmean(sh, s)
xb_mean = s_wmean(xb, s)
yb_mean = s_wmean(yb, s)
zb_mean = s_wmean(zb, s)

sh0 = sh - sh_mean
xb0 = xb - xb_mean
yb0 = yb - yb_mean
zb0 = zb - zb_mean

# IV slope for effect
beta_iv = np.dot(s * sh0, yb0) / np.dot(s * sh0, xb0)

# Structural residuals: u_n = yb_n - beta_iv * xb_n (after removing intercept)
intercept_iv = yb_mean - beta_iv * xb_mean
u_n = yb - (intercept_iv + beta_iv * xb)

# HC1 SE for shock-level IV of effect
# Sandwich: (Z'WX)^{-1} Z'W diag(u^2) WZ (X'WZ)^{-1} * N/(N-2)
# With intercept: X = [1, xb], Z = [1, sh], W = diag(s)
# Numerator score for slope: sum_n s_n * sh0_n * u_n
score = s * sh0 * u_n
# Bread: 1/sum(s*sh0*xb0)
bread = np.dot(s, sh0 * xb0)
# Meat: sum(s^2 * sh0^2 * u_n^2) -- but with analytic weights treated as fixed
# HC1: N/(N-2) * (1/bread)^2 * sum(s * sh0 * u_n)^2 ... no, sandwich
# Var(beta) = (1/bread^2) * sum((s * sh0 * u_n)^2) * N/(N-2)
meat = np.sum((s * sh0 * u_n)**2)
var_beta = (N / (N - 2)) * meat / bread**2
se_effect = np.sqrt(var_beta)

# First stage: x ~ z, instrument z with shock, weight s
# IV slope = sum(s*sh0*xb0) / sum(s*sh0*zb0)
beta_fs_shock = np.dot(s * sh0, xb0) / np.dot(s * sh0, zb0)

intercept_fs = xb_mean - beta_fs_shock * zb_mean
u_fs = xb - (intercept_fs + beta_fs_shock * zb)

# HC1 SE for first stage
bread_fs = np.dot(s, sh0 * zb0)
meat_fs = np.sum((s * sh0 * u_fs)**2)
var_fs = (N / (N - 2)) * meat_fs / bread_fs**2
se_fs = np.sqrt(var_fs)

# Effective shocks
effective_shocks = 1.0 / np.sum(s**2)

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": float(beta_iv), "se": float(se_effect), "n_obs": int(N)},
        {"term": "first_stage", "estimate": float(beta_fs_shock), "se": float(se_fs), "n_obs": int(N)},
        {"term": "effective_shocks", "estimate": float(effective_shocks), "se": None, "n_obs": int(N)}
    ],
    "method_metadata": {
        "estimator": "2SLS shift-share with Borusyak-Hull-Jaravel exposure-robust SE",
        "vcov": "HC1 shock-level"
    },
    "diagnostics": {}
}

with open('result.json', 'w') as f:
    json.dump(result, f, indent=2)
