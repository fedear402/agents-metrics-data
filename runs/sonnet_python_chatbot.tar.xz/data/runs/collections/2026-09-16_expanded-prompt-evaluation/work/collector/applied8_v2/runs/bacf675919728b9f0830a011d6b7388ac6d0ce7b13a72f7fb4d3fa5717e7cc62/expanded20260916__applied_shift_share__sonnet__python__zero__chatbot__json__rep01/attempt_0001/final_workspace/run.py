import pandas as pd
import numpy as np
import json

df = pd.read_csv("input.csv")

# One obs per region
regions = df.drop_duplicates("region_id")[["region_id", "region_weight", "x", "y"]].copy()
regions["e_r"] = regions["region_weight"] / regions["region_weight"].sum()

# Construct instrument z_r = sum_n share_rn * shock_n
z = df.groupby("region_id").apply(lambda g: (g["share"] * g["shock"]).sum()).rename("z")
regions = regions.join(z, on="region_id")

# Weighted means
def wmean(v, w):
    return (v * w).sum() / w.sum()

e = regions["e_r"].values
xr = regions["x"].values
yr = regions["y"].values
zr = regions["z"].values

xmean = wmean(regions["x"], regions["e_r"])
ymean = wmean(regions["y"], regions["e_r"])
zmean = wmean(regions["z"], regions["e_r"])

x0 = xr - xmean
y0 = yr - ymean
z0 = zr - zmean

regions["x0"] = x0
regions["y0"] = y0
regions["z0"] = z0

# Industry-level aggregation
# s_n = sum_r e_r * share_rn
region_e = regions.set_index("region_id")["e_r"].to_dict()
region_x0 = regions.set_index("region_id")["x0"].to_dict()
region_y0 = regions.set_index("region_id")["y0"].to_dict()
region_z0 = regions.set_index("region_id")["z0"].to_dict()

df["e_r"] = df["region_id"].map(region_e)
df["x0"] = df["region_id"].map(region_x0)
df["y0"] = df["region_id"].map(region_y0)
df["z0"] = df["region_id"].map(region_z0)

df["e_share"] = df["e_r"] * df["share"]

industries = df.groupby("industry_id").agg(
    shock=("shock", "first"),
    s_n=("e_share", "sum")
).reset_index()

def agg_resid(col):
    return df.groupby("industry_id").apply(
        lambda g: (g["e_r"] * g["share"] * g[col]).sum() / (g["e_r"] * g["share"]).sum()
    ).rename(col + "bar")

xbar = agg_resid("x0")
ybar = agg_resid("y0")
zbar = agg_resid("z0")

industries = industries.join(xbar, on="industry_id")
industries = industries.join(ybar, on="industry_id")
industries = industries.join(zbar, on="industry_id")

N = len(industries)
s = industries["s_n"].values
shock = industries["shock"].values
xb = industries["x0bar"].values
yb = industries["y0bar"].values
zb = industries["z0bar"].values

# Shock-level IV: y ~ 1 + x, instrument x with shock, weights s_n
# 2SLS slope: beta = (Z'WX)^{-1} Z'Wy  (with intercept absorbed by demeaning already done? No, fit with intercept)
# Weighted demeaning for shock-level regression
sw = s / s.sum()

def wm(v):
    return (v * s).sum() / s.sum()

xb_dm = xb - wm(xb)
yb_dm = yb - wm(yb)
zb_dm = zb - wm(zb)
shock_dm = shock - wm(shock)

# IV slope (with intercept, so use demeaned)
# beta_iv = cov_w(shock, y) / cov_w(shock, x)
def wcov(a, b):
    return (a * b * s).sum() / s.sum()

beta_effect = wcov(shock_dm, yb_dm) / wcov(shock_dm, xb_dm)

# Structural residuals for effect
resid_effect = yb_dm - beta_effect * xb_dm

# HC1 SE for effect
# Bread: (Z'WX)^{-1} = 1 / (sum s_n * shock_dm * xb_dm)
ZWX = (s * shock_dm * xb_dm).sum()
# Meat: sum s_n^2 * shock_dm^2 * resid^2
meat_effect = (s**2 * shock_dm**2 * resid_effect**2).sum()
var_effect = (N / (N - 2)) * meat_effect / ZWX**2
se_effect = np.sqrt(var_effect)

# First stage: x ~ 1 + z, instrument z with shock, weights s_n
# beta_fs = cov_w(shock, x) / cov_w(shock, z)
beta_fs = wcov(shock_dm, xb_dm) / wcov(shock_dm, zb_dm)

# Structural residuals for first stage (xbar ~ intercept + zbar, instrumented by shock)
resid_fs = xb_dm - beta_fs * zb_dm

ZWZ = (s * shock_dm * zb_dm).sum()
meat_fs = (s**2 * shock_dm**2 * resid_fs**2).sum()
var_fs = (N / (N - 2)) * meat_fs / ZWZ**2
se_fs = np.sqrt(var_fs)

# Effective shocks
eff_shocks = 1.0 / (s**2).sum()

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": float(beta_effect), "se": float(se_effect), "n_obs": int(N)},
        {"term": "first_stage", "estimate": float(beta_fs), "se": float(se_fs), "n_obs": int(N)},
        {"term": "effective_shocks", "estimate": float(eff_shocks), "se": None, "n_obs": int(N)}
    ],
    "method_metadata": {
        "estimator": "2SLS shift-share IV with BHJ exposure-robust SE",
        "vcov": "HC1 shock-level"
    },
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
