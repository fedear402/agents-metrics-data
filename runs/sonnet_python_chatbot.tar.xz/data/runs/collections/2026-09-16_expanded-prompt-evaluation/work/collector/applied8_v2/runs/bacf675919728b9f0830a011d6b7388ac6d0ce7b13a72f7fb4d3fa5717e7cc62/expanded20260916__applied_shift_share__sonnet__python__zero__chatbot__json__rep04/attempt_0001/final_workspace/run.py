import pandas as pd
import numpy as np
import json

df = pd.read_csv('input.csv')

# Get one obs per region for weights
regions = df.drop_duplicates('region_id')[['region_id', 'region_weight', 'x', 'y']].copy()
regions['e_r'] = regions['region_weight'] / regions['region_weight'].sum()

# Construct shift-share instrument z_r = sum_n share_rn * shock_n
shock_map = df.drop_duplicates('industry_id').set_index('industry_id')['shock']
df['share_shock'] = df['share'] * df['shock']
z_r = df.groupby('region_id')['share_shock'].sum().reset_index().rename(columns={'share_shock': 'z'})

regions = regions.merge(z_r, on='region_id')

# Weighted means (e_r weighted)
def wmean(v, w):
    return np.sum(v * w) / np.sum(w)

e = regions['e_r'].values
y = regions['y'].values
x = regions['x'].values
z = regions['z'].values

y_mean = wmean(y, e)
x_mean = wmean(x, e)
z_mean = wmean(z, e)

y0 = y - y_mean
x0 = x - x_mean
z0 = z - z_mean

regions['y0'] = y0
regions['x0'] = x0
regions['z0'] = z0

# Industry-level aggregation
# s_n = sum_r e_r * share_rn
# vbar_n = sum_r e_r * share_rn * v0_r / s_n

df2 = df.merge(regions[['region_id', 'e_r', 'y0', 'x0', 'z0']], on='region_id')

df2['w_share'] = df2['e_r'] * df2['share']
s_n = df2.groupby('industry_id')['w_share'].sum().reset_index().rename(columns={'w_share': 's_n'})

df2 = df2.merge(s_n, on='industry_id')

for v in ['y0', 'x0', 'z0']:
    df2[f'w_{v}'] = df2['e_r'] * df2['share'] * df2[v]

agg = df2.groupby('industry_id').agg(
    s_n=('s_n', 'first'),
    shock=('shock', 'first'),
    wy0=('w_y0', 'sum'),
    wx0=('w_x0', 'sum'),
    wz0=('w_z0', 'sum')
).reset_index()

agg['ybar'] = agg['wy0'] / agg['s_n']
agg['xbar'] = agg['wx0'] / agg['s_n']
agg['zbar'] = agg['wz0'] / agg['s_n']

N = len(agg)
s = agg['s_n'].values
shock = agg['shock'].values
ybar = agg['ybar'].values
xbar = agg['xbar'].values
zbar = agg['zbar'].values

def weighted_iv_slope(y_dep, x_end, z_inst, w):
    """Weighted IV: regress y on [1, x_end] with instrument [1, z_inst], weights w"""
    # Demean by weighted mean
    w = w / w.sum()
    # First stage: regress x_end on z_inst (weighted)
    # x_end ~ a + b*z_inst
    sw = np.sum(w)
    sz = np.sum(w * z_inst)
    szz = np.sum(w * z_inst**2)
    sxz = np.sum(w * x_end * z_inst)
    sx = np.sum(w * x_end)
    # b_fs = (sxz - sx*sz) / (szz - sz^2)
    b_fs = (sxz - sx * sz) / (szz - sz**2)
    
    # IV slope: cov(y, z) / cov(x, z) weighted
    syz = np.sum(w * y_dep * z_inst)
    sy = np.sum(w * y_dep)
    b_iv = (syz - sy * sz) / (sxz - sx * sz)
    return b_iv, b_fs

# Effect: shock-level IV of ybar on xbar, instrument shock, weights s_n
# (intercept included, but since we already demeaned y0/x0/z0, 
#  the weighted mean of ybar/xbar/zbar should be near zero)
# Actually we need to handle intercept properly in the HC1 calculation

def iv_with_hc1(y_dep, x_end, z_inst, w, n_df=None):
    """
    Weighted IV regression y_dep ~ 1 + x_end, instrument x_end with z_inst, weights w.
    Returns slope and HC1 SE.
    """
    W = np.diag(w)
    # Design matrices
    X = np.column_stack([np.ones(len(y_dep)), x_end])
    Z = np.column_stack([np.ones(len(y_dep)), z_inst])
    
    # 2SLS estimator: beta = (Z'WX)^{-1} Z'Wy
    ZWX = Z.T @ W @ X
    ZWy = Z.T @ W @ y_dep
    beta = np.linalg.solve(ZWX, ZWy)
    
    # Structural residuals
    resid = y_dep - X @ beta
    
    # HC1 variance: V = (Z'WX)^{-1} * [sum_i w_i^2 * u_i^2 * z_i * x_i'] * (X'WZ)^{-1}
    # More precisely, sandwich with HC1 multiplier N/(N-2)
    if n_df is None:
        n_df = len(y_dep)
    
    # Meat: sum_i (w_i * z_i) * u_i^2 * (w_i * x_i)'  -- need to be careful
    # Standard sandwich: (Z'WX)^{-1} [sum_i (w_i*z_i)(w_i*x_i)' u_i^2] (X'WZ)^{-1}
    # With analytic weights, the bread uses W, meat uses w_i^2 * u_i^2
    # HC1 multiplier: N/(N-2)
    
    ZWX_inv = np.linalg.inv(ZWX)
    
    meat = np.zeros((2, 2))
    for i in range(len(y_dep)):
        zi = Z[i] * w[i]
        xi = X[i] * w[i]
        meat += (zi[:, None] @ xi[None, :]) * resid[i]**2
    
    V = ZWX_inv @ meat @ ZWX_inv.T * (n_df / (n_df - 2))
    
    return beta[1], np.sqrt(V[1, 1])

# Effect: ybar ~ 1 + xbar, instrument xbar with shock, weights s_n
effect_slope, effect_se = iv_with_hc1(ybar, xbar, shock, s, N)

# First stage equivalent: xbar ~ 1 + zbar, instrument zbar with shock, weights s_n
fs_slope, fs_se = iv_with_hc1(xbar, zbar, shock, s, N)

# Effective shocks
effective_shocks = 1.0 / np.sum((s / s.sum())**2)
# Actually s_n are already normalized (sum to 1 if shares sum to 1 within regions)
# effective_shocks = 1 / sum_n s_n^2
effective_shocks = 1.0 / np.sum(s**2)

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": float(effect_slope), "se": float(effect_se), "n_obs": int(N)},
        {"term": "first_stage", "estimate": float(fs_slope), "se": float(fs_se), "n_obs": int(N)},
        {"term": "effective_shocks", "estimate": float(effective_shocks), "se": None, "n_obs": int(N)}
    ],
    "method_metadata": {
        "estimator": "2SLS shift-share with Borusyak-Hull-Jaravel exposure-robust SE",
        "vcov": "HC1 shock-level"
    },
    "diagnostics": {}
}

with open('result.json', 'w') as f:
    json.dump(result, f, indent=2)

print("Done. result.json written.")
print(f"Effect: {effect_slope:.6f} (SE: {effect_se:.6f})")
print(f"First stage: {fs_slope:.6f} (SE: {fs_se:.6f})")
print(f"Effective shocks: {effective_shocks:.6f}")
