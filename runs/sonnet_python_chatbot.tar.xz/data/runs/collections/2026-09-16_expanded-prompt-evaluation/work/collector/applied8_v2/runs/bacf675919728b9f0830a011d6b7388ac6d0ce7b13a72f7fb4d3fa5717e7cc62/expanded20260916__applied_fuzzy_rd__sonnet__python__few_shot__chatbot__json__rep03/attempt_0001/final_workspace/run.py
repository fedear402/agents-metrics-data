import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df.columns = df.columns.str.strip()

bw = 1.0
mask = df["score"].abs() < bw
df = df[mask].copy()
n_obs = len(df)

score = df["score"].values
weights = 1 - np.abs(score)
above = (score >= 0).astype(float)
earnings = df["earnings"].values
participated = df["participated"].values

X = np.column_stack([
    np.ones(n_obs),
    above,
    score,
    above * score
])

W = weights

def wls_influence(X, y, W):
    WX = W[:, None] * X
    bread = np.linalg.inv(X.T @ WX)
    coeffs = bread @ (WX.T @ y)
    resid = y - X @ coeffs
    return coeffs, resid, bread

coeffs_e, resid_e, bread = wls_influence(X, earnings, W)
coeffs_p, resid_p, _ = wls_influence(X, participated, W)

contrast = np.array([0., 1., 0., 0.])

reduced_form = contrast @ coeffs_e
first_stage = contrast @ coeffs_p

loading = W * (X @ bread @ contrast)

inf_e = loading * resid_e
inf_p = loading * resid_p

var_e = np.sum(inf_e**2)
var_p = np.sum(inf_p**2)
cov_ep = np.sum(inf_e * inf_p)

se_e = np.sqrt(var_e)
se_p = np.sqrt(var_p)

fs = first_stage
rf = reduced_form
te = rf / fs

grad = np.array([1.0 / fs, -rf / fs**2])
joint = np.array([[var_e, cov_ep], [cov_ep, var_p]])
se_te = np.sqrt(grad @ joint @ grad)

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": float(te), "se": float(se_te), "n_obs": n_obs},
        {"term": "reduced_form", "estimate": float(rf), "se": float(se_e), "n_obs": n_obs},
        {"term": "first_stage", "estimate": float(fs), "se": float(se_p), "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "fuzzy_rd_local_linear",
        "vcov": "HC0"
    },
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2, allow_nan=False)
