import pandas as pd
import numpy as np
from scipy import stats
import json

df = pd.read_csv('./input.csv')
n = len(df)
y = df['y'].values
endog = df['endog'].values
x = df['x'].values
z1 = df['z1'].values
z2 = df['z2'].values

# Critical value: F(2, n-4) at 95th percentile
df1 = 2
df2 = n - 4
f_crit = stats.f.ppf(0.95, df1, df2)

def ar_f_stat(beta):
    # Regress y - beta*endog on intercept, x, z1, z2
    # F test for joint significance of z1, z2 coefficients
    lhs = y - beta * endog
    
    # Restricted model: intercept + x only
    X_r = np.column_stack([np.ones(n), x])
    # Unrestricted model: intercept + x + z1 + z2
    X_u = np.column_stack([np.ones(n), x, z1, z2])
    
    # OLS fits
    beta_r, res_r, rank_r, sv_r = np.linalg.lstsq(X_r, lhs, rcond=None)
    beta_u, res_u, rank_u, sv_u = np.linalg.lstsq(X_u, lhs, rcond=None)
    
    resid_r = lhs - X_r @ beta_r
    resid_u = lhs - X_u @ beta_u
    
    RSS_r = resid_r @ resid_r
    RSS_u = resid_u @ resid_u
    
    F = ((RSS_r - RSS_u) / df1) / (RSS_u / df2)
    return F

# The AR confidence set is {beta: F(beta) <= f_crit}
# F(beta) is a rational function (quadratic/quadratic) in beta
# We need to find roots of F(beta) = f_crit
# 
# The F statistic as function of beta:
# Let w = y - beta*endog
# RSS_u = w'M_u*w where M_u = I - X_u(X_u'X_u)^{-1}X_u'
# RSS_r = w'M_r*w where M_r = I - X_r(X_r'X_r)^{-1}X_r'
# 
# F(beta) = (w'(M_r - M_u)w / 2) / (w'M_u*w / (n-4))
# 
# Since w = y - beta*endog = a - beta*b where a=y, b=endog
# w'Mw = (a - beta*b)'M(a - beta*b) = a'Ma - 2*beta*a'Mb + beta^2 * b'Mb
# This is quadratic in beta

# Precompute projection matrices
X_r = np.column_stack([np.ones(n), x])
X_u = np.column_stack([np.ones(n), x, z1, z2])

# M_r = I - X_r @ pinv(X_r)
Qr = np.linalg.qr(X_r)[0]
M_r = np.eye(n) - Qr @ Qr.T

Qu = np.linalg.qr(X_u)[0]
M_u = np.eye(n) - Qu @ Qu.T

A = M_r - M_u  # numerator projection
B = M_u        # denominator projection

a = y
b = endog

# Coefficients for numerator: a'Aa - 2beta*a'Ab + beta^2*b'Ab
aAa = a @ A @ a
aAb = a @ A @ b
bAb = b @ A @ b

# Coefficients for denominator: a'Ba - 2beta*a'Bb + beta^2*b'Bb
aBa = a @ B @ a
aBb = a @ B @ b
bBb = b @ B @ b

# F(beta) = (num_quad / df1) / (den_quad / df2)
# = (df2/df1) * num_quad / den_quad
# Accept when F <= f_crit
# i.e., (df2/df1) * num_quad <= f_crit * den_quad
# i.e., (df2/df1)*num_quad - f_crit*den_quad <= 0

# num_quad = bAb*beta^2 - 2*aAb*beta + aAa
# den_quad = bBb*beta^2 - 2*aBb*beta + aBa

# g(beta) = (df2/df1)*num_quad - f_crit*den_quad
# = (df2/df1*bAb - f_crit*bBb)*beta^2 
#   + (-2*df2/df1*aAb + 2*f_crit*aBb)*beta
#   + (df2/df1*aAa - f_crit*aBa)

ratio = df2 / df1

A_coef = ratio * bAb - f_crit * bBb
B_coef = -2 * ratio * aAb + 2 * f_crit * aBb
C_coef = ratio * aAa - f_crit * aBa

discriminant = B_coef**2 - 4 * A_coef * C_coef

print(f"A={A_coef}, B={B_coef}, C={C_coef}, disc={discriminant}")
print(f"f_crit={f_crit}, n={n}")

if discriminant < 0:
    # No real roots - either always accepted or never accepted
    # Check sign of A_coef to determine
    if A_coef > 0:
        # parabola opens up, g(beta) has no roots and is always positive if C_coef > 0
        # but discriminant < 0 and A > 0 means g > 0 everywhere -> never accept
        boundary_low = None
        boundary_high = None
        unbounded = 0
    else:
        # A < 0, g < 0 everywhere -> always accept
        boundary_low = None
        boundary_high = None
        unbounded = 1
else:
    root1 = (-B_coef - np.sqrt(discriminant)) / (2 * A_coef)
    root2 = (-B_coef + np.sqrt(discriminant)) / (2 * A_coef)
    boundary_low = min(root1, root2)
    boundary_high = max(root1, root2)
    
    # Determine if set is bounded interval or exterior
    # If A_coef > 0: parabola opens up, g <= 0 between roots -> accept between roots (bounded)
    # If A_coef < 0: parabola opens down, g <= 0 outside roots -> accept outside (unbounded)
    if A_coef > 0:
        unbounded = 0
    else:
        unbounded = 1

# Check accepts_zero
f_at_zero = ar_f_stat(0.0)
accepts_zero = 1 if f_at_zero <= f_crit else 0

# F at beta=1
ar_f_at_one = ar_f_stat(1.0)

print(f"boundary_low={boundary_low}, boundary_high={boundary_high}")
print(f"accepts_zero={accepts_zero}, unbounded={unbounded}")
print(f"ar_f_at_one={ar_f_at_one}")
print(f"f_at_zero={f_at_zero}")

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": [
        {"term": "boundary_low", "estimate": float(boundary_low) if boundary_low is not None else None, "se": None, "n_obs": n},
        {"term": "boundary_high", "estimate": float(boundary_high) if boundary_high is not None else None, "se": None, "n_obs": n},
        {"term": "accepts_zero", "estimate": float(accepts_zero), "se": None, "n_obs": n},
        {"term": "unbounded", "estimate": float(unbounded), "se": None, "n_obs": n},
        {"term": "ar_f_at_one", "estimate": float(ar_f_at_one), "se": None, "n_obs": n},
    ],
    "method_metadata": {
        "estimator": "Anderson-Rubin confidence set via F-test inversion",
        "vcov": "homoskedastic"
    },
    "diagnostics": {}
}

with open('./result.json', 'w') as f:
    json.dump(result, f, indent=2)

print("Done. result.json written.")
