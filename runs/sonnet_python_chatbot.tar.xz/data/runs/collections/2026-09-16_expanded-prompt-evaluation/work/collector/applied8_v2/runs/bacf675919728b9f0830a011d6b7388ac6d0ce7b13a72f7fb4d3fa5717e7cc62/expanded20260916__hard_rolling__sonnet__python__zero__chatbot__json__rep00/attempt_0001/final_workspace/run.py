import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

df = pd.read_csv('input.csv')
df = df.sort_values('time').reset_index(drop=True)
y = df['y'].values

forecasts = {}
for f in range(101, 251):
    window = y[f-100:f-1]  # y_(f-100) to y_(f-2), indices f-100 to f-2
    # s ranges from f-99 to f-1
    # y_s = a + b*y_(s-1)
    # y values: y[f-99-1] to y[f-1-1] as dependent, y[f-100-1] to y[f-2-1] as independent
    # indices (0-based): dependent = y[f-99] to y[f-1], independent = y[f-100] to y[f-2]
    y_dep = y[f-99:f]      # indices f-99 to f-1 inclusive, length 99... wait
    # f-99 to f-1 inclusive = 99 values when f-1 - (f-99) + 1 = 99. Correct.
    # Actually need to check: s=f-99,...,f-1 means 99 values
    # y_s for s=f-99,...,f-1: indices s-1 = f-99-1=f-100 to f-2
    # y_(s-1) for s=f-99,...,f-1: indices f-100 to f-2
    
    y_endog = y[f-99:f]       # y[f-99], ..., y[f-1] (length=99) -- these are y_s for s=f-99..f-1 (1-indexed: time f-99 to f-1)
    y_exog = y[f-100:f-1]     # y[f-100], ..., y[f-2] (length=99) -- these are y_(s-1)
    
    X = sm.add_constant(y_exog)
    model = sm.OLS(y_endog, X).fit()
    a_hat, b_hat = model.params
    forecast_val = a_hat + b_hat * y[f-1]
    forecasts[f] = forecast_val

actuals = {f: y[f-1] for f in range(101, 251)}  # y[f-1] is 0-indexed, so time f is y[f-1]
# Wait: time goes 1..250, y[0]=time1, y[f-1]=time_f
rmse = np.sqrt(sum((actuals[f] - forecasts[f])**2 for f in range(101, 251)) / 150)

result = {
    "task_id": "hard_rolling",
    "platform": "python",
    "estimates": [
        {"term": "rmse", "estimate": float(rmse), "se": None, "n_obs": 150},
        {"term": "forecast_101", "estimate": float(forecasts[101]), "se": None, "n_obs": 99},
        {"term": "forecast_150", "estimate": float(forecasts[150]), "se": None, "n_obs": 99},
        {"term": "forecast_200", "estimate": float(forecasts[200]), "se": None, "n_obs": 99},
        {"term": "forecast_250", "estimate": float(forecasts[250]), "se": None, "n_obs": 99},
    ],
    "method_metadata": {"estimator": "OLS AR(1) rolling", "vcov": "null"},
    "diagnostics": {}
}

with open('result.json', 'w') as f:
    json.dump(result, f, indent=2)
