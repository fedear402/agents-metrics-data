import pandas as pd
import numpy as np
from scipy import stats
import json

df = pd.read_csv('./input.csv')
y = df['y'].values
endog = df['endog'].values
x = df['x'].values
z1 = df['z1'].values
z2 = df['z2'].values
n = len(df)

# Critical value: F(2, n-4) at 95th percentile
df1, df2 = 2, n - 4
f_crit = stats.f.ppf(0.95, df1, df2)

def ar_f_stat(beta):
    # Regress (y - beta*endog) on intercept, x, z1, z2
    # F test for joint significance of z1, z2 coefficients
    lhs = y - beta * endog
    
    # Full model: intercept, x, z1, z2
    X_full = np.column_stack([np.ones(n), x, z1, z2])
    # Restricted model: intercept, x
    X_restr = np.column_stack([np.ones(n), x])
    
    # OLS
    beta_full, _, _, _ = np.linalg.lstsq(X_full, lhs, rcond=None)
    beta_restr, _, _, _ = np.linalg.lstsq(X_restr, lhs, rcond=None)
    
    resid_full = lhs - X_full @ beta_full
    resid_restr = lhs - X_restr @ beta_restr
    
    RSS_full = resid_full @ resid_full
    RSS_restr = resid_restr @ resid_restr
    
    F = ((RSS_restr - RSS_full) / df1) / (RSS_full / df2)
    return F

# The AR F statistic as a function of beta is a quadratic in beta
# F(beta) = [(RSS_restr(beta) - RSS_full(beta)) / df1] / [RSS_full(beta) / df2]
# 
# RSS_full(beta) = || M_full * (y - beta*endog) ||^2
# where M_full = I - X_full(X_full'X_full)^{-1}X_full'
# 
# Let a = M_full * y, b = M_full * endog
# RSS_full(beta) = ||a - beta*b||^2 = a'a - 2*beta*(a'b) + beta^2*(b'b)
#
# Similarly for restricted:
# Let c = M_restr * y, d = M_restr * endog
# RSS_restr(beta) = c'c - 2*beta*(c'd) + beta^2*(d'd)
#
# F(beta) = [(RSS_restr - RSS_full)/df1] / [RSS_full/df2]
# F(beta) * df1 / df2 * RSS_full = RSS_restr - RSS_full
# F(beta) <= f_crit iff RSS_restr - RSS_full <= f_crit * df1/df2 * RSS_full
# iff RSS_restr <= (1 + f_crit*df1/df2) * RSS_full
# 
# Numerator: RSS_restr - RSS_full is quadratic in beta
# Denominator: RSS_full is quadratic in beta
# F(beta) = f_crit at boundary points

X_full = np.column_stack([np.ones(n), x, z1, z2])
X_restr = np.column_stack([np.ones(n), x])

M_full = np.eye(n) - X_full @ np.linalg.solve(X_full.T @ X_full, X_full.T)
M_restr = np.eye(n) - X_restr @ np.linalg.solve(X_restr.T @ X_restr, X_restr.T)

a = M_full @ y
b = M_full @ endog
c = M_restr @ y
d = M_restr @ endog

# RSS_full(beta) = (a - beta*b)'(a - beta*b) = a'a - 2*beta*a'b + beta^2*b'b
aa = a @ a
ab = a @ b
bb = b @ b

# RSS_restr(beta) = c'c - 2*beta*c'd + beta^2*d'd
cc = c @ c
cd = c @ d
dd = d @ d

# F(beta) = [RSS_restr - RSS_full] / df1 / [RSS_full / df2]
# F(beta) = f_crit means:
# (RSS_restr - RSS_full) * df2 = f_crit * df1 * RSS_full
# RSS_restr * df2 - RSS_full * df2 = f_crit * df1 * RSS_full
# RSS_restr * df2 = RSS_full * (df2 + f_crit * df1)
# 
# Let k = df2 + f_crit * df1
# (cc - 2*beta*cd + beta^2*dd)*df2 = (aa - 2*beta*ab + beta^2*bb)*k
# beta^2*(dd*df2 - bb*k) + beta*(-2*cd*df2 + 2*ab*k) + (cc*df2 - aa*k) = 0

k = df2 + f_crit * df1
A_coef = dd * df2 - bb * k
B_coef = -2 * cd * df2 + 2 * ab * k
C_coef = cc * df2 - aa * k

discriminant = B_coef**2 - 4 * A_coef * C_coef

ar_at_one = ar_f_stat(1.0)

if discriminant < 0:
    # No real roots - either always inside or always outside
    f_at_zero = ar_f_stat(0.0)
    if f_at_zero <= f_crit:
        # Always inside - unbounded
        boundary_low = np.nan
        boundary_high = np.nan
        unbounded = 1
        accepts_zero = 1
    else:
        # Always outside - empty set
        boundary_low = np.nan
        boundary_high = np.nan
        unbounded = 0
        accepts_zero = 0
else:
    sqrt_disc = np.sqrt(discriminant)
    if abs(A_coef) < 1e-15:
        # Linear case
        beta_boundary = -C_coef / B_coef
        boundary_low = beta_boundary
        boundary_high = beta_boundary
        unbounded = 0
        accepts_zero = ar_f_stat(0.0) <= f_crit
        accepts_zero = 1 if accepts_zero else 0
    else:
        r1 = (-B_coef - sqrt_disc) / (2 * A_coef)
        r2 = (-B_coef + sqrt_disc) / (2 * A_coef)
        boundary_low = min(r1, r2)
        boundary_high = max(r1, r2)
        
        # Determine if the set is [boundary_low, boundary_high] or its complement
        # Check at midpoint
        mid = (boundary_low + boundary_high) / 2
        f_mid = ar_f_stat(mid)
        
        if f_mid <= f_crit:
            # Set is the interval [boundary_low, boundary_high]
            unbounded = 0
            accepts_zero = 1 if (boundary_low <= 0 <= boundary_high) else 0
        else:
            # Set is complement: (-inf, boundary_low] U [boundary_high, +inf)
            unbounded = 1
            accepts_zero = 1 if (0 <= boundary_low or 0 >= boundary_high) else 0

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": [
        {"term": "boundary_low", "estimate": float(boundary_low), "se": None, "n_obs": n},
        {"term": "boundary_high", "estimate": float(boundary_high), "se": None, "n_obs": n},
        {"term": "accepts_zero", "estimate": float(accepts_zero), "se": None, "n_obs": n},
        {"term": "unbounded", "estimate": float(unbounded), "se": None, "n_obs": n},
        {"term": "ar_f_at_one", "estimate": float(ar_at_one), "se": None, "n_obs": n}
    ],
    "method_metadata": {
        "estimator": "Anderson-Rubin confidence set via F-test inversion",
        "vcov": "homoskedastic"
    },
    "diagnostics": {}
}

with open('result.json', 'w') as f:
    json.dump(result, f, indent=2)

print("boundary_low:", boundary_low)
print("boundary_high:", boundary_high)
print("accepts_zero:", accepts_zero)
print("unbounded:", unbounded)
print("ar_f_at_one:", ar_at_one)
print("f_crit:", f_crit)
