import pandas as pd
import numpy as np
import json
from statsmodels.regression.linear_model import OLS, WLS
from statsmodels.tools import add_constant

df = pd.read_csv('input.csv')
df.columns = df.columns.str.strip()

# Apply bandwidth filter
bw = 1.0
mask = df['score'].abs() < bw
data = df[mask].copy()
n_obs = len(data)

# Triangular weights
data['w'] = 1 - data['score'].abs()

# Indicator for right side (score >= 0)
data['D'] = (data['score'] >= 0).astype(float)

# Design matrix: intercept, D (discontinuity), score_left, score_right
# score_left = score * (1-D), score_right = score * D
data['score_left'] = data['score'] * (1 - data['D'])
data['score_right'] = data['score'] * data['D']

X = data[['D', 'score_left', 'score_right']].copy()
X.insert(0, 'const', 1.0)
X_arr = X.values
W = np.diag(data['w'].values)

# WLS for earnings (reduced form)
y_earn = data['earnings'].values
y_part = data['participated'].values
w_arr = data['w'].values

def wls_hc0(X_arr, y, w):
    """WLS with HC0 robust SE"""
    W_sqrt = np.sqrt(w)
    Xw = X_arr * W_sqrt[:, None]
    yw = y * W_sqrt
    XtX_inv = np.linalg.inv(Xw.T @ Xw)
    beta = XtX_inv @ (Xw.T @ yw)
    resid = y - X_arr @ beta
    # HC0: meat = X'W diag(e^2) WX
    e2 = (resid ** 2)
    meat = (X_arr * w[:, None] * e2[:, None]).T @ (X_arr * w[:, None])
    vcov = XtX_inv @ (Xw.T @ np.diag(e2 * w) @ Xw) @ XtX_inv
    # Recompute properly
    # vcov = (X'WX)^{-1} (X'W diag(e^2) WX) (X'WX)^{-1}
    XtWX_inv = np.linalg.inv(X_arr.T @ np.diag(w) @ X_arr)
    meat2 = X_arr.T @ np.diag(w**2 * e2) @ X_arr
    vcov2 = XtWX_inv @ meat2 @ XtWX_inv
    return beta, vcov2, resid

beta_earn, vcov_earn, resid_earn = wls_hc0(X_arr, y_earn, w_arr)
beta_part, vcov_part, resid_part = wls_hc0(X_arr, y_part, w_arr)

# Discontinuity = coefficient on D (index 1)
rf_est = beta_earn[1]
fs_est = beta_part[1]

rf_se = np.sqrt(vcov_earn[1, 1])
fs_se = np.sqrt(vcov_part[1, 1])

# Treatment effect via delta method
# te = rf / fs
# Need joint covariance of (rf, fs)
# Cross-covariance: cov(beta_earn[1], beta_part[1])
XtWX_inv = np.linalg.inv(X_arr.T @ np.diag(w_arr) @ X_arr)
# cross meat: X'W diag(e_earn * e_part) WX
cross_meat = X_arr.T @ np.diag(w_arr**2 * resid_earn * resid_part) @ X_arr
vcov_cross = XtWX_inv @ cross_meat @ XtWX_inv

cov_rf_fs = vcov_cross[1, 1]

te_est = rf_est / fs_est
# Delta method: var(rf/fs) = (1/fs)^2 * var(rf) + (rf/fs^2)^2 * var(fs) - 2*(rf/fs^3)*cov(rf,fs)
var_te = (1/fs_est)**2 * vcov_earn[1,1] + (rf_est/fs_est**2)**2 * vcov_part[1,1] - 2*(rf_est/fs_est**3)*cov_rf_fs
te_se = np.sqrt(var_te)

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": float(te_est), "se": float(te_se), "n_obs": int(n_obs)},
        {"term": "reduced_form", "estimate": float(rf_est), "se": float(rf_se), "n_obs": int(n_obs)},
        {"term": "first_stage", "estimate": float(fs_est), "se": float(fs_se), "n_obs": int(n_obs)}
    ],
    "method_metadata": {
        "estimator": "fuzzy_rd_local_linear_triangular",
        "vcov": "HC0"
    },
    "diagnostics": {}
}

with open('result.json', 'w') as f:
    json.dump(result, f, indent=2)

print(json.dumps(result, indent=2))
