import pandas as pd
import numpy as np
import json
from statsmodels.regression.linear_model import OLS
from statsmodels.tools import add_constant

df = pd.read_csv('input.csv')
df = df.sort_values('date').reset_index(drop=True)

df['log_sales'] = np.log(df['sales'])
df['log_vix'] = np.log(df['vix'])
df['d_log_vix'] = df['log_vix'].diff()

for lag in range(1, 16):
    df[f'lag_{lag}'] = df['d_log_vix'].shift(lag)

df_reg = df.dropna(subset=['log_sales'] + [f'lag_{i}' for i in range(1, 16)]).copy()

y = df_reg['log_sales']
X = add_constant(df_reg[[f'lag_{i}' for i in range(1, 16)]])

model = OLS(y, X).fit()

N = len(df_reg)
n_lags_nw = 15

# Compute Newey-West HAC manually with Bartlett weights 1-j/16
residuals = model.resid.values
X_vals = model.model.exog

# S0
S = np.zeros((X_vals.shape[1], X_vals.shape[1]))
xe = X_vals * residuals[:, None]
S += xe.T @ xe

for j in range(1, n_lags_nw + 1):
    w = 1 - j / 16
    gamma = xe[j:].T @ xe[:-j]
    S += w * (gamma + gamma.T)

XtX_inv = np.linalg.inv(X_vals.T @ X_vals)
cov_hac = XtX_inv @ S @ XtX_inv

# Scale by N/(N-16)
scale = N / (N - 16)
cov_hac = cov_hac * scale

params = model.params
se_hac = np.sqrt(np.diag(cov_hac))

# cumulative response: sum of lag_1 through lag_15 coefficients (indices 1-15)
lag_indices = list(range(1, 16))
c = np.zeros(len(params))
for i in lag_indices:
    c[i] = 1.0

cumulative_response = c @ params
cumulative_se = np.sqrt(c @ cov_hac @ c)

lag1_est = params['lag_1']
lag1_se = se_hac[list(params.index).index('lag_1')]

lag15_est = params['lag_15']
lag15_se = se_hac[list(params.index).index('lag_15')]

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {"term": "cumulative_response", "estimate": float(cumulative_response), "se": float(cumulative_se), "n_obs": int(N)},
        {"term": "lag_1", "estimate": float(lag1_est), "se": float(lag1_se), "n_obs": int(N)},
        {"term": "lag_15", "estimate": float(lag15_est), "se": float(lag15_se), "n_obs": int(N)}
    ],
    "method_metadata": {
        "estimator": "OLS",
        "vcov": "Newey-West HAC, max_lag=15, Bartlett weights 1-j/16, scaled by N/(N-16)"
    },
    "diagnostics": {}
}

with open('result.json', 'w') as f:
    json.dump(result, f, indent=2)
