import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

df = pd.read_csv('input.csv')
df = df.sort_values('date').reset_index(drop=True)

df['log_sales'] = np.log(df['sales'])
df['log_vix'] = np.log(df['vix'])
df['d_log_vix'] = df['log_vix'].diff()

for lag in range(1, 16):
    df[f'lag_{lag}'] = df['d_log_vix'].shift(lag)

df_reg = df.dropna(subset=['log_sales'] + [f'lag_{i}' for i in range(1, 16)]).copy()

X = sm.add_constant(df_reg[[f'lag_{i}' for i in range(1, 16)]])
y = df_reg['log_sales']

model = sm.OLS(y, X)
results = model.fit()

N = len(df_reg)

# Newey-West with max lag 15, Bartlett weights 1-j/16
# statsmodels cov_hac uses Bartlett kernel by default
nw_cov = sm.stats.sandwich_covariance.cov_hac_simple(results, nlags=15, use_correction=False)
# Multiply by N/(N-16)
nw_cov = nw_cov * N / (N - 16)

params = results.params
lag_names = [f'lag_{i}' for i in range(1, 16)]

# Cumulative response: sum of lag_1 through lag_15 coefficients
# These are indices 1 through 15 in params (index 0 is const)
lag_indices = [list(params.index).index(f'lag_{i}') for i in range(1, 16)]

cum_response = sum(params[f'lag_{i}'] for i in range(1, 16))

# SE for cumulative response using full covariance matrix
c = np.zeros(len(params))
for idx in lag_indices:
    c[idx] = 1.0
cum_var = c @ nw_cov @ c
cum_se = np.sqrt(cum_var)

# Individual SEs
se_lag1 = np.sqrt(nw_cov[lag_indices[0], lag_indices[0]])
se_lag15 = np.sqrt(nw_cov[lag_indices[14], lag_indices[14]])

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {"term": "cumulative_response", "estimate": float(cum_response), "se": float(cum_se), "n_obs": int(N)},
        {"term": "lag_1", "estimate": float(params['lag_1']), "se": float(se_lag1), "n_obs": int(N)},
        {"term": "lag_15", "estimate": float(params['lag_15']), "se": float(se_lag15), "n_obs": int(N)}
    ],
    "method_metadata": {
        "estimator": "OLS",
        "vcov": "Newey-West HAC, max_lag=15, Bartlett weights 1-j/16, scaled by N/(N-16)"
    },
    "diagnostics": {}
}

with open('result.json', 'w') as f:
    json.dump(result, f, indent=2)
