import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

df = pd.read_csv('input.csv')
df = df.sort_values('date').reset_index(drop=True)

df['log_sales'] = np.log(df['sales'])
df['log_vix'] = np.log(df['vix'])
df['d_log_vix'] = df['log_vix'].diff()

for lag in range(1, 16):
    df[f'lag_{lag}'] = df['d_log_vix'].shift(lag)

df_reg = df.dropna(subset=['log_sales'] + [f'lag_{i}' for i in range(1, 16)]).copy()

y = df_reg['log_sales']
X = sm.add_constant(df_reg[[f'lag_{i}' for i in range(1, 16)]])

N = len(df_reg)
model = sm.OLS(y, X)
result = model.fit()

# Newey-West with max lag 15, Bartlett weights 1-j/16
# statsmodels cov_type='HAC' with maxlags=15 uses Bartlett by default
# We need to multiply by N/(N-16)
nw_result = model.fit(cov_type='HAC', cov_kwds={'maxlags': 15, 'use_correction': False})

# Get the raw HAC covariance and apply correction N/(N-16)
# statsmodels HAC: sandwich = (X'X)^{-1} * S * (X'X)^{-1}
# where S uses the Bartlett kernel
# use_correction=False means no df correction in S itself
# We multiply the final cov matrix by N/(N-16)

cov_hac = nw_result.cov_params() * (N / (N - 16))

# Coefficients for lag_1 through lag_15
lag_coefs = result.params[[f'lag_{i}' for i in range(1, 16)]].values
cumulative_response = lag_coefs.sum()

# Standard error of cumulative response using full covariance matrix
lag_cols = [f'lag_{i}' for i in range(1, 16)]
cov_lags = cov_hac.loc[lag_cols, lag_cols].values
ones = np.ones(15)
var_cumulative = ones @ cov_lags @ ones
se_cumulative = np.sqrt(var_cumulative)

se_lag1 = np.sqrt(cov_hac.loc['lag_1', 'lag_1'])
se_lag15 = np.sqrt(cov_hac.loc['lag_15', 'lag_15'])

output = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {"term": "cumulative_response", "estimate": float(cumulative_response), "se": float(se_cumulative), "n_obs": int(N)},
        {"term": "lag_1", "estimate": float(result.params['lag_1']), "se": float(se_lag1), "n_obs": int(N)},
        {"term": "lag_15", "estimate": float(result.params['lag_15']), "se": float(se_lag15), "n_obs": int(N)}
    ],
    "method_metadata": {
        "estimator": "OLS",
        "vcov": "Newey-West HAC maxlags=15 Bartlett weights 1-j/16 scaled by N/(N-16)"
    },
    "diagnostics": {}
}

with open('result.json', 'w') as f:
    json.dump(output, f, indent=2)
