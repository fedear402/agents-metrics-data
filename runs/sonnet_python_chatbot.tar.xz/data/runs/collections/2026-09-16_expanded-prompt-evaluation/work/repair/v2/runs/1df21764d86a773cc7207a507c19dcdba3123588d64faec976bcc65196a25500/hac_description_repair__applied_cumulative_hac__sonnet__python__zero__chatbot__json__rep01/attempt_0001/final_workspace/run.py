import pandas as pd
import numpy as np
import json
from statsmodels.regression.linear_model import OLS
from statsmodels.tools import add_constant

df = pd.read_csv('input.csv')
df = df.sort_values('date').reset_index(drop=True)

df['log_sales'] = np.log(df['sales'])
df['log_vix'] = np.log(df['vix'])
df['d_log_vix'] = df['log_vix'].diff()

for lag in range(1, 16):
    df[f'lag_{lag}'] = df['d_log_vix'].shift(lag)

df_reg = df.dropna(subset=['log_sales'] + [f'lag_{i}' for i in range(1, 16)]).copy()

y = df_reg['log_sales'].values
X = add_constant(df_reg[[f'lag_{i}' for i in range(1, 16)]].values)

model = OLS(y, X)
results = model.fit()

N = len(y)
n_lags_nw = 15

# Newey-West with Bartlett weights 1 - j/16
# statsmodels nw_lags parameter: number of lags
# use_correction=False to avoid internal correction, then apply our own N/(N-16)
cov_nw = results.cov_params() * 0  # placeholder

# Manual Newey-West
resid = results.resid
X_mat = X
XtX_inv = np.linalg.inv(X_mat.T @ X_mat)

# S matrix (sandwich middle)
S = X_mat.T @ np.diag(resid**2) @ X_mat  # lag 0

for j in range(1, n_lags_nw + 1):
    w = 1 - j / 16  # Bartlett weight
    Gamma_j = X_mat[j:].T @ np.diag(resid[j:] * resid[:-j]) @ X_mat[:-j]
    S += w * (Gamma_j + Gamma_j.T)

# Multiply by N/(N-16)
correction = N / (N - 16)
cov_nw = correction * XtX_inv @ S @ XtX_inv

betas = results.params  # intercept + 15 lags

# Coefficients: index 0 = intercept, 1..15 = lag_1..lag_15
lag_coefs = betas[1:]  # lags 1-15
cumulative = np.sum(lag_coefs)

# Standard errors from cov_nw
se_betas = np.sqrt(np.diag(cov_nw))

# SE for cumulative: sum of all lag coefficients
# c = vector of ones for lags (indices 1-15 in full parameter vector)
c = np.zeros(len(betas))
c[1:16] = 1.0
se_cumulative = np.sqrt(c @ cov_nw @ c)

se_lag1 = se_betas[1]
se_lag15 = se_betas[15]

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {"term": "cumulative_response", "estimate": float(cumulative), "se": float(se_cumulative), "n_obs": int(N)},
        {"term": "lag_1", "estimate": float(betas[1]), "se": float(se_lag1), "n_obs": int(N)},
        {"term": "lag_15", "estimate": float(betas[15]), "se": float(se_lag15), "n_obs": int(N)},
    ],
    "method_metadata": {
        "estimator": "OLS",
        "vcov": "Newey-West HAC, max_lag=15, Bartlett weights 1-j/16, scaled by N/(N-16)"
    },
    "diagnostics": {}
}

with open('result.json', 'w') as f:
    json.dump(result, f, indent=2)
