import pandas as pd
import numpy as np
import json
from statsmodels.regression.linear_model import OLS
from statsmodels.tools import add_constant

# Load and sort data
df = pd.read_csv('input.csv')
df['date'] = pd.to_datetime(df['date'])
df = df.sort_values('date').reset_index(drop=True)

# Compute log variables
df['log_sales'] = np.log(df['sales'])
df['log_vix'] = np.log(df['vix'])
df['dlvix'] = df['log_vix'].diff()

# Create lagged variables
for lag in range(1, 16):
    df[f'lag_{lag}'] = df['dlvix'].shift(lag)

# Drop rows with missing values
lag_cols = [f'lag_{i}' for i in range(1, 16)]
df_reg = df[['log_sales'] + lag_cols].dropna().reset_index(drop=True)

y = df_reg['log_sales']
X = add_constant(df_reg[lag_cols])

N = len(df_reg)

# OLS fit
model = OLS(y, X).fit()

# Newey-West HAC with max lag 15 and Bartlett weights 1-j/16
# Compute manually to apply N/(N-16) scaling
residuals = model.resid.values
X_vals = X.values
k = X_vals.shape[1]
max_lag = 15

# Meat of sandwich estimator
S = np.zeros((k, k))
# Lag 0
e_X = X_vals * residuals[:, np.newaxis]
S += e_X.T @ e_X

for j in range(1, max_lag + 1):
    w = 1 - j / 16  # Bartlett weight
    gamma = e_X[j:].T @ e_X[:-j]
    S += w * (gamma + gamma.T)

# Bread: (X'X)^{-1}
XtX_inv = np.linalg.inv(X_vals.T @ X_vals)

# Sandwich
V_raw = XtX_inv @ S @ XtX_inv

# Scale by N/(N-16)
V = V_raw * N / (N - 16)

# Extract coefficients (intercept is index 0, lag_1 is index 1, ..., lag_15 is index 15)
coefs = model.params.values  # [intercept, lag_1, ..., lag_15]

# Cumulative response: sum of lag_1 through lag_15 coefficients (indices 1-15)
lag_indices = list(range(1, 16))
cumulative_response = coefs[lag_indices].sum()

# SE for cumulative response using full covariance matrix
c = np.zeros(k)
for i in lag_indices:
    c[i] = 1.0
var_cum = c @ V @ c
se_cum = np.sqrt(var_cum)

# SE for lag_1 (index 1)
se_lag1 = np.sqrt(V[1, 1])

# SE for lag_15 (index 15)
se_lag15 = np.sqrt(V[15, 15])

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {"term": "cumulative_response", "estimate": float(cumulative_response), "se": float(se_cum), "n_obs": int(N)},
        {"term": "lag_1", "estimate": float(coefs[1]), "se": float(se_lag1), "n_obs": int(N)},
        {"term": "lag_15", "estimate": float(coefs[15]), "se": float(se_lag15), "n_obs": int(N)},
    ],
    "method_metadata": {
        "estimator": "OLS",
        "vcov": "Newey-West HAC max_lag=15 Bartlett scaled by N/(N-16)"
    },
    "diagnostics": {}
}

with open('result.json', 'w') as f:
    json.dump(result, f, indent=2)
