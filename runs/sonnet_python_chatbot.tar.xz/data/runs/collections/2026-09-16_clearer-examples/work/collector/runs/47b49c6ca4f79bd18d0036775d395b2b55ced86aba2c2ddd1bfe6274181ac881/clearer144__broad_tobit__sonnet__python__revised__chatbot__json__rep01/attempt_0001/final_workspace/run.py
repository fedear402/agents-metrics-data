import json
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.stats import norm
from statsmodels.tools.numdiff import approx_hess

df = pd.read_csv('input.csv')
y = df['y'].values
x = df['x'].values
z = df['z'].values
n = len(y)

design = np.column_stack([np.ones(n), x, z])
censored = y == 0.

def loss(params):
    beta = params[:3]
    sigma = np.exp(params[3])
    mu = design @ beta
    ll = 0.
    if censored.any():
        a = (0. - mu[censored]) / sigma
        ll += norm.logcdf(a).sum()
    if (~censored).any():
        r = (y[~censored] - mu[~censored]) / sigma
        ll += (norm.logpdf(r) - np.log(sigma)).sum()
    return -ll

def gradient(params):
    beta = params[:3]
    sigma = np.exp(params[3])
    mu = design @ beta
    grad_beta = np.zeros(3)
    grad_log_sigma = 0.

    if censored.any():
        a = (0. - mu[censored]) / sigma
        mills = np.exp(norm.logpdf(a) - norm.logcdf(a))
        grad_beta += design[censored].T @ (mills / sigma)
        grad_log_sigma += np.sum(a * mills)

    if (~censored).any():
        r = (y[~censored] - mu[~censored]) / sigma
        grad_beta -= design[~censored].T @ (r / sigma)
        grad_log_sigma += np.sum(1. - r * r)

    return np.r_[grad_beta, grad_log_sigma]

# Numerical gradient check
def numerical_gradient(params):
    g = np.zeros(4)
    for j in range(4):
        step = np.zeros(4)
        step[j] = 1e-5
        g[j] = (loss(params + step) - loss(params - step)) / 2e-5
    return g

init = np.array([0., 0., 0., np.log(1.)])
assert np.allclose(gradient(init), numerical_gradient(init), atol=1e-5, rtol=1e-5)

fit = minimize(loss, init, jac=gradient, method='BFGS', options={'gtol': 1e-8, 'maxiter': 10000})
assert np.max(np.abs(gradient(fit.x))) < 1e-5

information = approx_hess(fit.x, loss)
information = (information + information.T) / 2
assert np.linalg.eigvalsh(information).min() > 0
covariance = np.linalg.inv(information)

beta_hat = fit.x[:3]
sigma_hat = np.exp(fit.x[3])
se_const = float(np.sqrt(covariance[0, 0]))
se_x = float(np.sqrt(covariance[1, 1]))
se_z = float(np.sqrt(covariance[2, 2]))

output = {
    "task_id": "broad_tobit",
    "platform": "python",
    "estimates": [
        {"term": "const", "estimate": float(beta_hat[0]), "se": se_const, "n_obs": n},
        {"term": "x", "estimate": float(beta_hat[1]), "se": se_x, "n_obs": n},
        {"term": "z", "estimate": float(beta_hat[2]), "se": se_z, "n_obs": n},
        {"term": "sigma", "estimate": float(sigma_hat), "se": None, "n_obs": n},
    ],
    "method_metadata": {"estimator": "MLE_Tobit", "vcov": "observed_information"},
    "diagnostics": {}
}

with open('result.json', 'w') as f:
    json.dump(output, f, indent=2, allow_nan=False)
