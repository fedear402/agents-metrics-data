import json
import numpy as np
import pandas as pd

data = pd.read_csv("input.csv").sort_values("time").reset_index(drop=True)

window = 100
forecast_times = range(101, 251)
forecasts = {}

for f in forecast_times:
    history = data.loc[data["time"].between(f - window, f - 1)].copy()
    levels = history["y"].to_numpy(dtype=float)
    assert len(levels) == window

    lagged = levels[:-1]
    current = levels[1:]
    X = np.column_stack([np.ones(len(lagged)), lagged])
    coefficients = np.linalg.lstsq(X, current, rcond=None)[0]

    forecasts[f] = float(coefficients[0] + coefficients[1] * levels[-1])

actual = data.set_index("time").loc[list(forecast_times), "y"].to_numpy(dtype=float)
predicted = np.array([forecasts[f] for f in forecast_times])
rmse = float(np.sqrt(np.mean((actual - predicted) ** 2)))

rows = [
    {"term": "rmse", "estimate": rmse, "se": None, "n_obs": 150},
    {"term": "forecast_101", "estimate": forecasts[101], "se": None, "n_obs": 99},
    {"term": "forecast_150", "estimate": forecasts[150], "se": None, "n_obs": 99},
    {"term": "forecast_200", "estimate": forecasts[200], "se": None, "n_obs": 99},
    {"term": "forecast_250", "estimate": forecasts[250], "se": None, "n_obs": 99},
]

output = {
    "task_id": "hard_rolling",
    "platform": "python",
    "estimates": rows,
    "method_metadata": {"estimator": "OLS AR(1) rolling", "vcov": "none"},
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(output, f, indent=2, allow_nan=False)
