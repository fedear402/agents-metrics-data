import json
import numpy as np
import pandas as pd

df = pd.read_csv('input.csv')

# One obs per region for weights
regions = df.drop_duplicates('region_id')[['region_id', 'region_weight', 'x', 'y']].copy()
regions['e'] = regions['region_weight'] / regions['region_weight'].sum()
regions = regions.set_index('region_id')

# Construct shift-share instrument per region
df['ez'] = df['share'] * df['shock']
z_r = df.groupby('region_id')['ez'].sum()
regions['z'] = z_r

e = regions['e'].values
x = regions['x'].values
y = regions['y'].values
z = regions['z'].values

# Weighted means
x_mean = e @ x
y_mean = e @ y
z_mean = e @ z

x0 = x - x_mean
y0 = y - y_mean
z0 = z - z_mean

# Industry-level aggregation
industries = df['industry_id'].unique()
industry_ids = sorted(industries)
region_ids = regions.index.tolist()

# Build arrays indexed by region
e_dict = regions['e'].to_dict()
x0_dict = dict(zip(region_ids, x0))
y0_dict = dict(zip(region_ids, y0))
z0_dict = dict(zip(region_ids, z0))

df['e'] = df['region_id'].map(e_dict)
df['x0'] = df['region_id'].map(x0_dict)
df['y0'] = df['region_id'].map(y0_dict)
df['z0'] = df['region_id'].map(z0_dict)

# s_n = sum_r e_r * share_rn
df['e_share'] = df['e'] * df['share']
s_n = df.groupby('industry_id')['e_share'].sum()

# Aggregate residuals: vbar_n = sum_r e_r * share_rn * v0_r / s_n
df['ey0'] = df['e'] * df['share'] * df['y0']
df['ex0'] = df['e'] * df['share'] * df['x0']
df['ez0'] = df['e'] * df['share'] * df['z0']

ybar = df.groupby('industry_id')['ey0'].sum() / s_n
xbar = df.groupby('industry_id')['ex0'].sum() / s_n
zbar = df.groupby('industry_id')['ez0'].sum() / s_n

# shock is constant within industry
shock_n = df.groupby('industry_id')['shock'].first()

# Align
idx = s_n.index
s = s_n[idx].values
yb = ybar[idx].values
xb = xbar[idx].values
zb = zbar[idx].values
sh = shock_n[idx].values

N = len(idx)

def shock_iv(dependent, endogenous, instrument, weights):
    """IV regression with intercept, weighting by s_n, HC1 SE."""
    regressors = np.column_stack([np.ones(N), endogenous])
    instruments = np.column_stack([np.ones(N), instrument])
    W = weights
    # cross = Z'WX
    cross = instruments.T @ (W[:, None] * regressors)
    # beta = (Z'WX)^{-1} Z'Wy
    beta = np.linalg.solve(cross, instruments.T @ (W * dependent))
    residual = dependent - regressors @ beta
    scores = instruments * (W * residual)[:, None]
    inverse = np.linalg.inv(cross)
    hc1 = N / (N - 2)
    covariance = hc1 * inverse @ (scores.T @ scores) @ inverse.T
    return float(beta[1]), float(np.sqrt(covariance[1, 1]))

# Effect: IV of ybar on xbar, instrument = shock
effect, effect_se = shock_iv(yb, xb, sh, s)

# First stage: IV of xbar on zbar, instrument = shock (zbar is endogenous)
first_stage, first_stage_se = shock_iv(xb, zb, sh, s)

# Effective shocks
effective_shocks = float(1.0 / np.sum(s ** 2))

# Verify regional slopes match
# Regional 2SLS: slope = sum(e*z0*y0)/sum(e*z0*x0)
regional_2sls = np.sum(e * z0 * y0) / np.sum(e * z0 * x0)
regional_fs = np.sum(e * z0 * x0) / np.sum(e * z0 ** 2)
assert np.allclose([effect, first_stage], [regional_2sls, regional_fs], rtol=1e-5), \
    f"Mismatch: effect={effect} vs {regional_2sls}, fs={first_stage} vs {regional_fs}"

output = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": effect, "se": effect_se, "n_obs": N},
        {"term": "first_stage", "estimate": first_stage, "se": first_stage_se, "n_obs": N},
        {"term": "effective_shocks", "estimate": effective_shocks, "se": None, "n_obs": N}
    ],
    "method_metadata": {
        "estimator": "shift_share_IV_2SLS",
        "vcov": "exposure_robust_HC1_shock_level"
    },
    "diagnostics": {}
}

with open('result.json', 'w') as f:
    json.dump(output, f, indent=2, allow_nan=False)
