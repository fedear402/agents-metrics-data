import json
import numpy as np
import pandas as pd

df = pd.read_csv('input.csv')

# One obs per region for weights
regions = df.drop_duplicates('region_id')[['region_id', 'region_weight', 'x', 'y']].copy()
regions['e'] = regions['region_weight'] / regions['region_weight'].sum()
regions = regions.set_index('region_id')

# Compute shift-share instrument per region
df['z_contrib'] = df['share'] * df['shock']
z_by_region = df.groupby('region_id')['z_contrib'].sum()
regions['z'] = z_by_region

# Weighted means
e = regions['e'].values
x_mean = e @ regions['x'].values
y_mean = e @ regions['y'].values
z_mean = e @ regions['z'].values

regions['x0'] = regions['x'] - x_mean
regions['y0'] = regions['y'] - y_mean
regions['z0'] = regions['z'] - z_mean

# Industry-level aggregation
industries = df.drop_duplicates('industry_id')[['industry_id', 'shock']].set_index('industry_id')

# Merge region residuals into df
df2 = df.merge(regions[['e', 'x0', 'y0', 'z0']], on='region_id')

# s_n = sum_r e_r * share_rn
df2['e_share'] = df2['e'] * df2['share']
s_n = df2.groupby('industry_id')['e_share'].sum()

# vbar_n = sum_r e_r * share_rn * v0_r / s_n
for v in ['x0', 'y0', 'z0']:
    df2[f'e_share_{v}'] = df2['e'] * df2['share'] * df2[v]
    agg = df2.groupby('industry_id')[f'e_share_{v}'].sum() / s_n
    industries[f'{v}bar'] = agg

industries['s'] = s_n
shock = industries['shock'].values
s = industries['s'].values
xbar = industries['x0bar'].values
ybar = industries['y0bar'].values
zbar = industries['z0bar'].values

N = len(industries)

def shock_iv(dependent, endogenous, instrument, weights):
    # Include intercept
    regressors = np.column_stack([np.ones(N), endogenous])
    instruments = np.column_stack([np.ones(N), instrument])
    W = weights
    cross = instruments.T @ (W[:, None] * regressors)
    beta = np.linalg.solve(cross, instruments.T @ (W * dependent))
    residual = dependent - regressors @ beta
    scores = instruments * (W * residual)[:, None]
    inv = np.linalg.inv(cross)
    hc1 = N / (N - 2)
    cov = hc1 * inv @ (scores.T @ scores) @ inv.T
    return float(beta[1]), float(np.sqrt(cov[1, 1]))

effect, effect_se = shock_iv(ybar, xbar, shock, s)
first_stage, first_stage_se = shock_iv(xbar, zbar, shock, s)
effective_shocks = float(1.0 / np.sum(s**2))

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": effect, "se": effect_se, "n_obs": N},
        {"term": "first_stage", "estimate": first_stage, "se": first_stage_se, "n_obs": N},
        {"term": "effective_shocks", "estimate": effective_shocks, "se": None, "n_obs": N}
    ],
    "method_metadata": {"estimator": "2SLS_shift_share", "vcov": "HC1_shock_level"},
    "diagnostics": {}
}

with open('result.json', 'w') as f:
    json.dump(result, f, indent=2, allow_nan=False)
