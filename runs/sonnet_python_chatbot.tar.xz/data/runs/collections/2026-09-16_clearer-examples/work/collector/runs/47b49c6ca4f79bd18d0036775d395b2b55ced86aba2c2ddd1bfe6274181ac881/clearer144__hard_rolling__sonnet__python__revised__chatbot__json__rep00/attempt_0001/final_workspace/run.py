import json
import numpy as np
import pandas as pd

data = pd.read_csv("./input.csv").sort_values("time").reset_index(drop=True)

window_levels = 100
forecast_times = list(range(101, 251))
forecasts = {}

for f in forecast_times:
    history = data.loc[data["time"].between(f - window_levels, f - 1)].copy()
    levels = history["y"].to_numpy(dtype=float)
    lagged = levels[:-1]
    current = levels[1:]
    X = np.column_stack([np.ones(len(lagged)), lagged])
    coefficients = np.linalg.lstsq(X, current, rcond=None)[0]
    forecasts[f] = float(coefficients @ np.array([1.0, levels[-1]]))

actual = data.set_index("time").loc[forecast_times, "y"].to_numpy(dtype=float)
predicted = np.array([forecasts[f] for f in forecast_times])
rmse = float(np.sqrt(np.mean((actual - predicted) ** 2)))

report_times = [101, 150, 200, 250]
rows = [
    {"term": "rmse", "estimate": rmse, "se": None, "n_obs": 150},
    *[{"term": f"forecast_{f}", "estimate": forecasts[f], "se": None, "n_obs": 99}
      for f in report_times],
]

output = {
    "task_id": "hard_rolling",
    "platform": "python",
    "estimates": rows,
    "method_metadata": {"estimator": "OLS AR(1) rolling", "vcov": "none"},
    "diagnostics": {}
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
