import json
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.stats import norm
from statsmodels.tools.numdiff import approx_hess

df = pd.read_csv('input.csv')
y = df['y'].values
x = df['x'].values
z = df['z'].values
n = len(y)

design = np.column_stack([np.ones(n), x, z])
censored = y == 0.

def loss(params):
    beta = params[:3]
    sigma = np.exp(params[3])
    mu = design @ beta
    a = (0. - mu[censored]) / sigma
    r = (y[~censored] - mu[~censored]) / sigma
    ll = norm.logcdf(a).sum() + (norm.logpdf(r) - np.log(sigma)).sum()
    return -ll

def gradient(params):
    beta = params[:3]
    sigma = np.exp(params[3])
    mu = design @ beta
    a = (0. - mu[censored]) / sigma
    mills = np.exp(norm.logpdf(a) - norm.logcdf(a))
    r = (y[~censored] - mu[~censored]) / sigma
    # gradient wrt beta
    beta_grad = design[censored].T @ (mills / sigma)
    beta_grad -= design[~censored].T @ (r / sigma)
    # gradient wrt log_sigma
    sigma_grad = np.sum(a * mills) + np.sum(1. - r * r)
    return np.r_[beta_grad, sigma_grad]

initial = np.array([y[y > 0].mean(), 0., 0., np.log(y[y > 0].std())])

fit = minimize(loss, initial, jac=gradient, method='BFGS', options={'gtol': 1e-8, 'maxiter': 10000})

information = approx_hess(fit.x, loss)
covariance = np.linalg.inv(information)

beta_hat = fit.x[:3]
sigma_hat = np.exp(fit.x[3])

se_const = float(np.sqrt(covariance[0, 0]))
se_x = float(np.sqrt(covariance[1, 1]))
se_z = float(np.sqrt(covariance[2, 2]))

output = {
    'task_id': 'broad_tobit',
    'platform': 'python',
    'estimates': [
        {'term': 'const', 'estimate': float(beta_hat[0]), 'se': se_const, 'n_obs': n},
        {'term': 'x', 'estimate': float(beta_hat[1]), 'se': se_x, 'n_obs': n},
        {'term': 'z', 'estimate': float(beta_hat[2]), 'se': se_z, 'n_obs': n},
        {'term': 'sigma', 'estimate': float(sigma_hat), 'se': None, 'n_obs': n},
    ],
    'method_metadata': {
        'estimator': 'Tobit MLE via BFGS',
        'vcov': 'observed information (numerical Hessian of joint log-likelihood)'
    },
    'diagnostics': {}
}

with open('result.json', 'w') as f:
    json.dump(output, f, indent=2, allow_nan=False)
