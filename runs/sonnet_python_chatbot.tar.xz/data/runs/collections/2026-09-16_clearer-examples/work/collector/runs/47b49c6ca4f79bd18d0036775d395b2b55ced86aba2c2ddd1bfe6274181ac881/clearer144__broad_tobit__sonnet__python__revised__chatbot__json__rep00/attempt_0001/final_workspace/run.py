import json
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.stats import norm
from statsmodels.tools.numdiff import approx_hess

df = pd.read_csv('input.csv')
y = df['y'].values
x = df['x'].values
z = df['z'].values
n = len(y)

design = np.column_stack([np.ones(n), x, z])
censored = y == 0.0

def loss(params):
    beta = params[:3]
    sigma = np.exp(params[3])
    mu = design @ beta
    a = (0.0 - mu[censored]) / sigma
    r = (y[~censored] - mu[~censored]) / sigma
    ll = norm.logcdf(a).sum() + (norm.logpdf(r) - np.log(sigma)).sum()
    return -ll

def gradient(params):
    beta = params[:3]
    sigma = np.exp(params[3])
    mu = design @ beta
    a = (0.0 - mu[censored]) / sigma
    r = (y[~censored] - mu[~censored]) / sigma
    mills = np.exp(norm.logpdf(a) - norm.logcdf(a))
    beta_score = design[censored].T @ (mills / sigma)
    beta_score -= design[~censored].T @ (r / sigma)
    sigma_score = np.sum(a * mills) + np.sum(1.0 - r * r)
    return np.r_[beta_score, sigma_score]

def numerical_gradient(params):
    g = np.zeros(4)
    for j in range(4):
        step = np.zeros(4)
        step[j] = 1e-5
        g[j] = (loss(params + step) - loss(params - step)) / 2e-5
    return g

# Initial values
ols_beta = np.linalg.lstsq(design, y, rcond=None)[0]
initial = np.r_[ols_beta, np.log(np.std(y))]

# Verify gradient
assert np.allclose(gradient(initial), numerical_gradient(initial), atol=1e-4, rtol=1e-5)

fit = minimize(loss, initial, jac=gradient, method='BFGS', options={'gtol': 1e-8, 'maxiter': 10000})
assert np.max(np.abs(gradient(fit.x))) < 1e-5

information = approx_hess(fit.x, loss)
information = (information + information.T) / 2
assert np.linalg.eigvalsh(information).min() > 0
covariance = np.linalg.inv(information)

beta_hat = fit.x[:3]
sigma_hat = np.exp(fit.x[3])
se_beta = np.sqrt(np.diag(covariance)[:3])

output = {
    'task_id': 'broad_tobit',
    'platform': 'python',
    'estimates': [
        {'term': 'const', 'estimate': float(beta_hat[0]), 'se': float(se_beta[0]), 'n_obs': n},
        {'term': 'x',     'estimate': float(beta_hat[1]), 'se': float(se_beta[1]), 'n_obs': n},
        {'term': 'z',     'estimate': float(beta_hat[2]), 'se': float(se_beta[2]), 'n_obs': n},
        {'term': 'sigma', 'estimate': float(sigma_hat),   'se': None,              'n_obs': n},
    ],
    'method_metadata': {'estimator': 'MLE_Tobit', 'vcov': 'observed_information'},
    'diagnostics': {}
}

with open('result.json', 'w') as f:
    json.dump(output, f, indent=2, allow_nan=False)
