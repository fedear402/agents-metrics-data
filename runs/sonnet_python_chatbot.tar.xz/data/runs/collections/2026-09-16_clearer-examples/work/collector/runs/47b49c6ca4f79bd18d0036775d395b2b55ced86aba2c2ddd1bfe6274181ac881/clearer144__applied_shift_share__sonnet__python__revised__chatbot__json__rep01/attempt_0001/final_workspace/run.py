import json
import numpy as np
import pandas as pd

df = pd.read_csv('input.csv')

# One obs per region for weights
regions = df.drop_duplicates('region_id')[['region_id', 'region_weight', 'x', 'y']].copy()
regions['e_r'] = regions['region_weight'] / regions['region_weight'].sum()

# Merge weights back
df = df.merge(regions[['region_id', 'e_r']], on='region_id')

# Compute shift-share instrument per region
df['z_r'] = df.groupby('region_id').apply(lambda g: (g['share'] * g['shock']).sum()).reindex(df['region_id']).values

# Regional level data
reg = df.drop_duplicates('region_id')[['region_id', 'e_r', 'x', 'y', 'z_r']].copy()

# Weighted means
mean_y = (reg['e_r'] * reg['y']).sum()
mean_x = (reg['e_r'] * reg['x']).sum()
mean_z = (reg['e_r'] * reg['z_r']).sum()

# Demeaned regional variables
reg['y0'] = reg['y'] - mean_y
reg['x0'] = reg['x'] - mean_x
reg['z0'] = reg['z_r'] - mean_z

# Industry-level aggregation
# s_n = sum_r e_r * share_rn
industry_data = df.merge(reg[['region_id', 'y0', 'x0', 'z0']], on='region_id')
industry_data['e_share'] = industry_data['e_r'] * industry_data['share']

s_n = industry_data.groupby('industry_id')['e_share'].sum()
industries = s_n.index

def agg_var(col):
    tmp = industry_data.groupby('industry_id').apply(
        lambda g: (g['e_r'] * g['share'] * g[col]).sum()
    )
    return tmp / s_n

ybar = agg_var('y0')
xbar = agg_var('x0')
zbar = agg_var('z0')

# Get shock per industry (constant within industry)
shock_n = df.drop_duplicates('industry_id').set_index('industry_id')['shock']
shock_n = shock_n.reindex(industries)
s_n = s_n.reindex(industries)

N = len(industries)
shock_arr = shock_n.values
s_arr = s_n.values
ybar_arr = ybar.values
xbar_arr = xbar.values
zbar_arr = zbar.values

def shock_iv(dependent, endogenous, instrument, weights, n_obs):
    regressors = np.column_stack([np.ones(n_obs), endogenous])
    instruments = np.column_stack([np.ones(n_obs), instrument])
    w = weights
    cross = instruments.T @ (w[:, None] * regressors)
    beta = np.linalg.solve(cross, instruments.T @ (w * dependent))
    residual = dependent - regressors @ beta
    scores = instruments * (w * residual)[:, None]
    inverse = np.linalg.inv(cross)
    hc1 = n_obs / (n_obs - 2)
    covariance = hc1 * inverse @ (scores.T @ scores) @ inverse.T
    return float(beta[1]), float(np.sqrt(covariance[1, 1]))

effect, effect_se = shock_iv(ybar_arr, xbar_arr, shock_arr, s_arr, N)
first_stage, first_stage_se = shock_iv(xbar_arr, zbar_arr, shock_arr, s_arr, N)

effective_shocks = float(1.0 / np.sum(s_arr ** 2))

output = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": effect, "se": effect_se, "n_obs": N},
        {"term": "first_stage", "estimate": first_stage, "se": first_stage_se, "n_obs": N},
        {"term": "effective_shocks", "estimate": effective_shocks, "se": None, "n_obs": N}
    ],
    "method_metadata": {"estimator": "shock_level_IV_2SLS", "vcov": "HC1_exposure_robust"},
    "diagnostics": {}
}

with open('result.json', 'w') as f:
    json.dump(output, f, indent=2, allow_nan=False)
