import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

df = pd.read_csv('./input.csv')

y = df['y_twocluster']
X = sm.add_constant(df['x'])

model = sm.OLS(y, X).fit()

n = len(df)
k = X.shape[1]
resid = model.resid.values
X_mat = X.values

firms = df['firm'].values
years = df['year'].values

def meat_cluster(X_mat, resid, cluster_ids):
    clusters = np.unique(cluster_ids)
    meat = np.zeros((X_mat.shape[1], X_mat.shape[1]))
    for c in clusters:
        idx = cluster_ids == c
        Xc = X_mat[idx]
        ec = resid[idx]
        score = Xc * ec[:, None]
        s = score.sum(axis=0)
        meat += np.outer(s, s)
    return meat

bread = np.linalg.inv(X_mat.T @ X_mat)

meat_firm = meat_cluster(X_mat, resid, firms)
meat_year = meat_cluster(X_mat, resid, years)
meat_both = meat_cluster(X_mat, resid, firms.astype(str) + '_' + years.astype(str))

# CGM formula: V = V_firm + V_year - V_both
meat_cgm = meat_firm + meat_year - meat_both

# Small sample correction
G_firm = len(np.unique(firms))
G_year = len(np.unique(years))

# Standard sandwich
vcov = bread @ meat_cgm @ bread

# Apply small sample correction (common approach: (G/(G-1)) * (n-1)/(n-k))
# Use minimum of the two cluster counts for correction
G_min = min(G_firm, G_year)
correction = (G_min / (G_min - 1)) * ((n - 1) / (n - k))
vcov = correction * vcov

se = np.sqrt(np.diag(vcov))

estimates = [
    {"term": "const", "estimate": float(model.params['const']), "se": float(se[0]), "n_obs": int(n)},
    {"term": "x", "estimate": float(model.params['x']), "se": float(se[1]), "n_obs": int(n)},
]

result = {
    "task_id": "two_way_cluster",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "OLS",
        "vcov": "two-way cluster-robust (Cameron-Gelbach-Miller), clustered on firm and year"
    },
    "diagnostics": {}
}

with open('./result.json', 'w') as f:
    json.dump(result, f, indent=2)
