import pandas as pd
import numpy as np
import statsmodels.formula.api as smf
import json

df = pd.read_csv('./input.csv')

# Demean for two-way FE using within transformation
df['firm'] = df['firm'].astype('category')
df['year'] = df['year'].astype('category')

# Use statsmodels OLS with entity and time dummies
formula = 'y_twocluster ~ x + C(firm) + C(year)'
model = smf.ols(formula, data=df).fit(cov_type='cluster', cov_kwds={'groups': df['firm']})

x_coef = model.params['x']
x_se = model.bse['x']
n_obs = int(model.nobs)

result = {
    "task_id": "twoway_fe",
    "platform": "python",
    "estimates": [
        {"term": "x", "estimate": float(x_coef), "se": float(x_se), "n_obs": n_obs}
    ],
    "method_metadata": {
        "estimator": "OLS with firm and year fixed effects",
        "vcov": "clustered on firm"
    },
    "diagnostics": {}
}

with open('./result.json', 'w') as f:
    json.dump(result, f, indent=2)
