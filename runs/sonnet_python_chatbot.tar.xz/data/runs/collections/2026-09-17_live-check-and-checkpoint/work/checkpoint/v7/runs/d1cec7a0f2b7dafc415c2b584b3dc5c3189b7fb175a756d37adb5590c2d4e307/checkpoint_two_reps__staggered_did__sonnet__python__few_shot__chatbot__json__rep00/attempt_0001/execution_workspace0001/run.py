import json
import pandas as pd

df = pd.read_csv("./input.csv")

cohorts = [4, 6, 8]
never = df[df["cohort"] == -1]

att_cells = []

for g in cohorts:
    treated_g = df[df["cohort"] == g]
    baseline_year = g - 1
    
    mean_never_baseline = never[never["year"] == baseline_year]["y_did"].mean()
    mean_treated_baseline = treated_g[treated_g["year"] == baseline_year]["y_did"].mean()
    
    post_years = [t for t in range(g, 10)]
    
    for t in post_years:
        mean_treated_t = treated_g[treated_g["year"] == t]["y_did"].mean()
        mean_never_t = never[never["year"] == t]["y_did"].mean()
        
        cell_att = (mean_treated_t - mean_treated_baseline) - (mean_never_t - mean_never_baseline)
        att_cells.append(cell_att)

att_uniform = sum(att_cells) / len(att_cells)

n_obs = len(df)

result = {
    "task_id": "staggered_did",
    "platform": "python",
    "estimates": [
        {"term": "att", "estimate": float(att_uniform), "se": None, "n_obs": int(n_obs)}
    ],
    "method_metadata": {
        "estimator": "ATT_uniform from cohort-year cell means, equal-weighted over supported post-treatment cells",
        "vcov": "none"
    },
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(result, f)
