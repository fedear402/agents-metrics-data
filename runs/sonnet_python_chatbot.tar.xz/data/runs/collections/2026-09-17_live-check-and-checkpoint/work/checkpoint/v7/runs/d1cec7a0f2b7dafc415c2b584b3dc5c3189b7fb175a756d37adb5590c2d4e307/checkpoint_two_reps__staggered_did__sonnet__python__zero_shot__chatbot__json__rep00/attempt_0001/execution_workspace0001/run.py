import pandas as pd
import json

df = pd.read_csv('./input.csv')

cohorts = [4, 6, 8]
never = df[df['cohort'] == -1]

att_cells = []

for g in cohorts:
    treated = df[df['cohort'] == g]
    pre_year = g - 1
    
    mean_never_pre = never[never['year'] == pre_year]['y_did'].mean()
    mean_treated_pre = treated[treated['year'] == pre_year]['y_did'].mean()
    
    post_years = [t for t in range(g, 10)]
    
    for t in post_years:
        mean_never_t = never[never['year'] == t]['y_did'].mean()
        mean_treated_t = treated[treated['year'] == t]['y_did'].mean()
        
        att_gt = (mean_treated_t - mean_treated_pre) - (mean_never_t - mean_never_pre)
        att_cells.append(att_gt)

att_uniform = sum(att_cells) / len(att_cells)

n_obs = len(df)

result = {
    "task_id": "staggered_did",
    "platform": "python",
    "estimates": [
        {"term": "att", "estimate": float(att_uniform), "se": None, "n_obs": n_obs}
    ],
    "method_metadata": {
        "estimator": "Callaway-SantAnna style ATT_uniform via group-year means",
        "vcov": "none"
    },
    "diagnostics": {}
}

with open('./result.json', 'w') as f:
    json.dump(result, f, indent=2)
