import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("./input.csv")

X = sm.add_constant(df[["x"]])
y = df["y_twocluster"]

fit = sm.OLS(y, X).fit()

# Cameron-Gelbach-Miller two-way cluster-robust variance
# V_cgm = V_firm + V_year - V_firm_year
def cluster_vcov(fit, cluster_var):
    X = fit.model.exog
    e = fit.resid.values
    clusters = cluster_var.values
    unique = np.unique(clusters)
    meat = np.zeros((X.shape[1], X.shape[1]))
    for c in unique:
        idx = clusters == c
        Xc = X[idx]
        ec = e[idx]
        score = Xc * ec[:, None]
        s = score.sum(axis=0)
        meat += np.outer(s, s)
    bread = fit.normalized_cov_params * fit.nobs  # (X'X)^{-1} * n
    n = fit.nobs
    k = X.shape[1]
    g = len(unique)
    # small sample correction: g/(g-1) * (n-1)/(n-k)
    scale = (g / (g - 1)) * ((n - 1) / (n - k))
    vcov = (bread @ meat @ bread) / n**2 * scale
    return vcov

vcov_firm = cluster_vcov(fit, df["firm"])
vcov_year = cluster_vcov(fit, df["year"])

# intersection clusters (firm-year pairs, each unique so individual obs)
df["firm_year"] = df["firm"].astype(str) + "_" + df["year"].astype(str)
vcov_firmyear = cluster_vcov(fit, df["firm_year"])

vcov_cgm = vcov_firm + vcov_year - vcov_firmyear

se = np.sqrt(np.diag(vcov_cgm))

out = {
    "task_id": "two_way_cluster",
    "platform": "python",
    "estimates": [
        {"term": "const", "estimate": float(fit.params["const"]), "se": float(se[0]), "n_obs": int(fit.nobs)},
        {"term": "x", "estimate": float(fit.params["x"]), "se": float(se[1]), "n_obs": int(fit.nobs)},
    ],
    "method_metadata": {"estimator": "OLS", "vcov": "two-way cluster-robust (Cameron-Gelbach-Miller)"},
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(out, f)
