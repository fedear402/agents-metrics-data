import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

df = pd.read_csv('./input.csv')
z = df['z'].values
d = df['d'].values
y = df['y'].values

h = 0.5
cutoff = 0.0

def triangular_kernel(u):
    return np.maximum(1 - np.abs(u), 0)

weights = triangular_kernel((z - cutoff) / h)

left_mask = (z < cutoff) & (weights > 0)
right_mask = (z >= cutoff) & (weights > 0)

def fit_local_linear(z_sub, y_sub, w_sub):
    X = sm.add_constant(z_sub)
    model = sm.WLS(y_sub, X, weights=w_sub)
    result = model.fit()
    return result

left_result = fit_local_linear(z[left_mask], y[left_mask], weights[left_mask])
right_result = fit_local_linear(z[right_mask], y[right_mask], weights[right_mask])

intercept_left = left_result.params[0]
intercept_right = right_result.params[0]

late_estimate = intercept_right - intercept_left

se_left = left_result.bse[0]
se_right = right_result.bse[0]
late_se = np.sqrt(se_left**2 + se_right**2)

n_obs = int(left_mask.sum() + right_mask.sum())

output = {
    "task_id": "rdd_sharp",
    "platform": "python",
    "estimates": [
        {
            "term": "late",
            "estimate": float(late_estimate),
            "se": float(late_se),
            "n_obs": n_obs
        }
    ],
    "method_metadata": {
        "estimator": "local_linear_regression_triangular_kernel",
        "vcov": "standard_WLS"
    },
    "diagnostics": {}
}

with open('./result.json', 'w') as f:
    json.dump(output, f, indent=2)

print(f"LATE estimate: {late_estimate:.6f}")
print(f"SE: {late_se:.6f}")
print(f"N obs: {n_obs}")
