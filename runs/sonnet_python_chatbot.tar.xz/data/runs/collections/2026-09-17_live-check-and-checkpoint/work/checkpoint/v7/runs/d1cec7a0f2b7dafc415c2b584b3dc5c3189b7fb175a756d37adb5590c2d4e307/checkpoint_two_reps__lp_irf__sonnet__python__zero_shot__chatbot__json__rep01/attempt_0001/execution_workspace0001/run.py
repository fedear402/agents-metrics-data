import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

df = pd.read_csv('./input.csv')
df = df.sort_values('t').reset_index(drop=True)

h = 4
df['y_lead4'] = df['y'].shift(-h)
df['y_lag1'] = df['y'].shift(1)

reg_df = df[['y_lead4', 'shock', 'y_lag1']].dropna()

y = reg_df['y_lead4']
X = sm.add_constant(reg_df[['shock', 'y_lag1']])

model = sm.OLS(y, X)
results = model.fit(cov_type='HAC', cov_kwds={'maxlags': 4})

irf_h4_estimate = results.params['shock']
irf_h4_se = results.bse['shock']
n_obs = int(results.nobs)

output = {
    "task_id": "lp_irf",
    "platform": "python",
    "estimates": [
        {"term": "irf_h4", "estimate": float(irf_h4_estimate), "se": float(irf_h4_se), "n_obs": n_obs}
    ],
    "method_metadata": {"estimator": "OLS local projection", "vcov": "Newey-West HAC (maxlags=4)"},
    "diagnostics": {}
}

with open('./result.json', 'w') as f:
    json.dump(output, f, indent=2)
