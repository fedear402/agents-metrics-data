import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

df = pd.read_csv('./input.csv')

y = df['y_twocluster']
X = sm.add_constant(df['x'])

model = sm.OLS(y, X).fit()

n = len(df)
firms = df['firm'].values
years = df['year'].values

resid = model.resid.values
X_arr = X.values
k = X_arr.shape[1]

XtX_inv = np.linalg.inv(X_arr.T @ X_arr)

def meat_cluster(cluster_ids):
    scores = X_arr * resid[:, None]
    groups = {}
    for i, g in enumerate(cluster_ids):
        if g not in groups:
            groups[g] = np.zeros(k)
        groups[g] += scores[i]
    meat = sum(v[:, None] @ v[None, :] for v in groups.values())
    return meat

meat_firm = meat_cluster(firms)
meat_year = meat_cluster(years)

# Intersections: each observation is its own (firm, year) cluster
meat_both = meat_cluster(list(zip(firms, years)))

# Cameron-Gelbach-Miller: V = V_firm + V_year - V_firmyear
V_firm = XtX_inv @ meat_firm @ XtX_inv
V_year = XtX_inv @ meat_year @ XtX_inv
V_both = XtX_inv @ meat_both @ XtX_inv

V_cgm = V_firm + V_year - V_both

se = np.sqrt(np.diag(V_cgm))

result = {
    "task_id": "two_way_cluster",
    "platform": "python",
    "estimates": [
        {"term": "const", "estimate": float(model.params['const']), "se": float(se[0]), "n_obs": n},
        {"term": "x", "estimate": float(model.params['x']), "se": float(se[1]), "n_obs": n}
    ],
    "method_metadata": {
        "estimator": "OLS",
        "vcov": "two-way cluster-robust (Cameron-Gelbach-Miller), clustered on firm and year"
    },
    "diagnostics": {}
}

with open('./result.json', 'w') as f:
    json.dump(result, f, indent=2)
