import json
import pandas as pd
import statsmodels.formula.api as smf

df = pd.read_csv("./input.csv")

fit = smf.ols("y_twocluster ~ x + C(firm) + C(year)", data=df).fit(
    cov_type="cluster", cov_kwds={"groups": df["firm"]}
)

out = {
    "task_id": "twoway_fe",
    "platform": "python",
    "estimates": [
        {
            "term": "x",
            "estimate": float(fit.params["x"]),
            "se": float(fit.bse["x"]),
            "n_obs": int(fit.nobs),
        }
    ],
    "method_metadata": {
        "estimator": "two-way FE (LSDV, firm + year)",
        "vcov": "clustered (firm)",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(out, f)
