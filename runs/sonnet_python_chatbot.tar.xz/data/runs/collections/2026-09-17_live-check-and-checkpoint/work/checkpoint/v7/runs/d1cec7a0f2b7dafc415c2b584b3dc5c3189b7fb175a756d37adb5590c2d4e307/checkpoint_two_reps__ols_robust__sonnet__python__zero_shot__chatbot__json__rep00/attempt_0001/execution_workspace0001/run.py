import pandas as pd
import statsmodels.api as sm
import json

df = pd.read_csv("./input.csv")
X = sm.add_constant(df[["x1", "x2"]])
y = df["y_lin"]
model = sm.OLS(y, X).fit(cov_type="HC1")

n_obs = int(model.nobs)
estimates = [
    {"term": "const", "estimate": float(model.params["const"]), "se": float(model.bse["const"]), "n_obs": n_obs},
    {"term": "x1", "estimate": float(model.params["x1"]), "se": float(model.bse["x1"]), "n_obs": n_obs},
    {"term": "x2", "estimate": float(model.params["x2"]), "se": float(model.bse["x2"]), "n_obs": n_obs},
]

result = {
    "task_id": "ols_robust",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {"estimator": "OLS", "vcov": "HC1"},
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
