import pandas as pd
import numpy as np
import json
from linearmodels.iv import IV2SLS

df = pd.read_csv('./input.csv')

res = IV2SLS(dependent=df['y_iv'], exog=pd.DataFrame({'const': np.ones(len(df))}), endog=df[['x1_iv']], instruments=df[['z']]).fit(cov_type='robust')

n_obs = int(res.nobs)

estimates = [
    {"term": "const", "estimate": float(res.params['const']), "se": float(res.std_errors['const']), "n_obs": n_obs},
    {"term": "x1_iv", "estimate": float(res.params['x1_iv']), "se": float(res.std_errors['x1_iv']), "n_obs": n_obs},
]

output = {
    "task_id": "iv2sls_robust",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {"estimator": "IV2SLS", "vcov": "HC1"},
    "diagnostics": {}
}

with open('./result.json', 'w') as f:
    json.dump(output, f, indent=2)
