import json
import pandas as pd
import numpy as np
import statsmodels.api as sm

df = pd.read_csv("./input.csv")

cutoff = 0.0
h = 0.5

df_left = df[(df["z"] >= cutoff - h) & (df["z"] < cutoff)].copy()
df_right = df[(df["z"] >= cutoff) & (df["z"] <= cutoff + h)].copy()

def triangular_weight(z, cutoff, h):
    return 1.0 - np.abs(z - cutoff) / h

df_left["w"] = triangular_weight(df_left["z"], cutoff, h)
df_right["w"] = triangular_weight(df_right["z"], cutoff, h)

def fit_local_linear(data, cutoff):
    X = sm.add_constant(data["z"] - cutoff)
    model = sm.WLS(data["y"], X, weights=data["w"])
    result = model.fit()
    return result

res_left = fit_local_linear(df_left, cutoff)
res_right = fit_local_linear(df_right, cutoff)

intercept_left = res_left.params["const"]
intercept_right = res_right.params["const"]

late = intercept_right - intercept_left

se_late = np.sqrt(res_right.bse["const"]**2 + res_left.bse["const"]**2)

n_obs = len(df_left) + len(df_right)

out = {
    "task_id": "rdd_sharp",
    "platform": "python",
    "estimates": [
        {"term": "late", "estimate": float(late), "se": float(se_late), "n_obs": int(n_obs)}
    ],
    "method_metadata": {
        "estimator": "Local linear RDD with triangular kernel, bandwidth 0.5",
        "vcov": "OLS standard errors from WLS"
    },
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(out, f)
