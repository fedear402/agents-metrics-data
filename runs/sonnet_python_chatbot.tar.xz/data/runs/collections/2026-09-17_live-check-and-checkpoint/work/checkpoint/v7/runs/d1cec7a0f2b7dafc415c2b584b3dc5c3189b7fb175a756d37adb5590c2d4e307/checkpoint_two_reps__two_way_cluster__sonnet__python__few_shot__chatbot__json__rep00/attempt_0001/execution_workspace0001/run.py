import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("./input.csv")

X = sm.add_constant(df[["x"]])
y = df["y_twocluster"]

fit = sm.OLS(y, X).fit()

n = len(df)
k = X.shape[1]
firms = df["firm"].values
years = df["year"].values

# Cameron-Gelbach-Miller two-way cluster robust variance
resid = fit.resid.values
X_arr = X.values

def cluster_meat(cluster_ids):
    unique_clusters = np.unique(cluster_ids)
    meat = np.zeros((k, k))
    for c in unique_clusters:
        idx = cluster_ids == c
        X_c = X_arr[idx]
        e_c = resid[idx]
        score_c = X_c.T @ e_c
        meat += np.outer(score_c, score_c)
    return meat

bread = np.linalg.inv(X_arr.T @ X_arr)

meat_firm = cluster_meat(firms)
meat_year = cluster_meat(years)

# Intersection clusters (firm-year pairs)
intersection = np.array([f"{f}_{y}" for f, y in zip(firms, years)])
meat_intersection = cluster_meat(intersection)

# CGM formula: V_firm + V_year - V_intersection
meat_cgm = meat_firm + meat_year - meat_intersection

G_firm = len(np.unique(firms))
G_year = len(np.unique(years))

# Small sample correction: use min(G_firm, G_year)
G = min(G_firm, G_year)
correction = (G / (G - 1)) * (n - 1) / (n - k)

vcov_cgm = correction * bread @ meat_cgm @ bread

se = np.sqrt(np.diag(vcov_cgm))

out = {
    "task_id": "two_way_cluster",
    "platform": "python",
    "estimates": [
        {"term": "const", "estimate": float(fit.params["const"]), "se": float(se[0]), "n_obs": int(n)},
        {"term": "x", "estimate": float(fit.params["x"]), "se": float(se[1]), "n_obs": int(n)},
    ],
    "method_metadata": {"estimator": "OLS", "vcov": "two-way cluster robust (Cameron-Gelbach-Miller)"},
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(out, f)
