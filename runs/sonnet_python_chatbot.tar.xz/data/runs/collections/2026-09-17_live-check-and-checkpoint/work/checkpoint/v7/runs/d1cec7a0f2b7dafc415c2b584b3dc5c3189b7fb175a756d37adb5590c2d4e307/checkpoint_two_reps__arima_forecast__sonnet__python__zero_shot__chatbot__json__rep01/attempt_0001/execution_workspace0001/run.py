import pandas as pd
import json
from statsmodels.tsa.arima.model import ARIMA

df = pd.read_csv('./input.csv')
y = df['y'].values
n_obs = len(y)

model = ARIMA(y, order=(1, 1, 1), trend='n')
result = model.fit(method='innovations_mle')

forecast_result = result.get_forecast(steps=1)
forecast_mean = forecast_result.predicted_mean[0]
conf_int = forecast_result.conf_int(alpha=0.05)
lower_95 = conf_int[0, 0]
upper_95 = conf_int[0, 1]

output = {
    "task_id": "arima_forecast",
    "platform": "python",
    "estimates": [
        {"term": "forecast", "estimate": float(forecast_mean), "se": None, "n_obs": n_obs},
        {"term": "lower_95", "estimate": float(lower_95), "se": None, "n_obs": n_obs},
        {"term": "upper_95", "estimate": float(upper_95), "se": None, "n_obs": n_obs}
    ],
    "method_metadata": {
        "estimator": "ARIMA(1,1,1) MLE via statsmodels",
        "vcov": "observed_information"
    },
    "diagnostics": {}
}

with open('./result.json', 'w') as f:
    json.dump(output, f, indent=2)
