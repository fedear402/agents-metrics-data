import pandas as pd
import json
from lifelines import CoxPHFitter

df = pd.read_csv("./input.csv")

cph = CoxPHFitter()
cph.fit(df[["treat", "x", "t_obs", "event"]], duration_col="t_obs", event_col="event")

summary = cph.summary

n_obs = int(cph.event_observed.shape[0])

estimates = []
for term in ["treat", "x"]:
    coef = float(summary.loc[term, "coef"])
    se = float(summary.loc[term, "se(coef)"])
    estimates.append({"term": term, "estimate": coef, "se": se, "n_obs": n_obs})

result = {
    "task_id": "cox_hazard",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "CoxPHFitter (lifelines)",
        "vcov": "Breslow partial likelihood"
    },
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
