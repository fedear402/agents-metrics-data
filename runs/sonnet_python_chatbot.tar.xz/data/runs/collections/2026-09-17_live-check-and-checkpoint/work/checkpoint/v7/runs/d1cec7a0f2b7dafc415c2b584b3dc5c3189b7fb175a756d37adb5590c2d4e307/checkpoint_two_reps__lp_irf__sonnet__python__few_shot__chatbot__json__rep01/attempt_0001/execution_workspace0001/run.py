import json
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("./input.csv")

h = 4
df["y_lead4"] = df["y"].shift(-h)
df["y_lag1"] = df["y"].shift(1)

reg_df = df[["y_lead4", "shock", "y_lag1"]].dropna()

X = sm.add_constant(reg_df[["shock", "y_lag1"]])
y = reg_df["y_lead4"]

fit = sm.OLS(y, X).fit(cov_type="HAC", cov_kwds={"maxlags": 4})

out = {
    "task_id": "lp_irf",
    "platform": "python",
    "estimates": [
        {
            "term": "irf_h4",
            "estimate": float(fit.params["shock"]),
            "se": float(fit.bse["shock"]),
            "n_obs": int(fit.nobs),
        }
    ],
    "method_metadata": {
        "estimator": "Local Projection OLS, horizon h=4",
        "vcov": "Newey-West HAC, maxlags=4",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(out, f)
