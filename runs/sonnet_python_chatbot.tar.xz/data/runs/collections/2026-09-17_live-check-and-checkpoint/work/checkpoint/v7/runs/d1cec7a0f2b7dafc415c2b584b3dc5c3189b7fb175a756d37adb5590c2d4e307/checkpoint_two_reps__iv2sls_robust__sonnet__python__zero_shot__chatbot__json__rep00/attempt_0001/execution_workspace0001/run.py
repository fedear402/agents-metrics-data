import pandas as pd
import numpy as np
import json
from linearmodels.iv import IV2SLS

df = pd.read_csv('./input.csv')

res = IV2SLS(df['y_iv'], df[['x1_iv']], None, df[['z']], df[['x1_iv']]).fit(cov_type='unadjusted')

# Use statsmodels approach for proper HC1
import statsmodels.api as sm
from linearmodels.iv import IV2SLS as IV

# Actually use linearmodels properly
dependent = df['y_iv']
exog = pd.DataFrame({'const': np.ones(len(df))})
endog = df[['x1_iv']]
instruments = df[['z']]

model = IV2SLS(dependent, exog, endog, instruments)
result = model.fit(cov_type='robust')

params = result.params
std_errors = result.std_errors
n_obs = int(result.nobs)

estimates = [
    {"term": "const", "estimate": float(params['const']), "se": float(std_errors['const']), "n_obs": n_obs},
    {"term": "x1_iv", "estimate": float(params['x1_iv']), "se": float(std_errors['x1_iv']), "n_obs": n_obs},
]

output = {
    "task_id": "iv2sls_robust",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "IV2SLS",
        "vcov": "HC1_robust"
    },
    "diagnostics": {}
}

with open('./result.json', 'w') as f:
    json.dump(output, f, indent=2)
