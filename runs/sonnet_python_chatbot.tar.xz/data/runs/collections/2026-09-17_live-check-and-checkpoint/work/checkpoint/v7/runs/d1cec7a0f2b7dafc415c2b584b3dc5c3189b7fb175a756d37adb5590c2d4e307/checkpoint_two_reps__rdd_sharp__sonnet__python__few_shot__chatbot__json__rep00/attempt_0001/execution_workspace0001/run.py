import json
import pandas as pd
import numpy as np
import statsmodels.api as sm

df = pd.read_csv("./input.csv")

h = 0.5
cutoff = 0.0

df_left = df[(df["z"] >= cutoff - h) & (df["z"] < cutoff)].copy()
df_right = df[(df["z"] >= cutoff) & (df["z"] <= cutoff + h)].copy()

def triangular_kernel(z, c, h):
    u = (z - c) / h
    return np.maximum(0, 1 - np.abs(u))

df_left["w"] = triangular_kernel(df_left["z"], cutoff, h)
df_right["w"] = triangular_kernel(df_right["z"], cutoff, h)

X_left = sm.add_constant(df_left["z"])
model_left = sm.WLS(df_left["y"], X_left, weights=df_left["w"]).fit()
intercept_left = model_left.params["const"]

X_right = sm.add_constant(df_right["z"])
model_right = sm.WLS(df_right["y"], X_right, weights=df_right["w"]).fit()
intercept_right = model_right.params["const"]

late = intercept_right - intercept_left

se_late = float(np.sqrt(model_right.cov_params().loc["const", "const"] + model_left.cov_params().loc["const", "const"]))

n_obs = len(df_left) + len(df_right)

out = {
    "task_id": "rdd_sharp",
    "platform": "python",
    "estimates": [
        {"term": "late", "estimate": float(late), "se": se_late, "n_obs": int(n_obs)}
    ],
    "method_metadata": {
        "estimator": "Local linear RDD with triangular kernel, h=0.5",
        "vcov": "WLS standard errors, independent sides"
    },
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(out, f)
