import pandas as pd
import numpy as np
import json
from statsmodels.tsa.vector_ar.var_model import VAR

df = pd.read_csv('./input.csv')
data = df[['y1', 'y2']].dropna()
n_obs = len(data)

model = VAR(data)
results = model.fit(2, trend='c')

irf = results.irf(4)
# irf.orth_irfs shape: (horizons+1, n_vars, n_vars)
# orth_irfs[h, i, j] = response of variable i to shock in variable j
# Variables: y1=0, y2=1
# Response of y1 (index 0) to shock in y2 (index 1) at horizon 4
irf_val = float(irf.orth_irfs[4, 0, 1])

output = {
    "task_id": "var_irf",
    "platform": "python",
    "estimates": [
        {
            "term": "irf_y1_to_y2_h4",
            "estimate": round(irf_val, 10),
            "se": None,
            "n_obs": n_obs
        }
    ],
    "method_metadata": {
        "estimator": "VAR(2) OLS with constant, Cholesky orthogonalization (y1 ordered first)",
        "vcov": "OLS"
    },
    "diagnostics": {}
}

with open('./result.json', 'w') as f:
    json.dump(output, f, indent=2)
