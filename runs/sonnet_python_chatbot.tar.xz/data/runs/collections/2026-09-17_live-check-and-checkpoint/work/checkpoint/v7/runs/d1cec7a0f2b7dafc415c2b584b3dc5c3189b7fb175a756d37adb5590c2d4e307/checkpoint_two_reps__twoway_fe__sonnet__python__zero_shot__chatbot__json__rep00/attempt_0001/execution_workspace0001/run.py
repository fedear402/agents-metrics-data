import pandas as pd
import numpy as np
import statsmodels.formula.api as smf
import json

df = pd.read_csv("./input.csv")

df["firm"] = df["firm"].astype("category")
df["year"] = df["year"].astype("category")

formula = "y_twocluster ~ x + C(firm) + C(year)"
model = smf.ols(formula, data=df).fit(cov_type="cluster", cov_kwds={"groups": df["firm"]})

coef = float(model.params["x"])
se = float(model.bse["x"])
n_obs = int(model.nobs)

result = {
    "task_id": "twoway_fe",
    "platform": "python",
    "estimates": [
        {"term": "x", "estimate": coef, "se": se, "n_obs": n_obs}
    ],
    "method_metadata": {
        "estimator": "OLS with two-way fixed effects (firm and year)",
        "vcov": "cluster-robust (firm)"
    },
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
