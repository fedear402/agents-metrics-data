import json
import numpy as np
import pandas as pd
from scipy.stats import f

df_data = pd.read_csv('input.csv')
y = df_data['y'].values
endog = df_data['endog'].values
x = df_data['x'].values
z1 = df_data['z1'].values
z2 = df_data['z2'].values
n = len(y)

controls = np.column_stack([np.ones(n), x])
excluded = np.column_stack([z1, z2])
full = np.column_stack([np.ones(n), x, z1, z2])

q = 2
df = n - 4

def residual(y_vec, design):
    coef, _, _, _ = np.linalg.lstsq(design, y_vec, rcond=None)
    return y_vec - design @ coef

critical = f.ppf(0.95, q, df)
k = q * critical / df

ry = residual(y, controls)
rd = residual(endog, controls)
uy = residual(y, full)
ud = residual(endog, full)

A = rd @ rd - (1 + k) * (ud @ ud)
B = -2 * (ry @ rd - (1 + k) * (uy @ ud))
C = ry @ ry - (1 + k) * (uy @ uy)

discriminant = B * B - 4 * A * C

def direct_F(beta):
    yb = y - beta * endog
    r = residual(yb, controls)
    u = residual(yb, full)
    return ((r @ r - u @ u) / q) / ((u @ u) / df)

ar_f_at_one = float(direct_F(1.0))

boundaries = np.sort(np.roots([A, B, C]).real)
boundary_low = float(boundaries[0])
boundary_high = float(boundaries[1])

unbounded = int(A < 0)

def accepts(beta):
    return A * beta * beta + B * beta + C <= 0

accepts_zero = int(accepts(0.0))

rows = [
    {'term': 'boundary_low', 'estimate': boundary_low, 'se': None, 'n_obs': n},
    {'term': 'boundary_high', 'estimate': boundary_high, 'se': None, 'n_obs': n},
    {'term': 'accepts_zero', 'estimate': accepts_zero, 'se': None, 'n_obs': n},
    {'term': 'unbounded', 'estimate': unbounded, 'se': None, 'n_obs': n},
    {'term': 'ar_f_at_one', 'estimate': ar_f_at_one, 'se': None, 'n_obs': n},
]

result = {
    'task_id': 'broad_ar_confidence_set',
    'platform': 'python',
    'estimates': rows,
    'method_metadata': {'estimator': 'Anderson-Rubin', 'vcov': 'homoskedastic'},
    'diagnostics': {}
}

with open('result.json', 'w') as f_out:
    json.dump(result, f_out, indent=2, allow_nan=False)
