import json
import pandas as pd
from statsmodels.tsa.arima.model import ARIMA

df = pd.read_csv("./input.csv")
y = df["y"].values

model = ARIMA(y, order=(1, 1, 1), trend="n")
fit = model.fit()

forecast_result = fit.get_forecast(steps=1)
forecast_mean = float(forecast_result.predicted_mean[0])
conf_int = forecast_result.conf_int(alpha=0.05)
lower_95 = float(conf_int[0, 0])
upper_95 = float(conf_int[0, 1])

n_obs = int(fit.nobs)

out = {
    "task_id": "arima_forecast",
    "platform": "python",
    "estimates": [
        {"term": "forecast", "estimate": forecast_mean, "se": None, "n_obs": n_obs},
        {"term": "lower_95", "estimate": lower_95, "se": None, "n_obs": n_obs},
        {"term": "upper_95", "estimate": upper_95, "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "ARIMA(1,1,1) by maximum likelihood, no constant",
        "vcov": "MLE",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(out, f)
