import pandas as pd
import json

df = pd.read_csv('./input.csv')

cohorts = [4, 6, 8]
never = df[df['cohort'] == -1]

att_values = []
n_obs = 0

for g in cohorts:
    treated = df[df['cohort'] == g]
    baseline_year = g - 1
    post_years = [t for t in range(10) if t >= g]
    
    mean_never_base = never[never['year'] == baseline_year]['y_did'].mean()
    mean_treated_base = treated[treated['year'] == baseline_year]['y_did'].mean()
    
    for t in post_years:
        mean_treated_t = treated[treated['year'] == t]['y_did'].mean()
        mean_never_t = never[never['year'] == t]['y_did'].mean()
        
        att_gt = (mean_treated_t - mean_treated_base) - (mean_never_t - mean_never_base)
        att_values.append(att_gt)
        n_obs += len(treated[treated['year'] == t]) + len(never[never['year'] == t])

att_uniform = sum(att_values) / len(att_values)

result = {
    "task_id": "staggered_did",
    "platform": "python",
    "estimates": [
        {"term": "att", "estimate": float(att_uniform), "se": None, "n_obs": int(n_obs)}
    ],
    "method_metadata": {
        "estimator": "Callaway-SantAnna-style ATT_uniform (equal-weight cohort-time cells)",
        "vcov": "none"
    },
    "diagnostics": {}
}

with open('./result.json', 'w') as f:
    json.dump(result, f, indent=2)
