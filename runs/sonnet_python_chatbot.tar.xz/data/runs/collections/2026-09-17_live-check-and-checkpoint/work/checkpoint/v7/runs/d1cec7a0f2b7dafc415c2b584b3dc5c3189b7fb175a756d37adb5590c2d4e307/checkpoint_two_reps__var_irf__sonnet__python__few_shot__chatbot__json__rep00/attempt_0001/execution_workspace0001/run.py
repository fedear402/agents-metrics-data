import json
import pandas as pd
import numpy as np
from statsmodels.tsa.vector_ar.var_model import VAR

df = pd.read_csv("./input.csv")
data = df[["y1", "y2"]].dropna()

model = VAR(data)
results = model.fit(2)

irf = results.irf(4)

# Cholesky orthogonalized IRF: response of y1 (index 0) to shock in y2 (index 1) at horizon 4
# irf.orth_irfs shape: (horizons+1, k, k) -> [horizon, response_var, impulse_var]
irf_value = float(irf.orth_irfs[4, 0, 1])

n_obs = int(results.nobs)

out = {
    "task_id": "var_irf",
    "platform": "python",
    "estimates": [
        {"term": "irf_y1_to_y2_h4", "estimate": irf_value, "se": None, "n_obs": n_obs}
    ],
    "method_metadata": {
        "estimator": "VAR(2) by OLS with Cholesky identification, y1 ordered first",
        "vcov": "classical"
    },
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(out, f)
