import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy.special import softmax

df = pd.read_csv('input.csv')
n = len(df)

X = pd.DataFrame({'const': np.ones(n), 'x': df['x'].values, 'z': df['z'].values})
y = df['y'].values

fit = sm.MNLogit(y, X).fit(disp=False, tol=1e-10)

outcomes = sorted(np.unique(y).tolist())
nonbase = outcomes[1:]

coefficients = fit.params.copy()
errors = fit.bse.copy()
coefficients.columns = nonbase
errors.columns = nonbase

pred_input = pd.DataFrame({'const': [1.], 'x': [0.], 'z': [0.]})
predicted = pd.Series(np.asarray(fit.predict(pred_input))[0], index=outcomes)

result = {
    'task_id': 'broad_multinomial_logit',
    'platform': 'python',
    'estimates': [
        {'term': 'x_cat1', 'estimate': float(coefficients.loc['x', 1]), 'se': float(errors.loc['x', 1]), 'n_obs': n},
        {'term': 'z_cat1', 'estimate': float(coefficients.loc['z', 1]), 'se': float(errors.loc['z', 1]), 'n_obs': n},
        {'term': 'x_cat2', 'estimate': float(coefficients.loc['x', 2]), 'se': float(errors.loc['x', 2]), 'n_obs': n},
        {'term': 'z_cat2', 'estimate': float(coefficients.loc['z', 2]), 'se': float(errors.loc['z', 2]), 'n_obs': n},
        {'term': 'prob_cat2_zero', 'estimate': float(predicted.loc[2]), 'se': None, 'n_obs': n},
    ],
    'method_metadata': {'estimator': 'MNLogit', 'vcov': 'observed_information'},
    'diagnostics': {}
}

with open('result.json', 'w') as f:
    json.dump(result, f, indent=2, allow_nan=False)
