import pandas as pd
import numpy as np
import json
from statsmodels.discrete.discrete_model import MNLogit

df = pd.read_csv('./input.csv')
n_obs = len(df)

X = pd.DataFrame({'const': 1.0, 'x': df['x'], 'z': df['z']})
y = df['y']

model = MNLogit(y, X)
result = model.fit(method='newton', maxiter=200, disp=False)

params = result.params
bse = result.bse

# params columns correspond to outcomes 1, 2 (base is 0)
# params shape: (n_params, n_outcomes-1)
x_cat1 = float(params.iloc[1, 0])
z_cat1 = float(params.iloc[2, 0])
x_cat2 = float(params.iloc[1, 1])
z_cat2 = float(params.iloc[2, 1])

se_x_cat1 = float(bse.iloc[1, 0])
se_z_cat1 = float(bse.iloc[2, 0])
se_x_cat2 = float(bse.iloc[1, 1])
se_z_cat2 = float(bse.iloc[2, 1])

# Fitted probability of outcome 2 at x=0, z=0
x0 = np.array([[1.0, 0.0, 0.0]])
pred_probs = result.predict(x0)
prob_cat2_zero = float(pred_probs[0, 2])

output = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": [
        {"term": "x_cat1", "estimate": x_cat1, "se": se_x_cat1, "n_obs": n_obs},
        {"term": "z_cat1", "estimate": z_cat1, "se": se_z_cat1, "n_obs": n_obs},
        {"term": "x_cat2", "estimate": x_cat2, "se": se_x_cat2, "n_obs": n_obs},
        {"term": "z_cat2", "estimate": z_cat2, "se": se_z_cat2, "n_obs": n_obs},
        {"term": "prob_cat2_zero", "estimate": prob_cat2_zero, "se": None, "n_obs": n_obs}
    ],
    "method_metadata": {
        "estimator": "MNLogit MLE",
        "vcov": "observed_information"
    },
    "diagnostics": {}
}

with open('./result.json', 'w') as f:
    json.dump(output, f, indent=2)
