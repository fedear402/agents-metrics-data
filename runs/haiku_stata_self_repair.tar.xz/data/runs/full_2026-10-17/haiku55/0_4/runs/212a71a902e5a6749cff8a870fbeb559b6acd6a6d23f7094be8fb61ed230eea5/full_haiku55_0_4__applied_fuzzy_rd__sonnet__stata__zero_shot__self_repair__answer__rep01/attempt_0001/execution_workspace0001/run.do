clear all
set more off
set linesize 255

import delimited using "input.csv", clear varnames(1)

keep if abs(score) < 1
gen double w = 1 - abs(score)
gen double R = (score >= 0)
gen double Rx = R*score
gen double x = score
gen double one = 1

mata:
real matrix X, A, Ai, S1, S2, I, V, C
real colvector w, Y1, Y2, b1, b2, e1, e2, c
real scalar rf, fs, tau, var_tau, n

X = st_data(., ("one","R","x","Rx"))
Y1 = st_data(., "earnings")
Y2 = st_data(., "participated")
w = st_data(., "w")
n = rows(X)

A = cross(X, w, X)
Ai = invsym(A)
b1 = Ai*cross(X, w, Y1)
b2 = Ai*cross(X, w, Y2)
e1 = Y1 - X*b1
e2 = Y2 - X*b2

S1 = X :* ((w:*e1)*J(1,4,1))
S2 = X :* ((w:*e2)*J(1,4,1))
I = (S1*Ai, S2*Ai)
V = cross(I, I)

rf = b1[2]
fs = b2[2]
tau = rf/fs

c = J(8,1,0)
c[2] = 1/fs
c[6] = -rf/fs^2
var_tau = c'V*c

st_numscalar("r_rf", rf)
st_numscalar("se_rf", sqrt(V[2,2]))
st_numscalar("r_fs", fs)
st_numscalar("se_fs", sqrt(V[6,6]))
st_numscalar("r_tau", tau)
st_numscalar("se_tau", sqrt(var_tau))
st_numscalar("n_obs", n)
end

display "ANSWER: treatment_effect estimate=" %21.12f r_tau " se=" %21.12f se_tau " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f r_rf " se=" %21.12f se_rf " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f r_fs " se=" %21.12f se_fs " n_obs=" %12.0f n_obs
