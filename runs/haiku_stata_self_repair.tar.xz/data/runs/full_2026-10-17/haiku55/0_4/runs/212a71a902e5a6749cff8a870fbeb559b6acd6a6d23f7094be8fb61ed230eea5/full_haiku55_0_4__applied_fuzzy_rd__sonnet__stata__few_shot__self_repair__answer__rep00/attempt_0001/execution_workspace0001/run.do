version 19.0
clear all
set more off
set linesize 255

import delimited using "input.csv", clear varnames(1)
keep if abs(score) < 1
gen double w = 1 - abs(score)
gen double above = score >= 0
gen double above_score = above*score
scalar n_obs = _N

mata:
s = st_data(., "score")
a = st_data(., "above")
w = st_data(., "w")
Y = st_data(., ("earnings", "participated"))
X = (J(rows(Y), 1, 1), a, s, a:*s)
bread = invsym(X'*(w:*X))
beta = bread*X'*(w:*Y)
res = Y - X*beta
contrast = (0\1\0\0)
jump = contrast'*beta
loading = w:*(X*bread*contrast)
infl = loading:*res
V = infl'*infl
gradient = (1/jump[2]\-jump[1]/jump[2]^2)
ratio_se = sqrt(gradient'*V*gradient)
st_numscalar("rf_est", jump[1])
st_numscalar("fs_est", jump[2])
st_numscalar("rf_se", sqrt(V[1,1]))
st_numscalar("fs_se", sqrt(V[2,2]))
st_numscalar("te_est", jump[1]/jump[2])
st_numscalar("te_se", ratio_se)
end

display "ANSWER: treatment_effect estimate=" %21.12f te_est " se=" %21.12f te_se " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f rf_est " se=" %21.12f rf_se " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f fs_est " se=" %21.12f fs_se " n_obs=" %12.0f n_obs
