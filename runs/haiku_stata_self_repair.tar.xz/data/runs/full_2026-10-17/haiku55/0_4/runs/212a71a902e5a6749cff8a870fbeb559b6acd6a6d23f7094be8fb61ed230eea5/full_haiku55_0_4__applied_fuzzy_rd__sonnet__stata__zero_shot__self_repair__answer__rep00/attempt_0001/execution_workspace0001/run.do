clear all
set more off
set linesize 255

import delimited using "input.csv", clear varnames(1)

keep if abs(score) < 1
gen double w = 1 - abs(score)
scalar n_obs_total = _N

mata:
real rowvector side_fit(real colvector s, real colvector w, real colvector y, real colvector d)
{
    real matrix X, A, Ai, Myy, Mdd, Myd
    real colvector by, bd, ey, ed
    X = (J(rows(s), 1, 1), s)
    A = cross(X, w, X)
    Ai = invsym(A)
    by = Ai * cross(X, w, y)
    bd = Ai * cross(X, w, d)
    ey = y - X * by
    ed = d - X * bd
    Myy = cross(X, (w :* ey):^2, X)
    Mdd = cross(X, (w :* ed):^2, X)
    Myd = cross(X, (w:^2) :* ey :* ed, X)
    return((by[1], bd[1], (Ai*Myy*Ai)[1,1], (Ai*Mdd*Ai)[1,1], (Ai*Myd*Ai)[1,1]))
}

s = st_data(., "score")
w = st_data(., "w")
y = st_data(., "earnings")
d = st_data(., "participated")
r = selectindex(s :>= 0)
l = selectindex(s :< 0)

RR = side_fit(s[r], w[r], y[r], d[r])
RL = side_fit(s[l], w[l], y[l], d[l])

rf = RR[1] - RL[1]
fs = RR[2] - RL[2]
Vrf = RR[3] + RL[3]
Vfs = RR[4] + RL[4]
Cov = RR[5] + RL[5]
te = rf / fs
g1 = 1 / fs
g2 = -rf / (fs^2)
Vte = g1^2 * Vrf + 2 * g1 * g2 * Cov + g2^2 * Vfs

st_numscalar("rf_est", rf)
st_numscalar("rf_se", sqrt(Vrf))
st_numscalar("fs_est", fs)
st_numscalar("fs_se", sqrt(Vfs))
st_numscalar("te_est", te)
st_numscalar("te_se", sqrt(Vte))
end

display "ANSWER: treatment_effect estimate=" %21.12f te_est " se=" %21.12f te_se " n_obs=" %12.0f n_obs_total
display "ANSWER: reduced_form estimate=" %21.12f rf_est " se=" %21.12f rf_se " n_obs=" %12.0f n_obs_total
display "ANSWER: first_stage estimate=" %21.12f fs_est " se=" %21.12f fs_se " n_obs=" %12.0f n_obs_total
