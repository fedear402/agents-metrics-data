clear all
set more off

import delimited using "crosswalk.csv", clear
keep code industry
tempfile cw
save `cw'

import delimited using "trade.csv", clear
merge m:1 code using `cw', keep(match) nogen
keep period industry us_change other_change price_index years
tempfile tr
save `tr'

import delimited using "outcomes.csv", clear
keep area period control change_pp
tempfile out
save `out'

import delimited using "employment.csv", clear
collapse (sum) employment, by(area period vintage industry)
tempfile emp
save `emp'

import delimited using "crosswalk.csv", clear
keep industry
duplicates drop
gen byte k = 1
tempfile ind
save `ind'

import delimited using "areas.csv", clear
keep area period vintage total_employment population
gen byte k = 1
joinby k using `ind'
drop k
merge 1:1 area period vintage industry using `emp', keep(master match) nogen
replace employment = 0 if missing(employment)

egen double nat = total(employment), by(period vintage industry)

merge m:1 period industry using `tr', keep(match) nogen

gen double sh = employment / total_employment
gen double f = (100 / price_index) / 1000 * (10 / years)
gen double xc = cond(vintage == "base", sh * (us_change / nat) * f, 0)
gen double zc = cond(vintage == "early", sh * (other_change / nat) * f, 0)
gen double popb = cond(vintage == "base", population, 0)

collapse (sum) x = xc z = zc popb, by(area period)

merge 1:1 area period using `out', keep(match) nogen

count
local nobs = r(N)

ivregress 2sls change_pp period control (x = z) [aweight = popb]
local nobs = e(N)
local b_iv = _b[x]

summarize x if area == 0 & period == 0, meanonly
local ex0 = r(mean)
summarize x if area == 0 & period == 1, meanonly
local ex1 = r(mean)
summarize z if area == 0 & period == 0, meanonly
local iz0 = r(mean)

display "ANSWER: iv_slope estimate=" trim(string(`b_iv', "%20.12g")) " se=NA n_obs=" trim(string(`nobs', "%9.0f"))
display "ANSWER: exposure_area0_period0 estimate=" trim(string(`ex0', "%20.12g")) " se=NA n_obs=" trim(string(`nobs', "%9.0f"))
display "ANSWER: exposure_area0_period1 estimate=" trim(string(`ex1', "%20.12g")) " se=NA n_obs=" trim(string(`nobs', "%9.0f"))
display "ANSWER: instrument_area0_period0 estimate=" trim(string(`iz0', "%20.12g")) " se=NA n_obs=" trim(string(`nobs', "%9.0f"))
