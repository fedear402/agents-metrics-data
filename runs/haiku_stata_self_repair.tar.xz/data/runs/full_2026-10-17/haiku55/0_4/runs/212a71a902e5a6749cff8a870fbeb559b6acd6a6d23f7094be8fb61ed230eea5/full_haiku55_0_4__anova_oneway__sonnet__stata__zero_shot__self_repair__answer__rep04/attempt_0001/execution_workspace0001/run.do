clear all
set more off
set linesize 255

import delimited using "./input.csv", clear varnames(1) stringcols(_all)

capture confirm numeric variable group
if _rc {
    encode group, gen(group_id)
}
else {
    rename group group_id
}

capture confirm numeric variable y
if _rc {
    destring y, replace force
}

quietly count if !missing(y, group_id)
local n_obs = r(N)

quietly anova y group_id
local F_val    = e(F)
local df_num   = e(df_m)
local df_den   = e(df_r)
local p_val    = Ftail(`df_num', `df_den', `F_val')

display "ANSWER: F estimate=" %21.12f `F_val' " se=" %21.12f . " n_obs=" %12.0f `n_obs'
display "ANSWER: df_num estimate=" %21.12f `df_num' " se=" %21.12f . " n_obs=" %12.0f `n_obs'
display "ANSWER: df_den estimate=" %21.12f `df_den' " se=" %21.12f . " n_obs=" %12.0f `n_obs'
display "ANSWER: p_value estimate=" %21.12f `p_val' " se=" %21.12f . " n_obs=" %12.0f `n_obs'
