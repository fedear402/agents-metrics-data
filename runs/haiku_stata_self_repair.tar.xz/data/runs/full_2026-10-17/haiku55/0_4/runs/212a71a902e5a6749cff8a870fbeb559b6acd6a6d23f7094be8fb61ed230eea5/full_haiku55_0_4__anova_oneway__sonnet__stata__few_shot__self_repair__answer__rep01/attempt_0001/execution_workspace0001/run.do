clear all
set more off
set linesize 255

import delimited using "./input.csv", clear varnames(1) stringcols(_all)
capture destring group y, replace force
drop if missing(group) | missing(y)

quietly oneway y group
local F = r(F)
local dfn = r(df_m)
local dfd = r(df_r)
local p = Ftail(`dfn', `dfd', `F')
local n = _N

display "ANSWER: F estimate=" %21.12f `F' " se=. n_obs=" %12.0f `n'
display "ANSWER: df_num estimate=" %21.12f `dfn' " se=. n_obs=" %12.0f `n'
display "ANSWER: df_den estimate=" %21.12f `dfd' " se=. n_obs=" %12.0f `n'
display "ANSWER: p_value estimate=" %21.12f `p' " se=. n_obs=" %12.0f `n'
