clear all
set more off
set linesize 255

import delimited using "input.csv", clear varnames(1)

gen double x = score
keep if !missing(x, earnings, participated) & abs(x) < 1
gen double w = 1 - abs(x)
gen double right = (x >= 0)
gen double l1 = 1 - right
gen double r1 = right
gen double xL = x * l1
gen double xR = x * r1

count
scalar n_obs_all = r(N)

mata:
X = st_data(., ("l1", "r1", "xL", "xR"))
wt = st_data(., "w")
y1 = st_data(., "earnings")
y2 = st_data(., "participated")

A = invsym(cross(X, wt, X))
b1 = A * cross(X, wt, y1)
b2 = A * cross(X, wt, y2)
e1 = y1 - X * b1
e2 = y2 - X * b2

V1 = A * cross(X, wt:^2 :* e1:^2, X) * A
V2 = A * cross(X, wt:^2 :* e2:^2, X) * A
C12 = A * cross(X, wt:^2 :* e1 :* e2, X) * A

d = (-1 \ 1 \ 0 \ 0)
rf = d' * b1
fs = d' * b2
v_rf = d' * V1 * d
v_fs = d' * V2 * d
c_rf_fs = d' * C12 * d

te = rf / fs
g1 = 1 / fs
g2 = -rf / fs^2
v_te = g1^2 * v_rf + g2^2 * v_fs + 2 * g1 * g2 * c_rf_fs

st_numscalar("rf_est", rf)
st_numscalar("rf_se", sqrt(v_rf))
st_numscalar("fs_est", fs)
st_numscalar("fs_se", sqrt(v_fs))
st_numscalar("te_est", te)
st_numscalar("te_se", sqrt(v_te))
end

display "ANSWER: treatment_effect estimate=" %21.12f te_est " se=" %21.12f te_se " n_obs=" %12.0f n_obs_all
display "ANSWER: reduced_form estimate=" %21.12f rf_est " se=" %21.12f rf_se " n_obs=" %12.0f n_obs_all
display "ANSWER: first_stage estimate=" %21.12f fs_est " se=" %21.12f fs_se " n_obs=" %12.0f n_obs_all
