clear all
set more off

tempfile cw trd ar emp nat xz pop oc

import delimited using "crosswalk.csv", clear stringcols(_all)
replace code = strtrim(code)
replace industry = strtrim(industry)
keep code industry
duplicates drop
save `cw'

import delimited using "trade.csv", clear stringcols(_all)
replace code = strtrim(code)
destring period us_change other_change price_index years, replace
merge m:1 code using `cw', keep(match) nogen
keep period industry us_change other_change price_index years
save `trd'

import delimited using "areas.csv", clear stringcols(_all)
replace vintage = strtrim(vintage)
destring area period total_employment population, replace
keep area period vintage total_employment population
save `ar'

import delimited using "employment.csv", clear stringcols(_all)
replace vintage = strtrim(vintage)
replace industry = strtrim(industry)
destring area period employment, replace
replace employment = 0 if missing(employment)
keep area period vintage industry employment
save `emp'

import delimited using "outcomes.csv", clear stringcols(_all)
destring area period control change_pp, replace
keep area period control change_pp
save `oc'

use `emp', clear
collapse (sum) natl=employment, by(period vintage industry)
save `nat'

use `emp', clear
merge m:1 period industry using `trd', keep(match) nogen
merge m:1 area period vintage using `ar', keep(match) nogen
merge m:1 period vintage industry using `nat', keep(match) nogen

gen double share = employment / total_employment
gen double cx = cond(vintage == "base", share * (us_change / natl) / (price_index / 100) / 1000 * (10 / years), 0)
gen double cz = cond(vintage == "early", share * (other_change / natl) / (price_index / 100) / 1000 * (10 / years), 0)

collapse (sum) exposure=cx instrument=cz, by(area period)
save `xz'

use `ar', clear
keep if vintage == "base"
keep area period population
save `pop'

use `oc', clear
merge 1:1 area period using `xz', keep(master match) nogen
replace exposure = 0 if missing(exposure)
replace instrument = 0 if missing(instrument)
merge 1:1 area period using `pop', keep(match) nogen

ivregress 2sls change_pp period control (exposure = instrument) [pweight = population]

local n = e(N)
local b_iv = _b[exposure]

quietly summarize exposure if area == 0 & period == 0, meanonly
local e0 = r(mean)
quietly summarize exposure if area == 0 & period == 1, meanonly
local e1 = r(mean)
quietly summarize instrument if area == 0 & period == 0, meanonly
local z0 = r(mean)

display "ANSWER: iv_slope estimate=" trim(string(`b_iv', "%20.12g")) " se=NA n_obs=" `n'
display "ANSWER: exposure_area0_period0 estimate=" trim(string(`e0', "%20.12g")) " se=NA n_obs=" `n'
display "ANSWER: exposure_area0_period1 estimate=" trim(string(`e1', "%20.12g")) " se=NA n_obs=" `n'
display "ANSWER: instrument_area0_period0 estimate=" trim(string(`z0', "%20.12g")) " se=NA n_obs=" `n'
