clear all
set more off

import delimited using "census.csv", clear varnames(1)
summarize nonrecipient_population if eligible==0, meanonly
scalar N0 = r(mean)
summarize nonrecipient_population if eligible==1, meanonly
scalar N1 = r(mean)

import delimited using "households.csv", clear varnames(1)
keep if recipient==0

gen byte e0 = 1 - eligible
gen byte e1 = eligible
gen double d0 = dose*e0
gen double d1 = dose*e1
gen double b0 = baseline*e0
gen double b1 = baseline*e1
gen double z0 = instrument*e0
gen double z1 = instrument*e1

ivregress 2sls outcome e0 e1 b0 b1 (d0 d1 = z0 z1) [aweight=weight], noconstant

scalar nobs = e(N)
scalar s0 = _b[d0]
scalar s1 = _b[d1]

summarize dose [aweight=weight] if e(sample) & eligible==0
scalar m0 = r(mean)
summarize dose [aweight=weight] if e(sample) & eligible==1
scalar m1 = r(mean)

scalar eff0 = s0*m0
scalar eff1 = s1*m1
scalar popeff = (N0*eff0 + N1*eff1)/(N0 + N1)

display "ANSWER: ineligible_effect estimate=" trim(string(eff0, "%18.12f")) " se=NA n_obs=" trim(string(nobs, "%9.0f"))
display "ANSWER: eligible_nonrecipient_effect estimate=" trim(string(eff1, "%18.12f")) " se=NA n_obs=" trim(string(nobs, "%9.0f"))
display "ANSWER: population_effect estimate=" trim(string(popeff, "%18.12f")) " se=NA n_obs=" trim(string(nobs, "%9.0f"))
