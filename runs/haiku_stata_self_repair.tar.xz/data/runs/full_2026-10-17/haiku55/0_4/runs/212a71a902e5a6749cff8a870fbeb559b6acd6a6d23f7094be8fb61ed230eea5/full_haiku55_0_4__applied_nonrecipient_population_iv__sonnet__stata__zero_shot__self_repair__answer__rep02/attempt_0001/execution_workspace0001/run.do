clear all
set more off

import delimited using "households.csv", clear varnames(1)
keep if recipient==0

gen double d_ne = dose*(1-eligible)
gen double d_el = dose*eligible
gen double x_ne = 1-eligible
gen double x_el = eligible
gen double x_bne = baseline*(1-eligible)
gen double x_bel = baseline*eligible
gen double z_ne = instrument*(1-eligible)
gen double z_el = instrument*eligible

ivregress 2sls outcome x_ne x_el x_bne x_bel (d_ne d_el = z_ne z_el) [aweight=weight], noconstant

scalar n_obs = e(N)
scalar b_ne = _b[d_ne]
scalar b_el = _b[d_el]

summarize dose [aweight=weight] if e(sample) & eligible==0, meanonly
scalar m0 = r(mean)
summarize dose [aweight=weight] if e(sample) & eligible==1, meanonly
scalar m1 = r(mean)

scalar ineligible_effect = b_ne*m0
scalar eligible_nonrecipient_effect = b_el*m1

import delimited using "census.csv", clear varnames(1)
summarize nonrecipient_population if eligible==0, meanonly
scalar N0 = r(sum)
summarize nonrecipient_population if eligible==1, meanonly
scalar N1 = r(sum)

scalar population_effect = (N0*ineligible_effect + N1*eligible_nonrecipient_effect)/(N0+N1)

display "ANSWER: ineligible_effect estimate=" strtrim(string(ineligible_effect, "%24.12f")) " se=NA n_obs=" strtrim(string(n_obs, "%12.0f"))
display "ANSWER: eligible_nonrecipient_effect estimate=" strtrim(string(eligible_nonrecipient_effect, "%24.12f")) " se=NA n_obs=" strtrim(string(n_obs, "%12.0f"))
display "ANSWER: population_effect estimate=" strtrim(string(population_effect, "%24.12f")) " se=NA n_obs=" strtrim(string(n_obs, "%12.0f"))
