version 19.0
clear all
set more off
set linesize 255

import delimited using "input.csv", clear

gen double sxs = share*shock
bysort region_id: egen double z = total(sxs)
egen byte regtag = tag(region_id)

summarize region_weight if regtag, meanonly
scalar wsum = r(sum)
gen double e = region_weight/wsum

tempfile regions
preserve
keep if regtag
foreach v in y x z {
    gen double we_`v' = e*`v'
    summarize we_`v', meanonly
    local m_`v' = r(sum)
    gen double `v'0 = `v' - `m_`v''
}
keep region_id y0 x0 z0
save `regions'
restore

merge m:1 region_id using `regions', nogen

gen double num_eff = e*z0*y0*regtag
gen double den_eff = e*z0*x0*regtag
gen double num_fs  = e*z0*x0*regtag
gen double den_fs  = e*z0^2*regtag
summarize num_eff, meanonly
scalar sum_num_eff = r(sum)
summarize den_eff, meanonly
scalar sum_den_eff = r(sum)
summarize num_fs, meanonly
scalar sum_num_fs = r(sum)
summarize den_fs, meanonly
scalar sum_den_fs = r(sum)
scalar effect_est = sum_num_eff/sum_den_eff
scalar first_stage_est = sum_num_fs/sum_den_fs

gen double sh = share*e
gen double wy = share*e*y0
gen double wx = share*e*x0
gen double wz = share*e*z0
collapse (sum) s=sh wy wx wz (mean) shock, by(industry_id)

gen double ybar = wy/s
gen double xbar = wx/s
gen double zbar = wz/s

mata:
real rowvector iv_hc1(real colvector y, real colvector endo, real colvector inst, real colvector w)
{
    real scalar n
    real matrix R, Z, A, V, Sc
    real colvector beta, res
    n = rows(y)
    R = (J(n,1,1), endo)
    Z = (J(n,1,1), inst)
    A = luinv(Z'(w:*R))
    beta = A*Z'(w:*y)
    res = y - R*beta
    Sc = Z:*(w:*res)
    V = n/(n-2)*A*(Sc'*Sc)*A'
    return((beta[2], sqrt(V[2,2])))
}

Y = st_data(., "ybar")
X = st_data(., "xbar")
Zb = st_data(., "zbar")
I = st_data(., "shock")
S = st_data(., "s")

eff = iv_hc1(Y, X, I, S)
fs = iv_hc1(X, Zb, I, S)

st_numscalar("effect_se", eff[2])
st_numscalar("first_stage_se", fs[2])
st_numscalar("n_ind", rows(S))
st_numscalar("eff_shocks", 1/sum(S:^2))
end

display "ANSWER: effect estimate=" %21.12f effect_est " se=" %21.12f effect_se " n_obs=" %12.0f n_ind
display "ANSWER: first_stage estimate=" %21.12f first_stage_est " se=" %21.12f first_stage_se " n_obs=" %12.0f n_ind
display "ANSWER: effective_shocks estimate=" %21.12f eff_shocks " se=" %21.12f . " n_obs=" %12.0f n_ind
