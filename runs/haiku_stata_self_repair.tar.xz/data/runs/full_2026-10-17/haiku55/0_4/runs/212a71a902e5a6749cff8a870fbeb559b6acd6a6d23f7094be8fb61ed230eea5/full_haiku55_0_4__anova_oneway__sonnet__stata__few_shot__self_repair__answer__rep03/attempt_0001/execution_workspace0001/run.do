clear
set linesize 255
import delimited using "./input.csv", clear varnames(1)
quietly oneway y group
local F = r(F)
local dfn = r(df_m)
local dfd = r(df_r)
local p = Ftail(`dfn', `dfd', `F')
local Fs = string(`F', "%21.12f")
local dfns = string(`dfn', "%21.12f")
local dfds = string(`dfd', "%21.12f")
local ps = string(`p', "%21.12f")
local n = _N
local ns = string(`n', "%12.0f")
display "ANSWER: F estimate=`Fs' se=. n_obs=`ns'"
display "ANSWER: df_num estimate=`dfns' se=. n_obs=`ns'"
display "ANSWER: df_den estimate=`dfds' se=. n_obs=`ns'"
display "ANSWER: p_value estimate=`ps' se=. n_obs=`ns'"
