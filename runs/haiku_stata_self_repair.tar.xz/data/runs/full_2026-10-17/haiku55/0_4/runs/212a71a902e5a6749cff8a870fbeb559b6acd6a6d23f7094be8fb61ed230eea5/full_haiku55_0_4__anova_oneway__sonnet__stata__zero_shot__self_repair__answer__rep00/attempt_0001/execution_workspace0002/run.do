clear all
set more off
set linesize 255

import delimited using "./input.csv", clear varnames(1)

capture confirm numeric variable group
if _rc {
    encode group, gen(group_num)
    local grpvar group_num
}
else {
    local grpvar group
}

quietly count
local n_obs = r(N)

quietly oneway y `grpvar'
local F_val  = r(F)
local df_num = r(df_m)
local df_den = r(df_r)
local p_val  = r(p)

display "ANSWER: F estimate=" %21.12f `F_val' " se=" "." " n_obs=" %12.0f `n_obs'
display "ANSWER: df_num estimate=" %21.12f `df_num' " se=" "." " n_obs=" %12.0f `n_obs'
display "ANSWER: df_den estimate=" %21.12f `df_den' " se=" "." " n_obs=" %12.0f `n_obs'
display "ANSWER: p_value estimate=" %21.12f `p_val' " se=" "." " n_obs=" %12.0f `n_obs'
