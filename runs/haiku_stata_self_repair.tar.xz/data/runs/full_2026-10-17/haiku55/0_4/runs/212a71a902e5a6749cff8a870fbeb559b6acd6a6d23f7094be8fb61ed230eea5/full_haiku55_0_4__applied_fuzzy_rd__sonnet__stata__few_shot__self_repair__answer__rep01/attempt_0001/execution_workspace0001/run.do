version 19.0
clear all
set more off
set linesize 255

import delimited using "input.csv", clear varnames(1)

gen double h = abs(score)
keep if h < 1
gen double w = 1 - h
gen double right = (score >= 0)
gen double left = 1 - right

* Local-linear fit with separate slopes and intercepts on each side
gen double rs = right*score
gen double ls = left*score

mata:
st_view(S=., ., ("score","right","left","rs","ls"))
w_all = st_data(., "w")
Y_earn = st_data(., "earnings")
Y_part = st_data(., "participated")
n = rows(S)

X = (S[.,2], S[.,3], S[.,4], S[.,5])
// columns: right intercept, left intercept, right slope, left slope
bread = invsym(X' * (w_all :* X))
b_earn = bread * X' * (w_all :* Y_earn)
b_part = bread * X' * (w_all :* Y_part)
e_earn = Y_earn - X * b_earn
e_part = Y_part - X * b_part

// Discontinuity = right intercept - left intercept
c = (1 \ -1 \ 0 \ 0)
rf = c' * b_earn
fs = c' * b_part
tr = rf / fs

// Influence contributions: each row contributes w * (X*bread*c) * residual
load_e = w_all :* (X * bread * c)
load_p = w_all :* (X * bread * c)
infl_e = load_e :* e_earn
infl_p = load_p :* e_part
V = (infl_e, infl_p)' * (infl_e, infl_p)

se_rf = sqrt(V[1,1])
se_fs = sqrt(V[2,2])
grad = (1/fs \ -rf/fs^2)
se_tr = sqrt(grad' * V * grad)

nobs = n
st_numscalar("rf", rf)
st_numscalar("fs", fs)
st_numscalar("tr", tr)
st_numscalar("se_rf", se_rf)
st_numscalar("se_fs", se_fs)
st_numscalar("se_tr", se_tr)
st_numscalar("nobs", nobs)
end

display "ANSWER: treatment_effect estimate=" %21.12f tr " se=" %21.12f se_tr " n_obs=" %12.0f nobs
display "ANSWER: reduced_form estimate=" %21.12f rf " se=" %21.12f se_rf " n_obs=" %12.0f nobs
display "ANSWER: first_stage estimate=" %21.12f fs " se=" %21.12f se_fs " n_obs=" %12.0f nobs
