clear all
set more off

import delimited using "crosswalk.csv", clear varnames(1)
keep code industry
duplicates drop code, force
tempfile cw
save `cw'

duplicates drop industry, force
keep industry
gen byte one = 1
tempfile ind
save `ind'

import delimited using "trade.csv", clear varnames(1)
merge m:1 code using `cw', keep(match) nogen
keep period industry us_change other_change price_index years
duplicates drop period industry, force
tempfile tr
save `tr'

import delimited using "employment.csv", clear varnames(1)
collapse (sum) employment, by(area period vintage industry)
tempfile emp
save `emp'

import delimited using "areas.csv", clear varnames(1)
preserve
keep if vintage == "base"
keep area period population
tempfile pop
save `pop'
restore
keep area period vintage total_employment
gen byte one = 1
joinby one using `ind'
drop one
merge 1:1 area period vintage industry using `emp', keep(master match) nogen
replace employment = 0 if missing(employment)
merge m:1 period industry using `tr', keep(match master) nogen

egen double natl = total(employment), by(period vintage industry)
gen double share = employment/total_employment
gen double tx = share*us_change/natl/(price_index/100)/1000*(10/years) if vintage == "base"
gen double tz = share*other_change/natl/(price_index/100)/1000*(10/years) if vintage == "early"
collapse (sum) tx tz, by(area period)
rename tx x
rename tz z

merge 1:1 area period using `pop', keep(match) nogen

import delimited using "outcomes.csv", clear varnames(1)
tempfile out
save `out'
clear
use `out'
keep area period control change_pp
tempfile out2
save `out2'

clear
import delimited using "areas.csv", clear varnames(1)
keep if vintage == "base"
keep area period population
tempfile pop2
save `pop2'

ivregress 2sls change_pp period control (x = z) [aw=population]
local n = e(N)
scalar b_iv = _b[x]

quietly summarize x if area == 0 & period == 0, meanonly
scalar x00 = r(mean)
quietly summarize x if area == 0 & period == 1, meanonly
scalar x01 = r(mean)
quietly summarize z if area == 0 & period == 0, meanonly
scalar z00 = r(mean)

display "ANSWER: iv_slope estimate=" strtrim(string(b_iv, "%24.16g")) " se=NA n_obs=" `n'
display "ANSWER: exposure_area0_period0 estimate=" strtrim(string(x00, "%24.16g")) " se=NA n_obs=" `n'
display "ANSWER: exposure_area0_period1 estimate=" strtrim(string(x01, "%24.16g")) " se=NA n_obs=" `n'
display "ANSWER: instrument_area0_period0 estimate=" strtrim(string(z00, "%24.16g")) " se=NA n_obs=" `n'
