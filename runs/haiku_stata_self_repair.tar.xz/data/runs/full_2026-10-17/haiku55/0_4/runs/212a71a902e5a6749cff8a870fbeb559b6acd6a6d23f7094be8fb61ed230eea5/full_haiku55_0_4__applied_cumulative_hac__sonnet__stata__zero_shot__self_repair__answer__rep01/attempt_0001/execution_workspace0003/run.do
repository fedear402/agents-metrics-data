clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

capture confirm string variable date
if _rc == 0 {
    gen double tdate = date(date, "YMD")
}
else {
    gen double tdate = date
}
sort tdate

gen long obs = _n
tsset obs

gen double lnsales = ln(sales)
gen double lnvix = ln(vix)
gen double dlnvix = lnvix - L.lnvix

forvalues j = 1/15 {
    gen double L`j'_dv = L`j'.dlnvix
}

gen byte touse = !missing(lnsales)
forvalues j = 1/15 {
    replace touse = 0 if missing(L`j'_dv)
}

quietly count if touse
scalar Nsamp = r(N)

quietly newey lnsales L1_dv-L15_dv if touse, lag(15)

scalar n_obs = e(N)
scalar scale_fac = e(N)/(e(N)-16)
matrix b = e(b)
matrix V = e(V)*scale_fac

matrix c = J(16,1,1)
matrix c[16,1] = 0
matrix cb = b*c
matrix cv = c'*V*c
scalar cum_est = cb[1,1]
scalar cum_se = sqrt(cv[1,1])

scalar lag1_est = b[1,1]
scalar lag1_se = sqrt(V[1,1])

scalar lag15_est = b[1,15]
scalar lag15_se = sqrt(V[15,15])

display "ANSWER: cumulative_response estimate=" %21.12f cum_est " se=" %21.12f cum_se " n_obs=" %12.0f n_obs
display "ANSWER: lag_1 estimate=" %21.12f lag1_est " se=" %21.12f lag1_se " n_obs=" %12.0f n_obs
display "ANSWER: lag_15 estimate=" %21.12f lag15_est " se=" %21.12f lag15_se " n_obs=" %12.0f n_obs
