clear all
set more off
set linesize 255

import delimited using "input.csv", clear varnames(1)

keep if abs(score) < 1
gen double w = 1 - abs(score)
scalar nobs = _N

mata:
real rowvector sidecalc(real colvector s, real colvector y, real colvector d, real colvector w)
{
    real matrix X, Ai, MYY, MDD, MYD
    real colvector by, bd, ey, ed, wt
    X = (J(rows(s), 1, 1), s)
    Ai = invsym(cross(X, w, X))
    by = Ai * cross(X, w, y)
    bd = Ai * cross(X, w, d)
    ey = y - X * by
    ed = d - X * bd
    wt = w:^2
    MYY = cross(X, wt:*(ey:^2), X)
    MDD = cross(X, wt:*(ed:^2), X)
    MYD = cross(X, wt:*ey:*ed, X)
    return((by[1], bd[1], (Ai*MYY*Ai)[1,1], (Ai*MDD*Ai)[1,1], (Ai*MYD*Ai)[1,1]))
}

real colvector s, y, d, w, iR, iL
real rowvector R, L
real scalar rf, fs, vrf, vfs, cv, theta, vth, g1, g2

s = st_data(., "score")
y = st_data(., "earnings")
d = st_data(., "participated")
w = st_data(., "w")

iR = selectindex(s :>= 0)
iL = selectindex(s :< 0)

R = sidecalc(s[iR], y[iR], d[iR], w[iR])
L = sidecalc(s[iL], y[iL], d[iL], w[iL])

rf  = R[1] - L[1]
fs  = R[2] - L[2]
vrf = R[3] + L[3]
vfs = R[4] + L[4]
cv  = R[5] + L[5]

theta = rf / fs
g1 = 1 / fs
g2 = -rf / fs^2
vth = g1^2*vrf + g2^2*vfs + 2*g1*g2*cv

st_numscalar("rf", rf)
st_numscalar("se_rf", sqrt(vrf))
st_numscalar("fs", fs)
st_numscalar("se_fs", sqrt(vfs))
st_numscalar("te", theta)
st_numscalar("se_te", sqrt(vth))
end

display "ANSWER: treatment_effect estimate=" %21.12f te " se=" %21.12f se_te " n_obs=" %12.0f nobs
display "ANSWER: reduced_form estimate=" %21.12f rf " se=" %21.12f se_rf " n_obs=" %12.0f nobs
display "ANSWER: first_stage estimate=" %21.12f fs " se=" %21.12f se_fs " n_obs=" %12.0f nobs
