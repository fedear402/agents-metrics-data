clear all
set more off
set linesize 255

import delimited using "input.csv", clear

bysort region_id: gen byte first_r = (_n == 1)
bysort region_id: egen double z_r = total(share*shock)
gen double rw = region_weight*first_r
egen double wsum = total(rw)
gen double e = region_weight/wsum
gen double ey = e*y*first_r
gen double ex = e*x*first_r
gen double ez = e*z_r*first_r
egen double my = total(ey)
egen double mx = total(ex)
egen double mz = total(ez)
gen double y0 = y - my
gen double x0 = x - mx
gen double z0 = z_r - mz

preserve
keep if first_r
ivregress 2sls y (x = z_r) [aweight=e]
scalar eff_b = _b[x]
regress x z_r [aweight=e]
scalar fs_b = _b[z_r]
restore

gen double sh_e = e*share
bysort industry_id: egen double s_n = total(sh_e)
gen double yv = sh_e*y0
gen double xv = sh_e*x0
gen double zv = sh_e*z0
bysort industry_id: egen double ysum = total(yv)
bysort industry_id: egen double xsum = total(xv)
bysort industry_id: egen double zsum = total(zv)
gen double ybar = ysum/s_n
gen double xbar = xsum/s_n
gen double zbar = zsum/s_n

bysort industry_id: gen byte first_n = (_n == 1)
keep if first_n
gen double s2 = s_n^2
summarize s2, meanonly
scalar esh = 1/r(sum)
count
scalar Nind = r(N)

mata:
void iv_hc1(string scalar yn, string scalar xn, string scalar zn, string scalar wn, string scalar pre)
{
    real colvector y, x, z, s, u, b
    real matrix X, Z, A, M, Ai, V
    real scalar N

    y = st_data(., yn)
    x = st_data(., xn)
    z = st_data(., zn)
    s = st_data(., wn)
    N = rows(y)
    X = (J(N, 1, 1), x)
    Z = (J(N, 1, 1), z)
    A = cross(Z, s, X)
    Ai = luinv(A)
    b = Ai*cross(Z, s, y)
    u = y - X*b
    M = cross(Z, s:^2 :* u:^2, Z)
    V = Ai*M*Ai' * N/(N-2)
    st_numscalar(pre+"_b", b[2])
    st_numscalar(pre+"_se", sqrt(V[2,2]))
}
end

mata: iv_hc1("ybar", "xbar", "shock", "s_n", "eff")
mata: iv_hc1("xbar", "zbar", "shock", "s_n", "fs")

display "ANSWER: effect estimate=" %21.12f eff_b " se=" %21.12f eff_se " n_obs=" %12.0f Nind
display "ANSWER: first_stage estimate=" %21.12f fs_b " se=" %21.12f fs_se " n_obs=" %12.0f Nind
display "ANSWER: effective_shocks estimate=" %21.12f esh " se=. n_obs=" %12.0f Nind
