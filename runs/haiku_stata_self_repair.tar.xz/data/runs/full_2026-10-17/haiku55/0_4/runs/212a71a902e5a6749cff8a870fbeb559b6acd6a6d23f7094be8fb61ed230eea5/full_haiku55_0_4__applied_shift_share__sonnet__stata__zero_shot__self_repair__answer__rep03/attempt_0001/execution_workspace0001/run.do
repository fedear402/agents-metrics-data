clear all
set more off
set linesize 255

import delimited using "input.csv", clear

egen byte rtag = tag(region_id)
gen double rw = region_weight*rtag
egen double wsum = total(rw)
gen double ew = region_weight/wsum

gen double zi = share*shock
bysort region_id: egen double z = total(zi)

egen double ym = total(rtag*ew*y)
egen double xm = total(rtag*ew*x)
egen double zm = total(rtag*ew*z)
gen double y0 = y - ym
gen double x0 = x - xm
gen double z0 = z - zm

preserve
keep if rtag
ivregress 2sls y (x = z) [aw=ew]
scalar eff_est = _b[x]
regress x z [aw=ew]
scalar fs_est = _b[z]
restore

gen double es = ew*share
bysort industry_id: egen double sn = total(es)

gen double esy = es*y0
gen double esx = es*x0
gen double esz = es*z0
bysort industry_id: egen double tot_y = total(esy)
bysort industry_id: egen double tot_x = total(esx)
bysort industry_id: egen double tot_z = total(esz)

gen double ybar = tot_y/sn
gen double xbar = tot_x/sn
gen double zbar = tot_z/sn

bysort industry_id: keep if _n==1

scalar nind = _N

gen double sn2 = sn^2
summarize sn2, meanonly
scalar eff_shock = 1/r(sum)

mata:
real rowvector ivs(real colvector y, real colvector x, real colvector z, real colvector w)
{
    real scalar n
    real matrix X, Z, Ai, M, V
    real colvector b, u
    n = rows(y)
    X = (J(n,1,1), x)
    Z = (J(n,1,1), z)
    Ai = luinv(Z'*diag(w)*X)
    b = Ai*(Z'*(w:*y))
    u = y - X*b
    M = Z'*diag(w:^2:*u:^2)*Z
    V = (n/(n-2))*Ai*M*Ai'
    return((b[2], sqrt(V[2,2])))
}

real rowvector r1, r2
r1 = ivs(st_data(.,"ybar"), st_data(.,"xbar"), st_data(.,"shock"), st_data(.,"sn"))
r2 = ivs(st_data(.,"xbar"), st_data(.,"zbar"), st_data(.,"shock"), st_data(.,"sn"))
st_numscalar("eff_se", r1[2])
st_numscalar("fs_se", r2[2])
end

display "ANSWER: effect estimate=" %21.12f eff_est " se=" %21.12f eff_se " n_obs=" %12.0f nind
display "ANSWER: first_stage estimate=" %21.12f fs_est " se=" %21.12f fs_se " n_obs=" %12.0f nind
display "ANSWER: effective_shocks estimate=" %21.12f eff_shock " se=." " n_obs=" %12.0f nind
