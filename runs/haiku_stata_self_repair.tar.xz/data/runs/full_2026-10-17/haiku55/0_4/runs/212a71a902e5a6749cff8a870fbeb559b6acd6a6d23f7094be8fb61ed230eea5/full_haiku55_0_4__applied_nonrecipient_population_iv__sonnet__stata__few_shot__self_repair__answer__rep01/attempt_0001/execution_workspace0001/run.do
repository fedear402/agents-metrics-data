clear all
set more off

import delimited using "census.csv", clear varnames(1)
summarize nonrecipient_population if eligible==0, meanonly
scalar n0 = r(mean)
summarize nonrecipient_population if eligible==1, meanonly
scalar n1 = r(mean)

import delimited using "households.csv", clear varnames(1)
keep if recipient==0

gen double ineligible = 1-eligible
gen double dose_inel = dose*ineligible
gen double dose_el = dose*eligible
gen double base_inel = baseline*ineligible
gen double base_el = baseline*eligible
gen double inst_inel = instrument*ineligible
gen double inst_el = instrument*eligible

ivregress 2sls outcome ineligible eligible base_inel base_el (dose_inel dose_el = inst_inel inst_el) [aw=weight], noconstant
scalar nobs = e(N)
scalar slope0 = _b[dose_inel]
scalar slope1 = _b[dose_el]

summarize dose [aw=weight] if eligible==0, meanonly
scalar e0 = slope0*r(mean)
summarize dose [aw=weight] if eligible==1, meanonly
scalar e1 = slope1*r(mean)

scalar pop_effect = (e0*n0 + e1*n1)/(n0 + n1)

display "ANSWER: ineligible_effect estimate=" trim(string(e0,"%24.16g")) " se=NA n_obs=" trim(string(nobs,"%12.0f"))
display "ANSWER: eligible_nonrecipient_effect estimate=" trim(string(e1,"%24.16g")) " se=NA n_obs=" trim(string(nobs,"%12.0f"))
display "ANSWER: population_effect estimate=" trim(string(pop_effect,"%24.16g")) " se=NA n_obs=" trim(string(nobs,"%12.0f"))
