version 19.0
clear all
set more off
set linesize 255

import delimited using "input.csv", clear varnames(1)

* Normalize regional weights once, one observation per region
egen double rtag = tag(region_id)
egen double wsum_all = total(region_weight * rtag)
gen double e = region_weight / wsum_all

* Regional variables (constant within region)
bysort region_id: egen double x_r = mean(x)
bysort region_id: egen double y_r = mean(y)
bysort region_id: egen double z_r = total(share * shock)
replace z_r = . if rtag != 1

* Weighted means over regions (one obs per region used)
quietly summarize y_r [aw=e] if rtag == 1, meanonly
scalar ybar_all = r(mean)
quietly summarize x_r [aw=e] if rtag == 1, meanonly
scalar xbar_all = r(mean)
quietly summarize z_r [aw=e] if rtag == 1, meanonly
scalar zbar_all = r(mean)

gen double y0 = y_r - ybar_all if rtag == 1
gen double x0 = x_r - xbar_all if rtag == 1
gen double z0 = z_r - zbar_all if rtag == 1

* Industry-level shift-share aggregation
bysort industry_id: egen double s_n = total(e * share) 
* s_n must be computed over regions, not rows
drop s_n
gen double esh = e * share

foreach v in y0 x0 z0 {
    gen double esh_`v' = esh * `v' if rtag == 1
    bysort industry_id: egen double tot_`v' = total(esh_`v')
}
bysort industry_id: egen double s_n = total(esh)
foreach v in y0 x0 z0 {
    gen double vbar_`v' = tot_`v' / s_n
}

* One row per industry
egen double itag = tag(industry_id)
keep if itag == 1
keep industry_id shock s_n vbar_y0 vbar_x0 vbar_z0
sort industry_id
count
scalar N = r(N)

* Effect: shock-level IV of ybar on xbar, instrumenting with shock, weighted by s_n
gen double ybar_n = vbar_y0
gen double xbar_n = vbar_x0
gen double zbar_n = vbar_z0

ivregress 2sls ybar_n (xbar_n = shock) [aw=s_n], vce(robust)
scalar b_eff = _b[xbar_n]
scalar se_eff = _se[xbar_n] * sqrt(N/(N-2))

* First stage: shock-level IV of xbar on zbar, instrumenting with shock, weighted by s_n
ivregress 2sls xbar_n (zbar_n = shock) [aw=s_n], vce(robust)
scalar b_fs = _b[zbar_n]
scalar se_fs = _se[zbar_n] * sqrt(N/(N-2))

* Effective shocks
quietly summarize s_n
gen double s_n_sq = s_n^2
quietly summarize s_n_sq, meanonly
scalar eff_shocks = 1 / r(sum)

display "ANSWER: effect estimate=" %21.12f b_eff " se=" %21.12f se_eff " n_obs=" %12.0f N
display "ANSWER: first_stage estimate=" %21.12f b_fs " se=" %21.12f se_fs " n_obs=" %12.0f N
display "ANSWER: effective_shocks estimate=" %21.12f eff_shocks " se=" %21.12f . " n_obs=" %12.0f N
