clear all
set more off

import delimited using "households.csv", clear varnames(1)
keep if recipient == 0

generate d1 = dose*(1-eligible)
generate d2 = dose*eligible
generate x1 = 1-eligible
generate x2 = eligible
generate x3 = baseline*(1-eligible)
generate x4 = baseline*eligible
generate z5 = instrument*(1-eligible)
generate z6 = instrument*eligible

ivregress 2sls outcome x1 x2 x3 x4 (d1 d2 = z5 z6) [aweight=weight], noconstant

scalar b_d1 = _b[d1]
scalar b_d2 = _b[d2]
scalar n_obs = e(N)

summarize dose [aweight=weight] if e(sample) & eligible==0, meanonly
scalar mdose0 = r(mean)
summarize dose [aweight=weight] if e(sample) & eligible==1, meanonly
scalar mdose1 = r(mean)

scalar eff0 = b_d1*mdose0
scalar eff1 = b_d2*mdose1

preserve
import delimited using "census.csv", clear varnames(1)
summarize nonrecipient_population if eligible==0, meanonly
scalar N0 = r(mean)
summarize nonrecipient_population if eligible==1, meanonly
scalar N1 = r(mean)
restore

scalar pop_eff = (N0*eff0 + N1*eff1)/(N0+N1)

display "ANSWER: ineligible_effect estimate=" trim(string(eff0,"%20.12f")) " se=NA n_obs=" trim(string(n_obs,"%12.0f"))
display "ANSWER: eligible_nonrecipient_effect estimate=" trim(string(eff1,"%20.12f")) " se=NA n_obs=" trim(string(n_obs,"%12.0f"))
display "ANSWER: population_effect estimate=" trim(string(pop_eff,"%20.12f")) " se=NA n_obs=" trim(string(n_obs,"%12.0f"))
