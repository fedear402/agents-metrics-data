clear all
set more off
set type double

import delimited using "households.csv", clear varnames(1)
keep if recipient==0

gen byte nonelig = 1-eligible
gen double dose_ni = dose*nonelig
gen double dose_e = dose*eligible
gen double base_ni = baseline*nonelig
gen double base_e = baseline*eligible
gen double inst_ni = instrument*nonelig
gen double inst_e = instrument*eligible

ivregress 2sls outcome nonelig eligible base_ni base_e (dose_ni dose_e = inst_ni inst_e) [aw=weight], noconstant
local n = e(N)

scalar b0 = _b[dose_ni]
scalar b1 = _b[dose_e]

summarize dose [aw=weight] if eligible==0, meanonly
scalar e0 = b0*r(mean)
summarize dose [aw=weight] if eligible==1, meanonly
scalar e1 = b1*r(mean)

import delimited using "census.csv", clear varnames(1)
summarize nonrecipient_population if eligible==0, meanonly
scalar n0 = r(mean)
summarize nonrecipient_population if eligible==1, meanonly
scalar n1 = r(mean)

scalar pop = (e0*n0 + e1*n1)/(n0 + n1)

display "ANSWER: ineligible_effect estimate=" strtrim(string(e0,"%24.16g")) " se=NA n_obs=`n'"
display "ANSWER: eligible_nonrecipient_effect estimate=" strtrim(string(e1,"%24.16g")) " se=NA n_obs=`n'"
display "ANSWER: population_effect estimate=" strtrim(string(pop,"%24.16g")) " se=NA n_obs=`n'"

exit, clear
