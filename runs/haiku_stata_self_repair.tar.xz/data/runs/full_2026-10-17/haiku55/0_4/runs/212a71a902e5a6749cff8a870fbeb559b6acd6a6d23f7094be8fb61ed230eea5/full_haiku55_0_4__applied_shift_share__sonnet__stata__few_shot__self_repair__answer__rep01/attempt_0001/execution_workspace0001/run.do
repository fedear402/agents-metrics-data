version 19.0
clear all
set more off
set linesize 255

import delimited using "input.csv", clear varnames(1)

mata:
real matrix ivfit(real colvector yv, real colvector endo, real colvector shk, real colvector s)
{
    real scalar N
    real matrix W, Zi, Ai, M, V
    real colvector beta, u

    N = rows(yv)
    W = (J(N,1,1), endo)
    Zi = (J(N,1,1), shk)
    Ai = luinv(Zi' * (s:*W))
    beta = Ai * (Zi' * (s:*yv))
    u = yv - W * beta
    M = Zi:*(s:*u)
    V = N/(N-2) * Ai * (M'M) * Ai'
    return((beta[2], sqrt(V[2,2])))
}

d = st_data(., ("region_id","industry_id","share","shock","region_weight","x","y"))
rid = d[,1]; iid = d[,2]; sh = d[,3]; sk = d[,4]; rw = d[,5]; xx = d[,6]; yy = d[,7]

R = uniqrows(rid)
I = uniqrows(iid)
nR = rows(R); nI = rows(I)

e = J(nR,1,.); Y = J(nR,1,.); X = J(nR,1,.); Zr = J(nR,1,.)
S = J(nR,nI,0); shk = J(nI,1,.)

for (k=1; k<=rows(d); k++) {
    i = selectindex(R :== rid[k])
    j = selectindex(I :== iid[k])
    S[i,j] = sh[k]
    shk[j] = sk[k]
}

for (i=1; i<=nR; i++) {
    idx = selectindex(rid :== R[i])
    e[i] = rw[idx[1]]
    Y[i] = yy[idx[1]]
    X[i] = xx[idx[1]]
    Zr[i] = sum(sh[idx]:*sk[idx])
}
e = e / sum(e)

y0 = Y - sum(e:*Y)
x0 = X - sum(e:*X)
z0 = Zr - sum(e:*Zr)

s = S' * e
ybar = (S' * (e:*y0)) :/ s
xbar = (S' * (e:*x0)) :/ s
zbar = (S' * (e:*z0)) :/ s

b_eff = ivfit(ybar, xbar, shk, s)
b_fs = ivfit(xbar, zbar, shk, s)
eff_shocks = 1/sum(s:^2)

st_numscalar("eff_est", b_eff[1])
st_numscalar("eff_se", b_eff[2])
st_numscalar("fs_est", b_fs[1])
st_numscalar("fs_se", b_fs[2])
st_numscalar("es_est", eff_shocks)
st_numscalar("n_ind", nI)
end

scalar n_obs = n_ind

display "ANSWER: effect estimate=" %21.12f eff_est " se=" %21.12f eff_se " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f fs_est " se=" %21.12f fs_se " n_obs=" %12.0f n_obs
display "ANSWER: effective_shocks estimate=" %21.12f es_est " se=" %21.12f . " n_obs=" %12.0f n_obs
