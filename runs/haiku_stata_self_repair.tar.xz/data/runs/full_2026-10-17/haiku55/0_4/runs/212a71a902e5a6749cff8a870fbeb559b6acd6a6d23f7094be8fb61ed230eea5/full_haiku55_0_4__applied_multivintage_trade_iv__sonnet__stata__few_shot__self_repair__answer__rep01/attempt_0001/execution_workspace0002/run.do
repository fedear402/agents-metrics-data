clear all
set more off

import delimited using "crosswalk.csv", clear stringcols(_all)
foreach v of varlist code industry {
    replace `v' = strtrim(`v')
}
duplicates drop code, force
keep code industry
tempfile xw
save `xw'

import delimited using "trade.csv", clear stringcols(_all)
replace code = strtrim(code)
destring period us_change other_change price_index years, replace
merge m:1 code using `xw', keep(match) nogen
keep period industry us_change other_change price_index years
duplicates drop period industry, force
tempfile trd
save `trd'

import delimited using "areas.csv", clear stringcols(_all)
foreach v of varlist area period vintage {
    replace `v' = strtrim(`v')
}
destring area period total_employment population, replace
keep area period vintage total_employment population
tempfile ar
save `ar'

import delimited using "outcomes.csv", clear stringcols(_all)
foreach v of varlist area period {
    replace `v' = strtrim(`v')
}
destring area period control change_pp, replace
keep area period control change_pp
tempfile out
save `out'

import delimited using "employment.csv", clear stringcols(_all)
foreach v of varlist area period vintage industry {
    replace `v' = strtrim(`v')
}
destring area period employment, replace
collapse (sum) employment, by(area period vintage industry)
tempfile emp
save `emp'

use `xw', clear
levelsof industry, local(inds)
local ni : word count `inds'

use `ar', clear
expand `ni'
bysort area period vintage: gen byte k = _n
gen str industry = ""
local j 0
foreach i of local inds {
    local ++j
    replace industry = "`i'" if k == `j'
}
drop k

merge 1:1 area period vintage industry using `emp', keep(master match) nogen
replace employment = 0 if missing(employment)
merge m:1 period industry using `trd', keep(match) nogen

bysort period vintage industry: egen double nat = total(employment)

gen double xterm = (employment/total_employment)*(us_change/nat)/(price_index/100)/1000*(10/years) if vintage == "base"
gen double zterm = (employment/total_employment)*(other_change/nat)/(price_index/100)/1000*(10/years) if vintage == "early"

bysort area period: egen double x = total(xterm)
bysort area period: egen double z = total(zterm)
keep if vintage == "base"
sort area period industry
bysort area period: keep if _n == 1

merge 1:1 area period using `out', keep(match) nogen

ivregress 2sls change_pp period control (x = z) [aw=population]
local n = e(N)
scalar b_iv = _b[x]

summarize x if area == 0 & period == 0, meanonly
scalar x00 = r(mean)
summarize x if area == 0 & period == 1, meanonly
scalar x01 = r(mean)
summarize z if area == 0 & period == 0, meanonly
scalar z00 = r(mean)

display "ANSWER: iv_slope estimate=" strtrim(string(b_iv, "%24.16g")) " se=NA n_obs=" `n'
display "ANSWER: exposure_area0_period0 estimate=" strtrim(string(x00, "%24.16g")) " se=NA n_obs=" `n'
display "ANSWER: exposure_area0_period1 estimate=" strtrim(string(x01, "%24.16g")) " se=NA n_obs=" `n'
display "ANSWER: instrument_area0_period0 estimate=" strtrim(string(z00, "%24.16g")) " se=NA n_obs=" `n'
