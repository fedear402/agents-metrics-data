clear all
set linesize 255

import delimited using "./input.csv", clear varnames(1)

capture confirm string variable group
if _rc == 0 {
    encode group, gen(grp)
}
else {
    gen grp = group
}

anova y grp

scalar F_stat = e(F)
scalar df_num_val = e(df_m)
scalar df_den_val = e(df_r)
scalar p_val = Ftail(df_num_val, df_den_val, F_stat)
local n_obs = e(N)

display "ANSWER: F estimate=" %21.12f F_stat " se=. n_obs=" %12.0f `n_obs'
display "ANSWER: df_num estimate=" %21.12f df_num_val " se=. n_obs=" %12.0f `n_obs'
display "ANSWER: df_den estimate=" %21.12f df_den_val " se=. n_obs=" %12.0f `n_obs'
display "ANSWER: p_value estimate=" %21.12f p_val " se=. n_obs=" %12.0f `n_obs'
