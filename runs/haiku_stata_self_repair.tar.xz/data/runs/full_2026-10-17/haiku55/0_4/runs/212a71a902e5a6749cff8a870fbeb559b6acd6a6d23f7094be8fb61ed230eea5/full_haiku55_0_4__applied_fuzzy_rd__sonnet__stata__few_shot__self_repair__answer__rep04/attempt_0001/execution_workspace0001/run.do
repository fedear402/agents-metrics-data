version 19.0
clear all
set more off
set linesize 255

import delimited "input.csv", clear
keep if abs(score) < 1
gen double w = 1 - abs(score)
gen double R = (score >= 0)
gen double L = 1 - R
gen double Ls = L*score
gen double Rs = R*score
count
scalar n_in = r(N)

mata:
X = st_data(., ("L", "Ls", "R", "Rs"))
Y = st_data(., ("earnings", "participated"))
w = st_data(., "w")
B = invsym(X'*(w:*X))
b = B*X'*(w:*Y)
E = Y - X*b
c = (-1 \ 0 \ 1 \ 0)
h = X*B*c
U = (w:*h):*E
V = U'*U
jump = c'*b
r = jump[1]
f = jump[2]
g = (1/f \ -r/f^2)
st_numscalar("rf_est", r)
st_numscalar("rf_se", sqrt(V[1,1]))
st_numscalar("fs_est", f)
st_numscalar("fs_se", sqrt(V[2,2]))
st_numscalar("te_est", r/f)
st_numscalar("te_se", sqrt(g'*V*g))
end

display "ANSWER: treatment_effect estimate=" %21.12f te_est " se=" %21.12f te_se " n_obs=" %12.0f n_in
display "ANSWER: reduced_form estimate=" %21.12f rf_est " se=" %21.12f rf_se " n_obs=" %12.0f n_in
display "ANSWER: first_stage estimate=" %21.12f fs_est " se=" %21.12f fs_se " n_obs=" %12.0f n_in
