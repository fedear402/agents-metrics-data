clear all
set more off
set type double

import delimited using "crosswalk.csv", clear varnames(1) stringcols(_all)
keep code industry
duplicates drop
tempfile xw
save `xw'

keep industry
duplicates drop
gen byte one = 1
tempfile ind
save `ind'

import delimited using "trade.csv", clear varnames(1) stringcols(_all)
destring period us_change other_change price_index years, replace
merge m:1 code using `xw', keep(match) nogenerate
keep period industry us_change other_change price_index years
duplicates drop period industry, force
tempfile tr
save `tr'

import delimited using "areas.csv", clear varnames(1) stringcols(_all)
destring area period total_employment population, replace
replace vintage = strtrim(vintage)
preserve
keep if vintage == "base"
keep area period population
tempfile pop
save `pop'
restore
keep area period vintage total_employment
tempfile ar
save `ar'

import delimited using "employment.csv", clear varnames(1) stringcols(_all)
destring area period employment, replace
replace vintage = strtrim(vintage)
keep area period vintage industry employment
tempfile emp
save `emp'

use `ar', clear
gen byte one = 1
joinby one using `ind'
drop one
merge 1:1 area period vintage industry using `emp', keep(master match) nogenerate
replace employment = 0 if missing(employment)
merge m:1 period industry using `tr', keep(match) nogenerate

bysort period vintage industry: egen double natl = total(employment)
gen double scale = (10/years)/(price_index/100)/1000
gen double x = cond(vintage == "base", employment/total_employment*us_change/natl*scale, 0)
gen double z = cond(vintage == "early", employment/total_employment*other_change/natl*scale, 0)

collapse (sum) x z, by(area period)
merge 1:1 area period using `pop', keep(match) nogenerate

tempfile panel
save `panel'

import delimited using "outcomes.csv", clear varnames(1) stringcols(_all)
destring area period control change_pp, replace
keep area period control change_pp
tempfile outs
save `outs'

use `panel', clear
merge 1:1 area period using `outs', keep(match) nogenerate

ivregress 2sls change_pp period control (x = z) [aw=population]

scalar est_n = e(N)
scalar est_iv = _b[x]

summarize x if area == 0 & period == 0, meanonly
scalar ex00 = r(mean)
summarize x if area == 0 & period == 1, meanonly
scalar ex01 = r(mean)
summarize z if area == 0 & period == 0, meanonly
scalar iz00 = r(mean)

local l1 = "ANSWER: iv_slope estimate=" + trim(string(scalar(est_iv), "%24.16g")) + " se=NA n_obs=" + trim(string(scalar(est_n), "%12.0f"))
local l2 = "ANSWER: exposure_area0_period0 estimate=" + trim(string(scalar(ex00), "%24.16g")) + " se=NA n_obs=" + trim(string(scalar(est_n), "%12.0f"))
local l3 = "ANSWER: exposure_area0_period1 estimate=" + trim(string(scalar(ex01), "%24.16g")) + " se=NA n_obs=" + trim(string(scalar(est_n), "%12.0f"))
local l4 = "ANSWER: instrument_area0_period0 estimate=" + trim(string(scalar(iz00), "%24.16g")) + " se=NA n_obs=" + trim(string(scalar(est_n), "%12.0f"))

display `"`l1'"'
display `"`l2'"'
display `"`l3'"'
display `"`l4'"'
