clear all
set more off
set linesize 255

import delimited using "input.csv", clear varnames(1)

keep if abs(score) < 1
gen double w = 1 - abs(score)
gen double R = (score >= 0)
gen double Rx = R*score
gen double one = 1

scalar r_rf = .
scalar se_rf = .
scalar r_fs = .
scalar se_fs = .
scalar r_tau = .
scalar se_tau = .
scalar n_obs = .

mata:
Xm = st_data(., ("one","R","score","Rx"))
Y1v = st_data(., "earnings")
Y2v = st_data(., "participated")
wv = st_data(., "w")
nv = rows(Xm)

Am = cross(Xm, wv, Xm)
Aim = invsym(Am)
b1v = Aim*cross(Xm, wv, Y1v)
b2v = Aim*cross(Xm, wv, Y2v)
e1v = Y1v - Xm*b1v
e2v = Y2v - Xm*b2v

S1m = Xm :* ((wv:*e1v)*J(1,4,1))
S2m = Xm :* ((wv:*e2v)*J(1,4,1))
Im = (S1m*Aim, S2m*Aim)
Vm = cross(Im, Im)

rfv = b1v[2]
fsv = b2v[2]
tauv = rfv/fsv

gv = J(8,1,0)
gv[2] = 1/fsv
gv[6] = -rfv/(fsv^2)
vtau = (gv'*Vm*gv)

st_numscalar("r_rf", rfv)
st_numscalar("se_rf", sqrt(Vm[2,2]))
st_numscalar("r_fs", fsv)
st_numscalar("se_fs", sqrt(Vm[6,6]))
st_numscalar("r_tau", tauv)
st_numscalar("se_tau", sqrt(vtau))
st_numscalar("n_obs", nv)
end

display "ANSWER: treatment_effect estimate=" %21.12f r_tau " se=" %21.12f se_tau " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f r_rf " se=" %21.12f se_rf " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f r_fs " se=" %21.12f se_fs " n_obs=" %12.0f n_obs
