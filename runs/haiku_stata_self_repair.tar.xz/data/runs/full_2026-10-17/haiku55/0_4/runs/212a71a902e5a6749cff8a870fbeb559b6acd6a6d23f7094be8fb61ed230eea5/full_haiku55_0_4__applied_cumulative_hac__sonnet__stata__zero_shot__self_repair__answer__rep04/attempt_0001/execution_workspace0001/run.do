set linesize 255
clear all
set more off

import delimited using "input.csv", clear varnames(lower)

capture confirm string variable date
if _rc == 0 {
    gen double dnum = date(date, "YMD")
    count if missing(dnum)
    if r(N) > 0 {
        replace dnum = date(date, "MDY") if missing(dnum)
    }
}
else {
    gen double dnum = date
}

sort dnum
gen long t = _n
tsset t

gen double lnsales = ln(sales)
gen double lnvix = ln(vix)
gen double dlv = lnvix - L.lnvix

forvalues k = 1/15 {
    gen double l`k'dlv = L`k'.dlv
}

local lags
forvalues k = 1/15 {
    local lags `lags' l`k'dlv
}

newey lnsales `lags', lag(15)

scalar nobs = e(N)
matrix b = e(b)
matrix V = e(V) * (nobs/(nobs-16))

matrix c = J(1,16,1)
matrix c[1,1] = 0
matrix cb = c*b'
matrix cv = c*V*c'
scalar cum_est = cb[1,1]
scalar cum_se = sqrt(cv[1,1])

scalar lag1_est = b[1,2]
scalar lag1_se = sqrt(V[2,2])
scalar lag15_est = b[1,16]
scalar lag15_se = sqrt(V[16,16])

display "ANSWER: cumulative_response estimate=" %21.12f cum_est " se=" %21.12f cum_se " n_obs=" %12.0f nobs
display "ANSWER: lag_1 estimate=" %21.12f lag1_est " se=" %21.12f lag1_se " n_obs=" %12.0f nobs
display "ANSWER: lag_15 estimate=" %21.12f lag15_est " se=" %21.12f lag15_se " n_obs=" %12.0f nobs
