set linesize 255
clear all
import delimited "./input.csv", clear varnames(1)
capture confirm numeric variable group
if _rc {
    encode group, gen(grp_id)
}
else {
    egen grp_id = group(group)
}
quietly oneway y grp_id
local F = e(F)
local df_num = e(df_m)
local df_den = e(df_r)
local p = Ftail(`df_num', `df_den', `F')
local n = _N
local Fs = string(`F', "%21.12f")
local dfns = string(`df_num', "%21.12f")
local dfds = string(`df_den', "%21.12f")
local ps = string(`p', "%21.12f")
local ns = string(`n', "%12.0f")
display "ANSWER: F estimate=`Fs' se=. n_obs=`ns'"
display "ANSWER: df_num estimate=`dfns' se=. n_obs=`ns'"
display "ANSWER: df_den estimate=`dfds' se=. n_obs=`ns'"
display "ANSWER: p_value estimate=`ps' se=. n_obs=`ns'"
