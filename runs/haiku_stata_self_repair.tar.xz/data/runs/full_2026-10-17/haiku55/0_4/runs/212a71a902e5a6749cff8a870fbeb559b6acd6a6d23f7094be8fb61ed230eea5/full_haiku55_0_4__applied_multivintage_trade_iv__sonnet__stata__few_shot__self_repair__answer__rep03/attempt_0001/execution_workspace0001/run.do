clear all
set more off
set type double

import delimited using "crosswalk.csv", clear varnames(1)
keep code industry
tempfile xw
save `xw'

import delimited using "trade.csv", clear varnames(1)
merge m:1 code using `xw', keep(match) nogenerate
keep period industry us_change other_change price_index years
duplicates drop period industry, force
tempfile tr
save `tr'

import delimited using "areas.csv", clear varnames(1)
keep area period vintage total_employment population
tempfile ar
save `ar'

keep if vintage == "base"
keep area period population
tempfile pop
save `pop'

use `ar', clear
keep area period vintage
gen byte one = 1
tempfile keys
save `keys'

use `xw', clear
keep industry
duplicates drop
gen byte one = 1
joinby one using `keys'
drop one

import delimited using "employment.csv", clear varnames(1)
keep area period vintage industry employment
tempfile emp
save `emp'

import delimited using "outcomes.csv", clear varnames(1)
keep area period control change_pp
tempfile outs
save `outs'

use `xw', clear
keep industry
duplicates drop
gen byte one = 1
use `keys', clear
gen byte one = 1
joinby one using `tmpind'
exit, clear
