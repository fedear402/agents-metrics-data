clear all
set more off
set linesize 255

import delimited using "input.csv", clear varnames(1)

capture confirm string variable date
if _rc == 0 {
    gen double dt = date(date, "YMD")
}
else {
    gen double dt = date
}
sort dt
gen long t = _n
tsset t

gen double lsales = ln(sales)
gen double lvix = ln(vix)
gen double dvol = D.lvix

local lags ""
forvalues k = 1/15 {
    local lags `lags' L`k'.dvol
}

newey lsales `lags', lag(15)

scalar N = e(N)
scalar adj = N/(N-16)
matrix b = e(b)
matrix V = adj*e(V)

matrix c = J(1,16,0)
forvalues j = 1/15 {
    matrix c[1,`j'] = 1
}
matrix cb = c*b'
matrix cv = c*V*c'

scalar cum_est = cb[1,1]
scalar cum_se = sqrt(cv[1,1])
scalar lag1_est = b[1,1]
scalar lag1_se = sqrt(V[1,1])
scalar lag15_est = b[1,15]
scalar lag15_se = sqrt(V[15,15])

display "ANSWER: cumulative_response estimate=" %21.12f cum_est " se=" %21.12f cum_se " n_obs=" %12.0f N
display "ANSWER: lag_1 estimate=" %21.12f lag1_est " se=" %21.12f lag1_se " n_obs=" %12.0f N
display "ANSWER: lag_15 estimate=" %21.12f lag15_est " se=" %21.12f lag15_se " n_obs=" %12.0f N
