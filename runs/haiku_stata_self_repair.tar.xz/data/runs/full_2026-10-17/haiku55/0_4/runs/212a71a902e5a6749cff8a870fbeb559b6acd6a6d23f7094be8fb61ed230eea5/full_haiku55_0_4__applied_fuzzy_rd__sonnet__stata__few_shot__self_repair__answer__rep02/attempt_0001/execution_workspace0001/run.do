version 19.0
clear all
set more off
set linesize 255

import delimited using "input.csv", clear varnames(1)
keep if abs(score) < 1
gen double w = 1 - abs(score)
gen double right = (score >= 0)
gen double lint = 1 - right
gen double rint = right
gen double sleft = (1 - right) * score
gen double sright = right * score

mata:
X = st_data(., ("lint", "sleft", "rint", "sright"))
w = st_data(., "w")
Y = st_data(., ("earnings", "participated"))
n = rows(X)

B = invsym(X' * (w :* X))
b = B * X' * (w :* Y)
E = Y - X * b

c = (-1 \ 0 \ 1 \ 0)
g = X * B * c
a = (w :* g) :* E
V = a' * a

d = c' * b
ratio_grad = (1 / d[2] \ -d[1] / d[2]^2)
ratio_se = sqrt(ratio_grad' * V * ratio_grad)

st_numscalar("rf_est", d[1])
st_numscalar("rf_se", sqrt(V[1,1]))
st_numscalar("fs_est", d[2])
st_numscalar("fs_se", sqrt(V[2,2]))
st_numscalar("te_est", d[1] / d[2])
st_numscalar("te_se", ratio_se)
st_numscalar("nobs", n)
end

display "ANSWER: treatment_effect estimate=" %21.12f te_est " se=" %21.12f te_se " n_obs=" %12.0f nobs
display "ANSWER: reduced_form estimate=" %21.12f rf_est " se=" %21.12f rf_se " n_obs=" %12.0f nobs
display "ANSWER: first_stage estimate=" %21.12f fs_est " se=" %21.12f fs_se " n_obs=" %12.0f nobs
