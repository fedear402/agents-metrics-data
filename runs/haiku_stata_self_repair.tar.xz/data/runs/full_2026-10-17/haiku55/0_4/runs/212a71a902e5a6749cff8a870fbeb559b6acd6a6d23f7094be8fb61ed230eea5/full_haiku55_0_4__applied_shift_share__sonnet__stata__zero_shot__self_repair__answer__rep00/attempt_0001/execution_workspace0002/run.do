clear all
set more off
set linesize 255

import delimited using "input.csv", clear

egen byte regtag = tag(region_id)
egen double wsum = total(region_weight*regtag)
gen double e = region_weight/wsum

bysort region_id: egen double z = total(share*shock)

egen double my = total(regtag*e*y)
egen double mx = total(regtag*e*x)
egen double mz = total(regtag*e*z)
gen double y0 = y - my
gen double x0 = x - mx
gen double z0 = z - mz

gen double ezx = regtag*e*z0*x0
gen double ezz = regtag*e*z0^2
summarize ezx, meanonly
scalar fs_num = r(sum)
summarize ezz, meanonly
scalar fs_den = r(sum)
scalar fs_slope = fs_num/fs_den

egen byte tagi = tag(industry_id)
bysort industry_id: egen double shock_n = mean(shock)
gen double es = e*share
bysort industry_id: egen double s_n = total(es)
gen double ey = e*share*y0
gen double ex = e*share*x0
gen double ez = e*share*z0
bysort industry_id: egen double ysum = total(ey)
bysort industry_id: egen double xsum = total(ex)
bysort industry_id: egen double zsum = total(ez)
gen double ybar = ysum/s_n
gen double xbar = xsum/s_n
gen double zbar = zsum/s_n

preserve
keep if tagi

mata:
real matrix inv2(real matrix A)
{
    real scalar d
    d = A[1,1]*A[2,2] - A[1,2]*A[2,1]
    return(((A[2,2], -A[1,2]) \ (-A[2,1], A[1,1])) / d)
}

real matrix ivhc1(real colvector y, real colvector en, real colvector iv, real colvector w)
{
    real scalar N
    real matrix X, Z, Xw, A, Ainv, G, M
    real colvector b, u

    N = rows(y)
    X = (J(N,1,1), en)
    Z = (J(N,1,1), iv)
    Xw = X :* (w, w)
    A = Z' * Xw
    Ainv = inv2(A)
    b = Ainv * (Z' * (w :* y))
    u = y - X*b
    G = Z :* (w :* u, w :* u)
    M = G' * G
    return((b, (N/(N-2)) * (Ainv * M * Ainv')))
}

void run_iv()
{
    real matrix R1, R2

    R1 = ivhc1(st_data(.,"ybar"), st_data(.,"xbar"), st_data(.,"shock_n"), st_data(.,"s_n"))
    R2 = ivhc1(st_data(.,"xbar"), st_data(.,"zbar"), st_data(.,"shock_n"), st_data(.,"s_n"))

    st_numscalar("eff_b", R1[2,1])
    st_numscalar("eff_se", sqrt(R1[2,3]))
    st_numscalar("fs_se", sqrt(R2[2,3]))
}
run_iv()
end

gen double s2 = s_n^2
summarize s2, meanonly
scalar eff_shocks = 1/r(sum)

local n_ind = _N

display "ANSWER: effect estimate=" %21.12f scalar(eff_b) " se=" %21.12f scalar(eff_se) " n_obs=" %12.0f `n_ind'
display "ANSWER: first_stage estimate=" %21.12f scalar(fs_slope) " se=" %21.12f scalar(fs_se) " n_obs=" %12.0f `n_ind'
display "ANSWER: effective_shocks estimate=" %21.12f scalar(eff_shocks) " se=. n_obs=" %12.0f `n_ind'
