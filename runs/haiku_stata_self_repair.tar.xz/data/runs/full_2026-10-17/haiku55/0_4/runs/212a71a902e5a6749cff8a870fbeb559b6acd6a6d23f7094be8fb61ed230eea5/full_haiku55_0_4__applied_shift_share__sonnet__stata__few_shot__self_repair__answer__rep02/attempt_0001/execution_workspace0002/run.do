version 19.0
clear all
set more off
set linesize 255

import delimited using "input.csv", clear varnames(1)
sort region_id industry_id

gen double sxs = share*shock
bysort region_id: egen double z = total(sxs)
bysort region_id: gen byte first = (_n==1)
gen double wf = region_weight*first
quietly summarize wf
gen double e = region_weight/r(sum)
gen double ef = e*first

foreach v in y x z {
    quietly summarize `v' [aw=ef], meanonly
    gen double `v'0 = `v' - r(mean)
}

gen double w_zy = ef*z0*y0
gen double w_zx = ef*z0*x0
gen double w_zz = ef*z0*z0

quietly summarize w_zy, meanonly
scalar num_effect = r(sum)
quietly summarize w_zx, meanonly
scalar den_effect = r(sum)
quietly summarize w_zz, meanonly
scalar den_fs = r(sum)

scalar effect_est = num_effect/den_effect
scalar fs_est = den_effect/den_fs

gen double es = e*share
gen double esy = es*y0
gen double esx = es*x0
gen double esz = es*z0
collapse (sum) s=es sy=esy sx=esx sz=esz (mean) shock, by(industry_id)
gen double ybar = sy/s
gen double xbar = sx/s
gen double zbar = sz/s

mata:
real rowvector shock_iv(real colvector y, real matrix X, real matrix Z, real colvector w)
{
    real scalar N
    real matrix Ai, S, V
    real colvector b, u
    N = rows(y)
    Ai = luinv(cross(Z, w, X))
    b = Ai * cross(Z, w, y)
    u = y - X*b
    S = cross(Z, w:*w:*u:*u, Z)
    V = N/(N-2) * Ai * S * Ai'
    return((b[2], sqrt(V[2,2])))
}

ybar = st_data(., "ybar")
xbar = st_data(., "xbar")
zbar = st_data(., "zbar")
sh = st_data(., "shock")
sv = st_data(., "s")
n = rows(ybar)
one = J(n, 1, 1)
Z = (one, sh)

eff = shock_iv(ybar, (one, xbar), Z, sv)
fs = shock_iv(xbar, (one, zbar), Z, sv)

st_numscalar("n_ind", n)
st_numscalar("effect_se", eff[2])
st_numscalar("fs_se", fs[2])
st_numscalar("eff_shocks", 1/sum(sv:^2))
end

display "ANSWER: effect estimate=" %21.12f effect_est " se=" %21.12f effect_se " n_obs=" %12.0f n_ind
display "ANSWER: first_stage estimate=" %21.12f fs_est " se=" %21.12f fs_se " n_obs=" %12.0f n_ind
display "ANSWER: effective_shocks estimate=" %21.12f eff_shocks " se=" %21.12f . " n_obs=" %12.0f n_ind
