clear all
set more off

import delimited using "crosswalk.csv", clear varnames(1)
capture tostring code, replace
capture tostring industry, replace
replace code = strtrim(code)
replace industry = strtrim(industry)
keep code industry
tempfile xw
save `xw'

import delimited using "trade.csv", clear varnames(1)
capture tostring code, replace
replace code = strtrim(code)
merge m:1 code using `xw', keep(match) nogen
keep period industry us_change other_change price_index years
tempfile tr
save `tr'

import delimited using "areas.csv", clear varnames(1)
capture tostring area, replace
replace area = strtrim(area)
replace vintage = strtrim(vintage)
preserve
keep if vintage=="base"
keep area period total_employment population
rename total_employment te_base
tempfile teb
save `teb'
restore
keep if vintage=="early"
keep area period total_employment
rename total_employment te_early
tempfile tee
save `tee'

import delimited using "employment.csv", clear varnames(1)
capture tostring area, replace
capture tostring industry, replace
replace area = strtrim(area)
replace industry = strtrim(industry)
replace vintage = strtrim(vintage)
collapse (sum) employment, by(area period vintage industry)

merge m:1 period industry using `tr', keep(match) nogen
bysort period vintage industry: egen double ne = total(employment)
merge m:1 area period using `teb', keep(master match) nogen
merge m:1 area period using `tee', keep(master match) nogen

gen double fac = (100/price_index)/1000*(10/years)
gen double tx = cond(vintage=="base", employment/te_base*us_change/ne, 0)*fac
gen double tz = cond(vintage=="early", employment/te_early*other_change/ne, 0)*fac
collapse (sum) x=tx z=tz, by(area period)
tempfile ex
save `ex'

import delimited using "outcomes.csv", clear varnames(1)
capture tostring area, replace
replace area = strtrim(area)
merge m:1 area period using `ex', keep(master match) nogen
merge m:1 area period using `teb', keep(master match) nogen
replace x = 0 if missing(x)
replace z = 0 if missing(z)

ivregress 2sls change_pp period control (x = z) [pweight=population]
scalar b_iv = _b[x]
scalar n_obs = e(N)

summarize x if real(area)==0 & period==0, meanonly
scalar ex00 = r(mean)
summarize x if real(area)==0 & period==1, meanonly
scalar ex01 = r(mean)
summarize z if real(area)==0 & period==0, meanonly
scalar iz00 = r(mean)

display "ANSWER: iv_slope estimate=" trim(string(b_iv,"%21.15g")) " se=NA n_obs=" trim(string(n_obs,"%12.0f"))
display "ANSWER: exposure_area0_period0 estimate=" trim(string(ex00,"%21.15g")) " se=NA n_obs=" trim(string(n_obs,"%12.0f"))
display "ANSWER: exposure_area0_period1 estimate=" trim(string(ex01,"%21.15g")) " se=NA n_obs=" trim(string(n_obs,"%12.0f"))
display "ANSWER: instrument_area0_period0 estimate=" trim(string(iz00,"%21.15g")) " se=NA n_obs=" trim(string(n_obs,"%12.0f"))
