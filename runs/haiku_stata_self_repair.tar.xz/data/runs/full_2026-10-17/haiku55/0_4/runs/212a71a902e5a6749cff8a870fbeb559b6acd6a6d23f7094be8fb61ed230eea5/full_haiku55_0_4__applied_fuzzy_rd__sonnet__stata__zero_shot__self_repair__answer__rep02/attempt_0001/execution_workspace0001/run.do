clear all
set more off
set linesize 255

import delimited using "input.csv", clear varnames(1)

gen double x = score
keep if abs(x) < 1
gen double w = 1 - abs(x)
gen byte right = (x >= 0)

gen double xr = x * right
gen double xl = x * (1 - right)
gen double xr_r = x * right
gen double xl_l = x * (1 - right)

* Weighted local-linear regressions on each side with intercepts, joint estimation
* Model: y = a_L*left + b_L*x*left + a_R*right + b_R*x*right, weights w

gen double r1 = right
gen double l1 = 1 - right
gen double xL = x * l1
gen double xR = x * r1

quietly regress earnings l1 r1 xL xR [aweight=w], noconstant vce(hc0)
scalar rf_R = _b[r1]
scalar rf_L = _b[l1]
scalar reduced_form = rf_R - rf_L
matrix Vrf = e(V)
local rf_var_R = Vrf[2,2]
local rf_var_L = Vrf[1,1]
local rf_cov_RL = Vrf[1,2]
scalar n_rf = e(N)
local rf_RR = Vrf[2,2]
local rf_LL = Vrf[1,1]
local rf_RL = Vrf[1,2]

quietly regress participated l1 r1 xL xR [aweight=w], noconstant vce(hc0)
scalar fs_R = _b[r1]
scalar fs_L = _b[l1]
scalar first_stage = fs_R - fs_L
matrix Vfs = e(V)
scalar n_fs = e(N)
local fs_RR = Vfs[2,2]
local fs_LL = Vfs[1,1]
local fs_RL = Vfs[1,2]

* Covariance between earnings and participation estimates
quietly regress earnings l1 r1 xL xR [aweight=w], noconstant vce(hc0)
matrix b_e = e(b)
matrix V_e = e(V)
quietly regress participated l1 r1 xL xR [aweight=w], noconstant vce(hc0)
matrix b_p = e(b)
matrix V_p = e(V)

gen double u_e = .
gen double u_p = .
quietly regress earnings l1 r1 xL xR [aweight=w], noconstant
predict double res_e, residuals
quietly regress participated l1 r1 xL xR [aweight=w], noconstant
predict double res_p, residuals

gen double e_l = res_e * l1 * w
gen double e_r = res_e * r1 * w
gen double p_l = res_p * l1 * w
gen double p_r = res_p * r1 * w

gen double xwl = l1 * w
gen double xwr = r1 * w
gen double xwlx = l1 * w * x
gen double xwrx = r1 * w * x

* Build sandwich pieces with X'WX inverse and HC0 meat
mata:
X = (st_data(., "l1"), st_data(., "r1"), st_data(., "xL"), st_data(., "xR"))
w = st_data(., "w")
ee = st_data(., "res_e")
pp = st_data(., "res_p")
XWX = cross(X, w, X)
iX = invsym(XWX)
Me = cross(X, w:^2 :* ee :* ee, X)
Mp = cross(X, w:^2 :* pp :* pp, X)
Mep = cross(X, w:^2 :* ee :* pp, X)
Ve = iX * Me * iX
Vp = iX * Mp * iX
Vep = iX * Mep * iX
be = invsym(XWX) * cross(X, w, st_data(., "earnings"))
bp = invsym(XWX) * cross(X, w, st_data(., "participated"))
g = (-1, 1, 0, 0)
gx = (0, 0, -1, 1)
rfv = Ve[1,1]
end
mata:
X = st_data(., ("l1", "r1", "xL", "xR"))
w = st_data(., "w")
ee = st_data(., "res_e")
pp = st_data(., "res_p")
XWX = cross(X, w, X)
iX = invsym(XWX)
Ve = iX * cross(X, w:^2 :* ee :* ee, X) * iX
Vp = iX * cross(X, w:^2 :* pp :* pp, X) * iX
Vep = iX * cross(X, w:^2 :* ee :* pp, X) * iX
be = iX * cross(X, w, st_data(., "earnings"))
bp = iX * cross(X, w, st_data(., "participated"))
d_rf = (-1, 1, 0, 0)'
d_fs = (-1, 1, 0, 0)'
rf = d_rf' * be
fs = d_fs' * bp
v_rf = d_rf' * Ve * d_rf
v_fs = d_fs' * Vp * d_fs
c_rf_fs = d_rf' * Vep * d_fs
te = rf / fs
dte_rf = 1/fs
dte_fs = -rf/(fs^2)
v_te = dte_rf^2 * v_rf + dte_fs^2 * v_fs + 2*dte_rf*dte_fs*c_rf_fs
st_numscalar("rf_est", rf)
st_numscalar("rf_se", sqrt(v_rf))
st_numscalar("fs_est", fs)
st_numscalar("fs_se", sqrt(v_fs))
st_numscalar("te_est", te)
st_numscalar("te_se", sqrt(v_te))
end

scalar n_total = _N
quietly count
scalar n_obs_all = r(N)

display "ANSWER: treatment_effect estimate=" %21.12f te_est " se=" %21.12f te_se " n_obs=" %12.0f n_obs_all
display "ANSWER: reduced_form estimate=" %21.12f rf_est " se=" %21.12f rf_se " n_obs=" %12.0f n_obs_all
display "ANSWER: first_stage estimate=" %21.12f fs_est " se=" %21.12f fs_se " n_obs=" %12.0f n_obs_all
