version 19.0
clear all
set more off
set linesize 255

import delimited using "input.csv", clear varnames(1)
sort region_id industry_id

gen double sxs = share*shock
bysort region_id: egen double z = total(sxs)
bysort region_id: gen byte first = (_n==1)
gen double wf = region_weight*first
quietly summarize wf
gen double e = region_weight/r(sum)
gen double ef = e*first

foreach v in y x z {
    quietly summarize `v' [aw=ef]
    gen double `v'0 = `v' - r(mean)
}

gen double es = e*share
gen double esy = es*y0
gen double esx = es*x0
gen double esz = es*z0
collapse (sum) s=es sy=esy sx=esx sz=esz (mean) shock, by(industry_id)
gen double ybar = sy/s
gen double xbar = sx/s
gen double zbar = sz/s
scalar n_ind = _N

mata:
real rowvector shock_iv(real colvector y, real matrix X, real matrix Z, real colvector w)
{
    real scalar N
    real matrix A, Ai, S, V
    real colvector b, u
    N = rows(y)
    A = Z' * (w :* X)
    Ai = luinv(A)
    b = Ai * (Z' * (w :* y))
    u = y - X*b
    S = (Z :* (w :* u))' * (Z :* (w :* u))
    V = N/(N-2) * Ai * S * Ai'
    return((b[2], sqrt(V[2,2])))
}

one = J(n_ind, 1, 1)
Z = (one, st_data(., "shock"))
w = st_data(., "s")

eff = shock_iv(st_data(., "ybar"), (one, st_data(., "xbar")), Z, w)
fs  = shock_iv(st_data(., "xbar"), (one, st_data(., "zbar")), Z, w)

ef = st_data(., "ef")
y0 = st_data(., "y0")
x0 = st_data(., "x0")
z0 = st_data(., "z0")
sv = st_data(., "s")

st_numscalar("effect_est", sum(ef:*z0:*y0)/sum(ef:*z0:*x0))
st_numscalar("effect_se", eff[2])
st_numscalar("fs_est", sum(ef:*z0:*x0)/sum(ef:*z0:^2))
st_numscalar("fs_se", fs[2])
st_numscalar("eff_shocks", 1/sum(sv:^2))
end

display "ANSWER: effect estimate=" %21.12f effect_est " se=" %21.12f effect_se " n_obs=" %12.0f n_ind
display "ANSWER: first_stage estimate=" %21.12f fs_est " se=" %21.12f fs_se " n_obs=" %12.0f n_ind
display "ANSWER: effective_shocks estimate=" %21.12f eff_shocks " se=" %21.12f . " n_obs=" %12.0f n_ind
