clear all
set more off

capture program drop loadcsv
program define loadcsv
    args file
    import delimited using "`file'", clear varnames(1) stringcols(_all)
    foreach v of varlist _all {
        quietly replace `v' = strtrim(`v')
        capture destring `v', replace
    }
end

loadcsv "crosswalk.csv"
keep code industry
duplicates drop
tempfile xw
save `xw'

use `xw', clear
keep industry
duplicates drop
local ni = _N
gen byte k = _n
tempfile ind
save `ind'

loadcsv "trade.csv"
merge m:1 code using `xw', keep(match) nogen
keep period industry us_change other_change price_index years
tempfile tt
save `tt'

loadcsv "areas.csv"
keep area period vintage total_employment population
tempfile ar
save `ar'

loadcsv "employment.csv"
keep area period vintage industry employment
tempfile em
save `em'

loadcsv "outcomes.csv"
keep area period control change_pp
tempfile oc
save `oc'

use `ar', clear
expand `ni'
bysort area period vintage: gen byte k = _n
merge m:1 k using `ind', keep(match) nogen
drop k

merge 1:1 area period vintage industry using `em', keep(master match) nogen
replace employment = 0 if missing(employment)

merge m:1 period industry using `tt', keep(match) nogen

bysort period vintage industry: egen double natemp = total(employment)

gen double chg = cond(vintage=="early", other_change, us_change)
gen double term = employment/total_employment*chg/natemp/(price_index/100)/1000*(10/years)

gen double xt = term if vintage=="base"
gen double zt = term if vintage=="early"
gen double popb = population if vintage=="base"

collapse (sum) xt zt popb, by(area period)

merge 1:1 area period using `oc', keep(match) nogen

rename xt x
rename zt z
rename popb weight

ivregress 2sls change_pp period control (x = z) [aw=weight]
scalar iv_b = _b[x]
scalar n_obs = e(N)

capture confirm numeric variable area
if _rc==0 {
    gen str40 akey = string(area)
}
else {
    gen str40 akey = area
}

summarize x if akey=="0" & period==0, meanonly
scalar exp_a0_p0 = r(mean)
summarize x if akey=="0" & period==1, meanonly
scalar exp_a0_p1 = r(mean)
summarize z if akey=="0" & period==0, meanonly
scalar ins_a0_p0 = r(mean)

display "ANSWER: iv_slope estimate=" trim(string(iv_b, "%24.16g")) " se=NA n_obs=" trim(string(n_obs, "%12.0f"))
display "ANSWER: exposure_area0_period0 estimate=" trim(string(exp_a0_p0, "%24.16g")) " se=NA n_obs=" trim(string(n_obs, "%12.0f"))
display "ANSWER: exposure_area0_period1 estimate=" trim(string(exp_a0_p1, "%24.16g")) " se=NA n_obs=" trim(string(n_obs, "%12.0f"))
display "ANSWER: instrument_area0_period0 estimate=" trim(string(ins_a0_p0, "%24.16g")) " se=NA n_obs=" trim(string(n_obs, "%12.0f"))
