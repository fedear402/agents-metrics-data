version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

gen double dt = date(date, "YMD")
sort dt
gen long obs = _n
tsset obs

gen double lvix = ln(vix)
gen double dlv = lvix - L.lvix
gen double lsales = ln(sales)

local lagnames ""
forvalues k = 1/15 {
    gen double lag`k' = L`k'.dlv
    local lagnames `lagnames' lag`k'
}

egen byte nmiss = rowmiss(lsales `lagnames')
gen byte touse = (nmiss == 0)

mata:
y = st_data(., "lsales", "touse")
Z = st_data(., tokens("`lagnames'"), "touse")
X = (J(rows(y), 1, 1), Z)
N = rows(X)
p = cols(X)
bread = invsym(X'*X)
b = bread*X'*y
e = y - X*b
S = X :* e
meat = S'*S
for (j = 1; j <= 15; j++) {
    G = S[|j+1, 1 \ N, p|]' * S[|1, 1 \ N-j, p|]
    meat = meat + (1 - j/16) * (G + G')
}
V = N/(N-p) * bread * meat * bread
c = (0 \ J(15, 1, 1))
st_numscalar("cum_est", c'*b)
st_numscalar("cum_se", sqrt(c'*V*c))
st_numscalar("lag1_est", b[2])
st_numscalar("lag1_se", sqrt(V[2,2]))
st_numscalar("lag15_est", b[16])
st_numscalar("lag15_se", sqrt(V[16,16]))
st_numscalar("nobs", N)
end

display "ANSWER: cumulative_response estimate=" %21.12f cum_est " se=" %21.12f cum_se " n_obs=" %12.0f nobs
display "ANSWER: lag_1 estimate=" %21.12f lag1_est " se=" %21.12f lag1_se " n_obs=" %12.0f nobs
display "ANSWER: lag_15 estimate=" %21.12f lag15_est " se=" %21.12f lag15_se " n_obs=" %12.0f nobs
