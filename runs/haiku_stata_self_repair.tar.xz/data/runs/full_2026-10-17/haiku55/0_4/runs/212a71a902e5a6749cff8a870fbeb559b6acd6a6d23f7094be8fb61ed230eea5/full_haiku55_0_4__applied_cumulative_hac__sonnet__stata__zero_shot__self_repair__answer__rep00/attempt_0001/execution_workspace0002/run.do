clear all
set more off
set linesize 255

import delimited using "input.csv", clear varnames(1)
sort date

gen double lnsales = ln(sales)
gen double dlvix = ln(vix) - ln(vix[_n-1])
gen long t = _n
tsset t

local lags ""
forvalues j = 1/15 {
    local lags "`lags' L`j'.dlvix"
}

newey lnsales `lags', lag(15)

local N = e(N)
local k = colsof(e(b))
matrix b = e(b)
matrix V = e(V) * `N' / (`N' - 16)

matrix c = J(1, `k', 0)
forvalues j = 1/15 {
    matrix c[1, `j'] = 1
}

matrix cb = c * b'
matrix cV = c * V * c'
scalar cum_est = cb[1, 1]
scalar cum_se  = sqrt(cV[1, 1])

scalar lag1_est  = b[1, 1]
scalar lag1_se   = sqrt(V[1, 1])
scalar lag15_est = b[1, 15]
scalar lag15_se  = sqrt(V[15, 15])

scalar n_obs = e(N)

display "ANSWER: cumulative_response estimate=" %21.12f cum_est " se=" %21.12f cum_se " n_obs=" %12.0f n_obs
display "ANSWER: lag_1 estimate=" %21.12f lag1_est " se=" %21.12f lag1_se " n_obs=" %12.0f n_obs
display "ANSWER: lag_15 estimate=" %21.12f lag15_est " se=" %21.12f lag15_se " n_obs=" %12.0f n_obs
