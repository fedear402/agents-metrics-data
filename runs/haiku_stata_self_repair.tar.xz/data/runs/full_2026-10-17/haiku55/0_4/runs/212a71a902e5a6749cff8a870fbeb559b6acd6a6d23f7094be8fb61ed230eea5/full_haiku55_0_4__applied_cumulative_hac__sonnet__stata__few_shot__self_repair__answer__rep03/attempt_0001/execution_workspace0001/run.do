version 19.0
clear all
set more off
set linesize 255

import delimited using "input.csv", clear varnames(1)

capture confirm string variable date
if _rc == 0 {
    generate double day = date(date, "YMD")
}
else {
    generate double day = date
}

sort day
generate long obs = _n
tsset obs

generate double lnvix = ln(vix)
generate double dlnvix = D.lnvix
forvalues k = 1/15 {
    generate double dvl`k' = L`k'.dlnvix
}
generate double lnsales = ln(sales)

local lagvars ""
forvalues k = 1/15 {
    local lagvars "`lagvars' dvl`k'"
}

keep if !missing(lnsales, `lagvars')

mata:
y = st_data(., "lnsales")
X = (J(rows(y), 1, 1), st_data(., "`lagvars'"))
N = rows(X)
p = cols(X)

b = invsym(X'X) * X'y
e = y - X * b
scores = X :* e

meat = scores' * scores
for (j = 1; j <= 15; j++) {
    w = 1 - j / 16
    G = scores[|j+1, 1 \ N, p|]' * scores[|1, 1 \ N-j, p|]
    meat = meat + w * (G + G')
}

bread = invsym(X'X)
V = N / (N - p) * bread * meat * bread

c = J(p, 1, 0)
c[|2, 1 \ p, 1|] = J(15, 1, 1)

st_numscalar("r_cum", c' * b)
st_numscalar("r_cum_se", sqrt(c' * V * c))
st_numscalar("r_lag1", b[2])
st_numscalar("r_lag1_se", sqrt(V[2, 2]))
st_numscalar("r_lag15", b[16])
st_numscalar("r_lag15_se", sqrt(V[16, 16]))
st_numscalar("r_n", N)
end

display "ANSWER: cumulative_response estimate=" %21.12f r_cum " se=" %21.12f r_cum_se " n_obs=" %12.0f r_n
display "ANSWER: lag_1 estimate=" %21.12f r_lag1 " se=" %21.12f r_lag1_se " n_obs=" %12.0f r_n
display "ANSWER: lag_15 estimate=" %21.12f r_lag15 " se=" %21.12f r_lag15_se " n_obs=" %12.0f r_n
