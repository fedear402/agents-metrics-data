clear all
set more off
set linesize 255

import delimited using "input.csv", clear varnames(1)

egen byte tagr = tag(region_id)
summarize region_weight if tagr, meanonly
scalar Wsum = r(sum)
gen double e = region_weight/Wsum

gen double sz = share*shock
bysort region_id: egen double z = total(sz)
drop sz

gen double eyr = e*y if tagr
gen double exr = e*x if tagr
gen double ezr = e*z if tagr
summarize eyr, meanonly
scalar my = r(sum)
summarize exr, meanonly
scalar mx = r(sum)
summarize ezr, meanonly
scalar mz = r(sum)
drop eyr exr ezr

gen double y0 = y - my
gen double x0 = x - mx
gen double z0 = z - mz

gen double ezx = e*z0*x0 if tagr
gen double ezz = e*z0^2 if tagr
summarize ezx, meanonly
scalar sxz = r(sum)
summarize ezz, meanonly
scalar szz = r(sum)
scalar fs_b = sxz/szz
drop ezx ezz

gen double esh = e*share
bysort industry_id: egen double s = total(esh)
foreach v in y0 x0 z0 {
    gen double tmp = esh*`v'
    bysort industry_id: egen double `v'sum = total(tmp)
    gen double `v'bar = `v'sum/s
    drop tmp `v'sum
}

egen byte tagn = tag(industry_id)
keep if tagn
count
scalar nind = r(N)

gen double s2 = s^2
summarize s2, meanonly
scalar effsh = 1/r(sum)

mata:
real rowvector ivhc(real colvector y, real colvector x, real colvector z, real colvector w)
{
    real scalar N
    real matrix X, Z, Pi, Xh, A, G, V
    real colvector b, u
    N = rows(y)
    X = (J(N,1,1), x)
    Z = (J(N,1,1), z)
    Pi = invsym(cross(Z,w,Z)) * cross(Z,w,X)
    Xh = Z*Pi
    A = cross(Xh,w,X)
    b = inverse(A)*cross(Xh,w,y)
    u = y - X*b
    G = Xh :* ((w:*u)*J(1,2,1))
    V = inverse(A)*cross(G,G)*inverse(A)' * N/(N-2)
    return((b[2], sqrt(V[2,2])))
}

real rowvector r1, r2
r1 = ivhc(st_data(.,"y0bar"), st_data(.,"x0bar"), st_data(.,"shock"), st_data(.,"s"))
r2 = ivhc(st_data(.,"x0bar"), st_data(.,"z0bar"), st_data(.,"shock"), st_data(.,"s"))
st_numscalar("eff_b", r1[1])
st_numscalar("eff_se", r1[2])
st_numscalar("fs_se", r2[2])
end

display "ANSWER: effect estimate=" %21.12f eff_b " se=" %21.12f eff_se " n_obs=" %12.0f nind
display "ANSWER: first_stage estimate=" %21.12f fs_b " se=" %21.12f fs_se " n_obs=" %12.0f nind
display "ANSWER: effective_shocks estimate=" %21.12f effsh " se=. n_obs=" %12.0f nind
