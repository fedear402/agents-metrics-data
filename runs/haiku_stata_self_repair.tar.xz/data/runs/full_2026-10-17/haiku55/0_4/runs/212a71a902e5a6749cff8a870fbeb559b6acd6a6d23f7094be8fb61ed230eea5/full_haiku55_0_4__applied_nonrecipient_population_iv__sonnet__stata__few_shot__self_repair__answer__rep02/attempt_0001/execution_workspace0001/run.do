clear all
set more off
set type double

import delimited using "census.csv", clear varnames(1)
summarize nonrecipient_population if eligible==0, meanonly
scalar n0 = r(mean)
summarize nonrecipient_population if eligible==1, meanonly
scalar n1 = r(mean)

import delimited using "households.csv", clear varnames(1)
keep if recipient==0

gen byte elig0 = 1 - eligible
gen double dose_inel = dose*elig0
gen double dose_el = dose*eligible
gen double base_inel = baseline*elig0
gen double base_el = baseline*eligible
gen double inst_inel = instrument*elig0
gen double inst_el = instrument*eligible

ivregress 2sls outcome elig0 eligible base_inel base_el (dose_inel dose_el = inst_inel inst_el) [aw=weight], noconstant

scalar nobs = e(N)
scalar b0 = _b[dose_inel]
scalar b1 = _b[dose_el]

summarize dose [aw=weight] if eligible==0, meanonly
scalar e0 = b0*r(mean)
summarize dose [aw=weight] if eligible==1, meanonly
scalar e1 = b1*r(mean)

scalar pop = (e0*n0 + e1*n1)/(n0 + n1)

display "ANSWER: ineligible_effect estimate=" trim(string(e0, "%24.16g")) " se=NA n_obs=" trim(string(nobs, "%12.0f"))
display "ANSWER: eligible_nonrecipient_effect estimate=" trim(string(e1, "%24.16g")) " se=NA n_obs=" trim(string(nobs, "%12.0f"))
display "ANSWER: population_effect estimate=" trim(string(pop, "%24.16g")) " se=NA n_obs=" trim(string(nobs, "%12.0f"))

exit, clear
