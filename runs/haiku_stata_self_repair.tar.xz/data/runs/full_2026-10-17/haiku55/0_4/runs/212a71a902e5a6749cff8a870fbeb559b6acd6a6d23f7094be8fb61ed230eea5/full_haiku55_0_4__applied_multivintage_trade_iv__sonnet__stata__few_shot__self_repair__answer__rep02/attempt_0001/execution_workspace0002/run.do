clear all
set more off
set type double

import delimited using "crosswalk.csv", clear varnames(1)
capture tostring code industry, replace
tempfile xw
save `xw'

import delimited using "trade.csv", clear varnames(1)
capture tostring code, replace
merge m:1 code using `xw', keep(match) nogenerate
keep period industry us_change other_change price_index years
tempfile tr
save `tr'

use `tr', clear
keep industry
duplicates drop
gen byte one = 1
tempfile ind
save `ind'

import delimited using "employment.csv", clear varnames(1)
capture tostring industry, replace
keep area period vintage industry employment
reshape wide employment, i(area period industry) j(vintage) string
tempfile emp
save `emp'

import delimited using "areas.csv", clear varnames(1)
keep area period vintage total_employment population
reshape wide total_employment population, i(area period) j(vintage) string
rename (total_employmentbase total_employmentearly populationbase) (base_total early_total pop)
gen byte one = 1
joinby one using `ind'
drop one

merge 1:1 area period industry using `emp', keep(master match) nogenerate
replace employmentbase = 0 if missing(employmentbase)
replace employmentearly = 0 if missing(employmentearly)
merge m:1 period industry using `tr', keep(match) nogenerate

bysort period industry: egen double nat_base = total(employmentbase)
bysort period industry: egen double nat_early = total(employmentearly)

gen double xt = (employmentbase/base_total)*(us_change/nat_base)/(price_index/100)/1000*(10/years)
gen double zt = (employmentearly/early_total)*(other_change/nat_early)/(price_index/100)/1000*(10/years)

collapse (sum) x=xt z=zt (mean) pop, by(area period)
tempfile exp
save `exp'

import delimited using "outcomes.csv", clear varnames(1)
keep area period control change_pp
merge 1:1 area period using `exp', keep(match) nogenerate

ivregress 2sls change_pp period control (x = z) [aw=pop]
scalar iv_b = _b[x]
scalar nobs_est = e(N)

summarize x if area==0 & period==0, meanonly
scalar ex00 = r(mean)
summarize x if area==0 & period==1, meanonly
scalar ex01 = r(mean)
summarize z if area==0 & period==0, meanonly
scalar iz00 = r(mean)

display "ANSWER: iv_slope estimate=" strtrim(string(scalar(iv_b), "%24.16g")) " se=NA n_obs=" strtrim(string(scalar(nobs_est), "%12.0f"))
display "ANSWER: exposure_area0_period0 estimate=" strtrim(string(scalar(ex00), "%24.16g")) " se=NA n_obs=" strtrim(string(scalar(nobs_est), "%12.0f"))
display "ANSWER: exposure_area0_period1 estimate=" strtrim(string(scalar(ex01), "%24.16g")) " se=NA n_obs=" strtrim(string(scalar(nobs_est), "%12.0f"))
display "ANSWER: instrument_area0_period0 estimate=" strtrim(string(scalar(iz00), "%24.16g")) " se=NA n_obs=" strtrim(string(scalar(nobs_est), "%12.0f"))
