clear all
set more off
set linesize 255

import delimited using "input.csv", clear varnames(1)

bysort region_id: gen byte rtag = (_n == 1)
gen double rwr = region_weight if rtag == 1
egen double sumrw = total(rwr)
gen double e_r = region_weight / sumrw

gen double share_shock = share * shock
bysort region_id: egen double z = total(share_shock)

egen double ym = total(cond(rtag == 1, e_r * y, 0))
egen double xm = total(cond(rtag == 1, e_r * x, 0))
egen double zm = total(cond(rtag == 1, e_r * z, 0))
gen double y0 = y - ym
gen double x0 = x - xm
gen double z0 = z - zm

preserve
keep if rtag == 1
quietly regress x z [aw = e_r]
scalar fs_est = _b[z]
restore

gen double eS = e_r * share
gen double eY = e_r * share * y0
gen double eX = e_r * share * x0
gen double eZ = e_r * share * z0

preserve
collapse (sum) eS eY eX eZ (mean) shock, by(industry_id)
gen double s = eS
gen double ybar = eY / s
gen double xbar = eX / s
gen double zbar = eZ / s
gen double s2 = s^2

scalar nind = _N

quietly summarize s2, meanonly
scalar eff_sh = 1 / r(sum)

mata:
real rowvector ivfit(real colvector y, real matrix X, real matrix Z, real colvector w)
{
    real matrix ZWZ, XWZ, M, Q, Qu, V
    real colvector b, u
    real scalar N, k

    N = rows(y)
    k = cols(X)
    ZWZ = Z' * (w :* Z)
    XWZ = X' * (w :* Z)
    M = XWZ * invsym(ZWZ) * XWZ'
    Q = invsym(M) * XWZ * invsym(ZWZ) * (Z' :* w')
    b = Q * y
    u = y - X * b
    Qu = Q :* u'
    V = (N / (N - k)) * (Qu * Qu')
    return((b[k], sqrt(V[k, k])))
}

real colvector yv, sv
real matrix Xm, Zm
real rowvector r1, r2
real scalar Nn
yv = st_data(., "ybar")
sv = st_data(., "s")
Nn = rows(yv)
real colvector one
one = J(Nn, 1, 1)
Xm = (one, st_data(., "xbar"))
Zm = (one, st_data(., "shock"))
r1 = ivfit(yv, Xm, Zm, sv)
st_numscalar("eff_b", r1[1])
st_numscalar("eff_se", r1[2])

Xm = (one, st_data(., "zbar"))
r2 = ivfit(st_data(., "xbar"), Xm, Zm, sv)
st_numscalar("fs_se", r2[2])
end

display "ANSWER: effect estimate=" %21.12f eff_b " se=" %21.12f eff_se " n_obs=" %12.0f nind
display "ANSWER: first_stage estimate=" %21.12f fs_est " se=" %21.12f fs_se " n_obs=" %12.0f nind
display "ANSWER: effective_shocks estimate=" %21.12f eff_sh " se=" . " n_obs=" %12.0f nind
restore
