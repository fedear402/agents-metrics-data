version 19.0
clear all
set more off
set linesize 255

import delimited using "input.csv", clear varnames(1)

egen byte tag_r = tag(region_id)
gen double rw_tag = region_weight*tag_r
egen double sum_rw = total(rw_tag)
gen double e = region_weight/sum_rw

gen double shock_share = share*shock
bysort region_id: egen double z = total(shock_share)

gen double ey = e*y*tag_r
gen double ex = e*x*tag_r
gen double ez = e*z*tag_r
egen double my = total(ey)
egen double mx = total(ex)
egen double mz = total(ez)
gen double y0 = y - my
gen double x0 = x - mx
gen double z0 = z - mz

bysort industry_id: egen double s_n = total(e*share)
gen double w_y = e*share*y0
gen double w_x = e*share*x0
gen double w_z = e*share*z0
bysort industry_id: egen double ysum = total(w_y)
bysort industry_id: egen double xsum = total(w_x)
bysort industry_id: egen double zsum = total(w_z)
gen double ybar = ysum/s_n
gen double xbar = xsum/s_n
gen double zbar = zsum/s_n

egen byte tag_n = tag(industry_id)
keep if tag_n

mata:
real rowvector shockiv(real colvector y, real colvector xe, real colvector zi, real colvector w)
{
    real scalar N
    real matrix Z, X, inv, S, V
    real colvector b, res
    N = rows(y)
    Z = J(N,1,1), zi
    X = J(N,1,1), xe
    inv = luinv(Z' * (w:*X))
    b = inv * (Z' * (w:*y))
    res = y - X*b
    S = Z:*(w:*res)
    V = N/(N-2) * inv * (S' * S) * inv'
    return((b[2], sqrt(V[2,2])))
}

real matrix D
real rowvector r1, r2
real scalar effsh

D = st_data(., ("ybar","xbar","zbar","shock","s_n"))
r1 = shockiv(D[,1], D[,2], D[,4], D[,5])
r2 = shockiv(D[,2], D[,3], D[,4], D[,5])
effsh = 1/sum(D[,5]:^2)

st_numscalar("eff_b", r1[1])
st_numscalar("eff_se", r1[2])
st_numscalar("fs_b", r2[1])
st_numscalar("fs_se", r2[2])
st_numscalar("effsh", effsh)
st_numscalar("nind", rows(D))
end

display "ANSWER: effect estimate=" %21.12f eff_b " se=" %21.12f eff_se " n_obs=" %12.0f nind
display "ANSWER: first_stage estimate=" %21.12f fs_b " se=" %21.12f fs_se " n_obs=" %12.0f nind
display "ANSWER: effective_shocks estimate=" %21.12f effsh " se=." " n_obs=" %12.0f nind
