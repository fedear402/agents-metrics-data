clear all
set more off
set linesize 255

import delimited using "./input.csv", clear varnames(1)
tsset t

summarize t, meanonly
local nadd = 251 - r(max)
if `nadd' > 0 {
    tsappend, add(`nadd')
}

arima y, arima(1,1,1) noconstant
scalar nobs = e(N)

predict double fc_level, y
predict double mse_level, mse

quietly summarize fc_level if t == 251, meanonly
scalar fc_val = r(mean)
quietly summarize mse_level if t == 251, meanonly
scalar se_val = sqrt(r(mean))

scalar z95 = invnormal(0.975)
scalar lo_val = fc_val - z95*se_val
scalar hi_val = fc_val + z95*se_val

display "ANSWER: forecast estimate=" %21.12f fc_val " se=" %21.12f se_val " n_obs=" %12.0f nobs
display "ANSWER: lower_95 estimate=" %21.12f lo_val " se=. n_obs=" %12.0f nobs
display "ANSWER: upper_95 estimate=" %21.12f hi_val " se=. n_obs=" %12.0f nobs
