clear all
set more off
set type double

program define cleanup
    quietly ds, has(type string)
    foreach v in `r(varlist)' {
        quietly replace `v' = strtrim(`v')
        capture destring `v', replace
    }
end

import delimited using "crosswalk.csv", clear stringcols(_all) varnames(1)
cleanup
keep code industry
duplicates drop
tempfile xw
save `xw'

import delimited using "trade.csv", clear stringcols(_all) varnames(1)
cleanup
merge m:1 code using `xw', keep(match) nogenerate
keep period industry us_change other_change price_index years
tempfile tr
save `tr'

import delimited using "areas.csv", clear stringcols(_all) varnames(1)
cleanup
keep area period vintage total_employment population
tempfile ar
save `ar'

import delimited using "employment.csv", clear stringcols(_all) varnames(1)
cleanup
keep area period vintage industry employment
tempfile emp
save `emp'

import delimited using "outcomes.csv", clear stringcols(_all) varnames(1)
cleanup
keep area period control change_pp
tempfile oc
save `oc'

use `tr', clear
keep industry
duplicates drop
gen byte _k = 1
tempfile ind
save `ind'

use `ar', clear
keep area period vintage
duplicates drop
gen byte _k = 1
joinby _k using `ind'
drop _k

merge 1:1 area period vintage industry using `emp', keep(master match) nogenerate
replace employment = 0 if missing(employment)
merge m:1 area period vintage using `ar', keep(match) nogenerate
merge m:1 period industry using `tr', keep(match) nogenerate

egen double natemp = total(employment), by(period vintage industry)
gen double share = employment/total_employment
gen double pfac = (10/years)/(price_index/100)/1000
gen double comp = .
replace comp = share*us_change/natemp*pfac if vintage=="base"
replace comp = share*other_change/natemp*pfac if vintage=="early"
gen double xc = comp if vintage=="base"
gen double zc = comp if vintage=="early"
collapse (sum) x=xc z=zc, by(area period)
tempfile ex
save `ex'

use `ar', clear
keep if vintage=="base"
keep area period population
tempfile pop
save `pop'

use `oc', clear
merge 1:1 area period using `ex', keep(match) nogenerate
merge 1:1 area period using `pop', keep(match) nogenerate

ivregress 2sls change_pp period control (x = z) [pweight=population]
local b = _b[x]
local n = e(N)

summarize x if area==0 & period==0, meanonly
local e0 = r(mean)
summarize x if area==0 & period==1, meanonly
local e1 = r(mean)
summarize z if area==0 & period==0, meanonly
local i0 = r(mean)

display "ANSWER: iv_slope estimate=" trim(string(`b', "%20.12f")) " se=NA n_obs=" `n'
display "ANSWER: exposure_area0_period0 estimate=" trim(string(`e0', "%20.12f")) " se=NA n_obs=" `n'
display "ANSWER: exposure_area0_period1 estimate=" trim(string(`e1', "%20.12f")) " se=NA n_obs=" `n'
display "ANSWER: instrument_area0_period0 estimate=" trim(string(`i0', "%20.12f")) " se=NA n_obs=" `n'
