version 19.0
clear all
set more off
set linesize 255

import delimited using "input.csv", clear varnames(1)

keep if abs(score)<1
gen double w = 1 - abs(score)
gen double R = (score>=0)
gen double s = score
gen double Rs = R*s
gen double one = 1
count
local n_obs = r(N)

mata:
X = st_data(., ("one","R","s","Rs"))
w = st_data(., "w")
Y = st_data(., ("earnings","participated"))
bread = invsym(X'*(w:*X))
coefficients = bread*X'*(w:*Y)
residuals = Y - X*coefficients
contrast = (0\1\0\0)
jumps = contrast'*coefficients
loading = w:*(X*bread*contrast)
influence = loading:*residuals
joint = influence'*influence
gradient = (1/jumps[2]\-jumps[1]/jumps[2]^2)
ratio_se = sqrt(gradient'*joint*gradient)
st_numscalar("reduced_est", jumps[1])
st_numscalar("first_est", jumps[2])
st_numscalar("reduced_se", sqrt(joint[1,1]))
st_numscalar("first_se", sqrt(joint[2,2]))
st_numscalar("ratio_est", jumps[1]/jumps[2])
st_numscalar("ratio_se", ratio_se)
end

display "ANSWER: treatment_effect estimate=" %21.12f ratio_est " se=" %21.12f ratio_se " n_obs=" %12.0f `n_obs'
display "ANSWER: reduced_form estimate=" %21.12f reduced_est " se=" %21.12f reduced_se " n_obs=" %12.0f `n_obs'
display "ANSWER: first_stage estimate=" %21.12f first_est " se=" %21.12f first_se " n_obs=" %12.0f `n_obs'
