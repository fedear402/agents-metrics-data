version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear varnames(1)
rename date date_text
generate double day = date(date_text, "YMD")
sort day
generate long t = _n
tsset t

generate double log_vix = ln(vix)
generate double vol_change = D.log_vix
generate double log_sales = ln(sales)

local lagvars ""
forvalues k = 1/15 {
    generate double lag`k' = L`k'.vol_change
    local lagvars "`lagvars' lag`k'"
}

egen int miss = rowmiss(log_sales `lagvars')
keep if miss == 0

mata:
y = st_data(., "log_sales")
X = (J(rows(y), 1, 1), st_data(., tokens(st_local("lagvars"))))
b = qrsolve(X, y)
e = y - X*b
N = rows(X)
p = cols(X)
S = X :* e
meat = S'*S
hac_lags = 15
for (j = 1; j <= hac_lags; j++) {
    lag_product = S[|j+1, 1 \ N, p|]' * S[|1, 1 \ N-j, p|]
    meat = meat + (1 - j/(hac_lags+1)) * (lag_product + lag_product')
}
bread = invsym(X'*X)
V = N/(N-p) * bread * meat * bread
c = (0 \ J(15, 1, 1))
st_numscalar("cum_est", c'*b)
st_numscalar("cum_se", sqrt(c'*V*c))
st_numscalar("lag1_est", b[2])
st_numscalar("lag1_se", sqrt(V[2,2]))
st_numscalar("lag15_est", b[16])
st_numscalar("lag15_se", sqrt(V[16,16]))
st_numscalar("n_used", N)
end

display "ANSWER: cumulative_response estimate=" %21.12f cum_est " se=" %21.12f cum_se " n_obs=" %12.0f n_used
display "ANSWER: lag_1 estimate=" %21.12f lag1_est " se=" %21.12f lag1_se " n_obs=" %12.0f n_used
display "ANSWER: lag_15 estimate=" %21.12f lag15_est " se=" %21.12f lag15_se " n_obs=" %12.0f n_used
