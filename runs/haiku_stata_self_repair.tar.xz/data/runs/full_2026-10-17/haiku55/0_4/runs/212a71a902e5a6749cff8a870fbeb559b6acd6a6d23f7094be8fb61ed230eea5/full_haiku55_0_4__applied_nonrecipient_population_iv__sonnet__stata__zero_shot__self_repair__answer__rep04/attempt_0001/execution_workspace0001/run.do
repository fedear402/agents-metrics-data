clear all
set more off

import delimited using "census.csv", clear varnames(1)
summarize nonrecipient_population if eligible==0, meanonly
scalar N0 = r(mean)
summarize nonrecipient_population if eligible==1, meanonly
scalar N1 = r(mean)

import delimited using "households.csv", clear varnames(1)
keep if recipient==0
drop if missing(outcome, dose, baseline, instrument, weight, eligible)

gen d0  = dose*(1-eligible)
gen d1  = dose*eligible
gen ine = 1-eligible
gen eli = eligible
gen b0  = baseline*(1-eligible)
gen b1  = baseline*eligible
gen z0  = instrument*(1-eligible)
gen z1  = instrument*eligible

ivregress 2sls outcome ine eli b0 b1 (d0 d1 = z0 z1) [aweight=weight], noconstant

scalar n_obs = e(N)
scalar beta0 = _b[d0]
scalar beta1 = _b[d1]

summarize dose [aweight=weight] if eligible==0, meanonly
scalar m0 = r(mean)
summarize dose [aweight=weight] if eligible==1, meanonly
scalar m1 = r(mean)

scalar ineligible_effect = beta0*m0
scalar eligible_nonrecipient_effect = beta1*m1

scalar w0 = N0/(N0+N1)
scalar w1 = N1/(N0+N1)
scalar population_effect = w0*ineligible_effect + w1*eligible_nonrecipient_effect

display "ANSWER: ineligible_effect estimate=" trim(string(ineligible_effect, "%18.12f")) " se=NA n_obs=" trim(string(n_obs, "%12.0f"))
display "ANSWER: eligible_nonrecipient_effect estimate=" trim(string(eligible_nonrecipient_effect, "%18.12f")) " se=NA n_obs=" trim(string(n_obs, "%12.0f"))
display "ANSWER: population_effect estimate=" trim(string(population_effect, "%18.12f")) " se=NA n_obs=" trim(string(n_obs, "%12.0f"))
