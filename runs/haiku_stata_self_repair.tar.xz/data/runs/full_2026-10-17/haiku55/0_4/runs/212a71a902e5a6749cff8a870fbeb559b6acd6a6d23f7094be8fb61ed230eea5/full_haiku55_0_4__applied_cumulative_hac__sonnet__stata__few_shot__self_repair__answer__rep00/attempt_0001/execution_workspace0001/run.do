version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear varnames(1) stringcols(1)

generate double day = date(date, "YMD")
sort day
generate long obs = _n
tsset obs

generate double lvix = ln(vix)
generate double vol_change = D.lvix
generate double log_sales = ln(sales)

forvalues k = 1/15 {
    generate double vc_lag`k' = L`k'.vol_change
}

egen long nobs_full = rownonmiss(vc_lag1-vc_lag15)
keep if !missing(log_sales) & nobs_full == 15 & !missing(vol_change)

local N = _N
local p = 16

mata:
X = (J(st_nobs(), 1, 1), st_data(., ("vc_lag1", "vc_lag2", "vc_lag3", "vc_lag4", "vc_lag5", "vc_lag6", "vc_lag7", "vc_lag8", "vc_lag9", "vc_lag10", "vc_lag11", "vc_lag12", "vc_lag13", "vc_lag14", "vc_lag15")))
y = st_data(., "log_sales")
b = qrsolve(X, y)
e = y - X*b
n = rows(X)
k = cols(X)
S = X:*e
L = 15
meat = S'*S
for (j=1; j<=L; j++) {
    G = S[|j+1,1 \ n,k|]'*S[|1,1 \ n-j,k|]
    meat = meat + (1 - j/(L+1)) * (G + G')
}
bread = invsym(X'*X)
V = n/(n-k) * bread*meat*bread

c = J(k,1,0)
c[2..16] = J(15,1,1)
cum = c'*b
cum_se = sqrt(c'*V*c)

st_numscalar("cum_est", cum)
st_numscalar("cum_se", cum_se)
st_numscalar("l1_est", b[2])
st_numscalar("l1_se", sqrt(V[2,2]))
st_numscalar("l15_est", b[16])
st_numscalar("l15_se", sqrt(V[16,16]))
st_numscalar("nn", n)
end

display "ANSWER: cumulative_response estimate=" %21.12f cum_est " se=" %21.12f cum_se " n_obs=" %12.0f nn
display "ANSWER: lag_1 estimate=" %21.12f l1_est " se=" %21.12f l1_se " n_obs=" %12.0f nn
display "ANSWER: lag_15 estimate=" %21.12f l15_est " se=" %21.12f l15_se " n_obs=" %12.0f nn
