clear all
set more off
set type double

import delimited using "crosswalk.csv", stringcols(_all) clear
destring _all, replace
tempfile cw
save `cw'

import delimited using "trade.csv", stringcols(_all) clear
destring _all, replace
merge m:1 code using `cw', keep(match) nogen
keep period industry us_change other_change price_index years
tempfile trade
save `trade'

use `trade', clear
keep industry
duplicates drop
tempfile inds
save `inds'

import delimited using "employment.csv", stringcols(_all) clear
destring _all, replace
keep area period vintage industry employment
tempfile emp
save `emp'

import delimited using "areas.csv", stringcols(_all) clear
destring _all, replace
keep area period vintage total_employment population
cross using `inds'
merge 1:1 area period vintage industry using `emp', nogen
replace employment = 0 if missing(employment)
merge m:1 period industry using `trade', keep(match) nogen

bysort period vintage industry: egen double nat_emp = total(employment)

gen double share = employment/total_employment
gen double scale = (10/years)/(price_index/100)/1000
gen double tx = share*(us_change/nat_emp)*scale if vintage=="base"
gen double tz = share*(other_change/nat_emp)*scale if vintage=="early"
gen double pw = population if vintage=="base"

collapse (sum) x=tx z=tz (mean) pw, by(area period)
tempfile expo
save `expo'

import delimited using "outcomes.csv", stringcols(_all) clear
destring _all, replace
keep area period control change_pp
merge 1:1 area period using `expo', keep(match) nogen

ivregress 2sls change_pp period control (x = z) [aw=pw]
local nobs = e(N)
local bx = _b[x]

summarize x if area==0 & period==0, meanonly
local e00 = r(mean)
summarize x if area==0 & period==1, meanonly
local e01 = r(mean)
summarize z if area==0 & period==0, meanonly
local z00 = r(mean)

display "ANSWER: iv_slope estimate=" strtrim(string(`bx', "%20.12g")) " se=NA n_obs=" `nobs'
display "ANSWER: exposure_area0_period0 estimate=" strtrim(string(`e00', "%20.12g")) " se=NA n_obs=" `nobs'
display "ANSWER: exposure_area0_period1 estimate=" strtrim(string(`e01', "%20.12g")) " se=NA n_obs=" `nobs'
display "ANSWER: instrument_area0_period0 estimate=" strtrim(string(`z00', "%20.12g")) " se=NA n_obs=" `nobs'
