clear all
set more off
set type double

import delimited using "crosswalk.csv", clear varnames(1)
capture tostring code, replace
capture tostring industry, replace
keep code industry
duplicates drop code, force
tempfile xw
save `xw'

use `xw', clear
keep industry
duplicates drop
gen byte one = 1
tempfile ind
save `ind'

import delimited using "trade.csv", clear varnames(1)
capture tostring code, replace
capture destring period, replace
merge m:1 code using `xw', keep(match) nogenerate
keep period industry us_change other_change price_index years
duplicates drop period industry, force
tempfile tr
save `tr'

import delimited using "areas.csv", clear varnames(1)
capture destring area period, replace
keep area period vintage total_employment population
preserve
keep if vintage == "base"
keep area period population
tempfile pop
save `pop'
restore
drop population
tempfile ar
save `ar'

use `ar', clear
gen byte one = 1
joinby one using `ind'
drop one

import delimited using "employment.csv", clear varnames(1)
capture destring area period, replace
capture tostring industry, replace
keep area period vintage industry employment
tempfile emp
save `emp'

use `ar', clear
gen byte one = 1
joinby one using `ind'
drop one
merge 1:1 area period vintage industry using `emp', keep(master match) nogenerate
replace employment = 0 if missing(employment)

merge m:1 period industry using `tr', keep(match) nogenerate

bysort period vintage industry: egen double natl = total(employment)
gen double scale = (10/years)/(price_index/100)/1000
gen double x = cond(vintage == "base", employment/total_employment*us_change/natl*scale, 0)
gen double z = cond(vintage == "early", employment/total_employment*other_change/natl*scale, 0)

collapse (sum) x z, by(area period)

merge 1:1 area period using `pop', keep(match) nogenerate

import delimited using "outcomes.csv", clear varnames(1)
capture destring area period, replace
keep area period control change_pp
tempfile outs
save `outs'

use `ar', clear
keep area period
duplicates drop
tempfile dummy
save `dummy'

clear
use `pop'
merge 1:1 area period using `outs', keep(match) nogenerate
tempfile base_rows
save `base_rows'

use `base_rows', clear
merge 1:1 area period using `outs', keep(match) nogenerate
exit, clear
