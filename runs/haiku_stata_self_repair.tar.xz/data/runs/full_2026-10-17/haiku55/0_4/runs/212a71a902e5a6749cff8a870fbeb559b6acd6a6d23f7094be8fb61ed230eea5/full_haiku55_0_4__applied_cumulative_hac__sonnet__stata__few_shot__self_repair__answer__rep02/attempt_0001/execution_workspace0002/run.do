version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear varnames(1) stringcols(1)

generate double day = date(date, "YMD")
sort day
generate long obs = _n
tsset obs

generate double log_vix = ln(vix)
generate double vix_change = D.log_vix
generate double log_sales = ln(sales)

local lagnames ""
forvalues k = 1/15 {
    generate double lag_`k' = L`k'.vix_change
    local lagnames "`lagnames' lag_`k'"
}

egen double any_missing = rowmiss(log_sales `lagnames')
keep if any_missing == 0
drop any_missing

mata:
y = st_data(., "log_sales")
X = (J(rows(y), 1, 1), st_data(., tokens("`lagnames'")))
b = qrsolve(X, y)
e = y - X*b
N = rows(X)
p = cols(X)
S = X:*e
meat = S'*S
for (j = 1; j <= 15; j++) {
    w = 1 - j/16
    G = S[|j+1,1 \ N,p|]'*S[|1,1 \ N-j,p|]
    meat = meat + w*(G + G')
}
bread = invsym(X'*X)
V = (N/(N-16)) * bread * meat * bread

c = J(p, 1, 0)
c[2::p] = J(15, 1, 1)
cum_est = c'*b
cum_se = sqrt(c'*V*c)

st_numscalar("r_cum_est", cum_est)
st_numscalar("r_cum_se", cum_se)
st_numscalar("r_lag1_est", b[2])
st_numscalar("r_lag1_se", sqrt(V[2,2]))
st_numscalar("r_lag15_est", b[16])
st_numscalar("r_lag15_se", sqrt(V[16,16]))
st_numscalar("r_N", N)
end

display "ANSWER: cumulative_response estimate=" %21.12f r_cum_est " se=" %21.12f r_cum_se " n_obs=" %12.0f r_N
display "ANSWER: lag_1 estimate=" %21.12f r_lag1_est " se=" %21.12f r_lag1_se " n_obs=" %12.0f r_N
display "ANSWER: lag_15 estimate=" %21.12f r_lag15_est " se=" %21.12f r_lag15_se " n_obs=" %12.0f r_N
