clear all
set linesize 255

import delimited using "./input.csv", clear varnames(1)

capture confirm string variable date
if _rc == 0 {
    gen double dt = date(date, "YMD")
}
else {
    gen double dt = date
}
sort dt

gen double lnsales = ln(sales)
gen double dlvix = ln(vix) - ln(vix[_n-1]) if _n > 1
forvalues k = 1/15 {
    gen double lag`k' = dlvix[_n-`k'] if _n > `k'
}

gen byte touse = !missing(lnsales, lag1, lag2, lag3, lag4, lag5, lag6, lag7, lag8, lag9, lag10, lag11, lag12, lag13, lag14, lag15)

newey lnsales lag1-lag15 if touse, lag(15)

scalar N = e(N)
matrix b = e(b)
matrix V = e(V) * (N / (N - 16))
local k = colsof(b)
local cn : colnames b

matrix c = J(1, `k', 0)
forvalues j = 1/`k' {
    local nm : word `j' of `cn'
    if regexm("`nm'", "^lag[0-9]+$") {
        matrix c[1, `j'] = 1
    }
}

matrix cb = c * b'
matrix cv = c * V * c'
scalar cum_est = cb[1,1]
scalar cum_se = sqrt(cv[1,1])

local p1 = colnumb(b, "lag1")
local p15 = colnumb(b, "lag15")
scalar lag1_est = b[1, `p1']
scalar lag1_se = sqrt(V[`p1', `p1'])
scalar lag15_est = b[1, `p15']
scalar lag15_se = sqrt(V[`p15', `p15'])

display "ANSWER: cumulative_response estimate=" %21.12f cum_est " se=" %21.12f cum_se " n_obs=" %12.0f N
display "ANSWER: lag_1 estimate=" %21.12f lag1_est " se=" %21.12f lag1_se " n_obs=" %12.0f N
display "ANSWER: lag_15 estimate=" %21.12f lag15_est " se=" %21.12f lag15_se " n_obs=" %12.0f N
