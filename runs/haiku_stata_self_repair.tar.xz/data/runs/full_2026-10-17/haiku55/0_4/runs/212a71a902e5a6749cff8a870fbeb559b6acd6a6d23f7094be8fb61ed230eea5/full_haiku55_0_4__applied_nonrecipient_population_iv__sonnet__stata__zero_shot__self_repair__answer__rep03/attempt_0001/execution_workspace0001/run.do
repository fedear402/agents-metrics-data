clear all
set more off

import delimited using "census.csv", clear varnames(1)
keep eligible nonrecipient_population
tempfile census
save `census'

use `census', clear
summarize nonrecipient_population if eligible==0, meanonly
scalar N0 = r(mean)
summarize nonrecipient_population if eligible==1, meanonly
scalar N1 = r(mean)

import delimited using "households.csv", clear varnames(1)
keep if recipient==0

gen x0 = 1-eligible
gen x1 = eligible
gen d0 = dose*(1-eligible)
gen d1 = dose*eligible
gen b0 = baseline*(1-eligible)
gen b1 = baseline*eligible
gen z0 = instrument*(1-eligible)
gen z1 = instrument*eligible

ivregress 2sls outcome x0 x1 b0 b1 (d0 d1 = z0 z1) [aweight=weight], noconstant
scalar nobs = e(N)
scalar s0 = _b[d0]
scalar s1 = _b[d1]

quietly summarize dose [aweight=weight] if eligible==0
scalar m0 = r(mean)
quietly summarize dose [aweight=weight] if eligible==1
scalar m1 = r(mean)

scalar eff0 = s0*m0
scalar eff1 = s1*m1
scalar pop_eff = (N0*eff0 + N1*eff1)/(N0 + N1)

display "ANSWER: ineligible_effect estimate=" trim(string(eff0,"%18.12f")) " se=NA n_obs=" trim(string(nobs,"%12.0f"))
display "ANSWER: eligible_nonrecipient_effect estimate=" trim(string(eff1,"%18.12f")) " se=NA n_obs=" trim(string(nobs,"%12.0f"))
display "ANSWER: population_effect estimate=" trim(string(pop_eff,"%18.12f")) " se=NA n_obs=" trim(string(nobs,"%12.0f"))
