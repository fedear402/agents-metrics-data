clear all
set more off

import delimited using "households.csv", clear varnames(1)
keep if recipient==0

gen double e0 = 1-eligible
gen double e1 = eligible
gen double d0 = dose*(1-eligible)
gen double d1 = dose*eligible
gen double bl0 = baseline*(1-eligible)
gen double bl1 = baseline*eligible
gen double iv0 = instrument*(1-eligible)
gen double iv1 = instrument*eligible

ivregress 2sls outcome e0 e1 bl0 bl1 (d0 d1 = iv0 iv1) [aw=weight], noconstant
scalar n_obs = e(N)
scalar slope0 = _b[d0]
scalar slope1 = _b[d1]

summarize dose [aw=weight] if eligible==0, meanonly
scalar mdose0 = r(mean)
summarize dose [aw=weight] if eligible==1, meanonly
scalar mdose1 = r(mean)

scalar ineligible_eff = slope0*mdose0
scalar eligible_eff = slope1*mdose1

import delimited using "census.csv", clear varnames(1)
summarize nonrecipient_population if eligible==0, meanonly
scalar pop0 = r(mean)
summarize nonrecipient_population if eligible==1, meanonly
scalar pop1 = r(mean)

scalar population_eff = (ineligible_eff*pop0 + eligible_eff*pop1)/(pop0+pop1)

display "ANSWER: ineligible_effect estimate=" trim(string(ineligible_eff,"%24.16g")) " se=NA n_obs=" trim(string(n_obs,"%12.0f"))
display "ANSWER: eligible_nonrecipient_effect estimate=" trim(string(eligible_eff,"%24.16g")) " se=NA n_obs=" trim(string(n_obs,"%12.0f"))
display "ANSWER: population_effect estimate=" trim(string(population_eff,"%24.16g")) " se=NA n_obs=" trim(string(n_obs,"%12.0f"))

exit, clear
