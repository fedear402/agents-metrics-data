clear all
set more off
set linesize 255

import delimited using "input.csv", clear varnames(1)
keep if !missing(score) & !missing(participated) & !missing(earnings)
keep if abs(score) < 1
gen double w = 1 - abs(score)
gen byte right = score >= 0

count
scalar n_total = r(N)

mata:
real matrix side_cov(real colvector s, real colvector w, real colvector y, real colvector t)
{
    real matrix X, A, U, Ablk
    real colvector ey, et
    real colvector by, bt

    X = J(rows(s), 1, 1), s
    A = invsym(cross(X, w, X))
    by = A * cross(X, w, y)
    bt = A * cross(X, w, t)
    ey = y - X * by
    et = t - X * bt
    U = (X :* (w :* ey), X :* (w :* et))
    Ablk = (A, J(2,2,0) \ J(2,2,0), A)
    return(Ablk * (U' * U) * Ablk')
}

real colvector side_coef(real colvector s, real colvector w, real colvector y)
{
    real matrix X
    X = J(rows(s), 1, 1), s
    return(invsym(cross(X, w, X)) * cross(X, w, y))
}

s = st_data(., "score")
w = st_data(., "w")
y = st_data(., "earnings")
t = st_data(., "participated")
rt = st_data(., "right")

sR = select(s, rt :== 1);  wR = select(w, rt :== 1)
yR = select(y, rt :== 1);  tR = select(t, rt :== 1)
sL = select(s, rt :== 0);  wL = select(w, rt :== 0)
yL = select(y, rt :== 0);  tL = select(t, rt :== 0)

bYR = side_coef(sR, wR, yR)
bYL = side_coef(sL, wL, yL)
bTR = side_coef(sR, wR, tR)
bTL = side_coef(sL, wL, tL)

ry = bYR[1];  ly = bYL[1]
rtt = bTR[1]; ltt = bTL[1]

CR = side_cov(sR, wR, yR, tR)
CL = side_cov(sL, wL, yL, tL)

V = J(4, 4, 0)
V[1,1] = CR[1,1]; V[1,3] = CR[1,3]; V[3,1] = CR[3,1]; V[3,3] = CR[3,3]
V[2,2] = CL[1,1]; V[2,4] = CL[1,3]; V[4,2] = CL[3,1]; V[4,4] = CL[3,3]

red = ry - ly
fs = rtt - ltt
te = red / fs

c1 = (1, -1, 0, 0)
c2 = (0, 0, 1, -1)
c3 = (1/fs, -1/fs, -te/fs, te/fs)

st_numscalar("red", red)
st_numscalar("red_se", sqrt(c1 * V * c1'))
st_numscalar("fs", fs)
st_numscalar("fs_se", sqrt(c2 * V * c2'))
st_numscalar("te", te)
st_numscalar("te_se", sqrt(c3 * V * c3'))
end

display "ANSWER: treatment_effect estimate=" %21.12f te " se=" %21.12f te_se " n_obs=" %12.0f n_total
display "ANSWER: reduced_form estimate=" %21.12f red " se=" %21.12f red_se " n_obs=" %12.0f n_total
display "ANSWER: first_stage estimate=" %21.12f fs " se=" %21.12f fs_se " n_obs=" %12.0f n_total
