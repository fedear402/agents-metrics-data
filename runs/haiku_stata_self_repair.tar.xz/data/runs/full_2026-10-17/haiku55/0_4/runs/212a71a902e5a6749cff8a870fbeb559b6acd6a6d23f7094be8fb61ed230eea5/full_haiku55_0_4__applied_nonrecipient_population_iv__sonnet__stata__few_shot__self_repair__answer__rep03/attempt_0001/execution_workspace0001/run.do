clear all
set more off

import delimited using "households.csv", clear varnames(1)
keep if recipient==0

gen double g0  = 1 - eligible
gen double g1  = eligible
gen double bl0 = baseline*g0
gen double bl1 = baseline*g1
gen double d0  = dose*g0
gen double d1  = dose*g1
gen double iv0 = instrument*g0
gen double iv1 = instrument*g1

ivregress 2sls outcome g0 g1 bl0 bl1 (d0 d1 = iv0 iv1) [aw=weight], noconstant

local nobs = e(N)
gen byte insamp = e(sample)
scalar b0 = _b[d0]
scalar b1 = _b[d1]

summarize dose [aw=weight] if (insamp==1) & (eligible==0), meanonly
scalar e0 = b0*r(mean)
summarize dose [aw=weight] if (insamp==1) & (eligible==1), meanonly
scalar e1 = b1*r(mean)

import delimited using "census.csv", clear varnames(1)
summarize nonrecipient_population if eligible==0, meanonly
scalar n0 = r(mean)
summarize nonrecipient_population if eligible==1, meanonly
scalar n1 = r(mean)

scalar popeff = (e0*n0 + e1*n1)/(n0 + n1)

display "ANSWER: ineligible_effect estimate=" strtrim(string(e0,"%24.16g")) " se=NA n_obs=`nobs'"
display "ANSWER: eligible_nonrecipient_effect estimate=" strtrim(string(e1,"%24.16g")) " se=NA n_obs=`nobs'"
display "ANSWER: population_effect estimate=" strtrim(string(popeff,"%24.16g")) " se=NA n_obs=`nobs'"
