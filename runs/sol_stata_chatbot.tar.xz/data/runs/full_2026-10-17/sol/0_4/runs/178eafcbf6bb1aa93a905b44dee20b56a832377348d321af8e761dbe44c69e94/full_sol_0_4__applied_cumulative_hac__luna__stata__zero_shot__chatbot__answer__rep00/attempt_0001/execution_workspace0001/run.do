set linesize 255
import delimited "./input.csv", clear
sort date

generate double log_sales = ln(sales)
generate double dlog_vix = ln(vix) - ln(vix[_n-1])
generate double x0 = 1

forvalues j = 1/15 {
    generate double x`j' = dlog_vix[_n-`j']
}

quietly regress log_sales x1-x15
generate byte sample = e(sample)

mata:
    X = st_data(., tokens("x0 x1 x2 x3 x4 x5 x6 x7 x8 x9 x10 x11 x12 x13 x14 x15"), "sample")
    y = st_data(., "log_sales", "sample")
    N = rows(X)

    XXinv = invsym(X' * X)
    b = XXinv * X' * y
    u = y - X * b
    Z = X :* (u * J(1, cols(X), 1))

    S = Z' * Z
    for (j = 1; j <= 15; j++) {
        G = Z[(j+1)..N, .]' * Z[1..(N-j), .]
        S = S + (1 - j/16) * (G + G')
    }

    V = (N/(N-16)) * XXinv * S * XXinv
    c = J(15, 1, 1)

    st_numscalar("n_obs", N)
    st_numscalar("cumulative_response", sum(b[2..16]))
    st_numscalar("cumulative_se", sqrt(c' * V[|2,2\16,16|] * c))
    st_numscalar("lag_1", b[2])
    st_numscalar("lag_1_se", sqrt(V[2,2]))
    st_numscalar("lag_15", b[16])
    st_numscalar("lag_15_se", sqrt(V[16,16]))
end

display "ANSWER: cumulative_response estimate=" %21.12f cumulative_response " se=" %21.12f cumulative_se " n_obs=" %12.0f n_obs
display "ANSWER: lag_1 estimate=" %21.12f lag_1 " se=" %21.12f lag_1_se " n_obs=" %12.0f n_obs
display "ANSWER: lag_15 estimate=" %21.12f lag_15 " se=" %21.12f lag_15_se " n_obs=" %12.0f n_obs
