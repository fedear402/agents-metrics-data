clear all
set more off

tempfile industry_trade industries employment_data

import delimited "crosswalk.csv", clear
isid code
preserve
    keep industry
    duplicates drop
    save `industries'
restore

merge 1:m code using "trade.csv"
keep if _merge == 3
drop _merge
isid period industry
save `industry_trade'

import delimited "employment.csv", clear
isid area period vintage industry
save `employment_data'

import delimited "areas.csv", clear
isid area period vintage
cross using `industries'

merge 1:1 area period vintage industry using `employment_data'
replace employment = 0 if missing(employment)
drop _merge

merge m:1 period industry using `industry_trade'
keep if _merge == 3
drop _merge

bysort period vintage industry: egen double national_employment = total(employment)
assert national_employment > 0

generate double exposure_part = ///
    (employment / total_employment) * ///
    (cond(vintage == "base", us_change, other_change) / national_employment) / ///
    (price_index / 100) / 1000 * (10 / years)

collapse (sum) exposure_part (first) population, by(area period vintage)
reshape wide exposure_part population, i(area period) j(vintage) string

rename exposure_partbase x
rename exposure_partearly z

merge 1:1 area period using "outcomes.csv"
keep if _merge == 3
drop _merge

quietly summarize x if area == 0 & period == 0, meanonly
scalar exposure_area0_period0 = r(mean)
quietly summarize x if area == 0 & period == 1, meanonly
scalar exposure_area0_period1 = r(mean)
quietly summarize z if area == 0 & period == 0, meanonly
scalar instrument_area0_period0 = r(mean)

ivregress 2sls change_pp period control (x = z) [aw = populationbase]
assert e(N) == 72
scalar iv_slope = _b[x]

display "ANSWER: iv_slope estimate=" %21.12g scalar(iv_slope) " se=NA n_obs=72"
display "ANSWER: exposure_area0_period0 estimate=" %21.12g scalar(exposure_area0_period0) " se=NA n_obs=72"
display "ANSWER: exposure_area0_period1 estimate=" %21.12g scalar(exposure_area0_period1) " se=NA n_obs=72"
display "ANSWER: instrument_area0_period0 estimate=" %21.12g scalar(instrument_area0_period0) " se=NA n_obs=72"
