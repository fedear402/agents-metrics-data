clear all
set more off
set linesize 255

import delimited using "./input.csv", clear
keep if !missing(score, participated, earnings) & abs(score) < 1

generate double weight = 1 - abs(score)
generate byte right = score >= 0
generate double score_right = score * right

mata:
    X = (J(st_nobs(), 1, 1), st_data(., "right"), ///
         st_data(., "score"), st_data(., "score_right"))
    w = st_data(., "weight")
    y = st_data(., "earnings")
    d = st_data(., "participated")

    bread = invsym(quadcross(X, w, X))
    by = bread * quadcross(X, w, y)
    bd = bread * quadcross(X, w, d)
    ey = y - X * by
    ed = d - X * bd

    Vy = bread * quadcross(X, (w:^2) :* (ey:^2), X) * bread
    Vd = bread * quadcross(X, (w:^2) :* (ed:^2), X) * bread
    Cyd = bread * quadcross(X, (w:^2) :* ey :* ed, X) * bread

    rf = by[2]
    fs = bd[2]
    te = rf / fs

    st_numscalar("reduced_form", rf)
    st_numscalar("first_stage", fs)
    st_numscalar("treatment_effect", te)
    st_numscalar("reduced_form_se", sqrt(Vy[2,2]))
    st_numscalar("first_stage_se", sqrt(Vd[2,2]))
    st_numscalar("treatment_effect_se", ///
        sqrt(Vy[2,2]/fs^2 + rf^2*Vd[2,2]/fs^4 - ///
             2*rf*Cyd[2,2]/fs^3))
    st_numscalar("n_obs", st_nobs())
end

display "ANSWER: treatment_effect estimate=" %21.12f treatment_effect " se=" %21.12f treatment_effect_se " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f reduced_form " se=" %21.12f reduced_form_se " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f first_stage " se=" %21.12f first_stage_se " n_obs=" %12.0f n_obs
