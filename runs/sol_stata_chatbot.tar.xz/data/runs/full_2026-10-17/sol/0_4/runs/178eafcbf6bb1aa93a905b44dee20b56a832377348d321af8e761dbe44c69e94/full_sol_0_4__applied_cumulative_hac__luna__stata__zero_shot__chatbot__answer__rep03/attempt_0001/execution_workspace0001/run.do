set linesize 255

import delimited using "./input.csv", clear
sort date

generate double ln_sales = ln(sales)
generate double dln_vix = ln(vix) - ln(vix[_n-1])

local xvars
forvalues j = 1/15 {
    generate double lag_`j' = dln_vix[_n-`j']
    local xvars `xvars' lag_`j'
}

regress ln_sales `xvars'
generate byte sample = e(sample)
predict double residual if sample, residuals

scalar n_obs = e(N)
scalar cumulative_response = 0
forvalues j = 1/15 {
    scalar cumulative_response = cumulative_response + _b[lag_`j']
}
scalar estimate_lag_1 = _b[lag_1]
scalar estimate_lag_15 = _b[lag_15]

mata:
    Z = st_data(., tokens(st_local("xvars")), "sample")
    u = st_data(., "residual", "sample")
    N = rows(Z)
    X = J(N, 1, 1), Z
    Xu = X :* u
    S = quadcross(Xu, Xu)

    for (j = 1; j <= 15; j++) {
        C = quadcross(Xu[(j+1)..N, .], Xu[1..(N-j), .])
        S = S + (1 - j/16) * (C + C')
    }

    A = invsym(quadcross(X, X))
    V = (N/(N-16)) * A * S * A

    st_numscalar("se_cumulative", sqrt(sum(V)))
    st_numscalar("se_lag_1", sqrt(V[2,2]))
    st_numscalar("se_lag_15", sqrt(V[16,16]))
end

display "ANSWER: cumulative_response estimate=" %21.12f cumulative_response " se=" %21.12f se_cumulative " n_obs=" %12.0f n_obs
display "ANSWER: lag_1 estimate=" %21.12f estimate_lag_1 " se=" %21.12f se_lag_1 " n_obs=" %12.0f n_obs
display "ANSWER: lag_15 estimate=" %21.12f estimate_lag_15 " se=" %21.12f se_lag_15 " n_obs=" %12.0f n_obs
