clear all
set more off

tempfile areas_data industries trade_data employment_data weights exposures outcomes_data

import delimited "areas.csv", clear
save `areas_data'

preserve
    keep if vintage == "base"
    keep area period population
    isid area period
    save `weights'
restore

import delimited "crosswalk.csv", clear
isid code
preserve
    keep industry
    duplicates drop
    save `industries'
restore
save `trade_data'

import delimited "trade.csv", clear
merge m:1 code using `trade_data', assert(match) nogen
isid period industry
save `trade_data'

import delimited "employment.csv", clear
isid area period vintage industry
save `employment_data'

use `areas_data', clear
cross using `industries'
merge 1:1 area period vintage industry using `employment_data', ///
    assert(master match) nogen
replace employment = 0 if missing(employment)

bysort period vintage industry: egen double national_employment = total(employment)
merge m:1 period industry using `trade_data', assert(match) nogen

generate double x = 0
replace x = (employment / total_employment) * ///
    (us_change / national_employment) / (price_index / 100) / 1000 * ///
    (10 / years) if vintage == "base"

generate double z = 0
replace z = (employment / total_employment) * ///
    (other_change / national_employment) / (price_index / 100) / 1000 * ///
    (10 / years) if vintage == "early"

collapse (sum) x z, by(area period)
save `exposures'

import delimited "outcomes.csv", clear
merge 1:1 area period using `exposures', assert(match) nogen
merge 1:1 area period using `weights', assert(match) nogen

assert _N == 72
assert !missing(change_pp, period, control, x, z, population)
assert population > 0

quietly summarize x if area == 0 & period == 0, meanonly
assert r(N) == 1
scalar exposure_area0_period0 = r(mean)

quietly summarize x if area == 0 & period == 1, meanonly
assert r(N) == 1
scalar exposure_area0_period1 = r(mean)

quietly summarize z if area == 0 & period == 0, meanonly
assert r(N) == 1
scalar instrument_area0_period0 = r(mean)

quietly ivregress 2sls change_pp period control (x = z) [aweight = population]
assert e(N) == 72
scalar iv_slope = _b[x]

display "ANSWER: iv_slope estimate=" %21.12g scalar(iv_slope) " se=NA n_obs=72"
display "ANSWER: exposure_area0_period0 estimate=" %21.12g scalar(exposure_area0_period0) " se=NA n_obs=72"
display "ANSWER: exposure_area0_period1 estimate=" %21.12g scalar(exposure_area0_period1) " se=NA n_obs=72"
display "ANSWER: instrument_area0_period0 estimate=" %21.12g scalar(instrument_area0_period0) " se=NA n_obs=72"
