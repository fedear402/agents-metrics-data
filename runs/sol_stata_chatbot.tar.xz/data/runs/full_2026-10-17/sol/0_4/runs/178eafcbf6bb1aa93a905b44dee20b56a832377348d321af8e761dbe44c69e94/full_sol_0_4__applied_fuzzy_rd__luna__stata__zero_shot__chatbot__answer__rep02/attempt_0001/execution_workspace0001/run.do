set linesize 255
import delimited using "./input.csv", clear

keep if !missing(score, participated, earnings) & abs(score) < 1
generate double weight = 1 - abs(score)
generate byte right = score >= 0
generate double right_score = right * score

mata:
    X = st_data(., ("right", "score", "right_score"))
    X = J(rows(X), 1, 1), X
    Y = st_data(., ("earnings", "participated"))
    w = st_data(., "weight")

    A = invsym(quadcross(X, w, X))
    B = A * quadcross(X, w, Y)
    E = Y - X * B

    Sy = X :* (w :* E[, 1])
    Sd = X :* (w :* E[, 2])

    Vyy = A * quadcross(Sy, Sy) * A
    Vdd = A * quadcross(Sd, Sd) * A
    Vyd = A * quadcross(Sy, Sd) * A

    rf = B[2, 1]
    fs = B[2, 2]
    vrf = Vyy[2, 2]
    vfs = Vdd[2, 2]

    st_numscalar("n_obs", rows(X))
    st_numscalar("reduced_form", rf)
    st_numscalar("first_stage", fs)
    st_numscalar("se_reduced_form", sqrt(max((0, vrf))))
    st_numscalar("se_first_stage", sqrt(max((0, vfs))))

    if (fs != 0) {
        vte = vrf / fs^2 + rf^2 * vfs / fs^4 - 2 * rf * Vyd[2, 2] / fs^3
        st_numscalar("treatment_effect", rf / fs)
        st_numscalar("se_treatment_effect", sqrt(max((0, vte))))
    }
    else {
        st_numscalar("treatment_effect", .)
        st_numscalar("se_treatment_effect", .)
    }
end

display "ANSWER: treatment_effect estimate=" %21.12f treatment_effect " se=" %21.12f se_treatment_effect " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f reduced_form " se=" %21.12f se_reduced_form " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f first_stage " se=" %21.12f se_first_stage " n_obs=" %12.0f n_obs
