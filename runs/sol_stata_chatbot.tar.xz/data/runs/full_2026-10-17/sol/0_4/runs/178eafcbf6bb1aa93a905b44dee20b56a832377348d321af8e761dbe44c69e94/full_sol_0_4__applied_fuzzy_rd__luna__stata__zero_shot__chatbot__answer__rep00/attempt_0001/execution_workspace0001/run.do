set linesize 255
import delimited "./input.csv", clear

keep if !missing(score, participated, earnings) & abs(score) < 1
generate double weight = 1 - abs(score)
generate byte right = score >= 0

mata:
    s = st_data(., "score")
    r = st_data(., "right")
    w = st_data(., "weight")
    y = st_data(., "earnings")
    d = st_data(., "participated")

    X = (J(rows(s), 1, 1), r, s, r :* s)
    B = invsym(quadcross(X, w, X))
    by = B * quadcross(X, w, y)
    bd = B * quadcross(X, w, d)
    uy = y - X * by
    ud = d - X * bd

    vy = B * quadcross(X, (w :^ 2) :* (uy :^ 2), X) * B
    vd = B * quadcross(X, (w :^ 2) :* (ud :^ 2), X) * B
    cyd = B * quadcross(X, (w :^ 2) :* uy :* ud, X) * B

    rf = by[2]
    fs = bd[2]
    rf_se = sqrt(vy[2,2])
    fs_se = sqrt(vd[2,2])
    te = .
    te_se = .
    if (fs != 0) {
        te = rf / fs
        te_var = vy[2,2] / fs^2 + rf^2 * vd[2,2] / fs^4 ///
            - 2 * rf * cyd[2,2] / fs^3
        te_se = sqrt(max((0, te_var)))
    }

    st_numscalar("reduced_form", rf)
    st_numscalar("reduced_form_se", rf_se)
    st_numscalar("first_stage", fs)
    st_numscalar("first_stage_se", fs_se)
    st_numscalar("treatment_effect", te)
    st_numscalar("treatment_effect_se", te_se)
    st_numscalar("n_obs", rows(s))
end

display "ANSWER: treatment_effect estimate=" %21.12f treatment_effect " se=" %21.12f treatment_effect_se " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f reduced_form " se=" %21.12f reduced_form_se " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f first_stage " se=" %21.12f first_stage_se " n_obs=" %12.0f n_obs
