clear all
set more off
set type double

import delimited "households.csv", clear
keep if recipient == 0

generate double g0 = 1 - eligible
generate double g1 = eligible
generate double base0 = baseline * g0
generate double base1 = baseline * g1
generate double dose0 = dose * g0
generate double dose1 = dose * g1
generate double inst0 = instrument * g0
generate double inst1 = instrument * g1

ivregress 2sls outcome g0 g1 base0 base1 ///
    (dose0 dose1 = inst0 inst1) [aw=weight], noconstant

generate byte estimation_sample = e(sample)
count if estimation_sample
scalar n_obs = r(N)

summarize dose [aw=weight] if estimation_sample & eligible == 0, meanonly
scalar ineligible_effect = _b[dose0] * r(mean)

summarize dose [aw=weight] if estimation_sample & eligible == 1, meanonly
scalar eligible_nonrecipient_effect = _b[dose1] * r(mean)

import delimited "census.csv", clear
quietly summarize nonrecipient_population if eligible == 0, meanonly
scalar n0 = r(sum)
quietly summarize nonrecipient_population if eligible == 1, meanonly
scalar n1 = r(sum)

scalar population_effect = ///
    (ineligible_effect * n0 + eligible_nonrecipient_effect * n1) / (n0 + n1)

display "ANSWER: ineligible_effect estimate=" ///
    %24.16g ineligible_effect " se=NA n_obs=" %12.0f n_obs
display "ANSWER: eligible_nonrecipient_effect estimate=" ///
    %24.16g eligible_nonrecipient_effect " se=NA n_obs=" %12.0f n_obs
display "ANSWER: population_effect estimate=" ///
    %24.16g population_effect " se=NA n_obs=" %12.0f n_obs
