clear all
set more off
set linesize 255

import delimited "./input.csv", clear

generate double share_shock = share * shock
bysort region_id: egen double z = total(share_shock)

tempfile regions
preserve
bysort region_id: keep if _n == 1

egen double weight_total = total(region_weight)
generate double e = region_weight / weight_total

generate double ex = e * x
generate double ey = e * y
generate double ez = e * z
egen double mean_x = total(ex)
egen double mean_y = total(ey)
egen double mean_z = total(ez)

generate double x0 = x - mean_x
generate double y0 = y - mean_y
generate double z0 = z - mean_z

keep region_id e x0 y0 z0
save `regions'
restore

merge m:1 region_id using `regions', assert(match) nogen

generate double es = e * share
generate double sx = es * x0
generate double sy = es * y0
generate double sz = es * z0

collapse (sum) s=es sx sy sz (firstnm) shock, by(industry_id)

generate double xbar = sx / s
generate double ybar = sy / s
generate double zbar = sz / s

scalar N = _N
generate double s2 = s^2
quietly summarize s2, meanonly
scalar effective_shocks = 1 / r(sum)

generate double sg = s * shock
generate double sxbar = s * xbar
generate double sybar = s * ybar
generate double szbar = s * zbar

quietly summarize sg, meanonly
scalar mean_g = r(sum)
quietly summarize sxbar, meanonly
scalar mean_xbar = r(sum)
quietly summarize sybar, meanonly
scalar mean_ybar = r(sum)
quietly summarize szbar, meanonly
scalar mean_zbar = r(sum)

generate double g0 = shock - mean_g
generate double gx = s * g0 * xbar
generate double gy = s * g0 * ybar
generate double gz = s * g0 * zbar

quietly summarize gx, meanonly
scalar moment_x = r(sum)
quietly summarize gy, meanonly
scalar moment_y = r(sum)
quietly summarize gz, meanonly
scalar moment_z = r(sum)

scalar effect = moment_y / moment_x
scalar first_stage = moment_x / moment_z

scalar effect_intercept = mean_ybar - effect * mean_xbar
scalar first_intercept = mean_xbar - first_stage * mean_zbar

generate double effect_u = ybar - effect_intercept - effect * xbar
generate double first_u = xbar - first_intercept - first_stage * zbar
generate double effect_score2 = (s * g0 * effect_u)^2
generate double first_score2 = (s * g0 * first_u)^2

quietly summarize effect_score2, meanonly
scalar effect_se = sqrt((N / (N - 2)) * r(sum) / moment_x^2)
quietly summarize first_score2, meanonly
scalar first_stage_se = sqrt((N / (N - 2)) * r(sum) / moment_z^2)

display "ANSWER: effect estimate=" %21.12f effect " se=" %21.12f effect_se " n_obs=" %12.0f N
display "ANSWER: first_stage estimate=" %21.12f first_stage " se=" %21.12f first_stage_se " n_obs=" %12.0f N
display "ANSWER: effective_shocks estimate=" %21.12f effective_shocks " se=. n_obs=" %12.0f N
