set linesize 255
import delimited "./input.csv", clear

bysort region_id: gen byte region_tag = (_n == 1)
egen double total_weight = total(cond(region_tag, region_weight, 0))
gen double e = region_weight / total_weight

gen double share_shock = share * shock
bysort region_id: egen double z = total(share_shock)

egen double mean_y = total(cond(region_tag, e * y, 0))
egen double mean_x = total(cond(region_tag, e * x, 0))
egen double mean_z = total(cond(region_tag, e * z, 0))

gen double y0 = y - mean_y
gen double x0 = x - mean_x
gen double z0 = z - mean_z

gen double es = e * share
gen double ey = es * y0
gen double ex = es * x0
gen double ez = es * z0

collapse (sum) s=es sy=ey sx=ex sz=ez (first) shock, by(industry_id)
local N = _N

gen double ybar = sy / s
gen double xbar = sx / s
gen double zbar = sz / s

egen double sum_s = total(s)
egen double sum_sg = total(s * shock)
egen double sum_sy = total(s * ybar)
egen double sum_sx = total(s * xbar)
egen double sum_sz = total(s * zbar)

gen double gc = shock - sum_sg / sum_s
gen double yc = ybar - sum_sy / sum_s
gen double xc = xbar - sum_sx / sum_s
gen double zc = zbar - sum_sz / sum_s

egen double gy = total(s * gc * yc)
egen double gx = total(s * gc * xc)
egen double gz = total(s * gc * zc)

scalar effect = gy[1] / gx[1]
scalar first_stage = gx[1] / gz[1]

gen double effect_u = yc - effect * xc
gen double first_stage_u = xc - first_stage * zc
egen double effect_meat = total((s * gc * effect_u)^2)
egen double first_stage_meat = total((s * gc * first_stage_u)^2)

scalar effect_se = sqrt((`N' / (`N' - 2)) * effect_meat[1] / gx[1]^2)
scalar first_stage_se = sqrt((`N' / (`N' - 2)) * first_stage_meat[1] / gz[1]^2)

egen double sum_s2 = total(s^2)
scalar effective_shocks = 1 / sum_s2[1]

display "ANSWER: effect estimate=" %21.12f effect " se=" %21.12f effect_se " n_obs=" %12.0f `N'
display "ANSWER: first_stage estimate=" %21.12f first_stage " se=" %21.12f first_stage_se " n_obs=" %12.0f `N'
display "ANSWER: effective_shocks estimate=" %21.12f effective_shocks " se=. n_obs=" %12.0f `N'
