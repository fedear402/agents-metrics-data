set linesize 255

import delimited "./input.csv", clear

egen byte region_tag = tag(region_id)
generate double region_mass = cond(region_tag, region_weight, 0)
egen double total_weight = total(region_mass)
generate double e = region_weight / total_weight

generate double share_shock = share * shock
egen double z = total(share_shock), by(region_id)

foreach v in y x z {
    generate double weighted_`v' = cond(region_tag, e * `v', 0)
    egen double mean_`v' = total(weighted_`v')
    generate double `v'0 = `v' - mean_`v'
    generate double numerator_`v' = e * share * `v'0
}

generate double s = e * share
collapse (sum) s numerator_y numerator_x numerator_z ///
    (first) shock, by(industry_id)

local n_industries = _N

foreach v in y x z {
    generate double `v'bar = numerator_`v' / s
}

generate double s_squared = s^2
quietly summarize s_squared, meanonly
scalar effective_shocks = 1 / (r(mean) * r(N))

quietly ivregress 2sls ybar (xbar = shock) [aw=s], vce(robust)
scalar effect = _b[xbar]
scalar effect_se = _se[xbar]

quietly ivregress 2sls xbar (zbar = shock) [aw=s], vce(robust)
scalar first_stage = _b[zbar]
scalar first_stage_se = _se[zbar]

display "ANSWER: effect estimate=" %21.12f effect ///
    " se=" %21.12f effect_se " n_obs=" %12.0f `n_industries'
display "ANSWER: first_stage estimate=" %21.12f first_stage ///
    " se=" %21.12f first_stage_se " n_obs=" %12.0f `n_industries'
display "ANSWER: effective_shocks estimate=" %21.12f effective_shocks ///
    " se=" %21.12f . " n_obs=" %12.0f `n_industries'
