set linesize 255
import delimited using "./input.csv", clear

quietly count
scalar n_obs = r(N)
scalar critical = invFtail(2, n_obs-4, 0.05)

tempvar y_minus y_plus
generate double `y_minus' = y - endog
generate double `y_plus'  = y + endog

quietly regress y x
scalar r0 = e(rss)
quietly regress y x z1 z2
scalar u0 = e(rss)

quietly regress `y_minus' x
scalar r1 = e(rss)
quietly regress `y_minus' x z1 z2
scalar u1 = e(rss)

quietly regress `y_plus' x
scalar rm1 = e(rss)
quietly regress `y_plus' x z1 z2
scalar um1 = e(rss)

scalar d0  = (n_obs-4)*(r0-u0) - 2*critical*u0
scalar d1  = (n_obs-4)*(r1-u1) - 2*critical*u1
scalar dm1 = (n_obs-4)*(rm1-um1) - 2*critical*um1

scalar a = (d1+dm1-2*d0)/2
scalar b = (d1-dm1)/2
scalar c = d0
scalar discriminant = b^2-4*a*c

scalar root1 = (-b-sqrt(discriminant))/(2*a)
scalar root2 = (-b+sqrt(discriminant))/(2*a)
scalar boundary_low = min(root1, root2)
scalar boundary_high = max(root1, root2)

scalar accepts_zero = (c <= 0)
scalar unbounded = (a < 0)
scalar ar_f_at_one = ((r1-u1)/2)/(u1/(n_obs-4))

display "ANSWER: boundary_low estimate=" %21.12f boundary_low " se=. n_obs=" %12.0f n_obs
display "ANSWER: boundary_high estimate=" %21.12f boundary_high " se=. n_obs=" %12.0f n_obs
display "ANSWER: accepts_zero estimate=" %21.12f accepts_zero " se=. n_obs=" %12.0f n_obs
display "ANSWER: unbounded estimate=" %21.12f unbounded " se=. n_obs=" %12.0f n_obs
display "ANSWER: ar_f_at_one estimate=" %21.12f ar_f_at_one " se=. n_obs=" %12.0f n_obs
