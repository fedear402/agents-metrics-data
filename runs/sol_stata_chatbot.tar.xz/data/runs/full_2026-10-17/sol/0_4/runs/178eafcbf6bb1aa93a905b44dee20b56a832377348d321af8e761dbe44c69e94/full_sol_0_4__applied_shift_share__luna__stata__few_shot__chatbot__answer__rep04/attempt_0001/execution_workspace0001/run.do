version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear varnames(1)
egen rid = group(region_id)
egen nid = group(industry_id)

mata:
data = st_data(., ("rid", "nid", "share", "shock", "region_weight", "x", "y"))
R = max(data[,1])
N = max(data[,2])

shares = J(R, N, 0)
shocks = J(N, 1, .)
weights = J(R, 1, .)
x = J(R, 1, .)
y = J(R, 1, .)

for (i=1; i<=rows(data); i++) {
    r = data[i,1]
    n = data[i,2]
    shares[r,n] = data[i,3]
    shocks[n] = data[i,4]
    weights[r] = data[i,5]
    x[r] = data[i,6]
    y[r] = data[i,7]
}

e = weights / sum(weights)
z = shares * shocks
regional = (y, x, z)
centered = regional :- J(R,1,1) * (e' * regional)

mass = shares' * e
aggregated = (shares' * (e :* centered)) :/ mass
instruments = (J(N,1,1), shocks)

estimates = J(2,2,.)
for (equation=1; equation<=2; equation++) {
    dependent = aggregated[,equation]
    endogenous = aggregated[,equation+1]
    regressors = (J(N,1,1), endogenous)

    cross = instruments' * (mass :* regressors)
    inverse = luinv(cross)
    beta = inverse * instruments' * (mass :* dependent)

    residual = dependent - regressors * beta
    scores = instruments :* (mass :* residual)
    covariance = (N/(N-2)) * inverse * (scores' * scores) * inverse'

    estimates[equation,] = (beta[2], sqrt(covariance[2,2]))
}

printf("ANSWER: effect estimate=%21.15g se=%21.15g n_obs=%12.0f\n", estimates[1,1], estimates[1,2], N)
printf("ANSWER: first_stage estimate=%21.15g se=%21.15g n_obs=%12.0f\n", estimates[2,1], estimates[2,2], N)
printf("ANSWER: effective_shocks estimate=%21.15g se=. n_obs=%12.0f\n", 1/sum(mass:^2), N)
end
