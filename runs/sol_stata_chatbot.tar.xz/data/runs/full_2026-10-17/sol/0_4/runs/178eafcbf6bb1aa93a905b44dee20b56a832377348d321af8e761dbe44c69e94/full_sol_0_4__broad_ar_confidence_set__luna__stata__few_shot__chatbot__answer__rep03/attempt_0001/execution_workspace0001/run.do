clear all
set more off
set linesize 255
set type double

import delimited using "./input.csv", clear

quietly regress y x
predict double ry, residuals

quietly regress endog x
predict double rd, residuals

quietly regress y x z1 z2
predict double uy, residuals
scalar n_obs = e(N)
scalar df = n_obs - 4

quietly regress endog x z1 z2
predict double ud, residuals

scalar q = 2
scalar critical = invFtail(q, df, .05)
scalar k = q * critical / df

mata:
    ry = st_data(., "ry")
    rd = st_data(., "rd")
    uy = st_data(., "uy")
    ud = st_data(., "ud")
    k = st_numscalar("k")
    df = st_numscalar("df")
    q = st_numscalar("q")

    rr_0 = quadcross(ry, ry)
    rr_1 = quadcross(ry, rd)
    rr_2 = quadcross(rd, rd)
    uu_0 = quadcross(uy, uy)
    uu_1 = quadcross(uy, ud)
    uu_2 = quadcross(ud, ud)

    A = rr_2 - (1+k)*uu_2
    B = -2*(rr_1 - (1+k)*uu_1)
    C = rr_0 - (1+k)*uu_0

    discriminant = B^2 - 4*A*C
    if (A == 0 | discriminant <= 0) _error(3498)

    roots = sort(((-B-sqrt(discriminant))/(2*A) \ ///
                  (-B+sqrt(discriminant))/(2*A)), 1)

    ssr_r_one = rr_0 - 2*rr_1 + rr_2
    ssr_u_one = uu_0 - 2*uu_1 + uu_2
    f_one = ((ssr_r_one-ssr_u_one)/q)/(ssr_u_one/df)

    st_numscalar("boundary_low", roots[1])
    st_numscalar("boundary_high", roots[2])
    st_numscalar("accepts_zero", C <= 0)
    st_numscalar("unbounded", A < 0)
    st_numscalar("ar_f_at_one", f_one)
end

display "ANSWER: boundary_low estimate=" %21.15g (boundary_low) " se=. n_obs=" %12.0f (n_obs)
display "ANSWER: boundary_high estimate=" %21.15g (boundary_high) " se=. n_obs=" %12.0f (n_obs)
display "ANSWER: accepts_zero estimate=" %21.15g (accepts_zero) " se=. n_obs=" %12.0f (n_obs)
display "ANSWER: unbounded estimate=" %21.15g (unbounded) " se=. n_obs=" %12.0f (n_obs)
display "ANSWER: ar_f_at_one estimate=" %21.15g (ar_f_at_one) " se=. n_obs=" %12.0f (n_obs)
