clear all
set more off
set type double

tempfile crosswalk trade employment outcomes

import delimited "crosswalk.csv", clear varnames(1)
isid code
save `crosswalk'

import delimited "trade.csv", clear varnames(1)
merge m:1 code using `crosswalk', assert(match) nogen
isid period industry
save `trade'

import delimited "employment.csv", clear varnames(1)
isid area period vintage industry
save `employment'

import delimited "outcomes.csv", clear varnames(1)
isid area period
save `outcomes'

import delimited "areas.csv", clear varnames(1)
isid area period vintage
joinby period using `trade'

merge m:1 area period vintage industry using `employment', nogen
replace employment = 0 if missing(employment)

bysort period vintage industry: egen double national_employment = total(employment)
assert national_employment > 0

gen double exposure_component = ///
    (employment / total_employment) * ///
    (us_change / national_employment) / ///
    (price_index / 100) / 1000 * (10 / years)

gen double instrument_component = ///
    (employment / total_employment) * ///
    (other_change / national_employment) / ///
    (price_index / 100) / 1000 * (10 / years)

collapse (sum) exposure_component instrument_component ///
    (firstnm) population, by(area period vintage)

reshape wide exposure_component instrument_component population, ///
    i(area period) j(vintage) string

gen double x = exposure_componentbase
gen double z = instrument_componentearly
merge 1:1 area period using `outcomes', assert(match) nogen

quietly summarize x if area == 0 & period == 0, meanonly
scalar exposure_0_0 = r(mean)
quietly summarize x if area == 0 & period == 1, meanonly
scalar exposure_0_1 = r(mean)
quietly summarize z if area == 0 & period == 0, meanonly
scalar instrument_0_0 = r(mean)

ivregress 2sls change_pp period control (x = z) [aw = populationbase]
assert e(N) == 72

display "ANSWER: iv_slope estimate=" %24.16g _b[x] " se=NA n_obs=72"
display "ANSWER: exposure_area0_period0 estimate=" %24.16g scalar(exposure_0_0) " se=NA n_obs=72"
display "ANSWER: exposure_area0_period1 estimate=" %24.16g scalar(exposure_0_1) " se=NA n_obs=72"
display "ANSWER: instrument_area0_period0 estimate=" %24.16g scalar(instrument_0_0) " se=NA n_obs=72"
