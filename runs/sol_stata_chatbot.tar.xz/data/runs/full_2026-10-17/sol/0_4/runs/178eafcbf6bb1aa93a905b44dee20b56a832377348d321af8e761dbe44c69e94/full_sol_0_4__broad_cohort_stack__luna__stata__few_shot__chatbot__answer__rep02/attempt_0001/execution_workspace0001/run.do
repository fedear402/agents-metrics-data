clear all
set more off
set type double

import delimited using "./input.csv", clear varnames(1) numericcols(_all)

tempfile source
save `source'

foreach c in 3 5 7 {
    use `source', clear

    keep if inrange(time, `c'-2, `c'+2)
    keep if g == `c' | g == 0 | g > `c'+2

    bysort id: keep if _N == 5

    generate byte did = (g == `c' & time >= `c')

    quietly count
    scalar n_`c' = r(N)

    quietly count if g == `c'
    scalar treated_`c' = r(N) / 5

    quietly regress y did i.id i.time
    scalar att_`c' = _b[did]
}

scalar att_weighted = (treated_3*att_3 + treated_5*att_5 + treated_7*att_7) / ///
    (treated_3 + treated_5 + treated_7)

display "ANSWER: att_g3 estimate=" %24.16g att_3
display "ANSWER: att_g5 estimate=" %24.16g att_5
display "ANSWER: att_g7 estimate=" %24.16g att_7
display "ANSWER: att_weighted estimate=" %24.16g att_weighted
