clear all
set more off
set type double

import delimited using "./input.csv", clear varnames(1)

tempfile source
save `source'

foreach c in 3 5 7 {
    use `source', clear

    keep if inrange(time, `c' - 2, `c' + 2)
    keep if g == `c' | g == 0 | g > `c' + 2

    bysort id: keep if _N == 5

    generate byte did = (g == `c' & time >= `c')

    quietly regress y did i.id i.time
    scalar att_g`c' = _b[did]
    scalar n_g`c' = e(N)

    quietly count if g == `c'
    scalar treated_g`c' = r(N) / 5
}

scalar att_weighted = (treated_g3 * att_g3 + treated_g5 * att_g5 + treated_g7 * att_g7) / (treated_g3 + treated_g5 + treated_g7)
scalar n_weighted = n_g3 + n_g5 + n_g7

display "ANSWER: att_g3 estimate=" %24.16g att_g3
display "ANSWER: att_g5 estimate=" %24.16g att_g5
display "ANSWER: att_g7 estimate=" %24.16g att_g7
display "ANSWER: att_weighted estimate=" %24.16g att_weighted
