clear all
set more off
set type double

tempfile crosswalk industries trade areas employment weights

import delimited "crosswalk.csv", clear
save `crosswalk'

keep industry
duplicates drop
save `industries'

import delimited "trade.csv", clear
merge m:1 code using `crosswalk', assert(match) nogen
keep period industry us_change other_change price_index years
isid period industry
save `trade'

import delimited "areas.csv", clear
save `areas'

keep if vintage == "base"
keep area period population
isid area period
save `weights'

import delimited "employment.csv", clear
isid area period vintage industry
save `employment'

use `areas', clear
cross using `industries'
merge 1:1 area period vintage industry using `employment', keep(master match) nogen
replace employment = 0 if missing(employment)

bysort period vintage industry: egen double national_employment = total(employment)
merge m:1 period industry using `trade', assert(match) nogen

gen double x = 0
replace x = (employment/total_employment) * ///
    (us_change/national_employment) / (price_index/100) / 1000 * ///
    (10/years) if vintage == "base"

gen double z = 0
replace z = (employment/total_employment) * ///
    (other_change/national_employment) / (price_index/100) / 1000 * ///
    (10/years) if vintage == "early"

collapse (sum) x z, by(area period)
merge 1:1 area period using `weights', assert(match) nogen

tempvar wanted_x0 wanted_x1 wanted_z0
quietly summarize x if area == 0 & period == 0, meanonly
scalar `wanted_x0' = r(mean)
quietly summarize x if area == 0 & period == 1, meanonly
scalar `wanted_x1' = r(mean)
quietly summarize z if area == 0 & period == 0, meanonly
scalar `wanted_z0' = r(mean)

import delimited "outcomes.csv", clear
merge 1:1 area period using `areas', keep(master) nogen
