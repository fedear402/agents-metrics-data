version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear
egen long rid = group(region_id)
egen long nid = group(industry_id)

mata:
data = st_data(., ("rid", "nid", "share", "shock", "region_weight", "x", "y"))
R = max(data[,1])
N = max(data[,2])

shares = J(R, N, 0)
shock = J(N, 1, .)
weight = J(R, 1, .)
x = J(R, 1, .)
y = J(R, 1, .)

for (i = 1; i <= rows(data); i++) {
    r = data[i,1]
    n = data[i,2]
    shares[r,n] = data[i,3]
    shock[n] = data[i,4]
    weight[r] = data[i,5]
    x[r] = data[i,6]
    y[r] = data[i,7]
}

e = weight / sum(weight)
z = shares * shock
regional = (y, x, z)
centered = regional :- J(R,1,1) * (e' * regional)

mass = shares' * e
aggregated = (shares' * (e :* centered)) :/ (mass * J(1,3,1))
instruments = (J(N,1,1), shock)

estimates = J(2,2,.)
for (equation = 1; equation <= 2; equation++) {
    dependent = aggregated[,equation]
    endogenous = aggregated[,equation+1]
    regressors = (J(N,1,1), endogenous)

    inverse = luinv(instruments' * (mass :* regressors))
    beta = inverse * instruments' * (mass :* dependent)
    residual = dependent - regressors * beta
    scores = instruments :* (mass :* residual)
    covariance = (N/(N-2)) * inverse * (scores' * scores) * inverse'

    estimates[equation,] = (beta[2], sqrt(covariance[2,2]))
}

st_numscalar("effect", estimates[1,1])
st_numscalar("effect_se", estimates[1,2])
st_numscalar("first_stage", estimates[2,1])
st_numscalar("first_stage_se", estimates[2,2])
st_numscalar("effective_shocks", 1/sum(mass:^2))
st_numscalar("n_industries", N)
end

display "ANSWER: effect estimate=" %21.12f effect " se=" %21.12f effect_se " n_obs=" %12.0f n_industries
display "ANSWER: first_stage estimate=" %21.12f first_stage " se=" %21.12f first_stage_se " n_obs=" %12.0f n_industries
display "ANSWER: effective_shocks estimate=" %21.12f effective_shocks " se=. n_obs=" %12.0f n_industries
