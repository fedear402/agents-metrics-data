clear all
set more off
set linesize 255
set type double

import delimited using "./input.csv", clear
scalar n_obs = _N
scalar q = 2
scalar df = n_obs - 4
scalar critical = invFtail(q, df, .05)
scalar k = q * critical / df

quietly regress y x
predict double ry, residuals
quietly regress endog x
predict double rd, residuals
quietly regress y x z1 z2
predict double uy, residuals
quietly regress endog x z1 z2
predict double ud, residuals

mata:
    ry = st_data(., "ry")
    rd = st_data(., "rd")
    uy = st_data(., "uy")
    ud = st_data(., "ud")
    k = st_numscalar("k")

    a = quadcross(rd, rd) - (1+k)*quadcross(ud, ud)
    b = -2*(quadcross(ry, rd) - (1+k)*quadcross(uy, ud))
    c = quadcross(ry, ry) - (1+k)*quadcross(uy, uy))
end
