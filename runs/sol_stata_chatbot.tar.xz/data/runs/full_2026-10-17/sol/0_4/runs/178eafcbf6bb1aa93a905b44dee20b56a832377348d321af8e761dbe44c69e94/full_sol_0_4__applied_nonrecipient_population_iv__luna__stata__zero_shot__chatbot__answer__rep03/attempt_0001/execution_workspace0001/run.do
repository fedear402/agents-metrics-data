clear all
set more off

tempfile census_counts

import delimited "census.csv", clear
quietly summarize nonrecipient_population if eligible == 0, meanonly
scalar pop0 = r(sum)
quietly summarize nonrecipient_population if eligible == 1, meanonly
scalar pop1 = r(sum)
save `census_counts'

import delimited "households.csv", clear
keep if recipient == 0
local n_obs = _N

generate double g0 = 1 - eligible
generate double g1 = eligible
generate double b0 = baseline * g0
generate double b1 = baseline * g1
generate double d0 = dose * g0
generate double d1 = dose * g1
generate double z0 = instrument * g0
generate double z1 = instrument * g1

quietly summarize dose [aw=weight] if eligible == 0, meanonly
scalar mean_dose0 = r(mean)
quietly summarize dose [aw=weight] if eligible == 1, meanonly
scalar mean_dose1 = r(mean)

quietly ivregress 2sls outcome g0 g1 b0 b1 (d0 d1 = z0 z1) [aw=weight], noconstant

scalar effect0 = _b[d0] * mean_dose0
scalar effect1 = _b[d1] * mean_dose1
scalar effect_pop = (pop0 * effect0 + pop1 * effect1) / (pop0 + pop1)

display "ANSWER: ineligible_effect estimate=" %21.12g effect0 " se=NA n_obs=`n_obs'"
display "ANSWER: eligible_nonrecipient_effect estimate=" %21.12g effect1 " se=NA n_obs=`n_obs'"
display "ANSWER: population_effect estimate=" %21.12g effect_pop " se=NA n_obs=`n_obs'"
