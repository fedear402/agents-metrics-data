clear all
set more off
set linesize 255

import delimited "./input.csv", clear

bysort region_id: egen double z = total(share * shock)
egen byte region_tag = tag(region_id)

preserve
    keep if region_tag
    egen double total_weight = total(region_weight)
    generate double e = region_weight / total_weight

    quietly summarize y [aw=e], meanonly
    scalar mean_y = r(mean)
    quietly summarize x [aw=e], meanonly
    scalar mean_x = r(mean)
    quietly summarize z [aw=e], meanonly
    scalar mean_z = r(mean)

    keep region_id e
    tempfile region_weights
    save `region_weights'
restore

merge m:1 region_id using `region_weights', nogen assert(match)

generate double exposure = e * share
generate double exposure_y = exposure * (y - mean_y)
generate double exposure_x = exposure * (x - mean_x)
generate double exposure_z = exposure * (z - mean_z)

collapse (sum) s=exposure sy=exposure_y sx=exposure_x sz=exposure_z ///
    (firstnm) shock, by(industry_id)

generate double ybar = sy / s
generate double xbar = sx / s
generate double zbar = sz / s
local N = _N

quietly summarize shock [aw=s], meanonly
scalar mean_shock = r(mean)
quietly summarize ybar [aw=s], meanonly
scalar mean_ybar = r(mean)
quietly summarize xbar [aw=s], meanonly
scalar mean_xbar = r(mean)
quietly summarize zbar [aw=s], meanonly
scalar mean_zbar = r(mean)

generate double centered_shock = shock - mean_shock
generate double moment_y = s * centered_shock * ybar
generate double moment_x = s * centered_shock * xbar
generate double moment_z = s * centered_shock * zbar

quietly summarize moment_y, meanonly
scalar numerator_y = r(mean) * `N'
quietly summarize moment_x, meanonly
scalar numerator_x = r(mean) * `N'
quietly summarize moment_z, meanonly
scalar numerator_z = r(mean) * `N'

scalar effect = numerator_y / numerator_x
scalar first_stage = numerator_x / numerator_z

scalar effect_intercept = mean_ybar - effect * mean_xbar
scalar first_stage_intercept = mean_xbar - first_stage * mean_zbar

generate double effect_residual = ybar - effect_intercept - effect * xbar
generate double first_stage_residual = ///
    xbar - first_stage_intercept - first_stage * zbar

generate double effect_meat = ///
    s^2 * centered_shock^2 * effect_residual^2
generate double first_stage_meat = ///
    s^2 * centered_shock^2 * first_stage_residual^2
generate double s_squared = s^2

quietly summarize effect_meat, meanonly
scalar effect_se = sqrt((`N' / (`N' - 2)) * ///
    (r(mean) * `N') / numerator_x^2)

quietly summarize first_stage_meat, meanonly
scalar first_stage_se = sqrt((`N' / (`N' - 2)) * ///
    (r(mean) * `N') / numerator_z^2)

quietly summarize s_squared, meanonly
scalar effective_shocks = 1 / (r(mean) * `N')

display "ANSWER: effect estimate=" %21.12f effect ///
    " se=" %21.12f effect_se " n_obs=" %12.0f `N'
display "ANSWER: first_stage estimate=" %21.12f first_stage ///
    " se=" %21.12f first_stage_se " n_obs=" %12.0f `N'
display "ANSWER: effective_shocks estimate=" %21.12f effective_shocks ///
    " se=" %1.0f . " n_obs=" %12.0f `N'
