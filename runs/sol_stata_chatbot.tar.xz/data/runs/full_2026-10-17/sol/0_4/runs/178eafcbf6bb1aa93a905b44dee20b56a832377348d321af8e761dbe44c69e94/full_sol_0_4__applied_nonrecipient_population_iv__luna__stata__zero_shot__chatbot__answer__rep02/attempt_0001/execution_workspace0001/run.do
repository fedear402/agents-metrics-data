clear all
set more off

import delimited "households.csv", clear varnames(1)
keep if recipient == 0

generate double g0 = 1 - eligible
generate double g1 = eligible
generate double b0 = baseline * g0
generate double b1 = baseline * g1
generate double d0 = dose * g0
generate double d1 = dose * g1
generate double z0 = instrument * g0
generate double z1 = instrument * g1

ivregress 2sls outcome g0 g1 b0 b1 ///
    (d0 d1 = z0 z1) [aweight=weight], noconstant

scalar n_used = e(N)
scalar slope0 = _b[d0]
scalar slope1 = _b[d1]

quietly summarize dose [aweight=weight] if e(sample) & eligible == 0, meanonly
scalar effect0 = slope0 * r(mean)

quietly summarize dose [aweight=weight] if e(sample) & eligible == 1, meanonly
scalar effect1 = slope1 * r(mean)

import delimited "census.csv", clear varnames(1)
quietly summarize nonrecipient_population if eligible == 0, meanonly
scalar pop0 = r(sum)
quietly summarize nonrecipient_population if eligible == 1, meanonly
scalar pop1 = r(sum)

scalar effect_pop = (pop0 * effect0 + pop1 * effect1) / (pop0 + pop1)

local n = strtrim(string(n_used, "%18.0f"))
local v0 = strtrim(string(effect0, "%21.15g"))
local v1 = strtrim(string(effect1, "%21.15g"))
local vp = strtrim(string(effect_pop, "%21.15g"))

display "ANSWER: ineligible_effect estimate=`v0' se=NA n_obs=`n'"
display "ANSWER: eligible_nonrecipient_effect estimate=`v1' se=NA n_obs=`n'"
display "ANSWER: population_effect estimate=`vp' se=NA n_obs=`n'"
