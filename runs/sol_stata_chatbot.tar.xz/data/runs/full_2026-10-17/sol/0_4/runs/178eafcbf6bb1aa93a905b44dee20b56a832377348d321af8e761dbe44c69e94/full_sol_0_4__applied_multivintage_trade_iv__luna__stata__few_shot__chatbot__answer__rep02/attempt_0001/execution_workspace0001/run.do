clear all
set more off
set type double

tempfile trade_data base_areas early_areas base_employment early_employment

import delimited "crosswalk.csv", clear varnames(1)
isid code
tempfile crosswalk_data
save `crosswalk_data'

import delimited "trade.csv", clear varnames(1)
merge m:1 code using `crosswalk_data', assert(match) nogen
isid period industry
save `trade_data'

import delimited "areas.csv", clear varnames(1)
preserve
    keep if vintage == "early"
    keep area period total_employment
    rename total_employment early_total
    isid area period
    save `early_areas'
restore
keep if vintage == "base"
keep area period total_employment population
rename total_employment base_total
isid area period
save `base_areas'

import delimited "employment.csv", clear varnames(1)
preserve
    keep if vintage == "early"
    keep area period industry employment
    rename employment early_employment
    isid area period industry
    save `early_employment'
restore
keep if vintage == "base"
keep area period industry employment
rename employment base_employment
isid area period industry
save `base_employment'

use `base_areas', clear
merge 1:1 area period using `early_areas', assert(match) nogen
joinby period using `trade_data'

merge 1:1 area period industry using `base_employment', keep(master match) nogen
replace base_employment = 0 if missing(base_employment)

merge 1:1 area period industry using `early_employment', keep(master match) nogen
replace early_employment = 0 if missing(early_employment)

bysort period industry: egen double national_base = total(base_employment)
bysort period industry: egen double national_early = total(early_employment)

gen double x = (base_employment / base_total) * ///
    (us_change / national_base) / (price_index / 100) / 1000 * (10 / years)
gen double z = (early_employment / early_total) * ///
    (other_change / national_early) / (price_index / 100) / 1000 * (10 / years)

collapse (sum) x z (first) population, by(area period)

import delimited "outcomes.csv", clear varnames(1)
tempfile outcomes_data
isid area period
save `outcomes_data'

use `base_areas', clear
keep area period
merge 1:1 area period using `outcomes_data', assert(match) nogen
tempfile area_outcomes
save `area_outcomes'

* Recover the area-period exposures from the preceding construction.
* The exposure data are saved by repeating the construction below.
use `base_areas', clear
merge 1:1 area period using `early_areas', assert(match) nogen
joinby period using `trade_data'
merge 1:1 area period industry using `base_employment', keep(master match) nogen
replace base_employment = 0 if missing(base_employment)
merge 1:1 area period industry using `early_employment', keep(master match) nogen
replace early_employment = 0 if missing(early_employment)
bysort period industry: egen double national_base = total(base_employment)
bysort period industry: egen double national_early = total(early_employment)
gen double x = (base_employment / base_total) * ///
    (us_change / national_base) / (price_index / 100) / 1000 * (10 / years)
gen double z = (early_employment / early_total) * ///
    (other_change / national_early) / (price_index / 100) / 1000 * (10 / years)
collapse (sum) x z (first) population, by(area period)
merge 1:1 area period using `outcomes_data', assert(match) nogen

count
assert r(N) == 72

quietly summarize x if area == 0 & period == 0, meanonly
scalar exposure00 = r(mean)
quietly summarize x if area == 0 & period == 1, meanonly
scalar exposure01 = r(mean)
quietly summarize z if area == 0 & period == 0, meanonly
scalar instrument00 = r(mean)

ivregress 2sls change_pp period control (x = z) [aw = population]
scalar iv_slope = _b[x]

display "ANSWER: iv_slope estimate=" %21.12g iv_slope " se=NA n_obs=72"
display "ANSWER: exposure_area0_period0 estimate=" %21.12g exposure00 " se=NA n_obs=72"
display "ANSWER: exposure_area0_period1 estimate=" %21.12g exposure01 " se=NA n_obs=72"
display "ANSWER: instrument_area0_period0 estimate=" %21.12g instrument00 " se=NA n_obs=72"
