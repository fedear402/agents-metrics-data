set linesize 255
import delimited using "./input.csv", clear

keep if !missing(score, participated, earnings) & abs(score) < 1
generate double weight = 1 - abs(score)
generate double right = score >= 0

mata:
    x = st_data(., "score")
    r = st_data(., "right")
    w = st_data(., "weight")
    y = st_data(., ("earnings", "participated"))
    n = rows(x)

    X = (J(n, 1, 1), x, r, x :* r)
    Ainv = invsym(quadcross(X, w, X))
    B = Ainv * quadcross(X, w, y)
    U = y - X * B

    h = (X * Ainv[, 3]) :* w
    gy = h :* U[, 1]
    gp = h :* U[, 2]

    rf = B[3, 1]
    fs = B[3, 2]
    var_rf = quadcross(gy, gy)
    var_fs = quadcross(gp, gp)
    cov_rf_fs = quadcross(gy, gp)

    st_numscalar("reduced_form", rf)
    st_numscalar("first_stage", fs)
    st_numscalar("se_reduced_form", sqrt(var_rf))
    st_numscalar("se_first_stage", sqrt(var_fs))
    st_numscalar("n_obs", n)

    if (fs != 0) {
        te = rf / fs
        var_te = var_rf / fs^2 + rf^2 * var_fs / fs^4 - ///
            2 * rf * cov_rf_fs / fs^3
        st_numscalar("treatment_effect", te)
        st_numscalar("se_treatment_effect", sqrt(max((0, var_te))))
    }
    else {
        st_numscalar("treatment_effect", .)
        st_numscalar("se_treatment_effect", .)
    }
end

display "ANSWER: treatment_effect estimate=" %21.12f treatment_effect " se=" %21.12f se_treatment_effect " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f reduced_form " se=" %21.12f se_reduced_form " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f first_stage " se=" %21.12f se_first_stage " n_obs=" %12.0f n_obs
