set linesize 255
import delimited "./input.csv", clear

local n = _N
local df = `n' - 4
scalar critical = invFtail(2, `df', 0.05)

quietly regress y x
quietly predict double ry_r, residuals
quietly regress endog x
quietly predict double rd_r, residuals

quietly regress y x z1 z2
quietly predict double ry_u, residuals
quietly regress endog x z1 z2
quietly predict double rd_u, residuals

quietly generate double yy_r = ry_r^2
quietly generate double yd_r = ry_r*rd_r
quietly generate double dd_r = rd_r^2
quietly generate double yy_u = ry_u^2
quietly generate double yd_u = ry_u*rd_u
quietly generate double dd_u = rd_u^2

foreach v in yy_r yd_r dd_r yy_u yd_u dd_u {
    quietly summarize `v', meanonly
    scalar S_`v' = r(sum)
}

scalar k = 2*critical/`df'
scalar A = S_dd_r - (1+k)*S_dd_u
scalar B = -2*(S_yd_r - (1+k)*S_yd_u)
scalar C = S_yy_r - (1+k)*S_yy_u

scalar discriminant = B^2 - 4*A*C
scalar root1 = (-B - sqrt(discriminant))/(2*A)
scalar root2 = (-B + sqrt(discriminant))/(2*A)
scalar boundary_low = min(root1, root2)
scalar boundary_high = max(root1, root2)

scalar accepts_zero = (C <= 0)
scalar unbounded = (A < 0)
scalar rss_r_one = S_yy_r - 2*S_yd_r + S_dd_r
scalar rss_u_one = S_yy_u - 2*S_yd_u + S_dd_u
scalar ar_f_at_one = ((rss_r_one - rss_u_one)/2)/(rss_u_one/`df')

display "ANSWER: boundary_low estimate=" %21.12f boundary_low " se=. n_obs=" %12.0f `n'
display "ANSWER: boundary_high estimate=" %21.12f boundary_high " se=. n_obs=" %12.0f `n'
display "ANSWER: accepts_zero estimate=" %21.12f accepts_zero " se=. n_obs=" %12.0f `n'
display "ANSWER: unbounded estimate=" %21.12f unbounded " se=. n_obs=" %12.0f `n'
display "ANSWER: ar_f_at_one estimate=" %21.12f ar_f_at_one " se=. n_obs=" %12.0f `n'
