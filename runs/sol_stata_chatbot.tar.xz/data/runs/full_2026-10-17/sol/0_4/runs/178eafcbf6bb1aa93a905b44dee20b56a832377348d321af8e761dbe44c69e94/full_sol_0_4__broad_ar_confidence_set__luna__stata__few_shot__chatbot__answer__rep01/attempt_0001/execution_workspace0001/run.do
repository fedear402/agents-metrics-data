clear all
set more off
set linesize 255
set type double

import delimited using "./input.csv", clear
local n = _N
local df = `n' - 4
scalar critical = invFtail(2, `df', .05)
scalar k = 2 * critical / `df'

quietly regress y x
predict double ry, residuals
quietly regress endog x
predict double rd, residuals
quietly regress y x z1 z2
predict double uy, residuals
quietly regress endog x z1 z2
predict double ud, residuals

mata:
    ry = st_data(., "ry")
    rd = st_data(., "rd")
    uy = st_data(., "uy")
    ud = st_data(., "ud")
    k = st_numscalar("k")
    df = strtoreal(st_local("df"))

    rr_y = quadcross(ry, ry)
    rr_yd = quadcross(ry, rd)
    rr_d = quadcross(rd, rd)
    uu_y = quadcross(uy, uy)
    uu_yd = quadcross(uy, ud)
    uu_d = quadcross(ud, ud)

    A = rr_d - (1+k)*uu_d
    B = -2*(rr_yd - (1+k)*uu_yd)
    C = rr_y - (1+k)*uu_y
    discriminant = B^2 - 4*A*C
    if (A == 0 | discriminant <= 0) _error(3498)

    roots = sort(((-B-sqrt(discriminant))/(2*A) \ (-B+sqrt(discriminant))/(2*A)), 1)
    ssr_r_one = rr_y - 2*rr_yd + rr_d
    ssr_u_one = uu_y - 2*uu_yd + uu_d

    st_numscalar("boundary_low", roots[1])
    st_numscalar("boundary_high", roots[2])
    st_numscalar("accepts_zero", C <= 0)
    st_numscalar("unbounded", A < 0)
    st_numscalar("ar_f_at_one", ((ssr_r_one-ssr_u_one)/2)/(ssr_u_one/df))
end

display "ANSWER: boundary_low estimate=" %21.12f boundary_low " se=. n_obs=" %12.0f `n'
display "ANSWER: boundary_high estimate=" %21.12f boundary_high " se=. n_obs=" %12.0f `n'
display "ANSWER: accepts_zero estimate=" %21.12f accepts_zero " se=. n_obs=" %12.0f `n'
display "ANSWER: unbounded estimate=" %21.12f unbounded " se=. n_obs=" %12.0f `n'
display "ANSWER: ar_f_at_one estimate=" %21.12f ar_f_at_one " se=. n_obs=" %12.0f `n'
