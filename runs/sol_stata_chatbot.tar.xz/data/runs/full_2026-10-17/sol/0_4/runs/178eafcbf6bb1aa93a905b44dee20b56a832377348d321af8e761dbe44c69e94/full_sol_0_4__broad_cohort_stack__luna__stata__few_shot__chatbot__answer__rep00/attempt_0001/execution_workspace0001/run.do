clear all
set more off
set type double

import delimited using "./input.csv", clear varnames(1)
isid id time

tempfile source
save `source'

foreach c in 3 5 7 {
    use `source', clear
    keep if inrange(time, `c' - 2, `c' + 2)
    keep if g == `c' | g == 0 | g > `c' + 2

    bysort id: keep if _N == 5
    generate byte did = (g == `c' & time >= `c')

    quietly count
    local n_obs_`c' = r(N)

    quietly egen byte unit_tag = tag(id)
    quietly count if unit_tag & g == `c'
    local treated_`c' = r(N)

    quietly regress y did i.id i.time
    local att_`c' = _b[did]

    display "ANSWER: att_g`c' estimate=" %24.16g `att_`c''
}

local total_treated = `treated_3' + `treated_5' + `treated_7'
local att_weighted = (`treated_3' * `att_3' + ///
    `treated_5' * `att_5' + `treated_7' * `att_7') / `total_treated'

display "ANSWER: att_weighted estimate=" %24.16g `att_weighted'
