set linesize 255
import delimited "./input.csv", clear

local n = _N
generate double y_plus_endog = y + endog

quietly regress y x
scalar ry = e(rss)
quietly regress endog x
scalar re = e(rss)
quietly regress y_plus_endog x
scalar rye = (e(rss) - ry - re)/2

quietly regress y x z1 z2
scalar uy = e(rss)
quietly regress endog x z1 z2
scalar ue = e(rss)
quietly regress y_plus_endog x z1 z2
scalar uye = (e(rss) - uy - ue)/2

scalar critical = invFtail(2, `n'-4, 0.05)
scalar a = (`n'-4)*(re-ue) - 2*critical*ue
scalar b = -2*((`n'-4)*(rye-uye) - 2*critical*uye)
scalar c = (`n'-4)*(ry-uy) - 2*critical*uy

scalar discriminant = b^2 - 4*a*c
scalar root1 = (-b - sqrt(discriminant))/(2*a)
scalar root2 = (-b + sqrt(discriminant))/(2*a)
scalar boundary_low = min(root1, root2)
scalar boundary_high = max(root1, root2)

scalar accepts_zero = (c <= 0)
scalar unbounded = (a < 0)
scalar ar_f_at_one = ((ry - 2*rye + re) - (uy - 2*uye + ue)) / 2 ///
    / ((uy - 2*uye + ue)/(`n'-4))

display "ANSWER: boundary_low estimate=" %21.12f boundary_low " se=. n_obs=" %12.0f `n'
display "ANSWER: boundary_high estimate=" %21.12f boundary_high " se=. n_obs=" %12.0f `n'
display "ANSWER: accepts_zero estimate=" %21.12f accepts_zero " se=. n_obs=" %12.0f `n'
display "ANSWER: unbounded estimate=" %21.12f unbounded " se=. n_obs=" %12.0f `n'
display "ANSWER: ar_f_at_one estimate=" %21.12f ar_f_at_one " se=. n_obs=" %12.0f `n'
