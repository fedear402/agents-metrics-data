version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear
egen long rid = group(region_id)
egen long nid = group(industry_id)

mata:
rid = st_data(., "rid")
nid = st_data(., "nid")
share = st_data(., "share")
shock_row = st_data(., "shock")
weight_row = st_data(., "region_weight")
x_row = st_data(., "x")
y_row = st_data(., "y")

R = max(rid)
N = max(nid)
shares = J(R, N, 0)
shock = J(N, 1, .)
weight = J(R, 1, .)
x = J(R, 1, .)
y = J(R, 1, .)

for (i = 1; i <= rows(rid); i++) {
    r = rid[i]
    n = nid[i]
    shares[r,n] = share[i]
    shock[n] = shock_row[i]
    weight[r] = weight_row[i]
    x[r] = x_row[i]
    y[r] = y_row[i]
}

e = weight / sum(weight)
z = shares * shock
regional = (y, x, z)
centered = regional :- e' * regional

mass = shares' * e
aggregated = (shares' * (e :* centered)) :/ mass

estimates = J(2, 2, .)
for (equation = 1; equation <= 2; equation++) {
    dependent = aggregated[,equation]
    endogenous = aggregated[,equation+1]
    regressors = (J(N,1,1), endogenous)
    instruments = (J(N,1,1), shock)

    inverse = luinv(instruments' * (mass :* regressors))
    beta = inverse * instruments' * (mass :* dependent)
    residual = dependent - regressors * beta
    scores = instruments :* (mass :* residual)
    covariance = (N/(N-2)) * inverse * (scores' * scores) * inverse'

    estimates[equation,] = (beta[2], sqrt(covariance[2,2]))
}

st_numscalar("b_effect", estimates[1,1])
st_numscalar("se_effect", estimates[1,2])
st_numscalar("b_first_stage", estimates[2,1])
st_numscalar("se_first_stage", estimates[2,2])
st_numscalar("effective_shocks", 1/sum(mass:^2))
st_numscalar("n_industries", N)
end

display "ANSWER: effect estimate=" %21.15g scalar(b_effect) ///
    " se=" %21.15g scalar(se_effect) ///
    " n_obs=" %12.0f scalar(n_industries)
display "ANSWER: first_stage estimate=" %21.15g scalar(b_first_stage) ///
    " se=" %21.15g scalar(se_first_stage) ///
    " n_obs=" %12.0f scalar(n_industries)
display "ANSWER: effective_shocks estimate=" %21.15g scalar(effective_shocks) ///
    " se=. n_obs=" %12.0f scalar(n_industries)
