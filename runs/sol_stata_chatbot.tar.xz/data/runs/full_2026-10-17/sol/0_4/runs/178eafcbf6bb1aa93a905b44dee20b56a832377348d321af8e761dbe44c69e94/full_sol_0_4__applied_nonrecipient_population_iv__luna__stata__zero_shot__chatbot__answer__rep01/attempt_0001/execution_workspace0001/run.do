clear all
set more off

quietly import delimited "census.csv", clear
quietly summarize nonrecipient_population if eligible == 0, meanonly
scalar pop0 = r(mean)
quietly summarize nonrecipient_population if eligible == 1, meanonly
scalar pop1 = r(mean)

quietly import delimited "households.csv", clear
keep if recipient == 0

generate byte g0 = eligible == 0
generate byte g1 = eligible == 1
generate double b0 = baseline * g0
generate double b1 = baseline * g1
generate double d0 = dose * g0
generate double d1 = dose * g1
generate double z0 = instrument * g0
generate double z1 = instrument * g1

quietly ivregress 2sls outcome g0 g1 b0 b1 ///
    (d0 d1 = z0 z1) [aweight=weight], noconstant

local n_obs = e(N)
generate byte estimation_sample = e(sample)

quietly summarize dose [aweight=weight] if estimation_sample & g0, meanonly
scalar ineligible_effect = _b[d0] * r(mean)

quietly summarize dose [aweight=weight] if estimation_sample & g1, meanonly
scalar eligible_nonrecipient_effect = _b[d1] * r(mean)

scalar population_effect = ///
    (pop0 * ineligible_effect + pop1 * eligible_nonrecipient_effect) ///
    / (pop0 + pop1)

display "ANSWER: ineligible_effect estimate=" ///
    strtrim(string(scalar(ineligible_effect), "%24.16g")) ///
    " se=NA n_obs=" strtrim(string(`n_obs', "%12.0f"))
display "ANSWER: eligible_nonrecipient_effect estimate=" ///
    strtrim(string(scalar(eligible_nonrecipient_effect), "%24.16g")) ///
    " se=NA n_obs=" strtrim(string(`n_obs', "%12.0f"))
display "ANSWER: population_effect estimate=" ///
    strtrim(string(scalar(population_effect), "%24.16g")) ///
    " se=NA n_obs=" strtrim(string(`n_obs', "%12.0f"))
