version 17.0
clear all
set more off

tempfile crosswalk trade areas base_population employment industries outcomes

import delimited "crosswalk.csv", clear varnames(1)
save `crosswalk'

import delimited "trade.csv", clear varnames(1)
merge m:1 code using `crosswalk', assert(match) nogen
isid period industry
save `trade'

use `crosswalk', clear
keep industry
duplicates drop
save `industries'

import delimited "areas.csv", clear varnames(1)
isid area period vintage
save `areas'
keep if vintage == "base"
keep area period population
isid area period
save `base_population'

import delimited "employment.csv", clear varnames(1)
isid area period vintage industry
save `employment'

import delimited "outcomes.csv", clear varnames(1)
isid area period
save `outcomes'

use `areas', clear
cross using `industries'
merge 1:1 area period vintage industry using `employment', nogen
replace employment = 0 if missing(employment)

bysort period vintage industry: egen double national_employment = total(employment)
merge m:1 period industry using `trade', assert(match) nogen

gen double contribution = .
replace contribution = (employment / total_employment) * ///
    (us_change / national_employment) / (price_index / 100) / 1000 * ///
    (10 / years) if vintage == "base"
replace contribution = (employment / total_employment) * ///
    (other_change / national_employment) / (price_index / 100) / 1000 * ///
    (10 / years) if vintage == "early"

collapse (sum) contribution, by(area period vintage)
reshape wide contribution, i(area period) j(vintage) string
rename contributionbase x
rename contributionearly z

merge 1:1 area period using `base_population', assert(match) nogen
merge 1:1 area period using `outcomes', assert(match) nogen
assert _N == 72

quietly summarize x if area == 0 & period == 0, meanonly
scalar exposure_area0_period0 = r(mean)
quietly summarize x if area == 0 & period == 1, meanonly
scalar exposure_area0_period1 = r(mean)
quietly summarize z if area == 0 & period == 0, meanonly
scalar instrument_area0_period0 = r(mean)

quietly ivregress 2sls change_pp period control (x = z) [aw = population]
scalar iv_slope = _b[x]

display "ANSWER: iv_slope estimate=" %21.12g iv_slope " se=NA n_obs=72"
display "ANSWER: exposure_area0_period0 estimate=" %21.12g exposure_area0_period0 " se=NA n_obs=72"
display "ANSWER: exposure_area0_period1 estimate=" %21.12g exposure_area0_period1 " se=NA n_obs=72"
display "ANSWER: instrument_area0_period0 estimate=" %21.12g instrument_area0_period0 " se=NA n_obs=72"
