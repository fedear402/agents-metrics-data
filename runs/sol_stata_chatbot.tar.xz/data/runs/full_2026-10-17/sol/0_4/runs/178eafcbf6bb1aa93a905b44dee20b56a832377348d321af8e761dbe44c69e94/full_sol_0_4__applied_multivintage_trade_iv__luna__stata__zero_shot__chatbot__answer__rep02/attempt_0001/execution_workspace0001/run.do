clear all
set more off

tempfile industry trade_data area_data employment_data outcome_data

import delimited "crosswalk.csv", clear
isid code
preserve
    keep industry
    duplicates drop
    save `industry'
restore
save `trade_data', emptyok replace

import delimited "trade.csv", clear
merge m:1 code using `trade_data', keepusing(industry) keep(match) nogen
isid period industry
save `trade_data', replace

import delimited "areas.csv", clear
isid area period vintage
save `area_data'

import delimited "employment.csv", clear
isid area period vintage industry
save `employment_data'

import delimited "outcomes.csv", clear
isid area period
save `outcome_data'

use `area_data', clear
cross using `industry'
merge 1:1 area period vintage industry using `employment_data', nogen
replace employment = 0 if missing(employment)

bysort period vintage industry: egen national_employment = total(employment)
assert national_employment > 0
merge m:1 period industry using `trade_data', keep(match) nogen

gen double xpart = 0
replace xpart = (employment / total_employment) * ///
    (us_change / national_employment) / (price_index / 100) / 1000 * ///
    (10 / years) if vintage == "base"

gen double zpart = 0
replace zpart = (employment / total_employment) * ///
    (other_change / national_employment) / (price_index / 100) / 1000 * ///
    (10 / years) if vintage == "early"

gen double weight = population if vintage == "base"
collapse (sum) xpart zpart (max) weight, by(area period)
merge 1:1 area period using `outcome_data', keep(match) nogen
assert _N == 72

quietly summarize xpart if area == 0 & period == 0, meanonly
scalar exposure_area0_period0 = r(mean)
quietly summarize xpart if area == 0 & period == 1, meanonly
scalar exposure_area0_period1 = r(mean)
quietly summarize zpart if area == 0 & period == 0, meanonly
scalar instrument_area0_period0 = r(mean)

ivregress 2sls change_pp period control (xpart = zpart) [aw = weight]
scalar iv_slope = _b[xpart]

display "ANSWER: iv_slope estimate=" %21.16g iv_slope " se=NA n_obs=72"
display "ANSWER: exposure_area0_period0 estimate=" %21.16g exposure_area0_period0 " se=NA n_obs=72"
display "ANSWER: exposure_area0_period1 estimate=" %21.16g exposure_area0_period1 " se=NA n_obs=72"
display "ANSWER: instrument_area0_period0 estimate=" %21.16g instrument_area0_period0 " se=NA n_obs=72"
