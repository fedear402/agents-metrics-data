version 19.0
clear all
set more off
set linesize 255

import delimited "./input.csv", clear
keep if !missing(score, participated, earnings) & abs(score) < 1

generate double right = score >= 0
generate double right_score = right * score
generate double weight = 1 - abs(score)

count
scalar n_obs = r(N)

mata:
    X = (J(st_nobs(), 1, 1), st_data(., "right"), ///
         st_data(., "score"), st_data(., "right_score"))
    w = st_data(., "weight")
    Y = st_data(., ("earnings", "participated"))

    bread = invsym(X' * (w :* X))
    coefficients = bread * X' * (w :* Y)
    residuals = Y - X * coefficients

    contrast = (0 \ 1 \ 0 \ 0)
    jumps = contrast' * coefficients
    loading = w :* (X * bread * contrast)
    influence = loading :* residuals
    joint = influence' * influence

    reduced_form = jumps[1]
    first_stage = jumps[2]
    treatment_effect = .
    treatment_se = .

    if (first_stage != 0 & first_stage < .) {
        treatment_effect = reduced_form / first_stage
        gradient = (1 / first_stage \ -reduced_form / first_stage^2)
        treatment_se = sqrt(gradient' * joint * gradient)
    }

    st_numscalar("reduced_form", reduced_form)
    st_numscalar("reduced_form_se", sqrt(joint[1, 1]))
    st_numscalar("first_stage", first_stage)
    st_numscalar("first_stage_se", sqrt(joint[2, 2]))
    st_numscalar("treatment_effect", treatment_effect)
    st_numscalar("treatment_se", treatment_se)
end

display "ANSWER: treatment_effect estimate=" %21.12f treatment_effect ///
    " se=" %21.12f treatment_se " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f reduced_form ///
    " se=" %21.12f reduced_form_se " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f first_stage ///
    " se=" %21.12f first_stage_se " n_obs=" %12.0f n_obs
