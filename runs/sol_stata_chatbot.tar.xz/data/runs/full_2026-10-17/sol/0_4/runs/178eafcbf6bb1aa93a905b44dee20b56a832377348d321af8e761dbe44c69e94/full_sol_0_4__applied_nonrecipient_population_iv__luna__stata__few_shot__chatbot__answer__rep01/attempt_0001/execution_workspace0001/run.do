clear all
set more off
set type double

import delimited using "census.csv", clear
summarize nonrecipient_population if eligible == 0, meanonly
scalar n0 = r(mean)
summarize nonrecipient_population if eligible == 1, meanonly
scalar n1 = r(mean)

import delimited using "households.csv", clear
keep if recipient == 0

generate double g0 = 1 - eligible
generate double g1 = eligible
generate double x0 = baseline * g0
generate double x1 = baseline * g1
generate double d0 = dose * g0
generate double d1 = dose * g1
generate double z0 = instrument * g0
generate double z1 = instrument * g1

ivregress 2sls outcome g0 g1 x0 x1 (d0 d1 = z0 z1) ///
    [aw=weight], noconstant

scalar n_obs = e(N)
scalar b0 = _b[d0]
scalar b1 = _b[d1]
generate byte estimation_sample = e(sample)

summarize dose [aw=weight] if estimation_sample & eligible == 0, meanonly
scalar ineligible_effect = b0 * r(mean)

summarize dose [aw=weight] if estimation_sample & eligible == 1, meanonly
scalar eligible_nonrecipient_effect = b1 * r(mean)

scalar population_effect = ///
    (n0 * ineligible_effect + n1 * eligible_nonrecipient_effect) / (n0 + n1)

display "ANSWER: ineligible_effect estimate=" ///
    %24.16g (ineligible_effect) " se=NA n_obs=" %12.0f (n_obs)
display "ANSWER: eligible_nonrecipient_effect estimate=" ///
    %24.16g (eligible_nonrecipient_effect) " se=NA n_obs=" %12.0f (n_obs)
display "ANSWER: population_effect estimate=" ///
    %24.16g (population_effect) " se=NA n_obs=" %12.0f (n_obs)
