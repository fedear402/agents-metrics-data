version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear
keep if !missing(score, participated, earnings) & abs(score) < 1

generate double right = (score >= 0)
generate double score_left = score * (1 - right)
generate double score_right = score * right
generate double weight = 1 - abs(score)

mata:
    X = (J(st_nobs(), 1, 1), st_data(., ("right", "score_left", "score_right")))
    w = st_data(., "weight")
    Y = st_data(., ("earnings", "participated"))

    bread = invsym(X' * (w :* X))
    coefficients = bread * X' * (w :* Y)
    residuals = Y - X * coefficients

    contrast = (0 \ 1 \ 0 \ 0)
    jumps = contrast' * coefficients
    loading = w :* (X * bread * contrast)
    influence = loading :* residuals
    joint = influence' * influence

    gradient = (1 / jumps[2] \ -jumps[1] / jumps[2]^2)
    treatment_effect = jumps[1] / jumps[2]
    treatment_se = sqrt(gradient' * joint * gradient)

    st_numscalar("rd_n", rows(X))
    st_numscalar("rd_reduced_form", jumps[1])
    st_numscalar("rd_reduced_form_se", sqrt(joint[1,1]))
    st_numscalar("rd_first_stage", jumps[2])
    st_numscalar("rd_first_stage_se", sqrt(joint[2,2]))
    st_numscalar("rd_treatment_effect", treatment_effect)
    st_numscalar("rd_treatment_se", treatment_se)
end

display "ANSWER: treatment_effect estimate=" %21.12f rd_treatment_effect " se=" %21.12f rd_treatment_se " n_obs=" %12.0f rd_n
display "ANSWER: reduced_form estimate=" %21.12f rd_reduced_form " se=" %21.12f rd_reduced_form_se " n_obs=" %12.0f rd_n
display "ANSWER: first_stage estimate=" %21.12f rd_first_stage " se=" %21.12f rd_first_stage_se " n_obs=" %12.0f rd_n
