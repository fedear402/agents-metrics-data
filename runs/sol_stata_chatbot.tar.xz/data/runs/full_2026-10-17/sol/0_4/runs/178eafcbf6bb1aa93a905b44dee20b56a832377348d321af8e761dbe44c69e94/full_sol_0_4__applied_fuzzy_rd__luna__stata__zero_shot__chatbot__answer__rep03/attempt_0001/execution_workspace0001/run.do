set linesize 255
import delimited using "./input.csv", clear

keep if abs(score) < 1 & !missing(score, participated, earnings)
generate double weight = 1 - abs(score)
generate double right = score >= 0
generate double score_right = score * right

mata:
    X = (J(st_nobs(), 1, 1), st_data(., ("right", "score", "score_right")))
    w = st_data(., "weight")
    y = st_data(., "earnings")
    d = st_data(., "participated")

    B = invsym(quadcross(X, w, X))
    by = B * quadcross(X, w, y)
    bd = B * quadcross(X, w, d)
    ey = y - X * by
    ed = d - X * bd

    Vyy = B * quadcross(X, (w:^2) :* (ey:^2), X) * B
    Vdd = B * quadcross(X, (w:^2) :* (ed:^2), X) * B
    Vyd = B * quadcross(X, (w:^2) :* ey :* ed, X) * B

    rf = by[2]
    fs = bd[2]
    st_numscalar("reduced_form", rf)
    st_numscalar("first_stage", fs)
    st_numscalar("reduced_form_se", sqrt(Vyy[2,2]))
    st_numscalar("first_stage_se", sqrt(Vdd[2,2]))
    st_numscalar("n_obs", st_nobs())

    if (fs != 0) {
        te = rf / fs
        te_var = Vyy[2,2] / fs^2 + rf^2 * Vdd[2,2] / fs^4 - 2 * rf * Vyd[2,2] / fs^3
        st_numscalar("treatment_effect", te)
        st_numscalar("treatment_effect_se", sqrt(te_var))
    }
    else {
        st_numscalar("treatment_effect", .)
        st_numscalar("treatment_effect_se", .)
    }
end

display "ANSWER: treatment_effect estimate=" %21.12f treatment_effect " se=" %21.12f treatment_effect_se " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f reduced_form " se=" %21.12f reduced_form_se " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f first_stage " se=" %21.12f first_stage_se " n_obs=" %12.0f n_obs
