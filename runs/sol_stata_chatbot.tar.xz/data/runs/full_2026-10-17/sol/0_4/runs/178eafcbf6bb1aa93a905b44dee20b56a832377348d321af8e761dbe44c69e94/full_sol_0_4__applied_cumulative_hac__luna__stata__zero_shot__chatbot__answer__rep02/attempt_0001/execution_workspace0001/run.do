clear all
set more off
set linesize 255

import delimited using "./input.csv", clear
sort date

generate double log_sales = ln(sales)
generate double log_vix = ln(vix)
generate double dlog_vix = log_vix - log_vix[_n-1]

forvalues k = 1/15 {
    generate double lag_`k' = dlog_vix[_n-`k']
}

keep if !missing(log_sales, lag_1, lag_2, lag_3, lag_4, lag_5, ///
    lag_6, lag_7, lag_8, lag_9, lag_10, lag_11, lag_12, ///
    lag_13, lag_14, lag_15)

generate double intercept = 1
local xvars intercept
forvalues k = 1/15 {
    local xvars `xvars' lag_`k'
}

mata:
    X = st_data(., tokens(st_local("xvars")))
    y = st_data(., "log_sales")
    N = rows(X)
    Q = invsym(X'X)
    b = Q * X'y
    u = y - X*b

    S = J(16, 16, 0)
    for (t=1; t<=N; t++) {
        z = X[t,.]' * u[t]
        S = S + z*z'
    }
    for (j=1; j<=15; j++) {
        w = 1 - j/16
        for (t=j+1; t<=N; t++) {
            zt = X[t,.]' * u[t]
            zj = X[t-j,.]' * u[t-j]
            S = S + w*(zt*zj' + zj*zt')
        }
    }

    V = (N/(N-16)) * Q*S*Q
    a = (0 \ J(15,1,1))

    st_numscalar("answer_n", N)
    st_numscalar("answer_cum", a'b)
    st_numscalar("answer_cum_se", sqrt(a'V*a))
    st_numscalar("answer_lag1", b[2])
    st_numscalar("answer_lag1_se", sqrt(V[2,2]))
    st_numscalar("answer_lag15", b[16])
    st_numscalar("answer_lag15_se", sqrt(V[16,16]))
end

display "ANSWER: cumulative_response estimate=" %21.12f answer_cum ///
    " se=" %21.12f answer_cum_se " n_obs=" %12.0f answer_n
display "ANSWER: lag_1 estimate=" %21.12f answer_lag1 ///
    " se=" %21.12f answer_lag1_se " n_obs=" %12.0f answer_n
display "ANSWER: lag_15 estimate=" %21.12f answer_lag15 ///
    " se=" %21.12f answer_lag15_se " n_obs=" %12.0f answer_n
