clear all
set more off
set type double

tempfile industries trade_data areas_data employment_data weights exposures

import delimited "crosswalk.csv", clear
isid code
preserve
    keep industry
    duplicates drop
    save `industries'
restore
save `trade_data', emptyok replace

import delimited "trade.csv", clear
merge m:1 code using `trade_data', nogen
isid period industry
keep period industry us_change other_change price_index years
save `trade_data', replace

import delimited "areas.csv", clear
isid area period vintage
save `areas_data'
preserve
    keep if vintage == "base"
    keep area period population
    rename population regression_weight
    isid area period
    save `weights'
restore

import delimited "employment.csv", clear
isid area period vintage industry
save `employment_data'

use `areas_data', clear
cross using `industries'
merge 1:1 area period vintage industry using `employment_data', nogen
replace employment = 0 if missing(employment)

bysort period vintage industry: egen double national_employment = total(employment)
merge m:1 period industry using `trade_data', assert(match) nogen

gen double x_part = 0
replace x_part = (employment / total_employment) * ///
    (us_change / national_employment) / (price_index / 100) / 1000 * ///
    (10 / years) if vintage == "base"

gen double z_part = 0
replace z_part = (employment / total_employment) * ///
    (other_change / national_employment) / (price_index / 100) / 1000 * ///
    (10 / years) if vintage == "early"

collapse (sum) x_part z_part, by(area period)
rename x_part x
rename z_part z
save `exposures'

merge 1:1 area period using `weights', assert(match) nogen
merge 1:1 area period using "outcomes.csv", assert(match) nogen
