clear all
set more off

tempfile trade_data employment_data

import delimited "crosswalk.csv", clear varnames(1)
isid code
save `employment_data', emptyok replace

import delimited "trade.csv", clear varnames(1)
merge m:1 code using `employment_data', assert(match) nogen
isid period industry
save `trade_data'

import delimited "employment.csv", clear varnames(1)
isid area period vintage industry
save `employment_data'

import delimited "areas.csv", clear varnames(1)
isid area period vintage
merge 1:m area period vintage using `employment_data', nogen
replace employment = 0 if missing(employment)

bysort period vintage industry: egen national_employment = total(employment)
merge m:1 period industry using `trade_data', keep(master match) nogen

generate double contribution_x = 0
generate double contribution_z = 0

replace contribution_x = ///
    (employment / total_employment) * ///
    (us_change / national_employment) / ///
    (price_index / 100) / 1000 * (10 / years) ///
    if vintage == "base" & !missing(industry)

replace contribution_z = ///
    (employment / total_employment) * ///
    (other_change / national_employment) / ///
    (price_index / 100) / 1000 * (10 / years) ///
    if vintage == "early" & !missing(industry)

collapse (sum) contribution_x contribution_z ///
    (firstnm) population, by(area period vintage)

reshape wide contribution_x contribution_z population, ///
    i(area period) j(vintage) string

rename contribution_xbase x
rename contribution_zearly z
rename populationbase regression_weight

merge 1:1 area period using "outcomes.csv", assert(match) nogen
isid area period
assert _N == 72

quietly ivregress 2sls change_pp period control (x = z) ///
    [aweight = regression_weight]
scalar iv_slope = _b[x]

quietly summarize x if area == 0 & period == 0, meanonly
scalar exposure_area0_period0 = r(mean)

quietly summarize x if area == 0 & period == 1, meanonly
scalar exposure_area0_period1 = r(mean)

quietly summarize z if area == 0 & period == 0, meanonly
scalar instrument_area0_period0 = r(mean)

display "ANSWER: iv_slope estimate=" %24.15g iv_slope " se=NA n_obs=72"
display "ANSWER: exposure_area0_period0 estimate=" %24.15g exposure_area0_period0 " se=NA n_obs=72"
display "ANSWER: exposure_area0_period1 estimate=" %24.15g exposure_area0_period1 " se=NA n_obs=72"
display "ANSWER: instrument_area0_period0 estimate=" %24.15g instrument_area0_period0 " se=NA n_obs=72"
