set linesize 255
import delimited "./input.csv", clear

local n = _N
local df = `n' - 4
scalar critical = invFtail(2, `df', 0.05)

quietly regress y x
quietly predict double yr, residuals
quietly regress endog x
quietly predict double dr, residuals

quietly regress y x z1 z2
quietly predict double yu, residuals
quietly regress endog x z1 z2
quietly predict double du, residuals

quietly generate double yr2 = yr^2
quietly generate double dr2 = dr^2
quietly generate double yrdr = yr*dr
quietly generate double yu2 = yu^2
quietly generate double du2 = du^2
quietly generate double yudu = yu*du

foreach v in yr2 dr2 yrdr yu2 du2 yudu {
    quietly summarize `v', meanonly
    scalar S_`v' = r(mean)*`n'
}

* The test accepts beta when A*beta^2 + B*beta + C <= 0.
scalar A = `df'*(S_dr2-S_du2) - 2*critical*S_du2
scalar B = -2*`df'*(S_yrdr-S_yudu) + 4*critical*S_yudu
scalar C = `df'*(S_yr2-S_yu2) - 2*critical*S_yu2

scalar discriminant = B^2 - 4*A*C
scalar root1 = (-B-sqrt(discriminant))/(2*A)
scalar root2 = (-B+sqrt(discriminant))/(2*A)
scalar boundary_low = min(root1, root2)
scalar boundary_high = max(root1, root2)

scalar accepts_zero = (C <= 0)
scalar unbounded = (A < 0)
scalar ar_f_at_one = (`df'/2) * ///
    ((S_yr2-2*S_yrdr+S_dr2) - (S_yu2-2*S_yudu+S_du2)) / ///
    (S_yu2-2*S_yudu+S_du2)

display "ANSWER: boundary_low estimate=" %21.12f boundary_low " se=. n_obs=" %12.0f `n'
display "ANSWER: boundary_high estimate=" %21.12f boundary_high " se=. n_obs=" %12.0f `n'
display "ANSWER: accepts_zero estimate=" %21.12f accepts_zero " se=. n_obs=" %12.0f `n'
display "ANSWER: unbounded estimate=" %21.12f unbounded " se=. n_obs=" %12.0f `n'
display "ANSWER: ar_f_at_one estimate=" %21.12f ar_f_at_one " se=. n_obs=" %12.0f `n'
