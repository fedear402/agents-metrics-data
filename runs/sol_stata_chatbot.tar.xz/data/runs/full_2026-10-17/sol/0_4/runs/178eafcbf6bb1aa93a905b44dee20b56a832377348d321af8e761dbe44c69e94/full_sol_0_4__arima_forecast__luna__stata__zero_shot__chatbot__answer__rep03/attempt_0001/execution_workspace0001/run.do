clear all
set more off
set linesize 255

import delimited using "./input.csv", clear
sort t
tsset t

quietly count if !missing(y)
local n_obs = r(N)

quietly arima y, arima(1,1,1) noconstant

quietly summarize t if !missing(y), meanonly
local last_t = r(max)
assert `last_t' == 250

tsappend, add(1)
quietly predict double forecast_level, y dynamic(251)
quietly predict double forecast_mse, mse dynamic(251)

quietly summarize forecast_level if t == 251, meanonly
scalar forecast_value = r(mean)
quietly summarize forecast_mse if t == 251, meanonly
scalar forecast_se = sqrt(r(mean))
scalar lower_value = forecast_value - invnormal(0.975)*forecast_se
scalar upper_value = forecast_value + invnormal(0.975)*forecast_se

display "ANSWER: forecast estimate=" %21.12f forecast_value " se=" %21.12f forecast_se " n_obs=" %12.0f `n_obs'
display "ANSWER: lower_95 estimate=" %21.12f lower_value " se=. n_obs=" %12.0f `n_obs'
display "ANSWER: upper_95 estimate=" %21.12f upper_value " se=. n_obs=" %12.0f `n_obs'
