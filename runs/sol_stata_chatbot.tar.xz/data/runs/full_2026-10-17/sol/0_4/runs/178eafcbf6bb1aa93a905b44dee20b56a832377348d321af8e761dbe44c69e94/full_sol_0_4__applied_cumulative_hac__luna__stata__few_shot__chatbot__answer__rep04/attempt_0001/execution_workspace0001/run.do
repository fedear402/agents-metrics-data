version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear varnames(1)
generate double day = date(date, "YMD")
sort day
generate long observation = _n
tsset observation

generate double log_sales = ln(sales)
generate double log_vix = ln(vix)
generate double vix_change = D.log_vix

forvalues k = 1/15 {
    generate double change_lag`k' = L`k'.vix_change
}

keep if !missing(log_sales, change_lag1, change_lag15)

mata:
    lag_names = J(1, 15, "")
    for (k = 1; k <= 15; k++) {
        lag_names[k] = "change_lag" + strofreal(k)
    }

    y = st_data(., "log_sales")
    X = (J(rows(y), 1, 1), st_data(., lag_names))
    N = rows(X)
    p = cols(X)

    b = qrsolve(X, y)
    scores = X :* (y - X*b)

    meat = scores' * scores
    for (j = 1; j <= 15; j++) {
        product = scores[|j+1,1 \ N,p|]' * scores[|1,1 \ N-j,p|]
        meat = meat + (1 - j/16) * (product + product')
    }

    bread = invsym(X' * X)
    V = (N/(N-p)) * bread * meat * bread

    contrast = (0 \ J(15, 1, 1))
    st_numscalar("result_cumulative", (contrast' * b)[1,1])
    st_numscalar("se_cumulative", sqrt((contrast' * V * contrast)[1,1]))
    st_numscalar("result_lag1", b[2])
    st_numscalar("se_lag1", sqrt(V[2,2]))
    st_numscalar("result_lag15", b[16])
    st_numscalar("se_lag15", sqrt(V[16,16]))
    st_numscalar("result_n", N)
end

display "ANSWER: cumulative_response estimate=" %21.12f scalar(result_cumulative) " se=" %21.12f scalar(se_cumulative) " n_obs=" %12.0f scalar(result_n)
display "ANSWER: lag_1 estimate=" %21.12f scalar(result_lag1) " se=" %21.12f scalar(se_lag1) " n_obs=" %12.0f scalar(result_n)
display "ANSWER: lag_15 estimate=" %21.12f scalar(result_lag15) " se=" %21.12f scalar(se_lag15) " n_obs=" %12.0f scalar(result_n)
