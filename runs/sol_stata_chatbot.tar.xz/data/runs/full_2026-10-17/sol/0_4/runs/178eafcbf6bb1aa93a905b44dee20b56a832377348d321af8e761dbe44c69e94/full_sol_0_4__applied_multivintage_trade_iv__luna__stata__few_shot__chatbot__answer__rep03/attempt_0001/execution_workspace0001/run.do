clear all
set more off
set type double

tempfile trade_industry areas_base exposures

import delimited "crosswalk.csv", clear
isid code
save "`c(tmpdir)'/crosswalk_task.dta", replace

import delimited "trade.csv", clear
merge m:1 code using "`c(tmpdir)'/crosswalk_task.dta", keep(match) nogen
isid period industry
save `trade_industry'

import delimited "areas.csv", clear
preserve
    keep if vintage == "base"
    keep area period population
    rename population population_base
    isid area period
    save `areas_base'
restore

joinby period using `trade_industry'
merge 1:1 area period vintage industry using "employment.csv"
