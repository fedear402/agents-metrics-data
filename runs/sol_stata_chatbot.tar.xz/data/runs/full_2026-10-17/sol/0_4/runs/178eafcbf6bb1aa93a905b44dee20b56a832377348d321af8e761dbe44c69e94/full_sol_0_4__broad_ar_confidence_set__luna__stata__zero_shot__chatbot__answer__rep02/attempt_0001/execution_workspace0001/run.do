version 16.0
set more off
set linesize 255

import delimited "./input.csv", clear
local n = _N

tempvar ry rd uy ud work

quietly regress y x
quietly predict double `ry', residuals
quietly regress endog x
quietly predict double `rd', residuals
quietly regress y x z1 z2
quietly predict double `uy', residuals
quietly regress endog x z1 z2
quietly predict double `ud', residuals

quietly generate double `work' = `ry'^2
quietly summarize `work', meanonly
scalar R0 = r(sum)
quietly replace `work' = -2*`ry'*`rd'
quietly summarize `work', meanonly
scalar R1 = r(sum)
quietly replace `work' = `rd'^2
quietly summarize `work', meanonly
scalar R2 = r(sum)

quietly replace `work' = `uy'^2
quietly summarize `work', meanonly
scalar U0 = r(sum)
quietly replace `work' = -2*`uy'*`ud'
quietly summarize `work', meanonly
scalar U1 = r(sum)
quietly replace `work' = `ud'^2
quietly summarize `work', meanonly
scalar U2 = r(sum)

scalar critical = invFtail(2, `n'-4, 0.05)
scalar scale = 2*critical/(`n'-4)
scalar q0 = R0 - (1+scale)*U0
scalar q1 = R1 - (1+scale)*U1
scalar q2 = R2 - (1+scale)*U2

scalar discriminant = q1^2 - 4*q2*q0
scalar root_a = (-q1 - sqrt(discriminant))/(2*q2)
scalar root_b = (-q1 + sqrt(discriminant))/(2*q2)
scalar boundary_low = min(root_a, root_b)
scalar boundary_high = max(root_a, root_b)

scalar accepts_zero = (q0 <= 0)
scalar unbounded = (q2 < 0)
scalar ar_f_at_one = ((R0+R1+R2)-(U0+U1+U2))/2 / ///
    ((U0+U1+U2)/(`n'-4))

display "ANSWER: boundary_low estimate=" %21.12f boundary_low " se=. n_obs=" %12.0f `n'
display "ANSWER: boundary_high estimate=" %21.12f boundary_high " se=. n_obs=" %12.0f `n'
display "ANSWER: accepts_zero estimate=" %21.12f accepts_zero " se=. n_obs=" %12.0f `n'
display "ANSWER: unbounded estimate=" %21.12f unbounded " se=. n_obs=" %12.0f `n'
display "ANSWER: ar_f_at_one estimate=" %21.12f ar_f_at_one " se=. n_obs=" %12.0f `n'
