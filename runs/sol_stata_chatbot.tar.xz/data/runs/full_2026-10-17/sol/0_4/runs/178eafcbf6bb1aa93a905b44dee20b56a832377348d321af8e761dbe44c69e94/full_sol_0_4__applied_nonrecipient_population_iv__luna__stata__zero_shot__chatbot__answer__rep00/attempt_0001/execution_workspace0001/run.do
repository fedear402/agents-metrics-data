clear all
set more off

import delimited "census.csv", clear
quietly summarize nonrecipient_population if eligible == 0, meanonly
scalar pop0 = r(sum)
quietly summarize nonrecipient_population if eligible == 1, meanonly
scalar pop1 = r(sum)

import delimited "households.csv", clear
keep if recipient == 0

generate byte g0 = 1 - eligible
generate byte g1 = eligible
generate double base0 = baseline * g0
generate double base1 = baseline * g1
generate double dose0 = dose * g0
generate double dose1 = dose * g1
generate double z0 = instrument * g0
generate double z1 = instrument * g1

quietly ivregress 2sls outcome g0 g1 base0 base1 ///
    (dose0 dose1 = z0 z1) [aw=weight], noconstant

scalar n = e(N)
scalar slope0 = _b[dose0]
scalar slope1 = _b[dose1]
generate byte estimation_sample = e(sample)

quietly summarize dose [aw=weight] if estimation_sample & eligible == 0, meanonly
scalar ineligible_effect = slope0 * r(mean)

quietly summarize dose [aw=weight] if estimation_sample & eligible == 1, meanonly
scalar eligible_nonrecipient_effect = slope1 * r(mean)

scalar population_effect = ///
    (pop0 * ineligible_effect + pop1 * eligible_nonrecipient_effect) / (pop0 + pop1)

display "ANSWER: ineligible_effect estimate=" ///
    strtrim(string(ineligible_effect, "%21.15g")) ///
    " se=NA n_obs=" strtrim(string(n, "%18.0f"))
display "ANSWER: eligible_nonrecipient_effect estimate=" ///
    strtrim(string(eligible_nonrecipient_effect, "%21.15g")) ///
    " se=NA n_obs=" strtrim(string(n, "%18.0f"))
display "ANSWER: population_effect estimate=" ///
    strtrim(string(population_effect, "%21.15g")) ///
    " se=NA n_obs=" strtrim(string(n, "%18.0f"))
