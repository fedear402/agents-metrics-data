clear all
set more off
set linesize 255

import delimited "./input.csv", clear

capture confirm string variable group
if !_rc {
    encode group, gen(group_id)
}
else {
    generate long group_id = group
}

anova y group_id

local f_stat = e(F)
local df_num = e(df_m)
local df_den = e(df_r)
local p_value = Ftail(`df_num', `df_den', `f_stat')
local n_obs = e(N)

display "ANSWER: F estimate=" %21.12f `f_stat' " se=. n_obs=" %12.0f `n_obs'
display "ANSWER: df_num estimate=" %21.12f `df_num' " se=. n_obs=" %12.0f `n_obs'
display "ANSWER: df_den estimate=" %21.12f `df_den' " se=. n_obs=" %12.0f `n_obs'
display "ANSWER: p_value estimate=" %21.12f `p_value' " se=. n_obs=" %12.0f `n_obs'
