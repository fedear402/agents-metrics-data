set linesize 255
import delimited using "./input.csv", clear

sort date
generate double ln_sales = ln(sales)
generate double ln_vix = ln(vix)
generate double dln_vix = ln_vix - ln_vix[_n-1]

forvalues k = 1/15 {
    generate double lag_`k' = dln_vix[_n-`k']
}

generate byte sample = !missing(ln_sales)
forvalues k = 1/15 {
    replace sample = 0 if missing(lag_`k')
}

mata:
    y = st_data(., "ln_sales", "sample")
    X = J(rows(y), 1, 1), st_data(., tokens("lag_1 lag_2 lag_3 lag_4 lag_5 lag_6 lag_7 lag_8 lag_9 lag_10 lag_11 lag_12 lag_13 lag_14 lag_15"), "sample")
    N = rows(y)
    XXinv = invsym(X'X)
    b = XXinv * X'y
    u = y - X*b
    S = J(16, 16, 0)

    for (t = 1; t <= N; t++) {
        xt = X[t,.]'
        S = S + u[t]^2 * (xt*xt')
    }
    for (j = 1; j <= 15; j++) {
        for (t = j+1; t <= N; t++) {
            xt = X[t,.]'
            xprev = X[t-j,.]'
            S = S + (1-j/16)*u[t]*u[t-j]*(xt*xprev' + xprev*xt')
        }
    }

    V = (N/(N-16)) * XXinv*S*XXinv
    q = J(16, 1, 0)
    q[|2\16|] = J(15, 1, 1)

    st_numscalar("n_obs", N)
    st_numscalar("cum_est", q'b)
    st_numscalar("cum_se", sqrt(q'V*q))
    st_numscalar("lag1_est", b[2])
    st_numscalar("lag1_se", sqrt(V[2,2]))
    st_numscalar("lag15_est", b[16])
    st_numscalar("lag15_se", sqrt(V[16,16]))
end

display "ANSWER: cumulative_response estimate=" %21.12f scalar(cum_est) " se=" %21.12f scalar(cum_se) " n_obs=" %12.0f scalar(n_obs)
display "ANSWER: lag_1 estimate=" %21.12f scalar(lag1_est) " se=" %21.12f scalar(lag1_se) " n_obs=" %12.0f scalar(n_obs)
display "ANSWER: lag_15 estimate=" %21.12f scalar(lag15_est) " se=" %21.12f scalar(lag15_se) " n_obs=" %12.0f scalar(n_obs)
