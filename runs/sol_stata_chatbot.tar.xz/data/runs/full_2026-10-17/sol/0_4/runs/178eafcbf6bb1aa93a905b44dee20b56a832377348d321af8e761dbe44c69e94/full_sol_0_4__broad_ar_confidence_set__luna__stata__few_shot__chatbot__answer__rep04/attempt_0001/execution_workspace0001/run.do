clear all
set more off
set linesize 255
set type double

import delimited "./input.csv", clear
quietly count
scalar n_obs = r(N)
scalar df = n_obs - 4
scalar q = 2
scalar critical = invFtail(q, df, .05)
scalar k = q*critical/df

quietly regress y x
predict double ry, residuals
quietly regress endog x
predict double rd, residuals

quietly regress y x z1 z2
predict double uy, residuals
quietly regress endog x z1 z2
predict double ud, residuals

mata:
    ry = st_data(., "ry")
    rd = st_data(., "rd")
    uy = st_data(., "uy")
    ud = st_data(., "ud")
    k = st_numscalar("k")

    rr_y = quadcross(ry, ry)
    rr_yd = quadcross(ry, rd)
    rr_d = quadcross(rd, rd)
    uu_y = quadcross(uy, uy)
    uu_yd = quadcross(uy, ud)
    uu_d = quadcross(ud, ud)

    A = rr_d - (1+k)*uu_d
    B = -2*(rr_yd - (1+k)*uu_yd)
    C = rr_y - (1+k)*uu_y
    D = B^2 - 4*A*C

    if (A == 0 | D <= 0) _error(3498)
    roots = sort(((-B-sqrt(D))/(2*A) \ (-B+sqrt(D))/(2*A)), 1)

    st_numscalar("boundary_low", roots[1])
    st_numscalar("boundary_high", roots[2])
    st_numscalar("accepts_zero", C <= 0)
    st_numscalar("unbounded", A < 0)
    st_numscalar("ar_f_at_one", ((rr_y-2*rr_yd+rr_d) - ///
        (uu_y-2*uu_yd+uu_d))/2 / ((uu_y-2*uu_yd+uu_d)/st_numscalar("df")))
end

display "ANSWER: boundary_low estimate=" %21.12f boundary_low " se=. n_obs=" %12.0f n_obs
display "ANSWER: boundary_high estimate=" %21.12f boundary_high " se=. n_obs=" %12.0f n_obs
display "ANSWER: accepts_zero estimate=" %21.12f accepts_zero " se=. n_obs=" %12.0f n_obs
display "ANSWER: unbounded estimate=" %21.12f unbounded " se=. n_obs=" %12.0f n_obs
display "ANSWER: ar_f_at_one estimate=" %21.12f ar_f_at_one " se=. n_obs=" %12.0f n_obs
