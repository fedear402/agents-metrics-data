set linesize 255
import delimited using "./input.csv", clear

capture confirm string variable date
if !_rc {
    gen double trading_date = daily(date, "YMD")
    format trading_date %td
    sort trading_date
}
else {
    sort date
}

gen double log_sales = ln(sales)
gen double log_vix = ln(vix)
gen double vix_change = log_vix - log_vix[_n-1]

forvalues k = 1/15 {
    gen double lag_`k' = vix_change[_n-`k']
}

regress log_sales lag_1-lag_15
gen byte regression_sample = e(sample)
predict double residual if regression_sample, residuals

mata:
    X = st_data(., tokens("lag_1 lag_2 lag_3 lag_4 lag_5 lag_6 lag_7 lag_8 lag_9 lag_10 lag_11 lag_12 lag_13 lag_14 lag_15"), "regression_sample")
    X = X, J(rows(X), 1, 1)
    u = st_data(., "residual", "regression_sample")
    N = rows(X)
    S = X :* u
    meat = cross(S, S)
    for (j = 1; j <= 15; j++) {
        G = S[(j+1)..N, ]' * S[1..(N-j), ]
        meat = meat + (1 - j/16) * (G + G')
    }
    bread = invsym(cross(X, X))
    Vnw = (N/(N-16)) * bread * meat * bread
    st_matrix("Vnw", Vnw)
end

scalar n_obs = e(N)
scalar lag_1_estimate = _b[lag_1]
scalar lag_15_estimate = _b[lag_15]
scalar lag_1_se = sqrt(Vnw[1,1])
scalar lag_15_se = sqrt(Vnw[15,15])

scalar cumulative_estimate = 0
scalar cumulative_variance = 0
forvalues i = 1/15 {
    scalar cumulative_estimate = cumulative_estimate + _b[lag_`i']
    forvalues j = 1/15 {
        scalar cumulative_variance = cumulative_variance + Vnw[`i',`j']
    }
}
scalar cumulative_se = sqrt(cumulative_variance)

display "ANSWER: cumulative_response estimate=" %21.12f cumulative_estimate " se=" %21.12f cumulative_se " n_obs=" %12.0f n_obs
display "ANSWER: lag_1 estimate=" %21.12f lag_1_estimate " se=" %21.12f lag_1_se " n_obs=" %12.0f n_obs
display "ANSWER: lag_15 estimate=" %21.12f lag_15_estimate " se=" %21.12f lag_15_se " n_obs=" %12.0f n_obs
