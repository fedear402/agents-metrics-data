clear all
set more off
set linesize 255

import delimited "./input.csv", clear

* Normalize regional weights using one observation per region.
bysort region_id: gen byte region_tag = (_n == 1)
gen double weight_once = cond(region_tag, region_weight, 0)
quietly summarize weight_once, meanonly
gen double e = region_weight / r(sum)

* Construct the regional instrument.
gen double share_shock = share * shock
bysort region_id: egen double z = total(share_shock)

* Subtract weighted regional means.
foreach v in y x z {
    gen double weighted_`v' = cond(region_tag, e * `v', 0)
    quietly summarize weighted_`v', meanonly
    gen double `v'0 = `v' - r(sum)
}

* Aggregate residuals to industries.
gen double s_part = e * share
foreach v in y x z {
    gen double `v'_part = s_part * `v'0
}
collapse (sum) s=s_part y_num=y_part x_num=x_part z_num=z_part ///
         (firstnm) shock, by(industry_id)

local N = _N
foreach v in y x z {
    gen double `v'bar = `v'_num / s
}

* Center shock-level variables using the exposure weights.
foreach v in shock ybar xbar zbar {
    gen double weighted_`v' = s * `v'
    quietly summarize weighted_`v', meanonly
    scalar mean_`v' = r(sum)
}
quietly summarize s, meanonly
scalar total_s = r(sum)

foreach v in shock ybar xbar zbar {
    replace mean_`v' = mean_`v' / total_s
    gen double c_`v' = `v' - mean_`v'
}

* Shock-level IV slopes equal the requested regional slopes.
gen double effect_num = s * c_shock * c_ybar
gen double effect_den = s * c_shock * c_xbar
gen double first_num  = s * c_shock * c_xbar
gen double first_den  = s * c_shock * c_zbar

foreach v in effect_num effect_den first_num first_den {
    quietly summarize `v', meanonly
    scalar sum_`v' = r(sum)
}
scalar effect = sum_effect_num / sum_effect_den
scalar first_stage = sum_first_num / sum_first_den

* HC1 IV variance uses structural residuals and industry observations.
gen double effect_u = c_ybar - effect * c_xbar
gen double first_u  = c_xbar - first_stage * c_zbar
gen double effect_meat = (s * c_shock * effect_u)^2
gen double first_meat  = (s * c_shock * first_u)^2
quietly summarize effect_meat, meanonly
scalar effect_se = sqrt((`N' / (`N' - 2)) * r(sum) / sum_effect_den^2)
quietly summarize first_meat, meanonly
scalar first_stage_se = sqrt((`N' / (`N' - 2)) * r(sum) / sum_first_den^2)

gen double s_squared = s^2
quietly summarize s_squared, meanonly
scalar effective_shocks = 1 / r(sum)

display "ANSWER: effect estimate=" %21.12f effect ///
    " se=" %21.12f effect_se " n_obs=" %12.0f `N'
display "ANSWER: first_stage estimate=" %21.12f first_stage ///
    " se=" %21.12f first_stage_se " n_obs=" %12.0f `N'
display "ANSWER: effective_shocks estimate=" %21.12f effective_shocks ///
    " se=. n_obs=" %12.0f `N'
