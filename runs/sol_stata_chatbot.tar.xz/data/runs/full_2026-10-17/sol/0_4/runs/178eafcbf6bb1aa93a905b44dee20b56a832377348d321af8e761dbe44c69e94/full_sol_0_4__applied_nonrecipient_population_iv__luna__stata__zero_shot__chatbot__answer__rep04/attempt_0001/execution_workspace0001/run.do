clear all
set more off

import delimited "households.csv", clear varnames(1)
keep if recipient == 0

generate double ineligible = 1 - eligible
generate double dose_ineligible = dose * ineligible
generate double dose_eligible = dose * eligible
generate double baseline_ineligible = baseline * ineligible
generate double baseline_eligible = baseline * eligible
generate double instrument_ineligible = instrument * ineligible
generate double instrument_eligible = instrument * eligible

ivregress 2sls ineligible eligible baseline_ineligible baseline_eligible ///
    (dose_ineligible dose_eligible = instrument_ineligible instrument_eligible) ///
    [aweight=weight], noconstant

scalar n_obs = e(N)
generate byte estimation_sample = e(sample)

scalar slope_ineligible = _b[dose_ineligible]
scalar slope_eligible = _b[dose_eligible]

quietly summarize dose [aweight=weight] if estimation_sample & eligible == 0, meanonly
scalar ineligible_effect = slope_ineligible * r(mean)

quietly summarize dose [aweight=weight] if estimation_sample & eligible == 1, meanonly
scalar eligible_nonrecipient_effect = slope_eligible * r(mean)

import delimited "census.csv", clear varnames(1)

quietly summarize nonrecipient_population if eligible == 0, meanonly
scalar population_ineligible = r(sum)

quietly summarize nonrecipient_population if eligible == 1, meanonly
scalar population_eligible = r(sum)

scalar population_effect = ///
    (population_ineligible * ineligible_effect + ///
     population_eligible * eligible_nonrecipient_effect) / ///
    (population_ineligible + population_eligible)

display "ANSWER: ineligible_effect estimate=" ///
    strtrim(string(ineligible_effect, "%24.15g")) ///
    " se=NA n_obs=" strtrim(string(n_obs, "%12.0f"))

display "ANSWER: eligible_nonrecipient_effect estimate=" ///
    strtrim(string(eligible_nonrecipient_effect, "%24.15g")) ///
    " se=NA n_obs=" strtrim(string(n_obs, "%12.0f"))

display "ANSWER: population_effect estimate=" ///
    strtrim(string(population_effect, "%24.15g")) ///
    " se=NA n_obs=" strtrim(string(n_obs, "%12.0f"))
