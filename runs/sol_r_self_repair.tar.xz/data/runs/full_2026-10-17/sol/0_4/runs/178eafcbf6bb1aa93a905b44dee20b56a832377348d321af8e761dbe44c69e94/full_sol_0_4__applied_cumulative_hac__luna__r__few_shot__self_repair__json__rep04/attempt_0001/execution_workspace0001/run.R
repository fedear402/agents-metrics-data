library(jsonlite)

data <- read.csv("input.csv", stringsAsFactors = FALSE)
data <- data[order(as.Date(data$date)), ]

log_sales <- log(data$sales)
log_vix <- log(data$vix)
change <- c(NA_real_, diff(log_vix))

t <- seq.int(17L, nrow(data))
X <- cbind(
  "(Intercept)" = 1,
  sapply(1:15, function(k) change[t - k])
)
colnames(X)[-1] <- paste0("lag_", 1:15)
y <- log_sales[t]

complete <- complete.cases(cbind(y, X))
X <- X[complete, , drop = FALSE]
y <- y[complete]
N <- nrow(X)
p <- ncol(X)

fit <- lm.fit(X, y)
beta <- fit$coefficients
scores <- X * as.numeric(fit$residuals)

meat <- crossprod(scores)
for (j in 1:15) {
  lag_product <- crossprod(
    scores[(j + 1):N, , drop = FALSE],
    scores[1:(N - j), , drop = FALSE]
  )
  meat <- meat + (1 - j / 16) * (lag_product + t(lag_product))
}

bread <- solve(crossprod(X))
V <- (N / (N - p)) * bread %*% meat %*% bread
contrast <- c(0, rep(1, 15))

row <- function(term, estimate, se) {
  list(
    term = term,
    estimate = unname(as.numeric(estimate)),
    se = unname(as.numeric(se)),
    n_obs = as.integer(N)
  )
}

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    row(
      "cumulative_response",
      sum(beta[-1]),
      sqrt(drop(t(contrast) %*% V %*% contrast))
    ),
    row("lag_1", beta[2], sqrt(V[2, 2])),
    row("lag_15", beta[16], sqrt(V[16, 16]))
  ),
  method_metadata = list(
    estimator = "OLS with intercept and 15 trading-observation lags of log VIX changes",
    vcov = "Newey-West HAC, Bartlett weights, maximum lag 15, N/(N-16) correction"
  ),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, digits = 16, pretty = TRUE)
