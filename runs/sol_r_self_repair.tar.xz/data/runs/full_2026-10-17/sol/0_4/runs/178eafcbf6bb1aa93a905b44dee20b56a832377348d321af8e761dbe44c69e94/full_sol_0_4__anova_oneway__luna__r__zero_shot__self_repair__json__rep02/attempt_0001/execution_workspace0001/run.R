data <- read.csv("./input.csv", stringsAsFactors = FALSE)
data <- data[complete.cases(data[c("group", "y")]), ]
data$group <- factor(data$group)
data$y <- as.numeric(data$y)

fit <- aov(y ~ group, data = data)
anova_table <- summary(fit)[[1]]
n_obs <- nobs(fit)

terms <- c("F", "df_num", "df_den", "p_value")
values <- c(
  unname(anova_table["group", "F value"]),
  unname(anova_table["group", "Df"]),
  unname(anova_table["Residuals", "Df"]),
  unname(anova_table["group", "Pr(>F)"])
)

estimates <- lapply(seq_along(terms), function(i) {
  list(
    term = terms[i],
    estimate = as.numeric(values[i]),
    se = NULL,
    n_obs = as.integer(n_obs)
  )
})

result <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = estimates,
  method_metadata = list(estimator = "one-way ANOVA", vcov = "classical"),
  diagnostics = list()
)

jsonlite::write_json(
  result,
  path = "result.json",
  auto_unbox = TRUE,
  digits = NA,
  null = "null"
)
