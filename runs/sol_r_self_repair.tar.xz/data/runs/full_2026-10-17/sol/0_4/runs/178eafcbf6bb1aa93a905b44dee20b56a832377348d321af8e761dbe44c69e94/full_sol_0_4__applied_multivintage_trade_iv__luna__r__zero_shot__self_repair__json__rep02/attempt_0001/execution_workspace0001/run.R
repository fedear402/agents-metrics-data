library(jsonlite)

crosswalk <- read.csv("crosswalk.csv")
trade <- read.csv("trade.csv")
areas <- read.csv("areas.csv")
employment <- read.csv("employment.csv")
outcomes <- read.csv("outcomes.csv")

trade <- merge(trade, crosswalk, by = "code")

area_industry <- merge(
  areas[, c("area", "period", "vintage", "total_employment")],
  unique(trade[, c("period", "industry")]),
  by = "period"
)
area_industry <- merge(
  area_industry,
  employment[, c("area", "period", "vintage", "industry", "employment")],
  by = c("area", "period", "vintage", "industry"),
  all.x = TRUE
)
area_industry$employment[is.na(area_industry$employment)] <- 0

national <- aggregate(
  employment ~ period + vintage + industry,
  data = area_industry,
  FUN = sum
)
names(national)[names(national) == "employment"] <- "national_employment"

exposure_data <- merge(
  merge(
    area_industry,
    national,
    by = c("period", "vintage", "industry")
  ),
  trade[, c("period", "industry", "us_change", "other_change",
            "price_index", "years")],
  by = c("period", "industry")
)

exposure_data$contribution <- with(exposure_data, {
  change <- ifelse(vintage == "base", us_change, other_change)
  (employment / total_employment) *
    (change / national_employment) /
    (price_index / 100) / 1000 * (10 / years)
})

exposures <- aggregate(
  contribution ~ area + period + vintage,
  data = exposure_data,
  FUN = sum
)
wide <- reshape(
  exposures,
  idvar = c("area", "period"),
  timevar = "vintage",
  direction = "wide"
)
names(wide)[names(wide) == "contribution.base"] <- "x"
names(wide)[names(wide) == "contribution.early"] <- "z"

base_areas <- areas[areas$vintage == "base",
                    c("area", "period", "population")]
sample <- merge(
  merge(wide, base_areas, by = c("area", "period")),
  outcomes,
  by = c("area", "period")
)
stopifnot(nrow(sample) == 72L, all(is.finite(sample$x)),
          all(is.finite(sample$z)), all(sample$population > 0))

X <- model.matrix(~ period + control + x, data = sample)
Z <- model.matrix(~ period + control + z, data = sample)
y <- sample$change_pp
w <- sample$population

weighted_crossprod <- function(A, B) crossprod(A, w * B)
ZX <- weighted_crossprod(Z, X)
ZZ <- weighted_crossprod(Z, Z)
Zy <- weighted_crossprod(Z, y)
iv_coef <- solve(t(ZX) %*% solve(ZZ, ZX),
                 t(ZX) %*% solve(ZZ, Zy))

value_at <- function(column, area, period) {
  value <- sample[sample$area == area & sample$period == period, column]
  stopifnot(length(value) == 1L)
  unname(value)
}

terms <- c(
  iv_slope = unname(iv_coef["x", 1]),
  exposure_area0_period0 = value_at("x", 0, 0),
  exposure_area0_period1 = value_at("x", 0, 1),
  instrument_area0_period0 = value_at("z", 0, 0)
)
stopifnot(all(is.finite(terms)))

estimates <- lapply(seq_along(terms), function(i) {
  list(
    term = names(terms)[i],
    estimate = unname(terms[i]),
    se = NULL,
    n_obs = 72L
  )
})

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "population-weighted 2SLS",
    outcome = "change_pp",
    endogenous_regressor = "x",
    excluded_instrument = "z",
    exogenous_instruments = c("intercept", "period", "control"),
    weight = "base-vintage population"
  ),
  diagnostics = list(
    n_obs = 72L,
    n_industries = 4L
  )
)

jsonlite::write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  pretty = TRUE,
  digits = 16,
  null = "null"
)
