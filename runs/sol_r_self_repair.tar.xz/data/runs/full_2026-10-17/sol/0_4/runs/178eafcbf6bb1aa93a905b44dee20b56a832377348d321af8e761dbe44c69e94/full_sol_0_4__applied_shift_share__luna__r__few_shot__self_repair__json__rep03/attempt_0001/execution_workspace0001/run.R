library(jsonlite)

d <- read.csv("input.csv", stringsAsFactors = FALSE)
regions <- unique(d$region_id)
industries <- unique(d$industry_id)
R <- length(regions)
N <- length(industries)

r <- match(d$region_id, regions)
n <- match(d$industry_id, industries)

shares <- matrix(0, R, N)
shares[cbind(r, n)] <- d$share
stopifnot(nrow(d) == R * N, all(rowSums(shares) > 0))

region_value <- function(column) {
  value <- column[match(regions, d$region_id)]
  stopifnot(all(column == value[r]))
  as.numeric(value)
}

shock <- d$shock[match(industries, d$industry_id)]
stopifnot(all(d$shock == shock[n]))

e <- region_value(d$region_weight)
e <- e / sum(e)
x <- region_value(d$x)
y <- region_value(d$y)
z <- drop(shares %*% shock)

center <- function(v) v - sum(e * v)
y0 <- center(y)
x0 <- center(x)
z0 <- center(z)

mass <- drop(crossprod(e, shares))
stopifnot(all(mass > 0))
aggregate_exposure <- function(v) {
  drop(crossprod(shares, e * v)) / mass
}

ybar <- aggregate_exposure(y0)
xbar <- aggregate_exposure(x0)
zbar <- aggregate_exposure(z0)

shock_iv <- function(dependent, endogenous) {
  X <- cbind(1, endogenous)
  Z <- cbind(1, shock)
  cross <- crossprod(Z, mass * X)
  beta <- solve(cross, crossprod(Z, mass * dependent))
  residual <- drop(dependent - X %*% beta)
  scores <- Z * (mass * residual)
  inverse <- solve(cross)
  covariance <- (N / (N - 2)) *
    inverse %*% crossprod(scores) %*% t(inverse)
  c(estimate = unname(beta[2]), se = sqrt(covariance[2, 2]))
}

stopifnot(N > 2)
effect <- shock_iv(ybar, xbar)
first_stage <- shock_iv(xbar, zbar)

regional_effect <- sum(e * z0 * y0) / sum(e * z0 * x0)
regional_first_stage <- sum(e * z0 * x0) / sum(e * z0^2)
stopifnot(
  isTRUE(all.equal(unname(effect["estimate"]), regional_effect, tolerance = 1e-9)),
  isTRUE(all.equal(unname(first_stage["estimate"]), regional_first_stage, tolerance = 1e-9))
)

row <- function(term, estimate, se) {
  list(term = term, estimate = unname(as.numeric(estimate)),
       se = if (is.null(se)) NULL else unname(as.numeric(se)),
       n_obs = as.integer(N))
}

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    row("effect", effect["estimate"], effect["se"]),
    row("first_stage", first_stage["estimate"], first_stage["se"]),
    row("effective_shocks", 1 / sum(mass^2), NULL)
  ),
  method_metadata = list(
    estimator = "Weighted regional 2SLS with BHJ shock-level aggregation",
    vcov = "Shock-level structural IV HC1; analytic exposure weights; N/(N-2)"
  ),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null",
           digits = 16, pretty = TRUE)
