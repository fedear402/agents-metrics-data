library(jsonlite)

dat <- read.csv("./input.csv")
y <- as.numeric(dat$y)

fit <- arima(y, order = c(1, 1, 1), include.mean = FALSE, method = "ML")
pred <- predict(fit, n.ahead = 1)

forecast <- unname(pred$pred[1])
se <- unname(pred$se[1])
margin <- qnorm(0.975) * se
n_obs <- length(y)

out <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = list(
    list(term = "forecast", estimate = forecast, se = se, n_obs = n_obs),
    list(term = "lower_95", estimate = forecast - margin, se = NA, n_obs = n_obs),
    list(term = "upper_95", estimate = forecast + margin, se = NA, n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "ARIMA(1,1,1) maximum likelihood without drift",
    vcov = "model-based"
  ),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "result.json", auto_unbox = TRUE, digits = NA, na = "null")
