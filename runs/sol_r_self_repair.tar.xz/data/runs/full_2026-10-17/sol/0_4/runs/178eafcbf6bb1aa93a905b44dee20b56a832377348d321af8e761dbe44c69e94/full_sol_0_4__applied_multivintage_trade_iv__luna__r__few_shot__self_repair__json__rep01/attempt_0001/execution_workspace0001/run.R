crosswalk <- read.csv("crosswalk.csv")
trade <- read.csv("trade.csv")
areas <- read.csv("areas.csv")
employment <- read.csv("employment.csv")
outcomes <- read.csv("outcomes.csv")

trade <- merge(trade, crosswalk, by = "code", sort = FALSE)
national <- aggregate(
  employment ~ period + vintage + industry,
  data = employment,
  FUN = sum
)
names(national)[names(national) == "employment"] <- "national_employment"

cells <- merge(
  areas,
  trade[, c("period", "industry", "us_change", "other_change",
            "price_index", "years")],
  by = "period"
)
cells <- merge(
  cells,
  national,
  by = c("period", "vintage", "industry"),
  all.x = TRUE,
  sort = FALSE
)
cells <- merge(
  cells,
  employment,
  by = c("area", "period", "vintage", "industry"),
  all.x = TRUE,
  sort = FALSE
)
cells$employment[is.na(cells$employment)] <- 0

cells$contribution <- with(
  cells,
  (employment / total_employment) *
    ifelse(vintage == "base", us_change, other_change) /
    national_employment /
    (price_index / 100) / 1000 * (10 / years)
)
exposures <- aggregate(
  contribution ~ area + period + vintage,
  data = cells,
  FUN = sum
)
wide <- reshape(
  exposures,
  idvar = c("area", "period"),
  timevar = "vintage",
  direction = "wide"
)
names(wide)[names(wide) == "contribution.base"] <- "x"
names(wide)[names(wide) == "contribution.early"] <- "z"

base_areas <- areas[areas$vintage == "base",
                    c("area", "period", "population")]
d <- merge(wide, base_areas, by = c("area", "period"))
d <- merge(d, outcomes, by = c("area", "period"))

C <- model.matrix(~ period + control, data = d)
X <- cbind(C, x = d$x)
Z <- cbind(C, z = d$z)
sqrt_w <- sqrt(d$population)
Xw <- X * sqrt_w
Zw <- Z * sqrt_w
yw <- d$change_pp * sqrt_w
fitted_X <- qr.fitted(qr(Zw), Xw)
iv_slope <- unname(qr.coef(qr(fitted_X), yw)["x"])

get_value <- function(column, area_value, period_value) {
  value <- d[d$area == area_value & d$period == period_value, column]
  stopifnot(length(value) == 1L)
  unname(value)
}

terms <- c(
  "iv_slope",
  "exposure_area0_period0",
  "exposure_area0_period1",
  "instrument_area0_period0"
)
values <- c(
  iv_slope,
  get_value("x", 0, 0),
  get_value("x", 0, 1),
  get_value("z", 0, 0)
)
stopifnot(nrow(d) == 72L, all(is.finite(values)))

estimates <- lapply(seq_along(terms), function(i) {
  list(
    term = terms[i],
    estimate = values[i],
    se = NULL,
    n_obs = 72L
  )
})

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    method = "Weighted two-stage least squares",
    endogenous = "x",
    excluded_instrument = "z",
    exogenous = c("intercept", "period", "control"),
    weight = "base-vintage population"
  ),
  diagnostics = list(
    estimation_rows = 72L,
    industries = 4L
  )
)
jsonlite::write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  pretty = TRUE,
  digits = NA,
  null = "null"
)
