data <- read.csv("./input.csv", stringsAsFactors = FALSE)
data <- data[complete.cases(data[, c("group", "y")]), ]
data$group <- factor(data$group)

fit <- aov(y ~ group, data = data)
anova_row <- summary(fit)[[1]][1, ]

values <- c(
  F = unname(anova_row[["F value"]]),
  df_num = unname(anova_row[["Df"]]),
  df_den = unname(df.residual(fit)),
  p_value = unname(anova_row[["Pr(>F)"]])
)

n_obs <- nobs(fit)
estimates <- lapply(names(values), function(term) {
  list(
    term = term,
    estimate = as.numeric(values[[term]]),
    se = NULL,
    n_obs = as.integer(n_obs)
  )
})

result <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "One-way ANOVA",
    vcov = "Classical homoskedastic ANOVA"
  ),
  diagnostics = list()
)

jsonlite::write_json(
  result,
  path = "result.json",
  auto_unbox = TRUE,
  pretty = TRUE,
  digits = 16,
  null = "null"
)
