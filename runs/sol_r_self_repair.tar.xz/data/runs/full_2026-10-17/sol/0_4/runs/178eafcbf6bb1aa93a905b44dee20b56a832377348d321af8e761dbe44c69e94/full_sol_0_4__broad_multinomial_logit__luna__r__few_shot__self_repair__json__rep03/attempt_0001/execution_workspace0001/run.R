d <- read.csv("input.csv")
d$y <- factor(d$y, levels = 0:2)

fit <- nnet::multinom(
  y ~ x + z,
  data = d,
  Hess = TRUE,
  trace = FALSE,
  maxit = 1000,
  reltol = 1e-12,
  abstol = 1e-12
)

B <- coef(fit)
V <- vcov(fit)
n <- nrow(d)

row <- function(term, category, variable) {
  key <- paste0(category, ":", variable)
  list(
    term = term,
    estimate = unname(B[category, variable]),
    se = unname(sqrt(V[key, key])),
    n_obs = n
  )
}

indices <- c(0, B[, "(Intercept)"])
weights <- exp(indices - max(indices))
prob_cat2_zero <- unname(weights[3] / sum(weights))

result <- list(
  task_id = "broad_multinomial_logit",
  platform = "r",
  estimates = list(
    row("x_cat1", "1", "x"),
    row("z_cat1", "1", "z"),
    row("x_cat2", "2", "x"),
    row("z_cat2", "2", "z"),
    list(
      term = "prob_cat2_zero",
      estimate = prob_cat2_zero,
      se = NULL,
      n_obs = n
    )
  ),
  method_metadata = list(
    estimator = "Multinomial logit maximum likelihood; base outcome 0",
    vcov = "Inverse observed-information Hessian"
  ),
  diagnostics = list()
)

jsonlite::write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
