library(jsonlite)

dat <- read.csv("./input.csv")
y <- as.numeric(dat$y)

if (length(y) != 250L || anyNA(y)) {
  stop("Expected 250 nonmissing observations of y.")
}

fit <- stats::arima(
  y,
  order = c(1L, 1L, 1L),
  include.mean = FALSE,
  method = "ML"
)

pred <- stats::predict(fit, n.ahead = 1L)
forecast <- as.numeric(pred$pred[1L])
forecast_se <- as.numeric(pred$se[1L])
critical <- stats::qnorm(0.975)
n_obs <- length(y)

out <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = list(
    list(term = "forecast", estimate = forecast, se = forecast_se, n_obs = n_obs),
    list(term = "lower_95", estimate = forecast - critical * forecast_se,
         se = NULL, n_obs = n_obs),
    list(term = "upper_95", estimate = forecast + critical * forecast_se,
         se = NULL, n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "ARIMA(1,1,1) maximum likelihood without constant or drift",
    vcov = "Model-based one-step forecast variance"
  ),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "result.json", auto_unbox = TRUE, digits = NA)
