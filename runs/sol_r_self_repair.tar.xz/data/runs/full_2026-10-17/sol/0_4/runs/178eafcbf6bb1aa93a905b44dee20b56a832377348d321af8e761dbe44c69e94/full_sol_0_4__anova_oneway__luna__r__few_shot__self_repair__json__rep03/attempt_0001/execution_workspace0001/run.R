library(jsonlite)

data <- read.csv("./input.csv")
data <- data[complete.cases(data[, c("group", "y")]), ]
data$group <- factor(data$group)

fit <- aov(y ~ group, data = data)
anova_table <- summary(fit)[[1]]
n_obs <- nobs(fit)

estimates <- list(
  list(term = "F", estimate = unname(anova_table[1, "F value"]), se = NA_real_, n_obs = n_obs),
  list(term = "df_num", estimate = unname(anova_table[1, "Df"]), se = NA_real_, n_obs = n_obs),
  list(term = "df_den", estimate = unname(anova_table[2, "Df"]), se = NA_real_, n_obs = n_obs),
  list(term = "p_value", estimate = unname(anova_table[1, "Pr(>F)"]), se = NA_real_, n_obs = n_obs)
)

out <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = estimates,
  method_metadata = list(estimator = "One-way ANOVA", vcov = "Classical"),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "result.json", auto_unbox = TRUE, digits = NA, na = "null")
