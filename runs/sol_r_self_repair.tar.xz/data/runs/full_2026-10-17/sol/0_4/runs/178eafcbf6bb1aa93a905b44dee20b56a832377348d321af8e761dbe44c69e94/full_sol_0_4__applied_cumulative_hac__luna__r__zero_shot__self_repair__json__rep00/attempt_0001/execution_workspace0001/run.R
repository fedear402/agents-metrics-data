data <- read.csv("input.csv", stringsAsFactors = FALSE)
data <- data[order(as.Date(data$date)), ]

dlog_vix <- c(NA_real_, diff(log(data$vix)))
lag_change <- function(x, k) c(rep(NA_real_, k), head(x, -k))

regression_data <- data.frame(log_sales = log(data$sales))
for (k in 1:15) {
  regression_data[[paste0("lag_", k)]] <- lag_change(dlog_vix, k)
}
regression_data <- regression_data[complete.cases(regression_data), ]

fit <- lm(log_sales ~ ., data = regression_data)
X <- model.matrix(fit)
u <- residuals(fit)
N <- nrow(X)
bread <- solve(crossprod(X))
meat <- matrix(0, ncol(X), ncol(X))

for (j in 0:15) {
  if (j == 0) {
    gamma <- crossprod(X * u)
    meat <- meat + gamma
  } else {
    gamma <- crossprod(X[(j + 1):N, , drop = FALSE] *
                         u[(j + 1):N],
                       X[1:(N - j), , drop = FALSE] *
                         u[1:(N - j)])
    meat <- meat + (1 - j / 16) * (gamma + t(gamma))
  }
}

V <- (N / (N - 16)) * bread %*% meat %*% bread
b <- coef(fit)
lag_names <- paste0("lag_", 1:15)
weights <- as.numeric(names(b) %in% lag_names)
names(weights) <- names(b)

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(
      term = "cumulative_response",
      estimate = unname(sum(b[lag_names])),
      se = unname(sqrt(drop(t(weights) %*% V %*% weights))),
      n_obs = N
    ),
    list(
      term = "lag_1",
      estimate = unname(b["lag_1"]),
      se = unname(sqrt(V["lag_1", "lag_1"])),
      n_obs = N
    ),
    list(
      term = "lag_15",
      estimate = unname(b["lag_15"]),
      se = unname(sqrt(V["lag_15", "lag_15"])),
      n_obs = N
    )
  ),
  method_metadata = list(
    estimator = "OLS with intercept and 15 lagged log VIX changes",
    vcov = "Newey-West HAC, Bartlett lag 15, multiplied by N/(N-16)"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = NA)
