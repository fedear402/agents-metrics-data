d <- read.csv("input.csv")
n <- nrow(d)
q <- 2L
df <- n - 4L
critical <- qf(0.95, q, df)

restricted_y <- resid(lm(y ~ x, data = d))
restricted_e <- resid(lm(endog ~ x, data = d))
full_y <- resid(lm(y ~ x + z1 + z2, data = d))
full_e <- resid(lm(endog ~ x + z1 + z2, data = d))

k <- q * critical / df
A <- sum(restricted_e^2) - (1 + k) * sum(full_e^2)
B <- -2 * (sum(restricted_y * restricted_e) -
           (1 + k) * sum(full_y * full_e))
C <- sum(restricted_y^2) - (1 + k) * sum(full_y^2)

discriminant <- B^2 - 4 * A * C
if (!is.finite(discriminant) || discriminant <= 0 || A == 0) {
  stop("Expected two distinct finite boundary points.")
}
bounds <- sort(c(
  (-B - sqrt(discriminant)) / (2 * A),
  (-B + sqrt(discriminant)) / (2 * A)
))

ssr_r_at_one <- sum((restricted_y - restricted_e)^2)
ssr_u_at_one <- sum((full_y - full_e)^2)
ar_f_at_one <- ((ssr_r_at_one - ssr_u_at_one) / q) /
  (ssr_u_at_one / df)

rows <- list(
  list(term = "boundary_low", estimate = bounds[1], se = NULL, n_obs = n),
  list(term = "boundary_high", estimate = bounds[2], se = NULL, n_obs = n),
  list(term = "accepts_zero", estimate = as.integer(C <= 0), se = NULL, n_obs = n),
  list(term = "unbounded", estimate = as.integer(A < 0), se = NULL, n_obs = n),
  list(term = "ar_f_at_one", estimate = ar_f_at_one, se = NULL, n_obs = n)
)

jsonlite::write_json(
  list(
    task_id = "broad_ar_confidence_set",
    platform = "r",
    estimates = rows,
    method_metadata = list(
      estimator = "Anderson-Rubin test inversion",
      vcov = "Conventional homoskedastic OLS"
    ),
    diagnostics = list()
  ),
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
