library(jsonlite)

households <- read.csv("households.csv")
census <- read.csv("census.csv")

d <- households[!is.na(households$recipient) & households$recipient == 0, ]
g0 <- as.numeric(d$eligible == 0)
g1 <- as.numeric(d$eligible == 1)

C <- cbind(
  g0,
  g1,
  d$baseline * g0,
  d$baseline * g1
)
X <- cbind(C, d$dose * g0, d$dose * g1)
Z <- cbind(C, d$instrument * g0, d$instrument * g1)

sqrt_w <- sqrt(d$weight)
Xw <- X * sqrt_w
Zw <- Z * sqrt_w
yw <- d$outcome * sqrt_w

fitted_Xw <- qr.fitted(qr(Zw), Xw)
slopes <- as.numeric(qr.coef(qr(fitted_Xw), yw))[5:6]

mean_dose <- c(
  weighted.mean(d$dose[g0 == 1], d$weight[g0 == 1]),
  weighted.mean(d$dose[g1 == 1], d$weight[g1 == 1])
)
effects <- slopes * mean_dose

population <- census$nonrecipient_population[match(0:1, census$eligible)]
stopifnot(length(population) == 2, all(!is.na(population)))

terms <- c(
  "ineligible_effect",
  "eligible_nonrecipient_effect",
  "population_effect"
)
values <- c(effects, weighted.mean(effects, population))
n_obs <- as.integer(nrow(d))

estimates <- lapply(seq_along(terms), function(i) {
  list(term = terms[i], estimate = unname(values[i]), se = NULL, n_obs = n_obs)
})

result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "Weighted two-stage least squares",
    sample = "All households with recipient equal to zero",
    counterfactual = "Dose set to zero for every retained household",
    group_effect = "Group dose slope times household-weighted mean dose",
    population_weights = "Census nonrecipient_population"
  ),
  diagnostics = list(n_obs = n_obs)
)

write_json(result, "result.json", auto_unbox = TRUE, pretty = TRUE, digits = NA, null = "null")
