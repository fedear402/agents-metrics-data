library(jsonlite)

data <- read.csv("input.csv", stringsAsFactors = FALSE)
data <- data[order(as.Date(data$date)), ]

log_sales <- log(data$sales)
change <- c(NA_real_, diff(log(data$vix)))

n_total <- nrow(data)
stopifnot(n_total >= 33)

rows <- seq.int(17L, n_total)
lagged_changes <- sapply(1:15, function(k) change[rows - k])
colnames(lagged_changes) <- paste0("lag_", 1:15)

complete <- complete.cases(log_sales[rows], lagged_changes)
y <- log_sales[rows][complete]
X <- cbind("(Intercept)" = 1, lagged_changes[complete, , drop = FALSE])

fit <- lm.fit(X, y)
stopifnot(fit$rank == 16L)

coefficients <- fit$coefficients
N <- nrow(X)
scores <- X * as.numeric(fit$residuals)

meat <- crossprod(scores)
for (j in 1:15) {
  lag_product <- crossprod(
    scores[(j + 1):N, , drop = FALSE],
    scores[1:(N - j), , drop = FALSE]
  )
  meat <- meat + (1 - j / 16) * (lag_product + t(lag_product))
}

bread <- solve(crossprod(X))
covariance <- (N / (N - 16)) * bread %*% meat %*% bread

contrast <- c(0, rep(1, 15))
cumulative_estimate <- sum(contrast * coefficients)
cumulative_se <- sqrt(drop(t(contrast) %*% covariance %*% contrast))

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(
      term = "cumulative_response",
      estimate = unname(cumulative_estimate),
      se = unname(cumulative_se),
      n_obs = N
    ),
    list(
      term = "lag_1",
      estimate = unname(coefficients[2]),
      se = unname(sqrt(covariance[2, 2])),
      n_obs = N
    ),
    list(
      term = "lag_15",
      estimate = unname(coefficients[16]),
      se = unname(sqrt(covariance[16, 16])),
      n_obs = N
    )
  ),
  method_metadata = list(
    estimator = "OLS with intercept and 15 trading-observation lags of log VIX changes",
    vcov = "Newey-West Bartlett HAC, maximum lag 15, scaled by N/(N-16)"
  ),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, digits = 16, pretty = TRUE)
