# Save as an R script and run with Rscript in the directory containing input.csv.
d <- read.csv("input.csv", stringsAsFactors = FALSE)

required <- c("region_id", "industry_id", "share", "shock",
              "region_weight", "x", "y")
stopifnot(all(required %in% names(d)), all(complete.cases(d[required])))

regions <- unique(d$region_id)
industries <- unique(d$industry_id)
r <- match(d$region_id, regions)
n <- match(d$industry_id, industries)
R <- length(regions)
N <- length(industries)

regional <- d[match(regions, d$region_id), ]
shock <- d$shock[match(industries, d$industry_id)]
stopifnot(
  N > 2L,
  all(d$region_weight == regional$region_weight[r]),
  all(d$x == regional$x[r]),
  all(d$y == regional$y[r]),
  all(d$shock == shock[n]),
  all(regional$region_weight >= 0),
  sum(regional$region_weight) > 0
)

share_sum <- tabulate(r, nbins = R, weights = d$share)
stopifnot(all(abs(share_sum - 1) < 1e-8))

e <- regional$region_weight / sum(regional$region_weight)
z <- tabulate(r, nbins = R, weights = d$share * shock[n])

demean <- function(v) v - sum(e * v)
y0 <- demean(regional$y)
x0 <- demean(regional$x)
z0 <- demean(z)

exposure <- e[r] * d$share
s <- tabulate(n, nbins = N, weights = exposure)
stopifnot(all(s > 0))

aggregate_residual <- function(v0) {
  tabulate(n, nbins = N, weights = exposure * v0[r]) / s
}
ybar <- aggregate_residual(y0)
xbar <- aggregate_residual(x0)
zbar <- aggregate_residual(z0)

# Weighted IV with an intercept. Industries are independent observations.
# The sandwich uses analytic weights and structural IV residuals.
shock_iv <- function(outcome, endogenous) {
  weighted_mean <- function(v) sum(s * v) / sum(s)
  g0 <- shock - weighted_mean(shock)
  d0 <- endogenous - weighted_mean(endogenous)
  q0 <- outcome - weighted_mean(outcome)

  denominator <- sum(s * g0 * d0)
  stopifnot(is.finite(denominator), abs(denominator) > .Machine$double.eps)

  slope <- sum(s * g0 * q0) / denominator
  intercept <- weighted_mean(outcome) - slope * weighted_mean(endogenous)
  residual <- outcome - intercept - slope * endogenous

  variance <- (N / (N - 2)) *
    sum((s * g0 * residual)^2) / denominator^2
  list(estimate = unname(slope), se = unname(sqrt(variance)))
}

effect <- shock_iv(ybar, xbar)
first_stage <- shock_iv(xbar, zbar)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = effect$estimate,
         se = effect$se, n_obs = N),
    list(term = "first_stage", estimate = first_stage$estimate,
         se = first_stage$se, n_obs = N),
    list(term = "effective_shocks", estimate = unname(1 / sum(s^2)),
         se = NULL, n_obs = N)
  ),
  method_metadata = list(
    estimator = "Weighted regional 2SLS via BHJ shock-level aggregation",
    vcov = "Shock-level heteroskedasticity-robust HC1; multiplier N/(N-2)"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = NA)
