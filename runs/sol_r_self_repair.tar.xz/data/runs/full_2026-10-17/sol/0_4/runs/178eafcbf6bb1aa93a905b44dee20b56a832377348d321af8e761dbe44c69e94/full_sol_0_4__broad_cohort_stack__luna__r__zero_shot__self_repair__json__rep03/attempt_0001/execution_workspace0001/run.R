library(jsonlite)

data <- read.csv("input.csv")

cohorts <- c(3L, 5L, 7L)
results <- vector("list", length(cohorts))
treated_counts <- numeric(length(cohorts))

for (i in seq_along(cohorts)) {
  cohort <- cohorts[i]
  window <- seq.int(cohort - 2L, cohort + 2L)

  eligible <- data[
    data$time %in% window &
      (data$g == cohort | data$g == 0L | data$g > cohort + 2L),
  ]

  observations_per_unit <- table(eligible$id)
  balanced_ids <- names(observations_per_unit)[observations_per_unit == 5L]
  comparison <- eligible[as.character(eligible$id) %in% balanced_ids, ]

  comparison$did <- as.integer(
    comparison$g == cohort & comparison$time >= cohort
  )

  fit <- lm(y ~ did + factor(id) + factor(time), data = comparison)

  results[[i]] <- list(
    term = paste0("att_g", cohort),
    estimate = unname(as.numeric(coef(fit)["did"])),
    se = NULL,
    n_obs = nrow(comparison)
  )
  treated_counts[i] <- length(unique(comparison$id[comparison$g == cohort]))
}

estimates <- vapply(results, function(result) result$estimate, numeric(1))
results[[length(results) + 1L]] <- list(
  term = "att_weighted",
  estimate = unname(weighted.mean(estimates, treated_counts)),
  se = NULL,
  n_obs = sum(vapply(results, function(result) result$n_obs, integer(1)))
)

write_json(
  list(
    task_id = "broad_cohort_stack",
    platform = "r",
    estimates = results,
    method_metadata = list(),
    diagnostics = list()
  ),
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = NA
)
