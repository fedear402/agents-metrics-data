library(jsonlite)

dat <- read.csv("./input.csv")
dat <- dat[order(dat$t), ]
y <- as.numeric(dat$y)

if (length(y) != 250L || anyNA(y) || any(!is.finite(y))) {
  stop("Expected 250 finite observations of y.")
}

fit <- stats::arima(
  y,
  order = c(1L, 1L, 1L),
  include.mean = FALSE,
  method = "ML"
)

pred <- stats::predict(fit, n.ahead = 1L)
forecast <- unname(as.numeric(pred$pred[1L]))
forecast_se <- unname(as.numeric(pred$se[1L]))
critical_value <- stats::qnorm(0.975)

out <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = list(
    list(term = "forecast", estimate = forecast,
         se = forecast_se, n_obs = length(y)),
    list(term = "lower_95", estimate = forecast - critical_value * forecast_se,
         se = NA_real_, n_obs = length(y)),
    list(term = "upper_95", estimate = forecast + critical_value * forecast_se,
         se = NA_real_, n_obs = length(y))
  ),
  method_metadata = list(
    estimator = "ARIMA(1,1,1) maximum likelihood without constant or drift",
    vcov = "model-based forecast variance"
  ),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "result.json", auto_unbox = TRUE, digits = NA, na = "null")
