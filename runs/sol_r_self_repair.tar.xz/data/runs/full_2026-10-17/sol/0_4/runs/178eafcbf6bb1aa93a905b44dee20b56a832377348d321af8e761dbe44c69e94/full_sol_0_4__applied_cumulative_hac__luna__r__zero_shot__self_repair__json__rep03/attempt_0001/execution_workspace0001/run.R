d <- read.csv("input.csv", stringsAsFactors = FALSE)
d <- d[order(as.Date(d$date)), ]

log_vix <- log(d$vix)
change <- c(NA_real_, diff(log_vix))
n <- nrow(d)
rows <- seq.int(17L, n)
N <- length(rows)

X <- cbind(
  "(Intercept)" = 1,
  sapply(1:15, function(k) change[rows - k])
)
colnames(X)[-1] <- paste0("lag_", 1:15)
y <- log(d$sales[rows])

fit <- lm.fit(X, y)
beta <- as.vector(fit$coefficients)
names(beta) <- colnames(X)

scores <- X * as.vector(fit$residuals)
meat <- crossprod(scores)
for (j in 1:15) {
  cross_lag <- crossprod(
    scores[(j + 1):N, , drop = FALSE],
    scores[1:(N - j), , drop = FALSE]
  )
  meat <- meat + (1 - j / 16) * (cross_lag + t(cross_lag))
}

bread <- solve(crossprod(X))
vcov_hac <- (N / (N - 16)) * bread %*% meat %*% bread
lag_idx <- match(paste0("lag_", 1:15), names(beta))
cumulative_se <- sqrt(sum(vcov_hac[lag_idx, lag_idx]))

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(
      term = "cumulative_response",
      estimate = unname(sum(beta[lag_idx])),
      se = unname(cumulative_se),
      n_obs = N
    ),
    list(
      term = "lag_1",
      estimate = unname(beta["lag_1"]),
      se = unname(sqrt(vcov_hac[match("lag_1", names(beta)),
                                match("lag_1", names(beta))])),
      n_obs = N
    ),
    list(
      term = "lag_15",
      estimate = unname(beta["lag_15"]),
      se = unname(sqrt(vcov_hac[match("lag_15", names(beta)),
                                match("lag_15", names(beta))])),
      n_obs = N
    )
  ),
  method_metadata = list(
    estimator = "OLS with intercept and 15 lagged log VIX changes",
    vcov = "Newey-West HAC, Bartlett lag 15, multiplied by N/(N-16)"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = NA)
