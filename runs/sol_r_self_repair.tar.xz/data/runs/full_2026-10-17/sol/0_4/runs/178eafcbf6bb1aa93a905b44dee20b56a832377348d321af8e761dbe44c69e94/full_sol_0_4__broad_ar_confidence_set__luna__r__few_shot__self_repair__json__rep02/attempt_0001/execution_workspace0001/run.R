d <- read.csv("input.csv")
n <- nrow(d)
q <- 2L
df <- n - 4L
critical <- qf(0.95, q, df)
k <- q * critical / df

restricted <- model.matrix(~ x, data = d)
unrestricted <- model.matrix(~ x + z1 + z2, data = d)

residualize <- function(v, design) qr.resid(qr(design), v)

ry <- residualize(d$y, restricted)
rd <- residualize(d$endog, restricted)
uy <- residualize(d$y, unrestricted)
ud <- residualize(d$endog, unrestricted)

A <- sum(rd^2) - (1 + k) * sum(ud^2)
B <- -2 * (sum(ry * rd) - (1 + k) * sum(uy * ud))
C <- sum(ry^2) - (1 + k) * sum(uy^2)

discriminant <- B^2 - 4 * A * C
stopifnot(is.finite(discriminant), discriminant > 0, A != 0)
bounds <- sort(c((-B - sqrt(discriminant)) / (2 * A),
                 (-B + sqrt(discriminant)) / (2 * A)))

f_at <- function(beta) {
  restricted_ssr <- sum((ry - beta * rd)^2)
  unrestricted_ssr <- sum((uy - beta * ud)^2)
  ((restricted_ssr - unrestricted_ssr) / q) / (unrestricted_ssr / df)
}

values <- c(
  boundary_low = bounds[1],
  boundary_high = bounds[2],
  accepts_zero = as.numeric(C <= 0),
  unbounded = as.numeric(A < 0),
  ar_f_at_one = f_at(1)
)

estimates <- lapply(names(values), function(term) {
  list(term = term, estimate = unname(values[[term]]), se = NULL, n_obs = n)
})

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "Anderson-Rubin confidence set by inversion of the joint F test",
    vcov = "Conventional homoskedastic OLS"
  ),
  diagnostics = list()
)

jsonlite::write_json(
  result, "result.json", auto_unbox = TRUE, null = "null",
  digits = 16, pretty = TRUE
)
