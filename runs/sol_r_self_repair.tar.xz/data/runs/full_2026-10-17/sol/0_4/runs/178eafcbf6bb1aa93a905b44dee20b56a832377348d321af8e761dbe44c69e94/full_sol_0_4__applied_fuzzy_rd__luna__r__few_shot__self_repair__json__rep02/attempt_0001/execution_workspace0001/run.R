library(jsonlite)

data <- read.csv("input.csv")
sample <- data[!is.na(data$score) &
               !is.na(data$earnings) &
               !is.na(data$participated) &
               abs(data$score) < 1, ]

score <- sample$score
right <- as.numeric(score >= 0)
weights <- 1 - abs(score)
X <- cbind(1, score, right, score * right)
Y <- cbind(sample$earnings, sample$participated)

bread <- solve(crossprod(X, weights * X))
coefficients <- bread %*% crossprod(X, weights * Y)
residuals <- Y - X %*% coefficients

contrast <- c(0, 0, 1, 0)
jumps <- drop(contrast %*% coefficients)
loading <- weights * drop(X %*% bread %*% contrast)
influence <- residuals * loading
joint_vcov <- crossprod(influence)

reduced_form <- jumps[1]
first_stage <- jumps[2]
treatment_effect <- reduced_form / first_stage
gradient <- c(1 / first_stage, -reduced_form / first_stage^2)
treatment_variance <- drop(t(gradient) %*% joint_vcov %*% gradient)
n_obs <- nrow(sample)

row <- function(term, estimate, se) {
  list(
    term = term,
    estimate = unname(as.numeric(estimate)),
    se = unname(as.numeric(se)),
    n_obs = as.integer(n_obs)
  )
}

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    row("treatment_effect", treatment_effect, sqrt(treatment_variance)),
    row("reduced_form", reduced_form, sqrt(joint_vcov[1, 1])),
    row("first_stage", first_stage, sqrt(joint_vcov[2, 2]))
  ),
  method_metadata = list(
    estimator = "Weighted local linear fuzzy regression discontinuity",
    vcov = "Joint HC0 sandwich covariance with fixed triangular weights; delta method for ratio"
  ),
  diagnostics = list()
)

write_json(
  result, "result.json",
  auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE
)
