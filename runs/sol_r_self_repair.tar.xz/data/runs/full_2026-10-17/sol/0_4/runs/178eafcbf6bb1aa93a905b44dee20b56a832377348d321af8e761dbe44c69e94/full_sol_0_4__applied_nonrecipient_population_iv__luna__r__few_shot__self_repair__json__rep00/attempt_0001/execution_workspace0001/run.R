library(jsonlite)

households <- read.csv("households.csv")
census <- read.csv("census.csv")

d <- households[!is.na(households$recipient) & households$recipient == 0, ]
required <- c("eligible", "dose", "instrument", "baseline", "weight", "outcome")
d <- d[complete.cases(d[, required]), ]
stopifnot(
  all(d$eligible %in% c(0, 1)),
  all(d$weight > 0),
  all(c(0, 1) %in% census$eligible)
)

g0 <- as.numeric(d$eligible == 0)
g1 <- as.numeric(d$eligible == 1)

C <- cbind(
  ineligible = g0,
  eligible = g1,
  baseline_ineligible = d$baseline * g0,
  baseline_eligible = d$baseline * g1
)
X <- cbind(
  C,
  dose_ineligible = d$dose * g0,
  dose_eligible = d$dose * g1
)
Z <- cbind(
  C,
  instrument_ineligible = d$instrument * g0,
  instrument_eligible = d$instrument * g1
)

sw <- sqrt(d$weight)
Xw <- X * sw
Zw <- Z * sw
yw <- d$outcome * sw
stopifnot(qr(Zw)$rank == ncol(Z), qr(Xw)$rank == ncol(X))

Xhat <- qr.fitted(qr(Zw), Xw)
fit <- qr.coef(qr(Xhat), yw)
stopifnot(all(is.finite(fit)))

mean_dose <- vapply(0:1, function(group) {
  rows <- d$eligible == group
  weighted.mean(d$dose[rows], d$weight[rows])
}, numeric(1))

effects <- c(
  ineligible_effect = unname(fit["dose_ineligible"] * mean_dose[1]),
  eligible_nonrecipient_effect = unname(fit["dose_eligible"] * mean_dose[2])
)

population <- census$nonrecipient_population[
  match(0:1, census$eligible)
]
stopifnot(all(is.finite(population)), all(population >= 0), sum(population) > 0)

results <- c(
  effects,
  population_effect = weighted.mean(effects, population)
)

n_obs <- nrow(d)
estimates <- lapply(names(results), function(term) {
  list(term = term, estimate = unname(results[[term]]), se = NULL, n_obs = n_obs)
})

output <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "weighted two-stage least squares",
    sample = "households with recipient equal to zero",
    exogenous_columns = colnames(C),
    endogenous_columns = tail(colnames(X), 2),
    excluded_instruments = tail(colnames(Z), 2),
    intercept = "separate eligibility indicators; no additional intercept",
    group_effect = "fitted dose slope times household-weighted mean dose",
    counterfactual = "zero dose for every retained household",
    population_aggregation = "census nonrecipient_population weights"
  ),
  diagnostics = list(
    n_obs = n_obs,
    group_n_obs = list(
      ineligible = sum(d$eligible == 0),
      eligible = sum(d$eligible == 1)
    ),
    instrument_matrix_rank = qr(Zw)$rank,
    fitted_regressor_matrix_rank = qr(Xhat)$rank
  )
)

write_json(output, "result.json", auto_unbox = TRUE, pretty = TRUE, null = "null", digits = 15)
