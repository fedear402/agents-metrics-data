library(jsonlite)

data <- read.csv("./input.csv")
y <- as.numeric(data$y)

fit <- stats::arima(
  y,
  order = c(1, 1, 1),
  include.mean = FALSE,
  method = "ML"
)

prediction <- stats::predict(fit, n.ahead = 1)
forecast <- as.numeric(prediction$pred[1])
forecast_se <- as.numeric(prediction$se[1])
critical_value <- stats::qnorm(0.975)
n_obs <- length(y)

out <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = list(
    list(term = "forecast", estimate = forecast, se = forecast_se, n_obs = n_obs),
    list(term = "lower_95", estimate = forecast - critical_value * forecast_se,
         se = NULL, n_obs = n_obs),
    list(term = "upper_95", estimate = forecast + critical_value * forecast_se,
         se = NULL, n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "ARIMA(1,1,1) maximum likelihood, no constant or drift",
    vcov = "model-based"
  ),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "result.json", auto_unbox = TRUE, digits = NA)
