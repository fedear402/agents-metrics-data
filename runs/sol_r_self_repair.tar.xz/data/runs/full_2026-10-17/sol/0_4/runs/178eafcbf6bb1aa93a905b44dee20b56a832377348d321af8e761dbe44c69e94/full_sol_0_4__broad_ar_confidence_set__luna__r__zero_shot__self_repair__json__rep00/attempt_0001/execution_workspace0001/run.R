d <- read.csv("input.csv")
n <- nrow(d)

y <- d$y
e <- d$endog
x <- d$x

restricted <- cbind(1, x)
unrestricted <- cbind(1, x, d$z1, d$z2)

ry <- qr.resid(qr(restricted), y)
re <- qr.resid(qr(restricted), e)
uy <- qr.resid(qr(unrestricted), y)
ue <- qr.resid(qr(unrestricted), e)

rss_coeff <- function(a, b) {
  c(sum(a * a), -2 * sum(a * b), sum(b * b))
}

r <- rss_coeff(ry, re)
u <- rss_coeff(uy, ue)
critical <- qf(0.95, df1 = 2, df2 = n - 4)

# The Anderson-Rubin test accepts beta when q(beta) <= 0.
q <- (n - 4) * (r - u) - 2 * critical * u
roots <- sort(Re(polyroot(q)))
stopifnot(length(roots) == 2L, all(abs(Im(polyroot(q))) < 1e-8))

ar_f <- function(beta) {
  rss_r <- sum((ry - beta * re)^2)
  rss_u <- sum((uy - beta * ue)^2)
  ((rss_r - rss_u) / 2) / (rss_u / (n - 4))
}

estimates <- list(
  list(term = "boundary_low", estimate = roots[1], se = NULL, n_obs = n),
  list(term = "boundary_high", estimate = roots[2], se = NULL, n_obs = n),
  list(term = "accepts_zero", estimate = as.numeric(q[1] <= 0), se = NULL, n_obs = n),
  list(term = "unbounded", estimate = as.numeric(q[3] < 0), se = NULL, n_obs = n),
  list(term = "ar_f_at_one", estimate = ar_f(1), se = NULL, n_obs = n)
)

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "Anderson-Rubin confidence set by quadratic inversion",
    vcov = "Conventional homoskedastic F test"
  ),
  diagnostics = list()
)

jsonlite::write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 15,
  pretty = TRUE
)
