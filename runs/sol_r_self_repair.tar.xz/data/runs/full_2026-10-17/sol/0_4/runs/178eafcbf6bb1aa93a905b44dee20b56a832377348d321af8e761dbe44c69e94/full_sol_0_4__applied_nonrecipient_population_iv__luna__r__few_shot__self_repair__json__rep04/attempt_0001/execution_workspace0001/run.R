library(jsonlite)

households <- read.csv("households.csv")
census <- read.csv("census.csv")

d <- households[households$recipient == 0, ]
g0 <- as.numeric(d$eligible == 0)
g1 <- as.numeric(d$eligible == 1)

C <- cbind(
  ineligible = g0,
  eligible = g1,
  baseline_ineligible = d$baseline * g0,
  baseline_eligible = d$baseline * g1
)
X <- cbind(
  C,
  dose_ineligible = d$dose * g0,
  dose_eligible = d$dose * g1
)
Z <- cbind(
  C,
  instrument_ineligible = d$instrument * g0,
  instrument_eligible = d$instrument * g1
)

sqrt_weight <- sqrt(d$weight)
weighted_X <- X * sqrt_weight
weighted_Z <- Z * sqrt_weight
weighted_y <- d$outcome * sqrt_weight

fitted_X <- qr.fitted(qr(weighted_Z), weighted_X)
coefficients <- qr.coef(qr(fitted_X), weighted_y)

mean_dose <- vapply(0:1, function(group) {
  rows <- d$eligible == group
  weighted.mean(d$dose[rows], d$weight[rows])
}, numeric(1))

group_effects <- c(
  coefficients["dose_ineligible"] * mean_dose[1],
  coefficients["dose_eligible"] * mean_dose[2]
)
names(group_effects) <- c(
  "ineligible_effect",
  "eligible_nonrecipient_effect"
)

population <- census$nonrecipient_population[
  match(0:1, census$eligible)
]
population_effect <- weighted.mean(group_effects, population)

results <- c(group_effects, population_effect = population_effect)
n_obs <- nrow(d)

estimates <- lapply(names(results), function(term) {
  list(
    term = term,
    estimate = unname(results[[term]]),
    se = NULL,
    n_obs = as.integer(n_obs)
  )
})

write_json(
  list(
    task_id = "applied_nonrecipient_population_iv",
    platform = "r",
    estimates = estimates,
    method_metadata = list(
      estimator = "weighted two-stage least squares",
      counterfactual = "dose set to zero for every retained household",
      group_effect = "dose slope times household-weighted group mean dose",
      population_aggregation = "census nonrecipient population weights"
    ),
    diagnostics = list(
      n_obs = as.integer(n_obs)
    )
  ),
  "result.json",
  auto_unbox = TRUE,
  pretty = TRUE,
  digits = 15,
  null = "null"
)
