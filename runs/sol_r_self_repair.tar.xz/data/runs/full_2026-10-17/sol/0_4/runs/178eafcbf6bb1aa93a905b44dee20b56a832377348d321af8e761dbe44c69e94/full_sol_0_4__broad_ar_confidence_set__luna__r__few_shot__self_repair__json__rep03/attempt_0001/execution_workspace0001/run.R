d <- read.csv("input.csv")
n <- nrow(d)
q <- 2L
df <- n - 4L
stopifnot(n == 240L, all(c("y", "endog", "x", "z1", "z2") %in% names(d)))

restricted <- cbind(1, d$x)
unrestricted <- cbind(1, d$x, d$z1, d$z2)
stopifnot(qr(restricted)$rank == 2L, qr(unrestricted)$rank == 4L)

ry <- qr.resid(qr(restricted), d$y)
rd <- qr.resid(qr(restricted), d$endog)
uy <- qr.resid(qr(unrestricted), d$y)
ud <- qr.resid(qr(unrestricted), d$endog)

critical <- qf(0.95, q, df)
k <- q * critical / df
A <- sum(rd^2) - (1 + k) * sum(ud^2)
B <- -2 * (sum(ry * rd) - (1 + k) * sum(uy * ud))
C <- sum(ry^2) - (1 + k) * sum(uy^2)

roots <- polyroot(c(C, B, A))
stopifnot(
  abs(A) > 1e-10,
  length(roots) == 2L,
  all(abs(Im(roots)) < 1e-8)
)
bounds <- sort(Re(roots))
accepts_zero <- as.integer(C <= 0)
unbounded <- as.integer(A < 0)

transformed <- d$y - d$endog
ssr_r_one <- sum(qr.resid(qr(restricted), transformed)^2)
ssr_u_one <- sum(qr.resid(qr(unrestricted), transformed)^2)
ar_f_at_one <- ((ssr_r_one - ssr_u_one) / q) / (ssr_u_one / df)

terms <- c(
  "boundary_low", "boundary_high", "accepts_zero",
  "unbounded", "ar_f_at_one"
)
values <- c(bounds, accepts_zero, unbounded, ar_f_at_one)
estimates <- lapply(seq_along(terms), function(i) {
  list(
    term = terms[i],
    estimate = unname(values[i]),
    se = NULL,
    n_obs = n
  )
})

jsonlite::write_json(
  list(
    task_id = "broad_ar_confidence_set",
    platform = "r",
    estimates = estimates,
    method_metadata = list(
      estimator = "Anderson-Rubin confidence set inversion",
      vcov = "Conventional homoskedastic joint F test"
    ),
    diagnostics = list()
  ),
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
