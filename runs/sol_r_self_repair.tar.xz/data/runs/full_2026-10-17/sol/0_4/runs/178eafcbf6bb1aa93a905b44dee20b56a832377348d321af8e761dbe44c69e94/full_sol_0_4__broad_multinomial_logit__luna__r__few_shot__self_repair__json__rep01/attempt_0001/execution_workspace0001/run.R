d <- read.csv("input.csv")
d$y <- factor(d$y, levels = 0:2)

fit <- nnet::multinom(
  y ~ x + z, data = d, Hess = TRUE, trace = FALSE,
  maxit = 1000, reltol = 1e-12, abstol = 1e-12
)

B <- coef(fit)
V <- vcov(fit)

indices <- c(0, B["1", "(Intercept)"], B["2", "(Intercept)"])
scaled <- exp(indices - max(indices))
prob_cat2_zero <- scaled[3] / sum(scaled)

row <- function(term, estimate, se) {
  list(term = term, estimate = unname(estimate), se = unname(se),
       n_obs = nrow(d))
}

result <- list(
  task_id = "broad_multinomial_logit",
  platform = "r",
  estimates = list(
    row("x_cat1", B["1", "x"], sqrt(V["1:x", "1:x"])),
    row("z_cat1", B["1", "z"], sqrt(V["1:z", "1:z"])),
    row("x_cat2", B["2", "x"], sqrt(V["2:x", "2:x"])),
    row("z_cat2", B["2", "z"], sqrt(V["2:z", "2:z"])),
    row("prob_cat2_zero", prob_cat2_zero, NULL)
  ),
  method_metadata = list(
    estimator = "multinomial logit maximum likelihood",
    vcov = "inverse observed information"
  ),
  diagnostics = list()
)

jsonlite::write_json(
  result, "result.json", auto_unbox = TRUE, null = "null",
  digits = 16, pretty = TRUE
)
