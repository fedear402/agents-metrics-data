dat <- read.csv("input.csv")
n <- nrow(dat)

W <- cbind(1, dat$x)
Z <- cbind(dat$z1, dat$z2)

y_r <- qr.resid(qr(W), dat$y)
d_r <- qr.resid(qr(W), dat$endog)
Z_r <- qr.resid(qr(W), Z)

explained <- function(v) {
  fitted <- qr.fitted(qr(Z_r), v)
  sum(fitted^2)
}

residual <- function(v) {
  sum(qr.resid(qr(Z_r), v)^2)
}

cross_explained <- function(a, b) {
  sum(qr.fitted(qr(Z_r), a) * qr.fitted(qr(Z_r), b))
}

cross_residual <- function(a, b) {
  sum(qr.resid(qr(Z_r), a) * qr.resid(qr(Z_r), b))
}

crit <- qf(0.95, df1 = 2, df2 = n - 4)
scale <- (n - 4) / 2

a <- scale * explained(d_r) - crit * residual(d_r)
b <- -2 * (scale * cross_explained(y_r, d_r) -
           crit * cross_residual(y_r, d_r))
c <- scale * explained(y_r) - crit * residual(y_r)

disc <- b^2 - 4 * a * c
stopifnot(disc > 0, a != 0)

roots <- sort(c((-b - sqrt(disc)) / (2 * a),
                (-b + sqrt(disc)) / (2 * a)))

ar_f_at_one <- scale * explained(y_r - d_r) / residual(y_r - d_r)

values <- c(
  boundary_low = roots[1],
  boundary_high = roots[2],
  accepts_zero = as.numeric(c <= 0),
  unbounded = as.numeric(a < 0),
  ar_f_at_one = ar_f_at_one
)

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = lapply(names(values), function(term) {
    list(term = term, estimate = unname(values[[term]]),
         se = NULL, n_obs = n)
  }),
  method_metadata = list(
    estimator = "Anderson-Rubin confidence set by exact quadratic inversion",
    vcov = "Conventional homoskedastic joint F test"
  ),
  diagnostics = list()
)

writeLines(
  jsonlite::toJSON(result, auto_unbox = TRUE, null = "null", digits = 16),
  "result.json"
)
