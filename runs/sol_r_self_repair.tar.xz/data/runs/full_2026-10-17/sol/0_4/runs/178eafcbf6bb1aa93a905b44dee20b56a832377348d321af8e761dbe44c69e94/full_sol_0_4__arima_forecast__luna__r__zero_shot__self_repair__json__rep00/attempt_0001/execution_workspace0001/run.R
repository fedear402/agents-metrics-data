data <- read.csv("./input.csv")
data <- data[order(data$t), ]

if (anyNA(data$y) || any(!is.finite(data$y))) {
  stop("y must contain only finite values.")
}
if (tail(data$t, 1) != 250) {
  stop("The final observation must be at t = 250.")
}

y <- as.numeric(data$y)
fit <- stats::arima(
  y,
  order = c(1, 1, 1),
  include.mean = FALSE,
  method = "ML"
)
prediction <- stats::predict(fit, n.ahead = 1)

forecast <- as.numeric(prediction$pred[1])
se <- as.numeric(prediction$se[1])
margin <- stats::qnorm(0.975) * se
n_obs <- length(y)

result <- sprintf(
  paste0(
    '{"task_id":"arima_forecast","platform":"r","estimates":[',
    '{"term":"forecast","estimate":%.15g,"se":%.15g,"n_obs":%d},',
    '{"term":"lower_95","estimate":%.15g,"se":null,"n_obs":%d},',
    '{"term":"upper_95","estimate":%.15g,"se":null,"n_obs":%d}',
    '],"method_metadata":{"estimator":"ARIMA(1,1,1) maximum likelihood, no drift",',
    '"vcov":"Model-based forecast variance"},"diagnostics":{}}'
  ),
  forecast, se, n_obs,
  forecast - margin, n_obs,
  forecast + margin, n_obs
)

writeLines(result, "result.json")
