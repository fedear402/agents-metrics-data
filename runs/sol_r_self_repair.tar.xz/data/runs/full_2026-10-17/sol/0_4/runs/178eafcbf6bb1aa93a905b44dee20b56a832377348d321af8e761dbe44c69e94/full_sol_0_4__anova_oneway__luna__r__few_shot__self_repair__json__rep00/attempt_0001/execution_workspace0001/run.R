library(jsonlite)

data <- read.csv("./input.csv", stringsAsFactors = FALSE)
data <- data[complete.cases(data[c("group", "y")]), ]
data$group <- factor(data$group)

fit <- aov(y ~ group, data = data)
anova_table <- summary(fit)[[1]]
n_obs <- nrow(data)

make_row <- function(term, value) {
  list(term = term, estimate = unname(as.numeric(value)),
       se = NA_real_, n_obs = n_obs)
}

out <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = list(
    make_row("F", anova_table[1, "F value"]),
    make_row("df_num", anova_table[1, "Df"]),
    make_row("df_den", anova_table[2, "Df"]),
    make_row("p_value", anova_table[1, "Pr(>F)"])
  ),
  method_metadata = list(
    estimator = "One-way ANOVA",
    vcov = "Classical"
  ),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "result.json", auto_unbox = TRUE, digits = NA)
