households <- read.csv("households.csv")
census <- read.csv("census.csv")

required_households <- c(
  "eligible", "recipient", "instrument", "dose",
  "baseline", "weight", "outcome"
)
required_census <- c("eligible", "nonrecipient_population")

stopifnot(
  all(required_households %in% names(households)),
  all(required_census %in% names(census))
)

sample <- households[households$recipient == 0, , drop = FALSE]
stopifnot(
  nrow(sample) > 0,
  !anyNA(sample[, required_households]),
  all(sample$eligible %in% c(0, 1)),
  all(sample$weight > 0),
  all(c(0, 1) %in% sample$eligible),
  !anyNA(census[, required_census]),
  identical(sort(unique(census$eligible)), c(0L, 1L)),
  all(census$nonrecipient_population >= 0)
)

ineligible <- 1 - sample$eligible
eligible <- sample$eligible

exogenous <- cbind(
  ineligible,
  eligible,
  sample$baseline * ineligible,
  sample$baseline * eligible
)
X <- cbind(
  exogenous,
  sample$dose * ineligible,
  sample$dose * eligible
)
Z <- cbind(
  exogenous,
  sample$instrument * ineligible,
  sample$instrument * eligible
)

weighted_Z <- Z * sample$weight
beta <- as.vector(
  solve(crossprod(weighted_Z, X), crossprod(weighted_Z, sample$outcome))
)

mean_dose <- vapply(c(0, 1), function(group) {
  rows <- sample$eligible == group
  weighted.mean(sample$dose[rows], sample$weight[rows])
}, numeric(1))

ineligible_effect <- beta[5] * mean_dose[1]
eligible_nonrecipient_effect <- beta[6] * mean_dose[2]

population <- vapply(c(0, 1), function(group) {
  sum(census$nonrecipient_population[census$eligible == group])
}, numeric(1))
stopifnot(sum(population) > 0)

population_effect <- weighted.mean(
  c(ineligible_effect, eligible_nonrecipient_effect),
  population
)

make_estimate <- function(term, value) {
  list(term = term, estimate = unname(value), se = NULL, n_obs = nrow(sample))
}

result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = list(
    make_estimate("ineligible_effect", ineligible_effect),
    make_estimate(
      "eligible_nonrecipient_effect",
      eligible_nonrecipient_effect
    ),
    make_estimate("population_effect", population_effect)
  ),
  method_metadata = list(
    estimator = "Weighted two-stage least squares",
    sample = "All household rows with recipient equal to zero",
    regression_weight = "weight",
    intercept = "Group indicators only; no additional intercept",
    counterfactual = paste(
      "Dose equals zero for every retained household.",
      "Attribution to this counterfactual is a stated synthetic convention."
    ),
    group_effect = "Fitted group dose slope times household-weighted group mean dose",
    population_aggregation = "Census nonrecipient_population weights between groups only",
    standard_error = "Not requested"
  ),
  diagnostics = list(
    n_obs = nrow(sample),
    n_ineligible = sum(sample$eligible == 0),
    n_eligible = sum(sample$eligible == 1),
    weighted_mean_dose_ineligible = unname(mean_dose[1]),
    weighted_mean_dose_eligible = unname(mean_dose[2]),
    census_nonrecipient_population_ineligible = unname(population[1]),
    census_nonrecipient_population_eligible = unname(population[2])
  )
)

jsonlite::write_json(
  result,
  path = "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
