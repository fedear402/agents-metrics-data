crosswalk <- read.csv("crosswalk.csv")
trade <- read.csv("trade.csv")
areas <- read.csv("areas.csv")
employment <- read.csv("employment.csv")
outcomes <- read.csv("outcomes.csv")

trade <- merge(trade, crosswalk, by = "code", sort = FALSE)

cells <- merge(
  areas[, c("area", "period", "vintage", "total_employment", "population")],
  trade[, c("period", "industry", "us_change", "other_change",
            "price_index", "years")],
  by = "period",
  sort = FALSE
)
cells <- merge(
  cells,
  employment,
  by = c("area", "period", "vintage", "industry"),
  all.x = TRUE,
  sort = FALSE
)
cells$employment[is.na(cells$employment)] <- 0

national <- aggregate(
  employment ~ period + vintage + industry,
  data = cells,
  FUN = sum
)
names(national)[names(national) == "employment"] <- "national_employment"
cells <- merge(
  cells,
  national,
  by = c("period", "vintage", "industry"),
  sort = FALSE
)

cells$component <- with(cells, {
  change <- ifelse(vintage == "base", us_change, other_change)
  (employment / total_employment) *
    (change / national_employment) /
    (price_index / 100) / 1000 *
    (10 / years)
})

exposures <- aggregate(
  component ~ area + period + vintage,
  data = cells,
  FUN = sum
)
wide <- reshape(
  exposures,
  idvar = c("area", "period"),
  timevar = "vintage",
  direction = "wide"
)
names(wide)[names(wide) == "component.base"] <- "x"
names(wide)[names(wide) == "component.early"] <- "z"

base_areas <- areas[areas$vintage == "base",
                    c("area", "period", "population")]
d <- merge(wide, base_areas, by = c("area", "period"))
d <- merge(d, outcomes, by = c("area", "period"))
d <- d[order(d$period, d$area), ]

C <- model.matrix(~ period + control, data = d)
X <- cbind(C, x = d$x)
Z <- cbind(C, z = d$z)
root_weight <- sqrt(d$population)
weighted_X <- X * root_weight
weighted_Z <- Z * root_weight
weighted_y <- d$change_pp * root_weight
first_stage_fit <- qr.fitted(qr(weighted_Z), weighted_X)
iv_slope <- unname(qr.coef(qr(first_stage_fit), weighted_y)["x"])

get_exposure <- function(area_id, period_id, variable) {
  value <- d[d$area == area_id & d$period == period_id, variable]
  stopifnot(length(value) == 1L)
  unname(value)
}

terms <- c(
  "iv_slope",
  "exposure_area0_period0",
  "exposure_area0_period1",
  "instrument_area0_period0"
)
values <- c(
  iv_slope,
  get_exposure(0, 0, "x"),
  get_exposure(0, 1, "x"),
  get_exposure(0, 0, "z")
)
n_obs <- nrow(d)
stopifnot(n_obs == 72L, all(is.finite(values)))

estimates <- lapply(seq_along(terms), function(i) {
  list(
    term = terms[i],
    estimate = values[i],
    se = NULL,
    n_obs = as.integer(n_obs)
  )
})

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "weighted 2SLS",
    outcome = "change_pp",
    endogenous_regressor = "x",
    excluded_instrument = "z",
    exogenous_instruments = colnames(C),
    weight = "base-vintage population",
    exposure_units = "thousands of real dollars per worker per decade"
  ),
  diagnostics = list(
    n_obs = as.integer(n_obs),
    n_industries = as.integer(length(unique(crosswalk$industry))),
    n_periods = as.integer(length(unique(d$period))),
    first_stage_rank = as.integer(qr(weighted_Z)$rank)
  )
)

jsonlite::write_json(
  result,
  path = "result.json",
  auto_unbox = TRUE,
  pretty = TRUE,
  digits = NA,
  null = "null"
)
