d <- read.csv("input.csv")
d <- d[is.finite(d$score) & abs(d$score) < 1 &
         is.finite(d$earnings) & is.finite(d$participated), ]

x <- d$score
right <- as.numeric(x >= 0)
w <- 1 - abs(x)
X <- cbind(intercept = 1, score = x, right = right, right_score = right * x)
Y <- cbind(earnings = d$earnings, participated = d$participated)

WX <- X * sqrt(w)
WY <- Y * sqrt(w)
beta <- solve(crossprod(WX), crossprod(WX, WY))
resid <- Y - X %*% beta
bread <- solve(crossprod(WX))

# HC0 covariance for both outcomes, including their cross-outcome covariance.
scores <- lapply(seq_len(ncol(Y)), function(j) X * as.vector(w * resid[, j]))
cov_block <- function(a, b) bread %*% crossprod(scores[[a]], scores[[b]]) %*% bread

rf <- unname(beta["right", "earnings"])
fs <- unname(beta["right", "participated"])
te <- rf / fs

var_rf <- cov_block(1, 1)["right", "right"]
var_fs <- cov_block(2, 2)["right", "right"]
cov_rf_fs <- cov_block(1, 2)["right", "right"]
var_te <- var_rf / fs^2 + rf^2 * var_fs / fs^4 -
  2 * rf * cov_rf_fs / fs^3

se_rf <- sqrt(max(0, var_rf))
se_fs <- sqrt(max(0, var_fs))
se_te <- sqrt(max(0, var_te))
n <- nrow(d)

number <- function(z) if (is.finite(z)) sprintf("%.16g", z) else "null"
row <- function(term, estimate, se) {
  sprintf(
    '{"term":"%s","estimate":%s,"se":%s,"n_obs":%d}',
    term, number(estimate), number(se), n
  )
}

output <- paste0(
  '{"task_id":"applied_fuzzy_rd","platform":"r","estimates":[',
  paste(
    row("treatment_effect", te, se_te),
    row("reduced_form", rf, se_rf),
    row("first_stage", fs, se_fs),
    sep = ","
  ),
  '],"method_metadata":{"estimator":"Fuzzy regression discontinuity, local linear Wald ratio, triangular weights, bandwidth 1",',
  '"vcov":"HC0 sandwich with joint outcome covariance; delta method for ratio"},',
  '"diagnostics":{}}'
)

writeLines(output, "result.json")
