library(jsonlite)

crosswalk <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
trade <- read.csv("trade.csv", stringsAsFactors = FALSE)
areas <- read.csv("areas.csv", stringsAsFactors = FALSE)
employment <- read.csv("employment.csv", stringsAsFactors = FALSE)
outcomes <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

trade <- merge(trade, crosswalk, by = "code", sort = FALSE)

industry_totals <- aggregate(
  employment ~ period + vintage + industry,
  data = employment,
  FUN = sum
)
names(industry_totals)[4] <- "national_employment"

cells <- merge(
  areas, trade,
  by = "period",
  sort = FALSE
)
cells <- merge(
  cells, industry_totals,
  by = c("period", "vintage", "industry"),
  all.x = TRUE,
  sort = FALSE
)
cells <- merge(
  cells, employment,
  by = c("area", "period", "vintage", "industry"),
  all.x = TRUE,
  sort = FALSE
)
cells$employment[is.na(cells$employment)] <- 0

cells$exposure_component <- with(
  cells,
  (employment / total_employment) *
    (ifelse(vintage == "base", us_change, other_change) /
       national_employment) /
    (price_index / 100) / 1000 * (10 / years)
)

exposures <- aggregate(
  exposure_component ~ area + period + vintage,
  data = cells,
  FUN = sum
)
wide <- reshape(
  exposures,
  idvar = c("area", "period"),
  timevar = "vintage",
  direction = "wide"
)
names(wide)[names(wide) == "exposure_component.base"] <- "x"
names(wide)[names(wide) == "exposure_component.early"] <- "z"

base_areas <- areas[areas$vintage == "base",
                    c("area", "period", "population")]
d <- merge(base_areas, wide, by = c("area", "period"))
d <- merge(d, outcomes, by = c("area", "period"))
d <- d[order(d$area, d$period), ]

C <- model.matrix(~ period + control, data = d)
X <- cbind(C, x = d$x)
Z <- cbind(C, z = d$z)
sw <- sqrt(d$population)
Xw <- X * sw
Zw <- Z * sw
yw <- d$change_pp * sw
projected_X <- qr.fitted(qr(Zw), Xw)
iv_slope <- unname(qr.coef(qr(projected_X), yw)["x"])

get_value <- function(column, period_value) {
  values <- d[d$area == 0 & d$period == period_value, column]
  stopifnot(length(values) == 1L)
  unname(values)
}

n <- nrow(d)
stopifnot(n == 72L)

terms <- list(
  list(term = "iv_slope", estimate = iv_slope, se = NULL, n_obs = n),
  list(term = "exposure_area0_period0",
       estimate = get_value("x", 0), se = NULL, n_obs = n),
  list(term = "exposure_area0_period1",
       estimate = get_value("x", 1), se = NULL, n_obs = n),
  list(term = "instrument_area0_period0",
       estimate = get_value("z", 0), se = NULL, n_obs = n)
)

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = terms,
  method_metadata = list(
    estimator = "weighted 2SLS",
    endogenous_regressor = "x",
    excluded_instrument = "z",
    exogenous_regressors = c("intercept", "period", "control"),
    weight = "base-vintage population"
  ),
  diagnostics = list(n_obs = n)
)

write_json(result, "result.json", auto_unbox = TRUE, pretty = TRUE,
           digits = 16, null = "null")
