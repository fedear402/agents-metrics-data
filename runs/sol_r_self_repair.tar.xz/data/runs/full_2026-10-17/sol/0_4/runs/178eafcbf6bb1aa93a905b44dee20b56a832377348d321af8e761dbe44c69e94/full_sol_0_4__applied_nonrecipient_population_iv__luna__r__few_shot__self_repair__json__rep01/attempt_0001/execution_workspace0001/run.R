library(jsonlite)

task_id <- "applied_nonrecipient_population_iv"
households <- read.csv("households.csv")
census <- read.csv("census.csv")

d <- households[households$recipient == 0, ]
n_obs <- nrow(d)

g0 <- as.numeric(d$eligible == 0)
g1 <- as.numeric(d$eligible == 1)

C <- cbind(
  g0,
  g1,
  d$baseline * g0,
  d$baseline * g1
)
X <- cbind(C, d$dose * g0, d$dose * g1)
Z <- cbind(C, d$instrument * g0, d$instrument * g1)

sqrt_weight <- sqrt(d$weight)
Xw <- X * sqrt_weight
Zw <- Z * sqrt_weight
yw <- d$outcome * sqrt_weight

z_qr <- qr(Zw)
if (z_qr$rank != ncol(Zw)) stop("Instrument matrix is rank deficient.")
fitted_Xw <- qr.fitted(z_qr, Xw)
x_qr <- qr(fitted_Xw)
if (x_qr$rank != ncol(Xw)) stop("Weighted 2SLS is underidentified.")

coef <- as.numeric(qr.coef(x_qr, yw))
mean_dose_0 <- weighted.mean(d$dose[g0 == 1], d$weight[g0 == 1])
mean_dose_1 <- weighted.mean(d$dose[g1 == 1], d$weight[g1 == 1])

effects <- c(
  ineligible_effect = coef[5] * mean_dose_0,
  eligible_nonrecipient_effect = coef[6] * mean_dose_1
)

population <- census$nonrecipient_population[match(c(0, 1), census$eligible)]
if (anyNA(population)) stop("Census must contain both eligibility groups.")
effects <- c(
  effects,
  population_effect = weighted.mean(effects, population)
)

estimates <- lapply(names(effects), function(term) {
  list(
    term = term,
    estimate = unname(effects[[term]]),
    se = NULL,
    n_obs = as.integer(n_obs)
  )
})

result <- list(
  task_id = task_id,
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "weighted 2SLS",
    sample = "households with recipient == 0",
    counterfactual = "dose set to zero for every retained household",
    group_effect = "group dose slope times household-weighted group mean dose",
    aggregation = "group effects weighted by census nonrecipient_population"
  ),
  diagnostics = list(
    n_obs = as.integer(n_obs),
    n_ineligible = as.integer(sum(g0)),
    n_eligible = as.integer(sum(g1)),
    instrument_rank = as.integer(z_qr$rank),
    fitted_regressor_rank = as.integer(x_qr$rank)
  )
)

write_json(result, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE)
