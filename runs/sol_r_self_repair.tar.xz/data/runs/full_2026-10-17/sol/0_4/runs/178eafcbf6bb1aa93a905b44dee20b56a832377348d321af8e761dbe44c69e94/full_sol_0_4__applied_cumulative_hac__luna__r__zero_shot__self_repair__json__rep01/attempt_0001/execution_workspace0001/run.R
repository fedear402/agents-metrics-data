data <- read.csv("input.csv", stringsAsFactors = FALSE)
data <- data[order(as.Date(data$date)), ]

log_sales <- log(data$sales)
change <- c(NA_real_, diff(log(data$vix)))
n <- nrow(data)

lagged <- sapply(1:15, function(k) {
  c(rep(NA_real_, k), change[seq_len(n - k)])
})
colnames(lagged) <- paste0("lag_", 1:15)

complete <- complete.cases(log_sales, lagged)
y <- log_sales[complete]
X <- cbind("(Intercept)" = 1, lagged[complete, , drop = FALSE])
N <- length(y)

fit <- lm.fit(X, y)
beta <- fit$coefficients
residuals <- fit$residuals
scores <- X * as.numeric(residuals)

meat <- crossprod(scores)
for (j in 1:15) {
  gamma <- crossprod(
    scores[(j + 1):N, , drop = FALSE],
    scores[1:(N - j), , drop = FALSE]
  )
  meat <- meat + (1 - j / 16) * (gamma + t(gamma))
}

bread <- solve(crossprod(X))
vcov_hac <- (N / (N - 16)) * bread %*% meat %*% bread

lag_indices <- match(paste0("lag_", 1:15), colnames(X))
sum_weights <- numeric(ncol(X))
sum_weights[lag_indices] <- 1

estimates <- list(
  list(
    term = "cumulative_response",
    estimate = unname(sum(beta[lag_indices])),
    se = unname(sqrt(drop(t(sum_weights) %*% vcov_hac %*% sum_weights))),
    n_obs = N
  ),
  list(
    term = "lag_1",
    estimate = unname(beta["lag_1"]),
    se = unname(sqrt(vcov_hac["lag_1", "lag_1"])),
    n_obs = N
  ),
  list(
    term = "lag_15",
    estimate = unname(beta["lag_15"]),
    se = unname(sqrt(vcov_hac["lag_15", "lag_15"])),
    n_obs = N
  )
)

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "OLS with intercept and 15 lagged log VIX changes",
    vcov = "Newey-West HAC, Bartlett lag 15, multiplied by N/(N-16)"
  ),
  diagnostics = list()
)

jsonlite::write_json(
  result,
  path = "result.json",
  auto_unbox = TRUE,
  digits = 16,
  pretty = TRUE
)
