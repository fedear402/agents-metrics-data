library(jsonlite)

crosswalk <- read.csv("crosswalk.csv")
trade <- read.csv("trade.csv")
areas <- read.csv("areas.csv")
employment <- read.csv("employment.csv")
outcomes <- read.csv("outcomes.csv")

trade <- merge(trade, crosswalk, by = "code")
trade_industry <- aggregate(
  cbind(us_change, other_change) ~ period + industry + price_index + years,
  data = trade,
  FUN = sum
)

cells <- merge(
  areas,
  trade_industry,
  by = "period",
  all.x = TRUE
)
cells <- merge(
  cells,
  employment,
  by = c("area", "period", "vintage", "industry"),
  all.x = TRUE
)
cells$employment[is.na(cells$employment)] <- 0

national <- aggregate(
  employment ~ period + vintage + industry,
  data = cells,
  FUN = sum
)
names(national)[names(national) == "employment"] <- "national_employment"
cells <- merge(cells, national, by = c("period", "vintage", "industry"))

cells$component <- with(
  cells,
  (employment / total_employment) *
    ifelse(vintage == "base", us_change, other_change) /
    national_employment /
    (price_index / 100) / 1000 *
    (10 / years)
)

exposure <- aggregate(
  component ~ area + period + vintage,
  data = cells,
  FUN = sum
)
wide <- reshape(
  exposure,
  idvar = c("area", "period"),
  timevar = "vintage",
  direction = "wide"
)
names(wide)[names(wide) == "component.base"] <- "x"
names(wide)[names(wide) == "component.early"] <- "z"

base_areas <- areas[areas$vintage == "base",
                    c("area", "period", "population")]
d <- merge(outcomes, wide, by = c("area", "period"))
d <- merge(d, base_areas, by = c("area", "period"))
stopifnot(nrow(d) == 72L, all(complete.cases(d)))

C <- model.matrix(~ period + control, data = d)
X <- cbind(C, x = d$x)
Z <- cbind(C, z = d$z)
sw <- sqrt(d$population)
Xw <- X * sw
Zw <- Z * sw
yw <- d$change_pp * sw

fitted_X <- qr.fitted(qr(Zw), Xw)
iv_slope <- unname(qr.coef(qr(fitted_X), yw)[ncol(Xw)])

get_exposure <- function(area_id, period_id, column) {
  value <- d[d$area == area_id & d$period == period_id, column]
  stopifnot(length(value) == 1L)
  unname(value)
}

values <- c(
  iv_slope = iv_slope,
  exposure_area0_period0 = get_exposure(0, 0, "x"),
  exposure_area0_period1 = get_exposure(0, 1, "x"),
  instrument_area0_period0 = get_exposure(0, 0, "z")
)

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = lapply(names(values), function(term) {
    list(
      term = term,
      estimate = unname(values[[term]]),
      se = NULL,
      n_obs = 72L
    )
  }),
  method_metadata = list(
    estimator = "population-weighted 2SLS",
    endogenous_regressor = "x",
    excluded_instrument = "z",
    exogenous_regressors = c("intercept", "period", "control"),
    exposure_units = "thousands of real dollars per worker per decade"
  ),
  diagnostics = list(
    estimation_rows = nrow(d),
    industries = length(unique(crosswalk$industry)),
    complete_cases = all(complete.cases(d))
  )
)

jsonlite::write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
