library(jsonlite)

crosswalk <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
trade <- read.csv("trade.csv", stringsAsFactors = FALSE)
areas <- read.csv("areas.csv", stringsAsFactors = FALSE)
employment <- read.csv("employment.csv", stringsAsFactors = FALSE)
outcomes <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

trade_industry <- merge(
  trade, crosswalk,
  by = "code",
  all.x = TRUE,
  sort = FALSE
)

national <- aggregate(
  employment ~ period + vintage + industry,
  data = employment,
  FUN = sum
)
names(national)[names(national) == "employment"] <- "national_employment"

area_industry <- merge(
  areas,
  unique(trade_industry[c("period", "industry")]),
  by = "period",
  all.x = TRUE
)
area_industry <- merge(
  area_industry,
  employment,
  by = c("area", "period", "vintage", "industry"),
  all.x = TRUE
)
area_industry$employment[is.na(area_industry$employment)] <- 0

area_industry <- merge(
  area_industry,
  national,
  by = c("period", "vintage", "industry"),
  all.x = TRUE
)
area_industry <- merge(
  area_industry,
  trade_industry,
  by = c("period", "industry"),
  all.x = TRUE
)

area_industry$contribution <- with(
  area_industry,
  (employment / total_employment) *
    (ifelse(vintage == "base", us_change, other_change) /
       national_employment) /
    (price_index / 100) / 1000 * (10 / years)
)

exposures <- aggregate(
  contribution ~ area + period + vintage,
  data = area_industry,
  FUN = sum
)

base <- subset(
  exposures, vintage == "base",
  select = c(area, period, contribution)
)
names(base)[3] <- "x"

early <- subset(
  exposures, vintage == "early",
  select = c(area, period, contribution)
)
names(early)[3] <- "z"

weights <- subset(
  areas, vintage == "base",
  select = c(area, period, population)
)

sample <- merge(outcomes, base, by = c("area", "period"))
sample <- merge(sample, early, by = c("area", "period"))
sample <- merge(sample, weights, by = c("area", "period"))

exogenous <- model.matrix(~ factor(period) + control, data = sample)
regressors <- cbind(exogenous, x = sample$x)
instruments <- cbind(exogenous, z = sample$z)

w <- sample$population
weighted_crossprod <- function(a, b) crossprod(a, b * w)

xz <- weighted_crossprod(regressors, instruments)
zz <- weighted_crossprod(instruments, instruments)
zy <- weighted_crossprod(instruments, matrix(sample$change_pp, ncol = 1))

iv_coefficients <- solve(
  xz %*% solve(zz, t(xz)),
  xz %*% solve(zz, zy)
)

lookup <- function(column, period_value) {
  value <- sample[sample$area == 0 & sample$period == period_value, column]
  stopifnot(length(value) == 1L)
  as.numeric(value)
}

n_obs <- nrow(sample)

estimate <- function(term, value) {
  list(term = term, estimate = as.numeric(value), se = NULL, n_obs = n_obs)
}

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = list(
    estimate("iv_slope", iv_coefficients[nrow(iv_coefficients), 1]),
    estimate("exposure_area0_period0", lookup("x", 0)),
    estimate("exposure_area0_period1", lookup("x", 1)),
    estimate("instrument_area0_period0", lookup("z", 0))
  ),
  method_metadata = list(
    estimator = "population-weighted 2SLS",
    regressors = c("intercept", "period", "control", "x"),
    instruments = c("intercept", "period", "control", "z"),
    employment_convention = "omitted area-industry cells equal zero",
    exposure_units = "thousands of real dollars per worker per decade"
  ),
  diagnostics = list(n_obs = n_obs)
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  digits = 15,
  pretty = TRUE,
  null = "null"
)
