library(jsonlite)

d <- read.csv("input.csv", stringsAsFactors = FALSE)

regions <- unique(d$region_id)
industries <- unique(d$industry_id)
R <- length(regions)
N <- length(industries)

region_index <- match(d$region_id, regions)
industry_index <- match(d$industry_id, industries)

shares <- matrix(0, R, N)
shares[cbind(region_index, industry_index)] <- d$share

region_rows <- match(regions, d$region_id)
industry_rows <- match(industries, d$industry_id)

e <- d$region_weight[region_rows]
e <- e / sum(e)

x <- d$x[region_rows]
y <- d$y[region_rows]
shock <- d$shock[industry_rows]
z <- drop(shares %*% shock)

regional <- cbind(y = y, x = x, z = z)
centered <- sweep(regional, 2, drop(crossprod(e, regional)))
s <- drop(crossprod(e, shares))
aggregated <- crossprod(shares, centered * e) / s

shock_iv <- function(dependent, endogenous) {
  X <- cbind(1, endogenous)
  Z <- cbind(1, shock)
  cross <- crossprod(Z, s * X)
  beta <- solve(cross, crossprod(Z, s * dependent))
  residual <- drop(dependent - X %*% beta)
  scores <- Z * (s * residual)
  inverse <- solve(cross)
  covariance <- (N / (N - 2)) *
    inverse %*% crossprod(scores) %*% t(inverse)
  c(estimate = unname(beta[2]), se = sqrt(covariance[2, 2]))
}

effect <- shock_iv(aggregated[, "y"], aggregated[, "x"])
first_stage <- shock_iv(aggregated[, "x"], aggregated[, "z"])

regional_effect <- sum(e * centered[, "z"] * centered[, "y"]) /
  sum(e * centered[, "z"] * centered[, "x"])
regional_first_stage <- sum(e * centered[, "z"] * centered[, "x"]) /
  sum(e * centered[, "z"]^2)

stopifnot(
  isTRUE(all.equal(unname(effect["estimate"]), regional_effect, tolerance = 1e-9)),
  isTRUE(all.equal(unname(first_stage["estimate"]), regional_first_stage, tolerance = 1e-9))
)

row <- function(term, estimate, se) {
  list(
    term = term,
    estimate = unname(as.numeric(estimate)),
    se = if (is.null(se)) NULL else unname(as.numeric(se)),
    n_obs = as.integer(N)
  )
}

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    row("effect", effect["estimate"], effect["se"]),
    row("first_stage", first_stage["estimate"], first_stage["se"]),
    row("effective_shocks", 1 / sum(s^2), NULL)
  ),
  method_metadata = list(
    estimator = "Weighted regional 2SLS via equivalent shock-level IV",
    vcov = "Shock-level heteroskedasticity-robust HC1 with N/(N-2) multiplier"
  ),
  diagnostics = list()
)

write_json(
  result, "result.json",
  auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE
)
