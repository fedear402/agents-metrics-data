library(jsonlite)

d <- read.csv("input.csv")
region <- unique(d$region_id)
industry <- unique(d$industry_id)
r <- match(d$region_id, region)
n <- match(d$industry_id, industry)
R <- length(region)
N <- length(industry)

first <- match(region, d$region_id)
e <- d$region_weight[first]
e <- e / sum(e)
x <- d$x[first]
y <- d$y[first]

shock <- d$shock[match(industry, d$industry_id)]
z <- as.numeric(rowsum(d$share * shock[n], r, reorder = TRUE)[, 1])

center <- function(v) v - sum(e * v)
x0 <- center(x)
y0 <- center(y)
z0 <- center(z)

exposure <- e[r] * d$share
s <- as.numeric(rowsum(exposure, n, reorder = TRUE)[, 1])
aggregate_residual <- function(v0) {
  as.numeric(rowsum(exposure * v0[r], n, reorder = TRUE)[, 1]) / s
}
xbar <- aggregate_residual(x0)
ybar <- aggregate_residual(y0)
zbar <- aggregate_residual(z0)

shock_iv <- function(dependent, endogenous) {
  X <- cbind(1, endogenous)
  Z <- cbind(1, shock)
  cross <- crossprod(Z, s * X)
  beta <- solve(cross, crossprod(Z, s * dependent))
  residual <- as.numeric(dependent - X %*% beta)
  scores <- Z * as.numeric(s * residual)
  inverse <- solve(cross)
  vcov <- (N / (N - 2)) * inverse %*%
    crossprod(scores) %*% t(inverse)
  c(estimate = unname(beta[2]), se = sqrt(vcov[2, 2]))
}

effect <- shock_iv(ybar, xbar)
first_stage <- shock_iv(xbar, zbar)

row <- function(term, estimate, se = NULL) {
  list(
    term = term,
    estimate = unname(as.numeric(estimate)),
    se = if (is.null(se)) NULL else unname(as.numeric(se)),
    n_obs = N
  )
}

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    row("effect", effect["estimate"], effect["se"]),
    row("first_stage", first_stage["estimate"], first_stage["se"]),
    row("effective_shocks", 1 / sum(s^2))
  ),
  method_metadata = list(
    estimator = "Weighted regional 2SLS via shock-level IV aggregation",
    vcov = "Shock-level heteroskedasticity-robust HC1, N/(N-2)"
  ),
  diagnostics = list()
)

write_json(
  result, "result.json",
  auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE
)
