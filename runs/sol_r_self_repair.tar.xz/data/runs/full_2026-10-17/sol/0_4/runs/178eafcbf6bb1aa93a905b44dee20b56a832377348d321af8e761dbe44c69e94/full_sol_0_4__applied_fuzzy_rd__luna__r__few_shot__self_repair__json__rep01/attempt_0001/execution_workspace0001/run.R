library(jsonlite)

d <- read.csv("input.csv")
d <- d[is.finite(d$score) & abs(d$score) < 1 &
         is.finite(d$earnings) & is.finite(d$participated), ]

x <- d$score
right <- as.numeric(x >= 0)
w <- 1 - abs(x)
X <- cbind(1, right, x, right * x)
Y <- cbind(d$earnings, d$participated)

bread <- solve(crossprod(X, w * X))
beta <- bread %*% crossprod(X, w * Y)
residuals <- Y - X %*% beta

contrast <- c(0, 1, 0, 0)
jumps <- drop(contrast %*% beta)
loading <- w * drop(X %*% bread %*% contrast)
influence <- residuals * loading
joint <- crossprod(influence)

reduced_form <- jumps[1]
first_stage <- jumps[2]
treatment_effect <- reduced_form / first_stage
gradient <- c(1 / first_stage, -reduced_form / first_stage^2)
treatment_var <- drop(t(gradient) %*% joint %*% gradient)
n_obs <- nrow(d)

row <- function(term, estimate, se) {
  list(term = term, estimate = unname(as.numeric(estimate)),
       se = unname(as.numeric(se)), n_obs = as.integer(n_obs))
}

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    row("treatment_effect", treatment_effect, sqrt(treatment_var)),
    row("reduced_form", reduced_form, sqrt(joint[1, 1])),
    row("first_stage", first_stage, sqrt(joint[2, 2]))
  ),
  method_metadata = list(
    estimator = "Triangular-weighted local linear fuzzy regression discontinuity",
    vcov = "Joint heteroskedasticity-robust HC0; delta method for ratio"
  ),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null",
           digits = 16, pretty = TRUE)
