d <- read.csv("input.csv")

regions <- unique(d$region_id)
industries <- unique(d$industry_id)
r <- match(d$region_id, regions)
n <- match(d$industry_id, industries)
R <- length(regions)
N <- length(industries)

regional <- d[match(regions, d$region_id), ]
shocks <- d$shock[match(industries, d$industry_id)]
e <- regional$region_weight / sum(regional$region_weight)

weighted_mean <- function(v) sum(e * v)

z <- rowsum(d$share * d$shock, r, reorder = TRUE)[, 1]
y0 <- regional$y - weighted_mean(regional$y)
x0 <- regional$x - weighted_mean(regional$x)
z0 <- z - weighted_mean(z)

exposure <- e[r] * d$share
s <- as.numeric(rowsum(exposure, n, reorder = TRUE))
aggregate_residual <- function(v) {
  as.numeric(rowsum(exposure * v[r], n, reorder = TRUE)) / s
}

ybar <- aggregate_residual(y0)
xbar <- aggregate_residual(x0)
zbar <- aggregate_residual(z0)

shock_iv <- function(outcome, endogenous) {
  X <- cbind(1, endogenous)
  Z <- cbind(1, shocks)
  cross <- crossprod(Z, s * X)
  beta <- solve(cross, crossprod(Z, s * outcome))
  u <- as.numeric(outcome - X %*% beta)
  meat <- crossprod(Z, (s^2 * u^2) * Z)
  bread <- solve(cross)
  vcov <- (N / (N - 2)) * bread %*% meat %*% t(bread)
  list(estimate = as.numeric(beta[2]), se = sqrt(vcov[2, 2]))
}

effect <- shock_iv(ybar, xbar)
first_stage <- shock_iv(xbar, zbar)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = effect$estimate,
         se = effect$se, n_obs = N),
    list(term = "first_stage", estimate = first_stage$estimate,
         se = first_stage$se, n_obs = N),
    list(term = "effective_shocks", estimate = 1 / sum(s^2),
         se = NULL, n_obs = N)
  ),
  method_metadata = list(
    estimator = "Weighted regional 2SLS via BHJ shock-level aggregation",
    vcov = "Shock-level heteroskedasticity-robust HC1; multiplier N/(N-2)"
  ),
  diagnostics = list()
)

jsonlite::write_json(
  result, "result.json", auto_unbox = TRUE, digits = NA, null = "null"
)
