library(jsonlite)

households <- read.csv("households.csv")
census <- read.csv("census.csv")

sample <- households[!is.na(households$recipient) & households$recipient == 0, ]
n_obs <- nrow(sample)

if (n_obs == 0L) stop("No nonrecipient household rows.")
if (anyNA(sample[, c("eligible", "instrument", "dose", "baseline", "weight", "outcome")])) {
  stop("Estimation variables contain missing values.")
}
if (any(!sample$eligible %in% c(0, 1))) stop("eligible must be zero or one.")
if (any(sample$weight <= 0)) stop("Weights must be positive.")

g0 <- 1 - sample$eligible
g1 <- sample$eligible

X <- cbind(
  g0,
  g1,
  sample$baseline * g0,
  sample$baseline * g1,
  sample$dose * g0,
  sample$dose * g1
)
Z <- cbind(
  g0,
  g1,
  sample$baseline * g0,
  sample$baseline * g1,
  sample$instrument * g0,
  sample$instrument * g1
)

w <- sample$weight
y <- sample$outcome
ZWZ <- crossprod(Z, w * Z)
ZWX <- crossprod(Z, w * X)
ZWy <- crossprod(Z, w * y)

beta <- solve(
  crossprod(ZWX, solve(ZWZ, ZWX)),
  crossprod(ZWX, solve(ZWZ, ZWy))
)

mean_dose_0 <- weighted.mean(sample$dose[g0 == 1], w[g0 == 1])
mean_dose_1 <- weighted.mean(sample$dose[g1 == 1], w[g1 == 1])

ineligible_effect <- as.numeric(beta[5] * mean_dose_0)
eligible_nonrecipient_effect <- as.numeric(beta[6] * mean_dose_1)

if (anyNA(census[, c("eligible", "nonrecipient_population")])) {
  stop("Census aggregation variables contain missing values.")
}
if (any(!census$eligible %in% c(0, 1))) {
  stop("Census eligible values must be zero or one.")
}
if (any(census$nonrecipient_population < 0)) {
  stop("Census population counts must be nonnegative.")
}

population <- c(
  sum(census$nonrecipient_population[census$eligible == 0]),
  sum(census$nonrecipient_population[census$eligible == 1])
)
if (any(population <= 0)) stop("Both eligibility groups need positive census counts.")

population_effect <- sum(
  c(ineligible_effect, eligible_nonrecipient_effect) *
    population / sum(population)
)

result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = list(
    list(term = "ineligible_effect", estimate = ineligible_effect,
         se = NA_real_, n_obs = n_obs),
    list(term = "eligible_nonrecipient_effect",
         estimate = eligible_nonrecipient_effect,
         se = NA_real_, n_obs = n_obs),
    list(term = "population_effect", estimate = population_effect,
         se = NA_real_, n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "weighted 2SLS",
    sample = "All household rows with recipient equal to zero",
    counterfactual = "Dose set to zero for every retained household; attribution is a synthetic convention",
    group_effect = "Fitted group dose slope times the household-weighted group mean dose",
    aggregation = "Group effects weighted by census nonrecipient_population",
    intercept = "No additional intercept",
    standard_errors = "Not requested; reported as null"
  ),
  diagnostics = list(
    estimation_rows = n_obs,
    ineligible_rows = sum(g0),
    eligible_nonrecipient_rows = sum(g1),
    ineligible_weighted_mean_dose = mean_dose_0,
    eligible_nonrecipient_weighted_mean_dose = mean_dose_1,
    ineligible_population = population[1],
    eligible_nonrecipient_population = population[2]
  )
)

write_json(
  result, "result.json",
  auto_unbox = TRUE,
  na = "null",
  digits = 16,
  pretty = TRUE
)
