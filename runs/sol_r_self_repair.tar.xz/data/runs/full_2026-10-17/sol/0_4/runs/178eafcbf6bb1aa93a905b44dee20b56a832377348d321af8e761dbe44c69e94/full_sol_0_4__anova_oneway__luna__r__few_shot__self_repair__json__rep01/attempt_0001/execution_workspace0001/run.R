library(jsonlite)

dat <- read.csv("./input.csv")
fit <- aov(y ~ factor(group), data = dat)
anova_table <- summary(fit)[[1]]
n <- nobs(fit)

values <- c(
  F = anova_table[1, "F value"],
  df_num = anova_table[1, "Df"],
  df_den = anova_table[2, "Df"],
  p_value = anova_table[1, "Pr(>F)"]
)

out <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = lapply(names(values), function(term) {
    list(term = term, estimate = unname(as.numeric(values[term])),
         se = NA_real_, n_obs = as.integer(n))
  }),
  method_metadata = list(
    estimator = "One-way analysis of variance",
    vcov = "Classical homoskedastic ANOVA"
  ),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "result.json", auto_unbox = TRUE, digits = NA, na = "null")
