library(jsonlite)

dat <- read.csv("input.csv")
dat <- dat[is.finite(dat$score) & abs(dat$score) < 1 &
             is.finite(dat$earnings) & is.finite(dat$participated), ]

n <- nrow(dat)
x <- dat$score
right <- as.numeric(x >= 0)
w <- 1 - abs(x)

X <- cbind(left_intercept = 1 - right,
           left_slope = x * (1 - right),
           right_intercept = right,
           right_slope = x * right)
Y <- cbind(earnings = dat$earnings,
           participated = dat$participated)

bread <- solve(crossprod(X, w * X))
coef <- bread %*% crossprod(X, w * Y)
resid <- Y - X %*% coef

contrast <- c(-1, 0, 1, 0)
jumps <- drop(contrast %*% coef)
loading <- w * drop(X %*% bread %*% contrast)
influence <- loading * resid
joint <- crossprod(influence)

gradient <- c(1 / jumps[2], -jumps[1] / jumps[2]^2)
effect <- jumps[1] / jumps[2]
effect_se <- sqrt(drop(t(gradient) %*% joint %*% gradient))

row <- function(term, estimate, se) {
  list(term = term, estimate = unname(as.numeric(estimate)),
       se = unname(as.numeric(se)), n_obs = as.integer(n))
}

output <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    row("treatment_effect", effect, effect_se),
    row("reduced_form", jumps[1], sqrt(joint[1, 1])),
    row("first_stage", jumps[2], sqrt(joint[2, 2]))
  ),
  method_metadata = list(
    estimator = "Triangular-weighted local-linear fuzzy regression discontinuity; bandwidth 1",
    vcov = "Joint heteroskedasticity-robust HC0; delta method for ratio"
  ),
  diagnostics = list()
)

write_json(output, "result.json", auto_unbox = TRUE, null = "null",
           digits = 16, pretty = TRUE)
