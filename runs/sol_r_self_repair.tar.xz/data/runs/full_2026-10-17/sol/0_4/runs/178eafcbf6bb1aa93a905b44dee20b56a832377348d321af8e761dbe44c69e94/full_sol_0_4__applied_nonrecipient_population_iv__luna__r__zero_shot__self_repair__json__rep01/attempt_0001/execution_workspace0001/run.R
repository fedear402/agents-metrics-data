library(jsonlite)

households <- read.csv("households.csv")
census <- read.csv("census.csv")

sample <- households[!is.na(households$recipient) & households$recipient == 0, ]
needed <- c("eligible", "instrument", "dose", "baseline", "weight", "outcome")
sample <- sample[complete.cases(sample[, needed]), ]

stopifnot(
  nrow(sample) > 0,
  all(sample$eligible %in% c(0, 1)),
  all(sample$weight > 0),
  all(c(0, 1) %in% sample$eligible),
  all(c(0, 1) %in% census$eligible),
  !anyDuplicated(census$eligible)
)

ineligible <- as.numeric(sample$eligible == 0)
eligible <- as.numeric(sample$eligible == 1)

X <- cbind(
  ineligible,
  eligible,
  sample$baseline * ineligible,
  sample$baseline * eligible,
  sample$dose * ineligible,
  sample$dose * eligible
)

Z <- cbind(
  ineligible,
  eligible,
  sample$baseline * ineligible,
  sample$baseline * eligible,
  sample$instrument * ineligible,
  sample$instrument * eligible
)

sqrt_weight <- sqrt(sample$weight)
Xw <- X * sqrt_weight
Zw <- Z * sqrt_weight
yw <- sample$outcome * sqrt_weight

stopifnot(qr(Zw)$rank == ncol(Z), qr(crossprod(Zw, Xw))$rank == ncol(X))

# Weighted 2SLS: project weighted regressors and outcome onto weighted instruments.
projected_X <- Zw %*% qr.coef(qr(Zw), Xw)
projected_y <- Zw %*% qr.coef(qr(Zw), yw)
coefficients <- as.vector(qr.coef(qr(projected_X), projected_y))

group_mean_dose <- function(group) {
  rows <- sample$eligible == group
  weighted.mean(sample$dose[rows], sample$weight[rows])
}

ineligible_effect <- coefficients[5] * group_mean_dose(0)
eligible_nonrecipient_effect <- coefficients[6] * group_mean_dose(1)

population <- census$nonrecipient_population[
  match(c(0, 1), census$eligible)
]
stopifnot(all(is.finite(population)), all(population >= 0), sum(population) > 0)

population_effect <- sum(
  c(ineligible_effect, eligible_nonrecipient_effect) * population
) / sum(population)

n_obs <- as.integer(nrow(sample))
make_estimate <- function(term, value) {
  list(term = term, estimate = unname(value), se = NULL, n_obs = n_obs)
}

result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = list(
    make_estimate("ineligible_effect", ineligible_effect),
    make_estimate("eligible_nonrecipient_effect", eligible_nonrecipient_effect),
    make_estimate("population_effect", population_effect)
  ),
  method_metadata = list(
    estimator = "weighted 2SLS",
    sample = "households with recipient equal to zero and complete regression data",
    intercept = "group indicators only; no additional intercept",
    counterfactual = "dose set to zero for every retained household, as a synthetic attribution convention",
    group_effect = "fitted group dose slope times household-weighted mean dose",
    population_aggregation = "nonrecipient_population used only for final between-group weights",
    uncertainty = "not requested; standard errors set to null"
  ),
  diagnostics = list(
    n_obs = n_obs,
    n_ineligible = as.integer(sum(sample$eligible == 0)),
    n_eligible_nonrecipient = as.integer(sum(sample$eligible == 1)),
    weighted_mean_dose_ineligible = group_mean_dose(0),
    weighted_mean_dose_eligible_nonrecipient = group_mean_dose(1),
    dose_slope_ineligible = coefficients[5],
    dose_slope_eligible_nonrecipient = coefficients[6]
  )
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = NA,
  pretty = TRUE
)
