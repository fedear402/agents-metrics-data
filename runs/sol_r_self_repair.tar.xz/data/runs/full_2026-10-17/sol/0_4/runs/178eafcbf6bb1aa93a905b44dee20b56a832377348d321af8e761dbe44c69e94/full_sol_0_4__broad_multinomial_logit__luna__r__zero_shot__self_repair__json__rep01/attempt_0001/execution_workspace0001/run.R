d <- read.csv("input.csv")
X <- model.matrix(~ x + z, data = d)
y <- as.integer(d$y)
n <- nrow(d)
p <- ncol(X)

stopifnot(n == 480L, all(y %in% 0:2), !anyNA(X), !anyNA(y))

neg_loglik <- function(theta) {
  eta1 <- drop(X %*% theta[seq_len(p)])
  eta2 <- drop(X %*% theta[p + seq_len(p)])
  m <- pmax(0, eta1, eta2)
  log_denom <- m + log(exp(-m) + exp(eta1 - m) + exp(eta2 - m))
  -sum((y == 1L) * eta1 + (y == 2L) * eta2 - log_denom)
}

fit <- optim(rep(0, 2L * p), neg_loglik, method = "BFGS",
             control = list(reltol = 1e-12, maxit = 10000))
if (fit$convergence != 0L) stop("Optimization did not converge")

info <- optimHess(fit$par, neg_loglik)
se <- sqrt(diag(solve(info)))

eta2_zero <- fit$par[p + 1L]
m_zero <- max(0, fit$par[1L], eta2_zero)
prob2_zero <- exp(eta2_zero - m_zero) /
  (exp(-m_zero) + exp(fit$par[1L] - m_zero) + exp(eta2_zero - m_zero))

num <- function(v) sprintf("%.15g", v)
row <- function(term, estimate, standard_error = NULL) {
  se_json <- if (is.null(standard_error)) "null" else num(standard_error)
  sprintf(
    '{"term":"%s","estimate":%s,"se":%s,"n_obs":%d}',
    term, num(estimate), se_json, n
  )
}

rows <- c(
  row("x_cat1", fit$par[2L], se[2L]),
  row("z_cat1", fit$par[3L], se[3L]),
  row("x_cat2", fit$par[p + 2L], se[p + 2L]),
  row("z_cat2", fit$par[p + 3L], se[p + 3L]),
  row("prob_cat2_zero", prob2_zero)
)

json <- paste0(
  '{"task_id":"broad_multinomial_logit","platform":"r",',
  '"estimates":[', paste(rows, collapse = ","), '],',
  '"method_metadata":{"estimator":"multinomial logit maximum likelihood",',
  '"vcov":"inverse observed information"},"diagnostics":{}}'
)
writeLines(json, "result.json")
