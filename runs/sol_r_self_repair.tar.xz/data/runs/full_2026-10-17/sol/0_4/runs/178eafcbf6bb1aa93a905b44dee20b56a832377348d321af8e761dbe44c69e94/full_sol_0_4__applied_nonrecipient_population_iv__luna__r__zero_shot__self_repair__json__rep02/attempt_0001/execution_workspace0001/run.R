library(jsonlite)

households <- read.csv("households.csv")
census <- read.csv("census.csv")

sample <- households[households$recipient == 0, , drop = FALSE]
required <- c("eligible", "instrument", "dose", "baseline", "weight", "outcome")
stopifnot(nrow(sample) > 0L, all(complete.cases(sample[required])))
stopifnot(all(sample$eligible %in% c(0, 1)), all(sample$weight > 0))
stopifnot(all(census$eligible %in% c(0, 1)))
stopifnot(all(census$nonrecipient_population >= 0))
stopifnot(all(c(0, 1) %in% sample$eligible))
stopifnot(all(c(0, 1) %in% census$eligible))

ineligible <- 1 - sample$eligible
eligible <- sample$eligible

exogenous <- cbind(
  ineligible,
  eligible,
  sample$baseline * ineligible,
  sample$baseline * eligible
)
endogenous <- cbind(
  sample$dose * ineligible,
  sample$dose * eligible
)
excluded <- cbind(
  sample$instrument * ineligible,
  sample$instrument * eligible
)

X <- cbind(exogenous, endogenous)
Z <- cbind(exogenous, excluded)
w <- sample$weight

# Weighted 2SLS with no additional intercept.
ZtWZ <- crossprod(Z, Z * w)
ZtWX <- crossprod(Z, X * w)
ZtWy <- crossprod(Z, sample$outcome * w)
coefficients <- solve(
  crossprod(ZtWX, solve(ZtWZ, ZtWX)),
  crossprod(ZtWX, solve(ZtWZ, ZtWy))
)

mean_dose <- function(group) {
  rows <- sample$eligible == group
  weighted.mean(sample$dose[rows], w[rows])
}

effects <- c(
  ineligible_effect = coefficients[5] * mean_dose(0),
  eligible_nonrecipient_effect = coefficients[6] * mean_dose(1)
)

population <- vapply(
  0:1,
  function(group) sum(census$nonrecipient_population[census$eligible == group]),
  numeric(1)
)
stopifnot(sum(population) > 0)
population_effect <- sum(effects * population / sum(population))

n_obs <- as.integer(nrow(sample))
make_estimate <- function(term, value) {
  list(term = term, estimate = as.numeric(value), se = NULL, n_obs = n_obs)
}

result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = list(
    make_estimate("ineligible_effect", effects[1]),
    make_estimate("eligible_nonrecipient_effect", effects[2]),
    make_estimate("population_effect", population_effect)
  ),
  method_metadata = list(
    estimator = "weighted 2SLS",
    sample = "all households with recipient = 0",
    counterfactual = "dose set to zero for every retained household; attribution is a synthetic convention",
    group_effect = "fitted group dose slope times the household-weighted mean dose",
    population_aggregation = "group effects weighted by census nonrecipient_population"
  ),
  diagnostics = list(
    n_obs = n_obs,
    group_n_obs = list(
      ineligible = as.integer(sum(sample$eligible == 0)),
      eligible = as.integer(sum(sample$eligible == 1))
    )
  )
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = NA,
  pretty = TRUE
)
