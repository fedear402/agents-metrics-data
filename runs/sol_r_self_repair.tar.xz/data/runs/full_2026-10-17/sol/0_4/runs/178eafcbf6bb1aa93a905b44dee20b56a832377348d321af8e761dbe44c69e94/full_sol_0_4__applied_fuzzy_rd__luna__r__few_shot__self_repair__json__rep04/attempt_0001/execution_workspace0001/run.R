library(jsonlite)

data <- read.csv("input.csv")
data <- data[!is.na(data$score) & abs(data$score) < 1, ]

score <- data$score
right <- as.numeric(score >= 0)
weights <- 1 - abs(score)
X <- cbind(1, score, right, score * right)
Y <- cbind(data$earnings, data$participated)

bread <- solve(crossprod(X, weights * X))
coefficients <- bread %*% crossprod(X, weights * Y)
residuals <- Y - X %*% coefficients

contrast <- c(0, 0, 1, 0)
jumps <- drop(contrast %*% coefficients)
loading <- weights * drop(X %*% bread %*% contrast)
influence <- residuals * loading
joint_covariance <- crossprod(influence)

reduced_form <- jumps[1]
first_stage <- jumps[2]
treatment_effect <- reduced_form / first_stage
gradient <- c(1 / first_stage, -reduced_form / first_stage^2)
treatment_variance <- drop(t(gradient) %*% joint_covariance %*% gradient)

row <- function(term, estimate, se, n_obs) {
  list(term = term, estimate = unname(as.numeric(estimate)),
       se = unname(as.numeric(se)), n_obs = as.integer(n_obs))
}

n_obs <- nrow(data)
result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    row("treatment_effect", treatment_effect, sqrt(treatment_variance), n_obs),
    row("reduced_form", reduced_form, sqrt(joint_covariance[1, 1]), n_obs),
    row("first_stage", first_stage, sqrt(joint_covariance[2, 2]), n_obs)
  ),
  method_metadata = list(
    estimator = "Triangular-weighted local-linear fuzzy RD, bandwidth 1",
    vcov = "Joint heteroskedasticity-robust HC0; delta method for ratio"
  ),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null",
           digits = 16, pretty = TRUE)
