library(jsonlite)

data <- read.csv("./input.csv")
data <- data[complete.cases(data[, c("group", "y")]), ]
data$group <- factor(data$group)

fit <- aov(y ~ group, data = data)
anova_table <- summary(fit)[[1]]
n_obs <- nrow(data)

row <- function(term, estimate) {
  list(term = term, estimate = unname(as.numeric(estimate)),
       se = NA_real_, n_obs = n_obs)
}

out <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = list(
    row("F", anova_table[1, "F value"]),
    row("df_num", anova_table[1, "Df"]),
    row("df_den", anova_table[2, "Df"]),
    row("p_value", anova_table[1, "Pr(>F)"])
  ),
  method_metadata = list(
    estimator = "One-way ANOVA",
    vcov = "classical"
  ),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "result.json", auto_unbox = TRUE, digits = NA)
