d <- read.csv("input.csv")
region <- match(d$region_id, unique(d$region_id))
industry <- match(d$industry_id, unique(d$industry_id))
R <- max(region)
N <- max(industry)

first <- !duplicated(region)
w <- d$region_weight[first]
e <- w / sum(w)
x <- d$x[first]
y <- d$y[first]
shock <- d$shock[!duplicated(industry)]

group_sum <- function(value, group) {
  as.numeric(rowsum(value, group, reorder = TRUE)[, 1])
}

z <- group_sum(d$share * d$shock, region)
center <- function(v) v - sum(e * v)

x0 <- center(x)
y0 <- center(y)
z0 <- center(z)

exposure <- e[region] * d$share
s <- group_sum(exposure, industry)
aggregate_residual <- function(v0) {
  group_sum(exposure * v0[region], industry) / s
}

xbar <- aggregate_residual(x0)
ybar <- aggregate_residual(y0)
zbar <- aggregate_residual(z0)

shock_iv <- function(outcome, regressor) {
  X <- cbind(1, regressor)
  Z <- cbind(1, shock)
  WZ <- Z * s
  beta <- solve(crossprod(WZ, X), crossprod(WZ, outcome))
  residual <- as.numeric(outcome - X %*% beta)
  bread <- solve(crossprod(WZ, X))
  score <- Z * (s * residual)
  vcov <- (N / (N - 2)) * bread %*%
    crossprod(score) %*% t(bread)
  c(estimate = unname(beta[2]), se = sqrt(vcov[2, 2]))
}

effect <- shock_iv(ybar, xbar)
first_stage <- shock_iv(xbar, zbar)
effective_shocks <- 1 / sum(s^2)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = effect["estimate"],
         se = effect["se"], n_obs = N),
    list(term = "first_stage", estimate = first_stage["estimate"],
         se = first_stage["se"], n_obs = N),
    list(term = "effective_shocks", estimate = effective_shocks,
         se = NULL, n_obs = N)
  ),
  method_metadata = list(
    estimator = "Weighted regional 2SLS via BHJ shock-level IV aggregation",
    vcov = "Shock-level heteroskedasticity-robust HC1, N/(N-2)"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = 16)
