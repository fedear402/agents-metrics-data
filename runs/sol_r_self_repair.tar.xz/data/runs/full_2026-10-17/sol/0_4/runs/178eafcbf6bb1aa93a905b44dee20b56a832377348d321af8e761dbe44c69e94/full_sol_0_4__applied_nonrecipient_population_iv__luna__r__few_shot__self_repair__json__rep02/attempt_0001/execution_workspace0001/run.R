library(jsonlite)

households <- read.csv("households.csv")
census <- read.csv("census.csv")

d <- households[households$recipient == 0, ]
n_obs <- nrow(d)

g0 <- as.numeric(d$eligible == 0)
g1 <- as.numeric(d$eligible == 1)

C <- cbind(
  ineligible = g0,
  eligible = g1,
  baseline_ineligible = d$baseline * g0,
  baseline_eligible = d$baseline * g1
)
X <- cbind(
  C,
  dose_ineligible = d$dose * g0,
  dose_eligible = d$dose * g1
)
Z <- cbind(
  C,
  instrument_ineligible = d$instrument * g0,
  instrument_eligible = d$instrument * g1
)

sqrt_w <- sqrt(d$weight)
Xw <- X * sqrt_w
Zw <- Z * sqrt_w
yw <- d$outcome * sqrt_w

z_qr <- qr(Zw)
if (z_qr$rank != ncol(Zw)) stop("Instrument matrix is rank deficient.")

fitted_Xw <- qr.fitted(z_qr, Xw)
x_qr <- qr(fitted_Xw)
if (x_qr$rank != ncol(Xw)) stop("Weighted 2SLS is not identified.")

slope <- qr.coef(x_qr, qr.fitted(z_qr, yw))
mean_dose <- vapply(0:1, function(group) {
  rows <- d$eligible == group
  weighted.mean(d$dose[rows], d$weight[rows])
}, numeric(1))

effects <- c(
  ineligible_effect = unname(slope["dose_ineligible"] * mean_dose[1]),
  eligible_nonrecipient_effect = unname(slope["dose_eligible"] * mean_dose[2])
)

population <- census$nonrecipient_population[match(0:1, census$eligible)]
if (anyNA(population)) stop("Census must contain both eligibility groups.")

population_effect <- weighted.mean(effects, population)

make_estimate <- function(term, value) {
  list(term = term, estimate = unname(value), se = NULL, n_obs = as.integer(n_obs))
}

result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = list(
    make_estimate("ineligible_effect", effects["ineligible_effect"]),
    make_estimate("eligible_nonrecipient_effect", effects["eligible_nonrecipient_effect"]),
    make_estimate("population_effect", population_effect)
  ),
  method_metadata = list(
    estimator = "weighted 2SLS",
    sample = "households with recipient == 0",
    counterfactual = "dose set to zero for every retained household",
    group_effect = "group dose slope times household-weighted group mean dose",
    population_aggregation = "group effects weighted by census nonrecipient_population"
  ),
  diagnostics = list(
    n_obs = as.integer(n_obs),
    group_n_obs = as.integer(c(
      ineligible = sum(g0),
      eligible = sum(g1)
    )),
    weighted_mean_dose = unname(mean_dose),
    census_nonrecipient_population = as.integer(population)
  )
)

write_json(result, "result.json", auto_unbox = TRUE, digits = NA, null = "null")
