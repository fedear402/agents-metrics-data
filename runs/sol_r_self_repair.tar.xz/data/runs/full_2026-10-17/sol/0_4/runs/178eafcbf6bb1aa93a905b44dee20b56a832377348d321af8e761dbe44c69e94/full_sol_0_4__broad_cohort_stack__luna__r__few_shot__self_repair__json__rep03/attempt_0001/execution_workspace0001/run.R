d <- read.csv("input.csv")

cohorts <- c(3, 5, 7)
results <- lapply(cohorts, function(cohort) {
  window <- (cohort - 2):(cohort + 2)
  eligible <- subset(
    d,
    time %in% window & (g == cohort | g == 0 | g > cohort + 2)
  )

  counts <- table(eligible$id)
  balanced_ids <- names(counts[counts == length(window)])
  comparison <- eligible[as.character(eligible$id) %in% balanced_ids, ]
  comparison$did <- as.integer(
    comparison$g == cohort & comparison$time >= cohort
  )

  fit <- lm(y ~ did + factor(id) + factor(time), data = comparison)

  list(
    estimate = unname(coef(fit)[["did"]]),
    n_obs = nrow(comparison),
    treated_units = length(unique(comparison$id[comparison$g == cohort]))
  )
})

weights <- vapply(results, function(x) x$treated_units, numeric(1))
effects <- vapply(results, function(x) x$estimate, numeric(1))
row_counts <- vapply(results, function(x) x$n_obs, numeric(1))

estimates <- lapply(seq_along(cohorts), function(i) {
  list(
    term = paste0("att_g", cohorts[i]),
    estimate = results[[i]]$estimate,
    se = NULL,
    n_obs = results[[i]]$n_obs
  )
})

estimates[[length(estimates) + 1]] <- list(
  term = "att_weighted",
  estimate = weighted.mean(effects, weights),
  se = NULL,
  n_obs = sum(row_counts)
)

out <- list(
  task_id = "broad_cohort_stack",
  platform = "r",
  estimates = estimates,
  method_metadata = list(),
  diagnostics = list()
)

jsonlite::write_json(
  out,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16
)
