data <- read.csv("./input.csv", stringsAsFactors = FALSE)
required <- c("group", "y")
if (!all(required %in% names(data))) {
  stop("input.csv must contain group and y columns")
}

data$y <- as.numeric(data$y)
data <- data[!is.na(data$group) & !is.na(data$y), required, drop = FALSE]
data$group <- factor(data$group)

if (nlevels(data$group) < 2L) {
  stop("At least two groups are required")
}
if (nrow(data) <= nlevels(data$group)) {
  stop("Positive residual degrees of freedom are required")
}

fit <- aov(y ~ group, data = data)
anova_table <- summary(fit)[[1L]]
values <- c(
  F = unname(anova_table["group", "F value"]),
  df_num = unname(anova_table["group", "Df"]),
  df_den = unname(anova_table["Residuals", "Df"]),
  p_value = unname(anova_table["group", "Pr(>F)"])
)

if (any(!is.finite(values))) {
  stop("ANOVA statistics are not finite")
}

format_number <- function(x) {
  format(x, digits = 17L, scientific = TRUE, trim = TRUE)
}

n_obs <- nrow(data)
estimate_rows <- vapply(names(values), function(term) {
  sprintf(
    '{"term":"%s","estimate":%s,"se":null,"n_obs":%d}',
    term, format_number(values[[term]]), n_obs
  )
}, character(1L))

json <- paste0(
  '{"task_id":"anova_oneway","platform":"r","estimates":[',
  paste(estimate_rows, collapse = ","),
  '],"method_metadata":{"estimator":"one-way ANOVA",',
  '"vcov":"classical homoskedastic"},"diagnostics":{}}'
)

writeLines(json, "result.json", useBytes = TRUE)
