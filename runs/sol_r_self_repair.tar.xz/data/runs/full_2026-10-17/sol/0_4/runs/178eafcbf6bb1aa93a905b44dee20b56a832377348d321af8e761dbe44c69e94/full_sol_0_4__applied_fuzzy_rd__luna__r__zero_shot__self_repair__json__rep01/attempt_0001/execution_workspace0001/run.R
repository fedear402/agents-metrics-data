dat <- read.csv("input.csv")
dat <- dat[!is.na(dat$score) & abs(dat$score) < 1 &
             !is.na(dat$earnings) & !is.na(dat$participated), ]

x <- dat$score
right <- as.numeric(x >= 0)
w <- 1 - abs(x)
X <- cbind(intercept = 1, right = right, score = x,
           right_score = right * x)

bread <- solve(crossprod(X, w * X))
fit <- function(y) {
  beta <- as.vector(bread %*% crossprod(X, w * y))
  residual <- y - as.vector(X %*% beta)
  influence <- (w * residual) * as.vector(X %*% bread[, 2])
  list(discontinuity = beta[2], influence = influence)
}

rf <- fit(dat$earnings)
fs <- fit(dat$participated)

variance_rf <- sum(rf$influence^2)
variance_fs <- sum(fs$influence^2)
covariance <- sum(rf$influence * fs$influence)

effect <- rf$discontinuity / fs$discontinuity
variance_effect <- variance_rf / fs$discontinuity^2 +
  rf$discontinuity^2 * variance_fs / fs$discontinuity^4 -
  2 * rf$discontinuity * covariance / fs$discontinuity^3

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = effect,
         se = sqrt(max(0, variance_effect)), n_obs = nrow(dat)),
    list(term = "reduced_form", estimate = rf$discontinuity,
         se = sqrt(variance_rf), n_obs = nrow(dat)),
    list(term = "first_stage", estimate = fs$discontinuity,
         se = sqrt(variance_fs), n_obs = nrow(dat))
  ),
  method_metadata = list(
    estimator = "Triangular-weighted local-linear fuzzy RD; right minus left",
    vcov = "HC0 sandwich; joint delta method for ratio"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = NA)
