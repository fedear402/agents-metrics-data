data <- read.csv("./input.csv")
data <- data[order(data$t), ]

y <- as.numeric(data$y)
if (anyNA(y)) stop("y contains missing or nonnumeric values")
if (tail(data$t, 1) != 250) stop("The last observed time must be t = 250")

fit <- stats::arima(
  y,
  order = c(1, 1, 1),
  include.mean = FALSE,
  method = "ML"
)

pred <- stats::predict(fit, n.ahead = 1)
forecast <- as.numeric(pred$pred[1])
se <- as.numeric(pred$se[1])
critical <- stats::qnorm(0.975)
n_obs <- length(y)

result <- sprintf(
  paste0(
    '{"task_id":"arima_forecast","platform":"r","estimates":[',
    '{"term":"forecast","estimate":%.15g,"se":%.15g,"n_obs":%d},',
    '{"term":"lower_95","estimate":%.15g,"se":null,"n_obs":%d},',
    '{"term":"upper_95","estimate":%.15g,"se":null,"n_obs":%d}',
    '],"method_metadata":{"estimator":"ARIMA(1,1,1) maximum likelihood, no drift",',
    '"vcov":"Gaussian one-step predictive variance"},"diagnostics":{}}'
  ),
  forecast, se, n_obs,
  forecast - critical * se, n_obs,
  forecast + critical * se, n_obs
)

writeLines(result, "result.json")
