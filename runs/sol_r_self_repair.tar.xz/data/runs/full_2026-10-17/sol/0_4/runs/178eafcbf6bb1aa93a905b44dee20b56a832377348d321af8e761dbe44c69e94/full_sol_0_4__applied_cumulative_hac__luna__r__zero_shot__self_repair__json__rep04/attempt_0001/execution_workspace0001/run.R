data <- read.csv("input.csv", stringsAsFactors = FALSE)
data <- data[order(as.Date(data$date)), ]

log_vix_change <- c(NA_real_, diff(log(data$vix)))
n <- nrow(data)

lagged_changes <- sapply(1:15, function(k) {
  c(rep(NA_real_, k), log_vix_change[seq_len(n - k)])
})
colnames(lagged_changes) <- paste0("lag_", 1:15)

regression_data <- data.frame(
  log_sales = log(data$sales),
  lagged_changes
)
regression_data <- regression_data[complete.cases(regression_data), ]
fit <- lm(log_sales ~ ., data = regression_data)

X <- model.matrix(fit)
u <- residuals(fit)
N <- nrow(X)
bread <- solve(crossprod(X))
meat <- crossprod(X * u)

for (j in 1:15) {
  weight <- 1 - j / 16
  cross_lag <- crossprod(
    X[(j + 1):N, , drop = FALSE] * u[(j + 1):N],
    X[1:(N - j), , drop = FALSE] * u[1:(N - j)]
  )
  meat <- meat + weight * (cross_lag + t(cross_lag))
}

covariance <- (N / (N - 16)) * bread %*% meat %*% bread
coefficients <- coef(fit)
lag_names <- paste0("lag_", 1:15)

cumulative_estimate <- sum(coefficients[lag_names])
cumulative_variance <- sum(covariance[lag_names, lag_names, drop = FALSE])

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(
      term = "cumulative_response",
      estimate = unname(cumulative_estimate),
      se = unname(sqrt(cumulative_variance)),
      n_obs = N
    ),
    list(
      term = "lag_1",
      estimate = unname(coefficients["lag_1"]),
      se = unname(sqrt(covariance["lag_1", "lag_1"])),
      n_obs = N
    ),
    list(
      term = "lag_15",
      estimate = unname(coefficients["lag_15"]),
      se = unname(sqrt(covariance["lag_15", "lag_15"])),
      n_obs = N
    )
  ),
  method_metadata = list(
    estimator = "OLS with intercept and 15 lagged log VIX changes",
    vcov = "Newey-West HAC, Bartlett weights, maximum lag 15, scaled by N/(N-16)"
  ),
  diagnostics = list()
)

jsonlite::write_json(
  result,
  path = "result.json",
  auto_unbox = TRUE,
  digits = NA
)
