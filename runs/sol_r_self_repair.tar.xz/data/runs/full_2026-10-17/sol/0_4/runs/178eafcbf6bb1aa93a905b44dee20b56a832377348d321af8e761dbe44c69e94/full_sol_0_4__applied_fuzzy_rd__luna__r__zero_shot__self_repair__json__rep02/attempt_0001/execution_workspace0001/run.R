data <- read.csv("input.csv")

keep <- complete.cases(data[, c("score", "participated", "earnings")]) &
  abs(data$score) < 1
data <- data[keep, ]
n_obs <- nrow(data)

right <- as.numeric(data$score >= 0)
X <- cbind(
  intercept = 1,
  score = data$score,
  right = right,
  score_right = data$score * right
)
w <- 1 - abs(data$score)

bread <- solve(crossprod(X, w * X))

fit_jump <- function(y) {
  beta <- bread %*% crossprod(X, w * y)
  residual <- as.vector(y - X %*% beta)
  list(jump = unname(beta["right", 1]), residual = residual)
}

rf <- fit_jump(data$earnings)
fs <- fit_jump(data$participated)

jump_cov <- function(residual_a, residual_b) {
  meat <- crossprod(X, (w^2 * residual_a * residual_b) * X)
  unname((bread %*% meat %*% bread)["right", "right"])
}

var_rf <- jump_cov(rf$residual, rf$residual)
var_fs <- jump_cov(fs$residual, fs$residual)
cov_rf_fs <- jump_cov(rf$residual, fs$residual)

effect <- rf$jump / fs$jump
var_effect <- var_rf / fs$jump^2 +
  rf$jump^2 * var_fs / fs$jump^4 -
  2 * rf$jump * cov_rf_fs / fs$jump^3

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = effect,
         se = sqrt(max(0, var_effect)), n_obs = n_obs),
    list(term = "reduced_form", estimate = rf$jump,
         se = sqrt(max(0, var_rf)), n_obs = n_obs),
    list(term = "first_stage", estimate = fs$jump,
         se = sqrt(max(0, var_fs)), n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "Fuzzy RD ratio of triangular-weighted local-linear discontinuities",
    vcov = "HC0 sandwich; joint delta method for ratio"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = NA)
