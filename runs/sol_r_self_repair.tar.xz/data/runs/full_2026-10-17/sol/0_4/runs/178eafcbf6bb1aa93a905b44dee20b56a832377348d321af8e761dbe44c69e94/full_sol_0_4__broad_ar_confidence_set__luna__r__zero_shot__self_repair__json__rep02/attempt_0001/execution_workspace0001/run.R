dat <- read.csv("input.csv")
n <- nrow(dat)
df2 <- n - 4L

X <- cbind(1, dat$x)
Z <- cbind(dat$z1, dat$z2)

rx <- qr(X)
y_res <- qr.resid(rx, dat$y)
d_res <- qr.resid(rx, dat$endog)
z_res <- qr.resid(rx, Z)

rz <- qr(z_res)
y_proj <- qr.fitted(rz, y_res)
d_proj <- qr.fitted(rz, d_res)
y_unres <- y_res - y_proj
d_unres <- d_res - d_proj

quadratic <- function(a, b) {
  c(sum(a * a), -2 * sum(a * b), sum(b * b))
}

num <- quadratic(y_proj, d_proj)
den <- quadratic(y_unres, d_unres)

critical <- qf(0.95, df1 = 2, df2 = df2)
test_poly <- num - (2 * critical / df2) * den
roots <- polyroot(test_poly)
stopifnot(length(roots) == 2L, all(abs(Im(roots)) < 1e-8))
bounds <- sort(Re(roots))

accepts_zero <- as.integer(test_poly[1] <= 0)
unbounded <- as.integer(test_poly[3] < 0)
ar_f_at_one <- (df2 / 2) * sum(num) / sum(den)

estimates <- list(
  list(term = "boundary_low", estimate = bounds[1], se = NULL, n_obs = n),
  list(term = "boundary_high", estimate = bounds[2], se = NULL, n_obs = n),
  list(term = "accepts_zero", estimate = accepts_zero, se = NULL, n_obs = n),
  list(term = "unbounded", estimate = unbounded, se = NULL, n_obs = n),
  list(term = "ar_f_at_one", estimate = ar_f_at_one, se = NULL, n_obs = n)
)

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "Anderson-Rubin confidence set by exact quadratic inversion",
    vcov = "Conventional homoskedastic OLS joint F test"
  ),
  diagnostics = list()
)

jsonlite::write_json(
  result,
  path = "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 15,
  pretty = TRUE
)
