library(jsonlite)

d <- read.csv("input.csv", stringsAsFactors = FALSE)
regions <- unique(d$region_id)
industries <- unique(d$industry_id)

regional <- d[match(regions, d$region_id), ]
shock <- d$shock[match(industries, d$industry_id)]
e <- regional$region_weight / sum(regional$region_weight)

regional_z <- rowsum(d$share * d$shock, d$region_id, reorder = FALSE)
z <- as.numeric(regional_z[match(as.character(regions), rownames(regional_z)), 1])

center <- function(v) v - sum(e * v)
y0 <- center(regional$y)
x0 <- center(regional$x)
z0 <- center(z)

row_index <- match(d$region_id, regions)
ew_share <- e[row_index] * d$share

industry_sum <- function(v) {
  a <- rowsum(v, d$industry_id, reorder = FALSE)
  as.numeric(a[match(as.character(industries), rownames(a)), 1])
}

s <- industry_sum(ew_share)
ybar <- industry_sum(ew_share * y0[row_index]) / s
xbar <- industry_sum(ew_share * x0[row_index]) / s
zbar <- industry_sum(ew_share * z0[row_index]) / s

shock_iv <- function(outcome, regressor) {
  X <- cbind(1, regressor)
  Z <- cbind(1, shock)
  ZX <- crossprod(Z, s * X)
  beta <- solve(ZX, crossprod(Z, s * outcome))
  residual <- as.numeric(outcome - X %*% beta)
  meat <- crossprod(Z, (s * residual)^2 * Z)
  V <- solve(ZX) %*% meat %*% t(solve(ZX))
  V <- V * length(industries) / (length(industries) - 2)
  c(estimate = unname(beta[2]), se = sqrt(V[2, 2]))
}

effect <- shock_iv(ybar, xbar)
first_stage <- shock_iv(xbar, zbar)
N <- length(industries)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = effect["estimate"],
         se = effect["se"], n_obs = N),
    list(term = "first_stage", estimate = first_stage["estimate"],
         se = first_stage["se"], n_obs = N),
    list(term = "effective_shocks", estimate = 1 / sum(s^2),
         se = NULL, n_obs = N)
  ),
  method_metadata = list(
    estimator = "Weighted regional 2SLS via BHJ shock-level IV",
    vcov = "Shock-level heteroskedasticity-robust HC1; N/(N-2)"
  ),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, digits = NA)
