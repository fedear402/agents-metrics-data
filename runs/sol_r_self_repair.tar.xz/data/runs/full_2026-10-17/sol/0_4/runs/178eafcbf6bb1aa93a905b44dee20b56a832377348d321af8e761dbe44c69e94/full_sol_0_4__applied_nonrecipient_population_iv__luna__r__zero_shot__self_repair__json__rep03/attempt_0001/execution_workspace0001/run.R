households <- read.csv("households.csv")
census <- read.csv("census.csv")

sample <- households[!is.na(households$recipient) & households$recipient == 0, ]
n_obs <- nrow(sample)

if (n_obs == 0L) stop("No nonrecipient households are available.")
if (anyNA(sample[, c("eligible", "instrument", "dose", "baseline", "weight", "outcome")])) {
  stop("Estimation variables contain missing values.")
}
if (any(sample$weight <= 0)) stop("Weights must be positive.")

ineligible <- 1 - sample$eligible
eligible <- sample$eligible

exogenous <- cbind(
  ineligible,
  eligible,
  baseline_ineligible = sample$baseline * ineligible,
  baseline_eligible = sample$baseline * eligible
)
endogenous <- cbind(
  dose_ineligible = sample$dose * ineligible,
  dose_eligible = sample$dose * eligible
)
X <- cbind(exogenous, endogenous)
Z <- cbind(
  exogenous,
  instrument_ineligible = sample$instrument * ineligible,
  instrument_eligible = sample$instrument * eligible
)

weighted_X <- X * sqrt(sample$weight)
weighted_Z <- Z * sqrt(sample$weight)
weighted_y <- sample$outcome * sqrt(sample$weight)

ZtZ <- crossprod(weighted_Z)
ZtX <- crossprod(weighted_Z, weighted_X)
Zty <- crossprod(weighted_Z, weighted_y)

beta <- solve(
  crossprod(ZtX, solve(ZtZ, ZtX)),
  crossprod(ZtX, solve(ZtZ, Zty))
)
names(beta) <- colnames(X)

mean_dose_ineligible <- weighted.mean(
  sample$dose[ineligible == 1],
  sample$weight[ineligible == 1]
)
mean_dose_eligible <- weighted.mean(
  sample$dose[eligible == 1],
  sample$weight[eligible == 1]
)

ineligible_effect <- unname(beta["dose_ineligible"] * mean_dose_ineligible)
eligible_nonrecipient_effect <- unname(beta["dose_eligible"] * mean_dose_eligible)

if (anyNA(census[, c("eligible", "nonrecipient_population")])) {
  stop("Census aggregation variables contain missing values.")
}
population <- tapply(
  census$nonrecipient_population,
  census$eligible,
  sum
)
if (!all(c("0", "1") %in% names(population))) {
  stop("Census must include both eligibility groups.")
}
population <- population[c("0", "1")]
population_effect <- unname(
  sum(c(ineligible_effect, eligible_nonrecipient_effect) * population) /
    sum(population)
)

estimates <- list(
  list(term = "ineligible_effect", estimate = ineligible_effect, se = NULL, n_obs = n_obs),
  list(term = "eligible_nonrecipient_effect", estimate = eligible_nonrecipient_effect, se = NULL, n_obs = n_obs),
  list(term = "population_effect", estimate = population_effect, se = NULL, n_obs = n_obs)
)

result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "weighted 2SLS",
    sample = "all households with recipient = 0",
    intercept = "no additional intercept",
    group_effect = "fitted group dose slope times household-weighted mean dose",
    counterfactual = "dose set to zero for every retained household; synthetic attribution convention",
    population_aggregation = "nonrecipient_population census counts used only for final between-group weights"
  ),
  diagnostics = list(
    n_obs = n_obs,
    n_ineligible = sum(ineligible == 1),
    n_eligible = sum(eligible == 1)
  )
)

jsonlite::write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
