data <- read.csv("input.csv", stringsAsFactors = FALSE)
data <- data[order(as.Date(data$date)), ]

n_total <- nrow(data)
log_sales <- log(data$sales)
delta_log_vix <- diff(log(data$vix))

lags <- sapply(1:15, function(k) {
  c(rep(NA_real_, k + 1), head(delta_log_vix, n_total - k - 1))
})
colnames(lags) <- paste0("lag_", 1:15)

complete <- complete.cases(log_sales, lags)
y <- log_sales[complete]
X <- cbind("(Intercept)" = 1, lags[complete, , drop = FALSE])
N <- length(y)

fit <- lm.fit(X, y)
beta <- fit$coefficients
residuals <- fit$residuals
scores <- X * as.vector(residuals)

meat <- crossprod(scores)
for (j in 1:15) {
  gamma_j <- crossprod(
    scores[(j + 1):N, , drop = FALSE],
    scores[1:(N - j), , drop = FALSE]
  )
  meat <- meat + (1 - j / 16) * (gamma_j + t(gamma_j))
}

bread <- solve(crossprod(X))
vcov_hac <- (N / (N - 16)) * bread %*% meat %*% bread

cumulative_weights <- c(0, rep(1, 15))
estimates <- c(
  cumulative_response = sum(beta[-1]),
  lag_1 = beta["lag_1"],
  lag_15 = beta["lag_15"]
)
standard_errors <- c(
  cumulative_response = sqrt(as.numeric(
    t(cumulative_weights) %*% vcov_hac %*% cumulative_weights
  )),
  lag_1 = sqrt(vcov_hac["lag_1", "lag_1"]),
  lag_15 = sqrt(vcov_hac["lag_15", "lag_15"])
)

fmt <- function(x) sprintf("%.15g", x)
terms <- c("cumulative_response", "lag_1", "lag_15")
rows <- vapply(terms, function(term) {
  sprintf(
    '{"term":"%s","estimate":%s,"se":%s,"n_obs":%d}',
    term, fmt(estimates[term]), fmt(standard_errors[term]), N
  )
}, character(1))

json <- sprintf(
  paste0(
    '{"task_id":"applied_cumulative_hac","platform":"r",',
    '"estimates":[%s],',
    '"method_metadata":{"estimator":"OLS",',
    '"vcov":"Newey-West HAC, maximum lag 15, Bartlett weights, N/(N-16) adjustment"},',
    '"diagnostics":{}}'
  ),
  paste(rows, collapse = ",")
)
writeLines(json, "result.json")
