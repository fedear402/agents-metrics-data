d <- read.csv("input.csv")
n <- nrow(d)

W <- cbind(1, d$x)
Z <- cbind(d$z1, d$z2)
rw <- qr(W)

y <- qr.resid(rw, d$y)
e <- qr.resid(rw, d$endog)
zr <- qr.resid(rw, Z)
rz <- qr(zr)

project <- function(v) qr.fitted(rz, v)
py <- project(y)
pe <- project(e)

explained <- c(
  sum(py^2),
  -2 * sum(py * pe),
  sum(pe^2)
)
residual <- c(
  sum((y - py)^2),
  -2 * sum((y - py) * (e - pe)),
  sum((e - pe)^2)
)

critical <- qf(0.95, df1 = 2, df2 = n - 4)
q <- (n - 4) * explained - 2 * critical * residual

roots <- sort(Re(polyroot(q)))
if (length(roots) != 2 || any(abs(Im(polyroot(q))) > 1e-7)) {
  stop("Expected two finite real boundary points.")
}

ar_f <- function(beta) {
  v <- y - beta * e
  fitted <- project(v)
  (sum(fitted^2) / 2) /
    (sum((v - fitted)^2) / (n - 4))
}

entry <- function(term, estimate) {
  list(term = term, estimate = as.numeric(estimate), se = NULL, n_obs = n)
}

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = list(
    entry("boundary_low", roots[1]),
    entry("boundary_high", roots[2]),
    entry("accepts_zero", as.numeric(q[1] <= 0)),
    entry("unbounded", as.numeric(q[3] < 0)),
    entry("ar_f_at_one", ar_f(1))
  ),
  method_metadata = list(
    estimator = "Anderson-Rubin test inversion",
    vcov = "Conventional homoskedastic joint F test"
  ),
  diagnostics = list()
)

jsonlite::write_json(
  result, "result.json",
  auto_unbox = TRUE, null = "null", digits = 15
)
