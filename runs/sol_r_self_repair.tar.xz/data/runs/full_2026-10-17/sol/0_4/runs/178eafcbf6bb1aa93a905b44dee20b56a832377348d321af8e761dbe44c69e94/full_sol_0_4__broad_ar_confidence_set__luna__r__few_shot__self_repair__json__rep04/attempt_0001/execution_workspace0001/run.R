d <- read.csv("input.csv")
n <- nrow(d)
stopifnot(n > 4L, all(c("y", "endog", "x", "z1", "z2") %in% names(d)))
stopifnot(all(complete.cases(d[c("y", "endog", "x", "z1", "z2")])))

Xr <- cbind(1, d$x)
Xu <- cbind(1, d$x, d$z1, d$z2)
stopifnot(qr(Xr)$rank == 2L, qr(Xu)$rank == 4L)

residual_pair <- function(X) {
  fit <- qr(X)
  cbind(
    y = qr.resid(fit, d$y),
    endog = qr.resid(fit, d$endog)
  )
}

r <- residual_pair(Xr)
u <- residual_pair(Xu)
q <- 2L
df <- n - 4L
critical <- qf(0.95, q, df)
k <- q * critical / df

A <- sum(r[, "endog"]^2) - (1 + k) * sum(u[, "endog"]^2)
B <- -2 * (
  sum(r[, "y"] * r[, "endog"]) -
    (1 + k) * sum(u[, "y"] * u[, "endog"])
)
C <- sum(r[, "y"]^2) - (1 + k) * sum(u[, "y"]^2)

discriminant <- B^2 - 4 * A * C
stopifnot(is.finite(discriminant), discriminant > 0, A != 0)
bounds <- sort(c(
  (-B - sqrt(discriminant)) / (2 * A),
  (-B + sqrt(discriminant)) / (2 * A)
))

f_at <- function(beta) {
  restricted_ssr <- sum((r[, "y"] - beta * r[, "endog"])^2)
  unrestricted_ssr <- sum((u[, "y"] - beta * u[, "endog"])^2)
  ((restricted_ssr - unrestricted_ssr) / q) /
    (unrestricted_ssr / df)
}

row <- function(term, estimate) {
  list(term = term, estimate = unname(as.numeric(estimate)),
       se = NULL, n_obs = as.integer(n))
}

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = list(
    row("boundary_low", bounds[1]),
    row("boundary_high", bounds[2]),
    row("accepts_zero", as.integer(C <= 0)),
    row("unbounded", as.integer(A < 0)),
    row("ar_f_at_one", f_at(1))
  ),
  method_metadata = list(
    estimator = "Anderson-Rubin confidence set by joint F-test inversion",
    vcov = "Conventional homoskedastic OLS"
  ),
  diagnostics = list()
)

jsonlite::write_json(
  result, "result.json", auto_unbox = TRUE, null = "null",
  digits = 16, pretty = TRUE
)
