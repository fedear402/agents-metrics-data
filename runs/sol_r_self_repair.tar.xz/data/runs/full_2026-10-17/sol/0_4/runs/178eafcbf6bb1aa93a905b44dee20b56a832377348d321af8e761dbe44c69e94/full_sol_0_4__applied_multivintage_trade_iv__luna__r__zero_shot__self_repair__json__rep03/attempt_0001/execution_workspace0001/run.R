library(jsonlite)

crosswalk <- read.csv("crosswalk.csv")
trade <- read.csv("trade.csv")
areas <- read.csv("areas.csv")
employment <- read.csv("employment.csv")
outcomes <- read.csv("outcomes.csv")

trade <- merge(trade, crosswalk, by = "code")
industries <- unique(crosswalk["industry"])

cells <- merge(areas, industries)
cells <- merge(
  cells, employment,
  by = c("area", "period", "vintage", "industry"),
  all.x = TRUE
)
cells$employment[is.na(cells$employment)] <- 0

national <- aggregate(
  employment ~ period + vintage + industry,
  data = cells,
  FUN = sum
)
names(national)[names(national) == "employment"] <- "national_employment"

cells <- merge(
  cells, national,
  by = c("period", "vintage", "industry")
)
cells <- merge(
  cells, trade,
  by = c("period", "industry")
)

cells$trade_change <- ifelse(
  cells$vintage == "base",
  cells$us_change,
  cells$other_change
)
cells$contribution <- (
  (cells$employment / cells$total_employment) *
  (cells$trade_change / cells$national_employment) /
  (cells$price_index / 100) /
  1000 *
  (10 / cells$years)
)

exposures <- aggregate(
  contribution ~ area + period + vintage,
  data = cells,
  FUN = sum
)
wide <- reshape(
  exposures,
  idvar = c("area", "period"),
  timevar = "vintage",
  direction = "wide"
)
names(wide)[names(wide) == "contribution.base"] <- "x"
names(wide)[names(wide) == "contribution.early"] <- "z"

base_areas <- areas[areas$vintage == "base",
                    c("area", "period", "population")]
data <- merge(outcomes, wide, by = c("area", "period"))
data <- merge(data, base_areas, by = c("area", "period"))

Q <- model.matrix(~ period + control, data = data)
X <- cbind(Q, x = data$x)
Z <- cbind(Q, z = data$z)
weighted_Z <- Z * sqrt(data$population)
weighted_X <- X * sqrt(data$population)
weighted_y <- data$change_pp * sqrt(data$population)

beta <- solve(
  crossprod(weighted_Z, weighted_X),
  crossprod(weighted_Z, weighted_y)
)

lookup <- function(column, target_period) {
  rows <- data$area == 0 & as.character(data$period) == target_period
  stopifnot(sum(rows) == 1L)
  as.numeric(data[[column]][rows])
}

n_obs <- nrow(data)
stopifnot(n_obs == 72L)

make_estimate <- function(term, value) {
  list(
    term = term,
    estimate = as.numeric(value),
    se = NA_real_,
    n_obs = as.integer(n_obs)
  )
}

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = list(
    make_estimate("iv_slope", beta["x", 1]),
    make_estimate("exposure_area0_period0", lookup("x", "0")),
    make_estimate("exposure_area0_period1", lookup("x", "1")),
    make_estimate("instrument_area0_period0", lookup("z", "0"))
  ),
  method_metadata = list(
    estimator = "population-weighted two-stage least squares",
    endogenous_variable = "x",
    excluded_instrument = "z",
    exogenous_instruments = colnames(Q),
    exposure_units = "thousands of real dollars per worker per decade"
  ),
  diagnostics = list(n_obs = as.integer(n_obs))
)

jsonlite::write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  digits = NA,
  na = "null",
  pretty = TRUE
)
