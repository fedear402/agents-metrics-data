d <- read.csv("input.csv")
d$y <- factor(d$y, levels = 0:2)
n <- nrow(d)

fit <- nnet::multinom(
  y ~ x + z,
  data = d,
  Hess = TRUE,
  trace = FALSE,
  maxit = 1000,
  reltol = 1e-12,
  abstol = 1e-12
)

B <- coef(fit)
V <- vcov(fit)

indices <- c(0, B[, "(Intercept)"])
weights <- exp(indices - max(indices))
prob_cat2_zero <- weights[3] / sum(weights)

row <- function(term, estimate, se) {
  list(term = term, estimate = unname(estimate), se = unname(se), n_obs = n)
}

result <- list(
  task_id = "broad_multinomial_logit",
  platform = "r",
  estimates = list(
    row("x_cat1", B["1", "x"], sqrt(V["1:x", "1:x"])),
    row("z_cat1", B["1", "z"], sqrt(V["1:z", "1:z"])),
    row("x_cat2", B["2", "x"], sqrt(V["2:x", "2:x"])),
    row("z_cat2", B["2", "z"], sqrt(V["2:z", "2:z"])),
    row("prob_cat2_zero", prob_cat2_zero, NULL)
  ),
  method_metadata = list(
    estimator = "maximum likelihood multinomial logit; base outcome 0",
    vcov = "inverse observed information"
  ),
  diagnostics = list()
)

jsonlite::write_json(
  result, "result.json",
  auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE
)
