d <- read.csv("input.csv")
d$y <- factor(d$y, levels = 0:2)

fit <- nnet::multinom(
  y ~ x + z,
  data = d,
  Hess = TRUE,
  trace = FALSE,
  maxit = 1000,
  reltol = 1e-12,
  abstol = 1e-12
)

B <- coef(fit)
V <- vcov(fit)
indices <- c(0, B[, "(Intercept)"])
probabilities <- exp(indices - max(indices))
probabilities <- probabilities / sum(probabilities)
n <- nrow(d)

row <- function(term, category, variable) {
  key <- paste(category, variable, sep = ":")
  list(
    term = term,
    estimate = unname(B[category, variable]),
    se = unname(sqrt(V[key, key])),
    n_obs = n
  )
}

result <- list(
  task_id = "broad_multinomial_logit",
  platform = "r",
  estimates = list(
    row("x_cat1", "1", "x"),
    row("z_cat1", "1", "z"),
    row("x_cat2", "2", "x"),
    row("z_cat2", "2", "z"),
    list(
      term = "prob_cat2_zero",
      estimate = unname(probabilities[3]),
      se = NULL,
      n_obs = n
    )
  ),
  method_metadata = list(
    estimator = "multinomial logit maximum likelihood",
    vcov = "inverse observed information"
  ),
  diagnostics = list()
)

jsonlite::write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
