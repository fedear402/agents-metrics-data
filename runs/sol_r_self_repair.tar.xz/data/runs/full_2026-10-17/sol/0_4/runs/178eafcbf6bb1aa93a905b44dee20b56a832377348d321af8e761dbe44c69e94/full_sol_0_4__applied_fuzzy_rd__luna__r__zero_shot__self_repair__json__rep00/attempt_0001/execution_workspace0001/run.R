dat <- read.csv("input.csv")

keep <- complete.cases(dat[, c("score", "participated", "earnings")]) &
  abs(dat$score) < 1
dat <- dat[keep, ]

x <- dat$score
right <- as.numeric(x >= 0)
w <- 1 - abs(x)
X <- cbind(intercept = 1, right = right, score = x, right_score = right * x)

fit_y <- lm.wfit(X, dat$earnings, w)
fit_d <- lm.wfit(X, dat$participated, w)

bread <- solve(crossprod(X, w * X))
scores_y <- X * as.vector(w * fit_y$residuals)
scores_d <- X * as.vector(w * fit_d$residuals)

rf <- unname(fit_y$coefficients["right"])
fs <- unname(fit_d$coefficients["right"])
v_rf <- (bread %*% crossprod(scores_y) %*% bread)["right", "right"]
v_fs <- (bread %*% crossprod(scores_d) %*% bread)["right", "right"]
cov_rf_fs <- (bread %*% crossprod(scores_y, scores_d) %*% bread)["right", "right"]

effect <- rf / fs
v_effect <- v_rf / fs^2 + rf^2 * v_fs / fs^4 -
  2 * rf * cov_rf_fs / fs^3

as_se <- function(v) if (is.finite(v) && v >= 0) sqrt(v) else NULL
n <- nrow(dat)

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = effect,
         se = as_se(v_effect), n_obs = n),
    list(term = "reduced_form", estimate = rf,
         se = as_se(v_rf), n_obs = n),
    list(term = "first_stage", estimate = fs,
         se = as_se(v_fs), n_obs = n)
  ),
  method_metadata = list(
    estimator = "Triangular-weighted local linear fuzzy RD, bandwidth 1",
    vcov = "HC0 sandwich; joint covariance and delta method for ratio"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = NA,
                     null = "null")
