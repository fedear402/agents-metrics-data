data <- read.csv("input.csv", stringsAsFactors = FALSE)
data <- data[order(as.Date(data$date)), ]

log_sales <- log(data$sales)
change <- c(NA_real_, diff(log(data$vix)))
n_total <- nrow(data)

lags <- sapply(1:15, function(k) {
  c(rep(NA_real_, k), change[seq_len(n_total - k)])
})
colnames(lags) <- paste0("lag_", 1:15)

complete <- complete.cases(log_sales, lags)
y <- log_sales[complete]
X <- cbind("(Intercept)" = 1, lags[complete, , drop = FALSE])
N <- length(y)

fit <- lm.fit(X, y)
beta <- fit$coefficients
scores <- X * as.vector(fit$residuals)

meat <- crossprod(scores)
for (j in 1:15) {
  gamma_j <- crossprod(
    scores[(j + 1):N, , drop = FALSE],
    scores[1:(N - j), , drop = FALSE]
  )
  meat <- meat + (1 - j / 16) * (gamma_j + t(gamma_j))
}

bread <- solve(crossprod(X))
vcov_hac <- (N / (N - 16)) * bread %*% meat %*% bread
dimnames(vcov_hac) <- list(colnames(X), colnames(X))

weights <- c(0, rep(1, 15))
estimates <- c(
  cumulative_response = unname(sum(beta[-1])),
  lag_1 = unname(beta["lag_1"]),
  lag_15 = unname(beta["lag_15"])
)
standard_errors <- c(
  cumulative_response = sqrt(as.numeric(
    t(weights) %*% vcov_hac %*% weights
  )),
  lag_1 = sqrt(vcov_hac["lag_1", "lag_1"]),
  lag_15 = sqrt(vcov_hac["lag_15", "lag_15"])
)

fmt <- function(x) sprintf("%.15g", unname(x))
terms <- c("cumulative_response", "lag_1", "lag_15")
rows <- vapply(terms, function(term) {
  sprintf(
    '{"term":"%s","estimate":%s,"se":%s,"n_obs":%d}',
    term, fmt(estimates[[term]]), fmt(standard_errors[[term]]), N
  )
}, character(1))

json <- sprintf(
  paste0(
    '{"task_id":"applied_cumulative_hac","platform":"r",',
    '"estimates":[%s],',
    '"method_metadata":{"estimator":"OLS",',
    '"vcov":"Newey-West HAC, maximum lag 15, Bartlett weights, N/(N-16) adjustment"},',
    '"diagnostics":{}}'
  ),
  paste(rows, collapse = ",")
)
writeLines(json, "result.json")
