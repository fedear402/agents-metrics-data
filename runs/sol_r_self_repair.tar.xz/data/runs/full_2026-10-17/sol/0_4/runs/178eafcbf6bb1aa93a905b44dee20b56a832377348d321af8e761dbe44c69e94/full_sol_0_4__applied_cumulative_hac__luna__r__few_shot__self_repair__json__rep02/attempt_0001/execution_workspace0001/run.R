library(jsonlite)

data <- read.csv("input.csv", stringsAsFactors = FALSE)
data <- data[order(as.Date(data$date)), ]

n <- nrow(data)
change <- c(NA_real_, diff(log(data$vix)))
lags <- sapply(1:15, function(k) {
  c(rep(NA_real_, k), change[seq_len(n - k)])
})
colnames(lags) <- paste0("lag_", 1:15)

sample <- data.frame(log_sales = log(data$sales), lags)
sample <- sample[complete.cases(sample), ]

fit <- lm(log_sales ~ ., data = sample)
X <- model.matrix(fit)
scores <- X * as.numeric(residuals(fit))
N <- nrow(X)
p <- ncol(X)

meat <- crossprod(scores)
for (j in 1:15) {
  product <- crossprod(
    scores[(j + 1):N, , drop = FALSE],
    scores[1:(N - j), , drop = FALSE]
  )
  meat <- meat + (1 - j / 16) * (product + t(product))
}

bread <- solve(crossprod(X))
V <- (N / (N - p)) * bread %*% meat %*% bread
b <- coef(fit)

contrast <- c(0, rep(1, 15))
row <- function(term, estimate, se) {
  list(
    term = term,
    estimate = unname(as.numeric(estimate)),
    se = unname(as.numeric(se)),
    n_obs = as.integer(N)
  )
}

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    row("cumulative_response", sum(contrast * b),
        sqrt(drop(t(contrast) %*% V %*% contrast))),
    row("lag_1", b["lag_1"], sqrt(V["lag_1", "lag_1"])),
    row("lag_15", b["lag_15"], sqrt(V["lag_15", "lag_15"]))
  ),
  method_metadata = list(
    estimator = "OLS",
    vcov = "Newey-West HAC, Bartlett lag 15, N/(N-16) correction"
  ),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, digits = 16,
           null = "null", pretty = TRUE)
