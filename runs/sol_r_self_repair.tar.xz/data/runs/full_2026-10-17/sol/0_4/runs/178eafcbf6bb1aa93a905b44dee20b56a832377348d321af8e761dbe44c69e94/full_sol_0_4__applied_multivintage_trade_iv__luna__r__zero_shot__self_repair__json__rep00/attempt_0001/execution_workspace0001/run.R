library(jsonlite)

crosswalk <- read.csv("crosswalk.csv")
trade <- read.csv("trade.csv")
areas <- read.csv("areas.csv")
employment <- read.csv("employment.csv")
outcomes <- read.csv("outcomes.csv")

trade_industry <- merge(trade, crosswalk, by = "code")

grid <- merge(
  areas[, c("area", "period", "vintage", "total_employment", "population")],
  unique(crosswalk["industry"]),
  by = NULL
)
grid <- merge(
  grid, employment,
  by = c("area", "period", "vintage", "industry"),
  all.x = TRUE
)
grid$employment[is.na(grid$employment)] <- 0

national <- aggregate(
  employment ~ period + vintage + industry,
  data = grid,
  FUN = sum
)
names(national)[names(national) == "employment"] <- "national_employment"

cells <- merge(
  grid, national,
  by = c("period", "vintage", "industry")
)
cells <- merge(
  cells, trade_industry,
  by = c("period", "industry")
)

cells$trade_change <- ifelse(
  cells$vintage == "base", cells$us_change, cells$other_change
)
cells$contribution <-
  (cells$employment / cells$total_employment) *
  (cells$trade_change / cells$national_employment) /
  (cells$price_index / 100) / 1000 *
  (10 / cells$years)

exposures <- aggregate(
  contribution ~ area + period + vintage,
  data = cells,
  FUN = sum
)
wide <- reshape(
  exposures,
  idvar = c("area", "period"),
  timevar = "vintage",
  direction = "wide"
)
names(wide)[names(wide) == "contribution.base"] <- "x"
names(wide)[names(wide) == "contribution.early"] <- "z"

base_areas <- areas[
  areas$vintage == "base",
  c("area", "period", "population")
]
dat <- merge(wide, base_areas, by = c("area", "period"))
dat <- merge(dat, outcomes, by = c("area", "period"))
dat <- dat[complete.cases(dat[, c(
  "change_pp", "period", "control", "x", "z", "population"
)]), ]

# Weighted 2SLS: regress the outcome and endogenous exposure on the same
# instrument matrix, then solve the weighted projected normal equations.
X <- model.matrix(~ period + control + x, data = dat)
Z <- model.matrix(~ period + control + z, data = dat)
y <- dat$change_pp
w <- dat$population
WX <- X * sqrt(w)
WZ <- Z * sqrt(w)
Wy <- y * sqrt(w)

projected_X <- WZ %*% solve(crossprod(WZ), crossprod(WZ, WX))
beta <- solve(crossprod(projected_X, WX), crossprod(projected_X, Wy))
iv_slope <- unname(beta["x", 1])

period_values <- sort(unique(dat$period))
area0 <- dat[as.character(dat$area) == "0", ]
get_exposure <- function(period, column) {
  value <- area0[
    as.character(area0$period) == as.character(period),
    column
  ]
  stopifnot(length(value) == 1L)
  unname(value)
}

stopifnot(nrow(dat) == 72L, length(period_values) == 2L)

terms <- c(
  "iv_slope",
  "exposure_area0_period0",
  "exposure_area0_period1",
  "instrument_area0_period0"
)
values <- c(
  iv_slope,
  get_exposure(period_values[1], "x"),
  get_exposure(period_values[2], "x"),
  get_exposure(period_values[1], "z")
)
estimates <- lapply(seq_along(terms), function(i) {
  list(
    term = terms[i],
    estimate = unname(values[i]),
    se = NULL,
    n_obs = 72L
  )
})

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "weighted 2SLS",
    outcome = "change_pp",
    endogenous = "x",
    excluded_instrument = "z",
    exogenous_instruments = c("intercept", "period", "control"),
    weight = "base-vintage population",
    exposure_unit = "thousands of real dollars per worker per decade"
  ),
  diagnostics = list(
    n_obs = 72L,
    n_industries = 4L,
    n_periods = 2L
  )
)
write_json(result, "result.json", auto_unbox = TRUE, digits = NA, null = "null")
