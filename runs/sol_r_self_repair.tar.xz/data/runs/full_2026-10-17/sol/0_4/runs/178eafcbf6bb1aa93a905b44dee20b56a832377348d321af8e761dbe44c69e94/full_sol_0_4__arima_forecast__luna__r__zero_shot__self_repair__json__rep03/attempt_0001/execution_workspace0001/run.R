data <- read.csv("./input.csv")
y <- as.numeric(data$y)

if (anyNA(y) || length(y) != 250L) {
  stop("Expected 250 non-missing observations of y.")
}

fit <- stats::arima(
  y,
  order = c(1L, 1L, 1L),
  include.mean = FALSE,
  method = "ML"
)

prediction <- stats::predict(fit, n.ahead = 1L)
forecast <- as.numeric(prediction$pred[1L])
se <- as.numeric(prediction$se[1L])
critical <- stats::qnorm(0.975)

result <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = list(
    list(term = "forecast", estimate = forecast, se = se, n_obs = length(y)),
    list(term = "lower_95", estimate = forecast - critical * se, se = NULL, n_obs = length(y)),
    list(term = "upper_95", estimate = forecast + critical * se, se = NULL, n_obs = length(y))
  ),
  method_metadata = list(
    estimator = "ARIMA(1,1,1) maximum likelihood without constant or drift",
    vcov = "Model-based one-step-ahead forecast variance"
  ),
  diagnostics = list()
)

jsonlite::write_json(
  result,
  path = "result.json",
  auto_unbox = TRUE,
  digits = NA,
  null = "null"
)
