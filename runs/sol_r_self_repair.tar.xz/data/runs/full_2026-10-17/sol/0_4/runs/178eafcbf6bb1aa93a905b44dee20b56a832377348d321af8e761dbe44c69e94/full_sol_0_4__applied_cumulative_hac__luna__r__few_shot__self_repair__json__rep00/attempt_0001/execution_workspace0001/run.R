data <- read.csv("input.csv", stringsAsFactors = FALSE)
data <- data[order(as.Date(data$date)), ]

change <- c(NA_real_, diff(log(data$vix)))
for (k in 1:15) {
  data[[paste0("lag_", k)]] <- c(rep(NA_real_, k), head(change, -k))
}
data$log_sales <- log(data$sales)

lag_names <- paste0("lag_", 1:15)
sample <- data[complete.cases(data[, c("log_sales", lag_names)]), ]
fit <- lm(reformulate(lag_names, response = "log_sales"), data = sample)

X <- model.matrix(fit)
beta <- coef(fit)
N <- nrow(X)
p <- ncol(X)
scores <- X * as.numeric(residuals(fit))

meat <- crossprod(scores)
for (j in 1:15) {
  product <- crossprod(
    scores[(j + 1):N, , drop = FALSE],
    scores[1:(N - j), , drop = FALSE]
  )
  meat <- meat + (1 - j / 16) * (product + t(product))
}

bread <- solve(crossprod(X))
V <- (N / (N - p)) * bread %*% meat %*% bread

contrast <- c(0, rep(1, 15))
cumulative <- sum(contrast * beta)
cumulative_se <- sqrt(drop(t(contrast) %*% V %*% contrast))

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(
      term = "cumulative_response",
      estimate = unname(cumulative),
      se = unname(cumulative_se),
      n_obs = as.integer(N)
    ),
    list(
      term = "lag_1",
      estimate = unname(beta["lag_1"]),
      se = unname(sqrt(V["lag_1", "lag_1"])),
      n_obs = as.integer(N)
    ),
    list(
      term = "lag_15",
      estimate = unname(beta["lag_15"]),
      se = unname(sqrt(V["lag_15", "lag_15"])),
      n_obs = as.integer(N)
    )
  ),
  method_metadata = list(
    estimator = "OLS with intercept and 15 lags of log VIX changes",
    vcov = "Newey-West Bartlett HAC, maximum lag 15, multiplied by N/(N-16)"
  ),
  diagnostics = list()
)

writeLines(
  jsonlite::toJSON(result, auto_unbox = TRUE, digits = 16, pretty = TRUE),
  "result.json"
)
