d <- read.csv("input.csv")
n <- nrow(d)

stopifnot(n == 240L, all(c("y", "endog", "x", "z1", "z2") %in% names(d)))
stopifnot(!anyNA(d[c("y", "endog", "x", "z1", "z2")]))

W <- cbind(1, d$x)
Z <- cbind(d$z1, d$z2)
Y <- cbind(d$y, d$endog)

residualize <- function(A, B) {
  qr.resid(qr(A), B)
}

Yw <- residualize(W, Y)
Zw <- residualize(W, Z)
stopifnot(qr(Zw)$rank == 2L)

P_y <- Zw %*% qr.coef(qr(Zw), Yw)
R_y <- Yw - P_y

quad <- function(A) as.numeric(crossprod(A[, 1L], A[, 1L]))
cross <- function(A) as.numeric(crossprod(A[, 1L], A[, 2L]))
quad2 <- function(A) as.numeric(crossprod(A[, 2L], A[, 2L]))

explained <- c(quad(P_y), -2 * cross(P_y), quad2(P_y))
residual <- c(quad(R_y), -2 * cross(R_y), quad2(R_y))

df1 <- 2L
df2 <- n - 4L
critical <- qf(0.95, df1, df2)
scale <- df2 / df1

f_at <- function(beta) {
  numerator <- explained[1L] + explained[2L] * beta + explained[3L] * beta^2
  denominator <- residual[1L] + residual[2L] * beta + residual[3L] * beta^2
  scale * numerator / denominator
}

# With positive residual sums of squares, acceptance is equivalent to
# a quadratic inequality that holds for all real beta.
q <- scale * explained - critical * residual
disc <- q[2L]^2 - 4 * q[3L] * q[1L]
stopifnot(is.finite(disc), disc > 0, abs(q[3L]) > .Machine$double.eps)

roots <- sort(c(
  (-q[2L] - sqrt(disc)) / (2 * q[3L]),
  (-q[2L] + sqrt(disc)) / (2 * q[3L])
))

accepts_zero <- as.numeric(q[1L] <= 0)
unbounded <- as.numeric(q[3L] < 0)

estimates <- list(
  list(term = "boundary_low", estimate = roots[1L], se = NULL, n_obs = n),
  list(term = "boundary_high", estimate = roots[2L], se = NULL, n_obs = n),
  list(term = "accepts_zero", estimate = accepts_zero, se = NULL, n_obs = n),
  list(term = "unbounded", estimate = unbounded, se = NULL, n_obs = n),
  list(term = "ar_f_at_one", estimate = f_at(1), se = NULL, n_obs = n)
)

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "Anderson-Rubin confidence set by exact quadratic inversion",
    vcov = "Conventional homoskedastic joint F test"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = NA)
