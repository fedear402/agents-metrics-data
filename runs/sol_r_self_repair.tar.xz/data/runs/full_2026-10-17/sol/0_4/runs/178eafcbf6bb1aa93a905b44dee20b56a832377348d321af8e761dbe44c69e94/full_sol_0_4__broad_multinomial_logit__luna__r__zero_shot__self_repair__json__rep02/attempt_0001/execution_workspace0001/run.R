data <- read.csv("input.csv")
stopifnot(all(c("y", "x", "z") %in% names(data)))
stopifnot(nrow(data) == 480L, !anyNA(data[, c("y", "x", "z")]))
stopifnot(all(data$y %in% 0:2))

X <- model.matrix(~ x + z, data = data)
y <- as.integer(data$y)
n <- nrow(data)
p <- ncol(X)

log_likelihood <- function(theta) {
  B <- matrix(theta, nrow = p, ncol = 2)
  eta <- X %*% B
  m <- pmax(0, eta[, 1], eta[, 2])
  log_denom <- m + log(exp(-m) + exp(eta[, 1] - m) + exp(eta[, 2] - m))
  sum((y == 1L) * eta[, 1] + (y == 2L) * eta[, 2] - log_denom)
}

score <- function(theta) {
  B <- matrix(theta, nrow = p, ncol = 2)
  eta <- X %*% B
  m <- pmax(0, eta[, 1], eta[, 2])
  denom <- exp(-m) + exp(eta[, 1] - m) + exp(eta[, 2] - m)
  prob1 <- exp(eta[, 1] - m) / denom
  prob2 <- exp(eta[, 2] - m) / denom
  c(crossprod(X, as.numeric(y == 1L) - prob1),
    crossprod(X, as.numeric(y == 2L) - prob2))
}

fit <- optim(
  rep(0, 2L * p),
  fn = function(theta) -log_likelihood(theta),
  gr = function(theta) -score(theta),
  method = "BFGS",
  control = list(reltol = 1e-12, maxit = 10000L)
)
stopifnot(fit$convergence == 0L)

# The negative Hessian of the log likelihood is the observed information.
B <- matrix(fit$par, nrow = p, ncol = 2,
            dimnames = list(colnames(X), c("1", "2")))
eta <- X %*% B
m <- pmax(0, eta[, 1], eta[, 2])
denom <- exp(-m) + exp(eta[, 1] - m) + exp(eta[, 2] - m)
prob1 <- exp(eta[, 1] - m) / denom
prob2 <- exp(eta[, 2] - m) / denom

weighted_crossprod <- function(weight) crossprod(X, X * weight)
information <- rbind(
  cbind(weighted_crossprod(prob1 * (1 - prob1)),
        weighted_crossprod(-prob1 * prob2)),
  cbind(weighted_crossprod(-prob1 * prob2),
        weighted_crossprod(prob2 * (1 - prob2)))
)
standard_errors <- matrix(
  sqrt(diag(solve(information))),
  nrow = p,
  ncol = 2,
  dimnames = dimnames(B)
)

eta_zero <- B["(Intercept)", ]
m_zero <- max(0, eta_zero)
prob_cat2_zero <- exp(eta_zero["2"] - m_zero) /
  (exp(-m_zero) + sum(exp(eta_zero - m_zero)))

estimate_row <- function(term, estimate, se) {
  list(term = term, estimate = unname(as.numeric(estimate)),
       se = if (is.null(se)) NULL else unname(as.numeric(se)),
       n_obs = n)
}

result <- list(
  task_id = "broad_multinomial_logit",
  platform = "r",
  estimates = list(
    estimate_row("x_cat1", B["x", "1"], standard_errors["x", "1"]),
    estimate_row("z_cat1", B["z", "1"], standard_errors["z", "1"]),
    estimate_row("x_cat2", B["x", "2"], standard_errors["x", "2"]),
    estimate_row("z_cat2", B["z", "2"], standard_errors["z", "2"]),
    estimate_row("prob_cat2_zero", prob_cat2_zero, NULL)
  ),
  method_metadata = list(
    estimator = "Multinomial logit maximum likelihood; outcome 0 is the base",
    vcov = "Inverse observed information"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE,
                     pretty = TRUE, digits = 16, null = "null")
