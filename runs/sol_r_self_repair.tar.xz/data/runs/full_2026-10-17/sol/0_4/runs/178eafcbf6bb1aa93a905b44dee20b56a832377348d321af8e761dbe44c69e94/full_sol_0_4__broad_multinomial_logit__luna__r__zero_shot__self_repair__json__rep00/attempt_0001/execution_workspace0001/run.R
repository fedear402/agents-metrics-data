data <- read.csv("input.csv")
n <- nrow(data)

if (anyNA(data[, c("y", "x", "z")]) ||
    !all(data$y %in% c(0, 1, 2))) {
  stop("Input must contain complete y, x, and z values, with y in {0, 1, 2}.")
}

X <- cbind(1, data$x, data$z)
Y <- cbind(as.numeric(data$y == 1), as.numeric(data$y == 2))

probabilities <- function(beta) {
  eta <- X %*% matrix(beta, nrow = 3)
  scale <- pmax(0, eta[, 1], eta[, 2])
  e1 <- exp(eta[, 1] - scale)
  e2 <- exp(eta[, 2] - scale)
  denominator <- exp(-scale) + e1 + e2
  cbind(e1 / denominator, e2 / denominator)
}

objective <- function(beta) {
  p <- probabilities(beta)
  eta <- X %*% matrix(beta, nrow = 3)
  scale <- pmax(0, eta[, 1], eta[, 2])
  log_denom <- scale + log(exp(-scale) +
                             exp(eta[, 1] - scale) +
                             exp(eta[, 2] - scale))
  -sum(rowSums(Y * eta) - log_denom)
}

gradient <- function(beta) {
  p <- probabilities(beta)
  as.vector(crossprod(X, p - Y))
}

fit <- optim(rep(0, 6), objective, gradient, method = "BFGS",
             control = list(reltol = 1e-12, maxit = 10000))
if (fit$convergence != 0) stop("Optimization did not converge.")

p <- probabilities(fit$par)
information <- matrix(0, 6, 6)
for (i in seq_len(n)) {
  xi <- X[i, ]
  weights <- diag(p[i, ]) - tcrossprod(p[i, ])
  information <- information + kronecker(weights, tcrossprod(xi))
}
se <- sqrt(diag(solve(information)))

eta_zero <- c(fit$par[1], fit$par[4])
scale_zero <- max(0, eta_zero)
prob_cat2_zero <- exp(eta_zero[2] - scale_zero) /
  (exp(-scale_zero) + sum(exp(eta_zero - scale_zero)))

terms <- c("x_cat1", "z_cat1", "x_cat2", "z_cat2",
           "prob_cat2_zero")
indices <- c(2, 3, 5, 6)
estimates <- lapply(seq_along(terms), function(j) {
  list(
    term = terms[j],
    estimate = if (j <= 4) unname(fit$par[indices[j]]) else
      unname(prob_cat2_zero),
    se = if (j <= 4) unname(se[indices[j]]) else NULL,
    n_obs = n
  )
})

result <- list(
  task_id = "broad_multinomial_logit",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "Multinomial logit maximum likelihood; outcome 0 base",
    vcov = "Inverse observed information"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE,
                     null = "null", digits = NA)
