data <- read.csv("./input.csv", stringsAsFactors = FALSE)
data <- data[complete.cases(data[, c("group", "y")]), ]
data$group <- factor(data$group)
data$y <- as.numeric(data$y)

fit <- aov(y ~ group, data = data)
table <- summary(fit)[[1]]
n_obs <- nobs(fit)

values <- c(
  F = table["group", "F value"],
  df_num = table["group", "Df"],
  df_den = table["Residuals", "Df"],
  p_value = table["group", "Pr(>F)"]
)

estimates <- lapply(names(values), function(term) {
  list(
    term = term,
    estimate = unname(as.numeric(values[term])),
    se = NULL,
    n_obs = as.integer(n_obs)
  )
})

result <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "One-way ANOVA",
    vcov = "Classical homoskedastic"
  ),
  diagnostics = list()
)

jsonlite::write_json(
  result,
  path = "result.json",
  auto_unbox = TRUE,
  digits = NA,
  pretty = TRUE,
  null = "null"
)
