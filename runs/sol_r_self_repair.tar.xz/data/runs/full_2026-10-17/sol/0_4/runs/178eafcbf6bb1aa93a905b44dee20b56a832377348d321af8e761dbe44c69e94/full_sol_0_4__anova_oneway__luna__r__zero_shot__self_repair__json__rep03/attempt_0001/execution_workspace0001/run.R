data <- read.csv("./input.csv", stringsAsFactors = FALSE)
data <- data[complete.cases(data[, c("group", "y")]), c("group", "y")]
data$group <- factor(data$group)

fit <- aov(y ~ group, data = data)
anova_table <- summary(fit)[[1]]
values <- c(
  F = anova_table["group", "F value"],
  df_num = anova_table["group", "Df"],
  df_den = anova_table["Residuals", "Df"],
  p_value = anova_table["group", "Pr(>F)"]
)

n_obs <- nobs(fit)
estimates <- lapply(names(values), function(term) {
  list(term = term, estimate = unname(as.numeric(values[term])),
       se = NULL, n_obs = as.integer(n_obs))
})

result <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = estimates,
  method_metadata = list(estimator = "One-way ANOVA", vcov = "Classical"),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = NA)
