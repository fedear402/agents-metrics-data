library(jsonlite)

data <- read.csv("input.csv", stringsAsFactors = FALSE)

regions <- data[!duplicated(data$region_id), ]
industries <- data[!duplicated(data$industry_id), ]

r <- match(data$region_id, regions$region_id)
n <- match(data$industry_id, industries$industry_id)
R <- nrow(regions)
N <- nrow(industries)

shares <- matrix(0, R, N)
shares[cbind(r, n)] <- data$share

e <- regions$region_weight / sum(regions$region_weight)
shock <- industries$shock
z <- drop(shares %*% shock)

center <- function(v) v - sum(e * v)
y0 <- center(regions$y)
x0 <- center(regions$x)
z0 <- center(z)

s <- drop(crossprod(e, shares))
aggregate_exposure <- function(v) drop(crossprod(shares, e * v)) / s

ybar <- aggregate_exposure(y0)
xbar <- aggregate_exposure(x0)
zbar <- aggregate_exposure(z0)

shock_iv <- function(dependent, endogenous) {
  X <- cbind(1, endogenous)
  Z <- cbind(1, shock)
  cross <- crossprod(Z, s * X)
  beta <- solve(cross, crossprod(Z, s * dependent))
  residual <- drop(dependent - X %*% beta)
  scores <- Z * (s * residual)
  inverse <- solve(cross)
  vcov <- (N / (N - 2)) * inverse %*%
    crossprod(scores) %*% t(inverse)
  c(estimate = unname(beta[2]), se = sqrt(vcov[2, 2]))
}

effect <- shock_iv(ybar, xbar)
first_stage <- shock_iv(xbar, zbar)

row <- function(term, estimate, se) {
  list(
    term = term,
    estimate = unname(as.numeric(estimate)),
    se = if (is.null(se)) NULL else unname(as.numeric(se)),
    n_obs = as.integer(N)
  )
}

write_json(
  list(
    task_id = "applied_shift_share",
    platform = "r",
    estimates = list(
      row("effect", effect["estimate"], effect["se"]),
      row("first_stage", first_stage["estimate"], first_stage["se"]),
      row("effective_shocks", 1 / sum(s^2), NULL)
    ),
    method_metadata = list(
      estimator = "Weighted shift-share 2SLS via shock-level IV aggregation",
      vcov = "Shock-level heteroskedasticity-robust HC1, N/(N-2)"
    ),
    diagnostics = list()
  ),
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
