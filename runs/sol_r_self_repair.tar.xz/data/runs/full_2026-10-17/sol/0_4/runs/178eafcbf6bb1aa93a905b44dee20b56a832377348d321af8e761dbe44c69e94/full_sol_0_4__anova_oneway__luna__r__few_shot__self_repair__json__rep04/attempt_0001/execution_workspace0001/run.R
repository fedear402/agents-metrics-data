library(jsonlite)

dat <- read.csv("./input.csv")
dat <- dat[complete.cases(dat[, c("group", "y")]), ]
dat$group <- factor(dat$group)

fit <- aov(y ~ group, data = dat)
anova_table <- summary(fit)[[1]]
n <- nrow(dat)

out <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = list(
    list(term = "F", estimate = unname(anova_table[1, "F value"]), se = NA_real_, n_obs = n),
    list(term = "df_num", estimate = unname(anova_table[1, "Df"]), se = NA_real_, n_obs = n),
    list(term = "df_den", estimate = unname(anova_table[2, "Df"]), se = NA_real_, n_obs = n),
    list(term = "p_value", estimate = unname(anova_table[1, "Pr(>F)"]), se = NA_real_, n_obs = n)
  ),
  method_metadata = list(estimator = "One-way ANOVA", vcov = "classical"),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "result.json", auto_unbox = TRUE, digits = NA, na = "null")
