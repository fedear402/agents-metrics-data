library(jsonlite)

d <- read.csv("input.csv")
d <- d[is.finite(d$score) & abs(d$score) < 1 &
         is.finite(d$earnings) & is.finite(d$participated), ]

x <- d$score
right <- as.numeric(x >= 0)
w <- 1 - abs(x)
X <- cbind(left_intercept = 1 - right,
           right_intercept = right,
           left_slope = x * (1 - right),
           right_slope = x * right)
Y <- cbind(d$earnings, d$participated)

bread <- solve(crossprod(X, w * X))
beta <- bread %*% crossprod(X, w * Y)
residuals <- Y - X %*% beta
contrast <- c(-1, 1, 0, 0)
jumps <- drop(contrast %*% beta)

loading <- w * drop(X %*% bread %*% contrast)
influence <- residuals * loading
joint <- crossprod(influence)

effect <- jumps[1] / jumps[2]
gradient <- c(1 / jumps[2], -jumps[1] / jumps[2]^2)
effect_se <- sqrt(drop(t(gradient) %*% joint %*% gradient))

row <- function(term, estimate, se, n) {
  list(term = term, estimate = unname(as.numeric(estimate)),
       se = unname(as.numeric(se)), n_obs = as.integer(n))
}

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    row("treatment_effect", effect, effect_se, nrow(d)),
    row("reduced_form", jumps[1], sqrt(joint[1, 1]), nrow(d)),
    row("first_stage", jumps[2], sqrt(joint[2, 2]), nrow(d))
  ),
  method_metadata = list(
    estimator = "Triangular-weighted local-linear fuzzy regression discontinuity",
    vcov = "HC0 joint sandwich covariance; delta method for ratio"
  ),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null",
           digits = 16, pretty = TRUE)
