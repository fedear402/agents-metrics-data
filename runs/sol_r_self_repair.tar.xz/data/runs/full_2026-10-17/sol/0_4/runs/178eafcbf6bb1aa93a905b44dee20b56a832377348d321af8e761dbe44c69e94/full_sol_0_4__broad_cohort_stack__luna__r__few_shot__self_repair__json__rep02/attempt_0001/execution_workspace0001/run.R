d <- read.csv("input.csv")

cohorts <- c(3, 5, 7)
fits <- lapply(cohorts, function(c) {
  window <- (c - 2):(c + 2)
  x <- d[d$time %in% window &
           (d$g == c | d$g == 0 | d$g > c + 2), ]

  complete_ids <- names(which(table(x$id) == length(window)))
  x <- x[as.character(x$id) %in% complete_ids, ]
  x$did <- as.integer(x$g == c & x$time >= c)

  list(
    estimate = unname(coef(lm(y ~ did + factor(id) + factor(time), data = x))["did"]),
    n_obs = nrow(x),
    treated_units = length(unique(x$id[x$g == c]))
  )
})

estimates <- vapply(fits, `[[`, numeric(1), "estimate")
row_counts <- vapply(fits, `[[`, integer(1), "n_obs")
weights <- vapply(fits, `[[`, integer(1), "treated_units")

rows <- lapply(seq_along(cohorts), function(i) {
  list(
    term = paste0("att_g", cohorts[i]),
    estimate = estimates[i],
    se = NULL,
    n_obs = row_counts[i]
  )
})
rows[[4]] <- list(
  term = "att_weighted",
  estimate = weighted.mean(estimates, weights),
  se = NULL,
  n_obs = sum(row_counts)
)

out <- list(
  task_id = "broad_cohort_stack",
  platform = "r",
  estimates = rows,
  method_metadata = list(),
  diagnostics = list()
)

jsonlite::write_json(
  out, "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16
)
