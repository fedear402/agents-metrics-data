dat <- read.csv("input.csv")

keep <- complete.cases(dat[, c("score", "participated", "earnings")]) &
  abs(dat$score) < 1
dat <- dat[keep, ]
n <- nrow(dat)

right <- as.numeric(dat$score >= 0)
X <- cbind(1, right, dat$score, right * dat$score)
w <- 1 - abs(dat$score)
Y <- cbind(dat$earnings, dat$participated)

bread <- solve(crossprod(X, w * X))
beta <- bread %*% crossprod(X, w * Y)
resid <- Y - X %*% beta

# HC0 covariance, including covariance across the two outcome equations.
influence <- sweep(X, 1, w, "*") %*% bread[, 2]
rf <- beta[2, 1]
fs <- beta[2, 2]
v_rf <- sum((influence * resid[, 1])^2)
v_fs <- sum((influence * resid[, 2])^2)
cov_rf_fs <- sum(influence^2 * resid[, 1] * resid[, 2])

effect <- rf / fs
v_effect <- v_rf / fs^2 + rf^2 * v_fs / fs^4 -
  2 * rf * cov_rf_fs / fs^3

num <- function(x) {
  if (is.finite(x)) sprintf("%.15g", x) else "null"
}

out <- sprintf(
  paste0(
    '{"task_id":"applied_fuzzy_rd","platform":"r","estimates":[',
    '{"term":"treatment_effect","estimate":%s,"se":%s,"n_obs":%d},',
    '{"term":"reduced_form","estimate":%s,"se":%s,"n_obs":%d},',
    '{"term":"first_stage","estimate":%s,"se":%s,"n_obs":%d}',
    '],"method_metadata":{"estimator":"fuzzy local-linear regression discontinuity, triangular weights, bandwidth 1",',
    '"vcov":"joint heteroskedasticity-robust HC0; delta method for ratio"},',
    '"diagnostics":{}}'
  ),
  num(effect), num(sqrt(max(0, v_effect))), n,
  num(rf), num(sqrt(v_rf)), n,
  num(fs), num(sqrt(v_fs)), n
)

writeLines(out, "result.json")
