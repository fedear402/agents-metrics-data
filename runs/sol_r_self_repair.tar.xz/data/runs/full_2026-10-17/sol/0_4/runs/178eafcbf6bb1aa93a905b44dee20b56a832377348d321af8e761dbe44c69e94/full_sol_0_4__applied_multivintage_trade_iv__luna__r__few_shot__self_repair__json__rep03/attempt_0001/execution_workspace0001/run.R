crosswalk <- read.csv("crosswalk.csv")
trade <- read.csv("trade.csv")
areas <- read.csv("areas.csv")
employment <- read.csv("employment.csv")
outcomes <- read.csv("outcomes.csv")

trade <- merge(trade, crosswalk, by = "code", sort = FALSE)

# Complete omitted area-industry cells with zero.
area_keys <- areas[c("area", "period", "vintage")]
industries <- unique(crosswalk["industry"])
cells <- merge(area_keys, industries, by = NULL)
cells <- merge(
  cells, employment, by = c("area", "period", "vintage", "industry"),
  all.x = TRUE, sort = FALSE
)
cells$employment[is.na(cells$employment)] <- 0

national <- aggregate(
  employment ~ period + vintage + industry, cells, sum
)
names(national)[names(national) == "employment"] <- "national_employment"
cells <- merge(
  cells, national, by = c("period", "vintage", "industry"),
  sort = FALSE
)
cells <- merge(
  cells, areas, by = c("area", "period", "vintage"), sort = FALSE
)
cells <- merge(
  cells, trade, by = c("period", "industry"), sort = FALSE
)

cells$component <- with(cells, ifelse(
  vintage == "base",
  (employment / total_employment) *
    (us_change / national_employment) /
    (price_index / 100) / 1000 * (10 / years),
  (employment / total_employment) *
    (other_change / national_employment) /
    (price_index / 100) / 1000 * (10 / years)
))

exposures <- aggregate(
  component ~ area + period + vintage, cells, sum
)
wide <- reshape(
  exposures, idvar = c("area", "period"), timevar = "vintage",
  direction = "wide"
)
names(wide)[names(wide) == "component.base"] <- "x"
names(wide)[names(wide) == "component.early"] <- "z"

base_areas <- areas[areas$vintage == "base",
                    c("area", "period", "population")]
d <- merge(outcomes, wide, by = c("area", "period"), sort = FALSE)
d <- merge(d, base_areas, by = c("area", "period"), sort = FALSE)

C <- model.matrix(~ period + control, data = d)
sw <- sqrt(d$population)
X <- cbind(C, x = d$x) * sw
Z <- cbind(C, z = d$z) * sw
fitted_X <- qr.fitted(qr(Z), X)
iv_slope <- unname(qr.coef(qr(fitted_X), d$change_pp * sw)["x"])

lookup <- function(column, period_value) {
  value <- d[d$area == 0 & as.character(d$period) == period_value, column]
  stopifnot(length(value) == 1L)
  unname(value)
}

values <- c(
  iv_slope = iv_slope,
  exposure_area0_period0 = lookup("x", "0"),
  exposure_area0_period1 = lookup("x", "1"),
  instrument_area0_period0 = lookup("z", "0")
)
stopifnot(nrow(d) == 72L, all(is.finite(values)))

estimates <- lapply(names(values), function(term) {
  list(term = term, estimate = unname(values[[term]]),
       se = NULL, n_obs = 72L)
})

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "weighted 2SLS",
    outcome = "change_pp",
    endogenous_regressor = "x",
    excluded_instrument = "z",
    exogenous_regressors = c("intercept", "period", "control"),
    weight = "base-vintage population",
    exposure_units = "thousands of real dollars per worker per decade"
  ),
  diagnostics = list(n_obs = 72L)
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE,
                     pretty = TRUE, digits = NA, null = "null")
