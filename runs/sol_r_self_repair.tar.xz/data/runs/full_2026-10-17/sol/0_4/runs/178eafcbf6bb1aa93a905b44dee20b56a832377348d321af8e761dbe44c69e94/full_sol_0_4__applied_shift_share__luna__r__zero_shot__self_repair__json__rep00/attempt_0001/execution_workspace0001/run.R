d <- read.csv("input.csv", stringsAsFactors = FALSE)
regions <- unique(d$region_id)
industries <- unique(d$industry_id)
r <- match(d$region_id, regions)
n <- match(d$industry_id, industries)
R <- length(regions)
N <- length(industries)

region_value <- function(v) v[match(regions, d$region_id)]
shock <- d$shock[match(industries, d$industry_id)]
e <- region_value(d$region_weight)
e <- e / sum(e)
x <- region_value(d$x)
y <- region_value(d$y)

z <- as.numeric(rowsum(d$share * shock[n], r, reorder = TRUE))
center <- function(v) v - sum(e * v)
x0 <- center(x)
y0 <- center(y)
z0 <- center(z)

exposure <- e[r] * d$share
s <- as.numeric(rowsum(exposure, n, reorder = TRUE))
aggregate_residual <- function(v0) {
  as.numeric(rowsum(exposure * v0[r], n, reorder = TRUE)) / s
}
xbar <- aggregate_residual(x0)
ybar <- aggregate_residual(y0)
zbar <- aggregate_residual(z0)

shock_iv <- function(outcome, endogenous) {
  X <- cbind(1, endogenous)
  Z <- cbind(1, shock)
  WZ <- Z * s
  cross <- crossprod(WZ, X)
  beta <- solve(cross, crossprod(WZ, outcome))
  u <- as.numeric(outcome - X %*% beta)
  meat <- crossprod(Z * (s * u))
  bread <- solve(cross)
  vcov <- (N / (N - 2)) * bread %*% meat %*% t(bread)
  c(estimate = unname(beta[2]), se = sqrt(vcov[2, 2]))
}

effect <- shock_iv(ybar, xbar)
first_stage <- shock_iv(xbar, zbar)
effective_shocks <- 1 / sum(s^2)

num <- function(v) sprintf("%.17g", v)
row_json <- function(term, estimate, se = NULL) {
  se_json <- if (is.null(se)) "null" else num(se)
  sprintf(
    '{"term":"%s","estimate":%s,"se":%s,"n_obs":%d}',
    term, num(estimate), se_json, N
  )
}

result <- paste0(
  '{"task_id":"applied_shift_share","platform":"r","estimates":[',
  paste(
    row_json("effect", effect["estimate"], effect["se"]),
    row_json("first_stage", first_stage["estimate"], first_stage["se"]),
    row_json("effective_shocks", effective_shocks),
    sep = ","
  ),
  '],"method_metadata":{"estimator":"weighted 2SLS with BHJ shock-level aggregation",',
  '"vcov":"shock-level HC1, structural IV residuals, analytic weights, N/(N-2)"},',
  '"diagnostics":{}}'
)
writeLines(result, "result.json")
