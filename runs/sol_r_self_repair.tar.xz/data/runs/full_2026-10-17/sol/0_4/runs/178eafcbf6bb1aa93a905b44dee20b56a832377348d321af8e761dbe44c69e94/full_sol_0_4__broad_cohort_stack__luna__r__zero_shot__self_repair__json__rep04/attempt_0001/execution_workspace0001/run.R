library(jsonlite)

data <- read.csv("input.csv")
cohorts <- c(3, 5, 7)

compare_cohort <- function(c) {
  window <- (c - 2):(c + 2)
  eligible <- data$g == c | data$g == 0 | data$g > c + 2
  subset <- data[eligible & data$time %in% window, ]

  counts <- table(subset$id)
  balanced_ids <- names(counts[counts == length(window)])
  subset <- subset[as.character(subset$id) %in% balanced_ids, ]

  subset$did <- as.integer(subset$g == c & subset$time >= c)
  fit <- lm(y ~ did + factor(id) + factor(time), data = subset)

  list(
    estimate = unname(coef(fit)[["did"]]),
    n_obs = nrow(subset),
    n_treated = length(unique(subset$id[subset$g == c]))
  )
}

results <- lapply(cohorts, compare_cohort)
treated_counts <- vapply(results, `[[`, numeric(1), "n_treated")
estimates <- vapply(results, `[[`, numeric(1), "estimate")
row_counts <- vapply(results, `[[`, integer(1), "n_obs")

entries <- lapply(seq_along(cohorts), function(i) {
  list(
    term = paste0("att_g", cohorts[i]),
    estimate = estimates[i],
    se = NULL,
    n_obs = row_counts[i]
  )
})

entries[[4]] <- list(
  term = "att_weighted",
  estimate = weighted.mean(estimates, treated_counts),
  se = NULL,
  n_obs = sum(row_counts)
)

output <- list(
  task_id = "broad_cohort_stack",
  platform = "r",
  estimates = entries,
  method_metadata = list(),
  diagnostics = list()
)

write_json(output, "result.json", auto_unbox = TRUE, digits = NA)
