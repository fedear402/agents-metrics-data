d <- read.csv("input.csv")

cohorts <- c(3, 5, 7)
results <- lapply(cohorts, function(c) {
  window <- (c - 2):(c + 2)
  x <- d[
    d$time %in% window &
      (d$g == c | d$g == 0 | d$g > c + 2),
  ]

  counts <- table(x$id)
  balanced_ids <- names(counts[counts == length(window)])
  x <- x[as.character(x$id) %in% balanced_ids, ]
  x$did <- as.integer(x$g == c & x$time >= c)

  fit <- lm(y ~ did + factor(id) + factor(time), data = x)
  list(
    estimate = unname(coef(fit)[["did"]]),
    n_obs = nrow(x),
    treated_units = length(unique(x$id[x$g == c]))
  )
})

estimates <- vapply(results, `[[`, numeric(1), "estimate")
row_counts <- vapply(results, `[[`, integer(1), "n_obs")
weights <- vapply(results, `[[`, integer(1), "treated_units")

out <- list(
  task_id = "broad_cohort_stack",
  platform = "r",
  estimates = list(
    list(term = "att_g3", estimate = estimates[1], se = NULL, n_obs = row_counts[1]),
    list(term = "att_g5", estimate = estimates[2], se = NULL, n_obs = row_counts[2]),
    list(term = "att_g7", estimate = estimates[3], se = NULL, n_obs = row_counts[3]),
    list(
      term = "att_weighted",
      estimate = weighted.mean(estimates, weights),
      se = NULL,
      n_obs = sum(row_counts)
    )
  ),
  method_metadata = list(),
  diagnostics = list()
)

jsonlite::write_json(out, "result.json", auto_unbox = TRUE, null = "null", digits = 16)
