library(jsonlite)

crosswalk <- read.csv("crosswalk.csv")
trade <- read.csv("trade.csv")
areas <- read.csv("areas.csv")
employment <- read.csv("employment.csv")
outcomes <- read.csv("outcomes.csv")

trade <- merge(trade, crosswalk, by = "code")
industries <- unique(crosswalk$industry)

make_exposure <- function(vintage, change_column) {
  a <- areas[areas$vintage == vintage, ]
  e <- employment[employment$vintage == vintage, ]

  grid <- merge(
    a[c("area", "period", "total_employment")],
    data.frame(industry = industries)
  )
  grid <- merge(
    grid, e[c("area", "period", "industry", "employment")],
    by = c("area", "period", "industry"), all.x = TRUE
  )
  grid$employment[is.na(grid$employment)] <- 0

  national <- aggregate(
    employment ~ period + industry, grid, sum
  )
  names(national)[names(national) == "employment"] <- "national_employment"
  grid <- merge(grid, national, by = c("period", "industry"))
  grid <- merge(
    grid, trade[c("period", "industry", change_column, "price_index", "years")],
    by = c("period", "industry")
  )

  grid$contribution <-
    (grid$employment / grid$total_employment) *
    (grid[[change_column]] / grid$national_employment) /
    (grid$price_index / 100) / 1000 *
    (10 / grid$years)

  aggregate(contribution ~ area + period, grid, sum)
}

x <- make_exposure("base", "us_change")
z <- make_exposure("early", "other_change")
names(x)[3] <- "x"
names(z)[3] <- "z"

base_areas <- areas[
  areas$vintage == "base",
  c("area", "period", "population")
]
dat <- Reduce(
  function(left, right) merge(left, right, by = c("area", "period")),
  list(outcomes, base_areas, x, z)
)
stopifnot(nrow(dat) == 72L)

period_design <- model.matrix(~ period, data = dat)
stopifnot(ncol(period_design) == 2L)
exogenous <- cbind(
  intercept = 1,
  period = period_design[, 2],
  control = dat$control
)
regressors <- cbind(exogenous, x = dat$x)
instruments <- cbind(exogenous, z = dat$z)

w <- dat$population
weighted_cross <- function(left, right) crossprod(left, w * right)
zx <- weighted_cross(instruments, regressors)
zz <- weighted_cross(instruments, instruments)
zy <- crossprod(instruments, w * dat$change_pp)

beta <- solve(
  t(zx) %*% solve(zz, zx),
  t(zx) %*% solve(zz, zy)
)

lookup <- function(column, area_value, period_value) {
  value <- dat[
    as.character(dat$area) == as.character(area_value) &
      as.character(dat$period) == as.character(period_value),
    column
  ]
  stopifnot(length(value) == 1L)
  unname(value)
}

terms <- c(
  "iv_slope",
  "exposure_area0_period0",
  "exposure_area0_period1",
  "instrument_area0_period0"
)
values <- c(
  unname(beta["x", 1]),
  lookup("x", 0, 0),
  lookup("x", 0, 1),
  lookup("z", 0, 0)
)
estimates <- lapply(seq_along(terms), function(i) {
  list(term = terms[i], estimate = values[i], se = NULL, n_obs = 72L)
})

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "weighted 2SLS",
    outcome = "change_pp",
    endogenous_regressor = "x",
    excluded_instrument = "z",
    exogenous_regressors = c("intercept", "period", "control"),
    weight = "base-vintage population",
    exposure_units = "thousands of real dollars per worker per decade"
  ),
  diagnostics = list(n_obs = 72L)
)

jsonlite::write_json(
  result, "result.json", auto_unbox = TRUE, null = "null", digits = NA
)
