dat <- read.csv("./input.csv", stringsAsFactors = FALSE)
dat <- dat[order(dat$t), ]

y <- as.numeric(dat$y)
if (anyNA(y)) stop("Column y must contain numeric values without missing observations.")
if (anyDuplicated(dat$t)) stop("Column t contains duplicate values.")
if (tail(dat$t, 1) != 250) stop("The final observed period must be t = 250.")

fit <- stats::arima(
  y,
  order = c(1, 1, 1),
  include.mean = FALSE,
  method = "ML"
)

pred <- stats::predict(fit, n.ahead = 1)
forecast <- as.numeric(pred$pred[1])
se <- as.numeric(pred$se[1])
critical <- stats::qnorm(0.975)

result <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = list(
    list(term = "forecast", estimate = forecast, se = se, n_obs = length(y)),
    list(term = "lower_95", estimate = forecast - critical * se, se = NULL, n_obs = length(y)),
    list(term = "upper_95", estimate = forecast + critical * se, se = NULL, n_obs = length(y))
  ),
  method_metadata = list(
    estimator = "ARIMA(1,1,1) maximum likelihood, no constant or drift",
    vcov = "Model-based one-step-ahead prediction variance"
  ),
  diagnostics = list()
)

jsonlite::write_json(
  result,
  path = "result.json",
  auto_unbox = TRUE,
  digits = NA,
  null = "null"
)
