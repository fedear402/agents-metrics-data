clear all
set more off
set linesize 255

import delimited using "input.csv", clear varnames(1)

scalar n_obs = _N
scalar crit = invFtail(2, n_obs - 4, 0.05)

mata:
y  = st_data(., "y")
en = st_data(., "endog")
x  = st_data(., "x")
z  = st_data(., ("z1", "z2"))
n  = rows(y)
X  = (J(n, 1, 1), x)
MX = I(n) - X * invsym(X' * X) * X'
u  = MX * y
d  = MX * en
Z  = MX * z
P  = Z * invsym(Z' * Z) * Z'
M  = I(n) - P
Ruu = u' * M * u
Rud = u' * M * d
Rdd = d' * M * d
Puu = u' * P * u
Pud = u' * P * d
Pdd = d' * P * d
c  = st_numscalar("crit")
k  = (n - 4) / 2
A  = k * Pdd - c * Rdd
B  = -2 * k * Pud + 2 * c * Rud
C  = k * Puu - c * Ruu
disc = B^2 - 4 * A * C
lo = .
hi = .
if (A > 0 & disc >= 0) {
    r1 = (-B - sqrt(disc)) / (2 * A)
    r2 = (-B + sqrt(disc)) / (2 * A)
    lo = r1
    hi = r2
}
if (A < 0 & disc >= 0) {
    r1 = (-B - sqrt(disc)) / (2 * A)
    r2 = (-B + sqrt(disc)) / (2 * A)
    lo = r1
    hi = r2
    if (r2 < r1) {
        lo = r2
        hi = r1
    }
}
st_numscalar("b_low", lo)
st_numscalar("b_high", hi)
st_numscalar("a_coef", A)
st_numscalar("c_coef", C)
st_numscalar("f_one", ((Puu - 2 * Pud + Pdd) / 2) / ((Ruu - 2 * Rud + Rdd) / (n - 4)))
end
mata

scalar accepts_zero = (c_coef <= 0)
scalar unbounded    = (a_coef <= 0)

display "ANSWER: boundary_low estimate=" %21.12f b_low " se=. n_obs=" %12.0f n_obs
display "ANSWER: boundary_high estimate=" %21.12f b_high " se=. n_obs=" %12.0f n_obs
display "ANSWER: accepts_zero estimate=" %21.12f accepts_zero " se=. n_obs=" %12.0f n_obs
display "ANSWER: unbounded estimate=" %21.12f unbounded " se=. n_obs=" %12.0f n_obs
display "ANSWER: ar_f_at_one estimate=" %21.12f f_one " se=. n_obs=" %12.0f n_obs
