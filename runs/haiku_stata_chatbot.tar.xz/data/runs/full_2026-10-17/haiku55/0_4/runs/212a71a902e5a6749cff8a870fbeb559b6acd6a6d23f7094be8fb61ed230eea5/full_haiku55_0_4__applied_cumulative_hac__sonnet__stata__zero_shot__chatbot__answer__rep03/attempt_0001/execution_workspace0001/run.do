set linesize 255
clear all
import delimited using "input.csv", clear

capture confirm string variable date
if _rc == 0 {
    gen double dt = date(date, "YMD")
}
else {
    gen double dt = date
}
sort dt

gen double lnsales = ln(sales)
gen double lnvix = ln(vix)
gen double dlv = lnvix - lnvix[_n-1]

gen long t = _n
tsset t

forvalues j = 1/15 {
    gen double l`j' = L`j'.dlv
}

egen nmiss = rowmiss(l1-l15)
gen byte touse = (nmiss == 0) & !missing(lnsales)

newey lnsales l1-l15 if touse == 1, lag(15) small

scalar n_obs = e(N)

lincom l1+l2+l3+l4+l5+l6+l7+l8+l9+l10+l11+l12+l13+l14+l15
scalar cum_b  = r(estimate)
scalar cum_se = r(se)

scalar b1  = _b[l1]
scalar se1 = _se[l1]

scalar b15  = _b[l15]
scalar se15 = _se[l15]

display "ANSWER: cumulative_response estimate=" %21.12f cum_b " se=" %21.12f cum_se " n_obs=" %12.0f n_obs
display "ANSWER: lag_1 estimate=" %21.12f b1 " se=" %21.12f se1 " n_obs=" %12.0f n_obs
display "ANSWER: lag_15 estimate=" %21.12f b15 " se=" %21.12f se15 " n_obs=" %12.0f n_obs
