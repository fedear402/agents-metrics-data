clear all
set more off
set type double

import delimited using "input.csv", clear varnames(1)
tempfile base
save `base'

local cohorts 3 5 7
foreach c of local cohorts {
    use `base', clear
    keep if inrange(time, `c'-2, `c'+2)
    keep if g==`c' | g==0 | g>`c'+2
    bysort id: gen byte nwin = _N
    keep if nwin==5
    gen byte did = (g==`c' & time>=`c')

    quietly levelsof id if g==`c', local(tu)
    local ntreated : word count `tu'

    quietly regress y did i.id i.time
    scalar att`c' = _b[did]
    scalar n`c' = e(N)
    scalar w`c' = `ntreated'
}

scalar attw = (w3*att3 + w5*att5 + w7*att7) / (w3 + w5 + w7)
scalar nw = n3 + n5 + n7

display "ANSWER: att_g3 estimate=" %24.16g att3 " se=null n_obs=" %12.0f n3
display "ANSWER: att_g5 estimate=" %24.16g att5 " se=null n_obs=" %12.0f n5
display "ANSWER: att_g7 estimate=" %24.16g att7 " se=null n_obs=" %12.0f n7
display "ANSWER: att_weighted estimate=" %24.16g attw " se=null n_obs=" %12.0f nw
exit, clear
