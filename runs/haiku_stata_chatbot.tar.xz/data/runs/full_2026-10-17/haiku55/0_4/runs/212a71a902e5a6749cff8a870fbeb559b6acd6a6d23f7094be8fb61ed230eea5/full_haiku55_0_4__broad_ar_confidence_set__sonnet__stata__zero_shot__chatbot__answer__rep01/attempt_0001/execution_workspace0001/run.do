clear all
set more off
set linesize 255

import delimited using "input.csv", clear

local n_obs = _N

mata:
    X  = st_data(., ("y", "endog", "x", "z1", "z2"))
    y  = X[,1]
    e  = X[,2]
    x  = X[,3]
    z1 = X[,4]
    z2 = X[,5]
    n  = rows(X)

    Z0 = (J(n,1,1), x)
    Z1 = (J(n,1,1), x, z1, z2)
    M0 = I(n) - Z0*invsym(Z0'Z0)*Z0'
    M1 = I(n) - Z1*invsym(Z1'Z1)*Z1'

    Fc = invFtail(2, n-4, 0.05)
    k  = 2*Fc/(n-4)

    nyy = y'(M0-M1)*y
    ney = e'(M0-M1)*y
    nee = e'(M0-M1)*e
    uyy = y'M1*y
    uey = e'M1*y
    uee = e'M1*e

    A = nee - k*uee
    B = -2*(ney - k*uey)
    C = nyy - k*uyy
    disc = B^2 - 4*A*C

    rl = .
    rh = .
    unb = 0
    if (A > 0 & disc > 0) {
        rl = (-B - sqrt(disc))/(2*A)
        rh = (-B + sqrt(disc))/(2*A)
        unb = 0
    }
    else if (A < 0 & disc > 0) {
        r1 = (-B - sqrt(disc))/(2*A)
        r2 = (-B + sqrt(disc))/(2*A)
        rl = min((r1, r2))
        rh = max((r1, r2))
        unb = 1
    }
    else if (A < 0) {
        unb = 1
    }

    acc0 = (C <= 0)

    N1 = nyy - 2*ney + nee
    U1 = uyy - 2*uey + uee
    f1 = (N1/2)/(U1/(n-4))

    st_numscalar("rl", rl)
    st_numscalar("rh", rh)
    st_numscalar("unb", unb)
    st_numscalar("acc0", acc0)
    st_numscalar("f1", f1)
end

display "ANSWER: boundary_low estimate=" %21.12f rl " se=." " n_obs=" %12.0f `n_obs'
display "ANSWER: boundary_high estimate=" %21.12f rh " se=." " n_obs=" %12.0f `n_obs'
display "ANSWER: accepts_zero estimate=" %21.12f acc0 " se=." " n_obs=" %12.0f `n_obs'
display "ANSWER: unbounded estimate=" %21.12f unb " se=." " n_obs=" %12.0f `n_obs'
display "ANSWER: ar_f_at_one estimate=" %21.12f f1 " se=." " n_obs=" %12.0f `n_obs'
