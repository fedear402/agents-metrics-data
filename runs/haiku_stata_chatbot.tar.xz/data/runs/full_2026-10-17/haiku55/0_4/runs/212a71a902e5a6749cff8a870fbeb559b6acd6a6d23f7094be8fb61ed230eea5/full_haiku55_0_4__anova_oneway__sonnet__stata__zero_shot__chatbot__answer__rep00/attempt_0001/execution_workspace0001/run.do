clear all
set more off
set linesize 255

import delimited using "./input.csv", clear varnames(1)

egen grp_id = group(group)
regress y i.grp_id

scalar F_val = e(F)
scalar dfnum_val = e(df_m)
scalar dfden_val = e(df_r)
scalar pval_val = Ftail(dfnum_val, dfden_val, F_val)
scalar nobs_val = e(N)

display "ANSWER: F estimate=" %21.12f F_val " se=." " n_obs=" %12.0f nobs_val
display "ANSWER: df_num estimate=" %21.12f dfnum_val " se=." " n_obs=" %12.0f nobs_val
display "ANSWER: df_den estimate=" %21.12f dfden_val " se=." " n_obs=" %12.0f nobs_val
display "ANSWER: p_value estimate=" %21.12f pval_val " se=." " n_obs=" %12.0f nobs_val
