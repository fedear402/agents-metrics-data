clear all
set more off
set type double

tempfile cw trd ar pop outc

import delimited using "crosswalk.csv", clear varnames(1)
save `cw'

import delimited using "trade.csv", clear varnames(1)
merge m:1 code using `cw', keep(match) nogenerate
keep period industry us_change other_change price_index years
save `trd'

import delimited using "areas.csv", clear varnames(1)
preserve
keep if vintage == "base"
keep area period population
save `pop'
restore
keep area period vintage total_employment
save `ar'

import delimited using "outcomes.csv", clear varnames(1)
keep area period control change_pp
save `outc'

import delimited using "employment.csv", clear varnames(1)
collapse (sum) employment, by(area period vintage industry)
merge m:1 area period vintage using `ar', keep(match) nogenerate
merge m:1 period industry using `trd', keep(match) nogenerate
bysort period vintage industry: egen double nat = total(employment)

gen double tx = employment/total_employment*(us_change/nat)/(price_index/100)/1000*(10/years) if vintage == "base"
gen double tz = employment/total_employment*(other_change/nat)/(price_index/100)/1000*(10/years) if vintage == "early"

collapse (sum) x=tx z=tz, by(area period)
merge 1:1 area period using `outc', keep(match) nogenerate
merge 1:1 area period using `pop', keep(match) nogenerate

local n = _N

ivregress 2sls change_pp period control (x = z) [aw=population]

quietly summarize x if area == 0 & period == 0
scalar ex00 = r(mean)
quietly summarize x if area == 0 & period == 1
scalar ex01 = r(mean)
quietly summarize z if area == 0 & period == 0
scalar iz00 = r(mean)

display "ANSWER: iv_slope estimate=" trim(string(_b[x], "%24.16g")) " se=NA n_obs=" trim(string(`n', "%12.0f"))
display "ANSWER: exposure_area0_period0 estimate=" trim(string(ex00, "%24.16g")) " se=NA n_obs=" trim(string(`n', "%12.0f"))
display "ANSWER: exposure_area0_period1 estimate=" trim(string(ex01, "%24.16g")) " se=NA n_obs=" trim(string(`n', "%12.0f"))
display "ANSWER: instrument_area0_period0 estimate=" trim(string(iz00, "%24.16g")) " se=NA n_obs=" trim(string(`n', "%12.0f"))
