version 19.0
clear all
set more off
set linesize 255

mata:
real rowvector shockiv(real colvector d, real colvector en, real colvector ins, real colvector w)
{
    real scalar N
    real colvector beta, u
    real matrix Xi, Zi, inv_, S, V
    N=rows(d)
    Xi=(J(N,1,1),en)
    Zi=(J(N,1,1),ins)
    inv_=luinv(Zi'*(w:*Xi))
    beta=inv_*Zi'*(w:*d)
    u=d-Xi*beta
    S=Zi:*(w:*u)
    V=N/(N-2)*inv_*(S'*S)*inv_'
    return((beta[2],sqrt(V[2,2])))
}
end

import delimited using "input.csv", clear varnames(1)

gen double sxs = share*shock
bysort region_id: egen double zr = total(sxs)
bysort region_id: egen double yr = mean(y)
bysort region_id: egen double xr = mean(x)
bysort region_id: egen double wr = mean(region_weight)
egen byte tagr = tag(region_id)

preserve
keep if tagr
egen double wsum = total(wr)
gen double e = wr/wsum
foreach v in y x z {
    gen double ew_`v' = e*`v'r
    quietly summarize ew_`v', meanonly
    scalar m_`v' = r(sum)
    gen double `v'0 = `v'r - m_`v'
}
keep region_id e y0 x0 z0
tempfile regs
save `regs'
restore

merge m:1 region_id using `regs', assert(match) nogen

gen double esh = e*share
bysort industry_id: egen double sn = total(esh)
foreach v in y x z {
    gen double num_`v' = esh*`v'0
    bysort industry_id: egen double tot_`v' = total(num_`v')
    gen double vbar_`v' = tot_`v'/sn
}

egen byte tagi = tag(industry_id)
keep if tagi

mata:
d_y=st_data(.,"vbar_y")
d_x=st_data(.,"vbar_x")
d_z=st_data(.,"vbar_z")
ins=st_data(.,"shock")
w=st_data(.,"sn")
eff=shockiv(d_y,d_x,ins,w)
fs=shockiv(d_x,d_z,ins,w)
st_numscalar("effect_b", eff[1])
st_numscalar("effect_se", eff[2])
st_numscalar("fs_b", fs[1])
st_numscalar("fs_se", fs[2])
st_numscalar("eff_shocks", 1/sum(w:^2))
end

display "ANSWER: effect estimate=" %21.12f effect_b " se=" %21.12f effect_se " n_obs=" %12.0f _N
display "ANSWER: first_stage estimate=" %21.12f fs_b " se=" %21.12f fs_se " n_obs=" %12.0f _N
display "ANSWER: effective_shocks estimate=" %21.12f eff_shocks " se=" %21.12f . " n_obs=" %12.0f _N
