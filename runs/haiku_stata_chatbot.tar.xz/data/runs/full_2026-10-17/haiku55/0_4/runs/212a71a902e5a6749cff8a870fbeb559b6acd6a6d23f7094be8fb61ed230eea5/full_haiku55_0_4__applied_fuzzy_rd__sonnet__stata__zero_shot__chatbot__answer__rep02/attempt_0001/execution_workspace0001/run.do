clear all
set more off
set linesize 255

import delimited using "input.csv", clear varnames(1)

keep if abs(score) < 1
gen double w = 1 - abs(score)
gen byte D = (score >= 0)
gen double Ds = D * score
gen double one = 1
scalar n_obs = _N

mata:
real matrix X, XWX, B, Meat_yy, Meat_yp, Meat_pp, Vy, Vp, Cyp
real colvector w, Y, P, by, bp, ey, ep
real scalar dy, dp, Vy22, Vp22, Cyp22, Vtau, tau, se_tau, se_rf, se_fs

X = st_data(., ("one", "D", "score", "Ds"))
w = st_data(., "w")
Y = st_data(., "earnings")
P = st_data(., "participated")

XWX = cross(X, w, X)
B = invsym(XWX)

by = B * cross(X, w, Y)
bp = B * cross(X, w, P)

ey = Y - X * by
ep = P - X * bp

dy = by[2]
dp = bp[2]

Meat_yy = cross(X, w:^2 :* ey:^2, X)
Meat_yp = cross(X, w:^2 :* ey :* ep, X)
Meat_pp = cross(X, w:^2 :* ep:^2, X)

Vy = B * Meat_yy * B
Vp = B * Meat_pp * B
Cyp = B * Meat_yp * B

Vy22 = Vy[2, 2]
Vp22 = Vp[2, 2]
Cyp22 = Cyp[2, 2]

tau = dy / dp
Vtau = (1 / dp^2) * Vy22 + (dy^2 / dp^4) * Vp22 - 2 * (dy / dp^3) * Cyp22
se_tau = sqrt(Vtau)
se_rf = sqrt(Vy22)
se_fs = sqrt(Vp22)

st_numscalar("r_tau", tau)
st_numscalar("r_tau_se", se_tau)
st_numscalar("r_rf", dy)
st_numscalar("r_rf_se", se_rf)
st_numscalar("r_fs", dp)
st_numscalar("r_fs_se", se_fs)
end

display "ANSWER: treatment_effect estimate=" %21.12f r_tau " se=" %21.12f r_tau_se " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f r_rf " se=" %21.12f r_rf_se " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f r_fs " se=" %21.12f r_fs_se " n_obs=" %12.0f n_obs
