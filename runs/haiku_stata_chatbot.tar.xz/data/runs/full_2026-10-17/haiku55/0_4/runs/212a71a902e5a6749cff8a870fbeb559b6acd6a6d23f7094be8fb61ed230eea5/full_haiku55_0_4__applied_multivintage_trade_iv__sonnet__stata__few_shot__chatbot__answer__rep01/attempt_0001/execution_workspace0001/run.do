clear all
set more off
set type double

import delimited using "crosswalk.csv", clear varnames(1)
capture tostring code, replace
capture tostring industry, replace
replace code = trim(code)
replace industry = trim(industry)
bysort code: keep if _n == 1
tempfile xw
save `xw'

import delimited using "trade.csv", clear varnames(1)
capture tostring code, replace
replace code = trim(code)
capture destring period, replace
capture destring us_change, replace
capture destring other_change, replace
capture destring price_index, replace
capture destring years, replace
capture tostring industry, replace
merge m:1 code using `xw', keep(match) nogen
keep period industry us_change other_change price_index years
tempfile trd
save `trd'

import delimited using "areas.csv", clear varnames(1)
capture destring area, replace
capture destring period, replace
capture destring total_employment, replace
capture destring population, replace
replace vintage = trim(vintage)
tempfile ar
save `ar'

use `ar', clear
keep area period vintage total_employment
tempfile aret
save `aret'

use `ar', clear
keep if vintage == "base"
keep area period population
tempfile pop
save `pop'

import delimited using "employment.csv", clear varnames(1)
capture destring area, replace
capture destring period, replace
capture destring employment, replace
capture tostring industry, replace
replace vintage = trim(vintage)
replace industry = trim(industry)
collapse (sum) employment, by(area period vintage industry)

egen double nat = total(employment), by(vintage period industry)
merge m:1 period industry using `trd', keep(match) nogen
merge m:1 area period vintage using `aret', keep(match) nogen

gen double share = employment/total_employment
gen double term = share*(us_change/nat)/(price_index/100)/1000*(10/years) if vintage == "base"
gen double term_z = share*(other_change/nat)/(price_index/100)/1000*(10/years) if vintage == "early"
collapse (sum) x = term z = term_z, by(area period)
tempfile expo
save `expo'

import delimited using "outcomes.csv", clear varnames(1)
capture destring area, replace
capture destring period, replace
capture destring control, replace
capture destring change_pp, replace
merge 1:1 area period using `expo', keep(master match) nogen
replace x = 0 if missing(x)
replace z = 0 if missing(z)
merge 1:1 area period using `pop', keep(master match) nogen

ivregress 2sls change_pp period control (x = z) [aw=population]
scalar iv_b = _b[x]
scalar n_obs = e(N)

summarize x if area == 0 & period == 0, meanonly
scalar ex0 = r(mean)
summarize x if area == 0 & period == 1, meanonly
scalar ex1 = r(mean)
summarize z if area == 0 & period == 0, meanonly
scalar iz0 = r(mean)

display "ANSWER: iv_slope estimate=" trim(string(iv_b, "%24.16g")) " se=NA n_obs=" trim(string(n_obs, "%12.0g"))
display "ANSWER: exposure_area0_period0 estimate=" trim(string(ex0, "%24.16g")) " se=NA n_obs=" trim(string(n_obs, "%12.0g"))
display "ANSWER: exposure_area0_period1 estimate=" trim(string(ex1, "%24.16g")) " se=NA n_obs=" trim(string(n_obs, "%12.0g"))
display "ANSWER: instrument_area0_period0 estimate=" trim(string(iz0, "%24.16g")) " se=NA n_obs=" trim(string(n_obs, "%12.0g"))
exit
