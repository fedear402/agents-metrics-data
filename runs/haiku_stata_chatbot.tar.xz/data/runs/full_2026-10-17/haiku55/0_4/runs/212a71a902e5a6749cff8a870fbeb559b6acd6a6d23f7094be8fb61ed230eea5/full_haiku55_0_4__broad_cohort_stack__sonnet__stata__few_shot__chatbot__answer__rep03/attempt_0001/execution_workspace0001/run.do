clear all
set more off
set type double

import delimited using "input.csv", clear varnames(1)

tempfile base
save `base'

local cohorts 3 5 7
local wsum 0
local wtot 0
local rowsum 0

foreach c of local cohorts {
    use `base', clear
    keep if inrange(time, `c'-2, `c'+2)
    keep if g==`c' | g==0 | g>`c'+2
    bysort id: gen byte nobs = _N
    keep if nobs==5
    levelsof id if g==`c', local(tids)
    local ntr : word count `tids'
    gen byte did = (g==`c' & time>=`c')
    quietly regress y did i.id i.time
    scalar a`c' = _b[did]
    scalar r`c' = e(N)
    scalar n`c' = `ntr'
    local wsum = `wsum' + `ntr'*_b[did]
    local wtot = `wtot' + `ntr'
    local rowsum = `rowsum' + e(N)
}

display "ANSWER: att_g3 estimate=" %24.16g a3 " se=null n_obs=" %12.0f r3
display "ANSWER: att_g5 estimate=" %24.16g a5 " se=null n_obs=" %12.0f r5
display "ANSWER: att_g7 estimate=" %24.16g a7 " se=null n_obs=" %12.0f r7
display "ANSWER: att_weighted estimate=" %24.16g `wsum'/`wtot' " se=null n_obs=" %12.0f `rowsum'

exit, clear
