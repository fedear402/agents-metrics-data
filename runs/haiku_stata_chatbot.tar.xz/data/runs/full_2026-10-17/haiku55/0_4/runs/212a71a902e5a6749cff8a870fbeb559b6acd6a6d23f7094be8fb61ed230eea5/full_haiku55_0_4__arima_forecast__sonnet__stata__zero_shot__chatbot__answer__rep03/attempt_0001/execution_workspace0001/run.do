clear all
set more off
set linesize 255

import delimited using "./input.csv", clear
sort t
tsset t

arima y if t <= 250, arima(1,1,1) noconstant
scalar n_obs = e(N)

predict double fc_pred if t == 251, y
predict double fc_mse if t == 251, mse

summarize fc_pred if t == 251, meanonly
scalar forecast_val = r(mean)
summarize fc_mse if t == 251, meanonly
scalar forecast_se = sqrt(r(mean))

scalar z95 = invnormal(0.975)
scalar lower_val = forecast_val - z95 * forecast_se
scalar upper_val = forecast_val + z95 * forecast_se

display "ANSWER: forecast estimate=" %21.12f forecast_val " se=" %21.12f forecast_se " n_obs=" %12.0f n_obs
display "ANSWER: lower_95 estimate=" %21.12f lower_val " se=" "." " n_obs=" %12.0f n_obs
display "ANSWER: upper_95 estimate=" %21.12f upper_val " se=" "." " n_obs=" %12.0f n_obs
