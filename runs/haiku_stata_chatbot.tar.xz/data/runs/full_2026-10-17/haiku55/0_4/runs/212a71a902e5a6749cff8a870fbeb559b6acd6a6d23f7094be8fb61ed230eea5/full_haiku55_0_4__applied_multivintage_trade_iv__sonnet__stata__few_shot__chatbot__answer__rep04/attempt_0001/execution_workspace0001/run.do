clear all
set more off
set type double

import delimited using "crosswalk.csv", clear varnames(1)
keep code industry
duplicates drop
tempfile xw
save `xw'

import delimited using "trade.csv", clear varnames(1)
merge m:1 code using `xw', keep(match) nogenerate
keep period industry us_change other_change price_index years
duplicates drop period industry, force
tempfile tr
save `tr'

use `xw', clear
keep industry
duplicates drop
gen byte k = 1
tempfile ind
save `ind'

import delimited using "areas.csv", clear varnames(1)
keep area period vintage total_employment population
gen byte k = 1
joinby k using `ind'
tempfile grid
save `grid'

import delimited using "employment.csv", clear varnames(1)
collapse (sum) employment, by(area period vintage industry)
tempfile emp
save `emp'

use `grid', clear
merge 1:1 area period vintage industry using `emp', keep(master match) nogenerate
replace employment = 0 if missing(employment)
merge m:1 period industry using `tr', keep(match) nogenerate

egen double nat = total(employment), by(period vintage industry)
gen double ch = cond(vintage == "base", us_change, other_change)
gen double term = (employment / total_employment) * (ch / nat) / (price_index / 100) / 1000 * (10 / years)
gen double xterm = term if vintage == "base"
gen double zterm = term if vintage == "early"
gen double popw = population if vintage == "base"

collapse (sum) x = xterm z = zterm (max) pop = popw, by(area period)
tempfile agg
save `agg'

import delimited using "outcomes.csv", clear varnames(1)
keep area period control change_pp
merge 1:1 area period using `agg', keep(match) nogenerate

ivregress 2sls change_pp period control (x = z) [aw = pop]
scalar b_iv = _b[x]
scalar n_obs = e(N)

quietly summarize x if area == 0 & period == 0, meanonly
scalar ex0 = r(mean)
quietly summarize x if area == 0 & period == 1, meanonly
scalar ex1 = r(mean)
quietly summarize z if area == 0 & period == 0, meanonly
scalar iz0 = r(mean)

display "ANSWER: iv_slope estimate=" trim(string(scalar(b_iv), "%24.16g")) " se=NA n_obs=" trim(string(scalar(n_obs), "%12.0f"))
display "ANSWER: exposure_area0_period0 estimate=" trim(string(scalar(ex0), "%24.16g")) " se=NA n_obs=" trim(string(scalar(n_obs), "%12.0f"))
display "ANSWER: exposure_area0_period1 estimate=" trim(string(scalar(ex1), "%24.16g")) " se=NA n_obs=" trim(string(scalar(n_obs), "%12.0f"))
display "ANSWER: instrument_area0_period0 estimate=" trim(string(scalar(iz0), "%24.16g")) " se=NA n_obs=" trim(string(scalar(n_obs), "%12.0f"))
