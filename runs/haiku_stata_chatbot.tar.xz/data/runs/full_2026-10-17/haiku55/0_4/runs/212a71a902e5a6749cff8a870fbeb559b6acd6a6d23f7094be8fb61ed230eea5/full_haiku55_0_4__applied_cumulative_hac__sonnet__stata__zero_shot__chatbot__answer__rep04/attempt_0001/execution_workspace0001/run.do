clear all
set more off
set linesize 255

import delimited using "input.csv", clear varnames(1) stringcols(1)

gen double dt = date(date, "YMD")
replace dt = date(date, "MDY") if missing(dt)
sort dt
gen double t = _n
tsset t

gen double lnsales = ln(sales)
gen double lnvix = ln(vix)
gen double dlvix = D.lnvix

newey lnsales L(1/15).dlvix, lag(15)

scalar N = e(N)
matrix b = e(b)
matrix V = e(V) * N / (N - 16)

matrix c = J(16, 1, 1)
matrix c[16, 1] = 0
matrix cumv = b * c
matrix cv = c' * V * c

scalar cum_est = cumv[1, 1]
scalar cum_se = sqrt(cv[1, 1])

scalar l1_est = b[1, 1]
scalar l1_se = sqrt(V[1, 1])

scalar l15_est = b[1, 15]
scalar l15_se = sqrt(V[15, 15])

display "ANSWER: cumulative_response estimate=" %21.12f cum_est " se=" %21.12f cum_se " n_obs=" %12.0f N
display "ANSWER: lag_1 estimate=" %21.12f l1_est " se=" %21.12f l1_se " n_obs=" %12.0f N
display "ANSWER: lag_15 estimate=" %21.12f l15_est " se=" %21.12f l15_se " n_obs=" %12.0f N
