clear all
set more off
set linesize 255

import delimited using "./input.csv", clear varnames(1)

quietly count
local n_total = r(N)

quietly anova y group
local F_val    = e(F)
local df_num   = e(df_m)
local df_den   = e(df_r)
local p_val    = Ftail(e(df_m), e(df_r), e(F))

display "ANSWER: F estimate=" %21.12f `F_val' " se=" %21.12f . " n_obs=" %12.0f `n_total'
display "ANSWER: df_num estimate=" %21.12f `df_num' " se=" %21.12f . " n_obs=" %12.0f `n_total'
display "ANSWER: df_den estimate=" %21.12f `df_den' " se=" %21.12f . " n_obs=" %12.0f `n_total'
display "ANSWER: p_value estimate=" %21.12f `p_val' " se=" %21.12f . " n_obs=" %12.0f `n_total'
