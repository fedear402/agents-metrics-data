clear all
set more off
set linesize 255

import delimited using "input.csv", clear

local n = _N
local c = invF(2, `n'-4, 0.95)
local k = 2*`c'/(`n'-4)

capture program drop arsse
program define arsse, rclass
    args b
    tempvar e
    quietly gen double `e' = y - (`b')*endog
    quietly regress `e' x z1 z2
    local s1 = e(rss)
    quietly regress `e' x
    local s0 = e(rss)
    drop `e'
    return scalar s1 = `s1'
    return scalar s0 = `s0'
end

* S0(b)-S1(b)-k*S1(b) is an exact quadratic in b, so the test boundary
* is found from its coefficients without a grid search.
quietly arsse 0
local g0 = r(s0) - r(s1) - `k'*r(s1)

quietly arsse 1
local g1 = r(s0) - r(s1) - `k'*r(s1)
local s1_at1 = r(s1)
local s0_at1 = r(s0)

quietly arsse -1
local gm1 = r(s0) - r(s1) - `k'*r(s1)

local A = (`g1' + `gm1')/2 - `g0'
local B = (`g1' - `gm1')/2
local C = `g0'
local disc = `B'^2 - 4*`A'*`C'

local lo = .
local hi = .
local unb = 0

if `A' > 0 & `disc' >= 0 {
    local lo = (-`B' - sqrt(`disc'))/(2*`A')
    local hi = (-`B' + sqrt(`disc'))/(2*`A')
}

if `A' < 0 & `disc' >= 0 {
    local r1 = (-`B' + sqrt(`disc'))/(2*`A')
    local r2 = (-`B' - sqrt(`disc'))/(2*`A')
    local lo = min(`r1', `r2')
    local hi = max(`r1', `r2')
    local unb = 1
}

local accz = cond(`g0' <= 0, 1, 0)

local f_at_one = ((`s0_at1' - `s1_at1')/2)/(`s1_at1'/(`n'-4))

display "ANSWER: boundary_low estimate=" %21.12f `lo' " se=" "." " n_obs=" %12.0f `n'
display "ANSWER: boundary_high estimate=" %21.12f `hi' " se=" "." " n_obs=" %12.0f `n'
display "ANSWER: accepts_zero estimate=" %21.12f `accz' " se=" "." " n_obs=" %12.0f `n'
display "ANSWER: unbounded estimate=" %21.12f `unb' " se=" "." " n_obs=" %12.0f `n'
display "ANSWER: ar_f_at_one estimate=" %21.12f `f_at_one' " se=" "." " n_obs=" %12.0f `n'
