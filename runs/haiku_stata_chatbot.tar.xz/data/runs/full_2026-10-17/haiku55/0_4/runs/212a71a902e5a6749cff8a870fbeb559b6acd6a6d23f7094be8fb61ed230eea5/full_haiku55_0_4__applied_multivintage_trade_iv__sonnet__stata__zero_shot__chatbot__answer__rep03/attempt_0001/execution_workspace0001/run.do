clear all
set more off

import delimited using "crosswalk.csv", clear varnames(1)
capture destring code, replace
keep code industry
tempfile cw
save `cw'

import delimited using "trade.csv", clear varnames(1)
capture destring code period, replace
merge m:1 code using `cw', keep(match) nogen
keep period industry us_change other_change price_index years
tempfile tr
save `tr'

import delimited using "areas.csv", clear varnames(1)
capture destring area period, replace
tempfile ar
save `ar'

import delimited using "employment.csv", clear varnames(1)
capture destring area period employment, replace
tempfile emp
save `emp'

import delimited using "outcomes.csv", clear varnames(1)
capture destring area period, replace
tempfile oc
save `oc'

use `cw', clear
keep industry
duplicates drop
tempfile ind
save `ind'

use `ar', clear
cross using `ind'
merge 1:1 area period vintage industry using `emp', keep(master match) nogen
replace employment = 0 if missing(employment)
tempfile grid
save `grid'

collapse (sum) employment, by(period vintage industry)
rename employment natemp
tempfile nat
save `nat'

use `grid', clear
merge m:1 period vintage industry using `nat', nogen
merge m:1 period industry using `tr', keep(match) nogen

gen double xterm = (employment/total_employment)*(us_change/natemp)/(price_index/100)/1000*(10/years) if vintage=="base"
gen double zterm = (employment/total_employment)*(other_change/natemp)/(price_index/100)/1000*(10/years) if vintage=="early"
gen double pop = population if vintage=="base"

collapse (sum) xterm zterm (max) pop, by(area period)
rename xterm x
rename zterm z

merge 1:1 area period using `oc', keep(match) nogen

local nobs = _N

ivregress 2sls change_pp period control (x = z) [pweight=pop]
local b = _b[x]

quietly summarize x if area==0 & period==0, meanonly
local e0 = r(mean)
quietly summarize x if area==0 & period==1, meanonly
local e1 = r(mean)
quietly summarize z if area==0 & period==0, meanonly
local i0 = r(mean)

local s_b  = strtrim(string(`b',  "%20.15g"))
local s_e0 = strtrim(string(`e0', "%20.15g"))
local s_e1 = strtrim(string(`e1', "%20.15g"))
local s_i0 = strtrim(string(`i0', "%20.15g"))

display "ANSWER: iv_slope estimate=`s_b' se=NA n_obs=`nobs'"
display "ANSWER: exposure_area0_period0 estimate=`s_e0' se=NA n_obs=`nobs'"
display "ANSWER: exposure_area0_period1 estimate=`s_e1' se=NA n_obs=`nobs'"
display "ANSWER: instrument_area0_period0 estimate=`s_i0' se=NA n_obs=`nobs'"
