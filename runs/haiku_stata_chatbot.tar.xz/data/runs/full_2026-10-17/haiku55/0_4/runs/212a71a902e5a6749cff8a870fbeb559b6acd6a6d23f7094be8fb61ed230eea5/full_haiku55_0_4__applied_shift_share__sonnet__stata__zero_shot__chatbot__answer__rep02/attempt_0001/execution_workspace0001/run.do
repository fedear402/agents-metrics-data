clear all
set more off
set linesize 255

import delimited using "input.csv", clear varnames(1)

egen byte tagr = tag(region_id)
egen byte tagn = tag(industry_id)

gen double tmpw = region_weight if tagr
summarize tmpw, meanonly
scalar wsum = r(sum)
gen double e = region_weight / wsum
drop tmpw

bysort region_id: egen double z = total(share*shock)

gen double tmp = e*y if tagr
summarize tmp, meanonly
scalar ym = r(sum)
drop tmp

gen double tmp = e*x if tagr
summarize tmp, meanonly
scalar xm = r(sum)
drop tmp

gen double tmp = e*z if tagr
summarize tmp, meanonly
scalar zm = r(sum)
drop tmp

gen double y0 = y - ym
gen double x0 = x - xm
gen double z0 = z - zm

ivregress 2sls y (x = z) if tagr [aw=e]
scalar b_eff = _b[x]

regress x z if tagr [aw=e]
scalar b_fs = _b[z]

gen double es = e*share
bysort industry_id: egen double s = total(es)
drop es

local lst "y0 x0 z0"
foreach v of local lst {
    gen double ev = e*share*`v'
    bysort industry_id: egen double tot = total(ev)
    gen double `v'bar = tot/s
    drop ev tot
}

keep if tagn

count
scalar nobs = r(N)

gen double s2 = s^2
summarize s2, meanonly
scalar eff = 1/r(sum)

ivregress 2sls y0bar (x0bar = shock) [aw=s], vce(robust)
scalar se_eff = _se[x0bar]

ivregress 2sls x0bar (z0bar = shock) [aw=s], vce(robust)
scalar se_fs = _se[z0bar]

display "ANSWER: effect estimate=" %21.12f b_eff " se=" %21.12f se_eff " n_obs=" %12.0f nobs
display "ANSWER: first_stage estimate=" %21.12f b_fs " se=" %21.12f se_fs " n_obs=" %12.0f nobs
display "ANSWER: effective_shocks estimate=" %21.12f eff " se=." " n_obs=" %12.0f nobs
