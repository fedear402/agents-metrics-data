clear all
set more off
set linesize 255

import delimited using "./input.csv", clear varnames(1) stringcols(_all)

capture destring y, replace force
capture destring group, replace force

quietly count if !missing(y) & !missing(group)
local n_obs = r(N)

quietly anova y group
local F      = e(F)
local df_num = e(df_m)
local df_den = e(df_r)
local p      = Ftail(`df_num', `df_den', `F')

display "ANSWER: F estimate=" %21.12f `F' " se=" "." " n_obs=" %12.0f `n_obs'
display "ANSWER: df_num estimate=" %21.12f `df_num' " se=" "." " n_obs=" %12.0f `n_obs'
display "ANSWER: df_den estimate=" %21.12f `df_den' " se=" "." " n_obs=" %12.0f `n_obs'
display "ANSWER: p_value estimate=" %21.12f `p' " se=" "." " n_obs=" %12.0f `n_obs'
