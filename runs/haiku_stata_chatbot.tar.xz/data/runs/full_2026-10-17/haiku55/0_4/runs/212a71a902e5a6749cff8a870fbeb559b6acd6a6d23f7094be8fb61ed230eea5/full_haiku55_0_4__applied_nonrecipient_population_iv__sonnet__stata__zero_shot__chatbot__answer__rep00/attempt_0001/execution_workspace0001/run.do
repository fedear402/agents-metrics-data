clear all
set more off

import delimited using "census.csv", clear varnames(1)
summarize nonrecipient_population if eligible == 0, meanonly
local p0 = r(sum)
summarize nonrecipient_population if eligible == 1, meanonly
local p1 = r(sum)

import delimited using "households.csv", clear varnames(1)
keep if recipient == 0
egen double _miss = rowmiss(eligible treated instrument dose baseline weight outcome)
keep if _miss == 0
drop _miss

gen double inelig = 1 - eligible
gen double dose_inel = dose * inelig
gen double dose_el = dose * eligible
gen double base_inel = baseline * inelig
gen double base_el = baseline * eligible
gen double inst_inel = instrument * inelig
gen double inst_el = instrument * eligible

ivregress 2sls outcome inelig eligible base_inel base_el ///
    (dose_inel dose_el = inst_inel inst_el) [aw = weight], noconstant

local n_obs = e(N)
local b0 = _b[dose_inel]
local b1 = _b[dose_el]

summarize dose [aw = weight] if eligible == 0 & e(sample), meanonly
local m0 = r(mean)
summarize dose [aw = weight] if eligible == 1 & e(sample), meanonly
local m1 = r(mean)

local ineligible_effect = `b0' * `m0'
local eligible_nonrecipient_effect = `b1' * `m1'
local population_effect = (`p0' * `ineligible_effect' + `p1' * `eligible_nonrecipient_effect') / (`p0' + `p1')

di "ineligible_effect estimate=" trim(string(`ineligible_effect', "%20.12f")) " se=NA n_obs=" trim(string(`n_obs', "%12.0f"))
di "eligible_nonrecipient_effect estimate=" trim(string(`eligible_nonrecipient_effect', "%20.12f")) " se=NA n_obs=" trim(string(`n_obs', "%12.0f"))
di "population_effect estimate=" trim(string(`population_effect', "%20.12f")) " se=NA n_obs=" trim(string(`n_obs', "%12.0f"))
