clear all
set more off
set linesize 255

import delimited using "input.csv", clear varnames(1)

capture confirm string variable date
if _rc == 0 {
    gen double dnum = date(date, "YMD")
}
else {
    gen double dnum = date
}
sort dnum

gen double lnv = ln(vix)
gen double lns = ln(sales)
gen double dv = lnv - lnv[_n-1]

forvalues k = 1/15 {
    gen double L`k'dv = dv[_n-`k']
}

egen nmiss = rowmiss(L1dv-L15dv)
gen byte touse = (nmiss == 0) & !missing(lns)
count if touse
local N = r(N)

newey lns L1dv-L15dv if touse, lag(15)

local N = e(N)
matrix V = e(V) * (`N'/(`N'-16))
matrix b = e(b)

matrix c = J(1,16,1)
matrix c[1,16] = 0
matrix cb = c*b'
matrix cv = c*V*c'

scalar cum_est = cb[1,1]
scalar cum_se  = sqrt(cv[1,1])
scalar lag1_est  = b[1,1]
scalar lag1_se   = sqrt(V[1,1])
scalar lag15_est = b[1,15]
scalar lag15_se  = sqrt(V[15,15])

display "ANSWER: cumulative_response estimate=" %21.12f cum_est " se=" %21.12f cum_se " n_obs=" %12.0f `N'
display "ANSWER: lag_1 estimate=" %21.12f lag1_est " se=" %21.12f lag1_se " n_obs=" %12.0f `N'
display "ANSWER: lag_15 estimate=" %21.12f lag15_est " se=" %21.12f lag15_se " n_obs=" %12.0f `N'
