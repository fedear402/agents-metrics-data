clear all
set linesize 255

import delimited "./input.csv", clear varnames(1)

quietly anova y group
local F    = e(F)
local dfn  = e(df_m)
local dfd  = e(df_r)
local p    = Ftail(`dfn', `dfd', `F')

display "ANSWER: F estimate=" %21.12f `F' " se=. n_obs=" %12.0f e(N)
display "ANSWER: df_num estimate=" %21.12f `dfn' " se=. n_obs=" %12.0f e(N)
display "ANSWER: df_den estimate=" %21.12f `dfd' " se=. n_obs=" %12.0f e(N)
display "ANSWER: p_value estimate=" %21.12f `p' " se=. n_obs=" %12.0f e(N)
