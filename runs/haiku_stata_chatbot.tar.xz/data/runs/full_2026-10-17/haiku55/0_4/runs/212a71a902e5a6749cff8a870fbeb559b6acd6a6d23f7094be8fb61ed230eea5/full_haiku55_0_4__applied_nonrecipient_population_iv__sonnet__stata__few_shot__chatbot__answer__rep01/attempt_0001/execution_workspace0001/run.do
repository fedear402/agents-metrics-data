clear all
set more off

import delimited using "households.csv", clear
keep if recipient==0

gen double inel = 1-eligible
gen double dose_inel = dose*inel
gen double dose_el = dose*eligible
gen double base_inel = baseline*inel
gen double base_el = baseline*eligible
gen double inst_inel = instrument*inel
gen double inst_el = instrument*eligible

ivregress 2sls outcome inel eligible base_inel base_el (dose_inel dose_el = inst_inel inst_el) [aw=weight], noconstant
scalar n_obs = e(N)
scalar b_in = _b[dose_inel]
scalar b_el = _b[dose_el]

summarize dose [aw=weight] if eligible==0, meanonly
scalar eff0 = b_in*r(mean)
summarize dose [aw=weight] if eligible==1, meanonly
scalar eff1 = b_el*r(mean)

import delimited using "census.csv", clear
summarize nonrecipient_population if eligible==0, meanonly
scalar n0 = r(mean)
summarize nonrecipient_population if eligible==1, meanonly
scalar n1 = r(mean)

scalar pop_eff = (eff0*n0 + eff1*n1)/(n0 + n1)

local s0 = strtrim(string(eff0, "%24.16g"))
local s1 = strtrim(string(eff1, "%24.16g"))
local sp = strtrim(string(pop_eff, "%24.16g"))
local nobs = strtrim(string(n_obs, "%12.0f"))

display "ANSWER: ineligible_effect estimate=`s0' se=NA n_obs=`nobs'"
display "ANSWER: eligible_nonrecipient_effect estimate=`s1' se=NA n_obs=`nobs'"
display "ANSWER: population_effect estimate=`sp' se=NA n_obs=`nobs'"

exit, clear
