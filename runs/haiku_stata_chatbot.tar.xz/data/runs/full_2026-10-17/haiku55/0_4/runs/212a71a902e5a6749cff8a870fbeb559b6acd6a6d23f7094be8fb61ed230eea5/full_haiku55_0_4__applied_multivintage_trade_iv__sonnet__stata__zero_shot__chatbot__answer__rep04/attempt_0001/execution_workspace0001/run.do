clear all
set more off

import delimited using "crosswalk.csv", clear varnames(1)
capture tostring code, replace
capture tostring industry, replace
tempfile cw
save `cw'

import delimited using "trade.csv", clear varnames(1)
capture tostring code, replace
capture destring period, replace
merge m:1 code using `cw', keep(match) nogen
keep period industry us_change other_change price_index years
tempfile tr
save `tr'

use `tr', clear
keep industry
duplicates drop
gen byte one = 1
tempfile ind
save `ind'

import delimited using "employment.csv", clear varnames(1)
capture destring area period, replace
capture tostring industry, replace
keep area period vintage industry employment
tempfile emp
save `emp'

import delimited using "areas.csv", clear varnames(1)
capture destring area period, replace
gen byte one = 1
joinby one using `ind'
merge m:1 area period vintage industry using `emp', keep(master match) nogen
replace employment = 0 if missing(employment)
merge m:1 period industry using `tr', keep(match) nogen

bysort period vintage industry: egen nat_emp = total(employment)
gen pop_b = population if vintage == "base"
gen chg = cond(vintage == "base", us_change, other_change)
gen term = (employment / total_employment) * (chg / nat_emp) / (price_index / 100) / 1000 * (10 / years)
gen xterm = term if vintage == "base"
gen zterm = term if vintage == "early"

collapse (sum) x = xterm z = zterm (max) popb = pop_b, by(area period)
tempfile ex
save `ex'

import delimited using "outcomes.csv", clear varnames(1)
capture destring area period control, replace
capture destring change_pp, replace
merge 1:1 area period using `ex', keep(match) nogen

ivregress 2sls change_pp period control (x = z) [pweight = popb]
local b_iv = _b[x]
local n = e(N)

summarize x if area == 0 & period == 0, meanonly
local e0 = r(mean)
summarize x if area == 0 & period == 1, meanonly
local e1 = r(mean)
summarize z if area == 0 & period == 0, meanonly
local i0 = r(mean)

display "ANSWER: iv_slope estimate=" strtrim(string(`b_iv', "%21.15g")) " se=NA n_obs=" strtrim(string(`n', "%12.0f"))
display "ANSWER: exposure_area0_period0 estimate=" strtrim(string(`e0', "%21.15g")) " se=NA n_obs=" strtrim(string(`n', "%12.0f"))
display "ANSWER: exposure_area0_period1 estimate=" strtrim(string(`e1', "%21.15g")) " se=NA n_obs=" strtrim(string(`n', "%12.0f"))
display "ANSWER: instrument_area0_period0 estimate=" strtrim(string(`i0', "%21.15g")) " se=NA n_obs=" strtrim(string(`n', "%12.0f"))
