clear all
set more off
set linesize 255

import delimited using "./input.csv", clear varnames(1) case(preserve)

quietly count if t == 251
if r(N) == 0 {
    quietly summarize t
    local newn = _N + (251 - r(max))
    quietly set obs `newn'
    quietly replace t = 251 in L
}

tsset t

arima y, arima(1,1,1) noconstant
scalar n_obs = e(N)

predict double yhat_lvl if t == 251, y
predict double yhat_se if t == 251, stdp

summarize yhat_lvl if t == 251, meanonly
scalar fc = r(mean)
summarize yhat_se if t == 251, meanonly
scalar fc_se = r(mean)

scalar z975 = invnormal(0.975)
scalar lo = fc - z975*fc_se
scalar hi = fc + z975*fc_se

display "ANSWER: forecast estimate=" %21.12f fc " se=" %21.12f fc_se " n_obs=" %12.0f n_obs
display "ANSWER: lower_95 estimate=" %21.12f lo " se=" "." " n_obs=" %12.0f n_obs
display "ANSWER: upper_95 estimate=" %21.12f hi " se=" "." " n_obs=" %12.0f n_obs
