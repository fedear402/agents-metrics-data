clear all
set more off

import delimited using "crosswalk.csv", clear varnames(1)
capture destring _all, replace
tempfile xw
save `xw'

use `xw', clear
keep industry
duplicates drop
gen byte k = 1
tempfile ind
save `ind'

import delimited using "trade.csv", clear varnames(1)
capture destring _all, replace
merge m:1 code using `xw', keep(match) nogen
keep period industry us_change other_change price_index years
tempfile trd
save `trd'

import delimited using "areas.csv", clear varnames(1)
capture destring _all, replace
keep area period vintage total_employment population
tempfile ar
save `ar'

import delimited using "employment.csv", clear varnames(1)
capture destring _all, replace
keep area period vintage industry employment
tempfile emp
save `emp'

import delimited using "outcomes.csv", clear varnames(1)
capture destring _all, replace
keep area period control change_pp
tempfile oc
save `oc'

use `ar', clear
gen byte k = 1
joinby k using `ind'
drop k
merge 1:1 area period vintage industry using `emp', keep(master match) nogen
replace employment = 0 if missing(employment)
merge m:1 period industry using `trd', keep(match) nogen

bysort period vintage industry: egen double natE = total(employment)

gen double tx = (employment/total_employment) * (us_change/natE) / (price_index/100) / 1000 * (10/years)
gen double tz = (employment/total_employment) * (other_change/natE) / (price_index/100) / 1000 * (10/years)
gen double tx_b = tx if vintage == "base"
gen double tz_e = tz if vintage == "early"

bysort area period: egen double x = total(tx_b)
bysort area period: egen double z = total(tz_e)

keep if vintage == "base"
bysort area period: keep if _n == 1

merge 1:1 area period using `oc', keep(match) nogen

ivregress 2sls change_pp period control (x = z) [pweight=population]

local n_obs = e(N)
local b_iv = _b[x]

quietly summarize x if area == 0 & period == 0, meanonly
local ex0 = r(mean)
quietly summarize x if area == 0 & period == 1, meanonly
local ex1 = r(mean)
quietly summarize z if area == 0 & period == 0, meanonly
local iz0 = r(mean)

display "ANSWER: iv_slope estimate=" trim(string(`b_iv', "%20.12f")) " se=NA n_obs=" `n_obs'
display "ANSWER: exposure_area0_period0 estimate=" trim(string(`ex0', "%20.12f")) " se=NA n_obs=" `n_obs'
display "ANSWER: exposure_area0_period1 estimate=" trim(string(`ex1', "%20.12f")) " se=NA n_obs=" `n_obs'
display "ANSWER: instrument_area0_period0 estimate=" trim(string(`iz0', "%20.12f")) " se=NA n_obs=" `n_obs'
