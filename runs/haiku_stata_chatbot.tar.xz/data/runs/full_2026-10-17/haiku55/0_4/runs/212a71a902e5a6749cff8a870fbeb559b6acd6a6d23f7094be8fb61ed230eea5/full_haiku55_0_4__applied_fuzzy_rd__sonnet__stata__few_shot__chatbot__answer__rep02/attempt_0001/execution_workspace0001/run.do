version 19.0
clear all
set more off
set linesize 255

import delimited using "input.csv", clear varnames(1)
keep if abs(score)<1
gen double wt = 1-abs(score)
gen double D = score>=0
gen double sL = score*(1-D)
gen double sR = score*D

mata:
w = st_data(., "wt")
D = st_data(., "D")
s = st_data(., "score")
y1 = st_data(., "earnings")
y2 = st_data(., "participated")
X = (J(rows(w),1,1), D, s:*(1:-D), s:*D)
Y = (y1, y2)
B = invsym(X'*(w:*X))
beta = B*X'*(w:*Y)
E = Y - X*beta
c = (0\1\0\0)
loading = w:*(X*B*c)
infl = (loading:*E[.,1], loading:*E[.,2])
V = infl'*infl
jumps = c'*beta
g = (1/jumps[2]\-jumps[1]/jumps[2]^2)
se_tau = sqrt(g'*V*g)
st_numscalar("red", jumps[1])
st_numscalar("fs", jumps[2])
st_numscalar("tau", jumps[1]/jumps[2])
st_numscalar("se_red", sqrt(V[1,1]))
st_numscalar("se_fs", sqrt(V[2,2]))
st_numscalar("se_tau", se_tau)
st_numscalar("nobs", rows(X))
end

display "ANSWER: treatment_effect estimate=" %21.12f tau " se=" %21.12f se_tau " n_obs=" %12.0f nobs
display "ANSWER: reduced_form estimate=" %21.12f red " se=" %21.12f se_red " n_obs=" %12.0f nobs
display "ANSWER: first_stage estimate=" %21.12f fs " se=" %21.12f se_fs " n_obs=" %12.0f nobs
