clear all
set linesize 255

import delimited using "input.csv", clear
drop if missing(score, participated, earnings)
keep if abs(score) < 1
gen double w = 1 - abs(score)

mata:
real colvector bfit(real colvector s, real colvector y, real colvector w)
{
    real matrix X, A
    X = (J(rows(s), 1, 1), s)
    A = cross(X, w, X)
    return(invsym(A) * cross(X, w, y))
}

real rowvector ipsi(real colvector s, real colvector y, real colvector w)
{
    real matrix X, Ai
    real colvector e
    X = (J(rows(s), 1, 1), s)
    Ai = invsym(cross(X, w, X))
    e = y - X * bfit(s, y, w)
    return((((Ai[1,1] :+ Ai[1,2] :* s) :* w :* e))')
}

s = st_data(., "score")
y = st_data(., "earnings")
d = st_data(., "participated")
w = st_data(., "w")

R = s :>= 0
L = s :< 0

sR = select(s, R); sL = select(s, L)
yR = select(y, R); yL = select(y, L)
dR = select(d, R); dL = select(d, L)
wR = select(w, R); wL = select(w, L)

by_R = bfit(sR, yR, wR)
by_L = bfit(sL, yL, wL)
bd_R = bfit(sR, dR, wR)
bd_L = bfit(sL, dL, wL)

rf  = by_R[1] - by_L[1]
fs  = bd_R[1] - bd_L[1]
tau = rf / fs

pyR = ipsi(sR, yR, wR)
pyL = ipsi(sL, yL, wL)
pdR = ipsi(sR, dR, wR)
pdL = ipsi(sL, dL, wL)

Vyy = sum(pyR:^2) + sum(pyL:^2)
Vdd = sum(pdR:^2) + sum(pdL:^2)
Vyd = sum(pyR:*pdR) + sum(pyL:*pdL)

gy = 1 / fs
gd = -rf / fs^2
Vtau = gy^2 * Vyy + 2 * gy * gd * Vyd + gd^2 * Vdd

st_numscalar("rf_est", rf)
st_numscalar("rf_se", sqrt(Vyy))
st_numscalar("fs_est", fs)
st_numscalar("fs_se", sqrt(Vdd))
st_numscalar("tau_est", tau)
st_numscalar("tau_se", sqrt(Vtau))
st_numscalar("n_in", rows(s))
end

display "ANSWER: treatment_effect estimate=" %21.12f tau_est " se=" %21.12f tau_se " n_obs=" %12.0f n_in
display "ANSWER: reduced_form estimate=" %21.12f rf_est " se=" %21.12f rf_se " n_obs=" %12.0f n_in
display "ANSWER: first_stage estimate=" %21.12f fs_est " se=" %21.12f fs_se " n_obs=" %12.0f n_in
