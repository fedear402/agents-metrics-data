clear all
set more off
set type double

import delimited using "input.csv", clear varnames(1) case(lower)

local cohorts 3 5 7
local num 0
local den 0
local nobs 0

foreach c of local cohorts {
    preserve
    keep if inrange(time, `c'-2, `c'+2)
    keep if g==`c' | g==0 | g>`c'+2
    bysort id: gen byte nw = _N
    keep if nw==5
    drop nw
    gen byte did = (g==`c' & time>=`c')
    levelsof id if g==`c', local(tr)
    local ntr : word count `tr'
    quietly regress y did i.id i.time
    local b = _b[did]
    local n = e(N)
    display "ANSWER: att_g`c' estimate=" %24.16g `b' " se=null n_obs=" %12.0f `n'
    local num = `num' + `b'*`ntr'
    local den = `den' + `ntr'
    local nobs = `nobs' + `n'
    restore
}

local attw = `num'/`den'
display "ANSWER: att_weighted estimate=" %24.16g `attw' " se=null n_obs=" %12.0f `nobs'
exit, clear
