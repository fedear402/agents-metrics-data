version 19.0
clear all
set more off
set linesize 255

import delimited using "input.csv", clear varnames(1)

keep if abs(score)<1
gen double w = 1 - abs(score)
gen double right = (score>=0)
gen double score_right = score*right
count
scalar n_obs = r(N)

mata:
X = (J(st_nobs(),1,1), st_data(.,"right"), st_data(.,"score"), st_data(.,"score_right"))
wt = st_data(.,"w")
Y = st_data(.,("earnings","participated"))
A = invsym(X'*(wt:*X))
B = A*X'*(wt:*Y)
E = Y - X*B
ctr = (0\1\0\0)
loading = wt:*(X*A*ctr)
infl = E:*(loading*J(1,2,1))
V = infl'*infl
jump = ctr'*B
g = (1/jump[2] \ -jump[1]/jump[2]^2)
st_numscalar("rf_est", jump[1])
st_numscalar("rf_se", sqrt(V[1,1]))
st_numscalar("fs_est", jump[2])
st_numscalar("fs_se", sqrt(V[2,2]))
st_numscalar("te_est", jump[1]/jump[2])
st_numscalar("te_se", sqrt(g'*V*g))
end

display "ANSWER: treatment_effect estimate=" %21.12f te_est " se=" %21.12f te_se " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f rf_est " se=" %21.12f rf_se " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f fs_est " se=" %21.12f fs_se " n_obs=" %12.0f n_obs
