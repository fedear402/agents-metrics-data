clear all
set more off
set linesize 255

import delimited using "input.csv", clear

bysort region_id: egen double z = total(share*shock)

preserve
bysort region_id: keep if _n==1
egen double wtot = total(region_weight)
gen double e = region_weight/wtot
foreach v in y x z {
    quietly summarize `v' [aw=e], meanonly
    gen double `v'0 = `v' - r(mean)
}
quietly ivregress 2sls y (x = z) [aw=e]
scalar eff_b = _b[x]
quietly regress x z [aw=e]
scalar fs_b = _b[z]
tempfile reg
save `reg'
restore

merge m:1 region_id using `reg', keepusing(e y0 x0 z0) nogenerate

gen double ws = e*share
gen double wy = ws*y0
gen double wx = ws*x0
gen double wz = ws*z0
collapse (sum) s=ws ny=wy nx=wx nz=wz (mean) shock, by(industry_id)

gen double ybar = ny/s
gen double xbar = nx/s
gen double zbar = nz/s
scalar N = _N

foreach v in ybar xbar zbar shock {
    quietly summarize `v' [aw=s]
    gen double `v'_c = `v' - r(mean)
}

* Effect: shock-level IV of ybar on xbar, instrument shock_c
quietly summarize num_e_dummy
gen double num_e = s*shock_c*ybar_c
gen double den_e = s*shock_c*xbar_c
quietly summarize num_e
scalar ne = r(sum)
quietly summarize den_e
scalar de = r(sum)
scalar b_e = ne/de
gen double ue = ybar_c - b_e*xbar_c
gen double ge = s*shock_c*ue
gen double ge2 = ge^2
quietly summarize ge2
scalar me = r(sum)
scalar se_e = sqrt(scalar(N)/(scalar(N)-2) * me / de^2)

* First stage: shock-level IV of xbar on zbar, instrument shock_c
gen double num_f = s*shock_c*xbar_c
gen double den_f = s*shock_c*zbar_c
quietly summarize num_f
scalar nf = r(sum)
quietly summarize den_f
scalar df = r(sum)
scalar b_f = nf/df
gen double uf = xbar_c - b_f*zbar_c
gen double gf = s*shock_c*uf
gen double gf2 = gf^2
quietly summarize gf2
scalar mf = r(sum)
scalar se_f = sqrt(scalar(N)/(scalar(N)-2) * mf / df^2)

* Effective number of shocks
gen double s2 = s^2
quietly summarize s2
scalar eff_s = 1/r(sum)

display "ANSWER: effect estimate=" %21.12f eff_b " se=" %21.12f se_e " n_obs=" %12.0f scalar(N)
display "ANSWER: first_stage estimate=" %21.12f fs_b " se=" %21.12f se_f " n_obs=" %12.0f scalar(N)
display "ANSWER: effective_shocks estimate=" %21.12f eff_s " se=. n_obs=" %12.0f scalar(N)
