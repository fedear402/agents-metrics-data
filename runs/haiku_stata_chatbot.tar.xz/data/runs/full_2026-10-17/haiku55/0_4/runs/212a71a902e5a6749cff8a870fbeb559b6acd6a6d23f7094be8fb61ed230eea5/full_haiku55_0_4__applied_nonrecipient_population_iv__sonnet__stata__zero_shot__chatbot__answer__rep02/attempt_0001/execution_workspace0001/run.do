clear all
set more off

import delimited using "households.csv", clear varnames(1)
keep if recipient == 0

gen double e0 = 1 - eligible
gen double e1 = eligible
gen double b0 = baseline * (1 - eligible)
gen double b1 = baseline * eligible
gen double d0 = dose * (1 - eligible)
gen double d1 = dose * eligible
gen double z0 = instrument * (1 - eligible)
gen double z1 = instrument * eligible

ivregress 2sls outcome e0 e1 b0 b1 (d0 d1 = z0 z1) [aw = weight], noconstant

local n_obs = e(N)
gen byte touse = e(sample)

local slope_in = _b[d0]
local slope_el = _b[d1]

quietly summarize dose [aw = weight] if touse & eligible == 0
local mean_in = r(mean)
quietly summarize dose [aw = weight] if touse & eligible == 1
local mean_el = r(mean)

local ineligible_effect = `slope_in' * `mean_in'
local eligible_nonrecipient_effect = `slope_el' * `mean_el'

import delimited using "census.csv", clear varnames(1)
quietly summarize nonrecipient_population if eligible == 0, meanonly
local N0 = r(sum)
quietly summarize nonrecipient_population if eligible == 1, meanonly
local N1 = r(sum)

local w0 = `N0' / (`N0' + `N1')
local w1 = `N1' / (`N0' + `N1')
local population_effect = `w0' * `ineligible_effect' + `w1' * `eligible_nonrecipient_effect'

di "ineligible_effect estimate=" trim(string(`ineligible_effect', "%25.15f")) " se=NA n_obs=" `n_obs'
di "eligible_nonrecipient_effect estimate=" trim(string(`eligible_nonrecipient_effect', "%25.15f")) " se=NA n_obs=" `n_obs'
di "population_effect estimate=" trim(string(`population_effect', "%25.15f")) " se=NA n_obs=" `n_obs'
