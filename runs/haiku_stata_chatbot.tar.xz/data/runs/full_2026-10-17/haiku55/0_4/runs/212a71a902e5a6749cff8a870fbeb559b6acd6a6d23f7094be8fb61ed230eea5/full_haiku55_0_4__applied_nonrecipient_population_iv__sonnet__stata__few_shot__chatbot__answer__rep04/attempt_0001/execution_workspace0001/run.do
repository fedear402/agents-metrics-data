clear all
set more off
set type double

import delimited using "households.csv", clear varnames(1)
keep if recipient==0

gen double d0 = dose*(1-eligible)
gen double d1 = dose*eligible
gen double ex0 = 1-eligible
gen double ex1 = eligible
gen double ex2 = baseline*(1-eligible)
gen double ex3 = baseline*eligible
gen double z0 = instrument*(1-eligible)
gen double z1 = instrument*eligible

ivregress 2sls outcome ex0 ex1 ex2 ex3 (d0 d1 = z0 z1) [aw=weight], noconstant

scalar nobs = e(N)
scalar slope0 = _b[d0]
scalar slope1 = _b[d1]

summarize dose [aw=weight] if eligible==0, meanonly
scalar m0 = r(mean)
summarize dose [aw=weight] if eligible==1, meanonly
scalar m1 = r(mean)

scalar e0 = slope0*m0
scalar e1 = slope1*m1

import delimited using "census.csv", clear varnames(1)
summarize nonrecipient_population if eligible==0, meanonly
scalar n0 = r(mean)
summarize nonrecipient_population if eligible==1, meanonly
scalar n1 = r(mean)

scalar pop = (e0*n0 + e1*n1)/(n0 + n1)

display "ANSWER: ineligible_effect estimate=" trim(string(e0,"%24.16g")) " se=NA n_obs=" trim(string(nobs,"%12.0f"))
display "ANSWER: eligible_nonrecipient_effect estimate=" trim(string(e1,"%24.16g")) " se=NA n_obs=" trim(string(nobs,"%12.0f"))
display "ANSWER: population_effect estimate=" trim(string(pop,"%24.16g")) " se=NA n_obs=" trim(string(nobs,"%12.0f"))

exit, clear
