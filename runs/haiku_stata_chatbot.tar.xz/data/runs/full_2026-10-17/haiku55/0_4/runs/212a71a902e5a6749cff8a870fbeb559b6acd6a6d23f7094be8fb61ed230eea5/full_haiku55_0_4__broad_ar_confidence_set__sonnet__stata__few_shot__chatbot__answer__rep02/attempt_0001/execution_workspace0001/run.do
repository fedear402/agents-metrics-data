clear all
set more off
set linesize 255

import delimited using "input.csv", clear

local n = _N
scalar nobs = _N
scalar df = `n' - 4
scalar critical = invFtail(2, df, .05)
scalar k = 2*critical/df

quietly regress y x
predict double ry, residuals
quietly regress endog x
predict double re, residuals
quietly regress y x z1 z2
predict double uy, residuals
quietly regress endog x z1 z2
predict double ue, residuals

mata:
ry = st_data(., "ry")
re = st_data(., "re")
uy = st_data(., "uy")
ue = st_data(., "ue")
k  = st_numscalar("k")
df = st_numscalar("df")

A = cross(re, re) - (1+k)*cross(ue, ue)
B = -2*(cross(ry, re) - (1+k)*cross(uy, ue))
C = cross(ry, ry) - (1+k)*cross(uy, uy)
D = B^2 - 4*A*C

if (abs(A) > 1e-12 & D >= 0) {
    r = sort((-B - sqrt(D))/(2*A) \ (-B + sqrt(D))/(2*A), 1)
    lo = r[1]
    hi = r[2]
}
else {
    lo = .
    hi = .
}

st_numscalar("lo", lo)
st_numscalar("hi", hi)
st_numscalar("accepts_zero", C <= 0)
st_numscalar("unbounded", A < 0)

dR1 = ry - re
dU1 = uy - ue
ssrR1 = cross(dR1, dR1)
ssrU1 = cross(dU1, dU1)
st_numscalar("fone", ((ssrR1 - ssrU1)/2)/(ssrU1/df))
end

display "ANSWER: boundary_low estimate=" %21.12f lo " se=" "." " n_obs=" %12.0f nobs
display "ANSWER: boundary_high estimate=" %21.12f hi " se=" "." " n_obs=" %12.0f nobs
display "ANSWER: accepts_zero estimate=" %21.12f accepts_zero " se=" "." " n_obs=" %12.0f nobs
display "ANSWER: unbounded estimate=" %21.12f unbounded " se=" "." " n_obs=" %12.0f nobs
display "ANSWER: ar_f_at_one estimate=" %21.12f fone " se=" "." " n_obs=" %12.0f nobs
