clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

egen gid = group(group)
quietly regress y i.gid

scalar F_val = e(F)
scalar df_num_val = e(df_m)
scalar df_den_val = e(df_r)
scalar p_val = Ftail(df_num_val, df_den_val, F_val)
scalar n_val = e(N)

display "ANSWER: F estimate=" %21.12f F_val " se=. n_obs=" %12.0f n_val
display "ANSWER: df_num estimate=" %21.12f df_num_val " se=. n_obs=" %12.0f n_val
display "ANSWER: df_den estimate=" %21.12f df_den_val " se=. n_obs=" %12.0f n_val
display "ANSWER: p_value estimate=" %21.12f p_val " se=. n_obs=" %12.0f n_val
