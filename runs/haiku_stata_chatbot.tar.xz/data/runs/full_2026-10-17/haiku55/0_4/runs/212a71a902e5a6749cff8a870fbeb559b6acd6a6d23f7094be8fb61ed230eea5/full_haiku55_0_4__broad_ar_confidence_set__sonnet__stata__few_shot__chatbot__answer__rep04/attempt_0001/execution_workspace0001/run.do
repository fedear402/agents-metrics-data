clear all
set more off
set linesize 255

import delimited using "input.csv", clear
scalar n_obs = _N

mata:
real colvector y, en, x
real matrix Z, X1, W, Mx, Pz, M, G, Pw, Mu
real colvector ry, rd, e1
real matrix rz
real scalar n, kk, qa, qb, qc, disc, lo, hi, r1, r2, ssrr, ssru, fone

y  = st_data(., "y")
en = st_data(., "endog")
x  = st_data(., "x")
Z  = st_data(., ("z1", "z2"))
n  = rows(y)
X1 = (J(n, 1, 1), x)
W  = (X1, Z)

Mx = I(n) - X1*invsym(X1'*X1)*X1'
ry = Mx*y
rd = Mx*en
rz = Mx*Z
Pz = rz*invsym(rz'*rz)*rz'
M  = I(n) - Pz

kk = 2*invFtail(2, n-4, 0.05)/(n-4)
G  = Pz - kk*M

qa = rd'*G*rd
qb = -2*(rd'*G*ry)
qc = ry'*G*ry
disc = qb^2 - 4*qa*qc

if (disc > 0) {
    r1 = (-qb - sqrt(disc))/(2*qa)
    r2 = (-qb + sqrt(disc))/(2*qa)
    lo = min((r1, r2))
    hi = max((r1, r2))
}
else {
    lo = .
    hi = .
}

st_numscalar("boundary_low", lo)
st_numscalar("boundary_high", hi)
st_numscalar("accepts_zero", qc <= 0)
st_numscalar("unbounded", qa < 0)

e1  = y - en
Pw  = W*invsym(W'*W)*W'
Mu  = I(n) - Pw
ssru = e1'*Mu*e1
ssrr = e1'*Mx*e1
fone = ((ssrr - ssru)/2)/(ssru/(n-4))
st_numscalar("ar_f_at_one", fone)
end

display "ANSWER: boundary_low estimate=" %21.12f boundary_low " se=. n_obs=" %12.0f n_obs
display "ANSWER: boundary_high estimate=" %21.12f boundary_high " se=. n_obs=" %12.0f n_obs
display "ANSWER: accepts_zero estimate=" %21.12f accepts_zero " se=. n_obs=" %12.0f n_obs
display "ANSWER: unbounded estimate=" %21.12f unbounded " se=. n_obs=" %12.0f n_obs
display "ANSWER: ar_f_at_one estimate=" %21.12f ar_f_at_one " se=. n_obs=" %12.0f n_obs
