clear all
set more off
set linesize 255

import delimited using "./input.csv", clear varnames(1)

tsset t

arima y, arima(1,1,1) noconstant technique(bfgs) vsquish

scalar n_obs = e(N)
scalar T_last = 250

* One-step-ahead forecast for t = 251 in levels from the fitted ARIMA(1,1,1) model
predict double yhat_levels if t <= 251, y dynamic(251)
summarize yhat_levels if t == 251, meanonly
scalar forecast_est = r(mean)

* Forecast error variance from the ARIMA model
predict double yhat_se if t <= 251, mse
summarize yhat_se if t == 251, meanonly
scalar forecast_mse = r(mean)
scalar forecast_se = sqrt(forecast_mse)

scalar lower_est = forecast_est - invnormal(0.975) * forecast_se
scalar upper_est = forecast_est + invnormal(0.975) * forecast_se

display "ANSWER: forecast estimate=" %21.12f forecast_est " se=" %21.12f forecast_se " n_obs=" %12.0f n_obs
display "ANSWER: lower_95 estimate=" %21.12f lower_est " se=" %21.12f . " n_obs=" %12.0f n_obs
display "ANSWER: upper_95 estimate=" %21.12f upper_est " se=" %21.12f . " n_obs=" %12.0f n_obs
