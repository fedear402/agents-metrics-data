clear all
set more off
set linesize 255

import delimited using "./input.csv", clear varnames(1)

quietly summarize t
local add = 251 - r(max)
if `add' > 0 {
    quietly tsset t
    tsappend, add(`add')
}

quietly tsset t
arima y, arima(1,1,1) noconstant
local n_est = e(N)

predict double fc if t == 251
predict double mse251 if t == 251, mse

quietly summarize fc if t == 251
scalar fc_val = r(mean)
quietly summarize mse251 if t == 251
scalar se_val = sqrt(r(mean))
scalar z975 = invnormal(0.975)
scalar lo_val = fc_val - z975*se_val
scalar hi_val = fc_val + z975*se_val

display "ANSWER: forecast estimate=" %21.12f fc_val " se=" %21.12f se_val " n_obs=" %12.0f `n_est'
display "ANSWER: lower_95 estimate=" %21.12f lo_val " se=" "." " n_obs=" %12.0f `n_est'
display "ANSWER: upper_95 estimate=" %21.12f hi_val " se=" "." " n_obs=" %12.0f `n_est'
