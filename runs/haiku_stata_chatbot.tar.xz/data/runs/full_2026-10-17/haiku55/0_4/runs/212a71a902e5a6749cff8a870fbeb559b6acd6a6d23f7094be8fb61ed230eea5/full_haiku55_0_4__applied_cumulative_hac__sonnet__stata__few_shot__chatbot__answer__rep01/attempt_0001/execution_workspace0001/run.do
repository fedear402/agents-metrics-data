version 19.0
clear all
set more off
set linesize 255

import delimited using "input.csv", clear
capture confirm string variable date
if _rc == 0 {
    generate double day = date(date, "YMD")
}
else {
    generate double day = date
}
sort day
generate long obs = _n
tsset obs

generate double log_sales = ln(sales)
generate double log_vix = ln(vix)
generate double dlvix = D.log_vix

local lagnames ""
forvalues k = 1/15 {
    generate double lagv`k' = L`k'.dlvix
    local lagnames "`lagnames' lagv`k'"
}

keep if !missing(log_sales, `lagnames')

mata:
y = st_data(., "log_sales")
Z = st_data(., tokens("`lagnames'"))
X = (J(rows(y), 1, 1), Z)
N = rows(X)
p = cols(X)
b = qrsolve(X, y)
e = y - X*b
S = X:*e
meat = S'*S
for (j = 1; j <= 15; j++) {
    G = S[|j+1, 1 \ N, p|]' * S[|1, 1 \ N-j, p|]
    meat = meat + (1 - j/16) * (G + G')
}
bread = invsym(X'*X)
V = N/(N-p) * bread * meat * bread
c = (0 \ J(15, 1, 1))
st_numscalar("r_n", N)
st_numscalar("r_cum", c'*b)
st_numscalar("r_cum_se", sqrt(c'*V*c))
st_numscalar("r_lag1", b[2])
st_numscalar("r_lag1_se", sqrt(V[2,2]))
st_numscalar("r_lag15", b[16])
st_numscalar("r_lag15_se", sqrt(V[16,16]))
end

display "ANSWER: cumulative_response estimate=" %21.12f r(r_cum) " se=" %21.12f r(r_cum_se) " n_obs=" %12.0f r(r_n)
display "ANSWER: lag_1 estimate=" %21.12f r(r_lag1) " se=" %21.12f r(r_lag1_se) " n_obs=" %12.0f r(r_n)
display "ANSWER: lag_15 estimate=" %21.12f r(r_lag15) " se=" %21.12f r(r_lag15_se) " n_obs=" %12.0f r(r_n)
