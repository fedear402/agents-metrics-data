clear all
set linesize 255
import delimited using "input.csv", clear
keep if t <= 251
sort t
quietly count if t == 251
if r(N) == 0 {
    set obs `=_N + 1'
    replace t = 251 if _n == _N
}
tsset t
arima y, arima(1,1,1) noconstant
local n = e(N)
local sig = e(sigma)
predict yf if t == 251, y
summarize yf if t == 251, meanonly
local fc = r(mean)
local z = invnormal(0.975)
local lo = `fc' - `z' * `sig'
local hi = `fc' + `z' * `sig'
display "ANSWER: forecast estimate=" %21.12f `fc' " se=" %21.12f `sig' " n_obs=" %12.0f `n'
display "ANSWER: lower_95 estimate=" %21.12f `lo' " se=. n_obs=" %12.0f `n'
display "ANSWER: upper_95 estimate=" %21.12f `hi' " se=. n_obs=" %12.0f `n'
