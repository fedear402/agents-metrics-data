clear all
set more off
set linesize 255

import delimited using "input.csv", clear

quietly count
scalar n_obs = r(N)
scalar cval = invF(2, n_obs-4, 0.95)
scalar kk = 2*cval/(n_obs-4)

gen double ytil = y - endog
quietly regress ytil x z1 z2
quietly test z1 z2
scalar ar_f1 = r(F)

mata:
y  = st_data(., "y")
en = st_data(., "endog")
x  = st_data(., "x")
Z  = st_data(., ("z1", "z2"))
nn = rows(y)
Xf = (J(nn, 1, 1), x)
MX = I(nn) - Xf*invsym(Xf'*Xf)*Xf'
Wr = MX*Z
PW = Wr*invsym(Wr'*Wr)*Wr'
k  = st_numscalar("kk")
a  = MX*y
e  = MX*en
QA = (1+k)*(e'*PW*e) - k*(e'*MX*e)
QB = (1+k)*(a'*PW*e) - k*(a'*MX*e)
QC = (1+k)*(a'*PW*a) - k*(a'*MX*a)
D  = QB^2 - QA*QC
lo = .
hi = .
if (QA > 0 & D >= 0) {
    lo = (QB - sqrt(D))/QA
    hi = (QB + sqrt(D))/QA
}
ub = (QA <= 0)
cz = (QC <= 0)
st_numscalar("bnd_lo", lo)
st_numscalar("bnd_hi", hi)
st_numscalar("unb", ub)
st_numscalar("acc0", cz)
end

display "ANSWER: boundary_low estimate=" %21.12f bnd_lo " se=." " n_obs=" %12.0f n_obs
display "ANSWER: boundary_high estimate=" %21.12f bnd_hi " se=." " n_obs=" %12.0f n_obs
display "ANSWER: accepts_zero estimate=" %21.12f acc0 " se=." " n_obs=" %12.0f n_obs
display "ANSWER: unbounded estimate=" %21.12f unb " se=." " n_obs=" %12.0f n_obs
display "ANSWER: ar_f_at_one estimate=" %21.12f ar_f1 " se=." " n_obs=" %12.0f n_obs
