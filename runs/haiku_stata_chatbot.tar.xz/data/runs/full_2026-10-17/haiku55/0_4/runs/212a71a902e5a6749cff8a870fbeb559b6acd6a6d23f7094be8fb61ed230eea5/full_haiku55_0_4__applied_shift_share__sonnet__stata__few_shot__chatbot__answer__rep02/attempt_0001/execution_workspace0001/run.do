version 19.0
clear all
set more off
set linesize 255

mata:
real rowvector iv_hc1(real colvector y, real colvector d, real colvector z, real colvector w)
{
    real scalar N
    real matrix R, Zm, cross, inv_, S, V
    real colvector b, u

    N = rows(y)
    R = (J(N,1,1), d)
    Zm = (J(N,1,1), z)
    cross = Zm' * (w:*R)
    inv_ = luinv(cross)
    b = inv_ * Zm' * (w:*y)
    u = y - R*b
    S = Zm :* (w:*u)
    V = N/(N-2) * inv_ * (S'*S) * inv_'
    return((b[2], sqrt(V[2,2])))
}
end

import delimited using "input.csv", clear varnames(1)
tempfile orig
save `orig'

gen double sz = share*shock
bysort region_id: egen double z = total(sz)
bysort region_id: keep if _n==1
egen double wsum = total(region_weight)
gen double e = region_weight/wsum

foreach v in y x z {
    quietly summarize `v' [aw=e], meanonly
    gen double `v'0 = `v' - r(mean)
}

gen double e_zy = e*z0*y0
gen double e_zx = e*z0*x0
gen double e_zz = e*z0*z0
quietly summarize e_zy, meanonly
scalar reg_num_eff = r(sum)
quietly summarize e_zx, meanonly
scalar reg_den_eff = r(sum)
quietly summarize e_zz, meanonly
scalar reg_den_fs = r(sum)
scalar reg_effect = reg_num_eff/reg_den_eff
scalar reg_fs = reg_den_eff/reg_den_fs

tempfile regdata
keep region_id e x0 y0 z0
save `regdata'

use `orig', clear
merge m:1 region_id using `regdata', nogen assert(match)

gen double ew = e*share
gen double wy = ew*y0
gen double wx = ew*x0
gen double wz = ew*z0

collapse (sum) s=ew sy=wy sx=wx sz=wz (mean) shock, by(industry_id)
gen double ybar = sy/s
gen double xbar = sx/s
gen double zbar = sz/s

local N = _N

scalar eff_se = .
scalar fs_se = .
scalar eff_shocks = .

mata:
real colvector yb, xb, zb, sh, sw
real rowvector r1, r2
yb = st_data(.,"ybar")
xb = st_data(.,"xbar")
zb = st_data(.,"zbar")
sh = st_data(.,"shock")
sw = st_data(.,"s")
r1 = iv_hc1(yb, xb, sh, sw)
r2 = iv_hc1(xb, zb, sh, sw)
st_numscalar("eff_se", r1[2])
st_numscalar("fs_se", r2[2])
st_numscalar("eff_shocks", 1/sum(sw:^2))
end

display "ANSWER: effect estimate=" %21.12f reg_effect " se=" %21.12f eff_se " n_obs=" %12.0f `N'
display "ANSWER: first_stage estimate=" %21.12f reg_fs " se=" %21.12f fs_se " n_obs=" %12.0f `N'
display "ANSWER: effective_shocks estimate=" %21.12f eff_shocks " se=" %21.12f . " n_obs=" %12.0f `N'
