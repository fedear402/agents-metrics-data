version 17
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear varnames(1) case(preserve)
sort t
tsset t

quietly count if t==251
if r(N)==0 {
    quietly tsappend, add(1)
}

quietly arima y, arima(1,1,1) noconstant
scalar n_obs = e(N)

quietly predict double fv, y
quietly predict double mse_fc, mse

quietly summarize fv if t==251, meanonly
scalar fc = r(mean)
quietly summarize mse_fc if t==251, meanonly
scalar se_fc = sqrt(r(mean))

scalar z95 = invnormal(0.975)
scalar lo95 = fc - z95*se_fc
scalar hi95 = fc + z95*se_fc

display "ANSWER: forecast estimate=" %21.12f fc " se=" %21.12f se_fc " n_obs=" %12.0f n_obs
display "ANSWER: lower_95 estimate=" %21.12f lo95 " se=." " n_obs=" %12.0f n_obs
display "ANSWER: upper_95 estimate=" %21.12f hi95 " se=." " n_obs=" %12.0f n_obs
