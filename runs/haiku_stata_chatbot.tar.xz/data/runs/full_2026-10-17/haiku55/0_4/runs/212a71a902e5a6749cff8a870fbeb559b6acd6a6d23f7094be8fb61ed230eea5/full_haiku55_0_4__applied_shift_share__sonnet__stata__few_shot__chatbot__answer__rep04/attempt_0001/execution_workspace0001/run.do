version 19.0
clear all
set more off
set linesize 255

import delimited using "input.csv", clear varnames(1)

bysort region_id: gen byte first_r = (_n==1)
gen double zi = share*shock
bysort region_id: egen double z = total(zi)

gen double wr = region_weight*first_r
egen double wtot = total(wr)
gen double e = region_weight/wtot

foreach v in y x z {
    gen double e_`v' = e*`v'*first_r
    egen double m_`v' = total(e_`v')
    gen double `v'0 = `v' - m_`v'
}

gen double sh_e = share*e
bysort industry_id: egen double s_n = total(sh_e)

foreach v in y x z {
    gen double n_`v' = sh_e*`v'0
    bysort industry_id: egen double t_`v' = total(n_`v')
    gen double `v'bar = t_`v'/s_n
}

bysort industry_id: keep if _n==1

mata:
real rowvector ivhc(real colvector dep, real colvector endo, real colvector inst, real colvector w)
{
    real scalar N
    real matrix X, Z, Ainv, S, vcv
    real colvector beta, res
    N = rows(dep)
    X = (J(N,1,1), endo)
    Z = (J(N,1,1), inst)
    Ainv = luinv(Z'(w:*X))
    beta = Ainv*Z'(w:*dep)
    res = dep - X*beta
    S = Z:*(w:*res)
    vcv = N/(N-2)*Ainv*(S'*S)*Ainv'
    return((beta[2], sqrt(vcv[2,2])))
}

dep = st_data(., "ybar")
endo = st_data(., "xbar")
zb = st_data(., "zbar")
sh = st_data(., "shock")
w = st_data(., "s_n")

r1 = ivhc(dep, endo, sh, w)
r2 = ivhc(endo, zb, sh, w)
eff = 1/sum(w:^2)

st_numscalar("b1", r1[1])
st_numscalar("se1", r1[2])
st_numscalar("b2", r2[1])
st_numscalar("se2", r2[2])
st_numscalar("b3", eff)
st_numscalar("nN", rows(dep))
end

display "ANSWER: effect estimate=" %21.12f b1 " se=" %21.12f se1 " n_obs=" %12.0f nN
display "ANSWER: first_stage estimate=" %21.12f b2 " se=" %21.12f se2 " n_obs=" %12.0f nN
display "ANSWER: effective_shocks estimate=" %21.12f b3 " se=." " n_obs=" %12.0f nN
