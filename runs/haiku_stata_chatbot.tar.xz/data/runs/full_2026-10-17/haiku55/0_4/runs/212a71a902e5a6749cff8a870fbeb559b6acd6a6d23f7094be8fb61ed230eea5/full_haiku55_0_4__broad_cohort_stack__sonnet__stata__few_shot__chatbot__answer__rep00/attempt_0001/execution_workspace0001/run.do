clear all
set more off
set type double

import delimited using "input.csv", clear

local cohorts 3 5 7
local wsum 0
local wtot 0

foreach c of local cohorts {
    local lo = `c' - 2
    local hi = `c' + 2

    preserve
    keep if inrange(time, `lo', `hi')
    keep if g == `c' | g == 0 | g > `c' + 2
    bysort id: gen long nwin = _N
    keep if nwin == 5
    gen byte did = (g == `c' & time >= `c')

    egen byte tag = tag(id)
    quietly count if tag & g == `c'
    scalar ntr`c' = r(N)

    quietly regress y did i.id i.time
    scalar att`c' = _b[did]
    scalar rows`c' = e(N)
    restore

    local wsum = `wsum' + ntr`c' * att`c'
    local wtot = `wtot' + ntr`c'
}

scalar att_weighted = `wsum' / `wtot'

display "ANSWER: att_g3 estimate=" %24.16g att3
display "ANSWER: att_g5 estimate=" %24.16g att5
display "ANSWER: att_g7 estimate=" %24.16g att7
display "ANSWER: att_weighted estimate=" %24.16g att_weighted
