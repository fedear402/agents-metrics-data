clear all
set more off

import delimited using "census.csv", clear varnames(1)
summarize nonrecipient_population if eligible==0, meanonly
scalar N0 = r(mean)
summarize nonrecipient_population if eligible==1, meanonly
scalar N1 = r(mean)

import delimited using "households.csv", clear varnames(1)
keep if recipient==0
drop if missing(outcome, dose, baseline, instrument, weight, eligible)

gen byte ne = 1 - eligible
gen double d0 = dose*ne
gen double d1 = dose*eligible
gen double b0 = baseline*ne
gen double b1 = baseline*eligible
gen double z0 = instrument*ne
gen double z1 = instrument*eligible

ivregress 2sls outcome ne eligible b0 b1 (d0 d1 = z0 z1) [pweight=weight], noconstant

scalar n_obs = e(N)
scalar slope0 = _b[d0]
scalar slope1 = _b[d1]

summarize dose [aw=weight] if eligible==0, meanonly
scalar m0 = r(mean)
summarize dose [aw=weight] if eligible==1, meanonly
scalar m1 = r(mean)

scalar e1 = slope0*m0
scalar e2 = slope1*m1
scalar pe = (N0*e1 + N1*e2)/(N0 + N1)

display "ANSWER: ineligible_effect estimate=" trim(string(e1, "%23.15g")) " se=NA n_obs=" trim(string(n_obs, "%12.0f"))
display "ANSWER: eligible_nonrecipient_effect estimate=" trim(string(e2, "%23.15g")) " se=NA n_obs=" trim(string(n_obs, "%12.0f"))
display "ANSWER: population_effect estimate=" trim(string(pe, "%23.15g")) " se=NA n_obs=" trim(string(n_obs, "%12.0f"))
