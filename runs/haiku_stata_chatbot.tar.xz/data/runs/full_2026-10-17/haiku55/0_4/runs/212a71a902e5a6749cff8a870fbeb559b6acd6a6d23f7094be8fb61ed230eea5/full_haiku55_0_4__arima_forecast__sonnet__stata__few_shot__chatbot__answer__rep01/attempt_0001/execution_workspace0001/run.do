clear all
set linesize 255
import delimited using "./input.csv", clear varnames(1)
sort t
tsset t
quietly count if t == 251
if r(N) == 0 {
    quietly tsappend, add(1)
}
arima y, arima(1,1,1) noconstant
local n = e(N)
predict double yhat, y dynamic(250)
predict double mse, mse dynamic(250)
summarize yhat if t == 251, meanonly
scalar f = r(mean)
summarize mse if t == 251, meanonly
scalar fse = sqrt(r(mean))
scalar z = invnormal(0.975)
scalar lo = f - z*fse
scalar hi = f + z*fse
display "ANSWER: forecast estimate=" %21.12f f " se=" %21.12f fse " n_obs=" %12.0f `n'
display "ANSWER: lower_95 estimate=" %21.12f lo " se=." " n_obs=" %12.0f `n'
display "ANSWER: upper_95 estimate=" %21.12f hi " se=." " n_obs=" %12.0f `n'
