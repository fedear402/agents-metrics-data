clear all
set linesize 255

import delimited using "./input.csv", clear
keep if t <= 250
tsset t

arima y, arima(1,1,1) noconstant
local n = e(N)

tsappend, add(1)
predict double fc, y dynamic(251)
predict double se, stdf dynamic(251)

summarize fc if t == 251, meanonly
local f = r(mean)
summarize se if t == 251, meanonly
local s = r(mean)
local lo = `f' - invnormal(0.975)*`s'
local hi = `f' + invnormal(0.975)*`s'

display "ANSWER: forecast estimate=" %21.12f `f' " se=. n_obs=" %12.0f `n'
display "ANSWER: lower_95 estimate=" %21.12f `lo' " se=. n_obs=" %12.0f `n'
display "ANSWER: upper_95 estimate=" %21.12f `hi' " se=. n_obs=" %12.0f `n'
