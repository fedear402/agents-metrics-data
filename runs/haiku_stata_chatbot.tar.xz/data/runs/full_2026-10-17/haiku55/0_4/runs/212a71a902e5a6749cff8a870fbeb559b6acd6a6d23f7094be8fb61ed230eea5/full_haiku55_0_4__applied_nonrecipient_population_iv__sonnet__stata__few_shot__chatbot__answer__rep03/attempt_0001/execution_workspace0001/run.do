clear all
set more off
set type double

import delimited using "households.csv", clear
keep if recipient==0

gen double elig_u = 1-eligible
gen double dose_u = dose*elig_u
gen double dose_e = dose*eligible
gen double base_u = baseline*elig_u
gen double base_e = baseline*eligible
gen double inst_u = instrument*elig_u
gen double inst_e = instrument*eligible

ivregress 2sls outcome elig_u eligible base_u base_e (dose_u dose_e = inst_u inst_e) [aw=weight], noconstant

scalar n_obs = e(N)
gen byte insamp = e(sample)
scalar b_u = _b[dose_u]
scalar b_e = _b[dose_e]

summarize dose [aw=weight] if insamp & eligible==0, meanonly
scalar m0 = r(mean)
summarize dose [aw=weight] if insamp & eligible==1, meanonly
scalar m1 = r(mean)

scalar e0 = b_u*m0
scalar e1 = b_e*m1

import delimited using "census.csv", clear
summarize nonrecipient_population if eligible==0, meanonly
scalar n0 = r(mean)
summarize nonrecipient_population if eligible==1, meanonly
scalar n1 = r(mean)
scalar pop_effect = (e0*n0+e1*n1)/(n0+n1)

display "ANSWER: ineligible_effect estimate=" %24.16g (e0) " se=NA n_obs=" %9.0f (n_obs)
display "ANSWER: eligible_nonrecipient_effect estimate=" %24.16g (e1) " se=NA n_obs=" %9.0f (n_obs)
display "ANSWER: population_effect estimate=" %24.16g (pop_effect) " se=NA n_obs=" %9.0f (n_obs)

exit, clear
