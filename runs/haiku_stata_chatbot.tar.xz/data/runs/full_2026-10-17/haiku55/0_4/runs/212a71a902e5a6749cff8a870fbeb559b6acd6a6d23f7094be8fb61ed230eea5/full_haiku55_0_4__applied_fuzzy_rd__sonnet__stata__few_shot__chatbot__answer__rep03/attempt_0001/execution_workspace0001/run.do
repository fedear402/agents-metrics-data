version 19.0
clear all
set more off
set linesize 255

import delimited using "input.csv", clear varnames(1)

keep if abs(score) < 1
gen double w = 1 - abs(score)
gen byte right = (score >= 0)
gen double s = score

mata:
st_view(S=.,.,"s")
st_view(R=.,.,"right")
st_view(W=.,.,"w")
st_view(Y=.,.,("earnings","participated"))

n = rows(S)
X_l = J(n,1,1), (1:-R), S:*(1:-R)
X_r = J(n,1,1), R, S:*R

Xf = (J(n,1,1), R, S:*(1:-R), S:*R)

B = invsym(Xf'*(W:*Xf))*Xf'*(W:*Y)
E = Y - Xf*B

/* Intercepts: left = b1, right = b1 + b2 ; slopes: left = b3, right = b3 + b4 */
c = (0\1\0\0)'
dvec = (0\1\0\0)
cl = (0\1\0\0)
cr = (0\1\0\0)

disc = (B[2,.])'
disc_r = B[2,.]'
end
