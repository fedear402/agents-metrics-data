version 19.0
clear all
set more off
set linesize 255

import delimited using "input.csv", clear varnames(1)
keep if abs(score)<1
gen double w = 1 - abs(score)
gen byte above = score>=0
gen double r_i = above
gen double r_s = above*score
gen double l_i = 1-above
gen double l_s = (1-above)*score

mata:
X = st_data(., ("r_i","r_s","l_i","l_s"))
w = st_data(., "w")
Y = st_data(., ("earnings","participated"))
B = invsym(X'*(w:*X))
beta = B*X'*(w:*Y)
E = Y - X*beta
cvec = (1\0\-1\0)
jump = cvec'*beta
load = w:*(X*B*cvec)
infl = E:*(load*J(1,2,1))
V = infl'*infl
rf = jump[1]
fs = jump[2]
grad = (1/fs \ -rf/fs^2)
te_se = sqrt(grad'*V*grad)
st_numscalar("rf", rf)
st_numscalar("rf_se", sqrt(V[1,1]))
st_numscalar("fs", fs)
st_numscalar("fs_se", sqrt(V[2,2]))
st_numscalar("te", rf/fs)
st_numscalar("te_se", te_se)
st_numscalar("nobs", rows(X))
end

display "ANSWER: treatment_effect estimate=" %21.12f te " se=" %21.12f te_se " n_obs=" %12.0f nobs
display "ANSWER: reduced_form estimate=" %21.12f rf " se=" %21.12f rf_se " n_obs=" %12.0f nobs
display "ANSWER: first_stage estimate=" %21.12f fs " se=" %21.12f fs_se " n_obs=" %12.0f nobs
