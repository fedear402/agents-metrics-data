clear all
set more off
set linesize 255

import delimited using "input.csv", clear
drop if missing(score, participated, earnings)
keep if abs(score) < 1
gen double w = 1 - abs(score)
gen byte rind = (score >= 0)
gen byte lind = 1 - rind
gen double xr = score * rind
gen double xl = score * lind
local n = _N

mata:
X = st_data(., ("rind", "lind", "xr", "xl"))
w = st_data(., "w")
Y = st_data(., ("participated", "earnings"))
n = rows(X)

WX = X :* (w * J(1, 4, 1))
A = invsym(X' * WX)
B = A * (X' * (Y :* (w * J(1, 2, 1))))
E = Y - X * B

V = J(4, 4, 0)
V11 = J(4, 4, 0)
V12 = J(4, 4, 0)
V22 = J(4, 4, 0)
for (j = 1; j <= 2; j++) {
    for (k = 1; k <= 2; k++) {
        v = w:^2 :* E[, j] :* E[, k]
        M = X' * (X :* (v * J(1, 4, 1)))
        Vjk = A * M * A
        if (j == 1 & k == 1) V11 = Vjk
        if (j == 1 & k == 2) V12 = Vjk
        if (j == 2 & k == 2) V22 = Vjk
    }
}

g = (1 \ -1 \ 0 \ 0)
fs = g' * B[, 1]
rf = g' * B[, 2]
Vfs = g' * V11 * g
Vrf = g' * V22 * g
Cfr = g' * V12 * g

tau = rf / fs
Vtau = (1 / fs)^2 * Vrf + (rf / fs^2)^2 * Vfs - 2 * (1 / fs) * (rf / fs^2) * Cfr

st_numscalar("fs", fs)
st_numscalar("rf", rf)
st_numscalar("tau", tau)
st_numscalar("sefs", sqrt(Vfs))
st_numscalar("serf", sqrt(Vrf))
st_numscalar("setau", sqrt(Vtau))
end

display "ANSWER: treatment_effect estimate=" %21.12f tau " se=" %21.12f setau " n_obs=" %12.0f `n'
display "ANSWER: reduced_form estimate=" %21.12f rf " se=" %21.12f serf " n_obs=" %12.0f `n'
display "ANSWER: first_stage estimate=" %21.12f fs " se=" %21.12f sefs " n_obs=" %12.0f `n'
