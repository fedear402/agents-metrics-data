version 19.0
clear all
set more off
set linesize 255

import delimited using "input.csv", clear varnames(1)

capture confirm string variable date
if _rc == 0 {
    generate double day = date(date, "YMD")
}
else {
    generate double day = date
}

sort day
generate long obs = _n
tsset obs

generate double lvix = log(vix)
generate double dlvix = D.lvix
forvalues k = 1/15 {
    generate double lagdv`k' = L`k'.dlvix
}
generate double lsales = log(sales)

local lagvars ""
forvalues k = 1/15 {
    local lagvars "`lagvars' lagdv`k'"
}

egen double nmiss = rowmiss(lsales `lagvars')
keep if nmiss == 0
drop nmiss

mata:
y = st_data(., "lsales")
Z = st_data(., tokens("`lagvars'"))
X = (J(rows(Z), 1, 1), Z)
N = rows(X)
p = cols(X)
bread = invsym(X' * X)
b = bread * X' * y
e = y - X * b
S = X :* e
L = 15
meat = S' * S
for (j = 1; j <= L; j++) {
    G = S[|j+1, 1 \ N, p|]' * S[|1, 1 \ N-j, p|]
    meat = meat + (1 - j/(L+1)) * (G + G')
}
V = N/(N - p) * bread * meat * bread
c = (0 \ J(15, 1, 1))
st_numscalar("nobs", N)
st_numscalar("cum", c' * b)
st_numscalar("cse", sqrt(c' * V * c))
st_numscalar("b1", b[2])
st_numscalar("se1", sqrt(V[2, 2]))
st_numscalar("b15", b[16])
st_numscalar("se15", sqrt(V[16, 16]))
end

display "ANSWER: cumulative_response estimate=" %21.12f cum " se=" %21.12f cse " n_obs=" %12.0f nobs
display "ANSWER: lag_1 estimate=" %21.12f b1 " se=" %21.12f se1 " n_obs=" %12.0f nobs
display "ANSWER: lag_15 estimate=" %21.12f b15 " se=" %21.12f se15 " n_obs=" %12.0f nobs
