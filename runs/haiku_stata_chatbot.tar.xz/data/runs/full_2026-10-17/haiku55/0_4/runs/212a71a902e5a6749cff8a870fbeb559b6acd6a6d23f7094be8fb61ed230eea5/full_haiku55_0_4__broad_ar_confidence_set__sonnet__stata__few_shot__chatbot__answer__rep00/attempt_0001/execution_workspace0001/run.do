clear all
set more off
set linesize 255
set type double

import delimited using "input.csv", clear varnames(1)

mata:
real scalar qf(real colvector a, real colvector b, real matrix X)
{
    return(a'b - (a'X)*invsym(X'X)*(X'b))
}

y = st_data(., "y")
E = st_data(., "endog")
x = st_data(., "x")
Z = st_data(., ("z1", "z2"))
n = rows(y)
W = (J(n, 1, 1), x)
Fm = (W, Z)
df = n - 4
crit = invFtail(2, df, 0.05)
kk = 2 * crit / df

A = qf(E, E, W) - (1 + kk) * qf(E, E, Fm)
B = -2 * (qf(y, E, W) - (1 + kk) * qf(y, E, Fm))
C = qf(y, y, W) - (1 + kk) * qf(y, y, Fm)
disc = B^2 - 4 * A * C
r1 = (-B - sqrt(disc)) / (2 * A)
r2 = (-B + sqrt(disc)) / (2 * A)

st_numscalar("lo", min((r1, r2)))
st_numscalar("hi", max((r1, r2)))
st_numscalar("accepts_zero", C <= 0)
st_numscalar("unbounded", A < 0)

e1 = y - E
ssrR1 = qf(e1, e1, W)
ssrU1 = qf(e1, e1, Fm)
st_numscalar("ar_f1", ((ssrR1 - ssrU1) / 2) / (ssrU1 / df))
st_numscalar("nobs", n)
end

display "ANSWER: boundary_low estimate=" %21.12f lo " se=. n_obs=" %12.0f nobs
display "ANSWER: boundary_high estimate=" %21.12f hi " se=. n_obs=" %12.0f nobs
display "ANSWER: accepts_zero estimate=" %12.0f accepts_zero " se=. n_obs=" %12.0f nobs
display "ANSWER: unbounded estimate=" %12.0f unbounded " se=. n_obs=" %12.0f nobs
display "ANSWER: ar_f_at_one estimate=" %21.12f ar_f1 " se=. n_obs=" %12.0f nobs
