clear all
set more off
set linesize 255

import delimited using "input.csv", clear varnames(1)

gen double sz = share*shock
bysort region_id: egen double z = total(sz)

egen byte tagr = tag(region_id)
gen double rw_t = region_weight*tagr
quietly summarize rw_t
scalar Wsum = r(sum)
gen double e = region_weight/Wsum

gen double ey_t = e*y*tagr
gen double ex_t = e*x*tagr
gen double ez_t = e*z*tagr
quietly summarize ey_t
scalar my = r(sum)
quietly summarize ex_t
scalar mx = r(sum)
quietly summarize ez_t
scalar mz = r(sum)

gen double y0 = y - my
gen double x0 = x - mx
gen double z0 = z - mz

preserve
keep if tagr == 1
ivregress 2sls y (x = z) [aweight=e]
scalar reg_eff = _b[x]
restore

preserve
keep if tagr == 1
regress x z [aweight=e]
scalar reg_fs = _b[z]
restore

gen double esh = e*share
bysort industry_id: egen double s = total(esh)

bysort industry_id: egen double ysum = total(esh*y0)
bysort industry_id: egen double xsum = total(esh*x0)
bysort industry_id: egen double zsum = total(esh*z0)
gen double ybar = ysum/s
gen double xbar = xsum/s
gen double zbar = zsum/s

egen byte tagn = tag(industry_id)
keep if tagn == 1
quietly count
scalar Nind = r(N)

gen double s2 = s^2
quietly summarize s2
scalar sum_s2 = r(sum)

mata:
void iv_hc1(string scalar yv, string scalar xv, string scalar zv, string scalar wv)
{
    real colvector y, x, z, w, u, bvec
    real matrix X, Z, Ginv, M, V
    real scalar N
    y = st_data(., yv)
    x = st_data(., xv)
    z = st_data(., zv)
    w = st_data(., wv)
    N = rows(y)
    X = (J(N,1,1), x)
    Z = (J(N,1,1), z)
    Ginv = luinv(cross(Z, w, X))
    bvec = Ginv * cross(Z, w, y)
    u = y - X*bvec
    M = cross(Z, w:^2 :* u:^2, Z)
    V = (N/(N-2)) * Ginv * M * Ginv'
    st_numscalar("iv_b", bvec[2])
    st_numscalar("iv_se", sqrt(V[2,2]))
}
end

mata: iv_hc1("ybar", "xbar", "shock", "s")
scalar se_eff = iv_se

mata: iv_hc1("xbar", "zbar", "shock", "s")
scalar se_fs = iv_se

display "ANSWER: effect estimate=" %21.12f reg_eff " se=" %21.12f se_eff " n_obs=" %12.0f Nind
display "ANSWER: first_stage estimate=" %21.12f reg_fs " se=" %21.12f se_fs " n_obs=" %12.0f Nind
display "ANSWER: effective_shocks estimate=" %21.12f 1/sum_s2 " se=. n_obs=" %12.0f Nind
