clear all
set more off
set linesize 255
set type double

import delimited using "input.csv", clear varnames(1)
scalar n_obs = _N

mata:
y  = st_data(., "y")
en = st_data(., "endog")
x  = st_data(., "x")
Z  = st_data(., ("z1", "z2"))
n  = rows(y)
dfr = n - 4
k   = 2 * invFtail(2, dfr, 0.05) / dfr

X  = J(n, 1, 1), x
MX = I(n) - X * invsym(X' * X) * X'
Yt = MX * y
Et = MX * en
Zt = MX * Z
PZ = Zt * invsym(Zt' * Zt) * Zt'
G  = (1 + k) * PZ - k * I(n)

A = Et' * G * Et
B = -2 * Et' * G * Yt
C = Yt' * G * Yt
disc = B^2 - 4 * A * C
r = sort(((-B - sqrt(disc)) / (2 * A)) \ ((-B + sqrt(disc)) / (2 * A)), 1)

a     = Yt - Et
ssr_r = a' * a
ssr_u = a' * (I(n) - PZ) * a
f_at_one = ((ssr_r - ssr_u) / 2) / (ssr_u / dfr)

st_numscalar("boundary_low", r[1])
st_numscalar("boundary_high", r[2])
st_numscalar("accepts_zero", (C <= 0))
st_numscalar("unbounded", (A < 0))
st_numscalar("ar_f_at_one", f_at_one)
end

display "ANSWER: boundary_low estimate=" %21.12f boundary_low " se=" "." " n_obs=" %12.0f n_obs
display "ANSWER: boundary_high estimate=" %21.12f boundary_high " se=" "." " n_obs=" %12.0f n_obs
display "ANSWER: accepts_zero estimate=" %21.12f accepts_zero " se=" "." " n_obs=" %12.0f n_obs
display "ANSWER: unbounded estimate=" %21.12f unbounded " se=" "." " n_obs=" %12.0f n_obs
display "ANSWER: ar_f_at_one estimate=" %21.12f ar_f_at_one " se=" "." " n_obs=" %12.0f n_obs
