clear all
set more off
set linesize 255

import delimited using "input.csv", clear

capture confirm string variable date
if _rc == 0 {
    gen double dt = date(date, "YMD")
}
else {
    gen double dt = date
}
sort dt

gen double lnsales = ln(sales)
gen double lnvix = ln(vix)
gen double dlv = lnvix - lnvix[_n-1] if _n > 1

local rhs ""
forvalues k = 1/15 {
    gen double lag`k' = dlv[_n-`k'] if _n > `k'
    local rhs "`rhs' lag`k'"
}

gen byte touse = !missing(lnsales)
forvalues k = 1/15 {
    replace touse = 0 if missing(lag`k')
}

newey lnsales `rhs' if touse == 1, lag(15)

scalar N = e(N)
matrix b = e(b)
matrix V = e(V) * N / (N - 16)

matrix c = J(1, colsof(b), 0)
forvalues k = 1/15 {
    local j = colnumb(b, "lag`k'")
    matrix c[1, `j'] = 1
}

matrix cb = c * b'
matrix cv = c * V * c'
scalar cum_est = cb[1,1]
scalar cum_se = sqrt(cv[1,1])

local j1 = colnumb(b, "lag1")
local j15 = colnumb(b, "lag15")
scalar est1 = b[1, `j1']
scalar se1 = sqrt(V[`j1', `j1'])
scalar est15 = b[1, `j15']
scalar se15 = sqrt(V[`j15', `j15'])

display "ANSWER: cumulative_response estimate=" %21.12f cum_est " se=" %21.12f cum_se " n_obs=" %12.0f N
display "ANSWER: lag_1 estimate=" %21.12f est1 " se=" %21.12f se1 " n_obs=" %12.0f N
display "ANSWER: lag_15 estimate=" %21.12f est15 " se=" %21.12f se15 " n_obs=" %12.0f N
