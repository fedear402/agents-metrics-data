clear all
set more off
set type double

import delimited using "crosswalk.csv", clear stringcols(_all)
replace code = strtrim(code)
replace industry = strtrim(industry)
keep code industry
duplicates drop
tempfile xw
save `xw'

import delimited using "trade.csv", clear stringcols(_all)
replace code = strtrim(code)
destring period us_change other_change price_index years, replace
merge m:1 code using `xw', keep(match) nogen
keep period industry us_change other_change price_index years
duplicates drop
tempfile trd
save `trd'

import delimited using "employment.csv", clear stringcols(_all)
replace vintage = strtrim(vintage)
replace industry = strtrim(industry)
destring area period employment, replace
keep area period vintage industry employment
egen double national = total(employment), by(period vintage industry)
merge m:1 period industry using `trd', keep(match) nogen
tempfile emp
save `emp'

import delimited using "areas.csv", clear stringcols(_all)
replace vintage = strtrim(vintage)
destring area period total_employment population, replace
keep area period vintage total_employment population
tempfile ar
save `ar'

use `emp', clear
merge m:1 area period vintage using `ar', keep(match) nogen

gen double share = employment/total_employment
gen double scale = (10/years)/1000/(price_index/100)
gen double term_x = share*us_change/national*scale if vintage=="base"
gen double term_z = share*other_change/national*scale if vintage=="early"
gen double pop = population if vintage=="base"

egen double x = total(term_x), by(area period)
egen double z = total(term_z), by(area period)
egen double popw = max(pop), by(area period)
bysort area period: keep if _n==1
keep area period x z popw
tempfile expo
save `expo'

import delimited using "outcomes.csv", clear stringcols(_all)
destring area period change_pp control, replace
keep area period control change_pp
merge 1:1 area period using `expo', keep(match) nogen

quietly summarize x if area==0 & period==0, meanonly
scalar x00 = r(mean)
quietly summarize x if area==0 & period==1, meanonly
scalar x01 = r(mean)
quietly summarize z if area==0 & period==0, meanonly
scalar z00 = r(mean)

ivregress 2sls change_pp period control (x = z) [aw=popw]
local nobs = e(N)
scalar b_iv = _b[x]

display "ANSWER: iv_slope estimate=" trim(string(b_iv,"%24.16g")) " se=NA n_obs=" `nobs'
display "ANSWER: exposure_area0_period0 estimate=" trim(string(x00,"%24.16g")) " se=NA n_obs=" `nobs'
display "ANSWER: exposure_area0_period1 estimate=" trim(string(x01,"%24.16g")) " se=NA n_obs=" `nobs'
display "ANSWER: instrument_area0_period0 estimate=" trim(string(z00,"%24.16g")) " se=NA n_obs=" `nobs'
