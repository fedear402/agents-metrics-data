clear all
set more off
set type double

import delimited using "crosswalk.csv", clear varnames(1)
tempfile xw
save `xw'

import delimited using "trade.csv", clear varnames(1)
merge m:1 code using `xw', keep(match) nogen
keep period industry us_change other_change price_index years
tempfile trd
save `trd'

import delimited using "areas.csv", clear varnames(1)
tempfile areas
save `areas'
keep if vintage == "base"
keep area period population
tempfile popf
save `popf'

use `areas', clear
keep area period vintage total_employment
gen byte one = 1
tempfile areasone
save `areasone'

use `xw', clear
keep industry
duplicates drop
gen byte one = 1
joinby one using `areasone'
drop one
tempfile grid
save `grid'

import delimited using "employment.csv", clear varnames(1)
tempfile emp
save `emp'

use `grid', clear
merge 1:1 area period vintage industry using `emp', keep(master match) nogen
replace employment = 0 if missing(employment)

merge m:1 period industry using `trd', keep(match) nogen
egen double nat = total(employment), by(period vintage industry)
gen double w = (employment/total_employment)/(price_index/100)/1000*(10/years)
gen double tx = cond(vintage=="base", w*us_change/nat, 0)
gen double tz = cond(vintage=="early", w*other_change/nat, 0)
collapse (sum) x=tx z=tz, by(area period)
tempfile expo
save `expo'

import delimited using "outcomes.csv", clear varnames(1)
merge 1:1 area period using `expo', keep(match) nogen
merge 1:1 area period using `popf', keep(match) nogen

ivregress 2sls change_pp period control (x = z) [aw=population]
scalar bx = _b[x]
scalar nobs = e(N)

summarize x if area==0 & period==0, meanonly
scalar ex00 = r(mean)
summarize x if area==0 & period==1, meanonly
scalar ex01 = r(mean)
summarize z if area==0 & period==0, meanonly
scalar iz00 = r(mean)

display "ANSWER: iv_slope estimate=" trim(string(scalar(bx), "%24.16g")) " se=NA n_obs=" trim(string(scalar(nobs), "%12.0f"))
display "ANSWER: exposure_area0_period0 estimate=" trim(string(scalar(ex00), "%24.16g")) " se=NA n_obs=" trim(string(scalar(nobs), "%12.0f"))
display "ANSWER: exposure_area0_period1 estimate=" trim(string(scalar(ex01), "%24.16g")) " se=NA n_obs=" trim(string(scalar(nobs), "%12.0f"))
display "ANSWER: instrument_area0_period0 estimate=" trim(string(scalar(iz00), "%24.16g")) " se=NA n_obs=" trim(string(scalar(nobs), "%12.0f"))
