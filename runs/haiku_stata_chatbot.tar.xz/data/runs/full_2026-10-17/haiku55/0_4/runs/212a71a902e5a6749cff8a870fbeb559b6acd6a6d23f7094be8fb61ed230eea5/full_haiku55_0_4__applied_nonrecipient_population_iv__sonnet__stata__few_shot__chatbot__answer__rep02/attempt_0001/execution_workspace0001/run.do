clear all
set more off
set type double

import delimited using "households.csv", clear varnames(1)
keep if recipient==0

gen double d0 = dose*(1-eligible)
gen double d1 = dose*eligible
gen double b0 = baseline*(1-eligible)
gen double b1 = baseline*eligible
gen double i0 = instrument*(1-eligible)
gen double i1 = instrument*eligible
gen double ne0 = 1-eligible
gen double ne1 = eligible

ivregress 2sls outcome ne0 ne1 b0 b1 (d0 d1 = i0 i1) [aw=weight], noconstant
scalar nobs = e(N)
scalar s0 = _b[d0]
scalar s1 = _b[d1]
generate byte est = e(sample)

summarize dose [aw=weight] if est & eligible==0, meanonly
scalar e0 = s0*r(mean)
summarize dose [aw=weight] if est & eligible==1, meanonly
scalar e1 = s1*r(mean)

import delimited using "census.csv", clear varnames(1)
summarize nonrecipient_population if eligible==0, meanonly
scalar n0 = r(mean)
summarize nonrecipient_population if eligible==1, meanonly
scalar n1 = r(mean)
scalar pop = (e0*n0+e1*n1)/(n0+n1)

display "ANSWER: ineligible_effect estimate=" strtrim(string(e0,"%24.16g")) " se=NA n_obs=" strtrim(string(nobs,"%12.0f"))
display "ANSWER: eligible_nonrecipient_effect estimate=" strtrim(string(e1,"%24.16g")) " se=NA n_obs=" strtrim(string(nobs,"%12.0f"))
display "ANSWER: population_effect estimate=" strtrim(string(pop,"%24.16g")) " se=NA n_obs=" strtrim(string(nobs,"%12.0f"))

exit, clear
