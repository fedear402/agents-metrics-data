clear all
set more off
set linesize 255

import delimited using "input.csv", clear varnames(1)

keep if abs(score) < 1
gen double w = 1 - abs(score)
gen double right = (score >= 0)
gen double left = 1 - right
gen double rs = right * score
gen double ls = left * score
count
local nobs = r(N)

mata:
Z = st_data(., ("right", "rs", "left", "ls"))
w = st_data(., "w")
yE = st_data(., "earnings")
yD = st_data(., "participated")

A = cross(Z, w, Z)
Ai = invsym(A)
bE = Ai * cross(Z, w, yE)
bD = Ai * cross(Z, w, yD)
eE = yE - Z * bE
eD = yD - Z * bD

V_EE = Ai * cross(Z, w:^2 :* eE:^2, Z) * Ai
V_DD = Ai * cross(Z, w:^2 :* eD:^2, Z) * Ai
V_ED = Ai * cross(Z, w:^2 :* eE :* eD, Z) * Ai

g = (1 \ 0 \ -1 \ 0)
rf = g' * bE
fs = g' * bD
vrf = g' * V_EE * g
vfs = g' * V_DD * g
cvr = g' * V_ED * g

tau = rf / fs
grad = (1/fs, -rf/fs^2)
Sg = (vrf, cvr \ cvr, vfs)
vtau = grad * Sg * grad'

st_numscalar("rf_est", rf)
st_numscalar("rf_se", sqrt(vrf))
st_numscalar("fs_est", fs)
st_numscalar("fs_se", sqrt(vfs))
st_numscalar("tau_est", tau)
st_numscalar("tau_se", sqrt(vtau))
end

display "ANSWER: treatment_effect estimate=" %21.12f tau_est " se=" %21.12f tau_se " n_obs=" %12.0f `nobs'
display "ANSWER: reduced_form estimate=" %21.12f rf_est " se=" %21.12f rf_se " n_obs=" %12.0f `nobs'
display "ANSWER: first_stage estimate=" %21.12f fs_est " se=" %21.12f fs_se " n_obs=" %12.0f `nobs'
