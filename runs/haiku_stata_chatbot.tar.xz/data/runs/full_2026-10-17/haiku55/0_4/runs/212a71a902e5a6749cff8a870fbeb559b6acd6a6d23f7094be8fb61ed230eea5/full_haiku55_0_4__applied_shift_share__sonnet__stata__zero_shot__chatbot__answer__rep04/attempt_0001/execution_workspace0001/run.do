clear all
set more off
set linesize 255

import delimited using "input.csv", clear

egen byte tagr = tag(region_id)
egen byte tagi = tag(industry_id)

gen double rwt = region_weight*tagr
egen double Wtot = total(rwt)
gen double e = region_weight/Wtot

gen double prodsz = share*shock
bysort region_id: egen double z = total(prodsz)

gen double ey_t = e*y*tagr
gen double ex_t = e*x*tagr
gen double ez_t = e*z*tagr
egen double my = total(ey_t)
egen double mx = total(ex_t)
egen double mz = total(ez_t)

gen double y0 = y - my
gen double x0 = x - mx
gen double z0 = z - mz

preserve
keep if tagr
ivregress 2sls y (x = z) [aw=e]
scalar b_eff = _b[x]
regress x z [aw=e]
scalar b_fs = _b[z]
restore

gen double es = e*share
bysort industry_id: egen double s = total(es)

gen double esy = e*share*y0
gen double esx = e*share*x0
gen double esz = e*share*z0
bysort industry_id: egen double Ty = total(esy)
bysort industry_id: egen double Tx = total(esx)
bysort industry_id: egen double Tz = total(esz)
gen double ybar = Ty/s
gen double xbar = Tx/s
gen double zbar = Tz/s

keep if tagi
scalar Nind = _N

mata:
real rowvector iv_se(real colvector y, real colvector x, real colvector zi, real colvector w)
{
    real scalar N
    real matrix X, Z, A, Ainv, M, V
    real colvector b, u
    N = rows(y)
    X = (J(N,1,1), x)
    Z = (J(N,1,1), zi)
    A = cross(Z, w, X)
    Ainv = invsym(A)
    b = Ainv * cross(Z, w, y)
    u = y - X*b
    M = cross(Z, (w:*u):^2, Z)
    V = Ainv * M * Ainv' * N/(N-2)
    return((b[2], sqrt(V[2,2])))
}

real rowvector r1, r2
r1 = iv_se(st_data(., "ybar"), st_data(., "xbar"), st_data(., "shock"), st_data(., "s"))
r2 = iv_se(st_data(., "xbar"), st_data(., "zbar"), st_data(., "shock"), st_data(., "s"))
st_numscalar("se_eff", r1[2])
st_numscalar("se_fs", r2[2])
end

gen double s2 = s^2
quietly summarize s2
scalar effsh = 1/r(sum)

display "ANSWER: effect estimate=" %21.12f b_eff " se=" %21.12f se_eff " n_obs=" %12.0f Nind
display "ANSWER: first_stage estimate=" %21.12f b_fs " se=" %21.12f se_fs " n_obs=" %12.0f Nind
display "ANSWER: effective_shocks estimate=" %21.12f effsh " se=." " n_obs=" %12.0f Nind
