version 19.0
clear all
set more off
set linesize 255

import delimited using "input.csv", clear

mata:
real rowvector shockiv(real colvector yb, real colvector xb, real colvector ib, real colvector s)
{
    real scalar N
    real matrix X, Z, A, Ai, Om, V
    real colvector beta, u

    N = rows(yb)
    X = (J(N,1,1), xb)
    Z = (J(N,1,1), ib)
    A = Z' * diag(s) * X
    Ai = luinv(A)
    beta = Ai * Z' * diag(s) * yb
    u = yb - X*beta
    Om = Z' * diag(s:^2 :* u:^2) * Z
    V = N/(N-2) * Ai * Om * Ai'
    return((beta[2], sqrt(V[2,2])))
}

X = st_data(., ("region_id","industry_id","share","shock","region_weight","x","y"))
reg = uniqrows(X[,1])
ind = uniqrows(X[,2])
R = rows(reg)
N = rows(ind)

S = J(R,N,0)
sh = J(N,1,.)
w = J(R,1,.)
xr = J(R,1,.)
yr = J(R,1,.)
for (i=1; i<=rows(X); i++) {
    r = selectindex(reg:==X[i,1])[1]
    n = selectindex(ind:==X[i,2])[1]
    S[r,n] = X[i,3]
    sh[n] = X[i,4]
    w[r] = X[i,5]
    xr[r] = X[i,6]
    yr[r] = X[i,7]
}

e = w :/ sum(w)
zr = S * sh

y0 = yr :- sum(e:*yr)
x0 = xr :- sum(e:*xr)
z0 = zr :- sum(e:*zr)

s = S' * e
ybar = (S' * (e:*y0)) :/ s
xbar = (S' * (e:*x0)) :/ s
zbar = (S' * (e:*z0)) :/ s

eff = shockiv(ybar, xbar, sh, s)
fs_se = shockiv(xbar, zbar, sh, s)[2]
fs_est = sum(e:*z0:*x0) / sum(e:*z0:^2)
effsh = 1 / sum(s:^2)

st_numscalar("b_eff", eff[1])
st_numscalar("se_eff", eff[2])
st_numscalar("b_fs", fs_est)
st_numscalar("se_fs", fs_se)
st_numscalar("b_sh", effsh)
st_numscalar("nind", N)
end

display "ANSWER: effect estimate=" %21.12f b_eff " se=" %21.12f se_eff " n_obs=" %12.0f nind
display "ANSWER: first_stage estimate=" %21.12f b_fs " se=" %21.12f se_fs " n_obs=" %12.0f nind
display "ANSWER: effective_shocks estimate=" %21.12f b_sh " se=." " n_obs=" %12.0f nind
