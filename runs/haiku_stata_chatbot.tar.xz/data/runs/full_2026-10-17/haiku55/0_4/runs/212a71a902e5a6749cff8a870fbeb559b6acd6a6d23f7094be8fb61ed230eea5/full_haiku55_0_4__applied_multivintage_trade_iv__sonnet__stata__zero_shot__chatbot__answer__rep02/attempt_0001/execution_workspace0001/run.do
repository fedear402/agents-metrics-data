clear all
set more off

import delimited using "crosswalk.csv", clear varnames(1)
duplicates drop code, force
tempfile cw
save `cw'

import delimited using "trade.csv", clear varnames(1)
merge m:1 code using `cw', keep(match) nogen
keep period industry us_change other_change price_index years
tempfile tr
save `tr'

import delimited using "employment.csv", clear varnames(1)
tempfile emp
save `emp'

import delimited using "areas.csv", clear varnames(1)
preserve
keep if vintage == "base"
keep area period population
tempfile pop
save `pop'
restore
keep area period vintage total_employment
tempfile ar
save `ar'

use `cw', clear
keep industry
duplicates drop
gen byte k = 1
tempfile indk
save `indk'

use `ar', clear
gen byte k = 1
joinby k using `indk'
drop k
merge 1:1 area period vintage industry using `emp', keep(master match) nogen
replace employment = 0 if missing(employment)

bysort period vintage industry: egen double natemp = total(employment)
gen double share = employment / total_employment
merge m:1 period industry using `tr', keep(match) nogen

gen double term_x = share * (us_change / natemp) / (price_index / 100) / 1000 * (10 / years) if vintage == "base"
gen double term_z = share * (other_change / natemp) / (price_index / 100) / 1000 * (10 / years) if vintage == "early"

collapse (sum) x = term_x z = term_z, by(area period)
tempfile expo
save `expo'

import delimited using "outcomes.csv", clear varnames(1)
merge 1:1 area period using `expo', keep(match) nogen
merge 1:1 area period using `pop', keep(match) nogen

ivregress 2sls change_pp period control (x = z) [pweight = population]
local nobs = e(N)
scalar b_iv = _b[x]

summarize x if area == 0 & period == 0, meanonly
scalar ex0 = r(mean)
summarize x if area == 0 & period == 1, meanonly
scalar ex1 = r(mean)
summarize z if area == 0 & period == 0, meanonly
scalar iz0 = r(mean)

display "ANSWER: iv_slope estimate=" trim(string(b_iv, "%20.12f")) " se=NA n_obs=" `nobs'
display "ANSWER: exposure_area0_period0 estimate=" trim(string(ex0, "%20.12f")) " se=NA n_obs=" `nobs'
display "ANSWER: exposure_area0_period1 estimate=" trim(string(ex1, "%20.12f")) " se=NA n_obs=" `nobs'
display "ANSWER: instrument_area0_period0 estimate=" trim(string(iz0, "%20.12f")) " se=NA n_obs=" `nobs'
