version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear stringcols(1)

generate double day = date(date, "YMD")
sort day
generate long obs = _n
tsset obs

generate double log_vix = ln(vix)
generate double vol_change = D.log_vix
generate double log_sales = ln(sales)

forvalues j = 1/15 {
    generate double lag_`j' = L`j'.vol_change
}

regress log_sales lag_1-lag_15 if !missing(log_sales, lag_1, lag_15)
local N = e(N)
local K = 16

matrix b = e(b)
matrix V_ols = e(V)

tempname X_mat
mata:
    st_view(X=., ., ("lag_1","lag_2","lag_3","lag_4","lag_5","lag_6","lag_7","lag_8","lag_9","lag_10","lag_11","lag_12","lag_13","lag_14","lag_15"), st_local("touse"))
    X = J(rows(X), 1, 1), X
    y = st_data(., "log_sales", st_local("touse"))
    beta = qrsolve(X, y)
    resid = y - X*beta
    n = rows(X)
    p = cols(X)
    scores = X :* resid
    meat = scores'*scores
    for (j=1; j<=15; j++) {
        w = 1 - j/16
        gamma = scores[|j+1,1 \ n,p|]'*scores[|1,1 \ n-j,p|]
        meat = meat + w*(gamma + gamma')
    }
    bread = invsym(X'*X)
    V_nw = (n/(n-16)) * bread * meat * bread
    c = (0 \ J(15,1,1))
    cum_est = c'*beta
    cum_se = sqrt(c'*V_nw*c)
    st_numscalar("cum_est", cum_est)
    st_numscalar("cum_se", cum_se)
    st_numscalar("l1_est", beta[2])
    st_numscalar("l1_se", sqrt(V_nw[2,2]))
    st_numscalar("l15_est", beta[16])
    st_numscalar("l15_se", sqrt(V_nw[16,16]))
    st_numscalar("nobs", n)
end

display "ANSWER: cumulative_response estimate=" %21.12f cum_est " se=" %21.12f cum_se " n_obs=" %12.0f nobs
display "ANSWER: lag_1 estimate=" %21.12f l1_est " se=" %21.12f l1_se " n_obs=" %12.0f nobs
display "ANSWER: lag_15 estimate=" %21.12f l15_est " se=" %21.12f l15_se " n_obs=" %12.0f nobs
