version 19.0
clear all
set more off
set linesize 255

import delimited using "input.csv", clear varnames(1)

keep if abs(score) < 1
gen double w = 1 - abs(score)
gen double above = (score >= 0)
gen double s_above = score * above
gen double one = 1

mata:
X = st_data(., ("one", "above", "score", "s_above"))
w = st_data(., "w")
Y = st_data(., ("earnings", "participated"))
bread = invsym(X' * (w :* X))
B = bread * X' * (w :* Y)
E = Y - X * B
U1 = X :* (w :* E[,1])
U2 = X :* (w :* E[,2])
V11 = bread * (U1' * U1) * bread
V12 = bread * (U1' * U2) * bread
V22 = bread * (U2' * U2) * bread
c = (0 \ 1 \ 0 \ 0)
rf = (c' * B[,1])[1,1]
fs = (c' * B[,2])[1,1]
v11 = (c' * V11 * c)[1,1]
v12 = (c' * V12 * c)[1,1]
v22 = (c' * V22 * c)[1,1]
S = (v11, v12 \ v12, v22)
g = (1/fs \ -rf/fs^2)
te = rf/fs
te_se = sqrt((g' * S * g)[1,1])
st_numscalar("rf_est", rf)
st_numscalar("rf_se", sqrt(v11))
st_numscalar("fs_est", fs)
st_numscalar("fs_se", sqrt(v22))
st_numscalar("te_est", te)
st_numscalar("te_se", te_se)
st_numscalar("n_obs", rows(X))
end

display "ANSWER: treatment_effect estimate=" %21.12f te_est " se=" %21.12f te_se " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f rf_est " se=" %21.12f rf_se " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f fs_est " se=" %21.12f fs_se " n_obs=" %12.0f n_obs
