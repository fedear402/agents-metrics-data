clear all
set more off
set linesize 255

import delimited using "input.csv", clear varnames(1)

capture confirm string variable date
if _rc == 0 {
    gen double dt = date(date, "YMD")
}
else {
    gen double dt = date
}
sort dt
gen double tindex = _n
tsset tindex

gen double lsales = ln(sales)
gen double lvix = ln(vix)
gen double dlv = D.lvix

newey lsales L(1/15).dlv, lag(15)

scalar N_reg = e(N)
scalar adj = N_reg / (N_reg - 16)
matrix b = e(b)
matrix V = e(V) * adj

matrix c = J(colsof(b), 1, 0)
forvalues j = 1/15 {
    local p = colnumb(b, "L`j'.dlv")
    matrix c[`p', 1] = 1
}
matrix est_cum_m = c' * b'
matrix var_cum_m = c' * V * c
scalar est_cum = est_cum_m[1,1]
scalar se_cum = sqrt(var_cum_m[1,1])

local p1 = colnumb(b, "L1.dlv")
scalar est_1 = b[1, `p1']
scalar se_1 = sqrt(V[`p1', `p1'])

local p15 = colnumb(b, "L15.dlv")
scalar est_15 = b[1, `p15']
scalar se_15 = sqrt(V[`p15', `p15'])

display "ANSWER: cumulative_response estimate=" %21.12f est_cum " se=" %21.12f se_cum " n_obs=" %12.0f N_reg
display "ANSWER: lag_1 estimate=" %21.12f est_1 " se=" %21.12f se_1 " n_obs=" %12.0f N_reg
display "ANSWER: lag_15 estimate=" %21.12f est_15 " se=" %21.12f se_15 " n_obs=" %12.0f N_reg
