clear all
set more off
version 17

import delimited using "households.csv", clear varnames(1)
keep if recipient == 0

gen double e0 = 1 - eligible
gen double e1 = eligible
gen double d0 = dose * (1 - eligible)
gen double d1 = dose * eligible
gen double b0 = baseline * (1 - eligible)
gen double b1 = baseline * eligible
gen double z0 = instrument * (1 - eligible)
gen double z1 = instrument * eligible

ivregress 2sls outcome e0 e1 b0 b1 (d0 d1 = z0 z1) [aweight = weight], noconstant

scalar n_obs = e(N)
scalar s0 = _b[d0]
scalar s1 = _b[d1]

summarize dose [aweight = weight] if e(sample) & eligible == 0, meanonly
scalar m0 = r(mean)
summarize dose [aweight = weight] if e(sample) & eligible == 1, meanonly
scalar m1 = r(mean)

scalar ineligible_effect = s0 * m0
scalar eligible_nonrecipient_effect = s1 * m1

preserve
import delimited using "census.csv", clear varnames(1)
summarize nonrecipient_population if eligible == 0, meanonly
scalar p0 = r(mean)
summarize nonrecipient_population if eligible == 1, meanonly
scalar p1 = r(mean)
restore

scalar w0 = p0 / (p0 + p1)
scalar w1 = p1 / (p0 + p1)
scalar population_effect = w0 * ineligible_effect + w1 * eligible_nonrecipient_effect

display "ANSWER: ineligible_effect estimate=" strtrim(string(ineligible_effect, "%18.12f")) " se=NA n_obs=" strtrim(string(n_obs, "%12.0f"))
display "ANSWER: eligible_nonrecipient_effect estimate=" strtrim(string(eligible_nonrecipient_effect, "%18.12f")) " se=NA n_obs=" strtrim(string(n_obs, "%12.0f"))
display "ANSWER: population_effect estimate=" strtrim(string(population_effect, "%18.12f")) " se=NA n_obs=" strtrim(string(n_obs, "%12.0f"))
