clear all
set linesize 255
import delimited using "input.csv", clear
tsset t
arima y, arima(1,1,1) noconstant
local n = e(N)
predict double yhat, y
predict double mse, mse
summarize yhat if t==251, meanonly
scalar f = r(mean)
summarize mse if t==251, meanonly
scalar s = sqrt(r(mean))
scalar lo = f - invnormal(0.975)*s
scalar hi = f + invnormal(0.975)*s
display "ANSWER: forecast estimate=" %21.12f f " se=" %21.12f s " n_obs=" %12.0f `n'
display "ANSWER: lower_95 estimate=" %21.12f lo " se=. n_obs=" %12.0f `n'
display "ANSWER: upper_95 estimate=" %21.12f hi " se=. n_obs=" %12.0f `n'
