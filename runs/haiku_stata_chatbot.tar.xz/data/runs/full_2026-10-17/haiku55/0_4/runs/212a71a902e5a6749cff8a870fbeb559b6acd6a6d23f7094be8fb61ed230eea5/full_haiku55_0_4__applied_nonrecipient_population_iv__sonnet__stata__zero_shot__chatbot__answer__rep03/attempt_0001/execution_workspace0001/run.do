clear all
set more off

import delimited using "census.csv", clear varnames(1)
summarize nonrecipient_population if eligible==0, meanonly
local N0 = r(mean)
summarize nonrecipient_population if eligible==1, meanonly
local N1 = r(mean)

import delimited using "households.csv", clear varnames(1)
keep if recipient==0

gen byte x0 = 1-eligible
gen byte x1 = eligible
gen double b0 = baseline*(1-eligible)
gen double b1 = baseline*eligible
gen double d0 = dose*(1-eligible)
gen double d1 = dose*eligible
gen double z0 = instrument*(1-eligible)
gen double z1 = instrument*eligible

ivregress 2sls outcome x0 x1 b0 b1 (d0 d1 = z0 z1) [aweight=weight], noconstant

local n_obs = e(N)
local slope0 = _b[d0]
local slope1 = _b[d1]

summarize dose [aweight=weight] if eligible==0, meanonly
local m0 = r(mean)
summarize dose [aweight=weight] if eligible==1, meanonly
local m1 = r(mean)

local ineligible_effect = `slope0'*`m0'
local eligible_nonrecipient_effect = `slope1'*`m1'
local population_effect = (`N0'*`ineligible_effect' + `N1'*`eligible_nonrecipient_effect')/(`N0'+`N1')

local s1 = strtrim(string(`ineligible_effect', "%20.12f"))
local s2 = strtrim(string(`eligible_nonrecipient_effect', "%20.12f"))
local s3 = strtrim(string(`population_effect', "%20.12f"))

display "ANSWER: ineligible_effect estimate=`s1' se=NA n_obs=`n_obs'"
display "ANSWER: eligible_nonrecipient_effect estimate=`s2' se=NA n_obs=`n_obs'"
display "ANSWER: population_effect estimate=`s3' se=NA n_obs=`n_obs'"
