clear all
set more off
set linesize 255

import delimited using "./input.csv", clear varnames(1)
tsset t

quietly count if t==251
if r(N)==0 {
    tsappend, add(1)
}

arima y if t<=250, arima(1,1,1) noconstant
local n = e(N)

predict double f_lev if t==251, y dynamic(251)
predict double mse_lev if t==251, mse dynamic(251)

summarize f_lev if t==251, meanonly
local fc = r(mean)
summarize mse_lev if t==251, meanonly
local sd_fc = sqrt(r(mean))

local z = invnormal(0.975)
local lo = `fc' - `z'*`sd_fc'
local hi = `fc' + `z'*`sd_fc'

local fcs = string(`fc', "%21.12f")
local los = string(`lo', "%21.12f")
local his = string(`hi', "%21.12f")
local ns  = string(`n', "%12.0f")

display "ANSWER: forecast estimate=`fcs' se=. n_obs=`ns'"
display "ANSWER: lower_95 estimate=`los' se=. n_obs=`ns'"
display "ANSWER: upper_95 estimate=`his' se=. n_obs=`ns'"
