clear all
set more off
set varabbrev off

tempfile xw inds trade emp areas popf outc

import delimited using "crosswalk.csv", clear varnames(lower)
keep code industry
duplicates drop
save `xw'
keep industry
duplicates drop
gen byte k = 1
save `inds', replace

import delimited using "trade.csv", clear varnames(lower)
capture destring period, replace
merge m:1 code using `xw', keep(match) nogen
keep period industry us_change other_change price_index years
save `trade'

import delimited using "employment.csv", clear varnames(lower)
capture destring period, replace
keep area period vintage industry employment
save `emp'

import delimited using "areas.csv", clear varnames(lower)
capture destring period, replace
keep area period vintage total_employment population
save `areas'
keep if vintage == "base"
keep area period population
save `popf'

import delimited using "outcomes.csv", clear varnames(lower)
capture destring period, replace
keep area period control change_pp
save `outc'

use `areas', clear
gen byte k = 1
joinby k using `inds'
drop k
merge 1:1 area period vintage industry using `emp', keep(master match) nogen
replace employment = 0 if missing(employment)

bysort period vintage industry: egen double nat = total(employment)

merge m:1 period industry using `trade', keep(match) nogen

gen double scale = (10/years)/(price_index/100)/1000
gen double share = employment/total_employment
gen double trd = cond(vintage == "base", us_change, other_change)
gen double term = share*(trd/nat)*scale
gen double xterm = term if vintage == "base"
gen double zterm = term if vintage == "early"

collapse (sum) xterm zterm, by(area period)

merge 1:1 area period using `popf', keep(match) nogen
merge 1:1 area period using `outc', keep(match) nogen

rename xterm x
rename zterm z

ivregress 2sls change_pp period control (x = z) [aw=population]
local n = e(N)
local bx = _b[x]

summarize x if area == 0 & period == 0, meanonly
local x00 = r(mean)
summarize x if area == 0 & period == 1, meanonly
local x01 = r(mean)
summarize z if area == 0 & period == 0, meanonly
local z00 = r(mean)

di "ANSWER: iv_slope estimate=" strtrim(string(`bx', "%24.15g")) " se=NA n_obs=" strtrim(string(`n', "%12.0f"))
di "ANSWER: exposure_area0_period0 estimate=" strtrim(string(`x00', "%24.15g")) " se=NA n_obs=" strtrim(string(`n', "%12.0f"))
di "ANSWER: exposure_area0_period1 estimate=" strtrim(string(`x01', "%24.15g")) " se=NA n_obs=" strtrim(string(`n', "%12.0f"))
di "ANSWER: instrument_area0_period0 estimate=" strtrim(string(`z00', "%24.15g")) " se=NA n_obs=" strtrim(string(`n', "%12.0f"))
