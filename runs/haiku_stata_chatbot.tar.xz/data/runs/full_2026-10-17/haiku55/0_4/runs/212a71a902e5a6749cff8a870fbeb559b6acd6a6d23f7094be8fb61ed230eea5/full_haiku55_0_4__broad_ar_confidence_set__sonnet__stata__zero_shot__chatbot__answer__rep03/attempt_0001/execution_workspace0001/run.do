clear all
set more off
set linesize 255

import delimited using "input.csv", clear

scalar n_obs = _N
scalar cc = invF(2, _N - 4, 0.95)

mata:
y  = st_data(., "y")
v  = st_data(., "endog")
x  = st_data(., "x")
z1 = st_data(., "z1")
z2 = st_data(., "z2")
n  = rows(y)
X0 = J(n, 1, 1), x
X1 = X0, z1, z2
M0 = I(n) - X0 * invsym(X0' * X0) * X0'
M1 = I(n) - X1 * invsym(X1' * X1) * X1'
c  = st_numscalar("cc")
K  = (M0 - M1) / 2 - (c / (n - 4)) * M1
st_numscalar("qa", v' * K * v)
st_numscalar("qb", -2 * (v' * K * y))
st_numscalar("qc", y' * K * y)
e1 = y - v
rr = e1' * M0 * e1
ru = e1' * M1 * e1
st_numscalar("ar1", ((rr - ru) / 2) / (ru / (n - 4)))
end

scalar disc = qb^2 - 4*qa*qc
scalar lo = .
scalar hi = .
scalar unb = 0

if qa > 0 {
    if disc >= 0 {
        scalar lo = (-qb - sqrt(disc)) / (2*qa)
        scalar hi = (-qb + sqrt(disc)) / (2*qa)
    }
}
else if qa < 0 {
    scalar unb = 1
    if disc >= 0 {
        scalar lo = (-qb + sqrt(disc)) / (2*qa)
        scalar hi = (-qb - sqrt(disc)) / (2*qa)
    }
}
else {
    scalar unb = 1
    if qb != 0 {
        scalar lo = -qc / qb
    }
}

scalar accepts0 = (qc <= 0)

display "ANSWER: boundary_low estimate=" %21.12f lo " se=. n_obs=" %12.0f n_obs
display "ANSWER: boundary_high estimate=" %21.12f hi " se=. n_obs=" %12.0f n_obs
display "ANSWER: accepts_zero estimate=" %21.12f accepts0 " se=. n_obs=" %12.0f n_obs
display "ANSWER: unbounded estimate=" %21.12f unb " se=. n_obs=" %12.0f n_obs
display "ANSWER: ar_f_at_one estimate=" %21.12f ar1 " se=. n_obs=" %12.0f n_obs
