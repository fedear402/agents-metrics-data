clear all
set more off
set linesize 255

import delimited using "input.csv", clear

quietly regress y x
predict double r_y, residuals
quietly regress endog x
predict double r_e, residuals
quietly regress y x z1 z2
predict double u_y, residuals
scalar df = e(df_r)
quietly regress endog x z1 z2
predict double u_e, residuals

scalar q = 2
scalar critical = invFtail(q, df, .05)
scalar k = q*critical/df

mata:
ry = st_data(., "r_y")
re = st_data(., "r_e")
uy = st_data(., "u_y")
ue = st_data(., "u_e")
k = st_numscalar("k")
dfv = st_numscalar("df")

A = quadcross(re, re) - (1+k)*quadcross(ue, ue)
B = -2*(quadcross(ry, re) - (1+k)*quadcross(uy, ue))
C = quadcross(ry, ry) - (1+k)*quadcross(uy, uy)
D = B^2 - 4*A*C

if (abs(A) > 1e-12 & D > 0) {
    r1 = (-B - sqrt(D))/(2*A)
    r2 = (-B + sqrt(D))/(2*A)
    lo_b = min((r1, r2))
    hi_b = max((r1, r2))
}
else {
    lo_b = .
    hi_b = .
}

ssr_r1 = quadcross(ry - re, ry - re)
ssr_u1 = quadcross(uy - ue, uy - ue)
f_one = ((ssr_r1 - ssr_u1)/2)/(ssr_u1/dfv)

st_numscalar("lo_b", lo_b)
st_numscalar("hi_b", hi_b)
st_numscalar("unb", A < 0)
st_numscalar("acc0", C <= 0)
st_numscalar("f_one", f_one)
end

display "ANSWER: boundary_low estimate=" %21.12f lo_b " se=." " n_obs=" %12.0f _N
display "ANSWER: boundary_high estimate=" %21.12f hi_b " se=." " n_obs=" %12.0f _N
display "ANSWER: accepts_zero estimate=" %21.12f acc0 " se=." " n_obs=" %12.0f _N
display "ANSWER: unbounded estimate=" %21.12f unb " se=." " n_obs=" %12.0f _N
display "ANSWER: ar_f_at_one estimate=" %21.12f f_one " se=." " n_obs=" %12.0f _N
