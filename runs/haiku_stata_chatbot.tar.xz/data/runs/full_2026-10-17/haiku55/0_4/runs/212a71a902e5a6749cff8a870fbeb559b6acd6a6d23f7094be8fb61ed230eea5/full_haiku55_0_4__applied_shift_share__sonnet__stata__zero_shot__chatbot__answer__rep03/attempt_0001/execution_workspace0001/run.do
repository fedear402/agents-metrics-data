clear all
set more off
set linesize 255

import delimited using "input.csv", clear

bysort region_id: gen byte firstr = (_n == 1)

summarize region_weight if firstr, meanonly
scalar W = r(sum)

gen double e0 = region_weight / W if firstr
bysort region_id: egen double e = max(e0)

gen double sx = share * shock
bysort region_id: egen double z = total(sx)

gen double ex = e * x if firstr
gen double ey = e * y if firstr
gen double ez = e * z if firstr
summarize ex if firstr, meanonly
scalar mx = r(sum)
summarize ey if firstr, meanonly
scalar my = r(sum)
summarize ez if firstr, meanonly
scalar mz = r(sum)

gen double x0 = x - mx
gen double y0 = y - my
gen double z0 = z - mz

gen double w = e * share
bysort industry_id: egen double s = total(w)

gen double wy = w * y0
gen double wx = w * x0
gen double wz = w * z0
bysort industry_id: egen double sy = total(wy)
bysort industry_id: egen double sxw = total(wx)
bysort industry_id: egen double szw = total(wz)

gen double ybar = sy / s
gen double xbar = sxw / s
gen double zbar = szw / s

bysort industry_id: keep if _n == 1

ivregress 2sls ybar (xbar = shock) [aw = s], vce(robust)
scalar b_eff  = _b[xbar]
scalar se_eff = _se[xbar]
scalar n_eff  = e(N)

regress x z [aw = e] if firstr
scalar b_fs = _b[z]

ivregress 2sls xbar (zbar = shock) [aw = s], vce(robust)
scalar se_fs = _se[zbar]
scalar n_fs  = e(N)

gen double s2 = s^2
summarize s2, meanonly
scalar eff_shocks = 1 / r(sum)
scalar n_shk = _N

display "ANSWER: effect estimate=" %21.12f b_eff " se=" %21.12f se_eff " n_obs=" %12.0f n_eff
display "ANSWER: first_stage estimate=" %21.12f b_fs " se=" %21.12f se_fs " n_obs=" %12.0f n_fs
display "ANSWER: effective_shocks estimate=" %21.12f eff_shocks " se=. n_obs=" %12.0f n_shk
