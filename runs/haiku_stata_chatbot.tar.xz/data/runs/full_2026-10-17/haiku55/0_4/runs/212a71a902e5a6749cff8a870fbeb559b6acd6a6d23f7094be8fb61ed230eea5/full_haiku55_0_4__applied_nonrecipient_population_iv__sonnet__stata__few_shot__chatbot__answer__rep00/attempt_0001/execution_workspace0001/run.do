clear all
set more off
set type double

import delimited using "households.csv", clear varnames(1)
keep if recipient==0

gen double ineligible = 1 - eligible
gen double dose_in = dose*ineligible
gen double dose_el = dose*eligible
gen double base_in = baseline*ineligible
gen double base_el = baseline*eligible
gen double inst_in = instrument*ineligible
gen double inst_el = instrument*eligible

ivregress 2sls outcome ineligible eligible base_in base_el (dose_in dose_el = ineligible eligible base_in base_el inst_in inst_el) [aw=weight], noconstant

local n_obs = e(N)
scalar slope_in = _b[dose_in]
scalar slope_el = _b[dose_el]

summarize dose [aw=weight] if eligible==0 & e(sample)==1, meanonly
scalar m_in = r(mean)
summarize dose [aw=weight] if eligible==1 & e(sample)==1, meanonly
scalar m_el = r(mean)

scalar e_in = slope_in*m_in
scalar e_el = slope_el*m_el

import delimited using "census.csv", clear varnames(1)
summarize nonrecipient_population if eligible==0, meanonly
scalar n0 = r(mean)
summarize nonrecipient_population if eligible==1, meanonly
scalar n1 = r(mean)

scalar pop_effect = (e_in*n0 + e_el*n1)/(n0 + n1)

display "ANSWER: ineligible_effect estimate=" %24.16g (e_in) " se=NA n_obs=" `n_obs'
display "ANSWER: eligible_nonrecipient_effect estimate=" %24.16g (e_el) " se=NA n_obs=" `n_obs'
display "ANSWER: population_effect estimate=" %24.16g (pop_effect) " se=NA n_obs=" `n_obs'

exit, clear
