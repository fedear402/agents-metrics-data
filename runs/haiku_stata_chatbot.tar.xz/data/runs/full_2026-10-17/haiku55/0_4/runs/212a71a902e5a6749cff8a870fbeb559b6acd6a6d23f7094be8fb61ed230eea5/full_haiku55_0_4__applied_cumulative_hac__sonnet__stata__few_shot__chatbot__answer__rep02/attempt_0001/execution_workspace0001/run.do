version 19.0
clear all
set more off
set linesize 255

import delimited "./input.csv", clear varnames(1)

capture confirm numeric variable date
if !_rc tostring date, replace
generate double day = date(date, "YMD")
sort day
generate long obs = _n
tsset obs

generate double lsales = ln(sales)
generate double lvix = ln(vix)
generate double dlvix = D.lvix

local lagl ""
forvalues k = 1/15 {
    generate double lag_`k' = L`k'.dlvix
    local lagl "`lagl' lag_`k'"
}

keep if !missing(lsales, dlvix`lagl')

mata:
y = st_data(., "lsales")
X = (J(rows(y), 1, 1), st_data(., tokens(st_local("lagl"))))
N = rows(X)
p = cols(X)
bread = invsym(X'*X)
b = bread*X'*y
e = y - X*b
S = X :* e
H = 15
meat = S'*S
for (j = 1; j <= H; j++) {
    G = S[|j+1, 1 \ N, p|]' * S[|1, 1 \ N-j, p|]
    meat = meat + (1 - j/(H+1)) * (G + G')
}
V = N/(N-p) * bread * meat * bread
c = (0 \ J(15, 1, 1))
st_numscalar("cum_resp", c'*b)
st_numscalar("cum_se", sqrt(c'*V*c))
st_numscalar("lag1_b", b[2])
st_numscalar("lag1_se", sqrt(V[2,2]))
st_numscalar("lag15_b", b[16])
st_numscalar("lag15_se", sqrt(V[16,16]))
st_numscalar("nobs", N)
end

display "ANSWER: cumulative_response estimate=" %21.12f cum_resp " se=" %21.12f cum_se " n_obs=" %12.0f nobs
display "ANSWER: lag_1 estimate=" %21.12f lag1_b " se=" %21.12f lag1_se " n_obs=" %12.0f nobs
display "ANSWER: lag_15 estimate=" %21.12f lag15_b " se=" %21.12f lag15_se " n_obs=" %12.0f nobs
