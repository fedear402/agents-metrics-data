version 19.0
clear all
set more off
set linesize 255

import delimited using "input.csv", clear varnames(1)
gen double sz = share*shock
bysort region_id: egen double z = total(sz)
tempfile full
save `full'

bysort region_id: keep if _n==1
egen double wsum = total(region_weight)
gen double e = region_weight/wsum
foreach v in y x z {
    gen double tmp = e*`v'
    egen double mu_`v' = total(tmp)
    gen double `v'0 = `v' - mu_`v'
    drop tmp mu_`v'
}

regress x0 z0 [aw=e]
scalar fs_est = _b[z0]

tempfile regs
save `regs'

use `full', clear
merge m:1 region_id using `regs', assert(match) nogen keepusing(e y0 x0 z0)
gen double se_share = e*share
gen double ey = se_share*y0
gen double ex = se_share*x0
gen double ez = se_share*z0
collapse (sum) s=se_share ey ex ez (mean) shock, by(industry_id)
gen double ybar = ey/s
gen double xbar = ex/s
gen double zbar = ez/s

mata:
real rowvector iv_hc1(real colvector y, real colvector x, real colvector z, real colvector w)
{
    real scalar N
    real matrix X, Z, A, S, V
    real colvector beta, res
    N = rows(y)
    X = (J(N,1,1), x)
    Z = (J(N,1,1), z)
    A = luinv(Z'*(w:*X))
    beta = A*Z'*(w:*y)
    res = y - X*beta
    S = Z:*(w:*res)
    V = N/(N-2)*A*(S'*S)*A'
    return((beta[2], sqrt(V[2,2])))
}

real colvector yb, xb, zb, sw, sh
real rowvector eff, fs
yb = st_data(., "ybar")
xb = st_data(., "xbar")
zb = st_data(., "zbar")
sw = st_data(., "s")
sh = st_data(., "shock")
eff = iv_hc1(yb, xb, sh, sw)
fs = iv_hc1(xb, zb, sh, sw)
st_numscalar("eff_est", eff[1])
st_numscalar("eff_se", eff[2])
st_numscalar("fs_se", fs[2])
st_numscalar("eff_shocks", 1/sum(sw:^2))
st_numscalar("n_ind", rows(yb))
end

display "ANSWER: effect estimate=" %21.12f scalar(eff_est) " se=" %21.12f scalar(eff_se) " n_obs=" %12.0f scalar(n_ind)
display "ANSWER: first_stage estimate=" %21.12f scalar(fs_est) " se=" %21.12f scalar(fs_se) " n_obs=" %12.0f scalar(n_ind)
display "ANSWER: effective_shocks estimate=" %21.12f scalar(eff_shocks) " se=. n_obs=" %12.0f scalar(n_ind)
