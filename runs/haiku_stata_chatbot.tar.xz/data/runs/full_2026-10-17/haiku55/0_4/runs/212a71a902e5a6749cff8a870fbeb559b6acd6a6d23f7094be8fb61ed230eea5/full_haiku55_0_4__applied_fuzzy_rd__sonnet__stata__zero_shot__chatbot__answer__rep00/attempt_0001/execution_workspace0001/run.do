clear all
set more off
set linesize 255

import delimited using "input.csv", clear
keep if abs(score) < 1
gen double w = 1 - abs(score)
gen double D = (score >= 0)
gen double S = score
gen double DS = D * S
count
scalar N_obs = r(N)

mata:
X  = (J(rows(D), 1, 1), st_data(., "D"), st_data(., "S"), st_data(., "DS"))
w  = st_data(., "w")
y1 = st_data(., "earnings")
y2 = st_data(., "participated")

B   = invsym(cross(X, w, X))
b1  = B * cross(X, w, y1)
b2  = B * cross(X, w, y2)
e1  = y1 - X * b1
e2  = y2 - X * b2

M11 = cross(X, w:^2 :* e1 :* e1, X)
M22 = cross(X, w:^2 :* e2 :* e2, X)
M12 = cross(X, w:^2 :* e1 :* e2, X)

V11 = (B * M11 * B)[2, 2]
V22 = (B * M22 * B)[2, 2]
V12 = (B * M12 * B)[2, 2]

t1 = b1[2]
t2 = b2[2]
te = t1 / t2
g  = (1 / t2, -t1 / t2^2)
Vte = g * (V11, V12 \ V12, V22) * g'

st_numscalar("rf_est", t1)
st_numscalar("fs_est", t2)
st_numscalar("te_est", te)
st_numscalar("rf_se", sqrt(V11))
st_numscalar("fs_se", sqrt(V22))
st_numscalar("te_se", sqrt(Vte))
end

display "ANSWER: treatment_effect estimate=" %21.12f te_est " se=" %21.12f te_se " n_obs=" %12.0f N_obs
display "ANSWER: reduced_form estimate=" %21.12f rf_est " se=" %21.12f rf_se " n_obs=" %12.0f N_obs
display "ANSWER: first_stage estimate=" %21.12f fs_est " se=" %21.12f fs_se " n_obs=" %12.0f N_obs
