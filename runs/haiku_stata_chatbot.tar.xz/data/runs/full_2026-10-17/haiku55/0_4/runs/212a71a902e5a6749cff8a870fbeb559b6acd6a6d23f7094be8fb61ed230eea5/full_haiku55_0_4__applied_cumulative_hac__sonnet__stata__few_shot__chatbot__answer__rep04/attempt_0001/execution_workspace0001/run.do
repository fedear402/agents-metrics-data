version 19.0
clear all
set more off
set linesize 255

import delimited using "input.csv", clear

capture confirm string variable date
if _rc == 0 {
    generate double day = date(date, "YMD")
}
else {
    generate double day = date
}
sort day
generate long obs = _n
tsset obs

generate double lsales = ln(sales)
generate double lvix = ln(vix)
generate double dlvix = D.lvix

local lagvars ""
forvalues k = 1/15 {
    generate double lagdl`k' = L`k'.dlvix
    local lagvars "`lagvars' lagdl`k'"
}

generate byte touse = 1
foreach v of varlist lsales dlvix `lagvars' {
    replace touse = 0 if missing(`v')
}

mata:
y = st_data(., "lsales", "touse")
Z = st_data(., "`lagvars'", "touse")
X = J(rows(y), 1, 1), Z
b = qrsolve(X, y)
e = y - X*b
N = rows(X)
p = cols(X)
S = X :* (e * J(1, p, 1))
meat = S'*S
for (j = 1; j <= 15; j++) {
    G = S[|j+1, 1 \ N, p|]' * S[|1, 1 \ N-j, p|]
    meat = meat + (1 - j/16) * (G + G')
}
XtXi = invsym(X'*X)
V = N/(N-p) * XtXi * meat * XtXi
c = J(p, 1, 0)
c[|2, 1 \ p, 1|] = J(p-1, 1, 1)
st_numscalar("r_cum", c'*b)
st_numscalar("r_cum_se", sqrt(c'*V*c))
st_numscalar("r_lag1", b[2])
st_numscalar("r_lag1_se", sqrt(V[2,2]))
st_numscalar("r_lag15", b[p])
st_numscalar("r_lag15_se", sqrt(V[p,p]))
st_numscalar("r_n", N)
end

display "ANSWER: cumulative_response estimate=" %21.12f r_cum " se=" %21.12f r_cum_se " n_obs=" %12.0f r_n
display "ANSWER: lag_1 estimate=" %21.12f r_lag1 " se=" %21.12f r_lag1_se " n_obs=" %12.0f r_n
display "ANSWER: lag_15 estimate=" %21.12f r_lag15 " se=" %21.12f r_lag15_se " n_obs=" %12.0f r_n
