suppressPackageStartupMessages(library(jsonlite))

households <- read.csv("households.csv", stringsAsFactors = FALSE)
census <- read.csv("census.csv", stringsAsFactors = FALSE)

required_h <- c("eligible", "recipient", "instrument", "dose", "baseline", "weight", "outcome")
required_c <- c("eligible", "nonrecipient_population")
stopifnot(all(required_h %in% names(households)), all(required_c %in% names(census)))
stopifnot(all(households$eligible %in% c(0, 1)), all(households$recipient %in% c(0, 1)))
stopifnot(all(is.finite(households$weight)), all(households$weight > 0))

# Keep every nonrecipient record across both village-treatment statuses.
d <- households[households$recipient == 0, , drop = FALSE]
n_obs <- nrow(d)
stopifnot(n_obs > 0L, all(d$recipient == 0))

ineligible <- 1 - d$eligible
eligible <- d$eligible
# Endogenous regressors: dose interacted with each eligibility group.
X_endog <- cbind(dose_ineligible = d$dose * ineligible,
                 dose_eligible = d$dose * eligible)
# Included exogenous regressors. These are the complete included set; no other intercept.
X_exog <- cbind(ineligible = ineligible,
                eligible = eligible,
                baseline_ineligible = d$baseline * ineligible,
                baseline_eligible = d$baseline * eligible)
X <- cbind(X_exog, X_endog)
# Instruments: included exogenous regressors plus the two excluded interactions.
Z <- cbind(X_exog,
           instrument_ineligible = d$instrument * ineligible,
           instrument_eligible = d$instrument * eligible)
y <- d$outcome
w <- d$weight

# Weighted 2SLS: solve on square-root-weighted matrices.
sqrt_w <- sqrt(w)
Zw <- Z * sqrt_w
Xw <- X * sqrt_w
yw <- y * sqrt_w
qz <- qr(Zw)
stopifnot(qz$rank == ncol(Z))
# Projection onto the weighted instrument space, then weighted least squares.
Qz <- qr.Q(qz, complete = FALSE)
X_projected <- Qz %*% crossprod(Qz, Xw)
y_projected <- Qz %*% crossprod(Qz, yw)
fit <- lm.fit(x = X_projected, y = y_projected, tol = 1e-10)
stopifnot(fit$rank == ncol(X), length(fit$coefficients) == ncol(X))
beta <- fit$coefficients
names(beta) <- colnames(X)

# Household-weighted mean dose within each retained eligibility group.
weighted_mean <- function(x, weight) sum(x * weight) / sum(weight)
mean_dose_ineligible <- weighted_mean(d$dose[d$eligible == 0], w[d$eligible == 0])
mean_dose_eligible <- weighted_mean(d$dose[d$eligible == 1], w[d$eligible == 1])
ineligible_effect <- unname(beta[["dose_ineligible"]] * mean_dose_ineligible)
eligible_nonrecipient_effect <- unname(beta[["dose_eligible"]] * mean_dose_eligible)

# Census counts enter only in the final aggregation of the two group effects.
pop <- census$nonrecipient_population[match(c(0, 1), census$eligible)]
stopifnot(length(pop) == 2L, all(!is.na(pop)), all(pop >= 0), sum(pop) > 0)
population_effect <- (pop[1] * ineligible_effect + pop[2] * eligible_nonrecipient_effect) / sum(pop)

estimates <- list(
  list(term = "ineligible_effect", estimate = ineligible_effect, se = NULL, n_obs = as.integer(n_obs)),
  list(term = "eligible_nonrecipient_effect", estimate = eligible_nonrecipient_effect, se = NULL, n_obs = as.integer(n_obs)),
  list(term = "population_effect", estimate = population_effect, se = NULL, n_obs = as.integer(n_obs))
)
result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "weighted 2SLS",
    sample = "all household rows with recipient = 0, across both treated statuses",
    endogenous = c("dose*(1-eligible)", "dose*eligible"),
    exogenous = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"),
    instruments = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible", "instrument*(1-eligible)", "instrument*eligible"),
    regression_weight = "weight",
    group_effect = "fitted dose slope times household-weighted mean dose in retained group",
    counterfactual = "dose set to zero for every retained household; attribution is a stated synthetic convention",
    population_aggregation = "nonrecipient_population census counts used only as final between-group weights"
  ),
  diagnostics = list(
    n_obs = as.integer(n_obs),
    n_ineligible = as.integer(sum(d$eligible == 0)),
    n_eligible = as.integer(sum(d$eligible == 1)),
    n_treated_status_0 = as.integer(sum(d$treated == 0)),
    n_treated_status_1 = as.integer(sum(d$treated == 1)),
    weighted_mean_dose_ineligible = mean_dose_ineligible,
    weighted_mean_dose_eligible = mean_dose_eligible,
    fitted_dose_slope_ineligible = unname(beta[["dose_ineligible"]]),
    fitted_dose_slope_eligible = unname(beta[["dose_eligible"]]),
    census_nonrecipient_population_ineligible = as.integer(pop[1]),
    census_nonrecipient_population_eligible = as.integer(pop[2]),
    instrument_matrix_rank = as.integer(qz$rank),
    design_matrix_columns = as.integer(ncol(X))
  )
)
write_json(result, "result.json", auto_unbox = TRUE, pretty = TRUE, digits = 16, null = "null")
