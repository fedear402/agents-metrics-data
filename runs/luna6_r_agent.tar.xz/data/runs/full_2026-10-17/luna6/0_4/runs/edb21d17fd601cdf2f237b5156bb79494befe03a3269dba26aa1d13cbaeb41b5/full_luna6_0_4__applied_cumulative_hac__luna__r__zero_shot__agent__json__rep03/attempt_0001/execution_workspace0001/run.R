args <- commandArgs(trailingOnly = TRUE)
dat <- read.csv("input.csv", stringsAsFactors = FALSE)
dat$date <- as.Date(dat$date)
dat <- dat[order(dat$date), ]

stopifnot(identical(names(dat), c("date", "sales", "vix")))
stopifnot(all(is.finite(dat$sales)), all(dat$sales > 0),
          all(is.finite(dat$vix)), all(dat$vix > 0))

dlogv <- c(NA_real_, diff(log(dat$vix)))
lagmat <- sapply(1:15, function(k) c(rep(NA_real_, k), dlogv[seq_len(length(dlogv) - k)]))
colnames(lagmat) <- paste0("lag_", 1:15)
regdat <- data.frame(log_sales = log(dat$sales), lagmat)
regdat <- regdat[complete.cases(regdat), ]
N <- nrow(regdat)
fit <- lm(log_sales ~ ., data = regdat)
X <- model.matrix(fit)
u <- residuals(fit)

# Bartlett Newey-West meat, with maximum lag 15.
meat <- crossprod(X * as.vector(u))
for (j in 1:15) {
  gamma <- crossprod(X[(j + 1):N, , drop = FALSE] * u[(j + 1):N],
                     X[1:(N - j), , drop = FALSE] * u[1:(N - j)])
  w <- 1 - j / 16
  meat <- meat + w * (gamma + t(gamma))
}
bread <- solve(crossprod(X))
V <- bread %*% meat %*% bread * N / (N - 16)
V <- (V + t(V)) / 2
coef <- coef(fit)
idx <- match(paste0("lag_", 1:15), names(coef))
cum_est <- sum(coef[idx])
cum_var <- sum(V[idx, idx, drop = FALSE])
stopifnot(cum_var >= 0)

estimates <- list(
  list(term = "cumulative_response", estimate = unname(cum_est), se = sqrt(cum_var), n_obs = as.integer(N)),
  list(term = "lag_1", estimate = unname(coef["lag_1"]), se = sqrt(V["lag_1", "lag_1"]), n_obs = as.integer(N)),
  list(term = "lag_15", estimate = unname(coef["lag_15"]), se = sqrt(V["lag_15", "lag_15"]), n_obs = as.integer(N))
)

# Independent identity check: a linear contrast variance equals c' V c.
cvec <- rep(0, length(coef)); cvec[idx] <- 1
contrast_var <- drop(t(cvec) %*% V %*% cvec)
stopifnot(isTRUE(all.equal(cum_var, contrast_var, tolerance = 1e-12)))

if (!requireNamespace("jsonlite", quietly = TRUE)) stop("jsonlite is required")
out <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = estimates,
  method_metadata = list(estimator = "OLS with 15 trading-observation lags of first differences in log(vix)",
                         vcov = "Newey-West Bartlett HAC, max lag 15, finite-sample multiplier N/(N-16)"),
  diagnostics = list(input_obs = nrow(dat), regression_obs = N,
                     first_regression_date = as.character(dat$date[17]),
                     last_regression_date = as.character(dat$date[nrow(dat)]),
                     hac_max_lag = 15, finite_sample_multiplier = N / (N - 16),
                     cumulative_se_identity_check = "passed")
)
jsonlite::write_json(out, "result.json", auto_unbox = TRUE, pretty = TRUE, digits = NA, na = "null")
