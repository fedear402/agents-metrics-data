dat <- read.csv("input.csv")
keep <- abs(dat$score) < 1
d <- dat[keep, ]
x <- d$score
z <- as.numeric(x >= 0)
w <- 1 - abs(x)
stopifnot(all(w > 0), all(d$participated %in% c(0, 1)))

# One weighted least-squares design: separate intercepts and slopes by side.
X <- cbind(left = 1 - z, left_slope = (1 - z) * x,
           right = z, right_slope = z * x)
W <- diag(w)
XtWX_inv <- solve(crossprod(X, W %*% X))
fit_jump <- function(y) {
  bhat <- XtWX_inv %*% crossprod(X, w * y)
  # Right limit minus left limit is the difference in intercepts.
  c(bhat["right", 1] - bhat["left", 1], bhat)
}

ys <- cbind(earnings = d$earnings, participation = d$participated)
B <- XtWX_inv %*% crossprod(X, W %*% ys)
rf <- unname(B["right", "earnings"] - B["left", "earnings"])
fs <- unname(B["right", "participation"] - B["left", "participation"])

# HC0 sandwich covariance for both outcomes, preserving cross-outcome covariance.
resid <- ys - X %*% B
meat_cross <- crossprod(X, (w^2) * resid[, 1] * resid[, 2] * X)
meat_e <- crossprod(X, (w^2) * resid[, 1]^2 * X)
meat_p <- crossprod(X, (w^2) * resid[, 2]^2 * X)
V_e <- XtWX_inv %*% meat_e %*% XtWX_inv
V_p <- XtWX_inv %*% meat_p %*% XtWX_inv
V_ep <- XtWX_inv %*% meat_cross %*% XtWX_inv
contrast <- c(-1, 0, 1, 0)
var_rf <- as.numeric(t(contrast) %*% V_e %*% contrast)
var_fs <- as.numeric(t(contrast) %*% V_p %*% contrast)
cov_rf_fs <- as.numeric(t(contrast) %*% V_ep %*% contrast)
ratio <- rf / fs
var_ratio <- var_rf / fs^2 + rf^2 * var_fs / fs^4 - 2 * rf * cov_rf_fs / fs^3
se_ratio <- sqrt(var_ratio)

n <- nrow(d)
estimates <- list(
  list(term = "treatment_effect", estimate = ratio, se = se_ratio, n_obs = n),
  list(term = "reduced_form", estimate = rf, se = sqrt(var_rf), n_obs = n),
  list(term = "first_stage", estimate = fs, se = sqrt(var_fs), n_obs = n)
)
out <- list(task_id = "applied_fuzzy_rd", platform = "r", estimates = estimates,
            method_metadata = list(estimator = "Fuzzy RD: weighted local-linear regressions, triangular kernel, bandwidth 1", vcov = "HC0 sandwich; delta method for ratio with joint covariance"),
            diagnostics = list(n_inside_bandwidth = n, reduced_form_first_stage_covariance = cov_rf_fs))
jsonlite::write_json(out, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE, null = "null")
