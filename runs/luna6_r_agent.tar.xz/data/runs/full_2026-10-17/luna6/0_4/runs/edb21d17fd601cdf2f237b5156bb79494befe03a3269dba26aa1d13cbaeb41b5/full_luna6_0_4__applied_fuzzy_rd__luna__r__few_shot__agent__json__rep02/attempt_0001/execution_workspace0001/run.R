args <- commandArgs(trailingOnly = FALSE)
script_arg <- grep("^--file=", args, value = TRUE)
script_path <- if (length(script_arg)) sub("^--file=", "", script_arg[1]) else "run.R"
workdir <- dirname(normalizePath(script_path, mustWork = FALSE))
setwd(workdir)

suppressPackageStartupMessages(library(jsonlite))
d <- read.csv("input.csv")
needed <- c("id", "score", "participated", "earnings")
stopifnot(all(needed %in% names(d)), all(is.finite(d$score)),
          all(d$participated %in% c(0, 1)), all(is.finite(d$earnings)))
inside <- abs(d$score) < 1
d <- d[inside, , drop = FALSE]
n <- nrow(d)
stopifnot(n > 0L)
x <- d$score
right <- as.numeric(x >= 0)
w <- 1 - abs(x)
# Separate intercepts and slopes: [left intercept, left slope, right intercept, right slope].
X <- cbind(left_intercept = 1 - right,
           left_slope = (1 - right) * x,
           right_intercept = right,
           right_slope = right * x)
Y <- cbind(earnings = d$earnings, participation = d$participated)
A <- crossprod(X, w * X)
B <- solve(A)
beta <- B %*% crossprod(X, w * Y)
e <- Y - X %*% beta
# HC0 sandwich meat; row scores retain same-observation cross-outcome products.
scores <- X * as.numeric(w) * e[, 1L]
scores2 <- X * as.numeric(w) * e[, 2L]
meat11 <- crossprod(scores)
meat22 <- crossprod(scores2)
meat12 <- crossprod(scores, scores2)
V11 <- B %*% meat11 %*% B
V22 <- B %*% meat22 %*% B
V12 <- B %*% meat12 %*% B
contrast <- c(-1, 0, 1, 0)
rf <- drop(crossprod(contrast, beta[, "earnings"]))
fs <- drop(crossprod(contrast, beta[, "participation"]))
var_rf <- drop(t(contrast) %*% V11 %*% contrast)
var_fs <- drop(t(contrast) %*% V22 %*% contrast)
cov_rf_fs <- drop(t(contrast) %*% V12 %*% contrast)
tau <- rf / fs
grad <- c(1 / fs, -rf / fs^2)
V_jumps <- matrix(c(var_rf, cov_rf_fs, cov_rf_fs, var_fs), nrow = 2L)
se_tau <- sqrt(drop(t(grad) %*% V_jumps %*% grad))

row <- function(term, estimate, se) list(term = term,
  estimate = unname(as.numeric(estimate)), se = unname(as.numeric(se)), n_obs = as.integer(n))
result <- list(task_id = "applied_fuzzy_rd", platform = "r",
  estimates = list(row("treatment_effect", tau, se_tau),
                   row("reduced_form", rf, sqrt(var_rf)),
                   row("first_stage", fs, sqrt(var_fs))),
  method_metadata = list(estimator = "Fuzzy RD local-linear weighted least squares; triangular kernel; separate intercepts and slopes",
                         vcov = "HC0 sandwich; joint same-observation covariance; fixed bandwidth and weights"),
  diagnostics = list(covariance_reduced_form_first_stage = cov_rf_fs))
write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
