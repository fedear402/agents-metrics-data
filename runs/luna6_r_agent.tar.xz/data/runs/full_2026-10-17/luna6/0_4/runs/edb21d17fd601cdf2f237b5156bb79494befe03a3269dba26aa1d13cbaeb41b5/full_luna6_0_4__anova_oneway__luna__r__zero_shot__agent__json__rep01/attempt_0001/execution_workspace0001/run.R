data <- read.csv("input.csv", stringsAsFactors = FALSE)
stopifnot(all(c("group", "y") %in% names(data)))
data <- data[complete.cases(data[, c("group", "y")]), c("group", "y")]
data$group <- factor(data$group)
fit <- aov(y ~ group, data = data)
tab <- summary(fit)[[1]]
F_stat <- unname(tab["group", "F value"])
df_num <- unname(tab["group", "Df"])
df_den <- unname(tab["Residuals", "Df"])
p_value <- unname(tab["group", "Pr(>F)"])
n <- nrow(data)

# Independent identity check: F = (SS_between / df_num) / (SS_within / df_den).
grand_mean <- mean(data$y)
means <- tapply(data$y, data$group, mean)
counts <- tapply(data$y, data$group, length)
ss_between <- sum(counts * (means - grand_mean)^2)
ss_within <- sum((data$y - means[data$group])^2)
F_identity <- (ss_between / df_num) / (ss_within / df_den)
stopifnot(isTRUE(all.equal(F_stat, F_identity, tolerance = 1e-12)))

estimates <- list(
  list(term = "F", estimate = F_stat, se = NULL, n_obs = n),
  list(term = "df_num", estimate = as.numeric(df_num), se = NULL, n_obs = n),
  list(term = "df_den", estimate = as.numeric(df_den), se = NULL, n_obs = n),
  list(term = "p_value", estimate = p_value, se = NULL, n_obs = n)
)
result <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = estimates,
  method_metadata = list(estimator = "one-way ANOVA (aov)", vcov = "classical ANOVA pooled within-group variance"),
  diagnostics = list(n_obs = n, n_groups = nlevels(data$group), ss_between = ss_between, ss_within = ss_within, F_identity = F_identity)
)
json <- jsonlite::toJSON(result, auto_unbox = TRUE, digits = 16, na = "null", pretty = TRUE, null = "null")
writeLines(as.character(json), "result.json")
