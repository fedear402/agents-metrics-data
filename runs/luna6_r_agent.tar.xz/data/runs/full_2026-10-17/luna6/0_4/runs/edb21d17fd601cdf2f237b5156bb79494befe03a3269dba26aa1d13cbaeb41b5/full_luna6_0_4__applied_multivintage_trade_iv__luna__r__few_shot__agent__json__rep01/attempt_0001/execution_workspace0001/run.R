suppressPackageStartupMessages(library(jsonlite))

crosswalk <- read.csv('crosswalk.csv', stringsAsFactors = FALSE)
trade <- read.csv('trade.csv', stringsAsFactors = FALSE)
areas <- read.csv('areas.csv', stringsAsFactors = FALSE)
employment <- read.csv('employment.csv', stringsAsFactors = FALSE)
outcomes <- read.csv('outcomes.csv', stringsAsFactors = FALSE)

# Map each trade code to its industry, then sum employment nationally.
trade <- merge(trade, crosswalk, by = 'code', all.x = TRUE, sort = FALSE)
stopifnot(!anyNA(trade$industry), nrow(trade) == 8L)
national <- aggregate(employment ~ period + vintage + industry, employment, sum)

# Build area-period exposures. Missing area-industry cells contribute zero.
make_exposure <- function(vintage, trade_change) {
  a <- areas[areas$vintage == vintage, ]
  e <- employment[employment$vintage == vintage, c('area','period','industry','employment')]
  t <- trade[, c('period','industry',trade_change,'price_index','years')]
  names(t)[names(t) == trade_change] <- 'trade_change'
  t <- merge(t, national[national$vintage == vintage, c('period','industry','employment')],
             by = c('period','industry'), suffixes = c('', '_national'), all.x = TRUE)
  names(t)[names(t) == 'employment'] <- 'national_employment'
  t$rate <- t$trade_change / t$national_employment / (t$price_index / 100) / 1000 * (10 / t$years)
  ae <- merge(a, e, by = c('area','period'), all.x = TRUE)
  ae <- merge(ae, t[, c('period','industry','rate')], by = c('period','industry'), all.x = TRUE)
  ae$employment[is.na(ae$employment)] <- 0
  ae$component <- (ae$employment / ae$total_employment) * ae$rate
  aggregate(component ~ area + period, ae, sum)
}
x <- make_exposure('base', 'us_change')
z <- make_exposure('early', 'other_change')
d <- Reduce(function(a,b) merge(a,b,by=c('area','period'), all=TRUE),
            list(outcomes, areas[areas$vintage == 'base', c('area','period','population')], x, z))
names(d)[names(d) == 'component.x'] <- 'x'
names(d)[names(d) == 'component.y'] <- 'z'
d$period <- as.numeric(d$period)
d <- d[order(d$area,d$period), ]
stopifnot(nrow(d) == 72L, !anyNA(d[, c('change_pp','control','population','x','z')]))

# Weighted 2SLS: all exogenous regressors instrument themselves, and z instruments x.
X <- cbind(intercept = 1, period = d$period, control = d$control, x = d$x)
Z <- cbind(intercept = 1, period = d$period, control = d$control, z = d$z)
sw <- sqrt(d$population)
XZ <- qr.fitted(qr(Z * sw), X * sw)
beta <- qr.coef(qr(XZ), d$change_pp * sw)

estimates <- list(
  list(term='iv_slope', estimate=unname(beta['x']), se=NULL, n_obs=72L),
  list(term='exposure_area0_period0', estimate=x$component[x$area==0 & x$period==0], se=NULL, n_obs=72L),
  list(term='exposure_area0_period1', estimate=x$component[x$area==0 & x$period==1], se=NULL, n_obs=72L),
  list(term='instrument_area0_period0', estimate=z$component[z$area==0 & z$period==0], se=NULL, n_obs=72L)
)
result <- list(task_id='applied_multivintage_trade_iv', platform='r', estimates=estimates,
               method_metadata=list(estimator='weighted 2SLS', outcome='change_pp', endogenous='x', instrument='z', exogenous=c('intercept','period','control'), weight='base-vintage population', exposure_units='thousands of real dollars per worker per decade'),
               diagnostics=list(n_obs=72L, n_areas=36L, n_periods=2L, area0_period0_x=estimates[[2]]$estimate, area0_period1_x=estimates[[3]]$estimate, area0_period0_z=estimates[[4]]$estimate))
write_json(result, 'result.json', auto_unbox=TRUE, digits=15, pretty=TRUE, null='null')
