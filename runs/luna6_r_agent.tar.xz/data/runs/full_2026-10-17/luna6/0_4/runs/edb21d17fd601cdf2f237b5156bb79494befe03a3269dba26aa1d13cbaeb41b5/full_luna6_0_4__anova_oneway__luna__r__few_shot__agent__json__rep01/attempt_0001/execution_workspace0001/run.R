library(jsonlite)

dat <- read.csv("input.csv", stringsAsFactors = FALSE)
stopifnot(all(c("group", "y") %in% names(dat)))
dat <- dat[complete.cases(dat[, c("group", "y")]), c("group", "y")]
dat$group <- factor(dat$group)
fit <- aov(y ~ group, data = dat)
tab <- summary(fit)[[1]]
n <- nrow(dat)
F_stat <- unname(tab[1, "F value"])
df_num <- unname(tab[1, "Df"])
df_den <- unname(tab[2, "Df"])
p_value <- unname(tab[1, "Pr(>F)"])

out <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = list(
    list(term = "F", estimate = F_stat, se = NULL, n_obs = n),
    list(term = "df_num", estimate = df_num, se = NULL, n_obs = n),
    list(term = "df_den", estimate = df_den, se = NULL, n_obs = n),
    list(term = "p_value", estimate = p_value, se = NULL, n_obs = n)
  ),
  method_metadata = list(estimator = "One-way ANOVA", vcov = "Classical homoskedastic ANOVA"),
  diagnostics = structure(list(), names = character(0))
)
json_text <- toJSON(out, auto_unbox = TRUE, digits = 15, na = "null", null = "null")
# jsonlite treats NULL list elements as empty objects. Replace the four se fields with JSON null.
json_text <- gsub('"se":[{][}]', '"se":null', as.character(json_text))
writeLines(json_text, "result.json")
