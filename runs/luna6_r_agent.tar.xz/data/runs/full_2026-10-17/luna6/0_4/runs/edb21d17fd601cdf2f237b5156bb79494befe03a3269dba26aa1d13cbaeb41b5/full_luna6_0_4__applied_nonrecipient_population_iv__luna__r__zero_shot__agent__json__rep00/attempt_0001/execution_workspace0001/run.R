suppressPackageStartupMessages(library(jsonlite))
h <- read.csv("households.csv")
c <- read.csv("census.csv")
s <- h[h$recipient == 0, , drop = FALSE]
stopifnot(nrow(s) > 0, all(s$eligible %in% c(0, 1)), all(s$weight > 0))
e0 <- 1 - s$eligible
e1 <- s$eligible
X <- cbind(e0, e1, s$baseline * e0, s$baseline * e1,
           s$dose * e0, s$dose * e1)
Z <- cbind(e0, e1, s$baseline * e0, s$baseline * e1,
           s$instrument * e0, s$instrument * e1)
w <- s$weight
y <- s$outcome
# Weighted 2SLS: projection uses W inner product, then weighted least squares.
Zw <- Z * sqrt(w)
Xw <- X * sqrt(w)
yw <- y * sqrt(w)
PZX <- Zw %*% solve(crossprod(Zw), crossprod(Zw, Xw))
PZy <- Zw %*% solve(crossprod(Zw), crossprod(Zw, yw))
beta <- solve(crossprod(Xw, PZX), crossprod(Xw, PZy))[, 1]
# Independent equivalent moment-matrix calculation of 2SLS coefficients.
A <- crossprod(X, Z * w) %*% solve(crossprod(Z, Z * w), crossprod(Z, X * w))
beta_check <- solve(A, crossprod(X, Z * w) %*% solve(crossprod(Z, Z * w), crossprod(Z, y * w)))[, 1]
stopifnot(max(abs(beta - beta_check)) < 1e-9)
# Column order: intercept-group dummies, baseline slopes, then dose slopes.
slopes <- beta[5:6]
mean_dose <- vapply(0:1, function(g) {
  q <- s$eligible == g
  sum(w[q] * s$dose[q]) / sum(w[q])
}, numeric(1))
effects <- slopes * mean_dose
names(effects) <- c("ineligible_effect", "eligible_nonrecipient_effect")
pop <- sum(effects * c(8400, 1600) / sum(c(8400, 1600)))
# Use census rows by eligibility, with census used only for final aggregation.
stopifnot(identical(sort(c$eligible), 0:1))
pop <- sum(effects[order(c$eligible)] * c$nonrecipient_population) / sum(c$nonrecipient_population)
n <- nrow(s)
est <- list(
  list(term="ineligible_effect", estimate=unname(effects[1]), se=NULL, n_obs=as.integer(n)),
  list(term="eligible_nonrecipient_effect", estimate=unname(effects[2]), se=NULL, n_obs=as.integer(n)),
  list(term="population_effect", estimate=unname(pop), se=NULL, n_obs=as.integer(n))
)
result <- list(task_id="applied_nonrecipient_population_iv", platform="r", estimates=est,
  method_metadata=list(estimator="weighted 2SLS", endogenous_columns=c("dose*(1-eligible)", "dose*eligible"),
    exogenous_columns=c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"),
    instruments=c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible", "instrument*(1-eligible)", "instrument*eligible"),
    intercept="none beyond the two group indicators", regression_weight="weight",
    group_effect="fitted dose slope times household-weighted mean dose among retained observations",
    counterfactual="dose set to zero for every retained household; attribution is a stated synthetic convention",
    population_weights="nonrecipient_population from census.csv; used only for final group aggregation"),
  diagnostics=list(n_obs=as.integer(n), recipient_values=sort(unique(s$recipient)),
    group_n_obs=as.list(table(factor(s$eligible, levels=0:1))),
    weighted_mean_dose=as.list(setNames(mean_dose, c("ineligible", "eligible"))),
    fitted_dose_slopes=as.list(setNames(slopes, c("ineligible", "eligible"))),
    independent_2sls_max_abs_difference=unname(max(abs(beta-beta_check)))) )
write_json(result, "result.json", auto_unbox=TRUE, null="null", digits=16, pretty=TRUE)
