dat <- read.csv("input.csv")
sample <- dat[abs(dat$score) < 1, ]
sample$right <- as.numeric(sample$score >= 0)
sample$x <- sample$score
sample$right_x <- sample$right * sample$x
sample$w <- 1 - abs(sample$score)
n <- nrow(sample)

# Both outcomes use the same weighted local-linear design.
X <- cbind(left_intercept = 1 - sample$right,
          left_slope = (1 - sample$right) * sample$x,
          right_intercept = sample$right,
          right_slope = sample$right * sample$x)
Y <- cbind(earnings = sample$earnings, participation = sample$participated)
W <- sample$w
bread <- solve(crossprod(X, W * X))
coef <- bread %*% crossprod(X, W * Y)
resid <- Y - X %*% coef
# Right limit minus left limit: intercept contrast.
c <- c(-1, 0, 1, 0)
jump <- drop(crossprod(c, coef))
# HC0 sandwich joint covariance. Each observation contributes w_i x_i' bread c times its residual.
loading <- drop(X %*% bread %*% c) * W
influence <- loading * resid
joint_vcov <- crossprod(influence)
gradient <- c(1 / jump[2], -jump[1] / jump[2]^2)
treatment <- jump[1] / jump[2]
treatment_se <- sqrt(drop(t(gradient) %*% joint_vcov %*% gradient))

row <- function(term, estimate, se) list(term=term, estimate=unname(as.numeric(estimate)), se=unname(as.numeric(se)), n_obs=as.integer(n))
result <- list(task_id="applied_fuzzy_rd", platform="r",
  estimates=list(row("treatment_effect", treatment, treatment_se),
                 row("reduced_form", jump[1], sqrt(joint_vcov[1,1])),
                 row("first_stage", jump[2], sqrt(joint_vcov[2,2]))),
  method_metadata=list(estimator="triangular-weighted local-linear fuzzy RD; separate slopes by side", vcov="HC0 sandwich; joint covariance and delta method; fixed bandwidth and weights"),
  diagnostics=list())
jsonlite::write_json(result, "result.json", auto_unbox=TRUE, null="null", digits=16, pretty=TRUE)
