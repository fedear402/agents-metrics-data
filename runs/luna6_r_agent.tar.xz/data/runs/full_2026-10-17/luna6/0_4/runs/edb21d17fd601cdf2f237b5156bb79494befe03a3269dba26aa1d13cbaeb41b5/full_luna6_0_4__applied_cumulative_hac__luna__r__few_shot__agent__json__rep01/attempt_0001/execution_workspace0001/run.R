# Estimate cumulative association of lagged log-VIX changes with log sales.
suppressPackageStartupMessages(library(jsonlite))

d <- read.csv("input.csv", stringsAsFactors = FALSE)
stopifnot(identical(names(d), c("date", "sales", "vix")))
d$date <- as.Date(d$date)
d <- d[order(d$date), ]
stopifnot(all(is.finite(d$sales)), all(d$sales > 0), all(is.finite(d$vix)), all(d$vix > 0))
d$log_sales <- log(d$sales)
d$vol_change <- c(NA_real_, diff(log(d$vix)))
for (k in 1:15) d[[paste0("lag_", k)]] <- c(rep(NA_real_, k), head(d$vol_change, -k))
vars <- c("log_sales", paste0("lag_", 1:15))
s <- d[complete.cases(d[, vars]), vars]
fit <- lm(log_sales ~ ., data=s)
X <- model.matrix(fit)
e <- residuals(fit)
b <- coef(fit)
N <- nrow(X); p <- ncol(X)
stopifnot(p == 16L, N == nrow(d) - 16L)
scores <- X * e
meat <- crossprod(scores)
for (j in 1:15) {
  g <- crossprod(scores[(j+1):N, , drop=FALSE], scores[1:(N-j), , drop=FALSE])
  meat <- meat + (1-j/16) * (g + t(g))
}
bread <- solve(crossprod(X))
V <- (N/(N-16)) * bread %*% meat %*% bread
idx <- c(2L, 16L)
c <- c(0, rep(1, 15))
rows <- list(
  list(term="cumulative_response", estimate=unname(sum(b[-1])), se=unname(sqrt(drop(t(c)%*%V%*%c))), n_obs=as.integer(N)),
  list(term="lag_1", estimate=unname(b[2]), se=unname(sqrt(V[2,2])), n_obs=as.integer(N)),
  list(term="lag_15", estimate=unname(b[16]), se=unname(sqrt(V[16,16])), n_obs=as.integer(N)))
out <- list(task_id="applied_cumulative_hac", platform="r", estimates=rows,
            method_metadata=list(estimator="OLS with intercept and 15 observed-row lags of first log-VIX differences", vcov="Newey-West Bartlett HAC, maximum lag 15, finite-sample multiplier N/(N-16)"),
            diagnostics=list(n_input=nrow(d), n_obs=N, regressors=15, hac_max_lag=15, parameters=p))
write_json(out, "result.json", auto_unbox=TRUE, digits=16, pretty=TRUE)
cat(sprintf("N=%d p=%d\ncumulative=%.12g se=%.12g\nlag_1=%.12g se=%.12g\nlag_15=%.12g se=%.12g\n", N,p,rows[[1]]$estimate,rows[[1]]$se,rows[[2]]$estimate,rows[[2]]$se,rows[[3]]$estimate,rows[[3]]$se))
