#!/usr/bin/env Rscript

dat <- read.csv("./input.csv", stringsAsFactors = FALSE)

required <- c("group", "y")
if (!all(required %in% names(dat))) {
  stop("input.csv must contain columns: group, y")
}

# The model frame defines the common estimation sample for the one-way ANOVA.
sample <- dat[complete.cases(dat[, required]), required]
sample$group <- factor(sample$group)
sample$y <- as.numeric(sample$y)
if (nlevels(sample$group) < 2L) stop("At least two groups are required")

fit <- lm(y ~ group, data = sample)
tab <- anova(fit)
f_stat <- unname(tab[1L, "F value"])
df_num <- unname(tab[1L, "Df"])
df_den <- unname(tab[2L, "Df"])
p_value <- pf(f_stat, df_num, df_den, lower.tail = FALSE)
n_obs <- nrow(sample)

estimates <- lapply(c("F", "df_num", "df_den", "p_value"), function(term) {
  value <- switch(term, F = f_stat, df_num = df_num, df_den = df_den,
                  p_value = p_value)
  list(term = term, estimate = as.numeric(value), se = NULL, n_obs = n_obs)
})

result <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = estimates,
  method_metadata = list(estimator = "one-way ANOVA by OLS", vcov = "classical ANOVA F test"),
  diagnostics = list(n_obs = n_obs, n_groups = nlevels(sample$group))
)

if (!requireNamespace("jsonlite", quietly = TRUE)) {
  stop("Package jsonlite is required to write result.json")
}
jsonlite::write_json(result, "result.json", auto_unbox = TRUE,
                     pretty = TRUE, null = "null", digits = 17)
