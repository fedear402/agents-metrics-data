suppressPackageStartupMessages(library(jsonlite))

crosswalk <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
trade <- read.csv("trade.csv", stringsAsFactors = FALSE)
areas <- read.csv("areas.csv", stringsAsFactors = FALSE)
employment <- read.csv("employment.csv", stringsAsFactors = FALSE)
outcomes <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

stopifnot(nrow(crosswalk) == 8L, nrow(trade) == 8L)
trade <- merge(trade, crosswalk, by = "code", all.x = TRUE, sort = FALSE)
stopifnot(!anyNA(trade$industry), !anyDuplicated(trade[c("period", "industry")]))

# Complete the four-industry area cells. Omitted employment rows have value zero.
keys <- unique(areas[c("area", "period", "vintage")])
grid <- merge(keys, data.frame(industry = sort(unique(crosswalk$industry))), all = TRUE)
employment_full <- merge(grid, employment, by = c("area", "period", "vintage", "industry"), all.x = TRUE)
employment_full$employment[is.na(employment_full$employment)] <- 0

# Sum area employment within each period and vintage for national denominators.
national <- aggregate(employment ~ period + vintage + industry, employment_full, sum)
area_ind <- merge(employment_full, areas, by = c("area", "period", "vintage"), all = FALSE)
area_ind <- merge(area_ind, national, by = c("period", "vintage", "industry"), suffixes = c("", "_national"), all.x = TRUE)
area_ind <- merge(area_ind, trade, by = c("period", "industry"), all.x = TRUE)
stopifnot(!anyNA(area_ind$employment_national), !anyNA(area_ind$us_change))
area_ind$flow <- ifelse(area_ind$vintage == "base", area_ind$us_change, area_ind$other_change)
area_ind$exposure_piece <- (area_ind$employment / area_ind$total_employment) *
  (area_ind$flow / area_ind$employment_national) /
  (area_ind$price_index / 100) / 1000 * (10 / area_ind$years)
exposures <- aggregate(exposure_piece ~ area + period + vintage, area_ind, sum)
names(exposures)[names(exposures) == "exposure_piece"] <- "exposure"
wide <- reshape(exposures, idvar = c("area", "period"), timevar = "vintage", direction = "wide")
names(wide)[names(wide) == "exposure.base"] <- "x"
names(wide)[names(wide) == "exposure.early"] <- "z"

sample <- merge(outcomes, wide[c("area", "period", "x", "z")], by = c("area", "period"), all = FALSE)
sample <- merge(sample, areas[areas$vintage == "base", c("area", "period", "population")], by = c("area", "period"), all = FALSE)
sample <- sample[order(sample$period, sample$area), ]
stopifnot(nrow(sample) == 72L, !anyNA(sample), length(unique(sample$area)) == 36L)

# Weighted 2SLS: regressors [intercept, period, control, x], instruments
# [intercept, period, control, z]. The formula below is the matrix 2SLS estimator.
X <- cbind(intercept = 1, period = sample$period, control = sample$control, x = sample$x)
Z <- cbind(intercept = 1, period = sample$period, control = sample$control, z = sample$z)
W <- diag(sample$population)
A <- crossprod(Z, W %*% X)
B <- crossprod(Z, W %*% sample$change_pp)
beta <- solve(crossprod(A, solve(crossprod(Z, W %*% Z), A)),
              crossprod(A, solve(crossprod(Z, W %*% Z), B)))
iv_slope <- unname(beta["x", 1])

estimates <- list(
  list(term = "iv_slope", estimate = iv_slope, se = NULL, n_obs = 72L),
  list(term = "exposure_area0_period0", estimate = wide$x[wide$area == 0 & wide$period == 0], se = NULL, n_obs = 72L),
  list(term = "exposure_area0_period1", estimate = wide$x[wide$area == 0 & wide$period == 1], se = NULL, n_obs = 72L),
  list(term = "instrument_area0_period0", estimate = wide$z[wide$area == 0 & wide$period == 0], se = NULL, n_obs = 72L)
)
result <- list(task_id = "applied_multivintage_trade_iv", platform = "r", estimates = estimates,
               method_metadata = list(estimator = "weighted 2SLS", regressors = c("intercept", "period", "control", "x"),
                 instruments = c("intercept", "period", "control", "z"), weight = "base-vintage population",
                 exposure_units = "thousands of real dollars per worker per decade",
                 national_denominator = "sum of four-industry employment over supplied areas within period and vintage",
                 missing_area_industry_employment = 0),
               diagnostics = list(n_obs = 72L, n_areas = 36L, n_periods = 2L,
                 max_abs_weighted_instrument_orthogonality = max(abs(crossprod(Z, sample$population * (sample$change_pp - X %*% beta))))))
write_json(result, "result.json", auto_unbox = TRUE, pretty = TRUE, null = "null", digits = 16)

# Independent algebraic check: 2SLS coefficient equals OLS on projected regressors.
sqrtw <- sqrt(sample$population)
Zw <- Z * sqrtw
Xw <- X * sqrtw
yw <- sample$change_pp * sqrtw
PzXw <- Zw %*% solve(crossprod(Zw), crossprod(Zw, Xw))
beta_check <- solve(crossprod(PzXw), crossprod(PzXw, yw))
stopifnot(max(abs(beta - beta_check)) < 1e-8)
writeLines(c(
  "Verification checks",
  paste("Estimation rows:", nrow(sample), "(expected 72); unique area-period keys:", nrow(unique(sample[c('area','period')]))),
  paste("Exposure construction: four industries completed with zero; national totals sum supplied areas within period and vintage."),
  paste("Estimator: weighted 2SLS with intercept, period, control, x and instruments intercept, period, control, z."),
  paste("Independent numerical check: weighted projected-regressor identity; maximum coefficient difference =", format(max(abs(beta-beta_check)), digits=16, scientific=TRUE)),
  paste("Area 0, period 0 x:", format(estimates[[2]]$estimate, digits=16)),
  paste("Area 0, period 1 x:", format(estimates[[3]]$estimate, digits=16)),
  paste("Area 0, period 0 z:", format(estimates[[4]]$estimate, digits=16)),
  paste("IV slope:", format(iv_slope, digits=16))
), "verification.txt")
