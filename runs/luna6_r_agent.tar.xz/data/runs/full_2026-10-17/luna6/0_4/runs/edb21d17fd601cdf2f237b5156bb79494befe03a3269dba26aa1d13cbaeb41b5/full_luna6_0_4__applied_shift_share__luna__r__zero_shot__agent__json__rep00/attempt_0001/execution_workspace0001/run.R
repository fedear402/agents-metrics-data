d <- read.csv('input.csv', stringsAsFactors=FALSE)
req <- c('region_id','industry_id','share','shock','region_weight','x','y')
stopifnot(all(req %in% names(d)), all(is.finite(as.matrix(d[req[3:7]]))))
# Check one repeated region record per region and one shock per industry.
region_cols <- c('region_weight','x','y')
for (v in region_cols) stopifnot(all(vapply(split(d[[v]], d$region_id), function(a) length(unique(a)) == 1L, logical(1))))
stopifnot(all(vapply(split(d$shock, d$industry_id), function(a) length(unique(a)) == 1L, logical(1))))
share_sums <- tapply(d$share, d$region_id, sum)
stopifnot(max(abs(share_sums - 1)) < 1e-8)
# Keep all regions and industries; weights are normalized once by region.
r <- unique(d[c('region_id','region_weight','x','y')])
r <- r[order(r$region_id), ]
r$e <- r$region_weight / sum(r$region_weight)
# Construct instrument with all supplied region-industry observations.
z <- aggregate(share ~ region_id, d, sum) # placeholder for matched construction below
z <- tapply(d$share * d$shock, d$region_id, sum)
r$z <- as.numeric(z[as.character(r$region_id)])
stopifnot(all(is.finite(r$z)), abs(sum(r$e)-1) < 1e-12)
# Weighted demean regional variables.
wm <- function(v,w) sum(v*w)
r$y0 <- r$y - wm(r$y,r$e)
r$x0 <- r$x - wm(r$x,r$e)
r$z0 <- r$z - wm(r$z,r$e)
# Exposure shares s_n and weighted aggregated demeaned variables.
d$e <- r$e[match(d$region_id,r$region_id)]
d$y0 <- r$y0[match(d$region_id,r$region_id)]
d$x0 <- r$x0[match(d$region_id,r$region_id)]
d$z0 <- r$z0[match(d$region_id,r$region_id)]
d$eyshare <- d$e*d$share
by_ind <- split(seq_len(nrow(d)), d$industry_id)
agg <- do.call(rbind, lapply(names(by_ind), function(id) {
  ii <- by_ind[[id]]; s <- sum(d$eyshare[ii])
  data.frame(industry_id=id, shock=d$shock[ii[1]], s=s,
    ybar=sum(d$eyshare[ii]*d$y0[ii])/s,
    xbar=sum(d$eyshare[ii]*d$x0[ii])/s,
    zbar=sum(d$eyshare[ii]*d$z0[ii])/s)
}))
rownames(agg) <- NULL
stopifnot(all(agg$s > 0), abs(sum(agg$s)-1) < 1e-8)
# Weighted scalar IV with intercept. Compute 2SLS and HC1 sandwich directly,
# using structural IV residuals and analytic weights as specified.
iv_hc1 <- function(dat, outcome, endogenous, instrument, weight) {
  Y <- dat[[outcome]]; X <- cbind(1, dat[[endogenous]])
  Q <- cbind(1, dat[[instrument]])
  w <- dat[[weight]]; N <- nrow(dat)
  A <- crossprod(Q, Q*w)
  B <- crossprod(Q, X*w)
  beta <- solve(crossprod(X*w, Q) %*% solve(A, crossprod(Q, X*w)),
                crossprod(X*w,Q) %*% solve(A,crossprod(Q,Y*w)))
  # Equivalent weighted 2SLS bread based on projected regressors.
  Xhat <- Q %*% solve(A, crossprod(Q, X*w))
  bread <- solve(crossprod(Xhat, X*w))
  u <- Y - X %*% beta
  score <- Xhat * as.numeric(w*u)
  meat <- crossprod(score)
  V <- (N/(N-2)) * bread %*% meat %*% bread
  list(beta=as.numeric(beta), se=sqrt(diag(V)), residual=as.numeric(u))
}
# Primary effect: regional weighted 2SLS estimate, checked against shock-level IV.
reg_effect <- iv_hc1(data.frame(y=r$y,x=r$x,z=r$z,e=r$e),'y','x','z','e')
shock_effect <- iv_hc1(agg,'ybar','xbar','shock','s')
# Relevance: regional weighted first-stage OLS and exposure-robust shock-level IV.
reg_fs <- lm(x ~ z, data=r, weights=e)
shock_fs <- iv_hc1(agg,'xbar','zbar','shock','s')
N <- nrow(agg)
stopifnot(length(unique(d$industry_id)) == N)
# Identity checks: the shock-level IV slope must equal regional weighted IV;
# the shock-level first-stage IV slope must equal regional weighted OLS slope.
if (abs(shock_effect$beta[2] - reg_effect$beta[2]) > 1e-7) stop('Regional and shock-level effect slopes disagree')
if (abs(shock_fs$beta[2] - unname(coef(reg_fs)[2])) > 1e-7) stop('Regional and shock-level first-stage slopes disagree')
write_json <- function(obj, path) {
  # JSON emitted directly to keep null values and numeric precision clear.
  con <- file(path, 'wt'); on.exit(close(con))
  encode_num <- function(x) if (is.finite(x)) sprintf('%.15g',x) else 'null'
  rows <- vapply(obj$estimates, function(a) sprintf('    {"term":"%s","estimate":%s,"se":%s,"n_obs":%d}',
    a$term, encode_num(a$estimate), if (is.null(a$se)) 'null' else encode_num(a$se), a$n_obs), character(1))
  cat('{\n  "task_id":"applied_shift_share",\n  "platform":"r",\n  "estimates":[\n', paste(rows,collapse=',\n'), '\n  ],\n',
      '  "method_metadata":{"estimator":"weighted 2SLS with shock-level IV aggregation","vcov":"shock-level HC1 robust, structural IV residuals, analytic weights, no clustering"},\n',
      '  "diagnostics":{}\n}\n', file=con, sep='')
}
write_json(list(estimates=list(
  list(term='effect',estimate=shock_effect$beta[2],se=shock_effect$se[2],n_obs=N),
  list(term='first_stage',estimate=shock_fs$beta[2],se=shock_fs$se[2],n_obs=N),
  list(term='effective_shocks',estimate=1/sum(agg$s^2),se=NULL,n_obs=N)
)), 'result.json')
# Save compact verification record from final run.
writeLines(c(
  sprintf('Regions used: %d; region-industry rows used: %d; industries used: %d.', nrow(r), nrow(d), N),
  sprintf('Regional shares sum to one within each region: max absolute error %.3g.', max(abs(share_sums-1))),
  sprintf('Regional weights normalized once: sum(e) = %.15g.', sum(r$e)),
  sprintf('Industry exposure shares sum to %.15g.', sum(agg$s)),
  sprintf('Independent identity: effect slope regional IV %.12g; shock-level IV %.12g; absolute difference %.3g.', reg_effect$beta[2], shock_effect$beta[2], abs(reg_effect$beta[2]-shock_effect$beta[2])),
  sprintf('Independent identity: first-stage slope regional WLS %.12g; shock-level IV %.12g; absolute difference %.3g.', unname(coef(reg_fs)[2]), shock_fs$beta[2], abs(unname(coef(reg_fs)[2])-shock_fs$beta[2])),
  sprintf('Effect SE computed with N/(N-2) = %d/%d and shock-level structural IV residual scores.', N,N-2),
  sprintf('Effective shocks = %.12g.', 1/sum(agg$s^2))
), 'verification.txt')
