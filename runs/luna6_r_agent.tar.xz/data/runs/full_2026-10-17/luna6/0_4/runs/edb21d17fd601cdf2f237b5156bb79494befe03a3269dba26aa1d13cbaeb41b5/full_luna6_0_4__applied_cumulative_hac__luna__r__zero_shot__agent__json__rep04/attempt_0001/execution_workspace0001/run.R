args <- commandArgs(trailingOnly = TRUE)
input_path <- "input.csv"
data <- read.csv(input_path, stringsAsFactors = FALSE)
data$date <- as.Date(data$date)
data <- data[order(data$date), ]

stopifnot(identical(names(data), c("date", "sales", "vix")))
stopifnot(all(is.finite(data$sales)), all(data$sales > 0))
stopifnot(all(is.finite(data$vix)), all(data$vix > 0))

delta_log_vix <- c(NA_real_, diff(log(data$vix)))
lag_matrix <- sapply(1:15, function(k) c(rep(NA_real_, k), delta_log_vix[seq_len(length(delta_log_vix) - k)]))
colnames(lag_matrix) <- paste0("lag_", 1:15)
reg <- data.frame(log_sales = log(data$sales), lag_matrix, check.names = FALSE)
reg <- reg[complete.cases(reg), ]
fit <- lm(log_sales ~ ., data = reg)
X <- model.matrix(fit)
u <- residuals(fit)
N <- nrow(X)
stopifnot(N == nrow(data) - 16L)

# Newey-West meat, Bartlett weights, maximum lag 15, with the requested finite-sample multiplier.
bread <- solve(crossprod(X))
score <- X * as.numeric(u)
meat <- crossprod(score)
for (j in 1:15) {
  weight <- 1 - j / 16
  gamma <- crossprod(score[(j + 1):N, , drop = FALSE], score[1:(N - j), , drop = FALSE])
  meat <- meat + weight * (gamma + t(gamma))
}
V <- (N / (N - 16)) * bread %*% meat %*% bread

beta <- coef(fit)
cum_vector <- setNames(rep(0, length(beta)), names(beta))
cum_vector[paste0("lag_", 1:15)] <- 1
terms <- c("cumulative_response", "lag_1", "lag_15")
estimates <- c(sum(beta[paste0("lag_", 1:15)]), beta["lag_1"], beta["lag_15"])
ses <- c(sqrt(drop(t(cum_vector) %*% V %*% cum_vector)), sqrt(V["lag_1", "lag_1"]), sqrt(V["lag_15", "lag_15"]))
out <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = lapply(seq_along(terms), function(i) list(term = terms[i], estimate = unname(estimates[i]), se = unname(ses[i]), n_obs = as.integer(N))),
  method_metadata = list(estimator = "OLS of log(sales) on intercept and lags 1 through 15 of first difference of log(vix)", vcov = "Newey-West HAC, Bartlett weights, maximum lag 15, multiplied by N/(N-16)"),
  diagnostics = list(input_observations = nrow(data), regression_observations = N, first_difference_observations = sum(is.finite(delta_log_vix), na.rm = TRUE), lag_definition = "trading observations")
)
jsonlite::write_json(out, "result.json", auto_unbox = TRUE, digits = 15, pretty = TRUE, null = "null")

# Independent numerical checks: direct lag alignment and an equivalent weighted residual-score sum.
stopifnot(isTRUE(all.equal(reg$lag_1, delta_log_vix[(nrow(data)-N+1-1):(nrow(data)-1)], tolerance = 1e-12)))
meat_alt <- crossprod(score)
for (j in 1:15) {
  weight <- (16 - j) / 16
  gamma_alt <- Reduce(`+`, lapply(seq_len(N-j), function(t) tcrossprod(score[t+j, ], score[t, ])))
  meat_alt <- meat_alt + weight * (gamma_alt + t(gamma_alt))
}
V_alt <- (N / (N - 16)) * bread %*% meat_alt %*% bread
stopifnot(max(abs(V - V_alt)) < 1e-10)
cat(sprintf("N=%d; max covariance difference=%.3g; cumulative SE identity check=%.3g\n", N, max(abs(V-V_alt)), ses[1]^2 - drop(t(cum_vector) %*% V %*% cum_vector)))
