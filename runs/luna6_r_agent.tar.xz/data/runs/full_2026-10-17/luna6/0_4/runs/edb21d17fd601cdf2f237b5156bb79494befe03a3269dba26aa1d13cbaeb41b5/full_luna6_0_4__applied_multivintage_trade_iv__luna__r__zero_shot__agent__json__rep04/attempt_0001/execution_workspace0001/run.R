suppressPackageStartupMessages(library(jsonlite))

crosswalk <- read.csv('crosswalk.csv', stringsAsFactors = FALSE)
trade <- read.csv('trade.csv', stringsAsFactors = FALSE)
areas <- read.csv('areas.csv', stringsAsFactors = FALSE)
employment <- read.csv('employment.csv', stringsAsFactors = FALSE)
outcomes <- read.csv('outcomes.csv', stringsAsFactors = FALSE)

stopifnot(nrow(crosswalk) == 8L, nrow(trade) == 8L)
stopifnot(!anyDuplicated(crosswalk$code), !anyDuplicated(trade[c('period','code')]))
trade <- merge(trade, crosswalk, by='code', all.x=TRUE, sort=FALSE)
stopifnot(!anyNA(trade$industry), length(unique(trade$industry)) == 4L)

# Fill omitted area-period-vintage-industry cells with zero.
key <- unique(areas[c('area','period','vintage')])
industries <- sort(unique(crosswalk$industry))
full_emp <- merge(key, data.frame(industry=industries), by=NULL)
employment_full <- merge(full_emp, employment,
                         by=c('area','period','vintage','industry'),
                         all.x=TRUE, sort=FALSE)
employment_full$employment[is.na(employment_full$employment)] <- 0

# National industry employment sums across all supplied areas, by period and vintage.
national <- aggregate(employment ~ period + vintage + industry,
                      data=employment_full, FUN=sum)
base_area <- areas[areas$vintage == 'base',
                   c('area','period','total_employment','population')]
early_area <- areas[areas$vintage == 'early', c('area','period','total_employment')]
base_ind <- employment_full[employment_full$vintage == 'base',
                             c('area','period','industry','employment')]
early_ind <- employment_full[employment_full$vintage == 'early',
                              c('area','period','industry','employment')]

calc_exposure <- function(area_df, ind_df, vintage, trade_col, output_name) {
  a <- merge(ind_df, area_df, by=c('area','period'), all=FALSE)
  a <- merge(a, national[national$vintage == vintage,
                         c('period','industry','employment')],
             by=c('period','industry'), suffixes=c('_area','_national'))
  a <- merge(a, trade[c('period','industry',trade_col,'price_index','years')],
             by=c('period','industry'))
  # Each industry has one trade row per period. Exposure is real thousand dollars
  # per worker per decade, with interval annualization as specified.
  a$piece <- (a$employment_area / a$total_employment) *
    (a[[trade_col]] / a$employment_national) /
    (a$price_index / 100) / 1000 * (10 / a$years)
  out <- aggregate(piece ~ area + period, data=a, FUN=sum)
  names(out)[names(out) == 'piece'] <- output_name
  out
}
x <- calc_exposure(base_area, base_ind, 'base', 'us_change', 'x')
z <- calc_exposure(early_area, early_ind, 'early', 'other_change', 'z')

sample <- merge(base_area, outcomes, by=c('area','period'), all=FALSE)
sample <- merge(sample, x, by=c('area','period'), all=FALSE)
sample <- merge(sample, z, by=c('area','period'), all=FALSE)
sample$period_indicator <- as.numeric(sample$period == 1)
stopifnot(nrow(sample) == 72L, !anyNA(sample[c('change_pp','control','x','z','population')]))

# Weighted 2SLS: project each column on all instruments, then solve the
# weighted second-stage normal equations. All exogenous regressors instrument themselves.
X <- cbind(intercept=1, period=sample$period_indicator,
           control=sample$control, x=sample$x)
Q <- cbind(intercept=1, period=sample$period_indicator,
           control=sample$control, z=sample$z)
W <- sample$population
sqrtW <- sqrt(W)
Qw <- Q * sqrtW
Xw <- X * sqrtW
yw <- sample$change_pp * sqrtW
P_Xw <- Qw %*% solve(crossprod(Qw), crossprod(Qw, Xw))
beta <- solve(crossprod(P_Xw), crossprod(P_Xw, yw))

estimates <- list(
  list(term='iv_slope', estimate=unname(beta[4]), se=NA_real_, n_obs=72L),
  list(term='exposure_area0_period0', estimate=x$x[x$area == 0 & x$period == 0], se=NA_real_, n_obs=72L),
  list(term='exposure_area0_period1', estimate=x$x[x$area == 0 & x$period == 1], se=NA_real_, n_obs=72L),
  list(term='instrument_area0_period0', estimate=z$z[z$area == 0 & z$period == 0], se=NA_real_, n_obs=72L)
)
result <- list(task_id='applied_multivintage_trade_iv', platform='r', estimates=estimates,
               method_metadata=list(estimator='weighted 2SLS',
                 outcome='change_pp', regressors=c('intercept','period','control','x'),
                 instrumented_regressor='x', instruments=c('intercept','period','control','z'),
                 weight='base-vintage population', exposure_units='thousands of real dollars per worker per decade'),
               diagnostics=list(n_obs=72L, estimation_rows=nrow(sample),
                 periods=length(unique(sample$period)), industries=length(industries),
                 missing_employment_cells_filled_with_zero=TRUE))
write_json(result, 'result.json', auto_unbox=TRUE, pretty=TRUE, na='null', digits=17)

# Independent checks: recompute one focal exposure from its four components,
# and verify 2SLS equals weighted IV after partialling out all exogenous controls.
focus <- merge(base_ind[base_ind$area == 0 & base_ind$period == 0,],
               national[national$vintage == 'base' & national$period == 0,],
               by='industry', suffixes=c('_area','_national'))
focus <- merge(focus, trade[trade$period == 0, c('industry','us_change','price_index','years')], by='industry')
manual_x00 <- sum((focus$employment_area / base_area$total_employment[base_area$area == 0 & base_area$period == 0]) *
                   (focus$us_change / focus$employment_national) /
                   (focus$price_index / 100) / 1000 * (10 / focus$years))
C <- cbind(intercept=1, period=sample$period_indicator, control=sample$control)
Cw <- C * sqrtW
resid_w <- function(v) v - Cw %*% solve(crossprod(Cw), crossprod(Cw, v))
xr <- resid_w(sample$x * sqrtW)
zr <- resid_w(sample$z * sqrtW)
yr <- resid_w(sample$change_pp * sqrtW)
manual_iv <- sum(zr * yr) / sum(zr * xr)
writeLines(c(
  sprintf('sample_rows=%d (task target: 72)', nrow(sample)),
  sprintf('unique_area_period_rows=%d', nrow(unique(sample[c('area','period')]))),
  sprintf('industries=%d', length(industries)),
  sprintf('area0_period0_exposure_script=%.17g', x$x[x$area==0 & x$period==0]),
  sprintf('area0_period0_exposure_manual=%.17g', manual_x00),
  sprintf('exposure_absolute_difference=%.17g', abs(manual_x00 - x$x[x$area==0 & x$period==0])),
  sprintf('iv_slope_projection=%.17g', beta[4]),
  sprintf('iv_slope_partialled_out_identity=%.17g', manual_iv),
  sprintf('iv_slope_absolute_difference=%.17g', abs(beta[4] - manual_iv)),
  '2SLS check: weighted projection on all instruments; independent Frisch-Waugh-Lovell check partials out the three exogenous columns.'
), 'verification.txt')
cat(sprintf('rows=%d, slope=%.12g, x00=%.12g, x01=%.12g, z00=%.12g\n',
            nrow(sample), beta[4], estimates[[2]]$estimate, estimates[[3]]$estimate,
            estimates[[4]]$estimate))
