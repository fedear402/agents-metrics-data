#!/usr/bin/env Rscript
suppressPackageStartupMessages(library(jsonlite))

d <- read.csv("input.csv", stringsAsFactors = FALSE)
required <- c("region_id", "industry_id", "share", "shock", "region_weight", "x", "y")
stopifnot(all(required %in% names(d)), all(is.finite(as.matrix(d[required[-(1:2)]]))))

# Check repeated regional variables and industry shocks, then form one row per region.
region_groups <- split(seq_len(nrow(d)), d$region_id)
industry_groups <- split(seq_len(nrow(d)), d$industry_id)
stopifnot(all(vapply(region_groups, function(i) length(unique(d$region_weight[i])) == 1L &&
                       length(unique(d$x[i])) == 1L && length(unique(d$y[i])) == 1L, logical(1))))
stopifnot(all(vapply(industry_groups, function(i) length(unique(d$shock[i])) == 1L, logical(1))))
regions <- do.call(rbind, lapply(region_groups, function(i) {
  c(region_id = d$region_id[i[1]], region_weight = d$region_weight[i[1]],
    x = d$x[i[1]], y = d$y[i[1]])
}))
regions <- as.data.frame(regions)
regions[] <- lapply(regions, as.numeric)
regions$region_id <- as.integer(regions$region_id)
regions <- regions[order(regions$region_id), , drop = FALSE]
rownames(regions) <- NULL
e <- regions$region_weight / sum(regions$region_weight)

# Confirm each region's shares sum to one, then construct the shift-share instrument.
share_sums <- vapply(region_groups, function(i) sum(d$share[i]), numeric(1))
stopifnot(max(abs(share_sums - 1)) < 1e-8)
region_index <- match(d$region_id, regions$region_id)
z_sums <- rowsum(d$share * d$shock, d$region_id, reorder = TRUE)
z <- as.numeric(z_sums[as.character(regions$region_id), 1])
regions$z <- z
regions$e <- e

# Weighted regional IV slopes use the residualized variables, so no intercept is needed here.
wmean <- function(v) sum(e * v)
y0 <- regions$y - wmean(regions$y)
x0 <- regions$x - wmean(regions$x)
z0 <- regions$z - wmean(regions$z)
regional_effect <- sum(e * z0 * y0) / sum(e * z0 * x0)
regional_first <- sum(e * z0 * x0) / sum(e * z0^2)

# Shock-level exposure masses and weighted averages of regional residuals.
ids <- sort(unique(d$industry_id))
shock <- vapply(ids, function(j) d$shock[which(d$industry_id == j)[1]], numeric(1))
s <- vapply(ids, function(j) sum(e[match(d$region_id[d$industry_id == j], regions$region_id)] *
                                    d$share[d$industry_id == j]), numeric(1))
aggregate_residual <- function(v0) {
  vapply(seq_along(ids), function(k) {
    take <- d$industry_id == ids[k]
    sum(e[match(d$region_id[take], regions$region_id)] * d$share[take] *
          v0[match(d$region_id[take], regions$region_id)]) / s[k]
  }, numeric(1))
}
ybar <- aggregate_residual(y0)
xbar <- aggregate_residual(x0)
zbar <- aggregate_residual(z0)
N <- length(ids)
stopifnot(N > 2L, all(s > 0), abs(sum(s) - 1) < 1e-8)

# Weighted just-identified IV and HC1 sandwich with structural IV residuals.
shock_iv <- function(dependent, endogenous) {
  X <- cbind(1, endogenous)
  Q <- cbind(1, shock)
  A <- crossprod(Q, s * X)
  beta <- solve(A, crossprod(Q, s * dependent))
  residual <- as.numeric(dependent - X %*% beta)
  scores <- Q * (s * residual)
  Ainv <- solve(A)
  V <- (N / (N - 2)) * Ainv %*% crossprod(scores) %*% t(Ainv)
  c(estimate = beta[2], se = sqrt(V[2, 2]))
}
effect <- shock_iv(ybar, xbar)
first_stage <- shock_iv(xbar, zbar)
effective_shocks <- 1 / sum(s^2)

# Independent identity checks: aggregation preserves weighted regional cross-products.
check_aggregate <- function(a0, b0, abar, bbar) {
  regional <- sum(e * a0 * b0)
  shock_level <- sum(s * abar * bbar)
  c(regional = regional, shock_level = shock_level)
}
identity_effect <- c(regional = sum(e * z0 * y0),
                     shock_level = sum(s * shock * ybar))
identity_first <- c(regional = sum(e * z0 * x0),
                     shock_level = sum(s * shock * xbar))
stopifnot(max(abs(identity_effect[1] - identity_effect[2]),
               abs(identity_first[1] - identity_first[2])) < 1e-10)
stopifnot(abs(effect["estimate"] - regional_effect) < 1e-9,
          abs(first_stage["estimate"] - regional_first) < 1e-9)

row <- function(term, estimate, se = NULL) {
  list(term = term, estimate = unname(as.numeric(estimate)),
       se = if (is.null(se)) NULL else unname(as.numeric(se)), n_obs = as.integer(N))
}
out <- list(task_id = "applied_shift_share", platform = "r",
            estimates = list(row("effect", effect["estimate"], effect["se"]),
                             row("first_stage", first_stage["estimate"], first_stage["se"]),
                             row("effective_shocks", effective_shocks)),
            method_metadata = list(estimator = "Borusyak-Hull-Jaravel shock-level weighted IV",
                                   vcov = "shock-level HC1, structural IV residuals, analytic weights, no clustering"),
            diagnostics = list(n_regions = nrow(regions), n_industries = N,
                              n_region_industry_rows = nrow(d),
                              max_share_sum_error = max(abs(share_sums - 1)),
                              effect_slope_check_error = abs(effect["estimate"] - regional_effect),
                              first_stage_slope_check_error = abs(first_stage["estimate"] - regional_first),
                              effect_cross_product_check_error = abs(identity_effect[1] - identity_effect[2]),
                              first_stage_cross_product_check_error = abs(identity_first[1] - identity_first[2])))
write_json(out, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)

verification <- c(
  "Sample: input.csv contains 11,520 region-industry rows; the script uses all rows.",
  sprintf("Unique regions: %d. Unique industries used as shock observations: %d.", nrow(regions), N),
  sprintf("Maximum absolute error in within-region share sums: %.3g.", max(abs(share_sums - 1))),
  sprintf("Regional weighted IV effect slope: %.12g; shock-level slope: %.12g; absolute difference: %.3g.", regional_effect, effect["estimate"], abs(effect["estimate"] - regional_effect)),
  sprintf("Regional weighted first-stage slope: %.12g; shock-level slope: %.12g; absolute difference: %.3g.", regional_first, first_stage["estimate"], abs(first_stage["estimate"] - regional_first)),
  sprintf("Independent aggregation identity error for effect cross-product: %.3g.", abs(identity_effect[1] - identity_effect[2])),
  sprintf("Independent aggregation identity error for first-stage cross-product: %.3g.", abs(identity_first[1] - identity_first[2])),
  "Uncertainty uses structural IV residuals, analytic exposure weights, and N/(N-2) HC1 multiplier; no clustering."
)
writeLines(verification, "verification.txt")
