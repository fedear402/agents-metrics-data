d <- read.csv("input.csv")
stopifnot(all(c("region_id","industry_id","share","shock","region_weight","x","y") %in% names(d)))
# Confirm one repeated regional record per region and one shock per industry.
regions <- unique(d[c("region_id","region_weight","x","y")])
industries <- unique(d[c("industry_id","shock")])
stopifnot(nrow(regions) == length(unique(d$region_id)), nrow(industries) == length(unique(d$industry_id)))
stopifnot(max(abs(tapply(d$share,d$region_id,sum)-1)) < 1e-8)
e <- regions$region_weight/sum(regions$region_weight)
R <- nrow(regions); N <- nrow(industries)
# Align a region by industry matrix using explicit identifiers.
ri <- match(d$region_id, regions$region_id); ni <- match(d$industry_id, industries$industry_id)
S <- matrix(0,R,N)
S[cbind(ri,ni)] <- d$share
stopifnot(all(is.finite(S)), max(abs(rowSums(S)-1)) < 1e-8)
# Variables repeated within region; get the single value per region.
get_region <- function(nm) regions[[nm]]
x <- get_region("x"); y <- get_region("y")
z <- drop(S %*% industries$shock)
center <- function(a) a - sum(e*a)
y0 <- center(y); x0 <- center(x); z0 <- center(z)
mass <- drop(crossprod(e,S))
agg <- function(v0) drop(crossprod(S,e*v0))/mass
ybar <- agg(y0); xbar <- agg(x0); zbar <- agg(z0)
# Weighted just-identified IV slope and structural-residual HC1 covariance.
shock_iv <- function(dep,endog,inst,weight) {
  X <- cbind(1,endog); Q <- cbind(1,inst)
  A <- crossprod(Q, weight*X)
  b <- solve(A, crossprod(Q,weight*dep))
  u <- drop(dep-X%*%b)
  score <- Q*(weight*u)
  Ai <- solve(A)
  V <- (N/(N-2))*Ai%*%crossprod(score)%*%t(Ai)
  c(estimate=b[2],se=sqrt(V[2,2]))
}
effect <- shock_iv(ybar,xbar,industries$shock,mass)
first_stage <- shock_iv(xbar,zbar,industries$shock,mass)
# Regional weighted slope identities for independent numerical validation.
regional_effect <- sum(e*z0*y0)/sum(e*z0*x0)
regional_first <- sum(e*z0*x0)/sum(e*z0^2)
stopifnot(abs(effect["estimate"]-regional_effect)<1e-9,
          abs(first_stage["estimate"]-regional_first)<1e-9)
rows <- list(
 list(term="effect",estimate=unname(effect["estimate"]),se=unname(effect["se"]),n_obs=as.integer(N)),
 list(term="first_stage",estimate=unname(first_stage["estimate"]),se=unname(first_stage["se"]),n_obs=as.integer(N)),
 list(term="effective_shocks",estimate=unname(1/sum(mass^2)),se=NULL,n_obs=as.integer(N)))
jsonlite::write_json(list(task_id="applied_shift_share",platform="r",estimates=rows,
 method_metadata=list(estimator="weighted regional 2SLS; equivalent shock-level weighted IV",vcov="shock-level structural-residual HC1, analytic weights, N/(N-2), no clustering"),diagnostics=list(n_regions=as.integer(R),n_industries=as.integer(N))),
 "result.json",auto_unbox=TRUE,null="null",digits=16,pretty=TRUE)
