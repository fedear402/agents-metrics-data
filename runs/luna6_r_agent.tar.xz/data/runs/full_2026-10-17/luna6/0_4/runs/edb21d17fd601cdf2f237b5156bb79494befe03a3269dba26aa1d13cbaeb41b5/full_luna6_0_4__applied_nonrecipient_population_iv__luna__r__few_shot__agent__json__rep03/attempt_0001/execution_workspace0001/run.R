suppressPackageStartupMessages(library(jsonlite))

households <- read.csv("households.csv")
census <- read.csv("census.csv")

# Retain every nonrecipient household in both village treatment statuses.
d <- households[households$recipient == 0, , drop = FALSE]
g0 <- 1 - d$eligible
g1 <- d$eligible

# Two endogenous dose-by-eligibility terms and the six stated instruments.
X <- cbind(
  ineligible = g0,
  eligible = g1,
  baseline_ineligible = d$baseline * g0,
  baseline_eligible = d$baseline * g1,
  dose_ineligible = d$dose * g0,
  dose_eligible = d$dose * g1
)
Z <- cbind(
  ineligible = g0,
  eligible = g1,
  baseline_ineligible = d$baseline * g0,
  baseline_eligible = d$baseline * g1,
  instrument_ineligible = d$instrument * g0,
  instrument_eligible = d$instrument * g1
)
w <- d$weight
sw <- sqrt(w)
Xw <- X * sw
Zw <- Z * sw
yw <- d$outcome * sw

# Weighted 2SLS: solve (X'W P_Z X) b = X'W P_Z y.
qz <- qr(Zw)
Xhat <- qr.fitted(qz, Xw)
yhat <- qr.fitted(qz, yw)
coef <- as.numeric(qr.solve(crossprod(Xhat), crossprod(Xhat, yw)))
names(coef) <- colnames(X)

n_obs <- nrow(d)
means <- vapply(0:1, function(g) {
  a <- d[d$eligible == g, , drop = FALSE]
  weighted.mean(a$dose, a$weight)
}, numeric(1))
effects <- c(
  ineligible_effect = coef[["dose_ineligible"]] * means[[1]],
  eligible_nonrecipient_effect = coef[["dose_eligible"]] * means[[2]]
)
pop_counts <- census$nonrecipient_population[match(0:1, census$eligible)]
population_effect <- weighted.mean(effects, pop_counts)

estimates <- list(
  list(term = "ineligible_effect", estimate = unname(effects[[1]]), se = NULL, n_obs = as.integer(n_obs)),
  list(term = "eligible_nonrecipient_effect", estimate = unname(effects[[2]]), se = NULL, n_obs = as.integer(n_obs)),
  list(term = "population_effect", estimate = unname(population_effect), se = NULL, n_obs = as.integer(n_obs))
)
result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "weighted two-stage least squares",
    endogenous = c("dose*(1-eligible)", "dose*eligible"),
    exogenous = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"),
    instruments = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible", "instrument*(1-eligible)", "instrument*eligible"),
    counterfactual = "dose set to zero for every retained household; synthetic attribution convention",
    aggregation = "census nonrecipient_population counts used only for final between-group weighting"
  ),
  diagnostics = list(
    n_obs = as.integer(n_obs),
    retained_recipient_values = sort(unique(d$recipient)),
    retained_eligible_counts = as.list(table(factor(d$eligible, levels = 0:1))),
    weighted_mean_dose = as.list(setNames(as.numeric(means), c("ineligible", "eligible"))),
    dose_slopes = as.list(coef[c("dose_ineligible", "dose_eligible")])
  )
)
write_json(result, "result.json", auto_unbox = TRUE, digits = 15, pretty = TRUE, null = "null")
