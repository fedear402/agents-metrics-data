library(jsonlite)

input <- read.csv("input.csv", stringsAsFactors = FALSE)
input$date <- as.Date(input$date)
input <- input[order(input$date), ]
stopifnot(all(is.finite(input$sales)), all(input$sales > 0), all(input$vix > 0))

n <- nrow(input)
input$log_sales <- log(input$sales)
change <- c(NA_real_, diff(log(input$vix)))
for (j in 1:15) input[[paste0("lag_", j)]] <- c(rep(NA_real_, j), head(change, n-j))
vars <- c("log_sales", paste0("lag_", 1:15))
sample <- input[complete.cases(input[, vars]), ]
fit <- lm(log_sales ~ ., data=sample[, vars])
X <- model.matrix(fit)
e <- residuals(fit)
beta <- coef(fit)
N <- nrow(X)
p <- ncol(X)
stopifnot(N == n - 16, p == 16)

# Bartlett Newey-West covariance, with the requested finite-sample multiplier.
scores <- X * as.numeric(e)
meat <- crossprod(scores)
for (j in 1:15) {
  cross_lag <- crossprod(scores[(j+1):N, , drop=FALSE], scores[1:(N-j), , drop=FALSE])
  meat <- meat + (1-j/16) * (cross_lag + t(cross_lag))
}
bread <- solve(crossprod(X))
V <- (N/(N-16)) * bread %*% meat %*% bread

contrast <- c(0, rep(1,15))
vals <- c(sum(beta[-1]), beta[2], beta[16])
ses <- c(sqrt(drop(t(contrast) %*% V %*% contrast)), sqrt(V[2,2]), sqrt(V[16,16]))
terms <- c("cumulative_response", "lag_1", "lag_15")
rows <- lapply(seq_along(terms), function(i) list(term=terms[i], estimate=unname(as.numeric(vals[i])), se=unname(as.numeric(ses[i])), n_obs=as.integer(N)))
write_json(list(task_id="applied_cumulative_hac", platform="r", estimates=rows,
                method_metadata=list(estimator="OLS with intercept and 15 observed-row lags of log VIX changes", vcov="Newey-West Bartlett HAC, maximum lag 15, multiplier N/(N-16)"),
                diagnostics=list(total_observations=n, first_usable_date=as.character(min(sample$date)), last_usable_date=as.character(max(sample$date)), regression_sample_size=N, parameter_count=p, hac_max_lag=15)),
           "result.json", auto_unbox=TRUE, digits=16, pretty=TRUE)
