dat <- read.csv("input.csv")

# Keep the specified open bandwidth and apply the fixed triangular weights.
d <- dat[abs(dat$score) < 1, c("score", "participated", "earnings")]
d$right <- as.numeric(d$score >= 0)
d$weight <- 1 - abs(d$score)
d$right_score <- d$right * d$score

# The regressors give each side its own intercept and slope. WLS uses the
# triangular weights; HC0 uses the corresponding weighted score residuals.
X <- cbind(intercept_left = 1 - d$right,
           intercept_right = d$right,
           slope_left = d$score * (1 - d$right),
           slope_right = d$right_score)
fit_hc0 <- function(y) {
  y <- as.numeric(y)
  w <- d$weight
  bread <- solve(crossprod(X, w * X))
  beta <- as.vector(bread %*% crossprod(X, w * y))
  residual <- y - as.vector(X %*% beta)
  meat <- crossprod(X, (w * residual) * X)
  V <- bread %*% meat %*% bread
  # Right intercept minus left intercept.
  contrast <- c(-1, 1, 0, 0)
  list(discontinuity = sum(contrast * beta), variance = as.numeric(contrast %*% V %*% contrast), beta = beta, V = V)
}

rf <- fit_hc0(d$earnings)
fs <- fit_hc0(d$participated)
ratio <- rf$discontinuity / fs$discontinuity
# Delta method with joint HC0 covariance. Both outcomes use identical X and W.
cross_meat <- crossprod(X, (d$weight^2 * (d$earnings - as.vector(X %*% rf$beta)) *
                             (d$participated - as.vector(X %*% fs$beta))) * X)
bread <- solve(crossprod(X, d$weight * X))
cross_V <- bread %*% cross_meat %*% bread
contrast <- c(-1, 1, 0, 0)
cov_rf_fs <- as.numeric(contrast %*% cross_V %*% contrast)
var_ratio <- rf$variance / fs$discontinuity^2 +
  rf$discontinuity^2 * fs$variance / fs$discontinuity^4 -
  2 * rf$discontinuity * cov_rf_fs / fs$discontinuity^3

if (!is.finite(var_ratio) || var_ratio < -1e-12) stop("Invalid delta-method variance")
se_ratio <- sqrt(max(0, var_ratio))
n <- nrow(d)
fmt <- function(x) if (is.finite(x)) sprintf("%.12g", x) else "null"
row_json <- function(term, est, se) sprintf('{"term":"%s","estimate":%s,"se":%s,"n_obs":%d}', term, fmt(est), fmt(se), n)

json <- paste0(
  '{\n  "task_id": "applied_fuzzy_rd",\n',
  '  "platform": "r",\n',
  '  "estimates": [\n    ', row_json("treatment_effect", ratio, se_ratio), ',\n    ',
  row_json("reduced_form", rf$discontinuity, sqrt(rf$variance)), ',\n    ',
  row_json("first_stage", fs$discontinuity, sqrt(fs$variance)), '\n  ],\n',
  '  "method_metadata": {"estimator":"Triangular-weighted local-linear fuzzy regression discontinuity; bandwidth 1","vcov":"HC0 sandwich; delta method with joint cross-outcome covariance"},\n',
  '  "diagnostics": {}\n}\n')
writeLines(json, "result.json")

cat(sprintf("n_obs=%d\nreduced_form=%.12g se=%.12g\nfirst_stage=%.12g se=%.12g\ntreatment_effect=%.12g se=%.12g\ncov_rf_fs=%.12g\n",
            n, rf$discontinuity, sqrt(rf$variance), fs$discontinuity,
            sqrt(fs$variance), ratio, se_ratio, cov_rf_fs))
