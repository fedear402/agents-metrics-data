#!/usr/bin/env Rscript
library(jsonlite)

crosswalk <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
trade <- read.csv("trade.csv", stringsAsFactors = FALSE)
areas <- read.csv("areas.csv", stringsAsFactors = FALSE)
employment <- read.csv("employment.csv", stringsAsFactors = FALSE)
outcomes <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

# Map each trade code to its industry.
trade <- merge(trade, crosswalk, by = "code", sort = FALSE)

make_exposure <- function(vintage, trade_value) {
  a <- areas[areas$vintage == vintage, c("area", "period", "total_employment")]
  e <- employment[employment$vintage == vintage, c("area", "period", "industry", "employment")]
  # Complete the area-industry grid so omitted employment cells are explicit zeros.
  grid <- merge(a[c("area", "period")], unique(crosswalk["industry"]), all = TRUE)
  e <- merge(grid, e, by = c("area", "period", "industry"), all.x = TRUE)
  e$employment[is.na(e$employment)] <- 0
  e <- merge(e, a, by = c("area", "period"), all.x = TRUE)
  e <- merge(e, national[national$vintage == vintage, c("period", "industry", "employment")],
             by = c("period", "industry"), all.x = TRUE, suffixes = c("_area", "_national"))
  t <- trade[c("period", "industry", trade_value, "price_index", "years")]
  e <- merge(e, t, by = c("period", "industry"), all.x = TRUE)
  e$contribution <- (e$employment_area / e$total_employment) *
    (e[[trade_value]] / e$employment_national) / (e$price_index / 100) / 1000 * (10 / e$years)
  agg <- aggregate(contribution ~ area + period, data = e, FUN = sum)
  names(agg)[3] <- if (vintage == "base") "x" else "z"
  agg
}

# Sum national employment within period, vintage, and industry.
national <- do.call(rbind, lapply(unique(areas$vintage), function(v) {
  av <- areas[areas$vintage == v, c("area", "period")]
  g <- merge(av, unique(crosswalk["industry"]), all = TRUE)
  ev <- employment[employment$vintage == v, c("area", "period", "industry", "employment")]
  g <- merge(g, ev, by = c("area", "period", "industry"), all.x = TRUE)
  g$employment[is.na(g$employment)] <- 0
  n <- aggregate(employment ~ period + industry, data = g, FUN = sum)
  n$vintage <- v
  n
}))

x <- make_exposure("base", "us_change")
z <- make_exposure("early", "other_change")
dat <- merge(outcomes, x, by = c("area", "period"), sort = FALSE)
dat <- merge(dat, z, by = c("area", "period"), sort = FALSE)
dat <- merge(dat, areas[areas$vintage == "base", c("area", "period", "population")],
             by = c("area", "period"), sort = FALSE)
dat$period_indicator <- dat$period

# Weighted 2SLS: project all regressors on all instruments, then regress y on projections.
C <- cbind(intercept = 1, period = dat$period_indicator, control = dat$control)
X <- cbind(C, x = dat$x)
Z <- cbind(C, z = dat$z)
sw <- sqrt(dat$population)
Zw <- Z * sw
Xw <- X * sw
Q <- qr(Zw)
Xhat <- qr.fitted(Q, Xw)
fit <- lm.wfit(x = Xhat, y = dat$change_pp * sw, w = rep(1, nrow(dat)))
beta <- fit$coefficients["x"]

area0 <- function(period, v) {
  v[v$area == 0 & v$period == period, if ("x" %in% names(v)) "x" else "z"]
}
estimates <- list(
  list(term = "iv_slope", estimate = unname(beta), se = NULL, n_obs = 72L),
  list(term = "exposure_area0_period0", estimate = unname(area0(0, x)), se = NULL, n_obs = 72L),
  list(term = "exposure_area0_period1", estimate = unname(area0(1, x)), se = NULL, n_obs = 72L),
  list(term = "instrument_area0_period0", estimate = unname(area0(0, z)), se = NULL, n_obs = 72L)
)
result <- list(task_id = "applied_multivintage_trade_iv", platform = "r",
               estimates = estimates,
               method_metadata = list(estimator = "weighted_2sls", outcome = "change_pp",
                                      regressors = c("intercept", "period", "control", "x"),
                                      instruments = c("intercept", "period", "control", "z"),
                                      weight = "base-vintage population",
                                      exposure_units = "thousands of real dollars per worker per decade"),
               diagnostics = list(n_obs = 72L, n_area_period_rows = nrow(dat),
                                  missing_area_industry_cells_zero = TRUE))
write_json(result, "result.json", auto_unbox = TRUE, digits = 16, null = "null", pretty = TRUE)

# Independent check: the coefficient from the weighted 2SLS normal-equation identity.
PZ <- Zw %*% solve(crossprod(Zw), t(Zw))
beta_identity <- solve(crossprod(Xw, PZ %*% Xw), crossprod(Xw, PZ %*% (dat$change_pp * sw)))[4, 1]
cat(sprintf("rows=%d beta=%.12f identity=%.12f diff=%.3g\n", nrow(dat), beta, beta_identity, beta-beta_identity))
cat(sprintf("x00=%.12f x01=%.12f z00=%.12f\n", area0(0,x), area0(1,x), area0(0,z)))
