dat <- read.csv("input.csv", stringsAsFactors = FALSE)
dat$date <- as.Date(dat$date)
dat <- dat[order(dat$date), ]
dv <- c(NA_real_, diff(log(dat$vix)))
ls <- log(dat$sales)
# At row t, regress y_t on dv_(t-1) through dv_(t-15).
idx <- 17:nrow(dat)
X <- cbind(`(Intercept)` = 1, do.call(cbind, lapply(1:15, function(k) dv[idx-k])))
colnames(X) <- c("(Intercept)", paste0("lag_", 1:15))
y <- ls[idx]
fit <- lm.fit(X, y)
b <- fit$coefficients
u <- as.vector(y - X %*% b)
N <- nrow(X)
# Newey-West meat: Bartlett weighted lagged score cross-products, j=0..15.
g <- X * u
S <- crossprod(g)
for (j in 1:15) {
  w <- 1 - j/16
  G <- crossprod(g[(j+1):N, , drop=FALSE], g[1:(N-j), , drop=FALSE])
  S <- S + w * (G + t(G))
}
 bread <- solve(crossprod(X))
V <- (N/(N-16)) * bread %*% S %*% bread
cum_w <- c(0, rep(1, 15))
terms <- list(
  list(term="cumulative_response", estimate=sum(b[2:16]), se=sqrt(drop(t(cum_w) %*% V %*% cum_w))),
  list(term="lag_1", estimate=b[2], se=sqrt(V[2,2])),
  list(term="lag_15", estimate=b[16], se=sqrt(V[16,16]))
)
ests <- lapply(terms, function(z) list(term=z$term, estimate=unname(z$estimate), se=unname(z$se), n_obs=as.integer(N)))
metadata <- list(estimator="OLS with intercept and 15 trading-observation lags of first differences in log(vix)", vcov="Newey-West HAC, Bartlett maxlag 15, finite-sample multiplier N/(N-16)")
result <- list(task_id="applied_cumulative_hac", platform="r", estimates=ests, method_metadata=metadata, diagnostics=list())
if (!requireNamespace("jsonlite", quietly=TRUE)) stop("jsonlite required")
jsonlite::write_json(result, "result.json", auto_unbox=TRUE, digits=15, pretty=TRUE, null="null")
# Emit internal values for verification.
cat("n_input", nrow(dat), "n_obs", N, "first_sample_date", format(dat$date[min(idx)]), "last_sample_date", format(dat$date[max(idx)]), "\n")
cat("coefficients", paste(sprintf("%.12g", b), collapse=" "), "\n")
cat("cumulative_se", sprintf("%.12g", ests[[1]]$se), "\n")
