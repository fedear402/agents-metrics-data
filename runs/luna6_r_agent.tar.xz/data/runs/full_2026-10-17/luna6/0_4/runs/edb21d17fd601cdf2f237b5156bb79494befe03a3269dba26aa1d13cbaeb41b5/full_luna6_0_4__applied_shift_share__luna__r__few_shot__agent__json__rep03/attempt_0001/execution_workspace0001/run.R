# Applied shift-share IV with shock-level HC1 uncertainty.
suppressPackageStartupMessages(library(jsonlite))
d <- read.csv("input.csv")
stopifnot(all(c("region_id", "industry_id", "share", "shock", "region_weight", "x", "y") %in% names(d)))
# Reduce repeated regional and industry values to one value per unit.
rids <- unique(d$region_id)
iids <- unique(d$industry_id)
regions <- data.frame(region_id = rids)
regions$region_weight <- vapply(rids, function(id) unique(d$region_weight[d$region_id == id])[1], numeric(1))
regions$x <- vapply(rids, function(id) unique(d$x[d$region_id == id])[1], numeric(1))
regions$y <- vapply(rids, function(id) unique(d$y[d$region_id == id])[1], numeric(1))
regions$e <- regions$region_weight / sum(regions$region_weight)
shocks <- data.frame(industry_id = iids)
shocks$shock <- vapply(iids, function(id) unique(d$shock[d$industry_id == id])[1], numeric(1))
# Ensure the repeated inputs and share normalization follow the task statement.
stopifnot(all(vapply(rids, function(id) length(unique(d$region_weight[d$region_id == id])) == 1L, logical(1))))
stopifnot(all(vapply(rids, function(id) length(unique(d$x[d$region_id == id])) == 1L && length(unique(d$y[d$region_id == id])) == 1L, logical(1))))
stopifnot(all(vapply(iids, function(id) length(unique(d$shock[d$industry_id == id])) == 1L, logical(1))))
share_sums <- tapply(d$share, d$region_id, sum)
stopifnot(max(abs(share_sums - 1)) < 1e-8)
# Build the region-by-industry share matrix, with explicit zero shares where absent.
S <- matrix(0, nrow = length(rids), ncol = length(iids), dimnames = list(as.character(rids), as.character(iids)))
S[cbind(match(d$region_id, rids), match(d$industry_id, iids))] <- d$share
stopifnot(nrow(S) == length(rids), ncol(S) == length(iids))
shock_vec <- shocks$shock
z <- drop(S %*% shock_vec)
# Weighted centering of each regional variable.
center <- function(v) v - sum(regions$e * v)
y0 <- center(regions$y)
x0 <- center(regions$x)
z0 <- center(z)
s <- drop(crossprod(regions$e, S))
stopifnot(all(s > 0), abs(sum(s) - 1) < 1e-10)
aggregate <- function(v0) drop(crossprod(S, regions$e * v0)) / s
ybar <- aggregate(y0)
xbar <- aggregate(x0)
zbar <- aggregate(z0)
N <- length(iids)
# Weighted IV with one excluded instrument and intercept; fit via exact 2SLS.
iv_hc1 <- function(y, x, z, w) {
  X <- cbind(1, x)
  Z <- cbind(1, z)
  sw <- sqrt(w)
  Xw <- X * sw
  Zw <- Z * sw
  yw <- y * sw
  # 2SLS coefficient from weighted projection on instruments.
  A <- crossprod(Xw, Zw) %*% solve(crossprod(Zw)) %*% crossprod(Zw, Xw)
  b <- solve(A, crossprod(Xw, Zw) %*% solve(crossprod(Zw)) %*% crossprod(Zw, yw))
  u <- drop(y - X %*% b)
  # HC0 sandwich for analytic-weighted IV, based on structural residuals.
  bread <- solve(crossprod(Xw, Zw) %*% solve(crossprod(Zw)) %*% crossprod(Zw, Xw))
  # Equivalent IV score uses fitted instrument projection of regressors.
  PZX <- Zw %*% solve(crossprod(Zw), crossprod(Zw, Xw))
  score <- PZX * (w * u)
  meat <- crossprod(score)
  V <- N / (N - 2) * bread %*% meat %*% bread
  list(coef = drop(b), se = sqrt(diag(V)), residual = u)
}
effect_fit <- iv_hc1(ybar, xbar, shock_vec, s)
relevance_fit <- iv_hc1(xbar, zbar, shock_vec, s)
# Regional weighted 2SLS and first stage provide slope identities.
regional_iv <- iv_hc1(regions$y, regions$x, z, regions$e)
regional_fs <- lm.wfit(cbind(1, z), regions$x, w = regions$e)$coefficients
stopifnot(abs(effect_fit$coef[2] - regional_iv$coef[2]) < 1e-8)
stopifnot(abs(relevance_fit$coef[2] - regional_fs[2]) < 1e-8)
result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = unname(effect_fit$coef[2]), se = unname(effect_fit$se[2]), n_obs = as.integer(N)),
    list(term = "first_stage", estimate = unname(relevance_fit$coef[2]), se = unname(relevance_fit$se[2]), n_obs = as.integer(N)),
    list(term = "effective_shocks", estimate = unname(1 / sum(s^2)), se = NULL, n_obs = as.integer(N))
  ),
  method_metadata = list(estimator = "weighted 2SLS; Borusyak-Hull-Jaravel shock-level aggregation", vcov = "shock-level analytic-weight HC1 sandwich; structural IV residuals; N/(N-2)"),
  diagnostics = list(n_regions = length(rids), n_industries = N, n_region_industry_rows = nrow(d), regional_weight_sum = sum(regions$e), max_region_share_sum_error = max(abs(share_sums - 1)), regional_effect_slope = unname(regional_iv$coef[2]), regional_first_stage_slope = unname(regional_fs[2]))
)
write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
