households <- read.csv("households.csv")
census <- read.csv("census.csv")
d <- households[households$recipient == 0, , drop = FALSE]
e0 <- 1 - d$eligible
e1 <- d$eligible
X <- cbind(e0, e1, d$baseline * e0, d$baseline * e1,
           d$dose * e0, d$dose * e1)
Z <- cbind(e0, e1, d$baseline * e0, d$baseline * e1,
           d$instrument * e0, d$instrument * e1)
W <- diag(d$weight)
# Independent direct 2SLS identity with the weighted projection in levels.
Pz <- Z %*% solve(crossprod(Z, W %*% Z), t(Z) %*% W)
beta_direct <- solve(crossprod(X, W %*% Pz %*% X),
                     crossprod(X, W %*% Pz %*% d$outcome))[, 1]
Xw <- X * sqrt(d$weight)
Zw <- Z * sqrt(d$weight)
Xhat <- qr.fitted(qr(Zw), Xw)
beta_script <- qr.coef(qr(Xhat), d$outcome * sqrt(d$weight))
stopifnot(max(abs(beta_direct - beta_script)) < 1e-10)
slopes <- beta_direct[5:6]
means <- vapply(0:1, function(g) weighted.mean(d$dose[d$eligible == g], d$weight[d$eligible == g]), numeric(1))
effects <- slopes * means
counts <- census$nonrecipient_population[match(0:1, census$eligible)]
population_identity <- sum(effects * counts) / sum(counts)
out <- jsonlite::fromJSON("result.json", simplifyVector = FALSE)
reported <- vapply(out$estimates, `[[`, numeric(1), "estimate")
stopifnot(nrow(d) == 300L, sum(d$eligible == 0) == 120L,
          sum(d$eligible == 1) == 180L,
          max(abs(c(effects, population_identity) - reported)) < 1e-10,
          all(vapply(out$estimates, function(z) z$n_obs == 300L, logical(1))))
cat(sprintf("Direct matrix 2SLS max coefficient difference: %.3g\n", max(abs(beta_direct - beta_script))))
cat(sprintf("Weighted group dose means: %.12g, %.12g\n", means[1], means[2]))
cat(sprintf("Effects from direct slopes and weighted means: %.12g, %.12g\n", effects[1], effects[2]))
cat(sprintf("Census weighted identity: %.12g\n", population_identity))
cat(sprintf("Reported population effect: %.12g\n", reported[3]))
cat(sprintf("Sample counts checked: total %d, ineligible %d, eligible %d\n", nrow(d), sum(d$eligible == 0), sum(d$eligible == 1)))
