d <- read.csv('input.csv')
s <- d$score
keep <- abs(s) < 1
x <- d[keep, ]
x$right <- as.numeric(x$score >= 0)
x$run <- x$score
x$right_run <- x$right * x$run
x$w <- 1 - abs(x$score)
stopifnot(all(x$w > 0), all(x$participated %in% c(0,1)))
fit_jump <- function(y) {
  m <- lm(y ~ right + run + right_run, data=x, weights=w)
  X <- model.matrix(m)
  u <- residuals(m)
  bread <- solve(crossprod(X, X * x$w))
  meat <- crossprod(X, X * (x$w^2 * u^2))
  V <- bread %*% meat %*% bread
  c(est=unname(coef(m)['right']), var=V['right','right'])
}
a <- fit_jump(x$earnings)
b <- fit_jump(x$participated)
rf <- a['est']; fs <- b['est']
tau <- rf/fs
# Joint HC0 covariance, stacked estimating equations for same design and weights.
# Cross-equation meat uses weighted residual products.
mY <- lm(earnings ~ right + run + right_run, data=x, weights=w)
mD <- lm(participated ~ right + run + right_run, data=x, weights=w)
X <- model.matrix(mY); W <- x$w
bread <- solve(crossprod(X, X * W))
U <- cbind(residuals(mY), residuals(mD))
S <- crossprod(X, X * (W^2 * U[,1] * U[,2]))
cov_rf_fs <- (bread %*% S %*% bread)['right','right']
Vrf <- a['var']; Vfs <- b['var']
se_tau <- sqrt(Vrf/fs^2 + rf^2*Vfs/fs^4 - 2*rf*cov_rf_fs/fs^3)
n <- nrow(x)
fmt <- function(z) if (is.finite(z)) sprintf('%.12g', z) else 'null'
json <- sprintf('{\n  "task_id": "applied_fuzzy_rd",\n  "platform": "r",\n  "estimates": [\n    {"term": "treatment_effect", "estimate": %s, "se": %s, "n_obs": %d},\n    {"term": "reduced_form", "estimate": %s, "se": %s, "n_obs": %d},\n    {"term": "first_stage", "estimate": %s, "se": %s, "n_obs": %d}\n  ],\n  "method_metadata": {"estimator": "weighted local-linear fuzzy regression discontinuity; triangular kernel; bandwidth 1", "vcov": "HC0 sandwich; joint outcome-treatment covariance; delta method; fixed bandwidth and weights"},\n  "diagnostics": {}\n}\n', fmt(tau),fmt(se_tau),n,fmt(rf),fmt(sqrt(Vrf)),n,fmt(fs),fmt(sqrt(Vfs)),n)
writeLines(json, 'result.json')
cat(sprintf('n=%d rf=%.12g se_rf=%.12g fs=%.12g se_fs=%.12g cov=%.12g tau=%.12g se_tau=%.12g\n', n,rf,sqrt(Vrf),fs,sqrt(Vfs),cov_rf_fs,tau,se_tau))
