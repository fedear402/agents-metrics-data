library(jsonlite)
dat <- read.csv("./input.csv")
fit <- aov(y ~ factor(group), data = dat)
tab <- summary(fit)[[1]]
F_stat <- unname(tab[1, "F value"])
df_num <- unname(tab[1, "Df"])
df_den <- unname(tab[2, "Df"])
p_value <- unname(tab[1, "Pr(>F)"])
n <- nrow(dat)
out <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = list(
    list(term = "F", estimate = F_stat, se = NA_real_, n_obs = n),
    list(term = "df_num", estimate = df_num, se = NA_real_, n_obs = n),
    list(term = "df_den", estimate = df_den, se = NA_real_, n_obs = n),
    list(term = "p_value", estimate = p_value, se = NA_real_, n_obs = n)
  ),
  method_metadata = list(estimator = "One-way ANOVA", vcov = "Classical homoskedastic ANOVA"),
  diagnostics = list()
)
write_json(out, "result.json", auto_unbox = TRUE, digits = 15, na = "null")
