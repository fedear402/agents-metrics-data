task_id <- "applied_nonrecipient_population_iv"

households <- read.csv("households.csv", stringsAsFactors = FALSE)
census <- read.csv("census.csv", stringsAsFactors = FALSE)

# Keep all nonrecipient households, including both village treatment statuses.
d <- households[households$recipient == 0, , drop = FALSE]
n_obs <- nrow(d)
stopifnot(n_obs == 300L, all(d$weight > 0),
          identical(sort(unique(d$eligible)), c(0L, 1L)))

g0 <- 1 - d$eligible
g1 <- d$eligible
X <- cbind(g0, g1, d$baseline * g0, d$baseline * g1,
           d$dose * g0, d$dose * g1)
Z <- cbind(g0, g1, d$baseline * g0, d$baseline * g1,
           d$instrument * g0, d$instrument * g1)
y <- d$outcome
w <- d$weight

# Weighted 2SLS: beta = (X'W Pz X)^(-1) X'W Pz y.
sqrt_w <- sqrt(w)
Xw <- X * sqrt_w
Zw <- Z * sqrt_w
yw <- y * sqrt_w
qz <- qr(Zw)
Xhat <- qr.fitted(qz, Xw)
yhat <- qr.fitted(qz, yw)
beta <- as.numeric(qr.coef(qr(Xhat), yw))
stopifnot(length(beta) == ncol(X), all(is.finite(beta)))

mean_dose <- vapply(0:1, function(g) {
  a <- d$eligible == g
  weighted.mean(d$dose[a], w[a])
}, numeric(1))
effects <- beta[5:6] * mean_dose
names(effects) <- c("ineligible_effect", "eligible_nonrecipient_effect")

counts <- census$nonrecipient_population[match(0:1, census$eligible)]
stopifnot(length(counts) == 2L, all(is.finite(counts)), all(counts >= 0))
population_effect <- weighted.mean(effects, counts)
estimates <- c(effects, population_effect = population_effect)

# Independent numerical check: weighted IV normal equations, using cross-products.
lhs_check <- crossprod(Xw, Xhat)
rhs_check <- as.numeric(crossprod(Xw, yhat))
beta_check <- as.numeric(solve(lhs_check, rhs_check))
check_error <- max(abs(beta - beta_check))
stopifnot(check_error < 1e-9)

# Verify the aggregation identity against a direct census-weighted sum.
aggregate_check <- sum(effects * counts) / sum(counts)
stopifnot(abs(population_effect - aggregate_check) < 1e-12)

estimate_rows <- lapply(names(estimates), function(term) {
  list(term = term, estimate = unname(estimates[[term]]), se = NULL,
       n_obs = as.integer(n_obs))
})
result <- list(
  task_id = task_id,
  platform = "r",
  estimates = estimate_rows,
  method_metadata = list(
    estimator = "Weighted 2SLS",
    sample = "All households with recipient = 0",
    endogenous_columns = c("dose*(1-eligible)", "dose*eligible"),
    exogenous_columns = c("1-eligible", "eligible", "baseline*(1-eligible)",
                          "baseline*eligible"),
    instruments = c("1-eligible", "eligible", "baseline*(1-eligible)",
                    "baseline*eligible", "instrument*(1-eligible)",
                    "instrument*eligible"),
    regression_weight = "weight",
    group_effect = "Fitted group dose slope times weighted mean dose among retained group observations",
    final_group_weights = "census.csv nonrecipient_population",
    counterfactual = "Dose is zero for every retained household; attribution is a stated synthetic convention",
    uncertainty = "se set to null as specified"
  ),
  diagnostics = list(
    n_obs = as.integer(n_obs),
    retained_rows_by_eligible = as.list(setNames(as.integer(table(factor(d$eligible, levels = 0:1))),
                                                 c("0", "1"))),
    retained_treated_values = sort(unique(d$treated)),
    retained_recipient_values = sort(unique(d$recipient)),
    group_weighted_mean_dose = as.list(setNames(as.numeric(mean_dose), c("0", "1"))),
    fitted_dose_slopes = as.list(setNames(as.numeric(beta[5:6]), c("0", "1"))),
    census_counts = as.list(setNames(as.integer(counts), c("0", "1"))),
    crossproduct_check_max_abs_error = check_error,
    census_aggregation_check_abs_error = abs(population_effect - aggregate_check)
  )
)
jsonlite::write_json(result, "result.json", auto_unbox = TRUE,
                     digits = 16, pretty = TRUE, null = "null")

writeLines(c(
  "Verification of applied_nonrecipient_population_iv",
  sprintf("Sample check: retained %d of %d rows with recipient = 0.", n_obs, nrow(households)),
  sprintf("Eligibility counts among retained rows: %d ineligible, %d eligible.",
          sum(d$eligible == 0), sum(d$eligible == 1)),
  "Specification check: one weighted 2SLS regression; two group-specific endogenous dose columns; four group-specific exogenous columns; six instruments; no extra intercept.",
  sprintf("Independent calculation: weighted IV cross-product normal equations matched the QR 2SLS coefficients; maximum absolute coefficient difference %.3g.", check_error),
  sprintf("Aggregation identity: direct census-weighted sum matched population_effect; absolute difference %.3g.", abs(population_effect - aggregate_check)),
  "Dose construction check: each reported group effect equals its fitted dose slope times that group’s weighted mean dose among retained observations.",
  "Counterfactual attribution uses the stated synthetic convention that dose is zero for every retained household."
), "verification.txt")

cat(jsonlite::toJSON(as.list(estimates), auto_unbox = TRUE, digits = 16), "\n")
