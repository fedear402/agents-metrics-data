suppressPackageStartupMessages(library(jsonlite))

crosswalk <- read.csv('crosswalk.csv', stringsAsFactors = FALSE)
trade <- read.csv('trade.csv', stringsAsFactors = FALSE)
areas <- read.csv('areas.csv', stringsAsFactors = FALSE)
employment <- read.csv('employment.csv', stringsAsFactors = FALSE)
outcomes <- read.csv('outcomes.csv', stringsAsFactors = FALSE)

stopifnot(nrow(crosswalk) == 8L, !anyDuplicated(crosswalk$code),
          !anyDuplicated(trade[c('period', 'code')]),
          !anyDuplicated(areas[c('area', 'period', 'vintage')]),
          !anyDuplicated(employment[c('area', 'period', 'vintage', 'industry')]),
          !anyDuplicated(outcomes[c('area', 'period')]))
trade <- merge(trade, crosswalk, by = 'code', all.x = TRUE, sort = FALSE)
stopifnot(!anyNA(trade$industry), all(areas$vintage %in% c('base', 'early')))

# National denominators use every supplied area, within period and vintage.
national <- aggregate(employment$employment, by = list(period = employment$period,
                                                       vintage = employment$vintage,
                                                       industry = employment$industry),
                      FUN = sum)
names(national)[names(national) == 'x'] <- 'national_employment'

# Expand all area-period-vintage/industry cells. Omitted employment cells are zero.
cell_grid <- merge(areas[c('area', 'period', 'vintage', 'total_employment')],
                   data.frame(industry = sort(unique(crosswalk$industry))),
                   by = NULL)
cells <- merge(cell_grid, employment,
               by = c('area', 'period', 'vintage', 'industry'), all.x = TRUE,
               sort = FALSE)
cells$employment[is.na(cells$employment)] <- 0
cells <- merge(cells, national,
               by = c('period', 'vintage', 'industry'), all.x = TRUE, sort = FALSE)
stopifnot(!anyNA(cells$national_employment), all(cells$national_employment > 0))
cells <- merge(cells, trade, by = c('period', 'industry'), all.x = TRUE, sort = FALSE)
stopifnot(!anyNA(cells$us_change), !anyNA(cells$other_change))
cells$x_part <- (cells$employment / cells$total_employment) *
  (cells$us_change / cells$national_employment) /
  (cells$price_index / 100) / 1000 * (10 / cells$years)
cells$z_part <- (cells$employment / cells$total_employment) *
  (cells$other_change / cells$national_employment) /
  (cells$price_index / 100) / 1000 * (10 / cells$years)
exposure <- aggregate(cbind(x_part, z_part) ~ area + period + vintage, cells, sum)
base_exp <- exposure[exposure$vintage == 'base', c('area', 'period', 'x_part')]
early_exp <- exposure[exposure$vintage == 'early', c('area', 'period', 'z_part')]
names(base_exp)[3] <- 'x'
names(early_exp)[3] <- 'z'
wide <- merge(base_exp, early_exp, by = c('area', 'period'), all = TRUE, sort = FALSE)

est <- merge(areas[areas$vintage == 'base', c('area', 'period', 'population')],
             outcomes, by = c('area', 'period'), all = FALSE, sort = FALSE)
est <- merge(est, wide[c('area', 'period', 'x', 'z')], by = c('area', 'period'),
              all = FALSE, sort = FALSE)
est <- merge(est, unique(areas[c('area', 'period')]), by = c('area', 'period'),
              all = FALSE, sort = FALSE)
stopifnot(nrow(est) == 72L, !anyNA(est), all(est$population > 0))
est$period1 <- as.numeric(est$period == 1)

# Weighted 2SLS via weighted Frisch-Waugh-Lovell residualization.
w <- est$population
C <- cbind(intercept = 1, period = est$period1, control = est$control)
X <- cbind(C, x = est$x)
Z <- cbind(C, z = est$z)
sw <- sqrt(w)
Xw <- X * sw
Zw <- Z * sw
yw <- est$change_pp * sw
projZ <- qr(Zw)
Xhat <- qr.fitted(projZ, Xw)
beta <- qr.coef(qr(Xhat), yw)

# Independent numerical identity: weighted residualize x and y on exogenous C,
# then calculate the just-identified IV ratio using residualized z.
resid_w <- function(v, C, sw) qr.resid(qr(C * sw), v * sw)
xr <- resid_w(est$x, C, sw)
yr <- resid_w(est$change_pp, C, sw)
zr <- resid_w(est$z, C, sw)
independent_iv <- sum(zr * yr) / sum(zr * xr)
stopifnot(isTRUE(all.equal(unname(beta['x']), independent_iv, tolerance = 1e-10)))

get_one <- function(var, area, period) {
  v <- wide[wide$area == area & wide$period == period, var]
  stopifnot(length(v) == 1L)
  unname(v)
}
ests <- list(
  list(term = 'iv_slope', estimate = unname(beta['x']), se = NULL, n_obs = 72L),
  list(term = 'exposure_area0_period0', estimate = get_one('x', 0, 0), se = NULL, n_obs = 72L),
  list(term = 'exposure_area0_period1', estimate = get_one('x', 0, 1), se = NULL, n_obs = 72L),
  list(term = 'instrument_area0_period0', estimate = get_one('z', 0, 0), se = NULL, n_obs = 72L)
)
result <- list(task_id = 'applied_multivintage_trade_iv', platform = 'r',
               estimates = ests,
               method_metadata = list(estimator = 'weighted 2SLS',
                 outcome = 'change_pp', regressors = c('intercept', 'period', 'control', 'x'),
                 instruments = c('intercept', 'period', 'control', 'z'),
                 weight = 'base-vintage population',
                 exposure_units = 'thousands of real dollars per worker per decade'),
               diagnostics = list(n_obs = 72L, n_areas = 36L, n_periods = 2L,
                 n_industries = 4L, independent_iv_slope = independent_iv,
                 iv_identity_difference = unname(beta['x']) - independent_iv))
write_json(result, 'result.json', auto_unbox = TRUE, digits = 15, pretty = TRUE, null = 'null')
