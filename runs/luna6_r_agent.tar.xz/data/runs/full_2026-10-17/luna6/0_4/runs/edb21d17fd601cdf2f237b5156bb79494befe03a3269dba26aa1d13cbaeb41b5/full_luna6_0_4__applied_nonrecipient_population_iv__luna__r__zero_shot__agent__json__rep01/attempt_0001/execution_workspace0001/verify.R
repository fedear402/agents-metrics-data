h <- read.csv("households.csv")
c <- read.csv("census.csv")
d <- subset(h, recipient == 0)
n <- nrow(d)
stopifnot(n == 300L, sum(d$treated == 1) == 60L,
          sum(d$treated == 0) == 240L,
          sum(d$eligible == 0) == 120L,
          sum(d$eligible == 1) == 180L)

# Independent weighted 2SLS calculation via the W-orthogonalized instrument
# basis and the closed-form moment matrix.
e0 <- 1 - d$eligible
e1 <- d$eligible
X <- cbind(e0, e1, d$baseline * e0, d$baseline * e1)
Z <- cbind(X, d$instrument * e0, d$instrument * e1)
D <- cbind(d$dose * e0, d$dose * e1)
W <- diag(d$weight)
G <- crossprod(Z, W %*% Z)
Q <- crossprod(Z, W %*% D)
r <- crossprod(Z, W %*% d$outcome)
beta_alt <- solve(crossprod(D, W %*% Z) %*% solve(G, Q),
                  crossprod(D, W %*% Z) %*% solve(G, r))

# This separate identity checks the census aggregation independently.
res <- jsonlite::fromJSON("result.json", simplifyVector = FALSE)
effects <- setNames(vapply(res$estimates, `[[`, numeric(1), "estimate"),
                    vapply(res$estimates, `[[`, character(1), "term"))
mm0 <- weighted.mean(d$dose[d$eligible == 0], d$weight[d$eligible == 0])
mm1 <- weighted.mean(d$dose[d$eligible == 1], d$weight[d$eligible == 1])
e0_calc <- beta_alt[1] * mm0
e1_calc <- beta_alt[2] * mm1
p0 <- c$nonrecipient_population[match(0, c$eligible)]
p1 <- c$nonrecipient_population[match(1, c$eligible)]
pop_identity <- (p0 / (p0 + p1)) * e0_calc + (p1 / (p0 + p1)) * e1_calc
stopifnot(max(abs(as.numeric(beta_alt) - c(2.0718668456717992, 4.5902008904871261))) < 1e-10,
          abs(e0_calc - effects[["ineligible_effect"]]) < 1e-10,
          abs(e1_calc - effects[["eligible_nonrecipient_effect"]]) < 1e-10,
          abs(pop_identity - effects[["population_effect"]]) < 1e-10,
          all(vapply(res$estimates, function(x) x$n_obs == n, logical(1))))
cat(sprintf("n_obs=%d; ineligible=%d; eligible=%d; treated-village nonrecipients=%d; untreated-village nonrecipients=%d\n", n, sum(d$eligible == 0), sum(d$eligible == 1), sum(d$treated == 1), sum(d$treated == 0)))
cat(sprintf("independent slopes: %.12f, %.12f\n", beta_alt[1], beta_alt[2]))
cat(sprintf("independent effects: %.12f, %.12f\n", e0_calc, e1_calc))
cat(sprintf("census identity population effect: %.12f\n", pop_identity))
cat("All sample, matrix, weighted-mean, aggregation, and n_obs checks passed.\n")
