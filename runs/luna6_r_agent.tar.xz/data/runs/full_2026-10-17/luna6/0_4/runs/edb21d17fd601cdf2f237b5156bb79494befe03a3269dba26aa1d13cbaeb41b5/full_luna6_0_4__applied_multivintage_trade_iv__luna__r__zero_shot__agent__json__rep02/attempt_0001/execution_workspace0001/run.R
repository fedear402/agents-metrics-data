suppressPackageStartupMessages(library(jsonlite))

crosswalk <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
trade <- read.csv("trade.csv", stringsAsFactors = FALSE)
areas <- read.csv("areas.csv", stringsAsFactors = FALSE)
employment <- read.csv("employment.csv", stringsAsFactors = FALSE)
outcomes <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

stopifnot(nrow(crosswalk) == 8L, length(unique(crosswalk$industry)) == 4L, !anyDuplicated(crosswalk$code))
trade <- merge(trade, crosswalk, by = "code", all = FALSE, sort = FALSE)
stopifnot(nrow(trade) == 8L, !anyDuplicated(trade[c("period", "industry")]))

# Expand employment onto every area-period-vintage-industry cell. Omitted
# cells are zero by definition.
grid <- merge(areas, data.frame(industry = sort(unique(crosswalk$industry))))
emp <- merge(grid, employment, by = c("area", "period", "vintage", "industry"), all.x = TRUE)
emp$employment[is.na(emp$employment)] <- 0
stopifnot(nrow(emp) == nrow(areas) * 4L)

national <- aggregate(employment ~ period + vintage + industry, emp, sum)
base_area <- emp[emp$vintage == "base", c("area", "period", "industry", "employment")]
early_area <- emp[emp$vintage == "early", c("area", "period", "industry", "employment")]
names(base_area)[4] <- "base_employment"
names(early_area)[4] <- "early_employment"
denom <- areas[, c("area", "period", "vintage", "total_employment", "population")]
base_total <- denom[denom$vintage == "base", c("area", "period", "total_employment", "population")]
names(base_total)[3] <- "base_total_employment"
early_total <- denom[denom$vintage == "early", c("area", "period", "total_employment")]
names(early_total)[3] <- "early_total_employment"

calc_exposure <- function(area_emp, area_total_name, trade_value, output_name) {
  names(area_emp)[4] <- "area_industry_employment"
  d <- merge(area_emp, national[national$vintage == if (output_name == "x") "base" else "early", ],
             by = c("period", "industry"), all.x = TRUE)
  names(d)[names(d) == "employment"] <- "national_industry_employment"
  d <- merge(d, trade_value, by = c("period", "industry"), all.x = TRUE)
  d <- merge(d, area_total_name, by = c("area", "period"), all.x = TRUE)
  d$component <- (d$area_industry_employment / d[[if (output_name == "x") "base_total_employment" else "early_total_employment"]]) *
    (d$trade_change / d$national_industry_employment) / (d$price_index / 100) / 1000 * (10 / d$years)
  out <- aggregate(component ~ area + period, d, sum)
  names(out)[3] <- output_name
  out
}

tx <- trade[, c("period", "industry", "us_change", "price_index", "years")]
names(tx)[3] <- "trade_change"
tz <- trade[, c("period", "industry", "other_change", "price_index", "years")]
names(tz)[3] <- "trade_change"
x <- calc_exposure(base_area, base_total, tx, "x")
z <- calc_exposure(early_area, early_total, tz, "z")
dat <- Reduce(function(a, b) merge(a, b, by = c("area", "period"), all = TRUE), list(x, z, outcomes, base_total))
dat$period <- as.numeric(dat$period)
dat <- dat[complete.cases(dat[, c("change_pp", "period", "control", "x", "z", "population")]), ]
stopifnot(nrow(dat) == 72L, length(unique(dat$area)) == 36L,
          all(table(dat$area) == 2L), all(dat$population > 0))

# Weighted 2SLS: solve the weighted projection using the full instrument
# matrix [intercept, period, control, z].
Y <- as.matrix(dat$change_pp)
X <- model.matrix(~ period + control + x, data = dat)
Z <- model.matrix(~ period + control + z, data = dat)
W <- diag(dat$population)
solve_wls <- function(A, b, weights) solve(crossprod(A, weights * A), crossprod(A, weights * b))
PzX <- Z %*% solve_wls(Z, X, dat$population)
beta <- solve(crossprod(X, dat$population * PzX), crossprod(PzX, dat$population * Y))
iv_slope <- unname(beta["x", 1])

estimates <- list(
  list(term = "iv_slope", estimate = iv_slope, se = NULL, n_obs = 72L),
  list(term = "exposure_area0_period0", estimate = x$x[x$area == 0 & x$period == 0], se = NULL, n_obs = 72L),
  list(term = "exposure_area0_period1", estimate = x$x[x$area == 0 & x$period == 1], se = NULL, n_obs = 72L),
  list(term = "instrument_area0_period0", estimate = z$z[z$area == 0 & z$period == 0], se = NULL, n_obs = 72L)
)
result <- list(task_id = "applied_multivintage_trade_iv", platform = "r", estimates = estimates,
               method_metadata = list(estimator = "population-weighted 2SLS", outcome = "change_pp",
                                      endogenous_regressor = "x", excluded_instrument = "z",
                                      exogenous_regressors = c("intercept", "period", "control"),
                                      instruments = c("intercept", "period", "control", "z"),
                                      weight = "base-vintage population", n_obs = 72L),
               diagnostics = list(sample_rows = nrow(dat), areas = length(unique(dat$area)),
                                  periods = length(unique(dat$period)), excluded_instrument_count = 1L,
                                  missing_employment_cells_set_to_zero = TRUE))
write_json(result, "result.json", auto_unbox = TRUE, pretty = TRUE, digits = 17, null = "null")

cat(sprintf("n=%d\niv_slope=%.17g\nx_area0_p0=%.17g\nx_area0_p1=%.17g\nz_area0_p0=%.17g\n",
            nrow(dat), iv_slope, estimates[[2]]$estimate, estimates[[3]]$estimate, estimates[[4]]$estimate))
