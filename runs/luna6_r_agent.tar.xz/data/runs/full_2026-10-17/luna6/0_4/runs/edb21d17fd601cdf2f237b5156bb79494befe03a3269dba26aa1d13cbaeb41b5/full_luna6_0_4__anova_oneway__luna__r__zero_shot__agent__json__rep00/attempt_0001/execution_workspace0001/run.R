#!/usr/bin/env Rscript

input_path <- "./input.csv"
output_path <- "./result.json"

dat <- read.csv(input_path, stringsAsFactors = FALSE)
if (!all(c("group", "y") %in% names(dat))) stop("input.csv must contain group and y")
dat <- dat[complete.cases(dat[, c("group", "y")]), c("group", "y")]
dat$group <- factor(dat$group)
if (nlevels(dat$group) < 2L) stop("At least two observed groups are required")

n_obs <- nrow(dat)
k <- nlevels(dat$group)
fit <- aov(y ~ group, data = dat)
tab <- summary(fit)[[1L]]
f_stat <- unname(tab["group", "F value"])
df_num <- unname(tab["group", "Df"])
df_den <- unname(tab["Residuals", "Df"])
p_value <- unname(tab["group", "Pr(>F)"])

estimates <- list(
  list(term = "F", estimate = f_stat, se = NULL, n_obs = n_obs),
  list(term = "df_num", estimate = df_num, se = NULL, n_obs = n_obs),
  list(term = "df_den", estimate = df_den, se = NULL, n_obs = n_obs),
  list(term = "p_value", estimate = p_value, se = NULL, n_obs = n_obs)
)
result <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = estimates,
  method_metadata = list(estimator = "one-way ANOVA (ordinary least squares)", vcov = "classical ANOVA pooled within-group variance"),
  diagnostics = list(n_obs = n_obs, n_groups = k)
)
if (!requireNamespace("jsonlite", quietly = TRUE)) stop("Package jsonlite is required")
jsonlite::write_json(result, output_path, auto_unbox = TRUE, pretty = TRUE, null = "null", digits = 17)
