#!/usr/bin/env Rscript
suppressPackageStartupMessages(library(jsonlite))
d <- read.csv("input.csv")
keep <- abs(d$score) < 1
d <- d[keep, ]
x <- d$score
w <- 1 - abs(x)
right <- as.numeric(x >= 0)
# Separate local-linear regressions: intercept and score terms on each side.
X <- cbind(left_intercept = 1-right,
           left_slope = x*(1-right),
           right_intercept = right,
           right_slope = x*right)
Y <- cbind(earnings = d$earnings, participated = d$participated)
W <- diag(w)
 bread <- solve(crossprod(X, W %*% X))
B <- bread %*% crossprod(X, W %*% Y)
res <- Y - X %*% B
# HC0 sandwich for weighted least squares, treating weights as fixed.
meat <- crossprod(X, (w^2) * res[,1]^2 * X) # initialized for dimensions
Vbeta <- array(0, c(ncol(X), ncol(X), ncol(Y)))
for (j in seq_len(ncol(Y))) {
  Vbeta[,,j] <- bread %*% crossprod(X, (w^2 * res[,j]^2) * X) %*% bread
}
# Joint covariance of coefficient vectors, including cross-outcome covariance.
Vjoint <- matrix(0, 2*ncol(X), 2*ncol(X))
for (j in 1:2) for (k in 1:2) {
  Vjoint[((j-1)*4+1):(j*4), ((k-1)*4+1):(k*4)] <-
    bread %*% crossprod(X, (w^2 * res[,j] * res[,k]) * X) %*% bread
}
# Discontinuity is right intercept minus left intercept.
a <- c(-1,0,1,0)
disc <- as.numeric(t(a) %*% B)
C <- rbind(c(a, rep(0,4)), c(rep(0,4), a))
Vdisc <- C %*% Vjoint %*% t(C)
rf <- disc[1]
fs <- disc[2]
te <- rf/fs
grad <- c(1/fs, -rf/fs^2)
se_te <- sqrt(as.numeric(t(grad) %*% Vdisc %*% grad))
N <- nrow(d)
ests <- list(
 list(term="treatment_effect", estimate=te, se=se_te, n_obs=N),
 list(term="reduced_form", estimate=rf, se=sqrt(Vdisc[1,1]), n_obs=N),
 list(term="first_stage", estimate=fs, se=sqrt(Vdisc[2,2]), n_obs=N)
)
out <- list(task_id="applied_fuzzy_rd", platform="r", estimates=ests,
 method_metadata=list(estimator="Fuzzy RD; separate weighted local-linear regressions with triangular weights, bandwidth 1", vcov="HC0 sandwich for weighted least squares; joint outcome covariance; delta method"), diagnostics=as.list(setNames(list(), character())))
write_json(out, "result.json", auto_unbox=TRUE, digits=16, pretty=TRUE, na="null", null="null")
# Independent check: direct weighted lm fits for each outcome, plus direct joint HC0 covariance identity.
fit_y <- lm(earnings ~ x * right, data=d, weights=w)
fit_d <- lm(participated ~ x * right, data=d, weights=w)
# These parameterizations imply jump = right main effect; compare numerical estimates.
co_y <- coef(fit_y)["right"]
co_d <- coef(fit_d)["right"]
if (abs(co_y-rf)>1e-9 || abs(co_d-fs)>1e-9) stop("Independent lm check failed")
# Identity check for delta-method variance, expanded using the cross-outcome covariance.
se2_expanded <- (Vdisc[1,1]/fs^2) + (rf^2 * Vdisc[2,2]/fs^4) - (2*rf*Vdisc[1,2]/fs^3)
if (abs(se2_expanded - se_te^2) > 1e-12) stop("Delta variance identity check failed")
cat(sprintf("N=%d\nRF=%.12g FS=%.12g TE=%.12g\nRF_lm=%.12g FS_lm=%.12g\nSE_TE=%.12g expanded_SE_TE=%.12g\n",N,rf,fs,te,co_y,co_d,se_te,sqrt(se2_expanded)))
