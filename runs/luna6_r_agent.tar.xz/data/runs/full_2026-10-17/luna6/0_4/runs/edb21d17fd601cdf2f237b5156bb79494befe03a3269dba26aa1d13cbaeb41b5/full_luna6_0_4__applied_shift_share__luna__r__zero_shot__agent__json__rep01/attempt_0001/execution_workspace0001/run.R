options(digits = 17)
d <- read.csv('input.csv', stringsAsFactors = FALSE)
req <- c('region_id','industry_id','share','shock','region_weight','x','y')
stopifnot(all(req %in% names(d)), nrow(d) > 0, all(is.finite(as.matrix(d[, c('share','shock','region_weight','x','y')]))))
# Validate unique region-industry rows and region-level repeated values.
stopifnot(!anyDuplicated(d[c('region_id','industry_id')]))
byr <- split(d, d$region_id)
stopifnot(all(vapply(byr, function(a) length(unique(a$region_weight)) == 1L && length(unique(a$x)) == 1L && length(unique(a$y)) == 1L, logical(1))))
share_sums <- vapply(byr, function(a) sum(a$share), numeric(1))
stopifnot(max(abs(share_sums - 1)) < 1e-8)
# One observation per region for normalization.
r <- do.call(rbind, lapply(byr, function(a) a[1L, c('region_id','region_weight','x','y')]))
r <- r[order(r$region_id), ]
rownames(r) <- NULL
e <- r$region_weight / sum(r$region_weight)
# Construct the instrument using all industries, then center regional variables.
industries <- sort(unique(d$industry_id))
shocks <- vapply(industries, function(n) {
  q <- unique(d$shock[d$industry_id == n]); stopifnot(length(q) == 1L); q
}, numeric(1))
shares <- matrix(0, nrow(r), length(industries), dimnames=list(as.character(r$region_id), as.character(industries)))
ri <- match(d$region_id, r$region_id); ni <- match(d$industry_id, industries)
shares[cbind(ri, ni)] <- d$share
z <- as.vector(shares %*% shocks)
vars <- cbind(y=r$y, x=r$x, z=z)
means <- colSums(vars * e)
v0 <- sweep(vars, 2, means, '-')
s <- colSums(shares * e)
stopifnot(all(s > 0), abs(sum(s)-1) < 1e-8)
agg <- sweep(crossprod(shares, v0 * e), 1, s, '/')
colnames(agg) <- c('ybar','xbar','zbar')
# Analytic-weighted IV with intercept, structural residuals, HC1 correction N/(N-2).
shock_iv <- function(y, x, q, w) {
  # 2SLS: regress endogenous x on intercept and q, then weighted structural regression.
  X <- cbind(1, x); Z <- cbind(1, q)
  WZ <- Z * w
  A <- crossprod(X, WZ %*% solve(crossprod(Z, WZ), crossprod(Z, w * X)))
  b <- solve(A, crossprod(X, WZ %*% solve(crossprod(Z, WZ), crossprod(Z, w * y))))
  u <- as.vector(y - X %*% b)
  # HC0 sandwich for the IV estimating equations, with analytic weights.
  B <- solve(crossprod(Z, w * X))
  meat <- crossprod(Z * (w * u))
  V0 <- B %*% meat %*% t(B)
  N <- length(y)
  V <- V0 * N/(N-2)
  list(coef=as.vector(b), se=sqrt(diag(V)), residual=u)
}
# The shock-level IV slope is the regional weighted 2SLS slope.
eff <- shock_iv(agg[,'ybar'], agg[,'xbar'], shocks, s)
fs <- shock_iv(agg[,'xbar'], agg[,'zbar'], shocks, s)
# Regional point estimates provide an independent identity check.
regional_iv <- function(y, x, z, w) {
  X <- cbind(1,x); Z <- cbind(1,z)
  PZX <- Z %*% solve(crossprod(Z, w * Z), crossprod(Z, w * X))
  PZy <- Z %*% solve(crossprod(Z, w * Z), crossprod(Z, w * y))
  solve(crossprod(X, w * PZX), crossprod(X, w * PZy))
}
reg_eff <- regional_iv(r$y, r$x, z, e)
reg_fs <- regional_iv(r$x, z, z, e)
stopifnot(abs(eff$coef[2] - reg_eff[2]) < 1e-8, abs(fs$coef[2] - reg_fs[2]) < 1e-8)
N <- length(industries)
results <- list(
  list(term='effect', estimate=unname(eff$coef[2]), se=unname(eff$se[2]), n_obs=as.integer(N)),
  list(term='first_stage', estimate=unname(reg_fs[2]), se=unname(fs$se[2]), n_obs=as.integer(N)),
  list(term='effective_shocks', estimate=unname(1/sum(s^2)), se=NULL, n_obs=as.integer(N))
)
# jsonlite is a common R package. Keep numeric precision in output.
if (!requireNamespace('jsonlite', quietly=TRUE)) stop('jsonlite package is required')
out <- list(task_id='applied_shift_share', platform='r', estimates=results,
  method_metadata=list(estimator='Weighted regional 2SLS with Borusyak-Hull-Jaravel shock-level IV aggregation', vcov='Industry-level heteroskedasticity-robust HC1 sandwich using structural IV residuals and analytic weights; multiplier N/(N-2); no clustering'),
  diagnostics=list(n_regions=as.integer(nrow(r)), n_industries=as.integer(N), n_region_industry_rows=as.integer(nrow(d)), max_abs_share_sum_error=unname(max(abs(share_sums-1))), regional_effect_slope=unname(reg_eff[2]), shock_level_effect_slope=unname(eff$coef[2]), regional_first_stage_slope=unname(reg_fs[2]), shock_level_first_stage_slope=unname(fs$coef[2]), weight_sum=unname(sum(e)), industry_weight_sum=unname(sum(s))))
writeLines(jsonlite::toJSON(out, auto_unbox=TRUE, pretty=TRUE, digits=16, null='null'), 'result.json')
# Verification record includes regression count and independent point-estimate identity checks.
writeLines(c(
  'Verification of applied_shift_share calculation',
  sprintf('Rows: %d region-industry observations; regions: %d; industries: %d.', nrow(d), nrow(r), N),
  sprintf('Sample checks: unique region-industry pairs; x, y, and region_weight constant within region; maximum share-sum error = %.12g.', max(abs(share_sums-1))),
  sprintf('Regional weights normalized once over %d regions; sum(e) = %.16g. Industry exposure weights sum(s) = %.16g.', nrow(r), sum(e), sum(s)),
  sprintf('Independent identity check: regional versus shock-level effect slopes = %.12g versus %.12g; absolute difference = %.3g.', reg_eff[2], eff$coef[2], abs(reg_eff[2]-eff$coef[2])),
  sprintf('Independent identity check: regional versus shock-level first-stage slopes = %.12g versus %.12g; absolute difference = %.3g.', reg_fs[2], fs$coef[2], abs(reg_fs[2]-fs$coef[2])),
  sprintf('Shock-level HC1 uses structural IV residuals and analytic weights, with N/(N-2) = %.12g; number of independent industries N = %d.', N/(N-2), N),
  sprintf('Final estimates: effect %.12g (SE %.12g); first_stage %.12g (SE %.12g); effective_shocks %.12g.', eff$coef[2], eff$se[2], reg_fs[2], fs$se[2], 1/sum(s^2))
), 'verification.txt')
