import csv, math
rows=[]
with open('input.csv', newline='') as f:
    for r in csv.DictReader(f):
        x=float(r['score'])
        if abs(x)<1:
            side=int(x>=0)
            rows.append((x,side,1-abs(x),float(r['earnings']),float(r['participated'])))
# Independent separate-side weighted regressions and HC0 covariance for each joint score contribution.
# Compute weighted least squares coefficients via direct 2x2 moments.
nests=[]
for idx in (3,4):
    coeff=[]; residuals=[]
    for side in (0,1):
        rr=[r for r in rows if r[1]==side]
        sw=sum(r[2] for r in rr); sx=sum(r[2]*r[0] for r in rr); sxx=sum(r[2]*r[0]**2 for r in rr)
        sy=sum(r[2]*r[idx] for r in rr); sxy=sum(r[2]*r[0]*r[idx] for r in rr)
        det=sw*sxx-sx*sx
        a=(sy*sxx-sxy*sx)/det; b=(sxy*sw-sy*sx)/det
        coeff.append((a,b))
        residuals.append({id(r):r[idx]-a-b*r[0] for r in rr})
    jump=coeff[1][0]-coeff[0][0]
    # Observation influence for intercept jump: side-specific intercept row of weighted design inverse times weighted residual.
    inf=[]
    for r in rows:
        side=r[1]; rr=[q for q in rows if q[1]==side]
        sw=sum(q[2] for q in rr); sx=sum(q[2]*q[0] for q in rr); sxx=sum(q[2]*q[0]**2 for q in rr); det=sw*sxx-sx*sx
        intercept_loading=r[2]*(sxx-sx*r[0])/det
        sign=1 if side else -1
        inf.append(sign*intercept_loading*residuals[side][id(r)])
    nests.append((jump,inf))
rf, fs=nests
cov=sum(a*b for a,b in zip(rf[1],fs[1])); vrf=sum(a*a for a in rf[1]); vfs=sum(b*b for b in fs[1])
tau=rf[0]/fs[0]; g1=1/fs[0]; g2=-rf[0]/fs[0]**2
se=math.sqrt(g1*g1*vrf+g2*g2*vfs+2*g1*g2*cov)
print(f'independent n={len(rows)}, reduced_form={rf[0]:.12g}, first_stage={fs[0]:.12g}, treatment_effect={tau:.12g}')
print(f'independent HC0 se RF={math.sqrt(vrf):.12g}, FS={math.sqrt(vfs):.12g}, covariance={cov:.12g}, treatment={se:.12g}')
