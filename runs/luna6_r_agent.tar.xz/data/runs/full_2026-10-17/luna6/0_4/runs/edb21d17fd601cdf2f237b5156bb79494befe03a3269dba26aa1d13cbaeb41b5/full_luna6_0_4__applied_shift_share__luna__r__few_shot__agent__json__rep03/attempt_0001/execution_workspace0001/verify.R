d <- read.csv('input.csv')
rids <- unique(d$region_id); iids <- unique(d$industry_id)
reg <- data.frame(region_id=rids, w=sapply(rids,function(i) unique(d$region_weight[d$region_id==i])[1]), x=sapply(rids,function(i) unique(d$x[d$region_id==i])[1]), y=sapply(rids,function(i) unique(d$y[d$region_id==i])[1]))
e <- reg$w/sum(reg$w)
S <- matrix(0,length(rids),length(iids)); S[cbind(match(d$region_id,rids),match(d$industry_id,iids))] <- d$share
shock <- sapply(iids,function(i) unique(d$shock[d$industry_id==i])[1])
z <- drop(S%*%shock)
# Independent regional weighted first-stage and Wald ratio calculations.
xc <- reg$x-sum(e*reg$x); zc <- z-sum(e*z); yc <- reg$y-sum(e*reg$y)
fs <- sum(e*zc*xc)/sum(e*zc^2)
wald <- sum(e*zc*yc)/sum(e*zc*xc)
# Independent shock-level 2SLS slopes using the scalar weighted Wald identities.
s <- drop(crossprod(e,S)); x0 <- xc; y0 <- yc; z0 <- zc
xb <- drop(crossprod(S,e*x0))/s; yb <- drop(crossprod(S,e*y0))/s; zb <- drop(crossprod(S,e*z0))/s
shock_effect <- sum(s*shock*yb)/sum(s*shock*xb)
shock_fs <- sum(s*shock*xb)/sum(s*shock*zb)
cat('regions',length(rids),'industries',length(iids),'rows',nrow(d),'\n')
cat('weight_sum',sum(e),'share_sum_err',max(abs(tapply(d$share,d$region_id,sum)-1)),'\n')
cat('regional_fs',fs,'shock_fs',shock_fs,'\n')
cat('regional_iv_wald',wald,'shock_iv',shock_effect,'\n')
cat('effective_shocks',1/sum(s^2),'\n')
