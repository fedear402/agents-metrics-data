# Shift-share IV with shock-level HC1 uncertainty
suppressPackageStartupMessages(library(jsonlite))
d <- read.csv('input.csv', stringsAsFactors=FALSE)
req <- c('region_id','industry_id','share','shock','region_weight','x','y')
stopifnot(all(req %in% names(d)), nrow(d) > 0)
# Validate repeated values and normalized baseline shares.
by_region <- split(d, d$region_id)
close_const <- function(v) max(v) - min(v) < 1e-10
stopifnot(all(vapply(by_region, function(a) close_const(a$region_weight) && close_const(a$x) && close_const(a$y), logical(1))))
stopifnot(all(vapply(split(d$shock,d$industry_id), close_const, logical(1))))
stopifnot(all(abs(vapply(by_region, function(a) sum(a$share), numeric(1))-1) < 1e-7))
# One row per region. Normalize weights once at regional level.
r <- do.call(rbind, lapply(by_region, function(a) data.frame(region_id=a$region_id[1], region_weight=a$region_weight[1], x=a$x[1], y=a$y[1], z=sum(a$share*a$shock))))
r$e <- r$region_weight / sum(r$region_weight)
weighted_mean <- function(a,w) sum(a*w)/sum(w)
r$y0 <- r$y-weighted_mean(r$y,r$e); r$x0 <- r$x-weighted_mean(r$x,r$e); r$z0 <- r$z-weighted_mean(r$z,r$e)
# Industry totals and residual aggregates, using the full region-industry grid.
industries <- sort(unique(d$industry_id))
shocks <- tapply(d$shock,d$industry_id,function(v) v[1])[as.character(industries)]
s <- setNames(numeric(length(industries)), as.character(industries))
agg <- data.frame(industry_id=industries, s=0, ybar=0, xbar=0, zbar=0, shock=as.numeric(shocks))
ri <- match(d$region_id, r$region_id); ni <- match(d$industry_id, industries)
for (j in seq_along(industries)) {
 idx <- ni==j
 w <- r$e[ri[idx]]*d$share[idx]
 agg$s[j] <- sum(w)
 agg$ybar[j] <- sum(w*r$y0[ri[idx]])/agg$s[j]
 agg$xbar[j] <- sum(w*r$x0[ri[idx]])/agg$s[j]
 agg$zbar[j] <- sum(w*r$z0[ri[idx]])/agg$s[j]
}
stopifnot(all(agg$s>0), abs(sum(agg$s)-1)<1e-8)
# Weighted IV slope and structural residual HC1 analytic-weight sandwich.
iv_hc1 <- function(y,x,z,w) {
 X <- cbind(1, x); Z <- cbind(1,z)
 A <- crossprod(Z, X*w)
 b <- solve(A, crossprod(Z, y*w))
 u <- as.numeric(y-X%*%b)
 bread <- solve(A) %*% crossprod(Z, Z*w) %*% t(solve(A))
 # With analytic weights, meat uses squared weighted score contributions.
 meat <- crossprod(Z, Z*(w^2*u^2))
 V <- solve(A) %*% meat %*% t(solve(A))
 n <- length(y); V <- V*n/(n-ncol(X))
 c(estimate=b[2], se=sqrt(V[2,2]))
}
eff <- 1/sum(agg$s^2)
effect <- iv_hc1(agg$ybar,agg$xbar,agg$shock,agg$s)
first <- iv_hc1(agg$xbar,agg$zbar,agg$shock,agg$s)
N <- nrow(agg)
res <- list(task_id='applied_shift_share', platform='r', estimates=list(
 list(term='effect',estimate=unname(effect['estimate']),se=unname(effect['se']),n_obs=N),
 list(term='first_stage',estimate=unname(first['estimate']),se=unname(first['se']),n_obs=N),
 list(term='effective_shocks',estimate=eff,se=NULL,n_obs=N)),
 method_metadata=list(estimator='Weighted 2SLS; Borusyak-Hull-Jaravel shock-level aggregation',vcov='Shock-level heteroskedastic-robust HC1, analytic weights, structural IV residuals, no clustering'), diagnostics=list(n_regions=nrow(r),n_industries=N,regional_rows=nrow(d),sum_exposure=sum(agg$s)))
write_json(res,'result.json', auto_unbox=TRUE, digits=15, pretty=TRUE, null='null')
# Independent identity check: aggregated shock-level IV coefficient equals regional WLS reduced form / first stage ratio.
reg_rf <- weighted_mean(r$z0*r$y0,r$e)/weighted_mean(r$z0*r$x0,r$e)
stopifnot(abs(effect['estimate']-reg_rf)<1e-8)
