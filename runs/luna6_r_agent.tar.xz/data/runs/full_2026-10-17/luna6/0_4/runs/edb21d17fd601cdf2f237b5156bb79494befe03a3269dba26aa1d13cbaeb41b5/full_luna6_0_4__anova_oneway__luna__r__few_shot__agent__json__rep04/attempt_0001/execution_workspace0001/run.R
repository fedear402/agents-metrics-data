library(jsonlite)
dat <- read.csv("./input.csv", stringsAsFactors = FALSE)
stopifnot(all(c("group", "y") %in% names(dat)))
dat <- dat[complete.cases(dat[, c("group", "y")]), c("group", "y")]
dat$group <- factor(dat$group)
fit <- aov(y ~ group, data = dat)
tab <- summary(fit)[[1]]
n <- nrow(dat)
out <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = list(
    list(term = "F", estimate = unname(tab[1, "F value"]), se = NA_real_, n_obs = n),
    list(term = "df_num", estimate = unname(tab[1, "Df"]), se = NA_real_, n_obs = n),
    list(term = "df_den", estimate = unname(tab[2, "Df"]), se = NA_real_, n_obs = n),
    list(term = "p_value", estimate = unname(tab[1, "Pr(>F)"]), se = NA_real_, n_obs = n)
  ),
  method_metadata = list(estimator = "One-way ANOVA", vcov = "Classical homoskedastic ANOVA"),
  diagnostics = structure(list(), names = character(0))
)
write_json(out, "result.json", auto_unbox = TRUE, na = "null", digits = 16)
