args <- commandArgs(trailingOnly = FALSE)
script_arg <- grep('^--file=', args, value = TRUE)
wd <- if (length(script_arg)) dirname(normalizePath(sub('^--file=', '', script_arg[1]))) else getwd()
setwd(wd)
d <- read.csv('input.csv', stringsAsFactors = FALSE)
required <- c('region_id','industry_id','share','shock','region_weight','x','y')
stopifnot(all(required %in% names(d)))
# The input has one row per region-industry pair. Confirm region variables and shocks repeat consistently.
stopifnot(!anyDuplicated(d[c('region_id','industry_id')]))
check_const <- function(v, group) all(vapply(split(d[[v]], d[[group]]), function(a) length(unique(a)) == 1L, logical(1)))
stopifnot(check_const('region_weight','region_id'), check_const('x','region_id'), check_const('y','region_id'), check_const('shock','industry_id'))
regions <- unique(d$region_id)
industries <- unique(d$industry_id)
reg <- data.frame(region_id=regions,
  region_weight=vapply(regions, function(r) d$region_weight[match(r,d$region_id)], numeric(1)),
  x=vapply(regions, function(r) d$x[match(r,d$region_id)], numeric(1)),
  y=vapply(regions, function(r) d$y[match(r,d$region_id)], numeric(1)))
e <- reg$region_weight / sum(reg$region_weight)
# Construct regional exposure using all region-industry rows.
z <- vapply(regions, function(r) sum(d$share[d$region_id == r] * d$shock[d$region_id == r]), numeric(1))
reg$z <- z
# Verify each regional share total and create weighted-centered regional variables.
share_totals <- vapply(regions, function(r) sum(d$share[d$region_id == r]), numeric(1))
stopifnot(max(abs(share_totals - 1)) < 1e-8)
means <- c(y=sum(e*reg$y), x=sum(e*reg$x), z=sum(e*reg$z))
y0 <- reg$y-means['y']; x0 <- reg$x-means['x']; z0 <- reg$z-means['z']
# Regional weighted IV and first-stage slopes.
regional_effect <- sum(e*z0*y0)/sum(e*z0*x0)
regional_first <- sum(e*z0*x0)/sum(e*z0^2)
# Industry exposure masses and exposure-weighted means of centered residuals.
s <- vapply(industries, function(n) {
  rows <- which(d$industry_id == n)
  rr <- match(d$region_id[rows], regions)
  sum(e[rr] * d$share[rows])
}, numeric(1))
# Build unique industry shock vector and aggregated variables from region-industry rows.
shock_n <- vapply(industries, function(n) d$shock[match(n,d$industry_id)], numeric(1))
agg <- function(v0) vapply(seq_along(industries), function(j) {
  n <- industries[j]
  rows <- which(d$industry_id == n)
  rr <- match(d$region_id[rows], regions)
  sum(e[rr] * d$share[rows] * v0[rr]) / s[j]
}, numeric(1))
ybar <- agg(y0); xbar <- agg(x0); zbar <- agg(z0)
stopifnot(all(s > 0), abs(sum(s)-1) < 1e-8)
# Weighted IV coefficient and HC1 sandwich. With one endogenous variable and one excluded instrument,
# beta solves sum_n s_n q_n (Y_n - X_n beta) = 0, q=(1, shock).
shock_iv <- function(Y, X, q_excluded) {
  Q <- cbind(1, q_excluded)
  Xmat <- cbind(1, X)
  A <- crossprod(Q, s * Xmat)
  b <- drop(solve(A, crossprod(Q, s * Y)))
  u <- drop(Y - Xmat %*% b)
  # Analytic weights: score per industry is s_n q_n u_n; HC1 uses N/(N-2).
  meat <- crossprod(Q * (s*u))
  invA <- solve(A)
  V <- length(industries)/(length(industries)-2) * invA %*% meat %*% t(invA)
  c(slope=unname(b[2]), se=sqrt(V[2,2]))
}
N <- length(industries)
effect <- shock_iv(ybar, xbar, shock_n)
first_stage <- shock_iv(xbar, zbar, shock_n)
effective_shocks <- 1/sum(s^2)
# Numerical identities: shock aggregation slopes equal regional weighted IV slopes.
stopifnot(abs(effect["slope"]-regional_effect) < 1e-8,
          abs(first_stage['slope']-regional_first) < 1e-8)
rows <- list(
  list(term='effect', estimate=unname(effect['slope']), se=unname(effect['se']), n_obs=as.integer(N)),
  list(term='first_stage', estimate=unname(first_stage['slope']), se=unname(first_stage['se']), n_obs=as.integer(N)),
  list(term='effective_shocks', estimate=unname(effective_shocks), se=NULL, n_obs=as.integer(N)))
out <- list(task_id='applied_shift_share', platform='r', estimates=rows,
  method_metadata=list(estimator='weighted 2SLS; BHJ shock-level aggregation', vcov='shock-level analytic-weight HC1, structural IV residuals, N/(N-2), no clustering'),
  diagnostics=list(regions=length(regions), industries=N, region_industry_rows=nrow(d), regional_effect=unname(regional_effect), regional_first_stage=unname(regional_first), weight_sum=sum(e), share_total_min=min(share_totals), share_total_max=max(share_totals)))
if (!requireNamespace('jsonlite', quietly=TRUE)) stop('jsonlite package is required')
jsonlite::write_json(out, 'result.json', auto_unbox=TRUE, null='null', digits=16, pretty=TRUE)
