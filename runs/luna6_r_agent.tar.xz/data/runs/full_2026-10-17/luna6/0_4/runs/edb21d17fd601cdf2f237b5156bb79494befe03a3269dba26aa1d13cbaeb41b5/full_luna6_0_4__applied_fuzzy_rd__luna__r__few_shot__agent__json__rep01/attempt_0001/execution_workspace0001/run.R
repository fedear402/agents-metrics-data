#!/usr/bin/env Rscript
suppressPackageStartupMessages(library(jsonlite))

task_id <- "applied_fuzzy_rd"
d <- read.csv("input.csv")
inside <- abs(d$score) < 1
d <- d[inside, , drop = FALSE]
n <- nrow(d)

# Separate intercepts and local-linear slopes on the two sides of zero.
x <- d$score
right <- as.numeric(x >= 0)
X <- cbind(left_intercept = 1 - right,
           left_slope = x * (1 - right),
           right_intercept = right,
           right_slope = x * right)
w <- 1 - abs(x)
Y <- cbind(earnings = d$earnings, participated = d$participated)

# Weighted least squares with fixed triangular weights.
bread <- solve(crossprod(X, w * X))
beta <- bread %*% crossprod(X, w * Y)
resid <- Y - X %*% beta
contrast <- c(-1, 0, 1, 0)
jump <- drop(contrast %*% beta)

# HC0 meat, with one weighted score contribution per observation.
loading <- drop(X %*% bread %*% contrast)
influence <- (w * loading) * resid
joint <- crossprod(influence)
ratio <- jump[1] / jump[2]
gradient <- c(1 / jump[2], -jump[1] / jump[2]^2)
ratio_se <- sqrt(drop(t(gradient) %*% joint %*% gradient))

row <- function(term, estimate, se) {
  list(term = term, estimate = unname(as.numeric(estimate)),
       se = unname(as.numeric(se)), n_obs = as.integer(n))
}
result <- list(
  task_id = task_id,
  platform = "r",
  estimates = list(
    row("treatment_effect", ratio, ratio_se),
    row("reduced_form", jump[1], sqrt(joint[1, 1])),
    row("first_stage", jump[2], sqrt(joint[2, 2]))
  ),
  method_metadata = list(
    estimator = "Weighted local-linear fuzzy regression discontinuity; triangular kernel; separate slopes and intercepts",
    vcov = "HC0 sandwich with fixed bandwidth and weights; joint covariance and delta method for ratio"
  ),
  diagnostics = list()
)
write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
