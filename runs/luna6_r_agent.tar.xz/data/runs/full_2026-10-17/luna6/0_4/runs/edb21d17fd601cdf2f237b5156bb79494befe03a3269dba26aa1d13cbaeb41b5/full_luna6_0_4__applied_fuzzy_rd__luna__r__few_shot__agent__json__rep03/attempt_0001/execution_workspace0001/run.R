dat <- read.csv("input.csv")
s <- dat$score
keep <- abs(s) < 1
d <- dat[keep, , drop=FALSE]
x <- d$score
right <- as.numeric(x >= 0)
w <- 1 - abs(x)
# Side-specific local linear regression: intercept and score within each side.
X <- cbind(left_intercept=1-right, left_slope=(1-right)*x,
          right_intercept=right, right_slope=right*x)
Y <- cbind(earnings=d$earnings, participated=d$participated)
W <- diag(w)
B <- solve(crossprod(X, W %*% X))
beta <- B %*% crossprod(X, W %*% Y)
e <- Y - X %*% beta
# Right limit minus left limit, selected by this coefficient contrast.
c <- c(-1, 0, 1, 0)
jump <- drop(crossprod(c, beta))
# HC0 sandwich, joint across outcomes; no finite-sample multiplier.
score_contrib <- X * as.vector(w * 1) # kept for clear dimensions
A <- X %*% B
loading <- drop(A %*% c) * w
infl <- e * loading
V <- crossprod(infl)
rf <- jump[1]
fs <- jump[2]
g <- c(1/fs, -rf/fs^2)
treat <- rf/fs
se_rf <- sqrt(V[1,1]); se_fs <- sqrt(V[2,2])
se_treat <- sqrt(drop(t(g) %*% V %*% g))
n <- nrow(d)
row <- function(term, estimate, se) list(term=term, estimate=unname(as.numeric(estimate)), se=unname(as.numeric(se)), n_obs=as.integer(n))
out <- list(task_id="applied_fuzzy_rd", platform="r",
 estimates=list(row("treatment_effect",treat,se_treat),row("reduced_form",rf,se_rf),row("first_stage",fs,se_fs)),
 method_metadata=list(estimator="weighted local-linear fuzzy regression discontinuity",vcov="HC0 sandwich, joint outcome covariance; fixed triangular weights"), diagnostics=list())
jsonlite::write_json(out,"result.json",auto_unbox=TRUE,null="null",digits=16,pretty=TRUE)
# Independent identity check: separate weighted side regressions yield identical intercepts.
fit_side <- function(y, r) {
  a <- which((right == r))
  Xs <- cbind(1, x[a])
  solve(crossprod(Xs, w[a]*Xs), crossprod(Xs, w[a]*y[a]))[1]
}
identity_jumps <- c(fit_side(Y[,1],1)-fit_side(Y[,1],0), fit_side(Y[,2],1)-fit_side(Y[,2],0))
stopifnot(max(abs(identity_jumps-jump)) < 1e-10)
# Check HC0 meat directly via observation-level weighted residual score matrix.
meat <- crossprod((X %*% B) * (w*1), e)
meat <- matrix(0, 2, 2)
for (i in seq_len(ncol(e))) for (j in seq_len(ncol(e))) meat[i,j] <- sum((w * e[,i] * drop(X %*% B %*% c)) * (w * e[,j] * drop(X %*% B %*% c)))
stopifnot(max(abs(V-meat)) < 1e-10)
cat(sprintf("n=%d; jump estimates: %.12g, %.12g; covariance %.12g\n", n, rf, fs, V[1,2]))
