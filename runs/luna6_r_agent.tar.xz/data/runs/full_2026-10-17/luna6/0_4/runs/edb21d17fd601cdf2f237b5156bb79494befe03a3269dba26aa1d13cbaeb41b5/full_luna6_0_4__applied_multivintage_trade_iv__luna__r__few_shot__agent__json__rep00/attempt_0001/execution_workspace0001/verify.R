suppressPackageStartupMessages(library(jsonlite))
# Load the production script into an isolated environment to obtain its constructed sample.
env <- new.env(); sys.source('run.R', envir=env)
r <- env$reg
stopifnot(nrow(r)==72L, length(unique(r$area))==36L, length(unique(r$period))==2L)
# Independent 2SLS calculation using the weighted projection matrix identity.
C <- cbind(intercept=1, period=r$period, control=r$control)
X <- cbind(C, x=r$x); Z <- cbind(C, z=r$z); W <- diag(r$population)
Pz <- Z %*% solve(crossprod(Z, W %*% Z), t(Z) %*% W)
b_ind <- solve(crossprod(X, W %*% Pz %*% X), crossprod(X, W %*% Pz %*% r$change_pp))
res <- fromJSON('result.json', simplifyVector=FALSE)
stopifnot(abs(unname(b_ind[4])-res$estimates[[1]]$estimate)<1e-10)
# Independent exposure check: reproduce area 0 values with an explicit industry loop.
cw <- read.csv('crosswalk.csv'); tr <- merge(read.csv('trade.csv'),cw,by='code')
a <- read.csv('areas.csv'); e <- read.csv('employment.csv')
explicit <- function(p,v,ch) {
  aa <- a[a$area==0 & a$period==p & a$vintage==v,]
  ans <- 0
  for (j in unique(cw$industry)) {
    q <- e$employment[e$area==0 & e$period==p & e$vintage==v & e$industry==j]
    if (!length(q)) q <- 0
    den <- sum(e$employment[e$period==p & e$vintage==v & e$industry==j])
    t <- tr[tr$period==p & tr$industry==j,]
    ans <- ans + (q/aa$total_employment) * (t[[ch]]/den)/(t$price_index/100)/1000*(10/t$years)
  }
  ans
}
x00 <- explicit(0,'base','us_change'); x01 <- explicit(1,'base','us_change'); z00 <- explicit(0,'early','other_change')
stopifnot(abs(x00-res$estimates[[2]]$estimate)<1e-8,
          abs(x01-res$estimates[[3]]$estimate)<1e-8,
          abs(z00-res$estimates[[4]]$estimate)<1e-8)
cat(sprintf('Sample check passed: %d rows, %d areas, %d periods.\n',nrow(r),length(unique(r$area)),length(unique(r$period))))
cat(sprintf('Matrix 2SLS identity passed: %.12f.\n',b_ind[4]))
cat(sprintf('Explicit exposure checks passed: x00=%.12f, x01=%.12f, z00=%.12f.\n',x00,x01,z00))
