dat <- read.csv("input.csv", stringsAsFactors = FALSE)
stopifnot(all(c("date", "sales", "vix") %in% names(dat)))
dat$date <- as.Date(dat$date)
dat <- dat[order(dat$date), ]
stopifnot(all(is.finite(dat$sales)), all(dat$sales > 0),
          all(is.finite(dat$vix)), all(dat$vix > 0))

# First differences align with the later observation; lag k uses delta at t-k.
dlogv <- c(NA_real_, diff(log(dat$vix)))
y <- log(dat$sales)
N <- nrow(dat)
idx <- seq.int(17L, N)
X <- cbind(`(Intercept)` = 1, sapply(1:15, function(k) dlogv[idx - k]))
colnames(X) <- c("(Intercept)", paste0("lag_", 1:15))
ys <- y[idx]
n <- length(ys)
stopifnot(n > 16L, all(is.finite(X)), all(is.finite(ys)))

fit <- lm.fit(X, ys)
beta <- fit$coefficients
resid <- fit$residuals
bread <- solve(crossprod(X))
# Bartlett HAC meat: contemporaneous score covariance plus weighted lags 1..15.
score <- X * as.numeric(resid)
meat <- crossprod(score)
for (j in 1:15) {
  gamma <- crossprod(score[(j + 1):n, , drop = FALSE],
                     score[1:(n - j), , drop = FALSE])
  w <- 1 - j / 16
  meat <- meat + w * (gamma + t(gamma))
}
V <- bread %*% meat %*% bread * n / (n - 16)
se <- sqrt(diag(V))

cum_weights <- c(0, rep(1, 15))
est <- c(sum(beta[-1]), beta[2], beta[16])
ses <- c(sqrt(drop(t(cum_weights) %*% V %*% cum_weights)), se[2], se[16])
out <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(term = "cumulative_response", estimate = unname(est[1]), se = unname(ses[1]), n_obs = as.integer(n)),
    list(term = "lag_1", estimate = unname(est[2]), se = unname(ses[2]), n_obs = as.integer(n)),
    list(term = "lag_15", estimate = unname(est[3]), se = unname(ses[3]), n_obs = as.integer(n))
  ),
  method_metadata = list(estimator = "OLS of log(sales) on intercept and lags 1-15 of first-differenced log(vix)",
                         vcov = "Newey-West HAC, Bartlett maxlag 15, covariance scaled by N/(N-16)"),
  diagnostics = list(sample_start = as.character(dat$date[idx[1]]),
                     sample_end = as.character(dat$date[idx[n]]), n_total = as.integer(N))
)
if (!requireNamespace("jsonlite", quietly = TRUE)) stop("jsonlite package is required")
jsonlite::write_json(out, "result.json", auto_unbox = TRUE, digits = 16, pretty = TRUE, null = "null")

# Independent check: equivalent HAC calculation through sandwich::NeweyWest.
if (!requireNamespace("sandwich", quietly = TRUE)) stop("sandwich package is required")
df <- data.frame(y = ys, X[, -1, drop = FALSE], check.names = FALSE)
fit_check <- lm(y ~ ., data = df)
V_check <- sandwich::NeweyWest(fit_check, lag = 15, prewhite = FALSE,
                               adjust = TRUE)
stopifnot(max(abs(coef(fit_check) - beta)) < 1e-10,
          max(abs(V_check - V)) < 1e-8)
cat(sprintf("N=%d, coefficients max diff=%.3g, covariance max diff=%.3g\n",
            n, max(abs(coef(fit_check) - beta)), max(abs(V_check - V))))
