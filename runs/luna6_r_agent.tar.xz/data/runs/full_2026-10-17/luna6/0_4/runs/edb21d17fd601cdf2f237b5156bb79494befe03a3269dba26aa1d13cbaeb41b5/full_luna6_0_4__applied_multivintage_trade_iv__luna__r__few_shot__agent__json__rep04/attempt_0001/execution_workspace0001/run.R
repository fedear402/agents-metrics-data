options(stringsAsFactors = FALSE)

crosswalk <- read.csv("crosswalk.csv")
trade <- read.csv("trade.csv")
areas <- read.csv("areas.csv")
employment <- read.csv("employment.csv")
outcomes <- read.csv("outcomes.csv")

stopifnot(length(unique(crosswalk$industry)) == 4L)
stopifnot(!anyDuplicated(crosswalk$code))
trade <- merge(trade, crosswalk, by = "code", sort = FALSE)
stopifnot(all(vapply(split(trade$industry, trade$period), function(v) length(v) == 4L && !anyDuplicated(v), logical(1))))

periods <- sort(unique(areas$period))
industries <- sort(unique(crosswalk$industry))
make_exposure <- function(vintage, trade_value) {
  a <- areas[areas$vintage == vintage, c("area", "period", "total_employment")]
  e <- employment[employment$vintage == vintage, c("area", "period", "industry", "employment")]
  # Complete the area-industry grid so omitted cells contribute zero.
  grid <- merge(a[c("area", "period")], data.frame(industry = industries), all = TRUE)
  e <- merge(grid, e, by = c("area", "period", "industry"), all.x = TRUE)
  e$employment[is.na(e$employment)] <- 0
  e <- merge(e, a, by = c("area", "period"))
  for (p in periods) {
    denom <- aggregate(employment ~ industry, e[e$period == p, ], sum)
    tt <- trade[trade$period == p, c("industry", trade_value, "price_index", "years")]
    names(tt)[2] <- "trade_change"
    e_p <- e[e$period == p, ]
    e_p <- merge(e_p, denom, by = "industry", suffixes = c("", "_national"))
    e_p <- merge(e_p, tt, by = "industry")
    e_p$component <- (e_p$employment / e_p$total_employment) *
      (e_p$trade_change / e_p$employment_national) /
      (e_p$price_index / 100) / 1000 * (10 / e_p$years)
    value <- aggregate(component ~ area + period, e_p, sum)
    if (p == periods[1]) result <- value else result <- rbind(result, value)
  }
  names(result)[3] <- if (trade_value == "us_change") "x" else "z"
  result
}

x <- make_exposure("base", "us_change")
z <- make_exposure("early", "other_change")
reg <- merge(areas[areas$vintage == "base", c("area", "period", "population")],
             outcomes, by = c("area", "period"))
reg <- merge(reg, x, by = c("area", "period"))
reg <- merge(reg, z, by = c("area", "period"))
reg <- reg[order(reg$area, reg$period), ]
stopifnot(nrow(reg) == 72L, !anyNA(reg))

# Weighted 2SLS via the weighted projection formula. Exogenous regressors instrument themselves.
reg$period_indicator <- as.numeric(reg$period == max(reg$period))
Y <- as.matrix(reg$change_pp)
X <- cbind(intercept = 1, period = reg$period_indicator,
           control = reg$control, x = reg$x)
Z <- cbind(intercept = 1, period = reg$period_indicator,
           control = reg$control, z = reg$z)
sw <- sqrt(reg$population)
Xw <- X * sw
Zw <- Z * sw
Yw <- Y * sw
PZX <- qr.fitted(qr(Zw), Xw)
coef <- qr.coef(qr(PZX), qr.fitted(qr(Zw), Yw))
names(coef) <- colnames(X)
iv_slope <- unname(coef["x"])
area0 <- reg[reg$area == 0, ]
exposure_area0_period0 <- unname(area0$x[area0$period == 0])
exposure_area0_period1 <- unname(area0$x[area0$period == 1])
instrument_area0_period0 <- unname(area0$z[area0$period == 0])

estimates <- list(
  list(term = "iv_slope", estimate = iv_slope, se = NULL, n_obs = 72L),
  list(term = "exposure_area0_period0", estimate = exposure_area0_period0, se = NULL, n_obs = 72L),
  list(term = "exposure_area0_period1", estimate = exposure_area0_period1, se = NULL, n_obs = 72L),
  list(term = "instrument_area0_period0", estimate = instrument_area0_period0, se = NULL, n_obs = 72L)
)
result <- list(task_id = "applied_multivintage_trade_iv", platform = "r",
               estimates = estimates,
               method_metadata = list(estimator = "weighted 2SLS", outcome = "change_pp",
                                      endogenous_regressor = "x", excluded_instrument = "z",
                                      exogenous_regressors = c("intercept", "period", "control"),
                                      weight = "base-vintage population",
                                      exposure_units = "thousands of real dollars per worker per decade"),
               diagnostics = list(n_obs = 72L, area_period_rows = nrow(reg),
                                 areas = length(unique(reg$area)), periods = length(unique(reg$period))))
jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = 16, null = "null", pretty = TRUE)

# Independent identity check: weighted 2SLS equals WLS of y on X fitted from weighted Z.
Xhat <- qr.fitted(qr(Zw), Xw)
yhat <- qr.fitted(qr(Zw), Yw)
coef_check <- solve(crossprod(Xhat), crossprod(Xhat, yhat))
stopifnot(max(abs(coef - as.vector(coef_check))) < 1e-8)
writeLines(c(
  paste("Estimation rows:", nrow(reg)),
  paste("Areas:", length(unique(reg$area)), "periods:", length(unique(reg$period))),
  paste("Weighted 2SLS x coefficient:", sprintf("%.12f", iv_slope)),
  paste("Independent check, WLS on instrument-projected weighted X:", sprintf("%.12f", coef_check[4])),
  paste("Difference:", sprintf("%.3g", abs(iv_slope - coef_check[4]))),
  paste("Area 0 period 0 x:", sprintf("%.12f", exposure_area0_period0)),
  paste("Area 0 period 1 x:", sprintf("%.12f", exposure_area0_period1)),
  paste("Area 0 period 0 z:", sprintf("%.12f", instrument_area0_period0)),
  "National employment denominators checked positive in construction; omitted cells set to zero."
), "verification.txt")
