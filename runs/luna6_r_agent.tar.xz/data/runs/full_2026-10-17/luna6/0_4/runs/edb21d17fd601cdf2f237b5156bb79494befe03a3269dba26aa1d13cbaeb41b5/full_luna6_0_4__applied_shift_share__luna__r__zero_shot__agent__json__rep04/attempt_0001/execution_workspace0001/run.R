dat <- read.csv("input.csv")

# Keep one row per region for the normalized analysis weights and regional data.
regions <- dat[!duplicated(dat$region_id), c("region_id", "region_weight", "x", "y")]
regions <- regions[order(regions$region_id), ]
regions$e <- regions$region_weight / sum(regions$region_weight)

# The shares and shocks define the regional instrument. Aggregate all supplied
# region-industry observations, retaining zero and very small shares.
dat <- merge(dat, regions[, c("region_id", "e")], by = "region_id", sort = FALSE)
z <- aggregate(dat$share * dat$shock, list(region_id = dat$region_id), sum)
names(z)[2] <- "z"
reg <- merge(regions, z, by = "region_id", sort = FALSE)
reg <- reg[order(reg$region_id), ]
stopifnot(nrow(reg) == nrow(regions))

# Weighted demeaning at the regional level.
for (v in c("y", "x", "z")) {
  reg[[paste0(v, "0")]] <- reg[[v]] - weighted.mean(reg[[v]], reg$e)
}

# Industry exposure weights and shock-level aggregates.
industry <- aggregate(cbind(e_share = dat$e * dat$share,
                            y_num = dat$e * dat$share * reg$y0[match(dat$region_id, reg$region_id)],
                            x_num = dat$e * dat$share * reg$x0[match(dat$region_id, reg$region_id)],
                            z_num = dat$e * dat$share * reg$z0[match(dat$region_id, reg$region_id)]),
                     list(industry_id = dat$industry_id, shock = dat$shock), sum)
industry$s <- industry$e_share
industry$ybar <- industry$y_num / industry$s
industry$xbar <- industry$x_num / industry$s
industry$zbar <- industry$z_num / industry$s
N <- nrow(industry)
stopifnot(N > 2, all(industry$s > 0), length(unique(industry$shock)) == N)

# Shock-level IV. Analytic weights are s_n. HC1 uses the structural IV score
# and the requested N/(N-2) multiplier, without clustering.
fit_iv <- ivreg::ivreg(ybar ~ xbar | shock, data = industry, weights = s)
fit_fs <- ivreg::ivreg(xbar ~ zbar | shock, data = industry, weights = s)
hc1_se <- function(fit, term) {
  V <- sandwich::vcovHC(fit, type = "HC1")
  unname(sqrt(V[term, term]))
}
effect <- unname(coef(fit_iv)["xbar"])
effect_se <- hc1_se(fit_iv, "xbar")
first_stage <- unname(coef(fit_fs)["zbar"])
first_stage_se <- hc1_se(fit_fs, "zbar")
effective_shocks <- 1 / sum(industry$s^2)

# Independent identities: regional weighted 2SLS equals its shock-level IV
# counterpart, and the requested first stage equals regional weighted OLS.
fit_reg_iv <- ivreg::ivreg(y ~ x | z, data = reg, weights = e)
fit_reg_fs <- lm(x ~ z, data = reg, weights = e)
checks <- c(effect_identity = abs(effect - unname(coef(fit_reg_iv)["x"])),
            first_stage_identity = abs(first_stage - unname(coef(fit_reg_fs)["z"])),
            shares_sum_max_error = max(abs(aggregate(share ~ region_id, dat, sum)$share - 1)),
            regional_weight_sum_error = abs(sum(reg$e) - 1),
            shock_weight_sum_error = abs(sum(industry$s) - 1))
stopifnot(max(checks) < 1e-8)

estimates <- list(
  list(term = "effect", estimate = effect, se = effect_se, n_obs = as.integer(N)),
  list(term = "first_stage", estimate = first_stage, se = first_stage_se, n_obs = as.integer(N)),
  list(term = "effective_shocks", estimate = effective_shocks, se = NULL, n_obs = as.integer(N))
)
result <- list(task_id = "applied_shift_share", platform = "r", estimates = estimates,
               method_metadata = list(estimator = "weighted 2SLS; Borusyak-Hull-Jaravel shock-level aggregation",
                                      vcov = "shock-level HC1 robust, analytic weights s_n, multiplier N/(N-2), no clustering"),
               diagnostics = list(n_regions = as.integer(nrow(reg)), n_industries = as.integer(N),
                                  checks = as.list(checks)))
jsonlite::write_json(result, "result.json", auto_unbox = TRUE, pretty = TRUE, null = "null", digits = 17)
