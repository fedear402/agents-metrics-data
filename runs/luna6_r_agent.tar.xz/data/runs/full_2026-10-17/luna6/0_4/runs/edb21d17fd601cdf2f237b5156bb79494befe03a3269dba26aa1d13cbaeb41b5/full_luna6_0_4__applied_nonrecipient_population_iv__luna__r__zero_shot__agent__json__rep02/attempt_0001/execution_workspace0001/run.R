#!/usr/bin/env Rscript
suppressPackageStartupMessages(library(jsonlite))
h <- read.csv("households.csv", stringsAsFactors = FALSE)
census <- read.csv("census.csv", stringsAsFactors = FALSE)

# Retain all nonrecipient households in both village treatment statuses.
s <- h[h$recipient == 0, , drop = FALSE]
n_obs <- nrow(s)
stopifnot(n_obs > 0, all(s$weight > 0), setequal(unique(s$eligible), c(0, 1)))
inelig <- 1 - s$eligible
elig <- s$eligible
X <- cbind(ineligible = inelig, eligible = elig,
           baseline_ineligible = s$baseline * inelig,
           baseline_eligible = s$baseline * elig,
           dose_ineligible = s$dose * inelig,
           dose_eligible = s$dose * elig)
Z <- cbind(ineligible = inelig, eligible = elig,
           baseline_ineligible = s$baseline * inelig,
           baseline_eligible = s$baseline * elig,
           instrument_ineligible = s$instrument * inelig,
           instrument_eligible = s$instrument * elig)
y <- s$outcome
w <- s$weight

# Weighted 2SLS by weighted projection on the stated instrument matrix.
sqrtw <- sqrt(w)
Zw <- Z * sqrtw
Xw <- X * sqrtw
yw <- y * sqrtw
Q <- qr(Zw)
stopifnot(Q$rank == ncol(Z))
Xhatw <- qr.fitted(Q, Xw)
yhatw <- qr.fitted(Q, yw)
beta <- as.numeric(solve(crossprod(Xw, Xhatw), crossprod(Xw, yhatw)))
names(beta) <- colnames(X)
weighted_mean <- function(x, weight) sum(x * weight) / sum(weight)
ineligible_rows <- inelig == 1
eligible_rows <- elig == 1
mean_dose_ineligible <- weighted_mean(s$dose[ineligible_rows], w[ineligible_rows])
mean_dose_eligible <- weighted_mean(s$dose[eligible_rows], w[eligible_rows])
ineligible_effect <- beta[["dose_ineligible"]] * mean_dose_ineligible
eligible_nonrecipient_effect <- beta[["dose_eligible"]] * mean_dose_eligible

# Census counts enter only in the final between-group aggregation.
pop <- census$nonrecipient_population[match(c(0, 1), census$eligible)]
stopifnot(length(pop) == 2, all(!is.na(pop)), all(pop >= 0), sum(pop) > 0)
population_effect <- (ineligible_effect * pop[[1]] + eligible_nonrecipient_effect * pop[[2]]) / sum(pop)

estimates <- list(
  list(term = "ineligible_effect", estimate = unname(ineligible_effect), se = NULL, n_obs = as.integer(n_obs)),
  list(term = "eligible_nonrecipient_effect", estimate = unname(eligible_nonrecipient_effect), se = NULL, n_obs = as.integer(n_obs)),
  list(term = "population_effect", estimate = unname(population_effect), se = NULL, n_obs = as.integer(n_obs))
)
result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "weighted 2SLS",
    estimation_sample = "all household rows with recipient=0, across both treated-village statuses",
    endogenous_columns = c("dose*(1-eligible)", "dose*eligible"),
    exogenous_columns = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"),
    instrument_columns = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible", "instrument*(1-eligible)", "instrument*eligible"),
    additional_intercept = FALSE,
    regression_weight = "weight",
    within_group_dose_mean = "household-weighted mean using weight",
    counterfactual = "dose set to zero for every retained household; attribution is a stated synthetic convention",
    census_use = "nonrecipient_population used only for final between-group aggregation",
    n_obs_definition = "number of nonrecipient household rows used in estimation",
    uncertainty = "se is null as requested"
  ),
  diagnostics = list(
    n_obs = as.integer(n_obs),
    retained_by_eligible = as.list(table(factor(s$eligible, levels = c(0, 1)))),
    retained_treated_status = as.list(table(factor(s$treated, levels = c(0, 1)))),
    weighted_mean_dose_by_eligible = list(`0` = mean_dose_ineligible, `1` = mean_dose_eligible),
    dose_slope_by_eligible = list(ineligible = unname(beta[["dose_ineligible"]]), eligible_nonrecipient = unname(beta[["dose_eligible"]])),
    census_population_by_eligible = list(`0` = pop[[1]], `1` = pop[[2]]),
    instrument_rank = as.integer(Q$rank),
    endogenous_design_rank = as.integer(qr(Xw)$rank)
  )
)
write_json(result, "result.json", auto_unbox = TRUE, pretty = TRUE, digits = 17, null = "null")

# Independent matrix check of the weighted 2SLS coefficients and aggregation.
Pz <- Zw %*% solve(crossprod(Zw), t(Zw))
beta_check <- solve(crossprod(Xw, Pz %*% Xw), crossprod(Xw, Pz %*% yw))
stopifnot(isTRUE(all.equal(as.numeric(beta_check), unname(beta), tolerance = 1e-10)))
effect_check <- (ineligible_effect * pop[[1]] + eligible_nonrecipient_effect * pop[[2]]) / sum(pop)
stopifnot(isTRUE(all.equal(unname(effect_check), unname(population_effect), tolerance = 1e-12)))
cat(sprintf("n_obs=%d\n", n_obs))
cat(sprintf("ineligible_effect=%.17g\n", ineligible_effect))
cat(sprintf("eligible_nonrecipient_effect=%.17g\n", eligible_nonrecipient_effect))
cat(sprintf("population_effect=%.17g\n", population_effect))
