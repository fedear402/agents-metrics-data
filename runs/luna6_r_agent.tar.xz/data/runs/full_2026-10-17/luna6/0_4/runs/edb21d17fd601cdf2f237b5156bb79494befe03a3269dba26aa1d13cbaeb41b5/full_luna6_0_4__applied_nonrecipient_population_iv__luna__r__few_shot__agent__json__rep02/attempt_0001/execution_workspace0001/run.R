suppressPackageStartupMessages(library(jsonlite))
households <- read.csv("households.csv")
census <- read.csv("census.csv")

# Keep all nonrecipients, including both village treatment statuses.
d <- subset(households, recipient == 0)
stopifnot(nrow(d) == 300L, all(d$weight > 0), identical(sort(unique(d$eligible)), 0:1))
g0 <- 1 - d$eligible
g1 <- d$eligible
X <- cbind(g0, g1, d$baseline * g0, d$baseline * g1,
           d$dose * g0, d$dose * g1)
Z <- cbind(g0, g1, d$baseline * g0, d$baseline * g1,
           d$instrument * g0, d$instrument * g1)
w <- d$weight
# Weighted 2SLS via whitened projection onto all six instruments.
sw <- sqrt(w)
Xw <- X * sw
Zw <- Z * sw
Yw <- d$outcome * sw
qz <- qr(Zw)
Xhat <- qr.fitted(qz, Xw)
fit <- lm.fit(Xhat, Yw)
beta <- fit$coefficients
stopifnot(length(beta) == ncol(X), all(is.finite(beta)))

# The last two coefficients are group-specific dose slopes.
means <- vapply(0:1, function(g) {
  a <- d$eligible == g
  weighted.mean(d$dose[a], w[a])
}, numeric(1))
effects <- c(beta[5] * means[1], beta[6] * means[2])
pop <- weighted.mean(effects, census$nonrecipient_population[match(0:1, census$eligible)])
terms <- c("ineligible_effect", "eligible_nonrecipient_effect", "population_effect")
estimates <- data.frame(term = terms, estimate = c(effects, pop), se = rep(NA_real_, 3), n_obs = rep(nrow(d), 3))
result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "weighted 2SLS",
    sample = "all households with recipient == 0",
    endogenous = c("dose*(1-eligible)", "dose*eligible"),
    exogenous = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"),
    instruments = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible", "instrument*(1-eligible)", "instrument*eligible"),
    weight = "weight",
    group_effect = "fitted group dose slope times weighted mean dose among retained group observations",
    counterfactual = "dose set to zero for every retained household; attribution is a stated synthetic convention",
    population_aggregation = "census nonrecipient_population weights; census counts used only for final aggregation"
  ),
  diagnostics = list(
    n_obs = as.integer(nrow(d)),
    n_ineligible = as.integer(sum(d$eligible == 0)),
    n_eligible = as.integer(sum(d$eligible == 1)),
    instrument_matrix_rank = as.integer(qz$rank),
    projected_regressor_rank = as.integer(qr(Xhat)$rank),
    weighted_mean_dose_ineligible = unname(means[1]),
    weighted_mean_dose_eligible = unname(means[2]),
    dose_slope_ineligible = unname(beta[5]),
    dose_slope_eligible = unname(beta[6]),
    se_policy = "null as requested"
  )
)
write_json(result, "result.json", auto_unbox = TRUE, digits = 16, na = "null", pretty = TRUE)
cat(sprintf("ineligible_effect=%.12g\neligible_nonrecipient_effect=%.12g\npopulation_effect=%.12g\nn_obs=%d\n", effects[1], effects[2], pop, nrow(d)))
