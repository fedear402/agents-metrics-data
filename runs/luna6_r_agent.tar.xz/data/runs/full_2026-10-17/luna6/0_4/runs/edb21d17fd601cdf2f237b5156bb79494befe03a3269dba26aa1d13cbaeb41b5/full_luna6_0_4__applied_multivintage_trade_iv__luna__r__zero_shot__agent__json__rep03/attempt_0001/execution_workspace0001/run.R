suppressPackageStartupMessages(library(jsonlite))

crosswalk <- read.csv("crosswalk.csv", stringsAsFactors=FALSE)
trade <- read.csv("trade.csv", stringsAsFactors=FALSE)
areas <- read.csv("areas.csv", stringsAsFactors=FALSE)
employment <- read.csv("employment.csv", stringsAsFactors=FALSE)
outcomes <- read.csv("outcomes.csv", stringsAsFactors=FALSE)

trade <- merge(trade, crosswalk, by="code", all.x=TRUE, sort=FALSE)
stopifnot(!anyNA(trade$industry), !anyDuplicated(trade[c("period", "industry")]))
stopifnot(all(sort(unique(trade$industry)) == 0:3))

# Complete omitted area-industry cells as zero, separately by vintage.
key <- unique(areas[c("area", "period", "vintage", "total_employment", "population")])
grid <- merge(key, data.frame(industry=0:3))
employment <- merge(grid, employment, by=c("area", "period", "vintage", "industry"), all.x=TRUE)
employment$employment[is.na(employment$employment)] <- 0

# National industry employment uses the sum over every supplied area, by period and vintage.
national <- aggregate(employment ~ period + vintage + industry, employment, sum)
base <- employment[employment$vintage == "base", c("area", "period", "industry", "employment", "total_employment", "population")]
early <- employment[employment$vintage == "early", c("area", "period", "industry", "employment")]
names(base)[names(base)=="employment"] <- "base_emp"
names(early)[names(early)=="employment"] <- "early_emp"
d <- merge(base, early, by=c("area", "period", "industry"), all=TRUE)
d$base_emp[is.na(d$base_emp)] <- 0
d$early_emp[is.na(d$early_emp)] <- 0

trade_base <- trade[c("period", "industry", "us_change", "other_change", "price_index", "years")]
d <- merge(d, trade_base, by=c("period", "industry"), all.x=TRUE)
d <- merge(d, national[national$vintage=="base", c("period", "industry", "employment")], by=c("period", "industry"), all.x=TRUE)
names(d)[names(d)=="employment"] <- "national_base"
d <- merge(d, national[national$vintage=="early", c("period", "industry", "employment")], by=c("period", "industry"), all.x=TRUE)
names(d)[names(d)=="employment"] <- "national_early"
stopifnot(!anyNA(d[c("us_change", "other_change", "price_index", "years", "national_base", "national_early")]))
d$term_x <- (d$base_emp / d$total_employment) * (d$us_change / d$national_base) / (d$price_index/100) / 1000 * (10/d$years)
d$term_z <- (d$early_emp / d$total_employment) * (d$other_change / d$national_early) / (d$price_index/100) / 1000 * (10/d$years)
exposure <- aggregate(cbind(x=term_x, z=term_z) ~ area + period + population, d, sum)

est <- merge(outcomes, exposure, by=c("area", "period"), all=FALSE)
stopifnot(nrow(est)==72L, length(unique(est$area))==36L, length(unique(est$period))==2L)
est$period <- as.numeric(est$period)
# Weighted 2SLS: residualize all variables on the three exogenous regressors,
# then use the weighted instrument residual for x.
w <- est$population
W <- sqrt(w)
Q <- cbind(intercept=1, period=est$period, control=est$control)
qfit <- qr(Q * W)
resid_w <- function(v) qr.resid(qfit, v * W)
yr <- resid_w(est$change_pp)
xr <- resid_w(est$x)
zr <- resid_w(est$z)
beta <- sum(zr * yr) / sum(zr * xr)

# Independent numerical check: explicit weighted matrix 2SLS using instrument set [Q,z].
X <- cbind(Q, x=est$x)
Z <- cbind(Q, z=est$z)
A <- crossprod(Z * W)
PZX <- crossprod(Z * W, X * W)
PZY <- crossprod(Z * W, est$change_pp * W)
b2sls <- solve(crossprod(PZX, solve(A, PZX)), crossprod(PZX, solve(A, PZY)))
stopifnot(isTRUE(all.equal(unname(beta), unname(b2sls["x",1]), tolerance=1e-10)))

x0 <- exposure$x[exposure$area==0 & exposure$period==0]
x1 <- exposure$x[exposure$area==0 & exposure$period==1]
z0 <- exposure$z[exposure$area==0 & exposure$period==0]
stopifnot(length(x0)==1L, length(x1)==1L, length(z0)==1L)
terms <- list(
 list(term="iv_slope", estimate=unname(beta), se=NULL, n_obs=72L),
 list(term="exposure_area0_period0", estimate=unname(x0), se=NULL, n_obs=72L),
 list(term="exposure_area0_period1", estimate=unname(x1), se=NULL, n_obs=72L),
 list(term="instrument_area0_period0", estimate=unname(z0), se=NULL, n_obs=72L)
)
result <- list(task_id="applied_multivintage_trade_iv", platform="r", estimates=terms,
 method_metadata=list(estimator="population-weighted 2SLS", outcome="change_pp", regressors=c("intercept", "period", "control", "x"), instruments=c("intercept", "period", "control", "z"), weight="base-vintage population", n_obs=72L),
 diagnostics=list(sample_rows=nrow(est), area_count=length(unique(est$area)), period_count=length(unique(est$period)), weighted_2sls_matrix_check_abs_diff=abs(unname(beta-b2sls["x",1]))))
write_json(result, "result.json", auto_unbox=TRUE, digits=16, null="null", pretty=TRUE)
