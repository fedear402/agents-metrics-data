suppressPackageStartupMessages(library(jsonlite))
d <- read.csv('input.csv')
# Confirm region-level variables are repeated consistently and shocks are industry-constant.
region_ids <- unique(d$region_id)
industry_ids <- unique(d$industry_id)
byr <- split(d, d$region_id)
stopifnot(all(vapply(byr, function(a) length(unique(a$region_weight)) == 1L && length(unique(a$x)) == 1L && length(unique(a$y)) == 1L, logical(1))))
byn <- split(d, d$industry_id)
stopifnot(all(vapply(byn, function(a) length(unique(a$shock)) == 1L, logical(1))))
reg <- do.call(rbind, lapply(byr, function(a) data.frame(region_id=a$region_id[1], weight=a$region_weight[1], x=a$x[1], y=a$y[1], z=sum(a$share*a$shock))))
rownames(reg) <- NULL
reg$e <- reg$weight/sum(reg$weight)
N <- length(industry_ids)
# Center regional variables using normalized region weights.
for (v in c('y','x','z')) reg[[paste0(v,'0')]] <- reg[[v]] - sum(reg$e*reg[[v]])
# Construct industry exposure masses and aggregates.
ind <- do.call(rbind, lapply(byn, function(a) {
  ridx <- match(a$region_id, reg$region_id)
  sn <- sum(reg$e[ridx]*a$share)
  data.frame(industry_id=a$industry_id[1], shock=a$shock[1], s=sn,
    ybar=sum(reg$e[ridx]*a$share*reg$y0[ridx])/sn,
    xbar=sum(reg$e[ridx]*a$share*reg$x0[ridx])/sn,
    zbar=sum(reg$e[ridx]*a$share*reg$z0[ridx])/sn)
}))
# Weighted IV with intercept. Structural residual covariance, analytic weights, HC1.
shock_iv <- function(dep, endog, instrument) {
  D <- cbind(1, endog)
  Q <- cbind(1, instrument)
  A <- crossprod(Q, ind$s*D)
  b <- solve(A, crossprod(Q, ind$s*dep))
  u <- drop(dep-D%*%b)
  scores <- Q*(ind$s*u)
  Ai <- solve(A)
  V <- (N/(N-2))*Ai%*%crossprod(scores)%*%t(Ai)
  c(slope=unname(b[2]), se=sqrt(V[2,2]))
}
eff <- shock_iv(ind$ybar, ind$xbar, ind$shock)
first <- shock_iv(ind$xbar, ind$zbar, ind$shock)
# Regional weighted 2SLS and first-stage slopes as identity checks.
reg_iv <- sum(reg$e*reg$z0*reg$y0)/sum(reg$e*reg$z0*reg$x0)
reg_fs <- sum(reg$e*reg$z0*reg$x0)/sum(reg$e*reg$z0^2)
stopifnot(abs(eff['slope']-reg_iv)<1e-8, abs(first['slope']-reg_fs)<1e-8)
rows <- list(
 list(term='effect', estimate=unname(eff['slope']), se=unname(eff['se']), n_obs=as.integer(N)),
 list(term='first_stage', estimate=unname(first['slope']), se=unname(first['se']), n_obs=as.integer(N)),
 list(term='effective_shocks', estimate=1/sum(ind$s^2), se=NULL, n_obs=as.integer(N)))
write_json(list(task_id='applied_shift_share', platform='r', estimates=rows,
 method_metadata=list(estimator='Weighted 2SLS; shock-level aggregated IV', vcov='Shock-level HC1 with structural IV residuals and analytic weights; multiplier N/(N-2)'),
 diagnostics=list(regions=nrow(reg), industries=N, share_sum_max_error=max(abs(vapply(byr,function(a) sum(a$share),numeric(1))-1)),
 effect_regional_identity_error=unname(abs(eff['slope']-reg_iv)), first_stage_regional_identity_error=unname(abs(first['slope']-reg_fs)))),
 'result.json', auto_unbox=TRUE, pretty=TRUE, digits=16, null='null')
cat(sprintf('regions=%d industries=%d effect=%.12g se=%.12g first_stage=%.12g se=%.12g effective=%.12g\n',nrow(reg),N,eff[1],eff[2],first[1],first[2],1/sum(ind$s^2)))
