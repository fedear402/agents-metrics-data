#!/usr/bin/env Rscript

input_path <- "input.csv"
output_path <- "result.json"

dat <- read.csv(input_path, stringsAsFactors = FALSE)
if (!all(c("group", "y") %in% names(dat))) {
  stop("input.csv must contain columns named group and y")
}

# Use complete cases for the variables in the requested model.
estimation_data <- dat[complete.cases(dat[, c("group", "y")]), c("group", "y")]
estimation_data$group <- factor(estimation_data$group)
if (nrow(estimation_data) == 0L || nlevels(estimation_data$group) < 2L) {
  stop("The estimation sample must contain observations in at least two groups")
}

fit <- aov(y ~ group, data = estimation_data)
tab <- summary(fit)[[1L]]
f_stat <- unname(tab["group", "F value"])
df_num <- unname(tab["group", "Df"])
df_den <- unname(tab["Residuals", "Df"])
p_value <- unname(tab["group", "Pr(>F)"])
n_obs <- nrow(estimation_data)

if (!all(is.finite(c(f_stat, df_num, df_den, p_value)))) {
  stop("ANOVA returned a non-finite statistic")
}

estimates <- list(
  list(term = "F", estimate = as.numeric(f_stat), se = NULL, n_obs = n_obs),
  list(term = "df_num", estimate = as.numeric(df_num), se = NULL, n_obs = n_obs),
  list(term = "df_den", estimate = as.numeric(df_den), se = NULL, n_obs = n_obs),
  list(term = "p_value", estimate = as.numeric(p_value), se = NULL, n_obs = n_obs)
)

result <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = estimates,
  method_metadata = list(estimator = "one-way ANOVA (aov)", vcov = "classical pooled within-group variance"),
  diagnostics = list(n_input = nrow(dat), n_obs = n_obs, n_dropped = nrow(dat) - n_obs,
                     groups = nlevels(estimation_data$group))
)

json_escape <- function(x) {
  x <- gsub("\\\\", "\\\\\\\\", x)
  x <- gsub('"', '\\\\"', x)
  x <- gsub("\n", "\\\\n", x, fixed = TRUE)
  x
}
json_number <- function(x) {
  if (is.null(x)) return("null")
  format(x, digits = 17, scientific = TRUE, trim = TRUE)
}
estimate_json <- vapply(estimates, function(e) {
  sprintf('{"term":"%s","estimate":%s,"se":null,"n_obs":%d}',
          json_escape(e$term), json_number(e$estimate), e$n_obs)
}, character(1))
json <- paste0(
  '{\n  "task_id": "anova_oneway",\n',
  '  "platform": "r",\n',
  '  "estimates": [\n    ', paste(estimate_json, collapse = ",\n    "), '\n  ],\n',
  '  "method_metadata": {"estimator": "one-way ANOVA (aov)", "vcov": "classical pooled within-group variance"},\n',
  sprintf('  "diagnostics": {"n_input": %d, "n_obs": %d, "n_dropped": %d, "groups": %d}\n',
          nrow(dat), n_obs, nrow(dat) - n_obs, nlevels(estimation_data$group)),
  '}\n'
)
writeLines(json, output_path, useBytes = TRUE)
