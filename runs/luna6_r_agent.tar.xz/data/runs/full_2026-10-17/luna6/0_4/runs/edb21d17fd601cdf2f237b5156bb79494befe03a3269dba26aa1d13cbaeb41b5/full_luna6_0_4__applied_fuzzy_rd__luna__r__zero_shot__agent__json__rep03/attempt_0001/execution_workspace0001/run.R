d <- read.csv("input.csv")
d <- d[abs(d$score) < 1, ]
n <- nrow(d)
x <- d$score
z <- as.numeric(x >= 0)
w <- 1 - abs(x)
X <- cbind(1, x, z, z * x)
Y <- cbind(earnings = d$earnings, participated = d$participated)
XtWX <- crossprod(X, X * w)
B <- solve(XtWX)
coef <- B %*% crossprod(X, Y * w)
res <- Y - X %*% coef

# HC0 covariance, including the cross-outcome covariance from shared rows.
V <- array(0, c(ncol(X), ncol(X), ncol(Y), ncol(Y)))
for (a in seq_len(ncol(Y))) for (b in seq_len(ncol(Y))) {
  meat <- crossprod(X, X * (w^2 * res[, a] * res[, b]))
  V[, , a, b] <- B %*% meat %*% B
}
disc <- c(coef[3, 1], coef[3, 2])
S <- matrix(c(V[3,3,1,1], V[3,3,1,2], V[3,3,2,1], V[3,3,2,2]), 2, 2)
rf <- disc[1]
fs <- disc[2]
te <- rf / fs
g <- c(1 / fs, -rf / fs^2)
se_te <- sqrt(drop(t(g) %*% S %*% g))
se_rf <- sqrt(S[1,1])
se_fs <- sqrt(S[2,2])

# Independent point-estimate check: fit each side's weighted line separately.
side_fit <- function(y, side) {
  ii <- which(z == side)
  lm.wfit(cbind(1, x[ii]), y[ii], w[ii])$coefficients[1]
}
rf_check <- side_fit(d$earnings, 1) - side_fit(d$earnings, 0)
fs_check <- side_fit(d$participated, 1) - side_fit(d$participated, 0)
stopifnot(abs(rf - rf_check) < 1e-10, abs(fs - fs_check) < 1e-10)

# Independent delta-variance check using the explicit covariance cross term.
var_te_check <- S[1,1]/fs^2 + rf^2*S[2,2]/fs^4 - 2*rf*S[1,2]/fs^3
stopifnot(abs(se_te^2 - var_te_check) < 1e-12)

out <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = unname(te), se = unname(se_te), n_obs = n),
    list(term = "reduced_form", estimate = unname(rf), se = unname(se_rf), n_obs = n),
    list(term = "first_stage", estimate = unname(fs), se = unname(se_fs), n_obs = n)
  ),
  method_metadata = list(estimator = "Fuzzy RD: ratio of weighted local-linear discontinuities, triangular weights, bandwidth 1", vcov = "HC0 sandwich; joint outcome covariance with delta method; fixed bandwidth and weights"),
  diagnostics = list(n_left = sum(x < 0), n_right = sum(x >= 0), rf_independent_check = unname(rf_check), fs_independent_check = unname(fs_check), covariance_rf_fs = unname(S[1,2]))
)
jsonlite::write_json(out, "result.json", auto_unbox = TRUE, digits = 15, pretty = TRUE, null = "null")
