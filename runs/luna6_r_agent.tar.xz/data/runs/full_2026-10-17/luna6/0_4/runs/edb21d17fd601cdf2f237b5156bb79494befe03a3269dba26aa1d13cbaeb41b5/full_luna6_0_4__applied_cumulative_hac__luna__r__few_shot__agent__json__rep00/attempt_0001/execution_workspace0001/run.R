d <- read.csv('input.csv', stringsAsFactors=FALSE)
d$date <- as.Date(d$date)
d <- d[order(d$date), ]
stopifnot(all(is.finite(d$sales)), all(d$sales > 0), all(d$vix > 0))
d$dv <- c(NA_real_, diff(log(d$vix)))
for (j in 1:15) d[[paste0('lag_', j)]] <- c(rep(NA_real_,j+1), head(d$dv, -j-1))
vars <- paste0('lag_',1:15)
s <- d[complete.cases(d[,c('sales', vars)]),]
s$log_sales <- log(s$sales)
fit <- lm(reformulate(vars, 'log_sales'), data=s)
X <- model.matrix(fit); e <- residuals(fit); b <- coef(fit); N <- nrow(X); p <- ncol(X)
u <- X*e
meat <- crossprod(u)
for(j in 1:15) { G <- crossprod(u[(j+1):N,,drop=FALSE],u[1:(N-j),,drop=FALSE]); meat <- meat+(1-j/16)*(G+t(G)) }
V <- N/(N-16) * solve(crossprod(X)) %*% meat %*% solve(crossprod(X))
c <- c(0,rep(1,15))
rows <- list(
 list(term='cumulative_response',estimate=unname(sum(b[-1])),se=unname(sqrt(drop(t(c)%*%V%*%c))),n_obs=N),
 list(term='lag_1',estimate=unname(b['lag_1']),se=unname(sqrt(V['lag_1','lag_1'])),n_obs=N),
 list(term='lag_15',estimate=unname(b['lag_15']),se=unname(sqrt(V['lag_15','lag_15'])),n_obs=N))
out <- list(task_id='applied_cumulative_hac',platform='r',estimates=rows,method_metadata=list(estimator='OLS',vcov='Newey-West Bartlett HAC, max lag 15, scaled by N/(N-16)'),diagnostics=list(total_observations=nrow(d),regression_observations=N,parameter_count=p,first_date=as.character(min(s$date)),last_date=as.character(max(s$date))))
jsonlite::write_json(out,'result.json',auto_unbox=TRUE, pretty=TRUE,digits=16)
cat('N=',N,' p=',p,'\n'); print(b); print(V)
