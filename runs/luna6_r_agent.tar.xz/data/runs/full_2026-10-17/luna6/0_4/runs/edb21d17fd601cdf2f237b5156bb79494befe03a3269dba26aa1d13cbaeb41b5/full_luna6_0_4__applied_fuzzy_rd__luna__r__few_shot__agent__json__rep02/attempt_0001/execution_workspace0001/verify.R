d <- read.csv("input.csv")
d <- d[abs(d$score) < 1, , drop = FALSE]
x <- d$score
r <- as.numeric(x >= 0)
w <- 1 - abs(x)
# Independent check: lm with explicit side-specific regressors and case weights.
fit_y <- lm(earnings ~ 0 + I(1-r) + I((1-r)*x) + I(r) + I(r*x), data = transform(d, x=x, r=r), weights=w)
fit_p <- lm(participated ~ 0 + I(1-r) + I((1-r)*x) + I(r) + I(r*x), data = transform(d, x=x, r=r), weights=w)
get_X <- function() cbind(1-r, (1-r)*x, r, r*x)
X <- get_X()
C <- c(-1, 0, 1, 0)
# lm's weighted residuals are unweighted residuals; HC0 score includes w_i.
resid_y <- residuals(fit_y)
resid_p <- residuals(fit_p)
G <- solve(crossprod(X, w*X))
score_y <- X * (w*resid_y)
score_p <- X * (w*resid_p)
Vyp <- G %*% crossprod(score_y, score_p) %*% G
cov_check <- drop(t(C) %*% Vyp %*% C)
jump_y <- drop(C %*% coef(fit_y))
jump_p <- drop(C %*% coef(fit_p))
cat(sprintf("n_obs=%d\n", nrow(d)))
cat(sprintf("lm reduced_form=%.15g\n", jump_y))
cat(sprintf("lm first_stage=%.15g\n", jump_p))
cat(sprintf("lm ratio=%.15g\n", jump_y/jump_p))
cat(sprintf("cross-outcome HC0 covariance=%.15g\n", cov_check))
