library(forecast)
library(jsonlite)

dat <- read.csv("./input.csv")
stopifnot(identical(names(dat), c("t", "y")), nrow(dat) == 250L,
          identical(dat$t, seq_len(250L)), all(is.finite(dat$y)))
y <- ts(dat$y, start = 1, frequency = 1)
fit <- Arima(y, order = c(1, 1, 1), include.mean = FALSE,
             include.drift = FALSE, method = "ML")
fc <- forecast(fit, h = 1, level = 95)
vals <- c(forecast = as.numeric(fc$mean[1]),
          lower_95 = as.numeric(fc$lower[1, 1]),
          upper_95 = as.numeric(fc$upper[1, 1]))
n <- length(y)
out <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = lapply(names(vals), function(term) list(
    term = term, estimate = unname(vals[[term]]), se = NULL,
    n_obs = n
  )),
  method_metadata = list(estimator = "ARIMA(1,1,1) by maximum likelihood, no constant or drift",
                         vcov = "model-based Gaussian one-step prediction interval"),
  diagnostics = structure(list(), names = character(0))
)
write_json(out, "result.json", auto_unbox = TRUE, digits = 15, null = "null")
