data <- read.csv("input.csv")
sample <- data[abs(data$score) < 1, ]
n <- nrow(sample)
x <- sample$score
right <- as.numeric(x >= 0)
w <- 1 - abs(x)

# Separate local-linear intercepts and slopes on the two sides.
X <- cbind(left_intercept = 1 - right,
           left_slope = x * (1 - right),
           right_intercept = right,
           right_slope = x * right)
Y <- cbind(earnings = sample$earnings,
           participated = sample$participated)

bread <- solve(crossprod(X, w * X))
beta <- bread %*% crossprod(X, w * Y)
resid <- Y - X %*% beta

# Right limit minus left limit, selected from the two intercepts.
contrast <- c(-1, 0, 1, 0)
jumps <- drop(contrast %*% beta)
loading <- w * drop(X %*% bread %*% contrast)
influence <- loading * resid
joint_vcov <- crossprod(influence)
ses <- sqrt(diag(joint_vcov))

reduced_form <- jumps["earnings"]
first_stage <- jumps["participated"]
effect <- reduced_form / first_stage
gradient <- c(1 / first_stage, -reduced_form / first_stage^2)
effect_se <- sqrt(drop(t(gradient) %*% joint_vcov %*% gradient))

row <- function(term, estimate, se) {
  list(term = term, estimate = unname(as.numeric(estimate)),
       se = unname(as.numeric(se)), n_obs = as.integer(n))
}
result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    row("treatment_effect", effect, effect_se),
    row("reduced_form", reduced_form, ses["earnings"]),
    row("first_stage", first_stage, ses["participated"])
  ),
  method_metadata = list(estimator = "Triangular-weighted local-linear fuzzy regression discontinuity",
                         vcov = "HC0, fixed bandwidth and weights, no degrees-of-freedom correction"),
  diagnostics = list(n_obs = as.integer(n), bandwidth = 1,
                     cutoff = 0, weight = "1 - abs(score)",
                     joint_covariance = unname(joint_vcov[1, 2]))
)
jsonlite::write_json(result, "result.json", auto_unbox = TRUE,
                     null = "null", digits = 16, pretty = TRUE)
