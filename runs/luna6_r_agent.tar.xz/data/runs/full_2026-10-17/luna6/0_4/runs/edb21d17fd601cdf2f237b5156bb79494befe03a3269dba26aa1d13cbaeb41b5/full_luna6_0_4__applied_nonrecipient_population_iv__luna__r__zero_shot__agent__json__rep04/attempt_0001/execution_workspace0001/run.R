suppressPackageStartupMessages(library(jsonlite))

h <- read.csv("households.csv", stringsAsFactors = FALSE)
c <- read.csv("census.csv", stringsAsFactors = FALSE)

# Keep every nonrecipient household across both village treatment statuses.
d <- h[h$recipient == 0, , drop = FALSE]
if (nrow(d) == 0L) stop("No nonrecipient households found")
if (!all(c(0, 1) %in% d$eligible)) stop("Both eligibility groups must be represented")
if (any(!is.finite(d$weight) | d$weight <= 0)) stop("Estimation weights must be positive and finite")

E0 <- 1 - d$eligible
E1 <- d$eligible
X <- cbind(E0, E1, d$baseline * E0, d$baseline * E1,
           d$dose * E0, d$dose * E1)
Z <- cbind(E0, E1, d$baseline * E0, d$baseline * E1,
           d$instrument * E0, d$instrument * E1)
w <- d$weight
y <- d$outcome

# Weighted 2SLS: (X'WZ (Z'WZ)^-1 Z'WX)^-1 X'WZ (Z'WZ)^-1 Z'Wy.
wz <- Z * w
A <- crossprod(X, wz) %*% solve(crossprod(Z, wz), crossprod(Z, w * X))
b <- solve(A, crossprod(X, wz) %*% solve(crossprod(Z, wz), crossprod(Z, w * y)))
b <- as.vector(b)
if (any(!is.finite(b))) stop("Non-finite 2SLS coefficients")

slope_ineligible <- b[5]
slope_eligible <- b[6]
mean_dose <- vapply(0:1, function(g) {
  ix <- d$eligible == g
  sum(d$dose[ix] * d$weight[ix]) / sum(d$weight[ix])
}, numeric(1))
ineligible_effect <- slope_ineligible * mean_dose[1]
eligible_nonrecipient_effect <- slope_eligible * mean_dose[2]

pop <- c[match(0:1, c$eligible), "nonrecipient_population"]
if (anyNA(pop) || any(!is.finite(pop)) || any(pop < 0) || sum(pop) <= 0) stop("Invalid census population counts")
population_effect <- sum(c(ineligible_effect, eligible_nonrecipient_effect) * pop) / sum(pop)
n <- nrow(d)

estimates <- list(
  list(term = "ineligible_effect", estimate = unname(ineligible_effect), se = NULL, n_obs = n),
  list(term = "eligible_nonrecipient_effect", estimate = unname(eligible_nonrecipient_effect), se = NULL, n_obs = n),
  list(term = "population_effect", estimate = unname(population_effect), se = NULL, n_obs = n)
)
result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "weighted 2SLS",
    sample_rule = "all household rows with recipient equal to zero, including both village treatment statuses",
    endogenous_columns = c("dose*(1-eligible)", "dose*eligible"),
    exogenous_columns = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"),
    instrument_columns = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible", "instrument*(1-eligible)", "instrument*eligible"),
    regression_weight = "weight",
    group_mean_weight = "weight",
    counterfactual = "dose set to zero for every retained household; attribution is a stated synthetic convention",
    population_weight_source = "census.csv nonrecipient_population, used only for final between-group aggregation",
    n_obs = n
  ),
  diagnostics = list(
    n_nonrecipient = n,
    n_ineligible = sum(d$eligible == 0),
    n_eligible = sum(d$eligible == 1),
    n_treated_status_0 = sum(d$treated == 0),
    n_treated_status_1 = sum(d$treated == 1),
    weighted_mean_dose_ineligible = unname(mean_dose[1]),
    weighted_mean_dose_eligible = unname(mean_dose[2]),
    slope_ineligible = unname(slope_ineligible),
    slope_eligible = unname(slope_eligible),
    census_nonrecipient_population_ineligible = unname(pop[1]),
    census_nonrecipient_population_eligible = unname(pop[2])
  )
)
write_json(result, "result.json", auto_unbox = TRUE, digits = 17, null = "null", pretty = TRUE)
