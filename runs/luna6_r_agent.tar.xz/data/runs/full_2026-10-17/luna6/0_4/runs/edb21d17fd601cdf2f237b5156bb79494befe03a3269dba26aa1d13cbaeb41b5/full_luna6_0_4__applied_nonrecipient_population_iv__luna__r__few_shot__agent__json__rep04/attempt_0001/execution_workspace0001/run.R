# Weighted 2SLS among all nonrecipient households.
households <- read.csv("households.csv")
census <- read.csv("census.csv")

required_household <- c("eligible", "recipient", "instrument", "dose", "baseline", "weight", "outcome")
stopifnot(all(required_household %in% names(households)))
stopifnot(all(c("eligible", "nonrecipient_population") %in% names(census)))

d <- subset(households, recipient == 0)
stopifnot(nrow(d) == 300L, all(d$weight > 0))
g0 <- 1 - d$eligible
g1 <- d$eligible

# The two eligibility-specific slopes use group-specific exogenous controls and instruments.
X <- cbind(g0, g1, d$baseline * g0, d$baseline * g1,
           d$dose * g0, d$dose * g1)
Z <- cbind(g0, g1, d$baseline * g0, d$baseline * g1,
           d$instrument * g0, d$instrument * g1)
w <- d$weight
sw <- sqrt(w)
Xw <- X * sw
Zw <- Z * sw
yw <- d$outcome * sw

# Weighted 2SLS via weighted projections, with no additional intercept.
PZX <- qr.fitted(qr(Zw), Xw)
beta <- as.numeric(qr.coef(qr(PZX), yw))
stopifnot(length(beta) == ncol(X), all(is.finite(beta)))

slope_ineligible <- beta[5]
slope_eligible <- beta[6]
mean_dose <- vapply(0:1, function(g) {
  a <- d$eligible == g
  weighted.mean(d$dose[a], w[a])
}, numeric(1))
effects <- c(ineligible_effect = slope_ineligible * mean_dose[1],
             eligible_nonrecipient_effect = slope_eligible * mean_dose[2])
counts <- vapply(0:1, function(g) sum(d$eligible == g), integer(1))
stopifnot(identical(unname(counts), c(120L, 180L)))

pop <- census$nonrecipient_population[match(0:1, census$eligible)]
stopifnot(!anyNA(pop), sum(pop) > 0)
population_effect <- weighted.mean(effects, pop)
estimates <- list(
  list(term = "ineligible_effect", estimate = unname(effects[1]), se = NULL, n_obs = as.integer(nrow(d))),
  list(term = "eligible_nonrecipient_effect", estimate = unname(effects[2]), se = NULL, n_obs = as.integer(nrow(d))),
  list(term = "population_effect", estimate = unname(population_effect), se = NULL, n_obs = as.integer(nrow(d)))
)
result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "weighted 2SLS",
    sample = "all households with recipient == 0, across both village treatment statuses",
    endogenous_columns = c("dose*(1-eligible)", "dose*eligible"),
    exogenous_columns = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"),
    instruments = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible", "instrument*(1-eligible)", "instrument*eligible"),
    weighting = "household weight used as regression weight and within-group dose averaging",
    counterfactual = "dose is set to zero for every retained household; attribution to this counterfactual is a stated synthetic convention",
    aggregation_weights = "census nonrecipient_population, used only for final between-group aggregation",
    uncertainty = "standard errors not requested; se is null"
  ),
  diagnostics = list(
    n_obs = as.integer(nrow(d)),
    group_n_obs = list(ineligible = as.integer(counts[1]), eligible_nonrecipient = as.integer(counts[2])),
    weighted_mean_dose = list(ineligible = unname(mean_dose[1]), eligible_nonrecipient = unname(mean_dose[2])),
    group_dose_slopes = list(ineligible = unname(slope_ineligible), eligible_nonrecipient = unname(slope_eligible)),
    census_nonrecipient_population = list(ineligible = as.integer(pop[1]), eligible = as.integer(pop[2]))
  )
)
jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = 16, null = "null", pretty = TRUE)
