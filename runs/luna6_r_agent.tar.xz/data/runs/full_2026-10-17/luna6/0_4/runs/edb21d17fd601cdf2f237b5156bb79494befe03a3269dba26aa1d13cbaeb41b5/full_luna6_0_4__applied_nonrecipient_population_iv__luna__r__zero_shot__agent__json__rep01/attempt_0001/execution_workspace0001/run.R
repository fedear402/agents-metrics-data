suppressPackageStartupMessages(library(jsonlite))
h <- read.csv("households.csv", stringsAsFactors = FALSE)
c <- read.csv("census.csv", stringsAsFactors = FALSE)

# Retain every nonrecipient household, including households in treated villages.
d <- h[h$recipient == 0, , drop = FALSE]
n_obs <- nrow(d)
if (n_obs == 0L) stop("No nonrecipient households found")

z0 <- 1 - d$eligible
z1 <- d$eligible
# X has no additional intercept. Z contains the four included exogenous columns
# and the two eligibility-specific excluded instruments.
X <- cbind(ineligible = z0,
           eligible = z1,
           baseline_ineligible = d$baseline * z0,
           baseline_eligible = d$baseline * z1)
Z <- cbind(X,
           instrument_ineligible = d$instrument * z0,
           instrument_eligible = d$instrument * z1)
D <- cbind(dose_ineligible = d$dose * z0,
           dose_eligible = d$dose * z1)
Y <- d$outcome
w <- d$weight

# Weighted 2SLS: beta = (D'W Pz D)^(-1) D'W Pz Y,
# where Pz is the projection onto the columns of Z in the W metric.
sqrtw <- sqrt(w)
Zw <- Z * sqrtw
Dw <- D * sqrtw
Yw <- Y * sqrtw
qz <- qr(Zw)
if (qz$rank != ncol(Z)) stop("Instrument matrix is rank deficient")
Dhatw <- qr.fitted(qz, Dw)
Yhatw <- qr.fitted(qz, Yw)
A <- crossprod(Dhatw)
b <- crossprod(Dhatw, Yhatw)
if (qr(A)$rank != ncol(A)) stop("2SLS normal matrix is rank deficient")
beta <- solve(A, b)

# Weighted household means within each eligibility group.
weighted_mean <- function(x, weight) sum(x * weight) / sum(weight)
idx0 <- d$eligible == 0
idx1 <- d$eligible == 1
mean_dose_ineligible <- weighted_mean(d$dose[idx0], w[idx0])
mean_dose_eligible <- weighted_mean(d$dose[idx1], w[idx1])
ineligible_effect <- as.numeric(beta[1, 1] * mean_dose_ineligible)
eligible_nonrecipient_effect <- as.numeric(beta[2, 1] * mean_dose_eligible)

# Census counts enter only here, as final between-group aggregation weights.
if (!all(c(0, 1) %in% c$eligible)) stop("Census must contain both eligibility groups")
pop0 <- c$nonrecipient_population[match(0, c$eligible)]
pop1 <- c$nonrecipient_population[match(1, c$eligible)]
if (anyNA(c(pop0, pop1)) || sum(c(pop0, pop1)) <= 0) stop("Invalid census weights")
population_effect <- (pop0 * ineligible_effect + pop1 * eligible_nonrecipient_effect) / (pop0 + pop1)

estimates <- list(
  list(term = "ineligible_effect", estimate = ineligible_effect, se = NULL, n_obs = as.integer(n_obs)),
  list(term = "eligible_nonrecipient_effect", estimate = eligible_nonrecipient_effect, se = NULL, n_obs = as.integer(n_obs)),
  list(term = "population_effect", estimate = population_effect, se = NULL, n_obs = as.integer(n_obs))
)
result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "weighted 2SLS",
    sample = "all households with recipient = 0",
    endogenous_columns = c("dose*(1-eligible)", "dose*eligible"),
    exogenous_columns = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"),
    instrument_columns = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible", "instrument*(1-eligible)", "instrument*eligible"),
    regression_weight = "weight",
    within_group_mean = "household-weighted mean dose among retained observations in group",
    counterfactual = "dose set to zero for every retained household; attribution is a stated synthetic convention",
    population_weights = "nonrecipient_population from census.csv, used only for final between-group aggregation"
  ),
  diagnostics = list(
    n_obs = as.integer(n_obs),
    n_ineligible = as.integer(sum(idx0)),
    n_eligible = as.integer(sum(idx1)),
    n_treated_village_nonrecipients = as.integer(sum(d$treated == 1)),
    n_untreated_village_nonrecipients = as.integer(sum(d$treated == 0)),
    weighted_mean_dose_ineligible = mean_dose_ineligible,
    weighted_mean_dose_eligible = mean_dose_eligible,
    dose_slope_ineligible = as.numeric(beta[1, 1]),
    dose_slope_eligible = as.numeric(beta[2, 1]),
    census_population_ineligible = as.integer(pop0),
    census_population_eligible = as.integer(pop1),
    census_population_total = as.integer(pop0 + pop1)
  )
)
write_json(result, "result.json", auto_unbox = TRUE, pretty = TRUE, digits = 17, null = "null")
