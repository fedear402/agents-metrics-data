dat <- read.csv("input.csv", stringsAsFactors = FALSE)
dat$date <- as.Date(dat$date)
dat <- dat[order(dat$date), ]
stopifnot(nrow(dat) > 16L, all(is.finite(dat$sales)), all(dat$sales > 0),
          all(is.finite(dat$vix)), all(dat$vix > 0))

# First log change, then form trading-observation lags before dropping NAs.
dvix <- c(NA_real_, diff(log(dat$vix)))
design <- data.frame(y = log(dat$sales))
for (j in 1:15) design[[paste0("lag_", j)]] <- c(rep(NA_real_, j), dvix[seq_len(length(dvix) - j)])
sample <- design[complete.cases(design), , drop = FALSE]
fit <- lm(y ~ ., data = sample)
N <- nrow(sample)
stopifnot(N > 16L, nobs(fit) == N)

# Bartlett HAC meat at lags 0,...,15, with the requested finite sample scale.
X <- model.matrix(fit)
u <- residuals(fit)
bread <- solve(crossprod(X))
score <- X * as.vector(u)
meat <- crossprod(score)
for (j in 1:15) {
  gamma <- crossprod(score[(j + 1):N, , drop = FALSE], score[1:(N - j), , drop = FALSE])
  meat <- meat + (1 - j / 16) * (gamma + t(gamma))
}
V <- (N / (N - 16)) * bread %*% meat %*% bread
beta <- coef(fit)
terms <- c("cumulative_response", "lag_1", "lag_15")
lag_names <- paste0("lag_", 1:15)
a <- setNames(rep(0, length(beta)), names(beta))
a[lag_names] <- 1
cum_est <- sum(beta[lag_names])
cum_se <- sqrt(drop(t(a) %*% V %*% a))
estimates <- list(
  list(term = terms[1], estimate = unname(cum_est), se = unname(cum_se), n_obs = as.integer(N)),
  list(term = terms[2], estimate = unname(beta["lag_1"]), se = unname(sqrt(V["lag_1", "lag_1"])), n_obs = as.integer(N)),
  list(term = terms[3], estimate = unname(beta["lag_15"]), se = unname(sqrt(V["lag_15", "lag_15"])), n_obs = as.integer(N))
)
if (!requireNamespace("jsonlite", quietly = TRUE)) stop("jsonlite is required to write result.json")
result <- list(task_id = "applied_cumulative_hac", platform = "r", estimates = estimates,
               method_metadata = list(estimator = "OLS with intercept and trading-observation lags 1-15 of first difference in log(vix)",
                                      vcov = "Newey-West HAC, Bartlett weights through lag 15, multiplied by N/(N-16)"),
               diagnostics = list(input_rows = nrow(dat), first_valid_row = 17L, n_obs = N,
                                  sample_first_date = as.character(dat$date[17]),
                                  sample_last_date = as.character(dat$date[nrow(dat)]),
                                  rank = as.integer(fit$rank)))
jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = 16, pretty = TRUE, na = "null")

# Save independent checks for verification.txt.
writeLines(capture.output({
  cat("Independent calculation: sandwich::NeweyWest plus linear-combination check\n")
  V2 <- sandwich::NeweyWest(fit, lag = 15, prewhite = FALSE, adjust = FALSE)
  V2 <- V2 * N / (N - 16)
  cat(sprintf("Max absolute covariance difference (manual vs sandwich): %.12g\n", max(abs(V - V2))))
  cat(sprintf("Cumulative estimate via sum(beta) vs contrast: %.12g vs %.12g\n", cum_est, sum(drop(a * beta))))
  cat(sprintf("Cumulative SE via full covariance vs quadratic form: %.12g vs %.12g\n", cum_se, sqrt(drop(t(a) %*% V2 %*% a))))
  cat(sprintf("Rows=%d, complete lag sample=%d, first date=%s, last date=%s\n", nrow(dat), N, dat$date[17], dat$date[nrow(dat)]))
  cat(sprintf("First lag equals dlog(vix)[t-1]: %.12g\n", sample$lag_1[1] - (log(dat$vix[16]) - log(dat$vix[15]))))
  cat(sprintf("Fifteenth lag equals dlog(vix)[t-15]: %.12g\n", sample$lag_15[1] - (log(dat$vix[2]) - log(dat$vix[1]))))
}), "verification.txt")
