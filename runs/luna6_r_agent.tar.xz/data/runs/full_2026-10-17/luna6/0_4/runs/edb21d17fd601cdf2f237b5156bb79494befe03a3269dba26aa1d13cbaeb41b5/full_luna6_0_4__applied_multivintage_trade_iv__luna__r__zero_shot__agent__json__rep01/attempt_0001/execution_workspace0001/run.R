suppressPackageStartupMessages(library(jsonlite))

crosswalk <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
trade <- read.csv("trade.csv", stringsAsFactors = FALSE)
areas <- read.csv("areas.csv", stringsAsFactors = FALSE)
employment <- read.csv("employment.csv", stringsAsFactors = FALSE)
outcomes <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

trade <- merge(trade, crosswalk, by = "code", all = FALSE)
stopifnot(nrow(trade) == nrow(read.csv("trade.csv")))
stopifnot(all(table(trade$period, trade$industry) == 1L))
stopifnot(all(table(crosswalk$code) == 1L))

# Add omitted area-industry cells as zero, then form national denominators.
keys <- unique(areas[c("area", "period", "vintage")])
industries <- sort(unique(crosswalk$industry))
full <- merge(keys, data.frame(industry = industries), by = NULL)
emp <- merge(full, employment, by = c("area", "period", "vintage", "industry"), all.x = TRUE)
emp$employment[is.na(emp$employment)] <- 0
national <- aggregate(employment ~ period + vintage + industry, emp, sum)

trade$base_emp <- national$employment[match(paste(trade$period, "base", trade$industry), paste(national$period, national$vintage, national$industry))]
trade$early_emp <- national$employment[match(paste(trade$period, "early", trade$industry), paste(national$period, national$vintage, national$industry))]
stopifnot(all(is.finite(trade$base_emp)), all(trade$base_emp > 0), all(is.finite(trade$early_emp)), all(trade$early_emp > 0))

make_exposure <- function(vintage, change_col) {
  a <- areas[areas$vintage == vintage, ]
  e <- emp[emp$vintage == vintage, ]
  t <- trade
  t$trade_piece <- t[[change_col]] / t[[paste0(vintage, "_emp")]] /
    (t$price_index / 100) / 1000 * (10 / t$years)
  e <- merge(e, t[c("period", "industry", "trade_piece")], by = c("period", "industry"), all.x = TRUE)
  e$weighted_piece <- e$employment * e$trade_piece
  sums <- aggregate(weighted_piece ~ area + period + vintage, e, sum)
  denom <- setNames(a$total_employment, paste(a$area, a$period))
  sums$exposure <- (sums$weighted_piece / denom[paste(sums$area, sums$period)])
  sums[c("area", "period", "exposure")]
}

x <- make_exposure("base", "us_change")
z <- make_exposure("early", "other_change")
reg <- merge(outcomes, areas[areas$vintage == "base", c("area", "period", "population")], by = c("area", "period"), all = FALSE)
reg <- merge(reg, x, by = c("area", "period"), all = FALSE)
reg <- merge(reg, z, by = c("area", "period"), all = FALSE, suffixes = c("_x", "_z"))
reg <- reg[order(reg$area, reg$period), ]
stopifnot(nrow(reg) == 72L, !anyNA(reg), all(reg$population > 0))

# Weighted 2SLS: included exogenous variables instrument themselves, plus z for x.
Y <- as.matrix(reg$change_pp)
X <- cbind(intercept = 1, period = reg$period, control = reg$control, x = reg$exposure_x)
Q <- cbind(intercept = 1, period = reg$period, control = reg$control, z = reg$exposure_z)
w <- reg$population
sw <- sqrt(w)
Xw <- X * sw
Qw <- Q * sw
Yw <- Y * sw
PqX <- Qw %*% solve(crossprod(Qw), crossprod(Qw, Xw))
beta <- solve(crossprod(Xw, PqX), crossprod(Xw, Qw) %*% solve(crossprod(Qw), crossprod(Qw, Yw)))

coef <- as.numeric(beta["x", 1])
x00 <- x$exposure[x$area == 0 & x$period == 0]
x01 <- x$exposure[x$area == 0 & x$period == 1]
z00 <- z$exposure[z$area == 0 & z$period == 0]
stopifnot(length(x00) == 1L, length(x01) == 1L, length(z00) == 1L)

estimates <- list(
  list(term = "iv_slope", estimate = coef, se = NULL, n_obs = 72L),
  list(term = "exposure_area0_period0", estimate = x00, se = NULL, n_obs = 72L),
  list(term = "exposure_area0_period1", estimate = x01, se = NULL, n_obs = 72L),
  list(term = "instrument_area0_period0", estimate = z00, se = NULL, n_obs = 72L)
)
result <- list(task_id = "applied_multivintage_trade_iv", platform = "r", estimates = estimates,
               method_metadata = list(estimator = "weighted 2SLS", regressors = c("intercept", "period", "control", "x"),
                                      instruments = c("intercept", "period", "control", "z"),
                                      weight = "base-vintage population", exposure_units = "thousands of real dollars per worker per decade",
                                      outcome_units = "decadal percentage points"),
               diagnostics = list(n_obs = 72L))
write_json(result, "result.json", auto_unbox = TRUE, pretty = TRUE, digits = 17, null = "null")
