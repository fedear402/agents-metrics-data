suppressPackageStartupMessages(library(jsonlite))

crosswalk <- read.csv('crosswalk.csv', stringsAsFactors=FALSE)
trade <- read.csv('trade.csv', stringsAsFactors=FALSE)
areas <- read.csv('areas.csv', stringsAsFactors=FALSE)
employment <- read.csv('employment.csv', stringsAsFactors=FALSE)
outcomes <- read.csv('outcomes.csv', stringsAsFactors=FALSE)

# Map each trade code to its industry, then sum trade changes by period and industry.
trade <- merge(trade, crosswalk, by='code', all.x=TRUE, sort=FALSE)
stopifnot(!anyNA(trade$industry), !anyDuplicated(trade[c('period','industry')]))

# The complete area-period-vintage frame supplies zero for omitted employment cells.
emp <- merge(areas[c('area','period','vintage')],
             expand.grid(industry=sort(unique(crosswalk$industry))),
             by=NULL, sort=FALSE)
emp <- merge(emp, employment, by=c('area','period','vintage','industry'), all.x=TRUE, sort=FALSE)
emp$employment[is.na(emp$employment)] <- 0

# National denominators sum the supplied areas for each period and vintage.
national <- aggregate(employment ~ period + vintage + industry, emp, sum)
base_emp <- subset(emp, vintage=='base')
early_emp <- subset(emp, vintage=='early')
base_den <- subset(national, vintage=='base')[c('period','industry','employment')]
names(base_den)[3] <- 'national_employment'
early_den <- subset(national, vintage=='early')[c('period','industry','employment')]
names(early_den)[3] <- 'national_employment'

make_exposure <- function(local_emp, national_den, change_col) {
  x <- merge(local_emp, national_den, by=c('period','industry'))
  area_totals <- subset(areas, vintage==unique(local_emp$vintage))[c('area','period','total_employment')]
  x <- merge(x, area_totals, by=c('area','period'))
  names(x)[names(x)=='total_employment'] <- 'area_total_employment'
  x <- merge(x, trade[c('period','industry','price_index','years',change_col)], by=c('period','industry'))
  x$component <- (x$employment / x$area_total_employment) * (x[[change_col]] / x$national_employment) /
    (x$price_index/100) / 1000 * (10/x$years)
  aggregate(component ~ area + period, x, sum)
}
x <- make_exposure(base_emp, base_den, 'us_change')
z <- make_exposure(early_emp, early_den, 'other_change')
names(x)[3] <- 'x'
names(z)[3] <- 'z'

# Join the 72 outcome rows to area-period exposures and base-vintage weights.
base_weights <- subset(areas, vintage=='base')[c('area','period','population')]
reg <- Reduce(function(a,b) merge(a,b,by=c('area','period'),all=FALSE,sort=FALSE),
              list(outcomes, x, z, base_weights))
reg <- reg[order(reg$period,reg$area),]
stopifnot(nrow(reg)==72L, !anyNA(reg[c('change_pp','control','x','z','population')]))

# Weighted 2SLS: project all regressors on all instruments, then regress y on projections.
C <- cbind(intercept=1, period=reg$period, control=reg$control)
X <- cbind(C, x=reg$x)
Z <- cbind(C, z=reg$z)
sw <- sqrt(reg$population)
XZ <- qr.fitted(qr(Z*sw), X*sw)
beta <- qr.coef(qr(XZ), reg$change_pp*sw)

estimates <- list(
  list(term='iv_slope', estimate=unname(beta['x']), se=NULL, n_obs=72L),
  list(term='exposure_area0_period0', estimate=unname(x$x[x$area==0 & x$period==0]), se=NULL, n_obs=72L),
  list(term='exposure_area0_period1', estimate=unname(x$x[x$area==0 & x$period==1]), se=NULL, n_obs=72L),
  list(term='instrument_area0_period0', estimate=unname(z$z[z$area==0 & z$period==0]), se=NULL, n_obs=72L)
)
result <- list(task_id='applied_multivintage_trade_iv', platform='r', estimates=estimates,
               method_metadata=list(estimator='weighted 2SLS', outcome='change_pp',
                 regressors=c('intercept','period','control','x'), instruments=c('intercept','period','control','z'),
                 weight='base-vintage population', exposure_units='thousands of real dollars per worker per decade'),
               diagnostics=list(n_obs=72L, area_period_rows=nrow(reg), periods=sort(unique(reg$period)),
                 industries=length(unique(crosswalk$industry))))
write_json(result, 'result.json', auto_unbox=TRUE, digits=16, pretty=TRUE, null='null')
