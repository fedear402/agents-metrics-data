#!/usr/bin/env Rscript

suppressPackageStartupMessages(library(jsonlite))

households <- read.csv("households.csv", stringsAsFactors = FALSE)
census <- read.csv("census.csv", stringsAsFactors = FALSE)

# Keep all nonrecipients, including ineligible households in either village status.
d <- households[households$recipient == 0, , drop = FALSE]
stopifnot(nrow(d) > 0, all(d$weight > 0), all(d$eligible %in% c(0, 1)))

e0 <- 1 - d$eligible
e1 <- d$eligible
X <- cbind(e0, e1, d$baseline * e0, d$baseline * e1,
           d$dose * e0, d$dose * e1)
Z <- cbind(e0, e1, d$baseline * e0, d$baseline * e1,
           d$instrument * e0, d$instrument * e1)

# Weighted 2SLS: (X'W Pz X)^-1 X'W Pz y, with no additional intercept.
sw <- sqrt(d$weight)
Xw <- X * sw
Zw <- Z * sw
yw <- d$outcome * sw
qz <- qr(Zw)
if (qz$rank != ncol(Zw)) stop("Instrument matrix is rank deficient")
Xhat <- qr.fitted(qz, Xw)
fit <- lm.fit(Xhat, yw)
if (fit$rank != ncol(X)) stop("Second-stage design is rank deficient")
beta <- fit$coefficients

group_effect <- vapply(0:1, function(g) {
  idx <- d$eligible == g
  slope <- beta[if (g == 0) 5 else 6]
  slope * weighted.mean(d$dose[idx], d$weight[idx])
}, numeric(1))

pop_counts <- census$nonrecipient_population[match(0:1, census$eligible)]
stopifnot(!anyNA(pop_counts), all(pop_counts >= 0), sum(pop_counts) > 0)
population_effect <- weighted.mean(group_effect, pop_counts)
n_obs <- as.integer(nrow(d))

estimates <- list(
  list(term = "ineligible_effect", estimate = unname(group_effect[1]), se = NULL, n_obs = n_obs),
  list(term = "eligible_nonrecipient_effect", estimate = unname(group_effect[2]), se = NULL, n_obs = n_obs),
  list(term = "population_effect", estimate = unname(population_effect), se = NULL, n_obs = n_obs)
)

result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "weighted two-stage least squares",
    sample = "all household rows with recipient equal to zero",
    endogenous_columns = c("dose*(1-eligible)", "dose*eligible"),
    exogenous_columns = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"),
    instruments = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible", "instrument*(1-eligible)", "instrument*eligible"),
    regression_weight = "weight",
    group_effect = "fitted group dose slope times weighted mean dose among retained observations in that group",
    population_aggregation = "census nonrecipient_population weights",
    counterfactual = "dose set to zero for every retained household; attribution is a stated synthetic convention",
    uncertainty = "standard errors not requested; se is null"
  ),
  diagnostics = list(
    n_obs = n_obs,
    n_ineligible = as.integer(sum(d$eligible == 0)),
    n_eligible = as.integer(sum(d$eligible == 1)),
    instrument_matrix_rank = as.integer(qz$rank),
    second_stage_rank = as.integer(fit$rank),
    census_nonrecipient_population = as.list(setNames(as.integer(pop_counts), c("ineligible", "eligible")))
  )
)
write_json(result, "result.json", auto_unbox = TRUE, digits = 17, pretty = TRUE, null = "null")

cat(sprintf("n_obs=%d\n", n_obs))
cat(sprintf("ineligible_effect=%.12g\n", group_effect[1]))
cat(sprintf("eligible_nonrecipient_effect=%.12g\n", group_effect[2]))
cat(sprintf("population_effect=%.12g\n", population_effect))
