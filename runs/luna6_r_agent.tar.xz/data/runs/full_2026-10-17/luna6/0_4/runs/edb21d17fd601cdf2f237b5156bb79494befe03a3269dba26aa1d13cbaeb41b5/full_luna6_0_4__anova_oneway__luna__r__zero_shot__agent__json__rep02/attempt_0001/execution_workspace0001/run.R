#!/usr/bin/env Rscript
args <- commandArgs(trailingOnly = FALSE)
file_arg <- grep('^--file=', args, value = TRUE)
script_path <- if (length(file_arg)) sub('^--file=', '', file_arg[[1]]) else 'run.R'
workdir <- dirname(normalizePath(script_path, mustWork = FALSE))
input_path <- file.path(workdir, 'input.csv')
output_path <- file.path(workdir, 'result.json')

dat <- read.csv(input_path, stringsAsFactors = FALSE)
stopifnot(all(c('group', 'y') %in% names(dat)))
dat <- dat[complete.cases(dat[, c('group', 'y')]), c('group', 'y')]
dat$group <- factor(dat$group)
fit <- aov(y ~ group, data = dat)
tab <- summary(fit)[[1]]
F_stat <- unname(tab[['F value']][1])
df_num <- unname(tab[['Df']][1])
df_den <- unname(tab[['Df']][2])
p_value <- unname(tab[['Pr(>F)']][1])
n <- nrow(dat)

# Write the required JSON with 17 significant digits for numeric estimates.
fmt <- function(x) sprintf('%.17g', x)
terms <- c('F', 'df_num', 'df_den', 'p_value')
values <- c(F_stat, df_num, df_den, p_value)
estimates <- vapply(seq_along(terms), function(i) {
  paste0('    {"term": "', terms[i], '", "estimate": ', fmt(values[i]),
         ', "se": null, "n_obs": ', n, '}')
}, character(1))
json <- paste0('{
  "task_id": "anova_oneway",
  "platform": "r",
  "estimates": [
', paste(estimates, collapse = ',\n'), '
  ],
  "method_metadata": {"estimator": "one-way ANOVA (aov)", "vcov": "classical ANOVA; no separate standard errors"},
  "diagnostics": {}
}
')
writeLines(json, output_path)
