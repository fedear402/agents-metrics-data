d <- read.csv("input.csv", stringsAsFactors=FALSE)
d$date <- as.Date(d$date)
d <- d[order(d$date), ]
d$log_sales <- log(d$sales)
d$change <- c(NA_real_, diff(log(d$vix)))
for (j in 1:15) d[[paste0("lag_",j)]] <- c(rep(NA_real_,j), head(d$change, -j))
# lag_j at row t is change at t-j; first usable row is t=17.
vars <- c("log_sales", paste0("lag_",1:15))
s <- d[complete.cases(d[,vars]), vars]
fit <- lm(log_sales ~ ., data=s)
X <- model.matrix(fit); e <- residuals(fit); b <- coef(fit)
N <- nrow(X); p <- ncol(X)
score <- X * e
meat <- crossprod(score)
for (j in 1:15) {
  g <- crossprod(score[(j+1):N,,drop=FALSE], score[1:(N-j),,drop=FALSE])
  meat <- meat + (1-j/16)*(g+t(g))
}
 bread <- solve(crossprod(X))
V <- N/(N-16) * bread %*% meat %*% bread
cvec <- c(0, rep(1,15))
rows <- list(
 list(term="cumulative_response", estimate=unname(sum(b[-1])), se=unname(sqrt(drop(t(cvec)%*%V%*%cvec))), n_obs=as.integer(N)),
 list(term="lag_1", estimate=unname(b["lag_1"]), se=unname(sqrt(V["lag_1","lag_1"])), n_obs=as.integer(N)),
 list(term="lag_15", estimate=unname(b["lag_15"]), se=unname(sqrt(V["lag_15","lag_15"])), n_obs=as.integer(N)))
out <- list(task_id="applied_cumulative_hac", platform="r", estimates=rows,
 method_metadata=list(estimator="OLS", vcov="Newey-West Bartlett, max lag 15, finite-sample factor N/(N-16)"), diagnostics=list())
jsonlite::write_json(out,"result.json",auto_unbox=TRUE,null="null",digits=16,pretty=TRUE)
