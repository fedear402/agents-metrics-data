suppressPackageStartupMessages(library(jsonlite))
dat <- read.csv("input.csv")
stopifnot(all(c("group", "y") %in% names(dat)))
dat <- dat[complete.cases(dat[, c("group", "y")]), c("group", "y")]
dat$group <- factor(dat$group)
n <- nrow(dat)
fit <- aov(y ~ group, data = dat)
tab <- summary(fit)[[1]]
Fval <- unname(tab["group", "F value"])
df_num <- unname(tab["group", "Df"])
df_den <- unname(tab["Residuals", "Df"])
pval <- unname(tab["group", "Pr(>F)"])
est <- lapply(list(F = Fval, df_num = df_num, df_den = df_den, p_value = pval), function(x) list(estimate = x, se = NULL, n_obs = n))
estimates <- Map(function(term, z) c(list(term = term), z), names(est), est)
out <- list(task_id = "anova_oneway", platform = "r", estimates = estimates,
            method_metadata = list(estimator = "One-way ANOVA; classical F test", vcov = "classical pooled within-group variance"),
            diagnostics = list())
write_json(out, "result.json", auto_unbox = TRUE, digits = 17, null = "null")
