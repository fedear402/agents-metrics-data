data <- read.csv("input.csv", stringsAsFactors = FALSE)
data$date <- as.Date(data$date)
data <- data[order(data$date), ]
data$log_sales <- log(data$sales)
data$log_vix <- log(data$vix)
data$vol_change <- c(NA_real_, diff(data$log_vix))

# At row t, change_lagj is the volatility change observed at t-j.
for (j in 1:15) {
  data[[paste0("lag_", j)]] <- c(rep(NA_real_, j + 1L),
                                 data$vol_change[seq_len(nrow(data) - j - 1L)])
}
lag_names <- paste0("lag_", 1:15)
sample <- data[complete.cases(data[, c("log_sales", lag_names)]), ]
fit <- lm(log_sales ~ ., data = sample[, c("log_sales", lag_names)])
X <- model.matrix(fit)
e <- residuals(fit)
N <- nrow(X)
p <- ncol(X)
scores <- X * as.numeric(e)
meat <- crossprod(scores)
for (j in 1:15) {
  lag_product <- crossprod(scores[(j + 1):N, , drop = FALSE],
                           scores[1:(N - j), , drop = FALSE])
  meat <- meat + (1 - j / 16) * (lag_product + t(lag_product))
}
bread <- solve(crossprod(X))
V <- (N / (N - p)) * bread %*% meat %*% bread
b <- coef(fit)
ix <- match(lag_names, names(b))
contrast <- rep(0, length(b))
contrast[ix] <- 1
cumulative <- sum(contrast * b)
cumulative_se <- sqrt(drop(t(contrast) %*% V %*% contrast))

row <- function(term, estimate, se) {
  list(term = term, estimate = unname(as.numeric(estimate)),
       se = unname(as.numeric(se)), n_obs = as.integer(N))
}
out <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    row("cumulative_response", cumulative, cumulative_se),
    row("lag_1", b["lag_1"], sqrt(V[match("lag_1", names(b)), match("lag_1", names(b))])),
    row("lag_15", b["lag_15"], sqrt(V[match("lag_15", names(b)), match("lag_15", names(b))]))
  ),
  method_metadata = list(estimator = "OLS with 15 lagged log-VIX changes",
                         vcov = "Newey-West Bartlett HAC, max lag 15, N/(N-16) correction"),
  diagnostics = list(n_total = nrow(data), n_obs = N, regression_lags = 15L,
                     hac_lags = 15L, parameter_count = p,
                     first_sample_date = as.character(min(sample$date)),
                     last_sample_date = as.character(max(sample$date)))
)
jsonlite::write_json(out, "result.json", auto_unbox = TRUE, null = "null",
                     digits = 16, pretty = TRUE)

# Independent check: the contrast variance equals the sum of all elements
# in the 15-by-15 lag-coefficient covariance submatrix.
variance_by_submatrix <- sum(V[ix, ix, drop = FALSE])
stopifnot(isTRUE(all.equal(cumulative_se^2, variance_by_submatrix,
                           tolerance = 1e-10)))
