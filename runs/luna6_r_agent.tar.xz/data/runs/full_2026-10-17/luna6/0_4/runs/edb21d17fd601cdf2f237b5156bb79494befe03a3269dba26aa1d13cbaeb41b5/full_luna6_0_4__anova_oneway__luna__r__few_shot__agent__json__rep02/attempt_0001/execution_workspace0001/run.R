library(jsonlite)

dat <- read.csv("./input.csv", stringsAsFactors = FALSE)
fit <- aov(y ~ factor(group), data = dat)
tab <- summary(fit)[[1L]]
f_stat <- unname(tab[1L, "F value"])
df_num <- unname(tab[1L, "Df"])
df_den <- unname(tab[2L, "Df"])
p_value <- unname(tab[1L, "Pr(>F)"])
n <- nrow(dat)

out <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = list(
    list(term = "F", estimate = f_stat, se = NA_real_, n_obs = n),
    list(term = "df_num", estimate = df_num, se = NA_real_, n_obs = n),
    list(term = "df_den", estimate = df_den, se = NA_real_, n_obs = n),
    list(term = "p_value", estimate = p_value, se = NA_real_, n_obs = n)
  ),
  method_metadata = list(estimator = "One-way ANOVA", vcov = "classical pooled within-group variance"),
  diagnostics = structure(list(), names = character(0))
)
write_json(out, "result.json", auto_unbox = TRUE, na = "null", digits = 16)
