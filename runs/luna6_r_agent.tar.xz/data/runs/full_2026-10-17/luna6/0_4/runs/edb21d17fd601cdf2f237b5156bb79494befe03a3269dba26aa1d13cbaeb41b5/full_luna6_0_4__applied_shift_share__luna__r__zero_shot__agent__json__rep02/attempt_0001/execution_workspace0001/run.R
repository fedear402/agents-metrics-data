 d <- read.csv('input.csv', stringsAsFactors=FALSE)
req <- c('region_id','industry_id','share','shock','region_weight','x','y')
if (!all(req %in% names(d))) stop('Required columns are missing')
if (anyDuplicated(d[c('region_id','industry_id')])) stop('Duplicate region-industry rows')
regions <- unique(d$region_id)
industries <- unique(d$industry_id)
# Verify inputs that must be constant within region or industry.
constant_in_group <- function(x, g) all(vapply(split(x,g), function(v) length(unique(v)) == 1L, logical(1)))
if (!constant_in_group(d$region_weight,d$region_id) || !constant_in_group(d$x,d$region_id) || !constant_in_group(d$y,d$region_id)) stop('Regional variables vary within region')
if (!constant_in_group(d$shock,d$industry_id)) stop('Shock varies within industry')
share_sums <- tapply(d$share,d$region_id,sum)
if (max(abs(share_sums-1)) > 1e-8) stop('Shares do not sum to one within region')
# One observation per region is used to normalize regional weights.
r <- d[match(regions,d$region_id), c('region_id','region_weight','x','y')]
r$e <- r$region_weight/sum(r$region_weight)
# Aggregate all industry rows onto the regional analysis sample.
region_z <- aggregate(cbind(share_shock=d$share*d$shock), list(region_id=d$region_id), sum)
r$z <- region_z$share_shock[match(r$region_id,region_z$region_id)]
weighted_mean <- function(v,w) sum(w*v)/sum(w)
r$y0 <- r$y-weighted_mean(r$y,r$e)
r$x0 <- r$x-weighted_mean(r$x,r$e)
r$z0 <- r$z-weighted_mean(r$z,r$e)
# Industry exposure weights and exposure-weighted residual aggregates.
inds <- unique(d$industry_id)
out <- data.frame(industry_id=inds)
out$shock <- d$shock[match(inds,d$industry_id)]
out$s <- vapply(inds,function(j) sum(r$e[match(d$region_id[d$industry_id==j],r$region_id)]*d$share[d$industry_id==j]),numeric(1))
for (v in c('y0','x0','z0')) {
  vals <- vapply(inds,function(j) {
    q <- d[d$industry_id==j,]
    sum(r$e[match(q$region_id,r$region_id)]*q$share*r[[v]][match(q$region_id,r$region_id)])/out$s[match(j,inds)]
  },numeric(1))
  out[[paste0(v,'bar')]] <- vals
}
if (any(out$s <= 0) || abs(sum(out$s)-1)>1e-8) stop('Invalid industry exposure weights')
# Weighted 2SLS using the explicit weighted projection and structural IV residuals.
wiv <- function(y,x,q,w) {
  X <- cbind(1,x); Z <- cbind(1,q)
  sw <- sqrt(w)
  Xw <- X*sw; Zw <- Z*sw; yw <- y*sw
  PZX <- Zw %*% solve(crossprod(Zw), crossprod(Zw,Xw))
  b <- solve(crossprod(Xw,PZX), crossprod(PZX,yw))
  u <- as.vector(y-X%*%b)
  # HC1 sandwich for analytic weights: bread times sum_i w_i^2 u_i^2 z_i z_i' times bread.
  bread <- solve(crossprod(Xw,PZX))
  meat <- crossprod(Z, Z*(w^2*u^2))
  V <- bread %*% crossprod(X,Z) %*% solve(crossprod(Z,w*Z)) %*% meat %*% solve(crossprod(Z,w*Z)) %*% crossprod(Z,X) %*% bread
  V <- V * length(y)/(length(y)-ncol(X))
  list(coef=as.vector(b),se=sqrt(diag(V)),resid=u)
}
# Equivalent direct formulation of the analytic-weight IV sandwich.
# For z-score estimating equations: A=X'WZ(Z'WZ)^-1 Z'WX, B=Z'WZ.
# Covariance = A^-1 X'WZ B^-1 [sum w_i^2 u_i^2 z_i z_i'] B^-1 Z'WX A^-1.
effect <- wiv(out$y0bar,out$x0bar,out$shock,out$s)
first <- wiv(out$x0bar,out$z0bar,out$shock,out$s)
effective <- 1/sum(out$s^2)
# Independent check: regional weighted IV slope must equal the shock-level IV slope.
regional <- wiv(r$y0,r$x0,r$z,r$e)
if (abs(regional$coef[2]-effect$coef[2]) > 1e-8) stop('Regional and shock-level effect slopes do not agree')
# Regional first-stage slope is independently computed by weighted OLS.
fs_ols <- lm.wfit(cbind(1,r$z),r$x,r$e)$coefficients
if (abs(fs_ols[2]-first$coef[2]) > 1e-8) stop('Regional and shock-level first-stage slopes do not agree')
res <- list(task_id='applied_shift_share',platform='r',estimates=list(
  list(term='effect',estimate=unname(effect$coef[2]),se=unname(effect$se[2]),n_obs=length(inds)),
  list(term='first_stage',estimate=unname(fs_ols[2]),se=unname(first$se[2]),n_obs=length(inds)),
  list(term='effective_shocks',estimate=unname(effective),se=NULL,n_obs=length(inds))),
  method_metadata=list(estimator='Weighted 2SLS; BHJ shock-level aggregation with analytic exposure weights',vcov='Shock-level heteroskedasticity-robust HC1; structural IV residuals; no clustering'),
  diagnostics=list(n_regions=length(regions),n_industries=length(inds),n_region_industry_rows=nrow(d),share_sum_max_abs_error=max(abs(share_sums-1)),regional_effect_slope=unname(regional$coef[2]),shock_level_effect_slope=unname(effect$coef[2]),regional_first_stage_slope=unname(fs_ols[2]),shock_level_first_stage_slope=unname(first$coef[2]),sum_industry_exposures=sum(out$s))
)
jsonlite::write_json(res,'result.json',auto_unbox=TRUE,digits=16,null='null',pretty=TRUE)
