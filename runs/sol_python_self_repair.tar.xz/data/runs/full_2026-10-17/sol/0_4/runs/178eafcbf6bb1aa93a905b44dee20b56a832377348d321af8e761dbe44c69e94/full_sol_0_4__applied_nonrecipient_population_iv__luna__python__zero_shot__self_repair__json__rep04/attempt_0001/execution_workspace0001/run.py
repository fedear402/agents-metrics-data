import csv
import json


def solve_linear_system(matrix, vector):
    """Solve a square linear system using partial pivoting."""
    n = len(vector)
    augmented = [list(matrix[i]) + [vector[i]] for i in range(n)]

    for col in range(n):
        pivot = max(range(col, n), key=lambda row: abs(augmented[row][col]))
        if abs(augmented[pivot][col]) < 1e-14:
            raise ValueError("The weighted IV system is singular.")
        augmented[col], augmented[pivot] = augmented[pivot], augmented[col]

        scale = augmented[col][col]
        for j in range(col, n + 1):
            augmented[col][j] /= scale

        for row in range(col + 1, n):
            factor = augmented[row][col]
            for j in range(col, n + 1):
                augmented[row][j] -= factor * augmented[col][j]

    solution = [0.0] * n
    for row in range(n - 1, -1, -1):
        solution[row] = augmented[row][n] - sum(
            augmented[row][col] * solution[col]
            for col in range(row + 1, n)
        )
    return solution


with open("households.csv", newline="", encoding="utf-8-sig") as file:
    households = list(csv.DictReader(file))

with open("census.csv", newline="", encoding="utf-8-sig") as file:
    census = list(csv.DictReader(file))

# Retain all nonrecipients, regardless of village treatment status.
retained = [row for row in households if int(row["recipient"]) == 0]
n_obs = len(retained)

# With six instruments and six regressors, weighted 2SLS solves Z'WX beta = Z'Wy.
cross_product = [[0.0] * 6 for _ in range(6)]
outcome_product = [0.0] * 6
dose_weighted_sum = {0: 0.0, 1: 0.0}
weight_sum = {0: 0.0, 1: 0.0}

for row in retained:
    eligible = int(row["eligible"])
    if eligible not in (0, 1):
        raise ValueError("eligible must be zero or one.")

    ineligible = 1 - eligible
    baseline = float(row["baseline"])
    dose = float(row["dose"])
    instrument = float(row["instrument"])
    weight = float(row["weight"])
    outcome = float(row["outcome"])

    if weight <= 0:
        raise ValueError("All estimation weights must be positive.")

    exogenous = [
        float(ineligible),
        float(eligible),
        baseline * ineligible,
        baseline * eligible,
    ]
    regressors = exogenous + [dose * ineligible, dose * eligible]
    instruments = exogenous + [
        instrument * ineligible,
        instrument * eligible,
    ]

    for i in range(6):
        outcome_product[i] += weight * instruments[i] * outcome
        for j in range(6):
            cross_product[i][j] += weight * instruments[i] * regressors[j]

    dose_weighted_sum[eligible] += weight * dose
    weight_sum[eligible] += weight

coefficients = solve_linear_system(cross_product, outcome_product)

if any(weight_sum[group] <= 0 for group in (0, 1)):
    raise ValueError("Both eligibility groups need retained observations.")

mean_dose = {
    group: dose_weighted_sum[group] / weight_sum[group]
    for group in (0, 1)
}
ineligible_effect = coefficients[4] * mean_dose[0]
eligible_nonrecipient_effect = coefficients[5] * mean_dose[1]

population = {0: 0, 1: 0}
for row in census:
    group = int(row["eligible"])
    if group not in population:
        raise ValueError("Census eligible must be zero or one.")
    population[group] += int(row["nonrecipient_population"])

total_population = population[0] + population[1]
if total_population <= 0:
    raise ValueError("Total nonrecipient census population must be positive.")

population_effect = (
    population[0] * ineligible_effect
    + population[1] * eligible_nonrecipient_effect
) / total_population

results = [
    ("ineligible_effect", ineligible_effect),
    ("eligible_nonrecipient_effect", eligible_nonrecipient_effect),
    ("population_effect", population_effect),
]

output = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {"term": term, "estimate": estimate, "se": None, "n_obs": n_obs}
        for term, estimate in results
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "regressors": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
            "dose*(1-eligible)",
            "dose*eligible",
        ],
        "instruments": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
            "instrument*(1-eligible)",
            "instrument*eligible",
        ],
        "weight": "weight",
        "counterfactual": (
            "Dose is set to zero for every retained household. "
            "This attribution is a stated synthetic convention."
        ),
        "aggregation": (
            "Each group effect is its fitted dose slope times its "
            "household-weighted mean dose. Census nonrecipient populations "
            "determine only the final between-group weights."
        ),
    },
    "diagnostics": {
        "n_obs": n_obs,
        "group_weighted_mean_dose": {
            "ineligible": mean_dose[0],
            "eligible_nonrecipient": mean_dose[1],
        },
        "nonrecipient_population": {
            "ineligible": population[0],
            "eligible_nonrecipient": population[1],
        },
    },
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(output, file, indent=2, allow_nan=False)
