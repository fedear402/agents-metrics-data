import json

import numpy as np
import pandas as pd
from scipy.stats import f

data = pd.read_csv("input.csv")
n = len(data)
q = 2
df = n - 4

y = data["y"].to_numpy(dtype=float)
endog = data["endog"].to_numpy(dtype=float)
x = data["x"].to_numpy(dtype=float)
z1 = data["z1"].to_numpy(dtype=float)
z2 = data["z2"].to_numpy(dtype=float)

restricted = np.column_stack((np.ones(n), x))
unrestricted = np.column_stack((restricted, z1, z2))

def residual(values, design):
    coefficients = np.linalg.lstsq(design, values, rcond=None)[0]
    return values - design @ coefficients

ry = residual(y, restricted)
rd = residual(endog, restricted)
uy = residual(y, unrestricted)
ud = residual(endog, unrestricted)

critical = f.ppf(0.95, q, df)
scale = 1.0 + q * critical / df

# Acceptance holds when A*beta**2 + B*beta + C <= 0.
A = float(rd @ rd - scale * (ud @ ud))
B = float(-2.0 * (ry @ rd - scale * (uy @ ud)))
C = float(ry @ ry - scale * (uy @ uy))

discriminant = B * B - 4.0 * A * C
if A == 0.0 or discriminant <= 0.0:
    raise ValueError("Expected two distinct finite Anderson-Rubin boundaries")

root = np.sqrt(discriminant)
boundaries = sorted(((-B - root) / (2.0 * A), (-B + root) / (2.0 * A)))

restricted_at_one = ry - rd
unrestricted_at_one = uy - ud
ssr_r = float(restricted_at_one @ restricted_at_one)
ssr_u = float(unrestricted_at_one @ unrestricted_at_one)
ar_f_at_one = ((ssr_r - ssr_u) / q) / (ssr_u / df)

values = {
    "boundary_low": float(boundaries[0]),
    "boundary_high": float(boundaries[1]),
    "accepts_zero": int(C <= 0.0),
    "unbounded": int(A < 0.0),
    "ar_f_at_one": float(ar_f_at_one),
}

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": [
        {"term": term, "estimate": estimate, "se": None, "n_obs": n}
        for term, estimate in values.items()
    ],
    "method_metadata": {
        "estimator": "Anderson-Rubin test inversion",
        "vcov": "Conventional homoskedastic joint F test",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
