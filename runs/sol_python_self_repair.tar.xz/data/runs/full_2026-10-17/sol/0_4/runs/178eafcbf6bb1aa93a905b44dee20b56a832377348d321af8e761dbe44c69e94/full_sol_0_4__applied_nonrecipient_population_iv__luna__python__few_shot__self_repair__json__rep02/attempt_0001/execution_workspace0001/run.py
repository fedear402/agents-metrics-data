import json

import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS


def main():
    households = pd.read_csv("households.csv")
    census = pd.read_csv("census.csv")

    sample = households.loc[households["recipient"] == 0].copy()
    ineligible = 1 - sample["eligible"]
    eligible = sample["eligible"]

    exog = pd.DataFrame(
        {
            "ineligible": ineligible,
            "eligible": eligible,
            "baseline_ineligible": sample["baseline"] * ineligible,
            "baseline_eligible": sample["baseline"] * eligible,
        },
        index=sample.index,
    )
    endog = pd.DataFrame(
        {
            "dose_ineligible": sample["dose"] * ineligible,
            "dose_eligible": sample["dose"] * eligible,
        },
        index=sample.index,
    )
    excluded_instruments = pd.DataFrame(
        {
            "instrument_ineligible": sample["instrument"] * ineligible,
            "instrument_eligible": sample["instrument"] * eligible,
        },
        index=sample.index,
    )

    fit = IV2SLS(
        dependent=sample["outcome"],
        exog=exog,
        endog=endog,
        instruments=excluded_instruments,
        weights=sample["weight"],
    ).fit()

    effects = {}
    weighted_mean_dose = {}
    for group, term in (
        (0, "ineligible_effect"),
        (1, "eligible_nonrecipient_effect"),
    ):
        group_rows = sample.loc[sample["eligible"] == group]
        mean_dose = np.average(
            group_rows["dose"], weights=group_rows["weight"]
        )
        slope_name = "dose_ineligible" if group == 0 else "dose_eligible"
        weighted_mean_dose[group] = float(mean_dose)
        effects[term] = float(fit.params[slope_name] * mean_dose)

    population = census.groupby("eligible")["nonrecipient_population"].sum()
    population_effect = float(
        np.average(
            [
                effects["ineligible_effect"],
                effects["eligible_nonrecipient_effect"],
            ],
            weights=[population.loc[0], population.loc[1]],
        )
    )

    n_obs = int(len(sample))
    result = {
        "task_id": "applied_nonrecipient_population_iv",
        "platform": "python",
        "estimates": [
            {
                "term": term,
                "estimate": value,
                "se": None,
                "n_obs": n_obs,
            }
            for term, value in (
                ("ineligible_effect", effects["ineligible_effect"]),
                (
                    "eligible_nonrecipient_effect",
                    effects["eligible_nonrecipient_effect"],
                ),
                ("population_effect", population_effect),
            )
        ],
        "method_metadata": {
            "estimator": "weighted_2sls",
            "sample": "households with recipient == 0",
            "regression_weight": "weight",
            "exogenous_columns": list(exog.columns),
            "endogenous_columns": list(endog.columns),
            "excluded_instrument_columns": list(excluded_instruments.columns),
            "intercept": "no additional intercept",
            "group_effect": "fitted group dose slope times household-weighted mean dose",
            "counterfactual": "dose set to zero for every retained household",
            "population_aggregation_weight": "nonrecipient_population from census.csv",
        },
        "diagnostics": {
            "n_obs": n_obs,
            "weighted_mean_dose": {
                "ineligible": weighted_mean_dose[0],
                "eligible_nonrecipient": weighted_mean_dose[1],
            },
            "dose_slopes": {
                "ineligible": float(fit.params["dose_ineligible"]),
                "eligible_nonrecipient": float(fit.params["dose_eligible"]),
            },
        },
    }

    with open("result.json", "w", encoding="utf-8") as output:
        json.dump(result, output, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
