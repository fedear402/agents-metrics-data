import json

import numpy as np
import pandas as pd
import statsmodels.api as sm

data = pd.read_csv("input.csv", parse_dates=["date"]).sort_values("date")
delta = np.log(data["vix"].astype(float)).diff()

lags = pd.DataFrame(
    {f"lag_{i}": delta.shift(i) for i in range(1, 16)},
    index=data.index,
)
sample = lags.copy()
sample["log_sales"] = np.log(data["sales"].astype(float))
sample = sample.dropna()

terms = [f"lag_{i}" for i in range(1, 16)]
X = sm.add_constant(sample[terms], has_constant="add")
y = sample["log_sales"]
fit = sm.OLS(y, X).fit()

N = len(sample)
if N <= 16:
    raise ValueError("The regression requires more than 16 complete observations.")

residuals = fit.resid.to_numpy()
design = X.to_numpy()
bread = np.linalg.inv(design.T @ design)
scores = design * residuals[:, None]

meat = scores.T @ scores
for j in range(1, 16):
    cross = scores[j:].T @ scores[:-j]
    meat += (1.0 - j / 16.0) * (cross + cross.T)

covariance = (N / (N - 16)) * bread @ meat @ bread
covariance = (covariance + covariance.T) / 2
params = fit.params.to_numpy()
positions = {name: i for i, name in enumerate(X.columns)}

weights = np.zeros(len(params))
weights[[positions[name] for name in terms]] = 1.0


def result_row(term, vector):
    variance = float(vector @ covariance @ vector)
    return {
        "term": term,
        "estimate": float(vector @ params),
        "se": float(np.sqrt(max(variance, 0.0))),
        "n_obs": int(N),
    }


unit_1 = np.zeros(len(params))
unit_1[positions["lag_1"]] = 1.0
unit_15 = np.zeros(len(params))
unit_15[positions["lag_15"]] = 1.0

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        result_row("cumulative_response", weights),
        result_row("lag_1", unit_1),
        result_row("lag_15", unit_15),
    ],
    "method_metadata": {
        "estimator": "OLS with intercept and 15 lagged log-vix changes",
        "vcov": "Newey-West HAC, Bartlett weights, max lag 15, scaled by N/(N-16)",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output)
