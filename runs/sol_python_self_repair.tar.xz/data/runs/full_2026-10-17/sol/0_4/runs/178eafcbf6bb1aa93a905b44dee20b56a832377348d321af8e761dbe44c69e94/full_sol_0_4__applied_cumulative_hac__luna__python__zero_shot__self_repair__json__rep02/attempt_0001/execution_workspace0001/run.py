import json

import numpy as np
import pandas as pd

data = pd.read_csv("input.csv")
data["date"] = pd.to_datetime(data["date"])
data = data.sort_values("date")

log_vix_change = np.log(data["vix"]).diff()
regression = pd.DataFrame({"log_sales": np.log(data["sales"])})
for lag in range(1, 16):
    regression[f"lag_{lag}"] = log_vix_change.shift(lag)
regression = regression.dropna()

y = regression["log_sales"].to_numpy()
X = np.column_stack(
    [np.ones(len(regression))]
    + [regression[f"lag_{lag}"].to_numpy() for lag in range(1, 16)]
)
n_obs = len(y)
if n_obs <= 16:
    raise ValueError("The regression requires more than 16 complete observations.")

coefficients = np.linalg.solve(X.T @ X, X.T @ y)
residuals = y - X @ coefficients
scores = X * residuals[:, None]

meat = scores.T @ scores
for lag in range(1, 16):
    cross_product = scores[lag:].T @ scores[:-lag]
    meat += (1 - lag / 16) * (cross_product + cross_product.T)

bread = np.linalg.inv(X.T @ X)
covariance = (n_obs / (n_obs - 16)) * (bread @ meat @ bread)

def make_row(term, weights):
    estimate = float(weights @ coefficients)
    variance = float(weights @ covariance @ weights)
    return {
        "term": term,
        "estimate": estimate,
        "se": float(np.sqrt(max(variance, 0.0))),
        "n_obs": n_obs,
    }

cumulative_weights = np.r_[0.0, np.ones(15)]
lag_1_weights = np.eye(16)[1]
lag_15_weights = np.eye(16)[15]

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        make_row("cumulative_response", cumulative_weights),
        make_row("lag_1", lag_1_weights),
        make_row("lag_15", lag_15_weights),
    ],
    "method_metadata": {
        "estimator": "OLS with intercept and 15 lagged log-vix changes",
        "vcov": "Newey-West HAC, Bartlett weights, maximum lag 15, scaled by N/(N-16)",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file)
