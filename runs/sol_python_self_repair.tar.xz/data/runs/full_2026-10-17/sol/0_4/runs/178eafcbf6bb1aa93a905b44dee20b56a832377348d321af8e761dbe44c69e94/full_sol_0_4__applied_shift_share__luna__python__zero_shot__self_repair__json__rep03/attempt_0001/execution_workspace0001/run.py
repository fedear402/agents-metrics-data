import json

import numpy as np
import pandas as pd


def weighted_mean(values, weights):
    return np.sum(weights * values) / np.sum(weights)


def iv_slope_and_hc1(y, x, instrument, weights):
    n = len(y)
    x0 = x - weighted_mean(x, weights)
    q0 = instrument - weighted_mean(instrument, weights)
    denominator = np.sum(weights * q0 * x0)
    slope = np.sum(weights * q0 * (y - weighted_mean(y, weights))) / denominator
    intercept = weighted_mean(y, weights) - slope * weighted_mean(x, weights)
    residual = y - intercept - slope * x
    variance = (
        n / (n - 2)
        * np.sum((weights * q0 * residual) ** 2)
        / denominator**2
    )
    return float(slope), float(np.sqrt(variance))


data = pd.read_csv("input.csv")

regions = data.groupby("region_id", sort=False)[
    ["region_weight", "x", "y"]
].first()
regions["e"] = regions["region_weight"] / regions["region_weight"].sum()

exposure = data[["region_id", "industry_id", "share", "shock"]].merge(
    regions[["e", "x", "y"]],
    left_on="region_id",
    right_index=True,
    validate="many_to_one",
)
exposure["weighted_share"] = exposure["e"] * exposure["share"]

regional_z = (
    exposure.assign(contribution=exposure["share"] * exposure["shock"])
    .groupby("region_id", sort=False)["contribution"]
    .sum()
)
regions["z"] = regional_z

for variable in ("y", "x", "z"):
    regions[f"{variable}0"] = (
        regions[variable]
        - weighted_mean(regions[variable].to_numpy(), regions["e"].to_numpy())
    )

exposure = exposure.join(regions[["y0", "x0", "z0"]], on="region_id")
for variable in ("y", "x", "z"):
    exposure[f"{variable}_contribution"] = (
        exposure["weighted_share"] * exposure[f"{variable}0"]
    )

industry = exposure.groupby("industry_id", sort=False).agg(
    s=("weighted_share", "sum"),
    shock=("shock", "first"),
    y_total=("y_contribution", "sum"),
    x_total=("x_contribution", "sum"),
    z_total=("z_contribution", "sum"),
)
for variable in ("y", "x", "z"):
    industry[f"{variable}bar"] = industry[f"{variable}_total"] / industry["s"]

s = industry["s"].to_numpy(dtype=float)
shock = industry["shock"].to_numpy(dtype=float)
ybar = industry["ybar"].to_numpy(dtype=float)
xbar = industry["xbar"].to_numpy(dtype=float)
zbar = industry["zbar"].to_numpy(dtype=float)
n = len(industry)

effect, effect_se = iv_slope_and_hc1(ybar, xbar, shock, s)
first_stage, first_stage_se = iv_slope_and_hc1(xbar, zbar, shock, s)
effective_shocks = float(1 / np.sum(s**2))

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": effect, "se": effect_se, "n_obs": n},
        {
            "term": "first_stage",
            "estimate": first_stage,
            "se": first_stage_se,
            "n_obs": n,
        },
        {
            "term": "effective_shocks",
            "estimate": effective_shocks,
            "se": None,
            "n_obs": n,
        },
    ],
    "method_metadata": {
        "estimator": "Weighted regional 2SLS with BHJ shock-level aggregation",
        "vcov": "Shock-level analytic-weight IV HC1, multiplier N/(N-2)",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output, indent=2, allow_nan=False)
