import json

import numpy as np
import pandas as pd

data = pd.read_csv("input.csv")
regions = data.drop_duplicates("region_id").set_index("region_id")
industries = data.drop_duplicates("industry_id").set_index("industry_id")

e = regions["region_weight"].astype(float)
e = e / e.sum()

shares = data.pivot(index="region_id", columns="industry_id", values="share")
shares = shares.loc[regions.index, industries.index].to_numpy(dtype=float)
shock = industries["shock"].to_numpy(dtype=float)

x = regions["x"].to_numpy(dtype=float)
y = regions["y"].to_numpy(dtype=float)
weights = e.to_numpy(dtype=float)
z = shares @ shock

regional = np.column_stack((y, x, z))
centered = regional - weights @ regional

mass = weights @ shares
aggregated = shares.T @ (weights[:, None] * centered) / mass[:, None]
n_industries = len(shock)


def shock_level_iv(dependent, endogenous):
    regressors = np.column_stack((np.ones(n_industries), endogenous))
    instruments = np.column_stack((np.ones(n_industries), shock))
    cross = instruments.T @ (mass[:, None] * regressors)
    coefficients = np.linalg.solve(
        cross, instruments.T @ (mass * dependent)
    )
    residuals = dependent - regressors @ coefficients
    scores = instruments * (mass * residuals)[:, None]
    cross_inverse = np.linalg.inv(cross)
    covariance = (
        n_industries
        / (n_industries - 2)
        * cross_inverse
        @ (scores.T @ scores)
        @ cross_inverse.T
    )
    return float(coefficients[1]), float(np.sqrt(covariance[1, 1]))


effect, effect_se = shock_level_iv(aggregated[:, 0], aggregated[:, 1])
first_stage, first_stage_se = shock_level_iv(
    aggregated[:, 1], aggregated[:, 2]
)
effective_shocks = float(1 / np.sum(mass**2))

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {
            "term": "effect",
            "estimate": effect,
            "se": effect_se,
            "n_obs": n_industries,
        },
        {
            "term": "first_stage",
            "estimate": first_stage,
            "se": first_stage_se,
            "n_obs": n_industries,
        },
        {
            "term": "effective_shocks",
            "estimate": effective_shocks,
            "se": None,
            "n_obs": n_industries,
        },
    ],
    "method_metadata": {
        "estimator": "Weighted regional 2SLS via BHJ shock-level IV",
        "vcov": "Shock-level heteroskedasticity-robust HC1, N/(N-2)",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
