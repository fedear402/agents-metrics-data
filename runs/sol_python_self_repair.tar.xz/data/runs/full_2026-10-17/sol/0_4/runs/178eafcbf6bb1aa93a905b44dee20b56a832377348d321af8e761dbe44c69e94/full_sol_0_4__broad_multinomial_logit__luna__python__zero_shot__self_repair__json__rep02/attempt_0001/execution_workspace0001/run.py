import json

import pandas as pd
import statsmodels.api as sm


data = pd.read_csv("input.csv")
y = data["y"].astype(int)
X = sm.add_constant(data[["x", "z"]], has_constant="add")

model = sm.MNLogit(y, X)
fit = model.fit(method="newton", disp=False)

params = fit.params
ses = fit.bse
n_obs = len(data)

zero = pd.DataFrame({"const": [1.0], "x": [0.0], "z": [0.0]})
prob_cat2_zero = float(fit.predict(zero).iloc[0, 2])

estimates = []
for category, column in [(1, 0), (2, 1)]:
    for variable in ("x", "z"):
        estimates.append(
            {
                "term": f"{variable}_cat{category}",
                "estimate": float(params.loc[variable, column]),
                "se": float(ses.loc[variable, column]),
                "n_obs": n_obs,
            }
        )

estimates.append(
    {
        "term": "prob_cat2_zero",
        "estimate": prob_cat2_zero,
        "se": None,
        "n_obs": n_obs,
    }
)

result = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "Multinomial logit maximum likelihood; outcome 0 base",
        "vcov": "Inverse observed information",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output, indent=2)
