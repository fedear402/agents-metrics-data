import csv
import json
import math


def read_csv(path):
    with open(path, newline="", encoding="utf-8-sig") as file:
        return list(csv.DictReader(file))


def solve_linear(matrix, vector):
    size = len(vector)
    augmented = [list(matrix[i]) + [vector[i]] for i in range(size)]

    for column in range(size):
        pivot = max(range(column, size), key=lambda row: abs(augmented[row][column]))
        if abs(augmented[pivot][column]) < 1e-12:
            raise ValueError("The weighted IV system is singular.")
        augmented[column], augmented[pivot] = augmented[pivot], augmented[column]

        divisor = augmented[column][column]
        for index in range(column, size + 1):
            augmented[column][index] /= divisor

        for row in range(size):
            if row == column:
                continue
            factor = augmented[row][column]
            for index in range(column, size + 1):
                augmented[row][index] -= factor * augmented[column][index]

    return [augmented[row][size] for row in range(size)]


households = read_csv("households.csv")
census = read_csv("census.csv")

rows = [row for row in households if int(row["recipient"]) == 0]
n_obs = len(rows)

# Column order: group indicators, group-specific baselines, group-specific doses.
ztwx = [[0.0] * 6 for _ in range(6)]
ztwy = [0.0] * 6
dose_weighted_sum = [0.0, 0.0]
group_weight_sum = [0.0, 0.0]

for row in rows:
    group = int(row["eligible"])
    if group not in (0, 1):
        raise ValueError("eligible must be zero or one.")

    baseline = float(row["baseline"])
    dose = float(row["dose"])
    instrument = float(row["instrument"])
    weight = float(row["weight"])
    outcome = float(row["outcome"])
    if weight <= 0:
        raise ValueError("weight must be positive.")

    indicator = [float(group == 0), float(group == 1)]
    exogenous = indicator + [baseline * value for value in indicator]
    x = exogenous + [dose * value for value in indicator]
    z = exogenous + [instrument * value for value in indicator]

    for i in range(6):
        ztwy[i] += weight * z[i] * outcome
        for j in range(6):
            ztwx[i][j] += weight * z[i] * x[j]

    dose_weighted_sum[group] += weight * dose
    group_weight_sum[group] += weight

if any(total == 0 for total in group_weight_sum):
    raise ValueError("Each eligibility group needs positive total weight.")

coefficients = solve_linear(ztwx, ztwy)
effects = [
    coefficients[4 + group] * dose_weighted_sum[group] / group_weight_sum[group]
    for group in (0, 1)
]

population = [0, 0]
for row in census:
    group = int(row["eligible"])
    if group not in (0, 1):
        raise ValueError("Census eligible must be zero or one.")
    count = int(row["nonrecipient_population"])
    if count < 0:
        raise ValueError("Census population cannot be negative.")
    population[group] += count

total_population = sum(population)
if total_population == 0:
    raise ValueError("Total nonrecipient census population must be positive.")

population_effect = math.fsum(
    effects[group] * population[group] / total_population for group in (0, 1)
)

terms = [
    ("ineligible_effect", effects[0]),
    ("eligible_nonrecipient_effect", effects[1]),
    ("population_effect", population_effect),
]

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {"term": term, "estimate": estimate, "se": None, "n_obs": n_obs}
        for term, estimate in terms
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "sample": "all household rows with recipient=0",
        "endogenous_columns": [
            "dose*(1-eligible)",
            "dose*eligible",
        ],
        "exogenous_columns": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
        ],
        "excluded_instruments": [
            "instrument*(1-eligible)",
            "instrument*eligible",
        ],
        "additional_intercept": False,
        "regression_weight": "weight",
        "group_effect": "group dose slope times household-weighted mean dose",
        "counterfactual": "Dose is set to zero for every retained household as a synthetic attribution convention.",
        "population_aggregation": "Census nonrecipient_population weights only the final between-group average.",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "group_household_counts": {
            "ineligible": sum(int(row["eligible"]) == 0 for row in rows),
            "eligible_nonrecipient": sum(int(row["eligible"]) == 1 for row in rows),
        },
        "nonrecipient_population": {
            "ineligible": population[0],
            "eligible_nonrecipient": population[1],
            "total": total_population,
        },
        "weighted_mean_dose": {
            "ineligible": dose_weighted_sum[0] / group_weight_sum[0],
            "eligible_nonrecipient": dose_weighted_sum[1] / group_weight_sum[1],
        },
    },
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file, indent=2, allow_nan=False)
