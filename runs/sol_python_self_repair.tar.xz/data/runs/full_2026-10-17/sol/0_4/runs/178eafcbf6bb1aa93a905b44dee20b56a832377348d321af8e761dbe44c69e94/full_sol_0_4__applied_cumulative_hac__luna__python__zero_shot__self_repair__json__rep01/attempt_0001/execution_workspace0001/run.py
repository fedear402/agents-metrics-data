import json

import numpy as np
import pandas as pd
import statsmodels.api as sm
from statsmodels.stats.sandwich_covariance import cov_hac

df = pd.read_csv("input.csv")
df["date"] = pd.to_datetime(df["date"])
df = df.sort_values("date").reset_index(drop=True)

log_sales = np.log(df["sales"])
log_vix_change = np.log(df["vix"]).diff()

lags = pd.DataFrame(
    {f"lag_{i}": log_vix_change.shift(i) for i in range(1, 16)}
)
sample = pd.concat([log_sales.rename("log_sales"), lags], axis=1).dropna()

x = sm.add_constant(sample[lags.columns], has_constant="add")
model = sm.OLS(sample["log_sales"], x).fit()
n_obs = len(sample)

covariance = cov_hac(model, nlags=15, use_correction=False)
covariance *= n_obs / (n_obs - 16)

params = model.params
lag_positions = [x.columns.get_loc(f"lag_{i}") for i in range(1, 16)]
weights = np.zeros(len(params))
weights[lag_positions] = 1.0

estimates = [
    {
        "term": "cumulative_response",
        "estimate": float(weights @ params.to_numpy()),
        "se": float(np.sqrt(weights @ covariance @ weights)),
        "n_obs": n_obs,
    }
]

for term in ("lag_1", "lag_15"):
    position = x.columns.get_loc(term)
    estimates.append(
        {
            "term": term,
            "estimate": float(params[term]),
            "se": float(np.sqrt(covariance[position, position])),
            "n_obs": n_obs,
        }
    )

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "OLS with intercept and 15 lagged log VIX changes",
        "vcov": "Newey-West HAC, Bartlett weights, maximum lag 15, scaled by N/(N-16)",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file)
