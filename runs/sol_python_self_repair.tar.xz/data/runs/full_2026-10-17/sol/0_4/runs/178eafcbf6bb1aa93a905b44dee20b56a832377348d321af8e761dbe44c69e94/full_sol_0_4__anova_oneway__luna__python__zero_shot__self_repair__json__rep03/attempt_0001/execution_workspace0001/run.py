import json

import pandas as pd
from scipy.stats import f_oneway

data = pd.read_csv("./input.csv")
data = data[["group", "y"]].copy()
data["y"] = pd.to_numeric(data["y"], errors="coerce")
data = data.dropna(subset=["group", "y"])

groups = [part["y"].to_numpy() for _, part in data.groupby("group")]
if len(groups) < 2 or any(len(group) == 0 for group in groups):
    raise ValueError("ANOVA requires at least two nonempty groups.")

n_obs = len(data)
df_num = len(groups) - 1
df_den = n_obs - len(groups)
if df_den <= 0:
    raise ValueError("ANOVA requires positive residual degrees of freedom.")

f_stat, p_value = f_oneway(*groups)

result = {
    "task_id": "anova_oneway",
    "platform": "python",
    "estimates": [
        {"term": "F", "estimate": float(f_stat), "se": None, "n_obs": n_obs},
        {"term": "df_num", "estimate": float(df_num), "se": None, "n_obs": n_obs},
        {"term": "df_den", "estimate": float(df_den), "se": None, "n_obs": n_obs},
        {"term": "p_value", "estimate": float(p_value), "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "Classical one-way ANOVA",
        "vcov": "Pooled within-group variance",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output, allow_nan=False)
