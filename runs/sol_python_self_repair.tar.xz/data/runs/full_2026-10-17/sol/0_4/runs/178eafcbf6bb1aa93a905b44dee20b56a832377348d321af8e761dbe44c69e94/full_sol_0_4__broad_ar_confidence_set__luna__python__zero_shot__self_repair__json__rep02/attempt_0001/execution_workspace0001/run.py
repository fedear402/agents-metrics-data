import json

import numpy as np
import pandas as pd
from scipy.stats import f

data = pd.read_csv("input.csv")
n = len(data)

y = data["y"].to_numpy(dtype=float)
d = data["endog"].to_numpy(dtype=float)
w = np.column_stack((np.ones(n), data["x"].to_numpy(dtype=float)))
z = data[["z1", "z2"]].to_numpy(dtype=float)

# Remove the intercept and x from the outcome, regressor, and instruments.
def residualize(a, controls):
    return a - controls @ np.linalg.lstsq(controls, a, rcond=None)[0]

yr = residualize(y, w)
dr = residualize(d, w)
zr = residualize(z, w)
qz, _ = np.linalg.qr(zr)

def explained(a):
    return float(np.dot(qz.T @ a, qz.T @ a))

ey, ed, eyd = explained(yr), explained(dr), float(
    np.dot(qz.T @ yr, qz.T @ dr)
)
ry, rd, ryd = (
    float(yr @ yr),
    float(dr @ dr),
    float(yr @ dr),
)

critical = f.ppf(0.95, 2, n - 4)
c = 2 * critical / (n - 4)

# The Anderson-Rubin acceptance condition is A*beta^2+B*beta+C <= 0.
A = (1 + c) * ed - c * rd
B = -2 * ((1 + c) * eyd - c * ryd)
C = (1 + c) * ey - c * ry

roots = np.sort(np.roots([A, B, C]))
if len(roots) != 2 or np.any(np.abs(roots.imag) > 1e-8):
    raise ValueError("Expected two finite, real confidence-set boundaries")
boundary_low, boundary_high = roots.real

def ar_f(beta):
    q = yr - beta * dr
    ss_explained = explained(q)
    ss_residual = float(q @ q) - ss_explained
    return (ss_explained / 2) / (ss_residual / (n - 4))

values = {
    "boundary_low": float(boundary_low),
    "boundary_high": float(boundary_high),
    "accepts_zero": float(C <= 0),
    "unbounded": float(A < 0),
    "ar_f_at_one": float(ar_f(1.0)),
}

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": [
        {"term": term, "estimate": value, "se": None, "n_obs": n}
        for term, value in values.items()
    ],
    "method_metadata": {
        "estimator": "Anderson-Rubin confidence set by analytic quadratic inversion",
        "vcov": "Conventional homoskedastic joint F test",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output)
