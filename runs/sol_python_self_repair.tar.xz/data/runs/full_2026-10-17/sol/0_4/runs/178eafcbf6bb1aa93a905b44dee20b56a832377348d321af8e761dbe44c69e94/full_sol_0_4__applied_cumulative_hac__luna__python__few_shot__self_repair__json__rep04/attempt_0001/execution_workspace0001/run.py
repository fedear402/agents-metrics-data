import json

import numpy as np
import pandas as pd

data = pd.read_csv("input.csv")
data["date"] = pd.to_datetime(data["date"])
data = data.sort_values("date").reset_index(drop=True)

change = np.log(data["vix"].to_numpy(dtype=float))
change = pd.Series(change).diff()

regression = pd.DataFrame({
    "log_sales": np.log(data["sales"].to_numpy(dtype=float))
})
for lag in range(1, 16):
    regression[f"lag_{lag}"] = change.shift(lag)

regression = regression.dropna()
N = len(regression)
p = 16
if N <= p:
    raise ValueError("The regression needs more than 16 complete observations.")

X = np.column_stack([
    np.ones(N),
    regression[[f"lag_{lag}" for lag in range(1, 16)]].to_numpy(),
])
y = regression["log_sales"].to_numpy()

coefficients = np.linalg.lstsq(X, y, rcond=None)[0]
residuals = y - X @ coefficients
scores = X * residuals[:, None]

meat = scores.T @ scores
for j in range(1, 16):
    weight = 1 - j / 16
    lag_product = scores[j:].T @ scores[:-j]
    meat += weight * (lag_product + lag_product.T)

bread = np.linalg.inv(X.T @ X)
covariance = (N / (N - p)) * bread @ meat @ bread

def standard_error(contrast):
    variance = float(contrast @ covariance @ contrast)
    return float(np.sqrt(max(variance, 0.0)))

cumulative_contrast = np.r_[0.0, np.ones(15)]
lag_1_contrast = np.eye(p)[1]
lag_15_contrast = np.eye(p)[15]

output = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {
            "term": "cumulative_response",
            "estimate": float(cumulative_contrast @ coefficients),
            "se": standard_error(cumulative_contrast),
            "n_obs": N,
        },
        {
            "term": "lag_1",
            "estimate": float(coefficients[1]),
            "se": standard_error(lag_1_contrast),
            "n_obs": N,
        },
        {
            "term": "lag_15",
            "estimate": float(coefficients[15]),
            "se": standard_error(lag_15_contrast),
            "n_obs": N,
        },
    ],
    "method_metadata": {
        "estimator": "OLS with intercept and 15 observed-row lags of log VIX changes",
        "vcov": "Bartlett Newey-West, maximum lag 15, correction N/(N-16)",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
