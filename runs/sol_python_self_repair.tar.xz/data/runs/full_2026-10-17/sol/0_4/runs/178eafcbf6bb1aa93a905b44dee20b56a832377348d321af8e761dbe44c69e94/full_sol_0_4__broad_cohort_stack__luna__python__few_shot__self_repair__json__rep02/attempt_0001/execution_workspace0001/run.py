import json

import numpy as np
import pandas as pd


def cohort_result(data, cohort):
    times = list(range(cohort - 2, cohort + 3))
    eligible = data[
        data["time"].isin(times)
        & (
            (data["g"] == cohort)
            | (data["g"] == 0)
            | (data["g"] > cohort + 2)
        )
    ]

    complete_ids = eligible.groupby("id")["time"].nunique()
    complete_ids = complete_ids[complete_ids == len(times)].index
    sample = eligible[eligible["id"].isin(complete_ids)]

    outcomes = sample.pivot(index="id", columns="time", values="y")[times]
    adoption = sample.groupby("id")["g"].first().reindex(outcomes.index)
    treated = adoption.eq(cohort).to_numpy()

    did = treated[:, None] * (np.asarray(times) >= cohort)[None, :]
    did = did.astype(float)
    y = outcomes.to_numpy(dtype=float)

    def demean(values):
        return (
            values
            - values.mean(axis=1, keepdims=True)
            - values.mean(axis=0, keepdims=True)
            + values.mean()
        )

    did_residual = demean(did)
    y_residual = demean(y)
    estimate = np.sum(did_residual * y_residual) / np.sum(did_residual**2)

    return float(estimate), int(treated.sum()), int(sample.shape[0])


data = pd.read_csv("input.csv")
results = [cohort_result(data, cohort) for cohort in (3, 5, 7)]

weights = np.array([result[1] for result in results], dtype=float)
effects = np.array([result[0] for result in results], dtype=float)
weighted_effect = float(np.average(effects, weights=weights))

estimates = [
    {
        "term": f"att_g{cohort}",
        "estimate": result[0],
        "se": None,
        "n_obs": result[2],
    }
    for cohort, result in zip((3, 5, 7), results)
]
estimates.append(
    {
        "term": "att_weighted",
        "estimate": weighted_effect,
        "se": None,
        "n_obs": sum(result[2] for result in results),
    }
)

output = {
    "task_id": "broad_cohort_stack",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {},
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
