import json

import numpy as np
import pandas as pd

data = pd.read_csv("input.csv")
data["date"] = pd.to_datetime(data["date"])
data = data.sort_values("date").reset_index(drop=True)

change = np.log(data["vix"]).diff()
regressors = {
    f"lag_{lag}": change.shift(lag)
    for lag in range(1, 16)
}
sample = pd.DataFrame(regressors)
sample["log_sales"] = np.log(data["sales"])
sample = sample.dropna().reset_index(drop=True)

N = len(sample)
p = 16
if N <= p:
    raise ValueError("The regression needs more than 16 complete observations.")

X = np.column_stack(
    [np.ones(N)] + [sample[f"lag_{lag}"].to_numpy() for lag in range(1, 16)]
)
y = sample["log_sales"].to_numpy()

coefficients = np.linalg.lstsq(X, y, rcond=None)[0]
residuals = y - X @ coefficients
scores = X * residuals[:, None]

meat = scores.T @ scores
for lag in range(1, 16):
    weight = 1 - lag / 16
    product = scores[lag:].T @ scores[:-lag]
    meat += weight * (product + product.T)

bread = np.linalg.inv(X.T @ X)
covariance = (N / (N - p)) * bread @ meat @ bread

contrast = np.r_[0.0, np.ones(15)]
cumulative_variance = float(contrast @ covariance @ contrast)

output = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {
            "term": "cumulative_response",
            "estimate": float(contrast @ coefficients),
            "se": float(np.sqrt(max(cumulative_variance, 0.0))),
            "n_obs": N,
        },
        {
            "term": "lag_1",
            "estimate": float(coefficients[1]),
            "se": float(np.sqrt(max(covariance[1, 1], 0.0))),
            "n_obs": N,
        },
        {
            "term": "lag_15",
            "estimate": float(coefficients[15]),
            "se": float(np.sqrt(max(covariance[15, 15], 0.0))),
            "n_obs": N,
        },
    ],
    "method_metadata": {
        "estimator": "OLS with intercept and 15 observed-row lags of log VIX changes",
        "vcov": "Newey-West Bartlett HAC, maximum lag 15, corrected by N/(N-16)",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
