import json

import numpy as np
import pandas as pd
import statsmodels.api as sm

data = pd.read_csv("input.csv", parse_dates=["date"]).sort_values("date")
log_sales = np.log(data["sales"].astype(float))
delta_log_vix = np.log(data["vix"].astype(float)).diff()

lags = pd.DataFrame(
    {f"lag_{k}": delta_log_vix.shift(k) for k in range(1, 16)}
)
sample = pd.concat([log_sales.rename("log_sales"), lags], axis=1).dropna()
n_obs = len(sample)

x = sm.add_constant(sample[[f"lag_{k}" for k in range(1, 16)]])
fit = sm.OLS(sample["log_sales"], x).fit()

# HAC with Bartlett weights and no automatic finite-sample adjustment.
cov = sm.stats.sandwich_covariance.cov_hac(
    fit, nlags=15, weights_func=sm.stats.sandwich_covariance.weights_bartlett,
    use_correction=False,
)
cov *= n_obs / (n_obs - 16)
cov = pd.DataFrame(cov, index=fit.params.index, columns=fit.params.index)

lag_names = [f"lag_{k}" for k in range(1, 16)]
cumulative_estimate = float(fit.params[lag_names].sum())
cumulative_variance = float(cov.loc[lag_names, lag_names].to_numpy().sum())

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {
            "term": "cumulative_response",
            "estimate": cumulative_estimate,
            "se": float(np.sqrt(max(cumulative_variance, 0.0))),
            "n_obs": n_obs,
        },
        {
            "term": "lag_1",
            "estimate": float(fit.params["lag_1"]),
            "se": float(np.sqrt(max(cov.loc["lag_1", "lag_1"], 0.0))),
            "n_obs": n_obs,
        },
        {
            "term": "lag_15",
            "estimate": float(fit.params["lag_15"]),
            "se": float(np.sqrt(max(cov.loc["lag_15", "lag_15"], 0.0))),
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "OLS of log(sales) on intercept and lags 1-15 of delta log(vix)",
        "vcov": "Newey-West HAC, Bartlett lag 15, multiplied by N/(N-16)",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output)
