import json

import numpy as np
import pandas as pd
from scipy.stats import f

data = pd.read_csv("input.csv")
n = len(data)

y = data["y"].to_numpy(dtype=float)
d = data["endog"].to_numpy(dtype=float)
x = data["x"].to_numpy(dtype=float)
z1 = data["z1"].to_numpy(dtype=float)
z2 = data["z2"].to_numpy(dtype=float)

restricted = np.column_stack((np.ones(n), x))
unrestricted = np.column_stack((np.ones(n), x, z1, z2))

def residuals(design, values):
    coefficients = np.linalg.lstsq(design, values, rcond=None)[0]
    return values - design @ coefficients

ry, rd = residuals(restricted, y), residuals(restricted, d)
uy, ud = residuals(unrestricted, y), residuals(unrestricted, d)

def ssr(residual_y, residual_d, beta):
    residual = residual_y - beta * residual_d
    return float(residual @ residual)

def ar_f(beta):
    restricted_ssr = ssr(ry, rd, beta)
    unrestricted_ssr = ssr(uy, ud, beta)
    return ((restricted_ssr - unrestricted_ssr) / 2) / (
        unrestricted_ssr / (n - 4)
    )

critical = f.ppf(0.95, 2, n - 4)
scale = 2 * critical / (n - 4)

# The test inequality is a quadratic in beta.
a = float(rd @ rd - (1 + scale) * (ud @ ud))
b = float(-2 * (ry @ rd - (1 + scale) * (uy @ ud)))
c = float(ry @ ry - (1 + scale) * (uy @ uy))

roots = np.roots([a, b, c])
if len(roots) != 2 or np.any(np.abs(roots.imag) > 1e-8):
    raise ValueError("Expected two finite real Anderson-Rubin boundaries.")

boundary_low, boundary_high = sorted(roots.real.tolist())
accepts_zero = float(c <= 0)
unbounded = float(a < 0)

terms = {
    "boundary_low": boundary_low,
    "boundary_high": boundary_high,
    "accepts_zero": accepts_zero,
    "unbounded": unbounded,
    "ar_f_at_one": ar_f(1.0),
}

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": [
        {"term": term, "estimate": value, "se": None, "n_obs": n}
        for term, value in terms.items()
    ],
    "method_metadata": {
        "estimator": "Anderson-Rubin confidence set by quadratic inversion",
        "vcov": "Conventional homoskedastic joint F test",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file)
