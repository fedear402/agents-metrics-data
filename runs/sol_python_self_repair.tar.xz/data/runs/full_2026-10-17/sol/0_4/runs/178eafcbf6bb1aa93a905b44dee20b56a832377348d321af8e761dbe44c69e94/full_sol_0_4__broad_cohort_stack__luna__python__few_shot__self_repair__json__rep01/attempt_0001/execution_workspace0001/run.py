import json

import numpy as np
import pandas as pd


def estimate_cohort(data, cohort):
    times = list(range(cohort - 2, cohort + 3))
    window = data.loc[data["time"].isin(times)].copy()
    window = window.loc[
        (window["g"] == cohort)
        | (window["g"] == 0)
        | (window["g"] > cohort + 2)
    ].copy()

    balanced_ids = window.groupby("id")["time"].nunique()
    balanced_ids = balanced_ids.index[balanced_ids == len(times)]
    window = window.loc[window["id"].isin(balanced_ids)].copy()

    window["did"] = (
        (window["g"] == cohort) & (window["time"] >= cohort)
    ).astype(float)

    def remove_fixed_effects(column):
        values = window[column].astype(float)
        return (
            values
            - values.groupby(window["id"]).transform("mean")
            - values.groupby(window["time"]).transform("mean")
            + values.mean()
        ).to_numpy()

    did_residual = remove_fixed_effects("did")
    y_residual = remove_fixed_effects("y")
    denominator = np.dot(did_residual, did_residual)
    if denominator == 0:
        raise ValueError(f"Cohort {cohort} has no identified DID coefficient")

    coefficient = np.dot(did_residual, y_residual) / denominator
    treated_count = window.loc[window["g"] == cohort, "id"].nunique()
    return float(coefficient), int(len(window)), int(treated_count)


data = pd.read_csv("input.csv")
results = {cohort: estimate_cohort(data, cohort) for cohort in (3, 5, 7)}

total_treated = sum(results[cohort][2] for cohort in (3, 5, 7))
weighted = sum(
    results[cohort][0] * results[cohort][2] for cohort in (3, 5, 7)
) / total_treated

estimates = [
    {
        "term": f"att_g{cohort}",
        "estimate": results[cohort][0],
        "se": None,
        "n_obs": results[cohort][1],
    }
    for cohort in (3, 5, 7)
]
estimates.append(
    {
        "term": "att_weighted",
        "estimate": float(weighted),
        "se": None,
        "n_obs": sum(results[cohort][1] for cohort in (3, 5, 7)),
    }
)

with open("result.json", "w", encoding="utf-8") as stream:
    json.dump(
        {
            "task_id": "broad_cohort_stack",
            "platform": "python",
            "estimates": estimates,
            "method_metadata": {},
            "diagnostics": {},
        },
        stream,
        indent=2,
        allow_nan=False,
    )
