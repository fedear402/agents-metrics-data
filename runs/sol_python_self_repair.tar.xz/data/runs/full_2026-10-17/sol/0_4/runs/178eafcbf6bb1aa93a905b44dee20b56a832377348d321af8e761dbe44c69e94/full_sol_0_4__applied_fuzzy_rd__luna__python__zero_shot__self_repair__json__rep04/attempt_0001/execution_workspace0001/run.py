import json

import numpy as np
import pandas as pd

data = pd.read_csv("input.csv")
sample = data.loc[data["score"].abs() < 1].copy()

x = sample["score"].to_numpy(dtype=float)
right = (x >= 0).astype(float)
weights = 1 - np.abs(x)
X = np.column_stack((np.ones(len(x)), x, right, right * x))
Y = sample[["earnings", "participated"]].to_numpy(dtype=float)

bread = np.linalg.inv(X.T @ (weights[:, None] * X))
coefficients = bread @ (X.T @ (weights[:, None] * Y))
residuals = Y - X @ coefficients

# HC0 covariance for the two discontinuities, including their covariance.
influence = (weights[:, None] * residuals) * (X @ bread[:, 2])[:, None]
joint_cov = influence.T @ influence

reduced_form = float(coefficients[2, 0])
first_stage = float(coefficients[2, 1])
treatment_effect = reduced_form / first_stage

gradient = np.array([1 / first_stage, -reduced_form / first_stage**2])
effect_variance = float(gradient @ joint_cov @ gradient)
n_obs = len(sample)

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {
            "term": "treatment_effect",
            "estimate": float(treatment_effect),
            "se": float(np.sqrt(max(effect_variance, 0))),
            "n_obs": n_obs,
        },
        {
            "term": "reduced_form",
            "estimate": reduced_form,
            "se": float(np.sqrt(max(joint_cov[0, 0], 0))),
            "n_obs": n_obs,
        },
        {
            "term": "first_stage",
            "estimate": first_stage,
            "se": float(np.sqrt(max(joint_cov[1, 1], 0))),
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "Fuzzy local-linear regression discontinuity, triangular kernel, bandwidth 1",
        "vcov": "Joint heteroskedasticity-robust HC0 sandwich; delta method for ratio",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output)
