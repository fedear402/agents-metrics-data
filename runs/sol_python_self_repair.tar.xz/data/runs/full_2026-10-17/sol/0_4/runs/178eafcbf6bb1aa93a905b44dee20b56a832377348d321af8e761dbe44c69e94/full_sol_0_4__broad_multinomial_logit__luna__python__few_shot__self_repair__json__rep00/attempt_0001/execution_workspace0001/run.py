import json

import numpy as np
import pandas as pd
import statsmodels.api as sm


data = pd.read_csv("input.csv")
outcomes = [0, 1, 2]
if sorted(data["y"].unique().tolist()) != outcomes:
    raise ValueError("y must contain outcomes 0, 1, and 2")

X = sm.add_constant(data[["x", "z"]], has_constant="add")
fit = sm.MNLogit(data["y"], X).fit(disp=False, maxiter=1000, tol=1e-12)

# Parameter columns 0 and 1 represent outcomes 1 and 2.
coefficients = fit.params.copy()
errors = fit.bse.copy()
coefficients.columns = [1, 2]
errors.columns = [1, 2]

zero = pd.DataFrame({"const": [1.0], "x": [0.0], "z": [0.0]})
prob_cat2_zero = float(np.asarray(fit.predict(zero))[0, 2])
n_obs = int(len(data))

def row(term, estimate, se):
    return {
        "term": term,
        "estimate": float(estimate),
        "se": None if se is None else float(se),
        "n_obs": n_obs,
    }

result = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": [
        row("x_cat1", coefficients.loc["x", 1], errors.loc["x", 1]),
        row("z_cat1", coefficients.loc["z", 1], errors.loc["z", 1]),
        row("x_cat2", coefficients.loc["x", 2], errors.loc["x", 2]),
        row("z_cat2", coefficients.loc["z", 2], errors.loc["z", 2]),
        row("prob_cat2_zero", prob_cat2_zero, None),
    ],
    "method_metadata": {
        "estimator": "multinomial logit maximum likelihood",
        "vcov": "inverse observed information",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
