import json

import pandas as pd
import statsmodels.api as sm

data = pd.read_csv("input.csv")
n_obs = len(data)

X = sm.add_constant(data[["x", "z"]], has_constant="add")
model = sm.MNLogit(data["y"], X)
fit = model.fit(method="newton", disp=False)

params = fit.params
standard_errors = fit.bse
outcomes = [int(value) for value in model._ynames_map.values()]
nonbase_outcomes = [value for value in outcomes if value != 0]
column_for_outcome = {
    outcome: column for column, outcome in zip(params.columns, nonbase_outcomes)
}

def slope_row(variable, outcome):
    column = column_for_outcome[outcome]
    return {
        "term": f"{variable}_cat{outcome}",
        "estimate": float(params.loc[variable, column]),
        "se": float(standard_errors.loc[variable, column]),
        "n_obs": n_obs,
    }

zero_point = pd.DataFrame({"const": [1.0], "x": [0.0], "z": [0.0]})
zero_point = zero_point[X.columns]
probabilities = fit.predict(zero_point)
prob_cat2_zero = float(probabilities.iloc[0, outcomes.index(2)])

result = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": [
        slope_row("x", 1),
        slope_row("z", 1),
        slope_row("x", 2),
        slope_row("z", 2),
        {
            "term": "prob_cat2_zero",
            "estimate": prob_cat2_zero,
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "Multinomial logit maximum likelihood, outcome 0 base",
        "vcov": "Inverse observed information",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file, indent=2)
