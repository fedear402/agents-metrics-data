import json

import numpy as np
import pandas as pd


data = pd.read_csv("input.csv")
estimates = []
treated_counts = []
row_counts = []

for cohort in (3, 5, 7):
    window = list(range(cohort - 2, cohort + 3))
    eligible = data[
        data["time"].isin(window)
        & (
            (data["g"] == cohort)
            | (data["g"] == 0)
            | (data["g"] > cohort + 2)
        )
    ].copy()

    complete_ids = (
        eligible.groupby("id")["time"]
        .nunique()
        .loc[lambda counts: counts == len(window)]
        .index
    )
    sample = eligible[eligible["id"].isin(complete_ids)].copy()
    sample["did"] = (
        (sample["g"] == cohort) & (sample["time"] >= cohort)
    ).astype(float)

    # A balanced panel permits two-way demeaning for unit and time effects.
    for column in ("did", "y"):
        sample[f"{column}_residual"] = (
            sample[column]
            - sample.groupby("id")[column].transform("mean")
            - sample.groupby("time")[column].transform("mean")
            + sample[column].mean()
        )

    did_residual = sample["did_residual"].to_numpy()
    y_residual = sample["y_residual"].to_numpy()
    coefficient = float(
        np.dot(did_residual, y_residual)
        / np.dot(did_residual, did_residual)
    )

    n_obs = len(sample)
    n_treated = sample.loc[sample["g"] == cohort, "id"].nunique()
    estimates.append({
        "term": f"att_g{cohort}",
        "estimate": coefficient,
        "se": None,
        "n_obs": n_obs,
    })
    treated_counts.append(n_treated)
    row_counts.append(n_obs)

weighted = float(
    np.average(
        [row["estimate"] for row in estimates],
        weights=treated_counts,
    )
)
estimates.append({
    "term": "att_weighted",
    "estimate": weighted,
    "se": None,
    "n_obs": sum(row_counts),
})

result = {
    "task_id": "broad_cohort_stack",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {},
    "diagnostics": {},
}
with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
