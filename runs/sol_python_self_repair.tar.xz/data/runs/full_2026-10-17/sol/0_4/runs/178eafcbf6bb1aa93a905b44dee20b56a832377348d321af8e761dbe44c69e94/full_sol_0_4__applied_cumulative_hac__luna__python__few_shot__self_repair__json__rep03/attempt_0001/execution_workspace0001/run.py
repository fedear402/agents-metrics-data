import json

import numpy as np
import pandas as pd

data = pd.read_csv("input.csv", parse_dates=["date"])
data = data.sort_values("date").reset_index(drop=True)

change = np.log(data["vix"]).diff()
lag_columns = [f"lag_{i}" for i in range(1, 16)]
for i, column in enumerate(lag_columns, start=1):
    data[column] = change.shift(i)

data["log_sales"] = np.log(data["sales"])
sample = data.dropna(subset=["log_sales", *lag_columns])
N = len(sample)

X = np.column_stack(
    [np.ones(N), sample[lag_columns].to_numpy(dtype=float)]
)
y = sample["log_sales"].to_numpy(dtype=float)

coefficients = np.linalg.lstsq(X, y, rcond=None)[0]
residuals = y - X @ coefficients
scores = X * residuals[:, None]

meat = scores.T @ scores
for j in range(1, 16):
    weight = 1.0 - j / 16.0
    lag_product = scores[j:].T @ scores[:-j]
    meat += weight * (lag_product + lag_product.T)

bread = np.linalg.inv(X.T @ X)
covariance = (N / (N - 16)) * bread @ meat @ bread

contrast = np.r_[0.0, np.ones(15)]
cumulative_estimate = float(contrast @ coefficients)
cumulative_se = float(np.sqrt(contrast @ covariance @ contrast))

output = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {
            "term": "cumulative_response",
            "estimate": cumulative_estimate,
            "se": cumulative_se,
            "n_obs": N,
        },
        {
            "term": "lag_1",
            "estimate": float(coefficients[1]),
            "se": float(np.sqrt(covariance[1, 1])),
            "n_obs": N,
        },
        {
            "term": "lag_15",
            "estimate": float(coefficients[15]),
            "se": float(np.sqrt(covariance[15, 15])),
            "n_obs": N,
        },
    ],
    "method_metadata": {
        "estimator": "OLS with intercept and 15 lagged log-vix changes",
        "vcov": "Newey-West Bartlett HAC, max lag 15, multiplied by N/(N-16)",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
