import json

import numpy as np
import pandas as pd


data = pd.read_csv("input.csv")
estimates = []
weighted_sum = 0.0
total_treated_units = 0
total_rows = 0

for cohort in (3, 5, 7):
    window = data["time"].between(cohort - 2, cohort + 2)
    eligible = (data["g"] == cohort) | (data["g"] == 0) | (
        data["g"] > cohort + 2
    )
    comparison = data.loc[window & eligible].copy()

    complete_units = comparison.groupby("id")["time"].nunique()
    complete_units = complete_units.index[complete_units == 5]
    comparison = comparison[comparison["id"].isin(complete_units)].copy()

    comparison["did"] = (
        (comparison["g"] == cohort) & (comparison["time"] >= cohort)
    ).astype(float)

    unit_effects = pd.get_dummies(comparison["id"], drop_first=True)
    time_effects = pd.get_dummies(comparison["time"], drop_first=True)
    design = np.column_stack(
        (
            np.ones(len(comparison)),
            comparison["did"].to_numpy(),
            unit_effects.to_numpy(),
            time_effects.to_numpy(),
        )
    ).astype(float)

    coefficient = float(
        np.linalg.lstsq(
            design, comparison["y"].to_numpy(dtype=float), rcond=None
        )[0][1]
    )
    treated_units = comparison.loc[
        comparison["g"] == cohort, "id"
    ].nunique()
    row_count = len(comparison)

    estimates.append(
        {
            "term": f"att_g{cohort}",
            "estimate": coefficient,
            "se": None,
            "n_obs": row_count,
        }
    )
    weighted_sum += treated_units * coefficient
    total_treated_units += treated_units
    total_rows += row_count

estimates.append(
    {
        "term": "att_weighted",
        "estimate": weighted_sum / total_treated_units,
        "se": None,
        "n_obs": total_rows,
    }
)

result = {
    "task_id": "broad_cohort_stack",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {},
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output, indent=2)
