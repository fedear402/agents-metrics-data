import json

import numpy as np
import pandas as pd


TASK_ID = "applied_multivintage_trade_iv"

crosswalk = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv")
areas = pd.read_csv("areas.csv")
employment = pd.read_csv("employment.csv")
outcomes = pd.read_csv("outcomes.csv")

trade = trade.merge(crosswalk, on="code", how="left", validate="many_to_one")

def make_exposure(vintage, change_column):
    area_rows = areas.loc[
        areas["vintage"].eq(vintage),
        ["area", "period", "total_employment", "population"],
    ].copy()

    national = (
        employment.loc[employment["vintage"].eq(vintage)]
        .groupby(["period", "industry"], as_index=False)["employment"]
        .sum()
        .rename(columns={"employment": "national_employment"})
    )

    shocks = trade.merge(
        national, on=["period", "industry"], validate="many_to_one"
    )
    shocks["shock"] = (
        shocks[change_column]
        / shocks["national_employment"]
        / (shocks["price_index"] / 100)
        / 1000
        * (10 / shocks["years"])
    )

    cells = area_rows[["area", "period"]].merge(
        shocks[["period", "industry", "shock"]],
        on="period",
        how="left",
        validate="many_to_many",
    )
    cells = cells.merge(
        employment.loc[
            employment["vintage"].eq(vintage),
            ["area", "period", "industry", "employment"],
        ],
        on=["area", "period", "industry"],
        how="left",
        validate="one_to_one",
    )
    cells["employment"] = cells["employment"].fillna(0)
    cells["contribution"] = cells["employment"] * cells["shock"]

    exposure = (
        cells.groupby(["area", "period"], as_index=False)["contribution"]
        .sum()
        .merge(
            area_rows,
            on=["area", "period"],
            validate="one_to_one",
        )
    )
    exposure["exposure"] = (
        exposure["contribution"] / exposure["total_employment"]
    )
    return exposure[["area", "period", "exposure", "population"]]


base = make_exposure("base", "us_change").rename(
    columns={"exposure": "x"}
)
early = make_exposure("early", "other_change")[
    ["area", "period", "exposure"]
].rename(columns={"exposure": "z"})

data = (
    outcomes.merge(
        base, on=["area", "period"], validate="one_to_one"
    )
    .merge(
        early, on=["area", "period"], validate="one_to_one"
    )
    .sort_values(["period", "area"])
    .reset_index(drop=True)
)

n_obs = int(len(data))
if n_obs != 72:
    raise ValueError(f"Expected 72 estimation rows; found {n_obs}.")

y = data["change_pp"].to_numpy(dtype=float)
weights = data["population"].to_numpy(dtype=float)
exogenous = np.column_stack(
    (
        np.ones(n_obs),
        data["period"].to_numpy(dtype=float),
        data["control"].to_numpy(dtype=float),
    )
)
regressors = np.column_stack(
    (exogenous, data["x"].to_numpy(dtype=float))
)
instruments = np.column_stack(
    (exogenous, data["z"].to_numpy(dtype=float))
)

sqrt_weights = np.sqrt(weights)
yw = y * sqrt_weights
xw = regressors * sqrt_weights[:, None]
zw = instruments * sqrt_weights[:, None]

projected_x = zw @ np.linalg.solve(zw.T @ zw, zw.T @ xw)
coefficients = np.linalg.solve(projected_x.T @ xw, projected_x.T @ yw)

def selected_value(column, area, period):
    values = data.loc[
        data["area"].eq(area) & data["period"].eq(period), column
    ]
    if len(values) != 1:
        raise ValueError(f"Expected one row for area {area}, period {period}.")
    return float(values.iloc[0])


values = {
    "iv_slope": float(coefficients[-1]),
    "exposure_area0_period0": selected_value("x", 0, 0),
    "exposure_area0_period1": selected_value("x", 0, 1),
    "instrument_area0_period0": selected_value("z", 0, 0),
}

result = {
    "task_id": TASK_ID,
    "platform": "python",
    "estimates": [
        {
            "term": term,
            "estimate": estimate,
            "se": None,
            "n_obs": n_obs,
        }
        for term, estimate in values.items()
    ],
    "method_metadata": {
        "estimator": "weighted two-stage least squares",
        "outcome": "change_pp",
        "endogenous_regressor": "x",
        "excluded_instrument": "z",
        "exogenous_columns": ["intercept", "period", "control"],
        "weight": "base-vintage population",
        "exposure_unit": "thousands of real dollars per worker per decade",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "n_industries": int(crosswalk["industry"].nunique()),
        "n_periods": int(data["period"].nunique()),
    },
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file, indent=2, allow_nan=False)
