import json

import pandas as pd
from statsmodels.tsa.arima.model import ARIMA


data = pd.read_csv("./input.csv").sort_values("t")
y = pd.to_numeric(data["y"], errors="raise")
if y.isna().any():
    raise ValueError("The y series contains missing values.")

model = ARIMA(y, order=(1, 1, 1), trend="n")
fit = model.fit()
prediction = fit.get_forecast(steps=1)
interval = prediction.conf_int(alpha=0.05).iloc[0]

result = {
    "task_id": "arima_forecast",
    "platform": "python",
    "estimates": [
        {
            "term": "forecast",
            "estimate": float(prediction.predicted_mean.iloc[0]),
            "se": float(prediction.se_mean.iloc[0]),
            "n_obs": int(len(y)),
        },
        {
            "term": "lower_95",
            "estimate": float(interval.iloc[0]),
            "se": None,
            "n_obs": int(len(y)),
        },
        {
            "term": "upper_95",
            "estimate": float(interval.iloc[1]),
            "se": None,
            "n_obs": int(len(y)),
        },
    ],
    "method_metadata": {
        "estimator": "ARIMA(1,1,1) maximum likelihood, no constant or drift",
        "vcov": "Model-based forecast variance",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output, allow_nan=False)
