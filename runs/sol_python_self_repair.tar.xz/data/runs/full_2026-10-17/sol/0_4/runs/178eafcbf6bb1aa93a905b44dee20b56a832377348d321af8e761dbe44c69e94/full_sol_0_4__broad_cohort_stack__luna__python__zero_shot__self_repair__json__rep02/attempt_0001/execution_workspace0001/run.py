import csv
import json
from collections import defaultdict

with open("input.csv", newline="") as file:
    rows = [
        {
            "id": row["id"],
            "time": int(row["time"]),
            "g": int(row["g"]),
            "y": float(row["y"]),
        }
        for row in csv.DictReader(file)
    ]

by_unit = defaultdict(dict)
for row in rows:
    by_unit[row["id"]][row["time"]] = row

estimates = []
weighted_sum = 0.0
total_treated_units = 0
total_rows = 0

for cohort in (3, 5, 7):
    times = tuple(range(cohort - 2, cohort + 3))
    units = []

    for unit_id, observations in by_unit.items():
        if not all(time in observations for time in times):
            continue
        g = observations[times[0]]["g"]
        if g == cohort or g == 0 or g > cohort + 2:
            units.append(unit_id)

    panel = []
    for unit_id in units:
        for time in times:
            row = by_unit[unit_id][time]
            panel.append(
                (
                    unit_id,
                    time,
                    row["y"],
                    float(row["g"] == cohort and time >= cohort),
                )
            )

    unit_means = {}
    for unit_id in units:
        unit_rows = [row for row in panel if row[0] == unit_id]
        unit_means[unit_id] = (
            sum(row[2] for row in unit_rows) / 5,
            sum(row[3] for row in unit_rows) / 5,
        )

    time_means = {}
    for time in times:
        time_rows = [row for row in panel if row[1] == time]
        time_means[time] = (
            sum(row[2] for row in time_rows) / len(time_rows),
            sum(row[3] for row in time_rows) / len(time_rows),
        )

    overall_y = sum(row[2] for row in panel) / len(panel)
    overall_did = sum(row[3] for row in panel) / len(panel)

    numerator = 0.0
    denominator = 0.0
    for unit_id, time, y, did in panel:
        residual_y = (
            y - unit_means[unit_id][0] - time_means[time][0] + overall_y
        )
        residual_did = (
            did - unit_means[unit_id][1] - time_means[time][1] + overall_did
        )
        numerator += residual_did * residual_y
        denominator += residual_did * residual_did

    estimate = numerator / denominator
    treated_units = sum(
        by_unit[unit_id][times[0]]["g"] == cohort for unit_id in units
    )
    n_obs = len(panel)

    estimates.append(
        {
            "term": f"att_g{cohort}",
            "estimate": estimate,
            "se": None,
            "n_obs": n_obs,
        }
    )
    weighted_sum += treated_units * estimate
    total_treated_units += treated_units
    total_rows += n_obs

estimates.append(
    {
        "term": "att_weighted",
        "estimate": weighted_sum / total_treated_units,
        "se": None,
        "n_obs": total_rows,
    }
)

result = {
    "task_id": "broad_cohort_stack",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {},
    "diagnostics": {},
}

with open("result.json", "w") as file:
    json.dump(result, file, indent=2)
