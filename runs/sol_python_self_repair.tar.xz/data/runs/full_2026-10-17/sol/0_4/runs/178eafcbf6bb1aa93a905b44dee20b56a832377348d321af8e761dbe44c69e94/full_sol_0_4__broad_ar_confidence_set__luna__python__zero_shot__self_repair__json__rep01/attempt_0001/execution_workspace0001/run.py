import json

import numpy as np
import pandas as pd
from scipy.stats import f

data = pd.read_csv("input.csv")
n = len(data)

y = data["y"].to_numpy(dtype=float)
d = data["endog"].to_numpy(dtype=float)
x = data["x"].to_numpy(dtype=float)
z = data[["z1", "z2"]].to_numpy(dtype=float)

controls = np.column_stack((np.ones(n), x))
full = np.column_stack((controls, z))

def residual(vector, design):
    coefficients = np.linalg.lstsq(design, vector, rcond=None)[0]
    return vector - design @ coefficients

ry = residual(y, controls)
rd = residual(d, controls)
ey = residual(y, full)
ed = residual(d, full)

def quadratic_norm(a, b):
    return np.array([b @ b, -2.0 * (a @ b), a @ a])

restricted_ss = quadratic_norm(ry, rd)
unrestricted_ss = quadratic_norm(ey, ed)
explained_ss = restricted_ss - unrestricted_ss

critical = f.ppf(0.95, 2, n - 4)
test_polynomial = (n - 4) * explained_ss - 2 * critical * unrestricted_ss

roots = np.sort(np.roots(test_polynomial))
if len(roots) != 2 or np.any(np.abs(roots.imag) > 1e-8):
    raise ValueError("Expected two finite real confidence-set boundaries.")

boundary_low, boundary_high = roots.real
accepts_zero = float(np.polyval(test_polynomial, 0.0) <= 0.0)
unbounded = float(test_polynomial[0] < 0.0)

q_one = np.polyval(explained_ss, 1.0)
sse_one = np.polyval(unrestricted_ss, 1.0)
ar_f_at_one = (q_one / 2.0) / (sse_one / (n - 4))

values = {
    "boundary_low": boundary_low,
    "boundary_high": boundary_high,
    "accepts_zero": accepts_zero,
    "unbounded": unbounded,
    "ar_f_at_one": ar_f_at_one,
}

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": [
        {
            "term": term,
            "estimate": float(value),
            "se": None,
            "n_obs": n,
        }
        for term, value in values.items()
    ],
    "method_metadata": {
        "estimator": "Anderson-Rubin confidence set by exact quadratic inversion",
        "vcov": "Conventional homoskedastic OLS F test",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output)
