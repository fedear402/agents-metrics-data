import json

import pandas as pd
from scipy import stats

data = pd.read_csv("./input.csv")[["group", "y"]].dropna()
data["y"] = pd.to_numeric(data["y"], errors="raise")

groups = [part["y"].to_numpy() for _, part in data.groupby("group")]
n_obs = len(data)
df_num = len(groups) - 1
df_den = n_obs - len(groups)
f_stat, p_value = stats.f_oneway(*groups)

result = {
    "task_id": "anova_oneway",
    "platform": "python",
    "estimates": [
        {"term": "F", "estimate": float(f_stat), "se": None, "n_obs": n_obs},
        {"term": "df_num", "estimate": float(df_num), "se": None, "n_obs": n_obs},
        {"term": "df_den", "estimate": float(df_den), "se": None, "n_obs": n_obs},
        {"term": "p_value", "estimate": float(p_value), "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "One-way ANOVA",
        "vcov": "Classical equal-variance",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output)
