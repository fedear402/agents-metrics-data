import json

import numpy as np
import pandas as pd


TASK_ID = "applied_multivintage_trade_iv"


def main():
    crosswalk = pd.read_csv("crosswalk.csv")
    trade = pd.read_csv("trade.csv")
    areas = pd.read_csv("areas.csv")
    employment = pd.read_csv("employment.csv")
    outcomes = pd.read_csv("outcomes.csv")

    trade = trade.merge(crosswalk, on="code", how="left", validate="many_to_one")
    if trade["industry"].isna().any():
        raise ValueError("Every trade code must map to an industry.")

    keys = ["area", "period", "vintage"]
    industries = sorted(crosswalk["industry"].unique())
    grid = areas[keys].merge(pd.DataFrame({"industry": industries}), how="cross")
    cells = grid.merge(
        employment[keys + ["industry", "employment"]],
        on=keys + ["industry"],
        how="left",
        validate="one_to_one",
    )
    cells["employment"] = cells["employment"].fillna(0.0)

    national = (
        cells.groupby(["period", "vintage", "industry"], as_index=False)["employment"]
        .sum()
        .rename(columns={"employment": "national_employment"})
    )
    cells = cells.merge(
        areas[keys + ["total_employment"]],
        on=keys,
        validate="many_to_one",
    ).merge(
        national,
        on=["period", "vintage", "industry"],
        validate="many_to_one",
    ).merge(
        trade[
            ["period", "industry", "us_change", "other_change", "price_index", "years"]
        ],
        on=["period", "industry"],
        validate="many_to_one",
    )

    change = np.where(
        cells["vintage"].eq("base"),
        cells["us_change"],
        cells["other_change"],
    )
    cells["component"] = (
        (cells["employment"] / cells["total_employment"])
        * (change / cells["national_employment"])
        / (cells["price_index"] / 100.0)
        / 1000.0
        * (10.0 / cells["years"])
    )

    exposure = (
        cells.groupby(keys, as_index=False)["component"]
        .sum()
        .pivot(index=["area", "period"], columns="vintage", values="component")
        .rename(columns={"base": "x", "early": "z"})
        .reset_index()
    )
    base_areas = areas.loc[
        areas["vintage"].eq("base"), ["area", "period", "population"]
    ]
    sample = (
        outcomes.merge(exposure, on=["area", "period"], validate="one_to_one")
        .merge(base_areas, on=["area", "period"], validate="one_to_one")
        .sort_values(["area", "period"])
        .reset_index(drop=True)
    )

    n_obs = len(sample)
    if n_obs != 72:
        raise ValueError(f"Expected 72 area-period rows, found {n_obs}.")

    y = sample["change_pp"].to_numpy(dtype=float)
    period = pd.to_numeric(sample["period"], errors="raise").to_numpy(dtype=float)
    control = sample["control"].to_numpy(dtype=float)
    x = sample["x"].to_numpy(dtype=float)
    z = sample["z"].to_numpy(dtype=float)
    weights = sample["population"].to_numpy(dtype=float)

    regressors = np.column_stack((np.ones(n_obs), period, control, x))
    instruments = np.column_stack((np.ones(n_obs), period, control, z))
    sqrt_weights = np.sqrt(weights)
    yw = y * sqrt_weights
    Xw = regressors * sqrt_weights[:, None]
    Zw = instruments * sqrt_weights[:, None]

    # With equal numbers of regressors and instruments, weighted 2SLS
    # solves the weighted instrument moment equations.
    coefficients = np.linalg.solve(Zw.T @ Xw, Zw.T @ yw)

    def value(area, period_id, column):
        rows = sample.loc[
            sample["area"].eq(area) & sample["period"].eq(period_id), column
        ]
        if len(rows) != 1:
            raise ValueError(f"Expected one row for area {area}, period {period_id}.")
        return float(rows.iloc[0])

    estimates = [
        {"term": "iv_slope", "estimate": float(coefficients[-1]), "se": None, "n_obs": n_obs},
        {
            "term": "exposure_area0_period0",
            "estimate": value(0, 0, "x"),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "exposure_area0_period1",
            "estimate": value(0, 1, "x"),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "instrument_area0_period0",
            "estimate": value(0, 0, "z"),
            "se": None,
            "n_obs": n_obs,
        },
    ]

    result = {
        "task_id": TASK_ID,
        "platform": "python",
        "estimates": estimates,
        "method_metadata": {
            "estimator": "population-weighted 2SLS",
            "dependent_variable": "change_pp",
            "regressors": ["intercept", "period", "control", "x"],
            "instruments": ["intercept", "period", "control", "z"],
            "weight": "base-vintage population",
            "exposure_units": "thousands of real dollars per worker per decade",
        },
        "diagnostics": {
            "n_obs": n_obs,
            "n_industries": len(industries),
            "regressor_rank": int(np.linalg.matrix_rank(Xw)),
            "instrument_rank": int(np.linalg.matrix_rank(Zw)),
        },
    }
    with open("result.json", "w", encoding="utf-8") as output:
        json.dump(result, output, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
