import json

import numpy as np
import pandas as pd


TASK_ID = "applied_multivintage_trade_iv"
N_OBS = 72
INDUSTRIES = 4


def make_exposure(areas, employment, trade, vintage, change_column):
    area_rows = areas.loc[
        areas["vintage"].eq(vintage),
        ["area", "period", "total_employment"],
    ].copy()

    cells = area_rows[["area", "period"]].merge(
        trade[["period", "industry"]].drop_duplicates(),
        on="period",
        how="inner",
        validate="many_to_many",
    )
    cells = cells.merge(
        employment.loc[
            employment["vintage"].eq(vintage),
            ["area", "period", "industry", "employment"],
        ],
        on=["area", "period", "industry"],
        how="left",
        validate="one_to_one",
    )
    cells["employment"] = cells["employment"].fillna(0.0)

    national = (
        cells.groupby(["period", "industry"], as_index=False)["employment"]
        .sum()
        .rename(columns={"employment": "national_employment"})
    )
    cells = cells.merge(
        national, on=["period", "industry"], validate="many_to_one"
    )
    cells = cells.merge(
        trade[
            ["period", "industry", change_column, "price_index", "years"]
        ],
        on=["period", "industry"],
        validate="many_to_one",
    )
    cells = cells.merge(
        area_rows,
        on=["area", "period"],
        validate="many_to_one",
    )

    cells["contribution"] = (
        cells["employment"]
        / cells["total_employment"]
        * cells[change_column]
        / cells["national_employment"]
        / (cells["price_index"] / 100.0)
        / 1000.0
        * (10.0 / cells["years"])
    )
    return cells.groupby(["area", "period"], as_index=False)[
        "contribution"
    ].sum()


def main():
    crosswalk = pd.read_csv("crosswalk.csv")
    trade = pd.read_csv("trade.csv").merge(
        crosswalk, on="code", validate="many_to_one"
    )
    areas = pd.read_csv("areas.csv")
    employment = pd.read_csv("employment.csv")
    outcomes = pd.read_csv("outcomes.csv")

    assert crosswalk["industry"].nunique() == INDUSTRIES

    x = make_exposure(
        areas, employment, trade, "base", "us_change"
    ).rename(columns={"contribution": "x"})
    z = make_exposure(
        areas, employment, trade, "early", "other_change"
    ).rename(columns={"contribution": "z"})

    base_population = areas.loc[
        areas["vintage"].eq("base"), ["area", "period", "population"]
    ]
    sample = (
        outcomes.merge(x, on=["area", "period"], validate="one_to_one")
        .merge(z, on=["area", "period"], validate="one_to_one")
        .merge(
            base_population,
            on=["area", "period"],
            validate="one_to_one",
        )
    )
    assert len(sample) == N_OBS
    assert sample[
        ["change_pp", "control", "x", "z", "population"]
    ].notna().all().all()
    assert (sample["population"] > 0).all()

    period_values = sorted(sample["period"].unique())
    assert len(period_values) == 2
    period_indicator = sample["period"].eq(period_values[1]).to_numpy(
        dtype=float
    )

    exogenous = np.column_stack(
        [
            np.ones(N_OBS),
            period_indicator,
            sample["control"].to_numpy(dtype=float),
        ]
    )
    x_matrix = np.column_stack(
        [exogenous, sample["x"].to_numpy(dtype=float)]
    )
    instruments = np.column_stack(
        [exogenous, sample["z"].to_numpy(dtype=float)]
    )
    outcome = sample["change_pp"].to_numpy(dtype=float)
    sqrt_weight = np.sqrt(sample["population"].to_numpy(dtype=float))

    weighted_x = x_matrix * sqrt_weight[:, None]
    weighted_z = instruments * sqrt_weight[:, None]
    weighted_y = outcome * sqrt_weight

    if np.linalg.matrix_rank(weighted_z) != 4:
        raise ValueError("The instrument matrix is rank deficient.")

    projected_x = weighted_z @ np.linalg.lstsq(
        weighted_z, weighted_x, rcond=None
    )[0]
    if np.linalg.matrix_rank(projected_x) != 4:
        raise ValueError("The weighted 2SLS design is rank deficient.")

    coefficients = np.linalg.lstsq(
        projected_x, weighted_y, rcond=None
    )[0]

    def value(frame, area, period, column):
        selected = frame.loc[
            frame["area"].eq(area) & frame["period"].eq(period),
            column,
        ]
        if len(selected) != 1:
            raise ValueError("Expected one area-period exposure.")
        return float(selected.iloc[0])

    estimates = [
        ("iv_slope", float(coefficients[-1])),
        ("exposure_area0_period0", value(x, 0, 0, "x")),
        ("exposure_area0_period1", value(x, 0, 1, "x")),
        ("instrument_area0_period0", value(z, 0, 0, "z")),
    ]

    result = {
        "task_id": TASK_ID,
        "platform": "python",
        "estimates": [
            {
                "term": term,
                "estimate": estimate,
                "se": None,
                "n_obs": N_OBS,
            }
            for term, estimate in estimates
        ],
        "method_metadata": {
            "estimator": "population-weighted two-stage least squares",
            "regressors": ["intercept", "period", "control", "x"],
            "instruments": ["intercept", "period", "control", "z"],
            "weight": "base-vintage population",
            "exposure_unit": "thousands of real dollars per worker per decade",
        },
        "diagnostics": {
            "estimation_rows": N_OBS,
            "industries": INDUSTRIES,
            "instrument_rank": int(np.linalg.matrix_rank(weighted_z)),
        },
    }

    with open("result.json", "w", encoding="utf-8") as output:
        json.dump(result, output, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
