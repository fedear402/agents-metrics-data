import json

import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS


households = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

sample = households.loc[households["recipient"] == 0].copy()
n_obs = int(len(sample))

ineligible = (sample["eligible"] == 0).astype(float)
eligible = (sample["eligible"] == 1).astype(float)

exog = pd.DataFrame(
    {
        "ineligible": ineligible,
        "eligible": eligible,
        "baseline_ineligible": sample["baseline"] * ineligible,
        "baseline_eligible": sample["baseline"] * eligible,
    },
    index=sample.index,
)
endog = pd.DataFrame(
    {
        "dose_ineligible": sample["dose"] * ineligible,
        "dose_eligible": sample["dose"] * eligible,
    },
    index=sample.index,
)
excluded_instruments = pd.DataFrame(
    {
        "instrument_ineligible": sample["instrument"] * ineligible,
        "instrument_eligible": sample["instrument"] * eligible,
    },
    index=sample.index,
)

fit = IV2SLS(
    dependent=sample["outcome"],
    exog=exog,
    endog=endog,
    instruments=excluded_instruments,
    weights=sample["weight"],
).fit()

effects = {}
weighted_mean_dose = {}
for group, slope_name in ((0, "dose_ineligible"), (1, "dose_eligible")):
    group_sample = sample.loc[sample["eligible"] == group]
    weighted_mean_dose[group] = float(
        np.average(group_sample["dose"], weights=group_sample["weight"])
    )
    effects[group] = float(fit.params[slope_name] * weighted_mean_dose[group])

population = census.groupby("eligible")["nonrecipient_population"].sum()
population_effect = float(
    np.average(
        [effects[0], effects[1]],
        weights=[population.loc[0], population.loc[1]],
    )
)

estimates = [
    {
        "term": "ineligible_effect",
        "estimate": effects[0],
        "se": None,
        "n_obs": n_obs,
    },
    {
        "term": "eligible_nonrecipient_effect",
        "estimate": effects[1],
        "se": None,
        "n_obs": n_obs,
    },
    {
        "term": "population_effect",
        "estimate": population_effect,
        "se": None,
        "n_obs": n_obs,
    },
]

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "sample": "All households with recipient equal to zero, in both village treatment statuses",
        "endogenous_columns": ["dose_ineligible", "dose_eligible"],
        "exogenous_columns": [
            "ineligible",
            "eligible",
            "baseline_ineligible",
            "baseline_eligible",
        ],
        "excluded_instruments": [
            "instrument_ineligible",
            "instrument_eligible",
        ],
        "additional_intercept": False,
        "regression_weight": "weight",
        "group_effect": "Fitted group dose slope times the household-weighted mean dose for that group",
        "population_aggregation": "Group effects weighted by census nonrecipient_population",
        "counterfactual": "Dose is zero for every retained household under the stated synthetic convention",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "group_n_obs": {
            "ineligible": int((sample["eligible"] == 0).sum()),
            "eligible_nonrecipient": int((sample["eligible"] == 1).sum()),
        },
        "weighted_mean_dose": {
            "ineligible": weighted_mean_dose[0],
            "eligible_nonrecipient": weighted_mean_dose[1],
        },
        "dose_slopes": {
            "ineligible": float(fit.params["dose_ineligible"]),
            "eligible_nonrecipient": float(fit.params["dose_eligible"]),
        },
    },
}

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output, indent=2, allow_nan=False)
