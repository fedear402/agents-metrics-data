import json

import numpy as np
import pandas as pd


def weighted_iv(y, x, instrument, weights):
    y = np.asarray(y, dtype=float)
    x = np.asarray(x, dtype=float)
    instrument = np.asarray(instrument, dtype=float)
    weights = np.asarray(weights, dtype=float)

    X = np.column_stack((np.ones(len(y)), x))
    Z = np.column_stack((np.ones(len(y)), instrument))

    a = Z.T @ (weights[:, None] * X)
    b = Z.T @ (weights * y)
    beta = np.linalg.solve(a, b)

    residual = y - X @ beta
    scores = Z * (weights * residual)[:, None]
    meat = scores.T @ scores
    covariance = np.linalg.solve(a, meat) @ np.linalg.inv(a).T
    covariance *= len(y) / (len(y) - 2)

    return float(beta[1]), float(np.sqrt(covariance[1, 1]))


data = pd.read_csv("input.csv")

regions = data.drop_duplicates("region_id").copy()
regions["e"] = (
    regions["region_weight"] / regions["region_weight"].sum()
)
regions = regions.set_index("region_id")

data = data.join(regions["e"], on="region_id")
data["exposure"] = data["share"] * data["shock"]
z = data.groupby("region_id", sort=False)["exposure"].sum()

for variable in ("y", "x"):
    mean = float(np.sum(regions["e"] * regions[variable]))
    regions[f"{variable}0"] = regions[variable] - mean

z_mean = float(np.sum(regions["e"] * z.reindex(regions.index)))
regions["z0"] = z.reindex(regions.index) - z_mean

data = data.join(regions[["y0", "x0", "z0"]], on="region_id")
data["exposure_weight"] = data["e"] * data["share"]

for variable in ("y0", "x0", "z0"):
    data[f"{variable}_weighted"] = data["exposure_weight"] * data[variable]

industries = data.groupby("industry_id", sort=False).agg(
    s=("exposure_weight", "sum"),
    shock=("shock", "first"),
    y_total=("y0_weighted", "sum"),
    x_total=("x0_weighted", "sum"),
    z_total=("z0_weighted", "sum"),
)

industries["ybar"] = industries["y_total"] / industries["s"]
industries["xbar"] = industries["x_total"] / industries["s"]
industries["zbar"] = industries["z_total"] / industries["s"]

n_industries = len(industries)
weights = industries["s"].to_numpy()
shocks = industries["shock"].to_numpy()

effect, effect_se = weighted_iv(
    industries["ybar"],
    industries["xbar"],
    shocks,
    weights,
)
first_stage, first_stage_se = weighted_iv(
    industries["xbar"],
    industries["zbar"],
    shocks,
    weights,
)
effective_shocks = float(1.0 / np.sum(weights**2))

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {
            "term": "effect",
            "estimate": effect,
            "se": effect_se,
            "n_obs": n_industries,
        },
        {
            "term": "first_stage",
            "estimate": first_stage,
            "se": first_stage_se,
            "n_obs": n_industries,
        },
        {
            "term": "effective_shocks",
            "estimate": effective_shocks,
            "se": None,
            "n_obs": n_industries,
        },
    ],
    "method_metadata": {
        "estimator": "Weighted shift-share 2SLS via shock-level aggregation",
        "vcov": "Shock-level heteroskedasticity-robust HC1, N/(N-2)",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output, allow_nan=False)
