import json

import pandas as pd
from scipy.stats import f as f_distribution

data = pd.read_csv("./input.csv")
data["y"] = pd.to_numeric(data["y"], errors="coerce")
data = data.dropna(subset=["group", "y"])

groups = [values.to_numpy() for _, values in data.groupby("group")["y"]]
n_obs = len(data)
n_groups = len(groups)

if n_groups < 2 or n_obs <= n_groups:
    raise ValueError("ANOVA requires at least two groups and residual degrees of freedom.")

grand_mean = data["y"].mean()
ss_between = sum(len(values) * (values.mean() - grand_mean) ** 2 for values in groups)
ss_within = sum(((values - values.mean()) ** 2).sum() for values in groups)

df_num = n_groups - 1
df_den = n_obs - n_groups
f_statistic = (ss_between / df_num) / (ss_within / df_den)
p_value = f_distribution.sf(f_statistic, df_num, df_den)

result = {
    "task_id": "anova_oneway",
    "platform": "python",
    "estimates": [
        {"term": "F", "estimate": float(f_statistic), "se": None, "n_obs": n_obs},
        {"term": "df_num", "estimate": float(df_num), "se": None, "n_obs": n_obs},
        {"term": "df_den", "estimate": float(df_den), "se": None, "n_obs": n_obs},
        {"term": "p_value", "estimate": float(p_value), "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {"estimator": "one-way ANOVA", "vcov": "pooled within-group variance"},
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output, allow_nan=False)
