import csv
import json
from collections import defaultdict


def read_csv(path):
    with open(path, newline="", encoding="utf-8-sig") as file:
        return list(csv.DictReader(file))


def solve(matrix, vector):
    """Solve a small linear system with partial pivoting."""
    n = len(vector)
    a = [list(map(float, row)) + [float(vector[i])]
         for i, row in enumerate(matrix)]

    for col in range(n):
        pivot = max(range(col, n), key=lambda row: abs(a[row][col]))
        if abs(a[pivot][col]) < 1e-14:
            raise ValueError("The weighted IV system is singular.")
        a[col], a[pivot] = a[pivot], a[col]

        scale = a[col][col]
        for j in range(col, n + 1):
            a[col][j] /= scale

        for row in range(n):
            if row == col:
                continue
            factor = a[row][col]
            for j in range(col, n + 1):
                a[row][j] -= factor * a[col][j]

    return [a[i][n] for i in range(n)]


crosswalk = {row["code"]: row["industry"] for row in read_csv("crosswalk.csv")}
industries = set(crosswalk.values())
if len(industries) != 4:
    raise ValueError("Expected four industries.")

trade = {}
for row in read_csv("trade.csv"):
    key = (row["period"], crosswalk[row["code"]])
    if key in trade:
        raise ValueError(f"Duplicate period-industry trade row: {key}")
    trade[key] = row

areas = {
    (row["area"], row["period"], row["vintage"]): row
    for row in read_csv("areas.csv")
}

employment = defaultdict(float)
national = defaultdict(float)
for row in read_csv("employment.csv"):
    key = (row["area"], row["period"], row["vintage"], row["industry"])
    value = float(row["employment"])
    employment[key] += value
    national[(row["period"], row["vintage"], row["industry"])] += value


def exposure(area, period, vintage, change_column):
    area_row = areas[(area, period, vintage)]
    total = float(area_row["total_employment"])
    result = 0.0

    for industry in industries:
        trade_row = trade[(period, industry)]
        local = employment[(area, period, vintage, industry)]
        national_total = national[(period, vintage, industry)]
        result += (
            (local / total)
            * (float(trade_row[change_column]) / national_total)
            / (float(trade_row["price_index"]) / 100.0)
            / 1000.0
            * (10.0 / float(trade_row["years"]))
        )

    return result


outcomes = read_csv("outcomes.csv")
if len(outcomes) != 72:
    raise ValueError(f"Expected 72 area-period rows; found {len(outcomes)}.")

# Weighted, exactly identified IV: solve Z' W X beta = Z' W y.
moment_matrix = [[0.0] * 4 for _ in range(4)]
moment_outcome = [0.0] * 4
exposures = {}
instruments = {}

for row in outcomes:
    area, period = row["area"], row["period"]
    x = exposure(area, period, "base", "us_change")
    z = exposure(area, period, "early", "other_change")
    exposures[(area, period)] = x
    instruments[(area, period)] = z

    regressors = [1.0, float(period), float(row["control"]), x]
    iv_columns = [1.0, float(period), float(row["control"]), z]
    weight = float(areas[(area, period, "base")]["population"])
    outcome = float(row["change_pp"])

    for i in range(4):
        moment_outcome[i] += weight * iv_columns[i] * outcome
        for j in range(4):
            moment_matrix[i][j] += weight * iv_columns[i] * regressors[j]

beta = solve(moment_matrix, moment_outcome)
n_obs = 72

values = {
    "iv_slope": beta[3],
    "exposure_area0_period0": exposures[("0", "0")],
    "exposure_area0_period1": exposures[("0", "1")],
    "instrument_area0_period0": instruments[("0", "0")],
}

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [
        {"term": term, "estimate": value, "se": None, "n_obs": n_obs}
        for term, value in values.items()
    ],
    "method_metadata": {
        "estimator": "population-weighted 2SLS",
        "regressors": ["intercept", "period", "control", "x"],
        "instruments": ["intercept", "period", "control", "z"],
        "exposure_units": "thousands of real dollars per worker per decade",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "n_industries": 4,
    },
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file, indent=2, allow_nan=False)
