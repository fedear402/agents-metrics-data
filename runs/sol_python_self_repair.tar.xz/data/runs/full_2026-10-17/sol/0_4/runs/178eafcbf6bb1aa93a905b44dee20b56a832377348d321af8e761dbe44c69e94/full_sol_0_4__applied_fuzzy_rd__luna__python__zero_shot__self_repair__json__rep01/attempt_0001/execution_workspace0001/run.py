import json

import numpy as np
import pandas as pd

data = pd.read_csv("input.csv")
data = data.loc[data["score"].abs() < 1].copy()

score = data["score"].to_numpy(dtype=float)
right = (score >= 0).astype(float)
weights = 1.0 - np.abs(score)
X = np.column_stack((np.ones(len(data)), right, score, score * right))
Y = data[["earnings", "participated"]].to_numpy(dtype=float)

bread = np.linalg.inv(X.T @ (weights[:, None] * X))
coefficients = bread @ X.T @ (weights[:, None] * Y)
residuals = Y - X @ coefficients

# Each observation's influence on the right-minus-left intercept jump.
jump_influence = (X @ bread[:, 1]) * weights
joint_covariance = (
    residuals * jump_influence[:, None]
).T @ (residuals * jump_influence[:, None])

reduced_form = float(coefficients[1, 0])
first_stage = float(coefficients[1, 1])
treatment_effect = reduced_form / first_stage

gradient = np.array([1.0 / first_stage, -reduced_form / first_stage**2])
treatment_variance = float(gradient @ joint_covariance @ gradient)

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {
            "term": "treatment_effect",
            "estimate": treatment_effect,
            "se": float(np.sqrt(max(treatment_variance, 0.0))),
            "n_obs": int(len(data)),
        },
        {
            "term": "reduced_form",
            "estimate": reduced_form,
            "se": float(np.sqrt(max(joint_covariance[0, 0], 0.0))),
            "n_obs": int(len(data)),
        },
        {
            "term": "first_stage",
            "estimate": first_stage,
            "se": float(np.sqrt(max(joint_covariance[1, 1], 0.0))),
            "n_obs": int(len(data)),
        },
    ],
    "method_metadata": {
        "estimator": "Fuzzy RD, triangular-weighted local linear Wald ratio",
        "vcov": "Joint HC0 sandwich covariance; delta-method ratio SE",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file)
