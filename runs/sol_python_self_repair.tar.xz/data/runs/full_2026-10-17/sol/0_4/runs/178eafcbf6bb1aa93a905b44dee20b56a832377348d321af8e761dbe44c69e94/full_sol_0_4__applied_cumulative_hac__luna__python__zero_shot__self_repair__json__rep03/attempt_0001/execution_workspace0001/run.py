import json

import numpy as np
import pandas as pd
import statsmodels.api as sm
from statsmodels.stats.sandwich_covariance import cov_hac


def main():
    data = pd.read_csv("input.csv", parse_dates=["date"]).sort_values("date")
    change = np.log(data["vix"]).diff()
    regressors = pd.DataFrame(
        {f"lag_{lag}": change.shift(lag) for lag in range(1, 16)},
        index=data.index,
    )
    sample = regressors.copy()
    sample["log_sales"] = np.log(data["sales"])
    sample = sample.dropna()

    x = sm.add_constant(sample[[f"lag_{lag}" for lag in range(1, 16)]])
    fit = sm.OLS(sample["log_sales"], x).fit()
    n_obs = len(sample)

    # cov_hac uses Bartlett weights. Apply the requested N/(N-16) correction.
    covariance = cov_hac(fit, nlags=15, use_correction=False)
    covariance *= n_obs / (n_obs - 16)

    lag_names = [f"lag_{lag}" for lag in range(1, 16)]
    lag_positions = [x.columns.get_loc(name) for name in lag_names]
    cumulative_estimate = float(fit.params[lag_names].sum())
    cumulative_variance = float(
        covariance[np.ix_(lag_positions, lag_positions)].sum()
    )

    def row(term, estimate, variance):
        return {
            "term": term,
            "estimate": float(estimate),
            "se": float(np.sqrt(max(variance, 0.0))),
            "n_obs": n_obs,
        }

    result = {
        "task_id": "applied_cumulative_hac",
        "platform": "python",
        "estimates": [
            row("cumulative_response", cumulative_estimate, cumulative_variance),
            row(
                "lag_1",
                fit.params["lag_1"],
                covariance[x.columns.get_loc("lag_1"), x.columns.get_loc("lag_1")],
            ),
            row(
                "lag_15",
                fit.params["lag_15"],
                covariance[x.columns.get_loc("lag_15"), x.columns.get_loc("lag_15")],
            ),
        ],
        "method_metadata": {
            "estimator": "OLS with intercept and 15 trading-observation lags",
            "vcov": "Newey-West HAC, Bartlett weights, max lag 15, N/(N-16) correction",
        },
        "diagnostics": {},
    }

    with open("result.json", "w", encoding="utf-8") as output:
        json.dump(result, output, indent=2)


if __name__ == "__main__":
    main()
