import csv
import json
from collections import defaultdict

rows = []
with open("input.csv", newline="") as file:
    for row in csv.DictReader(file):
        rows.append({
            "id": row["id"],
            "time": int(float(row["time"])),
            "g": int(float(row["g"])),
            "y": float(row["y"]),
        })

estimates = []
weighted_sum = 0.0
total_treated = 0
total_rows = 0

for cohort in (3, 5, 7):
    window = set(range(cohort - 2, cohort + 3))
    by_unit = defaultdict(dict)

    for row in rows:
        if row["time"] in window and (
            row["g"] == cohort or row["g"] == 0 or row["g"] > cohort + 2
        ):
            by_unit[row["id"]][row["time"]] = row

    balanced = {
        unit: observations
        for unit, observations in by_unit.items()
        if set(observations) == window
    }

    comparison = []
    treated_units = 0
    for observations in balanced.values():
        if observations[cohort]["g"] == cohort:
            treated_units += 1
        for time in sorted(window):
            row = observations[time]
            comparison.append((
                row["id"],
                time,
                float(row["g"] == cohort and time >= cohort),
                row["y"],
            ))

    unit_sums = defaultdict(lambda: [0.0, 0.0, 0])
    time_sums = defaultdict(lambda: [0.0, 0.0, 0])
    for unit, time, did, y in comparison:
        for sums in (unit_sums[unit], time_sums[time]):
            sums[0] += did
            sums[1] += y
            sums[2] += 1

    mean_did = sum(row[2] for row in comparison) / len(comparison)
    mean_y = sum(row[3] for row in comparison) / len(comparison)

    numerator = 0.0
    denominator = 0.0
    for unit, time, did, y in comparison:
        unit_mean_did = unit_sums[unit][0] / unit_sums[unit][2]
        unit_mean_y = unit_sums[unit][1] / unit_sums[unit][2]
        time_mean_did = time_sums[time][0] / time_sums[time][2]
        time_mean_y = time_sums[time][1] / time_sums[time][2]

        residual_did = did - unit_mean_did - time_mean_did + mean_did
        residual_y = y - unit_mean_y - time_mean_y + mean_y
        numerator += residual_did * residual_y
        denominator += residual_did * residual_did

    coefficient = numerator / denominator
    n_obs = len(comparison)
    estimates.append({
        "term": f"att_g{cohort}",
        "estimate": coefficient,
        "se": None,
        "n_obs": n_obs,
    })
    weighted_sum += coefficient * treated_units
    total_treated += treated_units
    total_rows += n_obs

estimates.append({
    "term": "att_weighted",
    "estimate": weighted_sum / total_treated,
    "se": None,
    "n_obs": total_rows,
})

result = {
    "task_id": "broad_cohort_stack",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {},
    "diagnostics": {},
}

with open("result.json", "w") as file:
    json.dump(result, file, indent=2)
