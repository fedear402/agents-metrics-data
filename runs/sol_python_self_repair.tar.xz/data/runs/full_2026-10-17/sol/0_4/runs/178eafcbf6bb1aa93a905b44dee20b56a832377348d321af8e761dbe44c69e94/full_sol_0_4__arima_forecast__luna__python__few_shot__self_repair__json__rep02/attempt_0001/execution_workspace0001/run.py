import json

import pandas as pd
from statsmodels.tsa.arima.model import ARIMA

data = pd.read_csv("./input.csv")
data = data.sort_values("t")
y = pd.to_numeric(data["y"], errors="raise")

fit = ARIMA(y, order=(1, 1, 1), trend="n").fit()
prediction = fit.get_forecast(steps=1)
forecast = float(prediction.predicted_mean.iloc[0])
se = float(prediction.se_mean.iloc[0])
interval = prediction.conf_int(alpha=0.05)
lower = float(interval.iloc[0, 0])
upper = float(interval.iloc[0, 1])
n_obs = int(y.notna().sum())

result = {
    "task_id": "arima_forecast",
    "platform": "python",
    "estimates": [
        {"term": "forecast", "estimate": forecast, "se": se, "n_obs": n_obs},
        {"term": "lower_95", "estimate": lower, "se": None, "n_obs": n_obs},
        {"term": "upper_95", "estimate": upper, "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "ARIMA(1,1,1) maximum likelihood without constant or drift",
        "vcov": "model-based Gaussian prediction variance",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output)
