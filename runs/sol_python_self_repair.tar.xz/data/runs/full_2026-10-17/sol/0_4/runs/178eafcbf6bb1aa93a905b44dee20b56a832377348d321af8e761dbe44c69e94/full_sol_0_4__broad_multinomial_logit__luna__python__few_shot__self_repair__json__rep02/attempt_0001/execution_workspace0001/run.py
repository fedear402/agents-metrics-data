import json

import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy.special import softmax


data = pd.read_csv("input.csv")
outcomes = [0, 1, 2]
assert sorted(data["y"].unique().tolist()) == outcomes

design = sm.add_constant(data[["x", "z"]], has_constant="add")
fit = sm.MNLogit(data["y"], design).fit(disp=False, maxiter=1000, tol=1e-10)
assert fit.mle_retvals["converged"]

# Parameter columns 0 and 1 represent nonbase outcomes 1 and 2.
assert list(fit.params.columns) == [0, 1]
coefficients = fit.params.copy()
errors = fit.bse.copy()
coefficients.columns = [1, 2]
errors.columns = [1, 2]

prob_cat2_zero = float(
    softmax(np.array([0.0, coefficients.loc["const", 1], coefficients.loc["const", 2]]))[2]
)
n_obs = int(len(data))


def row(term, estimate, se):
    return {
        "term": term,
        "estimate": float(estimate),
        "se": None if se is None else float(se),
        "n_obs": n_obs,
    }


result = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": [
        row("x_cat1", coefficients.loc["x", 1], errors.loc["x", 1]),
        row("z_cat1", coefficients.loc["z", 1], errors.loc["z", 1]),
        row("x_cat2", coefficients.loc["x", 2], errors.loc["x", 2]),
        row("z_cat2", coefficients.loc["z", 2], errors.loc["z", 2]),
        row("prob_cat2_zero", prob_cat2_zero, None),
    ],
    "method_metadata": {
        "estimator": "multinomial logit maximum likelihood; outcome 0 base",
        "vcov": "inverse observed information",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
