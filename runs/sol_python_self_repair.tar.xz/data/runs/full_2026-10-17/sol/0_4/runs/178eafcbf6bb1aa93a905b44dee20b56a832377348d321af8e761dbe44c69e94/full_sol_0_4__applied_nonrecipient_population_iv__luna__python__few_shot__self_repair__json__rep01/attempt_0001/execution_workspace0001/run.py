import json

import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS


def main():
    households = pd.read_csv("households.csv")
    census = pd.read_csv("census.csv")

    sample = households.loc[households["recipient"] == 0].copy()
    n_obs = int(len(sample))

    ineligible = 1 - sample["eligible"]
    eligible = sample["eligible"]

    exog = pd.DataFrame(
        {
            "ineligible": ineligible,
            "eligible": eligible,
            "baseline_ineligible": sample["baseline"] * ineligible,
            "baseline_eligible": sample["baseline"] * eligible,
        },
        index=sample.index,
    )
    endog = pd.DataFrame(
        {
            "dose_ineligible": sample["dose"] * ineligible,
            "dose_eligible": sample["dose"] * eligible,
        },
        index=sample.index,
    )
    excluded_instruments = pd.DataFrame(
        {
            "instrument_ineligible": sample["instrument"] * ineligible,
            "instrument_eligible": sample["instrument"] * eligible,
        },
        index=sample.index,
    )

    fit = IV2SLS(
        dependent=sample["outcome"],
        exog=exog,
        endog=endog,
        instruments=excluded_instruments,
        weights=sample["weight"],
    ).fit()

    effects = {}
    for group, slope_name in (
        (0, "dose_ineligible"),
        (1, "dose_eligible"),
    ):
        group_rows = sample.loc[sample["eligible"] == group]
        mean_dose = np.average(
            group_rows["dose"], weights=group_rows["weight"]
        )
        effects[group] = float(fit.params[slope_name] * mean_dose)

    population = census.groupby("eligible")["nonrecipient_population"].sum()
    population_effect = float(
        np.average(
            [effects[0], effects[1]],
            weights=[population.loc[0], population.loc[1]],
        )
    )

    estimates = [
        {
            "term": "ineligible_effect",
            "estimate": effects[0],
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "eligible_nonrecipient_effect",
            "estimate": effects[1],
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "population_effect",
            "estimate": population_effect,
            "se": None,
            "n_obs": n_obs,
        },
    ]

    result = {
        "task_id": "applied_nonrecipient_population_iv",
        "platform": "python",
        "estimates": estimates,
        "method_metadata": {
            "estimator": "weighted 2SLS",
            "sample": "All households with recipient=0",
            "counterfactual": "Dose is set to zero for every retained household.",
            "group_effect": (
                "Fitted group dose slope times the household-weighted "
                "mean dose in that group."
            ),
            "population_aggregation": (
                "Group effects weighted by census nonrecipient_population."
            ),
            "attribution": "Zero-dose attribution is a synthetic convention.",
        },
        "diagnostics": {
            "n_obs": n_obs,
            "n_ineligible": int((sample["eligible"] == 0).sum()),
            "n_eligible_nonrecipient": int((sample["eligible"] == 1).sum()),
        },
    }

    with open("result.json", "w", encoding="utf-8") as output:
        json.dump(result, output, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
