import json

import numpy as np
import pandas as pd

data = pd.read_csv("input.csv")
data["date"] = pd.to_datetime(data["date"])
data = data.sort_values("date").reset_index(drop=True)

change = np.log(data["vix"]).diff()
lag_columns = [f"lag_{j}" for j in range(1, 16)]
for j, column in enumerate(lag_columns, start=1):
    data[column] = change.shift(j)
data["log_sales"] = np.log(data["sales"])

sample = data.dropna(subset=["log_sales", *lag_columns])
N = len(sample)
X = np.column_stack(
    [np.ones(N), sample[lag_columns].to_numpy(dtype=float)]
)
y = sample["log_sales"].to_numpy(dtype=float)

coefficients = np.linalg.lstsq(X, y, rcond=None)[0]
residuals = y - X @ coefficients
scores = X * residuals[:, None]

meat = scores.T @ scores
for j in range(1, 16):
    lag_product = scores[j:].T @ scores[:-j]
    meat += (1 - j / 16) * (lag_product + lag_product.T)

bread = np.linalg.inv(X.T @ X)
covariance = (N / (N - 16)) * bread @ meat @ bread

contrast = np.r_[0.0, np.ones(15)]
output = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {
            "term": "cumulative_response",
            "estimate": float(contrast @ coefficients),
            "se": float(np.sqrt(contrast @ covariance @ contrast)),
            "n_obs": N,
        },
        {
            "term": "lag_1",
            "estimate": float(coefficients[1]),
            "se": float(np.sqrt(covariance[1, 1])),
            "n_obs": N,
        },
        {
            "term": "lag_15",
            "estimate": float(coefficients[15]),
            "se": float(np.sqrt(covariance[15, 15])),
            "n_obs": N,
        },
    ],
    "method_metadata": {
        "estimator": "OLS with intercept and 15 observed-row lags of log VIX changes",
        "vcov": "Newey-West HAC, Bartlett weights, maximum lag 15, N/(N-16) correction",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
