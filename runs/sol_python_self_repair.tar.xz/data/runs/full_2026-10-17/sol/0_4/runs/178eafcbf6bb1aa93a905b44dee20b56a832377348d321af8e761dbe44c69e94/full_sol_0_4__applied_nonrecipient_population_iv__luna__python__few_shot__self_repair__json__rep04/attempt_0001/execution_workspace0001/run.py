import json

import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS

TASK_ID = "applied_nonrecipient_population_iv"


def main():
    households = pd.read_csv("households.csv")
    census = pd.read_csv("census.csv")

    sample = households.loc[households["recipient"] == 0].copy()
    n_obs = int(len(sample))

    ineligible = 1 - sample["eligible"]
    eligible = sample["eligible"]

    exog = pd.DataFrame(
        {
            "ineligible": ineligible,
            "eligible": eligible,
            "baseline_ineligible": sample["baseline"] * ineligible,
            "baseline_eligible": sample["baseline"] * eligible,
        },
        index=sample.index,
    )
    endog = pd.DataFrame(
        {
            "dose_ineligible": sample["dose"] * ineligible,
            "dose_eligible": sample["dose"] * eligible,
        },
        index=sample.index,
    )
    excluded_instruments = pd.DataFrame(
        {
            "instrument_ineligible": sample["instrument"] * ineligible,
            "instrument_eligible": sample["instrument"] * eligible,
        },
        index=sample.index,
    )

    fit = IV2SLS(
        dependent=sample["outcome"],
        exog=exog,
        endog=endog,
        instruments=excluded_instruments,
        weights=sample["weight"],
    ).fit()

    group_effects = {}
    weighted_mean_doses = {}
    slopes = {}
    for group, slope_name in (
        (0, "dose_ineligible"),
        (1, "dose_eligible"),
    ):
        group_rows = sample.loc[sample["eligible"] == group]
        mean_dose = float(
            np.average(group_rows["dose"], weights=group_rows["weight"])
        )
        slope = float(fit.params[slope_name])
        weighted_mean_doses[group] = mean_dose
        slopes[group] = slope
        group_effects[group] = slope * mean_dose

    population = census.groupby("eligible")["nonrecipient_population"].sum()
    population_effect = float(
        np.average(
            [group_effects[0], group_effects[1]],
            weights=[population.loc[0], population.loc[1]],
        )
    )

    estimates = [
        {
            "term": "ineligible_effect",
            "estimate": float(group_effects[0]),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "eligible_nonrecipient_effect",
            "estimate": float(group_effects[1]),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "population_effect",
            "estimate": population_effect,
            "se": None,
            "n_obs": n_obs,
        },
    ]

    result = {
        "task_id": TASK_ID,
        "platform": "python",
        "estimates": estimates,
        "method_metadata": {
            "estimator": "weighted 2SLS",
            "sample": "all households with recipient=0, in both village treatment statuses",
            "exogenous_columns": list(exog.columns),
            "endogenous_columns": list(endog.columns),
            "instrument_columns": list(exog.columns)
            + list(excluded_instruments.columns),
            "regression_weight": "weight",
            "group_effect": "fitted group dose slope times household-weighted mean dose",
            "population_aggregation_weight": "nonrecipient_population from census.csv",
            "counterfactual": "dose set to zero for every retained household under the stated synthetic convention",
        },
        "diagnostics": {
            "n_obs": n_obs,
            "group_n_obs": {
                str(group): int((sample["eligible"] == group).sum())
                for group in (0, 1)
            },
            "group_dose_slopes": {str(k): v for k, v in slopes.items()},
            "group_weighted_mean_doses": {
                str(k): v for k, v in weighted_mean_doses.items()
            },
            "nonrecipient_population": {
                str(group): int(population.loc[group]) for group in (0, 1)
            },
        },
    }

    with open("result.json", "w", encoding="utf-8") as output:
        json.dump(result, output, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
