import csv
import json


def solve_linear(a, b):
    """Solve a square linear system with partial pivoting."""
    n = len(b)
    a = [row[:] for row in a]
    b = b[:]

    for col in range(n):
        pivot = max(range(col, n), key=lambda row: abs(a[row][col]))
        if abs(a[pivot][col]) < 1e-12:
            raise ValueError("The weighted IV system is singular.")
        a[col], a[pivot] = a[pivot], a[col]
        b[col], b[pivot] = b[pivot], b[col]

        scale = a[col][col]
        for j in range(col, n):
            a[col][j] /= scale
        b[col] /= scale

        for row in range(col + 1, n):
            factor = a[row][col]
            for j in range(col, n):
                a[row][j] -= factor * a[col][j]
            b[row] -= factor * b[col]

    solution = [0.0] * n
    for row in range(n - 1, -1, -1):
        solution[row] = b[row] - sum(
            a[row][col] * solution[col] for col in range(row + 1, n)
        )
    return solution


# With six regressors and six instruments, weighted 2SLS solves
# (Z' W X) beta = Z' W y.
zx = [[0.0] * 6 for _ in range(6)]
zy = [0.0] * 6
weight_sum = [0.0, 0.0]
weighted_dose_sum = [0.0, 0.0]
n_obs = 0
group_counts = [0, 0]

with open("households.csv", newline="", encoding="utf-8-sig") as file:
    for row in csv.DictReader(file):
        if int(row["recipient"]) != 0:
            continue

        group = int(row["eligible"])
        if group not in (0, 1):
            raise ValueError("eligible must be zero or one.")

        ineligible = 1 - group
        eligible = group
        dose = float(row["dose"])
        baseline = float(row["baseline"])
        instrument = float(row["instrument"])
        weight = float(row["weight"])
        outcome = float(row["outcome"])

        if weight <= 0:
            raise ValueError("weight must be positive.")

        exogenous = [
            ineligible,
            eligible,
            baseline * ineligible,
            baseline * eligible,
        ]
        x = exogenous + [dose * ineligible, dose * eligible]
        z = exogenous + [
            instrument * ineligible,
            instrument * eligible,
        ]

        for i in range(6):
            zy[i] += weight * z[i] * outcome
            for j in range(6):
                zx[i][j] += weight * z[i] * x[j]

        weight_sum[group] += weight
        weighted_dose_sum[group] += weight * dose
        group_counts[group] += 1
        n_obs += 1

if not all(weight_sum):
    raise ValueError("Both eligibility groups need retained observations.")

beta = solve_linear(zx, zy)
mean_dose = [
    weighted_dose_sum[group] / weight_sum[group] for group in (0, 1)
]
ineligible_effect = beta[4] * mean_dose[0]
eligible_effect = beta[5] * mean_dose[1]

population = {}
with open("census.csv", newline="", encoding="utf-8-sig") as file:
    for row in csv.DictReader(file):
        group = int(row["eligible"])
        if group not in (0, 1) or group in population:
            raise ValueError("census.csv must have one row per eligibility group.")
        population[group] = int(row["nonrecipient_population"])

if set(population) != {0, 1} or sum(population.values()) <= 0:
    raise ValueError("Both census groups need valid population counts.")

population_effect = (
    population[0] * ineligible_effect
    + population[1] * eligible_effect
) / sum(population.values())

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "ineligible_effect",
            "estimate": ineligible_effect,
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "eligible_nonrecipient_effect",
            "estimate": eligible_effect,
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "population_effect",
            "estimate": population_effect,
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "method": "Weighted two-stage least squares",
        "sample": "All households with recipient=0",
        "regression_weight": "weight",
        "exogenous_columns": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
        ],
        "endogenous_columns": [
            "dose*(1-eligible)",
            "dose*eligible",
        ],
        "excluded_instruments": [
            "instrument*(1-eligible)",
            "instrument*eligible",
        ],
        "additional_intercept": False,
        "group_effect": "Fitted group dose slope times the household-weighted mean dose among retained observations",
        "counterfactual": "Dose is set to zero for every retained household as a synthetic attribution convention.",
        "population_aggregation": "Group effects are averaged using census nonrecipient_population counts only.",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "group_n_obs": {
            "ineligible": group_counts[0],
            "eligible": group_counts[1],
        },
        "weighted_mean_dose": {
            "ineligible": mean_dose[0],
            "eligible": mean_dose[1],
        },
        "dose_slopes": {
            "ineligible": beta[4],
            "eligible": beta[5],
        },
        "nonrecipient_population": {
            "ineligible": population[0],
            "eligible": population[1],
        },
    },
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file, indent=2, allow_nan=False)
