import json

import pandas as pd
from statsmodels.tsa.arima.model import ARIMA

data = pd.read_csv("./input.csv").sort_values("t")
y = pd.to_numeric(data["y"], errors="raise")
if y.isna().any():
    raise ValueError("The y column contains missing values.")
if len(y) != 250:
    raise ValueError(f"Expected 250 observations through t=250, found {len(y)}.")

model = ARIMA(y, order=(1, 1, 1), trend="n")
fit = model.fit()
prediction = fit.get_forecast(steps=1)
interval = prediction.conf_int(alpha=0.05)

forecast = float(prediction.predicted_mean.iloc[0])
standard_error = float(prediction.se_mean.iloc[0])
lower = float(interval.iloc[0, 0])
upper = float(interval.iloc[0, 1])

result = {
    "task_id": "arima_forecast",
    "platform": "python",
    "estimates": [
        {"term": "forecast", "estimate": forecast, "se": standard_error, "n_obs": len(y)},
        {"term": "lower_95", "estimate": lower, "se": None, "n_obs": len(y)},
        {"term": "upper_95", "estimate": upper, "se": None, "n_obs": len(y)},
    ],
    "method_metadata": {
        "estimator": "ARIMA(1,1,1) maximum likelihood, no constant or drift",
        "vcov": "Model-based forecast variance",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output, allow_nan=False)
