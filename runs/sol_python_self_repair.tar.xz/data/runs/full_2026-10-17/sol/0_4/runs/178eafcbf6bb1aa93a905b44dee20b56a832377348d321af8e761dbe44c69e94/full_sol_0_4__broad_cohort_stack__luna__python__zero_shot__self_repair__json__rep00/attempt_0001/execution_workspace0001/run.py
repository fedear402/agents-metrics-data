import csv
import json

COHORTS = (3, 5, 7)
UNIT_TIMES = {}

with open("input.csv", newline="", encoding="utf-8") as file:
    for row in csv.DictReader(file):
        unit_id = row["id"]
        time = int(row["time"])
        adoption = int(row["g"])
        outcome = float(row["y"])
        UNIT_TIMES.setdefault(unit_id, {})[time] = (adoption, outcome)


def estimate_cohort(cohort):
    window = range(cohort - 2, cohort + 3)
    units = []

    for observations in UNIT_TIMES.values():
        if not all(time in observations for time in window):
            continue

        adoptions = {observations[time][0] for time in window}
        if len(adoptions) != 1:
            raise ValueError("A unit has inconsistent adoption periods.")

        adoption = adoptions.pop()
        if adoption == cohort or adoption == 0 or adoption > cohort + 2:
            units.append((adoption, observations))

    if not units:
        raise ValueError(f"No eligible units for cohort {cohort}.")

    rows = []
    for unit_index, (adoption, observations) in enumerate(units):
        for time in window:
            did = float(adoption == cohort and time >= cohort)
            rows.append((unit_index, time, did, observations[time][1]))

    n = len(rows)
    unit_sums = [[0.0, 0.0] for _ in units]
    time_sums = {time: [0.0, 0.0] for time in window}
    total_did = total_y = 0.0

    for unit_index, time, did, outcome in rows:
        unit_sums[unit_index][0] += did
        unit_sums[unit_index][1] += outcome
        time_sums[time][0] += did
        time_sums[time][1] += outcome
        total_did += did
        total_y += outcome

    grand_did = total_did / n
    grand_y = total_y / n
    numerator = denominator = 0.0

    for unit_index, time, did, outcome in rows:
        residual_did = (
            did
            - unit_sums[unit_index][0] / 5
            - time_sums[time][0] / len(units)
            + grand_did
        )
        residual_y = (
            outcome
            - unit_sums[unit_index][1] / 5
            - time_sums[time][1] / len(units)
            + grand_y
        )
        numerator += residual_did * residual_y
        denominator += residual_did * residual_did

    if denominator == 0:
        raise ValueError(f"The DID coefficient is unidentified for cohort {cohort}.")

    treated_units = sum(adoption == cohort for adoption, _ in units)
    return numerator / denominator, n, treated_units


estimates = []
weighted_sum = 0.0
total_treated_units = 0
total_observations = 0

for cohort in COHORTS:
    coefficient, n_obs, treated_units = estimate_cohort(cohort)
    estimates.append({
        "term": f"att_g{cohort}",
        "estimate": coefficient,
        "se": None,
        "n_obs": n_obs,
    })
    weighted_sum += treated_units * coefficient
    total_treated_units += treated_units
    total_observations += n_obs

estimates.append({
    "term": "att_weighted",
    "estimate": weighted_sum / total_treated_units,
    "se": None,
    "n_obs": total_observations,
})

result = {
    "task_id": "broad_cohort_stack",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {},
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file, indent=2)
