import csv
import json
from collections import defaultdict


def read_csv(path):
    with open(path, newline="", encoding="utf-8") as file:
        return list(csv.DictReader(file))


def solve(matrix, vector):
    size = len(vector)
    augmented = [
        [float(value) for value in matrix[i]] + [float(vector[i])]
        for i in range(size)
    ]

    for column in range(size):
        pivot = max(
            range(column, size),
            key=lambda row: abs(augmented[row][column]),
        )
        augmented[column], augmented[pivot] = augmented[pivot], augmented[column]

        divisor = augmented[column][column]
        if abs(divisor) < 1e-14:
            raise ValueError("Singular weighted 2SLS system")

        for j in range(column, size + 1):
            augmented[column][j] /= divisor

        for row in range(size):
            if row == column:
                continue
            factor = augmented[row][column]
            for j in range(column, size + 1):
                augmented[row][j] -= factor * augmented[column][j]

    return [augmented[i][size] for i in range(size)]


crosswalk_rows = read_csv("crosswalk.csv")
trade_rows = read_csv("trade.csv")
area_rows_raw = read_csv("areas.csv")
employment_rows = read_csv("employment.csv")
outcome_rows = read_csv("outcomes.csv")

crosswalk = {row["code"]: row["industry"] for row in crosswalk_rows}
industries = sorted(set(crosswalk.values()))
if len(industries) != 4:
    raise ValueError(f"Expected four industries, found {len(industries)}")

areas = {
    (row["area"], row["period"], row["vintage"]): row
    for row in area_rows_raw
}

employment = defaultdict(float)
national_employment = defaultdict(float)
for row in employment_rows:
    area = row["area"]
    period = row["period"]
    vintage = row["vintage"]
    industry = row["industry"]
    value = float(row["employment"])
    employment[(area, period, vintage, industry)] += value
    national_employment[(period, vintage, industry)] += value

trade = defaultdict(dict)
for row in trade_rows:
    trade[row["period"]][crosswalk[row["code"]]] = row

periods = sorted({row["period"] for row in outcome_rows}, key=float)
period_indicator = {period: index for index, period in enumerate(periods)}


def exposure(area, period, vintage, change_column):
    total_employment = float(
        areas[(area, period, vintage)]["total_employment"]
    )
    value = 0.0

    for industry in industries:
        trade_row = trade[period][industry]
        area_employment = employment[(area, period, vintage, industry)]
        national = national_employment[(period, vintage, industry)]

        value += (
            (area_employment / total_employment)
            * (float(trade_row[change_column]) / national)
            / (float(trade_row["price_index"]) / 100.0)
            / 1000.0
            * (10.0 / float(trade_row["years"]))
        )

    return value


observations = []
for row in outcome_rows:
    area = row["area"]
    period = row["period"]
    observations.append(
        {
            "y": float(row["change_pp"]),
            "x": exposure(area, period, "base", "us_change"),
            "z": exposure(area, period, "early", "other_change"),
            "period": float(period_indicator[period]),
            "control": float(row["control"]),
            "weight": float(areas[(area, period, "base")]["population"]),
        }
    )

n_obs = len(observations)
if n_obs != 72:
    raise ValueError(f"Expected 72 area-period rows, found {n_obs}")

# In this exactly identified model, weighted 2SLS solves (Z' W X) beta = Z' W y.
moment_matrix = [[0.0] * 4 for _ in range(4)]
moment_outcome = [0.0] * 4

for observation in observations:
    instruments = [
        1.0,
        observation["period"],
        observation["control"],
        observation["z"],
    ]
    regressors = [
        1.0,
        observation["period"],
        observation["control"],
        observation["x"],
    ]
    weight = observation["weight"]

    for i in range(4):
        moment_outcome[i] += weight * instruments[i] * observation["y"]
        for j in range(4):
            moment_matrix[i][j] += weight * instruments[i] * regressors[j]

iv_slope = solve(moment_matrix, moment_outcome)[3]

estimates = [
    ("iv_slope", iv_slope),
    (
        "exposure_area0_period0",
        exposure("0", periods[0], "base", "us_change"),
    ),
    (
        "exposure_area0_period1",
        exposure("0", periods[1], "base", "us_change"),
    ),
    (
        "instrument_area0_period0",
        exposure("0", periods[0], "early", "other_change"),
    ),
]

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [
        {"term": term, "estimate": value, "se": None, "n_obs": 72}
        for term, value in estimates
    ],
    "method_metadata": {
        "estimator": "population-weighted 2SLS",
        "outcome": "change_pp",
        "endogenous_regressor": "x",
        "excluded_instrument": "z",
        "exogenous_instruments": ["intercept", "period", "control"],
        "weight": "base-vintage population",
        "exposure_units": "thousands of real dollars per worker per decade",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "n_industries": len(industries),
        "n_periods": len(periods),
    },
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file, indent=2, allow_nan=False)
