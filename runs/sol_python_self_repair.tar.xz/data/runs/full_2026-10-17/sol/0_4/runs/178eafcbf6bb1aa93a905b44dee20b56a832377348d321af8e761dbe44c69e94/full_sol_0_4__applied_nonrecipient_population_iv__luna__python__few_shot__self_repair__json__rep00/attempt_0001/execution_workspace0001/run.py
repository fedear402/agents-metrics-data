import json

import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS


def main():
    households = pd.read_csv("households.csv")
    census = pd.read_csv("census.csv")

    sample = households.loc[households["recipient"] == 0].copy()
    ineligible = 1 - sample["eligible"]
    eligible = sample["eligible"]

    exog = pd.DataFrame({
        "ineligible": ineligible,
        "eligible": eligible,
        "baseline_ineligible": sample["baseline"] * ineligible,
        "baseline_eligible": sample["baseline"] * eligible,
    }, index=sample.index)

    endog = pd.DataFrame({
        "dose_ineligible": sample["dose"] * ineligible,
        "dose_eligible": sample["dose"] * eligible,
    }, index=sample.index)

    excluded_instruments = pd.DataFrame({
        "instrument_ineligible": sample["instrument"] * ineligible,
        "instrument_eligible": sample["instrument"] * eligible,
    }, index=sample.index)

    fit = IV2SLS(
        dependent=sample["outcome"],
        exog=exog,
        endog=endog,
        instruments=excluded_instruments,
        weights=sample["weight"],
    ).fit()

    group_effects = {}
    group_counts = {}
    for group, slope_name in [(0, "dose_ineligible"), (1, "dose_eligible")]:
        rows = sample.loc[sample["eligible"] == group]
        mean_dose = np.average(rows["dose"], weights=rows["weight"])
        group_effects[group] = float(fit.params[slope_name] * mean_dose)
        group_counts[group] = int(len(rows))

    population = census.groupby("eligible")["nonrecipient_population"].sum()
    population_effect = float(
        np.average(
            [group_effects[0], group_effects[1]],
            weights=[population.loc[0], population.loc[1]],
        )
    )

    n_obs = int(len(sample))
    estimates = [
        {"term": "ineligible_effect", "estimate": group_effects[0], "se": None, "n_obs": n_obs},
        {"term": "eligible_nonrecipient_effect", "estimate": group_effects[1], "se": None, "n_obs": n_obs},
        {"term": "population_effect", "estimate": population_effect, "se": None, "n_obs": n_obs},
    ]

    result = {
        "task_id": "applied_nonrecipient_population_iv",
        "platform": "python",
        "estimates": estimates,
        "method_metadata": {
            "estimator": "weighted 2SLS",
            "sample": "recipient == 0 across both village treatment statuses",
            "counterfactual": "dose is zero for every retained household; this attribution is a synthetic convention",
            "group_effect": "fitted group dose slope times the household-weighted group mean dose",
            "population_aggregation": "group effects weighted by census nonrecipient_population",
            "standard_errors": "not requested; se is null",
        },
        "diagnostics": {
            "n_obs": n_obs,
            "group_n_obs": {
                "ineligible": group_counts[0],
                "eligible_nonrecipient": group_counts[1],
            },
        },
    }

    with open("result.json", "w", encoding="utf-8") as output:
        json.dump(result, output, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
