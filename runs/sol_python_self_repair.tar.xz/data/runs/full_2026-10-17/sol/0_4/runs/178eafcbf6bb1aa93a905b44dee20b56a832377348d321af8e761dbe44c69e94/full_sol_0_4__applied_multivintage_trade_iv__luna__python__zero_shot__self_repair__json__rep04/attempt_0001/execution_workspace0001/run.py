import csv
import json
from collections import defaultdict


def read_csv(path):
    with open(path, newline="", encoding="utf-8-sig") as file:
        return list(csv.DictReader(file))


def solve(matrix, vector):
    """Solve a square linear system with partial pivoting."""
    n = len(vector)
    augmented = [list(map(float, matrix[i])) + [float(vector[i])] for i in range(n)]

    for col in range(n):
        pivot = max(range(col, n), key=lambda row: abs(augmented[row][col]))
        if abs(augmented[pivot][col]) < 1e-14:
            raise ValueError("The weighted IV system is singular.")
        augmented[col], augmented[pivot] = augmented[pivot], augmented[col]

        scale = augmented[col][col]
        for j in range(col, n + 1):
            augmented[col][j] /= scale

        for row in range(n):
            if row == col:
                continue
            factor = augmented[row][col]
            for j in range(col, n + 1):
                augmented[row][j] -= factor * augmented[col][j]

    return [augmented[i][n] for i in range(n)]


crosswalk = read_csv("crosswalk.csv")
trade = read_csv("trade.csv")
areas = read_csv("areas.csv")
employment = read_csv("employment.csv")
outcomes = read_csv("outcomes.csv")

code_to_industry = {row["code"]: row["industry"] for row in crosswalk}

area_data = {
    (row["area"], row["period"], row["vintage"]): row
    for row in areas
}

area_industry = defaultdict(float)
national_industry = defaultdict(float)
for row in employment:
    key = (row["area"], row["period"], row["vintage"], row["industry"])
    value = float(row["employment"])
    area_industry[key] += value
    national_industry[(row["period"], row["vintage"], row["industry"])] += value

trade_by_period = defaultdict(list)
for row in trade:
    trade_by_period[row["period"]].append(
        {
            "industry": code_to_industry[row["code"]],
            "us_change": float(row["us_change"]),
            "other_change": float(row["other_change"]),
            "price_index": float(row["price_index"]),
            "years": float(row["years"]),
        }
    )


def exposure(area, period, vintage, change_field):
    total = float(area_data[(area, period, vintage)]["total_employment"])
    result = 0.0
    for item in trade_by_period[period]:
        industry = item["industry"]
        local = area_industry[(area, period, vintage, industry)]
        national = national_industry[(period, vintage, industry)]
        result += (
            (local / total)
            * (item[change_field] / national)
            / (item["price_index"] / 100.0)
            / 1000.0
            * (10.0 / item["years"])
        )
    return result


moment_matrix = [[0.0] * 4 for _ in range(4)]
moment_outcome = [0.0] * 4
exposures = {}
instruments = {}
n_obs = 0

for row in outcomes:
    area = row["area"]
    period = row["period"]
    x = exposure(area, period, "base", "us_change")
    z = exposure(area, period, "early", "other_change")
    exposures[(area, period)] = x
    instruments[(area, period)] = z

    weight = float(area_data[(area, period, "base")]["population"])
    regressors = [1.0, float(period), float(row["control"]), x]
    iv_columns = [1.0, float(period), float(row["control"]), z]
    outcome = float(row["change_pp"])

    for i in range(4):
        moment_outcome[i] += weight * iv_columns[i] * outcome
        for j in range(4):
            moment_matrix[i][j] += weight * iv_columns[i] * regressors[j]
    n_obs += 1

if n_obs != 72:
    raise ValueError(f"Expected 72 area-period rows, found {n_obs}.")

iv_slope = solve(moment_matrix, moment_outcome)[3]

estimates = [
    ("iv_slope", iv_slope),
    ("exposure_area0_period0", exposures[("0", "0")]),
    ("exposure_area0_period1", exposures[("0", "1")]),
    ("instrument_area0_period0", instruments[("0", "0")]),
]

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [
        {"term": term, "estimate": value, "se": None, "n_obs": n_obs}
        for term, value in estimates
    ],
    "method_metadata": {
        "estimator": "weighted exactly identified 2SLS",
        "regressors": ["intercept", "period", "control", "x"],
        "instruments": ["intercept", "period", "control", "z"],
        "weight": "base-vintage population",
        "exposure_units": "thousands of real dollars per worker per decade",
    },
    "diagnostics": {"n_obs": n_obs},
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file, indent=2, allow_nan=False)
