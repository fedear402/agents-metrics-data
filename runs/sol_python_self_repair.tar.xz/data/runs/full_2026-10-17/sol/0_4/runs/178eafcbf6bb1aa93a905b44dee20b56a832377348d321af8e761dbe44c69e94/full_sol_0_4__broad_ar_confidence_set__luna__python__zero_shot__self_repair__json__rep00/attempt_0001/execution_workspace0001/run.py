import json

import numpy as np
import pandas as pd
from scipy.stats import f

data = pd.read_csv("input.csv")
n = len(data)

y = data["y"].to_numpy(dtype=float)
d = data["endog"].to_numpy(dtype=float)
x = data["x"].to_numpy(dtype=float)
z = data[["z1", "z2"]].to_numpy(dtype=float)

restricted = np.column_stack((np.ones(n), x))
unrestricted = np.column_stack((restricted, z))

def residualize(values, design):
    coefficients = np.linalg.lstsq(design, values, rcond=None)[0]
    return values - design @ coefficients

yr = residualize(y, restricted)
dr = residualize(d, restricted)
yu = residualize(y, unrestricted)
du = residualize(d, unrestricted)

# The test inequality is a quadratic in beta:
# (n - 4) * (RSS_restricted - RSS_unrestricted)
#     - 2 * F_critical * RSS_unrestricted <= 0.
critical = f.ppf(0.95, 2, n - 4)

restricted_terms = np.array([
    np.dot(dr, dr),
    -2 * np.dot(yr, dr),
    np.dot(yr, yr),
])
unrestricted_terms = np.array([
    np.dot(du, du),
    -2 * np.dot(yu, du),
    np.dot(yu, yu),
])
quadratic = (n - 4) * (restricted_terms - unrestricted_terms)
quadratic -= 2 * critical * unrestricted_terms

roots = np.roots(quadratic)
if len(roots) != 2 or np.any(np.abs(roots.imag) > 1e-8):
    raise ValueError("Expected two finite real confidence-set boundaries.")

boundary_low, boundary_high = sorted(roots.real)
accepts_zero = float(quadratic[2] <= 0)
unbounded = float(quadratic[0] < 0)

rss_r_at_one = np.dot(yr - dr, yr - dr)
rss_u_at_one = np.dot(yu - du, yu - du)
ar_f_at_one = ((rss_r_at_one - rss_u_at_one) / 2) / (
    rss_u_at_one / (n - 4)
)

values = {
    "boundary_low": float(boundary_low),
    "boundary_high": float(boundary_high),
    "accepts_zero": accepts_zero,
    "unbounded": unbounded,
    "ar_f_at_one": float(ar_f_at_one),
}

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": [
        {"term": term, "estimate": value, "se": None, "n_obs": n}
        for term, value in values.items()
    ],
    "method_metadata": {
        "estimator": "Anderson-Rubin test inversion",
        "vcov": "Conventional homoskedastic OLS F test",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output)
