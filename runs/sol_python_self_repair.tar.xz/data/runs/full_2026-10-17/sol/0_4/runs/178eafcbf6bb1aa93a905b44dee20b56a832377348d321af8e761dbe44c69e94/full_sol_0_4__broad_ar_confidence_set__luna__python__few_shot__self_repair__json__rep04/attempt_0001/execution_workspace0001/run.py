import json

import numpy as np
import pandas as pd
from scipy.stats import f


data = pd.read_csv("input.csv")
required = ["y", "endog", "x", "z1", "z2"]
if data[required].isna().any().any():
    raise ValueError("Required columns contain missing values")

y = data["y"].to_numpy(dtype=float)
endog = data["endog"].to_numpy(dtype=float)
x = data["x"].to_numpy(dtype=float)
z1 = data["z1"].to_numpy(dtype=float)
z2 = data["z2"].to_numpy(dtype=float)

n = len(data)
restricted = np.column_stack((np.ones(n), x))
unrestricted = np.column_stack((np.ones(n), x, z1, z2))
q = 2
df = n - 4

if df <= 0 or np.linalg.matrix_rank(unrestricted) != 4:
    raise ValueError("The unrestricted F test is not identified")


def residual(values, design):
    coefficients = np.linalg.lstsq(design, values, rcond=None)[0]
    return values - design @ coefficients


ry = residual(y, restricted)
rd = residual(endog, restricted)
uy = residual(y, unrestricted)
ud = residual(endog, unrestricted)

critical = f.ppf(0.95, q, df)
scale = 1.0 + q * critical / df

# Acceptance is A*beta**2 + B*beta + C <= 0.
A = float(rd @ rd - scale * (ud @ ud))
B = float(-2.0 * (ry @ rd - scale * (uy @ ud)))
C = float(ry @ ry - scale * (uy @ uy))

discriminant = B * B - 4.0 * A * C
if A == 0.0 or discriminant <= 0.0:
    raise ValueError("Expected two distinct finite boundaries")

roots = np.sort(np.roots([A, B, C]).real)
if not np.all(np.isfinite(roots)):
    raise ValueError("Nonfinite confidence-set boundary")

at_one_restricted = ry - rd
at_one_unrestricted = uy - ud
ssr_r = float(at_one_restricted @ at_one_restricted)
ssr_u = float(at_one_unrestricted @ at_one_unrestricted)
ar_f_at_one = ((ssr_r - ssr_u) / q) / (ssr_u / df)

values = {
    "boundary_low": float(roots[0]),
    "boundary_high": float(roots[1]),
    "accepts_zero": int(C <= 0.0),
    "unbounded": int(A < 0.0),
    "ar_f_at_one": float(ar_f_at_one),
}

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": [
        {"term": term, "estimate": estimate, "se": None, "n_obs": n}
        for term, estimate in values.items()
    ],
    "method_metadata": {
        "estimator": "Anderson-Rubin test inversion",
        "vcov": "Homoskedastic joint F test",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
