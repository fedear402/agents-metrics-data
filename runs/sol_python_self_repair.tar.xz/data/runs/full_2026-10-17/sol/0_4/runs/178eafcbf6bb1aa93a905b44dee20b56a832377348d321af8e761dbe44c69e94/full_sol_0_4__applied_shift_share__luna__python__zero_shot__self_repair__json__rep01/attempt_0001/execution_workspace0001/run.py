import json

import numpy as np
import pandas as pd


def weighted_iv(y, x, instrument, weights):
    """Return the IV slope and shock-level HC1 standard error."""
    n = len(y)
    X = np.column_stack((np.ones(n), x))
    Z = np.column_stack((np.ones(n), instrument))
    WZ = weights[:, None] * Z

    beta = np.linalg.solve(Z.T @ (weights[:, None] * X), Z.T @ (weights * y))
    residuals = y - X @ beta

    bread = np.linalg.inv(Z.T @ (weights[:, None] * X))
    meat = WZ.T @ ((residuals**2)[:, None] * WZ)
    covariance = (n / (n - 2)) * bread @ meat @ bread.T
    return float(beta[1]), float(np.sqrt(covariance[1, 1]))


data = pd.read_csv("input.csv")

regions = data.drop_duplicates("region_id").set_index("region_id")
regional_weights = regions["region_weight"].astype(float)
regional_weights = regional_weights / regional_weights.sum()

data = data.copy()
data["e"] = data["region_id"].map(regional_weights)

regional_z = (
    data.assign(exposure=data["share"] * data["shock"])
    .groupby("region_id", sort=False)["exposure"]
    .sum()
)
regions["z"] = regional_z

for variable in ("y", "x", "z"):
    mean = np.sum(
        regional_weights.to_numpy()
        * regions[variable].to_numpy(dtype=float)
    )
    data[f"{variable}0"] = data["region_id"].map(regions[variable] - mean)

data["exposure_weight"] = data["e"] * data["share"]
for variable in ("y", "x", "z"):
    data[f"weighted_{variable}0"] = (
        data["exposure_weight"] * data[f"{variable}0"]
    )

shocks = data.groupby("industry_id", sort=False).agg(
    s=("exposure_weight", "sum"),
    shock=("shock", "first"),
    y_total=("weighted_y0", "sum"),
    x_total=("weighted_x0", "sum"),
    z_total=("weighted_z0", "sum"),
)
shocks = shocks.loc[shocks["s"] > 0].copy()

for variable in ("y", "x", "z"):
    shocks[f"{variable}bar"] = shocks[f"{variable}_total"] / shocks["s"]

weights = shocks["s"].to_numpy(dtype=float)
industry_shocks = shocks["shock"].to_numpy(dtype=float)
xbar = shocks["xbar"].to_numpy(dtype=float)
ybar = shocks["ybar"].to_numpy(dtype=float)
zbar = shocks["zbar"].to_numpy(dtype=float)
n_industries = len(shocks)

effect, effect_se = weighted_iv(ybar, xbar, industry_shocks, weights)
first_stage, first_stage_se = weighted_iv(
    xbar, zbar, industry_shocks, weights
)
effective_shocks = float(1.0 / np.sum(weights**2))

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {
            "term": "effect",
            "estimate": effect,
            "se": effect_se,
            "n_obs": n_industries,
        },
        {
            "term": "first_stage",
            "estimate": first_stage,
            "se": first_stage_se,
            "n_obs": n_industries,
        },
        {
            "term": "effective_shocks",
            "estimate": effective_shocks,
            "se": None,
            "n_obs": n_industries,
        },
    ],
    "method_metadata": {
        "estimator": "Weighted regional 2SLS via BHJ shock-level IV",
        "vcov": "Shock-level heteroskedasticity-robust HC1, N/(N-2)",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output, allow_nan=False)
