import json

import numpy as np
import pandas as pd

data = pd.read_csv("input.csv")
regions = data.groupby("region_id", sort=True)[["region_weight", "x", "y"]].first()
industries = data.groupby("industry_id", sort=True)["shock"].first()
shares = data.pivot(index="region_id", columns="industry_id", values="share")
shares = shares.reindex(index=regions.index, columns=industries.index)

weight = regions["region_weight"].to_numpy(dtype=float)
weight = weight / weight.sum()
share = shares.to_numpy(dtype=float)
shock = industries.to_numpy(dtype=float)
x = regions["x"].to_numpy(dtype=float)
y = regions["y"].to_numpy(dtype=float)
z = share @ shock

regional = np.column_stack((y, x, z))
centered = regional - weight @ regional
mass = weight @ share
aggregated = share.T @ (weight[:, None] * centered)
aggregated = aggregated / mass[:, None]
n_industries = len(shock)


def shock_level_iv(dependent, endogenous):
    regressors = np.column_stack((np.ones(n_industries), endogenous))
    instruments = np.column_stack((np.ones(n_industries), shock))
    cross = instruments.T @ (mass[:, None] * regressors)
    coefficients = np.linalg.solve(
        cross, instruments.T @ (mass * dependent)
    )
    residuals = dependent - regressors @ coefficients
    scores = instruments * (mass * residuals)[:, None]
    inverse = np.linalg.inv(cross)
    covariance = (
        n_industries / (n_industries - 2)
        * inverse
        @ (scores.T @ scores)
        @ inverse.T
    )
    return float(coefficients[1]), float(np.sqrt(covariance[1, 1]))


effect, effect_se = shock_level_iv(aggregated[:, 0], aggregated[:, 1])
first_stage, first_stage_se = shock_level_iv(
    aggregated[:, 1], aggregated[:, 2]
)

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {
            "term": "effect",
            "estimate": effect,
            "se": effect_se,
            "n_obs": n_industries,
        },
        {
            "term": "first_stage",
            "estimate": first_stage,
            "se": first_stage_se,
            "n_obs": n_industries,
        },
        {
            "term": "effective_shocks",
            "estimate": float(1 / np.sum(mass**2)),
            "se": None,
            "n_obs": n_industries,
        },
    ],
    "method_metadata": {
        "estimator": "Weighted regional 2SLS via shock-level IV",
        "vcov": "Shock-level HC1 with analytic weights and N/(N-2)",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
