import json

import numpy as np
import pandas as pd

data = pd.read_csv("input.csv")

required = ["score", "participated", "earnings"]
data = data.dropna(subset=required)
data = data.loc[data["score"].abs() < 1].copy()

score = data["score"].to_numpy(dtype=float)
right = (score >= 0).astype(float)
weights = 1 - np.abs(score)
X = np.column_stack((np.ones(len(data)), right, score, right * score))
Y = data[["earnings", "participated"]].to_numpy(dtype=float)

weighted_X = X * np.sqrt(weights)[:, None]
weighted_Y = Y * np.sqrt(weights)[:, None]
beta = np.linalg.lstsq(weighted_X, weighted_Y, rcond=None)[0]
residuals = Y - X @ beta
bread = np.linalg.inv(X.T @ (weights[:, None] * X))

def hc0_covariance(residual_a, residual_b):
    cross_meat = X.T @ (
        (weights**2 * residual_a * residual_b)[:, None] * X
    )
    return bread @ cross_meat @ bread

reduced_form = float(beta[1, 0])
first_stage = float(beta[1, 1])
var_reduced_form = float(hc0_covariance(residuals[:, 0], residuals[:, 0])[1, 1])
var_first_stage = float(hc0_covariance(residuals[:, 1], residuals[:, 1])[1, 1])
cov_discontinuities = float(
    hc0_covariance(residuals[:, 0], residuals[:, 1])[1, 1]
)

if first_stage == 0:
    treatment_effect = None
    treatment_se = None
else:
    treatment_effect = reduced_form / first_stage
    treatment_variance = (
        var_reduced_form / first_stage**2
        + reduced_form**2 * var_first_stage / first_stage**4
        - 2 * reduced_form * cov_discontinuities / first_stage**3
    )
    treatment_se = float(np.sqrt(max(0.0, treatment_variance)))

n_obs = len(data)
result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {
            "term": "treatment_effect",
            "estimate": treatment_effect,
            "se": treatment_se,
            "n_obs": n_obs,
        },
        {
            "term": "reduced_form",
            "estimate": reduced_form,
            "se": float(np.sqrt(max(0.0, var_reduced_form))),
            "n_obs": n_obs,
        },
        {
            "term": "first_stage",
            "estimate": first_stage,
            "se": float(np.sqrt(max(0.0, var_first_stage))),
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "Fuzzy regression discontinuity, triangular-weighted local linear Wald ratio",
        "vcov": "HC0 sandwich; joint covariance and delta method for Wald ratio",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output, allow_nan=False)
