import json

import pandas as pd
from statsmodels.tsa.arima.model import ARIMA


data = pd.read_csv("./input.csv").sort_values("t")
y = pd.to_numeric(data["y"], errors="raise")

if y.isna().any():
    raise ValueError("The y series contains missing values.")
if int(data["t"].iloc[-1]) != 250:
    raise ValueError("The last observed time must be t = 250.")

model = ARIMA(y.to_numpy(), order=(1, 1, 1), trend="n")
fit = model.fit()
prediction = fit.get_forecast(steps=1)
interval = prediction.conf_int(alpha=0.05)

forecast = float(prediction.predicted_mean[0])
standard_error = float(prediction.se_mean[0])
lower_95 = float(interval[0, 0])
upper_95 = float(interval[0, 1])
n_obs = int(len(y))

result = {
    "task_id": "arima_forecast",
    "platform": "python",
    "estimates": [
        {"term": "forecast", "estimate": forecast, "se": standard_error, "n_obs": n_obs},
        {"term": "lower_95", "estimate": lower_95, "se": None, "n_obs": n_obs},
        {"term": "upper_95", "estimate": upper_95, "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "ARIMA(1,1,1) maximum likelihood, no constant or drift",
        "vcov": "Model-based forecast error variance; 95% normal prediction interval",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output, allow_nan=False, indent=2)
