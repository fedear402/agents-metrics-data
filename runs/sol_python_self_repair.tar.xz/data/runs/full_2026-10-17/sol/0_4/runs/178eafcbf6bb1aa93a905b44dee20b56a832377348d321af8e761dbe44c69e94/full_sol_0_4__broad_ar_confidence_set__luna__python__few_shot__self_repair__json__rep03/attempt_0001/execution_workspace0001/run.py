import json

import numpy as np
import pandas as pd
from scipy.stats import f

data = pd.read_csv("input.csv")
n = len(data)
y = data["y"].to_numpy(dtype=float)
d = data["endog"].to_numpy(dtype=float)
x = data["x"].to_numpy(dtype=float)
z = data[["z1", "z2"]].to_numpy(dtype=float)

restricted = np.column_stack((np.ones(n), x))
unrestricted = np.column_stack((restricted, z))
q = 2
df = n - 4


def residual(values, design):
    coefficients = np.linalg.lstsq(design, values, rcond=None)[0]
    return values - design @ coefficients


ry = residual(y, restricted)
rd = residual(d, restricted)
uy = residual(y, unrestricted)
ud = residual(d, unrestricted)

critical = f.ppf(0.95, q, df)
scale = 1.0 + q * critical / df
a = float(rd @ rd - scale * (ud @ ud))
b = float(-2.0 * (ry @ rd - scale * (uy @ ud)))
c = float(ry @ ry - scale * (uy @ uy))

discriminant = b * b - 4.0 * a * c
if a == 0.0 or discriminant <= 0.0:
    raise ValueError("Expected two distinct finite Anderson-Rubin boundaries.")

roots = np.sort(np.roots([a, b, c]).real)
boundary_low, boundary_high = map(float, roots)
accepts_zero = int(c <= 0.0)
unbounded = int(a < 0.0)

r_at_one = ry - rd
u_at_one = uy - ud
ssr_r = float(r_at_one @ r_at_one)
ssr_u = float(u_at_one @ u_at_one)
ar_f_at_one = ((ssr_r - ssr_u) / q) / (ssr_u / df)

terms = {
    "boundary_low": boundary_low,
    "boundary_high": boundary_high,
    "accepts_zero": accepts_zero,
    "unbounded": unbounded,
    "ar_f_at_one": float(ar_f_at_one),
}

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": [
        {"term": term, "estimate": estimate, "se": None, "n_obs": n}
        for term, estimate in terms.items()
    ],
    "method_metadata": {
        "estimator": "Anderson-Rubin test inversion",
        "vcov": "homoskedastic OLS",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
