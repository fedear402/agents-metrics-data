import json

import numpy as np
import pandas as pd
from scipy.stats import f

data = pd.read_csv("input.csv")
n = len(data)
y = data["y"].to_numpy(dtype=float)
endog = data["endog"].to_numpy(dtype=float)
x = data["x"].to_numpy(dtype=float)
z1 = data["z1"].to_numpy(dtype=float)
z2 = data["z2"].to_numpy(dtype=float)

restricted = np.column_stack((np.ones(n), x))
unrestricted = np.column_stack((restricted, z1, z2))
q = 2
df = n - 4


def residual(values, design):
    coefficients = np.linalg.lstsq(design, values, rcond=None)[0]
    return values - design @ coefficients


ry = residual(y, restricted)
rd = residual(endog, restricted)
uy = residual(y, unrestricted)
ud = residual(endog, unrestricted)

critical = f.ppf(0.95, q, df)
scale = 1.0 + q * critical / df
a = float(rd @ rd - scale * (ud @ ud))
b = float(-2.0 * (ry @ rd - scale * (uy @ ud)))
c = float(ry @ ry - scale * (uy @ uy))

discriminant = b * b - 4.0 * a * c
if a == 0.0 or discriminant <= 0.0:
    raise ValueError("Expected two distinct finite Anderson-Rubin boundaries.")

boundaries = np.sort(np.roots([a, b, c]).real)


def ar_f(beta):
    restricted_residual = ry - beta * rd
    unrestricted_residual = uy - beta * ud
    ssr_r = restricted_residual @ restricted_residual
    ssr_u = unrestricted_residual @ unrestricted_residual
    return float(((ssr_r - ssr_u) / q) / (ssr_u / df))


rows = [
    {"term": "boundary_low", "estimate": float(boundaries[0]), "se": None, "n_obs": n},
    {"term": "boundary_high", "estimate": float(boundaries[1]), "se": None, "n_obs": n},
    {"term": "accepts_zero", "estimate": int(c <= 0.0), "se": None, "n_obs": n},
    {"term": "unbounded", "estimate": int(a < 0.0), "se": None, "n_obs": n},
    {"term": "ar_f_at_one", "estimate": ar_f(1.0), "se": None, "n_obs": n},
]

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": rows,
    "method_metadata": {
        "estimator": "Anderson-Rubin test inversion with an intercept and x",
        "vcov": "Conventional homoskedastic joint F test",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
