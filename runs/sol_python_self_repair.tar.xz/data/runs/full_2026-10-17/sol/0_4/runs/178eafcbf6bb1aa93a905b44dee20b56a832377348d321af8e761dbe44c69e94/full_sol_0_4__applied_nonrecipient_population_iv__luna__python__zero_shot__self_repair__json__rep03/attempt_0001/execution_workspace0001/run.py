import csv
import json
import math


TASK_ID = "applied_nonrecipient_population_iv"


def solve_linear_system(matrix, vector):
    """Solve a square linear system with partial pivoting."""
    size = len(vector)
    a = [row[:] for row in matrix]
    b = vector[:]

    for col in range(size):
        pivot = max(range(col, size), key=lambda row: abs(a[row][col]))
        if abs(a[pivot][col]) < 1e-12:
            raise ValueError("The weighted IV system is singular.")
        a[col], a[pivot] = a[pivot], a[col]
        b[col], b[pivot] = b[pivot], b[col]

        for row in range(col + 1, size):
            factor = a[row][col] / a[col][col]
            for j in range(col, size):
                a[row][j] -= factor * a[col][j]
            b[row] -= factor * b[col]

    solution = [0.0] * size
    for row in range(size - 1, -1, -1):
        solution[row] = (
            b[row] - math.fsum(a[row][j] * solution[j] for j in range(row + 1, size))
        ) / a[row][row]
    return solution


with open("households.csv", newline="", encoding="utf-8-sig") as file:
    retained = [row for row in csv.DictReader(file) if int(row["recipient"]) == 0]

n_obs = len(retained)
if n_obs == 0:
    raise ValueError("No nonrecipient households were found.")

# Column order: ineligible indicator, eligible indicator, their baseline
# interactions, then their dose interactions. The last two instruments use
# the corresponding instrument interactions instead of dose interactions.
cross_products = [[[] for _ in range(6)] for _ in range(6)]
right_products = [[] for _ in range(6)]
weight_parts = {0: [], 1: []}
dose_parts = {0: [], 1: []}
group_rows = {0: 0, 1: 0}

for row in retained:
    eligible = int(row["eligible"])
    if eligible not in (0, 1):
        raise ValueError("Eligibility must be zero or one.")

    ineligible = 1 - eligible
    baseline = float(row["baseline"])
    dose = float(row["dose"])
    instrument = float(row["instrument"])
    weight = float(row["weight"])
    outcome = float(row["outcome"])
    if not all(math.isfinite(value) for value in (baseline, dose, instrument, weight, outcome)):
        raise ValueError("Household data contain a nonfinite value.")
    if weight <= 0:
        raise ValueError("Regression weights must be positive.")

    x = [
        ineligible,
        eligible,
        baseline * ineligible,
        baseline * eligible,
        dose * ineligible,
        dose * eligible,
    ]
    z = [
        ineligible,
        eligible,
        baseline * ineligible,
        baseline * eligible,
        instrument * ineligible,
        instrument * eligible,
    ]

    for i in range(6):
        right_products[i].append(weight * z[i] * outcome)
        for j in range(6):
            cross_products[i][j].append(weight * z[i] * x[j])

    weight_parts[eligible].append(weight)
    dose_parts[eligible].append(weight * dose)
    group_rows[eligible] += 1

moment_matrix = [
    [math.fsum(cross_products[i][j]) for j in range(6)]
    for i in range(6)
]
moment_vector = [math.fsum(right_products[i]) for i in range(6)]

# This model has six instruments and six regressors. Its weighted 2SLS
# coefficients solve the exactly identified weighted IV moment equations.
coefficients = solve_linear_system(moment_matrix, moment_vector)

mean_dose = {}
for group in (0, 1):
    total_weight = math.fsum(weight_parts[group])
    if total_weight <= 0:
        raise ValueError(f"No retained households in eligibility group {group}.")
    mean_dose[group] = math.fsum(dose_parts[group]) / total_weight

ineligible_effect = coefficients[4] * mean_dose[0]
eligible_nonrecipient_effect = coefficients[5] * mean_dose[1]

population = {}
with open("census.csv", newline="", encoding="utf-8-sig") as file:
    for row in csv.DictReader(file):
        group = int(row["eligible"])
        if group not in (0, 1):
            raise ValueError("Census eligibility must be zero or one.")
        count = int(row["nonrecipient_population"])
        if count < 0:
            raise ValueError("Census population counts must be nonnegative.")
        population[group] = population.get(group, 0) + count

if set(population) != {0, 1} or sum(population.values()) == 0:
    raise ValueError("Census data must provide positive total population across both groups.")

population_effect = (
    population[0] * ineligible_effect
    + population[1] * eligible_nonrecipient_effect
) / sum(population.values())


def estimate(term, value):
    return {
        "term": term,
        "estimate": value,
        "se": None,
        "n_obs": n_obs,
    }


result = {
    "task_id": TASK_ID,
    "platform": "python",
    "estimates": [
        estimate("ineligible_effect", ineligible_effect),
        estimate("eligible_nonrecipient_effect", eligible_nonrecipient_effect),
        estimate("population_effect", population_effect),
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS, exactly identified",
        "sample": "households with recipient=0",
        "regression_weight": "weight",
        "counterfactual": "dose=0 for every retained household; synthetic attribution convention",
        "group_effect": "fitted group dose slope times household-weighted mean dose among retained group observations",
        "population_aggregation": "group effects weighted by census nonrecipient_population",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "group_n_obs": {
            "ineligible": group_rows[0],
            "eligible": group_rows[1],
        },
        "weighted_mean_dose": {
            "ineligible": mean_dose[0],
            "eligible": mean_dose[1],
        },
        "census_nonrecipient_population": {
            "ineligible": population[0],
            "eligible": population[1],
        },
    },
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file, indent=2, allow_nan=False)
