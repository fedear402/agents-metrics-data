import csv
import json
from collections import defaultdict


def read_csv(path):
    with open(path, newline="", encoding="utf-8-sig") as file:
        return list(csv.DictReader(file))


def solve(matrix, vector):
    """Solve a small linear system with partial pivoting."""
    n = len(vector)
    augmented = [list(map(float, matrix[i])) + [float(vector[i])] for i in range(n)]

    for column in range(n):
        pivot = max(range(column, n), key=lambda row: abs(augmented[row][column]))
        if abs(augmented[pivot][column]) < 1e-14:
            raise ValueError("The IV system is singular.")
        augmented[column], augmented[pivot] = augmented[pivot], augmented[column]

        scale = augmented[column][column]
        augmented[column] = [value / scale for value in augmented[column]]

        for row in range(n):
            if row == column:
                continue
            factor = augmented[row][column]
            augmented[row] = [
                augmented[row][j] - factor * augmented[column][j]
                for j in range(n + 1)
            ]

    return [augmented[row][-1] for row in range(n)]


crosswalk_rows = read_csv("crosswalk.csv")
trade_rows = read_csv("trade.csv")
area_rows = read_csv("areas.csv")
employment_rows = read_csv("employment.csv")
outcome_rows = read_csv("outcomes.csv")

code_to_industry = {
    row["code"]: row["industry"] for row in crosswalk_rows
}
industries = set(code_to_industry.values())
if len(industries) != 4:
    raise ValueError("Expected four industries.")

areas = {
    (row["area"], row["period"], row["vintage"]): row
    for row in area_rows
}

employment = defaultdict(float)
national_employment = defaultdict(float)
for row in employment_rows:
    key = (row["area"], row["period"], row["vintage"], row["industry"])
    value = float(row["employment"])
    employment[key] += value
    national_employment[(row["period"], row["vintage"], row["industry"])] += value

trade = {}
for row in trade_rows:
    industry = code_to_industry[row["code"]]
    key = (row["period"], industry)
    if key in trade:
        raise ValueError(f"Duplicate trade row for {key}.")
    trade[key] = row


def exposure(area, period, vintage, change_column):
    total = float(areas[(area, period, vintage)]["total_employment"])
    if total <= 0:
        raise ValueError("Total employment must be positive.")

    result = 0.0
    for industry in industries:
        row = trade[(period, industry)]
        national = national_employment[(period, vintage, industry)]
        if national <= 0:
            raise ValueError("National industry employment must be positive.")

        local = employment[(area, period, vintage, industry)]
        real_change = float(row[change_column]) / (float(row["price_index"]) / 100.0)
        decade_factor = 10.0 / float(row["years"])
        result += (
            (local / total)
            * (real_change / national)
            / 1000.0
            * decade_factor
        )
    return result


# Columns are intercept, period, control, and endogenous exposure.
# Instruments are intercept, period, control, and early-vintage exposure.
cross_product = [[0.0] * 4 for _ in range(4)]
instrument_outcome = [0.0] * 4
exposures = {}
instruments = {}

for row in outcome_rows:
    area, period = row["area"], row["period"]
    x = exposure(area, period, "base", "us_change")
    z = exposure(area, period, "early", "other_change")
    weight = float(areas[(area, period, "base")]["population"])
    if weight <= 0:
        raise ValueError("Regression weights must be positive.")

    regressors = [1.0, float(period), float(row["control"]), x]
    instruments_row = [1.0, float(period), float(row["control"]), z]
    outcome = float(row["change_pp"])

    for i in range(4):
        instrument_outcome[i] += weight * instruments_row[i] * outcome
        for j in range(4):
            cross_product[i][j] += weight * instruments_row[i] * regressors[j]

    exposures[(area, period)] = x
    instruments[(area, period)] = z

n_obs = len(outcome_rows)
if n_obs != 72 or len(exposures) != 72:
    raise ValueError("Expected 72 distinct area-period estimation rows.")

iv_slope = solve(cross_product, instrument_outcome)[3]

estimates = [
    {
        "term": "iv_slope",
        "estimate": iv_slope,
        "se": None,
        "n_obs": 72,
    },
    {
        "term": "exposure_area0_period0",
        "estimate": exposures[("0", "0")],
        "se": None,
        "n_obs": 72,
    },
    {
        "term": "exposure_area0_period1",
        "estimate": exposures[("0", "1")],
        "se": None,
        "n_obs": 72,
    },
    {
        "term": "instrument_area0_period0",
        "estimate": instruments[("0", "0")],
        "se": None,
        "n_obs": 72,
    },
]

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "population-weighted exactly identified 2SLS",
        "regressors": ["intercept", "period", "control", "x"],
        "instruments": ["intercept", "period", "control", "z"],
        "exposure_units": "thousands of real dollars per worker per decade",
        "outcome_units": "percentage points per decade",
    },
    "diagnostics": {
        "n_obs": 72,
        "n_industries": 4,
        "n_periods": len({row["period"] for row in outcome_rows}),
    },
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file, indent=2, allow_nan=False)
