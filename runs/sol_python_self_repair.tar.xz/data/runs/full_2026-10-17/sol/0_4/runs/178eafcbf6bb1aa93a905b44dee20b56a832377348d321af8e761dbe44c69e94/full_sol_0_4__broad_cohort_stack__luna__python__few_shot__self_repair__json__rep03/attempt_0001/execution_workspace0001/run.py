import json

import numpy as np
import pandas as pd


def estimate_cohort(data, cohort):
    window = range(cohort - 2, cohort + 3)
    eligible = data["g"].eq(cohort) | data["g"].eq(0) | data["g"].gt(cohort + 2)
    sample = data.loc[eligible & data["time"].isin(window)].copy()

    complete_ids = sample.groupby("id")["time"].nunique()
    sample = sample.loc[sample["id"].isin(complete_ids[complete_ids == 5].index)].copy()

    sample["did"] = (sample["g"].eq(cohort) & sample["time"].ge(cohort)).astype(float)

    # For this balanced panel, two-way demeaning removes unit and time fixed effects.
    for column in ("y", "did"):
        sample[column + "_resid"] = (
            sample[column]
            - sample.groupby("id")[column].transform("mean")
            - sample.groupby("time")[column].transform("mean")
            + sample[column].mean()
        )

    did_resid = sample["did_resid"].to_numpy()
    y_resid = sample["y_resid"].to_numpy()
    estimate = np.dot(did_resid, y_resid) / np.dot(did_resid, did_resid)
    treated_count = sample.loc[sample["g"].eq(cohort), "id"].nunique()

    return float(estimate), int(len(sample)), int(treated_count)


data = pd.read_csv("input.csv")
results = {cohort: estimate_cohort(data, cohort) for cohort in (3, 5, 7)}

estimates = [
    {
        "term": f"att_g{cohort}",
        "estimate": results[cohort][0],
        "se": None,
        "n_obs": results[cohort][1],
    }
    for cohort in (3, 5, 7)
]

total_treated = sum(result[2] for result in results.values())
weighted_att = sum(
    estimate * treated_count
    for estimate, _, treated_count in results.values()
) / total_treated

estimates.append(
    {
        "term": "att_weighted",
        "estimate": float(weighted_att),
        "se": None,
        "n_obs": sum(result[1] for result in results.values()),
    }
)

output = {
    "task_id": "broad_cohort_stack",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {},
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
