import json

import numpy as np
import pandas as pd

data = pd.read_csv("input.csv")
data = data[["score", "participated", "earnings"]].dropna()
data = data.loc[data["score"].abs() < 1].copy()

score = data["score"].to_numpy(dtype=float)
right = (score >= 0).astype(float)
weights = 1.0 - np.abs(score)
X = np.column_stack((np.ones(len(data)), score, right, right * score))
Y = data[["earnings", "participated"]].to_numpy(dtype=float)

bread = np.linalg.inv(X.T @ (weights[:, None] * X))
beta = bread @ X.T @ (weights[:, None] * Y)
residuals = Y - X @ beta

# Each column contains the HC0 influence contributions for one discontinuity.
influence = (
    weights[:, None]
    * residuals
    * (X @ bread[:, 2])[:, None]
)
joint_cov = influence.T @ influence

reduced_form = float(beta[2, 0])
first_stage = float(beta[2, 1])
treatment_effect = reduced_form / first_stage

gradient = np.array([1.0 / first_stage, -reduced_form / first_stage**2])
treatment_variance = float(gradient @ joint_cov @ gradient)

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {
            "term": "treatment_effect",
            "estimate": float(treatment_effect),
            "se": float(np.sqrt(max(treatment_variance, 0.0))),
            "n_obs": int(len(data)),
        },
        {
            "term": "reduced_form",
            "estimate": reduced_form,
            "se": float(np.sqrt(max(joint_cov[0, 0], 0.0))),
            "n_obs": int(len(data)),
        },
        {
            "term": "first_stage",
            "estimate": first_stage,
            "se": float(np.sqrt(max(joint_cov[1, 1], 0.0))),
            "n_obs": int(len(data)),
        },
    ],
    "method_metadata": {
        "estimator": "Fuzzy local-linear regression discontinuity, triangular weights, bandwidth 1",
        "vcov": "Joint HC0 sandwich covariance; delta-method treatment-effect SE",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output)
