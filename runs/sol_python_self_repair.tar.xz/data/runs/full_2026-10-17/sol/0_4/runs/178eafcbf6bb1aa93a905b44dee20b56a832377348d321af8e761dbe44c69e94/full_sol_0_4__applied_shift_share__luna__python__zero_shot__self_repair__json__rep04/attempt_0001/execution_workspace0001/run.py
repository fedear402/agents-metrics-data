import json

import numpy as np
import pandas as pd


def weighted_iv(y, x, instrument, weights):
    design = np.column_stack((np.ones(len(x)), x))
    instruments = np.column_stack((np.ones(len(x)), instrument))

    cross = instruments.T @ (weights[:, None] * design)
    moments = instruments.T @ (weights * y)
    coefficients = np.linalg.solve(cross, moments)

    residuals = y - design @ coefficients
    weighted_instruments = weights[:, None] * instruments
    meat = weighted_instruments.T @ (
        residuals[:, None] ** 2 * weighted_instruments
    )
    inverse_cross = np.linalg.inv(cross)
    covariance = inverse_cross @ meat @ inverse_cross.T
    covariance *= len(y) / (len(y) - 2)  # HC1

    return float(coefficients[1]), float(np.sqrt(covariance[1, 1]))


data = pd.read_csv("input.csv")
regions = data.drop_duplicates("region_id").set_index("region_id")
regions["e"] = regions["region_weight"] / regions["region_weight"].sum()

data = data.join(regions["e"], on="region_id")
data["exposure_weight"] = data["e"] * data["share"]

z = data.groupby("region_id").apply(
    lambda group: (group["share"] * group["shock"]).sum(),
    include_groups=False,
)
regions["z"] = z

for variable in ("y", "x", "z"):
    regions[f"{variable}0"] = (
        regions[variable] - np.sum(regions["e"] * regions[variable])
    )
    data = data.join(regions[f"{variable}0"], on="region_id")

industries = data.groupby("industry_id", sort=False)
s = industries["exposure_weight"].sum()
shock = industries["shock"].first()

aggregated = pd.DataFrame({"s": s, "shock": shock})
for variable in ("y", "x", "z"):
    numerator = (
        data["exposure_weight"] * data[f"{variable}0"]
    ).groupby(data["industry_id"], sort=False).sum()
    aggregated[f"{variable}bar"] = numerator / s

aggregated = aggregated.loc[aggregated["s"] > 0]
n = len(aggregated)
weights = aggregated["s"].to_numpy(dtype=float)
shocks = aggregated["shock"].to_numpy(dtype=float)

effect, effect_se = weighted_iv(
    aggregated["ybar"].to_numpy(dtype=float),
    aggregated["xbar"].to_numpy(dtype=float),
    shocks,
    weights,
)
first_stage, first_stage_se = weighted_iv(
    aggregated["xbar"].to_numpy(dtype=float),
    aggregated["zbar"].to_numpy(dtype=float),
    shocks,
    weights,
)

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": effect, "se": effect_se, "n_obs": n},
        {
            "term": "first_stage",
            "estimate": first_stage,
            "se": first_stage_se,
            "n_obs": n,
        },
        {
            "term": "effective_shocks",
            "estimate": float(1.0 / np.sum(weights**2)),
            "se": None,
            "n_obs": n,
        },
    ],
    "method_metadata": {
        "estimator": "Regional weighted 2SLS via BHJ shock-level aggregation",
        "vcov": "Shock-level heteroskedasticity-robust HC1, N/(N-2)",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output, indent=2)
