import json

import numpy as np
import pandas as pd


def weighted_iv(y, x, instrument, weights):
    weights = np.asarray(weights, dtype=float)
    y = np.asarray(y, dtype=float)
    x = np.asarray(x, dtype=float)
    instrument = np.asarray(instrument, dtype=float)

    def center(values):
        return values - np.average(values, weights=weights)

    yc = center(y)
    xc = center(x)
    qc = center(instrument)

    denominator = np.sum(weights * qc * xc)
    if np.isclose(denominator, 0.0):
        raise ValueError("The shock-level IV denominator is zero.")

    slope = np.sum(weights * qc * yc) / denominator
    residual = yc - slope * xc
    n = len(weights)
    if n <= 2:
        raise ValueError("HC1 requires more than two industries.")

    variance = (
        n / (n - 2)
        * np.sum((weights * qc * residual) ** 2)
        / denominator**2
    )
    return float(slope), float(np.sqrt(variance))


data = pd.read_csv("input.csv")
columns = [
    "region_id",
    "industry_id",
    "share",
    "shock",
    "region_weight",
    "x",
    "y",
]
data = data[columns].copy()

region = data.groupby("region_id", sort=False).agg(
    region_weight=("region_weight", "first"),
    x=("x", "first"),
    y=("y", "first"),
)
region["e"] = region["region_weight"] / region["region_weight"].sum()

data["share_shock"] = data["share"] * data["shock"]
region["z"] = data.groupby("region_id")["share_shock"].sum().reindex(region.index)

for variable in ("y", "x", "z"):
    region[f"{variable}0"] = (
        region[variable] - np.average(region[variable], weights=region["e"])
    )

data = data.join(region[["e", "y0", "x0", "z0"]], on="region_id")
data["exposure"] = data["e"] * data["share"]
for variable in ("y", "x", "z"):
    data[f"{variable}_numerator"] = data["exposure"] * data[f"{variable}0"]

industry = data.groupby("industry_id", sort=False).agg(
    shock=("shock", "first"),
    s=("exposure", "sum"),
    y_numerator=("y_numerator", "sum"),
    x_numerator=("x_numerator", "sum"),
    z_numerator=("z_numerator", "sum"),
)
industry = industry.loc[industry["s"] > 0].copy()

for variable in ("y", "x", "z"):
    industry[f"{variable}bar"] = (
        industry[f"{variable}_numerator"] / industry["s"]
    )

effect, effect_se = weighted_iv(
    industry["ybar"], industry["xbar"], industry["shock"], industry["s"]
)
first_stage, first_stage_se = weighted_iv(
    industry["xbar"], industry["zbar"], industry["shock"], industry["s"]
)

n_industries = len(industry)
effective_shocks = float(1 / np.sum(industry["s"].to_numpy() ** 2))

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {
            "term": "effect",
            "estimate": effect,
            "se": effect_se,
            "n_obs": n_industries,
        },
        {
            "term": "first_stage",
            "estimate": first_stage,
            "se": first_stage_se,
            "n_obs": n_industries,
        },
        {
            "term": "effective_shocks",
            "estimate": effective_shocks,
            "se": None,
            "n_obs": n_industries,
        },
    ],
    "method_metadata": {
        "estimator": "Weighted regional 2SLS via shock-level aggregation",
        "vcov": "Shock-level heteroskedasticity-robust HC1, multiplier N/(N-2)",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file, allow_nan=False)
