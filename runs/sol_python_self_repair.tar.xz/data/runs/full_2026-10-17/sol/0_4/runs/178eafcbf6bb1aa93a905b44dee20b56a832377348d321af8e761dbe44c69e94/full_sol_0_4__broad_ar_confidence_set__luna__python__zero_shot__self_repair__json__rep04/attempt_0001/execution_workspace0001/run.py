import json

import numpy as np
import pandas as pd
from scipy.stats import f

data = pd.read_csv("input.csv")
n = len(data)
y = data["y"].to_numpy(dtype=float)
d = data["endog"].to_numpy(dtype=float)

restricted = np.column_stack((np.ones(n), data["x"].to_numpy(dtype=float)))
unrestricted = np.column_stack(
    (
        restricted,
        data["z1"].to_numpy(dtype=float),
        data["z2"].to_numpy(dtype=float),
    )
)


def residuals(matrix, vector):
    return vector - matrix @ np.linalg.lstsq(matrix, vector, rcond=None)[0]


ry, rd = residuals(restricted, y), residuals(restricted, d)
uy, ud = residuals(unrestricted, y), residuals(unrestricted, d)

df_den = n - 4
critical = f.ppf(0.95, 2, df_den)
scale = 1.0 + 2.0 * critical / df_den

# The confidence set consists of all beta for which Q(beta) <= 0.
a = float(rd @ rd - scale * (ud @ ud))
b = float(-2.0 * (ry @ rd - scale * (uy @ ud)))
c = float(ry @ ry - scale * (uy @ uy))
roots = np.sort(np.roots([a, b, c]))

if len(roots) != 2 or np.any(np.abs(roots.imag) > 1e-8):
    raise ValueError("Expected two real, finite confidence-set boundaries")

boundary_low, boundary_high = roots.real
if not np.all(np.isfinite([boundary_low, boundary_high])):
    raise ValueError("Confidence-set boundaries must be finite")

r_at_one = ry - rd
u_at_one = uy - ud
rss_restricted = float(r_at_one @ r_at_one)
rss_unrestricted = float(u_at_one @ u_at_one)
ar_f_at_one = ((rss_restricted - rss_unrestricted) / 2.0) / (
    rss_unrestricted / df_den
)

values = {
    "boundary_low": float(boundary_low),
    "boundary_high": float(boundary_high),
    "accepts_zero": float(c <= 0.0),
    "unbounded": float(a < 0.0),
    "ar_f_at_one": float(ar_f_at_one),
}

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": [
        {"term": term, "estimate": value, "se": None, "n_obs": n}
        for term, value in values.items()
    ],
    "method_metadata": {
        "estimator": "Anderson-Rubin confidence set by quadratic F-test inversion",
        "vcov": "Conventional homoskedastic OLS",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output)
