import csv
import json
from collections import defaultdict


def read_csv(filename):
    with open(filename, newline="", encoding="utf-8-sig") as file:
        return list(csv.DictReader(file))


def solve(matrix, vector):
    """Solve a square linear system with partial pivoting."""
    n = len(vector)
    a = [list(map(float, row)) + [float(vector[i])] for i, row in enumerate(matrix)]

    for col in range(n):
        pivot = max(range(col, n), key=lambda row: abs(a[row][col]))
        if abs(a[pivot][col]) < 1e-14:
            raise ValueError("The IV system is singular.")
        a[col], a[pivot] = a[pivot], a[col]

        scale = a[col][col]
        for j in range(col, n + 1):
            a[col][j] /= scale

        for row in range(n):
            if row == col:
                continue
            factor = a[row][col]
            for j in range(col, n + 1):
                a[row][j] -= factor * a[col][j]

    return [a[i][n] for i in range(n)]


crosswalk = {row["code"]: row["industry"] for row in read_csv("crosswalk.csv")}
trade = read_csv("trade.csv")
areas = read_csv("areas.csv")
employment = read_csv("employment.csv")
outcomes = read_csv("outcomes.csv")

national = defaultdict(float)
area_employment = defaultdict(float)

for row in employment:
    area, period, vintage, industry = (
        row["area"],
        row["period"],
        row["vintage"],
        row["industry"],
    )
    value = float(row["employment"])
    national[(period, vintage, industry)] += value
    area_employment[(area, period, vintage, industry)] += value

area_data = {
    (row["area"], row["period"], row["vintage"]): row
    for row in areas
}
trade_by_period = defaultdict(list)
for row in trade:
    trade_by_period[row["period"]].append(row)

exposures = {}
for area, period in {(row["area"], row["period"]) for row in outcomes}:
    values = {}
    for vintage, change_column, name in (
        ("base", "us_change", "x"),
        ("early", "other_change", "z"),
    ):
        total_employment = float(
            area_data[(area, period, vintage)]["total_employment"]
        )
        exposure = 0.0

        for row in trade_by_period[period]:
            industry = crosswalk[row["code"]]
            share = (
                area_employment[(area, period, vintage, industry)]
                / total_employment
            )
            national_employment = national[(period, vintage, industry)]
            exposure += (
                share
                * (float(row[change_column]) / national_employment)
                / (float(row["price_index"]) / 100.0)
                / 1000.0
                * (10.0 / float(row["years"]))
            )

        values[name] = exposure
    exposures[(area, period)] = values

# With four regressors and four instruments, weighted 2SLS solves
# (Z' W X) beta = Z' W y.
moment_matrix = [[0.0] * 4 for _ in range(4)]
moment_outcome = [0.0] * 4

for row in outcomes:
    area, period = row["area"], row["period"]
    period_value = float(period)
    control = float(row["control"])
    outcome = float(row["change_pp"])
    weight = float(area_data[(area, period, "base")]["population"])
    x = exposures[(area, period)]["x"]
    z = exposures[(area, period)]["z"]

    regressors = [1.0, period_value, control, x]
    instruments = [1.0, period_value, control, z]

    for i in range(4):
        moment_outcome[i] += weight * instruments[i] * outcome
        for j in range(4):
            moment_matrix[i][j] += (
                weight * instruments[i] * regressors[j]
            )

iv_slope = solve(moment_matrix, moment_outcome)[3]
n_obs = len(outcomes)

requested = [
    ("iv_slope", iv_slope),
    ("exposure_area0_period0", exposures[("0", "0")]["x"]),
    ("exposure_area0_period1", exposures[("0", "1")]["x"]),
    ("instrument_area0_period0", exposures[("0", "0")]["z"]),
]

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [
        {
            "term": term,
            "estimate": estimate,
            "se": None,
            "n_obs": n_obs,
        }
        for term, estimate in requested
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "regressors": ["intercept", "period", "control", "x"],
        "instruments": ["intercept", "period", "control", "z"],
        "weight": "base-vintage population",
        "exposure_unit": "thousands of real dollars per worker per decade",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "n_industries": len(set(crosswalk.values())),
    },
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file, indent=2, allow_nan=False)
