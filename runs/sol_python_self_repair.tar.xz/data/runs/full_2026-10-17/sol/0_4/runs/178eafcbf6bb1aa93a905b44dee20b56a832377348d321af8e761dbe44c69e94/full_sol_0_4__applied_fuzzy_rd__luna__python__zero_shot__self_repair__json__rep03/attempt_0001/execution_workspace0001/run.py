import json

import numpy as np
import pandas as pd

data = pd.read_csv("input.csv")
data = data.loc[data["score"].abs() < 1].copy()

score = data["score"].to_numpy(dtype=float)
right = (score >= 0).astype(float)
weights = 1 - np.abs(score)
X = np.column_stack((np.ones(len(data)), right, score, right * score))
Y = data[["earnings", "participated"]].to_numpy(dtype=float)

bread = np.linalg.inv(X.T @ (weights[:, None] * X))
beta = bread @ X.T @ (weights[:, None] * Y)
residuals = Y - X @ beta

influence = (X @ bread[:, 1]) * weights
covariance = (influence[:, None] * residuals).T @ (
    influence[:, None] * residuals
)

reduced_form = float(beta[1, 0])
first_stage = float(beta[1, 1])
treatment_effect = reduced_form / first_stage

gradient = np.array([
    1 / first_stage,
    -reduced_form / first_stage**2,
])
treatment_variance = float(gradient @ covariance @ gradient)
n_obs = int(len(data))

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {
            "term": "treatment_effect",
            "estimate": treatment_effect,
            "se": float(np.sqrt(treatment_variance)),
            "n_obs": n_obs,
        },
        {
            "term": "reduced_form",
            "estimate": reduced_form,
            "se": float(np.sqrt(covariance[0, 0])),
            "n_obs": n_obs,
        },
        {
            "term": "first_stage",
            "estimate": first_stage,
            "se": float(np.sqrt(covariance[1, 1])),
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "Fuzzy RD, triangular-weighted local linear Wald ratio, bandwidth 1",
        "vcov": "Conventional HC0 sandwich with joint covariance and delta method",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output)
