import json

import numpy as np
import pandas as pd
from scipy.stats import f as f_distribution

data = pd.read_csv("./input.csv")
data["y"] = pd.to_numeric(data["y"], errors="coerce")
data = data.dropna(subset=["group", "y"])

groups = [values.to_numpy(dtype=float) for _, values in data.groupby("group")]
n_obs = sum(len(values) for values in groups)
df_num = len(groups) - 1
df_den = n_obs - len(groups)

if df_num <= 0 or df_den <= 0:
    raise ValueError("ANOVA requires at least two groups and positive residual degrees of freedom.")

grand_mean = data["y"].mean()
ss_between = sum(len(values) * (values.mean() - grand_mean) ** 2 for values in groups)
ss_within = sum(np.sum((values - values.mean()) ** 2) for values in groups)
f_statistic = (ss_between / df_num) / (ss_within / df_den)
p_value = f_distribution.sf(f_statistic, df_num, df_den)

estimates = [
    {"term": term, "estimate": float(value), "se": None, "n_obs": n_obs}
    for term, value in [
        ("F", f_statistic),
        ("df_num", df_num),
        ("df_den", df_den),
        ("p_value", p_value),
    ]
]

result = {
    "task_id": "anova_oneway",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "Classical one-way ANOVA",
        "vcov": "Pooled within-group variance",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output, allow_nan=False)
