import json

import numpy as np
import pandas as pd
import statsmodels.api as sm

data = pd.read_csv("input.csv")
outcomes = [0, 1, 2]
assert len(data) == 480
assert set(data["y"].unique()) == set(outcomes)
assert data[["y", "x", "z"]].notna().all().all()

design = sm.add_constant(data[["x", "z"]], has_constant="add")
fit = sm.MNLogit(data["y"], design).fit(method="newton", disp=False, tol=1e-10)

# Parameter columns 0 and 1 represent outcomes 1 and 2.
assert list(fit.params.columns) == [0, 1]
coefficients = fit.params.copy()
errors = fit.bse.copy()
coefficients.columns = outcomes[1:]
errors.columns = outcomes[1:]

zero = pd.DataFrame({"const": [1.0], "x": [0.0], "z": [0.0]})
prob_cat2_zero = float(np.asarray(fit.predict(zero))[0, 2])
n_obs = int(fit.nobs)

rows = []
for term, variable, outcome in [
    ("x_cat1", "x", 1),
    ("z_cat1", "z", 1),
    ("x_cat2", "x", 2),
    ("z_cat2", "z", 2),
]:
    rows.append({
        "term": term,
        "estimate": float(coefficients.loc[variable, outcome]),
        "se": float(errors.loc[variable, outcome]),
        "n_obs": n_obs,
    })

rows.append({
    "term": "prob_cat2_zero",
    "estimate": prob_cat2_zero,
    "se": None,
    "n_obs": n_obs,
})

result = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": rows,
    "method_metadata": {
        "estimator": "multinomial logit maximum likelihood",
        "vcov": "inverse observed information",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
