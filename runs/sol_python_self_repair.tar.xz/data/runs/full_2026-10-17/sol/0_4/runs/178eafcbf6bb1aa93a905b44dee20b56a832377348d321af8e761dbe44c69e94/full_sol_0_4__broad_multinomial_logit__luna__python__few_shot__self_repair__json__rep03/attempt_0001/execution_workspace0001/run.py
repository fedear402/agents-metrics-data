import json

import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy.special import softmax

data = pd.read_csv("input.csv")
outcomes = [0, 1, 2]
assert set(data["y"].unique()) == set(outcomes)

X = sm.add_constant(data[["x", "z"]], has_constant="add")
fit = sm.MNLogit(data["y"], X).fit(method="newton", maxiter=1000, tol=1e-12, disp=False)
assert fit.mle_retvals["converged"]

coefficients = fit.params.copy()
errors = fit.bse.copy()
assert list(coefficients.columns) == [0, 1]
coefficients.columns = [1, 2]
errors.columns = [1, 2]

prob_cat2_zero = float(
    softmax(
        np.array([
            0.0,
            coefficients.loc["const", 1],
            coefficients.loc["const", 2],
        ])
    )[2]
)

n_obs = int(len(data))
terms = [
    ("x_cat1", "x", 1),
    ("z_cat1", "z", 1),
    ("x_cat2", "x", 2),
    ("z_cat2", "z", 2),
]
estimates = [
    {
        "term": name,
        "estimate": float(coefficients.loc[variable, outcome]),
        "se": float(errors.loc[variable, outcome]),
        "n_obs": n_obs,
    }
    for name, variable, outcome in terms
]
estimates.append(
    {
        "term": "prob_cat2_zero",
        "estimate": prob_cat2_zero,
        "se": None,
        "n_obs": n_obs,
    }
)

result = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "multinomial logit maximum likelihood; outcome 0 base",
        "vcov": "inverse observed information",
    },
    "diagnostics": {},
}
with open("result.json", "w", encoding="utf-8") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
