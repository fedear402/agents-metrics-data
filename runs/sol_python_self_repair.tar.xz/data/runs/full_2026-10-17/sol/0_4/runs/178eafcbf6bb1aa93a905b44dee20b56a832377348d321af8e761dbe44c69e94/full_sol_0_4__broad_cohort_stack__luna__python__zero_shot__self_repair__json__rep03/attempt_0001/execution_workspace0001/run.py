import csv
import json
from collections import defaultdict

rows = []
with open("input.csv", newline="") as file:
    for row in csv.DictReader(file):
        rows.append({
            "id": row["id"],
            "time": int(row["time"]),
            "g": int(row["g"]),
            "y": float(row["y"]),
        })


def cohort_estimate(cohort):
    window = set(range(cohort - 2, cohort + 3))
    eligible = defaultdict(dict)

    for row in rows:
        if row["time"] in window and (
            row["g"] == cohort or row["g"] == 0 or row["g"] > cohort + 2
        ):
            eligible[row["id"]][row["time"]] = row

    units = {
        unit: observations
        for unit, observations in eligible.items()
        if set(observations) == window
    }

    comparison = []
    for unit, observations in units.items():
        for time in sorted(window):
            row = observations[time]
            comparison.append((
                unit,
                time,
                int(row["g"] == cohort and time >= cohort),
                row["y"],
            ))

    unit_means = {}
    for unit in units:
        unit_rows = [r for r in comparison if r[0] == unit]
        unit_means[unit] = (
            sum(r[2] for r in unit_rows) / 5,
            sum(r[3] for r in unit_rows) / 5,
        )

    time_means = {}
    for time in window:
        time_rows = [r for r in comparison if r[1] == time]
        time_means[time] = (
            sum(r[2] for r in time_rows) / len(time_rows),
            sum(r[3] for r in time_rows) / len(time_rows),
        )

    overall_did = sum(r[2] for r in comparison) / len(comparison)
    overall_y = sum(r[3] for r in comparison) / len(comparison)

    numerator = denominator = 0.0
    for unit, time, did, y in comparison:
        residual_did = did - unit_means[unit][0] - time_means[time][0] + overall_did
        residual_y = y - unit_means[unit][1] - time_means[time][1] + overall_y
        numerator += residual_did * residual_y
        denominator += residual_did * residual_did

    treated_units = sum(
        observations[cohort]["g"] == cohort
        for observations in units.values()
    )
    return numerator / denominator, len(comparison), treated_units


results = {cohort: cohort_estimate(cohort) for cohort in (3, 5, 7)}
total_treated = sum(result[2] for result in results.values())
weighted = sum(
    result[0] * result[2] for result in results.values()
) / total_treated

estimates = [
    {
        "term": f"att_g{cohort}",
        "estimate": results[cohort][0],
        "se": None,
        "n_obs": results[cohort][1],
    }
    for cohort in (3, 5, 7)
]
estimates.append({
    "term": "att_weighted",
    "estimate": weighted,
    "se": None,
    "n_obs": sum(result[1] for result in results.values()),
})

with open("result.json", "w") as file:
    json.dump({
        "task_id": "broad_cohort_stack",
        "platform": "python",
        "estimates": estimates,
        "method_metadata": {},
        "diagnostics": {},
    }, file, indent=2)
