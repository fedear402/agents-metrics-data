import json

import numpy as np
import pandas as pd


def estimate_cohort(data, cohort):
    window = list(range(cohort - 2, cohort + 3))
    eligible = data[
        data["time"].isin(window)
        & (
            (data["g"] == cohort)
            | (data["g"] == 0)
            | (data["g"] > cohort + 2)
        )
    ].copy()

    balanced_ids = eligible.groupby("id")["time"].nunique()
    balanced_ids = balanced_ids[balanced_ids == len(window)].index
    sample = eligible[eligible["id"].isin(balanced_ids)].copy()

    sample["did"] = (
        (sample["g"] == cohort) & (sample["time"] >= cohort)
    ).astype(float)

    # Remove unit and calendar-time fixed effects using the balanced panel.
    for column in ("did", "y"):
        values = sample[column].astype(float)
        sample[column + "_residual"] = (
            values
            - sample.groupby("id")[column].transform("mean")
            - sample.groupby("time")[column].transform("mean")
            + values.mean()
        )

    did_residual = sample["did_residual"].to_numpy()
    y_residual = sample["y_residual"].to_numpy()
    coefficient = np.dot(did_residual, y_residual) / np.dot(
        did_residual, did_residual
    )

    treated_count = sample.loc[sample["g"] == cohort, "id"].nunique()
    return float(coefficient), int(treated_count), int(len(sample))


data = pd.read_csv("input.csv")
results = {cohort: estimate_cohort(data, cohort) for cohort in (3, 5, 7)}

weighted = sum(
    results[cohort][0] * results[cohort][1] for cohort in (3, 5, 7)
) / sum(results[cohort][1] for cohort in (3, 5, 7))

estimates = [
    {
        "term": f"att_g{cohort}",
        "estimate": results[cohort][0],
        "se": None,
        "n_obs": results[cohort][2],
    }
    for cohort in (3, 5, 7)
]
estimates.append(
    {
        "term": "att_weighted",
        "estimate": float(weighted),
        "se": None,
        "n_obs": sum(results[cohort][2] for cohort in (3, 5, 7)),
    }
)

output = {
    "task_id": "broad_cohort_stack",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {},
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
