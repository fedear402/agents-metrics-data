import json

import numpy as np
import pandas as pd


data = pd.read_csv("input.csv")
data = data.loc[data["score"].abs() < 1].copy()

score = data["score"].to_numpy(dtype=float)
right = (score >= 0).astype(float)
weights = 1.0 - np.abs(score)
outcomes = data[["earnings", "participated"]].to_numpy(dtype=float)

# The right indicator selects the right-limit minus left-limit discontinuity.
design = np.column_stack((np.ones(len(data)), right, score, right * score))
bread = np.linalg.inv(design.T @ (weights[:, None] * design))
coefficients = bread @ design.T @ (weights[:, None] * outcomes)
residuals = outcomes - design @ coefficients

contrast = np.array([0.0, 1.0, 0.0, 0.0])
reduced_form, first_stage = contrast @ coefficients

# Joint HC0 covariance of the two discontinuities, with fixed weights.
loading = weights * (design @ bread @ contrast)
influence = loading[:, None] * residuals
joint_covariance = influence.T @ influence

treatment_effect = reduced_form / first_stage
gradient = np.array([
    1.0 / first_stage,
    -reduced_form / first_stage**2,
])
treatment_se = np.sqrt(gradient @ joint_covariance @ gradient)

n_obs = int(len(data))
result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {
            "term": "treatment_effect",
            "estimate": float(treatment_effect),
            "se": float(treatment_se),
            "n_obs": n_obs,
        },
        {
            "term": "reduced_form",
            "estimate": float(reduced_form),
            "se": float(np.sqrt(joint_covariance[0, 0])),
            "n_obs": n_obs,
        },
        {
            "term": "first_stage",
            "estimate": float(first_stage),
            "se": float(np.sqrt(joint_covariance[1, 1])),
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "triangular-weighted local-linear fuzzy RD, bandwidth 1",
        "vcov": "joint HC0 sandwich; delta method for ratio",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
