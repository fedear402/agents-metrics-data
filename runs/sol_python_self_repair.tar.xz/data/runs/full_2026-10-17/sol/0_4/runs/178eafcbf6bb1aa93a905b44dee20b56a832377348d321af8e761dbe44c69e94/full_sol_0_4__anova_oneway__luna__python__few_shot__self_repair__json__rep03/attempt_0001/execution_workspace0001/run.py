import json

import pandas as pd
from scipy import stats

data = pd.read_csv("./input.csv")
data["y"] = pd.to_numeric(data["y"], errors="coerce")
data = data.dropna(subset=["group", "y"])

samples = [part["y"].to_numpy() for _, part in data.groupby("group")]
n_obs = len(data)
df_num = len(samples) - 1
df_den = n_obs - len(samples)

if df_num < 1 or df_den < 1:
    raise ValueError("ANOVA requires at least two groups and positive residual degrees of freedom.")

f_stat, p_value = stats.f_oneway(*samples)

result = {
    "task_id": "anova_oneway",
    "platform": "python",
    "estimates": [
        {"term": "F", "estimate": float(f_stat), "se": None, "n_obs": n_obs},
        {"term": "df_num", "estimate": float(df_num), "se": None, "n_obs": n_obs},
        {"term": "df_den", "estimate": float(df_den), "se": None, "n_obs": n_obs},
        {"term": "p_value", "estimate": float(p_value), "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "One-way ANOVA",
        "vcov": "classical pooled within-group variance",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output, allow_nan=False)
