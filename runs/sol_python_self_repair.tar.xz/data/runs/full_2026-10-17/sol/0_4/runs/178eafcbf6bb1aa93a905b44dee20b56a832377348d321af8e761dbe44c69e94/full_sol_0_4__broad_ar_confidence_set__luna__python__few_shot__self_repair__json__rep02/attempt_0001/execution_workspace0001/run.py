import json

import numpy as np
import pandas as pd
from scipy.stats import f

data = pd.read_csv("input.csv")
n = len(data)

y = data["y"].to_numpy(dtype=float)
d = data["endog"].to_numpy(dtype=float)
x = data["x"].to_numpy(dtype=float)
z1 = data["z1"].to_numpy(dtype=float)
z2 = data["z2"].to_numpy(dtype=float)

restricted = np.column_stack((np.ones(n), x))
unrestricted = np.column_stack((np.ones(n), x, z1, z2))
q = 2
df = n - 4
critical = f.ppf(0.95, q, df)
k = q * critical / df

def residual(values, design):
    coefficients = np.linalg.lstsq(design, values, rcond=None)[0]
    return values - design @ coefficients

ry = residual(y, restricted)
rd = residual(d, restricted)
uy = residual(y, unrestricted)
ud = residual(d, unrestricted)

a = float(rd @ rd - (1 + k) * (ud @ ud))
b = float(-2 * (ry @ rd - (1 + k) * (uy @ ud)))
c = float(ry @ ry - (1 + k) * (uy @ uy))

discriminant = b * b - 4 * a * c
if a == 0 or discriminant <= 0:
    raise ValueError("Expected two distinct finite Anderson-Rubin boundaries")

root = np.sqrt(discriminant)
boundaries = sorted(((-b - root) / (2 * a), (-b + root) / (2 * a)))

def ar_f(beta):
    restricted_residual = ry - beta * rd
    unrestricted_residual = uy - beta * ud
    ssr_r = restricted_residual @ restricted_residual
    ssr_u = unrestricted_residual @ unrestricted_residual
    return float(((ssr_r - ssr_u) / q) / (ssr_u / df))

def row(term, estimate):
    return {
        "term": term,
        "estimate": float(estimate),
        "se": None,
        "n_obs": n,
    }

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": [
        row("boundary_low", boundaries[0]),
        row("boundary_high", boundaries[1]),
        row("accepts_zero", int(c <= 0)),
        row("unbounded", int(a < 0)),
        row("ar_f_at_one", ar_f(1.0)),
    ],
    "method_metadata": {
        "estimator": "Anderson-Rubin confidence set by joint F-test inversion",
        "vcov": "conventional homoskedastic",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
