import csv
import json


TASK_ID = "applied_nonrecipient_population_iv"


def read_csv(path):
    with open(path, newline="", encoding="utf-8-sig") as file:
        return list(csv.DictReader(file))


def solve_linear_system(matrix, vector):
    """Solve a square linear system with partial pivoting."""
    n = len(vector)
    augmented = [list(matrix[i]) + [vector[i]] for i in range(n)]

    for col in range(n):
        pivot = max(range(col, n), key=lambda row: abs(augmented[row][col]))
        if abs(augmented[pivot][col]) < 1e-12:
            raise ValueError("The weighted IV system is singular.")
        augmented[col], augmented[pivot] = augmented[pivot], augmented[col]

        scale = augmented[col][col]
        for j in range(col, n + 1):
            augmented[col][j] /= scale

        for row in range(n):
            if row == col:
                continue
            factor = augmented[row][col]
            for j in range(col, n + 1):
                augmented[row][j] -= factor * augmented[col][j]

    return [augmented[i][n] for i in range(n)]


households = read_csv("households.csv")
census = read_csv("census.csv")
retained = [row for row in households if int(row["recipient"]) == 0]
n_obs = len(retained)

# The six instruments and six regressors form an exactly identified
# weighted 2SLS system. Solve Z' W X beta = Z' W y.
cross_product = [[0.0] * 6 for _ in range(6)]
outcome_product = [0.0] * 6
weight_sum = [0.0, 0.0]
weighted_dose_sum = [0.0, 0.0]

for row in retained:
    group = int(row["eligible"])
    if group not in (0, 1):
        raise ValueError("eligible must equal zero or one.")

    dose = float(row["dose"])
    baseline = float(row["baseline"])
    instrument = float(row["instrument"])
    weight = float(row["weight"])
    outcome = float(row["outcome"])
    if weight <= 0:
        raise ValueError("Household weights must be positive.")

    ineligible = 1 - group
    eligible = group
    exogenous = [
        float(ineligible),
        float(eligible),
        baseline * ineligible,
        baseline * eligible,
    ]
    x = exogenous + [dose * ineligible, dose * eligible]
    z = exogenous + [instrument * ineligible, instrument * eligible]

    for i in range(6):
        outcome_product[i] += weight * z[i] * outcome
        for j in range(6):
            cross_product[i][j] += weight * z[i] * x[j]

    weight_sum[group] += weight
    weighted_dose_sum[group] += weight * dose

if not all(weight_sum):
    raise ValueError("Both eligibility groups need retained households.")

coefficients = solve_linear_system(cross_product, outcome_product)
mean_dose = [
    weighted_dose_sum[group] / weight_sum[group] for group in (0, 1)
]
ineligible_effect = coefficients[4] * mean_dose[0]
eligible_nonrecipient_effect = coefficients[5] * mean_dose[1]

population = [0, 0]
for row in census:
    group = int(row["eligible"])
    if group not in (0, 1):
        raise ValueError("Census eligible must equal zero or one.")
    count = int(row["nonrecipient_population"])
    if count < 0:
        raise ValueError("Census population counts must be nonnegative.")
    population[group] += count

total_population = sum(population)
if total_population <= 0:
    raise ValueError("Total nonrecipient population must be positive.")

population_effect = (
    population[0] * ineligible_effect
    + population[1] * eligible_nonrecipient_effect
) / total_population

result = {
    "task_id": TASK_ID,
    "platform": "python",
    "estimates": [
        {
            "term": "ineligible_effect",
            "estimate": ineligible_effect,
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "eligible_nonrecipient_effect",
            "estimate": eligible_nonrecipient_effect,
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "population_effect",
            "estimate": population_effect,
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "weighted, exactly identified 2SLS",
        "sample": "all household rows with recipient=0",
        "regressors": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
            "dose*(1-eligible)",
            "dose*eligible",
        ],
        "instruments": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
            "instrument*(1-eligible)",
            "instrument*eligible",
        ],
        "weight": "weight",
        "counterfactual": (
            "Synthetic convention: dose is zero for every retained household."
        ),
        "group_effect": "fitted group dose slope times household-weighted group mean dose",
        "population_aggregation": (
            "Group effects averaged using census nonrecipient_population only"
        ),
    },
    "diagnostics": {
        "n_obs": n_obs,
        "household_weight_sums": {
            "ineligible": weight_sum[0],
            "eligible": weight_sum[1],
        },
        "weighted_mean_dose": {
            "ineligible": mean_dose[0],
            "eligible": mean_dose[1],
        },
        "dose_slopes": {
            "ineligible": coefficients[4],
            "eligible": coefficients[5],
        },
        "nonrecipient_population": {
            "ineligible": population[0],
            "eligible": population[1],
        },
    },
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file, indent=2, allow_nan=False)
