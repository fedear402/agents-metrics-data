import json

import numpy as np
import pandas as pd


def main():
    crosswalk = pd.read_csv("crosswalk.csv")
    trade = pd.read_csv("trade.csv")
    areas = pd.read_csv("areas.csv")
    employment = pd.read_csv("employment.csv")
    outcomes = pd.read_csv("outcomes.csv")

    trade = trade.merge(crosswalk, on="code", how="left", validate="many_to_one")

    keys = ["area", "period", "vintage"]
    industries = crosswalk["industry"].drop_duplicates()
    cells = areas[keys].merge(
        industries.to_frame(), how="cross"
    )
    cells = cells.merge(
        employment[keys + ["industry", "employment"]],
        on=keys + ["industry"],
        how="left",
        validate="one_to_one",
    )
    cells["employment"] = cells["employment"].fillna(0.0)

    national = (
        cells.groupby(["period", "vintage", "industry"], as_index=False)["employment"]
        .sum()
        .rename(columns={"employment": "national_employment"})
    )
    cells = cells.merge(
        national, on=["period", "vintage", "industry"], validate="many_to_one"
    )
    cells = cells.merge(
        areas[keys + ["total_employment"]],
        on=keys,
        validate="many_to_one",
    )
    cells = cells.merge(
        trade[
            ["period", "industry", "us_change", "other_change", "price_index", "years"]
        ],
        on=["period", "industry"],
        validate="many_to_one",
    )

    change = np.where(
        cells["vintage"].eq("base"),
        cells["us_change"],
        cells["other_change"],
    )
    cells["contribution"] = (
        cells["employment"].to_numpy()
        / cells["total_employment"].to_numpy()
        * change
        / cells["national_employment"].to_numpy()
        / (cells["price_index"].to_numpy() / 100)
        / 1000
        * (10 / cells["years"].to_numpy())
    )

    exposure = (
        cells.groupby(keys, as_index=False)["contribution"]
        .sum()
        .pivot(index=["area", "period"], columns="vintage", values="contribution")
        .rename(columns={"base": "x", "early": "z"})
        .reset_index()
    )
    base_areas = areas.loc[
        areas["vintage"].eq("base"), ["area", "period", "population"]
    ]
    sample = (
        exposure.merge(base_areas, on=["area", "period"], validate="one_to_one")
        .merge(outcomes, on=["area", "period"], validate="one_to_one")
        .sort_values(["period", "area"])
    )

    exogenous = np.column_stack(
        [
            np.ones(len(sample)),
            sample["period"].to_numpy(dtype=float),
            sample["control"].to_numpy(dtype=float),
        ]
    )
    X = np.column_stack([exogenous, sample["x"].to_numpy(dtype=float)])
    Z = np.column_stack([exogenous, sample["z"].to_numpy(dtype=float)])
    y = sample["change_pp"].to_numpy(dtype=float)
    weights = sample["population"].to_numpy(dtype=float)

    # Weighted 2SLS uses the projection onto all three exogenous columns and z.
    ztwz = Z.T @ (weights[:, None] * Z)
    ztwx = Z.T @ (weights[:, None] * X)
    ztwy = Z.T @ (weights * y)
    beta = np.linalg.solve(
        ztwx.T @ np.linalg.solve(ztwz, ztwx),
        ztwx.T @ np.linalg.solve(ztwz, ztwy),
    )

    def value(area, period, column):
        row = sample.loc[
            sample["area"].eq(area) & sample["period"].eq(period), column
        ]
        if len(row) != 1:
            raise ValueError(f"Expected one row for area={area}, period={period}")
        return float(row.iloc[0])

    n_obs = len(sample)
    if n_obs != 72:
        raise ValueError(f"Expected 72 estimation rows, found {n_obs}")

    estimates = [
        {"term": "iv_slope", "estimate": float(beta[-1]), "se": None, "n_obs": n_obs},
        {
            "term": "exposure_area0_period0",
            "estimate": value(0, 0, "x"),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "exposure_area0_period1",
            "estimate": value(0, 1, "x"),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "instrument_area0_period0",
            "estimate": value(0, 0, "z"),
            "se": None,
            "n_obs": n_obs,
        },
    ]

    result = {
        "task_id": "applied_multivintage_trade_iv",
        "platform": "python",
        "estimates": estimates,
        "method_metadata": {
            "estimator": "weighted 2SLS",
            "outcome": "change_pp",
            "endogenous": "x",
            "instrument": "z",
            "exogenous": ["intercept", "period", "control"],
            "weight": "base-vintage population",
            "exposure_units": "thousands of real dollars per worker per decade",
        },
        "diagnostics": {
            "n_obs": n_obs,
            "n_industries": int(len(industries)),
            "missing_employment_cells_filled_with_zero": True,
        },
    }

    with open("result.json", "w", encoding="utf-8") as file:
        json.dump(result, file, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
