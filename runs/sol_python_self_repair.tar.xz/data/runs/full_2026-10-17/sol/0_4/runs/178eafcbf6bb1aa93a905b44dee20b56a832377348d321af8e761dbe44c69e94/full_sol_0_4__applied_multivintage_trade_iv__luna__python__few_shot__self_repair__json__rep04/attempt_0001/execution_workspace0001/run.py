import json

import numpy as np
import pandas as pd

TASK_ID = "applied_multivintage_trade_iv"

crosswalk = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv")
areas = pd.read_csv("areas.csv")
employment = pd.read_csv("employment.csv")
outcomes = pd.read_csv("outcomes.csv")

trade = trade.merge(crosswalk, on="code", how="left", validate="many_to_one")
if trade["industry"].isna().any():
    raise ValueError("A trade code is missing from the crosswalk.")

# Include every area-industry cell so omitted employment cells contribute zero.
industries = crosswalk[["industry"]].drop_duplicates()
cells = areas.merge(industries, how="cross")
cells = cells.merge(
    employment,
    on=["area", "period", "vintage", "industry"],
    how="left",
    validate="one_to_one",
)
cells["employment"] = cells["employment"].fillna(0.0)
cells["national_employment"] = cells.groupby(
    ["period", "vintage", "industry"]
)["employment"].transform("sum")

cells = cells.merge(
    trade[
        [
            "period",
            "industry",
            "us_change",
            "other_change",
            "price_index",
            "years",
        ]
    ],
    on=["period", "industry"],
    how="left",
    validate="many_to_one",
)

base = cells.loc[cells["vintage"].eq("base")].copy()
early = cells.loc[cells["vintage"].eq("early")].copy()

base["contribution"] = (
    base["employment"]
    / base["total_employment"]
    * base["us_change"]
    / base["national_employment"]
    / (base["price_index"] / 100.0)
    / 1000.0
    * (10.0 / base["years"])
)
early["contribution"] = (
    early["employment"]
    / early["total_employment"]
    * early["other_change"]
    / early["national_employment"]
    / (early["price_index"] / 100.0)
    / 1000.0
    * (10.0 / early["years"])
)

x = base.groupby(["area", "period"], as_index=False)["contribution"].sum()
x = x.rename(columns={"contribution": "x"})
z = early.groupby(["area", "period"], as_index=False)["contribution"].sum()
z = z.rename(columns={"contribution": "z"})

sample = outcomes.merge(x, on=["area", "period"], validate="one_to_one")
sample = sample.merge(z, on=["area", "period"], validate="one_to_one")
weights = areas.loc[
    areas["vintage"].eq("base"), ["area", "period", "population"]
]
sample = sample.merge(weights, on=["area", "period"], validate="one_to_one")
sample = sample.sort_values(["period", "area"]).reset_index(drop=True)

if len(sample) != 72:
    raise ValueError(f"Expected 72 estimation rows; found {len(sample)}.")

exog = np.column_stack(
    (
        np.ones(len(sample)),
        sample["period"].to_numpy(dtype=float),
        sample["control"].to_numpy(dtype=float),
    )
)
regressors = np.column_stack((exog, sample["x"].to_numpy(dtype=float)))
instruments = np.column_stack((exog, sample["z"].to_numpy(dtype=float)))
outcome = sample["change_pp"].to_numpy(dtype=float)
sqrt_weight = np.sqrt(sample["population"].to_numpy(dtype=float))

weighted_regressors = regressors * sqrt_weight[:, None]
weighted_instruments = instruments * sqrt_weight[:, None]
weighted_outcome = outcome * sqrt_weight

# Weighted 2SLS: project each regressor onto all instrument columns.
first_stage = np.linalg.lstsq(
    weighted_instruments, weighted_regressors, rcond=None
)[0]
fitted_regressors = weighted_instruments @ first_stage
coefficients = np.linalg.lstsq(
    fitted_regressors.T @ weighted_regressors,
    fitted_regressors.T @ weighted_outcome,
    rcond=None,
)[0]


def value_for(area, period, column):
    rows = sample.loc[
        sample["area"].eq(area) & sample["period"].eq(period), column
    ]
    if len(rows) != 1:
        raise ValueError(f"Expected one row for area {area}, period {period}.")
    return float(rows.iloc[0])


terms = {
    "iv_slope": float(coefficients[-1]),
    "exposure_area0_period0": value_for(0, 0, "x"),
    "exposure_area0_period1": value_for(0, 1, "x"),
    "instrument_area0_period0": value_for(0, 0, "z"),
}

result = {
    "task_id": TASK_ID,
    "platform": "python",
    "estimates": [
        {"term": term, "estimate": estimate, "se": None, "n_obs": 72}
        for term, estimate in terms.items()
    ],
    "method_metadata": {
        "estimator": "weighted two-stage least squares",
        "outcome": "change_pp",
        "endogenous_regressor": "x",
        "excluded_instrument": "z",
        "exogenous_columns": ["intercept", "period", "control"],
        "weight": "base-vintage population",
        "exposure_unit": "thousands of real dollars per worker per decade",
    },
    "diagnostics": {
        "n_obs": 72,
        "n_industries": 4,
        "regressor_rank": int(np.linalg.matrix_rank(weighted_regressors)),
        "instrument_rank": int(np.linalg.matrix_rank(weighted_instruments)),
    },
}

with open("result.json", "w", encoding="utf-8") as output_file:
    json.dump(result, output_file, indent=2, allow_nan=False)
