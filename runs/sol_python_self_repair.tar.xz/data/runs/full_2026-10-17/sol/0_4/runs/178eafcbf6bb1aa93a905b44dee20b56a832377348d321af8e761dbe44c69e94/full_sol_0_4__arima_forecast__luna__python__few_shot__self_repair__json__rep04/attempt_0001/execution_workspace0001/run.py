import json
import math

import pandas as pd
from statsmodels.tsa.arima.model import ARIMA

data = pd.read_csv("./input.csv").sort_values("t")
y = pd.to_numeric(data["y"], errors="raise")

fit = ARIMA(y, order=(1, 1, 1), trend="n").fit()
prediction = fit.get_forecast(steps=1)
forecast = float(prediction.predicted_mean.iloc[0])
forecast_se = float(prediction.se_mean.iloc[0])
bounds = prediction.conf_int(alpha=0.05).iloc[0]
lower_95 = float(bounds.iloc[0])
upper_95 = float(bounds.iloc[1])

values = (forecast, forecast_se, lower_95, upper_95)
if not all(math.isfinite(value) for value in values):
    raise ValueError("Forecast or prediction interval contains a nonfinite value.")

result = {
    "task_id": "arima_forecast",
    "platform": "python",
    "estimates": [
        {
            "term": "forecast",
            "estimate": forecast,
            "se": forecast_se,
            "n_obs": int(fit.nobs),
        },
        {
            "term": "lower_95",
            "estimate": lower_95,
            "se": None,
            "n_obs": int(fit.nobs),
        },
        {
            "term": "upper_95",
            "estimate": upper_95,
            "se": None,
            "n_obs": int(fit.nobs),
        },
    ],
    "method_metadata": {
        "estimator": "ARIMA(1,1,1) maximum likelihood, no constant or drift",
        "vcov": "model-based forecast variance",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output)
