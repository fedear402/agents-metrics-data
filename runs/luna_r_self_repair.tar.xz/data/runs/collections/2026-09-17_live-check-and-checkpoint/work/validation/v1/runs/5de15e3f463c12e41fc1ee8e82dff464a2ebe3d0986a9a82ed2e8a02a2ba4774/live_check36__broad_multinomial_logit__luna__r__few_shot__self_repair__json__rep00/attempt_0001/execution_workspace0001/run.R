d <- read.csv("input.csv")

d$y <- factor(d$y, levels = c(0, 1, 2))

fit <- nnet::multinom(
  y ~ x + z,
  data = d,
  Hess = TRUE,
  trace = FALSE,
  maxit = 1000,
  reltol = 1e-12,
  abstol = 1e-12
)

B <- coef(fit)
V <- vcov(fit)
n <- nrow(d)

se_for <- function(outcome, term) {
  nm <- paste0(outcome, ":", term)
  sqrt(V[nm, nm])
}

indices_zero <- c(
  0,
  unname(B["1", "(Intercept)"]),
  unname(B["2", "(Intercept)"])
)

indices_zero <- indices_zero - max(indices_zero)
prob_zero <- exp(indices_zero) / sum(exp(indices_zero))

result <- list(
  task_id = "broad_multinomial_logit",
  platform = "r",
  estimates = list(
    list(
      term = "x_cat1",
      estimate = unname(B["1", "x"]),
      se = se_for("1", "x"),
      n_obs = n
    ),
    list(
      term = "z_cat1",
      estimate = unname(B["1", "z"]),
      se = se_for("1", "z"),
      n_obs = n
    ),
    list(
      term = "x_cat2",
      estimate = unname(B["2", "x"]),
      se = se_for("2", "x"),
      n_obs = n
    ),
    list(
      term = "z_cat2",
      estimate = unname(B["2", "z"]),
      se = se_for("2", "z"),
      n_obs = n
    ),
    list(
      term = "prob_cat2_zero",
      estimate = unname(prob_zero[3]),
      se = NULL,
      n_obs = n
    )
  ),
  method_metadata = list(
    estimator = "Multinomial logit maximum likelihood",
    vcov = "Conventional observed-information covariance matrix"
  ),
  diagnostics = list()
)

jsonlite::write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
