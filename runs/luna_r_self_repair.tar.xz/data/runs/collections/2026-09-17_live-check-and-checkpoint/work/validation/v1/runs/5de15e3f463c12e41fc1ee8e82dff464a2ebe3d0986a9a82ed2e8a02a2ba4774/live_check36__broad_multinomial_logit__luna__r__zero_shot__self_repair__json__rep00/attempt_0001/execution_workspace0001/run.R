dat <- read.csv("input.csv", stringsAsFactors = FALSE)

y <- as.integer(dat$y)
x <- as.numeric(dat$x)
z <- as.numeric(dat$z)
n <- nrow(dat)

if (any(!y %in% c(0L, 1L, 2L))) {
  stop("y must contain only outcomes 0, 1, and 2")
}

X <- cbind("(Intercept)" = 1, x = x, z = z)

loglik <- function(beta) {
  eta1 <- drop(X %*% beta[1:3])
  eta2 <- drop(X %*% beta[4:6])
  m <- pmax(0, eta1, eta2)
  lse <- m + log(exp(-m) + exp(eta1 - m) + exp(eta2 - m))
  ll <- ifelse(y == 0L, -lse,
               ifelse(y == 1L, eta1 - lse, eta2 - lse))
  -sum(ll)
}

gradient <- function(beta) {
  eta1 <- drop(X %*% beta[1:3])
  eta2 <- drop(X %*% beta[4:6])
  m <- pmax(0, eta1, eta2)
  den <- exp(-m) + exp(eta1 - m) + exp(eta2 - m)
  p1 <- exp(eta1 - m) / den
  p2 <- exp(eta2 - m) / den

  s1 <- as.numeric(y == 1L) - p1
  s2 <- as.numeric(y == 2L) - p2

  -c(crossprod(X, s1), crossprod(X, s2))
}

fit <- optim(
  par = rep(0, 6),
  fn = loglik,
  gr = gradient,
  method = "BFGS",
  hessian = TRUE,
  control = list(reltol = 1e-12, maxit = 10000)
)

if (fit$convergence != 0) {
  stop("Maximum-likelihood optimization did not converge")
}

vcov_obs <- tryCatch(solve(fit$hessian), error = function(e) NULL)
if (is.null(vcov_obs) || any(!is.finite(vcov_obs))) {
  stop("Observed-information matrix is singular")
}

se <- sqrt(pmax(diag(vcov_obs), 0))
beta <- fit$par

eta1_zero <- beta[1]
eta2_zero <- beta[4]
m_zero <- max(0, eta1_zero, eta2_zero)
den_zero <- exp(-m_zero) + exp(eta1_zero - m_zero) + exp(eta2_zero - m_zero)
prob_cat2_zero <- exp(eta2_zero - m_zero) / den_zero

result <- list(
  task_id = "broad_multinomial_logit",
  platform = "r",
  estimates = list(
    list(term = "x_cat1", estimate = unname(beta[2]), se = unname(se[2]), n_obs = n),
    list(term = "z_cat1", estimate = unname(beta[3]), se = unname(se[3]), n_obs = n),
    list(term = "x_cat2", estimate = unname(beta[5]), se = unname(se[5]), n_obs = n),
    list(term = "z_cat2", estimate = unname(beta[6]), se = unname(se[6]), n_obs = n),
    list(term = "prob_cat2_zero", estimate = unname(prob_cat2_zero), se = NULL, n_obs = n)
  ),
  method_metadata = list(
    estimator = "Multinomial logit maximum likelihood",
    vcov = "Conventional observed-information covariance matrix"
  ),
  diagnostics = list()
)

if (!requireNamespace("jsonlite", quietly = TRUE)) {
  stop("Package jsonlite is required")
}

jsonlite::write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 17
)
