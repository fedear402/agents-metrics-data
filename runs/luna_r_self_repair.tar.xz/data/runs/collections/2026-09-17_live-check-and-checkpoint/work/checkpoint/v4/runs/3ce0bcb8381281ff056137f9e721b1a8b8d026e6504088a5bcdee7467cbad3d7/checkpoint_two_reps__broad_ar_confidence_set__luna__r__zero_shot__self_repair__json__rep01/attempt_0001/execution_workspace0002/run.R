#!/usr/bin/env Rscript

dat <- read.csv("input.csv")

y <- dat$y
d <- dat$endog
x <- dat$x
z <- as.matrix(dat[, c("z1", "z2")])

n <- nrow(dat)
q <- 2
df_den <- n - 4
crit <- qf(0.95, q, df_den)

base <- cbind(1, x)
qr_base <- qr(base)

resid_base <- function(v) {
  v - qr.fitted(qr_base, v)
}

yr <- resid_base(y)
dr <- resid_base(d)
zr <- apply(z, 2, resid_base)

S <- crossprod(zr)
S_inv <- solve(S)

a <- crossprod(zr, yr)
b <- crossprod(zr, dr)

num0 <- as.numeric(crossprod(a, S_inv %*% a))
num1 <- as.numeric(-2 * crossprod(a, S_inv %*% b))
num2 <- as.numeric(crossprod(b, S_inv %*% b))

coef_y <- S_inv %*% a
coef_d <- S_inv %*% b

ey <- as.numeric(yr - zr %*% coef_y)
ed <- as.numeric(dr - zr %*% coef_d)

rss0 <- sum(ey^2)
rss1 <- -2 * sum(ey * ed)
rss2 <- sum(ed^2)

g0 <- df_den * num0 - crit * q * rss0
g1 <- df_den * num1 - crit * q * rss1
g2 <- df_den * num2 - crit * q * rss2

roots <- polyroot(c(g0, g1, g2))
roots <- Re(roots[abs(Im(roots)) < 1e-8])
roots <- sort(roots)

if (length(roots) >= 2) {
  boundary_low <- roots[1]
  boundary_high <- roots[length(roots)]
} else {
  boundary_low <- NA_real_
  boundary_high <- NA_real_
}

ar_f <- function(beta) {
  w <- y - beta * d
  fit_u <- lm.fit(cbind(1, x, z1 = z[, 1], z2 = z[, 2]), w)
  fit_r <- lm.fit(cbind(1, x), w)
  num <- fit_r$qr$rank
  rss_r <- sum(fit_r$residuals^2)
  rss_u <- sum(fit_u$residuals^2)
  ((rss_r - rss_u) / q) / (rss_u / df_den)
}

accepts_zero <- as.numeric(g0 <= 0)

g_inf <- function(beta) g2 * beta^2 + g1 * beta + g0
unbounded <- as.numeric(g_inf(1e12) <= 0 || g_inf(-1e12) <= 0)

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = list(
    list(term = "boundary_low", estimate = as.numeric(boundary_low),
         se = NULL, n_obs = n),
    list(term = "boundary_high", estimate = as.numeric(boundary_high),
         se = NULL, n_obs = n),
    list(term = "accepts_zero", estimate = accepts_zero,
         se = NULL, n_obs = n),
    list(term = "unbounded", estimate = unbounded,
         se = NULL, n_obs = n),
    list(term = "ar_f_at_one", estimate = ar_f(1),
         se = NULL, n_obs = n)
  ),
  method_metadata = list(
    estimator = "Anderson-Rubin confidence-set inversion with conventional homoskedastic joint F test",
    vcov = "Conventional homoskedastic"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, na = "null")
