dat <- read.csv("input.csv")
dat <- dat[order(dat$time), ]

y <- dat$y
forecast_dates <- 101:250
forecasts <- numeric(length(forecast_dates))

for (i in seq_along(forecast_dates)) {
  f <- forecast_dates[i]
  response <- y[(f - 99):(f - 1)]
  lagged <- y[(f - 100):(f - 2)]
  fit <- lm(response ~ lagged)
  forecasts[i] <- predict(
    fit,
    newdata = data.frame(lagged = y[f - 1])
  )
}

actuals <- y[forecast_dates]
rmse <- sqrt(mean((actuals - forecasts)^2))

result <- list(
  task_id = "hard_rolling",
  platform = "r",
  estimates = list(
    list(term = "rmse", estimate = unname(rmse), se = NULL, n_obs = 150L),
    list(term = "forecast_101", estimate = unname(forecasts[which(forecast_dates == 101)]), se = NULL, n_obs = 99L),
    list(term = "forecast_150", estimate = unname(forecasts[which(forecast_dates == 150)]), se = NULL, n_obs = 99L),
    list(term = "forecast_200", estimate = unname(forecasts[which(forecast_dates == 200)]), se = NULL, n_obs = 99L),
    list(term = "forecast_250", estimate = unname(forecasts[which(forecast_dates == 250)]), se = NULL, n_obs = 99L)
  ),
  method_metadata = list(
    estimator = "Rolling OLS AR(1) with intercept",
    vcov = "Not applicable"
  ),
  diagnostics = list()
)

jsonlite::write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 17
)
