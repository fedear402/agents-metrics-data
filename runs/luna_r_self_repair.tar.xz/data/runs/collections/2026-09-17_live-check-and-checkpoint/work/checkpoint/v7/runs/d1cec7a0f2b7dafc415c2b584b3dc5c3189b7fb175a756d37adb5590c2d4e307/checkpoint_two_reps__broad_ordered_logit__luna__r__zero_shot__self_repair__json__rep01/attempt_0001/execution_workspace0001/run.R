library(MASS)

dat <- read.csv("input.csv")

fit <- polr(
  factor(y, levels = c(1, 2, 3), ordered = TRUE) ~ x + z,
  data = dat,
  method = "logistic",
  Hess = TRUE,
  model = TRUE
)

vcov_obs <- solve(fit$Hessian)
coef_names <- names(coef(fit))
beta <- coef(fit)

prob_high <- plogis(
  beta["x"] * 1 + beta["z"] * 0 - fit$zeta[2]
)

out <- list(
  task_id = "broad_ordered_logit",
  platform = "r",
  estimates = list(
    list(
      term = "x",
      estimate = unname(beta["x"]),
      se = sqrt(vcov_obs["x", "x"]),
      n_obs = nrow(dat)
    ),
    list(
      term = "z",
      estimate = unname(beta["z"]),
      se = sqrt(vcov_obs["z", "z"]),
      n_obs = nrow(dat)
    ),
    list(
      term = "prob_high",
      estimate = unname(prob_high),
      se = NULL,
      n_obs = nrow(dat)
    )
  ),
  method_metadata = list(
    estimator = "ordered logit maximum likelihood",
    vcov = "conventional observed information"
  ),
  diagnostics = list()
)

json_escape <- function(x) {
  gsub('"', '\\"', as.character(x), fixed = TRUE)
}

num <- function(x) {
  if (is.null(x)) "null" else formatC(x, format = "fg", digits = 17)
}

json <- paste0(
  "{",
  '"task_id":"', json_escape(out$task_id), '",',
  '"platform":"', json_escape(out$platform), '",',
  '"estimates":[',
  '{"term":"x","estimate":', num(out$estimates[[1]]$estimate),
  ',"se":', num(out$estimates[[1]]$se),
  ',"n_obs":', out$estimates[[1]]$n_obs, "},",
  '{"term":"z","estimate":', num(out$estimates[[2]]$estimate),
  ',"se":', num(out$estimates[[2]]$se),
  ',"n_obs":', out$estimates[[2]]$n_obs, "},",
  '{"term":"prob_high","estimate":', num(out$estimates[[3]]$estimate),
  ',"se":null,"n_obs":', out$estimates[[3]]$n_obs, "}",
  "],",
  '"method_metadata":{"estimator":"ordered logit maximum likelihood",',
  '"vcov":"conventional observed information"},',
  '"diagnostics":{}',
  "}"
)

writeLines(json, "result.json")
