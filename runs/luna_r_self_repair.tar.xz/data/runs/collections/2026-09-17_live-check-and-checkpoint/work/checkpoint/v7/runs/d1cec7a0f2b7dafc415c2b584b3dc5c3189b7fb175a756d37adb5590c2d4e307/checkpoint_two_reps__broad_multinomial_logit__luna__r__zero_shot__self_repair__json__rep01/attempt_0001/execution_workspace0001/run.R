dat <- read.csv("input.csv")

y <- as.integer(dat$y)
x <- as.numeric(dat$x)
z <- as.numeric(dat$z)
n <- nrow(dat)

X <- cbind(1, x, z)
K <- ncol(X)

loglik <- function(beta) {
  B <- matrix(beta, nrow = K, ncol = 2)
  eta1 <- X %*% B[, 1]
  eta2 <- X %*% B[, 2]
  den <- 1 + exp(eta1) + exp(eta2)
  p0 <- 1 / den
  p1 <- exp(eta1) / den
  p2 <- exp(eta2) / den
  
  sum(
    (y == 0) * log(p0) +
      (y == 1) * log(p1) +
      (y == 2) * log(p2)
  )
}

gradient <- function(beta) {
  B <- matrix(beta, nrow = K, ncol = 2)
  eta1 <- as.vector(X %*% B[, 1])
  eta2 <- as.vector(X %*% B[, 2])
  den <- 1 + exp(eta1) + exp(eta2)
  p1 <- exp(eta1) / den
  p2 <- exp(eta2) / den
  
  score <- cbind((y == 1) - p1, (y == 2) - p2)
  as.vector(crossprod(X, score))
}

fit <- optim(
  par = rep(0, 2 * K),
  fn = function(beta) -loglik(beta),
  gr = function(beta) -gradient(beta),
  method = "BFGS",
  hessian = FALSE,
  control = list(reltol = 1e-12, maxit = 10000)
)

beta_hat <- fit$par

B_hat <- matrix(beta_hat, nrow = K, ncol = 2)
eta1 <- as.vector(X %*% B_hat[, 1])
eta2 <- as.vector(X %*% B_hat[, 2])
den <- 1 + exp(eta1) + exp(eta2)
p1 <- exp(eta1) / den
p2 <- exp(eta2) / den

H <- matrix(0, nrow = 2 * K, ncol = 2 * K)

for (i in seq_len(n)) {
  xi <- matrix(X[i, ], nrow = 1)
  pi <- c(p1[i], p2[i])
  Omega <- diag(pi) - tcrossprod(pi)
  Zi <- kronecker(diag(2), xi)
  H <- H - crossprod(Zi, Omega %*% Zi)
}

vcov_hat <- solve(-H)
se_hat <- sqrt(pmax(diag(vcov_hat), 0))

prob_cat2_zero <- 1 / (1 + exp(-B_hat[1, 2]) + exp(-B_hat[1, 1]))

estimates <- list(
  list(term = "x_cat1", estimate = unname(B_hat[2, 1]), se = unname(se_hat[2]), n_obs = n),
  list(term = "z_cat1", estimate = unname(B_hat[3, 1]), se = unname(se_hat[3]), n_obs = n),
  list(term = "x_cat2", estimate = unname(B_hat[2, 2]), se = unname(se_hat[5]), n_obs = n),
  list(term = "z_cat2", estimate = unname(B_hat[3, 2]), se = unname(se_hat[6]), n_obs = n),
  list(term = "prob_cat2_zero", estimate = unname(prob_cat2_zero), se = NULL, n_obs = n)
)

result <- list(
  task_id = "broad_multinomial_logit",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "Multinomial logit maximum likelihood",
    vcov = "Conventional observed-information standard errors"
  ),
  diagnostics = list()
)

if (requireNamespace("jsonlite", quietly = TRUE)) {
  jsonlite::write_json(result, "result.json", auto_unbox = TRUE, pretty = TRUE, null = "null")
} else {
  stop("The jsonlite package is required.")
}
