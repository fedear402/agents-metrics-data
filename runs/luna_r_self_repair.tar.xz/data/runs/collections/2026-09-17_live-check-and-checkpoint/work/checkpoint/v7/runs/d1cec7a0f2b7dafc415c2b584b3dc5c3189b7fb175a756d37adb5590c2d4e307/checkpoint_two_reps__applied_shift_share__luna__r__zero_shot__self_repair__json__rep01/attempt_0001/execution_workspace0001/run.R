d <- read.csv("input.csv", stringsAsFactors = FALSE)

region_ids <- unique(d$region_id)
industry_ids <- unique(d$industry_id)

region_data <- d[match(region_ids, d$region_id), ]
e <- region_data$region_weight / sum(region_data$region_weight)
names(e) <- as.character(region_data$region_id)

d$e <- e[as.character(d$region_id)]
d$z <- ave(d$share * d$shock, d$region_id, FUN = sum)

wm <- function(v, w) sum(w * v) / sum(w)

region_vals <- d[match(region_ids, d$region_id), ]
region_vals$e <- e

y_mean <- wm(region_vals$y, region_vals$e)
x_mean <- wm(region_vals$x, region_vals$e)
z_mean <- wm(region_vals$z, region_vals$e)

region_vals$y0 <- region_vals$y - y_mean
region_vals$x0 <- region_vals$x - x_mean
region_vals$z0 <- region_vals$z - z_mean

industry_data <- data.frame(
  industry_id = industry_ids,
  shock = sapply(industry_ids, function(i) {
    unique(d$shock[d$industry_id == i])[1]
  }),
  s = sapply(industry_ids, function(i) {
    sum(region_vals$e[region_vals$region_id %in%
                         d$region_id[d$industry_id == i]] *
          d$share[d$industry_id == i])
  }),
  ybar = NA_real_,
  xbar = NA_real_,
  zbar = NA_real_
)

for (j in seq_len(nrow(industry_data))) {
  ind <- industry_data$industry_id[j]
  rows <- d$industry_id == ind
  reg_match <- match(d$region_id[rows], region_vals$region_id)
  w <- region_vals$e[reg_match] * d$share[rows]
  industry_data$ybar[j] <- sum(w * region_vals$y0[reg_match]) / industry_data$s[j]
  industry_data$xbar[j] <- sum(w * region_vals$x0[reg_match]) / industry_data$s[j]
  industry_data$zbar[j] <- sum(w * region_vals$z0[reg_match]) / industry_data$s[j]
}

industry_data <- industry_data[is.finite(industry_data$s) & industry_data$s > 0, ]
N <- nrow(industry_data)

iv_fit <- function(y, x, q, w) {
  X <- cbind(1, x)
  Z <- cbind(1, q)
  W <- diag(w, nrow = length(w))
  
  ZWZ <- crossprod(Z, W %*% Z)
  D <- crossprod(X, W %*% Z) %*% solve(ZWZ)
  A <- D %*% crossprod(Z, W %*% X)
  b <- solve(A, D %*% crossprod(Z, W %*% y))
  
  u <- as.numeric(y - X %*% b)
  Zu <- Z * (w * u)
  meat <- crossprod(Zu)
  middle <- D %*% meat %*% t(D)
  bread <- solve(A)
  vcov <- bread %*% middle %*% t(bread)
  
  vcov <- vcov * N / (N - 2)
  
  list(estimate = as.numeric(b[2]), se = sqrt(vcov[2, 2]))
}

effect_fit <- iv_fit(
  y = industry_data$ybar,
  x = industry_data$xbar,
  q = industry_data$shock,
  w = industry_data$s
)

first_stage_fit <- iv_fit(
  y = industry_data$xbar,
  x = industry_data$zbar,
  q = industry_data$shock,
  w = industry_data$s
)

effective_shocks <- 1 / sum(industry_data$s^2)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(
      term = "effect",
      estimate = effect_fit$estimate,
      se = effect_fit$se,
      n_obs = N
    ),
    list(
      term = "first_stage",
      estimate = first_stage_fit$estimate,
      se = first_stage_fit$se,
      n_obs = N
    ),
    list(
      term = "effective_shocks",
      estimate = effective_shocks,
      se = NULL,
      n_obs = N
    )
  ),
  method_metadata = list(
    estimator = "Borusyak-Hull-Jaravel shock-level weighted 2SLS",
    vcov = "shock-level heteroskedasticity-robust HC1, multiplier N/(N-2)"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, null = "null")
