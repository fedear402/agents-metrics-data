dat <- read.csv("input.csv", stringsAsFactors = FALSE)

y <- dat$y
x <- dat$x
z <- dat$z
n <- nrow(dat)

X <- cbind(const = 1, x = x, z = z)

pos <- y > 0
if (sum(pos) >= 3) {
  fit0 <- lm(y[pos] ~ x[pos] + z[pos])
  beta0 <- coef(fit0)
  beta0 <- c(beta0[1], beta0[2], beta0[3])
  sigma0 <- sd(residuals(fit0))
} else {
  beta0 <- c(mean(y), 0, 0)
  sigma0 <- sd(y)
}

if (!is.finite(sigma0) || sigma0 <= 0) {
  sigma0 <- max(sd(y), 1)
}

theta0 <- c(beta0, log(sigma0))

negloglik <- function(theta) {
  beta <- theta[1:3]
  sigma <- exp(theta[4])
  mu <- drop(X %*% beta)
  
  ll <- numeric(n)
  ll[!pos] <- pnorm(-mu[!pos] / sigma, log.p = TRUE)
  ll[pos] <- dnorm((y[pos] - mu[pos]) / sigma, log = TRUE) - log(sigma)
  
  if (any(!is.finite(ll))) return(1e100)
  -sum(ll)
}

fit <- optim(
  par = theta0,
  fn = negloglik,
  method = "BFGS",
  hessian = TRUE,
  control = list(maxit = 10000, reltol = 1e-12)
)

if (fit$convergence != 0 || !is.finite(fit$value)) {
  fit <- optim(
    par = theta0,
    fn = negloglik,
    method = "Nelder-Mead",
    control = list(maxit = 20000, reltol = 1e-12)
  )
  fit <- optim(
    par = fit$par,
    fn = negloglik,
    method = "BFGS",
    hessian = TRUE,
    control = list(maxit = 10000, reltol = 1e-12)
  )
}

theta_hat <- fit$par
beta_hat <- theta_hat[1:3]
sigma_hat <- exp(theta_hat[4])

H <- fit$hessian
V_theta <- tryCatch(solve(H), error = function(e) matrix(NA_real_, 4, 4))
se_beta <- sqrt(pmax(diag(V_theta)[1:3], 0))

fmt <- function(v) {
  if (is.null(v) || length(v) == 0 || !is.finite(v)) "null" else sprintf("%.15g", v)
}

result <- sprintf(
  paste0(
    '{\n',
    '  "task_id": "broad_tobit",\n',
    '  "platform": "r",\n',
    '  "estimates": [\n',
    '    {"term": "const", "estimate": %s, "se": %s, "n_obs": %d},\n',
    '    {"term": "x", "estimate": %s, "se": %s, "n_obs": %d},\n',
    '    {"term": "z", "estimate": %s, "se": %s, "n_obs": %d},\n',
    '    {"term": "sigma", "estimate": %s, "se": null, "n_obs": %d}\n',
    '  ],\n',
    '  "method_metadata": {"estimator": "Gaussian Tobit maximum likelihood", "vcov": "inverse observed information"},\n',
    '  "diagnostics": {}\n',
    '}\n'
  ),
  fmt(beta_hat[1]), fmt(se_beta[1]), n,
  fmt(beta_hat[2]), fmt(se_beta[2]), n,
  fmt(beta_hat[3]), fmt(se_beta[3]), n,
  fmt(sigma_hat), n
)

writeLines(result, "result.json")
