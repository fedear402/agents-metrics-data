library(jsonlite)

data <- read.csv("input.csv", stringsAsFactors = FALSE)
data$date <- as.Date(data$date)
data <- data[order(data$date), ]

data$log_vix <- log(data$vix)
data$vol_change <- c(NA_real_, diff(data$log_vix))
data$log_sales <- log(data$sales)

for (j in 1:15) {
  data[[paste0("lag_", j)]] <- c(
    rep(NA_real_, j + 1),
    head(data$vol_change, -j - 1)
  )
}

lag_names <- paste0("lag_", 1:15)
sample <- data[complete.cases(data[, c("log_sales", lag_names)]), ]

formula <- as.formula(
  paste("log_sales ~", paste(lag_names, collapse = " + "))
)
fit <- lm(formula, data = sample)

X <- model.matrix(fit)
residuals_fit <- residuals(fit)
N <- nrow(X)
p <- ncol(X)
hac_lags <- 15

scores <- X * residuals_fit
meat <- crossprod(scores)

for (j in 1:hac_lags) {
  lag_product <- crossprod(
    scores[(j + 1):N, , drop = FALSE],
    scores[1:(N - j), , drop = FALSE]
  )
  weight <- 1 - j / 16
  meat <- meat + weight * (lag_product + t(lag_product))
}

bread <- solve(crossprod(X))
covariance <- N / (N - 16) * bread %*% meat %*% bread

coefficients <- coef(fit)
coefficient_names <- names(coefficients)

contrast <- numeric(length(coefficients))
contrast[match(lag_names, coefficient_names)] <- 1

cumulative_response <- sum(contrast * coefficients)
cumulative_se <- sqrt(drop(t(contrast) %*% covariance %*% contrast))

lag_1_index <- match("lag_1", coefficient_names)
lag_15_index <- match("lag_15", coefficient_names)

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(
      term = "cumulative_response",
      estimate = unname(as.numeric(cumulative_response)),
      se = unname(as.numeric(cumulative_se)),
      n_obs = as.integer(N)
    ),
    list(
      term = "lag_1",
      estimate = unname(as.numeric(coefficients[lag_1_index])),
      se = unname(as.numeric(sqrt(covariance[lag_1_index, lag_1_index]))),
      n_obs = as.integer(N)
    ),
    list(
      term = "lag_15",
      estimate = unname(as.numeric(coefficients[lag_15_index])),
      se = unname(as.numeric(sqrt(covariance[lag_15_index, lag_15_index]))),
      n_obs = as.integer(N)
    )
  ),
  method_metadata = list(
    estimator = "OLS with intercept and 15 trading-observation lags of log volatility changes",
    vcov = "Bartlett Newey-West HAC, maximum lag 15, scaled by N/(N-16)"
  ),
  diagnostics = list()
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  digits = 16,
  pretty = TRUE,
  null = "null"
)
