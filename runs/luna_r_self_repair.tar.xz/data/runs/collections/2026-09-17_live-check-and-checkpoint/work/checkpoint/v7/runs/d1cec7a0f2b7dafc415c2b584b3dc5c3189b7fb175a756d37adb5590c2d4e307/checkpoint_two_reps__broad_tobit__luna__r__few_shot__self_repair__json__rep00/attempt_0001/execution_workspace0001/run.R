d <- read.csv("input.csv")

y <- as.numeric(d$y)
X <- cbind(const = 1, x = as.numeric(d$x), z = as.numeric(d$z))
n <- nrow(d)

uncensored <- y > 0
y_pos <- y[uncensored]
X_pos <- X[uncensored, , drop = FALSE]

if (sum(uncensored) >= 3) {
  beta0 <- tryCatch(
    as.numeric(coef(lm(y_pos ~ X_pos[, "x"] + X_pos[, "z"]))),
    error = function(e) c(0, 0, 0)
  )
  beta0 <- c(beta0[1], beta0[2], beta0[3])
  resid0 <- y_pos - as.vector(X_pos %*% beta0)
  sigma0 <- sd(resid0)
} else {
  beta0 <- c(mean(y_pos, na.rm = TRUE), 0, 0)
  sigma0 <- sd(y_pos, na.rm = TRUE)
}

if (!is.finite(sigma0) || sigma0 <= 0) {
  sigma0 <- max(sd(y, na.rm = TRUE), 1)
}

loglik <- function(par) {
  beta <- par[1:3]
  sigma <- exp(par[4])
  mu <- as.vector(X %*% beta)

  ll <- numeric(n)

  if (any(uncensored)) {
    r <- (y[uncensored] - mu[uncensored]) / sigma
    ll[uncensored] <- dnorm(r, log = TRUE) - log(sigma)
  }

  if (any(!uncensored)) {
    a <- -mu[!uncensored] / sigma
    ll[!uncensored] <- pnorm(a, log.p = TRUE)
  }

  -sum(ll)
}

gradient <- function(par) {
  beta <- par[1:3]
  sigma <- exp(par[4])
  mu <- as.vector(X %*% beta)

  score_mu <- numeric(n)
  score_log_sigma <- numeric(n)

  if (any(uncensored)) {
    r <- (y[uncensored] - mu[uncensored]) / sigma
    score_mu[uncensored] <- r / sigma
    score_log_sigma[uncensored] <- -1 + r^2
  }

  if (any(!uncensored)) {
    a <- -mu[!uncensored] / sigma
    log_lambda <- dnorm(a, log = TRUE) - pnorm(a, log.p = TRUE)
    lambda <- exp(log_lambda)
    score_mu[!uncensored] <- -lambda / sigma
    score_log_sigma[!uncensored] <- -a * lambda
  }

  c(as.vector(crossprod(X, score_mu)), sum(score_log_sigma))
}

fit <- optim(
  par = c(beta0, log(sigma0)),
  fn = loglik,
  gr = gradient,
  method = "BFGS",
  hessian = TRUE,
  control = list(reltol = 1e-12, maxit = 10000)
)

if (fit$convergence != 0) {
  fit <- optim(
    par = fit$par,
    fn = loglik,
    gr = gradient,
    method = "Nelder-Mead",
    hessian = TRUE,
    control = list(reltol = 1e-12, maxit = 10000)
  )
}

V <- solve(fit$hessian)
se_beta <- sqrt(pmax(diag(V)[1:3], 0))

estimates <- list(
  list(term = "const", estimate = unname(fit$par[1]), se = unname(se_beta[1]), n_obs = as.integer(n)),
  list(term = "x", estimate = unname(fit$par[2]), se = unname(se_beta[2]), n_obs = as.integer(n)),
  list(term = "z", estimate = unname(fit$par[3]), se = unname(se_beta[3]), n_obs = as.integer(n)),
  list(term = "sigma", estimate = unname(exp(fit$par[4])), se = NULL, n_obs = as.integer(n))
)

result <- list(
  task_id = "broad_tobit",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "Maximum likelihood Gaussian Tobit with left censoring at zero",
    vcov = "Inverse observed information from the jointly estimated likelihood"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = 16, pretty = TRUE, null = "null")
