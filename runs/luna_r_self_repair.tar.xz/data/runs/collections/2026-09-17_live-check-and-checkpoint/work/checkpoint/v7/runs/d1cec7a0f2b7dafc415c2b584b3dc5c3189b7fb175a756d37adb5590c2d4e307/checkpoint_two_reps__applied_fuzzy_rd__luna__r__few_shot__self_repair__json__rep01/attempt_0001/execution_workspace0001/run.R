library(jsonlite)

dat <- read.csv("input.csv")

keep <- abs(dat$score) < 1
dat <- dat[keep, , drop = FALSE]

score <- dat$score
right <- as.numeric(score >= 0)
weights <- 1 - abs(score)

X <- cbind(
  1,
  score,
  right,
  right * score
)

Y <- cbind(
  earnings = dat$earnings,
  participated = dat$participated
)

bread <- solve(crossprod(X, weights * X))
beta <- bread %*% crossprod(X, weights * Y)

contrast <- c(0, 0, 1, 0)
jumps <- drop(t(contrast) %*% beta)

residuals <- Y - X %*% beta
loading <- weights * drop(X %*% bread %*% contrast)
influence <- loading * residuals

joint_covariance <- crossprod(influence)
se_jumps <- sqrt(diag(joint_covariance))

reduced_form <- jumps[1]
first_stage <- jumps[2]
treatment_effect <- reduced_form / first_stage

gradient <- c(
  1 / first_stage,
  -reduced_form / first_stage^2
)

treatment_se <- sqrt(
  drop(t(gradient) %*% joint_covariance %*% gradient)
)

n_obs <- nrow(dat)

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(
      term = "treatment_effect",
      estimate = unname(as.numeric(treatment_effect)),
      se = unname(as.numeric(treatment_se)),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "reduced_form",
      estimate = unname(as.numeric(reduced_form)),
      se = unname(as.numeric(se_jumps[1])),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "first_stage",
      estimate = unname(as.numeric(first_stage)),
      se = unname(as.numeric(se_jumps[2])),
      n_obs = as.integer(n_obs)
    )
  ),
  method_metadata = list(
    estimator = "weighted local-linear fuzzy regression discontinuity",
    vcov = "HC0 with triangular fixed weights and delta method"
  ),
  diagnostics = list()
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  pretty = TRUE,
  digits = 16,
  null = "null"
)
