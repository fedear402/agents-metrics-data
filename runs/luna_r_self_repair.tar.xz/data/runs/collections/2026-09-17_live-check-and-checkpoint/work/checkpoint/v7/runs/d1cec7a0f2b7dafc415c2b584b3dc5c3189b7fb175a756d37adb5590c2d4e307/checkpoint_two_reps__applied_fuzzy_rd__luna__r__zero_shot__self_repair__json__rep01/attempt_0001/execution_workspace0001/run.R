d <- read.csv("input.csv")

keep <- is.finite(d$score) &
  is.finite(d$participated) &
  is.finite(d$earnings) &
  abs(d$score) < 1

d <- d[keep, , drop = FALSE]
x <- d$score
w <- 1 - abs(x)

X <- cbind(
  left_intercept = as.numeric(x < 0),
  left_slope = x * as.numeric(x < 0),
  right_intercept = as.numeric(x >= 0),
  right_slope = x * as.numeric(x >= 0)
)

Y <- cbind(d$earnings, d$participated)
bread <- solve(crossprod(X, w * X))
beta <- bread %*% crossprod(X, w * Y)
resid <- Y - X %*% beta

meat <- function(a, b) {
  S <- matrix(0, nrow = ncol(X), ncol = ncol(X))
  for (i in seq_len(nrow(X))) {
    S <- S + (w[i]^2 * resid[i, a] * resid[i, b]) *
      tcrossprod(X[i, ])
  }
  S
}

V11 <- bread %*% meat(1, 1) %*% bread
V22 <- bread %*% meat(2, 2) %*% bread
V12 <- bread %*% meat(1, 2) %*% bread

contrast <- c(-1, 0, 1, 0)

reduced_form <- as.numeric(crossprod(contrast, beta[, 1]))
first_stage <- as.numeric(crossprod(contrast, beta[, 2]))

var_rf <- as.numeric(t(contrast) %*% V11 %*% contrast)
var_fs <- as.numeric(t(contrast) %*% V22 %*% contrast)
cov_rf_fs <- as.numeric(t(contrast) %*% V12 %*% contrast)

treatment_effect <- reduced_form / first_stage
var_te <- var_rf / first_stage^2 +
  reduced_form^2 * var_fs / first_stage^4 -
  2 * reduced_form * cov_rf_fs / first_stage^3

safe_se <- function(v) {
  if (is.finite(v) && v >= 0) sqrt(v) else NA_real_
}

n_obs <- nrow(d)

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(
      term = "treatment_effect",
      estimate = treatment_effect,
      se = safe_se(var_te),
      n_obs = n_obs
    ),
    list(
      term = "reduced_form",
      estimate = reduced_form,
      se = safe_se(var_rf),
      n_obs = n_obs
    ),
    list(
      term = "first_stage",
      estimate = first_stage,
      se = safe_se(var_fs),
      n_obs = n_obs
    )
  ),
  method_metadata = list(
    estimator = "Fuzzy local-linear regression discontinuity with triangular weights",
    vcov = "Conventional heteroskedasticity-robust HC0; delta method with joint covariance"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, na = "null", digits = 17)
