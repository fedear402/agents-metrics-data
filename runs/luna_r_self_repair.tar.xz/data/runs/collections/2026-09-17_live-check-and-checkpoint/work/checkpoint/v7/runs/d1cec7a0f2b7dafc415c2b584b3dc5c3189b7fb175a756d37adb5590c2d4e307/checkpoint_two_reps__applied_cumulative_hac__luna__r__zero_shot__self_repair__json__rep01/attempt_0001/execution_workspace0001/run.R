dat <- read.csv("input.csv", stringsAsFactors = FALSE)

date_parsed <- as.Date(dat$date)
if (anyNA(date_parsed)) {
  ord <- order(dat$date, seq_len(nrow(dat)))
} else {
  ord <- order(date_parsed, seq_len(nrow(dat)))
}
dat <- dat[ord, , drop = FALSE]

y_all <- log(dat$sales)
dv_all <- c(NA_real_, diff(log(dat$vix)))

lag_matrix <- sapply(1:15, function(k) {
  c(rep(NA_real_, k), dv_all[seq_len(length(dv_all) - k)])
})
colnames(lag_matrix) <- paste0("lag_", 1:15)

complete <- complete.cases(y_all, lag_matrix)
y <- y_all[complete]
X <- cbind("(Intercept)" = 1, lag_matrix[complete, , drop = FALSE])

N <- nrow(X)
K <- ncol(X)

beta <- solve(crossprod(X), crossprod(X, y))
resid <- as.vector(y - X %*% beta)

Z <- X * resid
S <- crossprod(Z)

max_lag <- 15
for (j in seq_len(max_lag)) {
  if (j < N) {
    cross_j <- crossprod(Z[(j + 1):N, , drop = FALSE],
                         Z[1:(N - j), , drop = FALSE])
    weight <- 1 - j / 16
    S <- S + weight * (cross_j + t(cross_j))
  }
}

bread <- solve(crossprod(X))
V <- bread %*% S %*% bread
V <- V * N / (N - 16)

cum_vector <- c(0, rep(1, 15))
cum_estimate <- sum(beta[2:16])
cum_se <- sqrt(as.numeric(t(cum_vector) %*% V %*% cum_vector))

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(
      term = "cumulative_response",
      estimate = as.numeric(cum_estimate),
      se = as.numeric(cum_se),
      n_obs = as.integer(N)
    ),
    list(
      term = "lag_1",
      estimate = as.numeric(beta[2]),
      se = as.numeric(sqrt(V[2, 2])),
      n_obs = as.integer(N)
    ),
    list(
      term = "lag_15",
      estimate = as.numeric(beta[16]),
      se = as.numeric(sqrt(V[16, 16])),
      n_obs = as.integer(N)
    )
  ),
  method_metadata = list(
    estimator = "OLS with intercept and 15 lags of first-differenced log volatility",
    vcov = "Newey-West HAC, Bartlett weights, maximum lag 15, scaled by N/(N-16)"
  ),
  diagnostics = list()
)

if (!requireNamespace("jsonlite", quietly = TRUE)) {
  stop("The jsonlite package is required.")
}

jsonlite::write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  digits = 17,
  pretty = TRUE,
  null = "null"
)
