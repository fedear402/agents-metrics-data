library(jsonlite)

data <- read.csv("input.csv", stringsAsFactors = FALSE)
data <- data[order(data$time), ]

forecasts <- numeric(150)
forecast_times <- 101:250

for (i in seq_along(forecast_times)) {
  f <- forecast_times[i]
  history <- data$y[(f - 100):(f - 1)]
  
  fit <- lm(history[2:100] ~ history[1:99])
  forecasts[i] <- coef(fit)[1] + coef(fit)[2] * history[100]
}

actual <- data$y[forecast_times]
rmse <- sqrt(sum((actual - forecasts)^2) / 150)

selected_times <- c(101, 150, 200, 250)
selected_forecasts <- forecasts[match(selected_times, forecast_times)]

estimates <- list(
  list(term = "rmse", estimate = as.numeric(rmse), se = NULL, n_obs = 150L),
  list(term = "forecast_101", estimate = as.numeric(selected_forecasts[1]), se = NULL, n_obs = 99L),
  list(term = "forecast_150", estimate = as.numeric(selected_forecasts[2]), se = NULL, n_obs = 99L),
  list(term = "forecast_200", estimate = as.numeric(selected_forecasts[3]), se = NULL, n_obs = 99L),
  list(term = "forecast_250", estimate = as.numeric(selected_forecasts[4]), se = NULL, n_obs = 99L)
)

result <- list(
  task_id = "hard_rolling",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "Rolling OLS AR(1) with intercept",
    vcov = "Not applicable"
  ),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
