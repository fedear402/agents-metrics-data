df <- read.csv("input.csv", stringsAsFactors = FALSE)

parsed_date <- as.Date(df$date)
if (all(!is.na(parsed_date))) {
  df <- df[order(parsed_date), , drop = FALSE]
} else {
  df <- df[order(df$date), , drop = FALSE]
}

n <- nrow(df)
log_vix <- log(df$vix)
log_sales <- log(df$sales)
vol_change <- c(NA_real_, diff(log_vix))

if (n < 17) stop("Insufficient observations for 15 lags.")

rows <- 17:n
y <- log_sales[rows]

X <- matrix(1, nrow = length(rows), ncol = 16)
colnames(X) <- c("intercept", paste0("lag_", 1:15))

for (j in 1:15) {
  X[, j + 1] <- vol_change[rows - j]
}

N <- nrow(X)
XtX_inv <- solve(crossprod(X))
beta <- XtX_inv %*% crossprod(X, y)
resid <- as.vector(y - X %*% beta)

scores <- X * resid
meat <- crossprod(scores)

if (N > 1) {
  for (j in 1:15) {
    if (j < N) {
      gamma_j <- crossprod(scores[(j + 1):N, , drop = FALSE],
                           scores[1:(N - j), , drop = FALSE])
      weight <- 1 - j / 16
      meat <- meat + weight * (gamma_j + t(gamma_j))
    }
  }
}

vcov_hac <- XtX_inv %*% meat %*% XtX_inv
vcov_hac <- vcov_hac * N / (N - 16)

cumulative_weights <- c(0, rep(1, 15))
cumulative_estimate <- sum(beta[2:16])
cumulative_se <- sqrt(as.numeric(t(cumulative_weights) %*%
                                  vcov_hac %*%
                                  cumulative_weights))

lag1_estimate <- as.numeric(beta[2])
lag1_se <- sqrt(vcov_hac[2, 2])

lag15_estimate <- as.numeric(beta[16])
lag15_se <- sqrt(vcov_hac[16, 16])

result <- sprintf(
  paste0(
    '{',
    '"task_id":"applied_cumulative_hac",',
    '"platform":"r",',
    '"estimates":[',
    '{"term":"cumulative_response","estimate":%.15g,"se":%.15g,"n_obs":%d},',
    '{"term":"lag_1","estimate":%.15g,"se":%.15g,"n_obs":%d},',
    '{"term":"lag_15","estimate":%.15g,"se":%.15g,"n_obs":%d}',
    '],',
    '"method_metadata":{',
    '"estimator":"OLS with intercept and lags 1 through 15 of first-differenced log volatility",',
    '"vcov":"Newey-West HAC, maximum lag 15, Bartlett weights, multiplied by N/(N-16)"',
    '},',
    '"diagnostics":{}',
    '}'
  ),
  cumulative_estimate, cumulative_se, N,
  lag1_estimate, lag1_se, N,
  lag15_estimate, lag15_se, N
)

writeLines(result, "result.json")
