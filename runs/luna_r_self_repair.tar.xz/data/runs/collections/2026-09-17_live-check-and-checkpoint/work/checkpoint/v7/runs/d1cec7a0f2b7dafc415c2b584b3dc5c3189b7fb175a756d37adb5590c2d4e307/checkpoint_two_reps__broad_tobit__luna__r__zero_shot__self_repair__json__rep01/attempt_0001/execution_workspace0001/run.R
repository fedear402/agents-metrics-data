dat <- read.csv("input.csv")

y <- as.numeric(dat$y)
xmat <- cbind(const = 1, x = as.numeric(dat$x), z = as.numeric(dat$z))
n <- length(y)

if (any(!is.finite(y)) || any(!is.finite(xmat))) {
  stop("Input contains non-finite values.")
}
if (any(y < 0)) {
  stop("Observed expenditure must be non-negative.")
}

negloglik <- function(par) {
  beta <- par[1:3]
  sigma <- exp(par[4])
  eta <- drop(xmat %*% beta)
  censored <- y <= 0
  ll <- numeric(n)

  ll[censored] <- pnorm(
    (0 - eta[censored]) / sigma,
    log.p = TRUE
  )
  ll[!censored] <- dnorm(
    (y[!censored] - eta[!censored]) / sigma,
    log = TRUE
  ) - log(sigma)

  value <- -sum(ll)
  if (!is.finite(value)) 1e100 else value
}

beta_start <- tryCatch(
  coef(lm(y ~ x + z, data = dat)),
  error = function(e) c("(Intercept)" = 0, x = 0, z = 0)
)
beta_start <- as.numeric(beta_start)
if (length(beta_start) != 3 || any(!is.finite(beta_start))) {
  beta_start <- c(0, 0, 0)
}

sigma_start <- sd(y)
if (!is.finite(sigma_start) || sigma_start <= 0) {
  sigma_start <- 1
}

fit <- optim(
  par = c(beta_start, log(sigma_start)),
  fn = negloglik,
  method = "BFGS",
  hessian = TRUE,
  control = list(maxit = 10000, reltol = 1e-12)
)

if (fit$convergence != 0) {
  fit <- optim(
    par = fit$par,
    fn = negloglik,
    method = "Nelder-Mead",
    control = list(maxit = 20000, reltol = 1e-12)
  )
  fit <- optim(
    par = fit$par,
    fn = negloglik,
    method = "BFGS",
    hessian = TRUE,
    control = list(maxit = 10000, reltol = 1e-12)
  )
}

if (!is.finite(fit$value) || any(!is.finite(fit$par))) {
  stop("Maximum likelihood estimation failed.")
}

theta <- fit$par
beta_hat <- theta[1:3]
sigma_hat <- exp(theta[4])

hess <- fit$hessian
vcov_theta <- tryCatch(
  solve(hess),
  error = function(e) solve(hess + diag(1e-8, nrow(hess)))
)

se_beta <- sqrt(pmax(diag(vcov_theta)[1:3], 0))
se_sigma <- sigma_hat * sqrt(pmax(vcov_theta[4, 4], 0))

estimates <- list(
  list(term = "const", estimate = unname(beta_hat[1]),
       se = unname(se_beta[1]), n_obs = n),
  list(term = "x", estimate = unname(beta_hat[2]),
       se = unname(se_beta[2]), n_obs = n),
  list(term = "z", estimate = unname(beta_hat[3]),
       se = unname(se_beta[3]), n_obs = n),
  list(term = "sigma", estimate = unname(sigma_hat),
       se = NULL, n_obs = n)
)

output <- list(
  task_id = "broad_tobit",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "Homoskedastic Gaussian Tobit maximum likelihood",
    vcov = "Inverse jointly estimated observed information matrix"
  ),
  diagnostics = list(
    convergence = fit$convergence,
    log_likelihood = -fit$value
  )
)

if (!requireNamespace("jsonlite", quietly = TRUE)) {
  stop("Package 'jsonlite' is required.")
}

jsonlite::write_json(
  output,
  path = "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 15,
  pretty = TRUE
)
