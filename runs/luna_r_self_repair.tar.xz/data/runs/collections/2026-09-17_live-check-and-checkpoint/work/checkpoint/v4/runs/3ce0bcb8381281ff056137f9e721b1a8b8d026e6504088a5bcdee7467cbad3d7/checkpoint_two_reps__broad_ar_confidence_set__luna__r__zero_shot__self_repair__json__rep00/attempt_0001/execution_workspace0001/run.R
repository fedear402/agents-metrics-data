dat <- read.csv("input.csv")

n <- nrow(dat)
y <- dat$y
endog <- dat$endog
x <- dat$x
z <- as.matrix(dat[, c("z1", "z2")])

X <- cbind(1, x)
XZ <- cbind(X, z)

qr_x <- qr(X)
qr_xz <- qr(XZ)

Zr <- qr.resid(qr_x, z)
Zr_cross <- crossprod(Zr)
Zr_inv <- solve(Zr_cross)

ar_components <- function(beta) {
  yb <- y - beta * endog
  rx <- qr.resid(qr_x, yb)
  fitted_z <- Zr %*% (Zr_inv %*% crossprod(Zr, rx))
  ssr <- sum(fitted_z^2)
  sse <- sum(qr.resid(qr_xz, yb)^2)
  c(ssr = ssr, sse = sse)
}

df_num <- 2
df_den <- n - 4
f_critical <- qf(0.95, df_num, df_den)

ar_f <- function(beta) {
  comp <- ar_components(beta)
  (comp["ssr"] / df_num) / (comp["sse"] / df_den)
}

inequality_value <- function(beta) {
  comp <- ar_components(beta)
  comp["ssr"] * df_den - f_critical * df_num * comp["sse"]
}

v_m1 <- inequality_value(-1)
v_0 <- inequality_value(0)
v_1 <- inequality_value(1)

coef_a <- (v_1 + v_m1 - 2 * v_0) / 2
coef_b <- (v_1 - v_m1) / 2
coef_c <- v_0

tol <- 1e-10 * max(1, abs(coef_a), abs(coef_b), abs(coef_c))

if (abs(coef_a) > tol) {
  roots <- polyroot(c(coef_c, coef_b, coef_a))
} else if (abs(coef_b) > tol) {
  roots <- -coef_c / coef_b
} else {
  roots <- numeric(0)
}

real_roots <- Re(roots[abs(Im(roots)) <= 1e-7])
real_roots <- sort(real_roots)

if (length(real_roots) >= 2) {
  boundary_low <- real_roots[1]
  boundary_high <- real_roots[length(real_roots)]
} else {
  boundary_low <- NA_real_
  boundary_high <- NA_real_
}

accepts_zero <- as.numeric(inequality_value(0) <= 0)

if (abs(coef_a) > tol) {
  unbounded <- as.numeric(coef_a < 0)
} else if (abs(coef_b) > tol) {
  unbounded <- 1
} else {
  unbounded <- as.numeric(coef_c <= 0)
}

fmt <- function(x) {
  if (is.na(x)) "null" else sprintf("%.15g", x)
}

json <- paste0(
  "{\n",
  '  "task_id": "broad_ar_confidence_set",', "\n",
  '  "platform": "r",', "\n",
  '  "estimates": [', "\n",
  '    {"term": "boundary_low", "estimate": ', fmt(boundary_low),
  ', "se": null, "n_obs": ', n, '},', "\n",
  '    {"term": "boundary_high", "estimate": ', fmt(boundary_high),
  ', "se": null, "n_obs": ', n, '},', "\n",
  '    {"term": "accepts_zero", "estimate": ', fmt(accepts_zero),
  ', "se": null, "n_obs": ', n, '},', "\n",
  '    {"term": "unbounded", "estimate": ', fmt(unbounded),
  ', "se": null, "n_obs": ', n, '},', "\n",
  '    {"term": "ar_f_at_one", "estimate": ', fmt(ar_f(1)),
  ', "se": null, "n_obs": ', n, '}', "\n",
  "  ],\n",
  '  "method_metadata": {"estimator": "Anderson-Rubin confidence set with conventional homoskedastic joint F test", "vcov": "homoskedastic"},', "\n",
  '  "diagnostics": {}', "\n",
  "}\n"
)

writeLines(json, "result.json")
