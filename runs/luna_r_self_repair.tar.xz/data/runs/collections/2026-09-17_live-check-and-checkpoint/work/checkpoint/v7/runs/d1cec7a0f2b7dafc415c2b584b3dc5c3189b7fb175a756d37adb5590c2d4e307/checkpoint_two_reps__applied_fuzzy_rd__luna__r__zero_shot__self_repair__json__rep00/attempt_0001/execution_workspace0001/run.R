#!/usr/bin/env Rscript

dat <- read.csv("input.csv", stringsAsFactors = FALSE)

keep <- is.finite(dat$score) &
  is.finite(dat$participated) &
  is.finite(dat$earnings) &
  abs(dat$score) < 1

dat <- dat[keep, , drop = FALSE]
n_obs <- nrow(dat)

right <- as.numeric(dat$score >= 0)
x <- cbind(
  intercept = 1,
  right = right,
  score = dat$score,
  right_score = right * dat$score
)

w <- 1 - abs(dat$score)

fit_wls <- function(y) {
  fit <- lm.wfit(x = x, y = y, w = w)
  beta <- fit$coefficients
  residuals <- fit$residuals
  bread <- solve(crossprod(x, w * x))
  meat <- crossprod(
    x,
    (w^2 * residuals^2) * x
  )
  vcov <- bread %*% meat %*% bread
  list(beta = beta, residuals = residuals, vcov = vcov)
}

earn_fit <- fit_wls(dat$earnings)
part_fit <- fit_wls(dat$participated)

reduced_form <- earn_fit$beta[2]
first_stage <- part_fit$beta[2]

var_rf <- earn_fit$vcov[2, 2]
var_fs <- part_fit$vcov[2, 2]

cross_meat <- crossprod(
  x,
  (w^2 * earn_fit$residuals * part_fit$residuals) * x
)

bread <- solve(crossprod(x, w * x))
cross_vcov <- bread %*% cross_meat %*% bread
cov_rf_fs <- cross_vcov[2, 2]

rf_se <- sqrt(max(0, var_rf))
fs_se <- sqrt(max(0, var_fs))

if (is.finite(first_stage) && first_stage != 0) {
  treatment_effect <- reduced_form / first_stage
  gradient <- c(1 / first_stage, -reduced_form / first_stage^2)
  joint_vcov <- matrix(
    c(var_rf, cov_rf_fs, cov_rf_fs, var_fs),
    nrow = 2,
    byrow = TRUE
  )
  treatment_var <- as.numeric(t(gradient) %*% joint_vcov %*% gradient)
  treatment_se <- sqrt(max(0, treatment_var))
} else {
  treatment_effect <- NA_real_
  treatment_se <- NA_real_
}

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(
      term = "treatment_effect",
      estimate = treatment_effect,
      se = treatment_se,
      n_obs = n_obs
    ),
    list(
      term = "reduced_form",
      estimate = reduced_form,
      se = rf_se,
      n_obs = n_obs
    ),
    list(
      term = "first_stage",
      estimate = first_stage,
      se = fs_se,
      n_obs = n_obs
    )
  ),
  method_metadata = list(
    estimator = "Fuzzy regression discontinuity with local-linear weighted least squares",
    vcov = "Conventional heteroskedasticity-robust HC0 with delta-method treatment effect"
  ),
  diagnostics = list()
)

jsonlite::write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  digits = 16,
  na = "null"
)
