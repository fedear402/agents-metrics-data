d <- read.csv("input.csv")

n <- nrow(d)
q <- 2L
df <- n - 4L
critical <- qf(0.95, q, df)
k <- q * critical / df

ry <- residuals(lm(y ~ x, data = d))
rd <- residuals(lm(endog ~ x, data = d))

full_y <- lm(y ~ x + z1 + z2, data = d)
full_d <- lm(endog ~ x + z1 + z2, data = d)

uy <- residuals(full_y)
ud <- residuals(full_d)

A <- sum(rd^2) - (1 + k) * sum(ud^2)
B <- -2 * (sum(ry * rd) - (1 + k) * sum(uy * ud))
C <- sum(ry^2) - (1 + k) * sum(uy^2)

discriminant <- B^2 - 4 * A * C

if (abs(A) < 1e-12) {
  if (abs(B) < 1e-12) {
    boundaries <- c(-Inf, Inf)
  } else {
    root <- -C / B
    boundaries <- sort(c(root, root))
  }
} else if (discriminant < 0) {
  boundaries <- c(NA_real_, NA_real_)
} else {
  boundaries <- sort(c(
    (-B - sqrt(discriminant)) / (2 * A),
    (-B + sqrt(discriminant)) / (2 * A)
  ))
}

accepts <- function(beta) {
  A * beta^2 + B * beta + C <= 0
}

unbounded <- if (abs(A) < 1e-12) {
  as.integer(abs(B) < 1e-12 || TRUE)
} else {
  as.integer(A < 0)
}

transformed <- d$y - d$endog
transformed_one <- d$y - d$endog * 1

restricted_one <- lm(transformed_one ~ x, data = d)
unrestricted_one <- lm(transformed_one ~ x + z1 + z2, data = d)

ar_f_at_one <- (
  (deviance(restricted_one) - deviance(unrestricted_one)) / q
) / (deviance(unrestricted_one) / df)

estimates <- list(
  list(
    term = "boundary_low",
    estimate = unname(boundaries[1]),
    se = NULL,
    n_obs = n
  ),
  list(
    term = "boundary_high",
    estimate = unname(boundaries[2]),
    se = NULL,
    n_obs = n
  ),
  list(
    term = "accepts_zero",
    estimate = unname(as.numeric(accepts(0))),
    se = NULL,
    n_obs = n
  ),
  list(
    term = "unbounded",
    estimate = unname(unbounded),
    se = NULL,
    n_obs = n
  ),
  list(
    term = "ar_f_at_one",
    estimate = unname(ar_f_at_one),
    se = NULL,
    n_obs = n
  )
)

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "Anderson-Rubin inversion with homoskedastic joint F test",
    vcov = "conventional homoskedastic"
  ),
  diagnostics = list()
)

jsonlite::write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
