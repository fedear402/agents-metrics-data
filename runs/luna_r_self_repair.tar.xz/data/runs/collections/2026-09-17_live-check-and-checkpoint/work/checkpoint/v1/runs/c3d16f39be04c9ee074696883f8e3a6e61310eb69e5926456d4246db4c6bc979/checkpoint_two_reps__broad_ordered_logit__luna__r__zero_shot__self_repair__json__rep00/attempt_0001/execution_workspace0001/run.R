#!/usr/bin/env Rscript

dat <- read.csv("input.csv", stringsAsFactors = FALSE)

dat$y <- ordered(dat$y, levels = c(1, 2, 3))

fit <- MASS::polr(
  y ~ x + z,
  data = dat,
  method = "logistic",
  Hess = TRUE,
  model = TRUE
)

vc <- solve(fit$Hessian)
coef_names <- names(fit$coefficients)

beta_x <- unname(fit$coefficients["x"])
beta_z <- unname(fit$coefficients["z"])
theta_high <- unname(fit$zeta[2])

eta_high <- beta_x * 1 + beta_z * 0
prob_high <- plogis(eta_high - theta_high)

n_obs <- nrow(dat)

result <- list(
  task_id = "broad_ordered_logit",
  platform = "r",
  estimates = list(
    list(
      term = "x",
      estimate = as.numeric(beta_x),
      se = as.numeric(sqrt(vc[which(coef_names == "x"), which(coef_names == "x")])),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "z",
      estimate = as.numeric(beta_z),
      se = as.numeric(sqrt(vc[which(coef_names == "z"), which(coef_names == "z")])),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "prob_high",
      estimate = as.numeric(prob_high),
      se = NULL,
      n_obs = as.integer(n_obs)
    )
  ),
  method_metadata = list(
    estimator = "maximum likelihood ordered logistic regression",
    vcov = "conventional observed-information standard errors"
  ),
  diagnostics = list()
)

jsonlite::write_json(
  result,
  path = "result.json",
  auto_unbox = TRUE,
  digits = 17,
  null = "null"
)
