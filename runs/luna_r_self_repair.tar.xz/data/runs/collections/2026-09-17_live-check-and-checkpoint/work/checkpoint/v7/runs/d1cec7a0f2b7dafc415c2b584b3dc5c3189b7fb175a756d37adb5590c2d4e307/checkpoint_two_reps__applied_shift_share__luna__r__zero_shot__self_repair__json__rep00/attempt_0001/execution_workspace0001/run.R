#!/usr/bin/env Rscript

input <- read.csv("input.csv", stringsAsFactors = FALSE)

region_id <- input$region_id
industry_id <- input$industry_id

regions <- unique(region_id)
industries <- unique(industry_id)

region_data <- input[!duplicated(region_id), c("region_id", "region_weight", "x", "y")]
region_data <- region_data[match(regions, region_data$region_id), ]

e <- region_data$region_weight / sum(region_data$region_weight)
x_r <- region_data$x
y_r <- region_data$y

share_mat <- matrix(
  0,
  nrow = length(regions),
  ncol = length(industries),
  dimnames = list(as.character(regions), as.character(industries))
)

for (i in seq_len(nrow(input))) {
  r <- match(input$region_id[i], regions)
  n <- match(input$industry_id[i], industries)
  share_mat[r, n] <- input$share[i]
}

shock <- input$shock[match(industries, input$industry_id)]

z_r <- as.vector(share_mat %*% shock)

weighted_mean <- function(v, w) {
  sum(w * v) / sum(w)
}

y0 <- y_r - weighted_mean(y_r, e)
x0 <- x_r - weighted_mean(x_r, e)
z0 <- z_r - weighted_mean(z_r, e)

s <- as.vector(crossprod(e, share_mat))
keep <- s > 0

s <- s[keep]
shock <- shock[keep]
share_used <- share_mat[, keep, drop = FALSE]

aggregate_residual <- function(v0) {
  as.vector(crossprod(e * v0, share_used)) / s
}

ybar <- aggregate_residual(y0)
xbar <- aggregate_residual(x0)
zbar <- aggregate_residual(z0)

iv_fit <- function(y, endogenous, instrument, weights) {
  n <- length(y)
  X <- cbind(1, endogenous)
  Z <- cbind(1, instrument)
  W <- diag(weights, nrow = n)

  ZWZ <- crossprod(Z, W %*% Z)
  ZWX <- crossprod(Z, W %*% X)
  ZWy <- crossprod(Z, W %*% y)

  M <- solve(ZWZ)
  A <- crossprod(X, W %*% Z) %*% M %*% ZWX
  b <- solve(A, crossprod(X, W %*% Z) %*% M %*% ZWy)

  residuals <- as.vector(y - X %*% b)

  meat_core <- matrix(0, nrow = ncol(Z), ncol = ncol(Z))
  for (i in seq_len(n)) {
    zi <- matrix(Z[i, ], ncol = 1)
    meat_core <- meat_core + weights[i]^2 * residuals[i]^2 * (zi %*% t(zi))
  }

  meat <- crossprod(X, W %*% Z) %*% M %*% meat_core %*% M %*%
    crossprod(Z, W %*% X)

  vcov <- solve(A) %*% meat %*% solve(A)
  vcov <- vcov * n / (n - ncol(X))

  list(
    coefficients = as.vector(b),
    vcov = vcov,
    residuals = residuals
  )
}

effect_fit <- iv_fit(ybar, xbar, shock, s)
first_stage_fit <- iv_fit(xbar, zbar, shock, s)

n_obs <- length(s)

effective_shocks <- 1 / sum(s^2)

effect_estimate <- effect_fit$coefficients[2]
effect_se <- sqrt(effect_fit$vcov[2, 2])

first_stage_estimate <- first_stage_fit$coefficients[2]
first_stage_se <- sqrt(first_stage_fit$vcov[2, 2])

json_num <- function(x) {
  formatC(x, format = "fg", digits = 15, flag = "#")
}

result <- paste0(
  "{\n",
  '  "task_id": "applied_shift_share",\n',
  '  "platform": "r",\n',
  '  "estimates": [\n',
  '    {"term": "effect", "estimate": ', json_num(effect_estimate),
  ', "se": ', json_num(effect_se), ', "n_obs": ', n_obs, '},\n',
  '    {"term": "first_stage", "estimate": ', json_num(first_stage_estimate),
  ', "se": ', json_num(first_stage_se), ', "n_obs": ', n_obs, '},\n',
  '    {"term": "effective_shocks", "estimate": ', json_num(effective_shocks),
  ', "se": null, "n_obs": ', n_obs, '}\n',
  "  ],\n",
  '  "method_metadata": {"estimator": "shock-level weighted 2SLS", "vcov": "HC1 exposure-robust shock-level sandwich"},',
  "\n",
  '  "diagnostics": {}',
  "\n",
  "}\n"
)

writeLines(result, "result.json")
