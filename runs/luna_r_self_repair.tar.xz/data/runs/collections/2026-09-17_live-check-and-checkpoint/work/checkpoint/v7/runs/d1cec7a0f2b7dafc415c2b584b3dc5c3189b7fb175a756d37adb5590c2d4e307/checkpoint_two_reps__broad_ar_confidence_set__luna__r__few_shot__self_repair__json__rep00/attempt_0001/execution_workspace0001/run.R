d <- read.csv("input.csv")

n <- nrow(d)
q <- 2L
df <- n - 4L
critical <- qf(0.95, q, df)
k <- q * critical / df

Xr <- model.matrix(~ x, data = d)
Xu <- model.matrix(~ x + z1 + z2, data = d)

y <- d$y
endog <- d$endog

ry <- residuals(lm.fit(Xr, y))
rd <- residuals(lm.fit(Xr, endog))
uy <- residuals(lm.fit(Xu, y))
ud <- residuals(lm.fit(Xu, endog))

A <- sum(rd^2) - (1 + k) * sum(ud^2)
B <- -2 * (sum(ry * rd) - (1 + k) * sum(uy * ud))
C <- sum(ry^2) - (1 + k) * sum(uy^2)

discriminant <- B^2 - 4 * A * C
roots <- sort(Re(polyroot(c(C, B, A))))

accepts <- function(beta) {
  A * beta^2 + B * beta + C <= 0
}

ar_f <- function(beta) {
  w <- y - beta * endog
  ssr_r <- sum(residuals(lm.fit(Xr, w))^2)
  ssr_u <- sum(residuals(lm.fit(Xu, w))^2)
  ((ssr_r - ssr_u) / q) / (ssr_u / df)
}

if (length(roots) != 2L || any(!is.finite(roots)) ||
    !is.finite(discriminant) || discriminant <= 0) {
  stop("The data do not yield two finite real boundaries.")
}

accepts_zero <- as.integer(accepts(0))
unbounded <- as.integer(A < 0)

rows <- list(
  list(
    term = "boundary_low",
    estimate = unname(roots[1]),
    se = NULL,
    n_obs = n
  ),
  list(
    term = "boundary_high",
    estimate = unname(roots[2]),
    se = NULL,
    n_obs = n
  ),
  list(
    term = "accepts_zero",
    estimate = accepts_zero,
    se = NULL,
    n_obs = n
  ),
  list(
    term = "unbounded",
    estimate = unbounded,
    se = NULL,
    n_obs = n
  ),
  list(
    term = "ar_f_at_one",
    estimate = ar_f(1),
    se = NULL,
    n_obs = n
  )
)

jsonlite::write_json(
  list(
    task_id = "broad_ar_confidence_set",
    platform = "r",
    estimates = rows,
    method_metadata = list(
      estimator = "Anderson-Rubin inversion with homoskedastic joint F test",
      vcov = "conventional homoskedastic"
    ),
    diagnostics = list(
      numerator_df = q,
      denominator_df = df,
      critical_value = critical,
      quadratic_A = A,
      quadratic_B = B,
      quadratic_C = C
    )
  ),
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
