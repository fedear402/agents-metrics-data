library(jsonlite)

data <- read.csv("input.csv")
data <- data[order(data$time), ]

forecast_times <- 101:250
forecasts <- numeric(length(forecast_times))

for (i in seq_along(forecast_times)) {
  f <- forecast_times[i]
  history <- data[data$time >= f - 100 & data$time <= f - 1, ]

  stopifnot(
    nrow(history) == 100,
    identical(as.numeric(history$time), as.numeric(f - 100:f - 1))
  )

  levels <- history$y
  lagged <- levels[-length(levels)]
  current <- levels[-1]

  fit <- lm(current ~ lagged)
  forecasts[i] <- unname(coef(fit)[1] + coef(fit)[2] * tail(levels, 1))
}

actual <- data$y[match(forecast_times, data$time)]
rmse <- sqrt(mean((actual - forecasts)^2))

get_estimate <- function(term, estimate, n_obs) {
  list(
    term = term,
    estimate = unname(as.numeric(estimate)),
    se = NULL,
    n_obs = as.integer(n_obs)
  )
}

result <- list(
  task_id = "hard_rolling",
  platform = "r",
  estimates = list(
    get_estimate("rmse", rmse, 150),
    get_estimate("forecast_101", forecasts[which(forecast_times == 101)], 99),
    get_estimate("forecast_150", forecasts[which(forecast_times == 150)], 99),
    get_estimate("forecast_200", forecasts[which(forecast_times == 200)], 99),
    get_estimate("forecast_250", forecasts[which(forecast_times == 250)], 99)
  ),
  method_metadata = list(
    estimator = "Rolling OLS AR(1) with intercept",
    vcov = "Not applicable"
  ),
  diagnostics = list()
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
