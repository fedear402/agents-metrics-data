library(jsonlite)

data <- read.csv("input.csv", stringsAsFactors = FALSE)
data$date_parsed <- as.Date(data$date)
data <- data[order(data$date_parsed), ]

n_total <- nrow(data)
log_vix <- log(data$vix)
log_sales <- log(data$sales)
vix_change <- c(NA_real_, diff(log_vix))

lag_matrix <- sapply(
  1:15,
  function(j) c(rep(NA_real_, j), vix_change[1:(n_total - j)])
)
colnames(lag_matrix) <- paste0("lag_", 1:15)

complete <- complete.cases(log_sales, lag_matrix)
y <- log_sales[complete]
X <- cbind("(Intercept)" = 1, lag_matrix[complete, , drop = FALSE])

fit <- lm.fit(x = X, y = y)
beta <- fit$coefficients
residuals <- fit$residuals
N <- nrow(X)
p <- ncol(X)

scores <- X * residuals
meat <- crossprod(scores)

for (j in 1:15) {
  lag_product <- crossprod(
    scores[(j + 1):N, , drop = FALSE],
    scores[1:(N - j), , drop = FALSE]
  )
  weight <- 1 - j / 16
  meat <- meat + weight * (lag_product + t(lag_product))
}

bread <- solve(crossprod(X))
covariance <- (N / (N - 16)) * bread %*% meat %*% bread

contrast <- c(0, rep(1, 15))
cumulative <- sum(contrast * beta)
cumulative_se <- sqrt(drop(t(contrast) %*% covariance %*% contrast))

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(
      term = "cumulative_response",
      estimate = unname(as.numeric(cumulative)),
      se = unname(as.numeric(cumulative_se)),
      n_obs = as.integer(N)
    ),
    list(
      term = "lag_1",
      estimate = unname(as.numeric(beta[2])),
      se = unname(as.numeric(sqrt(covariance[2, 2]))),
      n_obs = as.integer(N)
    ),
    list(
      term = "lag_15",
      estimate = unname(as.numeric(beta[16])),
      se = unname(as.numeric(sqrt(covariance[16, 16]))),
      n_obs = as.integer(N)
    )
  ),
  method_metadata = list(
    estimator = "OLS with intercept and 15 trading-observation lags of log(vix) changes",
    vcov = "Bartlett Newey-West HAC, maximum lag 15, correction N/(N-16)"
  ),
  diagnostics = list()
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
