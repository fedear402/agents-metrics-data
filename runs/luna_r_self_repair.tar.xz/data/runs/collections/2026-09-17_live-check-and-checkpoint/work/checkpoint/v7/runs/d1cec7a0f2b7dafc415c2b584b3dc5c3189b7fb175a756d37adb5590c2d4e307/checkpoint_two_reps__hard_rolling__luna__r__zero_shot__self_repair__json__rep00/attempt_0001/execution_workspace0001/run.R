dat <- read.csv("input.csv", stringsAsFactors = FALSE)
dat <- dat[order(dat$time), ]

y <- dat$y
forecast_times <- 101:250
forecasts <- numeric(length(forecast_times))

for (i in seq_along(forecast_times)) {
  f <- forecast_times[i]
  s <- (f - 99):(f - 1)
  fit <- lm(y[s] ~ y[s - 1])
  forecasts[i] <- predict(
    fit,
    newdata = data.frame(`y[s - 1]` = y[f - 1])
  )
}

actual <- y[forecast_times]
rmse <- sqrt(mean((actual - forecasts)^2))

estimate_at <- function(f) {
  forecasts[which(forecast_times == f)]
}

result <- list(
  task_id = "hard_rolling",
  platform = "r",
  estimates = list(
    list(term = "rmse", estimate = unname(rmse), se = NULL, n_obs = 150L),
    list(term = "forecast_101", estimate = unname(estimate_at(101)), se = NULL, n_obs = 99L),
    list(term = "forecast_150", estimate = unname(estimate_at(150)), se = NULL, n_obs = 99L),
    list(term = "forecast_200", estimate = unname(estimate_at(200)), se = NULL, n_obs = 99L),
    list(term = "forecast_250", estimate = unname(estimate_at(250)), se = NULL, n_obs = 99L)
  ),
  method_metadata = list(
    estimator = "Rolling OLS AR(1) with intercept",
    vcov = "Not applicable"
  ),
  diagnostics = list()
)

if (requireNamespace("jsonlite", quietly = TRUE)) {
  jsonlite::write_json(
    result,
    "result.json",
    auto_unbox = TRUE,
    na = "null",
    digits = 17
  )
} else {
  escape_json <- function(x) {
    gsub('"', '\\"', format(x, scientific = FALSE, trim = TRUE))
  }

  lines <- c(
    '{',
    '  "task_id": "hard_rolling",',
    '  "platform": "r",',
    '  "estimates": ['
  )

  estimate_json <- vapply(
    result$estimates,
    function(x) {
      sprintf(
        '    {"term":"%s","estimate":%.17g,"se":null,"n_obs":%d}',
        escape_json(x$term), x$estimate, x$n_obs
      )
    },
    character(1)
  )

  lines <- c(
    lines,
    paste(estimate_json, collapse = ",\n"),
    '  ],',
    '  "method_metadata": {"estimator":"Rolling OLS AR(1) with intercept","vcov":"Not applicable"},',
    '  "diagnostics": {}',
    '}'
  )

  writeLines(lines, "result.json")
}
