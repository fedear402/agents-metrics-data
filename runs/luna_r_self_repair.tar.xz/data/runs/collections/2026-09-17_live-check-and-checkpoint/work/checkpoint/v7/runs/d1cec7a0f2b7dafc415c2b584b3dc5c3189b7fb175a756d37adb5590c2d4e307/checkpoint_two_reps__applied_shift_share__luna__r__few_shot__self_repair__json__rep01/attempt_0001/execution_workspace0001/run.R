library(jsonlite)

d <- read.csv("input.csv", stringsAsFactors = FALSE)

region_ids <- unique(d$region_id)
industry_ids <- unique(d$industry_id)

region_data <- do.call(rbind, lapply(region_ids, function(r) {
  q <- d[d$region_id == r, , drop = FALSE]
  data.frame(
    region_id = r,
    region_weight = q$region_weight[1],
    x = q$x[1],
    y = q$y[1],
    z = sum(q$share * q$shock)
  )
}))

e <- region_data$region_weight / sum(region_data$region_weight)

weighted_mean <- function(v, w) {
  sum(w * v)
}

y0 <- region_data$y - weighted_mean(region_data$y, e)
x0 <- region_data$x - weighted_mean(region_data$x, e)
z0 <- region_data$z - weighted_mean(region_data$z, e)

industry_data <- do.call(rbind, lapply(industry_ids, function(n) {
  q <- d[d$industry_id == n, , drop = FALSE]
  shares <- sapply(region_ids, function(r) {
    qr <- q[q$region_id == r, , drop = FALSE]
    if (nrow(qr) == 0) 0 else qr$share[1]
  })
  s <- sum(e * shares)
  data.frame(
    industry_id = n,
    shock = q$shock[1],
    s = s,
    ybar = if (s > 0) sum(e * shares * y0) / s else NA_real_,
    xbar = if (s > 0) sum(e * shares * x0) / s else NA_real_,
    zbar = if (s > 0) sum(e * shares * z0) / s else NA_real_
  )
}))

industry_data <- industry_data[
  is.finite(industry_data$s) &
    industry_data$s > 0 &
    is.finite(industry_data$shock) &
    is.finite(industry_data$ybar) &
    is.finite(industry_data$xbar) &
    is.finite(industry_data$zbar),
]

shock_iv <- function(dependent, endogenous, instrument, weights) {
  X <- cbind(1, endogenous)
  Z <- cbind(1, instrument)
  WZ <- Z * weights
  cross <- crossprod(Z, weights * X)
  beta <- solve(cross, crossprod(Z, weights * dependent))
  residual <- drop(dependent - X %*% beta)
  scores <- Z * (weights * residual)
  inverse <- solve(cross)
  n <- length(dependent)
  covariance <- (n / (n - 2)) *
    inverse %*% crossprod(scores) %*% t(inverse)
  c(estimate = beta[2], se = sqrt(covariance[2, 2]))
}

effect_fit <- shock_iv(
  industry_data$ybar,
  industry_data$xbar,
  industry_data$shock,
  industry_data$s
)

first_stage_fit <- shock_iv(
  industry_data$xbar,
  industry_data$zbar,
  industry_data$shock,
  industry_data$s
)

n_industries <- nrow(industry_data)
effective_shocks <- 1 / sum(industry_data$s^2)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(
      term = "effect",
      estimate = unname(as.numeric(effect_fit["estimate"])),
      se = unname(as.numeric(effect_fit["se"])),
      n_obs = as.integer(n_industries)
    ),
    list(
      term = "first_stage",
      estimate = unname(as.numeric(first_stage_fit["estimate"])),
      se = unname(as.numeric(first_stage_fit["se"])),
      n_obs = as.integer(n_industries)
    ),
    list(
      term = "effective_shocks",
      estimate = as.numeric(effective_shocks),
      se = NULL,
      n_obs = as.integer(n_industries)
    )
  ),
  method_metadata = list(
    estimator = "Borusyak-Hull-Jaravel shock-level weighted IV",
    vcov = "HC1 with N/(N-2) multiplier using structural IV residuals"
  ),
  diagnostics = list()
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
