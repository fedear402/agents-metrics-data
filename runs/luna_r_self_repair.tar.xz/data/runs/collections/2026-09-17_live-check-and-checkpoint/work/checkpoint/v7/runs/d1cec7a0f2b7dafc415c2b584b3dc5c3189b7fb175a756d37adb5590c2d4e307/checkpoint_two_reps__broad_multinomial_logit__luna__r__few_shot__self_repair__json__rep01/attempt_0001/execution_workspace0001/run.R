d <- read.csv("input.csv")

d$y <- factor(d$y, levels = c(0, 1, 2))

fit <- nnet::multinom(
  y ~ x + z,
  data = d,
  Hess = TRUE,
  trace = FALSE,
  maxit = 1000,
  reltol = 1e-12,
  abstol = 1e-12
)

B <- coef(fit)
V <- vcov(fit)
n <- nrow(d)

se_for <- function(category, term) {
  sqrt(V[paste0(category, ":", term), paste0(category, ":", term)])
}

indices <- c(
  0,
  unname(B["1", "(Intercept)"]),
  unname(B["2", "(Intercept)"])
)

scaled <- exp(indices - max(indices))
prob_cat2_zero <- scaled[3] / sum(scaled)

result <- list(
  task_id = "broad_multinomial_logit",
  platform = "r",
  estimates = list(
    list(
      term = "x_cat1",
      estimate = unname(B["1", "x"]),
      se = se_for("1", "x"),
      n_obs = n
    ),
    list(
      term = "z_cat1",
      estimate = unname(B["1", "z"]),
      se = se_for("1", "z"),
      n_obs = n
    ),
    list(
      term = "x_cat2",
      estimate = unname(B["2", "x"]),
      se = se_for("2", "x"),
      n_obs = n
    ),
    list(
      term = "z_cat2",
      estimate = unname(B["2", "z"]),
      se = se_for("2", "z"),
      n_obs = n
    ),
    list(
      term = "prob_cat2_zero",
      estimate = prob_cat2_zero,
      se = NULL,
      n_obs = n
    )
  ),
  method_metadata = list(
    estimator = "maximum likelihood multinomial logit",
    vcov = "conventional observed information"
  ),
  diagnostics = list()
)

jsonlite::write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
