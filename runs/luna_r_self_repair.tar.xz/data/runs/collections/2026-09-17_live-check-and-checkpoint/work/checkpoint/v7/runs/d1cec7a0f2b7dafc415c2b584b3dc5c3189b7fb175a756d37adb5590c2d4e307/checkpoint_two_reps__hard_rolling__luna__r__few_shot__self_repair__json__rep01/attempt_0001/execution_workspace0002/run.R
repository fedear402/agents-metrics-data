library(jsonlite)

data <- read.csv("input.csv")
data <- data[order(data$time), ]

forecast_times <- 101:250
forecasts <- numeric(length(forecast_times))

for (i in seq_along(forecast_times)) {
  f <- forecast_times[i]
  expected_times <- seq.int(f - 100L, f - 1L)
  history <- data[data$time %in% expected_times, ]
  history <- history[order(history$time), ]

  stopifnot(
    nrow(history) == 100L,
    identical(as.numeric(history$time), as.numeric(expected_times))
  )

  levels <- as.numeric(history$y)
  lagged <- levels[-length(levels)]
  current <- levels[-1L]

  fit <- lm(current ~ lagged)
  coefficients <- coef(fit)

  forecasts[i] <- unname(
    coefficients[1L] + coefficients[2L] * tail(levels, 1L)
  )
}

actual <- as.numeric(data$y[match(forecast_times, data$time)])
rmse <- sqrt(sum((actual - forecasts)^2) / length(forecast_times))

get_estimate <- function(term, estimate, n_obs) {
  list(
    term = term,
    estimate = unname(as.numeric(estimate)),
    se = NULL,
    n_obs = as.integer(n_obs)
  )
}

result <- list(
  task_id = "hard_rolling",
  platform = "r",
  estimates = list(
    get_estimate("rmse", rmse, 150L),
    get_estimate("forecast_101", forecasts[1L], 99L),
    get_estimate("forecast_150", forecasts[which(forecast_times == 150L)], 99L),
    get_estimate("forecast_200", forecasts[which(forecast_times == 200L)], 99L),
    get_estimate("forecast_250", forecasts[which(forecast_times == 250L)], 99L)
  ),
  method_metadata = list(
    estimator = "Rolling OLS AR(1) with intercept",
    vcov = "Not applicable"
  ),
  diagnostics = list()
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
