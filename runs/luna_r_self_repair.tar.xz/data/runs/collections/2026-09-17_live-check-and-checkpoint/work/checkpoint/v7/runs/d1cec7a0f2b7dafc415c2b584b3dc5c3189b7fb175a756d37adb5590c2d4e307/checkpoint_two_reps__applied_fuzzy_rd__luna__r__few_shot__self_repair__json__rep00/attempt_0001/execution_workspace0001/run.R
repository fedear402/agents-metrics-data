library(jsonlite)

dat <- read.csv("input.csv")

keep <- abs(dat$score) < 1
dat <- dat[keep, , drop = FALSE]

score <- dat$score
right <- as.numeric(score >= 0)
weights <- 1 - abs(score)

X <- cbind(
  intercept = 1,
  right = right,
  left_slope = score * (1 - right),
  right_slope = score * right
)

bread <- solve(crossprod(X, weights * X))
contrast <- c(0, 1, 0, 0)

Y <- cbind(
  earnings = dat$earnings,
  participated = dat$participated
)

B <- bread %*% crossprod(X, weights * Y)
residuals <- Y - X %*% B

jumps <- drop(contrast %*% B)

joint <- matrix(NA_real_, 2, 2)
for (a in 1:2) {
  for (b in 1:2) {
    meat <- crossprod(
      X,
      (weights^2 * residuals[, a] * residuals[, b]) * X
    )
    joint[a, b] <- drop(
      t(contrast) %*% bread %*% meat %*% bread %*% contrast
    )
  }
}

reduced_form <- jumps[1]
first_stage <- jumps[2]

gradient <- c(
  1 / first_stage,
  -reduced_form / first_stage^2
)

treatment_effect <- reduced_form / first_stage
treatment_var <- drop(t(gradient) %*% joint %*% gradient)

n_obs <- nrow(dat)

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(
      term = "treatment_effect",
      estimate = unname(as.numeric(treatment_effect)),
      se = unname(as.numeric(sqrt(treatment_var))),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "reduced_form",
      estimate = unname(as.numeric(reduced_form)),
      se = unname(as.numeric(sqrt(joint[1, 1]))),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "first_stage",
      estimate = unname(as.numeric(first_stage)),
      se = unname(as.numeric(sqrt(joint[2, 2]))),
      n_obs = as.integer(n_obs)
    )
  ),
  method_metadata = list(
    estimator = "triangular-weighted local-linear fuzzy regression discontinuity",
    vcov = "conventional heteroskedasticity-robust HC0 with joint delta method"
  ),
  diagnostics = list()
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
