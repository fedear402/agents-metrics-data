#!/usr/bin/env Rscript

library(jsonlite)

d <- read.csv("input.csv", stringsAsFactors = FALSE)

region_cols <- c("region_id", "region_weight", "x", "y")
regions <- d[!duplicated(d$region_id), region_cols]
regions <- regions[match(unique(d$region_id), regions$region_id), ]

e <- regions$region_weight / sum(regions$region_weight)
region_index <- match(d$region_id, regions$region_id)

industries <- unique(d$industry_id)
industry_info <- d[!duplicated(d$industry_id), c("industry_id", "shock")]
industry_info <- industry_info[match(industries, industry_info$industry_id), ]

z <- tapply(d$share * d$shock, d$region_id, sum)
z <- as.numeric(z[match(regions$region_id, names(z))])

weighted_mean <- function(v, w) {
  sum(w * v)
}

y0 <- regions$y - weighted_mean(regions$y, e)
x0 <- regions$x - weighted_mean(regions$x, e)
z0 <- z - weighted_mean(z, e)

d$e <- e[region_index]
d$x0 <- x0[region_index]
d$y0 <- y0[region_index]
d$z0 <- z0[region_index]

s <- tapply(d$e * d$share, d$industry_id, sum)
s <- as.numeric(s[match(industries, names(s))])

keep <- is.finite(s) & s > 0
industries_used <- industries[keep]
s <- s[keep]

aggregate_residual <- function(v0) {
  numerator <- tapply(d$e * d$share * v0, d$industry_id, sum)
  as.numeric(numerator[match(industries_used, names(numerator))]) / s
}

ybar <- aggregate_residual(d$y0)
xbar <- aggregate_residual(d$x0)
zbar <- aggregate_residual(d$z0)
shock <- industry_info$shock[match(industries_used, industry_info$industry_id)]

shock_iv <- function(dependent, endogenous, instrument, weights) {
  regressors <- cbind(1, endogenous)
  instruments <- cbind(1, instrument)

  cross <- crossprod(instruments, weights * regressors)
  beta <- solve(cross, crossprod(instruments, weights * dependent))

  residual <- drop(dependent - regressors %*% beta)
  scores <- instruments * (weights * residual)
  inverse <- solve(cross)

  n <- length(weights)
  covariance <- (n / (n - 2)) *
    inverse %*% crossprod(scores) %*% t(inverse)

  c(estimate = beta[2], se = sqrt(covariance[2, 2]))
}

effect_fit <- shock_iv(ybar, xbar, shock, s)
first_stage_fit <- shock_iv(xbar, zbar, shock, s)

n_industries <- length(industries_used)
effective_shocks <- 1 / sum(s^2)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(
      term = "effect",
      estimate = unname(effect_fit["estimate"]),
      se = unname(effect_fit["se"]),
      n_obs = as.integer(n_industries)
    ),
    list(
      term = "first_stage",
      estimate = unname(first_stage_fit["estimate"]),
      se = unname(first_stage_fit["se"]),
      n_obs = as.integer(n_industries)
    ),
    list(
      term = "effective_shocks",
      estimate = effective_shocks,
      se = NULL,
      n_obs = as.integer(n_industries)
    )
  ),
  method_metadata = list(
    estimator = "Weighted regional 2SLS with Borusyak-Hull-Jaravel shock-level aggregation",
    vcov = "Shock-level HC1 with N/(N-2) multiplier and structural IV residuals"
  ),
  diagnostics = list()
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
