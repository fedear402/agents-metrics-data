library(jsonlite)

dat <- read.csv("input.csv")

keep <- abs(dat$score) < 1
dat <- dat[keep, , drop = FALSE]

score <- dat$score
right <- as.numeric(score >= 0)
weights <- 1 - abs(score)

X <- cbind(
  intercept = 1,
  score = score,
  right = right,
  right_score = right * score
)

Y <- cbind(
  earnings = dat$earnings,
  participated = dat$participated
)

bread <- solve(crossprod(X, weights * X))
coefficients <- bread %*% crossprod(X, weights * Y)
residuals <- Y - X %*% coefficients

contrast <- c(0, 0, 1, 0)
discontinuities <- drop(t(contrast) %*% coefficients)

joint_covariance <- matrix(0, 2, 2)

for (j in seq_len(2)) {
  for (k in seq_len(2)) {
    score_residuals <- weights^2 * residuals[, j] * residuals[, k]
    meat <- crossprod(X, score_residuals * X)
    covariance <- bread %*% meat %*% bread
    joint_covariance[j, k] <-
      drop(t(contrast) %*% covariance %*% contrast)
  }
}

gradient <- c(
  1 / discontinuities[2],
  -discontinuities[1] / discontinuities[2]^2
)

treatment_effect <- discontinuities[1] / discontinuities[2]
treatment_effect_se <- sqrt(
  drop(t(gradient) %*% joint_covariance %*% gradient)
)

n_obs <- nrow(dat)

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(
      term = "treatment_effect",
      estimate = unname(as.numeric(treatment_effect)),
      se = unname(as.numeric(treatment_effect_se)),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "reduced_form",
      estimate = unname(as.numeric(discontinuities[1])),
      se = unname(as.numeric(sqrt(joint_covariance[1, 1]))),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "first_stage",
      estimate = unname(as.numeric(discontinuities[2])),
      se = unname(as.numeric(sqrt(joint_covariance[2, 2]))),
      n_obs = as.integer(n_obs)
    )
  ),
  method_metadata = list(
    estimator = "weighted local-linear fuzzy regression discontinuity",
    vcov = "conventional heteroskedasticity-robust HC0"
  ),
  diagnostics = list()
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
