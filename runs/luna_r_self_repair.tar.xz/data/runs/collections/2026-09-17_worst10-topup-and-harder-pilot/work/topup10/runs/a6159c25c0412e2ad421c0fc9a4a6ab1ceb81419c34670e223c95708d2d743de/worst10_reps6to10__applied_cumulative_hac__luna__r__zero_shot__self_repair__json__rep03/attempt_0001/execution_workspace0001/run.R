dat <- read.csv("input.csv", stringsAsFactors = FALSE)

dat <- dat[order(as.character(dat$date)), ]

log_sales <- log(dat$sales)
dlog_vix <- c(NA_real_, diff(log(dat$vix)))

n_total <- nrow(dat)
idx <- 17:n_total

y <- log_sales[idx]
X <- cbind(
  intercept = 1,
  lag_1 = dlog_vix[idx - 1],
  lag_2 = dlog_vix[idx - 2],
  lag_3 = dlog_vix[idx - 3],
  lag_4 = dlog_vix[idx - 4],
  lag_5 = dlog_vix[idx - 5],
  lag_6 = dlog_vix[idx - 6],
  lag_7 = dlog_vix[idx - 7],
  lag_8 = dlog_vix[idx - 8],
  lag_9 = dlog_vix[idx - 9],
  lag_10 = dlog_vix[idx - 10],
  lag_11 = dlog_vix[idx - 11],
  lag_12 = dlog_vix[idx - 12],
  lag_13 = dlog_vix[idx - 13],
  lag_14 = dlog_vix[idx - 14],
  lag_15 = dlog_vix[idx - 15]
)

complete <- complete.cases(y, X)
y <- y[complete]
X <- X[complete, , drop = FALSE]

n_obs <- length(y)
k <- ncol(X)
beta <- solve(crossprod(X), crossprod(X, y))
resid <- as.numeric(y - X %*% beta)

S <- matrix(0, k, k)

for (j in 0:15) {
  weight <- 1 - j / 16
  if (j == 0) {
    S <- S + crossprod(X * resid)
  } else {
    left <- X[(j + 1):n_obs, , drop = FALSE] *
      resid[(j + 1):n_obs]
    right <- X[1:(n_obs - j), , drop = FALSE] *
      resid[1:(n_obs - j)]
    cross_term <- crossprod(left, right)
    S <- S + weight * (cross_term + t(cross_term))
  }
}

bread <- solve(crossprod(X))
vcov_nw <- bread %*% S %*% bread
vcov_nw <- vcov_nw * n_obs / (n_obs - 16)

lag_indices <- 2:16
cumulative_estimate <- sum(beta[lag_indices])
cumulative_se <- sqrt(as.numeric(
  rep(0, 1) %*% matrix(0, 1, 1)
))

cumulative_weights <- c(0, rep(1, 15))
cumulative_se <- sqrt(as.numeric(
  t(cumulative_weights) %*% vcov_nw %*% cumulative_weights
))

lag_1_estimate <- beta["lag_1"]
lag_1_se <- sqrt(vcov_nw["lag_1", "lag_1"])

lag_15_estimate <- beta["lag_15"]
lag_15_se <- sqrt(vcov_nw["lag_15", "lag_15"])

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(
      term = "cumulative_response",
      estimate = as.numeric(cumulative_estimate),
      se = as.numeric(cumulative_se),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "lag_1",
      estimate = as.numeric(lag_1_estimate),
      se = as.numeric(lag_1_se),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "lag_15",
      estimate = as.numeric(lag_15_estimate),
      se = as.numeric(lag_15_se),
      n_obs = as.integer(n_obs)
    )
  ),
  method_metadata = list(
    estimator = "OLS with intercept and lags 1 through 15 of first-differenced log VIX",
    vcov = "Newey-West HAC with maximum lag 15, Bartlett weights, multiplied by N/(N-16)"
  ),
  diagnostics = list()
)

if (requireNamespace("jsonlite", quietly = TRUE)) {
  jsonlite::write_json(
    result,
    "result.json",
    auto_unbox = TRUE,
    digits = 17,
    pretty = FALSE,
    null = "null"
  )
} else {
  esc <- function(x) gsub('"', '\\"', x, fixed = TRUE)
  fmt <- function(x) formatC(x, format = "fg", digits = 17, flag = "#")
  lines <- c(
    "{",
    '  "task_id": "applied_cumulative_hac",',
    '  "platform": "r",',
    '  "estimates": [',
    paste0(
      '    {"term": "cumulative_response", "estimate": ',
      fmt(cumulative_estimate),
      ', "se": ',
      fmt(cumulative_se),
      ', "n_obs": ',
      n_obs,
      '},'
    ),
    paste0(
      '    {"term": "lag_1", "estimate": ',
      fmt(lag_1_estimate),
      ', "se": ',
      fmt(lag_1_se),
      ', "n_obs": ',
      n_obs,
      '},'
    ),
    paste0(
      '    {"term": "lag_15", "estimate": ',
      fmt(lag_15_estimate),
      ', "se": ',
      fmt(lag_15_se),
      ', "n_obs": ',
      n_obs,
      '}'
    ),
    "  ],",
    '  "method_metadata": {"estimator": "OLS with intercept and lags 1 through 15 of first-differenced log VIX", "vcov": "Newey-West HAC with maximum lag 15, Bartlett weights, multiplied by N/(N-16)"},',
    '  "diagnostics": {}',
    "}"
  )
  writeLines(lines, "result.json")
}
