#!/usr/bin/env Rscript

dat <- read.csv("input.csv", stringsAsFactors = FALSE)

keep <- is.finite(dat$score) &
  is.finite(dat$participated) &
  is.finite(dat$earnings) &
  abs(dat$score) < 1

d <- dat[keep, , drop = FALSE]
x <- d$score
right <- as.numeric(x >= 0)
w <- 1 - abs(x)

X <- cbind(
  intercept = 1,
  score = x,
  right = right,
  right_score = right * x
)

fit_hc0 <- function(y) {
  sw <- sqrt(w)
  Xw <- X * sw
  yw <- y * sw
  beta <- solve(crossprod(Xw), crossprod(Xw, yw))
  resid <- as.numeric(y - X %*% beta)
  bread <- solve(crossprod(Xw))
  meat <- crossprod(X * (w * resid))
  vcov <- bread %*% meat %*% bread
  list(beta = beta, vcov = vcov, resid = resid)
}

rf <- fit_hc0(d$earnings)
fs <- fit_hc0(d$participated)

rf_est <- unname(rf$beta["right"])
fs_est <- unname(fs$beta["right"])

rf_var <- unname(rf$vcov["right", "right"])
fs_var <- unname(fs$vcov["right", "right"])

joint_cross <- {
  e1 <- rf$resid
  e2 <- fs$resid
  bread <- solve(crossprod(X * sqrt(w)))
  meat_cross <- crossprod(X * (w * e1), X * (w * e2))
  bread %*% meat_cross %*% bread
}

cov_rf_fs <- unname(joint_cross["right", "right"])

te_est <- rf_est / fs_est
te_var <- fs_est^(-2) * rf_var +
  rf_est^2 * fs_est^(-4) * fs_var -
  2 * rf_est * fs_est^(-3) * cov_rf_fs

safe_se <- function(v) {
  if (is.finite(v) && v >= 0) sqrt(v) else NA_real_
}

out <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(
      term = "treatment_effect",
      estimate = unname(te_est),
      se = safe_se(te_var),
      n_obs = nrow(d)
    ),
    list(
      term = "reduced_form",
      estimate = unname(rf_est),
      se = safe_se(rf_var),
      n_obs = nrow(d)
    ),
    list(
      term = "first_stage",
      estimate = unname(fs_est),
      se = safe_se(fs_var),
      n_obs = nrow(d)
    )
  ),
  method_metadata = list(
    estimator = "fuzzy local-linear regression discontinuity with triangular weights",
    vcov = "conventional heteroskedasticity-robust HC0; delta method with joint covariance"
  ),
  diagnostics = list()
)

if (requireNamespace("jsonlite", quietly = TRUE)) {
  jsonlite::write_json(out, "result.json", auto_unbox = TRUE, na = "null")
} else {
  scalar_json <- function(x) {
    if (is.null(x) || length(x) == 0 || !is.finite(x)) "null"
    else format(x, digits = 17, scientific = FALSE, trim = TRUE)
  }

  txt <- paste0(
    "{",
    "\"task_id\":\"applied_fuzzy_rd\",",
    "\"platform\":\"r\",",
    "\"estimates\":[",
    "{\"term\":\"treatment_effect\",\"estimate\":", scalar_json(te_est),
    ",\"se\":", scalar_json(safe_se(te_var)),
    ",\"n_obs\":", nrow(d), "},",
    "{\"term\":\"reduced_form\",\"estimate\":", scalar_json(rf_est),
    ",\"se\":", scalar_json(safe_se(rf_var)),
    ",\"n_obs\":", nrow(d), "},",
    "{\"term\":\"first_stage\",\"estimate\":", scalar_json(fs_est),
    ",\"se\":", scalar_json(safe_se(fs_var)),
    ",\"n_obs\":", nrow(d), "}",
    "],",
    "\"method_metadata\":{",
    "\"estimator\":\"fuzzy local-linear regression discontinuity with triangular weights\",",
    "\"vcov\":\"conventional heteroskedasticity-robust HC0; delta method with joint covariance\"",
    "},",
    "\"diagnostics\":{}",
    "}"
  )
  writeLines(txt, "result.json")
}
