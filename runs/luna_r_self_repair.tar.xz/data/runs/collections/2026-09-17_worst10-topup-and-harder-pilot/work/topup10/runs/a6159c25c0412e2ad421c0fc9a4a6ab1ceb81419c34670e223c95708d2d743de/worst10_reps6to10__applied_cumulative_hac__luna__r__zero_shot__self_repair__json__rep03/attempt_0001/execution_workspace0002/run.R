dat <- read.csv("input.csv", stringsAsFactors = FALSE)

date_parsed <- as.Date(dat$date)
if (all(is.na(date_parsed))) {
  date_order <- order(dat$date)
} else {
  date_order <- order(date_parsed)
}
dat <- dat[date_order, , drop = FALSE]

log_sales <- log(as.numeric(dat$sales))
dlog_vix <- c(NA_real_, diff(log(as.numeric(dat$vix))))

n_total <- nrow(dat)
if (n_total < 17L) stop("Insufficient observations")

idx <- 17L:n_total
y_all <- log_sales[idx]

X_all <- cbind(
  intercept = 1,
  lag_1 = dlog_vix[idx - 1L],
  lag_2 = dlog_vix[idx - 2L],
  lag_3 = dlog_vix[idx - 3L],
  lag_4 = dlog_vix[idx - 4L],
  lag_5 = dlog_vix[idx - 5L],
  lag_6 = dlog_vix[idx - 6L],
  lag_7 = dlog_vix[idx - 7L],
  lag_8 = dlog_vix[idx - 8L],
  lag_9 = dlog_vix[idx - 9L],
  lag_10 = dlog_vix[idx - 10L],
  lag_11 = dlog_vix[idx - 11L],
  lag_12 = dlog_vix[idx - 12L],
  lag_13 = dlog_vix[idx - 13L],
  lag_14 = dlog_vix[idx - 14L],
  lag_15 = dlog_vix[idx - 15L]
)

keep <- is.finite(y_all) & apply(X_all, 1L, function(z) all(is.finite(z)))
y <- as.numeric(y_all[keep])
X <- X_all[keep, , drop = FALSE]

n_obs <- length(y)
if (n_obs <= 16L) stop("Insufficient complete observations")

fit <- lm.fit(x = X, y = y)
beta <- as.numeric(fit$coefficients)
names(beta) <- colnames(X)

if (any(!is.finite(beta))) {
  beta <- as.numeric(qr.solve(X, y))
  names(beta) <- colnames(X)
}

resid <- as.numeric(y - X %*% beta)
k <- ncol(X)

S <- matrix(0, nrow = k, ncol = k)
S <- S + crossprod(X * resid)

for (j in 1:15) {
  w <- 1 - j / 16
  left <- X[(j + 1):n_obs, , drop = FALSE] * resid[(j + 1):n_obs]
  right <- X[1:(n_obs - j), , drop = FALSE] * resid[1:(n_obs - j)]
  cross_term <- crossprod(left, right)
  S <- S + w * (cross_term + t(cross_term))
}

XtX_inv <- qr.solve(crossprod(X))
vcov_nw <- XtX_inv %*% S %*% XtX_inv
vcov_nw <- vcov_nw * n_obs / (n_obs - 16)

lag_weights <- c(0, rep(1, 15))
cumulative_estimate <- sum(beta[2:16])
cumulative_se <- sqrt(as.numeric(t(lag_weights) %*% vcov_nw %*% lag_weights))

lag_1_estimate <- beta[2]
lag_1_se <- sqrt(vcov_nw[2, 2])

lag_15_estimate <- beta[16]
lag_15_se <- sqrt(vcov_nw[16, 16])

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(
      term = "cumulative_response",
      estimate = as.numeric(cumulative_estimate),
      se = as.numeric(cumulative_se),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "lag_1",
      estimate = as.numeric(lag_1_estimate),
      se = as.numeric(lag_1_se),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "lag_15",
      estimate = as.numeric(lag_15_estimate),
      se = as.numeric(lag_15_se),
      n_obs = as.integer(n_obs)
    )
  ),
  method_metadata = list(
    estimator = "OLS with intercept and lags 1 through 15 of first-differenced log VIX",
    vcov = "Newey-West HAC with maximum lag 15, Bartlett weights, multiplied by N/(N-16)"
  ),
  diagnostics = list()
)

if (requireNamespace("jsonlite", quietly = TRUE)) {
  jsonlite::write_json(
    result,
    "result.json",
    auto_unbox = TRUE,
    digits = 17,
    pretty = FALSE,
    null = "null"
  )
} else {
  fmt <- function(x) formatC(as.numeric(x), format = "fg", digits = 17, flag = "#")
  lines <- c(
    "{",
    '  "task_id": "applied_cumulative_hac",',
    '  "platform": "r",',
    '  "estimates": [',
    paste0('    {"term": "cumulative_response", "estimate": ', fmt(cumulative_estimate),
           ', "se": ', fmt(cumulative_se), ', "n_obs": ', n_obs, '},'),
    paste0('    {"term": "lag_1", "estimate": ', fmt(lag_1_estimate),
           ', "se": ', fmt(lag_1_se), ', "n_obs": ', n_obs, '},'),
    paste0('    {"term": "lag_15", "estimate": ', fmt(lag_15_estimate),
           ', "se": ', fmt(lag_15_se), ', "n_obs": ', n_obs, '}'),
    "  ],",
    '  "method_metadata": {"estimator": "OLS with intercept and lags 1 through 15 of first-differenced log VIX", "vcov": "Newey-West HAC with maximum lag 15, Bartlett weights, multiplied by N/(N-16)"},',
    '  "diagnostics": {}',
    "}"
  )
  writeLines(lines, "result.json")
}
