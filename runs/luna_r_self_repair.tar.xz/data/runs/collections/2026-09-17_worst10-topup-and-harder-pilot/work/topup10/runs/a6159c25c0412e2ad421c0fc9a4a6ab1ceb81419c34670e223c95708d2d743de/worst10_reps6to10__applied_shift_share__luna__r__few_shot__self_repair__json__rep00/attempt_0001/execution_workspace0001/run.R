library(jsonlite)

dat <- read.csv("input.csv", stringsAsFactors = FALSE)

region_id <- unique(dat$region_id)
industry_id <- unique(dat$industry_id)

region_data <- do.call(rbind, lapply(region_id, function(r) {
  d <- dat[dat$region_id == r, ]
  shares <- tapply(d$share, d$industry_id, sum)
  shocks <- tapply(d$shock, d$industry_id, unique)

  data.frame(
    region_id = r,
    region_weight = unique(d$region_weight)[1],
    x = unique(d$x)[1],
    y = unique(d$y)[1],
    z = sum(shares * shocks),
    stringsAsFactors = FALSE
  )
}))

e <- region_data$region_weight / sum(region_data$region_weight)

weighted_mean <- function(v, w) {
  sum(w * v)
}

y0 <- region_data$y - weighted_mean(region_data$y, e)
x0 <- region_data$x - weighted_mean(region_data$x, e)
z0 <- region_data$z - weighted_mean(region_data$z, e)

share_matrix <- matrix(
  0,
  nrow = nrow(region_data),
  ncol = length(industry_id),
  dimnames = list(region_data$region_id, industry_id)
)

for (i in seq_len(nrow(dat))) {
  r <- match(dat$region_id[i], region_data$region_id)
  n <- match(dat$industry_id[i], industry_id)
  share_matrix[r, n] <- share_matrix[r, n] + dat$share[i]
}

shock_by_industry <- sapply(industry_id, function(n) {
  unique(dat$shock[dat$industry_id == n])[1]
})

s <- drop(crossprod(e, share_matrix))

keep <- s > 0
s <- s[keep]
shock_by_industry <- shock_by_industry[keep]
share_matrix <- share_matrix[, keep, drop = FALSE]

aggregate_residual <- function(v0) {
  drop(crossprod(e * v0, share_matrix)) / s
}

ybar <- aggregate_residual(y0)
xbar <- aggregate_residual(x0)
zbar <- aggregate_residual(z0)

shock_iv <- function(dependent, endogenous) {
  X <- cbind(1, endogenous)
  Z <- cbind(1, shock_by_industry)
  W <- s

  cross <- crossprod(Z, W * X)
  beta <- solve(cross, crossprod(Z, W * dependent))

  residual <- drop(dependent - X %*% beta)
  scores <- Z * (W * residual)
  inverse <- solve(cross)

  n_industries <- length(W)
  covariance <- n_industries / (n_industries - 2) *
    inverse %*% crossprod(scores) %*% t(inverse)

  c(
    estimate = beta[2],
    se = sqrt(covariance[2, 2])
  )
}

effect <- shock_iv(ybar, xbar)
first_stage <- shock_iv(xbar, zbar)
effective_shocks <- 1 / sum(s^2)
n_industries <- length(s)

row <- function(term, estimate, se = NULL, n_obs) {
  list(
    term = term,
    estimate = unname(as.numeric(estimate)),
    se = if (is.null(se)) NULL else unname(as.numeric(se)),
    n_obs = as.integer(n_obs)
  )
}

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    row("effect", effect["estimate"], effect["se"], n_industries),
    row("first_stage", first_stage["estimate"], first_stage["se"], n_industries),
    row("effective_shocks", effective_shocks, NULL, n_industries)
  ),
  method_metadata = list(
    estimator = "weighted shock-level IV with intercept",
    vcov = "shock-level HC1 with N/(N-2) multiplier"
  ),
  diagnostics = list()
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
