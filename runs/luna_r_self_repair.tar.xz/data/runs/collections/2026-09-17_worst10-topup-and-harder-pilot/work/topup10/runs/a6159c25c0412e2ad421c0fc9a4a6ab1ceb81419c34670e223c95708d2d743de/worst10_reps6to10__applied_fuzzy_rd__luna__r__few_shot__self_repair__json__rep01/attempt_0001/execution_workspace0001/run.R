library(jsonlite)

dat <- read.csv("input.csv")

keep <- abs(dat$score) < 1
dat <- dat[keep, , drop = FALSE]

right <- as.numeric(dat$score >= 0)
x <- cbind(
  1,
  right,
  dat$score,
  right * dat$score
)
w <- 1 - abs(dat$score)

y <- cbind(
  earnings = dat$earnings,
  participated = dat$participated
)

xwx <- crossprod(x, w * x)
bread <- solve(xwx)
beta <- bread %*% crossprod(x, w * y)
resid <- y - x %*% beta

meat <- matrix(0, nrow = 8, ncol = 8)
for (i in seq_len(nrow(x))) {
  xi <- x[i, , drop = FALSE]
  ri <- matrix(resid[i, ], nrow = 2)
  meat <- meat + (w[i]^2) * kronecker(t(ri) %*% ri, xi %*% t(xi))
}

joint_beta <- meat
joint_beta <- matrix(0, nrow = 4 * 2, ncol = 4 * 2)

for (a in seq_len(2)) {
  for (b in seq_len(2)) {
    block <- matrix(0, nrow = 4, ncol = 4)
    for (i in seq_len(nrow(x))) {
      xi <- x[i, ]
      block <- block +
        (w[i]^2) *
        resid[i, a] *
        resid[i, b] *
        tcrossprod(xi)
    }
    block <- bread %*% block %*% bread
    rows <- ((a - 1) * 4 + 1):(a * 4)
    cols <- ((b - 1) * 4 + 1):(b * 4)
    joint_beta[rows, cols] <- block
  }
}

reduced_form <- unname(beta[2, 1])
first_stage <- unname(beta[2, 2])

rf_var <- joint_beta[2, 2]
fs_var <- joint_beta[6, 6]
rf_fs_cov <- joint_beta[2, 6]

rf_se <- sqrt(rf_var)
fs_se <- sqrt(fs_var)

gradient <- c(1 / first_stage, -reduced_form / first_stage^2)
disc_cov <- matrix(
  c(rf_var, rf_fs_cov, rf_fs_cov, fs_var),
  nrow = 2,
  byrow = TRUE
)
treatment_effect <- reduced_form / first_stage
treatment_var <- drop(t(gradient) %*% disc_cov %*% gradient)
treatment_se <- sqrt(treatment_var)

n_obs <- nrow(dat)

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(
      term = "treatment_effect",
      estimate = unname(as.numeric(treatment_effect)),
      se = unname(as.numeric(treatment_se)),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "reduced_form",
      estimate = unname(as.numeric(reduced_form)),
      se = unname(as.numeric(rf_se)),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "first_stage",
      estimate = unname(as.numeric(first_stage)),
      se = unname(as.numeric(fs_se)),
      n_obs = as.integer(n_obs)
    )
  ),
  method_metadata = list(
    estimator = "Weighted local-linear fuzzy regression discontinuity",
    vcov = "HC0 with triangular fixed weights and delta method"
  ),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, digits = 16, pretty = TRUE)
