dat <- read.csv("input.csv", stringsAsFactors = FALSE)

dat$date_order <- as.Date(dat$date)
dat <- dat[order(dat$date_order), ]

log_sales <- log(dat$sales)
log_vix <- log(dat$vix)
dvix <- c(NA_real_, diff(log_vix))

n_total <- nrow(dat)
lagged <- sapply(1:15, function(k) {
  c(rep(NA_real_, k), dvix[1:(n_total - k)])
})
colnames(lagged) <- paste0("lag_", 1:15)

model_data <- data.frame(
  y = log_sales,
  lagged,
  check.names = FALSE
)
model_data <- model_data[complete.cases(model_data), ]

y <- model_data$y
X <- cbind("(Intercept)" = 1, as.matrix(model_data[, paste0("lag_", 1:15)]))
N <- nrow(X)
K <- ncol(X)

fit <- lm.fit(x = X, y = y)
beta <- as.numeric(fit$coefficients)
resid <- as.numeric(fit$residuals)

bread <- solve(crossprod(X))
S <- crossprod(X * resid)

if (N >= 2) {
  for (j in 1:min(15, N - 1)) {
    w <- 1 - j / 16
    Z_t <- X[(j + 1):N, , drop = FALSE] * resid[(j + 1):N]
    Z_lag <- X[1:(N - j), , drop = FALSE] * resid[1:(N - j)]
    gamma_j <- crossprod(Z_t, Z_lag)
    S <- S + w * (gamma_j + t(gamma_j))
  }
}

vcov_hac <- bread %*% S %*% bread
vcov_hac <- vcov_hac * N / (N - 16)

cumulative_weights <- c(0, rep(1, 15))
cumulative_estimate <- sum(beta[2:16])
cumulative_se <- sqrt(as.numeric(
  t(cumulative_weights) %*% vcov_hac %*% cumulative_weights
))

lag1_estimate <- beta[2]
lag1_se <- sqrt(vcov_hac[2, 2])

lag15_estimate <- beta[16]
lag15_se <- sqrt(vcov_hac[16, 16])

fmt <- function(x) {
  if (is.na(x) || is.nan(x) || is.infinite(x)) "null" else formatC(x, format = "fg", digits = 15)
}

json <- paste0(
  "{\n",
  '  "task_id": "applied_cumulative_hac",', "\n",
  '  "platform": "r",', "\n",
  '  "estimates": [', "\n",
  '    {"term": "cumulative_response", "estimate": ', fmt(cumulative_estimate),
  ', "se": ', fmt(cumulative_se), ', "n_obs": ', N, "},\n",
  '    {"term": "lag_1", "estimate": ', fmt(lag1_estimate),
  ', "se": ', fmt(lag1_se), ', "n_obs": ', N, "},\n",
  '    {"term": "lag_15", "estimate": ', fmt(lag15_estimate),
  ', "se": ', fmt(lag15_se), ', "n_obs": ', N, "}", "\n",
  "  ],\n",
  '  "method_metadata": {"estimator": "OLS with lags 1 through 15 of first-differenced log volatility", "vcov": "Newey-West HAC, maximum lag 15, Bartlett weights, scaled by N/(N-16)"}', "\n",
  '  ,"diagnostics": {}', "\n",
  "}\n"
)

writeLines(json, "result.json")
