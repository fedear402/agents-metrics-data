dat <- read.csv("input.csv", stringsAsFactors = FALSE)
dat$date <- as.Date(dat$date)
dat <- dat[order(dat$date), ]

log_sales <- log(dat$sales)
log_vix <- log(dat$vix)
vix_change <- c(NA_real_, diff(log_vix))

n <- nrow(dat)
idx <- 17:n
y <- log_sales[idx]

X <- cbind(
  intercept = 1,
  sapply(1:15, function(k) vix_change[idx - k])
)
X <- as.matrix(X)
colnames(X) <- c("intercept", paste0("lag_", 1:15))

valid <- complete.cases(y, X)
y <- y[valid]
X <- X[valid, , drop = FALSE]

fit <- lm.fit(x = X, y = y)
beta <- as.numeric(fit$coefficients)
names(beta) <- colnames(X)

u <- as.numeric(fit$residuals)
N <- nrow(X)
K <- ncol(X)

bread <- solve(crossprod(X))
meat <- crossprod(X * u)

max_lag <- 15
for (j in 1:max_lag) {
  w <- 1 - j / 16
  Xt <- X[(j + 1):N, , drop = FALSE]
  Xl <- X[1:(N - j), , drop = FALSE]
  ut <- u[(j + 1):N]
  ul <- u[1:(N - j)]
  gamma_j <- crossprod(Xt * ut, Xl * ul)
  meat <- meat + w * (gamma_j + t(gamma_j))
}

vcov_nw <- bread %*% meat %*% bread
vcov_nw <- vcov_nw * N / (N - 16)

cum_weights <- c(0, rep(1, 15))
cum_estimate <- sum(beta[2:16])
cum_se <- sqrt(as.numeric(t(cum_weights) %*% vcov_nw %*% cum_weights))

lag1_se <- sqrt(vcov_nw[2, 2])
lag15_se <- sqrt(vcov_nw[16, 16])

fmt <- function(x) {
  formatC(x, format = "fg", digits = 15, flag = "#")
}

json <- paste0(
  "{\n",
  '  "task_id": "applied_cumulative_hac",\n',
  '  "platform": "r",\n',
  '  "estimates": [\n',
  '    {"term": "cumulative_response", "estimate": ', fmt(cum_estimate),
  ', "se": ', fmt(cum_se), ', "n_obs": ', N, '},\n',
  '    {"term": "lag_1", "estimate": ', fmt(beta["lag_1"]),
  ', "se": ', fmt(lag1_se), ', "n_obs": ', N, '},\n',
  '    {"term": "lag_15", "estimate": ', fmt(beta["lag_15"]),
  ', "se": ', fmt(lag15_se), ', "n_obs": ', N, '}\n',
  "  ],\n",
  '  "method_metadata": {"estimator": "OLS with 15 trading-observation lags", ',
  '"vcov": "Newey-West HAC, Bartlett weights, maximum lag 15, scaled by N/(N-16)"},\n',
  '  "diagnostics": {}\n',
  "}\n"
)

writeLines(json, "result.json")
