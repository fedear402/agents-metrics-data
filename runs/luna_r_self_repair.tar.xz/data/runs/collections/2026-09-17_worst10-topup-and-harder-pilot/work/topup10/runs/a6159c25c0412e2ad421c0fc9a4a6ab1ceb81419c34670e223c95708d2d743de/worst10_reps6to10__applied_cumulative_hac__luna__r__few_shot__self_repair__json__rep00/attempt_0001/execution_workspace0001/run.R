library(jsonlite)

data <- read.csv("input.csv", stringsAsFactors = FALSE)
data$date <- as.Date(data$date)
data <- data[order(data$date), ]

data$log_vix <- log(data$vix)
data$vol_change <- c(NA, diff(data$log_vix))
data$log_sales <- log(data$sales)

for (j in 1:15) {
  data[[paste0("lag_", j)]] <- c(
    rep(NA, j + 1),
    head(data$vol_change, -j - 1)
  )
}

regressors <- paste0("lag_", 1:15)
sample <- data[complete.cases(data[, c("log_sales", regressors)]), ]

fit <- lm(
  as.formula(
    paste("log_sales ~", paste(regressors, collapse = " + "))
  ),
  data = sample
)

X <- model.matrix(fit)
u <- residuals(fit)
N <- nrow(X)
p <- ncol(X)
scores <- X * u

hac_lags <- 15
meat <- crossprod(scores)

for (j in 1:hac_lags) {
  lag_product <- crossprod(
    scores[(j + 1):N, , drop = FALSE],
    scores[1:(N - j), , drop = FALSE]
  )
  weight <- 1 - j / 16
  meat <- meat + weight * (lag_product + t(lag_product))
}

bread <- solve(crossprod(X))
covariance <- (N / (N - 16)) * bread %*% meat %*% bread

coefficients <- coef(fit)
lag_positions <- match(regressors, colnames(X))
contrast <- numeric(length(coefficients))
contrast[lag_positions] <- 1

cumulative_response <- sum(coefficients[lag_positions])
cumulative_se <- sqrt(drop(t(contrast) %*% covariance %*% contrast))

lag_1_position <- match("lag_1", colnames(X))
lag_15_position <- match("lag_15", colnames(X))

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(
      term = "cumulative_response",
      estimate = unname(as.numeric(cumulative_response)),
      se = unname(as.numeric(cumulative_se)),
      n_obs = as.integer(N)
    ),
    list(
      term = "lag_1",
      estimate = unname(as.numeric(coefficients[lag_1_position])),
      se = unname(as.numeric(sqrt(covariance[lag_1_position, lag_1_position]))),
      n_obs = as.integer(N)
    ),
    list(
      term = "lag_15",
      estimate = unname(as.numeric(coefficients[lag_15_position])),
      se = unname(as.numeric(sqrt(covariance[lag_15_position, lag_15_position]))),
      n_obs = as.integer(N)
    )
  ),
  method_metadata = list(
    estimator = "OLS with intercept and fifteen lagged log-volatility changes",
    vcov = "Bartlett Newey-West HAC, maximum lag 15, correction N/(N-16)"
  ),
  diagnostics = list()
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
