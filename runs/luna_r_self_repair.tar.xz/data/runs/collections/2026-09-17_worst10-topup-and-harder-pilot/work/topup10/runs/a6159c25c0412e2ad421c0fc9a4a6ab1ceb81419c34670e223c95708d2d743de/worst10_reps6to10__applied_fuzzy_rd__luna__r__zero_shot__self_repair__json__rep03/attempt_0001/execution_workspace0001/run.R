#!/usr/bin/env Rscript

dat <- read.csv("input.csv", stringsAsFactors = FALSE)

keep <- is.finite(dat$score) &
  is.finite(dat$participated) &
  is.finite(dat$earnings) &
  abs(dat$score) < 1

d <- dat[keep, ]
n_obs <- nrow(d)

x <- d$score
right <- as.numeric(x >= 0)
w <- 1 - abs(x)

X <- cbind(
  intercept = 1,
  right = right,
  score = x,
  right_score = right * x
)

fit_wls <- function(y) {
  XtWX <- crossprod(X, w * X)
  XtWy <- crossprod(X, w * y)
  beta <- solve(XtWX, XtWy)
  residuals <- as.vector(y - X %*% beta)

  bread <- solve(XtWX)
  meat <- matrix(0, ncol = ncol(X), nrow = ncol(X))

  for (i in seq_len(nrow(X))) {
    xi <- matrix(X[i, ], ncol = 1)
    meat <- meat + (w[i]^2) * residuals[i]^2 * (xi %*% t(xi))
  }

  vcov <- bread %*% meat %*% bread

  list(
    beta = as.vector(beta),
    vcov = vcov,
    residuals = residuals
  )
}

fit_y <- fit_wls(d$earnings)
fit_d <- fit_wls(d$participated)

reduced_form <- fit_y$beta[2]
first_stage <- fit_d$beta[2]

var_rf <- fit_y$vcov[2, 2]
var_fs <- fit_d$vcov[2, 2]

cross_meat <- matrix(0, ncol = ncol(X), nrow = ncol(X))

for (i in seq_len(nrow(X))) {
  xi <- matrix(X[i, ], ncol = 1)
  cross_meat <- cross_meat +
    (w[i]^2) *
    fit_y$residuals[i] *
    fit_d$residuals[i] *
    (xi %*% t(xi))
}

bread <- solve(crossprod(X, w * X))
cov_y_d <- bread %*% cross_meat %*% bread

cov_rf_fs <- cov_y_d[2, 2]

se_reduced_form <- sqrt(max(0, var_rf))
se_first_stage <- sqrt(max(0, var_fs))

treatment_effect <- reduced_form / first_stage

gradient <- c(
  1 / first_stage,
  -reduced_form / first_stage^2
)

joint_cov <- matrix(
  c(var_rf, cov_rf_fs, cov_rf_fs, var_fs),
  nrow = 2,
  byrow = TRUE
)

var_treatment_effect <- as.numeric(
  t(gradient) %*% joint_cov %*% gradient
)

se_treatment_effect <- sqrt(max(0, var_treatment_effect))

fmt <- function(x) {
  if (!is.finite(x)) "null" else formatC(x, digits = 15, format = "fg", flag = "#")
}

result_json <- paste0(
  "{\n",
  '  "task_id": "applied_fuzzy_rd",', "\n",
  '  "platform": "r",', "\n",
  '  "estimates": [', "\n",
  '    {"term": "treatment_effect", "estimate": ', fmt(treatment_effect),
  ', "se": ', fmt(se_treatment_effect),
  ', "n_obs": ', n_obs, '},', "\n",
  '    {"term": "reduced_form", "estimate": ', fmt(reduced_form),
  ', "se": ', fmt(se_reduced_form),
  ', "n_obs": ', n_obs, '},', "\n",
  '    {"term": "first_stage", "estimate": ', fmt(first_stage),
  ', "se": ', fmt(se_first_stage),
  ', "n_obs": ', n_obs, '}', "\n",
  "  ],\n",
  '  "method_metadata": {',
  '"estimator": "fuzzy local-linear regression discontinuity with triangular weights", ',
  '"vcov": "heteroskedasticity-robust HC0 with delta-method treatment-effect standard error"',
  "},\n",
  '  "diagnostics": {}', "\n",
  "}\n"
)

writeLines(result_json, "result.json")
