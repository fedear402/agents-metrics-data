#!/usr/bin/env Rscript

dat <- read.csv("input.csv", stringsAsFactors = FALSE)

keep <- is.finite(dat$score) &
  is.finite(dat$participated) &
  is.finite(dat$earnings) &
  abs(dat$score) < 1

d <- dat[keep, , drop = FALSE]
x <- as.numeric(d$score)
z <- as.numeric(x >= 0)
w <- 1 - abs(x)

X <- cbind(
  intercept = 1,
  score = x,
  right = z,
  right_score = z * x
)

bread <- solve(crossprod(X * sqrt(w)))

fit_hc0 <- function(y) {
  y <- as.numeric(y)
  beta <- drop(bread %*% crossprod(X * w, y))
  fitted <- drop(X %*% beta)
  resid <- y - fitted

  Xw_resid <- X * as.numeric(w * resid)
  meat <- crossprod(Xw_resid)
  vcov <- bread %*% meat %*% bread

  list(beta = beta, vcov = vcov, resid = resid)
}

rf <- fit_hc0(d$earnings)
fs <- fit_hc0(d$participated)

rf_est <- as.numeric(rf$beta[3])
fs_est <- as.numeric(fs$beta[3])
rf_var <- as.numeric(rf$vcov[3, 3])
fs_var <- as.numeric(fs$vcov[3, 3])

cross_meat <- crossprod(
  X * as.numeric(w * rf$resid),
  X * as.numeric(w * fs$resid)
)

cross_vcov <- bread %*% cross_meat %*% bread
cov_rf_fs <- as.numeric(cross_vcov[3, 3])

te_est <- rf_est / fs_est
te_var <- rf_var / fs_est^2 +
  rf_est^2 * fs_var / fs_est^4 -
  2 * rf_est * cov_rf_fs / fs_est^3

safe_value <- function(x) {
  x <- as.numeric(x)
  if (length(x) != 1L || !is.finite(x)) NA_real_ else x
}

safe_se <- function(v) {
  v <- safe_value(v)
  if (is.na(v) || v < 0) NA_real_ else sqrt(v)
}

out <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(
      term = "treatment_effect",
      estimate = safe_value(te_est),
      se = safe_se(te_var),
      n_obs = as.integer(nrow(d))
    ),
    list(
      term = "reduced_form",
      estimate = safe_value(rf_est),
      se = safe_se(rf_var),
      n_obs = as.integer(nrow(d))
    ),
    list(
      term = "first_stage",
      estimate = safe_value(fs_est),
      se = safe_se(fs_var),
      n_obs = as.integer(nrow(d))
    )
  ),
  method_metadata = list(
    estimator = "fuzzy local-linear regression discontinuity with triangular weights",
    vcov = "conventional heteroskedasticity-robust HC0; delta method with joint covariance"
  ),
  diagnostics = list()
)

if (requireNamespace("jsonlite", quietly = TRUE)) {
  jsonlite::write_json(
    out,
    "result.json",
    auto_unbox = TRUE,
    na = "null",
    digits = 17
  )
} else {
  scalar_json <- function(x) {
    x <- safe_value(x)
    if (is.na(x)) {
      "null"
    } else {
      format(x, digits = 17, scientific = FALSE, trim = TRUE)
    }
  }

  txt <- paste0(
    "{",
    "\"task_id\":\"applied_fuzzy_rd\",",
    "\"platform\":\"r\",",
    "\"estimates\":[",
    "{\"term\":\"treatment_effect\",\"estimate\":",
    scalar_json(te_est),
    ",\"se\":", scalar_json(safe_se(te_var)),
    ",\"n_obs\":", nrow(d), "},",
    "{\"term\":\"reduced_form\",\"estimate\":",
    scalar_json(rf_est),
    ",\"se\":", scalar_json(safe_se(rf_var)),
    ",\"n_obs\":", nrow(d), "},",
    "{\"term\":\"first_stage\",\"estimate\":",
    scalar_json(fs_est),
    ",\"se\":", scalar_json(safe_se(fs_var)),
    ",\"n_obs\":", nrow(d), "}",
    "],",
    "\"method_metadata\":{",
    "\"estimator\":\"fuzzy local-linear regression discontinuity with triangular weights\",",
    "\"vcov\":\"conventional heteroskedasticity-robust HC0; delta method with joint covariance\"",
    "},",
    "\"diagnostics\":{}",
    "}"
  )

  writeLines(txt, "result.json")
}
