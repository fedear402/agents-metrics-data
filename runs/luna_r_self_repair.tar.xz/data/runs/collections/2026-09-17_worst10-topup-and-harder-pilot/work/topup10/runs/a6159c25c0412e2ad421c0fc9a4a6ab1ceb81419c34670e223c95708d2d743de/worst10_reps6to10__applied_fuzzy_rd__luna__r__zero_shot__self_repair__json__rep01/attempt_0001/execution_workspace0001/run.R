dat <- read.csv("input.csv")

dat <- dat[abs(dat$score) < 1, ]
dat$weight <- 1 - abs(dat$score)

fit_side <- function(d) {
  X <- cbind(1, d$score)
  W <- d$weight
  A <- crossprod(X, W * X)
  Ainv <- solve(A)

  Y <- cbind(d$earnings, d$participated)
  B <- crossprod(X, W * Y)
  beta <- Ainv %*% B

  residuals <- Y - X %*% beta
  meat <- matrix(0, nrow = 4, ncol = 4)

  for (i in seq_len(nrow(X))) {
    xi <- X[i, , drop = FALSE]
    ri <- residuals[i, , drop = FALSE]
    score_vec <- as.vector(W[i] * t(xi) %*% ri)
    meat <- meat + tcrossprod(score_vec)
  }

  V <- kronecker(diag(2), Ainv) %*% meat %*% kronecker(diag(2), Ainv)

  list(
    beta = beta,
    vcov = V
  )
}

left <- dat[dat$score < 0, ]
right <- dat[dat$score >= 0, ]

fit_left <- fit_side(left)
fit_right <- fit_side(right)

left_intercepts <- as.vector(fit_left$beta[1, ])
right_intercepts <- as.vector(fit_right$beta[1, ])

discontinuities <- right_intercepts - left_intercepts

V_left <- fit_left$vcov[c(1, 3), c(1, 3)]
V_right <- fit_right$vcov[c(1, 3), c(1, 3)]
V_disc <- V_left + V_right

reduced_form <- discontinuities[1]
first_stage <- discontinuities[2]

var_reduced_form <- V_disc[1, 1]
var_first_stage <- V_disc[2, 2]
cov_rf_fs <- V_disc[1, 2]

treatment_effect <- reduced_form / first_stage
var_treatment_effect <-
  var_reduced_form / first_stage^2 +
  reduced_form^2 * var_first_stage / first_stage^4 -
  2 * reduced_form * cov_rf_fs / first_stage^3

var_treatment_effect <- max(var_treatment_effect, 0)

n_obs <- nrow(dat)

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(
      term = "treatment_effect",
      estimate = as.numeric(treatment_effect),
      se = as.numeric(sqrt(var_treatment_effect)),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "reduced_form",
      estimate = as.numeric(reduced_form),
      se = as.numeric(sqrt(var_reduced_form)),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "first_stage",
      estimate = as.numeric(first_stage),
      se = as.numeric(sqrt(var_first_stage)),
      n_obs = as.integer(n_obs)
    )
  ),
  method_metadata = list(
    estimator = "Fuzzy regression discontinuity with separate weighted local-linear regressions",
    vcov = "HC0 heteroskedasticity-robust covariance with joint delta method"
  ),
  diagnostics = list()
)

jsonlite::write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  digits = 17
)
