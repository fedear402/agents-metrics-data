df <- read.csv("input.csv", stringsAsFactors = FALSE)

date_parsed <- as.Date(df$date)
if (all(!is.na(date_parsed))) {
  ord <- order(date_parsed)
} else {
  ord <- order(df$date)
}
df <- df[ord, ]

log_sales <- log(df$sales)
dlog_vix <- diff(log(df$vix))

n_total <- nrow(df)
if (n_total <= 16) {
  stop("Insufficient observations for 15 lags.")
}

idx <- 17:n_total
y <- log_sales[idx]

X <- matrix(1, nrow = length(idx), ncol = 16)
colnames(X) <- c("intercept", paste0("lag_", 1:15))

for (j in 1:15) {
  X[, j + 1] <- dlog_vix[idx - j]
}

fit <- lm.fit(x = X, y = y)
beta <- as.numeric(fit$coefficients)
resid <- as.numeric(fit$residuals)
n_obs <- nrow(X)

bread <- solve(crossprod(X))
xu <- X * resid

meat <- crossprod(xu)

for (j in 1:15) {
  weight <- 1 - j / 16
  gamma_j <- crossprod(xu[(j + 1):n_obs, , drop = FALSE],
                       xu[1:(n_obs - j), , drop = FALSE])
  meat <- meat + weight * (gamma_j + t(gamma_j))
}

vcov_nw <- bread %*% meat %*% bread
vcov_nw <- vcov_nw * n_obs / (n_obs - 16)

slope_idx <- 2:16
cumulative_response <- sum(beta[slope_idx])
cumulative_var <- sum(vcov_nw[slope_idx, slope_idx])
cumulative_se <- sqrt(max(cumulative_var, 0))

lag_1_idx <- 2
lag_15_idx <- 16

fmt_num <- function(x) {
  if (!is.finite(x)) "null" else format(x, digits = 17, scientific = TRUE)
}

json <- paste0(
  '{\n',
  '  "task_id": "applied_cumulative_hac",\n',
  '  "platform": "r",\n',
  '  "estimates": [\n',
  '    {"term": "cumulative_response", "estimate": ', fmt_num(cumulative_response),
  ', "se": ', fmt_num(cumulative_se), ', "n_obs": ', n_obs, '},\n',
  '    {"term": "lag_1", "estimate": ', fmt_num(beta[lag_1_idx]),
  ', "se": ', fmt_num(sqrt(max(vcov_nw[lag_1_idx, lag_1_idx], 0))),
  ', "n_obs": ', n_obs, '},\n',
  '    {"term": "lag_15", "estimate": ', fmt_num(beta[lag_15_idx]),
  ', "se": ', fmt_num(sqrt(max(vcov_nw[lag_15_idx, lag_15_idx], 0))),
  ', "n_obs": ', n_obs, '}\n',
  '  ],\n',
  '  "method_metadata": {\n',
  '    "estimator": "OLS with intercept and lags 1 through 15 of first-differenced log volatility",\n',
  '    "vcov": "Newey-West HAC covariance, maximum lag 15, Bartlett weights, N/(N-16) correction"\n',
  '  },\n',
  '  "diagnostics": {}\n',
  '}\n'
)

writeLines(json, "result.json")
