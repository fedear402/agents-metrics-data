library(jsonlite)

dat <- read.csv("input.csv")

keep <- abs(dat$score) < 1
dat <- dat[keep, ]

score <- dat$score
right <- as.numeric(score >= 0)
weights <- 1 - abs(score)

X <- cbind(
  intercept = 1,
  discontinuity = right,
  slope_left = score * (1 - right),
  slope_right = score * right
)

fit_wls <- function(y) {
  bread <- solve(crossprod(X, weights * X))
  beta <- bread %*% crossprod(X, weights * y)
  residuals <- drop(y - X %*% beta)
  contrast <- c(0, 1, 0, 0)
  loading <- weights * drop(X %*% bread %*% contrast)
  list(
    estimate = unname(beta[2]),
    residuals = residuals,
    loading = loading
  )
}

earnings_fit <- fit_wls(dat$earnings)
participation_fit <- fit_wls(dat$participated)

earnings_contrib <- earnings_fit$loading * earnings_fit$residuals
participation_contrib <- participation_fit$loading * participation_fit$residuals

joint_covariance <- crossprod(
  cbind(earnings_contrib, participation_contrib)
)

reduced_form <- earnings_fit$estimate
first_stage <- participation_fit$estimate
treatment_effect <- reduced_form / first_stage

reduced_form_se <- sqrt(joint_covariance[1, 1])
first_stage_se <- sqrt(joint_covariance[2, 2])

gradient <- c(
  1 / first_stage,
  -reduced_form / first_stage^2
)

treatment_effect_se <- sqrt(
  drop(t(gradient) %*% joint_covariance %*% gradient)
)

n_obs <- nrow(dat)

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(
      term = "treatment_effect",
      estimate = unname(treatment_effect),
      se = unname(treatment_effect_se),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "reduced_form",
      estimate = unname(reduced_form),
      se = unname(reduced_form_se),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "first_stage",
      estimate = unname(first_stage),
      se = unname(first_stage_se),
      n_obs = as.integer(n_obs)
    )
  ),
  method_metadata = list(
    estimator = "weighted local-linear fuzzy regression discontinuity",
    vcov = "HC0 with fixed triangular weights"
  ),
  diagnostics = list()
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
