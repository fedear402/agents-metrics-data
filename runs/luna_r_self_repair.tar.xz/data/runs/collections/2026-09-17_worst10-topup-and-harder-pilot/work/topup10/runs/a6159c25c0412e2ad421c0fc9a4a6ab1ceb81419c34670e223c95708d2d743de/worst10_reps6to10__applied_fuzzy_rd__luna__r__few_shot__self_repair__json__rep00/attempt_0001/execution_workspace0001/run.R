library(jsonlite)

dat <- read.csv("input.csv")

keep <- abs(dat$score) < 1
d <- dat[keep, , drop = FALSE]

w <- 1 - abs(d$score)
right <- as.numeric(d$score >= 0)
left <- 1 - right

X <- cbind(
  left_intercept = left,
  left_score = left * d$score,
  right_intercept = right,
  right_score = right * d$score
)

W <- diag(w)
bread <- solve(crossprod(X, W %*% X))

fit_outcome <- function(y) {
  beta <- bread %*% crossprod(X, w * y)
  residual <- as.numeric(y - X %*% beta)
  list(beta = as.numeric(beta), residual = residual)
}

earn_fit <- fit_outcome(d$earnings)
part_fit <- fit_outcome(d$participated)

contrast <- c(-1, 0, 1, 0)

reduced_form <- sum(contrast * earn_fit$beta)
first_stage <- sum(contrast * part_fit$beta)

loading <- as.numeric(w * (X %*% bread %*% contrast))

influence_earnings <- loading * earn_fit$residual
influence_participation <- loading * part_fit$residual

joint_covariance <- crossprod(
  cbind(influence_earnings, influence_participation)
)

reduced_form_se <- sqrt(joint_covariance[1, 1])
first_stage_se <- sqrt(joint_covariance[2, 2])

treatment_effect <- reduced_form / first_stage
gradient <- c(
  1 / first_stage,
  -reduced_form / first_stage^2
)
treatment_effect_se <- sqrt(
  as.numeric(t(gradient) %*% joint_covariance %*% gradient)
)

n_obs <- nrow(d)

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(
      term = "treatment_effect",
      estimate = treatment_effect,
      se = treatment_effect_se,
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "reduced_form",
      estimate = reduced_form,
      se = reduced_form_se,
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "first_stage",
      estimate = first_stage,
      se = first_stage_se,
      n_obs = as.integer(n_obs)
    )
  ),
  method_metadata = list(
    estimator = "Fuzzy local-linear regression discontinuity with triangular weights",
    vcov = "Conventional heteroskedasticity-robust HC0 with joint delta-method covariance"
  ),
  diagnostics = list()
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  digits = 16,
  pretty = TRUE,
  null = "null"
)
