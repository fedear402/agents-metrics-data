library(jsonlite)

data <- read.csv("input.csv", stringsAsFactors = FALSE)
data$date <- as.Date(data$date)
data <- data[order(data$date), ]

log_vix <- log(data$vix)
log_sales <- log(data$sales)
vol_change <- c(NA_real_, diff(log_vix))

lag_count <- 15L
usable <- (lag_count + 2L):nrow(data)
N <- length(usable)

X <- cbind(
  intercept = rep(1, N),
  do.call(
    cbind,
    lapply(seq_len(lag_count), function(j) {
      vol_change[usable - j]
    })
  )
)
colnames(X) <- c("intercept", paste0("lag_", seq_len(lag_count)))

y <- log_sales[usable]

beta <- solve(crossprod(X), crossprod(X, y))
residuals <- as.numeric(y - X %*% beta)
scores <- X * residuals

hac_lags <- 15L
meat <- crossprod(scores)

for (j in seq_len(hac_lags)) {
  lag_product <- crossprod(
    scores[(j + 1L):N, , drop = FALSE],
    scores[1L:(N - j), , drop = FALSE]
  )
  weight <- 1 - j / (hac_lags + 1)
  meat <- meat + weight * (lag_product + t(lag_product))
}

bread <- solve(crossprod(X))
p <- ncol(X)
covariance <- (N / (N - p)) * bread %*% meat %*% bread

contrast <- c(0, rep(1, lag_count))
cumulative <- sum(contrast * beta)
cumulative_se <- sqrt(drop(t(contrast) %*% covariance %*% contrast))

lag_1 <- beta[2]
lag_1_se <- sqrt(covariance[2, 2])

lag_15 <- beta[16]
lag_15_se <- sqrt(covariance[16, 16])

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(
      term = "cumulative_response",
      estimate = unname(as.numeric(cumulative)),
      se = unname(as.numeric(cumulative_se)),
      n_obs = as.integer(N)
    ),
    list(
      term = "lag_1",
      estimate = unname(as.numeric(lag_1)),
      se = unname(as.numeric(lag_1_se)),
      n_obs = as.integer(N)
    ),
    list(
      term = "lag_15",
      estimate = unname(as.numeric(lag_15)),
      se = unname(as.numeric(lag_15_se)),
      n_obs = as.integer(N)
    )
  ),
  method_metadata = list(
    estimator = "OLS with intercept and 15 lagged log-volatility changes",
    vcov = "Bartlett Newey-West HAC, maximum lag 15, correction N/(N-16)"
  ),
  diagnostics = list()
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  digits = 16,
  pretty = TRUE,
  null = "null"
)
