dat <- read.csv("input.csv", stringsAsFactors = FALSE)

keep <- abs(dat$score) < 1
d <- dat[keep, , drop = FALSE]

x <- d$score
z <- as.numeric(x >= 0)
w <- 1 - abs(x)

X <- cbind(
  intercept = 1,
  treatment = z,
  score = x,
  treatment_score = z * x
)

fit_hc0 <- function(y) {
  y <- as.numeric(y)
  XtWX <- crossprod(X, w * X)
  bread <- solve(XtWX)
  beta <- bread %*% crossprod(X, w * y)
  residuals <- y - as.vector(X %*% beta)

  meat <- matrix(0, nrow = ncol(X), ncol = ncol(X))
  for (i in seq_len(nrow(X))) {
    xi <- X[i, , drop = FALSE]
    meat <- meat + (w[i]^2) * residuals[i]^2 * crossprod(xi)
  }

  vcov <- bread %*% meat %*% bread
  list(
    estimate = as.numeric(beta[2]),
    variance = vcov[2, 2],
    residuals = residuals
  )
}

rf <- fit_hc0(d$earnings)
fs <- fit_hc0(d$participated)

joint_meat <- matrix(0, nrow = ncol(X), ncol = ncol(X))
for (i in seq_len(nrow(X))) {
  xi <- X[i, , drop = FALSE]
  joint_meat <- joint_meat +
    (w[i]^2) *
    rf$residuals[i] *
    fs$residuals[i] *
    crossprod(xi)
}

XtWX <- crossprod(X, w * X)
bread <- solve(XtWX)
joint_cov <- bread %*% joint_meat %*% bread
cov_rf_fs <- joint_cov[2, 2]

treatment_effect <- rf$estimate / fs$estimate
te_variance <- (
  rf$variance +
    treatment_effect^2 * fs$variance -
    2 * treatment_effect * cov_rf_fs
) / fs$estimate^2

n_obs <- nrow(d)

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(
      term = "treatment_effect",
      estimate = treatment_effect,
      se = sqrt(max(te_variance, 0)),
      n_obs = n_obs
    ),
    list(
      term = "reduced_form",
      estimate = rf$estimate,
      se = sqrt(max(rf$variance, 0)),
      n_obs = n_obs
    ),
    list(
      term = "first_stage",
      estimate = fs$estimate,
      se = sqrt(max(fs$variance, 0)),
      n_obs = n_obs
    )
  ),
  method_metadata = list(
    estimator = "fuzzy regression discontinuity with local-linear weighted least squares",
    vcov = "HC0 heteroskedasticity-robust sandwich covariance with delta method"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = 15)
