#!/usr/bin/env Rscript

library(jsonlite)

dat <- read.csv("input.csv", stringsAsFactors = FALSE)

keep <- abs(dat$score) < 1
d <- dat[keep, , drop = FALSE]

xscore <- d$score
right <- as.numeric(xscore >= 0)
weights <- 1 - abs(xscore)

X <- cbind(
  intercept = 1,
  right = right,
  score = xscore,
  right_score = right * xscore
)

bread <- solve(crossprod(X, weights * X))

hc0_covariance <- function(y) {
  beta <- bread %*% crossprod(X, weights * y)
  residuals <- as.numeric(y - X %*% beta)
  meat <- crossprod(X, (weights^2 * residuals^2) * X)
  vcov <- bread %*% meat %*% bread
  list(beta = as.numeric(beta), vcov = vcov, residuals = residuals)
}

earnings_fit <- hc0_covariance(d$earnings)
participation_fit <- hc0_covariance(d$participated)

reduced_form <- earnings_fit$beta[2]
first_stage <- participation_fit$beta[2]

reduced_form_var <- earnings_fit$vcov[2, 2]
first_stage_var <- participation_fit$vcov[2, 2]

cross_meat <- crossprod(
  X,
  (weights^2 * earnings_fit$residuals * participation_fit$residuals) * X
)
cross_vcov <- bread %*% cross_meat %*% bread
cross_covariance <- cross_vcov[2, 2]

treatment_effect <- reduced_form / first_stage
gradient <- c(1 / first_stage, -reduced_form / first_stage^2)

joint_covariance <- matrix(
  c(reduced_form_var, cross_covariance,
    cross_covariance, first_stage_var),
  nrow = 2,
  byrow = TRUE
)

treatment_effect_var <- as.numeric(
  t(gradient) %*% joint_covariance %*% gradient
)

n_obs <- nrow(d)

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(
      term = "treatment_effect",
      estimate = unname(as.numeric(treatment_effect)),
      se = unname(as.numeric(sqrt(treatment_effect_var))),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "reduced_form",
      estimate = unname(as.numeric(reduced_form)),
      se = unname(as.numeric(sqrt(reduced_form_var))),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "first_stage",
      estimate = unname(as.numeric(first_stage)),
      se = unname(as.numeric(sqrt(first_stage_var))),
      n_obs = as.integer(n_obs)
    )
  ),
  method_metadata = list(
    estimator = "weighted local-linear fuzzy regression discontinuity",
    vcov = "HC0 with triangular fixed weights and delta method"
  ),
  diagnostics = list()
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
