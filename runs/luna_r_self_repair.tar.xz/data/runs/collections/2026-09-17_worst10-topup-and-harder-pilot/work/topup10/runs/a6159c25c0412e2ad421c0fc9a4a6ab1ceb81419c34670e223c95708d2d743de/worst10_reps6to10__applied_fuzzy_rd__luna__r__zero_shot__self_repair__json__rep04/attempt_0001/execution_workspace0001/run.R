dat <- read.csv("input.csv", stringsAsFactors = FALSE)

dat <- dat[
  is.finite(dat$score) &
    is.finite(dat$participated) &
    is.finite(dat$earnings) &
    abs(dat$score) < 1,
]

n_obs <- nrow(dat)
s <- dat$score
d <- as.numeric(s >= 0)
w <- 1 - abs(s)

X <- cbind(
  intercept = 1,
  cutoff = d,
  score = s,
  score_right = d * s
)

fit_robust <- function(y) {
  XtW <- t(X) * w
  bread <- solve(XtW %*% X)
  beta <- bread %*% (XtW %*% y)
  resid <- as.numeric(y - X %*% beta)

  meat <- matrix(0, ncol(X), ncol(X))
  for (i in seq_len(n_obs)) {
    xi <- matrix(X[i, ], ncol = 1)
    meat <- meat + (w[i]^2 * resid[i]^2) * (xi %*% t(xi))
  }

  vcov <- bread %*% meat %*% bread
  list(beta = as.numeric(beta), vcov = vcov, resid = resid)
}

fit_y <- fit_robust(dat$earnings)
fit_p <- fit_robust(dat$participated)

reduced_form <- fit_y$beta[2]
first_stage <- fit_p$beta[2]

var_rf <- fit_y$vcov[2, 2]
var_fs <- fit_p$vcov[2, 2]

cross_meat <- matrix(0, ncol(X), ncol(X))
for (i in seq_len(n_obs)) {
  xi <- matrix(X[i, ], ncol = 1)
  cross_meat <- cross_meat +
    (w[i]^2 * fit_y$resid[i] * fit_p$resid[i]) * (xi %*% t(xi))
}

bread <- solve(t(X) %*% (X * w))
cross_vcov <- bread %*% cross_meat %*% bread
cov_rf_fs <- cross_vcov[2, 2]

treatment_effect <- reduced_form / first_stage
var_te <-
  var_rf / first_stage^2 +
  reduced_form^2 * var_fs / first_stage^4 -
  2 * reduced_form * cov_rf_fs / first_stage^3

se_te <- sqrt(max(var_te, 0))

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(
      term = "treatment_effect",
      estimate = unname(treatment_effect),
      se = unname(se_te),
      n_obs = n_obs
    ),
    list(
      term = "reduced_form",
      estimate = unname(reduced_form),
      se = unname(sqrt(max(var_rf, 0))),
      n_obs = n_obs
    ),
    list(
      term = "first_stage",
      estimate = unname(first_stage),
      se = unname(sqrt(max(var_fs, 0))),
      n_obs = n_obs
    )
  ),
  method_metadata = list(
    estimator = "Fuzzy local-linear regression discontinuity with triangular weights",
    vcov = "Conventional HC0 sandwich covariance; delta method with joint covariance"
  ),
  diagnostics = list()
)

if (requireNamespace("jsonlite", quietly = TRUE)) {
  jsonlite::write_json(
    result,
    "result.json",
    auto_unbox = TRUE,
    digits = 17,
    pretty = FALSE,
    na = "null"
  )
} else {
  esc <- function(x) {
    if (is.null(x) || is.na(x)) return("null")
    if (is.character(x)) return(sprintf('"%s"', x))
    if (is.logical(x)) return(ifelse(x, "true", "false"))
    format(x, digits = 17, scientific = FALSE, trim = TRUE)
  }

  lines <- c(
    "{",
    sprintf('  "task_id": %s,', esc(result$task_id)),
    sprintf('  "platform": %s,', esc(result$platform)),
    '  "estimates": ['
  )

  for (j in seq_along(result$estimates)) {
    e <- result$estimates[[j]]
    comma <- if (j < length(result$estimates)) "," else ""
    lines <- c(
      lines,
      sprintf(
        '    {"term": %s, "estimate": %s, "se": %s, "n_obs": %s}%s',
        esc(e$term), esc(e$estimate), esc(e$se), esc(e$n_obs), comma
      )
    )
  }

  lines <- c(
    lines,
    "  ],",
    sprintf(
      '  "method_metadata": {"estimator": %s, "vcov": %s},',
      esc(result$method_metadata$estimator),
      esc(result$method_metadata$vcov)
    ),
    '  "diagnostics": {}',
    "}"
  )

  writeLines(lines, "result.json")
}
