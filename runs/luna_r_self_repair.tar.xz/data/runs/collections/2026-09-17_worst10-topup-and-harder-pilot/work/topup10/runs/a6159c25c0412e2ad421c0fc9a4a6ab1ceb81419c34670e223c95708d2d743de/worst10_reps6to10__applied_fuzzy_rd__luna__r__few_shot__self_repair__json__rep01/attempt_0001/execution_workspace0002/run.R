library(jsonlite)

dat <- read.csv("input.csv")

keep <- abs(dat$score) < 1
dat <- dat[keep, , drop = FALSE]

score <- as.numeric(dat$score)
right <- as.numeric(score >= 0)
weights <- 1 - abs(score)

X <- cbind(
  intercept = 1,
  right = right,
  score = score,
  right_score = right * score
)

Y <- cbind(
  earnings = as.numeric(dat$earnings),
  participated = as.numeric(dat$participated)
)

bread <- solve(crossprod(X, weights * X))
coefficients <- bread %*% crossprod(X, weights * Y)
residuals <- Y - X %*% coefficients

n_obs <- nrow(dat)
joint_beta <- matrix(0, nrow = 8, ncol = 8)

for (a in seq_len(2)) {
  for (b in seq_len(2)) {
    meat_ab <- matrix(0, nrow = 4, ncol = 4)

    for (i in seq_len(n_obs)) {
      xi <- matrix(X[i, ], ncol = 1)
      meat_ab <- meat_ab +
        weights[i]^2 *
        residuals[i, a] *
        residuals[i, b] *
        (xi %*% t(xi))
    }

    covariance_ab <- bread %*% meat_ab %*% bread

    rows <- ((a - 1) * 4 + 1):(a * 4)
    cols <- ((b - 1) * 4 + 1):(b * 4)
    joint_beta[rows, cols] <- covariance_ab
  }
}

reduced_form <- as.numeric(coefficients[2, 1])
first_stage <- as.numeric(coefficients[2, 2])

rf_var <- as.numeric(joint_beta[2, 2])
fs_var <- as.numeric(joint_beta[6, 6])
rf_fs_cov <- as.numeric(joint_beta[2, 6])

rf_se <- sqrt(rf_var)
fs_se <- sqrt(fs_var)

treatment_effect <- reduced_form / first_stage

gradient <- c(
  1 / first_stage,
  -reduced_form / first_stage^2
)

discontinuity_covariance <- matrix(
  c(rf_var, rf_fs_cov,
    rf_fs_cov, fs_var),
  nrow = 2,
  byrow = TRUE
)

treatment_var <- as.numeric(
  t(gradient) %*% discontinuity_covariance %*% gradient
)
treatment_se <- sqrt(treatment_var)

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(
      term = "treatment_effect",
      estimate = treatment_effect,
      se = treatment_se,
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "reduced_form",
      estimate = reduced_form,
      se = rf_se,
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "first_stage",
      estimate = first_stage,
      se = fs_se,
      n_obs = as.integer(n_obs)
    )
  ),
  method_metadata = list(
    estimator = "Weighted local-linear fuzzy regression discontinuity",
    vcov = "Conventional heteroskedasticity-robust HC0 with fixed triangular weights and delta method"
  ),
  diagnostics = list()
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  digits = 16,
  pretty = TRUE
)
