library(jsonlite)

data <- read.csv("input.csv", stringsAsFactors = FALSE)
data$date <- as.Date(data$date)
data <- data[order(data$date), ]

data$log_sales <- log(data$sales)
data$vol_change <- c(NA, diff(log(data$vix)))

for (j in 1:15) {
  data[[paste0("lag_", j)]] <- c(rep(NA, j), head(data$vol_change, -j))
}

regressors <- paste0("lag_", 1:15)
keep <- complete.cases(data[, c("log_sales", regressors)])
sample <- data[keep, ]

fit <- lm(
  as.formula(paste("log_sales ~", paste(regressors, collapse = " + "))),
  data = sample
)

X <- model.matrix(fit)
beta <- coef(fit)
residuals <- residuals(fit)
N <- nrow(X)
p <- ncol(X)
hac_lags <- 15

scores <- X * residuals
meat <- crossprod(scores)

for (j in seq_len(hac_lags)) {
  lag_product <- crossprod(
    scores[(j + 1):N, , drop = FALSE],
    scores[1:(N - j), , drop = FALSE]
  )
  weight <- 1 - j / 16
  meat <- meat + weight * (lag_product + t(lag_product))
}

bread <- solve(crossprod(X))
covariance <- (N / (N - 16)) * bread %*% meat %*% bread

contrast <- c(0, rep(1, 15))
cumulative_response <- sum(contrast * beta)
cumulative_se <- sqrt(drop(t(contrast) %*% covariance %*% contrast))

lag1_index <- which(colnames(X) == "lag_1")
lag15_index <- which(colnames(X) == "lag_15")

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(
      term = "cumulative_response",
      estimate = unname(as.numeric(cumulative_response)),
      se = unname(as.numeric(cumulative_se)),
      n_obs = as.integer(N)
    ),
    list(
      term = "lag_1",
      estimate = unname(as.numeric(beta[lag1_index])),
      se = unname(as.numeric(sqrt(covariance[lag1_index, lag1_index]))),
      n_obs = as.integer(N)
    ),
    list(
      term = "lag_15",
      estimate = unname(as.numeric(beta[lag15_index])),
      se = unname(as.numeric(sqrt(covariance[lag15_index, lag15_index]))),
      n_obs = as.integer(N)
    )
  ),
  method_metadata = list(
    estimator = "OLS with 15 lags of log volatility changes",
    vcov = "Bartlett Newey-West HAC, maximum lag 15, correction N/(N-16)"
  ),
  diagnostics = list()
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
