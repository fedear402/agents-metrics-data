dat <- read.csv("input.csv", stringsAsFactors = FALSE)
dat <- dat[order(dat$date), ]

y_all <- log(dat$sales)
z_all <- diff(log(dat$vix))

n_total <- nrow(dat)
idx <- 17:n_total

y <- y_all[idx]
X_lags <- sapply(1:15, function(j) z_all[idx - j])
colnames(X_lags) <- paste0("lag_", 1:15)

X <- cbind(intercept = 1, X_lags)
N <- nrow(X)
p <- ncol(X)

beta <- solve(crossprod(X), crossprod(X, y))
resid <- as.vector(y - X %*% beta)

S <- matrix(0, p, p)

for (t in 1:N) {
  xt <- X[t, , drop = FALSE]
  S <- S + resid[t]^2 * crossprod(xt)
}

for (j in 1:15) {
  weight <- 1 - j / 16
  for (t in (j + 1):N) {
    a <- resid[t] * X[t, , drop = FALSE]
    b <- resid[t - j] * X[t - j, , drop = FALSE]
    S <- S + weight * (crossprod(a, b) + crossprod(b, a))
  }
}

bread <- solve(crossprod(X))
vcov_hac <- bread %*% S %*% bread
vcov_hac <- vcov_hac * N / (N - 16)

cum_weights <- c(0, rep(1, 15))
cumulative_response <- sum(beta[2:16])
cumulative_se <- sqrt(as.numeric(t(cum_weights) %*% vcov_hac %*% cum_weights))

lag1_estimate <- beta[2]
lag1_se <- sqrt(vcov_hac[2, 2])

lag15_estimate <- beta[16]
lag15_se <- sqrt(vcov_hac[16, 16])

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(
      term = "cumulative_response",
      estimate = as.numeric(cumulative_response),
      se = as.numeric(cumulative_se),
      n_obs = as.integer(N)
    ),
    list(
      term = "lag_1",
      estimate = as.numeric(lag1_estimate),
      se = as.numeric(lag1_se),
      n_obs = as.integer(N)
    ),
    list(
      term = "lag_15",
      estimate = as.numeric(lag15_estimate),
      se = as.numeric(lag15_se),
      n_obs = as.integer(N)
    )
  ),
  method_metadata = list(
    estimator = "OLS with intercept and 15 trading-observation lags of first-differenced log volatility",
    vcov = "Newey-West HAC, maximum lag 15, Bartlett weights, scaled by N/(N-16)"
  ),
  diagnostics = list()
)

jsonlite::write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  digits = 17,
  pretty = TRUE,
  null = "null"
)
