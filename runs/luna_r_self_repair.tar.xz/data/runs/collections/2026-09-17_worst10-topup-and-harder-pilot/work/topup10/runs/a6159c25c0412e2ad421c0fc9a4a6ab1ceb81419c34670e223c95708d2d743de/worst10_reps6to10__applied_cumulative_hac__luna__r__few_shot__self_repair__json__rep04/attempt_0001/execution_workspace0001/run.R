library(jsonlite)

data <- read.csv("input.csv", stringsAsFactors = FALSE)
data$date <- as.Date(data$date)
data <- data[order(data$date), ]

log_vix <- log(data$vix)
delta_vix <- c(NA_real_, diff(log_vix))
log_sales <- log(data$sales)

n_total <- nrow(data)
usable <- seq.int(17L, n_total)
N <- length(usable)

y <- log_sales[usable]
lag_matrix <- sapply(1:15, function(j) delta_vix[usable - j])
colnames(lag_matrix) <- paste0("lag_", 1:15)

X <- cbind("(Intercept)" = 1, lag_matrix)
fit <- lm.fit(x = X, y = y)

beta <- fit$coefficients
residuals <- fit$residuals
p <- ncol(X)

scores <- X * residuals
meat <- crossprod(scores)

hac_lags <- 15L
for (j in seq_len(hac_lags)) {
  cross_lag <- crossprod(
    scores[(j + 1):N, , drop = FALSE],
    scores[1:(N - j), , drop = FALSE]
  )
  weight <- 1 - j / 16
  meat <- meat + weight * (cross_lag + t(cross_lag))
}

bread <- solve(crossprod(X))
covariance <- (N / (N - 16)) * bread %*% meat %*% bread

contrast <- c(0, rep(1, 15))
cumulative_estimate <- sum(contrast * beta)
cumulative_se <- sqrt(drop(t(contrast) %*% covariance %*% contrast))

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(
      term = "cumulative_response",
      estimate = unname(as.numeric(cumulative_estimate)),
      se = unname(as.numeric(cumulative_se)),
      n_obs = as.integer(N)
    ),
    list(
      term = "lag_1",
      estimate = unname(as.numeric(beta[2])),
      se = unname(as.numeric(sqrt(covariance[2, 2]))),
      n_obs = as.integer(N)
    ),
    list(
      term = "lag_15",
      estimate = unname(as.numeric(beta[16])),
      se = unname(as.numeric(sqrt(covariance[16, 16]))),
      n_obs = as.integer(N)
    )
  ),
  method_metadata = list(
    estimator = "OLS with intercept and 15 trading-observation lags of log volatility changes",
    vcov = "Bartlett Newey-West HAC, maximum lag 15, finite-sample correction N/(N-16)"
  ),
  diagnostics = list()
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  digits = 16,
  pretty = TRUE,
  null = "null"
)
