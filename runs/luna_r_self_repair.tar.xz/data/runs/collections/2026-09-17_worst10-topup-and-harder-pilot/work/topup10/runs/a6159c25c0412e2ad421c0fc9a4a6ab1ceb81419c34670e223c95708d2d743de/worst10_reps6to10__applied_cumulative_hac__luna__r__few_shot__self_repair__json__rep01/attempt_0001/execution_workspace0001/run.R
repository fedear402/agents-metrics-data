library(jsonlite)

data <- read.csv("input.csv", stringsAsFactors = FALSE)
data$date <- as.Date(data$date)
data <- data[order(data$date), ]

n <- nrow(data)
log_vix <- log(data$vix)
change <- c(NA_real_, diff(log_vix))

lagged_changes <- sapply(1:15, function(j) {
  c(rep(NA_real_, j), change[seq_len(n - j)])
})
colnames(lagged_changes) <- paste0("lag_", 1:15)

sample <- data.frame(
  log_sales = log(data$sales),
  lagged_changes,
  check.names = FALSE
)
sample <- sample[complete.cases(sample), ]

X <- cbind("(Intercept)" = 1, as.matrix(sample[, paste0("lag_", 1:15)]))
y <- sample$log_sales

beta <- solve(crossprod(X), crossprod(X, y))
residuals <- as.vector(y - X %*% beta)
N <- nrow(X)
p <- ncol(X)

scores <- X * residuals
meat <- crossprod(scores)

hac_lags <- 15
for (j in seq_len(hac_lags)) {
  lag_product <- crossprod(
    scores[(j + 1):N, , drop = FALSE],
    scores[1:(N - j), , drop = FALSE]
  )
  weight <- 1 - j / 16
  meat <- meat + weight * (lag_product + t(lag_product))
}

bread <- solve(crossprod(X))
covariance <- (N / (N - 16)) * bread %*% meat %*% bread

contrast <- c(0, rep(1, 15))
cumulative_response <- sum(contrast * beta)
cumulative_se <- sqrt(drop(t(contrast) %*% covariance %*% contrast))

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(
      term = "cumulative_response",
      estimate = unname(as.numeric(cumulative_response)),
      se = unname(as.numeric(cumulative_se)),
      n_obs = as.integer(N)
    ),
    list(
      term = "lag_1",
      estimate = unname(as.numeric(beta[2])),
      se = unname(as.numeric(sqrt(covariance[2, 2]))),
      n_obs = as.integer(N)
    ),
    list(
      term = "lag_15",
      estimate = unname(as.numeric(beta[16])),
      se = unname(as.numeric(sqrt(covariance[16, 16]))),
      n_obs = as.integer(N)
    )
  ),
  method_metadata = list(
    estimator = "OLS with intercept and lags 1 through 15 of log(vix) changes",
    vcov = "Bartlett Newey-West HAC covariance with maximum lag 15 and N/(N-16) correction"
  ),
  diagnostics = list()
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
