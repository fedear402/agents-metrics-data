#!/usr/bin/env Rscript

if (!requireNamespace("jsonlite", quietly = TRUE)) {
  stop("Package 'jsonlite' is required.")
}

d <- read.csv("input.csv")
n <- nrow(d)

X <- cbind(const = 1, x = d$x, z = d$z)
y <- d$y
uncensored <- y > 0

negloglik <- function(par) {
  beta <- par[1:3]
  sigma <- exp(par[4])
  eta <- drop(X %*% beta)

  ll <- numeric(n)

  if (any(uncensored)) {
    r <- y[uncensored] - eta[uncensored]
    ll[uncensored] <- -log(sigma) -
      0.5 * (r / sigma)^2 -
      0.5 * log(2 * pi)
  }

  if (any(!uncensored)) {
    ll[!uncensored] <- pnorm(
      -eta[!uncensored] / sigma,
      log.p = TRUE
    )
  }

  if (any(!is.finite(ll))) return(.Machine$double.xmax)
  -sum(ll)
}

gradient <- function(par) {
  beta <- par[1:3]
  sigma <- exp(par[4])
  eta <- drop(X %*% beta)

  g_beta <- numeric(3)
  g_logsigma <- 0

  if (any(uncensored)) {
    r <- y[uncensored] - eta[uncensored]
    g_beta <- g_beta + colSums(
      X[uncensored, , drop = FALSE] *
        (r / sigma^2)
    )
    g_logsigma <- g_logsigma + sum(-1 + (r / sigma)^2)
  }

  if (any(!uncensored)) {
    a <- -eta[!uncensored] / sigma
    lambda <- exp(
      dnorm(a, log = TRUE) - pnorm(a, log.p = TRUE)
    )

    g_beta <- g_beta + colSums(
      X[!uncensored, , drop = FALSE] *
        (-lambda / sigma)
    )
    g_logsigma <- g_logsigma + sum(-lambda * a)
  }

  -c(g_beta, g_logsigma)
}

ols_fit <- lm(y ~ x + z, data = d)
beta0 <- coef(ols_fit)
beta0[is.na(beta0)] <- 0
sigma0 <- sd(residuals(ols_fit))
if (!is.finite(sigma0) || sigma0 <= 0) sigma0 <- sd(y[y > 0])
if (!is.finite(sigma0) || sigma0 <= 0) sigma0 <- 1

start <- c(
  unname(beta0[c("(Intercept)", "x", "z")]),
  log(sigma0)
)

fit <- optim(
  par = start,
  fn = negloglik,
  gr = gradient,
  method = "BFGS",
  hessian = TRUE,
  control = list(reltol = 1e-12, maxit = 10000)
)

if (fit$convergence != 0) {
  warning("Optimization did not report convergence.")
}

H <- (fit$hessian + t(fit$hessian)) / 2
V <- solve(H)
V <- (V + t(V)) / 2

beta_hat <- fit$par[1:3]
sigma_hat <- exp(fit$par[4])
se_beta <- sqrt(pmax(diag(V)[1:3], 0))

result <- list(
  task_id = "broad_tobit",
  platform = "r",
  estimates = list(
    list(
      term = "const",
      estimate = unname(beta_hat[1]),
      se = unname(se_beta[1]),
      n_obs = as.integer(n)
    ),
    list(
      term = "x",
      estimate = unname(beta_hat[2]),
      se = unname(se_beta[2]),
      n_obs = as.integer(n)
    ),
    list(
      term = "z",
      estimate = unname(beta_hat[3]),
      se = unname(se_beta[3]),
      n_obs = as.integer(n)
    ),
    list(
      term = "sigma",
      estimate = unname(sigma_hat),
      se = NULL,
      n_obs = as.integer(n)
    )
  ),
  method_metadata = list(
    estimator = "Maximum likelihood homoskedastic Gaussian Tobit with left censoring at zero",
    vcov = "Inverse observed information from the jointly estimated likelihood"
  ),
  diagnostics = list()
)

jsonlite::write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
