dat <- read.csv("input.csv")
n <- nrow(dat)

y <- dat$y
endog <- dat$endog
x <- dat$x
z1 <- dat$z1
z2 <- dat$z2

restricted <- cbind(1, x)
unrestricted <- cbind(1, x, z1, z2)

qr_r <- qr(restricted)
qr_u <- qr(unrestricted)

Q_r <- qr.Q(qr_r)
Q_u <- qr.Q(qr_u)

M_r <- diag(n) - tcrossprod(Q_r)
M_u <- diag(n) - tcrossprod(Q_u)
D <- M_r - M_u

quad_form <- function(v, A) {
  as.numeric(crossprod(v, A %*% v))
}

bilinear_form <- function(v1, A, v2) {
  as.numeric(crossprod(v1, A %*% v2))
}

f_crit <- qf(0.95, df1 = 2, df2 = n - 4)
scale_full <- 2 * f_crit / (n - 4)

ar_stat <- function(beta) {
  v <- y - beta * endog
  ssr_diff <- quad_form(v, D)
  ssr_full <- quad_form(v, M_u)
  ssr_diff / 2 / (ssr_full / (n - 4))
}

inequality_value <- function(beta) {
  v <- y - beta * endog
  quad_form(v, D) - scale_full * quad_form(v, M_u)
}

v_y <- y
v_e <- endog

a <- quad_form(v_e, D) - scale_full * quad_form(v_e, M_u)
cross_term <- bilinear_form(v_y, D, v_e) -
  scale_full * bilinear_form(v_y, M_u, v_e)
b <- -2 * cross_term
c <- quad_form(v_y, D) - scale_full * quad_form(v_y, M_u)

coef_scale <- max(abs(c(a, b, c)), 1)
tol <- 1e-12 * coef_scale

if (abs(a) <= tol) {
  if (abs(b) <= tol) {
    real_roots <- numeric(0)
  } else {
    real_roots <- -c / b
  }
} else {
  discriminant <- as.numeric(b^2 - 4 * a * c)
  disc_tol <- 1e-12 * max(abs(b^2), abs(4 * a * c), 1)

  if (discriminant < 0 && discriminant > -disc_tol) {
    discriminant <- 0
  }

  if (discriminant < 0) {
    real_roots <- numeric(0)
  } else {
    sqrt_disc <- sqrt(discriminant)

    if (sqrt_disc == 0) {
      real_roots <- -b / (2 * a)
    } else {
      q <- -0.5 * (b + sign(b) * sqrt_disc)

      if (q == 0) {
        real_roots <- c(
          (-b + sqrt_disc) / (2 * a),
          (-b - sqrt_disc) / (2 * a)
        )
      } else {
        real_roots <- c(q / a, c / q)
      }
    }
  }
}

real_roots <- sort(real_roots[is.finite(real_roots)])

if (length(real_roots) < 2) {
  stop("Could not identify two finite AR confidence-set boundaries.")
}

boundary_low <- real_roots[1]
boundary_high <- real_roots[length(real_roots)]

accepts_zero <- as.integer(inequality_value(0) <= 0)

unbounded <- as.integer({
  if (abs(a) > tol) {
    a < 0
  } else if (abs(b) > tol) {
    TRUE
  } else {
    c <= 0
  }
})

estimates <- list(
  list(
    term = "boundary_low",
    estimate = as.numeric(boundary_low),
    se = NULL,
    n_obs = n
  ),
  list(
    term = "boundary_high",
    estimate = as.numeric(boundary_high),
    se = NULL,
    n_obs = n
  ),
  list(
    term = "accepts_zero",
    estimate = as.numeric(accepts_zero),
    se = NULL,
    n_obs = n
  ),
  list(
    term = "unbounded",
    estimate = as.numeric(unbounded),
    se = NULL,
    n_obs = n
  ),
  list(
    term = "ar_f_at_one",
    estimate = as.numeric(ar_stat(1)),
    se = NULL,
    n_obs = n
  )
)

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "Anderson-Rubin confidence set using homoskedastic joint F test",
    vcov = "conventional homoskedastic"
  ),
  diagnostics = list()
)

jsonlite::write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  na = "null",
  digits = 17
)
