library(jsonlite)

data <- read.csv("input.csv", stringsAsFactors = FALSE)
data$date <- as.Date(data$date)
data <- data[order(data$date), ]

log_vix <- log(data$vix)
log_sales <- log(data$sales)
vix_change <- c(NA_real_, diff(log_vix))

lagged_changes <- sapply(1:15, function(j) {
  c(rep(NA_real_, j), vix_change[seq_len(length(vix_change) - j)])
})
colnames(lagged_changes) <- paste0("lag_", 1:15)

sample <- data.frame(
  log_sales = log_sales,
  lagged_changes,
  check.names = FALSE
)
sample <- sample[complete.cases(sample), ]

X <- cbind("(Intercept)" = 1, as.matrix(sample[, paste0("lag_", 1:15)]))
y <- sample$log_sales

N <- nrow(X)
p <- ncol(X)

xtx_inv <- solve(crossprod(X))
coefficients <- drop(xtx_inv %*% crossprod(X, y))
residuals <- drop(y - X %*% coefficients)
scores <- X * residuals

meat <- crossprod(scores)
hac_lags <- 15

for (j in seq_len(hac_lags)) {
  lag_product <- crossprod(
    scores[(j + 1):N, , drop = FALSE],
    scores[1:(N - j), , drop = FALSE]
  )
  weight <- 1 - j / 16
  meat <- meat + weight * (lag_product + t(lag_product))
}

covariance <- (N / (N - 16)) * xtx_inv %*% meat %*% xtx_inv

contrast <- c(0, rep(1, 15))
cumulative_estimate <- sum(contrast * coefficients)
cumulative_se <- sqrt(drop(t(contrast) %*% covariance %*% contrast))

lag_1_estimate <- coefficients[2]
lag_1_se <- sqrt(covariance[2, 2])

lag_15_estimate <- coefficients[16]
lag_15_se <- sqrt(covariance[16, 16])

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(
      term = "cumulative_response",
      estimate = unname(as.numeric(cumulative_estimate)),
      se = unname(as.numeric(cumulative_se)),
      n_obs = as.integer(N)
    ),
    list(
      term = "lag_1",
      estimate = unname(as.numeric(lag_1_estimate)),
      se = unname(as.numeric(lag_1_se)),
      n_obs = as.integer(N)
    ),
    list(
      term = "lag_15",
      estimate = unname(as.numeric(lag_15_estimate)),
      se = unname(as.numeric(lag_15_se)),
      n_obs = as.integer(N)
    )
  ),
  method_metadata = list(
    estimator = "OLS with intercept and lags 1 through 15 of log(vix) changes",
    vcov = "Newey-West HAC, Bartlett maximum lag 15, correction N/(N-16)"
  ),
  diagnostics = list()
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
