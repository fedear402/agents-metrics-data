d <- read.csv("input.csv", stringsAsFactors = FALSE, check.names = FALSE)

region_key <- as.character(d$region_id)
industry_key <- as.character(d$industry_id)

region_first <- !duplicated(region_key)
regions <- unique(region_key)
industries <- unique(industry_key)

region_index <- match(region_key, regions)
industry_index <- match(industry_key, industries)

region_weight <- d$region_weight[region_first]
x_region <- d$x[region_first]
y_region <- d$y[region_first]

e <- region_weight / sum(region_weight)

share_matrix <- matrix(
  0,
  nrow = length(regions),
  ncol = length(industries),
  dimnames = list(regions, industries)
)

for (i in seq_len(nrow(d))) {
  share_matrix[region_index[i], industry_index[i]] <-
    share_matrix[region_index[i], industry_index[i]] + d$share[i]
}

shock_industry <- numeric(length(industries))
for (j in seq_along(industries)) {
  shock_industry[j] <- d$shock[which(industry_index == j)[1]]
}

z_region <- as.vector(share_matrix %*% shock_industry)

weighted_mean <- function(v, w) {
  sum(w * v) / sum(w)
}

y0 <- y_region - weighted_mean(y_region, e)
x0 <- x_region - weighted_mean(x_region, e)
z0 <- z_region - weighted_mean(z_region, e)

s_industry <- as.vector(crossprod(e, share_matrix))
used <- s_industry > 0

ybar <- as.vector(crossprod(e * y0, share_matrix)) / s_industry
xbar <- as.vector(crossprod(e * x0, share_matrix)) / s_industry
zbar <- as.vector(crossprod(e * z0, share_matrix)) / s_industry

iv_hc1 <- function(y, q, instrument, weights) {
  keep <- is.finite(y) &
    is.finite(q) &
    is.finite(instrument) &
    is.finite(weights) &
    weights > 0

  y <- y[keep]
  q <- q[keep]
  instrument <- instrument[keep]
  weights <- weights[keep]

  n <- length(y)
  X <- cbind(1, q)
  Z <- cbind(1, instrument)
  WZ <- Z * weights

  ztwz <- crossprod(Z, WZ)
  ztwx <- crossprod(Z, X * weights)
  ztwy <- crossprod(Z, y * weights)

  beta <- solve(crossprod(X * weights, Z) %*%
                  solve(ztwz, ztwx)) %*%
    (crossprod(X * weights, Z) %*%
       solve(ztwz, ztwy))

  residuals <- as.vector(y - X %*% beta)

  middle <- crossprod(X * weights, Z) %*% solve(ztwz)
  bread <- solve(middle %*% ztwx)

  weighted_scores <- Z * (weights * residuals)
  meat <- crossprod(weighted_scores)

  covariance <- bread %*% middle %*% meat %*%
    t(middle) %*% bread

  covariance <- covariance * n / (n - 2)
  se <- sqrt(diag(covariance))

  list(beta = as.vector(beta), se = se, n = n)
}

shock_y <- ybar[used]
shock_x <- xbar[used]
shock_z <- zbar[used]
shock <- shock_industry[used]
shock_weights <- s_industry[used]

effect_fit <- iv_hc1(
  y = shock_y,
  q = shock_x,
  instrument = shock,
  weights = shock_weights
)

first_stage_fit <- iv_hc1(
  y = shock_x,
  q = shock_z,
  instrument = shock,
  weights = shock_weights
)

n_industries <- length(shock_weights)
effective_shocks <- 1 / sum(shock_weights^2)

fmt <- function(x) sprintf("%.17g", x)

json <- paste0(
  "{\n",
  '  "task_id": "applied_shift_share",\n',
  '  "platform": "r",\n',
  '  "estimates": [\n',
  '    {"term": "effect", "estimate": ', fmt(effect_fit$beta[2]),
  ', "se": ', fmt(effect_fit$se[2]),
  ', "n_obs": ', n_industries, '},\n',
  '    {"term": "first_stage", "estimate": ', fmt(first_stage_fit$beta[2]),
  ', "se": ', fmt(first_stage_fit$se[2]),
  ', "n_obs": ', n_industries, '},\n',
  '    {"term": "effective_shocks", "estimate": ', fmt(effective_shocks),
  ', "se": null, "n_obs": ', n_industries, '}\n',
  "  ],\n",
  '  "method_metadata": {"estimator": "Borusyak-Hull-Jaravel shock-level weighted 2SLS", ',
  '"vcov": "shock-level heteroskedasticity-robust HC1"},\n',
  '  "diagnostics": {}\n',
  "}\n"
)

writeLines(json, "result.json")
