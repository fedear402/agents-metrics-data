d <- read.csv("input.csv")

n <- nrow(d)
q <- 2
df <- n - 4

W_restricted <- cbind(1, d$x)
W_full <- cbind(1, d$x, d$z1, d$z2)

residuals_from <- function(y, X) {
  fit <- lm.fit(X, y)
  fit$residuals
}

ry_r <- residuals_from(d$y, W_restricted)
rd_r <- residuals_from(d$endog, W_restricted)
ry_u <- residuals_from(d$y, W_full)
rd_u <- residuals_from(d$endog, W_full)

critical <- qf(0.95, q, df)
k <- q * critical / df

A <- sum(rd_r^2) - (1 + k) * sum(rd_u^2)
B <- -2 * (sum(ry_r * rd_r) - (1 + k) * sum(ry_u * rd_u))
C <- sum(ry_r^2) - (1 + k) * sum(ry_u^2)

discriminant <- B^2 - 4 * A * C

if (abs(A) < 1e-12) {
  stop("Degenerate quadratic boundary case.")
}
if (discriminant <= 0) {
  stop("The data do not yield two finite boundary points.")
}

bounds <- sort(c(
  (-B - sqrt(discriminant)) / (2 * A),
  (-B + sqrt(discriminant)) / (2 * A)
))

accepts <- function(beta) {
  A * beta^2 + B * beta + C <= 0
}

accepts_zero <- as.numeric(accepts(0))
unbounded <- as.numeric(A < 0)

ar_f <- function(beta) {
  transformed <- d$y - beta * d$endog
  restricted_fit <- lm.fit(W_restricted, transformed)
  unrestricted_fit <- lm.fit(W_full, transformed)
  ssr_r <- sum(restricted_fit$residuals^2)
  ssr_u <- sum(unrestricted_fit$residuals^2)
  ((ssr_r - ssr_u) / q) / (ssr_u / df)
}

rows <- list(
  list(term = "boundary_low", estimate = unname(bounds[1]), se = NULL, n_obs = n),
  list(term = "boundary_high", estimate = unname(bounds[2]), se = NULL, n_obs = n),
  list(term = "accepts_zero", estimate = accepts_zero, se = NULL, n_obs = n),
  list(term = "unbounded", estimate = unbounded, se = NULL, n_obs = n),
  list(term = "ar_f_at_one", estimate = ar_f(1), se = NULL, n_obs = n)
)

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = rows,
  method_metadata = list(
    estimator = "Anderson-Rubin inversion with homoskedastic joint F test",
    vcov = "conventional homoskedastic"
  ),
  diagnostics = list(
    numerator_df = q,
    denominator_df = df,
    critical_value = critical,
    quadratic_A = A,
    quadratic_B = B,
    quadratic_C = C
  )
)

jsonlite::write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
