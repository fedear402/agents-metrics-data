d <- read.csv("input.csv")

n <- nrow(d)
q <- 2L
df <- n - 4L
critical <- qf(0.95, q, df)
k <- q * critical / df

restricted_y <- lm(y ~ x, data = d)
restricted_endog <- lm(endog ~ x, data = d)

full_y <- lm(y ~ x + z1 + z2, data = d)
full_endog <- lm(endog ~ x + z1 + z2, data = d)

ry <- residuals(restricted_y)
rd <- residuals(restricted_endog)
uy <- residuals(full_y)
ud <- residuals(full_endog)

A <- sum(rd^2) - (1 + k) * sum(ud^2)
B <- -2 * (sum(ry * rd) - (1 + k) * sum(uy * ud))
C <- sum(ry^2) - (1 + k) * sum(uy^2)

discriminant <- B^2 - 4 * A * C

if (abs(A) > 1e-12 && discriminant > 0) {
  roots <- sort(c(
    (-B - sqrt(discriminant)) / (2 * A),
    (-B + sqrt(discriminant)) / (2 * A)
  ))
  boundary_low <- roots[1]
  boundary_high <- roots[2]
} else {
  stop("The data do not yield two finite boundary points.")
}

accepts <- function(beta) {
  A * beta^2 + B * beta + C <= 0
}

unbounded <- if (A < 0) {
  1
} else if (abs(A) <= 1e-12 && B < 0) {
  1
} else {
  0
}

transformed_one <- d$y - d$endog
restricted_one <- lm(transformed_one ~ x, data = d)
full_one <- lm(transformed_one ~ x + z1 + z2, data = d)

ar_f_at_one <- (
  (deviance(restricted_one) - deviance(full_one)) / q
) / (
  deviance(full_one) / df
)

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = list(
    list(
      term = "boundary_low",
      estimate = unname(boundary_low),
      se = NULL,
      n_obs = n
    ),
    list(
      term = "boundary_high",
      estimate = unname(boundary_high),
      se = NULL,
      n_obs = n
    ),
    list(
      term = "accepts_zero",
      estimate = as.numeric(accepts(0)),
      se = NULL,
      n_obs = n
    ),
    list(
      term = "unbounded",
      estimate = as.numeric(unbounded),
      se = NULL,
      n_obs = n
    ),
    list(
      term = "ar_f_at_one",
      estimate = unname(ar_f_at_one),
      se = NULL,
      n_obs = n
    )
  ),
  method_metadata = list(
    estimator = "Anderson-Rubin confidence set inversion with homoskedastic joint F test",
    vcov = "conventional homoskedastic"
  ),
  diagnostics = list(
    numerator_df = q,
    denominator_df = df,
    critical_value = critical,
    quadratic_A = A,
    quadratic_B = B,
    quadratic_C = C
  )
)

jsonlite::write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
