input <- read.csv("input.csv")

keep <- is.finite(input$score) &
  is.finite(input$participated) &
  is.finite(input$earnings) &
  abs(input$score) < 1

dat <- input[keep, , drop = FALSE]
n_obs <- nrow(dat)

x <- as.numeric(dat$score)
z <- as.numeric(x >= 0)
w <- 1 - abs(x)

X <- cbind(
  intercept = 1,
  discontinuity = z,
  score = x,
  score_discontinuity = z * x
)

fit_wls <- function(y) {
  sw <- sqrt(w)
  Xw <- X * sw
  yw <- y * sw

  cross_xx <- crossprod(Xw)
  cross_xy <- crossprod(Xw, yw)
  beta <- qr.solve(cross_xx, cross_xy)

  residuals <- as.numeric(y - X %*% beta)
  bread <- qr.solve(cross_xx)
  score_matrix <- X * (w * residuals)
  meat <- crossprod(score_matrix)
  vcov <- bread %*% meat %*% bread

  list(
    beta = as.numeric(beta),
    residuals = residuals,
    vcov = vcov
  )
}

fit_earnings <- fit_wls(as.numeric(dat$earnings))
fit_participation <- fit_wls(as.numeric(dat$participated))

reduced_form <- fit_earnings$beta[2]
first_stage <- fit_participation$beta[2]

var_reduced_form <- fit_earnings$vcov[2, 2]
var_first_stage <- fit_participation$vcov[2, 2]

se_reduced_form <- sqrt(max(0, var_reduced_form))
se_first_stage <- sqrt(max(0, var_first_stage))

cross_score <- crossprod(
  X * (w * fit_earnings$residuals),
  X * (w * fit_participation$residuals)
)

bread <- qr.solve(crossprod(X * sqrt(w)))
cross_vcov <- bread %*% cross_score %*% bread
cov_discontinuities <- cross_vcov[2, 2]

treatment_effect <- reduced_form / first_stage

var_treatment_effect <- (
  var_reduced_form +
    treatment_effect^2 * var_first_stage -
    2 * treatment_effect * cov_discontinuities
) / first_stage^2

se_treatment_effect <- sqrt(max(0, var_treatment_effect))

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(
      term = "treatment_effect",
      estimate = as.numeric(treatment_effect),
      se = as.numeric(se_treatment_effect),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "reduced_form",
      estimate = as.numeric(reduced_form),
      se = as.numeric(se_reduced_form),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "first_stage",
      estimate = as.numeric(first_stage),
      se = as.numeric(se_first_stage),
      n_obs = as.integer(n_obs)
    )
  ),
  method_metadata = list(
    estimator = "Fuzzy local-linear regression discontinuity with triangular weights",
    vcov = "Conventional heteroskedasticity-robust HC0 with joint delta method"
  ),
  diagnostics = list()
)

if (!requireNamespace("jsonlite", quietly = TRUE)) {
  stop("The jsonlite package is required.")
}

jsonlite::write_json(
  result,
  path = "result.json",
  auto_unbox = TRUE,
  digits = 17,
  null = "null"
)
