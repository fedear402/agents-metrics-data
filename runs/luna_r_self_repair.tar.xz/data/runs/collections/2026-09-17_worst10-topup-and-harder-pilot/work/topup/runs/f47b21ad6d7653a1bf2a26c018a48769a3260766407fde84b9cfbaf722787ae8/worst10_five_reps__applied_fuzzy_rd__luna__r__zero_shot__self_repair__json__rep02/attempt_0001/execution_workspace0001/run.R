#!/usr/bin/env Rscript

input <- read.csv("input.csv", stringsAsFactors = FALSE)

keep <- is.finite(input$score) &
  is.finite(input$participated) &
  is.finite(input$earnings) &
  abs(input$score) < 1

d <- input[keep, , drop = FALSE]
s <- d$score
w <- 1 - abs(s)
right <- as.numeric(s >= 0)

X <- cbind(
  intercept = 1,
  discontinuity = right,
  score = s,
  score_right = s * right
)

fit_hc0 <- function(y, X, w) {
  bread <- solve(crossprod(X, w * X))
  beta <- bread %*% crossprod(X, w * y)
  residuals <- as.numeric(y - X %*% beta)

  meat <- matrix(0, ncol = ncol(X), nrow = ncol(X))
  for (i in seq_along(y)) {
    xi <- X[i, , drop = FALSE]
    meat <- meat + (w[i]^2 * residuals[i]^2) * crossprod(xi)
  }

  vcov <- bread %*% meat %*% bread

  list(
    beta = as.numeric(beta),
    vcov = vcov,
    residuals = residuals
  )
}

earnings_fit <- fit_hc0(d$earnings, X, w)
participation_fit <- fit_hc0(d$participated, X, w)

reduced_form <- earnings_fit$beta[2]
first_stage <- participation_fit$beta[2]

var_reduced_form <- earnings_fit$vcov[2, 2]
var_first_stage <- participation_fit$vcov[2, 2]

cross_meat <- matrix(0, ncol = ncol(X), nrow = ncol(X))
for (i in seq_len(nrow(X))) {
  xi <- X[i, , drop = FALSE]
  cross_meat <- cross_meat +
    (w[i]^2 *
       earnings_fit$residuals[i] *
       participation_fit$residuals[i]) *
    crossprod(xi)
}

bread <- solve(crossprod(X, w * X))
cross_vcov <- bread %*% cross_meat %*% bread
cov_discontinuities <- cross_vcov[2, 2]

treatment_effect <- reduced_form / first_stage
var_treatment_effect <-
  var_reduced_form / first_stage^2 +
  reduced_form^2 * var_first_stage / first_stage^4 -
  2 * reduced_form * cov_discontinuities / first_stage^3

se_treatment_effect <- sqrt(max(0, var_treatment_effect))

n_obs <- nrow(d)

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(
      term = "treatment_effect",
      estimate = unname(treatment_effect),
      se = unname(se_treatment_effect),
      n_obs = n_obs
    ),
    list(
      term = "reduced_form",
      estimate = unname(reduced_form),
      se = unname(sqrt(var_reduced_form)),
      n_obs = n_obs
    ),
    list(
      term = "first_stage",
      estimate = unname(first_stage),
      se = unname(sqrt(var_first_stage)),
      n_obs = n_obs
    )
  ),
  method_metadata = list(
    estimator = "Fuzzy regression discontinuity with separate local-linear weighted regressions",
    vcov = "HC0 sandwich covariance with triangular fixed weights and delta method using joint covariance"
  ),
  diagnostics = list()
)

if (!requireNamespace("jsonlite", quietly = TRUE)) {
  stop("Package 'jsonlite' is required.")
}

jsonlite::write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  digits = 17,
  null = "null"
)
