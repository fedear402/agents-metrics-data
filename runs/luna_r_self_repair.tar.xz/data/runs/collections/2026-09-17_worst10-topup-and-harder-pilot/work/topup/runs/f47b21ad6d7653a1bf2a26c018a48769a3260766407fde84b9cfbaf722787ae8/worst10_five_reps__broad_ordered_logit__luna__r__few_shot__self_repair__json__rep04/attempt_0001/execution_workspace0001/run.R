d <- read.csv("input.csv")

d$y <- ordered(d$y, levels = c(1, 2, 3))

fit <- MASS::polr(
  y ~ x + z,
  data = d,
  method = "logistic",
  Hess = TRUE,
  control = list(reltol = 1e-12, maxit = 1000)
)

V <- vcov(fit)
b <- coef(fit)
n <- nrow(d)

eta <- unname(b["x"])
prob_high <- 1 - plogis(fit$zeta[2] - eta)

result <- list(
  task_id = "broad_ordered_logit",
  platform = "r",
  estimates = list(
    list(
      term = "x",
      estimate = unname(b["x"]),
      se = sqrt(V["x", "x"]),
      n_obs = n
    ),
    list(
      term = "z",
      estimate = unname(b["z"]),
      se = sqrt(V["z", "z"]),
      n_obs = n
    ),
    list(
      term = "prob_high",
      estimate = unname(prob_high),
      se = NULL,
      n_obs = n
    )
  ),
  method_metadata = list(
    estimator = "maximum-likelihood ordered logit with two free cutpoints and no intercept",
    vcov = "conventional observed-information covariance from the Hessian"
  ),
  diagnostics = list()
)

jsonlite::write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
