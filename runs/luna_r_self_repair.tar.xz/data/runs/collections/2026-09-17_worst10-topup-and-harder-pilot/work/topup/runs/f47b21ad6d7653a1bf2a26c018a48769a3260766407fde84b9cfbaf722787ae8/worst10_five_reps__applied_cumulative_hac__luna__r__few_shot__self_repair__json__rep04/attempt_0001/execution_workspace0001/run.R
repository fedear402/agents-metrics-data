library(jsonlite)

data <- read.csv("input.csv", stringsAsFactors = FALSE)
data$date <- as.Date(data$date)
data <- data[order(data$date), ]

log_vix <- log(data$vix)
data$vol_change <- c(NA_real_, diff(log_vix))
data$log_sales <- log(data$sales)

for (j in 1:15) {
  data[[paste0("lag_", j)]] <- c(rep(NA_real_, j), head(data$vol_change, -j))
}

regressors <- c("log_sales", paste0("lag_", 1:15))
sample <- data[complete.cases(data[, regressors]), ]
y <- sample$log_sales
X <- cbind("(Intercept)" = 1, as.matrix(sample[, paste0("lag_", 1:15)]))

N <- nrow(X)
p <- ncol(X)

beta <- solve(crossprod(X), crossprod(X, y))
residuals <- as.vector(y - X %*% beta)
scores <- X * residuals

meat <- crossprod(scores)

for (j in 1:15) {
  lag_product <- crossprod(
    scores[(j + 1):N, , drop = FALSE],
    scores[1:(N - j), , drop = FALSE]
  )
  weight <- 1 - j / 16
  meat <- meat + weight * (lag_product + t(lag_product))
}

bread <- solve(crossprod(X))
covariance <- (N / (N - 16)) * bread %*% meat %*% bread
standard_errors <- sqrt(diag(covariance))

contrast <- c(0, rep(1, 15))
cumulative_response <- sum(contrast * beta)
cumulative_se <- sqrt(drop(t(contrast) %*% covariance %*% contrast))

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(
      term = "cumulative_response",
      estimate = unname(as.numeric(cumulative_response)),
      se = unname(as.numeric(cumulative_se)),
      n_obs = as.integer(N)
    ),
    list(
      term = "lag_1",
      estimate = unname(as.numeric(beta[2])),
      se = unname(as.numeric(standard_errors[2])),
      n_obs = as.integer(N)
    ),
    list(
      term = "lag_15",
      estimate = unname(as.numeric(beta[16])),
      se = unname(as.numeric(standard_errors[16])),
      n_obs = as.integer(N)
    )
  ),
  method_metadata = list(
    estimator = "OLS with intercept and 15 lagged log-volatility changes",
    vcov = "Bartlett Newey-West HAC, maximum lag 15, finite-sample factor N/(N-16)"
  ),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, digits = 16, pretty = TRUE)
