dat <- read.csv("input.csv", stringsAsFactors = FALSE)

d <- as.Date(dat$date)
if (all(!is.na(d))) {
  dat <- dat[order(d), , drop = FALSE]
} else {
  dat <- dat[order(dat$date), , drop = FALSE]
}

log_vix <- log(dat$vix)
log_sales <- log(dat$sales)
vol_change <- c(NA_real_, diff(log_vix))

lag_matrix <- sapply(1:15, function(j) {
  c(rep(NA_real_, j), vol_change[1:(length(vol_change) - j)])
})

complete <- complete.cases(log_sales, lag_matrix)
y <- log_sales[complete]
X <- cbind("(Intercept)" = 1, lag_matrix[complete, , drop = FALSE])
colnames(X) <- c("(Intercept)", paste0("lag_", 1:15))

n_obs <- nrow(X)
beta <- solve(crossprod(X), crossprod(X, y))
resid <- y - drop(X %*% beta)

bread <- solve(crossprod(X))
meat <- crossprod(X * resid)

max_lag <- 15
for (j in 1:max_lag) {
  weight <- 1 - j / 16
  x_now <- X[(j + 1):n_obs, , drop = FALSE]
  x_lag <- X[1:(n_obs - j), , drop = FALSE]
  u_now <- resid[(j + 1):n_obs]
  u_lag <- resid[1:(n_obs - j)]
  
  gamma_j <- crossprod(x_now * u_now, x_lag * u_lag)
  meat <- meat + weight * (gamma_j + t(gamma_j))
}

vcov_nw <- bread %*% meat %*% bread
vcov_nw <- vcov_nw * n_obs / (n_obs - 16)

cumulative <- sum(beta[2:16])
cumulative_var <- sum(vcov_nw[2:16, 2:16])
cumulative_se <- sqrt(max(cumulative_var, 0))

lag1_se <- sqrt(max(vcov_nw[2, 2], 0))
lag15_se <- sqrt(max(vcov_nw[16, 16], 0))

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(
      term = "cumulative_response",
      estimate = unname(cumulative),
      se = unname(cumulative_se),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "lag_1",
      estimate = unname(beta[2]),
      se = unname(lag1_se),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "lag_15",
      estimate = unname(beta[16]),
      se = unname(lag15_se),
      n_obs = as.integer(n_obs)
    )
  ),
  method_metadata = list(
    estimator = "OLS with intercept and lags 1 through 15 of first-differenced log volatility",
    vcov = "Newey-West HAC covariance, Bartlett weights, maximum lag 15, scaled by N/(N-16)"
  ),
  diagnostics = list()
)

json_escape <- function(x) {
  x <- gsub("\\\\", "\\\\\\\\", x)
  x <- gsub('"', '\\"', x, fixed = TRUE)
  x
}

num <- function(x) {
  if (is.null(x) || !is.finite(x)) "null" else format(x, digits = 17, scientific = TRUE)
}

json <- paste0(
  '{',
  '"task_id":"', json_escape(result$task_id), '",',
  '"platform":"', result$platform, '",',
  '"estimates":[',
  '{"term":"cumulative_response","estimate":', num(result$estimates[[1]]$estimate),
  ',"se":', num(result$estimates[[1]]$se), ',"n_obs":', result$estimates[[1]]$n_obs, '},',
  '{"term":"lag_1","estimate":', num(result$estimates[[2]]$estimate),
  ',"se":', num(result$estimates[[2]]$se), ',"n_obs":', result$estimates[[2]]$n_obs, '},',
  '{"term":"lag_15","estimate":', num(result$estimates[[3]]$estimate),
  ',"se":', num(result$estimates[[3]]$se), ',"n_obs":', result$estimates[[3]]$n_obs, '}',
  '],',
  '"method_metadata":{',
  '"estimator":"', json_escape(result$method_metadata$estimator), '",',
  '"vcov":"', json_escape(result$method_metadata$vcov), '"',
  '},',
  '"diagnostics":{}',
  '}'
)

writeLines(json, "result.json")
