dat <- read.csv("input.csv", stringsAsFactors = FALSE)

dat$date <- as.Date(dat$date)
dat <- dat[order(dat$date), ]

log_vix <- log(dat$vix)
log_sales <- log(dat$sales)
dlog_vix <- c(NA_real_, diff(log_vix))

n_total <- nrow(dat)
sample_idx <- 17:n_total
n_obs <- length(sample_idx)

y <- log_sales[sample_idx]
X <- cbind(
  intercept = 1,
  lag_1 = dlog_vix[sample_idx - 1],
  lag_2 = dlog_vix[sample_idx - 2],
  lag_3 = dlog_vix[sample_idx - 3],
  lag_4 = dlog_vix[sample_idx - 4],
  lag_5 = dlog_vix[sample_idx - 5],
  lag_6 = dlog_vix[sample_idx - 6],
  lag_7 = dlog_vix[sample_idx - 7],
  lag_8 = dlog_vix[sample_idx - 8],
  lag_9 = dlog_vix[sample_idx - 9],
  lag_10 = dlog_vix[sample_idx - 10],
  lag_11 = dlog_vix[sample_idx - 11],
  lag_12 = dlog_vix[sample_idx - 12],
  lag_13 = dlog_vix[sample_idx - 13],
  lag_14 = dlog_vix[sample_idx - 14],
  lag_15 = dlog_vix[sample_idx - 15]
)

fit <- lm.fit(x = X, y = y)
beta <- fit$coefficients
resid <- fit$residuals

bread <- solve(crossprod(X))
scores <- X * resid
meat <- crossprod(scores)

max_lag <- 15L
for (j in seq_len(max_lag)) {
  weight <- 1 - j / 16
  cross_term <- crossprod(
    scores[(j + 1):n_obs, , drop = FALSE],
    scores[1:(n_obs - j), , drop = FALSE]
  )
  meat <- meat + weight * (cross_term + t(cross_term))
}

vcov_nw <- bread %*% meat %*% bread
vcov_nw <- vcov_nw * n_obs / (n_obs - 16)
se <- sqrt(diag(vcov_nw))

cumulative_response <- sum(beta[paste0("lag_", 1:15)])

results <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(
      term = "cumulative_response",
      estimate = unname(cumulative_response),
      se = unname(sqrt(sum(vcov_nw[2:16, 2:16]))),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "lag_1",
      estimate = unname(beta["lag_1"]),
      se = unname(se["lag_1"]),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "lag_15",
      estimate = unname(beta["lag_15"]),
      se = unname(se["lag_15"]),
      n_obs = as.integer(n_obs)
    )
  ),
  method_metadata = list(
    estimator = "OLS with intercept and trading-observation lags 1 through 15",
    vcov = "Newey-West HAC, maximum lag 15, Bartlett weights, scaled by N/(N-16)"
  ),
  diagnostics = list()
)

json_scalar <- function(x) {
  if (length(x) == 0L || is.na(x) || !is.finite(x)) "null" else format(x, digits = 17, scientific = FALSE)
}

json_text <- function(x) {
  paste0("\"", gsub("\"", "\\\\\"", x, fixed = TRUE), "\"")
}

estimate_json <- function(x) {
  paste0(
    "{\"term\":", json_text(x$term),
    ",\"estimate\":", json_scalar(x$estimate),
    ",\"se\":", json_scalar(x$se),
    ",\"n_obs\":", x$n_obs, "}"
  )
}

output <- paste0(
  "{",
  "\"task_id\":\"applied_cumulative_hac\",",
  "\"platform\":\"r\",",
  "\"estimates\":[",
  paste(vapply(results$estimates, estimate_json, character(1)), collapse = ","),
  "],",
  "\"method_metadata\":{",
  "\"estimator\":", json_text(results$method_metadata$estimator), ",",
  "\"vcov\":", json_text(results$method_metadata$vcov),
  "},",
  "\"diagnostics\":{}",
  "}"
)

writeLines(output, "result.json")
