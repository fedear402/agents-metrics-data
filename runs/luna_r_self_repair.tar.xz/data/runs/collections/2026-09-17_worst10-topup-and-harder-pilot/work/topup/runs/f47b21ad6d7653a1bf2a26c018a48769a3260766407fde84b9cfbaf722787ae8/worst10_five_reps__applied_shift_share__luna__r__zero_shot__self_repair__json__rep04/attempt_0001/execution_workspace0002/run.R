dat <- read.csv("input.csv", stringsAsFactors = FALSE, check.names = FALSE)

required <- c("region_id", "industry_id", "share", "shock",
              "region_weight", "x", "y")
if (!all(required %in% names(dat))) {
  stop("input.csv is missing required columns")
}

region_ids <- unique(dat$region_id)
industry_ids <- unique(dat$industry_id)

region_index <- match(dat$region_id, region_ids)
industry_index <- match(dat$industry_id, industry_ids)

region_rows <- match(region_ids, dat$region_id)
region_weight <- as.numeric(dat$region_weight[region_rows])
e <- region_weight / sum(region_weight)

R <- length(region_ids)
N_all <- length(industry_ids)

share_matrix <- matrix(0, nrow = R, ncol = N_all)

for (i in seq_len(nrow(dat))) {
  share_matrix[region_index[i], industry_index[i]] <-
    share_matrix[region_index[i], industry_index[i]] + as.numeric(dat$share[i])
}

shock_by_industry <- numeric(N_all)
for (j in seq_len(N_all)) {
  vals <- as.numeric(dat$shock[industry_index == j])
  shock_by_industry[j] <- vals[which(is.finite(vals))[1]]
}

x_region <- as.numeric(dat$x[region_rows])
y_region <- as.numeric(dat$y[region_rows])

z_region <- drop(share_matrix %*% shock_by_industry)

weighted_mean <- function(v, w) {
  sum(w * v) / sum(w)
}

y0 <- y_region - weighted_mean(y_region, e)
x0 <- x_region - weighted_mean(x_region, e)
z0 <- z_region - weighted_mean(z_region, e)

s_all <- drop(crossprod(e, share_matrix))
keep <- is.finite(s_all) & s_all > 0 &
  is.finite(shock_by_industry)

s <- s_all[keep]
shock <- shock_by_industry[keep]
share_kept <- share_matrix[, keep, drop = FALSE]

aggregate_residual <- function(v0) {
  drop(crossprod(e * v0, share_kept)) / s
}

ybar <- aggregate_residual(y0)
xbar <- aggregate_residual(x0)
zbar <- aggregate_residual(z0)

valid <- is.finite(s) & is.finite(shock) &
  is.finite(ybar) & is.finite(xbar) & is.finite(zbar)

s <- s[valid]
shock <- shock[valid]
ybar <- ybar[valid]
xbar <- xbar[valid]
zbar <- zbar[valid]

weighted_iv <- function(y, endogenous, instrument, w) {
  X <- cbind(1, endogenous)
  Z <- cbind(1, instrument)

  zwz <- crossprod(Z, w * Z)
  zwx <- crossprod(Z, w * X)
  zwy <- crossprod(Z, w * y)

  Xhat <- Z %*% solve(zwz, zwx)
  beta <- solve(crossprod(Xhat, w * Xhat),
                crossprod(Xhat, w * y))

  residual <- drop(y - X %*% beta)
  bread <- crossprod(Xhat, w * Xhat)
  meat <- crossprod(Xhat, (w^2 * residual^2) * Xhat)
  vcov <- solve(bread, meat) %*% solve(bread)
  vcov <- vcov * length(y) / (length(y) - 2)

  list(beta = drop(beta), vcov = vcov)
}

n_obs <- length(s)

if (n_obs <= 2) {
  stop("HC1 variance requires more than two industries")
}

effect_fit <- weighted_iv(ybar, xbar, shock, s)
first_stage_fit <- weighted_iv(xbar, zbar, shock, s)

effect_estimate <- effect_fit$beta[2]
effect_se <- sqrt(effect_fit$vcov[2, 2])

first_stage_estimate <- first_stage_fit$beta[2]
first_stage_se <- sqrt(first_stage_fit$vcov[2, 2])

effective_shocks <- 1 / sum(s^2)

if (!all(is.finite(c(effect_estimate, effect_se,
                     first_stage_estimate, first_stage_se,
                     effective_shocks)))) {
  stop("Non-finite estimate or standard error")
}

json_num <- function(x) {
  formatC(x, format = "fg", digits = 15, flag = "#")
}

result <- paste0(
  "{\n",
  '  "task_id": "applied_shift_share",', "\n",
  '  "platform": "r",', "\n",
  '  "estimates": [', "\n",
  '    {"term": "effect", "estimate": ', json_num(effect_estimate),
  ', "se": ', json_num(effect_se), ', "n_obs": ', n_obs, "},\n",
  '    {"term": "first_stage", "estimate": ', json_num(first_stage_estimate),
  ', "se": ', json_num(first_stage_se), ', "n_obs": ', n_obs, "},\n",
  '    {"term": "effective_shocks", "estimate": ', json_num(effective_shocks),
  ', "se": null, "n_obs": ', n_obs, "}", "\n",
  "  ],\n",
  '  "method_metadata": {"estimator": "shock-level weighted 2SLS", "vcov": "shock-level HC1 with variance multiplier N/(N-2)"},', "\n",
  '  "diagnostics": {}', "\n",
  "}\n"
)

writeLines(result, "result.json")
