d <- read.csv("input.csv")

d$y <- ordered(d$y, levels = c(1, 2, 3))

fit <- MASS::polr(
  y ~ x + z,
  data = d,
  method = "logistic",
  Hess = TRUE,
  control = list(reltol = 1e-12, maxit = 1000)
)

V <- vcov(fit)
beta_x <- unname(coef(fit)["x"])
prob_high <- 1 - plogis(fit$zeta[2] - beta_x)

n_obs <- nrow(d)

result <- list(
  task_id = "broad_ordered_logit",
  platform = "r",
  estimates = list(
    list(
      term = "x",
      estimate = beta_x,
      se = sqrt(V["x", "x"]),
      n_obs = n_obs
    ),
    list(
      term = "z",
      estimate = unname(coef(fit)["z"]),
      se = sqrt(V["z", "z"]),
      n_obs = n_obs
    ),
    list(
      term = "prob_high",
      estimate = unname(prob_high),
      se = NULL,
      n_obs = n_obs
    )
  ),
  method_metadata = list(
    estimator = "maximum-likelihood ordered logit with two free cutpoints and no intercept",
    vcov = "conventional observed-information covariance"
  ),
  diagnostics = list()
)

jsonlite::write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
