dat <- read.csv("input.csv", stringsAsFactors = FALSE)

region_ids <- unique(dat$region_id)
region_rows <- match(region_ids, dat$region_id)
region_weight <- dat$region_weight[region_rows]
e <- region_weight / sum(region_weight)

region_index <- match(dat$region_id, region_ids)
industry_ids <- unique(dat$industry_id)
industry_index <- match(dat$industry_id, industry_ids)

R <- length(region_ids)
N_all <- length(industry_ids)

share_matrix <- matrix(
  0,
  nrow = R,
  ncol = N_all,
  dimnames = list(region_ids, industry_ids)
)

for (i in seq_len(nrow(dat))) {
  share_matrix[region_index[i], industry_index[i]] <-
    share_matrix[region_index[i], industry_index[i]] + dat$share[i]
}

shock_by_industry <- tapply(dat$shock, dat$industry_id, function(v) v[1])
shock_by_industry <- shock_by_industry[industry_ids]

x_region <- dat$x[region_rows]
y_region <- dat$y[region_rows]

z_region <- as.vector(share_matrix %*% shock_by_industry)

weighted_mean <- function(v, w) sum(w * v) / sum(w)

y0 <- y_region - weighted_mean(y_region, e)
x0 <- x_region - weighted_mean(x_region, e)
z0 <- z_region - weighted_mean(z_region, e)

s_all <- as.vector(crossprod(e, share_matrix))
keep <- s_all > 0

s <- s_all[keep]
shock <- shock_by_industry[keep]

aggregate_residual <- function(v0) {
  as.vector(crossprod(e * v0, share_matrix[, keep])) / s
}

ybar <- aggregate_residual(y0)
xbar <- aggregate_residual(x0)
zbar <- aggregate_residual(z0)

iv_fit <- function(y, endogenous, instrument, weights) {
  Q <- cbind(1, endogenous)
  H <- cbind(1, instrument)
  Wsqrt <- sqrt(weights)

  Qw <- Q * Wsqrt
  Hw <- H * Wsqrt
  yw <- y * Wsqrt

  HtH_inv <- solve(crossprod(Hw, Hw))
  PzQ <- Hw %*% HtH_inv %*% crossprod(Hw, Qw)
  Pzy <- Hw %*% HtH_inv %*% crossprod(Hw, yw)

  beta <- solve(crossprod(PzQ, PzQ), crossprod(PzQ, Pzy))
  residual <- y - drop(Q %*% beta)

  A <- crossprod(PzQ, PzQ)
  meat <- crossprod(PzQ * residual, PzQ * residual)
  vcov <- solve(A) %*% meat %*% solve(A)
  vcov <- vcov * length(y) / (length(y) - 2)

  list(beta = drop(beta), vcov = vcov, residual = residual)
}

effect_fit <- iv_fit(
  y = ybar,
  endogenous = xbar,
  instrument = shock,
  weights = s
)

first_stage_fit <- iv_fit(
  y = xbar,
  endogenous = zbar,
  instrument = shock,
  weights = s
)

effective_shocks <- 1 / sum(s^2)
n_obs <- length(s)

result <- sprintf(
  paste0(
    '{\n',
    '  "task_id": "applied_shift_share",\n',
    '  "platform": "r",\n',
    '  "estimates": [\n',
    '    {"term": "effect", "estimate": %.15g, "se": %.15g, "n_obs": %d},\n',
    '    {"term": "first_stage", "estimate": %.15g, "se": %.15g, "n_obs": %d},\n',
    '    {"term": "effective_shocks", "estimate": %.15g, "se": null, "n_obs": %d}\n',
    '  ],\n',
    '  "method_metadata": {"estimator": "shock-level weighted 2SLS", "vcov": "shock-level HC1 with variance multiplier N/(N-2)"},\n',
    '  "diagnostics": {}\n',
    '}\n'
  ),
  effect_fit$beta[2],
  sqrt(effect_fit$vcov[2, 2]),
  n_obs,
  first_stage_fit$beta[2],
  sqrt(first_stage_fit$vcov[2, 2]),
  n_obs,
  effective_shocks,
  n_obs
)

writeLines(result, "result.json")
