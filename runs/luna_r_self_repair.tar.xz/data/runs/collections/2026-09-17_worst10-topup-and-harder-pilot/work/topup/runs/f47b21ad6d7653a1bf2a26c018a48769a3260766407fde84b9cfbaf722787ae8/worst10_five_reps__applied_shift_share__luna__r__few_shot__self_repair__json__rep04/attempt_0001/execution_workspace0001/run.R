library(jsonlite)

dat <- read.csv("input.csv", stringsAsFactors = FALSE)

region_ids <- unique(dat$region_id)
industry_ids <- unique(dat$industry_id)

region_info <- do.call(rbind, lapply(region_ids, function(r) {
  d <- dat[dat$region_id == r, , drop = FALSE]
  c(
    region_id = r,
    region_weight = d$region_weight[1],
    x = d$x[1],
    y = d$y[1]
  )
}))
region_info <- as.data.frame(region_info, stringsAsFactors = FALSE)
region_info$region_weight <- as.numeric(region_info$region_weight)
region_info$x <- as.numeric(region_info$x)
region_info$y <- as.numeric(region_info$y)

e <- region_info$region_weight / sum(region_info$region_weight)

shock_by_industry <- sapply(industry_ids, function(n) {
  dat$shock[dat$industry_id == n][1]
})
names(shock_by_industry) <- industry_ids

z <- sapply(region_ids, function(r) {
  d <- dat[dat$region_id == r, , drop = FALSE]
  sum(d$share * shock_by_industry[as.character(d$industry_id)])
})
z <- as.numeric(z)

weighted_mean <- function(v, w) {
  sum(w * v)
}

y0 <- region_info$y - weighted_mean(region_info$y, e)
x0 <- region_info$x - weighted_mean(region_info$x, e)
z0 <- z - weighted_mean(z, e)

s <- sapply(industry_ids, function(n) {
  d <- dat[dat$industry_id == n, , drop = FALSE]
  sum(e[match(d$region_id, region_ids)] * d$share)
})
names(s) <- industry_ids

used <- s > 0
s_used <- s[used]
shock_used <- shock_by_industry[used]
industry_used <- industry_ids[used]

aggregate_residual <- function(v0) {
  sapply(industry_used, function(n) {
    d <- dat[dat$industry_id == n, , drop = FALSE]
    er <- e[match(d$region_id, region_ids)]
    vr <- v0[match(d$region_id, region_ids)]
    sum(er * d$share * vr) / s[n]
  })
}

ybar <- aggregate_residual(y0)
xbar <- aggregate_residual(x0)
zbar <- aggregate_residual(z0)

shock_level_iv <- function(dependent, endogenous, instrument, weights) {
  regressors <- cbind(1, endogenous)
  instruments <- cbind(1, instrument)

  cross <- crossprod(instruments, weights * regressors)
  beta <- solve(
    cross,
    crossprod(instruments, weights * dependent)
  )

  residual <- drop(dependent - regressors %*% beta)
  scores <- instruments * (weights * residual)
  inverse <- solve(cross)

  n_industries <- length(weights)
  covariance <- n_industries / (n_industries - 2) *
    inverse %*% crossprod(scores) %*% t(inverse)

  c(
    estimate = beta[2],
    se = sqrt(covariance[2, 2])
  )
}

effect_fit <- shock_level_iv(
  dependent = ybar,
  endogenous = xbar,
  instrument = shock_used,
  weights = s_used
)

first_stage_fit <- shock_level_iv(
  dependent = xbar,
  endogenous = zbar,
  instrument = shock_used,
  weights = s_used
)

n_industries <- length(s_used)
effective_shocks <- 1 / sum(s_used^2)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(
      term = "effect",
      estimate = unname(as.numeric(effect_fit["estimate"])),
      se = unname(as.numeric(effect_fit["se"])),
      n_obs = as.integer(n_industries)
    ),
    list(
      term = "first_stage",
      estimate = unname(as.numeric(first_stage_fit["estimate"])),
      se = unname(as.numeric(first_stage_fit["se"])),
      n_obs = as.integer(n_industries)
    ),
    list(
      term = "effective_shocks",
      estimate = as.numeric(effective_shocks),
      se = NULL,
      n_obs = as.integer(n_industries)
    )
  ),
  method_metadata = list(
    estimator = "weighted shock-level IV with intercept",
    vcov = "shock-level HC1, structural IV residuals, analytic weights"
  ),
  diagnostics = list()
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
