library(jsonlite)

d <- read.csv("input.csv", stringsAsFactors = FALSE, check.names = FALSE)

region_id <- unique(d$region_id)
industry_id <- unique(d$industry_id)

R <- length(region_id)
N_all <- length(industry_id)

region_index <- match(d$region_id, region_id)
industry_index <- match(d$industry_id, industry_id)

region_rows <- match(region_id, d$region_id)

region_weight <- d$region_weight[region_rows]
e <- region_weight / sum(region_weight)

x <- d$x[region_rows]
y <- d$y[region_rows]

share_matrix <- matrix(
  0,
  nrow = R,
  ncol = N_all,
  dimnames = list(region_id, industry_id)
)

for (i in seq_len(nrow(d))) {
  share_matrix[region_index[i], industry_index[i]] <-
    share_matrix[region_index[i], industry_index[i]] + d$share[i]
}

shock <- numeric(N_all)

for (n in seq_len(N_all)) {
  shock_values <- d$shock[industry_index == n]
  shock[n] <- shock_values[1]
}

z <- drop(share_matrix %*% shock)

weighted_mean <- function(v, w) {
  sum(w * v)
}

y0 <- y - weighted_mean(y, e)
x0 <- x - weighted_mean(x, e)
z0 <- z - weighted_mean(z, e)

s_all <- drop(crossprod(e, share_matrix))

keep <- s_all > 0

s <- s_all[keep]
shock_used <- shock[keep]

ybar <- drop(crossprod(share_matrix[, keep], e * y0)) / s
xbar <- drop(crossprod(share_matrix[, keep], e * x0)) / s
zbar <- drop(crossprod(share_matrix[, keep], e * z0)) / s

N <- length(s)

shock_iv <- function(dependent, endogenous, instrument, weights) {
  regressors <- cbind(1, endogenous)
  instruments <- cbind(1, instrument)

  cross <- crossprod(instruments, weights * regressors)
  beta <- solve(
    cross,
    crossprod(instruments, weights * dependent)
  )

  residual <- drop(dependent - regressors %*% beta)
  scores <- instruments * (weights * residual)
  inverse <- solve(cross)

  covariance <- N / (N - 2) *
    inverse %*% crossprod(scores) %*% t(inverse)

  c(
    estimate = beta[2],
    se = sqrt(covariance[2, 2])
  )
}

effect <- shock_iv(
  dependent = ybar,
  endogenous = xbar,
  instrument = shock_used,
  weights = s
)

first_stage <- shock_iv(
  dependent = xbar,
  endogenous = zbar,
  instrument = shock_used,
  weights = s
)

effective_shocks <- 1 / sum(s^2)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(
      term = "effect",
      estimate = unname(as.numeric(effect["estimate"])),
      se = unname(as.numeric(effect["se"])),
      n_obs = as.integer(N)
    ),
    list(
      term = "first_stage",
      estimate = unname(as.numeric(first_stage["estimate"])),
      se = unname(as.numeric(first_stage["se"])),
      n_obs = as.integer(N)
    ),
    list(
      term = "effective_shocks",
      estimate = as.numeric(effective_shocks),
      se = NULL,
      n_obs = as.integer(N)
    )
  ),
  method_metadata = list(
    estimator = "Weighted shock-level IV with regional shift-share aggregation",
    vcov = "HC1 exposure-robust shock-level covariance using structural IV residuals"
  ),
  diagnostics = list()
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
