#!/usr/bin/env Rscript

dat <- read.csv("input.csv")

y <- as.integer(dat$y)
X <- as.matrix(dat[, c("x", "z")])
n_obs <- nrow(dat)

inv_logit <- function(v) plogis(v)

neg_loglik <- function(par) {
  beta <- par[1:2]
  c1 <- par[3]
  c2 <- c1 + exp(par[4])
  eta <- drop(X %*% beta)

  p1 <- plogis(c1 - eta)
  p3 <- plogis(eta - c2)
  p2 <- plogis(c2 - eta) - p1

  probs <- ifelse(y == 1L, p1, ifelse(y == 2L, p2, p3))
  if (any(!is.finite(probs)) || any(probs <= 0)) return(1e12)

  -sum(log(probs))
}

start <- c(0, 0, 0, log(1))

fit <- optim(
  par = start,
  fn = neg_loglik,
  method = "BFGS",
  hessian = TRUE,
  control = list(maxit = 10000, reltol = 1e-12)
)

if (fit$convergence != 0) {
  fit <- optim(
    par = fit$par,
    fn = neg_loglik,
    method = "Nelder-Mead",
    control = list(maxit = 20000, reltol = 1e-12)
  )
  fit <- optim(
    par = fit$par,
    fn = neg_loglik,
    method = "BFGS",
    hessian = TRUE,
    control = list(maxit = 10000, reltol = 1e-12)
  )
}

V <- tryCatch(solve(fit$hessian), error = function(e) MASS::ginv(fit$hessian))
se_beta <- sqrt(pmax(diag(V)[1:2], 0))

beta <- fit$par[1:2]
c2 <- fit$par[3] + exp(fit$par[4])
prob_high <- plogis(sum(beta * c(1, 0)) - c2)

result <- list(
  task_id = "broad_ordered_logit",
  platform = "r",
  estimates = list(
    list(
      term = "x",
      estimate = unname(beta[1]),
      se = unname(se_beta[1]),
      n_obs = n_obs
    ),
    list(
      term = "z",
      estimate = unname(beta[2]),
      se = unname(se_beta[2]),
      n_obs = n_obs
    ),
    list(
      term = "prob_high",
      estimate = unname(prob_high),
      se = NULL,
      n_obs = n_obs
    )
  ),
  method_metadata = list(
    estimator = "maximum likelihood ordered logit",
    vcov = "conventional observed information"
  ),
  diagnostics = list()
)

json_escape <- function(x) {
  x <- gsub("\\\\", "\\\\\\\\", x)
  x <- gsub("\"", "\\\\\"", x)
  x
}

num <- function(x) {
  if (is.null(x)) "null" else formatC(x, digits = 15, format = "fg", flag = "#")
}

json <- paste0(
  "{\n",
  '  "task_id": "broad_ordered_logit",\n',
  '  "platform": "r",\n',
  '  "estimates": [\n',
  '    {"term": "x", "estimate": ', num(beta[1]), ', "se": ', num(se_beta[1]), ', "n_obs": ', n_obs, '},\n',
  '    {"term": "z", "estimate": ', num(beta[2]), ', "se": ', num(se_beta[2]), ', "n_obs": ', n_obs, '},\n',
  '    {"term": "prob_high", "estimate": ', num(prob_high), ', "se": null, "n_obs": ', n_obs, '}\n',
  "  ],\n",
  '  "method_metadata": {"estimator": "maximum likelihood ordered logit", "vcov": "conventional observed information"},\n',
  '  "diagnostics": {}\n',
  "}\n"
)

writeLines(json, "result.json")
