#!/usr/bin/env Rscript

dat <- read.csv("input.csv")
dat$y <- as.integer(dat$y)
n <- nrow(dat)

logdiffexp <- function(a, b) {
  a + log1p(-exp(b - a))
}

negloglik <- function(par) {
  beta <- par[1:2]
  c1 <- par[3]
  c2 <- c1 + exp(par[4])
  eta <- beta[1] * dat$x + beta[2] * dat$z

  lp1 <- plogis(c1 - eta, log.p = TRUE)
  lp3 <- plogis(eta - c2, log.p = TRUE)
  lF1 <- plogis(c1 - eta, log.p = TRUE)
  lF2 <- plogis(c2 - eta, log.p = TRUE)
  lp2 <- logdiffexp(lF2, lF1)

  ll <- ifelse(dat$y == 1L, lp1,
               ifelse(dat$y == 2L, lp2, lp3))

  if (any(!is.finite(ll))) return(1e100)
  -sum(ll)
}

y_tab <- table(dat$y)
p1 <- max(0.05, min(0.95, as.numeric(y_tab["1"]) / n))
p12 <- max(0.10, min(0.90, sum(dat$y <= 2) / n))

starts <- list(
  c(0, 0, qlogis(p1), log(max(0.2, qlogis(p12) - qlogis(p1)))),
  c(0.2, -0.2, -0.5, 0),
  c(-0.2, 0.2, 0.5, 0)
)

fits <- lapply(starts, function(s) {
  optim(
    par = s,
    fn = negloglik,
    method = "BFGS",
    hessian = TRUE,
    control = list(maxit = 5000, reltol = 1e-12)
  )
})

fit <- fits[[which.min(vapply(fits, `[[`, numeric(1), "value"))]]
par_hat <- fit$par
beta_hat <- par_hat[1:2]
cut2_hat <- par_hat[3] + exp(par_hat[4])

H <- fit$hessian
V <- tryCatch(solve(H), error = function(e) MASS::ginv(H))
se_hat <- sqrt(pmax(0, diag(V)))[1:2]

eta_high <- beta_hat[1]
prob_high <- plogis(eta_high - cut2_hat)

out <- list(
  task_id = "broad_ordered_logit",
  platform = "r",
  estimates = list(
    list(term = "x", estimate = unname(beta_hat[1]),
         se = unname(se_hat[1]), n_obs = n),
    list(term = "z", estimate = unname(beta_hat[2]),
         se = unname(se_hat[2]), n_obs = n),
    list(term = "prob_high", estimate = unname(prob_high),
         se = NULL, n_obs = n)
  ),
  method_metadata = list(
    estimator = "Maximum likelihood ordered logit with two free cutpoints and no intercept",
    vcov = "Conventional observed-information covariance from the numerical Hessian"
  ),
  diagnostics = list()
)

if (requireNamespace("jsonlite", quietly = TRUE)) {
  jsonlite::write_json(out, "result.json", auto_unbox = TRUE, digits = 15)
} else {
  esc <- function(x) gsub('"', '\\"', x, fixed = TRUE)
  txt <- paste0(
    '{"task_id":"', out$task_id,
    '","platform":"r","estimates":[',
    '{"term":"x","estimate":', format(out$estimates[[1]]$estimate, digits = 15),
    ',"se":', format(out$estimates[[1]]$se, digits = 15), ',"n_obs":', n, '},',
    '{"term":"z","estimate":', format(out$estimates[[2]]$estimate, digits = 15),
    ',"se":', format(out$estimates[[2]]$se, digits = 15), ',"n_obs":', n, '},',
    '{"term":"prob_high","estimate":', format(prob_high, digits = 15),
    ',"se":null,"n_obs":', n, '}],',
    '"method_metadata":{"estimator":"Maximum likelihood ordered logit with two free cutpoints and no intercept",',
    '"vcov":"Conventional observed-information covariance from the numerical Hessian"},',
    '"diagnostics":{}}'
  )
  writeLines(txt, "result.json")
}
