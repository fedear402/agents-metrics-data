#!/usr/bin/env Rscript

dat <- read.csv("input.csv")

y <- dat$y
X <- cbind(const = 1, x = dat$x, z = dat$z)
n <- nrow(dat)

loglik <- function(theta) {
  beta <- theta[1:3]
  sigma <- exp(theta[4])
  mu <- drop(X %*% beta)
  
  positive <- y > 0
  ll <- numeric(n)
  
  ll[positive] <- dnorm(
    (y[positive] - mu[positive]) / sigma,
    log = TRUE
  ) - log(sigma)
  
  ll[!positive] <- pnorm(
    -mu[!positive] / sigma,
    log.p = TRUE
  )
  
  if (any(!is.finite(ll))) return(-Inf)
  sum(ll)
}

objective <- function(theta) {
  value <- loglik(theta)
  if (!is.finite(value)) return(1e100)
  -value
}

ols_fit <- lm(y ~ x + z, data = dat)
beta_start <- coef(ols_fit)
beta_start[is.na(beta_start)] <- 0
sigma_start <- sd(residuals(ols_fit))
if (!is.finite(sigma_start) || sigma_start <= 0) sigma_start <- sd(y[y > 0])
if (!is.finite(sigma_start) || sigma_start <= 0) sigma_start <- 1

start <- c(beta_start, log(sigma_start))

fit <- optim(
  par = start,
  fn = objective,
  method = "BFGS",
  hessian = TRUE,
  control = list(maxit = 10000, reltol = 1e-12)
)

if (fit$convergence != 0) {
  fit_nm <- optim(
    par = fit$par,
    fn = objective,
    method = "Nelder-Mead",
    control = list(maxit = 20000, reltol = 1e-12)
  )
  fit <- optim(
    par = fit_nm$par,
    fn = objective,
    method = "BFGS",
    hessian = TRUE,
    control = list(maxit = 10000, reltol = 1e-12)
  )
}

theta_hat <- fit$par
beta_hat <- theta_hat[1:3]
sigma_hat <- exp(theta_hat[4])

H <- fit$hessian
vcov_theta <- solve(H)
se_beta <- sqrt(pmax(diag(vcov_theta)[1:3], 0))

estimates <- list(
  list(term = "const", estimate = unname(beta_hat[1]), se = unname(se_beta[1]), n_obs = n),
  list(term = "x", estimate = unname(beta_hat[2]), se = unname(se_beta[2]), n_obs = n),
  list(term = "z", estimate = unname(beta_hat[3]), se = unname(se_beta[3]), n_obs = n),
  list(term = "sigma", estimate = unname(sigma_hat), se = NULL, n_obs = n)
)

result <- list(
  task_id = "broad_tobit",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "Homoskedastic Gaussian Tobit maximum likelihood",
    vcov = "Inverse jointly estimated observed information matrix"
  ),
  diagnostics = list()
)

if (requireNamespace("jsonlite", quietly = TRUE)) {
  jsonlite::write_json(
    result,
    "result.json",
    auto_unbox = TRUE,
    digits = 17,
    pretty = TRUE,
    null = "null"
  )
} else {
  esc <- function(x) {
    if (is.null(x)) return("null")
    if (is.character(x)) return(sprintf("\"%s\"", x))
    format(x, digits = 17, scientific = FALSE, trim = TRUE)
  }
  
  lines <- c(
    "{",
    '  "task_id": "broad_tobit",',
    '  "platform": "r",',
    '  "estimates": ['
  )
  
  for (i in seq_along(estimates)) {
    e <- estimates[[i]]
    comma <- if (i < length(estimates)) "," else ""
    lines <- c(
      lines,
      sprintf(
        '    {"term": "%s", "estimate": %s, "se": %s, "n_obs": %d}%s',
        e$term, esc(e$estimate), esc(e$se), e$n_obs, comma
      )
    )
  }
  
  lines <- c(
    lines,
    "  ],",
    '  "method_metadata": {"estimator": "Homoskedastic Gaussian Tobit maximum likelihood", "vcov": "Inverse jointly estimated observed information matrix"},',
    '  "diagnostics": {}',
    "}"
  )
  
  writeLines(lines, "result.json")
}
