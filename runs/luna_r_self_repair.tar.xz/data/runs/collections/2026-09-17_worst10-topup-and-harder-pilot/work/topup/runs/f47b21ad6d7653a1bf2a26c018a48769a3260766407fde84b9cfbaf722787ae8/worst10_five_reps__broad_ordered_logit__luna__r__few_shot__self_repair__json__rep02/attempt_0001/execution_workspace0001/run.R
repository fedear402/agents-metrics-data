#!/usr/bin/env Rscript

options(stringsAsFactors = FALSE)

if (!requireNamespace("MASS", quietly = TRUE)) {
  stop("Package MASS is required.")
}
if (!requireNamespace("jsonlite", quietly = TRUE)) {
  stop("Package jsonlite is required.")
}

d <- read.csv("input.csv")

required <- c("id", "y", "x", "z")
if (!all(required %in% names(d))) {
  stop("input.csv must contain id, y, x, and z.")
}

if (anyNA(d[, c("y", "x", "z")])) {
  stop("Missing values are not allowed.")
}

d$y <- ordered(d$y, levels = c(1, 2, 3))
n_obs <- nrow(d)

fit <- MASS::polr(
  y ~ x + z,
  data = d,
  method = "logistic",
  Hess = TRUE,
  na.action = na.fail,
  control = list(reltol = 1e-12, maxit = 1000)
)

V <- vcov(fit)
beta <- coef(fit)
se <- sqrt(diag(V))

eta <- unname(beta["x"])
prob_high <- plogis(eta - unname(fit$zeta[2]))

result <- list(
  task_id = "broad_ordered_logit",
  platform = "r",
  estimates = list(
    list(
      term = "x",
      estimate = unname(beta["x"]),
      se = unname(se["x"]),
      n_obs = n_obs
    ),
    list(
      term = "z",
      estimate = unname(beta["z"]),
      se = unname(se["z"]),
      n_obs = n_obs
    ),
    list(
      term = "prob_high",
      estimate = prob_high,
      se = NULL,
      n_obs = n_obs
    )
  ),
  method_metadata = list(
    estimator = "maximum-likelihood ordered logistic regression",
    vcov = "conventional observed-information covariance"
  ),
  diagnostics = list()
)

jsonlite::write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
