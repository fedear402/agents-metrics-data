dat <- read.csv("input.csv")

y <- dat$y
endog <- dat$endog
x <- dat$x
z1 <- dat$z1
z2 <- dat$z2

n <- nrow(dat)
df_num <- 2
df_den <- n - 4

X_r <- cbind(1, x)
X_u <- cbind(1, x, z1, z2)

fit_r <- lm.fit(X_r, y)
fit_u <- lm.fit(X_u, y)

M_r <- diag(n) - X_r %*% qr.solve(crossprod(X_r), t(X_r))
M_u <- diag(n) - X_u %*% qr.solve(crossprod(X_u), t(X_u))

a <- as.vector(M_r %*% endog)
b <- as.vector(M_r %*% y)
c <- as.vector(M_u %*% endog)
d <- as.vector(M_u %*% y)

rss_r <- function(beta) sum((b - beta * a)^2)
rss_u <- function(beta) sum((d - beta * c)^2)

f_critical <- qf(0.95, df_num, df_den)

ar_f <- function(beta) {
  ru <- rss_u(beta)
  ((rss_r(beta) - ru) / df_num) / (ru / df_den)
}

k <- 1 + df_num * f_critical / df_den

poly_coef <- c(
  sum(a^2) - k * sum(c^2),
  -2 * sum(a * b) + 2 * k * sum(c * d),
  sum(b^2) - k * sum(d^2)
)

roots <- polyroot(poly_coef)
tol <- 1e-7 * max(1, abs(Re(roots)))
real_roots <- sort(Re(roots[abs(Im(roots)) <= tol]))

finite_roots <- real_roots[is.finite(real_roots)]

if (length(finite_roots) >= 2) {
  boundary_low <- finite_roots[1]
  boundary_high <- finite_roots[length(finite_roots)]
} else {
  boundary_low <- NA_real_
  boundary_high <- NA_real_
}

if (length(finite_roots) >= 2) {
  test_points <- c(
    boundary_low - max(1, abs(boundary_low) * 0.01),
    (boundary_low + boundary_high) / 2,
    boundary_high + max(1, abs(boundary_high) * 0.01)
  )
  point_accept <- vapply(
    test_points,
    function(beta) is.finite(ar_f(beta)) && ar_f(beta) <= f_critical,
    logical(1)
  )
  unbounded <- as.numeric(point_accept[1] || point_accept[3])
} else {
  unbounded <- 1
}

accepts_zero <- as.numeric(is.finite(ar_f(0)) && ar_f(0) <= f_critical)
ar_f_at_one <- ar_f(1)

estimate_row <- function(term, estimate) {
  list(
    term = term,
    estimate = as.numeric(estimate),
    se = NULL,
    n_obs = as.integer(n)
  )
}

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = list(
    estimate_row("boundary_low", boundary_low),
    estimate_row("boundary_high", boundary_high),
    estimate_row("accepts_zero", accepts_zero),
    estimate_row("unbounded", unbounded),
    estimate_row("ar_f_at_one", ar_f_at_one)
  ),
  method_metadata = list(
    estimator = "Anderson-Rubin confidence set with conventional homoskedastic joint F test",
    vcov = "conventional homoskedastic"
  ),
  diagnostics = list()
)

json_escape <- function(x) {
  x <- gsub("\\\\", "\\\\\\\\", x)
  gsub('"', '\\"', x, fixed = TRUE)
}

to_json <- function(obj) {
  if (is.null(obj)) return("null")

  if (is.character(obj) && length(obj) == 1) {
    return(paste0('"', json_escape(obj), '"'))
  }

  if (is.numeric(obj) && length(obj) == 1) {
    if (is.na(obj) || !is.finite(obj)) return("null")
    return(format(obj, digits = 17, scientific = TRUE, trim = TRUE))
  }

  if (is.integer(obj) && length(obj) == 1) {
    return(as.character(obj))
  }

  if (is.logical(obj) && length(obj) == 1) {
    return(if (obj) "true" else "false")
  }

  if (is.list(obj)) {
    nm <- names(obj)

    if (is.null(nm) || any(is.na(nm)) || any(nm == "")) {
      return(paste0("[", paste(vapply(obj, to_json, character(1)), collapse = ","), "]"))
    }

    parts <- vapply(
      seq_along(obj),
      function(i) paste0('"', json_escape(nm[i]), '":', to_json(obj[[i]])),
      character(1)
    )
    return(paste0("{", paste(parts, collapse = ","), "}"))
  }

  stop("Unsupported JSON type")
}

writeLines(to_json(result), "result.json")
