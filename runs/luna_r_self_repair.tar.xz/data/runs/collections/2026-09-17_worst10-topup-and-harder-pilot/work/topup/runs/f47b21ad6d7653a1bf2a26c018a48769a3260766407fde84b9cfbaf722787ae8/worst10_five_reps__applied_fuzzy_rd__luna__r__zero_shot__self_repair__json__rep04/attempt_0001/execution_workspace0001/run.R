#!/usr/bin/env Rscript

dat <- read.csv("input.csv", stringsAsFactors = FALSE)

keep <- is.finite(dat$score) &
  is.finite(dat$participated) &
  is.finite(dat$earnings) &
  abs(dat$score) < 1

d <- dat[keep, , drop = FALSE]
n_obs <- nrow(d)

x <- d$score
right <- as.numeric(x >= 0)
z <- cbind(1, right, x, right * x)
w <- 1 - abs(x)

fit_hc0 <- function(y, X, weights) {
  sw <- sqrt(weights)
  Xw <- X * sw
  yw <- y * sw

  beta <- solve(crossprod(Xw), crossprod(Xw, yw))
  resid <- y - drop(X %*% beta)

  bread <- solve(crossprod(Xw))
  meat <- crossprod(X * (weights * resid))
  vcov <- bread %*% meat %*% bread

  list(beta = drop(beta), vcov = vcov, residuals = resid)
}

fit_rf <- fit_hc0(d$earnings, z, w)
fit_fs <- fit_hc0(d$participated, z, w)

reduced_form <- fit_rf$beta[2]
first_stage <- fit_fs$beta[2]

var_rf <- fit_rf$vcov[2, 2]
var_fs <- fit_fs$vcov[2, 2]

cross_meat <- crossprod(z * (w * fit_rf$residuals),
                        z * (w * fit_fs$residuals))
bread <- solve(crossprod(z * sqrt(w)))
cov_rf_fs <- (bread %*% cross_meat %*% bread)[2, 2]

treatment_effect <- reduced_form / first_stage
gradient <- c(1 / first_stage,
              -reduced_form / first_stage^2)

var_te <- gradient[1]^2 * var_rf +
  gradient[2]^2 * var_fs +
  2 * gradient[1] * gradient[2] * cov_rf_fs

se_te <- sqrt(max(var_te, 0))

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(
      term = "treatment_effect",
      estimate = unname(treatment_effect),
      se = unname(se_te),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "reduced_form",
      estimate = unname(reduced_form),
      se = unname(sqrt(max(var_rf, 0))),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "first_stage",
      estimate = unname(first_stage),
      se = unname(sqrt(max(var_fs, 0))),
      n_obs = as.integer(n_obs)
    )
  ),
  method_metadata = list(
    estimator = "Fuzzy local-linear regression discontinuity with triangular weights",
    vcov = "Conventional heteroskedasticity-robust HC0 with joint delta method covariance"
  ),
  diagnostics = list()
)

json_escape <- function(x) {
  x <- gsub("\\\\", "\\\\\\\\", x)
  x <- gsub('"', '\\"', x, fixed = TRUE)
  x
}

num <- function(x) {
  if (length(x) == 0 || is.na(x) || !is.finite(x)) "null"
  else format(x, digits = 17, scientific = FALSE, trim = TRUE)
}

json <- paste0(
  '{',
  '"task_id":"', json_escape(result$task_id), '",',
  '"platform":"', result$platform, '",',
  '"estimates":[',
  paste(
    vapply(result$estimates, function(e) paste0(
      '{"term":"', e$term,
      '","estimate":', num(e$estimate),
      ',"se":', num(e$se),
      ',"n_obs":', e$n_obs, '}'
    ), character(1)),
    collapse = ","
  ),
  '],',
  '"method_metadata":{',
  '"estimator":"', json_escape(result$method_metadata$estimator),
  '","vcov":"', json_escape(result$method_metadata$vcov),
  '"},',
  '"diagnostics":{}',
  '}'
)

writeLines(json, "result.json")
