library(jsonlite)

dat <- read.csv("input.csv", stringsAsFactors = FALSE, check.names = FALSE)

region_ids <- unique(dat$region_id)
industry_ids <- unique(dat$industry_id)

region_row <- match(region_ids, dat$region_id)
region_data <- dat[region_row, , drop = FALSE]

e <- as.numeric(region_data$region_weight)
e <- e / sum(e)

region_index <- match(dat$region_id, region_ids)
industry_index <- match(dat$industry_id, industry_ids)

z <- numeric(length(region_ids))
for (r in seq_along(region_ids)) {
  rows <- which(region_index == r)
  z[r] <- sum(dat$share[rows] * dat$shock[rows])
}

x <- as.numeric(region_data$x)
y <- as.numeric(region_data$y)

weighted_mean <- function(v, w) {
  sum(w * v)
}

y0 <- y - weighted_mean(y, e)
x0 <- x - weighted_mean(x, e)
z0 <- z - weighted_mean(z, e)

n_industries_all <- length(industry_ids)
s <- numeric(n_industries_all)
ybar <- numeric(n_industries_all)
xbar <- numeric(n_industries_all)
zbar <- numeric(n_industries_all)
shock <- numeric(n_industries_all)

for (j in seq_len(n_industries_all)) {
  rows <- which(industry_index == j)
  r <- region_index[rows]
  masses <- e[r] * dat$share[rows]

  s[j] <- sum(masses)
  shock[j] <- dat$shock[rows[1]]

  if (s[j] > 0) {
    ybar[j] <- sum(masses * y0[r]) / s[j]
    xbar[j] <- sum(masses * x0[r]) / s[j]
    zbar[j] <- sum(masses * z0[r]) / s[j]
  } else {
    ybar[j] <- NA_real_
    xbar[j] <- NA_real_
    zbar[j] <- NA_real_
  }
}

keep <- is.finite(s) &
  s > 0 &
  is.finite(shock) &
  is.finite(ybar) &
  is.finite(xbar) &
  is.finite(zbar)

s <- s[keep]
shock <- shock[keep]
ybar <- ybar[keep]
xbar <- xbar[keep]
zbar <- zbar[keep]

n_industries <- length(s)

shock_iv <- function(dependent, endogenous, instrument, weights) {
  regressors <- cbind(1, endogenous)
  instruments <- cbind(1, instrument)

  weighted_regressors <- regressors * weights
  cross <- crossprod(instruments, weighted_regressors)
  rhs <- crossprod(instruments, weights * dependent)

  beta <- solve(cross, rhs)
  residual <- as.numeric(dependent - regressors %*% beta)

  scores <- instruments * (weights * residual)
  inverse_cross <- solve(cross)

  covariance <- (n_industries / (n_industries - 2)) *
    inverse_cross %*% crossprod(scores) %*% t(inverse_cross)

  list(
    estimate = as.numeric(beta[2]),
    se = sqrt(as.numeric(covariance[2, 2]))
  )
}

effect <- shock_iv(ybar, xbar, shock, s)
first_stage <- shock_iv(xbar, zbar, shock, s)
effective_shocks <- 1 / sum(s^2)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(
      term = "effect",
      estimate = effect$estimate,
      se = effect$se,
      n_obs = as.integer(n_industries)
    ),
    list(
      term = "first_stage",
      estimate = first_stage$estimate,
      se = first_stage$se,
      n_obs = as.integer(n_industries)
    ),
    list(
      term = "effective_shocks",
      estimate = as.numeric(effective_shocks),
      se = NULL,
      n_obs = as.integer(n_industries)
    )
  ),
  method_metadata = list(
    estimator = "Weighted shock-level IV with intercept",
    vcov = "Borusyak-Hull-Jaravel exposure-robust HC1, multiplier N/(N-2)"
  ),
  diagnostics = list()
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
