dat <- read.csv("input.csv")
n <- nrow(dat)

y <- dat$y
endog <- dat$endog
x <- dat$x
z1 <- dat$z1
z2 <- dat$z2

Xr <- cbind(1, x)
Xu <- cbind(1, x, z1, z2)

qr <- qr(Xr)
qu <- qr(Xu)

Mr <- diag(n) - qr.Q(qr) %*% t(qr.Q(qr))
Mu <- diag(n) - qr.Q(qu) %*% t(qr.Q(qu))
D <- Mr - Mu

ssr_diff <- function(beta) {
  v <- y - beta * endog
  as.numeric(crossprod(v, D %*% v))
}

ssr_full <- function(beta) {
  v <- y - beta * endog
  as.numeric(crossprod(v, Mu %*% v))
}

d0 <- ssr_diff(0)
d1 <- (ssr_diff(1) - d0)
d2 <- (ssr_diff(2) - d0 - 2 * d1) / 2

u0 <- ssr_full(0)
u1 <- ssr_full(1) - u0
u2 <- (ssr_full(2) - u0 - 2 * u1) / 2

f_crit <- qf(0.95, df1 = 2, df2 = n - 4)

a <- (n - 4) * d2 - 2 * f_crit * u2
b <- (n - 4) * d1 - 2 * f_crit * u1
c <- (n - 4) * d0 - 2 * f_crit * u0

tol <- 1e-10 * max(1, abs(a), abs(b), abs(c))

if (abs(a) <= tol) {
  if (abs(b) <= tol) {
    roots <- c(-Inf, Inf)
  } else {
    r <- -c / b
    roots <- if (b > 0) c(-Inf, r) else c(r, Inf)
  }
} else {
  disc <- b^2 - 4 * a * c
  if (disc < 0 && disc > -tol) disc <- 0

  if (disc < 0) {
    if (a < 0) roots <- c(-Inf, Inf) else roots <- c(NA_real_, NA_real_)
  } else {
    r1 <- (-b - sqrt(disc)) / (2 * a)
    r2 <- (-b + sqrt(disc)) / (2 * a)
    roots <- sort(c(r1, r2))
  }
}

boundary_low <- roots[1]
boundary_high <- roots[2]

poly_value <- function(beta) a * beta^2 + b * beta + c
accepts_zero <- as.integer(poly_value(0) <= tol)

if (abs(a) <= tol && abs(b) <= tol) {
  unbounded <- as.integer(c <= tol)
} else if (abs(a) <= tol) {
  unbounded <- 1L
} else {
  unbounded <- as.integer(a < 0)
}

ar_f_at_one <- ssr_diff(1) / 2 / (ssr_full(1) / (n - 4))

estimates <- list(
  list(term = "boundary_low", estimate = boundary_low, se = NA_real_, n_obs = n),
  list(term = "boundary_high", estimate = boundary_high, se = NA_real_, n_obs = n),
  list(term = "accepts_zero", estimate = as.numeric(accepts_zero), se = NA_real_, n_obs = n),
  list(term = "unbounded", estimate = as.numeric(unbounded), se = NA_real_, n_obs = n),
  list(term = "ar_f_at_one", estimate = ar_f_at_one, se = NA_real_, n_obs = n)
)

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "Anderson-Rubin confidence set using homoskedastic joint F test",
    vcov = "conventional homoskedastic"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, na = "null", digits = 17)
