dat <- read.csv("input.csv")

y <- dat$y
endog <- dat$endog
x <- dat$x
z1 <- dat$z1
z2 <- dat$z2

n <- nrow(dat)
df_num <- 2
df_den <- n - 4

X_r <- cbind(1, x)
X_u <- cbind(1, x, z1, z2)

rss_at_beta <- function(beta, X) {
  q <- y - beta * endog
  fit <- lm.fit(X, q)
  sum(fit$residuals^2)
}

f_critical <- qf(0.95, df_num, df_den)

rss_r <- function(beta) rss_at_beta(beta, X_r)
rss_u <- function(beta) rss_at_beta(beta, X_u)

ar_f <- function(beta) {
  ru <- rss_u(beta)
  ((rss_r(beta) - ru) / df_num) / (ru / df_den)
}

# Construct the AR inversion polynomial:
# RSS_restricted(beta) - k * RSS_unrestricted(beta) <= 0
k <- 1 + df_num * f_critical / df_den

qr <- qr(X_r)
qu <- qr(X_u)

Mr <- diag(n) - X_r %*% solve(crossprod(X_r), t(X_r))
Mu <- diag(n) - X_u %*% solve(crossprod(X_u), t(X_u))

a_vec <- Mr %*% endog
b_vec <- Mr %*% y
c_vec <- Mu %*% endog
d_vec <- Mu %*% y

poly_coef <- c(
  sum(a_vec^2) - k * sum(c_vec^2),
  -2 * sum(a_vec * b_vec) + 2 * k * sum(c_vec * d_vec),
  sum(b_vec^2) - k * sum(d_vec^2)
)

roots <- polyroot(poly_coef)
real_roots <- sort(Re(roots[abs(Im(roots)) < 1e-8]))

if (length(real_roots) < 2) {
  boundary_low <- NA_real_
  boundary_high <- NA_real_
  unbounded <- 1
} else {
  boundary_low <- real_roots[1]
  boundary_high <- real_roots[length(real_roots)]

  test_points <- c(
    boundary_low - 1,
    mean(c(boundary_low, boundary_high)),
    boundary_high + 1
  )
  accepted <- vapply(test_points, function(b) {
    is.finite(ar_f(b)) && ar_f(b) <= f_critical
  }, logical(1))
  unbounded <- as.numeric(accepted[1] || accepted[3])
}

accepts_zero <- as.numeric(ar_f(0) <= f_critical)
ar_f_at_one <- ar_f(1)

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = list(
    list(term = "boundary_low", estimate = as.numeric(boundary_low),
         se = NULL, n_obs = n),
    list(term = "boundary_high", estimate = as.numeric(boundary_high),
         se = NULL, n_obs = n),
    list(term = "accepts_zero", estimate = as.numeric(accepts_zero),
         se = NULL, n_obs = n),
    list(term = "unbounded", estimate = as.numeric(unbounded),
         se = NULL, n_obs = n),
    list(term = "ar_f_at_one", estimate = as.numeric(ar_f_at_one),
         se = NULL, n_obs = n)
  ),
  method_metadata = list(
    estimator = "Anderson-Rubin confidence set with conventional homoskedastic joint F test",
    vcov = "conventional homoskedastic"
  ),
  diagnostics = list()
)

json_escape <- function(x) {
  x <- gsub("\\\\", "\\\\\\\\", x)
  gsub('"', '\\"', x, fixed = TRUE)
}

to_json <- function(obj) {
  if (is.null(obj)) return("null")
  if (is.character(obj) && length(obj) == 1) {
    return(paste0('"', json_escape(obj), '"'))
  }
  if (is.numeric(obj) && length(obj) == 1) {
    return(format(obj, digits = 17, scientific = TRUE, trim = TRUE))
  }
  if (is.list(obj)) {
    nm <- names(obj)
    parts <- vapply(seq_along(obj), function(i) {
      paste0('"', nm[i], '":', to_json(obj[[i]]))
    }, character(1))
    return(paste0("{", paste(parts, collapse = ","), "}"))
  }
  stop("Unsupported JSON type")
}

writeLines(to_json(result), "result.json")
