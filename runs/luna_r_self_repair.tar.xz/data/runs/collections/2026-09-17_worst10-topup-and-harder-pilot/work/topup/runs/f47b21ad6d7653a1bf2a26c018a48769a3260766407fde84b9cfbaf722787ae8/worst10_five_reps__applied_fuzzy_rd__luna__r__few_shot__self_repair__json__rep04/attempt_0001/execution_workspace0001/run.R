#!/usr/bin/env Rscript

library(jsonlite)

dat <- read.csv("input.csv")

keep <- abs(dat$score) < 1
dat <- dat[keep, , drop = FALSE]

score <- dat$score
side <- as.numeric(score >= 0)
weight <- 1 - abs(score)

X <- cbind(
  intercept = 1,
  above = side,
  score_left = score * (1 - side),
  score_right = score * side
)

fit_discontinuity <- function(y) {
  bread <- solve(crossprod(X, weight * X))
  beta <- drop(bread %*% crossprod(X, weight * y))
  residual <- drop(y - X %*% beta)
  loading <- weight * drop(X %*% bread %*% c(0, 1, 0, 0))
  contribution <- loading * residual
  list(
    estimate = beta[2],
    contribution = contribution
  )
}

earnings_fit <- fit_discontinuity(dat$earnings)
participation_fit <- fit_discontinuity(dat$participated)

joint_covariance <- crossprod(
  cbind(earnings_fit$contribution, participation_fit$contribution)
)

reduced_form <- earnings_fit$estimate
first_stage <- participation_fit$estimate

reduced_form_se <- sqrt(joint_covariance[1, 1])
first_stage_se <- sqrt(joint_covariance[2, 2])

treatment_effect <- reduced_form / first_stage
gradient <- c(
  1 / first_stage,
  -reduced_form / first_stage^2
)
treatment_effect_se <- sqrt(
  drop(t(gradient) %*% joint_covariance %*% gradient)
)

n_obs <- nrow(dat)

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(
      term = "treatment_effect",
      estimate = unname(as.numeric(treatment_effect)),
      se = unname(as.numeric(treatment_effect_se)),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "reduced_form",
      estimate = unname(as.numeric(reduced_form)),
      se = unname(as.numeric(reduced_form_se)),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "first_stage",
      estimate = unname(as.numeric(first_stage)),
      se = unname(as.numeric(first_stage_se)),
      n_obs = as.integer(n_obs)
    )
  ),
  method_metadata = list(
    estimator = "Fuzzy local-linear regression discontinuity with triangular weights",
    vcov = "Conventional heteroskedasticity-robust HC0 with delta-method ratio standard error"
  ),
  diagnostics = list()
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  digits = 16,
  pretty = TRUE,
  null = "null"
)
