dat <- read.csv("input.csv")

y <- dat$y
X <- cbind(const = 1, x = dat$x, z = dat$z)
n <- nrow(dat)

neg_loglik <- function(par) {
  beta <- par[1:3]
  sigma <- exp(par[4])
  mu <- drop(X %*% beta)

  censored <- y <= 0
  ll <- numeric(n)

  ll[censored] <- pnorm(
    (0 - mu[censored]) / sigma,
    lower.tail = TRUE,
    log.p = TRUE
  )

  ll[!censored] <- dnorm(
    (y[!censored] - mu[!censored]) / sigma,
    log = TRUE
  ) - log(sigma)

  if (any(!is.finite(ll))) return(1e100)
  -sum(ll)
}

start_fit <- lm(y ~ x + z, data = dat)
start_beta <- coef(start_fit)
start_beta[is.na(start_beta)] <- 0
start_sigma <- sd(residuals(start_fit))
if (!is.finite(start_sigma) || start_sigma <= 0) {
  start_sigma <- max(sd(y[y > 0]), 1)
}

fit <- optim(
  par = c(start_beta, log(start_sigma)),
  fn = neg_loglik,
  method = "BFGS",
  hessian = TRUE,
  control = list(maxit = 10000, reltol = 1e-12)
)

if (fit$convergence != 0) {
  fit <- optim(
    par = fit$par,
    fn = neg_loglik,
    method = "Nelder-Mead",
    control = list(maxit = 20000, reltol = 1e-12)
  )
  fit <- optim(
    par = fit$par,
    fn = neg_loglik,
    method = "BFGS",
    hessian = TRUE,
    control = list(maxit = 10000, reltol = 1e-12)
  )
}

par_hat <- fit$par
beta_hat <- par_hat[1:3]
sigma_hat <- exp(par_hat[4])

H <- fit$hessian
V <- tryCatch(solve(H), error = function(e) MASS::ginv(H))
se_transformed <- sqrt(pmax(diag(V), 0))
se_beta <- se_transformed[1:3]
se_sigma <- sigma_hat * se_transformed[4]

json_num <- function(x) {
  if (length(x) == 1 && is.finite(x)) {
    formatC(x, format = "fg", digits = 15)
  } else {
    "null"
  }
}

result <- sprintf(
  paste0(
    '{\n',
    '  "task_id": "broad_tobit",\n',
    '  "platform": "r",\n',
    '  "estimates": [\n',
    '    {"term": "const", "estimate": %s, "se": %s, "n_obs": %d},\n',
    '    {"term": "x", "estimate": %s, "se": %s, "n_obs": %d},\n',
    '    {"term": "z", "estimate": %s, "se": %s, "n_obs": %d},\n',
    '    {"term": "sigma", "estimate": %s, "se": null, "n_obs": %d}\n',
    '  ],\n',
    '  "method_metadata": {"estimator": "homoskedastic Gaussian Tobit maximum likelihood", "vcov": "inverse observed information with delta-method standard error for sigma"},\n',
    '  "diagnostics": {}\n',
    '}\n'
  ),
  json_num(beta_hat[1]), json_num(se_beta[1]), n,
  json_num(beta_hat[2]), json_num(se_beta[2]), n,
  json_num(beta_hat[3]), json_num(se_beta[3]), n,
  json_num(sigma_hat), n
)

writeLines(result, "result.json")
