library(jsonlite)

dat <- read.csv("input.csv", stringsAsFactors = FALSE)

keep <- is.finite(dat$score) &
  is.finite(dat$participated) &
  is.finite(dat$earnings) &
  abs(dat$score) < 1

dat <- dat[keep, , drop = FALSE]

z <- dat$score
y <- cbind(dat$earnings, dat$participated)
w <- 1 - abs(z)

X <- cbind(
  left_intercept = as.numeric(z < 0),
  left_slope = z * as.numeric(z < 0),
  right_intercept = as.numeric(z >= 0),
  right_slope = z * as.numeric(z >= 0)
)

bread <- solve(crossprod(X, w * X))
beta <- bread %*% crossprod(X, w * y)
residuals <- y - X %*% beta

meat <- matrix(0, nrow = 8, ncol = 8)

for (i in seq_len(nrow(X))) {
  score_matrix <- kronecker(
    t(residuals[i, , drop = FALSE]),
    w[i] * X[i, , drop = FALSE]
  )
  contribution <- as.vector(score_matrix)
  meat <- meat + tcrossprod(contribution)
}

block_bread <- kronecker(diag(2), bread)
vcov_joint_beta <- block_bread %*% meat %*% block_bread

contrast <- c(-1, 0, 1, 0)

reduced_form <- sum(contrast * beta[, 1])
first_stage <- sum(contrast * beta[, 2])

g <- c(contrast, rep(0, 4))
h <- c(rep(0, 4), contrast)

cov_disc <- matrix(
  c(
    drop(t(g) %*% vcov_joint_beta %*% g),
    drop(t(g) %*% vcov_joint_beta %*% h),
    drop(t(h) %*% vcov_joint_beta %*% g),
    drop(t(h) %*% vcov_joint_beta %*% h)
  ),
  nrow = 2,
  byrow = TRUE
)

treatment_effect <- reduced_form / first_stage
gradient <- c(
  1 / first_stage,
  -reduced_form / first_stage^2
)

treatment_se <- sqrt(
  drop(t(gradient) %*% cov_disc %*% gradient)
)

n_obs <- nrow(dat)

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(
      term = "treatment_effect",
      estimate = unname(as.numeric(treatment_effect)),
      se = unname(as.numeric(treatment_se)),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "reduced_form",
      estimate = unname(as.numeric(reduced_form)),
      se = unname(as.numeric(sqrt(cov_disc[1, 1]))),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "first_stage",
      estimate = unname(as.numeric(first_stage)),
      se = unname(as.numeric(sqrt(cov_disc[2, 2]))),
      n_obs = as.integer(n_obs)
    )
  ),
  method_metadata = list(
    estimator = "fuzzy local-linear regression discontinuity with triangular weights",
    vcov = "conventional heteroskedasticity-robust HC0 with joint covariance and delta method"
  ),
  diagnostics = list()
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  digits = 16,
  pretty = TRUE
)
