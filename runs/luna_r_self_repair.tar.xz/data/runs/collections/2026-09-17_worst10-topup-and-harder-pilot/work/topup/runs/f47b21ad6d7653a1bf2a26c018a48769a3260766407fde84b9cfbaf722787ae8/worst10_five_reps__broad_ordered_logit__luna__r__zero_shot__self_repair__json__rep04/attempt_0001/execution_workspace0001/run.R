#!/usr/bin/env Rscript

dat <- read.csv("input.csv")

stopifnot(all(c("y", "x", "z") %in% names(dat)))

dat$y_ord <- ordered(dat$y, levels = c(1, 2, 3))

fit <- MASS::polr(
  y_ord ~ x + z - 1,
  data = dat,
  method = "logistic",
  Hess = TRUE
)

vc <- solve(fit$Hessian)
coefs <- coef(fit)

newdata <- data.frame(x = 1, z = 0)
prob_high <- as.numeric(
  predict(fit, newdata = newdata, type = "probs")[1, "3"]
)

result <- list(
  task_id = "broad_ordered_logit",
  platform = "r",
  estimates = list(
    list(
      term = "x",
      estimate = unname(coefs["x"]),
      se = sqrt(vc["x", "x"]),
      n_obs = nrow(dat)
    ),
    list(
      term = "z",
      estimate = unname(coefs["z"]),
      se = sqrt(vc["z", "z"]),
      n_obs = nrow(dat)
    ),
    list(
      term = "prob_high",
      estimate = prob_high,
      se = NA_real_,
      n_obs = nrow(dat)
    )
  ),
  method_metadata = list(
    estimator = "maximum likelihood ordered logit with two free cutpoints and no intercept",
    vcov = "conventional observed-information covariance matrix"
  ),
  diagnostics = list()
)

jsonlite::write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  digits = 16,
  na = "null"
)
