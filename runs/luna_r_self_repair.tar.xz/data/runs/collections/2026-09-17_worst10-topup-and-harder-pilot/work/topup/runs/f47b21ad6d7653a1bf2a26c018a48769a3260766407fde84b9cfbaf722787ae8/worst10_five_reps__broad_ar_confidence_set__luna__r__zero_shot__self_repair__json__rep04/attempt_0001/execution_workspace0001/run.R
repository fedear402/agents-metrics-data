d <- read.csv("input.csv")

n <- nrow(d)
y <- d$y
endog <- d$endog
x <- d$x
Z <- as.matrix(d[, c("z1", "z2")])
W <- cbind(1, x)

resid_on_W <- function(v) {
  fit <- lm.fit(W, v)
  as.numeric(fit$residuals)
}

yr <- resid_on_W(y)
dr <- resid_on_W(endog)
Zr <- apply(Z, 2, resid_on_W)

ZtZ <- crossprod(Zr)
Pz_apply <- function(v) {
  Zr %*% solve(ZtZ, crossprod(Zr, v))
}

yp <- Pz_apply(yr)
dp <- Pz_apply(dr)

a <- drop(crossprod(dp, dp))
b <- -2 * drop(crossprod(dp, yp))
c0 <- drop(crossprod(yp, yp))

yy <- drop(crossprod(yr, yr))
yd <- drop(crossprod(yr, dr))
dd <- drop(crossprod(dr, dr))

k <- 2 * qf(0.95, df1 = 2, df2 = n - 4) / (n - 4)

# g(beta) <= 0 defines the Anderson-Rubin confidence set.
# g(beta) = (1 + k) * q'Pz q - k * q'q
A <- (1 + k) * a - k * dd
B <- (1 + k) * b + 2 * k * yd
C <- (1 + k) * c0 - k * yy

disc <- B^2 - 4 * A * C
if (disc < 0 && disc > -1e-10) disc <- 0

if (disc < 0) {
  roots <- numeric(0)
} else {
  roots <- sort(c(
    (-B - sqrt(disc)) / (2 * A),
    (-B + sqrt(disc)) / (2 * A)
  ))
}

if (length(roots) != 2) {
  stop("Expected two finite Anderson-Rubin boundary points.")
}

ar_f <- function(beta) {
  q <- yr - beta * dr
  numer <- drop(crossprod(q, Pz_apply(q))) / 2
  resid <- q - Pz_apply(q)
  denom <- drop(crossprod(resid, resid)) / (n - 4)
  numer / denom
}

accepts_zero <- as.integer(ar_f(0) <= qf(0.95, df1 = 2, df2 = n - 4))
unbounded <- as.integer(
  ar_f(1e12) <= qf(0.95, df1 = 2, df2 = n - 4) ||
    ar_f(-1e12) <= qf(0.95, df1 = 2, df2 = n - 4)
)

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = list(
    list(term = "boundary_low", estimate = roots[1], se = NULL, n_obs = n),
    list(term = "boundary_high", estimate = roots[2], se = NULL, n_obs = n),
    list(term = "accepts_zero", estimate = accepts_zero, se = NULL, n_obs = n),
    list(term = "unbounded", estimate = unbounded, se = NULL, n_obs = n),
    list(term = "ar_f_at_one", estimate = ar_f(1), se = NULL, n_obs = n)
  ),
  method_metadata = list(
    estimator = "Anderson-Rubin confidence set with homoskedastic joint F test",
    vcov = "Conventional homoskedastic OLS covariance"
  ),
  diagnostics = list()
)

if (requireNamespace("jsonlite", quietly = TRUE)) {
  jsonlite::write_json(result, "result.json", auto_unbox = TRUE, null = "null")
} else {
  esc <- function(x) {
    x <- as.character(x)
    gsub('"', '\\"', x, fixed = TRUE)
  }
  estimates_json <- paste(
    sprintf(
      '{"term":"%s","estimate":%.15g,"se":null,"n_obs":%d}',
      vapply(result$estimates, `[[`, character(1), "term"),
      vapply(result$estimates, `[[`, numeric(1), "estimate"),
      n
    ),
    collapse = ","
  )
  json <- sprintf(
    '{"task_id":"broad_ar_confidence_set","platform":"r","estimates":[%s],"method_metadata":{"estimator":"%s","vcov":"%s"},"diagnostics":{}}',
    estimates_json,
    esc(result$method_metadata$estimator),
    esc(result$method_metadata$vcov)
  )
  writeLines(json, "result.json")
}
