d <- read.csv("input.csv")

fit <- survival::survreg(
  survival::Surv(y, y > 0, type = "left") ~ x + z,
  data = d,
  dist = "gaussian",
  control = survival::survreg.control(rel.tolerance = 1e-12)
)

V <- stats::vcov(fit)
n <- nrow(d)
b <- stats::coef(fit)

result <- list(
  task_id = "broad_tobit",
  platform = "r",
  estimates = list(
    list(
      term = "const",
      estimate = unname(b["(Intercept)"]),
      se = sqrt(V["(Intercept)", "(Intercept)"]),
      n_obs = n
    ),
    list(
      term = "x",
      estimate = unname(b["x"]),
      se = sqrt(V["x", "x"]),
      n_obs = n
    ),
    list(
      term = "z",
      estimate = unname(b["z"]),
      se = sqrt(V["z", "z"]),
      n_obs = n
    ),
    list(
      term = "sigma",
      estimate = unname(fit$scale),
      se = NULL,
      n_obs = n
    )
  ),
  method_metadata = list(
    estimator = "Maximum likelihood homoskedastic Gaussian Tobit",
    vcov = "Observed information covariance"
  ),
  diagnostics = list()
)

jsonlite::write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
