input <- read.csv("input.csv")

keep <- is.finite(input$score) &
  is.finite(input$participated) &
  is.finite(input$earnings) &
  abs(input$score) < 1

dat <- input[keep, , drop = FALSE]
n_obs <- nrow(dat)

x <- dat$score
right <- as.numeric(x >= 0)
w <- 1 - abs(x)

X <- cbind(
  intercept = 1,
  right = right,
  score = x,
  right_score = right * x
)

fit_wls <- function(y) {
  sw <- sqrt(w)
  Xw <- X * sw
  yw <- y * sw
  beta <- solve(crossprod(Xw), crossprod(Xw, yw))
  resid <- as.numeric(y - X %*% beta)
  bread <- solve(crossprod(Xw))
  meat <- crossprod(X * (w * resid))
  vcov <- bread %*% meat %*% bread
  list(beta = beta, vcov = vcov, resid = resid)
}

fit_y <- fit_wls(dat$earnings)
fit_d <- fit_wls(dat$participated)

reduced_form <- unname(fit_y$beta["right"])
first_stage <- unname(fit_d$beta["right"])

se_reduced_form <- sqrt(fit_y$vcov["right", "right"])
se_first_stage <- sqrt(fit_d$vcov["right", "right"])

bread <- solve(crossprod(X * sqrt(w)))
cross_meat <- crossprod(
  X * (w * fit_y$resid),
  X * (w * fit_d$resid)
)
cross_vcov <- bread %*% cross_meat %*% bread
cov_discontinuities <- cross_vcov["right", "right"]

treatment_effect <- reduced_form / first_stage
var_treatment_effect <- (
  fit_y$vcov["right", "right"] +
    treatment_effect^2 * fit_d$vcov["right", "right"] -
    2 * treatment_effect * cov_discontinuities
) / first_stage^2

se_treatment_effect <- sqrt(max(0, var_treatment_effect))

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(
      term = "treatment_effect",
      estimate = unname(treatment_effect),
      se = unname(se_treatment_effect),
      n_obs = n_obs
    ),
    list(
      term = "reduced_form",
      estimate = unname(reduced_form),
      se = unname(se_reduced_form),
      n_obs = n_obs
    ),
    list(
      term = "first_stage",
      estimate = unname(first_stage),
      se = unname(se_first_stage),
      n_obs = n_obs
    )
  ),
  method_metadata = list(
    estimator = "Fuzzy local-linear regression discontinuity with triangular weights",
    vcov = "Conventional heteroskedasticity-robust HC0 with delta method and joint covariance"
  ),
  diagnostics = list()
)

if (!requireNamespace("jsonlite", quietly = TRUE)) {
  stop("The jsonlite package is required.")
}

jsonlite::write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  digits = 17,
  null = "null"
)
