#!/usr/bin/env Rscript

dat <- read.csv("input.csv")

stopifnot(all(c("y", "x", "z") %in% names(dat)))

dat <- dat[complete.cases(dat[, c("y", "x", "z")]), ]
y <- as.integer(dat$y)
x <- as.matrix(dat[, c("x", "z")])

stopifnot(all(y %in% c(1L, 2L, 3L)))

loglik <- function(par) {
  beta <- par[1:2]
  cut1 <- par[3]
  cut2 <- cut1 + exp(par[4])
  eta <- drop(x %*% beta)

  p1 <- plogis(cut1 - eta)
  p2 <- plogis(cut2 - eta) - p1
  p3 <- 1 - plogis(cut2 - eta)

  probs <- cbind(p1, p2, p3)
  probs <- pmax(probs, .Machine$double.xmin)

  sum(log(probs[cbind(seq_along(y), y)]))
}

start <- c(
  beta_x = 0,
  beta_z = 0,
  cut1 = qlogis(mean(y <= 1)),
  log_cut_gap = log(max(qlogis(mean(y <= 2)) - qlogis(mean(y <= 1)), 0.1))
)

fit <- optim(
  par = start,
  fn = function(par) -loglik(par),
  method = "BFGS",
  hessian = TRUE,
  control = list(maxit = 10000, reltol = 1e-12)
)

if (fit$convergence != 0 || any(!is.finite(fit$par))) {
  stop("Maximum likelihood optimization failed")
}

par_hat <- fit$par
beta_hat <- par_hat[1:2]

vcov_full <- tryCatch(
  solve(fit$hessian),
  error = function(e) solve(fit$hessian + diag(1e-8, nrow(fit$hessian)))
)

se_beta <- sqrt(pmax(diag(vcov_full)[1:2], 0))

cut1_hat <- par_hat[3]
cut2_hat <- cut1_hat + exp(par_hat[4])

eta_high <- beta_hat[1]
prob_high <- 1 - plogis(cut2_hat - eta_high)

result <- list(
  task_id = "broad_ordered_logit",
  platform = "r",
  estimates = list(
    list(
      term = "x",
      estimate = unname(beta_hat[1]),
      se = unname(se_beta[1]),
      n_obs = nrow(dat)
    ),
    list(
      term = "z",
      estimate = unname(beta_hat[2]),
      se = unname(se_beta[2]),
      n_obs = nrow(dat)
    ),
    list(
      term = "prob_high",
      estimate = unname(prob_high),
      se = NULL,
      n_obs = nrow(dat)
    )
  ),
  method_metadata = list(
    estimator = "maximum likelihood ordered logit with two free cutpoints and no intercept",
    vcov = "conventional observed-information covariance matrix"
  ),
  diagnostics = list()
)

jsonlite::write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  digits = 16,
  na = "null"
)
