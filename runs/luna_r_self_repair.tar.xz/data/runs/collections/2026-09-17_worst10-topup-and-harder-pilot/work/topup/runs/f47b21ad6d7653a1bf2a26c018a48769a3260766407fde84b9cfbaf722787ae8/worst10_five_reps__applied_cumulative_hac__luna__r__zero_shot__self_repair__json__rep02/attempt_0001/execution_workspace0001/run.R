dat <- read.csv("input.csv", stringsAsFactors = FALSE)

dat <- dat[order(as.character(dat$date)), ]
dlog_vix <- diff(log(dat$vix))
y <- log(dat$sales)[16:length(dat$sales)]

n_total <- length(dat$sales)
n_obs <- n_total - 15L

X <- matrix(1, nrow = n_obs, ncol = 16L)
colnames(X) <- c("intercept", paste0("lag_", 1:15))

for (j in 1:15) {
  X[, j + 1L] <- dlog_vix[(16L - j):(n_total - j)]
}

fit <- lm.fit(x = X, y = y)
beta <- as.numeric(fit$coefficients)
resid <- as.numeric(fit$residuals)

bread <- solve(crossprod(X))
S <- matrix(0, nrow = 16L, ncol = 16L)

for (t in seq_len(n_obs)) {
  xt <- X[t, , drop = FALSE]
  S <- S + as.numeric(resid[t]^2) * crossprod(xt)
}

for (j in 1:15) {
  weight <- 1 - j / 16
  for (t in (j + 1):n_obs) {
    xt <- X[t, , drop = FALSE]
    xlag <- X[t - j, , drop = FALSE]
    cross_term <- as.numeric(resid[t] * resid[t - j]) *
      (crossprod(xt, xlag) + crossprod(xlag, xt))
    S <- S + weight * cross_term
  }
}

vcov_hac <- bread %*% S %*% bread * n_obs / (n_obs - 16)
se_beta <- sqrt(pmax(0, diag(vcov_hac)))

lag_idx <- 2:16
cumulative_response <- sum(beta[lag_idx])
cumulative_se <- sqrt(pmax(0, sum(vcov_hac[lag_idx, lag_idx])))

fmt <- function(x) {
  if (is.na(x) || is.nan(x) || is.infinite(x)) "null" else sprintf("%.15g", x)
}

json <- paste0(
  '{',
  '"task_id":"applied_cumulative_hac",',
  '"platform":"r",',
  '"estimates":[',
  '{"term":"cumulative_response","estimate":', fmt(cumulative_response),
  ',"se":', fmt(cumulative_se), ',"n_obs":', n_obs, '},',
  '{"term":"lag_1","estimate":', fmt(beta[2]),
  ',"se":', fmt(se_beta[2]), ',"n_obs":', n_obs, '},',
  '{"term":"lag_15","estimate":', fmt(beta[16]),
  ',"se":', fmt(se_beta[16]), ',"n_obs":', n_obs, '}',
  '],',
  '"method_metadata":{',
  '"estimator":"OLS with intercept and lags 1 through 15 of first-differenced log VIX",',
  '"vcov":"Newey-West HAC covariance, maximum lag 15, Bartlett weights, scaled by N/(N-16)"',
  '},',
  '"diagnostics":{}',
  '}'
)

writeLines(json, "result.json")
