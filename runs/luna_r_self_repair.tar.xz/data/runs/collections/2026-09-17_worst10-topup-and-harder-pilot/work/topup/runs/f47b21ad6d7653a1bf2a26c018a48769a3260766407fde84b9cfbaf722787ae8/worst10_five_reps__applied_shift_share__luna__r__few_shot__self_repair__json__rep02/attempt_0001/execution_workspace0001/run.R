library(jsonlite)

dat <- read.csv("input.csv", stringsAsFactors = FALSE)

region_ids <- unique(dat$region_id)
industry_ids <- unique(dat$industry_id)

region_data <- dat[match(region_ids, dat$region_id), ]
e <- region_data$region_weight
e <- e / sum(e)

z <- tapply(dat$share * dat$shock, dat$region_id, sum)
z <- as.numeric(z[match(region_ids, names(z))])

y <- region_data$y
x <- region_data$x

weighted_mean <- function(v, w) {
  sum(w * v)
}

y0 <- y - weighted_mean(y, e)
x0 <- x - weighted_mean(x, e)
z0 <- z - weighted_mean(z, e)

shock_by_industry <- tapply(dat$shock, dat$industry_id, function(v) v[1])
shock <- as.numeric(shock_by_industry[industry_ids])

s <- numeric(length(industry_ids))
ybar <- numeric(length(industry_ids))
xbar <- numeric(length(industry_ids))
zbar <- numeric(length(industry_ids))

for (j in seq_along(industry_ids)) {
  rows <- dat$industry_id == industry_ids[j]
  region_match <- match(dat$region_id[rows], region_ids)
  masses <- e[region_match] * dat$share[rows]
  s[j] <- sum(masses)
  ybar[j] <- sum(masses * y0[region_match]) / s[j]
  xbar[j] <- sum(masses * x0[region_match]) / s[j]
  zbar[j] <- sum(masses * z0[region_match]) / s[j]
}

keep <- is.finite(s) & s > 0
s <- s[keep]
shock <- shock[keep]
ybar <- ybar[keep]
xbar <- xbar[keep]
zbar <- zbar[keep]

shock_iv <- function(dependent, endogenous, instrument, weights) {
  regressors <- cbind(1, endogenous)
  instruments <- cbind(1, instrument)

  cross <- crossprod(instruments, weights * regressors)
  beta <- solve(
    cross,
    crossprod(instruments, weights * dependent)
  )

  residual <- drop(dependent - regressors %*% beta)
  scores <- instruments * (weights * residual)
  inverse <- solve(cross)

  n_industries <- length(weights)
  covariance <- n_industries / (n_industries - 2) *
    inverse %*% crossprod(scores) %*% t(inverse)

  c(
    estimate = beta[2],
    se = sqrt(covariance[2, 2])
  )
}

n_industries <- length(s)

effect <- shock_iv(ybar, xbar, shock, s)
first_stage <- shock_iv(xbar, zbar, shock, s)
effective_shocks <- 1 / sum(s^2)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(
      term = "effect",
      estimate = unname(as.numeric(effect["estimate"])),
      se = unname(as.numeric(effect["se"])),
      n_obs = as.integer(n_industries)
    ),
    list(
      term = "first_stage",
      estimate = unname(as.numeric(first_stage["estimate"])),
      se = unname(as.numeric(first_stage["se"])),
      n_obs = as.integer(n_industries)
    ),
    list(
      term = "effective_shocks",
      estimate = as.numeric(effective_shocks),
      se = NULL,
      n_obs = as.integer(n_industries)
    )
  ),
  method_metadata = list(
    estimator = "Weighted shock-level IV with intercept",
    vcov = "Borusyak-Hull-Jaravel exposure-robust HC1, multiplier N/(N-2)"
  ),
  diagnostics = list()
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
