dat <- read.csv("input.csv", stringsAsFactors = FALSE)

region_key <- as.character(dat$region_id)
industry_key <- as.character(dat$industry_id)

region_ids <- unique(region_key)
region_index <- match(region_key, region_ids)
region_weight <- dat$region_weight[match(region_ids, region_key)]
e <- region_weight / sum(region_weight)

share <- dat$share
shock <- dat$shock

z_region <- as.numeric(tapply(share * shock, region_index, sum))
x_region <- dat$x[match(region_ids, region_key)]
y_region <- dat$y[match(region_ids, region_key)]

weighted_mean <- function(v, w) sum(w * v) / sum(w)

y0 <- y_region - weighted_mean(y_region, e)
x0 <- x_region - weighted_mean(x_region, e)
z0 <- z_region - weighted_mean(z_region, e)

industry_ids <- unique(industry_key)
industry_index <- match(industry_key, industry_ids)
shock_n <- shock[match(industry_ids, industry_key)]

s_n <- as.numeric(tapply(e[region_index] * share, industry_index, sum))

ybar <- numeric(length(industry_ids))
xbar <- numeric(length(industry_ids))
zbar <- numeric(length(industry_ids))

for (j in seq_along(industry_ids)) {
  ind <- industry_index == j
  weights <- e[region_index[ind]] * share[ind]
  ybar[j] <- sum(weights * y0[region_index[ind]]) / s_n[j]
  xbar[j] <- sum(weights * x0[region_index[ind]]) / s_n[j]
  zbar[j] <- sum(weights * z0[region_index[ind]]) / s_n[j]
}

keep <- is.finite(s_n) & s_n > 0 &
  is.finite(shock_n) & is.finite(ybar) &
  is.finite(xbar) & is.finite(zbar)

s_n <- s_n[keep]
shock_n <- shock_n[keep]
ybar <- ybar[keep]
xbar <- xbar[keep]
zbar <- zbar[keep]

iv_fit_hc1 <- function(y, x, z, w) {
  X <- cbind(1, x)
  Z <- cbind(1, z)

  ZWZ <- crossprod(Z, w * Z)
  Q <- solve(ZWZ)
  A <- crossprod(X, w * Z) %*% Q %*% crossprod(Z, w * X)
  rhs <- crossprod(X, w * Z) %*% Q %*% crossprod(Z, w * y)
  beta <- solve(A, rhs)

  u <- as.numeric(y - X %*% beta)
  Zu <- Z * as.numeric(w^2 * u^2)
  meat <- crossprod(X, w * Z) %*% Q %*%
    crossprod(Z, w^2 * u^2 * Z) %*% Q %*%
    crossprod(Z, w * X)

  n <- length(y)
  p <- ncol(X)
  vcov <- (n / (n - p)) * solve(A) %*% meat %*% solve(A)
  list(estimate = as.numeric(beta[2]), se = sqrt(vcov[2, 2]))
}

N <- length(s_n)

effect_fit <- iv_fit_hc1(ybar, xbar, shock_n, s_n)
first_stage_fit <- iv_fit_hc1(xbar, zbar, shock_n, s_n)

effective_shocks <- 1 / sum(s_n^2)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(
      term = "effect",
      estimate = effect_fit$estimate,
      se = effect_fit$se,
      n_obs = N
    ),
    list(
      term = "first_stage",
      estimate = first_stage_fit$estimate,
      se = first_stage_fit$se,
      n_obs = N
    ),
    list(
      term = "effective_shocks",
      estimate = effective_shocks,
      se = NULL,
      n_obs = N
    )
  ),
  method_metadata = list(
    estimator = "Borusyak-Hull-Jaravel shock-level weighted IV",
    vcov = "HC1 heteroskedasticity-robust shock-level covariance with N/(N-2) multiplier"
  ),
  diagnostics = list()
)

if (requireNamespace("jsonlite", quietly = TRUE)) {
  jsonlite::write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 17)
} else {
  esc <- function(x) {
    x <- format(x, scientific = FALSE, digits = 17, trim = TRUE)
    gsub("\"", "\\\\\"", x, fixed = TRUE)
  }
  lines <- c(
    "{",
    '  "task_id": "applied_shift_share",',
    '  "platform": "r",',
    '  "estimates": [',
    sprintf('    {"term":"effect","estimate":%s,"se":%s,"n_obs":%d},',
            esc(effect_fit$estimate), esc(effect_fit$se), N),
    sprintf('    {"term":"first_stage","estimate":%s,"se":%s,"n_obs":%d},',
            esc(first_stage_fit$estimate), esc(first_stage_fit$se), N),
    sprintf('    {"term":"effective_shocks","estimate":%s,"se":null,"n_obs":%d}',
            esc(effective_shocks), N),
    "  ],",
    '  "method_metadata": {"estimator":"Borusyak-Hull-Jaravel shock-level weighted IV","vcov":"HC1 heteroskedasticity-robust shock-level covariance with N/(N-2) multiplier"},',
    '  "diagnostics": {}',
    "}"
  )
  writeLines(lines, "result.json")
}
