library(jsonlite)

dat <- read.csv("input.csv")

keep <- abs(dat$score) < 1
dat <- dat[keep, ]

x <- dat$score
right <- as.numeric(x >= 0)
weights <- 1 - abs(x)

X <- cbind(
  intercept = 1,
  right = right,
  left_slope = x * (1 - right),
  right_slope = x * right
)

fit_outcome <- function(y) {
  bread <- solve(crossprod(X, weights * X))
  beta <- bread %*% crossprod(X, weights * y)
  residuals <- drop(y - X %*% beta)
  contrast <- c(0, 1, 0, 0)
  loading <- weights * drop(X %*% bread %*% contrast)
  contribution <- loading * residuals
  estimate <- drop(crossprod(contrast, beta))
  variance <- sum(contribution^2)
  list(
    estimate = estimate,
    variance = variance,
    contribution = contribution
  )
}

earnings_fit <- fit_outcome(dat$earnings)
participation_fit <- fit_outcome(dat$participated)

joint_covariance <- crossprod(
  earnings_fit$contribution,
  participation_fit$contribution
)

reduced_form <- earnings_fit$estimate
first_stage <- participation_fit$estimate
treatment_effect <- reduced_form / first_stage

gradient <- c(
  1 / first_stage,
  -reduced_form / first_stage^2
)

ratio_variance <- drop(
  t(gradient) %*%
    matrix(
      c(
        earnings_fit$variance,
        joint_covariance,
        joint_covariance,
        participation_fit$variance
      ),
      nrow = 2
    ) %*%
    gradient
)

n_obs <- nrow(dat)

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(
      term = "treatment_effect",
      estimate = as.numeric(treatment_effect),
      se = as.numeric(sqrt(ratio_variance)),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "reduced_form",
      estimate = as.numeric(reduced_form),
      se = as.numeric(sqrt(earnings_fit$variance)),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "first_stage",
      estimate = as.numeric(first_stage),
      se = as.numeric(sqrt(participation_fit$variance)),
      n_obs = as.integer(n_obs)
    )
  ),
  method_metadata = list(
    estimator = "fuzzy local-linear regression discontinuity with triangular weights",
    vcov = "conventional heteroskedasticity-robust HC0 with joint delta-method covariance"
  ),
  diagnostics = list()
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
