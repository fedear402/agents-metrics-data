d <- read.csv("input.csv")

n <- nrow(d)
q <- 2L
df <- n - 4L
critical <- qf(0.95, q, df)
k <- q * critical / df

ry <- residuals(lm(y ~ x, data = d))
rd <- residuals(lm(endog ~ x, data = d))

uy <- residuals(lm(y ~ x + z1 + z2, data = d))
ud <- residuals(lm(endog ~ x + z1 + z2, data = d))

ssr_r_y <- sum(ry^2)
ssr_r_d <- sum(rd^2)
ssr_u_y <- sum(uy^2)
ssr_u_d <- sum(ud^2)

A <- ssr_r_d - (1 + k) * ssr_u_d
B <- -2 * (sum(ry * rd) - (1 + k) * sum(uy * ud))
C <- ssr_r_y - (1 + k) * ssr_u_y

disc <- B^2 - 4 * A * C
roots <- c(
  (-B - sqrt(disc)) / (2 * A),
  (-B + sqrt(disc)) / (2 * A)
)
bounds <- sort(roots)

accepts <- function(beta) {
  A * beta^2 + B * beta + C <= 0
}

transformed <- d$y - d$endog
fit_r <- lm(I(y - endog) ~ x, data = d)
fit_u <- lm(I(y - endog) ~ x + z1 + z2, data = d)

ar_f_at_one <- ((deviance(fit_r) - deviance(fit_u)) / q) /
  (deviance(fit_u) / df)

rows <- list(
  list(
    term = "boundary_low",
    estimate = unname(bounds[1]),
    se = NULL,
    n_obs = n
  ),
  list(
    term = "boundary_high",
    estimate = unname(bounds[2]),
    se = NULL,
    n_obs = n
  ),
  list(
    term = "accepts_zero",
    estimate = as.numeric(accepts(0)),
    se = NULL,
    n_obs = n
  ),
  list(
    term = "unbounded",
    estimate = as.numeric(A < 0),
    se = NULL,
    n_obs = n
  ),
  list(
    term = "ar_f_at_one",
    estimate = unname(ar_f_at_one),
    se = NULL,
    n_obs = n
  )
)

jsonlite::write_json(
  list(
    task_id = "broad_ar_confidence_set",
    platform = "r",
    estimates = rows,
    method_metadata = list(
      estimator = "Anderson-Rubin inversion with homoskedastic joint F test",
      vcov = "conventional homoskedastic"
    ),
    diagnostics = list()
  ),
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
