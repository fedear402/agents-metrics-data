library(jsonlite)

dat <- read.csv("input.csv", stringsAsFactors = FALSE, check.names = FALSE)

region_ids <- unique(dat$region_id)
industry_ids <- unique(dat$industry_id)

region_rows <- match(region_ids, dat$region_id)
region_weight <- as.numeric(dat$region_weight[region_rows])
x <- as.numeric(dat$x[region_rows])
y <- as.numeric(dat$y[region_rows])

e <- region_weight / sum(region_weight)

industry_index <- match(dat$industry_id, industry_ids)
region_index <- match(dat$region_id, region_ids)

shock <- numeric(length(industry_ids))
for (j in seq_along(industry_ids)) {
  shock[j] <- as.numeric(dat$shock[which(industry_index == j)[1]])
}

share_matrix <- matrix(
  0,
  nrow = length(region_ids),
  ncol = length(industry_ids)
)

for (i in seq_len(nrow(dat))) {
  share_matrix[region_index[i], industry_index[i]] <- as.numeric(dat$share[i])
}

z <- drop(share_matrix %*% shock)

weighted_mean <- function(v, w) {
  sum(w * v)
}

y0 <- y - weighted_mean(y, e)
x0 <- x - weighted_mean(x, e)
z0 <- z - weighted_mean(z, e)

s <- drop(crossprod(e, share_matrix))
used <- is.finite(s) & s > 0

s_used <- s[used]
shock_used <- shock[used]
share_used <- share_matrix[, used, drop = FALSE]

aggregate_exposure <- function(v0) {
  out <- numeric(length(s_used))
  for (j in seq_along(s_used)) {
    out[j] <- sum(e * share_used[, j] * v0) / s_used[j]
  }
  out
}

ybar <- aggregate_exposure(y0)
xbar <- aggregate_exposure(x0)
zbar <- aggregate_exposure(z0)

shock_level_iv <- function(dependent, endogenous, instrument, weights) {
  regressors <- cbind(1, endogenous)
  instruments <- cbind(1, instrument)

  cross <- crossprod(instruments, weights * regressors)
  moment <- crossprod(instruments, weights * dependent)
  beta <- solve(cross, moment)

  residual <- drop(dependent - regressors %*% beta)
  scores <- instruments * (weights * residual)
  inverse <- solve(cross)

  n_obs <- length(weights)
  covariance <- (n_obs / (n_obs - 2)) *
    inverse %*% crossprod(scores) %*% t(inverse)

  c(
    estimate = as.numeric(beta[2]),
    se = sqrt(as.numeric(covariance[2, 2]))
  )
}

effect_fit <- shock_level_iv(
  dependent = ybar,
  endogenous = xbar,
  instrument = shock_used,
  weights = s_used
)

first_stage_fit <- shock_level_iv(
  dependent = xbar,
  endogenous = zbar,
  instrument = shock_used,
  weights = s_used
)

n_industries <- length(s_used)
effective_shocks <- 1 / sum(s_used^2)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(
      term = "effect",
      estimate = effect_fit[["estimate"]],
      se = effect_fit[["se"]],
      n_obs = as.integer(n_industries)
    ),
    list(
      term = "first_stage",
      estimate = first_stage_fit[["estimate"]],
      se = first_stage_fit[["se"]],
      n_obs = as.integer(n_industries)
    ),
    list(
      term = "effective_shocks",
      estimate = as.numeric(effective_shocks),
      se = NULL,
      n_obs = as.integer(n_industries)
    )
  ),
  method_metadata = list(
    estimator = "weighted shock-level IV with intercept",
    vcov = "shock-level HC1, structural IV residuals, analytic weights"
  ),
  diagnostics = list()
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
