dat <- read.csv("input.csv")

y <- as.numeric(dat$y)
xmat <- cbind(const = 1, x = dat$x, z = dat$z)
n <- nrow(dat)
uncensored <- y > 0

loglik <- function(theta) {
  beta <- theta[1:3]
  sigma <- exp(theta[4])
  mu <- as.vector(xmat %*% beta)

  ll <- numeric(n)
  ll[!uncensored] <- pnorm(
    (0 - mu[!uncensored]) / sigma,
    log.p = TRUE
  )
  ll[uncensored] <- dnorm(
    (y[uncensored] - mu[uncensored]) / sigma,
    log = TRUE
  ) - log(sigma)

  if (any(!is.finite(ll))) return(1e100)
  -sum(ll)
}

ols <- lm(y ~ x + z, data = dat)
beta0 <- coef(ols)
beta0[is.na(beta0)] <- 0
sigma0 <- sd(residuals(ols))
if (!is.finite(sigma0) || sigma0 <= 0) sigma0 <- sd(y[y > 0])
if (!is.finite(sigma0) || sigma0 <= 0) sigma0 <- 1

start <- c(beta0, log(sigma0))

fit <- optim(
  par = start,
  fn = loglik,
  method = "BFGS",
  hessian = TRUE,
  control = list(maxit = 10000, reltol = 1e-12)
)

if (fit$convergence != 0) {
  fit <- optim(
    par = fit$par,
    fn = loglik,
    method = "Nelder-Mead",
    control = list(maxit = 20000, reltol = 1e-12)
  )
  fit <- optim(
    par = fit$par,
    fn = loglik,
    method = "BFGS",
    hessian = TRUE,
    control = list(maxit = 10000, reltol = 1e-12)
  )
}

theta_hat <- fit$par
beta_hat <- theta_hat[1:3]
sigma_hat <- exp(theta_hat[4])

hess <- fit$hessian
vcov_theta <- tryCatch(
  solve(hess),
  error = function(e) qr.solve(hess)
)

se_beta <- sqrt(pmax(diag(vcov_theta)[1:3], 0))

result <- list(
  task_id = "broad_tobit",
  platform = "r",
  estimates = list(
    list(term = "const", estimate = unname(beta_hat[1]),
         se = unname(se_beta[1]), n_obs = n),
    list(term = "x", estimate = unname(beta_hat[2]),
         se = unname(se_beta[2]), n_obs = n),
    list(term = "z", estimate = unname(beta_hat[3]),
         se = unname(se_beta[3]), n_obs = n),
    list(term = "sigma", estimate = unname(sigma_hat),
         se = NULL, n_obs = n)
  ),
  method_metadata = list(
    estimator = "Homoskedastic Gaussian Tobit maximum likelihood",
    vcov = "Inverse observed information with numerical Hessian"
  ),
  diagnostics = list(
    convergence = fit$convergence,
    logLik = -fit$value
  )
)

if (requireNamespace("jsonlite", quietly = TRUE)) {
  jsonlite::write_json(
    result,
    "result.json",
    auto_unbox = TRUE,
    digits = 17,
    null = "null"
  )
} else {
  esc <- function(v) format(v, scientific = TRUE, digits = 17)
  txt <- paste0(
    '{',
    '"task_id":"broad_tobit",',
    '"platform":"r",',
    '"estimates":[',
    '{"term":"const","estimate":', esc(beta_hat[1]), ',"se":', esc(se_beta[1]), ',"n_obs":', n, '},',
    '{"term":"x","estimate":', esc(beta_hat[2]), ',"se":', esc(se_beta[2]), ',"n_obs":', n, '},',
    '{"term":"z","estimate":', esc(beta_hat[3]), ',"se":', esc(se_beta[3]), ',"n_obs":', n, '},',
    '{"term":"sigma","estimate":', esc(sigma_hat), ',"se":null,"n_obs":', n, '}',
    '],',
    '"method_metadata":{"estimator":"Homoskedastic Gaussian Tobit maximum likelihood","vcov":"Inverse observed information with numerical Hessian"},',
    '"diagnostics":{}',
    '}'
  )
  writeLines(txt, "result.json")
}
