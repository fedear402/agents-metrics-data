dat <- read.csv("input.csv")
n <- nrow(dat)

y <- dat$y
endog <- dat$endog
x <- dat$x
z1 <- dat$z1
z2 <- dat$z2

restricted <- cbind(1, x)
unrestricted <- cbind(1, x, z1, z2)

qr_r <- qr(restricted)
qr_u <- qr(unrestricted)

Q_r <- qr.Q(qr_r)
Q_u <- qr.Q(qr_u)

M_r <- diag(n) - tcrossprod(Q_r)
M_u <- diag(n) - tcrossprod(Q_u)
D <- M_r - M_u

ssr_diff <- function(beta) {
  v <- y - beta * endog
  as.numeric(crossprod(v, D %*% v))
}

ssr_full <- function(beta) {
  v <- y - beta * endog
  as.numeric(crossprod(v, M_u %*% v))
}

f_crit <- qf(0.95, df1 = 2, df2 = n - 4)

ar_stat <- function(beta) {
  ssr_diff(beta) / 2 / (ssr_full(beta) / (n - 4))
}

g <- function(beta) {
  ar_stat(beta) - f_crit
}

v_m1 <- g(-1)
v_0 <- g(0)
v_1 <- g(1)

a <- (v_1 + v_m1 - 2 * v_0) / 2
b <- (v_1 - v_m1) / 2
c <- v_0

roots <- polyroot(c(c, b, a))
real_roots <- sort(Re(roots[abs(Im(roots)) < 1e-7]))

boundary_low <- real_roots[1]
boundary_high <- real_roots[length(real_roots)]

accepts_zero <- as.integer(g(0) <= 0)

unbounded <- as.integer(
  if (abs(a) > 1e-12) {
    a < 0
  } else if (abs(b) > 1e-12) {
    TRUE
  } else {
    c <= 0
  }
)

estimates <- list(
  list(term = "boundary_low", estimate = as.numeric(boundary_low),
       se = NA_real_, n_obs = n),
  list(term = "boundary_high", estimate = as.numeric(boundary_high),
       se = NA_real_, n_obs = n),
  list(term = "accepts_zero", estimate = as.numeric(accepts_zero),
       se = NA_real_, n_obs = n),
  list(term = "unbounded", estimate = as.numeric(unbounded),
       se = NA_real_, n_obs = n),
  list(term = "ar_f_at_one", estimate = as.numeric(ar_stat(1)),
       se = NA_real_, n_obs = n)
)

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "Anderson-Rubin confidence set using homoskedastic joint F test",
    vcov = "conventional homoskedastic"
  ),
  diagnostics = list()
)

jsonlite::write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  na = "null",
  digits = 17
)
