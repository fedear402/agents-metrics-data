import json

import numpy as np
import pandas as pd


def read(name):
    df = pd.read_csv(name, dtype=str)
    for c in df.columns:
        df[c] = df[c].str.strip()
    return df


crosswalk = read("crosswalk.csv")
trade = read("trade.csv")
areas = read("areas.csv")
employment = read("employment.csv")
outcomes = read("outcomes.csv")

for df, cols in [
    (trade, ["period", "us_change", "other_change", "price_index", "years"]),
    (areas, ["period", "total_employment", "population"]),
    (employment, ["period", "employment"]),
    (outcomes, ["period", "control", "change_pp"]),
]:
    for c in cols:
        df[c] = pd.to_numeric(df[c])

trade = trade.merge(crosswalk[["code", "industry"]].drop_duplicates(), on="code", how="left")

industries = sorted(crosswalk["industry"].unique())
areas_list = sorted(areas["area"].unique())
periods = sorted(areas["period"].unique())

emp = employment.groupby(["area", "period", "vintage", "industry"], as_index=False)["employment"].sum()


def exposure(vintage, change_col):
    out = {}
    for p in periods:
        tr = trade[trade["period"] == p].set_index("industry")
        ar = areas[(areas["period"] == p) & (areas["vintage"] == vintage)].set_index("area")
        total = ar["total_employment"].reindex(areas_list).to_numpy(dtype=float)
        e = emp[(emp["period"] == p) & (emp["vintage"] == vintage)]
        E = e.pivot_table(index="area", columns="industry", values="employment", aggfunc="sum")
        E = E.reindex(index=areas_list, columns=industries).fillna(0.0).to_numpy(dtype=float)
        nat = E.sum(axis=0)
        chg = tr.loc[industries, change_col].to_numpy(dtype=float)
        price = float(tr["price_index"].iloc[0])
        years = float(tr["years"].iloc[0])
        x = ((E / total[:, None]) * (chg / nat)[None, :]).sum(axis=1)
        x = x / (price / 100.0) / 1000.0 * (10.0 / years)
        out[p] = pd.Series(x, index=areas_list)
    return out


x_by = exposure("base", "us_change")
z_by = exposure("early", "other_change")

base = areas[areas["vintage"] == "base"][["area", "period", "population"]]
obs = base.merge(outcomes[["area", "period", "control", "change_pp"]], on=["area", "period"], how="inner")
obs = obs.sort_values(["period", "area"]).reset_index(drop=True)
obs["x"] = [x_by[p][a] for a, p in zip(obs["area"], obs["period"])]
obs["z"] = [z_by[p][a] for a, p in zip(obs["area"], obs["period"])]

n = int(len(obs))
ones = np.ones(n)
y = obs["change_pp"].to_numpy(dtype=float)
sw = np.sqrt(obs["population"].to_numpy(dtype=float))
X = np.column_stack([ones, obs["period"].to_numpy(float), obs["control"].to_numpy(float), obs["x"].to_numpy(float)])
Z = np.column_stack([ones, obs["period"].to_numpy(float), obs["control"].to_numpy(float), obs["z"].to_numpy(float)])
Xw = X * sw[:, None]
Zw = Z * sw[:, None]
yw = y * sw

ZtZ_inv = np.linalg.inv(Zw.T @ Zw)
PZ = Zw @ ZtZ_inv @ Zw.T
beta = np.linalg.solve(Xw.T @ PZ @ Xw, Xw.T @ PZ @ yw)

p0, p1 = periods[0], periods[1]
exposure_area0_period0 = float(x_by[p0]["0"])
exposure_area0_period1 = float(x_by[p1]["0"])
instrument_area0_period0 = float(z_by[p0]["0"])

estimates = [
    {"term": "iv_slope", "estimate": float(beta[3]), "se": None, "n_obs": n},
    {"term": "exposure_area0_period0", "estimate": exposure_area0_period0, "se": None, "n_obs": n},
    {"term": "exposure_area0_period1", "estimate": exposure_area0_period1, "se": None, "n_obs": n},
    {"term": "instrument_area0_period0", "estimate": instrument_area0_period0, "se": None, "n_obs": n},
]

method_metadata = {
    "estimator": "weighted_2sls",
    "weights": "base_vintage_population",
    "endogenous": ["x"],
    "instruments": ["z"],
    "exogenous": ["intercept", "period", "control"],
    "exposure_units": "thousands of real dollars per worker per decade",
    "outcome_units": "percentage points per decade",
}

diagnostics = {
    "n_obs": n,
    "n_areas": int(len(areas_list)),
    "periods": [float(p) for p in periods],
    "industries": [str(i) for i in industries],
    "x_mean": float(obs["x"].mean()),
    "z_mean": float(obs["z"].mean()),
}

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": method_metadata,
    "diagnostics": diagnostics,
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
