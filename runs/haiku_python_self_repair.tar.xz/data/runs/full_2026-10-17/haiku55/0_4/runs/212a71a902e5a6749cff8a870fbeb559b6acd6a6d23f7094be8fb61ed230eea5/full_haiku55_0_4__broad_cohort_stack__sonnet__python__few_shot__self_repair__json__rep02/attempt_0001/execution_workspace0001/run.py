import json

import numpy as np
import pandas as pd

df = pd.read_csv('input.csv')
df['id'] = df['id'].astype(int)
df['time'] = df['time'].astype(int)
df['g'] = df['g'].astype(int)
df['y'] = df['y'].astype(float)

cohorts = [3, 5, 7]
results = {}
diagnostics = {'cohorts': {}}

for c in cohorts:
    lo, hi = c - 2, c + 2
    window = df[(df['time'] >= lo) & (df['time'] <= hi)]
    eligible = window[(window['g'] == c) | (window['g'] == 0) | (window['g'] > c + 2)].copy()

    window_counts = eligible.groupby('id')['time'].nunique()
    full_ids = window_counts[window_counts == (hi - lo + 1)].index
    sub = eligible[eligible['id'].isin(full_ids)].copy()

    sub['did'] = ((sub['g'] == c) & (sub['time'] >= c)).astype(float)

    unit_dummies = pd.get_dummies(sub['id'].astype(str), drop_first=True, dtype=float).values
    time_dummies = pd.get_dummies(sub['time'].astype(str), drop_first=True, dtype=float).values
    design = np.column_stack([
        np.ones(len(sub)),
        sub['did'].values,
        unit_dummies,
        time_dummies,
    ])

    beta = np.linalg.lstsq(design, sub['y'].values, rcond=None)[0]
    att = float(beta[1])

    n_treated = int(sub.loc[sub['g'] == c, 'id'].nunique())
    n_control = int(sub.loc[sub['g'] != c, 'id'].nunique())
    n_rows = int(len(sub))

    results[c] = {'att': att, 'n_treated': n_treated, 'n_rows': n_rows}
    diagnostics['cohorts'][f'g{c}'] = {
        'window_times': [lo, hi],
        'retained_treated_units': n_treated,
        'retained_control_units': n_control,
        'retained_rows': n_rows,
        'design_rank': int(np.linalg.matrix_rank(design)),
        'design_columns': int(design.shape[1]),
    }

total_weight = sum(results[c]['n_treated'] for c in cohorts)
att_weighted = float(
    sum(results[c]['n_treated'] * results[c]['att'] for c in cohorts) / total_weight
)
total_rows = int(sum(results[c]['n_rows'] for c in cohorts))

estimates = [
    {'term': 'att_g3', 'estimate': results[3]['att'], 'se': None, 'n_obs': results[3]['n_rows']},
    {'term': 'att_g5', 'estimate': results[5]['att'], 'se': None, 'n_obs': results[5]['n_rows']},
    {'term': 'att_g7', 'estimate': results[7]['att'], 'se': None, 'n_obs': results[7]['n_rows']},
    {'term': 'att_weighted', 'estimate': att_weighted, 'se': None, 'n_obs': total_rows},
]

output = {
    'task_id': 'broad_cohort_stack',
    'platform': 'python',
    'estimates': estimates,
    'method_metadata': {
        'design': 'separate cohort-specific stacked DiD, OLS with unit and calendar-time fixed effects',
        'cohorts': cohorts,
        'window_half_width': 2,
        'eligible_controls': 'g == 0 or g > c + 2',
        'balance': 'units observed at all five window times within each cohort comparison',
        'aggregation': 'weighted by retained treated unit count per cohort',
    },
    'diagnostics': diagnostics,
}

with open('result.json', 'w') as f:
    json.dump(output, f, indent=2, allow_nan=False)
