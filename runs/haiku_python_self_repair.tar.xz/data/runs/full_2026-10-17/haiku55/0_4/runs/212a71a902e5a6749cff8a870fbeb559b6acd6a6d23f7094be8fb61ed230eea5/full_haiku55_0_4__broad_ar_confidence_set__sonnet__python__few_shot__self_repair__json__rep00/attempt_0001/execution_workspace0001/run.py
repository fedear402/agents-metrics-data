import json

import numpy as np
import pandas as pd
from scipy.stats import f

data = pd.read_csv('input.csv')
y = data['y'].to_numpy(float)
endog = data['endog'].to_numpy(float)
x = data['x'].to_numpy(float)
z1 = data['z1'].to_numpy(float)
z2 = data['z2'].to_numpy(float)
n = len(y)

restricted = np.column_stack([np.ones(n), x])
unrestricted = np.column_stack([np.ones(n), x, z1, z2])
q = 2
dfree = n - 4
critical = f.ppf(0.95, q, dfree)


def residual(v, design):
    return v - design @ np.linalg.lstsq(design, v, rcond=None)[0]


def ar_f(beta):
    e = y - beta * endog
    r = residual(e, restricted)
    u = residual(e, unrestricted)
    ssr_r = r @ r
    ssr_u = u @ u
    return ((ssr_r - ssr_u) / q) / (ssr_u / dfree)


aR = residual(y, restricted)
bR = residual(endog, restricted)
aU = residual(y, unrestricted)
bU = residual(endog, unrestricted)

k = q * critical / dfree
A = bR @ bR - (1 + k) * (bU @ bU)
B = -2 * (aR @ bR - (1 + k) * (aU @ bU))
C = aR @ aR - (1 + k) * (aU @ aU)
disc = B * B - 4 * A * C

assert A != 0 and disc > 0
roots = np.sort(np.roots([A, B, C]).real)
unbounded = int(A < 0)


def accepts(beta):
    return A * beta * beta + B * beta + C <= 0


for root in roots:
    assert np.isclose(ar_f(root), critical, atol=1e-8)

result = {
    'task_id': 'broad_ar_confidence_set',
    'platform': 'python',
    'estimates': [
        {'term': 'boundary_low', 'estimate': float(roots[0]), 'se': None, 'n_obs': int(n)},
        {'term': 'boundary_high', 'estimate': float(roots[1]), 'se': None, 'n_obs': int(n)},
        {'term': 'accepts_zero', 'estimate': float(int(accepts(0.0))), 'se': None, 'n_obs': int(n)},
        {'term': 'unbounded', 'estimate': float(unbounded), 'se': None, 'n_obs': int(n)},
        {'term': 'ar_f_at_one', 'estimate': float(ar_f(1.0)), 'se': None, 'n_obs': int(n)},
    ],
    'method_metadata': {
        'estimator': 'Anderson-Rubin inversion of homoskedastic joint F test',
        'vcov': 'homoskedastic',
    },
    'diagnostics': {},
}

with open('result.json', 'w') as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
