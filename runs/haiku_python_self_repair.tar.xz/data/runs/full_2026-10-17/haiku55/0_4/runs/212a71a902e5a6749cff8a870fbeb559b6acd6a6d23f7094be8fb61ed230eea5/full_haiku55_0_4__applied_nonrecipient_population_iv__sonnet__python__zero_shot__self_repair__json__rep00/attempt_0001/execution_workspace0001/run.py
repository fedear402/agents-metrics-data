import json

import numpy as np
import pandas as pd

hh = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

df = hh[hh["recipient"] == 0].copy()
n_obs = int(len(df))

e = df["eligible"].astype(float).to_numpy()
ne = 1.0 - e
d = df["dose"].astype(float).to_numpy()
b = df["baseline"].astype(float).to_numpy()
z = df["instrument"].astype(float).to_numpy()
w = df["weight"].astype(float).to_numpy()
y = df["outcome"].astype(float).to_numpy()

X = np.column_stack([d * ne, d * e, ne, e, b * ne, b * e])
Z = np.column_stack([ne, e, b * ne, b * e, z * ne, z * e])

sw = np.sqrt(w)
Xw = X * sw[:, None]
Zw = Z * sw[:, None]
yw = y * sw

Xhat = Zw @ np.linalg.lstsq(Zw, Xw, rcond=None)[0]
beta = np.linalg.lstsq(Xhat, yw, rcond=None)[0]

slope_inel = float(beta[0])
slope_elig = float(beta[1])

w0 = w * ne
w1 = w * e
mean_dose_inel = float(np.sum(w0 * d) / np.sum(w0))
mean_dose_elig = float(np.sum(w1 * d) / np.sum(w1))

ineligible_effect = slope_inel * mean_dose_inel
eligible_nonrecipient_effect = slope_elig * mean_dose_elig

N0 = float(census.loc[census["eligible"] == 0, "nonrecipient_population"].sum())
N1 = float(census.loc[census["eligible"] == 1, "nonrecipient_population"].sum())
population_effect = (N0 * ineligible_effect + N1 * eligible_nonrecipient_effect) / (N0 + N1)

estimates = [
    {"term": "ineligible_effect", "estimate": float(ineligible_effect), "se": None, "n_obs": n_obs},
    {"term": "eligible_nonrecipient_effect", "estimate": float(eligible_nonrecipient_effect), "se": None, "n_obs": n_obs},
    {"term": "population_effect", "estimate": float(population_effect), "se": None, "n_obs": n_obs},
]

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "method": "weighted two-stage least squares",
        "regression_weight": "weight",
        "endogenous_columns": ["dose*(1-eligible)", "dose*eligible"],
        "exogenous_columns": ["1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"],
        "instrument_columns": [
            "1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible",
            "instrument*(1-eligible)", "instrument*eligible",
        ],
        "intercept": "none added; eligible indicators span the intercept",
        "sample": "households with recipient == 0, both treatment statuses retained",
        "group_effect": "fitted dose slope times weighted mean dose within eligibility group",
        "counterfactual": "dose set to zero for every retained household (synthetic attribution convention)",
        "population_weights": "census nonrecipient_population used only for final between-group weights",
        "standard_errors": "not computed; se reported as null",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "n_ineligible_obs": int(np.sum(ne)),
        "n_eligible_obs": int(np.sum(e)),
        "instrument_matrix_rank": int(np.linalg.matrix_rank(Zw)),
        "regressor_matrix_rank": int(np.linalg.matrix_rank(Xw)),
        "dose_slope_ineligible": slope_inel,
        "dose_slope_eligible": slope_elig,
        "weighted_mean_dose_ineligible": mean_dose_inel,
        "weighted_mean_dose_eligible": mean_dose_elig,
        "census_nonrecipient_population_ineligible": N0,
        "census_nonrecipient_population_eligible": N1,
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
