import json

import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")

reg = df.groupby("region_id")[["region_weight", "x", "y"]].first()
e = reg["region_weight"] / reg["region_weight"].sum()

df["p"] = df["share"] * df["shock"]
z = df.groupby("region_id")["p"].sum()
reg["z"] = z


def wdm(v, w):
    return v - np.sum(w * v)


e_arr = e.values
y0 = pd.Series(wdm(reg["y"].values, e_arr), index=reg.index)
x0 = pd.Series(wdm(reg["x"].values, e_arr), index=reg.index)
z0 = pd.Series(wdm(reg["z"].values, e_arr), index=reg.index)

effect_reg = np.sum(e_arr * z0.values * y0.values) / np.sum(e_arr * z0.values * x0.values)
first_stage_reg = np.sum(e_arr * z0.values * x0.values) / np.sum(e_arr * z0.values * z0.values)

df["e"] = df["region_id"].map(e)
df["ew"] = df["e"] * df["share"]
df["y0"] = df["region_id"].map(y0)
df["x0"] = df["region_id"].map(x0)
df["z0"] = df["region_id"].map(z0)

s = df.groupby("industry_id")["ew"].sum()


def agg(col):
    t = (df["ew"] * df[col]).groupby(df["industry_id"]).sum()
    return t / s


ybar = agg("y0")
xbar = agg("x0")
zbar = agg("z0")
shock = df.groupby("industry_id")["shock"].first()

s_arr = s.values
N = len(s_arr)


def cen(v):
    v = v.values
    return v - np.sum(s_arr * v) / np.sum(s_arr)


sh = cen(shock)
yt = cen(ybar)
xt = cen(xbar)
zt = cen(zbar)

mult = N / (N - 2)

denom_eff = np.sum(s_arr * sh * xt)
beta = np.sum(s_arr * sh * yt) / denom_eff
u = yt - beta * xt
var_eff = mult * np.sum((s_arr * sh * u) ** 2) / denom_eff ** 2
se_eff = np.sqrt(var_eff)

denom_fs = np.sum(s_arr * sh * zt)
gamma = np.sum(s_arr * sh * xt) / denom_fs
v = xt - gamma * zt
var_fs = mult * np.sum((s_arr * sh * v) ** 2) / denom_fs ** 2
se_fs = np.sqrt(var_fs)

effective_shocks = 1.0 / np.sum(s_arr ** 2)

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": float(effect_reg), "se": float(se_eff), "n_obs": int(N)},
        {"term": "first_stage", "estimate": float(first_stage_reg), "se": float(se_fs), "n_obs": int(N)},
        {"term": "effective_shocks", "estimate": float(effective_shocks), "se": None, "n_obs": int(N)},
    ],
    "method_metadata": {
        "estimator": "Weighted regional 2SLS of y on x instrumented by shift-share z, equivalent to BHJ shock-level weighted IV",
        "vcov": "BHJ shock-level HC1 robust variance with N/(N-2) multiplier, structural IV residuals, no clustering",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
