import json

import numpy as np
import pandas as pd
from scipy.stats import norm
from statsmodels.tsa.arima.model import ARIMA

df = pd.read_csv("./input.csv").sort_values("t")
train = df[df["t"] < 251]
y = train["y"].astype(float).to_numpy()
n_obs = int(len(y))

res = ARIMA(y, order=(1, 1, 1), trend="n").fit()

fc = res.get_forecast(steps=1)
mean = float(np.asarray(fc.predicted_mean)[0])
se = float(np.sqrt(np.asarray(fc.var_pred_mean)[0]))
z = float(norm.ppf(0.975))
lower = mean - z * se
upper = mean + z * se

converged = None
if res.mle_retvals is not None:
    converged = bool(res.mle_retvals.get("converged", False))

out = {
    "task_id": "arima_forecast",
    "platform": "python",
    "estimates": [
        {"term": "forecast", "estimate": mean, "se": se, "n_obs": n_obs},
        {"term": "lower_95", "estimate": float(lower), "se": se, "n_obs": n_obs},
        {"term": "upper_95", "estimate": float(upper), "se": se, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "ARIMA(1,1,1) maximum likelihood, no constant (statsmodels)",
        "vcov": "statsmodels default MLE covariance (" + str(res.cov_type) + ")",
    },
    "diagnostics": {
        "converged": converged,
        "aic": float(res.aic),
        "bic": float(res.bic),
        "ar1": float(res.params[0]),
        "ma1": float(res.params[1]),
        "sigma2": float(res.params[2]),
    },
}

with open("result.json", "w") as f:
    json.dump(out, f, indent=2)
