import json

import numpy as np
import pandas as pd
from scipy.stats import f

data = pd.read_csv("input.csv")
y = data["y"].to_numpy(dtype=float)
endog = data["endog"].to_numpy(dtype=float)
x = data["x"].to_numpy(dtype=float)
z1 = data["z1"].to_numpy(dtype=float)
z2 = data["z2"].to_numpy(dtype=float)
n = len(y)

ones = np.ones(n)
restricted_design = np.column_stack([ones, x])
unrestricted_design = np.column_stack([ones, x, z1, z2])
q = 2
dfd = n - unrestricted_design.shape[1]


def residual(v, design):
    return v - design @ np.linalg.lstsq(design, v, rcond=None)[0]


ry = residual(y, restricted_design)
rd = residual(endog, restricted_design)
uy = residual(y, unrestricted_design)
ud = residual(endog, unrestricted_design)

critical = f.ppf(0.95, q, dfd)
k = q * critical / dfd

A = rd @ rd - (1 + k) * (ud @ ud)
B = -2.0 * (ry @ rd - (1 + k) * (uy @ ud))
C = ry @ ry - (1 + k) * (uy @ uy)
discriminant = B * B - 4.0 * A * C


def f_stat(beta):
    r = ry - beta * rd
    u = uy - beta * ud
    ssr_r = r @ r
    ssr_u = u @ u
    return ((ssr_r - ssr_u) / q) / (ssr_u / dfd)


def accepts(beta):
    return f_stat(beta) <= critical


if abs(A) > 1e-12 and discriminant >= 0:
    root_a = (-B - np.sqrt(discriminant)) / (2.0 * A)
    root_b = (-B + np.sqrt(discriminant)) / (2.0 * A)
    boundary_low, boundary_high = sorted([root_a, root_b])
    unbounded = int(A < 0)
else:
    boundary_low, boundary_high = float("nan"), float("nan")
    unbounded = 1

accepts_zero = int(accepts(0.0))
ar_f_at_one = float(f_stat(1.0))

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": [
        {"term": "boundary_low", "estimate": float(boundary_low), "se": None, "n_obs": int(n)},
        {"term": "boundary_high", "estimate": float(boundary_high), "se": None, "n_obs": int(n)},
        {"term": "accepts_zero", "estimate": float(accepts_zero), "se": None, "n_obs": int(n)},
        {"term": "unbounded", "estimate": float(unbounded), "se": None, "n_obs": int(n)},
        {"term": "ar_f_at_one", "estimate": ar_f_at_one, "se": None, "n_obs": int(n)},
    ],
    "method_metadata": {
        "estimator": "Anderson-Rubin confidence set by inverting homoskedastic joint F test of excluded instruments z1 and z2",
        "vcov": "homoskedastic",
    },
    "diagnostics": {
        "critical_value": float(critical),
        "numerator_df": int(q),
        "denominator_df": int(dfd),
        "quadratic_A": float(A),
        "quadratic_B": float(B),
        "quadratic_C": float(C),
        "discriminant": float(discriminant),
    },
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
