import json

import numpy as np
import pandas as pd

crosswalk = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv")
areas = pd.read_csv("areas.csv")
employment = pd.read_csv("employment.csv")
outcomes = pd.read_csv("outcomes.csv")

for df in (crosswalk, trade, areas, employment, outcomes):
    for col in df.columns:
        if df[col].dtype == object:
            df[col] = df[col].str.strip()

trade_ind = trade.merge(crosswalk, on="code", how="inner")
tp = (
    trade_ind.groupby(["period", "industry"], as_index=False)
    .agg(
        us_change=("us_change", "first"),
        other_change=("other_change", "first"),
        price_index=("price_index", "first"),
        years=("years", "first"),
    )
)

industries = sorted(tp["industry"].unique())
keys = areas[["area", "period", "vintage", "total_employment"]].drop_duplicates(
    ["area", "period", "vintage"]
)
full = keys.merge(pd.DataFrame({"industry": industries}), how="cross")

emp_sum = employment.groupby(
    ["area", "period", "vintage", "industry"], as_index=False
)["employment"].sum()
full = full.merge(emp_sum, on=["area", "period", "vintage", "industry"], how="left")
full["employment"] = full["employment"].fillna(0.0)

nat = (
    full.groupby(["period", "vintage", "industry"], as_index=False)["employment"]
    .sum()
    .rename(columns={"employment": "nat"})
)
full = full.merge(nat, on=["period", "vintage", "industry"], how="left")
full = full.merge(tp, on=["period", "industry"], how="left")

full["share"] = full["employment"] / full["total_employment"]
full["scale"] = 10.0 / full["years"] / (full["price_index"] / 100.0) / 1000.0
full["change"] = np.where(full["vintage"] == "base", full["us_change"], full["other_change"])
full["term"] = full["share"] * full["change"] / full["nat"] * full["scale"]

ex = (
    full.groupby(["area", "period", "vintage"])["term"]
    .sum()
    .unstack("vintage")
    .reset_index()
    .rename(columns={"base": "x", "early": "z"})
)

pop = areas.loc[areas["vintage"] == "base", ["area", "period", "population"]]
data = (
    outcomes.merge(ex[["area", "period", "x", "z"]], on=["area", "period"], how="inner")
    .merge(pop, on=["area", "period"], how="inner")
    .sort_values(["area", "period"])
    .reset_index(drop=True)
)

n = int(len(data))
y = data["change_pp"].to_numpy(dtype=float)
x = data["x"].to_numpy(dtype=float)
z = data["z"].to_numpy(dtype=float)
w = data["population"].to_numpy(dtype=float)
exog = np.column_stack([
    np.ones(n),
    data["period"].to_numpy(dtype=float),
    data["control"].to_numpy(dtype=float),
])
X = np.column_stack([exog, x])
Z = np.column_stack([exog, z])

XtWZ = X.T @ (w[:, None] * Z)
ZtWZ_inv = np.linalg.inv(Z.T @ (w[:, None] * Z))
ZtWX = Z.T @ (w[:, None] * X)
ZtWy = Z.T @ (w * y)
beta = np.linalg.solve(XtWZ @ ZtWZ_inv @ ZtWX, XtWZ @ ZtWZ_inv @ ZtWy)
iv_slope = float(beta[-1])

def pick(area, period, col):
    row = data[(data["area"] == area) & (data["period"] == period)]
    return float(row[col].iloc[0])

exposure_area0_period0 = pick(0, 0, "x")
exposure_area0_period1 = pick(0, 1, "x")
instrument_area0_period0 = pick(0, 0, "z")

estimates = [
    {"term": "iv_slope", "estimate": iv_slope, "se": None, "n_obs": n},
    {"term": "exposure_area0_period0", "estimate": exposure_area0_period0, "se": None, "n_obs": n},
    {"term": "exposure_area0_period1", "estimate": exposure_area0_period1, "se": None, "n_obs": n},
    {"term": "instrument_area0_period0", "estimate": instrument_area0_period0, "se": None, "n_obs": n},
]

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "weighted_2SLS",
        "dependent": "change_pp",
        "endogenous": ["x"],
        "exogenous": ["intercept", "period", "control"],
        "instruments": ["z"],
        "weight": "base_vintage_population",
        "exposure_definition": "sum_j(base_share_j * us_change_j / national_base_emp_j / (price_index/100) / 1000 * (10/years))",
        "instrument_definition": "same as exposure with early vintage and other_change",
        "industries": [str(i) for i in industries],
    },
    "diagnostics": {
        "n_area_periods": n,
        "n_industries": int(len(industries)),
        "min_national_employment_base": float(nat.loc[nat["vintage"] == "base", "nat"].min()),
        "min_national_employment_early": float(nat.loc[nat["vintage"] == "early", "nat"].min()),
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
