import json

import numpy as np
import pandas as pd

BANDWIDTH = 1.0

df = pd.read_csv("input.csv")
d = df[np.abs(df["score"]) < BANDWIDTH].copy()
d["w"] = 1.0 - np.abs(d["score"])
n_obs = int(len(d))

def side_fit(g):
    X = np.column_stack([np.ones(len(g)), g["score"].values])
    w = g["w"].values
    inv = np.linalg.inv(X.T @ (w[:, None] * X))
    outcomes = [g["earnings"].values, g["participated"].values]
    betas, scores = [], []
    for y in outcomes:
        beta = inv @ (X.T @ (w * y))
        e = y - X @ beta
        betas.append(beta)
        scores.append((w * e)[:, None] * X)
    S = np.hstack(scores)
    Bd = np.block([[inv, np.zeros((2, 2))], [np.zeros((2, 2)), inv]])
    V = Bd @ (S.T @ S) @ Bd
    theta = np.concatenate(betas)
    return theta, V

L = d[d["score"] < 0]
R = d[d["score"] >= 0]

thL, VL = side_fit(L)
thR, VR = side_fit(R)

theta = np.concatenate([thL, thR])
V = np.zeros((8, 8))
V[:4, :4] = VL
V[4:, 4:] = VR

g_rf = np.zeros(8)
g_rf[4], g_rf[0] = 1.0, -1.0
g_fs = np.zeros(8)
g_fs[6], g_fs[2] = 1.0, -1.0

rf = float(g_rf @ theta)
fs = float(g_fs @ theta)
tau = rf / fs

grad = g_rf / fs - (rf / fs**2) * g_fs
se_tau = float(np.sqrt(grad @ V @ grad))
se_rf = float(np.sqrt(g_rf @ V @ g_rf))
se_fs = float(np.sqrt(g_fs @ V @ g_fs))

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": float(tau), "se": se_tau, "n_obs": n_obs},
        {"term": "reduced_form", "estimate": rf, "se": se_rf, "n_obs": n_obs},
        {"term": "first_stage", "estimate": fs, "se": se_fs, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "Fuzzy RD, local linear with separate slopes and intercepts, triangular kernel weights 1-|score|, cutoff 0, bandwidth 1, no bias correction",
        "vcov": "HC0 heteroskedasticity-robust sandwich (no small-sample correction), joint covariance across outcomes, delta method for ratio",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
