import json

import numpy as np
import pandas as pd
from scipy import stats

df = pd.read_csv("input.csv")
n = len(df)
y = df["y"].to_numpy(dtype=float)
e = df["endog"].to_numpy(dtype=float)
x = df["x"].to_numpy(dtype=float)
z1 = df["z1"].to_numpy(dtype=float)
z2 = df["z2"].to_numpy(dtype=float)

ones = np.ones(n)
X0 = np.column_stack([ones, x])
X1 = np.column_stack([ones, x, z1, z2])


def annihilator(X):
    return np.eye(n) - X @ np.linalg.pinv(X)


M0 = annihilator(X0)
M1 = annihilator(X1)

df_den = n - 4
crit = stats.f.ppf(0.95, 2, df_den)


def ar_f(b):
    v = y - b * e
    rss0 = v @ M0 @ v
    rss1 = v @ M1 @ v
    return ((rss0 - rss1) / 2.0) / (rss1 / df_den)


yM0y, yM0e, eM0e = y @ M0 @ y, y @ M0 @ e, e @ M0 @ e
yM1y, yM1e, eM1e = y @ M1 @ y, y @ M1 @ e, e @ M1 @ e

k = df_den / 2.0
A = k * (eM0e - eM1e) - crit * eM1e
B = k * (-2.0 * yM0e + 2.0 * yM1e) + 2.0 * crit * yM1e
C = k * (yM0y - yM1y) - crit * yM1y

unbounded = 1 if A <= 0 else 0

disc = B * B - 4.0 * A * C
if A != 0 and disc >= 0:
    sq = np.sqrt(disc)
    r = sorted([(-B - sq) / (2.0 * A), (-B + sq) / (2.0 * A)])
    boundary_low, boundary_high = float(r[0]), float(r[1])
else:
    boundary_low, boundary_high = float("nan"), float("nan")

accepts_zero = 1 if ar_f(0.0) <= crit else 0
ar_f_at_one = float(ar_f(1.0))

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": [
        {"term": "boundary_low", "estimate": boundary_low, "se": None, "n_obs": int(n)},
        {"term": "boundary_high", "estimate": boundary_high, "se": None, "n_obs": int(n)},
        {"term": "accepts_zero", "estimate": float(accepts_zero), "se": None, "n_obs": int(n)},
        {"term": "unbounded", "estimate": float(unbounded), "se": None, "n_obs": int(n)},
        {"term": "ar_f_at_one", "estimate": ar_f_at_one, "se": None, "n_obs": int(n)},
    ],
    "method_metadata": {
        "estimator": "Anderson-Rubin test inversion (homoskedastic joint F test of excluded instruments z1, z2)",
        "vcov": "homoskedastic",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
