import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df = df[np.abs(df["score"]) < 1].copy()
h = 1.0

s = df["score"].to_numpy(dtype=float)
w = 1.0 - np.abs(s)
y_e = df["earnings"].to_numpy(dtype=float)
d = df["participated"].to_numpy(dtype=float)
right = (s >= 0).astype(float)
left = 1.0 - right

X = np.column_stack([
    left,
    right,
    left * s,
    right * s,
])
n = len(s)


def fit(Y):
    Xw = X * w[:, None]
    bread = np.linalg.inv(X.T @ Xw)
    beta = bread @ (Xw.T @ Y)
    resid = Y - X @ beta
    return beta, bread, resid


Y = np.column_stack([y_e, d])
beta, bread, resid = fit(Y)

contrast = np.array([-1.0, 1.0, 0.0, 0.0])
jumps = contrast @ beta  # columns: earnings jump, participation jump
reduced_form, first_stage = jumps[0], jumps[1]

# Influence contributions for each discontinuity (HC0 sandwich rows)
loading = w * (X @ bread @ contrast)  # n-vector
infl = loading[:, None] * resid  # n x 2
joint = infl.T @ infl  # HC0, no dof correction

ratio = reduced_form / first_stage
grad = np.array([1.0 / first_stage, -reduced_form / first_stage**2])
ratio_se = float(np.sqrt(grad @ joint @ grad))

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {
            "term": "treatment_effect",
            "estimate": float(ratio),
            "se": ratio_se,
            "n_obs": int(n),
        },
        {
            "term": "reduced_form",
            "estimate": float(reduced_form),
            "se": float(np.sqrt(joint[0, 0])),
            "n_obs": int(n),
        },
        {
            "term": "first_stage",
            "estimate": float(first_stage),
            "se": float(np.sqrt(joint[1, 1])),
            "n_obs": int(n),
        },
    ],
    "method_metadata": {
        "estimator": "fuzzy RD, local linear, triangular kernel, bandwidth 1, separate slopes",
        "vcov": "HC0 heteroskedasticity-robust, delta method for ratio",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2, allow_nan=False)
