import json

import numpy as np
import pandas as pd
from statsmodels.tsa.arima.model import ARIMA

df = pd.read_csv("input.csv").sort_values("t").reset_index(drop=True)
y = df["y"].astype(float).reset_index(drop=True)

model = ARIMA(y, order=(1, 1, 1), trend="n")
res = model.fit()

fc = res.get_forecast(steps=1)
mean = float(np.asarray(fc.predicted_mean)[0])
conf = np.asarray(fc.conf_int(alpha=0.05))[0]
lower = float(conf[0])
upper = float(conf[1])
se = float(np.sqrt(np.asarray(fc.var_pred_mean)[0]))

n_obs = int(len(y))

out = {
    "task_id": "arima_forecast",
    "platform": "python",
    "estimates": [
        {"term": "forecast", "estimate": mean, "se": se, "n_obs": n_obs},
        {"term": "lower_95", "estimate": lower, "se": None, "n_obs": n_obs},
        {"term": "upper_95", "estimate": upper, "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "ARIMA(1,1,1) no constant, MLE",
        "vcov": "ML (statsmodels state-space)",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(out, f)
