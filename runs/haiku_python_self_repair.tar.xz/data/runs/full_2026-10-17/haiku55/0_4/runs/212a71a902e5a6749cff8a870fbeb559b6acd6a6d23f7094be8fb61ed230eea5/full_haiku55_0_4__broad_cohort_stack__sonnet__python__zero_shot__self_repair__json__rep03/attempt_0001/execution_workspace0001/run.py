import json

import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")

cohorts = [3, 5, 7]
rows = []
weights = []
atts = []
row_counts = []

for c in cohorts:
    lo, hi = c - 2, c + 2
    win = df[(df["time"] >= lo) & (df["time"] <= hi)]

    unit_g = win.groupby("id")["g"].first()
    eligible = unit_g[(unit_g == c) | (unit_g == 0) | (unit_g > c + 2)].index
    sub = win[win["id"].isin(eligible)]

    n_times = sub.groupby("id")["time"].nunique()
    balanced = n_times[n_times == 5].index
    sub = sub[sub["id"].isin(balanced)].copy()

    sub["did"] = ((sub["g"] == c) & (sub["time"] >= c)).astype(float)

    n_treated = int(sub.loc[sub["g"] == c, "id"].nunique())

    unit_d = pd.get_dummies(sub["id"], dtype=float).values
    time_d = pd.get_dummies(sub["time"], dtype=float).values
    X = np.column_stack([sub["did"].values, unit_d, time_d])
    y = sub["y"].values.astype(float)

    beta = np.linalg.lstsq(X, y, rcond=None)[0]
    att = float(beta[0])

    atts.append(att)
    weights.append(n_treated)
    row_counts.append(int(len(sub)))
    rows.append({
        "term": f"att_g{c}",
        "estimate": att,
        "se": None,
        "n_obs": int(len(sub)),
    })

weights_arr = np.asarray(weights, dtype=float)
att_weighted = float(np.sum(weights_arr * np.asarray(atts)) / np.sum(weights_arr))

rows.append({
    "term": "att_weighted",
    "estimate": att_weighted,
    "se": None,
    "n_obs": int(sum(row_counts)),
})

result = {
    "task_id": "broad_cohort_stack",
    "platform": "python",
    "estimates": rows,
    "method_metadata": {},
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
