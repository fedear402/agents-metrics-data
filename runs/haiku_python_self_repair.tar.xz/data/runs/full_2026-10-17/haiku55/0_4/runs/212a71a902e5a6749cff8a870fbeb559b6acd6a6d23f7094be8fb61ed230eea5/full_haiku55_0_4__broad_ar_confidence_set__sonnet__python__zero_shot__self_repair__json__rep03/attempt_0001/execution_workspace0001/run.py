import json

import numpy as np
import pandas as pd
from scipy import stats

df = pd.read_csv("input.csv")
n = len(df)
y = df["y"].to_numpy(dtype=float)
en = df["endog"].to_numpy(dtype=float)
x = df["x"].to_numpy(dtype=float)
z1 = df["z1"].to_numpy(dtype=float)
z2 = df["z2"].to_numpy(dtype=float)

ones = np.ones(n)
W = np.column_stack([ones, x])
Z = np.column_stack([ones, x, z1, z2])


def resid(M, v):
    b = np.linalg.lstsq(M, v, rcond=None)[0]
    return v - M @ b


ry_f = resid(Z, y)
re_f = resid(Z, en)
ry_r = resid(W, y)
re_r = resid(W, en)

A0 = ry_f @ ry_f
A1 = re_f @ ry_f
A2 = re_f @ re_f
B0 = ry_r @ ry_r
B1 = re_r @ ry_r
B2 = re_r @ re_r

df_den = n - 4
c = stats.f.ppf(0.95, 2, df_den)
k = df_den / 2.0

# Accept beta iff q(beta) = a2*beta^2 + a1*beta + a0 <= 0
a2 = k * (B2 - A2) - c * A2
a1 = -2.0 * k * (B1 - A1) + 2.0 * c * A1
a0 = k * (B0 - A0) - c * A0

roots = []
disc = a1 * a1 - 4.0 * a2 * a0
if abs(a2) > 1e-14 and disc >= 0:
    sq = np.sqrt(disc)
    roots = sorted([(-a1 - sq) / (2.0 * a2), (-a1 + sq) / (2.0 * a2)])
elif abs(a2) <= 1e-14 and abs(a1) > 1e-14:
    roots = [-a0 / a1]

boundary_low = float(roots[0]) if len(roots) >= 1 else None
boundary_high = float(roots[-1]) if len(roots) >= 2 else None

accepts_zero = int(a0 <= 0)

if a2 < -1e-14:
    unbounded = 1
elif abs(a2) <= 1e-14 and abs(a1) > 1e-14:
    unbounded = 1
elif abs(a2) <= 1e-14 and abs(a1) <= 1e-14:
    unbounded = int(a0 <= 0)
else:
    unbounded = 0

b = 1.0
rss_u_1 = A0 - 2.0 * b * A1 + b * b * A2
rss_r_1 = B0 - 2.0 * b * B1 + b * b * B2
ar_f_at_one = float(((rss_r_1 - rss_u_1) / 2.0) / (rss_u_1 / df_den))

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": [
        {"term": "boundary_low", "estimate": boundary_low, "se": None, "n_obs": int(n)},
        {"term": "boundary_high", "estimate": boundary_high, "se": None, "n_obs": int(n)},
        {"term": "accepts_zero", "estimate": float(accepts_zero), "se": None, "n_obs": int(n)},
        {"term": "unbounded", "estimate": float(unbounded), "se": None, "n_obs": int(n)},
        {"term": "ar_f_at_one", "estimate": ar_f_at_one, "se": None, "n_obs": int(n)},
    ],
    "method_metadata": {
        "estimator": "Anderson-Rubin confidence set via inverted joint F test of excluded instruments",
        "vcov": "homoskedastic",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
