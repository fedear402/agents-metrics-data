import json

import numpy as np
import pandas as pd
from statsmodels.tsa.arima.model import ARIMA

df = pd.read_csv("./input.csv").sort_values("t").reset_index(drop=True)
train = df[df["t"] < 251]
y = train["y"].astype(float).to_numpy()
n_obs = int(len(y))

res = ARIMA(y, order=(1, 1, 1), trend="n").fit()

fc = res.get_forecast(steps=1)
forecast = float(np.asarray(fc.predicted_mean)[0])
ci = np.asarray(fc.conf_int(alpha=0.05))[0]
lower_95 = float(ci[0])
upper_95 = float(ci[1])
se = float(np.asarray(fc.se_mean)[0])

retvals = res.mle_retvals or {}
converged = bool(retvals.get("converged", True))

result = {
    "task_id": "arima_forecast",
    "platform": "python",
    "estimates": [
        {"term": "forecast", "estimate": forecast, "se": se, "n_obs": n_obs},
        {"term": "lower_95", "estimate": lower_95, "se": None, "n_obs": n_obs},
        {"term": "upper_95", "estimate": upper_95, "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "ARIMA(1,1,1) exact maximum likelihood (statsmodels state space), no constant or drift",
        "vcov": str(res.cov_type),
    },
    "diagnostics": {
        "loglikelihood": float(res.llf),
        "aic": float(res.aic),
        "bic": float(res.bic),
        "converged": converged,
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
