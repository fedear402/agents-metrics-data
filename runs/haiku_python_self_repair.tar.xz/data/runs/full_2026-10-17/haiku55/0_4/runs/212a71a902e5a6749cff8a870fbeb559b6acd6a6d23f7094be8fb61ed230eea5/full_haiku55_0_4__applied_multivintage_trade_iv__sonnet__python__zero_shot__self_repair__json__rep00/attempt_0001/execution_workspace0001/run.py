import json

import numpy as np
import pandas as pd

crosswalk = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv")
areas = pd.read_csv("areas.csv")
employment = pd.read_csv("employment.csv")
outcomes = pd.read_csv("outcomes.csv")

for df in (crosswalk, trade, areas, employment, outcomes):
    df.columns = df.columns.str.strip()

trade = trade.merge(crosswalk[["code", "industry"]].drop_duplicates(), on="code", how="inner")
industries = sorted(trade["industry"].unique())

trade_ind = trade.groupby(["period", "industry"], as_index=False)[["us_change", "other_change"]].sum()
trade_per = trade.groupby("period", as_index=False)[["price_index", "years"]].first()

emp_sum = employment.groupby(["area", "period", "vintage", "industry"], as_index=False)["employment"].sum()

avv = areas[["area", "period", "vintage"]].drop_duplicates()
grid = avv.merge(pd.DataFrame({"industry": industries}), how="cross")
grid = grid.merge(emp_sum, on=["area", "period", "vintage", "industry"], how="left")
grid["employment"] = grid["employment"].fillna(0.0)

nat = (grid.groupby(["vintage", "period", "industry"], as_index=False)["employment"]
       .sum()
       .rename(columns={"employment": "nat_emp"}))

tot = areas[["area", "period", "vintage", "total_employment"]]


def exposure(vint, shock):
    d = grid[grid["vintage"] == vint].merge(
        tot[tot["vintage"] == vint][["area", "period", "total_employment"]],
        on=["area", "period"],
    )
    d = d.merge(nat[nat["vintage"] == vint][["period", "industry", "nat_emp"]],
                on=["period", "industry"])
    d = d.merge(trade_ind[["period", "industry", shock]], on=["period", "industry"])
    d = d.merge(trade_per, on="period")
    d["term"] = (
        (d["employment"] / d["total_employment"])
        * (d[shock] / d["nat_emp"])
        / (d["price_index"] / 100)
        / 1000
        * (10 / d["years"])
    )
    return d.groupby(["area", "period"], as_index=False)["term"].sum()


x_df = exposure("base", "us_change").rename(columns={"term": "x"})
z_df = exposure("early", "other_change").rename(columns={"term": "z"})

panel = (areas[areas["vintage"] == "base"][["area", "period", "population"]]
         .merge(outcomes[["area", "period", "control", "change_pp"]], on=["area", "period"])
         .merge(x_df, on=["area", "period"])
         .merge(z_df, on=["area", "period"]))

n = len(panel)
y = panel["change_pp"].to_numpy(dtype=float)
ones = np.ones(n)
X = np.column_stack([ones, panel["period"].to_numpy(float),
                     panel["control"].to_numpy(float), panel["x"].to_numpy(float)])
Z = np.column_stack([ones, panel["period"].to_numpy(float),
                     panel["control"].to_numpy(float), panel["z"].to_numpy(float)])
w = np.sqrt(panel["population"].to_numpy(dtype=float))

Xw = X * w[:, None]
Zw = Z * w[:, None]
yw = y * w

first_stage = np.linalg.lstsq(Zw, Xw, rcond=None)[0]
Xhat = Zw @ first_stage
beta = np.linalg.lstsq(Xhat, yw, rcond=None)[0]


def lookup(col, a, p):
    return float(panel.loc[(panel["area"] == a) & (panel["period"] == p), col].iloc[0])


iv_slope = float(beta[3])
exposure_area0_period0 = lookup("x", 0, 0)
exposure_area0_period1 = lookup("x", 0, 1)
instrument_area0_period0 = lookup("z", 0, 0)

estimates = [
    {"term": "iv_slope", "estimate": iv_slope, "se": None, "n_obs": int(n)},
    {"term": "exposure_area0_period0", "estimate": exposure_area0_period0, "se": None, "n_obs": int(n)},
    {"term": "exposure_area0_period1", "estimate": exposure_area0_period1, "se": None, "n_obs": int(n)},
    {"term": "instrument_area0_period0", "estimate": instrument_area0_period0, "se": None, "n_obs": int(n)},
]

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "method": "weighted_2sls",
        "outcome": "change_pp",
        "regressors": ["intercept", "period", "control", "x"],
        "instruments": ["intercept", "period", "control", "z"],
        "endogenous": ["x"],
        "weight": "base_vintage_population",
        "n_industries": int(len(industries)),
    },
    "diagnostics": {
        "n_obs": int(n),
        "first_stage_coef_z_on_x": float(first_stage[3, 3]),
        "corr_x_z": float(np.corrcoef(panel["x"], panel["z"])[0, 1]),
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
