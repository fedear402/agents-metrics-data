import json

import numpy as np
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("input.csv")
n_obs = int(len(df))

X = sm.add_constant(df[["x", "z"]].astype(float))
y = df["y"].astype(int)

model = sm.MNLogit(y, X)
res = model.fit(method="newton", maxiter=200, disp=False)

params = res.params
cov = res.cov_params()

def get_est(outcome, term):
    return float(params.loc[term, outcome])

def get_se(outcome, term):
    return float(np.sqrt(cov.loc[(outcome, term), (outcome, term)]))

b1_x = get_est(1, "x")
b1_z = get_est(1, "z")
b2_x = get_est(2, "x")
b2_z = get_est(2, "z")

se1_x = get_se(1, "x")
se1_z = get_se(1, "z")
se2_x = get_se(2, "x")
se2_z = get_se(2, "z")

# Fitted probability of outcome 2 at x=0, z=0
const1 = float(params.loc["const", 1])
const2 = float(params.loc["const", 2])
denom = 1.0 + np.exp(const1) + np.exp(const2)
p2_zero = float(np.exp(const2) / denom)

result = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": [
        {"term": "x_cat1", "estimate": b1_x, "se": se1_x, "n_obs": n_obs},
        {"term": "z_cat1", "estimate": b1_z, "se": se1_z, "n_obs": n_obs},
        {"term": "x_cat2", "estimate": b2_x, "se": se2_x, "n_obs": n_obs},
        {"term": "z_cat2", "estimate": b2_z, "se": se2_z, "n_obs": n_obs},
        {"term": "prob_cat2_zero", "estimate": p2_zero, "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "multinomial logit maximum likelihood (statsmodels MNLogit, base outcome 0)",
        "vcov": "conventional observed-information (inverse negative Hessian)",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
