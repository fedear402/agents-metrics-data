import json

import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df = df[["score", "participated", "earnings"]].dropna()
d = df[df["score"].abs() < 1].copy()

s = d["score"].to_numpy(dtype=float)
w = 1.0 - np.abs(s)
R = (s >= 0).astype(float)
L = 1.0 - R
X = np.column_stack([R, R * s, L, L * s])

bread = np.linalg.inv(X.T @ (w[:, None] * X))
Y = np.column_stack([
    d["earnings"].to_numpy(dtype=float),
    d["participated"].to_numpy(dtype=float),
])
coef = bread @ X.T @ (w[:, None] * Y)
resid = Y - X @ coef

contrast = np.array([1.0, 0.0, -1.0, 0.0])
jumps = contrast @ coef
reduced_form, first_stage = jumps[0], jumps[1]

loading = w * (X @ bread @ contrast)
influence = loading[:, None] * resid
joint = influence.T @ influence

treatment_effect = reduced_form / first_stage
gradient = np.array([1.0 / first_stage, -reduced_form / first_stage**2])
te_se = np.sqrt(gradient @ joint @ gradient)

n_obs = int(len(d))

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {
            "term": "treatment_effect",
            "estimate": float(treatment_effect),
            "se": float(te_se),
            "n_obs": n_obs,
        },
        {
            "term": "reduced_form",
            "estimate": float(reduced_form),
            "se": float(np.sqrt(joint[0, 0])),
            "n_obs": n_obs,
        },
        {
            "term": "first_stage",
            "estimate": float(first_stage),
            "se": float(np.sqrt(joint[1, 1])),
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "fuzzy RD, local linear with separate slopes and intercepts, cutoff 0, bandwidth 1, triangular weights 1-abs(score)",
        "vcov": "HC0 sandwich, no degrees-of-freedom correction, delta method for treatment_effect with joint covariance",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2)
