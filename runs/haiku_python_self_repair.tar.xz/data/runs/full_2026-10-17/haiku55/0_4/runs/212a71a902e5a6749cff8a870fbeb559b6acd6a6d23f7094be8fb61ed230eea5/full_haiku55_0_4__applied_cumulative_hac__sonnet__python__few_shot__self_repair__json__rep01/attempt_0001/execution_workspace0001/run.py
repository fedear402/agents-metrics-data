import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df["date"] = pd.to_datetime(df["date"])
df = df.sort_values("date").reset_index(drop=True)

df["vix_change"] = np.log(df["vix"]).diff()
L = 15
lag_cols = [f"lag_{k}" for k in range(1, L + 1)]
for k in range(1, L + 1):
    df[f"lag_{k}"] = df["vix_change"].shift(k)

sample = df.dropna(subset=lag_cols + ["sales"])
N = len(sample)
X = np.column_stack([np.ones(N), sample[lag_cols].to_numpy()])
y = np.log(sample["sales"].to_numpy())

beta = np.linalg.lstsq(X, y, rcond=None)[0]
resid = y - X @ beta

scores = X * resid[:, None]
meat = scores.T @ scores
for j in range(1, L + 1):
    w = 1 - j / (L + 1)
    G = scores[j:].T @ scores[:-j]
    meat += w * (G + G.T)

bread = np.linalg.inv(X.T @ X)
p = X.shape[1]
V = (N / (N - p)) * bread @ meat @ bread

contrast = np.zeros(p)
contrast[1:] = 1.0
cumulative = float(contrast @ beta)
cumulative_se = float(np.sqrt(contrast @ V @ contrast))

output = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {"term": "cumulative_response", "estimate": cumulative, "se": cumulative_se, "n_obs": int(N)},
        {"term": "lag_1", "estimate": float(beta[1]), "se": float(np.sqrt(V[1, 1])), "n_obs": int(N)},
        {"term": "lag_15", "estimate": float(beta[15]), "se": float(np.sqrt(V[15, 15])), "n_obs": int(N)},
    ],
    "method_metadata": {
        "estimator": "OLS of log(sales) on intercept and 15 lags of first difference of log(vix)",
        "vcov": "Newey-West HAC, max lag 15, Bartlett weights 1-j/16, scaled by N/(N-16)",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
