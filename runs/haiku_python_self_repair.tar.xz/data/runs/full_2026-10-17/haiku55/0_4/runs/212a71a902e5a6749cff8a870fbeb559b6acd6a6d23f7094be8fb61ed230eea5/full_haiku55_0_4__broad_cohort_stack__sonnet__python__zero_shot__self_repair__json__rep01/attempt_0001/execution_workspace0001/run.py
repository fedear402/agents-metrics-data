import json

import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")

cohort_results = []
for c in [3, 5, 7]:
    window = list(range(c - 2, c + 3))
    in_window = df[df["time"].isin(window)]
    eligible = in_window[(in_window["g"] == c) | (in_window["g"] == 0) | (in_window["g"] > c + 2)]

    times_per_unit = eligible.groupby("id")["time"].nunique()
    complete_ids = times_per_unit[times_per_unit == len(window)].index
    d = eligible[eligible["id"].isin(complete_ids)].copy()

    d["did"] = ((d["g"] == c) & (d["time"] >= c)).astype(float)

    units = sorted(d["id"].unique())
    periods = sorted(d["time"].unique())
    unit_idx = pd.Categorical(d["id"], categories=units).codes
    time_idx = pd.Categorical(d["time"], categories=periods).codes

    n = len(d)
    unit_dummies = (unit_idx[:, None] == np.arange(1, len(units))).astype(float)
    time_dummies = (time_idx[:, None] == np.arange(1, len(periods))).astype(float)
    X = np.column_stack([np.ones(n), d["did"].to_numpy(), unit_dummies, time_dummies])
    y = d["y"].to_numpy(dtype=float)

    beta = np.linalg.lstsq(X, y, rcond=None)[0]
    att = float(beta[1])
    n_treated = int(d.loc[d["g"] == c, "id"].nunique())

    cohort_results.append({"cohort": c, "att": att, "n_obs": n, "n_treated": n_treated})

total_treated = sum(r["n_treated"] for r in cohort_results)
att_weighted = float(sum(r["n_treated"] * r["att"] for r in cohort_results) / total_treated)
weighted_n_obs = int(sum(r["n_obs"] for r in cohort_results))

estimates = []
for r in cohort_results:
    estimates.append({
        "term": f"att_g{r['cohort']}",
        "estimate": r["att"],
        "se": None,
        "n_obs": r["n_obs"],
    })

estimates.append({
    "term": "att_weighted",
    "estimate": att_weighted,
    "se": None,
    "n_obs": weighted_n_obs,
})

result = {
    "task_id": "broad_cohort_stack",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {},
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
