import json

import numpy as np
import pandas as pd

BANDWIDTH = 1.0

df = pd.read_csv("input.csv")
d = df[np.abs(df["score"]) < BANDWIDTH].copy()
d["w"] = 1.0 - np.abs(d["score"])


def side_fit(s):
    X = np.column_stack([np.ones(len(s)), s["score"].values])
    w = s["w"].values
    Y = np.column_stack([s["earnings"].values, s["participated"].values])
    XtW = X.T * w
    B = np.linalg.inv(XtW @ X)
    beta = B @ (XtW @ Y)
    E = Y - X @ beta
    V_int = np.zeros((2, 2))
    for a in range(2):
        for b in range(2):
            meat = (X * (w ** 2 * E[:, a] * E[:, b])[:, None]).T @ X
            V_int[a, b] = (B @ meat @ B)[0, 0]
    return beta[0, :], V_int


R = d[d["score"] >= 0]
L = d[d["score"] < 0]

int_R, V_R = side_fit(R)
int_L, V_L = side_fit(L)

reduced_form = int_R[0] - int_L[0]
first_stage = int_R[1] - int_L[1]

V_rf = V_R[0, 0] + V_L[0, 0]
V_fs = V_R[1, 1] + V_L[1, 1]
C_rf_fs = V_R[0, 1] + V_L[0, 1]

treatment_effect = reduced_form / first_stage
grad = np.array([1.0 / first_stage, -reduced_form / first_stage ** 2])
V_joint = np.array([[V_rf, C_rf_fs], [C_rf_fs, V_fs]])
se_te = float(np.sqrt(grad @ V_joint @ grad))

n_obs = int(len(d))

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": float(treatment_effect), "se": se_te, "n_obs": n_obs},
        {"term": "reduced_form", "estimate": float(reduced_form), "se": float(np.sqrt(V_rf)), "n_obs": n_obs},
        {"term": "first_stage", "estimate": float(first_stage), "se": float(np.sqrt(V_fs)), "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "Fuzzy RD, local linear WLS with triangular weights 1-|score|, bandwidth 1, separate slopes and intercepts per side, cutoff 0",
        "vcov": "HC0 heteroskedasticity-robust sandwich (no dof correction); delta method for ratio using joint covariance of reduced form and first stage",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
