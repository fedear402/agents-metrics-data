import json

import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
cutoff = 0.0
bandwidth = 1.0

df = df[np.abs(df["score"] - cutoff) < bandwidth].copy()
x = df["score"].to_numpy(dtype=float) - cutoff
d = df["participated"].to_numpy(dtype=float)
y = df["earnings"].to_numpy(dtype=float)
w = 1.0 - np.abs(x)
right = (x >= 0).astype(float)
n = len(x)

X = np.column_stack([
    np.ones(n),
    right,
    x * (1.0 - right),
    x * right,
])
Y = np.column_stack([y, d])

XtWX = X.T @ (w[:, None] * X)
bread = np.linalg.inv(XtWX)
coef = bread @ X.T @ (w[:, None] * Y)
resid = Y - X @ coef

contrast = np.array([0.0, 1.0, 0.0, 0.0])
loading = w * (X @ bread @ contrast)
influence = loading[:, None] * resid
joint = influence.T @ influence

jump_y, jump_d = contrast @ coef
ratio = jump_y / jump_d
gradient = np.array([1.0 / jump_d, -jump_y / jump_d**2])
ratio_se = float(np.sqrt(gradient @ joint @ gradient))

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {
            "term": "treatment_effect",
            "estimate": float(ratio),
            "se": ratio_se,
            "n_obs": int(n),
        },
        {
            "term": "reduced_form",
            "estimate": float(jump_y),
            "se": float(np.sqrt(joint[0, 0])),
            "n_obs": int(n),
        },
        {
            "term": "first_stage",
            "estimate": float(jump_d),
            "se": float(np.sqrt(joint[1, 1])),
            "n_obs": int(n),
        },
    ],
    "method_metadata": {
        "estimator": "Fuzzy RD, local linear, triangular kernel, bandwidth 1, separate slopes by side, Wald ratio",
        "vcov": "HC0 sandwich, no degrees-of-freedom correction, delta method for ratio",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
