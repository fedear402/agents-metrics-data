import json
import numpy as np
import pandas as pd
from statsmodels.tsa.arima.model import ARIMA

df = pd.read_csv("input.csv").sort_values("t")
y = df["y"].astype(float).to_numpy()

res = ARIMA(y, order=(1, 1, 1), trend="n").fit()
fc = res.get_forecast(steps=1)
mean = float(np.asarray(fc.predicted_mean)[0])
se = float(np.asarray(fc.se_mean)[0])
ci = np.asarray(fc.conf_int(alpha=0.05))[0]
lower, upper = float(ci[0]), float(ci[1])
n = int(len(y))

out = {
    "task_id": "arima_forecast",
    "platform": "python",
    "estimates": [
        {"term": "forecast", "estimate": mean, "se": se, "n_obs": n},
        {"term": "lower_95", "estimate": lower, "se": None, "n_obs": n},
        {"term": "upper_95", "estimate": upper, "se": None, "n_obs": n},
    ],
    "method_metadata": {
        "estimator": "ARIMA(1,1,1) by maximum likelihood, no constant or drift",
        "vcov": "information matrix (statsmodels default)",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(out, f)
