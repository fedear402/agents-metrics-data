import json

import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")

reg = df.groupby("region_id").agg(
    w=("region_weight", "first"),
    x=("x", "first"),
    y=("y", "first"),
)
reg["e"] = reg["w"] / reg["w"].sum()
reg["z"] = (df["share"] * df["shock"]).groupby(df["region_id"]).sum()


def demean_region(v):
    return v - (reg["e"] * v).sum()


reg["y0"] = demean_region(reg["y"])
reg["x0"] = demean_region(reg["x"])
reg["z0"] = demean_region(reg["z"])

e = reg["e"]
z0 = reg["z0"]
x0 = reg["x0"]
y0 = reg["y0"]

effect_reg = (e * z0 * y0).sum() / (e * z0 * x0).sum()
first_stage_reg = (e * z0 * x0).sum() / (e * z0 * z0).sum()

d = df[["region_id", "industry_id", "share", "shock"]].merge(
    reg[["e", "x0", "y0", "z0"]], left_on="region_id", right_index=True
)
d["es"] = d["e"] * d["share"]

ind = pd.DataFrame({
    "s": d.groupby("industry_id")["es"].sum(),
    "shock": df.groupby("industry_id")["shock"].first(),
})
for v in ["y0", "x0", "z0"]:
    ind[v + "bar"] = (d["es"] * d[v]).groupby(d["industry_id"]).sum() / ind["s"]

N = len(ind)
s = ind["s"].to_numpy()
ws = s / s.sum()


def wdemean(v):
    return v - (ws * v).sum()


sh0 = wdemean(ind["shock"].to_numpy())
ybar0 = wdemean(ind["y0bar"].to_numpy())
xbar0 = wdemean(ind["x0bar"].to_numpy())
zbar0 = wdemean(ind["z0bar"].to_numpy())


def iv_slope(zc, xc, yc):
    return (s * zc * yc).sum() / (s * zc * xc).sum()


def iv_hc1_se(zc, xc, yc, b):
    u = yc - b * xc
    num = ((s * zc * u) ** 2).sum()
    den = ((s * zc * xc).sum()) ** 2
    return float(np.sqrt(num / den * N / (N - 2)))


effect_b = iv_slope(sh0, xbar0, ybar0)
effect_se = iv_hc1_se(sh0, xbar0, ybar0, effect_b)

fs_iv_b = iv_slope(sh0, zbar0, xbar0)
fs_se = iv_hc1_se(sh0, zbar0, xbar0, fs_iv_b)

effective_shocks = 1.0 / (s ** 2).sum()

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": float(effect_reg), "se": effect_se, "n_obs": int(N)},
        {"term": "first_stage", "estimate": float(first_stage_reg), "se": fs_se, "n_obs": int(N)},
        {"term": "effective_shocks", "estimate": float(effective_shocks), "se": None, "n_obs": int(N)},
    ],
    "method_metadata": {
        "estimator": "Regional e-weighted 2SLS of y on x instrumented by shift-share z; BHJ shock-level weighted IV with analytic weights s_n",
        "vcov": "Shock-level structural-residual HC1 robust variance with N/(N-2) multiplier, no clustering",
    },
    "diagnostics": {
        "shock_level_effect_iv": float(effect_b),
        "shock_level_first_stage_iv": float(fs_iv_b),
        "n_regions": int(len(reg)),
        "n_industries": int(N),
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
