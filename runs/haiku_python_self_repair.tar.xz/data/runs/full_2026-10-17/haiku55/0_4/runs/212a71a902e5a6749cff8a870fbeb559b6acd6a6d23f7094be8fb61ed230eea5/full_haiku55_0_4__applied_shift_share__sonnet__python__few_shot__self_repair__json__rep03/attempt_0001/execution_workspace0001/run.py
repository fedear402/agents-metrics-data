import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")

regions = df.groupby("region_id", sort=True).agg(
    region_weight=("region_weight", "first"),
    x=("x", "first"),
    y=("y", "first"),
).reset_index()
e = regions["region_weight"].to_numpy(dtype=float)
e = e / e.sum()

piv_share = df.pivot(index="region_id", columns="industry_id", values="share").sort_index()
shock_by_ind = df.groupby("industry_id")["shock"].first().sort_index()
shares = piv_share.to_numpy(dtype=float)
shock = shock_by_ind.to_numpy(dtype=float)

z = shares @ shock
y_r = regions["y"].to_numpy(dtype=float)
x_r = regions["x"].to_numpy(dtype=float)

def wmean(v):
    return float(np.sum(e * v))

y0 = y_r - wmean(y_r)
x0 = x_r - wmean(x_r)
z0 = z - wmean(z)

s = e @ shares
N = len(shock)
hc1 = N / (N - 2)

def aggregate(v0):
    return (shares.T @ (e * v0)) / s

def shock_iv(dep, endog):
    ones = np.ones(N)
    X = np.column_stack([ones, endog])
    Z = np.column_stack([ones, shock])
    W = s
    cross = Z.T @ (W[:, None] * X)
    beta = np.linalg.solve(cross, Z.T @ (W * dep))
    resid = dep - X @ beta
    scores = Z * (W * resid)[:, None]
    inv = np.linalg.inv(cross)
    cov = hc1 * inv @ (scores.T @ scores) @ inv.T
    return float(beta[1]), float(np.sqrt(cov[1, 1]))

ybar = aggregate(y0)
xbar = aggregate(x0)
zbar = aggregate(z0)

effect, effect_se = shock_iv(ybar, xbar)
first_stage, first_stage_se = shock_iv(xbar, zbar)
effective_shocks = float(1.0 / np.sum(s ** 2))

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": effect, "se": effect_se, "n_obs": int(N)},
        {"term": "first_stage", "estimate": first_stage, "se": first_stage_se, "n_obs": int(N)},
        {"term": "effective_shocks", "estimate": effective_shocks, "se": None, "n_obs": int(N)},
    ],
    "method_metadata": {
        "estimator": "Weighted 2SLS with shift-share instrument; shock-level (Borusyak-Hull-Jaravel) weighted IV aggregation",
        "vcov": "Shock-level HC1 robust (N/(N-2)), structural IV residuals, analytic weights, no clustering",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2, allow_nan=False)
