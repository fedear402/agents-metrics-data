import json

import numpy as np
import pandas as pd

df = pd.read_csv('input.csv')
df = df[['id', 'time', 'g', 'y']].astype({'id': int, 'time': int, 'g': int, 'y': float})

cohorts = [3, 5, 7]
estimates = []
diagnostics = {}
atts = []
weights = []
row_counts = []

for c in cohorts:
    times = list(range(c - 2, c + 3))
    win = df[df['time'].isin(times)]
    elig = win[(win['g'] == c) | (win['g'] == 0) | (win['g'] > c + 2)]
    n_times = elig.groupby('id')['time'].nunique()
    keep_ids = n_times[n_times == len(times)].index
    sub = elig[elig['id'].isin(keep_ids)].copy()
    sub = sub.sort_values(['id', 'time']).reset_index(drop=True)

    did = ((sub['g'] == c) & (sub['time'] >= c)).astype(float).to_numpy()
    unit_d = pd.get_dummies(sub['id'], drop_first=True, dtype=float).to_numpy()
    time_d = pd.get_dummies(sub['time'], drop_first=True, dtype=float).to_numpy()
    X = np.column_stack([np.ones(len(sub)), did, unit_d, time_d])
    assert np.linalg.matrix_rank(X) == X.shape[1]
    beta = np.linalg.lstsq(X, sub['y'].to_numpy(), rcond=None)[0]

    att = float(beta[1])
    n_treated = int(sub.loc[sub['g'] == c, 'id'].nunique())
    n_control = int(sub.loc[sub['g'] != c, 'id'].nunique())
    n_rows = int(len(sub))

    atts.append(att)
    weights.append(n_treated)
    row_counts.append(n_rows)
    estimates.append({
        'term': f'att_g{c}',
        'estimate': att,
        'se': None,
        'n_obs': n_rows,
    })
    diagnostics[f'cohort_{c}'] = {
        'window_times': times,
        'retained_treated_units': n_treated,
        'retained_control_units': n_control,
        'retained_rows': n_rows,
    }

weights_arr = np.array(weights, dtype=float)
atts_arr = np.array(atts, dtype=float)
att_weighted = float(np.sum(weights_arr * atts_arr) / np.sum(weights_arr))
total_rows = int(sum(row_counts))

estimates.append({
    'term': 'att_weighted',
    'estimate': att_weighted,
    'se': None,
    'n_obs': total_rows,
})

output = {
    'task_id': 'broad_cohort_stack',
    'platform': 'python',
    'estimates': estimates,
    'method_metadata': {
        'weights': 'retained treated units per cohort comparison',
        'comparison_type': 'separate cohort-specific stacked DiD with unit and calendar-time fixed effects',
    },
    'diagnostics': diagnostics,
}

with open('result.json', 'w') as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
