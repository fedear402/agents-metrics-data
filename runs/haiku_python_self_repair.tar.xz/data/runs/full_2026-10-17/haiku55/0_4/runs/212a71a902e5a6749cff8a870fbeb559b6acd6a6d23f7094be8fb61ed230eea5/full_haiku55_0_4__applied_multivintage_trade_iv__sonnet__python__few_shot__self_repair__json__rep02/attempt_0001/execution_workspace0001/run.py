import json

import numpy as np
import pandas as pd

crosswalk = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv")
areas = pd.read_csv("areas.csv")
emp = pd.read_csv("employment.csv")
outcomes = pd.read_csv("outcomes.csv")

trade = trade.merge(crosswalk, on="code", how="left")
industries = sorted(crosswalk["industry"].unique())
area_ids = sorted(areas["area"].unique())
periods = sorted(areas["period"].unique())
vintages = ["base", "early"]

emp_g = emp.groupby(["area", "period", "vintage", "industry"], as_index=False)["employment"].sum()
emp_g = emp_g.set_index(["area", "period", "vintage", "industry"])["employment"]
full_idx = pd.MultiIndex.from_product(
    [area_ids, periods, vintages, industries],
    names=["area", "period", "vintage", "industry"],
)
emp_full = emp_g.reindex(full_idx, fill_value=0.0).astype(float)

national = emp_full.groupby(level=["period", "vintage", "industry"]).sum()
total = areas.set_index(["area", "period", "vintage"])["total_employment"].astype(float)
tr_by_period = {p: trade[trade["period"] == p].set_index("industry") for p in periods}


def exposure(vintage, change_col):
    out = {}
    for p in periods:
        t = tr_by_period[p].reindex(industries)
        nat = national.loc[(p, vintage)].reindex(industries).to_numpy(float)
        shock = (
            t[change_col].to_numpy(float)
            / nat
            / (t["price_index"].to_numpy(float) / 100)
            / 1000
            * (10 / t["years"].to_numpy(float))
        )
        for a in area_ids:
            emp_vec = emp_full.loc[(a, p, vintage)].reindex(industries).to_numpy(float)
            share = emp_vec / total.loc[(a, p, vintage)]
            out[(a, p)] = float(np.sum(share * shock))
    return out


x_map = exposure("base", "us_change")
z_map = exposure("early", "other_change")

pop = areas[areas["vintage"] == "base"].set_index(["area", "period"])["population"].astype(float)
df = outcomes.set_index(["area", "period"]).copy()
keys = list(df.index)
df["x"] = [x_map[k] for k in keys]
df["z"] = [z_map[k] for k in keys]
df["w"] = pop.reindex(df.index).to_numpy(float)

n = len(df)
y = df["change_pp"].to_numpy(float)
period_col = df.index.get_level_values("period").to_numpy(float)
control = df["control"].to_numpy(float)
X = np.column_stack([np.ones(n), period_col, control, df["x"].to_numpy(float)])
Z = np.column_stack([np.ones(n), period_col, control, df["z"].to_numpy(float)])
w = df["w"].to_numpy(float)
sw = np.sqrt(w)

Xw = X * sw[:, None]
Zw = Z * sw[:, None]
yw = y * sw

gamma = np.linalg.lstsq(Zw, Xw, rcond=None)[0]
Xhat = Zw @ gamma
beta = np.linalg.lstsq(Xhat, yw, rcond=None)[0]

resid = y - X @ beta
k = X.shape[1]
sigma2 = float(np.sum(w * resid ** 2) / (n - k))
cov = sigma2 * np.linalg.inv(Xhat.T @ Xhat)
se = np.sqrt(np.diag(cov))

a0 = 0 if 0 in area_ids else area_ids[0]
p0, p1 = periods[0], periods[1]

iv_slope = float(beta[3])
iv_slope_se = float(se[3])

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [
        {"term": "iv_slope", "estimate": iv_slope, "se": None, "n_obs": int(n)},
        {"term": "iv_slope_se", "estimate": iv_slope_se, "se": None, "n_obs": int(n)},
        {"term": "exposure_area0_period0", "estimate": x_map[(a0, p0)], "se": None, "n_obs": int(n)},
        {"term": "exposure_area0_period1", "estimate": x_map[(a0, p1)], "se": None, "n_obs": int(n)},
        {"term": "instrument_area0_period0", "estimate": z_map[(a0, p0)], "se": None, "n_obs": int(n)},
    ],
    "method_metadata": {
        "estimator": "weighted_2sls",
        "dependent": "change_pp",
        "regressors": ["const", "period", "control", "x"],
        "instruments": ["const", "period", "control", "z"],
        "weights": "base_population",
        "se_type": "classical_weighted_2sls",
        "n_obs": int(n),
    },
    "diagnostics": {
        "n_obs": int(n),
        "n_areas": int(len(area_ids)),
        "n_periods": int(len(periods)),
        "n_industries": int(len(industries)),
        "first_stage_coef_z": float(gamma[3, 3]),
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
