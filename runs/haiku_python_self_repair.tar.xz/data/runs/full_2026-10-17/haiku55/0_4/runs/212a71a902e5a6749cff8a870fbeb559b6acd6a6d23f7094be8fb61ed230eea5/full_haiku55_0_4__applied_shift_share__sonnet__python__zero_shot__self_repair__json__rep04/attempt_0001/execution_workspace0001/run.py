import json

import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")

df["sz"] = df["share"] * df["shock"]
reg = df.groupby("region_id").agg(
    region_weight=("region_weight", "first"),
    x=("x", "first"),
    y=("y", "first"),
    z=("sz", "sum"),
)
reg["e"] = reg["region_weight"] / reg["region_weight"].sum()

e = reg["e"].values
for v in ["x", "y", "z"]:
    reg[v + "0"] = reg[v] - np.sum(e * reg[v].values) / np.sum(e)

reg_effect = np.sum(e * reg["z0"] * reg["y0"]) / np.sum(e * reg["z0"] * reg["x0"])
reg_first = np.sum(e * reg["z0"] * reg["x0"]) / np.sum(e * reg["z0"] ** 2)

df["e"] = df["region_id"].map(reg["e"])
for v in ["x", "y", "z"]:
    df[v + "0"] = df["region_id"].map(reg[v + "0"])
df["w"] = df["e"] * df["share"]

ind = df.groupby("industry_id").agg(shock=("shock", "first"), s=("w", "sum"))
for v in ["x", "y", "z"]:
    ind[v + "bar"] = (df.assign(t=df["w"] * df[v + "0"]).groupby("industry_id")["t"].sum()
                      / ind["s"])

s = ind["s"].values
shock = ind["shock"].values
xbar = ind["xbar"].values
ybar = ind["ybar"].values
zbar = ind["zbar"].values
N = len(ind)


def iv_hc1(y, X, Z, w):
    A = Z.T @ (w[:, None] * X)
    b = np.linalg.solve(A, Z.T @ (w * y))
    u = y - X @ b
    Ainv = np.linalg.inv(A)
    meat = (Z * (w ** 2 * u ** 2)[:, None]).T @ Z
    V = Ainv @ meat @ Ainv.T * N / (N - 2)
    return b, np.sqrt(np.diag(V))


ones = np.ones(N)
X_eff = np.column_stack([ones, xbar])
Z_eff = np.column_stack([ones, shock])
b_eff, se_eff = iv_hc1(ybar, X_eff, Z_eff, s)

X_fs = np.column_stack([ones, zbar])
b_fs_iv, se_fs = iv_hc1(xbar, X_fs, Z_eff, s)

effective_shocks = 1.0 / np.sum(s ** 2)

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": float(reg_effect), "se": float(se_eff[1]), "n_obs": int(N)},
        {"term": "first_stage", "estimate": float(reg_first), "se": float(se_fs[1]), "n_obs": int(N)},
        {"term": "effective_shocks", "estimate": float(effective_shocks), "se": None, "n_obs": int(N)},
    ],
    "method_metadata": {
        "estimator": "Weighted regional 2SLS of y on x instrumented by shift-share z, with Borusyak-Hull-Jaravel shock-level aggregation",
        "vcov": "Shock-level heteroskedasticity-robust HC1 (N/(N-2)), analytic weights, no clustering",
    },
    "diagnostics": {
        "shock_level_effect_slope": float(b_eff[1]),
        "shock_level_first_stage_iv_slope": float(b_fs_iv[1]),
        "n_regions": int(reg.shape[0]),
        "n_industries": int(N),
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
