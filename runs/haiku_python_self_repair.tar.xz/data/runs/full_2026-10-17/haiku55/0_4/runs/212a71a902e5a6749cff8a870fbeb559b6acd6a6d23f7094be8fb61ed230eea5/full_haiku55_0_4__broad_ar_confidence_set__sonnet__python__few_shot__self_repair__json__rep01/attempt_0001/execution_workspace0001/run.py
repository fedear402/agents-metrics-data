import json

import numpy as np
import pandas as pd
from scipy.stats import f

data = pd.read_csv("input.csv")
y = data["y"].to_numpy(dtype=float)
endog = data["endog"].to_numpy(dtype=float)
x = data["x"].to_numpy(dtype=float)
z1 = data["z1"].to_numpy(dtype=float)
z2 = data["z2"].to_numpy(dtype=float)

n = len(y)
q = 2
dfd = n - 4
crit = f.ppf(0.95, q, dfd)

restricted = np.column_stack([np.ones(n), x])
unrestricted = np.column_stack([np.ones(n), x, z1, z2])


def ssr(v, design):
    coef = np.linalg.lstsq(design, v, rcond=None)[0]
    resid = v - design @ coef
    return float(resid @ resid)


def f_stat(beta):
    v = y - beta * endog
    ssr_r = ssr(v, restricted)
    ssr_u = ssr(v, unrestricted)
    return ((ssr_r - ssr_u) / q) / (ssr_u / dfd)


k = q * crit / dfd


def g(beta):
    v = y - beta * endog
    return ssr(v, restricted) - (1.0 + k) * ssr(v, unrestricted)


# g is exactly quadratic in beta, so three evaluations recover its coefficients.
g0, g1, gm = g(0.0), g(1.0), g(-1.0)
A = 0.5 * (g1 + gm) - g0
B = 0.5 * (g1 - gm)
C = g0

discriminant = B * B - 4.0 * A * C
if abs(A) > 1e-12 and discriminant >= 0:
    roots = np.sort(np.roots([A, B, C]).real)
    boundary_low, boundary_high = float(roots[0]), float(roots[1])
else:
    boundary_low, boundary_high = float("nan"), float("nan")

accepts_zero = int(g0 <= 0.0)
unbounded = int(A < 0.0)
ar_f_at_one = float(f_stat(1.0))

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": [
        {"term": "boundary_low", "estimate": boundary_low, "se": None, "n_obs": n},
        {"term": "boundary_high", "estimate": boundary_high, "se": None, "n_obs": n},
        {"term": "accepts_zero", "estimate": accepts_zero, "se": None, "n_obs": n},
        {"term": "unbounded", "estimate": unbounded, "se": None, "n_obs": n},
        {"term": "ar_f_at_one", "estimate": ar_f_at_one, "se": None, "n_obs": n},
    ],
    "method_metadata": {
        "estimator": "Anderson-Rubin confidence set by test inversion",
        "vcov": "homoskedastic",
    },
    "diagnostics": {
        "critical_value": float(crit),
        "quadratic_A": float(A),
        "quadratic_B": float(B),
        "quadratic_C": float(C),
        "discriminant": float(discriminant),
    },
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=True)
