import json
import math

import numpy as np
import pandas as pd
from scipy import stats

df = pd.read_csv("input.csv")
n = len(df)
y = df["y"].to_numpy(float)
e = df["endog"].to_numpy(float)
x = df["x"].to_numpy(float)
z1 = df["z1"].to_numpy(float)
z2 = df["z2"].to_numpy(float)
ones = np.ones(n)

XR = np.column_stack([ones, x])
XU = np.column_stack([ones, x, z1, z2])


def resid(X, v):
    coef = np.linalg.lstsq(X, v, rcond=None)[0]
    return v - X @ coef


def ip(X, u, v):
    return resid(X, u) @ resid(X, v)


def f_stat(b):
    w = y - b * e
    rss_r = resid(XR, w) @ resid(XR, w)
    rss_u = resid(XU, w) @ resid(XU, w)
    return ((rss_r - rss_u) / 2.0) / (rss_u / (n - 4))


crit = stats.f.ppf(0.95, 2, n - 4)
k = 2.0 * crit / (n - 4)

R0, R1, R2 = ip(XR, y, y), ip(XR, e, y), ip(XR, e, e)
U0, U1, U2 = ip(XU, y, y), ip(XU, e, y), ip(XU, e, e)

a = R2 - (1.0 + k) * U2
b1 = -2.0 * (R1 - (1.0 + k) * U1)
c = R0 - (1.0 + k) * U0

tiny = 1e-12
disc = b1 * b1 - 4.0 * a * c

if a > tiny:
    if disc >= 0:
        sq = math.sqrt(disc)
        r = sorted([(-b1 - sq) / (2 * a), (-b1 + sq) / (2 * a)])
        boundary_low, boundary_high = r
    else:
        boundary_low = boundary_high = float("nan")
    unbounded = 0
elif a < -tiny:
    sq = math.sqrt(max(disc, 0.0))
    r = sorted([(-b1 - sq) / (2 * a), (-b1 + sq) / (2 * a)])
    boundary_low, boundary_high = r
    unbounded = 1
else:
    if abs(b1) > tiny:
        root = -c / b1
        boundary_low, boundary_high = sorted([root, float("nan")], key=lambda v: (math.isnan(v), v))
        unbounded = 1
    else:
        boundary_low = boundary_high = float("nan")
        unbounded = 1 if c <= 0 else 0

accepts_zero = 1 if f_stat(0.0) <= crit else 0
ar_f_at_one = float(f_stat(1.0))

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": [
        {"term": "boundary_low", "estimate": float(boundary_low), "se": None, "n_obs": int(n)},
        {"term": "boundary_high", "estimate": float(boundary_high), "se": None, "n_obs": int(n)},
        {"term": "accepts_zero", "estimate": float(accepts_zero), "se": None, "n_obs": int(n)},
        {"term": "unbounded", "estimate": float(unbounded), "se": None, "n_obs": int(n)},
        {"term": "ar_f_at_one", "estimate": ar_f_at_one, "se": None, "n_obs": int(n)},
    ],
    "method_metadata": {
        "estimator": "Anderson-Rubin test inversion using homoskedastic F test of excluded instruments",
        "vcov": "homoskedastic",
    },
    "diagnostics": {
        "critical_value": float(crit),
        "quadratic_a": float(a),
        "quadratic_b": float(b1),
        "quadratic_c": float(c),
        "discriminant": float(disc),
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
