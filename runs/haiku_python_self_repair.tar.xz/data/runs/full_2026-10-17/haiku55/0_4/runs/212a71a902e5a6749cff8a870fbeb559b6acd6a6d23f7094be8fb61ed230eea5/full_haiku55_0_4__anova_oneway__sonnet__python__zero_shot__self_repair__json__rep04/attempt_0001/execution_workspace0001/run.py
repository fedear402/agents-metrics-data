import json

import pandas as pd
from scipy import stats
import statsmodels.formula.api as smf
from statsmodels.stats.anova import anova_lm

df = pd.read_csv("./input.csv")
df = df.dropna(subset=["group", "y"])
df["group"] = df["group"].astype("category")

model = smf.ols("y ~ C(group)", data=df).fit()
table = anova_lm(model, typ=2)

f_stat = float(table.loc["C(group)", "F"])
df_num = float(table.loc["C(group)", "df"])
df_den = float(table.loc["Residual", "df"])
p_value = float(table.loc["C(group)", "PR(>F)"])

check = stats.f_oneway(*[g["y"].values for _, g in df.groupby("group", observed=True)])
f_stat = float(check.statistic) if not pd.isna(f_stat) else f_stat
p_value = float(check.pvalue) if not pd.isna(p_value) else p_value

n_obs = int(len(df))

result = {
    "task_id": "anova_oneway",
    "platform": "python",
    "estimates": [
        {"term": "F", "estimate": f_stat, "se": None, "n_obs": n_obs},
        {"term": "df_num", "estimate": df_num, "se": None, "n_obs": n_obs},
        {"term": "df_den", "estimate": df_den, "se": None, "n_obs": n_obs},
        {"term": "p_value", "estimate": p_value, "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "one-way ANOVA (OLS with categorical group factor, Type II sums of squares)",
        "vcov": "nonrobust",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
