import json

import numpy as np
import pandas as pd

households = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

df = households[households["recipient"] == 0].copy()
n_obs = int(len(df))

e = df["eligible"].astype(float).to_numpy()
w = df["weight"].astype(float).to_numpy()
dose = df["dose"].astype(float).to_numpy()
baseline = df["baseline"].astype(float).to_numpy()
instrument = df["instrument"].astype(float).to_numpy()
y = df["outcome"].astype(float).to_numpy()

x0 = 1.0 - e
x1 = e

X = np.column_stack([dose * x0, dose * x1, x0, x1, baseline * x0, baseline * x1])
Z = np.column_stack([x0, x1, baseline * x0, baseline * x1, instrument * x0, instrument * x1])

ZW = Z * w[:, None]
ZtWZ = Z.T @ ZW
ZtWX = Z.T @ (X * w[:, None])
ZtWy = Z.T @ (w * y)

ZtWZ_inv = np.linalg.inv(ZtWZ)
lhs = ZtWX.T @ ZtWZ_inv @ ZtWX
rhs = ZtWX.T @ ZtWZ_inv @ ZtWy
beta = np.linalg.solve(lhs, rhs)

slope_ineligible = float(beta[0])
slope_eligible = float(beta[1])


def weighted_mean_dose(mask):
    return float(np.sum(w[mask] * dose[mask]) / np.sum(w[mask]))


mask_ineligible = e == 0
mask_eligible = e == 1

mean_dose_ineligible = weighted_mean_dose(mask_ineligible)
mean_dose_eligible = weighted_mean_dose(mask_eligible)

ineligible_effect = slope_ineligible * mean_dose_ineligible
eligible_nonrecipient_effect = slope_eligible * mean_dose_eligible

N0 = float(census.loc[census["eligible"] == 0, "nonrecipient_population"].sum())
N1 = float(census.loc[census["eligible"] == 1, "nonrecipient_population"].sum())
population_effect = (N0 * ineligible_effect + N1 * eligible_effect) / (N0 + N1)

estimates = [
    {
        "term": "ineligible_effect",
        "estimate": float(ineligible_effect),
        "se": None,
        "n_obs": n_obs,
    },
    {
        "term": "eligible_nonrecipient_effect",
        "estimate": float(eligible_nonrecipient_effect),
        "se": None,
        "n_obs": n_obs,
    },
    {
        "term": "population_effect",
        "estimate": float(population_effect),
        "se": None,
        "n_obs": n_obs,
    },
]

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "weighted_2SLS",
        "regression_weight": "weight",
        "endogenous_columns": ["dose*(1-eligible)", "dose*eligible"],
        "exogenous_columns": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
        ],
        "instrument_columns": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
            "instrument*(1-eligible)",
            "instrument*eligible",
        ],
        "intercept": False,
        "sample_filter": "recipient == 0",
        "group_effect_definition": "fitted dose slope times weighted mean dose within eligibility group",
        "counterfactual": "dose set to zero for every retained household",
        "between_group_weights": "census nonrecipient_population by eligible group",
        "se_policy": "standard errors reported as null",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "n_households_by_eligible": {
            "0": int(np.sum(mask_ineligible)),
            "1": int(np.sum(mask_eligible)),
        },
        "dose_slope_ineligible": slope_ineligible,
        "dose_slope_eligible": slope_eligible,
        "weighted_mean_dose_ineligible": mean_dose_ineligible,
        "weighted_mean_dose_eligible": mean_dose_eligible,
        "census_nonrecipient_population_ineligible": N0,
        "census_nonrecipient_population_eligible": N1,
        "rank_ZtWX": int(np.linalg.matrix_rank(ZtWX)),
        "num_regressors": int(X.shape[1]),
        "num_instruments": int(Z.shape[1]),
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
