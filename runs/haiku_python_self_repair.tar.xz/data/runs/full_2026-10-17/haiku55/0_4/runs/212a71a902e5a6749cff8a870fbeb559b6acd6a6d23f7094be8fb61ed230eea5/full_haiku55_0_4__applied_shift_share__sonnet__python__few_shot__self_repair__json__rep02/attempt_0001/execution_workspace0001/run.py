import json

import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")

df["_sz"] = df["share"] * df["shock"]
regions = df.groupby("region_id", sort=True).agg(
    region_weight=("region_weight", "first"),
    x=("x", "first"),
    y=("y", "first"),
)
regions["z"] = df.groupby("region_id", sort=True)["_sz"].sum()

e = (regions["region_weight"] / regions["region_weight"].sum()).to_numpy()
y = regions["y"].to_numpy(dtype=float)
x = regions["x"].to_numpy(dtype=float)
z = regions["z"].to_numpy(dtype=float)

y0 = y - np.sum(e * y)
x0 = x - np.sum(e * x)
z0 = z - np.sum(e * z)

S = df.pivot_table(index="region_id", columns="industry_id", values="share",
                   aggfunc="first", fill_value=0.0).sort_index()
S = S.reindex(regions.index).to_numpy(dtype=float)
industry_ids = df.groupby("industry_id", sort=True)["shock"].first().index
shock_n = df.groupby("industry_id", sort=True)["shock"].first().to_numpy(dtype=float)

s = e @ S
ybar = (S.T @ (e * y0)) / s
xbar = (S.T @ (e * x0)) / s
zbar = (S.T @ (e * z0)) / s


def shock_iv(dependent, endogenous, instrument, weight):
    n = len(dependent)
    X = np.column_stack([np.ones(n), endogenous])
    Z = np.column_stack([np.ones(n), instrument])
    cross = Z.T @ (weight[:, None] * X)
    beta = np.linalg.solve(cross, Z.T @ (weight * dependent))
    resid = dependent - X @ beta
    scores = Z * (weight * resid)[:, None]
    inv = np.linalg.inv(cross)
    hc1 = n / (n - 2)
    cov = hc1 * inv @ (scores.T @ scores) @ inv.T
    return float(beta[1]), float(np.sqrt(cov[1, 1]))


effect, effect_se = shock_iv(ybar, xbar, shock_n, s)
first_stage, first_stage_se = shock_iv(xbar, zbar, shock_n, s)
effective_shocks = float(1.0 / np.sum(s ** 2))

n_industries = int(len(shock_n))
regional_effect = float(np.sum(e * z0 * y0) / np.sum(e * z0 * x0))
regional_first_stage = float(np.sum(e * z0 * x0) / np.sum(e * z0 ** 2))

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": effect, "se": effect_se, "n_obs": n_industries},
        {"term": "first_stage", "estimate": first_stage, "se": first_stage_se, "n_obs": n_industries},
        {"term": "effective_shocks", "estimate": effective_shocks, "se": None, "n_obs": n_industries},
    ],
    "method_metadata": {
        "estimator": "Weighted 2SLS of y on x instrumented by z, computed via Borusyak-Hull-Jaravel shock-level weighted IV with industry shock instruments",
        "vcov": "Shock-level HC1 robust variance with N/(N-2) multiplier, industries as independent observations, no clustering",
    },
    "diagnostics": {
        "n_regions": int(len(regions)),
        "n_industries": n_industries,
        "regional_effect_check": regional_effect,
        "regional_first_stage_check": regional_first_stage,
    },
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
