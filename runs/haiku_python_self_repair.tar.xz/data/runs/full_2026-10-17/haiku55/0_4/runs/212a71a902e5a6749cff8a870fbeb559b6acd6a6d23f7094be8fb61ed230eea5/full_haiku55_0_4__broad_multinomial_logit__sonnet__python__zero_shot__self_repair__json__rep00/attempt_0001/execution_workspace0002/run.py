import json

import numpy as np
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("input.csv")
n_obs = int(len(df))

X = sm.add_constant(df[["x", "z"]].astype(float), has_constant="add")
y = df["y"].astype(int).to_numpy()

model = sm.MNLogit(y, X.to_numpy())
res = model.fit(method="newton", maxiter=500, disp=False)

cats = np.unique(y)
if cats[0] != 0 or not {1, 2}.issubset(set(cats.tolist())):
    raise ValueError(f"Expected outcomes including 0, 1, 2; found {cats.tolist()}")
nonbase = [int(c) for c in cats[1:]]

B = np.asarray(res.params, dtype=float)
k = B.shape[0]
V = np.asarray(res.cov_params(), dtype=float)

term_idx = {"const": 0, "x": 1, "z": 2}


def col(cat):
    return nonbase.index(cat)


def flat_pos(cat, term):
    return col(cat) * k + term_idx[term]


def est(cat, term):
    return float(B[term_idx[term], col(cat)])


def se(cat, term):
    p = flat_pos(cat, term)
    return float(np.sqrt(V[p, p]))


eta1 = est(1, "const")
eta2 = est(2, "const")
p2_zero = float(np.exp(eta2) / (1.0 + np.exp(eta1) + np.exp(eta2)))

result = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": [
        {"term": "x_cat1", "estimate": est(1, "x"), "se": se(1, "x"), "n_obs": n_obs},
        {"term": "z_cat1", "estimate": est(1, "z"), "se": se(1, "z"), "n_obs": n_obs},
        {"term": "x_cat2", "estimate": est(2, "x"), "se": se(2, "x"), "n_obs": n_obs},
        {"term": "z_cat2", "estimate": est(2, "z"), "se": se(2, "z"), "n_obs": n_obs},
        {"term": "prob_cat2_zero", "estimate": p2_zero, "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "multinomial logit maximum likelihood (statsmodels MNLogit, base outcome 0)",
        "vcov": "conventional observed-information (inverse negative Hessian)",
    },
    "diagnostics": {
        "converged": bool(res.mle_retvals.get("converged", True)) if getattr(res, "mle_retvals", None) else True,
        "llf": float(res.llf),
        "outcome_levels": [int(c) for c in cats],
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
