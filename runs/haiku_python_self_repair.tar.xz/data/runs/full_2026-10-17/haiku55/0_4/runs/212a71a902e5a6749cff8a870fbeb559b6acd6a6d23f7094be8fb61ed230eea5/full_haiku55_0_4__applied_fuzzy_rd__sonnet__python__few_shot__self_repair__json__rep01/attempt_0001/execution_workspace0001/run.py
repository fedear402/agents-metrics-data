import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df = df[np.abs(df["score"]) < 1].copy()
h = 1.0
df["w"] = 1.0 - np.abs(df["score"])
df["right"] = (df["score"] >= 0).astype(float)
n_obs = int(len(df))

s = df["score"].to_numpy(float)
r = df["right"].to_numpy(float)
w = df["w"].to_numpy(float)
Y = np.column_stack([df["earnings"].to_numpy(float), df["participated"].to_numpy(float)])

X = np.column_stack([np.ones(n_obs), r, s * (1 - r), s * r])
XtWX = X.T @ (w[:, None] * X)
bread = np.linalg.inv(XtWX)
B = bread @ X.T @ (w[:, None] * Y)
resid = Y - X @ B

# Right-limit minus left-limit: intercept at s=0 on right is coef[0]+coef[1]; left is coef[0]
c = np.array([0.0, 1.0, 0.0, 0.0])
jumps = c @ B
# Contribution of each obs to the discontinuity estimates for both outcomes
loading = w * (X @ bread @ c)
influence = loading[:, None] * resid
joint = influence.T @ influence

red_form, first_stage = jumps[0], jumps[1]
tau = red_form / first_stage
grad = np.array([1.0 / first_stage, -red_form / first_stage**2])
tau_se = float(np.sqrt(grad @ joint @ grad))

estimates = [
    {"term": "treatment_effect", "estimate": float(tau), "se": tau_se, "n_obs": n_obs},
    {"term": "reduced_form", "estimate": float(red_form), "se": float(np.sqrt(joint[0, 0])), "n_obs": n_obs},
    {"term": "first_stage", "estimate": float(first_stage), "se": float(np.sqrt(joint[1, 1])), "n_obs": n_obs},
]

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "fuzzy regression discontinuity, local linear with separate slopes, triangular kernel, bandwidth 1",
        "vcov": "HC0 sandwich, no degrees-of-freedom correction, delta method for treatment_effect",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
