import json

import numpy as np
import pandas as pd

crosswalk = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv")
areas = pd.read_csv("areas.csv")
employment = pd.read_csv("employment.csv")
outcomes = pd.read_csv("outcomes.csv")

trade_ind = trade.merge(crosswalk[["code", "industry"]], on="code", how="inner")
trade_ind = trade_ind.set_index(["period", "industry"]).sort_index()
industries = sorted(trade_ind.index.get_level_values("industry").unique())
periods = sorted(areas["period"].unique())
area_ids = sorted(areas["area"].unique())
vintages = ["base", "early"]

emp_grouped = (
    employment.groupby(["area", "period", "vintage", "industry"], as_index=False)["employment"]
    .sum()
    .set_index(["area", "period", "vintage", "industry"])["employment"]
)
full_index = pd.MultiIndex.from_product(
    [area_ids, periods, vintages, industries],
    names=["area", "period", "vintage", "industry"],
)
emp = emp_grouped.reindex(full_index, fill_value=0.0)

national = emp.groupby(level=["period", "vintage", "industry"]).sum()
totals = areas.set_index(["area", "period", "vintage"])["total_employment"]
pop = areas[areas["vintage"] == "base"].set_index(["area", "period"])["population"]
period_info = trade_ind.groupby(level="period")[["price_index", "years"]].first()


def exposure(a, p, vint, change_col):
    total = totals.loc[(a, p, vint)]
    price = period_info.loc[p, "price_index"]
    years = period_info.loc[p, "years"]
    s = 0.0
    for j in industries:
        share = emp.loc[(a, p, vint, j)] / total
        nat = national.loc[(p, vint, j)]
        s += share * trade_ind.loc[(p, j), change_col] / nat
    return s / (price / 100.0) / 1000.0 * (10.0 / years)


panel = outcomes.merge(
    pop.rename("population").reset_index(), on=["area", "period"], how="inner"
)
panel["x"] = [exposure(a, p, "base", "us_change") for a, p in zip(panel["area"], panel["period"])]
panel["z"] = [exposure(a, p, "early", "other_change") for a, p in zip(panel["area"], panel["period"])]

n_obs = len(panel)
sw = np.sqrt(panel["population"].to_numpy(dtype=float))
ones = np.ones(n_obs)
y = panel["change_pp"].to_numpy(dtype=float) * sw
X = np.column_stack(
    [ones, panel["period"].to_numpy(dtype=float), panel["control"].to_numpy(dtype=float), panel["x"].to_numpy(dtype=float)]
) * sw[:, None]
Z = np.column_stack(
    [ones, panel["period"].to_numpy(dtype=float), panel["control"].to_numpy(dtype=float), panel["z"].to_numpy(dtype=float)]
) * sw[:, None]

proj_X = Z @ np.linalg.lstsq(Z, X, rcond=None)[0]
beta = np.linalg.lstsq(proj_X, y, rcond=None)[0]


def get_value(a, p, col):
    mask = (panel["area"] == a) & (panel["period"] == p)
    return float(panel.loc[mask, col].iloc[0])


results = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [
        {"term": "iv_slope", "estimate": float(beta[3]), "se": None, "n_obs": int(n_obs)},
        {"term": "exposure_area0_period0", "estimate": get_value(0, 0, "x"), "se": None, "n_obs": int(n_obs)},
        {"term": "exposure_area0_period1", "estimate": get_value(0, 1, "x"), "se": None, "n_obs": int(n_obs)},
        {"term": "instrument_area0_period0", "estimate": get_value(0, 0, "z"), "se": None, "n_obs": int(n_obs)},
    ],
    "method_metadata": {
        "method": "weighted_2sls",
        "dependent_variable": "change_pp",
        "endogenous": ["x"],
        "instruments": ["z"],
        "exogenous": ["intercept", "period", "control"],
        "weight": "base_vintage_population",
    },
    "diagnostics": {
        "n_obs": int(n_obs),
        "n_industries": int(len(industries)),
        "industries": [str(j) for j in industries],
        "n_instruments_total": 4,
    },
}

with open("result.json", "w") as f:
    json.dump(results, f, indent=2)
