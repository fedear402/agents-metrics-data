import json
import numpy as np
import pandas as pd

df = pd.read_csv('input.csv')

reg = (df.groupby('region_id')[['region_weight', 'x', 'y']].first()
         .sort_index())
S_df = (df.pivot_table(index='region_id', columns='industry_id', values='share',
                       aggfunc='first', fill_value=0.0)
          .reindex(index=reg.index))
shock_by_ind = df.groupby('industry_id')['shock'].first().reindex(S_df.columns)

S = S_df.to_numpy(dtype=float)
shock = shock_by_ind.to_numpy(dtype=float)
w = reg['region_weight'].to_numpy(dtype=float)
e = w / w.sum()
x = reg['x'].to_numpy(dtype=float)
y = reg['y'].to_numpy(dtype=float)
z = S @ shock

y0 = y - e @ y
x0 = x - e @ x
z0 = z - e @ z

s = e @ S
N = len(shock)

ybar = (S.T @ (e * y0)) / s
xbar = (S.T @ (e * x0)) / s
zbar = (S.T @ (e * z0)) / s


def shock_iv(dependent, endogenous):
    regressors = np.column_stack([np.ones(N), endogenous])
    instruments = np.column_stack([np.ones(N), shock])
    cross = instruments.T @ (s[:, None] * regressors)
    beta = np.linalg.solve(cross, instruments.T @ (s * dependent))
    residual = dependent - regressors @ beta
    scores = instruments * (s * residual)[:, None]
    inverse = np.linalg.inv(cross)
    hc1 = N / (N - 2)
    covariance = hc1 * inverse @ (scores.T @ scores) @ inverse.T
    return float(beta[1]), float(np.sqrt(covariance[1, 1]))


effect, effect_se = shock_iv(ybar, xbar)
_, first_stage_se = shock_iv(xbar, zbar)
first_stage = float(np.sum(e * z0 * x0) / np.sum(e * z0 ** 2))
effective_shocks = float(1.0 / np.sum(s ** 2))

output = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": effect, "se": effect_se, "n_obs": int(N)},
        {"term": "first_stage", "estimate": first_stage, "se": first_stage_se, "n_obs": int(N)},
        {"term": "effective_shocks", "estimate": effective_shocks, "se": None, "n_obs": int(N)},
    ],
    "method_metadata": {
        "estimator": "Weighted 2SLS shift-share with BHJ shock-level aggregation (shock-level weighted IV, weights s_n)",
        "vcov": "Shock-level heteroskedasticity-robust HC1 (N/(N-2)), structural residuals, no clustering",
    },
    "diagnostics": {},
}

with open('result.json', 'w') as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
