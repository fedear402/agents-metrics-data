import json

import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy.special import softmax

df = pd.read_csv("input.csv")
n_obs = int(len(df))

X = pd.DataFrame({
    "const": np.ones(n_obs),
    "x": df["x"].astype(float).to_numpy(),
    "z": df["z"].astype(float).to_numpy(),
})
y = df["y"].astype(int).to_numpy()

fit = sm.MNLogit(y, X).fit(method="newton", maxiter=500, tol=1e-10, disp=False)

params = fit.params.copy()
bse = fit.bse.copy()
params.columns = [1, 2]
bse.columns = [1, 2]

logits = np.r_[0.0, params.loc["const", 1], params.loc["const", 2]]
prob_cat2_zero = float(softmax(logits)[2])

output = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": [
        {"term": "x_cat1", "estimate": float(params.loc["x", 1]), "se": float(bse.loc["x", 1]), "n_obs": n_obs},
        {"term": "z_cat1", "estimate": float(params.loc["z", 1]), "se": float(bse.loc["z", 1]), "n_obs": n_obs},
        {"term": "x_cat2", "estimate": float(params.loc["x", 2]), "se": float(bse.loc["x", 2]), "n_obs": n_obs},
        {"term": "z_cat2", "estimate": float(params.loc["z", 2]), "se": float(bse.loc["z", 2]), "n_obs": n_obs},
        {"term": "prob_cat2_zero", "estimate": prob_cat2_zero, "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "multinomial logit, maximum likelihood, base outcome 0",
        "vcov": "conventional observed-information (inverse negative Hessian)",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
