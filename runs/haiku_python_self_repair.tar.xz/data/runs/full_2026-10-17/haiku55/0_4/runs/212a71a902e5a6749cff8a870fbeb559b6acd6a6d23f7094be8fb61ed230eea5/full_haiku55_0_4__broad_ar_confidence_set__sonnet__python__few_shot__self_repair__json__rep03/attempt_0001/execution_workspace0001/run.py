import json

import numpy as np
import pandas as pd
from scipy.stats import f

data = pd.read_csv('input.csv')
y = data['y'].to_numpy(dtype=float)
endog = data['endog'].to_numpy(dtype=float)
x = data['x'].to_numpy(dtype=float)
z = data[['z1', 'z2']].to_numpy(dtype=float)

n = len(y)
q = z.shape[1]
ctrl = np.column_stack([np.ones(n), x])
full = np.column_stack([ctrl, z])
dfree = n - full.shape[1]
crit = f.ppf(0.95, q, dfree)


def resid(v, X):
    return v - X @ np.linalg.lstsq(X, v, rcond=None)[0]


ry = resid(y, ctrl)
re = resid(endog, ctrl)
uy = resid(y, full)
ue = resid(endog, full)

k = q * crit / dfree
A = re @ re - (1 + k) * (ue @ ue)
B = -2 * (ry @ re - (1 + k) * (uy @ ue))
C = ry @ ry - (1 + k) * (uy @ uy)


def accepts(b):
    return A * b * b + B * b + C <= 0


tiny = 1e-12
disc = B * B - 4 * A * C
roots = []
if A > tiny:
    unbounded = 0
    if disc >= 0:
        roots = sorted(np.roots([A, B, C]).real.tolist())
elif A < -tiny:
    unbounded = 1
    if disc > 0:
        roots = sorted(np.roots([A, B, C]).real.tolist())
else:
    unbounded = 1
    if B != 0:
        roots = [-C / B]

boundary_low = float(roots[0]) if len(roots) >= 1 else None
boundary_high = float(roots[1]) if len(roots) == 2 else None

yt = y - endog
r_one = resid(yt, ctrl)
u_one = resid(yt, full)
ar_f_at_one = float(((r_one @ r_one - u_one @ u_one) / q) / (u_one @ u_one / dfree))

result = {
    'task_id': 'broad_ar_confidence_set',
    'platform': 'python',
    'estimates': [
        {'term': 'boundary_low', 'estimate': boundary_low, 'se': None, 'n_obs': n},
        {'term': 'boundary_high', 'estimate': boundary_high, 'se': None, 'n_obs': n},
        {'term': 'accepts_zero', 'estimate': int(accepts(0.0)), 'se': None, 'n_obs': n},
        {'term': 'unbounded', 'estimate': int(unbounded), 'se': None, 'n_obs': n},
        {'term': 'ar_f_at_one', 'estimate': ar_f_at_one, 'se': None, 'n_obs': n},
    ],
    'method_metadata': {
        'estimator': 'Anderson-Rubin confidence set by inverting homoskedastic joint F test of excluded instruments',
        'vcov': 'homoskedastic (nonrobust)',
    },
    'diagnostics': {
        'critical_value': float(crit),
        'numerator_df': int(q),
        'denominator_df': int(dfree),
        'quadratic_A': float(A),
        'quadratic_B': float(B),
        'quadratic_C': float(C),
        'discriminant': float(disc),
    },
}

with open('result.json', 'w') as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
