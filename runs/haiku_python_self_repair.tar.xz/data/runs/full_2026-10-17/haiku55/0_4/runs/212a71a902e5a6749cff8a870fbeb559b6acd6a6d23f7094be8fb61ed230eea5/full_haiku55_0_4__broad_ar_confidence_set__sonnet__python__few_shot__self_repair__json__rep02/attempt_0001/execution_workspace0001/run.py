import json
import numpy as np
import pandas as pd
from scipy.stats import f

data = pd.read_csv('input.csv')
y = data['y'].to_numpy(dtype=float)
e = data['endog'].to_numpy(dtype=float)
x = data['x'].to_numpy(dtype=float)
z = data[['z1', 'z2']].to_numpy(dtype=float)
n = len(y)

ones = np.ones((n, 1))
R = np.column_stack([ones, x])
U = np.column_stack([ones, x, z])
q = 2
dfree = n - U.shape[1]
crit = f.ppf(0.95, q, dfree)


def resid(v, W):
    return v - W @ np.linalg.lstsq(W, v, rcond=None)[0]


def f_stat(beta):
    yt = y - beta * e
    rr = resid(yt, R)
    ru = resid(yt, U)
    ssr_r = rr @ rr
    ssr_u = ru @ ru
    return ((ssr_r - ssr_u) / q) / (ssr_u / dfree)


ry = resid(y, R)
re_ = resid(e, R)
uy = resid(y, U)
ue = resid(e, U)
k = q * crit / dfree

A = re_ @ re_ - (1 + k) * (ue @ ue)
B = -2 * (ry @ re_ - (1 + k) * (uy @ ue))
C = ry @ ry - (1 + k) * (uy @ uy)

if abs(A) < 1e-12:
    if abs(B) < 1e-12:
        roots = []
        unbounded = 1 if C <= 0 else 0
    else:
        root = -C / B
        roots = [None, root] if B > 0 else [root, None]
        unbounded = 1
else:
    disc = B * B - 4 * A * C
    if disc >= 0:
        s = np.sqrt(disc)
        roots = sorted([(-B - s) / (2 * A), (-B + s) / (2 * A)])
    else:
        roots = []
    unbounded = 1 if A < 0 else 0

if len(roots) == 2:
    low, high = float(roots[0]), float(roots[1])
else:
    low, high = None, None
    if len(roots) == 2 or (len(roots) == 1 and False):
        pass
    padded = (list(roots) + [None, None])[:2] if roots else [None, None]
    low = None if padded[0] is None else float(padded[0])
    high = None if padded[1] is None else float(padded[1])

accepts_zero = int(f_stat(0.0) <= crit)
ar_f_at_one = float(f_stat(1.0))

result = {
    'task_id': 'broad_ar_confidence_set',
    'platform': 'python',
    'estimates': [
        {'term': 'boundary_low', 'estimate': low, 'se': None, 'n_obs': n},
        {'term': 'boundary_high', 'estimate': high, 'se': None, 'n_obs': n},
        {'term': 'accepts_zero', 'estimate': accepts_zero, 'se': None, 'n_obs': n},
        {'term': 'unbounded', 'estimate': int(unbounded), 'se': None, 'n_obs': n},
        {'term': 'ar_f_at_one', 'estimate': ar_f_at_one, 'se': None, 'n_obs': n},
    ],
    'method_metadata': {
        'estimator': 'Anderson-Rubin confidence set by inversion of homoskedastic joint F test',
        'vcov': 'homoskedastic',
    },
    'diagnostics': {
        'critical_value': float(crit),
        'quadratic_A': float(A),
        'quadratic_B': float(B),
        'quadratic_C': float(C),
    },
}

with open('result.json', 'w') as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
