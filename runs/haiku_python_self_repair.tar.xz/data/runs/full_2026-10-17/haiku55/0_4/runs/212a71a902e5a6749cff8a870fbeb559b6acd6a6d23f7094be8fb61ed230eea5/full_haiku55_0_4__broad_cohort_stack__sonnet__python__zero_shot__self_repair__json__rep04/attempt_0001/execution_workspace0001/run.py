import json

import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df["id"] = df["id"].astype(int)
df["time"] = df["time"].astype(int)
df["g"] = df["g"].astype(int)
df["y"] = df["y"].astype(float)


def estimate_cohort(c):
    lo, hi = c - 2, c + 2
    window = df[(df["time"] >= lo) & (df["time"] <= hi)]
    eligible = window[(window["g"] == c) | (window["g"] == 0) | (window["g"] > c + 2)]

    times_per_unit = eligible.groupby("id")["time"].nunique()
    balanced_ids = times_per_unit[times_per_unit == (hi - lo + 1)].index
    sub = eligible[eligible["id"].isin(balanced_ids)].copy()

    sub["did"] = ((sub["g"] == c) & (sub["time"] >= c)).astype(float)

    units = np.sort(sub["id"].unique())
    times = np.sort(sub["time"].unique())
    n = len(sub)

    unit_dummies = (sub["id"].values[:, None] == units[None, :]).astype(float)[:, 1:]
    time_dummies = (sub["time"].values[:, None] == times[None, :]).astype(float)[:, 1:]
    X = np.column_stack([np.ones(n), sub["did"].values, unit_dummies, time_dummies])
    y = sub["y"].values

    beta = np.linalg.lstsq(X, y, rcond=None)[0]
    att = float(beta[1])

    n_treated_units = int(sub.loc[sub["g"] == c, "id"].nunique())
    return att, n, n_treated_units


cohorts = [3, 5, 7]
estimates = []
weights = []
atts = []
total_rows = 0

for c in cohorts:
    att, n_rows, n_treated = estimate_cohort(c)
    atts.append(att)
    weights.append(n_treated)
    total_rows += n_rows
    estimates.append({
        "term": f"att_g{c}",
        "estimate": repr(att),
        "se": None,
        "n_obs": n_rows,
    })

weights_arr = np.asarray(weights, dtype=float)
atts_arr = np.asarray(atts, dtype=float)
att_weighted = float(np.sum(weights_arr * atts_arr) / np.sum(weights_arr))

estimates.append({
    "term": "att_weighted",
    "estimate": repr(att_weighted),
    "se": None,
    "n_obs": total_rows,
})

result = {
    "task_id": "broad_cohort_stack",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {},
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
