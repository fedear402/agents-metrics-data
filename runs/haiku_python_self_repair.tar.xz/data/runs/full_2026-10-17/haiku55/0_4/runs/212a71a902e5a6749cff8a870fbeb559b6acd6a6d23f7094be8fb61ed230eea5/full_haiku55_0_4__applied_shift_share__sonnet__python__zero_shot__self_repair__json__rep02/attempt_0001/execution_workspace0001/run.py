import json

import numpy as np
import pandas as pd


def wiv(y, endog, instr, w):
    n = len(y)
    X = np.column_stack([np.ones(n), endog])
    Z = np.column_stack([np.ones(n), instr])
    ZW = Z.T * w
    ZWZ = ZW @ Z
    ZWX = ZW @ X
    G = np.linalg.inv(ZWZ)
    A = ZWX.T @ G
    AK = A @ ZWX
    bread = np.linalg.solve(AK, A)
    beta = bread @ (ZW @ y)
    u = y - X @ beta
    Zs = Z * (w * u)[:, None]
    meat = Zs.T @ Zs
    V = bread @ meat @ bread.T * n / (n - 2)
    return beta, np.sqrt(np.diag(V))


df = pd.read_csv("input.csv")

reg = (
    df.groupby("region_id")
    .agg(region_weight=("region_weight", "first"), x=("x", "first"), y=("y", "first"))
    .reset_index()
)
reg["e"] = reg["region_weight"] / reg["region_weight"].sum()
z_raw = df.assign(p=df["share"] * df["shock"]).groupby("region_id")["p"].sum()
reg["z"] = reg["region_id"].map(z_raw)

e = reg["e"].values
reg["y0"] = reg["y"] - np.sum(e * reg["y"].values)
reg["x0"] = reg["x"] - np.sum(e * reg["x"].values)
reg["z0"] = reg["z"] - np.sum(e * reg["z"].values)

beta_reg, _ = wiv(reg["y0"].values, reg["x0"].values, reg["z0"].values, e)

dfm = df.merge(reg[["region_id", "e", "y0", "x0", "z0"]], on="region_id", how="left")
dfm["w_share"] = dfm["e"] * dfm["share"]

ind = dfm.groupby("industry_id").agg(shock=("shock", "first"), s=("w_share", "sum"))
for v in ["y0", "x0", "z0"]:
    num = (dfm["w_share"] * dfm[v]).groupby(dfm["industry_id"]).sum()
    ind[v + "bar"] = num / ind["s"]
ind = ind.reset_index()

s = ind["s"].values
shock = ind["shock"].values
ybar = ind["y0bar"].values
xbar = ind["x0bar"].values
zbar = ind["z0bar"].values

beta_eff, se_eff = wiv(ybar, xbar, shock, s)
beta_fs, se_fs = wiv(xbar, zbar, shock, s)

n_ind = len(ind)
effective_shocks = 1.0 / np.sum(s ** 2)

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": float(beta_eff[1]), "se": float(se_eff[1]), "n_obs": int(n_ind)},
        {"term": "first_stage", "estimate": float(beta_fs[1]), "se": float(se_fs[1]), "n_obs": int(n_ind)},
        {"term": "effective_shocks", "estimate": float(effective_shocks), "se": None, "n_obs": int(n_ind)},
    ],
    "method_metadata": {
        "estimator": "Weighted 2SLS of regional y on intercept and x, instrumented by shift-share z, with e_r weights; shock-level (BHJ) weighted IV by s_n",
        "vcov": "Shock-level heteroskedasticity-robust HC1 (N/(N-2)) sandwich, structural IV residuals, analytic weights, no clustering",
    },
    "diagnostics": {
        "regional_effect_check": float(beta_reg[1]),
        "n_regions": int(len(reg)),
        "n_industries": int(n_ind),
        "sum_s": float(np.sum(s)),
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
