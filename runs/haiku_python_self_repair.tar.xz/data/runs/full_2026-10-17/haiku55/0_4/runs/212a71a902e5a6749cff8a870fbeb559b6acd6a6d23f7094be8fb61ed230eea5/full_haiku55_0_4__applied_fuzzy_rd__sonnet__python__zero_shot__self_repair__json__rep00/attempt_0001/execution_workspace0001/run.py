import json

import numpy as np
import pandas as pd

H = 1.0

df = pd.read_csv("input.csv")
df = df.dropna(subset=["score", "participated", "earnings"])
d = df[df["score"].abs() < H].copy()
d["w"] = 1.0 - d["score"].abs()
n_obs = int(len(d))

left = d[d["score"] < 0]
right = d[d["score"] >= 0]


def side_fit(g):
    x = g["score"].to_numpy(float)
    w = g["w"].to_numpy(float)
    X = np.column_stack([np.ones_like(x), x])
    XtW = X.T * w
    A = np.linalg.inv(XtW @ X)
    outcomes = {
        "y": g["earnings"].to_numpy(float),
        "d": g["participated"].to_numpy(float),
    }
    betas, resid = {}, {}
    for k, v in outcomes.items():
        b = A @ (XtW @ v)
        betas[k] = b
        resid[k] = v - X @ b
    meat = {}
    for k1 in outcomes:
        for k2 in outcomes:
            c = w**2 * resid[k1] * resid[k2]
            meat[(k1, k2)] = A @ ((X * c[:, None]).T @ X) @ A
    return betas, meat


bl, Ml = side_fit(left)
br, Mr = side_fit(right)

rf = float(br["y"][0] - bl["y"][0])
fs = float(br["d"][0] - bl["d"][0])

V = np.zeros((2, 2))
V[0, 0] = Mr[("y", "y")][0, 0] + Ml[("y", "y")][0, 0]
V[1, 1] = Mr[("d", "d")][0, 0] + Ml[("d", "d")][0, 0]
V[0, 1] = Mr[("y", "d")][0, 0] + Ml[("y", "d")][0, 0]
V[1, 0] = V[0, 1]

se_rf = float(np.sqrt(V[0, 0]))
se_fs = float(np.sqrt(V[1, 1]))

te = rf / fs
g = np.array([1.0 / fs, -rf / fs**2])
se_te = float(np.sqrt(g @ V @ g))

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": float(te), "se": se_te, "n_obs": n_obs},
        {"term": "reduced_form", "estimate": rf, "se": se_rf, "n_obs": n_obs},
        {"term": "first_stage", "estimate": fs, "se": se_fs, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "Fuzzy RD, local linear WLS with triangular kernel weights, cutoff 0, bandwidth 1",
        "vcov": "HC0 sandwich per side; delta method for treatment_effect using joint covariance of reduced_form and first_stage",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
