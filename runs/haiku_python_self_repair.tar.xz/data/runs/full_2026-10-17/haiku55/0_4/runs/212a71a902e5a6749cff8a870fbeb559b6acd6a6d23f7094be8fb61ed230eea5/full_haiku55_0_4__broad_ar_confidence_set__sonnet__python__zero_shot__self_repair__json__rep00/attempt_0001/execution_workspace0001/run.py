import json

import numpy as np
import pandas as pd
from scipy import stats

df = pd.read_csv("input.csv")
n = len(df)
y = df["y"].to_numpy(dtype=float)
endog = df["endog"].to_numpy(dtype=float)
x = df["x"].to_numpy(dtype=float)
z1 = df["z1"].to_numpy(dtype=float)
z2 = df["z2"].to_numpy(dtype=float)

ones = np.ones(n)
W = np.column_stack([ones, x])
Z = np.column_stack([ones, x, z1, z2])


def ssr(X, v):
    coef, *_ = np.linalg.lstsq(X, v, rcond=None)
    r = v - X @ coef
    return float(r @ r)


def f_stat(b):
    v = y - b * endog
    ssr_r = ssr(W, v)
    ssr_u = ssr(Z, v)
    return ((ssr_r - ssr_u) / 2.0) / (ssr_u / (n - 4))


crit = stats.f.ppf(0.95, 2, n - 4)
k = 1.0 + 2.0 * crit / (n - 4)


def g(b):
    v = y - b * endog
    return ssr(W, v) - k * ssr(Z, v)


# g(b) is exactly quadratic in b; accept beta iff g(beta) <= 0 (equivalent to F <= crit)
g0 = g(0.0)
gp = g(1.0)
gm = g(-1.0)
a2 = (gp + gm) / 2.0 - g0
a1 = (gp - gm) / 2.0
a0 = g0

scale = max(1.0, abs(a0) + abs(a1) + abs(a2))
if abs(a2) > 1e-12 * scale:
    disc = a1 * a1 - 4.0 * a2 * a0
    if disc >= 0:
        sq = np.sqrt(disc)
        r1, r2 = sorted([(-a1 - sq) / (2.0 * a2), (-a1 + sq) / (2.0 * a2)])
    else:
        r1, r2 = float("nan"), float("nan")
    unbounded = 1 if a2 < 0 else 0
elif abs(a1) > 1e-12 * scale:
    root = -a0 / a1
    r1, r2 = sorted([root, root])
    unbounded = 1
else:
    r1, r2 = float("nan"), float("nan")
    unbounded = 1 if a0 <= 0 else 0

accepts_zero = 1 if a0 <= 0 else 0
ar_f_at_one = f_stat(1.0)

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": [
        {"term": "boundary_low", "estimate": float(r1), "se": None, "n_obs": int(n)},
        {"term": "boundary_high", "estimate": float(r2), "se": None, "n_obs": int(n)},
        {"term": "accepts_zero", "estimate": float(accepts_zero), "se": None, "n_obs": int(n)},
        {"term": "unbounded", "estimate": float(unbounded), "se": None, "n_obs": int(n)},
        {"term": "ar_f_at_one", "estimate": float(ar_f_at_one), "se": None, "n_obs": int(n)},
    ],
    "method_metadata": {
        "estimator": "Anderson-Rubin test inversion (homoskedastic F, both excluded instruments)",
        "vcov": "homoskedastic",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
