import json

import numpy as np
import pandas as pd
from statsmodels.tsa.arima.model import ARIMA

df = pd.read_csv("./input.csv")
df = df.sort_values("t").dropna(subset=["y"])
y = df["y"].astype(float).reset_index(drop=True)
n_obs = int(len(y))

model = ARIMA(y, order=(1, 1, 1), trend="n")
res = model.fit()

fc = res.get_forecast(steps=1)
mean = float(np.asarray(fc.predicted_mean)[0])
var = float(np.asarray(fc.var_pred_mean)[0])
se = float(np.sqrt(var))
z = 1.959963984540054
lower = mean - z * se
upper = mean + z * se

retvals = res.mle_retvals
converged = bool(retvals.get("converged", True)) if isinstance(retvals, dict) else bool(getattr(retvals, "converged", True))

result = {
    "task_id": "arima_forecast",
    "platform": "python",
    "estimates": [
        {"term": "forecast", "estimate": mean, "se": se, "n_obs": n_obs},
        {"term": "lower_95", "estimate": lower, "se": None, "n_obs": n_obs},
        {"term": "upper_95", "estimate": upper, "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "ARIMA(1,1,1) without constant, exact maximum likelihood (statsmodels)",
        "vcov": "outer product of gradients / numerical Hessian from statsmodels MLE; forecast variance from state-space filter",
    },
    "diagnostics": {
        "aic": float(res.aic),
        "bic": float(res.bic),
        "loglik": float(res.llf),
        "converged": converged,
        "ar1": float(res.params.iloc[0]) if hasattr(res.params, "iloc") else float(res.params[0]),
        "ma1": float(res.params.iloc[1]) if hasattr(res.params, "iloc") else float(res.params[1]),
        "sigma2": float(res.params.iloc[2]) if hasattr(res.params, "iloc") else float(res.params[2]),
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
