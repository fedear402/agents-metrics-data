import json

import numpy as np
import pandas as pd
from scipy import stats

df = pd.read_csv("input.csv")
n = len(df)

y = df["y"].to_numpy(dtype=float)
endog = df["endog"].to_numpy(dtype=float)
x = df["x"].to_numpy(dtype=float)
Z = df[["z1", "z2"]].to_numpy(dtype=float)

X = np.column_stack([np.ones(n), x])
I = np.eye(n)
H_X = X @ np.linalg.pinv(X)


def resid_x(A):
    return A - H_X @ A


u = resid_x(y)
v = resid_x(endog)
Zr = resid_x(Z)
P = Zr @ np.linalg.pinv(Zr.T @ Zr) @ Zr.T
M = I - P

df_den = n - 4
crit = stats.f.ppf(0.95, 2, df_den)


def ar_f(b):
    w = u - b * v
    num = (w @ P @ w) / 2.0
    den = (w @ M @ w) / df_den
    return num / den


W = df_den * P - 2.0 * crit * M
A = v @ W @ v
B = -2.0 * (u @ W @ v)
C = u @ W @ u

disc = B * B - 4.0 * A * C
if A > 0 and disc >= 0:
    r1 = (-B - np.sqrt(disc)) / (2.0 * A)
    r2 = (-B + np.sqrt(disc)) / (2.0 * A)
    boundary_low, boundary_high = sorted([r1, r2])
    unbounded = 0
    set_type = "bounded_interval"
elif A > 0:
    boundary_low = float("nan")
    boundary_high = float("nan")
    unbounded = 0
    set_type = "empty"
elif A < 0:
    if disc >= 0:
        r1 = (-B - np.sqrt(disc)) / (2.0 * A)
        r2 = (-B + np.sqrt(disc)) / (2.0 * A)
        boundary_low, boundary_high = sorted([r1, r2])
        set_type = "complement_of_interval"
    else:
        boundary_low = float("nan")
        boundary_high = float("nan")
        set_type = "whole_real_line"
    unbounded = 1
else:
    if B != 0:
        root = -C / B
        boundary_low, boundary_high = sorted([root, root])
    else:
        boundary_low = float("nan")
        boundary_high = float("nan")
    unbounded = 1
    set_type = "half_line_or_degenerate"

accepts_zero = int(C <= 0)
ar_f_at_one = float(ar_f(1.0))

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": [
        {"term": "boundary_low", "estimate": float(boundary_low), "se": None, "n_obs": int(n)},
        {"term": "boundary_high", "estimate": float(boundary_high), "se": None, "n_obs": int(n)},
        {"term": "accepts_zero", "estimate": float(accepts_zero), "se": None, "n_obs": int(n)},
        {"term": "unbounded", "estimate": float(unbounded), "se": None, "n_obs": int(n)},
        {"term": "ar_f_at_one", "estimate": ar_f_at_one, "se": None, "n_obs": int(n)},
    ],
    "method_metadata": {
        "estimator": "Anderson-Rubin confidence set via homoskedastic F test inversion",
        "vcov": "homoskedastic",
    },
    "diagnostics": {
        "n_obs": int(n),
        "critical_value_f_0.95_2_{}".format(df_den): float(crit),
        "quadratic_A": float(A),
        "quadratic_B": float(B),
        "quadratic_C": float(C),
        "discriminant": float(disc),
        "set_type": set_type,
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
