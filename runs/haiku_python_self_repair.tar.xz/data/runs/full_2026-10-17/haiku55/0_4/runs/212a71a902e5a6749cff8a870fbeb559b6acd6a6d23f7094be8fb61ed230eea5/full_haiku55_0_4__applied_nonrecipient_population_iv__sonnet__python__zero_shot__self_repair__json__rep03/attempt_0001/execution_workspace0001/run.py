import json

import numpy as np
import pandas as pd

hh = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

for col in ["eligible", "treated", "recipient", "instrument", "dose", "baseline", "weight", "outcome"]:
    hh[col] = pd.to_numeric(hh[col])
census["eligible"] = pd.to_numeric(census["eligible"])
census["nonrecipient_population"] = pd.to_numeric(census["nonrecipient_population"])

d = hh[hh["recipient"] == 0].copy()
n_obs = int(len(d))

el = d["eligible"].to_numpy(float)
ne = 1.0 - el
dose = d["dose"].to_numpy(float)
base = d["baseline"].to_numpy(float)
inst = d["instrument"].to_numpy(float)
w = d["weight"].to_numpy(float)
y = d["outcome"].to_numpy(float)

X = np.column_stack([dose * ne, dose * el, ne, el, base * ne, base * el])
Z = np.column_stack([ne, el, base * ne, base * el, inst * ne, inst * el])

sw = np.sqrt(w)
Xt = X * sw[:, None]
Zt = Z * sw[:, None]
yt = y * sw

first_stage = np.linalg.lstsq(Zt, Xt, rcond=None)[0]
Xhat = Zt @ first_stage
beta = np.linalg.lstsq(Xhat, yt, rcond=None)[0]

slope_inel = float(beta[0])
slope_el = float(beta[1])

m_in = ne == 1.0
m_el = el == 1.0

mean_dose_in = float(np.sum(w[m_in] * dose[m_in]) / np.sum(w[m_in]))
mean_dose_el = float(np.sum(w[m_el] * dose[m_el]) / np.sum(w[m_el]))

ineligible_effect = slope_inel * mean_dose_in
eligible_nonrecipient_effect = slope_el * mean_dose_el

N_in = float(census.loc[census["eligible"] == 0, "nonrecipient_population"].sum())
N_el = float(census.loc[census["eligible"] == 1, "nonrecipient_population"].sum())
population_effect = (N_in * ineligible_effect + N_el * eligible_nonrecipient_effect) / (N_in + N_el)

n_in = int(m_in.sum())
n_el = int(m_el.sum())

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "ineligible_effect",
            "estimate": float(ineligible_effect),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "eligible_nonrecipient_effect",
            "estimate": float(eligible_nonrecipient_effect),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "population_effect",
            "estimate": float(population_effect),
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "method": "weighted two-stage least squares, no added intercept",
        "regression_weight": "weight",
        "endogenous": ["dose*(1-eligible)", "dose*eligible"],
        "exogenous": ["1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"],
        "instruments": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
            "instrument*(1-eligible)",
            "instrument*eligible",
        ],
        "sample": "households with recipient == 0, all eligibility and treatment statuses",
        "group_effect": "fitted dose slope times weighted mean dose within eligibility group",
        "population_weights": "census nonrecipient_population by eligibility group",
        "counterfactual": "dose set to zero for every retained household (synthetic attribution convention)",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "n_ineligible_obs": n_in,
        "n_eligible_obs": n_el,
        "slope_dose_ineligible": slope_inel,
        "slope_dose_eligible": slope_el,
        "weighted_mean_dose_ineligible": mean_dose_in,
        "weighted_mean_dose_eligible": mean_dose_el,
        "census_population_ineligible": N_in,
        "census_population_eligible": N_el,
        "instrument_rank": int(np.linalg.matrix_rank(Zt)),
        "regressor_rank": int(np.linalg.matrix_rank(X * sw[:, None])),
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
