import json

import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS

households = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

d = households[households["recipient"] == 0].copy()
e = d["eligible"].astype(float)
ine = 1.0 - e
w = d["weight"].astype(float)

exog = pd.DataFrame({
    "ineligible_const": ine,
    "eligible_const": e,
    "baseline_ineligible": d["baseline"] * ine,
    "baseline_eligible": d["baseline"] * e,
}, index=d.index)

excluded_instruments = pd.DataFrame({
    "instrument_ineligible": d["instrument"] * ine,
    "instrument_eligible": d["instrument"] * e,
}, index=d.index)

endog = pd.DataFrame({
    "dose_ineligible": d["dose"] * ine,
    "dose_eligible": d["dose"] * e,
}, index=d.index)

y = d["outcome"].astype(float)

fit = IV2SLS(y, exog, endog, excluded_instruments, weights=w).fit()

mask_in = e == 0
mask_el = e == 1
n_total = int(len(d))
n_ineligible = int(mask_in.sum())
n_eligible = int(mask_el.sum())

mean_dose_in = np.average(d.loc[mask_in, "dose"], weights=w[mask_in])
mean_dose_el = np.average(d.loc[mask_el, "dose"], weights=w[mask_el])

ineligible_effect = float(fit.params["dose_ineligible"] * mean_dose_in)
eligible_nonrecipient_effect = float(fit.params["dose_eligible"] * mean_dose_el)

pop = census.set_index("eligible")["nonrecipient_population"].astype(float)
population_weights = [float(pop.loc[0]), float(pop.loc[1])]
population_effect = float(np.average(
    [ineligible_effect, eligible_nonrecipient_effect],
    weights=population_weights,
))

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "ineligible_effect",
            "estimate": ineligible_effect,
            "se": None,
            "n_obs": n_total,
        },
        {
            "term": "eligible_nonrecipient_effect",
            "estimate": eligible_nonrecipient_effect,
            "se": None,
            "n_obs": n_total,
        },
        {
            "term": "population_effect",
            "estimate": population_effect,
            "se": None,
            "n_obs": n_total,
        },
    ],
    "method_metadata": {
        "estimator": "weighted two-stage least squares (linearmodels IV2SLS)",
        "sample": "households with recipient == 0",
        "dependent_variable": "outcome",
        "endogenous_columns": ["dose_ineligible", "dose_eligible"],
        "exogenous_columns": [
            "ineligible_const",
            "eligible_const",
            "baseline_ineligible",
            "baseline_eligible",
        ],
        "excluded_instruments": ["instrument_ineligible", "instrument_eligible"],
        "regression_weight": "weight",
        "group_effect_definition": "dose slope times household-weighted mean dose within eligibility group",
        "population_aggregation": "nonrecipient_population from census.csv by eligibility group",
        "counterfactual": "dose set to zero for every retained household (synthetic attribution convention)",
    },
    "diagnostics": {
        "n_retained_rows": n_total,
        "n_ineligible_rows": n_ineligible,
        "n_eligible_rows": n_eligible,
        "census_population_weights": {
            "ineligible": population_weights[0],
            "eligible": population_weights[1],
        },
        "slope_dose_ineligible": float(fit.params["dose_ineligible"]),
        "slope_dose_eligible": float(fit.params["dose_eligible"]),
        "weighted_mean_dose_ineligible": float(mean_dose_in),
        "weighted_mean_dose_eligible": float(mean_dose_el),
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
