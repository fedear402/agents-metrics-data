import json

import pandas as pd
from linearmodels.iv import IV2SLS

cw = pd.read_csv("crosswalk.csv", dtype={"code": str, "industry": str})
tr = pd.read_csv("trade.csv", dtype={"code": str})
areas = pd.read_csv("areas.csv", dtype={"area": str, "vintage": str})
emp = pd.read_csv("employment.csv", dtype={"area": str, "vintage": str, "industry": str})
out = pd.read_csv("outcomes.csv", dtype={"area": str})

tr = tr.merge(cw, on="code", how="left")
trd = (
    tr.drop_duplicates(["period", "industry"])
    .set_index(["period", "industry"])
)

industries = sorted(cw["industry"].unique())
periods = sorted(areas["period"].unique())
areas_list = sorted(areas["area"].unique())
pidx = {p: i for i, p in enumerate(periods)}

emp_g = emp.groupby(["area", "period", "vintage", "industry"])["employment"].sum()
full_idx = pd.MultiIndex.from_product(
    [areas_list, periods, ["base", "early"], industries],
    names=["area", "period", "vintage", "industry"],
)
emp_g = emp_g.reindex(full_idx, fill_value=0.0)

national = emp_g.groupby(level=["period", "vintage", "industry"]).sum()
tot = areas.set_index(["area", "period", "vintage"])["total_employment"]
pop = areas[areas["vintage"] == "base"].set_index(["area", "period"])["population"]


def exposure(vintage, change_col):
    rows = {}
    for a in areas_list:
        for p in periods:
            T = float(tot.loc[(a, p, vintage)])
            s = 0.0
            for j in industries:
                E = float(emp_g.loc[(a, p, vintage, j)])
                N = float(national.loc[(p, vintage, j)])
                t = trd.loc[(p, j)]
                s += (
                    E / T
                    * float(t[change_col]) / N
                    / (float(t["price_index"]) / 100)
                    / 1000
                    * (10 / float(t["years"]))
                )
            rows[(a, p)] = s
    return pd.Series(rows)


x = exposure("base", "us_change")
z = exposure("early", "other_change")

df = out.copy()
keys = list(zip(df["area"], df["period"]))
df["x"] = [float(x[k]) for k in keys]
df["z"] = [float(z[k]) for k in keys]
df["w"] = pop.loc[keys].astype(float).values
df["t"] = df["period"].map(pidx).astype(float)

exog = pd.DataFrame(
    {
        "const": 1.0,
        "period": df["t"],
        "control": df["control"].astype(float),
    },
    index=df.index,
)

model = IV2SLS(
    df["change_pp"].astype(float),
    exog,
    df[["x"]],
    df[["z"]],
    weights=df["w"],
).fit(cov_type="unadjusted")

n_obs = int(len(df))
iv_slope = float(model.params["x"])
A0 = "0"
exposure_area0_period0 = float(x[(A0, periods[0])])
exposure_area0_period1 = float(x[(A0, periods[1])])
instrument_area0_period0 = float(z[(A0, periods[0])])

estimates = [
    {"term": "iv_slope", "estimate": iv_slope, "se": None, "n_obs": n_obs},
    {"term": "exposure_area0_period0", "estimate": exposure_area0_period0, "se": None, "n_obs": n_obs},
    {"term": "exposure_area0_period1", "estimate": exposure_area0_period1, "se": None, "n_obs": n_obs},
    {"term": "instrument_area0_period0", "estimate": instrument_area0_period0, "se": None, "n_obs": n_obs},
]

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "weighted 2SLS (linearmodels IV2SLS)",
        "endogenous": ["x"],
        "instruments": ["z", "const", "period", "control"],
        "exogenous": ["const", "period", "control"],
        "weights": "base-vintage population",
        "covariance": "unadjusted",
        "se_reported": False,
    },
    "diagnostics": {
        "n_obs": n_obs,
        "n_areas": int(len(areas_list)),
        "n_periods": int(len(periods)),
        "n_industries": int(len(industries)),
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
