import json

import numpy as np
import pandas as pd


def cohort_att(df, c):
    lo, hi = c - 2, c + 2
    win = df[(df["time"] >= lo) & (df["time"] <= hi)]
    elig = win[(win["g"] == c) | (win["g"] == 0) | (win["g"] > c + 2)]

    n_times = elig.groupby("id")["time"].nunique()
    keep_ids = n_times[n_times == (hi - lo + 1)].index
    sub = elig[elig["id"].isin(keep_ids)].copy()

    sub["did"] = ((sub["g"] == c) & (sub["time"] >= c)).astype(float)
    n_treated = int(sub.loc[sub["g"] == c, "id"].nunique())

    units = sorted(sub["id"].unique())
    times = sorted(sub["time"].unique())
    uidx = {u: i for i, u in enumerate(units)}
    tidx = {t: i for i, t in enumerate(times)}

    ui = sub["id"].map(uidx).to_numpy()
    ti = sub["time"].map(tidx).to_numpy()
    n = len(sub)
    k = 2 + (len(units) - 1) + (len(times) - 1)

    X = np.zeros((n, k))
    X[:, 0] = 1.0
    X[:, 1] = sub["did"].to_numpy()
    rows = np.arange(n)
    mu = ui > 0
    X[rows[mu], 1 + ui[mu]] = 1.0
    mt = ti > 0
    X[rows[mt], len(units) + ti[mt]] = 1.0

    y = sub["y"].to_numpy(dtype=float)
    beta = np.linalg.lstsq(X, y, rcond=None)[0]
    return float(beta[1]), n, n_treated


def main():
    df = pd.read_csv("input.csv")
    df = df[["id", "time", "g", "y"]].copy()
    df["time"] = df["time"].astype(int)
    df["g"] = df["g"].astype(int)

    estimates = []
    atts, weights, row_counts = [], [], []

    for c in (3, 5, 7):
        att, n, n_treated = cohort_att(df, c)
        atts.append(att)
        weights.append(n_treated)
        row_counts.append(n)
        estimates.append({
            "term": f"att_g{c}",
            "estimate": repr(att),
            "se": None,
            "n_obs": n,
        })

    w = np.asarray(weights, dtype=float)
    a = np.asarray(atts, dtype=float)
    att_weighted = float(np.sum(w * a) / np.sum(w))
    estimates.append({
        "term": "att_weighted",
        "estimate": repr(att_weighted),
        "se": None,
        "n_obs": int(sum(row_counts)),
    })

    result = {
        "task_id": "broad_cohort_stack",
        "platform": "python",
        "estimates": estimates,
        "method_metadata": {},
        "diagnostics": {},
    }

    with open("result.json", "w") as f:
        json.dump(result, f, indent=2)


if __name__ == "__main__":
    main()
