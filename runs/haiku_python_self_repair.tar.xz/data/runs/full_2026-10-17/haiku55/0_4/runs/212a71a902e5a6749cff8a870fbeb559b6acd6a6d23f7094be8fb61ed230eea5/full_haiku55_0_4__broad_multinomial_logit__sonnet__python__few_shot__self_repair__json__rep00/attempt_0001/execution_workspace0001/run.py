import json

import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("input.csv")
n_obs = len(df)

X = sm.add_constant(df[["x", "z"]].astype(float), has_constant="add")
y = df["y"].astype(int)

fit = sm.MNLogit(y, X).fit(method="newton", maxiter=500, disp=False, tol=1e-10)

coef = fit.params.copy()
bse = fit.bse.copy()
coef.columns = [1, 2]
bse.columns = [1, 2]

x_cat1 = float(coef.loc["x", 1])
z_cat1 = float(coef.loc["z", 1])
x_cat2 = float(coef.loc["x", 2])
z_cat2 = float(coef.loc["z", 2])
se_x_cat1 = float(bse.loc["x", 1])
se_z_cat1 = float(bse.loc["z", 1])
se_x_cat2 = float(bse.loc["x", 2])
se_z_cat2 = float(bse.loc["z", 2])

pred_input = pd.DataFrame({"const": [1.0], "x": [0.0], "z": [0.0]})
probs = fit.predict(pred_input)
prob_cat2_zero = float(probs.iloc[0, 2])

result = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": [
        {"term": "x_cat1", "estimate": x_cat1, "se": se_x_cat1, "n_obs": n_obs},
        {"term": "z_cat1", "estimate": z_cat1, "se": se_z_cat1, "n_obs": n_obs},
        {"term": "x_cat2", "estimate": x_cat2, "se": se_x_cat2, "n_obs": n_obs},
        {"term": "z_cat2", "estimate": z_cat2, "se": se_z_cat2, "n_obs": n_obs},
        {"term": "prob_cat2_zero", "estimate": prob_cat2_zero, "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "multinomial logit (maximum likelihood, base outcome 0)",
        "vcov": "observed information (inverse Hessian)",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
