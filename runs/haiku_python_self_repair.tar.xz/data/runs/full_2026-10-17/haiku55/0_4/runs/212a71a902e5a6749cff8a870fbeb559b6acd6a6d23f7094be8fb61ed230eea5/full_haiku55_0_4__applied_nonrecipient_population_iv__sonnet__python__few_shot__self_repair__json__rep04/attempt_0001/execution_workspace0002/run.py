import json

import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS

households = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

d = households[households["recipient"] == 0].copy()
n_obs = int(len(d))

ni = (1 - d["eligible"]).astype(float)
el = d["eligible"].astype(float)

endog = pd.DataFrame({
    "dose_ineligible": d["dose"] * ni,
    "dose_eligible": d["dose"] * el,
}, index=d.index)
exog = pd.DataFrame({
    "ineligible": ni,
    "eligible": el,
    "baseline_ineligible": d["baseline"] * ni,
    "baseline_eligible": d["baseline"] * el,
}, index=d.index)
excluded = pd.DataFrame({
    "instrument_ineligible": d["instrument"] * ni,
    "instrument_eligible": d["instrument"] * el,
}, index=d.index)

fit = IV2SLS(
    dependent=d["outcome"],
    exog=exog,
    endog=endog,
    instruments=excluded,
    weights=d["weight"],
).fit(cov_type="robust")

slope_ineligible = float(fit.params["dose_ineligible"])
slope_eligible = float(fit.params["dose_eligible"])

mask_ni = d["eligible"] == 0
mask_el = d["eligible"] == 1
mean_dose_ni = float(np.average(d.loc[mask_ni, "dose"], weights=d.loc[mask_ni, "weight"]))
mean_dose_el = float(np.average(d.loc[mask_el, "dose"], weights=d.loc[mask_el, "weight"]))

ineligible_effect = slope_ineligible * mean_dose_ni
eligible_nonrecipient_effect = slope_eligible * mean_dose_el

pop = census.set_index("eligible")["nonrecipient_population"]
population_effect = float(np.average(
    [ineligible_effect, eligible_nonrecipient_effect],
    weights=[float(pop.loc[0]), float(pop.loc[1])],
))

estimates = [
    {"term": "ineligible_effect", "estimate": float(ineligible_effect), "se": None, "n_obs": n_obs},
    {"term": "eligible_nonrecipient_effect", "estimate": float(eligible_nonrecipient_effect), "se": None, "n_obs": n_obs},
    {"term": "population_effect", "estimate": population_effect, "se": None, "n_obs": n_obs},
]

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "weighted 2SLS (linearmodels IV2SLS, robust covariance)",
        "sample": "households with recipient == 0, all treated statuses",
        "endogenous": ["dose*(1-eligible)", "dose*eligible"],
        "exogenous": ["1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"],
        "instruments_excluded": ["instrument*(1-eligible)", "instrument*eligible"],
        "intercept": "none added beyond group indicators",
        "counterfactual": "dose set to zero for every retained household (synthetic convention)",
        "aggregation_weights": "census nonrecipient_population by eligibility group",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "n_ineligible": int(mask_ni.sum()),
        "n_eligible": int(mask_el.sum()),
        "slope_ineligible": slope_ineligible,
        "slope_eligible": slope_eligible,
        "weighted_mean_dose_ineligible": mean_dose_ni,
        "weighted_mean_dose_eligible": mean_dose_el,
        "census_population_ineligible": int(pop.loc[0]),
        "census_population_eligible": int(pop.loc[1]),
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
