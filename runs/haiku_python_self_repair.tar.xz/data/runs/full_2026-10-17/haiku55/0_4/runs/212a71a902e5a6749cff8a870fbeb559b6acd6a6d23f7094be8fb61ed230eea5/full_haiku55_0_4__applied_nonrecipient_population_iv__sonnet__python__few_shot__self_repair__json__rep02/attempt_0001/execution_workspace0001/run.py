import json

import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS

households = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

d = households[households["recipient"] == 0].copy()
d["eligible"] = d["eligible"].astype(int)
d["ineligible_ind"] = 1.0 - d["eligible"]
d["eligible_ind"] = d["eligible"].astype(float)
d["dose_ne"] = d["dose"] * d["ineligible_ind"]
d["dose_e"] = d["dose"] * d["eligible_ind"]
d["base_ne"] = d["baseline"] * d["ineligible_ind"]
d["base_e"] = d["baseline"] * d["eligible_ind"]
d["inst_ne"] = d["instrument"] * d["ineligible_ind"]
d["inst_e"] = d["instrument"] * d["eligible_ind"]

exog = d[["ineligible_ind", "eligible_ind", "base_ne", "base_e"]]
endog = d[["dose_ne", "dose_e"]]
instruments = d[["ineligible_ind", "eligible_ind", "base_ne", "base_e", "inst_ne", "inst_e"]]

fit = IV2SLS(d["outcome"], exog, endog, instruments, weights=d["weight"]).fit()

slope_ne = float(fit.params["dose_ne"])
slope_e = float(fit.params["dose_e"])

mask_ne = d["eligible"] == 0
mask_e = d["eligible"] == 1

mean_dose_ne = float(np.average(d.loc[mask_ne, "dose"], weights=d.loc[mask_ne, "weight"]))
mean_dose_e = float(np.average(d.loc[mask_e, "dose"], weights=d.loc[mask_e, "weight"]))

ineligible_effect = slope_ne * mean_dose_ne
eligible_nonrecipient_effect = slope_e * mean_dose_e

pop = census.set_index("eligible")["nonrecipient_population"]
w_ne = float(pop.loc[0])
w_e = float(pop.loc[1])
population_effect = (w_ne * ineligible_effect + w_e * eligible_nonrecipient_effect) / (w_ne + w_e)

n_obs = int(len(d))
n_ineligible = int(mask_ne.sum())
n_eligible = int(mask_e.sum())

estimates = [
    {"term": "ineligible_effect", "estimate": float(ineligible_effect), "se": None, "n_obs": n_obs},
    {"term": "eligible_nonrecipient_effect", "estimate": float(eligible_nonrecipient_effect), "se": None, "n_obs": n_obs},
    {"term": "population_effect", "estimate": float(population_effect), "se": None, "n_obs": n_obs},
]

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "weighted 2SLS (linearmodels IV2SLS)",
        "sample": "households with recipient == 0, all village treatment statuses",
        "endogenous": ["dose*(1-eligible)", "dose*eligible"],
        "exogenous": ["1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"],
        "instruments": ["exogenous columns", "instrument*(1-eligible)", "instrument*eligible"],
        "regression_weight": "weight",
        "group_effect": "dose slope times household-weighted mean dose in group",
        "population_aggregation": "nonrecipient_population from census.csv",
        "counterfactual": "dose set to zero for every retained household (synthetic convention)",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "n_ineligible": n_ineligible,
        "n_eligible_nonrecipient": n_eligible,
        "dose_slope_ineligible": slope_ne,
        "dose_slope_eligible": slope_e,
        "weighted_mean_dose_ineligible": mean_dose_ne,
        "weighted_mean_dose_eligible": mean_dose_e,
        "census_weight_ineligible": w_ne,
        "census_weight_eligible": w_e,
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
