import json
import numpy as np
import pandas as pd

df = pd.read_csv('input.csv')
df['id'] = df['id'].astype(int)
df['time'] = df['time'].astype(int)
df['g'] = df['g'].astype(int)
df['y'] = df['y'].astype(float)

def cohort_att(c):
    lo, hi = c - 2, c + 2
    win = df[(df['time'] >= lo) & (df['time'] <= hi)].copy()

    eligible_units = win.loc[(win['g'] == c) | (win['g'] == 0) | (win['g'] > c + 2), 'id'].unique()
    win = win[win['id'].isin(eligible_units)]

    counts = win.groupby('id')['time'].nunique()
    full_units = counts[counts == (hi - lo + 1)].index
    win = win[win['id'].isin(full_units)].copy()

    win['did'] = ((win['g'] == c) & (win['time'] >= c)).astype(float)

    unit_ids = np.sort(win['id'].unique())
    time_ids = np.sort(win['time'].unique())

    n = len(win)
    X_unit = pd.get_dummies(win['id'], drop_first=True, dtype=float)
    X_time = pd.get_dummies(win['time'], drop_first=True, dtype=float)
    design = np.column_stack([
        np.ones(n),
        win['did'].values,
        X_unit.values,
        X_time.values,
    ])
    beta = np.linalg.lstsq(design, win['y'].values, rcond=None)[0]
    att = float(beta[1])

    retained_treated = int(win.loc[win['g'] == c, 'id'].nunique())
    return att, retained_treated, n

results = {}
for c in [3, 5, 7]:
    att, n_treated, n_rows = cohort_att(c)
    results[c] = {'att': att, 'treated': n_treated, 'rows': n_rows}

total_treated = sum(results[c]['treated'] for c in results)
att_weighted = float(
    sum(results[c]['att'] * results[c]['treated'] for c in results) / total_treated
) if total_treated > 0 else float('nan')
total_rows = int(sum(results[c]['rows'] for c in results))

estimates = [
    {'term': 'att_g3', 'estimate': results[3]['att'], 'se': None, 'n_obs': results[3]['rows']},
    {'term': 'att_g5', 'estimate': results[5]['att'], 'se': None, 'n_obs': results[5]['rows']},
    {'term': 'att_g7', 'estimate': results[7]['att'], 'se': None, 'n_obs': results[7]['rows']},
    {'term': 'att_weighted', 'estimate': att_weighted, 'se': None, 'n_obs': total_rows},
]

output = {
    'task_id': 'broad_cohort_stack',
    'platform': 'python',
    'estimates': estimates,
    'method_metadata': {},
    'diagnostics': {},
}

with open('result.json', 'w') as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
