import json

import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS

crosswalk = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv")
areas = pd.read_csv("areas.csv")
emp = pd.read_csv("employment.csv")
outcomes = pd.read_csv("outcomes.csv")

trade = trade.merge(crosswalk, on="code", how="left")
industries = sorted(crosswalk["industry"].unique())
periods = sorted(areas["period"].unique())

trade_map = {
    (p, j): (u, o)
    for p, j, u, o in trade[["period", "industry", "us_change", "other_change"]].itertuples(index=False, name=None)
}
price = trade.groupby("period")["price_index"].first().to_dict()
years = trade.groupby("period")["years"].first().to_dict()

emp_g = emp.groupby(["area", "period", "vintage", "industry"])["employment"].sum().to_dict()
nat_g = emp.groupby(["period", "vintage", "industry"])["employment"].sum().to_dict()
tot = areas.groupby(["area", "period", "vintage"])["total_employment"].sum().to_dict()
pop = areas[areas["vintage"] == "base"].groupby(["area", "period"])["population"].sum().to_dict()


def get_emp(a, p, v, j):
    return emp_g.get((a, p, v, j), 0.0)


def exposure(a, p, vintage, k):
    total = tot[(a, p, vintage)]
    s = 0.0
    for j in industries:
        nat = nat_g[(p, vintage, j)]
        shock = trade_map[(p, j)][k] / nat / (price[p] / 100) / 1000 * (10 / years[p])
        s += get_emp(a, p, vintage, j) / total * shock
    return s


rows = outcomes[["area", "period", "control", "change_pp"]].copy().reset_index(drop=True)
rows["x"] = [exposure(a, p, "base", 0) for a, p in zip(rows["area"], rows["period"])]
rows["z"] = [exposure(a, p, "early", 1) for a, p in zip(rows["area"], rows["period"])]
rows["w"] = [pop[(a, p)] for a, p in zip(rows["area"], rows["period"])]

exog = pd.DataFrame(
    {
        "const": 1.0,
        "period": rows["period"].astype(float),
        "control": rows["control"].astype(float),
    },
    index=rows.index,
)

fit = IV2SLS(
    rows["change_pp"].astype(float),
    exog,
    rows[["x"]].astype(float),
    rows[["z"]].astype(float),
    weights=rows["w"].astype(float),
).fit()

n_obs = int(len(rows))
iv_slope = float(fit.params["x"])
exposure_area0_period0 = float(exposure(0, periods[0], "base", 0))
exposure_area0_period1 = float(exposure(0, periods[1], "base", 0))
instrument_area0_period0 = float(exposure(0, periods[0], "early", 1))

estimates = [
    {"term": "iv_slope", "estimate": iv_slope, "se": None, "n_obs": n_obs},
    {"term": "exposure_area0_period0", "estimate": exposure_area0_period0, "se": None, "n_obs": n_obs},
    {"term": "exposure_area0_period1", "estimate": exposure_area0_period1, "se": None, "n_obs": n_obs},
    {"term": "instrument_area0_period0", "estimate": instrument_area0_period0, "se": None, "n_obs": n_obs},
]

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "library": "linearmodels.iv.IV2SLS",
        "dependent": "change_pp",
        "exogenous": ["const", "period", "control"],
        "endogenous": ["x"],
        "instruments": ["z"],
        "weights": "base-vintage population",
        "n_obs": n_obs,
    },
    "diagnostics": {
        "n_area_period_obs": n_obs,
        "n_periods": int(len(periods)),
        "n_industries": int(len(industries)),
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
