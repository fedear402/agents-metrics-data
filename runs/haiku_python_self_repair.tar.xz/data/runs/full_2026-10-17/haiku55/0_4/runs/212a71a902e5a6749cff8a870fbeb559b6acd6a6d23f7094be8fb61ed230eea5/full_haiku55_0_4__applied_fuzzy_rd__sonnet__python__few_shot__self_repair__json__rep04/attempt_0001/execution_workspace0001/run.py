import json

import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df = df[np.abs(df["score"]) < 1].copy()

s = df["score"].to_numpy(dtype=float)
w = 1.0 - np.abs(s)
y = df["earnings"].to_numpy(dtype=float)
d = df["participated"].to_numpy(dtype=float)
right = (s >= 0).astype(float)
left = 1.0 - right

X = np.column_stack([right, left, right * s, left * s])
n = len(s)


def fit(outcome):
    XtW = X.T * w
    bread = np.linalg.inv(XtW @ X)
    beta = bread @ (XtW @ outcome)
    resid = outcome - X @ beta
    scores = (X * (w * resid)[:, None])
    meat = scores.T @ scores
    vcov = bread @ meat @ bread
    return beta, vcov


beta_y, V_y = fit(y)
beta_d, V_d = fit(d)

# Intercepts: right-side intercept is beta[0], left-side intercept is beta[1]
jump_y = beta_y[0] - beta_y[1]
jump_d = beta_d[0] - beta_d[1]

c = np.array([1.0, -1.0, 0.0, 0.0])
# Joint covariance of the two discontinuities via stacked influence functions
bread_y = np.linalg.inv((X.T * w) @ X)
bread_d = bread_y
ry = y - X @ beta_y
rd = d - X @ beta_d
inf_y = (X @ bread_y @ c)[:, None] * 0  # placeholder replaced below
a = X @ bread_y @ c
inf_y = a * w * ry
inf_d = a * w * rd
V_yy = np.sum(inf_y**2)
V_dd = np.sum(inf_d**2)
V_yd = np.sum(inf_y * inf_d)
se_y = np.sqrt(V_yy)
se_d = np.sqrt(V_dd)

tau = jump_y / jump_d
grad = np.array([1.0 / jump_d, -jump_y / jump_d**2])
joint = np.array([[V_yy, V_yd], [V_yd, V_dd]])
se_tau = np.sqrt(grad @ joint @ grad)

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": float(tau), "se": float(se_tau), "n_obs": int(n)},
        {"term": "reduced_form", "estimate": float(jump_y), "se": float(se_y), "n_obs": int(n)},
        {"term": "first_stage", "estimate": float(jump_d), "se": float(se_d), "n_obs": int(n)},
    ],
    "method_metadata": {
        "estimator": "fuzzy RD, local linear, triangular kernel, bandwidth 1, separate slopes by side",
        "vcov": "HC0 heteroskedasticity-robust, delta method for ratio",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2, allow_nan=False)
