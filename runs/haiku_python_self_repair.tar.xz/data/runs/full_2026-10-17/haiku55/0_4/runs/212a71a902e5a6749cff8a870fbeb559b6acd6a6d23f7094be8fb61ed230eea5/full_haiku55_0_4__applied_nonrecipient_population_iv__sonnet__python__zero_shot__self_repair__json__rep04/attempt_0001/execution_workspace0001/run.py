import json

import numpy as np
import pandas as pd

hh = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

hh = hh[pd.to_numeric(hh["recipient"]) == 0].copy()
n_obs = int(len(hh))

e = hh["eligible"].astype(float).to_numpy()
ne = 1.0 - e
dose = hh["dose"].astype(float).to_numpy()
base = hh["baseline"].astype(float).to_numpy()
inst = hh["instrument"].astype(float).to_numpy()
w = hh["weight"].astype(float).to_numpy()
y = hh["outcome"].astype(float).to_numpy()

X = np.column_stack([dose * ne, dose * e, ne, e, base * ne, base * e])
Z = np.column_stack([ne, e, base * ne, base * e, inst * ne, inst * e])

ZW = Z * w[:, None]
A_inv = np.linalg.pinv(Z.T @ ZW)
XZ = X.T @ ZW
Zy = ZW.T @ y
beta = np.linalg.solve(XZ @ A_inv @ XZ.T, XZ @ A_inv @ Zy)

slope_ineligible = float(beta[0])
slope_eligible = float(beta[1])

w0 = np.sum(w * ne)
w1 = np.sum(w * e)
mean_dose_ineligible = float(np.sum(w * dose * ne) / w0)
mean_dose_eligible = float(np.sum(w * dose * e) / w1)

ineligible_effect = slope_ineligible * mean_dose_ineligible
eligible_nonrecipient_effect = slope_eligible * mean_dose_eligible

census["eligible"] = census["eligible"].astype(int)
pop = census.groupby("eligible")["nonrecipient_population"].sum().astype(float)
N0 = float(pop.loc[0])
N1 = float(pop.loc[1])
population_effect = (N0 * ineligible_effect + N1 * eligible_nonrecipient_effect) / (N0 + N1)

estimates = [
    {"term": "ineligible_effect", "estimate": float(ineligible_effect), "se": None, "n_obs": n_obs},
    {"term": "eligible_nonrecipient_effect", "estimate": float(eligible_nonrecipient_effect), "se": None, "n_obs": n_obs},
    {"term": "population_effect", "estimate": float(population_effect), "se": None, "n_obs": n_obs},
]

method_metadata = {
    "method": "weighted_2sls",
    "regression_weight": "weight",
    "intercept": False,
    "endogenous_columns": ["dose*(1-eligible)", "dose*eligible"],
    "exogenous_columns": ["1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"],
    "instrument_columns": [
        "1-eligible",
        "eligible",
        "baseline*(1-eligible)",
        "baseline*eligible",
        "instrument*(1-eligible)",
        "instrument*eligible",
    ],
    "sample": "households with recipient == 0, both village treatment statuses",
    "counterfactual": "dose set to zero for every retained household",
    "effect_definition": "group dose slope times household-weighted mean dose among retained group rows",
    "aggregation_weights": "census nonrecipient_population by eligibility group",
    "attribution_note": "Attribution to a zero-dose counterfactual is a stated synthetic convention.",
}

diagnostics = {
    "n_obs": n_obs,
    "n_ineligible": int(np.sum(ne)),
    "n_eligible": int(np.sum(e)),
    "rank_X": int(np.linalg.matrix_rank(X * np.sqrt(w)[:, None])),
    "rank_Z": int(np.linalg.matrix_rank(ZW / np.sqrt(w)[:, None] * np.sqrt(w)[:, None])),
    "slope_ineligible_dose": slope_ineligible,
    "slope_eligible_dose": slope_eligible,
    "weighted_mean_dose_ineligible": mean_dose_ineligible,
    "weighted_mean_dose_eligible": mean_dose_eligible,
    "weight_sum_ineligible": float(w0),
    "weight_sum_eligible": float(w1),
    "census_nonrecipient_population_ineligible": N0,
    "census_nonrecipient_population_eligible": N1,
}

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": method_metadata,
    "diagnostics": diagnostics,
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
