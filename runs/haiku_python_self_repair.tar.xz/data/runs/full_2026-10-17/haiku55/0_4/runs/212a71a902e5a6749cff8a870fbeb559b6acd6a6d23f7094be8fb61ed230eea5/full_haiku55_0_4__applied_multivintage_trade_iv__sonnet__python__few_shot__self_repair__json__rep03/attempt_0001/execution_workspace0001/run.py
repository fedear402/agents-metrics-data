import json

import numpy as np
import pandas as pd

crosswalk = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv")
areas = pd.read_csv("areas.csv")
employment = pd.read_csv("employment.csv")
outcomes = pd.read_csv("outcomes.csv")

trade = trade.merge(crosswalk, on="code", how="left", validate="m:1")

emp = employment.groupby(["area", "period", "vintage", "industry"], as_index=False)["employment"].sum()


def exposure(vintage, change_col):
    e = emp[emp["vintage"] == vintage]
    nat = (
        e.groupby(["period", "industry"], as_index=False)["employment"]
        .sum()
        .rename(columns={"employment": "national"})
    )
    tot = areas.loc[areas["vintage"] == vintage, ["area", "period", "total_employment"]]
    tr = trade[["period", "industry", change_col, "price_index", "years"]]
    m = (
        e.merge(nat, on=["period", "industry"], how="left", validate="m:1")
        .merge(tot, on=["area", "period"], how="left", validate="m:1")
        .merge(tr, on=["period", "industry"], how="left", validate="m:1")
    )
    m["term"] = (
        m["employment"] / m["total_employment"]
        * m[change_col] / m["national"]
        / (m["price_index"] / 100) / 1000 * (10 / m["years"])
    )
    out = m.groupby(["area", "period"], as_index=False)["term"].sum()
    grid = tot[["area", "period"]]
    out = grid.merge(out, on=["area", "period"], how="left")
    out["term"] = out["term"].fillna(0.0)
    return out


x_df = exposure("base", "us_change").rename(columns={"term": "x"})
z_df = exposure("early", "other_change").rename(columns={"term": "z"})
pop = areas.loc[areas["vintage"] == "base", ["area", "period", "population"]]

panel = (
    outcomes.merge(x_df, on=["area", "period"], how="left", validate="1:1")
    .merge(z_df, on=["area", "period"], how="left", validate="1:1")
    .merge(pop, on=["area", "period"], how="left", validate="1:1")
)

n_obs = int(len(panel))

y = panel["change_pp"].to_numpy(dtype=float)
w = panel["population"].to_numpy(dtype=float)
x = panel["x"].to_numpy(dtype=float)
z = panel["z"].to_numpy(dtype=float)
ones = np.ones(n_obs)
period = panel["period"].to_numpy(dtype=float)
control = panel["control"].to_numpy(dtype=float)

X = np.column_stack([ones, period, control, x])
Z = np.column_stack([ones, period, control, z])

sw = np.sqrt(w)
Xw = X * sw[:, None]
Zw = Z * sw[:, None]
yw = y * sw

Pz_yw = Zw @ np.linalg.lstsq(Zw, yw, rcond=None)[0]
Pz_Xw = Zw @ np.linalg.lstsq(Zw, Xw, rcond=None)[0]
beta = np.linalg.lstsq(Pz_Xw, Pz_yw, rcond=None)[0]
iv_slope = float(beta[-1])


def get_value(column, area, period_value):
    sel = panel.loc[(panel["area"] == area) & (panel["period"] == period_value), column]
    return float(sel.iloc[0])


exposure_area0_period0 = get_value("x", 0, 0)
exposure_area0_period1 = get_value("x", 0, 1)
instrument_area0_period0 = get_value("z", 0, 0)

estimates = [
    {"term": "iv_slope", "estimate": iv_slope, "se": None, "n_obs": n_obs},
    {"term": "exposure_area0_period0", "estimate": exposure_area0_period0, "se": None, "n_obs": n_obs},
    {"term": "exposure_area0_period1", "estimate": exposure_area0_period1, "se": None, "n_obs": n_obs},
    {"term": "instrument_area0_period0", "estimate": instrument_area0_period0, "se": None, "n_obs": n_obs},
]

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "weighted_2sls",
        "endogenous": ["x"],
        "instruments": ["z", "intercept", "period", "control"],
        "exogenous": ["intercept", "period", "control"],
        "weight": "base_vintage_population",
        "n_obs": n_obs,
    },
    "diagnostics": {
        "n_obs": n_obs,
        "sum_weights": float(w.sum()),
        "instrument_rank": int(np.linalg.matrix_rank(Zw)),
        "regressor_rank": int(np.linalg.matrix_rank(Xw)),
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
