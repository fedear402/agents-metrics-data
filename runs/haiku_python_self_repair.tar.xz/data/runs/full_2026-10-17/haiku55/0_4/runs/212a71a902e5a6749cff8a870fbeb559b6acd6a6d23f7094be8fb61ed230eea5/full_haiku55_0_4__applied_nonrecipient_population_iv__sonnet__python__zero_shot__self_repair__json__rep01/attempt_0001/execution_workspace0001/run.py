import json

import numpy as np
import pandas as pd

TASK_ID = "applied_nonrecipient_population_iv"

hh = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

numeric_cols = ["eligible", "treated", "recipient", "instrument", "dose", "baseline", "weight", "outcome"]
for col in numeric_cols:
    hh[col] = pd.to_numeric(hh[col])

df = hh.loc[hh["recipient"] == 0].copy()
n_obs = int(len(df))

e = df["eligible"].to_numpy(dtype=float)
ne = 1.0 - e
d = df["dose"].to_numpy(dtype=float)
b = df["baseline"].to_numpy(dtype=float)
z = df["instrument"].to_numpy(dtype=float)
w = df["weight"].to_numpy(dtype=float)
y = df["outcome"].to_numpy(dtype=float)

X = np.column_stack([d * ne, d * e, ne, e, b * ne, b * e])
Z = np.column_stack([ne, e, b * ne, b * e, z * ne, z * e])

ZW = Z * w[:, None]
A = X.T @ ZW
B = np.linalg.inv(Z.T @ ZW)
M = A @ B @ A.T
beta = np.linalg.solve(M, A @ B @ (ZW.T @ y))

slope_ineligible = float(beta[0])
slope_eligible = float(beta[1])

w0 = w * ne
w1 = w * e
mean_dose_ineligible = float(np.sum(w0 * d) / np.sum(w0))
mean_dose_eligible = float(np.sum(w1 * d) / np.sum(w1))

ineligible_effect = slope_ineligible * mean_dose_ineligible
eligible_nonrecipient_effect = slope_eligible * mean_dose_eligible

pop0 = float(census.loc[census["eligible"] == 0, "nonrecipient_population"].sum())
pop1 = float(census.loc[census["eligible"] == 1, "nonrecipient_population"].sum())
population_effect = (pop0 * ineligible_effect + pop1 * eligible_nonrecipient_effect) / (pop0 + pop1)

result = {
    "task_id": TASK_ID,
    "platform": "python",
    "estimates": [
        {
            "term": "ineligible_effect",
            "estimate": float(ineligible_effect),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "eligible_nonrecipient_effect",
            "estimate": float(eligible_nonrecipient_effect),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "population_effect",
            "estimate": float(population_effect),
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "weighted two-stage least squares",
        "regression_weight": "weight",
        "sample": "households with recipient == 0, both village treatment statuses retained",
        "endogenous_columns": ["dose*(1-eligible)", "dose*eligible"],
        "exogenous_columns": ["1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"],
        "instrument_columns": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
            "instrument*(1-eligible)",
            "instrument*eligible",
        ],
        "intercept": "none; 1-eligible and eligible act as group intercepts",
        "group_effect": "fitted dose slope times household-weighted mean dose within group",
        "counterfactual": "dose set to zero for every retained household",
        "population_aggregation": "census nonrecipient_population used only for between-group weights",
        "attribution_convention": "zero-dose counterfactual attribution is a stated synthetic convention",
        "standard_errors": "not reported",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "n_ineligible_obs": int(np.sum(ne)),
        "n_eligible_obs": int(np.sum(e)),
        "slope_dose_ineligible": slope_ineligible,
        "slope_dose_eligible": slope_eligible,
        "weighted_mean_dose_ineligible": mean_dose_ineligible,
        "weighted_mean_dose_eligible": mean_dose_eligible,
        "census_nonrecipient_population_ineligible": pop0,
        "census_nonrecipient_population_eligible": pop1,
        "rank_of_instrument_moment_matrix": int(np.linalg.matrix_rank(M)),
        "number_of_regressors": int(X.shape[1]),
        "number_of_instruments": int(Z.shape[1]),
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
