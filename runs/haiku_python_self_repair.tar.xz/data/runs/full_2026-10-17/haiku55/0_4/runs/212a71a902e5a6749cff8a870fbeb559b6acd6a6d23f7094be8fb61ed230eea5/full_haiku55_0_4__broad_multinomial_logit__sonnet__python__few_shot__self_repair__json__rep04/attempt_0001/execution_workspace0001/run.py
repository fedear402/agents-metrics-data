import json

import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("input.csv")
n = len(df)

X = sm.add_constant(df[["x", "z"]].astype(float), has_constant="add")
fit = sm.MNLogit(df["y"].astype(int), X).fit(disp=False, tol=1e-10, maxiter=1000)

outcomes = [0, 1, 2]
nonbase = [1, 2]
params = fit.params.copy()
bse = fit.bse.copy()
params.columns = nonbase
bse.columns = nonbase

pred_input = pd.DataFrame({"const": [1.0], "x": [0.0], "z": [0.0]})
pred = pd.Series(np.asarray(fit.predict(pred_input))[0], index=outcomes) if False else None

import numpy as np
from scipy.special import softmax

manual_eta = np.r_[0.0, params.loc["const", 1], params.loc["const", 2]]
probs_zero = softmax(manual_eta)
p_cat2_zero = float(probs_zero[2])

result = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": [
        {"term": "x_cat1", "estimate": float(params.loc["x", 1]), "se": float(bse.loc["x", 1]), "n_obs": int(n)},
        {"term": "z_cat1", "estimate": float(params.loc["z", 1]), "se": float(bse.loc["z", 1]), "n_obs": int(n)},
        {"term": "x_cat2", "estimate": float(params.loc["x", 2]), "se": float(bse.loc["x", 2]), "n_obs": int(n)},
        {"term": "z_cat2", "estimate": float(params.loc["z", 2]), "se": float(bse.loc["z", 2]), "n_obs": int(n)},
        {"term": "prob_cat2_zero", "estimate": p_cat2_zero, "se": None, "n_obs": int(n)},
    ],
    "method_metadata": {
        "estimator": "multinomial logit (maximum likelihood, base outcome 0)",
        "vcov": "conventional observed-information (inverse Hessian)",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
