import json

import numpy as np
import pandas as pd

BANDWIDTH = 1.0

df = pd.read_csv("input.csv")
s_all = df["score"].to_numpy(dtype=float)
d_all = df["participated"].to_numpy(dtype=float)
y_all = df["earnings"].to_numpy(dtype=float)

inside = np.abs(s_all) < BANDWIDTH
s = s_all[inside]
d = d_all[inside]
y = y_all[inside]
w = 1.0 - np.abs(s)
n_obs = int(s.size)


def side_fit(mask):
    ss = s[mask]
    ww = w[mask]
    yy = y[mask]
    dd = d[mask]
    X = np.column_stack([np.ones_like(ss), ss])
    XtW = X.T * ww
    B = np.linalg.inv(XtW @ X)
    by = B @ (XtW @ yy)
    bd = B @ (XtW @ dd)
    ey = yy - X @ by
    ed = dd - X @ bd
    Xw = X * ww[:, None]

    def meat(ea, eb):
        return (Xw * (ea * eb)[:, None]).T @ Xw

    Vyy = B @ meat(ey, ey) @ B
    Vdd = B @ meat(ed, ed) @ B
    Vyd = B @ meat(ey, ed) @ B
    return {
        "a_y": by[0],
        "a_d": bd[0],
        "V_yy": Vyy[0, 0],
        "V_dd": Vdd[0, 0],
        "V_yd": Vyd[0, 0],
        "n": int(mask.sum()),
    }


right = side_fit(s >= 0)
left = side_fit(s < 0)

rf = right["a_y"] - left["a_y"]
fs = right["a_d"] - left["a_d"]
var_rf = right["V_yy"] + left["V_yy"]
var_fs = right["V_dd"] + left["V_dd"]
cov_rf_fs = right["V_yd"] + left["V_yd"]

te = rf / fs
grad = np.array([1.0 / fs, -rf / fs**2])
V = np.array([[var_rf, cov_rf_fs], [cov_rf_fs, var_fs]])
se_te = float(np.sqrt(grad @ V @ grad))

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": float(te), "se": se_te, "n_obs": n_obs},
        {"term": "reduced_form", "estimate": float(rf), "se": float(np.sqrt(var_rf)), "n_obs": n_obs},
        {"term": "first_stage", "estimate": float(fs), "se": float(np.sqrt(var_fs)), "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "Fuzzy RD, local linear WLS with triangular kernel, cutoff 0, bandwidth 1, separate slopes and intercepts per side; treatment effect as ratio of discontinuities",
        "vcov": "HC0 heteroskedasticity-robust sandwich (no small-sample correction) for each side; delta method for ratio with joint covariance of reduced form and first stage",
    },
    "diagnostics": {
        "bandwidth": BANDWIDTH,
        "kernel": "triangular",
        "n_left": left["n"],
        "n_right": right["n"],
        "bias_correction": False,
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
