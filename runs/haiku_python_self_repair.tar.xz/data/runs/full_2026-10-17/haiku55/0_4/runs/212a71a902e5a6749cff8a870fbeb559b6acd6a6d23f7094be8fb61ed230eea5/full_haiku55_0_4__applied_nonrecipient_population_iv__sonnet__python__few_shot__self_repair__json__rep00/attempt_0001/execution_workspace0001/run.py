import json

import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS

households = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

d = households[households["recipient"] == 0].copy()
e = d["eligible"].astype(float)
ne = 1.0 - e

exog = pd.DataFrame(
    {
        "ineligible": ne,
        "eligible_ind": e,
        "baseline_ineligible": d["baseline"] * ne,
        "baseline_eligible": d["baseline"] * e,
    },
    index=d.index,
)

endog = pd.DataFrame(
    {
        "dose_ineligible": d["dose"] * ne,
        "dose_eligible": d["dose"] * e,
    },
    index=d.index,
)

excluded = pd.DataFrame(
    {
        "instrument_ineligible": d["instrument"] * ne,
        "instrument_eligible": d["instrument"] * e,
    },
    index=d.index,
)

instruments = pd.concat([exog, excluded], axis=1)

fit = IV2SLS(
    d["outcome"],
    exog,
    endog,
    instruments,
    weights=d["weight"],
).fit()

slope_ineligible = float(fit.params["dose_ineligible"])
slope_eligible = float(fit.params["dose_eligible"])

mask_ne = e == 0
mask_e = e == 1

mean_dose_ineligible = float(
    np.average(d.loc[mask_ne, "dose"], weights=d.loc[mask_ne, "weight"])
)
mean_dose_eligible = float(
    np.average(d.loc[mask_e, "dose"], weights=d.loc[mask_e, "weight"])
)

ineligible_effect = slope_ineligible * mean_dose_ineligible
eligible_nonrecipient_effect = slope_eligible * mean_dose_eligible

pop = census.set_index("eligible")["nonrecipient_population"]
w_ineligible = float(pop.loc[0])
w_eligible = float(pop.loc[1])
population_effect = (
    w_ineligible * ineligible_effect + w_eligible * eligible_nonrecipient_effect
) / (w_ineligible + w_eligible)

n_obs = int(len(d))
n_ineligible = int(mask_ne.sum())
n_eligible = int(mask_e.sum())

estimates = [
    {
        "term": "ineligible_effect",
        "estimate": float(ineligible_effect),
        "se": None,
        "n_obs": n_obs,
    },
    {
        "term": "eligible_nonrecipient_effect",
        "estimate": float(eligible_nonrecipient_effect),
        "se": None,
        "n_obs": n_obs,
    },
    {
        "term": "population_effect",
        "estimate": float(population_effect),
        "se": None,
        "n_obs": n_obs,
    },
]

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "weighted 2SLS via linearmodels IV2SLS",
        "sample": "households with recipient == 0, all village treatment statuses",
        "endogenous": ["dose_ineligible", "dose_eligible"],
        "instruments": ["instrument_ineligible", "instrument_eligible"],
        "regression_weight": "weight",
        "group_effect": "dose slope times household-weighted mean dose within eligibility group",
        "counterfactual": "zero dose for every retained household (synthetic attribution convention)",
        "population_aggregation": "nonrecipient_population from census.csv, used only for final group weights",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "n_obs_ineligible": n_ineligible,
        "n_obs_eligible": n_eligible,
        "group_slope_ineligible": slope_ineligible,
        "group_slope_eligible": slope_eligible,
        "weighted_mean_dose_ineligible": mean_dose_ineligible,
        "weighted_mean_dose_eligible": mean_dose_eligible,
        "census_population_ineligible": w_ineligible,
        "census_population_eligible": w_eligible,
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
