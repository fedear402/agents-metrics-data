import json

import numpy as np
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("input.csv")
y = df["y"].to_numpy().astype(int)
X = sm.add_constant(df[["x", "z"]].to_numpy(dtype=float), has_constant="add")
fit = sm.MNLogit(y, X).fit(disp=False, maxiter=500, tol=1e-10)

params = np.asarray(fit.params)
bse = np.asarray(fit.bse)
n = int(len(df))

a = np.array([0.0, params[0, 0], params[0, 1]])
p = np.exp(a - a.max())
p = p / p.sum()

output = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": [
        {"term": "x_cat1", "estimate": float(params[1, 0]), "se": float(bse[1, 0]), "n_obs": n},
        {"term": "z_cat1", "estimate": float(params[2, 0]), "se": float(bse[2, 0]), "n_obs": n},
        {"term": "x_cat2", "estimate": float(params[1, 1]), "se": float(bse[1, 1]), "n_obs": n},
        {"term": "z_cat2", "estimate": float(params[2, 1]), "se": float(bse[2, 1]), "n_obs": n},
        {"term": "prob_cat2_zero", "estimate": float(p[2]), "se": None, "n_obs": n},
    ],
    "method_metadata": {
        "estimator": "multinomial logit maximum likelihood",
        "vcov": "observed information (inverse negative Hessian)",
    },
    "diagnostics": {"converged": bool(fit.mle_retvals["converged"])},
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
