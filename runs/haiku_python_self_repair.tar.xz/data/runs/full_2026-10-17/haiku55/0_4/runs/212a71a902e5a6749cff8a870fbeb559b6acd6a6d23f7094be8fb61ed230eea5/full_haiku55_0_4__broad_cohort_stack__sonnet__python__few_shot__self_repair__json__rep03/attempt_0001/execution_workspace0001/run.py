import json

import numpy as np
import pandas as pd

df = pd.read_csv('input.csv')

cohorts = [3, 5, 7]
atts = {}
row_counts = {}
treated_counts = {}

for c in cohorts:
    window = list(range(c - 2, c + 3))
    sub = df[df['time'].isin(window)]
    eligible = sub[(sub['g'] == c) | (sub['g'] == 0) | (sub['g'] > c + 2)]
    n_times = eligible.groupby('id')['time'].nunique()
    keep_ids = n_times[n_times == len(window)].index
    d = eligible[eligible['id'].isin(keep_ids)].copy()
    d['did'] = ((d['g'] == c) & (d['time'] >= c)).astype(float)

    treated_counts[c] = int(d.loc[d['g'] == c, 'id'].nunique())
    row_counts[c] = int(len(d))

    X = pd.concat(
        [
            pd.Series(1.0, index=d.index, name='const'),
            d['did'],
            pd.get_dummies(d['id'], drop_first=True, dtype=float),
            pd.get_dummies(d['time'], drop_first=True, dtype=float),
        ],
        axis=1,
    ).values.astype(float)
    beta = np.linalg.lstsq(X, d['y'].values.astype(float), rcond=None)[0]
    atts[c] = float(beta[1])

total_treated = sum(treated_counts.values())
att_weighted = float(
    sum(treated_counts[c] * atts[c] for c in cohorts) / total_treated
)

output = {
    'task_id': 'broad_cohort_stack',
    'platform': 'python',
    'estimates': [
        {'term': 'att_g3', 'estimate': atts[3], 'se': None, 'n_obs': row_counts[3]},
        {'term': 'att_g5', 'estimate': atts[5], 'se': None, 'n_obs': row_counts[5]},
        {'term': 'att_g7', 'estimate': atts[7], 'se': None, 'n_obs': row_counts[7]},
        {
            'term': 'att_weighted',
            'estimate': att_weighted,
            'se': None,
            'n_obs': int(sum(row_counts.values())),
        },
    ],
    'method_metadata': {},
    'diagnostics': {},
}

with open('result.json', 'w') as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
