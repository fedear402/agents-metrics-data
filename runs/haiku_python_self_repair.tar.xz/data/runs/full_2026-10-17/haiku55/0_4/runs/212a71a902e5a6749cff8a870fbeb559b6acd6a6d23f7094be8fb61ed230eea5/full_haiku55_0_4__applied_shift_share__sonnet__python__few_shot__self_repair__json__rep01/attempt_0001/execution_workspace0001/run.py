import json

import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")

region = df.groupby("region_id").agg(
    region_weight=("region_weight", "first"),
    x=("x", "first"),
    y=("y", "first"),
)
S_df = df.pivot_table(
    index="region_id", columns="industry_id", values="share", aggfunc="sum", fill_value=0.0
)
S_df = S_df.loc[region.index]
shock_by_ind = df.groupby("industry_id")["shock"].first().reindex(S_df.columns)

S = S_df.to_numpy(float)
shock = shock_by_ind.to_numpy(float)
e = region["region_weight"].to_numpy(float)
e = e / e.sum()
x = region["x"].to_numpy(float)
y = region["y"].to_numpy(float)
z = S @ shock

y0 = y - e @ y
x0 = x - e @ x
z0 = z - e @ z

s = e @ S
N = len(s)


def agg(v0):
    return (S.T @ (e * v0)) / s


ybar = agg(y0)
xbar = agg(x0)
zbar = agg(z0)


def shock_iv(dep, endog):
    X = np.column_stack([np.ones(N), endog])
    Z = np.column_stack([np.ones(N), shock])
    cross = Z.T @ (s[:, None] * X)
    beta = np.linalg.solve(cross, Z.T @ (s * dep))
    u = dep - X @ beta
    scores = Z * (s * u)[:, None]
    inv = np.linalg.inv(cross)
    hc1 = N / (N - 2)
    V = hc1 * inv @ (scores.T @ scores) @ inv.T
    return float(beta[1]), float(np.sqrt(V[1, 1]))


effect, effect_se = shock_iv(ybar, xbar)
first_stage, first_stage_se = shock_iv(xbar, zbar)
effective_shocks = float(1.0 / np.sum(s ** 2))

regional_2sls = float(np.sum(e * z0 * y0) / np.sum(e * z0 * x0))
regional_first_stage = float(np.sum(e * z0 * x0) / np.sum(e * z0 ** 2))

output = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": effect, "se": effect_se, "n_obs": int(N)},
        {"term": "first_stage", "estimate": first_stage, "se": first_stage_se, "n_obs": int(N)},
        {"term": "effective_shocks", "estimate": effective_shocks, "se": None, "n_obs": int(N)},
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS of y on x instrumented by z, with Borusyak-Hull-Jaravel shock-level weighted IV",
        "vcov": "shock-level heteroskedasticity-robust HC1 (N/(N-2)), industries as independent units, no clustering",
    },
    "diagnostics": {
        "regional_2sls_check": regional_2sls,
        "regional_first_stage_check": regional_first_stage,
        "num_regions": int(len(e)),
        "num_industries": int(N),
    },
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
