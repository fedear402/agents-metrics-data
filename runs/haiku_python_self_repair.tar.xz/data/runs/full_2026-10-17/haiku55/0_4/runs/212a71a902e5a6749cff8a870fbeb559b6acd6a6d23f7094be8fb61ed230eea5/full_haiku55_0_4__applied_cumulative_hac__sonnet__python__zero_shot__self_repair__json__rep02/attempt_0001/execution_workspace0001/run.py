import json

import numpy as np
import pandas as pd
import statsmodels.api as sm

L = 15

df = pd.read_csv("input.csv")
df["date"] = pd.to_datetime(df["date"])
df = df.sort_values("date").reset_index(drop=True)

df["dlvix"] = np.log(df["vix"]).diff()
df["lsales"] = np.log(df["sales"])
lag_cols = [f"lag_{k}" for k in range(1, L + 1)]
for k in range(1, L + 1):
    df[f"lag_{k}"] = df["dlvix"].shift(k)

d = df.dropna(subset=["lsales"] + lag_cols).reset_index(drop=True)

X = sm.add_constant(d[lag_cols])
y = d["lsales"]
res = sm.OLS(y, X).fit()

N = int(res.nobs)
hac = res.get_robustcov_results(cov_type="HAC", maxlags=L, use_correction=False)
b = np.asarray(hac.params, dtype=float)
V = np.asarray(hac.cov_params(), dtype=float) * N / (N - (L + 1))

c = np.zeros(L + 1)
c[1:] = 1.0
cum_est = float(c @ b)
cum_se = float(np.sqrt(c @ V @ c))

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {"term": "cumulative_response", "estimate": cum_est, "se": cum_se, "n_obs": N},
        {"term": "lag_1", "estimate": float(b[1]), "se": float(np.sqrt(V[1, 1])), "n_obs": N},
        {"term": "lag_15", "estimate": float(b[15]), "se": float(np.sqrt(V[15, 15])), "n_obs": N},
    ],
    "method_metadata": {
        "estimator": "OLS regression of log(sales) on intercept and 15 lags of first difference of log(vix)",
        "vcov": "Newey-West HAC, maxlags=15, Bartlett weights 1-j/16, scaled by N/(N-16)",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
