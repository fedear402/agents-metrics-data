import json
import numpy as np
import pandas as pd

data = pd.read_csv("input.csv")
data["date"] = pd.to_datetime(data["date"])
data = data.sort_values("date").reset_index(drop=True)

data["vix_change"] = np.log(data["vix"]).diff()
data["log_sales"] = np.log(data["sales"])

max_lag = 15
for k in range(1, max_lag + 1):
    data[f"lag_{k}"] = data["vix_change"].shift(k)

lag_cols = [f"lag_{k}" for k in range(1, max_lag + 1)]
sample = data.dropna(subset=["log_sales"] + lag_cols).reset_index(drop=True)

N = len(sample)
X = np.column_stack([np.ones(N)] + [sample[c].to_numpy() for c in lag_cols])
y = sample["log_sales"].to_numpy()

coefficients = np.linalg.lstsq(X, y, rcond=None)[0]
residuals = y - X @ coefficients

scores = X * residuals[:, None]
hac_lags = max_lag
meat = scores.T @ scores
for j in range(1, hac_lags + 1):
    weight = 1 - j / (hac_lags + 1)
    lag_product = scores[j:].T @ scores[:-j]
    meat += weight * (lag_product + lag_product.T)

bread = np.linalg.inv(X.T @ X)
p = X.shape[1]
covariance = (N / (N - p)) * bread @ meat @ bread

contrast = np.zeros(p)
contrast[1:] = 1.0
cumulative = float(contrast @ coefficients)
cumulative_se = float(np.sqrt(contrast @ covariance @ contrast))

output = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {"term": "cumulative_response", "estimate": cumulative, "se": cumulative_se, "n_obs": N},
        {"term": "lag_1", "estimate": float(coefficients[1]), "se": float(np.sqrt(covariance[1, 1])), "n_obs": N},
        {"term": "lag_15", "estimate": float(coefficients[15]), "se": float(np.sqrt(covariance[15, 15])), "n_obs": N},
    ],
    "method_metadata": {
        "estimator": "OLS regression of log(sales) on intercept and 15 lags of first-differenced log(vix)",
        "vcov": "Newey-West HAC, max lag 15, Bartlett weights, scaled by N/(N-16)",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
