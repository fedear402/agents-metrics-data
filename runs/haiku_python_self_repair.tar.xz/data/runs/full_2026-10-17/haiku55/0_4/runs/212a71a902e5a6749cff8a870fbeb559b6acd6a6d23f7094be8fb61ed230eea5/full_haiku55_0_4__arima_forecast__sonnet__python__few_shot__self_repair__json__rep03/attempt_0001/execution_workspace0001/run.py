import json

import numpy as np
import pandas as pd
from statsmodels.tsa.arima.model import ARIMA

df = pd.read_csv("./input.csv")
y = df["y"].astype(float).reset_index(drop=True)

res = ARIMA(y, order=(1, 1, 1), trend="n").fit()
fc = res.get_forecast(steps=1)

mean = float(np.asarray(fc.predicted_mean).ravel()[0])
var = float(np.asarray(fc.var_pred_mean).ravel()[0])
se = float(np.sqrt(var))
ci = np.asarray(fc.conf_int(alpha=0.05)).ravel()
lower, upper = float(ci[0]), float(ci[1])
n_obs = int(res.nobs)

out = {
    "task_id": "arima_forecast",
    "platform": "python",
    "estimates": [
        {"term": "forecast", "estimate": mean, "se": se, "n_obs": n_obs},
        {"term": "lower_95", "estimate": lower, "se": None, "n_obs": n_obs},
        {"term": "upper_95", "estimate": upper, "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "ARIMA(1,1,1) without constant, maximum likelihood",
        "vcov": "statespace MLE (forecast variance from Kalman filter)",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(out, f)
