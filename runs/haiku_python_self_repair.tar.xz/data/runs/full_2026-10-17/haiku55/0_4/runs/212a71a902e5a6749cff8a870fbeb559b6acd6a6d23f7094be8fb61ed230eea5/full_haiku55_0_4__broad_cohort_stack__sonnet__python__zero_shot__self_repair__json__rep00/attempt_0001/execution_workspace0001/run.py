import json

import numpy as np
import pandas as pd


df = pd.read_csv("input.csv")[["id", "time", "g", "y"]]


def cohort_estimate(c):
    lo, hi = c - 2, c + 2
    window = df[(df["time"] >= lo) & (df["time"] <= hi)]
    eligible = window[(window["g"] == c) | (window["g"] == 0) | (window["g"] > c + 2)]

    times_per_unit = eligible.groupby("id")["time"].nunique()
    full_ids = times_per_unit[times_per_unit == (hi - lo + 1)].index
    sub = eligible[eligible["id"].isin(full_ids)].copy()

    sub["did"] = ((sub["g"] == c) & (sub["time"] >= c)).astype(float)
    n_treated = int(sub.loc[sub["g"] == c, "id"].nunique())

    units = np.sort(sub["id"].unique())
    times = np.sort(sub["time"].unique())
    unit_idx = np.searchsorted(units, sub["id"].to_numpy())
    time_idx = np.searchsorted(times, sub["time"].to_numpy())

    n = len(sub)
    unit_dummies = np.zeros((n, len(units)))
    unit_dummies[np.arange(n), unit_idx] = 1.0
    time_dummies = np.zeros((n, len(times)))
    time_dummies[np.arange(n), time_idx] = 1.0

    X = np.column_stack([
        np.ones(n),
        sub["did"].to_numpy(),
        unit_dummies[:, 1:],
        time_dummies[:, 1:],
    ])
    y = sub["y"].to_numpy(dtype=float)

    beta = np.linalg.lstsq(X, y, rcond=None)[0]
    return float(beta[1]), n, n_treated


results = {}
for c in (3, 5, 7):
    results[c] = cohort_estimate(c)

att_g3, n_g3, w_g3 = results[3]
att_g5, n_g5, w_g5 = results[5]
att_g7, n_g7, w_g7 = results[7]

weights = np.array([w_g3, w_g5, w_g7], dtype=float)
atts = np.array([att_g3, att_g5, att_g7], dtype=float)
att_weighted = float(np.sum(weights * atts) / np.sum(weights))
n_weighted = n_g3 + n_g5 + n_g7


def fmt(x):
    return format(x, ".15g")


output = {
    "task_id": "broad_cohort_stack",
    "platform": "python",
    "estimates": [
        {"term": "att_g3", "estimate": fmt(att_g3), "se": None, "n_obs": n_g3},
        {"term": "att_g5", "estimate": fmt(att_g5), "se": None, "n_obs": n_g5},
        {"term": "att_g7", "estimate": fmt(att_g7), "se": None, "n_obs": n_g7},
        {"term": "att_weighted", "estimate": fmt(att_weighted), "se": None, "n_obs": n_weighted},
    ],
    "method_metadata": {},
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(output, f, indent=2)
