import json

import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS

hh = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

d = hh[hh["recipient"] == 0].copy()
d["not_elig"] = 1 - d["eligible"]
d["dose_0"] = d["dose"] * d["not_elig"]
d["dose_1"] = d["dose"] * d["eligible"]
d["base_0"] = d["baseline"] * d["not_elig"]
d["base_1"] = d["baseline"] * d["eligible"]
d["inst_0"] = d["instrument"] * d["not_elig"]
d["inst_1"] = d["instrument"] * d["eligible"]

exog = d[["not_elig", "eligible", "base_0", "base_1"]]
endog = d[["dose_0", "dose_1"]]
excluded = d[["inst_0", "inst_1"]]

fit = IV2SLS(d["outcome"], exog, endog, excluded, weights=d["weight"]).fit()

inel = d[d["eligible"] == 0]
el = d[d["eligible"] == 1]
mean_dose_0 = float(np.average(inel["dose"], weights=inel["weight"]))
mean_dose_1 = float(np.average(el["dose"], weights=el["weight"]))

ineligible_effect = float(fit.params["dose_0"]) * mean_dose_0
eligible_nonrecipient_effect = float(fit.params["dose_1"]) * mean_dose_1

pop = census.set_index("eligible")["nonrecipient_population"]
pop_weights = [float(pop.loc[0]), float(pop.loc[1])]
population_effect = float(
    np.average([ineligible_effect, eligible_nonrecipient_effect], weights=pop_weights)
)

n_obs = int(len(d))
n_ineligible = int(len(inel))
n_eligible = int(len(el))

estimates = [
    {"term": "ineligible_effect", "estimate": ineligible_effect, "se": None, "n_obs": n_obs},
    {"term": "eligible_nonrecipient_effect", "estimate": eligible_nonrecipient_effect, "se": None, "n_obs": n_obs},
    {"term": "population_effect", "estimate": population_effect, "se": None, "n_obs": n_obs},
]

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "weighted 2SLS via linearmodels IV2SLS",
        "sample": "households with recipient == 0, both village treatment statuses",
        "regression_weight": "weight",
        "endogenous": ["dose*(1-eligible)", "dose*eligible"],
        "exogenous": ["1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"],
        "excluded_instruments": ["instrument*(1-eligible)", "instrument*eligible"],
        "counterfactual": "dose set to zero for every retained household",
        "group_effect": "fitted dose slope times household-weighted mean dose in group",
        "aggregation_weights": "nonrecipient_population from census.csv",
        "attribution_convention": "zero-dose counterfactual is a stated synthetic convention",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "n_ineligible": n_ineligible,
        "n_eligible": n_eligible,
        "mean_dose_ineligible": mean_dose_0,
        "mean_dose_eligible": mean_dose_1,
        "dose_slope_ineligible": float(fit.params["dose_0"]),
        "dose_slope_eligible": float(fit.params["dose_1"]),
        "census_population_ineligible": pop_weights[0],
        "census_population_eligible": pop_weights[1],
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
