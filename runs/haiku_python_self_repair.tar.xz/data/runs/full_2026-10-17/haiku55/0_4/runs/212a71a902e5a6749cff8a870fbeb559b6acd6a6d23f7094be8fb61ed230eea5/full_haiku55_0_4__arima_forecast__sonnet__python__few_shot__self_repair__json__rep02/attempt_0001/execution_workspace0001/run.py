import json

import numpy as np
import pandas as pd
from statsmodels.tsa.arima.model import ARIMA

df = pd.read_csv("./input.csv").sort_values("t")
y = df["y"].astype(float).reset_index(drop=True)

res = ARIMA(y, order=(1, 1, 1), trend="n").fit()
fc = res.get_forecast(steps=1)

mean = float(np.ravel(fc.predicted_mean)[0])
ci = np.asarray(fc.conf_int(alpha=0.05))[0]
lower = float(ci[0])
upper = float(ci[1])
se = float(np.sqrt(np.ravel(fc.var_pred_mean)[0]))
n_obs = int(res.nobs)

out = {
    "task_id": "arima_forecast",
    "platform": "python",
    "estimates": [
        {"term": "forecast", "estimate": mean, "se": se, "n_obs": n_obs},
        {"term": "lower_95", "estimate": lower, "se": None, "n_obs": n_obs},
        {"term": "upper_95", "estimate": upper, "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "ARIMA(1,1,1) by maximum likelihood, no constant or drift",
        "vcov": "mle_default",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(out, f)
