import json

import pandas as pd
from scipy import stats
import statsmodels.formula.api as smf
from statsmodels.stats.anova import anova_lm

df = pd.read_csv("./input.csv")
df = df.dropna(subset=["group", "y"])
df["group"] = df["group"].astype("category")

n_obs = int(len(df))

model = smf.ols("y ~ C(group)", data=df).fit()
anova = anova_lm(model, typ=2)

f_stat = float(anova.loc["C(group)", "F"])
df_num = float(anova.loc["C(group)", "df"])
df_den = float(anova.loc["Residual", "df"])
p_value = float(anova.loc["C(group)", "PR(>F)"])

if df_num <= 0 or df_den <= 0 or pd.isna(f_stat):
    f_stat_out = float("nan")
    p_value_out = float("nan")
else:
    f_stat_out = f_stat
    p_value_out = p_value

result = {
    "task_id": "anova_oneway",
    "platform": "python",
    "estimates": [
        {"term": "F", "estimate": f_stat_out, "se": None, "n_obs": n_obs},
        {"term": "df_num", "estimate": df_num, "se": None, "n_obs": n_obs},
        {"term": "df_den", "estimate": df_den, "se": None, "n_obs": n_obs},
        {"term": "p_value", "estimate": p_value_out, "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "one-way ANOVA (OLS with categorical group, Type II sums of squares)",
        "vcov": "nonrobust",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
