import json

import numpy as np
import pandas as pd
import statsmodels.api as sm

L = 15

df = pd.read_csv("input.csv")
df["date"] = pd.to_datetime(df["date"])
df = df.sort_values("date").reset_index(drop=True)

df["lsales"] = np.log(df["sales"])
df["dlvix"] = np.log(df["vix"]).diff()
lag_cols = [f"lag_{k}" for k in range(1, L + 1)]
for k in range(1, L + 1):
    df[f"lag_{k}"] = df["dlvix"].shift(k)

data = df.dropna(subset=["lsales"] + lag_cols).reset_index(drop=True)
N = len(data)

X = sm.add_constant(data[lag_cols])
y = data["lsales"]

res = sm.OLS(y, X).fit(
    cov_type="HAC",
    cov_kwds={"maxlags": L, "kernel": "bartlett", "use_correction": False},
)

scale = N / (N - (L + 1))
b = res.params.values
V = res.cov_params().values * scale

c = np.zeros(len(b))
c[1:] = 1.0
cum_est = float(c @ b)
cum_se = float(np.sqrt(c @ V @ c))

lag1_est = float(b[1])
lag1_se = float(np.sqrt(V[1, 1]))
lag15_est = float(b[L])
lag15_se = float(np.sqrt(V[L, L]))

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {"term": "cumulative_response", "estimate": cum_est, "se": cum_se, "n_obs": int(N)},
        {"term": "lag_1", "estimate": lag1_est, "se": lag1_se, "n_obs": int(N)},
        {"term": "lag_15", "estimate": lag15_est, "se": lag15_se, "n_obs": int(N)},
    ],
    "method_metadata": {
        "estimator": "OLS of log(sales) on intercept and 15 lags of first difference of log(vix)",
        "vcov": "Newey-West HAC, maxlags=15, Bartlett weights 1-j/16, scaled by N/(N-16)",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
