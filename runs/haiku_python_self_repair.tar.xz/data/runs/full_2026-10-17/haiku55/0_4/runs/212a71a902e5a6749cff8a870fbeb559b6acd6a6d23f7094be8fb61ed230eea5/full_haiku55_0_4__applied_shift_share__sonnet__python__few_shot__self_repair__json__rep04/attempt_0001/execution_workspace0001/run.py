import json

import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")

regions = (
    df.groupby("region_id")
    .agg(region_weight=("region_weight", "first"), x=("x", "first"), y=("y", "first"))
    .sort_index()
)
e = regions["region_weight"].to_numpy(dtype=float)
e = e / e.sum()
x = regions["x"].to_numpy(dtype=float)
y = regions["y"].to_numpy(dtype=float)

industries = df.groupby("industry_id")["shock"].first().sort_index()
shock_n = industries.to_numpy(dtype=float)

S = (
    df.pivot_table(index="region_id", columns="industry_id", values="share", aggfunc="first")
    .reindex(index=regions.index, columns=industries.index)
    .fillna(0.0)
    .to_numpy(dtype=float)
)

z = S @ shock_n

def wcenter(v):
    return v - e @ v

y0, x0, z0 = wcenter(y), wcenter(x), wcenter(z)

s = e @ S

def aggregate(v0):
    return (S.T @ (e * v0)) / s

ybar = aggregate(y0)
xbar = aggregate(x0)
zbar = aggregate(z0)

def shock_iv(dep, endo, inst, w):
    N = len(dep)
    X = np.column_stack([np.ones(N), endo])
    Z = np.column_stack([np.ones(N), inst])
    cross = Z.T @ (w[:, None] * X)
    beta = np.linalg.solve(cross, Z.T @ (w * dep))
    resid = dep - X @ beta
    scores = Z * (w * resid)[:, None]
    inv = np.linalg.inv(cross)
    hc1 = N / (N - 2)
    cov = hc1 * inv @ (scores.T @ scores) @ inv.T
    return float(beta[1]), float(np.sqrt(cov[1, 1]))

effect_point = float(np.sum(e * z0 * y0) / np.sum(e * z0 * x0))
_, effect_se = shock_iv(ybar, xbar, shock_n, s)

first_stage_point = float(np.sum(e * z0 * x0) / np.sum(e * z0 ** 2))
_, first_stage_se = shock_iv(xbar, zbar, shock_n, s)

effective_shocks = float(1.0 / np.sum(s ** 2))

n_industries = int(len(shock_n))

output = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": effect_point, "se": effect_se, "n_obs": n_industries},
        {"term": "first_stage", "estimate": first_stage_point, "se": first_stage_se, "n_obs": n_industries},
        {"term": "effective_shocks", "estimate": effective_shocks, "se": None, "n_obs": n_industries},
    ],
    "method_metadata": {
        "estimator": "Weighted 2SLS of y on x instrumented by shift-share z, regional weights e_r; first stage by weighted OLS",
        "vcov": "Borusyak-Hull-Jaravel shock-level weighted IV, HC1 robust (N/(N-2)), no clustering",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
