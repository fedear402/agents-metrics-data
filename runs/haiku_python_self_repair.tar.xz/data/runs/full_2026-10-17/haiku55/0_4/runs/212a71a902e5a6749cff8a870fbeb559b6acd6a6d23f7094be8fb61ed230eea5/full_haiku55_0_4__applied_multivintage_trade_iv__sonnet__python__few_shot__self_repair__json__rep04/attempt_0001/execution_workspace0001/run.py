import json

import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS

BASE, EARLY = "base", "early"
AREA0 = "0"

cw = pd.read_csv("crosswalk.csv", dtype=str)
trade = pd.read_csv("trade.csv", dtype={"code": str})
areas = pd.read_csv("areas.csv", dtype={"area": str, "vintage": str})
emp = pd.read_csv("employment.csv", dtype={"area": str, "vintage": str, "industry": str})
out = pd.read_csv("outcomes.csv", dtype={"area": str})

trade = trade.merge(cw[["code", "industry"]].drop_duplicates(), on="code", how="left")

industries = sorted(cw["industry"].unique())
periods = sorted(areas["period"].unique())
period_index = {p: i for i, p in enumerate(periods)}
area_list = list(dict.fromkeys(areas["area"]))

keys = pd.MultiIndex.from_frame(areas[["area", "period", "vintage"]].drop_duplicates())

emp_w = (
    emp.groupby(["area", "period", "vintage", "industry"])["employment"]
    .sum()
    .unstack("industry")
    .reindex(columns=industries)
    .reindex(keys, fill_value=0.0)
    .fillna(0.0)
)

tot = (
    areas.drop_duplicates(["area", "period", "vintage"])
    .set_index(["area", "period", "vintage"])["total_employment"]
    .astype(float)
)

nat = emp_w.groupby(level=["period", "vintage"]).sum()


def exposure(vintage, change_col):
    values = {}
    for p in periods:
        t = trade[trade["period"] == p].set_index("industry")
        price = float(t["price_index"].iloc[0])
        years = float(t["years"].iloc[0])
        change = t[change_col].astype(float).reindex(industries)
        national = nat.loc[(p, vintage), industries].astype(float)
        shock = change / national / (price / 100.0) / 1000.0 * (10.0 / years)
        for a in area_list:
            e = emp_w.loc[(a, p, vintage), industries].astype(float)
            values[(a, p)] = float((e / tot.loc[(a, p, vintage)] * shock).sum())
    return pd.Series(values)


x_series = exposure(BASE, "us_change")
z_series = exposure(EARLY, "other_change")

df = out.copy()
idx = pd.MultiIndex.from_frame(df[["area", "period"]])
df["x"] = x_series.reindex(idx).values
df["z"] = z_series.reindex(idx).values

pop = (
    areas[areas["vintage"] == BASE]
    .drop_duplicates(["area", "period"])
    .set_index(["area", "period"])["population"]
    .astype(float)
)
df["w"] = pop.reindex(idx).values
df["period_idx"] = df["period"].map(period_index).astype(float)
df["control"] = df["control"].astype(float)
df["change_pp"] = df["change_pp"].astype(float)

n_obs = int(len(df))

exog = pd.DataFrame(
    {"const": 1.0, "period": df["period_idx"], "control": df["control"]},
    index=df.index,
)
model = IV2SLS(
    df["change_pp"],
    exog,
    df[["x"]],
    df[["z"]],
    weights=df["w"],
).fit()

iv_slope = float(model.params["x"])
exposure_area0_period0 = float(x_series[(AREA0, periods[0])])
exposure_area0_period1 = float(x_series[(AREA0, periods[1])])
instrument_area0_period0 = float(z_series[(AREA0, periods[0])])

estimates = [
    {"term": "iv_slope", "estimate": iv_slope, "se": None, "n_obs": n_obs},
    {"term": "exposure_area0_period0", "estimate": exposure_area0_period0, "se": None, "n_obs": n_obs},
    {"term": "exposure_area0_period1", "estimate": exposure_area0_period1, "se": None, "n_obs": n_obs},
    {"term": "instrument_area0_period0", "estimate": instrument_area0_period0, "se": None, "n_obs": n_obs},
]

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "weighted 2SLS (linearmodels IV2SLS)",
        "dependent": "change_pp",
        "exogenous": ["intercept", "period", "control"],
        "endogenous": ["x"],
        "instruments": ["z"],
        "weights": "base-vintage population",
        "industries": industries,
        "periods": [str(p) for p in periods],
    },
    "diagnostics": {
        "n_obs": n_obs,
        "n_industries": int(len(industries)),
        "n_areas": int(len(area_list)),
        "n_periods": int(len(periods)),
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
