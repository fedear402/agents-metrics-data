import json
import numpy as np
import pandas as pd

data = pd.read_csv("input.csv")
data["date"] = pd.to_datetime(data["date"])
data = data.sort_values("date").reset_index(drop=True)

data["vix_change"] = np.log(data["vix"]).diff()
data["log_sales"] = np.log(data["sales"])

max_lag = 15
lag_cols = []
for k in range(1, max_lag + 1):
    col = f"lag_{k}"
    data[col] = data["vix_change"].shift(k)
    lag_cols.append(col)

sample = data.dropna(subset=["log_sales"] + lag_cols)
N = len(sample)

X = np.column_stack([np.ones(N), sample[lag_cols].to_numpy()])
y = sample["log_sales"].to_numpy()

XtX_inv = np.linalg.inv(X.T @ X)
coef = XtX_inv @ X.T @ y
resid = y - X @ coef

scores = X * resid[:, None]
meat = scores.T @ scores
for j in range(1, max_lag + 1):
    weight = 1 - j / (max_lag + 1)
    cross = scores[j:].T @ scores[:-j]
    meat += weight * (cross + cross.T)

p = X.shape[1]
cov = (N / (N - p)) * XtX_inv @ meat @ XtX_inv

contrast = np.zeros(p)
contrast[1:] = 1.0
cumulative = float(contrast @ coef)
cumulative_se = float(np.sqrt(contrast @ cov @ contrast))

output = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {
            "term": "cumulative_response",
            "estimate": cumulative,
            "se": cumulative_se,
            "n_obs": int(N),
        },
        {
            "term": "lag_1",
            "estimate": float(coef[1]),
            "se": float(np.sqrt(cov[1, 1])),
            "n_obs": int(N),
        },
        {
            "term": "lag_15",
            "estimate": float(coef[15]),
            "se": float(np.sqrt(cov[15, 15])),
            "n_obs": int(N),
        },
    ],
    "method_metadata": {
        "estimator": "OLS regression of log(sales) on intercept and 15 lags of first-differenced log(vix)",
        "vcov": "Newey-West HAC, max lag 15, Bartlett weights 1-j/16, scaled by N/(N-16)",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
