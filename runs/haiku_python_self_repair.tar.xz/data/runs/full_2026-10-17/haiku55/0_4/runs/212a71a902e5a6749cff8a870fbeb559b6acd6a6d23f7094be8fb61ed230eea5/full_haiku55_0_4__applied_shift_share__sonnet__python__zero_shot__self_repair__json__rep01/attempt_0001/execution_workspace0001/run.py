import json

import numpy as np
import pandas as pd


def iv_hc1(y, X, Z, w):
    A = Z.T @ (X * w[:, None])
    b = np.linalg.solve(A, Z.T @ (w * y))
    u = y - X @ b
    n = len(y)
    S = Z * (w * u)[:, None]
    meat = S.T @ S
    Ainv = np.linalg.inv(A)
    V = Ainv @ meat @ Ainv.T * n / (n - 2)
    return b, np.sqrt(np.diag(V))


df = pd.read_csv("input.csv")
df["sz"] = df["share"] * df["shock"]

reg = df.groupby("region_id").agg(
    region_weight=("region_weight", "first"),
    x=("x", "first"),
    y=("y", "first"),
    z=("sz", "sum"),
).reset_index()

reg["e"] = reg["region_weight"] / reg["region_weight"].sum()
e = reg["e"].to_numpy()
for v in ["y", "x", "z"]:
    reg[v + "0"] = reg[v] - np.sum(e * reg[v].to_numpy())

pairs = df.merge(reg[["region_id", "e", "y0", "x0", "z0"]], on="region_id")
pairs["w"] = pairs["e"] * pairs["share"]
for v in ["y0", "x0", "z0"]:
    pairs["w_" + v] = pairs["w"] * pairs[v]

agg = pairs.groupby("industry_id").agg(
    s=("w", "sum"),
    shock=("shock", "first"),
    wy=("w_y0", "sum"),
    wx=("w_x0", "sum"),
    wz=("w_z0", "sum"),
)
s = agg["s"].to_numpy()
shock = agg["shock"].to_numpy()
ybar = agg["wy"].to_numpy() / s
xbar = agg["wx"].to_numpy() / s
zbar = agg["wz"].to_numpy() / s
N = len(agg)

ones_r = np.ones(len(reg))
X_r = np.column_stack([ones_r, reg["x"].to_numpy()])
Z_r = np.column_stack([ones_r, reg["z"].to_numpy()])
b_reg, _ = iv_hc1(reg["y"].to_numpy(), X_r, Z_r, e)
effect_est = b_reg[1]

ones_n = np.ones(N)
X_n = np.column_stack([ones_n, xbar])
Z_n = np.column_stack([ones_n, shock])
b_eff, se_eff = iv_hc1(ybar, X_n, Z_n, s)

Xf_r = np.column_stack([ones_r, reg["z"].to_numpy()])
b_fs_reg, _ = iv_hc1(reg["x"].to_numpy(), Xf_r, Xf_r, e)
first_stage_est = b_fs_reg[1]

Xf_n = np.column_stack([ones_n, zbar])
b_fs, se_fs = iv_hc1(xbar, Xf_n, Z_n, s)

effective_shocks = 1.0 / np.sum(s ** 2)

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": float(effect_est), "se": float(se_eff[1]), "n_obs": int(N)},
        {"term": "first_stage", "estimate": float(first_stage_est), "se": float(se_fs[1]), "n_obs": int(N)},
        {"term": "effective_shocks", "estimate": float(effective_shocks), "se": None, "n_obs": int(N)},
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS shift-share with shock-level (BHJ) aggregation",
        "vcov": "shock-level heteroskedasticity-robust HC1, N/(N-2) multiplier, analytic weights, no clustering",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
