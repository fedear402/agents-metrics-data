import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("input.csv")
X = sm.add_constant(df[["x", "z"]].astype(float), has_constant="add")
y = df["y"].astype(int).to_numpy()
fit = sm.MNLogit(y, X).fit(method="newton", maxiter=500, disp=False, tol=1e-10)

params = fit.params
bse = fit.bse
n = len(df)

x_cat1 = float(params.iloc[1, 0])
z_cat1 = float(params.iloc[2, 0])
x_cat2 = float(params.iloc[1, 1])
z_cat2 = float(params.iloc[2, 1])
se_x_cat1 = float(bse.iloc[1, 0])
se_z_cat1 = float(bse.iloc[2, 0])
se_x_cat2 = float(bse.iloc[1, 1])
se_z_cat2 = float(bse.iloc[2, 1])

a1 = float(params.iloc[0, 0])
a2 = float(params.iloc[0, 1])
denom = 1.0 + np.exp(a1) + np.exp(a2)
p0 = 1.0 / denom
p1 = np.exp(a1) / denom
p2 = np.exp(a2) / denom
prob_cat2_zero = float(p2)

grad = np.zeros(fit.cov_params().shape[0])
grad[0] = -p2 * p1
grad[3] = p2 * (1.0 - p2)
V = np.asarray(fit.cov_params(), dtype=float)
se_prob = float(np.sqrt(max(grad @ V @ grad, 0.0)))

result = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": [
        {"term": "x_cat1", "estimate": x_cat1, "se": se_x_cat1, "n_obs": int(n)},
        {"term": "z_cat1", "estimate": z_cat1, "se": se_z_cat1, "n_obs": int(n)},
        {"term": "x_cat2", "estimate": x_cat2, "se": se_x_cat2, "n_obs": int(n)},
        {"term": "z_cat2", "estimate": z_cat2, "se": se_z_cat2, "n_obs": int(n)},
        {"term": "prob_cat2_zero", "estimate": prob_cat2_zero, "se": se_prob, "n_obs": int(n)},
    ],
    "method_metadata": {
        "estimator": "multinomial logit maximum likelihood, base outcome 0",
        "vcov": "observed information (inverse Hessian)",
    },
    "diagnostics": {
        "converged": bool(fit.mle_retvals.get("converged", True)),
        "log_likelihood": float(fit.llf),
    },
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
