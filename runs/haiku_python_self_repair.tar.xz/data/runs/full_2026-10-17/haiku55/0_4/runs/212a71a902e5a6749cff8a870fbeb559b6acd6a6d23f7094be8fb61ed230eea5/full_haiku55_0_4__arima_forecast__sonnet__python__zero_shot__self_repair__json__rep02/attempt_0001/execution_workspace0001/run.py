import json

import pandas as pd
from statsmodels.tsa.arima.model import ARIMA

df = pd.read_csv("./input.csv")
if "t" in df.columns:
    df = df.sort_values("t").reset_index(drop=True)
y = df["y"].astype(float).reset_index(drop=True)
n_obs = int(y.shape[0])

last_t = int(df["t"].max()) if "t" in df.columns else n_obs
steps = 251 - last_t
if steps < 1:
    raise ValueError("Target t=251 is not after the last observed t.")

model = ARIMA(y, order=(1, 1, 1), trend="n")
res = model.fit(cov_type="opg")

fc = res.get_forecast(steps=steps)
frame = fc.summary_frame(alpha=0.05)
row = frame.iloc[-1]

forecast = float(row["mean"])
se = float(row["mean_se"])
lower = float(row["mean_ci_lower"])
upper = float(row["mean_ci_upper"])

converged = bool(res.mle_retvals.get("converged", True)) if res.mle_retvals else True

result = {
    "task_id": "arima_forecast",
    "platform": "python",
    "estimates": [
        {"term": "forecast", "estimate": forecast, "se": se, "n_obs": n_obs},
        {"term": "lower_95", "estimate": lower, "se": None, "n_obs": n_obs},
        {"term": "upper_95", "estimate": upper, "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "ARIMA(1,1,1) maximum likelihood, no constant or drift (statsmodels ARIMA, trend='n')",
        "vcov": "outer product of gradients (cov_type='opg')",
    },
    "diagnostics": {
        "aic": float(res.aic),
        "bic": float(res.bic),
        "loglikelihood": float(res.llf),
        "ar1": float(res.params.get("ar.L1", float("nan"))),
        "ma1": float(res.params.get("ma.L1", float("nan"))),
        "sigma2": float(res.params.get("sigma2", float("nan"))),
        "converged": converged,
        "forecast_steps": int(steps),
        "last_observed_t": last_t,
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
