import json

import numpy as np
import pandas as pd

MAXLAG = 15

data = pd.read_csv("input.csv")
data["date"] = pd.to_datetime(data["date"])
data = data.sort_values("date").reset_index(drop=True)
data["vix_change"] = np.log(data["vix"]).diff()
data["log_sales"] = np.log(data["sales"])
lag_cols = [f"lag_{k}" for k in range(1, MAXLAG + 1)]
for k, col in enumerate(lag_cols, start=1):
    data[col] = data["vix_change"].shift(k)

sample = data.dropna(subset=["log_sales"] + lag_cols)
N = len(sample)
X = np.column_stack([np.ones(N)] + [sample[col].to_numpy() for col in lag_cols])
y = sample["log_sales"].to_numpy()
beta = np.linalg.lstsq(X, y, rcond=None)[0]
resid = y - X @ beta

scores = X * resid[:, None]
meat = scores.T @ scores
for j in range(1, MAXLAG + 1):
    weight = 1 - j / (MAXLAG + 1)
    gamma = scores[j:].T @ scores[:-j]
    meat += weight * (gamma + gamma.T)

bread = np.linalg.inv(X.T @ X)
p = X.shape[1]
V = (N / (N - p)) * bread @ meat @ bread

contrast = np.zeros(p)
contrast[1:] = 1.0
cumulative = float(contrast @ beta)
cumulative_se = float(np.sqrt(contrast @ V @ contrast))

output = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {
            "term": "cumulative_response",
            "estimate": cumulative,
            "se": cumulative_se,
            "n_obs": int(N),
        },
        {
            "term": "lag_1",
            "estimate": float(beta[1]),
            "se": float(np.sqrt(V[1, 1])),
            "n_obs": int(N),
        },
        {
            "term": "lag_15",
            "estimate": float(beta[MAXLAG]),
            "se": float(np.sqrt(V[MAXLAG, MAXLAG])),
            "n_obs": int(N),
        },
    ],
    "method_metadata": {
        "estimator": "OLS regression of log(sales) on intercept and 15 lags of log(vix) first differences",
        "vcov": "Newey-West HAC, Bartlett weights 1-j/16, maxlag 15, scaled by N/(N-16)",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
