import json

import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
score = df["score"].astype(float).to_numpy()
part = df["participated"].astype(float).to_numpy()
earn = df["earnings"].astype(float).to_numpy()

bw = 1.0
inside = np.abs(score) < bw
s = score[inside]
d = part[inside]
y = earn[inside]
w = 1.0 - np.abs(s)
n_obs = int(inside.sum())


def side_fit(mask):
    x = s[mask]
    ww = w[mask]
    yy = y[mask]
    dd = d[mask]
    X = np.column_stack([np.ones_like(x), x])
    H = np.linalg.inv(X.T @ (X * ww[:, None]))
    by = H @ (X.T @ (ww * yy))
    bd = H @ (X.T @ (ww * dd))
    ey = yy - X @ by
    ed = dd - X @ bd
    meat_yy = (X * (ww**2 * ey**2)[:, None]).T @ X
    meat_dd = (X * (ww**2 * ed**2)[:, None]).T @ X
    meat_yd = (X * (ww**2 * ey * ed)[:, None]).T @ X
    v_yy = (H @ meat_yy @ H)[0, 0]
    v_dd = (H @ meat_dd @ H)[0, 0]
    c_yd = (H @ meat_yd @ H)[0, 0]
    return by[0], bd[0], v_yy, v_dd, c_yd


yR, dR, vyyR, vddR, cR = side_fit(s >= 0)
yL, dL, vyyL, vddL, cL = side_fit(s < 0)

tY = yR - yL
tD = dR - dL
V_yy = vyyR + vyyL
V_dd = vddR + vddL
C_yd = cR + cL

te = tY / tD
var_te = V_yy / tD**2 + tY**2 * V_dd / tD**4 - 2.0 * tY * C_yd / tD**3
se_te = float(np.sqrt(var_te))

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": float(te), "se": se_te, "n_obs": n_obs},
        {"term": "reduced_form", "estimate": float(tY), "se": float(np.sqrt(V_yy)), "n_obs": n_obs},
        {"term": "first_stage", "estimate": float(tD), "se": float(np.sqrt(V_dd)), "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "fuzzy regression discontinuity, local linear, triangular kernel, cutoff 0, bandwidth 1, separate slopes by side",
        "vcov": "HC0 heteroskedasticity-robust sandwich; delta method for ratio with joint covariance of reduced form and first stage",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
