import json

import numpy as np
import pandas as pd

df = pd.read_csv('input.csv')
cohorts = [3, 5, 7]
estimates = {}
diagnostics = {}
weighted_sum = 0.0
weight_total = 0
row_total = 0

for c in cohorts:
    window = df[(df['time'] >= c - 2) & (df['time'] <= c + 2)]
    eligible = window[(window['g'] == c) | (window['g'] == 0) | (window['g'] > c + 2)]
    times_per_unit = eligible.groupby('id')['time'].nunique()
    keep_ids = times_per_unit[times_per_unit == 5].index
    comp = eligible[eligible['id'].isin(keep_ids)].copy()
    comp['did'] = ((comp['g'] == c) & (comp['time'] >= c)).astype(float)

    units = np.sort(comp['id'].unique())
    times = np.sort(comp['time'].unique())
    columns = [np.ones(len(comp)), comp['did'].to_numpy(dtype=float)]
    for unit in units[1:]:
        columns.append((comp['id'].to_numpy() == unit).astype(float))
    for period in times[1:]:
        columns.append((comp['time'].to_numpy() == period).astype(float))
    design = np.column_stack(columns)
    if np.linalg.matrix_rank(design) != design.shape[1]:
        raise ValueError(f'Design matrix is rank deficient for cohort {c}')

    beta = np.linalg.lstsq(design, comp['y'].to_numpy(dtype=float), rcond=None)[0]
    att = float(beta[1])
    n_rows = int(len(comp))
    n_treated = int(comp.loc[comp['g'] == c, 'id'].nunique())

    estimates[c] = att
    row_total += n_rows
    weighted_sum += att * n_treated
    weight_total += n_treated
    diagnostics[f'cohort_{c}'] = {
        'retained_rows': n_rows,
        'retained_units': int(len(units)),
        'retained_treated_units': n_treated,
        'calendar_times': [int(t) for t in times],
    }

att_weighted = weighted_sum / weight_total

output = {
    'task_id': 'broad_cohort_stack',
    'platform': 'python',
    'estimates': [
        {'term': 'att_g3', 'estimate': float(estimates[3]), 'se': None,
         'n_obs': diagnostics['cohort_3']['retained_rows']},
        {'term': 'att_g5', 'estimate': float(estimates[5]), 'se': None,
         'n_obs': diagnostics['cohort_5']['retained_rows']},
        {'term': 'att_g7', 'estimate': float(estimates[7]), 'se': None,
         'n_obs': diagnostics['cohort_7']['retained_rows']},
        {'term': 'att_weighted', 'estimate': float(att_weighted), 'se': None,
         'n_obs': int(row_total)},
    ],
    'method_metadata': {
        'design': 'separate cohort-specific DiD regressions with unit and calendar-time fixed effects',
        'window': 'calendar times c-2 through c+2 for each cohort c',
        'eligibility': 'g equals c, g equals 0, or g greater than c+2',
        'balance': 'units observed at all five window times',
        'weighting': 'retained treated unit counts per cohort',
    },
    'diagnostics': diagnostics,
}

with open('result.json', 'w') as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
