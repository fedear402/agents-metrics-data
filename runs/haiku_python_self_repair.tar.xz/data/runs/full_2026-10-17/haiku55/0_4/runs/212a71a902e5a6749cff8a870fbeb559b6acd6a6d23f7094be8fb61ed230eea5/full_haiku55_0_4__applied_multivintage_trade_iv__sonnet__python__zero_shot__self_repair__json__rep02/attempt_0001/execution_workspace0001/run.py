import json

import numpy as np
import pandas as pd

crosswalk = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv")
areas = pd.read_csv("areas.csv")
employment = pd.read_csv("employment.csv")
outcomes = pd.read_csv("outcomes.csv")

trade = trade.merge(crosswalk, on="code", how="inner")
trade_ps = trade[["period", "industry", "us_change", "other_change", "price_index", "years"]]

industries = pd.DataFrame({"industry": sorted(crosswalk["industry"].unique())})
ap = outcomes[["area", "period"]].drop_duplicates().reset_index(drop=True)
grid = ap.merge(industries, how="cross")


def exposure(vintage, change_col):
    emp = (
        employment[employment["vintage"] == vintage]
        .groupby(["area", "period", "industry"], as_index=False)["employment"]
        .sum()
    )
    g = grid.merge(emp, on=["area", "period", "industry"], how="left")
    g["employment"] = g["employment"].fillna(0.0)

    nat = (
        g.groupby(["period", "industry"], as_index=False)["employment"]
        .sum()
        .rename(columns={"employment": "nat_employment"})
    )
    te = areas[areas["vintage"] == vintage][["area", "period", "total_employment"]]

    g = (
        g.merge(nat, on=["period", "industry"])
        .merge(te, on=["area", "period"])
        .merge(trade_ps, on=["period", "industry"])
    )
    g["term"] = (
        (g["employment"] / g["total_employment"])
        * (g[change_col] / g["nat_employment"])
        / (g["price_index"] / 100.0)
        / 1000.0
        * (10.0 / g["years"])
    )
    return (
        g.groupby(["area", "period"], as_index=False)["term"]
        .sum()
        .rename(columns={"term": "value"})
    )


x_df = exposure("base", "us_change").rename(columns={"value": "x"})
z_df = exposure("early", "other_change").rename(columns={"value": "z"})
pop = areas[areas["vintage"] == "base"][["area", "period", "population"]]

df = (
    outcomes.merge(x_df, on=["area", "period"])
    .merge(z_df, on=["area", "period"])
    .merge(pop, on=["area", "period"])
)

n = int(len(df))
y = df["change_pp"].to_numpy(dtype=float)
w = df["population"].to_numpy(dtype=float)
sw = np.sqrt(w)

const = np.ones(n)
exog = np.column_stack([const, df["period"].to_numpy(dtype=float), df["control"].to_numpy(dtype=float)])
X = np.column_stack([exog, df["x"].to_numpy(dtype=float)])
Z = np.column_stack([exog, df["z"].to_numpy(dtype=float)])

Xw = X * sw[:, None]
Zw = Z * sw[:, None]
yw = y * sw

PZX = Zw @ np.linalg.lstsq(Zw, Xw, rcond=None)[0]
PZy = Zw @ np.linalg.lstsq(Zw, yw, rcond=None)[0]
beta = np.linalg.solve(PZX.T @ Xw, PZX.T @ yw)
iv_slope = float(beta[-1])

area_str = df["area"].astype(str)
period_str = df["period"].astype(str)
row00 = df[(area_str == "0") & (period_str == "0")].iloc[0]
row01 = df[(area_str == "0") & (period_str == "1")].iloc[0]

exposure_area0_period0 = float(row00["x"])
exposure_area0_period1 = float(row01["x"])
instrument_area0_period0 = float(row00["z"])

estimates = [
    {"term": "iv_slope", "estimate": iv_slope, "se": None, "n_obs": n},
    {"term": "exposure_area0_period0", "estimate": exposure_area0_period0, "se": None, "n_obs": n},
    {"term": "exposure_area0_period1", "estimate": exposure_area0_period1, "se": None, "n_obs": n},
    {"term": "instrument_area0_period0", "estimate": instrument_area0_period0, "se": None, "n_obs": n},
]

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "weighted_2sls",
        "dependent": "change_pp",
        "endogenous": ["x"],
        "instruments": ["z"],
        "exogenous": ["intercept", "period", "control"],
        "weight": "base_population",
        "n_obs": n,
    },
    "diagnostics": {
        "n_areas": int(df["area"].nunique()),
        "n_periods": int(df["period"].nunique()),
        "n_industries": int(len(industries)),
        "weighted_sum_population": float(w.sum()),
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
