import json

import numpy as np
import pandas as pd
import statsmodels.api as sm

LAGS = 15

df = pd.read_csv("input.csv")
df["date"] = pd.to_datetime(df["date"])
df = df.sort_values("date").reset_index(drop=True)

df["dlvix"] = np.log(df["vix"]).diff()
df["lsales"] = np.log(df["sales"])
lag_cols = [f"lag_{k}" for k in range(1, LAGS + 1)]
for k in range(1, LAGS + 1):
    df[f"lag_{k}"] = df["dlvix"].shift(k)

d = df.dropna(subset=["lsales"] + lag_cols).reset_index(drop=True)
X = sm.add_constant(d[lag_cols])
y = d["lsales"]
N = len(d)

res = sm.OLS(y, X).fit(cov_type="HAC", cov_kwds={"maxlags": LAGS, "use_correction": False})
V = np.asarray(res.cov_params()) * N / (N - (LAGS + 1))
b = np.asarray(res.params)

c = np.zeros(LAGS + 1)
c[1:] = 1.0
cum_est = float(c @ b)
cum_se = float(np.sqrt(c @ V @ c))

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {"term": "cumulative_response", "estimate": cum_est, "se": cum_se, "n_obs": int(N)},
        {"term": "lag_1", "estimate": float(b[1]), "se": float(np.sqrt(V[1, 1])), "n_obs": int(N)},
        {"term": "lag_15", "estimate": float(b[LAGS]), "se": float(np.sqrt(V[LAGS, LAGS])), "n_obs": int(N)},
    ],
    "method_metadata": {
        "estimator": "OLS regression of log(sales) on intercept and 15 lags of the first difference of log(vix)",
        "vcov": "Newey-West HAC, maxlags=15, Bartlett weights 1-j/16, scaled by N/(N-16)",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
