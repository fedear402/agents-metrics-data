import json

import numpy as np
import pandas as pd
import statsmodels.api as sm

L = 15
N_COEF_ADJ = 16

df = pd.read_csv("input.csv")
df["date"] = pd.to_datetime(df["date"])
df = df.sort_values("date").reset_index(drop=True)

df["dlog_vix"] = np.log(df["vix"]).diff()
for j in range(1, L + 1):
    df[f"lag_{j}"] = df["dlog_vix"].shift(j)
df["log_sales"] = np.log(df["sales"])

lag_cols = [f"lag_{j}" for j in range(1, L + 1)]
d = df.dropna(subset=["log_sales"] + lag_cols).reset_index(drop=True)

y = d["log_sales"]
X = sm.add_constant(d[lag_cols], has_constant="add")
N = len(d)

res = sm.OLS(y, X).fit(
    cov_type="HAC",
    cov_kwds={"maxlags": L, "use_correction": False},
)

b = np.asarray(res.params, dtype=float)
V = np.asarray(res.cov_params(), dtype=float) * N / (N - N_COEF_ADJ)

R = np.zeros(len(b))
R[1:] = 1.0
cum_est = float(R @ b)
cum_se = float(np.sqrt(R @ V @ R))

names = list(X.columns)
i1 = names.index("lag_1")
i15 = names.index("lag_15")

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {"term": "cumulative_response", "estimate": cum_est, "se": cum_se, "n_obs": int(N)},
        {"term": "lag_1", "estimate": float(b[i1]), "se": float(np.sqrt(V[i1, i1])), "n_obs": int(N)},
        {"term": "lag_15", "estimate": float(b[i15]), "se": float(np.sqrt(V[i15, i15])), "n_obs": int(N)},
    ],
    "method_metadata": {
        "estimator": "OLS regression of log(sales) on intercept and 15 lags of dlog(vix)",
        "vcov": "Newey-West HAC, maxlags=15, Bartlett weights 1-j/16, scaled by N/(N-16)",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
