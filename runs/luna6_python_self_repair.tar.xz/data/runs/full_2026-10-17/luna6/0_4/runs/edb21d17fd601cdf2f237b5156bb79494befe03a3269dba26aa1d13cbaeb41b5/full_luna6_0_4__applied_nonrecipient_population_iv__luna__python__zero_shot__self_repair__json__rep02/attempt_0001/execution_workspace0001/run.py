import json
import numpy as np
import pandas as pd

households = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

# Retain every household that did not receive the transfer.
data = households.loc[households["recipient"] == 0].copy()
n_obs = int(len(data))

eligible = data["eligible"].to_numpy(dtype=float)
ineligible = 1.0 - eligible
dose = data["dose"].to_numpy(dtype=float)
instrument = data["instrument"].to_numpy(dtype=float)
baseline = data["baseline"].to_numpy(dtype=float)
weight = data["weight"].to_numpy(dtype=float)
outcome = data["outcome"].to_numpy(dtype=float)

# The first four columns are exogenous regressors. The last two are excluded
# instruments. No additional intercept is included.
exogenous = np.column_stack(
    [
        ineligible,
        eligible,
        baseline * ineligible,
        baseline * eligible,
    ]
)
endogenous = np.column_stack([dose * ineligible, dose * eligible])
instruments = np.column_stack(
    [
        exogenous,
        instrument * ineligible,
        instrument * eligible,
    ]
)

# Weighted 2SLS: project regressors and outcome onto the instrument space
# using the supplied regression weights, then solve the weighted normal equations.
sqrt_weight = np.sqrt(weight)
weighted_instruments = instruments * sqrt_weight[:, None]
weighted_regressors = np.column_stack([exogenous, endogenous]) * sqrt_weight[:, None]
weighted_outcome = outcome * sqrt_weight

projection_coefficients = np.linalg.lstsq(
    weighted_instruments, weighted_regressors, rcond=None
)[0]
projected_regressors = weighted_instruments @ projection_coefficients
beta = np.linalg.lstsq(
    projected_regressors.T @ projected_regressors,
    projected_regressors.T @ weighted_outcome,
    rcond=None,
)[0]

ineligible_dose_slope = float(beta[4])
eligible_dose_slope = float(beta[5])

ineligible_mask = eligible == 0
eligible_mask = eligible == 1

ineligible_mean_dose = float(
    np.average(dose[ineligible_mask], weights=weight[ineligible_mask])
)
eligible_mean_dose = float(
    np.average(dose[eligible_mask], weights=weight[eligible_mask])
)

ineligible_effect = ineligible_dose_slope * ineligible_mean_dose
eligible_nonrecipient_effect = eligible_dose_slope * eligible_mean_dose

population = census.set_index("eligible")["nonrecipient_population"]
ineligible_population = float(population.loc[0])
eligible_population = float(population.loc[1])
population_effect = (
    ineligible_effect * ineligible_population
    + eligible_nonrecipient_effect * eligible_population
) / (ineligible_population + eligible_population)

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "ineligible_effect",
            "estimate": float(ineligible_effect),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "eligible_nonrecipient_effect",
            "estimate": float(eligible_nonrecipient_effect),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "population_effect",
            "estimate": float(population_effect),
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "weighted_2sls",
        "regression_weight": "weight",
        "endogenous_columns": [
            "dose*(1-eligible)",
            "dose*eligible",
        ],
        "exogenous_columns": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
        ],
        "instrument_columns": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
            "instrument*(1-eligible)",
            "instrument*eligible",
        ],
        "intercept_added": False,
        "sample": "all household rows with recipient=0",
        "counterfactual": (
            "Synthetic convention: attribute each group effect to setting "
            "dose to zero for every retained household."
        ),
        "within_group_mean": "household-weighted mean dose",
        "population_aggregation": "census nonrecipient_population weights",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "ineligible_n_obs": int(ineligible_mask.sum()),
        "eligible_nonrecipient_n_obs": int(eligible_mask.sum()),
        "ineligible_weighted_mean_dose": ineligible_mean_dose,
        "eligible_weighted_mean_dose": eligible_mean_dose,
        "ineligible_dose_slope": ineligible_dose_slope,
        "eligible_dose_slope": eligible_dose_slope,
        "ineligible_nonrecipient_population": ineligible_population,
        "eligible_nonrecipient_population": eligible_population,
    },
}

with open("result.json", "w", encoding="utf-8") as output_file:
    json.dump(result, output_file, indent=2, allow_nan=False)
