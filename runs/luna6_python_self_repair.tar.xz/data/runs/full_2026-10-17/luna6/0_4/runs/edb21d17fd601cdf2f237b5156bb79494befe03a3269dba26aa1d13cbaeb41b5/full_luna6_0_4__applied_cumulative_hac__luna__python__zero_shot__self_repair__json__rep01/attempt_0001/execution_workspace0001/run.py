import json

import numpy as np
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("input.csv")
df["date"] = pd.to_datetime(df["date"])
df = df.sort_values("date").reset_index(drop=True)

df["volatility_change"] = np.log(df["vix"]).diff()
for lag in range(1, 16):
    df[f"lag_{lag}"] = df["volatility_change"].shift(lag)

df["log_sales"] = np.log(df["sales"])
regression_data = df.dropna(subset=["log_sales"] + [f"lag_{lag}" for lag in range(1, 16)])

y = regression_data["log_sales"]
X = sm.add_constant(regression_data[[f"lag_{lag}" for lag in range(1, 16)]])
model = sm.OLS(y, X).fit()

n_obs = int(len(regression_data))
cov = np.asarray(
    sm.stats.sandwich_covariance.cov_hac(
        model,
        nlags=15,
        weights_func=lambda nlags: 1 - np.arange(nlags + 1) / 16,
        use_correction=False,
    )
)
cov *= n_obs / (n_obs - 16)

coefficients = model.params
cumulative_estimate = float(coefficients[[f"lag_{lag}" for lag in range(1, 16)]].sum())
lag_names = list(X.columns)
cumulative_vector = np.array(
    [0.0] + [1.0] * 15
)
cumulative_se = float(np.sqrt(cumulative_vector @ cov @ cumulative_vector))

estimates = [
    {
        "term": "cumulative_response",
        "estimate": cumulative_estimate,
        "se": cumulative_se,
        "n_obs": n_obs,
    },
    {
        "term": "lag_1",
        "estimate": float(coefficients["lag_1"]),
        "se": float(np.sqrt(cov[lag_names.index("lag_1"), lag_names.index("lag_1")])),
        "n_obs": n_obs,
    },
    {
        "term": "lag_15",
        "estimate": float(coefficients["lag_15"]),
        "se": float(np.sqrt(cov[lag_names.index("lag_15"), lag_names.index("lag_15")])),
        "n_obs": n_obs,
    },
]

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "OLS of log(sales) on intercept and lags 1 through 15 of first-differenced log(vix)",
        "vcov": "Newey-West HAC, Bartlett weights 1-j/16, maximum lag 15, multiplied by N/(N-16)",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2)
