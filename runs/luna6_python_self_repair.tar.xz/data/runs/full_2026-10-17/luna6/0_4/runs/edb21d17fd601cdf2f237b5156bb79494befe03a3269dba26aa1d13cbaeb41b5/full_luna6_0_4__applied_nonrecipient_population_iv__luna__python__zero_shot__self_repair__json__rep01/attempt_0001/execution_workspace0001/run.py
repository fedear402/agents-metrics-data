import json
import numpy as np
import pandas as pd

households = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

sample = households.loc[households["recipient"] == 0].copy()
n_obs = int(len(sample))

eligible = sample["eligible"].to_numpy(dtype=float)
ineligible = 1.0 - eligible
dose = sample["dose"].to_numpy(dtype=float)
instrument = sample["instrument"].to_numpy(dtype=float)
baseline = sample["baseline"].to_numpy(dtype=float)
weight = sample["weight"].to_numpy(dtype=float)
outcome = sample["outcome"].to_numpy(dtype=float)

# Endogenous regressors, exogenous regressors, and excluded instruments.
endogenous = np.column_stack((dose * ineligible, dose * eligible))
exogenous = np.column_stack(
    (
        ineligible,
        eligible,
        baseline * ineligible,
        baseline * eligible,
    )
)
instruments = np.column_stack(
    (
        exogenous,
        instrument * ineligible,
        instrument * eligible,
    )
)

# Weighted 2SLS: project all regressors onto the instrument space using
# regression weights, then estimate the weighted second-stage regression.
sqrt_weight = np.sqrt(weight)
weighted_instruments = instruments * sqrt_weight[:, None]
weighted_regressors = np.column_stack((exogenous, endogenous)) * sqrt_weight[:, None]
weighted_outcome = outcome * sqrt_weight

projection_coefficients, *_ = np.linalg.lstsq(
    weighted_instruments, weighted_regressors, rcond=None
)
projected_regressors = weighted_instruments @ projection_coefficients

second_stage_coefficients, *_ = np.linalg.lstsq(
    projected_regressors, weighted_outcome, rcond=None
)

# Column order is exogenous terms followed by the two dose slopes.
ineligible_slope = float(second_stage_coefficients[-2])
eligible_slope = float(second_stage_coefficients[-1])

ineligible_mean_dose = float(
    np.average(sample.loc[sample["eligible"] == 0, "dose"], weights=sample.loc[sample["eligible"] == 0, "weight"])
)
eligible_mean_dose = float(
    np.average(sample.loc[sample["eligible"] == 1, "dose"], weights=sample.loc[sample["eligible"] == 1, "weight"])
)

ineligible_effect = ineligible_slope * ineligible_mean_dose
eligible_nonrecipient_effect = eligible_slope * eligible_mean_dose

population_by_group = census.set_index("eligible")["nonrecipient_population"]
pop_ineligible = float(population_by_group.loc[0])
pop_eligible = float(population_by_group.loc[1])
population_effect = (
    pop_ineligible * ineligible_effect + pop_eligible * eligible_nonrecipient_effect
) / (pop_ineligible + pop_eligible)

estimates = [
    {"term": "ineligible_effect", "estimate": float(ineligible_effect), "se": None, "n_obs": n_obs},
    {
        "term": "eligible_nonrecipient_effect",
        "estimate": float(eligible_nonrecipient_effect),
        "se": None,
        "n_obs": n_obs,
    },
    {"term": "population_effect", "estimate": float(population_effect), "se": None, "n_obs": n_obs},
]

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "weighted_2sls",
        "sample": "all household rows with recipient=0",
        "endogenous_columns": ["dose*(1-eligible)", "dose*eligible"],
        "exogenous_columns": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
        ],
        "instrument_columns": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
            "instrument*(1-eligible)",
            "instrument*eligible",
        ],
        "intercept": "none beyond the specified exogenous columns",
        "regression_weight": "weight",
        "within_group_mean_dose_weight": "weight",
        "counterfactual": "dose set to zero for every retained household",
        "attribution_convention": "synthetic convention",
        "population_weights_source": "census.csv nonrecipient_population, used only for final aggregation",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "ineligible_dose_slope": ineligible_slope,
        "eligible_dose_slope": eligible_slope,
        "ineligible_weighted_mean_dose": ineligible_mean_dose,
        "eligible_weighted_mean_dose": eligible_mean_dose,
        "ineligible_nonrecipient_population": int(pop_ineligible),
        "eligible_nonrecipient_population": int(pop_eligible),
    },
}

with open("result.json", "w", encoding="utf-8") as result_file:
    json.dump(result, result_file, indent=2, allow_nan=False)
