import json
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("input.csv")

# Reduce to one observation per region for regional variables and weights.
regions = df.drop_duplicates("region_id").set_index("region_id")
region_weight = regions["region_weight"].astype(float)
e = region_weight / region_weight.sum()

# Compute regional shift-share exposure from all region-industry rows.
shares = df.pivot(index="region_id", columns="industry_id", values="share").astype(float)
industry_shocks = df.drop_duplicates("industry_id").set_index("industry_id")["shock"].astype(float)
shares = shares.reindex(index=e.index, columns=industry_shocks.index)
z = shares.mul(industry_shocks, axis=1).sum(axis=1)

x = regions.loc[e.index, "x"].astype(float)
y = regions.loc[e.index, "y"].astype(float)

# Weighted demean the regional variables.
x0 = x - (e * x).sum()
y0 = y - (e * y).sum()
z0 = z - (e * z).sum()

# Aggregate weighted residuals to industry exposure cells.
industry_exposure = shares.mul(e, axis=0)
s = industry_exposure.sum(axis=0)
valid = s > 0
s = s.loc[valid]
industry_exposure = industry_exposure.loc[:, valid]
shock = industry_shocks.loc[s.index]

def shock_aggregate(v0):
    return industry_exposure.mul(v0, axis=0).sum(axis=0) / s

xbar = shock_aggregate(x0)
ybar = shock_aggregate(y0)
zbar = shock_aggregate(z0)

def shock_level_iv(outcome, endogenous, instrument):
    exog = sm.add_constant(endogenous)
    fit = sm.WLS(outcome, exog, weights=s).fit()
    # Manual IV slope, intercept, structural residuals, and HC1 sandwich.
    weighted = s.to_numpy()
    q = exog.to_numpy()
    instr = sm.add_constant(instrument).to_numpy()
    yy = outcome.to_numpy()
    q_hat = instr @ (
        __import__("numpy").linalg.solve(
            instr.T @ (weighted[:, None] * instr),
            instr.T @ (weighted * yy),
        )
    )
    beta = __import__("numpy").linalg.solve(
        q.T @ (weighted[:, None] * q_hat),
        q_hat.T @ (weighted * yy),
    )
    residual = yy - q @ beta
    bread = __import__("numpy").linalg.inv(q_hat.T @ (weighted[:, None] * q))
    score = q_hat.T * (weighted * residual)
    n = len(yy)
    cov = (n / (n - 2)) * bread @ (score @ score.T) @ bread.T
    return float(beta[1]), float(cov[1, 1] ** 0.5)

import numpy as np

effect, effect_se = shock_level_iv(ybar, xbar, shock)
first_stage, first_stage_se = shock_level_iv(xbar, zbar, shock)
effective_shocks = float(1.0 / (s.pow(2).sum()))
n_industries = int(len(s))

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": effect, "se": effect_se, "n_obs": n_industries},
        {"term": "first_stage", "estimate": first_stage, "se": first_stage_se, "n_obs": n_industries},
        {"term": "effective_shocks", "estimate": effective_shocks, "se": None, "n_obs": n_industries},
    ],
    "method_metadata": {
        "estimator": "Weighted 2SLS with Borusyak-Hull-Jaravel shock-level aggregation",
        "vcov": "Shock-level heteroskedasticity-robust HC1; analytic exposure weights; no clustering",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, allow_nan=False)
