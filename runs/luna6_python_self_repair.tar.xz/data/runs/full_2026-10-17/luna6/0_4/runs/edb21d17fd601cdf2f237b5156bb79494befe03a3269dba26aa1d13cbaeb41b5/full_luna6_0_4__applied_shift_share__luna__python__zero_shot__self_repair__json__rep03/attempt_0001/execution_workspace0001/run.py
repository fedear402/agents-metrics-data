import json
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("input.csv")

# Reduce the region-industry data to one record per region.
regions = df[["region_id", "region_weight", "x", "y"]].drop_duplicates("region_id").copy()
regions["e"] = regions["region_weight"] / regions["region_weight"].sum()

# Construct regional shift-share exposure using all region-industry pairs.
df["share_shock"] = df["share"] * df["shock"]
z_by_region = df.groupby("region_id", sort=False)["share_shock"].sum()
regions["z"] = regions["region_id"].map(z_by_region)

# Center regional variables using normalized regional weights.
for variable in ("y", "x", "z"):
    regions[f"{variable}0"] = regions[variable] - (regions["e"] * regions[variable]).sum()

# Aggregate centered variables and shares to the industry level.
industries = df[["industry_id", "shock"]].drop_duplicates("industry_id").set_index("industry_id")
share_weights = df[["region_id", "industry_id", "share"]].copy()
share_weights = share_weights.merge(regions[["region_id", "e", "y0", "x0", "z0"]], on="region_id")
share_weights["es"] = share_weights["e"] * share_weights["share"]

agg = share_weights.groupby("industry_id").agg(
    s=("es", "sum"),
    y_num=("es", lambda v: 0.0),
)
# Compute weighted numerators directly.
for variable in ("y0", "x0", "z0"):
    share_weights[f"{variable}_num"] = share_weights["es"] * share_weights[variable]
numerators = share_weights.groupby("industry_id")[
    ["y0_num", "x0_num", "z0_num"]
].sum()
industries = industries.join(share_weights.groupby("industry_id")["es"].sum().rename("s"))
industries = industries.join(numerators)
for variable in ("y", "x", "z"):
    industries[f"{variable}bar"] = industries[f"{variable}0_num"] / industries["s"]
industries = industries.reset_index()

N = len(industries)
weights = industries["s"].to_numpy()

def weighted_iv_hc1(outcome, endogenous, instrument):
    """Weighted IV with one excluded instrument and HC1 robust covariance."""
    y = industries[outcome].to_numpy()
    x = industries[endogenous].to_numpy()
    z = industries[instrument].to_numpy()

    # 2SLS: regressors are [intercept, endogenous], instruments [intercept, excluded instrument].
    X = sm.add_constant(x)
    Z = sm.add_constant(z)
    W = weights
    bread = __import__("numpy").linalg.inv(X.T @ (W[:, None] * Z) @
                                         __import__("numpy").linalg.inv(Z.T @ (W[:, None] * Z)) @
                                         Z.T @ (W[:, None] * X))
    beta = bread @ (
        X.T @ (W[:, None] * Z) @
        __import__("numpy").linalg.inv(Z.T @ (W[:, None] * Z)) @
        Z.T @ (W * y)
    )
    residual = y - X @ beta

    # HC1 sandwich using structural IV residuals and analytic weights.
    A = X.T @ (W[:, None] * Z) @ __import__("numpy").linalg.inv(Z.T @ (W[:, None] * Z)) @ Z.T
    meat = A @ __import__("numpy").diag((W * residual) ** 2) @ A.T
    cov = bread @ meat @ bread.T * (N / (N - 2))
    return float(beta[1]), float(__import__("numpy").sqrt(cov[1, 1]))

effect, effect_se = weighted_iv_hc1("ybar", "xbar", "shock")
first_stage, first_stage_se = weighted_iv_hc1("xbar", "zbar", "shock")
effective_shocks = float(1.0 / (weights**2).sum())

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": effect, "se": effect_se, "n_obs": N},
        {"term": "first_stage", "estimate": first_stage, "se": first_stage_se, "n_obs": N},
        {"term": "effective_shocks", "estimate": effective_shocks, "se": None, "n_obs": N},
    ],
    "method_metadata": {
        "estimator": "Borusyak-Hull-Jaravel shock-level weighted 2SLS",
        "vcov": "HC1 heteroskedasticity-robust; analytic weights; no clustering",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, allow_nan=False)
