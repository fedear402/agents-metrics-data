import json
import numpy as np
import pandas as pd
from scipy.stats import f

data = pd.read_csv("input.csv")
y = data["y"].to_numpy(dtype=float)
endog = data["endog"].to_numpy(dtype=float)
controls = np.column_stack([np.ones(len(data)), data["x"].to_numpy(dtype=float)])
excluded = data[["z1", "z2"]].to_numpy(dtype=float)
restricted = np.column_stack([controls, excluded])

n = len(data)
q = excluded.shape[1]
df = n - restricted.shape[1]
critical = f.ppf(0.95, q, df)
k = q * critical / df

def residual(values, design):
    return values - design @ np.linalg.lstsq(design, values, rcond=None)[0]

ry = residual(y, controls)
rd = residual(endog, controls)
uy = residual(y, restricted)
ud = residual(endog, restricted)

# The AR acceptance condition is A*beta^2 + B*beta + C <= 0.
A = rd @ rd - (1 + k) * (ud @ ud)
B = -2 * (ry @ rd - (1 + k) * (uy @ ud))
C = ry @ ry - (1 + k) * (uy @ uy)

discriminant = B * B - 4 * A * C
if abs(A) < 1e-12 or discriminant < 0:
    raise ValueError("Expected two finite AR confidence-set boundaries.")

boundaries = np.sort(np.roots([A, B, C]).real)
unbounded = int(A < 0)
accepts_zero = int(C <= 0)

def ar_f(beta):
    value = y - beta * endog
    r = residual(value, controls)
    u = residual(value, restricted)
    ssr_difference = r @ r - u @ u
    return (ssr_difference / q) / ((u @ u) / df)

rows = [
    {"term": "boundary_low", "estimate": float(boundaries[0]), "se": None, "n_obs": n},
    {"term": "boundary_high", "estimate": float(boundaries[1]), "se": None, "n_obs": n},
    {"term": "accepts_zero", "estimate": float(accepts_zero), "se": None, "n_obs": n},
    {"term": "unbounded", "estimate": float(unbounded), "se": None, "n_obs": n},
    {"term": "ar_f_at_one", "estimate": float(ar_f(1.0)), "se": None, "n_obs": n},
]

with open("result.json", "w") as stream:
    json.dump(
        {
            "task_id": "broad_ar_confidence_set",
            "platform": "python",
            "estimates": rows,
            "method_metadata": {
                "estimator": "Anderson-Rubin confidence set inversion",
                "vcov": "conventional homoskedastic joint F test",
            },
            "diagnostics": {},
        },
        stream,
        indent=2,
        allow_nan=False,
    )
