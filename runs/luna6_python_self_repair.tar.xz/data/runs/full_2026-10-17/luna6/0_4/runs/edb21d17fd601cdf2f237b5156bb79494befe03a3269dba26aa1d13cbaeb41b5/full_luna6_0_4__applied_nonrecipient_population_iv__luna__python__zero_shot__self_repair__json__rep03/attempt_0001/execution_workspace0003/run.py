import json

import numpy as np
import pandas as pd

households = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

# Retain every nonrecipient household, across both village treatment statuses.
data = households.loc[households["recipient"] == 0].copy()
n_obs = int(len(data))

eligible = data["eligible"].astype(float).to_numpy()
ineligible = 1.0 - eligible
dose = data["dose"].astype(float).to_numpy()
instrument = data["instrument"].astype(float).to_numpy()
baseline = data["baseline"].astype(float).to_numpy()
weight = data["weight"].astype(float).to_numpy()
outcome = data["outcome"].astype(float).to_numpy()

# Weighted 2SLS via weighted least squares projections. The instrument
# matrix includes the exogenous columns once, as required.
exog = np.column_stack(
    [
        ineligible,
        eligible,
        baseline * ineligible,
        baseline * eligible,
    ]
)
endog = np.column_stack([dose * ineligible, dose * eligible])
instruments = np.column_stack(
    [
        exog,
        instrument * ineligible,
        instrument * eligible,
    ]
)

sqrt_weight = np.sqrt(weight)
weighted_instruments = instruments * sqrt_weight[:, None]
weighted_exog = exog * sqrt_weight[:, None]
weighted_endog = endog * sqrt_weight[:, None]
weighted_outcome = outcome * sqrt_weight

# Project endogenous regressors onto the full instrument space, then fit
# the structural equation by weighted least squares.
projected_endog = weighted_instruments @ np.linalg.lstsq(
    weighted_instruments, weighted_endog, rcond=None
)[0]
structural_design = np.column_stack([weighted_exog, projected_endog])
coefficients = np.linalg.lstsq(
    structural_design, weighted_outcome, rcond=None
)[0]

# The final two coefficients are the group-specific dose slopes.
dose_slope_ineligible = float(coefficients[-2])
dose_slope_eligible = float(coefficients[-1])

ineligible_mask = eligible == 0
eligible_mask = eligible == 1
ineligible_mean_dose = float(
    np.average(dose[ineligible_mask], weights=weight[ineligible_mask])
)
eligible_mean_dose = float(
    np.average(dose[eligible_mask], weights=weight[eligible_mask])
)

ineligible_effect = dose_slope_ineligible * ineligible_mean_dose
eligible_nonrecipient_effect = dose_slope_eligible * eligible_mean_dose

population = census.set_index("eligible")["nonrecipient_population"]
pop_ineligible = float(population.loc[0])
pop_eligible = float(population.loc[1])
population_effect = (
    ineligible_effect * pop_ineligible
    + eligible_nonrecipient_effect * pop_eligible
) / (pop_ineligible + pop_eligible)

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "ineligible_effect",
            "estimate": float(ineligible_effect),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "eligible_nonrecipient_effect",
            "estimate": float(eligible_nonrecipient_effect),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "population_effect",
            "estimate": float(population_effect),
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "weighted_2sls",
        "weight": "weight",
        "endogenous_columns": ["dose*(1-eligible)", "dose*eligible"],
        "exogenous_columns": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
        ],
        "instruments": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
            "instrument*(1-eligible)",
            "instrument*eligible",
        ],
        "intercept": "No additional intercept",
        "counterfactual": "Dose set to zero for every retained household",
        "attribution_convention": (
            "Each group effect is its fitted dose slope times its "
            "household-weighted mean dose. Attribution to a zero-dose "
            "counterfactual is a stated synthetic convention."
        ),
        "population_weights_source": (
            "census.csv nonrecipient_population, used only for final "
            "between-group aggregation"
        ),
    },
    "diagnostics": {
        "n_obs": n_obs,
        "retained_sample": "All household rows with recipient=0",
        "census_used_only_for_final_group_aggregation": True,
    },
}

with open("result.json", "w", encoding="utf-8") as output_file:
    json.dump(result, output_file, indent=2, allow_nan=False)
