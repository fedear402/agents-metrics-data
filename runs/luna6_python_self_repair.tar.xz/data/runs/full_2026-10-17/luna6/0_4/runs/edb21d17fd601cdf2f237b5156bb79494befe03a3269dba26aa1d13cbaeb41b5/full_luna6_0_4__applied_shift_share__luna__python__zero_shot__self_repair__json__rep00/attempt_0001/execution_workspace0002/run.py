import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")

# Keep one row per region for regional variables and weights.
regions = df.drop_duplicates("region_id").set_index("region_id")
region_weight = regions["region_weight"].astype(float)
e = region_weight / region_weight.sum()

# Build the region-by-industry share matrix and align shocks to its columns.
shares = df.pivot(index="region_id", columns="industry_id", values="share").astype(float)
shares = shares.reindex(index=e.index)
industry_shocks = (
    df.drop_duplicates("industry_id")
    .set_index("industry_id")["shock"]
    .astype(float)
)
shares = shares.reindex(columns=industry_shocks.index)

x = regions.loc[e.index, "x"].astype(float)
y = regions.loc[e.index, "y"].astype(float)
z = shares.mul(industry_shocks, axis=1).sum(axis=1)

# Weighted demean the regional variables.
x0 = x - (e * x).sum()
y0 = y - (e * y).sum()
z0 = z - (e * z).sum()

# Calculate industry exposure weights and shock-level aggregates.
exposure = shares.mul(e, axis=0)
s_all = exposure.sum(axis=0)
valid = s_all > 0
exposure = exposure.loc[:, valid]
s = s_all.loc[valid]
shock = industry_shocks.loc[s.index]

def aggregate_to_industries(v0):
    return exposure.mul(v0, axis=0).sum(axis=0) / s

xbar = aggregate_to_industries(x0)
ybar = aggregate_to_industries(y0)
zbar = aggregate_to_industries(z0)

def shock_level_iv(outcome, endogenous, instrument):
    """Weighted 2SLS with one endogenous regressor and an intercept."""
    w = s.to_numpy(dtype=float)
    yv = outcome.to_numpy(dtype=float)
    q = np.column_stack([np.ones(len(w)), endogenous.to_numpy(dtype=float)])
    h = np.column_stack([np.ones(len(w)), instrument.to_numpy(dtype=float)])

    # 2SLS coefficient: (Q'WH(H'WH)^-1H'WQ)^-1 Q'WH(H'WH)^-1H'Wy.
    hwh = h.T @ (w[:, None] * h)
    hwh_inv = np.linalg.inv(hwh)
    qwh = q.T @ (w[:, None] * h)
    bread = np.linalg.inv(qwh @ hwh_inv @ qwh.T)
    beta = bread @ qwh @ hwh_inv @ (h.T @ (w * yv))

    # Structural residuals and HC1 sandwich with analytic weights.
    residual = yv - q @ beta
    meat = q.T @ ((w * residual)[:, None] ** 2 * q)
    n = len(w)
    cov = (n / (n - 2)) * bread @ meat @ bread
    return float(beta[1]), float(np.sqrt(cov[1, 1]))

effect, effect_se = shock_level_iv(ybar, xbar, shock)
first_stage, first_stage_se = shock_level_iv(xbar, zbar, shock)
effective_shocks = float(1.0 / np.square(s.to_numpy(dtype=float)).sum())
n_industries = int(len(s))

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": effect, "se": effect_se, "n_obs": n_industries},
        {"term": "first_stage", "estimate": first_stage, "se": first_stage_se, "n_obs": n_industries},
        {"term": "effective_shocks", "estimate": effective_shocks, "se": None, "n_obs": n_industries},
    ],
    "method_metadata": {
        "estimator": "Weighted 2SLS with Borusyak-Hull-Jaravel shock-level aggregation",
        "vcov": "Shock-level heteroskedasticity-robust HC1; analytic exposure weights; no clustering",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, allow_nan=False)
