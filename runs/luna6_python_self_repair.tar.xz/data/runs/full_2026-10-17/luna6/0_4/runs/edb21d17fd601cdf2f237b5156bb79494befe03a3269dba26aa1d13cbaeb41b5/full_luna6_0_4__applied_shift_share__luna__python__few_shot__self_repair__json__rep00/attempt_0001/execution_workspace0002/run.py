import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")

# Keep one row per region for regional variables and weights.
regions = df.drop_duplicates("region_id").set_index("region_id")
region_ids = regions.index
e = regions["region_weight"].to_numpy(dtype=float).copy()
e /= e.sum()

industry_ids = pd.Index(df["industry_id"].drop_duplicates())
N = len(industry_ids)
if N <= 2:
    raise ValueError("At least three industries are required for HC1 standard errors.")

shares = (
    df.pivot(index="region_id", columns="industry_id", values="share")
    .reindex(index=region_ids, columns=industry_ids)
    .to_numpy(dtype=float)
)
shocks_by_industry = df.drop_duplicates("industry_id").set_index("industry_id")["shock"]
shock = shocks_by_industry.reindex(industry_ids).to_numpy(dtype=float)

x = regions["x"].to_numpy(dtype=float)
y = regions["y"].to_numpy(dtype=float)
z = shares @ shock

# Center regional variables using normalized regional weights.
x0 = x - np.dot(e, x)
y0 = y - np.dot(e, y)
z0 = z - np.dot(e, z)

# Aggregate centered variables by industry exposure.
s = e @ shares
if np.any(s <= 0):
    raise ValueError("Each industry must have positive exposure mass.")

def aggregate(v0):
    return (shares.T @ (e * v0)) / s

xbar = aggregate(x0)
ybar = aggregate(y0)
zbar = aggregate(z0)

def shock_level_iv(dependent, endogenous):
    regressors = np.column_stack((np.ones(N), endogenous))
    instruments = np.column_stack((np.ones(N), shock))
    weighted_cross = instruments.T @ (s[:, None] * regressors)
    beta = np.linalg.solve(weighted_cross, instruments.T @ (s * dependent))

    # Use structural IV residuals and analytic-weight HC1 scores.
    residual = dependent - regressors @ beta
    scores = instruments * (s * residual)[:, None]
    inverse = np.linalg.inv(weighted_cross)
    covariance = (N / (N - 2)) * inverse @ (scores.T @ scores) @ inverse.T
    return float(beta[1]), float(np.sqrt(covariance[1, 1]))

effect, effect_se = shock_level_iv(ybar, xbar)
first_stage, first_stage_se = shock_level_iv(xbar, zbar)
effective_shocks = float(1.0 / np.sum(s ** 2))

output = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": effect, "se": effect_se, "n_obs": N},
        {"term": "first_stage", "estimate": first_stage, "se": first_stage_se, "n_obs": N},
        {
            "term": "effective_shocks",
            "estimate": effective_shocks,
            "se": None,
            "n_obs": N,
        },
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS with Borusyak-Hull-Jaravel shock-level aggregation",
        "vcov": "shock-level analytic-weight HC1 with structural IV residuals",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
