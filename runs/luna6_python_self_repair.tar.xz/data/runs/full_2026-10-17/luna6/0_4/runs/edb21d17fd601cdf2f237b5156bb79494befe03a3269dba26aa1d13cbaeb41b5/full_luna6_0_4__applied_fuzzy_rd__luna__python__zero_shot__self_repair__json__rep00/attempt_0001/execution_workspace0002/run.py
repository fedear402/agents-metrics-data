import json

import numpy as np
import pandas as pd


def main():
    df = pd.read_csv("input.csv")
    data = df.loc[df["score"].abs() < 1].copy()
    n_obs = int(len(data))

    score = data["score"].to_numpy(dtype=float)
    right = (score >= 0).astype(float)
    weights = 1.0 - np.abs(score)

    # Separate intercepts and slopes on each side.
    design = np.column_stack(
        [
            1.0 - right,
            (1.0 - right) * score,
            right,
            right * score,
        ]
    )

    weighted_design = design * np.sqrt(weights)[:, None]
    bread = np.linalg.inv(weighted_design.T @ weighted_design)

    outcomes = data[["earnings", "participated"]].to_numpy(dtype=float)
    coefficients = bread @ weighted_design.T @ (outcomes * np.sqrt(weights)[:, None])
    residuals = outcomes - design @ coefficients

    # Right limit minus left limit.
    contrast = np.array([-1.0, 0.0, 1.0, 0.0])
    discontinuities = contrast @ coefficients
    reduced_form, first_stage = discontinuities

    # HC0 covariance for the two discontinuities, including their covariance.
    outcome_vcov = np.empty((2, 2), dtype=float)
    for i in range(2):
        for j in range(2):
            meat_ij = design.T @ (
                design
                * (weights**2 * residuals[:, i] * residuals[:, j])[:, None]
            )
            outcome_vcov[i, j] = contrast @ bread @ meat_ij @ bread @ contrast

    rf_var = outcome_vcov[0, 0]
    fs_var = outcome_vcov[1, 1]
    rf_fs_cov = outcome_vcov[0, 1]

    treatment_effect = reduced_form / first_stage
    treatment_variance = (
        rf_var / first_stage**2
        + reduced_form**2 * fs_var / first_stage**4
        - 2.0 * reduced_form * rf_fs_cov / first_stage**3
    )

    estimates = [
        {
            "term": "treatment_effect",
            "estimate": float(treatment_effect),
            "se": float(np.sqrt(max(treatment_variance, 0.0))),
            "n_obs": n_obs,
        },
        {
            "term": "reduced_form",
            "estimate": float(reduced_form),
            "se": float(np.sqrt(max(rf_var, 0.0))),
            "n_obs": n_obs,
        },
        {
            "term": "first_stage",
            "estimate": float(first_stage),
            "se": float(np.sqrt(max(fs_var, 0.0))),
            "n_obs": n_obs,
        },
    ]

    result = {
        "task_id": "applied_fuzzy_rd",
        "platform": "python",
        "estimates": estimates,
        "method_metadata": {
            "estimator": "weighted local-linear fuzzy regression discontinuity; triangular weights; bandwidth 1",
            "vcov": "HC0 sandwich; delta method with joint covariance",
        },
        "diagnostics": {},
    }

    with open("result.json", "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
