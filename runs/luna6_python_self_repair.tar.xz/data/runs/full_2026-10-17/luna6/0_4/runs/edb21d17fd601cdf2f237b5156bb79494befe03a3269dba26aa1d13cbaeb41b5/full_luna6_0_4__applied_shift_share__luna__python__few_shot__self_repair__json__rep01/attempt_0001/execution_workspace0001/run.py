import json
import pandas as pd
import numpy as np

df = pd.read_csv("input.csv")

# Use one row per region to normalize regional weights and read regional outcomes.
regions = df.drop_duplicates("region_id").copy()
regions["e"] = regions["region_weight"] / regions["region_weight"].sum()

region_weights = regions.set_index("region_id")["e"]
region_x = regions.set_index("region_id")["x"]
region_y = regions.set_index("region_id")["y"]

# Industry shocks must be constant within industry.
shock_by_industry = df.groupby("industry_id")["shock"].first()
if not df.groupby("industry_id")["shock"].nunique().eq(1).all():
    raise ValueError("shock must be constant within industry")

shares = df.pivot_table(
    index="region_id",
    columns="industry_id",
    values="share",
    aggfunc="sum",
    fill_value=0.0,
).reindex(index=region_weights.index, columns=shock_by_industry.index, fill_value=0.0)

shock = shock_by_industry.reindex(shares.columns).to_numpy(dtype=float)
e = region_weights.to_numpy(dtype=float)
x = region_x.reindex(shares.index).to_numpy(dtype=float)
y = region_y.reindex(shares.index).to_numpy(dtype=float)
z = shares.to_numpy(dtype=float) @ shock

# Weighted regional centering.
y0 = y - np.sum(e * y)
x0 = x - np.sum(e * x)
z0 = z - np.sum(e * z)

# Industry exposure masses and weighted residual aggregates.
s = e @ shares
if np.any(s <= 0):
    raise ValueError("Each industry must have positive exposure mass")

def aggregate(v0):
    return (shares.T @ (e * v0)) / s

ybar = aggregate(y0)
xbar = aggregate(x0)
zbar = aggregate(z0)
n_industries = len(s)

def weighted_iv_hc1(dependent, endogenous, instrument):
    # Weighted IV with an intercept, using the specified analytic weights.
    regressors = np.column_stack([np.ones(n_industries), endogenous])
    instruments = np.column_stack([np.ones(n_industries), instrument])
    cross = instruments.T @ (s[:, None] * regressors)
    beta = np.linalg.solve(cross, instruments.T @ (s * dependent))

    residual = dependent - regressors @ beta
    scores = instruments * (s * residual)[:, None]
    inverse = np.linalg.inv(cross)
    covariance = (
        n_industries / (n_industries - 2)
        * inverse
        @ (scores.T @ scores)
        @ inverse.T
    )
    return float(beta[1]), float(np.sqrt(covariance[1, 1]))

effect, effect_se = weighted_iv_hc1(ybar, xbar, shock)
first_stage, first_stage_se = weighted_iv_hc1(xbar, zbar, shock)

output = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {
            "term": "effect",
            "estimate": effect,
            "se": effect_se,
            "n_obs": n_industries,
        },
        {
            "term": "first_stage",
            "estimate": first_stage,
            "se": first_stage_se,
            "n_obs": n_industries,
        },
        {
            "term": "effective_shocks",
            "estimate": float(1.0 / np.sum(s**2)),
            "se": None,
            "n_obs": n_industries,
        },
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS with Borusyak-Hull-Jaravel shock-level aggregation",
        "vcov": "shock-level HC1 with structural IV residuals and analytic weights",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
