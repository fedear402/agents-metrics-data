import json
import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS

households = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

d = households.loc[households["recipient"] == 0].copy()
d["ineligible"] = 1 - d["eligible"]

exog = pd.DataFrame(
    {
        "ineligible": d["ineligible"],
        "eligible": d["eligible"],
        "baseline_ineligible": d["baseline"] * d["ineligible"],
        "baseline_eligible": d["baseline"] * d["eligible"],
    },
    index=d.index,
)
endog = pd.DataFrame(
    {
        "dose_ineligible": d["dose"] * d["ineligible"],
        "dose_eligible": d["dose"] * d["eligible"],
    },
    index=d.index,
)
instruments = exog.copy()
instruments["instrument_ineligible"] = d["instrument"] * d["ineligible"]
instruments["instrument_eligible"] = d["instrument"] * d["eligible"]

fit = IV2SLS(
    dependent=d["outcome"],
    exog=exog,
    endog=endog,
    instruments=instruments,
    weights=d["weight"],
).fit()

n_obs = int(len(d))
group_effects = {}
for eligible, slope_column, label in [
    (0, "dose_ineligible", "ineligible_effect"),
    (1, "dose_eligible", "eligible_nonrecipient_effect"),
]:
    group = d.loc[d["eligible"] == eligible]
    slope = float(fit.params[slope_column])
    mean_dose = float(np.average(group["dose"], weights=group["weight"]))
    group_effects[label] = slope * mean_dose

population_weights = census.set_index("eligible")["nonrecipient_population"]
population_effect = float(
    np.average(
        [
            group_effects["ineligible_effect"],
            group_effects["eligible_nonrecipient_effect"],
        ],
        weights=[
            population_weights.loc[0],
            population_weights.loc[1],
        ],
    )
)

estimates = [
    {
        "term": "ineligible_effect",
        "estimate": float(group_effects["ineligible_effect"]),
        "se": None,
        "n_obs": n_obs,
    },
    {
        "term": "eligible_nonrecipient_effect",
        "estimate": float(group_effects["eligible_nonrecipient_effect"]),
        "se": None,
        "n_obs": n_obs,
    },
    {
        "term": "population_effect",
        "estimate": population_effect,
        "se": None,
        "n_obs": n_obs,
    },
]

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "sample": "all households with recipient=0",
        "endogenous_columns": ["dose*(1-eligible)", "dose*eligible"],
        "exogenous_columns": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
        ],
        "instruments": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
            "instrument*(1-eligible)",
            "instrument*eligible",
        ],
        "weight_column": "weight",
        "counterfactual": "dose set to zero for every retained household",
        "attribution_convention": "synthetic convention",
        "group_effect_formula": "fitted dose slope times household-weighted mean dose",
        "population_aggregation_weights": "nonrecipient_population from census.csv",
    },
    "diagnostics": {"n_obs": n_obs},
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, allow_nan=False)
