import json

import numpy as np
import pandas as pd


def weighted_mean(values, weights):
    return np.sum(weights * values) / np.sum(weights)


def weighted_iv_hc1(y, x, z, instrument, weights):
    """Weighted IV with an intercept and HC1 robust covariance."""
    y = np.asarray(y, dtype=float)
    x = np.asarray(x, dtype=float)
    z = np.asarray(z, dtype=float)
    instrument = np.asarray(instrument, dtype=float)
    weights = np.asarray(weights, dtype=float)

    n = len(y)
    exog = np.column_stack((np.ones(n), x))
    instruments = np.column_stack((np.ones(n), instrument))

    # Analytic-weight 2SLS: project regressors onto instruments using W.
    instrument_cross = instruments.T @ (weights[:, None] * instruments)
    projection = np.linalg.solve(
        instrument_cross,
        instruments.T @ (weights[:, None] * exog),
    )
    bread_matrix = exog.T @ (weights[:, None] * instruments) @ projection
    beta = np.linalg.solve(
        bread_matrix,
        exog.T @ (weights * y),
    )

    residual = y - exog @ beta
    # HC1 sandwich for IV, using structural residuals and analytic weights.
    score_design = instruments.T @ (weights[:, None] * exog)
    bread = np.linalg.inv(bread_matrix)
    meat = instruments.T @ (
        ((weights * residual) ** 2)[:, None] * instruments
    )
    covariance = bread @ score_design.T @ np.linalg.inv(instrument_cross)
    covariance = covariance @ meat @ np.linalg.inv(instrument_cross).T
    covariance = covariance @ score_design @ bread
    covariance *= n / (n - exog.shape[1])
    return beta, covariance


df = pd.read_csv("input.csv")

# One record per region defines the normalized regional weights and outcomes.
regions = df.drop_duplicates("region_id").copy()
regions["e"] = regions["region_weight"] / regions["region_weight"].sum()

# Use every region-industry pair to construct shift-share exposure.
df["exposure_component"] = df["share"] * df["shock"]
z_by_region = df.groupby("region_id")["exposure_component"].sum()
regions = regions.merge(
    z_by_region.rename("z"),
    on="region_id",
    how="left",
    validate="one_to_one",
)

e = regions["e"].to_numpy(dtype=float)
for variable in ("y", "x", "z"):
    mean = weighted_mean(regions[variable].to_numpy(dtype=float), e)
    regions[f"{variable}0"] = regions[variable] - mean

# Aggregate region residuals to industry using weighted employment shares.
shares = df.pivot_table(
    index="region_id",
    columns="industry_id",
    values="share",
    aggfunc="sum",
    fill_value=0.0,
)
shares = shares.reindex(regions["region_id"]).to_numpy(dtype=float)
industry_ids = list(df["industry_id"].drop_duplicates())
shocks = (
    df.drop_duplicates("industry_id")
    .set_index("industry_id")
    .reindex(industry_ids)["shock"]
    .to_numpy(dtype=float)
)

weighted_shares = e[:, None] * shares
s = weighted_shares.sum(axis=0)
if np.any(s <= 0):
    raise ValueError("Each included industry must have positive weighted exposure.")

industry_data = {}
for variable in ("y", "x", "z"):
    residual = regions[f"{variable}0"].to_numpy(dtype=float)
    industry_data[f"{variable}bar"] = (
        weighted_shares.T @ residual
    ) / s

ybar = industry_data["ybar"]
xbar = industry_data["xbar"]
zbar = industry_data["zbar"]
n_industries = len(s)

effect_beta, effect_cov = weighted_iv_hc1(ybar, xbar, shocks, shocks, s)
first_beta, first_cov = weighted_iv_hc1(xbar, zbar, shocks, shocks, s)

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {
            "term": "effect",
            "estimate": float(effect_beta[1]),
            "se": float(np.sqrt(effect_cov[1, 1])),
            "n_obs": int(n_industries),
        },
        {
            "term": "first_stage",
            "estimate": float(first_beta[1]),
            "se": float(np.sqrt(first_cov[1, 1])),
            "n_obs": int(n_industries),
        },
        {
            "term": "effective_shocks",
            "estimate": float(1.0 / np.sum(s**2)),
            "se": None,
            "n_obs": int(n_industries),
        },
    ],
    "method_metadata": {
        "estimator": "Weighted 2SLS with intercept; BHJ shock-level aggregation",
        "vcov": "Shock-level heteroskedastic-robust HC1, structural IV residuals, analytic weights",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file, indent=2, allow_nan=False)
