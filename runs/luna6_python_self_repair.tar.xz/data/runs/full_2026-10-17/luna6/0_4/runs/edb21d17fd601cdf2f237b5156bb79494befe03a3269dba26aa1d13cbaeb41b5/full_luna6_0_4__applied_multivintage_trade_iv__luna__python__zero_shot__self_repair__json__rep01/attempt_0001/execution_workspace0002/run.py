import json
import pandas as pd
import numpy as np

crosswalk = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv")
areas = pd.read_csv("areas.csv")
employment = pd.read_csv("employment.csv")
outcomes = pd.read_csv("outcomes.csv")

# Attach each trade code to its industry.
trade = trade.merge(
    crosswalk[["code", "industry"]],
    on="code",
    how="inner",
    validate="many_to_one",
)

industries = crosswalk["industry"].drop_duplicates().tolist()

# Complete the area-period-vintage-industry grid so omitted cells equal zero.
grid = areas[["area", "period", "vintage"]].drop_duplicates().merge(
    pd.DataFrame({"industry": industries}),
    how="cross",
)
employment_complete = grid.merge(
    employment[["area", "period", "vintage", "industry", "employment"]],
    on=["area", "period", "vintage", "industry"],
    how="left",
    validate="one_to_one",
)
employment_complete["employment"] = employment_complete["employment"].fillna(0.0)

# Sum employment across all supplied areas for each period, vintage, and industry.
national = (
    employment_complete.groupby(
        ["period", "vintage", "industry"], as_index=False
    )["employment"]
    .sum()
    .rename(columns={"employment": "national_employment"})
)

def build_exposure(vintage, trade_change, output_name):
    area_rows = areas.loc[areas["vintage"].eq(vintage)].copy()
    components = area_rows[
        ["area", "period", "total_employment"]
    ].merge(
        employment_complete.loc[
            employment_complete["vintage"].eq(vintage),
            ["area", "period", "industry", "employment"],
        ],
        on=["area", "period"],
        how="left",
        validate="many_to_many",
    )
    components = components.merge(
        national.loc[national["vintage"].eq(vintage)],
        on=["period", "industry"],
        how="left",
        validate="many_to_one",
    )
    components = components.merge(
        trade[["period", "industry", trade_change, "price_index", "years"]],
        on=["period", "industry"],
        how="left",
        validate="many_to_one",
    )

    components[output_name] = (
        (components["employment"] / components["total_employment"])
        * (components[trade_change] / components["national_employment"])
        / (components["price_index"] / 100.0)
        / 1000.0
        * (10.0 / components["years"])
    )
    return components.groupby(["area", "period"], as_index=False)[output_name].sum()

x = build_exposure("base", "us_change", "x")
z = build_exposure("early", "other_change", "z")

data = (
    outcomes.merge(x, on=["area", "period"], how="inner", validate="one_to_one")
    .merge(z, on=["area", "period"], how="inner", validate="one_to_one")
    .merge(
        areas.loc[
            areas["vintage"].eq("base"),
            ["area", "period", "population"],
        ],
        on=["area", "period"],
        how="inner",
        validate="one_to_one",
    )
)

# Convert period labels to numeric values for the period regressor.
period_values = data["period"]
if not pd.api.types.is_numeric_dtype(period_values):
    period_values = pd.to_numeric(period_values)
data["period_indicator"] = period_values.astype(float)

y = data["change_pp"].to_numpy(dtype=float)
X_exog = np.column_stack(
    [
        np.ones(len(data)),
        data["period_indicator"].to_numpy(dtype=float),
        data["control"].to_numpy(dtype=float),
    ]
)
endog = data["x"].to_numpy(dtype=float)
instrument = data["z"].to_numpy(dtype=float)
weights = data["population"].to_numpy(dtype=float)

# Weighted 2SLS with all exogenous regressors included as instruments.
sqrt_w = np.sqrt(weights)
Xw = X_exog * sqrt_w[:, None]
yw = y * sqrt_w
xw = endog * sqrt_w
zw = instrument * sqrt_w

projection_coefficients = np.linalg.lstsq(Xw, np.column_stack([yw, xw, zw]), rcond=None)[0]
residualized = np.column_stack([yw, xw, zw]) - Xw @ projection_coefficients
y_tilde, x_tilde, z_tilde = residualized.T
denominator = z_tilde @ x_tilde
if np.isclose(denominator, 0.0):
    raise ValueError("The excluded instrument does not identify the endogenous regressor.")
beta_x = float((z_tilde @ y_tilde) / denominator)

def select_value(frame, area, period, column):
    match = frame.loc[
        frame["area"].eq(area) & frame["period"].eq(period), column
    ]
    if len(match) != 1:
        raise ValueError(f"Expected one value for area={area}, period={period}, column={column}.")
    return float(match.iloc[0])

exposure_area0_period0 = select_value(x, 0, 0, "x")
exposure_area0_period1 = select_value(x, 0, 1, "x")
instrument_area0_period0 = select_value(z, 0, 0, "z")

sample_count = int(len(data))
estimates = [
    {"term": "iv_slope", "estimate": beta_x, "se": None, "n_obs": sample_count},
    {"term": "exposure_area0_period0", "estimate": exposure_area0_period0, "se": None, "n_obs": sample_count},
    {"term": "exposure_area0_period1", "estimate": exposure_area0_period1, "se": None, "n_obs": sample_count},
    {"term": "instrument_area0_period0", "estimate": instrument_area0_period0, "se": None, "n_obs": sample_count},
]

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "outcome": "change_pp",
        "endogenous_regressor": "x",
        "excluded_instrument": "z",
        "exogenous_regressors": ["intercept", "period", "control"],
        "instruments": ["intercept", "period", "control", "z"],
        "weight": "base-vintage population",
        "exposure_units": "thousands of real dollars per worker per decade",
    },
    "diagnostics": {
        "n_obs": sample_count,
        "declared_sample_count": 72,
        "area_period_rows": sample_count,
    },
}

with open("result.json", "w", encoding="utf-8") as result_file:
    json.dump(result, result_file, indent=2)
