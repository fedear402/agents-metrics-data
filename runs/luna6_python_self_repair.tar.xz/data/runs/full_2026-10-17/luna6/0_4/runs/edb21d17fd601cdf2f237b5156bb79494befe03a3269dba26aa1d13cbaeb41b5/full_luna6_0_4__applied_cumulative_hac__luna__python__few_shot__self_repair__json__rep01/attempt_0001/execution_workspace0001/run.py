import json

import numpy as np
import pandas as pd

data = pd.read_csv("input.csv", parse_dates=["date"])
data = data.sort_values("date").reset_index(drop=True)

data["volatility_change"] = np.log(data["vix"]).diff()
for lag in range(1, 16):
    data[f"lag_{lag}"] = data["volatility_change"].shift(lag)
data["log_sales"] = np.log(data["sales"])

regressors = [f"lag_{lag}" for lag in range(1, 16)]
sample = data.dropna(subset=["log_sales", *regressors])
N = len(sample)

X = np.column_stack(
    [np.ones(N)] + [sample[name].to_numpy() for name in regressors]
)
y = sample["log_sales"].to_numpy()

coefficients = np.linalg.lstsq(X, y, rcond=None)[0]
residuals = y - X @ coefficients

scores = X * residuals[:, None]
meat = scores.T @ scores
for lag in range(1, 16):
    weight = 1 - lag / 16
    lag_product = scores[lag:].T @ scores[:-lag]
    meat += weight * (lag_product + lag_product.T)

bread = np.linalg.inv(X.T @ X)
covariance = (N / (N - 16)) * bread @ meat @ bread

cumulative_contrast = np.zeros(16)
cumulative_contrast[1:] = 1
rows = [
    {
        "term": "cumulative_response",
        "estimate": float(cumulative_contrast @ coefficients),
        "se": float(np.sqrt(cumulative_contrast @ covariance @ cumulative_contrast)),
        "n_obs": int(N),
    },
    {
        "term": "lag_1",
        "estimate": float(coefficients[1]),
        "se": float(np.sqrt(covariance[1, 1])),
        "n_obs": int(N),
    },
    {
        "term": "lag_15",
        "estimate": float(coefficients[15]),
        "se": float(np.sqrt(covariance[15, 15])),
        "n_obs": int(N),
    },
]

output = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": rows,
    "method_metadata": {
        "estimator": "OLS on log sales with an intercept and 15 observed-row lags of first differences in log vix",
        "vcov": "Newey-West HAC with Bartlett weights through lag 15 and N/(N-16) correction",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
