import json
from pathlib import Path

import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS

crosswalk = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv")
areas = pd.read_csv("areas.csv")
employment = pd.read_csv("employment.csv")
outcomes = pd.read_csv("outcomes.csv")

# Map trade codes to industries, then map those industries to employment codes.
trade = trade.merge(
    crosswalk[["code", "industry"]].drop_duplicates(),
    on="code",
    how="inner",
    validate="many_to_one",
)

base_areas = areas.loc[
    areas["vintage"] == "base",
    ["area", "period", "total_employment", "population"],
].copy()

def make_exposure(vintage, change_column):
    period_areas = areas.loc[
        areas["vintage"] == vintage,
        ["area", "period", "total_employment"],
    ].copy()

    emp = employment.loc[employment["vintage"] == vintage].copy()
    emp = emp.merge(
        crosswalk[["code", "industry"]].drop_duplicates(),
        on="industry",
        how="left",
    )

    # Missing area-industry cells count as zero. Sum supplied employment
    # across all areas to form each period-vintage national denominator.
    national = (
        emp.groupby(["period", "industry"], as_index=False)["employment"]
        .sum()
        .rename(columns={"employment": "national_employment"})
    )

    shocks = trade.merge(
        national,
        on=["period", "industry"],
        how="left",
        validate="many_to_one",
    )
    shocks["shock"] = (
        shocks[change_column]
        / shocks["national_employment"]
        / (shocks["price_index"] / 100)
        / 1000
        * (10 / shocks["years"])
    )

    cells = emp.merge(
        shocks[["period", "industry", "shock"]],
        on=["period", "industry"],
        how="left",
        validate="many_to_one",
    )
    contributions = (
        cells.assign(contribution=cells["employment"] * cells["shock"])
        .groupby(["area", "period"], as_index=False)["contribution"]
        .sum()
    )

    result = period_areas.merge(
        contributions,
        on=["area", "period"],
        how="left",
        validate="one_to_one",
    )
    result["value"] = (
        result["contribution"].fillna(0) / result["total_employment"]
    )
    return result[["area", "period", "value"]]

x_values = make_exposure("base", "us_change").rename(columns={"value": "x"})
z_values = make_exposure("early", "other_change").rename(columns={"value": "z"})

data = (
    base_areas.merge(
        outcomes,
        on=["area", "period"],
        how="inner",
        validate="one_to_one",
    )
    .merge(x_values, on=["area", "period"], how="left", validate="one_to_one")
    .merge(z_values, on=["area", "period"], how="left", validate="one_to_one")
    .sort_values(["area", "period"])
    .reset_index(drop=True)
)
data[["x", "z"]] = data[["x", "z"]].fillna(0)

period_values = sorted(data["period"].unique())
period_map = {period: i for i, period in enumerate(period_values)}
exog = pd.DataFrame(
    {
        "intercept": np.ones(len(data)),
        "period": data["period"].map(period_map).astype(float),
        "control": data["control"].astype(float),
    },
    index=data.index,
)

fit = IV2SLS(
    dependent=data["change_pp"].astype(float),
    exog=exog,
    endog=data[["x"]].astype(float),
    instruments=data[["z"]].astype(float),
    weights=data["population"].astype(float),
).fit()

def exposure_at(frame, period):
    value = frame.loc[
        (frame["area"] == 0) & (frame["period"] == period), frame.columns[-1]
    ]
    return float(value.iloc[0])

n_obs = int(len(data))
estimates = [
    {
        "term": "iv_slope",
        "estimate": float(fit.params["x"]),
        "se": None,
        "n_obs": n_obs,
    },
    {
        "term": "exposure_area0_period0",
        "estimate": exposure_at(x_values, period_values[0]),
        "se": None,
        "n_obs": n_obs,
    },
    {
        "term": "exposure_area0_period1",
        "estimate": exposure_at(x_values, period_values[1]),
        "se": None,
        "n_obs": n_obs,
    },
    {
        "term": "instrument_area0_period0",
        "estimate": exposure_at(z_values, period_values[0]),
        "se": None,
        "n_obs": n_obs,
    },
]

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "dependent_variable": "change_pp",
        "endogenous_variable": "x",
        "instrument": "z",
        "exogenous_regressors": ["intercept", "period", "control"],
        "instruments": ["intercept", "period", "control", "z"],
        "weight": "base-vintage population",
        "exposure_units": "thousands of real dollars per worker per decade",
    },
    "diagnostics": {"n_obs": n_obs},
}

with Path("result.json").open("w", encoding="utf-8") as output_file:
    json.dump(result, output_file, indent=2, allow_nan=False)
