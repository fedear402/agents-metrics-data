import json

import numpy as np
import pandas as pd

data = pd.read_csv("input.csv", parse_dates=["date"])
data = data.sort_values("date").reset_index(drop=True)

data["volatility_change"] = np.log(data["vix"]).diff()
data["log_sales"] = np.log(data["sales"])

for lag in range(1, 16):
    data[f"lag_{lag}"] = data["volatility_change"].shift(lag)

lag_columns = [f"lag_{lag}" for lag in range(1, 16)]
sample = data.dropna(subset=["log_sales", *lag_columns]).copy()

y = sample["log_sales"].to_numpy()
X = np.column_stack([np.ones(len(sample)), sample[lag_columns].to_numpy()])
N = len(sample)
p = X.shape[1]

coefficients = np.linalg.lstsq(X, y, rcond=None)[0]
residuals = y - X @ coefficients

scores = X * residuals[:, None]
meat = scores.T @ scores
for j in range(1, 16):
    weight = 1 - j / 16
    lag_product = scores[j:].T @ scores[:-j]
    meat += weight * (lag_product + lag_product.T)

bread = np.linalg.inv(X.T @ X)
covariance = (N / (N - p)) * bread @ meat @ bread

contrast = np.zeros(p)
contrast[1:] = 1.0

estimates = [
    {
        "term": "cumulative_response",
        "estimate": float(contrast @ coefficients),
        "se": float(np.sqrt(contrast @ covariance @ contrast)),
        "n_obs": int(N),
    },
    {
        "term": "lag_1",
        "estimate": float(coefficients[1]),
        "se": float(np.sqrt(covariance[1, 1])),
        "n_obs": int(N),
    },
    {
        "term": "lag_15",
        "estimate": float(coefficients[15]),
        "se": float(np.sqrt(covariance[15, 15])),
        "n_obs": int(N),
    },
]

output = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "OLS with intercept and 15 lagged log volatility changes",
        "vcov": "Newey-West HAC, Bartlett maximum lag 15, finite-sample correction N/(N-16)",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
