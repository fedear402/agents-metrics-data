import json
import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS

households = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

d = households.loc[households["recipient"] == 0].copy()
eligible = d["eligible"].astype(float)
ineligible = 1.0 - eligible

exog = pd.DataFrame(
    {
        "ineligible": ineligible,
        "eligible": eligible,
        "baseline_ineligible": d["baseline"] * ineligible,
        "baseline_eligible": d["baseline"] * eligible,
    },
    index=d.index,
)
endog = pd.DataFrame(
    {
        "dose_ineligible": d["dose"] * ineligible,
        "dose_eligible": d["dose"] * eligible,
    },
    index=d.index,
)
instruments = pd.DataFrame(
    {
        **exog.to_dict(orient="series"),
        "instrument_ineligible": d["instrument"] * ineligible,
        "instrument_eligible": d["instrument"] * eligible,
    },
    index=d.index,
)

fit = IV2SLS(
    dependent=d["outcome"],
    exog=exog,
    endog=endog,
    instruments=instruments,
    weights=d["weight"],
).fit()

ineligible_mean_dose = np.average(
    d.loc[d["eligible"] == 0, "dose"],
    weights=d.loc[d["eligible"] == 0, "weight"],
)
eligible_mean_dose = np.average(
    d.loc[d["eligible"] == 1, "dose"],
    weights=d.loc[d["eligible"] == 1, "weight"],
)

ineligible_effect = float(fit.params["dose_ineligible"] * ineligible_mean_dose)
eligible_nonrecipient_effect = float(
    fit.params["dose_eligible"] * eligible_mean_dose
)

population_weights = census.set_index("eligible")["nonrecipient_population"]
population_effect = float(
    np.average(
        [ineligible_effect, eligible_nonrecipient_effect],
        weights=[
            population_weights.loc[0],
            population_weights.loc[1],
        ],
    )
)

n_obs = int(len(d))
result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "ineligible_effect",
            "estimate": ineligible_effect,
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "eligible_nonrecipient_effect",
            "estimate": eligible_nonrecipient_effect,
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "population_effect",
            "estimate": population_effect,
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "weight_variable": "weight",
        "retained_sample": "all households with recipient=0",
        "endogenous_columns": [
            "dose*(1-eligible)",
            "dose*eligible",
        ],
        "exogenous_columns": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
        ],
        "instrument_columns": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
            "instrument*(1-eligible)",
            "instrument*eligible",
        ],
        "within_group_effect": "fitted dose slope times household-weighted mean dose",
        "counterfactual": "dose set to zero for every retained household",
        "attribution_convention": "synthetic convention",
        "population_weights_source": "census.csv nonrecipient_population",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "n_ineligible_nonrecipient": int((d["eligible"] == 0).sum()),
        "n_eligible_nonrecipient": int((d["eligible"] == 1).sum()),
    },
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, allow_nan=False)
