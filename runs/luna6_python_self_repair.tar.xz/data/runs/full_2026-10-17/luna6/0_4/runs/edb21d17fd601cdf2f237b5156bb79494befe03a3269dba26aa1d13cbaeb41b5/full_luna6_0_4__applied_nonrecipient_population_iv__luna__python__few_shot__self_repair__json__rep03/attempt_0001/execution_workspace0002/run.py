import json
import numpy as np
import pandas as pd

households = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

d = households.loc[households["recipient"] == 0].copy()
d["ineligible"] = 1.0 - d["eligible"].astype(float)
d["eligible_group"] = d["eligible"].astype(float)
d["dose_ineligible"] = d["dose"] * d["ineligible"]
d["dose_eligible"] = d["dose"] * d["eligible_group"]

# Fit weighted 2SLS directly. The excluded instruments are residualized
# against the exogenous columns, which avoids duplicate exogenous columns
# in the instrument matrix.
x = np.column_stack([
    d["ineligible"],
    d["eligible_group"],
    d["baseline"] * d["ineligible"],
    d["baseline"] * d["eligible_group"],
])
z_excluded = np.column_stack([
    d["instrument"] * d["ineligible"],
    d["instrument"] * d["eligible_group"],
])
endog = np.column_stack([d["dose_ineligible"], d["dose_eligible"]])
y = d["outcome"].to_numpy(dtype=float)
w = d["weight"].to_numpy(dtype=float)

sqrt_w = np.sqrt(w)
xw = x * sqrt_w[:, None]
zw = z_excluded * sqrt_w[:, None]
endog_w = endog * sqrt_w[:, None]
yw = y * sqrt_w

# The full instrument matrix consists of the exogenous columns plus the
# excluded instruments. Compute the weighted 2SLS coefficient by projection.
z = np.column_stack([x, z_excluded])
zw_full = z * sqrt_w[:, None]
if np.linalg.matrix_rank(zw_full) < zw_full.shape[1]:
    raise ValueError("Weighted instrument matrix is rank deficient.")

projected_x = zw_full @ np.linalg.lstsq(zw_full, xw, rcond=None)[0]
projected_endog = zw_full @ np.linalg.lstsq(zw_full, endog_w, rcond=None)[0]
projected_y = zw_full @ np.linalg.lstsq(zw_full, yw, rcond=None)[0]

design_w = np.column_stack([xw, endog_w])
projected_design = np.column_stack([projected_x, projected_endog])
beta = np.linalg.solve(
    projected_design.T @ design_w,
    projected_design.T @ projected_y,
)

ineligible_slope = float(beta[x.shape[1]])
eligible_slope = float(beta[x.shape[1] + 1])

ineligible_rows = d["eligible"].to_numpy() == 0
eligible_rows = d["eligible"].to_numpy() == 1

ineligible_mean_dose = float(np.average(
    d.loc[ineligible_rows, "dose"],
    weights=d.loc[ineligible_rows, "weight"],
))
eligible_mean_dose = float(np.average(
    d.loc[eligible_rows, "dose"],
    weights=d.loc[eligible_rows, "weight"],
))

ineligible_effect = ineligible_slope * ineligible_mean_dose
eligible_nonrecipient_effect = eligible_slope * eligible_mean_dose

census_weights = census.set_index("eligible")["nonrecipient_population"]
population_effect = float(np.average(
    [ineligible_effect, eligible_nonrecipient_effect],
    weights=[census_weights.loc[0], census_weights.loc[1]],
))

n_obs = int(len(d))

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {"term": "ineligible_effect", "estimate": float(ineligible_effect), "se": None, "n_obs": n_obs},
        {"term": "eligible_nonrecipient_effect", "estimate": float(eligible_nonrecipient_effect), "se": None, "n_obs": n_obs},
        {"term": "population_effect", "estimate": population_effect, "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "retained_sample": "households with recipient == 0",
        "exogenous_columns": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
        ],
        "endogenous_columns": ["dose*(1-eligible)", "dose*eligible"],
        "instruments": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
            "instrument*(1-eligible)",
            "instrument*eligible",
        ],
        "regression_weight": "weight",
        "within_group_dose_average": "household-weighted mean dose",
        "final_group_weights": "nonrecipient_population from census.csv",
        "counterfactual": "Set dose to zero for every retained household; attribution is a synthetic convention.",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "ineligible_slope": ineligible_slope,
        "eligible_slope": eligible_slope,
        "ineligible_weighted_mean_dose": ineligible_mean_dose,
        "eligible_weighted_mean_dose": eligible_mean_dose,
        "ineligible_nonrecipient_population": int(census_weights.loc[0]),
        "eligible_nonrecipient_population": int(census_weights.loc[1]),
    },
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, allow_nan=False)
