import json
import pandas as pd
import numpy as np

data = pd.read_csv("input.csv")
inside = data.loc[data["score"].abs() < 1].copy()

score = inside["score"].to_numpy(dtype=float)
right = (score >= 0).astype(float)
weights = 1 - np.abs(score)

# Separate local-linear fits on each side, with side-specific intercepts and slopes.
design = np.column_stack([
    1 - right,
    (1 - right) * score,
    right,
    right * score,
])
outcomes = inside[["earnings", "participated"]].to_numpy(dtype=float)

weighted_design = design * weights[:, None]
bread = np.linalg.inv(design.T @ weighted_design)
coefficients = bread @ design.T @ (weights[:, None] * outcomes)
residuals = outcomes - design @ coefficients

# Right limit minus left limit for each outcome.
contrast = np.array([-1.0, 0.0, 1.0, 0.0])
jumps = contrast @ coefficients

# HC0 covariance of the two discontinuity estimates, using shared observations.
loading = weights * (design @ bread @ contrast)
influence = loading[:, None] * residuals
joint_covariance = influence.T @ influence

reduced_form, first_stage = jumps
treatment_effect = reduced_form / first_stage
gradient = np.array([1.0 / first_stage, -reduced_form / first_stage**2])
treatment_effect_se = float(np.sqrt(gradient @ joint_covariance @ gradient))
n_obs = int(len(inside))

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {
            "term": "treatment_effect",
            "estimate": float(treatment_effect),
            "se": treatment_effect_se,
            "n_obs": n_obs,
        },
        {
            "term": "reduced_form",
            "estimate": float(reduced_form),
            "se": float(np.sqrt(joint_covariance[0, 0])),
            "n_obs": n_obs,
        },
        {
            "term": "first_stage",
            "estimate": float(first_stage),
            "se": float(np.sqrt(joint_covariance[1, 1])),
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "triangular_weighted_local_linear_fuzzy_rd",
        "vcov": "HC0",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
