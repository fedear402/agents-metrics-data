import json

import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
sample = df.loc[df["score"].abs() < 1].copy()
score = sample["score"].to_numpy(dtype=float)
participated = sample["participated"].to_numpy(dtype=float)
earnings = sample["earnings"].to_numpy(dtype=float)

weights = 1.0 - np.abs(score)
right = (score >= 0).astype(float)
# Separate intercepts and local-linear slopes on each side.
design = np.column_stack(
    [
        1.0 - right,
        (1.0 - right) * score,
        right,
        right * score,
    ]
)

sqrt_weights = np.sqrt(weights)
weighted_design = design * sqrt_weights[:, None]
bread = np.linalg.inv(weighted_design.T @ weighted_design)

outcomes = np.column_stack([earnings, participated])
weighted_outcomes = outcomes * sqrt_weights[:, None]
coefficients = bread @ weighted_design.T @ weighted_outcomes

# Right-limit minus left-limit is the difference between side intercepts.
contrast = np.array([-1.0, 0.0, 1.0, 0.0])
discontinuities = contrast @ coefficients
residuals = outcomes - design @ coefficients

# Joint HC0 covariance for the two outcomes, preserving their covariance.
meat = (design * weights[:, None]).T @ (
    design * (residuals[:, 0] * residuals[:, 1])[:, None]
)
# The expression above gives the cross-outcome meat; compute each element
# of the joint intercept-contrast covariance directly.
influence = (contrast @ bread @ design.T) * weights
covariance = np.array(
    [
        [
            np.sum(influence**2 * residuals[:, i] * residuals[:, j])
            for j in range(2)
        ]
        for i in range(2)
    ]
)

reduced_form = float(discontinuities[0])
first_stage = float(discontinuities[1])
treatment_effect = reduced_form / first_stage

var_reduced_form = covariance[0, 0]
var_first_stage = covariance[1, 1]
cov_rf_fs = covariance[0, 1]
se_reduced_form = float(np.sqrt(max(var_reduced_form, 0.0)))
se_first_stage = float(np.sqrt(max(var_first_stage, 0.0)))

gradient = np.array([1.0 / first_stage, -reduced_form / (first_stage**2)])
var_treatment_effect = float(gradient @ covariance @ gradient)
se_treatment_effect = float(np.sqrt(max(var_treatment_effect, 0.0)))

n_obs = int(len(sample))
result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {
            "term": "treatment_effect",
            "estimate": treatment_effect,
            "se": se_treatment_effect,
            "n_obs": n_obs,
        },
        {
            "term": "reduced_form",
            "estimate": reduced_form,
            "se": se_reduced_form,
            "n_obs": n_obs,
        },
        {
            "term": "first_stage",
            "estimate": first_stage,
            "se": se_first_stage,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "Fuzzy RD local linear regression, cutoff 0, bandwidth 1, triangular weights",
        "vcov": "HC0 sandwich covariance with joint outcome covariance; delta method for ratio",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file, indent=2, allow_nan=False)
