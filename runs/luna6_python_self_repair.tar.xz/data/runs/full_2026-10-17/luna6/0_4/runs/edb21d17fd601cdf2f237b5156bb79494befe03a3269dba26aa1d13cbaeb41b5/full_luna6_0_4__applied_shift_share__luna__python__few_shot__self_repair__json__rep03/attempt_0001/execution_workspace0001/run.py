import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")

# Keep one row per region to normalize regional weights and obtain regional data.
regions = df[["region_id", "region_weight", "x", "y"]].drop_duplicates("region_id").copy()
regions["e"] = regions["region_weight"] / regions["region_weight"].sum()

# Build the regional shift-share instrument from region-industry rows.
industry_shocks = df[["industry_id", "shock"]].drop_duplicates("industry_id")
assert industry_shocks["industry_id"].is_unique
assert df.groupby("industry_id")["shock"].nunique().max() == 1

shares = df[["region_id", "industry_id", "share", "shock"]].copy()
shares["instrument_component"] = shares["share"] * shares["shock"]
z = shares.groupby("region_id", as_index=False)["instrument_component"].sum()
z = z.rename(columns={"instrument_component": "z"})

regions = regions.merge(z, on="region_id", validate="one_to_one")
e = regions["e"].to_numpy()
x = regions["x"].to_numpy()
y = regions["y"].to_numpy()
z = regions["z"].to_numpy()

def weighted_mean(values, weights):
    return float(np.sum(weights * values))

y0 = y - weighted_mean(y, e)
x0 = x - weighted_mean(x, e)
z0 = z - weighted_mean(z, e)

# Aggregate centered regional variables to industry exposure means.
regional_centered = regions[["region_id"]].copy()
regional_centered["e"] = e
regional_centered["y0"] = y0
regional_centered["x0"] = x0
regional_centered["z0"] = z0

long = df.merge(regional_centered, on="region_id", validate="many_to_one")
long["weighted_share"] = long["e"] * long["share"]
long["wy"] = long["weighted_share"] * long["y0"]
long["wx"] = long["weighted_share"] * long["x0"]
long["wz"] = long["weighted_share"] * long["z0"]

agg = long.groupby("industry_id", as_index=False).agg(
    s=("weighted_share", "sum"),
    wy=("wy", "sum"),
    wx=("wx", "sum"),
    wz=("wz", "sum"),
)
if (agg["s"] <= 0).any():
    raise ValueError("Every included industry must have positive exposure mass.")

agg["ybar"] = agg["wy"] / agg["s"]
agg["xbar"] = agg["wx"] / agg["s"]
agg["zbar"] = agg["wz"] / agg["s"]
agg = agg.merge(industry_shocks, on="industry_id", validate="one_to_one")

def weighted_shock_iv(dependent, endogenous, instrument, weights):
    """Weighted IV with intercept and HC1 covariance using structural residuals."""
    n = len(dependent)
    regressors = np.column_stack([np.ones(n), endogenous])
    instruments = np.column_stack([np.ones(n), instrument])
    cross = instruments.T @ (weights[:, None] * regressors)
    inverse = np.linalg.inv(cross)
    beta = inverse @ (instruments.T @ (weights * dependent))
    residual = dependent - regressors @ beta
    scores = instruments * (weights * residual)[:, None]
    covariance = (n / (n - 2)) * inverse @ (scores.T @ scores) @ inverse.T
    return float(beta[1]), float(np.sqrt(covariance[1, 1]))

s = agg["s"].to_numpy()
n_industries = len(agg)
if n_industries <= 2:
    raise ValueError("At least three industries are required for the specified HC1 variance.")

effect, effect_se = weighted_shock_iv(
    agg["ybar"].to_numpy(),
    agg["xbar"].to_numpy(),
    agg["shock"].to_numpy(),
    s,
)
first_stage, first_stage_se = weighted_shock_iv(
    agg["xbar"].to_numpy(),
    agg["zbar"].to_numpy(),
    agg["shock"].to_numpy(),
    s,
)
effective_shocks = float(1.0 / np.sum(s**2))

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": effect, "se": effect_se, "n_obs": n_industries},
        {"term": "first_stage", "estimate": first_stage, "se": first_stage_se, "n_obs": n_industries},
        {"term": "effective_shocks", "estimate": effective_shocks, "se": None, "n_obs": n_industries},
    ],
    "method_metadata": {
        "estimator": "regional weighted 2SLS with Borusyak-Hull-Jaravel shock-level aggregation",
        "vcov": "shock-level HC1 using structural IV residuals and analytic exposure weights",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
