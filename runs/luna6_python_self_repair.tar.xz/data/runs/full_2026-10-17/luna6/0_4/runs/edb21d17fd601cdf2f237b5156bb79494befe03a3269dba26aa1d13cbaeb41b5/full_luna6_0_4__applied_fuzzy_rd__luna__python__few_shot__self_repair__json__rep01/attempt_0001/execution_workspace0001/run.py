import json

import numpy as np
import pandas as pd

data = pd.read_csv("input.csv")
sample = data.loc[data["score"].abs() < 1].copy()
n_obs = int(len(sample))

score = sample["score"].to_numpy(dtype=float)
right = (score >= 0).astype(float)
weights = 1.0 - np.abs(score)

# Separate local-linear regressions on either side of the cutoff.
X = np.column_stack([
    np.ones(n_obs),
    right,
    score * (1.0 - right),
    score * right,
])

Y = sample[["earnings", "participated"]].to_numpy(dtype=float)
weighted_x = weights[:, None] * X
bread = np.linalg.inv(X.T @ weighted_x)
coefficients = bread @ (X.T @ (weights[:, None] * Y))
residuals = Y - X @ coefficients

# The right-minus-left limit difference is the coefficient on `right`.
contrast = np.array([0.0, 1.0, 0.0, 0.0])
discontinuities = contrast @ coefficients

# HC0 covariance, jointly calculated for both outcomes on the same observations.
loading = weights * (X @ bread @ contrast)
influence = loading[:, None] * residuals
joint_covariance = influence.T @ influence

reduced_form, first_stage = discontinuities
treatment_effect = reduced_form / first_stage
gradient = np.array([1.0 / first_stage, -reduced_form / first_stage**2])
treatment_se = float(np.sqrt(gradient @ joint_covariance @ gradient))

rows = [
    {
        "term": "treatment_effect",
        "estimate": float(treatment_effect),
        "se": treatment_se,
        "n_obs": n_obs,
    },
    {
        "term": "reduced_form",
        "estimate": float(reduced_form),
        "se": float(np.sqrt(joint_covariance[0, 0])),
        "n_obs": n_obs,
    },
    {
        "term": "first_stage",
        "estimate": float(first_stage),
        "se": float(np.sqrt(joint_covariance[1, 1])),
        "n_obs": n_obs,
    },
]

output = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": rows,
    "method_metadata": {
        "estimator": "weighted local-linear fuzzy regression discontinuity",
        "vcov": "HC0, no degrees-of-freedom correction",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
