import json
import pandas as pd
from statsmodels.tsa.arima.model import ARIMA

data = pd.read_csv("./input.csv")
y = pd.to_numeric(data["y"], errors="raise").dropna()

fit = ARIMA(
    y,
    order=(1, 1, 1),
    trend="n",
    enforce_stationarity=True,
    enforce_invertibility=True,
).fit()

prediction = fit.get_forecast(steps=1)
forecast = float(prediction.predicted_mean.iloc[0])
interval = prediction.conf_int(alpha=0.05)
lower = float(interval.iloc[0, 0])
upper = float(interval.iloc[0, 1])
forecast_se = float(prediction.se_mean.iloc[0])

out = {
    "task_id": "arima_forecast",
    "platform": "python",
    "estimates": [
        {"term": "forecast", "estimate": forecast, "se": forecast_se, "n_obs": int(fit.nobs)},
        {"term": "lower_95", "estimate": lower, "se": None, "n_obs": int(fit.nobs)},
        {"term": "upper_95", "estimate": upper, "se": None, "n_obs": int(fit.nobs)},
    ],
    "method_metadata": {
        "estimator": "ARIMA(1,1,1) maximum likelihood, no constant or drift",
        "vcov": "model-based prediction interval",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(out, f)
