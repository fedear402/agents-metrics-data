import json
import numpy as np
import pandas as pd
from scipy.stats import f

df = pd.read_csv("input.csv")
n = len(df)

y = df["y"].to_numpy(dtype=float)
endog = df["endog"].to_numpy(dtype=float)
x = df["x"].to_numpy(dtype=float)
z1 = df["z1"].to_numpy(dtype=float)
z2 = df["z2"].to_numpy(dtype=float)

# Regress y - beta*endog on [intercept, x, z1, z2].
W = np.column_stack([np.ones(n), x, z1, z2])
bread = np.linalg.inv(W.T @ W)
resid_y = y - W @ (bread @ (W.T @ y))
resid_endog = endog - W @ (bread @ (W.T @ endog))
z_idx = [2, 3]
q = 2
df_den = n - 4
critical = f.ppf(0.95, q, df_den)

# The joint F statistic is a quadratic in beta:
# F(beta) = (a - beta*b)' C (a - beta*b) / (q * s2(beta)),
# where s2(beta) is the unrestricted residual variance estimate.
# Equivalently, use the residualized excluded instruments and form the
# restricted and unrestricted sums of squares.
Z = W[:, z_idx]
M = np.eye(n) - W @ bread @ W.T
# Numerically stable residualized instrument cross-products.
Rz = M @ Z
G = Rz.T @ Rz
Ginv = np.linalg.inv(G)
a = Rz.T @ y
b = Rz.T @ endog

# Residual sum of squares in the full model at beta.
rss0 = lambda beta: float(np.dot(resid_y - beta * resid_endog,
                                  resid_y - beta * resid_endog))
# Explained sum of squares from adding z1,z2.
ess = lambda beta: float((a - beta * b) @ Ginv @ (a - beta * b))

# F(beta) <= critical iff
# (rss0 - rss_full)/q divided by rss_full/(n-4) <= critical.
# Rearrange to a quadratic inequality in beta.
# rss_full = rss0 - ess.
# (n-4)*ess <= (q*critical)*(rss0 - ess).
# Thus (n-4 + q*critical)*ess - (n-4)*rss0 <= 0.
# Compute polynomial coefficients from evaluations / quadratic forms.
# rss0(beta) = r0 - 2*r1*beta + r2*beta^2.
r0 = float(resid_y @ resid_y)
r1 = float(resid_y @ resid_endog)
r2 = float(resid_endog @ resid_endog)

# ess(beta) = e0 - 2*e1*beta + e2*beta^2.
e0 = float(a @ Ginv @ a)
e1 = float(a @ Ginv @ b)
e2 = float(b @ Ginv @ b)

scale = df_den + q * critical
coef2 = scale * e2 - df_den * r2
coef1 = -2.0 * scale * e1 + 2.0 * df_den * r1
coef0 = scale * e0 - df_den * r0

roots = np.roots([coef2, coef1, coef0])
real_roots = sorted(float(root.real) for root in roots if abs(root.imag) < 1e-8)
if len(real_roots) != 2:
    raise RuntimeError(f"Expected two finite AR boundaries, got {roots}")

boundary_low, boundary_high = real_roots

def ar_f(beta):
    rss = rss0(beta)
    explained = ess(beta)
    full_rss = rss - explained
    return (explained / q) / (full_rss / df_den)

accepts_zero = int(ar_f(0.0) <= critical)
# The leading coefficient of the inequality determines whether the accepted
# set extends to either infinity. The task states there are two finite bounds.
unbounded = int(coef2 < 0)

estimates = [
    ("boundary_low", boundary_low),
    ("boundary_high", boundary_high),
    ("accepts_zero", accepts_zero),
    ("unbounded", unbounded),
    ("ar_f_at_one", ar_f(1.0)),
]

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": [
        {
            "term": term,
            "estimate": float(value),
            "se": None,
            "n_obs": int(n),
        }
        for term, value in estimates
    ],
    "method_metadata": {
        "estimator": "Anderson-Rubin test inversion, homoskedastic joint F test",
        "vcov": "conventional homoskedastic",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as f_out:
    json.dump(result, f_out, indent=2)
