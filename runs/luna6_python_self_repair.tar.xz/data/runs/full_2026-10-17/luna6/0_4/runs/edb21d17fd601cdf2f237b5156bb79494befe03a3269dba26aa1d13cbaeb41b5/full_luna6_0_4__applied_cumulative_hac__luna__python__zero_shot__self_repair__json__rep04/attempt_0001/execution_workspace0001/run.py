import json

import pandas as pd
import statsmodels.api as sm
from statsmodels.stats.sandwich_covariance import cov_hac

df = pd.read_csv("input.csv", parse_dates=["date"])
df = df.sort_values("date").reset_index(drop=True)

df["vol_change"] = df["vix"].apply(lambda x: __import__("math").log(x)).diff()
for lag in range(1, 16):
    df[f"lag_{lag}"] = df["vol_change"].shift(lag)

regression_df = df.dropna(subset=[f"lag_{lag}" for lag in range(1, 16)] + ["sales"]).copy()
y = regression_df["sales"].apply(lambda x: __import__("math").log(x))
X = sm.add_constant(regression_df[[f"lag_{lag}" for lag in range(1, 16)]])
model = sm.OLS(y, X).fit()

n_obs = int(len(regression_df))
covariance = cov_hac(model, nlags=15, weights_func=lambda nlags: [
    1.0 - lag / 16.0 for lag in range(nlags + 1)
])
covariance *= n_obs / (n_obs - 16)

coefficients = model.params
cumulative_estimate = float(coefficients[[f"lag_{lag}" for lag in range(1, 16)]].sum())
lag1_estimate = float(coefficients["lag_1"])
lag15_estimate = float(coefficients["lag_15"])

lag_names = [f"lag_{lag}" for lag in range(1, 16)]
cumulative_variance = float(covariance.loc[lag_names, lag_names].to_numpy().sum())

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {
            "term": "cumulative_response",
            "estimate": cumulative_estimate,
            "se": float(cumulative_variance**0.5) if cumulative_variance >= 0 else None,
            "n_obs": n_obs,
        },
        {
            "term": "lag_1",
            "estimate": lag1_estimate,
            "se": float(covariance.loc["lag_1", "lag_1"] ** 0.5),
            "n_obs": n_obs,
        },
        {
            "term": "lag_15",
            "estimate": lag15_estimate,
            "se": float(covariance.loc["lag_15", "lag_15"] ** 0.5),
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "OLS of log(sales) on intercept and lags 1-15 of first differences in log(vix)",
        "vcov": "Newey-West HAC, Bartlett weights 1-j/16, maximum lag 15, scaled by N/(N-16)",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, allow_nan=False)
