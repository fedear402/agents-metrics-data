import json
import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS

households = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

d = households.loc[households["recipient"] == 0].copy()
n_obs = int(len(d))

eligible = d["eligible"].astype(float)
ineligible = 1.0 - eligible

exog = pd.DataFrame(
    {
        "ineligible": ineligible,
        "eligible": eligible,
        "baseline_ineligible": d["baseline"] * ineligible,
        "baseline_eligible": d["baseline"] * eligible,
    },
    index=d.index,
)
endog = pd.DataFrame(
    {
        "dose_ineligible": d["dose"] * ineligible,
        "dose_eligible": d["dose"] * eligible,
    },
    index=d.index,
)
instruments = pd.DataFrame(
    {
        **exog.to_dict(orient="series"),
        "instrument_ineligible": d["instrument"] * ineligible,
        "instrument_eligible": d["instrument"] * eligible,
    },
    index=d.index,
)

fit = IV2SLS(
    dependent=d["outcome"],
    exog=exog,
    endog=endog,
    instruments=instruments[[
        "ineligible",
        "eligible",
        "baseline_ineligible",
        "baseline_eligible",
        "instrument_ineligible",
        "instrument_eligible",
    ]],
    weights=d["weight"],
).fit()

ineligible_slope = float(fit.params["dose_ineligible"])
eligible_slope = float(fit.params["dose_eligible"])

ineligible_rows = d["eligible"] == 0
eligible_rows = d["eligible"] == 1

ineligible_effect = ineligible_slope * float(
    np.average(d.loc[ineligible_rows, "dose"], weights=d.loc[ineligible_rows, "weight"])
)
eligible_nonrecipient_effect = eligible_slope * float(
    np.average(d.loc[eligible_rows, "dose"], weights=d.loc[eligible_rows, "weight"])
)

population_weights = census.set_index("eligible")["nonrecipient_population"]
population_effect = float(
    np.average(
        [ineligible_effect, eligible_nonrecipient_effect],
        weights=[
            population_weights.loc[0],
            population_weights.loc[1],
        ],
    )
)

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {"term": "ineligible_effect", "estimate": float(ineligible_effect), "se": None, "n_obs": n_obs},
        {
            "term": "eligible_nonrecipient_effect",
            "estimate": float(eligible_nonrecipient_effect),
            "se": None,
            "n_obs": n_obs,
        },
        {"term": "population_effect", "estimate": population_effect, "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "Weighted 2SLS",
        "counterfactual": "Set dose to zero for every retained nonrecipient household; attribution is a stated synthetic convention.",
        "group_effect_definition": "Fitted group dose slope multiplied by the household-weighted mean dose within that eligibility group.",
        "population_aggregation": "Census nonrecipient_population counts determine only the final between-group weights.",
        "sample": "All household rows with recipient equal to zero, including ineligible households in both village treatment statuses.",
        "regressors": {
            "endogenous": ["dose*(1-eligible)", "dose*eligible"],
            "exogenous": [
                "1-eligible",
                "eligible",
                "baseline*(1-eligible)",
                "baseline*eligible",
            ],
            "instruments": [
                "1-eligible",
                "eligible",
                "baseline*(1-eligible)",
                "baseline*eligible",
                "instrument*(1-eligible)",
                "instrument*eligible",
            ],
            "additional_intercept": False,
            "weight": "weight",
        },
    },
    "diagnostics": {
        "n_obs": n_obs,
        "ineligible_dose_slope": ineligible_slope,
        "eligible_dose_slope": eligible_slope,
        "ineligible_weighted_mean_dose": float(
            np.average(d.loc[ineligible_rows, "dose"], weights=d.loc[ineligible_rows, "weight"])
        ),
        "eligible_weighted_mean_dose": float(
            np.average(d.loc[eligible_rows, "dose"], weights=d.loc[eligible_rows, "weight"])
        ),
    },
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, allow_nan=False)
