import json
import pandas as pd
from scipy import stats

data = pd.read_csv("./input.csv")
data = data[["group", "y"]].dropna()

groups = [g["y"].to_numpy() for _, g in data.groupby("group", sort=False)]
F, p_value = stats.f_oneway(*groups)
df_num = len(groups) - 1
df_den = len(data) - len(groups)
n_obs = len(data)

out = {
    "task_id": "anova_oneway",
    "platform": "python",
    "estimates": [
        {"term": "F", "estimate": float(F), "se": None, "n_obs": n_obs},
        {"term": "df_num", "estimate": float(df_num), "se": None, "n_obs": n_obs},
        {"term": "df_den", "estimate": float(df_den), "se": None, "n_obs": n_obs},
        {"term": "p_value", "estimate": float(p_value), "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "One-way ANOVA",
        "vcov": "classical homoskedastic ANOVA",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(out, f)
