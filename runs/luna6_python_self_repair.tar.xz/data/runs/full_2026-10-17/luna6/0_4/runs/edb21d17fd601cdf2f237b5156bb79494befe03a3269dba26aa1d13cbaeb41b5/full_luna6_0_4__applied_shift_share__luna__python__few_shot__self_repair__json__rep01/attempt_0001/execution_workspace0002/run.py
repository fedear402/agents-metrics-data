import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")

# Use one row per region to normalize regional weights and read regional outcomes.
regions = df.drop_duplicates("region_id").copy()
regions["e"] = regions["region_weight"] / regions["region_weight"].sum()

region_weights = regions.set_index("region_id")["e"]
region_x = regions.set_index("region_id")["x"]
region_y = regions.set_index("region_id")["y"]

# Check that each industry has one constant shock.
shock_counts = df.groupby("industry_id")["shock"].nunique()
if not shock_counts.eq(1).all():
    raise ValueError("shock must be constant within industry")

shock_by_industry = df.groupby("industry_id")["shock"].first()

shares = df.pivot_table(
    index="region_id",
    columns="industry_id",
    values="share",
    aggfunc="sum",
    fill_value=0.0,
).reindex(
    index=region_weights.index,
    columns=shock_by_industry.index,
    fill_value=0.0,
)

share_array = shares.to_numpy(dtype=float)
shock = shock_by_industry.reindex(shares.columns).to_numpy(dtype=float)
e = region_weights.reindex(shares.index).to_numpy(dtype=float)
x = region_x.reindex(shares.index).to_numpy(dtype=float)
y = region_y.reindex(shares.index).to_numpy(dtype=float)
z = share_array @ shock

# Center all regional variables with normalized regional weights.
y0 = y - np.sum(e * y)
x0 = x - np.sum(e * x)
z0 = z - np.sum(e * z)

# Compute industry exposure masses and aggregated centered variables.
s = e @ share_array
if np.any(s <= 0):
    raise ValueError("Each industry must have positive exposure mass")

def aggregate(v0):
    return (share_array.T @ (e * v0)) / s

ybar = aggregate(y0)
xbar = aggregate(x0)
zbar = aggregate(z0)
n_industries = int(len(s))

if n_industries <= 2:
    raise ValueError("HC1 multiplier requires more than two industries")

def weighted_iv_hc1(dependent, endogenous, instrument):
    """Weighted IV slope and HC1 SE with structural IV residuals."""
    regressors = np.column_stack(
        [np.ones(n_industries), np.asarray(endogenous, dtype=float)]
    )
    instruments = np.column_stack(
        [np.ones(n_industries), np.asarray(instrument, dtype=float)]
    )
    dependent = np.asarray(dependent, dtype=float)

    cross = instruments.T @ (s[:, None] * regressors)
    beta = np.linalg.solve(cross, instruments.T @ (s * dependent))

    residual = dependent - regressors @ beta
    scores = instruments * (s * residual)[:, None]
    inverse = np.linalg.inv(cross)
    covariance = (
        n_industries / (n_industries - 2)
        * inverse
        @ (scores.T @ scores)
        @ inverse.T
    )
    return float(beta[1]), float(np.sqrt(covariance[1, 1]))

effect, effect_se = weighted_iv_hc1(ybar, xbar, shock)
first_stage, first_stage_se = weighted_iv_hc1(xbar, zbar, shock)
effective_shocks = float(1.0 / np.sum(s**2))

output = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {
            "term": "effect",
            "estimate": effect,
            "se": effect_se,
            "n_obs": n_industries,
        },
        {
            "term": "first_stage",
            "estimate": first_stage,
            "se": first_stage_se,
            "n_obs": n_industries,
        },
        {
            "term": "effective_shocks",
            "estimate": effective_shocks,
            "se": None,
            "n_obs": n_industries,
        },
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS with Borusyak-Hull-Jaravel shock-level aggregation",
        "vcov": "shock-level HC1 with structural IV residuals and analytic weights",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
