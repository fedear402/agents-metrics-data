import json
import numpy as np
import pandas as pd

crosswalk = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv")
areas = pd.read_csv("areas.csv")
employment = pd.read_csv("employment.csv")
outcomes = pd.read_csv("outcomes.csv")

trade = trade.merge(crosswalk[["code", "industry"]], on="code", how="inner", validate="many_to_one")

# Missing area-industry employment cells have zero employment.
area_rows = areas.merge(
    outcomes[["area", "period", "control", "change_pp"]],
    on=["area", "period"],
    how="inner",
    validate="one_to_one",
)
employment_wide = employment.pivot_table(
    index=["area", "period", "vintage"],
    columns="industry",
    values="employment",
    aggfunc="sum",
    fill_value=0,
)

def exposure(row, vintage, change_column):
    period = row["period"]
    period_trade = trade.loc[trade["period"] == period]
    price_index = float(period_trade["price_index"].iloc[0])
    years = float(period_trade["years"].iloc[0])

    exp = 0.0
    for _, tr in period_trade.iterrows():
        industry = tr["industry"]
        key = (row["area"], period, vintage)
        area_industry_employment = float(employment_wide.at[key, industry]) if key in employment_wide.index and industry in employment_wide.columns else 0.0
        base_total = float(
            areas.loc[
                (areas["area"] == row["area"])
                & (areas["period"] == period)
                & (areas["vintage"] == vintage),
                "total_employment",
            ].iloc[0]
        )
        national_base_employment = float(
            employment.loc[
                (employment["period"] == period)
                & (employment["vintage"] == vintage)
                & (employment["industry"] == industry),
                "employment",
            ].sum()
        )
        exp += (
            (area_industry_employment / base_total)
            * (float(tr[change_column]) / national_base_employment)
            / (price_index / 100.0)
            / 1000.0
            * (10.0 / years)
        )
    return exp

area_rows["x"] = area_rows.apply(lambda r: exposure(r, "base", "us_change"), axis=1)
area_rows["z"] = area_rows.apply(lambda r: exposure(r, "early", "other_change"), axis=1)
area_rows["period_numeric"] = pd.to_numeric(area_rows["period"], errors="coerce")
if area_rows["period_numeric"].isna().any():
    period_codes, _ = pd.factorize(area_rows["period"], sort=True)
    area_rows["period_numeric"] = period_codes.astype(float)

# Weighted 2SLS: regress each column on all instruments, then solve weighted
# normal equations for the second stage.
y = area_rows["change_pp"].to_numpy(dtype=float)
X = np.column_stack(
    [
        np.ones(len(area_rows)),
        area_rows["period_numeric"].to_numpy(dtype=float),
        area_rows["control"].to_numpy(dtype=float),
        area_rows["x"].to_numpy(dtype=float),
    ]
)
Z = np.column_stack([X[:, :3], area_rows["z"].to_numpy(dtype=float)])
weights = area_rows.merge(
    areas.loc[areas["vintage"] == "base", ["area", "period", "population"]],
    on=["area", "period"],
    how="left",
    validate="many_to_one",
)["population"].to_numpy(dtype=float)

sqrt_w = np.sqrt(weights)
Zw = Z * sqrt_w[:, None]
Xw = X * sqrt_w[:, None]
yw = y * sqrt_w
projected_X = Zw @ np.linalg.lstsq(Zw, Xw, rcond=None)[0]
projected_y = Zw @ np.linalg.lstsq(Zw, yw, rcond=None)[0]
beta = np.linalg.lstsq(Xw.T @ projected_X, Xw.T @ projected_y, rcond=None)[0]

area0_p0 = area_rows.loc[(area_rows["area"] == 0) & (area_rows["period"] == 0)].iloc[0]
area0_p1 = area_rows.loc[(area_rows["area"] == 0) & (area_rows["period"] == 1)].iloc[0]

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [
        {"term": "iv_slope", "estimate": float(beta[3]), "se": None, "n_obs": 72},
        {"term": "exposure_area0_period0", "estimate": float(area0_p0["x"]), "se": None, "n_obs": 72},
        {"term": "exposure_area0_period1", "estimate": float(area0_p1["x"]), "se": None, "n_obs": 72},
        {"term": "instrument_area0_period0", "estimate": float(area0_p0["z"]), "se": None, "n_obs": 72},
    ],
    "method_metadata": {
        "estimator": "weighted_2sls",
        "outcome": "change_pp",
        "regressors": ["intercept", "period", "control", "x"],
        "endogenous_regressor": "x",
        "instruments": ["intercept", "period", "control", "z"],
        "weight": "base-vintage population",
        "exposure_units": "thousands of real dollars per worker per decade",
        "trade_change_convention": "nominal dollars over the stated interval",
    },
    "diagnostics": {
        "n_obs": 72,
        "n_industries": 4,
        "missing_employment_cells_filled_with_zero": True,
    },
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2)
