import json

import numpy as np
import pandas as pd
from scipy.stats import f

data = pd.read_csv("input.csv")
y = data["y"].to_numpy(dtype=float)
endog = data["endog"].to_numpy(dtype=float)
x = data["x"].to_numpy(dtype=float)
z1 = data["z1"].to_numpy(dtype=float)
z2 = data["z2"].to_numpy(dtype=float)

n = len(data)
q = 2
df = n - 4
critical = f.ppf(0.95, q, df)

restricted = np.column_stack([np.ones(n), x])
unrestricted = np.column_stack([np.ones(n), x, z1, z2])

def residual_sum_squares(response, design):
    residual = response - design @ np.linalg.lstsq(design, response, rcond=None)[0]
    return float(residual @ residual)

# For each beta, the restricted model omits z1 and z2; the unrestricted
# model includes them. The AR acceptance condition is a quadratic in beta.
ry = y - restricted @ np.linalg.lstsq(restricted, y, rcond=None)[0]
rd = endog - restricted @ np.linalg.lstsq(restricted, endog, rcond=None)[0]
uy = y - unrestricted @ np.linalg.lstsq(unrestricted, y, rcond=None)[0]
ud = endog - unrestricted @ np.linalg.lstsq(unrestricted, endog, rcond=None)[0]

k = q * critical / df
A = float(rd @ rd - (1.0 + k) * (ud @ ud))
B = float(-2.0 * (ry @ rd - (1.0 + k) * (uy @ ud)))
C = float(ry @ ry - (1.0 + k) * (uy @ uy))

discriminant = B * B - 4.0 * A * C
if A == 0.0 or discriminant < 0.0:
    raise ValueError("The AR confidence set does not have two finite boundary points.")

boundaries = np.sort(np.roots([A, B, C]).real)

def accepts(beta):
    return A * beta * beta + B * beta + C <= 0.0

def ar_f(beta):
    response = y - beta * endog
    ssr_restricted = residual_sum_squares(response, restricted)
    ssr_unrestricted = residual_sum_squares(response, unrestricted)
    return ((ssr_restricted - ssr_unrestricted) / q) / (ssr_unrestricted / df)

rows = [
    {"term": "boundary_low", "estimate": float(boundaries[0]), "se": None, "n_obs": n},
    {"term": "boundary_high", "estimate": float(boundaries[1]), "se": None, "n_obs": n},
    {"term": "accepts_zero", "estimate": int(accepts(0.0)), "se": None, "n_obs": n},
    {"term": "unbounded", "estimate": int(A < 0.0), "se": None, "n_obs": n},
    {"term": "ar_f_at_one", "estimate": float(ar_f(1.0)), "se": None, "n_obs": n},
]

with open("result.json", "w") as stream:
    json.dump(
        {
            "task_id": "broad_ar_confidence_set",
            "platform": "python",
            "estimates": rows,
            "method_metadata": {
                "estimator": "Anderson-Rubin confidence set by inversion of the homoskedastic joint F test",
                "vcov": "homoskedastic",
            },
            "diagnostics": {},
        },
        stream,
        indent=2,
        allow_nan=False,
    )
