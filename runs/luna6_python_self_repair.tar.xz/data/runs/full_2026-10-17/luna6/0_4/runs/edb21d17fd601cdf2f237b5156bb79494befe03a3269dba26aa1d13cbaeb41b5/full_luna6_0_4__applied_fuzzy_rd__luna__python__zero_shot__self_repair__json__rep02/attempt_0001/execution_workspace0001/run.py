import json
import numpy as np
import pandas as pd

data = pd.read_csv("input.csv")

score = data["score"].to_numpy(dtype=float)
earnings = data["earnings"].to_numpy(dtype=float)
participated = data["participated"].to_numpy(dtype=float)

inside = np.abs(score) < 1
x = score[inside]
y = earnings[inside]
d = participated[inside]
n_obs = int(inside.sum())

weights = 1 - np.abs(x)
right = (x >= 0).astype(float)

# Separate local-linear fits on each side, parameterized as side-specific
# intercepts and slopes. This gives the right-minus-left intercept jump.
design = np.column_stack([
    1 - right,
    (1 - right) * x,
    right,
    right * x,
])
sqrt_weights = np.sqrt(weights)
weighted_design = design * sqrt_weights[:, None]

bread = np.linalg.inv(weighted_design.T @ weighted_design)

def fit_jump(outcome):
    beta = bread @ (weighted_design.T @ (outcome * sqrt_weights))
    residual = outcome - design @ beta
    scores = design * (weights * residual)[:, None]
    covariance = bread @ (scores.T @ scores) @ bread
    jump = beta[2] - beta[0]
    contrast = np.array([-1.0, 0.0, 1.0, 0.0])
    jump_variance = float(contrast @ covariance @ contrast)
    return float(jump), covariance, jump_variance

reduced_form, cov_y, var_y = fit_jump(y)
first_stage, cov_d, var_d = fit_jump(d)

# HC0 cross-covariance between the two jump estimates, using the same rows
# and weights for both outcomes.
resid_y = y - design @ (bread @ (weighted_design.T @ (y * sqrt_weights)))
resid_d = d - design @ (bread @ (weighted_design.T @ (d * sqrt_weights)))
scores_y = design * (weights * resid_y)[:, None]
scores_d = design * (weights * resid_d)[:, None]
cross_cov = bread @ (scores_y.T @ scores_d) @ bread
contrast = np.array([-1.0, 0.0, 1.0, 0.0])
cov_rf_fs = float(contrast @ cross_cov @ contrast)

if first_stage == 0:
    treatment_effect = None
    treatment_se = None
else:
    treatment_effect = reduced_form / first_stage
    gradient = np.array([1.0 / first_stage, -reduced_form / (first_stage ** 2)])
    joint_cov = np.array([[var_y, cov_rf_fs], [cov_rf_fs, var_d]])
    variance = float(gradient @ joint_cov @ gradient)
    treatment_se = float(np.sqrt(max(variance, 0.0)))

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {
            "term": "treatment_effect",
            "estimate": treatment_effect,
            "se": treatment_se,
            "n_obs": n_obs,
        },
        {
            "term": "reduced_form",
            "estimate": reduced_form,
            "se": float(np.sqrt(max(var_y, 0.0))),
            "n_obs": n_obs,
        },
        {
            "term": "first_stage",
            "estimate": first_stage,
            "se": float(np.sqrt(max(var_d, 0.0))),
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "Fuzzy RD local-linear WLS, cutoff 0, bandwidth 1, triangular weights, separate slopes",
        "vcov": "HC0 heteroskedasticity-robust sandwich; delta method with joint reduced-form/first-stage covariance",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file, allow_nan=False)
