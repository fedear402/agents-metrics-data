import json

import pandas as pd
from statsmodels.tsa.arima.model import ARIMA

data = pd.read_csv("./input.csv")
y = data["y"].astype(float)

model = ARIMA(
    y,
    order=(1, 1, 1),
    trend="n",
    enforce_stationarity=True,
    enforce_invertibility=True,
)
fit = model.fit(method="statespace", method_kwargs={"disp": 0})

prediction = fit.get_forecast(steps=1)
forecast = float(prediction.predicted_mean.iloc[0])
interval = prediction.conf_int(alpha=0.05)
lower_95 = float(interval.iloc[0, 0])
upper_95 = float(interval.iloc[0, 1])

result = {
    "task_id": "arima_forecast",
    "platform": "python",
    "estimates": [
        {"term": "forecast", "estimate": forecast, "se": None, "n_obs": int(fit.nobs)},
        {"term": "lower_95", "estimate": lower_95, "se": None, "n_obs": int(fit.nobs)},
        {"term": "upper_95", "estimate": upper_95, "se": None, "n_obs": int(fit.nobs)},
    ],
    "method_metadata": {
        "estimator": "Maximum likelihood ARIMA(1,1,1) state-space fit, no constant or drift",
        "vcov": "State-space one-step-ahead forecast prediction interval",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file, indent=2, allow_nan=False)
