import json

import numpy as np
import pandas as pd

data = pd.read_csv("input.csv", parse_dates=["date"])
data = data.sort_values("date").reset_index(drop=True)

data["volatility_change"] = np.log(data["vix"]).diff()
for lag in range(1, 16):
    data[f"lag_{lag}"] = data["volatility_change"].shift(lag)
data["log_sales"] = np.log(data["sales"])

lag_columns = [f"lag_{lag}" for lag in range(1, 16)]
sample = data.dropna(subset=["log_sales", *lag_columns])
N = len(sample)

X = np.column_stack(
    [np.ones(N)] + [sample[column].to_numpy() for column in lag_columns]
)
y = sample["log_sales"].to_numpy()

coefficients = np.linalg.lstsq(X, y, rcond=None)[0]
residuals = y - X @ coefficients

scores = X * residuals[:, None]
meat = scores.T @ scores
for j in range(1, 16):
    weight = 1 - j / 16
    lag_product = scores[j:].T @ scores[:-j]
    meat += weight * (lag_product + lag_product.T)

bread = np.linalg.inv(X.T @ X)
covariance = (N / (N - 16)) * bread @ meat @ bread

cumulative_contrast = np.r_[0.0, np.ones(15)]
terms = [
    ("cumulative_response", cumulative_contrast @ coefficients,
     cumulative_contrast @ covariance @ cumulative_contrast),
    ("lag_1", coefficients[1], covariance[1, 1]),
    ("lag_15", coefficients[15], covariance[15, 15]),
]

output = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {
            "term": term,
            "estimate": float(estimate),
            "se": float(np.sqrt(variance)),
            "n_obs": int(N),
        }
        for term, estimate, variance in terms
    ],
    "method_metadata": {
        "estimator": "OLS with intercept and 15 lags of log VIX first differences",
        "vcov": "Newey-West HAC, Bartlett maximum lag 15, correction N/(N-16)",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
