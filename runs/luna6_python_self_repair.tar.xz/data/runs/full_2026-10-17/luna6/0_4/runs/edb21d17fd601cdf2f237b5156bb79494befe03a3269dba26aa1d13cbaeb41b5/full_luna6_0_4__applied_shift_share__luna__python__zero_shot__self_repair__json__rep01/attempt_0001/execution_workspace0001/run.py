import json
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("input.csv")

# Keep one row per region for regional outcomes and weights.
regions = df.drop_duplicates("region_id").copy()
weights = regions["region_weight"].astype(float)
regions["e"] = weights / weights.sum()

# Construct the regional shift-share instrument from all region-industry rows.
df = df.merge(regions[["region_id", "e"]], on="region_id", how="left")
df["share"] = df["share"].astype(float)
df["shock"] = df["shock"].astype(float)
df["weighted_exposure"] = df["e"] * df["share"]

z = (
    df.assign(exposure_shock=df["share"] * df["shock"])
    .groupby("region_id", as_index=False)["exposure_shock"]
    .sum()
    .rename(columns={"exposure_shock": "z"})
)
regions = regions.merge(z, on="region_id", how="left")

# Demean regional variables using normalized regional weights.
for variable in ("y", "x", "z"):
    mean = (regions["e"] * regions[variable]).sum()
    regions[f"{variable}0"] = regions[variable] - mean

# Construct industry exposure weights and shock-level aggregates.
df = df.merge(
    regions[["region_id", "y0", "x0", "z0"]],
    on="region_id",
    how="left",
)
df["e_share"] = df["e"] * df["share"]
industry = (
    df.groupby("industry_id", as_index=False)
    .agg(
        s=("e_share", "sum"),
        shock=("shock", "first"),
        y_num=("e_share", lambda a: (a * df.loc[a.index, "y0"]).sum()),
        x_num=("e_share", lambda a: (a * df.loc[a.index, "x0"]).sum()),
        z_num=("e_share", lambda a: (a * df.loc[a.index, "z0"]).sum()),
    )
)
industry = industry[industry["s"] > 0].copy()
industry["ybar"] = industry["y_num"] / industry["s"]
industry["xbar"] = industry["x_num"] / industry["s"]
industry["zbar"] = industry["z_num"] / industry["s"]

n_industries = int(len(industry))

def weighted_iv_hc1(outcome, endogenous, instrument):
    """Weighted IV slope and shock-level HC1 standard error."""
    y = industry[outcome].to_numpy(dtype=float)
    x = industry[endogenous].to_numpy(dtype=float)
    q = industry[instrument].to_numpy(dtype=float)
    w = industry["s"].to_numpy(dtype=float)

    # With one excluded instrument and an intercept, the 2SLS coefficient
    # equals the weighted OLS coefficient on the instrumented endogenous
    # variable. Use the equivalent weighted IV sandwich calculation.
    X = sm.add_constant(x)
    Z = sm.add_constant(q)

    w_sqrt = w ** 0.5
    Xw = X * w_sqrt[:, None]
    Zw = Z * w_sqrt[:, None]
    yw = y * w_sqrt

    # 2SLS coefficient using the weighted instrument projection.
    projection = Zw @ __import__("numpy").linalg.inv(Zw.T @ Zw) @ Zw.T
    beta = __import__("numpy").linalg.solve(
        Xw.T @ projection @ Xw,
        Xw.T @ projection @ yw,
    )
    residual = y - X @ beta

    # HC1 sandwich for analytic weights, using structural IV residuals.
    z_wx = Z.T @ (w[:, None] * X)
    bread = __import__("numpy").linalg.inv(X.T @ (w[:, None] * Z)) @ (
        Z.T @ (w[:, None] * X)
    )
    bread = __import__("numpy").linalg.inv(bread)
    score = Z * (w * residual)[:, None]
    meat = score.T @ score
    middle = __import__("numpy").linalg.inv(X.T @ (w[:, None] * Z)) @ meat @ (
        __import__("numpy").linalg.inv(Z.T @ (w[:, None] * X))
    )
    covariance = bread @ middle @ bread * (n_industries / (n_industries - 2))
    return float(beta[1]), float(covariance[1, 1] ** 0.5)

effect, effect_se = weighted_iv_hc1("ybar", "xbar", "shock")
first_stage, first_stage_se = weighted_iv_hc1("xbar", "zbar", "shock")
effective_shocks = float(1.0 / (industry["s"] ** 2).sum())

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {
            "term": "effect",
            "estimate": effect,
            "se": effect_se,
            "n_obs": n_industries,
        },
        {
            "term": "first_stage",
            "estimate": first_stage,
            "se": first_stage_se,
            "n_obs": n_industries,
        },
        {
            "term": "effective_shocks",
            "estimate": effective_shocks,
            "se": None,
            "n_obs": n_industries,
        },
    ],
    "method_metadata": {
        "estimator": "Weighted 2SLS with Borusyak-Hull-Jaravel shock-level aggregation",
        "vcov": "Shock-level heteroskedasticity-robust HC1 using structural IV residuals and analytic weights",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file, indent=2)
