import json

import numpy as np
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("input.csv", parse_dates=["date"])
df = df.sort_values("date").reset_index(drop=True)

df["dlog_vix"] = np.log(df["vix"]).diff()
for lag in range(1, 16):
    df[f"lag_{lag}"] = df["dlog_vix"].shift(lag)

regressors = [f"lag_{lag}" for lag in range(1, 16)]
sample = df.dropna(subset=["dlog_vix", "sales", *regressors])

y = np.log(sample["sales"].to_numpy())
X = sm.add_constant(sample[regressors].to_numpy())
ols = sm.OLS(y, X).fit()

n_obs = int(len(sample))
hac_cov = sm.stats.sandwich_covariance.cov_hac(
    ols, nlags=15, weights_func=lambda nlags: 1 - np.arange(nlags + 1) / 16
)
hac_cov *= n_obs / (n_obs - 16)

coefficients = ols.params[1:]
cumulative_estimate = float(coefficients.sum())
cumulative_variance = float(hac_cov[1:, 1:].sum())
cumulative_se = float(np.sqrt(max(cumulative_variance, 0.0)))

estimates = [
    {
        "term": "cumulative_response",
        "estimate": cumulative_estimate,
        "se": cumulative_se,
        "n_obs": n_obs,
    },
    {
        "term": "lag_1",
        "estimate": float(ols.params[1]),
        "se": float(np.sqrt(max(hac_cov[1, 1], 0.0))),
        "n_obs": n_obs,
    },
    {
        "term": "lag_15",
        "estimate": float(ols.params[15]),
        "se": float(np.sqrt(max(hac_cov[15, 15], 0.0))),
        "n_obs": n_obs,
    },
]

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "OLS of log(sales) on an intercept and lags 1 through 15 of first-differenced log(vix)",
        "vcov": "Newey-West HAC with maximum lag 15, Bartlett weights 1-j/16, multiplied by N/(N-16)",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2)
