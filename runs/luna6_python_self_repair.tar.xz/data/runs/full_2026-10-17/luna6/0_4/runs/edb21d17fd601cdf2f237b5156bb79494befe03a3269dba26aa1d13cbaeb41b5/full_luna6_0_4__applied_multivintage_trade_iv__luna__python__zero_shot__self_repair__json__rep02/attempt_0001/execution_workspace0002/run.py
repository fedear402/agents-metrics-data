import json

import numpy as np
import pandas as pd

crosswalk = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv")
areas = pd.read_csv("areas.csv")
employment = pd.read_csv("employment.csv")
outcomes = pd.read_csv("outcomes.csv")

# Attach an industry to each trade row by its trade code.
trade = trade.merge(
    crosswalk[["code", "industry"]],
    on="code",
    how="inner",
    validate="many_to_one",
)

# Combine duplicate employment rows, then fill omitted area-industry cells with zero.
employment_totals = (
    employment.groupby(["area", "period", "vintage", "industry"], as_index=False)["employment"]
    .sum()
)
employment_lookup = {
    (row.area, row.period, row.vintage, row.industry): float(row.employment)
    for row in employment_totals.itertuples(index=False)
}

# Sum employment across all supplied areas for each period, vintage, and industry.
national_employment = (
    employment.groupby(["period", "vintage", "industry"])["employment"]
    .sum()
    .to_dict()
)

# Each area-period appears once in the estimation data.
area_rows = areas.loc[areas["vintage"] == "base"].merge(
    outcomes[["area", "period", "control", "change_pp"]],
    on=["area", "period"],
    how="inner",
    validate="one_to_one",
)

# Add each area-period's early-vintage totals for the instrument exposure.
area_rows = area_rows.merge(
    areas.loc[
        areas["vintage"] == "early",
        ["area", "period", "total_employment"],
    ].rename(columns={"total_employment": "early_total_employment"}),
    on=["area", "period"],
    how="left",
    validate="one_to_one",
)

trade_by_period = {
    period: group.copy()
    for period, group in trade.groupby("period", sort=False)
}

def exposure(area, period, vintage, total_employment, change_column):
    period_trade = trade_by_period[period]
    price_index = float(period_trade["price_index"].iloc[0])
    years = float(period_trade["years"].iloc[0])

    value = 0.0
    for row in period_trade.itertuples(index=False):
        industry = row.industry
        area_employment = employment_lookup.get(
            (area, period, vintage, industry),
            0.0,
        )
        national_base = float(
            national_employment.get((period, vintage, industry), 0.0)
        )
        trade_change = float(getattr(row, change_column))

        value += (
            (area_employment / float(total_employment))
            * (trade_change / national_base)
            / (price_index / 100.0)
            / 1000.0
            * (10.0 / years)
        )
    return value

area_rows["x"] = area_rows.apply(
    lambda row: exposure(
        row["area"],
        row["period"],
        "base",
        row["total_employment"],
        "us_change",
    ),
    axis=1,
)
area_rows["z"] = area_rows.apply(
    lambda row: exposure(
        row["area"],
        row["period"],
        "early",
        row["early_total_employment"],
        "other_change",
    ),
    axis=1,
)

# Use the supplied period values as the period regressor.
period_values = sorted(area_rows["period"].unique())
period_mapping = {value: index for index, value in enumerate(period_values)}
area_rows["period_numeric"] = area_rows["period"].map(period_mapping).astype(float)

y = area_rows["change_pp"].to_numpy(dtype=float)
X = np.column_stack(
    [
        np.ones(len(area_rows)),
        area_rows["period_numeric"].to_numpy(dtype=float),
        area_rows["control"].to_numpy(dtype=float),
        area_rows["x"].to_numpy(dtype=float),
    ]
)
Z = np.column_stack(
    [
        X[:, 0],
        X[:, 1],
        X[:, 2],
        area_rows["z"].to_numpy(dtype=float),
    ]
)
weights = area_rows["population"].to_numpy(dtype=float)

# Solve weighted 2SLS using the weighted instrument projection.
sqrt_weights = np.sqrt(weights)
X_weighted = X * sqrt_weights[:, None]
Z_weighted = Z * sqrt_weights[:, None]
y_weighted = y * sqrt_weights

projection_coefficients = np.linalg.lstsq(
    Z_weighted,
    X_weighted,
    rcond=None,
)[0]
projected_X = Z_weighted @ projection_coefficients
projected_y = Z_weighted @ np.linalg.lstsq(
    Z_weighted,
    y_weighted,
    rcond=None,
)[0]
beta = np.linalg.lstsq(
    X_weighted.T @ projected_X,
    X_weighted.T @ projected_y,
    rcond=None,
)[0]

area0_period0 = area_rows.loc[
    (area_rows["area"] == 0) & (area_rows["period"] == 0)
].iloc[0]
area0_period1 = area_rows.loc[
    (area_rows["area"] == 0) & (area_rows["period"] == 1)
].iloc[0]

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "iv_slope",
            "estimate": float(beta[3]),
            "se": None,
            "n_obs": 72,
        },
        {
            "term": "exposure_area0_period0",
            "estimate": float(area0_period0["x"]),
            "se": None,
            "n_obs": 72,
        },
        {
            "term": "exposure_area0_period1",
            "estimate": float(area0_period1["x"]),
            "se": None,
            "n_obs": 72,
        },
        {
            "term": "instrument_area0_period0",
            "estimate": float(area0_period0["z"]),
            "se": None,
            "n_obs": 72,
        },
    ],
    "method_metadata": {
        "estimator": "weighted_2sls",
        "outcome": "change_pp",
        "regressors": ["intercept", "period", "control", "x"],
        "endogenous_regressor": "x",
        "instruments": ["intercept", "period", "control", "z"],
        "weight": "base-vintage population",
        "exposure_units": "thousands of real dollars per worker per decade",
        "trade_change_convention": "nominal dollars over the stated interval",
    },
    "diagnostics": {
        "n_obs": 72,
        "n_industries": 4,
        "missing_employment_cells_filled_with_zero": True,
    },
}

with open("result.json", "w", encoding="utf-8") as output_file:
    json.dump(result, output_file, indent=2)
