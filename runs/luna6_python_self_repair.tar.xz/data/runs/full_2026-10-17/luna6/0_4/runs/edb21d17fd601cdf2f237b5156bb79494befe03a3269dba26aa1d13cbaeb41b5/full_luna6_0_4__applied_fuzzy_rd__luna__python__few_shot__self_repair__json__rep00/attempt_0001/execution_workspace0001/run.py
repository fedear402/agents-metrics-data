import json
import pandas as pd
import numpy as np

df = pd.read_csv("input.csv")
data = df.loc[df["score"].abs() < 1].copy()
n_obs = len(data)

score = data["score"].to_numpy(dtype=float)
right = (score >= 0).astype(float)
weights = 1 - np.abs(score)

# Separate local-linear slopes with side-specific intercepts.
X = np.column_stack([
    np.ones(n_obs),
    right,
    score * (1 - right),
    score * right,
])

bread = np.linalg.inv(X.T @ (weights[:, None] * X))
projection = bread @ X.T
outcomes = data[["earnings", "participated"]].to_numpy(dtype=float)
coefficients = projection @ (weights[:, None] * outcomes)
residuals = outcomes - X @ coefficients

# The coefficient on right is the right-limit minus left-limit discontinuity.
contrast = np.array([0.0, 1.0, 0.0, 0.0])
jumps = contrast @ coefficients

# HC0 joint covariance for the two discontinuity estimates.
loading = weights * (X @ bread @ contrast)
influence = loading[:, None] * residuals
joint_covariance = influence.T @ influence

reduced_form, first_stage = jumps
gradient = np.array([
    1.0 / first_stage,
    -reduced_form / (first_stage ** 2),
])
treatment_effect = reduced_form / first_stage
treatment_se = float(np.sqrt(gradient @ joint_covariance @ gradient))

estimates = [
    {
        "term": "treatment_effect",
        "estimate": float(treatment_effect),
        "se": treatment_se,
        "n_obs": int(n_obs),
    },
    {
        "term": "reduced_form",
        "estimate": float(reduced_form),
        "se": float(np.sqrt(joint_covariance[0, 0])),
        "n_obs": int(n_obs),
    },
    {
        "term": "first_stage",
        "estimate": float(first_stage),
        "se": float(np.sqrt(joint_covariance[1, 1])),
        "n_obs": int(n_obs),
    },
]

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "Triangular-weighted local-linear fuzzy regression discontinuity",
        "vcov": "HC0 joint covariance with delta-method standard error",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
