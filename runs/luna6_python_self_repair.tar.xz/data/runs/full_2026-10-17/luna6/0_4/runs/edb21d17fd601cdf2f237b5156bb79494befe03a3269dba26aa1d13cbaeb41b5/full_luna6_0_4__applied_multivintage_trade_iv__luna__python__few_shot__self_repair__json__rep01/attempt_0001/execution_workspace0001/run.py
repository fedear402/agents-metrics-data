import json
from pathlib import Path

import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS

crosswalk = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv")
areas = pd.read_csv("areas.csv")
employment = pd.read_csv("employment.csv")
outcomes = pd.read_csv("outcomes.csv")

trade = trade.merge(crosswalk, on="code", how="inner", validate="many_to_one")

area_periods = areas[["area", "period", "vintage", "total_employment", "population"]].copy()
base_areas = area_periods.loc[area_periods["vintage"] == "base"].copy()
early_areas = area_periods.loc[area_periods["vintage"] == "early"].copy()

emp = employment.merge(crosswalk[["code", "industry"]] if "code" in employment.columns else crosswalk[["industry"]].drop_duplicates(), on="industry", how="left") if False else employment.copy()

# Sum employment across all supplied areas for each period, vintage, and industry.
national = (
    employment.groupby(["period", "vintage", "industry"], as_index=False)["employment"]
    .sum()
    .rename(columns={"employment": "national_employment"})
)

def make_exposure(vintage, change_column):
    area_rows = area_periods.loc[area_periods["vintage"] == vintage, ["area", "period", "total_employment"]]
    area_emp = employment.loc[employment["vintage"] == vintage].merge(
        area_rows[["area", "period"]], on=["area", "period"], how="inner"
    )
    shocks = trade.merge(
        national.loc[national["vintage"] == vintage],
        on=["period", "industry"],
        how="inner",
        validate="one_to_one",
    )
    shocks["shock"] = (
        shocks[change_column]
        / shocks["national_employment"]
        / (shocks["price_index"] / 100.0)
        / 1000.0
        * (10.0 / shocks["years"])
    )
    contributions = area_emp.merge(
        shocks[["period", "industry", "shock"]],
        on=["period", "industry"],
        how="left",
        validate="many_to_one",
    )
    contributions["contribution"] = contributions["employment"] * contributions["shock"]
    sums = contributions.groupby(["area", "period"], as_index=False)["contribution"].sum()
    totals = area_rows[["area", "period", "total_employment"]]
    sums = sums.merge(totals, on=["area", "period"], how="left", validate="one_to_one")
    sums["exposure"] = sums["contribution"] / sums["total_employment"]
    return sums[["area", "period", "exposure"]]

x = make_exposure("base", "us_change").rename(columns={"exposure": "x"})
z = make_exposure("early", "other_change").rename(columns={"exposure": "z"})

data = (
    outcomes.merge(x, on=["area", "period"], how="inner", validate="one_to_one")
    .merge(z, on=["area", "period"], how="inner", validate="one_to_one")
    .merge(
        base_areas[["area", "period", "population"]],
        on=["area", "period"],
        how="inner",
        validate="one_to_one",
    )
)
data = data.sort_values(["area", "period"]).reset_index(drop=True)

period_values = pd.Categorical(data["period"])
period_dummies = pd.get_dummies(period_values, drop_first=True, dtype=float)
exog = pd.DataFrame(
    {
        "intercept": np.ones(len(data)),
        "period": period_dummies.iloc[:, 0].to_numpy(dtype=float),
        "control": data["control"].to_numpy(dtype=float),
    }
)
fit = IV2SLS(
    dependent=data["change_pp"],
    exog=exog,
    endog=data[["x"]],
    instruments=data[["z"]],
    weights=data["population"],
).fit()

lookup = data.set_index(["area", "period"])
periods = list(pd.unique(data["period"]))
result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [
        {"term": "iv_slope", "estimate": float(fit.params["x"]), "se": None, "n_obs": 72},
        {
            "term": "exposure_area0_period0",
            "estimate": float(lookup.loc[(0, periods[0]), "x"]),
            "se": None,
            "n_obs": 72,
        },
        {
            "term": "exposure_area0_period1",
            "estimate": float(lookup.loc[(0, periods[1]), "x"]),
            "se": None,
            "n_obs": 72,
        },
        {
            "term": "instrument_area0_period0",
            "estimate": float(lookup.loc[(0, periods[0]), "z"]),
            "se": None,
            "n_obs": 72,
        },
    ],
    "method_metadata": {
        "estimator": "weighted_2sls",
        "outcome": "change_pp",
        "endogenous_regressor": "x",
        "excluded_instrument": "z",
        "exogenous_regressors": ["intercept", "period", "control"],
        "exogenous_instruments": ["intercept", "period", "control"],
        "weight": "base-vintage population",
        "exposure_units": "thousands of real dollars per worker per decade",
    },
    "diagnostics": {"n_obs": 72},
}
with Path("result.json").open("w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, allow_nan=False)
