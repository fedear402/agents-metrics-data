import json
import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS

crosswalk = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv")
areas = pd.read_csv("areas.csv")
employment = pd.read_csv("employment.csv")
outcomes = pd.read_csv("outcomes.csv")

trade = trade.merge(crosswalk, on="code", how="inner", validate="many_to_one")
if trade.duplicated(["period", "industry"]).any():
    raise ValueError("Each period and industry must have one trade row.")

base_areas = areas.loc[areas["vintage"] == "base"].copy()
early_areas = areas.loc[areas["vintage"] == "early"].copy()
if base_areas.duplicated(["area", "period"]).any() or early_areas.duplicated(["area", "period"]).any():
    raise ValueError("Area-period totals must be unique within vintage.")

industries = crosswalk["industry"].drop_duplicates().tolist()
if len(industries) != 4:
    raise ValueError("Expected four industries.")

def make_exposure(vintage, change_column, area_totals):
    emp = employment.loc[employment["vintage"] == vintage].copy()
    panel = area_totals[["area", "period", "total_employment"]].merge(
        emp[["area", "period", "industry", "employment"]],
        on=["area", "period"],
        how="left",
    )
    panel["employment"] = panel["employment"].fillna(0.0)
    panel = panel.merge(trade[["period", "industry", change_column, "price_index", "years"]],
                        on=["period", "industry"], how="left", validate="many_to_one")
    if panel[change_column].isna().any():
        raise ValueError("Missing trade data for an area-period industry.")
    national = panel.groupby(["period", "industry"])["employment"].transform("sum")
    if (national <= 0).any():
        raise ValueError("National industry employment must be positive.")
    panel["contribution"] = (
        (panel["employment"] / panel["total_employment"])
        * (panel[change_column] / national)
        / (panel["price_index"] / 100.0)
        / 1000.0
        * (10.0 / panel["years"])
    )
    return panel.groupby(["area", "period"], as_index=False)["contribution"].sum().rename(
        columns={"contribution": "x" if change_column == "us_change" else "z"}
    )

x = make_exposure("base", "us_change", base_areas)
z = make_exposure("early", "other_change", early_areas)

base_weights = base_areas[["area", "period", "population"]]
data = outcomes.merge(x, on=["area", "period"], how="inner", validate="one_to_one")
data = data.merge(z, on=["area", "period"], how="inner", validate="one_to_one")
data = data.merge(base_weights, on=["area", "period"], how="inner", validate="one_to_one")
data = data.sort_values(["area", "period"]).reset_index(drop=True)

period_values = sorted(data["period"].unique())
if len(period_values) != 2:
    raise ValueError("Expected two periods.")
data["period_indicator"] = (data["period"] == period_values[1]).astype(float)

exog = pd.DataFrame({
    "intercept": np.ones(len(data)),
    "period": data["period_indicator"].to_numpy(),
    "control": data["control"].to_numpy(),
})
fit = IV2SLS(
    dependent=data["change_pp"],
    exog=exog,
    endog=data[["x"]],
    instruments=data[["z"]],
    weights=data["population"],
).fit()

def exposure_value(frame, area, period, column):
    row = frame.loc[(frame["area"] == area) & (frame["period"] == period), column]
    if len(row) != 1:
        raise ValueError(f"Expected one {column} value for area {area}, period {period}.")
    return float(row.iloc[0])

period0, period1 = period_values
estimates = [
    {"term": "iv_slope", "estimate": float(fit.params["x"]), "se": None, "n_obs": 72},
    {"term": "exposure_area0_period0", "estimate": exposure_value(x, 0, period0, "x"), "se": None, "n_obs": 72},
    {"term": "exposure_area0_period1", "estimate": exposure_value(x, 0, period1, "x"), "se": None, "n_obs": 72},
    {"term": "instrument_area0_period0", "estimate": exposure_value(z, 0, period0, "z"), "se": None, "n_obs": 72},
]

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "dependent_variable": "change_pp",
        "endogenous_variable": "x",
        "excluded_instrument": "z",
        "exogenous_regressors": ["intercept", "period", "control"],
        "included_instruments": ["intercept", "period", "control", "z"],
        "weight": "base-vintage population",
        "exposure_units": "thousands of real dollars per worker per decade",
    },
    "diagnostics": {"n_obs": 72},
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, allow_nan=False)
