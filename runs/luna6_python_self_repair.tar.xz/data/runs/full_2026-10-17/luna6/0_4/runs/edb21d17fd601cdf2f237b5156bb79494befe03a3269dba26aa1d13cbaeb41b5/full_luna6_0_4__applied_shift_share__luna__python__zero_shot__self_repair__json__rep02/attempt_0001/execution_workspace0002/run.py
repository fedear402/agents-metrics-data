import json

import numpy as np
import pandas as pd


df = pd.read_csv("input.csv")

# Use one row per region to normalize regional weights exactly once.
regions = df[["region_id", "region_weight", "x", "y"]].drop_duplicates(
    "region_id"
).copy()
regions["e"] = regions["region_weight"] / regions["region_weight"].sum()

# Construct the regional shift-share instrument from all region-industry rows.
shares = df[["region_id", "industry_id", "share", "shock"]].copy()
shares["share_shock"] = shares["share"] * shares["shock"]
z = (
    shares.groupby("region_id", as_index=False)["share_shock"]
    .sum()
    .rename(columns={"share_shock": "z"})
)
regions = regions.merge(z, on="region_id", how="inner", validate="one_to_one")

# Remove e-weighted regional means.
for variable in ["y", "x", "z"]:
    mean = (regions["e"] * regions[variable]).sum()
    regions[f"{variable}0"] = regions[variable] - mean

# Aggregate demeaned regional variables to industries.
industry = shares.merge(
    regions[["region_id", "e", "y0", "x0", "z0"]],
    on="region_id",
    how="inner",
    validate="many_to_one",
)
industry["weighted_share"] = industry["e"] * industry["share"]

for variable in ["y0", "x0", "z0"]:
    industry[f"{variable}_numerator"] = (
        industry["weighted_share"] * industry[variable]
    )

shock_data = (
    industry.groupby("industry_id", as_index=False)
    .agg(
        s=("weighted_share", "sum"),
        shock=("shock", "first"),
        y0_numerator=("y0_numerator", "sum"),
        x0_numerator=("x0_numerator", "sum"),
        z0_numerator=("z0_numerator", "sum"),
    )
)
for variable in ["y0", "x0", "z0"]:
    shock_data[f"{variable}_bar"] = (
        shock_data[f"{variable}_numerator"] / shock_data["s"]
    )

# Analytic-weighted 2SLS with intercept and structural-residual HC1 covariance.
def weighted_iv_hc1(outcome, endogenous, instrument, weights):
    y = np.asarray(outcome, dtype=float)
    x = np.asarray(endogenous, dtype=float)
    q = np.asarray(instrument, dtype=float)
    w = np.asarray(weights, dtype=float)

    if not (np.isfinite(y).all() and np.isfinite(x).all()
            and np.isfinite(q).all() and np.isfinite(w).all()):
        raise ValueError("Shock-level inputs must be finite.")
    if np.any(w <= 0):
        raise ValueError("Shock-level analytic weights must be positive.")

    n = len(y)
    if n <= 2:
        raise ValueError("HC1 variance requires more than two industries.")

    instrument_matrix = np.column_stack((np.ones(n), q))
    weighted_instrument_matrix = instrument_matrix * w[:, None]

    # 2SLS: project the endogenous regressor onto the instrument space
    # using the analytic-weighted least-squares criterion.
    first_stage_coef = np.linalg.lstsq(
        weighted_instrument_matrix,
        x * w,
        rcond=None,
    )[0]
    fitted_x = instrument_matrix @ first_stage_coef
    design = np.column_stack((np.ones(n), fitted_x))

    beta = np.linalg.lstsq(
        design * w[:, None],
        y * w,
        rcond=None,
    )[0]

    structural_residual = y - design @ beta
    bread = np.linalg.inv(design.T @ (w[:, None] * design))
    meat = design.T @ (
        ((w**2) * (structural_residual**2))[:, None] * design
    )
    covariance = bread @ meat @ bread * (n / (n - 2))

    return float(beta[1]), float(np.sqrt(covariance[1, 1]))


effect, effect_se = weighted_iv_hc1(
    shock_data["y0_bar"],
    shock_data["x0_bar"],
    shock_data["shock"],
    shock_data["s"],
)
first_stage, first_stage_se = weighted_iv_hc1(
    shock_data["x0_bar"],
    shock_data["z0_bar"],
    shock_data["shock"],
    shock_data["s"],
)

effective_shocks = 1.0 / float((shock_data["s"] ** 2).sum())
n_industries = int(len(shock_data))

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {
            "term": "effect",
            "estimate": effect,
            "se": effect_se,
            "n_obs": n_industries,
        },
        {
            "term": "first_stage",
            "estimate": first_stage,
            "se": first_stage_se,
            "n_obs": n_industries,
        },
        {
            "term": "effective_shocks",
            "estimate": effective_shocks,
            "se": None,
            "n_obs": n_industries,
        },
    ],
    "method_metadata": {
        "estimator": "Analytic-weighted 2SLS with BHJ shock-level aggregation",
        "vcov": "Shock-level HC1 sandwich using structural IV residuals and analytic exposure weights, without clustering",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, allow_nan=False)
