import json
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("input.csv")

# Collapse repeated region-level variables and normalize weights once per region.
regions = df[["region_id", "region_weight", "x", "y"]].drop_duplicates("region_id").copy()
regions["e"] = regions["region_weight"] / regions["region_weight"].sum()

# Build the regional shift-share instrument using all region-industry rows.
shares = df[["region_id", "industry_id", "share", "shock"]].copy()
shares["share_shock"] = shares["share"] * shares["shock"]
z = shares.groupby("region_id", as_index=False)["share_shock"].sum().rename(
    columns={"share_shock": "z"}
)
regions = regions.merge(z, on="region_id", how="inner")

# Demean regional variables using normalized regional weights.
for variable in ["y", "x", "z"]:
    regions[f"{variable}0"] = regions[variable] - (
        regions["e"] * regions[variable]
    ).sum()

# Aggregate regional residuals to industries using analytic exposure weights.
industry = df[["region_id", "industry_id", "share", "shock"]].merge(
    regions[["region_id", "e", "y0", "x0", "z0"]],
    on="region_id",
    how="inner",
)
industry["weighted_share"] = industry["e"] * industry["share"]
aggregations = {}
for variable in ["y0", "x0", "z0"]:
    industry[f"{variable}_numerator"] = industry["weighted_share"] * industry[variable]
    aggregations[f"{variable}_numerator"] = "sum"
aggregations["weighted_share"] = "sum"
aggregations["shock"] = "first"

shock_data = industry.groupby("industry_id", as_index=False).agg(aggregations)
shock_data = shock_data.rename(columns={"weighted_share": "s"})
for variable in ["y0", "x0", "z0"]:
    shock_data[variable.replace("0_numerator", "bar")] = (
        shock_data[f"{variable}_numerator"] / shock_data["s"]
    )

# Fit analytic-weighted shock-level IV using 2SLS and structural-residual HC1.
def weighted_iv_hc1(outcome, endogenous, instrument, weights):
    outcome = outcome.to_numpy(dtype=float)
    endogenous = endogenous.to_numpy(dtype=float)
    instrument = instrument.to_numpy(dtype=float)
    weights = weights.to_numpy(dtype=float)

    n = len(outcome)
    exog = sm.add_constant(instrument)
    weighted_exog = exog * weights[:, None]
    weighted_endog = endogenous * weights
    first_stage = sm.OLS(weighted_endog, weighted_exog).fit()
    fitted_endog = first_stage.fittedvalues / weights

    design = sm.add_constant(fitted_endog)
    weighted_design = design * weights[:, None]
    weighted_outcome = outcome * weights
    beta = pd.Series(
        sm.OLS(weighted_outcome, weighted_design).fit().params,
        index=["const", "slope"],
    ).to_numpy()

    structural_resid = outcome - beta[0] - beta[1] * endogenous
    bread = __import__("numpy").linalg.inv(design.T @ (weights[:, None] * design))
    meat = design.T @ ((weights**2 * structural_resid**2)[:, None] * design)
    covariance = bread @ meat @ bread * (n / (n - 2))
    return float(beta[1]), float(__import__("numpy").sqrt(covariance[1, 1]))

import numpy as np

effect, effect_se = weighted_iv_hc1(
    shock_data["y0_bar"],
    shock_data["x0_bar"],
    shock_data["shock"],
    shock_data["s"],
)

first_stage, first_stage_se = weighted_iv_hc1(
    shock_data["x0_bar"],
    shock_data["z0_bar"],
    shock_data["shock"],
    shock_data["s"],
)

effective_shocks = 1.0 / float((shock_data["s"] ** 2).sum())
n_industries = int(len(shock_data))

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {
            "term": "effect",
            "estimate": effect,
            "se": effect_se,
            "n_obs": n_industries,
        },
        {
            "term": "first_stage",
            "estimate": first_stage,
            "se": first_stage_se,
            "n_obs": n_industries,
        },
        {
            "term": "effective_shocks",
            "estimate": effective_shocks,
            "se": None,
            "n_obs": n_industries,
        },
    ],
    "method_metadata": {
        "estimator": "Weighted 2SLS with regional weights normalized once per region; BHJ shock-level aggregation",
        "vcov": "Shock-level HC1 sandwich using structural IV residuals and analytic exposure weights, no clustering",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, allow_nan=False)
