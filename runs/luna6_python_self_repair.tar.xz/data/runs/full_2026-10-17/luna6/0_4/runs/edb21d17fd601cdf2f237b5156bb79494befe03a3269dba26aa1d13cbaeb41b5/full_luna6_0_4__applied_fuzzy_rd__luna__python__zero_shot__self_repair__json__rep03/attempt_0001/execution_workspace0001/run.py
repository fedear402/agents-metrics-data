import json

import numpy as np
import pandas as pd


def main():
    data = pd.read_csv("input.csv")
    sample = data.loc[data["score"].abs() < 1].copy()
    sample["right"] = (sample["score"] >= 0).astype(float)
    sample["weight"] = 1 - sample["score"].abs()

    x = np.column_stack(
        [
            np.ones(len(sample)),
            sample["score"].to_numpy(),
            sample["right"].to_numpy(),
            (sample["right"] * sample["score"]).to_numpy(),
        ]
    )
    w = sample["weight"].to_numpy()
    xtwx_inv = np.linalg.inv(x.T @ (w[:, None] * x))

    outcomes = sample[["earnings", "participated"]].to_numpy(dtype=float)
    coefficients = xtwx_inv @ x.T @ (w[:, None] * outcomes)
    residuals = outcomes - x @ coefficients

    # HC0 covariance for the joint coefficient vector, retaining cross-outcome
    # covariance from each observation's paired residuals.
    scores = (x * w[:, None])[:, :, None] * residuals[:, None, :]
    meat = np.einsum("nia,njb->ijab", scores, scores)
    bread = xtwx_inv
    cov_joint = np.einsum("ik,kjab,jl->ilab", bread, meat, bread)

    reduced_form = float(coefficients[2, 0])
    first_stage = float(coefficients[2, 1])
    treatment_effect = reduced_form / first_stage

    cov_rf = cov_joint[2, 2, 0, 0]
    cov_fs = cov_joint[2, 2, 1, 1]
    cov_rf_fs = cov_joint[2, 2, 0, 1]

    grad_rf = 1.0 / first_stage
    grad_fs = -reduced_form / (first_stage**2)
    var_treatment = (
        grad_rf**2 * cov_rf
        + grad_fs**2 * cov_fs
        + 2 * grad_rf * grad_fs * cov_rf_fs
    )

    n_obs = int(len(sample))
    result = {
        "task_id": "applied_fuzzy_rd",
        "platform": "python",
        "estimates": [
            {
                "term": "treatment_effect",
                "estimate": treatment_effect,
                "se": float(np.sqrt(max(var_treatment, 0.0))),
                "n_obs": n_obs,
            },
            {
                "term": "reduced_form",
                "estimate": reduced_form,
                "se": float(np.sqrt(max(cov_rf, 0.0))),
                "n_obs": n_obs,
            },
            {
                "term": "first_stage",
                "estimate": first_stage,
                "se": float(np.sqrt(max(cov_fs, 0.0))),
                "n_obs": n_obs,
            },
        ],
        "method_metadata": {
            "estimator": "triangular-weighted local-linear fuzzy regression discontinuity",
            "vcov": "HC0 robust sandwich; delta method with joint covariance",
        },
        "diagnostics": {},
    }

    with open("result.json", "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
