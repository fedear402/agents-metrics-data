import json
import numpy as np
import pandas as pd
from scipy.stats import f

data = pd.read_csv("input.csv")
y = data["y"].to_numpy(dtype=float)
endog = data["endog"].to_numpy(dtype=float)
controls = np.column_stack([np.ones(len(data)), data["x"].to_numpy(dtype=float)])
excluded = data[["z1", "z2"]].to_numpy(dtype=float)
full = np.column_stack([controls, excluded])

n = len(data)
q = excluded.shape[1]
df = n - full.shape[1]
critical = f.ppf(0.95, q, df)
k = q * critical / df

def residual(values, design):
    return values - design @ np.linalg.lstsq(design, values, rcond=None)[0]

ry = residual(y, controls)
rd = residual(endog, controls)
uy = residual(y, full)
ud = residual(endog, full)

A = rd @ rd - (1 + k) * (ud @ ud)
B = -2 * (ry @ rd - (1 + k) * (uy @ ud))
C = ry @ ry - (1 + k) * (uy @ uy)

discriminant = B * B - 4 * A * C
if abs(A) < 1e-12:
    if abs(B) < 1e-12 or discriminant < 0:
        raise ValueError("The Anderson-Rubin set does not have two finite boundaries.")
    boundaries = np.array([-C / B, -C / B])
else:
    if discriminant < 0:
        raise ValueError("The Anderson-Rubin set does not have two finite boundaries.")
    boundaries = np.sort(np.roots([A, B, C]).real)

def accepts(beta):
    return A * beta * beta + B * beta + C <= 0

def ar_f(beta):
    reduced_residual = residual(y - beta * endog, controls)
    unrestricted_residual = residual(y - beta * endog, full)
    ssr_reduced = reduced_residual @ reduced_residual
    ssr_unrestricted = unrestricted_residual @ unrestricted_residual
    return ((ssr_reduced - ssr_unrestricted) / q) / (ssr_unrestricted / df)

rows = [
    {"term": "boundary_low", "estimate": float(boundaries[0]), "se": None, "n_obs": n},
    {"term": "boundary_high", "estimate": float(boundaries[1]), "se": None, "n_obs": n},
    {"term": "accepts_zero", "estimate": int(accepts(0.0)), "se": None, "n_obs": n},
    {"term": "unbounded", "estimate": int(A < 0), "se": None, "n_obs": n},
    {"term": "ar_f_at_one", "estimate": float(ar_f(1.0)), "se": None, "n_obs": n},
]

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": rows,
    "method_metadata": {
        "estimator": "Anderson-Rubin confidence set by inversion of the homoskedastic joint F test for z1 and z2",
        "vcov": "conventional homoskedastic"
    },
    "diagnostics": {}
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
