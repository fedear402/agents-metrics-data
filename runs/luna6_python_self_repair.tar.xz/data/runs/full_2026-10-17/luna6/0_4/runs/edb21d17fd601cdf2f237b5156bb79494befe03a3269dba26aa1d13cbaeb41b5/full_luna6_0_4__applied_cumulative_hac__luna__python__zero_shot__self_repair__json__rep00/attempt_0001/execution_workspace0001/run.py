import json

import numpy as np
import pandas as pd
import statsmodels.api as sm

data = pd.read_csv("input.csv", parse_dates=["date"])
data = data.sort_values("date").reset_index(drop=True)

data["volatility_change"] = np.log(data["vix"]).diff()

for lag in range(1, 16):
    data[f"lag_{lag}"] = data["volatility_change"].shift(lag)

regressors = [f"lag_{lag}" for lag in range(1, 16)]
sample = data.dropna(subset=["sales", *regressors]).copy()

X = sm.add_constant(sample[regressors])
y = np.log(sample["sales"])
fit = sm.OLS(y, X).fit()

n_obs = int(len(sample))
hac_cov = np.asarray(
    sm.stats.sandwich_covariance.cov_hac(
        fit, nlags=15, weights_func=sm.stats.sandwich_covariance.weights_bartlett
    )
)
hac_cov *= n_obs / (n_obs - 16)

coefficients = fit.params
names = ["cumulative_response", "lag_1", "lag_15"]

cumulative_weights = np.zeros(len(fit.params))
for lag in range(1, 16):
    cumulative_weights[fit.params.index.get_loc(f"lag_{lag}")] = 1.0

cumulative_estimate = float(sum(coefficients[f"lag_{lag}"] for lag in range(1, 16)))
cumulative_se = float(np.sqrt(cumulative_weights @ hac_cov @ cumulative_weights))

estimates = [
    {
        "term": "cumulative_response",
        "estimate": cumulative_estimate,
        "se": cumulative_se,
        "n_obs": n_obs,
    }
]

for term in ("lag_1", "lag_15"):
    position = fit.params.index.get_loc(term)
    estimates.append(
        {
            "term": term,
            "estimate": float(coefficients[term]),
            "se": float(np.sqrt(hac_cov[position, position])),
            "n_obs": n_obs,
        }
    )

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "OLS of log(sales) on an intercept and lags 1 through 15 of first differences in log(vix)",
        "vcov": "Newey-West HAC with maximum lag 15, Bartlett weights 1-j/16, and finite-sample multiplier N/(N-16)",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output_file:
    json.dump(result, output_file, indent=2, allow_nan=False)
