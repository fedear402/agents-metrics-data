import json

import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS

households = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

# Retain all nonrecipient households in both village treatment statuses.
data = households.loc[households["recipient"] == 0].copy()
n_obs = int(len(data))

eligible = data["eligible"].astype(float)
ineligible = 1.0 - eligible
weight = data["weight"].astype(float)

exogenous = pd.DataFrame(
    {
        "ineligible": ineligible,
        "eligible": eligible,
        "baseline_ineligible": data["baseline"] * ineligible,
        "baseline_eligible": data["baseline"] * eligible,
    },
    index=data.index,
)

endogenous = pd.DataFrame(
    {
        "dose_ineligible": data["dose"] * ineligible,
        "dose_eligible": data["dose"] * eligible,
    },
    index=data.index,
)

instruments = pd.concat(
    [
        exogenous,
        pd.DataFrame(
            {
                "instrument_ineligible": data["instrument"] * ineligible,
                "instrument_eligible": data["instrument"] * eligible,
            },
            index=data.index,
        ),
    ],
    axis=1,
)

fit = IV2SLS(
    dependent=data["outcome"],
    exog=exogenous,
    endog=endogenous,
    instruments=instruments,
    weights=weight,
).fit()

ineligible_mean_dose = float(
    np.average(data.loc[eligible == 0, "dose"], weights=weight.loc[eligible == 0])
)
eligible_mean_dose = float(
    np.average(data.loc[eligible == 1, "dose"], weights=weight.loc[eligible == 1])
)

ineligible_effect = float(fit.params["dose_ineligible"] * ineligible_mean_dose)
eligible_nonrecipient_effect = float(
    fit.params["dose_eligible"] * eligible_mean_dose
)

population = census.set_index("eligible")["nonrecipient_population"]
pop_ineligible = float(population.loc[0])
pop_eligible = float(population.loc[1])
population_effect = (
    ineligible_effect * pop_ineligible
    + eligible_nonrecipient_effect * pop_eligible
) / (pop_ineligible + pop_eligible)

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "ineligible_effect",
            "estimate": ineligible_effect,
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "eligible_nonrecipient_effect",
            "estimate": eligible_nonrecipient_effect,
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "population_effect",
            "estimate": float(population_effect),
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "weighted_2sls",
        "weight": "weight",
        "endogenous_columns": ["dose*(1-eligible)", "dose*eligible"],
        "exogenous_columns": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
        ],
        "instruments": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
            "instrument*(1-eligible)",
            "instrument*eligible",
        ],
        "intercept": "No additional intercept",
        "counterfactual": "Dose set to zero for every retained household",
        "attribution_convention": (
            "Each group effect is its fitted dose slope times its "
            "household-weighted mean dose. Attribution to a zero-dose "
            "counterfactual is a stated synthetic convention."
        ),
        "population_weights_source": (
            "census.csv nonrecipient_population, used only for final "
            "between-group aggregation"
        ),
    },
    "diagnostics": {
        "n_obs": n_obs,
        "retained_sample": "All household rows with recipient=0",
        "census_used_only_for_final_group_aggregation": True,
    },
}

with open("result.json", "w", encoding="utf-8") as output_file:
    json.dump(result, output_file, indent=2, allow_nan=False)
