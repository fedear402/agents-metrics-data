import json

import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS

crosswalk = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv")
areas = pd.read_csv("areas.csv")
employment = pd.read_csv("employment.csv")
outcomes = pd.read_csv("outcomes.csv")

trade = trade.merge(crosswalk, on="code", how="left", validate="many_to_one")
if trade["industry"].isna().any():
    raise ValueError("Every trade code must map to an industry.")

industries = crosswalk["industry"].drop_duplicates().tolist()
periods = trade["period"].drop_duplicates().tolist()


def build_exposure(period, vintage, change_column):
    area_rows = areas.loc[
        (areas["period"] == period) & (areas["vintage"] == vintage),
        ["area", "total_employment"],
    ].copy()

    emp_rows = employment.loc[
        (employment["period"] == period) & (employment["vintage"] == vintage),
        ["area", "industry", "employment"],
    ].copy()

    grid = (
        area_rows[["area"]].assign(_key=1)
        .merge(pd.DataFrame({"industry": industries, "_key": 1}), on="_key")
        .drop(columns="_key")
    )
    emp = grid.merge(emp_rows, on=["area", "industry"], how="left")
    emp["employment"] = emp["employment"].fillna(0.0)

    national = emp.groupby("industry")["employment"].sum().reindex(industries)
    trade_period = trade.loc[trade["period"] == period]

    if trade_period["industry"].duplicated().any():
        raise ValueError("Each period must have one trade row per industry.")
    if set(trade_period["industry"]) != set(industries):
        raise ValueError("Each period must include a trade row for every industry.")

    prices = trade_period["price_index"].unique()
    years_values = trade_period["years"].unique()
    if len(prices) != 1 or len(years_values) != 1:
        raise ValueError("Price index and years must be constant within period.")

    changes = trade_period.set_index("industry")[change_column].reindex(industries)
    shocks = (
        changes.to_numpy(dtype=float)
        / national.to_numpy(dtype=float)
        / (float(prices[0]) / 100.0)
        / 1000.0
        * (10.0 / float(years_values[0]))
    )

    matrix = emp.pivot(index="area", columns="industry", values="employment")
    matrix = matrix.reindex(columns=industries, fill_value=0.0)
    totals = area_rows.set_index("area")["total_employment"].reindex(matrix.index)
    return pd.Series(
        matrix.to_numpy(dtype=float) @ shocks / totals.to_numpy(dtype=float),
        index=matrix.index,
    )


records = []
for period in periods:
    x_values = build_exposure(period, "base", "us_change")
    z_values = build_exposure(period, "early", "other_change")
    base_rows = areas.loc[
        (areas["period"] == period) & (areas["vintage"] == "base")
    ]
    for row in base_rows.itertuples(index=False):
        records.append({
            "area": row.area,
            "period": period,
            "x": float(x_values.loc[row.area]),
            "z": float(z_values.loc[row.area]),
            "population": float(row.population),
        })

design = pd.DataFrame(records)
data = (
    outcomes.merge(design, on=["area", "period"], how="inner", validate="one_to_one")
)

if len(data) != 72:
    raise ValueError(f"Expected 72 area-period observations, found {len(data)}.")

period_numeric = pd.to_numeric(data["period"], errors="raise").to_numpy(dtype=float)
exog = pd.DataFrame({
    "intercept": np.ones(len(data)),
    "period": period_numeric,
    "control": pd.to_numeric(data["control"], errors="raise").to_numpy(dtype=float),
})

fit = IV2SLS(
    dependent=pd.to_numeric(data["change_pp"], errors="raise"),
    exog=exog,
    endog=pd.to_numeric(data["x"], errors="raise"),
    instruments=pd.to_numeric(data["z"], errors="raise"),
    weights=pd.to_numeric(data["population"], errors="raise"),
).fit()

def get_value(area, period, column):
    match = data.loc[
        (data["area"] == area) & (data["period"] == period), column
    ]
    if len(match) != 1:
        raise ValueError(f"Expected one {column} value for area {area}, period {period}.")
    return float(match.iloc[0])


n_obs = int(len(data))
result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [
        {"term": "iv_slope", "estimate": float(fit.params["x"]), "se": None, "n_obs": n_obs},
        {"term": "exposure_area0_period0", "estimate": get_value(0, 0, "x"), "se": None, "n_obs": n_obs},
        {"term": "exposure_area0_period1", "estimate": get_value(0, 1, "x"), "se": None, "n_obs": n_obs},
        {"term": "instrument_area0_period0", "estimate": get_value(0, 0, "z"), "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "weighted_2sls",
        "dependent_variable": "change_pp",
        "exogenous_variables": ["intercept", "period", "control"],
        "endogenous_variable": "x",
        "excluded_instrument": "z",
        "instruments": ["intercept", "period", "control", "z"],
        "weight": "base-vintage population",
        "exposure_units": "thousands of real dollars per worker per decade",
        "sample_count": n_obs,
    },
    "diagnostics": {
        "n_obs": n_obs,
        "area_period_rows": int(data[["area", "period"]].drop_duplicates().shape[0]),
    },
}

with open("result.json", "w", encoding="utf-8") as output_file:
    json.dump(result, output_file, indent=2, allow_nan=False)
