import json
from pathlib import Path

import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS

crosswalk = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv")
areas = pd.read_csv("areas.csv")
employment = pd.read_csv("employment.csv")
outcomes = pd.read_csv("outcomes.csv")

trade = trade.merge(crosswalk, on="code", how="inner", validate="many_to_one")

area_periods = areas.loc[
    (areas["vintage"] == "base"),
    ["area", "period", "total_employment", "population"],
].copy()

def make_exposure(vintage, change_column):
    emp = employment.loc[employment["vintage"] == vintage].merge(
        crosswalk, on="industry", how="inner", validate="many_to_one"
    )
    national = (
        emp.groupby(["period", "industry"], as_index=False)["employment"]
        .sum()
        .rename(columns={"employment": "national_employment"})
    )
    shocks = trade.merge(
        national, on=["period", "industry"], how="left", validate="many_to_one"
    )
    shocks["shock"] = (
        shocks[change_column]
        / shocks["national_employment"]
        / (shocks["price_index"] / 100)
        / 1000
        * (10 / shocks["years"])
    )
    cell = emp.merge(
        shocks[["period", "industry", "shock"]],
        on=["period", "industry"],
        how="left",
        validate="many_to_one",
    )
    exposure = (
        cell.assign(contribution=cell["employment"] * cell["shock"])
        .groupby(["area", "period"], as_index=False)["contribution"]
        .sum()
    )
    totals = areas.loc[
        areas["vintage"] == vintage, ["area", "period", "total_employment"]
    ]
    exposure = exposure.merge(
        totals, on=["area", "period"], how="right", validate="one_to_one"
    )
    exposure["value"] = exposure["contribution"].fillna(0) / exposure["total_employment"]
    return exposure[["area", "period", "value"]]

x = make_exposure("base", "us_change").rename(columns={"value": "x"})
z = make_exposure("early", "other_change").rename(columns={"value": "z"})

data = (
    area_periods.merge(outcomes, on=["area", "period"], how="inner", validate="one_to_one")
    .merge(x, on=["area", "period"], how="left", validate="one_to_one")
    .merge(z, on=["area", "period"], how="left", validate="one_to_one")
)
data[["x", "z"]] = data[["x", "z"]].fillna(0)
data = data.sort_values(["area", "period"]).reset_index(drop=True)

period_codes, _ = pd.factorize(data["period"], sort=True)
exog = pd.DataFrame(
    {
        "intercept": np.ones(len(data)),
        "period": period_codes.astype(float),
        "control": data["control"].astype(float),
    }
)
fit = IV2SLS(
    dependent=data["change_pp"].astype(float),
    exog=exog,
    endog=data[["x"]].astype(float),
    instruments=data[["z"]].astype(float),
    weights=data["population"].astype(float),
).fit()

def exposure_at(frame, area, period):
    row = frame.loc[(frame["area"] == area) & (frame["period"] == period), "value"]
    return float(row.iloc[0])

periods = sorted(data["period"].unique())
area0_periods = sorted(data.loc[data["area"] == 0, "period"].unique())

estimates = [
    {"term": "iv_slope", "estimate": float(fit.params["x"]), "se": None, "n_obs": 72},
    {
        "term": "exposure_area0_period0",
        "estimate": exposure_at(make_exposure("base", "us_change"), 0, periods[0]),
        "se": None,
        "n_obs": 72,
    },
    {
        "term": "exposure_area0_period1",
        "estimate": exposure_at(make_exposure("base", "us_change"), 0, periods[1]),
        "se": None,
        "n_obs": 72,
    },
    {
        "term": "instrument_area0_period0",
        "estimate": exposure_at(make_exposure("early", "other_change"), 0, periods[0]),
        "se": None,
        "n_obs": 72,
    },
]

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "dependent_variable": "change_pp",
        "endogenous_variable": "x",
        "instrument": "z",
        "exogenous_regressors": ["intercept", "period", "control"],
        "weight": "base-vintage population",
        "exposure_units": "thousands of real dollars per worker per decade",
    },
    "diagnostics": {"n_obs": 72},
}

with Path("result.json").open("w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, allow_nan=False)
