import json
import numpy as np
import pandas as pd
from scipy.stats import f

df = pd.read_csv("input.csv")
n = len(df)

y = df["y"].to_numpy(dtype=float)
endog = df["endog"].to_numpy(dtype=float)
x = df["x"].to_numpy(dtype=float)
z1 = df["z1"].to_numpy(dtype=float)
z2 = df["z2"].to_numpy(dtype=float)

# Regress the outcome and endogenous variable on the null-model regressors.
W = np.column_stack([np.ones(n), x])
bread_w = np.linalg.inv(W.T @ W)
M_w = np.eye(n) - W @ bread_w @ W.T

y_resid = M_w @ y
endog_resid = M_w @ endog

# Residualize the excluded instruments against the null-model regressors.
Z = np.column_stack([z1, z2])
Z_resid = M_w @ Z
G = Z_resid.T @ Z_resid
G_inv = np.linalg.inv(G)

a = Z_resid.T @ y_resid
b = Z_resid.T @ endog_resid

# The full model has four regressors: intercept, x, z1, and z2.
q = 2
df_den = n - 4
critical = float(f.ppf(0.95, q, df_den))

# For candidate beta, the restricted-model residual sum of squares is rss0.
# Adding z1 and z2 reduces it by ess. The full-model residual sum is rss0 - ess.
r0 = float(y_resid @ y_resid)
r1 = float(y_resid @ endog_resid)
r2 = float(endog_resid @ endog_resid)

e0 = float(a @ G_inv @ a)
e1 = float(a @ G_inv @ b)
e2 = float(b @ G_inv @ b)

# F(beta) <= critical is equivalent to this quadratic inequality <= 0.
scale = df_den + q * critical
coef2 = scale * e2 - df_den * r2
coef1 = -2.0 * scale * e1 + 2.0 * df_den * r1
coef0 = scale * e0 - df_den * r0

roots = np.roots([coef2, coef1, coef0])
real_roots = sorted(
    float(root.real)
    for root in roots
    if abs(root.imag) <= 1e-8 * max(1.0, abs(root.real))
)

if len(real_roots) == 2:
    boundary_low, boundary_high = real_roots
else:
    # Preserve finite output fields if numerical degeneracy occurs.
    # The task data are expected to yield two finite boundary points.
    real_part_roots = sorted(float(root.real) for root in roots)
    boundary_low, boundary_high = real_part_roots

def ar_f(beta):
    rss0_beta = r0 - 2.0 * r1 * beta + r2 * beta * beta
    d = a - beta * b
    ess_beta = float(d @ G_inv @ d)
    full_rss = rss0_beta - ess_beta
    return float((ess_beta / q) / (full_rss / df_den))

accepts_zero = int(ar_f(0.0) <= critical)
unbounded = int(coef2 < 0.0)

estimates = [
    ("boundary_low", boundary_low),
    ("boundary_high", boundary_high),
    ("accepts_zero", accepts_zero),
    ("unbounded", unbounded),
    ("ar_f_at_one", ar_f(1.0)),
]

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": [
        {
            "term": term,
            "estimate": float(value),
            "se": None,
            "n_obs": int(n),
        }
        for term, value in estimates
    ],
    "method_metadata": {
        "estimator": "Anderson-Rubin test inversion using a conventional homoskedastic joint F test",
        "vcov": "conventional homoskedastic",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as f_out:
    json.dump(result, f_out, indent=2)
