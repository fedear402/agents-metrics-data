import json
import numpy as np
import pandas as pd

households = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

# Retain all nonrecipient households, including ineligible households in
# villages with either treatment status.
data = households.loc[households["recipient"] == 0].copy()

eligible = data["eligible"].to_numpy(dtype=float)
dose = data["dose"].to_numpy(dtype=float)
instrument = data["instrument"].to_numpy(dtype=float)
baseline = data["baseline"].to_numpy(dtype=float)
weight = data["weight"].to_numpy(dtype=float)
outcome = data["outcome"].to_numpy(dtype=float)

ineligible = 1.0 - eligible

# The exogenous design has no additional intercept.
exogenous = np.column_stack(
    [
        ineligible,
        eligible,
        baseline * ineligible,
        baseline * eligible,
    ]
)
endogenous = np.column_stack([dose * ineligible, dose * eligible])
instruments = np.column_stack(
    [
        exogenous,
        instrument * ineligible,
        instrument * eligible,
    ]
)

# Weighted 2SLS: project every regressor onto the instrument space using
# regression weights, then perform weighted least squares on the projections.
sqrt_weight = np.sqrt(weight)
weighted_instruments = instruments * sqrt_weight[:, None]
weighted_design = np.column_stack([exogenous, endogenous]) * sqrt_weight[:, None]
weighted_outcome = outcome * sqrt_weight

projection_coefficients = np.linalg.lstsq(
    weighted_instruments, weighted_design, rcond=None
)[0]
projected_design = weighted_instruments @ projection_coefficients
beta = np.linalg.lstsq(projected_design, weighted_outcome, rcond=None)[0]

n_obs = int(len(data))
ineligible_mask = eligible == 0
eligible_mask = eligible == 1

def weighted_mean(values, weights):
    return float(np.sum(values * weights) / np.sum(weights))

ineligible_mean_dose = weighted_mean(dose[ineligible_mask], weight[ineligible_mask])
eligible_mean_dose = weighted_mean(dose[eligible_mask], weight[eligible_mask])

# Endogenous columns follow the four exogenous columns in beta.
ineligible_effect = float(beta[4] * ineligible_mean_dose)
eligible_nonrecipient_effect = float(beta[5] * eligible_mean_dose)

population_by_eligibility = census.set_index("eligible")[
    "nonrecipient_population"
]
ineligible_population = float(population_by_eligibility.loc[0])
eligible_population = float(population_by_eligibility.loc[1])
population_effect = float(
    (
        ineligible_effect * ineligible_population
        + eligible_nonrecipient_effect * eligible_population
    )
    / (ineligible_population + eligible_population)
)

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "ineligible_effect",
            "estimate": ineligible_effect,
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "eligible_nonrecipient_effect",
            "estimate": eligible_nonrecipient_effect,
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "population_effect",
            "estimate": population_effect,
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "weighted two-stage least squares",
        "counterfactual": (
            "Synthetic convention: set dose to zero for every retained "
            "nonrecipient household."
        ),
        "group_effect": (
            "Fitted group-specific dose slope multiplied by the "
            "household-weighted mean dose among retained group observations."
        ),
        "population_aggregation": (
            "Census nonrecipient_population counts are used only to "
            "aggregate the two group effects."
        ),
        "intercept": "No additional intercept; group indicators are included.",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "retained_sample": "All household rows with recipient=0.",
        "weight": "households.csv weight used as the regression weight.",
        "census_counts": {
            "ineligible": int(ineligible_population),
            "eligible": int(eligible_population),
        },
    },
}

with open("result.json", "w", encoding="utf-8") as output_file:
    json.dump(result, output_file, indent=2, allow_nan=False)
