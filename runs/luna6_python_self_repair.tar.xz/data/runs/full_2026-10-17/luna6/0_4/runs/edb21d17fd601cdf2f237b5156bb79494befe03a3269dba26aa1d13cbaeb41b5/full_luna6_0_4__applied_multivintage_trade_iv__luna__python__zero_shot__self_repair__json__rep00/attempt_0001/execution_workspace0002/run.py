import json
import numpy as np
import pandas as pd

crosswalk = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv")
areas = pd.read_csv("areas.csv")
employment = pd.read_csv("employment.csv")
outcomes = pd.read_csv("outcomes.csv")

trade = trade.merge(
    crosswalk[["code", "industry"]],
    on="code",
    how="inner",
    validate="many_to_one",
)

industries = crosswalk["industry"].drop_duplicates().tolist()

# Fill omitted area-period-vintage-industry employment cells with zero.
employment_full = (
    employment.pivot_table(
        index=["area", "period", "vintage"],
        columns="industry",
        values="employment",
        aggfunc="sum",
        fill_value=0,
    )
    .reindex(columns=industries, fill_value=0)
    .stack()
    .rename("employment")
    .reset_index()
)

national = (
    employment_full.groupby(
        ["period", "vintage", "industry"], as_index=False
    )["employment"]
    .sum()
    .rename(columns={"employment": "national_employment"})
)

base_areas = areas.loc[areas["vintage"] == "base"].copy()
early_areas = areas.loc[areas["vintage"] == "early"].copy()

base_cells = employment_full.loc[
    employment_full["vintage"] == "base"
].merge(
    base_areas[["area", "period", "total_employment"]],
    on=["area", "period"],
    how="inner",
    validate="many_to_one",
)

early_cells = employment_full.loc[
    employment_full["vintage"] == "early"
].merge(
    early_areas[["area", "period", "total_employment"]],
    on=["area", "period"],
    how="inner",
    validate="many_to_one",
)

base_cells = base_cells.merge(
    national.loc[national["vintage"] == "base"],
    on=["period", "vintage", "industry"],
    how="inner",
    validate="many_to_one",
).merge(
    trade[["period", "industry", "us_change", "price_index", "years"]],
    on=["period", "industry"],
    how="inner",
    validate="many_to_one",
)

early_cells = early_cells.merge(
    national.loc[national["vintage"] == "early"],
    on=["period", "vintage", "industry"],
    how="inner",
    validate="many_to_one",
).merge(
    trade[["period", "industry", "other_change", "price_index", "years"]],
    on=["period", "industry"],
    how="inner",
    validate="many_to_one",
)

base_cells["component"] = (
    (base_cells["employment"] / base_cells["total_employment"])
    * (base_cells["us_change"] / base_cells["national_employment"])
    / (base_cells["price_index"] / 100.0)
    / 1000.0
    * (10.0 / base_cells["years"])
)

early_cells["component"] = (
    (early_cells["employment"] / early_cells["total_employment"])
    * (early_cells["other_change"] / early_cells["national_employment"])
    / (early_cells["price_index"] / 100.0)
    / 1000.0
    * (10.0 / early_cells["years"])
)

x = (
    base_cells.groupby(["area", "period"], as_index=False)["component"]
    .sum()
    .rename(columns={"component": "x"})
)
z = (
    early_cells.groupby(["area", "period"], as_index=False)["component"]
    .sum()
    .rename(columns={"component": "z"})
)

panel = (
    outcomes.merge(x, on=["area", "period"], how="inner", validate="one_to_one")
    .merge(z, on=["area", "period"], how="inner", validate="one_to_one")
    .merge(
        base_areas[["area", "period", "population"]],
        on=["area", "period"],
        how="inner",
        validate="one_to_one",
    )
    .sort_values(["area", "period"])
    .reset_index(drop=True)
)

period_values = sorted(panel["period"].unique())
if len(period_values) != 2:
    raise ValueError("Expected exactly two periods.")
panel["period_indicator"] = (
    panel["period"] == period_values[1]
).astype(float)

y = panel["change_pp"].to_numpy(dtype=float)
weights = panel["population"].to_numpy(dtype=float)

# Regressors: intercept, period, control, and endogenous exposure x.
X = np.column_stack(
    [
        np.ones(len(panel)),
        panel["period_indicator"].to_numpy(dtype=float),
        panel["control"].to_numpy(dtype=float),
        panel["x"].to_numpy(dtype=float),
    ]
)

# Instruments include each exogenous regressor and instrument z.
Z = np.column_stack(
    [
        np.ones(len(panel)),
        panel["period_indicator"].to_numpy(dtype=float),
        panel["control"].to_numpy(dtype=float),
        panel["z"].to_numpy(dtype=float),
    ]
)

sqrt_w = np.sqrt(weights)
Zw = Z * sqrt_w[:, None]
Xw = X * sqrt_w[:, None]
yw = y * sqrt_w

projection_coef = np.linalg.lstsq(Zw, Xw, rcond=None)[0]
X_hat_w = Zw @ projection_coef
beta = np.linalg.lstsq(X_hat_w, yw, rcond=None)[0]

area0 = panel.loc[panel["area"] == 0].set_index("period")
n_obs = int(len(panel))

estimates = [
    {
        "term": "iv_slope",
        "estimate": float(beta[3]),
        "se": None,
        "n_obs": n_obs,
    },
    {
        "term": "exposure_area0_period0",
        "estimate": float(area0.loc[period_values[0], "x"]),
        "se": None,
        "n_obs": n_obs,
    },
    {
        "term": "exposure_area0_period1",
        "estimate": float(area0.loc[period_values[1], "x"]),
        "se": None,
        "n_obs": n_obs,
    },
    {
        "term": "instrument_area0_period0",
        "estimate": float(area0.loc[period_values[0], "z"]),
        "se": None,
        "n_obs": n_obs,
    },
]

def json_value(value):
    if isinstance(value, np.generic):
        return value.item()
    return value

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "population-weighted two-stage least squares",
        "outcome": "change_pp",
        "regressors": ["intercept", "period", "control", "x"],
        "endogenous_regressor": "x",
        "instruments": ["intercept", "period", "control", "z"],
        "weight": "base-vintage population",
        "exposure_units": "thousands of real dollars per worker per decade",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "periods": [json_value(value) for value in period_values],
        "industry_count": int(crosswalk["industry"].nunique()),
        "trade_code_count": int(crosswalk["code"].nunique()),
    },
}

with open("result.json", "w", encoding="utf-8") as result_file:
    json.dump(result, result_file, indent=2, allow_nan=False)
