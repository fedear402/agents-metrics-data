import json
import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS

households = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

d = households.loc[households["recipient"] == 0].copy()
d["ineligible"] = 1 - d["eligible"]
d["dose_ineligible"] = d["dose"] * d["ineligible"]
d["dose_eligible"] = d["dose"] * d["eligible"]

exog = pd.DataFrame({
    "ineligible": d["ineligible"],
    "eligible": d["eligible"],
    "baseline_ineligible": d["baseline"] * d["ineligible"],
    "baseline_eligible": d["baseline"] * d["eligible"],
}, index=d.index)

instruments = exog.copy()
instruments["instrument_ineligible"] = d["instrument"] * d["ineligible"]
instruments["instrument_eligible"] = d["instrument"] * d["eligible"]

endog = d[["dose_ineligible", "dose_eligible"]]

fit = IV2SLS(
    dependent=d["outcome"],
    exog=exog,
    endog=endog,
    instruments=instruments,
    weights=d["weight"],
).fit()

ineligible_slope = float(fit.params["dose_ineligible"])
eligible_slope = float(fit.params["dose_eligible"])

ineligible_rows = d["eligible"] == 0
eligible_rows = d["eligible"] == 1

ineligible_mean_dose = float(np.average(
    d.loc[ineligible_rows, "dose"],
    weights=d.loc[ineligible_rows, "weight"],
))
eligible_mean_dose = float(np.average(
    d.loc[eligible_rows, "dose"],
    weights=d.loc[eligible_rows, "weight"],
))

ineligible_effect = ineligible_slope * ineligible_mean_dose
eligible_nonrecipient_effect = eligible_slope * eligible_mean_dose

census_weights = census.set_index("eligible")["nonrecipient_population"]
population_effect = float(np.average(
    [ineligible_effect, eligible_nonrecipient_effect],
    weights=[
        census_weights.loc[0],
        census_weights.loc[1],
    ],
))

n_obs = int(len(d))

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "ineligible_effect",
            "estimate": float(ineligible_effect),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "eligible_nonrecipient_effect",
            "estimate": float(eligible_nonrecipient_effect),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "population_effect",
            "estimate": population_effect,
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "retained_sample": "households with recipient == 0",
        "exogenous_columns": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
        ],
        "endogenous_columns": [
            "dose*(1-eligible)",
            "dose*eligible",
        ],
        "instruments": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
            "instrument*(1-eligible)",
            "instrument*eligible",
        ],
        "regression_weight": "weight",
        "within_group_dose_average": "household-weighted mean dose",
        "final_group_weights": "nonrecipient_population from census.csv",
        "counterfactual": "Set dose to zero for every retained household; attribution is a synthetic convention.",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "ineligible_slope": ineligible_slope,
        "eligible_slope": eligible_slope,
        "ineligible_weighted_mean_dose": ineligible_mean_dose,
        "eligible_weighted_mean_dose": eligible_mean_dose,
        "ineligible_nonrecipient_population": int(census_weights.loc[0]),
        "eligible_nonrecipient_population": int(census_weights.loc[1]),
    },
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, allow_nan=False)
