import json
import math

import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("input.csv", parse_dates=["date"])
df = df.sort_values("date").reset_index(drop=True)

df["vol_change"] = df["vix"].map(math.log).diff()
df["log_sales"] = df["sales"].map(math.log)

for lag in range(1, 16):
    df[f"lag_{lag}"] = df["vol_change"].shift(lag)

lag_columns = [f"lag_{lag}" for lag in range(1, 16)]
sample = df[["log_sales", *lag_columns]].dropna()

y = sample["log_sales"]
X = sm.add_constant(sample[lag_columns], has_constant="add")
fit = sm.OLS(y, X).fit()
n_obs = int(len(sample))

# Convert to a DataFrame so covariance entries can be selected by coefficient name.
hac_cov = pd.DataFrame(
    fit.get_robustcov_results(
        cov_type="HAC",
        maxlags=15,
        kernel="bartlett",
        use_correction=False,
    ).cov_params(),
    index=fit.params.index,
    columns=fit.params.index,
)
hac_cov *= n_obs / (n_obs - 16)

params = fit.params
cum_weights = pd.Series(0.0, index=params.index)
cum_weights.loc[lag_columns] = 1.0

cumulative_estimate = float(cum_weights @ params)
cumulative_variance = float(cum_weights.to_numpy() @ hac_cov.to_numpy() @ cum_weights.to_numpy())
cumulative_se = math.sqrt(max(cumulative_variance, 0.0))

estimates = [
    {
        "term": "cumulative_response",
        "estimate": cumulative_estimate,
        "se": cumulative_se,
        "n_obs": n_obs,
    },
    {
        "term": "lag_1",
        "estimate": float(params["lag_1"]),
        "se": math.sqrt(max(float(hac_cov.loc["lag_1", "lag_1"]), 0.0)),
        "n_obs": n_obs,
    },
    {
        "term": "lag_15",
        "estimate": float(params["lag_15"]),
        "se": math.sqrt(max(float(hac_cov.loc["lag_15", "lag_15"]), 0.0)),
        "n_obs": n_obs,
    },
]

output = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "OLS of log(sales) on an intercept and trading-observation lags 1 through 15 of first differences in log(vix)",
        "vcov": "Newey-West HAC with maximum lag 15 and Bartlett weights 1-j/16, multiplied by N/(N-16)",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(output, f, indent=2, allow_nan=False)
