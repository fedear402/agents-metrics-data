import json
import numpy as np
import pandas as pd

households = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

d = households.loc[households["recipient"] == 0].copy()
eligible = d["eligible"].to_numpy(dtype=float)
ineligible = 1.0 - eligible
weight = d["weight"].to_numpy(dtype=float)
y = d["outcome"].to_numpy(dtype=float)

# Build the specified group-specific regressors. The group indicators span
# the constant, so the design has no additional intercept.
exog = np.column_stack([
    ineligible,
    eligible,
    d["baseline"].to_numpy(dtype=float) * ineligible,
    d["baseline"].to_numpy(dtype=float) * eligible,
])
endog = np.column_stack([
    d["dose"].to_numpy(dtype=float) * ineligible,
    d["dose"].to_numpy(dtype=float) * eligible,
])
excluded = np.column_stack([
    d["instrument"].to_numpy(dtype=float) * ineligible,
    d["instrument"].to_numpy(dtype=float) * eligible,
])

# Weighted 2SLS: project endogenous columns on the full instrument matrix,
# then estimate the weighted second-stage equation. Use a pseudoinverse so
# redundant instrument columns do not cause a rank error.
sqrt_w = np.sqrt(weight)
xw = exog * sqrt_w[:, None]
zw = np.column_stack([exog, excluded]) * sqrt_w[:, None]
qw = endog * sqrt_w[:, None]
yw = y * sqrt_w

projection = zw @ np.linalg.pinv(zw)
x2_w = np.column_stack([xw, projection @ qw])
beta = np.linalg.pinv(x2_w) @ yw
n_obs = int(len(d))

ineligible_mean_dose = np.average(
    d.loc[d["eligible"] == 0, "dose"],
    weights=d.loc[d["eligible"] == 0, "weight"],
)
eligible_mean_dose = np.average(
    d.loc[d["eligible"] == 1, "dose"],
    weights=d.loc[d["eligible"] == 1, "weight"],
)

ineligible_effect = float(beta[4] * ineligible_mean_dose)
eligible_nonrecipient_effect = float(beta[5] * eligible_mean_dose)

population_weights = census.set_index("eligible")["nonrecipient_population"]
population_effect = float(np.average(
    [ineligible_effect, eligible_nonrecipient_effect],
    weights=[population_weights.loc[0], population_weights.loc[1]],
))

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {"term": "ineligible_effect", "estimate": ineligible_effect, "se": None, "n_obs": n_obs},
        {"term": "eligible_nonrecipient_effect", "estimate": eligible_nonrecipient_effect, "se": None, "n_obs": n_obs},
        {"term": "population_effect", "estimate": population_effect, "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "weight_variable": "weight",
        "retained_sample": "all households with recipient=0",
        "endogenous_columns": ["dose*(1-eligible)", "dose*eligible"],
        "exogenous_columns": [
            "1-eligible", "eligible",
            "baseline*(1-eligible)", "baseline*eligible"
        ],
        "instrument_columns": [
            "1-eligible", "eligible",
            "baseline*(1-eligible)", "baseline*eligible",
            "instrument*(1-eligible)", "instrument*eligible"
        ],
        "within_group_effect": "fitted dose slope times household-weighted mean dose",
        "counterfactual": "dose set to zero for every retained household",
        "attribution_convention": "synthetic convention",
        "population_weights_source": "census.csv nonrecipient_population",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "n_ineligible_nonrecipient": int((d["eligible"] == 0).sum()),
        "n_eligible_nonrecipient": int((d["eligible"] == 1).sum()),
    },
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, allow_nan=False)
