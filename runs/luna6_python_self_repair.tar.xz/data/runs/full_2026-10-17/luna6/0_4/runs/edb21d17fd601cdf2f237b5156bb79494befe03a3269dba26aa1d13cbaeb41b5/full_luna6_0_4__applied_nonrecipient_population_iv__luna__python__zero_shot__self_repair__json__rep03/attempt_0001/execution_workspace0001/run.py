import json
import pandas as pd
import statsmodels.api as sm

households = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

# Retain every nonrecipient household, including ineligible households in
# villages with either treatment status.
data = households.loc[households["recipient"] == 0].copy()
data["ineligible"] = 1 - data["eligible"]

# Construct the two endogenous regressors and the specified exogenous
# regressors and instruments. No additional intercept is included.
data["dose_ineligible"] = data["dose"] * data["ineligible"]
data["dose_eligible"] = data["dose"] * data["eligible"]
data["baseline_ineligible"] = data["baseline"] * data["ineligible"]
data["baseline_eligible"] = data["baseline"] * data["eligible"]
data["instrument_ineligible"] = data["instrument"] * data["ineligible"]
data["instrument_eligible"] = data["instrument"] * data["eligible"]

exogenous = data[
    ["ineligible", "eligible", "baseline_ineligible", "baseline_eligible"]
]
endogenous = data[["dose_ineligible", "dose_eligible"]]
instruments = pd.concat(
    [
        exogenous,
        data[["instrument_ineligible", "instrument_eligible"]],
    ],
    axis=1,
)

fit = IV2SLS(
    data["outcome"],
    exogenous,
    endogenous,
    instruments,
).fit(weights=data["weight"])

n_obs = int(len(data))
ineligible_slope = float(fit.params["dose_ineligible"])
eligible_slope = float(fit.params["dose_eligible"])

ineligible_mean_dose = float(
    (data["weight"] * data["dose"] * data["ineligible"]).sum()
    / (data["weight"] * data["ineligible"]).sum()
)
eligible_mean_dose = float(
    (data["weight"] * data["dose"] * data["eligible"]).sum()
    / (data["weight"] * data["eligible"]).sum()
)

ineligible_effect = ineligible_slope * ineligible_mean_dose
eligible_nonrecipient_effect = eligible_slope * eligible_mean_dose

population = census.set_index("eligible")["nonrecipient_population"]
population_effect = (
    ineligible_effect * float(population.loc[0])
    + eligible_nonrecipient_effect * float(population.loc[1])
) / float(population.loc[0] + population.loc[1])

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "ineligible_effect",
            "estimate": float(ineligible_effect),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "eligible_nonrecipient_effect",
            "estimate": float(eligible_nonrecipient_effect),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "population_effect",
            "estimate": float(population_effect),
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "weighted_2sls",
        "weight": "weight",
        "endogenous_columns": ["dose*(1-eligible)", "dose*eligible"],
        "exogenous_columns": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
        ],
        "instruments": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
            "instrument*(1-eligible)",
            "instrument*eligible",
        ],
        "counterfactual": "dose set to zero for every retained household",
        "attribution_convention": (
            "Group effects are attributed to the zero-dose counterfactual "
            "as a stated synthetic convention."
        ),
        "population_weights_source": "census.csv nonrecipient_population",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "retained_sample": "all households with recipient=0",
        "census_used_only_for_final_group_aggregation": True,
    },
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file, indent=2)
