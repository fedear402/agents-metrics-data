import json
from pathlib import Path

import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS


crosswalk = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv")
areas = pd.read_csv("areas.csv")
employment = pd.read_csv("employment.csv")
outcomes = pd.read_csv("outcomes.csv")

trade = trade.merge(
    crosswalk[["code", "industry"]],
    on="code",
    how="inner",
    validate="many_to_one",
)
if trade.duplicated(["period", "industry"]).any():
    raise ValueError("Each period and industry must have one trade row.")

# Build every area-period-vintage-industry cell. Missing employment cells are zero.
area_keys = areas[["area", "period", "vintage", "total_employment", "population"]]
industries = crosswalk[["industry"]].drop_duplicates()
cells = area_keys.merge(industries, how="cross")
cells = cells.merge(
    employment[["area", "period", "vintage", "industry", "employment"]],
    on=["area", "period", "vintage", "industry"],
    how="left",
    validate="one_to_one",
)
cells["employment"] = cells["employment"].fillna(0.0)

national = (
    cells.groupby(["period", "vintage", "industry"], as_index=False)["employment"]
    .sum()
    .rename(columns={"employment": "national_employment"})
)
cells = cells.merge(
    national,
    on=["period", "vintage", "industry"],
    how="left",
    validate="many_to_one",
)
cells = cells.merge(
    trade,
    on=["period", "industry"],
    how="left",
    validate="many_to_one",
)

cells["change"] = np.where(
    cells["vintage"].eq("base"), cells["us_change"], cells["other_change"]
)
cells["exposure_component"] = (
    (cells["employment"] / cells["total_employment"])
    * (cells["change"] / cells["national_employment"])
    / (cells["price_index"] / 100.0)
    / 1000.0
    * (10.0 / cells["years"])
)

exposures = (
    cells.groupby(["area", "period", "vintage"], as_index=False)["exposure_component"]
    .sum()
    .pivot(index=["area", "period"], columns="vintage", values="exposure_component")
    .rename(columns={"base": "x", "early": "z"})
    .reset_index()
)

# Join population from base-vintage area rows. Areas has multiple vintage rows.
base_areas = areas.loc[
    areas["vintage"].eq("base"),
    ["area", "period", "population"],
]
sample = outcomes.merge(
    base_areas,
    on=["area", "period"],
    how="inner",
    validate="one_to_one",
)
sample = sample.merge(
    exposures,
    on=["area", "period"],
    how="inner",
    validate="one_to_one",
)
sample = sample.sort_values(["area", "period"]).reset_index(drop=True)

period_levels = sorted(sample["period"].unique())
if len(period_levels) != 2:
    raise ValueError("Expected exactly two periods.")
sample["period_indicator"] = sample["period"].eq(period_levels[1]).astype(float)

exog = pd.DataFrame(
    {
        "intercept": np.ones(len(sample)),
        "period": sample["period_indicator"].to_numpy(),
        "control": sample["control"].to_numpy(),
    }
)

fit = IV2SLS(
    dependent=sample["change_pp"],
    exog=exog,
    endog=sample[["x"]],
    instruments=sample[["z"]],
    weights=sample["population"],
).fit()

area0 = exposures.loc[exposures["area"].eq(0)].set_index("period")
period0, period1 = period_levels
n_obs = 72

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "iv_slope",
            "estimate": float(fit.params["x"]),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "exposure_area0_period0",
            "estimate": float(area0.loc[period0, "x"]),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "exposure_area0_period1",
            "estimate": float(area0.loc[period1, "x"]),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "instrument_area0_period0",
            "estimate": float(area0.loc[period0, "z"]),
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "dependent_variable": "change_pp",
        "endogenous_variable": "x",
        "excluded_instrument": "z",
        "exogenous_variables": ["intercept", "period", "control"],
        "weights": "base-vintage population",
        "exposure_units": "thousands of real dollars per worker per decade",
    },
    "diagnostics": {"n_obs": n_obs},
}

with Path("result.json").open("w", encoding="utf-8") as output_file:
    json.dump(result, output_file, indent=2, allow_nan=False)
