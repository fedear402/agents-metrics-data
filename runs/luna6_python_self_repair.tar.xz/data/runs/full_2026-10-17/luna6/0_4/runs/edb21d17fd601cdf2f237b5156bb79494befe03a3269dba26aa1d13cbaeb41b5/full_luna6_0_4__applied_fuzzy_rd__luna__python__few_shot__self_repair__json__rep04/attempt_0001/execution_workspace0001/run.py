import json
import numpy as np
import pandas as pd

TASK_ID = "applied_fuzzy_rd"

data = pd.read_csv("input.csv")
inside = data.loc[data["score"].abs() < 1].copy()
n_obs = len(inside)

score = inside["score"].to_numpy(dtype=float)
right = (score >= 0).astype(float)
weights = 1.0 - np.abs(score)

# Separate local-linear slopes with an intercept on each side.
X = np.column_stack([
    1.0 - right,
    (1.0 - right) * score,
    right,
    right * score,
])
Y = inside[["earnings", "participated"]].to_numpy(dtype=float)

bread = np.linalg.inv(X.T @ (weights[:, None] * X))
coefficients = bread @ X.T @ (weights[:, None] * Y)
residuals = Y - X @ coefficients

# Right limit minus left limit for each outcome.
contrast = np.array([-1.0, 0.0, 1.0, 0.0])
jumps = contrast @ coefficients

# HC0 joint covariance, with fixed triangular weights.
loading = weights * (X @ bread @ contrast)
influence = loading[:, None] * residuals
joint_covariance = influence.T @ influence

reduced_form, first_stage = jumps
treatment_effect = reduced_form / first_stage
gradient = np.array([
    1.0 / first_stage,
    -reduced_form / (first_stage ** 2),
])
treatment_effect_se = float(
    np.sqrt(gradient @ joint_covariance @ gradient)
)

estimates = [
    {
        "term": "treatment_effect",
        "estimate": float(treatment_effect),
        "se": treatment_effect_se,
        "n_obs": int(n_obs),
    },
    {
        "term": "reduced_form",
        "estimate": float(reduced_form),
        "se": float(np.sqrt(joint_covariance[0, 0])),
        "n_obs": int(n_obs),
    },
    {
        "term": "first_stage",
        "estimate": float(first_stage),
        "se": float(np.sqrt(joint_covariance[1, 1])),
        "n_obs": int(n_obs),
    },
]

output = {
    "task_id": TASK_ID,
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "triangular-weighted local-linear fuzzy regression discontinuity",
        "vcov": "HC0, fixed bandwidth and weights, no degrees-of-freedom correction",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
