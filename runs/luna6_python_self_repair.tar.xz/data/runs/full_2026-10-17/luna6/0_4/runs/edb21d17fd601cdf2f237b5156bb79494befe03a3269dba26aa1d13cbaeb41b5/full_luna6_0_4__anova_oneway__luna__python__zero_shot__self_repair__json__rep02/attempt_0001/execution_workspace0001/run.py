import json

import pandas as pd
from scipy.stats import f_oneway

data = pd.read_csv("./input.csv")
groups = [group["y"].dropna().to_numpy() for _, group in data.groupby("group", sort=True)]
groups = [values for values in groups if len(values) > 0]

if len(groups) < 2:
    raise ValueError("One-way ANOVA requires at least two non-empty groups.")

result = f_oneway(*groups)
n_obs = sum(len(values) for values in groups)
df_num = len(groups) - 1
df_den = n_obs - len(groups)

output = {
    "task_id": "anova_oneway",
    "platform": "python",
    "estimates": [
        {"term": "F", "estimate": float(result.statistic), "se": None, "n_obs": int(n_obs)},
        {"term": "df_num", "estimate": float(df_num), "se": None, "n_obs": int(n_obs)},
        {"term": "df_den", "estimate": float(df_den), "se": None, "n_obs": int(n_obs)},
        {"term": "p_value", "estimate": float(result.pvalue), "se": None, "n_obs": int(n_obs)},
    ],
    "method_metadata": {
        "estimator": "Classical one-way ANOVA",
        "vcov": "Classical homoskedastic ANOVA variance",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(output, file, indent=2)
