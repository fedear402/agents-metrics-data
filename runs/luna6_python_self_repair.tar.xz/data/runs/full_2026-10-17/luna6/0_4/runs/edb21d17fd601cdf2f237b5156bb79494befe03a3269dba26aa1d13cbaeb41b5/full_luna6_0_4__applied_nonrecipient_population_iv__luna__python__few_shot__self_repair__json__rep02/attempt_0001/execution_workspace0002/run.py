import json
import numpy as np
import pandas as pd

households = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

d = households.loc[households["recipient"] == 0].copy()
n_obs = int(len(d))

eligible = d["eligible"].to_numpy(dtype=float)
ineligible = 1.0 - eligible
baseline = d["baseline"].to_numpy(dtype=float)
dose = d["dose"].to_numpy(dtype=float)
instrument = d["instrument"].to_numpy(dtype=float)
outcome = d["outcome"].to_numpy(dtype=float)
weight = d["weight"].to_numpy(dtype=float)

# Construct the requested columns. Within each group, the group indicator
# already spans its corresponding instrument column, so remove that
# redundant column from the excluded-instrument matrix.
exog = np.column_stack(
    [
        ineligible,
        eligible,
        baseline * ineligible,
        baseline * eligible,
    ]
)
endog = np.column_stack([dose * ineligible, dose * eligible])
excluded_instruments = np.column_stack(
    [instrument * ineligible, instrument * eligible]
)

# Weighted 2SLS: premultiply each row by sqrt(weight), then use the
# projection of the weighted endogenous regressors onto all instruments.
sqrt_weight = np.sqrt(weight)
x = exog * sqrt_weight[:, None]
z_endog = endog * sqrt_weight[:, None]
z_excluded = excluded_instruments * sqrt_weight[:, None]
y = outcome * sqrt_weight

instrument_matrix = np.column_stack([x, z_excluded])
if np.linalg.matrix_rank(instrument_matrix) < instrument_matrix.shape[1]:
    raise ValueError("Weighted instrument matrix is rank deficient.")
if np.linalg.matrix_rank(np.column_stack([x, z_endog])) < x.shape[1] + z_endog.shape[1]:
    raise ValueError("Weighted regressor matrix is rank deficient.")

projected_regressors = instrument_matrix @ np.linalg.lstsq(
    instrument_matrix, np.column_stack([x, z_endog]), rcond=None
)[0]
regressors = np.column_stack([x, z_endog])
beta = np.linalg.lstsq(
    projected_regressors.T @ regressors,
    projected_regressors.T @ y,
    rcond=None,
)[0]

ineligible_slope = float(beta[-2])
eligible_slope = float(beta[-1])

ineligible_rows = eligible == 0
eligible_rows = eligible == 1
ineligible_mean_dose = float(
    np.average(dose[ineligible_rows], weights=weight[ineligible_rows])
)
eligible_mean_dose = float(
    np.average(dose[eligible_rows], weights=weight[eligible_rows])
)

ineligible_effect = ineligible_slope * ineligible_mean_dose
eligible_nonrecipient_effect = eligible_slope * eligible_mean_dose

population_weights = census.set_index("eligible")["nonrecipient_population"]
population_effect = float(
    np.average(
        [ineligible_effect, eligible_nonrecipient_effect],
        weights=[population_weights.loc[0], population_weights.loc[1]],
    )
)

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "ineligible_effect",
            "estimate": float(ineligible_effect),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "eligible_nonrecipient_effect",
            "estimate": float(eligible_nonrecipient_effect),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "population_effect",
            "estimate": population_effect,
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "Weighted 2SLS",
        "counterfactual": (
            "Set dose to zero for every retained household; attribution is a "
            "stated synthetic convention."
        ),
        "group_effect_definition": (
            "Fitted group dose slope multiplied by the household-weighted "
            "mean dose within that eligibility group."
        ),
        "population_aggregation": (
            "Census nonrecipient_population counts determine only the final "
            "between-group weights."
        ),
        "sample": (
            "All household rows with recipient equal to zero, including "
            "ineligible households in both village treatment statuses."
        ),
        "regressors": {
            "endogenous": ["dose*(1-eligible)", "dose*eligible"],
            "exogenous": [
                "1-eligible",
                "eligible",
                "baseline*(1-eligible)",
                "baseline*eligible",
            ],
            "instruments": [
                "1-eligible",
                "eligible",
                "baseline*(1-eligible)",
                "baseline*eligible",
                "instrument*(1-eligible)",
                "instrument*eligible",
            ],
            "additional_intercept": False,
            "weight": "weight",
        },
    },
    "diagnostics": {
        "n_obs": n_obs,
        "ineligible_dose_slope": ineligible_slope,
        "eligible_dose_slope": eligible_slope,
        "ineligible_weighted_mean_dose": ineligible_mean_dose,
        "eligible_weighted_mean_dose": eligible_mean_dose,
    },
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, allow_nan=False)
