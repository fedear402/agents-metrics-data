import json
import numpy as np
import pandas as pd

households = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

# Retain every nonrecipient household, including ineligible households in
# both village treatment statuses.
sample = households.loc[households["recipient"] == 0].copy()
n_obs = int(len(sample))

eligible = sample["eligible"].to_numpy(dtype=float)
ineligible = 1.0 - eligible
dose = sample["dose"].to_numpy(dtype=float)
instrument = sample["instrument"].to_numpy(dtype=float)
baseline = sample["baseline"].to_numpy(dtype=float)
weight = sample["weight"].to_numpy(dtype=float)
outcome = sample["outcome"].to_numpy(dtype=float)

# The specified regression has no additional intercept.
exogenous = np.column_stack(
    [
        ineligible,
        eligible,
        baseline * ineligible,
        baseline * eligible,
    ]
)
endogenous = np.column_stack([dose * ineligible, dose * eligible])
instruments = np.column_stack(
    [
        exogenous,
        instrument * ineligible,
        instrument * eligible,
    ]
)

# Weighted 2SLS: project both endogenous columns onto all instruments and
# exogenous regressors, then estimate the structural equation by WLS.
design_first_stage = instruments
sqrt_weight = np.sqrt(weight)
weighted_instruments = design_first_stage * sqrt_weight[:, None]
weighted_endogenous = endogenous * sqrt_weight[:, None]
first_stage_coefficients = np.linalg.lstsq(
    weighted_instruments, weighted_endogenous, rcond=None
)[0]
endogenous_fitted = design_first_stage @ first_stage_coefficients
structural_design = np.column_stack([exogenous, endogenous_fitted])
weighted_structural_design = structural_design * sqrt_weight[:, None]
weighted_outcome = outcome * sqrt_weight
structural_coefficients = np.linalg.lstsq(
    weighted_structural_design, weighted_outcome, rcond=None
)[0]

ineligible_slope = float(structural_coefficients[-2])
eligible_slope = float(structural_coefficients[-1])

ineligible_mask = eligible == 0
eligible_mask = eligible == 1
ineligible_mean_dose = float(
    np.average(dose[ineligible_mask], weights=weight[ineligible_mask])
)
eligible_mean_dose = float(
    np.average(dose[eligible_mask], weights=weight[eligible_mask])
)

ineligible_effect = ineligible_slope * ineligible_mean_dose
eligible_nonrecipient_effect = eligible_slope * eligible_mean_dose

population_by_group = census.set_index("eligible")["nonrecipient_population"]
ineligible_population = float(population_by_group.loc[0])
eligible_population = float(population_by_group.loc[1])
population_effect = (
    ineligible_effect * ineligible_population
    + eligible_nonrecipient_effect * eligible_population
) / (ineligible_population + eligible_population)

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "ineligible_effect",
            "estimate": float(ineligible_effect),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "eligible_nonrecipient_effect",
            "estimate": float(eligible_nonrecipient_effect),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "population_effect",
            "estimate": float(population_effect),
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "weighted_two_stage_least_squares",
        "weight_column": "weight",
        "endogenous_columns": [
            "dose*(1-eligible)",
            "dose*eligible",
        ],
        "exogenous_columns": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
        ],
        "instrument_columns": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
            "instrument*(1-eligible)",
            "instrument*eligible",
        ],
        "additional_intercept": False,
        "sample_rule": "recipient == 0",
        "counterfactual": "dose set to zero for every retained household",
        "attribution_convention": (
            "Group effect is the fitted dose slope times the household-weighted "
            "mean dose among retained observations; attribution to the "
            "zero-dose counterfactual is a stated synthetic convention."
        ),
        "population_aggregation": (
            "Census nonrecipient_population counts are used only as final "
            "between-group weights."
        ),
    },
    "diagnostics": {
        "n_obs": n_obs,
        "ineligible_n_obs": int(ineligible_mask.sum()),
        "eligible_n_obs": int(eligible_mask.sum()),
        "ineligible_dose_slope": ineligible_slope,
        "eligible_dose_slope": eligible_slope,
        "ineligible_weighted_mean_dose": ineligible_mean_dose,
        "eligible_weighted_mean_dose": eligible_mean_dose,
        "ineligible_nonrecipient_population": int(ineligible_population),
        "eligible_nonrecipient_population": int(eligible_population),
    },
}

with open("result.json", "w", encoding="utf-8") as output_file:
    json.dump(result, output_file, indent=2, allow_nan=False)
