import json

import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS

crosswalk = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv")
areas = pd.read_csv("areas.csv")
employment = pd.read_csv("employment.csv")
outcomes = pd.read_csv("outcomes.csv")

trade = trade.merge(crosswalk, on="code", how="left", validate="many_to_one")
if trade["industry"].isna().any():
    raise ValueError("Every trade code must map to an industry.")

area_periods = areas[["area", "period"]].drop_duplicates()
periods = trade["period"].drop_duplicates().tolist()
industries = crosswalk["industry"].drop_duplicates().tolist()

def build_exposure(period, vintage, change_column):
    area_rows = areas.loc[
        (areas["period"] == period) & (areas["vintage"] == vintage),
        ["area", "total_employment"],
    ].copy()

    emp = employment.loc[
        (employment["period"] == period) & (employment["vintage"] == vintage),
        ["area", "industry", "employment"],
    ].copy()

    grid = area_rows[["area"]].assign(_key=1).merge(
        pd.DataFrame({"industry": industries, "_key": 1}), on="_key"
    ).drop(columns="_key")

    emp = grid.merge(emp, on=["area", "industry"], how="left")
    emp["employment"] = emp["employment"].fillna(0.0)

    national = emp.groupby("industry")["employment"].sum()
    trade_period = trade.loc[trade["period"] == period]
    trade_by_industry = trade_period.set_index("industry")

    if trade_by_industry.index.duplicated().any():
        raise ValueError("Each period must have one trade-code row per industry.")

    price_values = trade_period["price_index"].unique()
    year_values = trade_period["years"].unique()
    if len(price_values) != 1 or len(year_values) != 1:
        raise ValueError("Price index and years must be constant within period.")
    price_index = float(price_values[0])
    years = float(year_values[0])

    changes = trade_by_industry[change_column].reindex(industries)
    if changes.isna().any():
        raise ValueError("Every industry must have a trade change in each period.")

    shocks = (
        changes.to_numpy(dtype=float)
        / national.reindex(industries).to_numpy(dtype=float)
        / (price_index / 100.0)
        / 1000.0
        * (10.0 / years)
    )
    emp_matrix = emp.pivot(index="area", columns="industry", values="employment")
    emp_matrix = emp_matrix.reindex(columns=industries).fillna(0.0)
    totals = area_rows.set_index("area")["total_employment"]
    exposure = emp_matrix.to_numpy(dtype=float) @ shocks / totals.reindex(emp_matrix.index).to_numpy(dtype=float)
    return pd.Series(exposure, index=emp_matrix.index)

records = []
for period in periods:
    x_period = build_exposure(period, "base", "us_change")
    z_period = build_exposure(period, "early", "other_change")
    for row in areas.loc[areas["period"] == period].itertuples(index=False):
        records.append({
            "area": row.area,
            "period": period,
            "x": float(x_period.loc[row.area]),
            "z": float(z_period.loc[row.area]),
            "population": float(row.population),
        })

design = pd.DataFrame(records)
data = (
    outcomes.merge(design, on=["area", "period"], how="inner", validate="one_to_one")
    .merge(
        areas.loc[areas["vintage"] == "base", ["area", "period", "population"]],
        on=["area", "period"],
        how="left",
        suffixes=("", "_base"),
        validate="one_to_one",
    )
)

if len(data) != 72:
    raise ValueError(f"Expected 72 area-period observations, found {len(data)}.")

exog = pd.DataFrame({
    "intercept": np.ones(len(data)),
    "period": pd.to_numeric(data["period"], errors="raise").to_numpy(dtype=float),
    "control": pd.to_numeric(data["control"], errors="raise").to_numpy(dtype=float),
})
fit = IV2SLS(
    dependent=pd.to_numeric(data["change_pp"], errors="raise"),
    exog=exog,
    endog=pd.to_numeric(data["x"], errors="raise"),
    instruments=pd.to_numeric(data["z"], errors="raise"),
    weights=pd.to_numeric(data["population_base"], errors="raise"),
).fit()

area0_period0_x = data.loc[
    (data["area"] == 0) & (data["period"] == 0), "x"
].iloc[0]
area0_period1_x = data.loc[
    (data["area"] == 0) & (data["period"] == 1), "x"
].iloc[0]
area0_period0_z = data.loc[
    (data["area"] == 0) & (data["period"] == 0), "z"
].iloc[0]

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [
        {"term": "iv_slope", "estimate": float(fit.params["x"]), "se": None, "n_obs": 72},
        {"term": "exposure_area0_period0", "estimate": float(area0_period0_x), "se": None, "n_obs": 72},
        {"term": "exposure_area0_period1", "estimate": float(area0_period1_x), "se": None, "n_obs": 72},
        {"term": "instrument_area0_period0", "estimate": float(area0_period0_z), "se": None, "n_obs": 72},
    ],
    "method_metadata": {
        "estimator": "weighted_2sls",
        "dependent_variable": "change_pp",
        "exogenous_variables": ["intercept", "period", "control"],
        "endogenous_variable": "x",
        "excluded_instrument": "z",
        "instruments": ["intercept", "period", "control", "z"],
        "weight": "base-vintage population",
        "exposure_units": "thousands of real dollars per worker per decade",
        "sample_count": 72,
    },
    "diagnostics": {
        "n_obs": 72,
        "area_period_rows": int(data[["area", "period"]].drop_duplicates().shape[0]),
    },
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, allow_nan=False)
