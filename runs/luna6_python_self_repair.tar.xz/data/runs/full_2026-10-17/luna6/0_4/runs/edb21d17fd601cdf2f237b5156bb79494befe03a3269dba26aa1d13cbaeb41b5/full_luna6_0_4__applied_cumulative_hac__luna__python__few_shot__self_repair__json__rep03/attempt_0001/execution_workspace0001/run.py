import json

import numpy as np
import pandas as pd

data = pd.read_csv("input.csv")
data["date"] = pd.to_datetime(data["date"])
data = data.sort_values("date").reset_index(drop=True)

data["volatility_change"] = np.log(data["vix"]).diff()
for lag in range(1, 16):
    data[f"lag_{lag}"] = data["volatility_change"].shift(lag)
data["log_sales"] = np.log(data["sales"])

sample = data.dropna(subset=["log_sales"] + [f"lag_{lag}" for lag in range(1, 16)])
N = len(sample)
X = np.column_stack(
    [np.ones(N)] + [sample[f"lag_{lag}"].to_numpy() for lag in range(1, 16)]
)
y = sample["log_sales"].to_numpy()

coefficients = np.linalg.lstsq(X, y, rcond=None)[0]
residuals = y - X @ coefficients
scores = X * residuals[:, None]

meat = scores.T @ scores
for j in range(1, 16):
    weight = 1 - j / 16
    lag_product = scores[j:].T @ scores[:-j]
    meat += weight * (lag_product + lag_product.T)

bread = np.linalg.inv(X.T @ X)
covariance = (N / (N - 16)) * bread @ meat @ bread

contrast = np.zeros(16)
contrast[1:] = 1.0

rows = [
    {
        "term": "cumulative_response",
        "estimate": float(contrast @ coefficients),
        "se": float(np.sqrt(contrast @ covariance @ contrast)),
        "n_obs": int(N),
    },
    {
        "term": "lag_1",
        "estimate": float(coefficients[1]),
        "se": float(np.sqrt(covariance[1, 1])),
        "n_obs": int(N),
    },
    {
        "term": "lag_15",
        "estimate": float(coefficients[15]),
        "se": float(np.sqrt(covariance[15, 15])),
        "n_obs": int(N),
    },
]

output = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": rows,
    "method_metadata": {
        "estimator": "OLS with intercept and 15 lagged log volatility changes",
        "vcov": "Newey-West HAC, Bartlett weights, maximum lag 15, correction N/(N-16)",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
