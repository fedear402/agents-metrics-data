import json

import pandas as pd
from statsmodels.tsa.arima.model import ARIMA

data = pd.read_csv("./input.csv")
y = pd.to_numeric(data["y"], errors="raise").dropna()

model = ARIMA(
    y,
    order=(1, 1, 1),
    trend="n",
    enforce_stationarity=True,
    enforce_invertibility=True,
)
fit = model.fit()

prediction = fit.get_forecast(steps=1)
forecast = float(prediction.predicted_mean.iloc[0])
forecast_se = float(prediction.se_mean.iloc[0])
interval = prediction.conf_int(alpha=0.05)
lower_95 = float(interval.iloc[0, 0])
upper_95 = float(interval.iloc[0, 1])
n_obs = int(len(y))

result = {
    "task_id": "arima_forecast",
    "platform": "python",
    "estimates": [
        {
            "term": "forecast",
            "estimate": forecast,
            "se": forecast_se,
            "n_obs": n_obs,
        },
        {"term": "lower_95", "estimate": lower_95, "se": None, "n_obs": n_obs},
        {"term": "upper_95", "estimate": upper_95, "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "ARIMA(1,1,1) maximum likelihood, no constant or drift",
        "vcov": "Model-based forecast variance",
    },
    "diagnostics": {},
}

with open("./result.json", "w", encoding="utf-8") as output_file:
    json.dump(result, output_file, indent=2, allow_nan=False)
