import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")

# Use one row per region to normalize regional weights and obtain regional data.
regions = df.drop_duplicates("region_id").copy()
region_weight = regions["region_weight"].to_numpy(dtype=float)
e = region_weight / region_weight.sum()

region_ids = regions["region_id"].to_numpy()
region_index = {region_id: i for i, region_id in enumerate(region_ids)}
industry_ids = pd.unique(df["industry_id"])
industry_index = {industry_id: i for i, industry_id in enumerate(industry_ids)}

R = len(regions)
N = len(industry_ids)
shares = np.zeros((R, N), dtype=float)
shocks = np.empty(N, dtype=float)

for row in df.itertuples(index=False):
    r = region_index[row.region_id]
    n = industry_index[row.industry_id]
    shares[r, n] = float(row.share)
    shocks[n] = float(row.shock)

x = regions["x"].to_numpy(dtype=float)
y = regions["y"].to_numpy(dtype=float)
z = shares @ shocks

# Center each regional variable using normalized regional weights.
x0 = x - np.dot(e, x)
y0 = y - np.dot(e, y)
z0 = z - np.dot(e, z)

# Aggregate centered residuals by industry exposure.
s = e @ shares
positive = s > 0
s = s[positive]
shock_used = shocks[positive]
industry_shares = shares[:, positive]

aggregated = np.column_stack([
    industry_shares.T @ (e * y0) / s,
    industry_shares.T @ (e * x0) / s,
    industry_shares.T @ (e * z0) / s,
])

def weighted_shock_iv(dependent, endogenous, instrument, weights):
    """Weighted IV slope and HC1 standard error with structural residuals."""
    regressors = np.column_stack([np.ones(len(weights)), endogenous])
    instruments = np.column_stack([np.ones(len(weights)), instrument])
    cross = instruments.T @ (weights[:, None] * regressors)
    beta = np.linalg.solve(cross, instruments.T @ (weights * dependent))
    residual = dependent - regressors @ beta

    scores = instruments * (weights * residual)[:, None]
    inverse = np.linalg.inv(cross)
    n = len(weights)
    covariance = (n / (n - 2)) * inverse @ (scores.T @ scores) @ inverse.T
    return float(beta[1]), float(np.sqrt(covariance[1, 1]))

effect, effect_se = weighted_shock_iv(
    aggregated[:, 0], aggregated[:, 1], shock_used, s
)
first_stage, first_stage_se = weighted_shock_iv(
    aggregated[:, 1], aggregated[:, 2], shock_used, s
)
effective_shocks = float(1.0 / np.sum(s**2))

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {
            "term": "effect",
            "estimate": effect,
            "se": effect_se,
            "n_obs": int(len(s)),
        },
        {
            "term": "first_stage",
            "estimate": first_stage,
            "se": first_stage_se,
            "n_obs": int(len(s)),
        },
        {
            "term": "effective_shocks",
            "estimate": effective_shocks,
            "se": None,
            "n_obs": int(len(s)),
        },
    ],
    "method_metadata": {
        "estimator": "weighted regional 2SLS with shift-share instrument",
        "vcov": "shock-level HC1 using structural IV residuals and analytic weights",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
