import json
import pandas as pd
import numpy as np

df = pd.read_csv("input.csv")

# Use one observation per region to normalize regional weights and collect
# regional variables.
regions = df[["region_id", "region_weight", "x", "y"]].drop_duplicates("region_id").copy()
regions["e"] = regions["region_weight"] / regions["region_weight"].sum()

# Build the region by industry share matrix and verify industry shocks are
# constant within industry.
shares = df.pivot(index="region_id", columns="industry_id", values="share")
shock_check = df.groupby("industry_id")["shock"].nunique()
if (shock_check > 1).any():
    raise ValueError("shock must be constant within industry")
shocks = df.groupby("industry_id")["shock"].first().reindex(shares.columns)

regions = regions.set_index("region_id").reindex(shares.index)
e = regions["e"].to_numpy()
x = regions["x"].to_numpy()
y = regions["y"].to_numpy()
share_matrix = shares.to_numpy()
shock = shocks.to_numpy()

# Regional shift-share instrument and weighted regional centering.
z = share_matrix @ shock
x0 = x - np.sum(e * x)
y0 = y - np.sum(e * y)
z0 = z - np.sum(e * z)

# Industry exposure masses and centered shock-level aggregates.
mass = e @ share_matrix
if np.any(mass <= 0):
    raise ValueError("Each industry must have positive exposure mass")

def aggregate(v0):
    return (share_matrix.T @ (e * v0)) / mass

xbar = aggregate(x0)
ybar = aggregate(y0)
zbar = aggregate(z0)
n_industries = len(shock)

def weighted_shock_iv(dependent, endogenous):
    # Weighted IV with an intercept, using shock as the excluded instrument.
    w = mass
    regressor = np.column_stack((np.ones(n_industries), endogenous))
    instrument = np.column_stack((np.ones(n_industries), shock))
    cross = instrument.T @ (w[:, None] * regressor)
    beta = np.linalg.solve(cross, instrument.T @ (w * dependent))

    # Structural residuals and analytic-weight HC1 sandwich covariance.
    residual = dependent - regressor @ beta
    scores = instrument * (w * residual)[:, None]
    inverse = np.linalg.inv(cross)
    hc1 = n_industries / (n_industries - 2)
    covariance = hc1 * inverse @ (scores.T @ scores) @ inverse.T
    return float(beta[1]), float(np.sqrt(covariance[1, 1]))

effect, effect_se = weighted_shock_iv(ybar, xbar)
first_stage, first_stage_se = weighted_shock_iv(xbar, zbar)
effective_shocks = float(1.0 / np.sum(mass ** 2))

output = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {
            "term": "effect",
            "estimate": effect,
            "se": effect_se,
            "n_obs": n_industries,
        },
        {
            "term": "first_stage",
            "estimate": first_stage,
            "se": first_stage_se,
            "n_obs": n_industries,
        },
        {
            "term": "effective_shocks",
            "estimate": effective_shocks,
            "se": None,
            "n_obs": n_industries,
        },
    ],
    "method_metadata": {
        "estimator": "Weighted regional 2SLS with BHJ shock-level IV aggregation",
        "vcov": "Shock-level HC1 with structural IV residuals and analytic weights",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
