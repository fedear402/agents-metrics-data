import json
import pandas as pd
import numpy as np

crosswalk = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv")
areas = pd.read_csv("areas.csv")
employment = pd.read_csv("employment.csv")
outcomes = pd.read_csv("outcomes.csv")

trade = trade.merge(crosswalk, on="code", how="inner", validate="many_to_one")

# Include omitted area-industry cells as zero.
employment = employment.merge(
    crosswalk[["industry"]].drop_duplicates(),
    how="cross",
)
employment = employment.fillna({"employment": 0.0})

national = (
    employment.groupby(["period", "vintage", "industry"], as_index=False)["employment"]
    .sum()
    .rename(columns={"employment": "national_employment"})
)

def build_exposure(vintage, trade_change, output_name):
    area_rows = areas.loc[areas["vintage"].eq(vintage)].copy()
    area_industry = area_rows[["area", "period", "total_employment"]].merge(
        employment.loc[employment["vintage"].eq(vintage),
                       ["area", "period", "industry", "employment"]],
        on=["area", "period"],
        how="left",
    )
    area_industry["employment"] = area_industry["employment"].fillna(0.0)
    area_industry = (
        area_industry.merge(national.loc[national["vintage"].eq(vintage)],
                            on=["period", "industry"], how="left",
                            validate="many_to_one")
        .merge(trade[["period", "industry", trade_change, "price_index", "years"]],
               on=["period", "industry"], how="left", validate="many_to_one")
    )
    area_industry[output_name] = (
        (area_industry["employment"] / area_industry["total_employment"])
        * (area_industry[trade_change] / area_industry["national_employment"])
        / (area_industry["price_index"] / 100.0)
        / 1000.0
        * (10.0 / area_industry["years"])
    )
    return area_industry.groupby(["area", "period"], as_index=False)[output_name].sum()

x = build_exposure("base", "us_change", "x")
z = build_exposure("early", "other_change", "z")

data = (
    outcomes.merge(x, on=["area", "period"], how="inner", validate="one_to_one")
    .merge(z, on=["area", "period"], how="inner", validate="one_to_one")
    .merge(areas.loc[areas["vintage"].eq("base"),
                     ["area", "period", "population"]],
           on=["area", "period"], how="inner", validate="one_to_one")
)

data["period_indicator"] = data["period"].astype(float)

# Weighted 2SLS: residualize all variables on the exogenous regressors,
# then apply weighted IV to the residualized endogenous regressor.
y = data["change_pp"].to_numpy(dtype=float)
X_exog = np.column_stack([
    np.ones(len(data)),
    data["period_indicator"].to_numpy(dtype=float),
    data["control"].to_numpy(dtype=float),
])
endog = data["x"].to_numpy(dtype=float)
instrument = data["z"].to_numpy(dtype=float)
weights = data["population"].to_numpy(dtype=float)

W = np.diag(weights)
A = X_exog.T @ W @ X_exog
P = X_exog @ np.linalg.solve(A, X_exog.T @ W)
y_tilde = y - P @ y
x_tilde = endog - P @ endog
z_tilde = instrument - P @ instrument
beta_x = (z_tilde @ W @ y_tilde) / (z_tilde @ W @ x_tilde)

# Recover the intercept and exogenous coefficients for the fitted 2SLS model.
beta_exog = np.linalg.solve(A, X_exog.T @ W @ (y - beta_x * endog))

area0_period0 = x.loc[(x["area"] == 0) & (x["period"] == 0), "x"].iloc[0]
area0_period1 = x.loc[(x["area"] == 0) & (x["period"] == 1), "x"].iloc[0]
instrument_area0_period0 = z.loc[(z["area"] == 0) & (z["period"] == 0), "z"].iloc[0]

estimates = [
    {"term": "iv_slope", "estimate": float(beta_x), "se": None, "n_obs": 72},
    {"term": "exposure_area0_period0", "estimate": float(area0_period0), "se": None, "n_obs": 72},
    {"term": "exposure_area0_period1", "estimate": float(area0_period1), "se": None, "n_obs": 72},
    {"term": "instrument_area0_period0", "estimate": float(instrument_area0_period0), "se": None, "n_obs": 72},
]

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "outcome": "change_pp",
        "endogenous_regressor": "x",
        "excluded_instrument": "z",
        "exogenous_regressors": ["intercept", "period", "control"],
        "instruments": ["intercept", "period", "control", "z"],
        "weight": "base-vintage population",
        "exposure_units": "thousands of real dollars per worker per decade",
    },
    "diagnostics": {
        "n_obs": 72,
        "declared_sample_count": 72,
        "area_period_rows": int(len(data)),
    },
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2)
