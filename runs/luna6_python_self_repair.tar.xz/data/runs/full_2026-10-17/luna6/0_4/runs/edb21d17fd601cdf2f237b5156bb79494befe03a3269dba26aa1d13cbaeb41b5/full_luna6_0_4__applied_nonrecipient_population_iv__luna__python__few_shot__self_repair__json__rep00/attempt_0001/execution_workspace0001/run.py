import json
import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS

households = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

d = households.loc[households["recipient"] == 0].copy()
d["dose_ineligible"] = d["dose"] * (1 - d["eligible"])
d["dose_eligible"] = d["dose"] * d["eligible"]

exog = pd.DataFrame({
    "ineligible": 1 - d["eligible"],
    "eligible": d["eligible"],
    "baseline_ineligible": d["baseline"] * (1 - d["eligible"]),
    "baseline_eligible": d["baseline"] * d["eligible"],
}, index=d.index)

endog = d[["dose_ineligible", "dose_eligible"]]

instruments = exog.copy()
instruments["instrument_ineligible"] = d["instrument"] * (1 - d["eligible"])
instruments["instrument_eligible"] = d["instrument"] * d["eligible"]

fit = IV2SLS(
    dependent=d["outcome"],
    exog=exog,
    endog=endog,
    instruments=instruments[["instrument_ineligible", "instrument_eligible"]],
    weights=d["weight"],
).fit()

ineligible_slope = float(fit.params["dose_ineligible"])
eligible_slope = float(fit.params["dose_eligible"])

ineligible = d.loc[d["eligible"] == 0]
eligible = d.loc[d["eligible"] == 1]

ineligible_effect = ineligible_slope * float(
    np.average(ineligible["dose"], weights=ineligible["weight"])
)
eligible_nonrecipient_effect = eligible_slope * float(
    np.average(eligible["dose"], weights=eligible["weight"])
)

census_counts = census.set_index("eligible")["nonrecipient_population"]
population_effect = float(np.average(
    [ineligible_effect, eligible_nonrecipient_effect],
    weights=[
        census_counts.loc[0],
        census_counts.loc[1],
    ],
))

n_obs = int(len(d))
result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {"term": "ineligible_effect", "estimate": float(ineligible_effect), "se": None, "n_obs": n_obs},
        {"term": "eligible_nonrecipient_effect", "estimate": float(eligible_nonrecipient_effect), "se": None, "n_obs": n_obs},
        {"term": "population_effect", "estimate": population_effect, "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "sample": "all household rows with recipient=0",
        "endogenous_columns": ["dose*(1-eligible)", "dose*eligible"],
        "exogenous_columns": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
        ],
        "excluded_instruments": [
            "instrument*(1-eligible)",
            "instrument*eligible",
        ],
        "weight": "weight",
        "group_effect_definition": "fitted group dose slope times the household-weighted mean dose for that group",
        "counterfactual": "dose set to zero for every retained household; attribution is a stated synthetic convention",
        "population_aggregation_weights": "census nonrecipient_population by eligibility group",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "counterfactual_dose": 0,
    },
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, allow_nan=False)
