import json
import pandas as pd
from scipy import stats

data = pd.read_csv("./input.csv")
data = data[["group", "y"]].dropna()

groups = [values["y"].to_numpy() for _, values in data.groupby("group", sort=False)]
result = stats.f_oneway(*groups)

n_obs = len(data)
df_num = len(groups) - 1
df_den = n_obs - len(groups)

out = {
    "task_id": "anova_oneway",
    "platform": "python",
    "estimates": [
        {"term": "F", "estimate": float(result.statistic), "se": None, "n_obs": n_obs},
        {"term": "df_num", "estimate": float(df_num), "se": None, "n_obs": n_obs},
        {"term": "df_den", "estimate": float(df_den), "se": None, "n_obs": n_obs},
        {"term": "p_value", "estimate": float(result.pvalue), "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "One-way ANOVA",
        "vcov": "classical homoskedastic ANOVA",
    },
    "diagnostics": {},
}

with open("./result.json", "w") as f:
    json.dump(out, f)
