import json

import pandas as pd
from scipy.stats import f
import statsmodels.api as sm
from statsmodels.formula.api import ols

data = pd.read_csv("./input.csv")

model = ols("y ~ C(group)", data=data).fit()
anova_table = sm.stats.anova_lm(model, typ=2)

f_stat = float(anova_table.loc["C(group)", "F"])
df_num = float(anova_table.loc["C(group)", "df"])
df_den = float(anova_table.loc["Residual", "df"])
p_value = float(f.sf(f_stat, df_num, df_den))
n_obs = int(model.nobs)

result = {
    "task_id": "anova_oneway",
    "platform": "python",
    "estimates": [
        {"term": "F", "estimate": f_stat, "se": None, "n_obs": n_obs},
        {"term": "df_num", "estimate": df_num, "se": None, "n_obs": n_obs},
        {"term": "df_den", "estimate": df_den, "se": None, "n_obs": n_obs},
        {"term": "p_value", "estimate": p_value, "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "One-way ANOVA (OLS)",
        "vcov": "Classical homoskedastic ANOVA"
    },
    "diagnostics": {}
}

with open("result.json", "w", encoding="utf-8") as output_file:
    json.dump(result, output_file, indent=2)
