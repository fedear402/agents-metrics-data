import json
import numpy as np
import pandas as pd

data = pd.read_csv("input.csv")
sample = data.loc[data["score"].abs() < 1].copy()
n_obs = int(len(sample))

x = sample["score"].to_numpy(dtype=float)
right = (x >= 0).astype(float)
weights = 1.0 - np.abs(x)
design = np.column_stack((np.ones(n_obs), right, x, right * x))

# Weighted least squares with separate local-linear fits on each side.
xtwx = design.T @ (weights[:, None] * design)
bread = np.linalg.inv(xtwx)

def fit_hc0(outcome):
    y = sample[outcome].to_numpy(dtype=float)
    beta = bread @ (design.T @ (weights * y))
    residual = y - design @ beta
    # HC0 sandwich covariance for weighted least squares.
    meat = design.T @ ((weights**2 * residual**2)[:, None] * design)
    covariance = bread @ meat @ bread
    # The right-minus-left discontinuity is the coefficient on right.
    return beta[1], covariance

reduced_form, cov_y = fit_hc0("earnings")
first_stage, cov_d = fit_hc0("participated")

# Joint HC0 covariance across earnings and participation equations.
earnings = sample["earnings"].to_numpy(dtype=float)
participated = sample["participated"].to_numpy(dtype=float)
resid_y = earnings - design @ (bread @ (design.T @ (weights * earnings)))
resid_d = participated - design @ (bread @ (design.T @ (weights * participated)))
cross_meat = design.T @ (
    (weights**2 * resid_y * resid_d)[:, None] * design
)
cross_cov = bread @ cross_meat @ bread
var_y = cov_y[1, 1]
var_d = cov_d[1, 1]
cov_yd = cross_cov[1, 1]

if first_stage != 0:
    treatment_effect = reduced_form / first_stage
    var_effect = (
        var_y / first_stage**2
        + reduced_form**2 * var_d / first_stage**4
        - 2 * reduced_form * cov_yd / first_stage**3
    )
    se_effect = float(np.sqrt(max(var_effect, 0.0)))
else:
    treatment_effect = None
    se_effect = None

estimates = [
    {
        "term": "treatment_effect",
        "estimate": treatment_effect,
        "se": se_effect,
        "n_obs": n_obs,
    },
    {
        "term": "reduced_form",
        "estimate": float(reduced_form),
        "se": float(np.sqrt(max(var_y, 0.0))),
        "n_obs": n_obs,
    },
    {
        "term": "first_stage",
        "estimate": float(first_stage),
        "se": float(np.sqrt(max(var_d, 0.0))),
        "n_obs": n_obs,
    },
]

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "Triangular-weighted local-linear fuzzy regression discontinuity",
        "vcov": "HC0 sandwich covariance with joint cross-equation covariance; delta method",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file, allow_nan=False)
