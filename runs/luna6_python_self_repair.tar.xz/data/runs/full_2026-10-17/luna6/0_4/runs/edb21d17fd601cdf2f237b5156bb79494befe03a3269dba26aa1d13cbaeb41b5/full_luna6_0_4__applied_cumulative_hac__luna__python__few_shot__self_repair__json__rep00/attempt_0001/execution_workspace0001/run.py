import json

import numpy as np
import pandas as pd

data = pd.read_csv("input.csv")
data["date"] = pd.to_datetime(data["date"])
data = data.sort_values("date").reset_index(drop=True)

data["volatility_change"] = np.log(data["vix"]).diff()
data["log_sales"] = np.log(data["sales"])

lag_columns = []
for lag in range(1, 16):
    column = f"change_lag_{lag}"
    data[column] = data["volatility_change"].shift(lag)
    lag_columns.append(column)

sample = data.dropna(subset=["log_sales", *lag_columns])
N = len(sample)
X = np.column_stack(
    [np.ones(N), sample[lag_columns].to_numpy(dtype=float)]
)
y = sample["log_sales"].to_numpy(dtype=float)

coefficients = np.linalg.lstsq(X, y, rcond=None)[0]
residuals = y - X @ coefficients

scores = X * residuals[:, None]
hac_lags = 15
meat = scores.T @ scores
for lag in range(1, hac_lags + 1):
    weight = 1 - lag / 16
    lag_product = scores[lag:].T @ scores[:-lag]
    meat += weight * (lag_product + lag_product.T)

bread = np.linalg.inv(X.T @ X)
parameter_count = X.shape[1]
covariance = (N / (N - parameter_count)) * bread @ meat @ bread

cumulative_contrast = np.zeros(parameter_count)
cumulative_contrast[1:] = 1.0
cumulative_estimate = float(cumulative_contrast @ coefficients)
cumulative_se = float(
    np.sqrt(cumulative_contrast @ covariance @ cumulative_contrast)
)

estimates = [
    {
        "term": "cumulative_response",
        "estimate": cumulative_estimate,
        "se": cumulative_se,
        "n_obs": N,
    },
    {
        "term": "lag_1",
        "estimate": float(coefficients[1]),
        "se": float(np.sqrt(covariance[1, 1])),
        "n_obs": N,
    },
    {
        "term": "lag_15",
        "estimate": float(coefficients[15]),
        "se": float(np.sqrt(covariance[15, 15])),
        "n_obs": N,
    },
]

output = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "OLS with intercept and 15 lagged log-volatility changes",
        "vcov": "Newey-West HAC, Bartlett maximum lag 15, correction N/(N-16)",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
