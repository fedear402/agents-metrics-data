import json
import math

import pandas as pd
import statsmodels.api as sm
from statsmodels.stats.sandwich_covariance import cov_hac

df = pd.read_csv("input.csv", parse_dates=["date"])
df = df.sort_values("date").reset_index(drop=True)

df["vol_change"] = df["vix"].map(math.log).diff()
for lag in range(1, 16):
    df[f"lag_{lag}"] = df["vol_change"].shift(lag)

lag_names = [f"lag_{lag}" for lag in range(1, 16)]
regression_df = df.dropna(subset=lag_names + ["sales"]).copy()

y = regression_df["sales"].map(math.log)
X = sm.add_constant(regression_df[lag_names])
model = sm.OLS(y, X).fit()

n_obs = int(len(regression_df))
if n_obs <= 16:
    raise ValueError("The regression sample must contain more than 16 observations.")

covariance = cov_hac(
    model,
    nlags=15,
    weights_func=lambda nlags: [1.0 - j / 16.0 for j in range(nlags + 1)],
)
covariance = covariance * (n_obs / (n_obs - 16))

params = model.params
cumulative_estimate = float(params[lag_names].sum())
cumulative_variance = float(covariance[1:, 1:].sum())

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {
            "term": "cumulative_response",
            "estimate": cumulative_estimate,
            "se": math.sqrt(cumulative_variance) if cumulative_variance >= 0 else None,
            "n_obs": n_obs,
        },
        {
            "term": "lag_1",
            "estimate": float(params["lag_1"]),
            "se": math.sqrt(float(covariance[1, 1])),
            "n_obs": n_obs,
        },
        {
            "term": "lag_15",
            "estimate": float(params["lag_15"]),
            "se": math.sqrt(float(covariance[15, 15])),
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "OLS of log(sales) on an intercept and lags 1-15 of first differences in log(vix)",
        "vcov": "Newey-West HAC with Bartlett weights 1-j/16, maximum lag 15, scaled by N/(N-16)",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, allow_nan=False)
