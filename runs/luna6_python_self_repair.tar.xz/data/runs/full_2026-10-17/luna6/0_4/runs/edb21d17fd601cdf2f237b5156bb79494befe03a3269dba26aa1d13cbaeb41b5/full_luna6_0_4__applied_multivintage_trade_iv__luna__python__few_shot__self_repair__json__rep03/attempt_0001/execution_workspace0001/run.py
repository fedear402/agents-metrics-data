import json
from pathlib import Path

import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS


crosswalk = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv")
areas = pd.read_csv("areas.csv")
employment = pd.read_csv("employment.csv")
outcomes = pd.read_csv("outcomes.csv")

trade = trade.merge(crosswalk[["code", "industry"]], on="code", how="inner", validate="many_to_one")
if trade.duplicated(["period", "industry"]).any():
    raise ValueError("Each period and industry must have one trade row.")

emp = employment.merge(
    areas[["area", "period", "vintage", "total_employment", "population"]],
    on=["area", "period", "vintage"],
    how="left",
    validate="many_to_one",
)
emp = emp.merge(crosswalk[["industry"]].drop_duplicates(), on="industry", how="right")
emp["employment"] = emp["employment"].fillna(0.0)

national = (
    emp.groupby(["period", "vintage", "industry"], as_index=False)["employment"]
    .sum()
    .rename(columns={"employment": "national_employment"})
)
emp = emp.merge(national, on=["period", "vintage", "industry"], how="left", validate="many_to_one")
emp = emp.merge(trade, on=["period", "industry"], how="left", validate="many_to_one")

emp["change"] = np.where(emp["vintage"].eq("base"), emp["us_change"], emp["other_change"])
emp["exposure_component"] = (
    (emp["employment"] / emp["total_employment"])
    * (emp["change"] / emp["national_employment"])
    / (emp["price_index"] / 100.0)
    / 1000.0
    * (10.0 / emp["years"])
)

exposures = (
    emp.groupby(["area", "period", "vintage"], as_index=False)["exposure_component"]
    .sum()
    .pivot(index=["area", "period"], columns="vintage", values="exposure_component")
    .rename(columns={"base": "x", "early": "z"})
    .reset_index()
)

sample = outcomes.merge(areas, on=["area", "period"], how="inner", validate="one_to_one")
sample = sample.merge(exposures, on=["area", "period"], how="inner", validate="one_to_one")
sample = sample.sort_values(["area", "period"]).reset_index(drop=True)

period_dummies = pd.get_dummies(sample["period"], drop_first=True, dtype=float)
exog = pd.DataFrame(
    {
        "intercept": 1.0,
        "period": period_dummies.iloc[:, 0].to_numpy(),
        "control": sample["control"].to_numpy(),
    }
)
fit = IV2SLS(
    dependent=sample["change_pp"],
    exog=exog,
    endog=sample[["x"]],
    instruments=sample[["z"]],
    weights=sample["population"],
).fit()

area0 = exposures[exposures["area"].eq(0)].set_index("period")
period_values = sorted(sample["period"].unique())
period0, period1 = period_values[0], period_values[1]

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [
        {"term": "iv_slope", "estimate": float(fit.params["x"]), "se": None, "n_obs": 72},
        {
            "term": "exposure_area0_period0",
            "estimate": float(area0.loc[period0, "x"]),
            "se": None,
            "n_obs": 72,
        },
        {
            "term": "exposure_area0_period1",
            "estimate": float(area0.loc[period1, "x"]),
            "se": None,
            "n_obs": 72,
        },
        {
            "term": "instrument_area0_period0",
            "estimate": float(area0.loc[period0, "z"]),
            "se": None,
            "n_obs": 72,
        },
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "dependent_variable": "change_pp",
        "endogenous_variable": "x",
        "excluded_instrument": "z",
        "exogenous_variables": ["intercept", "period", "control"],
        "weights": "base-vintage population",
        "exposure_units": "thousands of real dollars per worker per decade",
    },
    "diagnostics": {"n_obs": 72},
}

with Path("result.json").open("w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, allow_nan=False)
