import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
sample = df.loc[df["score"].abs() < 1].copy()

score = sample["score"].to_numpy(dtype=float)
right = (score >= 0).astype(float)
weights = 1.0 - np.abs(score)

# Separate local-linear slopes and intercepts on each side:
# [left intercept, left slope, right intercept, right slope].
X = np.column_stack([
    1.0 - right,
    (1.0 - right) * score,
    right,
    right * score,
])
bread = np.linalg.inv(X.T @ (weights[:, None] * X))
A = bread @ (X.T * weights)

earnings = sample["earnings"].to_numpy(dtype=float)
participated = sample["participated"].to_numpy(dtype=float)
Y = np.column_stack([earnings, participated])
beta = A @ Y
residuals = Y - X @ beta

# Right limit minus left limit for each outcome.
contrast = np.array([-1.0, 0.0, 1.0, 0.0])
discontinuities = contrast @ beta
loadings = weights * (X @ bread @ contrast)
influences = loadings[:, None] * residuals
joint_covariance = influences.T @ influences

reduced_form, first_stage = discontinuities
treatment_effect = reduced_form / first_stage
gradient = np.array([
    1.0 / first_stage,
    -reduced_form / first_stage**2,
])
treatment_effect_se = float(
    np.sqrt(gradient @ joint_covariance @ gradient)
)
n_obs = int(len(sample))

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {
            "term": "treatment_effect",
            "estimate": float(treatment_effect),
            "se": treatment_effect_se,
            "n_obs": n_obs,
        },
        {
            "term": "reduced_form",
            "estimate": float(reduced_form),
            "se": float(np.sqrt(joint_covariance[0, 0])),
            "n_obs": n_obs,
        },
        {
            "term": "first_stage",
            "estimate": float(first_stage),
            "se": float(np.sqrt(joint_covariance[1, 1])),
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "local_linear_fuzzy_rd_triangular_weights",
        "vcov": "HC0",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
