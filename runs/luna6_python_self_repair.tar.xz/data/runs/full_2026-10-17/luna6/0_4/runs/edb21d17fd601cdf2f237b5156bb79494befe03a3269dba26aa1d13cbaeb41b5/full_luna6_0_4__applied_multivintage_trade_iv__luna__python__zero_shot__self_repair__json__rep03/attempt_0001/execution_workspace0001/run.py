import json
import numpy as np
import pandas as pd

crosswalk = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv")
areas = pd.read_csv("areas.csv")
employment = pd.read_csv("employment.csv")
outcomes = pd.read_csv("outcomes.csv")

trade = trade.merge(crosswalk, on="code", how="inner", validate="many_to_one")

industry_national = (
    employment.groupby(["period", "vintage", "industry"], as_index=False)["employment"]
    .sum()
    .rename(columns={"employment": "national_employment"})
)

trade = trade.merge(industry_national, on=["period", "industry"], how="left")
trade["x_trade"] = (
    trade["us_change"]
    / trade["national_employment"]
    / (trade["price_index"] / 100.0)
    / 1000.0
    * (10.0 / trade["years"])
)
trade["z_trade"] = (
    trade["other_change"]
    / trade["national_employment"]
    / (trade["price_index"] / 100.0)
    / 1000.0
    * (10.0 / trade["years"])
)

trade_area = trade[["period", "industry", "x_trade", "z_trade"]]

base = employment[employment["vintage"] == "base"].rename(
    columns={"employment": "base_employment"}
)
early = employment[employment["vintage"] == "early"].rename(
    columns={"employment": "early_employment"}
)

cell = base[["area", "period", "industry", "base_employment"]].merge(
    early[["area", "period", "industry", "early_employment"]],
    on=["area", "period", "industry"],
    how="outer",
)
cell[["base_employment", "early_employment"]] = cell[
    ["base_employment", "early_employment"]
].fillna(0.0)

cell = cell.merge(trade_area, on=["period", "industry"], how="left", validate="many_to_many")
cell[["x_trade", "z_trade"]] = cell[["x_trade", "z_trade"]].fillna(0.0)

exposure = (
    cell.assign(
        x_component=lambda d: d["base_employment"] * d["x_trade"],
        z_component=lambda d: d["early_employment"] * d["z_trade"],
    )
    .groupby(["area", "period"], as_index=False)[["x_component", "z_component"]]
    .sum()
    .rename(columns={"x_component": "x_numerator", "z_component": "z_numerator"})
)

base_totals = areas[areas["vintage"] == "base"][
    ["area", "period", "total_employment", "population"]
].rename(columns={"total_employment": "base_total_employment"})
early_totals = areas[areas["vintage"] == "early"][
    ["area", "period", "total_employment"]
].rename(columns={"total_employment": "early_total_employment"})

exposure = exposure.merge(
    base_totals, on=["area", "period"], how="left", validate="one_to_one"
).merge(early_totals, on=["area", "period"], how="left", validate="one_to_one")

exposure["x"] = exposure["x_numerator"] / exposure["base_total_employment"]
exposure["z"] = exposure["z_numerator"] / exposure["early_total_employment"]

data = outcomes.merge(
    exposure[["area", "period", "x", "z", "population"]],
    on=["area", "period"],
    how="inner",
    validate="one_to_one",
)
data = data.sort_values(["area", "period"]).reset_index(drop=True)

period_values = sorted(data["period"].unique())
if len(period_values) != 2:
    raise ValueError("Expected exactly two periods.")
data["period_indicator"] = (data["period"] == period_values[1]).astype(float)

y = data["change_pp"].to_numpy(dtype=float)
x = data[["x"]].to_numpy(dtype=float)
exogenous = np.column_stack(
    [
        np.ones(len(data)),
        data["period_indicator"].to_numpy(dtype=float),
        data["control"].to_numpy(dtype=float),
    ]
)
instruments = np.column_stack([exogenous, data["z"].to_numpy(dtype=float)])
weights = data["population"].to_numpy(dtype=float)

sqrt_w = np.sqrt(weights)
xw = x * sqrt_w[:, None]
yw = y * sqrt_w
zw = instruments * sqrt_w[:, None]

projection = zw @ np.linalg.solve(zw.T @ zw, zw.T)
design = np.column_stack([exogenous, x])
design_w = design * sqrt_w[:, None]
beta = np.linalg.solve(design_w.T @ projection @ design_w, design_w.T @ projection @ yw)

area0_period0 = exposure.loc[
    (exposure["area"] == 0) & (exposure["period"] == period_values[0]), "x"
].iloc[0]
area0_period1 = exposure.loc[
    (exposure["area"] == 0) & (exposure["period"] == period_values[1]), "x"
].iloc[0]
instrument_area0_period0 = exposure.loc[
    (exposure["area"] == 0) & (exposure["period"] == period_values[0]), "z"
].iloc[0]

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [
        {"term": "iv_slope", "estimate": float(beta[-1]), "se": None, "n_obs": 72},
        {
            "term": "exposure_area0_period0",
            "estimate": float(area0_period0),
            "se": None,
            "n_obs": 72,
        },
        {
            "term": "exposure_area0_period1",
            "estimate": float(area0_period1),
            "se": None,
            "n_obs": 72,
        },
        {
            "term": "instrument_area0_period0",
            "estimate": float(instrument_area0_period0),
            "se": None,
            "n_obs": 72,
        },
    ],
    "method_metadata": {
        "estimator": "Weighted two-stage least squares",
        "outcome": "change_pp",
        "regressors": ["intercept", "period", "control", "x"],
        "instrumented_regressor": "x",
        "instruments": ["intercept", "period", "control", "z"],
        "weight": "base-vintage population",
        "exposure_units": "thousands of real dollars per worker per decade",
    },
    "diagnostics": {"n_obs": 72},
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, allow_nan=False)
