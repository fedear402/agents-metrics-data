import json
import numpy as np
import pandas as pd

crosswalk = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv")
areas = pd.read_csv("areas.csv")
employment = pd.read_csv("employment.csv")
outcomes = pd.read_csv("outcomes.csv")

trade = trade.merge(crosswalk, on="code", how="inner", validate="many_to_one")

industries = crosswalk["industry"].drop_duplicates().tolist()
employment_full = (
    employment.pivot_table(
        index=["area", "period", "vintage"],
        columns="industry",
        values="employment",
        aggfunc="sum",
        fill_value=0,
    )
    .reindex(columns=industries, fill_value=0)
)

area_rows = areas.merge(
    employment_full.reset_index(),
    on=["area", "period", "vintage"],
    how="left",
    validate="one_to_one",
)
area_rows[industries] = area_rows[industries].fillna(0)

national = (
    employment.groupby(["period", "vintage", "industry"], as_index=False)["employment"]
    .sum()
    .rename(columns={"employment": "national_employment"})
)

trade_by_industry = trade[["period", "industry", "us_change", "other_change", "price_index", "years"]]
periods = sorted(trade["period"].unique())
exposures = []

for period in periods:
    period_trade = trade_by_industry.loc[trade_by_industry["period"] == period].set_index("industry")
    period_rows = areas.loc[areas["period"] == period].copy()

    for vintage, change_column, exposure_name in (
        ("base", "us_change", "x"),
        ("early", "other_change", "z"),
    ):
        rows = area_rows.loc[
            (area_rows["period"] == period) & (area_rows["vintage"] == vintage)
        ].copy()
        total = rows["total_employment"].to_numpy(dtype=float)
        exposure = np.zeros(len(rows), dtype=float)

        for industry in industries:
            trade_row = period_trade.loc[industry]
            national_employment = national.loc[
                (national["period"] == period)
                & (national["vintage"] == vintage)
                & (national["industry"] == industry),
                "national_employment",
            ].iloc[0]
            share = rows[industry].to_numpy(dtype=float) / total
            price = float(trade_row["price_index"])
            years = float(trade_row["years"])
            exposure += (
                share
                * float(trade_row[change_column])
                / national_employment
                / (price / 100.0)
                / 1000.0
                * (10.0 / years)
            )

        rows[exposure_name] = exposure
        exposures.append(rows[["area", "period", exposure_name]])

x = pd.concat([frame[["area", "period", "x"]] for frame in exposures if "x" in frame.columns])
z = pd.concat([frame[["area", "period", "z"]] for frame in exposures if "z" in frame.columns])

data = (
    outcomes.merge(x, on=["area", "period"], how="inner", validate="one_to_one")
    .merge(z, on=["area", "period"], how="inner", validate="one_to_one")
    .merge(
        areas.loc[areas["vintage"] == "base", ["area", "period", "population"]],
        on=["area", "period"],
        how="inner",
        validate="one_to_one",
    )
)

period_values = sorted(data["period"].unique())
data["period_indicator"] = (data["period"] == period_values[-1]).astype(float)

y = data["change_pp"].to_numpy(dtype=float)
X = np.column_stack(
    [
        np.ones(len(data)),
        data["period_indicator"].to_numpy(dtype=float),
        data["control"].to_numpy(dtype=float),
        data["x"].to_numpy(dtype=float),
    ]
)
Z = np.column_stack(
    [
        np.ones(len(data)),
        data["period_indicator"].to_numpy(dtype=float),
        data["control"].to_numpy(dtype=float),
        data["z"].to_numpy(dtype=float),
    ]
)
weights = data["population"].to_numpy(dtype=float)
W = np.diag(weights)
beta = np.linalg.solve(X.T @ W @ Z @ np.linalg.solve(Z.T @ W @ Z, Z.T @ W @ X),
                       X.T @ W @ Z @ np.linalg.solve(Z.T @ W @ Z, Z.T @ W @ y))

area0_p0_x = data.loc[(data["area"] == 0) & (data["period"] == period_values[0]), "x"].iloc[0]
area0_p1_x = data.loc[(data["area"] == 0) & (data["period"] == period_values[1]), "x"].iloc[0]
area0_p0_z = data.loc[(data["area"] == 0) & (data["period"] == period_values[0]), "z"].iloc[0]

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [
        {"term": "iv_slope", "estimate": float(beta[3]), "se": None, "n_obs": 72},
        {"term": "exposure_area0_period0", "estimate": float(area0_p0_x), "se": None, "n_obs": 72},
        {"term": "exposure_area0_period1", "estimate": float(area0_p1_x), "se": None, "n_obs": 72},
        {"term": "instrument_area0_period0", "estimate": float(area0_p0_z), "se": None, "n_obs": 72},
    ],
    "method_metadata": {
        "estimator": "population-weighted 2SLS",
        "outcome": "change_pp",
        "endogenous_regressor": "x",
        "excluded_instrument": "z",
        "exogenous_regressors": ["intercept", "period", "control"],
        "instruments": ["intercept", "period", "control", "z"],
        "exposure_units": "thousands of real dollars per worker per decade",
    },
    "diagnostics": {"n_obs": 72},
}

with open("result.json", "w", encoding="utf-8") as output_file:
    json.dump(result, output_file, indent=2)
