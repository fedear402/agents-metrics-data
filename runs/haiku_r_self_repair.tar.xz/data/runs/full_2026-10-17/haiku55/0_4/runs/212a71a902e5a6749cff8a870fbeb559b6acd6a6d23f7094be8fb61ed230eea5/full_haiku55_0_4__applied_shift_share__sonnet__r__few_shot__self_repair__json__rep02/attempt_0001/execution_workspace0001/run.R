library(jsonlite)

d <- read.csv("input.csv", stringsAsFactors = FALSE)

regions <- sort(unique(d$region_id))
inds <- sort(unique(d$industry_id))
nr <- length(regions)
ni <- length(inds)

S <- matrix(0, nrow = nr, ncol = ni)
S[cbind(match(d$region_id, regions), match(d$industry_id, inds))] <- d$share

shock_n <- vapply(inds, function(k) d$shock[d$industry_id == k][1], numeric(1))

ridx <- match(regions, d$region_id)
w <- d$region_weight[ridx]
x <- d$x[ridx]
y <- d$y[ridx]

e <- w / sum(w)
z <- drop(S %*% shock_n)

y0 <- y - sum(e * y)
x0 <- x - sum(e * x)
z0 <- z - sum(e * z)

s <- drop(t(S) %*% e)
vbar <- function(v0) drop(t(S) %*% (e * v0)) / s
ybar <- vbar(y0)
xbar <- vbar(x0)
zbar <- vbar(z0)

shock_iv <- function(dep, endo) {
  X <- cbind(1, endo)
  Z <- cbind(1, shock_n)
  cross <- crossprod(Z, s * X)
  beta <- solve(cross, crossprod(Z, s * dep))
  resid <- drop(dep - X %*% beta)
  scores <- Z * (s * resid)
  inv <- solve(cross)
  N <- length(dep)
  V <- N / (N - 2) * inv %*% crossprod(scores) %*% t(inv)
  c(slope = beta[2], se = sqrt(V[2, 2]))
}

effect <- shock_iv(ybar, xbar)
first <- shock_iv(xbar, zbar)
effective_shocks <- 1 / sum(s^2)

reg_2sls <- sum(e * z0 * y0) / sum(e * z0 * x0)
reg_fs <- sum(e * z0 * x0) / sum(e * z0^2)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = unname(effect["slope"]),
         se = unname(effect["se"]), n_obs = as.integer(ni)),
    list(term = "first_stage", estimate = unname(first["slope"]),
         se = unname(first["se"]), n_obs = as.integer(ni)),
    list(term = "effective_shocks", estimate = unname(effective_shocks),
         se = NA_real_, n_obs = as.integer(ni))
  ),
  method_metadata = list(
    estimator = "Weighted 2SLS shift-share with BHJ shock-level IV aggregation",
    vcov = "BHJ shock-level HC1 sandwich with N/(N-2), structural residuals, analytic weights s_n, no clustering"
  ),
  diagnostics = list(
    regional_2sls_slope = unname(reg_2sls),
    regional_first_stage_slope = unname(reg_fs),
    n_regions = as.integer(nr),
    n_industries = as.integer(ni)
  )
)

write_json(result, "result.json", auto_unbox = TRUE, digits = 16,
           pretty = TRUE, null = "null", na = "null")
