suppressPackageStartupMessages(library(jsonlite))

d <- read.csv("input.csv")
n <- nrow(d)
y <- d$y
en <- d$endog
x <- d$x
X <- cbind(1, x)
W <- cbind(1, x, d$z1, d$z2)

a <- qr.resid(qr(X), y)
b <- qr.resid(qr(X), en)
cc_vec <- qr.resid(qr(W), y)
dd_vec <- qr.resid(qr(W), en)

aa <- sum(a * a); ab <- sum(a * b); bb <- sum(b * b)
cc <- sum(cc_vec * cc_vec); cd <- sum(cc_vec * dd_vec); dd <- sum(dd_vec * dd_vec)

q <- qf(0.95, 2, n - 4)
s <- 2 * q / (n - 4)

# Accept beta iff A*beta^2 + B*beta + C <= 0, from F(beta) <= q
A <- bb - (1 + s) * dd
B <- -2 * ab + 2 * (1 + s) * cd
C <- aa - (1 + s) * cc

disc <- B^2 - 4 * A * C
if (disc >= 0 && abs(A) > 1e-12) {
  roots <- sort((-B + c(-1, 1) * sqrt(disc)) / (2 * A))
  boundary_low <- roots[1]
  boundary_high <- roots[2]
} else {
  boundary_low <- NA_real_
  boundary_high <- NA_real_
}

accepts_zero <- as.numeric(C <= 0)
unbounded <- as.numeric(A < 0 || (abs(A) <= 1e-12 && B != 0))

beta1 <- 1
ssr_r1 <- sum((a - beta1 * b)^2)
ssr_u1 <- sum((cc_vec - beta1 * dd_vec)^2)
ar_f_at_one <- ((ssr_r1 - ssr_u1) / 2) / (ssr_u1 / (n - 4))

mk <- function(term, est) {
  list(term = term, estimate = est, se = NULL, n_obs = n)
}

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = list(
    mk("boundary_low", boundary_low),
    mk("boundary_high", boundary_high),
    mk("accepts_zero", accepts_zero),
    mk("unbounded", unbounded),
    mk("ar_f_at_one", ar_f_at_one)
  ),
  method_metadata = list(
    estimator = "Anderson-Rubin confidence set via homoskedastic F test inversion",
    vcov = "homoskedastic"
  ),
  diagnostics = setNames(list(), character(0))
)

json <- toJSON(result, auto_unbox = TRUE, digits = NA, na = "null", null = "null", pretty = TRUE)
writeLines(json, "result.json")
