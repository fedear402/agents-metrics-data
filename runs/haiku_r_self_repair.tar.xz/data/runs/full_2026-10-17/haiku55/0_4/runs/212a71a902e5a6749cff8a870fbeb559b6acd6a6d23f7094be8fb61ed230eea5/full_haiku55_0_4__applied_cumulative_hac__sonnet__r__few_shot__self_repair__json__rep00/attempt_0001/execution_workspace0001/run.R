library(jsonlite)

d <- read.csv("input.csv", stringsAsFactors = FALSE)
d$date <- as.Date(d$date)
d <- d[order(d$date), ]
d$dlvix <- c(NA, diff(log(d$vix)))

L <- 15
n <- nrow(d)
lagmat <- sapply(1:L, function(k) c(rep(NA, k), head(d$dlvix, -k)))
colnames(lagmat) <- paste0("lag", 1:L)
d$log_sales <- log(d$sales)
dat <- data.frame(y = d$log_sales, lagmat)
dat <- dat[complete.cases(dat), ]

fit <- lm(y ~ ., data = dat)
X <- model.matrix(fit)
b <- coef(fit)
N <- nrow(X)
p <- ncol(X)
u <- residuals(fit)
scores <- X * u

meat <- crossprod(scores)
for (j in seq_len(L)) {
  w <- 1 - j / (L + 1)
  gamma <- crossprod(scores[(j + 1):N, , drop = FALSE], scores[1:(N - j), , drop = FALSE])
  meat <- meat + w * (gamma + t(gamma))
}
bread <- solve(crossprod(X))
V <- N / (N - (L + 1)) * bread %*% meat %*% bread

contrast <- c(0, rep(1, L))
cum_est <- sum(contrast * b)
cum_se <- sqrt(drop(t(contrast) %*% V %*% contrast))

res <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(term = "cumulative_response", estimate = unname(cum_est), se = unname(cum_se), n_obs = as.integer(N)),
    list(term = "lag_1", estimate = unname(b["lag1"]), se = unname(sqrt(V["lag1", "lag1"])), n_obs = as.integer(N)),
    list(term = "lag_15", estimate = unname(b["lag15"]), se = unname(sqrt(V["lag15", "lag15"])), n_obs = as.integer(N))
  ),
  method_metadata = list(
    estimator = "OLS",
    vcov = "Newey-West HAC, max lag 15, Bartlett weights, N/(N-16) small-sample correction"
  ),
  diagnostics = setNames(list(), character(0))
)

write_json(res, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
