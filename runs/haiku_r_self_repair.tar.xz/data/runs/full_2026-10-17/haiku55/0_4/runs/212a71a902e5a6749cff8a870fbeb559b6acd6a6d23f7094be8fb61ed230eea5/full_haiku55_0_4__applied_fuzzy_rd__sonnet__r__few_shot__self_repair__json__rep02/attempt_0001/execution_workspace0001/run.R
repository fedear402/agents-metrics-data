library(jsonlite)

d <- read.csv("input.csv")
d <- d[abs(d$score) < 1, ]
w <- 1 - abs(d$score)
n <- nrow(d)

fit_side <- function(dd, ww, y, side_flag) {
  X <- cbind(1, dd$score)
  b <- solve(crossprod(X, ww * X))
  beta <- b %*% crossprod(X, ww * y)
  res <- y - X %*% beta
  list(beta = beta, bread = b, X = X, res = drop(res), w = ww)
}

left <- d$score < 0
right <- d$score >= 0

fit_outcome <- function(y) {
  L <- fit_side(d[left, ], w[left], y[left])
  R <- fit_side(d[right, ], w[right], y[right])
  jump <- R$beta[1] - L$beta[1]
  n_l <- sum(left)
  n_r <- sum(right)
  # influence contributions for the intercept at each side, length n
  infl <- numeric(n)
  cR <- drop(R$bread %*% c(1, 0))
  cL <- drop(L$bread %*% c(1, 0))
  loadR <- R$w * drop(R$X %*% cR)
  loadL <- L$w * drop(L$X %*% cL)
  infl[right] <- loadR * R$res
  infl[left] <- -loadL * L$res
  list(jump = jump, infl = infl)
}

yE <- d$earnings
yP <- d$participated

rf <- fit_outcome(yE)
fs <- fit_outcome(yP)

Ifull <- cbind(rf$infl, fs$infl)
V <- crossprod(Ifull)

rf_est <- rf$jump
fs_est <- fs$jump
te <- rf_est / fs_est

g <- c(1 / fs_est, -rf_est / fs_est^2)
te_se <- sqrt(drop(t(g) %*% V %*% g))

rf_se <- sqrt(V[1, 1])
fs_se <- sqrt(V[2, 2])

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = unname(as.numeric(te)),
         se = unname(as.numeric(te_se)), n_obs = as.integer(n)),
    list(term = "reduced_form", estimate = unname(as.numeric(rf_est)),
         se = unname(as.numeric(rf_se)), n_obs = as.integer(n)),
    list(term = "first_stage", estimate = unname(as.numeric(fs_est)),
         se = unname(as.numeric(fs_se)), n_obs = as.integer(n))
  ),
  method_metadata = list(
    estimator = "fuzzy RD, local linear, triangular kernel, bandwidth 1, separate slopes",
    vcov = "HC0 delta method"
  ),
  diagnostics = setNames(list(), character(0))
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
