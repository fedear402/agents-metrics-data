suppressPackageStartupMessages(library(jsonlite))

d <- read.csv("input.csv")
n <- nrow(d)
y <- d$y
endog <- d$endog
x <- d$x
Z <- as.matrix(d[, c("z1", "z2")])

X <- cbind(1, x)
MX <- diag(n) - X %*% solve(crossprod(X), t(X))
Zt <- MX %*% Z
A <- solve(crossprod(Zt))

u <- drop(MX %*% y)
v <- drop(MX %*% endog)
a <- drop(crossprod(Zt, y))
cc <- drop(crossprod(Zt, endog))

k <- qf(0.95, 2, n - 4)
q <- (n - 4) / 2 + k

uu <- sum(u^2)
uv <- sum(u * v)
vv <- sum(v^2)
aAa <- drop(t(a) %*% A %*% a)
aAc <- drop(t(a) %*% A %*% cc)
cAc <- drop(t(cc) %*% A %*% cc)

# Accept beta iff G(beta) = k*RSS_r(beta) - q*Q(beta) >= 0, a quadratic in beta
g0 <- k * uu - q * aAa
g1 <- -2 * k * uv + 2 * q * aAc
g2 <- k * vv - q * cAc

disc <- g1^2 - 4 * g2 * g0
if (disc >= 0) {
  roots <- sort((-g1 + c(-1, 1) * sqrt(disc)) / (2 * g2))
  boundary_low <- roots[1]
  boundary_high <- roots[2]
} else {
  boundary_low <- NA_real_
  boundary_high <- NA_real_
}

accepts_zero <- as.integer(g0 >= 0)
unbounded <- as.integer(g2 > 0)

s1 <- a - cc
Q1 <- drop(t(s1) %*% A %*% s1)
R1 <- sum((u - v)^2)
ar_f_at_one <- (Q1 / 2) / ((R1 - Q1) / (n - 4))

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = list(
    list(term = "boundary_low", estimate = boundary_low, se = NULL, n_obs = n),
    list(term = "boundary_high", estimate = boundary_high, se = NULL, n_obs = n),
    list(term = "accepts_zero", estimate = accepts_zero, se = NULL, n_obs = n),
    list(term = "unbounded", estimate = unbounded, se = NULL, n_obs = n),
    list(term = "ar_f_at_one", estimate = ar_f_at_one, se = NULL, n_obs = n)
  ),
  method_metadata = list(
    estimator = "Anderson-Rubin confidence set by inverting homoskedastic joint F test of excluded instruments",
    vcov = "homoskedastic"
  ),
  diagnostics = structure(list(), names = character(0))
)

write(toJSON(result, auto_unbox = TRUE, digits = NA, na = "null", pretty = TRUE),
      file = "result.json")
