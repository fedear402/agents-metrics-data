suppressPackageStartupMessages(library(jsonlite))

d <- read.csv("input.csv")
n <- nrow(d)
y <- d$y
endog <- d$endog

W <- model.matrix(~ x, data = d)
Z <- model.matrix(~ x + z1 + z2, data = d)
resid_on <- function(v, X) lm.fit(X, v)$residuals

ry <- resid_on(y, W)
rd <- resid_on(endog, W)
uy <- resid_on(y, Z)
ud <- resid_on(endog, Z)

q <- 2L
df <- n - ncol(Z)
crit <- qf(0.95, q, df)
k <- q * crit / df

A <- sum(rd^2) - (1 + k) * sum(ud^2)
B <- -2 * (sum(ry * rd) - (1 + k) * sum(uy * ud))
C <- sum(ry^2) - (1 + k) * sum(uy^2)
disc <- B^2 - 4 * A * C
accepts <- function(b) A * b^2 + B * b + C <= 0

lo <- NA_real_
hi <- NA_real_
unb <- FALSE
type <- NA_character_

if (abs(A) > 1e-12) {
  if (A > 0) {
    if (disc < 0) {
      type <- "empty"
    } else {
      r <- sort((-B + c(-1, 1) * sqrt(disc)) / (2 * A))
      lo <- r[1]
      hi <- r[2]
      type <- if (disc == 0) "point" else "interval"
    }
  } else {
    if (disc <= 0) {
      unb <- TRUE
      type <- "all_reals"
    } else {
      r <- sort((-B + c(-1, 1) * sqrt(disc)) / (2 * A))
      lo <- r[1]
      hi <- r[2]
      unb <- TRUE
      type <- "outer_rays"
    }
  }
} else if (abs(B) > 1e-12) {
  lo <- -C / B
  unb <- TRUE
  type <- if (B > 0) "ray_below" else "ray_above"
} else {
  if (C <= 0) {
    unb <- TRUE
    type <- "all_reals"
  } else {
    type <- "empty"
  }
}

f_at <- function(b) {
  t <- y - b * endog
  rr <- lm.fit(W, t)$residuals
  uu <- lm.fit(Z, t)$residuals
  ((sum(rr^2) - sum(uu^2)) / q) / (sum(uu^2) / df)
}

res <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = list(
    list(term = "boundary_low", estimate = lo, se = NA_real_, n_obs = n),
    list(term = "boundary_high", estimate = hi, se = NA_real_, n_obs = n),
    list(term = "accepts_zero", estimate = as.numeric(accepts(0)), se = NA_real_, n_obs = n),
    list(term = "unbounded", estimate = as.numeric(unb), se = NA_real_, n_obs = n),
    list(term = "ar_f_at_one", estimate = f_at(1), se = NA_real_, n_obs = n)
  ),
  method_metadata = list(
    estimator = "Anderson-Rubin confidence set by inverting homoskedastic joint F test of excluded instruments z1 and z2",
    vcov = "homoskedastic"
  ),
  diagnostics = list(
    critical_value = crit,
    df_denominator = df,
    quadratic_A = A,
    quadratic_B = B,
    quadratic_C = C,
    discriminant = disc,
    set_type = type
  )
)

write_json(res, "result.json", auto_unbox = TRUE, digits = 16, pretty = TRUE, na = "null")
