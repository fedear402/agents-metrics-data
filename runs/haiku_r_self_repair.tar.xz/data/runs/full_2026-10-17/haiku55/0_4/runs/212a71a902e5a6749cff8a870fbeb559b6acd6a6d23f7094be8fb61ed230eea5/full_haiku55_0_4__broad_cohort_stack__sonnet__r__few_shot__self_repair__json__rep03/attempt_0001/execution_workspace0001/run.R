df <- read.csv("input.csv")
cohorts <- c(3, 5, 7)

res <- lapply(cohorts, function(cc) {
  wt <- (cc - 2):(cc + 2)
  d <- df[df$time %in% wt & (df$g == cc | df$g == 0 | df$g > cc + 2), ]
  keep_ids <- names(which(tapply(d$time, d$id, function(t) all(wt %in% t))))
  d <- d[as.character(d$id) %in% keep_ids, ]
  d$did <- as.numeric(d$g == cc & d$time >= cc)
  fit <- lm(y ~ did + factor(id) + factor(time), data = d)
  list(
    att = unname(coef(fit)["did"]),
    n = nrow(d),
    ntr = length(unique(d$id[d$g == cc]))
  )
})

att <- vapply(res, `[[`, numeric(1), "att")
n <- vapply(res, `[[`, integer(1), "n")
ntr <- vapply(res, `[[`, integer(1), "ntr")
att_weighted <- sum(att * ntr) / sum(ntr)

out <- list(
  task_id = "broad_cohort_stack",
  platform = "r",
  estimates = list(
    list(term = "att_g3", estimate = as.numeric(att[1]), se = NULL, n_obs = n[1]),
    list(term = "att_g5", estimate = as.numeric(att[2]), se = NULL, n_obs = n[2]),
    list(term = "att_g7", estimate = as.numeric(att[3]), se = NULL, n_obs = n[3]),
    list(term = "att_weighted", estimate = as.numeric(att_weighted), se = NULL, n_obs = sum(n))
  ),
  method_metadata = setNames(list(), character(0)),
  diagnostics = setNames(list(), character(0))
)

jsonlite::write_json(out, "result.json", auto_unbox = TRUE, null = "null", digits = 16)
