library(jsonlite)

d <- read.csv("input.csv")
d <- d[abs(d$score) < 1, ]
s <- d$score
w <- 1 - abs(s)
right <- as.numeric(s >= 0)
left <- 1 - right
X <- cbind(left, right, left * s, right * s)
Y <- cbind(earnings = d$earnings, participated = d$participated)
A <- solve(crossprod(X, w * X))
B <- A %*% crossprod(X, w * Y)
E <- Y - X %*% B
cvec <- c(-1, 1, 0, 0)
jumps <- drop(t(cvec) %*% B)
loading <- w * drop(X %*% A %*% cvec)
G <- loading * E
V <- crossprod(G)
se_jumps <- sqrt(diag(V))
ratio <- jumps[1] / jumps[2]
grad <- c(1 / jumps[2], -jumps[1] / jumps[2]^2)
ratio_se <- sqrt(drop(t(grad) %*% V %*% grad))
n <- as.integer(nrow(d))

res <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = unname(ratio), se = unname(ratio_se), n_obs = n),
    list(term = "reduced_form", estimate = unname(jumps[1]), se = unname(se_jumps[1]), n_obs = n),
    list(term = "first_stage", estimate = unname(jumps[2]), se = unname(se_jumps[2]), n_obs = n)
  ),
  method_metadata = list(
    estimator = "Fuzzy RD, local linear with separate slopes, triangular kernel, bandwidth 1, cutoff 0",
    vcov = "HC0 sandwich, delta method for ratio"
  ),
  diagnostics = list(
    bandwidth = 1,
    n_left = as.integer(sum(left)),
    n_right = as.integer(sum(right))
  )
)

write_json(res, "result.json", auto_unbox = TRUE, digits = 16, pretty = TRUE)
