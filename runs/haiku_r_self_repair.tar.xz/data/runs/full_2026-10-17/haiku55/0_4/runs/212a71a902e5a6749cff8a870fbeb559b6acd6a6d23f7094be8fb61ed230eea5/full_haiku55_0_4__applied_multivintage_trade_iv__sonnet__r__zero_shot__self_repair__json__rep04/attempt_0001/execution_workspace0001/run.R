library(jsonlite)

num <- function(x) as.numeric(trimws(x))
chr <- function(x) trimws(as.character(x))

crosswalk <- read.csv("crosswalk.csv", colClasses = "character", stringsAsFactors = FALSE)
trade <- read.csv("trade.csv", colClasses = "character", stringsAsFactors = FALSE)
areas <- read.csv("areas.csv", colClasses = "character", stringsAsFactors = FALSE)
employment <- read.csv("employment.csv", colClasses = "character", stringsAsFactors = FALSE)
outcomes <- read.csv("outcomes.csv", colClasses = "character", stringsAsFactors = FALSE)

crosswalk$code <- chr(crosswalk$code)
crosswalk$industry <- chr(crosswalk$industry)

trade$period <- chr(trade$period)
trade$code <- chr(trade$code)
trade$us_change <- num(trade$us_change)
trade$other_change <- num(trade$other_change)
trade$price_index <- num(trade$price_index)
trade$years <- num(trade$years)
trade$industry <- crosswalk$industry[match(trade$code, crosswalk$code)]

areas$area <- chr(areas$area)
areas$period <- chr(areas$period)
areas$vintage <- chr(areas$vintage)
areas$total_employment <- num(areas$total_employment)
areas$population <- num(areas$population)

employment$area <- chr(employment$area)
employment$period <- chr(employment$period)
employment$vintage <- chr(employment$vintage)
employment$industry <- chr(employment$industry)
employment$employment <- num(employment$employment)

outcomes$area <- chr(outcomes$area)
outcomes$period <- chr(outcomes$period)
outcomes$control <- num(outcomes$control)
outcomes$change_pp <- num(outcomes$change_pp)

inds <- sort(unique(trade$industry))
area_ids <- unique(areas$area)

emp_key <- paste(employment$area, employment$period, employment$vintage, employment$industry, sep = "|")
get_emp <- function(a, p, v, j) {
  x <- employment$employment[match(paste(a, p, v, j, sep = "|"), emp_key)]
  x[is.na(x)] <- 0
  x
}

area_key <- paste(areas$area, areas$period, areas$vintage, sep = "|")
trade_key <- paste(trade$period, trade$industry, sep = "|")
price <- trade$price_index[match(outcomes$period, trade$period)]
years <- trade$years[match(outcomes$period, trade$period)]

build_exposure <- function(v, shock) {
  tot <- areas$total_employment[match(paste(outcomes$area, outcomes$period, v, sep = "|"), area_key)]
  x <- numeric(nrow(outcomes))
  for (j in inds) {
    emp <- get_emp(outcomes$area, outcomes$period, v, j)
    nat <- vapply(outcomes$period, function(p) sum(get_emp(area_ids, p, v, j)), numeric(1))
    sh <- trade[[shock]][match(paste(outcomes$period, j, sep = "|"), trade_key)]
    x <- x + (emp / tot) * (sh / nat) / (price / 100) / 1000 * (10 / years)
  }
  x
}

x <- build_exposure("base", "us_change")
z <- build_exposure("early", "other_change")
w <- areas$population[match(paste(outcomes$area, outcomes$period, "base", sep = "|"), area_key)]

pnum <- num(outcomes$period)
X <- cbind(1, pnum, outcomes$control, x)
Z <- cbind(1, pnum, outcomes$control, z)
sw <- sqrt(w)
Xw <- X * sw
Zw <- Z * sw
yw <- outcomes$change_pp * sw

PZ <- Zw %*% solve(crossprod(Zw), t(Zw))
A <- t(Xw) %*% PZ %*% Xw
b <- t(Xw) %*% PZ %*% yw
beta <- as.vector(solve(A, b))
iv_slope <- beta[4]

i00 <- which(outcomes$area == "0" & outcomes$period == "0")
i01 <- which(outcomes$area == "0" & outcomes$period == "1")

n_obs <- as.integer(nrow(outcomes))

estimates <- list(
  list(term = "iv_slope", estimate = iv_slope, se = NA_real_, n_obs = n_obs),
  list(term = "exposure_area0_period0", estimate = x[i00], se = NA_real_, n_obs = n_obs),
  list(term = "exposure_area0_period1", estimate = x[i01], se = NA_real_, n_obs = n_obs),
  list(term = "instrument_area0_period0", estimate = z[i00], se = NA_real_, n_obs = n_obs)
)

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    method = "weighted_2sls",
    outcome = "change_pp",
    endogenous = "x",
    instrument = "z",
    exogenous = c("intercept", "period", "control"),
    weight = "population_base_vintage",
    exposure_units = "thousands of real dollars per worker per decade",
    denominator = "national base industry employment summed over supplied areas"
  ),
  diagnostics = list(
    n_obs = n_obs,
    n_areas = as.integer(length(area_ids)),
    n_industries = as.integer(length(inds)),
    instrument_rank = as.integer(qr(Zw)$rank),
    regressor_rank = as.integer(qr(Xw)$rank)
  )
)

write_json(result, "result.json", auto_unbox = TRUE, digits = NA, na = "null", pretty = TRUE)
