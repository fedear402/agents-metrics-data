library(jsonlite)

d <- read.csv("input.csv", stringsAsFactors = FALSE)
cohorts <- c(3, 5, 7)

res <- lapply(cohorts, function(cc) {
  win <- (cc - 2):(cc + 2)
  s <- d[d$time %in% win & (d$g == cc | d$g == 0 | d$g > cc + 2), ]
  n_times <- tapply(s$time, s$id, function(t) length(unique(t)))
  keep_ids <- names(n_times)[n_times == length(win)]
  s <- s[as.character(s$id) %in% keep_ids, ]
  s$did <- as.integer(s$g == cc & s$time >= cc)
  fit <- lm(y ~ did + factor(id) + factor(time), data = s)
  list(
    att = unname(coef(fit)["did"]),
    n_obs = nrow(s),
    n_treated = length(unique(s$id[s$g == cc]))
  )
})

atts <- vapply(res, function(r) r$att, numeric(1))
n_obs <- vapply(res, function(r) r$n_obs, numeric(1))
wts <- vapply(res, function(r) r$n_treated, numeric(1))
att_weighted <- sum(wts * atts) / sum(wts)

fmt <- function(x) sprintf("%.15g", x)

out <- list(
  task_id = "broad_cohort_stack",
  platform = "r",
  estimates = list(
    list(term = "att_g3", estimate = fmt(atts[1]), se = NA, n_obs = as.integer(n_obs[1])),
    list(term = "att_g5", estimate = fmt(atts[2]), se = NA, n_obs = as.integer(n_obs[2])),
    list(term = "att_g7", estimate = fmt(atts[3]), se = NA, n_obs = as.integer(n_obs[3])),
    list(term = "att_weighted", estimate = fmt(att_weighted), se = NA, n_obs = as.integer(sum(n_obs)))
  ),
  method_metadata = setNames(list(), character(0)),
  diagnostics = setNames(list(), character(0))
)

write_json(out, "result.json", auto_unbox = TRUE, pretty = TRUE, na = "null")
