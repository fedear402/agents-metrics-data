library(jsonlite)

households <- read.csv("households.csv", stringsAsFactors = FALSE)
census <- read.csv("census.csv", stringsAsFactors = FALSE)

d <- households[households$recipient == 0, ]
num <- function(x) as.numeric(x)

e <- num(d$eligible)
ne <- 1 - e
dose <- num(d$dose)
base <- num(d$baseline)
inst <- num(d$instrument)
w <- num(d$weight)
y <- num(d$outcome)

endog <- cbind(dose * ne, dose * e)
exog <- cbind(ne, e, base * ne, base * e)
instr <- cbind(exog, inst * ne, inst * e)
colnames(endog) <- c("dose_ineligible", "dose_eligible")

R <- cbind(endog, exog)
Z <- instr

sw <- sqrt(w)
Rw <- R * sw
Zw <- Z * sw
yw <- y * sw

Rhat <- Zw %*% solve(crossprod(Zw), crossprod(Zw, Rw))
beta <- solve(crossprod(Rhat), crossprod(Rhat, yw))

slope_ineligible <- beta[1, 1]
slope_eligible <- beta[2, 1]

i0 <- ne == 1
i1 <- e == 1
mean_dose_ineligible <- sum(w[i0] * dose[i0]) / sum(w[i0])
mean_dose_eligible <- sum(w[i1] * dose[i1]) / sum(w[i1])

ineligible_effect <- slope_ineligible * mean_dose_ineligible
eligible_nonrecipient_effect <- slope_eligible * mean_dose_eligible

N0 <- sum(num(census$nonrecipient_population[census$eligible == 0]))
N1 <- sum(num(census$nonrecipient_population[census$eligible == 1]))
share0 <- N0 / (N0 + N1)
share1 <- N1 / (N0 + N1)

population_effect <- share0 * ineligible_effect + share1 * eligible_nonrecipient_effect

n_obs <- as.integer(nrow(d))

estimates <- list(
  list(term = "ineligible_effect", estimate = ineligible_effect,
       se = NA_real_, n_obs = n_obs),
  list(term = "eligible_nonrecipient_effect", estimate = eligible_nonrecipient_effect,
       se = NA_real_, n_obs = n_obs),
  list(term = "population_effect", estimate = population_effect,
       se = NA_real_, n_obs = n_obs)
)

method_metadata <- list(
  method = "weighted two-stage least squares",
  implementation = "sqrt-weighted projection onto instrument space, no intercept",
  endogenous = c("dose*(1-eligible)", "dose*eligible"),
  exogenous = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"),
  instruments = c("exogenous set", "instrument*(1-eligible)", "instrument*eligible"),
  regression_weight = "weight",
  sample = "recipient == 0, all eligibility and treatment groups",
  group_effect = "fitted dose slope times weighted mean dose within group",
  population_aggregation = "census nonrecipient_population group shares",
  counterfactual = "dose set to zero for every retained household (synthetic attribution convention)"
)

diagnostics <- list(
  n_obs = n_obs,
  n_ineligible = as.integer(sum(i0)),
  n_eligible = as.integer(sum(i1)),
  instrument_rank = as.integer(qr(Zw)$rank),
  regressor_count = as.integer(ncol(R)),
  slope_ineligible = slope_ineligible,
  slope_eligible = slope_eligible,
  weighted_mean_dose_ineligible = mean_dose_ineligible,
  weighted_mean_dose_eligible = mean_dose_eligible,
  census_nonrecipient_population_ineligible = N0,
  census_nonrecipient_population_eligible = N1,
  population_weight_ineligible = share0,
  population_weight_eligible = share1
)

result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = method_metadata,
  diagnostics = diagnostics
)

write_json(result, "result.json", auto_unbox = TRUE, pretty = TRUE,
           digits = NA, na = "null")
