suppressPackageStartupMessages(library(jsonlite))

df <- read.csv("input.csv", stringsAsFactors = FALSE)
df$date <- as.Date(df$date)
df <- df[order(df$date), ]
n <- nrow(df)

L <- 15
dv <- c(NA, diff(log(df$vix)))
ly <- log(df$sales)

idx <- (L + 2):n
X <- cbind(1, sapply(1:L, function(j) dv[idx - j]))
y <- ly[idx]
N <- length(y)
K <- ncol(X)

fit <- lm.fit(X, y)
b <- fit$coefficients
u <- fit$residuals

B <- solve(crossprod(X) / N)
h <- X * u
Omega <- crossprod(h) / N
for (j in 1:L) {
  w <- 1 - j / (L + 1)
  G <- crossprod(h[(j + 1):N, , drop = FALSE], h[1:(N - j), , drop = FALSE]) / N
  Omega <- Omega + w * (G + t(G))
}
V <- B %*% Omega %*% B / N * N / (N - K)

a <- c(0, rep(1, L))
cum_est <- sum(b[-1])
cum_se <- sqrt(as.numeric(t(a) %*% V %*% a))

res <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(term = "cumulative_response", estimate = cum_est, se = cum_se, n_obs = N),
    list(term = "lag_1", estimate = unname(b[2]), se = sqrt(V[2, 2]), n_obs = N),
    list(term = "lag_15", estimate = unname(b[16]), se = sqrt(V[16, 16]), n_obs = N)
  ),
  method_metadata = list(
    estimator = "OLS regression of log(sales) on intercept and 15 lags of first difference of log(vix)",
    vcov = "Newey-West HAC, max lag 15, Bartlett weights 1-j/16, scaled by N/(N-16)"
  ),
  diagnostics = list()
)

write_json(res, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE)
