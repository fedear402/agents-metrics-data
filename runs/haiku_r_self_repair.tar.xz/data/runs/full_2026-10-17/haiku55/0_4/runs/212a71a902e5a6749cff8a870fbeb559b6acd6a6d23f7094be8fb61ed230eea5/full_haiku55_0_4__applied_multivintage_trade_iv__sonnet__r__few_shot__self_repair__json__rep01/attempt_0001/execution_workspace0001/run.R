crosswalk <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
trade <- read.csv("trade.csv", stringsAsFactors = FALSE)
areas <- read.csv("areas.csv", stringsAsFactors = FALSE)
employment <- read.csv("employment.csv", stringsAsFactors = FALSE)
outcomes <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

iv <- function(y, C, x, z, w = rep(1, length(y))) {
  X <- cbind(C, x) * sqrt(w)
  Z <- cbind(C, z) * sqrt(w)
  fitted <- qr.fitted(qr(Z), X)
  as.numeric(qr.coef(qr(fitted), y * sqrt(w)))[ncol(X)]
}

trade$industry <- crosswalk$industry[match(trade$code, crosswalk$code)]
industries <- sort(unique(crosswalk$industry))

keys <- unique(areas[c("area", "period", "vintage")])
grid <- merge(keys, data.frame(industry = industries), by = NULL)
grid <- merge(grid,
              employment[c("area", "period", "vintage", "industry", "employment")],
              by = c("area", "period", "vintage", "industry"), all.x = TRUE)
grid$employment[is.na(grid$employment)] <- 0

nat <- aggregate(employment ~ period + vintage + industry, data = grid, FUN = sum)
names(nat)[names(nat) == "employment"] <- "national"
grid <- merge(grid, nat, by = c("period", "vintage", "industry"))

grid <- merge(grid,
              trade[c("period", "industry", "us_change", "other_change", "price_index", "years")],
              by = c("period", "industry"))
grid <- merge(grid, areas[c("area", "period", "vintage", "total_employment")],
              by = c("area", "period", "vintage"))

termfun <- function(emp, tot, nat_emp, chg, pidx, yrs) {
  emp / tot * chg / nat_emp / (pidx / 100) / 1000 * (10 / yrs)
}

b <- grid[grid$vintage == "base", ]
e <- grid[grid$vintage == "early", ]
b$t <- termfun(b$employment, b$total_employment, b$national, b$us_change, b$price_index, b$years)
e$t <- termfun(e$employment, e$total_employment, e$national, e$other_change, e$price_index, e$years)
xs <- aggregate(t ~ area + period, data = b, FUN = sum)
names(xs)[names(xs) == "t"] <- "x"
zs <- aggregate(t ~ area + period, data = e, FUN = sum)
names(zs)[names(zs) == "t"] <- "z"

base_areas <- areas[areas$vintage == "base", c("area", "period", "population")]
dat <- merge(base_areas, xs, by = c("area", "period"))
dat <- merge(dat, zs, by = c("area", "period"))
dat <- merge(dat, outcomes[c("area", "period", "control", "change_pp")], by = c("area", "period"))

periods <- sort(unique(dat$period))
dat$pidx <- match(dat$period, periods) - 1

C <- cbind(1, dat$pidx, dat$control)
slope <- iv(dat$change_pp, C, dat$x, dat$z, dat$population)

is_area0 <- as.character(dat$area) == "0"
exp_a0_p0 <- dat$x[is_area0 & dat$pidx == 0]
exp_a0_p1 <- dat$x[is_area0 & dat$pidx == 1]
inst_a0_p0 <- dat$z[is_area0 & dat$pidx == 0]

n <- as.integer(nrow(dat))

est <- list(
  list(term = "iv_slope", estimate = slope, se = NULL, n_obs = n),
  list(term = "exposure_area0_period0", estimate = exp_a0_p0, se = NULL, n_obs = n),
  list(term = "exposure_area0_period1", estimate = exp_a0_p1, se = NULL, n_obs = n),
  list(term = "instrument_area0_period0", estimate = inst_a0_p0, se = NULL, n_obs = n)
)

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = est,
  method_metadata = list(
    method = "weighted_2sls",
    outcome = "change_pp",
    endogenous = "x",
    instruments = "z",
    exogenous = c("intercept", "period", "control"),
    weight = "base_population"
  ),
  diagnostics = list(
    n_obs = n,
    n_industries = as.integer(length(industries)),
    n_periods = as.integer(length(periods))
  )
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE)
