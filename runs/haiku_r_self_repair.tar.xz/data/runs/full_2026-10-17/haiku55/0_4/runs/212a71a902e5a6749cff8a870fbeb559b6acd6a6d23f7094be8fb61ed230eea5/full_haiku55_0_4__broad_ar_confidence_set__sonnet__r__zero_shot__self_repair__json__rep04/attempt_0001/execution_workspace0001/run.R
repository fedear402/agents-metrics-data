suppressPackageStartupMessages(library(jsonlite))

d <- read.csv("input.csv")
n <- nrow(d)
y <- d$y
e <- d$endog
x <- d$x
Z <- cbind(d$z1, d$z2)

X0 <- cbind(1, x)
X1 <- cbind(1, x, Z)
resid_on <- function(X, v) qr.resid(qr(X), v)

a0 <- resid_on(X0, y)
b0 <- resid_on(X0, e)
a1 <- resid_on(X1, y)
b1 <- resid_on(X1, e)

Q0 <- sum(a0^2); P0 <- sum(a0 * b0); R0 <- sum(b0^2)
Q1 <- sum(a1^2); P1 <- sum(a1 * b1); R1 <- sum(b1^2)

crit <- qf(0.95, 2, n - 4)
k <- crit / (n - 4)

A <- (R0 - R1) / 2 - k * R1
B <- -(P0 - P1) + 2 * k * P1
C <- (Q0 - Q1) / 2 - k * Q1
disc <- B^2 - 4 * A * C

Fstat <- function(b) {
  rss0 <- Q0 - 2 * b * P0 + b^2 * R0
  rss1 <- Q1 - 2 * b * P1 + b^2 * R1
  ((rss0 - rss1) / 2) / (rss1 / (n - 4))
}

if (A > 0 && disc >= 0) {
  r <- (-B + c(-1, 1) * sqrt(disc)) / (2 * A)
  lo <- min(r)
  hi <- max(r)
} else {
  lo <- NA_real_
  hi <- NA_real_
}

unb <- if (A < 0) 1 else if (A == 0) {
  if (B != 0) 1 else if (C <= 0) 1 else 0
} else 0

accepts0 <- as.numeric(C <= 0)
ar1 <- Fstat(1)

est <- function(term, v) list(term = term, estimate = as.numeric(v), se = NA_real_, n_obs = as.integer(n))

out <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = list(
    est("boundary_low", lo),
    est("boundary_high", hi),
    est("accepts_zero", accepts0),
    est("unbounded", unb),
    est("ar_f_at_one", ar1)
  ),
  method_metadata = list(
    estimator = "Anderson-Rubin test inversion with joint F test of excluded instruments",
    vcov = "homoskedastic"
  ),
  diagnostics = list(
    quad_A = A,
    quad_B = B,
    quad_C = C,
    discriminant = disc,
    critical_value = crit
  )
)

write(toJSON(out, auto_unbox = TRUE, digits = NA, na = "null", pretty = TRUE), "result.json")
