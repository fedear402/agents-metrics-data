library(jsonlite)

d <- read.csv("input.csv", stringsAsFactors = FALSE)
d$date <- as.Date(d$date)
d <- d[order(d$date), ]
d$log_sales <- log(d$sales)
d$log_vix <- log(d$vix)
d$vix_change <- c(NA, diff(d$log_vix))

L <- 15
for (k in seq_len(L)) {
  d[[paste0("lag_", k)]] <- c(rep(NA, k), head(d$vix_change, -k))
}

lag_names <- paste0("lag_", seq_len(L))
sample <- d[complete.cases(d[, c("log_sales", lag_names)]), ]
fit <- lm(reformulate(lag_names, response = "log_sales"), data = sample)

X <- model.matrix(fit)
coefficients <- coef(fit)
N <- nrow(X)
p <- ncol(X)
scores <- X * residuals(fit)
hac_lags <- L

meat <- crossprod(scores)
for (j in seq_len(hac_lags)) {
  w <- 1 - j / (hac_lags + 1)
  gamma <- crossprod(scores[(j + 1):N, , drop = FALSE], scores[1:(N - j), , drop = FALSE])
  meat <- meat + w * (gamma + t(gamma))
}

bread <- solve(crossprod(X))
covariance <- N / (N - p) * bread %*% meat %*% bread

contrast <- c(0, rep(1, L))
cumulative <- sum(contrast * coefficients)
cumulative_se <- sqrt(drop(t(contrast) %*% covariance %*% contrast))

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(term = "cumulative_response", estimate = unname(as.numeric(cumulative)),
         se = unname(as.numeric(cumulative_se)), n_obs = as.integer(N)),
    list(term = "lag_1", estimate = unname(as.numeric(coefficients[2])),
         se = unname(as.numeric(sqrt(covariance[2, 2]))), n_obs = as.integer(N)),
    list(term = "lag_15", estimate = unname(as.numeric(coefficients[L + 1])),
         se = unname(as.numeric(sqrt(covariance[L + 1, L + 1]))), n_obs = as.integer(N))
  ),
  method_metadata = list(
    estimator = "OLS of log(sales) on intercept and 15 lags of volatility log-change",
    vcov = "Newey-West HAC, max lag 15, Bartlett weights, small-sample factor N/(N-16)"
  ),
  diagnostics = setNames(list(), character(0))
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
