library(jsonlite)

hh <- read.csv("households.csv", stringsAsFactors = FALSE)
census <- read.csv("census.csv", stringsAsFactors = FALSE)

d <- hh[hh$recipient == 0, , drop = FALSE]
d <- d[complete.cases(d[, c("eligible", "dose", "baseline", "instrument", "weight", "outcome")]), , drop = FALSE]

e <- as.numeric(d$eligible)
m <- 1 - e
dose <- as.numeric(d$dose)
base <- as.numeric(d$baseline)
inst <- as.numeric(d$instrument)
w <- as.numeric(d$weight)
y <- as.numeric(d$outcome)

X <- cbind(
  ineligible_intercept = m,
  eligible_intercept = e,
  baseline_ineligible = base * m,
  baseline_eligible = base * e,
  dose_ineligible = dose * m,
  dose_eligible = dose * e
)

Z <- cbind(
  instrument_ineligible_intercept = m,
  instrument_eligible_intercept = e,
  instrument_baseline_ineligible = base * m,
  instrument_baseline_eligible = base * e,
  instrument_dose_ineligible = inst * m,
  instrument_dose_eligible = inst * e
)

ZtWZ <- crossprod(Z, Z * w)
ZtWX <- crossprod(Z, X * w)
ZtWy <- crossprod(Z, y * w)

A <- crossprod(ZtWX, solve(ZtWZ, ZtWX))
b <- crossprod(ZtWX, solve(ZtWZ, ZtWy))
beta <- as.vector(solve(A, b))
names(beta) <- colnames(X)

slope_ineligible <- unname(beta["dose_ineligible"])
slope_eligible <- unname(beta["dose_eligible"])

idx0 <- e == 0
idx1 <- e == 1
wmean_dose_ineligible <- sum(w[idx0] * dose[idx0]) / sum(w[idx0])
wmean_dose_eligible <- sum(w[idx1] * dose[idx1]) / sum(w[idx1])

ineligible_effect <- slope_ineligible * wmean_dose_ineligible
eligible_nonrecipient_effect <- slope_eligible * wmean_dose_eligible

N0 <- sum(census$nonrecipient_population[census$eligible == 0])
N1 <- sum(census$nonrecipient_population[census$eligible == 1])
population_effect <- (N0 * ineligible_effect + N1 * eligible_nonrecipient_effect) / (N0 + N1)

n_obs <- as.integer(nrow(d))

estimates <- list(
  list(term = "ineligible_effect", estimate = unname(ineligible_effect), se = NULL, n_obs = n_obs),
  list(term = "eligible_nonrecipient_effect", estimate = unname(eligible_nonrecipient_effect), se = NULL, n_obs = n_obs),
  list(term = "population_effect", estimate = unname(population_effect), se = NULL, n_obs = n_obs)
)

method_metadata <- list(
  method = "weighted 2SLS",
  weighting = "weight used as regression weight",
  intercept = "none",
  endogenous = c("dose_ineligible", "dose_eligible"),
  instruments = colnames(Z),
  counterfactual = "dose set to zero for every retained household",
  attribution = "synthetic convention: group dose slope times weighted mean dose",
  sample = "recipient == 0, both treatment statuses included"
)

diagnostics <- list(
  n_obs = n_obs,
  n_ineligible = as.integer(sum(idx0)),
  n_eligible = as.integer(sum(idx1)),
  dose_slope_ineligible = slope_ineligible,
  dose_slope_eligible = slope_eligible,
  weighted_mean_dose_ineligible = wmean_dose_ineligible,
  weighted_mean_dose_eligible = wmean_dose_eligible,
  nonrecipient_population_ineligible = N0,
  nonrecipient_population_eligible = N1,
  instrument_matrix_rank = as.integer(qr(Z)$rank),
  regressor_matrix_rank = as.integer(qr(X)$rank)
)

result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = method_metadata,
  diagnostics = diagnostics
)

write_json(result, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE, null = "null")
