library(jsonlite)

df <- read.csv("input.csv", stringsAsFactors = FALSE)

first_row <- !duplicated(df$region_id)
reg_ids <- df$region_id[first_row]
R <- length(reg_ids)
r_idx <- match(df$region_id, reg_ids)

rw <- df$region_weight[first_row]
x_r <- df$x[first_row]
y_r <- df$y[first_row]
z_r <- as.numeric(tapply(df$share * df$shock, r_idx, sum))

e <- rw / sum(rw)
e_row <- e[r_idx]

x0 <- x_r - sum(e * x_r)
y0 <- y_r - sum(e * y_r)
z0 <- z_r - sum(e * z_r)

ind_ids <- sort(unique(df$industry_id))
i_idx <- match(df$industry_id, ind_ids)
N <- length(ind_ids)

s <- as.numeric(tapply(e_row * df$share, i_idx, sum))
shock_n <- as.numeric(tapply(df$shock, i_idx, mean))

agg <- function(v0_reg) {
  v_row <- v0_reg[r_idx]
  as.numeric(tapply(e_row * df$share * v_row, i_idx, sum)) / s
}

ybar <- agg(y0)
xbar <- agg(x0)
zbar <- agg(z0)

iv_reg <- function(y, X, Z, w) {
  A <- t(Z) %*% (w * X)
  b <- solve(A, t(Z) %*% (w * y))
  list(b = as.numeric(b), A = A)
}

reg_fit <- iv_reg(y_r, cbind(1, x_r), cbind(1, z_r), e)
effect_est <- unname(reg_fit$b[2])

sl_iv <- function(y, endo, inst, w) {
  n <- length(y)
  X <- cbind(1, endo)
  Z <- cbind(1, inst)
  A <- t(Z) %*% (w * X)
  b <- solve(A, t(Z) %*% (w * y))
  u <- as.numeric(y - X %*% b)
  Ai <- solve(A)
  meat <- t(Z) %*% (((w * u)^2) * Z)
  V <- Ai %*% meat %*% t(Ai) * n / (n - 2)
  list(b = as.numeric(b), V = V)
}

eff_fit <- sl_iv(ybar, xbar, shock_n, s)
effect_se <- sqrt(as.numeric(eff_fit$V[2, 2]))

fs_est <- unname(coef(lm(x_r ~ z_r, weights = e))[2])
fs_fit <- sl_iv(xbar, zbar, shock_n, s)
fs_se <- sqrt(as.numeric(fs_fit$V[2, 2]))

eff_shocks <- 1 / sum(s^2)

out <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = as.numeric(effect_est), se = as.numeric(effect_se), n_obs = as.integer(N)),
    list(term = "first_stage", estimate = as.numeric(fs_est), se = as.numeric(fs_se), n_obs = as.integer(N)),
    list(term = "effective_shocks", estimate = as.numeric(eff_shocks), se = NA_real_, n_obs = as.integer(N))
  ),
  method_metadata = list(
    estimator = "Weighted 2SLS shift-share with BHJ shock-level aggregation (weights e_r, shock-level weights s_n)",
    vcov = "Shock-level heteroskedasticity-robust HC1 (N/(N-2)), structural IV residuals, no clustering"
  ),
  diagnostics = list(
    n_regions = as.integer(R),
    n_industries = as.integer(N),
    shock_level_effect = as.numeric(eff_fit$b[2]),
    shock_level_first_stage = as.numeric(fs_fit$b[2])
  )
)

write_json(out, "result.json", auto_unbox = TRUE, digits = NA, na = "null", pretty = TRUE)
