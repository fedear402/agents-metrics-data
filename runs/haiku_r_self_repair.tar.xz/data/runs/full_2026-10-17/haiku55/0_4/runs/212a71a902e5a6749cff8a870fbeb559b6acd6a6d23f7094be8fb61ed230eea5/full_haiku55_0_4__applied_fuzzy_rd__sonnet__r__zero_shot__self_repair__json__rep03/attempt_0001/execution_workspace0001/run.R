library(jsonlite)

d <- read.csv("input.csv")
d <- d[complete.cases(d[, c("score", "participated", "earnings")]), ]
d <- d[abs(d$score) < 1, ]
w <- 1 - abs(d$score)
Y <- cbind(earnings = d$earnings, participated = d$participated)

side_fit <- function(idx) {
  s <- d$score[idx]
  X <- cbind(1, s)
  W <- w[idx]
  Yi <- Y[idx, , drop = FALSE]
  B <- solve(crossprod(X, W * X))
  beta <- B %*% crossprod(X, W * Yi)
  E <- Yi - X %*% beta
  l <- as.vector(B[1, ] %*% t(X))
  h2 <- (l * W)^2
  V <- t(E) %*% (E * h2)
  list(a = beta[1, ], V = V, n = sum(idx))
}

is_right <- d$score >= 0
L <- side_fit(!is_right)
R <- side_fit(is_right)

D <- R$a - L$a
Vd <- R$V + L$V

tau <- D[1] / D[2]
g <- c(1 / D[2], -D[1] / D[2]^2)
se_tau <- sqrt(as.numeric(t(g) %*% Vd %*% g))
se_rf <- sqrt(Vd[1, 1])
se_fs <- sqrt(Vd[2, 2])

n_total <- nrow(d)

res <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = unname(tau), se = se_tau, n_obs = as.integer(n_total)),
    list(term = "reduced_form", estimate = unname(D[1]), se = se_rf, n_obs = as.integer(n_total)),
    list(term = "first_stage", estimate = unname(D[2]), se = se_fs, n_obs = as.integer(n_total))
  ),
  method_metadata = list(
    estimator = "fuzzy RD, local linear, triangular kernel, bandwidth 1, cutoff 0, separate WLS intercepts and slopes on each side, ratio via delta method",
    vcov = "HC0 heteroskedasticity-robust, joint covariance across outcomes and sides, delta method for treatment_effect"
  ),
  diagnostics = list(
    cutoff = 0,
    bandwidth = 1,
    kernel = "triangular",
    n_left = as.integer(L$n),
    n_right = as.integer(R$n)
  )
)

write_json(res, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE, null = "null")
