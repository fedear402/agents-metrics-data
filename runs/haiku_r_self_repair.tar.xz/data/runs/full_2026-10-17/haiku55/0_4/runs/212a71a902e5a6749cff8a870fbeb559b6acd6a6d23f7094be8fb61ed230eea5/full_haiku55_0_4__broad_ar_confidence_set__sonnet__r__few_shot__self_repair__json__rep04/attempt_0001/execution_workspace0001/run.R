d <- read.csv("input.csv")
n <- nrow(d)
q <- 2L
df <- n - 4L
critical <- qf(0.95, q, df)
k <- q * critical / df

y <- d$y
endog <- d$endog
x <- d$x
z1 <- d$z1
z2 <- d$z2

# Partial out intercept and x from y, endog, z1, z2 (equivalent to full regression F test)
Xc <- cbind(1, x)
ry <- residuals(lm(y ~ x, data = d))
re <- residuals(lm(endog ~ x, data = d))
rz1 <- residuals(lm(z1 ~ x, data = d))
rz2 <- residuals(lm(z2 ~ x, data = d))

# Quadratic form: SSR_R(b) - (1+k) SSR_U(b) <= 0, where residuals of y - b*endog
# are linear in b. Expand using residuals on (1, x) and (z1, z2) projections.
Zt <- cbind(1, x, z1, z2)
Pz <- function(v) {
  fit <- lm(v ~ x + z1 + z2, data = d)
  residuals(fit)
}
# Residual-maker for restricted (intercept only) and unrestricted (intercept, x, z1, z2)
M_restr <- function(v) v - mean(v)
M_full <- function(v) residuals(lm(v ~ x + z1 + z2, data = d))

# Restricted SSR(b) = sum((M_restr(y - b*endog))^2) -> with restricted = intercept + x
# The test regresses y - b*endog on (1, x, z1, z2); restricted model is (1, x).
rY  <- residuals(lm(y ~ x, data = d))
rE  <- residuals(lm(endog ~ x, data = d))
uY  <- residuals(lm(y ~ x + z1 + z2, data = d))
uE  <- residuals(lm(endog ~ x + z1 + z2, data = d))

A <- sum(rE^2) - (1 + k) * sum(uE^2)
B <- -2 * (sum(rY * rE) - (1 + k) * sum(uY * uE))
C <- sum(rY^2) - (1 + k) * sum(uY^2)

accepts <- function(b) A * b^2 + B * b + C <= 0

disc <- B^2 - 4 * A * C
stopifnot(abs(A) > 1e-10, disc > 0)
roots <- sort(Re(polyroot(c(C, B, A))))

unbounded <- as.integer(A < 0)

# Verify boundaries against direct F test
for (b in roots) {
  tr <- y - b * endog
  fr <- lm(tr ~ 1 + x)
  ff <- lm(tr ~ x + z1 + z2, data = d)
  Fb <- ((deviance(fr) - deviance(ff)) / q) / (deviance(ff) / df)
  stopifnot(abs(Fb - critical) < 1e-6)
}

f_at_one <- {
  tr <- y - 1 * endog
  fr <- lm(tr ~ x)
  ff <- lm(tr ~ x + z1 + z2, data = d)
  ((deviance(fr) - deviance(ff)) / q) / (deviance(ff) / df)
}

accepts_zero <- as.integer(accepts(0))

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = list(
    list(term = "boundary_low", estimate = unname(roots[1]), se = NULL, n_obs = as.integer(n)),
    list(term = "boundary_high", estimate = unname(roots[2]), se = NULL, n_obs = as.integer(n)),
    list(term = "accepts_zero", estimate = accepts_zero, se = NULL, n_obs = as.integer(n)),
    list(term = "unbounded", estimate = unbounded, se = NULL, n_obs = as.integer(n)),
    list(term = "ar_f_at_one", estimate = unname(f_at_one), se = NULL, n_obs = as.integer(n))
  ),
  method_metadata = list(
    estimator = "Anderson-Rubin confidence set via homoskedastic joint F test of excluded instruments",
    vcov = "homoskedastic"
  ),
  diagnostics = setNames(list(), character(0))
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
