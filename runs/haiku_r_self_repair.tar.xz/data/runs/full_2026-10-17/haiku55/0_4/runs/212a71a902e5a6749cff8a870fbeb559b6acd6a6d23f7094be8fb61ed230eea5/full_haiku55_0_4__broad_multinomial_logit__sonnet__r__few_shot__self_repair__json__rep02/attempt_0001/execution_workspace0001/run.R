d <- read.csv("input.csv")
d$y <- factor(d$y, levels = 0:2)

fit <- nnet::multinom(y ~ x + z, data = d, Hess = TRUE, trace = FALSE,
                      maxit = 1000, reltol = 1e-12, abstol = 1e-12)

B <- coef(fit)
V <- vcov(fit)

coef_row <- function(row, term) unname(B[row, term])
se_of <- function(row, term) sqrt(V[paste0(row, ":", term), paste0(row, ":", term)])

b_x1 <- coef_row("1", "x"); b_z1 <- coef_row("1", "z")
b_x2 <- coef_row("2", "x"); b_z2 <- coef_row("2", "z")

se_x1 <- se_of("1", "x"); se_z1 <- se_of("1", "z")
se_x2 <- se_of("2", "x"); se_z2 <- se_of("2", "z")

indices <- c(0, B[, "(Intercept)"])
p <- exp(indices - max(indices)) / sum(exp(indices - max(indices)))
stopifnot(abs(sum(p) - 1) < 1e-12)
prob_cat2_zero <- unname(p[3])

n_obs <- nrow(d)

res <- list(
  task_id = "broad_multinomial_logit",
  platform = "r",
  estimates = list(
    list(term = "x_cat1", estimate = b_x1, se = se_x1, n_obs = n_obs),
    list(term = "z_cat1", estimate = b_z1, se = se_z1, n_obs = n_obs),
    list(term = "x_cat2", estimate = b_x2, se = se_x2, n_obs = n_obs),
    list(term = "z_cat2", estimate = b_z2, se = se_z2, n_obs = n_obs),
    list(term = "prob_cat2_zero", estimate = prob_cat2_zero, se = NULL, n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "multinomial logit (maximum likelihood, nnet::multinom, base category 0)",
    vcov = "conventional observed-information (inverse Hessian)"
  ),
  diagnostics = setNames(list(), character(0))
)

jsonlite::write_json(res, "result.json", auto_unbox = TRUE, null = "null",
                     digits = 16, pretty = TRUE)
