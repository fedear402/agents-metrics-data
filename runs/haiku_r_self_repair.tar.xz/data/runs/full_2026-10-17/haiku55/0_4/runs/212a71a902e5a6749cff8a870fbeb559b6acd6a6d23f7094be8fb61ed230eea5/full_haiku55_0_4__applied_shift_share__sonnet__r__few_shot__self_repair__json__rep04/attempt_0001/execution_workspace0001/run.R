library(jsonlite)

df <- read.csv("input.csv", stringsAsFactors = FALSE)

regions <- unique(df$region_id)
first <- match(regions, df$region_id)
rw <- df$region_weight[first]
e <- rw / sum(rw)
x <- df$x[first]
y <- df$y[first]
z <- as.numeric(tapply(df$share * df$shock, df$region_id, sum)[as.character(regions)])

wmean <- function(v) sum(e * v)
x0 <- x - wmean(x)
y0 <- y - wmean(y)
z0 <- z - wmean(z)

ri <- match(df$region_id, regions)
inds <- sort(unique(df$industry_id))
ii <- match(df$industry_id, inds)
N <- length(inds)

ew <- e[ri] * df$share
s <- as.numeric(rowsum(ew, ii))
shock_n <- df$shock[match(inds, df$industry_id)]

agg <- function(v) as.numeric(rowsum(ew * v[ri], ii)) / s

ybar <- agg(y0)
xbar <- agg(x0)
zbar <- agg(z0)

shock_iv <- function(dep, endo) {
  X <- cbind(1, endo)
  Z <- cbind(1, shock_n)
  cross <- crossprod(Z, s * X)
  beta <- solve(cross, crossprod(Z, s * dep))
  u <- drop(dep - X %*% beta)
  scores <- Z * (s * u)
  inv <- solve(cross)
  V <- N / (N - 2) * inv %*% crossprod(scores) %*% t(inv)
  c(slope = beta[2], se = sqrt(V[2, 2]))
}

effect <- shock_iv(ybar, xbar)
first_se <- shock_iv(xbar, zbar)[["se"]]
first_est <- sum(e * z0 * x0) / sum(e * z0^2)
effective_shocks <- 1 / sum(s^2)

effect_regional <- sum(e * z0 * y0) / sum(e * z0 * x0)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = unname(as.numeric(effect[["slope"]])),
         se = unname(as.numeric(effect[["se"]])), n_obs = as.integer(N)),
    list(term = "first_stage", estimate = unname(as.numeric(first_est)),
         se = unname(as.numeric(first_se)), n_obs = as.integer(N)),
    list(term = "effective_shocks", estimate = unname(as.numeric(effective_shocks)),
         se = NA_real_, n_obs = as.integer(N))
  ),
  method_metadata = list(
    estimator = "regional weighted 2SLS via Borusyak-Hull-Jaravel shock-level weighted IV",
    vcov = "shock-level HC1 robust with N/(N-2) multiplier, structural residuals, analytic weights"
  ),
  diagnostics = list(
    n_industries = as.integer(N),
    n_regions = as.integer(length(regions)),
    effect_regional_check = unname(as.numeric(effect_regional)),
    effect_shock_minus_regional = unname(as.numeric(effect[["slope"]] - effect_regional))
  )
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null", na = "null",
           digits = 16, pretty = TRUE)
