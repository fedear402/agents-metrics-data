library(jsonlite)

df <- read.csv("input.csv", stringsAsFactors = FALSE)

first <- !duplicated(df$region_id)
reg <- df[first, c("region_id", "region_weight", "x", "y")]
reg$e <- reg$region_weight / sum(reg$region_weight)
zt <- tapply(df$share * df$shock, df$region_id, sum)
reg$z <- as.numeric(zt[as.character(reg$region_id)])

wmean <- function(v, w) sum(w * v) / sum(w)
reg$y0 <- reg$y - wmean(reg$y, reg$e)
reg$x0 <- reg$x - wmean(reg$x, reg$e)
reg$z0 <- reg$z - wmean(reg$z, reg$e)

ridx <- match(df$region_id, reg$region_id)
df$e <- reg$e[ridx]
df$y0 <- reg$y0[ridx]
df$x0 <- reg$x0[ridx]
df$z0 <- reg$z0[ridx]

wiv <- function(y, X, Z, w) {
  A <- t(Z) %*% (w * X)
  b <- solve(A, t(Z) %*% (w * y))
  u <- as.vector(y - X %*% b)
  M <- crossprod(Z, (w^2 * u^2) * Z)
  Ainv <- solve(A)
  V <- Ainv %*% M %*% t(Ainv)
  n <- length(y)
  V <- V * n / (n - 2)
  list(b = as.vector(b), se = sqrt(diag(V)))
}

eff_reg <- wiv(reg$y, cbind(1, reg$x), cbind(1, reg$z), reg$e)$b[2]
fs_reg <- unname(coef(lm(x ~ z, data = reg, weights = e))[2])

ind <- df$industry_id
ids <- sort(unique(ind))
idx <- match(ind, ids)
s <- as.numeric(tapply(df$e * df$share, idx, sum))
agg <- function(v) as.numeric(tapply(df$e * df$share * v, idx, sum)) / s
ybar <- agg(df$y0)
xbar <- agg(df$x0)
zbar <- agg(df$z0)
shock_n <- as.numeric(tapply(df$shock, idx, mean))
N <- length(s)

eff_fit <- wiv(ybar, cbind(1, xbar), cbind(1, shock_n), s)
fs_fit <- wiv(xbar, cbind(1, zbar), cbind(1, shock_n), s)

effective_shocks <- 1 / sum(s^2)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = as.numeric(eff_reg),
         se = as.numeric(eff_fit$se[2]), n_obs = as.integer(N)),
    list(term = "first_stage", estimate = as.numeric(fs_reg),
         se = as.numeric(fs_fit$se[2]), n_obs = as.integer(N)),
    list(term = "effective_shocks", estimate = as.numeric(effective_shocks),
         se = NA_real_, n_obs = as.integer(N))
  ),
  method_metadata = list(
    estimator = "weighted 2SLS shift-share; shock-level BHJ IV aggregation",
    vcov = "shock-level HC1 robust, N/(N-2) multiplier, structural residuals, analytic weights"
  ),
  diagnostics = list(
    n_regions = nrow(reg),
    n_industries = N,
    first_stage_t = as.numeric(fs_fit$b[2] / fs_fit$se[2])
  )
)

write_json(result, "result.json", auto_unbox = TRUE, pretty = TRUE, digits = NA, na = "null")
