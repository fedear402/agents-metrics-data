df <- read.csv("input.csv")
y <- as.integer(df$y)
x <- as.numeric(df$x)
z <- as.numeric(df$z)
X <- cbind(1, x, z)
n <- nrow(X)

Y <- matrix(0, n, 3)
Y[cbind(seq_len(n), y + 1L)] <- 1

nll <- function(par) {
  B <- matrix(par, ncol = 2)
  eta <- cbind(0, X %*% B)
  m <- apply(eta, 1, max)
  lse <- m + log(rowSums(exp(eta - m)))
  -sum(eta[cbind(seq_len(n), y + 1L)] - lse)
}

grad <- function(par) {
  B <- matrix(par, ncol = 2)
  eta <- cbind(0, X %*% B)
  m <- apply(eta, 1, max)
  e <- exp(eta - m)
  P <- e / rowSums(e)
  G <- t(X) %*% (Y[, 2:3] - P[, 2:3])
  -as.vector(G)
}

fit <- optim(rep(0, 6), nll, grad, method = "BFGS",
             control = list(maxit = 10000, reltol = 1e-14))
fit <- optim(fit$par, nll, grad, method = "BFGS",
             control = list(maxit = 10000, reltol = 1e-16))

H <- optimHess(fit$par, nll, grad)
V <- solve(H)
se <- sqrt(diag(V))
B <- matrix(fit$par, nrow = 3, ncol = 2)

denom <- 1 + exp(B[1, 1]) + exp(B[1, 2])
prob_cat2_zero <- exp(B[1, 2]) / denom

fmt <- function(v) {
  if (is.na(v)) "null" else sprintf("%.12g", v)
}

est <- c(
  sprintf('{"term": "x_cat1", "estimate": %s, "se": %s, "n_obs": %d}',
          fmt(B[2, 1]), fmt(se[2]), n),
  sprintf('{"term": "z_cat1", "estimate": %s, "se": %s, "n_obs": %d}',
          fmt(B[3, 1]), fmt(se[3]), n),
  sprintf('{"term": "x_cat2", "estimate": %s, "se": %s, "n_obs": %d}',
          fmt(B[2, 2]), fmt(se[5]), n),
  sprintf('{"term": "z_cat2", "estimate": %s, "se": %s, "n_obs": %d}',
          fmt(B[3, 2]), fmt(se[6]), n),
  sprintf('{"term": "prob_cat2_zero", "estimate": %s, "se": null, "n_obs": %d}',
          fmt(prob_cat2_zero), n)
)

out <- c(
  "{",
  '  "task_id": "broad_multinomial_logit",',
  '  "platform": "r",',
  '  "estimates": [',
  paste0("    ", est, c(rep(",", length(est) - 1), "")),
  "  ],",
  '  "method_metadata": {"estimator": "multinomial logit maximum likelihood (base 0), BFGS via optim", "vcov": "observed information (inverse of numerical Hessian of negative log-likelihood)"},',
  sprintf('  "diagnostics": {"convergence": %d, "log_likelihood": %s, "n_obs": %d, "n_outcome_0": %d, "n_outcome_1": %d, "n_outcome_2": %d}',
          fit$convergence, fmt(-fit$value), n,
          sum(y == 0), sum(y == 1), sum(y == 2)),
  "}"
)

writeLines(out, "result.json")
