library(jsonlite)

d <- read.csv("input.csv", stringsAsFactors = FALSE)

reg <- d[!duplicated(d$region_id), c("region_id", "region_weight", "x", "y")]
reg <- reg[order(reg$region_id), ]

ind_shock <- d[!duplicated(d$industry_id), c("industry_id", "shock")]
ind_shock <- ind_shock[order(ind_shock$industry_id), ]

shares_wide <- reshape(d[, c("region_id", "industry_id", "share")],
                       idvar = "region_id", timevar = "industry_id",
                       direction = "wide")
shares_wide <- shares_wide[order(shares_wide$region_id), ]
share_mat <- as.matrix(shares_wide[, -1])
share_mat[is.na(share_mat)] <- 0

e <- reg$region_weight / sum(reg$region_weight)
shock <- ind_shock$shock
z <- drop(share_mat %*% shock)

wmean <- function(v) sum(e * v)
y0 <- reg$y - wmean(reg$y)
x0 <- reg$x - wmean(reg$x)
z0 <- z - wmean(z)

s <- colSums(e * share_mat)

agg <- function(v0) {
  drop(t(share_mat) %*% (e * v0)) / s
}
ybar <- agg(y0)
xbar <- agg(x0)
zbar <- agg(z0)

shock_iv <- function(dep, endog, instr_endog, shock_vec, w) {
  X <- cbind(1, endog)
  Z <- cbind(1, shock_vec)
  cross <- crossprod(Z, w * X)
  beta <- solve(cross, crossprod(Z, w * dep))
  resid <- drop(dep - X %*% beta)
  scores <- Z * (w * resid)
  bread <- solve(cross)
  N <- length(dep)
  V <- N / (N - 2) * bread %*% crossprod(scores) %*% t(bread)
  c(slope = beta[2], se = sqrt(V[2, 2]))
}

effect <- shock_iv(ybar, xbar, NULL, shock, s)

zx_reg <- sum(e * z0 * x0) / sum(e * z0^2)
zx_se_out <- shock_iv(xbar, zbar, NULL, shock, s)

first_stage_est <- zx_se_out["slope"]
first_stage_se <- zx_se_out["se"]

effective_shocks <- 1 / sum(s^2)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = unname(as.numeric(effect["slope"])),
         se = unname(as.numeric(effect["se"])), n_obs = length(ybar)),
    list(term = "first_stage", estimate = unname(as.numeric(first_stage_est)),
         se = unname(as.numeric(first_stage_se)), n_obs = length(ybar)),
    list(term = "effective_shocks", estimate = unname(as.numeric(effective_shocks)),
         se = NULL, n_obs = length(ybar))
  ),
  method_metadata = list(
    estimator = "weighted 2SLS with shift-share instrument; shock-level BHJ aggregation",
    vcov = "HC1 shock-level robust, N/(N-2) multiplier"
  ),
  diagnostics = setNames(list(), character(0))
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null",
           digits = 16, pretty = TRUE)
