suppressPackageStartupMessages(library(jsonlite))

hh <- read.csv("households.csv", stringsAsFactors = FALSE)
census <- read.csv("census.csv", stringsAsFactors = FALSE)

num_cols <- c("eligible", "treated", "recipient", "instrument", "dose", "baseline", "weight", "outcome")
for (v in num_cols) hh[[v]] <- as.numeric(hh[[v]])
census$eligible <- as.numeric(census$eligible)
census$nonrecipient_population <- as.numeric(census$nonrecipient_population)

d <- hh[hh$recipient == 0, , drop = FALSE]
d <- d[complete.cases(d[, num_cols]), , drop = FALSE]

e1 <- d$eligible
e0 <- 1 - e1
y <- d$outcome
w <- d$weight
n_obs <- as.integer(nrow(d))

X <- cbind(
  dose_inel = d$dose * e0,
  dose_el   = d$dose * e1,
  inel      = e0,
  el        = e1,
  base_inel = d$baseline * e0,
  base_el   = d$baseline * e1
)

Z <- cbind(
  inel      = e0,
  el        = e1,
  base_inel = d$baseline * e0,
  base_el   = d$baseline * e1,
  inst_inel = d$instrument * e0,
  inst_el   = d$instrument * e1
)

ZtWZ <- crossprod(Z, Z * w)
ZtWX <- crossprod(Z, X * w)
ZtWy <- crossprod(Z, y * w)

ZtWZ_inv_ZtWX <- solve(ZtWZ, ZtWX)
ZtWZ_inv_ZtWy <- solve(ZtWZ, ZtWy)
A <- crossprod(ZtWX, ZtWZ_inv_ZtWX)
b_vec <- solve(A, crossprod(ZtWX, ZtWZ_inv_ZtWy))
b <- setNames(as.numeric(b_vec), colnames(X))

slope_inel <- unname(b["dose_inel"])
slope_el   <- unname(b["dose_el"])

w0 <- w[e0 == 1]
w1 <- w[e1 == 1]
mean_dose_inel <- sum(w0 * d$dose[e0 == 1]) / sum(w0)
mean_dose_el   <- sum(w1 * d$dose[e1 == 1]) / sum(w1)

ineligible_effect          <- slope_inel * mean_dose_inel
eligible_nonrecipient_effect <- slope_el * mean_dose_el

N0 <- sum(census$nonrecipient_population[census$eligible == 0])
N1 <- sum(census$nonrecipient_population[census$eligible == 1])
p0 <- N0 / (N0 + N1)
p1 <- 1 - p0
population_effect <- p0 * ineligible_effect + p1 * eligible_nonrecipient_effect

res <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = list(
    list(term = "ineligible_effect", estimate = ineligible_effect, se = NA_real_, n_obs = n_obs),
    list(term = "eligible_nonrecipient_effect", estimate = eligible_nonrecipient_effect, se = NA_real_, n_obs = n_obs),
    list(term = "population_effect", estimate = population_effect, se = NA_real_, n_obs = n_obs)
  ),
  method_metadata = list(
    method = "weighted 2SLS, no intercept",
    endogenous = c("dose*(1-eligible)", "dose*eligible"),
    exogenous = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"),
    instruments = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible",
                    "instrument*(1-eligible)", "instrument*eligible"),
    regression_weight = "weight",
    sample = "recipient == 0, all village treatment statuses",
    counterfactual = "dose set to zero for every retained household",
    group_effect_definition = "fitted dose slope times weighted mean dose within eligibility group",
    aggregation_weights = "census nonrecipient_population by eligibility group",
    attribution_note = "zero-dose attribution is a stated synthetic convention",
    se_status = "not computed"
  ),
  diagnostics = list(
    n_obs = n_obs,
    n_ineligible = as.integer(sum(e0 == 1)),
    n_eligible = as.integer(sum(e1 == 1)),
    slope_ineligible = slope_inel,
    slope_eligible = slope_el,
    mean_dose_ineligible = mean_dose_inel,
    mean_dose_eligible = mean_dose_el,
    census_pop_ineligible = N0,
    census_pop_eligible = N1,
    instrument_matrix_rank = as.integer(qr(Z)$rank),
    all_weights_positive = all(w > 0)
  )
)

write_json(res, "result.json", auto_unbox = TRUE, digits = NA, na = "null", pretty = TRUE)
