suppressPackageStartupMessages(library(jsonlite))

d <- read.csv("./input.csv")
d <- d[order(d$t), ]
d <- d[d$t < 251 & is.finite(d$y), ]
y <- ts(d$y)
n <- as.integer(length(y))

fit <- arima(y, order = c(1, 1, 1), include.mean = FALSE, method = "ML")
p <- predict(fit, n.ahead = 1)

fc <- as.numeric(p$pred)
se <- as.numeric(p$se)
z <- qnorm(0.975)
lower <- fc - z * se
upper <- fc + z * se

res <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = list(
    list(term = "forecast", estimate = fc, se = se, n_obs = n),
    list(term = "lower_95", estimate = lower, se = NULL, n_obs = n),
    list(term = "upper_95", estimate = upper, se = NULL, n_obs = n)
  ),
  method_metadata = list(
    estimator = "ARIMA(1,1,1) maximum likelihood via stats::arima, no constant or drift",
    vcov = "inverse of observed information (stats::arima Hessian); forecast SE from predict.Arima"
  ),
  diagnostics = list(
    coef = as.list(coef(fit)),
    aic = AIC(fit),
    loglik = as.numeric(logLik(fit)),
    sigma2 = fit$sigma2,
    convergence_code = fit$code,
    forecast_origin_t = max(d$t),
    forecast_horizon_t = max(d$t) + 1
  )
)

write_json(res, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE, null = "null")
