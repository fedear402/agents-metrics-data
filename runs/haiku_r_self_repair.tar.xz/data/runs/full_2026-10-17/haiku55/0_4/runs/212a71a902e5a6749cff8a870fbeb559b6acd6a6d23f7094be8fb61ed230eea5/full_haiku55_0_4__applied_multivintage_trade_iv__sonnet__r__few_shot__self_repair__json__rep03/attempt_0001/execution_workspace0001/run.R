crosswalk <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
trade <- read.csv("trade.csv", stringsAsFactors = FALSE)
areas <- read.csv("areas.csv", stringsAsFactors = FALSE)
employment <- read.csv("employment.csv", stringsAsFactors = FALSE)
outcomes <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

iv <- function(y,C,x,z,w=rep(1,length(y))) {
  X <- cbind(C,x)*sqrt(w); Z <- cbind(C,z)*sqrt(w)
  fitted <- qr.fitted(qr(Z),X)
  as.numeric(qr.coef(qr(fitted),y*sqrt(w)))[ncol(X)]
}

tr <- merge(trade, crosswalk[, c("code", "industry")], by = "code")
industries <- sort(unique(crosswalk$industry))

grid <- expand.grid(area = unique(areas$area), period = unique(areas$period),
                    vintage = c("base", "early"), industry = industries,
                    stringsAsFactors = FALSE)
emp <- employment[, c("area", "period", "vintage", "industry", "employment")]
grid <- merge(grid, emp, by = c("area", "period", "vintage", "industry"), all.x = TRUE)
grid$employment[is.na(grid$employment)] <- 0

nat <- aggregate(employment ~ period + vintage + industry, data = grid, FUN = sum)
names(nat)[names(nat) == "employment"] <- "national"
grid <- merge(grid, nat, by = c("period", "vintage", "industry"))

tot <- areas[, c("area", "period", "vintage", "total_employment")]
g <- merge(grid, tot, by = c("area", "period", "vintage"))
g <- merge(g, tr[, c("period", "industry", "us_change", "other_change", "price_index", "years")],
           by = c("period", "industry"))

share <- g$employment / g$total_employment / (g$price_index / 100) / 1000 * (10 / g$years) / g$national
g$x_term <- share * g$us_change
g$z_term <- share * g$other_change

xs <- aggregate(x_term ~ area + period, data = g[g$vintage == "base", ], FUN = sum)
zs <- aggregate(z_term ~ area + period, data = g[g$vintage == "early", ], FUN = sum)
names(xs)[names(xs) == "x_term"] <- "x"
names(zs)[names(zs) == "z_term"] <- "z"

d <- merge(outcomes, areas[areas$vintage == "base", c("area", "period", "population")],
           by = c("area", "period"))
d <- merge(d, xs, by = c("area", "period"))
d <- merge(d, zs, by = c("area", "period"))

per <- as.numeric(as.character(d$period))
C <- cbind(1, per, d$control)
iv_slope <- iv(d$change_pp, C, d$x, d$z, d$population)

is_a0 <- as.character(d$area) == "0"
exposure_area0_period0 <- unname(d$x[is_a0 & as.character(d$period) == "0"])
exposure_area0_period1 <- unname(d$x[is_a0 & as.character(d$period) == "1"])
instrument_area0_period0 <- unname(d$z[is_a0 & as.character(d$period) == "0"])

n_obs <- as.integer(nrow(d))

estimates <- list(
  list(term = "iv_slope", estimate = unname(iv_slope), se = NA_real_, n_obs = n_obs),
  list(term = "exposure_area0_period0", estimate = exposure_area0_period0, se = NA_real_, n_obs = n_obs),
  list(term = "exposure_area0_period1", estimate = exposure_area0_period1, se = NA_real_, n_obs = n_obs),
  list(term = "instrument_area0_period0", estimate = instrument_area0_period0, se = NA_real_, n_obs = n_obs)
)

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "weighted 2SLS",
    outcome = "change_pp",
    endogenous = "x",
    instrument = "z",
    exogenous = c("intercept", "period", "control"),
    weight = "base-vintage population",
    exposure_units = "thousands of real dollars per worker per decade"
  ),
  diagnostics = list(
    n_obs = n_obs,
    n_areas = as.integer(length(unique(d$area))),
    n_periods = as.integer(length(unique(d$period))),
    n_industries = as.integer(length(industries)),
    weight_sum = sum(d$population)
  )
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = NA, na = "null", pretty = TRUE)
