d <- read.csv("input.csv")
cohorts <- c(3, 5, 7)

res <- lapply(cohorts, function(c0) {
  w <- d[d$time >= c0 - 2 & d$time <= c0 + 2 &
         (d$g == c0 | d$g == 0 | d$g > c0 + 2), ]
  n_times <- tapply(w$time, w$id, function(x) length(unique(x)))
  keep_ids <- names(n_times)[n_times == 5]
  w <- w[as.character(w$id) %in% keep_ids, ]
  w$did <- as.numeric(w$g == c0 & w$time >= c0)
  fit <- lm(y ~ did + factor(id) + factor(time), data = w)
  list(
    att = unname(coef(fit)["did"]),
    n_obs = nrow(w),
    n_treated = length(unique(w$id[w$g == c0]))
  )
})

atts <- sapply(res, `[[`, "att")
n_obs <- sapply(res, `[[`, "n_obs")
weights <- sapply(res, `[[`, "n_treated")
att_weighted <- sum(weights * atts) / sum(weights)

out <- list(
  task_id = "broad_cohort_stack",
  platform = "r",
  estimates = list(
    list(term = "att_g3", estimate = atts[1], se = NULL, n_obs = n_obs[1]),
    list(term = "att_g5", estimate = atts[2], se = NULL, n_obs = n_obs[2]),
    list(term = "att_g7", estimate = atts[3], se = NULL, n_obs = n_obs[3]),
    list(term = "att_weighted", estimate = att_weighted, se = NULL, n_obs = sum(n_obs))
  ),
  method_metadata = setNames(list(), character(0)),
  diagnostics = setNames(list(), character(0))
)

jsonlite::write_json(out, "result.json", auto_unbox = TRUE, null = "null", digits = 16)
