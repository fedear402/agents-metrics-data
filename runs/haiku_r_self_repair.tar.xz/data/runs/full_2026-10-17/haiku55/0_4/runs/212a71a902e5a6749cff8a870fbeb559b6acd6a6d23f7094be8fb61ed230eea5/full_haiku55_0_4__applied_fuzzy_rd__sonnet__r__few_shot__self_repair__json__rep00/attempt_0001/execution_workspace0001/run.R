library(jsonlite)

d <- read.csv("input.csv")
d <- d[abs(d$score) < 1, ]
h <- 1
w <- 1 - abs(d$score)
right <- as.numeric(d$score >= 0)
n_obs <- nrow(d)

fit_side <- function(y, x, r, w) {
  X <- cbind(1, x, x * r)
  X <- cbind(1 - r, x * (1 - r), r, x * r)
  XtWX <- crossprod(X, w * X)
  bread <- solve(XtWX)
  beta <- bread %*% crossprod(X, w * y)
  e <- drop(y - X %*% beta)
  list(beta = drop(beta), bread = bread, X = X, e = e, w = w)
}

fit_all <- function(y) {
  X <- cbind(1 - right, d$score * (1 - right), right, d$score * right)
  XtWX <- crossprod(X, w * X)
  bread <- solve(XtWX)
  beta <- drop(bread %*% crossprod(X, w * y))
  e <- drop(y - X %*% beta)
  list(beta = beta, bread = bread, X = X, e = e)
}

yE <- d$earnings
yT <- d$participated

fE <- fit_all(yE)
fT <- fit_all(yT)

contrast <- c(0, 0, -1, 0)
contrast[3] <- 1
cvec <- c(0, 0, 1, 0) - c(1, 0, 0, 0) * 0
cvec <- c(0, 0, 1, 0) - c(0, 0, 0, 0)
cvec <- c(0, 0, 1, 0)
cvec_l <- c(-1, 0, 0, 0)
cvec <- cvec + cvec_l

rf <- sum(cvec * fE$beta)
fs <- sum(cvec * fT$beta)

influence_for <- function(f) {
  loading <- f$w * f$X %*% f$bread %*% cvec
  loading * f$e
}

iE <- drop(influence_for(fE))
iT <- drop(influence_for(fT))
iE <- iE
J <- crossprod(cbind(iE, iT))

se_rf <- sqrt(J[1, 1])
se_fs <- sqrt(J[2, 2])

te <- rf / fs
g <- c(1 / fs, -rf / fs^2)
se_te <- sqrt(drop(t(g) %*% J %*% g))

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = unname(as.numeric(te)),
         se = unname(as.numeric(se_te)), n_obs = as.integer(n_obs)),
    list(term = "reduced_form", estimate = unname(as.numeric(rf)),
         se = unname(as.numeric(se_rf)), n_obs = as.integer(n_obs)),
    list(term = "first_stage", estimate = unname(as.numeric(fs)),
         se = unname(as.numeric(se_fs)), n_obs = as.integer(n_obs))
  ),
  method_metadata = list(
    estimator = "fuzzy RD, local linear, triangular kernel, bandwidth 1, separate slopes, Wald ratio",
    vcov = "HC0 sandwich, delta method for ratio"
  ),
  diagnostics = setNames(list(), character(0))
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
