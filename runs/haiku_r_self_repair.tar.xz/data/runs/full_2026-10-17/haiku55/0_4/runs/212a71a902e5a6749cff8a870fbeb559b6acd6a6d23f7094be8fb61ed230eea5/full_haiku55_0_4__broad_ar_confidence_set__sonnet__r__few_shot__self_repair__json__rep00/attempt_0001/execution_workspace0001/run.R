suppressPackageStartupMessages(library(jsonlite))

d <- read.csv("input.csv")
n <- nrow(d)

ry <- residuals(lm(y ~ x, data = d))
rd <- residuals(lm(endog ~ x, data = d))
full_y <- lm(y ~ x + z1 + z2, data = d)
full_d <- lm(endog ~ x + z1 + z2, data = d)
uy <- residuals(full_y)
ud <- residuals(full_d)

q <- 2L
df <- df.residual(full_y)
critical <- qf(0.95, q, df)
k <- q * critical / df

A <- sum(rd^2) - (1 + k) * sum(ud^2)
B <- -2 * (sum(ry * rd) - (1 + k) * sum(uy * ud))
C <- sum(ry^2) - (1 + k) * sum(uy^2)
disc <- B^2 - 4 * A * C

if (A != 0 && disc >= 0) {
  roots <- sort((-B + c(-1, 1) * sqrt(disc)) / (2 * A))
} else {
  roots <- c(NA_real_, NA_real_)
}

accepts_zero <- as.integer(C <= 0)
unbounded <- as.integer(A < 0 || (A == 0 && (B != 0 || C <= 0)))

transformed <- d$y - d$endog
restricted_fit <- lm(transformed ~ x, data = d)
full_fit <- lm(transformed ~ x + z1 + z2, data = d)
ar_f_at_one <- ((deviance(restricted_fit) - deviance(full_fit)) / q) /
  (deviance(full_fit) / df)

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = list(
    list(term = "boundary_low", estimate = as.numeric(roots[1]), se = NULL, n_obs = as.integer(n)),
    list(term = "boundary_high", estimate = as.numeric(roots[2]), se = NULL, n_obs = as.integer(n)),
    list(term = "accepts_zero", estimate = as.numeric(accepts_zero), se = NULL, n_obs = as.integer(n)),
    list(term = "unbounded", estimate = as.numeric(unbounded), se = NULL, n_obs = as.integer(n)),
    list(term = "ar_f_at_one", estimate = as.numeric(ar_f_at_one), se = NULL, n_obs = as.integer(n))
  ),
  method_metadata = list(
    estimator = "Anderson-Rubin confidence set by inverting homoskedastic joint F test of excluded instruments z1, z2",
    vcov = "homoskedastic"
  ),
  diagnostics = list(
    critical_value = critical,
    quadratic_A = A,
    quadratic_B = B,
    quadratic_C = C,
    discriminant = disc
  )
)

write_json(result, "result.json", auto_unbox = TRUE, pretty = TRUE, digits = 16, na = "null")
