library(jsonlite)

dat <- read.csv("input.csv")
cohorts <- c(3, 5, 7)

res <- lapply(cohorts, function(c0) {
  win <- (c0 - 2):(c0 + 2)
  s <- dat[dat$time %in% win & (dat$g == c0 | dat$g == 0 | dat$g > c0 + 2), ]
  n_times <- tapply(s$time, s$id, function(t) length(unique(t)))
  keep_ids <- names(n_times)[n_times == length(win)]
  s <- s[as.character(s$id) %in% keep_ids, ]
  s$did <- as.numeric(s$g == c0 & s$time >= c0)
  fit <- lm(y ~ did + factor(id) + factor(time), data = s)
  list(
    att = unname(coef(fit)["did"]),
    n_obs = nrow(s),
    n_treated = length(unique(s$id[s$g == c0]))
  )
})

atts <- sapply(res, `[[`, "att")
ns <- sapply(res, `[[`, "n_obs")
ws <- sapply(res, `[[`, "n_treated")
att_weighted <- sum(ws * atts) / sum(ws)

out <- list(
  task_id = "broad_cohort_stack",
  platform = "r",
  estimates = list(
    list(term = "att_g3", estimate = atts[1], se = NULL, n_obs = as.integer(ns[1])),
    list(term = "att_g5", estimate = atts[2], se = NULL, n_obs = as.integer(ns[2])),
    list(term = "att_g7", estimate = atts[3], se = NULL, n_obs = as.integer(ns[3])),
    list(term = "att_weighted", estimate = att_weighted, se = NULL, n_obs = as.integer(sum(ns)))
  ),
  method_metadata = setNames(list(), character(0)),
  diagnostics = setNames(list(), character(0))
)

jsonlite::write_json(out, "result.json", auto_unbox = TRUE, null = "null", digits = 16)
