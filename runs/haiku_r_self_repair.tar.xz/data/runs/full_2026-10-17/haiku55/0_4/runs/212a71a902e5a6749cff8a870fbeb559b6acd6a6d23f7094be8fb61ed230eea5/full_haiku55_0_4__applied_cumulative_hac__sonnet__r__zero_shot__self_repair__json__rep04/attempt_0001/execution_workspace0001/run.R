df <- read.csv("input.csv", stringsAsFactors = FALSE)
df <- df[order(as.Date(df$date)), ]

y <- log(df$sales)
dv <- c(NA, diff(log(df$vix)))
n <- nrow(df)
L <- 15
idx <- (L + 2):n

X <- cbind(1, sapply(1:L, function(k) dv[idx - k]))
yy <- y[idx]
N <- length(yy)

XtXi <- solve(crossprod(X))
b <- as.vector(XtXi %*% crossprod(X, yy))
u <- as.vector(yy - X %*% b)

Xu <- X * u
S <- crossprod(Xu)
for (j in 1:L) {
  w <- 1 - j / (L + 1)
  G <- crossprod(Xu[(j + 1):N, , drop = FALSE], Xu[1:(N - j), , drop = FALSE])
  S <- S + w * (G + t(G))
}
V <- XtXi %*% S %*% XtXi * N / (N - (L + 1))

cvec <- rep(0, L + 1)
cvec[2:(L + 1)] <- 1
cum_est <- sum(b[2:(L + 1)])
cum_se <- sqrt(as.numeric(t(cvec) %*% V %*% cvec))

lag1_est <- b[2]
lag1_se <- sqrt(V[2, 2])
lag15_est <- b[16]
lag15_se <- sqrt(V[16, 16])

f <- function(x) format(x, digits = 15)

json <- paste0(
  "{\n",
  "  \"task_id\": \"applied_cumulative_hac\",\n",
  "  \"platform\": \"r\",\n",
  "  \"estimates\": [\n",
  "    {\"term\": \"cumulative_response\", \"estimate\": ", f(cum_est), ", \"se\": ", f(cum_se), ", \"n_obs\": ", N, "},\n",
  "    {\"term\": \"lag_1\", \"estimate\": ", f(lag1_est), ", \"se\": ", f(lag1_se), ", \"n_obs\": ", N, "},\n",
  "    {\"term\": \"lag_15\", \"estimate\": ", f(lag15_est), ", \"se\": ", f(lag15_se), ", \"n_obs\": ", N, "}\n",
  "  ],\n",
  "  \"method_metadata\": {\"estimator\": \"OLS regression of log(sales) on intercept and lags 1-15 of first difference of log(vix)\", \"vcov\": \"Newey-West HAC, max lag 15, Bartlett weights 1-j/16, scaled by N/(N-16)\"},\n",
  "  \"diagnostics\": {\"total_rows\": ", n, ", \"regression_rows\": ", N, "}\n",
  "}\n"
)

writeLines(json, "result.json")
