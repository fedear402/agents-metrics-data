library(jsonlite)

crosswalk <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
trade <- read.csv("trade.csv", stringsAsFactors = FALSE)
areas <- read.csv("areas.csv", stringsAsFactors = FALSE)
employment <- read.csv("employment.csv", stringsAsFactors = FALSE)
outcomes <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

iv <- function(y, C, x, z, w = rep(1, length(y))) {
  X <- cbind(C, x) * sqrt(w)
  Z <- cbind(C, z) * sqrt(w)
  fitted <- qr.fitted(qr(Z), X)
  as.numeric(qr.coef(qr(fitted), y * sqrt(w)))[ncol(X)]
}

trade <- merge(trade, crosswalk, by = "code")
industries <- sort(unique(trade$industry))
trade_pi <- unique(trade[, c("period", "industry", "us_change", "other_change", "price_index", "years")])

keys <- expand.grid(
  area = unique(areas$area),
  period = unique(areas$period),
  vintage = c("base", "early"),
  industry = industries,
  stringsAsFactors = FALSE
)
emp_agg <- aggregate(employment ~ area + period + vintage + industry, data = employment, FUN = sum)
emp_full <- merge(keys, emp_agg, by = c("area", "period", "vintage", "industry"), all.x = TRUE)
emp_full$employment[is.na(emp_full$employment)] <- 0

nat <- aggregate(employment ~ period + vintage + industry, data = emp_full, FUN = sum)
names(nat)[names(nat) == "employment"] <- "nat_employment"

tot <- areas[, c("area", "period", "vintage", "total_employment")]
m <- merge(emp_full, nat, by = c("period", "vintage", "industry"))
m <- merge(m, tot, by = c("area", "period", "vintage"))
m <- merge(m, trade_pi, by = c("period", "industry"))

share_term <- function(df, change) {
  df$employment / df$total_employment * df[[change]] / df$nat_employment /
    (df$price_index / 100) / 1000 * (10 / df$years)
}

b <- m[m$vintage == "base", ]
e <- m[m$vintage == "early", ]
b$term <- share_term(b, "us_change")
e$term <- share_term(e, "other_change")

x_df <- aggregate(term ~ area + period, data = b, FUN = sum)
names(x_df)[names(x_df) == "term"] <- "x"
z_df <- aggregate(term ~ area + period, data = e, FUN = sum)
names(z_df)[names(z_df) == "term"] <- "z"

pop <- areas[areas$vintage == "base", c("area", "period", "population")]

dat <- merge(outcomes, x_df, by = c("area", "period"))
dat <- merge(dat, z_df, by = c("area", "period"))
dat <- merge(dat, pop, by = c("area", "period"))
dat <- dat[order(dat$area, dat$period), ]

n <- nrow(dat)
C <- cbind(1, dat$period, dat$control)
beta <- iv(dat$change_pp, C, dat$x, dat$z, dat$population)

exp00 <- dat$x[dat$area == 0 & dat$period == 0]
exp01 <- dat$x[dat$area == 0 & dat$period == 1]
ins00 <- dat$z[dat$area == 0 & dat$period == 0]

estimates <- list(
  list(term = "iv_slope", estimate = as.numeric(beta), se = NA_real_, n_obs = as.integer(n)),
  list(term = "exposure_area0_period0", estimate = as.numeric(exp00), se = NA_real_, n_obs = as.integer(n)),
  list(term = "exposure_area0_period1", estimate = as.numeric(exp01), se = NA_real_, n_obs = as.integer(n)),
  list(term = "instrument_area0_period0", estimate = as.numeric(ins00), se = NA_real_, n_obs = as.integer(n))
)

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    method = "weighted 2SLS",
    outcome = "change_pp",
    endogenous = "x",
    instrument = "z",
    exogenous = c("intercept", "period", "control"),
    weight = "base-vintage population"
  ),
  diagnostics = list(
    n_area_periods = as.integer(n),
    n_industries = as.integer(length(industries))
  )
)

write_json(result, "result.json", auto_unbox = TRUE, digits = NA, na = "null", pretty = TRUE)
