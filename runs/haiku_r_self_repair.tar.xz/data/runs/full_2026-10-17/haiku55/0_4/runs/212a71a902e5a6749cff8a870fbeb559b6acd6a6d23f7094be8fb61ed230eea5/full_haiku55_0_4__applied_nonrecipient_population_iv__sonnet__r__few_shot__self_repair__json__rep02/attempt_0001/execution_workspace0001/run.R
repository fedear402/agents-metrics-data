library(jsonlite)

households <- read.csv("households.csv")
census <- read.csv("census.csv")

d <- subset(households, recipient == 0)
n_obs <- as.integer(nrow(d))

w <- d$weight
sw <- sqrt(w)
el <- d$eligible
dose <- d$dose
base <- d$baseline
instr <- d$instrument

X_exog <- cbind(1 - el, el, base * (1 - el), base * el)
X_endog <- cbind(dose * (1 - el), dose * el)
Z_excl <- cbind(instr * (1 - el), instr * el)

X <- cbind(X_exog, X_endog) * sw
Z <- cbind(X_exog, Z_excl) * sw
y <- d$outcome * sw

fitted_X <- qr.fitted(qr(Z), X)
beta <- qr.coef(qr(fitted_X), y)
slopes <- unname(beta[5:6])

wmean_dose <- function(g) {
  s <- d$eligible == g
  weighted.mean(d$dose[s], d$weight[s])
}

ineligible_effect <- slopes[1] * wmean_dose(0)
eligible_nonrecipient_effect <- slopes[2] * wmean_dose(1)

pop_w <- census$nonrecipient_population[match(0:1, census$eligible)]
population_effect <- weighted.mean(c(ineligible_effect, eligible_nonrecipient_effect), pop_w)

terms <- c("ineligible_effect", "eligible_nonrecipient_effect", "population_effect")
vals <- c(ineligible_effect, eligible_nonrecipient_effect, population_effect)

estimates <- lapply(seq_along(terms), function(i) {
  list(term = terms[i], estimate = unname(vals[i]), se = NA, n_obs = n_obs)
})

result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    method = "pooled weighted 2SLS with group-specific dose slopes",
    weight = "weight",
    intercept = "none beyond eligibility indicators",
    counterfactual = "dose set to zero for all retained households (synthetic convention)",
    aggregation = "census nonrecipient_population by eligibility group"
  ),
  diagnostics = list(
    n_rows = n_obs,
    n_eligible0 = as.integer(sum(el == 0)),
    n_eligible1 = as.integer(sum(el == 1)),
    dose_slope_ineligible = slopes[1],
    dose_slope_eligible = slopes[2],
    weighted_mean_dose_ineligible = wmean_dose(0),
    weighted_mean_dose_eligible = wmean_dose(1)
  )
)

jsonlite::write_json(result, "result.json", digits = 15, auto_unbox = TRUE, pretty = TRUE, na = "null")
