library(jsonlite)

d <- read.csv("input.csv", stringsAsFactors = FALSE)
d$date <- as.Date(d$date)
d <- d[order(d$date), ]

d$dlvix <- c(NA, diff(log(d$vix)))
d$log_sales <- log(d$sales)

L <- 15
n <- nrow(d)
lagmat <- sapply(1:L, function(k) c(rep(NA, k), head(d$dlvix, -k)))
colnames(lagmat) <- paste0("lag_", 1:L)
d2 <- cbind(d[, c("log_sales"), drop = FALSE], lagmat)
d2 <- d2[complete.cases(d2), ]

fml <- as.formula(paste("log_sales ~", paste(colnames(lagmat), collapse = " + ")))
fit <- lm(fml, data = d2)

X <- model.matrix(fit)
u <- residuals(fit)
N <- nrow(X)
p <- ncol(X)

scores <- X * u
meat <- crossprod(scores)
for (j in 1:L) {
  w <- 1 - j / (L + 1)
  Gj <- crossprod(scores[(j + 1):N, , drop = FALSE], scores[1:(N - j), , drop = FALSE])
  meat <- meat + w * (Gj + t(Gj))
}

bread <- solve(crossprod(X))
V <- N / (N - (L + 1)) * bread %*% meat %*% bread

b <- coef(fit)
contrast <- c(0, rep(1, L))
cum_est <- sum(contrast * b)
cum_se <- sqrt(drop(t(contrast) %*% V %*% contrast))

res <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(term = "cumulative_response", estimate = unname(cum_est), se = unname(cum_se), n_obs = as.integer(N)),
    list(term = "lag_1", estimate = unname(b[["lag_1"]]), se = unname(sqrt(V["lag_1", "lag_1"])), n_obs = as.integer(N)),
    list(term = "lag_15", estimate = unname(b[["lag_15"]]), se = unname(sqrt(V["lag_15", "lag_15"])), n_obs = as.integer(N))
  ),
  method_metadata = list(
    estimator = "OLS of log(sales) on intercept and 15 lags of first difference of log(vix)",
    vcov = "Newey-West HAC, max lag 15, Bartlett weights 1-j/16, scaled by N/(N-16)"
  ),
  diagnostics = setNames(list(), character(0))
)

write_json(res, "result.json", auto_unbox = TRUE, digits = 16, pretty = TRUE, null = "null")
