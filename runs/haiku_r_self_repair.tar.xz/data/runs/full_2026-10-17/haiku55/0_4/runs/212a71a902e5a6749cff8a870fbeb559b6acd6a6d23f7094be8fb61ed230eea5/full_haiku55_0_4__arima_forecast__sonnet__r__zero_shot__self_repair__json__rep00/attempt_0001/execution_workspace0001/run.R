d <- read.csv("./input.csv")
y <- as.numeric(d$y)
n_obs <- length(y)

fit <- arima(y, order = c(1, 1, 1), include.mean = FALSE, method = "ML")

h <- 251 - max(d$t)
if (h < 1) stop("t = 251 is not beyond the sample")
fc <- predict(fit, n.ahead = h)
f_est <- as.numeric(fc$pred[h])
f_se <- as.numeric(fc$se[h])
z <- qnorm(0.975)
lo <- f_est - z * f_se
hi <- f_est + z * f_se

fmt <- function(x) sprintf("%.12g", x)

json <- sprintf(
  paste0(
    '{\n',
    '  "task_id": "arima_forecast",\n',
    '  "platform": "r",\n',
    '  "estimates": [\n',
    '    {"term": "forecast", "estimate": %s, "se": %s, "n_obs": %d},\n',
    '    {"term": "lower_95", "estimate": %s, "se": null, "n_obs": %d},\n',
    '    {"term": "upper_95", "estimate": %s, "se": null, "n_obs": %d}\n',
    '  ],\n',
    '  "method_metadata": {"estimator": "ARIMA(1,1,1) maximum likelihood, no constant (stats::arima, method=ML)", "vcov": "Hessian-based (stats::arima)"},\n',
    '  "diagnostics": {"aic": %s, "sigma2": %s, "forecast_horizon": %d}\n',
    '}\n'
  ),
  fmt(f_est), fmt(f_se), n_obs,
  fmt(lo), n_obs,
  fmt(hi), n_obs,
  fmt(AIC(fit)), fmt(fit$sigma2), h
)

writeLines(json, "result.json")
