library(jsonlite)
dat <- read.csv("./input.csv", stringsAsFactors = FALSE)
dat$group <- as.factor(dat$group)
fit <- aov(y ~ group, data = dat)
tab <- summary(fit)[[1]]
F_stat <- unname(tab[["F value"]][1])
df_num <- unname(tab[["Df"]][1])
df_den <- unname(tab[["Df"]][2])
p_val <- unname(tab[["Pr(>F)"]][1])
n_obs <- nrow(dat)
out <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = list(
    list(term = "F", estimate = F_stat, se = NULL, n_obs = n_obs),
    list(term = "df_num", estimate = df_num, se = NULL, n_obs = n_obs),
    list(term = "df_den", estimate = df_den, se = NULL, n_obs = n_obs),
    list(term = "p_value", estimate = p_val, se = NULL, n_obs = n_obs)
  ),
  method_metadata = list(estimator = "One-way ANOVA (aov)", vcov = "none"),
  diagnostics = structure(list(), names = character(0))
)
write_json(out, "result.json", auto_unbox = TRUE, digits = NA, null = "null")
