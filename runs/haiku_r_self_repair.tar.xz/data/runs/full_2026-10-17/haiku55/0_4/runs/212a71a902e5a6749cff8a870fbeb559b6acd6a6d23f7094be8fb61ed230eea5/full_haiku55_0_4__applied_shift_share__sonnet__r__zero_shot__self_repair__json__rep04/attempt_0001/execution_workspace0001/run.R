suppressPackageStartupMessages(library(jsonlite))

df <- read.csv("input.csv", stringsAsFactors = FALSE)

regions <- df[!duplicated(df$region_id), c("region_id", "region_weight", "x", "y")]
regions$e <- regions$region_weight / sum(regions$region_weight)
z_by_region <- tapply(df$share * df$shock, df$region_id, sum)
regions$z <- as.numeric(z_by_region[as.character(regions$region_id)])

wmean <- function(v, w) sum(w * v) / sum(w)
e <- regions$e
regions$y0 <- regions$y - wmean(regions$y, e)
regions$x0 <- regions$x - wmean(regions$x, e)
regions$z0 <- regions$z - wmean(regions$z, e)

effect_reg <- sum(e * regions$z0 * regions$y0) / sum(e * regions$z0 * regions$x0)
first_reg <- sum(e * regions$z0 * regions$x0) / sum(e * regions$z0^2)

idx <- match(df$region_id, regions$region_id)
df$e <- regions$e[idx]
df$y0 <- regions$y0[idx]
df$x0 <- regions$x0[idx]
df$z0 <- regions$z0[idx]

ind <- as.character(sort(unique(df$industry_id)))
N <- length(ind)

s <- as.numeric(tapply(df$e * df$share, df$industry_id, sum)[ind])
shock_n <- as.numeric(tapply(df$shock, df$industry_id, function(v) v[1])[ind])

agg <- function(v) {
  as.numeric(tapply(df$e * df$share * v, df$industry_id, sum)[ind]) / s
}
ybar <- agg(df$y0)
xbar <- agg(df$x0)
zbar <- agg(df$z0)

iv_shock <- function(y, xend, inst, w) {
  n <- length(y)
  X <- cbind(1, xend)
  Z <- cbind(1, inst)
  A <- crossprod(Z, w * X)
  b <- solve(A, crossprod(Z, w * y))
  u <- as.numeric(y - X %*% b)
  M <- Z * (w * u)
  Ai <- solve(A)
  V <- Ai %*% crossprod(M) %*% t(Ai) * n / (n - 2)
  list(b = as.numeric(b), se = sqrt(V[2, 2]))
}

fit_effect <- iv_shock(ybar, xbar, shock_n, s)
fit_first <- iv_shock(xbar, zbar, shock_n, s)
effective_shocks <- 1 / sum(s^2)

out <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = effect_reg, se = fit_effect$se, n_obs = as.integer(N)),
    list(term = "first_stage", estimate = first_reg, se = fit_first$se, n_obs = as.integer(N)),
    list(term = "effective_shocks", estimate = effective_shocks, se = NULL, n_obs = as.integer(N))
  ),
  method_metadata = list(
    estimator = "Weighted 2SLS shift-share with BHJ shock-level aggregation (just-identified weighted IV)",
    vcov = "Shock-level HC1 robust variance (N/(N-2) multiplier), structural IV residuals, analytic weights, no clustering"
  ),
  diagnostics = structure(list(), names = character(0))
)

writeLines(toJSON(out, auto_unbox = TRUE, null = "null", digits = NA, pretty = TRUE), "result.json")
