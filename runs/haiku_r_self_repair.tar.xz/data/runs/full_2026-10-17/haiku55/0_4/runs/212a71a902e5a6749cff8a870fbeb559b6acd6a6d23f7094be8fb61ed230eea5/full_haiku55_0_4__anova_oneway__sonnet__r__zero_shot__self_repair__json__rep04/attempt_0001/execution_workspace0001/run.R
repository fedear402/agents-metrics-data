df <- read.csv("./input.csv", stringsAsFactors = FALSE)
df$group <- factor(df$group)
fit <- aov(y ~ group, data = df)
s <- summary(fit)[[1]]
F_stat <- s[["F value"]][1]
df_num <- s[["Df"]][1]
df_den <- s[["Df"]][2]
p_val <- s[["Pr(>F)"]][1]
n_obs <- nrow(df)
est <- function(term, value) {
  list(term = term, estimate = as.numeric(value), se = NULL, n_obs = as.integer(n_obs))
}
result <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = list(
    est("F", F_stat),
    est("df_num", df_num),
    est("df_den", df_den),
    est("p_value", p_val)
  ),
  method_metadata = list(
    estimator = "one-way ANOVA (stats::aov)",
    vcov = "not applicable"
  ),
  diagnostics = setNames(list(), character(0))
)
if (!requireNamespace("jsonlite", quietly = TRUE)) {
  install.packages("jsonlite", repos = "https://cloud.r-project.org")
}
jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = NA, null = "null", pretty = TRUE)
