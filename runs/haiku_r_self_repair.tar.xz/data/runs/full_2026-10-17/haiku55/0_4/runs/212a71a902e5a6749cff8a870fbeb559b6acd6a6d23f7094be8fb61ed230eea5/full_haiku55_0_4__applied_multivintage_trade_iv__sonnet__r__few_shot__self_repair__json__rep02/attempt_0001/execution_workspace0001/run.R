library(jsonlite)

crosswalk <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
trade <- read.csv("trade.csv", stringsAsFactors = FALSE)
areas <- read.csv("areas.csv", stringsAsFactors = FALSE)
employment <- read.csv("employment.csv", stringsAsFactors = FALSE)
outcomes <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

trade$industry <- crosswalk$industry[match(trade$code, crosswalk$code)]
inds <- sort(unique(crosswalk$industry))

iv <- function(y, C, x, z, w = rep(1, length(y))) {
  X <- cbind(C, x) * sqrt(w)
  Z <- cbind(C, z) * sqrt(w)
  fitted <- qr.fitted(qr(Z), X)
  as.numeric(qr.coef(qr(fitted), y * sqrt(w)))[ncol(X)]
}

emp_sum <- tapply(employment$employment,
                  paste(employment$area, employment$period, employment$vintage, employment$industry, sep = "|"),
                  sum)
get_emp <- function(a, p, v, j) {
  val <- emp_sum[paste(a, p, v, j, sep = "|")]
  val[is.na(val)] <- 0
  unname(val)
}

nat_sum <- tapply(employment$employment,
                  paste(employment$period, employment$vintage, employment$industry, sep = "|"),
                  sum)
get_nat <- function(p, v, j) unname(nat_sum[paste(p, v, j, sep = "|")])

tot <- setNames(areas$total_employment, paste(areas$area, areas$period, areas$vintage, sep = "|"))
pop_rows <- areas$vintage == "base"
pop <- setNames(areas$population[pop_rows], paste(areas$area[pop_rows], areas$period[pop_rows], sep = "|"))

trade_key <- paste(trade$period, trade$industry, sep = "|")
us_vec <- setNames(trade$us_change, trade_key)
oth_vec <- setNames(trade$other_change, trade_key)
price <- setNames(trade$price_index, as.character(trade$period))
years <- setNames(trade$years, as.character(trade$period))

exposure <- function(a, p, v, shock) {
  total <- tot[paste(a, p, v, sep = "|")]
  s <- 0
  for (j in inds) {
    e <- get_emp(a, p, v, j)
    sh <- shock[paste(p, j, sep = "|")]
    nat <- get_nat(p, v, j)
    pr <- price[paste(p)]
    yr <- years[paste(p)]
    s <- s + (e / total) * (sh / nat) / (pr / 100) / 1000 * (10 / yr)
  }
  unname(s)
}

x <- vapply(seq_len(nrow(outcomes)),
            function(i) exposure(outcomes$area[i], outcomes$period[i], "base", us_vec),
            numeric(1))
z <- vapply(seq_len(nrow(outcomes)),
            function(i) exposure(outcomes$area[i], outcomes$period[i], "early", oth_vec),
            numeric(1))

w <- unname(pop[paste(outcomes$area, outcomes$period, sep = "|")])
C <- cbind(1, outcomes$period, outcomes$control)
iv_slope <- iv(outcomes$change_pp, C, x, z, w)

n_obs <- as.integer(nrow(outcomes))
i0 <- which(outcomes$area == 0 & outcomes$period == 0)
i1 <- which(outcomes$area == 0 & outcomes$period == 1)

estimates <- list(
  list(term = "iv_slope", estimate = as.numeric(iv_slope), se = NA, n_obs = n_obs),
  list(term = "exposure_area0_period0", estimate = as.numeric(x[i0]), se = NA, n_obs = n_obs),
  list(term = "exposure_area0_period1", estimate = as.numeric(x[i1]), se = NA, n_obs = n_obs),
  list(term = "instrument_area0_period0", estimate = as.numeric(z[i0]), se = NA, n_obs = n_obs)
)

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    method = "weighted 2SLS",
    outcome = "change_pp",
    endogenous = "x",
    instrument = "z",
    exogenous = c("intercept", "period", "control"),
    weight = "base-vintage population"
  ),
  diagnostics = list(
    n_obs = n_obs,
    n_industries = as.integer(length(inds)),
    min_national_employment = as.numeric(min(nat_sum))
  )
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = NA, na = "null", pretty = TRUE)
