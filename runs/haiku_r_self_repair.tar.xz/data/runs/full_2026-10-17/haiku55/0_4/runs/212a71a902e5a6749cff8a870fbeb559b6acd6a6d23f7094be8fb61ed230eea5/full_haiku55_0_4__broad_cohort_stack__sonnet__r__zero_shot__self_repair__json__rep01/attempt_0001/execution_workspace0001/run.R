df <- read.csv("input.csv", stringsAsFactors = FALSE)

cohorts <- c(3, 5, 7)
att <- numeric(length(cohorts))
ntreat <- integer(length(cohorts))
nrows <- integer(length(cohorts))

for (k in seq_along(cohorts)) {
  c_val <- cohorts[k]
  win <- (c_val - 2):(c_val + 2)

  d <- df[which(df$time %in% win & (df$g == c_val | df$g == 0 | df$g > c_val + 2)), ]

  n_times <- tapply(d$time, as.character(d$id), function(t) length(unique(t)))
  keep_ids <- names(n_times)[n_times == length(win)]
  d <- d[as.character(d$id) %in% keep_ids, ]

  d$did <- as.integer(d$g == c_val & d$time >= c_val)
  ntreat[k] <- length(unique(d$id[d$g == c_val]))
  nrows[k] <- nrow(d)

  fit <- lm(y ~ did + factor(id) + factor(time), data = d)
  att[k] <- unname(coef(fit)["did"])
}

att_weighted <- sum(ntreat * att) / sum(ntreat)

fmt <- function(x) sprintf("%.15g", x)

estimates <- list(
  list(term = "att_g3", estimate = fmt(att[1]), se = NA, n_obs = nrows[1]),
  list(term = "att_g5", estimate = fmt(att[2]), se = NA, n_obs = nrows[2]),
  list(term = "att_g7", estimate = fmt(att[3]), se = NA, n_obs = nrows[3]),
  list(term = "att_weighted", estimate = fmt(att_weighted), se = NA, n_obs = sum(nrows))
)

result <- list(
  task_id = "broad_cohort_stack",
  platform = "r",
  estimates = estimates,
  method_metadata = structure(list(), names = character(0)),
  diagnostics = structure(list(), names = character(0))
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, pretty = TRUE, na = "null")
