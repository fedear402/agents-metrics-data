d <- read.csv("input.csv")
n <- nrow(d)
q <- 2L
df <- n - 4L
crit <- qf(0.95, q, df)
k <- q * crit / df

ssr <- function(fit) sum(residuals(fit)^2)

g <- function(b) {
  dd <- d
  dd$yb <- d$y - b * d$endog
  ssr_r <- ssr(lm(yb ~ x, data = dd))
  ssr_u <- ssr(lm(yb ~ x + z1 + z2, data = dd))
  ssr_r - (1 + k) * ssr_u
}

g0 <- g(0)
gp <- g(1)
gm <- g(-1)
c0 <- g0
a <- (gp + gm) / 2 - g0
bb <- (gp - gm) / 2
disc <- bb^2 - 4 * a * c0

if (abs(a) < 1e-12) {
  root <- -c0 / bb
  lo <- root
  hi <- root
  unbounded <- 1L
  set_desc <- if (bb > 0) "ray: beta <= root" else "ray: beta >= root"
} else if (disc < 0) {
  lo <- NA_real_
  hi <- NA_real_
  unbounded <- as.integer(a < 0)
  set_desc <- if (a > 0) "empty" else "whole real line"
} else {
  r <- sort((-bb + c(-1, 1) * sqrt(disc)) / (2 * a))
  lo <- r[1]
  hi <- r[2]
  unbounded <- as.integer(a < 0)
  set_desc <- if (a > 0) "interval [lo, hi]" else "outer rays: beta <= lo or beta >= hi"
}

accepts_zero <- as.integer(c0 <= 0)

dd1 <- d
dd1$yb <- d$y - 1 * d$endog
fr1 <- lm(yb ~ x, data = dd1)
fu1 <- lm(yb ~ x + z1 + z2, data = dd1)
ar_f_at_one <- ((ssr(fr1) - ssr(fu1)) / q) / (ssr(fu1) / df)

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = list(
    list(term = "boundary_low", estimate = unname(lo), se = NA_real_, n_obs = n),
    list(term = "boundary_high", estimate = unname(hi), se = NA_real_, n_obs = n),
    list(term = "accepts_zero", estimate = accepts_zero, se = NA_real_, n_obs = n),
    list(term = "unbounded", estimate = unbounded, se = NA_real_, n_obs = n),
    list(term = "ar_f_at_one", estimate = unname(ar_f_at_one), se = NA_real_, n_obs = n)
  ),
  method_metadata = list(
    estimator = "Anderson-Rubin inversion of homoskedastic joint F test on excluded instruments z1, z2 with intercept and x",
    vcov = "homoskedastic"
  ),
  diagnostics = list(
    critical_value = crit,
    df_denominator = df,
    quadratic_a = a,
    quadratic_b = bb,
    quadratic_c = c0,
    discriminant = disc,
    set_description = set_desc
  )
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, null = "null", na = "null", digits = 16, pretty = TRUE)
