library(jsonlite)
df <- read.csv("./input.csv")
df <- df[order(df$t), ]
y <- df$y
n <- length(y)
fit <- arima(y, order = c(1, 1, 1), include.mean = FALSE, method = "ML")
p <- predict(fit, n.ahead = 1)
fc <- as.numeric(p$pred)
se <- as.numeric(p$se)
out <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = list(
    list(term = "forecast", estimate = fc, se = se, n_obs = n),
    list(term = "lower_95", estimate = fc - 1.96 * se, se = NA_real_, n_obs = n),
    list(term = "upper_95", estimate = fc + 1.96 * se, se = NA_real_, n_obs = n)
  ),
  method_metadata = list(
    estimator = "ARIMA(1,1,1) by maximum likelihood, no constant",
    vcov = "ML observed information"
  ),
  diagnostics = structure(list(), names = character(0))
)
write_json(out, "result.json", auto_unbox = TRUE, digits = NA, na = "null")
