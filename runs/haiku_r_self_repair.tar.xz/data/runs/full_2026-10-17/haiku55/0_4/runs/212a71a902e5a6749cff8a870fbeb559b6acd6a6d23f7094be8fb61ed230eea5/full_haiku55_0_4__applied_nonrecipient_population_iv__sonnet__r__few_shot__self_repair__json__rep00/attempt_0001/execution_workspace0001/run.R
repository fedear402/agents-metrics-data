households <- read.csv("households.csv")
census <- read.csv("census.csv")

d <- subset(households, recipient == 0)
e <- d$eligible
ne <- 1 - e
w <- d$weight
y <- d$outcome

C <- cbind(ne, e, d$baseline * ne, d$baseline * e)
x <- cbind(d$dose * ne, d$dose * e)
z_excl <- cbind(d$instrument * ne, d$instrument * e)
Z <- cbind(C, z_excl)

Xw <- cbind(C, x) * sqrt(w)
Zw <- cbind(Z) * sqrt(w)
yw <- y * sqrt(w)

fitted <- qr.fitted(qr(Zw), Xw)
beta <- as.numeric(qr.coef(qr(fitted), yw))
k <- ncol(Xw)
slopes <- beta[(k - 1):k]

m0 <- weighted.mean(d$dose[ne == 1], w[ne == 1])
m1 <- weighted.mean(d$dose[e == 1], w[e == 1])

ineligible_effect <- slopes[1] * m0
eligible_nonrecipient_effect <- slopes[2] * m1

pop_w <- census$nonrecipient_population[match(0:1, census$eligible)]
population_effect <- weighted.mean(c(ineligible_effect, eligible_nonrecipient_effect), pop_w)

n_obs <- as.integer(nrow(d))

make_estimate <- function(term, value) {
  list(term = term, estimate = value, se = NULL, n_obs = n_obs)
}

result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = list(
    make_estimate("ineligible_effect", ineligible_effect),
    make_estimate("eligible_nonrecipient_effect", eligible_nonrecipient_effect),
    make_estimate("population_effect", population_effect)
  ),
  method_metadata = list(
    estimator = "weighted 2SLS",
    endogenous = c("dose*(1-eligible)", "dose*eligible"),
    exogenous = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"),
    instruments = c("exogenous columns", "instrument*(1-eligible)", "instrument*eligible"),
    intercept = FALSE,
    sample = "recipient == 0",
    regression_weight = "weight",
    counterfactual = "dose set to zero for every retained household",
    aggregation_weights = "census nonrecipient_population",
    attribution_note = "zero-dose counterfactual attribution is a stated synthetic convention"
  ),
  diagnostics = list(
    n_total = n_obs,
    n_ineligible = as.integer(sum(ne == 1)),
    n_eligible = as.integer(sum(e == 1)),
    dose_slope_ineligible = slopes[1],
    dose_slope_eligible = slopes[2],
    weighted_mean_dose_ineligible = m0,
    weighted_mean_dose_eligible = m1,
    census_weight_ineligible = pop_w[1],
    census_weight_eligible = pop_w[2]
  )
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = NA, null = "null", pretty = TRUE)
