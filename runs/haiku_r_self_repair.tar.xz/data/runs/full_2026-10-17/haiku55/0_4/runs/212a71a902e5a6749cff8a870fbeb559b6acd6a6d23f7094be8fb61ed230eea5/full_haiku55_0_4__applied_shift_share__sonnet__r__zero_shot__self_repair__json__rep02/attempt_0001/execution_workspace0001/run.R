df <- read.csv("input.csv", stringsAsFactors = FALSE)

reg <- df[!duplicated(df$region_id), c("region_id", "region_weight", "x", "y")]
reg$e <- reg$region_weight / sum(reg$region_weight)
zsum <- tapply(df$share * df$shock, df$region_id, sum)
reg$z <- as.numeric(zsum[as.character(reg$region_id)])

wmean <- function(v, w) sum(w * v) / sum(w)
reg$y0 <- reg$y - wmean(reg$y, reg$e)
reg$x0 <- reg$x - wmean(reg$x, reg$e)
reg$z0 <- reg$z - wmean(reg$z, reg$e)

effect_hat <- sum(reg$e * reg$z0 * reg$y0) / sum(reg$e * reg$z0 * reg$x0)
fs_hat <- sum(reg$e * reg$z0 * reg$x0) / sum(reg$e * reg$z0^2)

ids <- as.character(sort(unique(df$industry_id)))
dfm <- merge(df[, c("region_id", "industry_id", "share")],
             reg[, c("region_id", "e", "y0", "x0", "z0")], by = "region_id")
dfm$w <- dfm$e * dfm$share
s_n <- as.numeric(tapply(dfm$w, dfm$industry_id, sum)[ids])
agg <- function(v) as.numeric(tapply(dfm$w * v, dfm$industry_id, sum)[ids]) / s_n
ybar <- agg(dfm$y0)
xbar <- agg(dfm$x0)
zbar <- agg(dfm$z0)
shock_n <- as.numeric(df$shock[match(ids, as.character(df$industry_id))])
N <- length(ids)

siv <- function(yv, xv, zv, w) {
  n <- length(yv)
  X <- cbind(1, xv)
  Z <- cbind(1, zv)
  A <- crossprod(Z * w, X)
  b <- solve(A, crossprod(Z * w, yv))
  u <- as.numeric(yv - X %*% b)
  Ai <- solve(A)
  meat <- crossprod(Z * (w * u))
  V <- Ai %*% meat %*% t(Ai) * n / (n - 2)
  list(b = as.numeric(b), se = sqrt(V[2, 2]))
}

eff_fit <- siv(ybar, xbar, shock_n, s_n)
se_eff <- eff_fit$se
se_fs <- siv(xbar, zbar, shock_n, s_n)$se
eff <- 1 / sum(s_n^2)

fmt <- function(x) sprintf("%.15g", x)

json <- paste0(
  '{\n',
  '  "task_id": "applied_shift_share",\n',
  '  "platform": "r",\n',
  '  "estimates": [\n',
  sprintf('    {"term": "effect", "estimate": %s, "se": %s, "n_obs": %d},\n',
          fmt(effect_hat), fmt(se_eff), N),
  sprintf('    {"term": "first_stage", "estimate": %s, "se": %s, "n_obs": %d},\n',
          fmt(fs_hat), fmt(se_fs), N),
  sprintf('    {"term": "effective_shocks", "estimate": %s, "se": null, "n_obs": %d}\n',
          fmt(eff), N),
  '  ],\n',
  '  "method_metadata": {"estimator": "weighted 2SLS shift-share with shock-level BHJ IV, analytic weights", "vcov": "shock-level HC1 robust with N/(N-2), structural IV residuals, no clustering"},\n',
  sprintf('  "diagnostics": {"n_regions": %d, "n_industries": %d, "shock_level_effect_slope": %s}\n',
          nrow(reg), N, fmt(eff_fit$b[2])),
  '}\n'
)

writeLines(json, "result.json")
