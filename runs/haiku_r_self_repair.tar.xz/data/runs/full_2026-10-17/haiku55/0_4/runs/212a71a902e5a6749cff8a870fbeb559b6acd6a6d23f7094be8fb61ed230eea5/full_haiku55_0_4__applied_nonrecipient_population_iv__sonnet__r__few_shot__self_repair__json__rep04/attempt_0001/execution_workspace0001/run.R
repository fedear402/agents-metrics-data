hh <- read.csv("households.csv")
census <- read.csv("census.csv")

d <- hh[hh$recipient == 0, ]
e <- d$eligible
ne <- 1 - e
w <- d$weight
n <- nrow(d)

X <- cbind(ne, e, d$baseline * ne, d$baseline * e, d$dose * ne, d$dose * e)
Z <- cbind(ne, e, d$baseline * ne, d$baseline * e, d$instrument * ne, d$instrument * e)

sw <- sqrt(w)
Xhat <- qr.fitted(qr(Z * sw), X * sw)
beta <- qr.coef(qr(Xhat), d$outcome * sw)

slope <- c(beta[5], beta[6])
mean_dose <- c(
  weighted.mean(d$dose[e == 0], w[e == 0]),
  weighted.mean(d$dose[e == 1], w[e == 1])
)
effect <- slope * mean_dose

pop <- census$nonrecipient_population[match(0:1, census$eligible)]
population_effect <- sum(effect * pop) / sum(pop)

estimates <- list(
  list(term = "ineligible_effect", estimate = effect[1], se = NA_real_, n_obs = as.integer(n)),
  list(term = "eligible_nonrecipient_effect", estimate = effect[2], se = NA_real_, n_obs = as.integer(n)),
  list(term = "population_effect", estimate = population_effect, se = NA_real_, n_obs = as.integer(n))
)

result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    method = "weighted 2SLS with group-interacted dose endogenous regressors",
    endogenous = c("dose*(1-eligible)", "dose*eligible"),
    exogenous = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"),
    instruments = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible",
                    "instrument*(1-eligible)", "instrument*eligible"),
    weight = "weight",
    counterfactual = "dose set to zero for every retained household",
    group_effect = "dose slope times household-weighted mean dose within group",
    aggregation = "nonrecipient_population from census.csv"
  ),
  diagnostics = list(
    n_obs = as.integer(n),
    n_ineligible = as.integer(sum(e == 0)),
    n_eligible = as.integer(sum(e == 1)),
    n_endogenous = 2L,
    n_instruments = 6L,
    dose_slopes = list(ineligible = slope[1], eligible = slope[2]),
    weighted_mean_dose = list(ineligible = mean_dose[1], eligible = mean_dose[2]),
    census_weights = list(ineligible = pop[1], eligible = pop[2])
  )
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = 15, na = "null", pretty = TRUE)
