library(jsonlite)

d <- read.csv("input.csv", stringsAsFactors = FALSE)

first <- d[!duplicated(d$region_id), c("region_id", "region_weight", "x", "y")]
nr <- nrow(first)
e <- first$region_weight / sum(first$region_weight)

ind <- sort(unique(d$industry_id))
ni <- length(ind)
idx_r <- match(d$region_id, first$region_id)
idx_n <- match(d$industry_id, ind)

S <- matrix(0, nr, ni)
S[cbind(idx_r, idx_n)] <- d$share

sh <- d$shock[match(ind, d$industry_id)]
z_reg <- drop(S %*% sh)

wm <- function(v) sum(e * v)
y0 <- first$y - wm(first$y)
x0 <- first$x - wm(first$x)
z0 <- z_reg - wm(z_reg)

s <- colSums(e * S)

vbar <- function(v0) drop(crossprod(S, e * v0)) / s
ybar <- vbar(y0)
xbar <- vbar(x0)
zbar <- vbar(z0)

shock_iv <- function(dep, endog) {
  X <- cbind(1, endog)
  Z <- cbind(1, sh)
  w <- s
  cross <- crossprod(Z, w * X)
  beta <- solve(cross, crossprod(Z, w * dep))
  res <- drop(dep - X %*% beta)
  scores <- Z * (w * res)
  inv <- solve(cross)
  N <- length(dep)
  V <- N / (N - 2) * inv %*% crossprod(scores) %*% t(inv)
  c(slope = beta[2], se = sqrt(V[2, 2]))
}

effect <- shock_iv(ybar, xbar)
first_stage <- shock_iv(xbar, zbar)
effective_shocks <- 1 / sum(s^2)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = unname(as.numeric(effect["slope"])),
         se = unname(as.numeric(effect["se"])), n_obs = as.integer(ni)),
    list(term = "first_stage", estimate = unname(as.numeric(first_stage["slope"])),
         se = unname(as.numeric(first_stage["se"])), n_obs = as.integer(ni)),
    list(term = "effective_shocks", estimate = unname(as.numeric(effective_shocks)),
         se = NULL, n_obs = as.integer(ni))
  ),
  method_metadata = list(
    estimator = "regional weighted 2SLS via Borusyak-Hull-Jaravel shock-level weighted IV",
    vcov = "shock-level HC1 robust, N/(N-2) multiplier, structural residuals, analytic weights"
  ),
  diagnostics = setNames(list(), character(0))
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
