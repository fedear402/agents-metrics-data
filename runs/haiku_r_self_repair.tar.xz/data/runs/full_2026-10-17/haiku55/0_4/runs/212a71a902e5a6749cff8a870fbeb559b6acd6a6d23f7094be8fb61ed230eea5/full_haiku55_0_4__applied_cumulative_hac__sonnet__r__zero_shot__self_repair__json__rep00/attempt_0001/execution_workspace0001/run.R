library(jsonlite)

df <- read.csv("input.csv", stringsAsFactors = FALSE)
df$date <- as.Date(df$date)
df <- df[order(df$date), ]

L <- 15
df$dlvix <- c(NA, diff(log(df$vix)))
cols <- paste0("lag_", 1:L)
for (k in 1:L) df[[cols[k]]] <- c(rep(NA, k), head(df$dlvix, -k))
df$ly <- log(df$sales)

d <- df[complete.cases(df[, c("ly", cols)]), ]
X <- cbind(1, as.matrix(d[, cols]))
y <- d$ly
N <- nrow(X)
k <- ncol(X)

XtXi <- solve(crossprod(X))
b <- as.vector(XtXi %*% crossprod(X, y))
u <- as.vector(y - X %*% b)
Xu <- X * u

S <- crossprod(Xu)
for (j in 1:L) {
  w <- 1 - j / (L + 1)
  G <- crossprod(Xu[(j + 1):N, , drop = FALSE], Xu[1:(N - j), , drop = FALSE])
  S <- S + w * (G + t(G))
}
V <- XtXi %*% S %*% XtXi * N / (N - k)

cvec <- c(0, rep(1, L))
cum_est <- sum(b[-1])
cum_se <- sqrt(as.numeric(t(cvec) %*% V %*% cvec))

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(term = "cumulative_response", estimate = cum_est, se = cum_se, n_obs = as.integer(N)),
    list(term = "lag_1", estimate = b[2], se = sqrt(V[2, 2]), n_obs = as.integer(N)),
    list(term = "lag_15", estimate = b[16], se = sqrt(V[16, 16]), n_obs = as.integer(N))
  ),
  method_metadata = list(
    estimator = "OLS: log(sales) on intercept and 15 lags of first difference of log(vix)",
    vcov = "Newey-West HAC, Bartlett weights 1-j/16, maxlag 15, scaled by N/(N-16)"
  ),
  diagnostics = list(
    n_rows_input = nrow(df),
    n_rows_used = as.integer(N),
    nw_max_lag = L
  )
)

write_json(result, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE)
