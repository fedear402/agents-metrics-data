library(jsonlite)

d <- read.csv("input.csv", stringsAsFactors = FALSE)
d$id <- as.integer(d$id)
d$time <- as.integer(d$time)
d$g <- as.numeric(d$g)
d$y <- as.numeric(d$y)

cohorts <- c(3, 5, 7)

res <- lapply(cohorts, function(cc) {
  wt <- (cc - 2):(cc + 2)
  s <- d[d$time %in% wt & (d$g == cc | d$g == 0 | d$g > cc + 2), ]
  complete <- tapply(s$time, s$id, function(t) all(wt %in% t))
  keep_ids <- names(complete)[complete]
  s <- s[as.character(s$id) %in% keep_ids, ]
  s$did <- as.integer(s$g == cc & s$time >= cc)
  fit <- lm(y ~ did + factor(id) + factor(time), data = s)
  list(
    att = unname(coef(fit)["did"]),
    n = nrow(s),
    w = length(unique(s$id[s$g == cc]))
  )
})

atts <- vapply(res, function(r) r$att, numeric(1))
ns <- vapply(res, function(r) r$n, numeric(1))
ws <- vapply(res, function(r) r$w, numeric(1))
att_weighted <- sum(ws * atts) / sum(ws)

fmt <- function(x) sprintf("%.15g", x)

out <- list(
  task_id = "broad_cohort_stack",
  platform = "r",
  estimates = list(
    list(term = "att_g3", estimate = fmt(atts[1]), se = NA, n_obs = as.integer(ns[1])),
    list(term = "att_g5", estimate = fmt(atts[2]), se = NA, n_obs = as.integer(ns[2])),
    list(term = "att_g7", estimate = fmt(atts[3]), se = NA, n_obs = as.integer(ns[3])),
    list(term = "att_weighted", estimate = fmt(att_weighted), se = NA, n_obs = as.integer(sum(ns)))
  ),
  method_metadata = structure(list(), names = character(0)),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "result.json", auto_unbox = TRUE, na = "null", pretty = TRUE)
