library(jsonlite)

df <- read.csv("input.csv", stringsAsFactors = FALSE)

cohorts <- c(3, 5, 7)

comp <- lapply(cohorts, function(cc) {
  lo <- cc - 2
  hi <- cc + 2
  d <- df[df$time >= lo & df$time <= hi &
            (df$g == cc | df$g == 0 | df$g > cc + 2), , drop = FALSE]
  ntimes <- tapply(d$time, d$id, function(t) length(unique(t)))
  keep_ids <- names(ntimes)[ntimes == (hi - lo + 1)]
  d <- d[as.character(d$id) %in% keep_ids, , drop = FALSE]
  d$did <- as.integer(d$g == cc & d$time >= cc)
  fit <- lm(y ~ did + factor(id) + factor(time), data = d)
  list(
    att = unname(coef(fit)["did"]),
    n = nrow(d),
    nt = length(unique(d$id[d$g == cc]))
  )
})

atts <- sapply(comp, `[[`, "att")
ns <- sapply(comp, `[[`, "n")
nts <- sapply(comp, `[[`, "nt")
att_weighted <- sum(nts * atts) / sum(nts)

fmt <- function(x) sprintf("%.15g", x)

result <- list(
  task_id = "broad_cohort_stack",
  platform = "r",
  estimates = list(
    list(term = "att_g3", estimate = fmt(atts[1]), se = NA_real_, n_obs = ns[1]),
    list(term = "att_g5", estimate = fmt(atts[2]), se = NA_real_, n_obs = ns[2]),
    list(term = "att_g7", estimate = fmt(atts[3]), se = NA_real_, n_obs = ns[3]),
    list(term = "att_weighted", estimate = fmt(att_weighted), se = NA_real_,
         n_obs = sum(ns))
  ),
  method_metadata = setNames(list(), character(0)),
  diagnostics = setNames(list(), character(0))
)

write_json(result, "result.json", auto_unbox = TRUE, pretty = TRUE, na = "null")
