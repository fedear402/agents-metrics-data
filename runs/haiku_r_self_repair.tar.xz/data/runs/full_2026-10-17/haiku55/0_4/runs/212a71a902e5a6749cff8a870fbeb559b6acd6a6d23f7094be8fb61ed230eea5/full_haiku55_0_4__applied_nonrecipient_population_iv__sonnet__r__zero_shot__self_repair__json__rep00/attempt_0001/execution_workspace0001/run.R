library(jsonlite)

hh <- read.csv("households.csv", stringsAsFactors = FALSE)
cen <- read.csv("census.csv", stringsAsFactors = FALSE)

d <- hh[hh$recipient == 0, , drop = FALSE]
n <- nrow(d)

e <- as.numeric(d$eligible)
ne <- 1 - e
w <- as.numeric(d$weight)
dose <- as.numeric(d$dose)
base <- as.numeric(d$baseline)
inst <- as.numeric(d$instrument)
y <- as.numeric(d$outcome)

X <- cbind(dose * ne, dose * e, ne, e, base * ne, base * e)
Z <- cbind(ne, e, base * ne, base * e, inst * ne, inst * e)

ZtWZ <- crossprod(Z, Z * w)
ZtWX <- crossprod(Z, X * w)
ZtWy <- crossprod(Z, y * w)

A <- t(ZtWX) %*% solve(ZtWZ, ZtWX)
rhs <- t(ZtWX) %*% solve(ZtWZ, ZtWy)
beta <- as.numeric(solve(A, rhs))

slope_ne <- beta[1]
slope_e <- beta[2]

m_ne <- sum(w[ne == 1] * dose[ne == 1]) / sum(w[ne == 1])
m_e <- sum(w[e == 1] * dose[e == 1]) / sum(w[e == 1])

ineligible_effect <- slope_ne * m_ne
eligible_nonrecipient_effect <- slope_e * m_e

N0 <- sum(as.numeric(cen$nonrecipient_population[cen$eligible == 0]))
N1 <- sum(as.numeric(cen$nonrecipient_population[cen$eligible == 1]))
population_effect <- (N0 * ineligible_effect + N1 * eligible_nonrecipient_effect) / (N0 + N1)

n_obs <- as.integer(n)

result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = list(
    list(term = "ineligible_effect", estimate = ineligible_effect, se = NA_real_, n_obs = n_obs),
    list(term = "eligible_nonrecipient_effect", estimate = eligible_nonrecipient_effect, se = NA_real_, n_obs = n_obs),
    list(term = "population_effect", estimate = population_effect, se = NA_real_, n_obs = n_obs)
  ),
  method_metadata = list(
    method = "weighted 2SLS",
    weight_column = "weight",
    intercept = FALSE,
    endogenous = c("dose*(1-eligible)", "dose*eligible"),
    exogenous = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"),
    instruments = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible",
                    "instrument*(1-eligible)", "instrument*eligible"),
    sample = "recipient == 0, both village treatment statuses retained",
    group_effect = "fitted dose slope times weighted mean dose within eligibility group",
    population_weights = "census nonrecipient_population by eligibility group",
    counterfactual = "dose set to zero for every retained household (synthetic attribution convention)",
    se = "not computed; null by specification"
  ),
  diagnostics = list(
    n_obs = n_obs,
    n_ineligible = as.integer(sum(ne == 1)),
    n_eligible = as.integer(sum(e == 1)),
    rank_ZtWX = as.integer(qr(ZtWX)$rank),
    slope_ineligible = slope_ne,
    slope_eligible = slope_e,
    weighted_mean_dose_ineligible = m_ne,
    weighted_mean_dose_eligible = m_e,
    census_population_ineligible = N0,
    census_population_eligible = N1
  )
)

write_json(result, "result.json", auto_unbox = TRUE, digits = NA, na = "null", pretty = TRUE)
