library(jsonlite)

df <- read.csv("input.csv")
df <- df[complete.cases(df[, c("id", "score", "participated", "earnings")]), ]
d <- df[abs(df$score) < 1, ]

s <- d$score
w <- 1 - abs(s)
R <- as.numeric(s >= 0)
X <- cbind(1, R, s, R * s)
Y <- d$earnings
D <- d$participated

XtWX <- t(X) %*% (X * w)
bread <- solve(XtWX)

bY <- bread %*% t(X) %*% (w * Y)
bD <- bread %*% t(X) %*% (w * D)
eY <- as.vector(Y - X %*% bY)
eD <- as.vector(D - X %*% bD)

meat_YY <- t(X) %*% (X * (w^2 * eY * eY))
meat_DD <- t(X) %*% (X * (w^2 * eD * eD))
meat_YD <- t(X) %*% (X * (w^2 * eY * eD))

V_YY <- bread %*% meat_YY %*% bread
V_DD <- bread %*% meat_DD %*% bread
V_YD <- bread %*% meat_YD %*% bread

rf <- as.numeric(bY[2])
fs <- as.numeric(bD[2])
tau <- rf / fs

Sigma <- matrix(c(V_YY[2, 2], V_YD[2, 2],
                  V_YD[2, 2], V_DD[2, 2]), nrow = 2)
g <- c(1 / fs, -rf / fs^2)
se_tau <- sqrt(as.numeric(t(g) %*% Sigma %*% g))

n_obs <- nrow(d)

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = tau, se = se_tau, n_obs = n_obs),
    list(term = "reduced_form", estimate = rf, se = sqrt(V_YY[2, 2]), n_obs = n_obs),
    list(term = "first_stage", estimate = fs, se = sqrt(V_DD[2, 2]), n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "Fuzzy RD, cutoff 0, bandwidth 1, triangular weights, local linear with separate slopes and intercepts",
    vcov = "HC0 heteroskedasticity-robust; delta method for treatment_effect using joint covariance"
  ),
  diagnostics = setNames(list(), character(0))
)

write_json(result, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE)
