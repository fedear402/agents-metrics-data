d <- read.csv("input.csv")
d$y <- factor(d$y, levels = 0:2)
fit <- nnet::multinom(y ~ x + z, data = d, Hess = TRUE, trace = FALSE,
                      maxit = 1000, reltol = 1e-12, abstol = 1e-12)
B <- coef(fit)
V <- vcov(fit)
n <- nrow(d)
est <- function(row, term) unname(B[row, term])
se <- function(row, term) {
  nm <- paste0(row, ":", term)
  sqrt(V[nm, nm])
}
b0 <- unname(B[, "(Intercept)"])
p2_zero <- exp(b0[["2"]]) / (1 + exp(b0[["1"]]) + exp(b0[["2"]]))
res <- list(
  task_id = "broad_multinomial_logit",
  platform = "r",
  estimates = list(
    list(term = "x_cat1", estimate = est("1", "x"), se = se("1", "x"), n_obs = n),
    list(term = "z_cat1", estimate = est("1", "z"), se = se("1", "z"), n_obs = n),
    list(term = "x_cat2", estimate = est("2", "x"), se = se("2", "x"), n_obs = n),
    list(term = "z_cat2", estimate = est("2", "z"), se = se("2", "z"), n_obs = n),
    list(term = "prob_cat2_zero", estimate = unname(p2_zero), se = NULL, n_obs = n)
  ),
  method_metadata = list(
    estimator = "multinomial logit maximum likelihood (nnet::multinom), base outcome 0",
    vcov = "conventional observed-information (inverse Hessian)"
  ),
  diagnostics = list(
    converged = fit$convergence == 0,
    base_category = "0",
    n_obs = n
  )
)
jsonlite::write_json(res, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
