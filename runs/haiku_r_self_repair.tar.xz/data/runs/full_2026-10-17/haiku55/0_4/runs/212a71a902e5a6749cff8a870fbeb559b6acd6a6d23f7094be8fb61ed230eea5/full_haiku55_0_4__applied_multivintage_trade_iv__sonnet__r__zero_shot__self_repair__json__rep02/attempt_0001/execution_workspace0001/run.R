library(jsonlite)

cw <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
tr <- read.csv("trade.csv", stringsAsFactors = FALSE)
ar <- read.csv("areas.csv", stringsAsFactors = FALSE)
em <- read.csv("employment.csv", stringsAsFactors = FALSE)
oc <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

cw$code <- trimws(as.character(cw$code))
cw$industry <- trimws(as.character(cw$industry))
tr$code <- trimws(as.character(tr$code))
tr$period <- as.numeric(tr$period)
tr <- merge(tr, unique(cw[, c("code", "industry")]), by = "code")

ar$area <- as.character(ar$area)
ar$period <- as.numeric(ar$period)
ar$vintage <- trimws(ar$vintage)

em$area <- as.character(em$area)
em$period <- as.numeric(em$period)
em$vintage <- trimws(em$vintage)
em$industry <- trimws(as.character(em$industry))

oc$area <- as.character(oc$area)
oc$period <- as.numeric(oc$period)

inds <- sort(unique(tr$industry))

tt <- unique(tr[, c("period", "industry", "us_change", "other_change", "price_index", "years")])

keys <- unique(ar[, c("area", "period", "vintage")])
grid <- merge(keys, data.frame(industry = inds, stringsAsFactors = FALSE), by = NULL)
emA <- aggregate(employment ~ area + period + vintage + industry, data = em, FUN = sum)
e <- merge(grid, emA, by = c("area", "period", "vintage", "industry"), all.x = TRUE)
e$employment[is.na(e$employment)] <- 0

nat <- aggregate(employment ~ period + vintage + industry, data = e, FUN = sum)

eb <- e[e$vintage == "base", c("area", "period", "industry", "employment")]
names(eb)[4] <- "E_base"
ee <- e[e$vintage == "early", c("area", "period", "industry", "employment")]
names(ee)[4] <- "E_early"

tb <- ar[ar$vintage == "base", c("area", "period", "total_employment", "population")]
names(tb)[3] <- "TE_base"
te <- ar[ar$vintage == "early", c("area", "period", "total_employment")]
names(te)[3] <- "TE_early"

nb <- nat[nat$vintage == "base", c("period", "industry", "employment")]
names(nb)[3] <- "N_base"
ne <- nat[nat$vintage == "early", c("period", "industry", "employment")]
names(ne)[3] <- "N_early"

d <- merge(eb, ee, by = c("area", "period", "industry"))
d <- merge(d, tb, by = c("area", "period"))
d <- merge(d, te, by = c("area", "period"))
d <- merge(d, nb, by = c("period", "industry"))
d <- merge(d, ne, by = c("period", "industry"))
d <- merge(d, tt, by = c("period", "industry"))

d$x_term <- with(d, (E_base / TE_base) * (us_change / N_base) / (price_index / 100) / 1000 * (10 / years))
d$z_term <- with(d, (E_early / TE_early) * (other_change / N_early) / (price_index / 100) / 1000 * (10 / years))

ap <- aggregate(cbind(x_term, z_term) ~ area + period, data = d, FUN = sum)
names(ap)[3:4] <- c("x", "z")

ap <- merge(ap, tb[, c("area", "period", "population")], by = c("area", "period"))
est <- merge(oc[, c("area", "period", "control", "change_pp")], ap, by = c("area", "period"))

n_obs <- as.integer(nrow(est))

y <- est$change_pp
X <- cbind(1, est$period, est$control, est$x)
Z <- cbind(1, est$period, est$control, est$z)
sw <- sqrt(est$population)
Xw <- X * sw
Zw <- Z * sw
yw <- y * sw
Xhat <- Zw %*% solve(crossprod(Zw), crossprod(Zw, Xw))
beta <- solve(crossprod(Xhat), crossprod(Xhat, yw))
iv_slope <- beta[4, 1]

e00 <- est$x[est$area == "0" & est$period == 0][1]
e01 <- est$x[est$area == "0" & est$period == 1][1]
i00 <- est$z[est$area == "0" & est$period == 0][1]

mk <- function(term, value) {
  list(term = term, estimate = as.numeric(value), se = NA_real_, n_obs = n_obs)
}

out <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = list(
    mk("iv_slope", iv_slope),
    mk("exposure_area0_period0", e00),
    mk("exposure_area0_period1", e01),
    mk("instrument_area0_period0", i00)
  ),
  method_metadata = list(
    estimator = "weighted_2sls",
    weight = "base_population",
    outcome = "change_pp",
    endogenous = "x",
    instruments = c("intercept", "period", "control", "z"),
    exogenous = c("intercept", "period", "control"),
    n_obs = n_obs
  ),
  diagnostics = list(
    n_obs = n_obs,
    n_areas = as.integer(length(unique(est$area))),
    n_periods = as.integer(length(unique(est$period))),
    n_industries = as.integer(length(inds))
  )
)

write_json(out, "result.json", auto_unbox = TRUE, digits = NA, na = "null", pretty = TRUE)
