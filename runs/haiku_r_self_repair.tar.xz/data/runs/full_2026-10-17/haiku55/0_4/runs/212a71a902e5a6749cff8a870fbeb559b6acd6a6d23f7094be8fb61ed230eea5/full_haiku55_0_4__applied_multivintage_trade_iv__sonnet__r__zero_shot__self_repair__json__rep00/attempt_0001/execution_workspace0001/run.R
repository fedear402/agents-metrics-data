library(jsonlite)

rd <- function(f) {
  d <- read.csv(f, stringsAsFactors = FALSE, colClasses = "character", strip.white = TRUE)
  if ("period" %in% names(d)) d$period <- as.numeric(d$period)
  d
}

crosswalk <- rd("crosswalk.csv")
trade <- rd("trade.csv")
areas <- rd("areas.csv")
employment <- rd("employment.csv")
outcomes <- rd("outcomes.csv")

for (col in c("us_change", "other_change", "price_index", "years")) trade[[col]] <- as.numeric(trade[[col]])
areas$total_employment <- as.numeric(areas$total_employment)
areas$population <- as.numeric(areas$population)
employment$employment <- as.numeric(employment$employment)
outcomes$change_pp <- as.numeric(outcomes$change_pp)
outcomes$control <- as.numeric(outcomes$control)

tc <- merge(trade, crosswalk, by = "code")
tr <- unique(tc[, c("period", "industry", "us_change", "other_change", "price_index", "years")])

ind <- sort(unique(crosswalk$industry))
ap <- unique(areas[, c("area", "period")])
grid <- merge(ap, data.frame(industry = ind, stringsAsFactors = FALSE), by = NULL)

emp_grid <- function(v) {
  e <- employment[employment$vintage == v & employment$industry %in% ind, ]
  e <- aggregate(employment ~ area + period + industry, data = e, FUN = sum)
  g <- merge(grid, e, by = c("area", "period", "industry"), all.x = TRUE)
  g$employment[is.na(g$employment)] <- 0
  g
}

exposure <- function(v, shock_col) {
  g <- emp_grid(v)
  te <- areas[areas$vintage == v, c("area", "period", "total_employment")]
  nat <- aggregate(employment ~ period + industry, data = g, FUN = sum)
  names(nat)[3] <- "nat_emp"
  sh <- tr[, c("period", "industry", "price_index", "years", shock_col)]
  names(sh)[5] <- "shock"
  d <- merge(g, te, by = c("area", "period"))
  d <- merge(d, nat, by = c("period", "industry"))
  d <- merge(d, sh, by = c("period", "industry"))
  d$term <- (d$employment / d$total_employment) * (d$shock / d$nat_emp) /
    (d$price_index / 100) / 1000 * (10 / d$years)
  x <- aggregate(term ~ area + period, data = d, FUN = sum)
  names(x)[3] <- "val"
  x
}

xb <- exposure("base", "us_change")
names(xb)[3] <- "x"
ze <- exposure("early", "other_change")
names(ze)[3] <- "z"

pop <- areas[areas$vintage == "base", c("area", "period", "population")]
dat <- merge(outcomes[, c("area", "period", "control", "change_pp")], pop, by = c("area", "period"))
dat <- merge(dat, xb, by = c("area", "period"))
dat <- merge(dat, ze, by = c("area", "period"))

n_obs <- nrow(dat)

y <- dat$change_pp
w <- dat$population
X <- cbind(1, dat$period, dat$control, dat$x)
Z <- cbind(1, dat$period, dat$control, dat$z)
Mxz <- crossprod(X, w * Z)
Mzz_inv <- solve(crossprod(Z, w * Z))
Mzy <- crossprod(Z, w * y)
beta <- solve(Mxz %*% Mzz_inv %*% t(Mxz), Mxz %*% Mzz_inv %*% Mzy)
iv_slope <- beta[4, 1]

is_a0 <- dat$area == "0"
exposure_area0_period0 <- dat$x[is_a0 & dat$period == 0]
exposure_area0_period1 <- dat$x[is_a0 & dat$period == 1]
instrument_area0_period0 <- dat$z[is_a0 & dat$period == 0]

est <- function(term, value) {
  list(term = term, estimate = as.numeric(value), se = NULL, n_obs = as.integer(n_obs))
}

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = list(
    est("iv_slope", iv_slope),
    est("exposure_area0_period0", exposure_area0_period0),
    est("exposure_area0_period1", exposure_area0_period1),
    est("instrument_area0_period0", instrument_area0_period0)
  ),
  method_metadata = list(
    estimator = "weighted 2SLS",
    weight = "base-vintage population",
    regressors = c("intercept", "period", "control", "x"),
    instruments = c("intercept", "period", "control", "z"),
    n_obs = as.integer(n_obs)
  ),
  diagnostics = list(
    n_industries = as.integer(length(ind)),
    n_area_periods = as.integer(n_obs)
  )
)

write_json(result, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE, null = "null")
