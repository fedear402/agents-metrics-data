suppressPackageStartupMessages(library(jsonlite))

df <- read.csv("input.csv", stringsAsFactors = FALSE)
df$date <- as.Date(df$date)
df <- df[order(df$date), ]

dl <- c(NA, diff(log(df$vix)))
ly <- log(df$sales)
L <- 15

lagmat <- sapply(1:L, function(k) c(rep(NA, k), head(dl, -k)))
colnames(lagmat) <- paste0("lag_", 1:L)

dat <- data.frame(y = ly, lagmat)
dat <- dat[complete.cases(dat), ]
N <- nrow(dat)

X <- cbind(1, as.matrix(dat[, -1]))
y <- dat$y
XtX_inv <- solve(crossprod(X))
b <- as.vector(XtX_inv %*% crossprod(X, y))
u <- as.vector(y - X %*% b)

Xu <- X * u
S <- crossprod(Xu)
for (j in 1:L) {
  w <- 1 - j / (L + 1)
  Gj <- crossprod(Xu[(j + 1):N, , drop = FALSE], Xu[1:(N - j), , drop = FALSE])
  S <- S + w * (Gj + t(Gj))
}
V <- XtX_inv %*% S %*% XtX_inv * N / (N - L - 1)

cvec <- c(0, rep(1, L))
cum_est <- sum(b[-1])
cum_se <- sqrt(as.numeric(t(cvec) %*% V %*% cvec))

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(term = "cumulative_response", estimate = cum_est, se = cum_se, n_obs = N),
    list(term = "lag_1", estimate = b[2], se = sqrt(V[2, 2]), n_obs = N),
    list(term = "lag_15", estimate = b[16], se = sqrt(V[16, 16]), n_obs = N)
  ),
  method_metadata = list(
    estimator = "OLS regression of log(sales) on intercept and 15 lags of dlog(vix)",
    vcov = "Newey-West HAC, max lag 15, Bartlett weights 1-j/16, scaled by N/(N-16)"
  ),
  diagnostics = setNames(list(), character(0))
)

write(toJSON(result, auto_unbox = TRUE, digits = NA, pretty = TRUE), "result.json")
