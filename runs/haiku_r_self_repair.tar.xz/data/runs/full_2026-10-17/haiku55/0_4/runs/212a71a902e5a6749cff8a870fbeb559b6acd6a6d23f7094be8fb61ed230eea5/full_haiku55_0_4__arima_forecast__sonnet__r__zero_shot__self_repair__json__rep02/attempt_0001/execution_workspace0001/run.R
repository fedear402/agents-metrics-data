df <- read.csv("./input.csv", stringsAsFactors = FALSE)
y <- as.numeric(df$y)
y <- y[!is.na(y)]
n <- length(y)

fit <- arima(y, order = c(1, 1, 1), include.mean = FALSE, method = "ML")

pred <- predict(fit, n.ahead = 1)
fc <- as.numeric(pred$pred[1])
se_fc <- as.numeric(pred$se[1])

z <- qnorm(0.975)
lower <- fc - z * se_fc
upper <- fc + z * se_fc

out <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = list(
    list(term = "forecast", estimate = fc, se = se_fc, n_obs = n),
    list(term = "lower_95", estimate = lower, se = se_fc, n_obs = n),
    list(term = "upper_95", estimate = upper, se = se_fc, n_obs = n)
  ),
  method_metadata = list(
    estimator = "ARIMA(1,1,1) maximum likelihood, no constant or drift",
    vcov = "model-based (inverse observed information from arima)"
  ),
  diagnostics = list(
    aic = fit$aic,
    loglik = fit$loglik,
    sigma2 = fit$sigma2,
    coef_ar1 = unname(coef(fit)["ar1"]),
    coef_ma1 = unname(coef(fit)["ma1"]),
    forecast_origin_t = max(df$t, na.rm = TRUE)
  )
)

if (requireNamespace("jsonlite", quietly = TRUE)) {
  json <- jsonlite::toJSON(out, auto_unbox = TRUE, digits = NA, pretty = TRUE)
} else {
  fmt <- function(x) format(x, digits = 15, scientific = FALSE)
  json <- sprintf(
    '{"task_id":"arima_forecast","platform":"r","estimates":[{"term":"forecast","estimate":%s,"se":%s,"n_obs":%d},{"term":"lower_95","estimate":%s,"se":%s,"n_obs":%d},{"term":"upper_95","estimate":%s,"se":%s,"n_obs":%d}],"method_metadata":{"estimator":"ARIMA(1,1,1) maximum likelihood, no constant or drift","vcov":"model-based (inverse observed information from arima)"},"diagnostics":{}}',
    fmt(fc), fmt(se_fc), n, fmt(lower), fmt(se_fc), n, fmt(upper), fmt(se_fc), n
  )
}
writeLines(json, "result.json")
