suppressPackageStartupMessages(library(jsonlite))

hh <- read.csv("households.csv", stringsAsFactors = FALSE)
census <- read.csv("census.csv", stringsAsFactors = FALSE)

d <- hh[hh$recipient == 0, , drop = FALSE]
n_obs <- as.integer(nrow(d))

e <- as.numeric(d$eligible)
ne <- 1 - e
dose <- as.numeric(d$dose)
base <- as.numeric(d$baseline)
inst <- as.numeric(d$instrument)
w <- as.numeric(d$weight)
y <- as.numeric(d$outcome)

X <- cbind(ne, e, base * ne, base * e)
Z <- cbind(X, inst * ne, inst * e)
R <- cbind(dose * ne, dose * e, X)

sw <- sqrt(w)
Rw <- R * sw
Zw <- Z * sw
yw <- y * sw

ZtZinv <- solve(crossprod(Zw))
PRz <- crossprod(Rw, Zw) %*% ZtZinv %*% crossprod(Zw, Rw)
Pzy <- crossprod(Rw, Zw) %*% ZtZinv %*% crossprod(Zw, yw)
beta <- as.numeric(solve(PRz, Pzy))

slope_ne <- beta[1]
slope_e <- beta[2]

wmean <- function(x, wt) sum(x * wt) / sum(wt)
mdose_ne <- wmean(dose[ne == 1], w[ne == 1])
mdose_e <- wmean(dose[e == 1], w[e == 1])

ineligible_effect <- slope_ne * mdose_ne
eligible_nonrecipient_effect <- slope_e * mdose_e

N0 <- sum(as.numeric(census$nonrecipient_population[census$eligible == 0]))
N1 <- sum(as.numeric(census$nonrecipient_population[census$eligible == 1]))
w0 <- N0 / (N0 + N1)
w1 <- N1 / (N0 + N1)

population_effect <- w0 * ineligible_effect + w1 * eligible_nonrecipient_effect

estimates <- list(
  list(term = "ineligible_effect", estimate = ineligible_effect, se = NA_real_, n_obs = n_obs),
  list(term = "eligible_nonrecipient_effect", estimate = eligible_nonrecipient_effect, se = NA_real_, n_obs = n_obs),
  list(term = "population_effect", estimate = population_effect, se = NA_real_, n_obs = n_obs)
)

result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    method = "weighted two-stage least squares, no added intercept",
    endogenous = c("dose*(1-eligible)", "dose*eligible"),
    exogenous = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"),
    instruments = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible",
                    "instrument*(1-eligible)", "instrument*eligible"),
    regression_weight = "weight",
    group_effect_definition = "dose slope times household-weighted mean dose among retained nonrecipients in group",
    counterfactual = "synthetic zero-dose attribution convention",
    final_aggregation_weights = "census nonrecipient_population by eligibility group",
    se_reported = "null"
  ),
  diagnostics = list(
    n_obs = n_obs,
    n_ineligible = as.integer(sum(ne == 1)),
    n_eligible = as.integer(sum(e == 1)),
    rank_instruments = as.integer(qr(Zw)$rank),
    ncol_instruments = as.integer(ncol(Zw)),
    rank_regressors = as.integer(qr(Rw)$rank),
    ncol_regressors = as.integer(ncol(Rw)),
    slope_dose_ineligible = slope_ne,
    slope_dose_eligible = slope_e,
    weighted_mean_dose_ineligible = mdose_ne,
    weighted_mean_dose_eligible = mdose_e,
    census_population_ineligible = N0,
    census_population_eligible = N1,
    population_weight_ineligible = w0,
    population_weight_eligible = w1
  )
)

write_json(result, "result.json", auto_unbox = TRUE, digits = NA, na = "null", pretty = TRUE)
