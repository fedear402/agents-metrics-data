library(jsonlite)

df <- read.csv("input.csv")
h <- 1
d <- df[abs(df$score) < h, ]
s <- d$score
w <- 1 - abs(s)
D <- as.numeric(s >= 0)
X <- cbind(1, D, s, D * s)
Y <- cbind(d$earnings, d$participated)

bread <- solve(crossprod(X, w * X))
B <- bread %*% crossprod(X, w * Y)
E <- Y - X %*% B

a <- bread[, 2]
h_i <- w * drop(X %*% a)
infl <- h_i * E
J <- crossprod(infl)

rf <- B[2, 1]
fs <- B[2, 2]
tau <- rf / fs
g <- c(1 / fs, -rf / fs^2)

se_rf <- sqrt(J[1, 1])
se_fs <- sqrt(J[2, 2])
se_tau <- sqrt(drop(t(g) %*% J %*% g))

n_obs <- nrow(d)

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = unname(as.numeric(tau)),
         se = unname(as.numeric(se_tau)), n_obs = as.integer(n_obs)),
    list(term = "reduced_form", estimate = unname(as.numeric(rf)),
         se = unname(as.numeric(se_rf)), n_obs = as.integer(n_obs)),
    list(term = "first_stage", estimate = unname(as.numeric(fs)),
         se = unname(as.numeric(se_fs)), n_obs = as.integer(n_obs))
  ),
  method_metadata = list(
    estimator = "fuzzy RD, local linear with separate slopes, triangular kernel, bandwidth 1, Wald ratio",
    vcov = "HC0 sandwich, no degrees-of-freedom correction; delta method for treatment_effect with joint covariance"
  ),
  diagnostics = list(
    cutoff = 0,
    bandwidth = h,
    kernel = "triangular",
    n_left = as.integer(sum(D == 0)),
    n_right = as.integer(sum(D == 1)),
    covariance_reduced_form_first_stage = unname(as.numeric(J[1, 2]))
  )
)

write_json(result, "result.json", auto_unbox = TRUE, digits = 16, pretty = TRUE)
