households <- read.csv("households.csv")
census <- read.csv("census.csv")

d <- subset(households, recipient == 0)
e <- d$eligible
ne <- 1 - e
w <- d$weight
sw <- sqrt(w)

exog <- cbind(ne, e, d$baseline * ne, d$baseline * e)
endog <- cbind(d$dose * ne, d$dose * e)
inst <- cbind(d$instrument * ne, d$instrument * e)

X <- cbind(exog, endog) * sw
Z <- cbind(exog, inst) * sw
y <- d$outcome * sw

ZZinv <- solve(crossprod(Z))
A <- crossprod(Z, X)
b <- crossprod(Z, y)
beta <- as.numeric(solve(t(A) %*% ZZinv %*% A, t(A) %*% ZZinv %*% b))

slope <- c(beta[ncol(exog) + 1], beta[ncol(exog) + 2])

mean_dose <- sapply(0:1, function(g) {
  idx <- e == g
  sum(d$dose[idx] * w[idx]) / sum(w[idx])
})

group_effect <- slope * mean_dose
names(group_effect) <- c("ineligible", "eligible_nonrecipient")

pop <- census$nonrecipient_population[match(0:1, census$eligible)]
population_effect <- sum(group_effect * pop) / sum(pop)

n_obs <- as.integer(nrow(d))

make_est <- function(term, value) {
  list(term = term, estimate = unname(value), se = NULL, n_obs = n_obs)
}

estimates <- list(
  make_est("ineligible_effect", group_effect[["ineligible"]]),
  make_est("eligible_nonrecipient_effect", group_effect[["eligible_nonrecipient"]]),
  make_est("population_effect", population_effect)
)

result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    method = "weighted two-stage least squares",
    endogenous_columns = c("dose*(1-eligible)", "dose*eligible"),
    exogenous_columns = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"),
    instrument_columns = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible",
                           "instrument*(1-eligible)", "instrument*eligible"),
    intercept = FALSE,
    regression_weight = "weight",
    sample = "recipient == 0",
    counterfactual = "dose set to zero for every retained household (synthetic attribution convention)"
  ),
  diagnostics = list(
    n_obs = n_obs,
    n_eligible_0 = as.integer(sum(e == 0)),
    n_eligible_1 = as.integer(sum(e == 1)),
    group_slopes = list(ineligible = unname(slope[1]), eligible_nonrecipient = unname(slope[2])),
    group_mean_dose = list(ineligible = unname(mean_dose[1]), eligible_nonrecipient = unname(mean_dose[2])),
    census_weights = list(ineligible = unname(pop[1]), eligible_nonrecipient = unname(pop[2]))
  )
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = 15, pretty = TRUE, null = "null")
