library(jsonlite)

read_chr <- function(f) read.csv(f, stringsAsFactors = FALSE, strip.white = TRUE)

to_chr <- function(df, cols) {
  for (nm in intersect(cols, names(df))) df[[nm]] <- as.character(df[[nm]])
  df
}

crosswalk <- read_chr("crosswalk.csv")
trade <- read_chr("trade.csv")
areas <- read_chr("areas.csv")
employment <- read_chr("employment.csv")
outcomes <- read_chr("outcomes.csv")

crosswalk <- to_chr(crosswalk, c("code", "industry"))
trade <- to_chr(trade, c("code", "period"))
areas <- to_chr(areas, c("area", "period", "vintage"))
employment <- to_chr(employment, c("area", "period", "vintage", "industry"))
outcomes <- to_chr(outcomes, c("area", "period"))

trade <- merge(trade, crosswalk, by = "code")

periods <- sort(unique(areas$period))
areas_u <- sort(unique(areas$area))
industries <- sort(unique(crosswalk$industry))

g <- expand.grid(area = areas_u, period = periods,
                 vintage = c("base", "early"), industry = industries,
                 stringsAsFactors = FALSE)
esum <- tapply(employment$employment,
               paste(employment$area, employment$period, employment$vintage,
                     employment$industry, sep = "|"), sum)
gkey <- paste(g$area, g$period, g$vintage, g$industry, sep = "|")
g$employment <- ifelse(gkey %in% names(esum), as.numeric(esum[gkey]), 0)

tot <- setNames(areas$total_employment,
                paste(areas$area, areas$period, areas$vintage, sep = "|"))
base_rows <- areas$vintage == "base"
pop <- setNames(areas$population[base_rows],
                paste(areas$area, areas$period, sep = "|")[base_rows])

trade$tkey <- paste(trade$period, trade$industry, sep = "|")

exposure <- function(v, shock_col) {
  e <- g[g$vintage == v, ]
  tk <- paste(e$period, e$industry, sep = "|")
  natv <- tapply(e$employment, tk, sum)
  shock <- trade[[shock_col]][match(tk, trade$tkey)]
  price <- trade$price_index[match(e$period, trade$period)]
  yrs <- trade$years[match(e$period, trade$period)]
  share <- e$employment / tot[paste(e$area, e$period, v, sep = "|")]
  contrib <- share * (shock / natv[tk]) / (price / 100) / 1000 * (10 / yrs)
  tapply(contrib, paste(e$area, e$period, sep = "|"), sum)
}

x_all <- exposure("base", "us_change")
z_all <- exposure("early", "other_change")

d <- outcomes
d$key <- paste(d$area, d$period, sep = "|")
d$x <- as.numeric(x_all[d$key])
d$z <- as.numeric(z_all[d$key])
d$weight <- as.numeric(pop[d$key])
d$period_num <- as.numeric(d$period)
d$control_num <- as.numeric(d$control)
n <- nrow(d)

iv <- function(y, C, x, z, w = rep(1, length(y))) {
  X <- cbind(C, x) * sqrt(w)
  Z <- cbind(C, z) * sqrt(w)
  fitted <- qr.fitted(qr(Z), X)
  as.numeric(qr.coef(qr(fitted), y * sqrt(w)))[ncol(X)]
}

C <- cbind(1, d$period_num, d$control_num)
iv_slope <- iv(d$change_pp, C, d$x, d$z, d$weight)

exp00 <- unname(x_all["0|0"])
exp01 <- unname(x_all["0|1"])
ins00 <- unname(z_all["0|0"])

n_obs <- as.integer(n)

estimates <- list(
  list(term = "iv_slope", estimate = unname(iv_slope), se = NA_real_, n_obs = n_obs),
  list(term = "exposure_area0_period0", estimate = exp00, se = NA_real_, n_obs = n_obs),
  list(term = "exposure_area0_period1", estimate = exp01, se = NA_real_, n_obs = n_obs),
  list(term = "instrument_area0_period0", estimate = ins00, se = NA_real_, n_obs = n_obs)
)

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    method = "weighted 2SLS",
    outcome = "change_pp",
    endogenous = "x",
    instruments = c("intercept", "period", "control", "z"),
    weight = "base-vintage population",
    n_obs = n_obs
  ),
  diagnostics = list(
    n_obs = n_obs,
    n_areas = as.integer(length(areas_u)),
    n_periods = as.integer(length(periods)),
    n_industries = as.integer(length(industries))
  )
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = NA,
                     na = "null", pretty = TRUE)
