library(jsonlite)

d <- read.csv("input.csv", stringsAsFactors = FALSE)

run_cohort <- function(c0) {
  w <- (c0 - 2):(c0 + 2)
  sub <- d[d$time %in% w & (d$g == c0 | d$g == 0 | d$g > c0 + 2), ]
  n_times <- tapply(sub$time, sub$id, function(t) length(unique(t)))
  keep_ids <- names(n_times)[n_times == length(w)]
  sub <- sub[as.character(sub$id) %in% keep_ids, ]
  sub$did <- as.numeric(sub$g == c0 & sub$time >= c0)
  n_treated <- length(unique(sub$id[sub$g == c0]))
  fit <- lm(y ~ did + factor(id) + factor(time), data = sub)
  list(
    att = unname(coef(fit)["did"]),
    n_obs = nrow(sub),
    n_treated = n_treated
  )
}

res3 <- run_cohort(3)
res5 <- run_cohort(5)
res7 <- run_cohort(7)

weights <- c(res3$n_treated, res5$n_treated, res7$n_treated)
atts <- c(res3$att, res5$att, res7$att)
att_weighted <- sum(weights * atts) / sum(weights)
n_obs_total <- res3$n_obs + res5$n_obs + res7$n_obs

result <- list(
  task_id = "broad_cohort_stack",
  platform = "r",
  estimates = list(
    list(term = "att_g3", estimate = sprintf("%.12g", res3$att), se = NULL, n_obs = as.integer(res3$n_obs)),
    list(term = "att_g5", estimate = sprintf("%.12g", res5$att), se = NULL, n_obs = as.integer(res5$n_obs)),
    list(term = "att_g7", estimate = sprintf("%.12g", res7$att), se = NULL, n_obs = as.integer(res7$n_obs)),
    list(term = "att_weighted", estimate = sprintf("%.12g", att_weighted), se = NULL, n_obs = as.integer(n_obs_total))
  ),
  method_metadata = jsonlite::emptyNamedList,
  diagnostics = jsonlite::emptyNamedList
)

write_json(result, "result.json", auto_unbox = TRUE, pretty = TRUE)
