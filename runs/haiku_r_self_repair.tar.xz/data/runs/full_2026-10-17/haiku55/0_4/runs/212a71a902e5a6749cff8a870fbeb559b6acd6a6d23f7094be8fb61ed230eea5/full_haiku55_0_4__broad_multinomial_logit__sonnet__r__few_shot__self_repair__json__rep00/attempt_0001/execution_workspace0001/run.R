d <- read.csv("input.csv")
d$y <- factor(d$y, levels = 0:2)
fit <- nnet::multinom(y ~ x + z, data = d, Hess = TRUE, trace = FALSE,
                      maxit = 1000, reltol = 1e-12, abstol = 1e-12)
B <- coef(fit)
V <- vcov(fit)
n <- nrow(d)
b1 <- B["1", ]
b2 <- B["2", ]
v1x <- sqrt(V["1:x", "1:x"])
v1z <- sqrt(V["1:z", "1:z"])
v2x <- sqrt(V["2:x", "2:x"])
v2z <- sqrt(V["2:z", "2:z"])
indices <- c(0, B[, "(Intercept)"])
p <- exp(indices - max(indices)) / sum(exp(indices - max(indices)))
stopifnot(abs(sum(p) - 1) < 1e-12)
res <- list(
  task_id = "broad_multinomial_logit",
  platform = "r",
  estimates = list(
    list(term = "x_cat1", estimate = unname(b1["x"]), se = unname(v1x), n_obs = as.integer(n)),
    list(term = "z_cat1", estimate = unname(b1["z"]), se = unname(v1z), n_obs = as.integer(n)),
    list(term = "x_cat2", estimate = unname(b2["x"]), se = unname(v2x), n_obs = as.integer(n)),
    list(term = "z_cat2", estimate = unname(b2["z"]), se = unname(v2z), n_obs = as.integer(n)),
    list(term = "prob_cat2_zero", estimate = unname(p[3]), se = NULL, n_obs = as.integer(n))
  ),
  method_metadata = list(
    estimator = "multinomial logit (nnet::multinom, MLE, base outcome 0)",
    vcov = "observed information (model-based Hessian)"
  ),
  diagnostics = setNames(list(), character(0))
)
jsonlite::write_json(res, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
