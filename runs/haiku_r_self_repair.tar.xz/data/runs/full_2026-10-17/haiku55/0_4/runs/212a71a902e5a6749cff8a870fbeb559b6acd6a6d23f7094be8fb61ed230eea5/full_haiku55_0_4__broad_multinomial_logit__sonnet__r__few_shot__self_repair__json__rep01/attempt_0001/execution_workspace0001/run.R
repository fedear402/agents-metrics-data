d <- read.csv("input.csv")
d$y <- factor(d$y, levels = 0:2)
fit <- nnet::multinom(y ~ x + z, data = d, Hess = TRUE, trace = FALSE,
                      maxit = 1000, reltol = 1e-12, abstol = 1e-12)
B <- coef(fit)
V <- vcov(fit)
n <- nrow(d)

b1 <- B["1", ]
b2 <- B["2", ]
V1 <- V[c("1:(Intercept)", "1:x", "1:z"), c("1:(Intercept)", "1:x", "1:z")]
V2 <- V[c("2:(Intercept)", "2:x", "2:z"), c("2:(Intercept)", "2:x", "2:z")]

xb <- c(1, 0, 0)
eta <- c(0, sum(B["1", c("(Intercept)")]), sum(B["2", c("(Intercept)")]))
indices <- c(0, unname(B["1", "(Intercept)"]), unname(B["2", "(Intercept)"]))
p <- exp(indices - max(indices))
p <- p / sum(p)
p2_zero <- p[3]

# Delta-method SE is not required (se = null)
out <- list(
  task_id = "broad_multinomial_logit",
  platform = "r",
  estimates = list(
    list(term = "x_cat1", estimate = unname(b1["x"]), se = unname(sqrt(V1["1:x", "1:x"])), n_obs = as.integer(n)),
    list(term = "z_cat1", estimate = unname(b1["z"]), se = unname(sqrt(V1["1:z", "1:z"])), n_obs = as.integer(n)),
    list(term = "x_cat2", estimate = unname(b2["x"]), se = unname(sqrt(V2["2:x", "2:x"])), n_obs = as.integer(n)),
    list(term = "z_cat2", estimate = unname(b2["z"]), se = unname(sqrt(V2["2:z", "2:z"])), n_obs = as.integer(n)),
    list(term = "prob_cat2_zero", estimate = unname(p2_zero), se = NULL, n_obs = as.integer(n))
  ),
  method_metadata = list(
    estimator = "multinomial logit (nnet::multinom, MLE, base outcome 0)",
    vcov = "observed information (model Hessian)"
  ),
  diagnostics = setNames(list(), character(0))
)

jsonlite::write_json(out, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
