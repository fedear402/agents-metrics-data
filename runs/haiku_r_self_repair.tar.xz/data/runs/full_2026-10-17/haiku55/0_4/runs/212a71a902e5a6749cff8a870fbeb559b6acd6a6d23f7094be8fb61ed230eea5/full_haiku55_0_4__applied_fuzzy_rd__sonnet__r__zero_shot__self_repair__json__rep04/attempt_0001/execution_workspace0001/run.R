library(jsonlite)

df <- read.csv("input.csv")
df <- df[abs(df$score) < 1, ]

s <- df$score
w <- 1 - abs(s)
earn <- df$earnings
part <- df$participated
right <- s >= 0
n_obs <- nrow(df)
idxR <- which(right)
idxL <- which(!right)

fit_side <- function(idx, y) {
  X <- cbind(1, s[idx])
  W <- w[idx]
  yy <- y[idx]
  B <- solve(crossprod(X, W * X))
  b <- B %*% crossprod(X, W * yy)
  e <- yy - X %*% b
  psi <- (X * (W * as.vector(e))) %*% B
  list(a = as.numeric(b[1]), psi = psi)
}

stack_if <- function(y) {
  fR <- fit_side(idxR, y)
  fL <- fit_side(idxL, y)
  IF <- numeric(n_obs)
  IF[idxR] <- fR$psi[, 1]
  IF[idxL] <- -fL$psi[, 1]
  list(disc = fR$a - fL$a, IF = IF)
}

ry <- stack_if(earn)
rd <- stack_if(part)

reduced_form <- ry$disc
first_stage <- rd$disc
V_rf <- sum(ry$IF^2)
V_fs <- sum(rd$IF^2)
C_rf_fs <- sum(ry$IF * rd$IF)

treatment_effect <- reduced_form / first_stage
var_te <- V_rf / first_stage^2 +
  reduced_form^2 * V_fs / first_stage^4 -
  2 * reduced_form * C_rf_fs / first_stage^3
se_te <- sqrt(var_te)

se_rf <- sqrt(V_rf)
se_fs <- sqrt(V_fs)

n_right <- length(idxR)
n_left <- length(idxL)

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = treatment_effect, se = se_te, n_obs = n_obs),
    list(term = "reduced_form", estimate = reduced_form, se = se_rf, n_obs = n_obs),
    list(term = "first_stage", estimate = first_stage, se = se_fs, n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "fuzzy RD, local linear with separate slopes per side, triangular kernel weights 1-|score|, cutoff 0, bandwidth 1, ratio via delta method",
    vcov = "HC0 heteroskedasticity-robust sandwich with joint stacked influence functions, delta method for ratio"
  ),
  diagnostics = list(
    cutoff = 0,
    bandwidth = 1,
    n_right = n_right,
    n_left = n_left
  )
)

write_json(result, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE)
