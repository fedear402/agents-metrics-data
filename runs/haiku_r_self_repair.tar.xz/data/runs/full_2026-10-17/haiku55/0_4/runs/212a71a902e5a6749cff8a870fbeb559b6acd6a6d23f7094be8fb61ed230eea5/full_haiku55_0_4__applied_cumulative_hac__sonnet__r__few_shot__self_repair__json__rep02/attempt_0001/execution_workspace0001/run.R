library(jsonlite)

d <- read.csv("input.csv", stringsAsFactors = FALSE)
d$date <- as.Date(d$date)
d <- d[order(d$date), ]

d$vix_change <- c(NA, diff(log(d$vix)))
d$log_sales <- log(d$sales)

L <- 15
n <- nrow(d)
lagmat <- sapply(1:L, function(k) c(rep(NA, k), d$vix_change[1:(n - k)]))
colnames(lagmat) <- paste0("lag", 1:L)

dat <- data.frame(log_sales = d$log_sales, lagmat)
sample <- dat[complete.cases(dat), ]

fit <- lm(log_sales ~ ., data = sample)
X <- model.matrix(fit)
coefficients <- coef(fit)
N <- nrow(X)
p <- ncol(X)

scores <- X * residuals(fit)
hac_lags <- L
meat <- crossprod(scores)
for (j in seq_len(hac_lags)) {
  lag_product <- crossprod(scores[(j + 1):N, , drop = FALSE], scores[1:(N - j), , drop = FALSE])
  meat <- meat + (1 - j / (hac_lags + 1)) * (lag_product + t(lag_product))
}
bread <- solve(crossprod(X))
covariance <- N / (N - p) * bread %*% meat %*% bread

contrast <- c(0, rep(1, L))
cumulative <- sum(contrast * coefficients)
cumulative_se <- sqrt(drop(t(contrast) %*% covariance %*% contrast))

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(term = "cumulative_response", estimate = unname(as.numeric(cumulative)),
         se = unname(as.numeric(cumulative_se)), n_obs = as.integer(N)),
    list(term = "lag_1", estimate = unname(as.numeric(coefficients["lag1"])),
         se = unname(as.numeric(sqrt(covariance[2, 2]))), n_obs = as.integer(N)),
    list(term = "lag_15", estimate = unname(as.numeric(coefficients["lag15"])),
         se = unname(as.numeric(sqrt(covariance[p, p]))), n_obs = as.integer(N))
  ),
  method_metadata = list(
    estimator = "OLS of log(sales) on intercept and 15 lags of vix log-change",
    vcov = "Newey-West HAC, max lag 15, Bartlett weights 1-j/16, scaled by N/(N-16)"
  ),
  diagnostics = list(
    n_total = as.integer(nrow(d)),
    n_used = as.integer(N),
    n_parameters = as.integer(p)
  )
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
