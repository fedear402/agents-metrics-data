library(jsonlite)

df <- read.csv("input.csv", stringsAsFactors = FALSE)
df$date <- as.Date(df$date)
df <- df[order(df$date), ]
n <- nrow(df)

df$lsales <- log(as.numeric(df$sales))
dl <- c(NA, diff(log(as.numeric(df$vix))))

L <- 15
lagmat <- sapply(1:L, function(k) c(rep(NA, k), head(dl, -k)))
colnames(lagmat) <- paste0("lag_", 1:L)

keep <- complete.cases(cbind(df$lsales, lagmat))
y <- df$lsales[keep]
Z <- lagmat[keep, , drop = FALSE]
X <- cbind(intercept = 1, Z)

fit <- lm.fit(X, y)
b <- fit$coefficients
e <- y - X %*% b
N <- nrow(X)
p <- ncol(X)

scores <- X * as.vector(e)
hac_lags <- 15
meat <- crossprod(scores)
for (j in seq_len(hac_lags)) {
  G <- crossprod(scores[(j + 1):N, , drop = FALSE], scores[1:(N - j), , drop = FALSE])
  meat <- meat + (1 - j / (hac_lags + 1)) * (G + t(G))
}
bread <- solve(crossprod(X))
V <- N / (N - p) * bread %*% meat %*% bread

contrast <- c(0, rep(1, L))
cumulative <- sum(contrast * b)
cumulative_se <- sqrt(drop(t(contrast) %*% V %*% contrast))

write_json(
  list(
    task_id = "applied_cumulative_hac",
    platform = "r",
    estimates = list(
      list(term = "cumulative_response", estimate = unname(cumulative),
           se = unname(cumulative_se), n_obs = as.integer(N)),
      list(term = "lag_1", estimate = unname(b[2]),
           se = unname(sqrt(V[2, 2])), n_obs = as.integer(N)),
      list(term = "lag_15", estimate = unname(b[16]),
           se = unname(sqrt(V[16, 16])), n_obs = as.integer(N))
    ),
    method_metadata = list(
      estimator = "OLS of log(sales) on intercept and lags 1-15 of diff(log(vix))",
      vcov = "Newey-West HAC, max lag 15, Bartlett weights 1-j/16, N/(N-16) correction"
    ),
    diagnostics = list(
      sample_size = as.integer(N),
      regression_lag_count = as.integer(L),
      hac_max_lag = as.integer(hac_lags),
      parameter_count = as.integer(p)
    )
  ),
  "result.json",
  auto_unbox = TRUE,
  digits = 16,
  pretty = TRUE
)
