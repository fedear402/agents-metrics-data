df <- read.csv("input.csv", stringsAsFactors = FALSE)

reg <- df[!duplicated(df$region_id), c("region_id", "region_weight", "x", "y")]
z_reg <- tapply(df$share * df$shock, df$region_id, sum)
reg$z <- as.numeric(z_reg[as.character(reg$region_id)])
reg$e <- reg$region_weight / sum(reg$region_weight)

wm <- function(v, w) sum(w * v) / sum(w)
reg$y0 <- reg$y - wm(reg$y, reg$e)
reg$x0 <- reg$x - wm(reg$x, reg$e)
reg$z0 <- reg$z - wm(reg$z, reg$e)

effect_reg <- sum(reg$e * reg$z0 * reg$y0) / sum(reg$e * reg$z0 * reg$x0)
first_reg <- sum(reg$e * reg$z0 * reg$x0) / sum(reg$e * reg$z0^2)

m <- merge(df, reg[, c("region_id", "e", "x0", "y0", "z0")], by = "region_id")
m$w_sh <- m$e * m$share

ind <- do.call(rbind, lapply(split(m, m$industry_id), function(d) {
  s <- sum(d$w_sh)
  data.frame(
    industry_id = d$industry_id[1],
    shock = d$shock[1],
    s = s,
    ybar = sum(d$w_sh * d$y0) / s,
    xbar = sum(d$w_sh * d$x0) / s,
    zbar = sum(d$w_sh * d$z0) / s
  )
}))

iv_hc1 <- function(y, endog, inst, w) {
  N <- length(y)
  X <- cbind(1, endog)
  Z <- cbind(1, inst)
  A <- t(Z) %*% (w * X)
  b <- solve(A, t(Z) %*% (w * y))
  u <- as.numeric(y - X %*% b)
  Ainv <- solve(A)
  M <- crossprod(Z * (w * u))
  V <- Ainv %*% M %*% t(Ainv) * N / (N - 2)
  list(b = as.numeric(b), se = sqrt(diag(V)))
}

eff <- iv_hc1(ind$ybar, ind$xbar, ind$shock, ind$s)
fs <- iv_hc1(ind$xbar, ind$zbar, ind$shock, ind$s)

eff_sh <- 1 / sum(ind$s^2)
N <- nrow(ind)

res <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = as.numeric(effect_reg), se = as.numeric(eff$se[2]), n_obs = as.integer(N)),
    list(term = "first_stage", estimate = as.numeric(first_reg), se = as.numeric(fs$se[2]), n_obs = as.integer(N)),
    list(term = "effective_shocks", estimate = as.numeric(eff_sh), se = NA_real_, n_obs = as.integer(N))
  ),
  method_metadata = list(
    estimator = "weighted 2SLS shift-share with Borusyak-Hull-Jaravel shock-level IV inference",
    vcov = "shock-level heteroskedasticity-robust HC1 with N/(N-2) multiplier, no clustering"
  ),
  diagnostics = list(
    n_regions = as.integer(nrow(reg)),
    n_industries = as.integer(N),
    shock_level_effect_slope = eff$b[2],
    shock_level_first_stage_slope = fs$b[2]
  )
)

jsonlite::write_json(res, "result.json", auto_unbox = TRUE, digits = NA, na = "null", pretty = TRUE)
