households <- read.csv("households.csv")
census <- read.csv("census.csv")

d <- subset(households, recipient == 0)
e <- d$eligible
b <- d$baseline
dose <- d$dose
z <- d$instrument
w <- d$weight
y <- d$outcome

exog <- cbind(1 - e, e, b * (1 - e), b * e)
endog <- cbind(dose * (1 - e), dose * e)
inst <- cbind(z * (1 - e), z * e)
X <- cbind(exog, endog)
Z <- cbind(exog, inst)

sw <- sqrt(w)
Xw <- X * sw
Zw <- Z * sw
yw <- y * sw
Pw <- qr.fitted(qr(Zw), Xw)
beta <- as.numeric(solve(crossprod(Pw), crossprod(Pw, yw)))

slope0 <- beta[5]
slope1 <- beta[6]
mean_dose0 <- weighted.mean(dose[e == 0], w[e == 0])
mean_dose1 <- weighted.mean(dose[e == 1], w[e == 1])
ineligible_effect <- slope0 * mean_dose0
eligible_effect <- slope1 * mean_dose1

pop_w <- census$nonrecipient_population[match(0:1, census$eligible)]
population_effect <- weighted.mean(c(ineligible_effect, eligible_effect), pop_w)

n_obs <- as.integer(nrow(d))
est <- function(term, value) list(term = term, estimate = value, se = NA_real_, n_obs = n_obs)

result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = list(
    est("ineligible_effect", ineligible_effect),
    est("eligible_nonrecipient_effect", eligible_effect),
    est("population_effect", population_effect)
  ),
  method_metadata = list(
    method = "weighted 2SLS, fully interacted by eligibility",
    sample = "recipient == 0, all treatment statuses retained",
    endogenous = c("dose*(1-eligible)", "dose*eligible"),
    instruments = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible",
                    "instrument*(1-eligible)", "instrument*eligible"),
    intercept = "none beyond group indicators",
    weight = "weight",
    counterfactual = "dose set to zero for every retained household",
    aggregation = "census nonrecipient_population by eligibility group",
    convention = "attribution to zero-dose counterfactual is a stated synthetic convention"
  ),
  diagnostics = list(
    n_obs = n_obs,
    rank_X = qr(Xw)$rank,
    rank_Z = qr(Zw)$rank,
    total_weight = sum(w),
    group_weighted_mean_dose = c(ineligible = mean_dose0, eligible = mean_dose1),
    group_dose_slope = c(ineligible = slope0, eligible = slope1)
  )
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = 15, na = "null", pretty = TRUE)
