d <- read.csv("input.csv")
n <- nrow(d)
q <- 2L
df <- n - 4L
crit <- qf(0.95, q, df)
k <- q * crit / df

gfun <- function(b) {
  yt <- d$y - b * d$endog
  rr <- lm(yt ~ x, data = d)
  ff <- lm(yt ~ x + z1 + z2, data = d)
  deviance(rr) - (1 + k) * deviance(ff)
}

g0 <- gfun(0)
g1 <- gfun(1)
gm1 <- gfun(-1)
C <- g0
A <- (g1 + gm1 - 2 * g0) / 2
B <- (g1 - gm1) / 2

accepts_zero <- as.integer(C <= 0)
disc <- B^2 - 4 * A * C

if (abs(A) < 1e-12) {
  root <- -C / B
  bounds <- c(root, NA_real_)
  unbounded <- 1L
  if (B > 0) {
    accepted_desc <- "(-Inf, root]"
  } else {
    accepted_desc <- "[root, Inf)"
  }
} else if (disc >= 0) {
  r <- sort(c((-B - sqrt(disc)) / (2 * A), (-B + sqrt(disc)) / (2 * A)))
  bounds <- r
  if (A > 0) {
    unbounded <- 0L
    accepted_desc <- "[low, high]"
  } else {
    unbounded <- 1L
    accepted_desc <- "(-Inf, low] U [high, Inf)"
  }
} else {
  bounds <- c(NA_real_, NA_real_)
  if (A > 0) {
    unbounded <- 0L
    accepted_desc <- "empty"
  } else {
    unbounded <- 1L
    accepted_desc <- "all reals"
  }
}

yt1 <- d$y - 1 * d$endog
rr1 <- lm(yt1 ~ x, data = d)
ff1 <- lm(yt1 ~ x + z1 + z2, data = d)
ar_f_at_one <- ((deviance(rr1) - deviance(ff1)) / q) / (deviance(ff1) / df)

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = list(
    list(term = "boundary_low", estimate = unname(bounds[1]), se = NULL, n_obs = as.integer(n)),
    list(term = "boundary_high", estimate = unname(bounds[2]), se = NULL, n_obs = as.integer(n)),
    list(term = "accepts_zero", estimate = accepts_zero, se = NULL, n_obs = as.integer(n)),
    list(term = "unbounded", estimate = unbounded, se = NULL, n_obs = as.integer(n)),
    list(term = "ar_f_at_one", estimate = unname(ar_f_at_one), se = NULL, n_obs = as.integer(n))
  ),
  method_metadata = list(
    estimator = "Anderson-Rubin confidence set by inverting homoskedastic joint F test",
    vcov = "homoskedastic"
  ),
  diagnostics = list(
    critical_value = crit,
    df_residual = df,
    quadratic_A = A,
    quadratic_B = B,
    quadratic_C = C,
    accepted_set = accepted_desc
  )
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
