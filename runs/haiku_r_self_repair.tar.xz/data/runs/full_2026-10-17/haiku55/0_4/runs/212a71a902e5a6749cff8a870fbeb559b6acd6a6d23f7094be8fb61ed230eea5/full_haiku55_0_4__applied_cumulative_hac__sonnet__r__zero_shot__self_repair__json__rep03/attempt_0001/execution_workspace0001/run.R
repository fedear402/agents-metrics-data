df <- read.csv("input.csv", stringsAsFactors = FALSE)
df$date <- as.Date(df$date)
df <- df[order(df$date), ]

n <- nrow(df)
ly <- log(df$sales)
lv <- log(df$vix)
d <- c(NA, diff(lv))

L <- 15
idx <- (L + 2):n
X <- cbind(1, sapply(1:L, function(k) d[idx - k]))
y <- ly[idx]
N <- length(y)

XtX_inv <- solve(crossprod(X))
b <- as.vector(XtX_inv %*% crossprod(X, y))
u <- as.vector(y - X %*% b)

G <- X * u
M <- crossprod(G)
for (j in 1:L) {
  w <- 1 - j / (L + 1)
  Gj <- crossprod(G[(j + 1):N, , drop = FALSE], G[1:(N - j), , drop = FALSE])
  M <- M + w * (Gj + t(Gj))
}
V <- XtX_inv %*% M %*% XtX_inv * N / (N - (L + 1))

R <- c(0, rep(1, L))
cum_est <- sum(b[2:(L + 1)])
cum_se <- sqrt(as.numeric(t(R) %*% V %*% R))

lag1_est <- b[2]
lag1_se <- sqrt(V[2, 2])
lag15_est <- b[L + 1]
lag15_se <- sqrt(V[L + 1, L + 1])

fmt <- function(x) formatC(x, digits = 15, format = "g")

json <- paste0(
  "{\n",
  "  \"task_id\": \"applied_cumulative_hac\",\n",
  "  \"platform\": \"r\",\n",
  "  \"estimates\": [\n",
  "    {\"term\": \"cumulative_response\", \"estimate\": ", fmt(cum_est),
  ", \"se\": ", fmt(cum_se), ", \"n_obs\": ", N, "},\n",
  "    {\"term\": \"lag_1\", \"estimate\": ", fmt(lag1_est),
  ", \"se\": ", fmt(lag1_se), ", \"n_obs\": ", N, "},\n",
  "    {\"term\": \"lag_15\", \"estimate\": ", fmt(lag15_est),
  ", \"se\": ", fmt(lag15_se), ", \"n_obs\": ", N, "}\n",
  "  ],\n",
  "  \"method_metadata\": {\"estimator\": \"OLS regression of log(sales) on intercept and lags 1-15 of first difference of log(vix)\", \"vcov\": \"Newey-West HAC, max lag 15, Bartlett weights 1-j/16, scaled by N/(N-16)\"},\n",
  "  \"diagnostics\": {\"n_total_rows\": ", n, ", \"n_obs\": ", N, ", \"newey_west_max_lag\": ", L, "}\n",
  "}\n"
)

writeLines(json, "result.json")
