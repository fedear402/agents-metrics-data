d <- read.csv("input.csv")
d$y <- factor(d$y, levels = 0:2)

fit <- nnet::multinom(y ~ x + z, data = d, Hess = TRUE, trace = FALSE,
                      maxit = 1000, reltol = 1e-12, abstol = 1e-12)

B <- coef(fit)
V <- vcov(fit)

get_se <- function(row, term) {
  sqrt(V[paste0(row, ":", term), paste0(row, ":", term)])
}

b1_x <- unname(B["1", "x"])
b1_z <- unname(B["1", "z"])
b2_x <- unname(B["2", "x"])
b2_z <- unname(B["2", "z"])

se1_x <- get_se("1", "x")
se1_z <- get_se("1", "z")
se2_x <- get_se("2", "x")
se2_z <- get_se("2", "z")

indices <- c(0, B[, "(Intercept)"])
p <- exp(indices - max(indices)) / sum(exp(indices - max(indices)))
stopifnot(abs(sum(p) - 1) < 1e-12)

n_obs <- nrow(d)

result <- list(
  task_id = "broad_multinomial_logit",
  platform = "r",
  estimates = list(
    list(term = "x_cat1", estimate = b1_x, se = se1_x, n_obs = as.integer(n_obs)),
    list(term = "z_cat1", estimate = b1_z, se = se1_z, n_obs = as.integer(n_obs)),
    list(term = "x_cat2", estimate = b2_x, se = se2_x, n_obs = as.integer(n_obs)),
    list(term = "z_cat2", estimate = b2_z, se = se2_z, n_obs = as.integer(n_obs)),
    list(term = "prob_cat2_zero", estimate = unname(p[3]), se = NULL, n_obs = as.integer(n_obs))
  ),
  method_metadata = list(
    estimator = "multinomial logit (maximum likelihood, nnet::multinom, base outcome 0)",
    vcov = "observed-information (inverse Hessian of negative log-likelihood)"
  ),
  diagnostics = setNames(list(), character(0))
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, null = "null",
                     digits = 16, pretty = TRUE)
