library(jsonlite)

d <- read.csv("input.csv")
cohorts <- c(3, 5, 7)

res <- lapply(cohorts, function(cc) {
  w <- (cc - 2):(cc + 2)
  s <- d[d$time %in% w & (d$g == cc | d$g == 0 | d$g > cc + 2), ]
  n_times <- tapply(s$time, s$id, function(t) length(unique(t)))
  keep_ids <- names(n_times)[n_times == length(w)]
  s <- s[as.character(s$id) %in% keep_ids, ]
  s$did <- as.numeric(s$g == cc & s$time >= cc)
  fit <- lm(y ~ did + factor(id) + factor(time), data = s)
  list(
    att = unname(coef(fit)["did"]),
    n_obs = nrow(s),
    n_treated = length(unique(s$id[s$g == cc]))
  )
})

atts <- sapply(res, `[[`, "att")
n_obs <- sapply(res, `[[`, "n_obs")
n_treated <- sapply(res, `[[`, "n_treated")
att_weighted <- sum(atts * n_treated) / sum(n_treated)

out <- list(
  task_id = "broad_cohort_stack",
  platform = "r",
  estimates = list(
    list(term = "att_g3", estimate = as.numeric(atts[1]), se = NULL, n_obs = as.integer(n_obs[1])),
    list(term = "att_g5", estimate = as.numeric(atts[2]), se = NULL, n_obs = as.integer(n_obs[2])),
    list(term = "att_g7", estimate = as.numeric(atts[3]), se = NULL, n_obs = as.integer(n_obs[3])),
    list(term = "att_weighted", estimate = as.numeric(att_weighted), se = NULL, n_obs = as.integer(sum(n_obs)))
  ),
  method_metadata = structure(list(), names = character(0)),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
