d <- read.csv("input.csv")
d <- d[abs(d$score) < 1, ]
w <- 1 - abs(d$score)
right <- d$score >= 0
left <- !right
n <- nrow(d)

infl_side <- function(idx, y) {
  X <- cbind(1, d$score[idx])
  W <- w[idx]
  yy <- y[idx]
  B <- solve(crossprod(X, X * W))
  beta <- B %*% crossprod(X, W * yy)
  e <- as.vector(yy - X %*% beta)
  h <- as.vector(X %*% B[, 1])
  psi <- numeric(n)
  psi[idx] <- W * e * h
  list(a = as.numeric(beta[1]), psi = psi)
}

disc <- function(y) {
  R <- infl_side(which(right), y)
  L <- infl_side(which(left), y)
  list(d = R$a - L$a, psi = R$psi - L$psi)
}

ef <- disc(d$earnings)
pf <- disc(d$participated)

rf <- ef$d
fs <- pf$d
V <- matrix(c(sum(ef$psi^2), sum(ef$psi * pf$psi),
              sum(ef$psi * pf$psi), sum(pf$psi^2)), 2, 2)

tau <- rf / fs
g <- c(1 / fs, -rf / fs^2)
se_tau <- sqrt(as.numeric(t(g) %*% V %*% g))
se_rf <- sqrt(V[1, 1])
se_fs <- sqrt(V[2, 2])

n_right <- as.integer(sum(right))
n_left <- as.integer(sum(left))

est <- function(term, e, s, nobs) {
  sprintf('{"term": "%s", "estimate": %.15g, "se": %s, "n_obs": %d}',
          term, e, if (is.na(s)) "null" else sprintf("%.15g", s), as.integer(nobs))
}

json <- sprintf(
'{
  "task_id": "applied_fuzzy_rd",
  "platform": "r",
  "estimates": [
    %s,
    %s,
    %s
  ],
  "method_metadata": {"estimator": "fuzzy RD, local linear, triangular kernel, bandwidth 1, separate slopes and intercepts per side, delta method for ratio", "vcov": "HC0 (no df correction), joint covariance from same observations"},
  "diagnostics": {"bandwidth": 1, "cutoff": 0, "n_left": %d, "n_right": %d}
}',
  est("treatment_effect", tau, se_tau, n),
  est("reduced_form", rf, se_rf, n),
  est("first_stage", fs, se_fs, n),
  n_left, n_right
)

writeLines(json, "result.json")
