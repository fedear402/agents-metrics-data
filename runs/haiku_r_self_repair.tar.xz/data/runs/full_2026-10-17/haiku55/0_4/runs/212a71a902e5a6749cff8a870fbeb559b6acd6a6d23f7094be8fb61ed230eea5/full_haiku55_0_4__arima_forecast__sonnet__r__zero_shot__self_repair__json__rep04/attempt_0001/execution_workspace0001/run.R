suppressPackageStartupMessages(library(jsonlite))

d <- read.csv("./input.csv")
d <- d[order(d$t), ]
y <- ts(d$y)
n <- length(y)

fit <- arima(y, order = c(1, 1, 1), include.mean = FALSE, method = "ML")
p <- predict(fit, n.ahead = 1)

fc <- as.numeric(p$pred)
se <- as.numeric(p$se)
z <- qnorm(0.975)
lo <- fc - z * se
hi <- fc + z * se

out <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = list(
    list(term = "forecast", estimate = fc, se = se, n_obs = n),
    list(term = "lower_95", estimate = lo, se = NULL, n_obs = n),
    list(term = "upper_95", estimate = hi, se = NULL, n_obs = n)
  ),
  method_metadata = list(
    estimator = "ARIMA(1,1,1) maximum likelihood, no constant or drift (stats::arima, method = ML)",
    vcov = "model-based (inverse Hessian of exact Gaussian likelihood)"
  ),
  diagnostics = list(
    forecast_horizon = 1,
    forecast_time_index = max(d$t) + 1,
    loglik = fit$loglik,
    aic = fit$aic,
    sigma2 = fit$sigma2,
    coefficients = as.list(fit$coef),
    optim_code = fit$code
  )
)

write_json(out, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE, null = "null")
