df <- read.csv("./input.csv", stringsAsFactors = FALSE)
df$group <- factor(df$group)
fit <- aov(y ~ group, data = df)
s <- summary(fit)[[1]]
F_stat <- s[["F value"]][1]
df_num <- s[["Df"]][1]
df_den <- s[["Df"]][2]
p_val <- s[["Pr(>F)"]][1]
n_obs <- nrow(df)
fmt <- function(x) as.numeric(x)
res <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = list(
    list(term = "F", estimate = fmt(F_stat), se = NULL, n_obs = n_obs),
    list(term = "df_num", estimate = fmt(df_num), se = NULL, n_obs = n_obs),
    list(term = "df_den", estimate = fmt(df_den), se = NULL, n_obs = n_obs),
    list(term = "p_value", estimate = fmt(p_val), se = NULL, n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "one-way ANOVA (aov, F-test)",
    vcov = "not applicable"
  ),
  diagnostics = setNames(list(), character(0))
)
if (requireNamespace("jsonlite", quietly = TRUE)) {
  json <- jsonlite::toJSON(res, auto_unbox = TRUE, digits = NA, null = "null", pretty = TRUE)
  writeLines(json, "result.json")
} else {
  stop("jsonlite package is required to write result.json")
}
