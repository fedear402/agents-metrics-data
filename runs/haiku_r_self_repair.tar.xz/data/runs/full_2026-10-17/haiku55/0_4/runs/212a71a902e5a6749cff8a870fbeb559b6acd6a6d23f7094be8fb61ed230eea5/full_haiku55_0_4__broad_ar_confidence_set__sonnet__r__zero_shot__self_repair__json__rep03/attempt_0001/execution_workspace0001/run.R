df <- read.csv("input.csv")
n <- nrow(df)
q <- qf(0.95, 2, n - 4)

Xc <- cbind(1, df$x)
resid_X <- function(M) M - Xc %*% solve(crossprod(Xc), crossprod(Xc, M))

ytil <- as.vector(resid_X(df$y))
etil <- as.vector(resid_X(df$endog))
Zt <- resid_X(cbind(df$z1, df$z2))

B <- solve(crossprod(Zt))
cc <- as.vector(crossprod(Zt, ytil))
dd <- as.vector(crossprod(Zt, etil))

yy <- sum(ytil^2)
ye <- sum(ytil * etil)
ee <- sum(etil^2)
cBc <- drop(t(cc) %*% B %*% cc)
dBc <- drop(t(dd) %*% B %*% cc)
dBd <- drop(t(dd) %*% B %*% dd)

m <- n - 4 + 2 * q
a2 <- m * dBd - 2 * q * ee
a1 <- -2 * m * dBc + 4 * q * ye
a0 <- m * cBc - 2 * q * yy

disc <- a1^2 - 4 * a2 * a0
if (a2 != 0) {
  roots <- (-a1 + c(-1, 1) * sqrt(disc)) / (2 * a2)
} else {
  roots <- -a0 / a1
}
r <- sort(roots)

Fstat <- function(b) {
  d2 <- data.frame(
    yb = df$y - b * df$endog,
    x = df$x,
    z1 = df$z1,
    z2 = df$z2
  )
  rss1 <- sum(resid(lm(yb ~ x + z1 + z2, data = d2))^2)
  rss0 <- sum(resid(lm(yb ~ x, data = d2))^2)
  ((rss0 - rss1) / 2) / (rss1 / (n - 4))
}

zero_in <- as.integer(Fstat(0) <= q)
f1 <- Fstat(1)
unb <- as.integer(a2 < 0)

est <- function(term, val) {
  sprintf('{"term": "%s", "estimate": %s, "se": null, "n_obs": %d}',
          term, format(val, digits = 15), n)
}

json <- paste0(
  '{\n  "task_id": "broad_ar_confidence_set",\n  "platform": "r",\n  "estimates": [\n    ',
  paste(c(
    est("boundary_low", r[1]),
    est("boundary_high", r[2]),
    est("accepts_zero", zero_in),
    est("unbounded", unb),
    est("ar_f_at_one", f1)
  ), collapse = ",\n    "),
  '\n  ],\n  "method_metadata": {"estimator": "Anderson-Rubin test inversion with homoskedastic F test of two excluded instruments", "vcov": "homoskedastic"},\n  "diagnostics": {"critical_value": ',
  format(q, digits = 15),
  ', "df_denominator": ', n - 4,
  ', "quadratic_a2": ', format(a2, digits = 15),
  '}\n}\n'
)

writeLines(json, "result.json")
