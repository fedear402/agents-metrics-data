library(jsonlite)

df <- read.csv("./input.csv", stringsAsFactors = FALSE)
df <- df[order(df$t), ]
train <- df[df$t <= 250, ]
y <- ts(train$y)

fit <- arima(y, order = c(1, 1, 1), include.mean = FALSE, method = "ML")
pred <- predict(fit, n.ahead = 1)

fc <- as.numeric(pred$pred[1])
se <- as.numeric(pred$se[1])
n_obs <- length(y)

out <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = list(
    list(term = "forecast", estimate = fc, se = se, n_obs = n_obs),
    list(term = "lower_95", estimate = fc - 1.96 * se, se = NA_real_, n_obs = n_obs),
    list(term = "upper_95", estimate = fc + 1.96 * se, se = NA_real_, n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "ARIMA(1,1,1) by maximum likelihood, no constant",
    vcov = "ML information matrix"
  ),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "result.json", auto_unbox = TRUE, digits = NA, na = "null", pretty = TRUE)
