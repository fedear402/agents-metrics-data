suppressPackageStartupMessages(library(jsonlite))

df <- read.csv("input.csv", stringsAsFactors = FALSE)

reg <- df[!duplicated(df$region_id), c("region_id", "region_weight", "x", "y")]
reg$e <- reg$region_weight / sum(reg$region_weight)
df$contrib <- df$share * df$shock
z_by_region <- tapply(df$contrib, df$region_id, sum)
reg$z <- as.numeric(z_by_region[as.character(reg$region_id)])

wmean <- function(v, w) sum(w * v) / sum(w)
reg$y0 <- reg$y - wmean(reg$y, reg$e)
reg$x0 <- reg$x - wmean(reg$x, reg$e)
reg$z0 <- reg$z - wmean(reg$z, reg$e)

effect_reg <- sum(reg$e * reg$z0 * reg$y0) / sum(reg$e * reg$z0 * reg$x0)
first_stage_reg <- sum(reg$e * reg$z0 * reg$x0) / sum(reg$e * reg$z0^2)

df$e <- reg$e[match(df$region_id, reg$region_id)]
df$y0 <- reg$y0[match(df$region_id, reg$region_id)]
df$x0 <- reg$x0[match(df$region_id, reg$region_id)]
df$z0 <- reg$z0[match(df$region_id, reg$region_id)]
df$w <- df$e * df$share

ind <- sort(unique(df$industry_id))
s <- as.numeric(tapply(df$w, df$industry_id, sum)[as.character(ind)])
shock_n <- as.numeric(tapply(df$shock, df$industry_id, function(v) v[1])[as.character(ind)])

agg <- function(v) {
  num <- tapply(df$w * v, df$industry_id, sum)
  as.numeric(num[as.character(ind)]) / s
}
ybar <- agg(df$y0)
xbar <- agg(df$x0)
zbar <- agg(df$z0)

shock_iv <- function(dep, endo, inst, w) {
  X <- cbind(1, endo)
  Z <- cbind(1, inst)
  A <- t(Z) %*% (w * X)
  beta <- solve(A, t(Z) %*% (w * dep))
  u <- drop(dep - X %*% beta)
  Ainv <- solve(A)
  scores <- Z * (w * u)
  N <- length(dep)
  V <- N / (N - 2) * Ainv %*% crossprod(scores) %*% t(Ainv)
  c(slope = unname(beta[2]), se = unname(sqrt(V[2, 2])))
}

effect_iv <- shock_iv(ybar, xbar, shock_n, s)
fs_iv <- shock_iv(xbar, zbar, shock_n, s)

N <- length(ind)
effective_shocks <- 1 / sum(s^2)

row <- function(term, estimate, se, n_obs) {
  list(term = term,
       estimate = unname(as.numeric(estimate)),
       se = if (is.null(se)) NULL else unname(as.numeric(se)),
       n_obs = as.integer(n_obs))
}

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    row("effect", effect_reg, effect_iv["se"], N),
    row("first_stage", first_stage_reg, fs_iv["se"], N),
    row("effective_shocks", effective_shocks, NULL, N)
  ),
  method_metadata = list(
    estimator = "Weighted 2SLS of y on intercept and x instrumented by shift-share z, with shock-level HC1 IV inference",
    vcov = "Shock-level heteroskedasticity-robust HC1 (N/(N-2)), structural residuals, analytic weights, no clustering"
  ),
  diagnostics = setNames(list(), character(0))
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
