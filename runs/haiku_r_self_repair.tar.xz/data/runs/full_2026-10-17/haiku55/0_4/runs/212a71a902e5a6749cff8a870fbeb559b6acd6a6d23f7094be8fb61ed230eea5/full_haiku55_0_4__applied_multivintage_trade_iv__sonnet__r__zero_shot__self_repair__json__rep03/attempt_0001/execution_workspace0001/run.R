library(jsonlite)

crosswalk <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
trade <- read.csv("trade.csv", stringsAsFactors = FALSE)
areas <- read.csv("areas.csv", stringsAsFactors = FALSE)
employment <- read.csv("employment.csv", stringsAsFactors = FALSE)
outcomes <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

crosswalk$code <- as.character(crosswalk$code)
crosswalk$industry <- as.character(crosswalk$industry)
trade$code <- as.character(trade$code)
trade$period <- as.numeric(trade$period)
trade <- merge(trade, crosswalk, by = "code")

areas$area <- as.character(areas$area)
areas$period <- as.numeric(areas$period)
employment$area <- as.character(employment$area)
employment$period <- as.numeric(employment$period)
employment$industry <- as.character(employment$industry)
outcomes$area <- as.character(outcomes$area)
outcomes$period <- as.numeric(outcomes$period)

industries <- sort(unique(crosswalk$industry))
ap <- unique(areas[, c("area", "period")])
vints <- c("base", "early")

grid <- do.call(rbind, lapply(vints, function(v) cbind(ap, vintage = v)))
grid <- do.call(rbind, lapply(industries, function(j) cbind(grid, industry = j)))

emp_full <- merge(grid,
                  employment[, c("area", "period", "vintage", "industry", "employment")],
                  by = c("area", "period", "vintage", "industry"), all.x = TRUE)
emp_full$employment[is.na(emp_full$employment)] <- 0
emp_full <- merge(emp_full, areas[, c("area", "period", "vintage", "total_employment")],
                  by = c("area", "period", "vintage"))

tr <- trade[, c("period", "industry", "us_change", "other_change", "price_index", "years")]

exposure <- function(v, chg) {
  e <- emp_full[emp_full$vintage == v, c("area", "period", "industry", "employment", "total_employment")]
  n <- aggregate(employment ~ period + industry, data = e, FUN = sum)
  names(n)[3] <- "nat"
  d <- merge(e, n, by = c("period", "industry"))
  d <- merge(d, tr[, c("period", "industry", chg, "price_index", "years")], by = c("period", "industry"))
  names(d)[names(d) == chg] <- "chg"
  d$term <- (d$employment / d$total_employment) * (d$chg / d$nat) /
    (d$price_index / 100) / 1000 * (10 / d$years)
  out <- aggregate(term ~ area + period, data = d, FUN = sum)
  names(out)[3] <- "value"
  list(values = out, nat = n)
}

xo <- exposure("base", "us_change")
zo <- exposure("early", "other_change")
x <- xo$values
names(x)[3] <- "x"
z <- zo$values
names(z)[3] <- "z"

pop <- areas[areas$vintage == "base", c("area", "period", "population")]

est <- merge(outcomes, x, by = c("area", "period"))
est <- merge(est, z, by = c("area", "period"))
est <- merge(est, pop, by = c("area", "period"))

y <- est$change_pp
X <- cbind(1, est$period, est$control, est$x)
Z <- cbind(1, est$period, est$control, est$z)
w <- est$population

A <- crossprod(Z, w * Z)
ZX <- crossprod(Z, w * X)
Zy <- crossprod(Z, w * y)
Ainv <- solve(A)
beta <- solve(t(ZX) %*% Ainv %*% ZX, t(ZX) %*% Ainv %*% Zy)

nobs <- as.integer(nrow(est))
get_val <- function(df, col, a, p) {
  df[[col]][df$area == as.character(a) & df$period == p]
}

iv_slope <- unname(beta[4, 1])
exposure_area0_period0 <- get_val(est, "x", 0, 0)
exposure_area0_period1 <- get_val(est, "x", 0, 1)
instrument_area0_period0 <- get_val(est, "z", 0, 0)

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = list(
    list(term = "iv_slope", estimate = iv_slope, se = NULL, n_obs = nobs),
    list(term = "exposure_area0_period0", estimate = exposure_area0_period0, se = NULL, n_obs = nobs),
    list(term = "exposure_area0_period1", estimate = exposure_area0_period1, se = NULL, n_obs = nobs),
    list(term = "instrument_area0_period0", estimate = instrument_area0_period0, se = NULL, n_obs = nobs)
  ),
  method_metadata = list(
    method = "weighted_2sls",
    outcome = "change_pp",
    endogenous = "x",
    instrument = "z",
    exogenous = c("intercept", "period", "control"),
    weight = "base_vintage_population",
    denominator = "national industry employment summed across supplied areas within period and vintage",
    exposure_units = "thousands of real dollars per worker per decade",
    n_obs = nobs
  ),
  diagnostics = list(
    n_obs = nobs,
    n_industries = as.integer(length(industries)),
    instrument_rank = as.integer(qr(Z)$rank),
    min_national_base_employment = min(xo$nat$nat),
    all_national_base_employment_positive = all(xo$nat$nat > 0),
    all_national_early_employment_positive = all(zo$nat$nat > 0)
  )
)

write_json(result, "result.json", auto_unbox = TRUE, digits = NA, null = "null", na = "null", pretty = TRUE)
