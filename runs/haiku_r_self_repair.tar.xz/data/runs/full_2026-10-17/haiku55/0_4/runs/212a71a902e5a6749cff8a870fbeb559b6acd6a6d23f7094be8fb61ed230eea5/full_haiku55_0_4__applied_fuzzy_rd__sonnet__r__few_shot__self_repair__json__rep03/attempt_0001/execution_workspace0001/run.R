library(jsonlite)

d <- read.csv("input.csv")
d <- d[abs(d$score) < 1, ]
w <- 1 - abs(d$score)
n <- nrow(d)

right <- as.numeric(d$score >= 0)
X <- cbind(1, right, d$score * (1 - right), d$score * right)
XtWX_inv <- solve(crossprod(X, w * X))

fit_one <- function(y) {
  b <- XtWX_inv %*% crossprod(X, w * y)
  e <- y - X %*% b
  list(coef = drop(b), e = drop(e))
}

fy <- fit_one(d$earnings)
fd <- fit_one(d$participated)

contrast <- c(0, 1, 0, 0)
jump_y <- sum(contrast * fy$coef)
jump_d <- sum(contrast * fd$coef)

loading <- w * drop(X %*% XtWX_inv %*% contrast)
infl_y <- loading * fy$e
infl_d <- loading * fd$e
joint <- crossprod(cbind(infl_y, infl_d))

se_y <- sqrt(joint[1, 1])
se_d <- sqrt(joint[2, 2])
cov_yd <- joint[1, 2]

tau <- jump_y / jump_d
grad <- c(1 / jump_d, -jump_y / jump_d^2)
se_tau <- sqrt(drop(t(grad) %*% joint %*% grad))

out <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = unname(as.numeric(tau)),
         se = unname(as.numeric(se_tau)), n_obs = as.integer(n)),
    list(term = "reduced_form", estimate = unname(as.numeric(jump_y)),
         se = unname(as.numeric(se_y)), n_obs = as.integer(n)),
    list(term = "first_stage", estimate = unname(as.numeric(jump_d)),
         se = unname(as.numeric(se_d)), n_obs = as.integer(n))
  ),
  method_metadata = list(
    estimator = "fuzzy RD, local linear, triangular kernel, bandwidth 1, separate slopes by side",
    vcov = "HC0 sandwich, no degrees-of-freedom correction, delta method for ratio"
  ),
  diagnostics = setNames(list(), character(0))
)

write_json(out, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
