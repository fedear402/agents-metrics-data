library(jsonlite)

crosswalk <- read.csv("crosswalk.csv", stringsAsFactors = FALSE, strip.white = TRUE)
trade <- read.csv("trade.csv", stringsAsFactors = FALSE, strip.white = TRUE)
areas <- read.csv("areas.csv", stringsAsFactors = FALSE, strip.white = TRUE)
employment <- read.csv("employment.csv", stringsAsFactors = FALSE, strip.white = TRUE)
outcomes <- read.csv("outcomes.csv", stringsAsFactors = FALSE, strip.white = TRUE)

trade <- merge(trade, crosswalk, by = "code")
industries <- sort(unique(crosswalk$industry))

emp_val <- function(a, p, v, j) {
  r <- employment$employment[employment$area == a & employment$period == p &
                             employment$vintage == v & employment$industry == j]
  if (length(r) == 0) 0 else sum(r)
}

nat_val <- function(p, v, j) {
  sum(employment$employment[employment$period == p & employment$vintage == v &
                            employment$industry == j])
}

tot_val <- function(a, p, v) {
  areas$total_employment[areas$area == a & areas$period == p & areas$vintage == v]
}

exposure_fn <- function(vint, chg) {
  vapply(seq_len(nrow(outcomes)), function(i) {
    a <- outcomes$area[i]
    p <- outcomes$period[i]
    tot <- tot_val(a, p, vint)
    tr_p <- trade[trade$period == p, ]
    sum(vapply(seq_len(nrow(tr_p)), function(k) {
      j <- tr_p$industry[k]
      share <- emp_val(a, p, vint, j) / tot
      share * (tr_p[[chg]][k] / nat_val(p, vint, j)) /
        (tr_p$price_index[k] / 100) / 1000 * (10 / tr_p$years[k])
    }, numeric(1)))
  }, numeric(1))
}

x <- exposure_fn("base", "us_change")
z <- exposure_fn("early", "other_change")

base_areas <- areas[areas$vintage == "base", ]
pop <- base_areas$population[match(paste(outcomes$area, outcomes$period),
                                   paste(base_areas$area, base_areas$period))]

y <- outcomes$change_pp
period_num <- as.numeric(outcomes$period)
control <- outcomes$control
X <- cbind(1, period_num, control, x)
Z <- cbind(1, period_num, control, z)
w <- pop

XZ <- t(X) %*% (w * Z)
ZX <- t(Z) %*% (w * X)
Zy <- t(Z) %*% (w * y)
ZWZ_inv <- solve(t(Z) %*% (w * Z))
beta <- solve(XZ %*% ZWZ_inv %*% ZX, XZ %*% ZWZ_inv %*% Zy)

n_obs <- as.integer(nrow(outcomes))
idx00 <- which(outcomes$area == 0 & outcomes$period == 0)
idx01 <- which(outcomes$area == 0 & outcomes$period == 1)

estimates <- list(
  list(term = "iv_slope", estimate = unname(beta[4, 1]), se = NA_real_, n_obs = n_obs),
  list(term = "exposure_area0_period0", estimate = unname(x[idx00]), se = NA_real_, n_obs = n_obs),
  list(term = "exposure_area0_period1", estimate = unname(x[idx01]), se = NA_real_, n_obs = n_obs),
  list(term = "instrument_area0_period0", estimate = unname(z[idx00]), se = NA_real_, n_obs = n_obs)
)

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    method = "weighted two-stage least squares",
    outcome = "change_pp",
    endogenous = "x",
    instrument = "z",
    exogenous = c("intercept", "period", "control"),
    weights = "base-vintage population"
  ),
  diagnostics = list(
    n_obs = n_obs,
    n_areas = as.integer(length(unique(outcomes$area))),
    n_periods = as.integer(length(unique(outcomes$period))),
    n_industries = as.integer(length(industries))
  )
)

write_json(result, "result.json", auto_unbox = TRUE, digits = NA, na = "null", pretty = TRUE)
