df <- read.csv("input.csv")
n <- nrow(df)
crit <- qf(0.95, 2, n - 4)

Xr <- cbind(1, df$x)
Xu <- cbind(1, df$x, df$z1, df$z2)

rss <- function(b, X) {
  yt <- df$y - b * df$endog
  fit <- lm.fit(X, yt)
  sum(fit$residuals^2)
}

ar_F <- function(b) {
  rr <- rss(b, Xr)
  ru <- rss(b, Xu)
  ((rr - ru) / 2) / (ru / (n - 4))
}

# g(b) = (n-4)/2 * (RSS_r - RSS_u) - crit * RSS_u is an exact quadratic in b
g <- function(b) {
  rr <- rss(b, Xr)
  ru <- rss(b, Xu)
  (n - 4) / 2 * (rr - ru) - crit * ru
}

g0 <- g(0)
g1 <- g(1)
gm1 <- g(-1)
C <- g0
A <- (g1 + gm1) / 2 - C
B <- (g1 - gm1) / 2

disc <- B^2 - 4 * A * C
if (disc >= 0 && A != 0) {
  roots <- sort(c((-B - sqrt(disc)) / (2 * A), (-B + sqrt(disc)) / (2 * A)))
} else {
  roots <- c(NA_real_, NA_real_)
}

boundary_low <- roots[1]
boundary_high <- roots[2]
accepts_zero <- as.numeric(g0 <= 0)
unbounded <- as.numeric(A <= 0)
ar_f_at_one <- ar_F(1)

fmt <- function(x) if (is.na(x)) "null" else sprintf("%.10g", x)

json <- sprintf(
'{
  "task_id": "broad_ar_confidence_set",
  "platform": "r",
  "estimates": [
    {"term": "boundary_low", "estimate": %s, "se": null, "n_obs": %d},
    {"term": "boundary_high", "estimate": %s, "se": null, "n_obs": %d},
    {"term": "accepts_zero", "estimate": %s, "se": null, "n_obs": %d},
    {"term": "unbounded", "estimate": %s, "se": null, "n_obs": %d},
    {"term": "ar_f_at_one", "estimate": %s, "se": null, "n_obs": %d}
  ],
  "method_metadata": {"estimator": "Anderson-Rubin test inversion (homoskedastic joint F of excluded instruments)", "vcov": "homoskedastic"},
  "diagnostics": {}
}',
fmt(boundary_low), n,
fmt(boundary_high), n,
fmt(accepts_zero), n,
fmt(unbounded), n,
fmt(ar_f_at_one), n
)

writeLines(json, "result.json")
