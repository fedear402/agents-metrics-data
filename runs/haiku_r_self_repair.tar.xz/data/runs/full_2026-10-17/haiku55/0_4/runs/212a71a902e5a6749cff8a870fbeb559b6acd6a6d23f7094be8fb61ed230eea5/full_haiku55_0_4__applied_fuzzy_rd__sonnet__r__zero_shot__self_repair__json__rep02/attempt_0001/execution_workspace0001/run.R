library(jsonlite)

df <- read.csv("input.csv")
h <- 1
d <- df[abs(df$score) < h, ]
x <- d$score
y <- d$earnings
p <- d$participated
w <- 1 - abs(x)
R <- as.numeric(x >= 0)
L <- 1 - R
Z <- cbind(R, R * x, L, L * x)
n <- nrow(d)

Bread <- solve(t(Z) %*% (w * Z))

beta_y <- Bread %*% t(Z) %*% (w * y)
beta_d <- Bread %*% t(Z) %*% (w * p)
e_y <- as.vector(y - Z %*% beta_y)
e_d <- as.vector(p - Z %*% beta_d)

psi_y <- Z * (w * e_y)
psi_d <- Z * (w * e_d)

IF_y <- psi_y %*% t(Bread)
IF_d <- psi_d %*% t(Bread)
IF <- cbind(IF_y, IF_d)
V <- t(IF) %*% IF

theta <- c(beta_y, beta_d)
rf <- theta[1] - theta[3]
fs <- theta[5] - theta[7]

Lrf <- c(1, 0, -1, 0, 0, 0, 0, 0)
Lfs <- c(0, 0, 0, 0, 1, 0, -1, 0)

v_rf <- as.numeric(t(Lrf) %*% V %*% Lrf)
v_fs <- as.numeric(t(Lfs) %*% V %*% Lfs)
c_rf_fs <- as.numeric(t(Lrf) %*% V %*% Lfs)
S <- matrix(c(v_rf, c_rf_fs, c_rf_fs, v_fs), 2, 2)

te <- rf / fs
g <- c(1 / fs, -rf / fs^2)
v_te <- as.numeric(t(g) %*% S %*% g)

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = te, se = sqrt(v_te), n_obs = as.integer(n)),
    list(term = "reduced_form", estimate = rf, se = sqrt(v_rf), n_obs = as.integer(n)),
    list(term = "first_stage", estimate = fs, se = sqrt(v_fs), n_obs = as.integer(n))
  ),
  method_metadata = list(
    estimator = "Fuzzy RD, local linear WLS with triangular kernel, cutoff 0, bandwidth 1, separate slopes and intercepts per side; treatment effect as ratio of discontinuities via delta method",
    vcov = "HC0 heteroskedasticity-robust sandwich (no df correction), joint covariance across reduced form and first stage, delta method for ratio"
  ),
  diagnostics = list(
    bandwidth = h,
    n_right = as.integer(sum(R)),
    n_left = as.integer(sum(L))
  )
)

write(toJSON(result, auto_unbox = TRUE, digits = NA, pretty = TRUE), "result.json")
