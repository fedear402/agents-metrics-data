d <- read.csv("input.csv", stringsAsFactors = FALSE)
d$id <- as.character(d$id)
d$time <- as.numeric(d$time)
d$g <- as.numeric(d$g)
d$y <- as.numeric(d$y)

cohorts <- c(3, 5, 7)
fits <- lapply(cohorts, function(cc) {
  w <- cc + (-2:2)
  x <- d[d$time %in% w & (d$g == cc | d$g == 0 | d$g > cc + 2), ]
  n_times <- tapply(x$time, x$id, function(t) length(unique(t)))
  keep <- names(n_times)[n_times == length(w)]
  x <- x[x$id %in% keep, ]
  x$did <- as.numeric(x$g == cc & x$time >= cc)
  fit <- lm(y ~ did + factor(id) + factor(time), data = x)
  list(
    att = unname(coef(fit)["did"]),
    n_obs = nrow(x),
    n_treated = length(unique(x$id[x$g == cc]))
  )
})
names(fits) <- paste0("att_g", cohorts)

weights <- vapply(fits, function(f) f$n_treated, numeric(1))
atts <- vapply(fits, function(f) f$att, numeric(1))
n_rows <- vapply(fits, function(f) f$n_obs, numeric(1))
att_weighted <- sum(weights * atts) / sum(weights)

out <- list(
  task_id = "broad_cohort_stack",
  platform = "r",
  estimates = list(
    list(term = "att_g3", estimate = atts[["att_g3"]], se = NULL, n_obs = n_rows[["att_g3"]]),
    list(term = "att_g5", estimate = atts[["att_g5"]], se = NULL, n_obs = n_rows[["att_g5"]]),
    list(term = "att_g7", estimate = atts[["att_g7"]], se = NULL, n_obs = n_rows[["att_g7"]]),
    list(term = "att_weighted", estimate = att_weighted, se = NULL, n_obs = sum(n_rows))
  ),
  method_metadata = setNames(list(), character(0)),
  diagnostics = setNames(list(), character(0))
)

jsonlite::write_json(out, "result.json", auto_unbox = TRUE, null = "null", digits = 16)
