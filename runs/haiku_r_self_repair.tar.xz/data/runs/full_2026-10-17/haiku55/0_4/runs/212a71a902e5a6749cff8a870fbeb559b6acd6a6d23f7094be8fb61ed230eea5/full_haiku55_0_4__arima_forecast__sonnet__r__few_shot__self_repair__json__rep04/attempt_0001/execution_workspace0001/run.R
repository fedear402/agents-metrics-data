library(jsonlite)

df <- read.csv("./input.csv")
df <- df[order(df$t), ]
y <- as.numeric(df$y)
n_obs <- sum(!is.na(y))

fit <- arima(y, order = c(1, 1, 1), include.mean = FALSE, method = "ML")
pr <- predict(fit, n.ahead = 1)

fc <- as.numeric(pr$pred[1])
fc_se <- as.numeric(pr$se[1])
z <- qnorm(0.975)

out <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = list(
    list(term = "forecast", estimate = fc, se = fc_se, n_obs = n_obs),
    list(term = "lower_95", estimate = fc - z * fc_se, se = NA_real_, n_obs = n_obs),
    list(term = "upper_95", estimate = fc + z * fc_se, se = NA_real_, n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "ARIMA(1,1,1) by maximum likelihood, no constant",
    vcov = "classical"
  ),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "result.json", auto_unbox = TRUE, digits = NA, na = "null", pretty = TRUE)
