suppressPackageStartupMessages({
  if (!requireNamespace("jsonlite", quietly = TRUE)) install.packages("jsonlite", repos = "https://cloud.r-project.org")
})

df <- read.csv("./input.csv", stringsAsFactors = FALSE)
y <- as.numeric(df$y)
n_obs <- length(y)

fit <- arima(y, order = c(1, 1, 1), include.mean = FALSE, method = "ML")

pred <- predict(fit, n.ahead = 1)
fc <- as.numeric(pred$pred[1])
fc_se <- as.numeric(pred$se[1])
z <- qnorm(0.975)
lower <- fc - z * fc_se
upper <- fc + z * fc_se

target_t <- 251
if ("t" %in% names(df)) {
  last_t <- max(df$t, na.rm = TRUE)
} else {
  last_t <- n_obs
}

result <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = list(
    list(term = "forecast", estimate = fc, se = fc_se, n_obs = n_obs),
    list(term = "lower_95", estimate = lower, se = NULL, n_obs = n_obs),
    list(term = "upper_95", estimate = upper, se = NULL, n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "ARIMA(1,1,1) maximum likelihood, no constant/drift (stats::arima)",
    vcov = "model-based (inverse observed information from arima)"
  ),
  diagnostics = list(
    target_t = target_t,
    last_observed_t = last_t,
    horizon = 1,
    aic = fit$aic,
    loglik = as.numeric(fit$loglik),
    ar1 = unname(coef(fit)["ar1"]),
    ma1 = unname(coef(fit)["ma1"]),
    sigma2 = fit$sigma2,
    converged = fit$code == 0
  )
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE)
