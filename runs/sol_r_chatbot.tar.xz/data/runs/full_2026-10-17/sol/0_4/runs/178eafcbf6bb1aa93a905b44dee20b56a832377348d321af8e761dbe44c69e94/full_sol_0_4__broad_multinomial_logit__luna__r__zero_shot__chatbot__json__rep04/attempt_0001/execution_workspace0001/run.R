d <- read.csv("input.csv")
stopifnot(nrow(d) == 480L, all(d$y %in% 0:2))
stopifnot(!anyNA(d[, c("y", "x", "z")]))

X <- cbind(1, d$x, d$z)
n <- nrow(X)

objective <- function(theta) {
  B <- matrix(theta, nrow = 3L)
  eta <- X %*% B
  m <- pmax(0, eta[, 1], eta[, 2])
  log_denom <- m + log(exp(-m) + exp(eta[, 1] - m) + exp(eta[, 2] - m))
  -sum((d$y == 1) * eta[, 1] + (d$y == 2) * eta[, 2] - log_denom)
}

fit <- optim(rep(0, 6L), objective, method = "BFGS",
             control = list(reltol = 1e-12, maxit = 10000L))
stopifnot(fit$convergence == 0L)

B <- matrix(fit$par, nrow = 3L)
eta <- X %*% B
m <- pmax(0, eta[, 1], eta[, 2])
denom <- exp(-m) + exp(eta[, 1] - m) + exp(eta[, 2] - m)
p1 <- exp(eta[, 1] - m) / denom
p2 <- exp(eta[, 2] - m) / denom

# The negative log-likelihood Hessian is the observed information matrix.
H <- matrix(0, 6L, 6L)
H[1:3, 1:3] <- crossprod(X, X * (p1 * (1 - p1)))
H[4:6, 4:6] <- crossprod(X, X * (p2 * (1 - p2)))
H[1:3, 4:6] <- -crossprod(X, X * (p1 * p2))
H[4:6, 1:3] <- t(H[1:3, 4:6])
se <- sqrt(diag(solve(H)))

prob_cat2_zero <- exp(B[1, 2] - max(0, B[1, 1], B[1, 2])) /
  sum(exp(c(0, B[1, 1], B[1, 2]) - max(0, B[1, 1], B[1, 2])))

num <- function(value) sprintf("%.15g", value)
row <- function(term, estimate, standard_error) {
  se_text <- if (is.null(standard_error)) "null" else num(standard_error)
  sprintf(
    '{"term":"%s","estimate":%s,"se":%s,"n_obs":%d}',
    term, num(estimate), se_text, n
  )
}

rows <- c(
  row("x_cat1", B[2, 1], se[2]),
  row("z_cat1", B[3, 1], se[3]),
  row("x_cat2", B[2, 2], se[5]),
  row("z_cat2", B[3, 2], se[6]),
  row("prob_cat2_zero", prob_cat2_zero, NULL)
)

output <- paste0(
  '{"task_id":"broad_multinomial_logit",',
  '"platform":"r",',
  '"estimates":[', paste(rows, collapse = ","), '],',
  '"method_metadata":{"estimator":"multinomial logit maximum likelihood",',
  '"vcov":"inverse observed information"},',
  '"diagnostics":{}}'
)

writeLines(output, "result.json")
