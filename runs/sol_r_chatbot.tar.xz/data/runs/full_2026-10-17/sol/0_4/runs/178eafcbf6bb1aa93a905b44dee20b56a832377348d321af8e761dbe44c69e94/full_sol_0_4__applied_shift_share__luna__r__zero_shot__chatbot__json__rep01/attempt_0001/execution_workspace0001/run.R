d <- read.csv("input.csv")

regions <- unique(d$region_id)
industries <- unique(d$industry_id)
region_row <- match(regions, d$region_id)
industry_row <- match(industries, d$industry_id)

e <- d$region_weight[region_row]
e <- e / sum(e)

regional <- data.frame(
  region_id = regions,
  e = e,
  x = d$x[region_row],
  y = d$y[region_row]
)

ri <- match(d$region_id, regions)
ni <- match(d$industry_id, industries)
shock <- d$shock[industry_row]

regional$z <- as.vector(rowsum(d$share * d$shock, ri, reorder = TRUE))

for (v in c("x", "y", "z")) {
  regional[[paste0(v, "0")]] <-
    regional[[v]] - sum(regional$e * regional[[v]])
}

exposure <- d$share * regional$e[ri]
s <- as.vector(rowsum(exposure, ni, reorder = TRUE))
N <- length(industries)

aggregate_residual <- function(v) {
  as.vector(rowsum(exposure * regional[[v]][ri], ni, reorder = TRUE)) / s
}

xbar <- aggregate_residual("x0")
ybar <- aggregate_residual("y0")
zbar <- aggregate_residual("z0")

shock_iv <- function(response, regressor) {
  X <- cbind(1, regressor)
  Z <- cbind(1, shock)
  WZ <- sweep(Z, 1, s, "*")
  A <- crossprod(X, WZ)
  beta <- solve(A, crossprod(WZ, response))
  u <- as.vector(response - X %*% beta)

  score <- sweep(WZ, 1, u, "*")
  meat <- crossprod(score)
  Ainv <- solve(A)
  covariance <- (N / (N - 2)) * Ainv %*% meat %*% t(Ainv)

  c(estimate = unname(beta[2]), se = sqrt(covariance[2, 2]))
}

effect <- shock_iv(ybar, xbar)
first_stage <- shock_iv(xbar, zbar)
effective_shocks <- 1 / sum(s^2)

num <- function(value) sprintf("%.17g", value)
result <- sprintf(
  paste0(
    '{"task_id":"applied_shift_share","platform":"r","estimates":[',
    '{"term":"effect","estimate":%s,"se":%s,"n_obs":%d},',
    '{"term":"first_stage","estimate":%s,"se":%s,"n_obs":%d},',
    '{"term":"effective_shocks","estimate":%s,"se":null,"n_obs":%d}',
    '],"method_metadata":{"estimator":"weighted shock-level IV",',
    '"vcov":"shock-level HC1, N/(N-2)"},"diagnostics":{}}'
  ),
  num(effect["estimate"]), num(effect["se"]), N,
  num(first_stage["estimate"]), num(first_stage["se"]), N,
  num(effective_shocks), N
)

writeLines(result, "result.json")
