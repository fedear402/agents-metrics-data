library(jsonlite)

d <- read.csv("input.csv", stringsAsFactors = FALSE)

regions <- d[!duplicated(d$region_id), ]
industries <- d[!duplicated(d$industry_id), ]

shares <- xtabs(share ~ region_id + industry_id, data = d)
shares <- as.matrix(shares)[
  match(as.character(regions$region_id), rownames(shares)),
  match(as.character(industries$industry_id), colnames(shares)),
  drop = FALSE
]

e <- regions$region_weight / sum(regions$region_weight)
shock <- industries$shock
z <- drop(shares %*% shock)

regional <- cbind(y = regions$y, x = regions$x, z = z)
centered <- sweep(regional, 2, drop(crossprod(e, regional)))
mass <- drop(crossprod(e, shares))
aggregated <- crossprod(shares, e * centered) / mass
n_industries <- length(shock)

shock_iv <- function(dependent, endogenous) {
  regressors <- cbind(1, endogenous)
  instruments <- cbind(1, shock)

  cross <- crossprod(instruments, mass * regressors)
  coefficients <- solve(cross, crossprod(instruments, mass * dependent))
  residuals <- drop(dependent - regressors %*% coefficients)
  scores <- instruments * (mass * residuals)
  inverse <- solve(cross)

  covariance <- n_industries / (n_industries - 2) *
    inverse %*% crossprod(scores) %*% t(inverse)

  c(estimate = unname(coefficients[2]),
    se = sqrt(unname(covariance[2, 2])))
}

effect <- shock_iv(aggregated[, "y"], aggregated[, "x"])
first_stage <- shock_iv(aggregated[, "x"], aggregated[, "z"])

row <- function(term, estimate, se) {
  list(term = term, estimate = unname(estimate),
       se = if (is.null(se)) NULL else unname(se),
       n_obs = as.integer(n_industries))
}

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    row("effect", effect["estimate"], effect["se"]),
    row("first_stage", first_stage["estimate"], first_stage["se"]),
    row("effective_shocks", 1 / sum(mass^2), NULL)
  ),
  method_metadata = list(
    estimator = "Weighted regional 2SLS via shock-level IV",
    vcov = "Shock-level heteroskedasticity-robust HC1, N/(N-2)"
  ),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE,
           null = "null", digits = 16, pretty = TRUE)
