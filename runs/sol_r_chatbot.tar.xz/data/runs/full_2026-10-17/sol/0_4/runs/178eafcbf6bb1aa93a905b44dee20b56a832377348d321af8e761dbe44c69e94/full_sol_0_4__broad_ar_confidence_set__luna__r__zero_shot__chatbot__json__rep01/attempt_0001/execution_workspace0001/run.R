d <- read.csv("input.csv")
n <- nrow(d)
stopifnot(n == 240L, all(c("y", "endog", "x", "z1", "z2") %in% names(d)))

Xr <- cbind(1, d$x)
Xu <- cbind(1, d$x, d$z1, d$z2)
stopifnot(qr(Xr)$rank == 2L, qr(Xu)$rank == 4L)

ry <- qr.resid(qr(Xr), d$y)
re <- qr.resid(qr(Xr), d$endog)
uy <- qr.resid(qr(Xu), d$y)
ue <- qr.resid(qr(Xu), d$endog)

rss_coeff <- function(a, b) {
  c(sum(a^2), -2 * sum(a * b), sum(b^2))
}

restricted <- rss_coeff(ry, re)
unrestricted <- rss_coeff(uy, ue)
df2 <- n - 4L
critical <- qf(0.95, df1 = 2, df2 = df2)
q <- restricted - (1 + 2 * critical / df2) * unrestricted

disc <- q[2]^2 - 4 * q[3] * q[1]
stopifnot(q[3] != 0, disc > 0)
roots <- sort(c(
  (-q[2] - sqrt(disc)) / (2 * q[3]),
  (-q[2] + sqrt(disc)) / (2 * q[3])
))

accepts_zero <- as.numeric(q[1] <= 0)
unbounded <- as.numeric(q[3] < 0)
rss_r_one <- sum((ry - re)^2)
rss_u_one <- sum((uy - ue)^2)
ar_f_at_one <- ((rss_r_one - rss_u_one) / 2) / (rss_u_one / df2)

estimate_row <- function(term, value) {
  list(term = term, estimate = as.numeric(value), se = NULL, n_obs = n)
}

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = list(
    estimate_row("boundary_low", roots[1]),
    estimate_row("boundary_high", roots[2]),
    estimate_row("accepts_zero", accepts_zero),
    estimate_row("unbounded", unbounded),
    estimate_row("ar_f_at_one", ar_f_at_one)
  ),
  method_metadata = list(
    estimator = "Anderson-Rubin confidence set by exact quadratic inversion",
    vcov = "Conventional homoskedastic F test"
  ),
  diagnostics = list()
)

jsonlite::write_json(
  result, "result.json", auto_unbox = TRUE, null = "null", digits = 16
)
