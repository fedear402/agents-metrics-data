library(jsonlite)

data <- read.csv("./input.csv")
data <- data[complete.cases(data[, c("group", "y")]), ]
data$group <- factor(data$group)

fit <- aov(y ~ group, data = data)
anova_table <- summary(fit)[[1]]
n_obs <- nrow(data)

make_row <- function(term, value) {
  list(term = term, estimate = unname(as.numeric(value)), se = NA_real_,
       n_obs = n_obs)
}

out <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = list(
    make_row("F", anova_table[["F value"]][1]),
    make_row("df_num", anova_table[["Df"]][1]),
    make_row("df_den", anova_table[["Df"]][2]),
    make_row("p_value", anova_table[["Pr(>F)"]][1])
  ),
  method_metadata = list(
    estimator = "One-way analysis of variance",
    vcov = "Classical ANOVA"
  ),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "result.json", auto_unbox = TRUE, digits = NA, na = "null")
