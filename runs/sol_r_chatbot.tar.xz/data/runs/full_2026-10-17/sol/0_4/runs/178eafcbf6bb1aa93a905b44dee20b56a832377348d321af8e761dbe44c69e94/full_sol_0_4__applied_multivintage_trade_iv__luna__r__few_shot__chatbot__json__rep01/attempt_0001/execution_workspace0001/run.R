crosswalk <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
trade <- read.csv("trade.csv", stringsAsFactors = FALSE)
areas <- read.csv("areas.csv", stringsAsFactors = FALSE)
employment <- read.csv("employment.csv", stringsAsFactors = FALSE)
outcomes <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

trade <- merge(trade, crosswalk, by = "code", sort = FALSE)

national <- aggregate(
  employment ~ period + vintage + industry,
  data = employment,
  FUN = sum
)
names(national)[names(national) == "employment"] <- "national_employment"

area_industry <- merge(
  areas, unique(trade[c("period", "industry")]),
  by = "period", sort = FALSE
)
area_industry <- merge(
  area_industry, employment,
  by = c("area", "period", "vintage", "industry"),
  all.x = TRUE, sort = FALSE
)
area_industry$employment[is.na(area_industry$employment)] <- 0

area_industry <- merge(
  area_industry, national,
  by = c("period", "vintage", "industry"), sort = FALSE
)
area_industry <- merge(
  area_industry,
  trade[c("period", "industry", "us_change", "other_change",
          "price_index", "years")],
  by = c("period", "industry"), sort = FALSE
)

area_industry$trade_change <- ifelse(
  area_industry$vintage == "base",
  area_industry$us_change,
  area_industry$other_change
)
area_industry$contribution <-
  (area_industry$employment / area_industry$total_employment) *
  (area_industry$trade_change / area_industry$national_employment) /
  (area_industry$price_index / 100) / 1000 *
  (10 / area_industry$years)

exposures <- aggregate(
  contribution ~ area + period + vintage,
  data = area_industry,
  FUN = sum
)
base_exposure <- subset(exposures, vintage == "base",
                        select = c(area, period, contribution))
early_exposure <- subset(exposures, vintage == "early",
                         select = c(area, period, contribution))
names(base_exposure)[3] <- "x"
names(early_exposure)[3] <- "z"

sample <- merge(outcomes, base_exposure,
                by = c("area", "period"), sort = FALSE)
sample <- merge(sample, early_exposure,
                by = c("area", "period"), sort = FALSE)
base_areas <- subset(areas, vintage == "base",
                     select = c(area, period, population))
sample <- merge(sample, base_areas,
                by = c("area", "period"), sort = FALSE)

stopifnot(nrow(sample) == 72L, all(sample$population > 0))

C <- cbind(intercept = 1, period = sample$period,
           control = sample$control)
X <- cbind(C, x = sample$x) * sqrt(sample$population)
Z <- cbind(C, z = sample$z) * sqrt(sample$population)
y <- sample$change_pp * sqrt(sample$population)

fitted_X <- qr.fitted(qr(Z), X)
iv_slope <- unname(qr.coef(qr(fitted_X), y)["x"])

get_value <- function(column, area, period) {
  value <- sample[sample$area == area & sample$period == period, column]
  stopifnot(length(value) == 1L)
  unname(value)
}

terms <- c(
  iv_slope = iv_slope,
  exposure_area0_period0 = get_value("x", 0, 0),
  exposure_area0_period1 = get_value("x", 0, 1),
  instrument_area0_period0 = get_value("z", 0, 0)
)

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = lapply(names(terms), function(term) {
    list(term = term, estimate = unname(terms[[term]]),
         se = NULL, n_obs = 72L)
  }),
  method_metadata = list(
    estimator = "weighted 2SLS",
    outcome = "change_pp",
    endogenous_regressor = "x",
    excluded_instrument = "z",
    exogenous_regressors = c("intercept", "period", "control"),
    weight = "base-vintage population"
  ),
  diagnostics = list(
    estimation_rows = 72L,
    first_stage_rank = as.integer(qr(Z)$rank),
    second_stage_rank = as.integer(qr(fitted_X)$rank)
  )
)

jsonlite::write_json(
  result, "result.json", auto_unbox = TRUE,
  null = "null", digits = NA, pretty = TRUE
)
