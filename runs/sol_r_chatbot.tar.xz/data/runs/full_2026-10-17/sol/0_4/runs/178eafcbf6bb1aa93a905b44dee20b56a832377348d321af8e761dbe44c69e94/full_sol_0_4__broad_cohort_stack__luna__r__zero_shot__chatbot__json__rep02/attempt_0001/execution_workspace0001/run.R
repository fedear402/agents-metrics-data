library(jsonlite)

data <- read.csv("input.csv")

cohorts <- c(3, 5, 7)
results <- lapply(cohorts, function(c) {
  window <- (c - 2):(c + 2)

  eligible <- data[
    data$time %in% window &
      (data$g == c | data$g == 0 | data$g > c + 2),
  ]

  counts <- table(eligible$id)
  balanced_ids <- names(counts[counts == length(window)])
  comparison <- eligible[as.character(eligible$id) %in% balanced_ids, ]

  comparison$did <- as.integer(
    comparison$g == c & comparison$time >= c
  )

  fit <- lm(y ~ did + factor(id) + factor(time), data = comparison)

  list(
    estimate = unname(coef(fit)[["did"]]),
    n_obs = nrow(comparison),
    n_treated = length(unique(comparison$id[comparison$g == c]))
  )
})

weights <- vapply(results, `[[`, numeric(1), "n_treated")
estimates <- vapply(results, `[[`, numeric(1), "estimate")
row_counts <- vapply(results, `[[`, integer(1), "n_obs")

make_row <- function(term, estimate, n_obs) {
  list(
    term = term,
    estimate = estimate,
    se = NULL,
    n_obs = n_obs
  )
}

output <- list(
  task_id = "broad_cohort_stack",
  platform = "r",
  estimates = list(
    make_row("att_g3", estimates[1], row_counts[1]),
    make_row("att_g5", estimates[2], row_counts[2]),
    make_row("att_g7", estimates[3], row_counts[3]),
    make_row("att_weighted", weighted.mean(estimates, weights), sum(row_counts))
  ),
  method_metadata = list(),
  diagnostics = list()
)

jsonlite::write_json(
  output,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = NA
)
