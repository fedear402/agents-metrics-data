library(jsonlite)

households <- read.csv("households.csv")
census <- read.csv("census.csv")

sample <- households[!is.na(households$recipient) & households$recipient == 0, ]
required <- c("eligible", "instrument", "dose", "baseline", "weight", "outcome")
sample <- sample[complete.cases(sample[, required]), ]

if (nrow(sample) == 0L || any(sample$weight <= 0)) {
  stop("The estimation sample is empty or contains nonpositive weights.")
}
if (!all(sample$eligible %in% c(0, 1))) {
  stop("eligible must contain only 0 and 1.")
}

ineligible <- 1 - sample$eligible
eligible <- sample$eligible

exogenous <- cbind(
  ineligible,
  eligible,
  baseline_ineligible = sample$baseline * ineligible,
  baseline_eligible = sample$baseline * eligible
)
endogenous <- cbind(
  dose_ineligible = sample$dose * ineligible,
  dose_eligible = sample$dose * eligible
)
excluded <- cbind(
  instrument_ineligible = sample$instrument * ineligible,
  instrument_eligible = sample$instrument * eligible
)

X <- cbind(exogenous, endogenous)
Z <- cbind(exogenous, excluded)
sqrt_weight <- sqrt(sample$weight)
Xw <- X * sqrt_weight
Zw <- Z * sqrt_weight
yw <- sample$outcome * sqrt_weight

if (qr(Zw)$rank != ncol(Z) ||
    qr(crossprod(Zw, Xw))$rank != ncol(X)) {
  stop("The weighted IV design does not identify all coefficients.")
}

beta <- solve(crossprod(Zw, Xw), crossprod(Zw, yw))

group_mean_dose <- function(group) {
  rows <- sample$eligible == group
  if (!any(rows)) stop("Both eligibility groups need observations.")
  weighted.mean(sample$dose[rows], sample$weight[rows])
}

ineligible_effect <- unname(beta["dose_ineligible", 1]) * group_mean_dose(0)
eligible_nonrecipient_effect <-
  unname(beta["dose_eligible", 1]) * group_mean_dose(1)

if (!all(c("eligible", "nonrecipient_population") %in% names(census)) ||
    anyNA(census[, c("eligible", "nonrecipient_population")]) ||
    !setequal(census$eligible, c(0, 1)) ||
    anyDuplicated(census$eligible) ||
    any(census$nonrecipient_population < 0)) {
  stop("census.csv must contain one valid population count for each group.")
}

population <- census$nonrecipient_population[
  match(c(0, 1), census$eligible)
]
if (sum(population) <= 0) stop("Total nonrecipient population must be positive.")

population_effect <- sum(
  population * c(ineligible_effect, eligible_nonrecipient_effect)
) / sum(population)

n_obs <- nrow(sample)
estimate_record <- function(term, value) {
  list(term = term, estimate = unname(value), se = NA_real_, n_obs = n_obs)
}

result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = list(
    estimate_record("ineligible_effect", ineligible_effect),
    estimate_record("eligible_nonrecipient_effect", eligible_nonrecipient_effect),
    estimate_record("population_effect", population_effect)
  ),
  method_metadata = list(
    estimator = "Weighted two-stage least squares",
    sample = "All household rows with recipient equal to zero and complete regression data",
    counterfactual = "Dose set to zero for every retained household as a synthetic attribution convention",
    intercept = "No additional intercept",
    group_effect = "Fitted group dose slope times the household-weighted mean dose in that group",
    population_aggregation = "Census nonrecipient_population weights used only between groups",
    standard_errors = "Not requested; reported as null"
  ),
  diagnostics = list(
    n_obs = n_obs,
    n_ineligible = sum(sample$eligible == 0),
    n_eligible_nonrecipient = sum(sample$eligible == 1),
    weighted_mean_dose_ineligible = group_mean_dose(0),
    weighted_mean_dose_eligible = group_mean_dose(1),
    census_nonrecipient_population_ineligible = population[1],
    census_nonrecipient_population_eligible = population[2],
    instrument_rank = qr(Zw)$rank
  )
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  na = "null",
  digits = NA,
  pretty = TRUE
)
