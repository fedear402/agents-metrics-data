library(jsonlite)

households <- read.csv("households.csv")
census <- read.csv("census.csv")

sample <- households[households$recipient == 0, ]
g0 <- as.numeric(sample$eligible == 0)
g1 <- as.numeric(sample$eligible == 1)

X <- cbind(
  g0,
  g1,
  sample$baseline * g0,
  sample$baseline * g1,
  sample$dose * g0,
  sample$dose * g1
)

Z <- cbind(
  g0,
  g1,
  sample$baseline * g0,
  sample$baseline * g1,
  sample$instrument * g0,
  sample$instrument * g1
)

w <- sample$weight
y <- sample$outcome

# Weighted 2SLS with the specified columns and no additional intercept.
ZWZ <- crossprod(Z, Z * w)
ZWX <- crossprod(Z, X * w)
ZWy <- crossprod(Z, y * w)
beta <- solve(crossprod(ZWX, solve(ZWZ, ZWX)),
              crossprod(ZWX, solve(ZWZ, ZWy)))

mean_dose <- function(group) {
  rows <- sample$eligible == group
  weighted.mean(sample$dose[rows], w[rows])
}

ineligible_effect <- as.numeric(beta[5] * mean_dose(0))
eligible_nonrecipient_effect <- as.numeric(beta[6] * mean_dose(1))

population <- setNames(
  census$nonrecipient_population,
  as.character(census$eligible)
)
population_effect <- as.numeric(
  (population["0"] * ineligible_effect +
   population["1"] * eligible_nonrecipient_effect) /
  sum(population[c("0", "1")])
)

n_obs <- nrow(sample)
estimate_entry <- function(term, value) {
  list(term = term, estimate = value, se = NA_real_, n_obs = n_obs)
}

result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = list(
    estimate_entry("ineligible_effect", ineligible_effect),
    estimate_entry("eligible_nonrecipient_effect",
                   eligible_nonrecipient_effect),
    estimate_entry("population_effect", population_effect)
  ),
  method_metadata = list(
    estimator = "weighted 2SLS",
    sample = "households with recipient == 0",
    counterfactual = "dose set to zero for every retained household",
    group_effect = "dose slope times household-weighted mean dose",
    population_aggregation = "nonrecipient_population census weights"
  ),
  diagnostics = list(n_obs = n_obs)
)

write_json(result, "result.json", auto_unbox = TRUE, na = "null",
           digits = NA, pretty = TRUE)
