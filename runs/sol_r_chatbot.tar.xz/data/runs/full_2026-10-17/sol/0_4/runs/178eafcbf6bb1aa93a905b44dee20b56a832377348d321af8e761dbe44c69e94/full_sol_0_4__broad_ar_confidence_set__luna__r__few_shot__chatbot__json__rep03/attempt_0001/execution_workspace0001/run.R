d <- read.csv("input.csv")
n <- nrow(d)
q <- 2L
df <- n - 4L

Xr <- cbind(1, d$x)
Xu <- cbind(1, d$x, d$z1, d$z2)

ry <- qr.resid(qr(Xr), d$y)
rd <- qr.resid(qr(Xr), d$endog)
uy <- qr.resid(qr(Xu), d$y)
ud <- qr.resid(qr(Xu), d$endog)

critical <- qf(0.95, q, df)
k <- q * critical / df

A <- sum(rd^2) - (1 + k) * sum(ud^2)
B <- -2 * (sum(ry * rd) - (1 + k) * sum(uy * ud))
C <- sum(ry^2) - (1 + k) * sum(uy^2)

discriminant <- B^2 - 4 * A * C
stopifnot(is.finite(discriminant), discriminant > 0, A != 0)

boundaries <- sort(c(
  (-B - sqrt(discriminant)) / (2 * A),
  (-B + sqrt(discriminant)) / (2 * A)
))

ssr_r_at_one <- sum((ry - rd)^2)
ssr_u_at_one <- sum((uy - ud)^2)
ar_f_at_one <- ((ssr_r_at_one - ssr_u_at_one) / q) /
  (ssr_u_at_one / df)

terms <- c(
  "boundary_low", "boundary_high", "accepts_zero",
  "unbounded", "ar_f_at_one"
)
values <- c(
  boundaries,
  as.integer(C <= 0),
  as.integer(A < 0),
  ar_f_at_one
)

estimates <- lapply(seq_along(terms), function(i) {
  list(
    term = terms[i],
    estimate = unname(values[i]),
    se = NULL,
    n_obs = n
  )
})

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "Anderson-Rubin confidence set by joint F-test inversion",
    vcov = "Conventional homoskedastic OLS"
  ),
  diagnostics = list()
)

jsonlite::write_json(
  result, "result.json",
  auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE
)
