data <- read.csv("input.csv")
data$y <- factor(data$y, levels = c(0, 1, 2))

fit <- nnet::multinom(y ~ x + z, data = data, trace = FALSE, Hess = TRUE)
coefficients <- coef(fit)
standard_errors <- summary(fit)$standard.errors
n_obs <- nrow(data)

intercepts <- coefficients[, "(Intercept)"]
prob_cat2_zero <- exp(intercepts["2"] - max(c(0, intercepts)))
prob_cat2_zero <- prob_cat2_zero /
  sum(exp(c(0, intercepts) - max(c(0, intercepts))))

row <- function(term, estimate, se) {
  list(term = term, estimate = unname(estimate), se = unname(se), n_obs = n_obs)
}

result <- list(
  task_id = "broad_multinomial_logit",
  platform = "r",
  estimates = list(
    row("x_cat1", coefficients["1", "x"], standard_errors["1", "x"]),
    row("z_cat1", coefficients["1", "z"], standard_errors["1", "z"]),
    row("x_cat2", coefficients["2", "x"], standard_errors["2", "x"]),
    row("z_cat2", coefficients["2", "z"], standard_errors["2", "z"]),
    row("prob_cat2_zero", prob_cat2_zero, NULL)
  ),
  method_metadata = list(
    estimator = "Maximum likelihood multinomial logit, base outcome 0",
    vcov = "Inverse observed information"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = NA)
