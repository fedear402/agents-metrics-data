data <- read.csv("./input.csv", stringsAsFactors = FALSE)
data <- data[complete.cases(data[, c("group", "y")]), c("group", "y")]
data$group <- factor(data$group)
data$y <- as.numeric(data$y)

fit <- aov(y ~ group, data = data)
anova_table <- summary(fit)[[1]]

values <- c(
  F = anova_table["group", "F value"],
  df_num = anova_table["group", "Df"],
  df_den = anova_table["Residuals", "Df"],
  p_value = anova_table["group", "Pr(>F)"]
)

json_number <- function(x) {
  if (!is.finite(x)) stop("ANOVA produced a non-finite result.")
  format(x, digits = 16, scientific = TRUE, trim = TRUE)
}

n_obs <- nobs(fit)
rows <- vapply(names(values), function(term) {
  sprintf(
    '{"term":"%s","estimate":%s,"se":null,"n_obs":%d}',
    term, json_number(values[[term]]), n_obs
  )
}, character(1))

result <- sprintf(
  paste0(
    '{"task_id":"anova_oneway","platform":"r","estimates":[%s],',
    '"method_metadata":{"estimator":"one-way ANOVA","vcov":"classical"},',
    '"diagnostics":{}}'
  ),
  paste(rows, collapse = ",")
)

writeLines(result, "result.json")
