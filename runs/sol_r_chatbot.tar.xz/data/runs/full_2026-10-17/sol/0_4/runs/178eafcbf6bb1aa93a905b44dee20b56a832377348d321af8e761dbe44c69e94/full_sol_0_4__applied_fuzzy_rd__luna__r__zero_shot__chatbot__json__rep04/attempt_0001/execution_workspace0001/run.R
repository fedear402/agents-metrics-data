d <- read.csv("input.csv")
d <- d[!is.na(d$score) & !is.na(d$earnings) &
         !is.na(d$participated) & abs(d$score) < 1, ]

x <- d$score
right <- as.numeric(x >= 0)
w <- 1 - abs(x)
X <- cbind(intercept = 1, right = right, score = x, right_score = right * x)
Y <- cbind(earnings = d$earnings, participated = d$participated)

bread <- solve(crossprod(X, w * X))
beta <- bread %*% crossprod(X, w * Y)
residuals <- Y - X %*% beta

# The second coefficient is the right limit minus the left limit.
influence <- (X %*% bread[, 2]) * w
joint_vcov <- crossprod(residuals * influence)
joint_vcov <- as.matrix(joint_vcov)

reduced_form <- beta[2, 1]
first_stage <- beta[2, 2]
treatment_effect <- reduced_form / first_stage

gradient <- c(1 / first_stage, -reduced_form / first_stage^2)
effect_variance <- as.numeric(t(gradient) %*% joint_vcov %*% gradient)

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = unname(treatment_effect),
         se = sqrt(max(0, effect_variance)), n_obs = nrow(d)),
    list(term = "reduced_form", estimate = unname(reduced_form),
         se = sqrt(max(0, joint_vcov[1, 1])), n_obs = nrow(d)),
    list(term = "first_stage", estimate = unname(first_stage),
         se = sqrt(max(0, joint_vcov[2, 2])), n_obs = nrow(d))
  ),
  method_metadata = list(
    estimator = "Fuzzy RD ratio of triangular-weighted local-linear discontinuities",
    vcov = "Joint HC0 sandwich covariance; delta-method ratio SE"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = NA)
