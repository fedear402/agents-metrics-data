d <- read.csv("input.csv", stringsAsFactors = FALSE)

regions <- unique(d$region_id)
industries <- unique(d$industry_id)
r <- match(d$region_id, regions)
n <- match(d$industry_id, industries)

regional <- d[match(regions, d$region_id), ]
industry <- d[match(industries, d$industry_id), ]

e <- regional$region_weight / sum(regional$region_weight)
z <- as.numeric(rowsum(d$share * industry$shock[n], r, reorder = TRUE))
x <- regional$x
y <- regional$y

center <- function(v) v - sum(e * v)
x0 <- center(x)
y0 <- center(y)
z0 <- center(z)

exposure <- e[r] * d$share
s <- as.numeric(rowsum(exposure, n, reorder = TRUE))
aggregate_residual <- function(v) {
  as.numeric(rowsum(exposure * v[r], n, reorder = TRUE)) / s
}

xbar <- aggregate_residual(x0)
ybar <- aggregate_residual(y0)
zbar <- aggregate_residual(z0)
shock <- industry$shock
N <- length(industries)

weighted_iv <- function(outcome, endogenous, instrument, weights) {
  X <- cbind(intercept = 1, slope = endogenous)
  Z <- cbind(intercept = 1, instrument = instrument)
  A <- crossprod(Z, weights * X)
  coefficient <- as.numeric(solve(A, crossprod(Z, weights * outcome)))
  residual <- as.numeric(outcome - X %*% coefficient)
  meat <- crossprod(Z, (weights * residual)^2 * Z)
  A_inverse <- solve(A)
  variance <- A_inverse %*% meat %*% t(A_inverse) * length(weights) /
    (length(weights) - 2)
  list(slope = coefficient[2], se = sqrt(variance[2, 2]))
}

regional_effect <- weighted_iv(y, x, z, e)$slope
regional_first_stage <- weighted_iv(x, z, z, e)$slope

shock_effect <- weighted_iv(ybar, xbar, shock, s)
shock_first_stage <- weighted_iv(xbar, zbar, shock, s)

stopifnot(
  N > 2,
  all(s > 0),
  isTRUE(all.equal(regional_effect, shock_effect$slope, tolerance = 1e-8)),
  isTRUE(all.equal(regional_first_stage, shock_first_stage$slope, tolerance = 1e-8))
)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = regional_effect,
         se = shock_effect$se, n_obs = N),
    list(term = "first_stage", estimate = regional_first_stage,
         se = shock_first_stage$se, n_obs = N),
    list(term = "effective_shocks", estimate = 1 / sum(s^2),
         se = NULL, n_obs = N)
  ),
  method_metadata = list(
    estimator = "Weighted regional 2SLS with BHJ shock-level aggregation",
    vcov = "Shock-level heteroskedasticity-robust HC1, N/(N-2)"
  ),
  diagnostics = list()
)

writeLines(
  jsonlite::toJSON(result, auto_unbox = TRUE, digits = 16, null = "null"),
  "result.json"
)
