library(jsonlite)

data <- read.csv("./input.csv")
y <- as.numeric(data$y)
if (anyNA(y) || length(y) != 250L) {
  stop("Expected 250 nonmissing observations of y.")
}

fit <- stats::arima(y, order = c(1, 1, 1), include.mean = FALSE,
                    method = "ML")
pred <- stats::predict(fit, n.ahead = 1L)

forecast <- unname(as.numeric(pred$pred[1L]))
forecast_se <- unname(as.numeric(pred$se[1L]))
critical <- stats::qnorm(0.975)
n_obs <- length(y)

out <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = list(
    list(term = "forecast", estimate = forecast, se = forecast_se,
         n_obs = n_obs),
    list(term = "lower_95", estimate = forecast - critical * forecast_se,
         se = NA_real_, n_obs = n_obs),
    list(term = "upper_95", estimate = forecast + critical * forecast_se,
         se = NA_real_, n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "ARIMA(1,1,1) maximum likelihood, no constant or drift",
    vcov = "Model-based forecast variance"
  ),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "result.json", auto_unbox = TRUE, digits = NA,
           na = "null")
