crosswalk <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
trade <- read.csv("trade.csv", stringsAsFactors = FALSE)
areas <- read.csv("areas.csv", stringsAsFactors = FALSE)
employment <- read.csv("employment.csv", stringsAsFactors = FALSE)
outcomes <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

trade <- merge(trade, crosswalk, by = "code", sort = FALSE)

industry_change <- aggregate(
  cbind(us_change, other_change) ~ period + industry,
  data = trade,
  FUN = sum
)
period_info <- unique(trade[c("period", "price_index", "years")])
industry_change <- merge(industry_change, period_info, by = "period")

national <- aggregate(
  employment ~ period + vintage + industry,
  data = employment,
  FUN = sum
)
names(national)[names(national) == "employment"] <- "national_employment"

cells <- merge(
  areas[c("area", "period", "vintage", "total_employment")],
  unique(industry_change["industry"]),
  by = NULL
)
cells <- merge(
  cells, employment,
  by = c("area", "period", "vintage", "industry"),
  all.x = TRUE,
  sort = FALSE
)
cells$employment[is.na(cells$employment)] <- 0

cells <- merge(
  cells, national,
  by = c("period", "vintage", "industry"),
  all.x = TRUE,
  sort = FALSE
)
cells <- merge(
  cells, industry_change,
  by = c("period", "industry"),
  all.x = TRUE,
  sort = FALSE
)

cells$component <- with(
  cells,
  (employment / total_employment) *
    (ifelse(vintage == "base", us_change, other_change) /
       national_employment) /
    (price_index / 100) / 1000 * (10 / years)
)

exposure <- aggregate(
  component ~ area + period + vintage,
  data = cells,
  FUN = sum
)

base <- exposure[exposure$vintage == "base", c("area", "period", "component")]
early <- exposure[exposure$vintage == "early", c("area", "period", "component")]
names(base)[3] <- "x"
names(early)[3] <- "z"

weights <- areas[
  areas$vintage == "base",
  c("area", "period", "population")
]
d <- merge(outcomes, base, by = c("area", "period"))
d <- merge(d, early, by = c("area", "period"))
d <- merge(d, weights, by = c("area", "period"))

C <- model.matrix(~ period + control, data = d)
X <- cbind(C, x = d$x)
Z <- cbind(C, z = d$z)
root_w <- sqrt(d$population)
Xw <- X * root_w
Zw <- Z * root_w
yw <- d$change_pp * root_w
fitted_X <- qr.fitted(qr(Zw), Xw)
iv_slope <- unname(qr.coef(qr(fitted_X), yw)[ncol(Xw)])

get_exposure <- function(data, area_value, period_value, column) {
  value <- data[
    as.character(data$area) == as.character(area_value) &
      as.character(data$period) == as.character(period_value),
    column
  ]
  stopifnot(length(value) == 1L, is.finite(value))
  unname(value)
}

stopifnot(nrow(d) == 72L, is.finite(iv_slope))

terms <- c(
  iv_slope = iv_slope,
  exposure_area0_period0 = get_exposure(d, 0, 0, "x"),
  exposure_area0_period1 = get_exposure(d, 0, 1, "x"),
  instrument_area0_period0 = get_exposure(d, 0, 0, "z")
)

estimates <- lapply(names(terms), function(term) {
  list(
    term = term,
    estimate = unname(terms[[term]]),
    se = NULL,
    n_obs = 72L
  )
})

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "weighted 2SLS",
    endogenous_regressor = "x",
    excluded_instrument = "z",
    exogenous_regressors = c("intercept", "period", "control"),
    weight = "base-vintage population",
    exposure_units = "thousands of real dollars per worker per decade"
  ),
  diagnostics = list(
    estimation_rows = 72L,
    industries = 4L
  )
)

jsonlite::write_json(
  result,
  path = "result.json",
  auto_unbox = TRUE,
  pretty = TRUE,
  digits = NA,
  null = "null"
)
