library(jsonlite)

crosswalk <- read.csv("crosswalk.csv")
trade <- read.csv("trade.csv")
areas <- read.csv("areas.csv")
employment <- read.csv("employment.csv")
outcomes <- read.csv("outcomes.csv")

trade_industry <- merge(trade, crosswalk, by = "code", all.x = TRUE)
industries <- unique(crosswalk$industry)

cells <- merge(
  areas[c("area", "period", "vintage", "total_employment", "population")],
  data.frame(industry = industries)
)
cells <- merge(
  cells, employment,
  by = c("area", "period", "vintage", "industry"),
  all.x = TRUE
)
cells$employment[is.na(cells$employment)] <- 0

national <- aggregate(
  employment ~ period + vintage + industry,
  data = cells,
  FUN = sum
)
names(national)[names(national) == "employment"] <- "national_employment"

cells <- merge(
  cells, national,
  by = c("period", "vintage", "industry")
)
cells <- merge(
  cells,
  trade_industry[c("period", "industry", "us_change", "other_change",
                   "price_index", "years")],
  by = c("period", "industry")
)

cells$component <- with(cells, {
  trade_change <- ifelse(vintage == "base", us_change, other_change)
  (employment / total_employment) *
    (trade_change / national_employment) /
    (price_index / 100) / 1000 * (10 / years)
})

exposures <- aggregate(
  component ~ area + period + vintage,
  data = cells,
  FUN = sum
)
wide <- reshape(
  exposures,
  idvar = c("area", "period"),
  timevar = "vintage",
  direction = "wide"
)
names(wide)[names(wide) == "component.base"] <- "x"
names(wide)[names(wide) == "component.early"] <- "z"

base_areas <- areas[areas$vintage == "base",
                    c("area", "period", "population")]
d <- merge(wide, base_areas, by = c("area", "period"))
d <- merge(d, outcomes, by = c("area", "period"))
stopifnot(nrow(d) == 72L, !anyNA(d[c("x", "z", "change_pp",
                                    "control", "population")]))

C <- model.matrix(~ period + control, data = d)
stopifnot(ncol(C) == 3L)
X <- cbind(C, x = d$x)
Z <- cbind(C, z = d$z)
root_weight <- sqrt(d$population)
Xw <- X * root_weight
Zw <- Z * root_weight
yw <- d$change_pp * root_weight
fitted_X <- qr.fitted(qr(Zw), Xw)
iv_slope <- unname(qr.coef(qr(fitted_X), yw)[ncol(X)])

get_exposure <- function(area_id, period_id, column) {
  value <- d[d$area == area_id & d$period == period_id, column]
  stopifnot(length(value) == 1L)
  unname(value)
}

values <- c(
  iv_slope = iv_slope,
  exposure_area0_period0 = get_exposure(0, 0, "x"),
  exposure_area0_period1 = get_exposure(0, 1, "x"),
  instrument_area0_period0 = get_exposure(0, 0, "z")
)

estimates <- lapply(names(values), function(term) {
  list(term = term, estimate = unname(values[[term]]),
       se = NULL, n_obs = 72L)
})

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "weighted 2SLS",
    outcome = "change_pp",
    endogenous_variable = "x",
    excluded_instrument = "z",
    exogenous_variables = c("intercept", "period", "control"),
    weight = "base-vintage population"
  ),
  diagnostics = list(n_obs = 72L)
)

jsonlite::write_json(
  result, "result.json", auto_unbox = TRUE, null = "null",
  digits = NA, pretty = TRUE
)
