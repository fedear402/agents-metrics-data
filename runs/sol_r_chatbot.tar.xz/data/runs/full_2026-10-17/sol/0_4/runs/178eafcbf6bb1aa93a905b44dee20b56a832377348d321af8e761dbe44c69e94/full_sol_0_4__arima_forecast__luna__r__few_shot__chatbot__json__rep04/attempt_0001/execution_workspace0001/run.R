library(jsonlite)

dat <- read.csv("./input.csv")
dat <- dat[order(dat$t), ]
y <- as.numeric(dat$y)

if (anyNA(y) || length(y) != 250L) {
  stop("The ordered series must contain 250 non-missing observations.")
}

fit <- stats::arima(
  y,
  order = c(1L, 1L, 1L),
  include.mean = FALSE,
  method = "ML"
)

pred <- stats::predict(fit, n.ahead = 1L)
forecast <- unname(as.numeric(pred$pred[1L]))
forecast_se <- unname(as.numeric(pred$se[1L]))
critical <- stats::qnorm(0.975)

out <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = list(
    list(term = "forecast", estimate = forecast,
         se = forecast_se, n_obs = length(y)),
    list(term = "lower_95", estimate = forecast - critical * forecast_se,
         se = NULL, n_obs = length(y)),
    list(term = "upper_95", estimate = forecast + critical * forecast_se,
         se = NULL, n_obs = length(y))
  ),
  method_metadata = list(
    estimator = "ARIMA(1,1,1) maximum likelihood without constant or drift",
    vcov = "Gaussian model-based prediction variance"
  ),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "result.json", auto_unbox = TRUE, digits = NA)
