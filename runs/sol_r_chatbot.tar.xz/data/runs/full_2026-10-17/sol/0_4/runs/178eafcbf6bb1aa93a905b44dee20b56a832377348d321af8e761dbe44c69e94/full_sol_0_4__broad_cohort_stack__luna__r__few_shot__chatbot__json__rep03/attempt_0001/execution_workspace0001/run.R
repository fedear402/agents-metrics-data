d <- read.csv("input.csv")

cohorts <- c(3, 5, 7)
results <- lapply(cohorts, function(c) {
  window <- (c - 2):(c + 2)
  eligible <- d$g == c | d$g == 0 | d$g > c + 2
  x <- d[eligible & d$time %in% window, ]

  counts <- table(x$id)
  balanced_ids <- names(counts[counts == length(window)])
  x <- x[as.character(x$id) %in% balanced_ids, ]

  x$did <- as.integer(x$g == c & x$time >= c)
  effect <- unname(coef(lm(y ~ did + factor(id) + factor(time), data = x))["did"])

  list(
    effect = effect,
    n_obs = nrow(x),
    n_treated = length(unique(x$id[x$g == c]))
  )
})

effects <- vapply(results, function(x) x$effect, numeric(1))
row_counts <- vapply(results, function(x) x$n_obs, integer(1))
treated_counts <- vapply(results, function(x) x$n_treated, integer(1))

stopifnot(identical(unname(row_counts), c(375L, 275L, 315L)))

estimates <- lapply(seq_along(cohorts), function(i) {
  list(
    term = paste0("att_g", cohorts[i]),
    estimate = effects[i],
    se = NULL,
    n_obs = row_counts[i]
  )
})

estimates[[length(estimates) + 1L]] <- list(
  term = "att_weighted",
  estimate = weighted.mean(effects, treated_counts),
  se = NULL,
  n_obs = sum(row_counts)
)

out <- list(
  task_id = "broad_cohort_stack",
  platform = "r",
  estimates = estimates,
  method_metadata = list(),
  diagnostics = list()
)

jsonlite::write_json(
  out,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16
)
