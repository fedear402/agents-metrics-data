library(jsonlite)

crosswalk <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
trade <- read.csv("trade.csv", stringsAsFactors = FALSE)
areas <- read.csv("areas.csv", stringsAsFactors = FALSE)
employment <- read.csv("employment.csv", stringsAsFactors = FALSE)
outcomes <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

trade <- merge(trade, crosswalk, by = "code", sort = FALSE)
national <- aggregate(
  employment ~ period + vintage + industry,
  data = employment,
  FUN = sum
)
names(national)[names(national) == "employment"] <- "national_employment"

make_exposure <- function(vintage, change_column) {
  a <- areas[areas$vintage == vintage, ]
  e <- merge(
    a[c("area", "period", "total_employment")],
    employment[employment$vintage == vintage,
               c("area", "period", "industry", "employment")],
    by = c("area", "period"),
    all.x = TRUE,
    sort = FALSE
  )
  e$employment[is.na(e$employment)] <- 0

  n <- national[national$vintage == vintage,
                c("period", "industry", "national_employment")]
  e <- merge(e, n, by = c("period", "industry"), all.x = TRUE, sort = FALSE)
  e <- merge(
    e,
    trade[c("period", "industry", change_column, "price_index", "years")],
    by = c("period", "industry"),
    all.x = TRUE,
    sort = FALSE
  )

  contribution <- with(
    e,
    (employment / total_employment) *
      (get(change_column) / national_employment) /
      (price_index / 100) / 1000 * (10 / years)
  )
  contribution[is.na(contribution) & e$employment == 0] <- 0
  e$contribution <- contribution

  result <- aggregate(
    contribution ~ area + period,
    data = e,
    FUN = sum
  )
  names(result)[3] <- if (vintage == "base") "x" else "z"
  result
}

x <- make_exposure("base", "us_change")
z <- make_exposure("early", "other_change")
base_areas <- areas[areas$vintage == "base",
                    c("area", "period", "population")]
d <- Reduce(
  function(left, right) merge(
    left, right, by = c("area", "period"), sort = FALSE
  ),
  list(outcomes, base_areas, x, z)
)

stopifnot(nrow(d) == 72L, !anyNA(d))
C <- cbind(intercept = 1, period = as.numeric(d$period), control = d$control)
X <- cbind(C, x = d$x) * sqrt(d$population)
Z <- cbind(C, z = d$z) * sqrt(d$population)
fitted_X <- qr.fitted(qr(Z), X)
iv_slope <- unname(qr.coef(qr(fitted_X), d$change_pp * sqrt(d$population))["x"])

get_value <- function(column, period_value) {
  value <- d[d$area == 0 & d$period == period_value, column]
  stopifnot(length(value) == 1L)
  unname(value)
}

terms <- c(
  "iv_slope",
  "exposure_area0_period0",
  "exposure_area0_period1",
  "instrument_area0_period0"
)
values <- c(
  iv_slope,
  get_value("x", 0),
  get_value("x", 1),
  get_value("z", 0)
)

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = lapply(seq_along(terms), function(i) {
    list(term = terms[i], estimate = values[i], se = NULL, n_obs = 72L)
  }),
  method_metadata = list(
    estimator = "weighted_2SLS",
    outcome = "change_pp",
    endogenous_regressor = "x",
    excluded_instrument = "z",
    exogenous_regressors = c("intercept", "period", "control"),
    weight = "base_vintage_population"
  ),
  diagnostics = list(n_obs = 72L)
)

jsonlite::write_json(
  result, "result.json",
  auto_unbox = TRUE, null = "null", digits = NA, pretty = TRUE
)
