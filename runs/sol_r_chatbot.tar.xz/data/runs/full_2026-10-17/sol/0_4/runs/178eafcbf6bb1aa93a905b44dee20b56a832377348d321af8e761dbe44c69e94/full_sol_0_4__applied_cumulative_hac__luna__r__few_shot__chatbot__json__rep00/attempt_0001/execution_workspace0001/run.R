library(jsonlite)

data <- read.csv("input.csv", stringsAsFactors = FALSE)
data <- data[order(as.Date(data$date)), ]

log_sales <- log(data$sales)
change <- c(NA_real_, diff(log(data$vix)))
n <- nrow(data)

lagged_changes <- sapply(1:15, function(k) {
  c(rep(NA_real_, k), change[seq_len(n - k)])
})
colnames(lagged_changes) <- paste0("lag_", 1:15)

sample <- data.frame(log_sales, lagged_changes)
sample <- sample[complete.cases(sample), ]

fit <- lm(log_sales ~ ., data = sample)
X <- model.matrix(fit)
coefficients <- coef(fit)
N <- nrow(X)
p <- ncol(X)

scores <- X * as.numeric(residuals(fit))
meat <- crossprod(scores)

for (j in 1:15) {
  lag_product <- crossprod(
    scores[(j + 1):N, , drop = FALSE],
    scores[1:(N - j), , drop = FALSE]
  )
  meat <- meat + (1 - j / 16) * (lag_product + t(lag_product))
}

bread <- solve(crossprod(X))
covariance <- (N / (N - p)) * bread %*% meat %*% bread

contrast <- c(0, rep(1, 15))
cumulative_estimate <- sum(contrast * coefficients)
cumulative_se <- sqrt(drop(t(contrast) %*% covariance %*% contrast))

row <- function(term, estimate, se) {
  list(
    term = term,
    estimate = unname(as.numeric(estimate)),
    se = unname(as.numeric(se)),
    n_obs = as.integer(N)
  )
}

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    row("cumulative_response", cumulative_estimate, cumulative_se),
    row("lag_1", coefficients["lag_1"], sqrt(covariance["lag_1", "lag_1"])),
    row("lag_15", coefficients["lag_15"], sqrt(covariance["lag_15", "lag_15"]))
  ),
  method_metadata = list(
    estimator = "OLS with intercept and 15 trading-observation lags of log(vix) changes",
    vcov = "Newey-West HAC, Bartlett weights, maximum lag 15, N/(N-16) correction"
  ),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, digits = 16, pretty = TRUE)
