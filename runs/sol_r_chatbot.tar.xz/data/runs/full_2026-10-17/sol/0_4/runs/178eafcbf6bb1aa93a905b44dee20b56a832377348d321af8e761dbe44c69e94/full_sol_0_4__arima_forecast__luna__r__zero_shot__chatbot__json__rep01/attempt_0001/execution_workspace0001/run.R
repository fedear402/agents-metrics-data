data <- read.csv("./input.csv")
data <- data[order(data$t), ]

if (!all(c("t", "y") %in% names(data))) {
  stop("input.csv must contain t and y columns")
}
if (anyNA(data$t) || anyNA(data$y) || tail(data$t, 1) != 250) {
  stop("Complete observations through t = 250 are required")
}

y <- as.numeric(data$y)
fit <- stats::arima(
  y,
  order = c(1, 1, 1),
  include.mean = FALSE,
  method = "ML"
)

prediction <- stats::predict(fit, n.ahead = 1)
forecast <- as.numeric(prediction$pred[1])
se <- as.numeric(prediction$se[1])
critical <- stats::qnorm(0.975)
n_obs <- length(y)

number <- function(x) sprintf("%.15g", x)

json <- sprintf(
  paste0(
    '{"task_id":"arima_forecast","platform":"r","estimates":[',
    '{"term":"forecast","estimate":%s,"se":%s,"n_obs":%d},',
    '{"term":"lower_95","estimate":%s,"se":null,"n_obs":%d},',
    '{"term":"upper_95","estimate":%s,"se":null,"n_obs":%d}',
    '],"method_metadata":{"estimator":"ARIMA(1,1,1) maximum likelihood, no drift",',
    '"vcov":"Model-based forecast variance"},"diagnostics":{}}'
  ),
  number(forecast), number(se), n_obs,
  number(forecast - critical * se), n_obs,
  number(forecast + critical * se), n_obs
)

writeLines(json, "result.json")
