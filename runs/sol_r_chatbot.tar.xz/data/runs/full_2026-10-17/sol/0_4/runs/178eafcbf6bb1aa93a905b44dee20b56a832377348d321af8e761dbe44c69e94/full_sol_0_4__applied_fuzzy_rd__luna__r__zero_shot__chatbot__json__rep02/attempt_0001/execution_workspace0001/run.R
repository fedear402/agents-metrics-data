data <- read.csv("input.csv")
keep <- complete.cases(data[, c("score", "participated", "earnings")]) &
  abs(data$score) < 1
data <- data[keep, ]

x <- data$score
right <- as.numeric(x >= 0)
w <- 1 - abs(x)
X <- cbind(intercept = 1, score = x, right = right, score_right = x * right)
Y <- cbind(earnings = data$earnings, participation = data$participated)

bread <- solve(crossprod(X, X * w))
coef <- bread %*% crossprod(X, Y * w)
resid <- Y - X %*% coef

jump <- as.numeric(coef["right", ])
names(jump) <- colnames(Y)

hc0_cov <- function(a, b) {
  meat <- crossprod(X, X * as.numeric(w^2 * resid[, a] * resid[, b]))
  (bread %*% meat %*% bread)["right", "right"]
}

rf <- jump["earnings"]
fs <- jump["participation"]
effect <- rf / fs

var_rf <- hc0_cov("earnings", "earnings")
var_fs <- hc0_cov("participation", "participation")
cov_rf_fs <- hc0_cov("earnings", "participation")
var_effect <- var_rf / fs^2 +
  rf^2 * var_fs / fs^4 -
  2 * rf * cov_rf_fs / fs^3

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = unname(effect),
         se = unname(sqrt(max(0, var_effect))), n_obs = nrow(data)),
    list(term = "reduced_form", estimate = unname(rf),
         se = unname(sqrt(max(0, var_rf))), n_obs = nrow(data)),
    list(term = "first_stage", estimate = unname(fs),
         se = unname(sqrt(max(0, var_fs))), n_obs = nrow(data))
  ),
  method_metadata = list(
    estimator = "Fuzzy local-linear RD; triangular weights; bandwidth 1",
    vcov = "Joint heteroskedasticity-robust HC0; delta method"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = NA)
