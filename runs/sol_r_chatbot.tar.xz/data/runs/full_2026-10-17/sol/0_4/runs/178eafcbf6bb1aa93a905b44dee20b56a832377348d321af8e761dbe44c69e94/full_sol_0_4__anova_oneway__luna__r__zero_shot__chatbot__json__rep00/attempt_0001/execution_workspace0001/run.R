dat <- read.csv("./input.csv", stringsAsFactors = FALSE)
dat <- dat[complete.cases(dat[c("group", "y")]), c("group", "y")]
dat$group <- factor(dat$group)

fit <- aov(y ~ group, data = dat)
tab <- summary(fit)[[1]]

values <- c(
  F = tab["group", "F value"],
  df_num = tab["group", "Df"],
  df_den = tab["Residuals", "Df"],
  p_value = tab["group", "Pr(>F)"]
)

estimates <- lapply(names(values), function(term) {
  list(
    term = term,
    estimate = unname(as.numeric(values[term])),
    se = NULL,
    n_obs = as.integer(nrow(dat))
  )
})

result <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "one-way ANOVA",
    vcov = "classical"
  ),
  diagnostics = list()
)

jsonlite::write_json(
  result,
  path = "result.json",
  auto_unbox = TRUE,
  digits = 16,
  null = "null"
)
