library(jsonlite)

task_id <- "applied_nonrecipient_population_iv"

households <- read.csv("households.csv")
census <- read.csv("census.csv")
d <- households[!is.na(households$recipient) & households$recipient == 0, ]

required <- c("eligible", "dose", "instrument", "baseline", "weight", "outcome")
if (!all(complete.cases(d[, required]))) {
  stop("Required estimation variables contain missing values.")
}
if (!all(d$eligible %in% c(0, 1)) || any(d$weight <= 0)) {
  stop("Invalid eligibility indicator or observation weight.")
}
if (!identical(sort(census$eligible), c(0L, 1L)) ||
    any(census$nonrecipient_population < 0) ||
    sum(census$nonrecipient_population) <= 0) {
  stop("Census must contain one valid row for each eligibility group.")
}

g0 <- 1 - d$eligible
g1 <- d$eligible

C <- cbind(
  ineligible = g0,
  eligible = g1,
  baseline_ineligible = d$baseline * g0,
  baseline_eligible = d$baseline * g1
)
X <- cbind(
  C,
  dose_ineligible = d$dose * g0,
  dose_eligible = d$dose * g1
)
Z <- cbind(
  C,
  instrument_ineligible = d$instrument * g0,
  instrument_eligible = d$instrument * g1
)

sqrt_weight <- sqrt(d$weight)
Xw <- X * sqrt_weight
Zw <- Z * sqrt_weight
yw <- d$outcome * sqrt_weight

instrument_qr <- qr(Zw)
if (instrument_qr$rank != ncol(Zw)) {
  stop("Instrument matrix is rank deficient.")
}
fitted_Xw <- qr.fitted(instrument_qr, Xw)
second_stage_qr <- qr(fitted_Xw)
if (second_stage_qr$rank != ncol(Xw)) {
  stop("Weighted 2SLS model is unidentified.")
}
slopes <- qr.coef(second_stage_qr, yw)

mean_dose <- vapply(0:1, function(group) {
  rows <- d$eligible == group
  if (!any(rows)) stop("An eligibility group has no retained households.")
  weighted.mean(d$dose[rows], d$weight[rows])
}, numeric(1))

effects <- c(
  ineligible_effect = slopes["dose_ineligible"] * mean_dose[1],
  eligible_nonrecipient_effect = slopes["dose_eligible"] * mean_dose[2]
)
population_weights <- census$nonrecipient_population[
  match(0:1, census$eligible)
]
effects <- c(
  effects,
  population_effect = weighted.mean(
    unname(effects), population_weights
  )
)

n_obs <- nrow(d)
estimates <- lapply(names(effects), function(term) {
  list(
    term = term,
    estimate = unname(as.numeric(effects[[term]])),
    se = NULL,
    n_obs = as.integer(n_obs)
  )
})

result <- list(
  task_id = task_id,
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    method = "Weighted two-stage least squares",
    sample = "Households with recipient equal to zero",
    endogenous = c("dose_ineligible", "dose_eligible"),
    exogenous = colnames(C),
    excluded_instruments = c(
      "instrument_ineligible", "instrument_eligible"
    ),
    intercept = "Eligibility indicators supply group intercepts; no other intercept",
    counterfactual = "Dose is zero for every retained household",
    group_effect = "Fitted group dose slope times household-weighted group mean dose",
    population_aggregation = "Census nonrecipient_population weights group effects"
  ),
  diagnostics = list(
    n_obs = as.integer(n_obs),
    n_ineligible = as.integer(sum(d$eligible == 0)),
    n_eligible = as.integer(sum(d$eligible == 1)),
    instrument_rank = as.integer(instrument_qr$rank),
    second_stage_rank = as.integer(second_stage_qr$rank)
  )
)

write_json(
  result,
  path = "result.json",
  auto_unbox = TRUE,
  pretty = TRUE,
  digits = 16,
  null = "null"
)
