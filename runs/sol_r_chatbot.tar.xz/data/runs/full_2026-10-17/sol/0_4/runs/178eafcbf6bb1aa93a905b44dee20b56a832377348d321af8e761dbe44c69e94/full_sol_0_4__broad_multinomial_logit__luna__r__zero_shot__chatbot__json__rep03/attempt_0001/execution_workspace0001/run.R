d <- read.csv("input.csv")
X <- cbind("(Intercept)" = 1, x = d$x, z = d$z)
y <- as.integer(as.character(d$y))
stopifnot(all(y %in% 0:2), all(is.finite(X)))
n <- nrow(X)
k <- ncol(X)

fit_values <- function(theta) {
  eta1 <- drop(X %*% theta[1:k])
  eta2 <- drop(X %*% theta[(k + 1):(2 * k)])
  m <- pmax(0, eta1, eta2)
  denom <- exp(-m) + exp(eta1 - m) + exp(eta2 - m)
  list(
    logdenom = m + log(denom),
    p1 = exp(eta1 - m) / denom,
    p2 = exp(eta2 - m) / denom
  )
}

objective <- function(theta) {
  v <- fit_values(theta)
  -sum((y == 1) * drop(X %*% theta[1:k]) +
       (y == 2) * drop(X %*% theta[(k + 1):(2 * k)]) -
       v$logdenom)
}

gradient <- function(theta) {
  v <- fit_values(theta)
  -c(drop(crossprod(X, (y == 1) - v$p1)),
     drop(crossprod(X, (y == 2) - v$p2)))
}

fit <- optim(rep(0, 2 * k), objective, gradient, method = "BFGS",
             control = list(reltol = 1e-12, maxit = 10000))
stopifnot(fit$convergence == 0)

v <- fit_values(fit$par)
h11 <- crossprod(X, X * (v$p1 * (1 - v$p1)))
h22 <- crossprod(X, X * (v$p2 * (1 - v$p2)))
h12 <- -crossprod(X, X * (v$p1 * v$p2))
information <- rbind(cbind(h11, h12), cbind(t(h12), h22))
se <- sqrt(diag(solve(information)))

eta1_zero <- fit$par[1]
eta2_zero <- fit$par[k + 1]
m_zero <- max(0, eta1_zero, eta2_zero)
prob2_zero <- exp(eta2_zero - m_zero) /
  sum(exp(c(0, eta1_zero, eta2_zero) - m_zero))

number <- function(x) sprintf("%.15g", x)
row <- function(term, estimate, standard_error) {
  se_json <- if (is.null(standard_error)) "null" else number(standard_error)
  sprintf(
    '{"term":"%s","estimate":%s,"se":%s,"n_obs":%d}',
    term, number(estimate), se_json, n
  )
}

rows <- c(
  row("x_cat1", fit$par[2], se[2]),
  row("z_cat1", fit$par[3], se[3]),
  row("x_cat2", fit$par[k + 2], se[k + 2]),
  row("z_cat2", fit$par[k + 3], se[k + 3]),
  row("prob_cat2_zero", prob2_zero, NULL)
)

json <- paste0(
  '{"task_id":"broad_multinomial_logit","platform":"r","estimates":[',
  paste(rows, collapse = ","),
  '],"method_metadata":{"estimator":"multinomial logit maximum likelihood",',
  '"vcov":"inverse observed information"},"diagnostics":{}}'
)
writeLines(json, "result.json")
