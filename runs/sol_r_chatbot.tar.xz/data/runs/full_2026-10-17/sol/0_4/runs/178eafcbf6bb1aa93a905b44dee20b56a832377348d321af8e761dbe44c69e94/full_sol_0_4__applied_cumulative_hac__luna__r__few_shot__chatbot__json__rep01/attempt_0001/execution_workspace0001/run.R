library(jsonlite)

data <- read.csv("input.csv")
data <- data[order(as.Date(data$date)), ]

change <- c(NA_real_, diff(log(data$vix)))
lagged <- sapply(1:15, function(k) {
  c(rep(NA_real_, k), head(change, -k))
})
colnames(lagged) <- paste0("lag_", 1:15)

sample <- data.frame(log_sales = log(data$sales), lagged)
sample <- sample[complete.cases(sample), ]

fit <- lm(log_sales ~ ., data = sample)
X <- model.matrix(fit)
beta <- coef(fit)
N <- nrow(X)
p <- ncol(X)

scores <- X * as.numeric(residuals(fit))
meat <- crossprod(scores)
for (j in 1:15) {
  product <- crossprod(
    scores[(j + 1):N, , drop = FALSE],
    scores[1:(N - j), , drop = FALSE]
  )
  meat <- meat + (1 - j / 16) * (product + t(product))
}

bread <- solve(crossprod(X))
V <- (N / (N - p)) * bread %*% meat %*% bread

contrast <- c(0, rep(1, 15))
cumulative <- sum(contrast * beta)
cumulative_se <- sqrt(drop(t(contrast) %*% V %*% contrast))

row <- function(term, estimate, se) {
  list(
    term = term,
    estimate = unname(as.numeric(estimate)),
    se = unname(as.numeric(se)),
    n_obs = as.integer(N)
  )
}

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    row("cumulative_response", cumulative, cumulative_se),
    row("lag_1", beta["lag_1"], sqrt(V["lag_1", "lag_1"])),
    row("lag_15", beta["lag_15"], sqrt(V["lag_15", "lag_15"]))
  ),
  method_metadata = list(
    estimator = "OLS with intercept and 15 lagged log VIX changes",
    vcov = "Newey-West HAC, Bartlett weights, maximum lag 15, N/(N-16) correction"
  ),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, digits = 16, pretty = TRUE)
