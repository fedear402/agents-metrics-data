library(jsonlite)

households <- read.csv("households.csv")
census <- read.csv("census.csv")

sample <- households[households$recipient == 0, ]
n_obs <- nrow(sample)

ineligible <- 1 - sample$eligible
eligible <- sample$eligible

X <- cbind(
  ineligible = ineligible,
  eligible = eligible,
  baseline_ineligible = sample$baseline * ineligible,
  baseline_eligible = sample$baseline * eligible,
  dose_ineligible = sample$dose * ineligible,
  dose_eligible = sample$dose * eligible
)

Z <- cbind(
  X[, 1:4, drop = FALSE],
  instrument_ineligible = sample$instrument * ineligible,
  instrument_eligible = sample$instrument * eligible
)

w <- sample$weight
y <- sample$outcome
zwz <- crossprod(Z, w * Z)
zwx <- crossprod(Z, w * X)
zwy <- crossprod(Z, w * y)

beta <- solve(crossprod(zwx, solve(zwz, zwx)),
              crossprod(zwx, solve(zwz, zwy)))

mean_dose <- function(group) {
  rows <- sample$eligible == group
  weighted.mean(sample$dose[rows], w[rows])
}

ineligible_effect <- unname(beta["dose_ineligible", 1]) * mean_dose(0)
eligible_nonrecipient_effect <- unname(beta["dose_eligible", 1]) * mean_dose(1)

population <- aggregate(nonrecipient_population ~ eligible, census, sum)
population <- population[match(c(0, 1), population$eligible), ]
population_effect <- weighted.mean(
  c(ineligible_effect, eligible_nonrecipient_effect),
  population$nonrecipient_population
)

estimate <- function(term, value) {
  list(term = term, estimate = unname(as.numeric(value)), se = NULL,
       n_obs = as.integer(n_obs))
}

result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = list(
    estimate("ineligible_effect", ineligible_effect),
    estimate("eligible_nonrecipient_effect", eligible_nonrecipient_effect),
    estimate("population_effect", population_effect)
  ),
  method_metadata = list(
    estimator = "weighted two-stage least squares",
    sample = "households with recipient equal to zero",
    regression_weight = "weight",
    intercept = "none beyond the two eligibility-group columns",
    group_effect = "fitted group dose slope times household-weighted mean dose",
    counterfactual = "dose set to zero for every retained household; synthetic attribution convention",
    population_aggregation = "census nonrecipient_population weights only the final between-group average"
  ),
  diagnostics = list(
    n_obs = as.integer(n_obs),
    ineligible_n = as.integer(sum(sample$eligible == 0)),
    eligible_nonrecipient_n = as.integer(sum(sample$eligible == 1)),
    instrument_rank = as.integer(qr(Z * sqrt(w))$rank)
  )
)

write_json(result, "result.json", auto_unbox = TRUE, digits = NA,
           null = "null", pretty = TRUE)
