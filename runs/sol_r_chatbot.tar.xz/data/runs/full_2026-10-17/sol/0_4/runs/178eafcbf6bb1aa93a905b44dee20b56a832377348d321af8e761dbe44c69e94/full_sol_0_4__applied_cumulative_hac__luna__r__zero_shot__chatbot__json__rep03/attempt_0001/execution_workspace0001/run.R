d <- read.csv("input.csv", stringsAsFactors = FALSE)
d <- d[order(as.Date(d$date)), ]

delta <- c(NA_real_, diff(log(d$vix)))
lagged <- sapply(1:15, function(k) {
  c(rep(NA_real_, k), head(delta, -k))
})
colnames(lagged) <- paste0("lag_", 1:15)

model_data <- data.frame(log_sales = log(d$sales), lagged)
model_data <- model_data[complete.cases(model_data), ]

fit <- lm(log_sales ~ ., data = model_data)
X <- model.matrix(fit)
e <- residuals(fit)
N <- nrow(X)
p <- ncol(X)

# Newey-West covariance with Bartlett weights and N/(N - 16) correction.
Xe <- X * as.numeric(e)
meat <- crossprod(Xe)
for (j in 1:15) {
  cross_lag <- crossprod(Xe[(j + 1):N, , drop = FALSE],
                         Xe[1:(N - j), , drop = FALSE])
  meat <- meat + (1 - j / 16) * (cross_lag + t(cross_lag))
}
bread <- solve(crossprod(X))
V <- (N / (N - p)) * bread %*% meat %*% bread

b <- coef(fit)
terms <- paste0("lag_", 1:15)
cumulative <- sum(b[terms])
cumulative_se <- sqrt(sum(V[terms, terms]))

estimates <- list(
  list(term = "cumulative_response", estimate = unname(cumulative),
       se = unname(cumulative_se), n_obs = N),
  list(term = "lag_1", estimate = unname(b["lag_1"]),
       se = unname(sqrt(V["lag_1", "lag_1"])), n_obs = N),
  list(term = "lag_15", estimate = unname(b["lag_15"]),
       se = unname(sqrt(V["lag_15", "lag_15"])), n_obs = N)
)

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "OLS with intercept and 15 lagged log VIX changes",
    vcov = "Newey-West HAC, Bartlett weights, maximum lag 15, N/(N-16) correction"
  ),
  diagnostics = list()
)

writeLines(jsonlite::toJSON(result, auto_unbox = TRUE, digits = 16),
           "result.json")
