dat <- read.csv("./input.csv")
dat <- dat[order(dat$t), ]

if (anyNA(dat$t) || anyNA(dat$y) || anyDuplicated(dat$t)) {
  stop("t and y must have no missing values, and t must be unique.")
}
if (tail(dat$t, 1) != 250) {
  stop("The final observation must be at t = 250.")
}

y <- as.numeric(dat$y)
fit <- stats::arima(
  y,
  order = c(1, 1, 1),
  include.mean = FALSE,
  method = "ML"
)

pred <- stats::predict(fit, n.ahead = 1)
forecast <- as.numeric(pred$pred[1])
se <- as.numeric(pred$se[1])
critical <- stats::qnorm(0.975)
lower <- forecast - critical * se
upper <- forecast + critical * se
n_obs <- length(y)

num <- function(x) sprintf("%.15g", x)

result <- sprintf(
  paste0(
    '{"task_id":"arima_forecast","platform":"r","estimates":[',
    '{"term":"forecast","estimate":%s,"se":%s,"n_obs":%d},',
    '{"term":"lower_95","estimate":%s,"se":null,"n_obs":%d},',
    '{"term":"upper_95","estimate":%s,"se":null,"n_obs":%d}',
    '],"method_metadata":{"estimator":"ARIMA(1,1,1) maximum likelihood, ',
    'no constant or drift","vcov":"Model-based forecast variance"},',
    '"diagnostics":{}}'
  ),
  num(forecast), num(se), n_obs,
  num(lower), n_obs,
  num(upper), n_obs
)

writeLines(result, "result.json")
