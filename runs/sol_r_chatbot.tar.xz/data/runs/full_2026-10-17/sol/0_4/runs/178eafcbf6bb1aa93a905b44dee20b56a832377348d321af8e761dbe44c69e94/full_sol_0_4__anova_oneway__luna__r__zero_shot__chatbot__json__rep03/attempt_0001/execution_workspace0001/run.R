data <- read.csv("./input.csv")
data <- data[complete.cases(data[, c("group", "y")]), ]
data$group <- factor(data$group)

fit <- aov(y ~ group, data = data)
anova_table <- summary(fit)[[1]]

values <- c(
  F = anova_table[1, "F value"],
  df_num = anova_table[1, "Df"],
  df_den = anova_table[2, "Df"],
  p_value = anova_table[1, "Pr(>F)"]
)

n_obs <- nobs(fit)
estimates <- lapply(names(values), function(term) {
  list(
    term = term,
    estimate = as.numeric(values[[term]]),
    se = NULL,
    n_obs = as.integer(n_obs)
  )
})

result <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "One-way ANOVA",
    vcov = "Classical homoskedastic"
  ),
  diagnostics = list()
)

jsonlite::write_json(
  result,
  path = "result.json",
  auto_unbox = TRUE,
  digits = NA,
  null = "null"
)
