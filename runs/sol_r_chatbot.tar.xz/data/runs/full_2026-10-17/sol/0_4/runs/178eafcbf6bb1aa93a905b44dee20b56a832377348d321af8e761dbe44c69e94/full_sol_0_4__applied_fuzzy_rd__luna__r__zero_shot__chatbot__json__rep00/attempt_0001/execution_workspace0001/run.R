dat <- read.csv("input.csv")

keep <- complete.cases(dat[, c("score", "participated", "earnings")]) &
  abs(dat$score) < 1
dat <- dat[keep, ]
n <- nrow(dat)

right <- as.numeric(dat$score >= 0)
X <- cbind(
  intercept = 1,
  right = right,
  score = dat$score,
  right_score = right * dat$score
)
w <- 1 - abs(dat$score)

bread <- solve(crossprod(X, w * X))
fit <- function(y) {
  beta <- bread %*% crossprod(X, w * y)
  residual <- as.numeric(y - X %*% beta)
  list(beta = beta, score = X * as.numeric(w * residual))
}

earnings_fit <- fit(dat$earnings)
participation_fit <- fit(dat$participated)

vcov_joint <- function(score_a, score_b) {
  bread %*% crossprod(score_a, score_b) %*% bread
}

rf <- as.numeric(earnings_fit$beta["right", 1])
fs <- as.numeric(participation_fit$beta["right", 1])
te <- rf / fs

var_rf <- vcov_joint(earnings_fit$score, earnings_fit$score)[2, 2]
var_fs <- vcov_joint(participation_fit$score, participation_fit$score)[2, 2]
cov_rf_fs <- vcov_joint(
  earnings_fit$score, participation_fit$score
)[2, 2]

var_te <- var_rf / fs^2 +
  rf^2 * var_fs / fs^4 -
  2 * rf * cov_rf_fs / fs^3

output <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = te,
         se = sqrt(max(0, var_te)), n_obs = n),
    list(term = "reduced_form", estimate = rf,
         se = sqrt(max(0, var_rf)), n_obs = n),
    list(term = "first_stage", estimate = fs,
         se = sqrt(max(0, var_fs)), n_obs = n)
  ),
  method_metadata = list(
    estimator = "Fuzzy local-linear regression discontinuity, triangular kernel, bandwidth 1",
    vcov = "Conventional HC0, fixed weights; joint covariance delta method"
  ),
  diagnostics = list()
)

jsonlite::write_json(output, "result.json", auto_unbox = TRUE, digits = 16)
