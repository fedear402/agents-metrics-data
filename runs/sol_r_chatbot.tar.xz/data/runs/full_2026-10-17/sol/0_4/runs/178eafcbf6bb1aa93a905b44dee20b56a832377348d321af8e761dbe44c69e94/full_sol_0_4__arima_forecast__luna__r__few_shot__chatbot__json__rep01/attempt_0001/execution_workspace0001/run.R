library(jsonlite)

dat <- read.csv("./input.csv")
y <- as.numeric(dat$y)
if (anyNA(y) || length(y) != 250L) {
  stop("Expected 250 non-missing observations of y.")
}

fit <- stats::arima(y, order = c(1, 1, 1), include.mean = FALSE,
                    method = "ML")
pred <- stats::predict(fit, n.ahead = 1L)

forecast <- as.numeric(pred$pred[1L])
forecast_se <- as.numeric(pred$se[1L])
margin <- stats::qnorm(0.975) * forecast_se

out <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = list(
    list(term = "forecast", estimate = forecast, se = forecast_se,
         n_obs = length(y)),
    list(term = "lower_95", estimate = forecast - margin, se = NULL,
         n_obs = length(y)),
    list(term = "upper_95", estimate = forecast + margin, se = NULL,
         n_obs = length(y))
  ),
  method_metadata = list(
    estimator = "ARIMA(1,1,1) maximum likelihood without constant or drift",
    vcov = "Model-based forecast variance"
  ),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "result.json", auto_unbox = TRUE, digits = NA)
