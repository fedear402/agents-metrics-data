data <- read.csv("input.csv", stringsAsFactors = FALSE)
data <- data[order(as.Date(data$date)), ]

change <- c(NA_real_, diff(log(data$vix)))
lag_count <- 15L
n <- nrow(data)

X_all <- sapply(seq_len(lag_count), function(k) {
  c(rep(NA_real_, k), head(change, n - k))
})
colnames(X_all) <- paste0("lag_", seq_len(lag_count))

regression_data <- data.frame(
  log_sales = log(data$sales),
  X_all,
  check.names = FALSE
)
regression_data <- regression_data[complete.cases(regression_data), ]

fit <- lm(log_sales ~ ., data = regression_data)
X <- model.matrix(fit)
beta <- coef(fit)
N <- nrow(X)
p <- ncol(X)

scores <- X * as.numeric(residuals(fit))
meat <- crossprod(scores)
for (j in seq_len(lag_count)) {
  product <- crossprod(
    scores[(j + 1L):N, , drop = FALSE],
    scores[seq_len(N - j), , drop = FALSE]
  )
  meat <- meat + (1 - j / (lag_count + 1L)) * (product + t(product))
}

bread <- solve(crossprod(X))
covariance <- (N / (N - p)) * bread %*% meat %*% bread

contrast <- c(0, rep(1, lag_count))
cumulative_estimate <- sum(contrast * beta)
cumulative_se <- sqrt(drop(t(contrast) %*% covariance %*% contrast))

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(
      term = "cumulative_response",
      estimate = unname(cumulative_estimate),
      se = unname(cumulative_se),
      n_obs = N
    ),
    list(
      term = "lag_1",
      estimate = unname(beta["lag_1"]),
      se = unname(sqrt(covariance["lag_1", "lag_1"])),
      n_obs = N
    ),
    list(
      term = "lag_15",
      estimate = unname(beta["lag_15"]),
      se = unname(sqrt(covariance["lag_15", "lag_15"])),
      n_obs = N
    )
  ),
  method_metadata = list(
    estimator = "OLS with intercept and 15 lagged log(vix) changes",
    vcov = "Newey-West Bartlett HAC, maximum lag 15, corrected by N/(N-16)"
  ),
  diagnostics = list()
)

jsonlite::write_json(
  result, "result.json",
  auto_unbox = TRUE, digits = 16, pretty = TRUE
)
