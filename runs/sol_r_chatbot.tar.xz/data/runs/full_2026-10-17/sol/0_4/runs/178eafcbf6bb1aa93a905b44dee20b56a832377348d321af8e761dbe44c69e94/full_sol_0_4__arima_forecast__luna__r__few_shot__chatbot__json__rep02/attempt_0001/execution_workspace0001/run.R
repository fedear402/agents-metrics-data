library(jsonlite)

dat <- read.csv("./input.csv")
y <- as.numeric(dat$y)
if (anyNA(y)) stop("Column y contains missing or nonnumeric values.")

fit <- stats::arima(y, order = c(1, 1, 1), include.mean = FALSE,
                    method = "ML")
pred <- stats::predict(fit, n.ahead = 1)

forecast <- as.numeric(pred$pred[1])
se <- as.numeric(pred$se[1])
critical_value <- stats::qnorm(0.975)
n_obs <- length(y)

out <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = list(
    list(term = "forecast", estimate = forecast, se = se, n_obs = n_obs),
    list(term = "lower_95", estimate = forecast - critical_value * se,
         se = NULL, n_obs = n_obs),
    list(term = "upper_95", estimate = forecast + critical_value * se,
         se = NULL, n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "ARIMA(1,1,1) maximum likelihood without constant or drift",
    vcov = "Model-based forecast variance"
  ),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "result.json", auto_unbox = TRUE, digits = NA)
