d <- read.csv("input.csv")
stopifnot(all(c("y", "endog", "x", "z1", "z2") %in% names(d)))
stopifnot(all(complete.cases(d[c("y", "endog", "x", "z1", "z2")])))

n <- nrow(d)
q <- 2L
df <- n - 4L
critical <- qf(0.95, q, df)
k <- q * critical / df

restricted <- cbind(1, d$x)
unrestricted <- cbind(1, d$x, d$z1, d$z2)
stopifnot(qr(restricted)$rank == 2L, qr(unrestricted)$rank == 4L)

ry <- qr.resid(qr(restricted), d$y)
rd <- qr.resid(qr(restricted), d$endog)
uy <- qr.resid(qr(unrestricted), d$y)
ud <- qr.resid(qr(unrestricted), d$endog)

A <- sum(rd^2) - (1 + k) * sum(ud^2)
B <- -2 * (sum(ry * rd) - (1 + k) * sum(uy * ud))
C <- sum(ry^2) - (1 + k) * sum(uy^2)

discriminant <- B^2 - 4 * A * C
stopifnot(is.finite(discriminant), discriminant > 0, A != 0)
bounds <- sort(c(
  (-B - sqrt(discriminant)) / (2 * A),
  (-B + sqrt(discriminant)) / (2 * A)
))

restricted_ssr_one <- sum((ry - rd)^2)
unrestricted_ssr_one <- sum((uy - ud)^2)
ar_f_at_one <- ((restricted_ssr_one - unrestricted_ssr_one) / q) /
  (unrestricted_ssr_one / df)

terms <- c(
  "boundary_low", "boundary_high", "accepts_zero",
  "unbounded", "ar_f_at_one"
)
values <- c(
  bounds[1], bounds[2], as.integer(C <= 0),
  as.integer(A < 0), ar_f_at_one
)
stopifnot(all(is.finite(values)))

estimates <- Map(
  function(term, estimate) {
    list(term = term, estimate = unname(estimate), se = NULL, n_obs = n)
  },
  terms, values
)

jsonlite::write_json(
  list(
    task_id = "broad_ar_confidence_set",
    platform = "r",
    estimates = estimates,
    method_metadata = list(
      estimator = "Anderson-Rubin test inversion",
      vcov = "Conventional homoskedastic joint F test"
    ),
    diagnostics = list()
  ),
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
