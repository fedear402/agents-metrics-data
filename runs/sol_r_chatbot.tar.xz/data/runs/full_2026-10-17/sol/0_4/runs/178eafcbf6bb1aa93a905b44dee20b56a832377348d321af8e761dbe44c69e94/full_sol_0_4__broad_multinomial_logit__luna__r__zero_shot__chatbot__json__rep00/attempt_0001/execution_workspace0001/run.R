library(nnet)

dat <- read.csv("input.csv")
dat$y <- factor(dat$y, levels = c(0, 1, 2))
n_obs <- nrow(dat)

fit <- multinom(y ~ x + z, data = dat, Hess = TRUE, trace = FALSE)
beta <- coef(fit)
se <- summary(fit)$standard.errors

p2_zero <- as.numeric(predict(
  fit,
  newdata = data.frame(x = 0, z = 0),
  type = "probs"
)[, "2"])

rows <- list(
  list("x_cat1", beta["1", "x"], se["1", "x"]),
  list("z_cat1", beta["1", "z"], se["1", "z"]),
  list("x_cat2", beta["2", "x"], se["2", "x"]),
  list("z_cat2", beta["2", "z"], se["2", "z"]),
  list("prob_cat2_zero", p2_zero, NULL)
)

fmt <- function(x) sprintf("%.15g", x)

entries <- vapply(rows, function(row) {
  se_value <- if (is.null(row[[3]])) "null" else fmt(row[[3]])
  sprintf(
    '{"term":"%s","estimate":%s,"se":%s,"n_obs":%d}',
    row[[1]], fmt(row[[2]]), se_value, n_obs
  )
}, character(1))

json <- paste0(
  '{"task_id":"broad_multinomial_logit","platform":"r","estimates":[',
  paste(entries, collapse = ","),
  '],"method_metadata":{"estimator":"multinomial logit maximum likelihood",',
  '"vcov":"inverse observed information"},"diagnostics":{}}'
)

writeLines(json, "result.json")
