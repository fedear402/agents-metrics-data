d <- read.csv("input.csv")
d$y <- factor(d$y, levels = 0:2)
n_obs <- nrow(d)

fit <- nnet::multinom(
  y ~ x + z,
  data = d,
  Hess = TRUE,
  trace = FALSE,
  maxit = 1000,
  reltol = 1e-12,
  abstol = 1e-12
)

B <- coef(fit)
V <- vcov(fit)
se <- function(category, variable) {
  sqrt(V[paste0(category, ":", variable), paste0(category, ":", variable)])
}

indices <- c(0, B["1", "(Intercept)"], B["2", "(Intercept)"])
probabilities <- exp(indices - max(indices))
probabilities <- probabilities / sum(probabilities)

rows <- list(
  list(term = "x_cat1", estimate = unname(B["1", "x"]), se = se("1", "x"), n_obs = n_obs),
  list(term = "z_cat1", estimate = unname(B["1", "z"]), se = se("1", "z"), n_obs = n_obs),
  list(term = "x_cat2", estimate = unname(B["2", "x"]), se = se("2", "x"), n_obs = n_obs),
  list(term = "z_cat2", estimate = unname(B["2", "z"]), se = se("2", "z"), n_obs = n_obs),
  list(term = "prob_cat2_zero", estimate = unname(probabilities[3]), se = NULL, n_obs = n_obs)
)

jsonlite::write_json(
  list(
    task_id = "broad_multinomial_logit",
    platform = "r",
    estimates = rows,
    method_metadata = list(
      estimator = "Multinomial logit maximum likelihood, base outcome 0",
      vcov = "Inverse observed information"
    ),
    diagnostics = list()
  ),
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
