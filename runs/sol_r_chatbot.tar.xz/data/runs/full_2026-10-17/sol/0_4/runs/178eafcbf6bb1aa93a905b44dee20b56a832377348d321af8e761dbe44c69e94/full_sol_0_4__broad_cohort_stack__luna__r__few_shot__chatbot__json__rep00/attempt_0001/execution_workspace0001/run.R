d <- read.csv("./input.csv")

estimate_cohort <- function(c) {
  window <- (c - 2):(c + 2)
  x <- subset(d, time %in% window & (g == c | g == 0 | g > c + 2))

  counts <- table(x$id)
  balanced_ids <- names(counts[counts == length(window)])
  x <- x[as.character(x$id) %in% balanced_ids, ]

  x$did <- as.integer(x$g == c & x$time >= c)
  fit <- lm(y ~ did + factor(id) + factor(time), data = x)

  list(
    estimate = unname(coef(fit)[["did"]]),
    n_obs = nrow(x),
    n_treated = length(unique(x$id[x$g == c]))
  )
}

cohorts <- c(3, 5, 7)
results <- lapply(cohorts, estimate_cohort)
effects <- vapply(results, `[[`, numeric(1), "estimate")
row_counts <- vapply(results, `[[`, integer(1), "n_obs")
weights <- vapply(results, `[[`, integer(1), "n_treated")

make_row <- function(term, estimate, n_obs) {
  list(term = term, estimate = estimate, se = NULL, n_obs = n_obs)
}

out <- list(
  task_id = "broad_cohort_stack",
  platform = "r",
  estimates = c(
    Map(make_row, paste0("att_g", cohorts), effects, row_counts),
    list(make_row("att_weighted", weighted.mean(effects, weights), sum(row_counts)))
  ),
  method_metadata = list(),
  diagnostics = list()
)

jsonlite::write_json(
  out, "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16
)
