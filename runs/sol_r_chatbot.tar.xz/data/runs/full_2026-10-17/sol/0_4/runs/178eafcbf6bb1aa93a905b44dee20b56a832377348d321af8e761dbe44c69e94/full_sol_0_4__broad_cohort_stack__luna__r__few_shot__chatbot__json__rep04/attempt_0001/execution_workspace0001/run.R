library(jsonlite)

d <- read.csv("input.csv")

estimate_cohort <- function(c) {
  window <- (c - 2):(c + 2)
  x <- d[
    d$time %in% window &
      (d$g == c | d$g == 0 | d$g > c + 2),
  ]

  counts <- table(x$id)
  balanced_ids <- names(counts)[counts == length(window)]
  x <- x[as.character(x$id) %in% balanced_ids, ]
  x$did <- as.numeric(x$g == c & x$time >= c)

  list(
    estimate = unname(coef(lm(y ~ did + factor(id) + factor(time), data = x))[["did"]]),
    n_obs = nrow(x),
    treated_units = length(unique(x$id[x$g == c]))
  )
}

cohorts <- c(3, 5, 7)
results <- lapply(cohorts, estimate_cohort)
weights <- vapply(results, `[[`, numeric(1), "treated_units")
effects <- vapply(results, `[[`, numeric(1), "estimate")
row_counts <- vapply(results, `[[`, integer(1), "n_obs")

estimates <- lapply(seq_along(cohorts), function(i) {
  list(
    term = paste0("att_g", cohorts[i]),
    estimate = effects[i],
    se = NULL,
    n_obs = row_counts[i]
  )
})

estimates[[4]] <- list(
  term = "att_weighted",
  estimate = weighted.mean(effects, weights),
  se = NULL,
  n_obs = sum(row_counts)
)

out <- list(
  task_id = "broad_cohort_stack",
  platform = "r",
  estimates = estimates,
  method_metadata = list(),
  diagnostics = list()
)

jsonlite::write_json(
  out, "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16
)
