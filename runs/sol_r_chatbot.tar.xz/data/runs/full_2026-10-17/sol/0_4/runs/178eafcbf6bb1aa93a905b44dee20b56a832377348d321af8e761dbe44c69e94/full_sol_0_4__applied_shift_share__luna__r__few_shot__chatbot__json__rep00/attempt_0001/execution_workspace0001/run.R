library(jsonlite)

d <- read.csv("input.csv", stringsAsFactors = FALSE)
regions <- unique(d$region_id)
industries <- unique(d$industry_id)
R <- length(regions)
N <- length(industries)

ri <- match(d$region_id, regions)
ni <- match(d$industry_id, industries)
first_row <- match(regions, d$region_id)

w <- d$region_weight[first_row]
e <- w / sum(w)
x <- d$x[first_row]
y <- d$y[first_row]
shock <- d$shock[match(industries, d$industry_id)]

shares <- matrix(0, nrow = R, ncol = N)
shares[cbind(ri, ni)] <- d$share

z <- drop(shares %*% shock)
center <- function(v) v - sum(e * v)
y0 <- center(y)
x0 <- center(x)
z0 <- center(z)

s <- drop(crossprod(e, shares))
aggregate_shocks <- function(v) drop(crossprod(shares, e * v)) / s
ybar <- aggregate_shocks(y0)
xbar <- aggregate_shocks(x0)
zbar <- aggregate_shocks(z0)

shock_iv <- function(dependent, endogenous) {
  X <- cbind(intercept = 1, slope = endogenous)
  Z <- cbind(intercept = 1, shock = shock)
  cross <- crossprod(Z, s * X)
  beta <- solve(cross, crossprod(Z, s * dependent))
  residual <- drop(dependent - X %*% beta)
  scores <- Z * (s * residual)
  inverse <- solve(cross)
  vcov <- (N / (N - 2)) * inverse %*%
    crossprod(scores) %*% t(inverse)
  c(estimate = unname(beta[2]), se = sqrt(vcov[2, 2]))
}

effect <- shock_iv(ybar, xbar)
first_stage <- shock_iv(xbar, zbar)

regional_effect <- sum(e * z0 * y0) / sum(e * z0 * x0)
regional_first_stage <- sum(e * z0 * x0) / sum(e * z0^2)
stopifnot(
  isTRUE(all.equal(unname(effect["estimate"]), regional_effect,
                   tolerance = 1e-8)),
  isTRUE(all.equal(unname(first_stage["estimate"]), regional_first_stage,
                   tolerance = 1e-8))
)

row <- function(term, estimate, se) {
  list(term = term, estimate = unname(as.numeric(estimate)),
       se = if (is.null(se)) NULL else unname(as.numeric(se)),
       n_obs = N)
}

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    row("effect", effect["estimate"], effect["se"]),
    row("first_stage", first_stage["estimate"], first_stage["se"]),
    row("effective_shocks", 1 / sum(s^2), NULL)
  ),
  method_metadata = list(
    estimator = "Weighted regional 2SLS with BHJ shock-level IV aggregation",
    vcov = "Shock-level heteroskedasticity-robust HC1, N/(N-2)"
  ),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null",
           digits = 16, pretty = TRUE)
