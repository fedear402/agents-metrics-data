library(jsonlite)

data <- read.csv("input.csv")
data <- data[!is.na(data$score) & abs(data$score) < 1, ]
data <- data[complete.cases(data[, c("earnings", "participated")]), ]

score <- data$score
right <- as.numeric(score >= 0)
weights <- 1 - abs(score)
X <- cbind(left_intercept = 1 - right,
           right_intercept = right,
           left_slope = score * (1 - right),
           right_slope = score * right)
Y <- cbind(data$earnings, data$participated)

bread <- solve(crossprod(X, weights * X))
coefficients <- bread %*% crossprod(X, weights * Y)
residuals <- Y - X %*% coefficients

contrast <- c(-1, 1, 0, 0)
jumps <- drop(contrast %*% coefficients)
loading <- weights * drop(X %*% bread %*% contrast)
influence <- residuals * loading
joint_covariance <- crossprod(influence)

reduced_form <- jumps[1]
first_stage <- jumps[2]
treatment_effect <- reduced_form / first_stage
gradient <- c(1 / first_stage, -reduced_form / first_stage^2)

n_obs <- nrow(data)
row <- function(term, estimate, se) {
  list(term = term, estimate = unname(as.numeric(estimate)),
       se = unname(as.numeric(se)), n_obs = as.integer(n_obs))
}

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    row("treatment_effect", treatment_effect,
        sqrt(drop(t(gradient) %*% joint_covariance %*% gradient))),
    row("reduced_form", reduced_form, sqrt(joint_covariance[1, 1])),
    row("first_stage", first_stage, sqrt(joint_covariance[2, 2]))
  ),
  method_metadata = list(
    estimator = "Fuzzy regression discontinuity, triangular-weighted local linear Wald ratio",
    vcov = "Joint heteroskedasticity-robust HC0 delta method"
  ),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, digits = 16,
           pretty = TRUE, null = "null")
