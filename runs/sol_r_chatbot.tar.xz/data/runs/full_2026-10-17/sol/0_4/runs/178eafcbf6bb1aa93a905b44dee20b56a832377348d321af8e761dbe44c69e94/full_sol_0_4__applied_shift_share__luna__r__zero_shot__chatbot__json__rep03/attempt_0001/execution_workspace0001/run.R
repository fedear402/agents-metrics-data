d <- read.csv("input.csv", stringsAsFactors = FALSE)

regions <- unique(d$region_id)
industries <- unique(d$industry_id)
r <- match(d$region_id, regions)
n <- match(d$industry_id, industries)
R <- length(regions)
N <- length(industries)

region_value <- function(column) {
  v <- column[match(regions, d$region_id)]
  stopifnot(all(column == v[r]))
  as.numeric(v)
}

industry_value <- function(column) {
  v <- column[match(industries, d$industry_id)]
  stopifnot(all(column == v[n]))
  as.numeric(v)
}

share <- as.numeric(d$share)
shock <- industry_value(d$shock)
weight <- region_value(d$region_weight)
x <- region_value(d$x)
y <- region_value(d$y)

stopifnot(
  N > 2L,
  all(is.finite(c(share, shock, weight, x, y))),
  all(weight > 0),
  all(share >= 0),
  all(abs(as.numeric(rowsum(share, r, reorder = TRUE)) - 1) < 1e-8)
)

e <- weight / sum(weight)
z <- numeric(R)
for (i in seq_along(share)) {
  z[r[i]] <- z[r[i]] + share[i] * shock[n[i]]
}

center <- function(v) v - sum(e * v)
y0 <- center(y)
x0 <- center(x)
z0 <- center(z)

exposure <- e[r] * share
s <- as.numeric(rowsum(exposure, n, reorder = TRUE))
stopifnot(length(s) == N, all(s > 0))

shock_mean <- function(v0) {
  as.numeric(rowsum(exposure * v0[r], n, reorder = TRUE)) / s
}

ybar <- shock_mean(y0)
xbar <- shock_mean(x0)
zbar <- shock_mean(z0)

weighted_iv <- function(outcome, regressor, instrument, weights) {
  X <- cbind("(Intercept)" = 1, regressor = regressor)
  Z <- cbind("(Intercept)" = 1, instrument = instrument)
  A <- crossprod(Z, weights * X)
  beta <- solve(A, crossprod(Z, weights * outcome))
  residual <- as.numeric(outcome - X %*% beta)

  scores <- Z * as.numeric(weights * residual)
  meat <- crossprod(scores)
  Ainv <- solve(A)
  vcov <- (length(outcome) / (length(outcome) - 2)) *
    t(Ainv) %*% meat %*% Ainv

  list(slope = unname(beta[2]), se = sqrt(unname(vcov[2, 2])))
}

regional_effect <- weighted_iv(y, x, z, e)
regional_first <- weighted_iv(x, z, z, e)
shock_effect <- weighted_iv(ybar, xbar, shock, s)
shock_first <- weighted_iv(xbar, zbar, shock, s)

stopifnot(
  isTRUE(all.equal(regional_effect$slope, shock_effect$slope,
                   tolerance = 1e-8)),
  isTRUE(all.equal(regional_first$slope, shock_first$slope,
                   tolerance = 1e-8))
)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = regional_effect$slope,
         se = shock_effect$se, n_obs = N),
    list(term = "first_stage", estimate = regional_first$slope,
         se = shock_first$se, n_obs = N),
    list(term = "effective_shocks", estimate = 1 / sum(s^2),
         se = NULL, n_obs = N)
  ),
  method_metadata = list(
    estimator = "Weighted regional 2SLS; BHJ shock-level IV",
    vcov = "Shock-level heteroskedasticity-robust HC1, N/(N-2)"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = NA)
