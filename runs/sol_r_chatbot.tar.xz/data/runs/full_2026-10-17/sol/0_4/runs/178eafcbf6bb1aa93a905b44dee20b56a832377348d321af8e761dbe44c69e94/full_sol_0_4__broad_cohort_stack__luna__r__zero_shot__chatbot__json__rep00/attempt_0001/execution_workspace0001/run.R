dat <- read.csv("input.csv", stringsAsFactors = FALSE)

cohorts <- c(3L, 5L, 7L)

compare_cohort <- function(c, data) {
  window <- seq.int(c - 2L, c + 2L)

  eligible <- data[
    data$time %in% window &
      (data$g == c | data$g == 0 | data$g > c + 2L),
    ,
    drop = FALSE
  ]

  time_count <- tapply(eligible$time, eligible$id, function(x) length(unique(x)))
  balanced_ids <- names(time_count)[time_count == length(window)]
  comparison <- eligible[as.character(eligible$id) %in% balanced_ids, , drop = FALSE]

  comparison$did <- as.integer(comparison$g == c & comparison$time >= c)
  fit <- lm(y ~ did + factor(id) + factor(time), data = comparison)

  list(
    estimate = unname(as.numeric(coef(fit)["did"])),
    n_obs = nrow(comparison),
    n_treated = length(unique(comparison$id[comparison$g == c]))
  )
}

results <- lapply(cohorts, compare_cohort, data = dat)
estimates <- vapply(results, `[[`, numeric(1), "estimate")
row_counts <- vapply(results, `[[`, numeric(1), "n_obs")
treated_counts <- vapply(results, `[[`, numeric(1), "n_treated")

make_row <- function(term, estimate, n_obs) {
  list(
    term = term,
    estimate = as.numeric(estimate),
    se = NULL,
    n_obs = as.integer(n_obs)
  )
}

output <- list(
  task_id = "broad_cohort_stack",
  platform = "r",
  estimates = c(
    Map(make_row, paste0("att_g", cohorts), estimates, row_counts),
    list(make_row(
      "att_weighted",
      weighted.mean(estimates, treated_counts),
      sum(row_counts)
    ))
  ),
  method_metadata = list(),
  diagnostics = list()
)

jsonlite::write_json(
  output,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = NA,
  pretty = TRUE
)
