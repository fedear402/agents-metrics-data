library(jsonlite)

households <- read.csv("households.csv")
census <- read.csv("census.csv")

d <- households[!is.na(households$recipient) & households$recipient == 0, ]
n_obs <- nrow(d)

g0 <- as.numeric(d$eligible == 0)
g1 <- as.numeric(d$eligible == 1)

C <- cbind(
  ineligible = g0,
  eligible = g1,
  baseline_ineligible = d$baseline * g0,
  baseline_eligible = d$baseline * g1
)
X <- cbind(C, dose_ineligible = d$dose * g0, dose_eligible = d$dose * g1)
Z <- cbind(
  C,
  instrument_ineligible = d$instrument * g0,
  instrument_eligible = d$instrument * g1
)

sw <- sqrt(d$weight)
Xw <- X * sw
Zw <- Z * sw
yw <- d$outcome * sw

first_stage <- qr.fitted(qr(Zw), Xw)
coef <- qr.coef(qr(first_stage), yw)

mean_dose <- vapply(0:1, function(g) {
  rows <- d$eligible == g
  weighted.mean(d$dose[rows], d$weight[rows])
}, numeric(1))

effects <- c(
  ineligible_effect = unname(coef["dose_ineligible"] * mean_dose[1]),
  eligible_nonrecipient_effect = unname(coef["dose_eligible"] * mean_dose[2])
)

census_weights <- census$nonrecipient_population[
  match(0:1, census$eligible)
]
effects <- c(
  effects,
  population_effect = unname(weighted.mean(effects, census_weights))
)

estimates <- lapply(names(effects), function(term) {
  list(term = term, estimate = unname(effects[[term]]), se = NULL, n_obs = n_obs)
})

result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "weighted 2SLS",
    sample = "households with recipient equal to zero",
    counterfactual = "dose set to zero for every retained household",
    group_effect = "fitted group dose slope times household-weighted mean group dose",
    population_aggregation = "group effects weighted by census nonrecipient_population"
  ),
  diagnostics = list(
    n_obs = n_obs,
    group_n_obs = as.list(setNames(
      as.integer(c(sum(d$eligible == 0), sum(d$eligible == 1))),
      c("ineligible", "eligible")
    ))
  )
)

write_json(result, "result.json", auto_unbox = TRUE, pretty = TRUE, digits = NA)
