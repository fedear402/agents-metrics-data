library(jsonlite)

d <- read.csv("input.csv", stringsAsFactors = FALSE)

regions <- unique(d$region_id)
industries <- unique(d$industry_id)
R <- length(regions)
N <- length(industries)

region_index <- match(d$region_id, regions)
industry_index <- match(d$industry_id, industries)

region_value <- function(column) {
  value <- d[[column]][match(regions, d$region_id)]
  stopifnot(all(vapply(seq_len(R), function(r) {
    all(d[[column]][region_index == r] == value[r])
  }, logical(1))))
  as.numeric(value)
}

industry_shock <- d$shock[match(industries, d$industry_id)]
stopifnot(all(vapply(seq_len(N), function(n) {
  all(d$shock[industry_index == n] == industry_shock[n])
}, logical(1))))

shares <- matrix(0, nrow = R, ncol = N)
for (i in seq_len(nrow(d))) {
  shares[region_index[i], industry_index[i]] <-
    shares[region_index[i], industry_index[i]] + d$share[i]
}

stopifnot(max(abs(rowSums(shares) - 1)) < 1e-8)

weight <- region_value("region_weight")
e <- weight / sum(weight)
x <- region_value("x")
y <- region_value("y")
z <- drop(shares %*% industry_shock)

regional <- cbind(y = y, x = x, z = z)
centered <- sweep(regional, 2, drop(crossprod(e, regional)))

s <- drop(crossprod(e, shares))
stopifnot(all(s > 0), N > 2)

aggregated <- sweep(crossprod(shares, e * centered), 1, s, "/")

shock_iv <- function(dependent, endogenous) {
  X <- cbind(intercept = 1, endogenous = endogenous)
  Z <- cbind(intercept = 1, shock = industry_shock)
  cross <- crossprod(Z, s * X)
  inverse <- solve(cross)
  beta <- drop(inverse %*% crossprod(Z, s * dependent))
  residual <- drop(dependent - X %*% beta)
  scores <- Z * (s * residual)
  vcov <- (N / (N - 2)) * inverse %*%
    crossprod(scores) %*% t(inverse)
  c(estimate = beta[2], se = sqrt(vcov[2, 2]))
}

effect <- shock_iv(aggregated[, "y"], aggregated[, "x"])
first_stage <- shock_iv(aggregated[, "x"], aggregated[, "z"])

regional_effect <- sum(e * centered[, "z"] * centered[, "y"]) /
  sum(e * centered[, "z"] * centered[, "x"])
regional_first_stage <- sum(e * centered[, "z"] * centered[, "x"]) /
  sum(e * centered[, "z"]^2)

stopifnot(
  isTRUE(all.equal(unname(effect["estimate"]), regional_effect,
                   tolerance = 1e-8)),
  isTRUE(all.equal(unname(first_stage["estimate"]), regional_first_stage,
                   tolerance = 1e-8))
)

row <- function(term, estimate, se) {
  list(
    term = term,
    estimate = unname(as.numeric(estimate)),
    se = if (is.null(se)) NULL else unname(as.numeric(se)),
    n_obs = as.integer(N)
  )
}

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    row("effect", effect["estimate"], effect["se"]),
    row("first_stage", first_stage["estimate"], first_stage["se"]),
    row("effective_shocks", 1 / sum(s^2), NULL)
  ),
  method_metadata = list(
    estimator = "Weighted regional 2SLS with BHJ shock-level aggregation",
    vcov = "Shock-level heteroskedasticity-robust HC1, N/(N-2)"
  ),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null",
           digits = 16, pretty = TRUE)
