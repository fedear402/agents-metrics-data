library(jsonlite)

households <- read.csv("households.csv")
census <- read.csv("census.csv")

sample <- households[!is.na(households$recipient) & households$recipient == 0, ]
n_obs <- nrow(sample)

g0 <- as.numeric(sample$eligible == 0)
g1 <- as.numeric(sample$eligible == 1)

X <- cbind(
  ineligible = g0,
  eligible = g1,
  baseline_ineligible = sample$baseline * g0,
  baseline_eligible = sample$baseline * g1,
  dose_ineligible = sample$dose * g0,
  dose_eligible = sample$dose * g1
)

Z <- cbind(
  X[, 1:4, drop = FALSE],
  instrument_ineligible = sample$instrument * g0,
  instrument_eligible = sample$instrument * g1
)

w_sqrt <- sqrt(sample$weight)
Xw <- X * w_sqrt
Zw <- Z * w_sqrt
yw <- sample$outcome * w_sqrt

# Weighted two-stage least squares, with no additional intercept.
X_fitted <- Zw %*% qr.solve(Zw, Xw)
beta <- qr.solve(crossprod(X_fitted, Xw), crossprod(X_fitted, yw))

mean_dose_0 <- weighted.mean(sample$dose[g0 == 1], sample$weight[g0 == 1])
mean_dose_1 <- weighted.mean(sample$dose[g1 == 1], sample$weight[g1 == 1])

effect_0 <- as.numeric(beta["dose_ineligible"] * mean_dose_0)
effect_1 <- as.numeric(beta["dose_eligible"] * mean_dose_1)

pop_0 <- sum(census$nonrecipient_population[census$eligible == 0])
pop_1 <- sum(census$nonrecipient_population[census$eligible == 1])
population_effect <- (pop_0 * effect_0 + pop_1 * effect_1) / (pop_0 + pop_1)

result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = list(
    list(term = "ineligible_effect", estimate = effect_0, se = NA_real_,
         n_obs = as.integer(n_obs)),
    list(term = "eligible_nonrecipient_effect", estimate = effect_1,
         se = NA_real_, n_obs = as.integer(n_obs)),
    list(term = "population_effect", estimate = population_effect,
         se = NA_real_, n_obs = as.integer(n_obs))
  ),
  method_metadata = list(
    estimator = "weighted 2SLS",
    sample = "All household rows with recipient equal to zero",
    counterfactual = "Dose set to zero for every retained household; synthetic attribution convention",
    group_effect = "Fitted group dose slope times household-weighted mean dose",
    population_aggregation = "Group effects weighted by census nonrecipient_population"
  ),
  diagnostics = list(
    n_obs = as.integer(n_obs),
    weighted_mean_dose_ineligible = mean_dose_0,
    weighted_mean_dose_eligible = mean_dose_1,
    census_nonrecipient_population_ineligible = pop_0,
    census_nonrecipient_population_eligible = pop_1
  )
)

write_json(result, "result.json", auto_unbox = TRUE, na = "null", digits = 15)
