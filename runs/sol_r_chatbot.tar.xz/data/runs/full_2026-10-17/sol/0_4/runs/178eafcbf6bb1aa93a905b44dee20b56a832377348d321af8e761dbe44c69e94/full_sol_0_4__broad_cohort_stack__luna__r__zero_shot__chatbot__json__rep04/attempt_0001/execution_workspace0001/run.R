library(jsonlite)

data <- read.csv("input.csv")
cohorts <- c(3, 5, 7)
results <- vector("list", length(cohorts))
treated_counts <- numeric(length(cohorts))

for (i in seq_along(cohorts)) {
  c <- cohorts[i]
  window <- (c - 2):(c + 2)

  comparison <- data[
    data$time %in% window &
      (data$g == c | data$g == 0 | data$g > c + 2),
  ]

  complete_ids <- names(which(
    tapply(comparison$time, comparison$id, function(x) {
      length(unique(x)) == length(window)
    })
  ))
  comparison <- comparison[as.character(comparison$id) %in% complete_ids, ]
  comparison$did <- as.integer(comparison$g == c & comparison$time >= c)

  fit <- lm(y ~ did + factor(id) + factor(time), data = comparison)
  treated_counts[i] <- length(unique(comparison$id[comparison$g == c]))

  results[[i]] <- list(
    term = paste0("att_g", c),
    estimate = unname(coef(fit)[["did"]]),
    se = NULL,
    n_obs = nrow(comparison)
  )
}

estimates <- vapply(results, function(x) x$estimate, numeric(1))
row_counts <- vapply(results, function(x) x$n_obs, numeric(1))

results[[4]] <- list(
  term = "att_weighted",
  estimate = weighted.mean(estimates, treated_counts),
  se = NULL,
  n_obs = sum(row_counts)
)

write_json(
  list(
    task_id = "broad_cohort_stack",
    platform = "r",
    estimates = results,
    method_metadata = list(),
    diagnostics = list()
  ),
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16
)
