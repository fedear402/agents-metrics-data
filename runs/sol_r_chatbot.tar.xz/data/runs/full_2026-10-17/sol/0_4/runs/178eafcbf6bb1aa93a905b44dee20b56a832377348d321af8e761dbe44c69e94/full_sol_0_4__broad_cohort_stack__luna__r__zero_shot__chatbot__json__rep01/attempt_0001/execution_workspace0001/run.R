library(jsonlite)

data <- read.csv("input.csv")

cohorts <- c(3L, 5L, 7L)
results <- lapply(cohorts, function(c) {
  window <- seq.int(c - 2L, c + 2L)
  comparison <- data[
    data$time %in% window &
      (data$g == c | data$g == 0L | data$g > c + 2L),
  ]

  unit_counts <- table(comparison$id)
  balanced_ids <- names(unit_counts[unit_counts == length(window)])
  comparison <- comparison[as.character(comparison$id) %in% balanced_ids, ]

  comparison$did <- as.integer(comparison$g == c & comparison$time >= c)
  fit <- lm(y ~ did + factor(id) + factor(time), data = comparison)

  list(
    estimate = unname(coef(fit)[["did"]]),
    n_obs = nrow(comparison),
    n_treated = length(unique(comparison$id[comparison$g == c]))
  )
})

estimates <- vapply(results, `[[`, numeric(1), "estimate")
row_counts <- vapply(results, `[[`, integer(1), "n_obs")
treated_counts <- vapply(results, `[[`, integer(1), "n_treated")

output <- list(
  task_id = "broad_cohort_stack",
  platform = "r",
  estimates = c(
    lapply(seq_along(cohorts), function(i) {
      list(
        term = paste0("att_g", cohorts[i]),
        estimate = estimates[i],
        se = NULL,
        n_obs = row_counts[i]
      )
    }),
    list(list(
      term = "att_weighted",
      estimate = weighted.mean(estimates, treated_counts),
      se = NULL,
      n_obs = sum(row_counts)
    ))
  ),
  method_metadata = list(),
  diagnostics = list()
)

write_json(output, "result.json", auto_unbox = TRUE, null = "null", digits = NA)
