library(jsonlite)

households <- read.csv("households.csv")
census <- read.csv("census.csv")

required_household <- c(
  "eligible", "recipient", "instrument", "dose",
  "baseline", "weight", "outcome"
)
required_census <- c("eligible", "nonrecipient_population")

stopifnot(
  all(required_household %in% names(households)),
  all(required_census %in% names(census))
)

sample <- households[!is.na(households$recipient) &
                       households$recipient == 0, ]
stopifnot(
  nrow(sample) > 0,
  all(complete.cases(sample[, required_household])),
  all(sample$eligible %in% c(0, 1)),
  all(sample$weight > 0),
  all(c(0, 1) %in% sample$eligible)
)

ineligible <- 1 - sample$eligible
eligible <- sample$eligible

X <- cbind(
  ineligible,
  eligible,
  sample$baseline * ineligible,
  sample$baseline * eligible,
  sample$dose * ineligible,
  sample$dose * eligible
)

Z <- cbind(
  ineligible,
  eligible,
  sample$baseline * ineligible,
  sample$baseline * eligible,
  sample$instrument * ineligible,
  sample$instrument * eligible
)

weighted_Z <- Z * sample$weight
moment_matrix <- crossprod(weighted_Z, X)
moment_outcome <- crossprod(weighted_Z, sample$outcome)
stopifnot(qr(moment_matrix)$rank == ncol(X))

coefficients <- as.vector(solve(moment_matrix, moment_outcome))

mean_dose <- function(group) {
  rows <- sample$eligible == group
  weighted.mean(sample$dose[rows], sample$weight[rows])
}

ineligible_effect <- coefficients[5] * mean_dose(0)
eligible_nonrecipient_effect <- coefficients[6] * mean_dose(1)

stopifnot(
  all(complete.cases(census[, required_census])),
  all(census$eligible %in% c(0, 1)),
  all(c(0, 1) %in% census$eligible),
  all(census$nonrecipient_population >= 0)
)

population <- c(
  sum(census$nonrecipient_population[census$eligible == 0]),
  sum(census$nonrecipient_population[census$eligible == 1])
)
stopifnot(sum(population) > 0)

population_effect <- sum(
  c(ineligible_effect, eligible_nonrecipient_effect) * population
) / sum(population)

n_obs <- nrow(sample)
make_estimate <- function(term, value) {
  list(term = term, estimate = unname(value), se = NA_real_, n_obs = n_obs)
}

result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = list(
    make_estimate("ineligible_effect", ineligible_effect),
    make_estimate("eligible_nonrecipient_effect",
                  eligible_nonrecipient_effect),
    make_estimate("population_effect", population_effect)
  ),
  method_metadata = list(
    estimator = "weighted two-stage least squares",
    sample = "All households with recipient equal to zero",
    regressors = c(
      "1-eligible", "eligible", "baseline*(1-eligible)",
      "baseline*eligible", "dose*(1-eligible)", "dose*eligible"
    ),
    instruments = c(
      "1-eligible", "eligible", "baseline*(1-eligible)",
      "baseline*eligible", "instrument*(1-eligible)",
      "instrument*eligible"
    ),
    counterfactual = paste(
      "Dose is set to zero for every retained household.",
      "Attribution to this counterfactual is a synthetic convention."
    ),
    group_aggregation = paste(
      "Each group dose slope is multiplied by its household-weighted",
      "mean dose. Census nonrecipient population sets only the final",
      "between-group weights."
    )
  ),
  diagnostics = list(
    n_obs = n_obs,
    ineligible_n_obs = sum(sample$eligible == 0),
    eligible_n_obs = sum(sample$eligible == 1),
    moment_matrix_rank = qr(moment_matrix)$rank,
    ineligible_mean_dose = mean_dose(0),
    eligible_mean_dose = mean_dose(1),
    census_nonrecipient_population = list(
      ineligible = population[1],
      eligible = population[2]
    )
  )
)

write_json(result, "result.json", auto_unbox = TRUE, na = "null",
           digits = 16, pretty = TRUE)
