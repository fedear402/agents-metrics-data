d <- read.csv("./input.csv")

cohorts <- c(3, 5, 7)

results <- lapply(cohorts, function(c) {
  window <- (c - 2):(c + 2)
  comparison <- subset(d, time %in% window & (g == c | g == 0 | g > c + 2))

  observed_times <- tapply(comparison$time, comparison$id, function(x) {
    length(unique(x))
  })
  balanced_ids <- names(observed_times)[observed_times == length(window)]
  comparison <- comparison[as.character(comparison$id) %in% balanced_ids, ]

  comparison$did <- as.integer(comparison$g == c & comparison$time >= c)
  fit <- lm(y ~ did + factor(id) + factor(time), data = comparison)

  list(
    estimate = unname(coef(fit)["did"]),
    n_obs = nrow(comparison),
    n_treated = length(unique(comparison$id[comparison$g == c]))
  )
})

weights <- vapply(results, `[[`, numeric(1), "n_treated")
effects <- vapply(results, `[[`, numeric(1), "estimate")
row_counts <- vapply(results, `[[`, integer(1), "n_obs")

estimates <- lapply(seq_along(cohorts), function(i) {
  list(
    term = paste0("att_g", cohorts[i]),
    estimate = effects[i],
    se = NULL,
    n_obs = row_counts[i]
  )
})

estimates[[length(estimates) + 1]] <- list(
  term = "att_weighted",
  estimate = weighted.mean(effects, weights),
  se = NULL,
  n_obs = sum(row_counts)
)

out <- list(
  task_id = "broad_cohort_stack",
  platform = "r",
  estimates = estimates,
  method_metadata = structure(list(), names = character()),
  diagnostics = structure(list(), names = character())
)

jsonlite::write_json(
  out,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16
)
