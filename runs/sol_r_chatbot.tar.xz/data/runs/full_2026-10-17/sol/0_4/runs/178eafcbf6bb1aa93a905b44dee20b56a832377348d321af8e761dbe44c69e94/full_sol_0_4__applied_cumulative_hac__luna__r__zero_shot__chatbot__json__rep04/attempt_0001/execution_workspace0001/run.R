d <- read.csv("input.csv", stringsAsFactors = FALSE)
d <- d[order(as.Date(d$date)), ]

change <- c(NA_real_, diff(log(d$vix)))
lags <- sapply(1:15, function(k) c(rep(NA_real_, k), head(change, -k)))
colnames(lags) <- paste0("lag_", 1:15)

model_data <- data.frame(log_sales = log(d$sales), lags)
fit <- lm(log_sales ~ ., data = model_data, na.action = na.omit)

X <- model.matrix(fit)
u <- residuals(fit)
N <- nrow(X)
scores <- X * as.numeric(u)

meat <- crossprod(scores)
for (j in 1:15) {
  cross_lag <- crossprod(
    scores[(j + 1):N, , drop = FALSE],
    scores[1:(N - j), , drop = FALSE]
  )
  meat <- meat + (1 - j / 16) * (cross_lag + t(cross_lag))
}

bread <- solve(crossprod(X))
vcov_nw <- (N / (N - 16)) * bread %*% meat %*% bread

b <- coef(fit)
lag_names <- paste0("lag_", 1:15)
cumulative_se <- sqrt(sum(vcov_nw[lag_names, lag_names]))

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(
      term = "cumulative_response",
      estimate = unname(sum(b[lag_names])),
      se = unname(cumulative_se),
      n_obs = N
    ),
    list(
      term = "lag_1",
      estimate = unname(b["lag_1"]),
      se = unname(sqrt(vcov_nw["lag_1", "lag_1"])),
      n_obs = N
    ),
    list(
      term = "lag_15",
      estimate = unname(b["lag_15"]),
      se = unname(sqrt(vcov_nw["lag_15", "lag_15"])),
      n_obs = N
    )
  ),
  method_metadata = list(
    estimator = "OLS with intercept and 15 lagged log VIX changes",
    vcov = "Newey-West, Bartlett weights, maximum lag 15, scaled by N/(N-16)"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = NA)
