d <- read.csv("input.csv")
n <- nrow(d)

X_restricted <- cbind(1, d$x)
X_full <- cbind(1, d$x, d$z1, d$z2)

residuals_from <- function(X, v) qr.resid(qr(X), v)

ry <- residuals_from(X_restricted, d$y)
re <- residuals_from(X_restricted, d$endog)
fy <- residuals_from(X_full, d$y)
fe <- residuals_from(X_full, d$endog)

ssr_coefficients <- function(y_resid, e_resid) {
  c(
    sum(y_resid^2),
    -2 * sum(y_resid * e_resid),
    sum(e_resid^2)
  )
}

restricted <- ssr_coefficients(ry, re)
full <- ssr_coefficients(fy, fe)
critical_value <- qf(0.95, df1 = 2, df2 = n - 4)

# The confidence set satisfies a0 + a1*beta + a2*beta^2 <= 0.
a <- (n - 4) * (restricted - full) - 2 * critical_value * full
discriminant <- a[2]^2 - 4 * a[3] * a[1]
stopifnot(a[3] != 0, discriminant > 0)

boundaries <- sort(c(
  (-a[2] - sqrt(discriminant)) / (2 * a[3]),
  (-a[2] + sqrt(discriminant)) / (2 * a[3])
))

ssr_at <- function(coefficients, beta) {
  coefficients[1] + coefficients[2] * beta + coefficients[3] * beta^2
}

ar_f_at_one <- ((ssr_at(restricted, 1) - ssr_at(full, 1)) / 2) /
  (ssr_at(full, 1) / (n - 4))

make_estimate <- function(term, value) {
  list(term = term, estimate = as.numeric(value), se = NULL, n_obs = n)
}

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = list(
    make_estimate("boundary_low", boundaries[1]),
    make_estimate("boundary_high", boundaries[2]),
    make_estimate("accepts_zero", as.numeric(a[1] <= 0)),
    make_estimate("unbounded", as.numeric(a[3] < 0)),
    make_estimate("ar_f_at_one", ar_f_at_one)
  ),
  method_metadata = list(
    estimator = "Anderson-Rubin confidence set by analytic inversion of the joint F test",
    vcov = "conventional homoskedastic OLS"
  ),
  diagnostics = list()
)

jsonlite::write_json(
  result, "result.json", auto_unbox = TRUE, pretty = TRUE,
  digits = 16, null = "null"
)
