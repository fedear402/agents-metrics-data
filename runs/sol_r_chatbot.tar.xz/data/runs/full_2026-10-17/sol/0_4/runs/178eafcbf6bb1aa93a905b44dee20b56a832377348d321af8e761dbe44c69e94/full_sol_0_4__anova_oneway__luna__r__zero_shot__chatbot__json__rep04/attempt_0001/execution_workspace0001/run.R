data <- read.csv("./input.csv")
required <- c("group", "y")
if (!all(required %in% names(data))) {
  stop("input.csv must contain group and y columns")
}

data <- data[complete.cases(data[, required]), required]
data$group <- factor(data$group)
if (!is.numeric(data$y)) {
  stop("y must be numeric")
}
if (nlevels(data$group) < 2L) {
  stop("At least two groups are required")
}

fit <- aov(y ~ group, data = data)
anova_table <- summary(fit)[[1L]]
f_stat <- as.numeric(anova_table["group", "F value"])
df_num <- as.numeric(anova_table["group", "Df"])
df_den <- as.numeric(anova_table["Residuals", "Df"])
p_value <- as.numeric(anova_table["group", "Pr(>F)"])
n_obs <- nobs(fit)

if (!requireNamespace("jsonlite", quietly = TRUE)) {
  stop("The jsonlite package is required")
}

terms <- c("F", "df_num", "df_den", "p_value")
values <- c(f_stat, df_num, df_den, p_value)
estimates <- Map(
  function(term, value) {
    list(term = term, estimate = value, se = NULL, n_obs = as.integer(n_obs))
  },
  terms,
  values
)

result <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "One-way ANOVA",
    vcov = "Classical homoskedastic ANOVA"
  ),
  diagnostics = list()
)

jsonlite::write_json(
  result,
  path = "result.json",
  pretty = TRUE,
  auto_unbox = TRUE,
  digits = NA,
  null = "null"
)
