library(jsonlite)

data <- read.csv("input.csv")
data <- data[!is.na(data$score) & abs(data$score) < 1, ]
data <- data[complete.cases(data[, c("score", "earnings", "participated")]), ]

score <- data$score
right <- as.numeric(score >= 0)
weights <- 1 - abs(score)
X <- cbind(intercept = 1, score = score, right = right,
           right_score = right * score)
Y <- cbind(earnings = data$earnings, participated = data$participated)

bread <- solve(crossprod(X, weights * X))
coefficients <- bread %*% crossprod(X, weights * Y)
residuals <- Y - X %*% coefficients

contrast <- c(0, 0, 1, 0)
jumps <- drop(contrast %*% coefficients)
names(jumps) <- colnames(Y)

loading <- weights * drop(X %*% bread %*% contrast)
influence <- residuals * loading
joint_vcov <- crossprod(influence)

reduced_form <- jumps["earnings"]
first_stage <- jumps["participated"]
treatment_effect <- reduced_form / first_stage
gradient <- c(1 / first_stage, -reduced_form / first_stage^2)
treatment_variance <- drop(t(gradient) %*% joint_vcov %*% gradient)
n_obs <- nrow(data)

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect",
         estimate = unname(treatment_effect),
         se = unname(sqrt(treatment_variance)),
         n_obs = n_obs),
    list(term = "reduced_form",
         estimate = unname(reduced_form),
         se = unname(sqrt(joint_vcov[1, 1])),
         n_obs = n_obs),
    list(term = "first_stage",
         estimate = unname(first_stage),
         se = unname(sqrt(joint_vcov[2, 2])),
         n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "Triangular-weighted local-linear fuzzy RD, bandwidth 1",
    vcov = "Joint heteroskedasticity-robust HC0; delta method for ratio"
  ),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, digits = 16,
           pretty = TRUE, null = "null")
