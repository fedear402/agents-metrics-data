library(jsonlite)

data <- read.csv("./input.csv")
data <- data[complete.cases(data[c("group", "y")]), ]
data$group <- factor(data$group)

fit <- aov(y ~ group, data = data)
table <- summary(fit)[[1]]
n <- nrow(data)

out <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = list(
    list(term = "F", estimate = unname(table["group", "F value"]), se = NA_real_, n_obs = n),
    list(term = "df_num", estimate = unname(table["group", "Df"]), se = NA_real_, n_obs = n),
    list(term = "df_den", estimate = unname(table["Residuals", "Df"]), se = NA_real_, n_obs = n),
    list(term = "p_value", estimate = unname(table["group", "Pr(>F)"]), se = NA_real_, n_obs = n)
  ),
  method_metadata = list(estimator = "One-way ANOVA", vcov = "classical"),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "result.json", auto_unbox = TRUE, digits = NA)
