d <- read.csv("input.csv")
n <- nrow(d)
stopifnot(n == 240L, all(c("y", "endog", "x", "z1", "z2") %in% names(d)))

W <- cbind(1, d$x)
Z <- cbind(d$z1, d$z2)
Y <- d$y
D <- d$endog

residualize <- function(v) qr.resid(qr(W), v)
y <- residualize(Y)
endog <- residualize(D)
z <- residualize(Z)

project_z <- function(v) qr.fitted(qr(z), v)
py <- project_z(y)
pd <- project_z(endog)

explained <- c(
  sum(py * py),
  -2 * sum(py * pd),
  sum(pd * pd)
)
total <- c(
  sum(y * y),
  -2 * sum(y * endog),
  sum(endog * endog)
)

f_critical <- qf(0.95, df1 = 2, df2 = n - 4)
qcoef <- (n - 4 + 2 * f_critical) * explained -
  2 * f_critical * total

roots <- sort(Re(polyroot(qcoef)))
stopifnot(length(roots) == 2L, all(abs(Im(polyroot(qcoef))) < 1e-8))

quadratic <- function(coef, beta) {
  coef[1] + coef[2] * beta + coef[3] * beta^2
}
ar_f_at_one <- ((n - 4) / 2) *
  quadratic(explained, 1) /
  (quadratic(total, 1) - quadratic(explained, 1))

values <- c(
  boundary_low = roots[1],
  boundary_high = roots[2],
  accepts_zero = as.numeric(qcoef[1] <= 0),
  unbounded = as.numeric(qcoef[3] < 0),
  ar_f_at_one = ar_f_at_one
)

estimates <- vapply(
  names(values),
  function(term) sprintf(
    '{"term":"%s","estimate":%.16g,"se":null,"n_obs":%d}',
    term, values[[term]], n
  ),
  character(1)
)

json <- paste0(
  '{"task_id":"broad_ar_confidence_set",',
  '"platform":"r",',
  '"estimates":[', paste(estimates, collapse = ","), '],',
  '"method_metadata":{"estimator":"Anderson-Rubin F-test inversion",',
  '"vcov":"conventional homoskedastic OLS"},',
  '"diagnostics":{}}'
)
writeLines(json, "result.json")
