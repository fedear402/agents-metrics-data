dat <- read.csv("input.csv")

score <- dat$score
keep <- is.finite(score) &
  abs(score) < 1 &
  is.finite(dat$earnings) &
  is.finite(dat$participated)

d <- dat[keep, ]
x <- d$score
right <- as.numeric(x >= 0)
w <- 1 - abs(x)
X <- cbind(1, right, x, right * x)

A <- solve(crossprod(X, w * X))
fit <- function(y) {
  beta <- A %*% crossprod(X, w * y)
  list(beta = beta, residual = as.vector(y - X %*% beta))
}

earnings_fit <- fit(d$earnings)
participation_fit <- fit(d$participated)

reduced_form <- as.numeric(earnings_fit$beta[2])
first_stage <- as.numeric(participation_fit$beta[2])
treatment_effect <- reduced_form / first_stage

influence_scale <- as.vector(w * (X %*% A[, 2]))
rf_influence <- influence_scale * earnings_fit$residual
fs_influence <- influence_scale * participation_fit$residual

rf_variance <- sum(rf_influence^2)
fs_variance <- sum(fs_influence^2)
rf_fs_covariance <- sum(rf_influence * fs_influence)

te_variance <- rf_variance / first_stage^2 +
  reduced_form^2 * fs_variance / first_stage^4 -
  2 * reduced_form * rf_fs_covariance / first_stage^3

number <- function(value) {
  if (is.finite(value)) sprintf("%.17g", value) else "null"
}

n_obs <- nrow(d)
row <- function(term, estimate, se) {
  sprintf(
    '{"term":"%s","estimate":%s,"se":%s,"n_obs":%d}',
    term, number(estimate), number(se), n_obs
  )
}

rows <- c(
  row("treatment_effect", treatment_effect, sqrt(max(0, te_variance))),
  row("reduced_form", reduced_form, sqrt(rf_variance)),
  row("first_stage", first_stage, sqrt(fs_variance))
)

result <- sprintf(
  paste0(
    '{"task_id":"applied_fuzzy_rd","platform":"r",',
    '"estimates":[%s],',
    '"method_metadata":{"estimator":"Fuzzy local-linear RD, triangular weights, bandwidth 1",',
    '"vcov":"Joint heteroskedasticity-robust HC0 sandwich; delta method"},',
    '"diagnostics":{}}'
  ),
  paste(rows, collapse = ",")
)

writeLines(result, "result.json")
