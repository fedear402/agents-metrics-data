d <- read.csv("input.csv")
n <- nrow(d)
stopifnot(n == 240L, all(c("y", "endog", "x", "z1", "z2") %in% names(d)))

W <- cbind(1, d$x)
Z <- cbind(d$z1, d$z2)
Y <- as.numeric(d$y)
D <- as.numeric(d$endog)

residualize <- function(v, controls) {
  qr.resid(qr(controls), v)
}

yr <- residualize(Y, W)
dr <- residualize(D, W)
zr <- residualize(Z, W)
Pz <- zr %*% solve(crossprod(zr), t(zr))

quad <- function(u, v, projection = FALSE) {
  if (projection) as.numeric(crossprod(u, Pz %*% v))
  else as.numeric(crossprod(u, v))
}

a <- c(quad(yr, yr, TRUE), -2 * quad(yr, dr, TRUE), quad(dr, dr, TRUE))
s <- c(quad(yr, yr), -2 * quad(yr, dr), quad(dr, dr))
c <- qf(0.95, 2, n - 4) * 2 / (n - 4)

# F <= critical value exactly when q0 + q1*beta + q2*beta^2 <= 0.
q <- (1 + c) * a - c * s
roots <- sort(Re(polyroot(q)))
stopifnot(length(roots) == 2L, all(abs(Im(polyroot(q))) < 1e-7))

accepted <- function(beta) {
  v <- yr - beta * dr
  explained <- quad(v, v, TRUE)
  f <- (explained / 2) / ((quad(v, v) - explained) / (n - 4))
  f <= qf(0.95, 2, n - 4)
}

f_one <- {
  v <- yr - dr
  explained <- quad(v, v, TRUE)
  (explained / 2) / ((quad(v, v) - explained) / (n - 4))
}

unbounded <- as.numeric(q[3] < 0)
estimates <- list(
  list(term = "boundary_low", estimate = roots[1], se = NULL, n_obs = n),
  list(term = "boundary_high", estimate = roots[2], se = NULL, n_obs = n),
  list(term = "accepts_zero", estimate = as.numeric(accepted(0)), se = NULL, n_obs = n),
  list(term = "unbounded", estimate = unbounded, se = NULL, n_obs = n),
  list(term = "ar_f_at_one", estimate = f_one, se = NULL, n_obs = n)
)

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "Anderson-Rubin confidence set by exact quadratic inversion",
    vcov = "Conventional homoskedastic joint F test"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = 16, null = "null")
