library(jsonlite)

data <- read.csv("input.csv")
keep <- is.finite(data$score) &
  is.finite(data$earnings) &
  is.finite(data$participated) &
  abs(data$score) < 1
data <- data[keep, ]
n <- nrow(data)

weight <- 1 - abs(data$score)
right <- as.numeric(data$score >= 0)
X <- cbind(
  intercept = 1,
  right = right,
  left_slope = data$score * (1 - right),
  right_slope = data$score * right
)
Y <- cbind(data$earnings, data$participated)

bread <- solve(crossprod(X, weight * X))
coefficients <- bread %*% crossprod(X, weight * Y)
residuals <- Y - X %*% coefficients

contrast <- c(0, 1, 0, 0)
jumps <- drop(contrast %*% coefficients)
loading <- weight * drop(X %*% bread %*% contrast)
influence <- residuals * loading
joint <- crossprod(influence)

treatment_effect <- jumps[1] / jumps[2]
gradient <- c(1 / jumps[2], -jumps[1] / jumps[2]^2)
treatment_se <- sqrt(drop(t(gradient) %*% joint %*% gradient))

row <- function(term, estimate, se) {
  list(term = term, estimate = unname(as.numeric(estimate)),
       se = unname(as.numeric(se)), n_obs = as.integer(n))
}

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    row("treatment_effect", treatment_effect, treatment_se),
    row("reduced_form", jumps[1], sqrt(joint[1, 1])),
    row("first_stage", jumps[2], sqrt(joint[2, 2]))
  ),
  method_metadata = list(
    estimator = "Triangular-weighted local-linear fuzzy regression discontinuity",
    vcov = "Joint heteroskedasticity-robust HC0; delta method for ratio"
  ),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, digits = 16,
           pretty = TRUE, null = "null")
