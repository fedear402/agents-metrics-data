library(jsonlite)

crosswalk <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
trade <- read.csv("trade.csv", stringsAsFactors = FALSE)
areas <- read.csv("areas.csv", stringsAsFactors = FALSE)
employment <- read.csv("employment.csv", stringsAsFactors = FALSE)
outcomes <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

trade_industry <- merge(trade, crosswalk, by = "code")

cells <- merge(
  areas,
  unique(trade_industry[c("period", "industry")]),
  by = "period"
)
cells <- merge(
  cells,
  employment,
  by = c("area", "period", "vintage", "industry"),
  all.x = TRUE
)
cells$employment[is.na(cells$employment)] <- 0

national <- aggregate(
  employment ~ period + vintage + industry,
  data = cells,
  FUN = sum
)
names(national)[names(national) == "employment"] <- "national_employment"

cells <- merge(
  cells,
  national,
  by = c("period", "vintage", "industry")
)
cells <- merge(
  cells,
  trade_industry,
  by = c("period", "industry")
)

cells$contribution <- with(
  cells,
  (employment / total_employment) *
    (ifelse(vintage == "base", us_change, other_change) /
       national_employment) /
    (price_index / 100) / 1000 * (10 / years)
)

exposures <- aggregate(
  contribution ~ area + period + vintage,
  data = cells,
  FUN = sum
)
wide <- reshape(
  exposures,
  idvar = c("area", "period"),
  timevar = "vintage",
  direction = "wide"
)
names(wide)[names(wide) == "contribution.base"] <- "x"
names(wide)[names(wide) == "contribution.early"] <- "z"

base_areas <- areas[areas$vintage == "base", c("area", "period", "population")]
sample <- merge(outcomes, base_areas, by = c("area", "period"))
sample <- merge(sample, wide, by = c("area", "period"))
sample <- sample[order(sample$area, sample$period), ]

period_factor <- factor(sample$period)
X <- model.matrix(
  ~ period_factor + control + x,
  data = sample
)
Z <- model.matrix(
  ~ period_factor + control + z,
  data = sample
)
w <- sample$population
y <- sample$change_pp

ZX <- crossprod(Z, X * w)
Zy <- crossprod(Z, y * w)
beta <- solve(ZX, Zy)
iv_slope <- unname(beta[which(colnames(X) == "x")])

get_exposure <- function(area_value, period_value, column) {
  row <- sample[
    as.character(sample$area) == as.character(area_value) &
      as.character(sample$period) == as.character(period_value),
  ]
  stopifnot(nrow(row) == 1L)
  unname(row[[column]])
}

n_obs <- as.integer(nrow(sample))
stopifnot(n_obs == 72L)

make_estimate <- function(term, value) {
  list(term = term, estimate = value, se = NULL, n_obs = n_obs)
}

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = list(
    make_estimate("iv_slope", iv_slope),
    make_estimate(
      "exposure_area0_period0",
      get_exposure(0, 0, "x")
    ),
    make_estimate(
      "exposure_area0_period1",
      get_exposure(0, 1, "x")
    ),
    make_estimate(
      "instrument_area0_period0",
      get_exposure(0, 0, "z")
    )
  ),
  method_metadata = list(
    estimator = "weighted 2SLS",
    endogenous_regressor = "x",
    excluded_instrument = "z",
    exogenous_regressors = c("intercept", "period", "control"),
    weight = "base-vintage population",
    exposure_units = "thousands of real dollars per worker per decade"
  ),
  diagnostics = list(n_obs = n_obs)
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = NA,
  pretty = TRUE
)
