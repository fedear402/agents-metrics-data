data <- read.csv("./input.csv")

if (!all(c("t", "y") %in% names(data))) {
  stop("input.csv must contain t and y columns.")
}

data <- data[order(data$t), ]
if (anyNA(data$y) || any(!is.finite(data$y))) {
  stop("y must contain only finite values.")
}
if (tail(data$t, 1) != 250) {
  stop("The final observed time must be t = 250.")
}

y <- as.numeric(data$y)
fit <- stats::arima(y, order = c(1, 1, 1), include.mean = FALSE, method = "ML")
pred <- stats::predict(fit, n.ahead = 1)

forecast <- as.numeric(pred$pred[1])
se <- as.numeric(pred$se[1])
margin <- stats::qnorm(0.975) * se
n_obs <- length(y)

result <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = list(
    list(term = "forecast", estimate = forecast, se = se, n_obs = n_obs),
    list(term = "lower_95", estimate = forecast - margin, se = NULL, n_obs = n_obs),
    list(term = "upper_95", estimate = forecast + margin, se = NULL, n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "ARIMA(1,1,1), maximum likelihood, no constant or drift",
    vcov = "Model-based forecast variance"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = NA)
