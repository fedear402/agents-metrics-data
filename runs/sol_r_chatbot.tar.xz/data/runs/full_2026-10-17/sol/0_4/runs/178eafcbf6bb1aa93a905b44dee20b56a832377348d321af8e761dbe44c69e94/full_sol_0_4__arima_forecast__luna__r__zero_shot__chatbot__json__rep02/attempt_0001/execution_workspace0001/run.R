dat <- read.csv("./input.csv")
dat <- dat[order(dat$t), ]

if (anyNA(dat$y) || anyNA(dat$t) || anyDuplicated(dat$t) ||
    nrow(dat) != 250L || tail(dat$t, 1L) != 250) {
  stop("Expected 250 ordered observations ending at t = 250, with no missing values.")
}

fit <- stats::arima(
  dat$y,
  order = c(1L, 1L, 1L),
  include.mean = FALSE,
  method = "ML"
)

pred <- stats::predict(fit, n.ahead = 1L)
forecast <- as.numeric(pred$pred[1L])
se <- as.numeric(pred$se[1L])
z <- stats::qnorm(0.975)

result <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = list(
    list(term = "forecast", estimate = forecast, se = se, n_obs = nrow(dat)),
    list(term = "lower_95", estimate = forecast - z * se, se = NULL, n_obs = nrow(dat)),
    list(term = "upper_95", estimate = forecast + z * se, se = NULL, n_obs = nrow(dat))
  ),
  method_metadata = list(
    estimator = "ARIMA(1,1,1) maximum likelihood, no constant or drift",
    vcov = "Model-based one-step-ahead prediction variance"
  ),
  diagnostics = list()
)

if (!requireNamespace("jsonlite", quietly = TRUE)) {
  stop("Package 'jsonlite' is required.")
}
jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = NA)
