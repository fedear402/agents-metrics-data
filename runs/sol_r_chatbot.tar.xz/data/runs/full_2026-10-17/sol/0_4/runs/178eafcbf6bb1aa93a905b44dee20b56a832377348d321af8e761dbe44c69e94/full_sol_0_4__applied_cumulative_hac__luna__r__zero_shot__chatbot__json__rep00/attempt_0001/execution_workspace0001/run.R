data <- read.csv("input.csv", stringsAsFactors = FALSE)
data <- data[order(as.Date(data$date)), ]

n <- nrow(data)
if (n < 17L) stop("At least 17 observations are required.")

log_sales <- log(data$sales)
log_vix <- log(data$vix)
change <- c(NA_real_, diff(log_vix))

rows <- 17L:n
lagged <- sapply(1L:15L, function(k) change[rows - k])
colnames(lagged) <- paste0("lag_", 1L:15L)

X <- cbind("(Intercept)" = 1, lagged)
y <- log_sales[rows]
N <- length(y)

fit <- lm.fit(x = X, y = y)
if (fit$rank < ncol(X)) stop("The regression design matrix is rank deficient.")

beta <- fit$coefficients
residual <- fit$residuals
scores <- X * as.numeric(residual)

meat <- crossprod(scores)
for (j in 1L:15L) {
  cross <- crossprod(
    scores[(j + 1L):N, , drop = FALSE],
    scores[1L:(N - j), , drop = FALSE]
  )
  meat <- meat + (1 - j / 16) * (cross + t(cross))
}

bread <- solve(crossprod(X))
covariance <- (N / (N - 16)) * bread %*% meat %*% bread
lag_ids <- match(paste0("lag_", 1L:15L), colnames(X))

cumulative_variance <- sum(covariance[lag_ids, lag_ids])
estimates <- list(
  list(
    term = "cumulative_response",
    estimate = unname(sum(beta[lag_ids])),
    se = unname(sqrt(max(0, cumulative_variance))),
    n_obs = N
  ),
  list(
    term = "lag_1",
    estimate = unname(beta["lag_1"]),
    se = unname(sqrt(max(0, covariance["lag_1", "lag_1"]))),
    n_obs = N
  ),
  list(
    term = "lag_15",
    estimate = unname(beta["lag_15"]),
    se = unname(sqrt(max(0, covariance["lag_15", "lag_15"]))),
    n_obs = N
  )
)

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "OLS of log sales on an intercept and 15 trading-observation lags of change in log VIX",
    vcov = "Newey-West HAC, Bartlett weights, maximum lag 15, multiplied by N/(N-16)"
  ),
  diagnostics = list()
)

writeLines(
  jsonlite::toJSON(result, auto_unbox = TRUE, digits = 16, pretty = TRUE),
  "result.json"
)
