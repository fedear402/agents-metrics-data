library(jsonlite)

d <- read.csv("input.csv", stringsAsFactors = FALSE)

regions <- d[!duplicated(d$region_id), ]
industries <- d[!duplicated(d$industry_id), ]

e <- regions$region_weight / sum(regions$region_weight)
names(e) <- as.character(regions$region_id)

shock <- industries$shock
names(shock) <- as.character(industries$industry_id)

shares <- matrix(
  0,
  nrow = nrow(regions),
  ncol = nrow(industries),
  dimnames = list(as.character(regions$region_id),
                  as.character(industries$industry_id))
)
shares[cbind(match(d$region_id, regions$region_id),
             match(d$industry_id, industries$industry_id))] <- d$share

z <- drop(shares %*% shock)
regional <- cbind(y = regions$y, x = regions$x, z = z)
centered <- sweep(regional, 2, drop(crossprod(e, regional)))
mass <- drop(crossprod(e, shares))
aggregated <- sweep(crossprod(shares, e * centered), 1, mass, "/")

shock_iv <- function(dependent, endogenous) {
  regressors <- cbind(1, endogenous)
  instruments <- cbind(1, shock)
  cross <- crossprod(instruments, mass * regressors)
  beta <- solve(cross, crossprod(instruments, mass * dependent))
  residual <- drop(dependent - regressors %*% beta)
  scores <- instruments * (mass * residual)
  inverse <- solve(cross)
  n <- length(shock)
  covariance <- n / (n - 2) *
    inverse %*% crossprod(scores) %*% t(inverse)
  c(estimate = unname(beta[2]),
    se = sqrt(unname(covariance[2, 2])))
}

effect <- shock_iv(aggregated[, "y"], aggregated[, "x"])
first_stage <- shock_iv(aggregated[, "x"], aggregated[, "z"])

regional_effect <- sum(e * centered[, "z"] * centered[, "y"]) /
  sum(e * centered[, "z"] * centered[, "x"])
regional_first_stage <- sum(e * centered[, "z"] * centered[, "x"]) /
  sum(e * centered[, "z"]^2)

stopifnot(
  isTRUE(all.equal(unname(effect["estimate"]), regional_effect,
                   tolerance = 1e-8)),
  isTRUE(all.equal(unname(first_stage["estimate"]), regional_first_stage,
                   tolerance = 1e-8))
)

row <- function(term, estimate, se, n_obs) {
  list(term = term, estimate = unname(as.numeric(estimate)),
       se = if (is.null(se)) NULL else unname(as.numeric(se)),
       n_obs = as.integer(n_obs))
}

n <- length(shock)
result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    row("effect", effect["estimate"], effect["se"], n),
    row("first_stage", first_stage["estimate"], first_stage["se"], n),
    row("effective_shocks", 1 / sum(mass^2), NULL, n)
  ),
  method_metadata = list(
    estimator = "Weighted regional 2SLS with BHJ shock-level IV aggregation",
    vcov = "Shock-level heteroskedasticity-robust HC1, N/(N-2)"
  ),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null",
           digits = 16, pretty = TRUE)
