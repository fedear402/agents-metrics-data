d <- read.csv("input.csv", stringsAsFactors = FALSE)

regions <- unique(d$region_id)
industries <- unique(d$industry_id)
r <- match(d$region_id, regions)
n <- match(d$industry_id, industries)
R <- length(regions)
N <- length(industries)

regional <- d[match(regions, d$region_id), ]
industry <- d[match(industries, d$industry_id), ]

e <- regional$region_weight / sum(regional$region_weight)
z <- as.numeric(rowsum(d$share * industry$shock[n], r, reorder = TRUE))

center <- function(v) v - sum(e * v)
y0 <- center(regional$y)
x0 <- center(regional$x)
z0 <- center(z)

exposure <- e[r] * d$share
s <- as.numeric(rowsum(exposure, n, reorder = TRUE))
stopifnot(N > 2L, all(s > 0))

aggregate_residual <- function(v0) {
  as.numeric(rowsum(exposure * v0[r], n, reorder = TRUE)) / s
}
ybar <- aggregate_residual(y0)
xbar <- aggregate_residual(x0)
zbar <- aggregate_residual(z0)

shock_iv <- function(outcome, endogenous) {
  X <- cbind(1, endogenous)
  Z <- cbind(1, industry$shock)
  A <- crossprod(Z, X * s)
  beta <- solve(A, crossprod(Z, outcome * s))
  u <- as.numeric(outcome - X %*% beta)
  scores <- Z * (s * u)
  Ainv <- solve(A)
  V <- (N / (N - 2)) * Ainv %*% crossprod(scores) %*% t(Ainv)
  list(slope = unname(beta[2]), se = sqrt(unname(V[2, 2])))
}

effect <- shock_iv(ybar, xbar)
first_stage <- shock_iv(xbar, zbar)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = effect$slope, se = effect$se, n_obs = N),
    list(term = "first_stage", estimate = first_stage$slope,
         se = first_stage$se, n_obs = N),
    list(term = "effective_shocks", estimate = 1 / sum(s^2),
         se = NULL, n_obs = N)
  ),
  method_metadata = list(
    estimator = "Exposure-weighted regional 2SLS via shock-level IV",
    vcov = "Shock-level heteroskedasticity-robust HC1; multiplier N/(N-2)"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE,
                     null = "null", digits = NA)
