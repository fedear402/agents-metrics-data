d <- read.csv("input.csv")
n <- nrow(d)
q <- 2L
df <- n - 4L
critical <- qf(0.95, q, df)
k <- q * critical / df

restricted <- model.matrix(~ x, data = d)
unrestricted <- model.matrix(~ x + z1 + z2, data = d)

residualize <- function(v, design) {
  as.vector(qr.resid(qr(design), v))
}

ry <- residualize(d$y, restricted)
rd <- residualize(d$endog, restricted)
uy <- residualize(d$y, unrestricted)
ud <- residualize(d$endog, unrestricted)

A <- sum(rd^2) - (1 + k) * sum(ud^2)
B <- -2 * (sum(ry * rd) - (1 + k) * sum(uy * ud))
C <- sum(ry^2) - (1 + k) * sum(uy^2))

discriminant <- B^2 - 4 * A * C
stopifnot(is.finite(discriminant), discriminant > 0, A != 0)
bounds <- sort(c(
  (-B - sqrt(discriminant)) / (2 * A),
  (-B + sqrt(discriminant)) / (2 * A)
))

ssr_r_one <- sum((ry - rd)^2)
ssr_u_one <- sum((uy - ud)^2)
ar_f_at_one <- ((ssr_r_one - ssr_u_one) / q) / (ssr_u_one / df)

row <- function(term, estimate) {
  list(term = term, estimate = as.numeric(estimate), se = NULL, n_obs = n)
}

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = list(
    row("boundary_low", bounds[1]),
    row("boundary_high", bounds[2]),
    row("accepts_zero", as.integer(C <= 0)),
    row("unbounded", as.integer(A < 0)),
    row("ar_f_at_one", ar_f_at_one)
  ),
  method_metadata = list(
    estimator = "Anderson-Rubin confidence set by quadratic inversion of the joint F test",
    vcov = "Conventional homoskedastic"
  ),
  diagnostics = list()
)

jsonlite::write_json(
  result, "result.json",
  auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE
)
