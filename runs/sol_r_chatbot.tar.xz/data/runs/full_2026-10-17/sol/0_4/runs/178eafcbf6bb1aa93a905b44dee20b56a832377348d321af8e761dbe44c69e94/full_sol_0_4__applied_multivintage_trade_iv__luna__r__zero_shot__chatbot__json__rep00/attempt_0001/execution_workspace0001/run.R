library(jsonlite)

crosswalk <- read.csv("crosswalk.csv")
trade <- read.csv("trade.csv")
areas <- read.csv("areas.csv")
employment <- read.csv("employment.csv")
outcomes <- read.csv("outcomes.csv")

trade <- merge(trade, crosswalk, by = "code")

industry_grid <- unique(expand.grid(
  area = unique(areas$area),
  period = unique(areas$period),
  vintage = unique(areas$vintage),
  industry = unique(crosswalk$industry)
))

cells <- merge(
  industry_grid, employment,
  by = c("area", "period", "vintage", "industry"),
  all.x = TRUE
)
cells$employment[is.na(cells$employment)] <- 0

national <- aggregate(
  employment ~ period + vintage + industry,
  data = cells,
  FUN = sum
)
names(national)[names(national) == "employment"] <- "national_employment"

cells <- merge(cells, areas, by = c("area", "period", "vintage"))
cells <- merge(cells, national, by = c("period", "vintage", "industry"))
cells <- merge(cells, trade, by = c("period", "industry"))

cells$trade_change <- ifelse(
  cells$vintage == "base", cells$us_change, cells$other_change
)
cells$contribution <-
  (cells$employment / cells$total_employment) *
  (cells$trade_change / cells$national_employment) /
  (cells$price_index / 100) / 1000 *
  (10 / cells$years)

exposures <- aggregate(
  contribution ~ area + period + vintage,
  data = cells,
  FUN = sum
)
names(exposures)[names(exposures) == "contribution"] <- "exposure"

base <- subset(areas, vintage == "base", c("area", "period", "population"))
base <- merge(
  base,
  subset(exposures, vintage == "base", c("area", "period", "exposure")),
  by = c("area", "period")
)
names(base)[names(base) == "exposure"] <- "x"

early <- subset(
  exposures, vintage == "early",
  c("area", "period", "exposure")
)
names(early)[names(early) == "exposure"] <- "z"

sample <- merge(base, early, by = c("area", "period"))
sample <- merge(sample, outcomes, by = c("area", "period"))
stopifnot(nrow(sample) == 72L)

# Weighted two-stage least squares, with all exogenous regressors in Z.
X <- model.matrix(~ period + control + x, data = sample)
Z <- model.matrix(~ period + control + z, data = sample)
y <- sample$change_pp
w <- sample$population

ZX <- crossprod(Z, X * w)
ZZ <- crossprod(Z, Z * w)
Zy <- crossprod(Z, y * w)
beta <- solve(t(ZX) %*% solve(ZZ, ZX), t(ZX) %*% solve(ZZ, Zy))

get_exposure <- function(data, area_value, period_value, column) {
  value <- data[
    as.character(data$area) == as.character(area_value) &
      as.character(data$period) == as.character(period_value),
    column
  ]
  stopifnot(length(value) == 1L)
  unname(value)
}

make_estimate <- function(term, value) {
  list(term = term, estimate = unname(as.numeric(value)),
       se = NULL, n_obs = 72L)
}

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = list(
    make_estimate("iv_slope", beta["x", 1]),
    make_estimate("exposure_area0_period0", get_exposure(sample, 0, 0, "x")),
    make_estimate("exposure_area0_period1", get_exposure(sample, 0, 1, "x")),
    make_estimate("instrument_area0_period0", get_exposure(sample, 0, 0, "z"))
  ),
  method_metadata = list(
    estimator = "weighted 2SLS",
    endogenous = "x",
    instrument = "z",
    exogenous = c("intercept", "period", "control"),
    weight = "base-vintage population",
    exposure_units = "thousands of real dollars per worker per decade"
  ),
  diagnostics = list(n_obs = 72L)
)

write_json(
  result, "result.json",
  auto_unbox = TRUE, null = "null", digits = NA, pretty = TRUE
)
