d <- read.csv("input.csv")
d <- d[is.finite(d$score) & abs(d$score) < 1 &
       is.finite(d$earnings) & is.finite(d$participated), ]

x <- d$score
right <- as.numeric(x >= 0)
w <- 1 - abs(x)
X <- cbind(1, x, right, x * right)
Y <- cbind(d$earnings, d$participated)

fit <- lm.fit(X * sqrt(w), Y * sqrt(w))
B <- fit$coefficients
E <- Y - X %*% B
bread <- solve(crossprod(X, w * X))

# HC0 covariance for both discontinuities, including their covariance.
score_y <- X * as.vector(w * E[, 1])
score_p <- X * as.vector(w * E[, 2])
influence <- cbind(score_y %*% bread[3, ],
                   score_p %*% bread[3, ])
V <- crossprod(influence)

reduced_form <- B[3, 1]
first_stage <- B[3, 2]
treatment_effect <- reduced_form / first_stage
gradient <- c(1 / first_stage, -reduced_form / first_stage^2)

estimates <- c(treatment_effect, reduced_form, first_stage)
ses <- c(
  sqrt(as.numeric(t(gradient) %*% V %*% gradient)),
  sqrt(V[1, 1]),
  sqrt(V[2, 2])
)
terms <- c("treatment_effect", "reduced_form", "first_stage")

number <- function(z) {
  if (is.finite(z)) sprintf("%.17g", z) else "null"
}
rows <- vapply(seq_along(terms), function(i) {
  sprintf(
    '{"term":"%s","estimate":%s,"se":%s,"n_obs":%d}',
    terms[i], number(estimates[i]), number(ses[i]), nrow(d)
  )
}, character(1))

output <- sprintf(
  paste0(
    '{"task_id":"applied_fuzzy_rd","platform":"r",',
    '"estimates":[%s],',
    '"method_metadata":{"estimator":"fuzzy local-linear RD, triangular kernel, bandwidth 1",',
    '"vcov":"joint HC0 sandwich with delta method"},',
    '"diagnostics":{}}'
  ),
  paste(rows, collapse = ",")
)
writeLines(output, "result.json")
