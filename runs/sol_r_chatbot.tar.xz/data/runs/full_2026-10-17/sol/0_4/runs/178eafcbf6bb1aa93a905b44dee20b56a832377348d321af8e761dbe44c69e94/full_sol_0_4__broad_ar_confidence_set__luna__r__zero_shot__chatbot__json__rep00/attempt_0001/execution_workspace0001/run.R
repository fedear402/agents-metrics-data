dat <- read.csv("input.csv")
n <- nrow(dat)
stopifnot(n == 240L, all(c("y", "endog", "x", "z1", "z2") %in% names(dat)))
stopifnot(all(complete.cases(dat[, c("y", "endog", "x", "z1", "z2")])))

X0 <- model.matrix(~ x, data = dat)
X1 <- model.matrix(~ x + z1 + z2, data = dat)
stopifnot(qr(X0)$rank == 2L, qr(X1)$rank == 4L)

resid0 <- qr.resid(qr(X0), cbind(dat$y, dat$endog))
resid1 <- qr.resid(qr(X1), cbind(dat$y, dat$endog))

quadratic <- function(r) {
  c(sum(r[, 1]^2), -2 * sum(r[, 1] * r[, 2]), sum(r[, 2]^2))
}

rss0 <- quadratic(resid0)
rss1 <- quadratic(resid1)
critical <- qf(0.95, df1 = 2, df2 = n - 4)
scale <- 2 * critical / (n - 4)

# Acceptance is equivalent to RSS_restricted - (1 + scale) RSS_full <= 0.
coef <- rss0 - (1 + scale) * rss1
disc <- coef[2]^2 - 4 * coef[3] * coef[1]
stopifnot(is.finite(disc), disc > 0, abs(coef[3]) > 1e-12)

roots <- sort(c(
  (-coef[2] - sqrt(disc)) / (2 * coef[3]),
  (-coef[2] + sqrt(disc)) / (2 * coef[3])
))

accepted <- function(beta) {
  sum(coef * c(1, beta, beta^2)) <= 0
}

rss_at <- function(q, beta) sum(q * c(1, beta, beta^2))
f_at_one <- ((rss_at(rss0, 1) - rss_at(rss1, 1)) / 2) /
  (rss_at(rss1, 1) / (n - 4))

library(jsonlite)
terms <- c("boundary_low", "boundary_high", "accepts_zero", "unbounded", "ar_f_at_one")
values <- c(roots[1], roots[2], as.numeric(accepted(0)),
            as.numeric(coef[3] < 0), f_at_one)

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = Map(function(term, estimate) {
    list(term = term, estimate = unname(estimate), se = NULL, n_obs = n)
  }, terms, values),
  method_metadata = list(
    estimator = "Anderson-Rubin confidence set by exact quadratic F-test inversion",
    vcov = "Conventional homoskedastic OLS"
  ),
  diagnostics = list()
)

writeLines(
  toJSON(result, auto_unbox = TRUE, null = "null", digits = 15),
  "result.json"
)
