d <- read.csv("input.csv")
n <- nrow(d)
q <- 2L
df <- n - 4L
critical <- qf(0.95, q, df)

restricted <- model.matrix(~ x, data = d)
unrestricted <- model.matrix(~ x + z1 + z2, data = d)

residual_vector <- function(design, response) {
  qr.resid(qr(design), response)
}

ry <- residual_vector(restricted, d$y)
rd <- residual_vector(restricted, d$endog)
uy <- residual_vector(unrestricted, d$y)
ud <- residual_vector(unrestricted, d$endog)

k <- q * critical / df
A <- sum(rd^2) - (1 + k) * sum(ud^2)
B <- -2 * (sum(ry * rd) - (1 + k) * sum(uy * ud))
C <- sum(ry^2) - (1 + k) * sum(uy^2))

discriminant <- B^2 - 4 * A * C
if (!is.finite(discriminant) || discriminant <= 0 || A == 0) {
  stop("Expected two distinct finite Anderson-Rubin boundaries.")
}

bounds <- sort(c(
  (-B - sqrt(discriminant)) / (2 * A),
  (-B + sqrt(discriminant)) / (2 * A)
))

ar_f <- function(beta) {
  restricted_ssr <- sum((ry - beta * rd)^2)
  unrestricted_ssr <- sum((uy - beta * ud)^2)
  ((restricted_ssr - unrestricted_ssr) / q) /
    (unrestricted_ssr / df)
}

row <- function(term, estimate) {
  list(term = term, estimate = unname(as.numeric(estimate)),
       se = NULL, n_obs = as.integer(n))
}

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = list(
    row("boundary_low", bounds[1]),
    row("boundary_high", bounds[2]),
    row("accepts_zero", as.integer(C <= 0)),
    row("unbounded", as.integer(A < 0)),
    row("ar_f_at_one", ar_f(1))
  ),
  method_metadata = list(
    estimator = "Anderson-Rubin confidence set by quadratic inversion",
    vcov = "Conventional homoskedastic joint F test"
  ),
  diagnostics = list()
)

jsonlite::write_json(
  result, "result.json", auto_unbox = TRUE,
  null = "null", digits = 16, pretty = TRUE
)
