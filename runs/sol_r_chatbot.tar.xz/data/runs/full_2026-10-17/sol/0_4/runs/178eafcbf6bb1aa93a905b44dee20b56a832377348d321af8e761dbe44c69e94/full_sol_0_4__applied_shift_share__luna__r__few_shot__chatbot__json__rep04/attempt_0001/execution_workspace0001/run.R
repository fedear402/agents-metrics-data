library(jsonlite)

d <- read.csv("input.csv", stringsAsFactors = FALSE)

regions <- unique(d$region_id)
industries <- unique(d$industry_id)
R <- length(regions)
N <- length(industries)

ri <- match(d$region_id, regions)
ni <- match(d$industry_id, industries)

regional <- d[match(regions, d$region_id), ]
e <- regional$region_weight / sum(regional$region_weight)

shares <- matrix(0, nrow = R, ncol = N)
shares[cbind(ri, ni)] <- d$share
shocks <- d$shock[match(industries, d$industry_id)]

z <- drop(shares %*% shocks)
values <- cbind(y = regional$y, x = regional$x, z = z)
centered <- sweep(values, 2, drop(crossprod(e, values)))
mass <- drop(crossprod(e, shares))
aggregated <- (crossprod(shares, e * centered)) / mass

shock_iv <- function(dependent, endogenous) {
  X <- cbind(intercept = 1, endogenous = endogenous)
  Z <- cbind(intercept = 1, shock = shocks)
  cross <- crossprod(Z, mass * X)
  beta <- solve(cross, crossprod(Z, mass * dependent))
  residual <- drop(dependent - X %*% beta)
  scores <- Z * as.vector(mass * residual)
  inverse <- solve(cross)
  vcov <- (N / (N - 2)) * inverse %*%
    crossprod(scores) %*% t(inverse)
  c(estimate = unname(beta[2]), se = sqrt(vcov[2, 2]))
}

effect <- shock_iv(aggregated[, "y"], aggregated[, "x"])
first_stage <- shock_iv(aggregated[, "x"], aggregated[, "z"])

row <- function(term, estimate, se) {
  list(
    term = term,
    estimate = unname(as.numeric(estimate)),
    se = if (is.null(se)) NULL else unname(as.numeric(se)),
    n_obs = as.integer(N)
  )
}

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    row("effect", effect["estimate"], effect["se"]),
    row("first_stage", first_stage["estimate"], first_stage["se"]),
    row("effective_shocks", 1 / sum(mass^2), NULL)
  ),
  method_metadata = list(
    estimator = "Regional weighted 2SLS; equivalent shock-level weighted IV",
    vcov = "Shock-level heteroskedasticity-robust HC1, structural IV scores, N/(N-2)"
  ),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null",
           digits = 16, pretty = TRUE)
