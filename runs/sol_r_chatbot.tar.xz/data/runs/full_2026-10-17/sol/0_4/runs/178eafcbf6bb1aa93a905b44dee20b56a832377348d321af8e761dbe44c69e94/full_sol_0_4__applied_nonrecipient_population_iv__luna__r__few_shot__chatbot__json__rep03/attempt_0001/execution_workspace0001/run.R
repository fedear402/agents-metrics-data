library(jsonlite)

households <- read.csv("households.csv")
census <- read.csv("census.csv")

d <- households[!is.na(households$recipient) & households$recipient == 0, ]
n_obs <- nrow(d)

g0 <- as.numeric(d$eligible == 0)
g1 <- as.numeric(d$eligible == 1)
C <- cbind(
  g0,
  g1,
  d$baseline * g0,
  d$baseline * g1
)
X <- cbind(C, d$dose * g0, d$dose * g1)
Z <- cbind(C, d$instrument * g0, d$instrument * g1)

sw <- sqrt(d$weight)
Xw <- X * sw
Zw <- Z * sw
yw <- d$outcome * sw
fitted_X <- qr.fitted(qr(Zw), Xw)
slopes <- as.numeric(qr.coef(qr(fitted_X), yw))[5:6]

mean_dose <- vapply(0:1, function(group) {
  a <- d[d$eligible == group, ]
  weighted.mean(a$dose, a$weight)
}, numeric(1))

group_effects <- slopes * mean_dose
population_weights <- census$nonrecipient_population[
  match(0:1, census$eligible)
]
population_effect <- weighted.mean(group_effects, population_weights)

terms <- c(
  "ineligible_effect",
  "eligible_nonrecipient_effect",
  "population_effect"
)
values <- c(group_effects, population_effect)

result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = lapply(seq_along(terms), function(i) {
    list(
      term = terms[i],
      estimate = unname(values[i]),
      se = NULL,
      n_obs = as.integer(n_obs)
    )
  }),
  method_metadata = list(
    estimator = "weighted 2SLS",
    sample = "households with recipient equal to zero",
    counterfactual = "dose set to zero for every retained household",
    group_effect = "group dose slope times household-weighted mean dose",
    population_aggregation = "group effects weighted by census nonrecipient_population"
  ),
  diagnostics = list(
    n_obs = as.integer(n_obs),
    n_ineligible = as.integer(sum(g0)),
    n_eligible = as.integer(sum(g1))
  )
)

write_json(result, "result.json", auto_unbox = TRUE, digits = 16,
           pretty = TRUE, null = "null")
