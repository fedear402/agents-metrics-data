data <- read.csv("input.csv", stringsAsFactors = FALSE)
data <- data[order(as.Date(data$date)), ]

change <- c(NA_real_, diff(log(data$vix)))
lagged <- sapply(1:15, function(k) {
  c(rep(NA_real_, k), head(change, -k))
})
colnames(lagged) <- paste0("lag_", 1:15)

sample <- data.frame(log_sales = log(data$sales), lagged)
sample <- sample[complete.cases(sample), ]
fit <- lm(log_sales ~ ., data = sample)

X <- model.matrix(fit)
N <- nrow(X)
p <- ncol(X)
scores <- X * as.numeric(residuals(fit))
meat <- crossprod(scores)

for (j in 1:15) {
  cross_lag <- crossprod(
    scores[(j + 1):N, , drop = FALSE],
    scores[1:(N - j), , drop = FALSE]
  )
  meat <- meat + (1 - j / 16) * (cross_lag + t(cross_lag))
}

bread <- solve(crossprod(X))
V <- (N / (N - p)) * bread %*% meat %*% bread
b <- coef(fit)
contrast <- c(0, rep(1, 15))

rows <- list(
  list(
    term = "cumulative_response",
    estimate = unname(as.numeric(sum(contrast * b))),
    se = unname(as.numeric(sqrt(t(contrast) %*% V %*% contrast))),
    n_obs = as.integer(N)
  ),
  list(
    term = "lag_1",
    estimate = unname(as.numeric(b["lag_1"])),
    se = unname(as.numeric(sqrt(V["lag_1", "lag_1"]))),
    n_obs = as.integer(N)
  ),
  list(
    term = "lag_15",
    estimate = unname(as.numeric(b["lag_15"])),
    se = unname(as.numeric(sqrt(V["lag_15", "lag_15"]))),
    n_obs = as.integer(N)
  )
)

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = rows,
  method_metadata = list(
    estimator = "OLS with intercept and 15 trading-observation lags of log VIX changes",
    vcov = "Newey-West Bartlett HAC, maximum lag 15, correction N/(N-16)"
  ),
  diagnostics = list()
)

jsonlite::write_json(
  result, "result.json",
  auto_unbox = TRUE, digits = 16, pretty = TRUE, null = "null"
)
