library(jsonlite)

crosswalk <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
trade <- read.csv("trade.csv", stringsAsFactors = FALSE)
areas <- read.csv("areas.csv", stringsAsFactors = FALSE)
employment <- read.csv("employment.csv", stringsAsFactors = FALSE)
outcomes <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

trade <- merge(trade, crosswalk, by = "code", sort = FALSE)

# Complete omitted area-industry cells with zero employment.
industries <- unique(crosswalk["industry"])
area_industries <- merge(areas, industries, by = NULL, sort = FALSE)
area_industries <- merge(
  area_industries, employment,
  by = c("area", "period", "vintage", "industry"),
  all.x = TRUE, sort = FALSE
)
area_industries$employment[is.na(area_industries$employment)] <- 0

national <- aggregate(
  employment ~ period + vintage + industry,
  data = area_industries, FUN = sum
)
names(national)[names(national) == "employment"] <- "national_employment"

cells <- merge(
  area_industries, national,
  by = c("period", "vintage", "industry"), sort = FALSE
)
cells <- merge(cells, trade, by = c("period", "industry"), sort = FALSE)

stopifnot(all(cells$national_employment > 0))
cells$trade_change <- ifelse(
  cells$vintage == "base", cells$us_change, cells$other_change
)
cells$contribution <-
  (cells$employment / cells$total_employment) *
  (cells$trade_change / cells$national_employment) /
  (cells$price_index / 100) / 1000 *
  (10 / cells$years)

exposures <- aggregate(
  contribution ~ area + period + vintage,
  data = cells, FUN = sum
)
wide <- reshape(
  exposures, idvar = c("area", "period"),
  timevar = "vintage", direction = "wide"
)
names(wide)[names(wide) == "contribution.base"] <- "x"
names(wide)[names(wide) == "contribution.early"] <- "z"

base_areas <- areas[areas$vintage == "base",
                    c("area", "period", "population")]
d <- merge(outcomes, wide, by = c("area", "period"), sort = FALSE)
d <- merge(d, base_areas, by = c("area", "period"), sort = FALSE)

stopifnot(
  nrow(d) == 72L,
  all(complete.cases(d[c(
    "change_pp", "period", "control", "x", "z", "population"
  )])),
  all(d$population > 0)
)

period_numeric <- as.numeric(as.character(d$period))
stopifnot(all(is.finite(period_numeric)))

# Weighted 2SLS with the intercept, period, and control in both matrices.
C <- cbind(intercept = 1, period = period_numeric, control = d$control)
sw <- sqrt(d$population)
X <- cbind(C, x = d$x) * sw
Z <- cbind(C, z = d$z) * sw
fitted_X <- qr.fitted(qr(Z), X)
iv_slope <- unname(qr.coef(qr(fitted_X), d$change_pp * sw)["x"])

lookup <- function(column, target_period) {
  value <- d[d$area == 0 & period_numeric == target_period, column]
  stopifnot(length(value) == 1L)
  unname(value)
}

make_estimate <- function(term, value) {
  list(term = term, estimate = value, se = NULL, n_obs = 72L)
}

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = list(
    make_estimate("iv_slope", iv_slope),
    make_estimate("exposure_area0_period0", lookup("x", 0)),
    make_estimate("exposure_area0_period1", lookup("x", 1)),
    make_estimate("instrument_area0_period0", lookup("z", 0))
  ),
  method_metadata = list(
    estimator = "weighted two-stage least squares",
    endogenous_variable = "x",
    excluded_instrument = "z",
    exogenous_variables = c("intercept", "period", "control"),
    weight = "base-vintage population"
  ),
  diagnostics = list(n_obs = 72L)
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16)
