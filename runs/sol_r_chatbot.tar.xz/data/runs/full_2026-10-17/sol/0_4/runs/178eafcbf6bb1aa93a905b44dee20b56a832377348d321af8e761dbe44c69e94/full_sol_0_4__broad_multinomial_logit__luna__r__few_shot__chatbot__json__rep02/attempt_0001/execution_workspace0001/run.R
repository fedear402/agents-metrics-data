d <- read.csv("input.csv")
stopifnot(nrow(d) == 480L, all(d$y %in% 0:2))
d$y <- factor(d$y, levels = 0:2)

fit <- nnet::multinom(
  y ~ x + z,
  data = d,
  Hess = TRUE,
  trace = FALSE,
  maxit = 1000,
  reltol = 1e-12,
  abstol = 1e-12
)

B <- coef(fit)
V <- vcov(fit)
indices <- c(0, B[, "(Intercept)"])
weights <- exp(indices - max(indices))
prob_cat2_zero <- weights[3] / sum(weights)
n <- nrow(d)

slope <- function(term, outcome, variable) {
  name <- paste0(outcome, ":", variable)
  list(
    term = term,
    estimate = unname(B[outcome, variable]),
    se = unname(sqrt(V[name, name])),
    n_obs = n
  )
}

result <- list(
  task_id = "broad_multinomial_logit",
  platform = "r",
  estimates = list(
    slope("x_cat1", "1", "x"),
    slope("z_cat1", "1", "z"),
    slope("x_cat2", "2", "x"),
    slope("z_cat2", "2", "z"),
    list(
      term = "prob_cat2_zero",
      estimate = unname(prob_cat2_zero),
      se = NULL,
      n_obs = n
    )
  ),
  method_metadata = list(
    estimator = "multinomial logit maximum likelihood",
    vcov = "inverse observed information"
  ),
  diagnostics = list()
)

jsonlite::write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
