library(jsonlite)

crosswalk <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
trade <- read.csv("trade.csv", stringsAsFactors = FALSE)
areas <- read.csv("areas.csv", stringsAsFactors = FALSE)
employment <- read.csv("employment.csv", stringsAsFactors = FALSE)
outcomes <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

trade <- merge(trade, crosswalk, by = "code")
industries <- unique(trade["industry"])

cells <- merge(areas, industries, by = NULL)
cells <- merge(
  cells, employment,
  by = c("area", "period", "vintage", "industry"),
  all.x = TRUE,
  sort = FALSE
)
cells$employment[is.na(cells$employment)] <- 0

national <- aggregate(
  employment ~ period + vintage + industry,
  data = cells,
  FUN = sum
)
names(national)[names(national) == "employment"] <- "national_employment"

cells <- merge(cells, national, by = c("period", "vintage", "industry"))
cells <- merge(
  cells,
  trade[c("period", "industry", "us_change", "other_change",
          "price_index", "years")],
  by = c("period", "industry")
)

cells$trade_change <- ifelse(
  cells$vintage == "base", cells$us_change, cells$other_change
)
cells$contribution <-
  (cells$employment / cells$total_employment) *
  (cells$trade_change / cells$national_employment) /
  (cells$price_index / 100) / 1000 *
  (10 / cells$years)

exposures <- aggregate(
  contribution ~ area + period + vintage,
  data = cells,
  FUN = sum
)
base <- exposures[exposures$vintage == "base",
                  c("area", "period", "contribution")]
early <- exposures[exposures$vintage == "early",
                   c("area", "period", "contribution")]
names(base)[3] <- "x"
names(early)[3] <- "z"

sample <- merge(base, early, by = c("area", "period"))
sample <- merge(sample, outcomes, by = c("area", "period"))
weights <- areas[areas$vintage == "base",
                 c("area", "period", "population")]
sample <- merge(sample, weights, by = c("area", "period"))

stopifnot(nrow(sample) == 72L, all(sample$population > 0))

exogenous <- model.matrix(~ factor(period) + control, data = sample)
X <- cbind(exogenous, x = sample$x)
Z <- cbind(exogenous, z = sample$z)
w <- sample$population

iv_slope <- unname(solve(
  crossprod(Z, X * w),
  crossprod(Z, sample$change_pp * w)
)["x", 1])

get_value <- function(column, period_value) {
  selected <- sample[
    as.character(sample$area) == "0" &
      as.character(sample$period) == as.character(period_value),
    column
  ]
  stopifnot(length(selected) == 1L)
  unname(selected)
}

make_estimate <- function(term, value) {
  list(term = term, estimate = value, se = NULL, n_obs = 72L)
}

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = list(
    make_estimate("iv_slope", iv_slope),
    make_estimate("exposure_area0_period0", get_value("x", 0)),
    make_estimate("exposure_area0_period1", get_value("x", 1)),
    make_estimate("instrument_area0_period0", get_value("z", 0))
  ),
  method_metadata = list(
    estimator = "Population-weighted two-stage least squares",
    endogenous_variable = "x",
    excluded_instrument = "z",
    included_exogenous_variables = c("intercept", "period", "control"),
    exposure_unit = "thousands of real dollars per worker per decade",
    weight = "base-vintage population"
  ),
  diagnostics = list(n_obs = 72L)
)

write_json(result, "result.json", auto_unbox = TRUE, pretty = TRUE, digits = NA)
