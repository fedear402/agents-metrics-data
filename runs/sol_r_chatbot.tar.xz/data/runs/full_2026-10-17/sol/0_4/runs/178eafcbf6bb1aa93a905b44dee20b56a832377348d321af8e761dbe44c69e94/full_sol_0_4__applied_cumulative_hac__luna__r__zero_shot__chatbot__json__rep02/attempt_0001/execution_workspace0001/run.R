dat <- read.csv("input.csv", stringsAsFactors = FALSE)
dat <- dat[order(as.Date(dat$date)), ]

m <- nrow(dat)
stopifnot(m >= 32, all(dat$sales > 0), all(dat$vix > 0))

dvix <- diff(log(dat$vix))
t <- 16:m
n <- length(t)

x <- cbind(
  intercept = 1,
  sapply(1:15, function(k) dvix[t - k])
)
colnames(x) <- c("intercept", paste0("lag_", 1:15))
y <- log(dat$sales[t])

fit <- lm.fit(x, y)
stopifnot(fit$rank == ncol(x))

b <- fit$coefficients
scores <- x * as.vector(fit$residuals)
meat <- crossprod(scores)

for (j in 1:15) {
  cross <- crossprod(
    scores[(j + 1):n, , drop = FALSE],
    scores[1:(n - j), , drop = FALSE]
  )
  meat <- meat + (1 - j / 16) * (cross + t(cross))
}

bread <- solve(crossprod(x))
vcov <- (n / (n - 16)) * bread %*% meat %*% bread

weights <- rep(0, ncol(x))
weights[2:16] <- 1

estimates <- list(
  list(
    term = "cumulative_response",
    estimate = unname(as.numeric(crossprod(weights, b))),
    se = unname(sqrt(as.numeric(t(weights) %*% vcov %*% weights))),
    n_obs = n
  ),
  list(
    term = "lag_1",
    estimate = unname(b["lag_1"]),
    se = unname(sqrt(vcov["lag_1", "lag_1"])),
    n_obs = n
  ),
  list(
    term = "lag_15",
    estimate = unname(b["lag_15"]),
    se = unname(sqrt(vcov["lag_15", "lag_15"])),
    n_obs = n
  )
)

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "OLS with intercept and 15 lagged log-vix changes",
    vcov = "Newey-West, Bartlett weights, maximum lag 15, scaled by N/(N-16)"
  ),
  diagnostics = list()
)

writeLines(
  jsonlite::toJSON(result, auto_unbox = TRUE, digits = 16, pretty = TRUE),
  "result.json"
)
