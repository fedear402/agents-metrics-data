d <- read.csv("input.csv")
n <- nrow(d)
q <- 2L
df <- n - 4L
critical <- qf(0.95, q, df)

restricted_y <- residuals(lm(y ~ x, data = d))
restricted_endog <- residuals(lm(endog ~ x, data = d))
full_y <- residuals(lm(y ~ x + z1 + z2, data = d))
full_endog <- residuals(lm(endog ~ x + z1 + z2, data = d))

k <- q * critical / df
A <- sum(restricted_endog^2) - (1 + k) * sum(full_endog^2)
B <- -2 * (
  sum(restricted_y * restricted_endog) -
    (1 + k) * sum(full_y * full_endog)
)
C <- sum(restricted_y^2) - (1 + k) * sum(full_y^2)

discriminant <- B^2 - 4 * A * C
stopifnot(is.finite(discriminant), discriminant > 0, abs(A) > 1e-12)
boundaries <- sort(c(
  (-B - sqrt(discriminant)) / (2 * A),
  (-B + sqrt(discriminant)) / (2 * A)
))

restricted_ssr_one <- sum((restricted_y - restricted_endog)^2)
full_ssr_one <- sum((full_y - full_endog)^2)
ar_f_at_one <- ((restricted_ssr_one - full_ssr_one) / q) /
  (full_ssr_one / df)

row <- function(term, estimate) {
  list(term = term, estimate = unname(as.numeric(estimate)),
       se = NULL, n_obs = n)
}

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = list(
    row("boundary_low", boundaries[1]),
    row("boundary_high", boundaries[2]),
    row("accepts_zero", as.integer(C <= 0)),
    row("unbounded", as.integer(A < 0)),
    row("ar_f_at_one", ar_f_at_one)
  ),
  method_metadata = list(
    estimator = "Anderson-Rubin confidence set by quadratic inversion",
    vcov = "Conventional homoskedastic joint F test"
  ),
  diagnostics = list()
)

jsonlite::write_json(
  result, "result.json", auto_unbox = TRUE, null = "null",
  digits = 16, pretty = TRUE
)
