library(jsonlite)

data <- read.csv("input.csv")
data <- data[!is.na(data$score) & abs(data$score) < 1 &
               !is.na(data$earnings) & !is.na(data$participated), ]

score <- data$score
right <- as.numeric(score >= 0)
weights <- 1 - abs(score)
X <- cbind(1, right, score, right * score)
Y <- cbind(data$earnings, data$participated)

bread <- solve(crossprod(X, weights * X))
coefficients <- bread %*% crossprod(X, weights * Y)
residuals <- Y - X %*% coefficients

contrast <- c(0, 1, 0, 0)
jumps <- drop(contrast %*% coefficients)
loading <- weights * drop(X %*% bread %*% contrast)
influence <- loading * residuals
joint_vcov <- crossprod(influence)

reduced_form <- jumps[1]
first_stage <- jumps[2]
treatment_effect <- reduced_form / first_stage
gradient <- c(1 / first_stage, -reduced_form / first_stage^2)
treatment_var <- drop(t(gradient) %*% joint_vcov %*% gradient)
n_obs <- nrow(data)

row <- function(term, estimate, se) {
  list(term = term, estimate = unname(as.numeric(estimate)),
       se = unname(as.numeric(se)), n_obs = as.integer(n_obs))
}

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    row("treatment_effect", treatment_effect, sqrt(treatment_var)),
    row("reduced_form", reduced_form, sqrt(joint_vcov[1, 1])),
    row("first_stage", first_stage, sqrt(joint_vcov[2, 2]))
  ),
  method_metadata = list(
    estimator = "Fuzzy regression discontinuity ratio with triangular-weighted local linear fits",
    vcov = "Joint heteroskedasticity-robust HC0; fixed bandwidth and weights; delta method"
  ),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null",
           digits = 16, pretty = TRUE)
