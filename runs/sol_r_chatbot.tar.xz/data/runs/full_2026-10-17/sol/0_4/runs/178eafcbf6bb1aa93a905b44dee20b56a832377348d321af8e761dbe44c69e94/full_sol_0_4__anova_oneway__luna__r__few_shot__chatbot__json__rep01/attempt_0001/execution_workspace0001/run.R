library(jsonlite)

data <- read.csv("./input.csv")
data <- data[complete.cases(data[, c("group", "y")]), ]
data$group <- factor(data$group)

fit <- aov(y ~ group, data = data)
anova_row <- summary(fit)[[1]][1, ]
n <- nobs(fit)

out <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = list(
    list(term = "F", estimate = unname(anova_row[["F value"]]), se = NA_real_, n_obs = n),
    list(term = "df_num", estimate = unname(anova_row[["Df"]]), se = NA_real_, n_obs = n),
    list(term = "df_den", estimate = unname(df.residual(fit)), se = NA_real_, n_obs = n),
    list(term = "p_value", estimate = unname(anova_row[["Pr(>F)"]]), se = NA_real_, n_obs = n)
  ),
  method_metadata = list(estimator = "One-way ANOVA", vcov = "Classical"),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "result.json", auto_unbox = TRUE, digits = NA)
