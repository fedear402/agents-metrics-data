library(jsonlite)

crosswalk <- read.csv("crosswalk.csv")
trade <- read.csv("trade.csv")
areas <- read.csv("areas.csv")
employment <- read.csv("employment.csv")
outcomes <- read.csv("outcomes.csv")

trade_industry <- merge(trade, crosswalk, by = "code", sort = FALSE)
industries <- unique(crosswalk$industry)

cells <- merge(
  areas[, c("area", "period", "vintage")],
  data.frame(industry = industries),
  by = NULL
)
cells <- merge(
  cells,
  employment[, c("area", "period", "vintage", "industry", "employment")],
  by = c("area", "period", "vintage", "industry"),
  all.x = TRUE,
  sort = FALSE
)
cells$employment[is.na(cells$employment)] <- 0

national <- aggregate(
  employment ~ period + vintage + industry,
  data = cells,
  FUN = sum
)
names(national)[names(national) == "employment"] <- "national_employment"

cells <- merge(cells, national,
               by = c("period", "vintage", "industry"), sort = FALSE)
cells <- merge(cells, areas,
               by = c("area", "period", "vintage"), sort = FALSE)
cells <- merge(cells, trade_industry,
               by = c("period", "industry"), sort = FALSE)

cells$component <- with(cells, ifelse(
  vintage == "base",
  (employment / total_employment) *
    (us_change / national_employment) /
    (price_index / 100) / 1000 * (10 / years),
  (employment / total_employment) *
    (other_change / national_employment) /
    (price_index / 100) / 1000 * (10 / years)
))

exposures <- aggregate(
  component ~ area + period + vintage,
  data = cells,
  FUN = sum
)
base <- subset(exposures, vintage == "base",
               select = c("area", "period", "component"))
early <- subset(exposures, vintage == "early",
                select = c("area", "period", "component"))
names(base)[3] <- "x"
names(early)[3] <- "z"

sample <- merge(base, early, by = c("area", "period"))
sample <- merge(sample, outcomes, by = c("area", "period"))
weights <- subset(areas, vintage == "base",
                  select = c("area", "period", "population"))
sample <- merge(sample, weights, by = c("area", "period"))

X <- model.matrix(~ period + control + x, data = sample)
Z <- model.matrix(~ period + control + z, data = sample)
w <- sample$population
ZX <- crossprod(Z, X * w)
Zy <- crossprod(Z, sample$change_pp * w)
beta <- solve(ZX, Zy)
iv_slope <- unname(beta[match("x", colnames(X))])

value_at <- function(column, area, period) {
  value <- sample[sample$area == area & sample$period == period, column]
  stopifnot(length(value) == 1L)
  unname(value)
}

n_obs <- as.integer(nrow(sample))
stopifnot(n_obs == 72L)

terms <- c(
  "iv_slope",
  "exposure_area0_period0",
  "exposure_area0_period1",
  "instrument_area0_period0"
)
values <- c(
  iv_slope,
  value_at("x", 0, 0),
  value_at("x", 0, 1),
  value_at("z", 0, 0)
)

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = lapply(seq_along(terms), function(i) {
    list(term = terms[i], estimate = values[i], se = NULL, n_obs = n_obs)
  }),
  method_metadata = list(
    estimator = "population-weighted 2SLS",
    regressors = colnames(X),
    instruments = colnames(Z),
    exposure_unit = "thousands of real dollars per worker per decade"
  ),
  diagnostics = list(n_obs = n_obs)
)

jsonlite::write_json(
  result, "result.json",
  auto_unbox = TRUE, null = "null", digits = 15, pretty = TRUE
)
