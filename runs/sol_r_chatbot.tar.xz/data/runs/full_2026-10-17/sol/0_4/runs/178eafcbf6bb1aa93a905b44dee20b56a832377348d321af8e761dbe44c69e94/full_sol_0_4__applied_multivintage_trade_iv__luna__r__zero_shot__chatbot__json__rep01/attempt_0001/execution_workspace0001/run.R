library(jsonlite)

crosswalk <- read.csv("crosswalk.csv")
trade <- read.csv("trade.csv")
areas <- read.csv("areas.csv")
employment <- read.csv("employment.csv")
outcomes <- read.csv("outcomes.csv")

trade <- merge(trade, crosswalk, by = "code")
industry_changes <- aggregate(
  cbind(us_change, other_change) ~ period + industry + price_index + years,
  data = trade,
  FUN = sum
)

industries <- unique(crosswalk["industry"])
area_vintages <- unique(areas[c("area", "period", "vintage")])
cells <- merge(area_vintages, industries)
cells <- merge(
  cells, employment,
  by = c("area", "period", "vintage", "industry"),
  all.x = TRUE
)
cells$employment[is.na(cells$employment)] <- 0

national <- aggregate(
  employment ~ period + vintage + industry,
  data = cells,
  FUN = sum
)
names(national)[names(national) == "employment"] <- "national_employment"

cells <- merge(cells, national, by = c("period", "vintage", "industry"))
cells <- merge(
  cells,
  areas[c("area", "period", "vintage", "total_employment", "population")],
  by = c("area", "period", "vintage")
)
cells <- merge(cells, industry_changes, by = c("period", "industry"))

cells$contribution <- with(
  cells,
  (employment / total_employment) *
    (ifelse(vintage == "base", us_change, other_change) /
       national_employment) /
    (price_index / 100) / 1000 * (10 / years)
)

exposures <- aggregate(
  contribution ~ area + period + vintage,
  data = cells,
  FUN = sum
)
wide <- reshape(
  exposures,
  idvar = c("area", "period"),
  timevar = "vintage",
  direction = "wide"
)
names(wide)[names(wide) == "contribution.base"] <- "x"
names(wide)[names(wide) == "contribution.early"] <- "z"

base_areas <- areas[areas$vintage == "base",
                    c("area", "period", "population")]
sample <- merge(outcomes, wide, by = c("area", "period"))
sample <- merge(sample, base_areas, by = c("area", "period"))

# Weighted 2SLS uses the same population weights in both projections.
X <- model.matrix(~ period + control + x, data = sample)
Z <- model.matrix(~ period + control + z, data = sample)
w <- sample$population
zwx <- crossprod(Z, w * X)
zwy <- crossprod(Z, w * sample$change_pp)
beta <- solve(zwx, zwy)
iv_slope <- unname(beta[which(colnames(X) == "x")])

get_exposure <- function(column, period_value) {
  value <- sample[sample$area == 0 & sample$period == period_value, column]
  stopifnot(length(value) == 1L)
  unname(value)
}

terms <- c(
  "iv_slope",
  "exposure_area0_period0",
  "exposure_area0_period1",
  "instrument_area0_period0"
)
values <- c(
  iv_slope,
  get_exposure("x", 0),
  get_exposure("x", 1),
  get_exposure("z", 0)
)
stopifnot(nrow(sample) == 72L, all(is.finite(values)))

estimates <- lapply(seq_along(terms), function(i) {
  list(term = terms[i], estimate = values[i], se = NULL, n_obs = 72L)
})

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "population-weighted two-stage least squares",
    endogenous_variable = "x",
    instruments = c("intercept", "period", "control", "z"),
    employment_vintages = list(exposure = "base", instrument = "early"),
    exposure_units = "thousands of real dollars per worker per decade"
  ),
  diagnostics = list(n_obs = 72L)
)

jsonlite::write_json(
  result, "result.json", auto_unbox = TRUE, pretty = TRUE, null = "null",
  digits = NA
)
