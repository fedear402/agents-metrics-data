library(jsonlite)

data <- read.csv("input.csv")

cohorts <- c(3, 5, 7)
results <- lapply(cohorts, function(c) {
  window <- (c - 2):(c + 2)
  comparison <- subset(
    data,
    time %in% window & (g == c | g == 0 | g > c + 2)
  )

  balanced_ids <- names(which(
    tapply(comparison$time, comparison$id, function(x) {
      length(unique(x)) == length(window)
    })
  ))
  comparison <- comparison[as.character(comparison$id) %in% balanced_ids, ]
  comparison$did <- as.integer(comparison$g == c & comparison$time >= c)

  fit <- lm(y ~ did + factor(id) + factor(time), data = comparison)

  list(
    estimate = unname(coef(fit)[["did"]]),
    n_obs = nrow(comparison),
    n_treated = length(unique(comparison$id[comparison$g == c]))
  )
})

estimates <- vapply(results, `[[`, numeric(1), "estimate")
n_obs <- vapply(results, `[[`, integer(1), "n_obs")
weights <- vapply(results, `[[`, integer(1), "n_treated")

output <- list(
  task_id = "broad_cohort_stack",
  platform = "r",
  estimates = lapply(seq_along(cohorts), function(i) {
    list(
      term = paste0("att_g", cohorts[i]),
      estimate = estimates[i],
      se = NULL,
      n_obs = n_obs[i]
    )
  }),
  method_metadata = list(),
  diagnostics = list()
)

output$estimates[[length(cohorts) + 1]] <- list(
  term = "att_weighted",
  estimate = weighted.mean(estimates, weights),
  se = NULL,
  n_obs = sum(n_obs)
)

write_json(output, "result.json", auto_unbox = TRUE, null = "null", digits = 16)
