data <- read.csv("input.csv")
data <- data[order(as.Date(data$date)), ]

log_vix <- log(data$vix)
change <- c(NA_real_, diff(log_vix))
n <- nrow(data)

lagged <- sapply(1:15, function(k) {
  c(rep(NA_real_, k), change[seq_len(n - k)])
})
colnames(lagged) <- paste0("lag_", 1:15)

reg_data <- data.frame(log_sales = log(data$sales), lagged)
reg_data <- reg_data[complete.cases(reg_data), ]

fit <- lm(log_sales ~ ., data = reg_data)
X <- model.matrix(fit)
u <- residuals(fit)
N <- nrow(X)
K <- ncol(X)
scores <- X * as.numeric(u)

S <- crossprod(scores)
for (j in 1:15) {
  cross_j <- crossprod(
    scores[(j + 1):N, , drop = FALSE],
    scores[1:(N - j), , drop = FALSE]
  )
  S <- S + (1 - j / 16) * (cross_j + t(cross_j))
}

bread <- solve(crossprod(X))
V <- (N / (N - 16)) * bread %*% S %*% bread
beta <- coef(fit)

weights <- setNames(rep(0, K), colnames(X))
weights[paste0("lag_", 1:15)] <- 1
cumulative_estimate <- sum(weights * beta)
cumulative_se <- sqrt(as.numeric(t(weights) %*% V %*% weights))

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(term = "cumulative_response", estimate = cumulative_estimate,
         se = cumulative_se, n_obs = N),
    list(term = "lag_1", estimate = unname(beta["lag_1"]),
         se = sqrt(V["lag_1", "lag_1"]), n_obs = N),
    list(term = "lag_15", estimate = unname(beta["lag_15"]),
         se = sqrt(V["lag_15", "lag_15"]), n_obs = N)
  ),
  method_metadata = list(
    estimator = "OLS with intercept and 15 lagged log-vix changes",
    vcov = "Newey-West, Bartlett lag 15, multiplied by N/(N-16)"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = NA)
