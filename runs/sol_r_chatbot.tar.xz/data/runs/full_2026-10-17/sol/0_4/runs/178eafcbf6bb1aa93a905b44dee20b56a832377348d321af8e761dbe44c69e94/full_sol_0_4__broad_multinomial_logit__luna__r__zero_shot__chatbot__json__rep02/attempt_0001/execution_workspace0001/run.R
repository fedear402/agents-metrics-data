dat <- read.csv("input.csv")
stopifnot(nrow(dat) == 480L, all(complete.cases(dat[, c("y", "x", "z")])))
stopifnot(all(dat$y %in% 0:2))

X <- model.matrix(~ x + z, data = dat)
y <- as.integer(dat$y)
n <- nrow(dat)
p <- ncol(X)

neg_log_lik <- function(beta) {
  B <- matrix(beta, nrow = p, ncol = 2)
  eta <- X %*% B
  max_eta <- pmax(0, eta[, 1], eta[, 2])
  log_denom <- max_eta +
    log(exp(-max_eta) + exp(eta[, 1] - max_eta) +
          exp(eta[, 2] - max_eta))
  -sum((y == 1L) * eta[, 1] + (y == 2L) * eta[, 2] - log_denom)
}

gradient <- function(beta) {
  B <- matrix(beta, nrow = p, ncol = 2)
  eta <- X %*% B
  max_eta <- pmax(0, eta[, 1], eta[, 2])
  denom <- exp(-max_eta) + exp(eta[, 1] - max_eta) +
    exp(eta[, 2] - max_eta)
  probs <- exp(eta - max_eta) / denom
  as.vector(crossprod(X, probs - cbind(y == 1L, y == 2L)))
}

fit <- optim(rep(0, 2L * p), neg_log_lik, gradient,
             method = "BFGS",
             control = list(reltol = 1e-12, maxit = 10000))
stopifnot(fit$convergence == 0L)

B <- matrix(fit$par, nrow = p, ncol = 2)
eta <- X %*% B
max_eta <- pmax(0, eta[, 1], eta[, 2])
denom <- exp(-max_eta) + exp(eta[, 1] - max_eta) +
  exp(eta[, 2] - max_eta)
probs <- exp(eta - max_eta) / denom
p1 <- probs[, 1]
p2 <- probs[, 2]

H11 <- crossprod(X, X * (p1 * (1 - p1)))
H22 <- crossprod(X, X * (p2 * (1 - p2)))
H12 <- crossprod(X, X * (-p1 * p2))
information <- rbind(cbind(H11, H12), cbind(H12, H22))
se <- sqrt(diag(solve(information)))

coef_names <- colnames(X)
get_index <- function(name, category) {
  match(name, coef_names) + (category - 1L) * p
}
make_row <- function(term, index) {
  list(term = term, estimate = unname(fit$par[index]),
       se = unname(se[index]), n_obs = n)
}

eta_zero <- B[match("(Intercept)", coef_names), ]
max_zero <- max(0, eta_zero)
prob_cat2_zero <- exp(eta_zero[2] - max_zero) /
  (exp(-max_zero) + sum(exp(eta_zero - max_zero)))

result <- list(
  task_id = "broad_multinomial_logit",
  platform = "r",
  estimates = list(
    make_row("x_cat1", get_index("x", 1L)),
    make_row("z_cat1", get_index("z", 1L)),
    make_row("x_cat2", get_index("x", 2L)),
    make_row("z_cat2", get_index("z", 2L)),
    list(term = "prob_cat2_zero",
         estimate = unname(prob_cat2_zero), se = NULL, n_obs = n)
  ),
  method_metadata = list(
    estimator = "multinomial logit maximum likelihood, base outcome 0",
    vcov = "inverse observed information"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE,
                     digits = 16, pretty = TRUE, null = "null")
