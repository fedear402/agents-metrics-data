d <- read.csv("input.csv")
d$y <- factor(d$y, levels = 0:2)

fit <- nnet::multinom(
  y ~ x + z,
  data = d,
  Hess = TRUE,
  trace = FALSE,
  maxit = 1000,
  reltol = 1e-12,
  abstol = 1e-12
)

B <- coef(fit)
V <- vcov(fit)
indices <- c(0, B["1", "(Intercept)"], B["2", "(Intercept)"])
p <- exp(indices - max(indices))
p <- p / sum(p)
n <- nrow(d)

slope_row <- function(term, category, variable) {
  name <- paste0(category, ":", variable)
  list(
    term = term,
    estimate = unname(B[category, variable]),
    se = unname(sqrt(V[name, name])),
    n_obs = n
  )
}

result <- list(
  task_id = "broad_multinomial_logit",
  platform = "r",
  estimates = list(
    slope_row("x_cat1", "1", "x"),
    slope_row("z_cat1", "1", "z"),
    slope_row("x_cat2", "2", "x"),
    slope_row("z_cat2", "2", "z"),
    list(term = "prob_cat2_zero", estimate = unname(p[3]), se = NULL, n_obs = n)
  ),
  method_metadata = list(
    estimator = "maximum likelihood multinomial logit; outcome 0 base",
    vcov = "inverse observed-information Hessian"
  ),
  diagnostics = list()
)

jsonlite::write_json(
  result, "result.json",
  auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE
)
