data <- read.csv("./input.csv", stringsAsFactors = FALSE)

required <- c("group", "y")
if (!all(required %in% names(data))) {
  stop("input.csv must contain group and y columns")
}

data <- data[complete.cases(data[, required]), required]
data$group <- factor(data$group)
data$y <- as.numeric(data$y)

if (nlevels(data$group) < 2L) {
  stop("ANOVA requires at least two groups")
}

fit <- aov(y ~ group, data = data)
table <- summary(fit)[[1L]]

values <- c(
  F = table["group", "F value"],
  df_num = table["group", "Df"],
  df_den = table["Residuals", "Df"],
  p_value = table["group", "Pr(>F)"]
)

json_number <- function(x) {
  if (is.na(x) || !is.finite(x)) {
    stop("ANOVA produced a non-finite result")
  }
  format(x, digits = 17L, scientific = TRUE, trim = TRUE)
}

n_obs <- nobs(fit)
rows <- vapply(names(values), function(term) {
  sprintf(
    '{"term":"%s","estimate":%s,"se":null,"n_obs":%d}',
    term, json_number(values[[term]]), n_obs
  )
}, character(1L))

output <- sprintf(
  paste0(
    '{"task_id":"anova_oneway","platform":"r","estimates":[%s],',
    '"method_metadata":{"estimator":"one-way ANOVA","vcov":"classical"},',
    '"diagnostics":{}}'
  ),
  paste(rows, collapse = ",")
)

writeLines(output, "result.json", useBytes = TRUE)
