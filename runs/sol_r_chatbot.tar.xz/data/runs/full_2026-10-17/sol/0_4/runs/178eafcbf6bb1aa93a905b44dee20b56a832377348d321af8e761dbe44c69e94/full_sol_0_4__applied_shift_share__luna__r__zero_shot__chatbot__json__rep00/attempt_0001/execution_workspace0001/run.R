d <- read.csv("input.csv", stringsAsFactors = FALSE)

regions <- unique(d$region_id)
industries <- unique(d$industry_id)
r <- match(d$region_id, regions)
n <- match(d$industry_id, industries)
R <- length(regions)
N <- length(industries)

region_row <- match(regions, d$region_id)
industry_row <- match(industries, d$industry_id)

e <- d$region_weight[region_row]
e <- e / sum(e)
x <- d$x[region_row]
y <- d$y[region_row]
shock <- d$shock[industry_row]

z <- as.numeric(rowsum(d$share * shock[n], r, reorder = TRUE))
x0 <- x - sum(e * x)
y0 <- y - sum(e * y)
z0 <- z - sum(e * z)

exposure <- e[r] * d$share
aggregate_industry <- function(v) {
  as.numeric(rowsum(exposure * v[r], n, reorder = TRUE))
}
s <- as.numeric(rowsum(exposure, n, reorder = TRUE))
stopifnot(all(s > 0))

ybar <- aggregate_industry(y0) / s
xbar <- aggregate_industry(x0) / s
zbar <- aggregate_industry(z0) / s

weighted_iv <- function(outcome, regressor, instrument, weights) {
  X <- cbind(1, regressor)
  Z <- cbind(1, instrument)
  A <- crossprod(Z, weights * X)
  beta <- solve(A, crossprod(Z, weights * outcome))
  u <- as.numeric(outcome - X %*% beta)
  meat <- crossprod(Z, (weights * u)^2 * Z)
  Ainv <- solve(A)
  vcov <- (N / (N - 2)) * Ainv %*% meat %*% t(Ainv)
  c(estimate = unname(beta[2]), se = sqrt(vcov[2, 2]))
}

effect <- weighted_iv(ybar, xbar, shock, s)
first_stage <- weighted_iv(xbar, zbar, shock, s)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = effect["estimate"],
         se = effect["se"], n_obs = N),
    list(term = "first_stage", estimate = first_stage["estimate"],
         se = first_stage["se"], n_obs = N),
    list(term = "effective_shocks", estimate = 1 / sum(s^2),
         se = NULL, n_obs = N)
  ),
  method_metadata = list(
    estimator = "Weighted regional 2SLS with BHJ shock-level aggregation",
    vcov = "Shock-level heteroskedasticity-robust HC1; multiplier N/(N-2)"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = NA)
