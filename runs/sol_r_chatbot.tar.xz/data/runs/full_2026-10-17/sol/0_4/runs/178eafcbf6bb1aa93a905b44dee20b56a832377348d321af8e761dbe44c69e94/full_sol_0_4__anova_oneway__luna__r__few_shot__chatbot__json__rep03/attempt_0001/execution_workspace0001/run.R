library(jsonlite)

dat <- read.csv("./input.csv")
dat <- dat[complete.cases(dat[, c("group", "y")]), ]
dat$group <- factor(dat$group)
fit <- aov(y ~ group, data = dat)
tab <- summary(fit)[[1]]

n <- nrow(dat)
values <- c(
  F = unname(tab[1, "F value"]),
  df_num = unname(tab[1, "Df"]),
  df_den = unname(tab[2, "Df"]),
  p_value = unname(tab[1, "Pr(>F)"])
)

out <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = lapply(names(values), function(term) {
    list(term = term, estimate = unname(values[[term]]), se = NA_real_,
         n_obs = n)
  }),
  method_metadata = list(
    estimator = "One-way ANOVA",
    vcov = "Classical homoskedastic"
  ),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "result.json", auto_unbox = TRUE, digits = NA)
