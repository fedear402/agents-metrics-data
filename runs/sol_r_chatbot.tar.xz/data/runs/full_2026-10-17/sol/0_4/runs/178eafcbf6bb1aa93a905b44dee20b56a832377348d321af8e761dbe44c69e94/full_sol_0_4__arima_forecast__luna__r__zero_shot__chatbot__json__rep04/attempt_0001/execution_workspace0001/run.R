dat <- read.csv("./input.csv")
stopifnot(all(c("t", "y") %in% names(dat)))

dat <- dat[order(dat$t), ]
stopifnot(
  nrow(dat) == 250L,
  identical(as.numeric(dat$t), seq_len(250)),
  all(is.finite(dat$y))
)

fit <- stats::arima(
  dat$y,
  order = c(1L, 1L, 1L),
  include.mean = FALSE,
  method = "ML"
)

pred <- stats::predict(fit, n.ahead = 1L)
forecast <- as.numeric(pred$pred[1L])
se <- as.numeric(pred$se[1L])
margin <- stats::qnorm(0.975) * se
n_obs <- nrow(dat)

json <- sprintf(
  paste0(
    '{"task_id":"arima_forecast","platform":"r","estimates":[',
    '{"term":"forecast","estimate":%.15g,"se":%.15g,"n_obs":%d},',
    '{"term":"lower_95","estimate":%.15g,"se":null,"n_obs":%d},',
    '{"term":"upper_95","estimate":%.15g,"se":null,"n_obs":%d}',
    '],"method_metadata":{"estimator":"ARIMA(1,1,1), no drift, maximum likelihood",',
    '"vcov":"ARIMA one-step forecast variance"},"diagnostics":{}}'
  ),
  forecast, se, n_obs,
  forecast - margin, n_obs,
  forecast + margin, n_obs
)

writeLines(json, "result.json")
