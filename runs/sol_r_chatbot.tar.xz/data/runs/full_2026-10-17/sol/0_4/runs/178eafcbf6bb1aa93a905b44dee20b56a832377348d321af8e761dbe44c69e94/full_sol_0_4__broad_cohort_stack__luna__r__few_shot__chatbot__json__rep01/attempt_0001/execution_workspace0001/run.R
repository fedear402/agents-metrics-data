d <- read.csv("input.csv")

cohorts <- c(3L, 5L, 7L)

results <- lapply(cohorts, function(cohort) {
  window <- (cohort - 2L):(cohort + 2L)
  comparison <- subset(
    d,
    time %in% window & (g == cohort | g == 0 | g > cohort + 2L)
  )

  counts <- table(comparison$id)
  balanced_ids <- names(counts[counts == length(window)])
  comparison <- comparison[
    as.character(comparison$id) %in% balanced_ids,
    ,
    drop = FALSE
  ]

  comparison$did <- as.numeric(
    comparison$g == cohort & comparison$time >= cohort
  )

  fit <- lm(
    y ~ did + factor(id) + factor(time),
    data = comparison
  )

  list(
    estimate = unname(coef(fit)[["did"]]),
    n_obs = nrow(comparison),
    treated_units = length(unique(comparison$id[comparison$g == cohort]))
  )
})

weights <- vapply(results, `[[`, numeric(1), "treated_units")
estimates <- vapply(results, `[[`, numeric(1), "estimate")
row_counts <- vapply(results, `[[`, integer(1), "n_obs")

output <- list(
  task_id = "broad_cohort_stack",
  platform = "r",
  estimates = c(
    Map(
      function(cohort, estimate, n_obs) {
        list(
          term = paste0("att_g", cohort),
          estimate = estimate,
          se = NULL,
          n_obs = n_obs
        )
      },
      cohorts,
      estimates,
      row_counts
    ),
    list(
      list(
        term = "att_weighted",
        estimate = weighted.mean(estimates, weights),
        se = NULL,
        n_obs = sum(row_counts)
      )
    )
  ),
  method_metadata = list(),
  diagnostics = list()
)

jsonlite::write_json(
  output,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16
)
