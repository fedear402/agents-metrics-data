library(jsonlite)

households <- read.csv("households.csv")
census <- read.csv("census.csv")

d <- households[households$recipient == 0, ]
n_obs <- nrow(d)

stopifnot(
  n_obs > 0,
  all(d$eligible %in% c(0, 1)),
  all(d$weight > 0),
  all(c(0, 1) %in% census$eligible)
)

g0 <- 1 - d$eligible
g1 <- d$eligible

C <- cbind(
  ineligible = g0,
  eligible = g1,
  baseline_ineligible = d$baseline * g0,
  baseline_eligible = d$baseline * g1
)
X <- cbind(
  C,
  dose_ineligible = d$dose * g0,
  dose_eligible = d$dose * g1
)
Z <- cbind(
  C,
  instrument_ineligible = d$instrument * g0,
  instrument_eligible = d$instrument * g1
)

sqrt_weight <- sqrt(d$weight)
Xw <- X * sqrt_weight
Zw <- Z * sqrt_weight
yw <- d$outcome * sqrt_weight

z_qr <- qr(Zw)
stopifnot(z_qr$rank == ncol(Zw))
fitted_Xw <- qr.fitted(z_qr, Xw)
second_stage_qr <- qr(fitted_Xw)
stopifnot(second_stage_qr$rank == ncol(Xw))

slopes <- qr.coef(second_stage_qr, yw)
mean_dose_0 <- weighted.mean(d$dose[d$eligible == 0], d$weight[d$eligible == 0])
mean_dose_1 <- weighted.mean(d$dose[d$eligible == 1], d$weight[d$eligible == 1])

effects <- c(
  ineligible_effect = slopes["dose_ineligible"] * mean_dose_0,
  eligible_nonrecipient_effect = slopes["dose_eligible"] * mean_dose_1
)

population <- census$nonrecipient_population[match(c(0, 1), census$eligible)]
stopifnot(all(is.finite(population)), all(population >= 0), sum(population) > 0)
population_effect <- weighted.mean(unname(effects), population)

estimates <- lapply(
  names(c(effects, population_effect = population_effect)),
  function(term) {
    values <- c(effects, population_effect = population_effect)
    list(
      term = term,
      estimate = unname(as.numeric(values[[term]])),
      se = NULL,
      n_obs = as.integer(n_obs)
    )
  }
)

result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "weighted_2sls",
    sample = "households with recipient == 0",
    intercept = "none beyond the two eligibility indicators",
    counterfactual = "dose set to zero for every retained household",
    group_effect = "group dose slope times household-weighted mean dose",
    population_aggregation = "group effects weighted by census nonrecipient_population",
    attribution = "zero-dose counterfactual is a stated synthetic convention"
  ),
  diagnostics = list(
    n_obs = as.integer(n_obs),
    n_ineligible = as.integer(sum(d$eligible == 0)),
    n_eligible = as.integer(sum(d$eligible == 1)),
    instrument_rank = as.integer(z_qr$rank),
    fitted_regressor_rank = as.integer(second_stage_qr$rank)
  )
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 15)
