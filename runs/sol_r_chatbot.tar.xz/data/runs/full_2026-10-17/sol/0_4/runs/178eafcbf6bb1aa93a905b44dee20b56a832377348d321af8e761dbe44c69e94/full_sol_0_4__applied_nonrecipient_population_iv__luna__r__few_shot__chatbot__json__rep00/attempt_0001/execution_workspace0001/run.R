library(jsonlite)

task_id <- "applied_nonrecipient_population_iv"

households <- read.csv("households.csv")
census <- read.csv("census.csv")
d <- households[households$recipient == 0, ]
n_obs <- nrow(d)

g0 <- as.numeric(d$eligible == 0)
g1 <- as.numeric(d$eligible == 1)

C <- cbind(
  ineligible = g0,
  eligible = g1,
  baseline_ineligible = d$baseline * g0,
  baseline_eligible = d$baseline * g1
)
X <- cbind(C, dose_ineligible = d$dose * g0, dose_eligible = d$dose * g1)
Z <- cbind(C, instrument_ineligible = d$instrument * g0,
           instrument_eligible = d$instrument * g1)

sw <- sqrt(d$weight)
Xw <- X * sw
Zw <- Z * sw
fitted_Xw <- qr.fitted(qr(Zw), Xw)
beta <- qr.coef(qr(fitted_Xw), d$outcome * sw)

mean_dose_0 <- weighted.mean(d$dose[g0 == 1], d$weight[g0 == 1])
mean_dose_1 <- weighted.mean(d$dose[g1 == 1], d$weight[g1 == 1])

ineligible_effect <- unname(beta["dose_ineligible"] * mean_dose_0)
eligible_nonrecipient_effect <- unname(beta["dose_eligible"] * mean_dose_1)

population <- census$nonrecipient_population[match(c(0, 1), census$eligible)]
population_effect <- weighted.mean(
  c(ineligible_effect, eligible_nonrecipient_effect),
  population
)

estimate <- function(term, value) {
  list(term = term, estimate = unname(as.numeric(value)), se = NULL,
       n_obs = as.integer(n_obs))
}

result <- list(
  task_id = task_id,
  platform = "r",
  estimates = list(
    estimate("ineligible_effect", ineligible_effect),
    estimate("eligible_nonrecipient_effect", eligible_nonrecipient_effect),
    estimate("population_effect", population_effect)
  ),
  method_metadata = list(
    method = "weighted 2SLS",
    sample = "households with recipient == 0",
    counterfactual = "dose set to zero for every retained household",
    group_effect = "dose slope times household-weighted group mean dose",
    population_weights = "census nonrecipient_population"
  ),
  diagnostics = list(
    n_obs = as.integer(n_obs),
    group_n_obs = list(
      ineligible = as.integer(sum(g0)),
      eligible = as.integer(sum(g1))
    )
  )
)

write_json(result, "result.json", auto_unbox = TRUE, pretty = TRUE,
           digits = NA, null = "null")
