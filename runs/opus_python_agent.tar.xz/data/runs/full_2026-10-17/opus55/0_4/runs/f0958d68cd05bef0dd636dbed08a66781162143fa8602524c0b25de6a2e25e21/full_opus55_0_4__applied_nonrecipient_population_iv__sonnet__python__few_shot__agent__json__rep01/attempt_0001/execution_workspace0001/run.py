import json, numpy as np, pandas as pd
from linearmodels.iv import IV2SLS
h = pd.read_csv('households.csv'); c = pd.read_csv('census.csv')
d = h[h.recipient == 0].copy()
e = d.eligible; ne = 1 - e
X = pd.DataFrame({'ne': ne, 'e': e, 'b_ne': d.baseline*ne, 'b_e': d.baseline*e})
D = pd.DataFrame({'d_ne': d.dose*ne, 'd_e': d.dose*e})
Z = pd.DataFrame({'z_ne': d.instrument*ne, 'z_e': d.instrument*e})
fit = IV2SLS(d.outcome, X, D, Z, weights=d.weight).fit()
n = int(len(d))
# independent check: manual weighted 2SLS
W = d.weight.values; Xf = np.column_stack([X, D]); Zf = np.column_stack([X, Z])
Pz = Zf @ np.linalg.solve(Zf.T @ (W[:,None]*Zf), Zf.T @ (W[:,None]*Xf))
bm = np.linalg.solve(Pz.T @ (W[:,None]*Xf), Pz.T @ (W*d.outcome.values))
assert np.allclose(bm[-2:], fit.params[['d_ne','d_e']].values)
eff = {}
for g, k in [(0, 'd_ne'), (1, 'd_e')]:
    s = d[d.eligible == g]
    eff[g] = float(fit.params[k] * np.average(s.dose, weights=s.weight))
pop = c.set_index('eligible').nonrecipient_population
pe = float((eff[0]*pop[0] + eff[1]*pop[1]) / (pop[0] + pop[1]))
est = [{'term': t, 'estimate': v, 'se': None, 'n_obs': n} for t, v in
       [('ineligible_effect', eff[0]), ('eligible_nonrecipient_effect', eff[1]), ('population_effect', pe)]]
res = {'task_id': 'applied_nonrecipient_population_iv', 'platform': 'python', 'estimates': est,
       'method_metadata': {'estimator': 'weighted IV2SLS, interacted by eligibility', 'weights': 'weight',
                           'aggregation_weights': {str(k): int(v) for k, v in pop.items()}},
       'diagnostics': {'slopes': {k: float(fit.params[k]) for k in ['d_ne','d_e']},
                       'n_by_group': {str(g): int((d.eligible==g).sum()) for g in [0,1]},
                       'manual_2sls_match': True}}
json.dump(res, open('result.json', 'w'), indent=2)
print(json.dumps(res, indent=2))
