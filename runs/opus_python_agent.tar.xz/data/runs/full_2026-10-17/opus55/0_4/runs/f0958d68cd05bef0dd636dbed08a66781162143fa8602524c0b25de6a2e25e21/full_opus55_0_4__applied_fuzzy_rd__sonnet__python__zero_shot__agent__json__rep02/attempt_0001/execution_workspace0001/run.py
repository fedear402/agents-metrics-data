import pandas as pd, numpy as np, json
import statsmodels.api as sm
d = pd.read_csv("input.csv")
d = d[d.score.abs() < 1].copy()
s = d.score.values; w = 1 - np.abs(s); D = (s >= 0).astype(float)
X = np.column_stack([np.ones_like(s), D, s, D*s])
A = X.T @ (w[:, None]*X); Ai = np.linalg.inv(A)
def fit(y):
    b = Ai @ X.T @ (w*y); return b, y - X @ b
by, ey = fit(d.earnings.values.astype(float))
bd, ed = fit(d.participated.values.astype(float))
# influence of D coefficient (index 1) per obs
IF = (Ai @ (X*(w[:, None])).T)[1]
vy = np.sum((IF*ey)**2); vd = np.sum((IF*ed)**2); cyd = np.sum(IF**2*ey*ed)
rf, fs = by[1], bd[1]; te = rf/fs
g = np.array([1/fs, -rf/fs**2]); V = np.array([[vy, cyd], [cyd, vd]])
se_te = float(np.sqrt(g @ V @ g)); n = len(d)
# check vs statsmodels
for y, v in [(d.earnings, vy), (d.participated, vd)]:
    r = sm.WLS(y.values, X, weights=w).fit(cov_type="HC0")
    assert np.isclose(r.bse[1], np.sqrt(v)), (r.bse[1], np.sqrt(v))
res = {"task_id": "applied_fuzzy_rd", "platform": "python",
 "estimates": [
  {"term": "treatment_effect", "estimate": float(te), "se": se_te, "n_obs": n},
  {"term": "reduced_form", "estimate": float(rf), "se": float(np.sqrt(vy)), "n_obs": n},
  {"term": "first_stage", "estimate": float(fs), "se": float(np.sqrt(vd)), "n_obs": n}],
 "method_metadata": {"estimator": "fuzzy RD, local linear, triangular kernel, h=1, Wald ratio",
                     "vcov": "HC0, delta method with joint covariance"},
 "diagnostics": {"cov_rf_fs": float(cyd), "n_left": int((D==0).sum()), "n_right": int((D==1).sum())}}
json.dump(res, open("result.json", "w"), indent=2)
print(json.dumps(res, indent=2))
