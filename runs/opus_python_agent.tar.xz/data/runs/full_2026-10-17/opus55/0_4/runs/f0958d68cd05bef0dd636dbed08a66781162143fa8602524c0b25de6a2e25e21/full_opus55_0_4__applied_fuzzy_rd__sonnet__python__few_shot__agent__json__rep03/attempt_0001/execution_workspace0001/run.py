import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("input.csv")
d = df[np.abs(df["score"]) < 1].copy()
n = len(d)
s = d["score"].to_numpy(float)
w = 1 - np.abs(s)
r = (s >= 0).astype(float)
X = np.column_stack([np.ones(n), s, r, r * s])
Y = d[["earnings", "participated"]].to_numpy(float)
bread = np.linalg.inv(X.T @ (w[:, None] * X))
coef = bread @ X.T @ (w[:, None] * Y)
res = Y - X @ coef
c = np.array([0., 0., 1., 0.])
rf, fs = c @ coef
load = w * (X @ bread @ c)
inf = load[:, None] * res
V = inf.T @ inf
g = np.array([1 / fs, -rf / fs**2])
te = rf / fs
te_se = float(np.sqrt(g @ V @ g))

# check vs statsmodels WLS HC0
chk = [sm.WLS(Y[:, k], X, weights=w).fit(cov_type="HC0") for k in range(2)]
assert np.allclose([chk[0].params[2], chk[1].params[2]], [rf, fs])
assert np.allclose([chk[0].bse[2], chk[1].bse[2]], np.sqrt(np.diag(V)))

rows = [
    {"term": "treatment_effect", "estimate": float(te), "se": te_se, "n_obs": n},
    {"term": "reduced_form", "estimate": float(rf), "se": float(np.sqrt(V[0, 0])), "n_obs": n},
    {"term": "first_stage", "estimate": float(fs), "se": float(np.sqrt(V[1, 1])), "n_obs": n},
]
out = {"task_id": "applied_fuzzy_rd", "platform": "python", "estimates": rows,
       "method_metadata": {"estimator": "fuzzy RD local linear, triangular kernel, h=1, ratio of WLS discontinuities",
                           "vcov": "HC0 joint, delta method with covariance"},
       "diagnostics": {"cov_rf_fs": float(V[0, 1]), "n_left": int((r == 0).sum()), "n_right": int(r.sum()), "n_total_file": len(df)}}
json.dump(out, open("result.json", "w"), indent=2)
print(json.dumps(out, indent=2))
