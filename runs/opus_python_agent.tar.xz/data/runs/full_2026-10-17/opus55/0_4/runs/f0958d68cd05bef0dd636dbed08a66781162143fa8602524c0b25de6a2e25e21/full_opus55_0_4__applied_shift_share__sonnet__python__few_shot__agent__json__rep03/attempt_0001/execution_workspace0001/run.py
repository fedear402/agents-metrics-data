import json
import numpy as np
import pandas as pd

df = pd.read_csv('input.csv')
S = df.pivot(index='region_id', columns='industry_id', values='share').fillna(0.0)
reg = df.groupby('region_id')[['region_weight','x','y']].first().loc[S.index]
shock = df.groupby('industry_id')['shock'].first().loc[S.columns].to_numpy()
shares = S.to_numpy()
e = reg['region_weight'].to_numpy(); e = e/e.sum()
x = reg['x'].to_numpy(); y = reg['y'].to_numpy()
z = shares @ shock
regional = np.column_stack([y, x, z])
centered = regional - e @ regional
mass = e @ shares
agg = (shares.T @ (e[:, None]*centered))/mass[:, None]
assert np.allclose(mass @ agg, 0)
N = len(shock)

def shock_iv(dep, endog):
    X = np.column_stack([np.ones(N), endog]); Z = np.column_stack([np.ones(N), shock])
    cross = Z.T @ (mass[:, None]*X)
    b = np.linalg.solve(cross, Z.T @ (mass*dep))
    u = dep - X @ b
    sc = Z*(mass*u)[:, None]
    inv = np.linalg.inv(cross)
    V = N/(N-2)*inv @ (sc.T @ sc) @ inv.T
    return float(b[1]), float(np.sqrt(V[1, 1]))

b, se = shock_iv(agg[:, 0], agg[:, 1])
fs, fse = shock_iv(agg[:, 1], agg[:, 2])
c = centered
rb = np.sum(e*c[:,2]*c[:,0])/np.sum(e*c[:,2]*c[:,1])
rf = np.sum(e*c[:,2]*c[:,1])/np.sum(e*c[:,2]**2)
assert np.allclose([b, fs], [rb, rf])
assert np.allclose(shares.sum(1), 1)
print(len(e), N, b, se, fs, fse, 1/np.sum(mass**2))
out = {"task_id": "applied_shift_share", "platform": "python", "estimates": [
    {"term": "effect", "estimate": b, "se": se, "n_obs": N},
    {"term": "first_stage", "estimate": fs, "se": fse, "n_obs": N},
    {"term": "effective_shocks", "estimate": float(1/np.sum(mass**2)), "se": None, "n_obs": N}],
    "method_metadata": {"estimator": "weighted 2SLS; BHJ shock-level IV", "vcov": "shock-level HC1 N/(N-2), structural residuals"},
    "diagnostics": {"n_regions": int(len(e)), "regional_slope_check": float(rb), "regional_fs_check": float(rf)}}
json.dump(out, open('result.json', 'w'), indent=2, allow_nan=False)
