import json
import pandas as pd
import statsmodels.formula.api as smf
from statsmodels.stats.anova import anova_lm
from scipy import stats

df = pd.read_csv("input.csv").dropna(subset=["group", "y"])
n = len(df)
fit = smf.ols("y ~ C(group)", data=df).fit()
tab = anova_lm(fit, typ=1)
F = float(tab.loc["C(group)", "F"])
dfn = float(tab.loc["C(group)", "df"])
dfd = float(tab.loc["Residual", "df"])
p = float(tab.loc["C(group)", "PR(>F)"])
# independent check
Fs, ps = stats.f_oneway(*[g["y"].values for _, g in df.groupby("group")])
assert abs(Fs - F) < 1e-8 and abs(ps - p) < 1e-10
out = {"task_id": "anova_oneway", "platform": "python",
       "estimates": [{"term": t, "estimate": v, "se": None, "n_obs": n}
                     for t, v in [("F", F), ("df_num", dfn), ("df_den", dfd), ("p_value", p)]],
       "method_metadata": {"estimator": "one-way ANOVA (OLS, group as categorical)", "vcov": "classical"},
       "diagnostics": {}}
with open("result.json", "w") as f:
    json.dump(out, f)
print(out)
