import pandas as pd, numpy as np, json
cw=pd.read_csv("crosswalk.csv"); tr=pd.read_csv("trade.csv").merge(cw,on="code",how="inner")
ar=pd.read_csv("areas.csv"); em=pd.read_csv("employment.csv"); out=pd.read_csv("outcomes.csv")
inds=sorted(cw.industry.unique()); assert len(inds)==4
full=pd.MultiIndex.from_product([ar.area.unique(),ar.period.unique(),["base","early"],inds],names=["area","period","vintage","industry"])
em=em.set_index(["area","period","vintage","industry"]).employment.reindex(full,fill_value=0).reset_index()
em["nat"]=em.groupby(["period","vintage","industry"]).employment.transform("sum")
em=em.merge(ar[["area","period","vintage","total_employment"]],on=["area","period","vintage"]).merge(tr,on=["period","industry"])
def expo(v,ch):
    d=em[em.vintage==v]
    t=d.employment/d.total_employment*d[ch]/d.nat/(d.price_index/100)/1000*(10/d.years)
    return t.groupby([d.area,d.period]).sum().rename(v)
x=expo("base","us_change").rename("x"); z=expo("early","other_change").rename("z")
pop=ar[ar.vintage=="base"][["area","period","population"]]
df=out.merge(x.reset_index(),on=["area","period"]).merge(z.reset_index(),on=["area","period"]).merge(pop,on=["area","period"])
assert len(df)==72
y=df.change_pp.values; w=df.population.values
X=np.column_stack([np.ones(72),df.period,df.control,df.x]); Z=np.column_stack([np.ones(72),df.period,df.control,df.z])
sw=np.sqrt(w)[:,None]; Xw,Zw,yw=X*sw,Z*sw,y*sw[:,0]
Xh=Zw@np.linalg.lstsq(Zw,Xw,rcond=None)[0]; b=np.linalg.solve(Xh.T@Xw,Xh.T@yw)
# check: just-identified IV = (Z'WX)^-1 Z'Wy
b2=np.linalg.solve(Zw.T@Xw,Zw.T@yw); assert np.allclose(b,b2)
g=lambda s,a,p: float(s.loc[(a,p)])
est={"iv_slope":b[3],"exposure_area0_period0":g(x,0,0),"exposure_area0_period1":g(x,0,1),"instrument_area0_period0":g(z,0,0)}
print(est, b2[3])
json.dump({"task_id":"applied_multivintage_trade_iv","platform":"python",
 "estimates":[{"term":k,"estimate":float(v),"se":None,"n_obs":72} for k,v in est.items()],
 "method_metadata":{"estimator":"weighted 2SLS","weights":"base population","instruments":["const","period","control","z"]},
 "diagnostics":{"n_obs":72,"first_stage_corr_xz":float(np.corrcoef(df.x,df.z)[0,1])}},open("result.json","w"),indent=1)
