import json
import pandas as pd
import statsmodels.formula.api as smf
import statsmodels.api as sm
from scipy import stats

d = pd.read_csv("input.csv").dropna(subset=["group", "y"])
n = len(d)
m = smf.ols("y ~ C(group)", data=d).fit()
t = sm.stats.anova_lm(m, typ=1)
F = float(t.loc["C(group)", "F"]); dfn = float(t.loc["C(group)", "df"])
dfd = float(t.loc["Residual", "df"]); p = float(t.loc["C(group)", "PR(>F)"])

# independent check
F2, p2 = stats.f_oneway(*[g.values for _, g in d.groupby("group")["y"]])
assert abs(F - F2) < 1e-8 and abs(p - p2) < 1e-10

res = {"task_id": "anova_oneway", "platform": "python",
       "estimates": [{"term": k, "estimate": v, "se": None, "n_obs": n}
                     for k, v in [("F", F), ("df_num", dfn), ("df_den", dfd), ("p_value", p)]],
       "method_metadata": {"estimator": "one-way ANOVA (OLS y ~ C(group), Type I SS)", "vcov": "classical homoskedastic"},
       "diagnostics": {"scipy_f_oneway_F": float(F2), "scipy_p": float(p2), "n_groups": int(d.group.nunique())}}
json.dump(res, open("result.json", "w"), indent=2)
print(res)
