import json, numpy as np, pandas as pd
from linearmodels.iv import IV2SLS
cw=pd.read_csv('crosswalk.csv',dtype={'code':str}); assert pd.read_csv('input.csv').equals(pd.read_csv('crosswalk.csv'))
tr=pd.read_csv('trade.csv',dtype={'code':str}).merge(cw,on='code',validate='1:1')
ar=pd.read_csv('areas.csv'); em=pd.read_csv('employment.csv'); out=pd.read_csv('outcomes.csv')
def expo(vint,col):
    a=ar[ar.vintage==vint][['area','period','total_employment']]
    grid=a[['area','period']].merge(pd.DataFrame({'industry':range(4)}),how='cross')
    e=grid.merge(em[em.vintage==vint][['area','period','industry','employment']],how='left',on=['area','period','industry']).fillna({'employment':0})
    e['nat']=e.groupby(['period','industry']).employment.transform('sum')
    e=e.merge(tr[['period','industry',col,'price_index','years']],on=['period','industry'],validate='m:1')
    e=e.merge(a,on=['area','period'])
    e['v']=e.employment/e.total_employment*e[col]/e.nat/(e.price_index/100)/1000*(10/e.years)
    return e.groupby(['area','period']).v.sum()
d=out.set_index(['area','period']).join(expo('base','us_change').rename('x')).join(expo('early','other_change').rename('z'))
d=d.join(ar[ar.vintage=='base'].set_index(['area','period']).population).reset_index()
assert len(d)==72 and d.notna().all().all()
d['const']=1.0
f=IV2SLS(d.change_pp,d[['const','period','control']],d[['x']],d[['z']],weights=d.population).fit()
g=lambda c,p:float(d.loc[(d.area==0)&(d.period==p),c].iloc[0])
est={'iv_slope':float(f.params['x']),'exposure_area0_period0':g('x',0),'exposure_area0_period1':g('x',1),'instrument_area0_period0':g('z',0)}
print(est)
json.dump({'task_id':'applied_multivintage_trade_iv','platform':'python',
 'estimates':[{'term':k,'estimate':v,'se':None,'n_obs':72} for k,v in est.items()],
 'method_metadata':{'estimator':'weighted 2SLS (linearmodels IV2SLS)','weights':'base population','exog':['const','period','control'],'instrument':'z'},
 'diagnostics':{'n_obs':72,'first_stage_corr_xz':float(d.x.corr(d.z))}},open('result.json','w'),indent=2)
# check: manual weighted 2SLS
W=np.sqrt(d.population.values)[:,None]; X=d[['const','period','control','x']].values*W; Z=d[['const','period','control','z']].values*W; y=d.change_pp.values*W[:,0]
b=np.linalg.solve(Z.T@X,Z.T@y); print('manual',b[-1])
