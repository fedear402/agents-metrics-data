import pandas as pd, numpy as np, json
import statsmodels.api as sm
d=pd.read_csv("input.csv").dropna(subset=["score","participated","earnings"])
d=d[d.score.abs()<1].copy()
w=1-d.score.abs().values; D=(d.score>=0).astype(float).values; x=d.score.values
X=np.column_stack([np.ones(len(d)),D,x,D*x]); n=len(d)
Y=np.column_stack([d.earnings.values,d.participated.values])
XtWX_inv=np.linalg.inv(X.T@(X*w[:,None]))
B=XtWX_inv@(X.T@(Y*w[:,None])); E=Y-X@B
# joint sandwich: influence of coef 1 for each eq
IF=(X*w[:,None])@XtWX_inv[:,1]  # n
S=IF[:,None]*E
V=S.T@S
rf,fs=B[1]; te=rf/fs
g=np.array([1/fs,-rf/fs**2]); se_te=float(np.sqrt(g@V@g))
# check with statsmodels
for k,yv in enumerate(["earnings","participated"]):
    m=sm.WLS(Y[:,k],X,weights=w).fit(cov_type="HC0")
    assert abs(m.params[1]-B[1,k])<1e-9 and abs(m.bse[1]-np.sqrt(V[k,k]))<1e-9
# IV check: weighted 2SLS should equal ratio
Z=X; Xe=np.column_stack([np.ones(n),Y[:,1],x,D*x]); W=np.diag(w)
biv=np.linalg.solve(Z.T@W@Xe,Z.T@W@Y[:,0]); u=Y[:,0]-Xe@biv
A=np.linalg.inv(Z.T@W@Xe); M=(Z*(w*u)[:,None]); Viv=A@(M.T@M)@A.T
print(n,rf,fs,te,se_te,biv[1],np.sqrt(Viv[1,1]))
r=lambda t,e,s:{"term":t,"estimate":float(e),"se":float(s),"n_obs":int(n)}
json.dump({"task_id":"applied_fuzzy_rd","platform":"python","estimates":[r("treatment_effect",te,se_te),r("reduced_form",rf,np.sqrt(V[0,0])),r("first_stage",fs,np.sqrt(V[1,1]))],
"method_metadata":{"estimator":"fuzzy RD, local linear, triangular kernel, h=1, ratio of WLS discontinuities","vcov":"HC0 joint sandwich, delta method"},"diagnostics":{"iv_check_estimate":float(biv[1]),"iv_check_se":float(np.sqrt(Viv[1,1]))}},open("result.json","w"),indent=1)
