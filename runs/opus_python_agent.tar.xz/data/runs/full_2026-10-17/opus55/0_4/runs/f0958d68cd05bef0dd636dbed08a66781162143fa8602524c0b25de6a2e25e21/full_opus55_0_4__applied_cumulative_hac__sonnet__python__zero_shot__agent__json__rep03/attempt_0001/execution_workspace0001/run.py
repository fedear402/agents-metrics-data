import pandas as pd, numpy as np, json
import statsmodels.api as sm
df=pd.read_csv("input.csv",parse_dates=["date"]).sort_values("date").reset_index(drop=True)
d=np.log(df.vix).diff()
X=pd.concat({f"lag_{k}":d.shift(k) for k in range(1,16)},axis=1)
y=np.log(df.sales)
m=X.notna().all(1)
Xc=sm.add_constant(X[m]); yc=y[m]
N=len(yc)
r=sm.OLS(yc,Xc).fit(cov_type="HAC",cov_kwds={"maxlags":15,"use_correction":False})
V=r.cov_params().values*N/(N-16)
# independent manual HAC
Xa=Xc.values; e=r.resid.values; u=Xa*e[:,None]
S=u.T@u
for j in range(1,16):
    G=u[j:].T@u[:-j]; S+=(1-j/16)*(G+G.T)
B=np.linalg.inv(Xa.T@Xa); V2=B@S@B*N/(N-16)
assert np.allclose(V,V2)
w=np.r_[0,np.ones(15)]
cr=float(w@r.params.values); se=float(np.sqrt(w@V@w))
sd=np.sqrt(np.diag(V))
est=[{"term":"cumulative_response","estimate":cr,"se":se,"n_obs":N},
 {"term":"lag_1","estimate":float(r.params["lag_1"]),"se":float(sd[1]),"n_obs":N},
 {"term":"lag_15","estimate":float(r.params["lag_15"]),"se":float(sd[15]),"n_obs":N}]
json.dump({"task_id":"applied_cumulative_hac","platform":"python","estimates":est,
 "method_metadata":{"estimator":"OLS distributed lag","vcov":"Newey-West Bartlett L=15, scaled N/(N-16)"},
 "diagnostics":{"n_raw":len(df),"max_abs_diff_manual_vcov":float(np.abs(V-V2).max())}},open("result.json","w"),indent=1)
print(len(df),N,est)
