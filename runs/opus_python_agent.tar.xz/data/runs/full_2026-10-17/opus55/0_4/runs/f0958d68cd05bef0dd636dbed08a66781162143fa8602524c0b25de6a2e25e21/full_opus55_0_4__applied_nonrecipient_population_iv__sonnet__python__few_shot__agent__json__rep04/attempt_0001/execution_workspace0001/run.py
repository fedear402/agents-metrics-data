import json, numpy as np, pandas as pd
from linearmodels.iv import IV2SLS
h = pd.read_csv('households.csv'); c = pd.read_csv('census.csv')
d = h[h.recipient == 0].copy()
e = d.eligible; ne = 1 - e
X = pd.DataFrame({'ine': ne, 'elig': e, 'base_ine': d.baseline*ne, 'base_elig': d.baseline*e})
D = pd.DataFrame({'dose_ine': d.dose*ne, 'dose_elig': d.dose*e})
Z = pd.DataFrame({'z_ine': d.instrument*ne, 'z_elig': d.instrument*e})
fit = IV2SLS(d.outcome, X, D, Z, weights=d.weight).fit()
# independent check: manual weighted 2SLS
W = d.weight.values; Xa = np.column_stack([X, D]); Za = np.column_stack([X, Z])
sw = np.sqrt(W)[:, None]; Zw, Xw, yw = Za*sw, Xa*sw, d.outcome.values*sw[:, 0]
P = Zw @ np.linalg.lstsq(Zw, Xw, rcond=None)[0]
b = np.linalg.solve(P.T @ Xw, P.T @ yw)
assert np.allclose(b[-2:], fit.params[['dose_ine', 'dose_elig']].values)
eff = {}
for g, name in [(0, 'dose_ine'), (1, 'dose_elig')]:
    s = d[d.eligible == g]
    eff[g] = float(fit.params[name] * np.average(s.dose, weights=s.weight))
pop = c.set_index('eligible').nonrecipient_population
pe = float((eff[0]*pop[0] + eff[1]*pop[1]) / (pop[0] + pop[1]))
n = int(len(d))
est = [{'term': t, 'estimate': v, 'se': None, 'n_obs': n} for t, v in
       [('ineligible_effect', eff[0]), ('eligible_nonrecipient_effect', eff[1]), ('population_effect', pe)]]
res = {'task_id': 'applied_nonrecipient_population_iv', 'platform': 'python', 'estimates': est,
       'method_metadata': {'estimator': 'weighted 2SLS (linearmodels IV2SLS), group-interacted, no common intercept',
                           'census_weights': {str(k): int(v) for k, v in pop.items()}},
       'diagnostics': {'slopes': {k: float(fit.params[k]) for k in ['dose_ine', 'dose_elig']},
                       'n_by_group': {str(k): int(v) for k, v in d.eligible.value_counts().items()},
                       'manual_2sls_match': True}}
json.dump(res, open('result.json', 'w'), indent=2); print(json.dumps(res, indent=2))
