import json
import numpy as np
import pandas as pd
from scipy import stats

df = pd.read_csv("input.csv").dropna(subset=["group", "y"])
groups = [g["y"].to_numpy() for _, g in df.groupby("group")]
n, k = len(df), len(groups)
F, p = stats.f_oneway(*groups)
df_num, df_den = k - 1, n - k

# independent check: manual sums of squares
gm = df["y"].mean()
ssb = sum(len(g) * (g.mean() - gm) ** 2 for g in groups)
ssw = sum(((g - g.mean()) ** 2).sum() for g in groups)
F2 = (ssb / df_num) / (ssw / df_den)
p2 = stats.f.sf(F2, df_num, df_den)
assert np.isclose(F, F2) and np.isclose(p, p2)
print(F, F2, p, p2, n, k)

rows = [("F", F), ("df_num", df_num), ("df_den", df_den), ("p_value", p)]
out = {"task_id": "anova_oneway", "platform": "python",
       "estimates": [{"term": t, "estimate": float(v), "se": None, "n_obs": int(n)} for t, v in rows],
       "method_metadata": {"estimator": "one-way ANOVA (scipy f_oneway)", "vcov": "classical homoskedastic"},
       "diagnostics": {"n_groups": k}}
with open("result.json", "w") as f:
    json.dump(out, f)
