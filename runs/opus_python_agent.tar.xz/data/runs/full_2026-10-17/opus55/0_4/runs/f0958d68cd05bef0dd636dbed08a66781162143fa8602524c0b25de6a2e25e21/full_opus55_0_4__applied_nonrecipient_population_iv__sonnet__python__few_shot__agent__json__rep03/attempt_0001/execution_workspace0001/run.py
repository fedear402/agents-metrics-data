import json, numpy as np, pandas as pd
from linearmodels.iv import IV2SLS
h=pd.read_csv('households.csv'); c=pd.read_csv('census.csv')
d=h[h.recipient==0].reset_index(drop=True); n=len(d)
e=d.eligible; ne=1-e
X=pd.DataFrame({'c0':ne,'c1':e,'b0':d.baseline*ne,'b1':d.baseline*e})
D=pd.DataFrame({'d0':d.dose*ne,'d1':d.dose*e})
Z=pd.DataFrame({'z0':d.instrument*ne,'z1':d.instrument*e})
fit=IV2SLS(d.outcome,X,D,Z,weights=d.weight).fit()
eff={}
for g,k in [(0,'d0'),(1,'d1')]:
    s=d[d.eligible==g]; eff[g]=float(fit.params[k]*np.average(s.dose,weights=s.weight))
# manual check: weighted 2SLS via sqrt-weight transform
w=np.sqrt(d.weight.values)[:,None]
Xf=np.column_stack([X,D])*w; Zf=np.column_stack([X,Z])*w; y=d.outcome.values*w[:,0]
P=Zf@np.linalg.pinv(Zf); b=np.linalg.solve(Xf.T@P@Xf,Xf.T@P@y)
assert np.allclose(b[4:],fit.params[['d0','d1']].values)
pop=c.set_index('eligible').nonrecipient_population
pe=(eff[0]*pop[0]+eff[1]*pop[1])/(pop[0]+pop[1])
est=[{'term':t,'estimate':v,'se':None,'n_obs':int(n)} for t,v in
     [('ineligible_effect',eff[0]),('eligible_nonrecipient_effect',eff[1]),('population_effect',float(pe))]]
json.dump({'task_id':'applied_nonrecipient_population_iv','platform':'python','estimates':est,
 'method_metadata':{'estimator':'weighted 2SLS, linearmodels IV2SLS, group-interacted, no common intercept'},
 'diagnostics':{'n_ineligible':int((e==0).sum()),'n_eligible':int((e==1).sum()),
  'slopes':{k:float(fit.params[k]) for k in ['d0','d1']},'manual_2sls_match':True}},open('result.json','w'),indent=2)
print(json.dumps(est,indent=1),fit.params.to_dict())
