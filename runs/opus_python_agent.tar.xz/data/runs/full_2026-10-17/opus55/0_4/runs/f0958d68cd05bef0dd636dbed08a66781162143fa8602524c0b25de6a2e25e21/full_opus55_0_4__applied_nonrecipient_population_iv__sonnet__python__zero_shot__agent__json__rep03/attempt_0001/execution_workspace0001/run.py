import json, numpy as np, pandas as pd
h=pd.read_csv("households.csv"); c=pd.read_csv("census.csv")
d=h[h.recipient==0].copy(); n=len(d)
e=d.eligible.values.astype(float); ie=1-e
X=np.column_stack([d.dose*ie,d.dose*e,ie,e,d.baseline*ie,d.baseline*e])
Z=np.column_stack([ie,e,d.baseline*ie,d.baseline*e,d.instrument*ie,d.instrument*e])
w=d.weight.values; y=d.outcome.values
Zw=Z*w[:,None]
P=np.linalg.solve(Z.T@Zw,Zw.T@X); Xh=Z@P
b=np.linalg.solve(Xh.T@(Xh*w[:,None]),(Xh*w[:,None]).T@y)
m0=np.average(d.dose[e==0],weights=w[e==0]); m1=np.average(d.dose[e==1],weights=w[e==1])
e0=b[0]*m0; e1=b[1]*m1
p=c.set_index("eligible").nonrecipient_population
pe=(p[0]*e0+p[1]*e1)/(p[0]+p[1])
# check: just-identified IV = (Z'WX)^-1 Z'Wy
b2=np.linalg.solve(Zw.T@X,Zw.T@y)
est=[dict(term=t,estimate=float(v),se=None,n_obs=int(n)) for t,v in
 [("ineligible_effect",e0),("eligible_nonrecipient_effect",e1),("population_effect",pe)]]
json.dump(dict(task_id="applied_nonrecipient_population_iv",platform="python",estimates=est,
 method_metadata=dict(estimator="weighted 2SLS, group-interacted, no extra intercept",weights="weight",counterfactual="dose=0"),
 diagnostics=dict(n_ineligible=int((e==0).sum()),n_eligible=int((e==1).sum()),slopes=b[:2].tolist(),
  mean_dose=[m0,m1],max_abs_diff_justid_check=float(abs(b-b2).max()))),open("result.json","w"),indent=1)
print(json.dumps(json.load(open("result.json")),indent=1))
