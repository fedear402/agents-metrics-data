import json, pandas as pd, numpy as np
import statsmodels.formula.api as smf, statsmodels.api as sm
from scipy import stats
d = pd.read_csv("input.csv").dropna(subset=["group", "y"])
n = len(d)
m = smf.ols("y ~ C(group)", data=d).fit()
a = sm.stats.anova_lm(m, typ=1)
F, p = float(a.loc["C(group)", "F"]), float(a.loc["C(group)", "PR(>F)"])
dfn, dfd = float(a.loc["C(group)", "df"]), float(a.loc["Residual", "df"])
# independent check
Fs, ps = stats.f_oneway(*[g.y.values for _, g in d.groupby("group")])
assert np.isclose(F, Fs) and np.isclose(p, ps)
est = [{"term": t, "estimate": v, "se": None, "n_obs": n}
       for t, v in [("F", F), ("df_num", dfn), ("df_den", dfd), ("p_value", p)]]
json.dump({"task_id": "anova_oneway", "platform": "python", "estimates": est,
           "method_metadata": {"estimator": "one-way ANOVA (OLS y ~ C(group), type I SS)", "vcov": "classical homoskedastic"},
           "diagnostics": {"scipy_f_oneway_F": float(Fs), "scipy_p": float(ps), "n_groups": int(d.group.nunique())}},
          open("result.json", "w"), indent=2)
print(json.dumps(est, indent=1))
