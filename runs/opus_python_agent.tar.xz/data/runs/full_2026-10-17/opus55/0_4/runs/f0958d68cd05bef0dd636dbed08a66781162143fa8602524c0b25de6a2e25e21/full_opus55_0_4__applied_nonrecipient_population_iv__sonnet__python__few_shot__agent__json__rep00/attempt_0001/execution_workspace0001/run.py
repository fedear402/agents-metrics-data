import json, numpy as np, pandas as pd
from linearmodels.iv import IV2SLS
h=pd.read_csv('households.csv'); c=pd.read_csv('census.csv')
d=h[h.recipient==0].copy(); n=len(d)
e=d.eligible; ne=1-e
X=pd.DataFrame({'ne':ne,'e':e,'b_ne':d.baseline*ne,'b_e':d.baseline*e})
D=pd.DataFrame({'d_ne':d.dose*ne,'d_e':d.dose*e})
Z=pd.DataFrame({'z_ne':d.instrument*ne,'z_e':d.instrument*e})
fit=IV2SLS(d.outcome,X,D,Z,weights=d.weight).fit()
# independent check: manual weighted 2SLS
W=d.weight.values; Xa=np.column_stack([X,D]); Za=np.column_stack([X,Z])
sw=np.sqrt(W)[:,None]; Xw,Zw,yw=Xa*sw,Za*sw,d.outcome.values*np.sqrt(W)
P=Zw@np.linalg.pinv(Zw.T@Zw)@Zw.T
bm=np.linalg.solve(Xw.T@P@Xw,Xw.T@P@yw)
assert np.allclose(bm[4:],fit.params[['d_ne','d_e']].values)
eff={}; cnt={}
for g,k in [(0,'d_ne'),(1,'d_e')]:
    s=d[d.eligible==g]; cnt[g]=len(s)
    eff[g]=float(fit.params[k]*np.average(s.dose,weights=s.weight))
pop=c.set_index('eligible').nonrecipient_population
pe=float((eff[0]*pop[0]+eff[1]*pop[1])/(pop[0]+pop[1]))
est=[{'term':t,'estimate':v,'se':None,'n_obs':int(n)} for t,v in
 [('ineligible_effect',eff[0]),('eligible_nonrecipient_effect',eff[1]),('population_effect',pe)]]
json.dump({'task_id':'applied_nonrecipient_population_iv','platform':'python','estimates':est,
 'method_metadata':{'estimator':'weighted 2SLS, linearmodels IV2SLS','counterfactual':'dose=0'},
 'diagnostics':{'n_ineligible':cnt[0],'n_eligible_nonrecipient':cnt[1],
  'slopes':{'ineligible':float(fit.params.d_ne),'eligible':float(fit.params.d_e)},
  'manual_2sls_match':True,'census_weights':{str(k):int(v) for k,v in pop.items()}}},
 open('result.json','w'),indent=2)
print(json.dumps(est,indent=1),cnt)
