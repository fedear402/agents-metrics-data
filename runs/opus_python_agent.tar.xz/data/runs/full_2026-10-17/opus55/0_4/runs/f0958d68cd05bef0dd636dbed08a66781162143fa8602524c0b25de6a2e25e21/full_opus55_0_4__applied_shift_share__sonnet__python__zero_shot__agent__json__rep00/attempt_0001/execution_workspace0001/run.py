import pandas as pd, numpy as np, json
d=pd.read_csv("input.csv")
reg=d.groupby("region_id")[["region_weight","x","y"]].first()
reg["e"]=reg.region_weight/reg.region_weight.sum()
d["z_part"]=d.share*d.shock
reg["z"]=d.groupby("region_id").z_part.sum()
e=reg.e.values
def wm(v): return np.sum(e*v)
for v in "xyz": reg[v+"0"]=reg[v]-wm(reg[v].values)
d=d.merge(reg[["e","x0","y0","z0"]],left_on="region_id",right_index=True)
d["w"]=d.e*d.share
g=d.groupby("industry_id")
s=g.w.sum()
ind=pd.DataFrame({"s":s,"shock":g.shock.first()})
for v in ["x0","y0","z0"]: ind[v[0]+"bar"]=(d.w*d[v]).groupby(d.industry_id).sum()/s
def wiv(y,x,z,w):
    X=np.column_stack([np.ones_like(x),x]);Z=np.column_stack([np.ones_like(z),z])
    W=w/w.sum()
    b=np.linalg.solve(Z.T@(W[:,None]*X),Z.T@(W*y))
    u=y-X@b;n=len(y)
    A=np.linalg.inv(Z.T@(W[:,None]*X))
    M=(Z*(W*u)[:,None]);V=A@(M.T@M)@A.T*n/(n-2)
    return b,np.sqrt(np.diag(V))
def regwiv(y,x,z):
    X=np.column_stack([np.ones_like(x),x]);Z=np.column_stack([np.ones_like(z),z])
    return np.linalg.solve(Z.T@(e[:,None]*X),Z.T@(e*y))[1]
N=len(ind)
b,se=wiv(ind.ybar.values,ind.xbar.values,ind.shock.values,ind.s.values)
bf,sef=wiv(ind.xbar.values,ind.zbar.values,ind.shock.values,ind.s.values)
breg=regwiv(reg.y.values,reg.x.values,reg.z.values)
bfreg=regwiv(reg.x.values,reg.z.values,reg.z.values)
print(b,breg,bf,bfreg,se,sef,N,len(reg),ind.s.sum())
# statsmodels check
from statsmodels.sandbox.regression.gmm import IV2SLS
import statsmodels.api as sm
ws=np.sqrt(ind.s.values)
m=IV2SLS(ind.ybar.values*ws,sm.add_constant(ind.xbar.values)*ws[:,None],sm.add_constant(ind.shock.values)*ws[:,None]).fit()
r=m.resid; Zs=sm.add_constant(ind.shock.values)*ws[:,None]; Xs=sm.add_constant(ind.xbar.values)*ws[:,None]
A=np.linalg.inv(Zs.T@Xs); V=A@((Zs*r[:,None]).T@(Zs*r[:,None]))@A.T*N/(N-2)
print("sm check",m.params[1],np.sqrt(V[1,1]))
eff=1/np.sum(ind.s.values**2)
out={"task_id":"applied_shift_share","platform":"python","estimates":[
{"term":"effect","estimate":float(b[1]),"se":float(se[1]),"n_obs":N},
{"term":"first_stage","estimate":float(bf[1]),"se":float(sef[1]),"n_obs":N},
{"term":"effective_shocks","estimate":float(eff),"se":None,"n_obs":N}],
"method_metadata":{"estimator":"weighted 2SLS shift-share, BHJ shock-level equivalence","vcov":"shock-level HC1 N/(N-2), analytic weights s_n"},
"diagnostics":{"regional_2sls_slope":float(breg),"regional_first_stage_slope":float(bfreg),"n_regions":len(reg),"sum_s":float(ind.s.sum())}}
json.dump(out,open("result.json","w"),indent=1)
