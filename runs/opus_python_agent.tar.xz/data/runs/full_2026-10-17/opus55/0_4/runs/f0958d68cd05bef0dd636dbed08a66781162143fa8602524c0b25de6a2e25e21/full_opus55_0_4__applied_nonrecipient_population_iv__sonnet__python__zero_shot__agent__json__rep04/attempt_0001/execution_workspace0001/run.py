import json, numpy as np, pandas as pd
h=pd.read_csv("households.csv"); c=pd.read_csv("census.csv")
d=h[h.recipient==0].dropna(subset=["eligible","instrument","dose","baseline","weight","outcome"]).copy()
e=d.eligible.values.astype(float); ne=1-e
X=np.column_stack([d.dose*ne,d.dose*e,ne,e,d.baseline*ne,d.baseline*e])
Z=np.column_stack([ne,e,d.baseline*ne,d.baseline*e,d.instrument*ne,d.instrument*e])
w=d.weight.values; y=d.outcome.values
ZW=Z*w[:,None]; P=np.linalg.solve(Z.T@ZW,ZW.T@X); Xh=Z@P
b=np.linalg.solve(Xh.T@(X*w[:,None]),Xh.T@(w*y))
# check: textbook formula
A=X.T@ZW; B=np.linalg.inv(Z.T@ZW); b2=np.linalg.solve(A@B@A.T,A@B@(ZW.T@y))
assert np.allclose(b,b2)
m0=np.average(d.dose[e==0],weights=w[e==0]); m1=np.average(d.dose[e==1],weights=w[e==1])
ie=b[0]*m0; ee=b[1]*m1
p=c.set_index("eligible").nonrecipient_population; pe=(p[0]*ie+p[1]*ee)/(p[0]+p[1])
n=int(len(d))
est=[{"term":t,"estimate":float(v),"se":None,"n_obs":n} for t,v in [("ineligible_effect",ie),("eligible_nonrecipient_effect",ee),("population_effect",pe)]]
json.dump({"task_id":"applied_nonrecipient_population_iv","platform":"python","estimates":est,
 "method_metadata":{"estimator":"weighted 2SLS, group-interacted, no extra intercept","counterfactual":"dose=0"},
 "diagnostics":{"n_ineligible":int((e==0).sum()),"n_eligible":int((e==1).sum()),"slopes":b[:2].tolist(),"mean_dose":[m0,m1],"formula_check":True}},open("result.json","w"),indent=1)
print(json.dumps(est,indent=1),b,m0,m1,len(h))
