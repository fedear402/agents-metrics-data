import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("input.csv", parse_dates=["date"]).sort_values("date").reset_index(drop=True)
df["dv"] = np.log(df["vix"]).diff()
names = [f"lag_{k}" for k in range(1, 16)]
for k in range(1, 16):
    df[f"lag_{k}"] = df["dv"].shift(k)
df["ly"] = np.log(df["sales"])
s = df.dropna(subset=["ly"] + names)
N = len(s)
X = np.column_stack([np.ones(N), s[names].to_numpy()])
y = s["ly"].to_numpy()
b = np.linalg.lstsq(X, y, rcond=None)[0]
e = y - X @ b
u = X * e[:, None]
L = 15
meat = u.T @ u
for j in range(1, L + 1):
    g = u[j:].T @ u[:-j]
    meat += (1 - j / (L + 1)) * (g + g.T)
bread = np.linalg.inv(X.T @ X)
p = X.shape[1]
V = N / (N - p) * bread @ meat @ bread
c = np.r_[0.0, np.ones(15)]

# independent check with statsmodels
m = sm.OLS(y, X).fit(cov_type="HAC", cov_kwds={"maxlags": L, "use_correction": False})
V2 = m.cov_params() * N / (N - p)
assert np.allclose(m.params, b) and np.allclose(V, V2)
print("N", N, "first date", s["date"].iloc[0], "check ok; sum se via sm", np.sqrt(c @ V2 @ c))

rows = [
    {"term": "cumulative_response", "estimate": float(c @ b), "se": float(np.sqrt(c @ V @ c)), "n_obs": N},
    {"term": "lag_1", "estimate": float(b[1]), "se": float(np.sqrt(V[1, 1])), "n_obs": N},
    {"term": "lag_15", "estimate": float(b[15]), "se": float(np.sqrt(V[15, 15])), "n_obs": N},
]
out = {"task_id": "applied_cumulative_hac", "platform": "python", "estimates": rows,
       "method_metadata": {"estimator": "OLS of log sales on intercept and 15 lags of dlog(vix)",
                           "vcov": "Newey-West Bartlett maxlag 15, scaled N/(N-16)"},
       "diagnostics": {}}
with open("result.json", "w") as f:
    json.dump(out, f, indent=2, allow_nan=False)
