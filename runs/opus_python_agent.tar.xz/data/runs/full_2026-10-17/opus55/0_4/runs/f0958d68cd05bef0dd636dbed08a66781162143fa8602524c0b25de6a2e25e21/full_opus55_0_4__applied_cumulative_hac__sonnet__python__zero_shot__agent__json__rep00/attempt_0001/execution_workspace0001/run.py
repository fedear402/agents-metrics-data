import pandas as pd, numpy as np, json
import statsmodels.api as sm
df=pd.read_csv("input.csv",parse_dates=["date"]).sort_values("date").reset_index(drop=True)
df["ly"]=np.log(df.sales); d=np.log(df.vix).diff()
L=15
for j in range(1,L+1): df[f"l{j}"]=d.shift(j)
cols=[f"l{j}" for j in range(1,L+1)]
s=df.dropna(subset=["ly"]+cols)
X=sm.add_constant(s[cols]); y=s.ly
m=sm.OLS(y,X).fit()
N=len(y); k=X.shape[1]
Xa=X.values; u=m.resid.values
S=(Xa*u[:,None]); Om=S.T@S
for j in range(1,L+1):
    G=S[j:].T@S[:-j]; Om+=(1-j/(L+1))*(G+G.T)
B=np.linalg.inv(Xa.T@Xa); V=B@Om@B*N/(N-k)
w=np.r_[0,np.ones(L)]
cum=float(w@m.params.values); se=float(np.sqrt(w@V@w))
# check vs statsmodels
V2=m.get_robustcov_results("HAC",maxlags=L,use_correction=False).cov_params()*N/(N-k)
assert np.allclose(V,V2)
se1=float(np.sqrt(V[1,1])); se15=float(np.sqrt(V[L,L]))
r={"task_id":"applied_cumulative_hac","platform":"python","estimates":[
 {"term":"cumulative_response","estimate":cum,"se":se,"n_obs":N},
 {"term":"lag_1","estimate":float(m.params["l1"]),"se":se1,"n_obs":N},
 {"term":"lag_15","estimate":float(m.params["l15"]),"se":se15,"n_obs":N}],
 "method_metadata":{"estimator":"OLS","vcov":"Newey-West HAC, Bartlett maxlag 15, scaled N/(N-16)"},"diagnostics":{"n_raw":len(df)}}
json.dump(r,open("result.json","w"),indent=1)
# independent check: sum of coefs via reparam: regress on l1 and differences
Z=s[cols].values.copy(); Zr=np.column_stack([np.ones(N),Z[:,0]]+[Z[:,j]-Z[:,0] for j in range(1,L)])
b=np.linalg.lstsq(Zr,y.values,rcond=None)[0]
print("reparam cum",b[1],"vs",cum)
print(r)
