import json
import numpy as np
import pandas as pd
from scipy import stats

df = pd.read_csv("input.csv").dropna(subset=["group", "y"])
groups = [g["y"].to_numpy() for _, g in df.groupby("group")]
n, k = len(df), len(groups)
F, p = stats.f_oneway(*groups)
# manual check
gm = df["y"].mean()
ssb = sum(len(g) * (g.mean() - gm) ** 2 for g in groups)
ssw = sum(((g - g.mean()) ** 2).sum() for g in groups)
F2 = (ssb / (k - 1)) / (ssw / (n - k))
assert abs(F - F2) < 1e-8 * max(1, F)
rows = {"F": F, "df_num": k - 1, "df_den": n - k, "p_value": p}
out = {"task_id": "anova_oneway", "platform": "python",
       "estimates": [{"term": t, "estimate": float(v), "se": None, "n_obs": int(n)} for t, v in rows.items()],
       "method_metadata": {"estimator": "one-way ANOVA (scipy f_oneway)", "vcov": "classical homoskedastic"},
       "diagnostics": {"F_manual": float(F2), "p_manual": float(stats.f.sf(F2, k - 1, n - k))}}
json.dump(out, open("result.json", "w"), indent=1)
