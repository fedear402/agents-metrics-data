import json
import pandas as pd
from statsmodels.tsa.arima.model import ARIMA
df = pd.read_csv("input.csv").sort_values("t")
y = df["y"].astype(float).values
fit = ARIMA(y, order=(1,1,1), trend="n").fit()
fc = fit.get_forecast(1)
m = float(fc.predicted_mean[0]); se = float(fc.se_mean[0])
ci = fc.conf_int(alpha=0.05)[0]
n = len(y)
out = {"task_id": "arima_forecast", "platform": "python",
 "estimates": [
  {"term": "forecast", "estimate": m, "se": se, "n_obs": n},
  {"term": "lower_95", "estimate": float(ci[0]), "se": None, "n_obs": n},
  {"term": "upper_95", "estimate": float(ci[1]), "se": None, "n_obs": n}],
 "method_metadata": {"estimator": "ARIMA(1,1,1) exact ML (state space, statsmodels), no constant", "vcov": "OPG"},
 "diagnostics": {"ar1": float(fit.params[0]), "ma1": float(fit.params[1]), "sigma2": float(fit.params[2]), "last_t": int(df.t.iloc[-1])}}
json.dump(out, open("result.json", "w"), indent=1)
# check: manual forecast from residuals
phi, th, s2 = fit.params
d = y[-1]-y[-2]
man = y[-1] + phi*d + th*fit.resid[-1]
print(man, m, m-1.959964*s2**0.5)
