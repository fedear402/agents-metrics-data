import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

d = pd.read_csv("input.csv", parse_dates=["date"]).sort_values("date").reset_index(drop=True)
d["dv"] = np.log(d["vix"]).diff()
L = 15
cols = []
for k in range(1, L + 1):
    d[f"l{k}"] = d["dv"].shift(k); cols.append(f"l{k}")
d["ly"] = np.log(d["sales"])
s = d.dropna(subset=["ly"] + cols)
N = len(s)
X = np.column_stack([np.ones(N), s[cols].to_numpy()])
y = s["ly"].to_numpy()
b = np.linalg.lstsq(X, y, rcond=None)[0]
e = y - X @ b
S = X * e[:, None]
meat = S.T @ S
for j in range(1, L + 1):
    G = S[j:].T @ S[:-j]
    meat += (1 - j / (L + 1)) * (G + G.T)
B = np.linalg.inv(X.T @ X)
p = X.shape[1]
V = N / (N - p) * B @ meat @ B
c = np.r_[0.0, np.ones(L)]
# independent check with statsmodels
r = sm.OLS(y, X).fit(cov_type="HAC", cov_kwds={"maxlags": L, "use_correction": False})
Vs = r.cov_params() * N / (N - p)
assert np.allclose(b, r.params) and np.allclose(V, Vs)
rows = [
    {"term": "cumulative_response", "estimate": float(c @ b), "se": float(np.sqrt(c @ V @ c)), "n_obs": N},
    {"term": "lag_1", "estimate": float(b[1]), "se": float(np.sqrt(V[1, 1])), "n_obs": N},
    {"term": "lag_15", "estimate": float(b[15]), "se": float(np.sqrt(V[15, 15])), "n_obs": N},
]
out = {"task_id": "applied_cumulative_hac", "platform": "python", "estimates": rows,
       "method_metadata": {"estimator": "OLS distributed lag (15 lags of dlog vix)",
                           "vcov": "Newey-West Bartlett maxlag 15, scaled N/(N-16)"},
       "diagnostics": {"n_rows_input": len(d), "sum_check_vs_statsmodels": "match"}}
json.dump(out, open("result.json", "w"), indent=2, allow_nan=False)
print(json.dumps(out, indent=1))
