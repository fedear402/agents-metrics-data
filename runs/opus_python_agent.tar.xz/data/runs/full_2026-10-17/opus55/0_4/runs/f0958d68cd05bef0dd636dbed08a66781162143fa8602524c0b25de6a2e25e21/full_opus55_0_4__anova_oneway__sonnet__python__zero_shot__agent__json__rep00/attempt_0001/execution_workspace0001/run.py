import json, pandas as pd, numpy as np
import statsmodels.formula.api as smf, statsmodels.api as sm
from scipy import stats
df = pd.read_csv("input.csv").dropna(subset=["group", "y"])
n = len(df)
m = smf.ols("y ~ C(group)", data=df).fit()
t = sm.stats.anova_lm(m, typ=1)
F, dfn, dfd, p = t.loc["C(group)", "F"], t.loc["C(group)", "df"], t.loc["Residual", "df"], t.loc["C(group)", "PR(>F)"]
# independent check
Fs, ps = stats.f_oneway(*[g["y"].values for _, g in df.groupby("group")])
assert np.isclose(F, Fs) and np.isclose(p, ps)
res = {"task_id": "anova_oneway", "platform": "python",
 "estimates": [{"term": k, "estimate": float(v), "se": None, "n_obs": n} for k, v in
               [("F", F), ("df_num", dfn), ("df_den", dfd), ("p_value", p)]],
 "method_metadata": {"estimator": "one-way ANOVA (OLS y ~ C(group), Type I SS)", "vcov": "classical homoskedastic"},
 "diagnostics": {"scipy_f_oneway_F": float(Fs), "scipy_p": float(ps), "k_groups": int(df.group.nunique())}}
json.dump(res, open("result.json", "w"), indent=2)
print(res)
