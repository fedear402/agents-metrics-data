import pandas as pd, numpy as np, json
cw=pd.read_csv('crosswalk.csv',dtype={'code':str}); tr=pd.read_csv('trade.csv',dtype={'code':str})
ar=pd.read_csv('areas.csv'); em=pd.read_csv('employment.csv'); out=pd.read_csv('outcomes.csv')
tr=tr.merge(cw,on='code',validate='m:1'); assert tr.industry.notna().all()
keys=ar[['area','period','vintage']]
full=keys.merge(pd.DataFrame({'industry':sorted(cw.industry.unique())}),how='cross')
em=full.merge(em,on=['area','period','vintage','industry'],how='left').fillna({'employment':0})
em['nat']=em.groupby(['period','vintage','industry']).employment.transform('sum')
em=em.merge(ar[['area','period','vintage','total_employment']],on=['area','period','vintage']).merge(tr,on=['period','industry'])
def expo(v,col):
    d=em[em.vintage==v]
    t=(d.employment/d.total_employment)*(d[col]/d.nat)/(d.price_index/100)/1000*(10/d.years)
    return d.assign(t=t).groupby(['area','period']).t.sum().rename('x' if v=='base' else 'z')
df=out.merge(expo('base','us_change').reset_index(),on=['area','period']).merge(expo('early','other_change').reset_index(),on=['area','period'])
df=df.merge(ar[ar.vintage=='base'][['area','period','population']],on=['area','period'])
assert len(df)==72
w=df.population.values; y=df.change_pp.values
X=np.column_stack([np.ones(72),df.period,df.control,df.x]); Z=np.column_stack([np.ones(72),df.period,df.control,df.z])
W=np.diag(w)
b=np.linalg.solve(Z.T@W@X,Z.T@W@y)
# check: two-stage
g=np.linalg.lstsq(np.sqrt(w)[:,None]*Z,np.sqrt(w)*df.x,rcond=None)[0]; Xh=X.copy(); Xh[:,3]=Z@g
b2=np.linalg.lstsq(np.sqrt(w)[:,None]*Xh,np.sqrt(w)*y,rcond=None)[0]
assert abs(b[3]-b2[3])<1e-8*max(1,abs(b[3]))
g0=lambda p,c: float(df[(df.area==0)&(df.period==p)][c].iloc[0])
est={'iv_slope':float(b[3]),'exposure_area0_period0':g0(0,'x'),'exposure_area0_period1':g0(1,'x'),'instrument_area0_period0':g0(0,'z')}
print(est,b2[3])
json.dump({'task_id':'applied_multivintage_trade_iv','platform':'python',
 'estimates':[{'term':k,'estimate':v,'se':None,'n_obs':72} for k,v in est.items()],
 'method_metadata':{'estimator':'weighted 2SLS (just-identified)','weights':'base population'},
 'diagnostics':{'two_stage_check_slope':float(b2[3]),'first_stage_z_coef':float(g[3])}},open('result.json','w'),indent=1)
