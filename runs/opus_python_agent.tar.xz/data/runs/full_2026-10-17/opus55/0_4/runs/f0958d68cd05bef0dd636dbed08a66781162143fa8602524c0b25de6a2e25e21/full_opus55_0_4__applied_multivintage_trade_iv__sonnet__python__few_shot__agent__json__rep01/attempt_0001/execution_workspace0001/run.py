import json, numpy as np, pandas as pd
from linearmodels.iv import IV2SLS
cw=pd.read_csv('crosswalk.csv'); assert cw.equals(pd.read_csv('input.csv'))
tr=pd.read_csv('trade.csv').merge(cw,on='code',validate='1:1')
ar=pd.read_csv('areas.csv'); em=pd.read_csv('employment.csv'); out=pd.read_csv('outcomes.csv')
full=ar[['area','period','vintage']].merge(pd.DataFrame({'industry':range(4)}),how='cross')
em=full.merge(em,how='left',on=['area','period','vintage','industry']).fillna({'employment':0})
em['nat']=em.groupby(['period','vintage','industry']).employment.transform('sum')
em=em.merge(ar,on=['area','period','vintage']).merge(tr,on=['period','industry'])
def expo(v,chg):
    d=em[em.vintage==v].copy()
    d['t']=d.employment/d.total_employment*d[chg]/d.nat/(d.price_index/100)/1000*(10/d.years)
    return d.groupby(['area','period']).t.sum().rename(chg)
X=pd.concat([expo('base','us_change').rename('x'),expo('early','other_change').rename('z')],axis=1).reset_index()
pop=ar[ar.vintage=='base'][['area','period','population']]
df=out.merge(X,on=['area','period'],validate='1:1').merge(pop,on=['area','period'],validate='1:1')
assert len(df)==72
df['const']=1.0
fit=IV2SLS(df.change_pp,df[['const','period','control']],df[['x']],df[['z']],weights=df.population).fit()
# manual check
W=np.sqrt(df.population.values)[:,None]
Xm=df[['const','period','control','x']].values*W; Zm=df[['const','period','control','z']].values*W; y=df.change_pp.values*W[:,0]
Ph=Zm@np.linalg.lstsq(Zm,Xm,rcond=None)[0]; b=np.linalg.lstsq(Ph,y,rcond=None)[0]
assert abs(b[-1]-fit.params['x'])<1e-8
g=lambda c,a,p: float(df.loc[(df.area==a)&(df.period==p),c].iloc[0])
est={'iv_slope':float(fit.params['x']),'exposure_area0_period0':g('x',0,0),
 'exposure_area0_period1':g('x',0,1),'instrument_area0_period0':g('z',0,0)}
print(est, b[-1])
json.dump({'task_id':'applied_multivintage_trade_iv','platform':'python',
 'estimates':[{'term':k,'estimate':v,'se':None,'n_obs':72} for k,v in est.items()],
 'method_metadata':{'estimator':'weighted 2SLS (linearmodels IV2SLS)','weights':'base population','instruments':['const','period','control','z']},
 'diagnostics':{'manual_2sls_slope':float(b[-1]),'n_obs':72}},open('result.json','w'),indent=2)
