import pandas as pd, numpy as np, json, statsmodels.api as sm
d=pd.read_csv("input.csv",parse_dates=["date"]).sort_values("date").reset_index(drop=True)
d["dv"]=np.log(d.vix).diff()
X=pd.concat({f"lag_{k}":d.dv.shift(k) for k in range(1,16)},axis=1)
X=sm.add_constant(X); y=np.log(d.sales)
m=X.notna().all(1)&y.notna(); X=X[m]; y=y[m]; N=len(y)
r=sm.OLS(y,X).fit()
# manual HAC
Xa=X.values; u=r.resid.values; S=(Xa*u[:,None]); Om=S.T@S
for j in range(1,16):
    G=S[j:].T@S[:-j]; Om+=(1-j/16)*(G+G.T)
B=np.linalg.inv(Xa.T@Xa); V=B@Om@B*N/(N-16)
Vs=r.get_robustcov_results("HAC",maxlags=15,use_correction=False).cov_params()*N/(N-16)
assert np.allclose(V,Vs)
w=np.r_[0,np.ones(15)]; b=r.params.values
cs=float(np.sqrt(w@V@w)); se=np.sqrt(np.diag(V))
out={"task_id":"applied_cumulative_hac","platform":"python","estimates":[
{"term":"cumulative_response","estimate":float(w@b),"se":cs,"n_obs":N},
{"term":"lag_1","estimate":float(b[1]),"se":float(se[1]),"n_obs":N},
{"term":"lag_15","estimate":float(b[15]),"se":float(se[15]),"n_obs":N}],
"method_metadata":{"estimator":"OLS","vcov":"Newey-West Bartlett maxlag 15, scaled N/(N-16)"},"diagnostics":{"n_raw":len(d)}}
json.dump(out,open("result.json","w"),indent=1)
# check: sum via reparam t-test
print(r.t_test(w).effect, w@b, len(d), N)
