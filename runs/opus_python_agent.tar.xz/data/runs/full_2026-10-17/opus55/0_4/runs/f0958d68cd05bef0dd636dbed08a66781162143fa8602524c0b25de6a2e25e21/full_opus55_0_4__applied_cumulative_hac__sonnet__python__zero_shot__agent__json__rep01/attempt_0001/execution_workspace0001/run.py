import pandas as pd, numpy as np, json
import statsmodels.api as sm
df=pd.read_csv("input.csv",parse_dates=["date"]).sort_values("date").reset_index(drop=True)
d=np.log(df.vix).diff()
X=pd.concat({f"lag_{k}":d.shift(k) for k in range(1,16)},axis=1)
y=np.log(df.sales)
m=pd.concat([y.rename("y"),X],axis=1).dropna()
Xc=sm.add_constant(m[X.columns]); N=len(m)
r=sm.OLS(m.y,Xc).fit(cov_type="HAC",cov_kwds={"maxlags":15,"use_correction":False})
V=r.cov_params().values*N/(N-16)
# manual check
e=r.resid.values[:,None]*Xc.values; S=e.T@e
for j in range(1,16):
    G=e[j:].T@e[:-j]; S+=(1-j/16)*(G+G.T)
B=np.linalg.inv(Xc.values.T@Xc.values); V2=B@S@B*N/(N-16)
assert np.allclose(V,V2)
w=np.r_[0,np.ones(15)]
cr=float(w@r.params.values); se=float(np.sqrt(w@V@w))
sd=np.sqrt(np.diag(V))
out={"task_id":"applied_cumulative_hac","platform":"python","estimates":[
{"term":"cumulative_response","estimate":cr,"se":se,"n_obs":N},
{"term":"lag_1","estimate":float(r.params["lag_1"]),"se":float(sd[1]),"n_obs":N},
{"term":"lag_15","estimate":float(r.params["lag_15"]),"se":float(sd[15]),"n_obs":N}],
"method_metadata":{"estimator":"OLS distributed lag","vcov":"Newey-West Bartlett L=15, scaled N/(N-16)"},"diagnostics":{"n_raw":len(df)}}
json.dump(out,open("result.json","w"),indent=1)
print(out)
