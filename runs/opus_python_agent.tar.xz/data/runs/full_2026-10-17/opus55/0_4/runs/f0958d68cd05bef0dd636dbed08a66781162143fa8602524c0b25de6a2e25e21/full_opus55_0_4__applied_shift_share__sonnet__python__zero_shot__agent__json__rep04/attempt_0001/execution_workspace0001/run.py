import pandas as pd, numpy as np, json
d=pd.read_csv("input.csv")
R=d.groupby("region_id")[["region_weight","x","y"]].first()
R["e"]=R.region_weight/R.region_weight.sum()
d["z_part"]=d.share*d.shock
R["z"]=d.groupby("region_id").z_part.sum()
e=R.e.values
def wiv(y,x,z,w):
    X=np.column_stack([np.ones_like(x),x]);Z=np.column_stack([np.ones_like(z),z])
    b=np.linalg.solve(Z.T@(w[:,None]*X),Z.T@(w*y));return b,X,Z
for v in ["x","y","z"]: R[v+"0"]=R[v]-np.sum(e*R[v])
d=d.merge(R[["e","x0","y0","z0"]],left_on="region_id",right_index=True)
d["w"]=d.e*d.share
g=d.groupby("industry_id")
s=g.w.sum()
S=pd.DataFrame({"s":s,"shock":g.shock.first()})
for v in ["x0","y0","z0"]: S[v]=(d.w*d[v]).groupby(d.industry_id).sum()/s
N=len(S)
def hc1(y,x,z,w):
    b,X,Z=wiv(y,x,z,w);u=y-X@b
    A=np.linalg.inv(Z.T@(w[:,None]*X))
    M=(Z*(w*u)[:,None]);V=A@(M.T@M)@A.T*N/(N-2);return b[1],np.sqrt(V[1,1])
sv=S.s.values;sh=S.shock.values
be,se_e=hc1(S.y0.values,S.x0.values,sh,sv)
bf,se_f=hc1(S.x0.values,S.z0.values,sh,sv)
br=wiv(R.y.values,R.x.values,R.z.values,e)[0][1]
bfr=wiv(R.x.values,R.z.values,R.z.values,e)[0][1]
print(be,br,bf,bfr,se_e,se_f,N,len(R))
eff=1/np.sum(sv**2)
json.dump({"task_id":"applied_shift_share","platform":"python","estimates":[
{"term":"effect","estimate":float(br),"se":float(se_e),"n_obs":N},
{"term":"first_stage","estimate":float(bfr),"se":float(se_f),"n_obs":N},
{"term":"effective_shocks","estimate":float(eff),"se":None,"n_obs":N}],
"method_metadata":{"estimator":"weighted 2SLS, shift-share IV","vcov":"BHJ shock-level HC1 N/(N-2)"},
"diagnostics":{"shock_level_slope":float(be),"shock_level_fs":float(bf),"n_regions":len(R),"sum_s":float(sv.sum())}},open("result.json","w"),indent=1)
