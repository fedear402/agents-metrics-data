import json
import numpy as np
import pandas as pd

df = pd.read_csv('input.csv')
S = df.pivot(index='region_id', columns='industry_id', values='share').fillna(0.0)
reg = df.groupby('region_id')[['region_weight','x','y']].first().loc[S.index]
shock = df.groupby('industry_id')['shock'].first().loc[S.columns].to_numpy()
shares = S.to_numpy()
e = reg['region_weight'].to_numpy(); e = e/e.sum()
x = reg['x'].to_numpy(); y = reg['y'].to_numpy()
z = shares @ shock
R = np.column_stack([y, x, z])
C = R - e @ R
s = e @ shares
agg = (shares.T @ (e[:,None]*C)) / s[:,None]
N = len(shock)

def shock_iv(dep, endo):
    X = np.column_stack([np.ones(N), endo]); Z = np.column_stack([np.ones(N), shock])
    A = Z.T @ (s[:,None]*X)
    b = np.linalg.solve(A, Z.T @ (s*dep))
    u = dep - X @ b
    sc = Z*(s*u)[:,None]
    Ai = np.linalg.inv(A)
    V = N/(N-2) * Ai @ (sc.T@sc) @ Ai.T
    return float(b[1]), float(np.sqrt(V[1,1]))

b, se = shock_iv(agg[:,0], agg[:,1])
fs, fse = shock_iv(agg[:,1], agg[:,2])
rb = np.sum(e*C[:,2]*C[:,0])/np.sum(e*C[:,2]*C[:,1])
rfs = np.sum(e*C[:,2]*C[:,1])/np.sum(e*C[:,2]**2)
assert np.allclose([b, fs], [rb, rfs])
assert np.allclose(shares.sum(1), 1)
out = {"task_id":"applied_shift_share","platform":"python","estimates":[
 {"term":"effect","estimate":b,"se":se,"n_obs":N},
 {"term":"first_stage","estimate":fs,"se":fse,"n_obs":N},
 {"term":"effective_shocks","estimate":float(1/np.sum(s**2)),"se":None,"n_obs":N}],
 "method_metadata":{"estimator":"weighted 2SLS; BHJ shock-level IV","vcov":"shock-level HC1 N/(N-2), structural residuals"},
 "diagnostics":{"n_regions":int(len(e)),"regional_slope_check":rb,"regional_first_stage_check":rfs}}
json.dump(out, open('result.json','w'), indent=2, allow_nan=False)
print(json.dumps(out, indent=2))
