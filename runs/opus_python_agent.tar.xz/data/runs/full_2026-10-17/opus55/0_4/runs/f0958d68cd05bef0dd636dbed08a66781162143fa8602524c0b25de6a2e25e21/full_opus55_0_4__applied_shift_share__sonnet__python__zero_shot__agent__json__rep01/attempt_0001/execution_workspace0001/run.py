import pandas as pd, numpy as np, json
d=pd.read_csv('input.csv')
reg=d.groupby('region_id')[['region_weight','x','y']].first()
reg['e']=reg.region_weight/reg.region_weight.sum()
d['z_c']=d.share*d.shock
reg['z']=d.groupby('region_id').z_c.sum()
e=reg.e.values
def wiv(y,x,z,w):
    X=np.column_stack([np.ones_like(x),x]); Z=np.column_stack([np.ones_like(z),z])
    b=np.linalg.solve(Z.T@(w[:,None]*X),Z.T@(w*y))
    u=y-X@b; n=len(y)
    A=np.linalg.inv(Z.T@(w[:,None]*X))
    M=(Z*(w*u)[:,None]); V=A@(M.T@M)@A.T*n/(n-2)
    return b[1],np.sqrt(V[1,1])
b_reg,_=wiv(reg.y.values,reg.x.values,reg.z.values,e)
fs_reg,_=wiv(reg.x.values,reg.z.values,reg.z.values,e)
for v in['y','x','z']: reg[v+'0']=reg[v]-np.sum(e*reg[v])
m=d.merge(reg[['e','y0','x0','z0']],left_on='region_id',right_index=True)
m['w']=m.e*m.share
g=m.groupby('industry_id')
s=g.w.sum(); shock=g.shock.first()
bar={v:(m.w*m[v+'0']).groupby(m.industry_id).sum()/s for v in['y','x','z']}
N=len(s)
b,se=wiv(bar['y'].values,bar['x'].values,shock.values,s.values)
f,fse=wiv(bar['x'].values,bar['z'].values,shock.values,s.values)
eff=1/np.sum(s**2)
print(b_reg,b,fs_reg,f,se,fse,eff,N,len(reg),s.sum(),d.groupby('region_id').share.sum().agg(['min','max']).values)
json.dump({"task_id":"applied_shift_share","platform":"python","estimates":[
{"term":"effect","estimate":float(b),"se":float(se),"n_obs":N},
{"term":"first_stage","estimate":float(f),"se":float(fse),"n_obs":N},
{"term":"effective_shocks","estimate":float(eff),"se":None,"n_obs":N}],
"method_metadata":{"estimator":"weighted 2SLS, shift-share IV; BHJ shock-level equivalence","vcov":"shock-level HC1 (N/(N-2)), analytic weights s_n"},
"diagnostics":{"regional_2sls_slope":float(b_reg),"regional_first_stage_slope":float(fs_reg),"n_regions":len(reg)}},open('result.json','w'),indent=1)
