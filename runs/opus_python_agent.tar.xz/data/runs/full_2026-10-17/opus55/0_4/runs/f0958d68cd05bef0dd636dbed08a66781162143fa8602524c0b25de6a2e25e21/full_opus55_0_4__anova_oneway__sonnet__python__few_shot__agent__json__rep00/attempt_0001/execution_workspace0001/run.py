import json
import pandas as pd
import statsmodels.formula.api as smf
import statsmodels.api as sm

df = pd.read_csv("input.csv").dropna(subset=["group", "y"])
n = len(df)
fit = smf.ols("y ~ C(group)", data=df).fit()
tab = sm.stats.anova_lm(fit, typ=1)
F = float(tab.loc["C(group)", "F"]); p = float(tab.loc["C(group)", "PR(>F)"])
dfn = float(tab.loc["C(group)", "df"]); dfd = float(tab.loc["Residual", "df"])
rows = [("F", F), ("df_num", dfn), ("df_den", dfd), ("p_value", p)]
out = {"task_id": "anova_oneway", "platform": "python",
       "estimates": [{"term": t, "estimate": v, "se": None, "n_obs": n} for t, v in rows],
       "method_metadata": {"estimator": "one-way ANOVA (OLS on group dummies)", "vcov": "classical"},
       "diagnostics": {}}
with open("result.json", "w") as f:
    json.dump(out, f)
