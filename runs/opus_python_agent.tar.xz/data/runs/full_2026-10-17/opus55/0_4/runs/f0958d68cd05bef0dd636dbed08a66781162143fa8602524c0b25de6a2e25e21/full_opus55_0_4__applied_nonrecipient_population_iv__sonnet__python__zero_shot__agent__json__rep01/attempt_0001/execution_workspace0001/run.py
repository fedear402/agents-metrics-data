import pandas as pd, numpy as np, json
h=pd.read_csv("households.csv"); c=pd.read_csv("census.csv")
d=h[h.recipient==0].reset_index(drop=True)
e=d.eligible.values.astype(float); ne=1-e
X=np.column_stack([d.dose*ne,d.dose*e,ne,e,d.baseline*ne,d.baseline*e])
Z=np.column_stack([d.instrument*ne,d.instrument*e,ne,e,d.baseline*ne,d.baseline*e])
y=d.outcome.values; w=d.weight.values
Zw=Z*w[:,None]
P=np.linalg.solve(Z.T@Zw,Zw.T@X); Xh=Z@P
b=np.linalg.solve(Xh.T@(Xh*w[:,None]),Xh.T@(w*y))
# check: IV form (Z'WX)^-1 Z'Wy, exactly identified
b2=np.linalg.solve(Zw.T@X,Zw.T@y)
assert np.allclose(b,b2)
eff={}
for g,k in [(0,0),(1,1)]:
    m=d.eligible==g; md=np.average(d.dose[m],weights=d.weight[m]); eff[g]=b[k]*md
pop=dict(zip(c.eligible,c.nonrecipient_population))
pe=(eff[0]*pop[0]+eff[1]*pop[1])/(pop[0]+pop[1])
n=int(len(d))
res={"task_id":"applied_nonrecipient_population_iv","platform":"python",
"estimates":[{"term":t,"estimate":float(v),"se":None,"n_obs":n} for t,v in
 [("ineligible_effect",eff[0]),("eligible_nonrecipient_effect",eff[1]),("population_effect",pe)]],
"method_metadata":{"estimator":"weighted 2SLS, group-interacted, no common intercept","weights":"weight","aggregation":"census nonrecipient_population"},
"diagnostics":{"coefficients":b.tolist(),"n_ineligible":int((e==0).sum()),"n_eligible_nonrecipient":int((e==1).sum()),"iv_identity_check":bool(np.allclose(b,b2))}}
json.dump(res,open("result.json","w"),indent=1)
print(json.dumps(res,indent=1))
