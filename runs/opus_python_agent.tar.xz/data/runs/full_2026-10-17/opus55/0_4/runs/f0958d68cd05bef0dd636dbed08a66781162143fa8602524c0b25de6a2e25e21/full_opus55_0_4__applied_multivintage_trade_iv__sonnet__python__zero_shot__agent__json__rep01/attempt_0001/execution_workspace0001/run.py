import pandas as pd, numpy as np, json
cw=pd.read_csv('crosswalk.csv'); inp=pd.read_csv('input.csv')
assert inp.equals(cw)
tr=pd.read_csv('trade.csv').merge(cw,on='code',validate='m:1')
ar=pd.read_csv('areas.csv'); em=pd.read_csv('employment.csv'); out=pd.read_csv('outcomes.csv')
idx=pd.MultiIndex.from_product([ar.area.unique(),ar.period.unique(),['base','early'],range(4)],names=['area','period','vintage','industry'])
E=em.set_index(['area','period','vintage','industry']).employment.reindex(idx,fill_value=0).reset_index()
nat=E.groupby(['period','vintage','industry']).employment.sum().rename('nat').reset_index()
E=E.merge(nat).merge(ar[['area','period','vintage','total_employment']]).merge(tr[['period','industry','us_change','other_change','price_index','years']])
E['chg']=np.where(E.vintage=='base',E.us_change,E.other_change)
E['c']=E.employment/E.total_employment*E.chg/E.nat/(E.price_index/100)/1000*(10/E.years)
X=E.pivot_table(index=['area','period'],columns='vintage',values='c',aggfunc='sum').reset_index()
d=out.merge(X).merge(ar[ar.vintage=='base'][['area','period','population']])
n=len(d); assert n==72
one=np.ones(n)
Xm=np.column_stack([one,d.period,d.control,d.base]); Zm=np.column_stack([one,d.period,d.control,d.early])
w=d.population.values; y=d.change_pp.values
W=np.diag(w)
Pz=Zm@np.linalg.solve(Zm.T@W@Zm,Zm.T@W)
b=np.linalg.solve(Xm.T@W@Pz@Xm,Xm.T@W@Pz@y)
# check: just-identified IV formula
b2=np.linalg.solve(Zm.T@W@Xm,Zm.T@W@y)
g=lambda a,p,v:float(d[(d.area==a)&(d.period==p)][v].iloc[0])
est={'iv_slope':b[3],'exposure_area0_period0':g(0,0,'base'),'exposure_area0_period1':g(0,1,'base'),'instrument_area0_period0':g(0,0,'early')}
json.dump({'task_id':'applied_multivintage_trade_iv','platform':'python',
 'estimates':[{'term':k,'estimate':float(v),'se':None,'n_obs':n} for k,v in est.items()],
 'method_metadata':{'estimator':'weighted 2SLS','weights':'base population','instruments':'const, period, control, z'},
 'diagnostics':{'just_identified_check_slope':float(b2[3]),'n_obs':n}},open('result.json','w'),indent=1)
print(est,b2[3])
