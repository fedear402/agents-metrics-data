import json, pandas as pd
import statsmodels.formula.api as smf
from statsmodels.stats.anova import anova_lm
d = pd.read_csv("input.csv").dropna(subset=["group", "y"])
m = smf.ols("y ~ C(group)", data=d).fit()
a = anova_lm(m, typ=1)
n = int(m.nobs)
vals = {"F": a.loc["C(group)", "F"], "df_num": a.loc["C(group)", "df"],
        "df_den": a.loc["Residual", "df"], "p_value": a.loc["C(group)", "PR(>F)"]}
out = {"task_id": "anova_oneway", "platform": "python",
       "estimates": [{"term": k, "estimate": float(v), "se": None, "n_obs": n} for k, v in vals.items()],
       "method_metadata": {"estimator": "one-way ANOVA (OLS y ~ C(group), Type I SS)", "vcov": "classical (homoskedastic)"},
       "diagnostics": {"n_groups": int(d.group.nunique())}}
json.dump(out, open("result.json", "w"), indent=2)
