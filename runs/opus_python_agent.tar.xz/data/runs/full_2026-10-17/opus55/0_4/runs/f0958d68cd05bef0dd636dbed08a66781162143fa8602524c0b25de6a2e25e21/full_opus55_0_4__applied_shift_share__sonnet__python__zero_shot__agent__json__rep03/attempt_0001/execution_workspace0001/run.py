import pandas as pd, numpy as np, json
d=pd.read_csv("input.csv")
d=d.dropna()
reg=d.groupby("region_id").agg(w=("region_weight","first"),x=("x","first"),y=("y","first"))
reg["e"]=reg.w/reg.w.sum()
d["z_c"]=d.share*d.shock
reg["z"]=d.groupby("region_id").z_c.sum()
e=reg.e.values
def wiv(y,x,z,w):
    yb=np.sum(w*y)/w.sum(); xb=np.sum(w*x)/w.sum(); zb=np.sum(w*z)/w.sum()
    return np.sum(w*(z-zb)*(y-yb))/np.sum(w*(z-zb)*(x-xb))
b_reg=wiv(reg.y.values,reg.x.values,reg.z.values,e)
fs_reg=wiv(reg.x.values,reg.z.values,reg.z.values,e)
for v in "xyz": reg[v+"0"]=reg[v]-np.sum(e*reg[v])
m=d.merge(reg[["e","x0","y0","z0"]],left_on="region_id",right_index=True)
m["es"]=m.e*m.share
g=m.groupby("industry_id")
sh=pd.DataFrame({"s":g.es.sum(),"g":g.shock.first()})
for v in "xyz": sh[v]=g.apply(lambda t:(t.es*t[v+"0"]).sum())/sh.s
N=len(sh)
def ssiv(y,x,g,w):
    X=np.column_stack([np.ones(N),x]);Z=np.column_stack([np.ones(N),g])
    W=np.diag(w); A=np.linalg.inv(Z.T@W@X)
    b=A@Z.T@W@y; u=y-X@b
    meat=(Z*(w*u)[:,None]).T@(Z*(w*u)[:,None])
    V=A@meat@A.T*N/(N-2); return b[1],np.sqrt(V[1,1])
b,se=ssiv(sh.y.values,sh.x.values,sh.g.values,sh.s.values)
f,fse=ssiv(sh.x.values,sh.z.values,sh.g.values,sh.s.values)
print(b,b_reg,f,fs_reg,se,fse,sh.s.sum())
eff=1/np.sum(sh.s**2)
json.dump({"task_id":"applied_shift_share","platform":"python","estimates":[
 {"term":"effect","estimate":float(b),"se":float(se),"n_obs":N},
 {"term":"first_stage","estimate":float(f),"se":float(fse),"n_obs":N},
 {"term":"effective_shocks","estimate":float(eff),"se":None,"n_obs":N}],
 "method_metadata":{"estimator":"weighted 2SLS shift-share, BHJ shock-level","vcov":"HC1 shock-level, N/(N-2)"},
 "diagnostics":{"regional_2sls":float(b_reg),"regional_fs":float(fs_reg),"n_regions":len(reg)}},open("result.json","w"),indent=1)
