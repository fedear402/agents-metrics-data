import pandas as pd, numpy as np, json
import statsmodels.api as sm
d = pd.read_csv("input.csv")
d = d[d.score.abs() < 1].dropna(subset=["score","participated","earnings"]).copy()
n = len(d)
x = d.score.values; r = (x >= 0).astype(float); w = 1 - np.abs(x)
X = np.column_stack([np.ones(n), r, x, r*x])
XtWX_inv = np.linalg.inv(X.T @ (X * w[:, None]))
def fit(y):
    b = XtWX_inv @ (X.T @ (w*y)); return b, y - X @ b
by, ey = fit(d.earnings.values); bd, ed = fit(d.participated.values)
# influence functions for jump coefficient (index 1)
IF = (X * w[:, None]) @ XtWX_inv
iy = IF[:, 1]*ey; idd = IF[:, 1]*ed
vy, vd, cyd = (iy**2).sum(), (idd**2).sum(), (iy*idd).sum()
rf, fs = by[1], bd[1]; te = rf/fs
g = np.array([1/fs, -rf/fs**2])
vte = g @ np.array([[vy, cyd], [cyd, vd]]) @ g
# check vs statsmodels
for y, v in [(d.earnings, vy), (d.participated, vd)]:
    m = sm.WLS(y.values, X, weights=w).fit(cov_type="HC0")
    assert abs(m.bse[1] - np.sqrt(v)) < 1e-10
res = {"task_id": "applied_fuzzy_rd", "platform": "python",
 "estimates": [
  {"term": "treatment_effect", "estimate": float(te), "se": float(np.sqrt(vte)), "n_obs": n},
  {"term": "reduced_form", "estimate": float(rf), "se": float(np.sqrt(vy)), "n_obs": n},
  {"term": "first_stage", "estimate": float(fs), "se": float(np.sqrt(vd)), "n_obs": n}],
 "method_metadata": {"estimator": "fuzzy RD, local linear, triangular kernel, h=1, ratio of WLS jumps", "vcov": "HC0 joint sandwich, delta method"},
 "diagnostics": {"cov_rf_fs": float(cyd), "n_left": int((r==0).sum()), "n_right": int(r.sum())}}
json.dump(res, open("result.json", "w"), indent=2)
print(res)
# independent check: 2SLS with weights gives same TE and SE
from linearmodels.iv import IV2SLS
try:
    iv = IV2SLS(d.earnings.values, np.column_stack([np.ones(n), x, r*x]), d.participated.values[:,None], r[:,None], weights=w).fit(cov_type="robust", debiased=False)
    print("IV check", iv.params.iloc[-1], iv.std_errors.iloc[-1])
except Exception as e: print("IV skip", e)
