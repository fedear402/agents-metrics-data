import pandas as pd, numpy as np, json
d=pd.read_csv("input.csv")
reg=d.groupby("region_id").first()[["region_weight","x","y"]]
reg["e"]=reg.region_weight/reg.region_weight.sum()
d["sz"]=d.share*d.shock
reg["z"]=d.groupby("region_id").sz.sum()
e=reg.e.values
def wiv(y,x,z,w):
    X=np.column_stack([np.ones_like(x),x]); Z=np.column_stack([np.ones_like(z),z])
    b=np.linalg.solve(Z.T@(w[:,None]*X),Z.T@(w*y)); return b,X,Z
def hc1(y,x,z,w):
    b,X,Z=wiv(y,x,z,w); u=y-X@b; n=len(y)
    A=np.linalg.inv(Z.T@(w[:,None]*X)); M=(Z*(w*u)[:,None]); V=A@(M.T@M)@A.T*n/(n-2)
    return b[1],np.sqrt(V[1,1])
for v in ["x","y","z"]: reg[v+"0"]=reg[v]-np.sum(e*reg[v])
d=d.merge(reg[["e","x0","y0","z0"]],left_on="region_id",right_index=True)
d["es"]=d.e*d.share
g=d.groupby("industry_id")
s=g.es.sum(); shock=g.shock.first()
bar={v:(d.es*d[v]).groupby(d.industry_id).sum()/s for v in ["x0","y0","z0"]}
N=len(s); sv=s.values
b_reg=wiv(reg.y.values,reg.x.values,reg.z.values,e)[0][1]
fs_reg=wiv(reg.x.values,reg.z.values,reg.z.values,e)[0][1]
b,se=hc1(bar["y0"].values,bar["x0"].values,shock.values,sv)
f,fse=hc1(bar["x0"].values,bar["z0"].values,shock.values,sv)
eff=1/np.sum(sv**2)
print(b_reg,b,se,fs_reg,f,fse,eff,N,len(reg),sv.sum())
json.dump({"task_id":"applied_shift_share","platform":"python","estimates":[
 {"term":"effect","estimate":float(b_reg),"se":float(se),"n_obs":N},
 {"term":"first_stage","estimate":float(fs_reg),"se":float(fse),"n_obs":N},
 {"term":"effective_shocks","estimate":float(eff),"se":None,"n_obs":N}],
 "method_metadata":{"estimator":"weighted 2SLS shift-share","vcov":"BHJ shock-level HC1 N/(N-2)"},
 "diagnostics":{"shock_level_effect":float(b),"shock_level_first_stage":float(f),"n_regions":len(reg)}},open("result.json","w"),indent=1)
