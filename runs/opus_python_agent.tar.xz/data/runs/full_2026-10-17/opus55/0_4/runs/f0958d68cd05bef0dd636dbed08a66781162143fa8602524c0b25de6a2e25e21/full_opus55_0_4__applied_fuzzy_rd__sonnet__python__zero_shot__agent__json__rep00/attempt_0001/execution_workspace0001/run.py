import pandas as pd, numpy as np, json
import statsmodels.api as sm
d=pd.read_csv("input.csv")
d=d[d.score.abs()<1].dropna(subset=["score","participated","earnings"]).copy()
x=d.score.values; r=(x>=0).astype(float); w=1-np.abs(x)
X=np.column_stack([np.ones_like(x),r,x,r*x]); n=len(d)
fits={}
for k,y in [("rf",d.earnings.values),("fs",d.participated.values)]:
    fits[k]=sm.WLS(y,X,weights=w).fit(cov_type="HC0")
# joint HC0 sandwich
B=np.linalg.inv(X.T@(w[:,None]*X))
S=(X*(w*fits["rf"].resid)[:,None]); T=(X*(w*fits["fs"].resid)[:,None])
V=lambda A,C: B@(A.T@C)@B
vrr,vff,vrf=V(S,S)[1,1],V(T,T)[1,1],V(S,T)[1,1]
rf,fs=fits["rf"].params[1],fits["fs"].params[1]
te=rf/fs; g=np.array([1/fs,-rf/fs**2])
vte=g@np.array([[vrr,vrf],[vrf,vff]])@g
assert np.isclose(vrr,fits["rf"].bse[1]**2) and np.isclose(vff,fits["fs"].bse[1]**2)
# check: IV with weights gives same point estimate
from numpy.linalg import solve
Z=X; D=np.column_stack([np.ones_like(x),d.participated.values,x,r*x])
biv=solve(Z.T@(w[:,None]*D),Z.T@(w*d.earnings.values))
assert np.isclose(biv[1],te)
u=d.earnings.values-D@biv; A=solve(Z.T@(w[:,None]*D),np.eye(4))
Vi=A@((Z*(w*u)[:,None]).T@(Z*(w*u)[:,None]))@A.T
print(n,te,vte**.5,"IV se",Vi[1,1]**.5,rf,vrr**.5,fs,vff**.5)
json.dump({"task_id":"applied_fuzzy_rd","platform":"python","estimates":[
 {"term":"treatment_effect","estimate":float(te),"se":float(vte**.5),"n_obs":n},
 {"term":"reduced_form","estimate":float(rf),"se":float(vrr**.5),"n_obs":n},
 {"term":"first_stage","estimate":float(fs),"se":float(vff**.5),"n_obs":n}],
 "method_metadata":{"estimator":"fuzzy RD local linear, triangular kernel h=1, ratio of WLS discontinuities","vcov":"HC0 joint sandwich, delta method"},
 "diagnostics":{"cov_rf_fs":float(vrf),"iv_se_check":float(Vi[1,1]**.5)}},open("result.json","w"),indent=1)
