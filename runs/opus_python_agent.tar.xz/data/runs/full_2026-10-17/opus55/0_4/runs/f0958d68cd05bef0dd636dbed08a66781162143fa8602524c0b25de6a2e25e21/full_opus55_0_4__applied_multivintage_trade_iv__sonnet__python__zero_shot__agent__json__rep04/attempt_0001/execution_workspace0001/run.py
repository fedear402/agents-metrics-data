import pandas as pd, numpy as np, json
cw=pd.read_csv('crosswalk.csv'); tr=pd.read_csv('trade.csv').merge(cw,on='code',validate='m:1')
ar=pd.read_csv('areas.csv'); em=pd.read_csv('employment.csv'); out=pd.read_csv('outcomes.csv')
areas=ar[['area','period']].drop_duplicates()
full=areas.assign(k=1).merge(pd.DataFrame({'vintage':['base','early'],'k':1})).merge(pd.DataFrame({'industry':range(4),'k':1})).drop(columns='k')
em=full.merge(em,how='left',on=['area','period','vintage','industry']).fillna({'employment':0})
em['nat']=em.groupby(['period','vintage','industry']).employment.transform('sum')
em=em.merge(ar[['area','period','vintage','total_employment']],on=['area','period','vintage']).merge(tr,on=['period','industry'])
def expo(v,col):
    d=em[em.vintage==v]; t=d.employment/d.total_employment*d[col]/d.nat/(d.price_index/100)/1000*(10/d.years)
    return t.groupby([d.area,d.period]).sum().rename(v)
X=pd.concat([expo('base','us_change').rename('x'),expo('early','other_change').rename('z')],axis=1).reset_index()
df=out.merge(X,on=['area','period']).merge(ar[ar.vintage=='base'][['area','period','population']],on=['area','period'])
assert len(df)==72
c=np.ones(72); Xm=np.column_stack([c,df.period,df.control,df.x]); Z=np.column_stack([c,df.period,df.control,df.z])
w=df.population.values; y=df.change_pp.values
b=np.linalg.solve(Z.T@(w[:,None]*Xm),Z.T@(w*y))
# check: two-stage
g=np.linalg.lstsq(Z*np.sqrt(w)[:,None],df.x*np.sqrt(w),rcond=None)[0]; Xh=Xm.copy(); Xh[:,3]=Z@g
b2=np.linalg.lstsq(Xh*np.sqrt(w)[:,None],y*np.sqrt(w),rcond=None)[0]
print(b,b2); assert np.allclose(b,b2)
g0=lambda p,col:df[(df.area==0)&(df.period==p)][col].iloc[0]
est={'iv_slope':b[3],'exposure_area0_period0':g0(0,'x'),'exposure_area0_period1':g0(1,'x'),'instrument_area0_period0':g0(0,'z')}
print(est)
json.dump({'task_id':'applied_multivintage_trade_iv','platform':'python',
 'estimates':[{'term':k,'estimate':float(v),'se':None,'n_obs':72} for k,v in est.items()],
 'method_metadata':{'estimator':'weighted 2SLS, just-identified','weights':'base population'},
 'diagnostics':{'twostage_check_slope':float(b2[3]),'first_stage_z_coef':float(g[3])}},open('result.json','w'),indent=1)
