import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

data = pd.read_csv("input.csv", parse_dates=["date"]).sort_values("date").reset_index(drop=True)
data["dlv"] = np.log(data["vix"]).diff()
L = 15
lag_cols = []
for k in range(1, L + 1):
    data[f"lag{k}"] = data["dlv"].shift(k)
    lag_cols.append(f"lag{k}")
data["ly"] = np.log(data["sales"])
sample = data.dropna(subset=["ly"] + lag_cols)
N = len(sample)
X = np.column_stack([np.ones(N), sample[lag_cols].to_numpy()])
y = sample["ly"].to_numpy()
b = np.linalg.lstsq(X, y, rcond=None)[0]
e = y - X @ b
S = X * e[:, None]
meat = S.T @ S
for j in range(1, L + 1):
    G = S[j:].T @ S[:-j]
    meat += (1 - j / (L + 1)) * (G + G.T)
bread = np.linalg.inv(X.T @ X)
p = X.shape[1]
V = (N / (N - p)) * bread @ meat @ bread

# Independent check with statsmodels (HAC without small-sample correction)
res = sm.OLS(y, X).fit(cov_type="HAC", cov_kwds={"maxlags": L, "use_correction": False})
Vsm = res.cov_params() * N / (N - p)
assert np.allclose(res.params, b) and np.allclose(Vsm, V)

c = np.r_[0.0, np.ones(L)]
rows = [
    {"term": "cumulative_response", "estimate": float(c @ b), "se": float(np.sqrt(c @ V @ c)), "n_obs": N},
    {"term": "lag_1", "estimate": float(b[1]), "se": float(np.sqrt(V[1, 1])), "n_obs": N},
    {"term": "lag_15", "estimate": float(b[15]), "se": float(np.sqrt(V[15, 15])), "n_obs": N},
]
out = {"task_id": "applied_cumulative_hac", "platform": "python", "estimates": rows,
       "method_metadata": {"estimator": "OLS", "vcov": "Newey-West Bartlett maxlag 15, N/(N-16)"},
       "diagnostics": {"n_total": len(data), "sum_check_diff": float(sum(b[1:]) - c @ b),
                       "statsmodels_max_abs_vcov_diff": float(np.max(np.abs(Vsm - V)))}}
with open("result.json", "w") as f:
    json.dump(out, f, indent=2, allow_nan=False)
