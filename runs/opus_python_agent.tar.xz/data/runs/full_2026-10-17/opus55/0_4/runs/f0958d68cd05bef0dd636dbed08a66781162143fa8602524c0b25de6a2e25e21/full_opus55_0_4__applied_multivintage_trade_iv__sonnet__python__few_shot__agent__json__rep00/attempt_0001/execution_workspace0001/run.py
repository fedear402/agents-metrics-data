import pandas as pd, numpy as np, json
from linearmodels.iv import IV2SLS
cw=pd.read_csv('crosswalk.csv'); tr=pd.read_csv('trade.csv').merge(cw,on='code',validate='m:1')
ar=pd.read_csv('areas.csv'); em=pd.read_csv('employment.csv'); out=pd.read_csv('outcomes.csv')
idx=pd.MultiIndex.from_product([sorted(ar.area.unique()),[0,1],['base','early'],range(4)],names=['area','period','vintage','industry'])
em=em.groupby(['area','period','vintage','industry']).employment.sum().reindex(idx,fill_value=0).reset_index()
em['nat']=em.groupby(['period','vintage','industry']).employment.transform('sum')
em=em.merge(ar[['area','period','vintage','total_employment']],on=['area','period','vintage']).merge(tr,on=['period','industry'])
def build(v,col):
    d=em[em.vintage==v].copy()
    d['t']=d.employment/d.total_employment*d[col]/d.nat/(d.price_index/100)/1000*(10/d.years)
    return d.groupby(['area','period']).t.sum()
x=build('base','us_change').rename('x'); z=build('early','other_change').rename('z')
pop=ar[ar.vintage=='base'].set_index(['area','period']).population
df=out.set_index(['area','period']).join([x,z,pop]).reset_index()
assert len(df)==72 and df.notna().all().all()
df['const']=1.0
f=IV2SLS(df.change_pp,df[['const','period','control']],df.x,df.z,weights=df.population).fit()
# check: manual weighted 2SLS
W=np.sqrt(df.population.values)[:,None]
X=df[['const','period','control','x']].values*W; Z=df[['const','period','control','z']].values*W; y=df.change_pp.values*W[:,0]
Xh=Z@np.linalg.lstsq(Z,X,rcond=None)[0]; b=np.linalg.lstsq(Xh,y,rcond=None)[0]
g=lambda s,a,p: float(df.loc[(df.area==a)&(df.period==p),s].iloc[0])
est={'iv_slope':float(f.params['x']),'exposure_area0_period0':g('x',0,0),'exposure_area0_period1':g('x',0,1),'instrument_area0_period0':g('z',0,0)}
print(est, 'manual', b[-1])
json.dump({'task_id':'applied_multivintage_trade_iv','platform':'python',
 'estimates':[{'term':k,'estimate':v,'se':None,'n_obs':72} for k,v in est.items()],
 'method_metadata':{'estimator':'weighted 2SLS (linearmodels IV2SLS)','weights':'base population','exog':['const','period','control'],'instrument':'z'},
 'diagnostics':{'manual_2sls_slope':float(b[-1]),'first_stage_partial_f':float(f.first_stage.diagnostics['f.stat'].iloc[0])}},open('result.json','w'),indent=2)
