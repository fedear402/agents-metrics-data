import json, numpy as np, pandas as pd
h=pd.read_csv("households.csv"); c=pd.read_csv("census.csv")
d=h[h.recipient==0].reset_index(drop=True); n=len(d)
e=d.eligible.values.astype(float); ne=1-e; w=d.weight.values
X=np.column_stack([d.dose*ne,d.dose*e,ne,e,d.baseline*ne,d.baseline*e])
Z=np.column_stack([d.instrument*ne,d.instrument*e,ne,e,d.baseline*ne,d.baseline*e])
y=d.outcome.values
sw=np.sqrt(w)[:,None]; Xw,Zw,yw=X*sw,Z*sw,y*sw[:,0]
Xh=Zw@np.linalg.lstsq(Zw,Xw,rcond=None)[0]
b=np.linalg.lstsq(Xh,yw,rcond=None)[0]
# check: just-identified -> (Z'WX)^-1 Z'Wy
b2=np.linalg.solve(Zw.T@Xw,Zw.T@yw)
assert np.allclose(b,b2)
m0=np.average(d.dose[e==0],weights=w[e==0]); m1=np.average(d.dose[e==1],weights=w[e==1])
ie=b[0]*m0; ee=b[1]*m1
P=c.set_index("eligible").nonrecipient_population
pe=(P[0]*ie+P[1]*ee)/(P[0]+P[1])
est=[dict(term=t,estimate=float(v),se=None,n_obs=int(n)) for t,v in
 [("ineligible_effect",ie),("eligible_nonrecipient_effect",ee),("population_effect",pe)]]
json.dump(dict(task_id="applied_nonrecipient_population_iv",platform="python",estimates=est,
 method_metadata=dict(estimator="weighted 2SLS, just identified, no extra intercept",weights="weight"),
 diagnostics=dict(n_ineligible=int((e==0).sum()),n_eligible=int((e==1).sum()),slopes=b[:2].tolist(),
 mean_dose=[m0,m1],max_abs_diff_2sls_vs_ivformula=float(np.abs(b-b2).max()))),open("result.json","w"),indent=2)
print(json.dumps(est,indent=1),b,m0,m1)
