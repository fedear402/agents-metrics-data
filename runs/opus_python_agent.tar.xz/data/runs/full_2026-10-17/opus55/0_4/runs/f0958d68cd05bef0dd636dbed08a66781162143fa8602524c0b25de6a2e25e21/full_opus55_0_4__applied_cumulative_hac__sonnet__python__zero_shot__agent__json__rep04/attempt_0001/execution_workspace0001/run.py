import pandas as pd, numpy as np, json, statsmodels.api as sm
d=pd.read_csv("input.csv"); d["date"]=pd.to_datetime(d["date"]); d=d.sort_values("date").reset_index(drop=True)
d["y"]=np.log(d.sales); dv=np.log(d.vix).diff()
L=15; X=pd.concat({f"lag_{k}":dv.shift(k) for k in range(1,L+1)},axis=1)
df=pd.concat([d.y,X],axis=1).dropna()
y=df.y.values; Xm=sm.add_constant(df.drop(columns="y")).values
N,K=Xm.shape
b=np.linalg.solve(Xm.T@Xm,Xm.T@y); u=y-Xm@b
g=Xm*u[:,None]; S=g.T@g
for j in range(1,L+1):
    G=g[j:].T@g[:-j]; S+=(1-j/(L+1))*(G+G.T)
B=np.linalg.inv(Xm.T@Xm); V=B@S@B*N/(N-16)
# check vs statsmodels
r=sm.OLS(y,Xm).fit(cov_type="HAC",cov_kwds={"maxlags":L,"use_correction":False})
assert np.allclose(r.params,b) and np.allclose(r.cov_params()*N/(N-16),V)
w=np.r_[0,np.ones(L)]
cr=w@b; cse=np.sqrt(w@V@w)
# identity check: reparametrize so lag_1 coef = cumulative
Z=Xm.copy(); Z[:,2:]=Xm[:,2:]-Xm[:,[1]]
r2=sm.OLS(y,Z).fit(cov_type="HAC",cov_kwds={"maxlags":L,"use_correction":False})
assert np.isclose(r2.params[1],cr) and np.isclose(np.sqrt(r2.cov_params()[1,1]*N/(N-16)),cse)
se=np.sqrt(np.diag(V))
res={"task_id":"applied_cumulative_hac","platform":"python","estimates":[
 {"term":"cumulative_response","estimate":float(cr),"se":float(cse),"n_obs":int(N)},
 {"term":"lag_1","estimate":float(b[1]),"se":float(se[1]),"n_obs":int(N)},
 {"term":"lag_15","estimate":float(b[15]),"se":float(se[15]),"n_obs":int(N)}],
 "method_metadata":{"estimator":"OLS of log(sales) on const + lags 1-15 of dlog(vix)","vcov":"Newey-West Bartlett maxlag 15, scaled N/(N-16)"},
 "diagnostics":{"n_rows":len(d)}}
json.dump(res,open("result.json","w"),indent=2); print(res)
