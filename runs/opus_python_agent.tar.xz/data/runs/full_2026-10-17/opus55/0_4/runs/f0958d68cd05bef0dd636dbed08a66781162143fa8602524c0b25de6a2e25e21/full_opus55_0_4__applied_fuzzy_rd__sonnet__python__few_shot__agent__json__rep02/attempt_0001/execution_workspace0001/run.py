import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
d = df[df["score"].abs() < 1].copy()
s = d["score"].to_numpy(float)
w = 1 - np.abs(s)
r = (s >= 0).astype(float)
X = np.column_stack([np.ones_like(s), r, s, r * s])
Y = d[["earnings", "participated"]].to_numpy(float)
bread = np.linalg.inv(X.T @ (w[:, None] * X))
beta = bread @ X.T @ (w[:, None] * Y)
res = Y - X @ beta
c = np.array([0., 1., 0., 0.])
rf, fs = c @ beta
load = w * (X @ bread @ c)
inf = load[:, None] * res
V = inf.T @ inf
g = np.array([1 / fs, -rf / fs**2])
n = int(len(d))
out = {"task_id": "applied_fuzzy_rd", "platform": "python",
 "estimates": [
  {"term": "treatment_effect", "estimate": float(rf / fs), "se": float(np.sqrt(g @ V @ g)), "n_obs": n},
  {"term": "reduced_form", "estimate": float(rf), "se": float(np.sqrt(V[0, 0])), "n_obs": n},
  {"term": "first_stage", "estimate": float(fs), "se": float(np.sqrt(V[1, 1])), "n_obs": n}],
 "method_metadata": {"estimator": "fuzzy RD, local linear, triangular kernel, h=1, separate slopes", "vcov": "HC0 joint, delta method"},
 "diagnostics": {"cov_rf_fs": float(V[0, 1])}}
json.dump(out, open("result.json", "w"), indent=2)
