import pandas as pd, numpy as np, json
import statsmodels.api as sm
df=pd.read_csv("input.csv")
d=df[df.score.abs()<1].dropna(subset=["score","participated","earnings"]).copy()
w=1-d.score.abs().values
r=(d.score>=0).astype(float).values
s=d.score.values
X=np.column_stack([np.ones(len(d)),r,s,r*s])
n=len(d)
fits={}
for y in ["earnings","participated"]:
    fits[y]=sm.WLS(d[y].values,X,weights=w).fit(cov_type="HC0")
# joint covariance via stacked influence functions
XtWX_inv=np.linalg.inv(X.T@(X*w[:,None]))
psi={}
for y,f in fits.items():
    e=d[y].values-X@f.params
    psi[y]=(X*(w*e)[:,None])@XtWX_inv  # n x k
a=psi["earnings"][:,1]; b=psi["participated"][:,1]
V=np.array([[a@a,a@b],[a@b,b@b]])
rf=fits["earnings"].params[1]; fs=fits["participated"].params[1]
te=rf/fs
g=np.array([1/fs,-rf/fs**2])
se_te=float(np.sqrt(g@V@g))
assert np.isclose(np.sqrt(V[0,0]),fits["earnings"].bse[1])
# check: IV equivalence
from numpy.linalg import solve
Z=X; Xe=np.column_stack([np.ones(n),d.participated.values,s,r*s])
bIV=solve(Z.T@(Xe*w[:,None]),Z.T@(w*d.earnings.values))
assert np.isclose(bIV[1],te)
ue=d.earnings.values-Xe@bIV
A=np.linalg.inv(Z.T@(Xe*w[:,None])); M=(Z*(w*ue)[:,None]); Vi=A@(M.T@M)@A.T
print(rf,fs,te,se_te,np.sqrt(Vi[1,1]),n)
res={"task_id":"applied_fuzzy_rd","platform":"python","estimates":[
 {"term":"treatment_effect","estimate":float(te),"se":se_te,"n_obs":n},
 {"term":"reduced_form","estimate":float(rf),"se":float(np.sqrt(V[0,0])),"n_obs":n},
 {"term":"first_stage","estimate":float(fs),"se":float(np.sqrt(V[1,1])),"n_obs":n}],
 "method_metadata":{"estimator":"fuzzy RD local linear, triangular kernel h=1, ratio of WLS discontinuities","vcov":"HC0, delta method with joint covariance"},
 "diagnostics":{"cov_rf_fs":float(V[0,1]),"iv_se_check":float(np.sqrt(Vi[1,1]))}}
json.dump(res,open("result.json","w"),indent=2)
