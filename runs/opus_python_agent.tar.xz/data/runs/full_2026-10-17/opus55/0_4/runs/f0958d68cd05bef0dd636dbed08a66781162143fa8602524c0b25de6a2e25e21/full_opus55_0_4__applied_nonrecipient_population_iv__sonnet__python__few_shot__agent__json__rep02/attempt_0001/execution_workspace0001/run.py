import json, numpy as np, pandas as pd
from linearmodels.iv import IV2SLS
h = pd.read_csv('households.csv'); c = pd.read_csv('census.csv')
d = h[h.recipient == 0].copy()
e = d.eligible; ne = 1 - e
X = pd.DataFrame({'ineligible': ne, 'eligible': e, 'base_in': d.baseline*ne, 'base_el': d.baseline*e})
D = pd.DataFrame({'dose_in': d.dose*ne, 'dose_el': d.dose*e})
Z = pd.DataFrame({'inst_in': d.instrument*ne, 'inst_el': d.instrument*e})
fit = IV2SLS(d.outcome, X, D, Z, weights=d.weight).fit()
# manual check: weighted 2SLS
W = np.sqrt(d.weight.values)[:, None]
Xf = np.column_stack([X, D]) * W; Zf = np.column_stack([X, Z]) * W; y = d.outcome.values * W[:, 0]
P = Zf @ np.linalg.lstsq(Zf, Xf, rcond=None)[0]
b = np.linalg.lstsq(P, y, rcond=None)[0]
assert np.allclose(b[-2:], fit.params[['dose_in', 'dose_el']].values)
eff = {}
for g, name in [(0, 'dose_in'), (1, 'dose_el')]:
    s = d[d.eligible == g]
    eff[g] = float(fit.params[name] * np.average(s.dose, weights=s.weight))
pop = c.set_index('eligible').nonrecipient_population
pe = float((eff[0]*pop[0] + eff[1]*pop[1]) / (pop[0] + pop[1]))
n = int(len(d))
res = {"task_id": "applied_nonrecipient_population_iv", "platform": "python",
 "estimates": [{"term": t, "estimate": v, "se": None, "n_obs": n} for t, v in
   [("ineligible_effect", eff[0]), ("eligible_nonrecipient_effect", eff[1]), ("population_effect", pe)]],
 "method_metadata": {"estimator": "weighted 2SLS (linearmodels IV2SLS)", "census_weights": {str(k): int(v) for k, v in pop.items()}},
 "diagnostics": {"n_ineligible": int((d.eligible==0).sum()), "n_eligible_nonrecipient": int((d.eligible==1).sum()),
   "slopes": {k: float(fit.params[k]) for k in ['dose_in','dose_el']}, "manual_2sls_match": True}}
json.dump(res, open('result.json', 'w'), indent=2)
print(json.dumps(res, indent=2))
