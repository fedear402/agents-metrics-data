import json
import numpy as np, pandas as pd
import statsmodels.api as sm
d = pd.read_csv("input.csv")
d = d[d.score.abs() < 1].copy()
n = len(d)
s = d.score.values; r = (s >= 0).astype(float)
w = 1 - np.abs(s)
X = np.column_stack([np.ones(n), r, s, r * s])
Y = d[["earnings", "participated"]].values.astype(float)
bread = np.linalg.inv(X.T @ (w[:, None] * X))
B = bread @ X.T @ (w[:, None] * Y)
res = Y - X @ B
c = np.array([0., 1., 0., 0.])
rf, fs = c @ B
load = w * (X @ bread @ c)
inf = load[:, None] * res
V = inf.T @ inf
g = np.array([1 / fs, -rf / fs**2])
te = rf / fs
# check with statsmodels WLS HC0
chk = [sm.WLS(Y[:, k], X, weights=w).fit(cov_type="HC0") for k in range(2)]
diag = {"sm_rf": float(chk[0].params[1]), "sm_rf_se": float(chk[0].bse[1]),
        "sm_fs": float(chk[1].params[1]), "sm_fs_se": float(chk[1].bse[1]),
        "cov_rf_fs": float(V[0, 1]), "n_left": int((r == 0).sum()), "n_right": int(r.sum())}
row = lambda t, e, se: {"term": t, "estimate": float(e), "se": float(se), "n_obs": int(n)}
out = {"task_id": "applied_fuzzy_rd", "platform": "python",
       "estimates": [row("treatment_effect", te, np.sqrt(g @ V @ g)),
                     row("reduced_form", rf, np.sqrt(V[0, 0])),
                     row("first_stage", fs, np.sqrt(V[1, 1]))],
       "method_metadata": {"estimator": "fuzzy RD local linear, triangular kernel h=1, ratio of WLS jumps",
                           "vcov": "HC0 joint, delta method"},
       "diagnostics": diag}
json.dump(out, open("result.json", "w"), indent=2)
