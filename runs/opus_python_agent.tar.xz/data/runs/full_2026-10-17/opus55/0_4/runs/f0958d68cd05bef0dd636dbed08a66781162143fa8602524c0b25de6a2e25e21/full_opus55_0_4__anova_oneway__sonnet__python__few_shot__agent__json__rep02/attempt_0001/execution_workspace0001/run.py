import json
import numpy as np
import pandas as pd
from scipy import stats

df = pd.read_csv("input.csv").dropna(subset=["group", "y"])
groups = [g["y"].values for _, g in df.groupby("group")]
n, k = len(df), len(groups)
F, p = stats.f_oneway(*groups)
# manual check
gm = df["y"].mean()
ssb = sum(len(g) * (g.mean() - gm) ** 2 for g in groups)
ssw = sum(((g - g.mean()) ** 2).sum() for g in groups)
F2 = (ssb / (k - 1)) / (ssw / (n - k))
assert abs(F - F2) < 1e-8 * max(1, F)
out = {
    "task_id": "anova_oneway",
    "platform": "python",
    "estimates": [
        {"term": "F", "estimate": float(F), "se": None, "n_obs": n},
        {"term": "df_num", "estimate": float(k - 1), "se": None, "n_obs": n},
        {"term": "df_den", "estimate": float(n - k), "se": None, "n_obs": n},
        {"term": "p_value", "estimate": float(p), "se": None, "n_obs": n},
    ],
    "method_metadata": {"estimator": "one-way ANOVA (scipy f_oneway)", "vcov": "none"},
    "diagnostics": {"F_manual": float(F2), "p_manual": float(stats.f.sf(F2, k - 1, n - k))},
}
with open("result.json", "w") as f:
    json.dump(out, f)
