import pandas as pd, numpy as np, json
cw=pd.read_csv("crosswalk.csv"); assert cw.equals(pd.read_csv("input.csv"))
tr=pd.read_csv("trade.csv").merge(cw,on="code",how="left",validate="one_to_one")
ar=pd.read_csv("areas.csv"); em=pd.read_csv("employment.csv"); out=pd.read_csv("outcomes.csv")
idx=pd.MultiIndex.from_product([ar.area.unique(),ar.period.unique(),["base","early"],range(4)],names=["area","period","vintage","industry"])
E=em.groupby(["area","period","vintage","industry"]).employment.sum().reindex(idx,fill_value=0).reset_index()
E["nat"]=E.groupby(["period","vintage","industry"]).employment.transform("sum")
E=E.merge(ar[["area","period","vintage","total_employment"]],on=["area","period","vintage"]).merge(tr,on=["period","industry"])
def expo(v,ch):
    d=E[E.vintage==v]
    t=d.employment/d.total_employment*d[ch]/d.nat/(d.price_index/100)/1000*(10/d.years)
    return t.groupby([d.area,d.period]).sum().rename(ch)
X=pd.concat([expo("base","us_change").rename("x"),expo("early","other_change").rename("z")],axis=1).reset_index()
pop=ar[ar.vintage=="base"][["area","period","population"]]
D=out.merge(X,on=["area","period"]).merge(pop,on=["area","period"]); assert len(D)==72
w=D.population.values; y=D.change_pp.values
Xm=np.column_stack([np.ones(72),D.period,D.control,D.x]); Zm=np.column_stack([np.ones(72),D.period,D.control,D.z])
W=np.diag(w); P=Zm@np.linalg.solve(Zm.T@W@Zm,Zm.T@W)
b=np.linalg.solve(Xm.T@W@P@Xm,Xm.T@W@P@y)
# check: just-identified IV = (Z'WX)^-1 Z'Wy
b2=np.linalg.solve(Zm.T@W@Xm,Zm.T@W@y); assert np.allclose(b,b2)
g=lambda a,p,c:float(D.loc[(D.area==a)&(D.period==p),c].iloc[0])
est={"iv_slope":b[3],"exposure_area0_period0":g(0,0,"x"),"exposure_area0_period1":g(0,1,"x"),"instrument_area0_period0":g(0,0,"z")}
print(est,b2)
json.dump({"task_id":"applied_multivintage_trade_iv","platform":"python",
 "estimates":[{"term":k,"estimate":float(v),"se":None,"n_obs":72} for k,v in est.items()],
 "method_metadata":{"estimator":"weighted 2SLS","weights":"base population","instruments":["const","period","control","z"]},
 "diagnostics":{"n_obs":72,"just_identified_check_maxdiff":float(np.abs(b-b2).max())}},open("result.json","w"),indent=1)
