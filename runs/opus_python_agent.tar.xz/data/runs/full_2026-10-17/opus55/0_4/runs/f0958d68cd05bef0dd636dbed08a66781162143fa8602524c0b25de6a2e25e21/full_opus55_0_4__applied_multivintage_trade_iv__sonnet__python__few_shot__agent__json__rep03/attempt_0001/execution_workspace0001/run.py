import pandas as pd, numpy as np, json
from linearmodels.iv import IV2SLS
cw=pd.read_csv('crosswalk.csv'); inp=pd.read_csv('input.csv')
assert inp.equals(cw)
tr=pd.read_csv('trade.csv').merge(cw,on='code',validate='m:1')
ar=pd.read_csv('areas.csv'); em=pd.read_csv('employment.csv'); out=pd.read_csv('outcomes.csv')
full=pd.MultiIndex.from_product([sorted(ar.area.unique()),sorted(ar.period.unique()),['base','early'],range(4)],names=['area','period','vintage','industry'])
em=em.groupby(['area','period','vintage','industry']).employment.sum().reindex(full,fill_value=0).reset_index()
em['nat']=em.groupby(['period','vintage','industry']).employment.transform('sum')
em=em.merge(tr,on=['period','industry']).merge(ar[['area','period','vintage','total_employment']],on=['area','period','vintage'])
em['chg']=np.where(em.vintage=='base',em.us_change,em.other_change)
em['c']=em.employment/em.total_employment*em.chg/em.nat/(em.price_index/100)/1000*(10/em.years)
e=em.groupby(['area','period','vintage']).c.sum().unstack('vintage').reset_index()
e=e.rename(columns={'base':'x','early':'z'})
pop=ar[ar.vintage=='base'][['area','period','population']]
d=out.merge(e,on=['area','period']).merge(pop,on=['area','period'])
assert len(d)==72
d['const']=1.0
f=IV2SLS(d.change_pp,d[['const','period','control']],d.x,d.z,weights=d.population).fit()
# check: manual weighted 2SLS
W=np.sqrt(d.population.values)[:,None]
X=d[['const','period','control','x']].values*W; Z=d[['const','period','control','z']].values*W; y=d.change_pp.values*W[:,0]
Xh=Z@np.linalg.lstsq(Z,X,rcond=None)[0]; b=np.linalg.lstsq(Xh,y,rcond=None)[0]
assert abs(b[-1]-f.params['x'])<1e-8
g=lambda a,p,c:float(d.loc[(d.area==a)&(d.period==p),c].iloc[0])
est={'iv_slope':float(f.params['x']),'exposure_area0_period0':g(0,0,'x'),'exposure_area0_period1':g(0,1,'x'),'instrument_area0_period0':g(0,0,'z')}
print(est,b[-1])
json.dump({'task_id':'applied_multivintage_trade_iv','platform':'python',
 'estimates':[{'term':k,'estimate':v,'se':None,'n_obs':72} for k,v in est.items()],
 'method_metadata':{'estimator':'weighted 2SLS (linearmodels IV2SLS)','weights':'base population','instruments':'z, const, period, control'},
 'diagnostics':{'manual_2sls_slope':float(b[-1]),'n_obs':72}},open('result.json','w'),indent=2)
