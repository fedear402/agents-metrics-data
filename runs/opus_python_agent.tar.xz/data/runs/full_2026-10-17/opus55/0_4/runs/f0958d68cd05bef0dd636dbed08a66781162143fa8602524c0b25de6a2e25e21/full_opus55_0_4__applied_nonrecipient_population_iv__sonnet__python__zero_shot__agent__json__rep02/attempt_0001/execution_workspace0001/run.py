import json, numpy as np, pandas as pd
h=pd.read_csv("households.csv"); c=pd.read_csv("census.csv")
d=h[h.recipient==0].copy(); n=len(d)
e=d.eligible.values.astype(float); ne=1-e; w=d.weight.values.astype(float)
X=np.column_stack([d.dose*ne,d.dose*e,ne,e,d.baseline*ne,d.baseline*e])
Z=np.column_stack([d.instrument*ne,d.instrument*e,ne,e,d.baseline*ne,d.baseline*e])
y=d.outcome.values
W=w[:,None]
Pz=Z@np.linalg.solve(Z.T@(W*Z),Z.T@(W*X))  # first-stage fitted X
b=np.linalg.solve(Pz.T@(W*X),Pz.T@(w*y))
# check: explicit second stage OLS on fitted values
b2=np.linalg.lstsq(np.sqrt(W)*Pz,np.sqrt(w)*y,rcond=None)[0]
assert np.allclose(b,b2)
eff={}
for g,k,name in [(0,0,"ineligible_effect"),(1,1,"eligible_nonrecipient_effect")]:
    m=e==g; md=np.average(d.dose.values[m],weights=w[m]); eff[name]=(b[k]*md,md)
pop=c.set_index("eligible").nonrecipient_population
pe=(eff["ineligible_effect"][0]*pop[0]+eff["eligible_nonrecipient_effect"][0]*pop[1])/(pop[0]+pop[1])
est=[{"term":k,"estimate":float(v[0]),"se":None,"n_obs":int(n)} for k,v in eff.items()]
est.append({"term":"population_effect","estimate":float(pe),"se":None,"n_obs":int(n)})
json.dump({"task_id":"applied_nonrecipient_population_iv","platform":"python","estimates":est,
 "method_metadata":{"estimator":"weighted 2SLS, group-interacted, no extra intercept","sample":"recipient==0","counterfactual":"dose=0"},
 "diagnostics":{"coef":b.tolist(),"mean_dose":{k:float(v[1]) for k,v in eff.items()},"n_ineligible":int((e==0).sum()),"n_eligible":int((e==1).sum()),"census_weights":pop.to_dict()}},open("result.json","w"),indent=2)
print(json.dumps(est,indent=1),b)
