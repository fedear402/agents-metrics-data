import json, numpy as np, pandas as pd
from linearmodels.iv import IV2SLS
cw=pd.read_csv('crosswalk.csv'); cw2=pd.read_csv('input.csv')
assert cw.equals(cw2)  # input.csv duplicates crosswalk
tr=pd.read_csv('trade.csv').merge(cw,on='code',how='left')
ar=pd.read_csv('areas.csv'); em=pd.read_csv('employment.csv'); oc=pd.read_csv('outcomes.csv')
full=ar[['area','period','vintage']].merge(pd.DataFrame({'industry':range(4)}),how='cross')
em=full.merge(em,on=['area','period','vintage','industry'],how='left').fillna({'employment':0})
em['nat']=em.groupby(['period','vintage','industry']).employment.transform('sum')
em=em.merge(ar,on=['area','period','vintage']).merge(tr,on=['period','industry'])
def expo(v,col):
    d=em[em.vintage==v].copy()
    d['t']=d.employment/d.total_employment*d[col]/d.nat/(d.price_index/100)/1000*(10/d.years)
    return d.groupby(['area','period']).t.sum().rename(v)
X=pd.concat([expo('base','us_change'),expo('early','other_change')],axis=1).reset_index().rename(columns={'base':'x','early':'z'})
pop=ar[ar.vintage=='base'][['area','period','population']]
d=oc.merge(X,on=['area','period']).merge(pop,on=['area','period'])
assert len(d)==72
d['const']=1.0
r=IV2SLS(d.change_pp,d[['const','period','control']],d[['x']],d[['z']],weights=d.population).fit()
# manual check
W=np.sqrt(d.population.values)[:,None]
Z=d[['const','period','control','z']].values*W; Xm=d[['const','period','control','x']].values*W; y=d.change_pp.values*W[:,0]
P=Z@np.linalg.lstsq(Z,Xm,rcond=None)[0]; b=np.linalg.lstsq(P,y,rcond=None)[0]
assert abs(b[-1]-r.params['x'])<1e-8
g=lambda a,p,c: float(d[(d.area==a)&(d.period==p)][c].iloc[0])
est={'iv_slope':float(r.params['x']),'exposure_area0_period0':g(0,0,'x'),'exposure_area0_period1':g(0,1,'x'),'instrument_area0_period0':g(0,0,'z')}
print(est, b[-1])
json.dump({'task_id':'applied_multivintage_trade_iv','platform':'python',
 'estimates':[{'term':k,'estimate':v,'se':None,'n_obs':72} for k,v in est.items()],
 'method_metadata':{'estimator':'weighted 2SLS (linearmodels IV2SLS)','weights':'base population','instruments':'z, const, period, control'},
 'diagnostics':{'manual_2sls_slope':float(b[-1]),'n_obs':72}},open('result.json','w'),indent=1)
