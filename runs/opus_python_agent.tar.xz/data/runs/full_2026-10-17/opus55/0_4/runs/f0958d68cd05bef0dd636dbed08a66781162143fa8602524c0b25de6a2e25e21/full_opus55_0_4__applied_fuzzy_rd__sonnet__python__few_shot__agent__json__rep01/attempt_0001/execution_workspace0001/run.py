import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("input.csv")
d = df[(df.score - 0).abs() < 1].copy()
n = len(d)
x = d.score.to_numpy(float)
w = 1 - np.abs(x)
r = (x >= 0).astype(float)
X = np.column_stack([np.ones(n), r, x, r * x])
Y = d[["earnings", "participated"]].to_numpy(float)
bread = np.linalg.inv(X.T @ (w[:, None] * X))
B = bread @ X.T @ (w[:, None] * Y)
res = Y - X @ B
c = np.array([0., 1., 0., 0.])
rf, fs = c @ B
load = w * (X @ bread @ c)
inf = load[:, None] * res
V = inf.T @ inf
g = np.array([1 / fs, -rf / fs**2])
te = rf / fs
se_te = float(np.sqrt(g @ V @ g))
# check with statsmodels WLS HC0
chk = [sm.WLS(Y[:, k], X, weights=w).fit(cov_type="HC0") for k in range(2)]
diag = {"sm_rf_se": float(chk[0].bse[1]), "sm_fs_se": float(chk[1].bse[1]),
        "cov_rf_fs": float(V[0, 1]), "n_left": int((r == 0).sum()), "n_right": int(r.sum())}
out = {"task_id": "applied_fuzzy_rd", "platform": "python",
       "estimates": [
           {"term": "treatment_effect", "estimate": float(te), "se": se_te, "n_obs": n},
           {"term": "reduced_form", "estimate": float(rf), "se": float(np.sqrt(V[0, 0])), "n_obs": n},
           {"term": "first_stage", "estimate": float(fs), "se": float(np.sqrt(V[1, 1])), "n_obs": n}],
       "method_metadata": {"estimator": "fuzzy RD local linear, triangular kernel, h=1, Wald ratio",
                           "vcov": "HC0 joint sandwich, delta method"},
       "diagnostics": diag}
json.dump(out, open("result.json", "w"), indent=2)
print(json.dumps(out, indent=2))
