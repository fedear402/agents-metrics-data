import numpy as np, pandas as pd
df = pd.read_csv("input.csv")
df = df.sort_values("date").reset_index(drop=True)
lv = np.log(df["vix"].values); ls = np.log(df["sales"].values)
d = np.full(len(df), np.nan); d[1:] = lv[1:] - lv[:-1]
L = 15
rows = range(L+1, len(df))  # need d[t-1..t-15] all valid (t-15>=1)
y = ls[list(rows)]
X = np.column_stack([np.ones(len(y))] + [d[np.array(list(rows))-k] for k in range(1, L+1)])
N, K = X.shape
XtX_inv = np.linalg.inv(X.T @ X)
b = XtX_inv @ X.T @ y
e = y - X @ b
S = (X * e[:, None]).T @ (X * e[:, None])
for j in range(1, L+1):
    w = 1 - j/(L+1)
    G = (X[j:] * e[j:, None]).T @ (X[:-j] * e[:-j, None])
    S += w * (G + G.T)
V = XtX_inv @ S @ XtX_inv * N/(N-16)
c = np.zeros(K); c[1:] = 1
print("N", N)
print("cum", c @ b, np.sqrt(c @ V @ c))
print("lag1", b[1], np.sqrt(V[1,1]))
print("lag15", b[15], np.sqrt(V[15,15]))
