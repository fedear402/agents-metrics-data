clear all
set more off
cd "/private/tmp/prospective_task_z5fzey8f"

import delimited using "crosswalk.csv", clear
isid code
tempfile cw
save `cw'

import delimited using "trade.csv", clear
merge m:1 code using `cw', keep(match) nogenerate assert(match)
isid period industry
tempfile tr
save `tr'

import delimited using "areas.csv", clear
isid area period vintage
tempfile ar
save `ar'

import delimited using "employment.csv", clear
isid area period vintage industry
tempfile em
save `em'

import delimited using "outcomes.csv", clear
isid area period
tempfile oc
save `oc'

use `ar', clear
expand 4
bysort area period vintage: gen int industry = _n - 1
merge 1:1 area period vintage industry using `em', keep(master match) nogenerate
replace employment = 0 if missing(employment)
merge m:1 period industry using `tr', keep(match) nogenerate
assert _N == 576

bysort period vintage industry: egen double nat = total(employment)
assert nat > 0
gen double share = employment / total_employment
gen double x_term = share * (us_change / nat) / (price_index / 100) / 1000 * (10 / years) if vintage == "base"
gen double z_term = share * (other_change / nat) / (price_index / 100) / 1000 * (10 / years) if vintage == "early"

bysort area period: egen double x = total(x_term)
bysort area period: egen double z = total(z_term)
keep if vintage == "base" & industry == 0
keep area period population x z
merge 1:1 area period using `oc', assert(match) nogenerate
count
local n = r(N)
assert `n' == 72

ivregress 2sls change_pp period control (x = z) [aw = population]
local b_iv = _b[x]

summarize x if area == 0 & period == 0, meanonly
local e0 = r(mean)
summarize x if area == 0 & period == 1, meanonly
local e1 = r(mean)
summarize z if area == 0 & period == 0, meanonly
local i0 = r(mean)

local s_b = strtrim(string(`b_iv', "%18.12f"))
local s_e0 = strtrim(string(`e0', "%18.12f"))
local s_e1 = strtrim(string(`e1', "%18.12f"))
local s_i0 = strtrim(string(`i0', "%18.12f"))
file open fh using "answer.txt", write replace text
file write fh "ANSWER: iv_slope estimate=`s_b' se=NA n_obs=`n'" _n
file write fh "ANSWER: exposure_area0_period0 estimate=`s_e0' se=NA n_obs=`n'" _n
file write fh "ANSWER: exposure_area0_period1 estimate=`s_e1' se=NA n_obs=`n'" _n
file write fh "ANSWER: instrument_area0_period0 estimate=`s_i0' se=NA n_obs=`n'" _n
file close fh
type answer.txt
