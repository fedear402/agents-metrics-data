clear all
set more off
set linesize 255

import delimited using "./input.csv", clear stringcols(1)
gen double dt = date(date, "YMD")
format dt %td
sort dt
gen t = _n
tsset t

gen double lsales = ln(sales)
gen double lvix = ln(vix)
gen double dlvix = lvix - L.lvix
label var dlvix "first difference of log vix"

forvalues j = 1/15 {
    gen double l`j'dv = L`j'.dlvix
}

regress lsales l1dv-l15dv
gen byte insamp = e(sample)
count if insamp
local N = r(N)

newey lsales l1dv-l15dv, lag(15)
local Nn = e(N)
display "newey N = `Nn'"

matrix b0 = e(b)
* newey already scales e(V) by N/(N-16) (k=16 regressors incl. constant)
matrix V0 = e(V)
matrix V1 = V0
matrix list b0

mata:
b = st_matrix("b0")
V = st_matrix("V1")
c = J(1,16,0)
c[1,1..15] = J(1,15,1)
cum_est = c * b'
cum_se  = sqrt(c * V * c')
e1 = b[1,1]
s1 = sqrt(V[1,1])
e15 = b[1,15]
s15 = sqrt(V[15,15])
st_numscalar("cum_est", cum_est)
st_numscalar("cum_se", cum_se)
st_numscalar("e1", e1)
st_numscalar("s1", s1)
st_numscalar("e15", e15)
st_numscalar("s15", s15)
end

display "ANSWER: cumulative_response estimate=" %21.12f cum_est " se=" %21.12f cum_se " n_obs=" %12.0f `Nn'
display "ANSWER: lag_1 estimate=" %21.12f e1 " se=" %21.12f s1 " n_obs=" %12.0f `Nn'
display "ANSWER: lag_15 estimate=" %21.12f e15 " se=" %21.12f s15 " n_obs=" %12.0f `Nn'
