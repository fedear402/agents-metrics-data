clear all
set more off
set linesize 255
import delimited using "input.csv", clear varnames(1)

keep if abs(score) < 1
gen double w = 1 - abs(score)
gen byte right = (score >= 0)
gen double s = score
count
local nobs = r(N)

mata:
void rd_fuzzy()
{
    real colvector yE, yP, sS, wS, rS, idxR, idxL
    real matrix XR, XL, AR, AL
    real colvector bER, bEL, bPR, bPL, IFE_R, IFE_L, IFP_R, IFP_L
    real colvector Ifrf, Iffs
    real scalar rf, fs, tau, n, var_rf, var_fs, cov_fs_rf, var_tau
    real rowvector g
    real matrix V

    yE = st_data(., "earnings"); yP = st_data(., "participated")
    sS = st_data(., "s"); wS = st_data(., "w"); rS = st_data(., "right")
    idxR = selectindex(rS :== 1)
    idxL = selectindex(rS :== 0)

    XR = (J(rows(idxR),1,1), sS[idxR]); XL = (J(rows(idxL),1,1), sS[idxL])
    AR = invsym(cross(XR, wS[idxR], XR)); AL = invsym(cross(XL, wS[idxL], XL))

    bER = AR*cross(XR, wS[idxR], yE[idxR])
    bEL = AL*cross(XL, wS[idxL], yE[idxL])
    bPR = AR*cross(XR, wS[idxR], yP[idxR])
    bPL = AL*cross(XL, wS[idxL], yP[idxL])

    rf = bER[1] - bEL[1]
    fs = bPR[1] - bPL[1]
    tau = rf / fs

    IFE_R = (XR*AR[.,1]) :* wS[idxR] :* (yE[idxR] - XR*bER)
    IFE_L = (XL*AL[.,1]) :* wS[idxL] :* (yE[idxL] - XL*bEL)
    IFP_R = (XR*AR[.,1]) :* wS[idxR] :* (yP[idxR] - XR*bPR)
    IFP_L = (XL*AL[.,1]) :* wS[idxL] :* (yP[idxL] - XL*bPL)

    n = rows(yE)
    Ifrf = J(n,1,0); Iffs = J(n,1,0)
    Ifrf[idxR] = IFE_R;  Ifrf[idxL] = -IFE_L
    Iffs[idxR] = IFP_R;  Iffs[idxL] = -IFP_L

    var_rf = cross(Ifrf, Ifrf)
    var_fs = cross(Iffs, Iffs)
    cov_fs_rf = cross(Ifrf, Iffs)
    g = (1/fs, -rf/(fs^2))
    V = (var_rf, cov_fs_rf \ cov_fs_rf, var_fs)
    var_tau = g * V * g'

    st_numscalar("rf", rf); st_numscalar("fs", fs); st_numscalar("tau", tau)
    st_numscalar("se_rf", sqrt(var_rf)); st_numscalar("se_fs", sqrt(var_fs))
    st_numscalar("se_tau", sqrt(var_tau))
}
rd_fuzzy()
end

display "ANSWER: treatment_effect estimate=" %21.12f tau " se=" %21.12f se_tau " n_obs=" %12.0f `nobs'
display "ANSWER: reduced_form estimate=" %21.12f rf " se=" %21.12f se_rf " n_obs=" %12.0f `nobs'
display "ANSWER: first_stage estimate=" %21.12f fs " se=" %21.12f se_fs " n_obs=" %12.0f `nobs'
