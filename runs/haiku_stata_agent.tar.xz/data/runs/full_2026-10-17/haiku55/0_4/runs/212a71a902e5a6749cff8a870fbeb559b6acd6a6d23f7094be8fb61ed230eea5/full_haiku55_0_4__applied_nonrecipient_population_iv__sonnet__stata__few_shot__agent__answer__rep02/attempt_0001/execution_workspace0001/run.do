clear all
set more off
set type double

import delimited using "households.csv", clear varnames(1)
keep if recipient==0
gen dose0 = dose*(1-eligible)
gen dose1 = dose*eligible
gen base0 = baseline*(1-eligible)
gen base1 = baseline*eligible
gen inst0 = instrument*(1-eligible)
gen inst1 = instrument*eligible
gen ne0 = 1-eligible
gen ne1 = eligible

count
local n_obs = r(N)

ivregress 2sls outcome ne0 ne1 base0 base1 (dose0 dose1 = inst0 inst1 ne0 ne1 base0 base1) [aw=weight], noconstant
scalar b0 = _b[dose0]
scalar b1 = _b[dose1]

summarize dose [aw=weight] if eligible==0, meanonly
scalar m0 = r(mean)
summarize dose [aw=weight] if eligible==1, meanonly
scalar m1 = r(mean)

scalar e0 = b0*m0
scalar e1 = b1*m1

preserve
import delimited using "census.csv", clear varnames(1)
summarize nonrecipient_population if eligible==0, meanonly
scalar p0 = r(mean)
summarize nonrecipient_population if eligible==1, meanonly
scalar p1 = r(mean)
restore

scalar pop = (e0*p0 + e1*p1)/(p0+p1)

display "ANSWER: ineligible_effect estimate=" trim(string(e0,"%24.16g")) " se=NA n_obs=`n_obs'"
display "ANSWER: eligible_nonrecipient_effect estimate=" trim(string(e1,"%24.16g")) " se=NA n_obs=`n_obs'"
display "ANSWER: population_effect estimate=" trim(string(pop,"%24.16g")) " se=NA n_obs=`n_obs'"
exit, clear
