clear all
set more off
set linesize 255
import delimited using "input.csv", clear varnames(1)

gen byte inbw = abs(score) < 1
gen double w = 1 - abs(score) if inbw
gen byte right = score >= 0 if inbw

mata:
void side_fit(real scalar s, real colvector y1, real colvector y2, real colvector sc, real colvector w, real colvector ind, real rowvector out)
{
    real colvector idx, x, yy1, yy2, ww, e1, e2, b1, b2
    real matrix X, B, M11, M12, M22
    idx = selectindex((ind :== 1) :& ((sc :>= 0) :== s))
    x = sc[idx]; yy1 = y1[idx]; yy2 = y2[idx]; ww = w[idx]
    X = (J(rows(x), 1, 1), x)
    B = invsym(cross(X, ww, X))
    b1 = B * cross(X, ww, yy1)
    b2 = B * cross(X, ww, yy2)
    e1 = yy1 - X*b1
    e2 = yy2 - X*b2
    M11 = B*cross(X, ww:^2 :* e1:^2, X)*B
    M12 = B*cross(X, ww:^2 :* e1 :* e2, X)*B
    M22 = B*cross(X, ww:^2 :* e2:^2, X)*B
    out = (b1[1], b2[1], M11[1,1], M12[1,1], M22[1,1], rows(x))
}

void main()
{
    real colvector Y1, Y2, SC, W, IND
    real rowvector R, L
    real scalar rf, fs, vRf, vFs, cRF, tau, vTau
    Y1 = st_data(., "earnings"); Y2 = st_data(., "participated")
    SC = st_data(., "score"); W = st_data(., "w"); IND = st_data(., "inbw")
    W = editmissing(W, 0)
    R = J(1,6,.); L = J(1,6,.)
    side_fit(1, Y1, Y2, SC, W, IND, R)
    side_fit(0, Y1, Y2, SC, W, IND, L)
    rf = R[1] - L[1]
    fs = R[2] - L[2]
    vRf = R[3] + L[3]
    vFs = R[5] + L[5]
    cRF = R[4] + L[4]
    tau = rf / fs
    vTau = vRf/fs^2 + rf^2*vFs/fs^4 - 2*rf*cRF/fs^3
    st_numscalar("rf", rf); st_numscalar("fs", fs)
    st_numscalar("serf", sqrt(vRf)); st_numscalar("sefs", sqrt(vFs))
    st_numscalar("tau", tau); st_numscalar("setau", sqrt(vTau))
    st_numscalar("nR", R[6]); st_numscalar("nL", L[6])
}
main()
end

display "ANSWER: treatment_effect estimate=" %21.12f tau " se=" %21.12f setau " n_obs=" %12.0f (nR+nL)
display "ANSWER: reduced_form estimate=" %21.12f rf " se=" %21.12f serf " n_obs=" %12.0f (nR+nL)
display "ANSWER: first_stage estimate=" %21.12f fs " se=" %21.12f sefs " n_obs=" %12.0f (nR+nL)
