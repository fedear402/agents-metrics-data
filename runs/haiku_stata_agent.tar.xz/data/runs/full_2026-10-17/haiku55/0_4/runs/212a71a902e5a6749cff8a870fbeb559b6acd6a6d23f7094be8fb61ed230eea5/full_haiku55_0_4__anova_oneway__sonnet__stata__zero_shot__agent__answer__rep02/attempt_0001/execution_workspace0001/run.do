clear all
set more off
set linesize 255
capture log close
log using run.log, replace text

import delimited using "input.csv", clear varnames(1) case(preserve) stringcols(2)
gen double y_dbl = real(y)
drop y
rename y_dbl y

anova y group

scalar F_stat = e(F)
scalar df_num = e(df_m)
scalar df_den = e(df_r)
scalar p_val  = Ftail(df_num, df_den, F_stat)
count if !missing(y) & !missing(group)
scalar n_obs = r(N)

display "ANSWER: F estimate=" %21.12f F_stat " se=" "." " n_obs=" %12.0f n_obs
display "ANSWER: df_num estimate=" %21.12f df_num " se=" "." " n_obs=" %12.0f n_obs
display "ANSWER: df_den estimate=" %21.12f df_den " se=" "." " n_obs=" %12.0f n_obs
display "ANSWER: p_value estimate=" %21.12f p_val " se=" "." " n_obs=" %12.0f n_obs

log close
