clear all
set more off
set linesize 255
capture log close
log using run.log, replace text

import delimited "input.csv", clear

mata:
void fit_side(real colvector x, real colvector w, real matrix Y, real colvector a, real matrix S)
{
    real matrix X, B, M, E, beta
    real scalar j, k
    X = J(rows(x), 1, 1), x
    B = invsym((X')*(X :* w))
    beta = B*((X')*(Y :* w))
    E = Y - X*beta
    a = beta[1, .]'
    S = J(2, 2, 0)
    for (j = 1; j <= 2; j++) {
        for (k = 1; k <= 2; k++) {
            M = (X')*(X :* (w:^2 :* E[, j] :* E[, k]))
            S[j, k] = (B*M*B)[1, 1]
        }
    }
}

void run_rd()
{
    real colvector x, p, e, inb, rgt, lft, xr, wr, xl, wl, aR, aL, d
    real matrix Y, Yr, Yl, SR, SL, Sig
    real scalar rf, fs, tau, vtau

    x = st_data(., "score")
    p = st_data(., "participated")
    e = st_data(., "earnings")
    inb = abs(x) :< 1
    rgt = inb :& (x :>= 0)
    lft = inb :& (x :< 0)
    Y = (e, p)

    xr = select(x, rgt);  wr = 1 :- abs(xr);  Yr = select(Y, rgt)
    xl = select(x, lft);  wl = 1 :- abs(xl);  Yl = select(Y, lft)

    fit_side(xr, wr, Yr, aR, SR)
    fit_side(xl, wl, Yl, aL, SL)

    d = aR - aL
    Sig = SR + SL
    rf = d[1]
    fs = d[2]
    tau = rf/fs
    vtau = Sig[1,1]/fs^2 + rf^2*Sig[2,2]/fs^4 - 2*rf*Sig[1,2]/fs^3

    st_numscalar("rf", rf)
    st_numscalar("fs", fs)
    st_numscalar("tau", tau)
    st_numscalar("se_rf", sqrt(Sig[1,1]))
    st_numscalar("se_fs", sqrt(Sig[2,2]))
    st_numscalar("se_tau", sqrt(vtau))
    st_numscalar("nobs", sum(inb))
}
run_rd()
end

display "ANSWER: treatment_effect estimate=" %21.12f tau " se=" %21.12f se_tau " n_obs=" %12.0f nobs
display "ANSWER: reduced_form estimate=" %21.12f rf " se=" %21.12f se_rf " n_obs=" %12.0f nobs
display "ANSWER: first_stage estimate=" %21.12f fs " se=" %21.12f se_fs " n_obs=" %12.0f nobs

log close
