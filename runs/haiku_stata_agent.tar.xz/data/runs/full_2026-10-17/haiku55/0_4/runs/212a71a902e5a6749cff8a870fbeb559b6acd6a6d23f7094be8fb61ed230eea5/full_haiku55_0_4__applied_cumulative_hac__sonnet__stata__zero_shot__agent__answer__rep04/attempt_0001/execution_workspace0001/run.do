clear all
set more off
set linesize 255

import delimited using "input.csv", clear stringcols(1)
gen double dt = date(date, "YMD")
format dt %td
sort dt
gen long t = _n
tsset t

gen double lsales = ln(sales)
gen double lvix = ln(vix)
gen double dlvix = lvix - L.lvix
forvalues k = 1/15 {
    gen double dlv_l`k' = L`k'.dlvix
}

local rhs ""
forvalues k = 1/15 {
    local rhs "`rhs' dlv_l`k'"
}

regress lsales `rhs' if !missing(dlv_l15) & !missing(lsales)
local N = e(N)
display "N=" `N'

newey lsales `rhs' if !missing(dlv_l15) & !missing(lsales), lag(15)
matrix b = e(b)
* newey already applies the N/(N-16) small-sample factor (K=16 regressors)
matrix V = e(V)
local n_obs = e(N)

matrix c = J(15,1,1)
matrix cb = b[1,1..15] * c
matrix cV = c' * V[1..15,1..15] * c
local cum = cb[1,1]
local cum_se = sqrt(cV[1,1])
local l1 = b[1,1]
local l1_se = sqrt(V[1,1])
local l15 = b[1,15]
local l15_se = sqrt(V[15,15])

display "ANSWER: cumulative_response estimate=" %21.12f `cum' " se=" %21.12f `cum_se' " n_obs=" %12.0f `n_obs'
display "ANSWER: lag_1 estimate=" %21.12f `l1' " se=" %21.12f `l1_se' " n_obs=" %12.0f `n_obs'
display "ANSWER: lag_15 estimate=" %21.12f `l15' " se=" %21.12f `l15_se' " n_obs=" %12.0f `n_obs'
