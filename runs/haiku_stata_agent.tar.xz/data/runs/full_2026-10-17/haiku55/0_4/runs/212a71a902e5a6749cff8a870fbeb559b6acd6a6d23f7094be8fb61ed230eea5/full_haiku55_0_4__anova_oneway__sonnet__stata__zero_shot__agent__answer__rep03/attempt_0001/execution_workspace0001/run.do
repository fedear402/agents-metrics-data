clear all
set more off
set linesize 255
import delimited using "input.csv", clear varnames(1)
quietly anova y group
scalar F_val = e(F)
scalar dfn = e(df_m)
scalar dfd = e(df_r)
scalar p_val = Ftail(dfn, dfd, F_val)
scalar n_obs = e(N)
display "ANSWER: F estimate=" %21.12f F_val " se=. n_obs=" %12.0f n_obs
display "ANSWER: df_num estimate=" %21.12f dfn " se=. n_obs=" %12.0f n_obs
display "ANSWER: df_den estimate=" %21.12f dfd " se=. n_obs=" %12.0f n_obs
display "ANSWER: p_value estimate=" %21.12f p_val " se=. n_obs=" %12.0f n_obs
