clear all
set more off
set type double

import delimited using "households.csv", clear varnames(1)
keep if recipient==0
local n_obs = _N

gen double d0 = dose*(1-eligible)
gen double d1 = dose*eligible
gen double b0 = baseline*(1-eligible)
gen double b1 = baseline*eligible
gen double i0 = instrument*(1-eligible)
gen double i1 = instrument*eligible
gen double g0 = 1-eligible
gen double g1 = eligible

ivregress 2sls outcome g0 g1 b0 b1 (d0 d1 = i0 i1) [aw=weight], noconstant
scalar s0 = _b[d0]
scalar s1 = _b[d1]

summarize dose [aw=weight] if eligible==0, meanonly
scalar m0 = r(mean)
summarize dose [aw=weight] if eligible==1, meanonly
scalar m1 = r(mean)
scalar e0 = s0*m0
scalar e1 = s1*m1

import delimited using "census.csv", clear varnames(1)
summarize nonrecipient_population if eligible==0, meanonly
scalar n0 = r(mean)
summarize nonrecipient_population if eligible==1, meanonly
scalar n1 = r(mean)
scalar pop = (e0*n0+e1*n1)/(n0+n1)

display "ANSWER: ineligible_effect estimate=" %24.16g (e0) " se=NA n_obs=" `n_obs'
display "ANSWER: eligible_nonrecipient_effect estimate=" %24.16g (e1) " se=NA n_obs=" `n_obs'
display "ANSWER: population_effect estimate=" %24.16g (pop) " se=NA n_obs=" `n_obs'

display "CHECK slopes s0=" %24.16g (s0) " s1=" %24.16g (s1)
display "CHECK weighted_mean_dose m0=" %24.16g (m0) " m1=" %24.16g (m1)
display "CHECK census n0=" n0 " n1=" n1
exit, clear
