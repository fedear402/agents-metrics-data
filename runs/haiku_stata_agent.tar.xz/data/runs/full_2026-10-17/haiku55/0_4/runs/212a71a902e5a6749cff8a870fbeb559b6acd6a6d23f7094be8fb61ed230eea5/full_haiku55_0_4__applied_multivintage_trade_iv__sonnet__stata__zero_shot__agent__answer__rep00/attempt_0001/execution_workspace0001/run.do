clear all
set more off
set type double

import delimited using crosswalk.csv, clear stringcols(1)
tempfile cw
save `cw'

import delimited using trade.csv, clear stringcols(2)
merge m:1 code using `cw', assert(match) nogen
isid period industry
tempfile tr
save `tr'

import delimited using areas.csv, clear
isid area period vintage
tempfile ar
save `ar'

import delimited using employment.csv, clear stringcols(3)
isid area period vintage industry
tempfile em
save `em'

use `cw', clear
keep industry
duplicates drop
gen byte k = 1
tempfile ind
save `ind'

use `ar', clear
gen byte k = 1
joinby k using `ind'
drop k
merge 1:1 area period vintage industry using `em'
assert _merge != 2
replace employment = 0 if _merge == 1
drop _merge

merge m:1 period industry using `tr', assert(match) nogen

bysort period vintage industry: egen double natemp = total(employment)
assert natemp > 0

gen byte isbase = vintage == "base"
gen double trade_val = cond(isbase, us_change, other_change)
gen double term = (employment / total_employment) * (trade_val / natemp) / (price_index / 100) / 1000 * (10 / years)
gen double x_term = term if isbase
gen double z_term = term if !isbase
gen double pop_b = population if isbase

collapse (sum) x = x_term z = z_term (max) population = pop_b, by(area period)
assert _N == 72

preserve
import delimited using outcomes.csv, clear
tempfile oc
save `oc'
restore
merge 1:1 area period using `oc', assert(match) nogen
count
local n_obs = r(N)

ivregress 2sls change_pp period control (x = z) [aw = population]
local b = _b[x]

summarize x if area == 0 & period == 0, meanonly
local e0 = r(mean)
summarize x if area == 0 & period == 1, meanonly
local e1 = r(mean)
summarize z if area == 0 & period == 0, meanonly
local z0 = r(mean)

file open out using answers.txt, write replace text
foreach line in ///
  "iv_slope estimate=`: di %21.14f `b'' se=NA n_obs=`n_obs'" ///
  "exposure_area0_period0 estimate=`: di %21.14f `e0'' se=NA n_obs=`n_obs'" ///
  "exposure_area0_period1 estimate=`: di %21.14f `e1'' se=NA n_obs=`n_obs'" ///
  "instrument_area0_period0 estimate=`: di %21.14f `z0'' se=NA n_obs=`n_obs'" {
    file write out "ANSWER: `line'" _n
    display "ANSWER: `line'"
}
file close out
