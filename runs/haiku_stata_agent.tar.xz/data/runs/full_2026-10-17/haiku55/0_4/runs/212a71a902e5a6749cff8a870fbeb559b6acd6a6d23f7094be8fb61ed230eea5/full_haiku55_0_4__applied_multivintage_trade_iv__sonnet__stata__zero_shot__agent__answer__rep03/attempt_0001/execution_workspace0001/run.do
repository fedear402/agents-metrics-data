clear all
set more off
set type double

import delimited using "crosswalk.csv", clear stringcols(_all)
destring industry, replace
tempfile cw
save `cw'

import delimited using "trade.csv", clear stringcols(2)
merge m:1 code using `cw', keep(match) nogen
tempfile tr
save `tr'

import delimited using "areas.csv", clear
tempfile ar
save `ar'

import delimited using "employment.csv", clear
tempfile em
save `em'

import delimited using "outcomes.csv", clear
tempfile oc
save `oc'

* full area x period x vintage x industry grid with zero-filled employment
use `ar', clear
expand 4
bysort area period vintage: gen industry = _n - 1
merge 1:1 area period vintage industry using `em', nogen
replace employment = 0 if missing(employment)
merge m:1 period industry using `tr', keep(match master) nogen
bysort period vintage industry: egen double nat = total(employment)
assert nat > 0
gen double tb = employment/total_employment * us_change/nat /(price_index/100)/1000*(10/years) if vintage=="base"
gen double te = employment/total_employment * other_change/nat /(price_index/100)/1000*(10/years) if vintage=="early"

preserve
keep if vintage=="base"
collapse (sum) x=tb (first) population, by(area period)
tempfile xb
save `xb'
restore

preserve
keep if vintage=="early"
collapse (sum) z=te, by(area period)
tempfile ze
save `ze'
restore

use `xb', clear
merge 1:1 area period using `ze', assert(match) nogen
merge 1:1 area period using `oc', assert(match) nogen
sort area period
gen byte per = period
gen double w = population
count
local n = r(N)
assert `n' == 72

mata:
y = st_data(., "change_pp")
X = st_data(., ("per", "control", "x"))
Z = st_data(., ("per", "control", "z"))
X = (J(rows(X),1,1), X)
Z = (J(rows(Z),1,1), Z)
w = st_data(., "w")
W = diag(w)
Pz = Z*invsym(Z'*W*Z)*Z'*W
b = invsym(X'*W*Pz*X)*X'*W*Pz*y
st_numscalar("iv_slope", b[4])
end

display "mata iv_slope = " %18.12f iv_slope
ivregress 2sls change_pp per control (x = z) [aw=w]
display "ivregress x = " %18.12f _b[x]
local ivb = _b[x]
display "difference = " %18.12e (iv_slope - `ivb')

summarize x if area==0 & period==0, meanonly
scalar e00 = r(mean)
summarize x if area==0 & period==1, meanonly
scalar e01 = r(mean)
summarize z if area==0 & period==0, meanonly
scalar z00 = r(mean)

file open out using "output.txt", write replace text
file write out "ANSWER: iv_slope estimate=" (strtrim(string(iv_slope,"%20.12f"))) " se=NA n_obs=" (strtrim(string(`n',"%5.0f"))) _n
file write out "ANSWER: exposure_area0_period0 estimate=" (strtrim(string(e00,"%20.12f"))) " se=NA n_obs=" (strtrim(string(`n',"%5.0f"))) _n
file write out "ANSWER: exposure_area0_period1 estimate=" (strtrim(string(e01,"%20.12f"))) " se=NA n_obs=" (strtrim(string(`n',"%5.0f"))) _n
file write out "ANSWER: instrument_area0_period0 estimate=" (strtrim(string(z00,"%20.12f"))) " se=NA n_obs=" (strtrim(string(`n',"%5.0f"))) _n
file close out
type output.txt
