version 19.0
clear all
set more off
import delimited using "input.csv", clear stringcols(1)
generate double day = date(date, "YMD")
sort day
generate long obs = _n
tsset obs
generate double lnvix = ln(vix)
generate double dlnvix = D.lnvix
generate double lnsales = ln(sales)
forvalues k = 1/15 {
    generate double lag_`k' = L`k'.dlnvix
}
egen double nmiss = rowmiss(lag_1-lag_15)
newey lnsales L(1/15).dlnvix if nmiss == 0, lag(15)
matrix b = e(b)
matrix V = e(V)
matrix c = J(16,1,1)
matrix c[16,1]=0
matrix cv = c'*V*c
matrix bc = b*c
display "CHECK N=" e(N)
display "CHECK cum=" %21.12f bc[1,1] " se=" %21.12f sqrt(cv[1,1])
display "CHECK lag1=" %21.12f b[1,1] " se=" %21.12f sqrt(V[1,1])
display "CHECK lag15=" %21.12f b[1,15] " se=" %21.12f sqrt(V[15,15])
