clear all
set more off

tempfile cw tr ar em oc pop

import delimited using "crosswalk.csv", clear stringcols(1)
save `cw'

import delimited using "trade.csv", clear stringcols(2)
merge m:1 code using `cw', assert(match) nogen
isid period industry
keep period industry us_change other_change price_index years
save `tr'

import delimited using "areas.csv", clear stringcols(3)
isid area period vintage
save `ar'
keep if vintage == "base"
keep area period population
save `pop'

import delimited using "employment.csv", clear stringcols(3)
isid area period vintage industry
save `em'

import delimited using "outcomes.csv", clear stringcols(_all)
foreach v in control change_pp {
    gen double `v'_d = real(`v')
    drop `v'
    rename `v'_d `v'
}
destring area period, replace
isid area period
save `oc'

use `ar', clear
expand 4
bysort area period vintage: gen industry = _n - 1
merge 1:1 area period vintage industry using `em', keep(master match) nogen
replace employment = 0 if missing(employment)
merge m:1 period industry using `tr', assert(match) nogen

bysort period vintage industry: egen double natl = total(employment)
assert natl > 0

gen double xt = 0
replace xt = (employment/total_employment) * (us_change/natl) / (price_index/100) / 1000 * (10/years) if vintage == "base"
gen double zt = 0
replace zt = (employment/total_employment) * (other_change/natl) / (price_index/100) / 1000 * (10/years) if vintage == "early"

collapse (sum) x = xt z = zt, by(area period)
merge 1:1 area period using `oc', assert(match) nogen
merge 1:1 area period using `pop', assert(match) nogen
isid area period
count
assert r(N) == 72

ivregress 2sls change_pp period control (x = z) [aw = population]
scalar b_x = _b[x]
scalar nobs = e(N)

quietly summarize x if area == 0 & period == 0, meanonly
scalar ex00 = r(mean)
quietly summarize x if area == 0 & period == 1, meanonly
scalar ex01 = r(mean)
quietly summarize z if area == 0 & period == 0, meanonly
scalar iz00 = r(mean)

di "ANSWER: iv_slope estimate=" trim(string(b_x, "%20.12f")) " se=NA n_obs=" trim(string(nobs, "%12.0f"))
di "ANSWER: exposure_area0_period0 estimate=" trim(string(ex00, "%20.12f")) " se=NA n_obs=" trim(string(nobs, "%12.0f"))
di "ANSWER: exposure_area0_period1 estimate=" trim(string(ex01, "%20.12f")) " se=NA n_obs=" trim(string(nobs, "%12.0f"))
di "ANSWER: instrument_area0_period0 estimate=" trim(string(iz00, "%20.12f")) " se=NA n_obs=" trim(string(nobs, "%12.0f"))
