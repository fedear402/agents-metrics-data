version 19.0
clear all
set more off
set linesize 255

import delimited using "input.csv", clear varnames(1) case(preserve)
keep if abs(score) < 1
gen double w = 1 - abs(score)
gen double D = (score >= 0)

mata:
s = st_data(., "score")
w = st_data(., "w")
D = st_data(., "D")
Y = st_data(., ("earnings", "participated"))
n = rows(s)
X = (1:-D, D, s:*(1:-D), s:*D)
bread = invsym(X' * (w:*X))
b = bread * X' * (w:*Y)
E = Y - X*b
c = (-1\1\0\0)
disc = c' * b
loading = w:*(X*bread*c)
infl = loading:*E
V = infl' * infl
grad = (1/disc[2] \ -disc[1]/disc[2]^2)
ratio = disc[1]/disc[2]
ratio_se = sqrt(grad' * V * grad)
st_numscalar("rf", disc[1])
st_numscalar("fs", disc[2])
st_numscalar("rf_se", sqrt(V[1,1]))
st_numscalar("fs_se", sqrt(V[2,2]))
st_numscalar("tau", ratio)
st_numscalar("tau_se", ratio_se)
st_numscalar("n_obs", n)
end

display "ANSWER: treatment_effect estimate=" %21.15f tau " se=" %21.15f tau_se " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.15f rf " se=" %21.15f rf_se " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.15f fs " se=" %21.15f fs_se " n_obs=" %12.0f n_obs
