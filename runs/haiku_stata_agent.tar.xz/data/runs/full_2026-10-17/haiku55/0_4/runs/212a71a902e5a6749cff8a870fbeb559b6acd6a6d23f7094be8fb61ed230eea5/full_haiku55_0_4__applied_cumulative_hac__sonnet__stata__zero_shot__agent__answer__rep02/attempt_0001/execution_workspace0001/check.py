import numpy as np, pandas as pd
df = pd.read_csv("input.csv")
df["date"] = pd.to_datetime(df["date"])
df = df.sort_values("date").reset_index(drop=True)
dv = np.diff(np.log(df["vix"].values))  # dv[k] = dlog vix at obs k+1
y_all = np.log(df["sales"].values)
T = len(df)
rows = []
for t in range(T):
    lags = [dv[t-2-j] if t-2-j >= 0 else np.nan for j in range(15)]  # lag j+1 at obs t = dlog vix at obs t-j-1
    if not np.isnan(lags).any():
        rows.append((t, y_all[t], lags))
ys = np.array([r[1] for r in rows])
X = np.column_stack([np.ones(len(rows))] + [np.array([r[2][j] for r in rows]) for j in range(15)])
N, k = X.shape
XtX_inv = np.linalg.inv(X.T @ X)
b = XtX_inv @ X.T @ ys
u = ys - X @ b
# Newey-West, lag 15, Bartlett weights
S = (X * u[:, None]).T @ (X * u[:, None])
for j in range(1, 16):
    w = 1 - j / 16
    G = (X[j:] * u[j:, None]).T @ (X[:-j] * u[:-j, None])
    S += w * (G + G.T)
V = XtX_inv @ S @ XtX_inv * N / (N - 16)
c = np.zeros(k); c[1:16] = 1
print("N", N)
print("cumulative", c @ b, np.sqrt(c @ V @ c))
print("lag_1", b[1], np.sqrt(V[1, 1]))
print("lag_15", b[15], np.sqrt(V[15, 15]))
