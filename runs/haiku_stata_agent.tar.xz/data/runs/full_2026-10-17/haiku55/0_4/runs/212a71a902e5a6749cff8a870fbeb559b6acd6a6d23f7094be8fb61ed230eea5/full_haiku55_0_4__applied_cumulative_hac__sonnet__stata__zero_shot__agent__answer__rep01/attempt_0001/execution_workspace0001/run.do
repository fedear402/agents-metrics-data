clear all
set more off
set linesize 255
import delimited using "./input.csv", clear varnames(1) stringcols(1)
gen double dt = daily(date, "YMD")
format dt %td
sort dt
gen double lnsales = ln(sales)
gen double lnvix = ln(vix)
gen double dlv = lnvix - lnvix[_n-1] if _n > 1
gen long t = _n
tsset t
forvalues k = 1/15 {
    gen double lag`k' = L`k'.dlv
}
egen double nmiss = rowmiss(lnsales lag1-lag15)
keep if nmiss == 0
newey lnsales lag1-lag15, lag(15)
* newey's e(V) already applies N/(N-K) with K=16, the required scaling
matrix b = e(b)
matrix V = e(V)
local nobs = e(N)
scalar cum_est = 0
matrix cvec = J(16,1,0)
forvalues k = 1/15 {
    scalar cum_est = cum_est + b[1,`k']
    matrix cvec[`k',1] = 1
}
matrix cv = cvec' * V * cvec
scalar cum_se = sqrt(cv[1,1])
scalar lag1_est = b[1,1]
scalar lag1_se = sqrt(V[1,1])
scalar lag15_est = b[1,15]
scalar lag15_se = sqrt(V[15,15])
display "ANSWER: cumulative_response estimate=" %21.12f cum_est " se=" %21.12f cum_se " n_obs=" %12.0f `nobs'
display "ANSWER: lag_1 estimate=" %21.12f lag1_est " se=" %21.12f lag1_se " n_obs=" %12.0f `nobs'
display "ANSWER: lag_15 estimate=" %21.12f lag15_est " se=" %21.12f lag15_se " n_obs=" %12.0f `nobs'
