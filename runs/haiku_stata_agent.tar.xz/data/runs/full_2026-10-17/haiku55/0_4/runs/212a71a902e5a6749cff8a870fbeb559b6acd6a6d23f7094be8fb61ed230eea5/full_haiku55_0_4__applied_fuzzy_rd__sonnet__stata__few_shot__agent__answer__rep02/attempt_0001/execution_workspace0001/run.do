version 19.0
clear all
set more off
set linesize 255

import delimited using "input.csv", clear varnames(1)
keep if abs(score)<1
gen double w = 1-abs(score)
gen double right = (score>=0)

mata:
w = st_data(.,"w")
s = st_data(.,"score")
r = st_data(.,"right")
X = (J(rows(s),1,1), r, s:*(1:-r), s:*r)
Y = st_data(.,("earnings","participated"))
n = rows(X)
bread = invsym(X'*(w:*X))
B = bread*X'*(w:*Y)
E = Y - X*B
c = (0\1\0\0)
jumps = c'*B
loading = w:*(X*bread*c)
infl = loading:*E
V = infl'*infl
grad = (1/jumps[2] \ -jumps[1]/jumps[2]^2)
st_numscalar("rf", jumps[1])
st_numscalar("fs", jumps[2])
st_numscalar("rf_se", sqrt(V[1,1]))
st_numscalar("fs_se", sqrt(V[2,2]))
st_numscalar("te", jumps[1]/jumps[2])
st_numscalar("te_se", sqrt(grad'*V*grad))
st_numscalar("nobs", n)
end

display "ANSWER: treatment_effect estimate=" %21.12f te " se=" %21.12f te_se " n_obs=" %12.0f nobs
display "ANSWER: reduced_form estimate=" %21.12f rf " se=" %21.12f rf_se " n_obs=" %12.0f nobs
display "ANSWER: first_stage estimate=" %21.12f fs " se=" %21.12f fs_se " n_obs=" %12.0f nobs
