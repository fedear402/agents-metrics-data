clear all
set more off
import delimited using "households.csv", clear varnames(1)
keep if recipient==0
gen ne0 = 1-eligible
gen ne1 = eligible
gen d0 = dose*(1-eligible)
gen d1 = dose*eligible
gen b0 = baseline*(1-eligible)
gen b1 = baseline*eligible
gen z0 = instrument*(1-eligible)
gen z1 = instrument*eligible
count
scalar nobs = r(N)
ivregress 2sls outcome ne0 ne1 b0 b1 (d0 d1 = z0 z1) [aweight=weight], noconstant
scalar bb0 = _b[d0]
scalar bb1 = _b[d1]
quietly summarize dose [aweight=weight] if eligible==0
scalar mm0 = r(mean)
quietly summarize dose [aweight=weight] if eligible==1
scalar mm1 = r(mean)
scalar ine = bb0*mm0
scalar ele = bb1*mm1
import delimited using "census.csv", clear varnames(1)
quietly summarize nonrecipient_population if eligible==0
scalar pp0 = r(mean)
quietly summarize nonrecipient_population if eligible==1
scalar pp1 = r(mean)
scalar pop = (pp0*ine + pp1*ele)/(pp0+pp1)
display "ANSWER: ineligible_effect estimate=" %16.12f ine " se=NA n_obs=" %1.0f nobs
display "ANSWER: eligible_nonrecipient_effect estimate=" %16.12f ele " se=NA n_obs=" %1.0f nobs
display "ANSWER: population_effect estimate=" %16.12f pop " se=NA n_obs=" %1.0f nobs
