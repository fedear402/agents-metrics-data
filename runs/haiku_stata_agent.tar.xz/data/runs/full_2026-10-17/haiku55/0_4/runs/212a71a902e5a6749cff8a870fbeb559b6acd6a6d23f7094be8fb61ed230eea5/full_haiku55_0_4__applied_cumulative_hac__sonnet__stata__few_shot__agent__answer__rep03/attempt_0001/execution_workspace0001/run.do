version 19.0
clear all
set more off
set linesize 255

import delimited using "input.csv", clear varnames(1) stringcols(1)
generate double dt = date(date, "YMD")
assert !missing(dt)
isid dt
sort dt
assert sales > 0 & vix > 0 & !missing(sales) & !missing(vix)
generate long tindex = _n
tsset tindex

generate double log_sales = ln(sales)
generate double log_vix = ln(vix)
generate double dlog_vix = D.log_vix
local lagvars ""
forvalues k = 1/15 {
    generate double lag`k' = L`k'.dlog_vix
    local lagvars "`lagvars' lag`k'"
}

egen long nmiss = rowmiss(log_sales lag1-lag15)
keep if nmiss == 0
drop nmiss

mata:
y = st_data(., "log_sales")
X = (J(rows(y), 1, 1), st_data(., "`lagvars'"))
N = rows(X)
p = cols(X)
b = qrsolve(X, y)
e = y - X*b
S = X :* e
L = 15
meat = S'*S
for (j = 1; j <= L; j++) {
    Gj = S[|j+1,1 \ N,p|]'*S[|1,1 \ N-j,p|]
    meat = meat + (1 - j/(L+1)) * (Gj + Gj')
}
bread = invsym(X'*X)
V = N/(N-p) * bread * meat * bread
c = J(p,1,0)
c[2..p] = J(15,1,1)
cum = c'*b
cum_se = sqrt(c'*V*c)
st_numscalar("r_cum", cum)
st_numscalar("r_cum_se", cum_se)
st_numscalar("r_lag1", b[2])
st_numscalar("r_lag1_se", sqrt(V[2,2]))
st_numscalar("r_lag15", b[16])
st_numscalar("r_lag15_se", sqrt(V[16,16]))
st_numscalar("r_N", N)
end

display "ANSWER: cumulative_response estimate=" %21.12f r_cum " se=" %21.12f r_cum_se " n_obs=" %12.0f r_N
display "ANSWER: lag_1 estimate=" %21.12f r_lag1 " se=" %21.12f r_lag1_se " n_obs=" %12.0f r_N
display "ANSWER: lag_15 estimate=" %21.12f r_lag15 " se=" %21.12f r_lag15_se " n_obs=" %12.0f r_N
