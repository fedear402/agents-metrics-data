clear all
set linesize 255
import delimited using "input.csv", clear varnames(1)
anova y group
local F = e(F)
local df_num = e(df_m)
local df_den = e(df_r)
local p = Ftail(`df_num', `df_den', `F')
local n = e(N)
local Fs = string(`F', "%21.12f")
local dns = string(`df_num', "%21.12f")
local dds = string(`df_den', "%21.12f")
local ps = string(`p', "%21.12f")
local ns = string(`n', "%12.0f")
display "ANSWER: F estimate=`Fs' se=. n_obs=`ns'"
display "ANSWER: df_num estimate=`dns' se=. n_obs=`ns'"
display "ANSWER: df_den estimate=`dds' se=. n_obs=`ns'"
display "ANSWER: p_value estimate=`ps' se=. n_obs=`ns'"
