import numpy as np, pandas as pd
d = pd.read_csv("input.csv")
regs = d.groupby("region_id").first().reset_index()
e = regs.region_weight.values / regs.region_weight.sum()
# regional z from raw data
z = d.assign(p=d.share*d.shock).groupby("region_id").p.sum().loc[regs.region_id].values
x = regs.x.values; y = regs.y.values
def dm(v): return v - np.sum(e*v)
y0, x0, z0 = dm(y), dm(x), dm(z)
beta_reg = np.sum(e*z0*y0)/np.sum(e*z0*x0)
fs_reg = np.sum(e*z0*x0)/np.sum(e*z0*z0)
# industry aggregation from raw rows
d = d.assign(e=d.region_id.map(dict(zip(regs.region_id, e))))
d["y0"] = d.region_id.map(dict(zip(regs.region_id, y0)))
d["x0"] = d.region_id.map(dict(zip(regs.region_id, x0)))
d["z0"] = d.region_id.map(dict(zip(regs.region_id, z0)))
d["ew"] = d.e*d.share
g = d.groupby("industry_id")
s = g.ew.sum()
ind = pd.DataFrame({"s": s})
for v in ["y0","x0","z0"]:
    ind[v] = g.apply(lambda t: np.sum(t.ew*t[v])/t.ew.sum())
ind["shock"] = g.shock.first()
N = len(ind)
w = ind.s.values; Z = np.column_stack([np.ones(N), ind.shock.values])
def iv(yv, xv, zv):
    X = np.column_stack([np.ones(N), xv]); Zm = np.column_stack([np.ones(N), zv])
    A = Zm.T @ (w[:,None]*X); Ainv = np.linalg.inv(A)
    b = Ainv @ (Zm.T @ (w*yv)); u = yv - X@b
    S = Zm*(w*u)[:,None]
    V = N/(N-2)*Ainv@(S.T@S)@Ainv.T
    return b[1], np.sqrt(V[1,1])
b_eff, se_eff = iv(ind.y0.values, ind.x0.values, ind.shock.values)
b_fs, se_fs = iv(ind.x0.values, ind.z0.values, ind.shock.values)
print(f"numpy effect {b_eff:.12f} se {se_eff:.12f} vs regional 2SLS {beta_reg:.12f}")
print(f"numpy first_stage {fs_reg:.12f} se {se_fs:.12f}")
print(f"numpy effective_shocks {1/np.sum(w**2):.12f}")
print(f"sum s {w.sum():.12f} N {N}")
