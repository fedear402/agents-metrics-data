import numpy as np, csv
rows = list(csv.DictReader(open("input.csv")))
s = np.array([float(r["score"]) for r in rows])
y = np.array([float(r["earnings"]) for r in rows])
d = np.array([float(r["participated"]) for r in rows])
m = np.abs(s) < 1
s, y, d = s[m], y[m], d[m]
w = 1 - np.abs(s)
n = len(s)

def side(mask):
    x = s[mask]; ww = w[mask]
    X = np.column_stack([np.ones(len(x)), x])
    W = np.diag(ww)
    bread = np.linalg.inv(X.T @ W @ X)
    out = {}
    B = {}
    for name, v in [("y", y[mask]), ("d", d[mask])]:
        b = bread @ X.T @ W @ v
        B[name] = (b, v - X @ b)
    # Full sandwich: Var(beta) = bread * sum_i (w_i x_i)(w_i x_i)' u_i^2 * bread
    def cov(a, b):
        ua = B[a][1]; ub = B[b][1]
        meat = (X * (ww**2 * ua * ub)[:, None]).T @ X
        return (bread @ meat @ bread)[0, 0]
    return B["y"][0][0], B["d"][0][0], cov("y", "y"), cov("d", "d"), cov("y", "d")

R = side(s >= 0)
L = side(s < 0)
rf = R[0] - L[0]; fs = R[1] - L[1]
vrf = R[2] + L[2]; vfs = R[3] + L[3]; cfr = R[4] + L[4]
te = rf / fs
# delta gradient of rf/fs wrt (rf, fs)
g = np.array([1/fs, -rf/fs**2])
V = np.array([[vrf, cfr], [cfr, vfs]])
se_te = np.sqrt(g @ V @ g)
print(f"n={n} rf={rf:.12f} se_rf={np.sqrt(vrf):.12f}")
print(f"fs={fs:.12f} se_fs={np.sqrt(vfs):.12f}")
print(f"te={te:.12f} se_te={se_te:.12f}")
