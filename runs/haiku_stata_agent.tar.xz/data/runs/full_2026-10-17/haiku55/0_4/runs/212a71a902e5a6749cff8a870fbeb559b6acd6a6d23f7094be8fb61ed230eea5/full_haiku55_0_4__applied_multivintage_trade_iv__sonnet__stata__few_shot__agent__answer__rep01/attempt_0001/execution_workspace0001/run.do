clear all
set more off
set type double

import delimited using "crosswalk.csv", clear stringcols(1)
tempfile cw1
save `cw1'
import delimited using "input.csv", clear stringcols(1)
append using `cw1'
duplicates drop
isid code
tempfile cw
save `cw'

import delimited using "trade.csv", clear stringcols(2)
merge m:1 code using `cw', assert(match) nogen
isid period code
keep period code industry us_change other_change price_index years
tempfile tr
save `tr'

import delimited using "areas.csv", clear
isid area period vintage
tempfile ar
save `ar'

import delimited using "employment.csv", clear stringcols(3)
replace employment = 0 if missing(employment)
isid area period vintage industry
tempfile em
save `em'

use `ar', clear
expand 4
bysort area period vintage: gen industry = _n - 1
merge 1:1 area period vintage industry using `em', assert(match master) nogen
replace employment = 0 if missing(employment)
merge m:1 period industry using `tr', assert(match) nogen

bysort period vintage industry: egen double nat = total(employment)
gen double share = employment / total_employment
gen double xt = .
replace xt = share * us_change / nat / (price_index/100) / 1000 * (10/years) if vintage == "base"
gen double zt = .
replace zt = share * other_change / nat / (price_index/100) / 1000 * (10/years) if vintage == "early"
collapse (sum) x=xt z=zt, by(area period)

tempfile ex
save `ex'
import delimited using "outcomes.csv", clear
isid area period
merge 1:1 area period using `ex', assert(match) nogen
tempfile full
save `full'

use `ar', clear
keep if vintage == "base"
keep area period population
merge 1:1 area period using `full', assert(match) nogen

ivregress 2sls change_pp period control (x = z) [aw=population]
local n = e(N)
display "ANSWER: iv_slope estimate=" strtrim(string(_b[x], "%24.16g")) " se=NA n_obs=`n'"
sum x if area == 0 & period == 0, meanonly
display "ANSWER: exposure_area0_period0 estimate=" strtrim(string(r(mean), "%24.16g")) " se=NA n_obs=`n'"
sum x if area == 0 & period == 1, meanonly
display "ANSWER: exposure_area0_period1 estimate=" strtrim(string(r(mean), "%24.16g")) " se=NA n_obs=`n'"
sum z if area == 0 & period == 0, meanonly
display "ANSWER: instrument_area0_period0 estimate=" strtrim(string(r(mean), "%24.16g")) " se=NA n_obs=`n'"
exit, clear
