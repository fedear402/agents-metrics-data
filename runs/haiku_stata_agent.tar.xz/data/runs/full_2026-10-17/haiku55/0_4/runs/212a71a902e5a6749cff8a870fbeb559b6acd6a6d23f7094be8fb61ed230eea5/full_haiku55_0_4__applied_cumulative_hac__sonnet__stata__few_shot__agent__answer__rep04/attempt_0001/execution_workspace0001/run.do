version 19.0
clear all
set more off
set linesize 255

import delimited using "input.csv", clear stringcols(1)
generate double day = date(date, "YMD")
assert !missing(day)
sort day
assert _N == 720
generate long obs = _n
tsset obs

generate double lnvix = ln(vix)
generate double dlnvix = D.lnvix
generate double lnsales = ln(sales)

local lagvars ""
forvalues k = 1/15 {
    generate double lag_`k' = L`k'.dlnvix
    local lagvars "`lagvars' lag_`k'"
}

egen double nmiss = rowmiss(`lagvars')
keep if nmiss == 0 & !missing(lnsales)
drop nmiss

mata:
y = st_data(., "lnsales")
X = (J(rows(y), 1, 1), st_data(., tokens("`lagvars'")))
N = rows(X)
k = cols(X)
L = 15

b = qrsolve(X, y)
e = y - X*b
S = X:*e
meat = S'*S
for (j = 1; j <= L; j++) {
    G = S[|j+1, 1 \ N, k|]' * S[|1, 1 \ N-j, k|]
    meat = meat + (1 - j/(L+1)) * (G + G')
}
bread = invsym(X'*X)
V = N/(N-k) * bread * meat * bread

c = (0 \ J(15, 1, 1))
cum = c' * b
cum_se = sqrt(c' * V * c)

st_numscalar("cum", cum)
st_numscalar("cum_se", cum_se)
st_numscalar("lag1", b[2])
st_numscalar("lag1_se", sqrt(V[2,2]))
st_numscalar("lag15", b[16])
st_numscalar("lag15_se", sqrt(V[16,16]))
st_numscalar("N", N)
end

display "ANSWER: cumulative_response estimate=" %21.12f cum " se=" %21.12f cum_se " n_obs=" %12.0f N
display "ANSWER: lag_1 estimate=" %21.12f lag1 " se=" %21.12f lag1_se " n_obs=" %12.0f N
display "ANSWER: lag_15 estimate=" %21.12f lag15 " se=" %21.12f lag15_se " n_obs=" %12.0f N
