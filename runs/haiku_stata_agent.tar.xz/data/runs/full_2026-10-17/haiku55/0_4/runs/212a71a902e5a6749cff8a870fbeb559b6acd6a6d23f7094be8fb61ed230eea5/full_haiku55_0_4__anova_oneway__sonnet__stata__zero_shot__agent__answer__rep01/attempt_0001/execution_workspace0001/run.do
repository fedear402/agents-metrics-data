clear all
set more off
set linesize 255

import delimited using "./input.csv", clear varnames(1) case(lower)
drop if missing(y) | missing(group)

quietly anova y group
scalar F_val = e(F)
scalar df_num_val = e(df_m)
scalar df_den_val = e(df_r)
scalar p_val = Ftail(df_num_val, df_den_val, F_val)
quietly count
scalar n_val = r(N)

display "ANSWER: F estimate=" %21.12f F_val " se=" "." " n_obs=" %12.0f n_val
display "ANSWER: df_num estimate=" %21.12f df_num_val " se=" "." " n_obs=" %12.0f n_val
display "ANSWER: df_den estimate=" %21.12f df_den_val " se=" "." " n_obs=" %12.0f n_val
display "ANSWER: p_value estimate=" %21.12f p_val " se=" "." " n_obs=" %12.0f n_val

* Independent check: F from group and total sums of squares
quietly summarize y
scalar grand = r(mean)
scalar N = r(N)
scalar sst = r(Var)*(N-1)
quietly levelsof group, local(gl)
scalar ssb = 0
scalar k = 0
foreach g of local gl {
    quietly summarize y if group==`g'
    scalar ssb = ssb + r(N)*(r(mean)-grand)^2
    scalar k = k + 1
}
scalar ssw = sst - ssb
scalar F_check = (ssb/(k-1))/(ssw/(N-k))
display "CHECK: F_manual=" %21.12f F_check " groups=" %6.0f k " N=" %6.0f N
