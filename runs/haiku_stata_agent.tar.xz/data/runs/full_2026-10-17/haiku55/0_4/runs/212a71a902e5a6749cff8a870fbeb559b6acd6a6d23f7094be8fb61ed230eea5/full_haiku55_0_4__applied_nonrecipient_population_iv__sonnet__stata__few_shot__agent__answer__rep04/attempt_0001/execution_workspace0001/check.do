clear all
set more off
set type double
import delimited using "households.csv", clear varnames(1)
keep if recipient==0
gen double d0 = dose*(1-eligible)
gen double d1 = dose*eligible
gen double x0 = 1-eligible
gen double x1 = eligible
gen double b0 = baseline*(1-eligible)
gen double b1 = baseline*eligible
gen double z0 = instrument*(1-eligible)
gen double z1 = instrument*eligible
mata:
y = st_data(., "outcome"); w = st_data(., "weight")
X = st_data(., ("d0","d1","x0","x1","b0","b1"))
Z = st_data(., ("z0","z1","x0","x1","b0","b1"))
A = invsym(cross(Z, w, Z))
G = cross(X, w, Z) * A
beta = invsym(G * cross(Z, w, X)) * G * cross(Z, w, y)
printf("MATA beta1 %21.16g\n", beta[1])
printf("MATA beta2 %21.16g\n", beta[2])
dose = st_data(., "dose"); el = st_data(., "eligible")
wm0 = sum(w:*(el:==0):*dose)/sum(w:*(el:==0))
wm1 = sum(w:*(el:==1):*dose)/sum(w:*(el:==1))
e0 = beta[1]*wm0
e1 = beta[2]*wm1
printf("MATA e0 %21.16g\n", e0)
printf("MATA e1 %21.16g\n", e1)
printf("MATA pop %21.16g\n", (e0*8400+e1*1600)/10000)
end
