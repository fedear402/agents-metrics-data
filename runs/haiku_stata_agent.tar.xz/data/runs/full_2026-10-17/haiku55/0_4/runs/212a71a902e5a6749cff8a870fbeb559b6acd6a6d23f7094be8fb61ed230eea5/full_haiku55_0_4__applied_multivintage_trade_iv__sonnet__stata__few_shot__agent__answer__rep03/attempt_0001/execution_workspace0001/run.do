clear all
set more off
set type double

import delimited using crosswalk.csv, clear stringcols(1)
tempfile cw1
save `cw1'
import delimited using input.csv, clear stringcols(1)
append using `cw1'
duplicates drop
tempfile cw
save `cw'

import delimited using trade.csv, clear stringcols(2)
merge m:1 code using `cw', assert(match) nogen
tempfile tr
save `tr'

import delimited using areas.csv, clear stringcols(3)
tempfile ar
save `ar'
sort area period vintage
expand 4
bysort area period vintage: gen byte industry = _n - 1
tempfile grid
save `grid'

import delimited using employment.csv, clear stringcols(3)
merge 1:1 area period vintage industry using `grid', assert(match master using) nogen
replace employment = 0 if missing(employment)
merge m:1 period industry using `tr', assert(match) nogen

bysort period vintage industry: egen double national = total(employment)
gen double tx = (employment/total_employment)*(us_change/national)/(price_index/100)/1000*(10/years) if vintage == "base"
gen double tz = (employment/total_employment)*(other_change/national)/(price_index/100)/1000*(10/years) if vintage == "early"

collapse (sum) x = tx z = tz, by(area period)
tempfile expo
save `expo'

import delimited using areas.csv, clear stringcols(3)
keep if vintage == "base"
keep area period population
merge 1:1 area period using `expo', assert(match) nogen
tempfile full
save `full'

import delimited using outcomes.csv, clear
merge 1:1 area period using `full', assert(match) nogen
sort area period
count
local nobs = r(N)

ivregress 2sls change_pp period control (x = z) [aw=population]
local b = _b[x]
local n = e(N)
summarize x if area == 0 & period == 0, meanonly
local x00 = r(mean)
summarize x if area == 0 & period == 1, meanonly
local x01 = r(mean)
summarize z if area == 0 & period == 0, meanonly
local z00 = r(mean)

display "ANSWER: iv_slope estimate=" trim(string(`b', "%24.16g")) " se=NA n_obs=" `n'
display "ANSWER: exposure_area0_period0 estimate=" trim(string(`x00', "%24.16g")) " se=NA n_obs=" `n'
display "ANSWER: exposure_area0_period1 estimate=" trim(string(`x01', "%24.16g")) " se=NA n_obs=" `n'
display "ANSWER: instrument_area0_period0 estimate=" trim(string(`z00', "%24.16g")) " se=NA n_obs=" `n'
