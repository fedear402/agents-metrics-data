clear all
set more off
set type double

import delimited using "crosswalk.csv", clear
tempfile cw
save `cw'

import delimited using "trade.csv", clear
merge m:1 code using `cw', assert(match) nogen
keep period industry us_change other_change price_index years
tempfile tr
save `tr'

import delimited using "outcomes.csv", clear
tempfile oc
save `oc'

import delimited using "employment.csv", clear
tempfile emp
save `emp'

import delimited using "areas.csv", clear
expand 4
bysort area period vintage: gen int industry = _n - 1
merge 1:1 area period vintage industry using `emp', nogen
replace employment = 0 if missing(employment)
merge m:1 period industry using `tr', assert(match) nogen

bysort period industry vintage: egen double nat = total(employment)
gen double xc = employment/total_employment*(us_change/nat)/(price_index/100)/1000*(10/years) if vintage=="base"
gen double zc = employment/total_employment*(other_change/nat)/(price_index/100)/1000*(10/years) if vintage=="early"
gen double pop = population if vintage=="base"

collapse (sum) x=xc z=zc pop (count) nrows=employment, by(area period)
assert nrows == 8
merge 1:1 area period using `oc', assert(match) nogen
assert _N == 72

ivregress 2sls change_pp period control (x = z) [aw=pop]
local n = e(N)
local b = _b[x]
summarize x if area==0 & period==0, meanonly
local ex0 = r(mean)
summarize x if area==0 & period==1, meanonly
local ex1 = r(mean)
summarize z if area==0 & period==0, meanonly
local iz0 = r(mean)

display "ANSWER: iv_slope estimate=" %24.16g `b' " se=NA n_obs=" %12.0f `n'
display "ANSWER: exposure_area0_period0 estimate=" %24.16g `ex0' " se=NA n_obs=" %12.0f `n'
display "ANSWER: exposure_area0_period1 estimate=" %24.16g `ex1' " se=NA n_obs=" %12.0f `n'
display "ANSWER: instrument_area0_period0 estimate=" %24.16g `iz0' " se=NA n_obs=" %12.0f `n'
exit, clear
