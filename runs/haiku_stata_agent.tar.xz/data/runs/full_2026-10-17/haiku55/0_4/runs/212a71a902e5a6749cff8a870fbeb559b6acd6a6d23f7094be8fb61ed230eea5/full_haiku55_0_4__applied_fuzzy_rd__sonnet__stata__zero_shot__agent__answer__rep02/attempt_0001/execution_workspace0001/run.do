clear all
set more off
set linesize 255

import delimited using "input.csv", clear varnames(1)

keep if abs(score) < 1
gen double w = 1 - abs(score)
quietly count
scalar n_obs = r(N)

mata:
real rowvector side_fit(real colvector x, real colvector w, real colvector y, real colvector d)
{
    real matrix X, A, Ai
    real colvector by, bd, ey, ed, g, h
    X = (J(rows(x), 1, 1), x)
    A = cross(X, w, X)
    Ai = invsym(A)
    by = Ai * cross(X, w, y)
    bd = Ai * cross(X, w, d)
    ey = y - X * by
    ed = d - X * bd
    g = X * Ai[., 1]
    h = w :* g
    return((by[1], bd[1], sum(h:^2 :* ey:^2), sum(h:^2 :* ed:^2), sum(h:^2 :* ey :* ed)))
}

void run_rd()
{
    real colvector s, w, y, d
    real rowvector R, L
    real scalar rf, fs, vrf, vfs, cfr, te, vte

    s = st_data(., "score")
    w = st_data(., "w")
    y = st_data(., "earnings")
    d = st_data(., "participated")

    R = side_fit(select(s, s :>= 0), select(w, s :>= 0), select(y, s :>= 0), select(d, s :>= 0))
    L = side_fit(select(s, s :< 0), select(w, s :< 0), select(y, s :< 0), select(d, s :< 0))

    rf  = R[1] - L[1]
    fs  = R[2] - L[2]
    vrf = R[3] + L[3]
    vfs = R[4] + L[4]
    cfr = R[5] + L[5]
    te  = rf / fs
    vte = vrf / fs^2 + rf^2 * vfs / fs^4 - 2 * rf * cfr / fs^3

    st_numscalar("rf", rf)
    st_numscalar("fs", fs)
    st_numscalar("te", te)
    st_numscalar("se_rf", sqrt(vrf))
    st_numscalar("se_fs", sqrt(vfs))
    st_numscalar("se_te", sqrt(vte))
}

run_rd()
end

display "ANSWER: treatment_effect estimate=" %21.12f te " se=" %21.12f se_te " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f rf " se=" %21.12f se_rf " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f fs " se=" %21.12f se_fs " n_obs=" %12.0f n_obs
