clear all
set more off
set linesize 255
import delimited using "input.csv", clear varnames(1) stringcols(1)
gen double dt = date(date, "YMD")
format dt %td
sort dt
gen long t = _n
tsset t
gen double lsales = ln(sales)
gen double dlvix = ln(vix) - ln(vix[_n-1])
forvalues k = 1/15 {
    gen double l`k'dlvix = dlvix[_n-`k']
}
egen double nmiss = rowmiss(lsales dlvix l1dlvix-l15dlvix)
keep if nmiss == 0
count
local regN = r(N)
newey lsales l1dlvix-l15dlvix, lag(15)
local n_obs = e(N)
matrix b = e(b)
matrix V = e(V)
matrix c = J(1, 16, 0)
forvalues k = 1/15 {
    matrix c[1, `k'] = 1
}
matrix c[1,16] = 0
matrix b_cum = c * b'
matrix V_cum = c * V * c'
scalar cum_est = b_cum[1,1]
scalar cum_se = sqrt(V_cum[1,1])
scalar lag1_est = b[1,1]
scalar lag1_se = sqrt(V[1,1])
scalar lag15_est = b[1,15]
scalar lag15_se = sqrt(V[15,15])
display "ANSWER: cumulative_response estimate=" %21.12f cum_est " se=" %21.12f cum_se " n_obs=" %12.0f `n_obs'
display "ANSWER: lag_1 estimate=" %21.12f lag1_est " se=" %21.12f lag1_se " n_obs=" %12.0f `n_obs'
display "ANSWER: lag_15 estimate=" %21.12f lag15_est " se=" %21.12f lag15_se " n_obs=" %12.0f `n_obs'
