clear all
set more off
set matsize 800

import delimited using "households.csv", clear varnames(1) case(lower)
keep if recipient == 0
drop if missing(eligible, dose, baseline, instrument, weight, outcome)
gen byte ne = 1 - eligible
gen d_ne = dose*ne
gen d_el = dose*eligible
gen b_ne = baseline*ne
gen b_el = baseline*eligible
gen i_ne = instrument*ne
gen i_el = instrument*eligible
count
local n = r(N)

ivregress 2sls outcome ne eligible b_ne b_el (d_ne d_el = instrument i_ne i_el) [aweight=weight], noconstant
matrix b = e(b)
local slope_ne = b[1,colnumb(b,"d_ne")]
local slope_el = b[1,colnumb(b,"d_el")]

summarize dose [aw=weight] if eligible==0
local mean_ne = r(mean)
summarize dose [aw=weight] if eligible==1
local mean_el = r(mean)

local eff_ne = `slope_ne'*`mean_ne'
local eff_el = `slope_el'*`mean_el'

preserve
import delimited using "census.csv", clear varnames(1) case(lower)
summarize nonrecipient_population if eligible==0
local p_ne = r(mean)
summarize nonrecipient_population if eligible==1
local p_el = r(mean)
restore
local pop_eff = (`p_ne'*`eff_ne' + `p_el'*`eff_el')/(`p_ne'+`p_el')

* Independent check: manual weighted 2SLS in Mata
mata:
  y = st_data(., "outcome")
  X = st_data(., "d_ne d_el ne eligible b_ne b_el")
  Z = st_data(., "instrument i_ne i_el ne eligible b_ne b_el")
  W = diag(st_data(., "weight"))
  Xh = Z*invsym(Z'*W*Z)*Z'*W*X
  bm = invsym(Xh'*W*X)*Xh'*W*y
  st_numscalar("chk_ne", bm[1])
  st_numscalar("chk_el", bm[2])
end
mata:
  printf("MANUAL_2SLS d_ne=%20.12f d_el=%20.12f\n", st_numscalar("chk_ne"), st_numscalar("chk_el"))
end
display "IVREG_2SLS d_ne=" %20.12f `slope_ne' "  d_el=" %20.12f `slope_el'
display "MEAN_DOSE ne=" %20.12f `mean_ne' "  el=" %20.12f `mean_el'

display "ANSWER: ineligible_effect estimate=" %20.12f `eff_ne' " se=NA n_obs=" %9.0f `n'
display "ANSWER: eligible_nonrecipient_effect estimate=" %20.12f `eff_el' " se=NA n_obs=" %9.0f `n'
display "ANSWER: population_effect estimate=" %20.12f `pop_eff' " se=NA n_obs=" %9.0f `n'
