clear all
set more off
set type double

import delimited using "crosswalk.csv", clear
tempfile cw
save `cw'

import delimited using "trade.csv", clear
merge m:1 code using `cw', nogen assert(match)
keep period industry us_change other_change price_index years
tempfile tr
save `tr'

import delimited using "employment.csv", clear
fillin area period vintage industry
replace employment = 0 if _fillin
drop _fillin
tempfile emp
save `emp'

collapse (sum) employment, by(period vintage industry)
rename employment nat
tempfile nat
save `nat'

import delimited using "areas.csv", clear
preserve
keep if vintage == "base"
keep area period population
tempfile pop
save `pop'
restore
rename total_employment tot
keep area period vintage tot
tempfile ar
save `ar'

import delimited using "outcomes.csv", clear
tempfile out
save `out'

use `emp', clear
merge m:1 area period vintage using `ar', nogen assert(match)
merge m:1 period vintage industry using `nat', nogen assert(match)
merge m:1 period industry using `tr', nogen assert(match)
gen double term = employment/tot * cond(vintage=="base", us_change, other_change) / nat / (price_index/100) / 1000 * (10/years)
collapse (sum) term, by(area period vintage)
reshape wide term, i(area period) j(vintage) string
rename termbase x
rename termearly z

merge 1:1 area period using `out', nogen assert(match)
merge m:1 area period using `pop', nogen assert(match)

ivregress 2sls change_pp period control (x = z) [aw=population]
display "ANSWER iv_slope estimate=" %24.16g _b[x] " se=NA n_obs=" %1.0f e(N)

summarize x if area==0 & period==0, meanonly
display "ANSWER exposure_area0_period0 estimate=" %24.16g r(mean) " se=NA n_obs=" %1.0f e(N)
summarize x if area==0 & period==1, meanonly
display "ANSWER exposure_area0_period1 estimate=" %24.16g r(mean) " se=NA n_obs=" %1.0f e(N)
summarize z if area==0 & period==0, meanonly
display "ANSWER instrument_area0_period0 estimate=" %24.16g r(mean) " se=NA n_obs=" %1.0f e(N)
exit, clear
