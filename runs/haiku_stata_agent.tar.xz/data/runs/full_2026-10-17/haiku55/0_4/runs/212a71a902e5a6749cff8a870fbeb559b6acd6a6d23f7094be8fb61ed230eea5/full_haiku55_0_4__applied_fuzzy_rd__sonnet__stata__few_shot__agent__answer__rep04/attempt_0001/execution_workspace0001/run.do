version 19.0
clear all
set more off
set linesize 255

import delimited using "input.csv", clear varnames(1) case(preserve)
keep if abs(score) < 1
gen double w = 1 - abs(score)
gen byte right = score >= 0
count if right == 1
scalar n_r = r(N)
count if right == 0
scalar n_l = r(N)
scalar n_tot = n_r + n_l

mata:
void side_fit(real colvector s, real colvector wt, real matrix Y,
              real rowvector b0, real matrix V)
{
    real matrix X, Bi, C, R
    real colvector a
    X = (J(rows(s), 1, 1), s)
    Bi = invsym(cross(X, wt, X))
    C = Bi * cross(X, wt, Y)
    R = Y - X * C
    a = wt :* (X * Bi[,1])
    b0 = C[1,]
    V = cross(R, a:*a, R)
}

void run_rd()
{
    real colvector s, wt, rt, sr, wr, sl, wl
    real matrix Y, Yr, Yl, Vr, Vl, V
    real rowvector br, bl, D, g
    real scalar Dy, Df, ratio, se_te

    s  = st_data(., "score")
    wt = st_data(., "w")
    rt = st_data(., "right")
    Y  = st_data(., ("earnings", "participated"))

    sr = select(s, rt :== 1);  wr = select(wt, rt :== 1);  Yr = select(Y, rt :== 1)
    sl = select(s, rt :== 0);  wl = select(wt, rt :== 0);  Yl = select(Y, rt :== 0)

    side_fit(sr, wr, Yr, br, Vr)
    side_fit(sl, wl, Yl, bl, Vl)

    D  = br - bl
    V  = Vr + Vl
    Dy = D[1]
    Df = D[2]
    ratio = Dy / Df
    g = (1/Df, -Dy/Df^2)
    se_te = sqrt(g * V * g')

    st_numscalar("rf", Dy)
    st_numscalar("fs", Df)
    st_numscalar("te", ratio)
    st_numscalar("se_rf", sqrt(V[1,1]))
    st_numscalar("se_fs", sqrt(V[2,2]))
    st_numscalar("se_te", se_te)
}

run_rd()
end

display "ANSWER: treatment_effect estimate=" %21.12f te " se=" %21.12f se_te " n_obs=" %12.0f n_tot
display "ANSWER: reduced_form estimate=" %21.12f rf " se=" %21.12f se_rf " n_obs=" %12.0f n_tot
display "ANSWER: first_stage estimate=" %21.12f fs " se=" %21.12f se_fs " n_obs=" %12.0f n_tot
