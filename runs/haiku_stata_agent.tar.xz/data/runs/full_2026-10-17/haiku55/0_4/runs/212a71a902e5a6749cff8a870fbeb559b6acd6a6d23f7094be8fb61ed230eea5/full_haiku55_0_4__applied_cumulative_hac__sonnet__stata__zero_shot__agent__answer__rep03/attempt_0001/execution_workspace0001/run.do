clear all
set more off
set linesize 255
capture log close
log using run.log, replace text

import delimited using input.csv, clear stringcols(1)
gen double dnum = date(date, "YMD")
assert !missing(dnum)
sort dnum
isid dnum
gen long t = _n
tsset t

gen double lsales = ln(sales)
gen double dlvix = ln(vix) - ln(L.vix)
forvalues j = 1/15 {
    gen double lag`j' = L`j'.dlvix
}

egen double nmiss = rowmiss(lsales lag1-lag15)
keep if nmiss == 0
drop nmiss
local N = _N

newey lsales lag1-lag15, lag(15)
matrix b = e(b)
matrix V = e(V)
local nobs = e(N)
assert `nobs' == `N'

matrix c = J(1, 15, 1)
matrix Vslope = V[1..15, 1..15]
matrix bslope = b[1, 1..15]
matrix cum_b = c * bslope'
matrix cum_V = c * Vslope * c'
local cum_est = cum_b[1,1]
local cum_se  = sqrt(cum_V[1,1])
local l1_est  = b[1,1]
local l1_se   = sqrt(V[1,1])
local l15_est = b[1,15]
local l15_se  = sqrt(V[15,15])

display "Sample N = " `N'
display "ANSWER: cumulative_response estimate=" %21.12f `cum_est' " se=" %21.12f `cum_se' " n_obs=" %12.0f `nobs'
display "ANSWER: lag_1 estimate=" %21.12f `l1_est' " se=" %21.12f `l1_se' " n_obs=" %12.0f `nobs'
display "ANSWER: lag_15 estimate=" %21.12f `l15_est' " se=" %21.12f `l15_se' " n_obs=" %12.0f `nobs'

log close
