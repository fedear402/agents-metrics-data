clear all
set more off

import delimited using "census.csv", clear stringcols(_all)
gen double elig_n = real(eligible)
gen double pop_n = real(nonrecipient_population)
summarize pop_n if elig_n==0, meanonly
scalar pop0 = r(mean)
summarize pop_n if elig_n==1, meanonly
scalar pop1 = r(mean)

import delimited using "households.csv", clear stringcols(_all)
foreach v in household eligible treated recipient instrument dose baseline weight outcome {
    gen double `v'_n = real(`v')
    drop `v'
    rename `v'_n `v'
}
keep if recipient==0

gen byte ne = 1 - eligible
gen double xin = dose*ne
gen double xel = dose*eligible
gen double bin = baseline*ne
gen double bel = baseline*eligible
gen double zin = instrument*ne
gen double zel = instrument*eligible
gen double wd  = weight*dose

ivregress 2sls outcome ne eligible bin bel (xin xel = zin zel) [aw=weight], noconstant

scalar s_in = _b[xin]
scalar s_el = _b[xel]

quietly summarize wd if eligible==0, meanonly
scalar sw_d0 = r(sum)
quietly summarize weight if eligible==0, meanonly
scalar mean_in = sw_d0/r(sum)

quietly summarize wd if eligible==1, meanonly
scalar sw_d1 = r(sum)
quietly summarize weight if eligible==1, meanonly
scalar mean_el = sw_d1/r(sum)

scalar eff_in = s_in*mean_in
scalar eff_el = s_el*mean_el
scalar pop_eff = (pop0*eff_in + pop1*eff_el)/(pop0+pop1)
quietly count
scalar nobs = r(N)

display "ANSWER: ineligible_effect estimate=" %18.12f eff_in " se=NA n_obs=" %1.0f nobs
display "ANSWER: eligible_nonrecipient_effect estimate=" %18.12f eff_el " se=NA n_obs=" %1.0f nobs
display "ANSWER: population_effect estimate=" %18.12f pop_eff " se=NA n_obs=" %1.0f nobs
