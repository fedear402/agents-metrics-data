version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear varnames(1)
keep if abs(score) < 1
gen double w = 1 - abs(score)
gen byte right = (score >= 0)
count
local nobs = r(N)
count if right == 1
local nR = r(N)
count if right == 0
local nL = r(N)

mata:
real matrix side_fit(real colvector s, real colvector w, real matrix Y)
{
    real matrix X, B, E, L, infl, J
    real colvector beta
    X = (J(rows(s),1,1), s)
    B = invsym(X' * (w :* X))
    beta = B * X' * (w :* Y)
    E = Y - X * beta
    L = w :* (X * B * (1\0))
    infl = L :* E
    J = infl' * infl
    return((beta[1,1], beta[1,2]) \ J)
}

s = st_data(., "score")
w = st_data(., "w")
Y = st_data(., ("earnings", "participated"))
R = st_data(., "right")

sR = select(s, R :== 1);  wR = select(w, R :== 1);  YR = select(Y, R :== 1)
sL = select(s, R :== 0);  wL = select(w, R :== 0);  YL = select(Y, R :== 0)

fitR = side_fit(sR, wR, YR)
fitL = side_fit(sL, wL, YL)

Vdisc = fitR[2::3, .] + fitL[2::3, .]
disc = (fitR[1,1] - fitL[1,1], fitR[1,2] - fitL[1,2])

rf = disc[1]
fs = disc[2]
tau = rf / fs
grad = (1/fs \ -rf/fs^2)
se_tau = sqrt(grad' * Vdisc * grad)
se_rf = sqrt(Vdisc[1,1])
se_fs = sqrt(Vdisc[2,2])

st_numscalar("rf", rf)
st_numscalar("fs", fs)
st_numscalar("tau", tau)
st_numscalar("se_rf", se_rf)
st_numscalar("se_fs", se_fs)
st_numscalar("se_tau", se_tau)
end

display "ANSWER: treatment_effect estimate=" %21.12f tau " se=" %21.12f se_tau " n_obs=" %12.0f `nobs'
display "ANSWER: reduced_form estimate=" %21.12f rf " se=" %21.12f se_rf " n_obs=" %12.0f `nobs'
display "ANSWER: first_stage estimate=" %21.12f fs " se=" %21.12f se_fs " n_obs=" %12.0f `nobs'

* Independent check: point estimates via weighted regressions on each side
regress earnings score [aw=w] if right == 1
scalar yR = _b[_cons]
regress earnings score [aw=w] if right == 0
scalar yL = _b[_cons]
regress participated score [aw=w] if right == 1
scalar pR = _b[_cons]
regress participated score [aw=w] if right == 0
scalar pL = _b[_cons]
display "CHECK: rf_regress=" %21.12f yR - yL "  fs_regress=" %21.12f pR - pL
display "CHECK: nR=`nR' nL=`nL' total=`nobs'"
