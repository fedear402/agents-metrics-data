clear all
set linesize 255
import delimited using "./input.csv", clear varnames(1) case(lower)
quietly anova y group
local F = e(F)
local df_num = e(df_m)
local df_den = e(df_r)
local p = Ftail(`df_num', `df_den', `F')
local n = e(N)
display "ANSWER: F estimate=" %21.12f `F' " se=. n_obs=" %12.0f `n'
display "ANSWER: df_num estimate=" %21.12f `df_num' " se=. n_obs=" %12.0f `n'
display "ANSWER: df_den estimate=" %21.12f `df_den' " se=. n_obs=" %12.0f `n'
display "ANSWER: p_value estimate=" %21.12f `p' " se=. n_obs=" %12.0f `n'
