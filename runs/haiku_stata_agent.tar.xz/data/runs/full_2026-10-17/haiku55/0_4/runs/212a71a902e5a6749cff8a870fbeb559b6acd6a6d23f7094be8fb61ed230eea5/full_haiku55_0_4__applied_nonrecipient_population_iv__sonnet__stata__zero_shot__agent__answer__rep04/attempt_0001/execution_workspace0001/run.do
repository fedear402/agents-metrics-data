clear all
set more off

import delimited using "households.csv", clear varnames(1) stringcols(_all)
foreach v of varlist household eligible treated recipient instrument dose baseline weight outcome {
    gen double x_`v' = real(`v')
    drop `v'
    rename x_`v' `v'
}
keep if recipient == 0

gen double g0 = 1 - eligible
gen double g1 = eligible
gen double d0 = dose * g0
gen double d1 = dose * g1
gen double b0 = baseline * g0
gen double b1 = baseline * g1
gen double z0 = instrument * g0
gen double z1 = instrument * g1

count
local n = r(N)

ivregress 2sls outcome g0 g1 b0 b1 (d0 d1 = z0 z1) [aw=weight], noconstant

local s0 = _b[d0]
local s1 = _b[d1]

summarize dose [aw=weight] if eligible == 0, meanonly
local m0 = r(mean)
summarize dose [aw=weight] if eligible == 1, meanonly
local m1 = r(mean)

local e0 = `s0' * `m0'
local e1 = `s1' * `m1'

preserve
import delimited using "census.csv", clear varnames(1)
summarize nonrecipient_population if eligible == 0, meanonly
local p0 = r(mean)
summarize nonrecipient_population if eligible == 1, meanonly
local p1 = r(mean)
restore

local pop = (`p0' * `e0' + `p1' * `e1') / (`p0' + `p1')

display "slope0=" string(`s0', "%20.12f") " slope1=" string(`s1', "%20.12f")
display "mean_dose0=" string(`m0', "%20.12f") " mean_dose1=" string(`m1', "%20.12f")
display "ANSWER: ineligible_effect estimate=" trim(string(`e0', "%20.12f")) " se=NA n_obs=" trim(string(`n', "%12.0f"))
display "ANSWER: eligible_nonrecipient_effect estimate=" trim(string(`e1', "%20.12f")) " se=NA n_obs=" trim(string(`n', "%12.0f"))
display "ANSWER: population_effect estimate=" trim(string(`pop', "%20.12f")) " se=NA n_obs=" trim(string(`n', "%12.0f"))
