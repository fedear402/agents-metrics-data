clear all
set more off
set linesize 255
import delimited using "input.csv", clear varnames(1) case(preserve)

keep if abs(score) < 1
gen double w = 1 - abs(score)
gen byte R = (score >= 0)
gen byte L = 1 - R
gen double sR = score * R
gen double sL = score * L
count
local nobs = r(N)

mata:
X = (st_data(., "L"), st_data(., "L") :* st_data(., "score"), st_data(., "R"), st_data(., "R") :* st_data(., "score"))
W = st_data(., "w")
Y1 = st_data(., "earnings")
Y2 = st_data(., "participated")

XtWX = cross(X, W, X)
B = invsym(XtWX)

b1 = B * cross(X, W, Y1)
b2 = B * cross(X, W, Y2)
e1 = Y1 - X * b1
e2 = Y2 - X * b2

// influence matrices: row i = (X'WX)^-1 x_i w_i e_i
P1 = (X :* (W :* e1)) * B
P2 = (X :* (W :* e2)) * B

// discontinuities: right intercept (col 3) minus left intercept (col 1)
d = (-1, 0, 1, 0)'
rf = d' * b1
fs = d' * b2
s1 = P1 * d
s2 = P2 * d
V11 = cross(s1, s1)
V22 = cross(s2, s2)
V12 = cross(s1, s2)

te = rf / fs
g = (1/fs, -rf/(fs^2))
Vte = g[1]^2 * V11 + 2*g[1]*g[2]*V12 + g[2]^2 * V22
st_numscalar("rf", rf)
st_numscalar("fs", fs)
st_numscalar("te", te)
st_numscalar("se_rf", sqrt(V11))
st_numscalar("se_fs", sqrt(V22))
st_numscalar("se_te", sqrt(Vte))
end

display "ANSWER: treatment_effect estimate=" %21.12f te " se=" %21.12f se_te " n_obs=" %12.0f `nobs'
display "ANSWER: reduced_form estimate=" %21.12f rf " se=" %21.12f se_rf " n_obs=" %12.0f `nobs'
display "ANSWER: first_stage estimate=" %21.12f fs " se=" %21.12f se_fs " n_obs=" %12.0f `nobs'
