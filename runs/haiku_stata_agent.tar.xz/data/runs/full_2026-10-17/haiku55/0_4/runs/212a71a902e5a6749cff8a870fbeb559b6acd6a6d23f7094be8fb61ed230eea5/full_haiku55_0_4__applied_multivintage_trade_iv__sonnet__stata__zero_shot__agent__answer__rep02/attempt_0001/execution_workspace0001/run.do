clear all
set more off

import delimited using "crosswalk.csv", clear stringcols(_all)
destring industry, replace
tempfile cw
save `cw'

import delimited using "trade.csv", clear stringcols(1)
destring period, replace
merge m:1 code using `cw', assert(match) nogen
keep period industry us_change other_change price_index years
tempfile tr
save `tr'

import delimited using "employment.csv", clear stringcols(3)
destring period industry, replace
tempfile emp
save `emp'

import delimited using "outcomes.csv", clear stringcols(_all)
rename control control_s
rename change_pp change_pp_s
destring area period, replace
gen double control = real(control_s)
gen double change_pp = real(change_pp_s)
drop control_s change_pp_s
tempfile oc
save `oc'

import delimited using "areas.csv", clear stringcols(3)
keep area period vintage total_employment population
tempfile areas
save `areas'
keep if vintage == "base"
keep area period population
tempfile pop
save `pop'

use `areas', clear
expand 4
bysort area period vintage: gen industry = _n - 1
merge 1:1 area period vintage industry using `emp', assert(match master) nogen
replace employment = 0 if missing(employment)
merge m:1 period industry using `tr', assert(match) nogen

bysort period vintage industry: egen double nat = total(employment)
gen double share = employment / total_employment
gen double xt = share * (us_change / nat) / (price_index / 100) / 1000 * (10 / years) if vintage == "base"
gen double zt = share * (other_change / nat) / (price_index / 100) / 1000 * (10 / years) if vintage == "early"

collapse (sum) x = xt z = zt, by(area period)

merge 1:1 area period using `oc', assert(match) nogen
merge 1:1 area period using `pop', assert(match) nogen
count
assert r(N) == 72

ivregress 2sls change_pp period control (x = z) [aweight = population]
local b = _b[x]
local nobs = e(N)

quietly summarize x if area == 0 & period == 0, meanonly
local ex0 = r(mean)
quietly summarize x if area == 0 & period == 1, meanonly
local ex1 = r(mean)
quietly summarize z if area == 0 & period == 0, meanonly
local iz0 = r(mean)

local l1 = "iv_slope estimate=" + trim(string(`b', "%20.12f")) + " se=NA n_obs=" + trim(string(`nobs', "%12.0f"))
local l2 = "exposure_area0_period0 estimate=" + trim(string(`ex0', "%20.12f")) + " se=NA n_obs=" + trim(string(`nobs', "%12.0f"))
local l3 = "exposure_area0_period1 estimate=" + trim(string(`ex1', "%20.12f")) + " se=NA n_obs=" + trim(string(`nobs', "%12.0f"))
local l4 = "instrument_area0_period0 estimate=" + trim(string(`iz0', "%20.12f")) + " se=NA n_obs=" + trim(string(`nobs', "%12.0f"))

file open fh using "answer.txt", write replace text
foreach l in "`l1'" "`l2'" "`l3'" "`l4'" {
    file write fh "ANSWER: `l'" _n
    display "ANSWER: `l'"
}
file close fh
