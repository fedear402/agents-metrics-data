version 19.0
clear all
set more off
set linesize 255
log using run.log, replace text

import delimited using "input.csv", clear stringcols(_all)
generate double day = date(date, "YMD")
generate double sales_d = real(sales)
generate double vix_d = real(vix)
drop sales vix
rename sales_d sales
rename vix_d vix
sort day
generate long t = _n
tsset t

generate double log_sales = log(sales)
generate double log_vix = log(vix)
generate double dlog_vix = D.log_vix
forvalues k = 1/15 {
    generate double lag`k' = L`k'.dlog_vix
}

local lags ""
forvalues k = 1/15 {
    local lags `lags' lag`k'
}

generate byte usable = !missing(log_sales, dlog_vix)
forvalues k = 1/15 {
    replace usable = usable & !missing(lag`k')
}
keep if usable

mata:
X = (J(st_nobs(), 1, 1), st_data(., tokens("`lags'")))
y = st_data(., "log_sales")
N = rows(X)
p = cols(X)
L = 15
bread = invsym(X' * X)
b = bread * X' * y
e = y - X * b
scores = X :* e
meat = scores' * scores
for (j = 1; j <= L; j++) {
    G = scores[|j+1, 1 \ N, p|]' * scores[|1, 1 \ N-j, p|]
    meat = meat + (1 - j/(L+1)) * (G + G')
}
V = N/(N-p) * bread * meat * bread
c = (0 \ J(L, 1, 1))
cum = c' * b
cum_se = sqrt(c' * V * c)
st_numscalar("cum", cum)
st_numscalar("cum_se", cum_se)
st_numscalar("b1", b[2])
st_numscalar("se1", sqrt(V[2,2]))
st_numscalar("b15", b[16])
st_numscalar("se15", sqrt(V[16,16]))
st_numscalar("N", N)
end

display "ANSWER: cumulative_response estimate=" %21.12f cum " se=" %21.12f cum_se " n_obs=" %12.0f N
display "ANSWER: lag_1 estimate=" %21.12f b1 " se=" %21.12f se1 " n_obs=" %12.0f N
display "ANSWER: lag_15 estimate=" %21.12f b15 " se=" %21.12f se15 " n_obs=" %12.0f N

log close
