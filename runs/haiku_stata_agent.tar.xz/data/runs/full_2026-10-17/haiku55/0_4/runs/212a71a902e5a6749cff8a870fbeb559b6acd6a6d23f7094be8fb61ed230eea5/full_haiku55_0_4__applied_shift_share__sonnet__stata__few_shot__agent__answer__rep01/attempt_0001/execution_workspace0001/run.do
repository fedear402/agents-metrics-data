version 19.0
clear all
set more off
set linesize 255

mata:
real rowvector ivhc(real colvector y, real matrix X, real matrix Z, real colvector w)
{
    real scalar n
    real matrix inv, S, V
    real colvector b, u
    n = rows(y)
    inv = luinv(Z'(w:*X))
    b = inv*Z'(w:*y)
    u = y - X*b
    S = Z:*(w:*u)
    V = n/(n-2)*inv*(S'S)*inv'
    return((b[2], sqrt(V[2,2])))
}

void reg_ref()
{
    real colvector y0, x0, z0, e
    y0 = st_data(., "y0"); x0 = st_data(., "x0"); z0 = st_data(., "z0"); e = st_data(., "e")
    st_numscalar("r_reg_2sls", sum(e:*z0:*y0)/sum(e:*z0:*x0))
    st_numscalar("r_reg_fs", sum(e:*z0:*x0)/sum(e:*z0:^2))
    st_numscalar("r_reg_n", rows(y0))
}
end

import delimited using "input.csv", clear varnames(1) stringcols(_all)
foreach v of varlist _all {
    gen double `v'_d = real(`v')
    drop `v'
    rename `v'_d `v'
}

gen double sh = share*shock
bysort region_id: egen double z = total(sh)
egen byte tagr = tag(region_id)
gen double rw = region_weight*tagr
egen double wsum = total(rw)
gen double e = region_weight/wsum if tagr

preserve
keep if tagr
quietly summarize y [aweight=e], meanonly
gen double y0 = y - r(mean)
quietly summarize x [aweight=e], meanonly
gen double x0 = x - r(mean)
quietly summarize z [aweight=e], meanonly
gen double z0 = z - r(mean)
quietly summarize e
scalar sum_e = r(sum)
mata: reg_ref()
keep region_id e y0 x0 z0
tempfile regfile
save `regfile'
restore

drop e
merge m:1 region_id using `regfile', nogenerate assert(match)

gen double ew = e*share
bysort industry_id: egen double s = total(ew)
foreach v in y0 x0 z0 {
    gen double tmp_`v' = ew*`v'
    bysort industry_id: egen double T_`v' = total(tmp_`v')
    gen double bar_`v' = T_`v'/s
}
rename bar_y0 ybn
rename bar_x0 xbn
rename bar_z0 zbn

egen byte tagi = tag(industry_id)
keep if tagi
keep industry_id shock s ybn xbn zbn
sort industry_id

mata:
void shock_level()
{
    real colvector yb, xb, zb, sv, shk
    real matrix I1
    real rowvector eff, fs
    real scalar nI

    st_view(yb, ., "ybn")
    st_view(xb, ., "xbn")
    st_view(zb, ., "zbn")
    st_view(sv, ., "s")
    shk = st_data(., "shock")
    nI = rows(yb)
    I1 = J(nI,1,1)
    eff = ivhc(yb, (I1,xb), (I1,shk), sv)
    fs  = ivhc(xb, (I1,zb), (I1,shk), sv)
    st_numscalar("r_eff_b", eff[1])
    st_numscalar("r_eff_se", eff[2])
    st_numscalar("r_fs_b", fs[1])
    st_numscalar("r_fs_se", fs[2])
    st_numscalar("r_nI", nI)
    st_numscalar("r_effs", 1/sum(sv:^2))
    st_numscalar("r_sum_s", sum(sv))
}
shock_level()
end


display "CHECK: sum_e=" %12.10f sum_e
display "CHECK: regional_2sls=" %21.15f r_reg_2sls " shock_iv=" %21.15f r_eff_b
display "CHECK: regional_first_stage=" %21.15f r_reg_fs " shock_fs=" %21.15f r_fs_b
display "CHECK: sum_s=" %12.10f r_sum_s " n_industries=" %4.0f r_nI

display "ANSWER: effect estimate=" %21.12f r_eff_b " se=" %21.12f r_eff_se " n_obs=" %12.0f r_nI
display "ANSWER: first_stage estimate=" %21.12f r_reg_fs " se=" %21.12f r_fs_se " n_obs=" %12.0f r_nI
display "ANSWER: effective_shocks estimate=" %21.12f r_effs " se=" %21.12f . " n_obs=" %12.0f r_nI
