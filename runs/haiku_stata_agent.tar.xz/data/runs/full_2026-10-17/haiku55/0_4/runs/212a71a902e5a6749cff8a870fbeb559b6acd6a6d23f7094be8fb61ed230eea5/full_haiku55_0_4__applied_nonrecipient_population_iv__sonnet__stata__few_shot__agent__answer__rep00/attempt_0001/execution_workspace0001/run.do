clear all
set more off
set type double

import delimited using "households.csv", clear varnames(1)
keep if recipient==0
count
local nobs = r(N)

gen dose0 = dose*(1-eligible)
gen dose1 = dose*eligible
gen base0 = baseline*(1-eligible)
gen base1 = baseline*eligible
gen inst0 = instrument*(1-eligible)
gen inst1 = instrument*eligible
gen ne0 = 1-eligible

ivregress 2sls outcome ne0 eligible base0 base1 (dose0 dose1 = ne0 eligible base0 base1 inst0 inst1) [aw=weight], noconstant

scalar b0 = _b[dose0]
scalar b1 = _b[dose1]

summarize dose [aw=weight] if eligible==0, meanonly
scalar e0 = b0*r(mean)
summarize dose [aw=weight] if eligible==1, meanonly
scalar e1 = b1*r(mean)

import delimited using "census.csv", clear varnames(1)
summarize nonrecipient_population if eligible==0, meanonly
scalar n0 = r(mean)
summarize nonrecipient_population if eligible==1, meanonly
scalar n1 = r(mean)
scalar pop = (e0*n0+e1*n1)/(n0+n1)

display "ANSWER: ineligible_effect estimate=" %24.16g (e0) " se=NA n_obs=" `nobs'
display "ANSWER: eligible_nonrecipient_effect estimate=" %24.16g (e1) " se=NA n_obs=" `nobs'
display "ANSWER: population_effect estimate=" %24.16g (pop) " se=NA n_obs=" `nobs'
exit, clear
