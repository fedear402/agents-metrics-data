version 19.0
clear all
set more off
set linesize 255

import delimited using "input.csv", clear stringcols(1) varnames(1)
generate double day = date(date, "YMD")
assert !missing(day)
isid day
sort day
generate long obs = _n
tsset obs

generate double lsales = ln(sales)
generate double lvix = ln(vix)
generate double dlvix = D.lvix
forvalues k = 1/15 {
    generate double lag`k' = L`k'.dlvix
}
local lagnames ""
forvalues k = 1/15 {
    local lagnames "`lagnames' lag`k'"
}
egen int nlags_ok = rownonmiss(lag1-lag15)
keep if nlags_ok == 15 & !missing(lsales)
count
local N = r(N)
display "Estimation sample N = `N'"

mata:
y = st_data(., "lsales")
X = (J(rows(y), 1, 1), st_data(., tokens(st_local("lagnames"))))
N = rows(X)
p = cols(X)
L = 15
b = qrsolve(X, y)
e = y - X*b
S = X:*e
meat = S'*S
for (j = 1; j <= L; j++) {
    w = 1 - j/(L+1)
    Gj = S[|j+1,1 \ N,p|]' * S[|1,1 \ N-j,p|]
    meat = meat + w*(Gj + Gj')
}
bread = invsym(X'*X)
V = N/(N-p) * bread*meat*bread
c = J(p,1,0)
c[2..p] = J(15,1,1)
cum_est = c'*b
cum_se = sqrt(c'*V*c)
st_numscalar("cum_est", cum_est)
st_numscalar("cum_se", cum_se)
st_numscalar("lag1_est", b[2])
st_numscalar("lag1_se", sqrt(V[2,2]))
st_numscalar("lag15_est", b[16])
st_numscalar("lag15_se", sqrt(V[16,16]))
st_numscalar("nobs", N)
end

display "ANSWER: cumulative_response estimate=" %21.12f cum_est " se=" %21.12f cum_se " n_obs=" %12.0f nobs
display "ANSWER: lag_1 estimate=" %21.12f lag1_est " se=" %21.12f lag1_se " n_obs=" %12.0f nobs
display "ANSWER: lag_15 estimate=" %21.12f lag15_est " se=" %21.12f lag15_se " n_obs=" %12.0f nobs

* Independent check: Stata newey with the same 15 lags and Bartlett kernel
quietly newey lsales lag1-lag15, lag(15)
matrix Vn = e(V)
matrix cvec = J(1,15,1)
matrix Vsum = cvec*Vn[1..15,1..15]*cvec'
display "CHECK newey_e(V) cum_est=" %21.12f (_b[lag1]+_b[lag2]+_b[lag3]+_b[lag4]+_b[lag5]+_b[lag6]+_b[lag7]+_b[lag8]+_b[lag9]+_b[lag10]+_b[lag11]+_b[lag12]+_b[lag13]+_b[lag14]+_b[lag15])
display "CHECK newey_e(V) cum_se=" %21.12f sqrt(Vsum[1,1]) "  lag1_se=" %21.12f sqrt(Vn[1,1]) "  lag15_se=" %21.12f sqrt(Vn[15,15])
display "CHECK newey_e(V) N=" %12.0f e(N)
