version 19.0
clear all
set more off
set linesize 255

import delimited using "input.csv", clear varnames(1) asdouble

count if missing(region_id, industry_id, share, shock, region_weight, x, y)
assert r(N)==0
bysort region_id: assert region_weight==region_weight[1]
bysort region_id: assert x==x[1]
bysort region_id: assert y==y[1]
bysort industry_id: assert shock==shock[1]
egen double shsum = total(share), by(region_id)
assert abs(shsum-1)<1e-8

egen byte regtag = tag(region_id)
egen byte indtag = tag(industry_id)
quietly count if regtag
scalar R = r(N)
quietly count if indtag
scalar N_ind = r(N)

egen double zr = total(share*shock), by(region_id)
quietly summarize region_weight if regtag, meanonly
scalar sumw = r(sum)
gen double e = region_weight/sumw

gen double ex = e*x
gen double ey = e*y
gen double ez = e*zr
quietly summarize ex if regtag, meanonly
scalar mx = r(sum)
quietly summarize ey if regtag, meanonly
scalar my = r(sum)
quietly summarize ez if regtag, meanonly
scalar mz = r(sum)

gen double x0 = x - mx
gen double y0 = y - my
gen double z0 = zr - mz

egen double sn = total(e*share), by(industry_id)
egen double sy = total(e*share*y0), by(industry_id)
egen double sx = total(e*share*x0), by(industry_id)
egen double sz = total(e*share*z0), by(industry_id)
gen double ybar = sy/sn
gen double xbar = sx/sn
gen double zbar = sz/sn

quietly summarize sn if indtag, meanonly
assert abs(r(sum)-1)<1e-8

gen double ezy = e*z0*y0 if regtag
gen double ezx = e*z0*x0 if regtag
gen double eZZ = e*z0*z0 if regtag
gen double exz = e*x0*z0 if regtag
quietly summarize ezy, meanonly
scalar num_eff = r(sum)
quietly summarize ezx, meanonly
scalar den_eff = r(sum)
quietly summarize eZZ, meanonly
scalar den_fs = r(sum)
quietly summarize exz, meanonly
scalar num_fs = r(sum)
scalar reg_effect = num_eff/den_eff
scalar reg_first = num_fs/den_fs

mata:
real colvector ivhc1(real colvector y, real colvector x, real colvector z, real colvector w)
{
    real scalar N
    real matrix X, Z, Ai, S, V
    real colvector b, u
    N = rows(y)
    X = (J(N,1,1), x)
    Z = (J(N,1,1), z)
    Ai = luinv(Z'*(w:*X))
    b = Ai*(Z'*(w:*y))
    u = y - X*b
    S = Z:*(w:*u)
    V = N/(N-2)*Ai*(S'*S)*Ai'
    return((b[2]\sqrt(V[2,2])))
}
void shockfit()
{
    real colvector ind_ybar, ind_xbar, ind_zbar, ind_shock, ind_s, eff, fs
    real scalar eff_eff
    ind_ybar  = st_data(., "ybar", "indtag")
    ind_xbar  = st_data(., "xbar", "indtag")
    ind_zbar  = st_data(., "zbar", "indtag")
    ind_shock = st_data(., "shock", "indtag")
    ind_s     = st_data(., "sn", "indtag")
    eff = ivhc1(ind_ybar, ind_xbar, ind_shock, ind_s)
    fs  = ivhc1(ind_xbar, ind_zbar, ind_shock, ind_s)
    eff_eff = 1/sum(ind_s:^2)
    st_numscalar("sh_eff", eff[1])
    st_numscalar("se_eff", eff[2])
    st_numscalar("sh_fs", fs[1])
    st_numscalar("se_fs", fs[2])
    st_numscalar("eff_shocks", eff_eff)
}
shockfit()
end

assert abs(sh_eff-reg_effect)<1e-8
assert abs(sh_fs-reg_first)<1e-8

display "ANSWER: effect estimate=" %21.12f sh_eff " se=" %21.12f se_eff " n_obs=" %12.0f N_ind
display "ANSWER: first_stage estimate=" %21.12f sh_fs " se=" %21.12f se_fs " n_obs=" %12.0f N_ind
display "ANSWER: effective_shocks estimate=" %21.12f eff_shocks " se=" %21.12f . " n_obs=" %12.0f N_ind
display "CHECK: regions=" %12.0f R " industries=" %12.0f N_ind
display "CHECK: regional_effect=" %21.12f reg_effect " regional_first=" %21.12f reg_first
