clear all
set more off
set type double

import delimited using "households.csv", clear varnames(1)
keep if recipient==0
local n_obs = _N

gen double d0 = dose*(1-eligible)
gen double d1 = dose*eligible
gen double x0 = 1-eligible
gen double x1 = eligible
gen double b0 = baseline*(1-eligible)
gen double b1 = baseline*eligible
gen double z0 = instrument*(1-eligible)
gen double z1 = instrument*eligible

ivregress 2sls outcome x0 x1 b0 b1 (d0 d1 = z0 z1) [aw=weight], noconstant
scalar s0 = _b[d0]
scalar s1 = _b[d1]

summarize dose [aw=weight] if eligible==0, meanonly
scalar m0 = r(mean)
summarize dose [aw=weight] if eligible==1, meanonly
scalar m1 = r(mean)

scalar e0 = s0*m0
scalar e1 = s1*m1

import delimited using "census.csv", clear varnames(1)
summarize nonrecipient_population if eligible==0, meanonly
scalar n0 = r(mean)
summarize nonrecipient_population if eligible==1, meanonly
scalar n1 = r(mean)
scalar pop = (e0*n0 + e1*n1)/(n0+n1)

display "ANSWER: ineligible_effect estimate=" strtrim(string(e0,"%24.16g")) " se=NA n_obs=" strtrim(string(`n_obs'))
display "ANSWER: eligible_nonrecipient_effect estimate=" strtrim(string(e1,"%24.16g")) " se=NA n_obs=" strtrim(string(`n_obs'))
display "ANSWER: population_effect estimate=" strtrim(string(pop,"%24.16g")) " se=NA n_obs=" strtrim(string(`n_obs'))
exit, clear
