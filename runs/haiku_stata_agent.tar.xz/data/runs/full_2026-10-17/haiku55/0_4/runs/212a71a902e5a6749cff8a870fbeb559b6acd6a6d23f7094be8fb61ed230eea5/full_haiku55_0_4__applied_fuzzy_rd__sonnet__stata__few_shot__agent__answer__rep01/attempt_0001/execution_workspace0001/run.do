version 19.0
clear all
set more off
set linesize 255

import delimited using "input.csv", clear varnames(1)

keep if abs(score) < 1
gen double w = 1 - abs(score)
gen byte right = score >= 0

mata:
Y = st_data(., ("earnings", "participated"))
s = st_data(., "score")
w = st_data(., "w")
r = st_data(., "right")
n = rows(Y)
infl = J(n, 2, 0)
b = J(2, 2, 0)

for (k = 0; k <= 1; k++) {
    idx = selectindex(r :== k)
    X = (J(rows(idx), 1, 1), s[idx])
    W = w[idx]
    Yk = Y[idx, .]
    bread = invsym(X' * (W :* X))
    coef = bread * X' * (W :* Yk)
    res = Yk - X * coef
    loading = W :* (X * bread * (1 \ 0))
    sgn = (k == 1 ? 1 : -1)
    infl[idx, .] = sgn :* (loading :* res)
    b[k + 1, .] = coef[1, .]
}

rf = b[2, 1] - b[1, 1]
fs = b[2, 2] - b[1, 2]
V = infl' * infl
te = rf / fs
grad = (1 / fs \ -rf / fs^2)
te_se = sqrt(grad' * V * grad)

printf("ANSWER: treatment_effect estimate=%21.12f se=%21.12f n_obs=%12.0f\n", te, te_se, n)
printf("ANSWER: reduced_form estimate=%21.12f se=%21.12f n_obs=%12.0f\n", rf, sqrt(V[1,1]), n)
printf("ANSWER: first_stage estimate=%21.12f se=%21.12f n_obs=%12.0f\n", fs, sqrt(V[2,2]), n)
end
