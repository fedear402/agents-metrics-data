clear all
set linesize 255
import delimited using "input.csv", clear varnames(1) case(preserve)
quietly count
local n = r(N)
quietly anova y group
local F = e(F)
local dfn = e(df_m)
local dfd = e(df_r)
local p = Ftail(`dfn', `dfd', `F')
local Fs = string(`F', "%21.12f")
local dfns = string(`dfn', "%12.0f")
local dfds = string(`dfd', "%12.0f")
local ps = string(`p', "%21.12f")
local ns = string(`n', "%12.0f")
display "ANSWER: F estimate=`Fs' se=. n_obs=`ns'"
display "ANSWER: df_num estimate=`dfns' se=. n_obs=`ns'"
display "ANSWER: df_den estimate=`dfds' se=. n_obs=`ns'"
display "ANSWER: p_value estimate=`ps' se=. n_obs=`ns'"
