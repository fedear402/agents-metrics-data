clear all
set more off
set linesize 255
import delimited using "households.csv", clear varnames(1)
keep if recipient==0
gen d0 = dose*(1-eligible)
gen d1 = dose*eligible
gen b0 = baseline*(1-eligible)
gen b1 = baseline*eligible
gen i0 = instrument*(1-eligible)
gen i1 = instrument*eligible
gen e0 = 1-eligible
gen e1 = eligible
quietly count
local N = r(N)

ivregress 2sls outcome e0 e1 b0 b1 (d0 d1 = i0 i1 e0 e1 b0 b1) [aw=weight], noconstant
matrix B = e(b)
local s0 = B[1,colnumb(B,"d0")]
local s1 = B[1,colnumb(B,"d1")]

quietly summarize dose [aw=weight] if eligible==0
local m0 = r(mean)
quietly summarize dose [aw=weight] if eligible==1
local m1 = r(mean)

local ine = `s0'*`m0'
local elig = `s1'*`m1'

preserve
import delimited using "census.csv", clear varnames(1)
quietly summarize nonrecipient_population if eligible==0
local p0 = r(mean)
quietly summarize nonrecipient_population if eligible==1
local p1 = r(mean)
restore
local pop = (`p0'*`ine' + `p1'*`elig')/(`p0'+`p1')

display "slope0=" %18.12f `s0' "  slope1=" %18.12f `s1'
display "meandose0=" %18.12f `m0' "  meandose1=" %18.12f `m1'
display "ANSWER: ineligible_effect estimate=" %18.12f `ine' " se=NA n_obs=" `N'
display "ANSWER: eligible_nonrecipient_effect estimate=" %18.12f `elig' " se=NA n_obs=" `N'
display "ANSWER: population_effect estimate=" %18.12f `pop' " se=NA n_obs=" `N'

mata:
X = st_data(., ("d0","d1","e0","e1","b0","b1"))
Z = st_data(., ("i0","i1","e0","e1","b0","b1"))
y = st_data(., "outcome")
w = st_data(., "weight")
d = st_data(., "dose")
el = st_data(., "eligible")
bb = luinv(Z'diag(w)*X)*(Z'diag(w)*y)
printf("MATA slope0=%18.12f slope1=%18.12f\n", bb[1], bb[2])
m0m = sum(w:*d:*(el:==0))/sum(w:*(el:==0))
m1m = sum(w:*d:*(el:==1))/sum(w:*(el:==1))
ine_m = bb[1]*m0m
elig_m = bb[2]*m1m
printf("MATA ineligible=%18.12f eligible=%18.12f\n", ine_m, elig_m)
printf("MATA population=%18.12f\n", (8400*ine_m+1600*elig_m)/10000)
end
