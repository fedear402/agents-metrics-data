clear all
set more off
set type double

import delimited using input.csv, clear stringcols(1)
tempfile in
save `in'
import delimited using crosswalk.csv, clear stringcols(1)
append using `in'
bysort code: assert industry == industry[1]
duplicates drop code, force
isid code
tempfile cw
save `cw'

import delimited using trade.csv, clear stringcols(2)
merge m:1 code using `cw'
assert _merge == 3
drop _merge
isid period industry
keep period industry us_change other_change price_index years
tempfile tr
save `tr'

import delimited using employment.csv, clear
tempfile emp
save `emp'

import delimited using areas.csv, clear
keep area period vintage total_employment population
expand 4
bysort area period vintage: gen industry = _n - 1
merge 1:1 area period vintage industry using `emp'
assert _merge != 2
drop _merge
replace employment = 0 if missing(employment)

merge m:1 period industry using `tr'
assert _merge == 3
drop _merge

egen double nat = total(employment), by(period vintage industry)
assert nat > 0
gen double ratio = employment / total_employment
gen double cx = ratio * us_change / nat / (price_index/100) / 1000 * (10/years)
gen double cz = ratio * other_change / nat / (price_index/100) / 1000 * (10/years)
gen double x = cx if vintage == "base"
gen double z = cz if vintage == "early"
gen double pop = population if vintage == "base"
collapse (sum) x z pop, by(area period)
tempfile expo
save `expo'

import delimited using outcomes.csv, clear
merge 1:1 area period using `expo'
assert _merge == 3
drop _merge
assert _N == 72

ivregress 2sls change_pp period control (x = z) [aw=pop]
local b = _b[x]
summarize x if area == 0 & period == 0, meanonly
local e0 = r(mean)
summarize x if area == 0 & period == 1, meanonly
local e1 = r(mean)
summarize z if area == 0 & period == 0, meanonly
local zz = r(mean)

display "ANSWER: iv_slope estimate=" %24.16g `b' " se=NA n_obs=" _N
display "ANSWER: exposure_area0_period0 estimate=" %24.16g `e0' " se=NA n_obs=" _N
display "ANSWER: exposure_area0_period1 estimate=" %24.16g `e1' " se=NA n_obs=" _N
display "ANSWER: instrument_area0_period0 estimate=" %24.16g `zz' " se=NA n_obs=" _N
exit, clear
