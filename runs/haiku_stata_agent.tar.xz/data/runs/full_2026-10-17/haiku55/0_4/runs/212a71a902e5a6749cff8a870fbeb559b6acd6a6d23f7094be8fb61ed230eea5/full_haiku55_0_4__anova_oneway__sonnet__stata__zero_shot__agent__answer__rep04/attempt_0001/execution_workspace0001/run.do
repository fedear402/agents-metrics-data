clear all
set more off
set linesize 255

import delimited using "input.csv", clear varnames(1) case(lower) stringcols(2)
gen double yval = real(y)
drop y
rename yval y

quietly count if !missing(y, group)
local n_obs = r(N)

quietly anova y group
scalar F_val  = e(F)
scalar df_n   = e(df_m)
scalar df_d   = e(df_r)
scalar p_val  = Ftail(df_n, df_d, F_val)

display "ANSWER: F estimate=" %21.12f F_val " se=. n_obs=" %12.0f `n_obs'
display "ANSWER: df_num estimate=" %21.12f df_n " se=. n_obs=" %12.0f `n_obs'
display "ANSWER: df_den estimate=" %21.12f df_d " se=. n_obs=" %12.0f `n_obs'
display "ANSWER: p_value estimate=" %21.12f p_val " se=. n_obs=" %12.0f `n_obs'
