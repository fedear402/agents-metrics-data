version 19.0
clear all
set more off
set linesize 255

import delimited using "input.csv", clear varnames(1) stringcols(1)
generate double day = date(date, "YMD")
sort day
generate long obs = _n
tsset obs

generate double lnvix = ln(vix)
generate double dlnvix = D.lnvix
local lagvars ""
forvalues k = 1/15 {
    generate double lag`k' = L`k'.dlnvix
    local lagvars `lagvars' lag`k'
}
generate double lnsales = ln(sales)

egen nmiss = rowmiss(lnsales dlnvix `lagvars')
keep if nmiss == 0

mata:
y = st_data(., "lnsales")
X = (J(st_nobs(), 1, 1), st_data(., tokens("`lagvars'")))
N = rows(X)
p = cols(X)
L = 15
b = qrsolve(X, y)
e = y - X * b
S = X :* e
meat = S' * S
for (j = 1; j <= L; j++) {
    G = S[|j+1, 1 \ N, p|]' * S[|1, 1 \ N-j, p|]
    meat = meat + (1 - j/(L+1)) * (G + G')
}
bread = invsym(X' * X)
V = N/(N-p) * bread * meat * bread
c = (0 \ J(15, 1, 1))
st_numscalar("cum", c' * b)
st_numscalar("cum_se", sqrt(c' * V * c))
st_numscalar("lag1_b", b[2])
st_numscalar("lag1_se", sqrt(V[2,2]))
st_numscalar("lag15_b", b[16])
st_numscalar("lag15_se", sqrt(V[16,16]))
st_numscalar("nobs", N)
end

display "ANSWER: cumulative_response estimate=" %21.12f cum " se=" %21.12f cum_se " n_obs=" %12.0f nobs
display "ANSWER: lag_1 estimate=" %21.12f lag1_b " se=" %21.12f lag1_se " n_obs=" %12.0f nobs
display "ANSWER: lag_15 estimate=" %21.12f lag15_b " se=" %21.12f lag15_se " n_obs=" %12.0f nobs
