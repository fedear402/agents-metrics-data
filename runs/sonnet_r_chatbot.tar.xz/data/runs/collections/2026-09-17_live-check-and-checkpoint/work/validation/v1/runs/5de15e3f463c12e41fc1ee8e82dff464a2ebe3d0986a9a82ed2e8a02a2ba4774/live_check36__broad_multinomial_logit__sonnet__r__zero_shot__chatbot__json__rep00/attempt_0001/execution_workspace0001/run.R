library(nnet)
library(jsonlite)

df <- read.csv("input.csv")
df$y <- factor(df$y, levels = c(0, 1, 2))

fit <- multinom(y ~ x + z, data = df, trace = FALSE)

coefs <- coef(fit)
vcov_mat <- vcov(fit)

x_cat1 <- coefs["1", "x"]
z_cat1 <- coefs["1", "z"]
x_cat2 <- coefs["2", "x"]
z_cat2 <- coefs["2", "z"]

se_x_cat1 <- sqrt(vcov_mat["1:x", "1:x"])
se_z_cat1 <- sqrt(vcov_mat["1:z", "1:z"])
se_x_cat2 <- sqrt(vcov_mat["2:x", "2:x"])
se_z_cat2 <- sqrt(vcov_mat["2:z", "2:z"])

newdata <- data.frame(x = 0, z = 0)
probs <- predict(fit, newdata = newdata, type = "probs")
prob_cat2_zero <- probs[1, "2"]

n <- nrow(df)

result <- list(
  task_id = "broad_multinomial_logit",
  platform = "r",
  estimates = list(
    list(term = "x_cat1", estimate = x_cat1, se = se_x_cat1, n_obs = n),
    list(term = "z_cat1", estimate = z_cat1, se = se_z_cat1, n_obs = n),
    list(term = "x_cat2", estimate = x_cat2, se = se_x_cat2, n_obs = n),
    list(term = "z_cat2", estimate = z_cat2, se = se_z_cat2, n_obs = n),
    list(term = "prob_cat2_zero", estimate = prob_cat2_zero, se = NULL, n_obs = n)
  ),
  method_metadata = list(
    estimator = "multinomial logit (nnet::multinom)",
    vcov = "observed information (default)"
  ),
  diagnostics = setNames(list(), character(0))
)

write(toJSON(result, auto_unbox = TRUE, digits = 10, null = "null"), "result.json")
