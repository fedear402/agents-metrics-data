library(jsonlite)

df <- read.csv("./input.csv")

cohorts <- c(4, 6, 8)
never <- df[df$cohort == -1, ]

att_cells <- c()
n_total <- 0

for (g in cohorts) {
  g_firms <- df[df$cohort == g, ]
  post_years <- (g):9
  
  for (t in post_years) {
    mean_gt <- mean(g_firms$y_did[g_firms$year == t])
    mean_g_pre <- mean(g_firms$y_did[g_firms$year == (g - 1)])
    
    mean_nt_t <- mean(never$y_did[never$year == t])
    mean_nt_pre <- mean(never$y_did[never$year == (g - 1)])
    
    cell_att <- (mean_gt - mean_g_pre) - (mean_nt_t - mean_nt_pre)
    att_cells <- c(att_cells, cell_att)
    n_total <- n_total + nrow(g_firms[g_firms$year == t, ])
  }
}

att_uniform <- mean(att_cells)

out <- list(
  task_id = "staggered_did",
  platform = "r",
  estimates = list(
    list(term = "att", estimate = att_uniform, se = NA, n_obs = n_total)
  ),
  method_metadata = list(
    estimator = "ATT_uniform from group-year cell means, equal-weight over cohort-time cells",
    vcov = "none"
  ),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "result.json", auto_unbox = TRUE)
