library(AER)
library(sandwich)
library(jsonlite)

# Read data
dat <- read.csv("input.csv")

# Get one obs per region for weights
regions <- unique(dat$region_id)
reg_dat <- dat[!duplicated(dat$region_id), c("region_id", "region_weight", "x", "y")]

# Normalize weights
reg_dat$e_r <- reg_dat$region_weight / sum(reg_dat$region_weight)

# Construct shift-share instrument z_r = sum_n share_rn * shock_n
z_r <- tapply(seq_len(nrow(dat)), dat$region_id, function(idx) {
  sum(dat$share[idx] * dat$shock[idx])
})
reg_dat$z <- z_r[as.character(reg_dat$region_id)]

# Weighted 2SLS: y on x, instrument z, weights e_r
iv_reg <- ivreg(y ~ x | z, data = reg_dat, weights = reg_dat$e_r)
regional_2sls_slope <- coef(iv_reg)["x"]

# First stage: x on z, weights e_r
fs_reg <- lm(x ~ z, data = reg_dat, weights = reg_dat$e_r)
regional_fs_slope <- coef(fs_reg)["z"]

# Subtract e_r-weighted means
wmean_y <- sum(reg_dat$e_r * reg_dat$y)
wmean_x <- sum(reg_dat$e_r * reg_dat$x)
wmean_z <- sum(reg_dat$e_r * reg_dat$z)

reg_dat$y0 <- reg_dat$y - wmean_y
reg_dat$x0 <- reg_dat$x - wmean_x
reg_dat$z0 <- reg_dat$z - wmean_z

# Merge e_r back to full data
dat$e_r <- reg_dat$e_r[match(dat$region_id, reg_dat$region_id)]
dat$y0 <- reg_dat$y0[match(dat$region_id, reg_dat$region_id)]
dat$x0 <- reg_dat$x0[match(dat$region_id, reg_dat$region_id)]
dat$z0 <- reg_dat$z0[match(dat$region_id, reg_dat$region_id)]

# For each industry n, s_n = sum_r e_r * share_rn
industries <- unique(dat$industry_id)
ind_dat <- data.frame(industry_id = industries)

s_n <- tapply(seq_len(nrow(dat)), dat$industry_id, function(idx) {
  sum(dat$e_r[idx] * dat$share[idx])
})
ind_dat$s_n <- s_n[as.character(ind_dat$industry_id)]

# Aggregate residuals: vbar_n = sum_r e_r * share_rn * v0_r / s_n
agg_resid <- function(v0_col) {
  tapply(seq_len(nrow(dat)), dat$industry_id, function(idx) {
    sum(dat$e_r[idx] * dat$share[idx] * dat[[v0_col]][idx])
  }) / s_n
}

ind_dat$ybar <- agg_resid("y0")[as.character(ind_dat$industry_id)]
ind_dat$xbar <- agg_resid("x0")[as.character(ind_dat$industry_id)]
ind_dat$zbar <- agg_resid("z0")[as.character(ind_dat$industry_id)]

# Get shock for each industry (constant within industry)
shock_n <- tapply(dat$shock, dat$industry_id, function(x) x[1])
ind_dat$shock <- shock_n[as.character(ind_dat$industry_id)]

N <- nrow(ind_dat)

# Shock-level IV for effect: ybar on xbar, instrument shock_n, weights s_n
iv_shock <- ivreg(ybar ~ xbar | shock, data = ind_dat, weights = ind_dat$s_n)

# HC1 SE: variance multiplier N/(N-2)
# Use structural IV residuals
beta_iv <- coef(iv_shock)["xbar"]
alpha_iv <- coef(iv_shock)["(Intercept)"]
iv_resid <- ind_dat$ybar - alpha_iv - beta_iv * ind_dat$xbar

# Manual HC1 for shock-level IV
# X matrix (endogenous), Z matrix (instrument)
X_mat <- cbind(1, ind_dat$xbar)
Z_mat <- cbind(1, ind_dat$shock)
W <- diag(ind_dat$s_n)

# 2SLS formula: beta = (Z'WX)^{-1} Z'Wy
ZWX <- t(Z_mat) %*% W %*% X_mat
ZWZ <- t(Z_mat) %*% W %*% Z_mat
ZWy <- t(Z_mat) %*% W %*% ind_dat$ybar

# HC1 sandwich variance for IV
# V = (Z'WX)^{-1} * (sum_n s_n^2 * z_n * u_n^2 * z_n') * (X'WZ)^{-1} * N/(N-2)
# where z_n is row of Z, u_n is structural residual

meat <- matrix(0, 2, 2)
for (i in 1:N) {
  z_i <- Z_mat[i, , drop = FALSE]
  meat <- meat + ind_dat$s_n[i]^2 * iv_resid[i]^2 * t(z_i) %*% z_i  # wait, need to weight properly
}

# Actually for weighted IV with analytic weights:
# Score for obs i: s_n[i] * z_i * u_i
# Meat = sum_i (s_n[i] * z_i * u_i)^2 ... no
# Standard HC1 for weighted IV:
# Each "score" contribution: w_i * Z_i * u_i
# Meat = sum_i (w_i * Z_i * u_i)(w_i * Z_i * u_i)'
# But then need to normalize properly

# Let's use sandwich manually
# V(beta_IV) = (Z'WX)^{-1} [sum_i w_i^2 * z_i z_i' * u_i^2] (X'WZ)^{-T} * N/(N-2)

meat2 <- matrix(0, 2, 2)
for (i in 1:N) {
  z_i <- Z_mat[i, , drop = FALSE]
  meat2 <- meat2 + ind_dat$s_n[i]^2 * iv_resid[i]^2 * t(z_i) %*% z_i
}

ZWX_inv <- solve(ZWX)
V_iv <- ZWX_inv %*% meat2 %*% t(ZWX_inv) * (N / (N - 2))
se_effect <- sqrt(V_iv[2, 2])

# First stage shock-level: xbar on zbar, instrument shock, weights s_n
# zbar is endogenous regressor, shock is instrument
iv_fs_shock <- ivreg(xbar ~ zbar | shock, data = ind_dat, weights = ind_dat$s_n)
beta_fs <- coef(iv_fs_shock)["zbar"]
alpha_fs <- coef(iv_fs_shock)["(Intercept)"]
fs_resid <- ind_dat$xbar - alpha_fs - beta_fs * ind_dat$zbar

X_fs <- cbind(1, ind_dat$zbar)
Z_fs <- cbind(1, ind_dat$shock)

meat_fs <- matrix(0, 2, 2)
for (i in 1:N) {
  z_i <- Z_fs[i, , drop = FALSE]
  meat_fs <- meat_fs + ind_dat$s_n[i]^2 * fs_resid[i]^2 * t(z_i) %*% z_i
}

ZWX_fs <- t(Z_fs) %*% W %*% X_fs
ZWX_fs_inv <- solve(ZWX_fs)
V_fs <- ZWX_fs_inv %*% meat_fs %*% t(ZWX_fs_inv) * (N / (N - 2))
se_fs <- sqrt(V_fs[2, 2])

# Effective shocks
effective_shocks <- 1 / sum(ind_dat$s_n^2)

# Build result
result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = as.numeric(regional_2sls_slope), se = as.numeric(se_effect), n_obs = as.integer(N)),
    list(term = "first_stage", estimate = as.numeric(regional_fs_slope), se = as.numeric(se_fs), n_obs = as.integer(N)),
    list(term = "effective_shocks", estimate = as.numeric(effective_shocks), se = NULL, n_obs = as.integer(N))
  ),
  method_metadata = list(
    estimator = "2SLS shift-share with BHJ exposure-robust SE",
    vcov = "HC1 shock-level"
  ),
  diagnostics = list()
)

write(toJSON(result, auto_unbox = TRUE, null = "null", digits = 10), "result.json")
