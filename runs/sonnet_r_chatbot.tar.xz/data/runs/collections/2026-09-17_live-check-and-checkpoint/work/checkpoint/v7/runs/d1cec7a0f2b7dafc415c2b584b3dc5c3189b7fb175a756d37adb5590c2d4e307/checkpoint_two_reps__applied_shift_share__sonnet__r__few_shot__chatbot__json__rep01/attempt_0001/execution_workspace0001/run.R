library(jsonlite)

dat <- read.csv("input.csv", stringsAsFactors = FALSE)

# Normalize regional weights (one obs per region)
regions <- unique(dat[, c("region_id", "region_weight", "x", "y")])
regions$e_r <- regions$region_weight / sum(regions$region_weight)

# Merge normalized weights back
dat <- merge(dat, regions[, c("region_id", "e_r")], by = "region_id")

# Construct shift-share instrument z_r = sum_n share_rn * shock_n
dat$share_shock <- dat$share * dat$shock
z_by_region <- aggregate(share_shock ~ region_id, data = dat, FUN = sum)
names(z_by_region)[2] <- "z_r"
regions <- merge(regions, z_by_region, by = "region_id")

# Weighted means
wmean <- function(x, w) sum(w * x) / sum(w)
e <- regions$e_r
mean_y <- wmean(regions$y, e)
mean_x <- wmean(regions$x, e)
mean_z <- wmean(regions$z_r, e)

# Demeaned residuals
regions$y0 <- regions$y - mean_y
regions$x0 <- regions$x - mean_x
regions$z0 <- regions$z_r - mean_z

# Industries
industries <- unique(dat$industry_id)
N <- length(industries)

# Compute s_n and aggregated residuals
s_n <- numeric(N)
ybar_n <- numeric(N)
xbar_n <- numeric(N)
zbar_n <- numeric(N)
shock_n <- numeric(N)

for (i in seq_along(industries)) {
  ind <- industries[i]
  sub <- dat[dat$industry_id == ind, ]
  # Merge e_r and residuals
  sub <- merge(sub, regions[, c("region_id", "e_r", "y0", "x0", "z0")], by = "region_id")
  s <- sum(sub$e_r * sub$share)
  s_n[i] <- s
  ybar_n[i] <- sum(sub$e_r * sub$share * sub$y0) / s
  xbar_n[i] <- sum(sub$e_r * sub$share * sub$x0) / s
  zbar_n[i] <- sum(sub$e_r * sub$share * sub$z0) / s
  shock_n[i] <- sub$shock[1]
}

# Shock-level IV regression function
# Dependent: dep, Endogenous: endo, Instrument: shock_n, Weights: s_n
shock_iv <- function(dep, endo, instr, wt) {
  regressors <- cbind(1, endo)
  instruments <- cbind(1, instr)
  W <- diag(wt)
  # IV estimator: beta = (Z'WX)^{-1} Z'Wy
  ZW <- t(instruments) %*% W
  beta <- solve(ZW %*% regressors, ZW %*% dep)
  # Structural residuals
  resid <- dep - regressors %*% beta
  # HC1 sandwich variance: N/(N-2) * (Z'WX)^{-1} * sum_n s_n^2 * z_n * z_n' * resid_n^2 * (Z'WX)^{-T}
  n <- length(dep)
  scores <- instruments * (wt * as.vector(resid))
  ZWX_inv <- solve(ZW %*% regressors)
  meat <- t(scores) %*% scores
  vcov <- n / (n - 2) * ZWX_inv %*% meat %*% t(ZWX_inv)
  list(slope = beta[2], se = sqrt(vcov[2, 2]))
}

# Effect: IV of ybar on xbar, instrument shock_n
effect <- shock_iv(ybar_n, xbar_n, shock_n, s_n)

# First stage: IV of xbar on zbar, instrument shock_n (zbar is endogenous)
first_stage <- shock_iv(xbar_n, zbar_n, shock_n, s_n)

# Effective shocks
effective_shocks <- 1 / sum(s_n^2)

# Build result
result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = unname(as.numeric(effect$slope)),
         se = unname(as.numeric(effect$se)), n_obs = as.integer(N)),
    list(term = "first_stage", estimate = unname(as.numeric(first_stage$slope)),
         se = unname(as.numeric(first_stage$se)), n_obs = as.integer(N)),
    list(term = "effective_shocks", estimate = unname(as.numeric(effective_shocks)),
         se = NULL, n_obs = as.integer(N))
  ),
  method_metadata = list(
    estimator = "shock-level IV (Borusyak-Hull-Jaravel)",
    vcov = "HC1 exposure-robust, N/(N-2) multiplier"
  ),
  diagnostics = setNames(list(), character(0))
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
