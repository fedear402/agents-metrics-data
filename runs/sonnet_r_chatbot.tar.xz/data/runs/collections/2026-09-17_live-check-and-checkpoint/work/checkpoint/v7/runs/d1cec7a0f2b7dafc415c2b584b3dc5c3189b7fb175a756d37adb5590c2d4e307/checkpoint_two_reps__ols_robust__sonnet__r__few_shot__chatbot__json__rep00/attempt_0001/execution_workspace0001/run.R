library(sandwich)
library(lmtest)
library(jsonlite)

df <- read.csv("./input.csv")
fit <- lm(y_lin ~ x1 + x2, data = df)
co <- coeftest(fit, vcov = vcovHC(fit, type = "HC1"))

out <- list(
  task_id = "ols_robust",
  platform = "r",
  estimates = list(
    list(term = "const", estimate = unname(co["(Intercept)", "Estimate"]),
         se = unname(co["(Intercept)", "Std. Error"]), n_obs = nrow(df)),
    list(term = "x1", estimate = unname(co["x1", "Estimate"]),
         se = unname(co["x1", "Std. Error"]), n_obs = nrow(df)),
    list(term = "x2", estimate = unname(co["x2", "Estimate"]),
         se = unname(co["x2", "Std. Error"]), n_obs = nrow(df))
  ),
  method_metadata = list(estimator = "OLS", vcov = "HC1"),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "result.json", auto_unbox = TRUE, digits = 10)
