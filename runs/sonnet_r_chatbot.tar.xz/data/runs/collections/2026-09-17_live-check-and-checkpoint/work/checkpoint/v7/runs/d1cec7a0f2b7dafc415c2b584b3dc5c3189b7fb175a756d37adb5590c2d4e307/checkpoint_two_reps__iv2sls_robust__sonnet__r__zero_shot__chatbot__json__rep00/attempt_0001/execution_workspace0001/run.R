library(AER)
library(sandwich)
library(lmtest)
library(jsonlite)

dat <- read.csv("./input.csv")

fit <- ivreg(y_iv ~ x1_iv | z, data = dat)

vcov_hc1 <- vcovHC(fit, type = "HC1")
coef_test <- coeftest(fit, vcov = vcov_hc1)

n_obs <- nobs(fit)

estimates <- list(
  list(term = "const",  estimate = unname(coef_test["(Intercept)", "Estimate"]),
       se = unname(coef_test["(Intercept)", "Std. Error"]), n_obs = n_obs),
  list(term = "x1_iv",  estimate = unname(coef_test["x1_iv", "Estimate"]),
       se = unname(coef_test["x1_iv", "Std. Error"]), n_obs = n_obs)
)

result <- list(
  task_id = "iv2sls_robust",
  platform = "r",
  estimates = estimates,
  method_metadata = list(estimator = "AER::ivreg 2SLS", vcov = "HC1"),
  diagnostics = setNames(list(), character(0))
)

write(toJSON(result, auto_unbox = TRUE, digits = 10), "result.json")
