library(AER)
library(sandwich)
library(jsonlite)

df <- read.csv("input.csv")

# One obs per region
regions <- unique(df[, c("region_id", "region_weight", "x", "y")])
regions$e_r <- regions$region_weight / sum(regions$region_weight)

# Construct shift-share instrument z_r = sum_n share_rn * shock_n
shocks <- unique(df[, c("industry_id", "shock")])
df2 <- merge(df, shocks, by = "industry_id", all.x = TRUE)
z_agg <- aggregate(share * shock ~ region_id, data = df2, FUN = sum)
colnames(z_agg) <- c("region_id", "z")
regions <- merge(regions, z_agg, by = "region_id")

# Weighted means
wmean <- function(v, w) sum(v * w) / sum(w)
mu_y <- wmean(regions$y, regions$e_r)
mu_x <- wmean(regions$x, regions$e_r)
mu_z <- wmean(regions$z, regions$e_r)

regions$y0 <- regions$y - mu_y
regions$x0 <- regions$x - mu_x
regions$z0 <- regions$z - mu_z

# For each industry n, s_n = sum_r e_r * share_rn
# Merge e_r into main df
df3 <- merge(df, regions[, c("region_id", "e_r", "y0", "x0", "z0")], by = "region_id")
df3$e_share <- df3$e_r * df3$share

s_n <- aggregate(e_share ~ industry_id, data = df3, FUN = sum)
colnames(s_n) <- c("industry_id", "s_n")

# vbar_n = sum_r e_r * share_rn * v0_r / s_n
df3$ey_share <- df3$e_r * df3$share * df3$y0
df3$ex_share <- df3$e_r * df3$share * df3$x0
df3$ez_share <- df3$e_r * df3$share * df3$z0

ybar_n <- aggregate(ey_share ~ industry_id, data = df3, FUN = sum)
xbar_n <- aggregate(ex_share ~ industry_id, data = df3, FUN = sum)
zbar_n <- aggregate(ez_share ~ industry_id, data = df3, FUN = sum)

shock_df <- merge(s_n, shocks, by = "industry_id")
shock_df <- merge(shock_df, ybar_n, by = "industry_id")
shock_df <- merge(shock_df, xbar_n, by = "industry_id")
shock_df <- merge(shock_df, zbar_n, by = "industry_id")

shock_df$ybar <- shock_df$ey_share / shock_df$s_n
shock_df$xbar <- shock_df$ex_share / shock_df$s_n
shock_df$zbar <- shock_df$ez_share / shock_df$s_n

N <- nrow(shock_df)

# Effect: IV regression ybar ~ xbar, instrumented by shock, weighted by s_n
iv_effect <- ivreg(ybar ~ xbar | shock, data = shock_df, weights = shock_df$s_n)
# HC1 with N/(N-2) multiplier
# sandwich vcovHC with HC1 uses n/(n-k) correction where k=2 here
vc_effect <- vcovHC(iv_effect, type = "HC1")
se_effect <- sqrt(vc_effect["xbar", "xbar"])
beta_effect <- coef(iv_effect)["xbar"]

# First stage: IV regression xbar ~ zbar, instrumented by shock, weighted by s_n
iv_fs <- ivreg(xbar ~ zbar | shock, data = shock_df, weights = shock_df$s_n)
vc_fs <- vcovHC(iv_fs, type = "HC1")
se_fs <- sqrt(vc_fs["zbar", "zbar"])
beta_fs <- coef(iv_fs)["zbar"]

# Effective shocks
effective_shocks <- 1 / sum(shock_df$s_n^2)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = as.numeric(beta_effect), se = as.numeric(se_effect), n_obs = as.integer(N)),
    list(term = "first_stage", estimate = as.numeric(beta_fs), se = as.numeric(se_fs), n_obs = as.integer(N)),
    list(term = "effective_shocks", estimate = as.numeric(effective_shocks), se = NULL, n_obs = as.integer(N))
  ),
  method_metadata = list(
    estimator = "2SLS shift-share with exposure-robust Borusyak-Hull-Jaravel SEs",
    vcov = "HC1"
  ),
  diagnostics = setNames(list(), character(0))
)

write(toJSON(result, auto_unbox = TRUE, null = "null", digits = 10), "result.json")
