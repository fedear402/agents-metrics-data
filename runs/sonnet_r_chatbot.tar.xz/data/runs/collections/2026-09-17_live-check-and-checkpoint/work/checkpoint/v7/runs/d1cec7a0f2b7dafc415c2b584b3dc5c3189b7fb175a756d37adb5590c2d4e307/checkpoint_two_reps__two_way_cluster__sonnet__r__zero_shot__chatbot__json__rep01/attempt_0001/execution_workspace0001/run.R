library(sandwich)
library(lmtest)
library(jsonlite)

data <- read.csv("./input.csv")

fit <- lm(y_twocluster ~ x, data = data)

vcov_twoway <- function(model, cluster1, cluster2) {
  X <- model.matrix(model)
  e <- residuals(model)
  n <- nrow(X)
  k <- ncol(X)
  
  meat_cluster <- function(cl) {
    cls <- unique(cl)
    m <- length(cls)
    S <- matrix(0, k, k)
    for (c in cls) {
      idx <- which(cl == c)
      Xc <- X[idx, , drop = FALSE]
      ec <- e[idx]
      sc <- colSums(Xc * ec)
      S <- S + outer(sc, sc)
    }
    m / (m - 1) * (n - 1) / (n - k) * S
  }
  
  meat_intersection <- function(cl1, cl2) {
    cl_int <- paste(cl1, cl2, sep = "_")
    meat_cluster(cl_int)
  }
  
  bread <- solve(crossprod(X))
  
  M1 <- meat_cluster(cluster1)
  M2 <- meat_cluster(cluster2)
  M12 <- meat_intersection(cluster1, cluster2)
  
  V <- bread %*% (M1 + M2 - M12) %*% bread
  V
}

vcov_cgm <- vcov_twoway(fit, data$firm, data$year)

coefs <- coef(fit)
ses <- sqrt(diag(vcov_cgm))
n_obs <- nobs(fit)

result <- list(
  task_id = "two_way_cluster",
  platform = "r",
  estimates = list(
    list(term = "const", estimate = unname(coefs["(Intercept)"]), se = unname(ses["(Intercept)"]), n_obs = n_obs),
    list(term = "x", estimate = unname(coefs["x"]), se = unname(ses["x"]), n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "OLS",
    vcov = "Cameron-Gelbach-Miller two-way cluster-robust"
  ),
  diagnostics = setNames(list(), character(0))
)

write(toJSON(result, auto_unbox = TRUE, digits = 10), "./result.json")
