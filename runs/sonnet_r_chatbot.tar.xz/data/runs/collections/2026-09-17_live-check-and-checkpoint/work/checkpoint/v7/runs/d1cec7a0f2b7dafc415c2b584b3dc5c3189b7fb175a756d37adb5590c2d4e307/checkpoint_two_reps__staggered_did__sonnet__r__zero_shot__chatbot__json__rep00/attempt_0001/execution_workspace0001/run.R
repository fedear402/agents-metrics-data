library(jsonlite)

df <- read.csv("./input.csv")

cohorts <- c(4, 6, 8)
never <- df[df$cohort == -1, ]

att_cells <- c()
n_obs_total <- 0

for (g in cohorts) {
  treated <- df[df$cohort == g, ]
  pre_year <- g - 1
  post_years <- (g):9
  
  for (t in post_years) {
    mean_treat_t   <- mean(treated$y_did[treated$year == t])
    mean_treat_pre <- mean(treated$y_did[treated$year == pre_year])
    mean_never_t   <- mean(never$y_did[never$year == t])
    mean_never_pre <- mean(never$y_did[never$year == pre_year])
    
    att_cell <- (mean_treat_t - mean_treat_pre) - (mean_never_t - mean_never_pre)
    att_cells <- c(att_cells, att_cell)
    n_obs_total <- n_obs_total + nrow(treated[treated$year == t, ]) + nrow(never[never$year == t, ])
  }
}

att_uniform <- mean(att_cells)

total_n <- nrow(df)

result <- list(
  task_id = "staggered_did",
  platform = "r",
  estimates = list(
    list(term = "att", estimate = att_uniform, se = NULL, n_obs = total_n)
  ),
  method_metadata = list(
    estimator = "Callaway-Sant'Anna ATT_uniform (manual group-year means)",
    vcov = "none"
  ),
  diagnostics = setNames(list(), character(0))
)

write(toJSON(result, auto_unbox = TRUE, null = "null", digits = 10), "./result.json")
