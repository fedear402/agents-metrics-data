library(jsonlite)

d <- read.csv("input.csv")
n <- nrow(d)

y <- d$y
endog <- d$endog
x <- d$x
z1 <- d$z1
z2 <- d$z2

q <- 2L
df <- n - 4L  # n - (intercept + x + z1 + z2)
critical <- qf(0.95, q, df)

# Unrestricted residuals: regress on intercept, x, z1, z2
full_fit_y <- lm(y ~ x + z1 + z2)
full_fit_e <- lm(endog ~ x + z1 + z2)
uy <- residuals(full_fit_y)
ud <- residuals(full_fit_e)

# For AR inversion:
# F(beta) = ((SSR_R(beta) - SSR_U(beta)) / q) / (SSR_U(beta) / df)
# Accept when F <= critical, i.e.:
# SSR_R(beta) - SSR_U(beta) <= (q * critical / df) * SSR_U(beta)
# SSR_R(beta) - (1 + k) * SSR_U(beta) <= 0
# where transformed = y - beta * endog, restricted regression on intercept + x
# unrestricted regression on intercept + x + z1 + z2

# Restricted residuals: regress transformed on intercept + x
# transformed = y - beta*endog
# residuals of (y - beta*endog) ~ intercept + x
# = residuals(y ~ intercept + x) - beta * residuals(endog ~ intercept + x)

ry <- residuals(lm(y ~ x))
rd <- residuals(lm(endog ~ x))

# SSR_R(beta) = sum((ry - beta*rd)^2)
# SSR_U(beta) = sum((uy - beta*ud)^2)

# Condition: SSR_R - (1+k)*SSR_U <= 0
k <- q * critical / df

# A*beta^2 + B*beta + C <= 0
A <- sum(rd^2) - (1 + k) * sum(ud^2)
B <- -2 * (sum(ry * rd) - (1 + k) * sum(uy * ud))
C <- sum(ry^2) - (1 + k) * sum(uy^2)

disc <- B^2 - 4 * A * C
bounds <- sort(Re(polyroot(c(C, B, A))))

unbounded <- as.integer(A < 0)

accepts <- function(beta) A * beta^2 + B * beta + C <= 0

# Compute F at beta = 1
beta_test <- 1.0
transformed_1 <- y - beta_test * endog
restricted_1 <- lm(transformed_1 ~ x)
full_1 <- lm(transformed_1 ~ x + z1 + z2)
ar_f_at_one <- ((deviance(restricted_1) - deviance(full_1)) / q) / (deviance(full_1) / df)

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = list(
    list(term = "boundary_low", estimate = unname(bounds[1]), se = NULL, n_obs = n),
    list(term = "boundary_high", estimate = unname(bounds[2]), se = NULL, n_obs = n),
    list(term = "accepts_zero", estimate = unname(as.integer(accepts(0))), se = NULL, n_obs = n),
    list(term = "unbounded", estimate = unname(unbounded), se = NULL, n_obs = n),
    list(term = "ar_f_at_one", estimate = unname(ar_f_at_one), se = NULL, n_obs = n)
  ),
  method_metadata = list(estimator = "Anderson-Rubin", vcov = "homoskedastic"),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
