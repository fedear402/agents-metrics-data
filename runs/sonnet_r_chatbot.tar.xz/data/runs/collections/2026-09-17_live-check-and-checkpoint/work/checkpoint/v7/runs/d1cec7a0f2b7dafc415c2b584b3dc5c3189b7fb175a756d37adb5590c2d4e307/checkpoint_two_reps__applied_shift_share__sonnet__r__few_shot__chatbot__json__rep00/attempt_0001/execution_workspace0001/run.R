library(jsonlite)

df <- read.csv("input.csv")

# Normalize regional weights (one obs per region)
regions <- unique(df[, c("region_id", "region_weight", "x", "y")])
total_weight <- sum(regions$region_weight)
regions$e_r <- regions$region_weight / total_weight

# Merge normalized weights back
df <- merge(df, regions[, c("region_id", "e_r")], by = "region_id")

# Construct shift-share instrument z_r = sum_n share_rn * shock_n
# shock is constant within industry, shares sum to 1 within region
instrument <- aggregate(share * shock ~ region_id, data = df, FUN = sum)
names(instrument)[2] <- "z_r"
regions <- merge(regions, instrument, by = "region_id")

# Weighted means
wmean <- function(v, w) sum(v * w) / sum(w)
mean_y <- wmean(regions$y, regions$e_r)
mean_x <- wmean(regions$x, regions$e_r)
mean_z <- wmean(regions$z_r, regions$e_r)

# Demeaned variables
regions$y0 <- regions$y - mean_y
regions$x0 <- regions$x - mean_x
regions$z0 <- regions$z_r - mean_z

# Merge demeaned back to df for aggregation
df <- merge(df, regions[, c("region_id", "y0", "x0", "z0", "e_r")], by = "region_id", suffixes = c("", ".reg"))

# Industry-level aggregation: s_n and vbar_n
industries <- unique(df$industry_id)
N <- length(industries)

ind_agg <- do.call(rbind, lapply(industries, function(n) {
  sub <- df[df$industry_id == n, ]
  s_n <- sum(sub$e_r * sub$share)
  ybar <- sum(sub$e_r * sub$share * sub$y0) / s_n
  xbar <- sum(sub$e_r * sub$share * sub$x0) / s_n
  zbar <- sum(sub$e_r * sub$share * sub$z0) / s_n
  shock_n <- sub$shock[1]
  data.frame(industry_id = n, s_n = s_n, ybar = ybar, xbar = xbar, zbar = zbar, shock_n = shock_n)
}))

# Shock-level IV regression function
shock_iv <- function(dependent, endogenous, instrument_var, weights) {
  regressors <- cbind(1, endogenous)
  instruments <- cbind(1, instrument_var)
  W <- weights
  
  cross <- t(instruments) %*% (W * regressors)
  beta <- solve(cross, t(instruments) %*% (W * dependent))
  
  residual <- drop(dependent - regressors %*% beta)
  scores <- instruments * (W * residual)
  inverse <- solve(cross)
  
  covariance <- N / (N - 2) * inverse %*% t(scores) %*% scores %*% t(inverse)
  
  c(slope = beta[2], se = sqrt(covariance[2, 2]))
}

# Effect: IV of ybar on xbar, instrument = shock_n, weights = s_n
effect <- shock_iv(ind_agg$ybar, ind_agg$xbar, ind_agg$shock_n, ind_agg$s_n)

# First stage: IV of xbar on zbar, instrument = shock_n, weights = s_n
first_stage <- shock_iv(ind_agg$xbar, ind_agg$zbar, ind_agg$shock_n, ind_agg$s_n)

# Effective shocks
effective_shocks <- 1 / sum(ind_agg$s_n^2)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = unname(as.numeric(effect["slope"])),
         se = unname(as.numeric(effect["se"])), n_obs = as.integer(N)),
    list(term = "first_stage", estimate = unname(as.numeric(first_stage["slope"])),
         se = unname(as.numeric(first_stage["se"])), n_obs = as.integer(N)),
    list(term = "effective_shocks", estimate = unname(as.numeric(effective_shocks)),
         se = NULL, n_obs = as.integer(N))
  ),
  method_metadata = list(
    estimator = "shift-share IV with shock-level aggregation",
    vcov = "HC1 exposure-robust (BHJ)"
  ),
  diagnostics = setNames(list(), character(0))
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
