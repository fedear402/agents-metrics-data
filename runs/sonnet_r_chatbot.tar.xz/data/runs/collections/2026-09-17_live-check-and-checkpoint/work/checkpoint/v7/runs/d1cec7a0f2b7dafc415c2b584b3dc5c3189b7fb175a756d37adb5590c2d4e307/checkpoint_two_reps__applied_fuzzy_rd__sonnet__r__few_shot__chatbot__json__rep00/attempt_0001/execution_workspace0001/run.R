library(jsonlite)

dat <- read.csv("input.csv")
names(dat) <- trimws(names(dat))

bw <- 1
in_bw <- abs(dat$score) < bw
dat_bw <- dat[in_bw, ]
n_obs <- nrow(dat_bw)

w <- 1 - abs(dat_bw$score)
above <- as.integer(dat_bw$score >= 0)

X <- cbind(1, above, dat_bw$score, dat_bw$score * above)

bread <- solve(crossprod(X, w * X))

coef_earn <- bread %*% crossprod(X, w * dat_bw$earnings)
coef_part <- bread %*% crossprod(X, w * dat_bw$participated)

resid_earn <- dat_bw$earnings - X %*% coef_earn
resid_part <- dat_bw$participated - X %*% coef_part

contrast <- c(0, 1, 0, 0)

jump_earn <- drop(contrast %*% coef_earn)
jump_part <- drop(contrast %*% coef_part)

loading <- w * drop(X %*% bread %*% contrast)

infl_earn <- loading * resid_earn
infl_part <- loading * resid_part

V11 <- sum(infl_earn^2)
V22 <- sum(infl_part^2)
V12 <- sum(infl_earn * infl_part)

se_earn <- sqrt(V11)
se_part <- sqrt(V22)

g1 <- 1 / jump_part
g2 <- -jump_earn / jump_part^2
se_te <- sqrt(g1^2 * V11 + g2^2 * V22 + 2 * g1 * g2 * V12)

te <- jump_earn / jump_part

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = unname(te), se = unname(se_te), n_obs = as.integer(n_obs)),
    list(term = "reduced_form", estimate = unname(jump_earn), se = unname(se_earn), n_obs = as.integer(n_obs)),
    list(term = "first_stage", estimate = unname(jump_part), se = unname(se_part), n_obs = as.integer(n_obs))
  ),
  method_metadata = list(estimator = "fuzzy_rd_local_linear", vcov = "HC0"),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, digits = 16, pretty = TRUE)
