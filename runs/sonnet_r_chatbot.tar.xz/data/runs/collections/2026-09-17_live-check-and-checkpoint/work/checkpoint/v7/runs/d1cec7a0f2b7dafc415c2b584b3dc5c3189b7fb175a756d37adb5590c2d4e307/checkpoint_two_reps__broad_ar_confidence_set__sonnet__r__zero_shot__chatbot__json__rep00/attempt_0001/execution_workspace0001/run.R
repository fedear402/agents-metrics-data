library(jsonlite)

data <- read.csv("input.csv")
n <- nrow(data)
y <- data$y
endog <- data$endog
x <- data$x
z1 <- data$z1
z2 <- data$z2

ar_f <- function(beta) {
  y_adj <- y - beta * endog
  fit <- lm(y_adj ~ x + z1 + z2)
  fit_r <- lm(y_adj ~ x)
  rss_r <- sum(residuals(fit_r)^2)
  rss_u <- sum(residuals(fit)^2)
  f <- ((rss_r - rss_u) / 2) / (rss_u / (n - 4))
  f
}

crit <- qf(0.95, 2, n - 4)

ar_f_at_one <- ar_f(1)

# The AR F statistic as a function of beta is a quadratic in beta
# F(beta) = (RSS_r(beta) - RSS_u(beta))/2 / (RSS_u(beta)/(n-4))
# Find boundary points where F(beta) = crit

# Scan over a grid to find roots
betas <- seq(-1000, 1000, by = 0.01)
f_vals <- sapply(betas, ar_f)

# Find sign changes of (f_vals - crit)
diff_vals <- f_vals - crit

# Find crossings
crossings <- which(diff(sign(diff_vals)) != 0)

# Refine each crossing with uniroot
boundaries <- c()
for (idx in crossings) {
  b_lo <- betas[idx]
  b_hi <- betas[idx + 1]
  root <- uniroot(function(b) ar_f(b) - crit, lower = b_lo, upper = b_hi, tol = 1e-10)
  boundaries <- c(boundaries, root$root)
}

# Sort boundaries
boundaries <- sort(boundaries)

# Check if the set is unbounded by checking behavior at extreme betas
f_at_extreme_pos <- ar_f(1e6)
f_at_extreme_neg <- ar_f(-1e6)
unbounded <- as.numeric(f_at_extreme_pos <= crit | f_at_extreme_neg <= crit)

# Determine boundary_low and boundary_high
if (length(boundaries) >= 2) {
  boundary_low <- boundaries[1]
  boundary_high <- boundaries[length(boundaries)]
} else if (length(boundaries) == 1) {
  boundary_low <- boundaries[1]
  boundary_high <- boundaries[1]
} else {
  boundary_low <- NA
  boundary_high <- NA
}

# Check if zero is in the confidence set
accepts_zero <- as.numeric(ar_f(0) <= crit)

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = list(
    list(term = "boundary_low", estimate = boundary_low, se = NULL, n_obs = n),
    list(term = "boundary_high", estimate = boundary_high, se = NULL, n_obs = n),
    list(term = "accepts_zero", estimate = accepts_zero, se = NULL, n_obs = n),
    list(term = "unbounded", estimate = unbounded, se = NULL, n_obs = n),
    list(term = "ar_f_at_one", estimate = ar_f_at_one, se = NULL, n_obs = n)
  ),
  method_metadata = list(
    estimator = "Anderson-Rubin test inversion",
    vcov = "homoskedastic"
  ),
  diagnostics = list()
)

write(toJSON(result, auto_unbox = TRUE, digits = 10, null = "null"), "result.json")
