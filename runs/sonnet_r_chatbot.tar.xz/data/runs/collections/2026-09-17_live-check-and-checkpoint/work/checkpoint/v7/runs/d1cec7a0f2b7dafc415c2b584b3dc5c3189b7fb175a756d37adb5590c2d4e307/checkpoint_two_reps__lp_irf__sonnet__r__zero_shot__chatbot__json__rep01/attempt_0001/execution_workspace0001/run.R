library(sandwich)
library(lmtest)
library(jsonlite)

data <- read.csv("./input.csv")

# Create lead of y by 4 periods
n <- nrow(data)
data$y_lead4 <- c(data$y[5:n], rep(NA, 4))
# Create lag of y by 1 period
data$y_lag1 <- c(NA, data$y[1:(n-1)])

# Drop rows with NAs
df <- na.omit(data[, c("y_lead4", "shock", "y_lag1")])

# Estimate local projection: y_{t+4} ~ 1 + shock_t + y_{t-1}
mod <- lm(y_lead4 ~ shock + y_lag1, data = df)

# Newey-West standard errors with lag 4
nw_vcov <- NeweyWest(mod, lag = 4, prewhite = FALSE)
ct <- coeftest(mod, vcov = nw_vcov)

# Extract shock coefficient (irf_h4)
estimate <- ct["shock", "Estimate"]
se <- ct["shock", "Std. Error"]
n_obs <- nrow(df)

result <- list(
  task_id = "lp_irf",
  platform = "r",
  estimates = list(
    list(term = "irf_h4", estimate = as.numeric(estimate), se = as.numeric(se), n_obs = as.integer(n_obs))
  ),
  method_metadata = list(estimator = "OLS local projection", vcov = "Newey-West (lag=4)"),
  diagnostics = setNames(list(), character(0))
)

write(toJSON(result, auto_unbox = TRUE, digits = 10), "./result.json")
