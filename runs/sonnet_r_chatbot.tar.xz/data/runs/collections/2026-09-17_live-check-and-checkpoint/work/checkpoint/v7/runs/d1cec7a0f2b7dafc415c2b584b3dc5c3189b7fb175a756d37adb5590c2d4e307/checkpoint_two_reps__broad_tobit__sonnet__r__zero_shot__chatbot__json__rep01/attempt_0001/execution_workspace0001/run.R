library(AER)
library(jsonlite)

dat <- read.csv("input.csv")

fit <- tobit(y ~ x + z, data = dat, left = 0, right = Inf)

s <- summary(fit)
coefs <- s$coefficients

const_est <- coefs["(Intercept)", "Estimate"]
const_se  <- coefs["(Intercept)", "Std. Error"]
x_est     <- coefs["x", "Estimate"]
x_se      <- coefs["x", "Std. Error"]
z_est     <- coefs["z", "Estimate"]
z_se      <- coefs["z", "Std. Error"]
sigma_est <- fit$scale
n         <- nrow(dat)

result <- list(
  task_id  = "broad_tobit",
  platform = "r",
  estimates = list(
    list(term = "const", estimate = const_est, se = const_se, n_obs = n),
    list(term = "x",     estimate = x_est,     se = x_se,     n_obs = n),
    list(term = "z",     estimate = z_est,      se = z_se,     n_obs = n),
    list(term = "sigma", estimate = sigma_est,  se = NULL,     n_obs = n)
  ),
  method_metadata = list(
    estimator = "Tobit MLE (AER::tobit)",
    vcov      = "observed information (default)"
  ),
  diagnostics = setNames(list(), character(0))
)

write(toJSON(result, auto_unbox = TRUE, digits = 10, null = "null"), "result.json")
