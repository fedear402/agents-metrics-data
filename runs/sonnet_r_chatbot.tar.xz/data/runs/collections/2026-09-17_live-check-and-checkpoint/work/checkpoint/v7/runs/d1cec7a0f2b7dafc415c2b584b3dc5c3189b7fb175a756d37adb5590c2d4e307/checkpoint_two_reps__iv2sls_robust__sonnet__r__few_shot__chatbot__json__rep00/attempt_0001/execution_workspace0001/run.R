library(AER)
library(sandwich)
library(lmtest)
library(jsonlite)

df <- read.csv("./input.csv")

fit <- ivreg(y_iv ~ x1_iv | z, data = df)

vcov_hc1 <- vcovHC(fit, type = "HC1")
ct <- coeftest(fit, vcov = vcov_hc1)

n_obs <- nrow(df)

out <- list(
  task_id = "iv2sls_robust",
  platform = "r",
  estimates = list(
    list(term = "const", estimate = ct["(Intercept)", "Estimate"], se = ct["(Intercept)", "Std. Error"], n_obs = n_obs),
    list(term = "x1_iv", estimate = ct["x1_iv", "Estimate"], se = ct["x1_iv", "Std. Error"], n_obs = n_obs)
  ),
  method_metadata = list(estimator = "2SLS via AER::ivreg", vcov = "HC1 robust"),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "./result.json", auto_unbox = TRUE)
