library(survival)
library(jsonlite)

dat <- read.csv("input.csv")

fit <- survreg(Surv(y, y > 0, type = "left") ~ x + z, data = dat, dist = "gaussian")

coefs <- coef(fit)
se_all <- sqrt(diag(vcov(fit)))

n_obs <- nrow(dat)

sigma_est <- fit$scale

result <- list(
  task_id = "broad_tobit",
  platform = "r",
  estimates = list(
    list(term = "const", estimate = unname(coefs["(Intercept)"]), se = unname(se_all["(Intercept)"]), n_obs = n_obs),
    list(term = "x", estimate = unname(coefs["x"]), se = unname(se_all["x"]), n_obs = n_obs),
    list(term = "z", estimate = unname(coefs["z"]), se = unname(se_all["z"]), n_obs = n_obs),
    list(term = "sigma", estimate = unname(sigma_est), se = NULL, n_obs = n_obs)
  ),
  method_metadata = list(estimator = "Tobit MLE (survreg, left-censored at 0)", vcov = "observed information (default survreg vcov)"),
  diagnostics = setNames(list(), character(0))
)

write(toJSON(result, auto_unbox = TRUE, digits = 10, null = "null"), "result.json")
