library(MASS)
library(jsonlite)

data <- read.csv("input.csv")

fit <- polr(factor(y) ~ x + z, data = data, method = "logistic", Hess = TRUE)

coefs <- summary(fit)$coefficients
x_est <- coefs["x", "Value"]
x_se <- coefs["x", "Std. Error"]
z_est <- coefs["z", "Value"]
z_se <- coefs["z", "Std. Error"]

newdata <- data.frame(x = 1, z = 0)
probs <- predict(fit, newdata = newdata, type = "probs")
prob_high <- probs[3]

n_obs <- nrow(data)

result <- list(
  task_id = "broad_ordered_logit",
  platform = "r",
  estimates = list(
    list(term = "x", estimate = x_est, se = x_se, n_obs = n_obs),
    list(term = "z", estimate = z_est, se = z_se, n_obs = n_obs),
    list(term = "prob_high", estimate = prob_high, se = NULL, n_obs = n_obs)
  ),
  method_metadata = list(estimator = "ordered logit (polr)", vcov = "observed information"),
  diagnostics = setNames(list(), character(0))
)

write(toJSON(result, auto_unbox = TRUE, null = "null", digits = 10), "result.json")
