library(sandwich)
library(jsonlite)

data <- read.csv("input.csv")
names(data) <- trimws(names(data))

bw <- 1
sub <- data[abs(data$score) < bw, ]
n_obs <- nrow(sub)

w <- 1 - abs(sub$score)
D <- as.integer(sub$score >= 0)

# Design matrix: intercept_left, slope_left, intercept_right, slope_right
# Left side: D=0, right side: D=1
# Parameterize as: intercept + slope*score + D*(intercept_jump) + D*slope*score_jump
# Use: X = [1, score, D, D*score]
# Left limit at 0: beta[1]
# Right limit at 0: beta[1] + beta[3]
# Discontinuity = beta[3]

X <- cbind(1, sub$score, D, D * sub$score)

wls_fit <- function(y, X, w) {
  XtW <- t(X) * w
  XtWX <- XtW %*% X
  XtWy <- XtW %*% y
  beta <- solve(XtWX, XtWy)
  fitted <- X %*% beta
  resid <- y - fitted
  # HC0 sandwich: (X'WX)^{-1} X'W diag(e^2) WX (X'WX)^{-1}
  # With weights treated as fixed
  # Score: w_i * x_i * e_i
  score_mat <- X * (w * resid)
  meat <- t(score_mat) %*% score_mat
  bread <- solve(XtWX)
  vcov <- bread %*% meat %*% bread
  list(beta = beta, vcov = vcov, resid = resid)
}

fit_earn <- wls_fit(sub$earnings, X, w)
fit_part <- wls_fit(sub$participated, X, w)

# Discontinuity is beta[3] (index 3, 1-based)
rf_est <- fit_earn$beta[3]
rf_se <- sqrt(fit_earn$vcov[3, 3])

fs_est <- fit_part$beta[3]
fs_se <- sqrt(fit_part$vcov[3, 3])

# Delta method for ratio: te = rf/fs
# Var(te) = (1/fs)^2 * Var(rf) + (rf/fs^2)^2 * Var(fs) - 2*(rf/fs^3)*Cov(rf,fs)
# Need joint covariance of rf and fs discontinuity estimates
# Both use same X and w, different y
# Cov(beta_earn[3], beta_part[3]) via joint sandwich

XtW <- t(X) * w
XtWX <- XtW %*% X
bread <- solve(XtWX)

resid_earn <- fit_earn$resid
resid_part <- fit_part$resid

# Cross meat: sum_i w_i^2 * x_i x_i' * e_earn_i * e_part_i
score_earn <- X * (w * resid_earn)
score_part <- X * (w * resid_part)
cross_meat <- t(score_earn) %*% score_part

cross_vcov <- bread %*% cross_meat %*% bread
cov_rf_fs <- cross_vcov[3, 3]

te_est <- rf_est / fs_est
te_var <- (1/fs_est)^2 * fit_earn$vcov[3,3] +
          (rf_est/fs_est^2)^2 * fit_part$vcov[3,3] -
          2 * (rf_est/fs_est^3) * cov_rf_fs
te_se <- sqrt(te_var)

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = as.numeric(te_est), se = as.numeric(te_se), n_obs = n_obs),
    list(term = "reduced_form", estimate = as.numeric(rf_est), se = as.numeric(rf_se), n_obs = n_obs),
    list(term = "first_stage", estimate = as.numeric(fs_est), se = as.numeric(fs_se), n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "fuzzy_RD_local_linear_triangular",
    vcov = "HC0"
  ),
  diagnostics = list()
)

write(toJSON(result, auto_unbox = TRUE, digits = 10), "result.json")
