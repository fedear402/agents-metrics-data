library(jsonlite)

data <- read.csv("./input.csv")

h <- 0.5
cutoff <- 0

within_bw <- data[abs(data$z - cutoff) <= h, ]

above <- within_bw[within_bw$z >= cutoff, ]
below <- within_bw[within_bw$z < cutoff, ]

tri_kernel <- function(z, cutoff, h) {
  u <- abs(z - cutoff) / h
  pmax(1 - u, 0)
}

above$w <- tri_kernel(above$z, cutoff, h)
below$w <- tri_kernel(below$z, cutoff, h)

fit_above <- lm(y ~ z, data = above, weights = w)
fit_below <- lm(y ~ z, data = below, weights = w)

intercept_above <- coef(fit_above)[["(Intercept)"]]
intercept_below <- coef(fit_below)[["(Intercept)"]]

late_est <- intercept_above - intercept_below

n_obs <- nrow(above) + nrow(below)

result <- list(
  task_id = "rdd_sharp",
  platform = "r",
  estimates = list(
    list(
      term = "late",
      estimate = as.numeric(late_est),
      se = NULL,
      n_obs = as.integer(n_obs)
    )
  ),
  method_metadata = list(
    estimator = "local_linear_rdd",
    vcov = "none"
  ),
  diagnostics = list()
)

write(toJSON(result, auto_unbox = TRUE, null = "null", digits = 10), "result.json")
