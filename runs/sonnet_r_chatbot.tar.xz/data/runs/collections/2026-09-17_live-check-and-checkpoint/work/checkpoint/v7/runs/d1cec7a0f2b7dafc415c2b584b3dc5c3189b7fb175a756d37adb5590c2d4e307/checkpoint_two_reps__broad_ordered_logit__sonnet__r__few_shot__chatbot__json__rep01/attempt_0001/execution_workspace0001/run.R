library(MASS)
library(jsonlite)

d <- read.csv("input.csv")
d$y <- ordered(d$y, levels = 1:3)

fit <- polr(y ~ x + z, data = d, method = "logistic", Hess = TRUE,
            control = list(reltol = 1e-12, maxit = 1000))

V <- vcov(fit)
n <- nrow(d)

x_est <- unname(coef(fit)["x"])
x_se  <- sqrt(V["x", "x"])

z_est <- unname(coef(fit)["z"])
z_se  <- sqrt(V["z", "z"])

# P(y=3 | x=1, z=0) = 1 - plogis(zeta[2] - x*1 - z*0) = 1 - plogis(zeta[2] - x_est)
prob_high <- 1 - plogis(fit$zeta[2] - x_est * 1 - z_est * 0)

result <- list(
  task_id = "broad_ordered_logit",
  platform = "r",
  estimates = list(
    list(term = "x",         estimate = x_est,     se = x_se, n_obs = n),
    list(term = "z",         estimate = z_est,     se = z_se, n_obs = n),
    list(term = "prob_high", estimate = unname(prob_high), se = NULL, n_obs = n)
  ),
  method_metadata = list(estimator = "ordered_logit_polr", vcov = "observed_information"),
  diagnostics = setNames(list(), character(0))
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
