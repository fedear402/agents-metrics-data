library(jsonlite)

data <- read.csv("input.csv")
n <- nrow(data)
y <- data$y
endog <- data$endog
x <- data$x
z1 <- data$z1
z2 <- data$z2

# Critical value: 95th percentile of F(2, n-4)
crit <- qf(0.95, 2, n - 4)

# AR test statistic for a given beta
ar_f <- function(beta) {
  y_tilde <- y - beta * endog
  # Regress y_tilde on intercept, x, z1, z2
  # F test for joint significance of z1, z2 coefficients
  fit_r <- lm(y_tilde ~ x)          # restricted
  fit_u <- lm(y_tilde ~ x + z1 + z2) # unrestricted
  rss_r <- sum(resid(fit_r)^2)
  rss_u <- sum(resid(fit_u)^2)
  f_stat <- ((rss_r - rss_u) / 2) / (rss_u / (n - 4))
  return(f_stat)
}

# The AR test statistic as function of beta is a ratio of quadratic forms in beta.
# It's a quadratic in beta divided by another quadratic in beta.
# The acceptance region is where F(beta) <= crit.
# This is equivalent to: rss_r - rss_u <= crit * 2 * rss_u / (n-4)
# => (rss_r - rss_u) - 2*crit/(n-4) * rss_u <= 0
# => rss_r - (1 + 2*crit/(n-4)) * rss_u <= 0

# To find boundaries analytically, express as quadratic in beta.
# y_tilde = y - beta*endog
# X_r = [1, x], X_u = [1, x, z1, z2]
# M_r = I - X_r(X_r'X_r)^{-1}X_r'
# M_u = I - X_u(X_u'X_u)^{-1}X_u'
# rss_r = y_tilde' M_r y_tilde
# rss_u = y_tilde' M_u y_tilde
# y_tilde = y - beta*endog = a - beta*b where a=y, b=endog

# Let's do it numerically by finding roots of F(beta) - crit = 0
# F(beta) is a rational function of beta, so it can have up to 2 solutions.

f_minus_crit <- function(beta) ar_f(beta) - crit

# First evaluate on a grid to understand behavior
grid <- seq(-1000, 1000, by = 0.1)
f_vals <- sapply(grid, ar_f)

# Find sign changes
accepts <- f_vals <= crit

# Find boundary points by looking at transitions
# More careful search with finer resolution around transitions
find_boundary <- function(lo, hi, tol = 1e-10) {
  # Assumes sign change of f_minus_crit between lo and hi
  tryCatch(uniroot(f_minus_crit, c(lo, hi), tol = tol)$root, error = function(e) NA)
}

# Find all sign change intervals
transitions <- which(diff(accepts) != 0)

boundaries <- c()
for (i in transitions) {
  b <- find_boundary(grid[i], grid[i + 1])
  if (!is.na(b)) boundaries <- c(boundaries, b)
}

# Also check extreme values
f_at_extremes_lo <- ar_f(-1e6)
f_at_extremes_hi <- ar_f(1e6)

unbounded <- 0
if (f_at_extremes_lo <= crit || f_at_extremes_hi <= crit) {
  unbounded <- 1
}

# Sort boundaries
boundaries <- sort(unique(round(boundaries, 8)))

if (length(boundaries) >= 2) {
  boundary_low <- boundaries[1]
  boundary_high <- boundaries[length(boundaries)]
} else if (length(boundaries) == 1) {
  boundary_low <- boundaries[1]
  boundary_high <- boundaries[1]
} else {
  boundary_low <- NA
  boundary_high <- NA
}

# Check if zero is accepted
accepts_zero <- as.numeric(ar_f(0) <= crit)

# AR F at beta = 1
ar_f_at_one <- ar_f(1)

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = list(
    list(term = "boundary_low", estimate = boundary_low, se = NULL, n_obs = n),
    list(term = "boundary_high", estimate = boundary_high, se = NULL, n_obs = n),
    list(term = "accepts_zero", estimate = as.numeric(accepts_zero), se = NULL, n_obs = n),
    list(term = "unbounded", estimate = as.numeric(unbounded), se = NULL, n_obs = n),
    list(term = "ar_f_at_one", estimate = ar_f_at_one, se = NULL, n_obs = n)
  ),
  method_metadata = list(
    estimator = "Anderson-Rubin test inversion",
    vcov = "homoskedastic"
  ),
  diagnostics = list()
)

write(toJSON(result, auto_unbox = TRUE, digits = 10, null = "null"), "result.json")
