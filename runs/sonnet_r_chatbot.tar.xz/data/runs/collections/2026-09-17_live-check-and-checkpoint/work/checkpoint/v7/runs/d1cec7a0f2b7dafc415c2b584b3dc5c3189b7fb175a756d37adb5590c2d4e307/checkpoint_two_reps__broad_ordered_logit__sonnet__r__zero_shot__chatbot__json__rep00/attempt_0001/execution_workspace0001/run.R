library(MASS)
library(jsonlite)

dat <- read.csv("input.csv")

# Ensure y is an ordered factor
dat$y <- factor(dat$y, levels = c(1, 2, 3), ordered = TRUE)

# Fit ordered logit model
fit <- polr(y ~ x + z, data = dat, method = "logistic", Hess = TRUE)

# Get coefficients and standard errors
coef_summary <- summary(fit)$coefficients
x_est <- coef_summary["x", "Value"]
x_se  <- coef_summary["x", "Std. Error"]
z_est <- coef_summary["z", "Value"]
z_se  <- coef_summary["z", "Std. Error"]

n_obs <- nrow(dat)

# Fitted probability of category 3 for x=1, z=0
newdata <- data.frame(x = 1, z = 0)
probs <- predict(fit, newdata = newdata, type = "probs")
prob_high <- as.numeric(probs[1, "3"])

result <- list(
  task_id = "broad_ordered_logit",
  platform = "r",
  estimates = list(
    list(term = "x", estimate = x_est, se = x_se, n_obs = n_obs),
    list(term = "z", estimate = z_est, se = z_se, n_obs = n_obs),
    list(term = "prob_high", estimate = prob_high, se = NULL, n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "ordered logit (polr)",
    vcov = "observed information (Hessian-based)"
  ),
  diagnostics = setNames(list(), character(0))
)

write(toJSON(result, auto_unbox = TRUE, digits = 10, null = "null"), "result.json")
