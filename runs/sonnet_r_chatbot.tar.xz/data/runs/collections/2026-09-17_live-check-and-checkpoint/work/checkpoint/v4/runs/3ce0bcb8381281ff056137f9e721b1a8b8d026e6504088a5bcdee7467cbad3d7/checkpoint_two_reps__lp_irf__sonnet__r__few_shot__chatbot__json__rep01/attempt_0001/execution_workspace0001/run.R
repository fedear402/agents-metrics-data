library(sandwich)
library(lmtest)
library(jsonlite)

df <- read.csv("./input.csv")

# Create lead of y by 4 periods
n <- nrow(df)
df$y_lead4 <- c(df$y[5:n], rep(NA, 4))
df$y_lag1 <- c(NA, df$y[1:(n-1)])

# Drop rows with NA
df_clean <- df[complete.cases(df[, c("y_lead4", "shock", "y_lag1")]), ]

# Estimate local projection: y_{t+4} = alpha + beta*shock_t + gamma*y_{t-1} + e
fit <- lm(y_lead4 ~ shock + y_lag1, data = df_clean)

# Newey-West standard errors with lag 4
nw_vcov <- NeweyWest(fit, lag = 4, prewhite = FALSE)
ct <- coeftest(fit, vcov = nw_vcov)

irf_est <- unname(ct["shock", "Estimate"])
irf_se <- unname(ct["shock", "Std. Error"])
n_obs <- nrow(df_clean)

out <- list(
  task_id = "lp_irf",
  platform = "r",
  estimates = list(
    list(term = "irf_h4", estimate = irf_est, se = irf_se, n_obs = n_obs)
  ),
  method_metadata = list(estimator = "Local Projection OLS h=4", vcov = "Newey-West lag 4"),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "./result.json", auto_unbox = TRUE)
