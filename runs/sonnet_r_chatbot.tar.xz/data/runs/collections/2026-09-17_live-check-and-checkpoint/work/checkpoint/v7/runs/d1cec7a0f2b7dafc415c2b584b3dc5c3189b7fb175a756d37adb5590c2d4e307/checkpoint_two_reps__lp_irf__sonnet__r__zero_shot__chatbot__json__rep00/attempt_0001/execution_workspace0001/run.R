library(sandwich)
library(lmtest)
library(jsonlite)

data <- read.csv("./input.csv")

# Sort by time
data <- data[order(data$t), ]
n <- nrow(data)

h <- 4

# Create lead of y (y_{t+h})
y_lead <- c(data$y[(h+1):n], rep(NA, h))

# Create lag of y (y_{t-1})
y_lag <- c(NA, data$y[1:(n-1)])

df <- data.frame(
  y_lead = y_lead,
  shock = data$shock,
  y_lag = y_lag
)

# Remove rows with NA
df_clean <- df[complete.cases(df), ]

# Estimate LP: y_{t+h} ~ 1 + shock_t + y_{t-1}
fit <- lm(y_lead ~ shock + y_lag, data = df_clean)

# Newey-West SE with lag 4
nw_vcov <- NeweyWest(fit, lag = 4, prewhite = FALSE, adjust = TRUE)
ct <- coeftest(fit, vcov = nw_vcov)

# Extract shock coefficient (IRF at h=4)
estimate <- ct["shock", "Estimate"]
se <- ct["shock", "Std. Error"]
n_obs <- nrow(df_clean)

result <- list(
  task_id = "lp_irf",
  platform = "r",
  estimates = list(
    list(
      term = "irf_h4",
      estimate = as.numeric(estimate),
      se = as.numeric(se),
      n_obs = as.integer(n_obs)
    )
  ),
  method_metadata = list(
    estimator = "local_projection_OLS",
    vcov = "Newey-West lag 4"
  ),
  diagnostics = list()
)

write(toJSON(result, auto_unbox = TRUE, digits = 10), "result.json")
