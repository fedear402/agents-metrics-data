library(sandwich)
library(jsonlite)

df <- read.csv("input.csv")
df <- df[order(df$date), ]

df$log_sales <- log(df$sales)
df$log_vix <- log(df$vix)
df$d_log_vix <- c(NA, diff(df$log_vix))

for (i in 1:15) {
  df[[paste0("lag_", i)]] <- c(rep(NA, i), df$d_log_vix[1:(nrow(df) - i)])
}

lag_cols <- paste0("lag_", 1:15)
df_complete <- df[complete.cases(df[, c("log_sales", lag_cols)]), ]

N <- nrow(df_complete)

formula_str <- paste("log_sales ~", paste(lag_cols, collapse = " + "))
model <- lm(as.formula(formula_str), data = df_complete)

# Newey-West with max lag 15, Bartlett weights 1-j/16, multiplied by N/(N-16)
nw_vcov <- NeweyWest(model, lag = 15, prewhite = FALSE, adjust = FALSE,
                     weights = function(j, ...) 1 - j/16)

# Multiply by N/(N-16)
nw_vcov_adj <- nw_vcov * (N / (N - 16))

coefs <- coef(model)

# lag coefficients (intercept is index 1, lag_1 is index 2, ..., lag_15 is index 16)
lag_coef_names <- paste0("lag_", 1:15)
lag_coefs <- coefs[lag_coef_names]

cumulative_response <- sum(lag_coefs)

# SE for cumulative response using full covariance matrix
# sum of all lag coefficients variance = sum of all elements of lag submatrix
lag_vcov <- nw_vcov_adj[lag_coef_names, lag_coef_names]
se_cumulative <- sqrt(sum(lag_vcov))

se_lag1 <- sqrt(nw_vcov_adj["lag_1", "lag_1"])
se_lag15 <- sqrt(nw_vcov_adj["lag_15", "lag_15"])

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(term = "cumulative_response", estimate = cumulative_response, se = se_cumulative, n_obs = N),
    list(term = "lag_1", estimate = unname(coefs["lag_1"]), se = se_lag1, n_obs = N),
    list(term = "lag_15", estimate = unname(coefs["lag_15"]), se = se_lag15, n_obs = N)
  ),
  method_metadata = list(
    estimator = "OLS",
    vcov = "Newey-West HAC, max lag 15, Bartlett weights 1-j/16, scaled N/(N-16)"
  ),
  diagnostics = list()
)

write(toJSON(result, auto_unbox = TRUE, digits = 10), "result.json")
