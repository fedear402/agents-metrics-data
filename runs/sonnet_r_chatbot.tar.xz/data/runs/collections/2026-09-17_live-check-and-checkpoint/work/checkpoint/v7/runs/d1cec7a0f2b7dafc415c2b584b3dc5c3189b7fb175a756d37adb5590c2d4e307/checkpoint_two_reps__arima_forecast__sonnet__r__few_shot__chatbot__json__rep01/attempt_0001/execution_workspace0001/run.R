library(forecast)
library(jsonlite)

df <- read.csv("./input.csv")
y <- df$y
n <- length(y)

fit <- Arima(y, order = c(1, 1, 1), include.constant = FALSE)
fc <- forecast(fit, h = 1, level = 95)

forecast_val <- as.numeric(fc$mean[1])
lower_val <- as.numeric(fc$lower[1, 1])
upper_val <- as.numeric(fc$upper[1, 1])

out <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = list(
    list(term = "forecast", estimate = forecast_val, se = NULL, n_obs = n),
    list(term = "lower_95", estimate = lower_val, se = NULL, n_obs = n),
    list(term = "upper_95", estimate = upper_val, se = NULL, n_obs = n)
  ),
  method_metadata = list(estimator = "ARIMA(1,1,1) by ML", vcov = "none"),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "./result.json", auto_unbox = TRUE)
