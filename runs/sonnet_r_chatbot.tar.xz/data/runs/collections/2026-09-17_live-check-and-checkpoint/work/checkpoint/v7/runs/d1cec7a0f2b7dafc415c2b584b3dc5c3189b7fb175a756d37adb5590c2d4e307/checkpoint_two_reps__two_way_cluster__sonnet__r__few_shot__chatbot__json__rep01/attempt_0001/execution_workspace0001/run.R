library(sandwich)
library(lmtest)
library(jsonlite)

df <- read.csv("./input.csv")

fit <- lm(y_twocluster ~ x, data = df)

# Cameron-Gelbach-Miller two-way cluster-robust SE
vcov_twoway <- function(model, data, cluster1, cluster2) {
  cl1 <- data[[cluster1]]
  cl2 <- data[[cluster2]]
  
  v1 <- vcovCL(model, cluster = cl1)
  v2 <- vcovCL(model, cluster = cl2)
  
  cl12 <- paste(cl1, cl2, sep = "_")
  v12 <- vcovCL(model, cluster = cl12)
  
  v1 + v2 - v12
}

vcov_cgm <- vcov_twoway(fit, df, "firm", "year")

co <- coeftest(fit, vcov = vcov_cgm)

n <- nrow(df)

out <- list(
  task_id = "two_way_cluster",
  platform = "r",
  estimates = list(
    list(term = "const", estimate = unname(co["(Intercept)", "Estimate"]),
         se = unname(co["(Intercept)", "Std. Error"]), n_obs = n),
    list(term = "x", estimate = unname(co["x", "Estimate"]),
         se = unname(co["x", "Std. Error"]), n_obs = n)
  ),
  method_metadata = list(estimator = "OLS", vcov = "two-way-cluster-CGM"),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "result.json", auto_unbox = TRUE, digits = 10)
