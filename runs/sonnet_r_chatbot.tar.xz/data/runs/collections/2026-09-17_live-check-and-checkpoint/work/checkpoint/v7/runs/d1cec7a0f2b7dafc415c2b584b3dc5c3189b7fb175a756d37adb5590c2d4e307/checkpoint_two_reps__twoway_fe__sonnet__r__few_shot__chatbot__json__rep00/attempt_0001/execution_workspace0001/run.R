library(jsonlite)
library(plm)
library(lmtest)
library(sandwich)

df <- read.csv("./input.csv")
pdf <- pdata.frame(df, index = c("firm", "year"))
fit <- plm(y_twocluster ~ x, data = pdf, model = "within", effect = "twoways")
vcov_cluster <- vcovHC(fit, type = "HC1", cluster = "group")
coef_test <- coeftest(fit, vcov = vcov_cluster)
est <- coef_test["x", "Estimate"]
se <- coef_test["x", "Std. Error"]
out <- list(
  task_id = "twoway_fe",
  platform = "r",
  estimates = list(
    list(term = "x", estimate = unname(est), se = unname(se), n_obs = nrow(df))
  ),
  method_metadata = list(estimator = "two-way FE (within)", vcov = "clustered on firm"),
  diagnostics = structure(list(), names = character(0))
)
write_json(out, "result.json", auto_unbox = TRUE, digits = 10)
