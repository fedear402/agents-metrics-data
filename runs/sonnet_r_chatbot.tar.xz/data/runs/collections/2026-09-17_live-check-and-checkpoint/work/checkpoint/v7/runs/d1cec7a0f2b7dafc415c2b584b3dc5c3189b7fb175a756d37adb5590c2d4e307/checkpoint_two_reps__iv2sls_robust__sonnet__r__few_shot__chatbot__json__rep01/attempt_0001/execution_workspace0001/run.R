library(AER)
library(sandwich)
library(lmtest)
library(jsonlite)

df <- read.csv("./input.csv")

fit <- ivreg(y_iv ~ x1_iv | z, data = df)

vc <- vcovHC(fit, type = "HC1")
ct <- coeftest(fit, vcov = vc)

n <- nrow(df)
const_est <- ct["(Intercept)", "Estimate"]
const_se  <- ct["(Intercept)", "Std. Error"]
x1iv_est  <- ct["x1_iv", "Estimate"]
x1iv_se   <- ct["x1_iv", "Std. Error"]

out <- list(
  task_id = "iv2sls_robust",
  platform = "r",
  estimates = list(
    list(term = "const",  estimate = const_est, se = const_se, n_obs = n),
    list(term = "x1_iv",  estimate = x1iv_est,  se = x1iv_se,  n_obs = n)
  ),
  method_metadata = list(estimator = "2SLS via AER::ivreg", vcov = "HC1"),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "./result.json", auto_unbox = TRUE, digits = 10)
