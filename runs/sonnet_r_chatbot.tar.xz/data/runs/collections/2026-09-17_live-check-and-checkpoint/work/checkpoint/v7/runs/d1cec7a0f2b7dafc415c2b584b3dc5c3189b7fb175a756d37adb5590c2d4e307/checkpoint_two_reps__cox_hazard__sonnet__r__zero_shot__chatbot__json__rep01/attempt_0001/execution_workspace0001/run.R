library(survival)
library(jsonlite)

data <- read.csv("./input.csv")

fit <- coxph(Surv(t_obs, event) ~ treat + x, data = data)

s <- summary(fit)
coefs <- s$coefficients

n_obs <- fit$n

result <- list(
  task_id = "cox_hazard",
  platform = "r",
  estimates = list(
    list(term = "treat", estimate = unname(coefs["treat", "coef"]), se = unname(coefs["treat", "se(coef)"]), n_obs = n_obs),
    list(term = "x", estimate = unname(coefs["x", "coef"]), se = unname(coefs["x", "se(coef)"]), n_obs = n_obs)
  ),
  method_metadata = list(estimator = "Cox proportional hazards", vcov = "model-based"),
  diagnostics = list()
)

write(toJSON(result, auto_unbox = TRUE, digits = 10), "result.json")
