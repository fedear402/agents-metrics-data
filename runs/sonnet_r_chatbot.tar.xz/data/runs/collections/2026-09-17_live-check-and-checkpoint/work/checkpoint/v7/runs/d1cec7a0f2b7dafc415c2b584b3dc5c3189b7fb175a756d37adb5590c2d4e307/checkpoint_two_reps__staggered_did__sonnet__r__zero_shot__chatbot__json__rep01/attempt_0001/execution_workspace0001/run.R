library(jsonlite)

dat <- read.csv("./input.csv")

cohorts <- c(4, 6, 8)
never <- dat[dat$cohort == -1, ]

att_cells <- c()
n_obs_total <- 0

for (g in cohorts) {
  treated_g <- dat[dat$cohort == g, ]
  pre_year <- g - 1
  post_years <- (g):9
  
  mu_nt_pre <- mean(never$y_did[never$year == pre_year])
  mu_tg_pre <- mean(treated_g$y_did[treated_g$year == pre_year])
  
  for (t in post_years) {
    mu_tg_t <- mean(treated_g$y_did[treated_g$year == t])
    mu_nt_t <- mean(never$y_did[never$year == t])
    
    att_gt <- (mu_tg_t - mu_tg_pre) - (mu_nt_t - mu_nt_pre)
    att_cells <- c(att_cells, att_gt)
    n_obs_total <- n_obs_total + nrow(treated_g[treated_g$year == t, ]) + nrow(never[never$year == t, ])
  }
}

att_uniform <- mean(att_cells)

n_firms <- length(unique(dat$firm))
n_years <- length(unique(dat$year))
n_obs <- n_firms * n_years

result <- list(
  task_id = "staggered_did",
  platform = "r",
  estimates = list(
    list(term = "att", estimate = att_uniform, se = NULL, n_obs = as.integer(n_obs))
  ),
  method_metadata = list(
    estimator = "ATT_uniform_group_year_means",
    vcov = "none"
  ),
  diagnostics = setNames(list(), character(0))
)

write(toJSON(result, auto_unbox = TRUE, null = "null", digits = 10), "./result.json")
