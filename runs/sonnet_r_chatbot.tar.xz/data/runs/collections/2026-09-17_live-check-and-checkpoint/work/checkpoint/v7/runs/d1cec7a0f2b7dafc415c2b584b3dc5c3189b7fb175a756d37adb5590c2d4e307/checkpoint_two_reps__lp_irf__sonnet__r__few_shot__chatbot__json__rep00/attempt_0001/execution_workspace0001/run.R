library(sandwich)
library(lmtest)
library(jsonlite)

df <- read.csv("./input.csv")

h <- 4
n <- nrow(df)

y_lead <- df$y[(h+1):n]
shock <- df$shock[1:(n-h)]
y_lag <- df$y[1:(n-h)]

reg_df <- data.frame(y_lead = y_lead, shock = shock, y_lag = y_lag)

fit <- lm(y_lead ~ shock + y_lag, data = reg_df)

nw_vcov <- NeweyWest(fit, lag = 4, prewhite = FALSE)
ct <- coeftest(fit, vcov = nw_vcov)

irf_est <- unname(ct["shock", "Estimate"])
irf_se  <- unname(ct["shock", "Std. Error"])
n_obs   <- nrow(reg_df)

out <- list(
  task_id = "lp_irf",
  platform = "r",
  estimates = list(
    list(term = "irf_h4", estimate = irf_est, se = irf_se, n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "Local Projection OLS, horizon h=4",
    vcov = "Newey-West, lag=4"
  ),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "./result.json", auto_unbox = TRUE, digits = 10)
