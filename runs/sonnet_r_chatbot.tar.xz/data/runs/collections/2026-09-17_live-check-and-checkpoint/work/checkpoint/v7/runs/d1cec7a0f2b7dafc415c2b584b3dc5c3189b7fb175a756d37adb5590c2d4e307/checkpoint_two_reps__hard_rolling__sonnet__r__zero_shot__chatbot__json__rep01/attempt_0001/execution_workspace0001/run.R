library(jsonlite)

data <- read.csv("input.csv")
data <- data[order(data$time), ]
y <- data$y

forecasts <- numeric(150)
for (f in 101:250) {
  idx <- (f - 100):(f - 1)
  y_window <- y[idx]
  y_dep <- y_window[2:100]
  y_lag <- y_window[1:99]
  fit <- lm(y_dep ~ y_lag)
  a_hat <- coef(fit)[1]
  b_hat <- coef(fit)[2]
  forecasts[f - 100] <- a_hat + b_hat * y[f - 1]
}

actuals <- y[101:250]
rmse <- sqrt(sum((actuals - forecasts)^2) / 150)

result <- list(
  task_id = "hard_rolling",
  platform = "r",
  estimates = list(
    list(term = "rmse", estimate = rmse, se = NULL, n_obs = 150L),
    list(term = "forecast_101", estimate = forecasts[1], se = NULL, n_obs = 99L),
    list(term = "forecast_150", estimate = forecasts[50], se = NULL, n_obs = 99L),
    list(term = "forecast_200", estimate = forecasts[100], se = NULL, n_obs = 99L),
    list(term = "forecast_250", estimate = forecasts[150], se = NULL, n_obs = 99L)
  ),
  method_metadata = list(estimator = "OLS AR(1) rolling window", vcov = "none"),
  diagnostics = setNames(list(), character(0))
)

write(toJSON(result, auto_unbox = TRUE, digits = 10, null = "null"), "result.json")
