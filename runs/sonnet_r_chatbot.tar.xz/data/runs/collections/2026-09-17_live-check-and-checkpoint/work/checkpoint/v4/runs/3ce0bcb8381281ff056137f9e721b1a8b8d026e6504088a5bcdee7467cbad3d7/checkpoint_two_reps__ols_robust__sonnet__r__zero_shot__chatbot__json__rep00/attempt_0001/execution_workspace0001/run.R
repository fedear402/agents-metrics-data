library(sandwich)
library(lmtest)
library(jsonlite)

data <- read.csv("./input.csv")

model <- lm(y_lin ~ x1 + x2, data = data)

vcov_hc1 <- vcovHC(model, type = "HC1")
coef_test <- coeftest(model, vcov = vcov_hc1)

n_obs <- nobs(model)

estimates <- list(
  list(term = "const", estimate = unname(coef_test["(Intercept)", "Estimate"]),
       se = unname(coef_test["(Intercept)", "Std. Error"]), n_obs = n_obs),
  list(term = "x1", estimate = unname(coef_test["x1", "Estimate"]),
       se = unname(coef_test["x1", "Std. Error"]), n_obs = n_obs),
  list(term = "x2", estimate = unname(coef_test["x2", "Estimate"]),
       se = unname(coef_test["x2", "Std. Error"]), n_obs = n_obs)
)

result <- list(
  task_id = "ols_robust",
  platform = "r",
  estimates = estimates,
  method_metadata = list(estimator = "OLS", vcov = "HC1"),
  diagnostics = setNames(list(), character(0))
)

write(toJSON(result, auto_unbox = TRUE, digits = 10), "result.json")
