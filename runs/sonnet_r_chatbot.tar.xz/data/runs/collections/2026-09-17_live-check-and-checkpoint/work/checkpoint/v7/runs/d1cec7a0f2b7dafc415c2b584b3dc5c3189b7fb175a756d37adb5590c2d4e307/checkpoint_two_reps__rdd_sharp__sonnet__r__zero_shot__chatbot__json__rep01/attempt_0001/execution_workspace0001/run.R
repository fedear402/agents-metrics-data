library(jsonlite)

dat <- read.csv("./input.csv")

h <- 0.5
cutoff <- 0

dat_left  <- dat[dat$z >= cutoff - h & dat$z < cutoff, ]
dat_right <- dat[dat$z >= cutoff & dat$z <= cutoff + h, ]

tri_kernel <- function(u) pmax(1 - abs(u) / h, 0)

w_left  <- tri_kernel(dat_left$z  - cutoff)
w_right <- tri_kernel(dat_right$z - cutoff)

fit_left  <- lm(y ~ z, data = dat_left,  weights = w_left)
fit_right <- lm(y ~ z, data = dat_right, weights = w_right)

intercept_left  <- coef(fit_left)[["(Intercept)"]]
intercept_right <- coef(fit_right)[["(Intercept)"]]

late_estimate <- intercept_right - intercept_left

n_left  <- nrow(dat_left)
n_right <- nrow(dat_right)
n_obs   <- n_left + n_right

vcov_left  <- vcov(fit_left)
vcov_right <- vcov(fit_right)

se_late <- sqrt(vcov_right["(Intercept)", "(Intercept)"] + vcov_left["(Intercept)", "(Intercept)"])

result <- list(
  task_id  = "rdd_sharp",
  platform = "r",
  estimates = list(
    list(
      term     = "late",
      estimate = as.numeric(late_estimate),
      se       = as.numeric(se_late),
      n_obs    = as.integer(n_obs)
    )
  ),
  method_metadata = list(
    estimator = "local_linear_regression",
    vcov      = "OLS_sandwich_delta"
  ),
  diagnostics = setNames(list(), character(0))
)

write(toJSON(result, auto_unbox = TRUE, digits = 10), "./result.json")
