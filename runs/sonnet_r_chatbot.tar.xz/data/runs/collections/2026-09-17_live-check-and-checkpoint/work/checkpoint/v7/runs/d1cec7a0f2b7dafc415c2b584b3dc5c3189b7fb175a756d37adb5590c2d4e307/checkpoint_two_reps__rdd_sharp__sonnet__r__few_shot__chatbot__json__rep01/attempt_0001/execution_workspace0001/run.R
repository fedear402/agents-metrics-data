library(jsonlite)

df <- read.csv("./input.csv")
h <- 0.5
cutoff <- 0

df$dist <- df$z - cutoff
df_sub <- df[abs(df$dist) <= h, ]

df_sub$w <- (1 - abs(df_sub$dist) / h)

right <- df_sub[df_sub$dist >= 0, ]
left  <- df_sub[df_sub$dist < 0, ]

fit_right <- lm(y ~ dist, data = right, weights = right$w)
fit_left  <- lm(y ~ dist, data = left,  weights = left$w)

intercept_right <- coef(fit_right)[["(Intercept)"]]
intercept_left  <- coef(fit_left)[["(Intercept)"]]

late_est <- intercept_right - intercept_left

n_obs <- nrow(df_sub)

out <- list(
  task_id = "rdd_sharp",
  platform = "r",
  estimates = list(
    list(term = "late", estimate = late_est, se = NA, n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "Local linear regression with triangular kernel, h=0.5",
    vcov = "none"
  ),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "./result.json", auto_unbox = TRUE)
