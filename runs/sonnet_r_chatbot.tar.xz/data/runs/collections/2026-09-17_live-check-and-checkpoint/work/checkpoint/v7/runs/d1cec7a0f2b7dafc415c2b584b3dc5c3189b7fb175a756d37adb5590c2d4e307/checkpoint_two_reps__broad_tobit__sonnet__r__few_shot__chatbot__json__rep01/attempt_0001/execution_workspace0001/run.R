library(survival)
library(jsonlite)

d <- read.csv("input.csv")
n <- nrow(d)

fit <- survreg(Surv(y, y > 0, type = "left") ~ x + z,
               data = d, dist = "gaussian",
               control = survreg.control(rel.tolerance = 1e-12))

V <- vcov(fit)
b <- coef(fit)

estimates <- list(
  list(term = "const", estimate = unname(b["(Intercept)"]), se = sqrt(V["(Intercept)", "(Intercept)"]), n_obs = n),
  list(term = "x",     estimate = unname(b["x"]),           se = sqrt(V["x", "x"]),                     n_obs = n),
  list(term = "z",     estimate = unname(b["z"]),           se = sqrt(V["z", "z"]),                     n_obs = n),
  list(term = "sigma", estimate = unname(fit$scale),        se = NULL,                                   n_obs = n)
)

result <- list(
  task_id  = "broad_tobit",
  platform = "r",
  estimates = estimates,
  method_metadata = list(estimator = "survreg_gaussian_tobit", vcov = "observed_information"),
  diagnostics = setNames(list(), character(0))
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
