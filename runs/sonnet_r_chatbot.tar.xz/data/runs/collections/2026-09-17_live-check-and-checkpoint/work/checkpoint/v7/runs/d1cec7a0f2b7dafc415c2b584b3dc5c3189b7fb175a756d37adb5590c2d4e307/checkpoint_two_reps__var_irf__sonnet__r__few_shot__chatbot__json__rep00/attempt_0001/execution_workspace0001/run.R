library(vars)
library(jsonlite)

df <- read.csv("./input.csv")
y <- df[, c("y1", "y2")]

var_model <- VAR(y, p = 2, type = "const")

irf_result <- irf(var_model, impulse = "y2", response = "y1",
                  n.ahead = 4, ortho = TRUE, boot = FALSE)

irf_value <- irf_result$irf$y2[5, "y1"]

n_obs <- nrow(y)

out <- list(
  task_id = "var_irf",
  platform = "r",
  estimates = list(
    list(term = "irf_y1_to_y2_h4", estimate = unname(irf_value),
         se = NULL, n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "VAR(2) with constant, Cholesky identification",
    vcov = "OLS"
  ),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "./result.json", auto_unbox = TRUE, null = "null")
