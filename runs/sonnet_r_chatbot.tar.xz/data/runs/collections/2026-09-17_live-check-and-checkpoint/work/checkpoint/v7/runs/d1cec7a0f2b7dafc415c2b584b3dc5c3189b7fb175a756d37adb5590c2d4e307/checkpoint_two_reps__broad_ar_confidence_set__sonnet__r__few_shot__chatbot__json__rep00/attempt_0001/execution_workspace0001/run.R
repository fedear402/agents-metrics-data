library(jsonlite)

d <- read.csv("input.csv")
n <- nrow(d)

# Model: y - beta*endog ~ intercept + x + z1 + z2
# Restricted: y - beta*endog ~ intercept + x (drop z1, z2)
# q = 2 excluded instruments, df = n - 4

q <- 2L
df <- n - 4L
critical <- qf(0.95, q, df)

# Compute residuals from unrestricted and restricted models
# For AR inversion, we use the algebraic approach
# Let ty = y - beta*endog
# Unrestricted: ty ~ 1 + x + z1 + z2
# Restricted: ty ~ 1 + x

# Precompute residuals using Frisch-Waugh
# Project out common regressors (intercept + x)
M_common <- lm(y ~ x, data = d)
ry <- residuals(M_common)
rendog <- residuals(lm(endog ~ x, data = d))
rz1 <- residuals(lm(z1 ~ x, data = d))
rz2 <- residuals(lm(z2 ~ x, data = d))

# For restricted model residuals after projecting out (1, x):
# ty_resid_restricted = ry - beta * rendog

# For unrestricted model, project out z1 and z2 additionally from ry and rendog
# SSR_U(beta) = ||M_full * (ry - beta*rendog)||^2
# where M_full projects out (z1_resid, z2_resid) from residuals

# Using FWL: unrestricted residuals = project (ry - beta*rendog) onto space orthogonal to (rz1, rz2)
# SSR_R(beta) = sum((ry - beta*rendog)^2)
# SSR_U(beta) = SSR after projecting out rz1, rz2 from (ry - beta*rendog)

# Let's compute directly:
# Z matrix of partialled-out instruments
Z <- cbind(rz1, rz2)
PZ <- Z %*% solve(t(Z) %*% Z) %*% t(Z)  # projection onto Z
MZ <- diag(n) - PZ  # annihilator

# Residuals from unrestricted:
# uy = MZ %*% ry, ud = MZ %*% rendog
uy <- as.vector(MZ %*% ry)
ud <- as.vector(MZ %*% rendog)

# SSR_R(beta) = sum((ry - beta*rendog)^2)
# SSR_U(beta) = sum((uy - beta*ud)^2)

# F(beta) = ((SSR_R - SSR_U)/q) / (SSR_U/df)
# Accept: F <= critical, i.e., SSR_R - SSR_U <= (q*critical/df)*SSR_U
# SSR_R - (1 + k)*SSR_U <= 0 where k = q*critical/df

k <- q * critical / df

# SSR_R(beta) = sum(ry^2) - 2*beta*sum(ry*rendog) + beta^2*sum(rendog^2)
# SSR_U(beta) = sum(uy^2) - 2*beta*sum(uy*ud) + beta^2*sum(ud^2)

A <- sum(rendog^2) - (1 + k) * sum(ud^2)
B <- -2 * (sum(ry * rendog) - (1 + k) * sum(uy * ud))
C <- sum(ry^2) - (1 + k) * sum(uy^2)

disc <- B^2 - 4 * A * C
bounds <- sort(Re(polyroot(c(C, B, A))))

unbounded <- as.integer(A < 0)

accepts <- function(beta) A * beta^2 + B * beta + C <= 0

accepts_zero <- as.integer(accepts(0))

# Compute F at beta = 1
ty1 <- d$y - 1 * d$endog
full_fit1 <- lm(ty1 ~ x + z1 + z2, data = d)
restr_fit1 <- lm(ty1 ~ x, data = d)
ar_f_at_one <- ((deviance(restr_fit1) - deviance(full_fit1)) / q) / (deviance(full_fit1) / df)

rows <- list(
  list(term = "boundary_low", estimate = unname(bounds[1]), se = NULL, n_obs = n),
  list(term = "boundary_high", estimate = unname(bounds[2]), se = NULL, n_obs = n),
  list(term = "accepts_zero", estimate = unname(accepts_zero * 1.0), se = NULL, n_obs = n),
  list(term = "unbounded", estimate = unname(unbounded * 1.0), se = NULL, n_obs = n),
  list(term = "ar_f_at_one", estimate = unname(ar_f_at_one), se = NULL, n_obs = n)
)

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = rows,
  method_metadata = list(estimator = "Anderson-Rubin", vcov = "homoskedastic"),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
