library(jsonlite)

df <- read.csv("./input.csv")

cutoff <- 0
h <- 0.5

df$dist <- df$z - cutoff

in_bw <- abs(df$dist) <= h
df_bw <- df[in_bw, ]

# Triangular kernel weights
df_bw$w <- (1 - abs(df_bw$dist) / h)

left <- df_bw[df_bw$dist < 0, ]
right <- df_bw[df_bw$dist >= 0, ]

fit_left <- lm(y ~ dist, data = left, weights = left$w)
fit_right <- lm(y ~ dist, data = right, weights = right$w)

intercept_left <- coef(fit_left)[["(Intercept)"]]
intercept_right <- coef(fit_right)[["(Intercept)"]]

late_est <- intercept_right - intercept_left

# SE via delta method approximation: sqrt(var(intercept_right) + var(intercept_left))
vcov_left <- vcov(fit_left)
vcov_right <- vcov(fit_right)

se_left <- sqrt(vcov_left["(Intercept)", "(Intercept)"])
se_right <- sqrt(vcov_right["(Intercept)", "(Intercept)"])

late_se <- sqrt(se_left^2 + se_right^2)

n_obs <- nrow(left) + nrow(right)

out <- list(
  task_id = "rdd_sharp",
  platform = "r",
  estimates = list(
    list(term = "late", estimate = late_est, se = late_se, n_obs = as.integer(n_obs))
  ),
  method_metadata = list(
    estimator = "local linear regression with triangular kernel, bandwidth 0.5",
    vcov = "OLS vcov each side, delta method for LATE SE"
  ),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "./result.json", auto_unbox = TRUE)
