library(sandwich)
library(jsonlite)

df <- read.csv("input.csv")
df <- df[order(df$date), ]

df$log_sales <- log(df$sales)
df$log_vix <- log(df$vix)
df$d_log_vix <- c(NA, diff(df$log_vix))

for (k in 1:15) {
  df[[paste0("lag_", k)]] <- c(rep(NA, k), df$d_log_vix[1:(nrow(df) - k)])
}

lag_vars <- paste0("lag_", 1:15)
formula_str <- paste("log_sales ~", paste(lag_vars, collapse = " + "))
model_df <- df[complete.cases(df[, c("log_sales", lag_vars)]), ]

fit <- lm(as.formula(formula_str), data = model_df)
N <- nrow(model_df)

# Newey-West with max lag 15, Bartlett weights 1 - j/16, multiplied by N/(N-16)
nw_vcov <- sandwich::NeweyWest(fit, lag = 15, prewhite = FALSE, adjust = FALSE,
                                weights = function(j, bw) 1 - j / (bw + 1),
                                sandwich = TRUE)
# sandwich::NeweyWest uses bandwidth parameter; let's do it manually to be precise

# Manual Newey-West
X <- model.matrix(fit)
e <- residuals(fit)
n <- N
k <- ncol(X)

# Meat with Bartlett kernel, max lag 15, weights 1 - j/16
S <- t(X) %*% diag(e^2) %*% X / n  # lag 0

for (j in 1:15) {
  w <- 1 - j / 16
  Gamma_j <- t(X[1:(n-j), , drop=FALSE]) %*% diag(e[1:(n-j)] * e[(j+1):n]) %*% X[(j+1):n, , drop=FALSE] / n
  S <- S + w * (Gamma_j + t(Gamma_j))
}

bread <- solve(t(X) %*% X / n)
vcov_nw <- (bread %*% S %*% bread) / n
# Multiply by N/(N-16)
vcov_nw <- vcov_nw * N / (N - 16)

coefs <- coef(fit)
lag_coef_names <- paste0("lag_", 1:15)
lag_coefs <- coefs[lag_coef_names]

cumulative_response <- sum(lag_coefs)

# Indices for lag_1 through lag_15 in the covariance matrix
idx <- match(lag_coef_names, names(coefs))

# SE for cumulative response: sqrt(1' V 1) where 1 is vector of ones for lag columns
ones <- rep(1, 15)
var_cum <- t(ones) %*% vcov_nw[idx, idx] %*% ones
se_cum <- sqrt(as.numeric(var_cum))

se_lag1 <- sqrt(vcov_nw[match("lag_1", names(coefs)), match("lag_1", names(coefs))])
se_lag15 <- sqrt(vcov_nw[match("lag_15", names(coefs)), match("lag_15", names(coefs))])

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(term = "cumulative_response", estimate = as.numeric(cumulative_response), se = as.numeric(se_cum), n_obs = as.integer(N)),
    list(term = "lag_1", estimate = as.numeric(lag_coefs["lag_1"]), se = as.numeric(se_lag1), n_obs = as.integer(N)),
    list(term = "lag_15", estimate = as.numeric(lag_coefs["lag_15"]), se = as.numeric(se_lag15), n_obs = as.integer(N))
  ),
  method_metadata = list(
    estimator = "OLS",
    vcov = "Newey-West HAC, max lag 15, Bartlett weights 1-j/16, scaled by N/(N-16)"
  ),
  diagnostics = list()
)

write(toJSON(result, auto_unbox = TRUE, digits = 10), "result.json")
