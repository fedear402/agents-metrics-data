library(sandwich)
library(jsonlite)

dat <- read.csv("input.csv")
names(dat) <- trimws(names(dat))

# Apply bandwidth filter and triangular weights
dat <- dat[abs(dat$score) < 1, ]
dat$w <- 1 - abs(dat$score)
dat$D <- as.numeric(dat$score >= 0)

n_obs <- nrow(dat)

# Create interaction terms for separate slopes on each side
dat$score_left  <- dat$score * (1 - dat$D)
dat$score_right <- dat$score * dat$D

# Fit reduced form: earnings ~ D + score_left + score_right
rf_fit <- lm(earnings ~ D + score_left + score_right, data = dat, weights = w)
vcov_rf <- vcovHC(rf_fit, type = "HC0")
rf_est <- coef(rf_fit)["D"]
rf_se  <- sqrt(vcov_rf["D", "D"])

# Fit first stage: participated ~ D + score_left + score_right
fs_fit <- lm(participated ~ D + score_left + score_right, data = dat, weights = w)
vcov_fs <- vcovHC(fs_fit, type = "HC0")
fs_est <- coef(fs_fit)["D"]
fs_se  <- sqrt(vcov_fs["D", "D"])

# Delta method for treatment effect = rf / fs
# Var(rf/fs) = (1/fs^2)*Var(rf) + (rf^2/fs^4)*Var(fs) - 2*(rf/fs^3)*Cov(rf,fs)
# Need joint covariance of rf_D and fs_D estimates
# Use meat/bread approach on stacked system

# Get residuals and design matrix for both models
X <- model.matrix(rf_fit)
w_vec <- dat$w

# Meat for joint covariance: stack the score equations
# rf influence: X_i * e_rf_i * w_i
# fs influence: X_i * e_fs_i * w_i
e_rf <- residuals(rf_fit)
e_fs <- residuals(fs_fit)

# Bread (inverse of XtWX) for each model
bread_rf <- solve(t(X * w_vec) %*% X)
bread_fs <- solve(t(X * w_vec) %*% X)  # same X

# Cross-meat: sum of (X_i * e_rf_i * w_i) * (X_i * e_fs_i * w_i)^T
# For the covariance between rf_D and fs_D:
# Cov(rf_D, fs_D) = [bread_rf %*% cross_meat %*% bread_fs]_{D,D}
meat_cross <- t(X * w_vec * e_rf) %*% (X * w_vec * e_fs)
cov_matrix_cross <- bread_rf %*% meat_cross %*% bread_fs

cov_rf_fs <- cov_matrix_cross["D", "D"]

# Delta method
te_est <- rf_est / fs_est
te_var <- (1/fs_est^2) * vcov_rf["D","D"] +
          (rf_est^2 / fs_est^4) * vcov_fs["D","D"] -
          2 * (rf_est / fs_est^3) * cov_rf_fs
te_se <- sqrt(te_var)

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = as.numeric(te_est), se = as.numeric(te_se), n_obs = n_obs),
    list(term = "reduced_form",     estimate = as.numeric(rf_est), se = as.numeric(rf_se), n_obs = n_obs),
    list(term = "first_stage",      estimate = as.numeric(fs_est), se = as.numeric(fs_se), n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "fuzzy_rd_local_linear_wald",
    vcov = "HC0"
  ),
  diagnostics = list()
)

write(toJSON(result, auto_unbox = TRUE, digits = 10), "result.json")
