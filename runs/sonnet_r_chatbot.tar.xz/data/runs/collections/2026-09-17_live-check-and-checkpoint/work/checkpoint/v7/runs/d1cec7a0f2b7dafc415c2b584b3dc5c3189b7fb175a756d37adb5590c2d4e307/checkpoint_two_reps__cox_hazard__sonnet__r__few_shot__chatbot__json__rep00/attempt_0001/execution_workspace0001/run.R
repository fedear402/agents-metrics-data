library(jsonlite)
library(survival)

df <- read.csv("./input.csv")

fit <- coxph(Surv(t_obs, event) ~ treat + x, data = df)

coef_summary <- summary(fit)$coefficients
loghr_treat <- coef_summary["treat", "coef"]
se_treat <- coef_summary["treat", "se(coef)"]
loghr_x <- coef_summary["x", "coef"]
se_x <- coef_summary["x", "se(coef)"]
n_obs <- fit$n

out <- list(
  task_id = "cox_hazard",
  platform = "r",
  estimates = list(
    list(term = "treat", estimate = loghr_treat, se = se_treat, n_obs = n_obs),
    list(term = "x", estimate = loghr_x, se = se_x, n_obs = n_obs)
  ),
  method_metadata = list(estimator = "Cox proportional hazards", vcov = "model-based"),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "result.json", auto_unbox = TRUE, digits = 10)
