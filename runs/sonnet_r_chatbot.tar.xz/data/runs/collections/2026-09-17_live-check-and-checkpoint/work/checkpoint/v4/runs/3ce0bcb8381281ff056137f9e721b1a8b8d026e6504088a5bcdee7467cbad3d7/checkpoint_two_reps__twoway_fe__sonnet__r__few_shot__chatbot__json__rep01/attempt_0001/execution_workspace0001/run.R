library(jsonlite)
library(plm)
library(lmtest)
library(sandwich)

df <- read.csv("./input.csv")

pdf <- pdata.frame(df, index = c("firm", "year"))

fit <- plm(y_twocluster ~ x, data = pdf, model = "within", effect = "twoways")

vcov_cl <- vcovHC(fit, type = "HC1", cluster = "group")

ct <- coeftest(fit, vcov = vcov_cl)

out <- list(
  task_id = "twoway_fe",
  platform = "r",
  estimates = list(
    list(term = "x",
         estimate = unname(ct["x", "Estimate"]),
         se = unname(ct["x", "Std. Error"]),
         n_obs = nrow(df))
  ),
  method_metadata = list(estimator = "two-way FE (within)",
                         vcov = "clustered on firm (HC1)"),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "result.json", auto_unbox = TRUE)
