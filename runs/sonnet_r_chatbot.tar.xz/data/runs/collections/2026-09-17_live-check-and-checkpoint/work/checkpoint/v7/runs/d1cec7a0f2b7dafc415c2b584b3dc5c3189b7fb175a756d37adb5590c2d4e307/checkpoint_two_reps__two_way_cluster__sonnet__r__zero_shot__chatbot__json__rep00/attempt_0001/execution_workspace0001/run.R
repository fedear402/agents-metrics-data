library(sandwich)
library(lmtest)
library(jsonlite)

dat <- read.csv("./input.csv")

fit <- lm(y_twocluster ~ x, data = dat)

# Cameron-Gelbach-Miller two-way cluster-robust variance
vcov_twoway <- function(model, dat, cluster1, cluster2) {
  X <- model.matrix(model)
  e <- residuals(model)
  n <- nrow(X)
  
  bread_mat <- solve(crossprod(X))
  
  meat_cluster <- function(cl) {
    cls <- unique(cl)
    M <- length(cls)
    S <- matrix(0, ncol(X), ncol(X))
    for (c in cls) {
      idx <- which(cl == c)
      Xi <- X[idx, , drop = FALSE]
      ei <- e[idx]
      score <- colSums(Xi * ei)
      S <- S + outer(score, score)
    }
    M / (M - 1) * (n - 1) / (n - ncol(X)) * S
  }
  
  cl1 <- dat[[cluster1]]
  cl2 <- dat[[cluster2]]
  cl12 <- paste(cl1, cl2, sep = "_")
  
  V1 <- bread_mat %*% meat_cluster(cl1) %*% bread_mat
  V2 <- bread_mat %*% meat_cluster(cl2) %*% bread_mat
  V12 <- bread_mat %*% meat_cluster(cl12) %*% bread_mat
  
  V1 + V2 - V12
}

V <- vcov_twoway(fit, dat, "firm", "year")

coefs <- coef(fit)
ses <- sqrt(diag(V))
n_obs <- nrow(dat)

result <- list(
  task_id = "two_way_cluster",
  platform = "r",
  estimates = list(
    list(term = "const", estimate = unname(coefs[1]), se = unname(ses[1]), n_obs = n_obs),
    list(term = "x", estimate = unname(coefs[2]), se = unname(ses[2]), n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "OLS",
    vcov = "Cameron-Gelbach-Miller two-way cluster-robust (firm, year)"
  ),
  diagnostics = setNames(list(), character(0))
)

write(toJSON(result, auto_unbox = TRUE, digits = 10), "./result.json")
