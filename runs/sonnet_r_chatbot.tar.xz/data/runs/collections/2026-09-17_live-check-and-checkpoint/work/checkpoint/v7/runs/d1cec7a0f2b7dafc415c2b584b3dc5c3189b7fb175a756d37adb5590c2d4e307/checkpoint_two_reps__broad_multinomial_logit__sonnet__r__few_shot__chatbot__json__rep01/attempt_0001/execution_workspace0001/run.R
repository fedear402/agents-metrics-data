library(nnet)
library(jsonlite)

d <- read.csv("input.csv")
d$y <- factor(d$y, levels = 0:2)

fit <- multinom(y ~ x + z, data = d, Hess = TRUE, trace = FALSE,
                maxit = 1000, reltol = 1e-12, abstol = 1e-12)

B <- coef(fit)
V <- vcov(fit)

n_obs <- nrow(d)

x_cat1 <- unname(B["1", "x"])
z_cat1 <- unname(B["1", "z"])
x_cat2 <- unname(B["2", "x"])
z_cat2 <- unname(B["2", "z"])

se_x_cat1 <- sqrt(V["1:x", "1:x"])
se_z_cat1 <- sqrt(V["1:z", "1:z"])
se_x_cat2 <- sqrt(V["2:x", "2:x"])
se_z_cat2 <- sqrt(V["2:z", "2:z"])

# Probability of cat2 at x=0, z=0
intercepts <- c(0, B["1", "(Intercept)"], B["2", "(Intercept)"])
exp_vals <- exp(intercepts - max(intercepts))
probs <- exp_vals / sum(exp_vals)
prob_cat2_zero <- probs[3]

estimates <- list(
  list(term = "x_cat1", estimate = x_cat1, se = se_x_cat1, n_obs = n_obs),
  list(term = "z_cat1", estimate = z_cat1, se = se_z_cat1, n_obs = n_obs),
  list(term = "x_cat2", estimate = x_cat2, se = se_x_cat2, n_obs = n_obs),
  list(term = "z_cat2", estimate = z_cat2, se = se_z_cat2, n_obs = n_obs),
  list(term = "prob_cat2_zero", estimate = prob_cat2_zero, se = NULL, n_obs = n_obs)
)

result <- list(
  task_id = "broad_multinomial_logit",
  platform = "r",
  estimates = estimates,
  method_metadata = list(estimator = "multinom (nnet)", vcov = "observed information (Hessian)"),
  diagnostics = setNames(list(), character(0))
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
