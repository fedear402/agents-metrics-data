library(jsonlite)

d <- read.csv("input.csv")
n <- nrow(d)
y <- d$y
endog <- d$endog
x <- d$x
z1 <- d$z1
z2 <- d$z2

q <- 2L
df <- n - 4L  # n - (intercept + x + z1 + z2)
critical <- qf(0.95, q, df)

# Unrestricted regression: y - beta*endog ~ 1 + x + z1 + z2
# Restricted regression: y - beta*endog ~ 1 + x
# We invert the joint F test on z1, z2 coefficients

# For a given beta, transformed = y - beta*endog
# SSR_R = residuals from lm(transformed ~ 1 + x)
# SSR_U = residuals from lm(transformed ~ 1 + x + z1 + z2)
# F(beta) = ((SSR_R - SSR_U)/q) / (SSR_U/df)
# Accept when F <= critical, i.e., SSR_R - (1 + q*critical/df)*SSR_U <= 0

# Residualize everything on intercept + x
MX <- function(v) residuals(lm(v ~ x))

ry <- MX(y)
rd <- MX(endog)
rz1 <- MX(z1)
rz2 <- MX(z2)

# Unrestricted residuals of transformed ~ 1 + x + z1 + z2
# = residuals of MX(y - beta*endog) ~ rz1 + rz2 (no intercept, already demeaned by x)
# = residuals of (ry - beta*rd) on rz1, rz2

# Let's compute symbolically:
# uy(beta) = ry - beta*rd - fitted from rz1,rz2
# But we need to be more careful. Let's use the quadratic expansion.

# SSR_U(beta) = ||ry - beta*rd||^2 - (ry-beta*rd)'Z(Z'Z)^{-1}Z'(ry-beta*rd)
# where Z = [rz1, rz2]

Z <- cbind(rz1, rz2)
ZtZ_inv <- solve(t(Z) %*% Z)
PZ <- Z %*% ZtZ_inv %*% t(Z)
MZ <- diag(n) - PZ

# SSR_U(beta) = (ry - beta*rd)' MZ (ry - beta*rd)
# SSR_R(beta) = (ry - beta*rd)' (ry - beta*rd)  [restricted has no z1,z2]

# k = q*critical/df
k <- q * critical / df

# A*beta^2 + B*beta + C <= 0
# where we expand SSR_R - (1+k)*SSR_U

# SSR_R = ||ry - beta*rd||^2 = sum(ry^2) - 2*beta*sum(ry*rd) + beta^2*sum(rd^2)
# SSR_U = (ry-beta*rd)' MZ (ry-beta*rd)
#       = ry'MZ ry - 2*beta*ry'MZ rd + beta^2 * rd'MZ rd

ryMZry <- as.numeric(t(ry) %*% MZ %*% ry)
ryMZrd <- as.numeric(t(ry) %*% MZ %*% rd)
rdMZrd <- as.numeric(t(rd) %*% MZ %*% rd)

SSR_R_a <- sum(rd^2)
SSR_R_b <- -2 * sum(ry * rd)
SSR_R_c <- sum(ry^2)

SSR_U_a <- rdMZrd
SSR_U_b <- -2 * ryMZrd
SSR_U_c <- ryMZry

A <- SSR_R_a - (1 + k) * SSR_U_a
B <- SSR_R_b - (1 + k) * SSR_U_b
C <- SSR_R_c - (1 + k) * SSR_U_c

disc <- B^2 - 4*A*C
bounds <- sort(Re(polyroot(c(C, B, A))))

accepts <- function(beta) A * beta^2 + B * beta + C <= 0

unbounded <- as.integer(A < 0)

# ar_f_at_one
compute_f <- function(beta) {
  transformed <- y - beta * endog
  full_fit <- lm(transformed ~ x + z1 + z2)
  restr_fit <- lm(transformed ~ x)
  ssr_u <- deviance(full_fit)
  ssr_r <- deviance(restr_fit)
  ((ssr_r - ssr_u) / q) / (ssr_u / df)
}

ar_f_1 <- compute_f(1)

rows <- list(
  list(term = "boundary_low", estimate = unname(bounds[1]), se = NULL, n_obs = n),
  list(term = "boundary_high", estimate = unname(bounds[2]), se = NULL, n_obs = n),
  list(term = "accepts_zero", estimate = unname(as.integer(accepts(0))), se = NULL, n_obs = n),
  list(term = "unbounded", estimate = unname(unbounded), se = NULL, n_obs = n),
  list(term = "ar_f_at_one", estimate = unname(ar_f_1), se = NULL, n_obs = n)
)

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = rows,
  method_metadata = list(estimator = "Anderson-Rubin", vcov = "homoskedastic"),
  diagnostics = setNames(list(), character(0))
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
