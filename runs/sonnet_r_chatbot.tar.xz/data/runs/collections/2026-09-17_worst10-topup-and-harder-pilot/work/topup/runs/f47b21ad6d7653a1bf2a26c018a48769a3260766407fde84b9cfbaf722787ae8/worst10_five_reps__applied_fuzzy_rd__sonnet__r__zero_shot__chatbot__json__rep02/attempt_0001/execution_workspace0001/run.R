library(sandwich)
library(jsonlite)

df <- read.csv("input.csv")
names(df) <- trimws(names(df))

# Apply bandwidth and triangular weights
df <- df[abs(df$score) < 1, ]
df$w <- 1 - abs(df$score)
df$D <- as.integer(df$score >= 0)

n_obs <- nrow(df)

# Design matrix for local linear RD
# y = a0 + a1*score + tau*D + a2*D*score + error
# tau is the discontinuity (right limit - left limit)
X <- cbind(1, df$score, df$D, df$D * df$score)

W <- diag(df$w)

# WLS solution: beta = (X'WX)^{-1} X'Wy
XtW <- t(X) %*% W
XtWX <- XtW %*% X
XtWX_inv <- solve(XtWX)

# Fit for earnings (reduced form)
y_earn <- df$earnings
beta_earn <- XtWX_inv %*% (XtW %*% y_earn)
rf_est <- beta_earn[3]

# Fit for participation (first stage)
y_part <- df$participated
beta_part <- XtWX_inv %*% (XtW %*% y_part)
fs_est <- beta_part[3]

# HC0 robust variance: V = (X'WX)^{-1} * (X'W * diag(e^2) * WX) * (X'WX)^{-1}
# where e are weighted residuals? 
# Actually for WLS with fixed weights, HC0 uses:
# V = (X'WX)^{-1} * sum_i w_i^2 * e_i^2 * x_i x_i' * (X'WX)^{-1}
# where e_i = y_i - x_i'beta (unweighted residuals)

resid_earn <- as.vector(y_earn - X %*% beta_earn)
resid_part <- as.vector(y_part - X %*% beta_part)

# Meat for HC0 (with triangular weights fixed, treat as weighted regression)
# Each observation contributes w_i * x_i as the "effective" regressor row
# Score equation: sum_i w_i x_i e_i = 0
# HC0 meat = sum_i (w_i x_i e_i)(w_i x_i e_i)'
meat_earn <- matrix(0, 4, 4)
meat_part <- matrix(0, 4, 4)
meat_cross <- matrix(0, 4, 4)

for (i in 1:n_obs) {
  xi <- X[i, ]
  wi <- df$w[i]
  ei_earn <- resid_earn[i]
  ei_part <- resid_part[i]
  score_i <- wi * xi
  meat_earn <- meat_earn + (wi * ei_earn)^2 * outer(xi, xi)
  meat_part <- meat_part + (wi * ei_part)^2 * outer(xi, xi)
  meat_cross <- meat_cross + (wi^2 * ei_earn * ei_part) * outer(xi, xi)
}

V_earn <- XtWX_inv %*% meat_earn %*% XtWX_inv
V_part <- XtWX_inv %*% meat_part %*% XtWX_inv
V_cross <- XtWX_inv %*% meat_cross %*% XtWX_inv

rf_var <- V_earn[3, 3]
fs_var <- V_part[3, 3]
rf_fs_cov <- V_cross[3, 3]

rf_se <- sqrt(rf_var)
fs_se <- sqrt(fs_var)

# Treatment effect via IV: tau_IV = rf / fs
te_est <- rf_est / fs_est

# Delta method: var(rf/fs) = (1/fs)^2 * var(rf) + (rf/fs^2)^2 * var(fs) - 2*(rf/fs^3)*cov(rf,fs)
te_var <- (1/fs_est)^2 * rf_var + (rf_est/fs_est^2)^2 * fs_var - 2*(rf_est/fs_est^3) * rf_fs_cov
te_se <- sqrt(te_var)

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = as.numeric(te_est), se = as.numeric(te_se), n_obs = n_obs),
    list(term = "reduced_form", estimate = as.numeric(rf_est), se = as.numeric(rf_se), n_obs = n_obs),
    list(term = "first_stage", estimate = as.numeric(fs_est), se = as.numeric(fs_se), n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "fuzzy_rd_local_linear_triangular",
    vcov = "HC0"
  ),
  diagnostics = setNames(list(), character(0))
)

write(toJSON(result, auto_unbox = TRUE, digits = 10), "result.json")
