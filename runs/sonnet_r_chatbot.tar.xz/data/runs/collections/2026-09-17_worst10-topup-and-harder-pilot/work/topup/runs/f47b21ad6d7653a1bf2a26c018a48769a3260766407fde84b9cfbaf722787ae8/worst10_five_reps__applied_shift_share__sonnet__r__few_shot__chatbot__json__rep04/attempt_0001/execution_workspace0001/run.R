library(jsonlite)

df <- read.csv("input.csv")

# Normalize regional weights (one obs per region)
regions <- unique(df[, c("region_id", "region_weight", "x", "y")])
total_weight <- sum(regions$region_weight)
regions$e_r <- regions$region_weight / total_weight

# Merge normalized weights back
df <- merge(df, regions[, c("region_id", "e_r")], by = "region_id")

# Construct shift-share instrument z_r = sum_n share_rn * shock_n
region_z <- aggregate(share * shock ~ region_id, data = df, FUN = sum)
names(region_z)[2] <- "z_r"
regions <- merge(regions, region_z, by = "region_id")

# Weighted means
wmean <- function(x, w) sum(w * x) / sum(w)
mean_y <- wmean(regions$y, regions$e_r)
mean_x <- wmean(regions$x, regions$e_r)
mean_z <- wmean(regions$z_r, regions$e_r)

# Demeaned residuals
regions$y0 <- regions$y - mean_y
regions$x0 <- regions$x - mean_x
regions$z0 <- regions$z_r - mean_z

# Merge demeaned values back to df for aggregation
df <- merge(df, regions[, c("region_id", "y0", "x0", "z0")], by = "region_id")

# Industry-level exposure masses s_n and aggregated residuals
industries <- unique(df$industry_id)
N <- length(industries)

# s_n = sum_r e_r * share_rn
industry_agg <- aggregate(e_r * share ~ industry_id, data = df, FUN = sum)
names(industry_agg)[2] <- "s_n"

# Aggregated residuals vbar_n = sum_r e_r * share_rn * v0_r / s_n
agg_var <- function(var) {
  tmp <- aggregate(df$e_r * df$share * df[[var]] ~ df$industry_id, FUN = sum)
  names(tmp) <- c("industry_id", paste0(var, "_num"))
  tmp
}

ybar_num <- agg_var("y0")
xbar_num <- agg_var("x0")
zbar_num <- agg_var("z0")

ind_df <- merge(industry_agg, ybar_num, by = "industry_id")
ind_df <- merge(ind_df, xbar_num, by = "industry_id")
ind_df <- merge(ind_df, zbar_num, by = "industry_id")

ind_df$ybar <- ind_df$y0_num / ind_df$s_n
ind_df$xbar <- ind_df$x0_num / ind_df$s_n
ind_df$zbar <- ind_df$z0_num / ind_df$s_n

# Get shock values (constant within industry)
shocks <- unique(df[, c("industry_id", "shock")])
ind_df <- merge(ind_df, shocks, by = "industry_id")

# Shock-level IV regression function (same as example)
shock_iv <- function(dependent, endogenous, mass, N) {
  regressors <- cbind(1, endogenous)
  instruments <- cbind(1, ind_df$shock)
  cross <- crossprod(instruments, mass * regressors)
  beta <- solve(cross, crossprod(instruments, mass * dependent))
  residual <- drop(dependent - regressors %*% beta)
  scores <- instruments * (mass * residual)
  inverse <- solve(cross)
  covariance <- N / (N - 2) * inverse %*% crossprod(scores) %*% t(inverse)
  c(slope = beta[2], se = sqrt(covariance[2, 2]))
}

# Effect: IV of ybar on xbar, instrumenting with shock
effect <- shock_iv(ind_df$ybar, ind_df$xbar, ind_df$s_n, N)

# First stage: IV of xbar on zbar, instrumenting zbar with shock
first_stage <- shock_iv(ind_df$xbar, ind_df$zbar, ind_df$s_n, N)

# Effective shocks
eff_shocks <- 1 / sum(ind_df$s_n^2)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = unname(effect["slope"]), se = unname(effect["se"]), n_obs = as.integer(N)),
    list(term = "first_stage", estimate = unname(first_stage["slope"]), se = unname(first_stage["se"]), n_obs = as.integer(N)),
    list(term = "effective_shocks", estimate = eff_shocks, se = NULL, n_obs = as.integer(N))
  ),
  method_metadata = list(estimator = "2SLS shock-level aggregation", vcov = "HC1 exposure-robust"),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
