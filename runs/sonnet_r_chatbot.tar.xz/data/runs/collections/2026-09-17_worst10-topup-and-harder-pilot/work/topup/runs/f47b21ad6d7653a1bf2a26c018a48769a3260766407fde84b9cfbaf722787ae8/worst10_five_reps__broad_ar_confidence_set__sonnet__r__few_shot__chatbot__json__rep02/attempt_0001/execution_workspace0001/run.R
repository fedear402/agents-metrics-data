d <- read.csv("input.csv")
n <- nrow(d)
q <- 2L
df <- n - 4L
critical <- qf(0.95, q, df)

ry <- residuals(lm(y ~ x, data = d))
rd <- residuals(lm(endog ~ x, data = d))
rz1 <- residuals(lm(z1 ~ x, data = d))
rz2 <- residuals(lm(z2 ~ x, data = d))

full_y <- lm(y ~ x + z1 + z2, data = d)
full_d <- lm(endog ~ x + z1 + z2, data = d)
uy <- residuals(full_y)
ud <- residuals(full_d)

SSR_U_y <- sum(uy^2)
SSR_U_d <- sum(ud^2)
SSR_U_yd <- sum(uy * ud)

SSR_R_y <- sum(ry^2)
SSR_R_d <- sum(rd^2)
SSR_R_yd <- sum(ry * rd)

k <- q * critical / df

A <- SSR_R_d - (1 + k) * SSR_U_d
B <- -2 * (SSR_R_yd - (1 + k) * SSR_U_yd)
C <- SSR_R_y - (1 + k) * SSR_U_y

disc <- B^2 - 4 * A * C
bounds <- sort(Re(polyroot(c(C, B, A))))
unbounded_val <- as.integer(A < 0)

accepts <- function(beta) A * beta^2 + B * beta + C <= 0

accepts_zero <- as.integer(accepts(0))

transformed_one <- d$y - 1 * d$endog
full_fit_one <- lm(transformed_one ~ x + z1 + z2, data = d)
restricted_fit_one <- lm(transformed_one ~ x, data = d)
ar_f_at_one <- ((deviance(restricted_fit_one) - deviance(full_fit_one)) / q) / (deviance(full_fit_one) / df)

rows <- list(
  list(term = "boundary_low", estimate = unname(bounds[1]), se = NULL, n_obs = n),
  list(term = "boundary_high", estimate = unname(bounds[2]), se = NULL, n_obs = n),
  list(term = "accepts_zero", estimate = unname(as.numeric(accepts_zero)), se = NULL, n_obs = n),
  list(term = "unbounded", estimate = unname(as.numeric(unbounded_val)), se = NULL, n_obs = n),
  list(term = "ar_f_at_one", estimate = unname(ar_f_at_one), se = NULL, n_obs = n)
)

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = rows,
  method_metadata = list(estimator = "Anderson-Rubin", vcov = "homoskedastic"),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
