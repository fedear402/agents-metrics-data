library(sandwich)
library(jsonlite)

dat <- read.csv("input.csv")
names(dat) <- trimws(names(dat))

# Filter bandwidth
bw <- 1
dat <- dat[abs(dat$score) < bw, ]
n_obs <- nrow(dat)

# Triangular weights
dat$w <- 1 - abs(dat$score)

# Indicator for right side
dat$D <- as.integer(dat$score >= 0)

# Local linear: interact score with side indicator
dat$score_left  <- dat$score * (1 - dat$D)
dat$score_right <- dat$score * dat$D

# Fit reduced form (earnings)
rf_fit <- lm(earnings ~ D + score_left + score_right, data = dat, weights = w)
vcov_rf <- vcovHC(rf_fit, type = "HC0")
rf_est <- coef(rf_fit)["D"]
rf_se  <- sqrt(vcov_rf["D", "D"])

# Fit first stage (participated)
fs_fit <- lm(participated ~ D + score_left + score_right, data = dat, weights = w)
vcov_fs <- vcovHC(fs_fit, type = "HC0")
fs_est <- coef(fs_fit)["D"]
fs_se  <- sqrt(vcov_fs["D", "D"])

# Delta method for treatment effect = rf / fs
# Need joint covariance of rf_D and fs_D estimates
# Stack residuals approach: use meat of joint sandwich

# Extract model matrices and residuals
X <- model.matrix(rf_fit)
W <- diag(dat$w)

# Weighted bread (same X for both models)
bread <- solve(t(X) %*% W %*% X)

# Residuals
e_rf <- residuals(rf_fit)
e_fs <- residuals(fs_fit)

# Meat for joint covariance of [rf_D, fs_D]
# Score vectors
s_rf <- as.vector(dat$w) * e_rf * X  # n x k
s_fs <- as.vector(dat$w) * e_fs * X  # n x k

# Joint meat blocks
meat_rr <- t(s_rf) %*% s_rf
meat_ff <- t(s_fs) %*% s_fs
meat_rf <- t(s_rf) %*% s_fs

# Covariance matrices
vcov_rf2 <- bread %*% meat_rr %*% bread
vcov_fs2 <- bread %*% meat_ff %*% bread
vcov_cross <- bread %*% meat_rf %*% bread

# Extract D coefficient index
idx <- which(names(coef(rf_fit)) == "D")

var_rf <- vcov_rf2[idx, idx]
var_fs <- vcov_fs2[idx, idx]
cov_rf_fs <- vcov_cross[idx, idx]

# Delta method: te = rf/fs
# var(te) = (1/fs)^2 * var_rf + (rf/fs^2)^2 * var_fs - 2*(rf/fs^3)*cov_rf_fs
te_est <- rf_est / fs_est
var_te <- (1/fs_est)^2 * var_rf + (rf_est/fs_est^2)^2 * var_fs - 2*(rf_est/fs_est^3)*cov_rf_fs
te_se <- sqrt(var_te)

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = as.numeric(te_est), se = as.numeric(te_se), n_obs = n_obs),
    list(term = "reduced_form",     estimate = as.numeric(rf_est), se = as.numeric(rf_se), n_obs = n_obs),
    list(term = "first_stage",      estimate = as.numeric(fs_est), se = as.numeric(fs_se), n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "fuzzy_RD_local_linear_triangular",
    vcov = "HC0"
  ),
  diagnostics = list()
)

write(toJSON(result, auto_unbox = TRUE, digits = 10), "result.json")
