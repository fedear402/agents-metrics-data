library(AER)
library(sandwich)
library(jsonlite)

dat <- read.csv("input.csv")

# One obs per region
regions <- dat[!duplicated(dat$region_id), c("region_id", "region_weight", "x", "y")]
regions$e_r <- regions$region_weight / sum(regions$region_weight)

# Construct shift-share instrument z_r = sum_n share_rn * shock_n
shock_map <- dat[!duplicated(dat$industry_id), c("industry_id", "shock")]
dat2 <- merge(dat, shock_map[, c("industry_id", "shock")], by = "industry_id", suffixes = c("", ".dup"))
# shock already in dat, just use it
z_r <- tapply(dat$share * dat$shock, dat$region_id, sum)
regions$z <- z_r[as.character(regions$region_id)]

# Weighted means
wmean <- function(v, w) sum(v * w) / sum(w)
ym <- wmean(regions$y, regions$e_r)
xm <- wmean(regions$x, regions$e_r)
zm <- wmean(regions$z, regions$e_r)

regions$y0 <- regions$y - ym
regions$x0 <- regions$x - xm
regions$z0 <- regions$z - zm

# Industry-level aggregation
industries <- unique(dat$industry_id)
N <- length(industries)

# s_n = sum_r e_r * share_rn
# merge e_r into dat
dat_m <- merge(dat, regions[, c("region_id", "e_r", "y0", "x0", "z0")], by = "region_id")

s_n <- tapply(dat_m$e_r * dat_m$share, dat_m$industry_id, sum)
ybar_n <- tapply(dat_m$e_r * dat_m$share * dat_m$y0, dat_m$industry_id, sum) / s_n
xbar_n <- tapply(dat_m$e_r * dat_m$share * dat_m$x0, dat_m$industry_id, sum) / s_n
zbar_n <- tapply(dat_m$e_r * dat_m$share * dat_m$z0, dat_m$industry_id, sum) / s_n

shock_n <- dat_m[!duplicated(dat_m$industry_id), c("industry_id", "shock")]
shock_n <- shock_n[order(shock_n$industry_id), ]
s_n_vec <- s_n[as.character(shock_n$industry_id)]
ybar_vec <- ybar_n[as.character(shock_n$industry_id)]
xbar_vec <- xbar_n[as.character(shock_n$industry_id)]
zbar_vec <- zbar_n[as.character(shock_n$industry_id)]
shock_vec <- shock_n$shock

# Shock-level IV: ybar_n ~ xbar_n | shock_n, weights = s_n, HC1
df_shock <- data.frame(
  ybar = ybar_vec,
  xbar = xbar_vec,
  zbar = zbar_vec,
  shock = shock_vec,
  sn = s_n_vec
)

# Effect: IV of ybar on xbar, instrument shock, weights s_n
iv_effect <- ivreg(ybar ~ xbar | shock, data = df_shock, weights = sn)
# HC1 with N/(N-2) multiplier: sandwich vcovHC HC1
vcov_effect <- vcovHC(iv_effect, type = "HC1")
se_effect <- sqrt(vcov_effect["xbar", "xbar"])
est_effect <- coef(iv_effect)["xbar"]

# First stage: x0_r on z0_r. Shock-level: xbar_n on zbar_n, instrument shock_n
iv_fs <- ivreg(xbar ~ zbar | shock, data = df_shock, weights = sn)
vcov_fs <- vcovHC(iv_fs, type = "HC1")
se_fs <- sqrt(vcov_fs["zbar", "zbar"])
est_fs <- coef(iv_fs)["zbar"]

# Effective shocks
eff_shocks <- 1 / sum(s_n_vec^2)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = as.numeric(est_effect), se = as.numeric(se_effect), n_obs = as.integer(N)),
    list(term = "first_stage", estimate = as.numeric(est_fs), se = as.numeric(se_fs), n_obs = as.integer(N)),
    list(term = "effective_shocks", estimate = as.numeric(eff_shocks), se = NULL, n_obs = as.integer(N))
  ),
  method_metadata = list(
    estimator = "2SLS shift-share with BHJ exposure-robust SE",
    vcov = "HC1 shock-level"
  ),
  diagnostics = list()
)

write(toJSON(result, auto_unbox = TRUE, null = "null", digits = 10), "result.json")
