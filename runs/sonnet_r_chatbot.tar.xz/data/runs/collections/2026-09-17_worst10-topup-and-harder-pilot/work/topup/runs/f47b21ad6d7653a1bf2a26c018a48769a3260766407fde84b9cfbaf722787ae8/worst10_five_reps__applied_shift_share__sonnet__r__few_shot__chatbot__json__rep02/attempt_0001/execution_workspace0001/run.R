library(jsonlite)

df <- read.csv("input.csv", stringsAsFactors = FALSE)

# Normalize regional weights (one obs per region)
regions <- unique(df[, c("region_id", "region_weight", "x", "y")])
total_weight <- sum(regions$region_weight)
regions$e_r <- regions$region_weight / total_weight

# Merge normalized weights back
df <- merge(df, regions[, c("region_id", "e_r")], by = "region_id")

# Construct regional shift-share instrument
df$weighted_share_shock <- df$share * df$shock
z_r <- aggregate(weighted_share_shock ~ region_id, data = df, FUN = sum)
names(z_r)[2] <- "z_r"
regions <- merge(regions, z_r, by = "region_id")

# Weighted means
mean_y <- sum(regions$e_r * regions$y)
mean_x <- sum(regions$e_r * regions$x)
mean_z <- sum(regions$e_r * regions$z_r)

# Demeaned residuals
regions$y0 <- regions$y - mean_y
regions$x0 <- regions$x - mean_x
regions$z0 <- regions$z_r - mean_z

# Industry-level exposure masses
industries <- unique(df$industry_id)
N <- length(industries)

s_n <- numeric(N)
ybar_n <- numeric(N)
xbar_n <- numeric(N)
zbar_n <- numeric(N)
shock_n <- numeric(N)

for (i in seq_along(industries)) {
  ind <- industries[i]
  sub <- df[df$industry_id == ind, ]
  # Merge region residuals
  sub <- merge(sub, regions[, c("region_id", "e_r", "y0", "x0", "z0")], by = "region_id")
  s <- sum(sub$e_r * sub$share)
  s_n[i] <- s
  ybar_n[i] <- sum(sub$e_r * sub$share * sub$y0) / s
  xbar_n[i] <- sum(sub$e_r * sub$share * sub$x0) / s
  zbar_n[i] <- sum(sub$e_r * sub$share * sub$z0) / s
  shock_n[i] <- sub$shock[1]
}

# Shock-level IV regression function
shock_iv <- function(dependent, endogenous, weights, shocks, n_ind) {
  regressors <- cbind(1, endogenous)
  instruments <- cbind(1, shocks)
  cross <- crossprod(instruments, weights * regressors)
  beta <- solve(cross, crossprod(instruments, weights * dependent))
  residual <- drop(dependent - regressors %*% beta)
  scores <- instruments * (weights * residual)
  inverse <- solve(cross)
  covariance <- n_ind / (n_ind - 2) * inverse %*% crossprod(scores) %*% t(inverse)
  c(slope = beta[2], se = sqrt(covariance[2, 2]))
}

# Effect: IV of ybar_n on xbar_n, instrument shock_n
effect <- shock_iv(ybar_n, xbar_n, s_n, shock_n, N)

# First stage: IV of xbar_n on zbar_n, instrument shock_n
first_stage <- shock_iv(xbar_n, zbar_n, s_n, shock_n, N)

# Effective shocks
effective_shocks <- 1 / sum(s_n^2)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = unname(effect["slope"]), se = unname(effect["se"]), n_obs = as.integer(N)),
    list(term = "first_stage", estimate = unname(first_stage["slope"]), se = unname(first_stage["se"]), n_obs = as.integer(N)),
    list(term = "effective_shocks", estimate = effective_shocks, se = NULL, n_obs = as.integer(N))
  ),
  method_metadata = list(estimator = "shock-level IV (Borusyak-Hull-Jaravel)", vcov = "HC1 exposure-robust"),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
