library(sandwich)
library(jsonlite)

dat <- read.csv("input.csv")
names(dat) <- trimws(names(dat))

# Apply bandwidth and triangular weights
bw <- 1
dat <- dat[abs(dat$score) < bw, ]
dat$w <- 1 - abs(dat$score)
n_obs <- nrow(dat)

# Indicator for right side
dat$D <- as.integer(dat$score >= 0)

# Design matrix for local linear with separate slopes
# Model: y ~ intercept_left + D + score_left + score_right
# where score_left = score*(1-D), score_right = score*D
dat$score_left <- dat$score * (1 - dat$D)
dat$score_right <- dat$score * dat$D

# Fit reduced form (earnings)
fit_rf <- lm(earnings ~ D + score_left + score_right, data = dat, weights = dat$w)

# Fit first stage (participated)
fit_fs <- lm(participated ~ D + score_left + score_right, data = dat, weights = dat$w)

# HC0 robust variance (no df correction)
vcov_rf <- vcovHC(fit_rf, type = "HC0")
vcov_fs <- vcovHC(fit_fs, type = "HC0")

# Discontinuity estimates = coefficient on D
rf_est <- coef(fit_rf)["D"]
fs_est <- coef(fit_fs)["D"]

rf_se <- sqrt(vcov_rf["D", "D"])
fs_se <- sqrt(vcov_fs["D", "D"])

# Treatment effect via ratio (Wald/fuzzy RD)
te_est <- rf_est / fs_est

# Delta method for SE of ratio
# Need joint covariance of (rf_D, fs_D)
# Stack residuals to get cross-covariance
# Bread matrices
X <- model.matrix(fit_rf)
W <- diag(dat$w)

bread <- solve(t(X) %*% W %*% X)

# Meat for cross-covariance
e_rf <- residuals(fit_rf)
e_fs <- residuals(fit_fs)

# HC0 meat: sum of w_i^2 * e_rf_i * e_fs_i * x_i x_i'
# But for cross terms we need: bread_rf %*% (X'W diag(e_rf*e_fs) WX) %*% bread_fs
# Weighted residuals
we_rf <- sqrt(dat$w) * e_rf
we_fs <- sqrt(dat$w) * e_fs

# HC0 sandwich cross-covariance
Xw <- X * dat$w  # W*X
meat_cross <- t(Xw * e_rf) %*% (Xw * e_fs)  # Wait, need to be careful

# Actually HC0: V = B * (sum_i w_i^2 e_i e_i' x_i x_i') * B
# For cross: cov(b_rf, b_fs) = B_rf * (sum_i w_i^2 e_rf_i e_fs_i x_i x_i') * B_fs
# Since same X and same weights:
meat_cross <- t(X * (dat$w * e_rf)) %*% (X * (dat$w * e_fs))
vcov_cross <- bread %*% meat_cross %*% bread

cov_rf_fs <- vcov_cross["D", "D"]

# Delta method: Var(rf/fs) = (1/fs)^2 * Var(rf) + (rf/fs^2)^2 * Var(fs) - 2*(rf/fs^3)*Cov(rf,fs)
var_rf <- vcov_rf["D", "D"]
var_fs <- vcov_fs["D", "D"]

var_te <- (1/fs_est)^2 * var_rf + (rf_est/fs_est^2)^2 * var_fs - 2*(rf_est/fs_est^3)*cov_rf_fs
te_se <- sqrt(var_te)

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = as.numeric(te_est), se = as.numeric(te_se), n_obs = n_obs),
    list(term = "reduced_form", estimate = as.numeric(rf_est), se = as.numeric(rf_se), n_obs = n_obs),
    list(term = "first_stage", estimate = as.numeric(fs_est), se = as.numeric(fs_se), n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "fuzzy_rd_local_linear_wald",
    vcov = "HC0"
  ),
  diagnostics = list()
)

write(toJSON(result, auto_unbox = TRUE, digits = 10), "result.json")
