library(jsonlite)

df <- read.csv("input.csv")

# Normalize weights: one obs per region
regions <- unique(df[, c("region_id", "region_weight")])
total_weight <- sum(regions$region_weight)
regions$e_r <- regions$region_weight / total_weight

df <- merge(df, regions[, c("region_id", "e_r")], by = "region_id")

# Construct shift-share instrument z_r = sum_n share_rn * shock_n
df$share_shock <- df$share * df$shock
z_by_region <- aggregate(share_shock ~ region_id, data = df, FUN = sum)
names(z_by_region)[2] <- "z_r"
df <- merge(df, z_by_region, by = "region_id")

# Get one row per region
reg_df <- unique(df[, c("region_id", "e_r", "x", "y", "z_r")])

# Weighted means
mean_y <- sum(reg_df$e_r * reg_df$y)
mean_x <- sum(reg_df$e_r * reg_df$x)
mean_z <- sum(reg_df$e_r * reg_df$z_r)

reg_df$y0 <- reg_df$y - mean_y
reg_df$x0 <- reg_df$x - mean_x
reg_df$z0 <- reg_df$z_r - mean_z

# Industry-level aggregation
# s_n = sum_r e_r * share_rn
df2 <- merge(df, reg_df[, c("region_id", "y0", "x0", "z0")], by = "region_id")
df2$e_share <- df2$e_r * df2$share

s_n <- aggregate(e_share ~ industry_id, data = df2, FUN = sum)
names(s_n)[2] <- "s_n"

# vbar_n = sum_r e_r * share_rn * v0_r / s_n
df2$ey0 <- df2$e_r * df2$share * df2$y0
df2$ex0 <- df2$e_r * df2$share * df2$x0
df2$ez0 <- df2$e_r * df2$share * df2$z0

agg_y <- aggregate(ey0 ~ industry_id, data = df2, FUN = sum)
agg_x <- aggregate(ex0 ~ industry_id, data = df2, FUN = sum)
agg_z <- aggregate(ez0 ~ industry_id, data = df2, FUN = sum)

# Get shock per industry (constant within industry)
shocks <- unique(df2[, c("industry_id", "shock")])

ind_df <- merge(s_n, agg_y, by = "industry_id")
ind_df <- merge(ind_df, agg_x, by = "industry_id")
ind_df <- merge(ind_df, agg_z, by = "industry_id")
ind_df <- merge(ind_df, shocks, by = "industry_id")

ind_df$ybar <- ind_df$ey0 / ind_df$s_n
ind_df$xbar <- ind_df$ex0 / ind_df$s_n
ind_df$zbar <- ind_df$ez0 / ind_df$s_n

N <- nrow(ind_df)
s <- ind_df$s_n
shock_n <- ind_df$shock

# Shock-level IV regression: ybar ~ 1 + xbar, instrument = shock_n, weights = s_n
# HC1 with multiplier N/(N-2)
shock_iv <- function(dependent, endogenous, instrument, weights, N_obs) {
  regressors <- cbind(1, endogenous)
  instruments <- cbind(1, instrument)
  
  WZ <- instruments * weights
  cross <- t(WZ) %*% regressors  # Z'WX
  beta <- solve(cross, t(WZ) %*% dependent)  # (Z'WX)^{-1} Z'Wy
  
  residual <- dependent - regressors %*% beta
  scores <- instruments * (weights * residual)
  inverse <- solve(cross)
  meat <- t(scores) %*% scores
  covariance <- (N_obs / (N_obs - 2)) * inverse %*% meat %*% t(inverse)
  
  c(slope = beta[2], se = sqrt(covariance[2, 2]))
}

effect <- shock_iv(ind_df$ybar, ind_df$xbar, shock_n, s, N)
first_stage <- shock_iv(ind_df$xbar, ind_df$zbar, shock_n, s, N)

effective_shocks <- 1 / sum(s^2)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = unname(as.numeric(effect["slope"])),
         se = unname(as.numeric(effect["se"])), n_obs = as.integer(N)),
    list(term = "first_stage", estimate = unname(as.numeric(first_stage["slope"])),
         se = unname(as.numeric(first_stage["se"])), n_obs = as.integer(N)),
    list(term = "effective_shocks", estimate = unname(as.numeric(effective_shocks)),
         se = NULL, n_obs = as.integer(N))
  ),
  method_metadata = list(
    estimator = "shock-level IV (Borusyak-Hull-Jaravel)",
    vcov = "HC1 with N/(N-2) multiplier"
  ),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
