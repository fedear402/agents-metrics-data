library(sandwich)
library(jsonlite)

df <- read.csv("input.csv", stringsAsFactors = FALSE)
df <- df[order(df$date), ]

df$log_sales <- log(df$sales)
df$log_vix <- log(df$vix)
df$d_log_vix <- c(NA, diff(df$log_vix))

for (i in 1:15) {
  df[[paste0("lag_", i)]] <- c(rep(NA, i), df$d_log_vix[1:(nrow(df) - i)])
}

lag_vars <- paste0("lag_", 1:15)
formula_str <- paste("log_sales ~", paste(lag_vars, collapse = " + "))
df_complete <- df[complete.cases(df[, c("log_sales", lag_vars)]), ]

fit <- lm(as.formula(formula_str), data = df_complete)

N <- nrow(df_complete)
max_lag <- 15

# Newey-West with Bartlett weights 1 - j/16, multiplied by N/(N-16)
nw_vcov <- sandwich::NeweyWest(fit, lag = max_lag, prewhite = FALSE, adjust = FALSE,
                                weights = NULL)

# Recompute manually with exact weights 1-j/16 and scaling N/(N-16)
meat_nw <- function(model, max_lag) {
  X <- model.matrix(model)
  e <- residuals(model)
  n <- length(e)
  Xe <- X * e
  S <- t(Xe) %*% Xe / n
  for (j in 1:max_lag) {
    w <- 1 - j / (max_lag + 1)
    Gamma_j <- t(Xe[(j+1):n, , drop=FALSE]) %*% Xe[1:(n-j), , drop=FALSE] / n
    S <- S + w * (Gamma_j + t(Gamma_j))
  }
  S
}

X <- model.matrix(fit)
e <- residuals(fit)
n <- N
bread <- solve(t(X) %*% X / n)
meat <- meat_nw(fit, max_lag)
vcov_nw <- (bread %*% meat %*% bread) / n
# Scale by N/(N-16)
vcov_scaled <- vcov_nw * n / (n - 16)

coefs <- coef(fit)
ses <- sqrt(diag(vcov_scaled))

# Cumulative response: sum of lag_1 through lag_15 coefficients
lag_names <- paste0("lag_", 1:15)
cum_response <- sum(coefs[lag_names])

# SE for cumulative response using full covariance matrix
R <- matrix(0, nrow = 1, ncol = length(coefs))
lag_idx <- which(names(coefs) %in% lag_names)
R[1, lag_idx] <- 1
cum_se <- sqrt(as.numeric(R %*% vcov_scaled %*% t(R)))

lag1_est <- coefs["lag_1"]
lag1_se <- ses["lag_1"]
lag15_est <- coefs["lag_15"]
lag15_se <- ses["lag_15"]

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(term = "cumulative_response", estimate = as.numeric(cum_response),
         se = as.numeric(cum_se), n_obs = as.integer(N)),
    list(term = "lag_1", estimate = as.numeric(lag1_est),
         se = as.numeric(lag1_se), n_obs = as.integer(N)),
    list(term = "lag_15", estimate = as.numeric(lag15_est),
         se = as.numeric(lag15_se), n_obs = as.integer(N))
  ),
  method_metadata = list(
    estimator = "OLS",
    vcov = "Newey-West HAC, max_lag=15, Bartlett weights 1-j/16, scaled N/(N-16)"
  ),
  diagnostics = list()
)

write(toJSON(result, auto_unbox = TRUE, digits = 10), "result.json")
