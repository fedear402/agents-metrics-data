library(sandwich)
library(jsonlite)

df <- read.csv("input.csv")
df <- df[order(df$date), ]

df$log_sales <- log(df$sales)
df$log_vix <- log(df$vix)
df$dlvix <- c(NA, diff(df$log_vix))

for (k in 1:15) {
  df[[paste0("lag_", k)]] <- c(rep(NA, k), df$dlvix[1:(nrow(df) - k)])
}

lag_cols <- paste0("lag_", 1:15)
df_complete <- df[complete.cases(df[, c("log_sales", lag_cols)]), ]

formula_str <- paste("log_sales ~", paste(lag_cols, collapse = " + "))
fit <- lm(as.formula(formula_str), data = df_complete)

N <- nrow(df_complete)
max_lag <- 15

# Newey-West with Bartlett weights 1 - j/16, multiplied by N/(N-16)
nw_vcov <- NeweyWest(fit, lag = max_lag, prewhite = FALSE, adjust = FALSE,
                     weights = NULL, sandwich = TRUE)

# NeweyWest with adjust=FALSE uses 1/N scaling; we need N/(N-16) correction
# sandwich package NeweyWest: by default uses 1/N, we need to multiply by N/(N-16)
nw_vcov <- nw_vcov * N / (N - 16)

coefs <- coef(fit)
lag_names <- paste0("lag_", 1:15)

# Cumulative response = sum of 15 lag coefficients
cum_resp <- sum(coefs[lag_names])

# Variance of cumulative response using full covariance matrix
vcov_lags <- nw_vcov[lag_names, lag_names]
cum_var <- sum(vcov_lags)
cum_se <- sqrt(cum_var)

lag1_est <- coefs["lag_1"]
lag1_se <- sqrt(nw_vcov["lag_1", "lag_1"])

lag15_est <- coefs["lag_15"]
lag15_se <- sqrt(nw_vcov["lag_15", "lag_15"])

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(term = "cumulative_response", estimate = as.numeric(cum_resp), se = as.numeric(cum_se), n_obs = as.integer(N)),
    list(term = "lag_1", estimate = as.numeric(lag1_est), se = as.numeric(lag1_se), n_obs = as.integer(N)),
    list(term = "lag_15", estimate = as.numeric(lag15_est), se = as.numeric(lag15_se), n_obs = as.integer(N))
  ),
  method_metadata = list(
    estimator = "OLS",
    vcov = "Newey-West HAC, max lag 15, Bartlett weights 1-j/16, scaled by N/(N-16)"
  ),
  diagnostics = list()
)

write(toJSON(result, auto_unbox = TRUE, digits = 10), "result.json")
