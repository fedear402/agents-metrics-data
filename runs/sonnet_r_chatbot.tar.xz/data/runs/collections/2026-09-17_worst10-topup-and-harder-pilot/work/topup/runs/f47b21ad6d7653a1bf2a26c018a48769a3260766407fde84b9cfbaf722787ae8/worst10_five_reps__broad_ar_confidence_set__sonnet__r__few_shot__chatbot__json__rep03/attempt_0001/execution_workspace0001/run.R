library(jsonlite)

d <- read.csv("input.csv")
n <- nrow(d)

# Unrestricted: regress y on intercept, x, z1, z2
# Restricted: for each beta, regress y-beta*endog on intercept, x, z1, z2
# F test on z1, z2 coefficients (q=2 excluded instruments)
# df = n - 4 (intercept + x + z1 + z2)

q <- 2L
df <- n - 4L
critical <- qf(0.95, q, df)

# Precompute residuals from unrestricted model
# Unrestricted: y ~ 1 + x + z1 + z2 (for the outcome side)
# We need to invert: F(beta) <= critical

# Following the example approach:
# For each beta, transformed = y - beta*endog
# Restricted model: transformed ~ 1 + x (exclude z1, z2)
# Full model: transformed ~ 1 + x + z1 + z2
# F = ((SSR_R - SSR_U)/q) / (SSR_U/df)
# Accept when F <= critical, i.e., SSR_R - (1 + q*critical/df)*SSR_U <= 0

# Analytical inversion:
# Let t = y - beta*endog
# SSR_R = residuals from t ~ 1 + x
# SSR_U = residuals from t ~ 1 + x + z1 + z2

# We can use Frisch-Waugh to express these analytically
# M_W = annihilator of [1, x]
# M_F = annihilator of [1, x, z1, z2]

# Compute projection matrices
W <- cbind(1, d$x)
F_mat <- cbind(1, d$x, d$z1, d$z2)

# M_W projector
MW <- diag(n) - W %*% solve(t(W) %*% W) %*% t(W)
MF <- diag(n) - F_mat %*% solve(t(F_mat) %*% F_mat) %*% t(F_mat)

# Residuals of y and endog after partialling out W and F_mat
ry_W <- MW %*% d$y
re_W <- MW %*% d$endog
ry_F <- MF %*% d$y
re_F <- MF %*% d$endog

# SSR_R(beta) = ||M_W(y - beta*endog)||^2 = ||ry_W - beta*re_W||^2
#             = sum(ry_W^2) - 2*beta*sum(ry_W*re_W) + beta^2*sum(re_W^2)
# SSR_U(beta) = ||M_F(y - beta*endog)||^2 = ||ry_F - beta*re_F||^2
#             = sum(ry_F^2) - 2*beta*sum(ry_F*re_F) + beta^2*sum(re_F^2)

a_R <- sum(re_W^2)
b_R <- -2*sum(ry_W*re_W)
c_R <- sum(ry_W^2)

a_U <- sum(re_F^2)
b_U <- -2*sum(ry_F*re_F)
c_U <- sum(ry_F^2)

k <- q * critical / df

# Condition: SSR_R - (1+k)*SSR_U <= 0
# (a_R - (1+k)*a_U)*beta^2 + (b_R - (1+k)*b_U)*beta + (c_R - (1+k)*c_U) <= 0
A <- a_R - (1+k)*a_U
B <- b_R - (1+k)*b_U
C <- c_R - (1+k)*c_U

disc <- B^2 - 4*A*C
stopifnot(abs(A) > 1e-10, disc > 0)

bounds <- sort(Re(polyroot(c(C, B, A))))
boundary_low <- bounds[1]
boundary_high <- bounds[2]

accepts <- function(beta) A*beta^2 + B*beta + C <= 0

accepts_zero <- as.integer(accepts(0))
unbounded <- as.integer(A < 0)

# Compute AR F statistic at beta=1
beta_test <- 1
transformed <- d$y - beta_test * d$endog
fit_full <- lm(transformed ~ d$x + d$z1 + d$z2)
fit_restr <- lm(transformed ~ d$x)
SSR_U <- deviance(fit_full)
SSR_R <- deviance(fit_restr)
ar_f_at_one <- ((SSR_R - SSR_U)/q) / (SSR_U/df)

rows <- list(
  list(term="boundary_low", estimate=unname(boundary_low), se=NULL, n_obs=n),
  list(term="boundary_high", estimate=unname(boundary_high), se=NULL, n_obs=n),
  list(term="accepts_zero", estimate=unname(accepts_zero), se=NULL, n_obs=n),
  list(term="unbounded", estimate=unname(unbounded), se=NULL, n_obs=n),
  list(term="ar_f_at_one", estimate=unname(ar_f_at_one), se=NULL, n_obs=n)
)

result <- list(
  task_id="broad_ar_confidence_set",
  platform="r",
  estimates=rows,
  method_metadata=list(estimator="Anderson-Rubin inversion", vcov="homoskedastic"),
  diagnostics=list()
)

write_json(result, "result.json", auto_unbox=TRUE, null="null", digits=16, pretty=TRUE)
