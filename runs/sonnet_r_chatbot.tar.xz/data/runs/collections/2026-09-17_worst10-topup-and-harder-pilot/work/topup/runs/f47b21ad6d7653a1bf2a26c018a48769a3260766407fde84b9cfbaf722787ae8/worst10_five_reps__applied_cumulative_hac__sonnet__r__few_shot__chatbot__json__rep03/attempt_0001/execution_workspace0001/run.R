library(jsonlite)

data <- read.csv("input.csv", stringsAsFactors = FALSE)
data$date <- as.Date(data$date)
data <- data[order(data$date), ]

data$log_sales <- log(data$sales)
data$log_vix <- log(data$vix)
data$vix_change <- c(NA, diff(data$log_vix))

n_lags <- 15
for (i in 1:n_lags) {
  data[[paste0("lag_", i)]] <- c(rep(NA, i), head(data$vix_change, -i))
}

lag_cols <- paste0("lag_", 1:n_lags)
keep_cols <- c("log_sales", lag_cols)
sample <- data[complete.cases(data[, keep_cols]), ]

formula_str <- paste("log_sales ~", paste(lag_cols, collapse = " + "))
fit <- lm(as.formula(formula_str), data = sample)

X <- model.matrix(fit)
coefs <- coef(fit)
N <- nrow(X)
p <- ncol(X)
resids <- residuals(fit)
scores <- X * resids

hac_lags <- 15
meat <- crossprod(scores)
for (j in seq_len(hac_lags)) {
  w <- 1 - j / (hac_lags + 1)
  lag_prod <- crossprod(scores[(j+1):N, , drop=FALSE], scores[1:(N-j), , drop=FALSE])
  meat <- meat + w * (lag_prod + t(lag_prod))
}

bread <- solve(crossprod(X))
covariance <- (N / (N - p)) * bread %*% meat %*% bread

contrast <- c(0, rep(1, n_lags))
cumulative <- sum(contrast * coefs)
cumulative_se <- sqrt(drop(t(contrast) %*% covariance %*% contrast))

lag1_idx <- 2
lag15_idx <- 16

lag1_est <- coefs[lag1_idx]
lag1_se <- sqrt(covariance[lag1_idx, lag1_idx])

lag15_est <- coefs[lag15_idx]
lag15_se <- sqrt(covariance[lag15_idx, lag15_idx])

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(term = "cumulative_response", estimate = unname(cumulative), se = unname(cumulative_se), n_obs = as.integer(N)),
    list(term = "lag_1", estimate = unname(lag1_est), se = unname(lag1_se), n_obs = as.integer(N)),
    list(term = "lag_15", estimate = unname(lag15_est), se = unname(lag15_se), n_obs = as.integer(N))
  ),
  method_metadata = list(
    estimator = "OLS",
    vcov = "Newey-West HAC, Bartlett kernel, max lag 15, correction N/(N-16)"
  ),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, digits = 16, pretty = TRUE)
