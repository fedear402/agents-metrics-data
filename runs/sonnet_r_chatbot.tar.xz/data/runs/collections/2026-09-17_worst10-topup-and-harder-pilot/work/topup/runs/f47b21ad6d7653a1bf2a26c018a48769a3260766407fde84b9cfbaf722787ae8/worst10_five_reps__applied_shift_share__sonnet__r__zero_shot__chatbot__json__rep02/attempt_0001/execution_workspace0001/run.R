library(AER)
library(sandwich)
library(jsonlite)

dat <- read.csv("input.csv")

# One obs per region
regions <- unique(dat[, c("region_id", "region_weight", "x", "y")])
regions$e_r <- regions$region_weight / sum(regions$region_weight)

# Construct instrument z_r = sum_n share_rn * shock_n
shock_lookup <- unique(dat[, c("industry_id", "shock")])
dat2 <- merge(dat, shock_lookup, by = "industry_id", all.x = TRUE)
# Already have shock in dat, just use it
z_r <- aggregate(share * shock ~ region_id, data = dat, FUN = sum)
names(z_r) <- c("region_id", "z")

regions <- merge(regions, z_r, by = "region_id")

# Weighted means
wmean <- function(v, w) sum(v * w) / sum(w)

mu_y <- wmean(regions$y, regions$e_r)
mu_x <- wmean(regions$x, regions$e_r)
mu_z <- wmean(regions$z, regions$e_r)

regions$y0 <- regions$y - mu_y
regions$x0 <- regions$x - mu_x
regions$z0 <- regions$z - mu_z

# Industry-level aggregation
industries <- unique(dat$industry_id)
N <- length(industries)

# s_n = sum_r e_r * share_rn
dat_merged <- merge(dat, regions[, c("region_id", "e_r", "y0", "x0", "z0")], by = "region_id")

s_n_df <- aggregate(e_r * share ~ industry_id, data = dat_merged, FUN = sum)
names(s_n_df) <- c("industry_id", "s_n")

# ybar_n, xbar_n, zbar_n = sum_r e_r * share_rn * v0_r / s_n
dat_merged$ew_share <- dat_merged$e_r * dat_merged$share

ybar_df <- aggregate(ew_share * y0 ~ industry_id, data = dat_merged, FUN = sum)
names(ybar_df) <- c("industry_id", "ybar_num")
xbar_df <- aggregate(ew_share * x0 ~ industry_id, data = dat_merged, FUN = sum)
names(xbar_df) <- c("industry_id", "xbar_num")
zbar_df <- aggregate(ew_share * z0 ~ industry_id, data = dat_merged, FUN = sum)
names(zbar_df) <- c("industry_id", "zbar_num")

shock_df <- unique(dat[, c("industry_id", "shock")])

ind_df <- Reduce(function(a, b) merge(a, b, by = "industry_id"),
                 list(s_n_df, ybar_df, xbar_df, zbar_df, shock_df))
ind_df$ybar <- ind_df$ybar_num / ind_df$s_n
ind_df$xbar <- ind_df$xbar_num / ind_df$s_n
ind_df$zbar <- ind_df$zbar_num / ind_df$s_n

# Shock-level IV: ybar ~ 1 + xbar | 1 + shock, weights = s_n
iv_effect <- ivreg(ybar ~ xbar | shock, data = ind_df, weights = s_n)

# HC1 variance with N/(N-2) multiplier (HC1 uses n/(n-k) = N/(N-2) for 2 params)
vcov_effect <- vcovHC(iv_effect, type = "HC1")
se_effect <- sqrt(vcov_effect["xbar", "xbar"])
coef_effect <- coef(iv_effect)["xbar"]

# First stage: regional x ~ 1 + z, weights = e_r
# Shock-level equivalent: xbar ~ 1 + zbar | 1 + shock, weights = s_n
iv_fs <- ivreg(xbar ~ zbar | shock, data = ind_df, weights = s_n)
vcov_fs <- vcovHC(iv_fs, type = "HC1")
se_fs <- sqrt(vcov_fs["zbar", "zbar"])
coef_fs <- coef(iv_fs)["zbar"]

# Effective shocks
eff_shocks <- 1 / sum(ind_df$s_n^2)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = as.numeric(coef_effect), se = as.numeric(se_effect), n_obs = as.integer(N)),
    list(term = "first_stage", estimate = as.numeric(coef_fs), se = as.numeric(se_fs), n_obs = as.integer(N)),
    list(term = "effective_shocks", estimate = as.numeric(eff_shocks), se = NULL, n_obs = as.integer(N))
  ),
  method_metadata = list(
    estimator = "2SLS shift-share with Borusyak-Hull-Jaravel exposure-robust SE",
    vcov = "HC1 shock-level"
  ),
  diagnostics = setNames(list(), character(0))
)

write(toJSON(result, auto_unbox = TRUE, digits = 10, null = "null"), "result.json")
