library(jsonlite)

dat <- read.csv("input.csv")
names(dat) <- trimws(names(dat))

# Apply bandwidth filter
bw_dat <- dat[abs(dat$score) < 1, ]
n_obs <- nrow(bw_dat)

# Triangular weights
bw_dat$w <- 1 - abs(bw_dat$score)

# Indicator for right side
bw_dat$above <- as.integer(bw_dat$score >= 0)

# Design matrix: intercept, score, above, score*above (separate slopes each side)
bw_dat$score_above <- bw_dat$score * bw_dat$above

X <- cbind(1, bw_dat$score, bw_dat$above, bw_dat$score_above)
w <- bw_dat$w
Y_earn <- bw_dat$earnings
Y_part <- bw_dat$participated

# WLS via manual computation
WX <- w * X
bread <- solve(t(X) %*% WX)

coef_earn <- bread %*% t(X) %*% (w * Y_earn)
coef_part <- bread %*% t(X) %*% (w * Y_part)

resid_earn <- Y_earn - X %*% coef_earn
resid_part <- Y_part - X %*% coef_part

# Discontinuity = coefficient on 'above' (index 3, 0-based: row 3 in 1-based)
contrast <- c(0, 0, 1, 0)

jump_earn <- drop(contrast %*% coef_earn)
jump_part <- drop(contrast %*% coef_part)

# HC0 sandwich: loading = w * (X %*% bread %*% contrast)
loading <- w * drop(X %*% bread %*% contrast)

# Influence for each outcome
inf_earn <- loading * resid_earn
inf_part <- loading * resid_part

# Joint covariance matrix (2x2)
inf_mat <- cbind(inf_earn, inf_part)
joint <- t(inf_mat) %*% inf_mat

se_earn <- sqrt(joint[1,1])
se_part <- sqrt(joint[2,2])

# Delta method for ratio = jump_earn / jump_part
# d(ratio)/d(jump_earn) = 1/jump_part
# d(ratio)/d(jump_part) = -jump_earn/jump_part^2
gradient <- c(1/jump_part, -jump_earn/jump_part^2)
ratio_se <- sqrt(drop(t(gradient) %*% joint %*% gradient))
ratio <- jump_earn / jump_part

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = unname(ratio), se = unname(ratio_se), n_obs = as.integer(n_obs)),
    list(term = "reduced_form", estimate = unname(jump_earn), se = unname(se_earn), n_obs = as.integer(n_obs)),
    list(term = "first_stage", estimate = unname(jump_part), se = unname(se_part), n_obs = as.integer(n_obs))
  ),
  method_metadata = list(
    estimator = "fuzzy_rd_local_linear_wald",
    vcov = "HC0"
  ),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, digits = 16, pretty = TRUE)
