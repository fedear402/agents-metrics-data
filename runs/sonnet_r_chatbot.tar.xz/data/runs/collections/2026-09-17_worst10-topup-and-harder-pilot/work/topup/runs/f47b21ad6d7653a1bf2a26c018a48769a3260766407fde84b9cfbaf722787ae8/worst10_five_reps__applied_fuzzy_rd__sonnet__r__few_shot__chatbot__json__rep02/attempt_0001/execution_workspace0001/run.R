library(jsonlite)

dat <- read.csv("input.csv")
names(dat) <- trimws(names(dat))

bw <- 1
in_bw <- abs(dat$score) < bw
sub <- dat[in_bw, ]
n <- nrow(sub)

w <- 1 - abs(sub$score)
above <- as.integer(sub$score >= 0)
score <- sub$score

X <- cbind(1, above, score, score * above)

bread <- solve(crossprod(X, w * X))

Y <- cbind(sub$earnings, sub$participated)
coef_mat <- bread %*% crossprod(X, w * Y)

resid_mat <- Y - X %*% coef_mat

contrast <- c(0, 1, 0, 0)

jumps <- drop(contrast %*% coef_mat)

loading <- w * drop(X %*% bread %*% contrast)
influence <- loading * resid_mat

joint <- crossprod(influence)

reduced_form <- jumps[1]
first_stage  <- jumps[2]
treatment_effect <- reduced_form / first_stage

gradient <- c(1/first_stage, -reduced_form/first_stage^2)
te_se <- sqrt(drop(t(gradient) %*% joint %*% gradient))

rf_se <- sqrt(joint[1,1])
fs_se <- sqrt(joint[2,2])

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = unname(treatment_effect), se = unname(te_se), n_obs = as.integer(n)),
    list(term = "reduced_form",     estimate = unname(reduced_form),     se = unname(rf_se), n_obs = as.integer(n)),
    list(term = "first_stage",      estimate = unname(first_stage),      se = unname(fs_se), n_obs = as.integer(n))
  ),
  method_metadata = list(
    estimator = "fuzzy_rd_local_linear",
    vcov = "HC0"
  ),
  diagnostics = setNames(list(), character(0))
)

write_json(result, "result.json", auto_unbox = TRUE, digits = 16, pretty = TRUE)
