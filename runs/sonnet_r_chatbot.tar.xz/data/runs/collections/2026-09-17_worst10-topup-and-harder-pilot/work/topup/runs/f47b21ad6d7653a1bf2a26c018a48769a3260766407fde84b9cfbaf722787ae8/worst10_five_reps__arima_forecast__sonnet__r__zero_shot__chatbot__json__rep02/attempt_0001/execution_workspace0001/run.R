library(forecast)
library(jsonlite)

data <- read.csv("./input.csv")
y <- data$y

fit <- Arima(y, order = c(1, 1, 1), include.constant = FALSE)

fc <- forecast(fit, h = 1, level = 95)

forecast_val <- as.numeric(fc$mean[1])
lower_val <- as.numeric(fc$lower[1, 1])
upper_val <- as.numeric(fc$upper[1, 1])

n_obs <- length(y)

result <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = list(
    list(term = "forecast", estimate = forecast_val, se = NULL, n_obs = n_obs),
    list(term = "lower_95", estimate = lower_val, se = NULL, n_obs = n_obs),
    list(term = "upper_95", estimate = upper_val, se = NULL, n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "ARIMA(1,1,1) via maximum likelihood",
    vcov = "none"
  ),
  diagnostics = setNames(list(), character(0))
)

write(toJSON(result, auto_unbox = TRUE, digits = 10, null = "null"), "./result.json")
