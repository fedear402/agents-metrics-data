library(jsonlite)

dat <- read.csv("input.csv")
n <- nrow(dat)
y <- dat$y
endog <- dat$endog
x <- dat$x
z1 <- dat$z1
z2 <- dat$z2

crit <- qf(0.95, df1 = 2, df2 = n - 4)

ar_f <- function(beta) {
  y_adj <- y - beta * endog
  fit <- lm(y_adj ~ x + z1 + z2)
  fit_r <- lm(y_adj ~ x)
  rss_r <- sum(residuals(fit_r)^2)
  rss_u <- sum(residuals(fit)^2)
  F_stat <- ((rss_r - rss_u) / 2) / (rss_u / (n - 4))
  F_stat
}

ar_f_at_one <- ar_f(1.0)

# AR F statistic as function of beta is a quadratic in beta
# F(beta) = [(RSS_r(beta) - RSS_u(beta))/2] / [RSS_u(beta)/(n-4)]
# We need to find where F(beta) = crit
# Let's work out analytically: F(beta) <= crit iff F(beta)*(n-4) <= 2*crit
# i.e., (RSS_r - RSS_u)/2 <= crit * RSS_u/(n-4)
# i.e., (n-4)(RSS_r - RSS_u) <= 2*crit*RSS_u
# i.e., (n-4)*RSS_r <= (n-4+2*crit)*RSS_u

# Both RSS_r and RSS_u are quadratic in beta, so F(beta) is ratio of quadratics
# F(beta)*crit_den = crit => numerator - crit*denominator = 0
# This is a quadratic equation in beta

# Let's find boundary by numerical root finding
# First, scan to understand the structure

betas_scan <- seq(-50, 50, by = 0.1)
f_vals <- sapply(betas_scan, ar_f)

# Find sign changes of (f_vals - crit)
diff_vals <- f_vals - crit

# Find where F crosses crit
crossings <- which(diff(sign(diff_vals)) != 0)

# Use uniroot to find precise crossings
boundaries <- c()
for (i in crossings) {
  b_lo <- betas_scan[i]
  b_hi <- betas_scan[i + 1]
  tryCatch({
    root <- uniroot(function(b) ar_f(b) - crit, lower = b_lo, upper = b_hi, tol = 1e-10)
    boundaries <- c(boundaries, root$root)
  }, error = function(e) NULL)
}

boundaries <- sort(unique(round(boundaries, 10)))

# Check if set is unbounded by checking extreme values
f_extreme_pos <- ar_f(1e6)
f_extreme_neg <- ar_f(-1e6)
unbounded <- as.integer(f_extreme_pos <= crit || f_extreme_neg <= crit)

# Check if zero is accepted
accepts_zero <- as.integer(ar_f(0) <= crit)

# For boundary points - should have exactly 2 finite boundaries
if (length(boundaries) >= 2) {
  boundary_low <- boundaries[1]
  boundary_high <- boundaries[length(boundaries)]
} else if (length(boundaries) == 1) {
  boundary_low <- boundaries[1]
  boundary_high <- boundaries[1]
} else {
  boundary_low <- NA
  boundary_high <- NA
}

# If unbounded, the confidence set extends to infinity
# Let's do a wider scan if needed
if (length(boundaries) < 2 && unbounded == 0) {
  betas_scan2 <- seq(-1000, 1000, by = 1)
  f_vals2 <- sapply(betas_scan2, ar_f)
  diff_vals2 <- f_vals2 - crit
  crossings2 <- which(diff(sign(diff_vals2)) != 0)
  boundaries2 <- c()
  for (i in crossings2) {
    b_lo <- betas_scan2[i]
    b_hi <- betas_scan2[i + 1]
    tryCatch({
      root <- uniroot(function(b) ar_f(b) - crit, lower = b_lo, upper = b_hi, tol = 1e-10)
      boundaries2 <- c(boundaries2, root$root)
    }, error = function(e) NULL)
  }
  boundaries2 <- sort(unique(round(boundaries2, 10)))
  if (length(boundaries2) >= 2) {
    boundary_low <- boundaries2[1]
    boundary_high <- boundaries2[length(boundaries2)]
  }
}

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = list(
    list(term = "boundary_low", estimate = boundary_low, se = NULL, n_obs = n),
    list(term = "boundary_high", estimate = boundary_high, se = NULL, n_obs = n),
    list(term = "accepts_zero", estimate = as.numeric(accepts_zero), se = NULL, n_obs = n),
    list(term = "unbounded", estimate = as.numeric(unbounded), se = NULL, n_obs = n),
    list(term = "ar_f_at_one", estimate = ar_f_at_one, se = NULL, n_obs = n)
  ),
  method_metadata = list(estimator = "Anderson-Rubin test inversion", vcov = "homoskedastic"),
  diagnostics = list()
)

write(toJSON(result, auto_unbox = TRUE, digits = 10, null = "null"), "result.json")
