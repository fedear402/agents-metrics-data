library(AER)
library(sandwich)
library(jsonlite)

# Load data
df <- read.csv("input.csv")

# Normalize regional weights (one obs per region)
regions <- unique(df[, c("region_id", "region_weight", "x", "y")])
regions$e_r <- regions$region_weight / sum(regions$region_weight)

# Construct shift-share instrument z_r = sum_n share_rn * shock_n
industry_shocks <- unique(df[, c("industry_id", "shock")])
df2 <- merge(df, regions[, c("region_id", "e_r")], by = "region_id")
z_r <- aggregate(share * shock ~ region_id, data = df2, FUN = sum)
colnames(z_r)[2] <- "z"
regions <- merge(regions, z_r, by = "region_id")

# Weighted means for demeaning
wmean <- function(v, w) sum(v * w) / sum(w)
e <- regions$e_r
ym <- wmean(regions$y, e)
xm <- wmean(regions$x, e)
zm <- wmean(regions$z, e)

regions$y0 <- regions$y - ym
regions$x0 <- regions$x - xm
regions$z0 <- regions$z - zm

# Merge e_r into df2
df3 <- merge(df2, regions[, c("region_id", "y0", "x0", "z0")], by = "region_id")

# For each industry n: s_n = sum_r e_r * share_rn
# ybar_n = sum_r e_r * share_rn * y0_r / s_n
agg_industry <- function(v0_col) {
  tmp <- aggregate(e_r * get(v0_col) * share ~ industry_id, data = df3, FUN = sum)
  sn <- aggregate(e_r * share ~ industry_id, data = df3, FUN = sum)
  colnames(sn)[2] <- "s_n"
  colnames(tmp)[2] <- paste0(v0_col, "_num")
  res <- merge(tmp, sn, by = "industry_id")
  res[[paste0(v0_col, "bar")]] <- res[[paste0(v0_col, "_num")]] / res$s_n
  res[, c("industry_id", paste0(v0_col, "bar"), "s_n")]
}

ybar <- agg_industry("y0")
xbar <- agg_industry("x0")
zbar <- agg_industry("z0")

ind_df <- merge(ybar[, c("industry_id", "y0bar", "s_n")],
                xbar[, c("industry_id", "x0bar")], by = "industry_id")
ind_df <- merge(ind_df, zbar[, c("industry_id", "z0bar")], by = "industry_id")
ind_df <- merge(ind_df, industry_shocks, by = "industry_id")

N <- nrow(ind_df)

# HC1 variance multiplier: N/(N-2)
hc1_mult <- N / (N - 2)

# Shock-level IV regression for effect: ybar ~ xbar, instrument = shock, weights = s_n
iv_effect <- ivreg(y0bar ~ x0bar | shock, data = ind_df, weights = ind_df$s_n)

# Get structural residuals and compute HC1 SE manually
# beta = (X'WZ)^{-1} Z'Wy where Z=shock instrument
# For simple IV with one endogenous var and one instrument:
# beta_iv = (z'Wx)^{-1} z'Wy (demeaned, since intercept included)

# Use ivreg coefficients
beta_effect <- coef(iv_effect)["x0bar"]

# Compute HC1 robust SE from ivreg
vcov_effect <- vcovHC(iv_effect, type = "HC1")
# vcovHC uses n/(n-k) by default for HC1 where k=number of params
# But we need N/(N-2) multiplier; HC1 with 2 params gives N/(N-2), which matches
se_effect <- sqrt(vcov_effect["x0bar", "x0bar"])

# First stage: x_r ~ z_r, e_r weights (regional level)
fs_regional <- lm(x ~ z, data = regions, weights = regions$e_r)
beta_fs <- coef(fs_regional)["z"]

# Shock-level equivalent for first stage SE:
# xbar_n ~ zbar_n, instrument = shock_n, weights = s_n
iv_fs <- ivreg(x0bar ~ z0bar | shock, data = ind_df, weights = ind_df$s_n)
vcov_fs <- vcovHC(iv_fs, type = "HC1")
se_fs <- sqrt(vcov_fs["z0bar", "z0bar"])

# Effective shocks
sn_vals <- ind_df$s_n / sum(ind_df$s_n)  # already normalized since e_r sums to 1 and shares sum to 1 within region
# Actually s_n = sum_r e_r * share_rn, and sum_n s_n = sum_r e_r * sum_n share_rn = sum_r e_r = 1
effective_shocks <- 1 / sum(ind_df$s_n^2)

# Build result
result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = as.numeric(beta_effect), se = as.numeric(se_effect), n_obs = as.integer(N)),
    list(term = "first_stage", estimate = as.numeric(beta_fs), se = as.numeric(se_fs), n_obs = as.integer(N)),
    list(term = "effective_shocks", estimate = as.numeric(effective_shocks), se = NULL, n_obs = as.integer(N))
  ),
  method_metadata = list(
    estimator = "2SLS shift-share with Borusyak-Hull-Jaravel shock-level SE",
    vcov = "HC1 heteroskedasticity-robust, shock-level aggregation"
  ),
  diagnostics = setNames(list(), character(0))
)

write(toJSON(result, auto_unbox = TRUE, digits = 10, null = "null"), "result.json")
