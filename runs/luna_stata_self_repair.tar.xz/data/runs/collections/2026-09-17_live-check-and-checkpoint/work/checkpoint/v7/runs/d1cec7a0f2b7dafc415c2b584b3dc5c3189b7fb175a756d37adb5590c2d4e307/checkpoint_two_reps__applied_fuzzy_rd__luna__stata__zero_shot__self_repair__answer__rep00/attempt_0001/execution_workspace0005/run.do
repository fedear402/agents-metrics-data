clear all
set linesize 255

import delimited "./input.csv", clear

keep if !missing(score, participated, earnings)
keep if abs(score) < 1
generate double weight = 1 - abs(score)

mata:
void main()
{
    real matrix X, bread, meat_y, meat_d, meat_yd, V_y, V_d, V_yd
    real colvector score, y, d, w, beta_y, beta_d, contrast
    real rowvector xi
    real scalar n, i, rf, fs, te
    real scalar var_rf, var_fs, cov_rf_fs, var_te
    real scalar ey, ed

    score = st_data(., "score")
    y = st_data(., "earnings")
    d = st_data(., "participated")
    w = st_data(., "weight")

    n = rows(score)
    X = J(n, 4, 0)

    for (i = 1; i <= n; i++) {
        if (score[i] < 0) {
            X[i,1] = 1
            X[i,2] = score[i]
        }
        else {
            X[i,3] = 1
            X[i,4] = score[i]
        }
    }

    bread = invsym(X' * diag(w) * X)
    beta_y = bread * X' * diag(w) * y
    beta_d = bread * X' * diag(w) * d

    meat_y = J(4, 4, 0)
    meat_d = J(4, 4, 0)
    meat_yd = J(4, 4, 0)

    for (i = 1; i <= n; i++) {
        xi = X[i,.]
        ey = y[i] - xi * beta_y
        ed = d[i] - xi * beta_d

        meat_y = meat_y + (w[i]^2) * (ey^2) * (xi' * xi)
        meat_d = meat_d + (w[i]^2) * (ed^2) * (xi' * xi)
        meat_yd = meat_yd + (w[i]^2) * ey * ed * (xi' * xi)
    }

    V_y = bread * meat_y * bread
    V_d = bread * meat_d * bread
    V_yd = bread * meat_yd * bread

    contrast = J(4, 1, 0)
    contrast[1] = -1
    contrast[3] = 1

    rf = contrast' * beta_y
    fs = contrast' * beta_d

    var_rf = contrast' * V_y * contrast
    var_fs = contrast' * V_d * contrast
    cov_rf_fs = contrast' * V_yd * contrast

    if (fs != 0) {
        te = rf / fs
        var_te = var_rf / (fs^2) + (rf^2 * var_fs) / (fs^4) -
            (2 * rf * cov_rf_fs) / (fs^3)
    }
    else {
        te = .
        var_te = .
    }

    st_numscalar("rf_est", rf)
    st_numscalar("rf_se", sqrt(max((0, var_rf))))
    st_numscalar("fs_est", fs)
    st_numscalar("fs_se", sqrt(max((0, var_fs))))
    st_numscalar("te_est", te)
    st_numscalar("te_se", sqrt(max((0, var_te))))
    st_numscalar("n_obs", n)
}
main()
end

display "ANSWER: treatment_effect estimate=" %21.12f scalar(te_est) " se=" %21.12f scalar(te_se) " n_obs=" %12.0f scalar(n_obs)
display "ANSWER: reduced_form estimate=" %21.12f scalar(rf_est) " se=" %21.12f scalar(rf_se) " n_obs=" %12.0f scalar(n_obs)
display "ANSWER: first_stage estimate=" %21.12f scalar(fs_est) " se=" %21.12f scalar(fs_se) " n_obs=" %12.0f scalar(n_obs)
