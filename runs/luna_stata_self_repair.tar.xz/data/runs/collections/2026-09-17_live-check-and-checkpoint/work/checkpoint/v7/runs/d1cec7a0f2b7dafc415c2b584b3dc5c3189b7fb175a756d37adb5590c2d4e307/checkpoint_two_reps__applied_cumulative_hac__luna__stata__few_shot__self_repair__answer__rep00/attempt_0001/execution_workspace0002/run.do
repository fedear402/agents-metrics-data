version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

generate double day = date(date, "YMD")
sort day
generate long observation = _n
tsset observation

generate double log_vix = log(vix)
generate double volatility_change = D.log_vix
generate double log_sales = log(sales)

local lagvars
forvalues j = 1/15 {
    generate double lag_`j' = L`j'.volatility_change
    local lagvars "`lagvars' lag_`j'"
}

keep if !missing(log_sales, `lagvars')

mata:
X = (J(st_nobs(), 1, 1), st_data(., "`lagvars'"))
y = st_data(., "log_sales")

coefficients = qrsolve(X, y)
residuals = y - X * coefficients
N = rows(X)
p = cols(X)

scores = X :* residuals
hac_lags = 15
meat = scores' * scores

for (j = 1; j <= hac_lags; j++) {
    lag_product = scores[|j + 1, 1 \ N, p|]' * scores[|1, 1 \ N - j, p|]
    meat = meat + (1 - j / 16) * (lag_product + lag_product')
}

bread = invsym(X' * X)
covariance = N / (N - 16) * bread * meat * bread

contrast = (J(1, 1, 0) \ J(15, 1, 1))
cumulative_response = contrast' * coefficients
cumulative_se = sqrt(contrast' * covariance * contrast)

st_numscalar("cumulative_response", cumulative_response)
st_numscalar("cumulative_se", cumulative_se)
st_numscalar("lag_1", coefficients[2])
st_numscalar("lag_1_se", sqrt(covariance[2, 2]))
st_numscalar("lag_15", coefficients[16])
st_numscalar("lag_15_se", sqrt(covariance[16, 16]))
st_numscalar("n_obs", N)
end

display "ANSWER: cumulative_response estimate=" %21.12f scalar(cumulative_response) ///
    " se=" %21.12f scalar(cumulative_se) ///
    " n_obs=" %12.0f scalar(n_obs)

display "ANSWER: lag_1 estimate=" %21.12f scalar(lag_1) ///
    " se=" %21.12f scalar(lag_1_se) ///
    " n_obs=" %12.0f scalar(n_obs)

display "ANSWER: lag_15 estimate=" %21.12f scalar(lag_15) ///
    " se=" %21.12f scalar(lag_15_se) ///
    " n_obs=" %12.0f scalar(n_obs)
