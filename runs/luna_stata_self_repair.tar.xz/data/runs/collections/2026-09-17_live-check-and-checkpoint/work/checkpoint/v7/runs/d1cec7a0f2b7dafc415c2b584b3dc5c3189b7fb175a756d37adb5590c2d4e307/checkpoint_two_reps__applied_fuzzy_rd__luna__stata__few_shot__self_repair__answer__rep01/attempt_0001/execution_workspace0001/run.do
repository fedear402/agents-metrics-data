version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

keep if !missing(score, participated, earnings)
keep if abs(score) < 1

generate double weight = 1 - abs(score)
generate byte right = score >= 0
generate double right_score = right * score

count
scalar n_obs = r(N)

mata:
score = st_data(., "score")
right = st_data(., "right")
right_score = st_data(., "right_score")
w = st_data(., "weight")
Y = st_data(., ("earnings", "participated"))

X = (J(rows(Y), 1, 1), score, right, right_score)

bread = invsym(X' * (w :* X))
coefficients = bread * X' * (w :* Y)
residuals = Y - X * coefficients

contrast = (0 \ 0 \ 1 \ 0)
jumps = contrast' * coefficients

loading = w :* (X * bread * contrast)
influence = loading :* residuals
joint = influence' * influence

reduced_form = jumps[1]
first_stage = jumps[2]
treatment_effect = reduced_form / first_stage

gradient = (1 / first_stage \ -reduced_form / first_stage^2)
treatment_se = sqrt(gradient' * joint * gradient)
reduced_se = sqrt(joint[1,1])
first_se = sqrt(joint[2,2])

st_numscalar("reduced_form", reduced_form)
st_numscalar("reduced_se", reduced_se)
st_numscalar("first_stage", first_stage)
st_numscalar("first_se", first_se)
st_numscalar("treatment_effect", treatment_effect)
st_numscalar("treatment_se", treatment_se)
end

display "ANSWER: treatment_effect estimate=" %21.12f treatment_effect " se=" %21.12f treatment_se " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f reduced_form " se=" %21.12f reduced_se " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f first_stage " se=" %21.12f first_se " n_obs=" %12.0f n_obs
