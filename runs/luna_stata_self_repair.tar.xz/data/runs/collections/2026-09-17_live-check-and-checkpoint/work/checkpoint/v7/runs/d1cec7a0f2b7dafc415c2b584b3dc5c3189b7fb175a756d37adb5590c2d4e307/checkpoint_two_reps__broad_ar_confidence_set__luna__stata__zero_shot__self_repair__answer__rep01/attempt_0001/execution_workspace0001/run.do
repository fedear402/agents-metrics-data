clear all
set linesize 255

import delimited "./input.csv", clear

quietly count
scalar n_obs = r(N)
scalar df_den = n_obs - 4
scalar fcrit = invF(0.95, 2, df_den)
scalar k = 1 + 2*fcrit/df_den

tempvar ybeta
scalar q_m1 = .
scalar q_0 = .
scalar q_1 = .
scalar f_at_one = .

foreach b in -1 0 1 {
    quietly generate double `ybeta' = y - (`b')*endog

    quietly regress `ybeta' x
    scalar ssr_r = e(rss)

    quietly regress `ybeta' x z1 z2
    scalar ssr_u = e(rss)

    quietly test z1 z2
    scalar f_value = r(F)

    scalar q_value = ssr_r - k*ssr_u

    if `b' == -1 {
        scalar q_m1 = q_value
    }
    if `b' == 0 {
        scalar q_0 = q_value
    }
    if `b' == 1 {
        scalar q_1 = q_value
        scalar f_at_one = f_value
    }

    quietly drop `ybeta'
}

scalar a = (q_1 + q_m1 - 2*q_0)/2
scalar c = (q_1 - q_m1)/2
scalar d = q_0
scalar discriminant = c^2 - 4*a*d

scalar boundary_low = (-c - sqrt(discriminant))/(2*a)
scalar boundary_high = (-c + sqrt(discriminant))/(2*a)

scalar accepts_zero = (d <= 0)
scalar unbounded = (a < 0)

display "ANSWER: boundary_low estimate=" %21.12f boundary_low " se=." " n_obs=" %12.0f n_obs
display "ANSWER: boundary_high estimate=" %21.12f boundary_high " se=." " n_obs=" %12.0f n_obs
display "ANSWER: accepts_zero estimate=" %21.12f accepts_zero " se=." " n_obs=" %12.0f n_obs
display "ANSWER: unbounded estimate=" %21.12f unbounded " se=." " n_obs=" %12.0f n_obs
display "ANSWER: ar_f_at_one estimate=" %21.12f f_at_one " se=." " n_obs=" %12.0f n_obs
