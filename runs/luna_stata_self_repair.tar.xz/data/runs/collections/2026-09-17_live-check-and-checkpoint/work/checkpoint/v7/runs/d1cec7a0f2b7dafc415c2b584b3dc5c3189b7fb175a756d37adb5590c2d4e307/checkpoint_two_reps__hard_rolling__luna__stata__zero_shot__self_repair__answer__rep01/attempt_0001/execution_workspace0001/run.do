clear
import delimited "./input.csv", clear

sort time
tsset time

scalar sse = 0
scalar forecast_101 = .
scalar forecast_150 = .
scalar forecast_200 = .
scalar forecast_250 = .

forvalues f = 101/250 {
    quietly regress y L.y if time >= `f' - 99 & time <= `f' - 1

    quietly summarize y if time == `f' - 1, meanonly
    scalar forecast = _b[_cons] + _b[L.y] * r(mean)

    quietly summarize y if time == `f', meanonly
    scalar sse = sse + (r(mean) - forecast)^2

    if `f' == 101 scalar forecast_101 = forecast
    if `f' == 150 scalar forecast_150 = forecast
    if `f' == 200 scalar forecast_200 = forecast
    if `f' == 250 scalar forecast_250 = forecast
}

scalar rmse = sqrt(sse / 150)
scalar se_missing = .

set linesize 255

display "ANSWER: rmse estimate=" %21.12f rmse " se=" %21.12f se_missing " n_obs=" %12.0f 150
display "ANSWER: forecast_101 estimate=" %21.12f forecast_101 " se=" %21.12f se_missing " n_obs=" %12.0f 99
display "ANSWER: forecast_150 estimate=" %21.12f forecast_150 " se=" %21.12f se_missing " n_obs=" %12.0f 99
display "ANSWER: forecast_200 estimate=" %21.12f forecast_200 " se=" %21.12f se_missing " n_obs=" %12.0f 99
display "ANSWER: forecast_250 estimate=" %21.12f forecast_250 " se=" %21.12f se_missing " n_obs=" %12.0f 99
