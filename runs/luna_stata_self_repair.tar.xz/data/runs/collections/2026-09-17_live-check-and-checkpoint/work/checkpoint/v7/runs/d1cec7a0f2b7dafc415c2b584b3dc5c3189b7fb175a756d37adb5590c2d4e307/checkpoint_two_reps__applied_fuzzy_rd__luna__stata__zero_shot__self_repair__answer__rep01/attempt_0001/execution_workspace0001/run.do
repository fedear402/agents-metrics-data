clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

keep if !missing(score, participated, earnings)
keep if abs(score) < 1

generate byte right = score >= 0
generate double weight = 1 - abs(score)
generate double score_right = score * right

mata:
    real matrix D, X, A, V
    real colvector y, p, s, r, w, ey, ep, b_y, b_p
    real scalar n, rf, fs, te, var_rf, var_fs, cov_rf_fs, var_te

    D = st_data(., ("earnings", "participated", "score", "right"))
    n = rows(D)

    y = D[,1]
    p = D[,2]
    s = D[,3]
    r = D[,4]
    w = 1 :- abs(s)

    X = (J(n,1,1), r, s, s:*r)
    A = invsym(X' * (X :* w))

    b_y = A * (X' * (w :* y))
    b_p = A * (X' * (w :* p))

    ey = y - X*b_y
    ep = p - X*b_p

    V = A * (X' * (X :* (w:^2 :* ey:^2))) * A
    var_rf = V[2,2]

    V = A * (X' * (X :* (w:^2 :* ep:^2))) * A
    var_fs = V[2,2]

    V = A * (X' * (X :* (w:^2 :* ey :* ep))) * A
    cov_rf_fs = V[2,2]

    rf = b_y[2]
    fs = b_p[2]

    if (fs != 0) {
        te = rf / fs
        var_te = var_rf/(fs^2) + (rf^2)*var_fs/(fs^4) ///
            - 2*rf*cov_rf_fs/(fs^3)
    }
    else {
        te = .
        var_te = .
    }

    st_numscalar("reduced_form", rf)
    st_numscalar("first_stage", fs)
    st_numscalar("treatment_effect", te)
    st_numscalar("reduced_form_se", sqrt(var_rf))
    st_numscalar("first_stage_se", sqrt(var_fs))
    st_numscalar("treatment_effect_se", sqrt(var_te))
    st_numscalar("n_obs", n)
end

display "ANSWER: treatment_effect estimate=" %21.12f treatment_effect " se=" %21.12f treatment_effect_se " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f reduced_form " se=" %21.12f reduced_form_se " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f first_stage " se=" %21.12f first_stage_se " n_obs=" %12.0f n_obs
