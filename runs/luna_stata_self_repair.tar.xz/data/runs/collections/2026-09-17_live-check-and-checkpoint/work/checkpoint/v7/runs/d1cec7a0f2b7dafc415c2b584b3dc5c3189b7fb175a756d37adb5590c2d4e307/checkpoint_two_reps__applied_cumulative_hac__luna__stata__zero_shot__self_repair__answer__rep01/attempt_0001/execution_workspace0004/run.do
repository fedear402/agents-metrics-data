clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

gen double __date = date(date, "YMD")
sort __date

gen double __y = ln(sales)
gen double __lvix = ln(vix)
gen double __dvol = __lvix - __lvix[_n-1]

gen long __t = _n
tsset __t

forvalues j = 1/15 {
    gen double __l`j' = L`j'.__dvol
}

regress __y __l1-__l15
predict double __u if e(sample), residuals

mata:
{
    real scalar N
    real scalar K
    real scalar t
    real scalar j
    real scalar L
    real scalar w
    real scalar hh
    real matrix X
    real matrix S
    real matrix B
    real matrix V
    real matrix zt
    real matrix zj
    real vector u

    L = 15

    X = st_data(., ("__l1", "__l2", "__l3", "__l4", "__l5", ///
        "__l6", "__l7", "__l8", "__l9", "__l10", "__l11", ///
        "__l12", "__l13", "__l14", "__l15"), "e(sample)")

    u = st_data(., "__u", "e(sample)")

    X = J(rows(X), 1, 1), X
    N = rows(X)
    K = cols(X)
    S = J(K, K, 0)

    for (t = 1; t <= N; t++) {
        zt = X[t,.]'
        S = S + zt * zt' * u[t]^2
        hh = min(t - 1, L)

        for (j = 1; j <= hh; j++) {
            w = 1 - j/16
            zj = X[t-j,.]'
            S = S + w * (zt*zj' + zj*zt') * u[t]*u[t-j]
        }
    }

    B = invsym(X'X)
    V = B*S*B * N/(N-16)

    st_matrix("Vnw", V)
    st_numscalar("Nreg", N)
}
end

scalar __cum = 0
forvalues j = 1/15 {
    scalar __cum = __cum + _b[__l`j']
}

matrix __c = J(1, 16, 0)
forvalues j = 1/15 {
    matrix __c[1, `=`j'+1'] = 1
}

scalar __se_cum = sqrt(__c * Vnw * __c')
scalar __se_l1 = sqrt(Vnw[2,2])
scalar __se_l15 = sqrt(Vnw[16,16])

display "ANSWER: cumulative_response estimate=" %21.12f __cum ///
    " se=" %21.12f __se_cum " n_obs=" %12.0f Nreg

display "ANSWER: lag_1 estimate=" %21.12f _b[__l1] ///
    " se=" %21.12f __se_l1 " n_obs=" %12.0f Nreg

display "ANSWER: lag_15 estimate=" %21.12f _b[__l15] ///
    " se=" %21.12f __se_l15 " n_obs=" %12.0f Nreg
