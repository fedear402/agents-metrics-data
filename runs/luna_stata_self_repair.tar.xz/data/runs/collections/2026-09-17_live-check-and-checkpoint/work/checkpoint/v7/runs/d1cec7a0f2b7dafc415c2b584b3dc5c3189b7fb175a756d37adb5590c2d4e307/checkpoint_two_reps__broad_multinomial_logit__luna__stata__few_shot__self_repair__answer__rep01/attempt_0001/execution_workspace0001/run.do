clear all
set more off
set linesize 255
set type double

import delimited "./input.csv", clear

mlogit y x z, baseoutcome(0)

scalar n_obs = e(N)
scalar prob_cat2_zero = exp(_b[2:_cons]) / ///
    (1 + exp(_b[1:_cons]) + exp(_b[2:_cons]))

display "ANSWER: x_cat1 estimate=" %21.12f (_b[1:x]) ///
    " se=" %21.12f (_se[1:x]) ///
    " n_obs=" %12.0f n_obs

display "ANSWER: z_cat1 estimate=" %21.12f (_b[1:z]) ///
    " se=" %21.12f (_se[1:z]) ///
    " n_obs=" %12.0f n_obs

display "ANSWER: x_cat2 estimate=" %21.12f (_b[2:x]) ///
    " se=" %21.12f (_se[2:x]) ///
    " n_obs=" %12.0f n_obs

display "ANSWER: z_cat2 estimate=" %21.12f (_b[2:z]) ///
    " se=" %21.12f (_se[2:z]) ///
    " n_obs=" %12.0f n_obs

display "ANSWER: prob_cat2_zero estimate=" %21.12f prob_cat2_zero ///
    " se=." ///
    " n_obs=" %12.0f n_obs
