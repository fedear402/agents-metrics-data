clear all
set more off
set linesize 255

import delimited "./input.csv", clear

gen double contribution = share * shock
bysort region_id: egen double z_r = total(contribution)
egen byte region_tag = tag(region_id)

egen double total_region_weight = total(cond(region_tag, region_weight, 0))
gen double e_r = region_weight / total_region_weight

egen double mean_y = total(cond(region_tag, e_r * y, 0))
egen double mean_x = total(cond(region_tag, e_r * x, 0))
egen double mean_z = total(cond(region_tag, e_r * z_r, 0))

gen double y0 = y - mean_y
gen double x0 = x - mean_x
gen double z0 = z_r - mean_z

tempfile regional
preserve
keep if region_tag
keep region_id e_r y0 x0 z0
save `regional'
restore

merge m:1 region_id using `regional', nogen assert(match)

gen double exposure_weight = e_r * share
gen double y_component = exposure_weight * y0
gen double x_component = exposure_weight * x0
gen double z_component = exposure_weight * z0

collapse (sum) s_n=exposure_weight ///
                 y_sum=y_component ///
                 x_sum=x_component ///
                 z_sum=z_component ///
         (firstnm) shock, by(industry_id)

keep if s_n > 0

gen double ybar = y_sum / s_n
gen double xbar = x_sum / s_n
gen double zbar = z_sum / s_n

quietly count
local n_industries = r(N)

quietly ivregress 2sls ybar (xbar = shock) [aw=s_n], vce(robust)
scalar effect_estimate = _b[xbar]
scalar effect_se = _se[xbar]

quietly ivregress 2sls xbar (zbar = shock) [aw=s_n], vce(robust)
scalar first_stage_estimate = _b[zbar]
scalar first_stage_se = _se[zbar]

quietly summarize s_n, meanonly
scalar effective_shocks_estimate = 1 / sum(s_n^2)

display "ANSWER: effect estimate=" %21.12f effect_estimate " se=" %21.12f effect_se " n_obs=" %12.0f `n_industries'
display "ANSWER: first_stage estimate=" %21.12f first_stage_estimate " se=" %21.12f first_stage_se " n_obs=" %12.0f `n_industries'
display "ANSWER: effective_shocks estimate=" %21.12f effective_shocks_estimate " se=" %21.12f . " n_obs=" %12.0f `n_industries'
