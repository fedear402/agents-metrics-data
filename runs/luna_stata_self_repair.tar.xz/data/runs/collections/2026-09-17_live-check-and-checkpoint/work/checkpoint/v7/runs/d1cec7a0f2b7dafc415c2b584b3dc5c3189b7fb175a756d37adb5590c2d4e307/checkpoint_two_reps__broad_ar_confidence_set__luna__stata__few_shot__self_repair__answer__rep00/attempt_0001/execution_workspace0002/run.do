clear all
set more off
set linesize 255
set type double

import delimited using "./input.csv", clear

quietly count
scalar n_obs = r(N)
scalar q = 2
scalar df = n_obs - 4
scalar critical = invFtail(q, df, .05)
scalar k = q * critical / df

quietly regress y x
predict double ry, residuals

quietly regress endog x
predict double re, residuals

quietly regress y x z1 z2
predict double uy, residuals

quietly regress endog x z1 z2
predict double ue, residuals

mata:
    ry = st_data(., "ry")
    re = st_data(., "re")
    uy = st_data(., "uy")
    ue = st_data(., "ue")
    k = st_numscalar("k")
    q = st_numscalar("q")
    df = st_numscalar("df")

    A = quadcross(re, re) - (1 + k) * quadcross(ue, ue)
    B = -2 * (quadcross(ry, re) - (1 + k) * quadcross(uy, ue))
    C = quadcross(ry, ry) - (1 + k) * quadcross(uy, uy)

    D = B^2 - 4 * A * C
    root1 = (-B - sqrt(D)) / (2 * A)
    root2 = (-B + sqrt(D)) / (2 * A)

    roots = (root1 \ root2)
    low = min(roots)
    high = max(roots)

    ssr_r_1 = quadcross(ry - re, ry - re)
    ssr_u_1 = quadcross(uy - ue, uy - ue)
    ar_f_1 = ((ssr_r_1 - ssr_u_1) / q) / (ssr_u_1 / df)

    st_numscalar("boundary_low", low)
    st_numscalar("boundary_high", high)
    st_numscalar("accepts_zero", C <= 0)
    st_numscalar("unbounded", A < 0)
    st_numscalar("ar_f_at_one", ar_f_1)
end

display "ANSWER: boundary_low estimate=" %21.12f boundary_low " se=. n_obs=" %12.0f n_obs
display "ANSWER: boundary_high estimate=" %21.12f boundary_high " se=. n_obs=" %12.0f n_obs
display "ANSWER: accepts_zero estimate=" %21.12f accepts_zero " se=. n_obs=" %12.0f n_obs
display "ANSWER: unbounded estimate=" %21.12f unbounded " se=. n_obs=" %12.0f n_obs
display "ANSWER: ar_f_at_one estimate=" %21.12f ar_f_at_one " se=. n_obs=" %12.0f n_obs
