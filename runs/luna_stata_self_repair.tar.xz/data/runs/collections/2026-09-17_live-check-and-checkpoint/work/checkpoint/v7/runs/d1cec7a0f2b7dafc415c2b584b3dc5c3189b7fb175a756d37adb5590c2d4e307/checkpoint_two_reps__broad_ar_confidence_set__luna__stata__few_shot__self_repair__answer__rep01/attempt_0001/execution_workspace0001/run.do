clear all
set more off
set linesize 255
set type double

import delimited using "./input.csv", clear

quietly regress y endog x z1 z2
scalar n_obs = e(N)
scalar df = n_obs - 4

predict double uy, residuals

quietly regress y x
predict double ry, residuals

quietly regress endog x z1 z2
predict double ud, residuals

quietly regress endog x
predict double rd, residuals

scalar q = 2
scalar critical = invFtail(q, df, .05)
scalar k = q * critical / df

mata:
    ry = st_data(., "ry")
    rd = st_data(., "rd")
    uy = st_data(., "uy")
    ud = st_data(., "ud")
    k = st_numscalar("k")
    df = st_numscalar("df")

    A = quadcross(rd, rd) - (1 + k) * quadcross(ud, ud)
    B = -2 * (quadcross(ry, rd) - (1 + k) * quadcross(uy, ud))
    C = quadcross(ry, ry) - (1 + k) * quadcross(uy, uy)

    discriminant = B^2 - 4 * A * C

    if (A != 0 & discriminant >= 0) {
        root1 = (-B - sqrt(discriminant)) / (2 * A)
        root2 = (-B + sqrt(discriminant)) / (2 * A)

        if (root1 <= root2) {
            low = root1
            high = root2
        }
        else {
            low = root2
            high = root1
        }
    }
    else {
        low = .
        high = .
    }

    ssr_r_1 = quadcross(ry - rd, ry - rd)
    ssr_u_1 = quadcross(uy - ud, uy - ud)
    ar_f_1 = ((ssr_r_1 - ssr_u_1) / q) / (ssr_u_1 / df)

    st_numscalar("boundary_low", low)
    st_numscalar("boundary_high", high)
    st_numscalar("accepts_zero", C <= 0)
    st_numscalar("unbounded", A < 0)
    st_numscalar("ar_f_at_one", ar_f_1)
end

display "ANSWER: boundary_low estimate=" %21.12f boundary_low " se=" %21.12f . " n_obs=" %12.0f n_obs
display "ANSWER: boundary_high estimate=" %21.12f boundary_high " se=" %21.12f . " n_obs=" %12.0f n_obs
display "ANSWER: accepts_zero estimate=" %21.12f accepts_zero " se=" %21.12f . " n_obs=" %12.0f n_obs
display "ANSWER: unbounded estimate=" %21.12f unbounded " se=" %21.12f . " n_obs=" %12.0f n_obs
display "ANSWER: ar_f_at_one estimate=" %21.12f ar_f_at_one " se=" %21.12f . " n_obs=" %12.0f n_obs
