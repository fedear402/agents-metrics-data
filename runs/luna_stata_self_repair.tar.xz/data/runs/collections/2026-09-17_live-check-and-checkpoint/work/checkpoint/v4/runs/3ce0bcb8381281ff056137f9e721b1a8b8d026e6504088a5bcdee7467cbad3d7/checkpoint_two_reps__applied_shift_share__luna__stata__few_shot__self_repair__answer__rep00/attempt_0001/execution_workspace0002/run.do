version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

generate double contribution = share * shock

preserve
collapse (sum) z=contribution (firstnm) region_weight x y, by(region_id)
summarize region_weight, meanonly
generate double e = region_weight / r(sum)

summarize e, meanonly
generate double ey = e * y
generate double ex = e * x
generate double ez = e * z
summarize ey, meanonly
scalar mean_y = r(sum)
summarize ex, meanonly
scalar mean_x = r(sum)
summarize ez, meanonly
scalar mean_z = r(sum)

generate double y0 = y - mean_y
generate double x0 = x - mean_x
generate double z0 = z - mean_z

keep region_id e y0 x0 z0
tempfile regions
save `regions'
restore

merge m:1 region_id using `regions', nogen keep(match)

generate double ew = e * share
generate double ys = ew * y0
generate double xs = ew * x0
generate double zs = ew * z0

collapse (sum) s=ew ynum=ys xnum=xs znum=zs (firstnm) shock, by(industry_id)

drop if missing(s) | s <= 0
generate double ybar = ynum / s
generate double xbar = xnum / s
generate double zbar = znum / s

count
scalar n_industries = r(N)

mata:
    y = st_data(., "ybar")
    x = st_data(., "xbar")
    z = st_data(., "zbar")
    shock = st_data(., "shock")
    w = st_data(., "s")

    N = rows(y)
    ones = J(N, 1, 1)

    X_effect = ones, x
    Z_effect = ones, shock
    cross_effect = Z_effect' * (w :* X_effect)
    inv_effect = luinv(cross_effect)
    beta_effect = inv_effect * Z_effect' * (w :* y)
    residual_effect = y - X_effect * beta_effect
    scores_effect = Z_effect :* (w :* residual_effect)
    vcov_effect = (N / (N - 2)) * inv_effect * (scores_effect' * scores_effect) * inv_effect'
    se_effect = sqrt(vcov_effect[2,2])

    X_first = ones, z
    Z_first = ones, shock
    cross_first = Z_first' * (w :* X_first)
    inv_first = luinv(cross_first)
    beta_first = inv_first * Z_first' * (w :* x)
    residual_first = x - X_first * beta_first
    scores_first = Z_first :* (w :* residual_first)
    vcov_first = (N / (N - 2)) * inv_first * (scores_first' * scores_first) * inv_first'
    se_first = sqrt(vcov_first[2,2])

    effective_shocks = 1 / sum((w :/ sum(w)) :^ 2)

    st_numscalar("effect_estimate", beta_effect[2])
    st_numscalar("effect_se", se_effect)
    st_numscalar("first_stage_estimate", beta_first[2])
    st_numscalar("first_stage_se", se_first)
    st_numscalar("effective_shocks_estimate", effective_shocks)
end

display "ANSWER: effect estimate=" %21.12f scalar(effect_estimate) " se=" %21.12f scalar(effect_se) " n_obs=" %12.0f scalar(n_industries)
display "ANSWER: first_stage estimate=" %21.12f scalar(first_stage_estimate) " se=" %21.12f scalar(first_stage_se) " n_obs=" %12.0f scalar(n_industries)
display "ANSWER: effective_shocks estimate=" %21.12f scalar(effective_shocks_estimate) " se=." " n_obs=" %12.0f scalar(n_industries)
