clear all
set linesize 255

import delimited "./input.csv", clear

quietly count
scalar n_obs = r(N)
scalar df_den = n_obs - 4
scalar fcrit = invF(0.95, 2, df_den)

mata:
    y = st_data(., "y")
    endog = st_data(., "endog")
    x = st_data(., "x")
    z1 = st_data(., "z1")
    z2 = st_data(., "z2")

    Xr = (J(rows(y), 1, 1), x)
    Xu = (J(rows(y), 1, 1), x, z1, z2)

    yr = y - Xr * qrsolve(Xr, y)
    er = endog - Xr * qrsolve(Xr, endog)

    K = 1 + 2 * st_numscalar("fcrit") / st_numscalar("df_den")

    sr_yy = quadcross(yr, yr)
    sr_ye = quadcross(yr, er)
    sr_ee = quadcross(er, er)

    yu = y - Xu * qrsolve(Xu, y)
    eu = endog - Xu * qrsolve(Xu, endog)

    su_yy = quadcross(yu, yu)
    su_ye = quadcross(yu, eu)
    su_ee = quadcross(eu, eu)

    a = sr_ee - K * su_ee
    b = -2 * sr_ye + 2 * K * su_ye
    c = sr_yy - K * su_yy

    disc = b^2 - 4 * a * c
    root1 = (-b - sqrt(disc)) / (2 * a)
    root2 = (-b + sqrt(disc)) / (2 * a)

    st_numscalar("boundary_low", min((root1, root2)))
    st_numscalar("boundary_high", max((root1, root2)))
    st_numscalar("accepts_zero", c <= 0)
    st_numscalar("unbounded", a < 0)

    v = y - endog
    rr = v - Xr * qrsolve(Xr, v)
    uu = v - Xu * qrsolve(Xu, v)

    ssr_r = quadcross(rr, rr)
    ssr_u = quadcross(uu, uu)

    ar_f = ((ssr_r - ssr_u) / 2) / ///
        (ssr_u / st_numscalar("df_den"))

    st_numscalar("ar_f_at_one", ar_f)
end

display "ANSWER: boundary_low estimate=" %21.12f boundary_low " se=. n_obs=" %12.0f n_obs
display "ANSWER: boundary_high estimate=" %21.12f boundary_high " se=. n_obs=" %12.0f n_obs
display "ANSWER: accepts_zero estimate=" %21.12f accepts_zero " se=. n_obs=" %12.0f n_obs
display "ANSWER: unbounded estimate=" %21.12f unbounded " se=. n_obs=" %12.0f n_obs
display "ANSWER: ar_f_at_one estimate=" %21.12f ar_f_at_one " se=. n_obs=" %12.0f n_obs
