clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

keep if !missing(score, participated, earnings)
keep if abs(score) < 1

generate byte right = score >= 0
generate double weight = 1 - abs(score)

mata:
void rd_estimate()
{
    real matrix D, X, A, Vy, Vp, Vyp
    real colvector y, p, s, r, w, ey, ep, by, bp
    real scalar n, rf, fs, te, vrf, vfs, crf_fs, vte

    D = st_data(., "earnings participated score right")
    n = rows(D)

    y = D[,1]
    p = D[,2]
    s = D[,3]
    r = D[,4]
    w = 1 :- abs(s)

    X = (J(n,1,1), r, s, s:*r)
    A = invsym(X' * diag(w) * X)

    by = A * X' * (w :* y)
    bp = A * X' * (w :* p)

    ey = y - X * by
    ep = p - X * bp

    Vy = A * (X' * diag(w:^2 :* ey:^2) * X) * A
    Vp = A * (X' * diag(w:^2 :* ep:^2) * X) * A
    Vyp = A * (X' * diag(w:^2 :* ey :* ep) * X) * A

    rf = by[2]
    fs = bp[2]
    vrf = Vy[2,2]
    vfs = Vp[2,2]
    crf_fs = Vyp[2,2]

    if (fs != 0) {
        te = rf / fs
        vte = vrf / (fs^2) + (rf^2 * vfs) / (fs^4) -
            (2 * rf * crf_fs) / (fs^3)
    }
    else {
        te = .
        vte = .
    }

    st_numscalar("reduced_form", rf)
    st_numscalar("reduced_form_se", sqrt(vrf))
    st_numscalar("first_stage", fs)
    st_numscalar("first_stage_se", sqrt(vfs))
    st_numscalar("treatment_effect", te)
    st_numscalar("treatment_effect_se", sqrt(vte))
    st_numscalar("n_obs", n)
}

rd_estimate()
end

display "ANSWER: treatment_effect estimate=" %21.12f treatment_effect " se=" %21.12f treatment_effect_se " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f reduced_form " se=" %21.12f reduced_form_se " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f first_stage " se=" %21.12f first_stage_se " n_obs=" %12.0f n_obs
