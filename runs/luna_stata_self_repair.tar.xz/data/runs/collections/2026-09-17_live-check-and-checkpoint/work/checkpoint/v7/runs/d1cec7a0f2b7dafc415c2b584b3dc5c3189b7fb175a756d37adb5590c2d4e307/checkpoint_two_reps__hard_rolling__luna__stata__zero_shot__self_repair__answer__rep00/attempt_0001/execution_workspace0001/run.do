set linesize 255

import delimited using "./input.csv", clear
sort time
tsset time

scalar sse = 0
scalar se_missing = .

forvalues f = 101/250 {
    local lo = `f' - 99
    local hi = `f' - 1

    quietly regress y L.y if inrange(time, `lo', `hi')
    quietly summarize y if time == `hi', meanonly

    scalar forecast_`f' = _b[_cons] + _b[L.y] * r(mean)

    quietly summarize y if time == `f', meanonly
    scalar error_`f' = r(mean) - forecast_`f'
    scalar sse = sse + error_`f'^2
}

scalar rmse = sqrt(sse / 150)

display "ANSWER: rmse estimate=" %21.12f rmse ///
    " se=" %21.12f se_missing " n_obs=" %12.0f 150
display "ANSWER: forecast_101 estimate=" %21.12f forecast_101 ///
    " se=" %21.12f se_missing " n_obs=" %12.0f 99
display "ANSWER: forecast_150 estimate=" %21.12f forecast_150 ///
    " se=" %21.12f se_missing " n_obs=" %12.0f 99
display "ANSWER: forecast_200 estimate=" %21.12f forecast_200 ///
    " se=" %21.12f se_missing " n_obs=" %12.0f 99
display "ANSWER: forecast_250 estimate=" %21.12f forecast_250 ///
    " se=" %21.12f se_missing " n_obs=" %12.0f 99
