clear all
set linesize 255

import delimited using "./input.csv", clear

scalar n_obs = _N
scalar df_den = n_obs - 4
scalar fcrit = invF(2, df_den, .95)

program define ar_eval, rclass
    syntax, B(real)

    tempvar dep
    quietly generate double `dep' = y - `B' * endog

    quietly regress `dep' x
    scalar rss_r = e(rss)

    quietly regress `dep' x z1 z2
    scalar rss_a = e(rss)

    return scalar qk = rss_r - rss_a
    return scalar qr = rss_a
    return scalar f = (rss_r - rss_a) / 2 / (rss_a / (e(N) - 4))
end

quietly ar_eval, b(-1)
scalar qk_m = r(qk)
scalar qr_m = r(qr)

quietly ar_eval, b(0)
scalar qk_0 = r(qk)
scalar qr_0 = r(qr)

quietly ar_eval, b(1)
scalar qk_p = r(qk)
scalar qr_p = r(qr)
scalar ar_f_at_one = r(f)

scalar p_m = df_den * qk_m - 2 * fcrit * qr_m
scalar p_0 = df_den * qk_0 - 2 * fcrit * qr_0
scalar p_p = df_den * qk_p - 2 * fcrit * qr_p

scalar a = (p_p + p_m - 2 * p_0) / 2
scalar b = (p_p - p_m) / 2
scalar c = p_0
scalar disc = b^2 - 4 * a * c

scalar boundary_low = (-b - sqrt(disc)) / (2 * a)
scalar boundary_high = (-b + sqrt(disc)) / (2 * a)

if boundary_low > boundary_high {
    scalar temp = boundary_low
    scalar boundary_low = boundary_high
    scalar boundary_high = temp
}

scalar accepts_zero = (p_0 <= 0)
scalar unbounded = (a < 0 | (a == 0 & b != 0) | (a == 0 & b == 0 & c <= 0))

display "ANSWER: boundary_low estimate=" %21.12f boundary_low ///
    " se=. n_obs=" %12.0f n_obs

display "ANSWER: boundary_high estimate=" %21.12f boundary_high ///
    " se=. n_obs=" %12.0f n_obs

display "ANSWER: accepts_zero estimate=" %21.12f accepts_zero ///
    " se=. n_obs=" %12.0f n_obs

display "ANSWER: unbounded estimate=" %21.12f unbounded ///
    " se=. n_obs=" %12.0f n_obs

display "ANSWER: ar_f_at_one estimate=" %21.12f ar_f_at_one ///
    " se=. n_obs=" %12.0f n_obs
