clear all
set linesize 255

import delimited "./input.csv", clear

quietly ologit y x z

scalar n_obs = e(N)
scalar x_est = _b[x]
scalar x_se = _se[x]
scalar z_est = _b[z]
scalar z_se = _se[z]

quietly margins, at(x=1 z=0) predict(outcome(3))
scalar prob_high = r(b)[1,1]

display "ANSWER: x estimate=" %21.12f x_est " se=" %21.12f x_se " n_obs=" %12.0f n_obs
display "ANSWER: z estimate=" %21.12f z_est " se=" %21.12f z_se " n_obs=" %12.0f n_obs
display "ANSWER: prob_high estimate=" %21.12f prob_high " se=." " n_obs=" %12.0f n_obs
