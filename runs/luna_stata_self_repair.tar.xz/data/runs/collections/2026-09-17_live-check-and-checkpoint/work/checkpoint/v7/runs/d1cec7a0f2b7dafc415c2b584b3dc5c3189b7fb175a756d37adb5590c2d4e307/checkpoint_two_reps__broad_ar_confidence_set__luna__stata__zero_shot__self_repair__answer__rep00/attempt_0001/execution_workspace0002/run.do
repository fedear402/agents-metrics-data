clear all
set linesize 255

import delimited using "./input.csv", clear

scalar n_obs = _N
scalar df_den = n_obs - 4
scalar fcrit = invF(2, df_den, .95)

mata:
real scalar qform(real matrix A, real colvector v)
{
    return(v' * A * v)
}

real scalar n
real colvector y, e, x, z1, z2, one, v1
real matrix Xr, Xa, Kr, Ka, K, R
real scalar a, b, c, disc, r1, r2
real scalar h0, hplus, hminus
real scalar f1, q1, s1

n = st_nobs()
y = st_data(., "y")
e = st_data(., "endog")
x = st_data(., "x")
z1 = st_data(., "z1")
z2 = st_data(., "z2")
one = J(n, 1, 1)

Xr = one, x
Xa = one, x, z1, z2

Kr = I(n) - Xr * invsym(Xr' * Xr) * Xr'
Ka = I(n) - Xa * invsym(Xa' * Xa) * Xa'

K = Kr - Ka
R = Ka

a = st_numscalar("df_den") * qform(K, e) - ///
    2 * st_numscalar("fcrit") * qform(R, e)

b = -2 * st_numscalar("df_den") * (e' * K * y) + ///
    4 * st_numscalar("fcrit") * (e' * R * y)

c = st_numscalar("df_den") * qform(K, y) - ///
    2 * st_numscalar("fcrit") * qform(R, y)

disc = b^2 - 4 * a * c

r1 = (-b - sqrt(disc)) / (2 * a)
r2 = (-b + sqrt(disc)) / (2 * a)

if (r1 < r2) {
    st_numscalar("boundary_low", r1)
    st_numscalar("boundary_high", r2)
}
else {
    st_numscalar("boundary_low", r2)
    st_numscalar("boundary_high", r1)
}

h0 = c
hplus = a
hminus = a

if (a == 0) {
    hplus = b
    hminus = -b
}

st_numscalar("accepts_zero", h0 <= 0)
st_numscalar("unbounded", (hplus <= 0) | (hminus <= 0))

v1 = y - e
q1 = qform(K, v1)
s1 = qform(R, v1)
f1 = st_numscalar("df_den") * q1 / (2 * s1)

st_numscalar("ar_f_at_one", f1)
end

display "ANSWER: boundary_low estimate=" %21.12f boundary_low ///
    " se=. n_obs=" %12.0f n_obs

display "ANSWER: boundary_high estimate=" %21.12f boundary_high ///
    " se=. n_obs=" %12.0f n_obs

display "ANSWER: accepts_zero estimate=" %21.12f accepts_zero ///
    " se=. n_obs=" %12.0f n_obs

display "ANSWER: unbounded estimate=" %21.12f unbounded ///
    " se=. n_obs=" %12.0f n_obs

display "ANSWER: ar_f_at_one estimate=" %21.12f ar_f_at_one ///
    " se=. n_obs=" %12.0f n_obs
