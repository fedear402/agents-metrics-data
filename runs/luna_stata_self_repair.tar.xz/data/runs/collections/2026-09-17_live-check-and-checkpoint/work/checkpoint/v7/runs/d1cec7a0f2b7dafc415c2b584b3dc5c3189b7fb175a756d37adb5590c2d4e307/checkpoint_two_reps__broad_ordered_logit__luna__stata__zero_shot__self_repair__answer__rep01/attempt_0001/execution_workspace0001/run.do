clear all
set linesize 255

import delimited using "./input.csv", clear

quietly ologit y x z

scalar n_obs = e(N)
scalar x_est = _b[x]
scalar x_se = _se[x]
scalar z_est = _b[z]
scalar z_se = _se[z]
scalar prob_high = invlogit(_b[x] - _b[/cut2])

display "ANSWER: x estimate=" %21.12f x_est " se=" %21.12f x_se " n_obs=" %12.0f n_obs
display "ANSWER: z estimate=" %21.12f z_est " se=" %21.12f z_se " n_obs=" %12.0f n_obs
display "ANSWER: prob_high estimate=" %21.12f prob_high " se=." " n_obs=" %12.0f n_obs
