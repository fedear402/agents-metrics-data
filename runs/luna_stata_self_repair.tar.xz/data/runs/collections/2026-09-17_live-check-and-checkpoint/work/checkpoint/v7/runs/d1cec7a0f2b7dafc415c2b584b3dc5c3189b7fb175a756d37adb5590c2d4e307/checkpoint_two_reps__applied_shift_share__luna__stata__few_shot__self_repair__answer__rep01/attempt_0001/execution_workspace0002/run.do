version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

tempfile region

gen double exposure = share * shock
bysort region_id: egen double z = total(exposure)
egen byte region_tag = tag(region_id)

preserve
    keep if region_tag
    quietly summarize region_weight, meanonly
    scalar total_region_weight = r(sum)

    gen double e = region_weight / total_region_weight

    quietly summarize y [aw=e], meanonly
    scalar mean_y = r(mean)

    quietly summarize x [aw=e], meanonly
    scalar mean_x = r(mean)

    quietly summarize z [aw=e], meanonly
    scalar mean_z = r(mean)

    gen double y0 = y - mean_y
    gen double x0 = x - mean_x
    gen double z0 = z - mean_z

    keep region_id e y0 x0 z0
    save `region', replace
restore

merge m:1 region_id using `region', nogen keep(match)

gen double w = e * share
gen double wy = w * y0
gen double wx = w * x0
gen double wz = w * z0

collapse (sum) s=w num_y=wy num_x=wx num_z=wz, by(industry_id shock)

drop if s <= 0

gen double ybar = num_y / s
gen double xbar = num_x / s
gen double zbar = num_z / s
gen double cons = 1

quietly count
scalar n_industries = r(N)

gen double s_squared = s^2
quietly summarize s_squared, meanonly
scalar effective_shocks = 1 / r(sum)

matrix accum A_effect = cons shock xbar ybar [aw=s], nocons
matrix ZX_effect = (A_effect[1,1], A_effect[1,3] \ ///
                    A_effect[2,1], A_effect[2,3])
matrix Zy_effect = (A_effect[1,4] \ A_effect[2,4])
matrix inv_effect = invsym(ZX_effect)
matrix beta_effect = inv_effect * Zy_effect

gen double residual_effect = ybar - beta_effect[1,1] - ///
    beta_effect[2,1] * xbar
gen double score_effect_0 = s * residual_effect
gen double score_effect_1 = s * shock * residual_effect

matrix accum SS_effect = score_effect_0 score_effect_1, nocons
matrix V_effect = (n_industries / (n_industries - 2)) * ///
    inv_effect * SS_effect * inv_effect'

scalar effect_estimate = beta_effect[2,1]
scalar effect_se = sqrt(V_effect[2,2])

matrix accum A_first = cons shock zbar xbar [aw=s], nocons
matrix ZX_first = (A_first[1,1], A_first[1,3] \ ///
                   A_first[2,1], A_first[2,3])
matrix Zy_first = (A_first[1,4] \ A_first[2,4])
matrix inv_first = invsym(ZX_first)
matrix beta_first = inv_first * Zy_first

gen double residual_first = xbar - beta_first[1,1] - ///
    beta_first[2,1] * zbar
gen double score_first_0 = s * residual_first
gen double score_first_1 = s * shock * residual_first

matrix accum SS_first = score_first_0 score_first_1, nocons
matrix V_first = (n_industries / (n_industries - 2)) * ///
    inv_first * SS_first * inv_first'

scalar first_estimate = beta_first[2,1]
scalar first_se = sqrt(V_first[2,2])

display "ANSWER: effect estimate=" %21.12f effect_estimate ///
    " se=" %21.12f effect_se " n_obs=" %12.0f n_industries

display "ANSWER: first_stage estimate=" %21.12f first_estimate ///
    " se=" %21.12f first_se " n_obs=" %12.0f n_industries

display "ANSWER: effective_shocks estimate=" %21.12f effective_shocks ///
    " se=." " n_obs=" %12.0f n_industries
