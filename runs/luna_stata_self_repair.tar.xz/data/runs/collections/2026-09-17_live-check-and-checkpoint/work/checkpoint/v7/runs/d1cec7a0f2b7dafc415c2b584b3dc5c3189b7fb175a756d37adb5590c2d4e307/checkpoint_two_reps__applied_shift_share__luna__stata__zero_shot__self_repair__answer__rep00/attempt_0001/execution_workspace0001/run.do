clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

egen byte region_tag = tag(region_id)
egen double total_weight = total(cond(region_tag, region_weight, 0))
generate double e = region_weight / total_weight

bysort region_id: egen double z = total(share * shock)

preserve
keep if region_tag
quietly summarize y [aw=e], meanonly
scalar y_mean = r(mean)
quietly summarize x [aw=e], meanonly
scalar x_mean = r(mean)
quietly summarize z [aw=e], meanonly
scalar z_mean = r(mean)

generate double y0 = y - y_mean
generate double x0 = x - x_mean
generate double z0 = z - z_mean

keep region_id e y0 x0 z0
tempfile regional
save `regional'
restore

merge m:1 region_id using `regional', nogen keep(match)

generate double eshare = e * share
generate double s_component = eshare
generate double y_component = eshare * y0
generate double x_component = eshare * x0
generate double z_component = eshare * z0

collapse (sum) s=s_component y_num=y_component x_num=x_component z_num=z_component ///
    (firstnm) shock, by(industry_id)

keep if s > 0

generate double ybar = y_num / s
generate double xbar = x_num / s
generate double zbar = z_num / s

count
scalar n_industries = r(N)

ivregress 2sls ybar (xbar = shock) [aw=s], vce(robust)
scalar effect_estimate = _b[xbar]
scalar effect_se = _se[xbar]

ivregress 2sls xbar (zbar = shock) [aw=s], vce(robust)
scalar first_stage_estimate = _b[zbar]
scalar first_stage_se = _se[zbar]

quietly summarize s, meanonly
generate double s_squared = s^2
quietly summarize s_squared, meanonly
scalar effective_shocks_value = 1 / r(sum)

display "ANSWER: effect estimate=" %21.12f effect_estimate ///
    " se=" %21.12f effect_se ///
    " n_obs=" %12.0f n_industries

display "ANSWER: first_stage estimate=" %21.12f first_stage_estimate ///
    " se=" %21.12f first_stage_se ///
    " n_obs=" %12.0f n_industries

display "ANSWER: effective_shocks estimate=" %21.12f effective_shocks_value ///
    " se=" %21.12f . ///
    " n_obs=" %12.0f n_industries
