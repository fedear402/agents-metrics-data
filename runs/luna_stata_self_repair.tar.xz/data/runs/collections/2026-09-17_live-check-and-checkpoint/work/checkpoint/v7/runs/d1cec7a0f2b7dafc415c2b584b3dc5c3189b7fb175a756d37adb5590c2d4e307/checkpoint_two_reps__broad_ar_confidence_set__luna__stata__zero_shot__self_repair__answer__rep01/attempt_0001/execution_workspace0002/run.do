clear all
set linesize 255

import delimited "./input.csv", clear

quietly count
scalar n_obs = r(N)
scalar df_den = n_obs - 4
scalar fcrit = invF(0.95, 2, df_den)

mata:
    y = st_data(., "y")
    endog = st_data(., "endog")
    x = st_data(., "x")
    z1 = st_data(., "z1")
    z2 = st_data(., "z2")

    Xr = (J(rows(y), 1, 1), x)
    Xu = (J(rows(y), 1, 1), x, z1, z2)

    function qstat(b, y, endog, Xr, Xu, fcrit, df_den) {
        v = y - b * endog
        br = qrsolve(Xr, v)
        bu = qrsolve(Xu, v)
        er = v - Xr * br
        eu = v - Xu * bu
        ssr_r = quadcross(er, er)
        ssr_u = quadcross(eu, eu)
        return(ssr_r - (1 + 2 * fcrit / df_den) * ssr_u)
    }

    q_m1 = qstat(-1, y, endog, Xr, Xu, st_numscalar("fcrit"), st_numscalar("df_den"))
    q_0  = qstat(0,  y, endog, Xr, Xu, st_numscalar("fcrit"), st_numscalar("df_den"))
    q_1  = qstat(1,  y, endog, Xr, Xu, st_numscalar("fcrit"), st_numscalar("df_den"))

    a = (q_1 + q_m1 - 2 * q_0) / 2
    c = (q_1 - q_m1) / 2
    d = q_0
    disc = c^2 - 4 * a * d

    root1 = (-c - sqrt(disc)) / (2 * a)
    root2 = (-c + sqrt(disc)) / (2 * a)

    st_numscalar("boundary_low", min((root1, root2)))
    st_numscalar("boundary_high", max((root1, root2)))
    st_numscalar("accepts_zero", d <= 0)
    st_numscalar("unbounded", a < 0)

    v = y - endog
    br = qrsolve(Xr, v)
    bu = qrsolve(Xu, v)
    er = v - Xr * br
    eu = v - Xu * bu
    ssr_r = quadcross(er, er)
    ssr_u = quadcross(eu, eu)
    st_numscalar("ar_f_at_one", ((ssr_r - ssr_u) / 2) / (ssr_u / st_numscalar("df_den")))
end

display "ANSWER: boundary_low estimate=" %21.12f boundary_low " se=. n_obs=" %12.0f n_obs
display "ANSWER: boundary_high estimate=" %21.12f boundary_high " se=. n_obs=" %12.0f n_obs
display "ANSWER: accepts_zero estimate=" %21.12f accepts_zero " se=. n_obs=" %12.0f n_obs
display "ANSWER: unbounded estimate=" %21.12f unbounded " se=. n_obs=" %12.0f n_obs
display "ANSWER: ar_f_at_one estimate=" %21.12f ar_f_at_one " se=. n_obs=" %12.0f n_obs
