clear all
set linesize 255

import delimited "./input.csv", clear
sort date

gen double log_sales = ln(sales)
gen double log_vix = ln(vix)
gen double dlog_vix = log_vix - log_vix[_n-1]

forvalues j = 1/15 {
    gen double lag_`j' = dlog_vix[_n-`j']
}

gen byte touse = !missing(log_sales, lag_1, lag_2, lag_3, lag_4, lag_5, ///
    lag_6, lag_7, lag_8, lag_9, lag_10, lag_11, lag_12, lag_13, lag_14, lag_15)

regress log_sales lag_1-lag_15 if touse

mata:
    y = st_data(., "log_sales", "touse")
    X = st_data(., "_cons lag_1-lag_15", "touse")
    b = st_matrix("e(b)")'
    u = y - X*b
    N = rows(X)
    K = cols(X)

    XXinv = invsym(X'X)
    S = J(K, K, 0)

    for (t = 1; t <= N; t++) {
        z = X[t,.]' * u[t]
        S = S + z*z'
    }

    for (j = 1; j <= 15; j++) {
        w = 1 - j/16
        for (t = j+1; t <= N; t++) {
            z1 = X[t,.]' * u[t]
            z2 = X[t-j,.]' * u[t-j]
            S = S + w * (z1*z2' + z2*z1')
        }
    }

    V = (N/(N-16)) * XXinv * S * XXinv
    st_matrix("V_nw", V)
    st_numscalar("N_reg", N)
end

scalar cumulative_response = 0
forvalues j = 1/15 {
    scalar cumulative_response = cumulative_response + _b[lag_`j']
}

scalar se_cumulative = sqrt((J(1,15) * syminv(V_nw[2..16,2..16]) * J(15,1)))
mata:
    c = J(1,15,1)
    Vlags = st_matrix("V_nw")[2..16,2..16]
    st_numscalar("se_cumulative", sqrt(c * Vlags * c'))
    st_numscalar("se_lag_1", sqrt(st_matrix("V_nw")[2,2]))
    st_numscalar("se_lag_15", sqrt(st_matrix("V_nw")[16,16]))
end

display "ANSWER: cumulative_response estimate=" %21.12f cumulative_response ///
    " se=" %21.12f se_cumulative " n_obs=" %12.0f N_reg

display "ANSWER: lag_1 estimate=" %21.12f _b[lag_1] ///
    " se=" %21.12f se_lag_1 " n_obs=" %12.0f N_reg

display "ANSWER: lag_15 estimate=" %21.12f _b[lag_15] ///
    " se=" %21.12f se_lag_15 " n_obs=" %12.0f N_reg
