clear all
set linesize 255

import delimited "./input.csv", clear
sort date

gen double lnsales = ln(sales)
gen double lnvix = ln(vix)
gen double dlnvix = lnvix - lnvix[_n-1]

forvalues j = 1/15 {
    gen double lag_`j' = dlnvix[_n-`j']
}

regress lnsales lag_1-lag_15
scalar n_obs = e(N)

predict double __uhat if e(sample), residuals
gen byte __esample = e(sample)

mata:
    real matrix Z X G A B Sj V bhat
    real colvector es u idx one15
    real scalar n j w

    Z = st_data(., "lag_1 lag_2 lag_3 lag_4 lag_5 lag_6 lag_7 lag_8 lag_9 lag_10 lag_11 lag_12 lag_13 lag_14 lag_15")
    es = st_data(., "__esample")
    u = st_data(., "__uhat")

    idx = selectindex(es :== 1)
    Z = Z[idx,.]
    u = u[idx]

    n = rows(Z)
    X = J(n,1,1), Z
    G = X :* u

    A = quadcross(X, X)
    B = quadcross(G, G)

    for (j = 1; j <= 15; j++) {
        w = 1 - j/16
        Sj = quadcross(G[(j+1)..n,.], G[1..(n-j),.])
        B = B + w * (Sj + Sj')
    }

    V = invsym(A) * B * invsym(A) * n/(n-16)
    bhat = st_matrix("e(b)")
    one15 = J(15,1,1)

    st_numscalar("b_lag1", bhat[1,2])
    st_numscalar("b_lag15", bhat[1,16])
    st_numscalar("b_cumulative", sum(bhat[1,2..16]))
    st_numscalar("se_lag1", sqrt(V[2,2]))
    st_numscalar("se_lag15", sqrt(V[16,16]))
    st_numscalar("se_cumulative", sqrt(one15' * V[2..16,2..16] * one15))
end

display "ANSWER: cumulative_response estimate=" %21.12f b_cumulative " se=" %21.12f se_cumulative " n_obs=" %12.0f n_obs
display "ANSWER: lag_1 estimate=" %21.12f b_lag1 " se=" %21.12f se_lag1 " n_obs=" %12.0f n_obs
display "ANSWER: lag_15 estimate=" %21.12f b_lag15 " se=" %21.12f se_lag15 " n_obs=" %12.0f n_obs
