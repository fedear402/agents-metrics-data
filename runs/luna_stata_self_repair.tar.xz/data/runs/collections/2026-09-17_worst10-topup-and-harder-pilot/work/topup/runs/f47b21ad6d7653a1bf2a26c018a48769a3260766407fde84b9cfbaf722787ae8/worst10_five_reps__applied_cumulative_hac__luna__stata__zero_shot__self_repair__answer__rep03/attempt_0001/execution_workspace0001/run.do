clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

sort date

gen double ln_sales = ln(sales)
gen double dln_vix = ln(vix) - ln(vix[_n-1])

forvalues j = 1/15 {
    gen double lag_`j' = dln_vix[_n-`j']
}

gen byte complete = !missing(ln_sales, lag_1, lag_2, lag_3, lag_4, lag_5, ///
    lag_6, lag_7, lag_8, lag_9, lag_10, lag_11, lag_12, lag_13, lag_14, lag_15)

regress ln_sales lag_1-lag_15 if complete

local n = e(N)
predict double __resid if e(sample), residual

mata:
    string scalar xvars
    real matrix X, Q, S, XXinv, V, b
    real colvector u
    real scalar n, k, j, w, cumvar

    xvars = "lag_1 lag_2 lag_3 lag_4 lag_5 lag_6 lag_7 lag_8 lag_9 lag_10 lag_11 lag_12 lag_13 lag_14 lag_15"
    X = st_data(., ("_cons", xvars), "e(sample)")
    u = st_data(., "__resid", "e(sample)")
    n = rows(X)
    k = cols(X)

    Q = X
    for (j = 1; j <= n; j++) {
        Q[j,.] = X[j,.] :* u[j]
    }

    S = Q' * Q
    for (j = 1; j <= 15; j++) {
        w = 1 - j/16
        S = S + w * (Q[(j+1)..n,.]' * Q[1..(n-j),.] + ///
            Q[1..(n-j),.]' * Q[(j+1)..n,.])
    }

    XXinv = invsym(X' * X)
    V = (n/(n-16)) * XXinv * S * XXinv
    b = st_matrix("e(b)")

    cumvar = sum(V[|2,2 \ 16,16|])
    for (j = 2; j <= 16; j++) {
        for (real scalar h = 2; h <= 16; h++) {
            if (j != h) cumvar = cumvar + V[j,h]
        }
    }

    st_numscalar("cumulative_response", sum(b[1,2..16]))
    st_numscalar("cumulative_se", sqrt(cumvar))
    st_numscalar("lag_1_estimate", b[1,2])
    st_numscalar("lag_1_se", sqrt(V[2,2]))
    st_numscalar("lag_15_estimate", b[1,16])
    st_numscalar("lag_15_se", sqrt(V[16,16]))
    st_numscalar("n_obs", n)
end

display "ANSWER: cumulative_response estimate=" %21.12f scalar(cumulative_response) ///
    " se=" %21.12f scalar(cumulative_se) " n_obs=" %12.0f scalar(n_obs)

display "ANSWER: lag_1 estimate=" %21.12f scalar(lag_1_estimate) ///
    " se=" %21.12f scalar(lag_1_se) " n_obs=" %12.0f scalar(n_obs)

display "ANSWER: lag_15 estimate=" %21.12f scalar(lag_15_estimate) ///
    " se=" %21.12f scalar(lag_15_se) " n_obs=" %12.0f scalar(n_obs)
