version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

egen long region_g = group(region_id)
egen long industry_g = group(industry_id)
sort region_g
by region_g: generate byte region_first = (_n == 1)

mata:
real rowvector iv_result(
    real colvector dependent,
    real colvector endogenous,
    real colvector instrument,
    real colvector weight,
    real scalar n
) {
    real matrix regressors, instruments, cross, inverse, covariance
    real colvector beta, residual, scores

    regressors = (J(n, 1, 1), endogenous)
    instruments = (J(n, 1, 1), instrument)
    cross = instruments' * (weight :* regressors)
    inverse = luinv(cross)
    beta = inverse * instruments' * (weight :* dependent)
    residual = dependent - regressors * beta
    scores = instruments :* (weight :* residual)
    covariance = n / (n - 2) * inverse * (scores' * scores) * inverse'

    return((beta[2], sqrt(covariance[2, 2])))
}

real colvector region, industry, share, shock, region_weight, x, y, first
real scalar n_rows, n_regions, n_industries, r, n
real colvector e, z, y0, x0, z0, mass, ybar, xbar, zbar
real rowvector effect_result, first_stage_result

region = st_data(., "region_g")
industry = st_data(., "industry_g")
share = st_data(., "share")
shock = st_data(., "shock")
region_weight = st_data(., "region_weight")
x = st_data(., "x")
y = st_data(., "y")
first = st_data(., "region_first")

n_rows = rows(region)
n_regions = max(region)
n_industries = max(industry)

e = J(n_regions, 1, 0)
for (r = 1; r <= n_rows; r++) {
    if (first[r] == 1) {
        e[region[r]] = region_weight[r]
    }
}
e = e / sum(e)

z = J(n_regions, 1, 0)
for (r = 1; r <= n_rows; r++) {
    z[region[r]] = z[region[r]] + share[r] * shock[r]
}

y = y[region]
x = x[region]

y0 = y :- sum(e :* y)
x0 = x :- sum(e :* x)
z0 = z :- sum(e :* z)

mass = J(n_industries, 1, 0)
ybar = J(n_industries, 1, 0)
xbar = J(n_industries, 1, 0)
zbar = J(n_industries, 1, 0)

for (r = 1; r <= n_rows; r++) {
    mass[industry[r]] = mass[industry[r]] + e[region[r]] * share[r]
    ybar[industry[r]] = ybar[industry[r]] + e[region[r]] * share[r] * y0[region[r]]
    xbar[industry[r]] = xbar[industry[r]] + e[region[r]] * share[r] * x0[region[r]]
    zbar[industry[r]] = zbar[industry[r]] + e[region[r]] * share[r] * z0[region[r]]
}

ybar = ybar :/ mass
xbar = xbar :/ mass
zbar = zbar :/ mass

effect_result = iv_result(ybar, xbar, shock[1..n_industries], mass, n_industries)
first_stage_result = iv_result(xbar, zbar, shock[1..n_industries], mass, n_industries)

st_numscalar("effect_estimate", effect_result[1])
st_numscalar("effect_se", effect_result[2])
st_numscalar("first_stage_estimate", first_stage_result[1])
st_numscalar("first_stage_se", first_stage_result[2])
st_numscalar("effective_shocks", 1 / sum(mass:^2))
st_numscalar("n_industries", n_industries)
end

display "ANSWER: effect estimate=" %21.12f effect_estimate " se=" %21.12f effect_se " n_obs=" %12.0f n_industries
display "ANSWER: first_stage estimate=" %21.12f first_stage_estimate " se=" %21.12f first_stage_se " n_obs=" %12.0f n_industries
display "ANSWER: effective_shocks estimate=" %21.12f effective_shocks " se=." " n_obs=" %12.0f n_industries
