clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

egen byte region_tag = tag(region_id)
bysort region_id: egen double z_r = total(share * shock)

keep if region_tag
drop region_tag

quietly summarize region_weight, meanonly
scalar total_region_weight = r(sum)
generate double e_r = region_weight / total_region_weight

quietly summarize y [aw=e_r], meanonly
scalar y_mean = r(mean)

quietly summarize x [aw=e_r], meanonly
scalar x_mean = r(mean)

quietly summarize z_r [aw=e_r], meanonly
scalar z_mean = r(mean)

generate double y0 = y - y_mean
generate double x0 = x - x_mean
generate double z0 = z_r - z_mean

generate double eshare = e_r * share
generate double y_contribution = eshare * y0
generate double x_contribution = eshare * x0
generate double z_contribution = eshare * z0

collapse (sum) s_n=eshare y_num=y_contribution x_num=x_contribution z_num=z_contribution ///
    (firstnm) shock_n=shock, by(industry_id)

keep if s_n > 0
generate double ybar = y_num / s_n
generate double xbar = x_num / s_n
generate double zbar = z_num / s_n

quietly count
scalar n_industries = r(N)

quietly summarize s_n, meanonly
generate double s_sq = s_n^2
quietly summarize s_sq, meanonly
scalar effective_shocks_value = 1 / r(sum)

quietly ivregress 2sls ybar (xbar = shock_n) [aw=s_n], vce(robust)
scalar effect_estimate = _b[xbar]
scalar effect_se = _se[xbar]

quietly ivregress 2sls xbar (zbar = shock_n) [aw=s_n], vce(robust)
scalar first_stage_estimate = _b[zbar]
scalar first_stage_se = _se[zbar]

display "ANSWER: effect estimate=" %21.12f effect_estimate ///
    " se=" %21.12f effect_se " n_obs=" %12.0f n_industries

display "ANSWER: first_stage estimate=" %21.12f first_stage_estimate ///
    " se=" %21.12f first_stage_se " n_obs=" %12.0f n_industries

display "ANSWER: effective_shocks estimate=" %21.12f effective_shocks_value ///
    " se=" %21.12f . " n_obs=" %12.0f n_industries
