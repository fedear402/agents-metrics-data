version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

keep if abs(score) < 1
gen double rw = 1 - abs(score)

mata:
score = st_data(., "score")
w = st_data(., "rw")
Y = st_data(., ("earnings", "participated"))

n = rows(score)
X = J(n, 4, 0)

left = score < 0
right = score >= 0

X[., 1] = left
X[., 2] = left :* score
X[., 3] = right
X[., 4] = right :* score

bread = invsym(X' * (w :* X))
b = bread * X' * (w :* Y)
residuals = Y - X * b

contrast = (-1 \ 0 \ 1 \ 0)
discontinuities = contrast' * b

loading = (w :* (X * bread * contrast))
influence = loading :* residuals
joint = influence' * influence

se = sqrt(diagonal(joint))
gradient = (discontinuities[2] / discontinuities[1]^2 \ -1 / discontinuities[1])
ratio = discontinuities[1] / discontinuities[2]
ratio_gradient = (1 / discontinuities[2] \ -discontinuities[1] / discontinuities[2]^2)
ratio_se = sqrt(ratio_gradient' * joint * ratio_gradient)

st_numscalar("reduced_form", discontinuities[1])
st_numscalar("first_stage", discontinuities[2])
st_numscalar("treatment_effect", ratio)
st_numscalar("reduced_form_se", se[1])
st_numscalar("first_stage_se", se[2])
st_numscalar("treatment_effect_se", ratio_se)
st_numscalar("n_obs", n)
end

display "ANSWER: treatment_effect estimate=" %21.12f treatment_effect " se=" %21.12f treatment_effect_se " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f reduced_form " se=" %21.12f reduced_form_se " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f first_stage " se=" %21.12f first_stage_se " n_obs=" %12.0f n_obs
