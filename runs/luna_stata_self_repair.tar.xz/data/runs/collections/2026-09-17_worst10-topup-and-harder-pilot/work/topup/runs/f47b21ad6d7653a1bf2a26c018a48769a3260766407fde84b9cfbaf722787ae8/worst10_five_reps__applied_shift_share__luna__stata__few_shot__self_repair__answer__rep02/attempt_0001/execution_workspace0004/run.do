version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

egen long region_g = group(region_id)
egen long industry_g = group(industry_id)

sort region_g industry_g
by region_g: generate byte region_first = (_n == 1)

sort industry_g region_g
by industry_g: generate byte industry_first = (_n == 1)

mata:
region = st_data(., "region_g")
industry = st_data(., "industry_g")
share = st_data(., "share")
shock = st_data(., "shock")
region_weight = st_data(., "region_weight")
x_row = st_data(., "x")
y_row = st_data(., "y")
region_first = st_data(., "region_first")
industry_first = st_data(., "industry_first")

n_rows = rows(region)
n_regions = max(region)
n_industries = max(industry)

e = J(n_regions, 1, 0)
x = J(n_regions, 1, 0)
y = J(n_regions, 1, 0)

for (r = 1; r <= n_rows; r++) {
    if (region_first[r] == 1) {
        e[region[r]] = region_weight[r]
        x[region[r]] = x_row[r]
        y[region[r]] = y_row[r]
    }
}
e = e / sum(e)

z = J(n_regions, 1, 0)
for (r = 1; r <= n_rows; r++) {
    z[region[r]] = z[region[r]] + share[r] * shock[r]
}

y0 = y :- sum(e :* y)
x0 = x :- sum(e :* x)
z0 = z :- sum(e :* z)

mass = J(n_industries, 1, 0)
ybar = J(n_industries, 1, 0)
xbar = J(n_industries, 1, 0)
zbar = J(n_industries, 1, 0)
shock_n = J(n_industries, 1, 0)

for (r = 1; r <= n_rows; r++) {
    mass[industry[r]] = mass[industry[r]] + e[region[r]] * share[r]
    ybar[industry[r]] = ybar[industry[r]] + e[region[r]] * share[r] * y0[region[r]]
    xbar[industry[r]] = xbar[industry[r]] + e[region[r]] * share[r] * x0[region[r]]
    zbar[industry[r]] = zbar[industry[r]] + e[region[r]] * share[r] * z0[region[r]]

    if (industry_first[r] == 1) {
        shock_n[industry[r]] = shock[r]
    }
}

ybar = ybar :/ mass
xbar = xbar :/ mass
zbar = zbar :/ mass

n = n_industries

regressors = (J(n, 1, 1), xbar)
instruments = (J(n, 1, 1), shock_n)
cross = instruments' * (mass :* regressors)
inverse = luinv(cross)
beta = inverse * instruments' * (mass :* ybar)
residual = ybar - regressors * beta
scores = instruments :* (mass :* residual)
covariance = n / (n - 2) * inverse * (scores' * scores) * inverse'

effect_estimate = beta[2]
effect_se = sqrt(covariance[2,2])

regressors = (J(n, 1, 1), zbar)
instruments = (J(n, 1, 1), shock_n)
cross = instruments' * (mass :* regressors)
inverse = luinv(cross)
beta = inverse * instruments' * (mass :* xbar)
residual = xbar - regressors * beta
scores = instruments :* (mass :* residual)
covariance = n / (n - 2) * inverse * (scores' * scores) * inverse'

first_stage_estimate = beta[2]
first_stage_se = sqrt(covariance[2,2])

effective_shocks = 1 / sum(mass :^ 2)

st_numscalar("effect_estimate", effect_estimate)
st_numscalar("effect_se", effect_se)
st_numscalar("first_stage_estimate", first_stage_estimate)
st_numscalar("first_stage_se", first_stage_se)
st_numscalar("effective_shocks", effective_shocks)
st_numscalar("n_industries", n)
end

display "ANSWER: effect estimate=" %21.12f scalar(effect_estimate) " se=" %21.12f scalar(effect_se) " n_obs=" %12.0f scalar(n_industries)
display "ANSWER: first_stage estimate=" %21.12f scalar(first_stage_estimate) " se=" %21.12f scalar(first_stage_se) " n_obs=" %12.0f scalar(n_industries)
display "ANSWER: effective_shocks estimate=" %21.12f scalar(effective_shocks) " se=." " n_obs=" %12.0f scalar(n_industries)
