clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

keep if abs(score) < 1
gen double tri_w = 1 - abs(score)
gen byte rd_right = score >= 0

count
scalar n_obs = r(N)

mata:
real scalar n_obs
real scalar rf, fs, te, var_rf, var_fs, cov_rf_fs, se_rf, se_fs, se_te
real matrix b, V
real rowvector x, e
real scalar i, j, k, side, n
real matrix X, Y, W, A, Ai, E, Meat, C
real scalar y1, y2, d1, d2

n_obs = st_numscalar("n_obs")
Y = st_data(., ("earnings", "participated"))
real colvector z = st_data(., "score")
real colvector w = st_data(., "tri_w")
real colvector r = st_data(., "rd_right")

b = J(2, 2, .)
C = J(2, 2, 0)

for (side = 0; side <= 1; side++) {
    real colvector keep = (r :== side)
    real matrix Z = select(z, keep)
    real matrix WW = select(w, keep)
    real matrix YY = select(Y, keep)
    n = rows(Z)

    if (n >= 2) {
        X = J(n, 1, 1), Z
        A = quadcross(X, WW, X)
        Ai = invsym(A)

        for (j = 1; j <= 2; j++) {
            b[side + 1, j] = (Ai * quadcross(X, WW, YY[,j]))[1,1]
        }

        E = YY - X * b[side + 1,.]'
        Meat = J(2, 2, 0)
        for (i = 1; i <= n; i++) {
            x = X[i,.]
            Meat = Meat + (WW[i]^2) * (x' * x) * (E[i,.]' * E[i,.])
        }
        V = Ai * Meat * Ai
        C = C + V
    }
}

rf = b[2,1] - b[1,1]
fs = b[2,2] - b[1,2]
te = rf / fs

var_rf = C[1,1]
var_fs = C[2,2]
cov_rf_fs = C[1,2]

se_rf = sqrt(var_rf)
se_fs = sqrt(var_fs)
se_te = sqrt((var_rf + te^2 * var_fs - 2 * te * cov_rf_fs) / fs^2)

st_numscalar("reduced_form", rf)
st_numscalar("first_stage", fs)
st_numscalar("treatment_effect", te)
st_numscalar("se_reduced_form", se_rf)
st_numscalar("se_first_stage", se_fs)
st_numscalar("se_treatment_effect", se_te)
end

display "ANSWER: treatment_effect estimate=" %21.12f treatment_effect " se=" %21.12f se_treatment_effect " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f reduced_form " se=" %21.12f se_reduced_form " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f first_stage " se=" %21.12f se_first_stage " n_obs=" %12.0f n_obs
