version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

egen long region_num = group(region_id)
egen long industry_num = group(industry_id)

sort region_num
by region_num: gen byte region_tag = (_n == 1)

egen double total_region_weight = total(region_weight) if region_tag
summarize total_region_weight, meanonly
scalar weight_total = r(max)

gen double e = region_weight / weight_total
gen double z_contribution = share * shock

by region_num: egen double z = total(z_contribution)

summarize y [aw=e] if region_tag, meanonly
scalar y_mean = r(mean)

summarize x [aw=e] if region_tag, meanonly
scalar x_mean = r(mean)

summarize z [aw=e] if region_tag, meanonly
scalar z_mean = r(mean)

gen double y0 = y - y_mean
gen double x0 = x - x_mean
gen double z0 = z - z_mean

gen double exposure_mass = e * share
gen double y_exposure = exposure_mass * y0
gen double x_exposure = exposure_mass * x0
gen double z_exposure = exposure_mass * z0

by industry_num: egen double s = total(exposure_mass)
by industry_num: egen double ybar_num = total(y_exposure)
by industry_num: egen double xbar_num = total(x_exposure)
by industry_num: egen double zbar_num = total(z_exposure)

gen double ybar = ybar_num / s
gen double xbar = xbar_num / s
gen double zbar = zbar_num / s

sort industry_num
by industry_num: gen byte industry_tag = (_n == 1)
keep if industry_tag & s > 0

count
scalar n_industries = r(N)

summarize shock, meanonly
scalar effective_shocks = 1 / sum(s^2)

mata:
void iv_hc1(string scalar depvar, string scalar endogvar, string scalar shockvar,
            string scalar weightvar, string scalar bname, string scalar sename)
{
    real matrix y, x, z, score, cross, invcross, covariance, beta
    real colvector w, residual
    real scalar n

    y = st_data(., depvar)
    x = st_data(., endogvar)
    z = st_data(., shockvar)
    w = st_data(., weightvar)

    n = rows(y)
    x = (J(n, 1, 1), x)
    z = (J(n, 1, 1), z)

    cross = z' * (w :* x)
    invcross = luinv(cross)
    beta = invcross * z' * (w :* y)

    residual = y - x * beta
    score = z :* (w :* residual)
    covariance = n / (n - 2) * invcross * (score' * score) * invcross'

    st_numscalar(bname, beta[2])
    st_numscalar(sename, sqrt(covariance[2,2]))
}

iv_hc1("ybar", "xbar", "shock", "s", "effect_b", "effect_se")
iv_hc1("xbar", "zbar", "shock", "s", "first_b", "first_se")
end

display "ANSWER: effect estimate=" %21.12f scalar(effect_b) ///
    " se=" %21.12f scalar(effect_se) ///
    " n_obs=" %12.0f scalar(n_industries)

display "ANSWER: first_stage estimate=" %21.12f scalar(first_b) ///
    " se=" %21.12f scalar(first_se) ///
    " n_obs=" %12.0f scalar(n_industries)

display "ANSWER: effective_shocks estimate=" %21.12f scalar(effective_shocks) ///
    " se=" %21.12f . ///
    " n_obs=" %12.0f scalar(n_industries)
