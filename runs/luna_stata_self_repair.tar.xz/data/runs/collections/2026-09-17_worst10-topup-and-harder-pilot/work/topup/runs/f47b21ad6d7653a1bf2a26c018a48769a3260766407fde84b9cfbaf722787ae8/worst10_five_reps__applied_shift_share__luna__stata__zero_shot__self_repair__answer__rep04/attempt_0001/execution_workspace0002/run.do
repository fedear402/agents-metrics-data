clear all
set more off
set linesize 255

import delimited using "./input.csv", varnames(1) clear

collapse (firstnm) region_weight x y shock (sum) share, by(region_id industry_id)

egen byte region_tag = tag(region_id)
egen double total_weight = total(cond(region_tag == 1, region_weight, 0))
gen double e = region_weight / total_weight

bysort region_id: egen double z = total(share * shock)

egen double mean_y = total(cond(region_tag == 1, e * y, 0))
egen double mean_x = total(cond(region_tag == 1, e * x, 0))
egen double mean_z = total(cond(region_tag == 1, e * z, 0))

gen double y0 = y - mean_y
gen double x0 = x - mean_x
gen double z0 = z - mean_z

gen double exposure = e * share
gen double y_num = exposure * y0
gen double x_num = exposure * x0
gen double z_num = exposure * z0

collapse (sum) s=exposure y_num x_num z_num, by(industry_id shock)

gen double ybar = y_num / s
gen double xbar = x_num / s
gen double zbar = z_num / s

count
local N = r(N)

summarize s, meanonly
local sum_s = r(sum)

mata:
void shock_iv(string scalar dep, string scalar endog, string scalar instr,
              string scalar wt, real scalar N, string scalar bname,
              string scalar sename)
{
    real matrix Y, X, Z, W, PZ, Xhat, A, B, V
    real colvector u, w, q, b

    Y = st_data(., dep)
    X = (J(rows(Y), 1, 1), st_data(., endog))
    Z = (J(rows(Y), 1, 1), st_data(., instr))
    w = st_data(., wt)
    W = diag(w)

    PZ = Z * invsym(Z' * W * Z) * Z' * W
    Xhat = PZ * X
    A = invsym(X' * W * X)
    b = A * X' * W * Y
    u = Y - X * b

    q = Xhat :* u :* w
    B = q' * q
    V = A * B * A * (N / (N - 2))

    st_numscalar(bname, b[2, 1])
    st_numscalar(sename, sqrt(V[2, 2]))
}
shock_iv("ybar", "xbar", "shock", "s", `N', "effect_b", "effect_se")
shock_iv("xbar", "zbar", "shock", "s", `N', "first_b", "first_se")
end

scalar effective = 1 / (`sum_s' - 1)

display "ANSWER: effect estimate=" %21.12f scalar(effect_b) ///
    " se=" %21.12f scalar(effect_se) ///
    " n_obs=" %12.0f `N'

display "ANSWER: first_stage estimate=" %21.12f scalar(first_b) ///
    " se=" %21.12f scalar(first_se) ///
    " n_obs=" %12.0f `N'

display "ANSWER: effective_shocks estimate=" %21.12f scalar(effective) ///
    " se=" %21.12f . ///
    " n_obs=" %12.0f `N'
