clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

gen double sort_date = date(date, "YMD")
sort sort_date

gen double ln_sales = ln(sales)
gen double ln_vix = ln(vix)
gen double dln_vix = ln_vix - ln_vix[_n-1]

forvalues j = 1/15 {
    gen double lag_`j' = dln_vix[_n-`j']
}

egen byte complete = rownonmiss(ln_sales lag_1-lag_15)
replace complete = 0 if missing(dln_vix)

quietly regress ln_sales lag_1-lag_15 if complete

gen byte regression_sample = e(sample)
predict double residual if regression_sample, residuals

count if regression_sample
scalar N_reg = r(N)

mata:
    X = st_data(., ("lag_1", "lag_2", "lag_3", "lag_4", "lag_5", ///
        "lag_6", "lag_7", "lag_8", "lag_9", "lag_10", "lag_11", ///
        "lag_12", "lag_13", "lag_14", "lag_15"), "regression_sample")
    X = J(rows(X), 1, 1), X
    u = st_data(., "residual", "regression_sample")
    N = rows(X)

    Z = X :* u
    S = cross(Z, Z)

    for (j = 1; j <= 15; j++) {
        w = 1 - j/16
        A = Z[(j+1)..N, .]
        B = Z[1..(N-j), .]
        S = S + w * (cross(A, B) + cross(B, A))
    }

    bread = invsym(cross(X, X))
    V = bread * S * bread * N/(N-16)
    b = bread * cross(X, u)

    c = J(16, 1, 1)
    c[1] = 0
    se_cumulative = sqrt(c' * V * c)

    st_numscalar("estimate_cumulative", sum(b[2..16]))
    st_numscalar("se_cumulative", se_cumulative)
    st_numscalar("estimate_lag1", b[2])
    st_numscalar("se_lag1", sqrt(V[2,2]))
    st_numscalar("estimate_lag15", b[16])
    st_numscalar("se_lag15", sqrt(V[16,16]))
end

display "ANSWER: cumulative_response estimate=" %21.12f estimate_cumulative " se=" %21.12f se_cumulative " n_obs=" %12.0f N_reg
display "ANSWER: lag_1 estimate=" %21.12f estimate_lag1 " se=" %21.12f se_lag1 " n_obs=" %12.0f N_reg
display "ANSWER: lag_15 estimate=" %21.12f estimate_lag15 " se=" %21.12f se_lag15 " n_obs=" %12.0f N_reg
