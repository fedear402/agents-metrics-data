clear all
set linesize 255

import delimited "./input.csv", clear
sort date

gen double lnsales = ln(sales)
gen double lnvix   = ln(vix)
gen double dlnvix  = lnvix - lnvix[_n-1]

forvalues j = 1/15 {
    gen double l`j' = dlnvix[_n-`j']
}

regress lnsales l1-l15
scalar n_obs = e(N)

predict double __uhat if e(sample), residuals
gen byte __esample = e(sample)

mata:
    real matrix Z, X, G, A, B, Sj, V
    real colvector es, u, idx, ones
    real scalar n, j, w

    Z = st_data(., "l1 l2 l3 l4 l5 l6 l7 l8 l9 l10 l11 l12 l13 l14 l15")
    es = st_data(., "__esample")
    u = st_data(., "__uhat")

    idx = selectindex(es :== 1)
    Z = Z[idx,.]
    u = u[idx]

    n = rows(Z)
    X = J(n,1,1), Z
    G = X :* u

    A = quadcross(X,X)
    B = quadcross(G,G)

    for (j=1; j<=15; j++) {
        w = 1 - j/16
        Sj = quadcross(G[(j+1)..n,.], G[1..(n-j),.])
        B = B + w * (Sj + Sj')
    }

    V = invsym(A) * B * invsym(A) * n/(n-16)

    st_numscalar("b_lag1", st_matrix("e(b)")[1,2])
    st_numscalar("b_lag15", st_matrix("e(b)")[1,16])
    st_numscalar("b_cumulative", sum(st_matrix("e(b)")[1,2..16]))
    st_numscalar("se_lag1", sqrt(V[2,2]))
    st_numscalar("se_lag15", sqrt(V[16,16]))
    st_numscalar("se_cumulative", sqrt(J(1,15,1) * V[2..16,2..16] * J(15,1,1)))
end

display "ANSWER: cumulative_response estimate=" %21.12f b_cumulative " se=" %21.12f se_cumulative " n_obs=" %12.0f n_obs
display "ANSWER: lag_1 estimate=" %21.12f b_lag1 " se=" %21.12f se_lag1 " n_obs=" %12.0f n_obs
display "ANSWER: lag_15 estimate=" %21.12f b_lag15 " se=" %21.12f se_lag15 " n_obs=" %12.0f n_obs
