version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

gen double z_part = share * shock
collapse (sum) z=z_part (firstnm) region_weight x y, by(region_id)

summarize region_weight, meanonly
gen double e = region_weight / r(sum)

tempfile regions
save `regions'

summarize y [aw=e], meanonly
scalar mean_y = r(mean)
summarize x [aw=e], meanonly
scalar mean_x = r(mean)
summarize z [aw=e], meanonly
scalar mean_z = r(mean)

use `regions', clear
gen double y0 = y - mean_y
gen double x0 = x - mean_x
gen double z0 = z - mean_z
keep region_id e y0 x0 z0
tempfile regional_centered
save `regional_centered'

import delimited using "./input.csv", clear
merge m:1 region_id using `regional_centered', nogen

gen double exposure = e * share
gen double s_part = exposure
gen double ybar_part = exposure * y0
gen double xbar_part = exposure * x0
gen double zbar_part = exposure * z0

collapse (sum) s=s_part ybar_num=ybar_part xbar_num=xbar_part zbar_num=zbar_part ///
    (firstnm) shock, by(industry_id)

drop if s <= 0
gen double ybar = ybar_num / s
gen double xbar = xbar_num / s
gen double zbar = zbar_num / s

mata:
    S = st_data(., "s")
    Y = st_data(., "ybar")
    X = st_data(., "xbar")
    Zshock = st_data(., "shock")
    Zbar = st_data(., "zbar")
    N = rows(S)

    W = (J(N,1,1), X)
    Q = (J(N,1,1), Zshock)
    A = Q' * (S :* W)
    b = luinv(A) * Q' * (S :* Y)
    u = Y - W*b
    scores = Q :* (S :* u)
    V = N/(N-2) * luinv(A) * (scores'*scores) * luinv(A)'
    st_numscalar("effect_est", b[2])
    st_numscalar("effect_se", sqrt(V[2,2]))

    W1 = (J(N,1,1), Zbar)
    Q1 = (J(N,1,1), Zshock)
    A1 = Q1' * (S :* W1)
    b1 = luinv(A1) * Q1' * (S :* X)
    u1 = X - W1*b1
    scores1 = Q1 :* (S :* u1)
    V1 = N/(N-2) * luinv(A1) * (scores1'*scores1) * luinv(A1)'
    st_numscalar("first_stage_est", b1[2])
    st_numscalar("first_stage_se", sqrt(V1[2,2]))

    st_numscalar("effective_shocks_est", 1/sum(S:^2))
    st_numscalar("n_industries", N)
end

display "ANSWER: effect estimate=" %21.12f scalar(effect_est) ///
    " se=" %21.12f scalar(effect_se) ///
    " n_obs=" %12.0f scalar(n_industries)

display "ANSWER: first_stage estimate=" %21.12f scalar(first_stage_est) ///
    " se=" %21.12f scalar(first_stage_se) ///
    " n_obs=" %12.0f scalar(n_industries)

display "ANSWER: effective_shocks estimate=" %21.12f scalar(effective_shocks_est) ///
    " se=." ///
    " n_obs=" %12.0f scalar(n_industries)
