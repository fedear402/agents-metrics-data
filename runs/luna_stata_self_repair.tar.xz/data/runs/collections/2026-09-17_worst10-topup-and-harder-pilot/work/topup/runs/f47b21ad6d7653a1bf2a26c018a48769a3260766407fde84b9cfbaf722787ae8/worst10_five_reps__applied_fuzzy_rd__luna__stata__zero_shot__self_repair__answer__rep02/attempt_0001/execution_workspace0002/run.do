clear all
set more off
set linesize 255

import delimited "./input.csv", clear

keep if abs(score) < 1
generate double weight = 1 - abs(score)

mata:
    y1 = st_data(., "earnings")
    y2 = st_data(., "participated")
    s  = st_data(., "score")
    w  = st_data(., "weight")
    n  = rows(s)

    X = J(n, 4, 0)
    X[,1] = s :< 0
    X[,2] = X[,1] :* s
    X[,3] = s :>= 0
    X[,4] = X[,3] :* s

    A = quadcross(X, w, X)
    Ai = invsym(A)

    b1 = Ai * quadcross(X, w, y1)
    b2 = Ai * quadcross(X, w, y2)

    e1 = y1 - X*b1
    e2 = y2 - X*b2

    M11 = J(4,4,0)
    M22 = J(4,4,0)
    M12 = J(4,4,0)

    for (i=1; i<=n; i++) {
        xi = X[i,.]'
        M11 = M11 + (w[i]^2 * e1[i]^2) * (xi*xi')
        M22 = M22 + (w[i]^2 * e2[i]^2) * (xi*xi')
        M12 = M12 + (w[i]^2 * e1[i]*e2[i]) * (xi*xi')
    }

    V11 = Ai * M11 * Ai
    V22 = Ai * M22 * Ai
    V12 = Ai * M12 * Ai

    c = (-1, 0, 1, 0)'

    rf = c' * b1
    fs = c' * b2

    var_rf = c' * V11 * c
    var_fs = c' * V22 * c
    cov_rf_fs = c' * V12 * c

    se_rf = sqrt(cond(var_rf < 0, 0, var_rf))
    se_fs = sqrt(cond(var_fs < 0, 0, var_fs))

    if (fs != 0) {
        te = rf / fs
        var_te = var_rf/(fs^2) + (rf^2*var_fs)/(fs^4) - 2*rf*cov_rf_fs/(fs^3)
        se_te = sqrt(cond(var_te < 0, 0, var_te))
    }
    else {
        te = .
        se_te = .
    }

    st_numscalar("estimate_rf", rf)
    st_numscalar("se_rf", se_rf)
    st_numscalar("estimate_fs", fs)
    st_numscalar("se_fs", se_fs)
    st_numscalar("estimate_te", te)
    st_numscalar("se_te", se_te)
    st_numscalar("n_obs", n)
end

display "ANSWER: treatment_effect estimate=" %21.12f estimate_te " se=" %21.12f se_te " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f estimate_rf " se=" %21.12f se_rf " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f estimate_fs " se=" %21.12f se_fs " n_obs=" %12.0f n_obs
