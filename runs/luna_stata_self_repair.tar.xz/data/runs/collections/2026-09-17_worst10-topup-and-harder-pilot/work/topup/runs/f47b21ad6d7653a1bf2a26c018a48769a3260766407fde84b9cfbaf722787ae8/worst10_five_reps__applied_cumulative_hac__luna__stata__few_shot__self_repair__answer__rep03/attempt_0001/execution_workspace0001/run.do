version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

generate double date_num = date(date, "YMD")
sort date_num
generate long observation = _n
tsset observation

generate double log_vix = log(vix)
generate double vix_change = D.log_vix
generate double log_sales = log(sales)

local lagvars
forvalues j = 1/15 {
    generate double lag_`j' = L`j'.vix_change
    local lagvars `lagvars' lag_`j'
}

egen byte n_missing = rowmiss(log_sales `lagvars')
keep if n_missing == 0
drop n_missing

mata:
y = st_data(., "log_sales")
X = (J(st_nobs(), 1, 1), st_data(., "`lagvars'"))

coefficients = qrsolve(X, y)
residuals = y - X * coefficients

N = rows(X)
p = cols(X)
hac_lags = 15

scores = X :* residuals
meat = scores' * scores

for (j = 1; j <= hac_lags; j++) {
    lag_product = scores[|j + 1, 1 \ N, p|]' * scores[|1, 1 \ N - j, p|]
    meat = meat + (1 - j / 16) * (lag_product + lag_product')
}

bread = invsym(X' * X)
covariance = N / (N - 16) * bread * meat * bread

contrast = (0 \ J(15, 1, 1))
cumulative_response = contrast' * coefficients
cumulative_se = sqrt(contrast' * covariance * contrast)

st_numscalar("cumulative_response", cumulative_response)
st_numscalar("cumulative_se", cumulative_se)
st_numscalar("lag_1_estimate", coefficients[2])
st_numscalar("lag_1_se", sqrt(covariance[2, 2]))
st_numscalar("lag_15_estimate", coefficients[16])
st_numscalar("lag_15_se", sqrt(covariance[16, 16]))
st_numscalar("n_obs", N)
end

display "ANSWER: cumulative_response estimate=" %21.12f scalar(cumulative_response) " se=" %21.12f scalar(cumulative_se) " n_obs=" %12.0f scalar(n_obs)
display "ANSWER: lag_1 estimate=" %21.12f scalar(lag_1_estimate) " se=" %21.12f scalar(lag_1_se) " n_obs=" %12.0f scalar(n_obs)
display "ANSWER: lag_15 estimate=" %21.12f scalar(lag_15_estimate) " se=" %21.12f scalar(lag_15_se) " n_obs=" %12.0f scalar(n_obs)
