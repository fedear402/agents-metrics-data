clear all
set linesize 255

import delimited using "./input.csv", clear

sort region_id industry_id
by region_id: gen byte region_tag = (_n == 1)

egen total_weight = total(cond(region_tag, region_weight, 0))
gen double e = region_weight / total_weight

gen double z = share * shock

egen double y_mean = total(cond(region_tag, e * y, 0))
egen double x_mean = total(cond(region_tag, e * x, 0))
egen double z_mean = total(cond(region_tag, e * z, 0))

gen double y0 = y - y_mean
gen double x0 = x - x_mean
gen double z0 = z - z_mean

gen double s_part = e * share
gen double y_num = e * share * y0
gen double x_num = e * share * x0
gen double z_num = e * share * z0

collapse (sum) s=s_part y_num x_num z_num (mean) shock, by(industry_id)
drop if s <= 0

gen double ybar = y_num / s
gen double xbar = x_num / s
gen double zbar = z_num / s

count
scalar N_industries = r(N)

ivregress 2sls ybar (xbar = shock) [aw=s], vce(robust)
scalar effect_estimate = _b[xbar]
scalar effect_se = _se[xbar] * sqrt(N_industries / (N_industries - 2))

ivregress 2sls xbar (zbar = shock) [aw=s], vce(robust)
scalar first_stage_estimate = _b[zbar]
scalar first_stage_se = _se[zbar] * sqrt(N_industries / (N_industries - 2))

quietly summarize s [aw=s], meanonly
scalar effective_shocks = 1 / sum(s^2)

display "ANSWER: effect estimate=" %21.12f effect_estimate ///
    " se=" %21.12f effect_se " n_obs=" %12.0f N_industries

display "ANSWER: first_stage estimate=" %21.12f first_stage_estimate ///
    " se=" %21.12f first_stage_se " n_obs=" %12.0f N_industries

display "ANSWER: effective_shocks estimate=" %21.12f effective_shocks ///
    " se=. n_obs=" %12.0f N_industries
