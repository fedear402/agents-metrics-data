clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

sort date

gen double ln_sales = ln(sales)
gen double dln_vix = ln(vix) - ln(vix[_n-1])

forvalues j = 1/15 {
    gen double lag_`j' = dln_vix[_n-`j']
}

gen byte complete = !missing(ln_sales, lag_1, lag_2, lag_3, lag_4, lag_5, ///
    lag_6, lag_7, lag_8, lag_9, lag_10, lag_11, lag_12, lag_13, lag_14, lag_15)

regress ln_sales lag_1-lag_15 if complete

local n = e(N)

predict double __resid if e(sample), residual

mata:
    real matrix Z
    real matrix X
    real matrix Q
    real matrix S
    real matrix XXinv
    real matrix V
    real matrix b
    real matrix Qlead
    real matrix Qlag
    real colvector u
    real colvector one
    real scalar n
    real scalar j
    real scalar w
    real scalar cumvar

    Z = st_data(., "lag_1 lag_2 lag_3 lag_4 lag_5 lag_6 lag_7 lag_8 lag_9 lag_10 lag_11 lag_12 lag_13 lag_14 lag_15", "e(sample)")
    X = J(rows(Z), 1, 1), Z
    u = st_data(., "__resid", "e(sample)")
    n = rows(X)

    Q = X :* u
    S = Q' * Q

    for (j = 1; j <= 15; j++) {
        w = 1 - j/16
        Qlead = Q[(j+1)..n, .]
        Qlag = Q[1..(n-j), .]
        S = S + w * (Qlead' * Qlag + Qlag' * Qlead)
    }

    XXinv = invsym(X' * X)
    V = (n/(n-16)) * XXinv * S * XXinv
    b = st_matrix("e(b)")'

    one = J(15, 1, 1)
    cumvar = one' * V[2..16, 2..16] * one

    st_numscalar("cumulative_response", sum(b[2..16]))
    st_numscalar("cumulative_se", sqrt(cumvar))
    st_numscalar("lag_1_estimate", b[2])
    st_numscalar("lag_1_se", sqrt(V[2, 2]))
    st_numscalar("lag_15_estimate", b[16])
    st_numscalar("lag_15_se", sqrt(V[16, 16]))
    st_numscalar("n_obs", n)
end

display "ANSWER: cumulative_response estimate=" %21.12f scalar(cumulative_response) ///
    " se=" %21.12f scalar(cumulative_se) " n_obs=" %12.0f scalar(n_obs)

display "ANSWER: lag_1 estimate=" %21.12f scalar(lag_1_estimate) ///
    " se=" %21.12f scalar(lag_1_se) " n_obs=" %12.0f scalar(n_obs)

display "ANSWER: lag_15 estimate=" %21.12f scalar(lag_15_estimate) ///
    " se=" %21.12f scalar(lag_15_se) " n_obs=" %12.0f scalar(n_obs)
