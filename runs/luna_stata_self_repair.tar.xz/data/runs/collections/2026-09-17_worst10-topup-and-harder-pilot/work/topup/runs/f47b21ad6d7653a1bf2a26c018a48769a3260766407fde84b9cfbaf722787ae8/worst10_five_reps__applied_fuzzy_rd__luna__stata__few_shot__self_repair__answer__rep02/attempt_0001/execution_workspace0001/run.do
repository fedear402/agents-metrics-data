version 19.0
clear all
set more off
set linesize 255

import delimited "./input.csv", clear

keep if abs(score) < 1
generate double weight = 1 - abs(score)
generate double right = score >= 0
generate double right_score = right * score
generate double left_score = (1 - right) * score

quietly count
local n_obs = r(N)

mata:
Y = st_data(., ("earnings", "participated"))
x = st_data(., ("right", "right_score", "left_score"))
w = st_data(., "weight")

bread = invsym(x' * (w :* x))
beta = bread * x' * (w :* Y)
residuals = Y - x * beta

right_limit = (1, 0, 0)
left_limit = (1, 0, 0)
right_limit[2] = 1
left_limit[3] = 1
contrast = right_limit - left_limit

discontinuities = contrast * beta
loading = w :* (x * bread * contrast')
influence = loading :* residuals
joint_covariance = influence' * influence

reduced_form = discontinuities[1]
first_stage = discontinuities[2]

gradient = (1 / first_stage \ -reduced_form / first_stage^2)
treatment_effect = reduced_form / first_stage
treatment_variance = gradient' * joint_covariance * gradient

st_numscalar("reduced_form", reduced_form)
st_numscalar("first_stage", first_stage)
st_numscalar("treatment_effect", treatment_effect)
st_numscalar("reduced_form_se", sqrt(joint_covariance[1,1]))
st_numscalar("first_stage_se", sqrt(joint_covariance[2,2]))
st_numscalar("treatment_effect_se", sqrt(treatment_variance))
end

display "ANSWER: treatment_effect estimate=" %21.12f treatment_effect " se=" %21.12f treatment_effect_se " n_obs=" %12.0f `n_obs'
display "ANSWER: reduced_form estimate=" %21.12f reduced_form " se=" %21.12f reduced_form_se " n_obs=" %12.0f `n_obs'
display "ANSWER: first_stage estimate=" %21.12f first_stage " se=" %21.12f first_stage_se " n_obs=" %12.0f `n_obs'
