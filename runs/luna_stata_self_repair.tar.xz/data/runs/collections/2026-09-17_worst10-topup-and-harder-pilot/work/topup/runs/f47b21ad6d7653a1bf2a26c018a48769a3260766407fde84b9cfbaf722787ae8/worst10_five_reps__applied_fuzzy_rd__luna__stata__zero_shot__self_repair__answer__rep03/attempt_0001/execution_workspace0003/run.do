clear
set linesize 255

import delimited using "./input.csv", clear

generate byte touse = abs(score) < 1 & !missing(score, participated, earnings)
generate double wt = 1 - abs(score)
generate byte right = score >= 0 if touse
generate double rightscore = right * score
generate double one = 1

count if touse
local n_obs = r(N)

regress earnings score right rightscore [aw=wt] if touse
matrix b_earnings = e(b)
predict double resid_earnings if e(sample), residuals

regress participated score right rightscore [aw=wt] if touse
matrix b_participated = e(b)
predict double resid_participated if e(sample), residuals

mata:
    X = st_data(., ("one", "score", "right", "rightscore"), "touse")
    w = st_data(., "wt", "touse")
    ey = st_data(., "resid_earnings", "touse")
    ep = st_data(., "resid_participated", "touse")

    A = quadcross(X, w, X)
    B = invsym(A)

    Qy = X :* (w :* ey)
    Qp = X :* (w :* ep)

    Vyy = B * quadcross(Qy, Qy) * B
    Vpp = B * quadcross(Qp, Qp) * B
    Vyp = B * quadcross(Qy, Qp) * B

    rf = st_matrix("b_earnings")[1, 2]
    fs = st_matrix("b_participated")[1, 2]

    vrf = Vyy[3, 3]
    vfs = Vpp[3, 3]
    crf_fs = Vyp[3, 3]

    se_rf = .
    if (vrf >= 0) se_rf = sqrt(vrf)

    se_fs = .
    if (vfs >= 0) se_fs = sqrt(vfs)

    te = .
    sete = .

    if (fs != 0) {
        te = rf / fs
        vte = vrf / (fs^2) + (rf^2 * vfs) / (fs^4) - 2 * rf * crf_fs / (fs^3)
        if (vte >= 0) sete = sqrt(vte)
    }

    st_numscalar("treatment_effect", te)
    st_numscalar("se_treatment_effect", sete)
    st_numscalar("reduced_form", rf)
    st_numscalar("se_reduced_form", se_rf)
    st_numscalar("first_stage", fs)
    st_numscalar("se_first_stage", se_fs)
end

display "ANSWER: treatment_effect estimate=" %21.12f scalar(treatment_effect) " se=" %21.12f scalar(se_treatment_effect) " n_obs=" %12.0f `n_obs'
display "ANSWER: reduced_form estimate=" %21.12f scalar(reduced_form) " se=" %21.12f scalar(se_reduced_form) " n_obs=" %12.0f `n_obs'
display "ANSWER: first_stage estimate=" %21.12f scalar(first_stage) " se=" %21.12f scalar(se_first_stage) " n_obs=" %12.0f `n_obs'
