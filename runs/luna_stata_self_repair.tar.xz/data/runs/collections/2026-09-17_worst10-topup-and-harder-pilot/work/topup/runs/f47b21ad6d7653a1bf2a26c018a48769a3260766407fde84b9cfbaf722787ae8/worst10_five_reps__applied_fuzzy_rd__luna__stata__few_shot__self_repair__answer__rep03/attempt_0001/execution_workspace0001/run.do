version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

keep if abs(score) < 1
keep if !missing(score, participated, earnings)

generate double right = (score >= 0)
generate double right_score = right * score
generate double weight = 1 - abs(score)

count
local n_obs = r(N)

mata:
y = st_data(., ("earnings", "participated"))
z = st_data(., ("score", "right", "right_score"))
w = st_data(., "weight")

X = (J(rows(z), 1, 1), z)
bread = invsym(X' * (w :* X))
b = bread * X' * (w :* y)
e = y - X * b

V11 = J(cols(X), cols(X), 0)
V22 = J(cols(X), cols(X), 0)
V12 = J(cols(X), cols(X), 0)

for (i = 1; i <= rows(X); i++) {
    xi = X[i,]'
    wi = w[i]
    e1 = e[i,1]
    e2 = e[i,2]
    V11 = V11 + (wi^2 * e1^2) * (bread * xi * xi' * bread)
    V22 = V22 + (wi^2 * e2^2) * (bread * xi * xi' * bread)
    V12 = V12 + (wi^2 * e1 * e2) * (bread * xi * xi' * bread)
}

d1 = b[3,1]
d2 = b[3,2]
v1 = V11[3,3]
v2 = V22[3,3]
cov12 = V12[3,3]

ratio = d1 / d2
g = (1 / d2 \ -d1 / d2^2)
ratio_var = g' * ((v1, cov12) \ (cov12, v2)) * g

st_numscalar("reduced_form", d1)
st_numscalar("reduced_form_se", sqrt(v1))
st_numscalar("first_stage", d2)
st_numscalar("first_stage_se", sqrt(v2))
st_numscalar("treatment_effect", ratio)
st_numscalar("treatment_effect_se", sqrt(ratio_var))
end

display "ANSWER: treatment_effect estimate=" %21.12f scalar(treatment_effect) " se=" %21.12f scalar(treatment_effect_se) " n_obs=" %12.0f `n_obs'
display "ANSWER: reduced_form estimate=" %21.12f scalar(reduced_form) " se=" %21.12f scalar(reduced_form_se) " n_obs=" %12.0f `n_obs'
display "ANSWER: first_stage estimate=" %21.12f scalar(first_stage) " se=" %21.12f scalar(first_stage_se) " n_obs=" %12.0f `n_obs'
