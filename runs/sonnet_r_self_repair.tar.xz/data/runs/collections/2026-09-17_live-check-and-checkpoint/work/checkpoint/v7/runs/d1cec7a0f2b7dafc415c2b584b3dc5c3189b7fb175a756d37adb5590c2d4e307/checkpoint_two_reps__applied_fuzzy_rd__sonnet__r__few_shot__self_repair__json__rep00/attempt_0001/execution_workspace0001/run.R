library(jsonlite)

dat <- read.csv("input.csv")
names(dat) <- trimws(names(dat))

# Apply bandwidth filter
bw_dat <- dat[abs(dat$score) < 1, ]
n_obs <- nrow(bw_dat)

# Triangular weights
bw_dat$w <- 1 - abs(bw_dat$score)

# Indicator for right side
bw_dat$above <- as.integer(bw_dat$score >= 0)

# Local linear: separate slopes on each side
# X matrix: intercept, above, score, score*above
X <- cbind(1, bw_dat$above, bw_dat$score, bw_dat$score * bw_dat$above)
w <- bw_dat$w
Y_earn <- bw_dat$earnings
Y_part <- bw_dat$participated

# WLS bread
WX <- w * X
bread <- solve(crossprod(X, WX))

# Coefficients
coef_earn <- bread %*% crossprod(X, w * Y_earn)
coef_part <- bread %*% crossprod(X, w * Y_part)

# Residuals
resid_earn <- Y_earn - X %*% coef_earn
resid_part <- Y_part - X %*% coef_part

# The discontinuity (right limit minus left limit) is the coefficient on 'above'
# contrast = c(0, 1, 0, 0)
contrast <- c(0, 1, 0, 0)

jump_earn <- drop(contrast %*% coef_earn)
jump_part <- drop(contrast %*% coef_part)

# HC0 sandwich: loading vector
loading <- w * drop(X %*% bread %*% contrast)

# Influence functions
inf_earn <- loading * resid_earn
inf_part <- loading * resid_part

# Joint covariance (HC0, no df correction)
V_ee <- sum(inf_earn^2)
V_pp <- sum(inf_part^2)
V_ep <- sum(inf_earn * inf_part)

se_earn <- sqrt(V_ee)
se_part <- sqrt(V_pp)

# Delta method for ratio = jump_earn / jump_part
# gradient w.r.t. (jump_earn, jump_part): (1/jump_part, -jump_earn/jump_part^2)
grad <- c(1/jump_part, -jump_earn/jump_part^2)
joint <- matrix(c(V_ee, V_ep, V_ep, V_pp), 2, 2)
se_ratio <- sqrt(drop(t(grad) %*% joint %*% grad))

ratio <- jump_earn / jump_part

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = unname(ratio), se = unname(se_ratio), n_obs = as.integer(n_obs)),
    list(term = "reduced_form", estimate = unname(jump_earn), se = unname(se_earn), n_obs = as.integer(n_obs)),
    list(term = "first_stage", estimate = unname(jump_part), se = unname(se_part), n_obs = as.integer(n_obs))
  ),
  method_metadata = list(
    estimator = "fuzzy_rd_local_linear_triangular",
    vcov = "HC0"
  ),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, digits = 16, pretty = TRUE)
