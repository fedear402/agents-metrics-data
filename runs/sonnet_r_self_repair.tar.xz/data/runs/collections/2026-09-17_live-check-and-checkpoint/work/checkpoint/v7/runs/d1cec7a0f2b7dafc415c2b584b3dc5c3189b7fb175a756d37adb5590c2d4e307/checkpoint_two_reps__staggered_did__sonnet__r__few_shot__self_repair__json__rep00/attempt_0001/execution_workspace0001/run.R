library(jsonlite)

df <- read.csv("./input.csv")

cohorts <- c(4, 6, 8)
never <- df[df$cohort == -1, ]

cell_atts <- c()

for (g in cohorts) {
  treated_g <- df[df$cohort == g, ]
  pre_year <- g - 1
  
  # Baseline for treated group
  base_treated <- mean(treated_g$y_did[treated_g$year == pre_year])
  # Baseline for never-treated
  base_never <- mean(never$y_did[never$year == pre_year])
  
  # Post-treatment years for cohort g: years >= g up to max year
  post_years <- unique(df$year[df$year >= g])
  
  for (t in post_years) {
    mean_treated_t <- mean(treated_g$y_did[treated_g$year == t])
    mean_never_t <- mean(never$y_did[never$year == t])
    
    att_gt <- (mean_treated_t - base_treated) - (mean_never_t - base_never)
    cell_atts <- c(cell_atts, att_gt)
  }
}

att_uniform <- mean(cell_atts)

# Count observations: treated cohort-year cells post treatment
n_obs <- 0
for (g in cohorts) {
  post_years <- unique(df$year[df$year >= g])
  n_obs <- n_obs + nrow(df[df$cohort == g & df$year %in% post_years, ])
}

out <- list(
  task_id = "staggered_did",
  platform = "r",
  estimates = list(
    list(term = "att", estimate = att_uniform, se = NA, n_obs = as.integer(n_obs))
  ),
  method_metadata = list(
    estimator = "ATT_uniform from cohort-year cell means (equal-weight)",
    vcov = "none"
  ),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "./result.json", auto_unbox = TRUE)
