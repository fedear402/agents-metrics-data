library(sandwich)
library(lmtest)
library(jsonlite)

data <- read.csv("./input.csv")

model <- lm(y_lin ~ x1 + x2, data = data)

vcov_hc1 <- vcovHC(model, type = "HC1")
ct <- coeftest(model, vcov = vcov_hc1)

n_obs <- nobs(model)

estimates <- list(
  list(term = "const", estimate = unname(ct["(Intercept)", "Estimate"]), se = unname(ct["(Intercept)", "Std. Error"]), n_obs = n_obs),
  list(term = "x1",    estimate = unname(ct["x1", "Estimate"]),          se = unname(ct["x1", "Std. Error"]),          n_obs = n_obs),
  list(term = "x2",    estimate = unname(ct["x2", "Estimate"]),          se = unname(ct["x2", "Std. Error"]),          n_obs = n_obs)
)

result <- list(
  task_id = "ols_robust",
  platform = "r",
  estimates = estimates,
  method_metadata = list(estimator = "OLS", vcov = "HC1"),
  diagnostics = setNames(list(), character(0))
)

write(toJSON(result, auto_unbox = TRUE, digits = 10), "result.json")
