library(plm)
library(lmtest)
library(sandwich)
library(jsonlite)

data <- read.csv("./input.csv")

pdata <- pdata.frame(data, index = c("firm", "year"))

model <- plm(y_twocluster ~ x, data = pdata, model = "within", effect = "twoways")

vcov_clustered <- vcovHC(model, type = "HC1", cluster = "group")

coef_test <- coeftest(model, vcov = vcov_clustered)

est <- coef_test["x", "Estimate"]
se  <- coef_test["x", "Std. Error"]
n   <- nobs(model)

result <- list(
  task_id  = "twoway_fe",
  platform = "r",
  estimates = list(
    list(term = "x", estimate = as.numeric(est), se = as.numeric(se), n_obs = as.integer(n))
  ),
  method_metadata = list(estimator = "plm within twoways", vcov = "HC1 clustered on firm"),
  diagnostics = setNames(list(), character(0))
)

write(toJSON(result, auto_unbox = TRUE, digits = 10), "./result.json")
