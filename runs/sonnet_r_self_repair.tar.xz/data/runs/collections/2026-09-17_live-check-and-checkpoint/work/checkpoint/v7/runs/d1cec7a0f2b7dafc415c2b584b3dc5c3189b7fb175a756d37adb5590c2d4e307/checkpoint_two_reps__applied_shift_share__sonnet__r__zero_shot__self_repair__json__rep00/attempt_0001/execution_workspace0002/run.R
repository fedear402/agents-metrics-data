library(AER)
library(sandwich)
library(jsonlite)

dat <- read.csv("input.csv")

reg_dat <- dat[!duplicated(dat$region_id), c("region_id", "region_weight", "x", "y")]
reg_dat$e_r <- reg_dat$region_weight / sum(reg_dat$region_weight)

z_vals <- tapply(seq_len(nrow(dat)), dat$region_id, function(idx) {
  sum(dat$share[idx] * dat$shock[idx])
})
reg_dat$z <- as.numeric(z_vals[as.character(reg_dat$region_id)])

wmean <- function(v, w) sum(v * w) / sum(w)
y_wm <- wmean(reg_dat$y, reg_dat$e_r)
x_wm <- wmean(reg_dat$x, reg_dat$e_r)
z_wm <- wmean(reg_dat$z, reg_dat$e_r)

reg_dat$y0 <- reg_dat$y - y_wm
reg_dat$x0 <- reg_dat$x - x_wm
reg_dat$z0 <- reg_dat$z - z_wm

dat2 <- merge(dat, reg_dat[, c("region_id", "e_r", "y0", "x0", "z0")], by = "region_id")

industries <- sort(unique(dat2$industry_id))
N <- length(industries)

ind_list <- lapply(industries, function(n) {
  idx <- which(dat2$industry_id == n)
  s_n <- sum(dat2$e_r[idx] * dat2$share[idx])
  shock_n <- dat2$shock[idx[1]]
  ybar <- sum(dat2$e_r[idx] * dat2$share[idx] * dat2$y0[idx]) / s_n
  xbar <- sum(dat2$e_r[idx] * dat2$share[idx] * dat2$x0[idx]) / s_n
  zbar <- sum(dat2$e_r[idx] * dat2$share[idx] * dat2$z0[idx]) / s_n
  data.frame(industry_id = n, shock = shock_n, s_n = s_n,
             ybar = ybar, xbar = xbar, zbar = zbar)
})
ind_dat <- do.call(rbind, ind_list)
rownames(ind_dat) <- NULL

wts <- as.numeric(ind_dat$s_n)

iv_effect <- ivreg(ybar ~ xbar | shock, data = ind_dat, weights = wts)
vcov_effect <- vcovHC(iv_effect, type = "HC1")
se_effect <- sqrt(diag(vcov_effect))["xbar"]
coef_effect <- coef(iv_effect)["xbar"]

iv_fs <- ivreg(xbar ~ zbar | shock, data = ind_dat, weights = wts)
vcov_fs <- vcovHC(iv_fs, type = "HC1")
se_fs <- sqrt(diag(vcov_fs))["zbar"]
coef_fs <- coef(iv_fs)["zbar"]

eff_shocks <- 1 / sum(ind_dat$s_n^2)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = as.numeric(coef_effect), se = as.numeric(se_effect), n_obs = as.integer(N)),
    list(term = "first_stage", estimate = as.numeric(coef_fs), se = as.numeric(se_fs), n_obs = as.integer(N)),
    list(term = "effective_shocks", estimate = as.numeric(eff_shocks), se = NULL, n_obs = as.integer(N))
  ),
  method_metadata = list(
    estimator = "2SLS shift-share with Borusyak-Hull-Jaravel exposure-robust SE",
    vcov = "HC1"
  ),
  diagnostics = list()
)

write(toJSON(result, auto_unbox = TRUE, digits = 10, null = "null"), "result.json")
