library(nnet)
library(jsonlite)

dat <- read.csv("input.csv")
dat$y <- factor(dat$y, levels = c(0, 1, 2))

fit <- multinom(y ~ x + z, data = dat, trace = FALSE)

coefs <- summary(fit)$coefficients
ses <- summary(fit)$standard.errors

x_cat1 <- coefs["1", "x"]
z_cat1 <- coefs["1", "z"]
x_cat2 <- coefs["2", "x"]
z_cat2 <- coefs["2", "z"]

se_x_cat1 <- ses["1", "x"]
se_z_cat1 <- ses["1", "z"]
se_x_cat2 <- ses["2", "x"]
se_z_cat2 <- ses["2", "z"]

newdat <- data.frame(x = 0, z = 0)
probs <- predict(fit, newdata = newdat, type = "probs")
prob_cat2_zero <- as.numeric(probs["2"])

n_obs <- nrow(dat)

result <- list(
  task_id = "broad_multinomial_logit",
  platform = "r",
  estimates = list(
    list(term = "x_cat1", estimate = x_cat1, se = se_x_cat1, n_obs = n_obs),
    list(term = "z_cat1", estimate = z_cat1, se = se_z_cat1, n_obs = n_obs),
    list(term = "x_cat2", estimate = x_cat2, se = se_x_cat2, n_obs = n_obs),
    list(term = "z_cat2", estimate = z_cat2, se = se_z_cat2, n_obs = n_obs),
    list(term = "prob_cat2_zero", estimate = prob_cat2_zero, se = NULL, n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "multinomial logit (nnet::multinom)",
    vcov = "observed information (default)"
  ),
  diagnostics = setNames(list(), character(0))
)

write(toJSON(result, auto_unbox = TRUE, digits = 10, null = "null"), "result.json")
