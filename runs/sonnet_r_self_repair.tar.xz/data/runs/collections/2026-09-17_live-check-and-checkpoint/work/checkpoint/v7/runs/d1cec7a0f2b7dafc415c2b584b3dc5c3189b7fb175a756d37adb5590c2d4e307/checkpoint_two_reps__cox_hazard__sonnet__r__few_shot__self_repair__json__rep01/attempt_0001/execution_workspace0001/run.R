library(jsonlite)
library(survival)

df <- read.csv("./input.csv")

fit <- coxph(Surv(t_obs, event) ~ treat + x, data = df)

coefs <- coef(fit)
ses <- sqrt(diag(vcov(fit)))
n <- nrow(df)

out <- list(
  task_id = "cox_hazard",
  platform = "r",
  estimates = list(
    list(term = "treat", estimate = unname(coefs["treat"]), se = unname(ses["treat"]), n_obs = n),
    list(term = "x", estimate = unname(coefs["x"]), se = unname(ses["x"]), n_obs = n)
  ),
  method_metadata = list(estimator = "Cox proportional hazards", vcov = "model-based"),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "result.json", auto_unbox = TRUE, digits = 10)
