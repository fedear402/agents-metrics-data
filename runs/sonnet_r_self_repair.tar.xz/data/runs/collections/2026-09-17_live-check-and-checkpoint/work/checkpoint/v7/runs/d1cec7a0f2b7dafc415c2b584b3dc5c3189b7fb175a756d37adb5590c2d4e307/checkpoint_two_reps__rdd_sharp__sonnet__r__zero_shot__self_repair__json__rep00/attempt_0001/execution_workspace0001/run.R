library(jsonlite)

data <- read.csv("./input.csv")

h <- 0.5
cutoff <- 0

data_left <- data[data$z >= (cutoff - h) & data$z < cutoff, ]
data_right <- data[data$z >= cutoff & data$z <= (cutoff + h), ]

tri_kernel <- function(u) {
  w <- 1 - abs(u) / h
  w[w < 0] <- 0
  w
}

w_left <- tri_kernel(data_left$z - cutoff)
w_right <- tri_kernel(data_right$z - cutoff)

fit_left <- lm(y ~ z, data = data_left, weights = w_left)
fit_right <- lm(y ~ z, data = data_right, weights = w_right)

intercept_left <- coef(fit_left)[["(Intercept)"]]
intercept_right <- coef(fit_right)[["(Intercept)"]]

late_estimate <- intercept_right - intercept_left

n_obs <- nrow(data_left) + nrow(data_right)

result <- list(
  task_id = "rdd_sharp",
  platform = "r",
  estimates = list(
    list(
      term = "late",
      estimate = as.numeric(late_estimate),
      se = NULL,
      n_obs = as.integer(n_obs)
    )
  ),
  method_metadata = list(
    estimator = "local_linear_regression",
    vcov = "none"
  ),
  diagnostics = list()
)

write(toJSON(result, auto_unbox = TRUE, digits = 10, null = "null"), "result.json")
