library(forecast)
library(jsonlite)

data <- read.csv("./input.csv")
y <- data$y

fit <- Arima(y, order = c(1, 1, 1), include.constant = FALSE)

fc <- forecast(fit, h = 1, level = 95)

forecast_se <- as.numeric((fc$upper[1, 1] - fc$lower[1, 1]) / (2 * 1.96))

result <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = list(
    list(term = "forecast", estimate = as.numeric(fc$mean[1]), se = forecast_se, n_obs = length(y)),
    list(term = "lower_95", estimate = as.numeric(fc$lower[1, 1]), se = forecast_se, n_obs = length(y)),
    list(term = "upper_95", estimate = as.numeric(fc$upper[1, 1]), se = forecast_se, n_obs = length(y))
  ),
  method_metadata = list(estimator = "ARIMA(1,1,1) ML", vcov = "none"),
  diagnostics = list()
)

write(toJSON(result, auto_unbox = TRUE, digits = 10), "result.json")
