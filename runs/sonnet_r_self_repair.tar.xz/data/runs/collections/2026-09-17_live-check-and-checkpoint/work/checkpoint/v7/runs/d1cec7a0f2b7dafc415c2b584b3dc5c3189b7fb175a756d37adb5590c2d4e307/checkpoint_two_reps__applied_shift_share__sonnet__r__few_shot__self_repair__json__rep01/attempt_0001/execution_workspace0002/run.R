library(jsonlite)

df <- read.csv("input.csv")

# Normalize regional weights (one obs per region)
regions <- unique(df[, c("region_id", "region_weight", "x", "y")])
total_weight <- sum(regions$region_weight)
regions$e_r <- regions$region_weight / total_weight

# Merge normalized weights back into df
df <- merge(df, regions[, c("region_id", "e_r")], by = "region_id")

# Construct regional shift-share instrument z_r
df$weighted_share_shock <- df$share * df$shock
z_agg <- aggregate(weighted_share_shock ~ region_id, data = df, FUN = sum)
names(z_agg)[2] <- "z_r"
regions <- merge(regions, z_agg, by = "region_id")

# Weighted means
mean_y <- sum(regions$e_r * regions$y)
mean_x <- sum(regions$e_r * regions$x)
mean_z <- sum(regions$e_r * regions$z_r)

# Demeaned residuals
regions$y0 <- regions$y - mean_y
regions$x0 <- regions$x - mean_x
regions$z0 <- regions$z_r - mean_z

# Merge demeaned residuals (y0, x0, z0) into df - e_r already in df
df2 <- merge(df, regions[, c("region_id", "y0", "x0", "z0")], by = "region_id")

# s_n = sum_r e_r * share_rn
df2$e_share <- df2$e_r * df2$share
s_n <- aggregate(e_share ~ industry_id, data = df2, FUN = sum)
names(s_n)[2] <- "s_n"

df2 <- merge(df2, s_n, by = "industry_id")
df2$ey0 <- df2$e_r * df2$share * df2$y0 / df2$s_n
df2$ex0 <- df2$e_r * df2$share * df2$x0 / df2$s_n
df2$ez0 <- df2$e_r * df2$share * df2$z0 / df2$s_n

ybar <- aggregate(ey0 ~ industry_id, data = df2, FUN = sum)
xbar <- aggregate(ex0 ~ industry_id, data = df2, FUN = sum)
zbar <- aggregate(ez0 ~ industry_id, data = df2, FUN = sum)

shocks <- unique(df[, c("industry_id", "shock")])

agg <- merge(s_n, ybar, by = "industry_id")
agg <- merge(agg, xbar, by = "industry_id")
agg <- merge(agg, zbar, by = "industry_id")
agg <- merge(agg, shocks, by = "industry_id")
names(agg)[3:6] <- c("ybar", "xbar", "zbar", "shock_val")

N <- nrow(agg)
mass <- agg$s_n
shock_n <- agg$shock_val

shock_iv <- function(dependent, endogenous, instrument, weights, N) {
  regressors <- cbind(1, endogenous)
  instruments <- cbind(1, instrument)
  cross <- crossprod(instruments, weights * regressors)
  beta <- solve(cross, crossprod(instruments, weights * dependent))
  residual <- drop(dependent - regressors %*% beta)
  scores <- instruments * (weights * residual)
  inverse <- solve(cross)
  covariance <- N / (N - 2) * inverse %*% crossprod(scores) %*% t(inverse)
  c(slope = beta[2], se = sqrt(covariance[2, 2]))
}

effect <- shock_iv(agg$ybar, agg$xbar, shock_n, mass, N)
first_stage <- shock_iv(agg$xbar, agg$zbar, shock_n, mass, N)
effective_shocks <- 1 / sum(mass^2)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = unname(effect["slope"]), se = unname(effect["se"]), n_obs = as.integer(N)),
    list(term = "first_stage", estimate = unname(first_stage["slope"]), se = unname(first_stage["se"]), n_obs = as.integer(N)),
    list(term = "effective_shocks", estimate = effective_shocks, se = NULL, n_obs = as.integer(N))
  ),
  method_metadata = list(estimator = "shock-level IV (Borusyak-Hull-Jaravel)", vcov = "HC1"),
  diagnostics = setNames(list(), character(0))
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
