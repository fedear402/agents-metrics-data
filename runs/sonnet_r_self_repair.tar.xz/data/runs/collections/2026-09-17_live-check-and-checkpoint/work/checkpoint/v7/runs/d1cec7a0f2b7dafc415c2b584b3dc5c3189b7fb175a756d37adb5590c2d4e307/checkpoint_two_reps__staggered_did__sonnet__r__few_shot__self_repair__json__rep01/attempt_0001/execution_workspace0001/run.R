library(jsonlite)

df <- read.csv("./input.csv")

cohorts <- c(4, 6, 8)
never <- df[df$cohort == -1, ]

att_cells <- c()
n_cells <- 0

for (g in cohorts) {
  g_firms <- df[df$cohort == g, ]
  pre_year <- g - 1
  post_years <- (g):9
  
  mean_never_pre <- mean(never$y_did[never$year == pre_year])
  mean_g_pre <- mean(g_firms$y_did[g_firms$year == pre_year])
  
  for (t in post_years) {
    mean_g_t <- mean(g_firms$y_did[g_firms$year == t])
    mean_never_t <- mean(never$y_did[never$year == t])
    
    cell_att <- (mean_g_t - mean_g_pre) - (mean_never_t - mean_never_pre)
    att_cells <- c(att_cells, cell_att)
    n_cells <- n_cells + 1
  }
}

att_uniform <- mean(att_cells)

n_obs <- nrow(df[df$cohort %in% cohorts, ])

out <- list(
  task_id = "staggered_did",
  platform = "r",
  estimates = list(
    list(term = "att", estimate = att_uniform, se = NA, n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "ATT_uniform from group-year cell means, equal-weighted over cohort-time cells",
    vcov = "none"
  ),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "result.json", auto_unbox = TRUE)
