library(AER)
library(sandwich)
library(jsonlite)

# Read data
dat <- read.csv("input.csv")

# Get one obs per region for weights
regions <- unique(dat$region_id)
reg_dat <- dat[!duplicated(dat$region_id), c("region_id", "region_weight", "x", "y")]

# Normalize weights
reg_dat$e_r <- reg_dat$region_weight / sum(reg_dat$region_weight)

# Construct shift-share instrument z_r = sum_n share_rn * shock_n
# For each region, sum over industries
z_vals <- tapply(seq_len(nrow(dat)), dat$region_id, function(idx) {
  sum(dat$share[idx] * dat$shock[idx])
})
reg_dat$z <- z_vals[as.character(reg_dat$region_id)]

# Weighted means
wmean <- function(v, w) sum(v * w) / sum(w)

y_wm <- wmean(reg_dat$y, reg_dat$e_r)
x_wm <- wmean(reg_dat$x, reg_dat$e_r)
z_wm <- wmean(reg_dat$z, reg_dat$e_r)

# Demeaned residuals
reg_dat$y0 <- reg_dat$y - y_wm
reg_dat$x0 <- reg_dat$x - x_wm
reg_dat$z0 <- reg_dat$z - z_wm

# Get industry-level data: one shock per industry
industries <- unique(dat$industry_id)
N <- length(industries)

# For each industry n: s_n = sum_r e_r * share_rn
# vbar_n = sum_r e_r * share_rn * v0_r / s_n

# Merge e_r and residuals into main data
dat2 <- merge(dat, reg_dat[, c("region_id", "e_r", "y0", "x0", "z0")], by = "region_id")

ind_dat <- data.frame(industry_id = industries)

# Get shock per industry (constant within industry)
shock_vals <- tapply(dat2$shock, dat2$industry_id, function(v) v[1])
ind_dat$shock <- shock_vals[as.character(ind_dat$industry_id)]

# s_n
s_n_vals <- tapply(seq_len(nrow(dat2)), dat2$industry_id, function(idx) {
  sum(dat2$e_r[idx] * dat2$share[idx])
})
ind_dat$s_n <- s_n_vals[as.character(ind_dat$industry_id)]

# ybar_n, xbar_n, zbar_n
agg_var <- function(v0_col) {
  tapply(seq_len(nrow(dat2)), dat2$industry_id, function(idx) {
    sum(dat2$e_r[idx] * dat2$share[idx] * dat2[[v0_col]][idx])
  })
}

ybar_vals <- agg_var("y0")
xbar_vals <- agg_var("x0")
zbar_vals <- agg_var("z0")

ind_dat$ybar <- ybar_vals[as.character(ind_dat$industry_id)] / ind_dat$s_n
ind_dat$xbar <- xbar_vals[as.character(ind_dat$industry_id)] / ind_dat$s_n
ind_dat$zbar <- zbar_vals[as.character(ind_dat$industry_id)] / ind_dat$s_n

# Shock-level IV regression for effect:
# ybar_n ~ 1 + xbar_n, instrument xbar_n with shock_n, weights s_n
# HC1 with N/(N-2) multiplier

iv_effect <- ivreg(ybar ~ xbar | shock, data = ind_dat, weights = s_n)
vcov_effect <- vcovHC(iv_effect, type = "HC1")
se_effect <- sqrt(diag(vcov_effect))["xbar"]
coef_effect <- coef(iv_effect)["xbar"]

# First stage: x_r on z_r (regional), exposure-robust SE from shock-level
# Shock-level: xbar_n ~ zbar_n, instrument zbar_n with shock_n, weights s_n
iv_fs <- ivreg(xbar ~ zbar | shock, data = ind_dat, weights = s_n)
vcov_fs <- vcovHC(iv_fs, type = "HC1")
se_fs <- sqrt(diag(vcov_fs))["zbar"]
coef_fs <- coef(iv_fs)["zbar"]

# Effective shocks
eff_shocks <- 1 / sum(ind_dat$s_n^2)

# Build result
result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = as.numeric(coef_effect), se = as.numeric(se_effect), n_obs = as.integer(N)),
    list(term = "first_stage", estimate = as.numeric(coef_fs), se = as.numeric(se_fs), n_obs = as.integer(N)),
    list(term = "effective_shocks", estimate = as.numeric(eff_shocks), se = NULL, n_obs = as.integer(N))
  ),
  method_metadata = list(
    estimator = "2SLS shift-share with Borusyak-Hull-Jaravel exposure-robust SE",
    vcov = "HC1"
  ),
  diagnostics = list()
)

write(toJSON(result, auto_unbox = TRUE, digits = 10, null = "null"), "result.json")
