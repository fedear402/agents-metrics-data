library(sandwich)
library(lmtest)
library(jsonlite)

df <- read.csv("./input.csv")

# Local projection at horizon h=4
# y_{t+4} on shock_t and y_{t-1}
n <- nrow(df)
h <- 4

y_lead <- df$y[(h+1):n]        # y_{t+4}, t=1...(n-h)
shock  <- df$shock[1:(n-h)]    # shock_t
y_lag  <- df$y[1:(n-h) - 1]    # y_{t-1}

# y_lag needs index t-1, so t starts at 2
# adjust: t goes from 2 to n-h (so t+4 goes up to n-h+1 ... need t+4 <= n)
# t from 2 to n-h: y_{t-1}=df$y[t-1], shock=df$y[t], y_{t+4}=df$y[t+4]
# indices: t in 2:(n-h), so length = n-h-1

t_idx  <- 2:(n - h)
y_lead2 <- df$y[t_idx + h]
shock2  <- df$shock[t_idx]
y_lag2  <- df$y[t_idx - 1]

lp_df <- data.frame(y_lead = y_lead2, shock = shock2, y_lag = y_lag2)

fit <- lm(y_lead ~ shock + y_lag, data = lp_df)

# Newey-West SE with lag 4
nw_vcov <- NeweyWest(fit, lag = 4, prewhite = FALSE, adjust = TRUE)
ct <- coeftest(fit, vcov = nw_vcov)

est <- ct["shock", "Estimate"]
se  <- ct["shock", "Std. Error"]
n_obs <- nrow(lp_df)

out <- list(
  task_id = "lp_irf",
  platform = "r",
  estimates = list(
    list(term = "irf_h4", estimate = unname(est), se = unname(se), n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "Local Projection OLS h=4",
    vcov = "Newey-West lag=4"
  ),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "./result.json", auto_unbox = TRUE)
