library(vars)
library(jsonlite)

dat <- read.csv("./input.csv")
y <- dat[, c("y1", "y2")]

var_fit <- VAR(y, p = 2, type = "const")

irf_res <- irf(var_fit, impulse = "y2", response = "y1",
               n.ahead = 4, ortho = TRUE, boot = FALSE)

irf_val <- irf_res$irf$y2[5, "y1"]

n_obs <- nrow(y)

out <- list(
  task_id = "var_irf",
  platform = "r",
  estimates = list(
    list(term = "irf_y1_to_y2_h4", estimate = unname(irf_val), se = NULL, n_obs = n_obs)
  ),
  method_metadata = list(estimator = "VAR(2) with constant, Cholesky IRF", vcov = "Cholesky"),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "./result.json", auto_unbox = TRUE, null = "null")
