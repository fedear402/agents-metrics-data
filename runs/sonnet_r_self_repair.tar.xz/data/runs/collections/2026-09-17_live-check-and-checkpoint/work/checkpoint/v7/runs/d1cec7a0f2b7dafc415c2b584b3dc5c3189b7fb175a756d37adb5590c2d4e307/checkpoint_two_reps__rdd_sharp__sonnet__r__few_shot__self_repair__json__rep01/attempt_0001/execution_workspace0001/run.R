library(jsonlite)

df <- read.csv("./input.csv")

cutoff <- 0
h <- 0.5

df$dist <- df$z - cutoff
df$in_bw <- abs(df$dist) <= h
df_bw <- df[df$in_bw, ]

# Triangular kernel weights
df_bw$kw <- (1 - abs(df_bw$dist) / h)

# Left side: dist < 0
left <- df_bw[df_bw$dist < 0, ]
fit_left <- lm(y ~ dist, data = left, weights = left$kw)

# Right side: dist >= 0
right <- df_bw[df_bw$dist >= 0, ]
fit_right <- lm(y ~ dist, data = right, weights = right$kw)

intercept_left <- coef(fit_left)[["(Intercept)"]]
intercept_right <- coef(fit_right)[["(Intercept)"]]

late <- intercept_right - intercept_left
n_obs <- nrow(df_bw)

out <- list(
  task_id = "rdd_sharp",
  platform = "r",
  estimates = list(
    list(term = "late", estimate = late, se = NA, n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "Local linear regression with triangular kernel, bandwidth 0.5",
    vcov = "none"
  ),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "./result.json", auto_unbox = TRUE)
