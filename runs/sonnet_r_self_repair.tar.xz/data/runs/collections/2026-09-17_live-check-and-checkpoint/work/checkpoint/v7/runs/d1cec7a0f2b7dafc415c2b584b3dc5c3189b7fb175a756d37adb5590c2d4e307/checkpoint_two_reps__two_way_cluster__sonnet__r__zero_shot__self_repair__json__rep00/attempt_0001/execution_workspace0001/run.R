library(sandwich)
library(lmtest)
library(jsonlite)

data <- read.csv("./input.csv")

fit <- lm(y_twocluster ~ x, data = data)

# Cameron-Gelbach-Miller two-way cluster-robust SE
cluster_vcov <- function(model, cluster1, cluster2) {
  X <- model.matrix(model)
  e <- residuals(model)
  n <- nrow(X)
  
  meat_cluster <- function(cl) {
    cl_levels <- unique(cl)
    m <- length(cl_levels)
    meat <- matrix(0, ncol(X), ncol(X))
    for (g in cl_levels) {
      idx <- which(cl == g)
      Xg <- X[idx, , drop = FALSE]
      eg <- e[idx]
      score_g <- colSums(Xg * eg)
      meat <- meat + outer(score_g, score_g)
    }
    bread <- solve(crossprod(X))
    m / (m - 1) * (n - 1) / (n - ncol(X)) * bread %*% meat %*% bread
  }
  
  V1 <- cluster_vcov_single <- function(cl) {
    cl_levels <- unique(cl)
    m <- length(cl_levels)
    bread <- solve(crossprod(X))
    meat <- matrix(0, ncol(X), ncol(X))
    for (g in cl_levels) {
      idx <- which(cl == g)
      Xg <- X[idx, , drop = FALSE]
      eg <- e[idx]
      score_g <- colSums(Xg * eg)
      meat <- meat + outer(score_g, score_g)
    }
    m / (m - 1) * (n - 1) / (n - ncol(X)) * bread %*% meat %*% bread
  }
  
  V_c1 <- V1(cluster1)
  V_c2 <- V1(cluster2)
  
  # Intersection cluster (firm-year pairs)
  cl_int <- paste(cluster1, cluster2, sep = "_")
  V_int <- V1(cl_int)
  
  V_cgm <- V_c1 + V_c2 - V_int
  V_cgm
}

V <- cluster_vcov(fit, data$firm, data$year)

coef_names <- names(coef(fit))
estimates_vec <- coef(fit)
se_vec <- sqrt(diag(V))

n_obs <- nrow(data)

result <- list(
  task_id = "two_way_cluster",
  platform = "r",
  estimates = list(
    list(term = "const", estimate = unname(estimates_vec["(Intercept)"]),
         se = unname(se_vec["(Intercept)"]), n_obs = n_obs),
    list(term = "x", estimate = unname(estimates_vec["x"]),
         se = unname(se_vec["x"]), n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "OLS",
    vcov = "Cameron-Gelbach-Miller two-way cluster-robust (firm, year)"
  ),
  diagnostics = setNames(list(), character(0))
)

write(toJSON(result, auto_unbox = TRUE, digits = 10), "result.json")
