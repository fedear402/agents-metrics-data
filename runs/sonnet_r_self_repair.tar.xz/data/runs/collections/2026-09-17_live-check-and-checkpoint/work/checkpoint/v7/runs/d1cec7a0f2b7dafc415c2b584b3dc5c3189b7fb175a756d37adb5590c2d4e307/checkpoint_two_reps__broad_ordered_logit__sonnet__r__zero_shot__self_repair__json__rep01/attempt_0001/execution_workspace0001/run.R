library(MASS)
library(jsonlite)

data <- read.csv("input.csv")

model <- polr(factor(y, levels = c(1, 2, 3), ordered = TRUE) ~ x + z,
              data = data, method = "logistic", Hess = TRUE)

coef_summary <- summary(model)$coefficients
n_obs <- nrow(data)

x_est <- coef_summary["x", "Value"]
x_se <- coef_summary["x", "Std. Error"]
z_est <- coef_summary["z", "Value"]
z_se <- coef_summary["z", "Std. Error"]

newdata <- data.frame(x = 1, z = 0)
pred_probs <- predict(model, newdata = newdata, type = "probs")
prob_high <- as.numeric(pred_probs[3])

result <- list(
  task_id = "broad_ordered_logit",
  platform = "r",
  estimates = list(
    list(term = "x", estimate = x_est, se = x_se, n_obs = n_obs),
    list(term = "z", estimate = z_est, se = z_se, n_obs = n_obs),
    list(term = "prob_high", estimate = prob_high, se = NULL, n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "ordered logit (polr)",
    vcov = "observed information (default polr)"
  ),
  diagnostics = list()
)

write(toJSON(result, auto_unbox = TRUE, digits = 10, null = "null"), "result.json")
