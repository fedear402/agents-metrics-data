library(jsonlite)

data <- read.csv("input.csv", stringsAsFactors = FALSE)
data <- data[order(as.Date(data$date)), ]

data$log_sales <- log(data$sales)
data$log_vix <- log(data$vix)
data$vix_change <- c(NA, diff(data$log_vix))

n_lags <- 15
for (j in 1:n_lags) {
  data[[paste0("lag_", j)]] <- c(rep(NA, j), head(data$vix_change, -j))
}

lag_vars <- paste0("lag_", 1:n_lags)
complete_cols <- c("log_sales", lag_vars)
sample <- data[complete.cases(data[, complete_cols]), ]

formula_str <- paste("log_sales ~", paste(lag_vars, collapse = " + "))
fit <- lm(as.formula(formula_str), data = sample)

X <- model.matrix(fit)
resids <- residuals(fit)
N <- nrow(X)
p <- ncol(X)  # 16: intercept + 15 lags

scores <- X * resids
hac_lags <- 15
meat <- crossprod(scores)
for (j in seq_len(hac_lags)) {
  w <- 1 - j / (hac_lags + 1)
  lag_product <- crossprod(scores[(j+1):N, , drop=FALSE], scores[1:(N-j), , drop=FALSE])
  meat <- meat + w * (lag_product + t(lag_product))
}

bread <- solve(crossprod(X))
covariance <- (N / (N - p)) * bread %*% meat %*% bread

coefs <- coef(fit)

# cumulative response: sum of lag_1 through lag_15 coefficients
contrast <- c(0, rep(1, 15))
cumulative <- sum(contrast * coefs)
cumulative_se <- sqrt(drop(t(contrast) %*% covariance %*% contrast))

lag1_est <- coefs["lag_1"]
lag1_se <- sqrt(covariance["lag_1", "lag_1"])

lag15_est <- coefs["lag_15"]
lag15_se <- sqrt(covariance["lag_15", "lag_15"])

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(term = "cumulative_response", estimate = unname(cumulative), se = unname(cumulative_se), n_obs = as.integer(N)),
    list(term = "lag_1", estimate = unname(lag1_est), se = unname(lag1_se), n_obs = as.integer(N)),
    list(term = "lag_15", estimate = unname(lag15_est), se = unname(lag15_se), n_obs = as.integer(N))
  ),
  method_metadata = list(
    estimator = "OLS",
    vcov = "Newey-West HAC, Bartlett kernel, max lag 15, correction N/(N-16)"
  ),
  diagnostics = setNames(list(), character(0))
)

write_json(result, "result.json", auto_unbox = TRUE, digits = 16, pretty = TRUE)
