library(jsonlite)

d <- read.csv("input.csv")
n <- nrow(d)

y <- d$y
endog <- d$endog
x <- d$x
z1 <- d$z1
z2 <- d$z2

q <- 2L
df <- n - 4L
critical <- qf(0.95, q, df)
k <- q * critical / df

# Unrestricted: regress y on intercept, x, z1, z2 (for a given beta, regress y-beta*endog)
# But we need residuals as functions of beta
# Let's compute the pieces:
# For restricted (no z1, z2): regress transformed on intercept + x
# For unrestricted: regress transformed on intercept + x + z1 + z2

# AR condition: F(beta) <= critical
# Equivalently: SSR_R(beta) - (1 + k)*SSR_U(beta) <= 0
# where SSR is sum of squared residuals

# Let M_r = annihilator of [1, x] (restricted)
# Let M_u = annihilator of [1, x, z1, z2] (unrestricted)

# SSR_R(beta) = ||M_r (y - beta*endog)||^2
# SSR_U(beta) = ||M_u (y - beta*endog)||^2

# M_r y, M_r endog, M_u y, M_u endog
X_r <- cbind(1, x)
X_u <- cbind(1, x, z1, z2)

Mr_y <- residuals(lm(y ~ x))
Mr_e <- residuals(lm(endog ~ x))
Mu_y <- residuals(lm(y ~ x + z1 + z2))
Mu_e <- residuals(lm(endog ~ x + z1 + z2))

# SSR_R(beta) = sum((Mr_y - beta*Mr_e)^2)
# SSR_U(beta) = sum((Mu_y - beta*Mu_e)^2)

# Condition: SSR_R - (1+k)*SSR_U <= 0
# A*beta^2 + B*beta + C <= 0

A <- sum(Mr_e^2) - (1+k)*sum(Mu_e^2)
B <- -2*(sum(Mr_y*Mr_e) - (1+k)*sum(Mu_y*Mu_e))
C <- sum(Mr_y^2) - (1+k)*sum(Mu_y^2)

disc <- B^2 - 4*A*C
bounds <- sort(Re(polyroot(c(C, B, A))))

accepts <- function(beta) A*beta^2 + B*beta + C <= 0

unbounded <- as.integer(A < 0)

# ar_f_at_one
beta1 <- 1.0
transformed1 <- y - beta1 * endog
restricted_fit1 <- lm(transformed1 ~ x)
full_fit1 <- lm(transformed1 ~ x + z1 + z2)
ar_f_1 <- ((deviance(restricted_fit1) - deviance(full_fit1)) / q) / (deviance(full_fit1) / df)

rows <- list(
  list(term="boundary_low", estimate=unname(bounds[1]), se=NULL, n_obs=n),
  list(term="boundary_high", estimate=unname(bounds[2]), se=NULL, n_obs=n),
  list(term="accepts_zero", estimate=unname(as.integer(accepts(0))), se=NULL, n_obs=n),
  list(term="unbounded", estimate=unname(unbounded), se=NULL, n_obs=n),
  list(term="ar_f_at_one", estimate=unname(ar_f_1), se=NULL, n_obs=n)
)

result <- list(
  task_id="broad_ar_confidence_set",
  platform="r",
  estimates=rows,
  method_metadata=list(estimator="Anderson-Rubin inversion", vcov="homoskedastic"),
  diagnostics=list()
)

write_json(result, "result.json", auto_unbox=TRUE, null="null", digits=16, pretty=TRUE)
