library(sandwich)
library(jsonlite)

df <- read.csv("input.csv", stringsAsFactors = FALSE)
df <- df[order(df$date), ]

df$log_sales <- log(df$sales)
df$log_vix <- log(df$vix)
df$d_log_vix <- c(NA, diff(df$log_vix))

for (k in 1:15) {
  df[[paste0("lag_", k)]] <- c(rep(NA, k), df$d_log_vix[1:(nrow(df) - k)])
}

lag_cols <- paste0("lag_", 1:15)
complete_rows <- complete.cases(df[, c("log_sales", lag_cols)])
df_reg <- df[complete_rows, ]

N <- nrow(df_reg)

formula_str <- paste("log_sales ~", paste(lag_cols, collapse = " + "))
model <- lm(as.formula(formula_str), data = df_reg)

# Compute Newey-West HAC manually with Bartlett weights 1-j/16, max lag 15
# then scale by N/(N-16)

X <- model.matrix(model)
e <- residuals(model)
n <- nrow(X)
k <- ncol(X)

# Meat of the sandwich
# S = X'ee'X with HAC weights
Xe <- X * e

# Compute the meat with Bartlett kernel weights 1 - j/16 for j = 1..15
meat <- t(Xe) %*% Xe  # j=0 term

for (j in 1:15) {
  w <- 1 - j/16
  gamma_j <- t(Xe[(j+1):n, , drop=FALSE]) %*% Xe[1:(n-j), , drop=FALSE]
  meat <- meat + w * (gamma_j + t(gamma_j))
}

# Bread
bread <- solve(t(X) %*% X)

# Raw NW vcov (like sandwich without any finite sample correction)
nw_vcov_raw <- bread %*% meat %*% bread

# Scale by N/(N-16)
scale_factor <- N / (N - 16)
nw_vcov <- nw_vcov_raw * scale_factor

# Set row/col names
rownames(nw_vcov) <- colnames(nw_vcov) <- colnames(X)

coefs <- coef(model)

lag_coef_names <- paste0("lag_", 1:15)
cum_response <- sum(coefs[lag_coef_names])

grad <- rep(0, length(coefs))
names(grad) <- names(coefs)
grad[lag_coef_names] <- 1

se_cum <- sqrt(as.numeric(t(grad) %*% nw_vcov %*% grad))
se_lag1 <- sqrt(nw_vcov["lag_1", "lag_1"])
se_lag15 <- sqrt(nw_vcov["lag_15", "lag_15"])

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(term = "cumulative_response", estimate = as.numeric(cum_response), se = as.numeric(se_cum), n_obs = as.integer(N)),
    list(term = "lag_1", estimate = as.numeric(coefs["lag_1"]), se = as.numeric(se_lag1), n_obs = as.integer(N)),
    list(term = "lag_15", estimate = as.numeric(coefs["lag_15"]), se = as.numeric(se_lag15), n_obs = as.integer(N))
  ),
  method_metadata = list(
    estimator = "OLS",
    vcov = "Newey-West HAC, max lag 15, Bartlett weights 1-j/16, scaled by N/(N-16)"
  ),
  diagnostics = setNames(list(), character(0))
)

write(toJSON(result, auto_unbox = TRUE, digits = 10), "result.json")
