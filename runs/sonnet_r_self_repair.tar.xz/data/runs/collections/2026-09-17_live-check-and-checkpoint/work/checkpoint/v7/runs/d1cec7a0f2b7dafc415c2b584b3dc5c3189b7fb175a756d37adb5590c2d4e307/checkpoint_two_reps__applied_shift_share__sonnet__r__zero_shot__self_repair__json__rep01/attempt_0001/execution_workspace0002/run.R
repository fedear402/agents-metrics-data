library(AER)
library(sandwich)
library(jsonlite)

dat <- read.csv("input.csv", stringsAsFactors = FALSE)

# One obs per region
regions <- dat[!duplicated(dat$region_id), c("region_id", "region_weight", "x", "y")]
regions$e_r <- regions$region_weight / sum(regions$region_weight)

# Construct shift-share instrument z_r = sum_n share_rn * shock_n
# shock is in dat already
z_list <- tapply(dat$share * dat$shock, dat$region_id, sum)
z_df <- data.frame(region_id = names(z_list), z = as.numeric(z_list), stringsAsFactors = FALSE)
regions <- merge(regions, z_df, by = "region_id")

# Weighted means
e <- regions$e_r
wmean <- function(v, w) sum(v * w) / sum(w)

mean_y <- wmean(regions$y, e)
mean_x <- wmean(regions$x, e)
mean_z <- wmean(regions$z, e)

regions$y0 <- regions$y - mean_y
regions$x0 <- regions$x - mean_x
regions$z0 <- regions$z - mean_z

# Industry-level aggregation
dat3 <- merge(dat, regions[, c("region_id", "e_r", "y0", "x0", "z0")], by = "region_id")
dat3$e_share <- dat3$e_r * dat3$share

industries <- unique(dat3$industry_id)

agg <- lapply(industries, function(n) {
  sub <- dat3[dat3$industry_id == n, ]
  s_n <- sum(sub$e_share)
  ybar_n <- sum(sub$e_share * sub$y0) / s_n
  xbar_n <- sum(sub$e_share * sub$x0) / s_n
  zbar_n <- sum(sub$e_share * sub$z0) / s_n
  shock_n <- sub$shock[1]
  data.frame(industry_id = n, s_n = s_n, ybar = ybar_n, xbar = xbar_n, zbar = zbar_n, shock_n = shock_n)
})
agg_df <- do.call(rbind, agg)

N <- nrow(agg_df)

# --- Effect: shock-level IV of ybar on xbar, instrument = shock_n, weights = s_n ---
iv_effect <- ivreg(ybar ~ xbar | shock_n, data = agg_df, weights = s_n)
beta_effect <- coef(iv_effect)["xbar"]
vc_effect <- vcovHC(iv_effect, type = "HC1")
se_effect <- sqrt(vc_effect["xbar", "xbar"])

# --- First stage: shock-level IV of xbar on zbar, instrument = shock_n, weights = s_n ---
iv_fs <- ivreg(xbar ~ zbar | shock_n, data = agg_df, weights = s_n)
beta_fs <- coef(iv_fs)["zbar"]
vc_fs <- vcovHC(iv_fs, type = "HC1")
se_fs <- sqrt(vc_fs["zbar", "zbar"])

# --- Effective shocks ---
eff_shocks <- 1 / sum(agg_df$s_n^2)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = as.numeric(beta_effect), se = as.numeric(se_effect), n_obs = as.integer(N)),
    list(term = "first_stage", estimate = as.numeric(beta_fs), se = as.numeric(se_fs), n_obs = as.integer(N)),
    list(term = "effective_shocks", estimate = as.numeric(eff_shocks), se = NULL, n_obs = as.integer(N))
  ),
  method_metadata = list(
    estimator = "2SLS shift-share with exposure-robust SE",
    vcov = "HC1 shock-level"
  ),
  diagnostics = list()
)

write(toJSON(result, auto_unbox = TRUE, digits = 10, null = "null"), "result.json")
