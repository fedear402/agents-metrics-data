library(sandwich)
library(jsonlite)

df <- read.csv("input.csv", stringsAsFactors = FALSE)
df <- df[order(df$date), ]

df$log_sales <- log(df$sales)
df$log_vix <- log(df$vix)
df$d_log_vix <- c(NA, diff(df$log_vix))

for (k in 1:15) {
  df[[paste0("lag_", k)]] <- c(rep(NA, k), df$d_log_vix[1:(nrow(df) - k)])
}

lag_cols <- paste0("lag_", 1:15)
df_reg <- df[complete.cases(df[, c("log_sales", lag_cols)]), ]

N <- nrow(df_reg)

formula_str <- paste("log_sales ~", paste(lag_cols, collapse = " + "))
model <- lm(as.formula(formula_str), data = df_reg)

# Newey-West with max lag 15, Bartlett weights 1 - j/16
# sandwich::NeweyWest with prewhite=FALSE, adjust=FALSE gives standard NW
# We need weights 1 - j/16 for j=1..15, which is the standard Bartlett kernel with bandwidth=16
# sandwich::lrvar / NeweyWest uses bandwidth parameter
# NeweyWest with lag=15 uses bandwidth=16 (lag+1) with Bartlett weights 1-j/(lag+1)
nw_vcov <- NeweyWest(model, lag = 15, prewhite = FALSE, adjust = FALSE)

# Multiply by N/(N-16)
nw_vcov_adj <- nw_vcov * (N / (N - 16))

coefs <- coef(model)

# lag coefficients (intercept is index 1, lag_1 is index 2, ..., lag_15 is index 16)
lag_names <- paste0("lag_", 1:15)
lag_coefs <- coefs[lag_names]

cumulative_response <- sum(lag_coefs)

# Variance of cumulative response: sum of all elements in the submatrix of lag coefficients
vcov_lags <- nw_vcov_adj[lag_names, lag_names]
var_cumulative <- sum(vcov_lags)
se_cumulative <- sqrt(var_cumulative)

se_lag1 <- sqrt(nw_vcov_adj["lag_1", "lag_1"])
se_lag15 <- sqrt(nw_vcov_adj["lag_15", "lag_15"])

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(term = "cumulative_response", estimate = as.numeric(cumulative_response), se = as.numeric(se_cumulative), n_obs = as.integer(N)),
    list(term = "lag_1", estimate = as.numeric(lag_coefs["lag_1"]), se = as.numeric(se_lag1), n_obs = as.integer(N)),
    list(term = "lag_15", estimate = as.numeric(lag_coefs["lag_15"]), se = as.numeric(se_lag15), n_obs = as.integer(N))
  ),
  method_metadata = list(
    estimator = "OLS",
    vcov = "Newey-West HAC, max lag 15, Bartlett weights 1-j/16, scaled by N/(N-16)"
  ),
  diagnostics = list()
)

write(toJSON(result, auto_unbox = TRUE, digits = 10), "result.json")
