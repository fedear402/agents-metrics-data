library(jsonlite)

df <- read.csv("./input.csv")

cohorts <- c(4, 6, 8)
never <- df[df$cohort == -1, ]

att_cells <- c()

for (g in cohorts) {
  treated <- df[df$cohort == g, ]
  post_years <- (g):9
  
  # baseline year for this cohort: year = g - 1
  baseline_year <- g - 1
  
  # never-treated baseline
  nt_baseline <- mean(never$y_did[never$year == baseline_year])
  
  # treated baseline
  tr_baseline <- mean(treated$y_did[treated$year == baseline_year])
  
  for (t in post_years) {
    # never-treated at time t
    nt_t <- mean(never$y_did[never$year == t])
    
    # treated at time t
    tr_t <- mean(treated$y_did[treated$year == t])
    
    att_cell <- (tr_t - tr_baseline) - (nt_t - nt_baseline)
    att_cells <- c(att_cells, att_cell)
  }
}

att_uniform <- mean(att_cells)

# n_obs: total observations for treated cohorts 4,6,8 in post-treatment periods
n_obs <- 0
for (g in cohorts) {
  post_years <- g:9
  n_obs <- n_obs + nrow(df[df$cohort == g & df$year %in% post_years, ])
}

result <- list(
  task_id = "staggered_did",
  platform = "r",
  estimates = list(
    list(term = "att", estimate = att_uniform, se = NULL, n_obs = as.integer(n_obs))
  ),
  method_metadata = list(
    estimator = "Callaway-Sant'Anna-style ATT_uniform via group-year means",
    vcov = "none"
  ),
  diagnostics = setNames(list(), character(0))
)

write(toJSON(result, auto_unbox = TRUE, null = "null", digits = 10), "./result.json")
