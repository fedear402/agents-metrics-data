library(survival)
library(jsonlite)

d <- read.csv("input.csv")
n <- nrow(d)

fit <- survreg(Surv(y, y > 0, type = "left") ~ x + z,
               data = d, dist = "gaussian",
               control = survreg.control(rel.tolerance = 1e-12))

V <- vcov(fit)
coefs <- coef(fit)

result <- list(
  task_id = "broad_tobit",
  platform = "r",
  estimates = list(
    list(term = "const", estimate = unname(coefs["(Intercept)"]), se = sqrt(V["(Intercept)", "(Intercept)"]), n_obs = n),
    list(term = "x",     estimate = unname(coefs["x"]),           se = sqrt(V["x", "x"]),                   n_obs = n),
    list(term = "z",     estimate = unname(coefs["z"]),           se = sqrt(V["z", "z"]),                   n_obs = n),
    list(term = "sigma", estimate = unname(fit$scale),            se = NULL,                                n_obs = n)
  ),
  method_metadata = list(
    estimator = "survreg Gaussian left-censored Tobit",
    vcov = "observed information (survreg vcov)"
  ),
  diagnostics = setNames(list(), character(0))
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
