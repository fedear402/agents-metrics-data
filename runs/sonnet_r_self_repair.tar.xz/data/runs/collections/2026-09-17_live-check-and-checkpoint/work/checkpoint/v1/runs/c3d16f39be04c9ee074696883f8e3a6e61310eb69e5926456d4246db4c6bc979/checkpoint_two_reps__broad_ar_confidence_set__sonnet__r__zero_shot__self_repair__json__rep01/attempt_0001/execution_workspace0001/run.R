library(jsonlite)

data <- read.csv("input.csv")
n <- nrow(data)
y <- data$y
endog <- data$endog
x <- data$x
z1 <- data$z1
z2 <- data$z2

ar_f <- function(beta) {
  y_adj <- y - beta * endog
  fit <- lm(y_adj ~ x + z1 + z2)
  fit_r <- lm(y_adj ~ x)
  rss_r <- sum(residuals(fit_r)^2)
  rss_u <- sum(residuals(fit)^2)
  f <- ((rss_r - rss_u) / 2) / (rss_u / (n - 4))
  return(f)
}

crit <- qf(0.95, 2, n - 4)

ar_f_at_one <- ar_f(1)

# Find roots of ar_f(beta) - crit = 0
# The AR function in beta is a ratio of quadratics, resulting in a quadratic in beta
# Let's find the boundary points analytically or numerically

# Scan a wide range first
beta_grid <- seq(-1000, 1000, by = 0.01)
f_vals <- sapply(beta_grid, ar_f)
diff_vals <- f_vals - crit

# Find sign changes
sign_changes <- which(diff(sign(diff_vals)) != 0)

roots <- c()
for (i in sign_changes) {
  root <- tryCatch(
    uniroot(function(b) ar_f(b) - crit, interval = c(beta_grid[i], beta_grid[i+2]))$root,
    error = function(e) NULL
  )
  if (!is.null(root)) roots <- c(roots, root)
}

roots <- sort(unique(round(roots, 8)))

# Check if there are exactly 2 finite boundary points
boundary_low <- min(roots)
boundary_high <- max(roots)

# Check accepts_zero
accepts_zero <- as.numeric(ar_f(0) <= crit)

# Check unbounded: test at very large/small beta values
f_large_pos <- ar_f(1e6)
f_large_neg <- ar_f(-1e6)
unbounded <- as.numeric(f_large_pos <= crit | f_large_neg <= crit)

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = list(
    list(term = "boundary_low", estimate = boundary_low, se = NULL, n_obs = n),
    list(term = "boundary_high", estimate = boundary_high, se = NULL, n_obs = n),
    list(term = "accepts_zero", estimate = accepts_zero, se = NULL, n_obs = n),
    list(term = "unbounded", estimate = unbounded, se = NULL, n_obs = n),
    list(term = "ar_f_at_one", estimate = ar_f_at_one, se = NULL, n_obs = n)
  ),
  method_metadata = list(
    estimator = "Anderson-Rubin test inversion",
    vcov = "homoskedastic"
  ),
  diagnostics = list()
)

write(toJSON(result, auto_unbox = TRUE, digits = 10, null = "null"), "result.json")
