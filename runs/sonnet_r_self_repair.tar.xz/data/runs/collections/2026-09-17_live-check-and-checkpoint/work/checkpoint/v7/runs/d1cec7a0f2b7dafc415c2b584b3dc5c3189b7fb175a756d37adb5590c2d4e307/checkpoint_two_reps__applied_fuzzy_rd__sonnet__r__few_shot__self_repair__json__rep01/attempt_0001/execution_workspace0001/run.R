library(jsonlite)

data <- read.csv("input.csv")
names(data) <- trimws(names(data))

bw <- 1
in_bw <- abs(data$score) < bw
df <- data[in_bw, ]
n_obs <- nrow(df)

df$w <- 1 - abs(df$score)
df$above <- as.integer(df$score >= 0)
df$score_left <- df$score * (1 - df$above)
df$score_right <- df$score * df$above

X <- cbind(1, df$above, df$score_left, df$score_right)
W <- df$w
Y_earn <- df$earnings
Y_part <- df$participated

bread <- solve(crossprod(X, W * X))

coef_earn <- bread %*% crossprod(X, W * Y_earn)
coef_part <- bread %*% crossprod(X, W * Y_part)

resid_earn <- Y_earn - X %*% coef_earn
resid_part <- Y_part - X %*% coef_part

contrast <- c(0, 1, 0, 0)

jump_earn <- drop(contrast %*% coef_earn)
jump_part <- drop(contrast %*% coef_part)

loading <- W * drop(X %*% bread %*% contrast)

inf_earn <- loading * resid_earn
inf_part <- loading * resid_part

influence <- cbind(inf_earn, inf_part)
joint <- crossprod(influence)

se_earn <- sqrt(joint[1, 1])
se_part <- sqrt(joint[2, 2])
cov_ep <- joint[1, 2]

ratio <- jump_earn / jump_part
grad <- c(1 / jump_part, -jump_earn / jump_part^2)
se_ratio <- sqrt(drop(t(grad) %*% joint %*% grad))

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = unname(ratio), se = unname(se_ratio), n_obs = as.integer(n_obs)),
    list(term = "reduced_form", estimate = unname(jump_earn), se = unname(se_earn), n_obs = as.integer(n_obs)),
    list(term = "first_stage", estimate = unname(jump_part), se = unname(se_part), n_obs = as.integer(n_obs))
  ),
  method_metadata = list(
    estimator = "fuzzy_RD_local_linear_delta_method",
    vcov = "HC0"
  ),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
