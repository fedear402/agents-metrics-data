library(sandwich)
library(lmtest)
library(jsonlite)

df <- read.csv("./input.csv")

fit <- lm(y_twocluster ~ x, data = df)

vcov_twoway <- vcovCL(fit, cluster = ~ firm + year, type = "HC1", multi0 = TRUE)

co <- coeftest(fit, vcov = vcov_twoway)

n_obs <- nrow(df)

out <- list(
  task_id = "two_way_cluster",
  platform = "r",
  estimates = list(
    list(term = "const", estimate = unname(co["(Intercept)", "Estimate"]),
         se = unname(co["(Intercept)", "Std. Error"]), n_obs = n_obs),
    list(term = "x", estimate = unname(co["x", "Estimate"]),
         se = unname(co["x", "Std. Error"]), n_obs = n_obs)
  ),
  method_metadata = list(estimator = "OLS", vcov = "two-way cluster-robust (Cameron-Gelbach-Miller)"),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "result.json", auto_unbox = TRUE, digits = 10)
