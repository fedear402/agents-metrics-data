library(sandwich)
library(jsonlite)

dat <- read.csv("input.csv")
names(dat) <- trimws(names(dat))

# Apply bandwidth and triangular weights
bw <- 1
dat <- dat[abs(dat$score) < bw, ]
dat$w <- 1 - abs(dat$score)
dat$above <- as.integer(dat$score >= 0)
n_obs <- nrow(dat)

# Fit reduced form: earnings ~ above + score + above:score
rf_fit <- lm(earnings ~ above + score + above:score, data = dat, weights = w)
# Fit first stage: participated ~ above + score + above:score
fs_fit <- lm(participated ~ above + score + above:score, data = dat, weights = w)

# HC0 robust vcov (no df correction)
vcov_rf <- vcovHC(rf_fit, type = "HC0")
vcov_fs <- vcovHC(fs_fit, type = "HC0")

# The discontinuity is the coefficient on 'above' (intercept jump at score=0)
rf_est <- coef(rf_fit)["above"]
fs_est <- coef(fs_fit)["above"]
rf_se <- sqrt(vcov_rf["above", "above"])
fs_se <- sqrt(vcov_fs["above", "above"])

# Treatment effect via delta method: te = rf / fs
te_est <- rf_est / fs_est

# For delta method, need joint covariance of (rf_disc, fs_disc)
# Stack residuals to get cross-covariance
# Use meat of sandwich estimator jointly
X_rf <- model.matrix(rf_fit)
X_fs <- model.matrix(fs_fit)
w_vec <- dat$w

e_rf <- residuals(rf_fit)
e_fs <- residuals(fs_fit)

# Weighted residuals
we_rf <- w_vec * e_rf
we_fs <- w_vec * e_fs

# Bread matrices (XtWX)^{-1}
bread_rf <- solve(t(X_rf) %*% (X_rf * w_vec))
bread_fs <- solve(t(X_fs) %*% (X_fs * w_vec))

# Cross meat: sum_i (X_rf_i * we_rf_i) * (X_fs_i * we_fs_i)^T
# For the covariance between rf "above" coef and fs "above" coef
# We need the (above, above) element of bread_rf %*% cross_meat %*% bread_fs^T

# Cross meat matrix
cross_meat <- t(X_rf * we_rf) %*% (X_fs * we_fs)

# Full cross-vcov matrix
cross_vcov <- bread_rf %*% cross_meat %*% t(bread_fs)

# Covariance between rf[above] and fs[above]
cov_rf_fs <- cross_vcov["above", "above"]

# Delta method: Var(rf/fs) = (1/fs)^2 * Var(rf) + (rf/fs^2)^2 * Var(fs) - 2*(rf/fs^3)*Cov(rf,fs)
var_rf <- vcov_rf["above", "above"]
var_fs <- vcov_fs["above", "above"]

var_te <- (1/fs_est)^2 * var_rf + (rf_est/fs_est^2)^2 * var_fs - 2*(rf_est/fs_est^3)*cov_rf_fs
te_se <- sqrt(var_te)

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = unname(te_est), se = unname(te_se), n_obs = n_obs),
    list(term = "reduced_form", estimate = unname(rf_est), se = unname(rf_se), n_obs = n_obs),
    list(term = "first_stage", estimate = unname(fs_est), se = unname(fs_se), n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "fuzzy_rd_local_linear_wald",
    vcov = "HC0"
  ),
  diagnostics = list()
)

write(toJSON(result, auto_unbox = TRUE, digits = 10), "result.json")
