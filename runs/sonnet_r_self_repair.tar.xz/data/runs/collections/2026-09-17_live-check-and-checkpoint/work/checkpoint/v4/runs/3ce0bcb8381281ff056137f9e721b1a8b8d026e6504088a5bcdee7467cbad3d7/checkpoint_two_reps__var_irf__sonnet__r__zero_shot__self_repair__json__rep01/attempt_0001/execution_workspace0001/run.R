library(vars)
library(jsonlite)

data <- read.csv("./input.csv")
y <- data[, c("y1", "y2")]

var_model <- VAR(y, p = 2, type = "const")

irf_result <- irf(var_model, impulse = "y2", response = "y1", n.ahead = 4,
                  ortho = TRUE, boot = FALSE)

irf_y1_to_y2_h4 <- irf_result$irf$y2[5, "y1"]

n_obs <- nrow(y) - 2

result <- list(
  task_id = "var_irf",
  platform = "r",
  estimates = list(
    list(
      term = "irf_y1_to_y2_h4",
      estimate = as.numeric(irf_y1_to_y2_h4),
      se = NULL,
      n_obs = as.integer(n_obs)
    )
  ),
  method_metadata = list(
    estimator = "VAR(2) with constant, Cholesky identification",
    vcov = "none"
  ),
  diagnostics = setNames(list(), character(0))
)

write(toJSON(result, auto_unbox = TRUE, digits = 10, null = "null"), "result.json")
