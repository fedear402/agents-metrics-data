library(sandwich)
library(jsonlite)

dat <- read.csv("input.csv")
names(dat) <- trimws(names(dat))

# Apply bandwidth filter
bw <- 1
dat <- dat[abs(dat$score) < bw, ]
n_obs <- nrow(dat)

# Triangular weights
dat$w <- 1 - abs(dat$score)

# Above/below cutoff indicator
dat$above <- as.integer(dat$score >= 0)

# Interaction terms for local linear
dat$score_above <- dat$score * dat$above
dat$score_below <- dat$score * (1 - dat$above)

# Design matrix: intercept_left, above, score_below, score_above
# This parameterizes:
#   left side: beta0 + beta2*score
#   right side: (beta0 + beta1) + (beta2 + beta3)*score  [but we want separate slopes]
# Better: use above, score:above, score:(1-above) directly

X <- cbind(
  intercept = 1,
  above = dat$above,
  score_left = dat$score * (1 - dat$above),
  score_right = dat$score * dat$above
)

W <- diag(dat$w)

# WLS via matrix algebra
XtWX <- t(X) %*% W %*% X
XtWX_inv <- solve(XtWX)

# Reduced form: outcome = earnings
y_earn <- dat$earnings
beta_earn <- XtWX_inv %*% t(X) %*% W %*% y_earn
resid_earn <- y_earn - X %*% beta_earn

# First stage: outcome = participated
y_part <- dat$participated
beta_part <- XtWX_inv %*% t(X) %*% W %*% y_part
resid_part <- y_part - X %*% beta_part

# HC0 robust variance: (X'WX)^{-1} X'W diag(e^2) WX (X'WX)^{-1}
# With weights absorbed: meat = sum_i w_i^2 * e_i^2 * x_i x_i'
meat_earn <- t(X) %*% (W %*% diag(as.vector(resid_earn^2)) %*% W) %*% X
vcov_earn <- XtWX_inv %*% meat_earn %*% XtWX_inv

meat_part <- t(X) %*% (W %*% diag(as.vector(resid_part^2)) %*% W) %*% X
vcov_part <- XtWX_inv %*% meat_part %*% XtWX_inv

# Cross-covariance for delta method
meat_cross <- t(X) %*% (W %*% diag(as.vector(resid_earn * resid_part)) %*% W) %*% X
vcov_cross <- XtWX_inv %*% meat_cross %*% XtWX_inv

# Discontinuities are coefficient on 'above' (index 2, 0-based: row/col 2 in 1-indexed)
idx <- 2  # 'above' coefficient

rf_est <- beta_earn[idx]
fs_est <- beta_part[idx]
te_est <- rf_est / fs_est

rf_se <- sqrt(vcov_earn[idx, idx])
fs_se <- sqrt(vcov_part[idx, idx])

# Delta method for treatment effect: te = rf/fs
# Var(te) = (1/fs)^2 * Var(rf) + (rf/fs^2)^2 * Var(fs) - 2*(rf/fs^3)*Cov(rf,fs)
cov_rf_fs <- vcov_cross[idx, idx]
var_te <- (1/fs_est)^2 * vcov_earn[idx,idx] +
          (rf_est/fs_est^2)^2 * vcov_part[idx,idx] -
          2 * (rf_est/fs_est^3) * cov_rf_fs
te_se <- sqrt(var_te)

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = as.numeric(te_est), se = as.numeric(te_se), n_obs = n_obs),
    list(term = "reduced_form", estimate = as.numeric(rf_est), se = as.numeric(rf_se), n_obs = n_obs),
    list(term = "first_stage", estimate = as.numeric(fs_est), se = as.numeric(fs_se), n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "fuzzy_rd_local_linear_wls",
    vcov = "HC0"
  ),
  diagnostics = list()
)

write(toJSON(result, auto_unbox = TRUE, digits = 10), "result.json")
