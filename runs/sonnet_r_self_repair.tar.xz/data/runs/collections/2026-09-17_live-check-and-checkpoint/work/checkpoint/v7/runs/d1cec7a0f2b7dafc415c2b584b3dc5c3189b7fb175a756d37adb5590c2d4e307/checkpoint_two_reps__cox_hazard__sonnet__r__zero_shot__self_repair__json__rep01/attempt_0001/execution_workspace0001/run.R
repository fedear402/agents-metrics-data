library(survival)
library(jsonlite)

dat <- read.csv("./input.csv")

fit <- coxph(Surv(t_obs, event) ~ treat + x, data = dat)

coef_summary <- summary(fit)$coefficients
n_obs <- fit$n

result <- list(
  task_id = "cox_hazard",
  platform = "r",
  estimates = list(
    list(term = "treat", estimate = as.numeric(coef_summary["treat", "coef"]),
         se = as.numeric(coef_summary["treat", "se(coef)"]), n_obs = as.integer(n_obs)),
    list(term = "x", estimate = as.numeric(coef_summary["x", "coef"]),
         se = as.numeric(coef_summary["x", "se(coef)"]), n_obs = as.integer(n_obs))
  ),
  method_metadata = list(estimator = "Cox proportional hazards (partial likelihood)", vcov = "model-based"),
  diagnostics = setNames(list(), character(0))
)

write(toJSON(result, auto_unbox = TRUE, digits = 10), "./result.json")
