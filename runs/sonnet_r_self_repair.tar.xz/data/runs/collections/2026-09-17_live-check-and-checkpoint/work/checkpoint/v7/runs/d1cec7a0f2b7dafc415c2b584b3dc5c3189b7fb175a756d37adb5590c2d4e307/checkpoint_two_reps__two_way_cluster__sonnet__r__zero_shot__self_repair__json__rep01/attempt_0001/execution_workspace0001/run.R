library(sandwich)
library(lmtest)
library(jsonlite)

data <- read.csv("./input.csv")

model <- lm(y_twocluster ~ x, data = data)

# Cameron-Gelbach-Miller two-way cluster-robust vcov
vcov_twoway <- function(model, cluster1, cluster2) {
  vcov1 <- sandwich::vcovCL(model, cluster = cluster1)
  vcov2 <- sandwich::vcovCL(model, cluster = cluster2)
  cluster12 <- paste(cluster1, cluster2, sep = "_")
  vcov12 <- sandwich::vcovCL(model, cluster = cluster12)
  vcov1 + vcov2 - vcov12
}

V <- vcov_twoway(model, data$firm, data$year)

coefs <- coef(model)
ses <- sqrt(diag(V))
n_obs <- nobs(model)

result <- list(
  task_id = "two_way_cluster",
  platform = "r",
  estimates = list(
    list(term = "const", estimate = unname(coefs["(Intercept)"]), se = unname(ses["(Intercept)"]), n_obs = n_obs),
    list(term = "x", estimate = unname(coefs["x"]), se = unname(ses["x"]), n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "OLS",
    vcov = "two-way cluster-robust (Cameron-Gelbach-Miller), clustered on firm and year"
  ),
  diagnostics = setNames(list(), character(0))
)

write(toJSON(result, auto_unbox = TRUE, digits = 10), "result.json")
