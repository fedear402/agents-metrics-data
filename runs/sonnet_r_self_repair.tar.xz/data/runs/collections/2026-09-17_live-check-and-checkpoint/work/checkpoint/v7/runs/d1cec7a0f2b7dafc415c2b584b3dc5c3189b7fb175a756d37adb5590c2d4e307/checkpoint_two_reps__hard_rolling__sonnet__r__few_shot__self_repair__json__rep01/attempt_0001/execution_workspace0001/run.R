library(jsonlite)

data <- read.csv("input.csv")
data <- data[order(data$time),]

forecast_times <- 101:250
forecasts <- numeric(length(forecast_times))

for (i in seq_along(forecast_times)) {
  f <- forecast_times[i]
  history <- data[data$time >= (f-100) & data$time <= (f-1),]
  levels <- history$y
  lagged <- head(levels, -1)
  current <- tail(levels, -1)
  fit <- lm(current ~ lagged)
  forecasts[i] <- coef(fit)[1] + coef(fit)[2] * tail(levels, 1)
}

actual <- data$y[match(forecast_times, data$time)]
rmse <- sqrt(mean((actual - forecasts)^2))

row <- function(term, estimate, se=NULL, n_obs) {
  list(term=term, estimate=unname(as.numeric(estimate)),
       se=if (is.null(se)) NULL else unname(as.numeric(se)), n_obs=as.integer(n_obs))
}

estimates <- list(
  row("rmse", rmse, NULL, 150),
  row("forecast_101", forecasts[forecast_times==101], NULL, 99),
  row("forecast_150", forecasts[forecast_times==150], NULL, 99),
  row("forecast_200", forecasts[forecast_times==200], NULL, 99),
  row("forecast_250", forecasts[forecast_times==250], NULL, 99)
)

result <- list(
  task_id = "hard_rolling",
  platform = "r",
  estimates = estimates,
  method_metadata = list(estimator = "OLS AR(1) rolling", vcov = "none"),
  diagnostics = setNames(list(), character(0))
)

write_json(result, "result.json", auto_unbox=TRUE, null="null", digits=16, pretty=TRUE)
