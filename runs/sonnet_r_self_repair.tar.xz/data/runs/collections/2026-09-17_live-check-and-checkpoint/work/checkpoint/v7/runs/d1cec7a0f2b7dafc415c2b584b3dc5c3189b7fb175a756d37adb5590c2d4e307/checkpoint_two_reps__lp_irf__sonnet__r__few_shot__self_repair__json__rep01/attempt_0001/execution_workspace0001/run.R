library(sandwich)
library(lmtest)
library(jsonlite)

dat <- read.csv("./input.csv")

# Sort by t
dat <- dat[order(dat$t), ]

n <- nrow(dat)
h <- 4

# Create y_{t+4} as forward variable
y_lead4 <- c(dat$y[(h+1):n], rep(NA, h))
y_lag1  <- c(NA, dat$y[1:(n-1)])
shock   <- dat$shock

df <- data.frame(
  y_lead4 = y_lead4,
  shock   = shock,
  y_lag1  = y_lag1
)

df <- df[complete.cases(df), ]

fit <- lm(y_lead4 ~ shock + y_lag1, data = df)

nw_vcov <- NeweyWest(fit, lag = 4, prewhite = FALSE, adjust = TRUE)
ct <- coeftest(fit, vcov = nw_vcov)

irf_est <- ct["shock", "Estimate"]
irf_se  <- ct["shock", "Std. Error"]
n_obs   <- nrow(df)

out <- list(
  task_id  = "lp_irf",
  platform = "r",
  estimates = list(
    list(term = "irf_h4", estimate = unname(irf_est), se = unname(irf_se), n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "Local Projection OLS at h=4",
    vcov      = "Newey-West lag=4"
  ),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "./result.json", auto_unbox = TRUE)
