d <- read.csv("input.csv")
d$y <- ordered(d$y, levels=1:3)

fit <- MASS::polr(y ~ x + z, data=d, method="logistic", Hess=TRUE,
                  control=list(reltol=1e-12, maxit=1000))
V <- vcov(fit)
n <- nrow(d)

# Probability of category 3 at x=1, z=0
# P(Y=3) = 1 - plogis(zeta[2] - beta_x*1 - beta_z*0)
prob_high <- 1 - plogis(fit$zeta[2] - coef(fit)["x"])

estimates <- list(
  list(term="x", estimate=unname(coef(fit)["x"]), se=sqrt(V["x","x"]), n_obs=n),
  list(term="z", estimate=unname(coef(fit)["z"]), se=sqrt(V["z","z"]), n_obs=n),
  list(term="prob_high", estimate=unname(prob_high), se=NULL, n_obs=n)
)

result <- list(
  task_id="broad_ordered_logit",
  platform="r",
  estimates=estimates,
  method_metadata=list(estimator="MASS::polr ordered logit", vcov="observed information (native)"),
  diagnostics=list()
)

jsonlite::write_json(result, "result.json", auto_unbox=TRUE, null="null", digits=16, pretty=TRUE)
