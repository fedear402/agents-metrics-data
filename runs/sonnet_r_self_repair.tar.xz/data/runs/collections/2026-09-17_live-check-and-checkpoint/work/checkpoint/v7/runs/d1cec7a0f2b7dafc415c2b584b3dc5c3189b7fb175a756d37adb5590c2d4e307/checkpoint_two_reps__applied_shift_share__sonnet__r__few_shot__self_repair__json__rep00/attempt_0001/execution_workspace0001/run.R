library(jsonlite)

dat <- read.csv("input.csv", stringsAsFactors = FALSE)

# Normalize regional weights (one obs per region)
regions <- unique(dat[, c("region_id", "region_weight", "x", "y")])
regions$e_r <- regions$region_weight / sum(regions$region_weight)

# Compute shift-share instrument z_r = sum_n share_rn * shock_n
industries <- unique(dat[, c("industry_id", "shock")])
shock_map <- setNames(industries$shock, industries$industry_id)

inst <- tapply(dat$share * shock_map[as.character(dat$industry_id)], dat$region_id, sum)
regions$z_r <- inst[as.character(regions$region_id)]

# Weighted means
wmean <- function(x, w) sum(w * x) / sum(w)
e <- regions$e_r
mu_y <- wmean(regions$y, e)
mu_x <- wmean(regions$x, e)
mu_z <- wmean(regions$z_r, e)

regions$y0 <- regions$y - mu_y
regions$x0 <- regions$x - mu_x
regions$z0 <- regions$z_r - mu_z

# Industry masses s_n and aggregated residuals
n_ids <- unique(dat$industry_id)
N <- length(n_ids)

# Merge e_r and residuals into dat
reg_sub <- regions[, c("region_id", "e_r", "y0", "x0", "z0")]
dat2 <- merge(dat, reg_sub, by = "region_id")

shock_level <- do.call(rbind, lapply(n_ids, function(nid) {
  sub <- dat2[dat2$industry_id == nid, ]
  s_n <- sum(sub$e_r * sub$share)
  ybar <- sum(sub$e_r * sub$share * sub$y0) / s_n
  xbar <- sum(sub$e_r * sub$share * sub$x0) / s_n
  zbar <- sum(sub$e_r * sub$share * sub$z0) / s_n
  shock_n <- unique(sub$shock)
  data.frame(industry_id = nid, s_n = s_n, ybar = ybar, xbar = xbar, zbar = zbar, shock_n = shock_n)
}))

# Shock-level IV regression helper
shock_iv <- function(dependent, endogenous, instrument, weights, N_obs) {
  regressors <- cbind(1, endogenous)
  instruments <- cbind(1, instrument)
  cross <- crossprod(instruments, weights * regressors)
  beta <- solve(cross, crossprod(instruments, weights * dependent))
  residual <- drop(dependent - regressors %*% beta)
  scores <- instruments * (weights * residual)
  inverse <- solve(cross)
  covariance <- N_obs / (N_obs - 2) * inverse %*% crossprod(scores) %*% t(inverse)
  c(slope = beta[2], se = sqrt(covariance[2, 2]))
}

s <- shock_level$s_n
ybar <- shock_level$ybar
xbar <- shock_level$xbar
zbar <- shock_level$zbar
shock_n <- shock_level$shock_n

# Effect: IV of ybar on xbar, instrument shock_n
effect <- shock_iv(ybar, xbar, shock_n, s, N)

# First stage: IV of xbar on zbar (endogenous), instrument shock_n
first_stage <- shock_iv(xbar, zbar, shock_n, s, N)

# Effective shocks
effective_shocks <- 1 / sum(s^2)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = unname(effect["slope"]), se = unname(effect["se"]), n_obs = N),
    list(term = "first_stage", estimate = unname(first_stage["slope"]), se = unname(first_stage["se"]), n_obs = N),
    list(term = "effective_shocks", estimate = effective_shocks, se = NULL, n_obs = N)
  ),
  method_metadata = list(estimator = "shift_share_2SLS", vcov = "HC1_shock_level"),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
