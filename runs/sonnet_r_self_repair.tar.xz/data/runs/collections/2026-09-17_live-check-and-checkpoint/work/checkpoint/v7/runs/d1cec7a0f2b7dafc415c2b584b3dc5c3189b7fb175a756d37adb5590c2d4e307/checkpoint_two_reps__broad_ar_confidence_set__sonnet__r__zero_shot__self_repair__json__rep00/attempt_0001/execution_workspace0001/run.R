library(jsonlite)

data <- read.csv("input.csv")
n <- nrow(data)
y <- data$y
endog <- data$endog
x <- data$x
z1 <- data$z1
z2 <- data$z2

# Critical value: 95th percentile of F(2, n-4)
cv <- qf(0.95, df1 = 2, df2 = n - 4)

ar_f <- function(beta) {
  y_adj <- y - beta * endog
  fit_restricted <- lm(y_adj ~ x)
  fit_full <- lm(y_adj ~ x + z1 + z2)
  rss_r <- sum(residuals(fit_restricted)^2)
  rss_f <- sum(residuals(fit_full)^2)
  f_stat <- ((rss_r - rss_f) / 2) / (rss_f / (n - 4))
  return(f_stat)
}

# Find roots of ar_f(beta) - cv = 0
# The AR F statistic is a quadratic in beta, so we can find roots analytically
# F(beta) = [(RSS_r(beta) - RSS_f(beta))/2] / [RSS_f(beta)/(n-4)]
# This equals cv at boundaries

# Let's find roots numerically over a wide range first
# Then use uniroot for precise values

f_minus_cv <- function(beta) ar_f(beta) - cv

# Search for sign changes
beta_grid <- seq(-1000, 1000, by = 0.1)
f_vals <- sapply(beta_grid, f_minus_cv)

# Find sign changes
sign_changes <- which(diff(sign(f_vals)) != 0)

roots <- c()
for (i in sign_changes) {
  r <- uniroot(f_minus_cv, interval = c(beta_grid[i], beta_grid[i+1]), tol = 1e-10)
  roots <- c(roots, r$root)
}

# Check if we need to extend search
# Try very large values
f_large_pos <- f_minus_cv(1e6)
f_large_neg <- f_minus_cv(-1e6)

# If F at large values is < 0, the set might be unbounded
# (F < cv means beta is accepted)
# Actually F < cv means accepted, F > cv means rejected
# So f_minus_cv < 0 means accepted

unbounded <- 0
if (f_large_pos < 0 || f_large_neg < 0) {
  unbounded <- 1
}

# Sort roots
roots <- sort(unique(round(roots, 8)))

# Determine boundary_low and boundary_high
# These are the two finite boundary points
boundary_low <- roots[1]
boundary_high <- roots[length(roots)]

# Check if zero is in confidence set
f_at_zero <- ar_f(0)
accepts_zero <- if (f_at_zero <= cv) 1 else 0

# AR F at beta = 1
ar_f_at_one <- ar_f(1)

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = list(
    list(term = "boundary_low", estimate = boundary_low, se = NULL, n_obs = n),
    list(term = "boundary_high", estimate = boundary_high, se = NULL, n_obs = n),
    list(term = "accepts_zero", estimate = as.numeric(accepts_zero), se = NULL, n_obs = n),
    list(term = "unbounded", estimate = as.numeric(unbounded), se = NULL, n_obs = n),
    list(term = "ar_f_at_one", estimate = ar_f_at_one, se = NULL, n_obs = n)
  ),
  method_metadata = list(
    estimator = "Anderson-Rubin test inversion",
    vcov = "homoskedastic"
  ),
  diagnostics = setNames(list(), character(0))
)

write(toJSON(result, auto_unbox = TRUE, digits = 10, null = "null"), "result.json")
