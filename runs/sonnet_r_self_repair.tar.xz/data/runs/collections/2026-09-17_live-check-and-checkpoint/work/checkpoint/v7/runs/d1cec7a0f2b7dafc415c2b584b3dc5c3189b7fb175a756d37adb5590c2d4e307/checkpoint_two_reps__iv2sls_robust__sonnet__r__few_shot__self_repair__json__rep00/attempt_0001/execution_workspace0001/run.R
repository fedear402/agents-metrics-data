library(AER)
library(sandwich)
library(lmtest)
library(jsonlite)

df <- read.csv("./input.csv")

iv_model <- ivreg(y_iv ~ x1_iv | z, data = df)

robust_se <- vcovHC(iv_model, type = "HC1")
coef_test <- coeftest(iv_model, vcov = robust_se)

n_obs <- nrow(df)

out <- list(
  task_id = "iv2sls_robust",
  platform = "r",
  estimates = list(
    list(term = "const", estimate = coef_test["(Intercept)", "Estimate"],
         se = coef_test["(Intercept)", "Std. Error"], n_obs = n_obs),
    list(term = "x1_iv", estimate = coef_test["x1_iv", "Estimate"],
         se = coef_test["x1_iv", "Std. Error"], n_obs = n_obs)
  ),
  method_metadata = list(estimator = "2SLS via AER::ivreg",
                         vcov = "HC1 robust"),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "./result.json", auto_unbox = TRUE)
