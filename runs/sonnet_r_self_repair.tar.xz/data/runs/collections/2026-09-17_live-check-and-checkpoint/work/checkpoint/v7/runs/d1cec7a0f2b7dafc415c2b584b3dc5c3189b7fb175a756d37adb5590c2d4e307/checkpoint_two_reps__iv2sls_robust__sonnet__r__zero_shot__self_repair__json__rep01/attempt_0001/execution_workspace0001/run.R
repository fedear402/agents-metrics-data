library(AER)
library(sandwich)
library(lmtest)
library(jsonlite)

dat <- read.csv("./input.csv")

fit <- ivreg(y_iv ~ x1_iv | z, data = dat)

vcov_hc1 <- vcovHC(fit, type = "HC1")
ct <- coeftest(fit, vcov = vcov_hc1)

n_obs <- nobs(fit)

estimates <- list(
  list(term = "const", estimate = unname(ct["(Intercept)", "Estimate"]),
       se = unname(ct["(Intercept)", "Std. Error"]), n_obs = n_obs),
  list(term = "x1_iv", estimate = unname(ct["x1_iv", "Estimate"]),
       se = unname(ct["x1_iv", "Std. Error"]), n_obs = n_obs)
)

result <- list(
  task_id = "iv2sls_robust",
  platform = "r",
  estimates = estimates,
  method_metadata = list(estimator = "2SLS via AER::ivreg", vcov = "HC1"),
  diagnostics = setNames(list(), character(0))
)

write(toJSON(result, auto_unbox = TRUE, digits = 10), "./result.json")
