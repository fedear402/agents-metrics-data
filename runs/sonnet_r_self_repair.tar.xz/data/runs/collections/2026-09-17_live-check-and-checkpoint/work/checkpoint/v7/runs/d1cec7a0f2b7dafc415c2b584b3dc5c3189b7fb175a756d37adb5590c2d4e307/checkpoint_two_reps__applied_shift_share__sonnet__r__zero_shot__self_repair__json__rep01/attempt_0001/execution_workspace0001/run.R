library(AER)
library(sandwich)
library(jsonlite)

dat <- read.csv("input.csv", stringsAsFactors = FALSE)

# One obs per region
regions <- dat[!duplicated(dat$region_id), c("region_id", "region_weight", "x", "y")]
regions$e_r <- regions$region_weight / sum(regions$region_weight)

# Construct shift-share instrument z_r = sum_n share_rn * shock_n
shock_map <- unique(dat[, c("industry_id", "shock")])
dat2 <- merge(dat, shock_map, by = "industry_id", all.x = TRUE)
# dat2$shock is already there
z_agg <- aggregate(share * shock ~ region_id, data = dat2, FUN = sum)
names(z_agg) <- c("region_id", "z")

regions <- merge(regions, z_agg, by = "region_id")

# Weighted means
wmean <- function(v, w) sum(v * w) / sum(w)
e <- regions$e_r

mean_y <- wmean(regions$y, e)
mean_x <- wmean(regions$x, e)
mean_z <- wmean(regions$z, e)

regions$y0 <- regions$y - mean_y
regions$x0 <- regions$x - mean_x
regions$z0 <- regions$z - mean_z

# Industry-level aggregation
# s_n = sum_r e_r * share_rn
dat3 <- merge(dat2, regions[, c("region_id", "e_r", "y0", "x0", "z0")], by = "region_id")

dat3$e_share <- dat3$e_r * dat3$share

industries <- unique(dat3$industry_id)

agg <- lapply(industries, function(n) {
  sub <- dat3[dat3$industry_id == n, ]
  s_n <- sum(sub$e_share)
  ybar_n <- sum(sub$e_share * sub$y0) / s_n
  xbar_n <- sum(sub$e_share * sub$x0) / s_n
  zbar_n <- sum(sub$e_share * sub$z0) / s_n
  shock_n <- sub$shock[1]
  data.frame(industry_id = n, s_n = s_n, ybar = ybar_n, xbar = xbar_n, zbar = zbar_n, shock = shock_n)
})
agg_df <- do.call(rbind, agg)

N <- nrow(agg_df)

# HC1 multiplier: N/(N-2)
hc1_mult <- N / (N - 2)

# --- Effect: shock-level IV of ybar on xbar, instrument = shock, weights = s_n ---
iv_effect <- ivreg(ybar ~ xbar | shock, data = agg_df, weights = s_n)
# Get structural residuals
beta_effect <- coef(iv_effect)["xbar"]

# Manual HC1 SE for IV
# bread = (Z'WX)^{-1} Z'WZ (Z'WX)^{-T} ... use sandwich approach
# Actually use vcovHC from sandwich with type HC1, then scale
vc_effect <- vcovHC(iv_effect, type = "HC1")
# vcovHC for ivreg uses n/(n-k) by default for HC1 where k includes intercept
# We need to verify: HC1 = HC0 * n/(n-k), k=2 here
# sandwich::vcovHC should handle this
se_effect <- sqrt(vc_effect["xbar", "xbar"])

# --- First stage: shock-level IV of xbar on zbar, instrument = shock, weights = s_n ---
iv_fs <- ivreg(xbar ~ zbar | shock, data = agg_df, weights = s_n)
beta_fs <- coef(iv_fs)["zbar"]
vc_fs <- vcovHC(iv_fs, type = "HC1")
se_fs <- sqrt(vc_fs["zbar", "zbar"])

# --- Effective shocks ---
eff_shocks <- 1 / sum(agg_df$s_n^2)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = as.numeric(beta_effect), se = as.numeric(se_effect), n_obs = as.integer(N)),
    list(term = "first_stage", estimate = as.numeric(beta_fs), se = as.numeric(se_fs), n_obs = as.integer(N)),
    list(term = "effective_shocks", estimate = as.numeric(eff_shocks), se = NULL, n_obs = as.integer(N))
  ),
  method_metadata = list(
    estimator = "2SLS shift-share with exposure-robust SE",
    vcov = "HC1 shock-level"
  ),
  diagnostics = list()
)

write(toJSON(result, auto_unbox = TRUE, digits = 10, null = "null"), "result.json")
