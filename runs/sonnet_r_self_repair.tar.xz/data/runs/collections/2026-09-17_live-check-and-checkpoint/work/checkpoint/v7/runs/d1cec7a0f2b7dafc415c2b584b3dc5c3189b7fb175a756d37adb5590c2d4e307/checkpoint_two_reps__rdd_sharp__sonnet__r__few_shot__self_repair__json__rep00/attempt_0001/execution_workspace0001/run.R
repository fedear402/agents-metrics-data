library(jsonlite)

df <- read.csv("./input.csv")

h <- 0.5
cutoff <- 0

df_left <- df[df$z >= cutoff - h & df$z < cutoff, ]
df_right <- df[df$z >= cutoff & df$z <= cutoff + h, ]

tri_kernel <- function(u) pmax(1 - abs(u) / h, 0)

w_left <- tri_kernel(df_left$z - cutoff)
w_right <- tri_kernel(df_right$z - cutoff)

fit_left <- lm(y ~ z, data = df_left, weights = w_left)
fit_right <- lm(y ~ z, data = df_right, weights = w_right)

intercept_left <- coef(fit_left)[["(Intercept)"]]
intercept_right <- coef(fit_right)[["(Intercept)"]]

late <- intercept_right - intercept_left

n_obs <- nrow(df_left) + nrow(df_right)

vcov_left <- vcov(fit_left)
vcov_right <- vcov(fit_right)
se_late <- sqrt(vcov_right["(Intercept)", "(Intercept)"] + vcov_left["(Intercept)", "(Intercept)"])

out <- list(
  task_id = "rdd_sharp",
  platform = "r",
  estimates = list(
    list(term = "late", estimate = late, se = se_late, n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "Local linear RDD with triangular kernel, h=0.5",
    vcov = "OLS standard errors on each side"
  ),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "./result.json", auto_unbox = TRUE)
