library(jsonlite)

dat <- read.csv("./input.csv")

cohorts <- c(4, 6, 8)
never <- dat[dat$cohort == -1, ]

cells <- list()
for (g in cohorts) {
  treated <- dat[dat$cohort == g, ]
  pre_t <- g - 1
  
  mean_never_pre <- mean(never$y_did[never$year == pre_t])
  mean_treated_pre <- mean(treated$y_did[treated$year == pre_t])
  
  post_years <- (g):9
  for (t in post_years) {
    mean_treated_t <- mean(treated$y_did[treated$year == t])
    mean_never_t <- mean(never$y_did[never$year == t])
    
    att_gt <- (mean_treated_t - mean_treated_pre) - (mean_never_t - mean_never_pre)
    cells <- c(cells, list(att_gt))
  }
}

att_uniform <- mean(unlist(cells))

n_obs <- nrow(dat)

result <- list(
  task_id = "staggered_did",
  platform = "r",
  estimates = list(
    list(term = "att", estimate = att_uniform, se = NULL, n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "Callaway-SantAnna ATT_uniform manual computation",
    vcov = "none"
  ),
  diagnostics = setNames(list(), character(0))
)

write(toJSON(result, auto_unbox = TRUE, null = "null", digits = 10), "./result.json")
