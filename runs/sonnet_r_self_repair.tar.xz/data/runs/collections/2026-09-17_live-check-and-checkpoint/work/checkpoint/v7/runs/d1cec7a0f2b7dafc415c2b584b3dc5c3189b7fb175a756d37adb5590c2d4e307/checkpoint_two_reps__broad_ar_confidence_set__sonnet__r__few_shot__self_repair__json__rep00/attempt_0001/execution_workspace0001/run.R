library(jsonlite)

d <- read.csv("input.csv")
n <- nrow(d)
q <- 2L
df <- n - 4L  # n - (intercept + x + z1 + z2)
critical <- qf(0.95, q, df)

# Residuals from unrestricted regression: y ~ intercept + x + z1 + z2
full_y <- lm(y ~ x + z1 + z2, data = d)
full_endog <- lm(endog ~ x + z1 + z2, data = d)
uy <- residuals(full_y)
ud <- residuals(full_endog)

# Residuals from restricted regression (no z1, z2): y ~ intercept + x
ry <- residuals(lm(y ~ x, data = d))
rd <- residuals(lm(endog ~ x, data = d))

k <- q * critical / df

A <- sum(rd^2) - (1 + k) * sum(ud^2)
B <- -2 * (sum(ry * rd) - (1 + k) * sum(uy * ud))
C <- sum(ry^2) - (1 + k) * sum(uy^2)

bounds <- sort(Re(polyroot(c(C, B, A))))
unbounded <- as.integer(A < 0)

accepts <- function(beta) A * beta^2 + B * beta + C <= 0

accepts_zero <- as.integer(accepts(0))

# F statistic at beta = 1
transformed_1 <- d$y - 1 * d$endog
restricted_1 <- lm(transformed_1 ~ x, data = d)
full_1 <- lm(transformed_1 ~ x + z1 + z2, data = d)
ar_f_at_one <- ((deviance(restricted_1) - deviance(full_1)) / q) / (deviance(full_1) / df)

rows <- list(
  list(term = "boundary_low", estimate = unname(bounds[1]), se = NULL, n_obs = n),
  list(term = "boundary_high", estimate = unname(bounds[2]), se = NULL, n_obs = n),
  list(term = "accepts_zero", estimate = unname(accepts_zero), se = NULL, n_obs = n),
  list(term = "unbounded", estimate = unname(unbounded), se = NULL, n_obs = n),
  list(term = "ar_f_at_one", estimate = unname(ar_f_at_one), se = NULL, n_obs = n)
)

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = rows,
  method_metadata = list(estimator = "Anderson-Rubin", vcov = "homoskedastic"),
  diagnostics = setNames(list(), character(0))
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
