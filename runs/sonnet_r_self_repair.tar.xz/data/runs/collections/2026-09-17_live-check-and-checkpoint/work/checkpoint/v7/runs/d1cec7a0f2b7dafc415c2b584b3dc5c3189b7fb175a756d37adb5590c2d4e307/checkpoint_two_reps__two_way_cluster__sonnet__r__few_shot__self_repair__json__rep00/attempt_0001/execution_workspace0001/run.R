library(jsonlite)
library(sandwich)
library(lmtest)

df <- read.csv("./input.csv")

fit <- lm(y_twocluster ~ x, data = df)

# Cameron-Gelbach-Miller two-way cluster-robust variance
vcov_firm <- sandwich::vcovCL(fit, cluster = ~firm)
vcov_year <- sandwich::vcovCL(fit, cluster = ~year)
vcov_firm_year <- sandwich::vcovCL(fit, cluster = ~firm + year)

vcov_twoway <- vcov_firm + vcov_year - vcov_firm_year

se_twoway <- sqrt(diag(vcov_twoway))
co <- coef(fit)

n_obs <- nrow(df)

out <- list(
  task_id = "two_way_cluster",
  platform = "r",
  estimates = list(
    list(term = "const", estimate = unname(co["(Intercept)"]),
         se = unname(se_twoway["(Intercept)"]), n_obs = n_obs),
    list(term = "x", estimate = unname(co["x"]),
         se = unname(se_twoway["x"]), n_obs = n_obs)
  ),
  method_metadata = list(estimator = "OLS", vcov = "two-way cluster-robust (CGM)"),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "result.json", auto_unbox = TRUE, digits = 10)
