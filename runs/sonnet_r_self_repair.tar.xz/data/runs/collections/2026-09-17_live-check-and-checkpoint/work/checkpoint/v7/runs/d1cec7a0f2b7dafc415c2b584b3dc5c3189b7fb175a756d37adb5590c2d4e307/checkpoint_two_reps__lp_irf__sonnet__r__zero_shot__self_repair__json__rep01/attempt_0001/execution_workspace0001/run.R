library(sandwich)
library(lmtest)
library(jsonlite)

data <- read.csv("./input.csv")

data <- data[order(data$t), ]

h <- 4
n <- nrow(data)

y_lead <- c(data$y[(h+1):n], rep(NA, h))
shock <- data$shock
y_lag <- c(NA, data$y[1:(n-1)])

df <- data.frame(y_lead = y_lead, shock = shock, y_lag = y_lag)
df <- df[complete.cases(df), ]

fit <- lm(y_lead ~ shock + y_lag, data = df)

nw_vcov <- NeweyWest(fit, lag = 4, prewhite = FALSE, adjust = TRUE)
ct <- coeftest(fit, vcov = nw_vcov)

irf_h4_est <- ct["shock", "Estimate"]
irf_h4_se  <- ct["shock", "Std. Error"]
n_obs <- nrow(df)

result <- list(
  task_id = "lp_irf",
  platform = "r",
  estimates = list(
    list(term = "irf_h4", estimate = as.numeric(irf_h4_est), se = as.numeric(irf_h4_se), n_obs = as.integer(n_obs))
  ),
  method_metadata = list(estimator = "local_projection_OLS", vcov = "Newey-West lag=4"),
  diagnostics = setNames(list(), character(0))
)

write(toJSON(result, auto_unbox = TRUE, digits = 10), "./result.json")
