library(survival)
library(jsonlite)

d <- read.csv("input.csv")
n <- nrow(d)

fit <- survreg(Surv(y, y > 0, type = "left") ~ x + z,
               data = d, dist = "gaussian",
               control = survreg.control(rel.tolerance = 1e-12))

V <- vcov(fit)
se_const <- sqrt(V["(Intercept)", "(Intercept)"])
se_x     <- sqrt(V["x", "x"])
se_z     <- sqrt(V["z", "z"])

estimates <- list(
  list(term = "const", estimate = unname(coef(fit)["(Intercept)"]), se = se_const, n_obs = n),
  list(term = "x",     estimate = unname(coef(fit)["x"]),           se = se_x,     n_obs = n),
  list(term = "z",     estimate = unname(coef(fit)["z"]),           se = se_z,     n_obs = n),
  list(term = "sigma", estimate = unname(fit$scale),                se = NULL,     n_obs = n)
)

result <- list(
  task_id  = "broad_tobit",
  platform = "r",
  estimates = estimates,
  method_metadata = list(estimator = "survreg_gaussian_tobit", vcov = "observed_information"),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
