library(jsonlite)

df <- read.csv("input.csv", stringsAsFactors = FALSE)

# One row per region for weights
reg_ids <- unique(df$region_id)
regions_df <- df[match(reg_ids, df$region_id), c("region_id","region_weight","x","y")]
regions_df$e_r <- regions_df$region_weight / sum(regions_df$region_weight)
rownames(regions_df) <- as.character(regions_df$region_id)

# Shift-share instrument z_r
for (rid in reg_ids) {
  sub <- df[df$region_id == rid, ]
  regions_df[as.character(rid), "z_r"] <- sum(sub$share * sub$shock)
}

# Weighted means (e_r sums to 1)
e <- regions_df$e_r
wm_y <- sum(e * regions_df$y)
wm_x <- sum(e * regions_df$x)
wm_z <- sum(e * regions_df$z_r)

regions_df$y0 <- regions_df$y - wm_y
regions_df$x0 <- regions_df$x - wm_x
regions_df$z0 <- regions_df$z_r - wm_z

# Merge residuals back to df
df$e_r <- regions_df[as.character(df$region_id), "e_r"]
df$y0  <- regions_df[as.character(df$region_id), "y0"]
df$x0  <- regions_df[as.character(df$region_id), "x0"]
df$z0  <- regions_df[as.character(df$region_id), "z0"]

# Industry-level aggregation
ind_ids <- sort(unique(df$industry_id))
N <- length(ind_ids)

s_n_vals  <- numeric(N)
shock_vals <- numeric(N)
ybar <- numeric(N)
xbar <- numeric(N)
zbar <- numeric(N)

for (i in seq_len(N)) {
  n   <- ind_ids[i]
  sub <- df[df$industry_id == n, ]
  s_n <- sum(sub$e_r * sub$share)
  s_n_vals[i]   <- s_n
  shock_vals[i] <- as.numeric(sub$shock[1])
  ybar[i] <- sum(sub$e_r * sub$share * sub$y0) / s_n
  xbar[i] <- sum(sub$e_r * sub$share * sub$x0) / s_n
  zbar[i] <- sum(sub$e_r * sub$share * sub$z0) / s_n
}

# Shock-level weighted IV (as in example)
shock_iv <- function(dep, endog, instr_vec, w, n_ind) {
  dep       <- as.numeric(dep)
  endog     <- as.numeric(endog)
  instr_vec <- as.numeric(instr_vec)
  w         <- as.numeric(w)

  regressors  <- cbind(1, endog)
  instruments <- cbind(1, instr_vec)

  cross <- t(instruments) %*% (w * regressors)   # 2x2
  rhs   <- t(instruments) %*% (w * dep)           # 2x1

  beta     <- solve(cross, rhs)
  residual <- as.numeric(dep - regressors %*% beta)
  scores   <- instruments * (w * residual)         # Nx2
  inv_c    <- solve(cross)
  cov_mat  <- (n_ind / (n_ind - 2)) * inv_c %*% (t(scores) %*% scores) %*% t(inv_c)

  c(slope = as.numeric(beta[2]), se = sqrt(cov_mat[2, 2]))
}

effect_res <- shock_iv(ybar,  xbar,  shock_vals, s_n_vals, N)
fs_res     <- shock_iv(xbar,  zbar,  shock_vals, s_n_vals, N)
eff_shocks <- 1 / sum(s_n_vals^2)

result <- list(
  task_id  = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect",          estimate = unname(effect_res["slope"]),
         se = unname(effect_res["se"]), n_obs = as.integer(N)),
    list(term = "first_stage",     estimate = unname(fs_res["slope"]),
         se = unname(fs_res["se"]),    n_obs = as.integer(N)),
    list(term = "effective_shocks", estimate = as.numeric(eff_shocks),
         se = NULL,                    n_obs = as.integer(N))
  ),
  method_metadata = list(estimator = "2SLS shock-level IV", vcov = "HC1 exposure-robust"),
  diagnostics = setNames(list(), character(0))
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
