library(jsonlite)

df <- read.csv("input.csv")

# Normalize regional weights (one obs per region)
regions <- unique(df[, c("region_id", "region_weight", "x", "y")])
total_weight <- sum(regions$region_weight)
regions$e_r <- regions$region_weight / total_weight

# Merge normalized weights back
df <- merge(df, regions[, c("region_id", "e_r")], by = "region_id")

# Construct shift-share instrument z_r = sum_n share_rn * shock_n
ss <- aggregate(share * shock ~ region_id, data = df, FUN = sum)
names(ss)[2] <- "z_r"
regions <- merge(regions, ss, by = "region_id")

# Weighted means
wmean <- function(v, w) sum(v * w) / sum(w)
mean_y <- wmean(regions$y, regions$e_r)
mean_x <- wmean(regions$x, regions$e_r)
mean_z <- wmean(regions$z_r, regions$e_r)

regions$y0 <- regions$y - mean_y
regions$x0 <- regions$x - mean_x
regions$z0 <- regions$z_r - mean_z

# Industry exposure masses s_n
industries <- unique(df$industry_id)
N <- length(industries)

# For each industry, compute s_n and aggregated residuals
# Merge region-level residuals into df
df <- merge(df, regions[, c("region_id", "e_r", "y0", "x0", "z0")], by = "region_id")

agg <- lapply(industries, function(n) {
  sub <- df[df$industry_id == n, ]
  s_n <- sum(sub$e_r * sub$share)
  ybar_n <- sum(sub$e_r * sub$share * sub$y0) / s_n
  xbar_n <- sum(sub$e_r * sub$share * sub$x0) / s_n
  zbar_n <- sum(sub$e_r * sub$share * sub$z0) / s_n
  shock_n <- sub$shock[1]
  data.frame(industry_id = n, s_n = s_n, ybar_n = ybar_n, xbar_n = xbar_n,
             zbar_n = zbar_n, shock_n = shock_n)
})
agg <- do.call(rbind, agg)

# Shock-level IV regression helper (same as example)
shock_iv <- function(dependent, endogenous, instruments_mat, weights, n_industries) {
  regressors <- cbind(1, endogenous)
  instr <- cbind(1, instruments_mat)
  w <- weights
  cross <- crossprod(instr, w * regressors)
  beta <- solve(cross, crossprod(instr, w * dependent))
  residual <- drop(dependent - regressors %*% beta)
  scores <- instr * (w * residual)
  inverse <- solve(cross)
  covariance <- n_industries / (n_industries - 2) * inverse %*% crossprod(scores) %*% t(inverse)
  c(slope = beta[2], se = sqrt(covariance[2, 2]))
}

# Effect: IV of ybar on xbar, instrument shock_n, weights s_n
effect_res <- shock_iv(agg$ybar_n, agg$xbar_n, agg$shock_n, agg$s_n, N)

# First stage: IV of xbar on zbar (endogenous), instrument shock_n, weights s_n
fs_res <- shock_iv(agg$xbar_n, agg$zbar_n, agg$shock_n, agg$s_n, N)

# Effective shocks
effective_shocks <- 1 / sum(agg$s_n^2)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = unname(effect_res["slope"]),
         se = unname(effect_res["se"]), n_obs = as.integer(N)),
    list(term = "first_stage", estimate = unname(fs_res["slope"]),
         se = unname(fs_res["se"]), n_obs = as.integer(N)),
    list(term = "effective_shocks", estimate = effective_shocks,
         se = NULL, n_obs = as.integer(N))
  ),
  method_metadata = list(estimator = "2SLS shock-level IV", vcov = "HC1 exposure-robust"),
  diagnostics = setNames(list(), character(0))
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
