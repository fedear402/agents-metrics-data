library(sandwich)
library(jsonlite)

dat <- read.csv("input.csv")
dat <- dat[order(dat$date), ]

dat$log_sales <- log(dat$sales)
dat$log_vix <- log(dat$vix)
dat$d_log_vix <- c(NA, diff(dat$log_vix))

for (k in 1:15) {
  dat[[paste0("lag_", k)]] <- c(rep(NA, k), dat$d_log_vix[1:(nrow(dat) - k)])
}

lag_cols <- paste0("lag_", 1:15)
complete_rows <- complete.cases(dat[, c("log_sales", lag_cols)])
dat_reg <- dat[complete_rows, ]
N <- nrow(dat_reg)

formula_str <- paste("log_sales ~", paste(lag_cols, collapse = " + "))
model <- lm(as.formula(formula_str), data = dat_reg)

# Newey-West with max lag 15, Bartlett weights 1-j/16, multiplied by N/(N-16)
vcov_nw <- NeweyWest(model, lag = 15, prewhite = FALSE, adjust = FALSE,
                     weights = function(j, ...) 1 - j/16)
vcov_nw <- vcov_nw * N / (N - 16)

coefs <- coef(model)

# Coefficient names
lag_names <- paste0("lag_", 1:15)

# Cumulative response: sum of lag_1 through lag_15
R <- matrix(0, nrow = 1, ncol = length(coefs))
colnames(R) <- names(coefs)
for (nm in lag_names) {
  R[1, nm] <- 1
}

cumulative_est <- as.numeric(R %*% coefs)
cumulative_var <- as.numeric(R %*% vcov_nw %*% t(R))
cumulative_se <- sqrt(cumulative_var)

lag1_est <- coefs["lag_1"]
lag1_se <- sqrt(vcov_nw["lag_1", "lag_1"])

lag15_est <- coefs["lag_15"]
lag15_se <- sqrt(vcov_nw["lag_15", "lag_15"])

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(term = "cumulative_response", estimate = cumulative_est, se = cumulative_se, n_obs = N),
    list(term = "lag_1", estimate = unname(lag1_est), se = unname(lag1_se), n_obs = N),
    list(term = "lag_15", estimate = unname(lag15_est), se = unname(lag15_se), n_obs = N)
  ),
  method_metadata = list(
    estimator = "OLS",
    vcov = "Newey-West HAC, max lag 15, Bartlett weights 1-j/16, scaled by N/(N-16)"
  ),
  diagnostics = list()
)

write(toJSON(result, auto_unbox = TRUE, digits = 10), "result.json")
