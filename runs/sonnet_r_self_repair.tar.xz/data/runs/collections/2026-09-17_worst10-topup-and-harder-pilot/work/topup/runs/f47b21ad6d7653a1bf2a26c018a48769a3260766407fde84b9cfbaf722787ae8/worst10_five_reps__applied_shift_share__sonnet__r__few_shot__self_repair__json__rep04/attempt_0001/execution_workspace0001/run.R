library(jsonlite)

df <- read.csv("input.csv")

# Normalize weights: one obs per region
regions <- unique(df[, c("region_id", "region_weight", "x", "y")])
total_weight <- sum(regions$region_weight)
regions$e_r <- regions$region_weight / total_weight

# Merge normalized weights back
df <- merge(df, regions[, c("region_id", "e_r")], by = "region_id")

# Construct shift-share instrument z_r = sum_n share_rn * shock_n
df$share_shock <- df$share * df$shock
z_r <- aggregate(share_shock ~ region_id, data = df, FUN = sum)
names(z_r)[2] <- "z_r"
regions <- merge(regions, z_r, by = "region_id")

# Weighted means
wmean <- function(x, w) sum(w * x) / sum(w)

mean_y <- wmean(regions$y, regions$e_r)
mean_x <- wmean(regions$x, regions$e_r)
mean_z <- wmean(regions$z_r, regions$e_r)

# Demeaned residuals
regions$y0 <- regions$y - mean_y
regions$x0 <- regions$x - mean_x
regions$z0 <- regions$z_r - mean_z

# Industry-level aggregation
# s_n = sum_r e_r * share_rn
# vbar_n = sum_r e_r * share_rn * v0_r / s_n

industries <- unique(df$industry_id)
N <- length(industries)

# Merge region residuals into df
df <- merge(df, regions[, c("region_id", "e_r", "y0", "x0", "z0")], by = "region_id")

df$w_share <- df$e_r * df$share

s_n <- aggregate(w_share ~ industry_id, data = df, FUN = sum)
names(s_n)[2] <- "s_n"

df <- merge(df, s_n, by = "industry_id")

df$wy0 <- df$w_share * df$y0
df$wx0 <- df$w_share * df$x0
df$wz0 <- df$w_share * df$z0

ybar_num <- aggregate(wy0 ~ industry_id, data = df, FUN = sum)
xbar_num <- aggregate(wx0 ~ industry_id, data = df, FUN = sum)
zbar_num <- aggregate(wz0 ~ industry_id, data = df, FUN = sum)

ind_df <- merge(s_n, ybar_num, by = "industry_id")
ind_df <- merge(ind_df, xbar_num, by = "industry_id")
ind_df <- merge(ind_df, zbar_num, by = "industry_id")

ind_df$ybar <- ind_df$wy0 / ind_df$s_n
ind_df$xbar <- ind_df$wx0 / ind_df$s_n
ind_df$zbar <- ind_df$wz0 / ind_df$s_n

# Merge shocks (constant within industry)
shocks <- unique(df[, c("industry_id", "shock")])
ind_df <- merge(ind_df, shocks, by = "industry_id")

mass <- ind_df$s_n
shock_vec <- ind_df$shock

# Shock-level IV regression function
# Estimate slope of 'dependent' on intercept + 'endogenous', instrumented by shock_vec
# Weights: mass (s_n)
shock_iv <- function(dependent, endogenous) {
  regressors <- cbind(1, endogenous)
  instruments <- cbind(1, shock_vec)
  
  cross <- crossprod(instruments, mass * regressors)
  beta <- solve(cross, crossprod(instruments, mass * dependent))
  
  residual <- drop(dependent - regressors %*% beta)
  scores <- instruments * (mass * residual)
  inverse <- solve(cross)
  
  # HC1 with multiplier N/(N-2)
  covariance <- N / (N - 2) * inverse %*% crossprod(scores) %*% t(inverse)
  c(slope = beta[2], se = sqrt(covariance[2, 2]))
}

# Effect: shock-level IV of ybar on xbar (instrumented by shock)
effect_res <- shock_iv(ind_df$ybar, ind_df$xbar)

# First stage: shock-level IV of xbar on zbar (instrumented by shock)
firststage_res <- shock_iv(ind_df$xbar, ind_df$zbar)

# Effective shocks
effective_shocks <- 1 / sum(mass^2)

# Build result
result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = unname(effect_res["slope"]), se = unname(effect_res["se"]), n_obs = as.integer(N)),
    list(term = "first_stage", estimate = unname(firststage_res["slope"]), se = unname(firststage_res["se"]), n_obs = as.integer(N)),
    list(term = "effective_shocks", estimate = unname(effective_shocks), se = NULL, n_obs = as.integer(N))
  ),
  method_metadata = list(estimator = "shock_level_IV_2SLS", vcov = "HC1_exposure_robust"),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
