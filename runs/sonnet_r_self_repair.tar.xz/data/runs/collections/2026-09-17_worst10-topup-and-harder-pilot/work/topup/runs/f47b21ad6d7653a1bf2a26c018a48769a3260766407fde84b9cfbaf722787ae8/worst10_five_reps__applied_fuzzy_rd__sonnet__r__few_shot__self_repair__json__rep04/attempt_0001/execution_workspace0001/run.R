library(jsonlite)

dat <- read.csv("input.csv")
names(dat) <- trimws(names(dat))

bw <- 1
inside <- abs(dat$score) < bw
df <- dat[inside, ]
n <- nrow(df)

w <- 1 - abs(df$score)
above <- as.integer(df$score >= 0)

# Design matrix: intercept, score, above indicator, score*above interaction
X <- cbind(1, df$score, above, df$score * above)
Y <- cbind(df$earnings, df$participated)

# WLS
WX <- w * X
bread <- solve(crossprod(X, WX))
coefs <- bread %*% crossprod(WX, Y)

# Discontinuity = right limit - left limit at score=0
# Right limit: coefs[1] + coefs[3] (intercept + above)
# Left limit: coefs[1]
# Difference = coefs[3] (the 'above' coefficient)
contrast <- c(0, 0, 1, 0)

jumps <- drop(contrast %*% coefs)  # length 2: earnings, participated

residuals <- Y - X %*% coefs
loading <- w * drop(X %*% bread %*% contrast)
influence <- loading * residuals

joint <- crossprod(influence)

gradient <- c(1/jumps[2], -jumps[1]/jumps[2]^2)
te_se <- sqrt(drop(t(gradient) %*% joint %*% gradient))

rf_se <- sqrt(joint[1,1])
fs_se <- sqrt(joint[2,2])
te_est <- jumps[1] / jumps[2]

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = unname(te_est), se = unname(te_se), n_obs = n),
    list(term = "reduced_form",     estimate = unname(jumps[1]), se = unname(rf_se), n_obs = n),
    list(term = "first_stage",      estimate = unname(jumps[2]), se = unname(fs_se), n_obs = n)
  ),
  method_metadata = list(estimator = "fuzzy_rd_local_linear", vcov = "HC0"),
  diagnostics = setNames(list(), character(0))
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
