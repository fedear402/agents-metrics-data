library(sandwich)
library(jsonlite)

df <- read.csv("input.csv")
df <- df[order(df$date), ]

df$log_sales <- log(df$sales)
df$log_vix <- log(df$vix)
df$d_log_vix <- c(NA, diff(df$log_vix))

for (k in 1:15) {
  df[[paste0("lag_", k)]] <- c(rep(NA, k), df$d_log_vix[1:(nrow(df) - k)])
}

lag_cols <- paste0("lag_", 1:15)
formula_str <- paste("log_sales ~", paste(lag_cols, collapse = " + "))
model_df <- df[complete.cases(df[, c("log_sales", lag_cols)]), ]

fit <- lm(as.formula(formula_str), data = model_df)
N <- nrow(model_df)

# Manually compute Newey-West HAC with Bartlett weights 1-j/16 for lag j, max lag 15
# Using sandwich::lrvar approach via meatHAC or manual construction
X <- model.matrix(fit)
e <- residuals(fit)
n <- nrow(X)
k <- ncol(X)

# Meat of HAC estimator with Bartlett kernel weights 1 - j/16
meat_hac <- t(X) %*% (e * X)  # lag 0 term (outer products summed)
# Actually compute properly:
# S = sum_t x_t e_t x_t' + sum_{j=1}^{15} w_j * sum_t (x_t e_t x_{t-j}' e_{t-j} + x_{t-j} e_{t-j} x_t' e_t) ... 
# Use the standard formula

# Compute score matrix
scores <- X * as.vector(e)

# Lag 0
meat <- crossprod(scores)

# Lags 1 to 15
for (j in 1:15) {
  w <- 1 - j/16
  s1 <- scores[(j+1):n, , drop=FALSE]
  s0 <- scores[1:(n-j), , drop=FALSE]
  gamma_j <- t(s1) %*% s0
  meat <- meat + w * (gamma_j + t(gamma_j))
}

# Bread
bread <- solve(crossprod(X))

# HAC covariance (sandwich)
nw_vcov <- bread %*% meat %*% bread

# Adjust by N/(N-16)
nw_vcov <- nw_vcov * (N / (N - 16))

# Set names
rownames(nw_vcov) <- colnames(nw_vcov) <- colnames(X)

coefs <- coef(fit)

# Cumulative response: sum of lag_1 through lag_15
lag_names <- paste0("lag_", 1:15)
cum_resp <- sum(coefs[lag_names])

# SE for cumulative response
e_vec <- rep(1, 15)
names(e_vec) <- lag_names
var_cum <- as.numeric(t(e_vec) %*% nw_vcov[lag_names, lag_names] %*% e_vec)
se_cum <- sqrt(var_cum)

se_lag1 <- sqrt(nw_vcov["lag_1", "lag_1"])
se_lag15 <- sqrt(nw_vcov["lag_15", "lag_15"])

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(term = "cumulative_response", estimate = cum_resp, se = se_cum, n_obs = N),
    list(term = "lag_1", estimate = unname(coefs["lag_1"]), se = se_lag1, n_obs = N),
    list(term = "lag_15", estimate = unname(coefs["lag_15"]), se = se_lag15, n_obs = N)
  ),
  method_metadata = list(
    estimator = "OLS",
    vcov = "Newey-West HAC, max lag 15, Bartlett weights 1-j/16, adjusted N/(N-16)"
  ),
  diagnostics = list()
)

write(toJSON(result, auto_unbox = TRUE, digits = 10), "result.json")
