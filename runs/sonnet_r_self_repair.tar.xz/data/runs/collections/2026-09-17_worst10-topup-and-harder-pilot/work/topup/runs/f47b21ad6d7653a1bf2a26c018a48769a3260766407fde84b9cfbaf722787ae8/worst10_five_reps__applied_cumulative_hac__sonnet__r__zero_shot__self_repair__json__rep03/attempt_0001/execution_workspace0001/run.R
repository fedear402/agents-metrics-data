library(sandwich)
library(jsonlite)

df <- read.csv("input.csv")
df <- df[order(df$date), ]

df$log_sales <- log(df$sales)
df$log_vix <- log(df$vix)
df$d_log_vix <- c(NA, diff(df$log_vix))

for (k in 1:15) {
  df[[paste0("lag_", k)]] <- c(rep(NA, k), df$d_log_vix[1:(nrow(df) - k)])
}

lag_cols <- paste0("lag_", 1:15)
complete_rows <- complete.cases(df[, c("log_sales", lag_cols)])
df_reg <- df[complete_rows, ]
N <- nrow(df_reg)

formula_str <- paste("log_sales ~", paste(lag_cols, collapse = " + "))
model <- lm(as.formula(formula_str), data = df_reg)

# Newey-West with max lag 15, Bartlett weights 1 - j/16
nw_vcov_raw <- sandwich::NeweyWest(model, lag = 15, prewhite = FALSE, adjust = FALSE,
                                    weights = NULL)

# The sandwich package uses bandwidth = lag + 1, and Bartlett weights by default
# We need weights 1 - j/16 for j=1,...,15 (Bartlett kernel with bandwidth 16)
# NeweyWest with lag=15 uses weights 1 - j/(lag+1) = 1 - j/16 by default
# adjust=FALSE means no small sample correction yet; we apply N/(N-16)

# Apply finite sample correction N/(N-16)
correction <- N / (N - 16)
nw_vcov <- nw_vcov_raw * correction

coefs <- coef(model)
lag_names <- paste0("lag_", 1:15)

# Cumulative response: sum of lag_1 through lag_15 coefficients
cum_response <- sum(coefs[lag_names])

# Variance of cumulative response using full covariance matrix
vcov_lags <- nw_vcov[lag_names, lag_names]
ones <- rep(1, 15)
var_cum <- as.numeric(t(ones) %*% vcov_lags %*% ones)
se_cum <- sqrt(var_cum)

se_lag1 <- sqrt(nw_vcov["lag_1", "lag_1"])
se_lag15 <- sqrt(nw_vcov["lag_15", "lag_15"])

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(term = "cumulative_response", estimate = cum_response, se = se_cum, n_obs = N),
    list(term = "lag_1", estimate = unname(coefs["lag_1"]), se = se_lag1, n_obs = N),
    list(term = "lag_15", estimate = unname(coefs["lag_15"]), se = se_lag15, n_obs = N)
  ),
  method_metadata = list(
    estimator = "OLS",
    vcov = "Newey-West HAC, max lag 15, Bartlett weights 1-j/16, multiplied by N/(N-16)"
  ),
  diagnostics = list()
)

write(toJSON(result, auto_unbox = TRUE, digits = 10), "result.json")
