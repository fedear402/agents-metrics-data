library(AER)
library(sandwich)
library(jsonlite)

dat <- read.csv("input.csv")

# One obs per region
regions <- dat[!duplicated(dat$region_id), c("region_id","region_weight","x","y")]
regions$e_r <- regions$region_weight / sum(regions$region_weight)

# Construct shift-share instrument z_r for each region
z_r <- tapply(seq_len(nrow(dat)), dat$region_id, function(idx) {
  sum(dat$share[idx] * dat$shock[idx])
})
regions$z <- z_r[as.character(regions$region_id)]

# Weighted means
wmean <- function(v, w) sum(v * w) / sum(w)
e <- regions$e_r
y_mean <- wmean(regions$y, e)
x_mean <- wmean(regions$x, e)
z_mean <- wmean(regions$z, e)

regions$y0 <- regions$y - y_mean
regions$x0 <- regions$x - x_mean
regions$z0 <- regions$z - z_mean

# Industry-level aggregation
industries <- unique(dat$industry_id)
N <- length(industries)

# For each industry, s_n and aggregated residuals
ind_df <- data.frame(industry_id = industries)
ind_df$shock <- dat$shock[match(industries, dat$industry_id)]

s_n <- numeric(N)
ybar_n <- numeric(N)
xbar_n <- numeric(N)
zbar_n <- numeric(N)

for (i in seq_len(N)) {
  n <- industries[i]
  rows <- dat$region_id[dat$industry_id == n]
  # match to regions
  ridx <- match(rows, regions$region_id)
  shares_rn <- dat$share[dat$industry_id == n]
  
  s_n[i] <- sum(e[ridx] * shares_rn)
  ybar_n[i] <- sum(e[ridx] * shares_rn * regions$y0[ridx]) / s_n[i]
  xbar_n[i] <- sum(e[ridx] * shares_rn * regions$x0[ridx]) / s_n[i]
  zbar_n[i] <- sum(e[ridx] * shares_rn * regions$z0[ridx]) / s_n[i]
}

ind_df$s_n <- s_n
ind_df$ybar <- ybar_n
ind_df$xbar <- xbar_n
ind_df$zbar <- zbar_n

# HC1 variance multiplier
hc1_mult <- N / (N - 2)

# Effect: shock-level IV of ybar on xbar, instrument = shock, weights = s_n
iv_effect <- ivreg(ybar ~ xbar | shock, data = ind_df, weights = s_n)
# HC1 SE
V_effect <- vcovHC(iv_effect, type = "HC1") * hc1_mult / (N / (N - 2))
# Actually, vcovHC with HC1 already uses n/(n-k) correction. Let me compute manually.
# Manual HC1: residuals from structural equation
beta_effect <- coef(iv_effect)["xbar"]

# Get structural residuals
fitted_y <- cbind(1, ind_df$xbar) %*% c(coef(iv_effect)["(Intercept)"], coef(iv_effect)["xbar"])
resid_effect <- ind_df$ybar - as.vector(fitted_y)

# Instruments matrix
Z_mat <- cbind(1, ind_df$shock)
X_mat <- cbind(1, ind_df$xbar)
W <- diag(ind_df$s_n)

# 2SLS formula: (X'PZ X)^{-1} X'PZ Omega PZ X (X'PZ X)^{-1}
PZ_X <- Z_mat %*% solve(t(Z_mat) %*% W %*% Z_mat) %*% t(Z_mat) %*% W %*% X_mat
bread <- solve(t(PZ_X) %*% X_mat)

# Meat with HC1
meat_terms <- sapply(seq_len(N), function(i) {
  z_i <- Z_mat[i,]
  x_i <- X_mat[i,]
  u_i <- resid_effect[i]
  w_i <- ind_df$s_n[i]
  outer(w_i * z_i * u_i, w_i * z_i * u_i)
}, simplify = FALSE)

# Actually for weighted IV, let me use sandwich approach more carefully
# Use ivreg vcovHC directly and apply HC1 multiplier manually
# vcovHC with type="HC0" then multiply by N/(N-2)
V_effect_hc0 <- vcovHC(iv_effect, type = "HC0")
V_effect_hc1 <- V_effect_hc0 * hc1_mult
se_effect <- sqrt(V_effect_hc1["xbar", "xbar"])

# First stage: shock-level IV of xbar on zbar, instrument = shock, weights = s_n
iv_fs <- ivreg(xbar ~ zbar | shock, data = ind_df, weights = s_n)
beta_fs <- coef(iv_fs)["zbar"]
V_fs_hc0 <- vcovHC(iv_fs, type = "HC0")
V_fs_hc1 <- V_fs_hc0 * hc1_mult
se_fs <- sqrt(V_fs_hc1["zbar", "zbar"])

# Effective shocks
eff_shocks <- 1 / sum(s_n^2)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = unname(beta_effect), se = unname(se_effect), n_obs = N),
    list(term = "first_stage", estimate = unname(beta_fs), se = unname(se_fs), n_obs = N),
    list(term = "effective_shocks", estimate = eff_shocks, se = NULL, n_obs = N)
  ),
  method_metadata = list(
    estimator = "2SLS shift-share with Borusyak-Hull-Jaravel exposure-robust SE",
    vcov = "HC1 shock-level"
  ),
  diagnostics = setNames(list(), character(0))
)

write(toJSON(result, auto_unbox = TRUE, digits = 10, null = "null"), "result.json")
