library(jsonlite)

df <- read.csv("input.csv")

# One obs per region for weights
regions <- unique(df[, c("region_id", "region_weight", "x", "y")])
total_weight <- sum(regions$region_weight)
regions$e_r <- regions$region_weight / total_weight

# Construct shift-share instrument z_r = sum_n share_rn * shock_n
df_tmp <- merge(df, regions[, c("region_id", "e_r")], by = "region_id")
df_tmp$share_shock <- df_tmp$share * df_tmp$shock
z_r <- aggregate(share_shock ~ region_id, data = df_tmp, FUN = sum)
names(z_r)[2] <- "z_r"
regions <- merge(regions, z_r, by = "region_id")

# Weighted means
wmean <- function(x, w) sum(w * x) / sum(w)
mean_y <- wmean(regions$y, regions$e_r)
mean_x <- wmean(regions$x, regions$e_r)
mean_z <- wmean(regions$z_r, regions$e_r)

# Demeaned residuals
regions$y0 <- regions$y - mean_y
regions$x0 <- regions$x - mean_x
regions$z0 <- regions$z_r - mean_z

# Merge region info (e_r, residuals) into df_tmp (which already has e_r)
# df_tmp already has e_r; now add y0, x0, z0
df_merged <- merge(df_tmp, regions[, c("region_id", "y0", "x0", "z0")], by = "region_id")

# s_n = sum_r e_r * share_rn
df_merged$w_share <- df_merged$e_r * df_merged$share

s_n_df <- aggregate(w_share ~ industry_id, data = df_merged, FUN = sum)
names(s_n_df)[2] <- "s_n"

df_merged <- merge(df_merged, s_n_df, by = "industry_id")

df_merged$wy0 <- df_merged$w_share * df_merged$y0
df_merged$wx0 <- df_merged$w_share * df_merged$x0
df_merged$wz0 <- df_merged$w_share * df_merged$z0

ybar_num <- aggregate(wy0 ~ industry_id, data = df_merged, FUN = sum)
xbar_num <- aggregate(wx0 ~ industry_id, data = df_merged, FUN = sum)
zbar_num <- aggregate(wz0 ~ industry_id, data = df_merged, FUN = sum)

ind_df <- merge(s_n_df, ybar_num, by = "industry_id")
ind_df <- merge(ind_df, xbar_num, by = "industry_id")
ind_df <- merge(ind_df, zbar_num, by = "industry_id")

ind_df$ybar <- ind_df$wy0 / ind_df$s_n
ind_df$xbar <- ind_df$wx0 / ind_df$s_n
ind_df$zbar <- ind_df$wz0 / ind_df$s_n

# Merge shocks (constant within industry)
shocks <- unique(df[, c("industry_id", "shock")])
ind_df <- merge(ind_df, shocks, by = "industry_id")

mass <- ind_df$s_n
shock_vec <- ind_df$shock
N <- nrow(ind_df)

# Shock-level IV regression
shock_iv <- function(dependent, endogenous) {
  regressors <- cbind(1, endogenous)
  instruments <- cbind(1, shock_vec)
  
  cross <- crossprod(instruments, mass * regressors)
  beta <- solve(cross, crossprod(instruments, mass * dependent))
  
  residual <- drop(dependent - regressors %*% beta)
  scores <- instruments * (mass * residual)
  inverse <- solve(cross)
  
  covariance <- N / (N - 2) * inverse %*% crossprod(scores) %*% t(inverse)
  c(slope = beta[2], se = sqrt(covariance[2, 2]))
}

effect_res <- shock_iv(ind_df$ybar, ind_df$xbar)
firststage_res <- shock_iv(ind_df$xbar, ind_df$zbar)
effective_shocks <- 1 / sum(mass^2)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = unname(effect_res["slope"]), se = unname(effect_res["se"]), n_obs = as.integer(N)),
    list(term = "first_stage", estimate = unname(firststage_res["slope"]), se = unname(firststage_res["se"]), n_obs = as.integer(N)),
    list(term = "effective_shocks", estimate = unname(effective_shocks), se = NULL, n_obs = as.integer(N))
  ),
  method_metadata = list(estimator = "shock_level_IV_2SLS", vcov = "HC1_exposure_robust"),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
