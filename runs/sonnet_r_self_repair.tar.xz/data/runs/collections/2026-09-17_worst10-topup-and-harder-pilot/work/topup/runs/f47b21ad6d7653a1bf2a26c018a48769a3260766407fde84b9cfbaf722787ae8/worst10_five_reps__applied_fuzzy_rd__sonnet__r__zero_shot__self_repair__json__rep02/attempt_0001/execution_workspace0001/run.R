library(sandwich)
library(jsonlite)

dat <- read.csv("input.csv")
names(dat) <- trimws(names(dat))

# Apply bandwidth filter and triangular weights
dat <- dat[abs(dat$score) < 1, ]
dat$w <- 1 - abs(dat$score)
dat$above <- as.integer(dat$score >= 0)

n_obs <- nrow(dat)

# Create interaction terms for local linear on each side
dat$score_above <- dat$score * dat$above

# Fit reduced form: earnings ~ above + score + score:above
rf_fit <- lm(earnings ~ above + score + score_above, data = dat, weights = w)

# Fit first stage: participated ~ above + score + score:above
fs_fit <- lm(participated ~ above + score + score_above, data = dat, weights = w)

# HC0 robust standard errors
vcov_rf <- vcovHC(rf_fit, type = "HC0")
vcov_fs <- vcovHC(fs_fit, type = "HC0")

# Discontinuities are coefficients on 'above'
rf_est <- coef(rf_fit)["above"]
fs_est <- coef(fs_fit)["above"]

rf_se <- sqrt(vcov_rf["above", "above"])
fs_se <- sqrt(vcov_fs["above", "above"])

# Delta method for treatment effect = rf/fs
# Need joint covariance of rf and fs discontinuity estimates
# Stack the two regressions and compute joint sandwich estimator

# Both use same observations and weights, so we can compute cross-covariance
# using the meat of the sandwich estimator

X <- model.matrix(rf_fit)
w_vec <- dat$w

# Residuals
e_rf <- residuals(rf_fit)
e_fs <- residuals(fs_fit)

# Bread for rf
bread_rf <- solve(t(X * w_vec) %*% X)
# Bread for fs (same X)
bread_fs <- bread_rf  # same design matrix

# Meat matrices
# For cross-covariance: E[score_rf * score_fs] where score = X'e
meat_cross <- t(X * (w_vec * e_rf)) %*% (X * (w_vec * e_fs))

# Cross-covariance of coefficients
cov_cross <- bread_rf %*% meat_cross %*% bread_fs

# Covariance of 'above' coefficient between rf and fs
cov_rf_fs <- cov_cross["above", "above"]

# Delta method: te = rf/fs
# d(te)/d(rf) = 1/fs
# d(te)/d(fs) = -rf/fs^2
te_est <- rf_est / fs_est
d_rf <- 1 / fs_est
d_fs <- -rf_est / fs_est^2

var_rf <- vcov_rf["above", "above"]
var_fs <- vcov_fs["above", "above"]

var_te <- d_rf^2 * var_rf + d_fs^2 * var_fs + 2 * d_rf * d_fs * cov_rf_fs
te_se <- sqrt(var_te)

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = unname(te_est), se = unname(te_se), n_obs = n_obs),
    list(term = "reduced_form", estimate = unname(rf_est), se = unname(rf_se), n_obs = n_obs),
    list(term = "first_stage", estimate = unname(fs_est), se = unname(fs_se), n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "fuzzy_rd_local_linear_triangular",
    vcov = "HC0"
  ),
  diagnostics = setNames(list(), character(0))
)

write(toJSON(result, auto_unbox = TRUE, digits = 10), "result.json")
