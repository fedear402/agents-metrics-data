library(sandwich)
library(jsonlite)

dat <- read.csv("input.csv")
names(dat) <- trimws(names(dat))

# Apply bandwidth and triangular weights
bw <- 1
dat_bw <- dat[abs(dat$score) < bw, ]
dat_bw$w <- 1 - abs(dat_bw$score)
dat_bw$D <- as.integer(dat_bw$score >= 0)

n_obs <- nrow(dat_bw)

# Fit local linear models with interactions for separate slopes on each side
# Model: outcome ~ D + score + D:score
# The coefficient on D is the discontinuity (right limit - left limit)

fit_rf <- lm(earnings ~ D + score + D:score, data = dat_bw, weights = w)
fit_fs <- lm(participated ~ D + score + D:score, data = dat_bw, weights = w)

# HC0 robust standard errors (no df correction)
vcov_rf <- vcovHC(fit_rf, type = "HC0")
vcov_fs <- vcovHC(fit_fs, type = "HC0")

coef_rf <- coef(fit_rf)
coef_fs <- coef(fit_fs)

est_rf <- coef_rf["D"]
est_fs <- coef_fs["D"]
se_rf <- sqrt(vcov_rf["D", "D"])
se_fs <- sqrt(vcov_fs["D", "D"])

# Treatment effect via delta method (Wald estimator)
# te = est_rf / est_fs
te <- est_rf / est_fs

# For delta method, need joint covariance of (est_rf, est_fs)
# Stack the two models and compute joint sandwich covariance
# Using the meat of the sandwich from both models jointly

# Get model matrices and residuals
X <- model.matrix(fit_rf)
w_vec <- dat_bw$w

e_rf <- residuals(fit_rf)
e_fs <- residuals(fit_fs)

# Weighted scores (meat of sandwich)
# For HC0: V = (X'WX)^{-1} * (sum w_i^2 * e_i^2 * x_i x_i') * (X'WX)^{-1}
# Cross covariance between rf and fs for the D coefficient

XtWX <- t(X) %*% diag(w_vec) %*% X
XtWX_inv <- solve(XtWX)

# Meat cross-term: sum w_i^2 * e_rf_i * e_fs_i * x_i x_i'
meat_cross <- t(X * (w_vec * e_rf)) %*% (X * (w_vec * e_fs))

# Joint covariance of all coefficients (rf, fs)
cov_cross_full <- XtWX_inv %*% meat_cross %*% XtWX_inv

# We want cov(coef_rf["D"], coef_fs["D"])
d_idx <- which(names(coef_rf) == "D")
cov_cross_D <- cov_cross_full[d_idx, d_idx]

# Delta method: var(rf/fs) = (1/fs)^2 * var(rf) + (rf/fs^2)^2 * var(fs) - 2*(rf/fs^3)*cov(rf,fs)
var_rf <- vcov_rf["D", "D"]
var_fs <- vcov_fs["D", "D"]

var_te <- (1/est_fs)^2 * var_rf + (est_rf/est_fs^2)^2 * var_fs - 2*(est_rf/est_fs^3)*cov_cross_D
se_te <- sqrt(var_te)

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = as.numeric(te), se = as.numeric(se_te), n_obs = n_obs),
    list(term = "reduced_form", estimate = as.numeric(est_rf), se = as.numeric(se_rf), n_obs = n_obs),
    list(term = "first_stage", estimate = as.numeric(est_fs), se = as.numeric(se_fs), n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "fuzzy_rd_local_linear_wald",
    vcov = "HC0"
  ),
  diagnostics = list()
)

write(toJSON(result, auto_unbox = TRUE, digits = 10), "result.json")
