library(jsonlite)

df <- read.csv("input.csv")

# Normalize regional weights (one obs per region)
regions <- unique(df[, c("region_id", "region_weight", "x", "y")])
total_weight <- sum(regions$region_weight)
regions$e_r <- regions$region_weight / total_weight

# Merge normalized weights back
df <- merge(df, regions[, c("region_id", "e_r")], by = "region_id")

# Construct shift-share instrument z_r = sum_n share_rn * shock_n
df$share_shock <- df$share * df$shock
z_r <- aggregate(share_shock ~ region_id, data = df, FUN = sum)
names(z_r)[2] <- "z_r"
regions <- merge(regions, z_r, by = "region_id")

# Weighted means
wmean <- function(v, w) sum(v * w) / sum(w)
mean_y <- wmean(regions$y, regions$e_r)
mean_x <- wmean(regions$x, regions$e_r)
mean_z <- wmean(regions$z_r, regions$e_r)

# Demeaned residuals
regions$y0 <- regions$y - mean_y
regions$x0 <- regions$x - mean_x
regions$z0 <- regions$z_r - mean_z

# Industry-level aggregation
industries <- unique(df[, c("industry_id", "shock")])

# s_n = sum_r e_r * share_rn
s_n <- aggregate(e_r * share ~ industry_id, data = df, FUN = sum)
names(s_n)[2] <- "s_n"

# Merge region residuals into df
df <- merge(df, regions[, c("region_id", "y0", "x0", "z0")], by = "region_id")

# ybar_n, xbar_n, zbar_n = sum_r e_r * share_rn * v0_r / s_n
agg_y <- aggregate(e_r * share * y0 ~ industry_id, data = df, FUN = sum)
agg_x <- aggregate(e_r * share * x0 ~ industry_id, data = df, FUN = sum)
agg_z <- aggregate(e_r * share * z0 ~ industry_id, data = df, FUN = sum)
names(agg_y)[2] <- "num_y"
names(agg_x)[2] <- "num_x"
names(agg_z)[2] <- "num_z"

shock_data <- merge(industries, s_n, by = "industry_id")
shock_data <- merge(shock_data, agg_y, by = "industry_id")
shock_data <- merge(shock_data, agg_x, by = "industry_id")
shock_data <- merge(shock_data, agg_z, by = "industry_id")

shock_data$ybar <- shock_data$num_y / shock_data$s_n
shock_data$xbar <- shock_data$num_x / shock_data$s_n
shock_data$zbar <- shock_data$num_z / shock_data$s_n

N <- nrow(shock_data)
mass <- shock_data$s_n

# Shock-level IV: regress ybar on (1, xbar), instrument xbar with shock, weight s_n
shock_iv <- function(dependent, endogenous, instrument_var, weights) {
  regressors <- cbind(1, endogenous)
  instruments <- cbind(1, instrument_var)
  cross <- crossprod(instruments, weights * regressors)
  beta <- solve(cross, crossprod(instruments, weights * dependent))
  residual <- drop(dependent - regressors %*% beta)
  scores <- instruments * (weights * residual)
  inverse <- solve(cross)
  covariance <- N / (N - 2) * inverse %*% crossprod(scores) %*% t(inverse)
  c(slope = beta[2], se = sqrt(covariance[2, 2]))
}

# Effect: IV of ybar on xbar, instrument = shock
effect_res <- shock_iv(shock_data$ybar, shock_data$xbar, shock_data$shock, mass)

# First stage relevance: IV of xbar on zbar, instrument = shock (zbar is endogenous)
fs_res <- shock_iv(shock_data$xbar, shock_data$zbar, shock_data$shock, mass)

# Effective shocks
effective_shocks <- 1 / sum(mass^2)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = unname(effect_res["slope"]), se = unname(effect_res["se"]), n_obs = as.integer(N)),
    list(term = "first_stage", estimate = unname(fs_res["slope"]), se = unname(fs_res["se"]), n_obs = as.integer(N)),
    list(term = "effective_shocks", estimate = effective_shocks, se = NULL, n_obs = as.integer(N))
  ),
  method_metadata = list(estimator = "2SLS shift-share IV", vcov = "HC1 shock-level exposure-robust"),
  diagnostics = setNames(list(), character(0))
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
