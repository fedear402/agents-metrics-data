library(sandwich)
library(jsonlite)

df <- read.csv("input.csv")
df <- df[order(df$date), ]

df$log_sales <- log(df$sales)
df$log_vix <- log(df$vix)
df$d_log_vix <- c(NA, diff(df$log_vix))

for (k in 1:15) {
  df[[paste0("lag_", k)]] <- c(rep(NA, k), df$d_log_vix[1:(nrow(df) - k)])
}

lag_cols <- paste0("lag_", 1:15)
formula_str <- paste("log_sales ~", paste(lag_cols, collapse = " + "))
model_df <- df[complete.cases(df[, c("log_sales", lag_cols)]), ]

fit <- lm(as.formula(formula_str), data = model_df)
N <- nrow(model_df)

# Newey-West with Bartlett weights 1-j/16 for lag j, max lag 15
# sandwich::NeweyWest uses bwNeweyWest by default; we set manually
nw_vcov <- NeweyWest(fit, lag = 15, prewhite = FALSE, adjust = FALSE,
                     weights = function(j, ...) 1 - j/16,
                     sandwich = TRUE)

# Multiply by N/(N-16)
nw_vcov <- nw_vcov * (N / (N - 16))

coefs <- coef(fit)

# Cumulative response: sum of lag_1 through lag_15
lag_names <- paste0("lag_", 1:15)
cum_resp <- sum(coefs[lag_names])

# SE for cumulative response using full covariance matrix
e <- rep(1, 15)
names(e) <- lag_names
var_cum <- as.numeric(t(e) %*% nw_vcov[lag_names, lag_names] %*% e)
se_cum <- sqrt(var_cum)

se_lag1 <- sqrt(nw_vcov["lag_1", "lag_1"])
se_lag15 <- sqrt(nw_vcov["lag_15", "lag_15"])

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(term = "cumulative_response", estimate = cum_resp, se = se_cum, n_obs = N),
    list(term = "lag_1", estimate = unname(coefs["lag_1"]), se = se_lag1, n_obs = N),
    list(term = "lag_15", estimate = unname(coefs["lag_15"]), se = se_lag15, n_obs = N)
  ),
  method_metadata = list(
    estimator = "OLS",
    vcov = "Newey-West HAC, max lag 15, Bartlett weights 1-j/16, adjusted N/(N-16)"
  ),
  diagnostics = list()
)

write(toJSON(result, auto_unbox = TRUE, digits = 10), "result.json")
