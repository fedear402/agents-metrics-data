library(sandwich)
library(jsonlite)

data <- read.csv("input.csv")
names(data) <- trimws(names(data))

# Apply bandwidth and triangular weights
bw <- 1
data_bw <- data[abs(data$score) < bw, ]
data_bw$w <- 1 - abs(data_bw$score)
data_bw$D <- as.integer(data_bw$score >= 0)

n_obs <- nrow(data_bw)

# Design matrix for local linear on both sides
# Model: y = a0 + a1*D + a2*score + a3*(D*score)
X <- model.matrix(~ D + score + I(D * score), data = data_bw)
W <- diag(data_bw$w)

# WLS via weighted regression
fit_wls <- function(y, X, W) {
  XtW <- t(X) %*% W
  XtWX <- XtW %*% X
  XtWy <- XtW %*% y
  beta <- solve(XtWX, XtWy)
  fitted <- X %*% beta
  resid <- y - fitted
  list(beta = beta, resid = resid, XtWX_inv = solve(XtWX), X = X, W = W, resid = resid)
}

# HC0 robust SE (sandwich, no df correction)
hc0_vcov <- function(fit) {
  X <- fit$X
  W <- fit$W
  e <- fit$resid
  XtW <- t(X) %*% W
  XtWX_inv <- fit$XtWX_inv
  # Meat: sum_i w_i^2 * e_i^2 * x_i x_i'
  We <- as.vector(diag(W)) * as.vector(e)
  meat <- t(X) %*% diag(We^2) %*% X
  XtWX_inv %*% meat %*% XtWX_inv
}

y_earn <- data_bw$earnings
y_part <- data_bw$participated

fit_earn <- fit_wls(y_earn, X, W)
fit_part <- fit_wls(y_part, X, W)

# Discontinuity is coefficient on D (index 2, since intercept is 1)
rf_est <- fit_earn$beta[2]
fs_est <- fit_part$beta[2]

vcov_earn <- hc0_vcov(fit_earn)
vcov_part <- hc0_vcov(fit_part)

rf_se <- sqrt(vcov_earn[2, 2])
fs_se <- sqrt(vcov_part[2, 2])

# Delta method for treatment_effect = rf / fs
# Need cross-covariance between rf and fs estimates
# Cross-covariance of beta_earn[2] and beta_part[2]:
# Cov = XtWX_inv_earn * (cross-meat) * XtWX_inv_part
# cross-meat: sum_i w_i^2 * e_earn_i * e_part_i * x_i x_i'

XtWX_inv_earn <- fit_earn$XtWX_inv
XtWX_inv_part <- fit_part$XtWX_inv
w_vec <- as.vector(diag(W))
e_earn <- as.vector(fit_earn$resid)
e_part <- as.vector(fit_part$resid)

cross_meat <- t(X) %*% diag(w_vec^2 * e_earn * e_part) %*% X
cross_vcov <- XtWX_inv_earn %*% cross_meat %*% XtWX_inv_part

cov_rf_fs <- cross_vcov[2, 2]

# Delta method: Var(rf/fs) = (1/fs)^2 * Var(rf) - 2*(rf/fs^2)*Cov(rf,fs) + (rf/fs)^2*(1/fs)^2*Var(fs)... 
# Standard delta method: let g = rf/fs
# Var(g) = (dg/drf)^2 * Var(rf) + (dg/dfs)^2 * Var(fs) + 2*(dg/drf)*(dg/dfs)*Cov(rf,fs)
# dg/drf = 1/fs, dg/dfs = -rf/fs^2
te_est <- rf_est / fs_est
d_rf <- 1 / fs_est
d_fs <- -rf_est / fs_est^2
te_var <- d_rf^2 * vcov_earn[2, 2] + d_fs^2 * vcov_part[2, 2] + 2 * d_rf * d_fs * cov_rf_fs
te_se <- sqrt(te_var)

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = as.numeric(te_est), se = as.numeric(te_se), n_obs = n_obs),
    list(term = "reduced_form", estimate = as.numeric(rf_est), se = as.numeric(rf_se), n_obs = n_obs),
    list(term = "first_stage", estimate = as.numeric(fs_est), se = as.numeric(fs_se), n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "fuzzy_rd_local_linear_triangular",
    vcov = "HC0"
  ),
  diagnostics = list()
)

write(toJSON(result, auto_unbox = TRUE, digits = 10), "result.json")
