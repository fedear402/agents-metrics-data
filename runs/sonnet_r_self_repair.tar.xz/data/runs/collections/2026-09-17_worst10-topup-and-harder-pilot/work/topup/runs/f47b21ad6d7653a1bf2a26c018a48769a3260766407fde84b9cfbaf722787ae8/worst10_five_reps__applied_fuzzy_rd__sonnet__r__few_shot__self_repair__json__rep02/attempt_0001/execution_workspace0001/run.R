library(jsonlite)

dat <- read.csv("input.csv")
names(dat) <- trimws(names(dat))

bw <- 1
in_bw <- abs(dat$score) < bw
dat_bw <- dat[in_bw, ]
n_obs <- nrow(dat_bw)

w <- 1 - abs(dat_bw$score)
above <- as.integer(dat_bw$score >= 0)

# Design matrix: intercept, score, above indicator, above*score (separate slopes)
X <- cbind(1, dat_bw$score, above, above * dat_bw$score)

Y_earn <- dat_bw$earnings
Y_part <- dat_bw$participated

WX <- w * X
bread <- solve(t(X) %*% WX)

coef_earn <- bread %*% (t(WX) %*% Y_earn)
coef_part <- bread %*% (t(WX) %*% Y_part)

resid_earn <- Y_earn - X %*% coef_earn
resid_part <- Y_part - X %*% coef_part

# Contrast for right-minus-left limit at cutoff (score=0): c(0,0,1,0)
contrast <- c(0, 0, 1, 0)

jump_earn <- drop(contrast %*% coef_earn)
jump_part <- drop(contrast %*% coef_part)

# HC0 sandwich
loading <- w * drop(X %*% bread %*% contrast)

inf_earn <- loading * resid_earn
inf_part <- loading * resid_part

joint <- matrix(c(
  sum(inf_earn^2), sum(inf_earn * inf_part),
  sum(inf_earn * inf_part), sum(inf_part^2)
), 2, 2)

se_earn <- sqrt(joint[1, 1])
se_part <- sqrt(joint[2, 2])

# Delta method for ratio = jump_earn / jump_part
ratio <- jump_earn / jump_part
grad <- c(1 / jump_part, -jump_earn / jump_part^2)
se_ratio <- sqrt(drop(t(grad) %*% joint %*% grad))

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = unname(ratio), se = unname(se_ratio), n_obs = as.integer(n_obs)),
    list(term = "reduced_form", estimate = unname(jump_earn), se = unname(se_earn), n_obs = as.integer(n_obs)),
    list(term = "first_stage", estimate = unname(jump_part), se = unname(se_part), n_obs = as.integer(n_obs))
  ),
  method_metadata = list(estimator = "fuzzy_rd_local_linear", vcov = "HC0"),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, digits = 16, pretty = TRUE)
