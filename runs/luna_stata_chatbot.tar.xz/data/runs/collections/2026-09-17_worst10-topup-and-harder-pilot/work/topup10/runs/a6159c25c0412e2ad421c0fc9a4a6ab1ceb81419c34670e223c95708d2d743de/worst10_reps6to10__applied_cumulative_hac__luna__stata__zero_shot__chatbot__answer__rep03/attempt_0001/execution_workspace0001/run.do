clear all
set more off
set linesize 255

import delimited "./input.csv", clear

capture confirm string variable date
if !_rc {
    gen double __sort_date = date(date, "YMD")
}
else {
    gen double __sort_date = date
}

sort __sort_date
gen long __t = _n
tsset __t

gen double __ln_sales = ln(sales)
gen double __ln_vix   = ln(vix)
gen double __dvix     = D.__ln_vix

forvalues j = 1/15 {
    gen double lag_`j' = L`j'.__dvix
}

regress __ln_sales lag_1-lag_15 if __t >= 17
scalar N = e(N)

predict double __resid if e(sample), residual

mata:
    real matrix X, V, meat
    real colvector u, x_t, x_lag
    real scalar n, k, j, t, w
    X = st_data(., tokens("lag_1 lag_2 lag_3 lag_4 lag_5 lag_6 lag_7 lag_8 lag_9 lag_10 lag_11 lag_12 lag_13 lag_14 lag_15"), "e(sample)")
    u = st_data(., "__resid", "e(sample)")
    X = X, J(rows(X), 1, 1)
    X = X[., (16, 1..15)]
    n = rows(X)
    k = cols(X)
    meat = J(k, k, 0)

    for (t = 1; t <= n; t++) {
        x_t = X[t, .]'
        meat = meat + u[t]^2 * (x_t * x_t')
    }

    for (j = 1; j <= 15; j++) {
        w = 1 - j/16
        for (t = j + 1; t <= n; t++) {
            x_t = X[t, .]'
            x_lag = X[t-j, .]'
            meat = meat + w * u[t] * u[t-j] * (x_t * x_lag' + x_lag * x_t')
        }
    }

    V = invsym(cross(X, X)) * meat * invsym(cross(X, X)) * n/(n-16)
    st_matrix("Vhac", V)
end

scalar b_lag1  = _b[lag_1]
scalar b_lag15 = _b[lag_15]
scalar b_cum   = 0

forvalues j = 1/15 {
    scalar b_cum = b_cum + _b[lag_`j']
}

mata:
    real colvector c
    c = J(16, 1, 0)
    c[|2\16|] = J(15, 1, 1)
    st_numscalar("se_cum", sqrt(c' * st_matrix("Vhac") * c))
    st_numscalar("se_lag1", sqrt(st_matrix("Vhac")[2,2]))
    st_numscalar("se_lag15", sqrt(st_matrix("Vhac")[16,16]))
end

display "ANSWER: cumulative_response estimate=" %21.12f b_cum " se=" %21.12f se_cum " n_obs=" %12.0f N
display "ANSWER: lag_1 estimate=" %21.12f b_lag1 " se=" %21.12f se_lag1 " n_obs=" %12.0f N
display "ANSWER: lag_15 estimate=" %21.12f b_lag15 " se=" %21.12f se_lag15 " n_obs=" %12.0f N
