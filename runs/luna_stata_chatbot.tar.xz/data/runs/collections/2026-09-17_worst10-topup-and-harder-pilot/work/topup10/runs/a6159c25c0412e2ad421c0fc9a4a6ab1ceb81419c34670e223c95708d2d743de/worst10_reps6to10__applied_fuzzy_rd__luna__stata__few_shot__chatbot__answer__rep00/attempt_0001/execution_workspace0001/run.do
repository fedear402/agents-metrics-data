version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

keep if !missing(score, participated, earnings)
keep if abs(score) < 1

count
local n_obs = r(N)

mata:
x = st_data(., "score")
w = 1 :- abs(x)
left = x :< 0
right = x :>= 0

X = (left, left:*x, right, right:*x)
Y = st_data(., ("earnings", "participated"))

bread = invsym(X' * (w:*X))
B = bread * X' * (w:*Y)
residuals = Y - X*B

contrast = (-1 \ 0 \ 1 \ 0)
discontinuities = contrast' * B

loading = X * bread * contrast
influence = (w:*loading) :* residuals
joint = influence' * influence

reduced_form = discontinuities[1]
first_stage = discontinuities[2]
treatment_effect = reduced_form / first_stage

gradient = (1/first_stage \ -reduced_form/(first_stage^2))
treatment_se = sqrt(gradient' * joint * gradient)
reduced_se = sqrt(joint[1,1])
first_se = sqrt(joint[2,2])

st_numscalar("reduced_form", reduced_form)
st_numscalar("reduced_se", reduced_se)
st_numscalar("first_stage", first_stage)
st_numscalar("first_se", first_se)
st_numscalar("treatment_effect", treatment_effect)
st_numscalar("treatment_se", treatment_se)
end

display "ANSWER: treatment_effect estimate=" %21.12f scalar(treatment_effect) " se=" %21.12f scalar(treatment_se) " n_obs=" %12.0f `n_obs'
display "ANSWER: reduced_form estimate=" %21.12f scalar(reduced_form) " se=" %21.12f scalar(reduced_se) " n_obs=" %12.0f `n_obs'
display "ANSWER: first_stage estimate=" %21.12f scalar(first_stage) " se=" %21.12f scalar(first_se) " n_obs=" %12.0f `n_obs'
