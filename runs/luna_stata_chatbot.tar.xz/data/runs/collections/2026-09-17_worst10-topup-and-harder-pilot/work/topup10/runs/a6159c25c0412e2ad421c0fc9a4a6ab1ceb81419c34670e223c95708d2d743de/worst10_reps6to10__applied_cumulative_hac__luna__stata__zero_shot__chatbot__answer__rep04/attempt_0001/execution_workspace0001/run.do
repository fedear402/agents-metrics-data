clear all
set linesize 255

import delimited using "./input.csv", clear

sort date

gen double lnsales = ln(sales)
gen double lnvix   = ln(vix)
gen double dlnvix  = lnvix - lnvix[_n-1]

forvalues j = 1/15 {
    gen double lag_`j' = dlnvix[_n-`j']
}

gen byte touse = !missing(lnsales, lag_1, lag_2, lag_3, lag_4, lag_5, ///
    lag_6, lag_7, lag_8, lag_9, lag_10, lag_11, lag_12, lag_13, lag_14, lag_15)

regress lnsales lag_1-lag_15 if touse
predict double ols_resid if e(sample), residuals

mata:
    string scalar xvars
    real matrix X, V, XXi, S, a, b
    real colvector y, u, beta, one
    real scalar N, K, j, t, w, estimate, se

    xvars = "lag_1 lag_2 lag_3 lag_4 lag_5 lag_6 lag_7 lag_8 lag_9 lag_10 lag_11 lag_12 lag_13 lag_14 lag_15"
    X = st_data(., tokens(xvars), "touse")
    y = st_data(., "lnsales", "touse")
    u = st_data(., "ols_resid", "touse")

    N = rows(X)
    K = cols(X)
    X = X, J(N, 1, 1)
    X = X[., (K + 1, 1..K)]
    K = cols(X)

    beta = invsym(X' * X) * X' * y
    XXi = invsym(X' * X)
    S = X' * diag(u:^2) * X

    for (j = 1; j <= 15; j++) {
        w = 1 - j / 16
        for (t = j + 1; t <= N; t++) {
            a = X[t, .]' * u[t]
            b = X[t - j, .]' * u[t - j]
            S = S + w * (a * b' + b * a')
        }
    }

    V = (N / (N - 16)) * XXi * S * XXi

    one = J(K, 1, 0)
    one[2..16] = J(15, 1, 1)

    estimate = one' * beta
    se = sqrt(one' * V * one)

    st_numscalar("cumulative_estimate", estimate)
    st_numscalar("cumulative_se", se)
    st_numscalar("lag1_estimate", beta[2])
    st_numscalar("lag1_se", sqrt(V[2, 2]))
    st_numscalar("lag15_estimate", beta[16])
    st_numscalar("lag15_se", sqrt(V[16, 16]))
    st_numscalar("n_obs_result", N)
end

display "ANSWER: cumulative_response estimate=" %21.12f scalar(cumulative_estimate) ///
    " se=" %21.12f scalar(cumulative_se) ///
    " n_obs=" %12.0f scalar(n_obs_result)

display "ANSWER: lag_1 estimate=" %21.12f scalar(lag1_estimate) ///
    " se=" %21.12f scalar(lag1_se) ///
    " n_obs=" %12.0f scalar(n_obs_result)

display "ANSWER: lag_15 estimate=" %21.12f scalar(lag15_estimate) ///
    " se=" %21.12f scalar(lag15_se) ///
    " n_obs=" %12.0f scalar(n_obs_result)
