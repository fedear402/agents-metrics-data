version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

keep if abs(score) < 1
generate double tri_weight = 1 - abs(score)

mata:
    y = st_data(., ("earnings", "participated"))
    xscore = st_data(., "score")
    w = st_data(., "tri_weight")

    left = xscore :< 0
    right = xscore :>= 0
    X = (left, left:*xscore, right, right:*xscore)

    bread = invsym(X' * (w :* X))
    coefficients = bread * X' * (w :* y)
    residuals = y - X * coefficients

    contrast = (-1 \ 0 \ 1 \ 0)
    discontinuities = contrast' * coefficients

    loading = X * bread * contrast
    influence = (w :* loading) :* residuals
    joint_covariance = influence' * influence

    reduced_form = discontinuities[1]
    first_stage = discontinuities[2]
    treatment_effect = reduced_form / first_stage

    gradient = (1 / first_stage \ -reduced_form / first_stage^2)
    treatment_variance = gradient' * joint_covariance * gradient

    st_numscalar("reduced_form_value", reduced_form)
    st_numscalar("reduced_form_se", sqrt(joint_covariance[1,1]))
    st_numscalar("first_stage_value", first_stage)
    st_numscalar("first_stage_se", sqrt(joint_covariance[2,2]))
    st_numscalar("treatment_effect_value", treatment_effect)
    st_numscalar("treatment_effect_se", sqrt(treatment_variance))
    st_numscalar("n_obs_value", rows(y))
end

display "ANSWER: treatment_effect estimate=" %21.12f treatment_effect_value " se=" %21.12f treatment_effect_se " n_obs=" %12.0f n_obs_value
display "ANSWER: reduced_form estimate=" %21.12f reduced_form_value " se=" %21.12f reduced_form_se " n_obs=" %12.0f n_obs_value
display "ANSWER: first_stage estimate=" %21.12f first_stage_value " se=" %21.12f first_stage_se " n_obs=" %12.0f n_obs_value
