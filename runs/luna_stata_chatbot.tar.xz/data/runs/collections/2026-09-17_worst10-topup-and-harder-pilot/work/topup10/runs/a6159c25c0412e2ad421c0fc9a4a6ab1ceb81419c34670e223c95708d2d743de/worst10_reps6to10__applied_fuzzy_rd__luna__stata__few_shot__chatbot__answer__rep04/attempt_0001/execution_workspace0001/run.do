version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", varnames(1) clear

keep if abs(score) < 1
generate double weight = 1 - abs(score)
generate byte right = score >= 0
generate double right_score = right * score

mata:
    y = st_data(., ("earnings", "participated"))
    s = st_data(., ("score", "right", "right_score"))
    w = st_data(., "weight")

    X = (J(rows(y), 1, 1), s)
    W = diag(w)
    bread = invsym(X' * W * X)
    beta = bread * X' * W * y
    residuals = y - X * beta

    contrast = (0 \ 0 \ 1 \ 0)
    jumps = contrast' * beta

    loading = w :* (X * bread * contrast)
    influence = loading :* residuals
    joint = influence' * influence

    gradient = (-jumps[2] / jumps[1]^2 \ 1 / jumps[1])
    ratio = jumps[2] / jumps[1]
    ratio_se = sqrt(gradient' * joint * gradient)

    st_numscalar("reduced_form", jumps[1])
    st_numscalar("reduced_form_se", sqrt(joint[1,1]))
    st_numscalar("first_stage", jumps[2])
    st_numscalar("first_stage_se", sqrt(joint[2,2]))
    st_numscalar("treatment_effect", ratio)
    st_numscalar("treatment_effect_se", ratio_se)
    st_numscalar("n_obs", rows(y))
end

display "ANSWER: treatment_effect estimate=" %21.12f scalar(treatment_effect) " se=" %21.12f scalar(treatment_effect_se) " n_obs=" %12.0f scalar(n_obs)
display "ANSWER: reduced_form estimate=" %21.12f scalar(reduced_form) " se=" %21.12f scalar(reduced_form_se) " n_obs=" %12.0f scalar(n_obs)
display "ANSWER: first_stage estimate=" %21.12f scalar(first_stage) " se=" %21.12f scalar(first_stage_se) " n_obs=" %12.0f scalar(n_obs)
