version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

generate double day = date(date, "YMD")
sort day
generate long observation = _n
tsset observation

generate double log_vix = ln(vix)
generate double volatility_change = D.log_vix
generate double log_sales = ln(sales)

local lagvars
forvalues j = 1/15 {
    generate double lag_`j' = L`j'.volatility_change
    local lagvars `lagvars' lag_`j'
}

keep if !missing(log_sales, `lagvars')

mata:
    X = (J(st_nobs(), 1, 1), st_data(., tokens("`lagvars'")))
    y = st_data(., "log_sales")

    coefficients = qrsolve(X, y)
    residuals = y - X * coefficients

    N = rows(X)
    p = cols(X)
    scores = X :* residuals

    hac_lags = 15
    meat = scores' * scores

    for (j = 1; j <= hac_lags; j++) {
        lag_product = scores[|j + 1, 1 \ N, p|]' * scores[|1, 1 \ N - j, p|]
        meat = meat + (1 - j / 16) * (lag_product + lag_product')
    }

    bread = invsym(X' * X)
    covariance = N / (N - 16) * bread * meat * bread

    contrast = J(16, 1, 0)
    contrast[|2 \ 16|] = J(15, 1, 1)

    cumulative = contrast' * coefficients
    cumulative_se = sqrt(contrast' * covariance * contrast)

    lag_1_estimate = coefficients[2]
    lag_1_se = sqrt(covariance[2, 2])

    lag_15_estimate = coefficients[16]
    lag_15_se = sqrt(covariance[16, 16])

    st_numscalar("cumulative", cumulative)
    st_numscalar("cumulative_se", cumulative_se)
    st_numscalar("lag_1_estimate", lag_1_estimate)
    st_numscalar("lag_1_se", lag_1_se)
    st_numscalar("lag_15_estimate", lag_15_estimate)
    st_numscalar("lag_15_se", lag_15_se)
    st_numscalar("n_obs", N)
end

display "ANSWER: cumulative_response estimate=" %21.12f scalar(cumulative) ///
    " se=" %21.12f scalar(cumulative_se) " n_obs=" %12.0f scalar(n_obs)

display "ANSWER: lag_1 estimate=" %21.12f scalar(lag_1_estimate) ///
    " se=" %21.12f scalar(lag_1_se) " n_obs=" %12.0f scalar(n_obs)

display "ANSWER: lag_15 estimate=" %21.12f scalar(lag_15_estimate) ///
    " se=" %21.12f scalar(lag_15_se) " n_obs=" %12.0f scalar(n_obs)
