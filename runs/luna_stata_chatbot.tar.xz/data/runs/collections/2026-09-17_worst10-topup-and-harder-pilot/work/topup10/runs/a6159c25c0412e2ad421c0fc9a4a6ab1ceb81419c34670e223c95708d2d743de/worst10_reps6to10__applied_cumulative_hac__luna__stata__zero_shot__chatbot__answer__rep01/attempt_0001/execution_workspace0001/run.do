clear all
set linesize 255

import delimited using "./input.csv", clear

sort date

gen double lnsales = ln(sales)
gen double lnvix = ln(vix)

tsset _n
gen double dlnvix = lnvix - L.lnvix

forvalues j = 1/15 {
    gen double lag_`j' = L`j'.dlnvix
}

drop if missing(lnsales, lag_1, lag_2, lag_3, lag_4, lag_5, ///
    lag_6, lag_7, lag_8, lag_9, lag_10, lag_11, lag_12, lag_13, ///
    lag_14, lag_15)

regress lnsales lag_1-lag_15
predict double residual, residuals

scalar n_obs = e(N)

mata:
    X = st_data(., " _cons lag_1 lag_2 lag_3 lag_4 lag_5 lag_6 lag_7 lag_8 lag_9 lag_10 lag_11 lag_12 lag_13 lag_14 lag_15")
    e = st_data(., "residual")
    n = rows(X)
    k = cols(X)

    Q = J(n, k, 0)
    for (i = 1; i <= n; i++) {
        Q[i,.] = X[i,.] * e[i]
    }

    S = J(k, k, 0)
    for (i = 1; i <= n; i++) {
        S = S + Q[i,.]' * Q[i,.]
    }

    for (h = 1; h <= 15; h++) {
        G = J(k, k, 0)
        for (i = h + 1; i <= n; i++) {
            G = G + Q[i,.]' * Q[i-h,.]
        }
        w = 1 - h/16
        S = S + w * (G + G')
    }

    XXinv = invsym(X' * X)
    V = (n/(n-16)) * XXinv * S * XXinv

    b = st_matrix("e(b)")
    c = J(1, k, 0)
    c[1, 2..16] = J(1, 15, 1)

    cumulative = c * b'
    cumulative_se = sqrt(c * V * c')
    lag1_se = sqrt(V[2,2])
    lag15_se = sqrt(V[16,16])

    st_numscalar("cumulative_response", cumulative[1,1])
    st_numscalar("cumulative_se", cumulative_se[1,1])
    st_numscalar("lag_1_se", lag1_se)
    st_numscalar("lag_15_se", lag15_se)
end

display "ANSWER: cumulative_response estimate=" %21.12f cumulative_response ///
    " se=" %21.12f cumulative_se " n_obs=" %12.0f n_obs

display "ANSWER: lag_1 estimate=" %21.12f _b[lag_1] ///
    " se=" %21.12f lag_1_se " n_obs=" %12.0f n_obs

display "ANSWER: lag_15 estimate=" %21.12f _b[lag_15] ///
    " se=" %21.12f lag_15_se " n_obs=" %12.0f n_obs
