version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear varnames(1)

generate double _day = date(date, "YMD")
sort _day
generate long _observation = _n
tsset _observation

generate double _log_vix = log(vix)
generate double _vix_change = D._log_vix
generate double _log_sales = log(sales)

forvalues j = 1/15 {
    generate double _lag_`j' = L`j'._vix_change
}

keep if !missing(_log_sales, _lag_1, _lag_2, _lag_3, _lag_4, _lag_5, ///
    _lag_6, _lag_7, _lag_8, _lag_9, _lag_10, _lag_11, _lag_12, ///
    _lag_13, _lag_14, _lag_15)

mata:
    y = st_data(., "_log_sales")
    X = (J(rows(y), 1, 1), st_data(., ///
        ("_lag_1", "_lag_2", "_lag_3", "_lag_4", "_lag_5", ///
         "_lag_6", "_lag_7", "_lag_8", "_lag_9", "_lag_10", ///
         "_lag_11", "_lag_12", "_lag_13", "_lag_14", "_lag_15")))

    b = qrsolve(X, y)
    u = y - X*b
    N = rows(X)
    p = cols(X)

    scores = X :* (u * J(1, p, 1))
    meat = scores' * scores

    for (j = 1; j <= 15; j++) {
        lag_product = scores[|j+1, 1 \ N, p|]' * scores[|1, 1 \ N-j, p|]
        meat = meat + (1 - j/16) * (lag_product + lag_product')
    }

    bread = invsym(X' * X)
    V = (N/(N-16)) * bread * meat * bread

    contrast = (0 \ J(15, 1, 1))
    cumulative = contrast' * b
    cumulative_se = sqrt(contrast' * V * contrast)

    st_numscalar("cumulative_value", cumulative)
    st_numscalar("cumulative_se", cumulative_se)
    st_numscalar("lag1_value", b[2])
    st_numscalar("lag1_se", sqrt(V[2,2]))
    st_numscalar("lag15_value", b[16])
    st_numscalar("lag15_se", sqrt(V[16,16]))
    st_numscalar("n_obs", N)
end

display "ANSWER: cumulative_response estimate=" %21.12f scalar(cumulative_value) ///
    " se=" %21.12f scalar(cumulative_se) " n_obs=" %12.0f scalar(n_obs)

display "ANSWER: lag_1 estimate=" %21.12f scalar(lag1_value) ///
    " se=" %21.12f scalar(lag1_se) " n_obs=" %12.0f scalar(n_obs)

display "ANSWER: lag_15 estimate=" %21.12f scalar(lag15_value) ///
    " se=" %21.12f scalar(lag15_se) " n_obs=" %12.0f scalar(n_obs)
