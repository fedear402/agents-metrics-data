clear all
set linesize 255

import delimited "./input.csv", clear

sort date

gen double ln_sales = ln(sales)
gen double ln_vix   = ln(vix)
gen double dln_vix  = ln_vix - ln_vix[_n-1]

forvalues j = 1/15 {
    gen double lag_`j' = dln_vix[_n-`j']
}

regress ln_sales lag_1-lag_15

scalar N_reg = e(N)

predict double __resid if e(sample), residual

mata:
    yvars = "lag_1 lag_2 lag_3 lag_4 lag_5 lag_6 lag_7 lag_8 lag_9 lag_10 lag_11 lag_12 lag_13 lag_14 lag_15"
    X0 = st_data(., yvars, "e(sample)")
    u  = st_data(., "__resid", "e(sample)")
    N  = rows(X0)

    X = J(N, 16, 1)
    X[, 2..16] = X0

    XXi = invsym(X' * X)
    S = X' * diag(u:^2) * X

    for (j = 1; j <= 15; j++) {
        w = 1 - j/16
        S = S + w * (X[(j+1)..N, ]' * diag(u[(j+1)..N] :* u[1..(N-j)]) * X[1..(N-j), ])
        S = S + w * (X[1..(N-j), ]' * diag(u[1..(N-j)] :* u[(j+1)..N]) * X[(j+1)..N, ])
    }

    V = (N/(N-16)) * XXi * S * XXi
    st_matrix("Vnw", V)

    b = st_matrix("e(b)")
    st_numscalar("estimate_lag1", b[1, 2])
    st_numscalar("estimate_lag15", b[1, 16])
    st_numscalar("estimate_cumulative", sum(b[1, 2..16]))

    st_numscalar("se_lag1", sqrt(V[2, 2]))
    st_numscalar("se_lag15", sqrt(V[16, 16]))

    c = J(16, 1, 0)
    c[2..16, 1] = J(15, 1, 1)
    st_numscalar("se_cumulative", sqrt((c' * V * c)[1, 1]))
end

display "ANSWER: cumulative_response estimate=" %21.12f scalar(estimate_cumulative) " se=" %21.12f scalar(se_cumulative) " n_obs=" %12.0f scalar(N_reg)
display "ANSWER: lag_1 estimate=" %21.12f scalar(estimate_lag1) " se=" %21.12f scalar(se_lag1) " n_obs=" %12.0f scalar(N_reg)
display "ANSWER: lag_15 estimate=" %21.12f scalar(estimate_lag15) " se=" %21.12f scalar(se_lag15) " n_obs=" %12.0f scalar(N_reg)
