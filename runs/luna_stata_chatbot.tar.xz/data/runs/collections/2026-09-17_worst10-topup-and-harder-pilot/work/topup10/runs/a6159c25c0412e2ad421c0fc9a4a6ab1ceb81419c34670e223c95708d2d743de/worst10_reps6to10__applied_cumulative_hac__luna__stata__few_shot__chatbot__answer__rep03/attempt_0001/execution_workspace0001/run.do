version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

generate double day = date(date, "YMD")
format day %td
sort day

generate long observation = _n
tsset observation

generate double log_vix = ln(vix)
generate double volatility_change = D.log_vix
generate double log_sales = ln(sales)

forvalues j = 1/15 {
    generate double lag_`j' = L`j'.volatility_change
}

keep if !missing(log_sales, lag_1, lag_2, lag_3, lag_4, lag_5, ///
    lag_6, lag_7, lag_8, lag_9, lag_10, lag_11, lag_12, lag_13, ///
    lag_14, lag_15)

mata:
y = st_data(., "log_sales")
X = (J(rows(y), 1, 1), st_data(., ///
    ("lag_1", "lag_2", "lag_3", "lag_4", "lag_5", ///
     "lag_6", "lag_7", "lag_8", "lag_9", "lag_10", ///
     "lag_11", "lag_12", "lag_13", "lag_14", "lag_15")))

b = qrsolve(X, y)
u = y - X*b
N = rows(X)
p = cols(X)

scores = X :* u
meat = scores' * scores

for (j = 1; j <= 15; j++) {
    lag_product = scores[|j+1, 1 \ N, p|]' * ///
        scores[|1, 1 \ N-j, p|]
    weight = 1 - j/16
    meat = meat + weight * (lag_product + lag_product')
}

bread = invsym(X' * X)
V = N/(N-16) * bread * meat * bread

contrast = J(p, 1, 0)
contrast[|2 \ 16|] = J(15, 1, 1)

cumulative_response = contrast' * b
cumulative_se = sqrt(contrast' * V * contrast)

st_numscalar("cumulative_response", cumulative_response)
st_numscalar("cumulative_se", cumulative_se)
st_numscalar("lag_1_estimate", b[2])
st_numscalar("lag_1_se", sqrt(V[2,2]))
st_numscalar("lag_15_estimate", b[16])
st_numscalar("lag_15_se", sqrt(V[16,16]))
st_numscalar("n_obs", N)
end

display "ANSWER: cumulative_response estimate=" %21.12f scalar(cumulative_response) ///
    " se=" %21.12f scalar(cumulative_se) ///
    " n_obs=" %12.0f scalar(n_obs)

display "ANSWER: lag_1 estimate=" %21.12f scalar(lag_1_estimate) ///
    " se=" %21.12f scalar(lag_1_se) ///
    " n_obs=" %12.0f scalar(n_obs)

display "ANSWER: lag_15 estimate=" %21.12f scalar(lag_15_estimate) ///
    " se=" %21.12f scalar(lag_15_se) ///
    " n_obs=" %12.0f scalar(n_obs)
