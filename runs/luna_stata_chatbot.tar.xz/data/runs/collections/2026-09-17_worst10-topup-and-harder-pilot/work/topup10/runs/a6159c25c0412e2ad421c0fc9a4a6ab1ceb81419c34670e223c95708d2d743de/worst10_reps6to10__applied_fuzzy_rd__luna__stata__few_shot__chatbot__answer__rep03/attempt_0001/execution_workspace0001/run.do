version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear varnames(1)

keep if abs(score) < 1
generate byte right = score >= 0
generate double right_score = right * score
generate double weight = 1 - abs(score)

mata:
    y = st_data(., ("earnings", "participated"))
    s = st_data(., "score")
    r = st_data(., "right")
    rs = st_data(., "right_score")
    w = st_data(., "weight")

    X = (J(rows(y), 1, 1), s, r, rs)
    W = diag(w)
    bread = invsym(X' * W * X)
    beta = bread * X' * W * y
    residuals = y - X * beta

    contrast = (0 \ 0 \ 1 \ 0)
    discontinuities = contrast' * beta
    loading = w :* (X * bread * contrast)
    influence = loading :* residuals
    covariance = influence' * influence

    gradient = (1 / discontinuities[2] \ ///
        -discontinuities[1] / discontinuities[2]^2)
    treatment_se = sqrt(gradient' * covariance * gradient)

    st_numscalar("reduced_form", discontinuities[1])
    st_numscalar("first_stage", discontinuities[2])
    st_numscalar("treatment_effect", discontinuities[1] / discontinuities[2])
    st_numscalar("reduced_form_se", sqrt(covariance[1,1]))
    st_numscalar("first_stage_se", sqrt(covariance[2,2]))
    st_numscalar("treatment_effect_se", treatment_se)
    st_numscalar("n_obs", rows(y))
end

display "ANSWER: treatment_effect estimate=" %21.12f scalar(treatment_effect) ///
    " se=" %21.12f scalar(treatment_effect_se) ///
    " n_obs=" %12.0f scalar(n_obs)

display "ANSWER: reduced_form estimate=" %21.12f scalar(reduced_form) ///
    " se=" %21.12f scalar(reduced_form_se) ///
    " n_obs=" %12.0f scalar(n_obs)

display "ANSWER: first_stage estimate=" %21.12f scalar(first_stage) ///
    " se=" %21.12f scalar(first_stage_se) ///
    " n_obs=" %12.0f scalar(n_obs)
