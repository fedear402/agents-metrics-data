version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

keep if abs(score) < 1
count
local n_obs = r(N)

generate double weight = 1 - abs(score)
generate double left = score < 0
generate double right = score >= 0

generate double left_score = left * score
generate double right_score = right * score

mata:
X = st_data(., ("left", "left_score", "right", "right_score"))
w = st_data(., "weight")
Y = st_data(., ("earnings", "participated"))

bread = invsym(X' * (w :* X))
B = bread * X' * (w :* Y)
residuals = Y - X * B

contrast = (-1 \ 0 \ 1 \ 0)
discontinuities = contrast' * B

loading = w :* (X * bread * contrast)
influence = loading :* residuals
joint_covariance = influence' * influence

reduced_form = discontinuities[1,1]
first_stage = discontinuities[1,2]
treatment_effect = reduced_form / first_stage

gradient = (1 / first_stage \ -reduced_form / first_stage^2)
treatment_variance = gradient' * joint_covariance * gradient

st_numscalar("reduced_form", reduced_form)
st_numscalar("first_stage", first_stage)
st_numscalar("treatment_effect", treatment_effect)
st_numscalar("reduced_form_se", sqrt(joint_covariance[1,1]))
st_numscalar("first_stage_se", sqrt(joint_covariance[2,2]))
st_numscalar("treatment_effect_se", sqrt(treatment_variance[1,1]))
end

display "ANSWER: treatment_effect estimate=" %21.12f treatment_effect " se=" %21.12f treatment_effect_se " n_obs=" %12.0f `n_obs'
display "ANSWER: reduced_form estimate=" %21.12f reduced_form " se=" %21.12f reduced_form_se " n_obs=" %12.0f `n_obs'
display "ANSWER: first_stage estimate=" %21.12f first_stage " se=" %21.12f first_stage_se " n_obs=" %12.0f `n_obs'
