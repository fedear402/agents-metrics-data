clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

capture confirm string variable date
if !_rc {
    gen double date_num = date(date, "YMD")
}
else {
    gen double date_num = date
}
sort date_num

gen double ln_sales = ln(sales)
gen double ln_vix   = ln(vix)
gen double dln_vix  = ln_vix - ln_vix[_n-1]

forvalues j = 1/15 {
    gen double lag_`j' = dln_vix[_n-`j']
}

regress ln_sales lag_1-lag_15

predict double __resid if e(sample), resid

mata:
    X = st_data(., ("lag_1".."lag_15"), "e(sample)")
    u = st_data(., "__resid", "e(sample)")
    N = rows(X)
    X = J(N, 1, 1), X
    S = X'X
    meat = J(cols(X), cols(X), 0)

    for (t = 1; t <= N; t++) {
        score = X[t,.]' * u[t]
        meat = meat + score * score'
    }

    for (j = 1; j <= 15; j++) {
        w = 1 - j/16
        for (t = j+1; t <= N; t++) {
            score_t = X[t,.]' * u[t]
            score_l = X[t-j,.]' * u[t-j]
            meat = meat + w * (score_t * score_l' + score_l * score_t')
        }
    }

    V = syminv(S) * meat * syminv(S) * N/(N-16)
    st_matrix("Vnw", V)
    st_numscalar("Nobs", N)

    b = st_matrix("e(b)")'
    cum = sum(b[|2\16|])
    v_cum = J(1,16,1) * V * J(16,1,1)

    st_numscalar("cum_est", cum)
    st_numscalar("cum_se", sqrt(v_cum))
    st_numscalar("lag1_est", b[2])
    st_numscalar("lag1_se", sqrt(V[2,2]))
    st_numscalar("lag15_est", b[16])
    st_numscalar("lag15_se", sqrt(V[16,16]))
end

display "ANSWER: cumulative_response estimate=" %21.12f scalar(cum_est) ///
    " se=" %21.12f scalar(cum_se) " n_obs=" %12.0f scalar(Nobs)

display "ANSWER: lag_1 estimate=" %21.12f scalar(lag1_est) ///
    " se=" %21.12f scalar(lag1_se) " n_obs=" %12.0f scalar(Nobs)

display "ANSWER: lag_15 estimate=" %21.12f scalar(lag15_est) ///
    " se=" %21.12f scalar(lag15_se) " n_obs=" %12.0f scalar(Nobs)
