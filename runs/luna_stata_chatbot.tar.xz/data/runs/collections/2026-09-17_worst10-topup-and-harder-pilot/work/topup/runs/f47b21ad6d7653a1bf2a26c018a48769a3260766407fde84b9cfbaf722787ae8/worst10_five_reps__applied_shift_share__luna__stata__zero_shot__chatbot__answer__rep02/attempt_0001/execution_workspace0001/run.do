clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

sort region_id
by region_id: gen byte region_tag = (_n == 1)

egen double total_weight = total(cond(region_tag, region_weight, 0))
gen double e = region_weight / total_weight

gen double exposure = share * shock
bysort region_id: egen double z = total(exposure)

egen double mean_y = total(cond(region_tag, e * y, 0))
egen double mean_x = total(cond(region_tag, e * x, 0))
egen double mean_z = total(cond(region_tag, e * z, 0))

gen double y0 = y - mean_y
gen double x0 = x - mean_x
gen double z0 = z - mean_z

gen double es = e * share
gen double es_y0 = es * y0
gen double es_x0 = es * x0
gen double es_z0 = es * z0

collapse (sum) s=es y_num=es_y0 x_num=es_x0 z_num=es_z0 ///
    (firstnm) shock, by(industry_id)

keep if s > 0

gen double ybar = y_num / s
gen double xbar = x_num / s
gen double zbar = z_num / s

count
scalar n_ind = r(N)

summarize s, meanonly
scalar effective_shocks = 1 / r(sum_of_sq)

quietly ivregress 2sls ybar (xbar = shock) [aw=s], vce(robust)
scalar effect_estimate = _b[xbar]
scalar effect_se = _se[xbar]

quietly ivregress 2sls xbar (zbar = shock) [aw=s], vce(robust)
scalar first_stage_estimate = _b[zbar]
scalar first_stage_se = _se[zbar]

display "ANSWER: effect estimate=" %21.12f effect_estimate ///
    " se=" %21.12f effect_se " n_obs=" %12.0f n_ind

display "ANSWER: first_stage estimate=" %21.12f first_stage_estimate ///
    " se=" %21.12f first_stage_se " n_obs=" %12.0f n_ind

display "ANSWER: effective_shocks estimate=" %21.12f effective_shocks ///
    " se=." " n_obs=" %12.0f n_ind
