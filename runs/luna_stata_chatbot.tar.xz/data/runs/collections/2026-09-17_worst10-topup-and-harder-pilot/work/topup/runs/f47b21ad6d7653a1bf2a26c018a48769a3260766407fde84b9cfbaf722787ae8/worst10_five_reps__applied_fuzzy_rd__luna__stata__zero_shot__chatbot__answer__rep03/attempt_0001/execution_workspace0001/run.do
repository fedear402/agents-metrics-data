clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

keep if !missing(score, participated, earnings)
keep if abs(score) < 1

generate byte right = score >= 0
generate double score_right = score * right
generate double weight = 1 - abs(score)
generate byte touse = 1

mata:
    real matrix X, y, w, e, p
    real matrix A, Ae, Ap, Me, Mp, Mep, Ve, Vp, Vep
    real colvector be, bp
    real scalar n, rf, fs, te, se_rf, se_fs, se_te, ratio

    X = st_data(., ("right", "score", "score_right"), "touse")
    X = X[., (0, 0)] // placeholder
    X = J(rows(X), 1, 1), st_data(., ("score", "right", "score_right"), "touse")
    y = st_data(., ("earnings", "participated"), "touse")
    w = st_data(., "weight", "touse")

    n = rows(X)
    A = quadcross(X, w, X)

    be = invsym(A) * quadcross(X, w, y[., 1])
    bp = invsym(A) * quadcross(X, w, y[., 2])

    e = y[., 1] - X * be
    p = y[., 2] - X * bp

    Me  = quadcross(X, w:^2 :* e:^2, X)
    Mp  = quadcross(X, w:^2 :* p:^2, X)
    Mep = quadcross(X, w:^2 :* e :* p, X)

    Ae = invsym(A)
    Ve  = Ae * Me  * Ae
    Vp  = Ae * Mp  * Ae
    Vep = Ae * Mep * Ae

    rf = be[3]
    fs = bp[3]

    se_rf = sqrt(max(Ve[3,3], 0))
    se_fs = sqrt(max(Vp[3,3], 0))

    if (abs(fs) > 1e-12) {
        te = rf / fs
        ratio = te
        se_te = sqrt(max((Ve[3,3] - 2*ratio*Vep[3,3] + ratio^2*Vp[3,3]) / fs^2, 0))
    }
    else {
        te = .
        se_te = .
    }

    st_numscalar("reduced_form", rf)
    st_numscalar("reduced_form_se", se_rf)
    st_numscalar("first_stage", fs)
    st_numscalar("first_stage_se", se_fs)
    st_numscalar("treatment_effect", te)
    st_numscalar("treatment_effect_se", se_te)
    st_numscalar("n_obs", n)
end

display "ANSWER: treatment_effect estimate=" %21.12f treatment_effect " se=" %21.12f treatment_effect_se " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f reduced_form " se=" %21.12f reduced_form_se " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f first_stage " se=" %21.12f first_stage_se " n_obs=" %12.0f n_obs
