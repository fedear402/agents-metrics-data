version 19.0
clear all
set more off
set linesize 255

import delimited "./input.csv", clear

keep if abs(score) < 1
gen double weight = 1 - abs(score)
gen byte right = score >= 0
gen double right_score = right * score
gen double left_score = (1 - right) * score

local n_obs = _N

mata:
    y = st_data(., "earnings")
    p = st_data(., "participated")
    x = st_data(., ("right", "right_score", "left_score"))
    w = st_data(., "weight")

    X = (J(rows(x), 1, 1), x)
    W = diag(w)
    bread = invsym(X' * W * X)

    B = bread * X' * W * (y, p)
    E = (y, p) - X * B

    contrast = (1, 0, 0, 0)'
    contrast[1] = 0
    contrast[2] = 1

    d = contrast' * B
    loading = w :* (X * bread * contrast)
    influence = loading :* E
    joint = influence' * influence

    gradient = (1 / d[2] \ -d[1] / d[2]^2)
    ratio_se = sqrt(gradient' * joint * gradient)

    st_numscalar("reduced_form", d[1])
    st_numscalar("first_stage", d[2])
    st_numscalar("treatment_effect", d[1] / d[2])
    st_numscalar("reduced_form_se", sqrt(joint[1,1]))
    st_numscalar("first_stage_se", sqrt(joint[2,2]))
    st_numscalar("treatment_effect_se", ratio_se)
end

display "ANSWER: treatment_effect estimate=" %21.12f treatment_effect " se=" %21.12f treatment_effect_se " n_obs=" %12.0f `n_obs'
display "ANSWER: reduced_form estimate=" %21.12f reduced_form " se=" %21.12f reduced_form_se " n_obs=" %12.0f `n_obs'
display "ANSWER: first_stage estimate=" %21.12f first_stage " se=" %21.12f first_stage_se " n_obs=" %12.0f `n_obs'
