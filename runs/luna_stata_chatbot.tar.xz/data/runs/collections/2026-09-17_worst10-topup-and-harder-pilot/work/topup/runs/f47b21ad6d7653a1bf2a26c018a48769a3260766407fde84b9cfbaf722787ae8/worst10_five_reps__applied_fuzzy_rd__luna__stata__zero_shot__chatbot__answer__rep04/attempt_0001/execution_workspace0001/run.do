clear all
set more off
set linesize 255

import delimited "./input.csv", clear

generate byte touse = abs(score) < 1
count if touse
scalar n_obs = r(N)

mata:
    Z = st_data(., ("score", "earnings", "participated"), "touse")
    n = rows(Z)

    s = Z[,1]
    y = Z[,2..3]
    w = 1 :- abs(s)

    X = J(n, 4, 0)
    for (i = 1; i <= n; i++) {
        if (s[i] < 0) {
            X[i,1] = 1
            X[i,2] = s[i]
        }
        else {
            X[i,3] = 1
            X[i,4] = s[i]
        }
    }

    W = diag(w)
    bread = invsym(X' * W * X)
    beta = bread * X' * W * y
    residuals = y - X * beta

    meat = J(4, 4, 0)
    cross_meat = J(4, 4, 0)

    for (i = 1; i <= n; i++) {
        xi = X[i,.]'
        meat = meat + (w[i]^2) * (xi * xi') * (residuals[i,1]^2)
        cross_meat = cross_meat + (w[i]^2) * (xi * xi') * ///
            (residuals[i,1] * residuals[i,2])
    }

    meat_participation = J(4, 4, 0)
    for (i = 1; i <= n; i++) {
        xi = X[i,.]'
        meat_participation = meat_participation + ///
            (w[i]^2) * (xi * xi') * (residuals[i,2]^2)
    }

    V_earnings = bread * meat * bread'
    V_participation = bread * meat_participation * bread'
    V_cross = bread * cross_meat * bread'

    C = (-1, 0, 1, 0)

    reduced_form = C * beta[,1]
    first_stage = C * beta[,2]

    var_reduced_form = C * V_earnings * C'
    var_first_stage = C * V_participation * C'
    cov_rf_fs = C * V_cross * C'

    se_reduced_form = sqrt(max((var_reduced_form), 0))
    se_first_stage = sqrt(max((var_first_stage), 0))

    if (first_stage != 0) {
        treatment_effect = reduced_form / first_stage
        var_treatment_effect = ///
            (var_reduced_form / first_stage^2) + ///
            (reduced_form^2 * var_first_stage / first_stage^4) - ///
            (2 * reduced_form * cov_rf_fs / first_stage^3)
        se_treatment_effect = sqrt(max(var_treatment_effect, 0))
    }
    else {
        treatment_effect = .
        se_treatment_effect = .
    }

    st_numscalar("reduced_form", reduced_form)
    st_numscalar("se_reduced_form", se_reduced_form)
    st_numscalar("first_stage", first_stage)
    st_numscalar("se_first_stage", se_first_stage)
    st_numscalar("treatment_effect", treatment_effect)
    st_numscalar("se_treatment_effect", se_treatment_effect)
end

display "ANSWER: treatment_effect estimate=" %21.12f treatment_effect ///
    " se=" %21.12f se_treatment_effect " n_obs=" %12.0f n_obs

display "ANSWER: reduced_form estimate=" %21.12f reduced_form ///
    " se=" %21.12f se_reduced_form " n_obs=" %12.0f n_obs

display "ANSWER: first_stage estimate=" %21.12f first_stage ///
    " se=" %21.12f se_first_stage " n_obs=" %12.0f n_obs
