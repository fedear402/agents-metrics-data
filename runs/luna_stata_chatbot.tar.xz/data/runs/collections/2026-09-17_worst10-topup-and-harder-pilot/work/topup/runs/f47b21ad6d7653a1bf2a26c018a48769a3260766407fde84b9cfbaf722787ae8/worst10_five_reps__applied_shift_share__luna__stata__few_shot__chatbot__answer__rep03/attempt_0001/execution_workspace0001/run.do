version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

tempfile original regions shocks

sort region_id industry_id
by region_id: egen z = total(share * shock)
by region_id: gen byte region_tag = (_n == 1)

egen total_region_weight = total(region_weight) if region_tag
summarize total_region_weight, meanonly
scalar weight_sum = r(sum)

gen double e = region_weight / weight_sum if region_tag

gen double wy = e * y if region_tag
gen double wx = e * x if region_tag
gen double wz = e * z if region_tag

summarize wy, meanonly
scalar mean_y = r(sum)
summarize wx, meanonly
scalar mean_x = r(sum)
summarize wz, meanonly
scalar mean_z = r(sum)

gen double y0 = y - mean_y
gen double x0 = x - mean_x
gen double z0 = z - mean_z

preserve
keep if region_tag
keep region_id e y0 x0 z0
save `regions', replace
restore

save `original', replace

merge m:1 region_id using `regions', nogen keep(match)

gen double eshare = e * share
by industry_id: egen double s = total(eshare)

gen double sy = eshare * y0
gen double sx = eshare * x0
gen double sz = eshare * z0

collapse (sum) sy sx sz eshare (first) s shock, by(industry_id)
keep if s > 0

gen double ybar = sy / s
gen double xbar = sx / s
gen double zbar = sz / s

count
scalar N_industries = r(N)

mata:
void bhj_iv(string scalar dep, string scalar endog, string scalar instr,
            string scalar weight, string scalar bname, string scalar sename)
{
    real matrix d, q, h, w, cross, invcross, beta, residual, scores, covariance
    real scalar n

    d = st_data(., dep)
    q = st_data(., endog)
    h = st_data(., instr)
    w = st_data(., weight)

    d = d, q
    q = J(rows(q), 1, 1), q
    h = J(rows(h), 1, 1), h

    cross = h' * (w :* q)
    invcross = luinv(cross)
    beta = invcross * h' * (w :* d[,1])

    residual = d[,1] - q * beta
    scores = h :* (w :* residual)
    n = rows(d)

    covariance = n / (n - 2) * invcross * (scores' * scores) * invcross'

    st_numscalar(bname, beta[2])
    st_numscalar(sename, sqrt(covariance[2,2]))
}
end

mata: bhj_iv("ybar", "xbar", "shock", "s", "effect_b", "effect_se")
mata: bhj_iv("xbar", "zbar", "shock", "s", "first_b", "first_se")

summarize s, meanonly
scalar effective_shocks = 1 / sum((s / r(sum))^2)

display "ANSWER: effect estimate=" %21.12f scalar(effect_b) ///
    " se=" %21.12f scalar(effect_se) ///
    " n_obs=" %12.0f scalar(N_industries)

display "ANSWER: first_stage estimate=" %21.12f scalar(first_b) ///
    " se=" %21.12f scalar(first_se) ///
    " n_obs=" %12.0f scalar(N_industries)

display "ANSWER: effective_shocks estimate=" %21.12f scalar(effective_shocks) ///
    " se=" %21.12f . ///
    " n_obs=" %12.0f scalar(N_industries)
