clear all
set more off
set linesize 255

import delimited using "./input.csv", clear
sort date

gen double ln_sales = ln(sales)
gen double dln_vix = ln(vix) - ln(vix[_n-1])
gen long obs_index = _n
tsset obs_index

regress ln_sales L(1/15).dln_vix
gen byte touse = e(sample)

mata:
    y = st_data(., "ln_sales", "touse")
    X = st_data(., "dln_vix L1.dln_vix L2.dln_vix L3.dln_vix L4.dln_vix L5.dln_vix L6.dln_vix L7.dln_vix L8.dln_vix L9.dln_vix L10.dln_vix L11.dln_vix L12.dln_vix L13.dln_vix L14.dln_vix L15.dln_vix", "touse")
    X = J(rows(X), 1, 1), X
    N = rows(X)
    K = cols(X)

    b = invsym(X'X) * X'y
    u = y - X*b
    Z = X :* u

    S = Z'Z
    for (j = 1; j <= 15; j++) {
        w = 1 - j/16
        S = S + w * (Z[(j+1)..N, ]' * Z[1..(N-j), ] + Z[1..(N-j), ]' * Z[(j+1)..N, ])
    }

    V = invsym(X'X) * S * invsym(X'X) * (N/(N-16))

    cumulative_response = sum(b[2..16])
    cumulative_se = sqrt(sum(V[2..16, 2..16]))
    lag_1_estimate = b[2]
    lag_1_se = sqrt(V[2,2])
    lag_15_estimate = b[16]
    lag_15_se = sqrt(V[16,16])

    st_numscalar("cumulative_response", cumulative_response)
    st_numscalar("cumulative_se", cumulative_se)
    st_numscalar("lag_1_estimate", lag_1_estimate)
    st_numscalar("lag_1_se", lag_1_se)
    st_numscalar("lag_15_estimate", lag_15_estimate)
    st_numscalar("lag_15_se", lag_15_se)
    st_numscalar("n_obs", N)
end

display "ANSWER: cumulative_response estimate=" %21.12f scalar(cumulative_response) " se=" %21.12f scalar(cumulative_se) " n_obs=" %12.0f scalar(n_obs)
display "ANSWER: lag_1 estimate=" %21.12f scalar(lag_1_estimate) " se=" %21.12f scalar(lag_1_se) " n_obs=" %12.0f scalar(n_obs)
display "ANSWER: lag_15 estimate=" %21.12f scalar(lag_15_estimate) " se=" %21.12f scalar(lag_15_se) " n_obs=" %12.0f scalar(n_obs)
