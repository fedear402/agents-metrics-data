clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

keep if abs(score) < 1
generate double right = score >= 0
generate double right_score = right * score
generate double weight = 1 - abs(score)

mata:
    real matrix d, X, W, A, Ai, B, U, V1, V2
    real colvector score, participation, earnings, w, ur, up
    real scalar n, rf, fs, te, var_rf, var_fs, cov_rf_fs, var_te

    score = st_data(., "score")
    participation = st_data(., "participated")
    earnings = st_data(., "earnings")
    w = 1 :- abs(score)
    n = rows(score)

    X = J(n, 1, 1), (score :>= 0), score, (score :>= 0) :* score
    W = diag(w)
    A = X' * W * X
    Ai = invsym(A)
    B = Ai * X' * W * (earnings, participation)

    ur = earnings :- X * B[,1]
    up = participation :- X * B[,2]

    V1 = J(4, 4, 0)
    V2 = J(4, 4, 0)

    for (i = 1; i <= n; i++) {
        V1 = V1 + (w[i]^2) * (X[i,]' * X[i,]) * (ur[i]^2)
        V2 = V2 + (w[i]^2) * (X[i,]' * X[i,]) * (up[i]^2)
    }

    V1 = Ai * V1 * Ai
    V2 = Ai * V2 * Ai

    cov_rf_fs = 0
    for (i = 1; i <= n; i++) {
        cov_rf_fs = cov_rf_fs + (w[i]^2) * ur[i] * up[i] * (Ai[2,] * X[i,]') * (Ai[2,] * X[i,]')
    }

    rf = B[2,1]
    fs = B[2,2]

    st_numscalar("rf_est", rf)
    st_numscalar("fs_est", fs)
    st_numscalar("rf_se", sqrt(V1[2,2]))
    st_numscalar("fs_se", sqrt(V2[2,2]))
    st_numscalar("n_total", n)

    if (fs != 0) {
        te = rf / fs
        var_te = V1[2,2] / (fs^2) + (rf^2) * V2[2,2] / (fs^4) - 2 * rf * cov_rf_fs / (fs^3)
        st_numscalar("te_est", te)
        st_numscalar("te_se", sqrt(max((0, var_te))))
    }
    else {
        st_numscalar("te_est", .)
        st_numscalar("te_se", .)
    }
end

display "ANSWER: treatment_effect estimate=" %21.12f scalar(te_est) " se=" %21.12f scalar(te_se) " n_obs=" %12.0f scalar(n_total)
display "ANSWER: reduced_form estimate=" %21.12f scalar(rf_est) " se=" %21.12f scalar(rf_se) " n_obs=" %12.0f scalar(n_total)
display "ANSWER: first_stage estimate=" %21.12f scalar(fs_est) " se=" %21.12f scalar(fs_se) " n_obs=" %12.0f scalar(n_total)
