clear all
set linesize 255

import delimited using "./input.csv", clear

count
scalar n_obs = r(N)

tobit y x z, ll(0) vce(oim)

scalar b_const = _b[_cons]
scalar se_const = _se[_cons]
scalar b_x = _b[x]
scalar se_x = _se[x]
scalar b_z = _b[z]
scalar se_z = _se[z]
scalar b_sigma = e(sigma)

display "ANSWER: const estimate=" %21.12f b_const " se=" %21.12f se_const " n_obs=" %12.0f n_obs
display "ANSWER: x estimate=" %21.12f b_x " se=" %21.12f se_x " n_obs=" %12.0f n_obs
display "ANSWER: z estimate=" %21.12f b_z " se=" %21.12f se_z " n_obs=" %12.0f n_obs
display "ANSWER: sigma estimate=" %21.12f b_sigma " se=." " n_obs=" %12.0f n_obs
