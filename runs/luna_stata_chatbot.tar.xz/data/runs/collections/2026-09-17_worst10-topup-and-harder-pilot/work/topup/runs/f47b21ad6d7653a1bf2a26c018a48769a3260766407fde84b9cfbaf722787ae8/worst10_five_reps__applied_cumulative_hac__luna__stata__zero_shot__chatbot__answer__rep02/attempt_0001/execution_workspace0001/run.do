clear all
set linesize 255

import delimited "./input.csv", clear
sort date

generate double ln_sales = ln(sales)
generate double ln_vix = ln(vix)
generate double dln_vix = ln_vix - ln_vix[_n-1]

forvalues j = 1/15 {
    generate double lag_`j' = dln_vix[_n-`j']
}

regress ln_sales lag_1-lag_15
generate byte touse = e(sample)

mata:
    real matrix X, V, XXi, S
    real colvector u
    real scalar n, k, j, w
    string scalar xvars

    xvars = "lag_1"
    for (j = 2; j <= 15; j++) {
        xvars = xvars + " lag_" + strofreal(j)
    }

    X = st_data(., xvars, "touse")
    u = st_data(., "e(resid)", "touse")
    n = rows(X)
    k = cols(X)
    X = J(n, 1, 1), X

    S = J(k, k, 0)
    for (j = 0; j <= 15; j++) {
        w = 1 - j/16
        if (j == 0) {
            S = S + quadcross(X, u:^2, X)
        }
        else {
            S = S + w * (
                quadcross(X[(j+1)..n, .], u[(j+1)..n] :* u[1..(n-j)],
                    X[1..(n-j), .])
                +
                quadcross(X[1..(n-j), .], u[1..(n-j)] :* u[(j+1)..n],
                    X[(j+1)..n, .])
            )
        }
    }

    XXi = invsym(quadcross(X, X))
    V = (n/(n-16)) * XXi * S * XXi
    st_matrix("Vnw", V)
    st_numscalar("nw_n", n)
end

matrix b = e(b)
scalar cumulative_response = 0
forvalues j = 1/15 {
    scalar cumulative_response = cumulative_response + b[1,`j'+1]
}

scalar se_cumulative = sqrt(quadcolsum(quadrowsum((Vnw[2..16,2..16]))))
scalar se_lag_1 = sqrt(Vnw[2,2])
scalar se_lag_15 = sqrt(Vnw[16,16])

display "ANSWER: cumulative_response estimate=" %21.12f cumulative_response " se=" %21.12f se_cumulative " n_obs=" %12.0f nw_n
display "ANSWER: lag_1 estimate=" %21.12f b[1,2] " se=" %21.12f se_lag_1 " n_obs=" %12.0f nw_n
display "ANSWER: lag_15 estimate=" %21.12f b[1,16] " se=" %21.12f se_lag_15 " n_obs=" %12.0f nw_n
