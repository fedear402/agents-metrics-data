clear all
set more off
set linesize 255
set type double

import delimited "./input.csv", clear

ologit y x z, tolerance(1e-10) nrtolerance(1e-10)

scalar n_obs = e(N)
scalar prob_high = 1 - invlogit(_b[/cut2] - _b[x])

display "ANSWER: x estimate=" %21.12f (_b[x]) ///
    " se=" %21.12f (_se[x]) ///
    " n_obs=" %12.0f (n_obs)

display "ANSWER: z estimate=" %21.12f (_b[z]) ///
    " se=" %21.12f (_se[z]) ///
    " n_obs=" %12.0f (n_obs)

display "ANSWER: prob_high estimate=" %21.12f (prob_high) ///
    " se=" %21.12f (.) ///
    " n_obs=" %12.0f (n_obs)
