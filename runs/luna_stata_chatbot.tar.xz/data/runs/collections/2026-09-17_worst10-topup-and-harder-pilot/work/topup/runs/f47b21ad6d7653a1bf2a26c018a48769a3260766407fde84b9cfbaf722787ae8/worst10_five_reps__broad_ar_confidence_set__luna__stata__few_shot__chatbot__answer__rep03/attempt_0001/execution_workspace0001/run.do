clear all
set more off
set linesize 255
set type double

import delimited using "./input.csv", clear

quietly count
scalar n_obs = r(N)

quietly regress y x
predict double ry_r, residuals

quietly regress endog x
predict double re_r, residuals

quietly regress y x z1 z2
predict double ry_u, residuals

quietly regress endog x z1 z2
predict double re_u, residuals

scalar q = 2
scalar df = n_obs - 4
scalar critical = invFtail(q, df, .05)
scalar k = q * critical / df

mata:
    ry_r = st_data(., "ry_r")
    re_r = st_data(., "re_r")
    ry_u = st_data(., "ry_u")
    re_u = st_data(., "re_u")
    kk = st_numscalar("k")

    A = quadcross(re_r, re_r) - (1 + kk) * quadcross(re_u, re_u)
    B = -2 * (quadcross(ry_r, re_r) - (1 + kk) * quadcross(ry_u, re_u))
    C = quadcross(ry_r, ry_r) - (1 + kk) * quadcross(ry_u, ry_u)

    discriminant = B^2 - 4 * A * C
    root1 = (-B - sqrt(discriminant)) / (2 * A)
    root2 = (-B + sqrt(discriminant)) / (2 * A)

    low = min(root1, root2)
    high = max(root1, root2)

    ssr_r_0 = quadcross(ry_r, ry_r)
    ssr_u_0 = quadcross(ry_u, ry_u)
    accepts_zero = (C <= 0)

    ssr_r_1 = quadcross(ry_r - re_r, ry_r - re_r)
    ssr_u_1 = quadcross(ry_u - re_u, ry_u - re_u)
    ar_f_one = ((ssr_r_1 - ssr_u_1) / q) / (ssr_u_1 / st_numscalar("df"))

    unbounded = (A < 0)

    st_numscalar("boundary_low", low)
    st_numscalar("boundary_high", high)
    st_numscalar("accepts_zero", accepts_zero)
    st_numscalar("unbounded", unbounded)
    st_numscalar("ar_f_at_one", ar_f_one)
end

display "ANSWER: boundary_low estimate=" %21.12f boundary_low " se=." " n_obs=" %12.0f n_obs
display "ANSWER: boundary_high estimate=" %21.12f boundary_high " se=." " n_obs=" %12.0f n_obs
display "ANSWER: accepts_zero estimate=" %21.12f accepts_zero " se=." " n_obs=" %12.0f n_obs
display "ANSWER: unbounded estimate=" %21.12f unbounded " se=." " n_obs=" %12.0f n_obs
display "ANSWER: ar_f_at_one estimate=" %21.12f ar_f_at_one " se=." " n_obs=" %12.0f n_obs
