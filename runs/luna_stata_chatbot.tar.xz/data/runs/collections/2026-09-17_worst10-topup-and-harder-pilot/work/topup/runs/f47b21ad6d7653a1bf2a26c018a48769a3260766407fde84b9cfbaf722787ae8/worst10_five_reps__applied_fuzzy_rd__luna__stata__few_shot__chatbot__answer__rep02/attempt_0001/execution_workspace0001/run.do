version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

keep if !missing(score, participated, earnings) & abs(score) < 1

mata:
score = st_data(., "score")
Y = st_data(., ("earnings", "participated"))

n = rows(score)
right = score :>= 0
weights = 1 :- abs(score)

X = (J(n, 1, 1), score, right, right:*score)

bread = invsym(X' * (weights:*X))
coefficients = bread * X' * (weights:*Y)
residuals = Y - X*coefficients

contrast = (0\0\1\0)
discontinuities = contrast' * coefficients

loading = weights :* (X * bread * contrast)
influence = loading :* residuals
joint = influence' * influence

reduced_form = discontinuities[1]
first_stage = discontinuities[2]
treatment_effect = reduced_form / first_stage

gradient = (1/first_stage \ -reduced_form/first_stage^2)
treatment_effect_se = sqrt(gradient' * joint * gradient)
reduced_form_se = sqrt(joint[1,1])
first_stage_se = sqrt(joint[2,2])

st_numscalar("reduced_form", reduced_form)
st_numscalar("reduced_form_se", reduced_form_se)
st_numscalar("first_stage", first_stage)
st_numscalar("first_stage_se", first_stage_se)
st_numscalar("treatment_effect", treatment_effect)
st_numscalar("treatment_effect_se", treatment_effect_se)
st_numscalar("n_obs", n)
end

display "ANSWER: treatment_effect estimate=" %21.12f treatment_effect " se=" %21.12f treatment_effect_se " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f reduced_form " se=" %21.12f reduced_form_se " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f first_stage " se=" %21.12f first_stage_se " n_obs=" %12.0f n_obs
