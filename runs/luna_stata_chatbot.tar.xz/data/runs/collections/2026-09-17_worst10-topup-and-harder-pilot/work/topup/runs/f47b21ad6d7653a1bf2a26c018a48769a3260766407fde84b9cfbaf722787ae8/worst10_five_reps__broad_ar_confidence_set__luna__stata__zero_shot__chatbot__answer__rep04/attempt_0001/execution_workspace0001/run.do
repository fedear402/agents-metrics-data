clear all
set linesize 255

import delimited using "./input.csv", clear

quietly count
scalar n_obs = r(N)

generate double y1 = y - endog

quietly regress y1 x z1 z2
quietly test z1 z2
scalar ar_f_at_one = r(F)

mata:
    y = st_data(., "y")
    e = st_data(., "endog")
    x = st_data(., "x")
    z1 = st_data(., "z1")
    z2 = st_data(., "z2")
    n = rows(y)

    Xr = J(n, 1, 1), x
    Xf = J(n, 1, 1), x, z1, z2

    Ir = I(n) - Xr * invsym(Xr' * Xr) * Xr'
    If = I(n) - Xf * invsym(Xf' * Xf) * Xf'
    Q  = Ir - If
    D  = If

    crit = invF(2, n - 4, .95)
    k = 2 * crit / (n - 4)

    aq = y' * Q * y
    bq = -2 * e' * Q * y
    cq = e' * Q * e

    ad = y' * D * y
    bd = -2 * e' * D * y
    cd = e' * D * e

    A = aq - k * ad
    B = bq - k * bd
    C = cq - k * cd

    disc = B^2 - 4 * C * A
    r1 = (-B - sqrt(disc)) / (2 * C)
    r2 = (-B + sqrt(disc)) / (2 * C)

    st_numscalar("boundary_low", min((r1, r2)))
    st_numscalar("boundary_high", max((r1, r2)))
    st_numscalar("ineq_zero", A)
    st_numscalar("quad_C", C)
end

scalar accepts_zero = (ineq_zero <= 0)
scalar unbounded = (quad_C < 0)

display "ANSWER: boundary_low estimate=" %21.12f boundary_low " se=." " n_obs=" %12.0f n_obs
display "ANSWER: boundary_high estimate=" %21.12f boundary_high " se=." " n_obs=" %12.0f n_obs
display "ANSWER: accepts_zero estimate=" %21.12f accepts_zero " se=." " n_obs=" %12.0f n_obs
display "ANSWER: unbounded estimate=" %21.12f unbounded " se=." " n_obs=" %12.0f n_obs
display "ANSWER: ar_f_at_one estimate=" %21.12f ar_f_at_one " se=." " n_obs=" %12.0f n_obs
