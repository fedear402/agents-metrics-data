clear all
set linesize 255

import delimited "./input.csv", clear

egen byte region_tag = tag(region_id)
summarize region_weight if region_tag, meanonly
scalar total_region_weight = r(sum)

generate double e = region_weight / total_region_weight
generate double contribution = share * shock

collapse (sum) z=contribution (first) region_weight x y e, by(region_id)

summarize y [aw=e], meanonly
scalar mean_y = r(mean)
summarize x [aw=e], meanonly
scalar mean_x = r(mean)
summarize z [aw=e], meanonly
scalar mean_z = r(mean)

generate double y0 = y - mean_y
generate double x0 = x - mean_x
generate double z0 = z - mean_z

tempfile regional
save `regional'

import delimited "./input.csv", clear
merge m:1 region_id using `regional', keepusing(e y0 x0 z0) nogen

generate double exposure = e * share
generate double y_num = exposure * y0
generate double x_num = exposure * x0
generate double z_num = exposure * z0

collapse (sum) s=exposure y_num x_num z_num (first) shock, by(industry_id)

drop if s <= 0
generate double ybar = y_num / s
generate double xbar = x_num / s
generate double zbar = z_num / s

count
scalar N_industries = r(N)

mata:
void iv_hc1(string scalar depvar, string scalar endogvar,
            string scalar instrument, string scalar weightvar,
            string scalar bname, string scalar sename)
{
    real matrix y, X, Z, W, G, H, Q, Omega, V
    real colvector w, u, b
    real scalar N

    y = st_data(., depvar)
    X = J(rows(y), 1, 1), st_data(., endogvar)
    Z = J(rows(y), 1, 1), st_data(., instrument)
    w = st_data(., weightvar)
    W = diag(w)

    G = Z' * W * X
    H = Z' * W * Z
    Q = G' * invsym(H) * G
    b = invsym(Q) * G' * invsym(H) * Z' * W * y

    u = y - X * b
    Omega = (Z :* w)' * diag(u:^2) * (Z :* w)

    V = invsym(Q) * (G' * invsym(H) * Omega * invsym(H) * G) * invsym(Q)
    N = rows(y)
    V = V * N / (N - 2)

    st_numscalar(bname, b[2])
    st_numscalar(sename, sqrt(V[2,2]))
}
end

mata: iv_hc1("ybar", "xbar", "shock", "s", "effect_b", "effect_se")
mata: iv_hc1("xbar", "zbar", "shock", "s", "first_b", "first_se")

generate double s_squared = s^2
summarize s_squared, meanonly
scalar effective_shocks_value = 1 / r(sum)

display "ANSWER: effect estimate=" %21.12f effect_b ///
    " se=" %21.12f effect_se ///
    " n_obs=" %12.0f N_industries

display "ANSWER: first_stage estimate=" %21.12f first_b ///
    " se=" %21.12f first_se ///
    " n_obs=" %12.0f N_industries

display "ANSWER: effective_shocks estimate=" %21.12f effective_shocks_value ///
    " se=" %21.12f . ///
    " n_obs=" %12.0f N_industries
