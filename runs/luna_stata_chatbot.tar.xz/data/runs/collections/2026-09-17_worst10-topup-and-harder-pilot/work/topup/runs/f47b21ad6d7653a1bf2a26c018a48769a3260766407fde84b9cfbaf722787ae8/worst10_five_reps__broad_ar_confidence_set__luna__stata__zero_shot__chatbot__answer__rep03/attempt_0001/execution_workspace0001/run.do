clear all
set more off
set linesize 255

import delimited "./input.csv", clear

count
local n = r(N)
scalar n_obs = `n'

scalar fcrit = invF(2, `n' - 4, .05)

mata:
    y = st_data(., "y")
    e = st_data(., "endog")
    x = st_data(., "x")
    z1 = st_data(., "z1")
    z2 = st_data(., "z2")

    n = rows(y)
    Xr = J(n, 1, 1), x
    Xf = J(n, 1, 1), x, z1, z2

    Mr = I(n) - Xr * invsym(Xr' * Xr) * Xr'
    Mf = I(n) - Xf * invsym(Xf' * Xf) * Xf'

    A = Mr - Mf
    B = Mf

    a2 = (e' * A * e)[1,1]
    a1 = -2 * (e' * A * y)[1,1]
    a0 = (y' * A * y)[1,1]

    b2 = (e' * B * e)[1,1]
    b1 = -2 * (e' * B * y)[1,1]
    b0 = (y' * B * y)[1,1]

    c2 = (n - 4) * a2 - 2 * st_numscalar("fcrit") * b2
    c1 = (n - 4) * a1 - 2 * st_numscalar("fcrit") * b1
    c0 = (n - 4) * a0 - 2 * st_numscalar("fcrit") * b0

    disc = c1^2 - 4*c2*c0
    root1 = (-c1 - sqrt(disc)) / (2*c2)
    root2 = (-c1 + sqrt(disc)) / (2*c2)

    st_numscalar("boundary_low", min((root1, root2)))
    st_numscalar("boundary_high", max((root1, root2)))

    nzero = a0
    dzero = b0
    fzero = (nzero / 2) / (dzero / (n - 4))
    st_numscalar("accepts_zero", fzero <= st_numscalar("fcrit"))

    qlead = c2
    st_numscalar("unbounded", qlead <= 0)

    qone = (n - 4) * (a2 + a1 + a0) - ///
        2 * st_numscalar("fcrit") * (b2 + b1 + b0)
    done = b2 + b1 + b0
    fone = ((a2 + a1 + a0) / 2) / (done / (n - 4))
    st_numscalar("ar_f_at_one", fone)
end

display "ANSWER: boundary_low estimate=" %21.12f boundary_low ///
    " se=" %21.12f . " n_obs=" %12.0f n_obs

display "ANSWER: boundary_high estimate=" %21.12f boundary_high ///
    " se=" %21.12f . " n_obs=" %12.0f n_obs

display "ANSWER: accepts_zero estimate=" %21.12f accepts_zero ///
    " se=" %21.12f . " n_obs=" %12.0f n_obs

display "ANSWER: unbounded estimate=" %21.12f unbounded ///
    " se=" %21.12f . " n_obs=" %12.0f n_obs

display "ANSWER: ar_f_at_one estimate=" %21.12f ar_f_at_one ///
    " se=" %21.12f . " n_obs=" %12.0f n_obs
