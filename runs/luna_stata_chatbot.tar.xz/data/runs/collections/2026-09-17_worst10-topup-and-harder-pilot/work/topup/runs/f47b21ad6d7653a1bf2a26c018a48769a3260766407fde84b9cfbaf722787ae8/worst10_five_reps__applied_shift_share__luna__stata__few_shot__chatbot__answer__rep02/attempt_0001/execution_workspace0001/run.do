version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

tempfile regions

preserve
    gen double contribution = share * shock

    collapse (sum) z=contribution ///
        (firstnm) region_weight x y, by(region_id)

    egen double total_region_weight = total(region_weight)
    gen double e = region_weight / total_region_weight

    summarize y [aw=e], meanonly
    scalar mean_y = r(mean)

    summarize x [aw=e], meanonly
    scalar mean_x = r(mean)

    summarize z [aw=e], meanonly
    scalar mean_z = r(mean)

    gen double y0 = y - mean_y
    gen double x0 = x - mean_x
    gen double z0 = z - mean_z

    keep region_id e x0 y0 z0
    save `regions'
restore

merge m:1 region_id using `regions', nogen keep(match)

gen double exposure = e * share

collapse ///
    (sum) s=exposure ///
    (sum) ybar_num=exposure*y0 ///
    (sum) xbar_num=exposure*x0 ///
    (sum) zbar_num=exposure*z0 ///
    (firstnm) shock, by(industry_id)

drop if missing(s) | s <= 0 | missing(shock)
gen double ybar = ybar_num / s
gen double xbar = xbar_num / s
gen double zbar = zbar_num / s

mata:
    real matrix d, Z, X, W, cross, invcross, beta, residual, scores, covariance
    real scalar N, effect, effect_se, first_stage, first_stage_se, effective

    d = st_data(., ("ybar", "xbar", "zbar", "shock", "s"))
    N = rows(d)

    W = diag(d[,5])
    Z = d[,4], J(N,1,1)

    X = J(N,1,1), d[,2]
    cross = Z' * W * X
    invcross = luinv(cross)
    beta = invcross * Z' * W * d[,1]
    residual = d[,1] - X * beta
    scores = Z :* (d[,5] :* residual)
    covariance = (N / (N - 2)) * invcross * (scores' * scores) * invcross'
    effect = beta[2]
    effect_se = sqrt(covariance[2,2])

    X = J(N,1,1), d[,3]
    cross = Z' * W * X
    invcross = luinv(cross)
    beta = invcross * Z' * W * d[,2]
    residual = d[,2] - X * beta
    scores = Z :* (d[,5] :* residual)
    covariance = (N / (N - 2)) * invcross * (scores' * scores) * invcross'
    first_stage = beta[2]
    first_stage_se = sqrt(covariance[2,2])

    effective = 1 / sum((d[,5]) :^ 2)

    st_numscalar("effect_value", effect)
    st_numscalar("effect_se_value", effect_se)
    st_numscalar("first_stage_value", first_stage)
    st_numscalar("first_stage_se_value", first_stage_se)
    st_numscalar("effective_value", effective)
    st_numscalar("industry_count", N)
end

display "ANSWER: effect estimate=" %21.12f scalar(effect_value) ///
    " se=" %21.12f scalar(effect_se_value) ///
    " n_obs=" %12.0f scalar(industry_count)

display "ANSWER: first_stage estimate=" %21.12f scalar(first_stage_value) ///
    " se=" %21.12f scalar(first_stage_se_value) ///
    " n_obs=" %12.0f scalar(industry_count)

display "ANSWER: effective_shocks estimate=" %21.12f scalar(effective_value) ///
    " se=." ///
    " n_obs=" %12.0f scalar(industry_count)
