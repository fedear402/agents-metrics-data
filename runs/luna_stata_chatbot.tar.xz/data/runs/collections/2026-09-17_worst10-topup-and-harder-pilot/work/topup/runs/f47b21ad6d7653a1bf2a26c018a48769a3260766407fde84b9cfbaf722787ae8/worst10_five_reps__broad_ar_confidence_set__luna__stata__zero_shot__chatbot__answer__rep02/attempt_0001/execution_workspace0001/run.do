clear all
set more off
set linesize 255

import delimited using "./input.csv", clear
count
local n_obs = r(N)

mata:
    y = st_data(., "y")
    e = st_data(., "endog")
    x = st_data(., "x")
    z1 = st_data(., "z1")
    z2 = st_data(., "z2")

    W = J(rows(y), 1, 1), x, z1, z2
    R = J(rows(y), 1, 1), x

    Mf = I(rows(y)) - W * invsym(W' * W) * W'
    Mr = I(rows(y)) - R * invsym(R' * R) * R'
    Md = Mr - Mf

    sf0 = y' * Mf * y
    sf1 = -(e' * Mf * y + y' * Mf * e)
    sf2 = e' * Mf * e

    d0 = y' * Md * y
    d1 = -(e' * Md * y + y' * Md * e)
    d2 = e' * Md * e

    st_numscalar("sf0", sf0)
    st_numscalar("sf1", sf1)
    st_numscalar("sf2", sf2)
    st_numscalar("d0", d0)
    st_numscalar("d1", d1)
    st_numscalar("d2", d2)
end

scalar fcrit = invF(2, `n_obs' - 4, .95)

scalar c0 = (`n_obs' - 4)*d0 - 2*fcrit*sf0
scalar c1 = (`n_obs' - 4)*d1 - 2*fcrit*sf1
scalar c2 = (`n_obs' - 4)*d2 - 2*fcrit*sf2

scalar disc = c1^2 - 4*c2*c0
scalar root1 = (-c1 - sqrt(disc))/(2*c2)
scalar root2 = (-c1 + sqrt(disc))/(2*c2)

scalar boundary_low = min(root1, root2)
scalar boundary_high = max(root1, root2)

scalar f_at_one = (`n_obs' - 4)*(d0 + d1 + d2) / ///
    (2*(sf0 + sf1 + sf2))

scalar accepts_zero = (c0 <= 0)
scalar unbounded = (c2 <= 0)

display "ANSWER: boundary_low estimate=" %21.12f boundary_low ///
    " se=." " n_obs=" %12.0f `n_obs'

display "ANSWER: boundary_high estimate=" %21.12f boundary_high ///
    " se=." " n_obs=" %12.0f `n_obs'

display "ANSWER: accepts_zero estimate=" %21.12f accepts_zero ///
    " se=." " n_obs=" %12.0f `n_obs'

display "ANSWER: unbounded estimate=" %21.12f unbounded ///
    " se=." " n_obs=" %12.0f `n_obs'

display "ANSWER: ar_f_at_one estimate=" %21.12f f_at_one ///
    " se=." " n_obs=" %12.0f `n_obs'
