clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

sort date

generate double ln_sales = ln(sales)
generate double ln_vix = ln(vix)
generate double dln_vix = ln_vix - ln_vix[_n-1]

forvalues j = 1/15 {
    generate double lag_`j' = dln_vix[_n-`j']
}

generate byte touse = !missing(ln_sales, lag_1, lag_2, lag_3, lag_4, lag_5, ///
    lag_6, lag_7, lag_8, lag_9, lag_10, lag_11, lag_12, lag_13, lag_14, lag_15)

regress ln_sales lag_1-lag_15 if touse

predict double nw_resid if e(sample), residuals

mata:
void compute_nw()
{
    string scalar xvars
    real matrix X, V, bread, meat, G
    real colvector u
    real scalar N, k, j, w

    xvars = "lag_1 lag_2 lag_3 lag_4 lag_5 lag_6 lag_7 lag_8 lag_9 lag_10 lag_11 lag_12 lag_13 lag_14 lag_15"
    X = J(0, 16, .)
    X = st_data(., xvars, "touse")
    X = J(rows(X), 1, 1), X
    u = st_data(., "nw_resid", "touse")

    N = rows(X)
    k = cols(X)
    bread = invsym(X'X)
    meat = J(k, k, 0)

    for (j = 0; j <= 15; j++) {
        if (j == 0) {
            G = (X :* u)' * (X :* u)
            meat = meat + G
        }
        else {
            G = (X[|j + 1, 1 \ N, k|] :* u[|j + 1, 1 \ N, 1|])' * ///
                (X[|1, 1 \ N - j, k|] :* u[|1, 1 \ N - j, 1|])
            w = 1 - j / 16
            meat = meat + w * (G + G')
        }
    }

    V = bread * meat * bread * (N / (N - 16))
    st_matrix("Vnw", V)
    st_numscalar("Nreg", N)
}
compute_nw()
end

scalar cumulative_response = 0
forvalues j = 1/15 {
    scalar cumulative_response = cumulative_response + _b[lag_`j']
}

matrix cvec = J(1, 16, 0)
forvalues j = 1/15 {
    matrix cvec[1, `j' + 1] = 1
}

scalar se_cumulative = sqrt((cvec * Vnw * cvec')[1, 1])
scalar se_lag_1 = sqrt(Vnw[2, 2])
scalar se_lag_15 = sqrt(Vnw[16, 16])

display "ANSWER: cumulative_response estimate=" %21.12f cumulative_response ///
    " se=" %21.12f se_cumulative " n_obs=" %12.0f Nreg

display "ANSWER: lag_1 estimate=" %21.12f _b[lag_1] ///
    " se=" %21.12f se_lag_1 " n_obs=" %12.0f Nreg

display "ANSWER: lag_15 estimate=" %21.12f _b[lag_15] ///
    " se=" %21.12f se_lag_15 " n_obs=" %12.0f Nreg
