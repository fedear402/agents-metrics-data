version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

keep if abs(score) < 1
count
local n_obs = r(N)

mata:
s = st_data(., "score")
y = st_data(., ("earnings", "participated"))
w = 1 :- abs(s)

left  = s :< 0
right = s :>= 0

X = (left, s:*left, right, s:*right)
W = diag(w)

bread = invsym(X' * W * X)
b = bread * X' * W * y
residuals = y - X * b

contrast = (-1 \ 0 \ 1 \ 0)
discontinuities = contrast' * b

loading = (w :* (X * bread * contrast))
influence = loading :* residuals
joint = influence' * influence

reduced_form = discontinuities[1]
first_stage = discontinuities[2]
treatment_effect = reduced_form / first_stage

gradient = (1 / first_stage \ -reduced_form / first_stage^2)
treatment_se = sqrt(gradient' * joint * gradient)
reduced_se = sqrt(joint[1,1])
first_se = sqrt(joint[2,2])

st_numscalar("reduced_form", reduced_form)
st_numscalar("reduced_se", reduced_se)
st_numscalar("first_stage", first_stage)
st_numscalar("first_se", first_se)
st_numscalar("treatment_effect", treatment_effect)
st_numscalar("treatment_se", treatment_se)
end

display "ANSWER: treatment_effect estimate=" %21.12f scalar(treatment_effect) ///
    " se=" %21.12f scalar(treatment_se) " n_obs=" %12.0f `n_obs'

display "ANSWER: reduced_form estimate=" %21.12f scalar(reduced_form) ///
    " se=" %21.12f scalar(reduced_se) " n_obs=" %12.0f `n_obs'

display "ANSWER: first_stage estimate=" %21.12f scalar(first_stage) ///
    " se=" %21.12f scalar(first_se) " n_obs=" %12.0f `n_obs'
