clear all
set more off
set linesize 255
set type double

import delimited using "./input.csv", clear

count
scalar n_obs = r(N)
scalar df = n_obs - 4
scalar q = 2
scalar critical = invFtail(q, df, .05)
scalar k = q * critical / df

mata:
    y = st_data(., "y")
    d = st_data(., "endog")
    x = st_data(., "x")
    z = st_data(., ("z1", "z2"))

    X = J(rows(y), 1, 1), x
    M = I(rows(y)) - X * invsym(X' * X) * X'

    ry = M * y
    rd = M * d
    Zr = M * z

    Pz = Zr * invsym(Zr' * Zr) * Zr'
    I = I(rows(y))

    sy0 = quadcross(ry, ry)
    syd = quadcross(ry, rd)
    sd0 = quadcross(rd, rd)

    uy = (I - Pz) * ry
    ud = (I - Pz) * rd

    suy0 = quadcross(uy, uy)
    suyd = quadcross(uy, ud)
    sud0 = quadcross(ud, ud)

    kk = st_numscalar("k")

    A = sd0 - (1 + kk) * sud0
    B = -2 * (syd - (1 + kk) * suyd)
    C = sy0 - (1 + kk) * suy0

    disc = B^2 - 4 * A * C

    r1 = (-B - sqrt(disc)) / (2 * A)
    r2 = (-B + sqrt(disc)) / (2 * A)

    low = min((r1, r2))
    high = max((r1, r2))

    f1_num = (sy0 - 2 * syd + sd0) - (suy0 - 2 * suyd + sud0)
    f1_den = (suy0 - 2 * suyd + sud0) / st_numscalar("df")
    ar_f_one = (f1_num / st_numscalar("q")) / f1_den

    st_numscalar("boundary_low", low)
    st_numscalar("boundary_high", high)
    st_numscalar("accepts_zero", C <= 0)
    st_numscalar("unbounded", A < 0)
    st_numscalar("ar_f_at_one", ar_f_one)
end

display "ANSWER: boundary_low estimate=" %21.12f boundary_low " se=." " n_obs=" %12.0f n_obs
display "ANSWER: boundary_high estimate=" %21.12f boundary_high " se=." " n_obs=" %12.0f n_obs
display "ANSWER: accepts_zero estimate=" %21.12f accepts_zero " se=." " n_obs=" %12.0f n_obs
display "ANSWER: unbounded estimate=" %21.12f unbounded " se=." " n_obs=" %12.0f n_obs
display "ANSWER: ar_f_at_one estimate=" %21.12f ar_f_at_one " se=." " n_obs=" %12.0f n_obs
