clear all
set linesize 255

import delimited using "./input.csv", clear

local n_obs = _N

quietly tobit y x z, ll(0)

scalar estimate_const = _b[_cons]
scalar se_const = _se[_cons]
scalar estimate_x = _b[x]
scalar se_x = _se[x]
scalar estimate_z = _b[z]
scalar se_z = _se[z]
scalar estimate_sigma = _b[/sigma]

display "ANSWER: const estimate=" %21.12f estimate_const " se=" %21.12f se_const " n_obs=" %12.0f `n_obs'
display "ANSWER: x estimate=" %21.12f estimate_x " se=" %21.12f se_x " n_obs=" %12.0f `n_obs'
display "ANSWER: z estimate=" %21.12f estimate_z " se=" %21.12f se_z " n_obs=" %12.0f `n_obs'
display "ANSWER: sigma estimate=" %21.12f estimate_sigma " se=. n_obs=" %12.0f `n_obs'
