version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

egen region = group(region_id)
egen industry = group(industry_id)

bysort region: egen z = total(share * shock)
egen region_tag = tag(region)

egen total_region_weight = total(cond(region_tag, region_weight, 0))
generate double e = region_weight / total_region_weight

egen mean_y = total(e * y)
egen mean_x = total(e * x)
egen mean_z = total(e * z)

generate double y0 = y - mean_y
generate double x0 = x - mean_x
generate double z0 = z - mean_z

bysort industry: egen double s = total(e * share)
bysort industry: egen double y_num = total(e * share * y0)
bysort industry: egen double x_num = total(e * share * x0)
bysort industry: egen double z_num = total(e * share * z0)

generate double ybar = y_num / s
generate double xbar = x_num / s
generate double zbar = z_num / s

collapse (firstnm) s shock ybar xbar zbar, by(industry)

mata:
    s = st_data(., "s")
    shock = st_data(., "shock")
    ybar = st_data(., "ybar")
    xbar = st_data(., "xbar")
    zbar = st_data(., "zbar")

    N = rows(s)
    W = s
    Q = (J(N, 1, 1), shock)

    X_effect = (J(N, 1, 1), xbar)
    cross_effect = Q' * (W :* X_effect)
    beta_effect = luinv(cross_effect) * Q' * (W :* ybar)
    residual_effect = ybar - X_effect * beta_effect
    scores_effect = Q :* (W :* residual_effect)
    vcov_effect = N / (N - 2) * luinv(cross_effect) * ///
        (scores_effect' * scores_effect) * luinv(cross_effect)'
    se_effect = sqrt(vcov_effect[2, 2])

    X_first = (J(N, 1, 1), zbar)
    cross_first = Q' * (W :* X_first)
    beta_first = luinv(cross_first) * Q' * (W :* xbar)
    residual_first = xbar - X_first * beta_first
    scores_first = Q :* (W :* residual_first)
    vcov_first = N / (N - 2) * luinv(cross_first) * ///
        (scores_first' * scores_first) * luinv(cross_first)'
    se_first = sqrt(vcov_first[2, 2])

    effective_shocks = 1 / sum(s :^ 2)

    st_numscalar("effect_estimate", beta_effect[2])
    st_numscalar("effect_se", se_effect)
    st_numscalar("first_stage_estimate", beta_first[2])
    st_numscalar("first_stage_se", se_first)
    st_numscalar("effective_shocks_estimate", effective_shocks)
    st_numscalar("n_industries", N)
end

display "ANSWER: effect estimate=" %21.12f effect_estimate ///
    " se=" %21.12f effect_se ///
    " n_obs=" %12.0f n_industries

display "ANSWER: first_stage estimate=" %21.12f first_stage_estimate ///
    " se=" %21.12f first_stage_se ///
    " n_obs=" %12.0f n_industries

display "ANSWER: effective_shocks estimate=" %21.12f effective_shocks_estimate ///
    " se=." ///
    " n_obs=" %12.0f n_industries
