clear all
set more off
set linesize 255
set type double

import delimited "./input.csv", clear

quietly count
scalar n_obs = r(N)

quietly regress y x
predict double ry, residuals

quietly regress endog x
predict double rd, residuals

quietly regress y x z1 z2
scalar ssr_u = e(rss)
scalar df = e(df_r)
scalar q = 2
scalar critical = invFtail(q, df, .05)
scalar k = q * critical / df

generate double y_beta1 = y - endog
quietly regress y_beta1 x z1 z2
scalar ssr_r_one = e(rss)
scalar ar_f_at_one = ((ssr_r_one - ssr_u) / q) / (ssr_u / df)

mata:
    ry = st_data(., "ry")
    rd = st_data(., "rd")
    ssr_u = st_numscalar("ssr_u")
    k = st_numscalar("k")

    A = quadcross(rd, rd) - (1 + k) * quadcross(rd, rd)
    B = -2 * quadcross(ry, rd)
    C = quadcross(ry, ry) - (1 + k) * ssr_u

    disc = B^2 - 4 * A * C
    root1 = (-B - sqrt(disc)) / (2 * A)
    root2 = (-B + sqrt(disc)) / (2 * A)

    if (root1 < root2) {
        low = root1
        high = root2
    }
    else {
        low = root2
        high = root1
    }

    accepts_zero = (C <= 0)
    unbounded = (A < 0)

    st_numscalar("boundary_low", low)
    st_numscalar("boundary_high", high)
    st_numscalar("accepts_zero", accepts_zero)
    st_numscalar("unbounded", unbounded)
end

scalar se_missing = .

display "ANSWER: boundary_low estimate=" %21.12f boundary_low " se=" %21.12f se_missing " n_obs=" %12.0f n_obs
display "ANSWER: boundary_high estimate=" %21.12f boundary_high " se=" %21.12f se_missing " n_obs=" %12.0f n_obs
display "ANSWER: accepts_zero estimate=" %21.12f accepts_zero " se=" %21.12f se_missing " n_obs=" %12.0f n_obs
display "ANSWER: unbounded estimate=" %21.12f unbounded " se=" %21.12f se_missing " n_obs=" %12.0f n_obs
display "ANSWER: ar_f_at_one estimate=" %21.12f ar_f_at_one " se=" %21.12f se_missing " n_obs=" %12.0f n_obs
