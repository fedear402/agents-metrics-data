version 19.0
clear all
set more off
set linesize 255

tempfile original regions

import delimited using "./input.csv", clear
save `original'

gen double z_part = share * shock
collapse (sum) z=z_part (firstnm) x y region_weight, by(region_id)
egen double total_weight = total(region_weight)
gen double e = region_weight / total_weight

quietly summarize e, meanonly
scalar e_sum = r(sum)

quietly summarize y [aw=e], meanonly
gen double y0 = y - r(mean)

quietly summarize x [aw=e], meanonly
gen double x0 = x - r(mean)

quietly summarize z [aw=e], meanonly
gen double z0 = z - r(mean)

save `regions'

use `original', clear
merge m:1 region_id using `regions', nogen keepusing(e y0 x0 z0)

gen double s_part = e * share
gen double y_num = s_part * y0
gen double x_num = s_part * x0
gen double z_num = s_part * z0

collapse (sum) s=s_part y_num x_num z_num (firstnm) shock, by(industry_id)
drop if s <= 0

gen double ybar = y_num / s
gen double xbar = x_num / s
gen double zbar = z_num / s

count
scalar n_industries = r(N)

mata:
void bhj_iv(string scalar dep, string scalar endog, string scalar instr,
            scalar result_b, scalar result_se)
{
    real matrix d, q, h, w, cross, beta, resid, scores, covariance
    real scalar n

    d = st_data(., dep)
    q = st_data(., endog)
    h = st_data(., instr)
    w = st_data(., "s")
    n = rows(d)

    q = (J(n,1,1), q)
    h = (J(n,1,1), h)

    cross = h' * (w :* q)
    beta = luinv(cross) * h' * (w :* d)
    resid = d - q * beta

    scores = h :* (w :* resid)
    covariance = (n / (n - 2)) * luinv(cross) * (scores' * scores) * luinv(cross)'

    st_numscalar(result_b, beta[2])
    st_numscalar(result_se, sqrt(covariance[2,2]))
}

bhj_iv("ybar", "xbar", "shock", "effect_b", "effect_se")
bhj_iv("xbar", "zbar", "shock", "first_b", "first_se")

quietly summarize s, meanonly
scalar effective_shocks = 1 / sum((s / r(sum))^2)

display "ANSWER: effect estimate=" %21.12f effect_b " se=" %21.12f effect_se " n_obs=" %12.0f n_industries
display "ANSWER: first_stage estimate=" %21.12f first_b " se=" %21.12f first_se " n_obs=" %12.0f n_industries
display "ANSWER: effective_shocks estimate=" %21.12f effective_shocks " se=" %21.12f . " n_obs=" %12.0f n_industries
