clear all
set linesize 255

import delimited using "./input.csv", clear

count
scalar n_obs = r(N)

mata:
    y = st_data(., "y")
    e = st_data(., "endog")
    x = st_data(., "x")
    z = st_data(., ("z1", "z2"))

    n = rows(y)
    X = J(n, 1, 1), x
    Mx = I(n) - X * invsym(X' * X) * X'

    yr = Mx * y
    er = Mx * e
    zr = Mx * z
    Pz = zr * invsym(zr' * zr) * zr'
    Mz = I(n) - Pz

    crit = invFtail(2, n - 4, .05)

    a0 = quadcross(yr, Pz, yr) * (n - 4) - 2 * crit * quadcross(yr, Mz, yr)
    a1 = -2 * quadcross(er, Pz, yr) * (n - 4) + 4 * crit * quadcross(er, Mz, yr)
    a2 = quadcross(er, Pz, er) * (n - 4) - 2 * crit * quadcross(er, Mz, er)

    disc = a1^2 - 4 * a2 * a0
    root1 = (-a1 - sqrt(disc)) / (2 * a2)
    root2 = (-a1 + sqrt(disc)) / (2 * a2)

    low = min((root1, root2))
    high = max((root1, root2))

    w1 = yr - er
    inc1 = quadcross(w1, Pz, w1)
    ssru1 = quadcross(w1, Mz, w1)
    f1 = (inc1 / 2) / (ssru1 / (n - 4))

    w0 = yr
    inc0 = quadcross(w0, Pz, w0)
    ssru0 = quadcross(w0, Mz, w0)
    f0 = (inc0 / 2) / (ssru0 / (n - 4))

    unb = (a2 <= 0)
    acc0 = (f0 <= crit)

    st_numscalar("boundary_low", low)
    st_numscalar("boundary_high", high)
    st_numscalar("accepts_zero", acc0)
    st_numscalar("unbounded", unb)
    st_numscalar("ar_f_at_one", f1)
end

display "ANSWER: boundary_low estimate=" %21.12f boundary_low " se=." " n_obs=" %12.0f n_obs
display "ANSWER: boundary_high estimate=" %21.12f boundary_high " se=." " n_obs=" %12.0f n_obs
display "ANSWER: accepts_zero estimate=" %21.12f accepts_zero " se=." " n_obs=" %12.0f n_obs
display "ANSWER: unbounded estimate=" %21.12f unbounded " se=." " n_obs=" %12.0f n_obs
display "ANSWER: ar_f_at_one estimate=" %21.12f ar_f_at_one " se=." " n_obs=" %12.0f n_obs
