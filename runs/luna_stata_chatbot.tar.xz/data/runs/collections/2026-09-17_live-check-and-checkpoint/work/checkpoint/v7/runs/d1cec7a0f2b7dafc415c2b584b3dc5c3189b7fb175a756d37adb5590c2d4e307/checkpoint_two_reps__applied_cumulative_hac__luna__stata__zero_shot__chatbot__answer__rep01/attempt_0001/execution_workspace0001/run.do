clear all
set more off
set linesize 255

import delimited "./input.csv", clear
sort date

gen double ln_sales = ln(sales)
gen double ln_vix = ln(vix)
gen double dln_vix = ln_vix - ln_vix[_n-1]

gen long obs_id = _n
tsset obs_id

gen byte touse = !missing(ln_sales, L(1/15).dln_vix)

regress ln_sales L(1/15).dln_vix if touse
predict double resid if e(sample), residuals

gen byte sample = e(sample)

mata:
    X = st_data(., tokens("L1.dln_vix L2.dln_vix L3.dln_vix L4.dln_vix L5.dln_vix L6.dln_vix L7.dln_vix L8.dln_vix L9.dln_vix L10.dln_vix L11.dln_vix L12.dln_vix L13.dln_vix L14.dln_vix L15.dln_vix _cons"), "sample")
    u = select(st_data(., "resid"), st_data(., "sample"))
    b = st_matrix("e(b)")'
    N = rows(X)
    K = cols(X)
    S = J(K, K, 0)

    for (i = 1; i <= N; i++) {
        xi = X[i,.]'
        S = S + u[i]^2 * (xi * xi')
    }

    for (j = 1; j <= 15; j++) {
        w = 1 - j/16
        for (i = j + 1; i <= N; i++) {
            xi = X[i,.]'
            xj = X[i-j,.]'
            S = S + w * u[i] * u[i-j] * (xi*xj' + xj*xi')
        }
    }

    XXinv = invsym(quadcross(X, X))
    V = XXinv * S * XXinv * N/(N-16)

    c = J(K, 1, 0)
    c[1..15] = J(15, 1, 1)

    cum_est = c'b
    cum_se = sqrt(c'V*c)
    lag1_est = b[1]
    lag1_se = sqrt(V[1,1])
    lag15_est = b[15]
    lag15_se = sqrt(V[15,15])

    st_numscalar("cumulative_response", cum_est)
    st_numscalar("cumulative_response_se", cum_se)
    st_numscalar("lag_1", lag1_est)
    st_numscalar("lag_1_se", lag1_se)
    st_numscalar("lag_15", lag15_est)
    st_numscalar("lag_15_se", lag15_se)
    st_numscalar("n_obs", N)
end

display "ANSWER: cumulative_response estimate=" %21.12f cumulative_response " se=" %21.12f cumulative_response_se " n_obs=" %12.0f n_obs
display "ANSWER: lag_1 estimate=" %21.12f lag_1 " se=" %21.12f lag_1_se " n_obs=" %12.0f n_obs
display "ANSWER: lag_15 estimate=" %21.12f lag_15 " se=" %21.12f lag_15_se " n_obs=" %12.0f n_obs
