clear all
set linesize 255

import delimited using "./input.csv", clear

tobit y x z, ll(0) vce(oim)

display "ANSWER: const estimate=" %21.12f (_b[_cons]) " se=" %21.12f (_se[_cons]) " n_obs=" %12.0f (e(N))
display "ANSWER: x estimate=" %21.12f (_b[x]) " se=" %21.12f (_se[x]) " n_obs=" %12.0f (e(N))
display "ANSWER: z estimate=" %21.12f (_b[z]) " se=" %21.12f (_se[z]) " n_obs=" %12.0f (e(N))
display "ANSWER: sigma estimate=" %21.12f (e(sigma)) " se=" %21.12f (.) " n_obs=" %12.0f (e(N))
