clear all
set more off
set linesize 255

import delimited using "./input.csv", clear
sort date

gen double ln_sales = ln(sales)
gen double dln_vix = ln(vix) - ln(vix[_n-1])

forvalues j = 1/15 {
    gen double lag_`j' = dln_vix[_n-`j']
}

regress ln_sales lag_1-lag_15
gen byte touse = e(sample)
predict double resid if touse, residuals

local n = e(N)

mata:
    X = st_data(., tokens(" _cons lag_1 lag_2 lag_3 lag_4 lag_5 lag_6 lag_7 lag_8 lag_9 lag_10 lag_11 lag_12 lag_13 lag_14 lag_15"), "touse")
    u = st_data(., "resid", "touse")
    n = rows(X)
    k = cols(X)

    Z = X :* u
    S = Z' * Z

    for (j = 1; j <= 15; j++) {
        w = 1 - j/16
        S = S + w * (Z[(j+1)..n,.]' * Z[1..(n-j),.] +
                     Z[1..(n-j),.]' * Z[(j+1)..n,.])
    }

    XXinv = invsym(X' * X)
    V = (n/(n-16)) * XXinv * S * XXinv
    b = XXinv * (X' * st_data(., "ln_sales", "touse"))

    c = J(k, 1, 0)
    c[2..16] = J(15, 1, 1)

    st_numscalar("estimate_cumulative", c' * b)
    st_numscalar("se_cumulative", sqrt(c' * V * c))
    st_numscalar("estimate_lag1", b[2])
    st_numscalar("se_lag1", sqrt(V[2,2]))
    st_numscalar("estimate_lag15", b[16])
    st_numscalar("se_lag15", sqrt(V[16,16]))
    st_numscalar("n_obs", n)
end

display "ANSWER: cumulative_response estimate=" %21.12f scalar(estimate_cumulative) ///
    " se=" %21.12f scalar(se_cumulative) ///
    " n_obs=" %12.0f scalar(n_obs)

display "ANSWER: lag_1 estimate=" %21.12f scalar(estimate_lag1) ///
    " se=" %21.12f scalar(se_lag1) ///
    " n_obs=" %12.0f scalar(n_obs)

display "ANSWER: lag_15 estimate=" %21.12f scalar(estimate_lag15) ///
    " se=" %21.12f scalar(se_lag15) ///
    " n_obs=" %12.0f scalar(n_obs)
