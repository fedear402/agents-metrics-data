clear all
set linesize 255

import delimited using "./input.csv", clear

keep if abs(score) < 1
keep if !missing(score, participated, earnings)

generate double weight = 1 - abs(score)
generate byte right = score >= 0

count
scalar n_obs = r(N)

mata:
    s  = st_data(., "score")
    y  = st_data(., "earnings")
    p  = st_data(., "participated")
    w  = st_data(., "weight")
    r  = st_data(., "right")

    n = rows(s)
    X = J(n, 4, 0)
    for (i=1; i<=n; i++) {
        if (r[i] == 0) {
            X[i,1] = 1
            X[i,2] = s[i]
        }
        else {
            X[i,3] = 1
            X[i,4] = s[i]
        }
    }

    W = diag(w)
    B = invsym(X' * W * X)

    by = B * (X' * W * y)
    bp = B * (X' * W * p)

    ey = y - X * by
    ep = p - X * bp

    My = J(4,4,0)
    Mp = J(4,4,0)
    Myp = J(4,4,0)

    for (i=1; i<=n; i++) {
        xi = X[i,.]'
        My  = My  + (w[i]^2) * (ey[i]^2) * (xi * xi')
        Mp  = Mp  + (w[i]^2) * (ep[i]^2) * (xi * xi')
        Myp = Myp + (w[i]^2) * (ey[i] * ep[i]) * (xi * xi')
    }

    Vy  = B * My  * B
    Vp  = B * Mp  * B
    Vyp = B * Myp * B

    c = (-1, 0, 1, 0)

    rf = c * by
    fs = c * bp
    vrf = c * Vy * c'
    vfs = c * Vp * c'
    cv  = c * Vyp * c'

    if (fs != 0) {
        te = rf / fs
        vte = vrf/(fs^2) + (rf^2)*vfs/(fs^4) - 2*rf*cv/(fs^3)
    }
    else {
        te = .
        vte = .
    }

    if (vte >= 0) sete = sqrt(vte)
    else sete = .

    if (vrf >= 0) serf = sqrt(vrf)
    else serf = .

    if (vfs >= 0) sefs = sqrt(vfs)
    else sefs = .

    st_numscalar("reduced_form", rf)
    st_numscalar("reduced_form_se", serf)
    st_numscalar("first_stage", fs)
    st_numscalar("first_stage_se", sefs)
    st_numscalar("treatment_effect", te)
    st_numscalar("treatment_effect_se", sete)
end

display "ANSWER: treatment_effect estimate=" %21.12f treatment_effect " se=" %21.12f treatment_effect_se " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f reduced_form " se=" %21.12f reduced_form_se " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f first_stage " se=" %21.12f first_stage_se " n_obs=" %12.0f n_obs
