clear all
set more off
set linesize 255
set type double

import delimited using "./input.csv", clear

tobit y x z, ll(0)

scalar n_obs = _N
scalar sigma_hat = sqrt(_b[/var(e.y)])

display "ANSWER: const estimate=" %21.12f _b[_cons] ///
    " se=" %21.12f _se[_cons] ///
    " n_obs=" %12.0f n_obs

display "ANSWER: x estimate=" %21.12f _b[x] ///
    " se=" %21.12f _se[x] ///
    " n_obs=" %12.0f n_obs

display "ANSWER: z estimate=" %21.12f _b[z] ///
    " se=" %21.12f _se[z] ///
    " n_obs=" %12.0f n_obs

display "ANSWER: sigma estimate=" %21.12f sigma_hat ///
    " se=" %21.12f . ///
    " n_obs=" %12.0f n_obs
