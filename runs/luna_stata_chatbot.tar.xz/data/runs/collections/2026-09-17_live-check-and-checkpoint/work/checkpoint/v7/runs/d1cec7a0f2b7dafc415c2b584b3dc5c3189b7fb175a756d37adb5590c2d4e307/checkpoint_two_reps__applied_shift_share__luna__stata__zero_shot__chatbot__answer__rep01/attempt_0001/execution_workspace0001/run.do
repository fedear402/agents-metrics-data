clear all
set more off
set linesize 255

import delimited "./input.csv", clear

sort region_id industry_id
by region_id: gen byte region_tag = (_n == 1)

gen double rw_one = region_weight if region_tag
egen double total_rw = total(rw_one)
gen double e = region_weight / total_rw

gen double exposure = share * shock
by region_id: egen double z = total(exposure)

collapse (firstnm) region_weight x y z e, by(region_id)

egen double y_mean = total(e * y)
egen double x_mean = total(e * x)
egen double z_mean = total(e * z)

gen double y0 = y - y_mean
gen double x0 = x - x_mean
gen double z0 = z - z_mean

tempfile regions
save `regions'

restore, not

import delimited "./input.csv", clear

sort region_id industry_id
by region_id: gen byte region_tag = (_n == 1)

gen double rw_one = region_weight if region_tag
egen double total_rw = total(rw_one)
gen double e = region_weight / total_rw

gen double exposure = share * shock
by region_id: egen double z = total(exposure)

merge m:1 region_id using `regions', nogen keepusing(y0 x0 z0 e)

gen double s_component = e * share
gen double y_component = s_component * y0
gen double x_component = s_component * x0
gen double z_component = s_component * z0

collapse (sum) s=s_component y_num=y_component x_num=x_component z_num=z_component ///
    (firstnm) shock, by(industry_id)

drop if s <= 0 | missing(s) | missing(shock)

gen double ybar = y_num / s
gen double xbar = x_num / s
gen double zbar = z_num / s

count
local n_industries = r(N)

quietly ivregress 2sls ybar (xbar = shock) [aw=s], vce(robust)
scalar effect_est = _b[xbar]
scalar effect_se = _se[xbar]

quietly ivregress 2sls xbar (zbar = shock) [aw=s], vce(robust)
scalar first_est = _b[zbar]
scalar first_se = _se[zbar]

quietly summarize s, meanonly
scalar sum_s2 = r(sum) == . ? . : 0
quietly gen double s_squared = s^2
quietly summarize s_squared, meanonly
scalar effective_est = 1 / r(sum)

display "ANSWER: effect estimate=" %21.12f effect_est " se=" %21.12f effect_se " n_obs=" %12.0f `n_industries'
display "ANSWER: first_stage estimate=" %21.12f first_est " se=" %21.12f first_se " n_obs=" %12.0f `n_industries'
display "ANSWER: effective_shocks estimate=" %21.12f effective_est " se=" %21.12f . " n_obs=" %12.0f `n_industries'
