clear
set linesize 255

import delimited "./input.csv", clear
sort time

scalar sse = 0
scalar se_missing = .
scalar forecast_101 = .
scalar forecast_150 = .
scalar forecast_200 = .
scalar forecast_250 = .

forvalues f = 101/250 {
    local lo = `f' - 100
    local hi = `f' - 1

    preserve
        keep if inrange(time, `lo', `hi')
        sort time
        generate double y_lag = y[_n-1]
        drop if _n == 1

        regress y y_lag

        scalar a_hat = _b[_cons]
        scalar b_hat = _b[y_lag]
    restore

    quietly summarize y if time == `hi', meanonly
    scalar forecast_value = a_hat + b_hat * r(mean)

    quietly summarize y if time == `f', meanonly
    scalar error_value = r(mean) - forecast_value
    scalar sse = sse + error_value^2

    if `f' == 101 {
        scalar forecast_101 = forecast_value
    }
    if `f' == 150 {
        scalar forecast_150 = forecast_value
    }
    if `f' == 200 {
        scalar forecast_200 = forecast_value
    }
    if `f' == 250 {
        scalar forecast_250 = forecast_value
    }
}

scalar rmse = sqrt(sse / 150)

display "ANSWER: rmse estimate=" %21.12f rmse " se=" %21.12f se_missing " n_obs=" %12.0f 150
display "ANSWER: forecast_101 estimate=" %21.12f forecast_101 " se=" %21.12f se_missing " n_obs=" %12.0f 99
display "ANSWER: forecast_150 estimate=" %21.12f forecast_150 " se=" %21.12f se_missing " n_obs=" %12.0f 99
display "ANSWER: forecast_200 estimate=" %21.12f forecast_200 " se=" %21.12f se_missing " n_obs=" %12.0f 99
display "ANSWER: forecast_250 estimate=" %21.12f forecast_250 " se=" %21.12f se_missing " n_obs=" %12.0f 99
