clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

egen byte region_tag = tag(region_id)

quietly summarize region_weight if region_tag, meanonly
scalar total_region_weight = r(sum)

generate double e_r = region_weight / total_region_weight
bysort region_id: egen double z_r = total(share * shock)

quietly summarize y if region_tag [aw=e_r], meanonly
scalar mean_y = r(mean)

quietly summarize x if region_tag [aw=e_r], meanonly
scalar mean_x = r(mean)

quietly summarize z_r if region_tag [aw=e_r], meanonly
scalar mean_z = r(mean)

generate double y0 = y - mean_y
generate double x0 = x - mean_x
generate double z0 = z_r - mean_z

bysort industry_id: egen double s_n = total(e_r * share)
bysort industry_id: egen double y_num = total(e_r * share * y0)
bysort industry_id: egen double x_num = total(e_r * share * x0)
bysort industry_id: egen double z_num = total(e_r * share * z0)

bysort industry_id: keep if _n == 1
drop if missing(s_n) | s_n <= 0

generate double ybar = y_num / s_n
generate double xbar = x_num / s_n
generate double zbar = z_num / s_n

quietly count
scalar n_industries = r(N)

quietly ivregress 2sls ybar (xbar = shock) [aw=s_n], vce(robust)
scalar effect_estimate = _b[xbar]
scalar effect_se = _se[xbar]

quietly ivregress 2sls xbar (zbar = shock) [aw=s_n], vce(robust)
scalar first_stage_estimate = _b[zbar]
scalar first_stage_se = _se[zbar]

quietly summarize s_n, meanonly
scalar effective_shocks = 1 / sum(s_n^2)

display "ANSWER: effect estimate=" %21.12f effect_estimate " se=" %21.12f effect_se " n_obs=" %12.0f n_industries
display "ANSWER: first_stage estimate=" %21.12f first_stage_estimate " se=" %21.12f first_stage_se " n_obs=" %12.0f n_industries
display "ANSWER: effective_shocks estimate=" %21.12f effective_shocks " se=. n_obs=" %12.0f n_industries
