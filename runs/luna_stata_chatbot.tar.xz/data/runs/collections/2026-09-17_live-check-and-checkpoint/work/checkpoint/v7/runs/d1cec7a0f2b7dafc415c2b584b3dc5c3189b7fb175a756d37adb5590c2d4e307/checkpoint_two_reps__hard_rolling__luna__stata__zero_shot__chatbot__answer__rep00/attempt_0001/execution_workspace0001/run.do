clear
import delimited "./input.csv", clear varnames(1)

sort time
tsset time

scalar sse = 0
scalar se_missing = .
scalar n_rmse = 150
scalar n_forecast = 99

forvalues f = 101/250 {
    local lo = `f' - 99
    local hi = `f' - 1

    quietly summarize y if time == `hi', meanonly
    scalar lag_value = r(mean)

    quietly regress y L.y if time >= `lo' & time <= `hi'
    scalar forecast_value = _b[_cons] + _b[L.y] * lag_value

    quietly summarize y if time == `f', meanonly
    scalar actual_value = r(mean)

    scalar sse = sse + (actual_value - forecast_value)^2

    if `f' == 101 {
        scalar forecast_101 = forecast_value
    }
    if `f' == 150 {
        scalar forecast_150 = forecast_value
    }
    if `f' == 200 {
        scalar forecast_200 = forecast_value
    }
    if `f' == 250 {
        scalar forecast_250 = forecast_value
    }
}

scalar rmse = sqrt(sse / 150)

display "ANSWER: rmse estimate=" %21.12f rmse " se=" %21.12f se_missing " n_obs=" %12.0f n_rmse
display "ANSWER: forecast_101 estimate=" %21.12f forecast_101 " se=" %21.12f se_missing " n_obs=" %12.0f n_forecast
display "ANSWER: forecast_150 estimate=" %21.12f forecast_150 " se=" %21.12f se_missing " n_obs=" %12.0f n_forecast
display "ANSWER: forecast_200 estimate=" %21.12f forecast_200 " se=" %21.12f se_missing " n_obs=" %12.0f n_forecast
display "ANSWER: forecast_250 estimate=" %21.12f forecast_250 " se=" %21.12f se_missing " n_obs=" %12.0f n_forecast
