clear all
set linesize 255

import delimited using "./input.csv", clear

count
scalar n_obs = r(N)
scalar df_r = n_obs - 4

quietly regress y x
predict double ry, residuals

quietly regress endog x
predict double rb, residuals

quietly regress y x z1 z2
predict double ey, residuals

quietly regress endog x z1 z2
predict double eb, residuals

generate double ry2 = ry^2
generate double rb2 = rb^2
generate double ey2 = ey^2
generate double eb2 = eb^2
generate double ryrb = ry*rb
generate double eyeb = ey*eb

quietly summarize ry2, meanonly
scalar s_ry2 = r(sum)

quietly summarize rb2, meanonly
scalar s_rb2 = r(sum)

quietly summarize ey2, meanonly
scalar s_ey2 = r(sum)

quietly summarize eb2, meanonly
scalar s_eb2 = r(sum)

quietly summarize ryrb, meanonly
scalar s_ryrb = r(sum)

quietly summarize eyeb, meanonly
scalar s_eyeb = r(sum)

scalar f_crit = invF(0.95, 2, df_r)
scalar k = f_crit / df_r

scalar n2 = s_rb2 - s_eb2
scalar n1 = -2*s_ryrb + 2*s_eyeb
scalar n0 = s_ry2 - s_ey2

scalar qa = n2 - k*s_eb2
scalar qb = n1 + 2*k*s_eyeb
scalar qc = n0 - k*s_ey2

scalar disc = qb^2 - 4*qa*qc
scalar root1 = (-qb - sqrt(disc))/(2*qa)
scalar root2 = (-qb + sqrt(disc))/(2*qa)

scalar boundary_low = min(root1, root2)
scalar boundary_high = max(root1, root2)

scalar ar_f_at_one = ///
    ((n0 + n1 + n2)/2) / ///
    ((s_ey2 - 2*s_eyeb + s_eb2)/df_r)

scalar accepts_zero = (n0 <= k*s_ey2)
scalar unbounded = (qa < 0)

display "ANSWER: boundary_low estimate=" %21.12f boundary_low ///
    " se=." " n_obs=" %12.0f n_obs

display "ANSWER: boundary_high estimate=" %21.12f boundary_high ///
    " se=." " n_obs=" %12.0f n_obs

display "ANSWER: accepts_zero estimate=" %21.12f accepts_zero ///
    " se=." " n_obs=" %12.0f n_obs

display "ANSWER: unbounded estimate=" %21.12f unbounded ///
    " se=." " n_obs=" %12.0f n_obs

display "ANSWER: ar_f_at_one estimate=" %21.12f ar_f_at_one ///
    " se=." " n_obs=" %12.0f n_obs
