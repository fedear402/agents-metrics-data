version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear
sort time
tsset time

generate double lagged_y = L.y
generate double forecast = .
generate double squared_error = .

forvalues f = 101/250 {
    local first_response = `f' - 99
    local last_response = `f' - 1

    quietly regress y lagged_y if inrange(time, `first_response', `last_response')
    assert e(N) == 99

    quietly replace forecast = _b[_cons] + _b[lagged_y] * lagged_y if time == `f'
    quietly replace squared_error = (y - forecast)^2 if time == `f'
}

quietly summarize squared_error if inrange(time, 101, 250), meanonly
scalar rmse = sqrt(r(sum) / 150)
scalar se_missing = .

foreach f in 101 150 200 250 {
    quietly summarize forecast if time == `f', meanonly
    scalar forecast_`f' = r(mean)
}

display "ANSWER: rmse estimate=" %21.12f rmse " se=" %21.12f se_missing " n_obs=" %12.0f 150
display "ANSWER: forecast_101 estimate=" %21.12f forecast_101 " se=" %21.12f se_missing " n_obs=" %12.0f 99
display "ANSWER: forecast_150 estimate=" %21.12f forecast_150 " se=" %21.12f se_missing " n_obs=" %12.0f 99
display "ANSWER: forecast_200 estimate=" %21.12f forecast_200 " se=" %21.12f se_missing " n_obs=" %12.0f 99
display "ANSWER: forecast_250 estimate=" %21.12f forecast_250 " se=" %21.12f se_missing " n_obs=" %12.0f 99
