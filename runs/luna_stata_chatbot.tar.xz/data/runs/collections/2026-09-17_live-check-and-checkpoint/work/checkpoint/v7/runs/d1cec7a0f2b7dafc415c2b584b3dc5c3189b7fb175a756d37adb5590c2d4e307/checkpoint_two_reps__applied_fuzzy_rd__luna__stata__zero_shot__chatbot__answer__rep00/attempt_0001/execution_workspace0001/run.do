clear all
set linesize 255

import delimited using "./input.csv", clear

keep if !missing(score, participated, earnings)
keep if abs(score) < 1

mata:
    real matrix z, X, A, B, M
    real colvector s, p, y, w, e_y, e_p, b_y, b_p
    real scalar n, i, j, rf, fs, te, var_rf, var_fs, cov_rf_fs, var_te

    z = st_data(., "score participated earnings")
    s = z[,1]
    p = z[,2]
    y = z[,3]
    n = rows(z)

    X = J(n, 4, 0)
    w = J(n, 1, 0)

    for (i=1; i<=n; i++) {
        w[i] = 1 - abs(s[i])
        if (s[i] < 0) {
            X[i,1] = 1
            X[i,2] = s[i]
        }
        else {
            X[i,3] = 1
            X[i,4] = s[i]
        }
    }

    A = quadcross(X, w, X)
    A = invsym(A)

    b_y = A * quadcross(X, w, y)
    b_p = A * quadcross(X, w, p)

    e_y = y - X*b_y
    e_p = p - X*b_p

    M = J(4,4,0)
    for (i=1; i<=n; i++)
        M = M + (w[i]^2 * e_y[i]^2) * (X[i,]') * X[i,]
    var_rf = (-(1,0,0,0) + (0,0,1,0)) * A * M * A * (-(1,0,0,0) + (0,0,1,0))'

    M = J(4,4,0)
    for (i=1; i<=n; i++)
        M = M + (w[i]^2 * e_p[i]^2) * (X[i,]') * X[i,]
    var_fs = (-(1,0,0,0) + (0,0,1,0)) * A * M * A * (-(1,0,0,0) + (0,0,1,0))'

    M = J(4,4,0)
    for (i=1; i<=n; i++)
        M = M + (w[i]^2 * e_y[i] * e_p[i]) * (X[i,]') * X[i,]
    cov_rf_fs = (-(1,0,0,0) + (0,0,1,0)) * A * M * A * (-(1,0,0,0) + (0,0,1,0))'

    rf = b_y[3] - b_y[1]
    fs = b_p[3] - b_p[1]

    if (fs != 0) {
        te = rf/fs
        var_te = (1/fs)^2 * var_rf + (rf/fs^2)^2 * var_fs - 2*(1/fs)*(rf/fs^2)*cov_rf_fs
        if (var_te >= 0)
            st_numscalar("se_te", sqrt(var_te))
        else
            st_numscalar("se_te", .)
        st_numscalar("te", te)
    }
    else {
        st_numscalar("te", .)
        st_numscalar("se_te", .)
    }

    if (var_rf >= 0)
        st_numscalar("se_rf", sqrt(var_rf))
    else
        st_numscalar("se_rf", .)

    if (var_fs >= 0)
        st_numscalar("se_fs", sqrt(var_fs))
    else
        st_numscalar("se_fs", .)

    st_numscalar("rf", rf)
    st_numscalar("fs", fs)
    st_numscalar("n_obs", n)
end

display "ANSWER: treatment_effect estimate=" %21.12f scalar(te) " se=" %21.12f scalar(se_te) " n_obs=" %12.0f scalar(n_obs)
display "ANSWER: reduced_form estimate=" %21.12f scalar(rf) " se=" %21.12f scalar(se_rf) " n_obs=" %12.0f scalar(n_obs)
display "ANSWER: first_stage estimate=" %21.12f scalar(fs) " se=" %21.12f scalar(se_fs) " n_obs=" %12.0f scalar(n_obs)
