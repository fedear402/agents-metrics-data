clear all
set more off
set linesize 255
set type double

import delimited using "./input.csv", clear

mata:
y = st_data(., "y")
e = st_data(., "endog")
x = st_data(., "x")
z1 = st_data(., "z1")
z2 = st_data(., "z2")

n = rows(y)
q = 2
df = n - 4
critical = invFtail(q, df, .05)
k = q * critical / df

Xr = (J(n, 1, 1), x)
Xu = (J(n, 1, 1), x, z1, z2)

yr = y - Xr * qrsolve(Xr, y)
er = e - Xr * qrsolve(Xr, e)
yu = y - Xu * qrsolve(Xu, y)
eu = e - Xu * qrsolve(Xu, e)

A = quadcross(er, er) - (1 + k) * quadcross(eu, eu)
B = -2 * (quadcross(yr, er) - (1 + k) * quadcross(yu, eu))
C = quadcross(yr, yr) - (1 + k) * quadcross(yu, yu)

disc = B^2 - 4 * A * C
root1 = (-B - sqrt(disc)) / (2 * A)
root2 = (-B + sqrt(disc)) / (2 * A)

bounds = sort((root1 \ root2), 1)

ssr_r_1 = quadcross(yr - er, yr - er)
ssr_u_1 = quadcross(yu - eu, yu - eu)
ar_f_1 = ((ssr_r_1 - ssr_u_1) / q) / (ssr_u_1 / df)

st_numscalar("boundary_low", bounds[1])
st_numscalar("boundary_high", bounds[2])
st_numscalar("accepts_zero", C <= 0)
st_numscalar("unbounded", (A < 0))
st_numscalar("ar_f_at_one", ar_f_1)
st_numscalar("n_obs", n)
end

display "ANSWER: boundary_low estimate=" %21.12f scalar(boundary_low) " se=." " n_obs=" %12.0f scalar(n_obs)
display "ANSWER: boundary_high estimate=" %21.12f scalar(boundary_high) " se=." " n_obs=" %12.0f scalar(n_obs)
display "ANSWER: accepts_zero estimate=" %21.12f scalar(accepts_zero) " se=." " n_obs=" %12.0f scalar(n_obs)
display "ANSWER: unbounded estimate=" %21.12f scalar(unbounded) " se=." " n_obs=" %12.0f scalar(n_obs)
display "ANSWER: ar_f_at_one estimate=" %21.12f scalar(ar_f_at_one) " se=." " n_obs=" %12.0f scalar(n_obs)
