version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

sort region_id industry_id
by region_id: gen byte region_tag = (_n == 1)

egen double total_region_weight = total(cond(region_tag, region_weight, 0))
gen double e = region_weight / total_region_weight

by region_id: replace e = e[1]

egen double z = total(share * shock), by(region_id)

egen double mean_y = total(cond(region_tag, e * y, 0))
egen double mean_x = total(cond(region_tag, e * x, 0))
egen double mean_z = total(cond(region_tag, e * z, 0))

gen double y0 = y - mean_y
gen double x0 = x - mean_x
gen double z0 = z - mean_z

gen double exposure = e * share
gen double exposure_y = exposure * y0
gen double exposure_x = exposure * x0
gen double exposure_z = exposure * z0

collapse (sum) s=exposure y_num=exposure_y x_num=exposure_x z_num=exposure_z ///
    (firstnm) shock, by(industry_id)

drop if s <= 0

gen double ybar = y_num / s
gen double xbar = x_num / s
gen double zbar = z_num / s

count
local n_industries = r(N)

mata:
    s = st_data(., "s")
    shock = st_data(., "shock")
    ybar = st_data(., "ybar")
    xbar = st_data(., "xbar")
    zbar = st_data(., "zbar")

    N = rows(s)
    Z = (J(N, 1, 1), shock)

    X_effect = (J(N, 1, 1), xbar)
    cross_effect = Z' * (s :* X_effect)
    beta_effect = luinv(cross_effect) * (Z' * (s :* ybar))
    residual_effect = ybar - X_effect * beta_effect
    scores_effect = Z :* (s :* residual_effect)
    V_effect = (N / (N - 2)) * luinv(cross_effect) * ///
        (scores_effect' * scores_effect) * luinv(cross_effect)'
    se_effect = sqrt(V_effect[2, 2])

    X_first = (J(N, 1, 1), zbar)
    cross_first = Z' * (s :* X_first)
    beta_first = luinv(cross_first) * (Z' * (s :* xbar))
    residual_first = xbar - X_first * beta_first
    scores_first = Z :* (s :* residual_first)
    V_first = (N / (N - 2)) * luinv(cross_first) * ///
        (scores_first' * scores_first) * luinv(cross_first)'
    se_first = sqrt(V_first[2, 2])

    effective_shocks = 1 / sum(s:^2)

    st_numscalar("effect_estimate", beta_effect[2])
    st_numscalar("effect_se", se_effect)
    st_numscalar("first_stage_estimate", beta_first[2])
    st_numscalar("first_stage_se", se_first)
    st_numscalar("effective_shocks_estimate", effective_shocks)
end

display "ANSWER: effect estimate=" %21.12f scalar(effect_estimate) ///
    " se=" %21.12f scalar(effect_se) ///
    " n_obs=" %12.0f `n_industries'

display "ANSWER: first_stage estimate=" %21.12f scalar(first_stage_estimate) ///
    " se=" %21.12f scalar(first_stage_se) ///
    " n_obs=" %12.0f `n_industries'

display "ANSWER: effective_shocks estimate=" %21.12f scalar(effective_shocks_estimate) ///
    " se=." ///
    " n_obs=" %12.0f `n_industries'
