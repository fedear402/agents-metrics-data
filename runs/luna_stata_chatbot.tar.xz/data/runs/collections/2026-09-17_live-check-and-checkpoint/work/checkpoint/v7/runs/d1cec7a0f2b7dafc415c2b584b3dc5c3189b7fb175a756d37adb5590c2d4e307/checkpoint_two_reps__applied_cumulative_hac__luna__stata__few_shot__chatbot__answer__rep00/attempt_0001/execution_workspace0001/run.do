version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", varnames(1) clear

generate double trading_day = date(date, "YMD")
sort trading_day
generate long observation = _n
tsset observation

generate double log_vix = log(vix)
generate double volatility_change = D.log_vix
generate double log_sales = log(sales)

forvalues j = 1/15 {
    generate double lag_`j' = L`j'.volatility_change
}

keep if !missing(log_sales, lag_1, lag_2, lag_3, lag_4, lag_5, ///
    lag_6, lag_7, lag_8, lag_9, lag_10, lag_11, lag_12, lag_13, ///
    lag_14, lag_15)

mata:
    X = (J(st_nobs(), 1, 1), st_data(., ///
        ("lag_1", "lag_2", "lag_3", "lag_4", "lag_5", ///
         "lag_6", "lag_7", "lag_8", "lag_9", "lag_10", ///
         "lag_11", "lag_12", "lag_13", "lag_14", "lag_15")))
    y = st_data(., "log_sales")

    coefficients = qrsolve(X, y)
    residuals = y - X * coefficients

    N = rows(X)
    p = cols(X)
    hac_lags = 15

    scores = X :* residuals
    meat = scores' * scores

    for (j = 1; j <= hac_lags; j++) {
        lag_product = scores[|j + 1, 1 \ N, p|]' * ///
            scores[|1, 1 \ N - j, p|]
        bartlett_weight = 1 - j / 16
        meat = meat + bartlett_weight * ///
            (lag_product + lag_product')
    }

    bread = invsym(X' * X)
    covariance = (N / (N - 16)) * bread * meat * bread

    contrast = (0 \ J(15, 1, 1))
    cumulative_response = contrast' * coefficients
    cumulative_se = sqrt(contrast' * covariance * contrast)

    lag_1_estimate = coefficients[2]
    lag_1_se = sqrt(covariance[2, 2])

    lag_15_estimate = coefficients[16]
    lag_15_se = sqrt(covariance[16, 16])

    st_numscalar("cumulative_response", cumulative_response)
    st_numscalar("cumulative_se", cumulative_se)
    st_numscalar("lag_1_estimate", lag_1_estimate)
    st_numscalar("lag_1_se", lag_1_se)
    st_numscalar("lag_15_estimate", lag_15_estimate)
    st_numscalar("lag_15_se", lag_15_se)
    st_numscalar("n_obs", N)
end

display "ANSWER: cumulative_response estimate=" %21.12f cumulative_response ///
    " se=" %21.12f cumulative_se " n_obs=" %12.0f n_obs

display "ANSWER: lag_1 estimate=" %21.12f lag_1_estimate ///
    " se=" %21.12f lag_1_se " n_obs=" %12.0f n_obs

display "ANSWER: lag_15 estimate=" %21.12f lag_15_estimate ///
    " se=" %21.12f lag_15_se " n_obs=" %12.0f n_obs
