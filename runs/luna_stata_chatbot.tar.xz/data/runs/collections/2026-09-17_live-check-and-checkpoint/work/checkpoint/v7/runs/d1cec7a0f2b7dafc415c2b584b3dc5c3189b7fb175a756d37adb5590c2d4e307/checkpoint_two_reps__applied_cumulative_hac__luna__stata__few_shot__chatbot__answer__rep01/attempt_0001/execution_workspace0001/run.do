version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear varnames(1)

rename date date_text
generate double day = date(date_text, "YMD")
sort day
generate long observation = _n
tsset observation

generate double log_vix = log(vix)
generate double change_vix = D.log_vix
generate double log_sales = log(sales)

local lagvars
forvalues j = 1/15 {
    generate double lag_`j' = L`j'.change_vix
    local lagvars `lagvars' lag_`j'
}

keep if !missing(log_sales, `lagvars')

mata:
X = (J(st_nobs(), 1, 1), st_data(., "`lagvars'"))
y = st_data(., "log_sales")

coefficients = qrsolve(X, y)
residuals = y - X * coefficients

N = rows(X)
p = cols(X)
hac_lags = 15

scores = X :* residuals
meat = scores' * scores

for (j = 1; j <= hac_lags; j++) {
    lag_product = scores[|j+1, 1 \ N, p|]' * scores[|1, 1 \ N-j, p|]
    meat = meat + (1 - j/16) * (lag_product + lag_product')
}

bread = invsym(X' * X)
covariance = N/(N-16) * bread * meat * bread

contrast = (0 \ J(15, 1, 1))
cumulative = contrast' * coefficients
cumulative_se = sqrt(contrast' * covariance * contrast)

st_numscalar("cumulative_estimate", cumulative)
st_numscalar("cumulative_se", cumulative_se)
st_numscalar("lag1_estimate", coefficients[2])
st_numscalar("lag1_se", sqrt(covariance[2,2]))
st_numscalar("lag15_estimate", coefficients[16])
st_numscalar("lag15_se", sqrt(covariance[16,16]))
st_numscalar("sample_n", N)
end

display "ANSWER: cumulative_response estimate=" %21.12f scalar(cumulative_estimate) " se=" %21.12f scalar(cumulative_se) " n_obs=" %12.0f scalar(sample_n)
display "ANSWER: lag_1 estimate=" %21.12f scalar(lag1_estimate) " se=" %21.12f scalar(lag1_se) " n_obs=" %12.0f scalar(sample_n)
display "ANSWER: lag_15 estimate=" %21.12f scalar(lag15_estimate) " se=" %21.12f scalar(lag15_se) " n_obs=" %12.0f scalar(sample_n)
