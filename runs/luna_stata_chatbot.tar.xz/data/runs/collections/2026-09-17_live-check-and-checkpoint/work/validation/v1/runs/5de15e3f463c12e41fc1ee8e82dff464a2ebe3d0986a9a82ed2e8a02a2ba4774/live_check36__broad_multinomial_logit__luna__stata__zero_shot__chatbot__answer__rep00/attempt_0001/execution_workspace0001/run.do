clear all
set linesize 255

import delimited "./input.csv", clear

mlogit y x z, baseoutcome(0)

scalar n_obs = e(N)

scalar x_cat1 = _b[1:x]
scalar se_x_cat1 = _se[1:x]

scalar z_cat1 = _b[1:z]
scalar se_z_cat1 = _se[1:z]

scalar x_cat2 = _b[2:x]
scalar se_x_cat2 = _se[2:x]

scalar z_cat2 = _b[2:z]
scalar se_z_cat2 = _se[2:z]

scalar p_cat2_zero = exp(_b[2:_cons]) / ///
    (1 + exp(_b[1:_cons]) + exp(_b[2:_cons]))

display "ANSWER: x_cat1 estimate=" %21.12f x_cat1 ///
    " se=" %21.12f se_x_cat1 " n_obs=" %12.0f n_obs

display "ANSWER: z_cat1 estimate=" %21.12f z_cat1 ///
    " se=" %21.12f se_z_cat1 " n_obs=" %12.0f n_obs

display "ANSWER: x_cat2 estimate=" %21.12f x_cat2 ///
    " se=" %21.12f se_x_cat2 " n_obs=" %12.0f n_obs

display "ANSWER: z_cat2 estimate=" %21.12f z_cat2 ///
    " se=" %21.12f se_z_cat2 " n_obs=" %12.0f n_obs

display "ANSWER: prob_cat2_zero estimate=" %21.12f p_cat2_zero ///
    " se=. n_obs=" %12.0f n_obs
