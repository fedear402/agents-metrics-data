set linesize 255
clear

import delimited "./input.csv", varnames(1)

* Sort by time and declare time series
sort t
tsset t

* Create y_lag1 (y_{t-1})
gen y_lag1 = L.y

* Create y_lead4 (y_{t+4})
gen y_lead4 = F4.y

* Estimate local projection: y_{t+4} on shock_t and y_{t-1} with intercept
* Using Newey-West SE with lag 4
newey y_lead4 shock y_lag1, lag(4)

local est_shock = _b[shock]
local se_shock  = _se[shock]
local nobs      = e(N)

display "ANSWER: irf_h4 estimate=" %21.12f `est_shock' " se=" %21.12f `se_shock' " n_obs=" %12.0f `nobs'
