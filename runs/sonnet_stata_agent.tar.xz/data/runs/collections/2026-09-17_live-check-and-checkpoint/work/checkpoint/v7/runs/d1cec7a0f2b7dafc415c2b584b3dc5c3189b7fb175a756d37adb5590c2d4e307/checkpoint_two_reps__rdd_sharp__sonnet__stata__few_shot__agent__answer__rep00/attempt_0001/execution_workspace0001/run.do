set linesize 255
clear

import delimited "./input.csv", varnames(1)

* Bandwidth and cutoff
local h = 0.5
local c = 0

* Triangular kernel weights: K(u) = 1 - |u/h|, for |u| <= h
gen dist = z - `c'
gen absdist = abs(dist)
gen kw = (1 - absdist/`h') if absdist <= `h'
drop if missing(kw)

* Right side: z >= 0
* Left side: z < 0
gen right = (z >= `c')

* Count observations in bandwidth
count
local n_total = r(N)

* Fit local linear regression on right side (z >= 0)
reg y dist [aw=kw] if right == 1
local b_right_0 = _b[_cons]  // intercept at z=0 for right side

* Fit local linear regression on left side (z < 0)
reg y dist [aw=kw] if right == 0
local b_left_0 = _b[_cons]   // intercept at z=0 for left side

* LATE = difference in intercepts (right - left)
local late = `b_right_0' - `b_left_0'

display "ANSWER: late estimate=" %21.12f `late' " se=. n_obs=" %12.0f `n_total'
