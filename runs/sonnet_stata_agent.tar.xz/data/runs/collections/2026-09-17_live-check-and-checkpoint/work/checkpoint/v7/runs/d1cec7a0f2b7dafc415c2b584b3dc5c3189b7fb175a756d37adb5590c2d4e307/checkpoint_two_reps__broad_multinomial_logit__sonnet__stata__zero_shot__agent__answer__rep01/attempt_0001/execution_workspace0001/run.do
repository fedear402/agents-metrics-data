set linesize 255
import delimited "./input.csv", clear

* Estimate multinomial logit with y=0 as base outcome
mlogit y x z, base(0) vce(oim)

* Store coefficients and SEs
* For category 1 (log P(y=1)/P(y=0))
scalar x_cat1_est = _b[1:x]
scalar x_cat1_se  = _se[1:x]
scalar z_cat1_est = _b[1:z]
scalar z_cat1_se  = _se[1:z]

* For category 2 (log P(y=2)/P(y=0))
scalar x_cat2_est = _b[2:x]
scalar x_cat2_se  = _se[2:x]
scalar z_cat2_est = _b[2:z]
scalar z_cat2_se  = _se[2:z]

* Fitted probability of outcome 2 at x=0, z=0
* P(y=2) = exp(a2) / (1 + exp(a1) + exp(a2))
* where a1 = intercept for cat1, a2 = intercept for cat2 (at x=0, z=0)
scalar cons1 = _b[1:_cons]
scalar cons2 = _b[2:_cons]
scalar denom = 1 + exp(cons1) + exp(cons2)
scalar prob_cat2_zero_est = exp(cons2) / denom

scalar n_obs = e(N)

* Display results
display "ANSWER: x_cat1 estimate=" %21.12f x_cat1_est " se=" %21.12f x_cat1_se " n_obs=" %12.0f n_obs
display "ANSWER: z_cat1 estimate=" %21.12f z_cat1_est " se=" %21.12f z_cat1_se " n_obs=" %12.0f n_obs
display "ANSWER: x_cat2 estimate=" %21.12f x_cat2_est " se=" %21.12f x_cat2_se " n_obs=" %12.0f n_obs
display "ANSWER: z_cat2 estimate=" %21.12f z_cat2_est " se=" %21.12f z_cat2_se " n_obs=" %12.0f n_obs
display "ANSWER: prob_cat2_zero estimate=" %21.12f prob_cat2_zero_est " se=. n_obs=" %12.0f n_obs
