version 16.0
set more off
set linesize 255

import delimited "./input.csv", clear

* Keep observations within bandwidth (abs(score) < 1)
keep if abs(score) < 1

* Triangular weights
gen w = 1 - abs(score)

* Above-cutoff indicator
gen above = (score >= 0)

* Interaction terms for separate slopes
gen score_left  = score * (1 - above)
gen score_right = score * above

* Count observations
count
local n_obs = r(N)

mata:
    // Load data
    Y = st_data(., ("earnings", "participated"))
    w = st_data(., "w")
    above    = st_data(., "above")
    sl       = st_data(., "score_left")
    sr       = st_data(., "score_right")
    n        = rows(Y)

    // Design matrix: intercept, above, left-slope, right-slope
    X = (J(n,1,1), above, sl, sr)

    // WLS: bread = (X'WX)^{-1}
    Xw = w :* X
    bread = invsym(X' * Xw)
    coef = bread * (Xw' * Y)

    // Residuals
    resid = Y - X * coef

    // Contrast selects the jump (coefficient on "above")
    contrast = (0 \ 1 \ 0 \ 0)

    // Discontinuity estimates
    jumps = contrast' * coef   // 1x2: [earnings_jump, participation_jump]

    // Influence (loading) for HC0 sandwich
    loading = w :* (X * bread * contrast)   // nx1
    influence = loading :* resid             // nx2

    // Joint HC0 covariance of the two discontinuity estimates
    joint = influence' * influence           // 2x2

    // Delta method for ratio
    rf = jumps[1]
    fs = jumps[2]
    grad = (1/fs \ -rf/fs^2)
    te_se = sqrt(grad' * joint * grad)

    // Store results
    st_numscalar("te_est",  rf/fs)
    st_numscalar("te_se",   te_se)
    st_numscalar("rf_est",  rf)
    st_numscalar("rf_se",   sqrt(joint[1,1]))
    st_numscalar("fs_est",  fs)
    st_numscalar("fs_se",   sqrt(joint[2,2]))
end

display "ANSWER: treatment_effect estimate=" %21.12f te_est " se=" %21.12f te_se " n_obs=" %12.0f `n_obs'
display "ANSWER: reduced_form estimate="     %21.12f rf_est " se=" %21.12f rf_se " n_obs=" %12.0f `n_obs'
display "ANSWER: first_stage estimate="      %21.12f fs_est " se=" %21.12f fs_se " n_obs=" %12.0f `n_obs'
