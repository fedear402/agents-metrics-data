set linesize 255
import delimited using "./input.csv", clear

stset t_obs, failure(event)
stcox treat x

scalar est_treat = _b[treat]
scalar se_treat  = _se[treat]
scalar est_x     = _b[x]
scalar se_x      = _se[x]
scalar n_obs     = e(N)

display "ANSWER: treat estimate=" %21.12f est_treat " se=" %21.12f se_treat " n_obs=" %12.0f n_obs
display "ANSWER: x estimate=" %21.12f est_x " se=" %21.12f se_x " n_obs=" %12.0f n_obs
