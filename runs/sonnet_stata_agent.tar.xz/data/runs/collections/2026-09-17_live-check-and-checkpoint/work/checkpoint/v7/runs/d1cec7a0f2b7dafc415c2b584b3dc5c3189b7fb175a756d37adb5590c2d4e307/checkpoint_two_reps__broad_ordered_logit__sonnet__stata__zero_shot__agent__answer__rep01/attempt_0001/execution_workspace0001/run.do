set linesize 255
import delimited using "./input.csv", clear

* Ordered logit model
ologit y x z

* Store estimates
scalar b_x = _b[x]
scalar b_z = _b[z]
scalar se_x = _se[x]
scalar se_z = _se[z]
scalar n = e(N)

* Predict probability of category 3 (prob_high) for x=1, z=0
* P(y=3) = 1 - F(cut2 - xb) where xb = b_x*1 + b_z*0
scalar cut2 = _b[/cut2]
scalar xb = b_x * 1 + b_z * 0
scalar prob_high = 1 - invlogit(cut2 - xb)

display "ANSWER: x estimate=" %21.12f b_x " se=" %21.12f se_x " n_obs=" %12.0f n
display "ANSWER: z estimate=" %21.12f b_z " se=" %21.12f se_z " n_obs=" %12.0f n
display "ANSWER: prob_high estimate=" %21.12f prob_high " se=." " n_obs=" %12.0f n
