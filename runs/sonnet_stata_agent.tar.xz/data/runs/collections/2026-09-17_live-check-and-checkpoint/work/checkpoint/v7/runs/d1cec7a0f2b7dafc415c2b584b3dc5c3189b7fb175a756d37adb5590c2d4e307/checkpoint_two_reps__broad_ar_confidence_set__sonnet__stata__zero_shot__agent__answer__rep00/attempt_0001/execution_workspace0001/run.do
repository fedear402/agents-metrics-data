set linesize 255
clear all

* Import data
import delimited "./input.csv", clear
scalar n = _N  // 240

* The model: y = a + beta*endog + gamma*x + error
* For each beta, regress (y - beta*endog) on [1, x, z1, z2]
* F-test of z1 and z2 coefficients jointly
* n-4 denominator df (4 regressors: intercept, x, z1, z2)

* We need quadratic components:
* Let M_x = residual maker for [1, x]
* Let M_z = residual maker for [1, x, z1, z2]
*
* RSS_r(beta) = (y - beta*endog)' M_x (y - beta*endog)
* RSS_u(beta) = (y - beta*endog)' M_z (y - beta*endog)
*
* Each is quadratic in beta: A*beta^2 - 2*B*beta + C

* Get residuals from regressing on [1, x] - restricted
quietly reg y x
predict double res_y_x, resid
quietly reg endog x
predict double res_e_x, resid

scalar A_r = 0
scalar B_r = 0
scalar C_r = 0
quietly {
    gen double tmp1 = res_e_x * res_e_x
    gen double tmp2 = res_y_x * res_e_x
    gen double tmp3 = res_y_x * res_y_x
    sum tmp1, meanonly
    scalar A_r = r(sum)
    sum tmp2, meanonly
    scalar B_r = r(sum)
    sum tmp3, meanonly
    scalar C_r = r(sum)
    drop tmp1 tmp2 tmp3
}

* Get residuals from regressing on [1, x, z1, z2] - unrestricted
quietly reg y x z1 z2
predict double res_y_xz, resid
quietly reg endog x z1 z2
predict double res_e_xz, resid

scalar A_u = 0
scalar B_u = 0
scalar C_u = 0
quietly {
    gen double tmp1 = res_e_xz * res_e_xz
    gen double tmp2 = res_y_xz * res_e_xz
    gen double tmp3 = res_y_xz * res_y_xz
    sum tmp1, meanonly
    scalar A_u = r(sum)
    sum tmp2, meanonly
    scalar B_u = r(sum)
    sum tmp3, meanonly
    scalar C_u = r(sum)
    drop tmp1 tmp2 tmp3
}

* F critical value: F(2, n-4) at 95th percentile
scalar df1 = 2
scalar df2 = n - 4
scalar Fcrit = invFtail(df1, df2, 0.05)

display "n = " n ", df2 = " df2 ", Fcrit = " Fcrit

* The boundary equation: F(beta) = Fcrit
* k*(Num) = Fcrit * Denom
* where Num = RSS_r - RSS_u, Denom = RSS_u, k = (n-4)/2
*
* Num = (C_r - C_u) - 2*beta*(B_r - B_u) + beta^2*(A_r - A_u)
* Denom = C_u - 2*beta*B_u + beta^2*A_u
*
* k*Num = Fcrit*Denom
* [k*(A_r-A_u) - Fcrit*A_u]*beta^2 + [-2*k*(B_r-B_u) + 2*Fcrit*B_u]*beta + [k*(C_r-C_u) - Fcrit*C_u] = 0

scalar k = (n - 4) / 2

scalar coef2 = k * (A_r - A_u) - Fcrit * A_u
scalar coef1 = -2 * k * (B_r - B_u) + 2 * Fcrit * B_u
scalar coef0 = k * (C_r - C_u) - Fcrit * C_u

display "Quadratic coefficients: coef2=" coef2 " coef1=" coef1 " coef0=" coef0

scalar disc = coef1^2 - 4 * coef2 * coef0
display "Discriminant = " disc

* Compute roots
scalar root1 = (-coef1 - sqrt(disc)) / (2 * coef2)
scalar root2 = (-coef1 + sqrt(disc)) / (2 * coef2)

display "root1 = " root1 ", root2 = " root2

* Determine confidence set structure
* coef2 > 0: parabola opens up, F < Fcrit between roots -> CI is [root_low, root_high]
* coef2 < 0: parabola opens down, F < Fcrit outside roots -> CI is (-inf, root_low) U (root_high, +inf) [unbounded]

scalar boundary_low = min(root1, root2)
scalar boundary_high = max(root1, root2)

* Check if set is unbounded (coef2 < 0)
scalar unbounded = (coef2 < 0)

* Compute F at beta=0 to check accepts_zero
* RSS_r(0) = C_r, RSS_u(0) = C_u
scalar F_at_zero = (k / Fcrit) * . // placeholder
scalar Num_0 = C_r - C_u
scalar Denom_0 = C_u
scalar F_at_zero = k * Num_0 / Denom_0
display "F at beta=0: " F_at_zero " vs Fcrit=" Fcrit

* accepts_zero: F_at_zero <= Fcrit
* If unbounded, zero is in set if it's outside the roots; if bounded, zero is in set if between roots
if unbounded == 0 {
    scalar accepts_zero = (F_at_zero <= Fcrit)
} 
else {
    * Unbounded: set is (-inf, boundary_low] U [boundary_high, +inf)
    scalar accepts_zero = (0 <= boundary_low | 0 >= boundary_high)
}

* Compute F at beta=1
scalar Num_1 = (C_r - C_u) - 2*(B_r - B_u) + (A_r - A_u)
scalar Denom_1 = C_u - 2*B_u + A_u
scalar ar_f_at_one = k * Num_1 / Denom_1

display "F at beta=1: " ar_f_at_one

* Report results
display "ANSWER: boundary_low estimate=" %21.12f boundary_low " se=" %21.12f . " n_obs=" %12.0f n
display "ANSWER: boundary_high estimate=" %21.12f boundary_high " se=" %21.12f . " n_obs=" %12.0f n
display "ANSWER: accepts_zero estimate=" %21.12f accepts_zero " se=" %21.12f . " n_obs=" %12.0f n
display "ANSWER: unbounded estimate=" %21.12f unbounded " se=" %21.12f . " n_obs=" %12.0f n
display "ANSWER: ar_f_at_one estimate=" %21.12f ar_f_at_one " se=" %21.12f . " n_obs=" %12.0f n

* ---- NUMERICAL VERIFICATION ----
* Verify F at beta=1 directly using Stata regression
gen double y_adj = y - 1 * endog
quietly reg y_adj x z1 z2
test z1 z2
display "Direct F test at beta=1: " r(F) " (should match ar_f_at_one=" ar_f_at_one ")"
drop y_adj

* Verify F at beta=0
gen double y_adj0 = y - 0 * endog
quietly reg y_adj0 x z1 z2
test z1 z2
display "Direct F test at beta=0: " r(F) " (should match F_at_zero=" F_at_zero ")"
drop y_adj0

* Verify boundary points by computing F at them
scalar F_at_blo = k * ((C_r - C_u) - 2*(B_r-B_u)*boundary_low + (A_r-A_u)*boundary_low^2) / ///
                      (C_u - 2*B_u*boundary_low + A_u*boundary_low^2)
scalar F_at_bhi = k * ((C_r - C_u) - 2*(B_r-B_u)*boundary_high + (A_r-A_u)*boundary_high^2) / ///
                      (C_u - 2*B_u*boundary_high + A_u*boundary_high^2)
display "F at boundary_low=" boundary_low ": " F_at_blo " (should be ~" Fcrit ")"
display "F at boundary_high=" boundary_high ": " F_at_bhi " (should be ~" Fcrit ")"

