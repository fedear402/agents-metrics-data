set linesize 255
import delimited "./input.csv", clear

* Estimate ordered logit model
ologit y x z

* Store results
local n_obs = e(N)
matrix b = e(b)
matrix V = e(V)

* Get coefficients - in ologit, x and z are first, then cutpoints
* b matrix: x, z, cut1, cut2
local b_x = b[1,1]
local b_z = b[1,2]
local se_x = sqrt(V[1,1])
local se_z = sqrt(V[2,2])

* Compute prob_high (P(y=3)) for x=1, z=0
* P(y=3) = 1 - F(cut2 - (b_x*1 + b_z*0))
* For logistic: F(t) = exp(t)/(1+exp(t))
local cut2 = b[1,4]
local xb = `b_x' * 1 + `b_z' * 0
local arg = `cut2' - `xb'
local prob_high = 1 - (exp(`arg') / (1 + exp(`arg')))

display "ANSWER: x estimate=" %21.12f `b_x' " se=" %21.12f `se_x' " n_obs=" %12.0f `n_obs'
display "ANSWER: z estimate=" %21.12f `b_z' " se=" %21.12f `se_z' " n_obs=" %12.0f `n_obs'
display "ANSWER: prob_high estimate=" %21.12f `prob_high' " se=." " n_obs=" %12.0f `n_obs'
