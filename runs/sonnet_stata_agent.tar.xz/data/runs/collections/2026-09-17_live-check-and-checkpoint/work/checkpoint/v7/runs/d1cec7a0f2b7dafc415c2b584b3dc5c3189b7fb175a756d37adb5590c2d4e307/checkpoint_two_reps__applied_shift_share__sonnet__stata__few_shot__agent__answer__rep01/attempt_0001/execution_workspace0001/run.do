version 16
clear all
set more off
set linesize 255

// Load data
import delimited "./input.csv", clear

// Step 1: Normalize regional weights using one obs per region
// e_r = region_weight_r / sum_r region_weight_r
bysort region_id (industry_id): gen first_in_region = (_n == 1)
quietly summ region_weight if first_in_region == 1
local sum_weights = r(sum)
gen e_r = region_weight / `sum_weights'

// Step 2: Construct regional instrument z_r = sum_n share_rn * shock_n
gen share_shock = share * shock
bysort region_id: egen z_r = total(share_shock)

// Step 3: Collapse to region level (x, y, z_r, e_r all constant within region)
bysort region_id (industry_id): keep if _n == 1
// Verify e_r sums to 1
quietly summ e_r
di "Sum of e_r = " r(sum)  // should be 1

// Step 4: Subtract e_r-weighted regional means
foreach v in y x z_r {
    gen wt_`v' = e_r * `v'
    quietly summ wt_`v'
    gen `v'0 = `v' - r(sum)
    drop wt_`v'
}

// Verify weighted means are zero
foreach v in y x z_r {
    gen chk = e_r * `v'0
    quietly summ chk
    di "Weighted mean of `v'0 = " r(sum)
    drop chk
}

// Save region-level data
tempfile region_data
save `region_data'

// Step 5: Go back to full data for shock-level aggregation
import delimited "./input.csv", clear

// Re-normalize weights
bysort region_id (industry_id): gen first_in_region = (_n == 1)
quietly summ region_weight if first_in_region == 1
local sum_weights = r(sum)
gen e_r = region_weight / `sum_weights'

// Construct z_r
gen share_shock = share * shock
bysort region_id: egen z_r = total(share_shock)

// Merge in demeaned regional variables
bysort region_id (industry_id): keep if _n == 1
merge 1:1 region_id using `region_data', keepusing(y0 x0 z_r0) nogen

// Now merge these demeaned values back to full data
keep region_id y0 x0 z_r0 e_r
tempfile region_demeaned
save `region_demeaned'

import delimited "./input.csv", clear
bysort region_id (industry_id): gen first_in_region = (_n == 1)
quietly summ region_weight if first_in_region == 1
local sum_weights = r(sum)
gen e_r = region_weight / `sum_weights'
gen share_shock = share * shock
bysort region_id: egen z_r = total(share_shock)

merge m:1 region_id using `region_demeaned', keepusing(y0 x0 z_r0) nogen

// Step 6: Construct shock-level aggregates
// s_n = sum_r e_r * share_rn
// vbar_n = sum_r e_r * share_rn * v0_r / s_n

gen ew_share = e_r * share
bysort industry_id: egen s_n = total(ew_share)

foreach v in y x z_r {
    gen ew_`v' = e_r * share * `v'0
    bysort industry_id: egen sum_ew_`v' = total(ew_`v')
    gen `v'bar_n = sum_ew_`v' / s_n
}

// Also get shock (constant within industry)
bysort industry_id (region_id): gen shock_n = shock[1]

// Collapse to industry level
bysort industry_id (region_id): keep if _n == 1
keep industry_id s_n ybar_n xbar_n z_rbar_n shock_n

count
local N_industries = r(N)
di "Number of industries: " `N_industries'

// Step 7: Shock-level IV regression of ybar_n on xbar_n, instrument shock_n, weights s_n
// First verify: shock-level slope should equal regional 2SLS slope

// Manual IV: beta_IV = (sum s_n * shock_n * ybar_n) / (sum s_n * shock_n * xbar_n)
// (after partialling out intercept = after centering by s_n-weighted means)
// But we include intercept, so need to partial it out

// s_n-weighted means
gen sw_y = s_n * ybar_n
gen sw_x = s_n * xbar_n
gen sw_z = s_n * shock_n
gen sw_zbar = s_n * z_rbar_n
quietly summ sw_y
local mean_y = r(sum)
quietly summ sw_x
local mean_x = r(sum)
quietly summ sw_z
local mean_z = r(sum)
quietly summ sw_zbar
local mean_zbar = r(sum)
quietly summ s_n
local sum_sn = r(sum)

gen ybar_dm = ybar_n - `mean_y'/`sum_sn'
gen xbar_dm = xbar_n - `mean_x'/`sum_sn'
gen shock_dm = shock_n - `mean_z'/`sum_sn'
gen zbar_dm = z_rbar_n - `mean_zbar'/`sum_sn'

// IV slope for effect: beta = (s_n-weighted cov of shock_dm and ybar_dm) / (s_n-weighted cov of shock_dm and xbar_dm)
gen num_effect = s_n * shock_dm * ybar_dm
gen den_effect = s_n * shock_dm * xbar_dm
quietly summ num_effect
local num_e = r(sum)
quietly summ den_effect
local den_e = r(sum)
local beta_effect = `num_e' / `den_e'
di "Effect beta = " `beta_effect'

// IV slope for first_stage: beta = (s_n-weighted cov of shock_dm and xbar_dm) / (s_n-weighted cov of shock_dm and zbar_dm)
gen num_fs = s_n * shock_dm * xbar_dm
gen den_fs = s_n * shock_dm * zbar_dm
quietly summ num_fs
local num_f = r(sum)
quietly summ den_fs
local den_f = r(sum)
local beta_fs = `num_f' / `den_f'
di "First-stage beta = " `beta_fs'

// Step 8: HC1 standard errors
// Effect regression: structural residuals from IV
// Fitted xbar_dm_hat using instrument, then residual from y on (1, x) is y - intercept - beta*x
// Structural residual: e_n = ybar_dm - beta_effect * xbar_dm

gen resid_effect = ybar_dm - `beta_effect' * xbar_dm
gen resid_fs = xbar_dm - `beta_fs' * zbar_dm

// Score for effect: instrument * weight * residual
// score_n = shock_dm * s_n * resid_effect_n
// But the IV formula: beta = (Z'W X)^{-1} Z'W y  where W = diag(s_n), Z = [1, shock_dm], X = [1, xbar_dm]
// HC1 variance = N/(N-2) * (Z'WX)^{-1} (sum_n s_n^2 * shock_dm_n^2 * resid_n^2 * ...) 

// For 2x2 case with demeaned data (intercept partialled out), the IV estimator reduces to scalar
// The "design matrix" in demeaned space: instrument = shock_dm (scalar per obs)
// Score_n = shock_dm_n * (s_n * resid_effect_n) -- but one weight in score gives s_n in outer product
// Actually following the example: scores = instruments :* (mass :* residual)
// where instruments are demeaned shocks, mass = s_n, residual = structural residual
// beta = (Z'WX)^{-1} Z'Wy, where W=diag(s_n), Z=[1,shock], X=[1,xbar]
// In partitioned form with intercept, the slope part uses demeaned variables
// score for slope = shock_dm_n * s_n * resid_n  (following the example structure)

// Following the example exactly:
// regressors = (ones, endogenous), instruments = (ones, shock_n), weights = s_n
// cross = instruments' * (s_n :* regressors)  [2x2 matrix]
// inverse = inv(cross)
// beta = inverse * instruments' * (s_n :* dependent)
// residual = dependent - regressors * beta
// scores = instruments :* (s_n :* residual)  [N x 2 matrix]
// covariance = N/(N-2) * inverse * (scores'*scores) * inverse'

// Let me compute this properly in matrix form
// For effect regression:
matrix define ones = J(`N_industries', 1, 1)
mkmat ybar_n xbar_n shock_n z_rbar_n s_n, matrix(data_mat)

// Use mata for matrix calculations
mata:
    data = st_matrix("data_mat")
    ybar = data[,1]
    xbar = data[,2]
    shock = data[,3]
    zbar = data[,4]
    s = data[,5]
    N = rows(data)
    
    // Effect regression: y on (1,x), instrument (1,shock), weights s
    dep_e = ybar
    endog_e = xbar
    regressors_e = (J(N,1,1), endog_e)
    instruments_e = (J(N,1,1), shock)
    
    cross_e = instruments_e' * (s :* regressors_e)
    inv_e = luinv(cross_e)
    beta_e = inv_e * instruments_e' * (s :* dep_e)
    resid_e = dep_e - regressors_e * beta_e
    scores_e = instruments_e :* (s :* resid_e)
    cov_e = N/(N-2) * inv_e * (scores_e' * scores_e) * inv_e'
    
    effect_est = beta_e[2]
    effect_se = sqrt(cov_e[2,2])
    
    // First-stage regression: x on (1,zbar), instrument (1,shock), weights s
    dep_f = xbar
    endog_f = zbar
    regressors_f = (J(N,1,1), endog_f)
    instruments_f = (J(N,1,1), shock)
    
    cross_f = instruments_f' * (s :* regressors_f)
    inv_f = luinv(cross_f)
    beta_f = inv_f * instruments_f' * (s :* dep_f)
    resid_f = dep_f - regressors_f * beta_f
    scores_f = instruments_f :* (s :* resid_f)
    cov_f = N/(N-2) * inv_f * (scores_f' * scores_f) * inv_f'
    
    fs_est = beta_f[2]
    fs_se = sqrt(cov_f[2,2])
    
    // Effective shocks
    eff_shocks = 1 / sum(s:^2)
    
    printf("Effect slope = %21.15g\n", effect_est)
    printf("Effect SE = %21.15g\n", effect_se)
    printf("FS slope = %21.15g\n", fs_est)
    printf("FS SE = %21.15g\n", fs_se)
    printf("Effective shocks = %21.15g\n", eff_shocks)
    
    st_numscalar("effect_est", effect_est)
    st_numscalar("effect_se", effect_se)
    st_numscalar("fs_est", fs_est)
    st_numscalar("fs_se", fs_se)
    st_numscalar("eff_shocks", eff_shocks)
    st_numscalar("N_ind", N)
end

display "ANSWER: effect estimate=" %21.12f effect_est " se=" %21.12f effect_se " n_obs=" %12.0f N_ind
display "ANSWER: first_stage estimate=" %21.12f fs_est " se=" %21.12f fs_se " n_obs=" %12.0f N_ind
display "ANSWER: effective_shocks estimate=" %21.12f eff_shocks " se=" %21.12f . " n_obs=" %12.0f N_ind

