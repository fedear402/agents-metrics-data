set linesize 255
clear all

import delimited "./input.csv", varnames(1)

* Keep observations within bandwidth (strict inequality: abs(score) < 1)
keep if abs(score) < 1

count
scalar n_obs = r(N)

* Generate triangular weights
gen weight = 1 - abs(score)

* Generate treatment indicator (right side: score >= 0)
gen right = (score >= 0)

* Generate interaction terms for local linear regression
gen score_right = score * right
gen score_left  = score * (1 - right)

* ============================================================
* Manual HC0 computation in Mata
* Model: Y = intercept + right + score_left + score_right
* Same X and weights for both outcomes
* ============================================================
mata:
    // Load data
    y_earn  = st_data(., "earnings")
    y_part  = st_data(., "participated")
    w       = st_data(., "weight")
    right_v = st_data(., "right")
    sl      = st_data(., "score_left")
    sr      = st_data(., "score_right")
    
    n = rows(y_earn)
    
    // Build X matrix: intercept, right, score_left, score_right
    X = J(n, 4, 1)
    X[., 2] = right_v
    X[., 3] = sl
    X[., 4] = sr
    
    // Weight matrix (aweights: use raw weights, Stata normalizes aweights)
    // For analytic weights, Stata scales: w_scaled = w * n / sum(w)
    // We use raw weights since we want 1-abs(score) directly
    // Actually for HC0 consistency we use the raw weights as given
    W = diag(w)
    
    // Weighted X'WX and its inverse
    XtWX = X' * W * X
    XtWXi = luinv(XtWX)
    
    // WLS coefficients
    b_earn = XtWXi * X' * W * y_earn
    b_part = XtWXi * X' * W * y_part
    
    // Residuals
    e_earn = y_earn - X * b_earn
    e_part = y_part - X * b_part
    
    // HC0 sandwich: V = (X'WX)^{-1} * (X'W diag(e^2) WX) * (X'WX)^{-1}
    // For weighted case: meat = X' * W * diag(e^2) * W * X
    //   = X' * diag(w .* e^2) * X  [since W*diag(e^2)*W = diag(w)*diag(e^2)*diag(w)]
    //   Wait: W * diag(e^2) * W = diag(w) * diag(e^2) * diag(w) = diag(w .* e .* w .* e)?
    //   No: diag(w)*diag(e^2)*diag(w) = diag(w .* e^2 .* w) = diag(w^2 .* e^2)
    // Hmm, need to be careful about the weighted HC0 formula
    //
    // For WLS, the bread is (X'WX)^{-1}
    // The meat for HC0 is: X' * W * diag(e^2) * W * X
    //   where e = y - X*b are the weighted residuals from WLS
    // This gives: sum_i w_i^2 * e_i^2 * x_i * x_i'
    
    // HC0 variance for earnings
    meat_earn = X' * diag(w:^2 :* e_earn:^2) * X
    V_earn = XtWXi * meat_earn * XtWXi
    
    // HC0 variance for participation
    meat_part = X' * diag(w:^2 :* e_part:^2) * X
    V_part = XtWXi * meat_part * XtWXi
    
    // HC0 cross-covariance
    meat_cross = X' * diag(w:^2 :* e_earn :* e_part) * X
    V_cross = XtWXi * meat_cross * XtWXi
    
    // Coefficient on 'right' is position 2
    rf_est = b_earn[2]
    fs_est = b_part[2]
    rf_se  = sqrt(V_earn[2,2])
    fs_se  = sqrt(V_part[2,2])
    
    // Delta method for TE = rf/fs
    te_est = rf_est / fs_est
    var_rf = V_earn[2,2]
    var_fs = V_part[2,2]
    cov_rf_fs = V_cross[2,2]
    
    d_rf = 1 / fs_est
    d_fs = -rf_est / fs_est^2
    var_te = d_rf^2 * var_rf + d_fs^2 * var_fs + 2 * d_rf * d_fs * cov_rf_fs
    te_se = sqrt(var_te)
    
    // Store results as Stata scalars
    st_numscalar("rf_est",  rf_est)
    st_numscalar("rf_se",   rf_se)
    st_numscalar("fs_est",  fs_est)
    st_numscalar("fs_se",   fs_se)
    st_numscalar("te_est",  te_est)
    st_numscalar("te_se",   te_se)
    
    printf("Coefficients check:\n")
    printf("  b_earn = %f %f %f %f\n", b_earn[1], b_earn[2], b_earn[3], b_earn[4])
    printf("  b_part = %f %f %f %f\n", b_part[1], b_part[2], b_part[3], b_part[4])
    printf("  n_obs  = %f\n", n)
    printf("  cov(rf,fs) = %f\n", cov_rf_fs)
end

display "ANSWER: treatment_effect estimate=" %21.12f te_est " se=" %21.12f te_se " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f rf_est " se=" %21.12f rf_se " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f fs_est " se=" %21.12f fs_se " n_obs=" %12.0f n_obs
