clear all
set more off
set linesize 255
set type double

import delimited "./input.csv", clear

* Check data
summarize y x z
tab y

* Fit ordered logit: y on x and z, no separate intercept (ologit uses cutpoints)
ologit y x z, tolerance(1e-10) nrtolerance(1e-10)

scalar n_obs = e(N)

* Extract coefficients and SEs
scalar b_x = _b[x]
scalar se_x = _se[x]
scalar b_z = _b[z]
scalar se_z = _se[z]

* Prob of category 3 at x=1, z=0
* P(y=3) = 1 - F(cut2 - (b_x*1 + b_z*0)) = 1 - logistic(cut2 - b_x)
scalar cut2 = _b[/cut2]
scalar xb_10 = b_x * 1 + b_z * 0
scalar prob_high = 1 - invlogit(cut2 - xb_10)

display "ANSWER: x estimate=" %21.12f b_x " se=" %21.12f se_x " n_obs=" %12.0f n_obs
display "ANSWER: z estimate=" %21.12f b_z " se=" %21.12f se_z " n_obs=" %12.0f n_obs
display "ANSWER: prob_high estimate=" %21.12f prob_high " se=." " n_obs=" %12.0f n_obs
