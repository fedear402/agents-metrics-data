set linesize 255
import delimited "./input.csv", clear

tobit y x z, ll(0)

scalar n = e(N)

* Extract coefficients by name
scalar b_const = _b[_cons]
scalar b_x = _b[x]
scalar b_z = _b[z]

* Standard errors
scalar se_const = _se[_cons]
scalar se_x = _se[x]
scalar se_z = _se[z]

* sigma: e(b) has /:var(e.y) as the 4th element = sigma^2
* sigma = sqrt(var(e.y))
matrix eb = e(b)
scalar b_sigma = sqrt(eb[1,4])

display "ANSWER: const estimate=" %21.12f b_const " se=" %21.12f se_const " n_obs=" %12.0f n
display "ANSWER: x estimate=" %21.12f b_x " se=" %21.12f se_x " n_obs=" %12.0f n
display "ANSWER: z estimate=" %21.12f b_z " se=" %21.12f se_z " n_obs=" %12.0f n
display "ANSWER: sigma estimate=" %21.12f b_sigma " se=. n_obs=" %12.0f n
