version 17.0
clear all
set more off
set linesize 255

import delimited "./input.csv", clear
sort time
tsset time

generate double lagged_y = L.y

generate double forecast = .

local window_levels = 100
local first_forecast = 101
local last_forecast = 250

forvalues f = `first_forecast'/`last_forecast' {
    local first_response = `f' - `window_levels' + 1
    local last_response = `f' - 1
    quietly regress y lagged_y if inrange(time, `first_response', `last_response')
    assert e(N) == `window_levels' - 1
    quietly replace forecast = _b[_cons] + _b[lagged_y] * lagged_y if time == `f'
}

generate double sq_err = (y - forecast)^2 if inrange(time, `first_forecast', `last_forecast')
quietly summarize sq_err, meanonly
scalar rmse = sqrt(r(mean))

display "ANSWER: rmse estimate=" %21.15g rmse " se=. n_obs=150"

foreach f in 101 150 200 250 {
    quietly summarize forecast if time == `f', meanonly
    display "ANSWER: forecast_`f' estimate=" %21.15g r(mean) " se=. n_obs=99"
}
