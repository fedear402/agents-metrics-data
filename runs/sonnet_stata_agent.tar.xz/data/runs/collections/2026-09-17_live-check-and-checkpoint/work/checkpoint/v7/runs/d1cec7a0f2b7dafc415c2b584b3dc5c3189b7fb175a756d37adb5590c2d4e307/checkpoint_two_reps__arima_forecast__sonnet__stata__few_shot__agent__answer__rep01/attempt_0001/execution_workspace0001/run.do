set linesize 255
clear

import delimited "./input.csv", varnames(1)

tsset t

* Fit ARIMA(1,1,1) with no constant
arima y, arima(1,1,1) noconstant

local nobs = e(N)

* One-step-ahead forecast for t=251
* Use predict with dynamic forecast
predict yhat, y dynamic(251)
predict yhat_se, mse dynamic(251)

* The forecast at t=251 is yhat[_N] since _N=250 but we need t=251
* Actually forecast is outside sample - use tsappend
tsappend, add(1)

predict yhat2, y dynamic(251)
predict yhat2_mse, mse dynamic(251)

* Get the forecast value at t=251 (the last observation)
local fc = yhat2[_N]
local fc_se_sq = yhat2_mse[_N]
local fc_se = sqrt(`fc_se_sq')

* 95% CI: forecast +/- 1.96 * se
local lower = `fc' - 1.96 * `fc_se'
local upper = `fc' + 1.96 * `fc_se'

display "ANSWER: forecast estimate=" %21.12f `fc' " se=" %21.12f `fc_se' " n_obs=" %12.0f `nobs'
display "ANSWER: lower_95 estimate=" %21.12f `lower' " se=. n_obs=" %12.0f `nobs'
display "ANSWER: upper_95 estimate=" %21.12f `upper' " se=. n_obs=" %12.0f `nobs'
