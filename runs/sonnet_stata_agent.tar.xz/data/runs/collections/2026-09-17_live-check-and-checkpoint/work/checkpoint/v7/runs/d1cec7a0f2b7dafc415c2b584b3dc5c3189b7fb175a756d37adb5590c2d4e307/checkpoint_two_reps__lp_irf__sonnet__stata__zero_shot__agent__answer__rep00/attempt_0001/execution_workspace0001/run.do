set linesize 255
clear all

import delimited "./input.csv", clear

* Sort by time and declare time series
sort t
tsset t

* Generate lead of y at h=4
gen y_lead4 = f4.y

* Generate lag of y (y_{t-1})
gen y_lag1 = l1.y

* Estimate local projection: y_{t+4} on shock_t and y_{t-1}, with intercept
* Use Newey-West standard errors with lag 4
newey y_lead4 shock y_lag1, lag(4)

* Store results
scalar est_shock = _b[shock]
scalar se_shock = _se[shock]
scalar nobs = e(N)

display "ANSWER: irf_h4 estimate=" %21.12f est_shock " se=" %21.12f se_shock " n_obs=" %12.0f nobs
