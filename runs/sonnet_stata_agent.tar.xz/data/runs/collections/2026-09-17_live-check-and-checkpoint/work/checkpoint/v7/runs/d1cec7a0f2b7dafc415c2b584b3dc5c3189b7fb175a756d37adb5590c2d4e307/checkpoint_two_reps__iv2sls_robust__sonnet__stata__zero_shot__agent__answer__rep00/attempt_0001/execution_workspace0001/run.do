set linesize 255
clear all

import delimited "./input.csv", varnames(1) case(preserve)

* 2SLS: y_iv on x1_iv, using z as excluded instrument, HC1 robust SEs
ivregress 2sls y_iv (x1_iv = z), robust

* Store results
local n = e(N)
scalar n_obs = e(N)

matrix b = e(b)
matrix V = e(V)

scalar est_const = b[1,2]
scalar est_x1_iv = b[1,1]

scalar se_const = sqrt(V[2,2])
scalar se_x1_iv = sqrt(V[1,1])

display "ANSWER: const estimate=" %21.12f est_const " se=" %21.12f se_const " n_obs=" %12.0f n_obs
display "ANSWER: x1_iv estimate=" %21.12f est_x1_iv " se=" %21.12f se_x1_iv " n_obs=" %12.0f n_obs
