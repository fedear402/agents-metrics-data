set linesize 255
clear all

import delimited "./input.csv", clear

* 2SLS with HC1 robust standard errors
ivregress 2sls y_iv (x1_iv = z), robust small

* Store results
scalar n_obs = e(N)
scalar const_est = _b[_cons]
scalar const_se = _se[_cons]
scalar x1_iv_est = _b[x1_iv]
scalar x1_iv_se = _se[x1_iv]

display "ANSWER: const estimate=" %21.12f const_est " se=" %21.12f const_se " n_obs=" %12.0f n_obs
display "ANSWER: x1_iv estimate=" %21.12f x1_iv_est " se=" %21.12f x1_iv_se " n_obs=" %12.0f n_obs
