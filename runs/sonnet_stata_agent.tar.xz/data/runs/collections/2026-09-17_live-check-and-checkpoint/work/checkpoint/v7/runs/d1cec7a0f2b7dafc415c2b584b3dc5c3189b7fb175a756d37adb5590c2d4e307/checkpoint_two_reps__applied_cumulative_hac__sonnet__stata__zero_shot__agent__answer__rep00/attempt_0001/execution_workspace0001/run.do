set linesize 255
clear all

import delimited "/private/tmp/prospective_task_0hw54llw/input.csv", varnames(1)

* Parse date and sort
gen date2 = date(date, "YMD")
format date2 %td
sort date2

* Create sequential time index for tsset
gen t = _n
tsset t

* Log variables
gen log_sales = ln(sales)
gen log_vix = ln(vix)

* First difference of log_vix (consecutive trading obs)
gen d_log_vix = log_vix - log_vix[_n-1]

* Generate lags 1-15
forval i = 1/15 {
    gen dv_lag`i' = d_log_vix[_n-`i']
}

* Newey-West with max lag 15 (Bartlett weights 1-j/16 for j=1..15)
* Stata's newey already applies N/(N-k) = N/(N-16) correction in e(V)
newey log_sales dv_lag1-dv_lag15, lag(15)

scalar N2 = e(N)
matrix V_nw = e(V)
matrix b2 = e(b)

* lag_1 coefficient and SE
scalar b_lag1 = b2[1,1]
scalar se_lag1 = sqrt(V_nw[1,1])

* lag_15 coefficient and SE
scalar b_lag15 = b2[1,15]
scalar se_lag15 = sqrt(V_nw[15,15])

* Cumulative response: sum of coefficients on lags 1-15
scalar cum_response = 0
forval i = 1/15 {
    scalar cum_response = cum_response + b2[1,`i']
}

* SE of cumulative response using delta method
* c = [1,1,...,1,0] (15 ones + 0 for constant)
matrix c = J(1,16,0)
forval i = 1/15 {
    matrix c[1,`i'] = 1
}

matrix V_cum = c * V_nw * c'
scalar se_cum = sqrt(V_cum[1,1])

display "ANSWER: cumulative_response estimate=" %21.12f cum_response " se=" %21.12f se_cum " n_obs=" %12.0f N2
display "ANSWER: lag_1 estimate=" %21.12f b_lag1 " se=" %21.12f se_lag1 " n_obs=" %12.0f N2
display "ANSWER: lag_15 estimate=" %21.12f b_lag15 " se=" %21.12f se_lag15 " n_obs=" %12.0f N2

