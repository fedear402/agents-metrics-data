set linesize 255
clear

import delimited "./input.csv", varnames(1)

* Sort by time and set time series
sort t
tsset t

* Create y_{t+4} (forward value)
gen y_lead4 = f4.y

* Create y_{t-1} (lag of y)
gen y_lag1 = l1.y

* Run local projection: y_{t+4} on shock_t and y_{t-1}, with intercept
* Using Newey-West SE with lag 4
newey y_lead4 shock y_lag1, lag(4)

local est = _b[shock]
local se  = _se[shock]
local n   = e(N)

display "ANSWER: irf_h4 estimate=" %21.12f `est' " se=" %21.12f `se' " n_obs=" %12.0f `n'
