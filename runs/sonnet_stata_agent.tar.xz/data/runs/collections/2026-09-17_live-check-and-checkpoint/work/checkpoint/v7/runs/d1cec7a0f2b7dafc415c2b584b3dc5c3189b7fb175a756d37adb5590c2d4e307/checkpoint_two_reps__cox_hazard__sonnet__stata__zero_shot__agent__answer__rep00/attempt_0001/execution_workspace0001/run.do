set linesize 255
clear all

import delimited using "./input.csv", varnames(1)

stset t_obs, failure(event)

stcox treat x

* Extract estimates and SEs
matrix b = e(b)
matrix V = e(V)

scalar est_treat = b[1,1]
scalar est_x     = b[1,2]
scalar se_treat  = sqrt(V[1,1])
scalar se_x      = sqrt(V[2,2])
scalar n_obs     = e(N)

display "ANSWER: treat estimate=" %21.12f est_treat " se=" %21.12f se_treat " n_obs=" %12.0f n_obs
display "ANSWER: x estimate=" %21.12f est_x " se=" %21.12f se_x " n_obs=" %12.0f n_obs
