import pandas as pd
import numpy as np

df = pd.read_csv("/private/tmp/prospective_task_0hw54llw/input.csv")
df['date'] = pd.to_datetime(df['date'])
df = df.sort_values('date').reset_index(drop=True)

df['log_sales'] = np.log(df['sales'])
df['log_vix'] = np.log(df['vix'])
df['d_log_vix'] = df['log_vix'].diff()

for i in range(1, 16):
    df[f'dv_lag{i}'] = df['d_log_vix'].shift(i)

df_reg = df.dropna(subset=[f'dv_lag{i}' for i in range(1,16)]).copy()
N = len(df_reg)
print(f"N = {N}")

y = df_reg['log_sales'].values
X_cols = [f'dv_lag{i}' for i in range(1,16)]
X = np.column_stack([df_reg[c].values for c in X_cols] + [np.ones(N)])

# OLS
b = np.linalg.lstsq(X, y, rcond=None)[0]
print("OLS coefficients (lag1..lag15, const):", b)

resid = y - X @ b

# Newey-West with max lag 15, Bartlett weights 1-j/16
k = X.shape[1]
XtX_inv = np.linalg.inv(X.T @ X)

# Compute S (the meat of sandwich)
S = np.zeros((k, k))
# j=0 term
for t in range(N):
    xe = X[t] * resid[t]
    S += np.outer(xe, xe)

# j=1..15 terms
for j in range(1, 16):
    w = 1 - j/16  # Bartlett weight
    gamma = np.zeros((k, k))
    for t in range(j, N):
        gamma += np.outer(X[t]*resid[t], X[t-j]*resid[t-j])
    S += w * (gamma + gamma.T)

# Variance: (X'X)^-1 * S * (X'X)^-1
# Stata's newey scales by 1/N internally
# V_newey = (1/N) * (X'X/N)^-1 * (S/N) * (X'X/N)^-1 = N * (X'X)^-1 * S * (X'X)^-1 / N
# Actually: newey V = (X'X)^{-1} * (S/N) * (X'X)^{-1} where S here is sum not avg
# Let me verify: Stata's newey sandwich = (X'X)^{-1} * Omega_hat * (X'X)^{-1}
# where Omega_hat = (1/N) * S (with S as sum above)
# So V = (X'X)^{-1} * (S/N) * (X'X)^{-1}

V_nw = XtX_inv @ (S / N) @ XtX_inv

# Apply N/(N-16) correction
scale = N / (N - 16)
V_scaled = V_nw * scale

cum_resp = b[:15].sum()
c = np.zeros(k)
c[:15] = 1
se_cum = np.sqrt(c @ V_scaled @ c)

print(f"\ncumulative_response: {cum_resp:.12f}")
print(f"se_cum: {se_cum:.12f}")
print(f"lag_1: {b[0]:.12f}, se: {np.sqrt(V_scaled[0,0]):.12f}")
print(f"lag_15: {b[14]:.12f}, se: {np.sqrt(V_scaled[14,14]):.12f}")
