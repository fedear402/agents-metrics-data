set linesize 255
clear all

import delimited "./input.csv", clear

* ─── Step 1: Normalize regional weights (one obs per region) ───────────────────
* Keep one obs per region for region-level data
bysort region_id (industry_id): gen first_in_region = (_n == 1)

* Sum of region_weight across regions (one per region)
egen total_weight = total(region_weight * first_in_region)
gen e_r = region_weight / total_weight

* Verify: sum of e_r across regions = 1
egen check_sum = total(e_r * first_in_region)
di "Sum of e_r = " check_sum

* ─── Step 2: Construct shift-share instrument z_r = sum_n share_rn * shock_n ──
gen share_shock = share * shock
bysort region_id: egen z_r = total(share_shock)

* ─── Step 3: Regional-level dataset ────────────────────────────────────────────
* Keep one obs per region
preserve
keep if first_in_region == 1
keep region_id x y z_r e_r

* Verify: 240 regions
count
di "Number of regions = " r(N)

* ─── Step 4: Demean by e_r-weighted regional mean ──────────────────────────────
* Weighted means
egen sum_e = total(e_r)  /* should be 1 */
gen ey = e_r * y
gen ex = e_r * x
gen ez = e_r * z_r
egen mean_y = total(ey)
egen mean_x = total(ex)
egen mean_z = total(ez)

gen y0 = y - mean_y
gen x0 = x - mean_x
gen z0 = z_r - mean_z

* ─── Step 5: Regional 2SLS ──────────────────────────────────────────────────────
* This is the primary estimator; we use it to verify the shock-level result
ivregress 2sls y (x = z_r) [aw=e_r], nocons
* Actually we want the slope with intercept:
ivregress 2sls y (x = z_r) [aw=e_r]
scalar beta_2sls = _b[x]
di "Regional 2SLS slope = " beta_2sls

* First stage
reg x z_r [aw=e_r]
scalar beta_fs = _b[z_r]
di "Regional first-stage slope = " beta_fs

restore

* ─── Step 6: Shock-level aggregation (Borusyak-Hull-Jaravel) ────────────────────
* Compute s_n = sum_r e_r * share_rn
gen e_share = e_r * share
bysort industry_id: egen s_n = total(e_share)

* Compute industry-level aggregates of demeaned residuals
* First need demeaned variables at region level
* Recompute e_r-weighted means from the full dataset (same value repeated within region)
gen ey2 = e_r * y * first_in_region
gen ex2 = e_r * x * first_in_region
gen ez2 = e_r * z_r * first_in_region
egen mean_y2 = total(ey2)
egen mean_x2 = total(ex2)
egen mean_z2 = total(ez2)

gen y0_r = y - mean_y2
gen x0_r = x - mean_x2
gen z0_r = z_r - mean_z2

* Aggregate to industry level: vbar_n = sum_r e_r * share_rn * v0_r / s_n
gen e_share_y0 = e_r * share * y0_r
gen e_share_x0 = e_r * share * x0_r
gen e_share_z0 = e_r * share * z0_r

bysort industry_id: egen num_y = total(e_share_y0)
bysort industry_id: egen num_x = total(e_share_x0)
bysort industry_id: egen num_z = total(e_share_z0)

gen ybar_n = num_y / s_n
gen xbar_n = num_x / s_n
gen zbar_n = num_z / s_n

* ─── Step 7: Industry-level dataset ─────────────────────────────────────────────
* Keep one obs per industry
bysort industry_id (region_id): gen first_in_industry = (_n == 1)
preserve
keep if first_in_industry == 1
keep industry_id shock s_n ybar_n xbar_n zbar_n
count
scalar N_ind = r(N)
di "Number of industries = " N_ind

* ─── Step 8: Shock-level IV for 2SLS slope ──────────────────────────────────────
* Regress ybar_n on intercept + xbar_n, instrumenting xbar_n with shock_n, weights s_n
* HC1 with variance multiplier N/(N-2) where N = number of industries

* Manual 2SLS using the Frisch-Waugh / shock-level approach:
* Since we instrumented with shock, let's use ivregress
ivregress 2sls ybar_n (xbar_n = shock) [aw=s_n]
scalar beta_effect = _b[xbar_n]
di "Shock-level 2SLS slope (effect) = " beta_effect

* Get HC1 SE manually
* First compute structural IV residuals
predict double yhat_iv, xb
gen double resid_iv = ybar_n - yhat_iv

* For HC1 SE of beta in IV regression:
* beta = (Z'WX)^{-1} Z'Wy where Z is instrument, W is weight matrix
* Var(beta) = (Z'WX)^{-1} (Z'W diag(e^2) W Z) (X'WZ)^{-1} * n/(n-k) HC1 adjustment
* With k=2 (intercept + slope), HC1 multiplier = N/(N-2)

* Number of obs
scalar N = N_ind
di "N industries = " N

* Weighted sums needed
* Let's demean first (within the shock-level regression)
* We need (Z'WX) = sum_n s_n * shock_n * xbar_n (after demeaning by intercept)
* The intercept means we need to partial out the weighted mean

* Compute weighted means for demeaning in shock-level regression
gen sw = s_n  /* analytic weights */
egen sum_sw = total(sw)
gen sw_shock = sw * shock
gen sw_xbar = sw * xbar_n
gen sw_ybar = sw * ybar_n
egen sum_sw_shock = total(sw_shock)
egen sum_sw_xbar = total(sw_xbar)
gen shock_dm = shock - sum_sw_shock/sum_sw
gen xbar_dm = xbar_n - sum_sw_xbar/sum_sw

* Check: beta_effect = sum(sw * shock_dm * ybar_n) / sum(sw * shock_dm * xbar_dm)
gen sw_sd_ybar = sw * shock_dm * ybar_n
gen sw_sd_xbar = sw * shock_dm * xbar_dm
egen num_beta = total(sw_sd_ybar)
egen den_beta = total(sw_sd_xbar)
scalar beta_check = num_beta / den_beta
di "Beta check = " beta_check " (should match " beta_effect ")"

* IV residuals: e_n = ybar_n - beta0 - beta_effect * xbar_n
scalar beta0_effect = _b[_cons]
replace resid_iv = ybar_n - beta0_effect - beta_effect * xbar_n

* HC1 sandwich variance:
* V = (sum_n s_n * shock_dm_n * xbar_dm_n)^{-2} * sum_n (s_n * shock_dm_n * e_n)^2 * N/(N-2)
gen score_n = sw * shock_dm * resid_iv
gen score_sq = score_n^2
egen sum_score_sq = total(score_sq)
scalar denom_sq = den_beta^2
scalar var_beta = (sum_score_sq / denom_sq) * (N / (N - 2))
scalar se_effect = sqrt(var_beta)
di "SE(effect) HC1 = " se_effect

* ─── Step 9: Shock-level IV for first-stage slope ──────────────────────────────
* Regress xbar_n on intercept + zbar_n, instrumenting zbar_n with shock_n, weights s_n
ivregress 2sls xbar_n (zbar_n = shock) [aw=s_n]
scalar beta_fs2 = _b[zbar_n]
di "Shock-level 2SLS slope (first-stage) = " beta_fs2

scalar beta0_fs2 = _b[_cons]
gen double resid_fs = xbar_n - beta0_fs2 - beta_fs2 * zbar_n

* Need demeaned zbar_n
gen sw_zbar = sw * zbar_n
egen sum_sw_zbar = total(sw_zbar)
gen zbar_dm = zbar_n - sum_sw_zbar/sum_sw

gen sw_sd_zbar = sw * shock_dm * zbar_dm
egen den_fs = total(sw_sd_zbar)

gen score_fs = sw * shock_dm * resid_fs
gen score_fs_sq = score_fs^2
egen sum_score_fs_sq = total(score_fs_sq)
scalar var_fs = (sum_score_fs_sq / den_fs^2) * (N / (N - 2))
scalar se_fs = sqrt(var_fs)
di "SE(first_stage) HC1 = " se_fs

* ─── Step 10: Effective shocks ─────────────────────────────────────────────────
gen s_n_sq = s_n^2
egen sum_s_n_sq = total(s_n_sq)
scalar eff_shocks = 1 / sum_s_n_sq
di "Effective shocks = " eff_shocks

restore

* ─── Step 11: Report results ────────────────────────────────────────────────────
di "ANSWER: effect estimate=" %21.12f beta_effect " se=" %21.12f se_effect " n_obs=" %12.0f N_ind
di "ANSWER: first_stage estimate=" %21.12f beta_fs2 " se=" %21.12f se_fs " n_obs=" %12.0f N_ind
di "ANSWER: effective_shocks estimate=" %21.12f eff_shocks " se=" %21.12f . " n_obs=" %12.0f N_ind

