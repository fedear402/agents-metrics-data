set linesize 255
clear all

import delimited "./input.csv", varnames(1)

* Add a row for t=251 (out-of-sample forecast period)
local N = _N
set obs `=_N + 1'
replace t = 251 in `=_N'

tsset t

* Fit ARIMA(1,1,1) - no constant, no drift
arima y, arima(1,1,1) noconstant

scalar n_obs = e(N)

* One-step-ahead forecast (y option gives levels, dynamic from t=251 means forecast starts there)
predict yhat, y dynamic(251)
predict yhat_mse, mse dynamic(251)

* The forecast at t=251
summarize yhat if t == 251
scalar fc = r(mean)

summarize yhat_mse if t == 251
scalar fc_mse = r(mean)
scalar fc_se = sqrt(fc_mse)

* 95% prediction interval
scalar lower = fc - 1.96 * fc_se
scalar upper = fc + 1.96 * fc_se

display "ANSWER: forecast estimate=" %21.12f fc " se=" %21.12f fc_se " n_obs=" %12.0f n_obs
display "ANSWER: lower_95 estimate=" %21.12f lower " se=. n_obs=" %12.0f n_obs
display "ANSWER: upper_95 estimate=" %21.12f upper " se=. n_obs=" %12.0f n_obs
