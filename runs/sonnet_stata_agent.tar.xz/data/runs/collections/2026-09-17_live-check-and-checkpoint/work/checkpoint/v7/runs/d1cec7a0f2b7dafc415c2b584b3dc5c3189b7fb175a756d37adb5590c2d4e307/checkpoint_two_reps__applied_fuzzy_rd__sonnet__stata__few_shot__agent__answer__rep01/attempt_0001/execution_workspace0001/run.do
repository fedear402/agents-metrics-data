version 19.0
clear all
set more off
set linesize 255

import delimited "./input.csv", clear

* Keep observations within bandwidth (strict inequality)
keep if abs(score) < 1

* Triangular kernel weights
gen w = 1 - abs(score)

* Right-side indicator
gen above = (score >= 0)

* Count in-bandwidth observations
count
local n_obs = r(N)

mata:
    // Load variables
    Y     = st_data(., ("earnings", "participated"))
    score = st_data(., "score")
    above = st_data(., "above")
    w     = st_data(., "w")
    n     = rows(Y)

    // Design: intercept, score, above, score*above
    X = (J(n,1,1), score, above, score :* above)

    // Weighted least squares
    bread        = invsym(X' * (w :* X))
    coefficients = bread * (X' * (w :* Y))
    residuals    = Y - X * coefficients

    // Contrast selects the 'above' coefficient = right-limit minus left-limit
    contrast = (0 \ 0 \ 1 \ 0)
    jumps    = contrast' * coefficients   // 1x2: [reduced_form, first_stage]

    // HC0 influence functions
    loading   = w :* (X * bread * contrast)
    influence = loading :* residuals       // n x 2

    // Joint sandwich covariance of the two discontinuity estimates
    joint = influence' * influence         // 2x2

    // Delta method gradient for ratio = jumps[1]/jumps[2]
    rf = jumps[1]
    fs = jumps[2]
    gradient = (1/fs \ -rf/fs^2)
    ratio_se = sqrt(gradient' * joint * gradient)

    st_numscalar("rf_est",  rf)
    st_numscalar("rf_se",   sqrt(joint[1,1]))
    st_numscalar("fs_est",  fs)
    st_numscalar("fs_se",   sqrt(joint[2,2]))
    st_numscalar("te_est",  rf/fs)
    st_numscalar("te_se",   ratio_se)
end

display "ANSWER: reduced_form estimate=" %21.12f rf_est " se=" %21.12f rf_se " n_obs=" %12.0f `n_obs'
display "ANSWER: first_stage estimate=" %21.12f fs_est " se=" %21.12f fs_se " n_obs=" %12.0f `n_obs'
display "ANSWER: treatment_effect estimate=" %21.12f te_est " se=" %21.12f te_se " n_obs=" %12.0f `n_obs'
