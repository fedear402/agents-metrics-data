clear all
set more off
set linesize 255
set type double

import delimited "./input.csv", clear
scalar n = r(N)
scalar q = 2
scalar df = n - 4
scalar critical = invFtail(q, df, 0.05)

* Direct F-test verification at specific beta values
foreach b in 0 1 2.112021053064 3 5.137228679323 6 {
    quietly {
        gen double ystar = y - `b'*endog
        regress ystar x
        scalar SSR_R = e(rss)
        regress ystar x z1 z2
        scalar SSR_U = e(rss)
        scalar F_val = ((SSR_R - SSR_U)/q) / (SSR_U/df)
        drop ystar
    }
    display "beta=" `b' " F=" F_val " critical=" critical " accepted=" (F_val <= critical)
}
