set linesize 255
clear all

import delimited "./input.csv", varnames(1)

* Fit Tobit model with lower censoring at 0
tobit y x z, ll(0)

* Extract results
scalar n_obs = e(N)
scalar b_const = _b[_cons]
scalar b_x = _b[x]
scalar b_z = _b[z]

scalar se_const = _se[_cons]
scalar se_x = _se[x]
scalar se_z = _se[z]

* sigma is sqrt of variance stored in /:var(e.y)
matrix b = e(b)
scalar b_var = b[1,4]
scalar b_sigma = sqrt(b_var)

display "ANSWER: const estimate=" %21.12f b_const " se=" %21.12f se_const " n_obs=" %12.0f n_obs
display "ANSWER: x estimate=" %21.12f b_x " se=" %21.12f se_x " n_obs=" %12.0f n_obs
display "ANSWER: z estimate=" %21.12f b_z " se=" %21.12f se_z " n_obs=" %12.0f n_obs
display "ANSWER: sigma estimate=" %21.12f b_sigma " se=." " n_obs=" %12.0f n_obs
