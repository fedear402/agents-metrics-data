clear all
set more off
set linesize 255
set type double

import delimited "./input.csv", clear

mlogit y x z, baseoutcome(0) tolerance(1e-10) nrtolerance(1e-10)

scalar x_cat1_est = _b[1:x]
scalar x_cat1_se  = _se[1:x]
scalar z_cat1_est = _b[1:z]
scalar z_cat1_se  = _se[1:z]
scalar x_cat2_est = _b[2:x]
scalar x_cat2_se  = _se[2:x]
scalar z_cat2_est = _b[2:z]
scalar z_cat2_se  = _se[2:z]
scalar n_obs = e(N)

* prob_cat2_zero: P(y=2 | x=0, z=0)
* = exp(cons2) / (1 + exp(cons1) + exp(cons2))
scalar cons1 = _b[1:_cons]
scalar cons2 = _b[2:_cons]
scalar prob2_zero = exp(cons2) / (1 + exp(cons1) + exp(cons2))

display "ANSWER: x_cat1 estimate=" %21.12f x_cat1_est " se=" %21.12f x_cat1_se " n_obs=" %12.0f n_obs
display "ANSWER: z_cat1 estimate=" %21.12f z_cat1_est " se=" %21.12f z_cat1_se " n_obs=" %12.0f n_obs
display "ANSWER: x_cat2 estimate=" %21.12f x_cat2_est " se=" %21.12f x_cat2_se " n_obs=" %12.0f n_obs
display "ANSWER: z_cat2 estimate=" %21.12f z_cat2_est " se=" %21.12f z_cat2_se " n_obs=" %12.0f n_obs
display "ANSWER: prob_cat2_zero estimate=" %21.12f prob2_zero " se=" . " n_obs=" %12.0f n_obs
