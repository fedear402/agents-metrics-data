import pandas as pd
import numpy as np

df = pd.read_csv("/private/tmp/prospective_task_0hw54llw/input.csv")
df['date'] = pd.to_datetime(df['date'])
df = df.sort_values('date').reset_index(drop=True)

df['log_sales'] = np.log(df['sales'])
df['log_vix'] = np.log(df['vix'])
df['d_log_vix'] = df['log_vix'].diff()

for i in range(1, 16):
    df[f'dv_lag{i}'] = df['d_log_vix'].shift(i)

df_reg = df.dropna(subset=[f'dv_lag{i}' for i in range(1,16)]).copy()
N = len(df_reg)
print(f"N = {N}")

y = df_reg['log_sales'].values
X_cols = [f'dv_lag{i}' for i in range(1,16)]
X = np.column_stack([df_reg[c].values for c in X_cols] + [np.ones(N)])

# OLS
b = np.linalg.lstsq(X, y, rcond=None)[0]
resid = y - X @ b

k = X.shape[1]
XtX_inv = np.linalg.inv(X.T @ X)

# Newey-West with max lag 15, Bartlett weights 1-j/16
# Stata uses: V = (X'X)^{-1} * S * (X'X)^{-1} (sum form, not 1/N scaled)
S = np.zeros((k, k))
for t in range(N):
    xe = X[t] * resid[t]
    S += np.outer(xe, xe)

for j in range(1, 16):
    w = 1 - j/16  # Bartlett weight
    gamma = np.zeros((k, k))
    for t in range(j, N):
        gamma += np.outer(X[t]*resid[t], X[t-j]*resid[t-j])
    S += w * (gamma + gamma.T)

# Try with full S (no 1/N) 
V_nw = XtX_inv @ S @ XtX_inv
print(f"se_lag1 with full S: {np.sqrt(V_nw[0,0]):.6f}")  # Should match Stata's ~0.034 before correction

# Apply N/(N-16) correction
scale = N / (N - 16)
V_scaled = V_nw * scale

cum_resp = b[:15].sum()
c = np.zeros(k)
c[:15] = 1
se_cum = np.sqrt(c @ V_scaled @ c)

print(f"\ncumulative_response: {cum_resp:.12f}")
print(f"se_cum (with full S scaling): {se_cum:.12f}")
print(f"lag_1: {b[0]:.12f}, se: {np.sqrt(V_scaled[0,0]):.12f}")
print(f"lag_15: {b[14]:.12f}, se: {np.sqrt(V_scaled[14,14]):.12f}")
