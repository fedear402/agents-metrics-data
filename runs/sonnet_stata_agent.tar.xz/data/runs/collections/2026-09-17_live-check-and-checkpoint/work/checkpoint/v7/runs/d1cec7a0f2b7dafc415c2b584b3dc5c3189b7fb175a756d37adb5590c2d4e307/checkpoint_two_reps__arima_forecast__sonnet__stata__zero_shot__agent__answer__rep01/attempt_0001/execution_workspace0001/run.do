set linesize 255
clear all

import delimited "./input.csv", varnames(1)

tsset t

* Fit ARIMA(1,1,1) with no constant
arima y, arima(1,1,1) noconstant

* One-step-ahead forecast for t=251
* The last observation is t=250, so we need to extend the time series
* and forecast one step ahead

* Store number of obs used in estimation
scalar n_obs = e(N)

* Forecast using predict after arima
* We need to add t=251
local newt = 251
set obs `= _N + 1'
replace t = `newt' in `= _N'
tsset t

* Dynamic forecast
predict yhat, y dynamic(251)
predict yhat_se, mse dynamic(251)

* The forecast value at t=251
scalar fc = yhat[251]
scalar fc_se = sqrt(yhat_se[251])

* 95% prediction interval
scalar lower95 = fc - 1.96 * fc_se
scalar upper95 = fc + 1.96 * fc_se

display "ANSWER: forecast estimate=" %21.12f fc " se=" %21.12f fc_se " n_obs=" %12.0f n_obs
display "ANSWER: lower_95 estimate=" %21.12f lower95 " se=" %21.12f fc_se " n_obs=" %12.0f n_obs
display "ANSWER: upper_95 estimate=" %21.12f upper95 " se=" %21.12f fc_se " n_obs=" %12.0f n_obs
