import pandas as pd
import numpy as np

df = pd.read_csv("/private/tmp/prospective_task_0hw54llw/input.csv")
df['date'] = pd.to_datetime(df['date'])
df = df.sort_values('date').reset_index(drop=True)

df['log_sales'] = np.log(df['sales'])
df['log_vix'] = np.log(df['vix'])
df['d_log_vix'] = df['log_vix'].diff()

for i in range(1, 16):
    df[f'dv_lag{i}'] = df['d_log_vix'].shift(i)

df_reg = df.dropna(subset=[f'dv_lag{i}' for i in range(1,16)]).copy()
N = len(df_reg)
print(f"N = {N}")

y = df_reg['log_sales'].values
X_cols = [f'dv_lag{i}' for i in range(1,16)]
X = np.column_stack([df_reg[c].values for c in X_cols] + [np.ones(N)])

b = np.linalg.lstsq(X, y, rcond=None)[0]
resid = y - X @ b
k = X.shape[1]

# Check: compare White HC (no lags) vs robust reg
XtX_inv = np.linalg.inv(X.T @ X)

# HC0: V = (X'X)^-1 * (sum e^2 x x') * (X'X)^-1
meat0 = np.zeros((k, k))
for t in range(N):
    meat0 += resid[t]**2 * np.outer(X[t], X[t])

V_hc0 = XtX_inv @ meat0 @ XtX_inv
print(f"HC0 se_lag1: {np.sqrt(V_hc0[0,0]):.8f}")

# HC1: multiply by N/(N-k)
V_hc1 = V_hc0 * N / (N-k)
print(f"HC1 se_lag1: {np.sqrt(V_hc1[0,0]):.8f}")

# Now check NW with lag=0 (should = HC0)
S_nw_0 = np.zeros((k, k))
for t in range(N):
    xe = X[t] * resid[t]
    S_nw_0 += np.outer(xe, xe)

V_nw0 = XtX_inv @ S_nw_0 @ XtX_inv
print(f"NW lag=0 (same as HC0): {np.sqrt(V_nw0[0,0]):.8f}")

# Full NW with lag=15
S_nw = np.zeros((k, k))
for t in range(N):
    xe = X[t] * resid[t]
    S_nw += np.outer(xe, xe)

for j in range(1, 16):
    w = 1 - j/16
    gamma = np.zeros((k, k))
    for t in range(j, N):
        gamma += np.outer(X[t]*resid[t], X[t-j]*resid[t-j])
    S_nw += w * (gamma + gamma.T)

V_nw = XtX_inv @ S_nw @ XtX_inv
print(f"\nNW lag=15 se_lag1 (no correction): {np.sqrt(V_nw[0,0]):.8f}")
print(f"NW lag=15 se_lag1 (with N/(N-16)): {np.sqrt(V_nw[0,0] * N/(N-16)):.8f}")

# Check what Stata's newey gives = 0.033956 (before task's N/(N-16) correction)
# So Stata's raw = 0.033956, and our NW = 0.033568
# These should be the same without any df correction

# Try using vectorized computation
X_e = X * resid[:, np.newaxis]
S_v = X_e.T @ X_e  # j=0

for j in range(1, 16):
    w = 1 - j/16
    cross = X_e[j:].T @ X_e[:-j]
    S_v += w * (cross + cross.T)

V_nw_v = XtX_inv @ S_v @ XtX_inv
print(f"\nVectorized NW: {np.sqrt(V_nw_v[0,0]):.8f}")
print(f"Vectorized NW cum: {np.sqrt((np.ones(15)@V_nw_v[:15,:15]@np.ones(15))):.8f}")

