import pandas as pd
import numpy as np

df = pd.read_csv("./input.csv")
df['day'] = pd.to_datetime(df['date'])
df = df.sort_values('day').reset_index(drop=True)

df['log_sales'] = np.log(df['sales'])
df['log_vix'] = np.log(df['vix'])
df['vix_change'] = df['log_vix'].diff()

for k in range(1, 16):
    df[f'change_lag{k}'] = df['vix_change'].shift(k)

lag_cols = [f'change_lag{k}' for k in range(1, 16)]
df_clean = df.dropna(subset=['log_sales'] + lag_cols).copy()

N = len(df_clean)
print(f"N = {N}")

y = df_clean['log_sales'].values
X = np.column_stack([np.ones(N)] + [df_clean[c].values for c in lag_cols])

# OLS
coeffs, _, _, _ = np.linalg.lstsq(X, y, rcond=None)
residuals = y - X @ coeffs

p = X.shape[1]  # 16

# Newey-West HAC with 15 lags, Bartlett weights, correction N/(N-16)
scores = X * residuals[:, None]
hac_lags = 15
meat = scores.T @ scores
for j in range(1, hac_lags + 1):
    w = 1 - j / (hac_lags + 1)
    lag_prod = scores[j:].T @ scores[:N-j]
    meat += w * (lag_prod + lag_prod.T)

bread = np.linalg.inv(X.T @ X)
cov = (N / (N - p)) * bread @ meat @ bread

contrast = np.ones(p)
contrast[0] = 0

cumulative = contrast @ coeffs
cumulative_se = np.sqrt(contrast @ cov @ contrast)

lag1_est = coeffs[1]
lag1_se = np.sqrt(cov[1, 1])
lag15_est = coeffs[15]
lag15_se = np.sqrt(cov[15, 15])

print(f"ANSWER: cumulative_response estimate={cumulative:.12f} se={cumulative_se:.12f} n_obs={N}")
print(f"ANSWER: lag_1 estimate={lag1_est:.12f} se={lag1_se:.12f} n_obs={N}")
print(f"ANSWER: lag_15 estimate={lag15_est:.12f} se={lag15_se:.12f} n_obs={N}")
