set linesize 255
clear all
import delimited "/private/tmp/prospective_task_0hw54llw/input.csv", varnames(1)
gen date2 = date(date, "YMD")
format date2 %td
sort date2
gen t = _n
tsset t
gen log_sales = ln(sales)
gen log_vix = ln(vix)
gen d_log_vix = log_vix - log_vix[_n-1]
forval i = 1/15 {
    gen dv_lag`i' = d_log_vix[_n-`i']
}
newey log_sales dv_lag1-dv_lag15, lag(15)
scalar N2 = e(N)
matrix V_nw = e(V)
* Show raw NW SE for lag1 (before correction)
display "Raw NW se_lag1 = " %21.12f sqrt(V_nw[1,1])
display "N = " N2
display "scale = " N2/(N2-16)
display "Corrected se_lag1 = " %21.12f sqrt(V_nw[1,1] * N2/(N2-16))
