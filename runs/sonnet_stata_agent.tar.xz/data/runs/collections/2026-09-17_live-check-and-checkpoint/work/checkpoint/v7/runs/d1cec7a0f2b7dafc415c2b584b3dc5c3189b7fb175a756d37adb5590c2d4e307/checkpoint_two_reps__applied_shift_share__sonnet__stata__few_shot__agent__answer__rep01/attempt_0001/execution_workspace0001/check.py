import numpy as np
import pandas as pd

df = pd.read_csv('input.csv')

# Normalize regional weights
region_weights = df.drop_duplicates('region_id')[['region_id','region_weight']].copy()
region_weights['e_r'] = region_weights['region_weight'] / region_weights['region_weight'].sum()
df = df.merge(region_weights[['region_id','e_r']], on='region_id')

# Construct z_r
df['share_shock'] = df['share'] * df['shock']
z_r = df.groupby('region_id')['share_shock'].sum().reset_index(name='z_r')
df = df.merge(z_r, on='region_id')

# Collapse to region level
reg = df.drop_duplicates('region_id')[['region_id','e_r','x','y','z_r']].copy()

# Demean
for v in ['y','x','z_r']:
    mean_v = (reg['e_r'] * reg[v]).sum()
    reg[v+'0'] = reg[v] - mean_v

print("Weighted means after demeaning:")
for v in ['y','x','z_r']:
    print(f"  {v}0: {(reg['e_r'] * reg[v+'0']).sum():.2e}")

# Regional 2SLS for verification
z0 = reg['z_r0'].values
x0 = reg['x0'].values
y0 = reg['y0'].values
e = reg['e_r'].values

# Regional 2SLS slope = Cov(z,y,w) / Cov(z,x,w)
beta_effect_regional = np.sum(e * z0 * y0) / np.sum(e * z0 * x0)
beta_fs_regional = np.sum(e * z0 * x0) / np.sum(e * z0**2)
print(f"\nRegional 2SLS effect slope: {beta_effect_regional:.15g}")
print(f"Regional first-stage slope: {beta_fs_regional:.15g}")

# Shock-level aggregation
# s_n = sum_r e_r * share_rn
full = df.merge(reg[['region_id','y0','x0','z_r0']], on='region_id')
full['ew_share'] = full['e_r'] * full['share']
s_n = full.groupby('industry_id')['ew_share'].sum().reset_index(name='s_n')

for v in ['y0','x0','z_r0']:
    full['ew_'+v] = full['e_r'] * full['share'] * full[v]

agg = full.groupby('industry_id').agg(
    s_n=('ew_share','sum'),
    sum_ew_y=('ew_y0','sum'),
    sum_ew_x=('ew_x0','sum'),
    sum_ew_z=('ew_z_r0','sum'),
    shock=('shock','first')
).reset_index()

agg['ybar'] = agg['sum_ew_y'] / agg['s_n']
agg['xbar'] = agg['sum_ew_x'] / agg['s_n']
agg['zbar'] = agg['sum_ew_z'] / agg['s_n']

N = len(agg)
s = agg['s_n'].values
ybar = agg['ybar'].values
xbar = agg['xbar'].values
zbar = agg['zbar'].values
shock = agg['shock'].values

# IV in matrix form
def iv_hc1(dep, endog, instr, weights, N):
    ones = np.ones(N)
    X = np.column_stack([ones, endog])
    Z = np.column_stack([ones, instr])
    W = np.diag(weights)
    
    cross = Z.T @ W @ X
    inv = np.linalg.inv(cross)
    beta = inv @ Z.T @ (weights * dep)
    resid = dep - X @ beta
    scores = Z * (weights * resid)[:, np.newaxis]
    cov = N/(N-2) * inv @ (scores.T @ scores) @ inv.T
    return beta[1], np.sqrt(cov[1,1])

effect_est, effect_se = iv_hc1(ybar, xbar, shock, s, N)
fs_est, fs_se = iv_hc1(xbar, zbar, shock, s, N)
eff_shocks = 1 / np.sum(s**2)

print(f"\nShock-level IV results:")
print(f"Effect: {effect_est:.15g} se={effect_se:.15g}")
print(f"First-stage: {fs_est:.15g} se={fs_se:.15g}")
print(f"Effective shocks: {eff_shocks:.15g}")
print(f"N industries: {N}")

# Verify shock-level = regional
assert abs(effect_est - beta_effect_regional) < 1e-10, f"Effect mismatch: {effect_est} vs {beta_effect_regional}"
assert abs(fs_est - beta_fs_regional) < 1e-10, f"FS mismatch: {fs_est} vs {beta_fs_regional}"
print("\nVerification passed: shock-level slopes match regional slopes")
