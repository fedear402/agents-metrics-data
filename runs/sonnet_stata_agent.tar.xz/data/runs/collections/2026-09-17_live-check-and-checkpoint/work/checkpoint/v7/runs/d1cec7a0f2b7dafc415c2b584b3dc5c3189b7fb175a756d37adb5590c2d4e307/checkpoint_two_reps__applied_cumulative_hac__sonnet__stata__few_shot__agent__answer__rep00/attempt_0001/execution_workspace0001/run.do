version 17
clear all
set more off
set linesize 255

import delimited "./input.csv", clear

* Parse date and sort
generate double day = date(date, "YMD")
sort day
generate int observation = _n
tsset observation

* Construct log variables
generate double log_sales = log(sales)
generate double log_vix = log(vix)
generate double vix_change = D.log_vix

* Generate 15 lags of vix_change
forvalues k = 1/15 {
    generate double change_lag`k' = L`k'.vix_change
}

* Keep only complete observations
keep if !missing(log_sales, change_lag1, change_lag2, change_lag3, change_lag4, change_lag5, ///
    change_lag6, change_lag7, change_lag8, change_lag9, change_lag10, ///
    change_lag11, change_lag12, change_lag13, change_lag14, change_lag15)

mata:
    y = st_data(., "log_sales")
    X = J(rows(y), 16, .)
    X[.,1] = J(rows(y), 1, 1)
    for (k = 1; k <= 15; k++) {
        X[.,k+1] = st_data(., "change_lag" + strofreal(k))
    }
    
    coefficients = qrsolve(X, y)
    residuals = y - X * coefficients
    
    N = rows(X)
    p = cols(X)
    
    scores = X :* residuals
    hac_lags = 15
    meat = scores' * scores
    for (j = 1; j <= hac_lags; j++) {
        lag_product = scores[|j+1,1 \ N,p|]' * scores[|1,1 \ N-j,p|]
        meat = meat + (1 - j/(hac_lags+1)) * (lag_product + lag_product')
    }
    
    bread = invsym(X'*X)
    covariance = (N/(N-p)) * bread * meat * bread
    
    contrast = J(p, 1, 1)
    contrast[1] = 0
    
    cumulative = contrast' * coefficients
    cumulative_se = sqrt(contrast' * covariance * contrast)
    
    lag1_est = coefficients[2]
    lag1_se  = sqrt(covariance[2,2])
    lag15_est = coefficients[16]
    lag15_se  = sqrt(covariance[16,16])
    
    printf("ANSWER: cumulative_response estimate=%21.12f se=%21.12f n_obs=%12.0f\n", cumulative, cumulative_se, N)
    printf("ANSWER: lag_1 estimate=%21.12f se=%21.12f n_obs=%12.0f\n", lag1_est, lag1_se, N)
    printf("ANSWER: lag_15 estimate=%21.12f se=%21.12f n_obs=%12.0f\n", lag15_est, lag15_se, N)
end
