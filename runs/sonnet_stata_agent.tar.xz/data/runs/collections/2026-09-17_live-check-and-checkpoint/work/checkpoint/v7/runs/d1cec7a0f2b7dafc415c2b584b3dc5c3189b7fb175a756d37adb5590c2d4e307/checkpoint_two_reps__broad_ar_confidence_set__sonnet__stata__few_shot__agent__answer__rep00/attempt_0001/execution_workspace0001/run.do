clear all
set more off
set linesize 255
set type double

import delimited "./input.csv", clear

scalar n = _N
scalar q = 2
scalar df = n - 4

scalar critical = invFtail(q, df, 0.05)
scalar k = q * critical / df

quietly regress y x
predict double ry, residuals

quietly regress endog x
predict double rd, residuals

quietly regress y x z1 z2
predict double uy, residuals

quietly regress endog x z1 z2
predict double ud, residuals

mata:
ry = st_data(., "ry")
rd = st_data(., "rd")
uy = st_data(., "uy")
ud = st_data(., "ud")
k  = st_numscalar("k")

A = quadcross(rd, rd) - (1+k)*quadcross(ud, ud)
B = -2*(quadcross(ry, rd) - (1+k)*quadcross(uy, ud))
C = quadcross(ry, ry) - (1+k)*quadcross(uy, uy)
disc = B^2 - 4*A*C

st_numscalar("A_out", A)
st_numscalar("B_out", B)
st_numscalar("C_out", C)
st_numscalar("disc_out", disc)

if (abs(A) > 1e-12 & disc > 0) {
    sq = sqrt(disc)
    b1 = (-B - sq)/(2*A)
    b2 = (-B + sq)/(2*A)
    bounds = sort((b1 \ b2), 1)
    st_numscalar("low", bounds[1])
    st_numscalar("high", bounds[2])
    st_numscalar("unbounded", A < 0)
} else {
    st_numscalar("low", .)
    st_numscalar("high", .)
    st_numscalar("unbounded", .)
}
st_numscalar("accepts_zero", C <= 0)
end

* F at beta=1
gen double y_adj1 = y - endog
quietly regress y_adj1 x
scalar SSR_R1 = e(rss)
quietly regress y_adj1 x z1 z2
scalar SSR_U1 = e(rss)
scalar ar_f_one = ((SSR_R1 - SSR_U1)/q) / (SSR_U1/df)

* Check accepts_zero via direct F test
quietly regress y x
scalar SSR_R0 = e(rss)
quietly regress y x z1 z2
scalar SSR_U0 = e(rss)
scalar ar_f_zero = ((SSR_R0 - SSR_U0)/q) / (SSR_U0/df)
scalar critical_f = invFtail(q, df, 0.05)
scalar accepts_zero_check = (ar_f_zero <= critical_f)

display "DEBUG: A=" A_out " B=" B_out " C=" C_out " disc=" disc_out
display "DEBUG: critical=" critical " k=" k
display "DEBUG: ar_f_at_one=" ar_f_one
display "DEBUG: ar_f_at_zero=" ar_f_zero " critical_f=" critical_f
display "DEBUG: accepts_zero_quadratic=" accepts_zero " accepts_zero_Ftest=" accepts_zero_check

display "ANSWER: boundary_low estimate=" %21.12f low " se=" %21.12f . " n_obs=" %12.0f n
display "ANSWER: boundary_high estimate=" %21.12f high " se=" %21.12f . " n_obs=" %12.0f n
display "ANSWER: accepts_zero estimate=" %21.12f accepts_zero " se=" %21.12f . " n_obs=" %12.0f n
display "ANSWER: unbounded estimate=" %21.12f unbounded " se=" %21.12f . " n_obs=" %12.0f n
display "ANSWER: ar_f_at_one estimate=" %21.12f ar_f_one " se=" %21.12f . " n_obs=" %12.0f n
