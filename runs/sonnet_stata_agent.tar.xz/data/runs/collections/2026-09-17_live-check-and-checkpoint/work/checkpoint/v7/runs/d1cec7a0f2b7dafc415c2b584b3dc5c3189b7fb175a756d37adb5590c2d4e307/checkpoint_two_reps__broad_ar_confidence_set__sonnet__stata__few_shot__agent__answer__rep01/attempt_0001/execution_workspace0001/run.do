clear all
set more off
set linesize 255
set type double

import delimited "./input.csv", clear
count
scalar n = r(N)

* p = number of regressors in unrestricted model: intercept, x, z1, z2 = 4
* q = number of excluded instruments = 2
* df = n - p = n - 4
scalar q = 2
scalar df = n - 4
scalar critical = invFtail(q, df, 0.05)
scalar k = q * critical / df

* For AR test inversion:
* Residualize y and endog on included exogenous (intercept, x)
* Then for F test: regress y - beta*endog on intercept, x, z1, z2 (unrestricted)
* and on intercept, x (restricted)

* Get residuals from projecting on included exogenous (intercept, x)
quietly regress y x
predict double ry, residuals

quietly regress endog x
predict double rd, residuals

* Unrestricted: regress y on intercept, x, z1, z2
quietly regress y x z1 z2
predict double uy, residuals
* Similarly for endog
quietly regress endog x z1 z2
predict double ud, residuals

* AR F statistic for beta: F(beta) = ((SSR_R(beta) - SSR_U(beta))/q) / (SSR_U(beta)/df)
* where SSR_R(beta) = sum of squared residuals of (y - beta*endog) on intercept, x
* and SSR_U(beta) = sum of squared residuals of (y - beta*endog) on intercept, x, z1, z2
* 
* By FWL theorem:
* SSR_R(beta) = sum((ry - beta*rd)^2)
* SSR_U(beta) = sum((uy - beta*ud)^2)
*
* Acceptance: F(beta) <= critical
* => (SSR_R - SSR_U)/q / (SSR_U/df) <= critical
* => (SSR_R - SSR_U) * df <= critical * q * SSR_U
* => SSR_R * df <= SSR_U * (df + q*critical)
* => SSR_R <= (1 + k) * SSR_U   where k = q*critical/df
* => SSR_R - (1+k)*SSR_U <= 0

mata:
ry = st_data(., "ry")
rd = st_data(., "rd")
uy = st_data(., "uy")
ud = st_data(., "ud")
k = st_numscalar("k")
n = st_numscalar("n")

A = quadcross(rd,rd) - (1+k)*quadcross(ud,ud)
B = -2*(quadcross(ry,rd) - (1+k)*quadcross(uy,ud))
C = quadcross(ry,ry) - (1+k)*quadcross(uy,uy)

disc = B^2 - 4*A*C

// Compute ar_f_at_one
beta1 = 1
SSR_R1 = quadcross(ry - beta1*rd, ry - beta1*rd)
SSR_U1 = quadcross(uy - beta1*ud, uy - beta1*ud)
df_val = st_numscalar("df")
q_val = st_numscalar("q")
ar_f1 = ((SSR_R1 - SSR_U1)/q_val) / (SSR_U1/df_val)
st_numscalar("ar_f_at_one", ar_f1)

// Check discriminant
if (disc <= 0) {
    printf("No real roots\n")
    st_numscalar("low", .)
    st_numscalar("high", .)
} else {
    bounds = sort(((-B - sqrt(disc))/(2*A) \ (-B + sqrt(disc))/(2*A)), 1)
    st_numscalar("low", bounds[1])
    st_numscalar("high", bounds[2])
}

// unbounded: A<0 means set is outer rays (unbounded), A>0 means interval (bounded)
st_numscalar("unbounded", A < 0)

// accepts_zero: plug beta=0 => A*0 + B*0 + C = C <= 0
st_numscalar("accepts_zero", C <= 0)

st_numscalar("A_val", A)
st_numscalar("B_val", B)
st_numscalar("C_val", C)
st_numscalar("disc_val", disc)
end

display "A=" A_val " B=" B_val " C=" C_val " disc=" disc_val
display "k=" k " df=" df " critical=" critical

display "ANSWER: boundary_low estimate=" %21.12f (low) " se=" %21.12f (.) " n_obs=" %12.0f (n)
display "ANSWER: boundary_high estimate=" %21.12f (high) " se=" %21.12f (.) " n_obs=" %12.0f (n)
display "ANSWER: accepts_zero estimate=" %21.12f (accepts_zero) " se=" %21.12f (.) " n_obs=" %12.0f (n)
display "ANSWER: unbounded estimate=" %21.12f (unbounded) " se=" %21.12f (.) " n_obs=" %12.0f (n)
display "ANSWER: ar_f_at_one estimate=" %21.12f (ar_f_at_one) " se=" %21.12f (.) " n_obs=" %12.0f (n)
