set linesize 255
clear
import delimited "./input.csv", varnames(1)

* Keep observations within bandwidth h=0.5 of cutoff z=0
keep if abs(z) <= 0.5

* Triangular kernel weights: w = 1 - |z|/h, h=0.5
gen w = 1 - abs(z)/0.5

* Indicator for right side (z >= 0)
gen right = (z >= 0)

* Left side local linear regression
reg y z [aw=w] if right == 0
local intercept_left = _b[_cons]

* Right side local linear regression
reg y z [aw=w] if right == 1
local intercept_right = _b[_cons]

* LATE = difference in intercepts (right - left)
local late = `intercept_right' - `intercept_left'

* For SE: use WLS on full bandwidth sample with interaction terms
* y = a + b*z + c*right + d*right*z + error
* c = difference in intercepts = LATE
gen z_right = z * right

reg y z right z_right [aw=w]
local late_est = _b[right]
local late_se = _se[right]
local n_obs = e(N)

display "ANSWER: late estimate=" %21.12f `late_est' " se=" %21.12f `late_se' " n_obs=" %12.0f `n_obs'
