set linesize 255
clear

import delimited "./input.csv", varnames(1)
sort t
tsset t

gen y_lag1 = L.y
gen y_lead4 = F4.y

* Method 1: newey directly
newey y_lead4 shock y_lag1, lag(4)
scalar b_nw   = _b[shock]
scalar se_nw  = _se[shock]
scalar n_nw   = e(N)

* Method 2: OLS then compare to check the coefficient is the same
regress y_lead4 shock y_lag1
scalar b_ols  = _b[shock]

display "Newey-West b[shock] = " b_nw
display "OLS b[shock]        = " b_ols
display "Difference (should be ~0): " b_nw - b_ols
display "Newey-West SE = " se_nw
display "OLS SE        = " _se[shock]
display "N = " n_nw
