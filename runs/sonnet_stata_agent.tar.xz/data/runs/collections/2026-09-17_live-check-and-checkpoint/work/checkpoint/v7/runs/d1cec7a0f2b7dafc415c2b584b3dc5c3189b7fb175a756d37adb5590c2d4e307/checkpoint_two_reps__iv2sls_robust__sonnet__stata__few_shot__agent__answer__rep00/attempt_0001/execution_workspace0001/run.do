set linesize 255
clear

import delimited "./input.csv", varnames(1) case(lower)

* 2SLS: y_iv on x1_iv, instrument z, HC1 robust SE
ivregress 2sls y_iv (x1_iv = z), robust

local n = e(N)
local b_const = _b[_cons]
local se_const = _se[_cons]
local b_x1iv = _b[x1_iv]
local se_x1iv = _se[x1_iv]

display "ANSWER: const estimate=" %21.12f `b_const' " se=" %21.12f `se_const' " n_obs=" %12.0f `n'
display "ANSWER: x1_iv estimate=" %21.12f `b_x1iv' " se=" %21.12f `se_x1iv' " n_obs=" %12.0f `n'
