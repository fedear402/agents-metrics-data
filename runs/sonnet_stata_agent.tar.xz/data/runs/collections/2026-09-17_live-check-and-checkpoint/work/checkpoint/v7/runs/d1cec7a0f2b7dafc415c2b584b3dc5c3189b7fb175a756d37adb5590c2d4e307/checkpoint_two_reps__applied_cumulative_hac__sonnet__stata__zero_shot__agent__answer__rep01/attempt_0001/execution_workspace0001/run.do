set linesize 255
log using run.log, replace text

import delimited "./input.csv", clear

* Sort by date
sort date

* Generate time index for tsset
gen t = _n
tsset t

* Generate log variables
gen ln_sales = ln(sales)
gen ln_vix = ln(vix)

* Generate first difference of ln(vix)
gen d_ln_vix = ln_vix - ln_vix[_n-1]

* Generate lags 1-15 of d_ln_vix
forvalues k = 1/15 {
    gen d_ln_vix_L`k' = d_ln_vix[_n-`k']
}

* OLS to get coefficients (same as newey point estimates)
regress ln_sales d_ln_vix_L1-d_ln_vix_L15

* Store N and OLS coefficients
scalar N = e(N)
scalar b_lag1 = _b[d_ln_vix_L1]
scalar b_lag15 = _b[d_ln_vix_L15]

scalar cumresp = 0
forvalues k = 1/15 {
    scalar cumresp = cumresp + _b[d_ln_vix_L`k']
}

* Newey-West HAC with maxlag=15
newey ln_sales d_ln_vix_L1-d_ln_vix_L15, lag(15)

scalar N2 = e(N)

* Get Newey-West covariance matrix
matrix V_nw = e(V)

* Scale by N/(N-16)
matrix V_scaled = V_nw * (N2 / (N2 - 16))

* SE for lag_1 (index 1)
scalar se_lag1 = sqrt(V_scaled[1,1])

* SE for lag_15 (index 15)
scalar se_lag15 = sqrt(V_scaled[15,15])

* SE for cumulative response using full covariance matrix
* Variables are: d_ln_vix_L1 ... d_ln_vix_L15, _cons (indices 1-15 for lags)
matrix c = J(1, 16, 0)
forvalues k = 1/15 {
    matrix c[1, `k'] = 1
}

matrix var_cum = c * V_scaled * c'
scalar se_cum = sqrt(var_cum[1,1])

* Report results
display "ANSWER: cumulative_response estimate=" %21.12f cumresp " se=" %21.12f se_cum " n_obs=" %12.0f N2
display "ANSWER: lag_1 estimate=" %21.12f b_lag1 " se=" %21.12f se_lag1 " n_obs=" %12.0f N2
display "ANSWER: lag_15 estimate=" %21.12f b_lag15 " se=" %21.12f se_lag15 " n_obs=" %12.0f N2

log close
