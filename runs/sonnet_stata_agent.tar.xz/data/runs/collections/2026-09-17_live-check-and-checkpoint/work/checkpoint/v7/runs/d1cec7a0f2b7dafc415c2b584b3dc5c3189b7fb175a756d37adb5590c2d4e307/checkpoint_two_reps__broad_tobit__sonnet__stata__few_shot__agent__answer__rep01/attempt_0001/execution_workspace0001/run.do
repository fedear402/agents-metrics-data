clear all
set more off
set linesize 255
set type double

import delimited "./input.csv", clear

* Fit Tobit model with lower censoring at 0
tobit y x z, ll(0) tolerance(1e-10) nrtolerance(1e-10)

* Store results
local n = e(N)
local b_const = _b[_cons]
local b_x = _b[x]
local b_z = _b[z]
local se_const = _se[_cons]
local se_x = _se[x]
local se_z = _se[z]
local sigma = sqrt(_b[/var(e.y)])

display "ANSWER: const estimate=" %21.12f `b_const' " se=" %21.12f `se_const' " n_obs=" %12.0f `n'
display "ANSWER: x estimate=" %21.12f `b_x' " se=" %21.12f `se_x' " n_obs=" %12.0f `n'
display "ANSWER: z estimate=" %21.12f `b_z' " se=" %21.12f `se_z' " n_obs=" %12.0f `n'
display "ANSWER: sigma estimate=" %21.12f `sigma' " se=" %21.12f . " n_obs=" %12.0f `n'
