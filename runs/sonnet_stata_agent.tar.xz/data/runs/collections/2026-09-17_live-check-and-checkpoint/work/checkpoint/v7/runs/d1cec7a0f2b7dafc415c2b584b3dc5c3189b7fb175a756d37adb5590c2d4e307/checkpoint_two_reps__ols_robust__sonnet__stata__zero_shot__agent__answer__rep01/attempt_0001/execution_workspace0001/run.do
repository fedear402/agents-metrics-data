set linesize 255
clear all

import delimited "./input.csv", varnames(1) case(lower)

* OLS with HC1 robust standard errors
* Stata's vce(robust) uses HC1 by default (divides by n-k, not n)
regress y_lin x1 x2, vce(robust)

scalar n_obs = e(N)

* Extract coefficients
scalar b_const = _b[_cons]
scalar b_x1    = _b[x1]
scalar b_x2    = _b[x2]

* Extract robust SEs
scalar se_const = _se[_cons]
scalar se_x1    = _se[x1]
scalar se_x2    = _se[x2]

display "ANSWER: const estimate=" %21.12f b_const " se=" %21.12f se_const " n_obs=" %12.0f n_obs
display "ANSWER: x1 estimate=" %21.12f b_x1 " se=" %21.12f se_x1 " n_obs=" %12.0f n_obs
display "ANSWER: x2 estimate=" %21.12f b_x2 " se=" %21.12f se_x2 " n_obs=" %12.0f n_obs
