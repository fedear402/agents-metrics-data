set linesize 255
clear
import delimited "./input.csv", varnames(1)

tsset t

* Fit ARIMA(1,1,1) with no constant
arima y, arima(1,1,1) noconstant

local n = e(N)

* Extend dataset by 1 obs to get t=251 forecast
local last_t = t[_N]
set obs `=_N+1'
replace t = `last_t' + 1 in `=_N'
tsset t

* One-step-ahead forecast and MSE starting from t=251
predict yhat, y dynamic(251)
predict ymse, mse dynamic(251)

local fc     = yhat[_N]
local se_fc  = sqrt(ymse[_N])
local lower  = `fc' - 1.96 * `se_fc'
local upper  = `fc' + 1.96 * `se_fc'

display "ANSWER: forecast estimate=" %21.12f `fc'    " se=" %21.12f `se_fc' " n_obs=" %12.0f `n'
display "ANSWER: lower_95 estimate=" %21.12f `lower' " se=."                " n_obs=" %12.0f `n'
display "ANSWER: upper_95 estimate=" %21.12f `upper' " se=."                " n_obs=" %12.0f `n'
