version 17
clear all
set more off
set linesize 255

import delimited "./input.csv", clear

// Step 1: Normalize regional weights (one obs per region)
bysort region_id (industry_id): gen first_in_region = (_n == 1)
qui sum region_weight if first_in_region
local sum_rw = r(sum)
gen e_r = region_weight / `sum_rw'

// Step 2: Construct regional shift-share instrument z_r = sum_n share_rn * shock_n
bysort region_id: egen z_r = total(share * shock)

// Step 3: Compute e_r-weighted regional means of y, x, z
qui sum y [aw=e_r] if first_in_region
local mean_y = r(mean)
qui sum x [aw=e_r] if first_in_region
local mean_x = r(mean)
qui sum z_r [aw=e_r] if first_in_region
local mean_z = r(mean)

// Demeaned variables (at region level)
gen y0 = y - `mean_y'
gen x0 = x - `mean_x'
gen z0 = z_r - `mean_z'

// Step 4: Compute exposure masses s_n and aggregate residuals
bysort industry_id: egen s_n = total(e_r * share)
bysort industry_id: egen num_ybar = total(e_r * share * y0)
bysort industry_id: egen num_xbar = total(e_r * share * x0)
bysort industry_id: egen num_zbar = total(e_r * share * z0)

gen ybar = num_ybar / s_n
gen xbar = num_xbar / s_n
gen zbar = num_zbar / s_n

// Collapse to shock level (one obs per industry)
bysort industry_id (region_id): gen first_in_industry = (_n == 1)
preserve
keep if first_in_industry
keep industry_id shock s_n ybar xbar zbar
sort industry_id

local N = _N

// Save to tempfile for Mata
tempfile shocklevel
save `shocklevel'
restore

// Reload shock-level data
use `shocklevel', clear

// Step 5: Shock-level IV estimation via Mata
mata:
    N = st_nobs()
    s    = st_data(., "s_n")
    shk  = st_data(., "shock")
    yb   = st_data(., "ybar")
    xb   = st_data(., "xbar")
    zb   = st_data(., "zbar")
    
    // EFFECT: IV of ybar on (1, xbar), instrument=(1, shock), weights=s
    dep       = yb
    endog     = xb
    instr     = shk
    regressors  = (J(N,1,1), endog)
    instruments = (J(N,1,1), instr)
    
    cross    = instruments' * (s :* regressors)
    inv_c    = luinv(cross)
    beta_eff = inv_c * (instruments' * (s :* dep))
    resid_eff = dep - regressors * beta_eff
    scores_eff = instruments :* (s :* resid_eff)
    cov_eff  = N/(N-2) * inv_c * (scores_eff' * scores_eff) * inv_c'
    
    effect_est = beta_eff[2]
    effect_se  = sqrt(cov_eff[2,2])
    
    // FIRST STAGE: IV of xbar on (1, zbar), instrument=(1, shock), weights=s
    dep2      = xb
    endog2    = zb
    regressors2  = (J(N,1,1), endog2)
    instruments2 = (J(N,1,1), instr)
    
    cross2    = instruments2' * (s :* regressors2)
    inv_c2    = luinv(cross2)
    beta_fs   = inv_c2 * (instruments2' * (s :* dep2))
    resid_fs  = dep2 - regressors2 * beta_fs
    scores_fs = instruments2 :* (s :* resid_fs)
    cov_fs    = N/(N-2) * inv_c2 * (scores_fs' * scores_fs) * inv_c2'
    
    fs_est = beta_fs[2]
    fs_se  = sqrt(cov_fs[2,2])
    
    // EFFECTIVE SHOCKS: 1/sum_n s_n^2
    eff_shocks = 1 / sum(s:^2)
    
    st_numscalar("effect_est",   effect_est)
    st_numscalar("effect_se",    effect_se)
    st_numscalar("fs_est",       fs_est)
    st_numscalar("fs_se",        fs_se)
    st_numscalar("eff_shocks",   eff_shocks)
    st_numscalar("N_industries", N)
end

display "ANSWER: effect estimate=" %21.12f effect_est " se=" %21.12f effect_se " n_obs=" %12.0f N_industries
display "ANSWER: first_stage estimate=" %21.12f fs_est " se=" %21.12f fs_se " n_obs=" %12.0f N_industries
display "ANSWER: effective_shocks estimate=" %21.12f eff_shocks " se=" %21.12f . " n_obs=" %12.0f N_industries
