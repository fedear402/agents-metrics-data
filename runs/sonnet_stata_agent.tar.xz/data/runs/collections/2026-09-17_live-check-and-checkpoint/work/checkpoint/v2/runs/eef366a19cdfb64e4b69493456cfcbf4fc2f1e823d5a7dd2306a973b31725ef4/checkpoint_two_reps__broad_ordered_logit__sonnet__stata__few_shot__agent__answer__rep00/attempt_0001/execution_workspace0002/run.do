clear all
set more off
set linesize 255
set type double

import delimited "/private/tmp/prospective_task_4jx7y8v4/input.csv", clear

* Verify data
count
tab y

* Fit ordered logit: y ~ x + z, no separate intercept (two free cutpoints)
ologit y x z, tolerance(1e-10) nrtolerance(1e-10)

* Store estimates
scalar b_x = _b[x]
scalar se_x = _se[x]
scalar b_z = _b[z]
scalar se_z = _se[z]
scalar n_obs = e(N)

* Probability of category 3 at x=1, z=0
* P(y=3) = 1 - F(cut2 - (b_x*1 + b_z*0)) = 1 - invlogit(cut2 - b_x)
scalar cut2 = _b[/cut2]
scalar xb_eval = b_x * 1 + b_z * 0
scalar prob_high = 1 - invlogit(cut2 - xb_eval)

display "ANSWER: x estimate=" %21.12f b_x " se=" %21.12f se_x " n_obs=" %12.0f n_obs
display "ANSWER: z estimate=" %21.12f b_z " se=" %21.12f se_z " n_obs=" %12.0f n_obs
display "ANSWER: prob_high estimate=" %21.12f prob_high " se=" %21.12f . " n_obs=" %12.0f n_obs
