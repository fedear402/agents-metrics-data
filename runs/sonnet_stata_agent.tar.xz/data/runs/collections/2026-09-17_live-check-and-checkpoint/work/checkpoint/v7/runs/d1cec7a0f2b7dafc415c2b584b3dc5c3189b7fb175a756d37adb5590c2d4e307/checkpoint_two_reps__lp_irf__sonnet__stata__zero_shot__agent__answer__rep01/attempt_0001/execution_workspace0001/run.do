set linesize 255
import delimited "./input.csv", clear

* Sort by t and declare time series
sort t
tsset t

* Generate y_{t+4} (lead of y by 4 periods)
gen y_lead4 = f4.y

* Generate y_{t-1} (lag of y by 1 period)
gen y_lag1 = l1.y

* Estimate local projection: y_{t+4} = b0 + b1*shock + b2*y_{t-1} + e
* Using Newey-West SE with lag 4
newey y_lead4 shock y_lag1, lag(4)

* Store results
local b_shock = _b[shock]
local se_shock = _se[shock]
local nobs = e(N)

display "ANSWER: irf_h4 estimate=" %21.12f `b_shock' " se=" %21.12f `se_shock' " n_obs=" %12.0f `nobs'
