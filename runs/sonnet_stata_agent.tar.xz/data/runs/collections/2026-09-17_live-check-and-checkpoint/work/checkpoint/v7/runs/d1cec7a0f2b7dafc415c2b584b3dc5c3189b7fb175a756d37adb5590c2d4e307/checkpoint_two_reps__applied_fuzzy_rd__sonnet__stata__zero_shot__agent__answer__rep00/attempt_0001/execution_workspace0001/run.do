set linesize 255
import delimited "./input.csv", clear

* Keep observations within bandwidth (abs(score) < 1)
keep if abs(score) < 1

count
scalar n_obs = r(N)

* Triangular weights
gen w = 1 - abs(score)

* Right side indicator (score >= 0)
gen right = (score >= 0)

* Local linear terms: separate slopes each side
gen score_left  = score * (1 - right)
gen score_right = score * right

* Constant
gen cons = 1

* All computation in Mata to get exact HC0 (no df correction) with WLS
mata:
    // Load data
    st_view(X=.,  ., ("cons","right","score_left","score_right"))
    st_view(wv=., ., "w")
    st_view(Y_earn=., ., "earnings")
    st_view(Y_part=., ., "participated")
    
    n = rows(X)
    k = cols(X)
    
    // WLS: b = (X'WX)^{-1} X'Wy
    XWX = X' * (X :* wv)
    iXWX = invsym(XWX)
    
    b_rf = iXWX * (X' * (wv :* Y_earn))
    b_fs = iXWX * (X' * (wv :* Y_part))
    
    // Residuals
    erf = Y_earn - X * b_rf
    efs = Y_part - X * b_fs
    
    // HC0 sandwich for each regression
    // V_hc0 = (X'WX)^{-1} * [sum_i w_i^2 * e_i^2 * x_i x_i'] * (X'WX)^{-1}
    we_rf = wv :* erf
    we_fs = wv :* efs
    
    meat_rf = X' * (X :* (we_rf :* we_rf))
    meat_fs = X' * (X :* (we_fs :* we_fs))
    meat_cx = X' * (X :* (we_rf :* we_fs))
    
    V_rf = iXWX * meat_rf * iXWX
    V_fs = iXWX * meat_fs * iXWX
    V_cx = iXWX * meat_cx * iXWX
    
    // 'right' is column 2
    rf_est = b_rf[2]
    fs_est = b_fs[2]
    rf_var = V_rf[2,2]
    fs_var = V_fs[2,2]
    cov_cf = V_cx[2,2]
    
    rf_se = sqrt(rf_var)
    fs_se = sqrt(fs_var)
    
    // Delta method: te = rf / fs
    // Var(te) = (1/fs)^2*Var(rf) + (rf/fs^2)^2*Var(fs) - 2*(rf/fs^3)*Cov(rf,fs)
    te_est = rf_est / fs_est
    var_te = (1/fs_est)^2 * rf_var + (rf_est^2/fs_est^4) * fs_var - 2*(rf_est/fs_est^3)*cov_cf
    te_se  = sqrt(var_te)
    
    st_numscalar("rf_est", rf_est)
    st_numscalar("rf_se",  rf_se)
    st_numscalar("fs_est", fs_est)
    st_numscalar("fs_se",  fs_se)
    st_numscalar("te_est", te_est)
    st_numscalar("te_se",  te_se)
    st_numscalar("cov_cf", cov_cf)
    
    // Print intermediate checks
    printf("b_rf = "); b_rf'
    printf("b_fs = "); b_fs'
    printf("cov_rf_fs(right) = %g\n", cov_cf)
end

display "ANSWER: treatment_effect estimate=" %21.12f te_est " se=" %21.12f te_se " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate="     %21.12f rf_est " se=" %21.12f rf_se " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate="      %21.12f fs_est " se=" %21.12f fs_se " n_obs=" %12.0f n_obs
