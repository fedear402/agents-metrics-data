set linesize 255
clear all

import delimited "./input.csv", varnames(1)

sort time

* Store all y values in a local or matrix for rolling windows
* We need forecasts for f=101,...,250
* For each f, use obs f-100,...,f-1 (100 obs), fit AR(1) on s=f-99,...,f-1 (99 pairs)

* Create lagged y
gen y_lag = y[_n-1]

* Save observed y values to scalars for easy access
* We'll use a loop approach with preserve/restore

* Store all y values
mkmat y, matrix(Y)
local N = _N

* Matrix to store forecasts
matrix FCST = J(150, 2, .)

forvalues idx = 1/150 {
    local f = 100 + `idx'
    * Window: obs f-100 to f-1 in 1-based indexing
    * Regression pairs: s = f-99 to f-1 (99 pairs)
    * y_s = a + b*y_{s-1}
    * s ranges from f-99 to f-1
    * s-1 ranges from f-100 to f-2
    
    local s_start = `f' - 99
    local s_end   = `f' - 1
    
    * Run regression on this window
    quietly reg y y_lag if time >= `s_start' & time <= `s_end'
    
    local a_hat = _b[_cons]
    local b_hat = _b[y_lag]
    
    * y_{f-1} is the observation at time f-1
    quietly summarize y if time == `f' - 1
    local y_prev = r(mean)
    
    local fcst = `a_hat' + `b_hat' * `y_prev'
    
    matrix FCST[`idx', 1] = `f'
    matrix FCST[`idx', 2] = `fcst'
}

* Now compute RMSE
* Get actual y values for f=101,...,250
gen forecast = .
gen actual = .

forvalues idx = 1/150 {
    local f = 100 + `idx'
    quietly replace forecast = FCST[`idx', 2] if time == `f'
    quietly replace actual = y if time == `f'
}

gen sq_err = (y - forecast)^2 if time >= 101 & time <= 250
quietly summarize sq_err
local sse = r(sum)
local rmse = sqrt(`sse' / 150)

* Extract specific forecasts
local fc101 = FCST[1, 2]
local fc150 = FCST[50, 2]
local fc200 = FCST[100, 2]
local fc250 = FCST[150, 2]

display "ANSWER: rmse estimate=" %21.12f `rmse' " se=" %21.12f . " n_obs=" %12.0f 150
display "ANSWER: forecast_101 estimate=" %21.12f `fc101' " se=" %21.12f . " n_obs=" %12.0f 99
display "ANSWER: forecast_150 estimate=" %21.12f `fc150' " se=" %21.12f . " n_obs=" %12.0f 99
display "ANSWER: forecast_200 estimate=" %21.12f `fc200' " se=" %21.12f . " n_obs=" %12.0f 99
display "ANSWER: forecast_250 estimate=" %21.12f `fc250' " se=" %21.12f . " n_obs=" %12.0f 99
