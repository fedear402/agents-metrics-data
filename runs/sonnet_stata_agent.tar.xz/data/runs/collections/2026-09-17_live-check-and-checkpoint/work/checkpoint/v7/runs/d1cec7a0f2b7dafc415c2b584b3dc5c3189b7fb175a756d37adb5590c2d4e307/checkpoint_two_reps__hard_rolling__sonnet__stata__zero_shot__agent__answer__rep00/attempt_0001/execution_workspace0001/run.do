set linesize 255
clear all

* Read data
import delimited "./input.csv", clear

* Sort by time
sort time

* Create lag variable
gen y_lag = y[_n-1]

* Storage for forecasts
gen forecast = .

* Rolling AR(1) forecasts for f=101,...,250
forvalues f = 101/250 {
    * Use obs s = f-99,...,f-1 (window of 99 regression pairs)
    * s goes from f-99 to f-1, each pair is (y_s, y_{s-1})
    * So the window for regression needs y_{f-100} through y_{f-1}
    * In our dataset, these are observations with time = f-99,...,f-1
    * where y_lag(time=s) = y(time=s-1)
    
    local s_start = `f' - 99
    local s_end   = `f' - 1
    
    * Fit OLS on this window
    quietly regress y y_lag if time >= `s_start' & time <= `s_end'
    
    * Get coefficients
    local a_hat = _b[_cons]
    local b_hat = _b[y_lag]
    
    * Get y_{f-1} (the last observed value before f)
    local y_prev = y[`f'-1]
    
    * Forecast
    local fc = `a_hat' + `b_hat' * `y_prev'
    replace forecast = `fc' if time == `f'
}

* Compute RMSE over f=101,...,250
gen sq_err = (y - forecast)^2 if time >= 101 & time <= 250
quietly summarize sq_err
local rmse = sqrt(r(sum) / 150)

* Extract specific forecasts
quietly summarize forecast if time == 101
local fc101 = r(mean)
quietly summarize forecast if time == 150
local fc150 = r(mean)
quietly summarize forecast if time == 200
local fc200 = r(mean)
quietly summarize forecast if time == 250
local fc250 = r(mean)

* Report results
display "ANSWER: rmse estimate=" %21.12f `rmse' " se=" %21.12f . " n_obs=" %12.0f 150
display "ANSWER: forecast_101 estimate=" %21.12f `fc101' " se=" %21.12f . " n_obs=" %12.0f 99
display "ANSWER: forecast_150 estimate=" %21.12f `fc150' " se=" %21.12f . " n_obs=" %12.0f 99
display "ANSWER: forecast_200 estimate=" %21.12f `fc200' " se=" %21.12f . " n_obs=" %12.0f 99
display "ANSWER: forecast_250 estimate=" %21.12f `fc250' " se=" %21.12f . " n_obs=" %12.0f 99

