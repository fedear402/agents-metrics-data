set linesize 255
import delimited "./input.csv", clear

stset t_obs, failure(event)
stcox treat x, nohr

local b_treat = _b[treat]
local se_treat = _se[treat]
local b_x = _b[x]
local se_x = _se[x]
local n = e(N)

display "ANSWER: treat estimate=" %21.12f `b_treat' " se=" %21.12f `se_treat' " n_obs=" %12.0f `n'
display "ANSWER: x estimate=" %21.12f `b_x' " se=" %21.12f `se_x' " n_obs=" %12.0f `n'
