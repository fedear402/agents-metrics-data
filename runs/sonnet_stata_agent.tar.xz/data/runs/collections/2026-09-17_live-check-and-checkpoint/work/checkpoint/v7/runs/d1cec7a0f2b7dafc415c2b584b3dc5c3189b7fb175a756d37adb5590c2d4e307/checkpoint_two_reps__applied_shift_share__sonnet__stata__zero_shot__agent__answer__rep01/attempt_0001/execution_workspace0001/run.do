set linesize 255
clear all

* Import data
import delimited "./input.csv", clear

* Step 1: Normalize regional weights (one obs per region)
* Get one obs per region for weights
bysort region_id (industry_id): gen region_first = (_n == 1)

* Sum of region_weights across regions (one per region)
quietly sum region_weight if region_first
scalar total_weight = r(sum)
gen e_r = region_weight / total_weight

* Step 2: Construct shift-share instrument z_r = sum_n share_rn * shock_n
gen share_shock = share * shock
bysort region_id: egen z = sum(share_shock)

* Step 3: Collapse to region level for the regional 2SLS
* Keep one obs per region
preserve
keep if region_first
keep region_id e_r z x y region_weight

* Verify e_r sums to 1
quietly sum e_r
display "Sum of e_r = " r(sum)

* Step 4: Weighted 2SLS of y on x, instrumenting x with z, weights e_r
* First get 2SLS estimate using ivreg2 or ivregress
* ivregress 2sls y (x = z) [aw=e_r], robust
* But we need the exact 2SLS slope

* Compute weighted means
quietly sum y [aw=e_r]
scalar mean_y = r(mean)
quietly sum x [aw=e_r]
scalar mean_x = r(mean)
quietly sum z [aw=e_r]
scalar mean_z = r(mean)

* Demeaned variables
gen y0 = y - mean_y
gen x0 = x - mean_x
gen z0 = z - mean_z

* 2SLS slope = cov(z0, y0, w) / cov(z0, x0, w)
* = sum(e_r * z0 * y0) / sum(e_r * z0 * x0)
gen ez0y0 = e_r * z0 * y0
gen ez0x0 = e_r * z0 * x0

quietly sum ez0y0
scalar cov_zy = r(sum)
quietly sum ez0x0
scalar cov_zx = r(sum)

scalar beta_2sls = cov_zy / cov_zx
display "Regional 2SLS slope (beta): " beta_2sls

* First stage slope: x on z with e_r weights
gen ez0z0 = e_r * z0 * z0
quietly sum ez0z0
scalar cov_zz = r(sum)
scalar fs_slope = cov_zx / cov_zz
display "First stage slope: " fs_slope

restore

* ============================================================
* Shock-level aggregation for exposure-robust SEs
* ============================================================

* We need e_r (normalized weights) for all obs
* Already computed e_r for all obs above

* For each industry n, compute:
* s_n = sum_r e_r * share_rn
* ybar_n = sum_r e_r * share_rn * y0_r / s_n
* xbar_n = sum_r e_r * share_rn * x0_r / s_n
* zbar_n = sum_r e_r * share_rn * z0_r / s_n

* First get region-level demeaned variables
* Merge in the demeaned variables
* We need y0, x0, z0 at region level

* Reconstruct at full dataset level
* Get region-level values for y, x, z

* We have e_r, z already at full dataset level
* Need demeaned: subtract weighted means

* Compute weighted means of y, x, z at region level (constant within region)
* Since x,y are constant within region, use region_first
preserve
keep if region_first
quietly sum y [aw=e_r]
scalar mean_y = r(mean)
quietly sum x [aw=e_r]
scalar mean_x = r(mean)
quietly sum z [aw=e_r]
scalar mean_z = r(mean)
restore

* Now create demeaned at full obs level
gen y0 = y - mean_y
gen x0 = x - mean_x
gen z0 = z - mean_z

* Now compute shock-level aggregates
* s_n = sum_r e_r * share_rn
gen e_share = e_r * share

bysort industry_id: egen s_n = sum(e_share)

* weighted residuals
gen e_share_y0 = e_r * share * y0
gen e_share_x0 = e_r * share * x0
gen e_share_z0 = e_r * share * z0

bysort industry_id: egen sum_esy0 = sum(e_share_y0)
bysort industry_id: egen sum_esx0 = sum(e_share_x0)
bysort industry_id: egen sum_esz0 = sum(e_share_z0)

gen ybar = sum_esy0 / s_n
gen xbar = sum_esx0 / s_n
gen zbar = sum_esz0 / s_n

* Collapse to industry level
preserve
bysort industry_id (region_id): keep if _n == 1
keep industry_id shock s_n ybar xbar zbar

* Number of industries
count
scalar N_ind = r(N)
display "Number of industries: " N_ind

* ============================================================
* Shock-level IV for effect (2SLS): ybar on xbar, instrument=shock, weights=s_n
* ============================================================

* 2SLS slope at shock level
* = cov(shock, ybar, s_n) / cov(shock, xbar, s_n)
* But since instrument is shock and endogenous is xbar,
* we regress ybar on xbar with shock as instrument

* IV slope: beta = [sum s_n * shock_n * ybar_n] / [sum s_n * shock_n * xbar_n]
* (after demeaning by s_n weights)

quietly sum shock [aw=s_n]
scalar mean_shock = r(mean)
quietly sum ybar [aw=s_n]
scalar mean_ybar = r(mean)
quietly sum xbar [aw=s_n]
scalar mean_xbar = r(mean)
quietly sum zbar [aw=s_n]
scalar mean_zbar = r(mean)

gen shock0 = shock - mean_shock
gen ybar0 = ybar - mean_ybar
gen xbar0 = xbar - mean_xbar
gen zbar0 = zbar - mean_zbar

gen s_shock_ybar = s_n * shock0 * ybar0
gen s_shock_xbar = s_n * shock0 * xbar0

quietly sum s_shock_ybar
scalar num_effect = r(sum)
quietly sum s_shock_xbar
scalar den_effect = r(sum)

scalar beta_effect = num_effect / den_effect
display "Shock-level IV slope (effect) = " beta_effect
display "Matches regional 2SLS? beta_2sls = " beta_2sls

* ============================================================
* HC1 SE for effect
* ============================================================
* Structural IV residuals: u_n = ybar_n - beta_effect * xbar_n
* (using demeaned or levels - since intercept in model, use residuals from fitted model)
* fitted: ybar_hat = alpha + beta*xbar
* alpha = mean_ybar - beta * mean_xbar (from WLS)

scalar alpha_effect = mean_ybar - beta_effect * mean_xbar
gen uhat_effect = ybar - alpha_effect - beta_effect * xbar

* HC1 variance: V = (N/(N-2)) * [sum s_n * shock0^2 * uhat^2] / [sum s_n * shock0 * xbar0]^2
gen s_shock0sq_u2 = s_n * shock0^2 * uhat_effect^2

quietly sum s_shock0sq_u2
scalar meat_effect = r(sum)

scalar var_effect = (N_ind / (N_ind - 2)) * meat_effect / (den_effect^2)
scalar se_effect = sqrt(var_effect)
display "SE for effect = " se_effect

* ============================================================
* First stage: xbar on zbar, instrument=shock, weights=s_n
* ============================================================
* FS slope at shock level:
* = cov(shock, xbar, s_n) / cov(shock, zbar, s_n)

gen s_shock_zbar = s_n * shock0 * zbar0

quietly sum s_shock_zbar
scalar den_fs = r(sum)
* num_fs = den_effect (already computed as sum s_n * shock0 * xbar0)

scalar fs_slope_check = den_effect / den_fs
display "First stage slope (shock-level check) = " fs_slope_check
display "Matches fs_slope? " fs_slope

* HC1 SE for first stage
* Structural residuals: v_n = xbar_n - fs_alpha - fs_slope * zbar_n
scalar fs_alpha = mean_xbar - fs_slope_check * mean_zbar
gen vhat_fs = xbar - fs_alpha - fs_slope_check * zbar

gen s_shock0sq_v2 = s_n * shock0^2 * vhat_fs^2
quietly sum s_shock0sq_v2
scalar meat_fs = r(sum)

scalar var_fs = (N_ind / (N_ind - 2)) * meat_fs / (den_fs^2)
scalar se_fs = sqrt(var_fs)
display "SE for first stage = " se_fs

* ============================================================
* Effective shocks = 1 / sum_n s_n^2
* ============================================================
gen s_n_sq = s_n^2
quietly sum s_n_sq
scalar eff_shocks = 1 / r(sum)
display "Effective shocks = " eff_shocks

* ============================================================
* Report answers
* ============================================================
display "ANSWER: effect estimate=" %21.12f beta_effect " se=" %21.12f se_effect " n_obs=" %12.0f N_ind
display "ANSWER: first_stage estimate=" %21.12f fs_slope_check " se=" %21.12f se_fs " n_obs=" %12.0f N_ind
display "ANSWER: effective_shocks estimate=" %21.12f eff_shocks " se=." " n_obs=" %12.0f N_ind

restore
