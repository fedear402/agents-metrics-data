set linesize 255
clear all

import delimited "/private/tmp/prospective_task_dqb_sgrv/input.csv", clear

local n = _N
local df1 = 2
local df2 = `n' - 4

scalar fcrit = invFtail(`df1', `df2', 0.05)
display "F critical value (95th pct, df1=2, df2=" `df2' "): " fcrit

gen ones = 1

mkmat y endog x ones z1 z2, matrix(DATA)

* DATA columns: y=1, endog=2, x=3, ones=4, z1=5, z2=6
matrix Xfull = DATA[1...,4], DATA[1...,3], DATA[1...,5], DATA[1...,6]
matrix Xrest = DATA[1...,4], DATA[1...,3]
matrix yvec = DATA[1...,1]
matrix evec = DATA[1...,2]

* Projection matrices times vectors
* Mfy = (I - Xfull * inv(Xfull'*Xfull) * Xfull') * yvec
matrix tmp = invsym(Xfull'*Xfull)
matrix Mfy = yvec - Xfull * tmp * (Xfull'*yvec)
matrix Mfe = evec - Xfull * tmp * (Xfull'*evec)

matrix tmp2 = invsym(Xrest'*Xrest)
matrix Mry = yvec - Xrest * tmp2 * (Xrest'*yvec)
matrix Mre = evec - Xrest * tmp2 * (Xrest'*evec)

* Inner products (using matrix multiplication; transpose with ')
* In Stata, A' means transpose of A
matrix inner_yMfy = Mfy' * yvec
matrix inner_yMfe = Mfy' * evec
matrix inner_eMfe = Mfe' * evec
matrix inner_yMry = Mry' * yvec
matrix inner_yMre = Mry' * evec
matrix inner_eMre = Mre' * evec

scalar yMfy = inner_yMfy[1,1]
scalar yMfe = inner_yMfe[1,1]
scalar eMfe = inner_eMfe[1,1]
scalar yMry = inner_yMry[1,1]
scalar yMre = inner_yMre[1,1]
scalar eMre = inner_eMre[1,1]

display "yMfy=" yMfy " yMfe=" yMfe " eMfe=" eMfe
display "yMry=" yMry " yMre=" yMre " eMre=" eMre

* RSS_U(beta) = eMfe*beta^2 - 2*yMfe*beta + yMfy
* RSS_R(beta) = eMre*beta^2 - 2*yMre*beta + yMry
*
* F(beta) = [(RSS_R - RSS_U)/df1] / [RSS_U/df2]
* F(beta) <= fcrit iff df2*(RSS_R - RSS_U) <= fcrit*df1*RSS_U
* iff df2*(RSS_R - RSS_U) - fcrit*df1*RSS_U <= 0
* iff df2*RSS_R - (df2 + fcrit*df1)*RSS_U <= 0
* => quadratic: c2*beta^2 + c1*beta + c0 <= 0

scalar c0 = `df2' * yMry - (`df2' + fcrit * `df1') * yMfy
scalar c1 = `df2' * (-2*yMre) - (`df2' + fcrit * `df1') * (-2*yMfe)
scalar c2 = `df2' * eMre - (`df2' + fcrit * `df1') * eMfe

display "Quadratic: " c2 " * beta^2 + " c1 " * beta + " c0
display "df2=" `df2' " df1=" `df1'

scalar disc = c1^2 - 4*c2*c0
display "Discriminant: " disc

if (disc < 0) {
    display "No real roots - set is either empty or entire real line"
    if (c2 < 0) {
        display "c2<0 and disc<0: F(beta)<fcrit for all beta (entire real line)"
        scalar unbounded = 1
        scalar boundary_low = .
        scalar boundary_high = .
        scalar accepts_zero = 1
    }
    else {
        display "c2>0 and disc<0: F(beta)>fcrit for all beta (empty set)"
        scalar unbounded = 0
        scalar boundary_low = .
        scalar boundary_high = .
        scalar accepts_zero = 0
    }
}
else {
    scalar root1 = (-c1 - sqrt(disc)) / (2*c2)
    scalar root2 = (-c1 + sqrt(disc)) / (2*c2)
    scalar boundary_low = min(root1, root2)
    scalar boundary_high = max(root1, root2)
    display "Root1: " root1
    display "Root2: " root2
    
    if (c2 > 0) {
        * Set is [boundary_low, boundary_high]
        scalar unbounded = 0
        scalar accepts_zero = (boundary_low <= 0 & 0 <= boundary_high)
    }
    else {
        * Set is (-inf, boundary_low] U [boundary_high, inf)
        scalar unbounded = 1
        scalar accepts_zero = (0 <= boundary_low | 0 >= boundary_high)
    }
}

display "boundary_low: " boundary_low
display "boundary_high: " boundary_high
display "unbounded: " unbounded
display "accepts_zero: " accepts_zero

* F statistic at beta=1
scalar RSS_U_1 = eMfe * 1^2 - 2*yMfe*1 + yMfy
scalar RSS_R_1 = eMre * 1^2 - 2*yMre*1 + yMry
scalar ar_f_at_one = ((RSS_R_1 - RSS_U_1)/`df1') / (RSS_U_1/`df2')
display "AR F at beta=1: " ar_f_at_one

* Verification: check RSS_U_1 and RSS_R_1 directly
gen yw1 = y - 1*endog
reg yw1 ones x z1 z2, nocons
display "RSS_U(1) from reg: " e(rss) " (computed: " RSS_U_1 ")"
reg yw1 ones x, nocons
display "RSS_R(1) from reg: " e(rss) " (computed: " RSS_R_1 ")"

* Report answers
display "ANSWER: boundary_low estimate=" %21.12f boundary_low " se=" %21.12f . " n_obs=" %12.0f `n'
display "ANSWER: boundary_high estimate=" %21.12f boundary_high " se=" %21.12f . " n_obs=" %12.0f `n'
display "ANSWER: accepts_zero estimate=" %21.12f accepts_zero " se=" %21.12f . " n_obs=" %12.0f `n'
display "ANSWER: unbounded estimate=" %21.12f unbounded " se=" %21.12f . " n_obs=" %12.0f `n'
display "ANSWER: ar_f_at_one estimate=" %21.12f ar_f_at_one " se=" %21.12f . " n_obs=" %12.0f `n'
