set linesize 255
import delimited "./input.csv", clear

regress y_lin x1 x2, vce(robust)

local b0 = _b[_cons]
local se0 = _se[_cons]
local b1 = _b[x1]
local se1 = _se[x1]
local b2 = _b[x2]
local se2 = _se[x2]
local n = e(N)

display "ANSWER: const estimate=" %21.12f `b0' " se=" %21.12f `se0' " n_obs=" %12.0f `n'
display "ANSWER: x1 estimate=" %21.12f `b1' " se=" %21.12f `se1' " n_obs=" %12.0f `n'
display "ANSWER: x2 estimate=" %21.12f `b2' " se=" %21.12f `se2' " n_obs=" %12.0f `n'
