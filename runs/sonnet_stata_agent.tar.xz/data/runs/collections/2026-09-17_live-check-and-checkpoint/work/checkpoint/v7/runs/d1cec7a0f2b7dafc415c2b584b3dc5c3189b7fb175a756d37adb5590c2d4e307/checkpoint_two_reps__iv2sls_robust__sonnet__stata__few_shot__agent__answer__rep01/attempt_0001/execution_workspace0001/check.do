set linesize 255
clear
import delimited "./input.csv", varnames(1)

* Manual 2SLS verification
* First stage: regress x1_iv on z and constant
reg x1_iv z
predict x1iv_hat, xb

* Second stage: regress y_iv on x1iv_hat
reg y_iv x1iv_hat

display "Manual 2SLS coef on x1_iv: " _b[x1iv_hat]
display "Manual 2SLS const: " _b[_cons]

* Also verify with ivreg2 if available
capture which ivreg2
if _rc == 0 {
    ivreg2 y_iv (x1_iv = z), robust small
}
