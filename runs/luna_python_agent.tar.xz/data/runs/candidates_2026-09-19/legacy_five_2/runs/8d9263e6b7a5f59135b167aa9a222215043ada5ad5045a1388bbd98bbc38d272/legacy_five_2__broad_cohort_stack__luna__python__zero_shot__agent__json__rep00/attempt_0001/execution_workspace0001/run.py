import csv
import json
import numpy as np


def read_data(path):
    with open(path, newline="") as f:
        return [{k: (int(v) if k in ("id", "time", "g") else float(v))
                 for k, v in row.items()} for row in csv.DictReader(f)]


def cohort_estimate(rows, c):
    times = list(range(c - 2, c + 3))
    eligible = {r["id"] for r in rows if r["g"] == c or r["g"] == 0 or r["g"] > c + 2}
    present = {i: {r["time"] for r in rows if r["id"] == i} for i in eligible}
    units = sorted(i for i in eligible if all(t in present[i] for t in times))
    sample = [r for r in rows if r["id"] in units and r["time"] in times]
    did = np.array([float(r["g"] == c and r["time"] >= c) for r in sample])
    y = np.array([r["y"] for r in sample])
    ids = sorted({r["id"] for r in sample})
    ts = sorted({r["time"] for r in sample})
    X = np.column_stack([np.ones(len(sample)), did] + [np.array([r["id"] == i for r in sample], float) for i in ids[1:]]
                         + [np.array([r["time"] == t for r in sample], float) for t in ts[1:]])
    beta = np.linalg.lstsq(X, y, rcond=None)[0][1]
    # Independent check: double demeaning is exact for this balanced panel.
    mat_d = np.array([[did[next(k for k, r in enumerate(sample) if r["id"] == i and r["time"] == t)] for t in ts] for i in ids])
    mat_y = np.array([[y[next(k for k, r in enumerate(sample) if r["id"] == i and r["time"] == t)] for t in ts] for i in ids])
    dd = mat_d - mat_d.mean(1, keepdims=True) - mat_d.mean(0, keepdims=True) + mat_d.mean()
    yy = mat_y - mat_y.mean(1, keepdims=True) - mat_y.mean(0, keepdims=True) + mat_y.mean()
    check = float((dd * yy).sum() / (dd * dd).sum())
    treated_units = sum(r["g"] == c for r in (next(r for r in rows if r["id"] == i) for i in units))
    return float(beta), len(sample), treated_units, check, len(units)


def main():
    rows = read_data("input.csv")
    out = []
    checks = []
    weighted_num = weighted_den = total_n = 0
    for c in (3, 5, 7):
        est, n, nt, check, nu = cohort_estimate(rows, c)
        out.append({"term": f"att_g{c}", "estimate": f"{est:.12g}", "se": None, "n_obs": n})
        checks.append((c, est, check, n, nu, nt))
        weighted_num += est * nt
        weighted_den += nt
        total_n += n
    weighted = weighted_num / weighted_den
    out.append({"term": "att_weighted", "estimate": f"{weighted:.12g}", "se": None, "n_obs": total_n})
    with open("result.json", "w") as f:
        json.dump({"task_id": "broad_cohort_stack", "platform": "python", "estimates": out,
                   "method_metadata": {}, "diagnostics": {}}, f, indent=2)
    with open("verification.txt", "w") as f:
        f.write("Checks: each cohort retained only eligible units observed at all five window times.\n")
        for c, est, check, n, nu, nt in checks:
            f.write(f"g={c}: units={nu}, treated_units={nt}, n_obs={n}, OLS={est:.15g}, double_demean={check:.15g}, difference={est-check:.3g}\n")
        f.write(f"Weighted estimate uses treated-unit weights: numerator/denominator = {weighted_num:.15g}/{weighted_den}; n_obs sum={total_n}.\n")


if __name__ == "__main__":
    main()
