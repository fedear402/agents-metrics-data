import csv
import json
from collections import defaultdict
import numpy as np


def read_data(path):
    rows = []
    with open(path, newline="") as f:
        for r in csv.DictReader(f):
            rows.append({"id": int(r["id"]), "time": int(r["time"]),
                         "g": int(r["g"]), "y": float(r["y"])})
    return rows


def ols_did(rows, cohort):
    window = list(range(cohort - 2, cohort + 3))
    by_id = defaultdict(dict)
    for r in rows:
        if r["time"] in window and (r["g"] == cohort or r["g"] == 0 or r["g"] > cohort + 2):
            by_id[r["id"]][r["time"]] = r
    kept = [unit for unit, obs in by_id.items() if all(t in obs for t in window)]
    sample = [by_id[i][t] for i in sorted(kept) for t in window]

    ids = sorted(kept)
    id_index = {v: i for i, v in enumerate(ids)}
    # Intercept, did, unit fixed effects excluding the first unit, time fixed effects excluding first time.
    X = []
    y = []
    for r in sample:
        row = [1.0, float(r["g"] == cohort and r["time"] >= cohort)]
        row += [float(r["id"] == u) for u in ids[1:]]
        row += [float(r["time"] == t) for t in window[1:]]
        X.append(row)
        y.append(r["y"])
    beta = np.linalg.lstsq(np.asarray(X), np.asarray(y), rcond=None)[0]
    treated_units = sum(by_id[i][window[0]]["g"] == cohort for i in kept)
    return float(beta[1]), len(sample), treated_units, len(kept), sample


def main():
    rows = read_data("input.csv")
    results = []
    checks = []
    estimates = {}
    for c in (3, 5, 7):
        est, n_obs, n_treated, n_units, sample = ols_did(rows, c)
        estimates[c] = est
        results.append({"term": f"att_g{c}", "estimate": f"{est:.12g}", "se": None, "n_obs": n_obs})
        # Independent check: residualize did and y by unit and time effects, then use covariance/variance.
        window = list(range(c - 2, c + 3))
        y = np.array([r["y"] for r in sample])
        d = np.array([float(r["g"] == c and r["time"] >= c) for r in sample])
        unit_vals = [r["id"] for r in sample]
        time_vals = [r["time"] for r in sample]
        def twoway_resid(v):
            overall = v.mean()
            out = np.empty_like(v)
            for i, r in enumerate(sample):
                um = v[np.array(unit_vals) == r["id"]].mean()
                tm = v[np.array(time_vals) == r["time"]].mean()
                out[i] = v[i] - um - tm + overall
            return out
        yd, dd = twoway_resid(y), twoway_resid(d)
        check_est = float(np.dot(dd, yd) / np.dot(dd, dd))
        checks.append((c, n_obs, n_treated, n_units, check_est, abs(est - check_est)))
    weighted = sum(estimates[c] * ols_did(rows, c)[2] for c in (3, 5, 7)) / sum(ols_did(rows, c)[2] for c in (3, 5, 7))
    results.append({"term": "att_weighted", "estimate": f"{weighted:.12g}", "se": None,
                    "n_obs": sum(ols_did(rows, c)[1] for c in (3, 5, 7))})
    with open("result.json", "w") as f:
        json.dump({"task_id": "broad_cohort_stack", "platform": "python", "estimates": results,
                   "method_metadata": {}, "diagnostics": {}}, f, indent=2)
    with open("verification.txt", "w") as f:
        f.write("Verification checks\n")
        f.write("Each cohort retained complete five-period panels after eligibility filtering.\n")
        for c, n, nt, nu, ce, diff in checks:
            f.write(f"g={c}: units={nu}, treated_units={nt}, rows={n}, OLS={estimates[c]:.15g}, two-way residual check={ce:.15g}, absolute difference={diff:.3g}\n")
        f.write(f"Weighted estimate uses treated-unit weights {sum(x[2] for x in checks)} and row count {sum(x[1] for x in checks)}.\n")


if __name__ == "__main__":
    main()
