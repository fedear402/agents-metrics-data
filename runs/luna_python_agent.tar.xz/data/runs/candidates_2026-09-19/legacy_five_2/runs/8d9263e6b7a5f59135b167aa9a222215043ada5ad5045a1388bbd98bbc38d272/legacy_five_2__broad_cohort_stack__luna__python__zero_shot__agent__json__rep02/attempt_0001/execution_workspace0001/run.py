import csv
import json
from collections import defaultdict
import numpy as np

with open("input.csv", newline="") as f:
    rows = [{k: float(v) for k, v in r.items()} for r in csv.DictReader(f)]

def cohort_fit(c):
    lo, hi = c - 2, c + 2
    eligible = [r for r in rows if r["g"] in (0, c) or r["g"] > hi]
    by_id = defaultdict(list)
    for r in eligible:
        if lo <= r["time"] <= hi:
            by_id[r["id"]].append(r)
    keep_ids = {i for i, rr in by_id.items() if len({r["time"] for r in rr}) == 5}
    sample = [r for r in eligible if r["id"] in keep_ids and lo <= r["time"] <= hi]
    # OLS with a constant, unit FE, time FE, and did.
    ids = sorted(keep_ids)
    ts = list(range(lo, hi + 1))
    id0, t0 = ids[0], ts[0]
    X = []
    y = []
    for r in sample:
        unit_d = [float(r["id"] == i) for i in ids[1:]]
        time_d = [float(r["time"] == t) for t in ts[1:]]
        did = float(r["g"] == c and r["time"] >= c)
        X.append([1.0, *unit_d, *time_d, did])
        y.append(r["y"])
    beta = np.linalg.lstsq(np.asarray(X), np.asarray(y), rcond=None)[0]
    treated_n = sum(1 for i in ids if any(r["id"] == i and r["g"] == c for r in sample))
    # Independent FWL check: residualize y and did on the same FE design.
    Z = np.asarray([x[:-1] for x in X])
    yy, dd = np.asarray(y), np.asarray([x[-1] for x in X])
    ry = yy - Z @ np.linalg.lstsq(Z, yy, rcond=None)[0]
    rd = dd - Z @ np.linalg.lstsq(Z, dd, rcond=None)[0]
    fwl = float(rd @ ry / (rd @ rd))
    return float(beta[-1]), len(sample), treated_n, fwl, len(ids)

fits = {c: cohort_fit(c) for c in (3, 5, 7)}
weights = np.array([fits[c][2] for c in (3, 5, 7)], dtype=float)
atts = np.array([fits[c][0] for c in (3, 5, 7)])
weighted = float(weights @ atts / weights.sum())
estimates = []
for c in (3, 5, 7):
    estimates.append({"term": f"att_g{c}", "estimate": f"{fits[c][0]:.12g}", "se": None, "n_obs": fits[c][1]})
estimates.append({"term": "att_weighted", "estimate": f"{weighted:.12g}", "se": None,
                  "n_obs": sum(fits[c][1] for c in (3, 5, 7))})
with open("result.json", "w") as f:
    json.dump({"task_id": "broad_cohort_stack", "platform": "python", "estimates": estimates,
               "method_metadata": {}, "diagnostics": {}}, f, indent=2)

with open("verification.txt", "w") as f:
    f.write("Verification checks\n")
    for c in (3, 5, 7):
        b, n, tn, fwl, nu = fits[c]
        f.write(f"g={c}: retained units={nu}, treated units={tn}, rows={n}, "
                f"FE OLS={b:.15g}, FWL={fwl:.15g}, abs_diff={abs(b-fwl):.3e}\n")
    f.write(f"weighted estimate={weighted:.15g}; weighted n_obs={sum(fits[c][1] for c in (3,5,7))}\n")
