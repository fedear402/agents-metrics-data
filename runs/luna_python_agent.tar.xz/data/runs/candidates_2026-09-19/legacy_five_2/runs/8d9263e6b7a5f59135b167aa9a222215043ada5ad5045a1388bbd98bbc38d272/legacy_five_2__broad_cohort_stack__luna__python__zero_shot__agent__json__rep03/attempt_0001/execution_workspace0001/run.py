import csv
import json
from collections import defaultdict

import numpy as np


def read_data(path):
    rows = []
    with open(path, newline="") as f:
        for r in csv.DictReader(f):
            rows.append({"id": int(r["id"]), "time": int(r["time"]),
                         "g": int(r["g"]), "y": float(r["y"])})
    return rows


def cohort_estimate(rows, c):
    times = list(range(c - 2, c + 3))
    eligible = [r for r in rows if r["g"] == c or r["g"] == 0 or r["g"] > c + 2]
    by_id = defaultdict(dict)
    for r in eligible:
        if r["time"] in times:
            by_id[r["id"]][r["time"]] = r
    keep_ids = [i for i, obs in by_id.items() if all(t in obs for t in times)]
    sample = [by_id[i][t] for i in sorted(keep_ids) for t in times]
    y = np.array([r["y"] for r in sample], dtype=float)
    did = np.array([float(r["g"] == c and r["time"] >= c) for r in sample])

    ids = sorted({r["id"] for r in sample})
    # Intercept, unit indicators excluding the first unit, time indicators excluding the first period.
    X = [np.ones(len(sample)), did]
    for i in ids[1:]:
        X.append(np.array([float(r["id"] == i) for r in sample]))
    for t in times[1:]:
        X.append(np.array([float(r["time"] == t) for r in sample]))
    beta = np.linalg.lstsq(np.column_stack(X), y, rcond=None)[0][1]
    treated_units = sum(1 for i in keep_ids if by_id[i][c]["g"] == c)
    return beta, len(sample), treated_units, sample


def main():
    rows = read_data("input.csv")
    estimates = []
    results = {}
    for c in (3, 5, 7):
        est, n_obs, n_treated, sample = cohort_estimate(rows, c)
        results[c] = (est, n_obs, n_treated, sample)
        estimates.append({"term": f"att_g{c}", "estimate": format(est, ".12g"),
                          "se": None, "n_obs": n_obs})
    weighted = sum(results[c][0] * results[c][2] for c in results) / sum(results[c][2] for c in results)
    estimates.append({"term": "att_weighted", "estimate": format(weighted, ".12g"),
                      "se": None, "n_obs": sum(results[c][1] for c in results)})
    with open("result.json", "w") as f:
        json.dump({"task_id": "broad_cohort_stack", "platform": "python",
                   "estimates": estimates, "method_metadata": {}, "diagnostics": {}}, f, indent=2)


if __name__ == "__main__":
    main()
