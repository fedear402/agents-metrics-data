import csv
import json
import numpy as np


def read_data(path):
    rows = []
    with open(path, newline="") as f:
        for r in csv.DictReader(f):
            rows.append((int(r["id"]), int(r["time"]), int(r["g"]), float(r["y"])))
    return rows


def cohort_estimate(rows, c):
    lo, hi = c - 2, c + 2
    eligible = {u for u, t, g, y in rows if (g == c or g == 0 or g > hi)}
    by_unit_time = {(u, t): (g, y) for u, t, g, y in rows}
    retained = [u for u in eligible if all((u, t) in by_unit_time for t in range(lo, hi + 1))]
    sample = []
    for u in sorted(retained):
        g = by_unit_time[(u, lo)][0]
        for t in range(lo, hi + 1):
            gt, y = by_unit_time[(u, t)]
            assert gt == g
            did = int(g == c and t >= c)
            sample.append((u, t, did, y, g))
    units = sorted(retained)
    times = list(range(lo, hi + 1))
    # OLS with unit and time fixed effects, omitting one dummy per effect.
    y = np.array([r[3] for r in sample])
    d = np.array([r[2] for r in sample], dtype=float)
    X = [np.ones(len(sample)), d]
    for u in units[1:]:
        X.append(np.array([r[0] == u for r in sample], dtype=float))
    for t in times[1:]:
        X.append(np.array([r[1] == t for r in sample], dtype=float))
    beta = np.linalg.lstsq(np.column_stack(X), y, rcond=None)[0][1]
    treated_units = sum(g == c for u, t, did, yv, g in sample) // 5
    return float(beta), len(sample), treated_units, sample


def main():
    rows = read_data("input.csv")
    results = []
    checks = {}
    for c in (3, 5, 7):
        est, n_obs, n_treated, sample = cohort_estimate(rows, c)
        results.append((c, est, n_obs, n_treated))
        checks[c] = (sample, est)
    weighted = sum(est * nt for c, est, n, nt in results) / sum(nt for c, est, n, nt in results)
    output = {
        "task_id": "broad_cohort_stack",
        "platform": "python",
        "estimates": [
            {"term": f"att_g{c}", "estimate": est, "se": None, "n_obs": n}
            for c, est, n, nt in results
        ] + [{"term": "att_weighted", "estimate": float(weighted), "se": None,
              "n_obs": sum(n for c, est, n, nt in results)}],
        "method_metadata": {},
        "diagnostics": {},
    }
    with open("result.json", "w") as f:
        json.dump(output, f, indent=2)

    # Independent check: two-way within transformation on the balanced panel.
    check_lines = []
    for c, est, n, nt in results:
        sample, direct = checks[c]
        yy = np.array([r[3] for r in sample])
        dd = np.array([r[2] for r in sample], dtype=float)
        units = sorted({r[0] for r in sample})
        times = sorted({r[1] for r in sample})
        ym = {u: np.mean([r[3] for r in sample if r[0] == u]) for u in units}
        dm = {u: np.mean([r[2] for r in sample if r[0] == u]) for u in units}
        yt = {t: np.mean([r[3] for r in sample if r[1] == t]) for t in times}
        dt = {t: np.mean([r[2] for r in sample if r[1] == t]) for t in times}
        ybar, dbar = yy.mean(), dd.mean()
        yr = np.array([r[3] - ym[r[0]] - yt[r[1]] + ybar for r in sample])
        dr = np.array([r[2] - dm[r[0]] - dt[r[1]] + dbar for r in sample])
        independent = float(dr @ yr / (dr @ dr))
        if abs(independent - direct) >= 1e-10:
            raise AssertionError((c, direct, independent, independent - direct))
        check_lines.append(f"g={c}: rows={n}, treated_units={nt}, direct={direct:.12f}, within={independent:.12f}")
    check_lines.append(f"weighted={weighted:.12f}; weight denominator={sum(nt for c, est, n, nt in results)}")
    with open("verification.txt", "w") as f:
        f.write("Independent check used the two-way within transformation on each balanced five-period panel.\n")
        f.write("The transformed-regressor covariance/variance estimate matched dummy-variable OLS within 1e-10.\n")
        f.write("\n".join(check_lines) + "\n")


if __name__ == "__main__":
    main()
