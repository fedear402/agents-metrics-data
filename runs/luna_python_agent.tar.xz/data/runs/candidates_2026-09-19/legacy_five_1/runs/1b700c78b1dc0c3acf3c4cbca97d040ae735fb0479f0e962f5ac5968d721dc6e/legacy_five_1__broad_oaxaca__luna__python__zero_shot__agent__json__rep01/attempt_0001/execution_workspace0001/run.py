import csv
import json

import numpy as np


def main():
    with open("input.csv", newline="") as f:
        rows = list(csv.DictReader(f))

    y = np.array([float(r["y"]) for r in rows])
    x = np.array([float(r["x"]) for r in rows])
    z = np.array([float(r["z"]) for r in rows])
    group = np.array([int(r["group"]) for r in rows])
    n_obs = len(rows)

    def fit(g):
        mask = group == g
        design = np.column_stack((np.ones(mask.sum()), x[mask], z[mask]))
        return np.linalg.lstsq(design, y[mask], rcond=None)[0], mask

    beta_0, mask_0 = fit(0)
    beta_1, mask_1 = fit(1)
    xbar_0 = np.array([1.0, x[mask_0].mean(), z[mask_0].mean()])
    xbar_1 = np.array([1.0, x[mask_1].mean(), z[mask_1].mean()])

    gap = y[mask_1].mean() - y[mask_0].mean()
    explained = (xbar_1 - xbar_0) @ beta_0
    unexplained = xbar_1 @ (beta_1 - beta_0)
    explained_x = (xbar_1[1] - xbar_0[1]) * beta_0[1]

    result = {
        "task_id": "broad_oaxaca",
        "platform": "python",
        "estimates": [
            {"term": "gap", "estimate": float(gap), "se": None, "n_obs": n_obs},
            {"term": "explained", "estimate": float(explained), "se": None, "n_obs": n_obs},
            {"term": "unexplained", "estimate": float(unexplained), "se": None, "n_obs": n_obs},
            {"term": "explained_x", "estimate": float(explained_x), "se": None, "n_obs": n_obs},
        ],
        "method_metadata": {},
        "diagnostics": {},
    }
    with open("result.json", "w") as f:
        json.dump(result, f, indent=2)


if __name__ == "__main__":
    main()
