import csv
import json
from pathlib import Path

import numpy as np


def read_data(path):
    with path.open(newline="") as f:
        rows = list(csv.DictReader(f))
    required = {"id", "y", "x", "z", "group"}
    if set(rows[0]) != required:
        raise ValueError(f"Unexpected columns: {list(rows[0])}")
    data = {name: np.array([float(row[name]) for row in rows]) for name in required}
    data["group"] = data["group"].astype(int)
    return data


def ols_by_group(data, group):
    mask = data["group"] == group
    X = np.column_stack((np.ones(mask.sum()), data["x"][mask], data["z"][mask]))
    beta, _, rank, _ = np.linalg.lstsq(X, data["y"][mask], rcond=None)
    if rank != X.shape[1]:
        raise ValueError("Regressor matrix is not full rank")
    return beta, mask


def main():
    data = read_data(Path("input.csv"))
    beta0, mask0 = ols_by_group(data, 0)
    beta1, mask1 = ols_by_group(data, 1)
    means0 = np.array([1.0, data["x"][mask0].mean(), data["z"][mask0].mean()])
    means1 = np.array([1.0, data["x"][mask1].mean(), data["z"][mask1].mean()])
    gap = data["y"][mask1].mean() - data["y"][mask0].mean()
    explained = (means1 - means0) @ beta0
    unexplained = means1 @ (beta1 - beta0)
    explained_x = (means1[1] - means0[1]) * beta0[1]
    n_obs = len(data["y"])
    result = {
        "task_id": "broad_oaxaca",
        "platform": "python",
        "estimates": [
            {"term": "gap", "estimate": float(gap), "se": None, "n_obs": n_obs},
            {"term": "explained", "estimate": float(explained), "se": None, "n_obs": n_obs},
            {"term": "unexplained", "estimate": float(unexplained), "se": None, "n_obs": n_obs},
            {"term": "explained_x", "estimate": float(explained_x), "se": None, "n_obs": n_obs},
        ],
        "method_metadata": {},
        "diagnostics": {},
    }
    with Path("result.json").open("w") as f:
        json.dump(result, f, indent=2)


if __name__ == "__main__":
    main()
