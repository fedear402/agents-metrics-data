import csv
import json
import numpy as np


def read_data(path):
    with open(path, newline="") as f:
        rows = list(csv.DictReader(f))
    return rows


rows = read_data("input.csv")
y = np.array([float(r["y"]) for r in rows], dtype=float)
x = np.array([float(r["x"]) for r in rows], dtype=float)
z = np.array([float(r["z"]) for r in rows], dtype=float)
group = np.array([int(r["group"]) for r in rows], dtype=int)

if len(rows) != 360 or set(group) != {0, 1}:
    raise ValueError("Unexpected estimation sample")

def ols(mask):
    design = np.column_stack((np.ones(mask.sum()), x[mask], z[mask]))
    return np.linalg.lstsq(design, y[mask], rcond=None)[0]


mask0 = group == 0
mask1 = group == 1
beta0 = ols(mask0)
beta1 = ols(mask1)
means0 = np.array([1.0, x[mask0].mean(), z[mask0].mean()])
means1 = np.array([1.0, x[mask1].mean(), z[mask1].mean()])
gap = y[mask1].mean() - y[mask0].mean()
explained = (means1 - means0) @ beta0
unexplained = means1 @ (beta1 - beta0)
explained_x = (means1[1] - means0[1]) * beta0[1]

def estimate(term, value):
    return {"term": term, "estimate": format(float(value), ".15g"),
            "se": None, "n_obs": int(len(rows))}

result = {
    "task_id": "broad_oaxaca",
    "platform": "python",
    "estimates": [
        estimate("gap", gap),
        estimate("explained", explained),
        estimate("unexplained", unexplained),
        estimate("explained_x", explained_x),
    ],
    "method_metadata": {},
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)

