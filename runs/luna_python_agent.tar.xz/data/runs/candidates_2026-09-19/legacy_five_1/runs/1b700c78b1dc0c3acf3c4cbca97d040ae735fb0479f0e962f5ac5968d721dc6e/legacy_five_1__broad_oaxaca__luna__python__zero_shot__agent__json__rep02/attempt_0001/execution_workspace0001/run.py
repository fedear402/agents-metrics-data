import csv
import json
import numpy as np


def read_data(path):
    with open(path, newline="") as f:
        rows = list(csv.DictReader(f))
    return rows


def fit_group(rows):
    y = np.array([float(r["y"]) for r in rows], dtype=float)
    X = np.array([[1.0, float(r["x"]), float(r["z"])] for r in rows], dtype=float)
    return np.linalg.lstsq(X, y, rcond=None)[0]


rows = read_data("input.csv")
g0 = [r for r in rows if int(r["group"]) == 0]
g1 = [r for r in rows if int(r["group"]) == 1]

beta0 = fit_group(g0)
beta1 = fit_group(g1)
xbar0 = np.array([1.0, np.mean([float(r["x"]) for r in g0]), np.mean([float(r["z"]) for r in g0])])
xbar1 = np.array([1.0, np.mean([float(r["x"]) for r in g1]), np.mean([float(r["z"]) for r in g1])])

gap = np.mean([float(r["y"]) for r in g1]) - np.mean([float(r["y"]) for r in g0])
explained = float((xbar1 - xbar0) @ beta0)
unexplained = float(xbar1 @ (beta1 - beta0))
explained_x = float((xbar1[1] - xbar0[1]) * beta0[1])
n_obs = len(rows)

result = {
    "task_id": "broad_oaxaca",
    "platform": "python",
    "estimates": [
        {"term": "gap", "estimate": float(gap), "se": None, "n_obs": n_obs},
        {"term": "explained", "estimate": explained, "se": None, "n_obs": n_obs},
        {"term": "unexplained", "estimate": unexplained, "se": None, "n_obs": n_obs},
        {"term": "explained_x", "estimate": explained_x, "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {},
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
