import csv
import json
import numpy as np


def main():
    with open("input.csv", newline="") as stream:
        rows = list(csv.DictReader(stream))

    y = np.array([float(row["y"]) for row in rows], dtype=float)
    x = np.array([float(row["x"]) for row in rows], dtype=float)
    z = np.array([float(row["z"]) for row in rows], dtype=float)
    group = np.array([int(row["group"]) for row in rows], dtype=int)
    estimates = {}
    means = {}

    for g in (0, 1):
        mask = group == g
        X = np.column_stack((np.ones(mask.sum()), x[mask], z[mask]))
        beta = np.linalg.lstsq(X, y[mask], rcond=None)[0]
        means[g] = np.array([1.0, x[mask].mean(), z[mask].mean()])
        estimates[g] = beta

    beta0, beta1 = estimates[0], estimates[1]
    Xbar0, Xbar1 = means[0], means[1]
    gap = y[group == 1].mean() - y[group == 0].mean()
    explained = (Xbar1 - Xbar0) @ beta0
    unexplained = Xbar1 @ (beta1 - beta0)
    explained_x = (Xbar1[1] - Xbar0[1]) * beta0[1]
    n_obs = len(y)

    output = {
        "task_id": "broad_oaxaca",
        "platform": "python",
        "estimates": [
            {"term": "gap", "estimate": float(gap), "se": None, "n_obs": n_obs},
            {"term": "explained", "estimate": float(explained), "se": None, "n_obs": n_obs},
            {"term": "unexplained", "estimate": float(unexplained), "se": None, "n_obs": n_obs},
            {"term": "explained_x", "estimate": float(explained_x), "se": None, "n_obs": n_obs},
        ],
        "method_metadata": {},
        "diagnostics": {},
    }
    with open("result.json", "w") as stream:
        json.dump(output, stream, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
