import csv
import json

import numpy as np


def main():
    with open("input.csv", newline="") as stream:
        rows = list(csv.DictReader(stream))

    y = np.array([float(row["y"]) for row in rows])
    x = np.array([float(row["x"]) for row in rows])
    z = np.array([float(row["z"]) for row in rows])
    group = np.array([int(row["group"]) for row in rows])

    estimates = {}
    means = {}
    coefficients = {}
    for g in (0, 1):
        mask = group == g
        X = np.column_stack((np.ones(mask.sum()), x[mask], z[mask]))
        coefficients[g] = np.linalg.lstsq(X, y[mask], rcond=None)[0]
        means[g] = np.array([1.0, x[mask].mean(), z[mask].mean()])

    gap = y[group == 1].mean() - y[group == 0].mean()
    explained = (means[1] - means[0]) @ coefficients[0]
    unexplained = means[1] @ (coefficients[1] - coefficients[0])
    explained_x = (means[1][1] - means[0][1]) * coefficients[0][1]

    values = [
        ("gap", gap),
        ("explained", explained),
        ("unexplained", unexplained),
        ("explained_x", explained_x),
    ]
    output = {
        "task_id": "broad_oaxaca",
        "platform": "python",
        "estimates": [
            {"term": term, "estimate": float(value), "se": None, "n_obs": len(rows)}
            for term, value in values
        ],
        "method_metadata": {},
        "diagnostics": {},
    }
    with open("result.json", "w") as stream:
        json.dump(output, stream, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
