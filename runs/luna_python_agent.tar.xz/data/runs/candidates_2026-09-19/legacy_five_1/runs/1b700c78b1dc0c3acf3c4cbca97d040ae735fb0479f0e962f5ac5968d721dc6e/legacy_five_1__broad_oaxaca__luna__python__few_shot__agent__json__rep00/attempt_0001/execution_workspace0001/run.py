import csv
import json
import numpy as np


def read_data(path):
    with open(path, newline="") as stream:
        rows = list(csv.DictReader(stream))
    y = np.array([float(row["y"]) for row in rows])
    x = np.array([float(row["x"]) for row in rows])
    z = np.array([float(row["z"]) for row in rows])
    group = np.array([int(row["group"]) for row in rows])
    return y, x, z, group


def main():
    y, x, z, group = read_data("input.csv")
    design = np.column_stack((np.ones(len(y)), x, z))
    means = {}
    coefficients = {}
    for g in (0, 1):
        mask = group == g
        means[g] = design[mask].mean(axis=0)
        coefficients[g] = np.linalg.lstsq(design[mask], y[mask], rcond=None)[0]

    gap = y[group == 1].mean() - y[group == 0].mean()
    explained = (means[1] - means[0]) @ coefficients[0]
    unexplained = means[1] @ (coefficients[1] - coefficients[0])
    explained_x = (x[group == 1].mean() - x[group == 0].mean()) * coefficients[0][1]
    n_obs = len(y)
    estimates = [
        ("gap", gap),
        ("explained", explained),
        ("unexplained", unexplained),
        ("explained_x", explained_x),
    ]
    output = {
        "task_id": "broad_oaxaca",
        "platform": "python",
        "estimates": [
            {"term": term, "estimate": float(value), "se": None, "n_obs": n_obs}
            for term, value in estimates
        ],
        "method_metadata": {},
        "diagnostics": {},
    }
    with open("result.json", "w") as stream:
        json.dump(output, stream, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
