import csv
import json
import numpy as np


def main():
    with open("input.csv", newline="") as f:
        rows = list(csv.DictReader(f))

    y = np.array([float(r["y"]) for r in rows], dtype=float)
    x = np.array([float(r["x"]) for r in rows], dtype=float)
    z = np.array([float(r["z"]) for r in rows], dtype=float)
    group = np.array([int(r["group"]) for r in rows], dtype=int)
    n_obs = len(rows)

    design = np.column_stack((np.ones(n_obs), x, z))
    means = {}
    beta = {}
    for g in (0, 1):
        mask = group == g
        means[g] = design[mask].mean(axis=0)
        beta[g] = np.linalg.lstsq(design[mask], y[mask], rcond=None)[0]

    gap = y[group == 1].mean() - y[group == 0].mean()
    explained = (means[1] - means[0]) @ beta[0]
    unexplained = means[1] @ (beta[1] - beta[0])
    explained_x = (x[group == 1].mean() - x[group == 0].mean()) * beta[0][1]

    result = {
        "task_id": "broad_oaxaca",
        "platform": "python",
        "estimates": [
            {"term": "gap", "estimate": format(gap, ".17g"), "se": None, "n_obs": n_obs},
            {"term": "explained", "estimate": format(explained, ".17g"), "se": None, "n_obs": n_obs},
            {"term": "unexplained", "estimate": format(unexplained, ".17g"), "se": None, "n_obs": n_obs},
            {"term": "explained_x", "estimate": format(explained_x, ".17g"), "se": None, "n_obs": n_obs},
        ],
        "method_metadata": {},
        "diagnostics": {},
    }
    with open("result.json", "w") as f:
        json.dump(result, f, indent=2)


if __name__ == "__main__":
    main()
