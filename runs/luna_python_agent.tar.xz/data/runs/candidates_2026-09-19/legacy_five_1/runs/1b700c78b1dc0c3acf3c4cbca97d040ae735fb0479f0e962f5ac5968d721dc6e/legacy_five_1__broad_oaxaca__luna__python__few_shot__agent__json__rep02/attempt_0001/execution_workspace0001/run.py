import csv
import json

import numpy as np


def main():
    rows = []
    with open("input.csv", newline="") as stream:
        rows.extend(csv.DictReader(stream))

    y = np.array([float(row["y"]) for row in rows], dtype=float)
    x = np.array([float(row["x"]) for row in rows], dtype=float)
    z = np.array([float(row["z"]) for row in rows], dtype=float)
    group = np.array([int(row["group"]) for row in rows], dtype=int)

    means = {}
    coefficients = {}
    for g in (0, 1):
        mask = group == g
        X = np.column_stack((np.ones(mask.sum()), x[mask], z[mask]))
        coefficients[g] = np.linalg.lstsq(X, y[mask], rcond=None)[0]
        means[g] = np.array([1.0, x[mask].mean(), z[mask].mean()])

    gap = y[group == 1].mean() - y[group == 0].mean()
    explained = (means[1] - means[0]) @ coefficients[0]
    unexplained = means[1] @ (coefficients[1] - coefficients[0])
    explained_x = (means[1][1] - means[0][1]) * coefficients[0][1]
    n_obs = len(y)

    estimates = [
        {"term": "gap", "estimate": float(gap), "se": None, "n_obs": n_obs},
        {"term": "explained", "estimate": float(explained), "se": None, "n_obs": n_obs},
        {"term": "unexplained", "estimate": float(unexplained), "se": None, "n_obs": n_obs},
        {"term": "explained_x", "estimate": float(explained_x), "se": None, "n_obs": n_obs},
    ]
    output = {
        "task_id": "broad_oaxaca",
        "platform": "python",
        "estimates": estimates,
        "method_metadata": {},
        "diagnostics": {},
    }
    with open("result.json", "w") as stream:
        json.dump(output, stream, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
