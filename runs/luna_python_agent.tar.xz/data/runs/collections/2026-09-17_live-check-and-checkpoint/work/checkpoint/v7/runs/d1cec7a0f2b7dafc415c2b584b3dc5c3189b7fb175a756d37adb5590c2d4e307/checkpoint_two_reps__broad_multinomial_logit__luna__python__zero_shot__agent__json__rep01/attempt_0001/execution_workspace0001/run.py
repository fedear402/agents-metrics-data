import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy.optimize import minimize


def main():
    df = pd.read_csv("input.csv")
    required = {"id", "y", "x", "z"}
    if set(df.columns) != required:
        raise ValueError(f"Unexpected columns: {df.columns.tolist()}")
    n = len(df)
    if df[["y", "x", "z"]].isna().any().any():
        raise ValueError("Missing estimation values")
    if set(df["y"].unique()) != {0, 1, 2}:
        raise ValueError("Expected outcomes 0, 1, and 2")

    X = sm.add_constant(df[["x", "z"]], has_constant="add")
    model = sm.MNLogit(df["y"].astype(int), X)
    fit = model.fit(method="newton", disp=False, maxiter=200)

    # statsmodels uses outcome 0 as the reference and columns 1, 2 as alternatives.
    names = list(fit.params.index)
    if names != ["const", "x", "z"]:
        raise ValueError(f"Unexpected parameter order: {names}")
    p = fit.predict(np.array([[1.0, 0.0, 0.0]]))[0]
    params = fit.params.to_numpy()
    bse = fit.bse.to_numpy()
    estimates = [
        ("x_cat1", params[1, 0], bse[1, 0]),
        ("z_cat1", params[2, 0], bse[2, 0]),
        ("x_cat2", params[1, 1], bse[1, 1]),
        ("z_cat2", params[2, 1], bse[2, 1]),
        ("prob_cat2_zero", p[2], None),
    ]
    output = {
        "task_id": "broad_multinomial_logit",
        "platform": "python",
        "estimates": [
            {"term": term, "estimate": float(est), "se": None if se is None else float(se), "n_obs": n}
            for term, est, se in estimates
        ],
        "method_metadata": {"estimator": "multinomial logit maximum likelihood", "vcov": "conventional observed information"},
        "diagnostics": {},
    }
    with open("result.json", "w") as f:
        json.dump(output, f, indent=2)

    # Independent check: optimize the same log likelihood with scipy.
    y = df["y"].to_numpy(dtype=int)
    Xa = X.to_numpy(dtype=float)
    def negll(theta):
        B = theta.reshape(3, 2)
        eta = Xa @ B
        den = 1.0 + np.exp(eta).sum(axis=1)
        ll = np.where(y == 0, -np.log(den), eta[np.arange(n), y - 1] - np.log(den))
        return -ll.sum()
    def grad_negll(theta):
        B = theta.reshape(3, 2)
        eta = Xa @ B
        exp_eta = np.exp(eta)
        probs = exp_eta / (1.0 + exp_eta.sum(axis=1, keepdims=True))
        target = np.column_stack([(y == 1), (y == 2)]).astype(float)
        return (Xa.T @ (probs - target)).ravel()
    check = minimize(negll, params.ravel(), jac=grad_negll, method="BFGS", options={"gtol": 1e-9, "maxiter": 1000})
    scipy_params = check.x.reshape(3, 2)
    max_diff = float(np.max(np.abs(params - scipy_params)))
    # Mathematical identity check for the zero-covariate probability.
    e = np.exp(params[0, :])
    identity_p2 = float(e[1] / (1.0 + e.sum()))
    with open("verification.txt", "w") as f:
        f.write(f"Rows read: {n}; estimation rows: {n}; outcome counts: {df['y'].value_counts().sort_index().to_dict()}\n")
        f.write("Construction: y is the outcome, x and z enter with an intercept, and outcome 0 is the base.\n")
        f.write(f"Statsmodels converged: {fit.mle_retvals.get('converged', None)}; scipy objective check success: {check.success}; scipy gradient max: {np.max(np.abs(grad_negll(check.x))):.3e}\n")
        f.write(f"Maximum absolute coefficient difference, statsmodels versus independent scipy optimization: {max_diff:.3e}\n")
        f.write(f"P(y=2|x=0,z=0) identity check difference: {abs(p[2] - identity_p2):.3e}\n")
        f.write("Standard errors use the fitted model's conventional observed-information covariance.\n")


if __name__ == "__main__":
    main()
