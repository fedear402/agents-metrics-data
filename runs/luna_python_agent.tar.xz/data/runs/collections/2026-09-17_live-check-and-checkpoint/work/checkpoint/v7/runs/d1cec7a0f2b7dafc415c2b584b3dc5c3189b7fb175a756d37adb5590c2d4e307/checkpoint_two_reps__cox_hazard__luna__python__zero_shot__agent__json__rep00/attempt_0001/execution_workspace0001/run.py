import json
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from statsmodels.duration.hazard_regression import PHReg


def breslow_negloglik(beta, time, event, X):
    order = np.argsort(time)
    time, event, X = time[order], event[order], X[order]
    value = 0.0
    for i in np.flatnonzero(event == 1):
        risk = time >= time[i]
        value += -(X[i] @ beta) + np.log(np.exp(X[risk] @ beta).sum())
    return value


def main():
    data = pd.read_csv("input.csv")
    required = ["treat", "x", "t_obs", "event"]
    if data[required].isna().any().any():
        raise ValueError("Missing values in estimation variables")
    X = data[["treat", "x"]].to_numpy(dtype=float)
    time = data["t_obs"].to_numpy(dtype=float)
    event = data["event"].to_numpy(dtype=int)
    if not np.isin(event, [0, 1]).all() or (time <= 0).any():
        raise ValueError("Invalid survival data")

    fit = PHReg(time, X, status=event, ties="breslow").fit()
    beta = np.asarray(fit.params, dtype=float)
    se = np.asarray(fit.bse, dtype=float)

    # Independent numerical check: direct minimization of the Breslow objective.
    check = minimize(breslow_negloglik, np.zeros(2), args=(time, event, X), method="BFGS")
    if not np.allclose(beta, check.x, rtol=1e-5, atol=2e-6):
        raise RuntimeError(f"Independent Cox check failed: {check.message}; {check.x} vs {beta}")

    n = int(len(data))
    output = {
        "task_id": "cox_hazard",
        "platform": "python",
        "estimates": [
            {"term": name, "estimate": float(beta[i]), "se": float(se[i]), "n_obs": n}
            for i, name in enumerate(["treat", "x"])
        ],
        "method_metadata": {
            "estimator": "Cox proportional hazards partial likelihood (Breslow ties)",
            "vcov": "model-based inverse observed information",
        },
        "diagnostics": {},
    }
    with open("result.json", "w") as handle:
        json.dump(output, handle, indent=2)


if __name__ == "__main__":
    main()
