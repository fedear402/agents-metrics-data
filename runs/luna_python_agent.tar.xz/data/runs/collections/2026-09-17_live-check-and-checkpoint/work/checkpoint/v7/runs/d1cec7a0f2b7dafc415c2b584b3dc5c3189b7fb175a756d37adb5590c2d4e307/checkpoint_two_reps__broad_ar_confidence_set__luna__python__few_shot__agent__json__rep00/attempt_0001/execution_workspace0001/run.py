import json
import numpy as np
import pandas as pd
from scipy.stats import f
import statsmodels.api as sm

df = pd.read_csv("input.csv")
required = ["y", "endog", "x", "z1", "z2"]
if list(df.columns) != required:
    raise ValueError(f"Unexpected columns: {list(df.columns)}")
if df[required].isna().any().any():
    raise ValueError("Missing values are not permitted")

n = len(df)
y = df.y.to_numpy(float)
d = df.endog.to_numpy(float)
restricted = sm.add_constant(df[["x"]].to_numpy(float), has_constant="add")
unrestricted = sm.add_constant(df[["x", "z1", "z2"]].to_numpy(float), has_constant="add")
q = 2
den_df = n - unrestricted.shape[1]
critical = f.ppf(0.95, q, den_df)

def ssr(response, design):
    resid = response - design @ np.linalg.lstsq(design, response, rcond=None)[0]
    return float(resid @ resid)

# F(beta) <= critical is equivalent to A beta^2 + B beta + C <= 0.
ry = y - restricted @ np.linalg.lstsq(restricted, y, rcond=None)[0]
rd = d - restricted @ np.linalg.lstsq(restricted, d, rcond=None)[0]
uy = y - unrestricted @ np.linalg.lstsq(unrestricted, y, rcond=None)[0]
ud = d - unrestricted @ np.linalg.lstsq(unrestricted, d, rcond=None)[0]
k = q * critical / den_df
A = float(rd @ rd - (1 + k) * (ud @ ud))
B = float(-2 * (ry @ rd - (1 + k) * (uy @ ud)))
C = float(ry @ ry - (1 + k) * (uy @ uy))
disc = B * B - 4 * A * C
if A == 0 or disc <= 0:
    raise ValueError("Expected two finite boundary points")
roots = np.sort(np.roots([A, B, C]).real)

def ar_f(beta):
    response = y - beta * d
    sr = ssr(response, restricted)
    su = ssr(response, unrestricted)
    return ((sr - su) / q) / (su / den_df)

def accepts(beta):
    return A * beta * beta + B * beta + C <= 0

rows = [
    {"term": "boundary_low", "estimate": float(roots[0]), "se": None, "n_obs": n},
    {"term": "boundary_high", "estimate": float(roots[1]), "se": None, "n_obs": n},
    {"term": "accepts_zero", "estimate": int(accepts(0.0)), "se": None, "n_obs": n},
    {"term": "unbounded", "estimate": int(A < 0), "se": None, "n_obs": n},
    {"term": "ar_f_at_one", "estimate": float(ar_f(1.0)), "se": None, "n_obs": n},
]
out = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": rows,
    "method_metadata": {"estimator": "Anderson-Rubin inverted homoskedastic joint F test", "vcov": "homoskedastic"},
    "diagnostics": {},
}
with open("result.json", "w") as stream:
    json.dump(out, stream, indent=2, allow_nan=False)
