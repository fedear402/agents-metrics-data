import json
import numpy as np
import pandas as pd


def main():
    df = pd.read_csv("input.csv")
    needed = ["y_iv", "x1_iv", "z"]
    sample = df[needed].dropna()
    y = sample["y_iv"].to_numpy(dtype=float)
    x = sample["x1_iv"].to_numpy(dtype=float)
    z_excluded = sample["z"].to_numpy(dtype=float)
    n = len(sample)
    X = np.column_stack((np.ones(n), x))
    Z = np.column_stack((np.ones(n), z_excluded))
    # 2SLS: project the structural regressors onto the instrument space.
    ztz_inv = np.linalg.inv(Z.T @ Z)
    PzX = Z @ ztz_inv @ (Z.T @ X)
    beta = np.linalg.solve(X.T @ PzX, X.T @ (Z @ ztz_inv @ (Z.T @ y)))
    u = y - X @ beta
    # Heteroskedastic 2SLS sandwich, with HC1 finite-sample scaling.
    bread = np.linalg.inv(X.T @ PzX)
    middle = X.T @ Z @ ztz_inv @ (Z.T * (u * u)) @ Z @ ztz_inv @ Z.T @ X
    cov = (n / (n - X.shape[1])) * bread @ middle @ bread
    se = np.sqrt(np.diag(cov))
    estimates = []
    for term, b, s in zip(("const", "x1_iv"), beta, se):
        estimates.append({"term": term, "estimate": float(b), "se": float(s), "n_obs": int(n)})
    result = {
        "task_id": "iv2sls_robust",
        "platform": "python",
        "estimates": estimates,
        "method_metadata": {"estimator": "two-stage least squares (2SLS)", "vcov": "HC1 heteroskedastic 2SLS sandwich"},
        "diagnostics": {},
    }
    with open("result.json", "w") as f:
        json.dump(result, f, indent=2)


if __name__ == "__main__":
    main()
