import json
import pandas as pd
from statsmodels.tsa.arima.model import ARIMA


def main():
    data = pd.read_csv("input.csv")
    if list(data.columns) != ["t", "y"]:
        raise ValueError("input.csv must contain columns t and y")
    if len(data) != 250 or not data["t"].equals(pd.Series(range(1, 251), name="t")):
        raise ValueError("Expected t to contain 1,...,250")
    y = data["y"].astype(float)

    model = ARIMA(y, order=(1, 1, 1), trend="n")
    fitted = model.fit()
    pred = fitted.get_forecast(steps=1)
    forecast = float(pred.predicted_mean.iloc[0])
    interval = pred.conf_int(alpha=0.05).iloc[0]
    lower = float(interval.iloc[0])
    upper = float(interval.iloc[1])
    result = {
        "task_id": "arima_forecast",
        "platform": "python",
        "estimates": [
            {"term": "forecast", "estimate": forecast, "se": None, "n_obs": len(y)},
            {"term": "lower_95", "estimate": lower, "se": None, "n_obs": len(y)},
            {"term": "upper_95", "estimate": upper, "se": None, "n_obs": len(y)},
        ],
        "method_metadata": {
            "estimator": "Gaussian maximum-likelihood ARIMA(1,1,1), no constant or drift",
            "vcov": "model-based Gaussian prediction variance",
        },
        "diagnostics": {},
    }
    with open("result.json", "w", encoding="utf-8") as handle:
        json.dump(result, handle, indent=2)


if __name__ == "__main__":
    main()
