import json

import numpy as np
import pandas as pd


def main():
    data = pd.read_csv("input.csv").sort_values("time").reset_index(drop=True)
    expected_time = np.arange(1, 251)
    if not np.array_equal(data["time"].to_numpy(), expected_time):
        raise ValueError("time must contain the ordered labels 1 through 250")

    y = data["y"].to_numpy(dtype=float)
    forecasts = {}
    errors = []
    for f in range(101, 251):
        # Labels f-100 through f-1 provide exactly 100 observed levels.
        levels = y[f - 101 : f - 1]
        lagged = levels[:-1]
        current = levels[1:]
        if len(levels) != 100 or len(current) != 99:
            raise ValueError("incorrect rolling estimation sample")
        X = np.column_stack((np.ones(99), lagged))
        a_hat, b_hat = np.linalg.lstsq(X, current, rcond=None)[0]
        forecast = float(a_hat + b_hat * levels[-1])
        forecasts[f] = forecast
        errors.append(y[f - 1] - forecast)

    rmse = float(np.sqrt(np.mean(np.square(errors))))
    requested = [101, 150, 200, 250]
    estimates = [
        {"term": "rmse", "estimate": rmse, "se": None, "n_obs": 150}
    ]
    estimates.extend(
        {"term": f"forecast_{f}", "estimate": forecasts[f], "se": None, "n_obs": 99}
        for f in requested
    )
    output = {
        "task_id": "hard_rolling",
        "platform": "python",
        "estimates": estimates,
        "method_metadata": {
            "estimator": "rolling OLS AR(1) with intercept, 99 pairs per forecast",
            "vcov": "none; se set to null",
        },
        "diagnostics": {},
    }
    with open("result.json", "w") as stream:
        json.dump(output, stream, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
