import json
import numpy as np
import pandas as pd
from statsmodels.tsa.arima.model import ARIMA


def main():
    data = pd.read_csv("input.csv")
    if list(data.columns) != ["t", "y"]:
        raise ValueError("input.csv must contain columns t and y")
    y = pd.to_numeric(data["y"], errors="raise").astype(float)
    if y.isna().any() or len(y) != 250:
        raise ValueError("Expected 250 non-missing observations of y")

    # ARIMA(1,1,1) in levels, with no constant or drift.
    fit = ARIMA(y, order=(1, 1, 1), trend="n").fit()
    pred = fit.get_forecast(steps=1)
    forecast = float(pred.predicted_mean.iloc[0])
    interval = pred.conf_int(alpha=0.05).iloc[0]
    lower = float(interval.iloc[0])
    upper = float(interval.iloc[1])
    n_obs = int(len(y))

    # Independent API check of the one-step forecast.
    api_forecast = float(fit.predict(start=len(y), end=len(y)).iloc[0])
    if not np.isclose(forecast, api_forecast, rtol=1e-10, atol=1e-10):
        raise AssertionError("Forecast API check failed")

    # Prediction intervals use the normal 1.96 multiplier. Check this identity.
    se_forecast = float((upper - lower) / (2.0 * 1.959963984540054))
    if not np.isclose((forecast - lower) / se_forecast, 1.959963984540054,
                      rtol=1e-10, atol=1e-10):
        raise AssertionError("Prediction interval check failed")

    out = {
        "task_id": "arima_forecast",
        "platform": "python",
        "estimates": [
            {"term": "forecast", "estimate": forecast, "se": se_forecast, "n_obs": n_obs},
            {"term": "lower_95", "estimate": lower, "se": None, "n_obs": n_obs},
            {"term": "upper_95", "estimate": upper, "se": None, "n_obs": n_obs},
        ],
        "method_metadata": {
            "estimator": "ARIMA(1,1,1) by maximum likelihood, no constant or drift",
            "vcov": "normal prediction interval from fitted state-space forecast",
        },
        "diagnostics": {},
    }
    with open("result.json", "w") as f:
        json.dump(out, f, indent=2)

    with open("verification.txt", "w") as f:
        f.write("Input columns: t, y; observations: 250; forecast target: t=251.\n")
        f.write("Model: ARIMA(1,1,1), trend='n', maximum likelihood.\n")
        f.write(f"Independent predict() forecast check: {api_forecast:.12g} vs {forecast:.12g}; passed.\n")
        f.write(f"Normal interval identity check: se={se_forecast:.12g}; passed.\n")


if __name__ == "__main__":
    main()
