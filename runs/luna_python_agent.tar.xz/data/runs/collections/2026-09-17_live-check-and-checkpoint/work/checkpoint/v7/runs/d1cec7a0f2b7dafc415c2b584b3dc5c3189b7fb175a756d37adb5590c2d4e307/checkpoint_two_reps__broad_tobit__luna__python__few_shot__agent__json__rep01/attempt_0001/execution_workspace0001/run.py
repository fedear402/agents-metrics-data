import json
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.special import log_ndtr
from scipy.stats import norm
from statsmodels.tools.numdiff import approx_hess

df = pd.read_csv('input.csv')
assert list(df.columns) == ['id', 'y', 'x', 'z']
assert len(df) == 400 and df[['y', 'x', 'z']].notna().all().all()
y = df['y'].to_numpy(float)
X = np.column_stack([np.ones(len(df)), df['x'], df['z']])
cens = y == 0.0
uncens = ~cens
n = len(y)

def loss(theta):
    beta = theta[:3]
    sigma = np.exp(theta[3])
    mu = X @ beta
    a = -mu[cens] / sigma
    r = (y[uncens] - mu[uncens]) / sigma
    return -np.sum(log_ndtr(a)) - np.sum(norm.logpdf(r) - np.log(sigma))

def gradient(theta):
    beta = theta[:3]
    sigma = np.exp(theta[3])
    mu = X @ beta
    a = -mu[cens] / sigma
    mills = np.exp(norm.logpdf(a) - log_ndtr(a))
    r = (y[uncens] - mu[uncens]) / sigma
    g_beta = X[cens].T @ (mills / sigma) - X[uncens].T @ (r / sigma)
    g_logsigma = np.sum(a * mills) + np.sum(1.0 - r*r)
    return np.r_[g_beta, g_logsigma]

initial = np.r_[np.linalg.lstsq(X[uncens], y[uncens], rcond=None)[0], np.log(np.std(y[uncens]))]
for delta in (np.array([.13, -.07, .11, .09]), np.array([-.21, .12, -.08, -.14])):
    p = initial + delta
    fd = np.array([(loss(p + np.eye(4)[j]*1e-5)-loss(p-np.eye(4)[j]*1e-5))/(2e-5) for j in range(4)])
    assert np.allclose(gradient(p), fd, atol=2e-5, rtol=2e-6)

fit = minimize(loss, initial, jac=gradient, method='BFGS', options={'gtol': 1e-9, 'maxiter': 2000})
if not fit.success or np.max(np.abs(gradient(fit.x))) > 2e-6:
    fit = minimize(loss, fit.x, method='Nelder-Mead', options={'xatol':1e-11, 'fatol':1e-11, 'maxiter':10000})
    fit = minimize(loss, fit.x, jac=gradient, method='BFGS', options={'gtol': 1e-9, 'maxiter': 2000})
assert np.isfinite(loss(fit.x)) and np.max(np.abs(gradient(fit.x))) < 2e-5

info = approx_hess(fit.x, loss, epsilon=1e-5)
info = (info + info.T) / 2
assert np.linalg.eigvalsh(info).min() > 0
cov = np.linalg.inv(info)
beta = fit.x[:3]
sigma = np.exp(fit.x[3])
out = {'task_id':'broad_tobit', 'platform':'python', 'estimates':[
    {'term':t, 'estimate':float(v), 'se':float(np.sqrt(cov[i,i])), 'n_obs':n}
    for i, (t,v) in enumerate(zip(['const','x','z'], beta))] + [
    {'term':'sigma', 'estimate':float(sigma), 'se':None, 'n_obs':n}],
    'method_metadata': {'estimator':'Gaussian Tobit maximum likelihood, left censored at 0',
                        'vcov':'inverse observed information (full joint Hessian)'},
    'diagnostics': {}}
with open('result.json','w') as f:
    json.dump(out, f, indent=2, allow_nan=False)

# Independent checks: no-jacobian optimization and direct score finite differences.
nojac = minimize(loss, fit.x, method='BFGS', options={'gtol':1e-7, 'maxiter':2000})
fd_final = np.array([(loss(fit.x + np.eye(4)[j]*1e-5)-loss(fit.x-np.eye(4)[j]*1e-5))/(2e-5) for j in range(4)])
with open('verification.txt','w') as f:
    f.write(f'Rows read: {n}; y=0 rows: {int(cens.sum())}; uncensored rows: {int(uncens.sum())}.\n')
    f.write('Design: const, x, z; all 400 rows included in the likelihood.\n')
    f.write(f'Analytic score max abs at solution: {np.max(np.abs(gradient(fit.x))):.3e}.\n')
    f.write(f'Independent centered numerical score max abs: {np.max(np.abs(fd_final)):.3e}.\n')
    f.write(f'Independent no-jacobian objective difference: {abs(nojac.fun-loss(fit.x)):.3e}.\n')
    f.write(f'Observed-information minimum eigenvalue: {np.linalg.eigvalsh(info).min():.6g}.\n')
