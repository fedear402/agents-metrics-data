import json
import numpy as np
import pandas as pd
from scipy.special import expit
from statsmodels.miscmodels.ordinal_model import OrderedModel


def main():
    data = pd.read_csv("input.csv")
    required = {"id", "y", "x", "z"}
    assert required.issubset(data.columns)
    assert len(data) == 420
    assert data[["y", "x", "z"]].notna().all().all()
    assert set(data["y"].unique()) == {1, 2, 3}

    y = data["y"].astype(int)
    X = data[["x", "z"]]
    model = OrderedModel(y, X, distr="logit")
    fit = model.fit(method="bfgs", disp=False, gtol=1e-10, maxiter=1000)
    assert fit.mle_retvals.get("converged", True)

    params = np.asarray(fit.params)
    slopes = params[:2]
    slope_se = np.asarray(fit.bse)[:2]
    point = model.predict(params, exog=np.array([[1.0, 0.0]]))[0]
    prob_high = float(point[2])

    # Independent identity check: category 3 probability is one minus
    # the logistic CDF at its fitted upper cutpoint minus the linear index.
    thresholds = model.transform_threshold_params(params)
    manual_high = float(expit(slopes @ np.array([1.0, 0.0]) - thresholds[2]))
    assert np.isclose(prob_high, manual_high, rtol=1e-10, atol=1e-12)

    rows = [
        {"term": "x", "estimate": float(slopes[0]), "se": float(slope_se[0]), "n_obs": len(data)},
        {"term": "z", "estimate": float(slopes[1]), "se": float(slope_se[1]), "n_obs": len(data)},
        {"term": "prob_high", "estimate": prob_high, "se": None, "n_obs": len(data)},
    ]
    result = {
        "task_id": "broad_ordered_logit",
        "platform": "python",
        "estimates": rows,
        "method_metadata": {
            "estimator": "maximum-likelihood ordered logit with two free cutpoints and no intercept",
            "vcov": "conventional observed-information standard errors",
        },
        "diagnostics": {},
    }
    with open("result.json", "w") as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
    with open("verification.txt", "w") as stream:
        stream.write(f"Loaded {len(data)} observations; y levels={sorted(y.unique().tolist())}; x and z used directly.\n")
        stream.write(f"Converged={fit.mle_retvals.get('converged', True)}; optimizer={fit.mle_retvals.get(' warnflag', fit.mle_retvals.get('warnflag', 'unknown'))}.\n")
        stream.write(f"Independent category-3 check: predict={prob_high:.15g}, identity={manual_high:.15g}, equal={np.isclose(prob_high, manual_high, rtol=1e-10, atol=1e-12)}.\n")
        stream.write("Standard errors are fit.bse for the slope coefficients from the observed-information covariance.\n")


if __name__ == "__main__":
    main()
