import json

import numpy as np
import pandas as pd
from statsmodels.sandbox.regression.gmm import IV2SLS


def main():
    df = pd.read_csv("input.csv")
    cols = ["y_iv", "x1_iv", "z"]
    est = df[cols].dropna().copy()
    y = est["y_iv"].to_numpy(dtype=float)
    x = np.column_stack([np.ones(len(est)), est["x1_iv"].to_numpy(dtype=float)])
    instruments = np.column_stack([np.ones(len(est)), est["z"].to_numpy(dtype=float)])

    # 2SLS point estimate: regressors are projected on the full instrument set.
    pz_x = instruments @ np.linalg.solve(instruments.T @ instruments, instruments.T @ x)
    beta = np.linalg.solve(pz_x.T @ x, pz_x.T @ y)
    residual = y - x @ beta

    # HC1 sandwich covariance for 2SLS, using the fitted (projected) regressors.
    bread = np.linalg.inv(pz_x.T @ x)
    meat = pz_x.T @ (residual[:, None] ** 2 * pz_x)
    cov_hc0 = bread @ meat @ bread.T
    n_obs = len(est)
    cov_hc1 = cov_hc0 * n_obs / (n_obs - x.shape[1])
    se = np.sqrt(np.diag(cov_hc1))

    # Call the standard statsmodels IV2SLS routine as an independent point check.
    routine_beta = IV2SLS(y, x, instrument=instruments).fit().params
    if not np.allclose(beta, routine_beta, rtol=1e-10, atol=1e-10):
        raise RuntimeError("Independent IV2SLS point estimate check failed")

    out = {
        "task_id": "iv2sls_robust",
        "platform": "python",
        "estimates": [
            {"term": "const", "estimate": float(beta[0]), "se": float(se[0]), "n_obs": n_obs},
            {"term": "x1_iv", "estimate": float(beta[1]), "se": float(se[1]), "n_obs": n_obs},
        ],
        "method_metadata": {"estimator": "two-stage least squares", "vcov": "HC1 robust"},
        "diagnostics": {},
    }
    with open("result.json", "w") as f:
        json.dump(out, f)


if __name__ == "__main__":
    main()
