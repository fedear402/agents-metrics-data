import json

import numpy as np
import pandas as pd
import statsmodels.api as sm


def main():
    df = pd.read_csv("input.csv")
    sample = df.loc[df["z"].abs() <= 0.5, ["z", "y"]].copy()
    sample["weight"] = 1.0 - sample["z"].abs() / 0.5

    fits = {}
    for side, mask in [("left", sample["z"] < 0), ("right", sample["z"] >= 0)]:
        part = sample.loc[mask]
        design = sm.add_constant(part["z"], has_constant="add")
        fits[side] = sm.WLS(part["y"], design, weights=part["weight"]).fit()

    estimate = float(fits["right"].params["const"] - fits["left"].params["const"])
    se = float(np.sqrt(fits["right"].bse["const"] ** 2 + fits["left"].bse["const"] ** 2))

    output = {
        "task_id": "rdd_sharp",
        "platform": "python",
        "estimates": [{
            "term": "late",
            "estimate": estimate,
            "se": se,
            "n_obs": int(len(sample)),
        }],
        "method_metadata": {
            "estimator": "local linear regression with triangular kernel, h=0.5",
            "vcov": "conventional homoskedastic WLS",
        },
        "diagnostics": {},
    }
    with open("result.json", "w") as handle:
        json.dump(output, handle)


if __name__ == "__main__":
    main()
