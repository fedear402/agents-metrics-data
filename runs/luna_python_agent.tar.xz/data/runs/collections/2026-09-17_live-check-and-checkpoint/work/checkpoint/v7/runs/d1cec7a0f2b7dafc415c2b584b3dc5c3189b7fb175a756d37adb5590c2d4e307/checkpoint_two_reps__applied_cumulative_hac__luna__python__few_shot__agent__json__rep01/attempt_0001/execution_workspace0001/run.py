import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

data = pd.read_csv("input.csv", parse_dates=["date"]).sort_values("date").reset_index(drop=True)
data["log_sales"] = np.log(data["sales"])
data["vol_change"] = np.log(data["vix"]).diff()
for lag in range(1, 16):
    data[f"lag_{lag}"] = data["vol_change"].shift(lag)
regressors = [f"lag_{lag}" for lag in range(1, 16)]
sample = data.dropna(subset=["log_sales", *regressors]).copy()
n_obs = len(sample)
X = np.column_stack([np.ones(n_obs), sample[regressors].to_numpy()])
y = sample["log_sales"].to_numpy()
beta = np.linalg.lstsq(X, y, rcond=None)[0]
resid = y - X @ beta
scores = X * resid[:, None]
meat = scores.T @ scores
for j in range(1, 16):
    weight = 1.0 - j / 16.0
    cross = scores[j:].T @ scores[:-j]
    meat += weight * (cross + cross.T)
bread = np.linalg.inv(X.T @ X)
cov = (n_obs / (n_obs - 16)) * bread @ meat @ bread
contrast = np.r_[0.0, np.ones(15)]
estimate = float(contrast @ beta)
se_cumulative = float(np.sqrt(contrast @ cov @ contrast))
output = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {"term": "cumulative_response", "estimate": estimate, "se": se_cumulative, "n_obs": n_obs},
        {"term": "lag_1", "estimate": float(beta[1]), "se": float(np.sqrt(cov[1, 1])), "n_obs": n_obs},
        {"term": "lag_15", "estimate": float(beta[15]), "se": float(np.sqrt(cov[15, 15])), "n_obs": n_obs},
    ],
    "method_metadata": {"estimator": "OLS of log(sales) on intercept and lags 1-15 of first differences of log(vix)", "vcov": "Bartlett Newey-West HAC, max lag 15, finite-sample factor N/(N-16)"},
    "diagnostics": {},
}
with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)

# Independent check against statsmodels and the cumulative quadratic-form identity.
sm_fit = sm.OLS(y, X).fit(cov_type="HAC", cov_kwds={"maxlags": 15, "weights": "bartlett", "use_correction": True})
sm_cov = sm_fit.cov_params()
with open("verification.txt", "w") as stream:
    stream.write(f"Sorted rows: {len(data)}; regression sample: {n_obs} (expected {len(data)-16}).\n")
    stream.write(f"First usable date: {sample['date'].iloc[0].date()}; last: {sample['date'].iloc[-1].date()}.\n")
    stream.write(f"OLS beta max absolute difference from statsmodels: {np.max(np.abs(beta-sm_fit.params)):.3e}\n")
    stream.write(f"HAC covariance max absolute difference from statsmodels: {np.max(np.abs(cov-sm_cov)):.3e}\n")
    stream.write(f"Cumulative estimate equals sum of lag coefficients: {estimate:.15g} vs {beta[1:].sum():.15g}.\n")
    stream.write(f"Cumulative SE quadratic form: {se_cumulative:.15g}; covariance includes cross terms.\n")
    stream.write("Construction check: log(vix) first difference, then observed-row lags 1 through 15; intercept included.\n")
