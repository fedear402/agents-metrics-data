import json
import numpy as np
import pandas as pd

PATH = "input.csv"

def iv_hc1(y, endog, instrument, weights):
    """Weighted single-endogenous-regressor IV with robust HC1 covariance."""
    y = np.asarray(y, float); q = np.asarray(endog, float)
    z = np.asarray(instrument, float); w = np.asarray(weights, float)
    X = np.column_stack([np.ones(len(y)), q])
    Z = np.column_stack([np.ones(len(y)), z])
    sw = np.sqrt(w)
    Xw, Zw, yw = X * sw[:, None], Z * sw[:, None], y * sw
    zz = Zw.T @ Zw
    A = Xw.T @ Zw @ np.linalg.solve(zz, Zw.T @ Xw)
    b = np.linalg.solve(A, Xw.T @ Zw @ np.linalg.solve(zz, Zw.T @ yw))
    u = y - X @ b
    middle = Zw.T @ (u[:, None] ** 2 * Zw)
    bread_right = np.linalg.solve(zz, Zw.T @ Xw)
    meat = Xw.T @ Zw @ np.linalg.solve(zz, middle) @ np.linalg.solve(zz, Zw.T @ Xw)
    cov = np.linalg.solve(A, meat) @ np.linalg.inv(A)
    cov *= len(y) / (len(y) - 2)
    return b, cov

df = pd.read_csv(PATH)
region = df.drop_duplicates("region_id").copy()
region["e"] = region["region_weight"] / region["region_weight"].sum()
e_map = region.set_index("region_id")["e"]
df["e"] = df["region_id"].map(e_map)
df["z"] = df["share"] * df["shock"]
regional = (df.groupby("region_id", as_index=False)
              .agg(share_sum=("share", "sum"), z=("z", "sum"),
                   x=("x", "first"), y=("y", "first"), e=("e", "first")))
mean = {v: np.sum(regional.e * regional[v]) for v in ["y", "x", "z"]}
for v in ["y", "x", "z"]:
    regional[v + "0"] = regional[v] - mean[v]

g = df.merge(regional[["region_id", "y0", "x0", "z0"]], on="region_id")
g["ewshare"] = g["e"] * g["share"]
ind = g.groupby("industry_id").agg(s=("ewshare", "sum"), shock=("shock", "first"))
for v in ["y0", "x0", "z0"]:
    ind[v + "bar"] = g.assign(val=g["ewshare"] * g[v]).groupby("industry_id")["val"].sum() / ind["s"]
ind = ind[ind["s"] > 0].copy()

effect_b, effect_cov = iv_hc1(ind.y0bar, ind.x0bar, ind.shock, ind.s)
first_b, first_cov = iv_hc1(ind.x0bar, ind.z0bar, ind.shock, ind.s)

# Independent check: regional weighted 2SLS slopes equal the shock-level slopes.
reg_b, _ = iv_hc1(regional.y, regional.x, regional.z, regional.e)
reg_first_b, _ = iv_hc1(regional.x, regional.z, regional.z, regional.e)
# The first-stage slope is weighted OLS x on z, and equals the shock-level IV slope.
first_ols = np.sum(regional.e * (regional.z - mean["z"]) * (regional.x - mean["x"])) / np.sum(regional.e * (regional.z - mean["z"])**2)

result = {
    "task_id": "applied_shift_share", "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": float(effect_b[1]), "se": float(np.sqrt(effect_cov[1,1])), "n_obs": int(len(ind))},
        {"term": "first_stage", "estimate": float(first_b[1]), "se": float(np.sqrt(first_cov[1,1])), "n_obs": int(len(ind))},
        {"term": "effective_shocks", "estimate": float(1 / np.sum(ind.s**2)), "se": None, "n_obs": int(len(ind))}
    ],
    "method_metadata": {"estimator": "weighted regional 2SLS with BHJ shock-level aggregation", "vcov": "shock-level heteroskedastic HC1, multiplier N/(N-2), structural IV residuals"},
    "diagnostics": {}
}
with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
with open("verification.txt", "w") as f:
    f.write(f"Rows: {len(df)}; regions: {len(regional)}; industries used: {len(ind)}.\n")
    f.write(f"Share sums: max absolute error from one = {np.max(np.abs(regional.share_sum-1)):.6g}.\n")
    f.write(f"Regional effect slope = {reg_b[1]:.12g}; shock-level effect slope = {effect_b[1]:.12g}; difference = {reg_b[1]-effect_b[1]:.6g}.\n")
    f.write(f"Regional first-stage OLS slope = {first_ols:.12g}; shock-level IV slope = {first_b[1]:.12g}; difference = {first_ols-first_b[1]:.6g}.\n")
    f.write(f"Effective shocks = {result['estimates'][2]['estimate']:.12g}; sum(s) = {ind.s.sum():.12g}.\n")
