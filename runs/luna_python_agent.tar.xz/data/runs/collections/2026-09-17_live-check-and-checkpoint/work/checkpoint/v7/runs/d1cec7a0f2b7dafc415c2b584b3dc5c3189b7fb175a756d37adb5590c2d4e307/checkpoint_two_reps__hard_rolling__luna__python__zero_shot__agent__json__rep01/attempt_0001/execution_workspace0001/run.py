import json
import numpy as np
import pandas as pd


def main():
    df = pd.read_csv("input.csv").sort_values("time").reset_index(drop=True)
    y = df["y"].to_numpy(dtype=float)
    forecasts = {}
    errors = []

    for f in range(101, 251):
        # The 100 levels are y_(f-100), ..., y_(f-1).
        first = f - 100 - 1  # zero-based position of y_(f-100)
        last = f - 1         # exclusive zero-based position after y_(f-1)
        levels = y[first:last]
        x = levels[:-1]
        response = levels[1:]
        design = np.column_stack((np.ones(99), x))
        coefficients, _, _, _ = np.linalg.lstsq(design, response, rcond=None)
        forecast = float(coefficients @ np.array([1.0, y[f - 2]]))
        forecasts[f] = forecast
        errors.append(y[f - 1] - forecast)

    rmse = float(np.sqrt(np.sum(np.square(errors)) / 150.0))
    estimates = [
        {"term": "rmse", "estimate": rmse, "se": None, "n_obs": 150},
        {"term": "forecast_101", "estimate": forecasts[101], "se": None, "n_obs": 99},
        {"term": "forecast_150", "estimate": forecasts[150], "se": None, "n_obs": 99},
        {"term": "forecast_200", "estimate": forecasts[200], "se": None, "n_obs": 99},
        {"term": "forecast_250", "estimate": forecasts[250], "se": None, "n_obs": 99},
    ]
    result = {
        "task_id": "hard_rolling",
        "platform": "python",
        "estimates": estimates,
        "method_metadata": {"estimator": "rolling OLS AR(1) with intercept", "vcov": "none"},
        "diagnostics": {},
    }
    with open("result.json", "w", encoding="utf-8") as handle:
        json.dump(result, handle, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
