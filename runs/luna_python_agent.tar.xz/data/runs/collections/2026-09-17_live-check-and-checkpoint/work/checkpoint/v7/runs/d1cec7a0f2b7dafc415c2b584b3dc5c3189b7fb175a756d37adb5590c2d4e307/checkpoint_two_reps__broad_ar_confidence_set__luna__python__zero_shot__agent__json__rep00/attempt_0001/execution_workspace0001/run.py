import json
import numpy as np
import pandas as pd
from scipy.stats import f as f_dist


def ssr_coefficients(y, endog, design):
    """Return coefficients a,b,c for SSR(y-beta*endog)=a*beta^2+b*beta+c."""
    q0 = y
    qe = endog
    r0 = q0 - design @ np.linalg.lstsq(design, q0, rcond=None)[0]
    re = qe - design @ np.linalg.lstsq(design, qe, rcond=None)[0]
    return float(re @ re), float(-2.0 * (r0 @ re)), float(r0 @ r0)


def main():
    data = pd.read_csv("input.csv")
    required = ["y", "endog", "x", "z1", "z2"]
    if list(data.columns) != required or len(data) != 240:
        raise ValueError("Unexpected data columns or observation count")
    y = data.y.to_numpy(float)
    e = data.endog.to_numpy(float)
    x = data.x.to_numpy(float)
    z1 = data.z1.to_numpy(float)
    z2 = data.z2.to_numpy(float)
    restricted = np.column_stack([np.ones(len(data)), x])
    unrestricted = np.column_stack([np.ones(len(data)), x, z1, z2])
    ar, au = ssr_coefficients(y, e, restricted), ssr_coefficients(y, e, unrestricted)
    n = len(data)
    df2, df1 = n - 4, 2
    critical = f_dist.ppf(0.95, df1, df2)
    # F <= critical is equivalent to (SSRr-SSRu) - critical*df1/df2*SSRu <= 0.
    scale = critical * df1 / df2
    poly = np.array(ar) - (1.0 + scale) * np.array(au)
    roots = np.roots([poly[0], poly[1], poly[2]])
    real_roots = sorted(float(r.real) for r in roots if abs(r.imag) < 1e-7)
    if len(real_roots) != 2:
        raise ValueError(f"Expected two finite real boundaries, got {roots}")
    low, high = real_roots

    def ar_f(beta):
        q = y - beta * e
        b_u = np.linalg.lstsq(unrestricted, q, rcond=None)[0]
        b_r = np.linalg.lstsq(restricted, q, rcond=None)[0]
        ssru = float(np.sum((q - unrestricted @ b_u) ** 2))
        ssrr = float(np.sum((q - restricted @ b_r) ** 2))
        return ((ssrr - ssru) / df1) / (ssru / df2)

    f1 = ar_f(1.0)
    accepts_zero = int(ar_f(0.0) <= critical)
    # The leading coefficient is negative for the acceptance inequality here.
    unbounded = int(poly[0] < 0 and poly[0] != 0)
    estimates = [
        ("boundary_low", low), ("boundary_high", high),
        ("accepts_zero", accepts_zero), ("unbounded", unbounded),
        ("ar_f_at_one", f1),
    ]
    result = {
        "task_id": "broad_ar_confidence_set",
        "platform": "python",
        "estimates": [
            {"term": term, "estimate": float(value), "se": None, "n_obs": n}
            for term, value in estimates
        ],
        "method_metadata": {
            "estimator": "Anderson-Rubin confidence set via homoskedastic joint F test",
            "vcov": "conventional homoskedastic",
        },
        "diagnostics": {},
    }
    with open("result.json", "w") as f:
        json.dump(result, f, indent=2)

    # Independent checks: direct regressions and the quadratic identity at beta=1.
    direct_f1 = ar_f(1.0)
    q1 = y - e
    r_restricted = q1 - restricted @ np.linalg.lstsq(restricted, q1, rcond=None)[0]
    r_unrestricted = q1 - unrestricted @ np.linalg.lstsq(unrestricted, q1, rcond=None)[0]
    direct_ssrr, direct_ssru = float(r_restricted @ r_restricted), float(r_unrestricted @ r_unrestricted)
    quadratic_ssrr = np.polyval(ar, 1.0)
    quadratic_ssru = np.polyval(au, 1.0)
    with open("verification.txt", "w") as f:
        f.write(f"Rows and variables checked: n={n}, columns={required}.\n")
        f.write(f"Design ranks: restricted={np.linalg.matrix_rank(restricted)}, unrestricted={np.linalg.matrix_rank(unrestricted)}.\n")
        f.write(f"F critical (2,{df2}) at 95 percent: {critical:.12f}.\n")
        f.write(f"Boundary roots of acceptance polynomial: {low:.12f}, {high:.12f}.\n")
        f.write(f"Direct AR F at beta=1: {direct_f1:.12f}.\n")
        f.write(f"Independent quadratic check SSRr(beta=1): direct={direct_ssrr:.12f}, quadratic={quadratic_ssrr:.12f}.\n")
        f.write(f"Independent quadratic check SSRu(beta=1): direct={direct_ssru:.12f}, quadratic={quadratic_ssru:.12f}.\n")
        f.write(f"F consistency check: reported={f1:.12f}, direct={direct_f1:.12f}.\n")
        f.write(f"Acceptance at zero: {accepts_zero}; unbounded: {unbounded}.\n")


if __name__ == "__main__":
    main()
