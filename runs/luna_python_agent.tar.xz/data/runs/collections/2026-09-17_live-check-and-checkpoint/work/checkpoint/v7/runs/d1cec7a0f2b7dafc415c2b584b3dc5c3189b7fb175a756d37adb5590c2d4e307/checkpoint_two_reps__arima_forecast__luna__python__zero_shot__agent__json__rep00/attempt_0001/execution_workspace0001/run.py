import json
import numpy as np
import pandas as pd
from statsmodels.tsa.arima.model import ARIMA


def main():
    data = pd.read_csv("input.csv")
    if list(data.columns) != ["t", "y"]:
        raise ValueError("input.csv must contain columns t and y")
    if data["y"].isna().any() or data["t"].isna().any():
        raise ValueError("input.csv contains missing values")
    y = data["y"].astype(float).to_numpy()
    if len(y) != 250 or not np.array_equal(data["t"].to_numpy(), np.arange(1, 251)):
        raise ValueError("Expected t=1,...,250 and 250 observations")

    # ARIMA(1,1,1) with no constant or drift.
    fitted = ARIMA(y, order=(1, 1, 1), trend="n").fit()
    pred = fitted.get_forecast(steps=1)
    forecast = float(np.asarray(pred.predicted_mean)[0])
    interval = np.asarray(pred.conf_int(alpha=0.05))[0]
    lower, upper = map(float, interval)
    n_obs = int(len(y))

    output = {
        "task_id": "arima_forecast",
        "platform": "python",
        "estimates": [
            {"term": "forecast", "estimate": forecast, "se": None, "n_obs": n_obs},
            {"term": "lower_95", "estimate": lower, "se": None, "n_obs": n_obs},
            {"term": "upper_95", "estimate": upper, "se": None, "n_obs": n_obs},
        ],
        "method_metadata": {
            "estimator": "Gaussian maximum likelihood ARIMA(1,1,1), no constant or drift",
            "vcov": "model-based forecast uncertainty",
        },
        "diagnostics": {},
    }
    with open("result.json", "w", encoding="utf-8") as handle:
        json.dump(output, handle, indent=2)


if __name__ == "__main__":
    main()
