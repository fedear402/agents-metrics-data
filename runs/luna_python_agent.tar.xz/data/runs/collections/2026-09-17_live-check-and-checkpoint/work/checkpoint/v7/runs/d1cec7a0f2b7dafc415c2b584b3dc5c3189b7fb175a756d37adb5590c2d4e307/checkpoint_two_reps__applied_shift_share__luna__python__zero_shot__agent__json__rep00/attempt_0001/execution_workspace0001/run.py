import json
import numpy as np
import pandas as pd


INPUT = "input.csv"


def weighted_mean(values, weights):
    return float(np.sum(weights * values) / np.sum(weights))


def iv_slope_and_hc1(y, q, instrument, weights):
    """Weighted one-instrument IV with robust HC1 covariance."""
    y = np.asarray(y, float)
    q = np.asarray(q, float)
    h = np.asarray(instrument, float)
    w = np.asarray(weights, float)
    Z = np.column_stack((np.ones(len(y)), h))
    X = np.column_stack((np.ones(len(y)), q))
    # Weighted projection onto the instrument space.
    zwz_inv = np.linalg.inv(Z.T @ (w[:, None] * Z))
    PZX = Z @ zwz_inv @ (Z.T @ (w[:, None] * X))
    beta = np.linalg.solve(PZX.T @ (w[:, None] * PZX), PZX.T @ (w * y))
    resid = y - X @ beta
    bread = np.linalg.inv(PZX.T @ (w[:, None] * PZX))
    meat = PZX.T @ ((w * w * resid * resid)[:, None] * PZX)
    cov = bread @ meat @ bread * (len(y) / (len(y) - X.shape[1]))
    return float(beta[1]), float(np.sqrt(cov[1, 1]))


def main():
    df = pd.read_csv(INPUT)
    # Keep one observation per region for the regional weights and outcomes.
    reg = df.drop_duplicates("region_id").copy()
    reg["e"] = reg["region_weight"] / reg["region_weight"].sum()
    reg_ids = reg["region_id"].to_numpy()
    e = reg["e"].to_numpy(float)
    x = reg["x"].to_numpy(float)
    y = reg["y"].to_numpy(float)
    # Construct z from all region-industry rows, then align it to reg.
    z = (df.assign(weighted_share=df["share"] * df["shock"])
           .groupby("region_id", sort=False)["weighted_share"].sum()
           .reindex(reg_ids).to_numpy(float))
    x0 = x - np.sum(e * x)
    y0 = y - np.sum(e * y)
    z0 = z - np.sum(e * z)
    work = pd.DataFrame({"region_id": df["region_id"], "industry_id": df["industry_id"], "share": df["share"]})
    work = work.merge(pd.DataFrame({"region_id": reg_ids, "e": e, "x0": x0,
                                    "y0": y0, "z0": z0}), on="region_id")
    work = work.merge(df[["industry_id", "shock"]].drop_duplicates("industry_id"),
                      on="industry_id", how="left")
    work["es"] = work["e"] * work["share"]
    agg = work.groupby("industry_id", sort=True).agg(
        s=("es", "sum"), shock=("shock", "first"))
    for v in ("x0", "y0", "z0"):
        nums = (work["es"] * work[v]).groupby(work["industry_id"]).sum()
        agg[v + "bar"] = nums / agg["s"]
    agg = agg[agg["s"] > 0].copy()
    n = len(agg)
    effect, effect_se = iv_slope_and_hc1(agg["y0bar"], agg["x0bar"], agg["shock"], agg["s"])
    first, first_se = iv_slope_and_hc1(agg["x0bar"], agg["z0bar"], agg["shock"], agg["s"])
    result = {"task_id": "applied_shift_share", "platform": "python", "estimates": [
        {"term": "effect", "estimate": effect, "se": effect_se, "n_obs": n},
        {"term": "first_stage", "estimate": first, "se": first_se, "n_obs": n},
        {"term": "effective_shocks", "estimate": float(1 / np.sum(agg["s"] ** 2)), "se": None, "n_obs": n}],
        "method_metadata": {"estimator": "BHJ shock-level weighted 2SLS", "vcov": "shock-level HC1 robust, structural IV residuals"},
        "diagnostics": {}}
    with open("result.json", "w") as f:
        json.dump(result, f, indent=2)
    # Independent checks: direct regional 2SLS slopes equal shock-level slopes.
    direct_effect, _ = iv_slope_and_hc1(y, x, z, e)
    direct_first, _ = iv_slope_and_hc1(x, z, z, e)
    with open("verification.txt", "w") as f:
        f.write(f"regions={len(reg)}, industries={n}, share_sum_max_error={df.groupby('region_id')['share'].sum().sub(1).abs().max():.3e}\n")
        f.write(f"weighted_mean_residuals={np.sum(e*y0):.3e},{np.sum(e*x0):.3e},{np.sum(e*z0):.3e}\n")
        f.write(f"effect shock-level={effect:.12g}, direct regional={direct_effect:.12g}, difference={effect-direct_effect:.3e}\n")
        f.write(f"first-stage shock-level={first:.12g}, direct regional={direct_first:.12g}, difference={first-direct_first:.3e}\n")
        f.write(f"effective_shocks={result['estimates'][2]['estimate']:.12g}; all positive exposure masses used\n")


if __name__ == "__main__":
    main()
