import json

import numpy as np
import pandas as pd
import statsmodels.api as sm


df = pd.read_csv("input.csv")
df["y_h4"] = df["y"].shift(-4)
df["y_lag1"] = df["y"].shift(1)
sample = df[["y_h4", "shock", "y_lag1"]].dropna()

X = sm.add_constant(sample[["shock", "y_lag1"]], has_constant="add")
y = sample["y_h4"]
fit = sm.OLS(y, X).fit(cov_type="HAC", cov_kwds={"maxlags": 4, "use_correction": False})

out = {
    "task_id": "lp_irf",
    "platform": "python",
    "estimates": [{
        "term": "irf_h4",
        "estimate": float(fit.params["shock"]),
        "se": float(fit.bse["shock"]),
        "n_obs": int(fit.nobs),
    }],
    "method_metadata": {
        "estimator": "Local projection OLS: y[t+4] on shock[t] and y[t-1] with intercept",
        "vcov": "Newey-West HAC with lag 4",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(out, f)
