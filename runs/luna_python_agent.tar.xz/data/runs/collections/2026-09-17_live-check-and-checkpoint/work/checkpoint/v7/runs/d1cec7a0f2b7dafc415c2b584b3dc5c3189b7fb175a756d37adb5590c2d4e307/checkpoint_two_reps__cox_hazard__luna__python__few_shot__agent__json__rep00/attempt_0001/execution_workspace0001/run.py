import json
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from statsmodels.duration.hazard_regression import PHReg


df = pd.read_csv("input.csv")
required = ["subject", "treat", "x", "t_obs", "event"]
if any(c not in df.columns for c in required):
    raise ValueError("input.csv does not contain the required columns")
use = df[required].dropna().copy()
if (use["t_obs"] <= 0).any():
    raise ValueError("Cox durations must be positive")
if not use["event"].isin([0, 1]).all():
    raise ValueError("event must be binary")

X = use[["treat", "x"]].to_numpy(dtype=float)
duration = use["t_obs"].to_numpy(dtype=float)
status = use["event"].to_numpy(dtype=int)
fit = PHReg(duration, X, status=status, ties="breslow").fit()

def neg_log_pl(beta):
    eta = X @ beta
    total = 0.0
    for time in np.unique(duration[status == 1]):
        deaths = (duration == time) & (status == 1)
        risk = duration >= time
        d = int(deaths.sum())
        total -= eta[deaths].sum() - d * np.log(np.exp(eta[risk]).sum())
    return total

check = minimize(neg_log_pl, np.zeros(X.shape[1]), method="BFGS", tol=1e-12)
if not np.allclose(fit.params, check.x, rtol=2e-5, atol=2e-5):
    raise RuntimeError("independent partial-likelihood check failed")

out = {
    "task_id": "cox_hazard",
    "platform": "python",
    "estimates": [
        {"term": name, "estimate": float(fit.params[i]),
         "se": float(fit.bse[i]), "n_obs": int(len(use))}
        for i, name in enumerate(["treat", "x"])
    ],
    "method_metadata": {"estimator": "Cox proportional hazards, Breslow ties",
                        "vcov": "model-based asymptotic covariance"},
    "diagnostics": {},
}
with open("result.json", "w") as f:
    json.dump(out, f)

with open("verification.txt", "w") as f:
    f.write("Estimation sample: %d complete observations; %d events.\n" %
            (len(use), int(status.sum())))
    f.write("Variables: t_obs is duration, event is status, treat and x are covariates; subject is unused.\n")
    f.write("Estimator: statsmodels PHReg Cox partial likelihood with Breslow ties; model-based covariance.\n")
    f.write("Independent check: scipy BFGS maximization of the Breslow partial likelihood.\n")
    f.write("Package estimates: %s\n" % np.array2string(fit.params, precision=12))
    f.write("Independent estimates: %s\n" % np.array2string(check.x, precision=12))
    f.write("Maximum absolute estimate difference: %.3g\n" % np.max(np.abs(fit.params - check.x)))
