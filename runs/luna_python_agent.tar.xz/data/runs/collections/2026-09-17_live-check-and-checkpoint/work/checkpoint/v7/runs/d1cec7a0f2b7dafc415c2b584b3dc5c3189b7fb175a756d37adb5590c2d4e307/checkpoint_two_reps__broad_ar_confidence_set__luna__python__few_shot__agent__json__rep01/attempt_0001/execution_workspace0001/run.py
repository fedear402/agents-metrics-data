import json

import numpy as np
import pandas as pd
from scipy.stats import f


def residual(v, design):
    return v - design @ np.linalg.lstsq(design, v, rcond=None)[0]


data = pd.read_csv("input.csv")
n = len(data)
y = data["y"].to_numpy(float)
endog = data["endog"].to_numpy(float)
x = data["x"].to_numpy(float)
z1 = data["z1"].to_numpy(float)
z2 = data["z2"].to_numpy(float)

restricted = np.column_stack((np.ones(n), x))
unrestricted = np.column_stack((np.ones(n), x, z1, z2))
q = 2
df = n - unrestricted.shape[1]
critical = f.ppf(0.95, q, df)

ry = residual(y, restricted)
rd = residual(endog, restricted)
uy = residual(y, unrestricted)
ud = residual(endog, unrestricted)

# F(beta) <= critical is equivalent to A beta^2 + B beta + C <= 0.
k = q * critical / df
A = rd @ rd - (1.0 + k) * (ud @ ud)
B = -2.0 * (ry @ rd - (1.0 + k) * (uy @ ud))
C = ry @ ry - (1.0 + k) * (uy @ uy)
roots = np.sort(np.roots((A, B, C)).real)


def accepts(beta):
    return A * beta * beta + B * beta + C <= 0.0


def ar_f(beta):
    target = y - beta * endog
    rr = residual(target, restricted)
    uu = residual(target, unrestricted)
    return ((rr @ rr - uu @ uu) / q) / ((uu @ uu) / df)


rows = [
    {"term": "boundary_low", "estimate": float(roots[0]), "se": None, "n_obs": n},
    {"term": "boundary_high", "estimate": float(roots[1]), "se": None, "n_obs": n},
    {"term": "accepts_zero", "estimate": int(accepts(0.0)), "se": None, "n_obs": n},
    {"term": "unbounded", "estimate": int(A < 0.0), "se": None, "n_obs": n},
    {"term": "ar_f_at_one", "estimate": float(ar_f(1.0)), "se": None, "n_obs": n},
]

with open("result.json", "w") as stream:
    json.dump(
        {
            "task_id": "broad_ar_confidence_set",
            "platform": "python",
            "estimates": rows,
            "method_metadata": {
                "estimator": "Anderson-Rubin inverted homoskedastic joint F test",
                "vcov": "homoskedastic",
            },
            "diagnostics": {},
        },
        stream,
        indent=2,
        allow_nan=False,
    )
