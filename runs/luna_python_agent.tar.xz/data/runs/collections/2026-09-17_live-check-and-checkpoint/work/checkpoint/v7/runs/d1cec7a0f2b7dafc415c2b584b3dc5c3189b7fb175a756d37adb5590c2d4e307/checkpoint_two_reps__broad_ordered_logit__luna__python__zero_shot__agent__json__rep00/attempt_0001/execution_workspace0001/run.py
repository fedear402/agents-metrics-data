import json
import numpy as np
import pandas as pd
from statsmodels.miscmodels.ordinal_model import OrderedModel
from scipy.special import expit


def main():
    df = pd.read_csv("input.csv")
    required = {"id", "y", "x", "z"}
    if set(df.columns) != required:
        raise ValueError(f"Unexpected columns: {df.columns.tolist()}")
    if len(df) != 420 or df[["y", "x", "z"]].isna().any().any():
        raise ValueError("Invalid estimation sample")
    if not set(df["y"].unique()).issubset({1, 2, 3}):
        raise ValueError("y must contain categories 1, 2, 3")

    model = OrderedModel(df["y"], df[["x", "z"]], distr="logit")
    fit = model.fit(method="bfgs", disp=False, maxiter=1000)
    params = fit.params
    bse = fit.bse
    beta = np.asarray(params.iloc[:2], dtype=float)
    # Statsmodels stores the first threshold and log increment; recover cut2.
    thresholds = model.transform_threshold_params(np.asarray(params.iloc[2:], dtype=float))
    cut2 = float(thresholds[2])
    eta = float(beta @ np.array([1.0, 0.0]))
    prob_high = float(expit(eta - cut2))

    result = {
        "task_id": "broad_ordered_logit",
        "platform": "python",
        "estimates": [
            {"term": "x", "estimate": float(params.iloc[0]), "se": float(bse.iloc[0]), "n_obs": 420},
            {"term": "z", "estimate": float(params.iloc[1]), "se": float(bse.iloc[1]), "n_obs": 420},
            {"term": "prob_high", "estimate": prob_high, "se": None, "n_obs": 420},
        ],
        "method_metadata": {
            "estimator": "maximum likelihood ordered logit with two free cutpoints and no intercept",
            "vcov": "conventional observed-information standard errors",
        },
        "diagnostics": {},
    }
    with open("result.json", "w") as f:
        json.dump(result, f, indent=2)

    # Independent checks: category-3 probability identity and sample construction.
    p3_from_predict = float(model.predict(params, exog=np.array([[1.0, 0.0]]))[0, 2])
    with open("verification.txt", "w") as f:
        f.write(f"rows={len(df)}, y_values={sorted(df.y.unique().tolist())}, missing={int(df.isna().sum().sum())}\n")
        f.write(f"converged={fit.mle_retvals.get('converged')}, iterations={fit.mle_retvals.get('iterations')}\n")
        f.write(f"prob_high_manual={prob_high:.15g}\n")
        f.write(f"prob_high_model_predict={p3_from_predict:.15g}\n")
        f.write(f"absolute_difference={abs(prob_high - p3_from_predict):.15g}\n")
        f.write("The manual check uses P(y=3)=expit(x*beta_x+z*beta_z-cutpoint_2).\n")


if __name__ == "__main__":
    main()
