import json
import numpy as np
import pandas as pd
import statsmodels.api as sm


def fit_side(x, y, w):
    X = np.column_stack((np.ones(len(x)), x))
    root_w = np.sqrt(w)
    Xw = X * root_w[:, None]
    yw = y * root_w
    bread = np.linalg.inv(Xw.T @ Xw)
    beta = bread @ (Xw.T @ yw)
    resid = y - X @ beta
    meat = X.T @ ((w * w * resid * resid)[:, None] * X)
    vcov = bread @ meat @ bread
    return beta, vcov, X, resid


def main():
    df = pd.read_csv("input.csv")
    sample = df.loc[df["score"].abs() < 1].copy()
    sample["weight"] = 1.0 - sample["score"].abs()
    n = len(sample)

    side = sample["score"].to_numpy() >= 0
    outcomes = {}
    for name in ("earnings", "participated"):
        fits = {}
        for right in (False, True):
            mask = side == right
            fits[right] = fit_side(
                sample.loc[mask, "score"].to_numpy(),
                sample.loc[mask, name].to_numpy(),
                sample.loc[mask, "weight"].to_numpy(),
            )
        left_beta, left_v, _, _ = fits[False]
        right_beta, right_v, _, _ = fits[True]
        estimate = right_beta[0] - left_beta[0]
        variance = right_v[0, 0] + left_v[0, 0]
        outcomes[name] = (estimate, variance)

    rf, var_rf = outcomes["earnings"]
    fs, var_fs = outcomes["participated"]
    # Joint HC0 covariance uses the same observations, weights, and regressors.
    cross = 0.0
    for right in (False, True):
        mask = side == right
        x = sample.loc[mask, "score"].to_numpy()
        w = sample.loc[mask, "weight"].to_numpy()
        _, _, X, er = fit_side(x, sample.loc[mask, "earnings"].to_numpy(), w)
        _, _, _, ep = fit_side(x, sample.loc[mask, "participated"].to_numpy(), w)
        bread = np.linalg.inv((X * np.sqrt(w)[:, None]).T @ (X * np.sqrt(w)[:, None]))
        cross += (bread @ (X.T @ ((w * w * er * ep)[:, None] * X)) @ bread)[0, 0]
    cov_discontinuities = cross  # left and right samples are disjoint; signs cancel.
    treatment = rf / fs
    var_treatment = var_rf / fs**2 + rf**2 * var_fs / fs**4 - 2 * rf * cov_discontinuities / fs**3
    se_treatment = float(np.sqrt(max(var_treatment, 0.0)))

    estimates = [
        {"term": "treatment_effect", "estimate": float(treatment), "se": se_treatment, "n_obs": n},
        {"term": "reduced_form", "estimate": float(rf), "se": float(np.sqrt(max(var_rf, 0.0))), "n_obs": n},
        {"term": "first_stage", "estimate": float(fs), "se": float(np.sqrt(max(var_fs, 0.0))), "n_obs": n},
    ]
    result = {
        "task_id": "applied_fuzzy_rd",
        "platform": "python",
        "estimates": estimates,
        "method_metadata": {"estimator": "fuzzy local-linear RD, triangular weights, bandwidth 1", "vcov": "HC0, fixed weights, delta method with joint covariance"},
        "diagnostics": {},
    }
    with open("result.json", "w") as f:
        json.dump(result, f, indent=2)

    # Independent checks: statsmodels WLS HC0 and the ratio identity.
    checks = []
    for name in ("earnings", "participated"):
        side_intercepts = []
        for right in (False, True):
            mask = side == right
            x = sample.loc[mask, "score"]
            X = sm.add_constant(x)
            model = sm.WLS(sample.loc[mask, name], X, weights=sample.loc[mask, "weight"]).fit(cov_type="HC0")
            side_intercepts.append((model.params.iloc[0], model.cov_params().iloc[0, 0]))
        checks.append(f"{name}: statsmodels discontinuity={side_intercepts[1][0]-side_intercepts[0][0]:.12g}, direct={outcomes[name][0]:.12g}")
    checks.append(f"sample_count={n}; ratio_identity={rf/fs:.12g}; reported_ratio={treatment:.12g}")
    with open("verification.txt", "w") as f:
        f.write("\n".join(checks) + "\n")


if __name__ == "__main__":
    main()
