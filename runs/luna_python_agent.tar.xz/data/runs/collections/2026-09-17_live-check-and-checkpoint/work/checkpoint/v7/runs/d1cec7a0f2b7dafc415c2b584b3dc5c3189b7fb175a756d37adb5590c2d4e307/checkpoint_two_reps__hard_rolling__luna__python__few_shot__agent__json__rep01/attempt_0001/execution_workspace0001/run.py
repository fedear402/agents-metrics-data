import json

import numpy as np
import pandas as pd


def main():
    data = pd.read_csv("input.csv").sort_values("time").reset_index(drop=True)
    assert data["time"].tolist() == list(range(1, 251))
    y = data["y"].to_numpy(dtype=float)

    forecasts = {}
    errors = []
    for f in range(101, 251):
        # Labels f-100 through f-1 correspond to array positions f-101:f-1.
        levels = y[f - 101 : f - 1]
        assert len(levels) == 100
        lagged = levels[:-1]
        current = levels[1:]
        X = np.column_stack((np.ones(99), lagged))
        coefficients = np.linalg.lstsq(X, current, rcond=None)[0]
        forecast = float(coefficients @ np.array([1.0, levels[-1]]))
        forecasts[f] = forecast
        errors.append(y[f - 1] - forecast)

    rmse = float(np.sqrt(np.mean(np.square(errors))))
    requested = [101, 150, 200, 250]
    rows = [
        {"term": "rmse", "estimate": rmse, "se": None, "n_obs": 150},
        *[
            {
                "term": f"forecast_{f}",
                "estimate": forecasts[f],
                "se": None,
                "n_obs": 99,
            }
            for f in requested
        ],
    ]
    output = {
        "task_id": "hard_rolling",
        "platform": "python",
        "estimates": rows,
        "method_metadata": {
            "estimator": "rolling OLS AR(1) with intercept, 99 pairs per forecast",
            "vcov": "none; forecasts and RMSE have se=null",
        },
        "diagnostics": {},
    }
    with open("result.json", "w") as stream:
        json.dump(output, stream, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
