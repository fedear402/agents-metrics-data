import json

import numpy as np
import pandas as pd
from scipy.special import expit
from statsmodels.miscmodels.ordinal_model import OrderedModel


def main():
    data = pd.read_csv("input.csv")
    required = ["id", "y", "x", "z"]
    if list(data.columns) != required:
        raise ValueError(f"Unexpected columns: {list(data.columns)}")
    if data[required].isna().any().any():
        raise ValueError("Input contains missing values")
    if len(data) != 420 or not set(data["y"].unique()).issubset({1, 2, 3}):
        raise ValueError("Invalid estimation sample")

    model = OrderedModel(data["y"], data[["x", "z"]], distr="logit")
    fit = model.fit(method="bfgs", disp=False, gtol=1e-10, maxiter=1000)

    threshold = model.transform_threshold_params(fit.params)
    linear_predictor = float(fit.params.iloc[0] * 1.0 + fit.params.iloc[1] * 0.0)
    prob_high = float(expit(linear_predictor - threshold[2]))
    predicted = float(model.predict(fit.params, exog=np.array([[1.0, 0.0]]))[0, 2])
    if not np.isclose(prob_high, predicted, rtol=1e-10, atol=1e-12):
        raise RuntimeError("Independent probability check failed")

    n_obs = int(len(data))
    rows = [
        {"term": "x", "estimate": float(fit.params.iloc[0]), "se": float(fit.bse.iloc[0]), "n_obs": n_obs},
        {"term": "z", "estimate": float(fit.params.iloc[1]), "se": float(fit.bse.iloc[1]), "n_obs": n_obs},
        {"term": "prob_high", "estimate": prob_high, "se": None, "n_obs": n_obs},
    ]
    result = {
        "task_id": "broad_ordered_logit",
        "platform": "python",
        "estimates": rows,
        "method_metadata": {
            "estimator": "maximum likelihood ordered logit with two free cutpoints and no intercept",
            "vcov": "conventional observed-information standard errors",
        },
        "diagnostics": {},
    }
    with open("result.json", "w") as stream:
        json.dump(result, stream, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
