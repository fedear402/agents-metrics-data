import json
import numpy as np
import pandas as pd


def shock_iv(dependent, endogenous, instrument, mass, shock):
    n = len(shock)
    regressors = np.column_stack((np.ones(n), endogenous))
    instruments = np.column_stack((np.ones(n), instrument))
    cross = instruments.T @ (mass[:, None] * regressors)
    rhs = instruments.T @ (mass * dependent)
    beta = np.linalg.solve(cross, rhs)
    residual = dependent - regressors @ beta
    scores = instruments * (mass * residual)[:, None]
    inv_cross = np.linalg.inv(cross)
    covariance = (n / (n - 2)) * inv_cross @ (scores.T @ scores) @ inv_cross.T
    return float(beta[1]), float(np.sqrt(covariance[1, 1]))


df = pd.read_csv("input.csv")
region = df.drop_duplicates("region_id").copy()
region_weight = region["region_weight"].to_numpy(float)
e = region_weight / region_weight.sum()
x = region["x"].to_numpy(float)
y = region["y"].to_numpy(float)
share_table = df.pivot(index="region_id", columns="industry_id", values="share").reindex(region["region_id"])
shares = share_table.to_numpy(float)
industry = df.drop_duplicates("industry_id").set_index("industry_id").reindex(share_table.columns)
shock = industry["shock"].to_numpy(float)
z = shares @ shock

means = np.array([e @ y, e @ x, e @ z])
centered = np.column_stack((y, x, z)) - means
mass = e @ shares
used = mass > 0
mass = mass[used]
shock = shock[used]
bar = (shares[:, used].T @ (e[:, None] * centered)) / mass[:, None]

effect, effect_se = shock_iv(bar[:, 0], bar[:, 1], shock, mass, shock)
first_stage, first_stage_se = shock_iv(bar[:, 1], bar[:, 2], shock, mass, shock)
effective = float(1.0 / np.sum(mass ** 2))
n_ind = int(len(shock))

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": effect, "se": effect_se, "n_obs": n_ind},
        {"term": "first_stage", "estimate": first_stage, "se": first_stage_se, "n_obs": n_ind},
        {"term": "effective_shocks", "estimate": effective, "se": None, "n_obs": n_ind},
    ],
    "method_metadata": {
        "estimator": "shock-level weighted IV with intercept and regional shift-share exposure",
        "vcov": "HC1, structural IV residuals, analytic shock-mass weights",
    },
    "diagnostics": {},
}
with open("result.json", "w") as f:
    json.dump(result, f, indent=2, allow_nan=False)

# Independent checks: direct weighted regional IV formulas must equal the
# shock-level slopes, and exposure masses must sum to one.
regional_cross = np.column_stack((np.ones(len(x)), z)).T @ (e[:, None] * np.column_stack((np.ones(len(x)), x)))
regional_rhs = np.column_stack((np.ones(len(x)), z)).T @ (e * y)
regional_beta = np.linalg.solve(regional_cross, regional_rhs)[1]
regional_first = (e @ ((x - e @ x) * (z - e @ z))) / (e @ ((z - e @ z) ** 2))
checks = [
    f"regions={len(region)} industries_total={len(industry)} industries_used={n_ind} rows={len(df)}",
    f"max_share_sum_error={np.max(np.abs(shares.sum(axis=1) - 1)):.3e}",
    f"mass_sum={mass.sum():.12f}",
    f"effect_shock={effect:.12f} effect_regional={regional_beta:.12f} difference={effect-regional_beta:.3e}",
    f"first_stage_shock={first_stage:.12f} first_stage_regional={regional_first:.12f} difference={first_stage-regional_first:.3e}",
]
with open("verification.txt", "w") as f:
    f.write("\n".join(checks) + "\n")
