import json
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.special import log_ndtr
from statsmodels.tools.numdiff import approx_hess


def main():
    df = pd.read_csv("input.csv")
    y = df["y"].to_numpy(dtype=float)
    X = np.column_stack([np.ones(len(df)), df["x"].to_numpy(float), df["z"].to_numpy(float)])
    cens = y <= 0.0

    def loglike(p):
        beta = p[:3]
        sigma = np.exp(p[3])
        eta = X @ beta
        t = (y - eta) / sigma
        ll = np.empty(len(y))
        ll[~cens] = -np.log(sigma) - 0.5*np.log(2*np.pi) - 0.5*t[~cens]**2
        ll[cens] = log_ndtr(-eta[cens] / sigma)
        return ll.sum()

    def grad_loglike(p):
        beta = p[:3]
        sigma = np.exp(p[3])
        eta = X @ beta
        t = (y - eta) / sigma
        g = np.zeros(4)
        g[:3] += (X[~cens].T @ t[~cens]) / sigma
        g[3] += np.sum(-1.0 + t[~cens]**2)
        q = -eta[cens] / sigma
        mills = np.exp(-0.5*q*q - 0.5*np.log(2*np.pi) - log_ndtr(q))
        g[:3] += X[cens].T @ (-mills / sigma)
        g[3] += np.sum(-q * mills)
        return g

    yp = y[~cens]
    Xp = X[~cens]
    b0 = np.linalg.lstsq(Xp, yp, rcond=None)[0]
    s0 = np.std(yp - Xp @ b0)
    start = np.r_[b0, np.log(max(s0, 0.1))]
    fit = minimize(lambda p: -loglike(p), start, jac=lambda p: -grad_loglike(p), method="BFGS",
                   options={"gtol": 1e-10, "maxiter": 2000})
    if not fit.success:
        fit = minimize(lambda p: -loglike(p), fit.x, jac=lambda p: -grad_loglike(p), method="BFGS",
                       options={"gtol": 1e-9, "maxiter": 2000})
    p = fit.x
    H = approx_hess(p, lambda q: -loglike(q), epsilon=1e-5)
    cov = np.linalg.inv(H)
    se = np.sqrt(np.diag(cov))
    n = int(len(df))
    estimates = [
        {"term": name, "estimate": float(val), "se": (float(err) if name != "sigma" else None), "n_obs": n}
        for name, val, err in zip(["const", "x", "z"], p[:3], se[:3])
    ]
    estimates.append({"term": "sigma", "estimate": float(np.exp(p[3])), "se": None, "n_obs": n})
    out = {"task_id": "broad_tobit", "platform": "python", "estimates": estimates,
           "method_metadata": {"estimator": "homoskedastic Gaussian Tobit maximum likelihood",
                                "vcov": "inverse observed information (negative Hessian of joint log-likelihood)"},
           "diagnostics": {}}
    with open("result.json", "w") as f:
        json.dump(out, f, indent=2)
    # Independent checks: direct likelihood recomputation and finite-difference score.
    eps = 1e-6
    score = np.array([(loglike(p + np.eye(4)[j]*eps) - loglike(p - np.eye(4)[j]*eps))/(2*eps) for j in range(4)])
    direct = np.sum(np.where(cens, log_ndtr(-(X@p[:3])/np.exp(p[3])),
                             -np.log(np.exp(p[3])) - .5*np.log(2*np.pi) - .5*((y-X@p[:3])/np.exp(p[3]))**2))
    with open("verification.txt", "w") as f:
        f.write(f"Rows read: {n}; zero-censored rows: {int(cens.sum())}; positive rows: {int((~cens).sum())}.\n")
        f.write(f"Optimizer success: {fit.success}; convergence message: {fit.message}\n")
        f.write(f"Log likelihood from objective: {loglike(p):.12f}; direct recomputation: {direct:.12f}; difference: {abs(loglike(p)-direct):.3e}\n")
        f.write(f"Independent central check, symmetric finite-difference score norm: {np.linalg.norm(score):.3e}; score: {score}\n")
        f.write(f"Analytic score norm: {np.linalg.norm(grad_loglike(p)):.3e}\n")
        f.write("Model uses all rows, y<=0 as left-censored, regressors [1, x, z], and log_sigma parameterization.\n")


if __name__ == "__main__":
    main()
