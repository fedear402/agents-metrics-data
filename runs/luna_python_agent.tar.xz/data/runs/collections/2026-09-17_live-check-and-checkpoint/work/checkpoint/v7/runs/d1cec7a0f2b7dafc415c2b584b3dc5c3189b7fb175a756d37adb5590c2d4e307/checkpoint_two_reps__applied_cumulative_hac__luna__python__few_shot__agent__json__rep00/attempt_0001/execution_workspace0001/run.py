import json

import numpy as np
import pandas as pd


def main():
    data = pd.read_csv("input.csv", parse_dates=["date"])
    data = data.sort_values("date").reset_index(drop=True)

    data["log_sales"] = np.log(data["sales"])
    data["volatility_change"] = np.log(data["vix"]).diff()
    for lag in range(1, 16):
        data[f"lag_{lag}"] = data["volatility_change"].shift(lag)

    lag_names = [f"lag_{lag}" for lag in range(1, 16)]
    sample = data.dropna(subset=["log_sales", *lag_names]).copy()
    y = sample["log_sales"].to_numpy(dtype=float)
    x = np.column_stack([np.ones(len(sample)), sample[lag_names].to_numpy(dtype=float)])
    n_obs = len(y)

    coefficients = np.linalg.lstsq(x, y, rcond=None)[0]
    residuals = y - x @ coefficients
    scores = x * residuals[:, None]

    hac_lags = 15
    meat = scores.T @ scores
    for j in range(1, hac_lags + 1):
        weight = 1.0 - j / 16.0
        lag_product = scores[j:].T @ scores[:-j]
        meat += weight * (lag_product + lag_product.T)
    bread = np.linalg.inv(x.T @ x)
    covariance = (n_obs / (n_obs - 16)) * bread @ meat @ bread

    cumulative_contrast = np.r_[0.0, np.ones(15)]
    cumulative = float(cumulative_contrast @ coefficients)
    cumulative_se = float(np.sqrt(cumulative_contrast @ covariance @ cumulative_contrast))
    rows = [
        {"term": "cumulative_response", "estimate": cumulative, "se": cumulative_se, "n_obs": n_obs},
        {"term": "lag_1", "estimate": float(coefficients[1]), "se": float(np.sqrt(covariance[1, 1])), "n_obs": n_obs},
        {"term": "lag_15", "estimate": float(coefficients[15]), "se": float(np.sqrt(covariance[15, 15])), "n_obs": n_obs},
    ]
    output = {
        "task_id": "applied_cumulative_hac",
        "platform": "python",
        "estimates": rows,
        "method_metadata": {
            "estimator": "OLS with intercept and lags 1 through 15 of first log(vix) difference",
            "vcov": "Bartlett Newey-West HAC, maximum lag 15, correction N/(N-16)",
        },
        "diagnostics": {},
    }
    with open("result.json", "w") as stream:
        json.dump(output, stream, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
