import json

import numpy as np
import pandas as pd
import statsmodels.api as sm


df = pd.read_csv("input.csv")
needed = ["y_lin", "x1", "x2"]
est = df[needed].dropna()
X = sm.add_constant(est[["x1", "x2"]], has_constant="add")
y = est["y_lin"]

fit = sm.OLS(y, X).fit(cov_type="HC1")
n_obs = int(fit.nobs)
terms = ["const", "x1", "x2"]
out = {
    "task_id": "ols_robust",
    "platform": "python",
    "estimates": [
        {
            "term": term,
            "estimate": float(fit.params[term]),
            "se": float(fit.bse[term]),
            "n_obs": n_obs,
        }
        for term in terms
    ],
    "method_metadata": {"estimator": "OLS", "vcov": "HC1"},
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(out, f)

# Independent HC1 calculation using the sandwich matrix identity.
Xv = X.to_numpy(dtype=float)
yv = y.to_numpy(dtype=float)
beta = np.linalg.solve(Xv.T @ Xv, Xv.T @ yv)
resid = yv - Xv @ beta
meat = Xv.T @ ((resid**2)[:, None] * Xv)
hc1 = (n_obs / (n_obs - Xv.shape[1])) * np.linalg.solve(
    Xv.T @ Xv, meat @ np.linalg.inv(Xv.T @ Xv)
)
independent_se = np.sqrt(np.diag(hc1))
if not np.allclose(beta, fit.params.to_numpy(), rtol=1e-10, atol=1e-12):
    raise AssertionError("Independent OLS coefficients do not match statsmodels")
if not np.allclose(independent_se, fit.bse.to_numpy(), rtol=1e-10, atol=1e-12):
    raise AssertionError("Independent HC1 standard errors do not match statsmodels")

with open("verification.txt", "w") as f:
    f.write(f"Estimation sample: {n_obs} complete observations from y_lin, x1, x2.\n")
    f.write("Model: OLS of y_lin on const, x1, and x2.\n")
    f.write("Uncertainty: HC1 sandwich covariance, factor n/(n-k).\n")
    f.write("Independent check: direct normal equations and HC1 sandwich calculation.\n")
    f.write("Result: coefficients and standard errors match statsmodels within 1e-10 relative tolerance.\n")
