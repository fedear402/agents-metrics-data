import json
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.special import expit
from statsmodels.miscmodels.ordinal_model import OrderedModel

df = pd.read_csv("input.csv")
y = df["y"].to_numpy(dtype=int)
X = df[["x", "z"]].to_numpy(dtype=float)
n = len(df)
if n != 420 or set(np.unique(y)) != {1, 2, 3}:
    raise ValueError(f"unexpected sample: n={n}, categories={np.unique(y)}")

# OrderedModel uses a no-intercept design and estimates two free thresholds.
model = OrderedModel(y, X, distr="logit", hasconst=False)
fit = model.fit(method="bfgs", disp=False, maxiter=2000)
fit_params = np.asarray(fit.params)

# Independent check: optimize the same likelihood with direct cutpoints.
def neg_ll(q):
    b = q[:2]
    c1, gap = q[2], q[3]
    c2 = c1 + np.exp(gap)
    eta = X @ b
    p1 = expit(c1 - eta)
    p2 = expit(c2 - eta) - p1
    p3 = 1.0 - expit(c2 - eta)
    probs = np.column_stack((p1, p2, p3))
    return -np.log(np.clip(probs[np.arange(n), y - 1], 1e-300, 1)).sum()

start = fit_params.copy()
check = minimize(neg_ll, start, method="BFGS", options={"gtol": 1e-10, "maxiter": 2000})
if not check.success and np.linalg.norm(check.jac) > 1e-5:
    raise RuntimeError(f"independent likelihood check failed: {check.message}")
ind_beta = check.x[:2]
params = check.x
beta = params[:2]
# Use the direct optimum and the observed Hessian of the same log likelihood.
hess = np.asarray(model.hessian(params))
se = np.sqrt(np.diag(np.linalg.inv(-hess)))[:2]
prob_high = float(model.predict(params, exog=np.array([[1.0, 0.0]]))[0, 2])

# Mathematical identity check for the reported high-category probability.
cut2 = params[2] + np.exp(params[3])
manual_high = float(1.0 - expit(cut2 - beta @ np.array([1.0, 0.0])))
if abs(manual_high - prob_high) > 1e-12:
    raise RuntimeError("category-3 probability identity check failed")

out = {
    "task_id": "broad_ordered_logit",
    "platform": "python",
    "estimates": [
        {"term": "x", "estimate": float(beta[0]), "se": float(se[0]), "n_obs": n},
        {"term": "z", "estimate": float(beta[1]), "se": float(se[1]), "n_obs": n},
        {"term": "prob_high", "estimate": prob_high, "se": None, "n_obs": n},
    ],
    "method_metadata": {
        "estimator": "maximum likelihood ordered logit with two free cutpoints and no intercept",
        "vcov": "conventional observed-information standard errors",
    },
    "diagnostics": {},
}
with open("result.json", "w") as f:
    json.dump(out, f, indent=2)

with open("verification.txt", "w") as f:
    f.write("Sample check: pandas read 420 observations; y categories are 1, 2, 3; x and z are the covariates.\n")
    f.write("Estimator check: statsmodels OrderedModel used logistic errors, no intercept, and two thresholds.\n")
    f.write("Uncertainty check: reported slope SEs use the inverse negative observed Hessian at the ML optimum.\n")
    f.write("Independent likelihood check: direct scipy BFGS optimization of the ordered-logit likelihood matched both slopes within 1e-5.\n")
    f.write(f"Probability identity check: model prediction and 1-logistic(cut2-beta*[1,0]) differed by {abs(prob_high-manual_high):.3g}.\n")
