import json

import numpy as np
import pandas as pd
import statsmodels.api as sm


def main():
    data = pd.read_csv("input.csv")
    n_obs = len(data)
    if set(data.columns) != {"id", "y", "x", "z"}:
        raise ValueError("Unexpected columns")
    if data[["y", "x", "z"]].isna().any().any():
        raise ValueError("Missing estimation values")
    if set(data["y"].unique()) != {0, 1, 2}:
        raise ValueError("Outcomes must be 0, 1, and 2")

    X = sm.add_constant(data[["x", "z"]], has_constant="add")
    fit = sm.MNLogit(data["y"], X).fit(disp=False, method="newton", tol=1e-12, maxiter=200)

    # Statsmodels columns enumerate non-base equations: 0 -> outcome 1, 1 -> outcome 2.
    params = fit.params.copy()
    bse = fit.bse.copy()
    params.columns = [1, 2]
    bse.columns = [1, 2]

    at_zero = pd.DataFrame({"const": [1.0], "x": [0.0], "z": [0.0]})
    p2_zero = float(np.asarray(fit.predict(at_zero))[0, 2])
    rows = []
    for term, variable, outcome in [
        ("x_cat1", "x", 1), ("z_cat1", "z", 1),
        ("x_cat2", "x", 2), ("z_cat2", "z", 2),
    ]:
        rows.append({"term": term, "estimate": float(params.loc[variable, outcome]),
                     "se": float(bse.loc[variable, outcome]), "n_obs": n_obs})
    rows.append({"term": "prob_cat2_zero", "estimate": p2_zero, "se": None, "n_obs": n_obs})
    output = {
        "task_id": "broad_multinomial_logit", "platform": "python", "estimates": rows,
        "method_metadata": {"estimator": "multinomial logit maximum likelihood", "vcov": "conventional observed information"},
        "diagnostics": {},
    }
    with open("result.json", "w") as stream:
        json.dump(output, stream, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
