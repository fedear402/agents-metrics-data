import json
import numpy as np
import pandas as pd


def fit_local(y, x, side, weights):
    # Columns are side-specific intercept and slope, with the requested intercepts.
    z = np.column_stack([
        (side == -1).astype(float),
        (side == -1).astype(float) * x,
        (side == 1).astype(float),
        (side == 1).astype(float) * x,
    ])
    sw = np.sqrt(weights)
    zw = z * sw[:, None]
    yw = y * sw
    beta = np.linalg.solve(zw.T @ zw, zw.T @ yw)
    resid = y - z @ beta
    bread = np.linalg.inv(zw.T @ zw)
    meat = z.T @ ((weights ** 2 * resid ** 2)[:, None] * z)
    cov = bread @ meat @ bread
    return beta, cov, resid, z


def main():
    df = pd.read_csv("input.csv")
    sample = df.loc[df["score"].abs() < 1].copy()
    x = sample["score"].to_numpy(float)
    side = np.where(x < 0, -1, 1)
    weights = 1.0 - np.abs(x)
    y_e = sample["earnings"].to_numpy(float)
    y_p = sample["participated"].to_numpy(float)
    be, ce, re, z = fit_local(y_e, x, side, weights)
    bp, cp, rp, _ = fit_local(y_p, x, side, weights)
    # right limit minus left limit
    contrast = np.array([-1.0, 0.0, 1.0, 0.0])
    rf = float(contrast @ be)
    fs = float(contrast @ bp)
    var_rf = float(contrast @ ce @ contrast)
    var_fs = float(contrast @ cp @ contrast)
    # Joint HC0 covariance for the two outcomes, using the common design and sample.
    bread = np.linalg.inv((z * np.sqrt(weights)[:, None]).T @ (z * np.sqrt(weights)[:, None]))
    meat_ep = z.T @ ((weights ** 2 * re * rp)[:, None] * z)
    cov_ep = bread @ meat_ep @ bread
    cov_rf_fs = float(contrast @ cov_ep @ contrast)
    te = rf / fs
    var_te = var_rf / fs**2 + rf**2 * var_fs / fs**4 - 2 * rf * cov_rf_fs / fs**3
    se_te = float(np.sqrt(max(0.0, var_te)))
    n = int(len(sample))
    result = {
        "task_id": "applied_fuzzy_rd",
        "platform": "python",
        "estimates": [
            {"term": "treatment_effect", "estimate": te, "se": se_te, "n_obs": n},
            {"term": "reduced_form", "estimate": rf, "se": float(np.sqrt(var_rf)), "n_obs": n},
            {"term": "first_stage", "estimate": fs, "se": float(np.sqrt(var_fs)), "n_obs": n},
        ],
        "method_metadata": {
            "estimator": "fuzzy local-linear RD, triangular weights, bandwidth 1, cutoff 0",
            "vcov": "HC0 fixed-weight sandwich; delta method with joint covariance",
        },
        "diagnostics": {},
    }
    with open("result.json", "w") as f:
        json.dump(result, f, indent=2)
    # Independent checks: direct weighted normal equations and covariance identity.
    be_direct = np.linalg.solve(z.T @ (weights[:, None] * z), z.T @ (weights * y_e))
    direct_rf = float(contrast @ be_direct)
    ratio_identity = rf / fs
    with open("verification.txt", "w") as f:
        f.write(f"Sample check: abs(score)<1, n_obs={n}, negative={int((x<0).sum())}, nonnegative={int((x>=0).sum())}.\n")
        f.write(f"Independent direct weighted-normal-equation reduced_form={direct_rf:.12g}; scripted={rf:.12g}; difference={direct_rf-rf:.3g}.\n")
        f.write(f"Ratio identity reduced_form/first_stage={ratio_identity:.12g}; treatment_effect={te:.12g}; difference={ratio_identity-te:.3g}.\n")
        f.write(f"Joint covariance used for delta method: cov(reduced_form, first_stage)={cov_rf_fs:.12g}.\n")


if __name__ == "__main__":
    main()
