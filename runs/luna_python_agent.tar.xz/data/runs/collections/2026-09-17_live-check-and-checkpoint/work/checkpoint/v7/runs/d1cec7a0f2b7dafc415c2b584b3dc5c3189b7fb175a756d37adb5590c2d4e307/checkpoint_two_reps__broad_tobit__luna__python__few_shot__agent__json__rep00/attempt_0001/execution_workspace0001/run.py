import json
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.stats import norm
from statsmodels.tools.numdiff import approx_hess

data = pd.read_csv('input.csv')
y = data['y'].to_numpy(float)
X = data[['x', 'z']].to_numpy(float)
X = np.column_stack((np.ones(len(y)), X))
n = len(y)
censored = y <= 0.0
uncensored = ~censored

def loss(theta):
    mu = X @ theta[:3]
    sigma = np.exp(theta[3])
    a = -mu[censored] / sigma
    r = (y[uncensored] - mu[uncensored]) / sigma
    return float(-norm.logcdf(a).sum() - (norm.logpdf(r) - np.log(sigma)).sum())

def gradient(theta):
    mu = X @ theta[:3]
    sigma = np.exp(theta[3])
    a = -mu[censored] / sigma
    mills = np.exp(norm.logpdf(a) - norm.logcdf(a))
    r = (y[uncensored] - mu[uncensored]) / sigma
    beta_score = X[censored].T @ (mills / sigma)
    beta_score -= X[uncensored].T @ (r / sigma)
    log_sigma_score = np.sum(a * mills) + np.sum(1.0 - r * r)
    return np.r_[beta_score, log_sigma_score]

ols = np.linalg.lstsq(X, y, rcond=None)[0]
sigma0 = np.sqrt(np.mean((y - X @ ols) ** 2))
initial = np.r_[ols, np.log(max(sigma0, 1e-6))]
fit = minimize(loss, initial, jac=gradient, method='BFGS', options={'gtol': 1e-9, 'maxiter': 2000})
if not fit.success and np.max(np.abs(gradient(fit.x))) > 1e-5:
    fit = minimize(loss, fit.x, jac=gradient, method='L-BFGS-B', options={'ftol': 1e-15, 'gtol': 1e-10, 'maxiter': 5000})
assert np.isfinite(loss(fit.x))
assert np.max(np.abs(gradient(fit.x))) < 2e-5

def numerical_gradient(theta):
    out = np.empty(4)
    for j in range(4):
        h = 1e-5
        step = np.zeros(4)
        step[j] = h
        out[j] = (loss(theta + step) - loss(theta - step)) / (2 * h)
    return out

gradient_checks = []
for point in (initial, np.array([0.4, 0.8, -0.3, np.log(1.2)])):
    err = float(np.max(np.abs(gradient(point) - numerical_gradient(point))))
    gradient_checks.append(err)
assert max(gradient_checks) < 2e-5

information = approx_hess(fit.x, loss)
information = (information + information.T) / 2.0
eigenvalues = np.linalg.eigvalsh(information)
assert eigenvalues.min() > 0
covariance = np.linalg.inv(information)
beta = fit.x[:3]
sigma = float(np.exp(fit.x[3]))
se_beta = np.sqrt(np.diag(covariance)[:3])

output = {
    'task_id': 'broad_tobit',
    'platform': 'python',
    'estimates': [
        {'term': 'const', 'estimate': float(beta[0]), 'se': float(se_beta[0]), 'n_obs': n},
        {'term': 'x', 'estimate': float(beta[1]), 'se': float(se_beta[1]), 'n_obs': n},
        {'term': 'z', 'estimate': float(beta[2]), 'se': float(se_beta[2]), 'n_obs': n},
        {'term': 'sigma', 'estimate': sigma, 'se': None, 'n_obs': n},
    ],
    'method_metadata': {
        'estimator': 'Gaussian Tobit maximum likelihood with left censoring at zero',
        'vcov': 'inverse observed information from the joint likelihood in (beta, log_sigma)',
    },
    'diagnostics': {},
}
with open('result.json', 'w') as stream:
    json.dump(output, stream, indent=2, allow_nan=False)

with open('verification.txt', 'w') as stream:
    stream.write(f'Rows read: {n}; censored y=0: {int(censored.sum())}; uncensored y>0: {int(uncensored.sum())}.\n')
    stream.write('Variables: intercept, x, and z; all rows included in the likelihood.\n')
    stream.write(f'Converged objective: {loss(fit.x):.12f}; max absolute score: {np.max(np.abs(gradient(fit.x))):.3e}.\n')
    stream.write('Independent central-difference score checks: ' + ', '.join(f'{v:.3e}' for v in gradient_checks) + '.\n')
    stream.write(f'Observed-information eigenvalues: {eigenvalues.tolist()}.\n')
    stream.write('The positive eigenvalues verify local positive curvature. Standard errors use the full inverse Hessian.\n')
