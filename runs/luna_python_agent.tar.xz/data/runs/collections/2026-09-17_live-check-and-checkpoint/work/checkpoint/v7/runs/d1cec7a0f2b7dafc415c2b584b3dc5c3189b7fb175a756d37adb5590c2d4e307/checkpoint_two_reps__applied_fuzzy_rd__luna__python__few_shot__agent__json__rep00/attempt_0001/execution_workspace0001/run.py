import json
import numpy as np
import pandas as pd


def main():
    df = pd.read_csv("input.csv")
    sample = df.loc[df["score"].abs() < 1].copy()
    x = sample["score"].to_numpy(float)
    right = (x >= 0).astype(float)
    weights = 1.0 - np.abs(x)
    X = np.column_stack((np.ones(len(x)), x, right, right * x))
    Y = sample[["earnings", "participated"]].to_numpy(float)

    bread = np.linalg.inv(X.T @ (weights[:, None] * X))
    beta = bread @ X.T @ (weights[:, None] * Y)
    residuals = Y - X @ beta
    contrast = np.array([0.0, 0.0, 1.0, 0.0])
    jumps = contrast @ beta
    loading = weights * (X @ bread @ contrast)
    influence = loading[:, None] * residuals
    joint = influence.T @ influence

    earnings_jump, participation_jump = jumps
    gradient = np.array([1.0 / participation_jump,
                         -earnings_jump / participation_jump**2])
    ratio = earnings_jump / participation_jump
    ratio_se = np.sqrt(gradient @ joint @ gradient)
    n_obs = int(len(sample))
    rows = [
        {"term": "treatment_effect", "estimate": float(ratio),
         "se": float(ratio_se), "n_obs": n_obs},
        {"term": "reduced_form", "estimate": float(earnings_jump),
         "se": float(np.sqrt(joint[0, 0])), "n_obs": n_obs},
        {"term": "first_stage", "estimate": float(participation_jump),
         "se": float(np.sqrt(joint[1, 1])), "n_obs": n_obs},
    ]
    output = {
        "task_id": "applied_fuzzy_rd",
        "platform": "python",
        "estimates": rows,
        "method_metadata": {
            "estimator": "triangular-weighted local-linear fuzzy RD",
            "vcov": "conventional heteroskedasticity-robust HC0"
        },
        "diagnostics": {}
    }
    with open("result.json", "w") as stream:
        json.dump(output, stream, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
