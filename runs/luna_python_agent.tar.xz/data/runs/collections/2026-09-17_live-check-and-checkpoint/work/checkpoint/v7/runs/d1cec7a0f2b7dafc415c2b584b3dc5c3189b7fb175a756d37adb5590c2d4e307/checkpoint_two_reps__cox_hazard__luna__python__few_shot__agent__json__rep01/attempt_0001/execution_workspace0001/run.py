import json

import numpy as np
import pandas as pd
from statsmodels.duration.hazard_regression import PHReg


df = pd.read_csv("input.csv")
required = ["subject", "treat", "x", "t_obs", "event"]
if any(c not in df.columns for c in required):
    raise ValueError("input.csv is missing a required column")

analysis = df[["treat", "x", "t_obs", "event"]].dropna().copy()
if (analysis["t_obs"] <= 0).any():
    raise ValueError("Cox durations must be positive")

fit = PHReg(
    analysis["t_obs"].to_numpy(),
    analysis[["treat", "x"]].to_numpy(),
    status=analysis["event"].to_numpy(),
    ties="breslow",
).fit()

n_obs = int(len(analysis))
out = {
    "task_id": "cox_hazard",
    "platform": "python",
    "estimates": [
        {"term": term, "estimate": float(fit.params[i]),
         "se": float(fit.bse[i]), "n_obs": n_obs}
        for i, term in enumerate(["treat", "x"])
    ],
    "method_metadata": {
        "estimator": "Cox proportional-hazards model, Breslow ties",
        "vcov": "model-based asymptotic covariance",
    },
    "diagnostics": {},
}
with open("result.json", "w") as f:
    json.dump(out, f)
