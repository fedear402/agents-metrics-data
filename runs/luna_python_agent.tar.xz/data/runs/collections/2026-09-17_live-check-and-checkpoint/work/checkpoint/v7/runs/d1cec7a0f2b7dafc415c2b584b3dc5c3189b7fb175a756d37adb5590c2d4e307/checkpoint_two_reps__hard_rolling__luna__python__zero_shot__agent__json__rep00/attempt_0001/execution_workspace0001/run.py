import json
import math
import numpy as np
import pandas as pd


def main():
    data = pd.read_csv("input.csv").sort_values("time").reset_index(drop=True)
    if len(data) != 250 or list(data["time"]) != list(range(1, 251)):
        raise ValueError("input must contain ordered times 1 through 250")
    y = data["y"].to_numpy(dtype=float)
    forecasts = {}
    errors = []
    for f in range(101, 251):
        # Levels y_(f-100), ..., y_(f-1), with pairs s=f-99, ..., f-1.
        levels = y[f - 101:f - 1]  # zero-based representation of the 100 levels
        x = levels[:-1]
        target = levels[1:]
        X = np.column_stack((np.ones(99), x))
        coef = np.linalg.lstsq(X, target, rcond=None)[0]
        forecast = float(coef[0] + coef[1] * y[f - 2])
        forecasts[f] = forecast
        errors.append(y[f - 1] - forecast)
    rmse = math.sqrt(float(np.dot(errors, errors)) / 150.0)
    terms = [
        {"term": "rmse", "estimate": rmse, "se": None, "n_obs": 150},
        *[{"term": f"forecast_{f}", "estimate": forecasts[f], "se": None, "n_obs": 99}
          for f in (101, 150, 200, 250)],
    ]
    result = {
        "task_id": "hard_rolling",
        "platform": "python",
        "estimates": terms,
        "method_metadata": {"estimator": "rolling OLS AR(1) with intercept", "vcov": "none"},
        "diagnostics": {},
    }
    with open("result.json", "w") as handle:
        json.dump(result, handle, indent=2)


if __name__ == "__main__":
    main()
