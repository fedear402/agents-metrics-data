import json

import numpy as np
import pandas as pd


def main():
    df = pd.read_csv("input.csv")
    cols = ["y_iv", "x1_iv", "z"]
    sample = df[cols].dropna().copy()
    y = sample["y_iv"].to_numpy(dtype=float)[:, None]
    x = np.column_stack((np.ones(len(sample)), sample["x1_iv"].to_numpy(dtype=float)))
    instruments = np.column_stack((np.ones(len(sample)), sample["z"].to_numpy(dtype=float)))

    # Two-stage least squares: beta = (X'PzX)^(-1) X'PzY.
    ztz_inv = np.linalg.inv(instruments.T @ instruments)
    pz_x = instruments @ ztz_inv @ instruments.T @ x
    pz_y = instruments @ ztz_inv @ instruments.T @ y
    a = x.T @ pz_x
    beta = np.linalg.solve(a, x.T @ pz_y).ravel()

    # HC1 sandwich covariance for IV, with n/(n-k) small-sample correction.
    residual = y.ravel() - x @ beta
    z_score = instruments.T @ ((residual**2)[:, None] * instruments)
    middle = x.T @ instruments @ ztz_inv @ z_score @ ztz_inv @ instruments.T @ x
    cov = np.linalg.solve(a, middle)
    cov = np.linalg.solve(a, cov.T).T * (len(sample) / (x.shape[1]))
    se = np.sqrt(np.diag(cov))

    out = {
        "task_id": "iv2sls_robust",
        "platform": "python",
        "estimates": [
            {"term": "const", "estimate": float(beta[0]), "se": float(se[0]), "n_obs": int(len(sample))},
            {"term": "x1_iv", "estimate": float(beta[1]), "se": float(se[1]), "n_obs": int(len(sample))},
        ],
        "method_metadata": {"estimator": "Two-stage least squares", "vcov": "HC1 robust"},
        "diagnostics": {},
    }
    with open("result.json", "w") as f:
        json.dump(out, f)


if __name__ == "__main__":
    main()
