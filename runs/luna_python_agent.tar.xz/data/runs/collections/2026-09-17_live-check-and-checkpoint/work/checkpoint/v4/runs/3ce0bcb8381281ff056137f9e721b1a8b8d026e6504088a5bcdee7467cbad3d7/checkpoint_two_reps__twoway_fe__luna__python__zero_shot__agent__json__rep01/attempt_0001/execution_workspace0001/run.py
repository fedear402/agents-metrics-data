import json
import numpy as np
import pandas as pd
import statsmodels.api as sm


def main():
    df = pd.read_csv("input.csv")
    required = ["firm", "year", "x", "y_twocluster"]
    missing = [v for v in required if v not in df.columns]
    if missing:
        raise ValueError(f"Missing columns: {missing}")
    sample = df[required].dropna().copy()
    n = len(sample)

    # Firm and year fixed effects, with one omitted category per dimension.
    X = pd.concat(
        [sample[["x"]], pd.get_dummies(sample["firm"], drop_first=True, dtype=float),
         pd.get_dummies(sample["year"], drop_first=True, dtype=float)], axis=1
    )
    X = sm.add_constant(X, has_constant="add").astype(float)
    y = sample["y_twocluster"].astype(float)
    fit = sm.OLS(y, X).fit(cov_type="cluster", cov_kwds={"groups": sample["firm"]})
    x_pos = X.columns.get_loc("x")
    estimate = float(fit.params.iloc[x_pos])
    se = float(fit.bse.iloc[x_pos])

    # Independent numerical check: remove firm and year means from x and y.
    xd = sample["x"] - sample.groupby("firm")["x"].transform("mean") - sample.groupby("year")["x"].transform("mean") + sample["x"].mean()
    yd = sample["y_twocluster"] - sample.groupby("firm")["y_twocluster"].transform("mean") - sample.groupby("year")["y_twocluster"].transform("mean") + sample["y_twocluster"].mean()
    check_estimate = float((xd * yd).sum() / (xd * xd).sum())

    # Cluster covariance from the within-regression, with statsmodels' finite-sample correction.
    residual = yd - check_estimate * xd
    bread = 1.0 / float((xd * xd).sum())
    scores = sample.assign(score=xd * residual).groupby("firm")["score"].sum().to_numpy()
    raw_var = bread * bread * float((scores * scores).sum())
    g = sample["firm"].nunique()
    k = 2 + sample["firm"].nunique() - 1 + sample["year"].nunique() - 1
    correction = (g / (g - 1.0)) * ((n - 1.0) / (n - k))
    check_se = float(np.sqrt(raw_var * correction))

    result = {
        "task_id": "twoway_fe",
        "platform": "python",
        "estimates": [{"term": "x", "estimate": estimate, "se": se, "n_obs": int(n)}],
        "method_metadata": {"estimator": "OLS with firm and year fixed effects", "vcov": "firm-clustered (small-sample corrected)"},
        "diagnostics": {},
    }
    with open("result.json", "w") as f:
        json.dump(result, f, indent=2)
    with open("verification.txt", "w") as f:
        f.write(f"Rows in estimation sample: {n}; firms: {g}; years: {sample['year'].nunique()}.\n")
        f.write("The sample uses complete observations for firm, year, x, and y_twocluster.\n")
        f.write(f"Dummy-variable OLS x coefficient: {estimate:.12g}\n")
        f.write(f"Double-demeaned x coefficient: {check_estimate:.12g}; absolute difference: {abs(estimate-check_estimate):.3g}\n")
        f.write(f"Statsmodels clustered SE: {se:.12g}; independent cluster-meat SE: {check_se:.12g}; absolute difference: {abs(se-check_se):.3g}\n")


if __name__ == "__main__":
    main()
