import json

import numpy as np
import pandas as pd
import statsmodels.api as sm


def main():
    df = pd.read_csv("input.csv")
    # For each t, regress y[t+4] on shock[t] and y[t-1].
    df["y_lead4"] = df["y"].shift(-4)
    df["y_lag1"] = df["y"].shift(1)
    sample = df.dropna(subset=["y_lead4", "shock", "y_lag1"]).copy()

    X = sm.add_constant(sample[["shock", "y_lag1"]], has_constant="add")
    fit = sm.OLS(sample["y_lead4"], X).fit(
        cov_type="HAC", cov_kwds={"maxlags": 4, "use_correction": True}
    )
    result = {
        "task_id": "lp_irf",
        "platform": "python",
        "estimates": [{
            "term": "irf_h4",
            "estimate": float(fit.params["shock"]),
            "se": float(fit.bse["shock"]),
            "n_obs": int(fit.nobs),
        }],
        "method_metadata": {
            "estimator": "OLS local projection with intercept",
            "vcov": "Newey-West HAC, lag 4",
        },
        "diagnostics": {},
    }
    with open("result.json", "w") as handle:
        json.dump(result, handle, indent=2)

    # Independent checks: normal equations for beta and explicit HAC meat.
    xv = np.asarray(X, dtype=float)
    yv = sample["y_lead4"].to_numpy(dtype=float)
    beta = np.linalg.solve(xv.T @ xv, xv.T @ yv)
    resid = yv - xv @ beta
    meat = xv.T @ (resid[:, None] ** 2 * xv)
    for lag in range(1, 5):
        weight = 1.0 - lag / 5.0
        cross = xv[lag:].T @ (resid[lag:, None] * resid[:-lag, None] * xv[:-lag])
        meat += weight * (cross + cross.T)
    n = len(yv)
    cov = (n / (n - xv.shape[1])) * np.linalg.inv(xv.T @ xv) @ meat @ np.linalg.inv(xv.T @ xv)
    with open("verification.txt", "w") as handle:
        handle.write(f"rows in input: {len(df)}\n")
        handle.write(f"estimation t range: {int(sample.t.iloc[0])} to {int(sample.t.iloc[-1])}\n")
        handle.write(f"n_obs: {n}\n")
        handle.write(f"statsmodels shock coefficient: {fit.params['shock']:.15g}\n")
        handle.write(f"normal-equation shock coefficient: {beta[1]:.15g}\n")
        handle.write(f"statsmodels HAC shock se: {fit.bse['shock']:.15g}\n")
        handle.write(f"explicit HAC shock se: {np.sqrt(cov[1, 1]):.15g}\n")
        handle.write(f"coefficient match: {np.allclose(fit.params['shock'], beta[1], rtol=1e-12, atol=1e-12)}\n")
        handle.write(f"SE match: {np.allclose(fit.bse['shock'], np.sqrt(cov[1, 1]), rtol=1e-12, atol=1e-12)}\n")


if __name__ == "__main__":
    main()
