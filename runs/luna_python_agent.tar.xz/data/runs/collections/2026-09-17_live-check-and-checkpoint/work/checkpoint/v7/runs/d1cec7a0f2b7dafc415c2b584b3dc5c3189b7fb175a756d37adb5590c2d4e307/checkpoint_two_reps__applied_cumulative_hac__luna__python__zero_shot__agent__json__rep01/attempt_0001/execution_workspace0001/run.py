import json
import numpy as np
import pandas as pd


def main():
    df = pd.read_csv("input.csv", parse_dates=["date"]).sort_values("date").reset_index(drop=True)
    df["log_sales"] = np.log(df["sales"])
    df["dlog_vix"] = np.log(df["vix"]).diff()
    for j in range(1, 16):
        df[f"lag_{j}"] = df["dlog_vix"].shift(j)
    sample = df.dropna(subset=["log_sales"] + [f"lag_{j}" for j in range(1, 16)]).copy()

    y = sample["log_sales"].to_numpy(float)
    lag_names = [f"lag_{j}" for j in range(1, 16)]
    X = np.column_stack([np.ones(len(sample)), sample[lag_names].to_numpy(float)])
    beta = np.linalg.solve(X.T @ X, X.T @ y)
    resid = y - X @ beta

    # HAC covariance with Bartlett weights 1-j/16 for j=1,...,15.
    n = len(y)
    meat = X.T @ (resid[:, None] ** 2 * X)
    for j in range(1, 16):
        cross = X[j:].T @ (resid[j:, None] * resid[:-j, None] * X[:-j])
        meat += (1.0 - j / 16.0) * (cross + cross.T)
    bread = np.linalg.inv(X.T @ X)
    cov = (n / (n - 16.0)) * bread @ meat @ bread

    cumulative = float(beta[1:].sum())
    cumulative_var = float(np.ones(15) @ cov[1:, 1:] @ np.ones(15))
    estimates = [
        {"term": "cumulative_response", "estimate": cumulative,
         "se": float(np.sqrt(max(cumulative_var, 0.0))), "n_obs": int(n)},
        {"term": "lag_1", "estimate": float(beta[1]), "se": float(np.sqrt(max(cov[1, 1], 0.0))), "n_obs": int(n)},
        {"term": "lag_15", "estimate": float(beta[15]), "se": float(np.sqrt(max(cov[15, 15], 0.0))), "n_obs": int(n)},
    ]
    result = {
        "task_id": "applied_cumulative_hac",
        "platform": "python",
        "estimates": estimates,
        "method_metadata": {
            "estimator": "OLS with intercept and trading-observation lags 1 through 15 of first-differenced log(vix)",
            "vcov": "Newey-West HAC, Bartlett weights 1-j/16 for j=1,...,15, scaled by N/(N-16)",
        },
        "diagnostics": {},
    }
    with open("result.json", "w") as f:
        json.dump(result, f, indent=2)


if __name__ == "__main__":
    main()
