import json

import pandas as pd
from statsmodels.tsa.arima.model import ARIMA


def main():
    data = pd.read_csv("input.csv")
    y = pd.to_numeric(data["y"], errors="raise").dropna()
    if len(y) != len(data) or len(y) < 3:
        raise ValueError("y must contain a numeric, complete estimation series")

    fit = ARIMA(y, order=(1, 1, 1), trend="n").fit()
    prediction = fit.get_forecast(steps=1)
    forecast = float(prediction.predicted_mean.iloc[0])
    se = float(prediction.se_mean.iloc[0])
    z = 1.959963984540054
    lower = forecast - z * se
    upper = forecast + z * se
    n_obs = int(fit.nobs)

    output = {
        "task_id": "arima_forecast",
        "platform": "python",
        "estimates": [
            {"term": "forecast", "estimate": forecast, "se": se, "n_obs": n_obs},
            {"term": "lower_95", "estimate": lower, "se": None, "n_obs": n_obs},
            {"term": "upper_95", "estimate": upper, "se": None, "n_obs": n_obs},
        ],
        "method_metadata": {
            "estimator": "ARIMA(1,1,1) by maximum likelihood, no constant or drift",
            "vcov": "model-based Gaussian prediction interval",
        },
        "diagnostics": {},
    }
    with open("result.json", "w") as handle:
        json.dump(output, handle)


if __name__ == "__main__":
    main()
