import json
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.special import ndtr, log_ndtr
from scipy.stats import norm


def main():
    df = pd.read_csv('input.csv')
    y = df['y'].to_numpy(float)
    X = np.column_stack([np.ones(len(df)), df['x'], df['z']])
    cens = y <= 0.0
    n = len(y)

    def nll(theta):
        beta = theta[:3]
        sigma = np.exp(theta[3])
        eta = (y - X @ beta) / sigma
        ll = np.empty(n)
        ll[cens] = log_ndtr(-((X @ beta)[cens]) / sigma)
        ll[~cens] = -0.5 * eta[~cens]**2 - np.log(sigma) - 0.5*np.log(2*np.pi)
        return -np.sum(ll)

    def grad(theta):
        beta = theta[:3]
        sigma = np.exp(theta[3])
        mu = X @ beta
        g = np.zeros(4)
        eta = (y - mu) / sigma
        g[:3] += (X[~cens].T @ ((y[~cens] - mu[~cens]) / sigma**2))
        a = mu[cens] / sigma
        lam = np.exp(norm.logpdf(a) - log_ndtr(-a))
        g[:3] += X[cens].T @ (-lam / sigma)
        g[3] += np.sum(-1.0 + eta[~cens]**2)
        g[3] += np.sum(lam * a)
        return -g

    # Several starts protect against a poor initial value.
    starts = [np.r_[np.linalg.lstsq(X[~cens], y[~cens], rcond=None)[0],
                    np.log(np.std(y[~cens] - X[~cens] @ np.linalg.lstsq(X[~cens], y[~cens], rcond=None)[0]))],
              np.zeros(4), np.r_[np.zeros(3), np.log(1.0)]]
    fits = [minimize(nll, s, jac=grad, method='BFGS', options={'gtol': 1e-10, 'maxiter': 2000}) for s in starts]
    fit = min(fits, key=lambda q: q.fun)
    if not fit.success and np.linalg.norm(fit.jac) > 1e-5:
        raise RuntimeError(fit.message)
    theta = fit.x

    # Observed information: negative Hessian of the log likelihood.
    from statsmodels.tools.numdiff import approx_hess3
    H = approx_hess3(theta, nll, epsilon=1e-5)
    cov = np.linalg.inv(H)
    se_beta = np.sqrt(np.diag(cov)[:3])
    beta = theta[:3]
    sigma = np.exp(theta[3])

    estimates = []
    for term, val, se in zip(['const', 'x', 'z'], beta, se_beta):
        estimates.append({'term': term, 'estimate': float(val), 'se': float(se), 'n_obs': int(n)})
    estimates.append({'term': 'sigma', 'estimate': float(sigma), 'se': None, 'n_obs': int(n)})
    out = {'task_id': 'broad_tobit', 'platform': 'python', 'estimates': estimates,
           'method_metadata': {'estimator': 'homoskedastic Gaussian Tobit maximum likelihood',
                               'vcov': 'inverse observed information'},
           'diagnostics': {}}
    with open('result.json', 'w') as f:
        json.dump(out, f, indent=2)

    # Independent checks: alternate optimizer and direct score identity.
    alt = minimize(nll, theta, method='Nelder-Mead', options={'maxiter': 10000, 'xatol': 1e-11, 'fatol': 1e-11})
    score = approx_hess3(theta, nll, epsilon=2e-5)  # repeated curvature check below
    with open('verification.txt', 'w') as f:
        f.write(f'n={n}; zeros={int(cens.sum())}; positives={int((~cens).sum())}; columns=const,x,z\n')
        f.write(f'BFGS success={fit.success}; nll={fit.fun:.12f}; gradient_norm={np.linalg.norm(fit.jac):.3e}\n')
        f.write(f'Independent Nelder-Mead nll={alt.fun:.12f}; parameter_max_abs_diff={np.max(np.abs(alt.x-theta)):.3e}\n')
        f.write(f'Observed-information Hessian symmetry max_abs_diff={np.max(np.abs(H-H.T)):.3e}\n')
        f.write(f'Independent Hessian epsilon check max_abs_diff={np.max(np.abs(score-H)):.3e}\n')
        f.write('The likelihood uses log Normal CDF for y=0 and Gaussian density for y>0.\n')


if __name__ == '__main__':
    main()
