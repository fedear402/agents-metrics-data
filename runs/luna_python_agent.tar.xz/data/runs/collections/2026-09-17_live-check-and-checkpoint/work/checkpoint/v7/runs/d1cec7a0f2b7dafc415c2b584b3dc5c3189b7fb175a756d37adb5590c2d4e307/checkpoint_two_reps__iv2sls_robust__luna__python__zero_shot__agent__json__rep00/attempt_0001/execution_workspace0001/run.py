import json
import numpy as np
import pandas as pd


def main():
    data = pd.read_csv("input.csv")
    variables = ["y_iv", "x1_iv", "z"]
    sample = data[variables].dropna()
    y = sample["y_iv"].to_numpy(dtype=float)[:, None]
    x = np.column_stack((np.ones(len(sample)), sample["x1_iv"].to_numpy(dtype=float)))
    z = np.column_stack((np.ones(len(sample)), sample["z"].to_numpy(dtype=float)))
    n, k = x.shape

    # Two-stage least squares: Pz projects onto the intercept and instrument.
    ztz_inv = np.linalg.inv(z.T @ z)
    pz = z @ ztz_inv @ z.T
    xpx_inv = np.linalg.inv(x.T @ pz @ x)
    beta = xpx_inv @ (x.T @ pz @ y)
    resid = y - x @ beta

    # HC1 sandwich covariance for the 2SLS estimator.
    middle = x.T @ pz @ np.diagflat(resid[:, 0] ** 2) @ pz @ x
    vcov = (n / (n - k)) * xpx_inv @ middle @ xpx_inv
    se = np.sqrt(np.diag(vcov))

    output = {
        "task_id": "iv2sls_robust",
        "platform": "python",
        "estimates": [
            {"term": "const", "estimate": float(beta[0, 0]), "se": float(se[0]), "n_obs": int(n)},
            {"term": "x1_iv", "estimate": float(beta[1, 0]), "se": float(se[1]), "n_obs": int(n)},
        ],
        "method_metadata": {"estimator": "2SLS", "vcov": "HC1 robust"},
        "diagnostics": {},
    }
    with open("result.json", "w") as handle:
        json.dump(output, handle, indent=2)


if __name__ == "__main__":
    main()
