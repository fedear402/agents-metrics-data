import json
import numpy as np
import pandas as pd


def fit_local(y, x, side, weights):
    z = (side == 1).astype(float)
    # Separate intercepts and slopes: [left intercept, left slope,
    # right intercept, right slope].
    X = np.column_stack([1 - z, x * (1 - z), z, x * z])
    bread = np.linalg.inv(X.T @ (weights[:, None] * X))
    beta = bread @ X.T @ (weights * y)
    resid = y - X @ beta
    return beta, resid, X, bread


def main():
    df = pd.read_csv("input.csv")
    sample = df.loc[df["score"].abs() < 1].copy()
    x = sample["score"].to_numpy(float)
    side = (x >= 0).astype(int)
    w = 1.0 - np.abs(x)
    outcomes = [sample["earnings"].to_numpy(float),
                sample["participated"].to_numpy(float)]

    fits = [fit_local(y, x, side, w) for y in outcomes]
    # Right-limit intercept minus left-limit intercept.
    c = np.array([-1.0, 0.0, 1.0, 0.0])
    jumps = np.array([c @ fit[0] for fit in fits])
    joint = np.empty((2, 2))
    for a in range(2):
        for b in range(2):
            Xa, bread = fits[a][2], fits[a][3]
            Xb = fits[b][2]
            cross = bread @ Xa.T @ np.diag(w ** 2 * fits[a][1] * fits[b][1]) @ Xb @ bread
            joint[a, b] = c @ cross @ c

    ratio = jumps[0] / jumps[1]
    gradient = np.array([1.0 / jumps[1], -jumps[0] / jumps[1] ** 2])
    ratio_se = float(np.sqrt(gradient @ joint @ gradient))
    n = int(len(sample))
    rows = [
        {"term": "treatment_effect", "estimate": float(ratio), "se": ratio_se, "n_obs": n},
        {"term": "reduced_form", "estimate": float(jumps[0]), "se": float(np.sqrt(joint[0, 0])), "n_obs": n},
        {"term": "first_stage", "estimate": float(jumps[1]), "se": float(np.sqrt(joint[1, 1])), "n_obs": n},
    ]
    output = {
        "task_id": "applied_fuzzy_rd",
        "platform": "python",
        "estimates": rows,
        "method_metadata": {
            "estimator": "fuzzy local-linear regression discontinuity, triangular weights",
            "vcov": "conventional HC0, fixed bandwidth and weights, joint delta method",
        },
        "diagnostics": {},
    }
    with open("result.json", "w") as f:
        json.dump(output, f, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
