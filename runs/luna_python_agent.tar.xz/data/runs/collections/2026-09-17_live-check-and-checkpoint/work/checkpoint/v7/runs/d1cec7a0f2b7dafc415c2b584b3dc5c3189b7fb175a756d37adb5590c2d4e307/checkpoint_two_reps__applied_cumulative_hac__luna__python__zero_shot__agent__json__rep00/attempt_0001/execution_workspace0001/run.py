import json
import numpy as np
import pandas as pd
import statsmodels.api as sm


def main():
    df = pd.read_csv("input.csv")
    df["date"] = pd.to_datetime(df["date"])
    df = df.sort_values("date").reset_index(drop=True)

    dlog_vix = np.log(df["vix"].to_numpy())[1:] - np.log(df["vix"].to_numpy())[:-1]
    y_all = np.log(df["sales"].to_numpy())
    # At original row t, lag j is the change from rows t-j-1 to t-j.
    rows = np.arange(16, len(df))
    y = y_all[rows]
    x = np.column_stack([dlog_vix[rows - j - 1] for j in range(1, 16)])
    X = sm.add_constant(x, has_constant="add")
    fit = sm.OLS(y, X).fit()

    # Bartlett HAC covariance, with the requested N/(N-16) multiplier.
    u = fit.resid
    N, K = X.shape
    scores = X * u[:, None]
    meat = scores.T @ scores
    for j in range(1, 16):
        weight = 1.0 - j / 16.0
        cross = scores[j:].T @ scores[:-j]
        meat += weight * (cross + cross.T)
    bread = np.linalg.inv(X.T @ X)
    cov = (N / (N - 16.0)) * bread @ meat @ bread
    se = np.sqrt(np.diag(cov))

    cumulative = float(np.sum(fit.params[1:]))
    cumulative_var = float(np.ones(15) @ cov[1:, 1:] @ np.ones(15))
    estimates = [
        {"term": "cumulative_response", "estimate": cumulative,
         "se": float(np.sqrt(cumulative_var)), "n_obs": int(N)},
        {"term": "lag_1", "estimate": float(fit.params[1]),
         "se": float(se[1]), "n_obs": int(N)},
        {"term": "lag_15", "estimate": float(fit.params[15]),
         "se": float(se[15]), "n_obs": int(N)},
    ]
    result = {
        "task_id": "applied_cumulative_hac",
        "platform": "python",
        "estimates": estimates,
        "method_metadata": {
            "estimator": "OLS with intercept and trading-observation lags 1-15",
            "vcov": "Newey-West HAC max lag 15, Bartlett weights, multiplied by N/(N-16)",
        },
        "diagnostics": {},
    }
    with open("result.json", "w") as f:
        json.dump(result, f, indent=2)


if __name__ == "__main__":
    main()
