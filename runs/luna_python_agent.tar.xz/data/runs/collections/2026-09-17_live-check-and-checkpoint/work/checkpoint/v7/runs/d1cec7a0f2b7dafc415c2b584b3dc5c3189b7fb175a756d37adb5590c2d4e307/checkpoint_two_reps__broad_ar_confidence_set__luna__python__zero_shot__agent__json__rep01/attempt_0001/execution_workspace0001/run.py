import json
import numpy as np
import pandas as pd
from scipy.stats import f as f_dist
import statsmodels.api as sm

df = pd.read_csv('input.csv')
n = len(df)
y = df['y'].to_numpy(float)
e = df['endog'].to_numpy(float)
X0 = sm.add_constant(df[['x']].to_numpy(float), has_constant='add')
Z = df[['z1', 'z2']].to_numpy(float)
X = np.column_stack([X0, Z])
df_res = n - 4
crit = f_dist.ppf(0.95, 2, df_res)

def ssr(beta, design):
    r = y - beta * e
    fit = sm.OLS(r, design).fit()
    return float(np.dot(fit.resid, fit.resid))

def ar_f(beta):
    sr = ssr(beta, X0)
    su = ssr(beta, X)
    return ((sr - su) / 2.0) / (su / df_res)

def quad(fun):
    vals = np.array([fun(-1.0), fun(0.0), fun(1.0)])
    return np.array([(vals[2] + vals[0] - 2 * vals[1]) / 2,
                     (vals[2] - vals[0]) / 2, vals[1]])

cr = quad(lambda b: ssr(b, X0))
cu = quad(lambda b: ssr(b, X))
cd = cr - cu
h = df_res * cd - 2.0 * crit * cu
roots = np.sort(np.roots(h).real) if abs(h[0]) > 1e-12 else np.sort(np.roots(h[1:]).real)
boundary_low, boundary_high = float(roots[0]), float(roots[-1])
accepts_zero = float(ar_f(0.0) <= crit)
unbounded = float(h[0] < 0)

out = {
    'task_id': 'broad_ar_confidence_set',
    'platform': 'python',
    'estimates': [
        {'term': 'boundary_low', 'estimate': boundary_low, 'se': None, 'n_obs': n},
        {'term': 'boundary_high', 'estimate': boundary_high, 'se': None, 'n_obs': n},
        {'term': 'accepts_zero', 'estimate': accepts_zero, 'se': None, 'n_obs': n},
        {'term': 'unbounded', 'estimate': unbounded, 'se': None, 'n_obs': n},
        {'term': 'ar_f_at_one', 'estimate': ar_f(1.0), 'se': None, 'n_obs': n},
    ],
    'method_metadata': {'estimator': 'Anderson-Rubin inverted homoskedastic joint F test',
                        'vcov': 'conventional homoskedastic'},
    'diagnostics': {}
}
with open('result.json', 'w') as f:
    json.dump(out, f, indent=2)
