import json
import numpy as np
import pandas as pd


def shock_iv(dependent, endogenous, instrument, weights, shocks):
    n = len(shocks)
    X = np.column_stack((np.ones(n), endogenous))
    Z = np.column_stack((np.ones(n), shocks))
    cross = Z.T @ (weights[:, None] * X)
    beta = np.linalg.solve(cross, Z.T @ (weights * dependent))
    residual = dependent - X @ beta
    scores = Z * (weights * residual)[:, None]
    inv_cross = np.linalg.inv(cross)
    hc1 = n / (n - 2)
    cov = hc1 * inv_cross @ (scores.T @ scores) @ inv_cross.T
    return float(beta[1]), float(np.sqrt(cov[1, 1]))


df = pd.read_csv("input.csv")
region = df.drop_duplicates("region_id").copy()
region_weight = region["region_weight"].to_numpy(float)
e = region_weight / region_weight.sum()
region_ids = region["region_id"].to_numpy()

# Preserve the region order used for all regional arrays.
df = df.set_index("region_id").loc[region_ids].reset_index()
share = df.pivot(index="region_id", columns="industry_id", values="share").loc[region_ids].fillna(0.0)
shock_by_industry = df.groupby("industry_id")["shock"].first()
industries = share.columns.to_numpy()
shock = shock_by_industry.reindex(industries).to_numpy(float)
S = share.to_numpy(float)

x = region["x"].to_numpy(float)
y = region["y"].to_numpy(float)
z = S @ shock
regional = np.column_stack((y, x, z))
centered = regional - e @ regional

mass = e @ S
keep = mass > 0
mass = mass[keep]
shock = shock[keep]
aggregated = (S[:, keep].T @ (e[:, None] * centered)) / mass[:, None]
ybar, xbar, zbar = aggregated.T

effect, effect_se = shock_iv(ybar, xbar, shock, mass, shock)
first_stage, first_stage_se = shock_iv(xbar, zbar, shock, mass, shock)
effective = float(1.0 / np.sum(mass ** 2))
n_industry = int(len(mass))

output = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": effect, "se": effect_se, "n_obs": n_industry},
        {"term": "first_stage", "estimate": first_stage, "se": first_stage_se, "n_obs": n_industry},
        {"term": "effective_shocks", "estimate": effective, "se": None, "n_obs": n_industry},
    ],
    "method_metadata": {
        "estimator": "weighted shock-level IV with intercept",
        "vcov": "shock-level HC1, structural IV residuals, analytic weights",
    },
    "diagnostics": {},
}
with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
