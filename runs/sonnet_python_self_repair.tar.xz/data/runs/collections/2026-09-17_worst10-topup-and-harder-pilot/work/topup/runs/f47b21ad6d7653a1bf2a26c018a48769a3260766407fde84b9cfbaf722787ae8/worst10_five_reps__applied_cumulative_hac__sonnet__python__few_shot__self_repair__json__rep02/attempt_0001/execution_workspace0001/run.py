import json
import numpy as np
import pandas as pd

data = pd.read_csv("input.csv")
data = data.sort_values("date").reset_index(drop=True)
data["log_vix"] = np.log(data["vix"])
data["vix_change"] = data["log_vix"].diff()
data["log_sales"] = np.log(data["sales"])

for lag in range(1, 16):
    data[f"lag_{lag}"] = data["vix_change"].shift(lag)

sample = data.dropna(subset=["log_sales"] + [f"lag_{i}" for i in range(1, 16)])
N = len(sample)

lag_cols = [f"lag_{i}" for i in range(1, 16)]
X = np.column_stack([np.ones(N)] + [sample[c].to_numpy() for c in lag_cols])
y = sample["log_sales"].to_numpy()

coefficients = np.linalg.lstsq(X, y, rcond=None)[0]
residuals = y - X @ coefficients

scores = X * residuals[:, None]
hac_lags = 15
meat = scores.T @ scores
for j in range(1, hac_lags + 1):
    weight = 1 - j / (hac_lags + 1)
    lag_product = scores[j:].T @ scores[:-j]
    meat += weight * (lag_product + lag_product.T)

bread = np.linalg.inv(X.T @ X)
p = X.shape[1]
covariance = (N / (N - p)) * bread @ meat @ bread

contrast = np.array([0.0] + [1.0] * 15)
cumulative = float(contrast @ coefficients)
cumulative_se = float(np.sqrt(contrast @ covariance @ contrast))

lag1_est = float(coefficients[1])
lag1_se = float(np.sqrt(covariance[1, 1]))
lag15_est = float(coefficients[15])
lag15_se = float(np.sqrt(covariance[15, 15]))

output = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {"term": "cumulative_response", "estimate": cumulative, "se": cumulative_se, "n_obs": N},
        {"term": "lag_1", "estimate": lag1_est, "se": lag1_se, "n_obs": N},
        {"term": "lag_15", "estimate": lag15_est, "se": lag15_se, "n_obs": N},
    ],
    "method_metadata": {"estimator": "OLS", "vcov": "Newey-West HAC lag 15 Bartlett N/(N-16)"},
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(output, f, indent=2, allow_nan=False)
