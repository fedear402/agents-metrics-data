import pandas as pd
import numpy as np
import json
from statsmodels.regression.linear_model import OLS
from statsmodels.tools import add_constant

df = pd.read_csv('input.csv')
df = df.sort_values('date').reset_index(drop=True)

df['log_sales'] = np.log(df['sales'])
df['log_vix'] = np.log(df['vix'])
df['d_log_vix'] = df['log_vix'].diff()

for lag in range(1, 16):
    df[f'lag_{lag}'] = df['d_log_vix'].shift(lag)

lag_cols = [f'lag_{i}' for i in range(1, 16)]
df_model = df[['log_sales'] + lag_cols].dropna().reset_index(drop=True)

y = df_model['log_sales']
X = add_constant(df_model[lag_cols])

N = len(df_model)

model = OLS(y, X).fit()

# Newey-West with max lag 15, Bartlett weights 1-j/16
# Manual implementation
residuals = model.resid.values
X_vals = X.values
n, k = X_vals.shape

# Meat of sandwich
XtX_inv = np.linalg.inv(X_vals.T @ X_vals)

# Compute S (HAC meat)
xe = X_vals * residuals[:, None]

S = xe.T @ xe  # lag 0

for j in range(1, 16):
    weight = 1 - j / 16
    gamma = xe[j:].T @ xe[:-j]
    S += weight * (gamma + gamma.T)

# HAC covariance with N/(N-16) adjustment
scale = N / (N - 16)
cov_hac = scale * XtX_inv @ S @ XtX_inv

# Coefficients (excluding intercept)
coef = model.params
lag_names = lag_cols

# Cumulative response: sum of lag_1 through lag_15 coefficients
# Intercept is index 0, lags are indices 1-15
lag_indices = list(range(1, 16))
cum_response = sum(coef.iloc[i] for i in lag_indices)

# SE for cumulative response using full covariance matrix
c = np.zeros(k)
for i in lag_indices:
    c[i] = 1.0
cum_var = c @ cov_hac @ c
cum_se = np.sqrt(cum_var)

# SE for individual lags
se_all = np.sqrt(np.diag(cov_hac))

lag1_idx = 1  # index in X (after intercept)
lag15_idx = 15

lag1_coef = coef.iloc[lag1_idx]
lag1_se = se_all[lag1_idx]

lag15_coef = coef.iloc[lag15_idx]
lag15_se = se_all[lag15_idx]

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {"term": "cumulative_response", "estimate": float(cum_response), "se": float(cum_se), "n_obs": int(N)},
        {"term": "lag_1", "estimate": float(lag1_coef), "se": float(lag1_se), "n_obs": int(N)},
        {"term": "lag_15", "estimate": float(lag15_coef), "se": float(lag15_se), "n_obs": int(N)}
    ],
    "method_metadata": {
        "estimator": "OLS",
        "vcov": "Newey-West HAC, max_lag=15, Bartlett weights 1-j/16, scaled N/(N-16)"
    },
    "diagnostics": {}
}

with open('result.json', 'w') as f:
    json.dump(result, f, indent=2)
