import json
import numpy as np
import pandas as pd

df = pd.read_csv('input.csv')

# One obs per region for weights
regions = df.drop_duplicates('region_id')[['region_id', 'region_weight', 'x', 'y']].copy()
regions['e_r'] = regions['region_weight'] / regions['region_weight'].sum()

# Compute shift-share instrument per region
df_z = df.groupby('region_id').apply(lambda g: (g['share'] * g['shock']).sum()).reset_index()
df_z.columns = ['region_id', 'z']
regions = regions.merge(df_z, on='region_id')

e_r = regions['e_r'].values
x_r = regions['x'].values
y_r = regions['y'].values
z_r = regions['z'].values

# Subtract e_r-weighted means
x0 = x_r - np.sum(e_r * x_r)
y0 = y_r - np.sum(e_r * y_r)
z0 = z_r - np.sum(e_r * z_r)

# Industry-level aggregation
industries = df['industry_id'].unique()
N = len(industries)

# s_n = sum_r e_r * share_rn
# vbar_n = sum_r e_r * share_rn * v0_r / s_n
region_idx = {r: i for i, r in enumerate(regions['region_id'].values)}

s_n = np.zeros(N)
ybar_n = np.zeros(N)
xbar_n = np.zeros(N)
zbar_n = np.zeros(N)
shock_n = np.zeros(N)

for j, ind in enumerate(industries):
    sub = df[df['industry_id'] == ind]
    # shock is constant within industry
    shock_n[j] = sub['shock'].iloc[0]
    for _, row in sub.iterrows():
        i = region_idx[row['region_id']]
        w = e_r[i] * row['share']
        s_n[j] += w
        ybar_n[j] += w * y0[i]
        xbar_n[j] += w * x0[i]
        zbar_n[j] += w * z0[i]
    ybar_n[j] /= s_n[j]
    xbar_n[j] /= s_n[j]
    zbar_n[j] /= s_n[j]

def shock_iv(dependent, endogenous, instrument, weights):
    n = len(dependent)
    regressors = np.column_stack([np.ones(n), endogenous])
    instruments = np.column_stack([np.ones(n), instrument])
    W = weights
    cross = instruments.T @ (W[:, None] * regressors)
    beta = np.linalg.solve(cross, instruments.T @ (W * dependent))
    residual = dependent - regressors @ beta
    scores = instruments * (W * residual)[:, None]
    inverse = np.linalg.inv(cross)
    hc1 = n / (n - 2)
    covariance = hc1 * inverse @ (scores.T @ scores) @ inverse.T
    return float(beta[1]), float(np.sqrt(covariance[1, 1]))

effect, effect_se = shock_iv(ybar_n, xbar_n, shock_n, s_n)
first_stage, first_stage_se = shock_iv(xbar_n, zbar_n, shock_n, s_n)

effective_shocks = float(1.0 / np.sum(s_n ** 2))

output = {
    'task_id': 'applied_shift_share',
    'platform': 'python',
    'estimates': [
        {'term': 'effect', 'estimate': effect, 'se': effect_se, 'n_obs': N},
        {'term': 'first_stage', 'estimate': first_stage, 'se': first_stage_se, 'n_obs': N},
        {'term': 'effective_shocks', 'estimate': effective_shocks, 'se': None, 'n_obs': N},
    ],
    'method_metadata': {'estimator': 'shift_share_IV_BHJ', 'vcov': 'HC1_shock_level'},
    'diagnostics': {}
}

with open('result.json', 'w') as f:
    json.dump(output, f, indent=2, allow_nan=False)
