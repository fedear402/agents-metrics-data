import pandas as pd
import numpy as np
import json
from statsmodels.regression.linear_model import OLS, WLS

df = pd.read_csv('input.csv')
df.columns = df.columns.str.strip()

bw = 1.0
mask = np.abs(df['score']) < bw
data = df[mask].copy()
n_obs = len(data)

data['w'] = 1 - np.abs(data['score'])
data['above'] = (data['score'] >= 0).astype(float)
data['score_above'] = data['score'] * data['above']
data['score_below'] = data['score'] * (1 - data['above'])

X = pd.DataFrame({
    'const': 1.0,
    'above': data['above'],
    'score_below': data['score_below'],
    'score_above': data['score_above']
})

W = np.diag(data['w'].values)

def wls_hc0(X_df, y_series, weights):
    X_mat = X_df.values
    y = y_series.values
    w = weights.values
    W_sqrt = np.sqrt(w)
    Xw = X_mat * W_sqrt[:, None]
    yw = y * W_sqrt
    XtX_inv = np.linalg.inv(Xw.T @ Xw)
    beta = XtX_inv @ (Xw.T @ yw)
    resid = y - X_mat @ beta
    meat = (Xw * (resid * W_sqrt)[:, None]).T @ (Xw * (resid * W_sqrt)[:, None])
    # HC0: sum of outer products of weighted residuals
    # Correct: V = (X'WX)^{-1} * sum(w_i^2 * e_i^2 * x_i x_i') * (X'WX)^{-1}
    # where Xw = sqrt(w)*X, so XtX = X'WX
    # meat should be sum over i of (w_i * e_i)^2 * x_i x_i' ... 
    # Actually for WLS, the weighted residuals are w_i*e_i, 
    # HC0 sandwich: (X'WX)^{-1} [sum w_i^2 e_i^2 x_i x_i'] (X'WX)^{-1}
    meat2 = np.zeros((X_mat.shape[1], X_mat.shape[1]))
    for i in range(len(y)):
        xi = X_mat[i]
        meat2 += (w[i] * resid[i])**2 * np.outer(xi, xi)
    V = XtX_inv @ meat2 @ XtX_inv
    return beta, V

beta_earn, V_earn = wls_hc0(X, data['earnings'], data['w'])
beta_part, V_part = wls_hc0(X, data['participated'], data['w'])

# Discontinuity = coefficient on 'above' (index 1)
rf_est = beta_earn[1]
rf_se = np.sqrt(V_earn[1, 1])

fs_est = beta_part[1]
fs_se = np.sqrt(V_part[1, 1])

# Treatment effect via delta method: te = rf / fs
te_est = rf_est / fs_est

# Joint covariance of (rf, fs) from same observations
# Need cross-covariance between earn and part regressions
X_mat = X.values
w = data['w'].values
XtX_inv_earn = np.linalg.inv((X_mat * w[:, None]).T @ X_mat)
XtX_inv_part = np.linalg.inv((X_mat * w[:, None]).T @ X_mat)
# Same X so same (X'WX)^{-1}
XtWX_inv = XtX_inv_earn

resid_earn = data['earnings'].values - X_mat @ beta_earn
resid_part = data['participated'].values - X_mat @ beta_part

# Cross-covariance meat: sum w_i^2 * e_earn_i * e_part_i * x_i x_i'
meat_cross = np.zeros((X_mat.shape[1], X_mat.shape[1]))
for i in range(len(w)):
    xi = X_mat[i]
    meat_cross += (w[i]**2) * resid_earn[i] * resid_part[i] * np.outer(xi, xi)

V_cross = XtWX_inv @ meat_cross @ XtWX_inv

cov_rf_fs = V_cross[1, 1]

# Delta method: se(te)^2 = (1/fs)^2 * var(rf) + (rf/fs^2)^2 * var(fs) - 2*(rf/fs^3)*cov(rf,fs)
te_var = (1/fs_est)**2 * V_earn[1,1] + (rf_est/fs_est**2)**2 * V_part[1,1] - 2*(rf_est/fs_est**3)*cov_rf_fs
te_se = np.sqrt(te_var)

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": float(te_est), "se": float(te_se), "n_obs": int(n_obs)},
        {"term": "reduced_form", "estimate": float(rf_est), "se": float(rf_se), "n_obs": int(n_obs)},
        {"term": "first_stage", "estimate": float(fs_est), "se": float(fs_se), "n_obs": int(n_obs)}
    ],
    "method_metadata": {
        "estimator": "fuzzy_rd_local_linear_triangular",
        "vcov": "HC0_heteroskedasticity_robust"
    },
    "diagnostics": {}
}

with open('result.json', 'w') as f:
    json.dump(result, f, indent=2)

print("Done. Results:")
for e in result['estimates']:
    print(f"  {e['term']}: {e['estimate']:.6f} (se={e['se']:.6f}, n={e['n_obs']})")
