import pandas as pd
import numpy as np
import json
from statsmodels.regression.linear_model import WLS, OLS

df = pd.read_csv('input.csv')
df.columns = df.columns.str.strip()

bw = 1.0
mask = df['score'].abs() < bw
sub = df[mask].copy()
n_obs = len(sub)

sub['w'] = 1 - sub['score'].abs()
sub['D'] = (sub['score'] >= 0).astype(float)
sub['score_left'] = sub['score'] * (1 - sub['D'])
sub['score_right'] = sub['score'] * sub['D']

X = np.column_stack([
    np.ones(n_obs),
    sub['D'].values,
    sub['score_left'].values,
    sub['score_right'].values
])

w = sub['w'].values
Y_earn = sub['earnings'].values
Y_part = sub['participated'].values

def wls_hc0(X, y, w):
    W = np.diag(w)
    XtW = X.T @ W
    XtWX = XtW @ X
    XtWX_inv = np.linalg.inv(XtWX)
    beta = XtWX_inv @ XtW @ y
    resid = y - X @ beta
    # HC0: sandwich with weighted residuals
    # Score: w_i * x_i * e_i
    meat = np.zeros((X.shape[1], X.shape[1]))
    for i in range(n_obs):
        score_i = w[i] * X[i, :] * resid[i]
        meat += np.outer(score_i, score_i)
    vcov = XtWX_inv @ meat @ XtWX_inv
    return beta, vcov

beta_earn, vcov_earn = wls_hc0(X, Y_earn, w)
beta_part, vcov_part = wls_hc0(X, Y_part, w)

# Discontinuity is coefficient on D (index 1)
rf_est = beta_earn[1]
fs_est = beta_part[1]
rf_se = np.sqrt(vcov_earn[1, 1])
fs_se = np.sqrt(vcov_part[1, 1])

# Delta method for treatment_effect = rf / fs
# Need joint covariance of (rf, fs)
# Fit jointly to get cross-covariance
W = np.diag(w)
XtW = X.T @ W
XtWX = XtW @ X
XtWX_inv = np.linalg.inv(XtWX)

resid_earn = Y_earn - X @ beta_earn
resid_part = Y_part - X @ beta_part

# Cross-covariance meat
meat_cross = np.zeros((X.shape[1], X.shape[1]))
for i in range(n_obs):
    xi = X[i, :]
    meat_cross += w[i]**2 * resid_earn[i] * resid_part[i] * np.outer(xi, xi)

vcov_cross = XtWX_inv @ meat_cross @ XtWX_inv
cov_rf_fs = vcov_cross[1, 1]

# Delta method: te = rf/fs
# d(te)/d(rf) = 1/fs, d(te)/d(fs) = -rf/fs^2
te_est = rf_est / fs_est
g_rf = 1.0 / fs_est
g_fs = -rf_est / fs_est**2
te_var = g_rf**2 * vcov_earn[1,1] + g_fs**2 * vcov_part[1,1] + 2 * g_rf * g_fs * cov_rf_fs
te_se = np.sqrt(te_var)

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": float(te_est), "se": float(te_se), "n_obs": int(n_obs)},
        {"term": "reduced_form", "estimate": float(rf_est), "se": float(rf_se), "n_obs": int(n_obs)},
        {"term": "first_stage", "estimate": float(fs_est), "se": float(fs_se), "n_obs": int(n_obs)}
    ],
    "method_metadata": {
        "estimator": "fuzzy_rd_local_linear_triangular",
        "vcov": "HC0"
    },
    "diagnostics": {}
}

with open('result.json', 'w') as f:
    json.dump(result, f, indent=2)

print(json.dumps(result, indent=2))
