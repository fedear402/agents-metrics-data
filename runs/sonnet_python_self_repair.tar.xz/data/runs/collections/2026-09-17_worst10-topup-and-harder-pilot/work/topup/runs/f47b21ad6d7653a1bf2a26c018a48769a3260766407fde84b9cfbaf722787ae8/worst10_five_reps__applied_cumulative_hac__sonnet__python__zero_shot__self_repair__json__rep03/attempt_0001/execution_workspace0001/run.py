import pandas as pd
import numpy as np
import json
from statsmodels.regression.linear_model import OLS
from statsmodels.tools import add_constant

df = pd.read_csv('input.csv')
df['date'] = pd.to_datetime(df['date'])
df = df.sort_values('date').reset_index(drop=True)

df['log_sales'] = np.log(df['sales'])
df['log_vix'] = np.log(df['vix'])
df['d_log_vix'] = df['log_vix'].diff()

for lag in range(1, 16):
    df[f'lag_{lag}'] = df['d_log_vix'].shift(lag)

lag_cols = [f'lag_{i}' for i in range(1, 16)]
reg_df = df[['log_sales'] + lag_cols].dropna()

y = reg_df['log_sales']
X = add_constant(reg_df[lag_cols])

model = OLS(y, X).fit()
N = len(reg_df)

# Newey-West with max_lags=15, Bartlett weights 1 - j/16
# Manual implementation to match exact specification
resid = model.resid.values
X_vals = X.values
n, k = X_vals.shape

# Meat of sandwich estimator
S = np.zeros((k, k))
# Lag 0
e_x = X_vals * resid[:, None]
S += e_x.T @ e_x

# Lags 1 to 15
for j in range(1, 16):
    w = 1 - j / 16
    gamma = e_x[j:].T @ e_x[:-j]
    S += w * (gamma + gamma.T)

bread = np.linalg.inv(X_vals.T @ X_vals)
# Scale by N/(N-16)
scale = N / (N - 16)
cov_hac = scale * bread @ S @ bread

# Extract coefficients and covariance for lag_1 through lag_15
# Intercept is index 0, lag_1 is index 1, ..., lag_15 is index 15
lag_indices = list(range(1, 16))

coefs = model.params
lag_coefs = coefs.iloc[lag_indices].values

# Cumulative response = sum of lag coefficients
cum_resp = lag_coefs.sum()

# Variance of cumulative response using full covariance matrix
c = np.ones(len(lag_indices))
sub_cov = cov_hac[np.ix_(lag_indices, lag_indices)]
var_cum = c @ sub_cov @ c
se_cum = np.sqrt(var_cum)

# SE for individual lags
se_lag1 = np.sqrt(cov_hac[1, 1])
se_lag15 = np.sqrt(cov_hac[15, 15])

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {"term": "cumulative_response", "estimate": float(cum_resp), "se": float(se_cum), "n_obs": int(N)},
        {"term": "lag_1", "estimate": float(coefs.iloc[1]), "se": float(se_lag1), "n_obs": int(N)},
        {"term": "lag_15", "estimate": float(coefs.iloc[15]), "se": float(se_lag15), "n_obs": int(N)},
    ],
    "method_metadata": {
        "estimator": "OLS",
        "vcov": "Newey-West HAC, max_lag=15, Bartlett weights 1-j/16, scaled N/(N-16)"
    },
    "diagnostics": {}
}

with open('result.json', 'w') as f:
    json.dump(result, f, indent=2)
