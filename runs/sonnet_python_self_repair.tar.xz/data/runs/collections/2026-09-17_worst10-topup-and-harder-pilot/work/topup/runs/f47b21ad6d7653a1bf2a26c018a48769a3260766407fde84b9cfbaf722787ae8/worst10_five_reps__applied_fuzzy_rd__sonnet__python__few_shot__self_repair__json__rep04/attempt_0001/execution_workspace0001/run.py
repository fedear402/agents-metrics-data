import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df.columns = df.columns.str.strip()

bw = 1.0
mask = df["score"].abs() < bw
df = df[mask].copy()
n = len(df)

score = df["score"].values
weights = 1 - np.abs(score)
above = (score >= 0).astype(float)

# Design matrix: [1, above, score, score*above]
X = np.column_stack([
    np.ones(n),
    above,
    score,
    score * above
])

Y = np.column_stack([df["earnings"].values, df["participated"].values])

W = weights
WX = W[:, None] * X
bread = np.linalg.inv(X.T @ WX)
coefficients = bread @ WX.T @ Y
residuals = Y - X @ coefficients

# Contrast for right-limit minus left-limit at score=0
# Right limit: [1,1,0,0] @ coef, Left limit: [1,0,0,0] @ coef
# Difference: [0,1,0,0] @ coef
contrast = np.array([0., 1., 0., 0.])
jumps = contrast @ coefficients  # [earnings_jump, participated_jump]

loading = W * (X @ bread @ contrast)
influence = loading[:, None] * residuals
joint = influence.T @ influence

earnings_jump, takeup_jump = jumps
outcome_se = float(np.sqrt(joint[0, 0]))
takeup_se = float(np.sqrt(joint[1, 1]))
cov_01 = float(joint[0, 1])

gradient = np.array([1.0 / takeup_jump, -earnings_jump / takeup_jump**2])
te_se = float(np.sqrt(gradient @ joint @ gradient))
te = float(earnings_jump / takeup_jump)

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": te, "se": te_se, "n_obs": n},
        {"term": "reduced_form", "estimate": float(earnings_jump), "se": outcome_se, "n_obs": n},
        {"term": "first_stage", "estimate": float(takeup_jump), "se": takeup_se, "n_obs": n},
    ],
    "method_metadata": {
        "estimator": "fuzzy_rd_local_linear",
        "vcov": "HC0"
    },
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2, allow_nan=False)
