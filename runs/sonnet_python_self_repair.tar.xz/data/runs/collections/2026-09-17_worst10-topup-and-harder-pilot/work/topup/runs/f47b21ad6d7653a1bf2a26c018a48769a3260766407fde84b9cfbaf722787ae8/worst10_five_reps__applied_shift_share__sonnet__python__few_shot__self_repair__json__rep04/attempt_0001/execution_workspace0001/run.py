import json
import numpy as np
import pandas as pd

df = pd.read_csv('input.csv')

# One obs per region for weights
regions = df.drop_duplicates('region_id')[['region_id', 'region_weight', 'x', 'y']].copy()
regions['e'] = regions['region_weight'] / regions['region_weight'].sum()

# Construct shift-share instrument per region
df2 = df.merge(regions[['region_id', 'e']], on='region_id')
df2['z'] = df2['share'] * df2['shock']
z_r = df2.groupby('region_id')['z'].sum().reset_index().rename(columns={'z': 'z_r'})
regions = regions.merge(z_r, on='region_id')

e = regions['e'].values
x = regions['x'].values
y = regions['y'].values
z = regions['z_r'].values

# Weighted means
xm = e @ x
ym = e @ y
zm = e @ z

x0 = x - xm
y0 = y - ym
z0 = z - zm

# Industry-level aggregation
industries = df['industry_id'].unique()
industry_list = sorted(industries)
N = len(industry_list)

# Map region to e, x0, y0, z0
region_vals = dict(zip(regions['region_id'], zip(e, x0, y0, z0)))

# For each industry compute s_n and aggregated residuals
s_n = []
xbar_n = []
ybar_n = []
zbar_n = []
shock_n = []

for ind in industry_list:
    sub = df[df['industry_id'] == ind]
    s = 0.0
    xb = 0.0
    yb = 0.0
    zb = 0.0
    for _, row in sub.iterrows():
        rid = row['region_id']
        er, x0r, y0r, z0r = region_vals[rid]
        w = er * row['share']
        s += w
        xb += w * x0r
        yb += w * y0r
        zb += w * z0r
    xbar_n.append(xb / s)
    ybar_n.append(yb / s)
    zbar_n.append(zb / s)
    s_n.append(s)
    shock_n.append(sub['shock'].iloc[0])

s_n = np.array(s_n)
xbar_n = np.array(xbar_n)
ybar_n = np.array(ybar_n)
zbar_n = np.array(zbar_n)
shock_n = np.array(shock_n)

def shock_iv(dependent, endogenous, instrument, weights, N):
    regressors = np.column_stack([np.ones(N), endogenous])
    instruments = np.column_stack([np.ones(N), instrument])
    W = weights
    cross = instruments.T @ (W[:, None] * regressors)
    rhs = instruments.T @ (W * dependent)
    beta = np.linalg.solve(cross, rhs)
    residual = dependent - regressors @ beta
    scores = instruments * (W * residual)[:, None]
    inverse = np.linalg.inv(cross)
    hc1 = N / (N - 2)
    covariance = hc1 * inverse @ (scores.T @ scores) @ inverse.T
    return float(beta[1]), float(np.sqrt(covariance[1, 1]))

effect, effect_se = shock_iv(ybar_n, xbar_n, shock_n, s_n, N)
first_stage, first_stage_se = shock_iv(xbar_n, zbar_n, shock_n, s_n, N)

effective_shocks = float(1.0 / np.sum(s_n ** 2))

# Verify regional slopes match
regional_effect = (e @ (z0 * y0)) / (e @ (z0 * x0))
regional_fs = (e @ (z0 * x0)) / (e @ (z0 ** 2))
assert np.allclose([effect, first_stage], [regional_effect, regional_fs], rtol=1e-5), \
    f"Mismatch: effect={effect} vs {regional_effect}, fs={first_stage} vs {regional_fs}"

output = {
    'task_id': 'applied_shift_share',
    'platform': 'python',
    'estimates': [
        {'term': 'effect', 'estimate': effect, 'se': effect_se, 'n_obs': N},
        {'term': 'first_stage', 'estimate': first_stage, 'se': first_stage_se, 'n_obs': N},
        {'term': 'effective_shocks', 'estimate': effective_shocks, 'se': None, 'n_obs': N},
    ],
    'method_metadata': {'estimator': '2SLS shift-share BHJ', 'vcov': 'HC1 shock-level'},
    'diagnostics': {}
}

with open('result.json', 'w') as f:
    json.dump(output, f, indent=2, allow_nan=False)
