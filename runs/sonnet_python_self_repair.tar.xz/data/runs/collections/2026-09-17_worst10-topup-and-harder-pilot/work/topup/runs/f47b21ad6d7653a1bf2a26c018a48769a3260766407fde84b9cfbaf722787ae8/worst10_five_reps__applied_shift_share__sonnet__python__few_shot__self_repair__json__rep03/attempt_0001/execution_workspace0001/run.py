import json
import numpy as np
import pandas as pd

df = pd.read_csv('input.csv')

# One obs per region for weights
regions = df.drop_duplicates('region_id')[['region_id', 'region_weight', 'x', 'y']].copy()
regions['e'] = regions['region_weight'] / regions['region_weight'].sum()

# Construct instrument z_r = sum_n share_rn * shock_n
z = df.groupby('region_id').apply(lambda g: (g['share'] * g['shock']).sum()).rename('z')
regions = regions.join(z, on='region_id')

e = regions['e'].values
x_r = regions['x'].values
y_r = regions['y'].values
z_r = regions['z'].values

# Subtract e-weighted regional means
x0 = x_r - e @ x_r
y0 = y_r - e @ y_r
z0 = z_r - e @ z_r

# Industry-level aggregation
industries = df['industry_id'].unique()
industry_shocks = df.drop_duplicates('industry_id').set_index('industry_id')['shock']

# s_n = sum_r e_r * share_rn
# For each industry n: vbar_n = sum_r e_r * share_rn * v0_r / s_n

region_index = {r: i for i, r in enumerate(regions['region_id'].values)}
n_industries = len(industries)
industry_list = sorted(industries)

s_n = np.zeros(n_industries)
ybar = np.zeros(n_industries)
xbar = np.zeros(n_industries)
zbar = np.zeros(n_industries)
shock_n = np.zeros(n_industries)

# Build lookup arrays
e_arr = regions.set_index('region_id')['e']
x0_map = dict(zip(regions['region_id'], x0))
y0_map = dict(zip(regions['region_id'], y0))
z0_map = dict(zip(regions['region_id'], z0))

for i, ind in enumerate(industry_list):
    subset = df[df['industry_id'] == ind]
    shock_n[i] = subset['shock'].iloc[0]
    for _, row in subset.iterrows():
        r = row['region_id']
        er = e_arr[r]
        srn = row['share']
        s_n[i] += er * srn
    for _, row in subset.iterrows():
        r = row['region_id']
        er = e_arr[r]
        srn = row['share']
        ybar[i] += er * srn * y0_map[r]
        xbar[i] += er * srn * x0_map[r]
        zbar[i] += er * srn * z0_map[r]
    ybar[i] /= s_n[i]
    xbar[i] /= s_n[i]
    zbar[i] /= s_n[i]

N = n_industries

def shock_iv(dependent, endogenous, instrument, weights):
    regressors = np.column_stack([np.ones(N), endogenous])
    instruments = np.column_stack([np.ones(N), instrument])
    W = weights
    cross = instruments.T @ (W[:,None] * regressors)
    beta = np.linalg.solve(cross, instruments.T @ (W * dependent))
    residual = dependent - regressors @ beta
    scores = instruments * (W * residual)[:,None]
    inverse = np.linalg.inv(cross)
    hc1 = N / (N - 2)
    covariance = hc1 * inverse @ (scores.T @ scores) @ inverse.T
    return float(beta[1]), float(np.sqrt(covariance[1, 1]))

effect, effect_se = shock_iv(ybar, xbar, shock_n, s_n)
first_stage, first_stage_se = shock_iv(xbar, zbar, shock_n, s_n)

effective_shocks = float(1.0 / np.sum(s_n**2))

output = {
    'task_id': 'applied_shift_share',
    'platform': 'python',
    'estimates': [
        {'term': 'effect', 'estimate': effect, 'se': effect_se, 'n_obs': N},
        {'term': 'first_stage', 'estimate': first_stage, 'se': first_stage_se, 'n_obs': N},
        {'term': 'effective_shocks', 'estimate': effective_shocks, 'se': None, 'n_obs': N},
    ],
    'method_metadata': {'estimator': '2SLS_shift_share', 'vcov': 'HC1_shock_level'},
    'diagnostics': {}
}

with open('result.json', 'w') as f:
    json.dump(output, f, indent=2, allow_nan=False)
