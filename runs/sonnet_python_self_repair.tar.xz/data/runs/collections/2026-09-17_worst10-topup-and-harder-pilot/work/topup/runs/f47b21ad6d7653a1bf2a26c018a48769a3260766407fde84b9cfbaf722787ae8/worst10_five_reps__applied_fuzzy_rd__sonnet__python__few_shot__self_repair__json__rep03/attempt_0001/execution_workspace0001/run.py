import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df.columns = df.columns.str.strip()

bw = 1.0
mask = df["score"].abs() < bw
df = df[mask].copy()
n_obs = len(df)

score = df["score"].values
weights = 1 - np.abs(score)
above = (score >= 0).astype(float)

X = np.column_stack([
    np.ones(n_obs),
    above,
    score,
    above * score
])

Y = np.column_stack([df["earnings"].values, df["participated"].values])

W = weights
WX = W[:, None] * X
bread = np.linalg.inv(X.T @ WX)
coefs = bread @ WX.T @ Y
residuals = Y - X @ coefs

contrast = np.array([0., 1., 0., 0.])
jumps = contrast @ coefs

loading = W * (X @ bread @ contrast)
influence = loading[:, None] * residuals
joint = influence.T @ influence

earnings_jump = jumps[0]
participation_jump = jumps[1]

se_earnings = np.sqrt(joint[0, 0])
se_participation = np.sqrt(joint[1, 1])

ratio = earnings_jump / participation_jump
gradient = np.array([1.0 / participation_jump, -earnings_jump / participation_jump**2])
se_ratio = np.sqrt(gradient @ joint @ gradient)

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": float(ratio), "se": float(se_ratio), "n_obs": n_obs},
        {"term": "reduced_form", "estimate": float(earnings_jump), "se": float(se_earnings), "n_obs": n_obs},
        {"term": "first_stage", "estimate": float(participation_jump), "se": float(se_participation), "n_obs": n_obs},
    ],
    "method_metadata": {"estimator": "fuzzy_rd_local_linear", "vcov": "HC0"},
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2, allow_nan=False)
