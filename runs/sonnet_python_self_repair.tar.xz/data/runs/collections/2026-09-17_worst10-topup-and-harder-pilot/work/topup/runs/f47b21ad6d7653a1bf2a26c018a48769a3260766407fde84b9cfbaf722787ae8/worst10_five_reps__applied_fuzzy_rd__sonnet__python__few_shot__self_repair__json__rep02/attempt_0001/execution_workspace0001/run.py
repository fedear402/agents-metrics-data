import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df.columns = df.columns.str.strip()

bw = 1.0
mask = df["score"].abs() < bw
df = df[mask].copy()
n_obs = len(df)

score = df["score"].values
weights = 1.0 - np.abs(score)
above = (score >= 0).astype(float)

X = np.column_stack([
    np.ones(n_obs),
    above,
    score,
    above * score
])

Y = np.column_stack([df["earnings"].values, df["participated"].values])

W = weights
WX = W[:, None] * X
bread = np.linalg.inv(X.T @ WX)
coef = bread @ (WX.T @ Y)

residuals = Y - X @ coef

# contrast for right-limit minus left-limit at score=0
# X @ coef gives predictions; at score=0, above=1: [1,1,0,0]@coef - above=0: [1,0,0,0]@coef = [0,1,0,0]@coef
contrast = np.array([0., 1., 0., 0.])

jumps = contrast @ coef  # shape (2,) for earnings and participation

loading = W * (X @ bread @ contrast)  # shape (n_obs,)
influence = loading[:, None] * residuals  # (n_obs, 2)
joint = influence.T @ influence  # (2, 2)

rf_est = jumps[0]
fs_est = jumps[1]
te_est = rf_est / fs_est

rf_se = np.sqrt(joint[0, 0])
fs_se = np.sqrt(joint[1, 1])

gradient = np.array([1.0 / fs_est, -rf_est / fs_est**2])
te_se = np.sqrt(gradient @ joint @ gradient)

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": float(te_est), "se": float(te_se), "n_obs": n_obs},
        {"term": "reduced_form", "estimate": float(rf_est), "se": float(rf_se), "n_obs": n_obs},
        {"term": "first_stage", "estimate": float(fs_est), "se": float(fs_se), "n_obs": n_obs},
    ],
    "method_metadata": {"estimator": "fuzzy_rd_local_linear", "vcov": "HC0"},
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2, allow_nan=False)
