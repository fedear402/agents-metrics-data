import json
import numpy as np
import pandas as pd

data = pd.read_csv("input.csv", parse_dates=["date"])
data = data.sort_values("date").reset_index(drop=True)

data["log_vix"] = np.log(data["vix"])
data["log_sales"] = np.log(data["sales"])
data["vix_change"] = data["log_vix"].diff()

n_lags = 15
for i in range(1, n_lags + 1):
    data[f"lag_{i}"] = data["vix_change"].shift(i)

lag_cols = [f"lag_{i}" for i in range(1, n_lags + 1)]
sample = data.dropna(subset=["log_sales"] + lag_cols).copy()
N = len(sample)

X = np.column_stack([np.ones(N)] + [sample[c].to_numpy() for c in lag_cols])
y = sample["log_sales"].to_numpy()

coefficients = np.linalg.lstsq(X, y, rcond=None)[0]
residuals = y - X @ coefficients

scores = X * residuals[:, None]
hac_lags = 15
meat = scores.T @ scores
for j in range(1, hac_lags + 1):
    weight = 1 - j / (hac_lags + 1)
    lag_product = scores[j:].T @ scores[:-j]
    meat += weight * (lag_product + lag_product.T)

bread = np.linalg.inv(X.T @ X)
p = X.shape[1]
covariance = (N / (N - p)) * bread @ meat @ bread

contrast = np.array([0.0] + [1.0] * n_lags)
cumulative = float(contrast @ coefficients)
cumulative_se = float(np.sqrt(contrast @ covariance @ contrast))

lag1_idx = 1
lag15_idx = 15

estimates = [
    {"term": "cumulative_response", "estimate": cumulative, "se": cumulative_se, "n_obs": N},
    {"term": "lag_1", "estimate": float(coefficients[lag1_idx]), "se": float(np.sqrt(covariance[lag1_idx, lag1_idx])), "n_obs": N},
    {"term": "lag_15", "estimate": float(coefficients[lag15_idx]), "se": float(np.sqrt(covariance[lag15_idx, lag15_idx])), "n_obs": N},
]

output = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "OLS",
        "vcov": "Newey-West HAC, max_lag=15, Bartlett weights, correction N/(N-16)"
    },
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(output, f, indent=2, allow_nan=False)
