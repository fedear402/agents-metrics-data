import pandas as pd
import numpy as np
import json

df = pd.read_csv('input.csv')

# One obs per region for weights
regions = df.drop_duplicates('region_id')[['region_id', 'region_weight', 'x', 'y']].copy()
regions['e_r'] = regions['region_weight'] / regions['region_weight'].sum()

# Construct instrument z_r = sum_n share_rn * shock_n
shock_map = df.drop_duplicates('industry_id').set_index('industry_id')['shock']
df['share_shock'] = df['share'] * df['shock']
z_r = df.groupby('region_id')['share_shock'].sum().rename('z')
regions = regions.merge(z_r, on='region_id')

e = regions['e_r'].values
x = regions['x'].values
y = regions['y'].values
z = regions['z'].values

# Weighted means
x_mean = np.sum(e * x)
y_mean = np.sum(e * y)
z_mean = np.sum(e * z)

x0 = x - x_mean
y0 = y - y_mean
z0 = z - z_mean

regions['x0'] = x0
regions['y0'] = y0
regions['z0'] = z0

# Regional 2SLS slope: beta = (sum e_r z0_r y0_r) / (sum e_r z0_r x0_r)
num_2sls = np.sum(e * z0 * y0)
den_2sls = np.sum(e * z0 * x0)
beta_2sls = num_2sls / den_2sls

# Regional first-stage slope
num_fs = np.sum(e * z0 * x0)
den_fs = np.sum(e * z0 * z0)
beta_fs = num_fs / den_fs

# Industry-level aggregation
industries = df['industry_id'].unique()
N = len(industries)

# s_n = sum_r e_r * share_rn
region_e = regions.set_index('region_id')['e_r']
df2 = df.merge(regions[['region_id','e_r','x0','y0','z0']], on='region_id')

# s_n
df2['e_share'] = df2['e_r'] * df2['share']
s_n = df2.groupby('industry_id')['e_share'].sum()

# vbar_n = sum_r e_r * share_rn * v0_r / s_n
for v in ['x0','y0','z0']:
    df2[f'e_share_{v}'] = df2['e_r'] * df2['share'] * df2[v]

agg = df2.groupby('industry_id').agg(
    e_share_x0=('e_share_x0','sum'),
    e_share_y0=('e_share_y0','sum'),
    e_share_z0=('e_share_z0','sum'),
    shock=('shock','first')
).join(s_n)

agg['xbar'] = agg['e_share_x0'] / agg['e_share']
agg['ybar'] = agg['e_share_y0'] / agg['e_share']
agg['zbar'] = agg['e_share_z0'] / agg['e_share']
agg['s_n'] = agg['e_share']

sn = agg['s_n'].values
shock = agg['shock'].values
xbar = agg['xbar'].values
ybar = agg['ybar'].values
zbar = agg['zbar'].values

# Shock-level IV for effect: y ~ x, instrument x with shock, weight s_n
# IV slope = (sum s_n * shock_n * ybar_n) / (sum s_n * shock_n * xbar_n)
# But need intercept: demean by weighted mean first
sn_sum = sn.sum()
def wmean(v, w): return np.sum(w * v) / np.sum(w)

shock_wm = wmean(shock, sn)
xbar_wm = wmean(xbar, sn)
ybar_wm = wmean(ybar, sn)
zbar_wm = wmean(zbar, sn)

shock_d = shock - shock_wm
xbar_d = xbar - xbar_wm
ybar_d = ybar - ybar_wm
zbar_d = zbar - zbar_wm

# Effect: IV of ybar on xbar, instrument shock
beta_effect_sl = np.sum(sn * shock_d * ybar_d) / np.sum(sn * shock_d * xbar_d)
# Structural residuals
resid_effect = ybar_d - beta_effect_sl * xbar_d

# HC1 SE for shock-level IV
# Meat of sandwich: sum s_n^2 * shock_d_n^2 * resid_n^2
# Bread: sum s_n * shock_d_n * xbar_d_n
bread_effect = np.sum(sn * shock_d * xbar_d)
meat_effect = np.sum(sn**2 * shock_d**2 * resid_effect**2)
# HC1: multiply by N/(N-2)
var_effect = (N / (N - 2)) * meat_effect / bread_effect**2
se_effect = np.sqrt(var_effect)

# First-stage: IV of xbar on zbar, instrument shock, weight s_n
# Demean already done above
beta_fs_sl = np.sum(sn * shock_d * xbar_d) / np.sum(sn * shock_d * zbar_d)
resid_fs = xbar_d - beta_fs_sl * zbar_d

bread_fs = np.sum(sn * shock_d * zbar_d)
meat_fs = np.sum(sn**2 * shock_d**2 * resid_fs**2)
var_fs = (N / (N - 2)) * meat_fs / bread_fs**2
se_fs = np.sqrt(var_fs)

# Effective shocks
effective_shocks = 1.0 / np.sum(sn**2)

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": float(beta_2sls), "se": float(se_effect), "n_obs": int(N)},
        {"term": "first_stage", "estimate": float(beta_fs), "se": float(se_fs), "n_obs": int(N)},
        {"term": "effective_shocks", "estimate": float(effective_shocks), "se": None, "n_obs": int(N)}
    ],
    "method_metadata": {
        "estimator": "2SLS shift-share with Borusyak-Hull-Jaravel exposure-robust SE",
        "vcov": "HC1 shock-level"
    },
    "diagnostics": {}
}

with open('result.json', 'w') as f:
    json.dump(result, f, indent=2)

print("Done. beta_2sls =", beta_2sls, "se =", se_effect)
print("first_stage =", beta_fs, "se =", se_fs)
print("effective_shocks =", effective_shocks)
