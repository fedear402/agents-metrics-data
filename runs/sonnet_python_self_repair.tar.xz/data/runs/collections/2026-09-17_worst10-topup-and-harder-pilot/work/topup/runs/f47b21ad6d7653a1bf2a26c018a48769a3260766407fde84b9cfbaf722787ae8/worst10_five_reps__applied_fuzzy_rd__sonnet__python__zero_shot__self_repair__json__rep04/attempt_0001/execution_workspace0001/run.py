import pandas as pd
import numpy as np
import json
from statsmodels.regression.linear_model import OLS, WLS

df = pd.read_csv('input.csv')
df.columns = df.columns.str.strip()

bw = 1.0
mask = np.abs(df['score']) < bw
df = df[mask].copy()
n_obs = len(df)

df['w'] = 1 - np.abs(df['score'])
df['above'] = (df['score'] >= 0).astype(float)
df['score_above'] = df['score'] * df['above']
df['score_below'] = df['score'] * (1 - df['above'])

X = np.column_stack([
    np.ones(n_obs),
    df['above'].values,
    df['score_below'].values,
    df['score_above'].values,
])

W = np.diag(df['w'].values)
y_earn = df['earnings'].values
y_part = df['participated'].values

def wls_fit(X, y, w):
    Xw = X * w[:, None]
    XtWX = X.T @ Xw
    XtWy = Xw.T @ y
    beta = np.linalg.solve(XtWX, XtWy)
    return beta, XtWX

def hc0_cov(X, y, w, beta):
    resid = y - X @ beta
    Xw = X * w[:, None]
    XtWX = X.T @ Xw
    XtWX_inv = np.linalg.inv(XtWX)
    # HC0: meat = sum_i w_i^2 * e_i^2 * x_i x_i'
    wr = w * resid
    meat = (X * wr[:, None]).T @ (X * wr[:, None])
    cov = XtWX_inv @ meat @ XtWX_inv
    return cov

w = df['w'].values

beta_earn, XtWX_earn = wls_fit(X, y_earn, w)
beta_part, XtWX_part = wls_fit(X, y_part, w)

cov_earn = hc0_cov(X, y_earn, w, beta_earn)
cov_part = hc0_cov(X, y_part, w, beta_part)

# Discontinuities are the coefficient on 'above' (index 1)
rf_est = beta_earn[1]
fs_est = beta_part[1]
rf_se = np.sqrt(cov_earn[1, 1])
fs_se = np.sqrt(cov_part[1, 1])

# Treatment effect via delta method: tau = rf / fs
te_est = rf_est / fs_est

# Cross-covariance between rf and fs estimates
# Cov(beta_earn[1], beta_part[1]) via HC0 joint sandwich
resid_earn = y_earn - X @ beta_earn
resid_part = y_part - X @ beta_part

Xw = X * w[:, None]
XtWX_earn_inv = np.linalg.inv(X.T @ Xw)
XtWX_part_inv = np.linalg.inv(X.T @ Xw)  # same X and w

# Cross meat: sum_i w_i^2 * e_earn_i * e_part_i * x_i x_i'
wr_earn = w * resid_earn
wr_part = w * resid_part
cross_meat = (X * wr_earn[:, None]).T @ (X * wr_part[:, None])
cross_cov = XtWX_earn_inv @ cross_meat @ XtWX_part_inv

cov_rf_fs = cross_cov[1, 1]

# Delta method: Var(rf/fs) = (1/fs)^2 * Var(rf) + (rf/fs^2)^2 * Var(fs) - 2*(rf/fs^3)*Cov(rf,fs)
var_te = (1/fs_est)**2 * cov_earn[1,1] + (rf_est/fs_est**2)**2 * cov_part[1,1] - 2*(rf_est/fs_est**3)*cov_rf_fs
te_se = np.sqrt(var_te)

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": float(te_est), "se": float(te_se), "n_obs": int(n_obs)},
        {"term": "reduced_form", "estimate": float(rf_est), "se": float(rf_se), "n_obs": int(n_obs)},
        {"term": "first_stage", "estimate": float(fs_est), "se": float(fs_se), "n_obs": int(n_obs)},
    ],
    "method_metadata": {
        "estimator": "fuzzy_rd_local_linear_triangular",
        "vcov": "HC0"
    },
    "diagnostics": {}
}

with open('result.json', 'w') as f:
    json.dump(result, f, indent=2)

print(json.dumps(result, indent=2))
