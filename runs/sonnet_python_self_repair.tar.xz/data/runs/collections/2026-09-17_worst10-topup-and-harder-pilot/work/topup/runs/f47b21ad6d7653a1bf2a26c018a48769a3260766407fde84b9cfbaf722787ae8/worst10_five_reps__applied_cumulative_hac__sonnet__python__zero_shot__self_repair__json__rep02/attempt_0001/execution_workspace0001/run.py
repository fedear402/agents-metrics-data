import pandas as pd
import numpy as np
import json
from statsmodels.regression.linear_model import OLS
from statsmodels.tools import add_constant

df = pd.read_csv('input.csv')
df = df.sort_values('date').reset_index(drop=True)

df['log_sales'] = np.log(df['sales'])
df['log_vix'] = np.log(df['vix'])
df['d_log_vix'] = df['log_vix'].diff()

for lag in range(1, 16):
    df[f'lag_{lag}'] = df['d_log_vix'].shift(lag)

df_reg = df.dropna(subset=[f'lag_{i}' for i in range(1, 16)] + ['log_sales']).copy()

y = df_reg['log_sales']
X = add_constant(df_reg[[f'lag_{i}' for i in range(1, 16)]])

model = OLS(y, X).fit()
N = len(df_reg)

# Newey-West with max lag 15, Bartlett weights 1-j/16, scaled by N/(N-16)
nw_cov = model.get_robustcov_results(cov_type='HAC', maxlags=15, use_correction=False).cov_params()
# statsmodels HAC uses Bartlett by default, but we need to apply the N/(N-16) correction
# get_robustcov_results with use_correction=False gives us the raw sandwich
# We need to compute manually to ensure exact spec

# Manual Newey-West
resid = model.resid.values
X_vals = X.values
k = X_vals.shape[1]

S = np.zeros((k, k))
# Contemporaneous
for i in range(N):
    S += np.outer(X_vals[i] * resid[i], X_vals[i] * resid[i])

for j in range(1, 16):
    w = 1 - j / 16.0
    gamma = np.zeros((k, k))
    for i in range(j, N):
        gamma += np.outer(X_vals[i] * resid[i], X_vals[i-j] * resid[i-j])
    S += w * (gamma + gamma.T)

XtX_inv = np.linalg.inv(X_vals.T @ X_vals)
cov_nw = XtX_inv @ S @ XtX_inv
cov_nw_scaled = cov_nw * N / (N - 16)

coefs = model.params

# Lag coefficients start at index 1 (index 0 is intercept)
lag_names = [f'lag_{i}' for i in range(1, 16)]
lag_coefs = coefs[lag_names].values

cumulative = lag_coefs.sum()

# Cumulative response SE: sum of all lag coefficients
# var(sum) = e'Ve where e is vector of ones for lag coefficients
lag_indices = [list(X.columns).index(f'lag_{i}') for i in range(1, 16)]
cov_lags = cov_nw_scaled[np.ix_(lag_indices, lag_indices)]
e = np.ones(15)
se_cumulative = np.sqrt(e @ cov_lags @ e)

se_lag1 = np.sqrt(cov_nw_scaled[lag_indices[0], lag_indices[0]])
se_lag15 = np.sqrt(cov_nw_scaled[lag_indices[14], lag_indices[14]])

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {"term": "cumulative_response", "estimate": float(cumulative), "se": float(se_cumulative), "n_obs": int(N)},
        {"term": "lag_1", "estimate": float(lag_coefs[0]), "se": float(se_lag1), "n_obs": int(N)},
        {"term": "lag_15", "estimate": float(lag_coefs[14]), "se": float(se_lag15), "n_obs": int(N)}
    ],
    "method_metadata": {
        "estimator": "OLS",
        "vcov": "Newey-West HAC maxlag=15 Bartlett weights 1-j/16 scaled N/(N-16)"
    },
    "diagnostics": {}
}

with open('result.json', 'w') as f:
    json.dump(result, f, indent=2)
