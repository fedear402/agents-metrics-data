import pandas as pd
import numpy as np
import json

df = pd.read_csv('input.csv')

# Get one obs per region for weights
regions = df.drop_duplicates('region_id')[['region_id', 'region_weight', 'x', 'y']].copy()
regions['e_r'] = regions['region_weight'] / regions['region_weight'].sum()

# Construct instrument z_r = sum_n share_rn * shock_n
df_z = df.groupby('region_id').apply(lambda g: (g['share'] * g['shock']).sum()).reset_index()
df_z.columns = ['region_id', 'z']
regions = regions.merge(df_z, on='region_id')

# Weighted means
def wmean(v, w):
    return (v * w).sum() / w.sum()

e = regions['e_r'].values
x = regions['x'].values
y = regions['y'].values
z = regions['z'].values

mx = wmean(regions['x'], regions['e_r'])
my = wmean(regions['y'], regions['e_r'])
mz = wmean(regions['z'], regions['e_r'])

x0 = x - mx
y0 = y - my
z0 = z - mz

regions['x0'] = x0
regions['y0'] = y0
regions['z0'] = z0

# Industry-level aggregation
# s_n = sum_r e_r * share_rn
df2 = df.merge(regions[['region_id', 'e_r', 'x0', 'y0', 'z0']], on='region_id')
df2['e_share'] = df2['e_r'] * df2['share']

industry_sn = df2.groupby('industry_id')['e_share'].sum().reset_index()
industry_sn.columns = ['industry_id', 's_n']

# vbar_n = sum_r e_r * share_rn * v0_r / s_n
for col in ['x0', 'y0', 'z0']:
    df2[f'e_share_{col}'] = df2['e_share'] * df2[col]
    agg = df2.groupby('industry_id')[f'e_share_{col}'].sum().reset_index()
    agg.columns = ['industry_id', f'num_{col}']
    industry_sn = industry_sn.merge(agg, on='industry_id')
    industry_sn[f'{col}bar'] = industry_sn[f'num_{col}'] / industry_sn['s_n']

# Get shock for each industry (constant within industry)
shocks = df.drop_duplicates('industry_id')[['industry_id', 'shock']]
industry_sn = industry_sn.merge(shocks, on='industry_id')

N = len(industry_sn)
s = industry_sn['s_n'].values
shock = industry_sn['shock'].values
xbar = industry_sn['x0bar'].values
ybar = industry_sn['y0bar'].values
zbar = industry_sn['z0bar'].values

# Shock-level IV for effect: y on x, instrument x with shock, weight s_n
# 2SLS: first stage xbar on shock (weighted), then use fitted xbar to predict ybar
def shock_level_iv_slope(endog, exog_instrument, dep, weights, hc1=True):
    """
    IV regression of dep on [1, endog], instrumenting endog with exog_instrument, weights=weights
    Returns slope and HC1 SE
    endog: the endogenous regressor (xbar or zbar)
    exog_instrument: the instrument (shock or zbar... wait, shock for effect)
    dep: dependent variable (ybar or xbar)
    """
    w = weights
    W = np.diag(w)
    
    # Z matrix (instruments): [1, shock]
    Zmat = np.column_stack([np.ones(N), exog_instrument])
    # X matrix (regressors): [1, endog]
    Xmat = np.column_stack([np.ones(N), endog])
    # Y
    Y = dep
    
    # 2SLS estimator: beta = (X'WZ (Z'WZ)^{-1} Z'WX)^{-1} X'WZ (Z'WZ)^{-1} Z'WY
    ZtW = Zmat.T @ W
    ZtWZ = ZtW @ Zmat
    ZtWX = ZtW @ Xmat
    ZtWY = ZtW @ Y
    
    ZtWZ_inv = np.linalg.inv(ZtWZ)
    
    # First stage projection: Xhat = Z (Z'WZ)^{-1} Z'WX projected
    # Actually for 2SLS:
    A = ZtWX.T @ ZtWZ_inv @ ZtWX
    b = ZtWX.T @ ZtWZ_inv @ ZtWY
    beta = np.linalg.solve(A, b)
    
    slope = beta[1]
    
    # Structural residuals: u = Y - X*beta
    u = Y - Xmat @ beta
    
    # HC1 variance: V = (X'WZ (Z'WZ)^{-1} Z'WX)^{-1} * (X'WZ (Z'WZ)^{-1} (sum w_i^2 z_i z_i' u_i^2) (Z'WZ)^{-1} Z'WX) * (X'WZ (Z'WZ)^{-1} Z'WX)^{-1}
    # HC1 multiplier: N/(N-2)
    
    # Meat: sum_i w_i^2 * u_i^2 * z_i z_i'  -- but with analytic weights convention
    # With analytic weights, the sandwich meat is: Z'W diag(u^2) W Z * N/(N-2)
    # Actually for HC1 with analytic weights:
    # Meat = sum_i (w_i * z_i * u_i)^2 ... need to be careful
    # Standard HC1: Meat = n/(n-k) * sum_i e_i^2 * x_i x_i' where e_i are residuals
    # With weights as in WLS/2SLS: the score for obs i is w_i * z_i * u_i
    # Meat = N/(N-2) * sum_i (w_i * z_i * u_i)(w_i * z_i * u_i)'
    
    scores = w[:, None] * Zmat * u[:, None]  # N x 2
    meat = (N / (N - 2)) * scores.T @ scores
    
    bread = np.linalg.inv(A)  # (X'WZ (Z'WZ)^{-1} Z'WX)^{-1}
    
    # Need to map from Z space to X space
    # V(beta) = bread @ (ZtWX/something)' @ meat @ (ZtWX/something) @ bread
    # More carefully:
    # beta = (P'WP)^{-1} P'WY where P = Z(Z'WZ)^{-1}Z'WX... 
    # Actually simpler formula:
    # V = (X'PwX)^{-1} X'Pw [meat_zz] PwX (X'PwX)^{-1}
    # where Pw = W Z (Z'WZ)^{-1} Z' W
    
    # Let's use: D = ZtWX (shape 2x2), M = ZtWZ_inv (2x2)
    # bread_full = inv(D.T @ M @ D)
    # middle = D.T @ M @ meat @ M @ D
    # V = bread_full @ middle @ bread_full
    
    middle = ZtWX.T @ ZtWZ_inv @ meat @ ZtWZ_inv @ ZtWX
    V = bread @ middle @ bread
    
    se_slope = np.sqrt(V[1, 1])
    return slope, se_slope

# Effect: IV of ybar on xbar, instrument = shock, weights = s_n
effect_slope, effect_se = shock_level_iv_slope(xbar, shock, ybar, s)

# First stage: slope of x on z (regional level)
# Shock-level equivalent: IV of xbar on zbar, instrument = shock, weights = s_n
fs_slope, fs_se = shock_level_iv_slope(zbar, shock, xbar, s)

# Effective shocks
effective_shocks = 1.0 / (s**2).sum()

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": float(effect_slope), "se": float(effect_se), "n_obs": int(N)},
        {"term": "first_stage", "estimate": float(fs_slope), "se": float(fs_se), "n_obs": int(N)},
        {"term": "effective_shocks", "estimate": float(effective_shocks), "se": None, "n_obs": int(N)}
    ],
    "method_metadata": {
        "estimator": "shift-share 2SLS with Borusyak-Hull-Jaravel exposure-robust SE",
        "vcov": "HC1 shock-level"
    },
    "diagnostics": {}
}

with open('result.json', 'w') as f:
    json.dump(result, f, indent=2)

print("Done. result.json written.")
