import pandas as pd
import numpy as np
import statsmodels.api as sm
from statsmodels.discrete.discrete_model import MNLogit
import json

df = pd.read_csv('input.csv')
n_obs = len(df)

X = sm.add_constant(df[['x', 'z']])
y = df['y']

model = MNLogit(y, X)
result = model.fit(method='newton', maxiter=200, disp=False)

params = result.params
bse = result.bse

# params columns are indexed 0-based for non-base categories
# For 3 outcomes (0,1,2) with base=0, columns are [0,1] corresponding to outcomes 1,2
x_cat1 = float(params.iloc[params.index.get_loc('x'), 0])
z_cat1 = float(params.iloc[params.index.get_loc('z'), 0])
x_cat2 = float(params.iloc[params.index.get_loc('x'), 1])
z_cat2 = float(params.iloc[params.index.get_loc('z'), 1])

se_x_cat1 = float(bse.iloc[bse.index.get_loc('x'), 0])
se_z_cat1 = float(bse.iloc[bse.index.get_loc('z'), 0])
se_x_cat2 = float(bse.iloc[bse.index.get_loc('x'), 1])
se_z_cat2 = float(bse.iloc[bse.index.get_loc('z'), 1])

# Fitted probability of outcome 2 at x=0, z=0
x0 = np.array([[1.0, 0.0, 0.0]])
pred_probs = result.predict(x0)
prob_cat2_zero = float(pred_probs[0, 2])

estimates = [
    {"term": "x_cat1", "estimate": x_cat1, "se": se_x_cat1, "n_obs": n_obs},
    {"term": "z_cat1", "estimate": z_cat1, "se": se_z_cat1, "n_obs": n_obs},
    {"term": "x_cat2", "estimate": x_cat2, "se": se_x_cat2, "n_obs": n_obs},
    {"term": "z_cat2", "estimate": z_cat2, "se": se_z_cat2, "n_obs": n_obs},
    {"term": "prob_cat2_zero", "estimate": prob_cat2_zero, "se": None, "n_obs": n_obs},
]

output = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "MNLogit MLE",
        "vcov": "observed_information"
    },
    "diagnostics": {}
}

with open('result.json', 'w') as f:
    json.dump(output, f, indent=2)
