import pandas as pd
import statsmodels.api as sm
import json

df = pd.read_csv("./input.csv")
X = sm.add_constant(df[["x1", "x2"]])
model = sm.OLS(df["y_lin"], X).fit(cov_type="HC1")

n = int(model.nobs)
terms = ["const", "x1", "x2"]
estimates = [
    {"term": t, "estimate": float(model.params[t]), "se": float(model.bse[t]), "n_obs": n}
    for t in terms
]

result = {
    "task_id": "ols_robust",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {"estimator": "OLS", "vcov": "HC1"},
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
