import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df.columns = df.columns.str.strip()

bw = 1.0
mask = df["score"].abs() < bw
df = df[mask].copy()
n_obs = len(df)

score = df["score"].values
weights = 1 - np.abs(score)
above = (score >= 0).astype(float)
earnings = df["earnings"].values
participated = df["participated"].values

X = np.column_stack([
    np.ones(n_obs),
    above,
    score,
    score * above
])

def wls_fit(X, y, w):
    Xw = X * w[:, None]
    bread = np.linalg.inv(Xw.T @ X)
    coef = bread @ Xw.T @ y
    return coef, bread

def hc0_joint(X, y1, y2, w, bread):
    coef1, _ = wls_fit(X, y1, w)
    coef2, _ = wls_fit(X, y2, w)
    res1 = y1 - X @ coef1
    res2 = y2 - X @ coef2
    loading = w * (X @ bread @ np.array([0., 1., 0., 0.]))
    inf1 = loading * res1
    inf2 = loading * res2
    var1 = np.sum(inf1**2)
    var2 = np.sum(inf2**2)
    cov12 = np.sum(inf1 * inf2)
    jump1 = (np.array([0., 1., 0., 0.]) @ coef1)
    jump2 = (np.array([0., 1., 0., 0.]) @ coef2)
    return jump1, jump2, var1, var2, cov12

bread = np.linalg.inv((X * weights[:, None]).T @ X)

rf_jump, fs_jump, rf_var, fs_var, cov12 = hc0_joint(X, earnings, participated, weights, bread)

te = rf_jump / fs_jump
grad = np.array([1.0 / fs_jump, -rf_jump / fs_jump**2])
J = np.array([[rf_var, cov12], [cov12, fs_var]])
te_var = grad @ J @ grad

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": float(te), "se": float(np.sqrt(te_var)), "n_obs": n_obs},
        {"term": "reduced_form", "estimate": float(rf_jump), "se": float(np.sqrt(rf_var)), "n_obs": n_obs},
        {"term": "first_stage", "estimate": float(fs_jump), "se": float(np.sqrt(fs_var)), "n_obs": n_obs},
    ],
    "method_metadata": {"estimator": "fuzzy_rd_local_linear", "vcov": "HC0"},
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2, allow_nan=False)
