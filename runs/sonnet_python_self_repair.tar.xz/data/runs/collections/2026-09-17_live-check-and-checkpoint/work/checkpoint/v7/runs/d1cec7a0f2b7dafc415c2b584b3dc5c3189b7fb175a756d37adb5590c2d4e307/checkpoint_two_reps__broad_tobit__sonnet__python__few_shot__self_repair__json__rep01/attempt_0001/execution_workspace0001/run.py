import json
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.stats import norm
from statsmodels.tools.numdiff import approx_hess

df = pd.read_csv('input.csv')
y = df['y'].values
x = df['x'].values
z = df['z'].values
n = len(y)

design = np.column_stack([np.ones(n), x, z])
censored = y == 0.

def loss(params):
    beta = params[:3]
    scale = np.exp(params[3])
    mu = design @ beta
    a = (0. - mu[censored]) / scale
    r = (y[~censored] - mu[~censored]) / scale
    return -norm.logcdf(a).sum() - (norm.logpdf(r) - np.log(scale)).sum()

def gradient(params):
    beta = params[:3]
    scale = np.exp(params[3])
    mu = design @ beta
    a = (0. - mu[censored]) / scale
    mills = np.exp(norm.logpdf(a) - norm.logcdf(a))
    r = (y[~censored] - mu[~censored]) / scale
    coef_score = design[censored].T @ (mills / scale)
    coef_score -= design[~censored].T @ (r / scale)
    scale_score = np.sum(a * mills) + np.sum(1. - r * r)
    return np.r_[coef_score, scale_score]

# Initial values via OLS on uncensored
from numpy.linalg import lstsq
beta0, _, _, _ = lstsq(design[~censored], y[~censored], rcond=None)
params0 = np.r_[beta0, np.log(np.std(y[~censored]))]

fit = minimize(loss, params0, jac=gradient, method='BFGS', options={'gtol': 1e-8, 'maxiter': 10000})

information = approx_hess(fit.x, loss)
covariance = np.linalg.inv(information)

beta_hat = fit.x[:3]
sigma_hat = np.exp(fit.x[3])
se = np.sqrt(np.diag(covariance))

result = {
    "task_id": "broad_tobit",
    "platform": "python",
    "estimates": [
        {"term": "const", "estimate": float(beta_hat[0]), "se": float(se[0]), "n_obs": n},
        {"term": "x", "estimate": float(beta_hat[1]), "se": float(se[1]), "n_obs": n},
        {"term": "z", "estimate": float(beta_hat[2]), "se": float(se[2]), "n_obs": n},
        {"term": "sigma", "estimate": float(sigma_hat), "se": None, "n_obs": n},
    ],
    "method_metadata": {"estimator": "MLE_Tobit", "vcov": "observed_information"},
    "diagnostics": {}
}

with open('result.json', 'w') as f:
    json.dump(result, f, indent=2, allow_nan=False)
