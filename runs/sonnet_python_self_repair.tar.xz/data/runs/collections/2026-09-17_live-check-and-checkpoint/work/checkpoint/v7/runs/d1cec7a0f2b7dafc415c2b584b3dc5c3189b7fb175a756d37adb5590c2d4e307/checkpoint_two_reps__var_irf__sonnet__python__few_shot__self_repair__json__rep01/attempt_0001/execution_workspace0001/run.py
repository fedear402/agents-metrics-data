import json
import pandas as pd
from statsmodels.tsa.vector_ar.var_model import VAR

df = pd.read_csv("./input.csv")
data = df[["y1", "y2"]].dropna()

model = VAR(data)
results = model.fit(2)

n_obs = int(results.nobs)

irf = results.irf(10)
# irf.orth_irfs shape: (horizons+1, n_vars, n_vars)
# orth_irfs[h, i, j] = response of variable i to shock in variable j
# Variables ordered as [y1, y2], so y1=0, y2=1
# Response of y1 (index 0) to shock in y2 (index 1) at horizon 4
irf_val = float(irf.orth_irfs[4, 0, 1])

out = {
    "task_id": "var_irf",
    "platform": "python",
    "estimates": [
        {
            "term": "irf_y1_to_y2_h4",
            "estimate": irf_val,
            "se": None,
            "n_obs": n_obs,
        }
    ],
    "method_metadata": {
        "estimator": "VAR(2) by OLS with Cholesky identification",
        "vcov": "classical",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(out, f)
