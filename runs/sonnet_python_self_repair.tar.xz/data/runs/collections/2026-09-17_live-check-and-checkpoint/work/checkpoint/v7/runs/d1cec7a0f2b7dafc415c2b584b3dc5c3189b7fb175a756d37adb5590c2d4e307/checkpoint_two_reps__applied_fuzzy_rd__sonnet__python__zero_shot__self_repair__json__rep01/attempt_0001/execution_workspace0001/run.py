import pandas as pd
import numpy as np
import json
from statsmodels.regression.linear_model import OLS, WLS

df = pd.read_csv('input.csv')
df.columns = df.columns.str.strip()

bw = 1.0
mask = df['score'].abs() < bw
df_bw = df[mask].copy()
n_obs = len(df_bw)

df_bw['weight'] = 1 - df_bw['score'].abs()
df_bw['above'] = (df_bw['score'] >= 0).astype(float)
df_bw['score_above'] = df_bw['score'] * df_bw['above']
df_bw['score_below'] = df_bw['score'] * (1 - df_bw['above'])

X = np.column_stack([
    np.ones(n_obs),
    df_bw['above'].values,
    df_bw['score_below'].values,
    df_bw['score_above'].values
])

W = np.diag(df_bw['weight'].values)
w = df_bw['weight'].values

# WLS manually: beta = (X'WX)^{-1} X'Wy
XtW = X.T * w  # (4, n)
XtWX = XtW @ X  # (4, 4)
XtWX_inv = np.linalg.inv(XtWX)

y_earn = df_bw['earnings'].values
y_part = df_bw['participated'].values

beta_earn = XtWX_inv @ (XtW @ y_earn)
beta_part = XtWX_inv @ (XtW @ y_part)

resid_earn = y_earn - X @ beta_earn
resid_part = y_part - X @ beta_part

# HC0 sandwich covariance for each regression
# Cov(beta) = (X'WX)^{-1} (X' W diag(e^2) W X) (X'WX)^{-1}
# With triangular weights fixed:
# score function: psi_i = w_i * x_i * e_i
# V = (X'WX)^{-1} [sum_i w_i^2 x_i x_i' e_i^2] (X'WX)^{-1}

def hc0_cov(XtWX_inv, X, w, resid):
    # meat: sum_i (w_i * x_i * e_i)^2 outer
    we = w * resid  # weighted residuals
    meat = (X * we[:, None]).T @ (X * we[:, None])
    return XtWX_inv @ meat @ XtWX_inv

cov_earn = hc0_cov(XtWX_inv, X, w, resid_earn)
cov_part = hc0_cov(XtWX_inv, X, w, resid_part)

# discontinuity is coefficient on 'above' (index 1)
rf_est = beta_earn[1]
fs_est = beta_part[1]
rf_se = np.sqrt(cov_earn[1, 1])
fs_se = np.sqrt(cov_part[1, 1])

# Treatment effect = rf / fs
te_est = rf_est / fs_est

# Cross covariance between rf and fs estimates
# score functions for earn: psi_earn_i = w_i * x_i * e_earn_i
# score functions for part: psi_part_i = w_i * x_i * e_part_i
# joint sandwich:
we_earn = w * resid_earn
we_part = w * resid_part
cross_meat = (X * we_earn[:, None]).T @ (X * we_part[:, None])
cov_cross = XtWX_inv @ cross_meat @ XtWX_inv  # cov(beta_earn, beta_part)

cov_rf_fs = cov_cross[1, 1]

# Delta method for te = rf/fs
# d(te)/d(rf) = 1/fs, d(te)/d(fs) = -rf/fs^2
g_rf = 1.0 / fs_est
g_fs = -rf_est / (fs_est ** 2)
te_var = g_rf**2 * cov_earn[1,1] + g_fs**2 * cov_part[1,1] + 2 * g_rf * g_fs * cov_rf_fs
te_se = np.sqrt(te_var)

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": float(te_est), "se": float(te_se), "n_obs": int(n_obs)},
        {"term": "reduced_form", "estimate": float(rf_est), "se": float(rf_se), "n_obs": int(n_obs)},
        {"term": "first_stage", "estimate": float(fs_est), "se": float(fs_se), "n_obs": int(n_obs)}
    ],
    "method_metadata": {
        "estimator": "fuzzy_rd_local_linear_triangular_kernel",
        "vcov": "HC0"
    },
    "diagnostics": {}
}

with open('result.json', 'w') as f:
    json.dump(result, f, indent=2)

print(json.dumps(result, indent=2))
