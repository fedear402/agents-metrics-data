import json
import pandas as pd
from statsmodels.tsa.vector_ar.var_model import VAR

df = pd.read_csv("./input.csv")
data = df[["y1", "y2"]].dropna()

model = VAR(data)
results = model.fit(2)

irf = results.irf(4)
# irf.orth_irfs shape: (horizons+1, k, k)
# orth_irfs[h, i, j] = response of variable i to shock in variable j
# y1 is index 0, y2 is index 1
irf_y1_to_y2_h4 = float(irf.orth_irfs[4, 0, 1])

n_obs = int(results.nobs)

out = {
    "task_id": "var_irf",
    "platform": "python",
    "estimates": [
        {
            "term": "irf_y1_to_y2_h4",
            "estimate": irf_y1_to_y2_h4,
            "se": None,
            "n_obs": n_obs
        }
    ],
    "method_metadata": {
        "estimator": "VAR(2) by OLS with Cholesky orthogonalization",
        "vcov": "classical"
    },
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(out, f)
