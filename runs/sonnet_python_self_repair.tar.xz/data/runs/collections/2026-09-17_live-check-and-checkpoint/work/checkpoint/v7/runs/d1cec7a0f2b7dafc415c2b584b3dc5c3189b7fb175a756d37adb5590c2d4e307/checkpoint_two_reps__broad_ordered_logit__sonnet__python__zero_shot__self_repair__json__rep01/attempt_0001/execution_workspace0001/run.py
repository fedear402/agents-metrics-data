import pandas as pd
import numpy as np
from scipy import stats
from scipy.optimize import minimize
import json

df = pd.read_csv('./input.csv')
y = df['y'].values
x = df['x'].values
z = df['z'].values
n = len(y)

# Ordered logit via statsmodels
from statsmodels.miscmodels.ordinal_model import OrderedModel

model = OrderedModel(y, df[['x', 'z']], distr='logit')
result = model.fit(method='bfgs', disp=False)

# Extract coefficients
params = result.params
# statsmodels OrderedModel: first params are covariates, then thresholds
x_coef = params['x']
z_coef = params['z']

bse = result.bse
x_se = bse['x']
z_se = bse['z']

# Compute prob_high: P(y=3 | x=1, z=0)
# Ordered logit: P(y<=k) = logistic(cutpoint_k - X*beta)
# P(y=3) = 1 - P(y<=2)
# Thresholds in statsmodels are named like '1/2' and '2/3'
threshold_names = [p for p in params.index if '/' in str(p)]
# threshold_names[0] is cutpoint between cat1 and cat2
# threshold_names[1] is cutpoint between cat2 and cat3

cut1 = params[threshold_names[0]]
cut2 = params[threshold_names[1]]

linear_pred = x_coef * 1 + z_coef * 0
prob_high = 1 - 1 / (1 + np.exp(-(cut2 - linear_pred)))

estimates = [
    {"term": "x", "estimate": float(x_coef), "se": float(x_se), "n_obs": int(n)},
    {"term": "z", "estimate": float(z_coef), "se": float(z_se), "n_obs": int(n)},
    {"term": "prob_high", "estimate": float(prob_high), "se": None, "n_obs": int(n)},
]

output = {
    "task_id": "broad_ordered_logit",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "OrderedModel (ordered logit)",
        "vcov": "observed_information"
    },
    "diagnostics": {}
}

with open('./result.json', 'w') as f:
    json.dump(output, f, indent=2)

print("Done. result.json written.")
print(f"x coef: {x_coef:.6f}, se: {x_se:.6f}")
print(f"z coef: {z_coef:.6f}, se: {z_se:.6f}")
print(f"prob_high: {prob_high:.6f}")
