import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

df = pd.read_csv('./input.csv')

y = df['y_twocluster']
X = sm.add_constant(df['x'])

model = sm.OLS(y, X).fit()

n = len(df)
k = X.shape[1]
e = model.resid.values
X_arr = X.values

firms = df['firm'].values
years = df['year'].values

def meat_cluster(X_arr, e, groups):
    unique_g = np.unique(groups)
    meat = np.zeros((k, k))
    for g in unique_g:
        idx = groups == g
        Xe = X_arr[idx] * e[idx, None]
        s = Xe.sum(axis=0)
        meat += np.outer(s, s)
    return meat

bread = model.normalized_cov_params * n

B_firm = meat_cluster(X_arr, e, firms)
B_year = meat_cluster(X_arr, e, years)

firm_year = firms.astype(str) + '_' + years.astype(str)
B_fy = meat_cluster(X_arr, e, firm_year)

meat_cgm = B_firm + B_year - B_fy

# scale factor: n/(n-k) is sometimes applied; use standard sandwich
scale = 1.0 / n
V = scale * bread @ meat_cgm @ bread

se = np.sqrt(np.diag(V))

result = {
    "task_id": "two_way_cluster",
    "platform": "python",
    "estimates": [
        {"term": "const", "estimate": float(model.params['const']), "se": float(se[0]), "n_obs": n},
        {"term": "x", "estimate": float(model.params['x']), "se": float(se[1]), "n_obs": n}
    ],
    "method_metadata": {
        "estimator": "OLS",
        "vcov": "two-way cluster-robust (Cameron-Gelbach-Miller), clustered on firm and year"
    },
    "diagnostics": {}
}

with open('./result.json', 'w') as f:
    json.dump(result, f, indent=2)
