import pandas as pd
import numpy as np
import json

df = pd.read_csv('input.csv')

# One obs per region for weights
regions = df.drop_duplicates('region_id')[['region_id', 'region_weight', 'x', 'y']].copy()
regions['e_r'] = regions['region_weight'] / regions['region_weight'].sum()

# Construct instrument z_r = sum_n share_rn * shock_n
shock_map = df.drop_duplicates('industry_id').set_index('industry_id')['shock']
df['share_shock'] = df['share'] * df['shock']
z_r = df.groupby('region_id')['share_shock'].sum().reset_index().rename(columns={'share_shock': 'z'})
regions = regions.merge(z_r, on='region_id')

# Weighted means
def wmean(v, w):
    return (v * w).sum() / w.sum()

ew = regions['e_r'].values
xr = regions['x'].values
yr = regions['y'].values
zr = regions['z'].values

xbar = wmean(regions['x'], regions['e_r'])
ybar = wmean(regions['y'], regions['e_r'])
zbar_mean = wmean(regions['z'], regions['e_r'])

# Demeaned residuals
regions['x0'] = regions['x'] - xbar
regions['y0'] = regions['y'] - ybar
regions['z0'] = regions['z'] - zbar_mean

# Industry-level aggregation
industries = df.drop_duplicates('industry_id')[['industry_id', 'shock']].copy()

# Merge region residuals back to df
df2 = df.merge(regions[['region_id', 'e_r', 'x0', 'y0', 'z0']], on='region_id')

# s_n = sum_r e_r * share_rn
df2['e_share'] = df2['e_r'] * df2['share']
s_n = df2.groupby('industry_id')['e_share'].sum().reset_index().rename(columns={'e_share': 's_n'})

# vbar_n = sum_r e_r * share_rn * v0_r / s_n
for v in ['x0', 'y0', 'z0']:
    df2[f'e_share_{v}'] = df2['e_r'] * df2['share'] * df2[v]
    agg = df2.groupby('industry_id')[f'e_share_{v}'].sum().reset_index().rename(columns={f'e_share_{v}': f'sum_{v}'})
    s_n = s_n.merge(agg, on='industry_id')

s_n = s_n.merge(industries, on='industry_id')
s_n['xbar_n'] = s_n['sum_x0'] / s_n['s_n']
s_n['ybar_n'] = s_n['sum_y0'] / s_n['s_n']
s_n['zbar_n'] = s_n['sum_z0'] / s_n['s_n']

N = len(s_n)
w = s_n['s_n'].values
shock = s_n['shock'].values
xbar_n = s_n['xbar_n'].values
ybar_n = s_n['ybar_n'].values
zbar_n = s_n['zbar_n'].values

# Shock-level IV: ybar_n ~ xbar_n, instrument = shock_n, weights = s_n
# 2SLS slope = (shock' W xbar_n)^{-1} shock' W ybar_n ... but with intercept
# With demeaned variables, intercept is zero, so we can use weighted IV formula directly
# But let's be careful: fit with intercept properly

def weighted_iv_slope_and_se(y, x, z, w, n_obs):
    """Weighted IV regression y ~ 1 + x, instrument x with z, weights w.
    Returns slope and HC1 SE. Intercept included but we only care about slope."""
    W = np.diag(w)
    Z = np.column_stack([np.ones(len(y)), z])
    X = np.column_stack([np.ones(len(y)), x])
    
    # 2SLS: beta = (Z'WX)^{-1} Z'Wy
    ZWX = Z.T @ W @ X
    ZWy = Z.T @ W @ y
    beta = np.linalg.solve(ZWX, ZWy)
    
    # Structural residuals
    resid = y - X @ beta
    
    # HC1 sandwich variance
    # V = (Z'WX)^{-1} * (sum_i w_i^2 * e_i^2 * z_i z_i') * (X'WZ)^{-1} ... 
    # Standard HC1 for IV: V = (Z'WX)^{-1} S (X'WZ)^{-T} * n/(n-k)
    # where S = sum_i w_i * z_i * e_i * (w_i * z_i * e_i)' ... 
    # Actually for analytic weights in HC1:
    # meat = Z' W diag(e^2) W Z ... 
    # But with analytic weights, the "score" for obs i is w_i * z_i * e_i
    # S = sum_i (w_i * z_i * e_i)(w_i * z_i * e_i)'  -- but this double counts weights
    # 
    # Standard WLS HC1: V(beta_2sls) = (Z'WX)^{-1} [sum_i w_i^2 * e_i^2 * z_i*z_i'] (X'WZ)^{-T} * n/(n-2)
    # 
    # Actually for weighted IV with analytic weights, HC robust variance is:
    # V = (Z'WX)^{-1} * [sum_i w_i * e_i^2 * z_i z_i'] * (X'WZ)^{-T} * n/(n-2)
    # The convention with analytic weights treats w as fixed scaling
    
    # Use: meat = Z' diag(w * e^2) Z, bread = (Z'WX)^{-1}
    # HC1 multiplier: N/(N-2)
    we2 = w * resid**2
    meat = Z.T @ np.diag(we2) @ Z
    
    bread = np.linalg.inv(ZWX)
    V = bread @ meat @ bread.T * (n_obs / (n_obs - 2))
    
    se_slope = np.sqrt(V[1, 1])
    return beta[1], se_slope

# Effect: ybar_n ~ xbar_n, instrument xbar_n with shock_n
effect_slope, effect_se = weighted_iv_slope_and_se(ybar_n, xbar_n, shock, w, N)

# First stage: xbar_n ~ zbar_n, instrument zbar_n with shock_n
fs_slope, fs_se = weighted_iv_slope_and_se(xbar_n, zbar_n, shock, w, N)

# Effective shocks
effective_shocks = 1.0 / np.sum((w / w.sum())**2 * w.sum()**2 / w.sum()**2)
# Actually: effective_shocks = 1 / sum_n s_n^2
# s_n here is already normalized (sums to 1 since sum_r e_r * sum_n share_rn = sum_r e_r * 1 = 1)
effective_shocks = 1.0 / np.sum(w**2)

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": float(effect_slope), "se": float(effect_se), "n_obs": int(N)},
        {"term": "first_stage", "estimate": float(fs_slope), "se": float(fs_se), "n_obs": int(N)},
        {"term": "effective_shocks", "estimate": float(effective_shocks), "se": None, "n_obs": int(N)}
    ],
    "method_metadata": {
        "estimator": "2SLS shift-share with Borusyak-Hull-Jaravel shock-level aggregation",
        "vcov": "HC1 heteroskedasticity-robust (shock-level)"
    },
    "diagnostics": {}
}

with open('result.json', 'w') as f:
    json.dump(result, f, indent=2)

print("Done. Result written to result.json")
