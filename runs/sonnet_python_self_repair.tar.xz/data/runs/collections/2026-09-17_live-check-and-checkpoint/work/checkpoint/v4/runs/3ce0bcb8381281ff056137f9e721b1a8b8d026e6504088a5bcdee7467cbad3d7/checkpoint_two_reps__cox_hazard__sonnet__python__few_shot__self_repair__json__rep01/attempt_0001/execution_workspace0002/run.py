import json
import numpy as np
import pandas as pd
from scipy.optimize import minimize

df = pd.read_csv("./input.csv")
df = df.sort_values("t_obs").reset_index(drop=True)

times = df["t_obs"].values
events = df["event"].values
X = df[["treat", "x"]].values
n = len(df)

def neg_log_partial_likelihood(beta):
    xb = X @ beta
    ll = 0.0
    for i in range(n):
        if events[i] == 1:
            at_risk = times >= times[i]
            log_sum_risk = np.log(np.sum(np.exp(xb[at_risk])))
            ll += xb[i] - log_sum_risk
    return -ll

def neg_log_pl_grad(beta):
    xb = X @ beta
    grad = np.zeros_like(beta)
    for i in range(n):
        if events[i] == 1:
            at_risk = times >= times[i]
            exp_xb = np.exp(xb[at_risk])
            s0 = np.sum(exp_xb)
            s1 = X[at_risk].T @ exp_xb
            grad += X[i] - s1 / s0
    return -grad

beta0 = np.zeros(2)
res = minimize(neg_log_partial_likelihood, beta0, jac=neg_log_pl_grad, method="BFGS")
beta_hat = res.x

# Compute Hessian (information matrix) numerically for SE
eps = 1e-5
hess = np.zeros((2, 2))
for i in range(2):
    for j in range(2):
        e_i = np.zeros(2); e_i[i] = eps
        e_j = np.zeros(2); e_j[j] = eps
        hess[i, j] = (
            neg_log_partial_likelihood(beta_hat + e_i + e_j)
            - neg_log_partial_likelihood(beta_hat + e_i - e_j)
            - neg_log_partial_likelihood(beta_hat - e_i + e_j)
            + neg_log_partial_likelihood(beta_hat - e_i - e_j)
        ) / (4 * eps * eps)

var_cov = np.linalg.inv(hess)
se = np.sqrt(np.diag(var_cov))

n_obs = int(n)

out = {
    "task_id": "cox_hazard",
    "platform": "python",
    "estimates": [
        {"term": "treat", "estimate": float(beta_hat[0]), "se": float(se[0]), "n_obs": n_obs},
        {"term": "x", "estimate": float(beta_hat[1]), "se": float(se[1]), "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "Cox proportional hazards (Efron-style partial likelihood)",
        "vcov": "model-based (inverse observed information)",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(out, f)
