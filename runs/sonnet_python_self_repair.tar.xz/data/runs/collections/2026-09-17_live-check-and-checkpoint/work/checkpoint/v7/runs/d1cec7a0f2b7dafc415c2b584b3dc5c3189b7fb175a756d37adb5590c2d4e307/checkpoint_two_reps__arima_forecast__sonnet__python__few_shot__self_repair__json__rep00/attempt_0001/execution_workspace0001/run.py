import json
import pandas as pd
from statsmodels.tsa.arima.model import ARIMA

df = pd.read_csv("./input.csv")
y = df["y"].values

model = ARIMA(y, order=(1, 1, 1), trend="n")
fit = model.fit()

forecast_res = fit.get_forecast(steps=1)
fc = float(forecast_res.predicted_mean[0])
ci = forecast_res.conf_int(alpha=0.05)
lower = float(ci[0, 0])
upper = float(ci[0, 1])
n_obs = int(fit.nobs)

out = {
    "task_id": "arima_forecast",
    "platform": "python",
    "estimates": [
        {"term": "forecast", "estimate": fc, "se": float(forecast_res.se_mean[0]), "n_obs": n_obs},
        {"term": "lower_95", "estimate": lower, "se": None, "n_obs": n_obs},
        {"term": "upper_95", "estimate": upper, "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {"estimator": "ARIMA(1,1,1) by MLE", "vcov": "MLE"},
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(out, f)
