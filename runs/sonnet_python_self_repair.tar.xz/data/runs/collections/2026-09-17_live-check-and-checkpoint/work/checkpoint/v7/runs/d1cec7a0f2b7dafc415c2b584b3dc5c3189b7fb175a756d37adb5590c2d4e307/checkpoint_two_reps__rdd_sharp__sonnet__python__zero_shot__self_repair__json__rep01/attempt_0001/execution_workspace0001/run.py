import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

df = pd.read_csv('./input.csv')
z = df['z'].values
d = df['d'].values
y = df['y'].values

h = 0.5
cutoff = 0.0

mask_left = (z >= cutoff - h) & (z < cutoff)
mask_right = (z >= cutoff) & (z <= cutoff + h)

def triangular_kernel(u):
    return np.maximum(1 - np.abs(u), 0)

weights_left = triangular_kernel((z[mask_left] - cutoff) / h)
weights_right = triangular_kernel((z[mask_right] - cutoff) / h)

z_left = z[mask_left] - cutoff
z_right = z[mask_right] - cutoff
y_left = y[mask_left]
y_right = y[mask_right]

X_left = sm.add_constant(z_left)
X_right = sm.add_constant(z_right)

model_left = sm.WLS(y_left, X_left, weights=weights_left).fit()
model_right = sm.WLS(y_right, X_right, weights=weights_right).fit()

intercept_left = model_left.params[0]
intercept_right = model_right.params[0]
late = intercept_right - intercept_left

se_left = model_left.bse[0]
se_right = model_right.bse[0]
se_late = np.sqrt(se_left**2 + se_right**2)

n_obs = int(mask_left.sum() + mask_right.sum())

result = {
    "task_id": "rdd_sharp",
    "platform": "python",
    "estimates": [
        {
            "term": "late",
            "estimate": float(late),
            "se": float(se_late),
            "n_obs": n_obs
        }
    ],
    "method_metadata": {
        "estimator": "local linear regression with triangular kernel",
        "vcov": "OLS standard errors from WLS"
    },
    "diagnostics": {}
}

with open('./result.json', 'w') as f:
    json.dump(result, f, indent=2)
