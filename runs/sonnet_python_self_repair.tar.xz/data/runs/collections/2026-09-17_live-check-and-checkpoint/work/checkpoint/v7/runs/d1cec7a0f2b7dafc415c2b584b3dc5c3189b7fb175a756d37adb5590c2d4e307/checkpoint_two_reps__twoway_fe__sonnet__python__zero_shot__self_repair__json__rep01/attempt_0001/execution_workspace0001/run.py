import pandas as pd
import numpy as np
import statsmodels.formula.api as smf
import json

df = pd.read_csv('./input.csv')

# Demean for two-way fixed effects (within transformation)
df['y_dm'] = df['y_twocluster'] - df.groupby('firm')['y_twocluster'].transform('mean') \
             - df.groupby('year')['y_twocluster'].transform('mean') \
             + df['y_twocluster'].mean()

df['x_dm'] = df['x'] - df.groupby('firm')['x'].transform('mean') \
             - df.groupby('year')['x'].transform('mean') \
             + df['x'].mean()

# Use statsmodels OLS with cluster-robust SE on firm
model = smf.ols('y_dm ~ x_dm - 1', data=df).fit(
    cov_type='cluster', cov_kwds={'groups': df['firm']}
)

coef = float(model.params['x_dm'])
se = float(model.bse['x_dm'])
n_obs = int(model.nobs)

result = {
    "task_id": "twoway_fe",
    "platform": "python",
    "estimates": [
        {"term": "x", "estimate": coef, "se": se, "n_obs": n_obs}
    ],
    "method_metadata": {
        "estimator": "OLS with two-way FE via demeaning",
        "vcov": "clustered on firm"
    },
    "diagnostics": {}
}

with open('./result.json', 'w') as f:
    json.dump(result, f, indent=2)
