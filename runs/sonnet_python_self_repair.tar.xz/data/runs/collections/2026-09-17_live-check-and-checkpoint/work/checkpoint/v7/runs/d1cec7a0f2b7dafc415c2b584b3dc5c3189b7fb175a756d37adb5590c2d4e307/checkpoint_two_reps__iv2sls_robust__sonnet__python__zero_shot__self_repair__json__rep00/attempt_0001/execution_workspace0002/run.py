import pandas as pd
import numpy as np
import json
import statsmodels.api as sm

df = pd.read_csv('./input.csv')

y = df['y_iv'].values
X_endog = df['x1_iv'].values
Z = df['z'].values
n = len(df)

# First stage: regress x1_iv on const and z
X1 = np.column_stack([np.ones(n), Z])
first_stage = sm.OLS(X_endog, X1).fit()
x1_hat = first_stage.fittedvalues

# Second stage: regress y_iv on const and fitted x1_iv
X_proj = np.column_stack([np.ones(n), x1_hat])
second_stage = sm.OLS(y, X_proj).fit()
beta = second_stage.params

# HC1 robust SEs for 2SLS
# Residuals use actual endogenous variable
X_actual = np.column_stack([np.ones(n), X_endog])
resid = y - X_actual @ beta

k = X_proj.shape[1]
scale = n / (n - k)

XtX_inv = np.linalg.inv(X_proj.T @ X_proj)
meat = X_proj.T @ (resid**2 * scale * X_proj.T).T
V = XtX_inv @ meat @ XtX_inv
se = np.sqrt(np.diag(V))

result = {
    "task_id": "iv2sls_robust",
    "platform": "python",
    "estimates": [
        {"term": "const", "estimate": float(beta[0]), "se": float(se[0]), "n_obs": int(n)},
        {"term": "x1_iv", "estimate": float(beta[1]), "se": float(se[1]), "n_obs": int(n)}
    ],
    "method_metadata": {"estimator": "2SLS", "vcov": "HC1"},
    "diagnostics": {}
}

with open('./result.json', 'w') as f:
    json.dump(result, f, indent=2)
