import pandas as pd
import numpy as np
import json
from statsmodels.tsa.vector_ar.var_model import VAR

df = pd.read_csv('./input.csv')
data = df[['y1', 'y2']].dropna()
n_obs = len(data)

model = VAR(data)
results = model.fit(2, trend='c')

irf = results.irf(4)
# irf.orth_irfs shape: (horizons+1, neqs, neqs)
# orth_irfs[h, i, j] = response of variable i to shock in variable j
# y1 is index 0, y2 is index 1
irf_y1_to_y2_h4 = float(irf.orth_irfs[4, 0, 1])

output = {
    "task_id": "var_irf",
    "platform": "python",
    "estimates": [
        {
            "term": "irf_y1_to_y2_h4",
            "estimate": irf_y1_to_y2_h4,
            "se": None,
            "n_obs": n_obs
        }
    ],
    "method_metadata": {
        "estimator": "VAR(2) with constant, Cholesky identification (y1 ordered first)",
        "vcov": "OLS"
    },
    "diagnostics": {}
}

with open('./result.json', 'w') as f:
    json.dump(output, f, indent=2)
