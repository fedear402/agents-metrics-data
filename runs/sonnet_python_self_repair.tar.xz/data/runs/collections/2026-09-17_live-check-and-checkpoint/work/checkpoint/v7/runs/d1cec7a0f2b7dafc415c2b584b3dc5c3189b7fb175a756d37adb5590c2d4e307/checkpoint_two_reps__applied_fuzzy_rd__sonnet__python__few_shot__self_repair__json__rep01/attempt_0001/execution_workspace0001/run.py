import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df.columns = df.columns.str.strip()

bw = 1.0
mask = df["score"].abs() < bw
df = df[mask].copy()
n_obs = len(df)

score = df["score"].values
weights = 1.0 - np.abs(score)
above = (score >= 0).astype(float)
earnings = df["earnings"].values
participated = df["participated"].values

X = np.column_stack([
    np.ones(n_obs),
    above,
    score,
    above * score
])

W = weights

def wls_fit(y, X, W):
    WX = W[:, None] * X
    bread = np.linalg.inv(X.T @ WX)
    coef = bread @ (WX.T @ y)
    return coef, bread

def hc0_joint(X, W, residuals_y, residuals_p, bread_y, bread_p, contrast):
    loading_y = W * (X @ bread_y @ contrast)
    loading_p = W * (X @ bread_p @ contrast)
    
    inf_y = loading_y * residuals_y
    inf_p = loading_p * residuals_p
    
    var_y = np.sum(inf_y**2)
    var_p = np.sum(inf_p**2)
    cov_yp = np.sum(inf_y * inf_p)
    
    return var_y, var_p, cov_yp

coef_e, bread_e = wls_fit(earnings, X, W)
coef_p, bread_p = wls_fit(participated, X, W)

resid_e = earnings - X @ coef_e
resid_p = participated - X @ coef_p

contrast = np.array([0., 1., 0., 0.])

reduced_form = float(contrast @ coef_e)
first_stage = float(contrast @ coef_p)
treatment_effect = reduced_form / first_stage

var_e, var_p, cov_ep = hc0_joint(X, W, resid_e, resid_p, bread_e, bread_p, contrast)

se_rf = float(np.sqrt(var_e))
se_fs = float(np.sqrt(var_p))

grad = np.array([1.0 / first_stage, -reduced_form / first_stage**2])
joint = np.array([[var_e, cov_ep], [cov_ep, var_p]])
se_te = float(np.sqrt(grad @ joint @ grad))

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": treatment_effect, "se": se_te, "n_obs": n_obs},
        {"term": "reduced_form", "estimate": reduced_form, "se": se_rf, "n_obs": n_obs},
        {"term": "first_stage", "estimate": first_stage, "se": se_fs, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "fuzzy_rd_local_linear",
        "vcov": "HC0"
    },
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2, allow_nan=False)
