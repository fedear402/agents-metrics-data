import json
import numpy as np
import pandas as pd
from scipy.optimize import minimize

df = pd.read_csv("./input.csv")
df = df.sort_values("t_obs").reset_index(drop=True)

times = df["t_obs"].values
events = df["event"].values
X = df[["treat", "x"]].values
n = len(df)

def neg_log_partial_likelihood(beta):
    xb = X @ beta
    ll = 0.0
    for i in range(n):
        if events[i] == 1:
            risk_set = times >= times[i]
            log_denom = np.log(np.sum(np.exp(xb[risk_set])))
            ll += xb[i] - log_denom
    return -ll

def neg_log_pl_gradient(beta):
    xb = X @ beta
    grad = np.zeros(2)
    for i in range(n):
        if events[i] == 1:
            risk_set = times >= times[i]
            exp_xb_risk = np.exp(xb[risk_set])
            denom = np.sum(exp_xb_risk)
            weighted_x = X[risk_set] * exp_xb_risk[:, None]
            grad += X[i] - weighted_x.sum(axis=0) / denom
    return -grad

beta0 = np.zeros(2)
result = minimize(neg_log_partial_likelihood, beta0, jac=neg_log_pl_gradient, method="BFGS")
beta_hat = result.x

# Compute Hessian numerically for standard errors
eps = 1e-5
hess = np.zeros((2, 2))
for i in range(2):
    for j in range(2):
        e_i = np.zeros(2); e_i[i] = eps
        e_j = np.zeros(2); e_j[j] = eps
        hess[i, j] = (
            neg_log_partial_likelihood(beta_hat + e_i + e_j)
            - neg_log_partial_likelihood(beta_hat + e_i - e_j)
            - neg_log_partial_likelihood(beta_hat - e_i + e_j)
            + neg_log_partial_likelihood(beta_hat - e_i - e_j)
        ) / (4 * eps * eps)

var_cov = np.linalg.inv(hess)
se = np.sqrt(np.diag(var_cov))

n_obs = int(n)

out = {
    "task_id": "cox_hazard",
    "platform": "python",
    "estimates": [
        {"term": "treat", "estimate": float(beta_hat[0]), "se": float(se[0]), "n_obs": n_obs},
        {"term": "x", "estimate": float(beta_hat[1]), "se": float(se[1]), "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "Cox proportional hazards (Efron partial likelihood)",
        "vcov": "model-based (inverse Hessian)",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(out, f)
