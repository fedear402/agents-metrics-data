import pandas as pd
import json
import numpy as np
from statsmodels.duration.hazard_regression import PHReg

df = pd.read_csv("./input.csv")

model = PHReg(df["t_obs"], df[["treat", "x"]], status=df["event"], ties="efron")
result_fit = model.fit()

params = result_fit.params
bse = result_fit.bse
n_obs = int(result_fit.nobs)

estimates = []
for i, term in enumerate(["treat", "x"]):
    estimates.append({
        "term": term,
        "estimate": float(params[i]),
        "se": float(bse[i]),
        "n_obs": n_obs
    })

output = {
    "task_id": "cox_hazard",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "Cox Proportional Hazards (statsmodels PHReg)",
        "vcov": "Efron partial likelihood"
    },
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(output, f, indent=2)
