import pandas as pd
import numpy as np
import json
from scipy import stats
from scipy.optimize import minimize

df = pd.read_csv('./input.csv')
y = df['y'].values
x = df['x'].values
z = df['z'].values
n = len(y)

X = np.column_stack([x, z])

def log_likelihood(params):
    b1, b2, c1, c2 = params
    xb = b1 * x + b2 * z
    # P(y <= 1) = logistic(c1 - xb)
    # P(y <= 2) = logistic(c2 - xb)
    p1 = 1 / (1 + np.exp(-(c1 - xb)))
    p2 = 1 / (1 + np.exp(-(c2 - xb)))
    
    p_cat1 = p1
    p_cat2 = p2 - p1
    p_cat3 = 1 - p2
    
    p_cat1 = np.clip(p_cat1, 1e-15, 1)
    p_cat2 = np.clip(p_cat2, 1e-15, 1)
    p_cat3 = np.clip(p_cat3, 1e-15, 1)
    
    ll = np.where(y == 1, np.log(p_cat1),
         np.where(y == 2, np.log(p_cat2), np.log(p_cat3)))
    return -np.sum(ll)

def neg_log_likelihood(params):
    b1, b2, c1, c2 = params
    if c2 <= c1:
        return 1e10
    return log_likelihood(params)

x0 = [0.0, 0.0, -0.5, 0.5]
result = minimize(neg_log_likelihood, x0, method='BFGS', 
                  options={'maxiter': 10000, 'gtol': 1e-8})

params_hat = result.x
b1_hat, b2_hat, c1_hat, c2_hat = params_hat

hess_inv = result.hess_inv
se = np.sqrt(np.diag(hess_inv))

se_b1 = se[0]
se_b2 = se[1]

# prob_high for x=1, z=0
xb_new = b1_hat * 1 + b2_hat * 0
p2_new = 1 / (1 + np.exp(-(c2_hat - xb_new)))
prob_high = 1 - p2_new

output = {
    "task_id": "broad_ordered_logit",
    "platform": "python",
    "estimates": [
        {"term": "x", "estimate": float(b1_hat), "se": float(se_b1), "n_obs": int(n)},
        {"term": "z", "estimate": float(b2_hat), "se": float(se_b2), "n_obs": int(n)},
        {"term": "prob_high", "estimate": float(prob_high), "se": None, "n_obs": int(n)}
    ],
    "method_metadata": {
        "estimator": "ordered_logit_mle",
        "vcov": "observed_information_bfgs_inverse"
    },
    "diagnostics": {}
}

with open('./result.json', 'w') as f:
    json.dump(output, f, indent=2)

print("Done. Parameters:", params_hat)
print("SEs:", se)
print("prob_high:", prob_high)
