import json
import numpy as np
import pandas as pd
from lifelines import CoxPHFitter

df = pd.read_csv("./input.csv")

cph = CoxPHFitter()
cph.fit(df[["treat", "x", "t_obs", "event"]], duration_col="t_obs", event_col="event")

summary = cph.summary

n_obs = int(cph.event_observed.shape[0])

out = {
    "task_id": "cox_hazard",
    "platform": "python",
    "estimates": [
        {
            "term": "treat",
            "estimate": float(summary.loc["treat", "coef"]),
            "se": float(summary.loc["treat", "se(coef)"]),
            "n_obs": n_obs,
        },
        {
            "term": "x",
            "estimate": float(summary.loc["x", "coef"]),
            "se": float(summary.loc["x", "se(coef)"]),
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "Cox proportional hazards",
        "vcov": "model-based (Efron partial likelihood)",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(out, f)
