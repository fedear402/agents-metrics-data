import pandas as pd
import numpy as np
from scipy import stats
from scipy.optimize import minimize
import json

df = pd.read_csv('./input.csv')
y = df['y'].values
X = np.column_stack([np.ones(len(df)), df['x'].values, df['z'].values])
n = len(df)

def neg_log_likelihood(params):
    beta = params[:3]
    log_sigma = params[3]
    sigma = np.exp(log_sigma)
    
    mu = X @ beta
    
    censored = (y == 0)
    uncensored = ~censored
    
    ll = 0.0
    if uncensored.any():
        ll += np.sum(stats.norm.logpdf(y[uncensored], loc=mu[uncensored], scale=sigma))
    if censored.any():
        ll += np.sum(stats.norm.logcdf(0, loc=mu[censored], scale=sigma))
    
    return -ll

# Initial values via OLS
from numpy.linalg import lstsq
beta0, _, _, _ = lstsq(X, y, rcond=None)
sigma0 = np.std(y - X @ beta0)
params0 = np.append(beta0, np.log(sigma0))

result = minimize(neg_log_likelihood, params0, method='BFGS', 
                  options={'maxiter': 10000, 'gtol': 1e-8})

params_hat = result.x
sigma_hat = np.exp(params_hat[3])

# Compute Hessian numerically for standard errors
from scipy.optimize import approx_fprime

def hessian(f, x0, eps=1e-5):
    n = len(x0)
    H = np.zeros((n, n))
    f0 = f(x0)
    for i in range(n):
        for j in range(n):
            x_pp = x0.copy(); x_pp[i] += eps; x_pp[j] += eps
            x_pm = x0.copy(); x_pm[i] += eps; x_pm[j] -= eps
            x_mp = x0.copy(); x_mp[i] -= eps; x_mp[j] += eps
            x_mm = x0.copy(); x_mm[i] -= eps; x_mm[j] -= eps
            H[i, j] = (f(x_pp) - f(x_pm) - f(x_mp) + f(x_mm)) / (4 * eps**2)
    return H

H = hessian(neg_log_likelihood, params_hat)
try:
    cov = np.linalg.inv(H)
    se_params = np.sqrt(np.diag(cov))
    se_const = se_params[0]
    se_x = se_params[1]
    se_z = se_params[2]
except:
    se_const = se_x = se_z = None

estimates = [
    {"term": "const", "estimate": float(params_hat[0]), "se": float(se_const) if se_const is not None else None, "n_obs": n},
    {"term": "x", "estimate": float(params_hat[1]), "se": float(se_x) if se_x is not None else None, "n_obs": n},
    {"term": "z", "estimate": float(params_hat[2]), "se": float(se_z) if se_z is not None else None, "n_obs": n},
    {"term": "sigma", "estimate": float(sigma_hat), "se": None, "n_obs": n},
]

output = {
    "task_id": "broad_tobit",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "Tobit MLE (homoskedastic Gaussian, left-censored at 0)",
        "vcov": "observed information (numerical Hessian of log-likelihood)"
    },
    "diagnostics": {}
}

with open('./result.json', 'w') as f:
    json.dump(output, f, indent=2)

print("Done. Results written to result.json")
