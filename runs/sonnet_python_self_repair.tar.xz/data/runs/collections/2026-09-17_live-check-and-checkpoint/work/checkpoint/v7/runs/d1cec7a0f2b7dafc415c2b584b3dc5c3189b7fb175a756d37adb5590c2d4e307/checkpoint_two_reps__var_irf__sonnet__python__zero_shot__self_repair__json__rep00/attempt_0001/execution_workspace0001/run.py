import pandas as pd
import numpy as np
import json
from statsmodels.tsa.vector_ar.var_model import VAR

df = pd.read_csv('./input.csv')
data = df[['y1', 'y2']].dropna()
n_obs = len(data)

model = VAR(data)
results = model.fit(2, trend='c')

irf = results.irf(4)
# irf.irfs shape: (horizons+1, k, k)
# irfs[h, i, j] = response of variable i to shock in variable j (orthogonalized)
# With Cholesky, orth_irfs uses the lower triangular decomposition
orth_irfs = irf.orth_irfs  # shape (5, 2, 2)

# y1 is index 0, y2 is index 1
# response of y1 (index 0) to shock in y2 (index 1) at horizon 4
irf_val = float(orth_irfs[4, 0, 1])

result = {
    "task_id": "var_irf",
    "platform": "python",
    "estimates": [
        {
            "term": "irf_y1_to_y2_h4",
            "estimate": round(irf_val, 10),
            "se": None,
            "n_obs": int(n_obs)
        }
    ],
    "method_metadata": {
        "estimator": "VAR(2) OLS with constant, Cholesky identification",
        "vcov": "asymptotic OLS"
    },
    "diagnostics": {}
}

with open('./result.json', 'w') as f:
    json.dump(result, f, indent=2)
