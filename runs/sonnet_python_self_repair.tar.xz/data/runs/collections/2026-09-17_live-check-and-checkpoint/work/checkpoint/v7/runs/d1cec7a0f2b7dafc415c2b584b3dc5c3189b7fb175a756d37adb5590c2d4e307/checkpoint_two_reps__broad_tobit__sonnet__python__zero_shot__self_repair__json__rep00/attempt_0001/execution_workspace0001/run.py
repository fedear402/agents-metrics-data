import pandas as pd
import numpy as np
from scipy import stats
from scipy.optimize import minimize
import json

df = pd.read_csv("input.csv")
y = df["y"].values
x = df["x"].values
z = df["z"].values
n = len(y)

X = np.column_stack([np.ones(n), x, z])

def neg_log_likelihood(params):
    beta = params[:3]
    log_sigma = params[3]
    sigma = np.exp(log_sigma)
    
    mu = X @ beta
    censored = (y == 0)
    uncensored = ~censored
    
    ll = 0.0
    if uncensored.any():
        residuals = (y[uncensored] - mu[uncensored]) / sigma
        ll += np.sum(stats.norm.logpdf(residuals) - np.log(sigma))
    if censored.any():
        ll += np.sum(stats.norm.logcdf(-mu[censored] / sigma))
    
    return -ll

beta_init = np.linalg.lstsq(X, y, rcond=None)[0]
sigma_init = np.std(y - X @ beta_init)
params_init = np.append(beta_init, np.log(max(sigma_init, 1e-6)))

result = minimize(neg_log_likelihood, params_init, method="BFGS",
                  options={"maxiter": 10000, "gtol": 1e-8})

params_opt = result.x
hess_inv = result.hess_inv

# SE for beta params from hessian inverse (BFGS approx)
# Use numerical hessian for observed information
from scipy.optimize import approx_fprime

def hessian_numerical(f, x0, eps=1e-5):
    n = len(x0)
    H = np.zeros((n, n))
    for i in range(n):
        def grad_i(x):
            return approx_fprime(x, f, eps)[i]
        H[i] = approx_fprime(x0, grad_i, eps)
    return H

H = hessian_numerical(neg_log_likelihood, params_opt)
try:
    cov = np.linalg.inv(H)
    se_params = np.sqrt(np.diag(cov))
except np.linalg.LinAlgError:
    se_params = np.full(4, np.nan)

beta_opt = params_opt[:3]
log_sigma_opt = params_opt[3]
sigma_opt = np.exp(log_sigma_opt)

se_const = float(se_params[0])
se_x = float(se_params[1])
se_z = float(se_params[2])

output = {
    "task_id": "broad_tobit",
    "platform": "python",
    "estimates": [
        {"term": "const", "estimate": float(beta_opt[0]), "se": se_const, "n_obs": n},
        {"term": "x", "estimate": float(beta_opt[1]), "se": se_x, "n_obs": n},
        {"term": "z", "estimate": float(beta_opt[2]), "se": se_z, "n_obs": n},
        {"term": "sigma", "estimate": float(sigma_opt), "se": None, "n_obs": n},
    ],
    "method_metadata": {
        "estimator": "MLE Tobit (homoskedastic Gaussian, lower censoring at 0)",
        "vcov": "observed information (numerical Hessian)"
    },
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(output, f, indent=2)
