import pandas as pd
import numpy as np
import json
from statsmodels.regression.linear_model import OLS
from statsmodels.tools import add_constant

df = pd.read_csv('input.csv')
df = df.sort_values('date').reset_index(drop=True)

df['log_sales'] = np.log(df['sales'])
df['log_vix'] = np.log(df['vix'])
df['d_log_vix'] = df['log_vix'].diff()

for lag in range(1, 16):
    df[f'lag_{lag}'] = df['d_log_vix'].shift(lag)

df_reg = df.dropna(subset=['log_sales'] + [f'lag_{i}' for i in range(1, 16)]).copy()

y = df_reg['log_sales']
X = add_constant(df_reg[[f'lag_{i}' for i in range(1, 16)]])

model = OLS(y, X).fit()
N = len(df_reg)

# Newey-West with max lag 15, Bartlett weights 1-j/16, scaled by N/(N-16)
nw_cov = model.get_robustcov_results(cov_type='HAC', maxlags=15, use_correction=False).cov_params()
scale = N / (N - 16)
nw_cov = nw_cov * scale

params = model.params
lag_names = [f'lag_{i}' for i in range(1, 16)]

# Cumulative response: sum of lag_1 through lag_15 coefficients
# These are indices 1 through 15 in the parameter vector (index 0 is const)
lag_indices = [list(params.index).index(name) for name in lag_names]

cum_coef = sum(params[name] for name in lag_names)

# SE for cumulative response using full covariance matrix
e = np.zeros(len(params))
for idx in lag_indices:
    e[idx] = 1.0
cum_var = e @ nw_cov @ e
cum_se = np.sqrt(cum_var)

lag1_idx = list(params.index).index('lag_1')
lag15_idx = list(params.index).index('lag_15')

lag1_se = np.sqrt(nw_cov[lag1_idx, lag1_idx])
lag15_se = np.sqrt(nw_cov[lag15_idx, lag15_idx])

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {"term": "cumulative_response", "estimate": float(cum_coef), "se": float(cum_se), "n_obs": int(N)},
        {"term": "lag_1", "estimate": float(params['lag_1']), "se": float(lag1_se), "n_obs": int(N)},
        {"term": "lag_15", "estimate": float(params['lag_15']), "se": float(lag15_se), "n_obs": int(N)}
    ],
    "method_metadata": {
        "estimator": "OLS",
        "vcov": "Newey-West HAC, maxlag=15, Bartlett weights 1-j/16, scaled N/(N-16)"
    },
    "diagnostics": {}
}

with open('result.json', 'w') as f:
    json.dump(result, f, indent=2)
