import json
import pandas as pd
import numpy as np
import statsmodels.api as sm

df = pd.read_csv("./input.csv")

X = sm.add_constant(df[["x"]])
y = df["y_twocluster"]

fit = sm.OLS(y, X).fit()

n = len(df)
k = X.shape[1]

# Cameron-Gelbach-Miller two-way cluster robust variance
def cluster_vcov(fit, cluster1, cluster2):
    X = fit.model.exog
    e = fit.resid.values
    
    def one_cluster_meat(clust):
        labels = clust.values
        unique = np.unique(labels)
        meat = np.zeros((X.shape[1], X.shape[1]))
        for lbl in unique:
            idx = labels == lbl
            Xi = X[idx]
            ei = e[idx]
            score = Xi.T @ ei
            meat += np.outer(score, score)
        return meat
    
    bread = np.linalg.inv(X.T @ X)
    
    meat1 = one_cluster_meat(cluster1)
    meat2 = one_cluster_meat(cluster2)
    
    # Intersection cluster
    intersection = cluster1.astype(str) + "_" + cluster2.astype(str)
    meat12 = one_cluster_meat(intersection)
    
    g1 = cluster1.nunique()
    g2 = cluster2.nunique()
    g12 = intersection.nunique()
    
    # Small sample corrections
    def correction(g):
        return (g / (g - 1)) * ((n - 1) / (n - k))
    
    V = (correction(g1) * bread @ meat1 @ bread +
         correction(g2) * bread @ meat2 @ bread -
         correction(g12) * bread @ meat12 @ bread)
    
    return V

V = cluster_vcov(fit, df["firm"], df["year"])
se = np.sqrt(np.diag(V))

out = {
    "task_id": "two_way_cluster",
    "platform": "python",
    "estimates": [
        {"term": "const", "estimate": float(fit.params["const"]), "se": float(se[0]), "n_obs": int(fit.nobs)},
        {"term": "x", "estimate": float(fit.params["x"]), "se": float(se[1]), "n_obs": int(fit.nobs)},
    ],
    "method_metadata": {"estimator": "OLS", "vcov": "two_way_cluster_CGM"},
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(out, f)
