import pandas as pd
import numpy as np
import json

df = pd.read_csv('input.csv')

# One obs per region
regions = df.drop_duplicates('region_id')[['region_id', 'region_weight', 'x', 'y']].copy()
regions['e_r'] = regions['region_weight'] / regions['region_weight'].sum()

# Construct shift-share instrument z_r = sum_n share_rn * shock_n
z = df.groupby('region_id').apply(lambda g: (g['share'] * g['shock']).sum()).reset_index()
z.columns = ['region_id', 'z']
regions = regions.merge(z, on='region_id')

N_industries = df['industry_id'].nunique()

# Weighted means
def wmean(v, w):
    return (v * w).sum() / w.sum()

e = regions['e_r'].values
ym = wmean(regions['y'], regions['e_r'])
xm = wmean(regions['x'], regions['e_r'])
zm = wmean(regions['z'], regions['e_r'])

regions['y0'] = regions['y'] - ym
regions['x0'] = regions['x'] - xm
regions['z0'] = regions['z'] - zm

# Shock-level aggregation
# s_n = sum_r e_r * share_rn
ind_data = df.merge(regions[['region_id', 'e_r', 'y0', 'x0', 'z0']], on='region_id')
ind_data['e_share'] = ind_data['e_r'] * ind_data['share']
s_n = ind_data.groupby('industry_id')['e_share'].sum().reset_index()
s_n.columns = ['industry_id', 's_n']

def agg_var(varname):
    tmp = ind_data.copy()
    tmp['num'] = tmp['e_r'] * tmp['share'] * tmp[varname]
    num = tmp.groupby('industry_id')['num'].sum().reset_index()
    num.columns = ['industry_id', 'num']
    res = num.merge(s_n, on='industry_id')
    res[f'{varname}bar'] = res['num'] / res['s_n']
    return res[['industry_id', f'{varname}bar']]

ybar = agg_var('y0')
xbar = agg_var('x0')
zbar = agg_var('z0')

shocks = df[['industry_id', 'shock']].drop_duplicates()
ind = s_n.merge(shocks, on='industry_id').merge(ybar, on='industry_id').merge(xbar, on='industry_id').merge(zbar, on='industry_id')

N = len(ind)
w = ind['s_n'].values
shock = ind['shock'].values
xb = ind['x0bar'].values
yb = ind['y0bar'].values
zb = ind['z0bar'].values

# Weighted IV: ybar ~ xbar, instrument = shock, weights = s_n
# First stage of shock-level IV: xbar ~ shock (weighted by s_n)
def wls_slope(endog, exog_inst, weights):
    # Weighted regression of endog on intercept + exog_inst
    W = np.diag(weights)
    X = np.column_stack([np.ones(len(endog)), exog_inst])
    XtW = X.T @ W
    beta = np.linalg.solve(XtW @ X, XtW @ endog)
    return beta

# 2SLS slope (shock-level): regress ybar on xbar, instrument xbar with shock
# First stage: regress xbar on shock (weighted)
beta_fs_sl = wls_slope(xb, shock, w)  # xbar on shock
xb_hat = beta_fs_sl[0] + beta_fs_sl[1] * shock

# Second stage: regress ybar on xb_hat (weighted)
beta_2sls_sl = wls_slope(yb, xb_hat, w)
effect_slope = beta_2sls_sl[1]

# Structural residuals for 2SLS: u = ybar - beta[0] - beta[1]*xbar
u_2sls = yb - beta_2sls_sl[0] - beta_2sls_sl[1] * xb

# HC1 SE for 2SLS at shock level
# V = (Z'WX)^{-1} (Z'W diag(u^2) WZ) (X'WZ)^{-1} * N/(N-2)
# where Z = [1, shock], X = [1, xbar]
Z_mat = np.column_stack([np.ones(N), shock])
X_mat = np.column_stack([np.ones(N), xb])
W_mat = np.diag(w)

ZtWX = Z_mat.T @ W_mat @ X_mat
ZtWZ = Z_mat.T @ W_mat @ Z_mat
# Meat: sum_n w_n^2 * u_n^2 * z_n * z_n' ... actually:
# Standard HC1 sandwich for IV
# V = (Z'WX)^{-1} * [sum_n w_n * u_n^2 * (w_n * z_n)(w_n * z_n)' ... 
# Let me be careful: analytic weights, structural residuals
# V(beta_IV) = (Z'WX)^{-1} * (Z'W * diag(u^2) * W * Z) * (X'WZ)^{-1} * N/(N-2)
ZtWX_inv = np.linalg.inv(ZtWX)
meat = Z_mat.T @ W_mat @ np.diag(u_2sls**2) @ W_mat @ Z_mat
V_2sls = ZtWX_inv @ meat @ ZtWX_inv.T * N / (N - 2)
se_effect = np.sqrt(V_2sls[1, 1])

# First stage (regional): slope of x on z weighted by e_r
beta_fs_reg = wls_slope(regions['x'].values, regions['z'].values, regions['e_r'].values)
fs_slope = beta_fs_reg[1]

# Exposure-robust SE for first stage:
# Shock-level IV: xbar ~ zbar, instrument zbar with shock, weights s_n
beta_fs2_sl = wls_slope(zb, shock, w)  # first stage of zbar on shock
zb_hat = beta_fs2_sl[0] + beta_fs2_sl[1] * shock

beta_fs_iv_sl = wls_slope(xb, zb_hat, w)
# structural residuals
u_fs = xb - beta_fs_iv_sl[0] - beta_fs_iv_sl[1] * zb

Z_mat2 = np.column_stack([np.ones(N), shock])
X_mat2 = np.column_stack([np.ones(N), zb])

ZtWX2 = Z_mat2.T @ W_mat @ X_mat2
ZtWX2_inv = np.linalg.inv(ZtWX2)
meat2 = Z_mat2.T @ W_mat @ np.diag(u_fs**2) @ W_mat @ Z_mat2
V_fs = ZtWX2_inv @ meat2 @ ZtWX2_inv.T * N / (N - 2)
se_fs = np.sqrt(V_fs[1, 1])

# Effective shocks
effective_shocks = 1.0 / (w**2).sum()

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": float(effect_slope), "se": float(se_effect), "n_obs": int(N)},
        {"term": "first_stage", "estimate": float(fs_slope), "se": float(se_fs), "n_obs": int(N)},
        {"term": "effective_shocks", "estimate": float(effective_shocks), "se": None, "n_obs": int(N)}
    ],
    "method_metadata": {
        "estimator": "2SLS shift-share with Borusyak-Hull-Jaravel exposure-robust SE",
        "vcov": "HC1 shock-level"
    },
    "diagnostics": {}
}

with open('result.json', 'w') as f:
    json.dump(result, f, indent=2)
