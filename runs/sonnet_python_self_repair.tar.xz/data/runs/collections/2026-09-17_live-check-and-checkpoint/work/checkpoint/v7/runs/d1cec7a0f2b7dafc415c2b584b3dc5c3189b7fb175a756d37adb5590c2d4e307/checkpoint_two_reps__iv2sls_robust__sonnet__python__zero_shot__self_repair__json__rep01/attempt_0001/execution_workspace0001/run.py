import pandas as pd
import numpy as np
import json
from linearmodels.iv import IV2SLS

df = pd.read_csv("./input.csv")

res = IV2SLS(df["y_iv"], df[["x1_iv"]], None, df[["z"]]).fit(cov_type="robust")

n_obs = int(res.nobs)
params = res.params
ses = res.std_errors

estimates = [
    {"term": "const", "estimate": float(params.get("const", np.nan)), "se": float(ses.get("const", np.nan)) if "const" in ses else None, "n_obs": n_obs},
    {"term": "x1_iv", "estimate": float(params["x1_iv"]), "se": float(ses["x1_iv"]), "n_obs": n_obs},
]

# linearmodels IV2SLS with exog=None doesn't include intercept by default; add const explicitly
from linearmodels.iv import IV2SLS as IV2SLS2
import statsmodels.api as sm

endog = df["y_iv"]
exog = sm.add_constant(pd.DataFrame(index=df.index))  # const only as exogenous
endog_reg = df["x1_iv"]
instruments = sm.add_constant(df[["z"]])

# Use statsmodels IV2SLS instead
from statsmodels.sandbox.regression.gmm import IV2SLS as smIV2SLS

endog_col = df["y_iv"].values
exog_cols = sm.add_constant(df["x1_iv"]).values
instr_cols = sm.add_constant(df["z"]).values

model = smIV2SLS(endog_col, exog_cols, instrument=instr_cols)
results = model.fit()

# HC1 robust std errors
hc1 = results.get_robustcov_results(cov_type="HC1")
params2 = hc1.params
ses2 = hc1.bse
n_obs2 = int(hc1.nobs)

estimates = [
    {"term": "const", "estimate": float(params2[0]), "se": float(ses2[0]), "n_obs": n_obs2},
    {"term": "x1_iv", "estimate": float(params2[1]), "se": float(ses2[1]), "n_obs": n_obs2},
]

output = {
    "task_id": "iv2sls_robust",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {"estimator": "IV2SLS", "vcov": "HC1"},
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(output, f, indent=2)
