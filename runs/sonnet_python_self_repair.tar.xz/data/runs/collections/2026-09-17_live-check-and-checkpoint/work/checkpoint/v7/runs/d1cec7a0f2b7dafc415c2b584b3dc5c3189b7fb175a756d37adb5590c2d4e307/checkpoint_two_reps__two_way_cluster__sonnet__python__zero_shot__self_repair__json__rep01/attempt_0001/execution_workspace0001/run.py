import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

df = pd.read_csv("./input.csv")

y = df["y_twocluster"].values
X = sm.add_constant(df["x"].values)
n = len(y)

# OLS estimates
b = np.linalg.lstsq(X, y, rcond=None)[0]
e = y - X @ b

# Cameron-Gelbach-Miller two-way cluster robust SE
firms = df["firm"].values
years = df["year"].values

def cluster_meat(resids, X, group):
    labels = np.unique(group)
    meat = np.zeros((X.shape[1], X.shape[1]))
    for g in labels:
        idx = group == g
        Xg = X[idx]
        eg = resids[idx]
        s = Xg.T @ eg
        meat += np.outer(s, s)
    return meat

meat_firm = cluster_meat(e, X, firms)
meat_year = cluster_meat(e, X, years)
meat_both = cluster_meat(e, X, firms * 10000 + years)

meat_cgm = meat_firm + meat_year - meat_both

XtX_inv = np.linalg.inv(X.T @ X)
vcov = XtX_inv @ meat_cgm @ XtX_inv

ses = np.sqrt(np.diag(vcov))

result = {
    "task_id": "two_way_cluster",
    "platform": "python",
    "estimates": [
        {"term": "const", "estimate": float(b[0]), "se": float(ses[0]), "n_obs": int(n)},
        {"term": "x", "estimate": float(b[1]), "se": float(ses[1]), "n_obs": int(n)}
    ],
    "method_metadata": {
        "estimator": "OLS",
        "vcov": "Cameron-Gelbach-Miller two-way cluster robust (firm, year)"
    },
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
