import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

df = pd.read_csv("input.csv")
df = df.sort_values("time").reset_index(drop=True)
y = df["y"].values

forecasts = {}
for f in range(101, 251):
    window = y[f-100:f-1]  # indices f-100 to f-2 (0-indexed), values y_(f-99) to y_(f-1)
    # Actually: y_(f-100),...,y_(f-1) are the 100 observed levels
    # Regression pairs: y_s = a + b*y_(s-1) for s=f-99,...,f-1
    # s=f-99: y_(f-99) ~ y_(f-100)
    # s=f-1:  y_(f-1) ~ y_(f-2)
    # So X = y_(f-100),...,y_(f-2) (99 values), Y = y_(f-99),...,y_(f-1) (99 values)
    Y = y[f-99:f]    # 0-indexed: indices f-99 to f-1 => y_(f-98+1)... wait let me recount
    # time is 1-indexed, array is 0-indexed: y[i] = y_(i+1)
    # y_(f-100) = y[f-101], y_(f-1) = y[f-2], y_(f) = y[f-1]
    # pairs: s=f-99,...,f-1 (99 pairs)
    # Y_reg[k] = y_(f-99+k) = y[f-100+k], k=0..98
    # X_reg[k] = y_(f-100+k) = y[f-101+k], k=0..98
    Y_reg = y[f-100:f-1]   # indices f-100 to f-2, length 99
    X_reg = y[f-101:f-2]   # indices f-101 to f-3... wait
    # k=0: Y=y[f-100], X=y[f-101]
    # k=98: Y=y[f-2], X=y[f-3]
    # That's only 99 pairs but uses y_(f-100) as dependent var first pair
    # Let me redo: s=f-99 to f-1 (inclusive), 99 values
    # y_s ~ y_(s-1)
    # s=f-99: dep=y_(f-99)=y[f-100], indep=y_(f-100)=y[f-101]
    # s=f-1:  dep=y_(f-1)=y[f-2],   indep=y_(f-2)=y[f-3]
    Y_reg = y[f-100:f-1]  # length 99: y[f-100]...y[f-2]
    X_reg = y[f-101:f-2]  # length 99: y[f-101]...y[f-3]
    X_const = sm.add_constant(X_reg)
    model = sm.OLS(Y_reg, X_const).fit()
    a_hat, b_hat = model.params
    y_prev = y[f-2]  # y_(f-1) = y[f-2] in 0-indexed
    forecasts[f] = a_hat + b_hat * y_prev

actuals = {f: y[f-1] for f in range(101, 251)}
rmse = np.sqrt(sum((actuals[f] - forecasts[f])**2 for f in range(101, 251)) / 150)

result = {
    "task_id": "hard_rolling",
    "platform": "python",
    "estimates": [
        {"term": "rmse", "estimate": float(rmse), "se": None, "n_obs": 150},
        {"term": "forecast_101", "estimate": float(forecasts[101]), "se": None, "n_obs": 99},
        {"term": "forecast_150", "estimate": float(forecasts[150]), "se": None, "n_obs": 99},
        {"term": "forecast_200", "estimate": float(forecasts[200]), "se": None, "n_obs": 99},
        {"term": "forecast_250", "estimate": float(forecasts[250]), "se": None, "n_obs": 99},
    ],
    "method_metadata": {"estimator": "OLS AR(1) rolling", "vcov": "null"},
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
