import pandas as pd
import numpy as np
import statsmodels.formula.api as smf
import json

df = pd.read_csv('./input.csv')

# Demean for two-way FE (within transformation)
df['firm'] = df['firm'].astype('category')
df['year'] = df['year'].astype('category')

# Use statsmodels with absorbed fixed effects via entity/time dummies
# Add firm and year dummies explicitly
model = smf.ols('y_twocluster ~ x + C(firm) + C(year)', data=df)
result = model.fit(cov_type='cluster', cov_kwds={'groups': df['firm']})

x_coef = result.params['x']
x_se = result.bse['x']
n_obs = int(result.nobs)

output = {
    "task_id": "twoway_fe",
    "platform": "python",
    "estimates": [
        {"term": "x", "estimate": float(x_coef), "se": float(x_se), "n_obs": n_obs}
    ],
    "method_metadata": {
        "estimator": "OLS with firm and year fixed effects",
        "vcov": "clustered on firm"
    },
    "diagnostics": {}
}

with open('./result.json', 'w') as f:
    json.dump(output, f, indent=2)
