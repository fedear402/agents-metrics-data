import pandas as pd
import numpy as np
from scipy import stats
import json

df = pd.read_csv('./input.csv')
n = len(df)
y = df['y'].values
endog = df['endog'].values
x = df['x'].values
z1 = df['z1'].values
z2 = df['z2'].values

def ar_f_stat(beta):
    lhs = y - beta * endog
    X = np.column_stack([np.ones(n), x, z1, z2])
    X_restricted = np.column_stack([np.ones(n), x])
    
    # Full model
    coef_full, _, _, _ = np.linalg.lstsq(X, lhs, rcond=None)
    resid_full = lhs - X @ coef_full
    rss_full = resid_full @ resid_full
    
    # Restricted model (no z1, z2)
    coef_restricted, _, _, _ = np.linalg.lstsq(X_restricted, lhs, rcond=None)
    resid_restricted = lhs - X_restricted @ coef_restricted
    rss_restricted = resid_restricted @ resid_restricted
    
    df_num = 2
    df_denom = n - 4
    
    f_stat = ((rss_restricted - rss_full) / df_num) / (rss_full / df_denom)
    return f_stat

critical_value = stats.f.ppf(0.95, 2, n - 4)

# The AR test inverts to a quadratic in beta
# F(beta) <= critical_value defines the confidence set
# F(beta) = [(RSS_restricted(beta) - RSS_full(beta))/2] / [RSS_full(beta)/(n-4)]
# This is a rational function in beta, leading to a quadratic equation at the boundary

# Let's derive analytically
# lhs = y - beta*endog
# RSS_full(beta): project lhs on [1, x, z1, z2]
# RSS_restricted(beta): project lhs on [1, x]
# 
# Let M_full = I - X(X'X)^{-1}X' (annihilator for full)
# Let M_rest = I - X_r(X_r'X_r)^{-1}X_r' (annihilator for restricted)
# 
# lhs = y - beta*endog = a - beta*b where a=y, b=endog
# RSS_full = (a - beta*b)' M_full (a - beta*b)
#          = a'M_full a - 2*beta*(a'M_full b) + beta^2*(b'M_full b)
# RSS_restricted = similarly
#
# F(beta) = [(RSS_rest - RSS_full)/2] / [RSS_full/(n-4)]
# F(beta) <= c  =>  (RSS_rest - RSS_full)/2 <= c * RSS_full/(n-4)
# (RSS_rest - RSS_full)*(n-4) <= 2*c * RSS_full
# (n-4)*(RSS_rest - RSS_full) - 2*c*RSS_full <= 0

X_full = np.column_stack([np.ones(n), x, z1, z2])
X_rest = np.column_stack([np.ones(n), x])

def proj_matrix(X):
    return X @ np.linalg.solve(X.T @ X, X.T)

P_full = proj_matrix(X_full)
P_rest = proj_matrix(X_rest)
M_full = np.eye(n) - P_full
M_rest = np.eye(n) - P_rest

a = y
b = endog

# Quadratic coefficients for RSS_full(beta) = A_f*beta^2 - 2*B_f*beta + C_f
A_f = b @ M_full @ b
B_f = a @ M_full @ b
C_f = a @ M_full @ a

A_r = b @ M_rest @ b
B_r = a @ M_rest @ b
C_r = a @ M_rest @ a

# F(beta) = [(RSS_r - RSS_f)/2] / [RSS_f/(n-4)]
# Boundary: F(beta) = c_val
# (RSS_r - RSS_f)/2 = c_val * RSS_f / (n-4)
# (n-4)*(RSS_r - RSS_f) = 2*c_val * RSS_f
# (n-4)*(RSS_r - RSS_f) - 2*c_val*RSS_f = 0

c_val = critical_value
df_denom = n - 4

# RSS_r - RSS_f = (A_r - A_f)*beta^2 - 2*(B_r - B_f)*beta + (C_r - C_f)
dA = A_r - A_f
dB = B_r - B_f
dC = C_r - C_f

# (n-4)*[dA*beta^2 - 2*dB*beta + dC] - 2*c_val*[A_f*beta^2 - 2*B_f*beta + C_f] = 0
# [df_denom*dA - 2*c_val*A_f]*beta^2 + [-2*df_denom*dB + 4*c_val*B_f]*beta + [df_denom*dC - 2*c_val*C_f] = 0

qa = df_denom * dA - 2 * c_val * A_f
qb = -2 * df_denom * dB + 4 * c_val * B_f
qc = df_denom * dC - 2 * c_val * C_f

discriminant = qb**2 - 4 * qa * qc

# Compute F at beta=1
f_at_one = ar_f_stat(1.0)

# Compute F at beta=0
f_at_zero = ar_f_stat(0.0)
accepts_zero = 1 if f_at_zero <= critical_value else 0

if abs(qa) < 1e-12:
    # Linear or degenerate case
    if abs(qb) < 1e-12:
        # Constant - either always accepted or never
        boundary_low = None
        boundary_high = None
        unbounded = 1
    else:
        # Single root
        root = -qc / qb
        boundary_low = root
        boundary_high = root
        unbounded = 0
else:
    if discriminant < 0:
        # No real roots - set is either empty or all reals
        # Check at beta=0
        val_at_zero = qa * 0 + qb * 0 + qc  # = qc
        if qa > 0:
            # parabola opens up, all values above minimum, no real crossings
            # If qc > 0 (same sign as qa), quadratic always positive -> F always > c -> empty set
            # Actually: condition is qa*beta^2 + qb*beta + qc <= 0
            # If discriminant < 0 and qa > 0, always positive -> never satisfied -> empty
            boundary_low = np.nan
            boundary_high = np.nan
            unbounded = 0
        else:
            # qa < 0, parabola opens down, always negative -> always satisfied -> unbounded
            boundary_low = np.nan
            boundary_high = np.nan
            unbounded = 1
    else:
        root1 = (-qb - np.sqrt(discriminant)) / (2 * qa)
        root2 = (-qb + np.sqrt(discriminant)) / (2 * qa)
        r_low = min(root1, root2)
        r_high = max(root1, root2)
        
        if qa > 0:
            # Parabola opens up: quadratic <= 0 between the roots -> bounded interval
            boundary_low = r_low
            boundary_high = r_high
            unbounded = 0
        else:
            # Parabola opens down: quadratic <= 0 outside the roots -> two rays, unbounded
            boundary_low = r_low
            boundary_high = r_high
            unbounded = 1

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": [
        {"term": "boundary_low", "estimate": float(boundary_low) if boundary_low is not None and not np.isnan(boundary_low) else None, "se": None, "n_obs": n},
        {"term": "boundary_high", "estimate": float(boundary_high) if boundary_high is not None and not np.isnan(boundary_high) else None, "se": None, "n_obs": n},
        {"term": "accepts_zero", "estimate": float(accepts_zero), "se": None, "n_obs": n},
        {"term": "unbounded", "estimate": float(unbounded), "se": None, "n_obs": n},
        {"term": "ar_f_at_one", "estimate": float(f_at_one), "se": None, "n_obs": n}
    ],
    "method_metadata": {
        "estimator": "Anderson-Rubin confidence set via F-test inversion",
        "vcov": "homoskedastic"
    },
    "diagnostics": {}
}

with open('./result.json', 'w') as f:
    json.dump(result, f, indent=2)

print("boundary_low:", boundary_low)
print("boundary_high:", boundary_high)
print("accepts_zero:", accepts_zero)
print("unbounded:", unbounded)
print("ar_f_at_one:", f_at_one)
print("critical_value:", critical_value)
