import json
import numpy as np
import pandas as pd

df = pd.read_csv('input.csv')

# Normalize regional weights (one obs per region)
regions = df.drop_duplicates('region_id')[['region_id', 'region_weight']].copy()
regions['e_r'] = regions['region_weight'] / regions['region_weight'].sum()
df = df.merge(regions[['region_id', 'e_r']], on='region_id')

# Get region-level data (x, y, z)
region_df = df.groupby('region_id').apply(lambda g: pd.Series({
    'e_r': g['e_r'].iloc[0],
    'x': g['x'].iloc[0],
    'y': g['y'].iloc[0],
    'z': (g['share'] * g['shock']).sum()
})).reset_index()

e_r = region_df['e_r'].values
x_r = region_df['x'].values
y_r = region_df['y'].values
z_r = region_df['z'].values

# Subtract weighted means
x0 = x_r - np.sum(e_r * x_r)
y0 = y_r - np.sum(e_r * y_r)
z0 = z_r - np.sum(e_r * z_r)

# Industry-level aggregation
industries = df['industry_id'].unique()
industry_shocks = df.drop_duplicates('industry_id').set_index('industry_id')['shock']

s_n = []
xbar_n = []
ybar_n = []
zbar_n = []
shock_n = []

region_x0 = dict(zip(region_df['region_id'], x0))
region_y0 = dict(zip(region_df['region_id'], y0))
region_z0 = dict(zip(region_df['region_id'], z0))
region_e = dict(zip(region_df['region_id'], e_r))

for ind in industries:
    sub = df[df['industry_id'] == ind]
    sn = sum(region_e[r] * row['share'] for r, row in zip(sub['region_id'], sub.to_dict('records')))
    if sn == 0:
        continue
    xb = sum(region_e[r] * row['share'] * region_x0[r] for r, row in zip(sub['region_id'], sub.to_dict('records'))) / sn
    yb = sum(region_e[r] * row['share'] * region_y0[r] for r, row in zip(sub['region_id'], sub.to_dict('records'))) / sn
    zb = sum(region_e[r] * row['share'] * region_z0[r] for r, row in zip(sub['region_id'], sub.to_dict('records'))) / sn
    s_n.append(sn)
    xbar_n.append(xb)
    ybar_n.append(yb)
    zbar_n.append(zb)
    shock_n.append(industry_shocks[ind])

s_n = np.array(s_n)
xbar_n = np.array(xbar_n)
ybar_n = np.array(ybar_n)
zbar_n = np.array(zbar_n)
shock_n = np.array(shock_n)
N = len(s_n)

def shock_iv(dependent, endogenous, instrument, weights):
    n = len(dependent)
    regressors = np.column_stack([np.ones(n), endogenous])
    instruments = np.column_stack([np.ones(n), instrument])
    cross = instruments.T @ (weights[:, None] * regressors)
    beta = np.linalg.solve(cross, instruments.T @ (weights * dependent))
    residual = dependent - regressors @ beta
    scores = instruments * (weights * residual)[:, None]
    inverse = np.linalg.inv(cross)
    hc1 = n / (n - 2)
    covariance = hc1 * inverse @ (scores.T @ scores) @ inverse.T
    return float(beta[1]), float(np.sqrt(covariance[1, 1]))

# Effect: shock-level IV of ybar on xbar, instrument=shock
effect, effect_se = shock_iv(ybar_n, xbar_n, shock_n, s_n)

# First stage: shock-level IV of xbar on zbar, instrument=shock (zbar is endogenous)
first_stage, first_stage_se = shock_iv(xbar_n, zbar_n, shock_n, s_n)

# Effective shocks
effective_shocks = 1.0 / np.sum(s_n ** 2)

output = {
    'task_id': 'applied_shift_share',
    'platform': 'python',
    'estimates': [
        {'term': 'effect', 'estimate': effect, 'se': effect_se, 'n_obs': N},
        {'term': 'first_stage', 'estimate': first_stage, 'se': first_stage_se, 'n_obs': N},
        {'term': 'effective_shocks', 'estimate': float(effective_shocks), 'se': None, 'n_obs': N}
    ],
    'method_metadata': {
        'estimator': '2SLS shift-share IV with exposure-robust SE',
        'vcov': 'HC1 shock-level heteroskedasticity-robust'
    },
    'diagnostics': {}
}

with open('result.json', 'w') as f:
    json.dump(output, f, indent=2, allow_nan=False)
