import pandas as pd
import numpy as np
import json
from linearmodels.iv import IV2SLS

df = pd.read_csv('./input.csv')

res = IV2SLS(df['y_iv'], df[['const']].assign(const=1), df[['x1_iv']], df[['z']]).fit(cov_type='unadjusted')

# Use linearmodels IV2SLS with HC1
from linearmodels.iv import IV2SLS
import statsmodels.api as sm

# Prepare data
y = df['y_iv']
X_endog = df['x1_iv']
Z = df['z']
n = len(df)

# Manual 2SLS
X_exog = pd.DataFrame({'const': np.ones(n)})

# First stage
X1 = sm.add_constant(Z)
first_stage = sm.OLS(X_endog, X1).fit()
x1_hat = first_stage.fittedvalues

# Second stage with fitted values
X2 = pd.DataFrame({'const': np.ones(n), 'x1_iv': x1_hat})
second_stage = sm.OLS(y, X2).fit()

# Get 2SLS coefficients
beta = second_stage.params

# Compute HC1 robust standard errors for 2SLS
# Using actual x1_iv (not fitted) for residuals but fitted regressors for projection
X_actual = pd.DataFrame({'const': np.ones(n), 'x1_iv': X_endog.values})
X_proj = X2.values  # with fitted x1

# Residuals from 2SLS (using actual x1_iv)
resid = y.values - X_actual.values @ beta.values

# HC1 sandwich estimator
# V = (X'X_hat)^{-1} * X_hat' * diag(e^2) * n/(n-k) * X_hat * (X_hat'X_hat)^{-1}
# where X_hat uses fitted instruments
XtXhat = X_proj.T @ X_proj
XtXhat_inv = np.linalg.inv(XtXhat)

# HC1 meat
k = X_proj.shape[1]
scale = n / (n - k)
meat = X_proj.T @ np.diag(resid**2 * scale) @ X_proj

V = XtXhat_inv @ meat @ XtXhat_inv
se = np.sqrt(np.diag(V))

result = {
    "task_id": "iv2sls_robust",
    "platform": "python",
    "estimates": [
        {"term": "const", "estimate": float(beta['const']), "se": float(se[0]), "n_obs": int(n)},
        {"term": "x1_iv", "estimate": float(beta['x1_iv']), "se": float(se[1]), "n_obs": int(n)}
    ],
    "method_metadata": {"estimator": "2SLS", "vcov": "HC1"},
    "diagnostics": {}
}

with open('./result.json', 'w') as f:
    json.dump(result, f, indent=2)
