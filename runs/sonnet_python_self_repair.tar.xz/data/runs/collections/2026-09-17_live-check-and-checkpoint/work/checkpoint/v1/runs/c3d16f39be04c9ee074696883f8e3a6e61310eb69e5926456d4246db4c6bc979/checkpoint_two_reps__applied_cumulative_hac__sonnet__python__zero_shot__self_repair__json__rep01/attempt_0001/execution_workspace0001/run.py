import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

df = pd.read_csv('input.csv')
df = df.sort_values('date').reset_index(drop=True)

df['log_sales'] = np.log(df['sales'])
df['log_vix'] = np.log(df['vix'])
df['d_log_vix'] = df['log_vix'].diff()

for lag in range(1, 16):
    df[f'lag_{lag}'] = df['d_log_vix'].shift(lag)

df_reg = df.dropna(subset=['log_sales'] + [f'lag_{i}' for i in range(1, 16)]).copy()

X = sm.add_constant(df_reg[[f'lag_{i}' for i in range(1, 16)]])
y = df_reg['log_sales']

N = len(df_reg)
model = sm.OLS(y, X).fit()

# Newey-West with max lag 15, Bartlett weights 1-j/16, multiplied by N/(N-16)
nw_cov = model.cov_HC0  # placeholder, will replace

# Manual Newey-West
resid = model.resid.values
X_arr = X.values
k = X_arr.shape[1]
S = np.zeros((k, k))

# Meat of sandwich
Xe = X_arr * resid[:, None]
S += Xe.T @ Xe  # lag 0

for j in range(1, 16):
    w = 1 - j / 16.0
    XeT = Xe[j:]
    XeL = Xe[:-j]
    gamma = XeT.T @ XeL
    S += w * (gamma + gamma.T)

bread = np.linalg.inv(X_arr.T @ X_arr)
V_nw = bread @ S @ bread
V_nw = V_nw * N / (N - 16)

betas = model.params.values

# Indices for lag_1 through lag_15 (index 0 is const)
lag_indices = list(range(1, 16))

# cumulative response: sum of lag_1 ... lag_15
c = np.zeros(k)
for i in lag_indices:
    c[i] = 1.0

cum_resp = c @ betas
cum_se = np.sqrt(c @ V_nw @ c)

lag1_est = betas[1]
lag1_se = np.sqrt(V_nw[1, 1])

lag15_est = betas[15]
lag15_se = np.sqrt(V_nw[15, 15])

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {"term": "cumulative_response", "estimate": float(cum_resp), "se": float(cum_se), "n_obs": int(N)},
        {"term": "lag_1", "estimate": float(lag1_est), "se": float(lag1_se), "n_obs": int(N)},
        {"term": "lag_15", "estimate": float(lag15_est), "se": float(lag15_se), "n_obs": int(N)},
    ],
    "method_metadata": {
        "estimator": "OLS",
        "vcov": "Newey-West HAC, max_lag=15, Bartlett weights 1-j/16, scaled N/(N-16)"
    },
    "diagnostics": {}
}

with open('result.json', 'w') as f:
    json.dump(result, f, indent=2)
