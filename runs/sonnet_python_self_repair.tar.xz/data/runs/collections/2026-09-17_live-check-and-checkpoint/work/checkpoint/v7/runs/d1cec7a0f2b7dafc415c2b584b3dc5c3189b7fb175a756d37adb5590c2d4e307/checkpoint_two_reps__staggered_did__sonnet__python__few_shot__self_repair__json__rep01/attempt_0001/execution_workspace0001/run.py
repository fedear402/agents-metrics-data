import json
import pandas as pd

df = pd.read_csv("./input.csv")

cohorts = [4, 6, 8]
never = df[df["cohort"] == -1]

cell_atts = []
n_total = 0

for g in cohorts:
    treated_g = df[df["cohort"] == g]
    base_year = g - 1
    
    mean_treat_base = treated_g[treated_g["year"] == base_year]["y_did"].mean()
    mean_never_base = never[never["year"] == base_year]["y_did"].mean()
    
    post_years = [t for t in range(10) if t >= g]
    
    for t in post_years:
        mean_treat_t = treated_g[treated_g["year"] == t]["y_did"].mean()
        mean_never_t = never[never["year"] == t]["y_did"].mean()
        
        att_gt = (mean_treat_t - mean_treat_base) - (mean_never_t - mean_never_base)
        cell_atts.append(att_gt)
        n_total += len(treated_g[treated_g["year"] == t])

att_uniform = sum(cell_atts) / len(cell_atts)

out = {
    "task_id": "staggered_did",
    "platform": "python",
    "estimates": [
        {"term": "att", "estimate": float(att_uniform), "se": None, "n_obs": int(len(df))}
    ],
    "method_metadata": {
        "estimator": "ATT_uniform from cohort-year cell means, equal-weighted over post-treatment cells",
        "vcov": "none"
    },
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(out, f)
