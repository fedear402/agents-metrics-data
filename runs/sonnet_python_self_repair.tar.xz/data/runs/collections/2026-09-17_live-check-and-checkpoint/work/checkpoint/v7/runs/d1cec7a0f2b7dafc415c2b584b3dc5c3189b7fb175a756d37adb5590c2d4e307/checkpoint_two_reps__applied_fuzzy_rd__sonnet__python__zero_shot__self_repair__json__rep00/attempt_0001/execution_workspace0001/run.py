import pandas as pd
import numpy as np
import json
from statsmodels.regression.linear_model import OLS, WLS

df = pd.read_csv('input.csv')
df.columns = df.columns.str.strip()

bw = 1.0
mask = df['score'].abs() < bw
data = df[mask].copy()
n_obs = len(data)

data['w'] = 1 - data['score'].abs()
data['D'] = (data['score'] >= 0).astype(float)
data['score_left'] = data['score'] * (1 - data['D'])
data['score_right'] = data['score'] * data['D']

X = np.column_stack([
    np.ones(n_obs),
    data['D'].values,
    data['score_left'].values,
    data['score_right'].values
])
w = data['w'].values
Y_earn = data['earnings'].values
Y_part = data['participated'].values

def wls_hc0(X, y, w):
    W = np.diag(w)
    XtW = X.T @ W
    XtWX = XtW @ X
    XtWX_inv = np.linalg.inv(XtWX)
    beta = XtWX_inv @ XtW @ y
    resid = y - X @ beta
    # HC0 sandwich
    wr = w * resid
    meat = X.T @ np.diag(wr**2) @ X
    V = XtWX_inv @ meat @ XtWX_inv
    return beta, V

beta_earn, V_earn = wls_hc0(X, Y_earn, w)
beta_part, V_part = wls_hc0(X, Y_part, w)

# Discontinuities are the coefficient on D (index 1)
rf_est = beta_earn[1]
fs_est = beta_part[1]
rf_se = np.sqrt(V_earn[1, 1])
fs_se = np.sqrt(V_part[1, 1])

# For delta method on treatment_effect = rf / fs, need joint covariance
# Compute joint covariance of (rf, fs) via stacking
W_mat = np.diag(w)
XtW = X.T @ W_mat
XtWX_inv = np.linalg.inv(XtW @ X)

resid_earn = Y_earn - X @ beta_earn
resid_part = Y_part - X @ beta_part

# Joint sandwich
# theta = [beta_earn, beta_part], 8 params
# score for earn: w * resid_earn * X[i]
# score for part: w * resid_part * X[i]
p = X.shape[1]
scores_earn = (w * resid_earn)[:, None] * X  # n x p
scores_part = (w * resid_part)[:, None] * X  # n x p

scores = np.hstack([scores_earn, scores_part])  # n x 2p
meat_joint = scores.T @ scores  # 2p x 2p

bread = np.zeros((2*p, 2*p))
bread[:p, :p] = XtWX_inv
bread[p:, p:] = XtWX_inv

V_joint = bread @ meat_joint @ bread  # 2p x 2p

# rf is beta_earn[1], fs is beta_part[1]
# in joint vector: rf at index 1, fs at index p+1
cov_rf_fs = V_joint[1, p+1]

# Delta method: te = rf/fs
# d(te)/d(rf) = 1/fs, d(te)/d(fs) = -rf/fs^2
g_rf = 1.0 / fs_est
g_fs = -rf_est / (fs_est ** 2)
te_var = g_rf**2 * V_join = V_joint[1,1]

# Redo properly
var_rf = V_joint[1, 1]
var_fs = V_joint[p+1, p+1]
cov_rf_fs = V_joint[1, p+1]

te_est = rf_est / fs_est
te_var = g_rf**2 * var_rf + g_fs**2 * var_fs + 2 * g_rf * g_fs * cov_rf_fs
te_se = np.sqrt(te_var)

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": float(te_est), "se": float(te_se), "n_obs": int(n_obs)},
        {"term": "reduced_form", "estimate": float(rf_est), "se": float(rf_se), "n_obs": int(n_obs)},
        {"term": "first_stage", "estimate": float(fs_est), "se": float(fs_se), "n_obs": int(n_obs)},
    ],
    "method_metadata": {
        "estimator": "fuzzy_rd_local_linear_triangular",
        "vcov": "HC0"
    },
    "diagnostics": {}
}

with open('result.json', 'w') as f:
    json.dump(result, f, indent=2)
