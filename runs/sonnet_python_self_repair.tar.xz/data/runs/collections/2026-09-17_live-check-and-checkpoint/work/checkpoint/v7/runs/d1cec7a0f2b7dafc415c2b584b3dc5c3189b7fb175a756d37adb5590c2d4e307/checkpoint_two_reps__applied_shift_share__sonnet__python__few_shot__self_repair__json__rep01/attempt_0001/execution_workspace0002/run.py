import json
import numpy as np
import pandas as pd

df = pd.read_csv('input.csv')

# One obs per region for weights
regions = df.drop_duplicates('region_id')[['region_id', 'region_weight', 'x', 'y']].copy()
regions['e'] = regions['region_weight'] / regions['region_weight'].sum()

# Construct shift-share instrument per region
instrument = df.groupby('region_id').apply(lambda g: (g['share'] * g['shock']).sum()).reset_index()
instrument.columns = ['region_id', 'z']
regions = regions.merge(instrument, on='region_id')

e = regions['e'].values
x_r = regions['x'].values
y_r = regions['y'].values
z_r = regions['z'].values

# Weighted means
x_mean = e @ x_r
y_mean = e @ y_r
z_mean = e @ z_r

# Merge region-level info back to df (avoid column name conflicts)
region_info = regions[['region_id', 'e', 'z']].copy()
industry_df = df.merge(region_info, on='region_id')

industry_df['x0'] = industry_df['x'] - x_mean
industry_df['y0'] = industry_df['y'] - y_mean
industry_df['z0'] = industry_df['z'] - z_mean

# s_n and aggregated residuals per industry
def agg_industry(g):
    w = g['e'] * g['share']
    s = w.sum()
    return pd.Series({
        's_n': s,
        'ybar': (w * g['y0']).sum() / s,
        'xbar': (w * g['x0']).sum() / s,
        'zbar': (w * g['z0']).sum() / s,
        'shock': g['shock'].iloc[0]
    })

agg = industry_df.groupby('industry_id').apply(agg_industry).reset_index()

s_n = agg['s_n'].values
ybar = agg['ybar'].values
xbar = agg['xbar'].values
zbar = agg['zbar'].values
shock = agg['shock'].values
N = len(agg)

def shock_iv(dependent, endogenous):
    regressors = np.column_stack([np.ones(N), endogenous])
    instruments = np.column_stack([np.ones(N), shock])
    cross = instruments.T @ (s_n[:, None] * regressors)
    beta = np.linalg.solve(cross, instruments.T @ (s_n * dependent))
    residual = dependent - regressors @ beta
    scores = instruments * (s_n * residual)[:, None]
    inverse = np.linalg.inv(cross)
    hc1 = N / (N - 2)
    covariance = hc1 * inverse @ (scores.T @ scores) @ inverse.T
    return float(beta[1]), float(np.sqrt(covariance[1, 1]))

effect, effect_se = shock_iv(ybar, xbar)
first_stage, first_stage_se = shock_iv(xbar, zbar)

effective_shocks = float(1.0 / np.sum(s_n ** 2))

output = {
    'task_id': 'applied_shift_share',
    'platform': 'python',
    'estimates': [
        {'term': 'effect', 'estimate': effect, 'se': effect_se, 'n_obs': N},
        {'term': 'first_stage', 'estimate': first_stage, 'se': first_stage_se, 'n_obs': N},
        {'term': 'effective_shocks', 'estimate': effective_shocks, 'se': None, 'n_obs': N}
    ],
    'method_metadata': {'estimator': '2SLS_shift_share', 'vcov': 'HC1_shock_level'},
    'diagnostics': {}
}

with open('result.json', 'w') as f:
    json.dump(output, f, indent=2, allow_nan=False)
