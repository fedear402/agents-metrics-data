import json
import pandas as pd
from linearmodels.iv import IV2SLS

df = pd.read_csv("./input.csv")

df["const"] = 1.0

res = IV2SLS(df["y_iv"], df[["const"]], df[["x1_iv"]], df[["z"]]).fit(cov_type="unadjusted")

# Use HC1 robust via heteroskedastic covariance
res_hc1 = IV2SLS(df["y_iv"], df[["const"]], df[["x1_iv"]], df[["z"]]).fit(cov_type="robust")

n_obs = int(len(df))

out = {
    "task_id": "iv2sls_robust",
    "platform": "python",
    "estimates": [
        {"term": "const", "estimate": float(res_hc1.params["const"]), "se": float(res_hc1.std_errors["const"]), "n_obs": n_obs},
        {"term": "x1_iv", "estimate": float(res_hc1.params["x1_iv"]), "se": float(res_hc1.std_errors["x1_iv"]), "n_obs": n_obs},
    ],
    "method_metadata": {"estimator": "2SLS via linearmodels IV2SLS", "vcov": "HC1 robust"},
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(out, f, indent=2)
