import json
import pandas as pd

df = pd.read_csv("./input.csv")

cohorts = [4, 6, 8]
never = df[df["cohort"] == -1]

att_cells = []

for g in cohorts:
    treated_g = df[df["cohort"] == g]
    base_year = g - 1
    
    mean_never_base = never[never["year"] == base_year]["y_did"].mean()
    mean_treated_base = treated_g[treated_g["year"] == base_year]["y_did"].mean()
    
    post_years = [t for t in range(10) if t >= g]
    
    for t in post_years:
        mean_treated_t = treated_g[treated_g["year"] == t]["y_did"].mean()
        mean_never_t = never[never["year"] == t]["y_did"].mean()
        
        cell_att = (mean_treated_t - mean_treated_base) - (mean_never_t - mean_never_base)
        att_cells.append(cell_att)

att_uniform = sum(att_cells) / len(att_cells)

n_obs = int(len(df))

out = {
    "task_id": "staggered_did",
    "platform": "python",
    "estimates": [
        {"term": "att", "estimate": float(att_uniform), "se": None, "n_obs": n_obs}
    ],
    "method_metadata": {
        "estimator": "ATT_uniform from group-year means, equal-weight over cohort-time cells",
        "vcov": "none"
    },
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(out, f)
