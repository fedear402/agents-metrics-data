import pandas as pd
import numpy as np
import json

df = pd.read_csv('input.csv')
df.columns = df.columns.str.strip()

bw = 1.0
mask = df['score'].abs() < bw
data = df[mask].copy()
n_obs = len(data)

data['w'] = 1 - data['score'].abs()
data['D'] = (data['score'] >= 0).astype(float)
data['score_left'] = data['score'] * (1 - data['D'])
data['score_right'] = data['score'] * data['D']

X = np.column_stack([
    np.ones(n_obs),
    data['D'].values,
    data['score_left'].values,
    data['score_right'].values
])
w = data['w'].values
Y_earn = data['earnings'].values
Y_part = data['participated'].values

W_mat = np.diag(w)
XtW = X.T @ W_mat
XtWX_inv = np.linalg.inv(XtW @ X)

beta_earn = XtWX_inv @ XtW @ Y_earn
beta_part = XtWX_inv @ XtW @ Y_part

resid_earn = Y_earn - X @ beta_earn
resid_part = Y_part - X @ beta_part

p = X.shape[1]
scores_earn = (w * resid_earn)[:, None] * X
scores_part = (w * resid_part)[:, None] * X

scores = np.hstack([scores_earn, scores_part])
meat_joint = scores.T @ scores

bread = np.zeros((2*p, 2*p))
bread[:p, :p] = XtWX_inv
bread[p:, p:] = XtWX_inv

V_joint = bread @ meat_joint @ bread

rf_est = beta_earn[1]
fs_est = beta_part[1]
rf_se = np.sqrt(V_joint[1, 1])
fs_se = np.sqrt(V_joint[p+1, p+1])

var_rf = V_joint[1, 1]
var_fs = V_joint[p+1, p+1]
cov_rf_fs = V_joint[1, p+1]

te_est = rf_est / fs_est
g_rf = 1.0 / fs_est
g_fs = -rf_est / (fs_est ** 2)
te_var = g_rf**2 * var_rf + g_fs**2 * var_fs + 2 * g_rf * g_fs * cov_rf_fs
te_se = np.sqrt(te_var)

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": float(te_est), "se": float(te_se), "n_obs": int(n_obs)},
        {"term": "reduced_form", "estimate": float(rf_est), "se": float(rf_se), "n_obs": int(n_obs)},
        {"term": "first_stage", "estimate": float(fs_est), "se": float(fs_se), "n_obs": int(n_obs)},
    ],
    "method_metadata": {
        "estimator": "fuzzy_rd_local_linear_triangular",
        "vcov": "HC0"
    },
    "diagnostics": {}
}

with open('result.json', 'w') as f:
    json.dump(result, f, indent=2)
