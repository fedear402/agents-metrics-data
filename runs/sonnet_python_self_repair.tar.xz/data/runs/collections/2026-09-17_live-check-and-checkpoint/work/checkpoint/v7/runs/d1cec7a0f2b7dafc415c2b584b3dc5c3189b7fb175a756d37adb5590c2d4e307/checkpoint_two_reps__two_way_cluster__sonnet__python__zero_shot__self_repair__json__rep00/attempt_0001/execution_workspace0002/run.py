import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

df = pd.read_csv('./input.csv')

y = df['y_twocluster'].values
X = sm.add_constant(df['x'].values)

model = sm.OLS(y, X).fit()

n = len(df)
k = X.shape[1]
e = model.resid.values

firms = df['firm'].values
years = df['year'].values

def meat_cluster(X_arr, e, groups):
    unique_g = np.unique(groups)
    meat = np.zeros((k, k))
    for g in unique_g:
        idx = groups == g
        Xe = X_arr[idx] * e[idx, np.newaxis]
        s = Xe.sum(axis=0)
        meat += np.outer(s, s)
    return meat

XtXinv = np.linalg.inv(X.T @ X)

B_firm = meat_cluster(X, e, firms)
B_year = meat_cluster(X, e, years)

firm_year = firms.astype(str) + '_' + years.astype(str)
B_fy = meat_cluster(X, e, firm_year)

meat_cgm = B_firm + B_year - B_fy

V = XtXinv @ meat_cgm @ XtXinv

se = np.sqrt(np.diag(V))

result = {
    "task_id": "two_way_cluster",
    "platform": "python",
    "estimates": [
        {"term": "const", "estimate": float(model.params[0]), "se": float(se[0]), "n_obs": n},
        {"term": "x", "estimate": float(model.params[1]), "se": float(se[1]), "n_obs": n}
    ],
    "method_metadata": {
        "estimator": "OLS",
        "vcov": "two-way cluster-robust (Cameron-Gelbach-Miller), clustered on firm and year"
    },
    "diagnostics": {}
}

with open('./result.json', 'w') as f:
    json.dump(result, f, indent=2)
