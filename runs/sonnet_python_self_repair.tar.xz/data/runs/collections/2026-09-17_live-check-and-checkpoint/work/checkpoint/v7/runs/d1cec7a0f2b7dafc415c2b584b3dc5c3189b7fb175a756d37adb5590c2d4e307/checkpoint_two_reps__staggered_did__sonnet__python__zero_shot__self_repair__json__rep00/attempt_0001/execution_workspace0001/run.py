import pandas as pd
import json

df = pd.read_csv('./input.csv')

cohorts = [4, 6, 8]
never = df[df['cohort'] == -1]

att_sum = 0.0
count = 0
n_obs = 0

for g in cohorts:
    treated = df[df['cohort'] == g]
    baseline_t = g - 1
    
    mean_treated_base = treated[treated['year'] == baseline_t]['y_did'].mean()
    mean_never_base = never[never['year'] == baseline_t]['y_did'].mean()
    
    post_years = df[df['year'] >= g]['year'].unique()
    
    for t in sorted(post_years):
        mean_treated_t = treated[treated['year'] == t]['y_did'].mean()
        mean_never_t = never[never['year'] == t]['y_did'].mean()
        
        cell_att = (mean_treated_t - mean_treated_base) - (mean_never_t - mean_never_base)
        att_sum += cell_att
        count += 1
        n_obs += len(treated[treated['year'] == t]) + len(never[never['year'] == t])

att_uniform = att_sum / count

result = {
    "task_id": "staggered_did",
    "platform": "python",
    "estimates": [
        {"term": "att", "estimate": float(att_uniform), "se": None, "n_obs": int(n_obs)}
    ],
    "method_metadata": {
        "estimator": "Callaway-SantAnna group-time ATT uniform aggregation",
        "vcov": "null"
    },
    "diagnostics": {}
}

with open('./result.json', 'w') as f:
    json.dump(result, f, indent=2)
