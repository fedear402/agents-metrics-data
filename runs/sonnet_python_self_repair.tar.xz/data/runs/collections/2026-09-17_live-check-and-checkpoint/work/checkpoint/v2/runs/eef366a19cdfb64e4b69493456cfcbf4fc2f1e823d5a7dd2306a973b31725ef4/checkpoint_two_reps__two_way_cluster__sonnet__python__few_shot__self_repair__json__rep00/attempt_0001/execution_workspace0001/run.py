import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("./input.csv")

X = sm.add_constant(df[["x"]])
y = df["y_twocluster"]

fit = sm.OLS(y, X).fit()

# Cameron-Gelbach-Miller two-way cluster robust variance
# V_twoway = V_firm + V_year - V_firm_year

def cluster_vcov(fit, cluster_var):
    X = fit.model.exog
    e = fit.resid.values
    n, k = X.shape
    XtXinv = np.linalg.inv(X.T @ X)
    groups = cluster_var.values
    unique_groups = np.unique(groups)
    B = np.zeros((k, k))
    for g in unique_groups:
        idx = groups == g
        Xg = X[idx]
        eg = e[idx]
        score = Xg.T @ eg
        B += np.outer(score, score)
    return XtXinv @ B @ XtXinv

firm_vcov = cluster_vcov(fit, df["firm"])
year_vcov = cluster_vcov(fit, df["year"])

# Intersection clusters (each firm-year is unique, so this reduces to standard OLS vcov)
# But CGM formula: V = V_1 + V_2 - V_12
# V_12 clusters on firm-year intersections
firm_year = df["firm"].astype(str) + "_" + df["year"].astype(str)
firm_year_vcov = cluster_vcov(fit, firm_year)

cgm_vcov = firm_vcov + year_vcov - firm_year_vcov

se = np.sqrt(np.diag(cgm_vcov))

n_obs = int(fit.nobs)

out = {
    "task_id": "two_way_cluster",
    "platform": "python",
    "estimates": [
        {"term": "const", "estimate": float(fit.params["const"]), "se": float(se[0]), "n_obs": n_obs},
        {"term": "x", "estimate": float(fit.params["x"]), "se": float(se[1]), "n_obs": n_obs},
    ],
    "method_metadata": {"estimator": "OLS", "vcov": "two_way_cluster_CGM"},
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(out, f)
