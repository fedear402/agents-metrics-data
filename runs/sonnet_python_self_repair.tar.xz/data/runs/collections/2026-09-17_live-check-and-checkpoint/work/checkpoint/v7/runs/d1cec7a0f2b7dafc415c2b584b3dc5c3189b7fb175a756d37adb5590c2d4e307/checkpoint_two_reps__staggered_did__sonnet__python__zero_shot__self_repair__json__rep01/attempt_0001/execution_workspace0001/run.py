import pandas as pd
import json

df = pd.read_csv("./input.csv")

cohorts = [4, 6, 8]
never = df[df["cohort"] == -1]

att_cells = []
n_obs_total = 0

for g in cohorts:
    treated = df[df["cohort"] == g]
    post_years = [t for t in range(10) if t >= g]
    
    for t in post_years:
        mean_treat_t = treated[treated["year"] == t]["y_did"].mean()
        mean_treat_base = treated[treated["year"] == g - 1]["y_did"].mean()
        mean_never_t = never[never["year"] == t]["y_did"].mean()
        mean_never_base = never[never["year"] == g - 1]["y_did"].mean()
        
        att_gt = (mean_treat_t - mean_treat_base) - (mean_never_t - mean_never_base)
        att_cells.append(att_gt)
        n_obs_total += len(treated[treated["year"] == t]) + len(never[never["year"] == t])

att_uniform = sum(att_cells) / len(att_cells)

result = {
    "task_id": "staggered_did",
    "platform": "python",
    "estimates": [
        {"term": "att", "estimate": float(att_uniform), "se": None, "n_obs": int(n_obs_total)}
    ],
    "method_metadata": {
        "estimator": "Callaway-SantAnna-style ATT_uniform (equal-weight cohort-time cells)",
        "vcov": "none"
    },
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
