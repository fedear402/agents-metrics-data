import pandas as pd
import statsmodels.api as sm
import json

df = pd.read_csv('./input.csv')
X = sm.add_constant(df[['x1', 'x2']])
model = sm.OLS(df['y_lin'], X).fit(cov_type='HC1')

n = int(model.nobs)
params = model.params
bse = model.bse

result = {
    "task_id": "ols_robust",
    "platform": "python",
    "estimates": [
        {"term": "const", "estimate": float(params['const']), "se": float(bse['const']), "n_obs": n},
        {"term": "x1", "estimate": float(params['x1']), "se": float(bse['x1']), "n_obs": n},
        {"term": "x2", "estimate": float(params['x2']), "se": float(bse['x2']), "n_obs": n},
    ],
    "method_metadata": {"estimator": "OLS", "vcov": "HC1"},
    "diagnostics": {}
}

with open('./result.json', 'w') as f:
    json.dump(result, f, indent=2)
