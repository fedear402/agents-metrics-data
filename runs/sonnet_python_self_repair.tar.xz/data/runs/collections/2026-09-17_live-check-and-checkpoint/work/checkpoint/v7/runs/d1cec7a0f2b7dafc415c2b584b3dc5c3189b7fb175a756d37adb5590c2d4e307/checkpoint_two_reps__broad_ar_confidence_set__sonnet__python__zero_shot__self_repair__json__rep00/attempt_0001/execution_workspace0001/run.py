import pandas as pd
import numpy as np
from scipy import stats
import json

df = pd.read_csv('./input.csv')
n = len(df)
y = df['y'].values
endog = df['endog'].values
x = df['x'].values
z1 = df['z1'].values
z2 = df['z2'].values

# Critical value: 95th percentile of F(2, n-4)
f_crit = stats.f.ppf(0.95, 2, n - 4)

def ar_f_stat(beta):
    y_adj = y - beta * endog
    X = np.column_stack([np.ones(n), x, z1, z2])
    # OLS
    XtX = X.T @ X
    Xty = X.T @ y_adj
    coef = np.linalg.solve(XtX, Xty)
    resid = y_adj - X @ coef
    s2 = (resid @ resid) / (n - 4)
    
    # Test H0: coef[2]=0, coef[3]=0 (z1 and z2 coefficients)
    R = np.array([[0, 0, 1, 0],
                  [0, 0, 0, 1]])
    Rb = R @ coef
    RXtXiRt = R @ np.linalg.solve(XtX, R.T)
    F = (Rb @ np.linalg.solve(RXtXiRt, Rb)) / (2 * s2)
    return F

# The AR confidence set is the set of beta where F(beta) <= f_crit
# F(beta) is a rational function of beta (quadratic/quadratic)
# Find the roots of F(beta) = f_crit analytically

# y_adj = y - beta*endog
# We need to find when F(beta) = f_crit
# This is a quadratic equation in beta

# Let's derive analytically
# M = I - X_restricted * (X_restricted'X_restricted)^{-1} * X_restricted'
# where X_restricted = [1, x]
# Let Z_tilde = M * [z1, z2] (residuals of z1, z2 on intercept and x)
# Let y_tilde = M * y, e_tilde = M * endog

X_r = np.column_stack([np.ones(n), x])
XrXr = X_r.T @ X_r
Pr = X_r @ np.linalg.solve(XrXr, X_r.T)
Mr = np.eye(n) - Pr

y_tilde = Mr @ y
e_tilde = Mr @ endog
z1_tilde = Mr @ z1
z2_tilde = Mr @ z2

Zt = np.column_stack([z1_tilde, z2_tilde])

# y_adj_tilde = y_tilde - beta * e_tilde
# The F stat for testing z1,z2 coefs in full regression equals:
# (y_adj_tilde' Pz y_adj_tilde / 2) / (y_adj_tilde' Mz y_adj_tilde / (n-4))
# where Pz = Zt(Zt'Zt)^{-1}Zt', Mz = I - Pz

ZtZ = Zt.T @ Zt
Pz = Zt @ np.linalg.solve(ZtZ, Zt.T)
Mz_mat = np.eye(n) - Pz

# Define a = y_tilde, b = e_tilde
a = y_tilde
b = e_tilde

# v(beta) = a - beta*b
# F(beta) = [v'Pz v / 2] / [v'Mz v / (n-4)]
# F = f_crit when:
# (n-4) * v'Pz v = 2 * f_crit * v'Mz v
# (n-4) * v'Pz v - 2*f_crit * v'Mz v = 0
# v'[(n-4)*Pz - 2*f_crit*Mz]v = 0

# v = a - beta*b
# v'Av = a'Aa - 2*beta*a'Ab + beta^2 * b'Ab = 0

A = (n - 4) * Pz - 2 * f_crit * Mz_mat

c2 = b @ A @ b
c1 = -2 * (a @ A @ b)
c0 = a @ A @ a

discriminant = c1**2 - 4*c2*c0

# Compute F at beta=1
ar_f_1 = ar_f_stat(1.0)

if discriminant < 0:
    # No real roots - either all betas accepted or none
    # Check at beta=0
    f0 = ar_f_stat(0.0)
    if f0 <= f_crit:
        # All betas accepted - unbounded with no finite boundaries
        # This case shouldn't produce two finite boundary points per problem statement
        boundary_low = np.nan
        boundary_high = np.nan
        accepts_zero = 1.0
        unbounded = 1.0
    else:
        # No betas accepted
        boundary_low = np.nan
        boundary_high = np.nan
        accepts_zero = 0.0
        unbounded = 0.0
else:
    r1 = (-c1 - np.sqrt(discriminant)) / (2 * c2)
    r2 = (-c1 + np.sqrt(discriminant)) / (2 * c2)
    
    boundary_low = min(r1, r2)
    boundary_high = max(r1, r2)
    
    # Determine structure: inside or outside parabola
    # Test a point between roots
    beta_mid = (boundary_low + boundary_high) / 2
    f_mid = ar_f_stat(beta_mid)
    
    if f_mid <= f_crit:
        # Interval [boundary_low, boundary_high] is the confidence set
        unbounded = 0.0
    else:
        # Outside: (-inf, boundary_low) U (boundary_high, +inf)
        unbounded = 1.0
    
    f0 = ar_f_stat(0.0)
    accepts_zero = 1.0 if f0 <= f_crit else 0.0

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": [
        {"term": "boundary_low", "estimate": float(boundary_low), "se": None, "n_obs": n},
        {"term": "boundary_high", "estimate": float(boundary_high), "se": None, "n_obs": n},
        {"term": "accepts_zero", "estimate": float(accepts_zero), "se": None, "n_obs": n},
        {"term": "unbounded", "estimate": float(unbounded), "se": None, "n_obs": n},
        {"term": "ar_f_at_one", "estimate": float(ar_f_1), "se": None, "n_obs": n}
    ],
    "method_metadata": {
        "estimator": "Anderson-Rubin confidence set inversion",
        "vcov": "homoskedastic"
    },
    "diagnostics": {}
}

with open('result.json', 'w') as f:
    json.dump(result, f, indent=2)

print("Done. boundary_low:", boundary_low, "boundary_high:", boundary_high)
print("accepts_zero:", accepts_zero, "unbounded:", unbounded)
print("ar_f_at_one:", ar_f_1)
