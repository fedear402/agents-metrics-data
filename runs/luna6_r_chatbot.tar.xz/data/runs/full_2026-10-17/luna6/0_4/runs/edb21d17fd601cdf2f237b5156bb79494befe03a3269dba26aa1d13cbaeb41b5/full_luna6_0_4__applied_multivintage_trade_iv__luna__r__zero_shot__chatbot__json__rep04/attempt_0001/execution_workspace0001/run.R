library(jsonlite)

crosswalk <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
trade <- read.csv("trade.csv", stringsAsFactors = FALSE)
areas <- read.csv("areas.csv", stringsAsFactors = FALSE)
employment <- read.csv("employment.csv", stringsAsFactors = FALSE)
outcomes <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

trade <- merge(trade, crosswalk, by = "code", all.x = TRUE, sort = FALSE)

if (anyNA(trade$industry)) {
  stop("Every trade code must map to an industry.")
}

periods <- unique(areas$period)
industries <- unique(crosswalk$industry)

build_exposure <- function(area_data, employment_data, trade_data, vintage,
                           trade_change, output_name) {
  a <- area_data[area_data$vintage == vintage, , drop = FALSE]
  e <- employment_data[employment_data$vintage == vintage, , drop = FALSE]

  national <- aggregate(
    employment ~ period + industry,
    data = e,
    FUN = sum
  )
  names(national)[names(national) == "employment"] <- "national_employment"

  grid <- merge(
    a[, c("area", "period", "total_employment")],
    data.frame(industry = industries, stringsAsFactors = FALSE),
    by = NULL
  )
  grid <- merge(
    grid,
    e[, c("area", "period", "industry", "employment")],
    by = c("area", "period", "industry"),
    all.x = TRUE,
    sort = FALSE
  )
  grid$employment[is.na(grid$employment)] <- 0

  grid <- merge(
    grid,
    national,
    by = c("period", "industry"),
    all.x = TRUE,
    sort = FALSE
  )
  grid <- merge(
    grid,
    trade_data[, c("period", "industry", trade_change, "price_index", "years")],
    by = c("period", "industry"),
    all.x = TRUE,
    sort = FALSE
  )

  if (anyNA(grid$national_employment) || any(grid$national_employment <= 0) ||
      anyNA(grid[[trade_change]]) || anyNA(grid$price_index) ||
      anyNA(grid$years)) {
    stop("Required exposure inputs are missing or invalid.")
  }

  grid$contribution <- (
    (grid$employment / grid$total_employment) *
      (grid[[trade_change]] / grid$national_employment) /
      (grid$price_index / 100) / 1000 * (10 / grid$years)
  )

  result <- aggregate(
    contribution ~ area + period,
    data = grid,
    FUN = sum
  )
  names(result)[names(result) == "contribution"] <- output_name
  result
}

x <- build_exposure(
  areas, employment, trade, "base", "us_change", "x"
)
z <- build_exposure(
  areas, employment, trade, "early", "other_change", "z"
)

base_areas <- areas[areas$vintage == "base", , drop = FALSE]
base_areas <- base_areas[, c("area", "period", "population")]

analysis <- merge(outcomes, base_areas, by = c("area", "period"), all = FALSE)
analysis <- merge(analysis, x, by = c("area", "period"), all = FALSE)
analysis <- merge(analysis, z, by = c("area", "period"), all = FALSE)
analysis$period_numeric <- as.numeric(as.character(analysis$period))

if (nrow(analysis) != 72L) {
  stop("The estimation data must contain exactly 72 area-period rows.")
}
if (anyNA(analysis[, c("control", "change_pp", "population", "x", "z")]) ||
    any(analysis$population <= 0)) {
  stop("Regression inputs must be complete and weights must be positive.")
}

regressors <- cbind(
  intercept = 1,
  period = analysis$period_numeric,
  control = analysis$control,
  x = analysis$x
)
instruments <- cbind(
  intercept = 1,
  period = analysis$period_numeric,
  control = analysis$control,
  z = analysis$z
)
weights <- analysis$population

sqrt_weights <- sqrt(weights)
weighted_instruments <- instruments * sqrt_weights
weighted_regressors <- regressors * sqrt_weights
weighted_outcome <- analysis$change_pp * sqrt_weights

first_stage_projection <- qr.solve(
  crossprod(weighted_instruments),
  crossprod(weighted_instruments, weighted_regressors)
)
projected_regressors <- weighted_instruments %*% first_stage_projection

iv_coefficients <- qr.solve(
  crossprod(projected_regressors, weighted_regressors),
  crossprod(projected_regressors, weighted_outcome)
)

names(iv_coefficients) <- colnames(regressors)
iv_slope <- unname(iv_coefficients["x"])

area0 <- min(analysis$area)
period_values <- sort(unique(analysis$period))
area0_period0 <- x[x$area == area0 & x$period == period_values[1], "x"]
area0_period1 <- x[x$area == area0 & x$period == period_values[2], "x"]
area0_instrument_period0 <- z[z$area == area0 & z$period == period_values[1], "z"]

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = list(
    list(term = "iv_slope", estimate = unname(iv_slope), se = NULL),
    list(term = "exposure_area0_period0", estimate = unname(area0_period0), se = NULL),
    list(term = "exposure_area0_period1", estimate = unname(area0_period1), se = NULL),
    list(term = "instrument_area0_period0", estimate = unname(area0_instrument_period0), se = NULL)
  ),
  method_metadata = list(
    estimator = "weighted_2sls",
    outcome = "change_pp",
    endogenous_regressor = "x",
    excluded_instrument = "z",
    included_exogenous = c("intercept", "period", "control"),
    weight = "base-vintage population",
    exposure_units = "thousands of real dollars per worker per decade",
    interval_annualization = "10 / years"
  ),
  diagnostics = list(
    n_obs = 72L
  )
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  digits = 16,
  null = "null",
  pretty = TRUE
)
