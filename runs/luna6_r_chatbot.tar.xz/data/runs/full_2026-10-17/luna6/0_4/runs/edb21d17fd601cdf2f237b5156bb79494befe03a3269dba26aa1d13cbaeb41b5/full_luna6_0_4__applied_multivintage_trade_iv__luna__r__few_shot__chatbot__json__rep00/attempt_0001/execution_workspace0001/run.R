library(jsonlite)

crosswalk <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
trade <- read.csv("trade.csv", stringsAsFactors = FALSE)
areas <- read.csv("areas.csv", stringsAsFactors = FALSE)
employment <- read.csv("employment.csv", stringsAsFactors = FALSE)
outcomes <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

trade <- merge(trade, crosswalk, by = "code", sort = FALSE)

make_exposure <- function(vintage, change_column) {
  area_rows <- areas[areas$vintage == vintage, ]
  emp_rows <- employment[employment$vintage == vintage, ]

  national <- aggregate(
    employment ~ period + industry,
    data = merge(emp_rows, crosswalk, by = "industry", all.x = TRUE),
    FUN = sum
  )

  rows <- merge(area_rows, trade, by = "period", all = FALSE)
  rows <- merge(rows, crosswalk, by = "code", all.x = TRUE)
  rows <- merge(rows, emp_rows, by = c("area", "period", "industry"),
                all.x = TRUE)
  rows$employment[is.na(rows$employment)] <- 0
  rows <- merge(rows, national, by = c("period", "industry"),
                suffixes = c("", "_national"), all.x = TRUE)

  rows$component <- (rows$employment / rows$total_employment) *
    (rows[[change_column]] / rows$employment_national) /
    (rows$price_index / 100) / 1000 * (10 / rows$years)

  aggregate(component ~ area + period, data = rows, FUN = sum)
}

x <- make_exposure("base", "us_change")
z <- make_exposure("early", "other_change")

base_areas <- areas[areas$vintage == "base",
                    c("area", "period", "population")]
dat <- merge(outcomes, base_areas, by = c("area", "period"))
dat <- merge(dat, x, by = c("area", "period"))
dat <- merge(dat, z, by = c("area", "period"))
names(dat)[names(dat) == "component"] <- "x"
names(dat)[names(dat) == "component.1"] <- "z"
if (!"x" %in% names(dat)) names(dat)[names(dat) == "component"] <- "x"
if (!"z" %in% names(dat)) names(dat)[names(dat) == "component"] <- "z"

dat$period_factor <- factor(dat$period)
W <- sqrt(dat$population)
C <- model.matrix(~ period_factor + control, data = dat)
X <- cbind(C, x = dat$x)
Z <- cbind(C, z = dat$z)

Xw <- X * W
Zw <- Z * W
yw <- dat$change_pp * W
PZX <- qr.fitted(qr(Zw), Xw)
PZy <- qr.fitted(qr(Zw), yw)
beta <- solve(crossprod(Xw, PZX), crossprod(Xw, PZy))
iv_slope <- as.numeric(beta[ncol(beta)])

area0_period0 <- x$x[x$area == 0 & x$period == 0]
area0_period1 <- x$x[x$area == 0 & x$period == 1]
instrument_area0_period0 <- z$component[
  z$area == 0 & z$period == 0
]

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = list(
    list(term = "iv_slope", estimate = iv_slope, se = NULL, n_obs = 72L),
    list(term = "exposure_area0_period0",
         estimate = as.numeric(area0_period0), se = NULL, n_obs = 72L),
    list(term = "exposure_area0_period1",
         estimate = as.numeric(area0_period1), se = NULL, n_obs = 72L),
    list(term = "instrument_area0_period0",
         estimate = as.numeric(instrument_area0_period0), se = NULL,
         n_obs = 72L)
  ),
  method_metadata = list(
    estimator = "weighted_two_stage_least_squares",
    outcome = "change_pp",
    endogenous_regressor = "x",
    excluded_instrument = "z",
    exogenous_regressors = c("intercept", "period", "control"),
    weight = "base-vintage population",
    exposure_units = "thousands of real dollars per worker per decade"
  ),
  diagnostics = list(n_obs = 72L)
)

write_json(result, "result.json", auto_unbox = TRUE, digits = 12,
           null = "null", pretty = TRUE)
