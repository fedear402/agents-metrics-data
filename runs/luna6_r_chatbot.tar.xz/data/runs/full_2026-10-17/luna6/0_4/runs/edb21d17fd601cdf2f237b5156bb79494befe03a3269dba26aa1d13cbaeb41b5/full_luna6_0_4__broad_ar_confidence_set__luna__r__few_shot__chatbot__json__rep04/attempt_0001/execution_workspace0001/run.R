d <- read.csv("input.csv")
n <- nrow(d)
q <- 2L
df <- n - 4L
critical <- qf(0.95, q, df)
k <- q * critical / df

# Residualize on the included regressors: intercept and x.
X <- model.matrix(~ x, data = d)
resid_on_X <- function(v) qr.resid(qr(X), v)

ry <- resid_on_X(d$y)
rd <- resid_on_X(d$endog)
Z <- cbind(d$z1, d$z2)
Zr <- qr.resid(qr(X), Z)

# The restricted-minus-scaled-unrestricted SSR inequality is
# A*beta^2 + B*beta + C <= 0.
fit_ssr <- function(v) {
  r <- resid_on_X(v)
  u <- qr.resid(qr(cbind(X, Z)), v)
  c(restricted = sum(r^2), unrestricted = sum(u^2))
}
sy <- fit_ssr(d$y)
sd <- fit_ssr(d$endog)
cross_r <- sum(ry * rd)
cross_u <- sum(qr.resid(qr(cbind(X, Z)), d$y) *
               qr.resid(qr(cbind(X, Z)), d$endog))

A <- sd["restricted"] - (1 + k) * sd["unrestricted"]
B <- -2 * (cross_r - (1 + k) * cross_u)
C <- sy["restricted"] - (1 + k) * sy["unrestricted"]

roots <- sort(Re(polyroot(c(C, B, A))))
stopifnot(length(roots) == 2L, all(is.finite(roots)))

accepts <- function(beta) A * beta^2 + B * beta + C <= 0

ar_f <- function(beta) {
  v <- d$y - beta * d$endog
  s <- fit_ssr(v)
  ((s["restricted"] - s["unrestricted"]) / q) /
    (s["unrestricted"] / df)
}

rows <- list(
  list(term = "boundary_low", estimate = unname(roots[1]), se = NULL, n_obs = n),
  list(term = "boundary_high", estimate = unname(roots[2]), se = NULL, n_obs = n),
  list(term = "accepts_zero", estimate = as.integer(accepts(0)), se = NULL, n_obs = n),
  list(term = "unbounded", estimate = as.integer(A < 0), se = NULL, n_obs = n),
  list(term = "ar_f_at_one", estimate = unname(ar_f(1)), se = NULL, n_obs = n)
)

jsonlite::write_json(
  list(
    task_id = "broad_ar_confidence_set",
    platform = "r",
    estimates = rows,
    method_metadata = list(
      estimator = "Anderson-Rubin inversion using the homoskedastic joint F test of z1 and z2",
      vcov = "Conventional homoskedastic"
    ),
    diagnostics = list()
  ),
  "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE
)
