library(jsonlite)

crosswalk <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
trade <- read.csv("trade.csv", stringsAsFactors = FALSE)
areas <- read.csv("areas.csv", stringsAsFactors = FALSE)
employment <- read.csv("employment.csv", stringsAsFactors = FALSE)
outcomes <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

trade <- merge(trade, crosswalk, by = "code", all.x = TRUE, sort = FALSE)

make_exposures <- function(vintage, change_column) {
  area_data <- areas[areas$vintage == vintage, ]
  area_data <- merge(
    area_data,
    outcomes,
    by = c("area", "period"),
    all = FALSE,
    sort = FALSE
  )

  emp <- employment[employment$vintage == vintage, ]
  emp <- merge(
    emp,
    crosswalk,
    by = "industry",
    all.x = TRUE,
    sort = FALSE
  )

  national <- aggregate(
    employment ~ period + industry,
    data = emp,
    FUN = sum
  )
  names(national)[names(national) == "employment"] <- "national_employment"

  emp <- merge(
    emp,
    national,
    by = c("period", "industry"),
    all.x = TRUE,
    sort = FALSE
  )
  emp <- merge(
    emp,
    area_data[, c("area", "period", "total_employment")],
    by = c("area", "period"),
    all.x = TRUE,
    sort = FALSE
  )
  emp <- merge(
    emp,
    trade[, c("period", "industry", change_column, "price_index", "years")],
    by = c("period", "industry"),
    all.x = TRUE,
    sort = FALSE
  )

  emp$component <- (emp$employment / emp$total_employment) *
    (emp[[change_column]] / emp$national_employment) /
    (emp$price_index / 100) / 1000 * (10 / emp$years)

  exposure <- aggregate(
    component ~ area + period,
    data = emp,
    FUN = sum
  )
  names(exposure)[names(exposure) == "component"] <- "exposure"
  exposure
}

x <- make_exposures("base", "us_change")
z <- make_exposures("early", "other_change")

regression_data <- merge(
  areas[areas$vintage == "base", c("area", "period", "population")],
  outcomes,
  by = c("area", "period"),
  all = FALSE,
  sort = FALSE
)
regression_data <- merge(
  regression_data,
  x,
  by = c("area", "period"),
  all = FALSE,
  sort = FALSE
)
names(regression_data)[names(regression_data) == "exposure"] <- "x"
regression_data <- merge(
  regression_data,
  z,
  by = c("area", "period"),
  all = FALSE,
  sort = FALSE
)
names(regression_data)[names(regression_data) == "exposure"] <- "z"

regression_data$period_indicator <- as.numeric(regression_data$period == 1)

fit <- lm(
  change_pp ~ period_indicator + control + x,
  data = regression_data,
  weights = population
)
instrument_fit <- lm(
  x ~ period_indicator + control + z,
  data = regression_data,
  weights = population
)
fitted_x <- fitted(instrument_fit)

weighted_projection <- function(response, regressors, weights) {
  root_w <- sqrt(weights)
  qr.solve(regressors * root_w, response * root_w)
}

y_matrix <- model.matrix(
  ~ period_indicator + control + change_pp,
  data = regression_data
)
x_matrix <- model.matrix(
  ~ period_indicator + control + x,
  data = regression_data
)
instrument_matrix <- model.matrix(
  ~ period_indicator + control + z,
  data = regression_data
)
first_stage <- weighted_projection(
  regression_data$x,
  instrument_matrix,
  regression_data$population
)
x_hat <- cbind(
  x_matrix[, 1:3, drop = FALSE],
  as.vector(instrument_matrix %*% first_stage)
)
iv_coefficients <- weighted_projection(
  regression_data$change_pp,
  x_hat,
  regression_data$population
)

area0_period0 <- x[
  x$area == 0 & x$period == 0,
  "exposure"
]
area0_period1 <- x[
  x$area == 0 & x$period == 1,
  "exposure"
]
instrument_area0_period0 <- z[
  z$area == 0 & z$period == 0,
  "exposure"
]

estimates <- list(
  list(term = "iv_slope", estimate = unname(iv_coefficients[4]), se = NULL),
  list(term = "exposure_area0_period0", estimate = area0_period0, se = NULL),
  list(term = "exposure_area0_period1", estimate = area0_period1, se = NULL),
  list(term = "instrument_area0_period0", estimate = instrument_area0_period0, se = NULL)
)

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "weighted_two_stage_least_squares",
    outcome = "change_pp",
    endogenous_regressor = "x",
    excluded_instrument = "z",
    exogenous_regressors = c("intercept", "period_indicator", "control"),
    weight = "base_vintage_population",
    exposure_units = "thousands_of_real_dollars_per_worker_per_decade",
    trade_changes = "nominal_dollars_over_stated_interval"
  ),
  diagnostics = list(n_obs = 72L)
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  digits = 16,
  null = "null",
  na = "null",
  pretty = TRUE
)
