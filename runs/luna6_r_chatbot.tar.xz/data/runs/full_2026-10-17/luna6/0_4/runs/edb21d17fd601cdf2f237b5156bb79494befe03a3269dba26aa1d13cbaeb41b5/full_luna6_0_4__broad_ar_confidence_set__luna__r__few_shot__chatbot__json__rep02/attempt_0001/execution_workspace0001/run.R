d <- read.csv("input.csv")

n <- nrow(d)
q <- 2L
df <- n - 4L
critical <- qf(0.95, df1 = q, df2 = df)
k <- q * critical / df

# Restricted and unrestricted residual sums of squares for y - beta * endog.
ry <- residuals(lm(y ~ x, data = d))
rd <- residuals(lm(endog ~ x, data = d))
uy <- residuals(lm(y ~ x + z1 + z2, data = d))
ud <- residuals(lm(endog ~ x + z1 + z2, data = d))

A <- sum(rd^2) - (1 + k) * sum(ud^2)
B <- -2 * (sum(ry * rd) - (1 + k) * sum(uy * ud))
C <- sum(ry^2) - (1 + k) * sum(uy^2)

disc <- B^2 - 4 * A * C
if (!is.finite(disc) || disc < 0 || abs(A) < 1e-12) {
  stop("The data do not yield two finite distinct AR boundaries.")
}

bounds <- sort(c((-B - sqrt(disc)) / (2 * A),
                 (-B + sqrt(disc)) / (2 * A)))
accepts <- function(beta) A * beta^2 + B * beta + C <= 0

transformed <- d$y - d$endog
fit_r1 <- lm(transformed ~ x, data = d)
fit_u1 <- lm(transformed ~ x + z1 + z2, data = d)
ar_f_at_one <- ((deviance(fit_r1) - deviance(fit_u1)) / q) /
  (deviance(fit_u1) / df)

rows <- list(
  list(term = "boundary_low", estimate = unname(bounds[1]), se = NULL, n_obs = n),
  list(term = "boundary_high", estimate = unname(bounds[2]), se = NULL, n_obs = n),
  list(term = "accepts_zero", estimate = as.integer(accepts(0)), se = NULL, n_obs = n),
  list(term = "unbounded", estimate = as.integer(A < 0), se = NULL, n_obs = n),
  list(term = "ar_f_at_one", estimate = unname(ar_f_at_one), se = NULL, n_obs = n)
)

jsonlite::write_json(
  list(
    task_id = "broad_ar_confidence_set",
    platform = "r",
    estimates = rows,
    method_metadata = list(
      estimator = "Anderson-Rubin inversion of the homoskedastic joint F test",
      vcov = "Conventional homoskedastic"
    ),
    diagnostics = list(
      numerator_df = q,
      denominator_df = df,
      critical_value = critical,
      quadratic_A = A,
      quadratic_B = B,
      quadratic_C = C
    )
  ),
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
