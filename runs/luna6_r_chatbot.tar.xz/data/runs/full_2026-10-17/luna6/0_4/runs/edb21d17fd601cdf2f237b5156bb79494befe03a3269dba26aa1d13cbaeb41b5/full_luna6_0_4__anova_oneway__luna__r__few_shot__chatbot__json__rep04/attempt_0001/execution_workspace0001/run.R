library(jsonlite)

dat <- read.csv("./input.csv")
fit <- aov(y ~ group, data = dat)
tab <- summary(fit)[[1]]

out <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = list(
    list(term = "F", estimate = unname(tab["group", "F value"]), se = NULL,
         n_obs = nrow(dat)),
    list(term = "df_num", estimate = unname(tab["group", "Df"]), se = NULL,
         n_obs = nrow(dat)),
    list(term = "df_den", estimate = unname(tab["Residuals", "Df"]), se = NULL,
         n_obs = nrow(dat)),
    list(term = "p_value", estimate = unname(tab["group", "Pr(>F)"]), se = NULL,
         n_obs = nrow(dat))
  ),
  method_metadata = list(estimator = "One-way ANOVA",
                         vcov = "Classical ANOVA"),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "result.json", auto_unbox = TRUE, null = "null", digits = 15)
