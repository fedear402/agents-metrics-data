dat <- read.csv("./input.csv")
if (!"y" %in% names(dat)) stop("input.csv must contain a column named y")
y <- as.numeric(dat$y)
if (anyNA(y) || length(y) < 3L) stop("y must contain at least three non-missing observations")

fit <- stats::arima(y, order = c(1, 1, 1), include.mean = FALSE, method = "ML")
pred <- predict(fit, n.ahead = 1L)

forecast <- as.numeric(pred$pred[1L])
se <- as.numeric(pred$se[1L])
z <- stats::qnorm(0.975)
bounds <- c(forecast - z * se, forecast + z * se)
n <- length(y)

result <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = list(
    list(term = "forecast", estimate = forecast, se = se, n_obs = n),
    list(term = "lower_95", estimate = bounds[1L], se = se, n_obs = n),
    list(term = "upper_95", estimate = bounds[2L], se = se, n_obs = n)
  ),
  method_metadata = list(
    estimator = "ARIMA(1,1,1) maximum likelihood, no constant or drift",
    vcov = "Model-based one-step-ahead forecast standard error"
  ),
  diagnostics = list()
)

if (!requireNamespace("jsonlite", quietly = TRUE)) {
  stop("Package jsonlite is required to write result.json")
}
jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = 16, pretty = TRUE, na = "null")
