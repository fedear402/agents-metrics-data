dat <- read.csv("input.csv")

fit <- nnet::multinom(y ~ x + z, data = dat, trace = FALSE)
V <- vcov(fit)
b <- coef(fit)

# multinom uses outcome 0 as the reference when levels are ordered 0, 1, 2.
if (!identical(rownames(b), c("1", "2"))) {
  stop("Expected outcomes 1 and 2 with 0 as the base outcome.")
}

terms <- c("x_cat1", "z_cat1", "x_cat2", "z_cat2")
estimates <- c(b["1", "x"], b["1", "z"], b["2", "x"], b["2", "z"])
ses <- c(
  sqrt(V["1:x", "1:x"]),
  sqrt(V["1:z", "1:z"]),
  sqrt(V["2:x", "2:x"]),
  sqrt(V["2:z", "2:z"])
)

eta2_zero <- b["2", "(Intercept)"]
prob_cat2_zero <- exp(eta2_zero) / (1 + exp(b["1", "(Intercept)"]) + exp(eta2_zero))

n <- nrow(dat)
rows <- lapply(seq_along(terms), function(i) {
  list(term = terms[i], estimate = unname(estimates[i]), se = unname(ses[i]), n_obs = n)
})
rows[[5]] <- list(term = "prob_cat2_zero", estimate = unname(prob_cat2_zero), se = NULL, n_obs = n)

result <- list(
  task_id = "broad_multinomial_logit",
  platform = "r",
  estimates = rows,
  method_metadata = list(
    estimator = "Multinomial logit maximum likelihood",
    vcov = "Conventional observed-information covariance matrix"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = 15, na = "null")
