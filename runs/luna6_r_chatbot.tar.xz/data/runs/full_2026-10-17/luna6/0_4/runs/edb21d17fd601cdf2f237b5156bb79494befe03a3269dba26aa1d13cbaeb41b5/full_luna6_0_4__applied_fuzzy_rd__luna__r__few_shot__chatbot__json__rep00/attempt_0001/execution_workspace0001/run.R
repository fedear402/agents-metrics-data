library(jsonlite)

data <- read.csv("input.csv")
d <- data[abs(data$score) < 1, ]
n <- nrow(d)

x <- d$score
right <- as.numeric(x >= 0)
weight <- 1 - abs(x)

# Side-specific intercepts and slopes, with separate local-linear fits.
X <- cbind(left_intercept = 1 - right,
           left_slope = (1 - right) * x,
           right_intercept = right,
           right_slope = right * x)

Y <- cbind(earnings = d$earnings, participated = d$participated)
bread <- solve(crossprod(X, weight * X))
beta <- bread %*% crossprod(X, weight * Y)
residuals <- Y - X %*% beta

# Right limit minus left limit.
contrast <- c(-1, 0, 1, 0)
jumps <- drop(contrast %*% beta)

# HC0 joint covariance for the two discontinuity estimates.
loading <- drop(X %*% bread %*% contrast) * weight
influence <- loading * residuals
joint_vcov <- crossprod(influence)
ses <- sqrt(diag(joint_vcov))

ratio <- jumps[1] / jumps[2]
gradient <- c(1 / jumps[2], -jumps[1] / jumps[2]^2)
ratio_se <- sqrt(drop(t(gradient) %*% joint_vcov %*% gradient))

row <- function(term, estimate, se) {
  list(term = term, estimate = unname(as.numeric(estimate)),
       se = unname(as.numeric(se)), n_obs = as.integer(n))
}

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    row("treatment_effect", ratio, ratio_se),
    row("reduced_form", jumps[1], ses[1]),
    row("first_stage", jumps[2], ses[2])
  ),
  method_metadata = list(
    estimator = "Triangular-weighted local-linear fuzzy regression discontinuity",
    vcov = "HC0, no degrees-of-freedom correction; joint covariance with delta method"
  ),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null",
           digits = 16, pretty = TRUE)
