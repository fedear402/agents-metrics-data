dat <- read.csv("input.csv")
d <- dat[abs(dat$score) < 1, ]
n <- nrow(d)

x <- abs(d$score)
w <- 1 - x
right <- as.numeric(d$score >= 0)
z <- cbind(1, right, d$score, right * d$score)

# Estimate the two outcomes with the same weighted local-linear design.
fit_joint <- function(y) {
  Xw <- z * sqrt(w)
  yw <- y * sqrt(w)
  solve(crossprod(Xw), crossprod(Xw, yw))
}

b_y <- fit_joint(d$earnings)
b_p <- fit_joint(d$participated)

# The coefficient on right is the right-minus-left discontinuity.
reduced_form <- b_y[2]
first_stage <- b_p[2]
treatment_effect <- reduced_form / first_stage

# HC0 covariance for the joint outcome coefficients, retaining cross-outcome
# covariance because both outcomes use the same observations and weights.
Xw <- z * sqrt(w)
bread <- solve(crossprod(Xw))
res_y <- d$earnings - drop(z %*% b_y)
res_p <- d$participated - drop(z %*% b_p)
meat_yy <- crossprod(z, z * (w * res_y^2))
meat_pp <- crossprod(z, z * (w * res_p^2))
meat_yp <- crossprod(z, z * (w * res_y * res_p))
var_y <- bread %*% meat_yy %*% bread
var_p <- bread %*% meat_pp %*% bread
cov_yp <- bread %*% meat_yp %*% bread
se_rf <- sqrt(var_y[2, 2])
se_fs <- sqrt(var_p[2, 2])

grad_y <- 1 / first_stage
grad_p <- -reduced_form / first_stage^2
se_te <- sqrt(grad_y^2 * var_y[2, 2] +
              grad_p^2 * var_p[2, 2] +
              2 * grad_y * grad_p * cov_yp[2, 2])

out <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = unname(treatment_effect),
         se = unname(se_te), n_obs = n),
    list(term = "reduced_form", estimate = unname(reduced_form),
         se = unname(se_rf), n_obs = n),
    list(term = "first_stage", estimate = unname(first_stage),
         se = unname(se_fs), n_obs = n)
  ),
  method_metadata = list(
    estimator = "Fuzzy RD local-linear WLS, triangular weights, bandwidth 1",
    vcov = "HC0 sandwich; delta method with joint outcome covariance"
  ),
  diagnostics = list()
)

jsonlite::write_json(out, "result.json", auto_unbox = TRUE, digits = 15, na = "null")
