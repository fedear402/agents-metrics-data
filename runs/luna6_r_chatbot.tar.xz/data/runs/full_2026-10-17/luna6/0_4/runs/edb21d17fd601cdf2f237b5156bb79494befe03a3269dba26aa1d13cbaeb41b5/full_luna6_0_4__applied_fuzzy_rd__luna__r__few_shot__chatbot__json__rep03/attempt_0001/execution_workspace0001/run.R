library(jsonlite)

dat <- read.csv("input.csv")
d <- dat[abs(dat$score) < 1, , drop = FALSE]
n <- nrow(d)

x <- d$score
right <- as.numeric(x >= 0)
w <- 1 - abs(x)

# Separate local-linear fits, represented by side-specific intercept and slope.
X <- cbind(left_intercept = 1 - right,
           left_slope = x * (1 - right),
           right_intercept = right,
           right_slope = x * right)

bread <- solve(crossprod(X, w * X))
contrast <- c(-1, 0, 1, 0)

fit_outcome <- function(y) {
  beta <- drop(bread %*% crossprod(X, w * y))
  resid <- y - drop(X %*% beta)
  jump <- sum(contrast * beta)
  loading <- drop(w * X %*% bread %*% contrast)
  list(jump = jump, influence = loading * resid)
}

rf <- fit_outcome(d$earnings)
fs <- fit_outcome(d$participated)

joint_cov <- crossprod(cbind(rf$influence, fs$influence))
gradient <- c(1 / fs$jump, -rf$jump / fs$jump^2)
te_se <- sqrt(drop(t(gradient) %*% joint_cov %*% gradient))

row <- function(term, estimate, se) {
  list(term = term, estimate = unname(as.numeric(estimate)),
       se = unname(as.numeric(se)), n_obs = as.integer(n))
}

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    row("treatment_effect", rf$jump / fs$jump, te_se),
    row("reduced_form", rf$jump, sqrt(joint_cov[1, 1])),
    row("first_stage", fs$jump, sqrt(joint_cov[2, 2]))
  ),
  method_metadata = list(
    estimator = "weighted local-linear fuzzy regression discontinuity",
    vcov = "joint HC0 sandwich, fixed bandwidth and triangular weights"
  ),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null",
           digits = 16, pretty = TRUE)
