households <- read.csv("households.csv")
census <- read.csv("census.csv")

d <- subset(households, recipient == 0)

# Weighted 2SLS with group-specific dose slopes and no additional intercept.
g0 <- 1 - d$eligible
g1 <- d$eligible
X <- cbind(
  g0 = g0,
  g1 = g1,
  baseline_g0 = d$baseline * g0,
  baseline_g1 = d$baseline * g1,
  dose_g0 = d$dose * g0,
  dose_g1 = d$dose * g1
)
Z <- cbind(
  g0 = g0,
  g1 = g1,
  baseline_g0 = d$baseline * g0,
  baseline_g1 = d$baseline * g1,
  instrument_g0 = d$instrument * g0,
  instrument_g1 = d$instrument * g1
)

sqrt_w <- sqrt(d$weight)
Xw <- X * sqrt_w
Zw <- Z * sqrt_w
yw <- d$outcome * sqrt_w

# Solve the weighted 2SLS normal equations.
PZX <- qr.fitted(qr(Zw), Xw)
PZy <- qr.fitted(qr(Zw), yw)
beta <- as.numeric(qr.coef(qr(PZX), PZy))

slope_ineligible <- beta[5]
slope_eligible <- beta[6]

mean_dose <- sapply(0:1, function(g) {
  a <- d[d$eligible == g, ]
  weighted.mean(a$dose, a$weight)
})

effects <- c(
  ineligible_effect = slope_ineligible * mean_dose[1],
  eligible_nonrecipient_effect = slope_eligible * mean_dose[2]
)

census_weights <- census$nonrecipient_population[
  match(0:1, census$eligible)
]
population_effect <- weighted.mean(effects, census_weights)

n_obs <- as.integer(nrow(d))
estimates <- list(
  list(term = "ineligible_effect", estimate = unname(effects[1]),
       se = NULL, n_obs = n_obs),
  list(term = "eligible_nonrecipient_effect", estimate = unname(effects[2]),
       se = NULL, n_obs = n_obs),
  list(term = "population_effect", estimate = unname(population_effect),
       se = NULL, n_obs = n_obs)
)

result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "weighted_2sls",
    sample = "all households with recipient == 0",
    endogenous_columns = c("dose*(1-eligible)", "dose*eligible"),
    exogenous_columns = c(
      "1-eligible", "eligible",
      "baseline*(1-eligible)", "baseline*eligible"
    ),
    instruments = c(
      "1-eligible", "eligible",
      "baseline*(1-eligible)", "baseline*eligible",
      "instrument*(1-eligible)", "instrument*eligible"
    ),
    counterfactual = "dose set to zero for every retained household",
    attribution_convention = "synthetic zero-dose counterfactual",
    group_effect = "fitted group dose slope times weighted mean dose",
    aggregation_weights = "census nonrecipient_population"
  ),
  diagnostics = list(
    n_obs = n_obs,
    n_ineligible = as.integer(sum(d$eligible == 0)),
    n_eligible_nonrecipient = as.integer(sum(d$eligible == 1))
  )
)

jsonlite::write_json(
  result,
  path = "result.json",
  auto_unbox = TRUE,
  digits = 16,
  null = "null",
  pretty = TRUE
)
