library(jsonlite)

dat <- read.csv("input.csv")
keep <- abs(dat$score) < 1
d <- dat[keep, ]
n <- nrow(d)

x <- d$score
right <- as.numeric(x >= 0)
w <- 1 - abs(x)

# Separate local-linear regressions, represented by side-specific intercepts
# and slopes. The coefficient on the right-side intercept gives the jump.
X <- cbind(left = 1 - right,
           left_slope = (1 - right) * x,
           right = right,
           right_slope = right * x)

bread <- solve(crossprod(X, w * X))
contrast <- c(-1, 0, 1, 0)

Y <- cbind(earnings = d$earnings, participated = d$participated)
coef <- bread %*% crossprod(X, w * Y)
resid <- Y - X %*% coef
jumps <- drop(contrast %*% coef)

loading <- w * drop(X %*% bread %*% contrast)
influence <- loading * resid
joint_vcov <- crossprod(influence)
jump_se <- sqrt(diag(joint_vcov))

ratio <- jumps[1] / jumps[2]
gradient <- c(1 / jumps[2], -jumps[1] / jumps[2]^2)
ratio_se <- sqrt(drop(t(gradient) %*% joint_vcov %*% gradient))

row <- function(term, estimate, se) {
  list(term = term, estimate = unname(as.numeric(estimate)),
       se = unname(as.numeric(se)), n_obs = as.integer(n))
}

write_json(
  list(
    task_id = "applied_fuzzy_rd",
    platform = "r",
    estimates = list(
      row("treatment_effect", ratio, ratio_se),
      row("reduced_form", jumps[1], jump_se[1]),
      row("first_stage", jumps[2], jump_se[2])
    ),
    method_metadata = list(
      estimator = "Weighted local-linear fuzzy regression discontinuity",
      vcov = "HC0, joint covariance from observation-level influence contributions; no degrees-of-freedom correction"
    ),
    diagnostics = list()
  ),
  "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE
)
