data <- read.csv("input.csv")

keep <- abs(data$score) < 1
d <- data[keep, ]
n_obs <- nrow(d)
w <- 1 - abs(d$score)
right <- as.numeric(d$score >= 0)
x <- abs(d$score)

# Fit each outcome using a common design and triangular weights.
design <- cbind(intercept = 1, right = right, x_left = x * (1 - right), x_right = x * right)
fit <- function(y) {
  sw <- sqrt(w)
  coef <- qr.solve(design * sw, y * sw)
  resid <- y - drop(design %*% coef)
  bread <- solve(crossprod(design, w * design))
  meat <- crossprod(design, (w * resid^2) * design)
  list(coef = coef, vcov = bread %*% meat %*% bread)
}

earn <- fit(d$earnings)
part <- fit(d$participated)

# Right-limit minus left-limit is the coefficient on the right indicator.
rf <- earn$coef["right"]
fs <- part$coef["right"]
var_rf <- earn$vcov["right", "right"]
var_fs <- part$vcov["right", "right"]

# HC0 cross-covariance for the two estimates, using the same observations.
bread <- solve(crossprod(design, w * design))
cross_meat <- crossprod(design, (w^2 * (d$earnings - drop(design %*% earn$coef)) *
                                  (d$participated - drop(design %*% part$coef))) * design)
cross_vcov <- bread %*% cross_meat %*% bread
cov_rf_fs <- cross_vcov["right", "right"]

te <- rf / fs
var_te <- var_rf / fs^2 + rf^2 * var_fs / fs^4 - 2 * rf * cov_rf_fs / fs^3

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = unname(te), se = sqrt(max(0, var_te)), n_obs = n_obs),
    list(term = "reduced_form", estimate = unname(rf), se = sqrt(max(0, var_rf)), n_obs = n_obs),
    list(term = "first_stage", estimate = unname(fs), se = sqrt(max(0, var_fs)), n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "Fuzzy local-linear regression discontinuity with triangular weights",
    vcov = "HC0 sandwich; delta method using joint covariance"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = 15, na = "null")
