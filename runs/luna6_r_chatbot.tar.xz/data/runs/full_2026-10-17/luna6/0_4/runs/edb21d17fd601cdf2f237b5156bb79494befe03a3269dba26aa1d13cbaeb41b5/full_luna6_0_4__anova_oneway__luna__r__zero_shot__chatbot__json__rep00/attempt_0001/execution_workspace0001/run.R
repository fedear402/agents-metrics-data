data <- read.csv("./input.csv")
data$group <- as.factor(data$group)

fit <- aov(y ~ group, data = data)
tab <- summary(fit)[[1]]

f_stat <- unname(tab["group", "F value"])
df_num <- unname(tab["group", "Df"])
df_den <- unname(tab["Residuals", "Df"])
p_value <- unname(tab["group", "Pr(>F)"])
n_obs <- sum(complete.cases(data[, c("y", "group")]))

estimates <- data.frame(
  term = c("F", "df_num", "df_den", "p_value"),
  estimate = c(f_stat, df_num, df_den, p_value),
  se = rep(NA_real_, 4),
  n_obs = rep(as.integer(n_obs), 4)
)

result <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = estimates,
  method_metadata = list(estimator = "one-way ANOVA", vcov = "classical ANOVA"),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, pretty = TRUE, na = "null", digits = 15)
