library(jsonlite)

dat <- read.csv("./input.csv")
fit <- aov(y ~ factor(group), data = dat)
tab <- summary(fit)[[1]]

f_stat <- unname(tab["factor(group)", "F value"])
df_num <- unname(tab["factor(group)", "Df"])
df_den <- unname(tab["Residuals", "Df"])
p_value <- unname(tab["factor(group)", "Pr(>F)"])
n_obs <- nrow(dat)

out <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = list(
    list(term = "F", estimate = f_stat, se = NULL, n_obs = n_obs),
    list(term = "df_num", estimate = df_num, se = NULL, n_obs = n_obs),
    list(term = "df_den", estimate = df_den, se = NULL, n_obs = n_obs),
    list(term = "p_value", estimate = p_value, se = NULL, n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "One-way ANOVA",
    vcov = "classical ANOVA"
  ),
  diagnostics = list()
)

write_json(out, "result.json", auto_unbox = TRUE, digits = 15)
