households <- read.csv("households.csv")
census <- read.csv("census.csv")

d <- subset(households, recipient == 0)
n_obs <- nrow(d)

# Build group-specific endogenous regressors and their excluded instruments.
d$endog_ineligible <- d$dose * (1 - d$eligible)
d$endog_eligible <- d$dose * d$eligible
d$instrument_ineligible <- d$instrument * (1 - d$eligible)
d$instrument_eligible <- d$instrument * d$eligible

X <- cbind(
  ineligible = 1 - d$eligible,
  eligible = d$eligible,
  baseline_ineligible = d$baseline * (1 - d$eligible),
  baseline_eligible = d$baseline * d$eligible,
  dose_ineligible = d$endog_ineligible,
  dose_eligible = d$endog_eligible
)

Z <- cbind(
  ineligible = 1 - d$eligible,
  eligible = d$eligible,
  baseline_ineligible = d$baseline * (1 - d$eligible),
  baseline_eligible = d$baseline * d$eligible,
  instrument_ineligible = d$instrument_ineligible,
  instrument_eligible = d$instrument_eligible
)

w <- d$weight
sqrt_w <- sqrt(w)
Xw <- X * sqrt_w
Zw <- Z * sqrt_w
yw <- d$outcome * sqrt_w

# Weighted 2SLS: project all regressors onto the instrument space,
# then estimate the structural equation using the projected regressors.
X_hat <- qr.fitted(qr(Zw), Xw)
beta <- as.numeric(qr.coef(qr(X_hat), yw))
names(beta) <- colnames(X)

mean_dose_ineligible <- weighted.mean(
  d$dose[d$eligible == 0],
  w[d$eligible == 0]
)
mean_dose_eligible <- weighted.mean(
  d$dose[d$eligible == 1],
  w[d$eligible == 1]
)

ineligible_effect <- beta["dose_ineligible"] * mean_dose_ineligible
eligible_nonrecipient_effect <- beta["dose_eligible"] * mean_dose_eligible

group_counts <- census$nonrecipient_population[
  match(c(0, 1), census$eligible)
]
population_effect <- weighted.mean(
  c(ineligible_effect, eligible_nonrecipient_effect),
  group_counts
)

estimates <- list(
  list(term = "ineligible_effect", estimate = unname(ineligible_effect),
       se = NULL, n_obs = as.integer(n_obs)),
  list(term = "eligible_nonrecipient_effect",
       estimate = unname(eligible_nonrecipient_effect),
       se = NULL, n_obs = as.integer(n_obs)),
  list(term = "population_effect", estimate = unname(population_effect),
       se = NULL, n_obs = as.integer(n_obs))
)

result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    method = "Weighted 2SLS with group-specific dose slopes",
    sample = "All households with recipient equal to zero",
    endogenous_columns = c("dose*(1-eligible)", "dose*eligible"),
    exogenous_columns = c(
      "1-eligible", "eligible",
      "baseline*(1-eligible)", "baseline*eligible"
    ),
    instrument_columns = c(
      "1-eligible", "eligible",
      "baseline*(1-eligible)", "baseline*eligible",
      "instrument*(1-eligible)", "instrument*eligible"
    ),
    within_group_average = "Household-weighted mean dose",
    final_aggregation = "Census nonrecipient population counts",
    counterfactual_convention =
      "Synthetic attribution to a counterfactual with dose zero for every retained household"
  ),
  diagnostics = list(
    n_obs = as.integer(n_obs),
    n_ineligible = as.integer(sum(d$eligible == 0)),
    n_eligible_nonrecipient = as.integer(sum(d$eligible == 1)),
    census_counts_used = as.list(setNames(
      as.integer(group_counts),
      c("ineligible", "eligible")
    ))
  )
)

jsonlite::write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  digits = 16,
  na = "null",
  pretty = TRUE
)
