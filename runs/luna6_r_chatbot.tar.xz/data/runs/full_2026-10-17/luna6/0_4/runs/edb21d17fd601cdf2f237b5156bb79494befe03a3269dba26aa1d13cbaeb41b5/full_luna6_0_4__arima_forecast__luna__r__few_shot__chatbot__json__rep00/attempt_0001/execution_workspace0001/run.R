library(forecast)
library(jsonlite)

df <- read.csv("./input.csv")
y <- as.numeric(df$y)

fit <- Arima(y, order = c(1, 1, 1), include.drift = FALSE,
             include.mean = FALSE, method = "ML")
pred <- forecast(fit, h = 1, level = 95)

out <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = list(
    list(term = "forecast", estimate = unname(pred$mean[1]), se = NA_real_, n_obs = length(y)),
    list(term = "lower_95", estimate = unname(pred$lower[1, 1]), se = NA_real_, n_obs = length(y)),
    list(term = "upper_95", estimate = unname(pred$upper[1, 1]), se = NA_real_, n_obs = length(y))
  ),
  method_metadata = list(estimator = "ARIMA(1,1,1) maximum likelihood, no constant or drift",
                         vcov = "model-based prediction interval"),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "result.json", auto_unbox = TRUE, na = "null", digits = 16)
