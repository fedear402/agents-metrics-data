library(jsonlite)

d <- read.csv("input.csv")

cohorts <- c(3, 5, 7)
terms <- c("att_g3", "att_g5", "att_g7")
estimates <- numeric(length(cohorts))
treated_counts <- integer(length(cohorts))
row_counts <- integer(length(cohorts))

for (i in seq_along(cohorts)) {
  c <- cohorts[i]
  window_times <- (c - 2):(c + 2)

  eligible <- d[
    d$time %in% window_times &
      (d$g == c | d$g == 0 | d$g > c + 2),
  ]

  observed_times <- split(eligible$time, eligible$id)
  balanced_ids <- names(Filter(
    function(x) all(window_times %in% x),
    observed_times
  ))

  comparison <- eligible[eligible$id %in% balanced_ids, ]
  comparison$did <- as.numeric(comparison$g == c & comparison$time >= c)

  estimates[i] <- unname(coef(lm(
    y ~ did + factor(id) + factor(time),
    data = comparison
  ))["did"])
  treated_counts[i] <- length(unique(comparison$id[comparison$g == c]))
  row_counts[i] <- nrow(comparison)
}

out <- list(
  task_id = "broad_cohort_stack",
  platform = "r",
  estimates = c(
    lapply(seq_along(cohorts), function(i) {
      list(
        term = terms[i],
        estimate = estimates[i],
        se = NULL,
        n_obs = row_counts[i]
      )
    }),
    list(list(
      term = "att_weighted",
      estimate = weighted.mean(estimates, treated_counts),
      se = NULL,
      n_obs = sum(row_counts)
    ))
  ),
  method_metadata = list(),
  diagnostics = list()
)

write_json(out, "result.json", auto_unbox = TRUE, null = "null", digits = 16)
