dat <- read.csv("input.csv")
n <- nrow(dat)
crit <- qf(0.95, df1 = 2, df2 = n - 4)

ar_f <- function(beta) {
  fit <- lm(I(y - beta * endog) ~ x + z1 + z2, data = dat)
  tab <- anova(fit)
  rss_full <- sum(resid(fit)^2)
  fit_restricted <- lm(I(y - beta * endog) ~ x, data = dat)
  rss_restricted <- sum(resid(fit_restricted)^2)
  ((rss_restricted - rss_full) / 2) / (rss_full / (n - 4))
}

# The AR statistic is a quadratic function of beta. Evaluate it at
# three points to recover that quadratic and solve F(beta) = crit.
f0 <- ar_f(0)
f1 <- ar_f(1)
fm1 <- ar_f(-1)
a <- (f1 + fm1 - 2 * f0) / 2
b <- (f1 - fm1) / 2
c <- f0 - crit

roots <- sort((-b + c(-1, 1) * sqrt(b^2 - 4 * a * c)) / (2 * a))
accepts_zero <- as.integer(f0 <= crit)
unbounded <- as.integer(a <= 0 || b^2 - 4 * a * c < 0)

estimates <- data.frame(
  term = c("boundary_low", "boundary_high", "accepts_zero", "unbounded", "ar_f_at_one"),
  estimate = c(roots[1], roots[2], accepts_zero, unbounded, f1),
  se = rep(NA_real_, 5),
  n_obs = rep(n, 5)
)

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = lapply(seq_len(nrow(estimates)), function(i) {
    list(
      term = estimates$term[i],
      estimate = unname(estimates$estimate[i]),
      se = NULL,
      n_obs = estimates$n_obs[i]
    )
  }),
  method_metadata = list(
    estimator = "Anderson-Rubin test inversion with conventional homoskedastic joint F test",
    vcov = "Conventional homoskedastic"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = 15, null = "null")
