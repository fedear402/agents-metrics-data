dat <- read.csv("input.csv")
n <- nrow(dat)
critical <- qf(0.95, df1 = 2, df2 = n - 4)

ar_stat <- function(beta) {
  fit <- lm(I(y - beta * endog) ~ x + z1 + z2, data = dat)
  rss_restricted <- sum(resid(lm(I(y - beta * endog) ~ x, data = dat))^2)
  rss_full <- sum(resid(fit)^2)
  ((rss_restricted - rss_full) / 2) / (rss_full / (n - 4))
}

# The AR test statistic is a ratio of quadratic forms in beta.
# Locate its finite boundary points by solving the equivalent RSS inequality.
rss_diff <- function(beta) {
  yb <- dat$y - beta * dat$endog
  restricted <- lm(yb ~ dat$x)
  full <- lm(yb ~ dat$x + dat$z1 + dat$z2)
  sum(resid(restricted)^2) - sum(resid(full)^2) -
    2 * critical * sum(resid(full)^2) / (n - 4)
}

# A quadratic inequality has at most two finite roots. Recover its coefficients
# from evaluations, then solve analytically over the full real line.
v0 <- rss_diff(0)
vp <- rss_diff(1)
vm <- rss_diff(-1)
a <- (vp + vm - 2 * v0) / 2
b <- (vp - vm) / 2
c <- v0
disc <- b^2 - 4 * a * c
roots <- sort(c((-b - sqrt(disc)) / (2 * a),
                (-b + sqrt(disc)) / (2 * a)))

accepts_zero <- as.integer(ar_stat(0) <= critical)
unbounded <- as.integer(rss_diff(1e6) <= 0 || rss_diff(-1e6) <= 0)

estimates <- data.frame(
  term = c("boundary_low", "boundary_high", "accepts_zero", "unbounded", "ar_f_at_one"),
  estimate = c(roots[1], roots[2], accepts_zero, unbounded, ar_stat(1)),
  se = I(rep(list(NULL), 5)),
  n_obs = rep(n, 5)
)

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = lapply(seq_len(nrow(estimates)), function(i) {
    list(term = estimates$term[i], estimate = estimates$estimate[i],
         se = NULL, n_obs = estimates$n_obs[i])
  }),
  method_metadata = list(
    estimator = "Anderson-Rubin inversion using conventional homoskedastic joint F test",
    vcov = "Conventional homoskedastic"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 15)
