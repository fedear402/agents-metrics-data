#!/usr/bin/env Rscript

suppressPackageStartupMessages(library(jsonlite))

dat <- read.csv("input.csv")
n <- nrow(dat)

fit <- nnet::multinom(y ~ x + z, data = dat, trace = FALSE)
co <- coef(fit)
vc <- vcov(fit)

x_cat1 <- co["1", "x"]
z_cat1 <- co["1", "z"]
x_cat2 <- co["2", "x"]
z_cat2 <- co["2", "z"]

p_cat2_zero <- plogis(co["2", "(Intercept)") - co["1", "(Intercept)") - log1p(
  exp(co["1", "(Intercept)") - co["2", "(Intercept)"))
# Compute the base-outcome probability and normalize all three alternatives.
eta1 <- co["1", "(Intercept)"]
eta2 <- co["2", "(Intercept)"]
prob_cat2_zero <- exp(eta2) / (1 + exp(eta1) + exp(eta2))

estimates <- list(
  list(term = "x_cat1", estimate = unname(x_cat1), se = sqrt(vc["1:x", "1:x"]), n_obs = n),
  list(term = "z_cat1", estimate = unname(z_cat1), se = sqrt(vc["1:z", "1:z"]), n_obs = n),
  list(term = "x_cat2", estimate = unname(x_cat2), se = sqrt(vc["2:x", "2:x"]), n_obs = n),
  list(term = "z_cat2", estimate = unname(z_cat2), se = sqrt(vc["2:z", "2:z"]), n_obs = n),
  list(term = "prob_cat2_zero", estimate = unname(prob_cat2_zero), se = NULL, n_obs = n)
)

result <- list(
  task_id = "broad_multinomial_logit",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "Multinomial logit maximum likelihood",
    vcov = "Conventional observed-information standard errors"
  ),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, digits = 15, na = "null")
