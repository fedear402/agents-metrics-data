library(jsonlite)

households <- read.csv("households.csv", stringsAsFactors = FALSE)
census <- read.csv("census.csv", stringsAsFactors = FALSE)

required_household_columns <- c(
  "household", "eligible", "recipient", "instrument", "dose",
  "baseline", "weight", "outcome"
)
required_census_columns <- c("eligible", "nonrecipient_population")

if (!all(required_household_columns %in% names(households))) {
  stop("households.csv is missing one or more required columns.")
}
if (!all(required_census_columns %in% names(census))) {
  stop("census.csv is missing one or more required columns.")
}

dat <- households[households$recipient == 0, , drop = FALSE]
if (nrow(dat) == 0L) {
  stop("No nonrecipient household rows are available.")
}
if (any(!is.finite(dat$weight)) || any(dat$weight <= 0)) {
  stop("Estimation weights must be finite and positive.")
}

g0 <- 1 - dat$eligible
g1 <- dat$eligible

# Structural regressors: group indicators, group-specific baseline terms,
# and the two group-specific dose terms. No additional intercept is added.
X <- cbind(
  ineligible = g0,
  eligible = g1,
  baseline_ineligible = dat$baseline * g0,
  baseline_eligible = dat$baseline * g1,
  dose_ineligible = dat$dose * g0,
  dose_eligible = dat$dose * g1
)

# The instrument matrix contains the exogenous columns and both
# group-specific excluded instruments.
Z <- cbind(
  ineligible = g0,
  eligible = g1,
  baseline_ineligible = dat$baseline * g0,
  baseline_eligible = dat$baseline * g1,
  instrument_ineligible = dat$instrument * g0,
  instrument_eligible = dat$instrument * g1
)

y <- dat$outcome
w <- dat$weight
n_obs <- as.integer(nrow(dat))

# Weighted 2SLS: project every structural regressor on the full instrument
# matrix using regression weights, then estimate the structural equation
# with the same weights.
sqrt_w <- sqrt(w)
Zw <- Z * sqrt_w
Xw <- X * sqrt_w
yw <- y * sqrt_w

if (qr(Zw)$rank < ncol(Z)) {
  stop("Weighted instrument matrix is rank deficient.")
}
PZXw <- Z %*% qr.coef(qr(Zw), qr.solve(Zw, Xw))
PZyw <- Z %*% qr.coef(qr(Zw), qr.solve(Zw, yw))

# Equivalent weighted IV normal equations: X'W P_Z X and X'W P_Z y.
A <- crossprod(X, w * PZXw)
b <- crossprod(X, w * PZyw)
if (qr(A)$rank < ncol(A)) {
  stop("Weighted 2SLS coefficient matrix is rank deficient.")
}
beta <- drop(solve(A, b))

slope_ineligible <- beta[5L]
slope_eligible <- beta[6L]

weighted_mean_dose <- function(group) {
  idx <- group == 1
  sum(dat$weight[idx] * dat$dose[idx]) / sum(dat$weight[idx])
}

ineligible_effect <- slope_ineligible * weighted_mean_dose(g0)
eligible_nonrecipient_effect <- slope_eligible * weighted_mean_dose(g1)

population <- census$nonrecipient_population[match(c(0, 1), census$eligible)]
if (length(population) != 2L || anyNA(population) ||
    any(!is.finite(population)) || any(population < 0) ||
    sum(population) <= 0) {
  stop("Census must provide nonnegative population counts for both groups.")
}
population_effect <- (
  population[1L] * ineligible_effect +
    population[2L] * eligible_nonrecipient_effect
) / sum(population)

estimates <- list(
  list(term = "ineligible_effect",
       estimate = unname(ineligible_effect),
       se = NULL,
       n_obs = n_obs),
  list(term = "eligible_nonrecipient_effect",
       estimate = unname(eligible_nonrecipient_effect),
       se = NULL,
       n_obs = n_obs),
  list(term = "population_effect",
       estimate = unname(population_effect),
       se = NULL,
       n_obs = n_obs)
)

result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "weighted 2SLS",
    sample = "all household rows with recipient equal to zero",
    endogenous_columns = c("dose*(1-eligible)", "dose*eligible"),
    exogenous_columns = c(
      "1-eligible", "eligible",
      "baseline*(1-eligible)", "baseline*eligible"
    ),
    instrument_columns = c(
      "1-eligible", "eligible",
      "baseline*(1-eligible)", "baseline*eligible",
      "instrument*(1-eligible)", "instrument*eligible"
    ),
    regression_weight = "weight",
    group_effect_definition =
      "fitted group-specific dose slope times household-weighted mean dose among retained group observations",
    counterfactual_convention =
      "synthetic convention setting dose to zero for every retained household",
    population_aggregation =
      "weighted by census nonrecipient_population; census totals are used only for final between-group aggregation"
  ),
  diagnostics = list(
    n_obs = n_obs,
    nonrecipient_rows_used = n_obs,
    weighted_mean_dose_ineligible = weighted_mean_dose(g0),
    weighted_mean_dose_eligible = weighted_mean_dose(g1),
    ineligible_dose_slope = unname(slope_ineligible),
    eligible_dose_slope = unname(slope_eligible)
  )
)

write_json(
  result,
  path = "result.json",
  auto_unbox = TRUE,
  pretty = TRUE,
  digits = 16,
  null = "null"
)
