library(jsonlite)

dat <- read.csv("input.csv")

fit_cohort <- function(cohort) {
  window <- (cohort - 2):(cohort + 2)
  eligible <- dat[dat$g == cohort | dat$g == 0 | dat$g > cohort + 2, ]
  eligible <- eligible[eligible$time %in% window, ]

  counts <- table(eligible$id)
  balanced_ids <- names(counts[counts == length(window)])
  d <- eligible[eligible$id %in% balanced_ids, ]

  d$did <- as.integer(d$g == cohort & d$time >= cohort)
  d$id <- factor(d$id)
  d$time <- factor(d$time)

  coefficient <- unname(coef(lm(y ~ did + id + time, data = d))["did"])
  treated_units <- length(unique(d$id[d$g == cohort]))

  list(estimate = coefficient, n_obs = nrow(d), treated_units = treated_units)
}

results <- lapply(c(3, 5, 7), fit_cohort)
names(results) <- c("att_g3", "att_g5", "att_g7")

weights <- vapply(results, `[[`, numeric(1), "treated_units")
estimates <- vapply(results, `[[`, numeric(1), "estimate")
row_counts <- vapply(results, `[[`, integer(1), "n_obs")

output <- list(
  task_id = "broad_cohort_stack",
  platform = "r",
  estimates = list(
    list(term = "att_g3", estimate = estimates[1], se = NULL, n_obs = row_counts[1]),
    list(term = "att_g5", estimate = estimates[2], se = NULL, n_obs = row_counts[2]),
    list(term = "att_g7", estimate = estimates[3], se = NULL, n_obs = row_counts[3]),
    list(
      term = "att_weighted",
      estimate = weighted.mean(estimates, weights),
      se = NULL,
      n_obs = sum(row_counts)
    )
  ),
  method_metadata = list(),
  diagnostics = list()
)

write_json(output, "result.json", auto_unbox = TRUE, digits = 17, null = "null")
