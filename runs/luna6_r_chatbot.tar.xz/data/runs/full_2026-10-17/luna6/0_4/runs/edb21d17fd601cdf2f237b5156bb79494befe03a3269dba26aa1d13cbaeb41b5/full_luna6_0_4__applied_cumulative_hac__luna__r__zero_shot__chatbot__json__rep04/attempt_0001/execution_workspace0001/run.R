d <- read.csv("input.csv", stringsAsFactors = FALSE)
d$date <- as.Date(d$date)
d <- d[order(d$date), ]

d$vol_change <- c(NA_real_, diff(log(d$vix)))
d$log_sales <- log(d$sales)

for (j in 1:15) {
  d[[paste0("lag_", j)]] <- c(rep(NA_real_, j), head(d$vol_change, -j))
}

vars <- c("log_sales", paste0("lag_", 1:15))
est <- d[complete.cases(d[, vars]), vars]
fit <- lm(log_sales ~ ., data = est)
N <- nrow(est)

X <- model.matrix(fit)
u <- residuals(fit)
bread <- solve(crossprod(X))
score <- X * as.vector(u)
meat <- crossprod(score)

for (j in 1:15) {
  weight <- 1 - j / 16
  gamma <- crossprod(score[(j + 1):N, , drop = FALSE],
                     score[1:(N - j), , drop = FALSE])
  meat <- meat + weight * (gamma + t(gamma))
}

V <- (N / (N - 16)) * bread %*% meat %*% bread
b <- coef(fit)
cum_weights <- rep(0, length(b))
names(cum_weights) <- names(b)
cum_weights[paste0("lag_", 1:15)] <- 1

estimates <- list(
  list(term = "cumulative_response",
       estimate = sum(b[paste0("lag_", 1:15)]),
       se = sqrt(drop(t(cum_weights) %*% V %*% cum_weights)),
       n_obs = as.integer(N)),
  list(term = "lag_1", estimate = unname(b["lag_1"]),
       se = sqrt(V["lag_1", "lag_1"]), n_obs = as.integer(N)),
  list(term = "lag_15", estimate = unname(b["lag_15"]),
       se = sqrt(V["lag_15", "lag_15"]), n_obs = as.integer(N))
)

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "OLS of log(sales) on an intercept and lags 1 through 15 of first differences in log(vix)",
    vcov = "Newey-West HAC with Bartlett weights through lag 15, multiplied by N/(N-16)"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = 15, pretty = TRUE)
