dat <- read.csv("./input.csv", stringsAsFactors = FALSE)

if (!all(c("group", "y") %in% names(dat))) {
  stop("input.csv must contain columns 'group' and 'y'.")
}

dat <- dat[complete.cases(dat[, c("group", "y")]), c("group", "y")]
dat$group <- factor(dat$group)

fit <- aov(y ~ group, data = dat)
tab <- summary(fit)[[1]]

f_stat <- unname(tab["group", "F value"])
df_num <- unname(tab["group", "Df"])
df_den <- unname(tab["Residuals", "Df"])
p_value <- unname(tab["group", "Pr(>F)"])
n_obs <- nrow(dat)

estimates <- lapply(
  list(F = f_stat, df_num = df_num, df_den = df_den, p_value = p_value),
  function(value) {
    list(term = names(value), estimate = as.numeric(value), se = NULL, n_obs = n_obs)
  }
)

# Preserve the required term names and output order.
terms <- c("F", "df_num", "df_den", "p_value")
values <- c(f_stat, df_num, df_den, p_value)
estimates <- lapply(seq_along(terms), function(i) {
  list(term = terms[i], estimate = as.numeric(values[i]), se = NULL, n_obs = n_obs)
})

result <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = estimates,
  method_metadata = list(estimator = "one-way ANOVA", vcov = "classical ANOVA"),
  diagnostics = list()
)

jsonlite::write_json(result, path = "./result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE)
