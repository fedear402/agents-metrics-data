dat <- read.csv("input.csv")
n <- nrow(dat)
critical <- qf(0.95, df1 = 2, df2 = n - 4)

# Residualize variables on the included regressors: intercept and x.
W <- model.matrix(~ x, data = dat)
resid_on_W <- function(v) qr.resid(qr(W), v)

yr <- resid_on_W(dat$y)
er <- resid_on_W(dat$endog)
Zr <- cbind(resid_on_W(dat$z1), resid_on_W(dat$z2))

# For candidate beta, instrument coefficients are linear in beta.
# The joint F statistic is a quadratic divided by a quadratic.
A <- solve(crossprod(Zr), crossprod(Zr, yr))
B <- solve(crossprod(Zr), crossprod(Zr, er))
SSE0 <- sum(yr^2)

f_stat <- function(beta) {
  u <- yr - beta * er
  coef_z <- solve(crossprod(Zr), crossprod(Zr, u))
  rss_restricted <- sum(u^2)
  rss_unrestricted <- sum(qr.resid(qr(Zr), u)^2)
  ((rss_restricted - rss_unrestricted) / 2) /
    (rss_unrestricted / (n - 4))
}

# Find exact quadratic inequality coefficients for the AR acceptance set:
# 2*(RSS_restricted - RSS_unrestricted) <= critical*(n-4)*RSS_unrestricted.
P <- qr.resid(qr(Zr), yr)
Q <- qr.resid(qr(Zr), er)
u0 <- sum(P^2)
u1 <- -2 * sum(P * Q)
u2 <- sum(Q^2)

# Instrument-explained sums of squares for y-beta*endog.
C0 <- sum((yr - P)^2)
C1 <- -2 * sum((yr - P) * (er - Q))
C2 <- sum((er - Q)^2)

k <- critical * (n - 4)
# Equivalent polynomial: 2*C(beta) <= k*U(beta).
a <- 2 * C2 - k * u2
b <- 2 * C1 - k * u1
cc <- 2 * C0 - k * u0

disc <- b^2 - 4 * a * cc
roots <- sort(c((-b - sqrt(disc)) / (2 * a),
                (-b + sqrt(disc)) / (2 * a)))

accepts_zero <- as.integer(f_stat(0) <= critical)
unbounded <- as.integer(a < 0)

estimates <- list(
  list(term = "boundary_low", estimate = roots[1], se = NULL, n_obs = n),
  list(term = "boundary_high", estimate = roots[2], se = NULL, n_obs = n),
  list(term = "accepts_zero", estimate = accepts_zero, se = NULL, n_obs = n),
  list(term = "unbounded", estimate = unbounded, se = NULL, n_obs = n),
  list(term = "ar_f_at_one", estimate = f_stat(1), se = NULL, n_obs = n)
)

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "Anderson-Rubin test inversion using homoskedastic joint F test",
    vcov = "conventional homoskedastic"
  ),
  diagnostics = list()
)
jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = 16, null = "null")
