library(jsonlite)

dat <- read.csv("input.csv", stringsAsFactors = FALSE)

# Keep one row per region for regional variables and weights.
regions <- unique(dat[c("region_id", "region_weight", "x", "y")])
industries <- unique(dat[c("industry_id", "shock")])

region_ids <- regions$region_id
industry_ids <- industries$industry_id
R <- length(region_ids)
N <- length(industry_ids)

e <- regions$region_weight / sum(regions$region_weight)

# Build the region by industry share matrix.
share_matrix <- matrix(0, nrow = R, ncol = N,
                       dimnames = list(as.character(region_ids),
                                       as.character(industry_ids)))
r_index <- match(dat$region_id, region_ids)
n_index <- match(dat$industry_id, industry_ids)
share_matrix[cbind(r_index, n_index)] <- dat$share

shock <- industries$shock[match(industry_ids, industries$industry_id)]
z <- drop(share_matrix %*% shock)

weighted_center <- function(v, w) v - sum(w * v)

y0 <- weighted_center(regions$y, e)
x0 <- weighted_center(regions$x, e)
z0 <- weighted_center(z, e)

s <- drop(crossprod(e, share_matrix))
aggregate_residual <- function(v0) {
  drop(crossprod(share_matrix, e * v0)) / s
}

ybar <- aggregate_residual(y0)
xbar <- aggregate_residual(x0)
zbar <- aggregate_residual(z0)

# Weighted IV slope and HC1 standard error using structural residuals.
shock_iv <- function(dependent, endogenous, instrument, weights) {
  X <- cbind(1, endogenous)
  Z <- cbind(1, instrument)
  cross <- crossprod(Z, weights * X)
  beta <- solve(cross, crossprod(Z, weights * dependent))
  residual <- drop(dependent - X %*% beta)
  scores <- Z * (weights * residual)
  inverse <- solve(cross)
  covariance <- (N / (N - 2)) *
    inverse %*% crossprod(scores) %*% t(inverse)
  c(estimate = beta[2], se = sqrt(covariance[2, 2]))
}

effect <- shock_iv(ybar, xbar, shock, s)
first_stage <- shock_iv(xbar, zbar, shock, s)
effective_shocks <- 1 / sum(s^2)

row <- function(term, estimate, se = NULL) {
  list(term = term, estimate = unname(as.numeric(estimate)),
       se = if (is.null(se)) NULL else unname(as.numeric(se)),
       n_obs = as.integer(N))
}

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    row("effect", effect["estimate"], effect["se"]),
    row("first_stage", first_stage["estimate"], first_stage["se"]),
    row("effective_shocks", effective_shocks)
  ),
  method_metadata = list(
    estimator = "Weighted regional 2SLS; equivalent shock-level weighted IV",
    vcov = "Shock-level HC1 with structural IV residuals and analytic weights"
  ),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null",
           digits = 16, pretty = TRUE)
