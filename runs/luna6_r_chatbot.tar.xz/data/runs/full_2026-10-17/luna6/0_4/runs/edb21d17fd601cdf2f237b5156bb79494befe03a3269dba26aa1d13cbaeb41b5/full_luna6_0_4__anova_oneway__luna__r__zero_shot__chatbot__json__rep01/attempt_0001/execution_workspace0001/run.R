data <- read.csv("./input.csv")
data$group <- as.factor(data$group)

fit <- aov(y ~ group, data = data)
tab <- summary(fit)[[1]]

f_stat <- unname(tab["group", "F value"])
df_num <- unname(tab["group", "Df"])
df_den <- unname(tab["Residuals", "Df"])
p_value <- unname(tab["group", "Pr(>F)"])
n_obs <- nrow(data)

estimates <- lapply(
  c(F = f_stat, df_num = df_num, df_den = df_den, p_value = p_value),
  function(value) list(
    term = names(value),
    estimate = unname(value),
    se = NULL,
    n_obs = n_obs
  )
)

result <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = estimates,
  method_metadata = list(estimator = "One-way ANOVA", vcov = "Classical ANOVA"),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = NA, na = "null")
