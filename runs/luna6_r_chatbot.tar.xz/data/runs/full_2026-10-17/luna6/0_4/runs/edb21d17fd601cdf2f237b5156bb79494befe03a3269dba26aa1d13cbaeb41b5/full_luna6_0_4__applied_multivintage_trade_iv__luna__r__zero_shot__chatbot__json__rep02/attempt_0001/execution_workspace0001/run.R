library(jsonlite)

crosswalk <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
trade <- read.csv("trade.csv", stringsAsFactors = FALSE)
areas <- read.csv("areas.csv", stringsAsFactors = FALSE)
employment <- read.csv("employment.csv", stringsAsFactors = FALSE)
outcomes <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

trade <- merge(trade, crosswalk, by = "code", all.x = TRUE, sort = FALSE)

make_exposure <- function(area_data, employment_data, trade_data, area_vintage,
                          trade_change, output_name) {
  selected_areas <- area_data[area_data$vintage == area_vintage, ]
  selected_employment <- employment_data[
    employment_data$vintage == area_vintage, ]

  national <- aggregate(
    employment ~ period + industry,
    data = merge(selected_employment, trade_data[c("period", "industry")],
                 by = c("period", "industry"), all = TRUE),
    FUN = sum
  )
  names(national)[names(national) == "employment"] <- "national_employment"

  cells <- merge(
    selected_areas[c("area", "period", "total_employment")],
    selected_employment[c("area", "period", "industry", "employment")],
    by = c("area", "period"),
    all.x = TRUE
  )
  cells$employment[is.na(cells$employment)] <- 0

  cells <- merge(cells, trade_data, by = c("period", "industry"), all.x = TRUE)
  cells <- merge(cells, national, by = c("period", "industry"), all.x = TRUE)

  cells$component <- (cells$employment / cells$total_employment) *
    (cells[[trade_change]] / cells$national_employment) /
    (cells$price_index / 100) / 1000 * (10 / cells$years)

  exposure <- aggregate(component ~ area + period, data = cells, FUN = sum)
  names(exposure)[names(exposure) == "component"] <- output_name
  exposure
}

base_trade <- unique(trade[c("period", "industry", "us_change",
                             "other_change", "price_index", "years")])
early_trade <- base_trade

x <- make_exposure(areas, employment, base_trade, "base", "us_change", "x")
z <- make_exposure(areas, employment, early_trade, "early", "other_change", "z")

data <- merge(areas[areas$vintage == "base",
                    c("area", "period", "population")],
              outcomes, by = c("area", "period"), all = FALSE)
data <- merge(data, x, by = c("area", "period"), all = FALSE)
data <- merge(data, z, by = c("area", "period"), all = FALSE)

data$period_indicator <- as.numeric(as.character(data$period))
if (anyNA(data$period_indicator)) {
  period_levels <- sort(unique(data$period))
  data$period_indicator <- match(data$period, period_levels) - 1
}

fit <- lm(change_pp ~ period_indicator + control + x,
          data = data, weights = population,
          method = "model.frame")

X <- model.matrix(~ period_indicator + control + x, data = data)
Z <- model.matrix(~ period_indicator + control + z, data = data)
y <- data$change_pp
w <- data$population

A <- crossprod(Z, X * w)
b <- crossprod(Z, y * w)
iv_coef <- solve(A, b)
iv_slope <- unname(iv_coef[which(colnames(X) == "x"), 1])

area0p0 <- x$x[x$area == 0 & x$period == 0]
area0p1 <- x$x[x$area == 0 & x$period == 1]
instrument0p0 <- z$z[z$area == 0 & z$period == 0]

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = list(
    list(term = "iv_slope", estimate = iv_slope, se = NULL, n_obs = 72L),
    list(term = "exposure_area0_period0",
         estimate = unname(area0p0), se = NULL, n_obs = 72L),
    list(term = "exposure_area0_period1",
         estimate = unname(area0p1), se = NULL, n_obs = 72L),
    list(term = "instrument_area0_period0",
         estimate = unname(instrument0p0), se = NULL, n_obs = 72L)
  ),
  method_metadata = list(
    estimator = "weighted_2sls",
    outcome = "change_pp",
    endogenous_regressor = "x",
    instrument = "z",
    exogenous_regressors = c("intercept", "period_indicator", "control"),
    weight = "base-vintage population",
    exposure_units = "thousands of real dollars per worker per decade"
  ),
  diagnostics = list(n_obs = 72L)
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null",
           digits = 16, pretty = TRUE)
