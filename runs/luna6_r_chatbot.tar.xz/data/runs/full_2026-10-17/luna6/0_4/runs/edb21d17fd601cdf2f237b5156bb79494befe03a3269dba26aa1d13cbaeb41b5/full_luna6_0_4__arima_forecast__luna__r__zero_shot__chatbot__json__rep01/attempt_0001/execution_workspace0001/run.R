dat <- read.csv("./input.csv")
if (!"y" %in% names(dat)) stop("input.csv must contain a column named y")
y <- as.numeric(dat$y)
if (length(y) < 3L || anyNA(y) || any(!is.finite(y))) {
  stop("y must contain at least three finite, non-missing observations")
}

fit <- stats::arima(y, order = c(1L, 1L, 1L), include.mean = FALSE,
                    method = "ML")
fc <- predict(fit, n.ahead = 1L)
forecast <- as.numeric(fc$pred[1L])
se <- as.numeric(fc$se[1L])

estimates <- data.frame(
  term = c("forecast", "lower_95", "upper_95"),
  estimate = c(forecast, forecast - qnorm(0.975) * se,
               forecast + qnorm(0.975) * se),
  se = c(se, se, se),
  n_obs = rep(length(y), 3L)
)

result <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = lapply(seq_len(nrow(estimates)), function(i) {
    list(term = estimates$term[i],
         estimate = estimates$estimate[i],
         se = estimates$se[i],
         n_obs = estimates$n_obs[i])
  }),
  method_metadata = list(
    estimator = "Gaussian maximum-likelihood ARIMA(1,1,1), no constant or drift",
    vcov = "Model-based one-step forecast standard error"
  ),
  diagnostics = list()
)

if (requireNamespace("jsonlite", quietly = TRUE)) {
  jsonlite::write_json(result, "result.json", auto_unbox = TRUE,
                       digits = 16, pretty = TRUE, null = "null")
} else {
  estimates_json <- vapply(seq_len(nrow(estimates)), function(i) {
    sprintf('{"term":"%s","estimate":%.16g,"se":%.16g,"n_obs":%d}',
            estimates$term[i], estimates$estimate[i],
            estimates$se[i], estimates$n_obs[i])
  }, character(1))
  json <- paste0(
    '{"task_id":"arima_forecast","platform":"r","estimates":[',
    paste(estimates_json, collapse = ","),
    '],"method_metadata":{"estimator":"Gaussian maximum-likelihood ARIMA(1,1,1), no constant or drift","vcov":"Model-based one-step forecast standard error"},"diagnostics":{}}'
  )
  writeLines(json, "result.json")
}
