library(jsonlite)

crosswalk <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
trade <- read.csv("trade.csv", stringsAsFactors = FALSE)
areas <- read.csv("areas.csv", stringsAsFactors = FALSE)
employment <- read.csv("employment.csv", stringsAsFactors = FALSE)
outcomes <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

trade <- merge(trade, crosswalk, by = "code", all.x = TRUE, sort = FALSE)

stopifnot(
  !anyNA(trade$industry),
  !anyDuplicated(trade[c("period", "industry")]),
  !anyDuplicated(crosswalk$code),
  all(areas$vintage %in% c("base", "early"))
)

industries <- unique(crosswalk$industry)
periods <- unique(areas$period)

make_exposure <- function(area, period, vintage, trade_column) {
  area_rows <- areas[
    areas$area == area & areas$period == period & areas$vintage == vintage,
    ,
    drop = FALSE
  ]
  stopifnot(nrow(area_rows) == 1L)

  period_trade <- trade[trade$period == period, , drop = FALSE]
  stopifnot(nrow(period_trade) == length(industries))

  national_employment <- vapply(industries, function(ind) {
    sum(employment$employment[
      employment$period == period &
        employment$vintage == vintage &
        employment$industry == ind
    ])
  }, numeric(1))

  stopifnot(all(national_employment > 0))

  area_industry_employment <- vapply(industries, function(ind) {
    sum(employment$employment[
      employment$area == area &
        employment$period == period &
        employment$vintage == vintage &
        employment$industry == ind
    ])
  }, numeric(1))

  trade_values <- vapply(industries, function(ind) {
    row <- period_trade[period_trade$industry == ind, , drop = FALSE]
    stopifnot(nrow(row) == 1L)
    row[[trade_column]]
  }, numeric(1))

  period_row <- period_trade[1L, , drop = FALSE]
  sum(
    (area_industry_employment / area_rows$total_employment) *
      (trade_values / national_employment) /
      (period_row$price_index / 100) / 1000 * (10 / period_row$years)
  )
}

key <- function(area, period) paste(area, period, sep = "\r")

area_periods <- unique(areas[c("area", "period")])
area_periods$x <- vapply(seq_len(nrow(area_periods)), function(i) {
  make_exposure(
    area_periods$area[i], area_periods$period[i], "base", "us_change"
  )
}, numeric(1))
area_periods$z <- vapply(seq_len(nrow(area_periods)), function(i) {
  make_exposure(
    area_periods$area[i], area_periods$period[i], "early", "other_change"
  )
}, numeric(1))

base_population <- areas[areas$vintage == "base", c("area", "period", "population")]
stopifnot(!anyDuplicated(base_population[c("area", "period")]))

dat <- merge(outcomes, area_periods, by = c("area", "period"), all = FALSE, sort = FALSE)
dat <- merge(dat, base_population, by = c("area", "period"), all = FALSE, sort = FALSE)
dat$period_factor <- factor(dat$period, levels = periods)

stopifnot(nrow(dat) == 72L, all(is.finite(dat$population)), all(dat$population > 0))

X <- model.matrix(~ period_factor + control + x, data = dat)
Z <- model.matrix(~ period_factor + control + z, data = dat)
sqrt_w <- sqrt(dat$population)
Xw <- X * sqrt_w
Zw <- Z * sqrt_w
yw <- dat$change_pp * sqrt_w

projected_X <- qr.fitted(qr(Zw), Xw)
fit <- lm.fit(projected_X, yw)
stopifnot(length(fit$coefficients) == ncol(X), !anyNA(fit$coefficients))

area0 <- unique(dat$area)[1L]
period0 <- periods[1L]
period1 <- periods[2L]
lookup <- function(a, p, variable) {
  value <- dat[[variable]][dat$area == a & dat$period == p]
  stopifnot(length(value) == 1L)
  as.numeric(value)
}

estimates <- list(
  list(term = "iv_slope", estimate = unname(fit$coefficients[which(colnames(X) == "x")]), se = NULL, n_obs = 72L),
  list(term = "exposure_area0_period0", estimate = lookup(area0, period0, "x"), se = NULL, n_obs = 72L),
  list(term = "exposure_area0_period1", estimate = lookup(area0, period1, "x"), se = NULL, n_obs = 72L),
  list(term = "instrument_area0_period0", estimate = lookup(area0, period0, "z"), se = NULL, n_obs = 72L)
)

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "weighted_2sls",
    outcome = "change_pp",
    endogenous_regressor = "x",
    excluded_instrument = "z",
    exogenous_regressors = c("intercept", "period", "control"),
    weight = "base_vintage_population",
    exposure_units = "thousands_of_real_dollars_per_worker_per_decade",
    outcome_units = "percentage_points_per_decade",
    national_employment_denominator = "sum_across_all_supplied_areas_within_period_and_vintage",
    missing_area_industry_employment = 0
  ),
  diagnostics = list(n_obs = 72L)
)

write_json(result, "result.json", auto_unbox = TRUE, digits = 17, null = "null")
