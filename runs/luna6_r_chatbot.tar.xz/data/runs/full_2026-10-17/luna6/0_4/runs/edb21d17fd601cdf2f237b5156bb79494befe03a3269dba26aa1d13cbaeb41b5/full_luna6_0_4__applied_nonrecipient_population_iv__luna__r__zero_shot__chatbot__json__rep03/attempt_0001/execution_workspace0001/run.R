library(jsonlite)

households <- read.csv("households.csv")
census <- read.csv("census.csv")

retained <- households[households$recipient == 0, , drop = FALSE]
n_obs <- as.integer(nrow(retained))

ineligible <- 1 - retained$eligible
eligible <- retained$eligible

X <- cbind(
  ineligible = ineligible,
  eligible = eligible,
  baseline_ineligible = retained$baseline * ineligible,
  baseline_eligible = retained$baseline * eligible,
  dose_ineligible = retained$dose * ineligible,
  dose_eligible = retained$dose * eligible
)

Z <- cbind(
  ineligible = ineligible,
  eligible = eligible,
  baseline_ineligible = retained$baseline * ineligible,
  baseline_eligible = retained$baseline * eligible,
  instrument_ineligible = retained$instrument * ineligible,
  instrument_eligible = retained$instrument * eligible
)

w <- retained$weight
W_sqrt <- sqrt(w)
Xw <- X * W_sqrt
Zw <- Z * W_sqrt
yw <- retained$outcome * W_sqrt

# Weighted 2SLS: project the weighted regressors and outcome onto the
# weighted instrument space, then estimate the structural coefficients.
Q <- qr.Q(qr(Zw))
X_projected <- Q %*% crossprod(Q, Xw)
y_projected <- Q %*% crossprod(Q, yw)
beta <- solve(crossprod(X_projected), crossprod(X_projected, y_projected))
beta <- as.vector(beta)

dose_mean <- function(group) {
  sum(w[group] * retained$dose[group]) / sum(w[group])
}

ineligible_slope <- beta[5]
eligible_slope <- beta[6]

ineligible_effect <- ineligible_slope * dose_mean(ineligible == 1)
eligible_nonrecipient_effect <- eligible_slope * dose_mean(eligible == 1)

census_ineligible <- census$nonrecipient_population[census$eligible == 0]
census_eligible <- census$nonrecipient_population[census$eligible == 1]
population_effect <- (
  ineligible_effect * census_ineligible +
    eligible_nonrecipient_effect * census_eligible
) / (census_ineligible + census_eligible)

estimates <- list(
  list(term = "ineligible_effect", estimate = as.numeric(ineligible_effect),
       se = NULL, n_obs = n_obs),
  list(term = "eligible_nonrecipient_effect",
       estimate = as.numeric(eligible_nonrecipient_effect),
       se = NULL, n_obs = n_obs),
  list(term = "population_effect", estimate = as.numeric(population_effect),
       se = NULL, n_obs = n_obs)
)

result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "weighted 2SLS",
    sample = "All household rows with recipient equal to zero",
    endogenous_columns = c("dose*(1-eligible)", "dose*eligible"),
    exogenous_columns = c(
      "1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"
    ),
    instrument_columns = c(
      "1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible",
      "instrument*(1-eligible)", "instrument*eligible"
    ),
    regression_weight = "weight",
    group_effect = "Fitted dose slope times the household-weighted mean dose in that group",
    counterfactual = "Dose set to zero for every retained household",
    attribution_convention = "Attribution to the zero-dose counterfactual is a stated synthetic convention",
    population_aggregation = "Census nonrecipient_population used only for final between-group weighting"
  ),
  diagnostics = list(
    n_obs = n_obs,
    n_obs_definition = "Number of retained nonrecipient household rows used in estimation",
    ineligible_group_rows = as.integer(sum(ineligible == 1)),
    eligible_group_rows = as.integer(sum(eligible == 1))
  )
)

write_json(result, "result.json", auto_unbox = TRUE, digits = 17, pretty = TRUE, null = "null")
