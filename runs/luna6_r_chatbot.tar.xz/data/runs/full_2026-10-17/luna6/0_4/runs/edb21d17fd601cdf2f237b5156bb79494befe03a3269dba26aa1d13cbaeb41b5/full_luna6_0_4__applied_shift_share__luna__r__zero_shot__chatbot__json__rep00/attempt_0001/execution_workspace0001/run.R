library(AER)
library(sandwich)
library(jsonlite)

d <- read.csv("input.csv", stringsAsFactors = FALSE)

# Keep one row per region for regional variables and weight normalization.
regions <- d[!duplicated(d$region_id), c("region_id", "region_weight", "x", "y")]
regions$e <- regions$region_weight / sum(regions$region_weight)

# Baseline shares and shocks are defined at the region-industry and industry levels.
shares <- aggregate(share ~ region_id + industry_id, data = d, FUN = sum)
shocks <- aggregate(shock ~ industry_id, data = d, FUN = function(v) {
  if (length(unique(v)) != 1L) stop("shock must be constant within industry")
  v[1L]
})
shares <- merge(shares, shocks, by = "industry_id", sort = FALSE)
regions <- merge(regions, shares, by = "region_id", sort = FALSE)
regions$exposure <- regions$share * regions$shock

z <- aggregate(exposure ~ region_id, data = regions, FUN = sum)
names(z)[2L] <- "z"
regions <- merge(regions, z, by = "region_id", sort = FALSE)

weighted_mean <- function(v, w) sum(w * v) / sum(w)
my <- weighted_mean(regions$y, regions$e)
mx <- weighted_mean(regions$x, regions$e)
mz <- weighted_mean(regions$z, regions$e)
regions$y0 <- regions$y - my
regions$x0 <- regions$x - mx
regions$z0 <- regions$z - mz

regions$weighted_share <- regions$e * regions$share
shock_level <- aggregate(
  cbind(weighted_share, y_num = weighted_share * y0,
        x_num = weighted_share * x0, z_num = weighted_share * z0) ~ industry_id,
  data = regions, FUN = sum
)
names(shock_level)[names(shock_level) == "weighted_share"] <- "s"
shock_level <- merge(shock_level, shocks, by = "industry_id", sort = FALSE)
shock_level$ybar <- shock_level$y_num / shock_level$s
shock_level$xbar <- shock_level$x_num / shock_level$s
shock_level$zbar <- shock_level$z_num / shock_level$s
N <- nrow(shock_level)

# Shock-level IV with analytic weights. HC1 uses N/(N-2).
effect_fit <- AER::ivreg(ybar ~ xbar | shock, data = shock_level, weights = s)
effect_vcov <- sandwich::vcovHC(effect_fit, type = "HC1") * ((N - 2) / N)
effect_estimate <- unname(coef(effect_fit)["xbar"])
effect_se <- sqrt(unname(effect_vcov["xbar", "xbar"]))

first_fit <- AER::ivreg(xbar ~ zbar | shock, data = shock_level, weights = s)
first_vcov <- sandwich::vcovHC(first_fit, type = "HC1") * ((N - 2) / N)
first_estimate <- unname(coef(first_fit)["zbar"])
first_se <- sqrt(unname(first_vcov["zbar", "zbar"]))

effective_shocks <- 1 / sum(shock_level$s^2)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = effect_estimate, se = effect_se, n_obs = N),
    list(term = "first_stage", estimate = first_estimate, se = first_se, n_obs = N),
    list(term = "effective_shocks", estimate = effective_shocks, se = NULL, n_obs = N)
  ),
  method_metadata = list(
    estimator = "Borusyak-Hull-Jaravel shock-level weighted 2SLS",
    vcov = "Shock-level heteroskedasticity-robust HC1, analytic weights, multiplier N/(N-2)"
  ),
  diagnostics = list()
)
write_json(result, "result.json", auto_unbox = TRUE, digits = 16, null = "null")
