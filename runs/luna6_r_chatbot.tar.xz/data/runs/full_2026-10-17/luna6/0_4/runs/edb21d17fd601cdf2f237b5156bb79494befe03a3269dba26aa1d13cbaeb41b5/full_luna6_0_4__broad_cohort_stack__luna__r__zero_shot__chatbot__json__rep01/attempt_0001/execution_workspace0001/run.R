library(jsonlite)

data <- read.csv("input.csv")

fit_cohort <- function(cohort) {
  window_times <- (cohort - 2):(cohort + 2)

  eligible <- data[
    data$g == cohort | data$g == 0 | data$g > cohort + 2,
    ,
    drop = FALSE
  ]

  observed_times <- split(eligible$time, eligible$id)
  balanced_ids <- names(Filter(
    function(times) all(window_times %in% times),
    observed_times
  ))

  comparison <- eligible[
    eligible$id %in% balanced_ids & eligible$time %in% window_times,
    ,
    drop = FALSE
  ]

  comparison$did <- as.integer(
    comparison$g == cohort & comparison$time >= cohort
  )

  estimate <- unname(coef(lm(
    y ~ did + factor(id) + factor(time),
    data = comparison
  ))["did"])

  treated_units <- length(unique(
    comparison$id[comparison$g == cohort]
  ))

  list(
    estimate = estimate,
    n_obs = nrow(comparison),
    treated_units = treated_units
  )
}

results <- lapply(c(3, 5, 7), fit_cohort)
names(results) <- c("att_g3", "att_g5", "att_g7")

weighted_estimate <- weighted.mean(
  vapply(results, `[[`, numeric(1), "estimate"),
  vapply(results, `[[`, numeric(1), "treated_units")
)

estimates <- lapply(names(results), function(term) {
  list(
    term = term,
    estimate = unname(results[[term]]$estimate),
    se = NULL,
    n_obs = results[[term]]$n_obs
  )
})

estimates[[4]] <- list(
  term = "att_weighted",
  estimate = unname(weighted_estimate),
  se = NULL,
  n_obs = sum(vapply(results, `[[`, integer(1), "n_obs"))
)

output <- list(
  task_id = "broad_cohort_stack",
  platform = "r",
  estimates = estimates,
  method_metadata = list(),
  diagnostics = list()
)

write_json(output, "result.json", auto_unbox = TRUE, digits = 16, null = "null")
