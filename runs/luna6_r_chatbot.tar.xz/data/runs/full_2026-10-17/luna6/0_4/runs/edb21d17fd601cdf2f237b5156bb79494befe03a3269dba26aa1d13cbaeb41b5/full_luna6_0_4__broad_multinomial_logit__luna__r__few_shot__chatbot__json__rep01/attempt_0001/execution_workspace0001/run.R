d <- read.csv("input.csv")
d$y <- factor(d$y, levels = c(0, 1, 2))

fit <- nnet::multinom(
  y ~ x + z,
  data = d,
  Hess = TRUE,
  trace = FALSE,
  maxit = 1000,
  reltol = 1e-12,
  abstol = 1e-12
)

B <- coef(fit)
V <- vcov(fit)
n <- nrow(d)

indices <- c(0, B["1", "(Intercept)"], B["2", "(Intercept)"])
p <- exp(indices - max(indices))
p <- p / sum(p)

rows <- list(
  list(term = "x_cat1", estimate = unname(B["1", "x"]), se = sqrt(V["1:x", "1:x"]), n_obs = n),
  list(term = "z_cat1", estimate = unname(B["1", "z"]), se = sqrt(V["1:z", "1:z"]), n_obs = n),
  list(term = "x_cat2", estimate = unname(B["2", "x"]), se = sqrt(V["2:x", "2:x"]), n_obs = n),
  list(term = "z_cat2", estimate = unname(B["2", "z"]), se = sqrt(V["2:z", "2:z"]), n_obs = n),
  list(term = "prob_cat2_zero", estimate = unname(p[3]), se = NULL, n_obs = n)
)

jsonlite::write_json(
  list(
    task_id = "broad_multinomial_logit",
    platform = "r",
    estimates = rows,
    method_metadata = list(
      estimator = "Maximum likelihood multinomial logit",
      vcov = "Conventional observed-information covariance matrix"
    ),
    diagnostics = list()
  ),
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
