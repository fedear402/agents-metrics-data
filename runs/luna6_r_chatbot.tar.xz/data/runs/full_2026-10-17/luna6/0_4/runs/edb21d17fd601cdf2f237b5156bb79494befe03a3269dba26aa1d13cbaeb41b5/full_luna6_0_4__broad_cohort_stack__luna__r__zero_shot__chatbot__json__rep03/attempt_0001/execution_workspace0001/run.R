library(jsonlite)

data <- read.csv("input.csv")

cohorts <- c(3, 5, 7)
terms <- c("att_g3", "att_g5", "att_g7")
expected_n_obs <- c(375, 275, 315)

estimates <- numeric(length(cohorts))
n_obs <- integer(length(cohorts))
n_treated <- integer(length(cohorts))

for (i in seq_along(cohorts)) {
  c <- cohorts[i]
  window_times <- (c - 2):(c + 2)

  comparison <- data[
    data$time %in% window_times &
      (data$g == c | data$g == 0 | data$g > c + 2),
    ,
    drop = FALSE
  ]

  counts <- table(comparison$id)
  balanced_ids <- names(counts[counts == length(window_times)])
  comparison <- comparison[comparison$id %in% balanced_ids, , drop = FALSE]

  comparison$did <- as.integer(comparison$g == c & comparison$time >= c)

  fit <- lm(y ~ did + factor(id) + factor(time), data = comparison)
  estimates[i] <- unname(coef(fit)["did"])
  n_obs[i] <- nrow(comparison)
  n_treated[i] <- length(unique(comparison$id[comparison$g == c]))
}

stopifnot(identical(as.integer(n_obs), expected_n_obs))

weighted_estimate <- weighted.mean(estimates, w = n_treated)

results <- data.frame(
  term = c(terms, "att_weighted"),
  estimate = c(estimates, weighted_estimate),
  se = rep(list(NULL), 4),
  n_obs = c(n_obs, sum(n_obs))
)

output <- list(
  task_id = "broad_cohort_stack",
  platform = "r",
  estimates = lapply(seq_len(nrow(results)), function(i) {
    list(
      term = results$term[i],
      estimate = results$estimate[i],
      se = NULL,
      n_obs = results$n_obs[i]
    )
  }),
  method_metadata = list(),
  diagnostics = list()
)

write_json(output, "result.json", auto_unbox = TRUE, digits = 17, pretty = TRUE)
