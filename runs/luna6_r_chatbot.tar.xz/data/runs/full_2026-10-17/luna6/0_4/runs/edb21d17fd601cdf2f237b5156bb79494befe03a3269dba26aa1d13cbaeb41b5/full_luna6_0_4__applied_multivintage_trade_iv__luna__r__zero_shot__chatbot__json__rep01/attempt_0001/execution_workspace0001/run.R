library(jsonlite)

crosswalk <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
trade <- read.csv("trade.csv", stringsAsFactors = FALSE)
areas <- read.csv("areas.csv", stringsAsFactors = FALSE)
employment <- read.csv("employment.csv", stringsAsFactors = FALSE)
outcomes <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

trade <- merge(trade, crosswalk, by = "code", all.x = TRUE, sort = FALSE)

make_exposures <- function(vintage, change_column) {
  area_data <- areas[areas$vintage == vintage, ]
  area_data <- merge(
    area_data,
    employment[employment$vintage == vintage, c("area", "period", "industry", "employment")],
    by = c("area", "period"),
    all.x = TRUE,
    sort = FALSE
  )
  area_data$employment[is.na(area_data$employment)] <- 0

  national <- aggregate(
    employment ~ period + industry,
    data = area_data,
    FUN = sum
  )
  names(national)[names(national) == "employment"] <- "national_employment"

  trade_subset <- trade[, c("period", "industry", change_column, "price_index", "years")]
  names(trade_subset)[names(trade_subset) == change_column] <- "trade_change"

  industry_data <- merge(
    national, trade_subset,
    by = c("period", "industry"),
    all = FALSE,
    sort = FALSE
  )
  industry_data$component <- industry_data$trade_change /
    industry_data$national_employment /
    (industry_data$price_index / 100) / 1000 *
    (10 / industry_data$years)

  area_data <- merge(
    area_data,
    industry_data[, c("period", "industry", "component")],
    by = c("period", "industry"),
    all.x = TRUE,
    sort = FALSE
  )
  area_data$component[is.na(area_data$component)] <- 0

  area_industry <- aggregate(
    cbind(employment, component) ~ area + period + total_employment,
    data = transform(area_data,
      weighted_component = employment * component
    ),
    FUN = sum
  )

  # Recompute the employment-weighted sum by area and period.
  area_data$weighted_component <- area_data$employment * area_data$component
  weighted <- aggregate(
    weighted_component ~ area + period,
    data = area_data,
    FUN = sum
  )
  denominators <- unique(area_data[, c("area", "period", "total_employment")])
  result <- merge(weighted, denominators, by = c("area", "period"))
  result$exposure <- result$weighted_component / result$total_employment
  result[, c("area", "period", "exposure")]
}

base_x <- make_exposures("base", "us_change")
early_z <- make_exposures("early", "other_change")
names(base_x)[names(base_x) == "exposure"] <- "x"
names(early_z)[names(early_z) == "exposure"] <- "z"

dat <- merge(outcomes, base_x, by = c("area", "period"))
dat <- merge(dat, early_z, by = c("area", "period"))
dat$period_indicator <- as.numeric(dat$period == sort(unique(dat$period))[2])

fit <- lm(
  change_pp ~ period_indicator + control + x,
  data = dat,
  weights = merge(
    areas[areas$vintage == "base", c("area", "period", "population")],
    dat[, c("area", "period")],
    by = c("area", "period")
  )$population
)

iv_fit <- AER::ivreg(
  change_pp ~ period_indicator + control + x |
    period_indicator + control + z,
  data = dat,
  weights = merge(
    areas[areas$vintage == "base", c("area", "period", "population")],
    dat[, c("area", "period")],
    by = c("area", "period")
  )$population
)

area0_p0_x <- dat$x[dat$area == 0 & dat$period == sort(unique(dat$period))[1]]
area0_p1_x <- dat$x[dat$area == 0 & dat$period == sort(unique(dat$period))[2]]
area0_p0_z <- dat$z[dat$area == 0 & dat$period == sort(unique(dat$period))[1]]

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = list(
    list(term = "iv_slope", estimate = unname(coef(iv_fit)["x"]), se = NULL),
    list(term = "exposure_area0_period0", estimate = unname(area0_p0_x), se = NULL),
    list(term = "exposure_area0_period1", estimate = unname(area0_p1_x), se = NULL),
    list(term = "instrument_area0_period0", estimate = unname(area0_p0_z), se = NULL)
  ),
  method_metadata = list(
    estimator = "Weighted two-stage least squares",
    outcome = "change_pp",
    endogenous_regressor = "x",
    instrument = "z",
    exogenous_regressors = c("intercept", "period_indicator", "control"),
    weight = "base-vintage population",
    exposure_units = "thousands of real dollars per worker per decade",
    interval_scaling = "10 / years",
    missing_area_industry_employment = 0L
  ),
  diagnostics = list(
    n_obs = 72L,
    area_period_observations = 72L
  )
)

write_json(result, "result.json", auto_unbox = TRUE, digits = 17, na = "null")
