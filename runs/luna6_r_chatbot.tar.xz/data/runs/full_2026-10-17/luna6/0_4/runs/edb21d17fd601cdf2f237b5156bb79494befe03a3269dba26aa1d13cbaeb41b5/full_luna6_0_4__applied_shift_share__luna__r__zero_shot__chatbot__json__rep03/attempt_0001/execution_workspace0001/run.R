d <- read.csv("input.csv", stringsAsFactors = FALSE)

# Keep one row per region for regional variables and weights.
regions <- d[!duplicated(d$region_id), c("region_id", "region_weight", "x", "y")]
e <- regions$region_weight / sum(regions$region_weight)

# Construct the regional shift-share instrument from all region-industry rows.
z_by_region <- aggregate(
  share * shock ~ region_id,
  data = d,
  FUN = sum
)
names(z_by_region)[2] <- "z"
regions <- merge(regions, z_by_region, by = "region_id", sort = FALSE)

# Reorder weights to match the merged regional data.
regions <- regions[match(unique(d$region_id), regions$region_id), ]
e <- regions$region_weight / sum(regions$region_weight)

weighted_mean <- function(v, w) sum(w * v) / sum(w)
y0 <- regions$y - weighted_mean(regions$y, e)
x0 <- regions$x - weighted_mean(regions$x, e)
z0 <- regions$z - weighted_mean(regions$z, e)

# Aggregate weighted residuals to the industry shock level.
industry <- sort(unique(d$industry_id))
shock_by_industry <- aggregate(shock ~ industry_id, data = d, FUN = function(v) v[1])
shock_by_industry <- shock_by_industry[match(industry, shock_by_industry$industry_id), ]

industry_rows <- lapply(industry, function(n) {
  rows <- d$industry_id == n
  region_index <- match(d$region_id[rows], regions$region_id)
  a <- e[region_index] * d$share[rows]
  s <- sum(a)
  data.frame(
    industry_id = n,
    s = s,
    ybar = sum(a * y0[region_index]) / s,
    xbar = sum(a * x0[region_index]) / s,
    zbar = sum(a * z0[region_index]) / s
  )
})
agg <- do.call(rbind, industry_rows)
agg <- merge(agg, shock_by_industry, by = "industry_id", sort = FALSE)
agg <- agg[match(industry, agg$industry_id), ]
N <- nrow(agg)

# Weighted shock-level IV slope and HC1 analytic-weight sandwich SE.
iv_hc1 <- function(y, endogenous, instrument, weights) {
  D <- cbind(1, endogenous)
  Z <- cbind(1, instrument)
  W <- diag(weights)
  A <- solve(crossprod(Z, W %*% D))
  beta <- A %*% crossprod(Z, W %*% y)
  resid <- as.vector(y - D %*% beta)

  # Structural IV meat, with analytic weights and no clustering.
  score <- Z * as.vector(weights * resid)
  meat <- crossprod(score)
  bread <- solve(crossprod(D, W %*% Z)) %*%
    crossprod(Z, W %*% D) %*%
    solve(crossprod(Z, W %*% D))
  # Equivalent sandwich in the structural-regressor parameterization.
  V <- bread %*% meat %*% t(bread)
  V <- V * N / (N - 2)
  list(beta = as.vector(beta), se = sqrt(diag(V)))
}

effect_fit <- iv_hc1(agg$ybar, agg$xbar, agg$shock, agg$s)
first_fit <- iv_hc1(agg$xbar, agg$zbar, agg$shock, agg$s)

effective_shocks <- 1 / sum(agg$s^2)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = effect_fit$beta[2], se = effect_fit$se[2], n_obs = N),
    list(term = "first_stage", estimate = first_fit$beta[2], se = first_fit$se[2], n_obs = N),
    list(term = "effective_shocks", estimate = effective_shocks, se = NULL, n_obs = N)
  ),
  method_metadata = list(
    estimator = "Borusyak-Hull-Jaravel shock-level weighted IV with analytic weights",
    vcov = "Shock-level HC1 sandwich, structural IV residuals, multiplier N/(N-2), no clustering"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = 15, null = "null")
