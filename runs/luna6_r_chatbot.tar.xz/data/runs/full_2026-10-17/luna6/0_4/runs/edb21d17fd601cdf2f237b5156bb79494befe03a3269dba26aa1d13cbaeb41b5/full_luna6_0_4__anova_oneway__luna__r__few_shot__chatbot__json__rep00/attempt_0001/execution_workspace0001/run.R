library(jsonlite)

data <- read.csv("./input.csv")
data <- data[complete.cases(data[, c("group", "y")]), ]
fit <- aov(y ~ factor(group), data = data)
tab <- summary(fit)[[1]]

f_stat <- unname(tab[1, "F value"])
df_num <- unname(tab[1, "Df"])
df_den <- unname(tab[2, "Df"])
p_value <- unname(tab[1, "Pr(>F)"])
n_obs <- nrow(data)

out <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = list(
    list(term = "F", estimate = f_stat, se = NULL, n_obs = n_obs),
    list(term = "df_num", estimate = df_num, se = NULL, n_obs = n_obs),
    list(term = "df_den", estimate = df_den, se = NULL, n_obs = n_obs),
    list(term = "p_value", estimate = p_value, se = NULL, n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "One-way ANOVA",
    vcov = "Classical ANOVA"
  ),
  diagnostics = list()
)

write_json(out, "./result.json", auto_unbox = TRUE, na = "null", digits = 15)
