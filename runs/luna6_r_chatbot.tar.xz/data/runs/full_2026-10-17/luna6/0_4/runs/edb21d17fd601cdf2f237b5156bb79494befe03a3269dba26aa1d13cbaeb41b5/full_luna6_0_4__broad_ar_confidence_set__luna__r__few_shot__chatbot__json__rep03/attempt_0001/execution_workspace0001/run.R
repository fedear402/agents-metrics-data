d <- read.csv("input.csv")
n <- nrow(d)
q <- 2L
df <- n - 4L
critical <- qf(0.95, df1 = q, df2 = df)

# Partial out the intercept and x from each variable.
resid_on_controls <- function(v) {
  residuals(lm(v ~ x, data = d))
}

ry <- resid_on_controls(d$y)
rd <- resid_on_controls(d$endog)
rz1 <- resid_on_controls(d$z1)
rz2 <- resid_on_controls(d$z2)

Z <- cbind(rz1, rz2)
project_resid <- function(v) {
  as.vector(Z %*% qr.solve(Z, v))
}

uy <- ry - project_resid(ry)
ud <- rd - project_resid(rd)

# The restricted-minus-unrestricted SSR inequality is quadratic in beta.
k <- q * critical / df
A <- sum(rd^2) - (1 + k) * sum(ud^2)
B <- -2 * (sum(ry * rd) - (1 + k) * sum(uy * ud))
C <- sum(ry^2) - (1 + k) * sum(uy^2)

disc <- B^2 - 4 * A * C
if (abs(A) < 1e-12 || disc < 0) {
  stop("The confidence set does not have two finite boundary points.")
}
bounds <- sort(c((-B - sqrt(disc)) / (2 * A),
                 (-B + sqrt(disc)) / (2 * A)))

accepts <- function(beta) A * beta^2 + B * beta + C <= 0
unbounded <- as.integer(A < 0)

ar_f <- function(beta) {
  v <- ry - beta * rd
  u <- v - project_resid(v)
  ssr_restricted <- sum(v^2)
  ssr_unrestricted <- sum(u^2)
  ((ssr_restricted - ssr_unrestricted) / q) / (ssr_unrestricted / df)
}

rows <- list(
  list(term = "boundary_low", estimate = unname(bounds[1]), se = NULL, n_obs = n),
  list(term = "boundary_high", estimate = unname(bounds[2]), se = NULL, n_obs = n),
  list(term = "accepts_zero", estimate = as.integer(accepts(0)), se = NULL, n_obs = n),
  list(term = "unbounded", estimate = unbounded, se = NULL, n_obs = n),
  list(term = "ar_f_at_one", estimate = unname(ar_f(1)), se = NULL, n_obs = n)
)

jsonlite::write_json(
  list(
    task_id = "broad_ar_confidence_set",
    platform = "r",
    estimates = rows,
    method_metadata = list(
      estimator = "Anderson-Rubin confidence set by inversion of the homoskedastic joint F test",
      vcov = "Conventional homoskedastic"
    ),
    diagnostics = list()
  ),
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
