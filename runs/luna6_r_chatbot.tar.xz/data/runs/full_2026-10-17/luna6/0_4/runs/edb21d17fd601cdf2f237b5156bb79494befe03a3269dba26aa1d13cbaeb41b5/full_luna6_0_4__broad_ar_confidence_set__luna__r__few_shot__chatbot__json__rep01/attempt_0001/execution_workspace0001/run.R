d <- read.csv("input.csv")

n <- nrow(d)
q <- 2L
df <- n - 4L
critical <- qf(0.95, q, df)
k <- q * critical / df

# Residualize on the included regressors: intercept and x.
W <- model.matrix(~ x, data = d)
resid_on_W <- function(v) qr.resid(qr(W), v)

ry <- resid_on_W(d$y)
rd <- resid_on_W(d$endog)
Z <- cbind(resid_on_W(d$z1), resid_on_W(d$z2))

# Restricted and unrestricted sums of squares for y - beta * endog.
# The unrestricted fit adds both excluded instruments.
ssr <- function(v) {
  u <- resid_on_W(v)
  sum(u^2)
}
ssr_unrestricted <- function(v) {
  u <- resid_on_W(v)
  fit <- lm.fit(x = cbind(W, d$z1, d$z2), y = v)
  sum(fit$residuals^2)
}

# The AR acceptance inequality is quadratic in beta.
A <- sum(rd^2) - (1 + k) * sum(qr.resid(qr(cbind(W, d$z1, d$z2)), d$endog)^2)
B <- -2 * (sum(ry * rd) -
             (1 + k) * sum(qr.resid(qr(cbind(W, d$z1, d$z2)), d$y) *
                             qr.resid(qr(cbind(W, d$z1, d$z2)), d$endog)))
C <- sum(ry^2) -
  (1 + k) * sum(qr.resid(qr(cbind(W, d$z1, d$z2)), d$y)^2)

disc <- B^2 - 4 * A * C
if (!is.finite(disc) || disc < 0 || abs(A) < .Machine$double.eps) {
  stop("The data do not yield two finite AR boundaries.")
}

bounds <- sort(c((-B - sqrt(disc)) / (2 * A),
                 (-B + sqrt(disc)) / (2 * A)))

accepts <- function(beta) A * beta^2 + B * beta + C <= 0
unbounded <- as.integer(A < 0)

v1 <- d$y - d$endog
ssr_r1 <- ssr(v1)
ssr_u1 <- ssr_unrestricted(v1)
ar_f_at_one <- ((ssr_r1 - ssr_u1) / q) / (ssr_u1 / df)

rows <- list(
  list(term = "boundary_low", estimate = unname(bounds[1]), se = NULL, n_obs = n),
  list(term = "boundary_high", estimate = unname(bounds[2]), se = NULL, n_obs = n),
  list(term = "accepts_zero", estimate = unname(as.integer(accepts(0))), se = NULL, n_obs = n),
  list(term = "unbounded", estimate = unname(unbounded), se = NULL, n_obs = n),
  list(term = "ar_f_at_one", estimate = unname(ar_f_at_one), se = NULL, n_obs = n)
)

jsonlite::write_json(
  list(
    task_id = "broad_ar_confidence_set",
    platform = "r",
    estimates = rows,
    method_metadata = list(
      estimator = "Anderson-Rubin confidence set by inversion of the homoskedastic joint F test",
      vcov = "Conventional homoskedastic"
    ),
    diagnostics = list()
  ),
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
