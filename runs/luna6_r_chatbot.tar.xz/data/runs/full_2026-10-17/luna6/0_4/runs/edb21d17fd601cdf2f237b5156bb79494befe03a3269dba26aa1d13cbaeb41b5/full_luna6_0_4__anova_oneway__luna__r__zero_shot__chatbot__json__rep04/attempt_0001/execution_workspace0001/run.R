data <- read.csv("./input.csv")

fit <- aov(y ~ group, data = data)
tab <- summary(fit)[[1]]

f_stat <- unname(tab[["F value"]][1])
df_num <- unname(tab[["Df"]][1])
df_den <- unname(tab[["Df"]][2])
p_value <- unname(tab[["Pr(>F)"]][1])
n_obs <- nrow(data)

result <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = list(
    list(term = "F", estimate = f_stat, se = NULL, n_obs = n_obs),
    list(term = "df_num", estimate = df_num, se = NULL, n_obs = n_obs),
    list(term = "df_den", estimate = df_den, se = NULL, n_obs = n_obs),
    list(term = "p_value", estimate = p_value, se = NULL, n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "One-way ANOVA",
    vcov = "Classical ANOVA"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = NA, na = "null")
