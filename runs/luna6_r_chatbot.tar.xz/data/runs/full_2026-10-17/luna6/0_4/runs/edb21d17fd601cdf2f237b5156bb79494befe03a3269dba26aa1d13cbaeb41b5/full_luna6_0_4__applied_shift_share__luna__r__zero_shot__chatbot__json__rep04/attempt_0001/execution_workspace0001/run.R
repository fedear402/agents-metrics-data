d <- read.csv("input.csv", stringsAsFactors = FALSE)

# Reduce the region-industry data to one row per region, checking repeated values.
region_cols <- c("region_weight", "x", "y")
regions <- unique(d[c("region_id", region_cols)])
if (anyDuplicated(regions$region_id)) stop("Region-level values vary within region.")

# Normalize regional weights once, using one observation per region.
regions$e <- regions$region_weight / sum(regions$region_weight)

# Shares and shocks are defined at the region-industry and industry levels.
if (anyDuplicated(d[c("region_id", "industry_id")])) stop("Duplicate region-industry rows.")
industry_shocks <- unique(d[c("industry_id", "shock")])
if (anyDuplicated(industry_shocks$industry_id)) stop("Shock varies within industry.")

d$share <- as.numeric(d$share)
d$shock <- as.numeric(d$shock)
regions <- merge(regions, unique(d[c("region_id", "industry_id", "share")]),
                 by = "region_id", sort = FALSE)
regions <- merge(regions, industry_shocks, by = "industry_id", sort = FALSE)

# Construct the regional shift-share instrument.
z <- aggregate(share * shock ~ region_id, data = regions, sum)
names(z)[2] <- "z"
regions <- merge(regions, z, by = "region_id", sort = FALSE)
regions <- regions[!duplicated(regions$region_id), ]

weighted_mean <- function(v, w) sum(w * v) / sum(w)
regions$y0 <- regions$y - weighted_mean(regions$y, regions$e)
regions$x0 <- regions$x - weighted_mean(regions$x, regions$e)
regions$z0 <- regions$z - weighted_mean(regions$z, regions$e)

# Aggregate demeaned regional variables to industry exposures.
agg <- merge(
  unique(regions[c("region_id", "e", "y0", "x0", "z0")]),
  unique(d[c("region_id", "industry_id", "share")]),
  by = "region_id", sort = FALSE
)
agg$es <- agg$e * agg$share
industry <- aggregate(
  cbind(es, es_y = es * agg$y0, es_x = es * agg$x0, es_z = es * agg$z0) ~ industry_id,
  data = agg, sum
)
names(industry)[names(industry) == "es"] <- "s"
industry <- merge(industry, industry_shocks, by = "industry_id", sort = FALSE)
industry$ybar <- industry$es_y / industry$s
industry$xbar <- industry$es_x / industry$s
industry$zbar <- industry$es_z / industry$s

N <- nrow(industry)
if (N <= 2) stop("At least three industries are required for HC1.")

# Shock-level weighted IV slope and analytic-weight HC1 standard error.
iv_hc1 <- function(data, outcome, endogenous, instrument, weights) {
  y <- data[[outcome]]
  x <- data[[endogenous]]
  q <- data[[instrument]]
  w <- data[[weights]]

  # Weighted 2SLS with an intercept and one excluded instrument.
  X <- cbind(1, x)
  Z <- cbind(1, q)
  WZ <- Z * w
  bread <- solve(crossprod(X, WZ) %*% solve(crossprod(Z, WZ), crossprod(WZ, X)))
  beta <- bread %*% crossprod(X, WZ) %*%
    solve(crossprod(Z, WZ), crossprod(WZ, y))
  residual <- as.vector(y - X %*% beta)

  # HC1 sandwich for structural IV residuals and analytic weights.
  A <- crossprod(X, WZ) %*% solve(crossprod(Z, WZ), crossprod(WZ, X))
  Ainv <- solve(A)
  score_design <- X * as.vector(w * residual)
  meat <- crossprod(score_design)
  V <- (N / (N - 2)) * Ainv %*% meat %*% t(Ainv)
  c(estimate = beta[2], se = sqrt(V[2, 2]))
}

effect <- iv_hc1(industry, "ybar", "xbar", "shock", "s")
first_stage <- iv_hc1(industry, "xbar", "zbar", "shock", "s")
effective_shocks <- 1 / sum(industry$s^2)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = unname(effect["estimate"]),
         se = unname(effect["se"]), n_obs = as.integer(N)),
    list(term = "first_stage", estimate = unname(first_stage["estimate"]),
         se = unname(first_stage["se"]), n_obs = as.integer(N)),
    list(term = "effective_shocks", estimate = effective_shocks,
         se = NULL, n_obs = as.integer(N))
  ),
  method_metadata = list(
    estimator = "Borusyak-Hull-Jaravel shock-level weighted 2SLS",
    vcov = "Shock-level HC1 sandwich with analytic weights; multiplier N/(N-2)"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = 15, na = "null")
