library(jsonlite)

dat <- read.csv("input.csv")
inside <- abs(dat$score) < 1
d <- dat[inside, ]
n <- nrow(d)

right <- as.numeric(d$score >= 0)
x_left <- d$score * (1 - right)
x_right <- d$score * right
w <- 1 - abs(d$score)
X <- cbind(left_intercept = 1 - right,
           left_slope = x_left,
           right_intercept = right,
           right_slope = x_right)

bread <- solve(crossprod(X, w * X))
Y <- cbind(earnings = d$earnings, participation = d$participated)
coef <- bread %*% crossprod(X, w * Y)
resid <- Y - X %*% coef

# Right limit minus left limit.
contrast <- c(-1, 0, 1, 0)
jumps <- drop(contrast %*% coef)

loading <- w * drop(X %*% bread %*% contrast)
influence <- loading * resid
joint_vcov <- crossprod(influence)
jump_se <- sqrt(diag(joint_vcov))

ratio <- jumps[1] / jumps[2]
gradient <- c(1 / jumps[2], -jumps[1] / jumps[2]^2)
ratio_se <- sqrt(drop(t(gradient) %*% joint_vcov %*% gradient))

row <- function(term, estimate, se) {
  list(term = term, estimate = unname(as.numeric(estimate)),
       se = unname(as.numeric(se)), n_obs = as.integer(n))
}

write_json(
  list(
    task_id = "applied_fuzzy_rd",
    platform = "r",
    estimates = list(
      row("treatment_effect", ratio, ratio_se),
      row("reduced_form", jumps[1], jump_se[1]),
      row("first_stage", jumps[2], jump_se[2])
    ),
    method_metadata = list(
      estimator = "triangular-weighted local-linear fuzzy regression discontinuity",
      vcov = "HC0, fixed bandwidth and weights, joint covariance for delta method"
    ),
    diagnostics = list()
  ),
  "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE
)
