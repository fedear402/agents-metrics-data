data <- read.csv("input.csv", stringsAsFactors = FALSE)
data$date <- as.Date(data$date)
data <- data[order(data$date), ]

log_vix <- log(data$vix)
delta_log_vix <- c(NA_real_, diff(log_vix))
log_sales <- log(data$sales)

n <- nrow(data)
lag_matrix <- sapply(1:15, function(k) {
  c(rep(NA_real_, k), delta_log_vix[seq_len(n - k)])
})
colnames(lag_matrix) <- paste0("lag_", 1:15)

reg_data <- data.frame(log_sales = log_sales, lag_matrix)
reg_data <- reg_data[complete.cases(reg_data), ]

fit <- lm(log_sales ~ ., data = reg_data)
X <- model.matrix(fit)
u <- residuals(fit)
N <- nrow(X)

bread <- solve(crossprod(X))
meat <- matrix(0, ncol(X), ncol(X))
for (j in 0:15) {
  weight <- if (j == 0) 1 else 1 - j / 16
  if (j == 0) {
    meat <- meat + crossprod(X, X * u^2)
  } else {
    left <- (j + 1):N
    right <- 1:(N - j)
    score_left <- X[left, , drop = FALSE] * u[left]
    score_right <- X[right, , drop = FALSE] * u[right]
    cross <- crossprod(score_left, score_right)
    meat <- meat + weight * (cross + t(cross))
  }
}

vcov_nw <- (N / (N - 16)) * bread %*% meat %*% bread
coef_fit <- coef(fit)
names(coef_fit) <- colnames(X)

cumulative_estimate <- sum(coef_fit[paste0("lag_", 1:15)])
cumulative_vector <- rep(0, length(coef_fit))
names(cumulative_vector) <- names(coef_fit)
cumulative_vector[paste0("lag_", 1:15)] <- 1
cumulative_se <- sqrt(drop(t(cumulative_vector) %*% vcov_nw %*% cumulative_vector))

estimates <- list(
  list(term = "cumulative_response", estimate = unname(cumulative_estimate),
       se = unname(cumulative_se), n_obs = as.integer(N)),
  list(term = "lag_1", estimate = unname(coef_fit["lag_1"]),
       se = unname(sqrt(vcov_nw["lag_1", "lag_1"])), n_obs = as.integer(N)),
  list(term = "lag_15", estimate = unname(coef_fit["lag_15"]),
       se = unname(sqrt(vcov_nw["lag_15", "lag_15"])), n_obs = as.integer(N))
)

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "OLS of log(sales) on intercept and lags 1 through 15 of first-differenced log(vix)",
    vcov = "Newey-West HAC with maximum lag 15, Bartlett weights 1-j/16, and N/(N-16) correction"
  ),
  diagnostics = list()
)

if (!requireNamespace("jsonlite", quietly = TRUE)) {
  stop("Package jsonlite is required to write result.json")
}
jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = 16, pretty = TRUE)
