dat <- read.csv("input.csv", stringsAsFactors = FALSE)

required <- c("region_id", "industry_id", "share", "shock",
              "region_weight", "x", "y")
if (!all(required %in% names(dat))) stop("Required columns are missing.")

# Keep one row per region for regional weights and outcomes.
region_cols <- c("region_id", "region_weight", "x", "y")
regions <- unique(dat[region_cols])
if (anyDuplicated(regions$region_id)) stop("Regional values vary within region.")

regions$e <- regions$region_weight / sum(regions$region_weight)

# Construct one exposure and one shock value per region-industry pair.
pairs <- unique(dat[c("region_id", "industry_id", "share", "shock")])
if (anyDuplicated(pairs[c("region_id", "industry_id")])) {
  stop("Shares or shocks vary within a region-industry pair.")
}

# Center regional variables using normalized regional weights.
weighted_mean <- function(v, w) sum(w * v) / sum(w)
regions$y0 <- regions$y - weighted_mean(regions$y, regions$e)
regions$x0 <- regions$x - weighted_mean(regions$x, regions$e)

z_by_region <- aggregate(
  pairs$share * pairs$shock,
  by = list(region_id = pairs$region_id),
  FUN = sum
)
names(z_by_region)[2] <- "z"
regions <- merge(regions, z_by_region, by = "region_id", all.x = TRUE,
                 sort = FALSE)
regions$z0 <- regions$z - weighted_mean(regions$z, regions$e)

# Aggregate centered regional variables to industry level.
p <- merge(pairs, regions[c("region_id", "e", "y0", "x0", "z0")],
           by = "region_id", all.x = TRUE, sort = FALSE)
p$weighted_share <- p$e * p$share

industry <- aggregate(
  cbind(weighted_share,
        weighted_y = p$weighted_share * p$y0,
        weighted_x = p$weighted_share * p$x0,
        weighted_z = p$weighted_share * p$z0),
  by = list(industry_id = p$industry_id, shock = p$shock),
  FUN = sum
)
names(industry)[3:6] <- c("s", "sum_y", "sum_x", "sum_z")
if (any(industry$s <= 0)) stop("Every industry must have positive exposure.")

industry$ybar <- industry$sum_y / industry$s
industry$xbar <- industry$sum_x / industry$s
industry$zbar <- industry$sum_z / industry$s

# Weighted IV coefficient and structural residual HC1 variance.
iv_hc1 <- function(outcome, endogenous, instrument, weights) {
  N <- length(outcome)
  if (N <= 2) stop("At least three industries are required.")

  X <- cbind(intercept = 1, endogenous = endogenous)
  Z <- cbind(intercept = 1, instrument = instrument)
  W <- diag(weights)
  bread <- solve(t(X) %*% W %*% Z %*%
                   solve(t(Z) %*% W %*% Z) %*% t(Z) %*% W %*% X)
  beta <- bread %*% (t(X) %*% W %*% Z %*%
                       solve(t(Z) %*% W %*% Z) %*% t(Z) %*% W %*% outcome)
  residual <- as.vector(outcome - X %*% beta)

  # HC1 sandwich for analytic-weighted IV, with structural IV residuals.
  meat <- t(X) %*% Z %*% solve(t(Z) %*% W %*% Z) %*%
    t(Z) %*% diag((weights * residual)^2) %*% Z %*%
    solve(t(Z) %*% W %*% Z) %*% t(Z) %*% X
  vcov <- (N / (N - 2)) * bread %*% meat %*% bread
  list(beta = as.vector(beta), se = sqrt(diag(vcov)))
}

effect_fit <- iv_hc1(industry$ybar, industry$xbar,
                     industry$shock, industry$s)
first_fit <- iv_hc1(industry$xbar, industry$zbar,
                    industry$shock, industry$s)

N <- nrow(industry)
effective_shocks <- 1 / sum(industry$s^2)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = effect_fit$beta[2],
         se = effect_fit$se[2], n_obs = N),
    list(term = "first_stage", estimate = first_fit$beta[2],
         se = first_fit$se[2], n_obs = N),
    list(term = "effective_shocks", estimate = effective_shocks,
         se = NULL, n_obs = N)
  ),
  method_metadata = list(
    estimator = "Weighted regional 2SLS; equivalent shock-level weighted IV",
    vcov = "Shock-level analytic-weight HC1 sandwich, structural IV residuals, no clustering"
  ),
  diagnostics = list()
)

if (!requireNamespace("jsonlite", quietly = TRUE)) {
  stop("Package jsonlite is required to write result.json.")
}
jsonlite::write_json(result, "result.json", auto_unbox = TRUE,
                     digits = 16, na = "null")
