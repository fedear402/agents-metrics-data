dat <- read.csv("input.csv")
n <- nrow(dat)
critical <- qf(0.95, df1 = 2, df2 = n - 4)

# The joint instrument test is a quadratic function of beta. Evaluate it
# from the restricted and unrestricted residual sums of squares.
fit_full <- lm(y ~ x + z1 + z2, data = dat)
rss_full <- sum(residuals(fit_full)^2)

ar_f <- function(beta) {
  fit_restricted <- lm(I(y - beta * endog) ~ x, data = dat)
  rss_restricted <- sum(residuals(fit_restricted)^2)
  ((rss_restricted - rss_full) / 2) / (rss_full / (n - 4))
}

# Obtain the quadratic coefficients from evaluations at three points.
f0 <- ar_f(0)
f1 <- ar_f(1)
fm1 <- ar_f(-1)
a <- (f1 + fm1 - 2 * f0) / 2
b <- (f1 - fm1) / 2
c <- f0 - critical

roots <- sort(polyroot(c(c, b, a)))
roots <- Re(roots[abs(Im(roots)) < 1e-8])
boundary_low <- roots[1]
boundary_high <- roots[length(roots)]

out <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = list(
    list(term = "boundary_low", estimate = unname(boundary_low), se = NULL, n_obs = n),
    list(term = "boundary_high", estimate = unname(boundary_high), se = NULL, n_obs = n),
    list(term = "accepts_zero", estimate = as.numeric(ar_f(0) <= critical), se = NULL, n_obs = n),
    list(term = "unbounded", estimate = 0, se = NULL, n_obs = n),
    list(term = "ar_f_at_one", estimate = unname(ar_f(1)), se = NULL, n_obs = n)
  ),
  method_metadata = list(
    estimator = "Anderson-Rubin confidence set by inversion of the conventional homoskedastic joint F test for z1 and z2",
    vcov = "Conventional homoskedastic"
  ),
  diagnostics = list()
)

jsonlite::write_json(out, "result.json", auto_unbox = TRUE, digits = 15, null = "null")
