households <- read.csv("households.csv")
census <- read.csv("census.csv")

d <- subset(households, recipient == 0)
g <- d$eligible
w <- d$weight

# Build the group-specific regressors and instruments. The two group indicators
# supply the intercepts, so no additional intercept is included.
X <- cbind(
  ineligible = 1 - g,
  eligible = g,
  baseline_ineligible = d$baseline * (1 - g),
  baseline_eligible = d$baseline * g,
  dose_ineligible = d$dose * (1 - g),
  dose_eligible = d$dose * g
)

Z <- cbind(
  ineligible = 1 - g,
  eligible = g,
  baseline_ineligible = d$baseline * (1 - g),
  baseline_eligible = d$baseline * g,
  instrument_ineligible = d$instrument * (1 - g),
  instrument_eligible = d$instrument * g
)

# Weighted 2SLS using the supplied observation weights.
sqrt_w <- sqrt(w)
Xw <- X * sqrt_w
Zw <- Z * sqrt_w
yw <- d$outcome * sqrt_w

projected_X <- qr.fitted(qr(Zw), Xw)
beta <- qr.coef(qr(projected_X), crossprod(projected_X, yw))
names(beta) <- colnames(X)

ineligible_mean_dose <- weighted.mean(d$dose[g == 0], w[g == 0])
eligible_mean_dose <- weighted.mean(d$dose[g == 1], w[g == 1])

ineligible_effect <- unname(beta["dose_ineligible"] * ineligible_mean_dose)
eligible_nonrecipient_effect <- unname(beta["dose_eligible"] * eligible_mean_dose)

population_counts <- census$nonrecipient_population[
  match(c(0, 1), census$eligible)
]
population_effect <- weighted.mean(
  c(ineligible_effect, eligible_nonrecipient_effect),
  population_counts
)

n_obs <- as.integer(nrow(d))
estimates <- list(
  list(term = "ineligible_effect", estimate = ineligible_effect,
       se = NULL, n_obs = n_obs),
  list(term = "eligible_nonrecipient_effect", estimate = eligible_nonrecipient_effect,
       se = NULL, n_obs = n_obs),
  list(term = "population_effect", estimate = population_effect,
       se = NULL, n_obs = n_obs)
)

result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    method = "Weighted 2SLS",
    sample = "All household rows with recipient equal to zero",
    endogenous_columns = c(
      "dose*(1-eligible)",
      "dose*eligible"
    ),
    exogenous_columns = c(
      "1-eligible",
      "eligible",
      "baseline*(1-eligible)",
      "baseline*eligible"
    ),
    instruments = c(
      "1-eligible",
      "eligible",
      "baseline*(1-eligible)",
      "baseline*eligible",
      "instrument*(1-eligible)",
      "instrument*eligible"
    ),
    group_effect = "Fitted dose slope multiplied by the household-weighted mean dose in that group",
    population_aggregation = "Census nonrecipient_population counts determine between-group weights",
    counterfactual = "Dose set to zero for every retained household",
    attribution_convention = "Synthetic convention"
  ),
  diagnostics = list(
    n_obs = n_obs,
    n_ineligible = as.integer(sum(g == 0)),
    n_eligible = as.integer(sum(g == 1))
  )
)

jsonlite::write_json(
  result,
  path = "result.json",
  auto_unbox = TRUE,
  digits = 16,
  null = "null",
  pretty = TRUE
)
