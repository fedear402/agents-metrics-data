data <- read.csv("./input.csv")

if (!"y" %in% names(data)) {
  stop("input.csv must contain a column named y")
}

y <- data$y
if (!is.numeric(y) || anyNA(y) || length(y) < 3L) {
  stop("y must be numeric, complete, and contain at least three observations")
}

fit <- stats::arima(
  y,
  order = c(1L, 1L, 1L),
  include.mean = FALSE,
  method = "ML"
)

pred <- predict(fit, n.ahead = 1L)
forecast <- as.numeric(pred$pred[1L])
se <- as.numeric(pred$se[1L])

result <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = list(
    list(term = "forecast", estimate = forecast, se = se, n_obs = length(y)),
    list(term = "lower_95", estimate = forecast - stats::qnorm(0.975) * se, se = NULL, n_obs = length(y)),
    list(term = "upper_95", estimate = forecast + stats::qnorm(0.975) * se, se = NULL, n_obs = length(y))
  ),
  method_metadata = list(
    estimator = "ARIMA(1,1,1) maximum likelihood, no constant or drift",
    vcov = "Model-based one-step forecast variance"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = NA, null = "null")
