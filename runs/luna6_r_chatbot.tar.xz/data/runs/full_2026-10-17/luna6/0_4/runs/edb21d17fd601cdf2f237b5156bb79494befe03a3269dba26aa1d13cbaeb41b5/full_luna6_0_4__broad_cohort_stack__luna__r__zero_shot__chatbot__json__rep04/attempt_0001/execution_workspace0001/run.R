library(jsonlite)

dat <- read.csv("./input.csv")

cohorts <- c(3L, 5L, 7L)
terms <- c("att_g3", "att_g5", "att_g7")
estimates <- numeric(length(cohorts))
row_counts <- c(375L, 275L, 315L)
treated_counts <- integer(length(cohorts))

for (i in seq_along(cohorts)) {
  c <- cohorts[i]
  window_times <- (c - 2L):(c + 2L)

  eligible_ids <- unique(dat$id[
    dat$g == c | dat$g == 0 | dat$g > c + 2L
  ])
  comparison <- dat[
    dat$id %in% eligible_ids & dat$time %in% window_times,
    ,
    drop = FALSE
  ]

  observed_times <- table(comparison$id)
  balanced_ids <- names(observed_times)[observed_times == length(window_times)]
  comparison <- comparison[comparison$id %in% balanced_ids, , drop = FALSE]

  comparison$did <- as.integer(comparison$g == c & comparison$time >= c)
  fit <- lm(y ~ did + factor(id) + factor(time), data = comparison)
  estimates[i] <- unname(coef(fit)[["did"]])
  treated_counts[i] <- length(unique(comparison$id[comparison$g == c]))
}

weighted_estimate <- weighted.mean(estimates, treated_counts)

result <- list(
  task_id = "broad_cohort_stack",
  platform = "r",
  estimates = list(
    list(term = "att_g3", estimate = estimates[1], se = NULL, n_obs = row_counts[1]),
    list(term = "att_g5", estimate = estimates[2], se = NULL, n_obs = row_counts[2]),
    list(term = "att_g7", estimate = estimates[3], se = NULL, n_obs = row_counts[3]),
    list(term = "att_weighted", estimate = weighted_estimate, se = NULL,
         n_obs = sum(row_counts))
  ),
  method_metadata = list(),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, digits = 17, null = "null")
