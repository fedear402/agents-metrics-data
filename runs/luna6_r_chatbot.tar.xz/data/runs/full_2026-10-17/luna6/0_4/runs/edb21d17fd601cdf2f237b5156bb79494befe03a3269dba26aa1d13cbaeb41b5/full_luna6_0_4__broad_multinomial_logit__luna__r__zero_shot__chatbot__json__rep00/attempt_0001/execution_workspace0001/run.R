dat <- read.csv("input.csv")
fit <- nnet::multinom(y ~ x + z, data = dat, trace = FALSE)
V <- vcov(fit)
b <- coef(fit)
n <- nrow(dat)

terms <- c("x_cat1", "z_cat1", "x_cat2", "z_cat2")
coef_names <- c("x", "z", "x", "z")
categories <- c(1, 1, 2, 2)

estimates <- lapply(seq_along(terms), function(i) {
  category <- as.character(categories[i])
  coefficient <- coef_names[i]
  key <- paste(category, coefficient, sep = ":")
  list(
    term = terms[i],
    estimate = unname(b[category, coefficient]),
    se = sqrt(unname(V[key, key])),
    n_obs = as.integer(n)
  )
})

eta <- c(1, 2) * 0
eta <- c(
  unname(b["1", "(Intercept)"]),
  unname(b["2", "(Intercept)"])
)
prob_cat2_zero <- exp(eta[2]) / (1 + sum(exp(eta)))

estimates[[5]] <- list(
  term = "prob_cat2_zero",
  estimate = unname(prob_cat2_zero),
  se = NULL,
  n_obs = as.integer(n)
)

result <- list(
  task_id = "broad_multinomial_logit",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "Maximum likelihood multinomial logit",
    vcov = "Conventional observed-information covariance matrix"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = 15, null = "null")
