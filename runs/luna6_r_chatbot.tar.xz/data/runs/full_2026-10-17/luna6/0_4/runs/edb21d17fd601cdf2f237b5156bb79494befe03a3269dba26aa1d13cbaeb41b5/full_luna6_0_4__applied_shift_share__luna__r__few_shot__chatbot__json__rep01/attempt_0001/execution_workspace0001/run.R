library(jsonlite)

d <- read.csv("input.csv")

# Use one row per region to define normalized regional weights and regional outcomes.
regions <- unique(d[c("region_id", "region_weight", "x", "y")])
regions <- regions[order(regions$region_id), ]
regions$e <- regions$region_weight / sum(regions$region_weight)

industries <- unique(d[c("industry_id", "shock")])
industries <- industries[order(industries$industry_id), ]

shares <- xtabs(share ~ region_id + industry_id, data = d)
shares <- shares[as.character(regions$region_id), as.character(industries$industry_id),
                 drop = FALSE]

z <- drop(shares %*% industries$shock)
e <- regions$e
x <- regions$x
y <- regions$y

weighted_center <- function(v) v - sum(e * v)
x0 <- weighted_center(x)
y0 <- weighted_center(y)
z0 <- weighted_center(z)

mass <- drop(crossprod(e, shares))
aggregate_residual <- function(v0) {
  drop(crossprod(shares, e * v0)) / mass
}
xbar <- aggregate_residual(x0)
ybar <- aggregate_residual(y0)
zbar <- aggregate_residual(z0)

N <- length(industries$shock)
stopifnot(N > 2L, all(mass > 0))

# Just-identified shock-level IV with an intercept and analytic weights.
shock_iv <- function(dependent, endogenous, instrument) {
  q <- cbind(1, instrument)
  r <- cbind(1, endogenous)
  cross <- crossprod(q, mass * r)
  beta <- solve(cross, crossprod(q, mass * dependent))
  residual <- drop(dependent - r %*% beta)
  scores <- q * (mass * residual)
  inverse <- solve(cross)
  vcov <- (N / (N - 2)) * inverse %*% crossprod(scores) %*% t(inverse)
  c(estimate = beta[2], se = sqrt(vcov[2, 2]))
}

effect <- shock_iv(ybar, xbar, industries$shock)
first_stage <- shock_iv(xbar, zbar, industries$shock)

# Check that the shock-level slopes equal their regional weighted counterparts.
regional_effect <- sum(e * z0 * y0) / sum(e * z0 * x0)
regional_first_stage <- sum(e * z0 * x0) / sum(e * z0^2)
stopifnot(
  abs(effect["estimate"] - regional_effect) < 1e-8,
  abs(first_stage["estimate"] - regional_first_stage) < 1e-8
)

rows <- list(
  list(term = "effect", estimate = unname(as.numeric(effect["estimate"])),
       se = unname(as.numeric(effect["se"])), n_obs = as.integer(N)),
  list(term = "first_stage", estimate = unname(as.numeric(first_stage["estimate"])),
       se = unname(as.numeric(first_stage["se"])), n_obs = as.integer(N)),
  list(term = "effective_shocks", estimate = unname(1 / sum(mass^2)),
       se = NULL, n_obs = as.integer(N))
)

write_json(
  list(
    task_id = "applied_shift_share",
    platform = "r",
    estimates = rows,
    method_metadata = list(
      estimator = "Regional weighted 2SLS with Borusyak-Hull-Jaravel shock-level IV aggregation",
      vcov = "Shock-level heteroskedasticity-robust HC1 with structural IV residuals and analytic weights"
    ),
    diagnostics = list()
  ),
  "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE
)
