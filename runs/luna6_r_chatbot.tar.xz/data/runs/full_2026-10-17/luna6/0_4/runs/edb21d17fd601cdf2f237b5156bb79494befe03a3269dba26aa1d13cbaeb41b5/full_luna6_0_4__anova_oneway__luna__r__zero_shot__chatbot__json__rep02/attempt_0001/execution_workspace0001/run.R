data <- read.csv("./input.csv")
data$group <- as.factor(data$group)

fit <- aov(y ~ group, data = data)
anova_table <- summary(fit)[[1]]

f_stat <- anova_table["group", "F value"]
df_num <- anova_table["group", "Df"]
df_den <- anova_table["Residuals", "Df"]
p_value <- anova_table["group", "Pr(>F)"]
n_obs <- sum(complete.cases(data[, c("y", "group")]))

estimates <- data.frame(
  term = c("F", "df_num", "df_den", "p_value"),
  estimate = c(f_stat, df_num, df_den, p_value),
  se = rep(NA_real_, 4),
  n_obs = rep(n_obs, 4)
)

result <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = lapply(seq_len(nrow(estimates)), function(i) {
    list(
      term = estimates$term[i],
      estimate = unname(estimates$estimate[i]),
      se = NULL,
      n_obs = as.integer(estimates$n_obs[i])
    )
  }),
  method_metadata = list(
    estimator = "One-way ANOVA",
    vcov = "Classical ANOVA"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = 15, na = "null")
