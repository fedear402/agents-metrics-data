library(jsonlite)

data <- read.csv("input.csv", stringsAsFactors = FALSE)
data$date <- as.Date(data$date)
data <- data[order(data$date), ]

log_vix <- log(data$vix)
log_sales <- log(data$sales)
change <- c(NA_real_, diff(log_vix))

n <- nrow(data)
lag_matrix <- sapply(1:15, function(j) {
  c(rep(NA_real_, j), change[seq_len(n - j)])
})
colnames(lag_matrix) <- paste0("lag_", 1:15)

complete <- complete.cases(log_sales, lag_matrix)
y <- log_sales[complete]
X <- cbind(intercept = 1, lag_matrix[complete, , drop = FALSE])
N <- nrow(X)

fit <- lm.fit(x = X, y = y)
beta <- fit$coefficients
residuals <- fit$residuals

scores <- X * residuals
meat <- crossprod(scores)
for (j in 1:15) {
  lag_product <- crossprod(
    scores[(j + 1):N, , drop = FALSE],
    scores[1:(N - j), , drop = FALSE]
  )
  meat <- meat + (1 - j / 16) * (lag_product + t(lag_product))
}

bread <- solve(crossprod(X))
covariance <- (N / (N - 16)) * bread %*% meat %*% bread

contrast <- c(0, rep(1, 15))
cumulative <- sum(contrast * beta)
cumulative_se <- sqrt(drop(t(contrast) %*% covariance %*% contrast))

estimates <- list(
  list(term = "cumulative_response", estimate = unname(cumulative),
       se = unname(cumulative_se), n_obs = as.integer(N)),
  list(term = "lag_1", estimate = unname(beta[2]),
       se = unname(sqrt(covariance[2, 2])), n_obs = as.integer(N)),
  list(term = "lag_15", estimate = unname(beta[16]),
       se = unname(sqrt(covariance[16, 16])), n_obs = as.integer(N))
)

write_json(
  list(
    task_id = "applied_cumulative_hac",
    platform = "r",
    estimates = estimates,
    method_metadata = list(
      estimator = "OLS with 15 lagged log-volatility changes",
      vcov = "Newey-West HAC, Bartlett maximum lag 15, N/(N-16) correction"
    ),
    diagnostics = list()
  ),
  "result.json",
  auto_unbox = TRUE,
  digits = 16,
  pretty = TRUE
)
