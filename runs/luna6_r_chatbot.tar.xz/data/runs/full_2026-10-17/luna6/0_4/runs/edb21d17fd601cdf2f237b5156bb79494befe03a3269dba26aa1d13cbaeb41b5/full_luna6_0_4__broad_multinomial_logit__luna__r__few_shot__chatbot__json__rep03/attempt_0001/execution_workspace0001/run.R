d <- read.csv("input.csv")

stopifnot(all(c("y", "x", "z") %in% names(d)))
stopifnot(all(d$y %in% 0:2))
n <- nrow(d)

if (!requireNamespace("nnet", quietly = TRUE) ||
    !requireNamespace("jsonlite", quietly = TRUE)) {
  stop("Packages nnet and jsonlite are required.")
}

d$y <- factor(d$y, levels = 0:2)
fit <- nnet::multinom(
  y ~ x + z, data = d, Hess = TRUE, trace = FALSE,
  maxit = 1000, reltol = 1e-12, abstol = 1e-12
)

B <- coef(fit)
V <- vcov(fit)

# Rows of B are outcome labels; covariance names use outcome:term.
get_estimate <- function(outcome, term) unname(B[outcome, term])
get_se <- function(outcome, term) {
  sqrt(V[paste0(outcome, ":", term), paste0(outcome, ":", term)])
}

indices <- c(0, unname(B[, "(Intercept)"]))
probabilities <- exp(indices - max(indices))
probabilities <- probabilities / sum(probabilities)

rows <- list(
  list(term = "x_cat1", estimate = get_estimate("1", "x"), se = get_se("1", "x"), n_obs = n),
  list(term = "z_cat1", estimate = get_estimate("1", "z"), se = get_se("1", "z"), n_obs = n),
  list(term = "x_cat2", estimate = get_estimate("2", "x"), se = get_se("2", "x"), n_obs = n),
  list(term = "z_cat2", estimate = get_estimate("2", "z"), se = get_se("2", "z"), n_obs = n),
  list(term = "prob_cat2_zero", estimate = unname(probabilities[3]), se = NULL, n_obs = n)
)

jsonlite::write_json(
  list(
    task_id = "broad_multinomial_logit",
    platform = "r",
    estimates = rows,
    method_metadata = list(
      estimator = "Multinomial logit maximum likelihood",
      vcov = "Conventional observed-information covariance from the likelihood Hessian"
    ),
    diagnostics = list()
  ),
  "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE
)
