library(jsonlite)

crosswalk <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
trade <- read.csv("trade.csv", stringsAsFactors = FALSE)
areas <- read.csv("areas.csv", stringsAsFactors = FALSE)
employment <- read.csv("employment.csv", stringsAsFactors = FALSE)
outcomes <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

trade <- merge(trade, crosswalk, by = "code", all.x = TRUE, sort = FALSE)

if (anyNA(trade$industry)) {
  stop("Every trade code must map to an industry.")
}

national_employment <- aggregate(
  employment ~ period + vintage + industry,
  data = employment,
  FUN = sum
)

base_area <- areas[areas$vintage == "base", ]
early_area <- areas[areas$vintage == "early", ]

base_cells <- merge(
  base_area,
  employment[employment$vintage == "base", c("area", "period", "industry", "employment")],
  by = c("area", "period"),
  all.x = TRUE,
  sort = FALSE
)
base_cells$employment[is.na(base_cells$employment)] <- 0

early_cells <- merge(
  early_area,
  employment[employment$vintage == "early", c("area", "period", "industry", "employment")],
  by = c("area", "period"),
  all.x = TRUE,
  sort = FALSE
)
early_cells$employment[is.na(early_cells$employment)] <- 0

build_exposure <- function(area_cells, vintage, trade_amount) {
  national <- national_employment[national_employment$vintage == vintage, ]
  trade_values <- trade[, c("period", "industry", trade_amount, "price_index", "years")]
  names(trade_values)[names(trade_values) == trade_amount] <- "trade_change"

  d <- merge(
    area_cells,
    national[, c("period", "industry", "employment")],
    by = c("period", "industry"),
    all.x = TRUE,
    sort = FALSE,
    suffixes = c("_area", "_national")
  )
  d <- merge(d, trade_values, by = c("period", "industry"), all.x = TRUE, sort = FALSE)

  d$component <- (d$employment_area / d$total_employment) *
    (d$trade_change / d$employment_national) /
    (d$price_index / 100) / 1000 * (10 / d$years)

  aggregate(component ~ area + period, data = d, FUN = sum)
}

x <- build_exposure(base_cells, "base", "us_change")
z <- build_exposure(early_cells, "early", "other_change")
names(x)[names(x) == "component"] <- "x"
names(z)[names(z) == "component"] <- "z"

dat <- merge(outcomes, base_area[, c("area", "period", "population")],
             by = c("area", "period"), all = FALSE, sort = FALSE)
dat <- merge(dat, x, by = c("area", "period"), all = FALSE, sort = FALSE)
dat <- merge(dat, z, by = c("area", "period"), all = FALSE, sort = FALSE)

dat$period_indicator <- as.integer(dat$period == sort(unique(dat$period))[2])

if (nrow(dat) != 72L) {
  stop("Expected exactly 72 area-period estimation rows.")
}

fit <- lm(
  change_pp ~ period_indicator + control + x,
  data = dat,
  weights = population,
  na.action = na.fail
)

iv_fit <- AER::ivreg(
  change_pp ~ period_indicator + control + x |
    period_indicator + control + z,
  data = dat,
  weights = population
)

area0_values <- dat[dat$area == 0, ]
periods <- sort(unique(dat$period))
x0p0 <- area0_values$x[area0_values$period == periods[1]]
x0p1 <- area0_values$x[area0_values$period == periods[2]]
z0p0 <- area0_values$z[area0_values$period == periods[1]]

if (length(x0p0) != 1L || length(x0p1) != 1L || length(z0p0) != 1L) {
  stop("Area 0 must have one observation in each of the two periods.")
}

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = list(
    list(term = "iv_slope", estimate = unname(coef(iv_fit)["x"]), se = NULL),
    list(term = "exposure_area0_period0", estimate = unname(x0p0), se = NULL),
    list(term = "exposure_area0_period1", estimate = unname(x0p1), se = NULL),
    list(term = "instrument_area0_period0", estimate = unname(z0p0), se = NULL)
  ),
  method_metadata = list(
    estimator = "weighted_2sls",
    formula = "change_pp ~ period + control + x; instrument x with z and include all exogenous regressors as instruments",
    exposure_units = "thousands of real dollars per worker per decade",
    regression_weight = "base-vintage population",
    missing_area_industry_employment = 0
  ),
  diagnostics = list(
    n_obs = 72L,
    sample_count = nrow(dat)
  )
)

write_json(result, "result.json", auto_unbox = TRUE, digits = 17, null = "null")
