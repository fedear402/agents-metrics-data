library(jsonlite)

data <- read.csv("input.csv", stringsAsFactors = FALSE)
data$date <- as.Date(data$date)
data <- data[order(data$date), ]

log_vix <- log(data$vix)
vol_change <- c(NA_real_, diff(log_vix))
log_sales <- log(data$sales)

n <- nrow(data)
max_lag <- 15L
usable <- (max_lag + 2L):n

reg_data <- data.frame(log_sales = log_sales[usable])
for (j in seq_len(max_lag)) {
  reg_data[[paste0("lag_", j)]] <- vol_change[usable - j]
}
fit <- lm(log_sales ~ ., data = reg_data)

X <- model.matrix(fit)
residuals <- residuals(fit)
N <- nrow(X)
p <- ncol(X)
scores <- X * residuals

meat <- crossprod(scores)
for (j in seq_len(max_lag)) {
  lag_product <- crossprod(
    scores[(j + 1L):N, , drop = FALSE],
    scores[1L:(N - j), , drop = FALSE]
  )
  weight <- 1 - j / 16
  meat <- meat + weight * (lag_product + t(lag_product))
}

bread <- solve(crossprod(X))
covariance <- (N / (N - 16)) * bread %*% meat %*% bread
coefficients <- coef(fit)
contrast <- c(0, rep(1, max_lag))

rows <- list(
  list(
    term = "cumulative_response",
    estimate = unname(sum(contrast * coefficients)),
    se = unname(sqrt(drop(t(contrast) %*% covariance %*% contrast))),
    n_obs = as.integer(N)
  ),
  list(
    term = "lag_1",
    estimate = unname(coefficients["lag_1"]),
    se = unname(sqrt(covariance["lag_1", "lag_1"])),
    n_obs = as.integer(N)
  ),
  list(
    term = "lag_15",
    estimate = unname(coefficients["lag_15"]),
    se = unname(sqrt(covariance["lag_15", "lag_15"])),
    n_obs = as.integer(N)
  )
)

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = rows,
  method_metadata = list(
    estimator = "OLS with intercept and 15 lags of log volatility changes",
    vcov = "Newey-West HAC, Bartlett maximum lag 15, scaled by N/(N-16)"
  ),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
