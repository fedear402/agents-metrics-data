# Run with: Rscript estimate.R
data <- read.csv("input.csv", stringsAsFactors = FALSE)
data$date <- as.Date(data$date)
data <- data[order(data$date), ]

data$log_sales <- log(data$sales)
data$delta_log_vix <- c(NA_real_, diff(log(data$vix)))

for (j in 1:15) {
  data[[paste0("lag_", j)]] <- c(rep(NA_real_, j), head(data$delta_log_vix, -j))
}

lag_names <- paste0("lag_", 1:15)
sample_data <- data[complete.cases(data[, c("log_sales", lag_names)]), ]
n <- nrow(sample_data)

fit <- lm(reformulate(lag_names, response = "log_sales"), data = sample_data)
X <- model.matrix(fit)
u <- residuals(fit)
bread <- solve(crossprod(X))
scores <- X * as.vector(u)

# Bartlett Newey-West covariance, with maximum lag 15.
meat <- crossprod(scores)
for (j in 1:15) {
  weight <- 1 - j / 16
  gamma <- crossprod(scores[(j + 1):n, , drop = FALSE],
                     scores[1:(n - j), , drop = FALSE])
  meat <- meat + weight * (gamma + t(gamma))
}
vcov_nw <- bread %*% meat %*% bread * n / (n - 16)

coefs <- coef(fit)
cum_weights <- rep(0, length(coefs))
names(cum_weights) <- names(coefs)
cum_weights[lag_names] <- 1

estimates <- list(
  list(term = "cumulative_response",
       estimate = unname(sum(coefs[lag_names])),
       se = unname(sqrt(drop(t(cum_weights) %*% vcov_nw %*% cum_weights))),
       n_obs = as.integer(n)),
  list(term = "lag_1",
       estimate = unname(coefs["lag_1"]),
       se = unname(sqrt(vcov_nw["lag_1", "lag_1"])),
       n_obs = as.integer(n)),
  list(term = "lag_15",
       estimate = unname(coefs["lag_15"]),
       se = unname(sqrt(vcov_nw["lag_15", "lag_15"])),
       n_obs = as.integer(n))
)

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "OLS of log sales on intercept and lags 1 through 15 of first-differenced log VIX",
    vcov = "Newey-West HAC, Bartlett weights, maximum lag 15, multiplied by N/(N-16)"
  ),
  diagnostics = list()
)

if (!requireNamespace("jsonlite", quietly = TRUE)) {
  stop("Package jsonlite is required to write result.json")
}
jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = 15, na = "null")
