households <- read.csv("households.csv")
census <- read.csv("census.csv")

d <- subset(households, recipient == 0)
n_obs <- nrow(d)

eligible <- d$eligible
dose_ineligible <- d$dose * (1 - eligible)
dose_eligible <- d$dose * eligible

X <- cbind(
  ineligible = 1 - eligible,
  eligible = eligible,
  baseline_ineligible = d$baseline * (1 - eligible),
  baseline_eligible = d$baseline * eligible,
  dose_ineligible = dose_ineligible,
  dose_eligible = dose_eligible
)

Z <- cbind(
  ineligible = 1 - eligible,
  eligible = eligible,
  baseline_ineligible = d$baseline * (1 - eligible),
  baseline_eligible = d$baseline * eligible,
  instrument_ineligible = d$instrument * (1 - eligible),
  instrument_eligible = d$instrument * eligible
)

sqrt_weight <- sqrt(d$weight)
Xw <- X * sqrt_weight
Zw <- Z * sqrt_weight
yw <- d$outcome * sqrt_weight

projected_X <- qr.fitted(qr(Zw), Xw)
coefficients <- qr.coef(qr(projected_X), yw)
slope_ineligible <- unname(coefficients["dose_ineligible"])
slope_eligible <- unname(coefficients["dose_eligible"])

mean_dose_ineligible <- weighted.mean(
  d$dose[eligible == 0],
  d$weight[eligible == 0]
)
mean_dose_eligible <- weighted.mean(
  d$dose[eligible == 1],
  d$weight[eligible == 1]
)

ineligible_effect <- slope_ineligible * mean_dose_ineligible
eligible_nonrecipient_effect <- slope_eligible * mean_dose_eligible

population_weights <- census$nonrecipient_population[
  match(c(0, 1), census$eligible)
]
population_effect <- weighted.mean(
  c(ineligible_effect, eligible_nonrecipient_effect),
  population_weights
)

estimates <- list(
  list(term = "ineligible_effect", estimate = ineligible_effect, se = NULL, n_obs = n_obs),
  list(term = "eligible_nonrecipient_effect", estimate = eligible_nonrecipient_effect, se = NULL, n_obs = n_obs),
  list(term = "population_effect", estimate = population_effect, se = NULL, n_obs = n_obs)
)

result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "Weighted 2SLS",
    sample = "All households with recipient = 0, including ineligible households in both village treatment statuses",
    endogenous_columns = c("dose*(1-eligible)", "dose*eligible"),
    exogenous_columns = c(
      "1-eligible", "eligible",
      "baseline*(1-eligible)", "baseline*eligible"
    ),
    instruments = c(
      "1-eligible", "eligible",
      "baseline*(1-eligible)", "baseline*eligible",
      "instrument*(1-eligible)", "instrument*eligible"
    ),
    regression_weight = "weight",
    group_effect = "Fitted dose slope multiplied by the household-weighted mean dose in that eligibility group",
    aggregation = "Census nonrecipient_population counts determine only the final between-group weights",
    counterfactual = "Synthetic convention: set dose to zero for every retained household"
  ),
  diagnostics = list(n_obs = n_obs)
)

jsonlite::write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  digits = 16,
  null = "null",
  pretty = TRUE
)
