library(jsonlite)

data <- read.csv("input.csv", stringsAsFactors = FALSE)
data$date <- as.Date(data$date)
data <- data[order(data$date), ]

log_vix <- log(data$vix)
log_sales <- log(data$sales)
vol_change <- c(NA_real_, diff(log_vix))

n <- nrow(data)
lag_matrix <- sapply(1:15, function(j) {
  c(rep(NA_real_, j), vol_change[seq_len(n - j)])
})
colnames(lag_matrix) <- paste0("lag_", 1:15)

reg_data <- data.frame(log_sales = log_sales, lag_matrix)
sample <- reg_data[complete.cases(reg_data), ]
fit <- lm(log_sales ~ ., data = sample)

X <- model.matrix(fit)
residuals <- residuals(fit)
N <- nrow(X)
p <- ncol(X)
scores <- X * residuals

meat <- crossprod(scores)
for (j in 1:15) {
  lag_product <- crossprod(
    scores[(j + 1):N, , drop = FALSE],
    scores[1:(N - j), , drop = FALSE]
  )
  weight <- 1 - j / 16
  meat <- meat + weight * (lag_product + t(lag_product))
}

bread <- solve(crossprod(X))
covariance <- (N / (N - 16)) * bread %*% meat %*% bread
coefficients <- coef(fit)

contrast <- c(0, rep(1, 15))
cumulative_response <- sum(contrast * coefficients)
cumulative_se <- sqrt(drop(t(contrast) %*% covariance %*% contrast))

rows <- list(
  list(
    term = "cumulative_response",
    estimate = unname(as.numeric(cumulative_response)),
    se = unname(as.numeric(cumulative_se)),
    n_obs = as.integer(N)
  ),
  list(
    term = "lag_1",
    estimate = unname(as.numeric(coefficients["lag_1"])),
    se = unname(as.numeric(sqrt(covariance["lag_1", "lag_1"]))),
    n_obs = as.integer(N)
  ),
  list(
    term = "lag_15",
    estimate = unname(as.numeric(coefficients["lag_15"])),
    se = unname(as.numeric(sqrt(covariance["lag_15", "lag_15"]))),
    n_obs = as.integer(N)
  )
)

write_json(
  list(
    task_id = "applied_cumulative_hac",
    platform = "r",
    estimates = rows,
    method_metadata = list(
      estimator = "OLS with 15 lags of log volatility changes",
      vcov = "Newey-West Bartlett HAC, maximum lag 15, correction N/(N-16)"
    ),
    diagnostics = list()
  ),
  "result.json",
  auto_unbox = TRUE,
  digits = 16,
  pretty = TRUE
)
