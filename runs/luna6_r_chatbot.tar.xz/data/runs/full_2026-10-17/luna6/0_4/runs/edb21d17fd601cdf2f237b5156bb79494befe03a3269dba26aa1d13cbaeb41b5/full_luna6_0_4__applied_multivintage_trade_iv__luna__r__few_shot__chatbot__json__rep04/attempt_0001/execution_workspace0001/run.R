library(jsonlite)

crosswalk <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
trade <- read.csv("trade.csv", stringsAsFactors = FALSE)
areas <- read.csv("areas.csv", stringsAsFactors = FALSE)
employment <- read.csv("employment.csv", stringsAsFactors = FALSE)
outcomes <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

trade <- merge(trade, crosswalk, by = "code", all.x = TRUE, sort = FALSE)

make_exposure <- function(vintage, change_column) {
  area_rows <- areas[areas$vintage == vintage, ]
  emp <- merge(
    area_rows,
    employment[employment$vintage == vintage, ],
    by = c("area", "period", "vintage"),
    all = TRUE,
    sort = FALSE
  )
  emp$employment[is.na(emp$employment)] <- 0

  national <- aggregate(
    employment ~ period + industry,
    data = emp,
    FUN = sum
  )

  joined <- merge(
    emp,
    national,
    by = c("period", "industry"),
    suffixes = c("_area", "_national"),
    all.x = TRUE,
    sort = FALSE
  )
  joined <- merge(
    joined,
    trade,
    by = c("period", "industry"),
    all.x = TRUE,
    sort = FALSE
  )

  joined$contribution <-
    (joined$employment_area / joined$total_employment) *
    (joined[[change_column]] / joined$employment_national) /
    (joined$price_index / 100) / 1000 *
    (10 / joined$years)

  aggregate(contribution ~ area + period, data = joined, FUN = sum)
}

x <- make_exposure("base", "us_change")
z <- make_exposure("early", "other_change")

dat <- merge(
  outcomes,
  x,
  by = c("area", "period"),
  all = FALSE,
  sort = FALSE
)
names(dat)[names(dat) == "contribution"] <- "x"
dat <- merge(dat, z, by = c("area", "period"), all = FALSE, sort = FALSE)
names(dat)[names(dat) == "contribution"] <- "z"
dat <- merge(dat, areas[areas$vintage == "base", c("area", "period", "population")],
             by = c("area", "period"), all = FALSE, sort = FALSE)

dat$period <- as.factor(dat$period)
w <- sqrt(dat$population)
C <- model.matrix(~ period + control, data = dat)
X <- cbind(C, x = dat$x) * w
Z <- cbind(C, z = dat$z) * w
y <- dat$change_pp * w

fitted_X <- qr.fitted(qr(Z), X)
iv_coef <- qr.coef(qr(fitted_X), y)
iv_slope <- unname(iv_coef[ncol(X)])

area0 <- function(frame, period_value, value_column) {
  frame[[value_column]][frame$area == 0 & frame$period == period_value]
}

estimates <- list(
  list(term = "iv_slope", estimate = iv_slope, se = NULL, n_obs = 72L),
  list(term = "exposure_area0_period0",
       estimate = area0(dat, levels(dat$period)[1], "x"), se = NULL, n_obs = 72L),
  list(term = "exposure_area0_period1",
       estimate = area0(dat, levels(dat$period)[2], "x"), se = NULL, n_obs = 72L),
  list(term = "instrument_area0_period0",
       estimate = area0(dat, levels(dat$period)[1], "z"), se = NULL, n_obs = 72L)
)

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "Weighted two-stage least squares",
    outcome = "change_pp",
    endogenous_regressor = "x",
    excluded_instrument = "z",
    exogenous_regressors = c("intercept", "period", "control"),
    weight = "base-vintage population",
    exposure_units = "thousands of real dollars per worker per decade"
  ),
  diagnostics = list(n_obs = 72L)
)

write_json(result, "result.json", auto_unbox = TRUE, digits = 16, na = "null")
