data <- read.csv("input.csv", stringsAsFactors = FALSE)
data$date <- as.Date(data$date)
data <- data[order(data$date), ]

data$vol_change <- c(NA_real_, diff(log(data$vix)))
for (j in 1:15) {
  data[[paste0("lag_", j)]] <- c(rep(NA_real_, j), head(data$vol_change, -j))
}

lag_names <- paste0("lag_", 1:15)
sample <- data[complete.cases(data[, c("sales", lag_names)]), ]
sample$log_sales <- log(sample$sales)

fit <- lm(
  log_sales ~ lag_1 + lag_2 + lag_3 + lag_4 + lag_5 +
    lag_6 + lag_7 + lag_8 + lag_9 + lag_10 +
    lag_11 + lag_12 + lag_13 + lag_14 + lag_15,
  data = sample
)

X <- model.matrix(fit)
u <- residuals(fit)
N <- nrow(X)
bread <- solve(crossprod(X))
meat <- crossprod(X * u)

for (j in 1:15) {
  weight <- 1 - j / 16
  gamma <- crossprod(X[(j + 1):N, , drop = FALSE] * u[(j + 1):N],
                     X[1:(N - j), , drop = FALSE] * u[1:(N - j)])
  meat <- meat + weight * (gamma + t(gamma))
}

vcov_nw <- bread %*% meat %*% bread * N / (N - 16)
coefs <- coef(fit)
cum_vector <- setNames(rep(0, length(coefs)), names(coefs))
cum_vector[lag_names] <- 1
cum_est <- sum(coefs[lag_names])
cum_se <- sqrt(drop(t(cum_vector) %*% vcov_nw %*% cum_vector))

estimates <- list(
  list(term = "cumulative_response", estimate = unname(cum_est),
       se = unname(cum_se), n_obs = as.integer(N)),
  list(term = "lag_1", estimate = unname(coefs["lag_1"]),
       se = sqrt(vcov_nw["lag_1", "lag_1"]), n_obs = as.integer(N)),
  list(term = "lag_15", estimate = unname(coefs["lag_15"]),
       se = sqrt(vcov_nw["lag_15", "lag_15"]), n_obs = as.integer(N))
)

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "OLS of log sales on intercept and volatility-change lags 1-15",
    vcov = "Newey-West Bartlett max lag 15, multiplied by N/(N-16)"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = NA)
