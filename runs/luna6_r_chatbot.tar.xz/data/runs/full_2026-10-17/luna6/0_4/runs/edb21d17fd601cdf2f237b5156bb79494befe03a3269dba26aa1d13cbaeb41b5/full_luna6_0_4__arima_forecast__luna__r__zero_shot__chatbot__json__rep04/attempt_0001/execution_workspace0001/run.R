dat <- read.csv("./input.csv")
if (!"y" %in% names(dat)) stop("input.csv must contain a y column")
y <- dat$y
if (!is.numeric(y) || length(y) < 2L || anyNA(y) || any(!is.finite(y))) {
  stop("y must contain at least two finite numeric observations")
}

fit <- stats::arima(
  y,
  order = c(1L, 1L, 1L),
  include.mean = FALSE,
  method = "ML"
)

pred <- stats::predict(fit, n.ahead = 1L)
forecast <- as.numeric(pred$pred[1L])
se <- as.numeric(pred$se[1L])
z <- stats::qnorm(0.975)

estimates <- data.frame(
  term = c("forecast", "lower_95", "upper_95"),
  estimate = c(forecast, forecast - z * se, forecast + z * se),
  se = c(se, NA_real_, NA_real_),
  n_obs = rep(length(y), 3L)
)

result <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = lapply(seq_len(nrow(estimates)), function(i) {
    list(
      term = estimates$term[i],
      estimate = estimates$estimate[i],
      se = if (is.na(estimates$se[i])) NULL else estimates$se[i],
      n_obs = estimates$n_obs[i]
    )
  }),
  method_metadata = list(
    estimator = "ARIMA(1,1,1) maximum likelihood, no constant or drift",
    vcov = "Prediction standard error from fitted ARIMA model"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, na = "null", digits = 15)
