library(jsonlite)

households <- read.csv("households.csv", stringsAsFactors = FALSE)
census <- read.csv("census.csv", stringsAsFactors = FALSE)

required_household_columns <- c(
  "eligible", "recipient", "instrument", "dose", "baseline",
  "weight", "outcome"
)
required_census_columns <- c("eligible", "nonrecipient_population")

if (!all(required_household_columns %in% names(households))) {
  stop("households.csv is missing one or more required columns.")
}
if (!all(required_census_columns %in% names(census))) {
  stop("census.csv is missing one or more required columns.")
}

retained <- households[households$recipient == 0, , drop = FALSE]
if (nrow(retained) == 0L) {
  stop("No nonrecipient household rows are available.")
}
if (any(!is.finite(retained$weight)) || any(retained$weight <= 0)) {
  stop("Estimation weights must be finite and positive.")
}

eligible <- retained$eligible
ineligible <- 1 - eligible
dose <- retained$dose
instrument <- retained$instrument
baseline <- retained$baseline
weight <- retained$weight
outcome <- retained$outcome

# Endogenous regressors, exogenous regressors, and instruments follow
# the specified columns. The design has no additional intercept.
endogenous <- cbind(
  dose_ineligible = dose * ineligible,
  dose_eligible = dose * eligible
)
exogenous <- cbind(
  ineligible = ineligible,
  eligible = eligible,
  baseline_ineligible = baseline * ineligible,
  baseline_eligible = baseline * eligible
)
instruments <- cbind(
  exogenous,
  instrument_ineligible = instrument * ineligible,
  instrument_eligible = instrument * eligible
)

# Weighted 2SLS via the weighted projection of endogenous columns onto
# the full instrument matrix, followed by weighted least squares.
sqrt_weight <- sqrt(weight)
weighted_instruments <- instruments * sqrt_weight
weighted_endogenous <- endogenous * sqrt_weight
weighted_outcome <- outcome * sqrt_weight

qr_instruments <- qr(weighted_instruments)
if (qr_instruments$rank < ncol(instruments)) {
  stop("The weighted instrument matrix is rank deficient.")
}

projected_endogenous <- qr.fitted(qr_instruments, weighted_endogenous)
design <- cbind(exogenous, projected_endogenous)
weighted_design <- design * sqrt_weight

qr_design <- qr(weighted_design)
if (qr_design$rank < ncol(design)) {
  stop("The weighted 2SLS design matrix is rank deficient.")
}

coefficients <- qr.coef(qr_design, weighted_outcome)
if (any(!is.finite(coefficients))) {
  stop("The weighted 2SLS estimate is not finite.")
}

slope_ineligible <- unname(coefficients["dose_ineligible"])
slope_eligible <- unname(coefficients["dose_eligible"])

weighted_mean_dose <- function(group) {
  selected <- group == 1
  if (!any(selected)) {
    stop("A required eligibility group has no retained observations.")
  }
  sum(weight[selected] * dose[selected]) / sum(weight[selected])
}

ineligible_effect <- slope_ineligible * weighted_mean_dose(ineligible)
eligible_nonrecipient_effect <- slope_eligible * weighted_mean_dose(eligible)

population <- census$nonrecipient_population[match(c(0, 1), census$eligible)]
if (length(population) != 2L || anyNA(population) ||
    any(!is.finite(population)) || any(population < 0) ||
    sum(population) <= 0) {
  stop("Census must provide valid nonrecipient populations for both groups.")
}

population_effect <- (
  population[1] * ineligible_effect +
    population[2] * eligible_nonrecipient_effect
) / sum(population)

n_obs <- as.integer(nrow(retained))
estimates <- list(
  list(term = "ineligible_effect",
       estimate = unname(ineligible_effect), se = NULL, n_obs = n_obs),
  list(term = "eligible_nonrecipient_effect",
       estimate = unname(eligible_nonrecipient_effect), se = NULL, n_obs = n_obs),
  list(term = "population_effect",
       estimate = unname(population_effect), se = NULL, n_obs = n_obs)
)

result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "weighted_two_stage_least_squares",
    endogenous_columns = c("dose*(1-eligible)", "dose*eligible"),
    exogenous_columns = c(
      "1-eligible", "eligible",
      "baseline*(1-eligible)", "baseline*eligible"
    ),
    instrument_columns = c(
      "1-eligible", "eligible",
      "baseline*(1-eligible)", "baseline*eligible",
      "instrument*(1-eligible)", "instrument*eligible"
    ),
    intercept = "none",
    estimation_weight = "weight",
    retained_sample = "all household rows with recipient=0",
    group_effect = "fitted dose slope times household-weighted mean dose among retained group observations",
    counterfactual = "dose set to zero for every retained household; attribution is a stated synthetic convention",
    population_aggregation = "census nonrecipient_population shares; census totals used only for final between-group weights"
  ),
  diagnostics = list(
    n_obs = n_obs,
    retained_rows = n_obs,
    ineligible_retained_rows = as.integer(sum(ineligible == 1)),
    eligible_retained_rows = as.integer(sum(eligible == 1)),
    ineligible_weighted_mean_dose = unname(weighted_mean_dose(ineligible)),
    eligible_weighted_mean_dose = unname(weighted_mean_dose(eligible)),
    ineligible_dose_slope = slope_ineligible,
    eligible_dose_slope = slope_eligible,
    ineligible_census_population = unname(population[1]),
    eligible_census_population = unname(population[2])
  )
)

write_json(result, "result.json", auto_unbox = TRUE, digits = 17, null = "null")
