library(nnet)
library(jsonlite)

data <- read.csv("input.csv")
data$y <- factor(data$y, levels = c(0, 1, 2))

fit <- multinom(y ~ x + z, data = data, Hess = TRUE, trace = FALSE)
beta <- coef(fit)
vc <- solve(fit$Hessian)
se <- sqrt(diag(vc))

# multinom orders coefficients by non-base outcome, then regressor
terms <- c("x_cat1", "z_cat1", "x_cat2", "z_cat2")
estimates <- c(beta[1, "x"], beta[1, "z"], beta[2, "x"], beta[2, "z"])
ses <- c(se["1:x"], se["1:z"], se["2:x"], se["2:z"])

eta1 <- beta[1, "(Intercept)"]
eta2 <- beta[2, "(Intercept)"]
prob_cat2_zero <- exp(eta2) / (1 + exp(eta1) + exp(eta2))

rows <- lapply(seq_along(terms), function(i) {
  list(term = terms[i], estimate = unname(estimates[i]),
       se = unname(ses[i]), n_obs = nrow(data))
})
rows[[5]] <- list(term = "prob_cat2_zero", estimate = unname(prob_cat2_zero),
                  se = NULL, n_obs = nrow(data))

result <- list(
  task_id = "broad_multinomial_logit",
  platform = "r",
  estimates = rows,
  method_metadata = list(
    estimator = "Maximum likelihood multinomial logit",
    vcov = "Conventional observed-information inverse Hessian"
  ),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, digits = 15, null = "null")
