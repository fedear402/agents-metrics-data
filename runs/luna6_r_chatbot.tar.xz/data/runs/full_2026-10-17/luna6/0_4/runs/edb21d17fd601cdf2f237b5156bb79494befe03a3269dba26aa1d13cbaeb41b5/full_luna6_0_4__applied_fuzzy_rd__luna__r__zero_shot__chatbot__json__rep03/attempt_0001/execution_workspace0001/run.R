dat <- read.csv("input.csv")

d <- dat[abs(dat$score) < 1, ]
n_obs <- nrow(d)
x <- d$score
right <- as.numeric(x >= 0)
w <- 1 - abs(x)

# Separate local-linear fits, represented by side-specific intercepts and slopes.
X <- cbind(left_intercept = 1 - right,
           left_slope = x * (1 - right),
           right_intercept = right,
           right_slope = x * right)

fit_discontinuities <- function(y) {
  bread <- solve(crossprod(X, w * X))
  beta <- bread %*% crossprod(X, w * y)
  residual <- y - drop(X %*% beta)

  # HC0 sandwich covariance for weighted least squares.
  meat <- crossprod(X, (w * residual)^2 * X)
  vcov <- bread %*% meat %*% bread

  contrast <- c(-1, 0, 1, 0)
  estimate <- drop(contrast %*% beta)
  variance <- drop(contrast %*% vcov %*% contrast)
  list(estimate = estimate, variance = variance, vcov = vcov)
}

rf <- fit_discontinuities(d$earnings)
fs <- fit_discontinuities(d$participated)

# Joint HC0 covariance uses the same design and observations for both outcomes.
bread <- solve(crossprod(X, w * X))
resid_y <- d$earnings - drop(X %*% (bread %*% crossprod(X, w * d$earnings)))
resid_d <- d$participated - drop(X %*% (bread %*% crossprod(X, w * d$participated)))
meat_cross <- crossprod(X, (w^2 * resid_y * resid_d) * X)
vcov_cross <- bread %*% meat_cross %*% bread
contrast <- c(-1, 0, 1, 0)
cov_rf_fs <- drop(contrast %*% vcov_cross %*% contrast)

ratio <- rf$estimate / fs$estimate
se_ratio <- sqrt(rf$variance / fs$estimate^2 +
                 rf$estimate^2 * fs$variance / fs$estimate^4 -
                 2 * rf$estimate * cov_rf_fs / fs$estimate^3)

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = ratio, se = se_ratio, n_obs = n_obs),
    list(term = "reduced_form", estimate = rf$estimate, se = sqrt(rf$variance), n_obs = n_obs),
    list(term = "first_stage", estimate = fs$estimate, se = sqrt(fs$variance), n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "Fuzzy RD: separate weighted local-linear regressions with triangular weights; ratio of discontinuities",
    vcov = "HC0 sandwich; delta method using joint covariance of reduced form and first stage"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = 15, null = "null")
