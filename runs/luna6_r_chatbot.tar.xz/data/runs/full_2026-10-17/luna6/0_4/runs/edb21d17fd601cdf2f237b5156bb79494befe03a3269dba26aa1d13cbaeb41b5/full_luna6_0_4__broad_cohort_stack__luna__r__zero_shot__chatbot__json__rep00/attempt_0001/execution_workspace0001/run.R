library(jsonlite)

data <- read.csv("input.csv")

cohorts <- c(3, 5, 7)
terms <- paste0("att_g", cohorts)
estimates <- numeric(length(cohorts))
row_counts <- integer(length(cohorts))
treated_counts <- integer(length(cohorts))

for (i in seq_along(cohorts)) {
  cohort <- cohorts[i]
  window <- (cohort - 2):(cohort + 2)

  eligible_ids <- unique(data$id[data$g == cohort | data$g == 0 | data$g > cohort + 2])
  comparison <- data[data$id %in% eligible_ids & data$time %in% window, ]

  observed_times <- tapply(comparison$time, comparison$id, function(x) length(unique(x)))
  balanced_ids <- names(observed_times[observed_times == length(window)])
  comparison <- comparison[comparison$id %in% balanced_ids, ]

  comparison$did <- as.integer(comparison$g == cohort & comparison$time >= cohort)
  fit <- lm(y ~ did + factor(id) + factor(time), data = comparison)

  estimates[i] <- unname(coef(fit)["did"])
  row_counts[i] <- nrow(comparison)
  treated_counts[i] <- length(unique(comparison$id[comparison$g == cohort]))
}

weighted_estimate <- sum(estimates * treated_counts) / sum(treated_counts)

estimate_rows <- lapply(seq_along(cohorts), function(i) {
  list(
    term = terms[i],
    estimate = estimates[i],
    se = NULL,
    n_obs = row_counts[i]
  )
})

estimate_rows[[4]] <- list(
  term = "att_weighted",
  estimate = weighted_estimate,
  se = NULL,
  n_obs = sum(row_counts)
)

result <- list(
  task_id = "broad_cohort_stack",
  platform = "r",
  estimates = estimate_rows,
  method_metadata = list(),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, digits = 17, na = "null")
