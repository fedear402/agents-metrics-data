library(jsonlite)

dat <- read.csv("input.csv")
inside <- abs(dat$score) < 1
d <- dat[inside, ]
n <- nrow(d)

x <- d$score
right <- as.numeric(x >= 0)
w <- 1 - abs(x)

# Separate local-linear regressions, represented by side-specific intercepts
# and slopes. Fit both outcomes with the same design and weights.
X <- cbind(left_intercept = 1 - right,
           left_slope = (1 - right) * x,
           right_intercept = right,
           right_slope = right * x)
bread <- solve(crossprod(X, w * X))

Y <- cbind(earnings = d$earnings, participated = d$participated)
beta <- bread %*% crossprod(X, w * Y)
resid <- Y - X %*% beta

# Right limit minus left limit.
contrast <- c(-1, 0, 1, 0)
discontinuities <- drop(contrast %*% beta)

# HC0 joint covariance for the two discontinuities, using paired residuals.
loading <- drop(X %*% bread %*% contrast) * w
influence <- loading * resid
joint_vcov <- crossprod(influence)
standard_errors <- sqrt(diag(joint_vcov))

reduced_form <- discontinuities[1]
first_stage <- discontinuities[2]
treatment_effect <- reduced_form / first_stage
gradient <- c(1 / first_stage, -reduced_form / first_stage^2)
treatment_se <- sqrt(drop(t(gradient) %*% joint_vcov %*% gradient))

row <- function(term, estimate, se) {
  list(term = term, estimate = unname(as.numeric(estimate)),
       se = unname(as.numeric(se)), n_obs = as.integer(n))
}

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    row("treatment_effect", treatment_effect, treatment_se),
    row("reduced_form", reduced_form, standard_errors[1]),
    row("first_stage", first_stage, standard_errors[2])
  ),
  method_metadata = list(
    estimator = "weighted local-linear fuzzy regression discontinuity",
    vcov = "joint HC0 sandwich; fixed triangular weights; no degrees-of-freedom correction"
  ),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null",
           digits = 16, pretty = TRUE)
