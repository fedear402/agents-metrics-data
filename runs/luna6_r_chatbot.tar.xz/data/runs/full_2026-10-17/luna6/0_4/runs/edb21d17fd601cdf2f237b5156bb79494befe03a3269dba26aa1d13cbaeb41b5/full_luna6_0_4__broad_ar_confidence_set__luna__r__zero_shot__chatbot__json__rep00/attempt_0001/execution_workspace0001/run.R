dat <- read.csv("input.csv")
n <- nrow(dat)
critical <- qf(0.95, df1 = 2, df2 = n - 4)

ar_f <- function(beta) {
  fit <- lm(I(y - beta * endog) ~ x + z1 + z2, data = dat)
  an <- anova(fit)
  rss_restricted <- sum(resid(lm(I(y - beta * endog) ~ x, data = dat))^2)
  rss_unrestricted <- sum(resid(fit)^2)
  ((rss_restricted - rss_unrestricted) / 2) /
    (rss_unrestricted / (n - 4))
}

# The unrestricted model's residual-maker defines a quadratic AR test
# numerator in beta. Solve its equality to the critical value directly.
X <- model.matrix(~ x + z1 + z2, data = dat)
Z <- model.matrix(~ x, data = dat)
M <- diag(n) - X %*% solve(crossprod(X), t(X))
MR <- diag(n) - Z %*% solve(crossprod(Z), t(Z))
Y <- dat$y
D <- dat$endog
A <- drop(crossprod(D, M %*% D))
B <- -2 * drop(crossprod(Y, M %*% D))
C <- drop(crossprod(Y, M %*% Y))
# F(beta) = (RSS_restricted - RSS_unrestricted)/2 divided by
# RSS_unrestricted/(n-4); equivalently use the joint projection test.
# Compute numerator as the difference in residual sums of squares.
Q <- X[, c("z1", "z2"), drop = FALSE]
# Use nested-model projection matrices for the instrument contribution.
P_X <- X %*% solve(crossprod(X), t(X))
P_R <- Z %*% solve(crossprod(Z), t(Z))
H <- P_X - P_R
# F(beta) = (v'Hv / 2) / (v'Mv / (n-4)).
# Both quadratic forms yield a quadratic equation at the cutoff.
g2 <- drop(crossprod(D, H %*% D))
g1 <- -2 * drop(crossprod(Y, H %*% D))
g0 <- drop(crossprod(Y, H %*% Y))
h2 <- drop(crossprod(D, M %*% D))
h1 <- -2 * drop(crossprod(Y, M %*% D))
h0 <- drop(crossprod(Y, M %*% Y))
roots <- sort(Re(polyroot(c((n - 4) * g0 - 2 * critical * h0,
                            (n - 4) * g1 - 2 * critical * h1,
                            (n - 4) * g2 - 2 * critical * h2))))
roots <- roots[is.finite(roots)]
boundary_low <- roots[1]
boundary_high <- roots[length(roots)]

f_one <- ar_f(1)
accepts_zero <- as.integer(ar_f(0) <= critical)
unbounded <- as.integer((n - 4) * g2 - 2 * critical * h2 <= 0)

estimates <- list(
  list(term = "boundary_low", estimate = boundary_low, se = NULL, n_obs = n),
  list(term = "boundary_high", estimate = boundary_high, se = NULL, n_obs = n),
  list(term = "accepts_zero", estimate = as.numeric(accepts_zero), se = NULL, n_obs = n),
  list(term = "unbounded", estimate = as.numeric(unbounded), se = NULL, n_obs = n),
  list(term = "ar_f_at_one", estimate = f_one, se = NULL, n_obs = n)
)

jsonlite::write_json(
  list(
    task_id = "broad_ar_confidence_set",
    platform = "r",
    estimates = estimates,
    method_metadata = list(
      estimator = "Anderson-Rubin joint F test, inverted over the real line",
      vcov = "conventional homoskedastic"
    ),
    diagnostics = list()
  ),
  "result.json",
  auto_unbox = TRUE,
  digits = 16,
  null = "null"
)
