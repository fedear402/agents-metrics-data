data <- read.csv("input.csv", stringsAsFactors = FALSE)
data$date <- as.Date(data$date)
data <- data[order(data$date), ]

dlog_vix <- c(NA_real_, diff(log(data$vix)))
log_sales <- log(data$sales)

n <- nrow(data)
lag_matrix <- sapply(1:15, function(k) {
  c(rep(NA_real_, k), dlog_vix[seq_len(n - k)])
})
colnames(lag_matrix) <- paste0("lag_", 1:15)

model_data <- data.frame(log_sales = log_sales, lag_matrix)
model_data <- model_data[complete.cases(model_data), ]
fit <- lm(log_sales ~ ., data = model_data)

X <- model.matrix(fit)
u <- residuals(fit)
N <- nrow(X)
bread <- solve(crossprod(X))
score <- X * as.vector(u)

meat <- crossprod(score)
for (j in 1:15) {
  weight <- 1 - j / 16
  cross_lag <- crossprod(score[(j + 1):N, , drop = FALSE],
                         score[1:(N - j), , drop = FALSE])
  meat <- meat + weight * (cross_lag + t(cross_lag))
}
vcov_nw <- bread %*% meat %*% bread * (N / (N - 16))

beta <- coef(fit)
cumulative_vector <- rep(0, length(beta))
names(cumulative_vector) <- names(beta)
cumulative_vector[paste0("lag_", 1:15)] <- 1

terms <- c("cumulative_response", "lag_1", "lag_15")
estimates <- c(
  sum(beta[paste0("lag_", 1:15)]),
  beta["lag_1"],
  beta["lag_15"]
)
ses <- c(
  sqrt(drop(t(cumulative_vector) %*% vcov_nw %*% cumulative_vector)),
  sqrt(vcov_nw["lag_1", "lag_1"]),
  sqrt(vcov_nw["lag_15", "lag_15"])
)

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = lapply(seq_along(terms), function(i) {
    list(term = terms[i], estimate = unname(estimates[i]),
         se = unname(ses[i]), n_obs = as.integer(N))
  }),
  method_metadata = list(
    estimator = "OLS of log sales on an intercept and lags 1 through 15 of first differences in log VIX",
    vcov = "Newey-West HAC, Bartlett weights, maximum lag 15, covariance scaled by N/(N-16)"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = 15, null = "null")
