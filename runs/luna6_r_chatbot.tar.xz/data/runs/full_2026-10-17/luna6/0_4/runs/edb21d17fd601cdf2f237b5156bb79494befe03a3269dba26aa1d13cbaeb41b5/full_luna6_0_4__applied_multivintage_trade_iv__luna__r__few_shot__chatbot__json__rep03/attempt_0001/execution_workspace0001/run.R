files <- c("crosswalk.csv", "trade.csv", "areas.csv", "employment.csv", "outcomes.csv")
data <- setNames(lapply(files, read.csv, stringsAsFactors = FALSE), files)

crosswalk <- data[["crosswalk.csv"]]
trade <- merge(data[["trade.csv"]], crosswalk, by = "code", all.x = TRUE, sort = FALSE)
areas <- data[["areas.csv"]]
employment <- data[["employment.csv"]]
outcomes <- data[["outcomes.csv"]]

if (anyNA(trade$industry)) stop("A trade code has no crosswalk industry.")

make_exposure <- function(period, vintage, trade_value) {
  area_rows <- areas[areas$period == period & areas$vintage == vintage, ]
  period_trade <- trade[trade$period == period, ]
  if (nrow(area_rows) == 0L || nrow(period_trade) == 0L) stop("Missing period data.")

  national <- setNames(numeric(length(unique(crosswalk$industry))), unique(crosswalk$industry))
  period_employment <- employment[
    employment$period == period & employment$vintage == vintage, ]
  national_by_industry <- aggregate(
    employment ~ industry, data = period_employment, FUN = sum
  )
  national[national_by_industry$industry] <- national_by_industry$employment
  if (any(national <= 0)) stop("National industry employment must be positive.")

  area_codes <- area_rows$area
  result <- data.frame(area = area_codes, value = 0)
  for (i in seq_len(nrow(period_trade))) {
    row <- period_trade[i, ]
    industry <- row$industry
    area_industry <- employment[
      employment$period == period &
        employment$vintage == vintage &
        employment$industry == industry, c("area", "employment")
    ]
    employment_by_area <- setNames(area_industry$employment, area_industry$area)
    emp <- unname(employment_by_area[as.character(area_codes)])
    emp[is.na(emp)] <- 0

    total <- area_rows$total_employment[
      match(area_codes, area_rows$area)
    ]
    if (anyNA(total) || any(total == 0)) stop("Invalid area total employment.")

    contribution <- (emp / total) *
      (row[[trade_value]] / national[industry]) /
      (row$price_index / 100) / 1000 * (10 / row$years)
    result$value <- result$value + contribution
  }
  result
}

periods <- sort(unique(areas$period))
if (length(periods) != 2L) stop("Expected two periods.")

panel <- merge(
  areas[areas$vintage == "base", c("area", "period", "total_employment", "population")],
  outcomes, by = c("area", "period"), all = FALSE, sort = FALSE
)
panel$x <- NA_real_
panel$z <- NA_real_

for (period in periods) {
  base_x <- make_exposure(period, "base", "us_change")
  early_z <- make_exposure(period, "early", "other_change")
  panel$x[panel$period == period] <- base_x$value[
    match(panel$area[panel$period == period], base_x$area)
  ]
  panel$z[panel$period == period] <- early_z$value[
    match(panel$area[panel$period == period], early_z$area)
  ]
}

panel$period_indicator <- as.numeric(panel$period == periods[2])
if (anyNA(panel[, c("x", "z", "change_pp", "control", "population")])) {
  stop("Incomplete estimation data.")
}

n_obs <- 72L
if (nrow(panel) != n_obs) stop("Expected 72 area-period estimation rows.")

Y <- panel$change_pp
X <- cbind(intercept = 1, period = panel$period_indicator,
           control = panel$control, x = panel$x)
Z <- cbind(intercept = 1, period = panel$period_indicator,
           control = panel$control, z = panel$z)
w <- panel$population

Xw <- X * sqrt(w)
Zw <- Z * sqrt(w)
yw <- Y * sqrt(w)
fit <- qr.coef(qr(Zw), yw)
projected_X <- qr.fitted(qr(Zw), Xw)
beta <- qr.coef(qr(projected_X), yw)
iv_slope <- unname(beta[ncol(X)])

area0 <- min(panel$area)
area0_period0 <- panel$x[panel$area == area0 & panel$period == periods[1]]
area0_period1 <- panel$x[panel$area == area0 & panel$period == periods[2]]
instrument_area0_period0 <- panel$z[panel$area == area0 & panel$period == periods[1]]

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = list(
    list(term = "iv_slope", estimate = unname(iv_slope), se = NULL, n_obs = n_obs),
    list(term = "exposure_area0_period0", estimate = unname(area0_period0), se = NULL, n_obs = n_obs),
    list(term = "exposure_area0_period1", estimate = unname(area0_period1), se = NULL, n_obs = n_obs),
    list(term = "instrument_area0_period0", estimate = unname(instrument_area0_period0), se = NULL, n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "weighted two-stage least squares",
    outcome = "change_pp",
    endogenous_regressor = "x",
    excluded_instrument = "z",
    exogenous_regressors = c("intercept", "period", "control"),
    weight = "base-vintage population",
    exposure_units = "thousands of real dollars per worker per decade",
    period_order = as.list(periods)
  ),
  diagnostics = list(n_obs = n_obs)
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = 16, na = "null")
