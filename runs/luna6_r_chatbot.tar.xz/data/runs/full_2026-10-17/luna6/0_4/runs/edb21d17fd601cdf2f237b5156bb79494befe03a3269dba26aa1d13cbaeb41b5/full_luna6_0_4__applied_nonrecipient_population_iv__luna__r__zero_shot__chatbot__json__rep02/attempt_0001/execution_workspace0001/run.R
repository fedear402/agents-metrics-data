library(jsonlite)

households <- read.csv("households.csv", stringsAsFactors = FALSE)
census <- read.csv("census.csv", stringsAsFactors = FALSE)

required_household_columns <- c(
  "eligible", "recipient", "instrument", "dose", "baseline", "weight", "outcome"
)
required_census_columns <- c("eligible", "nonrecipient_population")

if (!all(required_household_columns %in% names(households))) {
  stop("households.csv is missing required columns")
}
if (!all(required_census_columns %in% names(census))) {
  stop("census.csv is missing required columns")
}
if (any(!is.finite(households$weight)) || any(households$weight <= 0)) {
  stop("All regression weights must be positive and finite")
}

dat <- households[households$recipient == 0, , drop = FALSE]
n_obs <- as.integer(nrow(dat))
if (n_obs == 0L) stop("No nonrecipient household rows are available")

ineligible <- 1 - dat$eligible
eligible <- dat$eligible

# Exogenous regressors include the two group indicators and group-specific
# baseline terms. No additional intercept is included.
X <- cbind(
  ineligible = ineligible,
  eligible = eligible,
  baseline_ineligible = dat$baseline * ineligible,
  baseline_eligible = dat$baseline * eligible
)

# The endogenous dose slopes are estimated separately by eligibility group.
D <- cbind(
  dose_ineligible = dat$dose * ineligible,
  dose_eligible = dat$dose * eligible
)

Z <- cbind(
  X,
  instrument_ineligible = dat$instrument * ineligible,
  instrument_eligible = dat$instrument * eligible
)

W <- diag(dat$weight)
A <- cbind(X, D)
bread <- solve(t(A) %*% W %*% Z %*%
                 solve(t(Z) %*% W %*% Z) %*% t(Z) %*% W %*% A)
projection <- Z %*% solve(t(Z) %*% W %*% Z) %*% t(Z) %*% W
beta <- bread %*% t(A) %*% W %*% Z %*%
  solve(t(Z) %*% W %*% Z) %*% t(Z) %*% W %*% dat$outcome

# Compute the household-weighted mean dose within each retained group.
weighted_mean <- function(x, w) sum(x * w) / sum(w)

idx0 <- dat$eligible == 0
idx1 <- dat$eligible == 1
if (!any(idx0) || !any(idx1)) stop("Both eligibility groups must be represented")

dose_mean_ineligible <- weighted_mean(dat$dose[idx0], dat$weight[idx0])
dose_mean_eligible <- weighted_mean(dat$dose[idx1], dat$weight[idx1])

slope_ineligible <- unname(beta[5])
slope_eligible <- unname(beta[6])

ineligible_effect <- slope_ineligible * dose_mean_ineligible
eligible_nonrecipient_effect <- slope_eligible * dose_mean_eligible

census_nonrecipient <- census$nonrecipient_population[
  match(c(0, 1), census$eligible)
]
if (anyNA(census_nonrecipient) || any(!is.finite(census_nonrecipient)) ||
    any(census_nonrecipient < 0) || sum(census_nonrecipient) <= 0) {
  stop("Census must provide nonnegative population counts for both groups")
}

population_effect <- (
  ineligible_effect * census_nonrecipient[1] +
    eligible_nonrecipient_effect * census_nonrecipient[2]
) / sum(census_nonrecipient)

estimates <- list(
  list(term = "ineligible_effect", estimate = as.numeric(ineligible_effect),
       se = NULL, n_obs = n_obs),
  list(term = "eligible_nonrecipient_effect",
       estimate = as.numeric(eligible_nonrecipient_effect),
       se = NULL, n_obs = n_obs),
  list(term = "population_effect", estimate = as.numeric(population_effect),
       se = NULL, n_obs = n_obs)
)

result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "weighted_2sls",
    sample = "all household rows with recipient equal to zero",
    endogenous_columns = c("dose*(1-eligible)", "dose*eligible"),
    exogenous_columns = c(
      "1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"
    ),
    instrument_columns = c(
      "1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible",
      "instrument*(1-eligible)", "instrument*eligible"
    ),
    regression_weight = "weight",
    group_effect = "fitted group-specific dose slope times weighted mean dose",
    counterfactual = "dose set to zero for all retained households",
    counterfactual_attribution = "stated synthetic convention",
    population_aggregation = "census nonrecipient_population used only for final between-group weights"
  ),
  diagnostics = list(
    n_obs = n_obs,
    n_ineligible = as.integer(sum(idx0)),
    n_eligible = as.integer(sum(idx1)),
    dose_mean_ineligible = as.numeric(dose_mean_ineligible),
    dose_mean_eligible = as.numeric(dose_mean_eligible),
    census_nonrecipient_population_ineligible =
      as.numeric(census_nonrecipient[1]),
    census_nonrecipient_population_eligible =
      as.numeric(census_nonrecipient[2])
  )
)

write_json(
  result,
  path = "result.json",
  auto_unbox = TRUE,
  digits = 16,
  null = "null",
  pretty = TRUE
)
