data <- read.csv("input.csv")

d <- data[abs(data$score) < 1, ]
n <- nrow(d)
w <- 1 - abs(d$score)
right <- as.numeric(d$score >= 0)

fit_discontinuity <- function(y) {
  design <- cbind(
    intercept = 1,
    right = right,
    score_left = d$score * (1 - right),
    score_right = d$score * right
  )
  bread <- solve(crossprod(design, design * w))
  beta <- bread %*% crossprod(design, w * y)
  resid <- as.vector(y - design %*% beta)
  meat <- crossprod(design, design * (w^2 * resid^2))
  vcov <- bread %*% meat %*% bread
  list(estimate = as.numeric(beta["right", 1]), vcov = vcov)
}

rf <- fit_discontinuity(d$earnings)
fs <- fit_discontinuity(d$participated)
tau <- rf$estimate / fs$estimate

# The two outcome regressions use the same design and weights. Their HC0
# cross-covariance uses the paired residuals from those regressions.
design <- cbind(
  intercept = 1,
  right = right,
  score_left = d$score * (1 - right),
  score_right = d$score * right
)
bread <- solve(crossprod(design, design * w))
resid_y <- as.vector(d$earnings - design %*% (bread %*% crossprod(design, w * d$earnings)))
resid_d <- as.vector(d$participated - design %*% (bread %*% crossprod(design, w * d$participated)))
cross_meat <- crossprod(design, design * (w^2 * resid_y * resid_d))
cross_vcov <- bread %*% cross_meat %*% bread
cov_rf_fs <- as.numeric(cross_vcov["right", "right"])

se_rf <- sqrt(rf$vcov["right", "right"])
se_fs <- sqrt(fs$vcov["right", "right"])
var_tau <- (se_rf^2 / fs$estimate^2) +
  (rf$estimate^2 * se_fs^2 / fs$estimate^4) -
  (2 * rf$estimate * cov_rf_fs / fs$estimate^3)
se_tau <- sqrt(max(0, var_tau))

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = tau, se = se_tau, n_obs = n),
    list(term = "reduced_form", estimate = rf$estimate, se = se_rf, n_obs = n),
    list(term = "first_stage", estimate = fs$estimate, se = se_fs, n_obs = n)
  ),
  method_metadata = list(
    estimator = "Fuzzy RD, separate weighted local-linear regressions, triangular kernel, bandwidth 1",
    vcov = "Joint HC0 sandwich covariance; delta method for ratio"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = 15, null = "null")
