library(jsonlite)

d <- read.csv("input.csv")

fit_cohort <- function(c) {
  window <- (c - 2):(c + 2)
  eligible <- d[d$g == c | d$g == 0 | d$g > c + 2, ]
  eligible <- eligible[eligible$time %in% window, ]

  complete_ids <- names(which(table(eligible$id) == length(window)))
  comparison <- eligible[eligible$id %in% complete_ids, ]
  comparison$did <- as.numeric(comparison$g == c & comparison$time >= c)

  effect <- unname(coef(lm(
    y ~ did + factor(id) + factor(time),
    data = comparison
  ))["did"])

  list(
    estimate = effect,
    n_obs = nrow(comparison),
    n_treated = length(unique(comparison$id[comparison$g == c]))
  )
}

cohorts <- c(3, 5, 7)
fits <- lapply(cohorts, fit_cohort)

weighted_effect <- sum(vapply(fits, `[[`, numeric(1), "estimate") *
                       vapply(fits, `[[`, numeric(1), "n_treated")) /
  sum(vapply(fits, `[[`, numeric(1), "n_treated"))

row_counts <- vapply(fits, `[[`, integer(1), "n_obs")

out <- list(
  task_id = "broad_cohort_stack",
  platform = "r",
  estimates = list(
    list(term = "att_g3", estimate = fits[[1]]$estimate,
         se = NULL, n_obs = row_counts[1]),
    list(term = "att_g5", estimate = fits[[2]]$estimate,
         se = NULL, n_obs = row_counts[2]),
    list(term = "att_g7", estimate = fits[[3]]$estimate,
         se = NULL, n_obs = row_counts[3]),
    list(term = "att_weighted", estimate = weighted_effect,
         se = NULL, n_obs = sum(row_counts))
  ),
  method_metadata = list(),
  diagnostics = list()
)

write_json(out, "result.json", auto_unbox = TRUE, null = "null", digits = 16)
