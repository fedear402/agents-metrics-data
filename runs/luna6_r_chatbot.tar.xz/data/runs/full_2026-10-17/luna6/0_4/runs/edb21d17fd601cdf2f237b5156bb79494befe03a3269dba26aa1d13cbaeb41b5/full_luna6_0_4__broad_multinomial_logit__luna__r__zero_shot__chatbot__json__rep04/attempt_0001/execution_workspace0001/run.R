library(jsonlite)

d <- read.csv("input.csv")
d$y <- factor(d$y, levels = c(0, 1, 2))

fit <- nnet::multinom(y ~ x + z, data = d, trace = FALSE, Hess = TRUE)
b <- coef(fit)
V <- solve(fit$Hessian)
se <- sqrt(diag(V))

p0 <- predict(fit, newdata = data.frame(x = 0, z = 0), type = "probs")
n <- nrow(d)

estimates <- list(
  list(term = "x_cat1", estimate = unname(b["1", "x"]), se = unname(se["1:x"]), n_obs = n),
  list(term = "z_cat1", estimate = unname(b["1", "z"]), se = unname(se["1:z"]), n_obs = n),
  list(term = "x_cat2", estimate = unname(b["2", "x"]), se = unname(se["2:x"]), n_obs = n),
  list(term = "z_cat2", estimate = unname(b["2", "z"]), se = unname(se["2:z"]), n_obs = n),
  list(term = "prob_cat2_zero", estimate = unname(p0["2"]), se = NULL, n_obs = n)
)

out <- list(
  task_id = "broad_multinomial_logit",
  platform = "r",
  estimates = estimates,
  method_metadata = list(estimator = "Maximum likelihood multinomial logit", vcov = "Conventional observed-information"),
  diagnostics = list()
)

write_json(out, "result.json", auto_unbox = TRUE, digits = 15, null = "null")
