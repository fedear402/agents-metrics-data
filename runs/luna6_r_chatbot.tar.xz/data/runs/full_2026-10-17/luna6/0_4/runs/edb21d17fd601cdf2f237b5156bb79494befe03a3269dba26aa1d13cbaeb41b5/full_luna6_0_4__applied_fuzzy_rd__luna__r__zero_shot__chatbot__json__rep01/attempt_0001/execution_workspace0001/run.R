data <- read.csv("input.csv")

d <- data[data$score > -1 & data$score < 1, ]
n <- nrow(d)

x <- d$score
z <- as.numeric(x >= 0)
w <- 1 - abs(x)

# Fit the same weighted local-linear model to each outcome.
fit_discontinuities <- function(y) {
  X <- cbind(intercept = 1, right = z, score_left = x,
             score_right = z * x)
  bread <- solve(crossprod(X, w * X))
  beta <- bread %*% crossprod(X, w * y)
  residuals <- y - as.vector(X %*% beta)
  meat <- crossprod(X, (w * residuals)^2 * X)
  vcov <- bread %*% meat %*% bread
  list(discontinuity = beta[2, 1], variance = vcov[2, 2])
}

rf <- fit_discontinuities(d$earnings)
fs <- fit_discontinuities(d$participated)

# HC0 covariance between outcome discontinuity estimates, using shared observations.
X <- cbind(intercept = 1, right = z, score_left = x,
           score_right = z * x)
bread <- solve(crossprod(X, w * X))
beta_y <- bread %*% crossprod(X, w * d$earnings)
beta_d <- bread %*% crossprod(X, w * d$participated)
resid_y <- d$earnings - as.vector(X %*% beta_y)
resid_d <- d$participated - as.vector(X %*% beta_d)
meat_yd <- crossprod(X, (w^2 * resid_y * resid_d) * X)
vcov_yd <- bread %*% meat_yd %*% bread
cov_rf_fs <- vcov_yd[2, 2]

tau <- rf$discontinuity / fs$discontinuity
se_tau <- sqrt(rf$variance / fs$discontinuity^2 +
               rf$discontinuity^2 * fs$variance / fs$discontinuity^4 -
               2 * rf$discontinuity * cov_rf_fs / fs$discontinuity^3)

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = as.numeric(tau),
         se = as.numeric(se_tau), n_obs = as.integer(n)),
    list(term = "reduced_form", estimate = as.numeric(rf$discontinuity),
         se = sqrt(rf$variance), n_obs = as.integer(n)),
    list(term = "first_stage", estimate = as.numeric(fs$discontinuity),
         se = sqrt(fs$variance), n_obs = as.integer(n))
  ),
  method_metadata = list(
    estimator = "Triangular-weighted local-linear fuzzy regression discontinuity",
    vcov = "HC0, no degrees-of-freedom correction; delta method with joint covariance"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = 15,
                     pretty = TRUE, na = "null")
