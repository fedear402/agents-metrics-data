library(jsonlite)

d <- read.csv("input.csv", stringsAsFactors = FALSE)

required <- c("region_id", "industry_id", "share", "shock",
              "region_weight", "x", "y")
if (!all(required %in% names(d))) stop("input.csv is missing required columns")

# Use one row per region for regional variables and weights.
regions <- unique(d[c("region_id", "region_weight", "x", "y")])
if (anyDuplicated(regions$region_id)) {
  stop("region_weight, x, or y is not constant within region")
}
regions$e <- regions$region_weight / sum(regions$region_weight)

# Build the region-industry share and shock matrices.
region_ids <- regions$region_id
industry_ids <- unique(d$industry_id)
R <- length(region_ids)
N <- length(industry_ids)

share_mat <- matrix(0, nrow = R, ncol = N,
                    dimnames = list(as.character(region_ids),
                                    as.character(industry_ids)))
for (i in seq_len(nrow(d))) {
  r <- match(d$region_id[i], region_ids)
  n <- match(d$industry_id[i], industry_ids)
  share_mat[r, n] <- d$share[i]
}

if (any(abs(rowSums(share_mat) - 1) > 1e-8)) {
  stop("baseline employment shares must sum to one within region")
}

shock_by_industry <- vapply(industry_ids, function(id) {
  vals <- unique(d$shock[d$industry_id == id])
  if (length(vals) != 1L) stop("shock must be constant within industry")
  vals
}, numeric(1))

e <- regions$e
x <- regions$x
y <- regions$y
z <- drop(share_mat %*% shock_by_industry)

weighted_center <- function(v) v - sum(e * v)
x0 <- weighted_center(x)
y0 <- weighted_center(y)
z0 <- weighted_center(z)

mass <- drop(crossprod(e, share_mat))
if (any(mass <= 0)) stop("each industry must have positive exposure mass")

aggregate_residual <- function(v0) {
  drop(crossprod(share_mat, e * v0)) / mass
}
xbar <- aggregate_residual(x0)
ybar <- aggregate_residual(y0)
zbar <- aggregate_residual(z0)

# Shock-level IV with analytic exposure weights and HC1 covariance.
shock_iv <- function(dependent, endogenous) {
  X <- cbind(intercept = 1, endogenous = endogenous)
  Q <- cbind(intercept = 1, shock = shock_by_industry)
  W <- diag(mass, nrow = N, ncol = N)

  A <- crossprod(Q, W %*% X)
  beta <- solve(A, crossprod(Q, W %*% dependent))
  residual <- drop(dependent - X %*% beta)

  # HC1 sandwich for the weighted IV moment conditions.
  scores <- Q * drop(mass * residual)
  Ainv <- solve(A)
  meat <- crossprod(scores)
  vcov <- (N / (N - 2)) * Ainv %*% meat %*% t(Ainv)

  c(estimate = beta[2], se = sqrt(vcov[2, 2]))
}

effect <- shock_iv(ybar, xbar)
first_stage <- shock_iv(xbar, zbar)

# Confirm both shock-level slopes equal the regional weighted slopes.
regional_effect <- sum(e * z0 * y0) / sum(e * z0 * x0)
regional_first_stage <- sum(e * z0 * x0) / sum(e * z0^2)
if (max(abs(c(effect["estimate"], first_stage["estimate"]) -
           c(regional_effect, regional_first_stage))) > 1e-8) {
  stop("shock-level and regional slope calculations do not agree")
}

effective_shocks <- 1 / sum(mass^2)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect",
         estimate = unname(as.numeric(effect["estimate"])),
         se = unname(as.numeric(effect["se"])),
         n_obs = as.integer(N)),
    list(term = "first_stage",
         estimate = unname(as.numeric(first_stage["estimate"])),
         se = unname(as.numeric(first_stage["se"])),
         n_obs = as.integer(N)),
    list(term = "effective_shocks",
         estimate = unname(as.numeric(effective_shocks)),
         se = NULL,
         n_obs = as.integer(N))
  ),
  method_metadata = list(
    estimator = "Weighted regional 2SLS with shock-level IV aggregation",
    vcov = "Shock-level analytic-weight HC1 sandwich, structural IV residuals"
  ),
  diagnostics = list(
    regions = as.integer(R),
    industries = as.integer(N),
    shock_slopes_match_regional = TRUE
  )
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16,
           pretty = TRUE)
