library(jsonlite)

data <- read.csv("input.csv")

# Use one row per region to normalize regional weights and verify repeated values.
regions <- unique(data[c("region_id", "region_weight", "x", "y")])
e <- regions$region_weight / sum(regions$region_weight)

region_ids <- regions$region_id
industry_ids <- unique(data$industry_id)
N <- length(industry_ids)

# Build region-by-industry share and shock arrays.
share_matrix <- matrix(0, nrow = length(region_ids), ncol = N,
                       dimnames = list(as.character(region_ids),
                                       as.character(industry_ids)))
for (i in seq_len(nrow(data))) {
  share_matrix[as.character(data$region_id[i]),
               as.character(data$industry_id[i])] <- data$share[i]
}
shock <- vapply(industry_ids, function(ind) {
  vals <- unique(data$shock[data$industry_id == ind])
  if (length(vals) != 1L) stop("shock must be constant within industry")
  vals
}, numeric(1))

z <- drop(share_matrix %*% shock)
y <- regions$y
x <- regions$x

weighted_center <- function(v) v - sum(e * v)
y0 <- weighted_center(y)
x0 <- weighted_center(x)
z0 <- weighted_center(z)

mass <- drop(crossprod(e, share_matrix))
aggregate_residual <- function(v0) {
  drop(crossprod(share_matrix, e * v0)) / mass
}

ybar <- aggregate_residual(y0)
xbar <- aggregate_residual(x0)
zbar <- aggregate_residual(z0)

# Shock-level IV slope and HC1 covariance using structural residuals.
shock_iv <- function(dependent, endogenous) {
  regressors <- cbind(1, endogenous)
  instruments <- cbind(1, shock)
  cross <- crossprod(instruments, mass * regressors)
  beta <- solve(cross, crossprod(instruments, mass * dependent))
  residual <- drop(dependent - regressors %*% beta)
  scores <- instruments * (mass * residual)
  inverse <- solve(cross)
  covariance <- (N / (N - 2)) * inverse %*% crossprod(scores) %*% t(inverse)
  c(estimate = beta[2], se = sqrt(covariance[2, 2]))
}

effect <- shock_iv(ybar, xbar)
first_stage <- shock_iv(xbar, zbar)
effective_shocks <- 1 / sum(mass^2)

output <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = unname(effect["estimate"]),
         se = unname(effect["se"]), n_obs = as.integer(N)),
    list(term = "first_stage", estimate = unname(first_stage["estimate"]),
         se = unname(first_stage["se"]), n_obs = as.integer(N)),
    list(term = "effective_shocks", estimate = unname(effective_shocks),
         se = NULL, n_obs = as.integer(N))
  ),
  method_metadata = list(
    estimator = "Weighted regional 2SLS with Borusyak-Hull-Jaravel shock-level aggregation",
    vcov = "Shock-level HC1 using structural IV residuals and analytic weights"
  ),
  diagnostics = list()
)

write_json(output, "result.json", auto_unbox = TRUE, null = "null",
           digits = 16, pretty = TRUE)
