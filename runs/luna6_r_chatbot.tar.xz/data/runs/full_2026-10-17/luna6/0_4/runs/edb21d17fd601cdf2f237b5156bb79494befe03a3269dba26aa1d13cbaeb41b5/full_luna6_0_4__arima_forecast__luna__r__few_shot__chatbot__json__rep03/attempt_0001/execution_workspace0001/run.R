library(jsonlite)

data <- read.csv("./input.csv")
y <- data$y

fit <- stats::arima(
  y,
  order = c(1, 1, 1),
  include.mean = FALSE,
  method = "ML"
)

prediction <- predict(fit, n.ahead = 1)
forecast_value <- unname(prediction$pred[1])
forecast_se <- unname(prediction$se[1])

n_obs <- length(y)
out <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = list(
    list(term = "forecast", estimate = forecast_value,
         se = forecast_se, n_obs = n_obs),
    list(term = "lower_95", estimate = forecast_value - qnorm(0.975) * forecast_se,
         se = NA, n_obs = n_obs),
    list(term = "upper_95", estimate = forecast_value + qnorm(0.975) * forecast_se,
         se = NA, n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "ARIMA(1,1,1) by maximum likelihood, no constant or drift",
    vcov = "Model-based one-step-ahead prediction variance"
  ),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "result.json", auto_unbox = TRUE, na = "null", digits = 15)
