d <- read.csv("input.csv")
n <- nrow(d)
q <- 2L
df <- n - 4L
critical <- qf(0.95, q, df)
k <- q * critical / df

fit_resid <- function(formula, data) residuals(lm(formula, data = data))

ry <- fit_resid(y ~ x, d)
rd <- fit_resid(endog ~ x, d)
uy <- fit_resid(y ~ x + z1 + z2, d)
ud <- fit_resid(endog ~ x + z1 + z2, d)

A <- sum(rd^2) - (1 + k) * sum(ud^2)
B <- -2 * (sum(ry * rd) - (1 + k) * sum(uy * ud))
C <- sum(ry^2) - (1 + k) * sum(uy^2)

disc <- B^2 - 4 * A * C
if (!is.finite(disc) || disc < 0 || abs(A) < 1e-12) {
  stop("The AR confidence set does not have two finite boundary points.")
}
bounds <- sort(Re(polyroot(c(C, B, A))))
accepts <- function(beta) A * beta^2 + B * beta + C <= 0

transformed <- d$y - d$endog
fit_r <- lm(transformed ~ x, data = d)
fit_u <- lm(transformed ~ x + z1 + z2, data = d)
ar_f_at_one <- ((deviance(fit_r) - deviance(fit_u)) / q) /
  (deviance(fit_u) / df)

rows <- list(
  list(term = "boundary_low", estimate = unname(bounds[1]), se = NULL, n_obs = n),
  list(term = "boundary_high", estimate = unname(bounds[2]), se = NULL, n_obs = n),
  list(term = "accepts_zero", estimate = as.integer(accepts(0)), se = NULL, n_obs = n),
  list(term = "unbounded", estimate = as.integer(A < 0), se = NULL, n_obs = n),
  list(term = "ar_f_at_one", estimate = unname(ar_f_at_one), se = NULL, n_obs = n)
)

jsonlite::write_json(
  list(
    task_id = "broad_ar_confidence_set",
    platform = "r",
    estimates = rows,
    method_metadata = list(
      estimator = "Anderson-Rubin inversion of the homoskedastic joint F test",
      vcov = "Conventional homoskedastic"
    ),
    diagnostics = list()
  ),
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
