crosswalk <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
trade <- read.csv("trade.csv", stringsAsFactors = FALSE)
areas <- read.csv("areas.csv", stringsAsFactors = FALSE)
employment <- read.csv("employment.csv", stringsAsFactors = FALSE)
outcomes <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

trade <- merge(trade, crosswalk, by = "code", all.x = TRUE, sort = FALSE)

periods <- unique(areas$period)
industries <- unique(crosswalk$industry)

exposures <- list()
for (p in periods) {
  area_period <- areas[areas$period == p, , drop = FALSE]
  trade_period <- trade[trade$period == p, , drop = FALSE]

  for (vintage in c("base", "early")) {
    emp_vintage <- employment[
      employment$period == p & employment$vintage == vintage,
      , drop = FALSE
    ]

    national <- vapply(industries, function(ind) {
      sum(emp_vintage$employment[emp_vintage$industry == ind], na.rm = TRUE)
    }, numeric(1))
    names(national) <- as.character(industries)

    trade_column <- if (vintage == "base") "us_change" else "other_change"
    trade_by_industry <- setNames(
      trade_period[[trade_column]],
      as.character(trade_period$industry)
    )

    exp_values <- vapply(area_period$area, function(a) {
      a_emp <- emp_vintage[emp_vintage$area == a, , drop = FALSE]
      emp_by_industry <- setNames(
        a_emp$employment,
        as.character(a_emp$industry)
      )
      emp_by_industry <- emp_by_industry[!duplicated(names(emp_by_industry))]

      numerator <- sum(vapply(industries, function(ind) {
        area_emp <- if (as.character(ind) %in% names(emp_by_industry)) {
          emp_by_industry[[as.character(ind)]]
        } else {
          0
        }
        area_emp / national[[as.character(ind)]] *
          trade_by_industry[[as.character(ind)]]
      }, numeric(1)))

      total <- area_period$total_employment[area_period$area == a][1]
      price <- trade_period$price_index[1]
      years <- trade_period$years[1]
      numerator / total / (price / 100) / 1000 * (10 / years)
    }, numeric(1))

    exposures[[paste(p, vintage, sep = "_")]] <- data.frame(
      area = area_period$area,
      period = p,
      vintage = vintage,
      exposure = exp_values
    )
  }
}

base_exposure <- do.call(rbind, exposures[grepl("_base$", names(exposures))])
early_exposure <- do.call(rbind, exposures[grepl("_early$", names(exposures))])
names(base_exposure)[names(base_exposure) == "exposure"] <- "x"
names(early_exposure)[names(early_exposure) == "exposure"] <- "z"

data <- merge(outcomes, areas[areas$vintage == "base", ], by = c("area", "period"))
data <- merge(data, base_exposure[, c("area", "period", "x")],
              by = c("area", "period"))
data <- merge(data, early_exposure[, c("area", "period", "z")],
              by = c("area", "period"))

data$period_reg <- as.numeric(factor(data$period))
X <- cbind(intercept = 1, period = data$period_reg,
           control = data$control, x = data$x)
Z <- cbind(intercept = 1, period = data$period_reg,
           control = data$control, z = data$z)
w <- data$population

Xw <- X * sqrt(w)
Zw <- Z * sqrt(w)
yw <- data$change_pp * sqrt(w)
projected_X <- qr.fitted(qr(Zw), Xw)
coef <- qr.coef(qr(projected_X), yw)
iv_slope <- unname(coef["x"])

area0 <- unique(areas$area)[1]
period0 <- periods[1]
period1 <- periods[2]
exposure_area0_period0 <- base_exposure$x[
  base_exposure$area == area0 & base_exposure$period == period0
][1]
exposure_area0_period1 <- base_exposure$x[
  base_exposure$area == area0 & base_exposure$period == period1
][1]
instrument_area0_period0 <- early_exposure$z[
  early_exposure$area == area0 & early_exposure$period == period0
][1]

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = list(
    list(term = "iv_slope", estimate = as.numeric(iv_slope),
         se = NULL, n_obs = 72L),
    list(term = "exposure_area0_period0",
         estimate = as.numeric(exposure_area0_period0),
         se = NULL, n_obs = 72L),
    list(term = "exposure_area0_period1",
         estimate = as.numeric(exposure_area0_period1),
         se = NULL, n_obs = 72L),
    list(term = "instrument_area0_period0",
         estimate = as.numeric(instrument_area0_period0),
         se = NULL, n_obs = 72L)
  ),
  method_metadata = list(
    method = "Weighted two-stage least squares",
    outcome = "change_pp",
    endogenous_regressor = "x",
    excluded_instrument = "z",
    exogenous_regressors = c("intercept", "period", "control"),
    weight = "base-vintage population",
    exposure_units = "thousands of real dollars per worker per decade"
  ),
  diagnostics = list(n_obs = 72L)
)

jsonlite::write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  digits = 12,
  null = "null",
  pretty = TRUE
)
