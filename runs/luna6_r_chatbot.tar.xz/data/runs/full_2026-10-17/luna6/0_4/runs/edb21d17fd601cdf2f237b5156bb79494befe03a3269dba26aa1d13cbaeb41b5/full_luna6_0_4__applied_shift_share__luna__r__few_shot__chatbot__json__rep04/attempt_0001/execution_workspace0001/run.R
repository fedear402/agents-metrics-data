library(jsonlite)

dat <- read.csv("input.csv", stringsAsFactors = FALSE)

# Use one row per region to normalize regional analysis weights.
regions <- unique(dat[c("region_id", "region_weight", "x", "y")])
e <- regions$region_weight / sum(regions$region_weight)

# Build region-by-industry share and shock matrices.
region_ids <- regions$region_id
industry_ids <- unique(dat$industry_id)
R <- length(region_ids)
N <- length(industry_ids)

share_mat <- matrix(0, nrow = R, ncol = N,
                    dimnames = list(as.character(region_ids), as.character(industry_ids)))
shock <- numeric(N)
names(shock) <- as.character(industry_ids)

for (i in seq_len(nrow(dat))) {
  r <- match(dat$region_id[i], region_ids)
  n <- match(dat$industry_id[i], industry_ids)
  share_mat[r, n] <- dat$share[i]
  shock[n] <- dat$shock[i]
}

x <- regions$x
y <- regions$y
z <- drop(share_mat %*% shock)

# Center regional variables using normalized regional weights.
weighted_mean <- function(v) sum(e * v)
y0 <- y - weighted_mean(y)
x0 <- x - weighted_mean(x)
z0 <- z - weighted_mean(z)

# Industry exposure masses and exposure-weighted regional residual means.
s <- drop(crossprod(e, share_mat))
aggregate_by_industry <- function(v0) {
  drop(crossprod(share_mat, e * v0)) / s
}
ybar <- aggregate_by_industry(y0)
xbar <- aggregate_by_industry(x0)
zbar <- aggregate_by_industry(z0)

# Weighted shock-level IV with an intercept and one excluded instrument.
shock_iv <- function(dependent, endogenous) {
  regressors <- cbind(1, endogenous)
  instruments <- cbind(1, shock)
  cross <- crossprod(instruments, s * regressors)
  beta <- solve(cross, crossprod(instruments, s * dependent))
  residual <- drop(dependent - regressors %*% beta)
  scores <- instruments * (s * residual)
  inverse <- solve(cross)
  covariance <- (N / (N - 2)) * inverse %*% crossprod(scores) %*% t(inverse)
  c(slope = beta[2], se = sqrt(covariance[2, 2]))
}

effect <- shock_iv(ybar, xbar)
first_stage <- shock_iv(xbar, zbar)
effective_shocks <- 1 / sum(s^2)

rows <- list(
  list(term = "effect", estimate = unname(effect["slope"]),
       se = unname(effect["se"]), n_obs = as.integer(N)),
  list(term = "first_stage", estimate = unname(first_stage["slope"]),
       se = unname(first_stage["se"]), n_obs = as.integer(N)),
  list(term = "effective_shocks", estimate = unname(effective_shocks),
       se = NULL, n_obs = as.integer(N))
)

write_json(
  list(
    task_id = "applied_shift_share",
    platform = "r",
    estimates = rows,
    method_metadata = list(
      estimator = "Weighted regional 2SLS with Borusyak-Hull-Jaravel shock-level aggregation",
      vcov = "Shock-level analytic-weight HC1, structural IV residuals, no clustering"
    ),
    diagnostics = list()
  ),
  "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE
)
