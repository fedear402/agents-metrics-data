d <- read.csv("input.csv", stringsAsFactors = FALSE)

# Collapse repeated region-level values, and normalize weights once per region.
regions <- unique(d[c("region_id", "region_weight", "x", "y")])
regions$e <- regions$region_weight / sum(regions$region_weight)

# Build the regional instrument from all region-industry rows.
z_by_region <- aggregate(
  share * shock ~ region_id,
  data = d,
  FUN = sum
)
names(z_by_region)[2] <- "z"
r <- merge(regions, z_by_region, by = "region_id", sort = FALSE)

# Center each regional variable using normalized regional weights.
weighted_mean <- function(v, w) sum(w * v)
r$y0 <- r$y - weighted_mean(r$y, r$e)
r$x0 <- r$x - weighted_mean(r$x, r$e)
r$z0 <- r$z - weighted_mean(r$z, r$e)

# Aggregate centered variables to industries using exposure weights.
d <- merge(d, r[c("region_id", "e", "y0", "x0", "z0")],
           by = "region_id", sort = FALSE)
d$exposure <- d$e * d$share

industry <- aggregate(
  cbind(exposure, exposure_y0 = exposure * y0,
        exposure_x0 = exposure * x0, exposure_z0 = exposure * z0) ~ industry_id,
  data = d,
  FUN = sum
)
industry$shock <- vapply(industry$industry_id, function(id) {
  unique(d$shock[d$industry_id == id])[1]
}, numeric(1))
industry$ybar <- industry$exposure_y0 / industry$exposure
industry$xbar <- industry$exposure_x0 / industry$exposure
industry$zbar <- industry$exposure_z0 / industry$exposure

N <- nrow(industry)
s <- industry$exposure

# Weighted IV slope and HC1 shock-level standard error, using structural residuals.
iv_hc1 <- function(y, x, instrument, w) {
  X <- cbind(1, x)
  Z <- cbind(1, instrument)
  A <- solve(crossprod(Z, w * X))
  beta <- A %*% crossprod(Z, w * y)
  u <- as.numeric(y - X %*% beta)
  meat <- crossprod(Z, (w * u)^2 * Z)
  V <- A %*% meat %*% t(A) * N / (N - 2)
  c(estimate = beta[2], se = sqrt(V[2, 2]))
}

effect <- iv_hc1(industry$ybar, industry$xbar, industry$shock, s)
first_stage <- iv_hc1(industry$xbar, industry$zbar, industry$shock, s)
effective_shocks <- 1 / sum(s^2)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = unname(effect["estimate"]),
         se = unname(effect["se"]), n_obs = N),
    list(term = "first_stage", estimate = unname(first_stage["estimate"]),
         se = unname(first_stage["se"]), n_obs = N),
    list(term = "effective_shocks", estimate = effective_shocks,
         se = NULL, n_obs = N)
  ),
  method_metadata = list(
    estimator = "Borusyak-Hull-Jaravel shock-level weighted IV",
    vcov = "Shock-level HC1, analytic exposure weights, multiplier N/(N-2)"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = 16,
                     null = "null", pretty = TRUE)
