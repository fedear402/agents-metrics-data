library(jsonlite)

households <- read.csv("households.csv", stringsAsFactors = FALSE)
census <- read.csv("census.csv", stringsAsFactors = FALSE)

d <- households[households$recipient == 0, , drop = FALSE]
n_obs <- as.integer(nrow(d))

ineligible <- 1 - d$eligible
eligible <- d$eligible

# The four group-specific columns form the exogenous design.
X <- cbind(
  ineligible = ineligible,
  eligible = eligible,
  baseline_ineligible = d$baseline * ineligible,
  baseline_eligible = d$baseline * eligible,
  dose_ineligible = d$dose * ineligible,
  dose_eligible = d$dose * eligible
)

# Included exogenous columns plus the two excluded instruments.
Z <- cbind(
  ineligible = ineligible,
  eligible = eligible,
  baseline_ineligible = d$baseline * ineligible,
  baseline_eligible = d$baseline * eligible,
  instrument_ineligible = d$instrument * ineligible,
  instrument_eligible = d$instrument * eligible
)

w <- d$weight
sqrt_w <- sqrt(w)
Xw <- X * sqrt_w
Zw <- Z * sqrt_w
yw <- d$outcome * sqrt_w

# Weighted 2SLS: project the full regressor matrix onto the instrument
# space, then estimate the structural equation using the weighted data.
qr_Zw <- qr(Zw)
Xhat_w <- qr.fitted(qr_Zw, Xw)
beta <- solve(crossprod(Xhat_w, Xw), crossprod(Xhat_w, yw))
names(beta) <- colnames(X)

weighted_mean <- function(x, group) {
  sum(w[group] * x[group]) / sum(w[group])
}

ineligible_dose_mean <- weighted_mean(d$dose, d$eligible == 0)
eligible_dose_mean <- weighted_mean(d$dose, d$eligible == 1)

ineligible_effect <- unname(beta["dose_ineligible"] * ineligible_dose_mean)
eligible_nonrecipient_effect <- unname(beta["dose_eligible"] * eligible_dose_mean)

population <- setNames(
  census$nonrecipient_population,
  as.character(census$eligible)
)
population_effect <- (
  ineligible_effect * population[["0"]] +
    eligible_nonrecipient_effect * population[["1"]]
) / (population[["0"]] + population[["1"]])

result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = list(
    list(term = "ineligible_effect", estimate = ineligible_effect, se = NULL, n_obs = n_obs),
    list(term = "eligible_nonrecipient_effect", estimate = eligible_nonrecipient_effect, se = NULL, n_obs = n_obs),
    list(term = "population_effect", estimate = population_effect, se = NULL, n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "weighted two-stage least squares",
    endogenous_columns = c("dose*(1-eligible)", "dose*eligible"),
    exogenous_columns = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"),
    instruments = c(
      "1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible",
      "instrument*(1-eligible)", "instrument*eligible"
    ),
    regression_weight = "weight",
    counterfactual = "dose set to zero for every retained household",
    attribution_convention = "The group effect is the fitted dose slope times the household-weighted mean dose. Attribution to a zero-dose counterfactual is a stated synthetic convention.",
    aggregation_weights = "nonrecipient_population from census.csv; used only for final between-group aggregation"
  ),
  diagnostics = list(
    retained_households = n_obs,
    sample = "All rows with recipient=0, including ineligible households in both village treatment statuses",
    ineligible_weighted_mean_dose = ineligible_dose_mean,
    eligible_weighted_mean_dose = eligible_dose_mean
  )
)

write_json(result, "result.json", auto_unbox = TRUE, digits = 17, null = "null")
