library(jsonlite)

data <- read.csv("./input.csv")
y <- as.numeric(data$y)

fit <- stats::arima(
  y,
  order = c(1, 1, 1),
  include.mean = FALSE,
  method = "ML"
)

pred <- predict(fit, n.ahead = 1)
forecast <- unname(pred$pred[1])
se <- unname(pred$se[1])

n_obs <- length(y)
out <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = list(
    list(term = "forecast", estimate = forecast, se = se, n_obs = n_obs),
    list(term = "lower_95", estimate = forecast - qnorm(0.975) * se,
         se = NA_real_, n_obs = n_obs),
    list(term = "upper_95", estimate = forecast + qnorm(0.975) * se,
         se = NA_real_, n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "ARIMA(1,1,1) by maximum likelihood, no drift",
    vcov = "Model-based forecast variance"
  ),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "result.json", auto_unbox = TRUE, na = "null", digits = 15)
