files <- list(
  households = read.csv("households.csv"),
  census = read.csv("census.csv")
)

d <- subset(files$households, recipient == 0)
census <- files$census

# Fit weighted 2SLS with group-specific dose slopes and group-specific
# baseline coefficients. The instrument set contains the exogenous columns
# and the two group-specific excluded instruments.
g0 <- 1 - d$eligible
g1 <- d$eligible

X <- cbind(
  g0 = g0,
  g1 = g1,
  baseline_g0 = d$baseline * g0,
  baseline_g1 = d$baseline * g1,
  dose_g0 = d$dose * g0,
  dose_g1 = d$dose * g1
)

Z <- cbind(
  g0,
  g1,
  baseline_g0 = d$baseline * g0,
  baseline_g1 = d$baseline * g1,
  instrument_g0 = d$instrument * g0,
  instrument_g1 = d$instrument * g1
)

sqrt_w <- sqrt(d$weight)
Xw <- X * sqrt_w
Zw <- Z * sqrt_w
yw <- d$outcome * sqrt_w

Xhat <- qr.fitted(qr(Zw), Xw)
beta <- as.numeric(qr.coef(qr(Xhat), yw))
names(beta) <- colnames(X)

mean_dose <- vapply(0:1, function(g) {
  idx <- d$eligible == g
  weighted.mean(d$dose[idx], d$weight[idx])
}, numeric(1))

effects <- c(
  ineligible_effect = beta["dose_g0"] * mean_dose[1],
  eligible_nonrecipient_effect = beta["dose_g1"] * mean_dose[2]
)

census_weights <- census$nonrecipient_population[
  match(0:1, census$eligible)
]
population_effect <- weighted.mean(effects, census_weights)

n_obs <- nrow(d)

estimates <- list(
  list(term = "ineligible_effect", estimate = unname(effects[1]),
       se = NULL, n_obs = n_obs),
  list(term = "eligible_nonrecipient_effect", estimate = unname(effects[2]),
       se = NULL, n_obs = n_obs),
  list(term = "population_effect", estimate = unname(population_effect),
       se = NULL, n_obs = n_obs)
)

result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "weighted 2SLS",
    sample = "all households with recipient = 0",
    endogenous_columns = c("dose*(1-eligible)", "dose*eligible"),
    exogenous_columns = c(
      "1-eligible", "eligible",
      "baseline*(1-eligible)", "baseline*eligible"
    ),
    instruments = c(
      "1-eligible", "eligible",
      "baseline*(1-eligible)", "baseline*eligible",
      "instrument*(1-eligible)", "instrument*eligible"
    ),
    counterfactual = "dose set to zero for every retained household",
    attribution_convention = "synthetic zero-dose counterfactual",
    group_effect = "fitted dose slope multiplied by household-weighted mean dose",
    population_weights = "census nonrecipient_population; used only for final group aggregation"
  ),
  diagnostics = list(
    n_obs = n_obs,
    retained_households = n_obs,
    group_counts = list(
      ineligible = sum(d$eligible == 0),
      eligible = sum(d$eligible == 1)
    )
  )
)

jsonlite::write_json(
  result,
  path = "result.json",
  auto_unbox = TRUE,
  digits = 15,
  null = "null",
  pretty = TRUE
)
