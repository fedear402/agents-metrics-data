# Fit ARIMA(1,1,1) by maximum likelihood, with no constant or drift.
dat <- read.csv("./input.csv")
if (!"y" %in% names(dat)) stop("input.csv must contain a column named y")
y <- as.numeric(dat$y)
if (length(y) < 3L || any(!is.finite(y))) stop("y must contain at least three finite observations")

fit <- stats::arima(
  y,
  order = c(1, 1, 1),
  include.mean = FALSE,
  method = "ML"
)

# The one-step forecast is for the next observation, t = 251.
fc <- stats::predict(fit, n.ahead = 1L)
forecast <- as.numeric(fc$pred[1L])
se <- as.numeric(fc$se[1L])
z <- stats::qnorm(0.975)
lower <- forecast - z * se
upper <- forecast + z * se
n <- length(y)

estimates <- data.frame(
  term = c("forecast", "lower_95", "upper_95"),
  estimate = c(forecast, lower, upper),
  se = c(se, NA_real_, NA_real_),
  n_obs = rep(n, 3L)
)

result <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = lapply(seq_len(nrow(estimates)), function(i) {
    list(
      term = estimates$term[i],
      estimate = estimates$estimate[i],
      se = if (is.na(estimates$se[i])) NULL else estimates$se[i],
      n_obs = estimates$n_obs[i]
    )
  }),
  method_metadata = list(
    estimator = "ARIMA(1,1,1) maximum likelihood, no constant or drift",
    vcov = "Model-based one-step-ahead prediction variance"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, pretty = TRUE, na = "null", null = "null")
