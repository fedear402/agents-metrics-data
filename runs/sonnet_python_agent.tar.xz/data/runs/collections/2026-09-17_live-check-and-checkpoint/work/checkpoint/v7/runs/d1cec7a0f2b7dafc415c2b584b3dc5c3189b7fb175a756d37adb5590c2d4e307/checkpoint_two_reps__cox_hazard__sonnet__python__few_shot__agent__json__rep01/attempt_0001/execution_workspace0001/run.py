import json
import numpy as np
import pandas as pd
from statsmodels.duration.hazard_regression import PHReg

df = pd.read_csv("./input.csv")

mod = PHReg(df["t_obs"], df[["treat", "x"]], status=df["event"])
fit = mod.fit()

names = fit.model.exog_names
params = fit.params
bse = fit.bse
n_obs = len(df)

idx_treat = names.index("treat")
idx_x = names.index("x")

treat_est = float(params[idx_treat])
treat_se = float(bse[idx_treat])
x_est = float(params[idx_x])
x_se = float(bse[idx_x])

out = {
    "task_id": "cox_hazard",
    "platform": "python",
    "estimates": [
        {"term": "treat", "estimate": treat_est, "se": treat_se, "n_obs": n_obs},
        {"term": "x", "estimate": x_est, "se": x_se, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "Cox proportional hazards",
        "vcov": "model-based (asymptotic)"
    },
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(out, f, indent=2)

print("treat:", treat_est, "se:", treat_se)
print("x:", x_est, "se:", x_se)
print("n_obs:", n_obs)
