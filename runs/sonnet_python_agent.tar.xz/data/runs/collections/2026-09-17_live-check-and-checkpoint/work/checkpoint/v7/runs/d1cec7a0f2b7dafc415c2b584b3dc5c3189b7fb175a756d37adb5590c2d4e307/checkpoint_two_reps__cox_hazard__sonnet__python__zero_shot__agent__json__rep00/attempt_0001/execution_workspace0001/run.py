import pandas as pd
import numpy as np
import json
from statsmodels.duration.hazard_regression import PHReg

# Load data
df = pd.read_csv("input.csv")
n_obs = len(df)

# Fit Cox PH model (Breslow tie-handling)
model = PHReg(
    endog=df["t_obs"],
    exog=df[["treat", "x"]],
    status=df["event"],
    ties="breslow"
)
result = model.fit(disp=False)

# params and bse are positional arrays: [treat, x]
params = result.params   # numpy array
bse    = result.bse      # numpy array

estimates = [
    {"term": "treat", "estimate": float(params[0]), "se": float(bse[0]), "n_obs": n_obs},
    {"term": "x",     "estimate": float(params[1]), "se": float(bse[1]), "n_obs": n_obs},
]

output = {
    "task_id": "cox_hazard",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "Cox proportional hazards (partial likelihood)",
        "vcov": "model-based (inverse observed information)"
    },
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(output, f, indent=2)

print("Estimates:")
for e in estimates:
    print(f"  {e['term']}: coef={e['estimate']:.8f}, se={e['se']:.8f}")
print(f"n_obs = {n_obs}")
