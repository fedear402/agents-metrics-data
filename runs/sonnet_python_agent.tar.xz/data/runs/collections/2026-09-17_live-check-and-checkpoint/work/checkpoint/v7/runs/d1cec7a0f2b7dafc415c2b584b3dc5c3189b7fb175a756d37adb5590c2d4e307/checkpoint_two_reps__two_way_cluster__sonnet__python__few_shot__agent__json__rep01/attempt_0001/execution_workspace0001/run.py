import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("./input.csv")

y = df["y_twocluster"].values
X = sm.add_constant(df[["x"]]).values
n, k = X.shape

# OLS fit
fit = sm.OLS(y, X).fit()
beta = fit.params
e = np.array(fit.resid)

# Cameron-Gelbach-Miller two-way clustering on firm and year
# V_cgm = V_firm + V_year - V_firm_year
def meatXX(cluster_ids, X, e):
    """Compute sum_g (X'e within g)(X'e within g)' for cluster_ids."""
    scores = X * e[:, None]  # n x k
    df_scores = pd.DataFrame(scores)
    df_scores["_cid"] = cluster_ids
    grouped = df_scores.groupby("_cid").sum().values  # G x k
    return grouped.T @ grouped

XtX_inv = np.linalg.inv(X.T @ X)

def sandwich(meat):
    return XtX_inv @ meat @ XtX_inv

# Cluster on firm
meat_firm = meatXX(df["firm"].values, X, e)
# Cluster on year
meat_year = meatXX(df["year"].values, X, e)
# Cluster on firm x year (intersection) - each obs is its own "cluster"
meat_int = meatXX(df["firm"].astype(str) + "_" + df["year"].astype(str), X, e)

V_cgm = sandwich(meat_firm + meat_year - meat_int)
se_cgm = np.sqrt(np.diag(V_cgm))

n_obs = int(fit.nobs)

out = {
    "task_id": "two_way_cluster",
    "platform": "python",
    "estimates": [
        {"term": "const", "estimate": float(beta[0]), "se": float(se_cgm[0]), "n_obs": n_obs},
        {"term": "x",     "estimate": float(beta[1]), "se": float(se_cgm[1]), "n_obs": n_obs},
    ],
    "method_metadata": {"estimator": "OLS", "vcov": "two-way cluster-robust (CGM)"},
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(out, f, indent=2)

print(json.dumps(out, indent=2))
