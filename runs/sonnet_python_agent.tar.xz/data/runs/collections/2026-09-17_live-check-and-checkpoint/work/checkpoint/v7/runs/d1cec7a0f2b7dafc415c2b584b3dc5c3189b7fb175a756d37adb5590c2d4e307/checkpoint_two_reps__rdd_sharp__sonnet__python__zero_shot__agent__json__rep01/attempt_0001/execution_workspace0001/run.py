import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

df = pd.read_csv("input.csv")

# Bandwidth and cutoff
h = 0.5
cutoff = 0.0

# Triangular kernel weights: K(u) = (1 - |u|) for |u| <= 1
# u = (z - cutoff) / h
df["u"] = (df["z"] - cutoff) / h
df["w"] = np.where(np.abs(df["u"]) <= 1, 1 - np.abs(df["u"]), 0)

# Keep only observations within bandwidth with positive weight
left = df[(df["z"] < cutoff) & (df["w"] > 0)].copy()
right = df[(df["z"] >= cutoff) & (df["w"] > 0)].copy()

n_left = len(left)
n_right = len(right)
n_obs = n_left + n_right

# Local linear regression on left side
X_left = sm.add_constant(left["z"])
wls_left = sm.WLS(left["y"], X_left, weights=left["w"]).fit()
intercept_left = wls_left.params["const"]

# Local linear regression on right side
X_right = sm.add_constant(right["z"])
wls_right = sm.WLS(right["y"], X_right, weights=right["w"]).fit()
intercept_right = wls_right.params["const"]

# LATE = jump at cutoff = right intercept - left intercept
late = intercept_right - intercept_left

print(f"Left n: {n_left}, Right n: {n_right}, Total n: {n_obs}")
print(f"Intercept left: {intercept_left:.8f}")
print(f"Intercept right: {intercept_right:.8f}")
print(f"LATE: {late:.8f}")

# SE via delta method / combined regression
# Fit a single pooled regression with interaction to get SE of jump
df_bw = df[df["w"] > 0].copy()
df_bw["above"] = (df_bw["z"] >= cutoff).astype(float)
df_bw["z_above"] = df_bw["z"] * df_bw["above"]

X_pooled = df_bw[["above", "z", "z_above"]].copy()
X_pooled.insert(0, "const", 1.0)

wls_pooled = sm.WLS(df_bw["y"], X_pooled, weights=df_bw["w"]).fit()
print("\nPooled regression:")
print(wls_pooled.summary())

late_se = wls_pooled.bse["above"]
late_est = wls_pooled.params["above"]

print(f"\nLATE from pooled: {late_est:.8f}, SE: {late_se:.8f}")
print(f"LATE from separate: {late:.8f}")

result = {
    "task_id": "rdd_sharp",
    "platform": "python",
    "estimates": [
        {
            "term": "late",
            "estimate": float(late_est),
            "se": float(late_se),
            "n_obs": int(n_obs)
        }
    ],
    "method_metadata": {
        "estimator": "local_linear_WLS_triangular_kernel",
        "vcov": "OLS_HC0"
    },
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)

print("\nResult written to result.json")
