import pandas as pd
import numpy as np
import json
from linearmodels.iv import IV2SLS

df = pd.read_csv("input.csv")

mod = IV2SLS(dependent=df['y_iv'],
             exog=pd.DataFrame({'const': np.ones(len(df))}),
             endog=df[['x1_iv']],
             instruments=df[['z']])

# debiased=True applies n/(n-k) correction => HC1
res = mod.fit(cov_type='robust', debiased=True)

print(res.summary)

n_obs = int(res.nobs)

estimates = []
for term in ['const', 'x1_iv']:
    estimates.append({
        "term": term,
        "estimate": float(res.params[term]),
        "se": float(res.std_errors[term]),
        "n_obs": n_obs
    })

out = {
    "task_id": "iv2sls_robust",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "IV2SLS",
        "vcov": "HC1"
    },
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(out, f, indent=2)

print("\nresult.json written")
print(json.dumps(out, indent=2))
