import pandas as pd
import numpy as np
from scipy import stats
import json

df = pd.read_csv('./input.csv')
n = len(df)
y = df['y'].values
endog = df['endog'].values
x = df['x'].values
z1 = df['z1'].values
z2 = df['z2'].values

# Full model regressors: [1, x, z1, z2]
X_full = np.column_stack([np.ones(n), x, z1, z2])
# Restricted model regressors: [1, x]
X_restr = np.column_stack([np.ones(n), x])

# Precompute projection matrices
def proj(X, v):
    """Project v onto column space of X"""
    coef = np.linalg.lstsq(X, v, rcond=None)[0]
    return X @ coef

def rss(X, v):
    fitted = proj(X, v)
    resid = v - fitted
    return resid @ resid

# F stat as function of beta
# y_tilde = y - beta*endog
# RSS_r(beta) = ||M_r * y_tilde||^2 where M_r = I - P_r
# RSS_f(beta) = ||M_f * y_tilde||^2 where M_f = I - P_f
# F(beta) = (RSS_r - RSS_f)/2 / (RSS_f/(n-4))
# = (n-4)/2 * (RSS_r/RSS_f - 1)

# Let's express RSS as quadratic in beta:
# y_tilde = y - beta*endog
# RSS = y_tilde' M y_tilde = (y - beta*endog)' M (y - beta*endog)
#     = y'My - 2*beta*(endog'My) + beta^2*(endog'Mendog)

def make_M(X):
    Q, _ = np.linalg.qr(X)
    P = Q @ Q.T
    return np.eye(n) - P

M_f = make_M(X_full)
M_r = make_M(X_restr)

# Coefficients for RSS_f(beta) = a_f + b_f*beta + c_f*beta^2
a_f = y @ (M_f @ y)
b_f = -2 * endog @ (M_f @ y)
c_f = endog @ (M_f @ endog)

# Coefficients for RSS_r(beta)
a_r = y @ (M_r @ y)
b_r = -2 * endog @ (M_r @ y)
c_r = endog @ (M_r @ endog)

# Critical value
df1 = 2
df2 = n - 4
F_crit = stats.f.ppf(0.95, df1, df2)
print(f"n={n}, F_crit={F_crit:.6f}, df2={df2}")

# F(beta) <= F_crit iff
# (n-4)/2 * ((RSS_r - RSS_f)/RSS_f) <= F_crit
# (RSS_r - RSS_f)/RSS_f <= 2*F_crit/(n-4)
# RSS_r <= RSS_f * (1 + 2*F_crit/(n-4))
# Let k = 1 + 2*F_crit/(n-4) = (n-4+2*F_crit)/(n-4) = df2/df2 + 2*F_crit/df2
k = 1 + df1 * F_crit / df2
print(f"k = {k:.6f}")

# RSS_r(beta) <= k * RSS_f(beta)
# (a_r + b_r*beta + c_r*beta^2) - k*(a_f + b_f*beta + c_f*beta^2) <= 0
# (c_r - k*c_f)*beta^2 + (b_r - k*b_f)*beta + (a_r - k*a_f) <= 0

A = c_r - k * c_f
B = b_r - k * b_f
C = a_r - k * a_f

print(f"Quadratic: A={A:.8f}, B={B:.8f}, C={C:.8f}")
discriminant = B**2 - 4*A*C
print(f"Discriminant = {discriminant:.8f}")

# F statistic at a given beta
def F_stat(beta):
    y_t = y - beta * endog
    rss_f = rss(X_full, y_t)
    rss_r = rss(X_restr, y_t)
    return (rss_r - rss_f) / df1 / (rss_f / df2)

# Evaluate F at beta=1
ar_f_at_one = F_stat(1.0)
print(f"AR F at beta=1: {ar_f_at_one:.8f}")

# Roots
if discriminant < 0:
    # No real roots: either always inside or always outside
    # Check sign of A
    if A > 0:
        # parabola opens up, always > 0: never accepted (empty set)
        print("Empty confidence set")
        boundary_low = boundary_high = np.nan
        accepts_zero = 0
        unbounded = 0
    else:
        # parabola opens down, A*x^2+... always < 0: always accepted (whole real line)
        print("Unbounded confidence set (whole real line)")
        boundary_low = boundary_high = np.nan
        accepts_zero = 1
        unbounded = 1
elif discriminant == 0:
    root = -B / (2*A)
    boundary_low = boundary_high = root
    accepts_zero = 0
    unbounded = 0
else:
    sqrt_d = np.sqrt(discriminant)
    r1 = (-B - sqrt_d) / (2*A)
    r2 = (-B + sqrt_d) / (2*A)
    root1, root2 = min(r1, r2), max(r1, r2)
    print(f"Roots: {root1:.8f}, {root2:.8f}")
    
    if A > 0:
        # Parabola opens up: quadratic <= 0 between roots -> [root1, root2]
        boundary_low = root1
        boundary_high = root2
        unbounded = 0
        # Check if zero is in [root1, root2]
        accepts_zero = 1 if root1 <= 0 <= root2 else 0
    else:
        # Parabola opens down: quadratic <= 0 outside [root1, root2] -> (-inf, root1] U [root2, +inf)
        boundary_low = root1
        boundary_high = root2
        unbounded = 1
        # Zero is in (-inf, root1] U [root2, +inf)?
        accepts_zero = 1 if 0 <= root1 or 0 >= root2 else 0

# Verification: check F at boundary points
if not np.isnan(boundary_low):
    f_low = F_stat(boundary_low)
    f_high = F_stat(boundary_high)
    print(f"F at boundary_low={boundary_low:.6f}: {f_low:.6f} (should be ~{F_crit:.6f})")
    print(f"F at boundary_high={boundary_high:.6f}: {f_high:.6f} (should be ~{F_crit:.6f})")

print(f"accepts_zero={accepts_zero}, unbounded={unbounded}")

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": [
        {"term": "boundary_low",  "estimate": float(boundary_low),  "se": None, "n_obs": n},
        {"term": "boundary_high", "estimate": float(boundary_high), "se": None, "n_obs": n},
        {"term": "accepts_zero",  "estimate": float(accepts_zero),  "se": None, "n_obs": n},
        {"term": "unbounded",     "estimate": float(unbounded),     "se": None, "n_obs": n},
        {"term": "ar_f_at_one",   "estimate": float(ar_f_at_one),   "se": None, "n_obs": n},
    ],
    "method_metadata": {
        "estimator": "Anderson-Rubin confidence set via F-test inversion",
        "vcov": "homoskedastic"
    },
    "diagnostics": {}
}

with open('./result.json', 'w') as f:
    json.dump(result, f, indent=2)

print("\nresult.json written.")
