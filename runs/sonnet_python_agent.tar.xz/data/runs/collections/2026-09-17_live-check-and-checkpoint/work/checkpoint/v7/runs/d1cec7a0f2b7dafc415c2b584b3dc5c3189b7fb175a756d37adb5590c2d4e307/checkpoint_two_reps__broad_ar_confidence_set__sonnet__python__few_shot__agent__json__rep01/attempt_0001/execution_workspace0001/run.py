import json
import numpy as np
import pandas as pd
from scipy.stats import f

df_data = pd.read_csv('./input.csv')
n = len(df_data)
assert n == 240

y = df_data['y'].values
endog = df_data['endog'].values
x = df_data['x'].values
z1 = df_data['z1'].values
z2 = df_data['z2'].values

controls = np.column_stack([np.ones(n), x])
excluded = np.column_stack([z1, z2])
full = np.column_stack([np.ones(n), x, z1, z2])

q = 2  # number of excluded instruments
df_resid = n - full.shape[1]  # n - 4

def residual(y_vec, design):
    coef, _, _, _ = np.linalg.lstsq(design, y_vec, rcond=None)
    return y_vec - design @ coef

# Residuals of y and endog on controls (restricted) and full (unrestricted)
ry = residual(y, controls)
rd = residual(endog, controls)
uy = residual(y, full)
ud = residual(endog, full)

critical = f.ppf(0.95, q, df_resid)
k = q * critical / df_resid

# Quadratic coefficients: A*beta^2 + B*beta + C <= 0
A = rd @ rd - (1 + k) * (ud @ ud)
B = -2 * (ry @ rd - (1 + k) * (uy @ ud))
C = ry @ ry - (1 + k) * (uy @ uy)

discriminant = B**2 - 4 * A * C
print(f"n={n}, df_resid={df_resid}, critical={critical:.6f}")
print(f"A={A:.8f}, B={B:.8f}, C={C:.8f}")
print(f"discriminant={discriminant:.8f}")

assert abs(A) > 1e-10 and discriminant > 0, "Expected two real boundaries"

boundaries = np.sort(np.roots([A, B, C]).real)
unbounded = int(A < 0)  # A<0 means outer rays accepted (unbounded set)

def direct_F(beta):
    y_adj = y - beta * endog
    r = residual(y_adj, controls)
    u = residual(y_adj, full)
    return ((r @ r - u @ u) / q) / ((u @ u) / df_resid)

def accepts(beta):
    return A * beta**2 + B * beta + C <= 0

# Verification
for boundary in boundaries:
    f_val = direct_F(boundary)
    print(f"F at boundary {boundary:.8f}: {f_val:.8f} (critical={critical:.8f})")
    assert np.isclose(f_val, critical, atol=1e-6), f"Boundary check failed: F={f_val}, critical={critical}"

ar_f_at_one = direct_F(1.0)
accepts_zero = int(accepts(0.0))

print(f"\nboundary_low={boundaries[0]:.10f}")
print(f"boundary_high={boundaries[1]:.10f}")
print(f"accepts_zero={accepts_zero}")
print(f"unbounded={unbounded}")
print(f"ar_f_at_one={ar_f_at_one:.10f}")

# Additional check: direct F at a few points matches quadratic inequality
for beta_test in [boundaries[0] - 1, boundaries.mean(), boundaries[1] + 1, 0.0, 1.0]:
    quad_accepts = accepts(beta_test)
    direct_accepts = direct_F(beta_test) <= critical
    assert quad_accepts == direct_accepts, f"Mismatch at beta={beta_test}"

rows = [
    {'term': 'boundary_low',  'estimate': float(boundaries[0]),  'se': None, 'n_obs': n},
    {'term': 'boundary_high', 'estimate': float(boundaries[1]),  'se': None, 'n_obs': n},
    {'term': 'accepts_zero',  'estimate': int(accepts_zero),      'se': None, 'n_obs': n},
    {'term': 'unbounded',     'estimate': int(unbounded),          'se': None, 'n_obs': n},
    {'term': 'ar_f_at_one',   'estimate': float(ar_f_at_one),     'se': None, 'n_obs': n},
]

result = {
    'task_id': 'broad_ar_confidence_set',
    'platform': 'python',
    'estimates': rows,
    'method_metadata': {
        'estimator': 'Anderson-Rubin confidence set via quadratic inversion',
        'vcov': 'homoskedastic'
    },
    'diagnostics': {}
}

with open('result.json', 'w') as f_out:
    json.dump(result, f_out, indent=2, allow_nan=False)

print("\nresult.json written successfully.")
