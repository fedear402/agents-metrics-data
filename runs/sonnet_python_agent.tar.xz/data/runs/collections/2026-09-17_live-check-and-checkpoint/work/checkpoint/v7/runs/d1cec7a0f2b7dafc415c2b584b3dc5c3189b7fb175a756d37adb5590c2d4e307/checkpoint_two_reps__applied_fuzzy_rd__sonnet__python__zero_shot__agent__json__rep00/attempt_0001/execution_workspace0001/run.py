import pandas as pd
import numpy as np
import json

df = pd.read_csv('/private/tmp/prospective_task_bkpfe3_g/input.csv')

# Apply bandwidth filter: abs(score) < 1
mask = df['score'].abs() < 1
df_bw = df[mask].copy()
n_obs = len(df_bw)

# Triangular weights
df_bw['w'] = 1 - df_bw['score'].abs()

# Indicator for right side (score >= 0)
df_bw['D'] = (df_bw['score'] >= 0).astype(float)

# For local linear RD with separate slopes on each side:
# Model: y = a0 + a1*D + b0*score + b1*D*score
# The discontinuity is a1 (coefficient on D)
# We use WLS with triangular weights

score = df_bw['score'].values
D = df_bw['D'].values
w = df_bw['w'].values
y_earn = df_bw['earnings'].values
y_part = df_bw['participated'].values

# Design matrix: [1, D, score, D*score]
X = np.column_stack([np.ones(len(score)), D, score, D * score])

def wls_hc0(X, y, w):
    """WLS with HC0 standard errors."""
    W = np.diag(w)
    XtW = X.T @ W
    XtWX = XtW @ X
    XtWX_inv = np.linalg.inv(XtWX)
    beta = XtWX_inv @ (XtW @ y)
    
    # Residuals
    e = y - X @ beta
    
    # HC0: sandwich estimator V = (X'WX)^{-1} (X'W diag(e^2) WX) (X'WX)^{-1}
    # Note: weights are fixed (not random), so the meat uses w_i^2 * e_i^2
    # WLS weighted residuals approach:
    # The WLS estimator is beta = (X'WX)^{-1} X'Wy
    # Score for obs i: w_i * x_i * e_i
    # HC0 meat = sum_i (w_i * x_i * e_i)(w_i * x_i * e_i)' = X'W diag(e^2) W X
    meat = X.T @ W @ np.diag(e**2) @ W @ X
    vcov = XtWX_inv @ meat @ XtWX_inv
    return beta, vcov

# Fit earnings equation
beta_earn, vcov_earn = wls_hc0(X, y_earn, w)
# Fit participation equation  
beta_part, vcov_part = wls_hc0(X, y_part, w)

# Discontinuities: coefficient on D (index 1)
reduced_form = beta_earn[1]
first_stage = beta_part[1]

# Standard errors
se_rf = np.sqrt(vcov_earn[1, 1])
se_fs = np.sqrt(vcov_part[1, 1])

# Treatment effect = reduced_form / first_stage
treatment_effect = reduced_form / first_stage

# Delta method for treatment_effect SE:
# te = rf / fs
# Var(te) = (1/fs)^2 * Var(rf) + (rf/fs^2)^2 * Var(fs) - 2*(rf/fs^3)*Cov(rf, fs)
# Need joint covariance of rf and fs estimates

# Stack the two systems to get joint covariance
# Both regressions use same X, w, so we need cross-equation covariance
# cov(beta_earn[1], beta_part[1]) from the joint sandwich

e_earn = y_earn - X @ beta_earn
e_part = y_part - X @ beta_part

W_mat = np.diag(w)
XtWX = X.T @ W_mat @ X
XtWX_inv = np.linalg.inv(XtWX)

# Cross-equation meat: sum_i w_i^2 * e_earn_i * e_part_i * x_i x_i'
meat_cross = X.T @ W_mat @ np.diag(e_earn * e_part) @ W_mat @ X
vcov_cross = XtWX_inv @ meat_cross @ XtWX_inv

cov_rf_fs = vcov_cross[1, 1]

# Delta method
fs = first_stage
rf = reduced_form
var_te = (1/fs)**2 * vcov_earn[1,1] + (rf/fs**2)**2 * vcov_part[1,1] - 2*(rf/fs**3)*cov_rf_fs
se_te = np.sqrt(var_te)

print(f"n_obs = {n_obs}")
print(f"reduced_form = {reduced_form:.8f}, se = {se_rf:.8f}")
print(f"first_stage  = {first_stage:.8f}, se = {se_fs:.8f}")
print(f"treatment_effect = {treatment_effect:.8f}, se = {se_te:.8f}")
print(f"cov(rf, fs) = {cov_rf_fs:.8f}")

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": float(treatment_effect), "se": float(se_te), "n_obs": int(n_obs)},
        {"term": "reduced_form", "estimate": float(reduced_form), "se": float(se_rf), "n_obs": int(n_obs)},
        {"term": "first_stage", "estimate": float(first_stage), "se": float(se_fs), "n_obs": int(n_obs)}
    ],
    "method_metadata": {
        "estimator": "fuzzy_rd_local_linear_triangular",
        "vcov": "HC0"
    },
    "diagnostics": {}
}

with open('/private/tmp/prospective_task_bkpfe3_g/result.json', 'w') as f:
    json.dump(result, f, indent=2)

print("\nresult.json written.")
