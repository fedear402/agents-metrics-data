import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("./input.csv")

y = df["y_twocluster"]
X = sm.add_constant(df[["x"]])
n = len(df)
k = X.shape[1]

# OLS fit (standard errors will be replaced)
fit = sm.OLS(y, X).fit()

# Cameron-Gelbach-Miller two-way clustering
# V_CGM = V(firm) + V(year) - V(firm x year)
# Each V(g) is the cluster-robust sandwich estimator

def cluster_vcov(y, X, clusters, fit):
    """Compute cluster-robust variance matrix."""
    n = len(y)
    k = X.shape[1]
    e = fit.resid.values
    X_arr = X.values
    XtXinv = np.linalg.inv(X_arr.T @ X_arr)
    
    unique_clusters = clusters.unique()
    G = len(unique_clusters)
    
    # Meat of the sandwich
    meat = np.zeros((k, k))
    for g in unique_clusters:
        idx = clusters == g
        Xg = X_arr[idx]
        eg = e[idx]
        score_g = Xg.T @ eg
        meat += np.outer(score_g, score_g)
    
    # Small sample correction: G/(G-1) * (n-1)/(n-k)
    correction = (G / (G - 1)) * ((n - 1) / (n - k))
    vcov = correction * (XtXinv @ meat @ XtXinv)
    return vcov

fit_plain = sm.OLS(y, X).fit()

vcov_firm = cluster_vcov(y, X, df["firm"], fit_plain)
vcov_year = cluster_vcov(y, X, df["year"], fit_plain)
vcov_firmyear = cluster_vcov(y, X, df["firm"].astype(str) + "_" + df["year"].astype(str), fit_plain)

vcov_cgm = vcov_firm + vcov_year - vcov_firmyear
se_cgm = np.sqrt(np.diag(vcov_cgm))

params = fit_plain.params
se_const = float(se_cgm[0])
se_x = float(se_cgm[1])

out = {
    "task_id": "two_way_cluster",
    "platform": "python",
    "estimates": [
        {"term": "const", "estimate": float(params["const"]), "se": se_const, "n_obs": int(fit_plain.nobs)},
        {"term": "x", "estimate": float(params["x"]), "se": se_x, "n_obs": int(fit_plain.nobs)},
    ],
    "method_metadata": {"estimator": "OLS", "vcov": "two-way-cluster-CGM (firm, year)"},
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(out, f, indent=2)

print("Done. Estimates:")
for e in out["estimates"]:
    print(f"  {e['term']}: estimate={e['estimate']:.8f}, se={e['se']:.8f}, n={e['n_obs']}")
