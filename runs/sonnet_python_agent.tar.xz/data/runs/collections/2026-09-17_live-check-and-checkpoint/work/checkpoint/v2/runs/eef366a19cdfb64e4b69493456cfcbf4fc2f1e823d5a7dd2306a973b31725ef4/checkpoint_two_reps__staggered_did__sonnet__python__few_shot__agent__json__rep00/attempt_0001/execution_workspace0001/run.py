import json
import pandas as pd

df = pd.read_csv("./input.csv")

# Cohorts of interest
cohorts = [4, 6, 8]
never = df[df["cohort"] == -1]

# Precompute never-treated means by year
nt_means = never.groupby("year")["y_did"].mean()

cells = []
for g in cohorts:
    g_df = df[df["cohort"] == g]
    g_means = g_df.groupby("year")["y_did"].mean()
    # baseline year is g-1
    baseline_g = g_means[g - 1]
    baseline_nt = nt_means[g - 1]
    # post-treatment years: t >= g
    for t in range(g, 10):
        att_cell = (g_means[t] - baseline_g) - (nt_means[t] - baseline_nt)
        cells.append(att_cell)

att_uniform = sum(cells) / len(cells)

n_obs = len(df)

out = {
    "task_id": "staggered_did",
    "platform": "python",
    "estimates": [
        {"term": "att", "estimate": float(att_uniform), "se": None, "n_obs": int(n_obs)}
    ],
    "method_metadata": {
        "estimator": "ATT_uniform: equal-weight average over supported post-treatment cohort-time cells",
        "vcov": "none"
    },
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(out, f, indent=2)

print(f"ATT_uniform = {att_uniform:.8f}")
print(f"Number of cells: {len(cells)}")
print(f"Cells: {cells}")
