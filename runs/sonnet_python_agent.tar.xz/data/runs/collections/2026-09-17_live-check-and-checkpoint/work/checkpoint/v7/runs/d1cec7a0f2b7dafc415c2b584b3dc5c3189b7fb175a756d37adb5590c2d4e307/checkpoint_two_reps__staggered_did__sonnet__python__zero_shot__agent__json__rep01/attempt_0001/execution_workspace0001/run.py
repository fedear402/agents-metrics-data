import pandas as pd
import json

df = pd.read_csv("input.csv")

cohorts = [4, 6, 8]
never = df[df["cohort"] == -1]

# Precompute never-treated means by year
nt_mean = never.groupby("year")["y_did"].mean()

# Compute ATT for each (g, t) cell: t >= g (post-treatment)
cell_atts = []
for g in cohorts:
    treated = df[df["cohort"] == g]
    treat_mean = treated.groupby("year")["y_did"].mean()
    base_year = g - 1  # last pre-treatment year
    # post-treatment years: t >= g
    for t in range(g, 10):
        delta_treated = treat_mean[t] - treat_mean[base_year]
        delta_never = nt_mean[t] - nt_mean[base_year]
        att_gt = delta_treated - delta_never
        cell_atts.append(att_gt)

att_uniform = sum(cell_atts) / len(cell_atts)

# n_obs: total observations in post-treatment cells for treated cohorts
n_obs = int(df[df["cohort"].isin(cohorts) & (df["year"] >= df["cohort"])].shape[0])

result = {
    "task_id": "staggered_did",
    "platform": "python",
    "estimates": [
        {"term": "att", "estimate": round(att_uniform, 10), "se": None, "n_obs": n_obs}
    ],
    "method_metadata": {
        "estimator": "Callaway-Sant'Anna ATT_uniform (equal-weight over cohort-time cells)",
        "vcov": "none"
    },
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)

print(f"ATT_uniform = {att_uniform:.8f}")
print(f"n_cells = {len(cell_atts)}, n_obs = {n_obs}")
print("Cells:", [round(x, 6) for x in cell_atts])
