import json
import numpy as np
import pandas as pd

df = pd.read_csv('input.csv')

# --- Regional level ---
# One row per region
region_df = df.drop_duplicates('region_id')[['region_id','region_weight','x','y']].copy()
region_df = region_df.sort_values('region_id').reset_index(drop=True)

# Normalize weights
e = region_df['region_weight'].values
e = e / e.sum()
region_df['e'] = e

# Compute shift-share instrument z_r = sum_n share_rn * shock_n
# Pivot shares
share_pivot = df.pivot(index='region_id', columns='industry_id', values='share').fillna(0)
shock_by_industry = df.drop_duplicates('industry_id').set_index('industry_id')['shock']
shock_vec = shock_by_industry.loc[share_pivot.columns].values

region_df = region_df.set_index('region_id')
share_matrix = share_pivot.loc[region_df.index].values  # (R x N)

z = share_matrix @ shock_vec
region_df['z'] = z

e = region_df['e'].values
x_r = region_df['x'].values
y_r = region_df['y'].values
z_r = region_df['z'].values

# Weighted means
x_mean = e @ x_r
y_mean = e @ y_r
z_mean = e @ z_r

# Center
x0 = x_r - x_mean
y0 = y_r - y_mean
z0 = z_r - z_mean

# --- Shock-level aggregation ---
industry_ids = share_pivot.columns.values
N = len(industry_ids)  # number of industries

# s_n = sum_r e_r * share_rn
s = (e[:, None] * share_matrix).sum(axis=0)  # (N,)

# Aggregate residuals: vbar_n = sum_r e_r * share_rn * v0_r / s_n
ybar = (e[:, None] * share_matrix * y0[:, None]).sum(axis=0) / s
xbar = (e[:, None] * share_matrix * x0[:, None]).sum(axis=0) / s
zbar = (e[:, None] * share_matrix * z0[:, None]).sum(axis=0) / s

shock_n = shock_by_industry.loc[industry_ids].values

# Check: mass-weighted aggregates sum to zero
assert np.allclose(s @ ybar, 0.), f"ybar mass sum = {s @ ybar}"
assert np.allclose(s @ xbar, 0.), f"xbar mass sum = {s @ xbar}"
assert np.allclose(s @ zbar, 0.), f"zbar mass sum = {s @ zbar}"

def shock_iv(dependent, endogenous, instrument, weights):
    """Shock-level IV with intercept, HC1 SE."""
    n = len(dependent)
    regressors = np.column_stack([np.ones(n), endogenous])
    instruments = np.column_stack([np.ones(n), instrument])
    W = weights
    cross = instruments.T @ (W[:, None] * regressors)
    beta = np.linalg.solve(cross, instruments.T @ (W * dependent))
    residual = dependent - regressors @ beta
    scores = instruments * (W * residual)[:, None]
    inverse = np.linalg.inv(cross)
    hc1 = n / (n - 2)
    covariance = hc1 * inverse @ (scores.T @ scores) @ inverse.T
    return float(beta[1]), float(np.sqrt(covariance[1, 1]))

# Effect: IV of ybar on xbar, instrument=shock_n
effect, effect_se = shock_iv(ybar, xbar, shock_n, s)

# First stage: IV of xbar on zbar, instrument=shock_n (zbar is endogenous)
first_stage, first_stage_se = shock_iv(xbar, zbar, shock_n, s)

# Effective shocks
effective_shocks = float(1.0 / np.sum(s**2))

# Verify: regional 2SLS slope
regional_2sls = np.sum(e * z0 * y0) / np.sum(e * z0 * x0)
regional_fs = np.sum(e * z0 * x0) / np.sum(e * z0**2)
print(f"Effect (shock-level): {effect:.8f}, Regional 2SLS: {regional_2sls:.8f}")
print(f"First stage (shock-level): {first_stage:.8f}, Regional: {regional_fs:.8f}")
assert np.allclose(effect, regional_2sls, rtol=1e-6), f"Mismatch: {effect} vs {regional_2sls}"
assert np.allclose(first_stage, regional_fs, rtol=1e-6), f"Mismatch: {first_stage} vs {regional_fs}"
print("All checks passed.")

output = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": effect, "se": effect_se, "n_obs": N},
        {"term": "first_stage", "estimate": first_stage, "se": first_stage_se, "n_obs": N},
        {"term": "effective_shocks", "estimate": effective_shocks, "se": None, "n_obs": N},
    ],
    "method_metadata": {
        "estimator": "shift-share IV (Borusyak-Hull-Jaravel)",
        "vcov": "HC1 shock-level exposure-robust"
    },
    "diagnostics": {}
}

with open('result.json', 'w') as f:
    json.dump(output, f, indent=2, allow_nan=False)
print("Wrote result.json")
