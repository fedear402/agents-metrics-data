import pandas as pd
import numpy as np
from scipy.optimize import minimize
from scipy.stats import norm

df = pd.read_csv('input.csv')
n = len(df)
y = df['y'].values
X = np.column_stack([np.ones(n), df['x'].values, df['z'].values])

censored = (y == 0)
uncensored = ~censored

# Parameterize in (beta, sigma) directly - no log transform
def tobit_nll_sigma(params):
    beta = params[:3]
    sigma = params[3]
    if sigma <= 0:
        return 1e10
    xb = X @ beta
    ll_unc = np.sum(norm.logpdf(y[uncensored], loc=xb[uncensored], scale=sigma))
    ll_cen = np.sum(norm.logcdf(-xb[censored] / sigma))
    return -(ll_unc + ll_cen)

from numpy.linalg import lstsq
beta0, _, _, _ = lstsq(X[uncensored], y[uncensored], rcond=None)
sigma0 = np.std(y[uncensored] - X[uncensored] @ beta0)
params0 = np.append(beta0, sigma0)

result_s = minimize(tobit_nll_sigma, params0, method='Nelder-Mead',
                    options={'maxiter': 500000, 'xatol': 1e-12, 'fatol': 1e-12})
# Polish with L-BFGS-B
result_s2 = minimize(tobit_nll_sigma, result_s.x, method='L-BFGS-B',
                     bounds=[(None,None),(None,None),(None,None),(1e-8,None)],
                     options={'maxiter': 50000, 'ftol': 1e-15, 'gtol': 1e-10})
params_s = result_s2.x
print("Direct sigma parameterization:")
print(f"const: {params_s[0]:.10f}")
print(f"x:     {params_s[1]:.10f}")
print(f"z:     {params_s[2]:.10f}")
print(f"sigma: {params_s[3]:.10f}")
print(f"NLL:   {result_s2.fun:.10f}")

# Numerical Hessian in sigma space
def numerical_hessian(f, x0, eps=1e-5):
    n = len(x0)
    H = np.zeros((n, n))
    for i in range(n):
        for j in range(i, n):
            ei = np.zeros(n); ei[i] = eps
            ej = np.zeros(n); ej[j] = eps
            H[i,j] = (f(x0+ei+ej) - f(x0+ei-ej) - f(x0-ei+ej) + f(x0-ei-ej)) / (4*eps**2)
            H[j,i] = H[i,j]
    return H

H_s = numerical_hessian(tobit_nll_sigma, params_s, eps=1e-4)
Hinv_s = np.linalg.inv(H_s)
se_s = np.sqrt(np.diag(Hinv_s))
print(f"\nSE in sigma parameterization:")
print(f"const: {se_s[0]:.8f}")
print(f"x:     {se_s[1]:.8f}")
print(f"z:     {se_s[2]:.8f}")
print(f"sigma: {se_s[3]:.8f}")

# Also check: verify log-likelihood at main solution
beta_main = np.array([0.20029164, 0.83508989, -0.65088889])
sigma_main = 1.08969118
xb = X @ beta_main
ll_unc = np.sum(norm.logpdf(y[uncensored], loc=xb[uncensored], scale=sigma_main))
ll_cen = np.sum(norm.logcdf(-xb[censored] / sigma_main))
print(f"\nVerification NLL at main estimates: {-(ll_unc + ll_cen):.10f}")
print(f"Number uncensored: {uncensored.sum()}, censored: {censored.sum()}")
