import json
import numpy as np
import pandas as pd

data = pd.read_csv("/private/tmp/prospective_task_uzo_x90u/input.csv")
data["date"] = pd.to_datetime(data["date"])
data = data.sort_values("date").reset_index(drop=True)

data["log_sales"] = np.log(data["sales"])
data["log_vix"] = np.log(data["vix"])
data["vix_change"] = data["log_vix"].diff()

n_lags = 15
for k in range(1, n_lags + 1):
    data[f"lag_{k}"] = data["vix_change"].shift(k)

lag_cols = [f"lag_{k}" for k in range(1, n_lags + 1)]
sample = data.dropna(subset=["log_sales"] + lag_cols).copy()
N = len(sample)

X = np.column_stack([np.ones(N)] + [sample[col].to_numpy() for col in lag_cols])
y = sample["log_sales"].to_numpy()

coefficients = np.linalg.lstsq(X, y, rcond=None)[0]
residuals = y - X @ coefficients

# Newey-West HAC with Bartlett weights, max lag 15
scores = X * residuals[:, None]
hac_lags = 15
meat = scores.T @ scores
for j in range(1, hac_lags + 1):
    weight = 1 - j / (hac_lags + 1)  # = 1 - j/16
    lag_product = scores[j:].T @ scores[:-j]
    meat += weight * (lag_product + lag_product.T)

bread = np.linalg.inv(X.T @ X)
p = X.shape[1]  # intercept + 15 lags = 16
covariance = (N / (N - p)) * bread @ meat @ bread

# Cumulative response: sum of 15 lag coefficients (exclude intercept)
contrast = np.array([0.0] + [1.0] * n_lags)
cumulative = float(contrast @ coefficients)
cumulative_se = float(np.sqrt(contrast @ covariance @ contrast))

lag1_est = float(coefficients[1])
lag1_se = float(np.sqrt(covariance[1, 1]))
lag15_est = float(coefficients[15])
lag15_se = float(np.sqrt(covariance[15, 15]))

rows = [
    {"term": "cumulative_response", "estimate": cumulative, "se": cumulative_se, "n_obs": N},
    {"term": "lag_1", "estimate": lag1_est, "se": lag1_se, "n_obs": N},
    {"term": "lag_15", "estimate": lag15_est, "se": lag15_se, "n_obs": N},
]

output = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": rows,
    "method_metadata": {
        "estimator": "OLS",
        "vcov": "Newey-West HAC, Bartlett weights 1-j/16, max lag 15, correction N/(N-16)"
    },
    "diagnostics": {}
}

with open("/private/tmp/prospective_task_uzo_x90u/result.json", "w") as f:
    json.dump(output, f, indent=2, allow_nan=False)

print(f"N={N}, p={p}")
print(f"cumulative_response={cumulative:.8f}, se={cumulative_se:.8f}")
print(f"lag_1={lag1_est:.8f}, se={lag1_se:.8f}")
print(f"lag_15={lag15_est:.8f}, se={lag15_se:.8f}")
