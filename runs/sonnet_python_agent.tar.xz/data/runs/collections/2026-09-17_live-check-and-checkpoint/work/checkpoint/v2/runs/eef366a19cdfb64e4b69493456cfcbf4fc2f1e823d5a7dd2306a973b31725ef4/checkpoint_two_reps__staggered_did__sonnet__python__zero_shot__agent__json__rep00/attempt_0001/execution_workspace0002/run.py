import pandas as pd
import json

df = pd.read_csv("input.csv")

cohorts = [4, 6, 8]
never = df[df["cohort"] == -1]

# Precompute never-treated group means by year
nt_mean = never.groupby("year")["y_did"].mean()

cells = []
for g in cohorts:
    grp = df[df["cohort"] == g]
    grp_mean = grp.groupby("year")["y_did"].mean()
    base_year = g - 1  # last pre-treatment year for cohort g
    # Post-treatment years: t >= g
    for t in range(g, 10):
        att_gt = (grp_mean[t] - grp_mean[base_year]) - (nt_mean[t] - nt_mean[base_year])
        cells.append(att_gt)

att_uniform = sum(cells) / len(cells)

# n_obs: total observations in supported cells (post-treatment rows for treated cohorts)
n_obs = 0
for g in cohorts:
    grp_size = len(df[(df["cohort"] == g) & (df["year"] >= g)])
    n_obs += grp_size

result = {
    "task_id": "staggered_did",
    "platform": "python",
    "estimates": [
        {"term": "att", "estimate": round(att_uniform, 10), "se": None, "n_obs": n_obs}
    ],
    "method_metadata": {
        "estimator": "ATT_uniform_group_year_means",
        "vcov": "null"
    },
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)

print(f"ATT_uniform = {att_uniform:.8f}")
print(f"Number of cells: {len(cells)}")
print(f"n_obs: {n_obs}")
