import pandas as pd
import numpy as np
from scipy import stats
import json

df = pd.read_csv('./input.csv')
n = len(df)
y = df['y'].values
endog = df['endog'].values
x = df['x'].values
z1 = df['z1'].values
z2 = df['z2'].values

# Degrees of freedom
num_df = 2
den_df = n - 4
f_crit = stats.f.ppf(0.95, num_df, den_df)
print(f"n={n}, den_df={den_df}, F_crit={f_crit:.6f}")

# For a given beta, compute F statistic for joint significance of z1, z2
# in regression: (y - beta*endog) = a + b*x + c*z1 + d*z2 + eps
# We need the restricted (c=d=0) vs unrestricted F test

def compute_f(beta):
    lhs = y - beta * endog
    # Unrestricted: regress lhs on [1, x, z1, z2]
    X_full = np.column_stack([np.ones(n), x, z1, z2])
    # Restricted: regress lhs on [1, x]
    X_rest = np.column_stack([np.ones(n), x])
    
    # OLS
    b_full = np.linalg.lstsq(X_full, lhs, rcond=None)[0]
    b_rest = np.linalg.lstsq(X_rest, lhs, rcond=None)[0]
    
    resid_full = lhs - X_full @ b_full
    resid_rest = lhs - X_rest @ b_rest
    
    RSS_full = resid_full @ resid_full
    RSS_rest = resid_rest @ resid_rest
    
    F = ((RSS_rest - RSS_full) / num_df) / (RSS_full / den_df)
    return F

# The F statistic is a quadratic in beta, find roots of F(beta) = f_crit
# Use fine grid to understand behavior, then find roots numerically
betas = np.linspace(-100, 100, 10001)
f_vals = np.array([compute_f(b) for b in betas])

# Find where F crosses f_crit
accepted = f_vals <= f_crit
print(f"Number of accepted betas in [-100,100]: {accepted.sum()}")

# Check if the set is unbounded (check large values)
f_at_1000 = compute_f(1000)
f_at_neg1000 = compute_f(-1000)
print(f"F at beta=1000: {f_at_1000:.6f}")
print(f"F at beta=-1000: {f_at_neg1000:.6f}")

# The AR F statistic is quadratic in beta. Find the boundary points using root finding
from scipy.optimize import brentq

# Find sign changes in (F - f_crit)
def f_minus_crit(beta):
    return compute_f(beta) - f_crit

# Find intervals where f_minus_crit changes sign
sign_changes = []
for i in range(len(betas)-1):
    if (f_vals[i] - f_crit) * (f_vals[i+1] - f_crit) < 0:
        sign_changes.append((betas[i], betas[i+1]))

print(f"Sign changes found at: {sign_changes}")

# Find exact roots
roots = []
for a, b in sign_changes:
    root = brentq(f_minus_crit, a, b, xtol=1e-10, rtol=1e-12)
    roots.append(root)

print(f"Boundary points: {roots}")

# Check boundary with wider range
betas_wide = np.linspace(-1000, 1000, 20001)
f_wide = np.array([compute_f(b) for b in betas_wide])
sign_changes_wide = []
for i in range(len(betas_wide)-1):
    if (f_wide[i] - f_crit) * (f_wide[i+1] - f_crit) < 0:
        sign_changes_wide.append((betas_wide[i], betas_wide[i+1]))
print(f"Sign changes in [-1000,1000]: {sign_changes_wide}")

# The quadratic nature of F means at most 2 roots
# Determine if set is bounded or unbounded
# If F -> infinity as beta -> +/-inf, set is bounded (two finite roots)
# If F -> 0 as beta -> +/-inf, set could be unbounded

# For Anderson-Rubin, F is quadratic in beta. The leading coefficient determines behavior at extremes.
# Let's check large values
f_large = [compute_f(b) for b in [1e4, -1e4, 1e6, -1e6]]
print(f"F at large betas: {f_large}")

ar_f_at_one = compute_f(1.0)
print(f"AR F at beta=1: {ar_f_at_one:.6f}")

# Determine boundary points
roots_wide = []
for a, b in sign_changes_wide:
    root = brentq(f_minus_crit, a, b, xtol=1e-10, rtol=1e-12)
    roots_wide.append(root)
print(f"All boundary points: {roots_wide}")

boundary_low = min(roots_wide)
boundary_high = max(roots_wide)

# Check accepts_zero
f_at_zero = compute_f(0.0)
accepts_zero = 1 if f_at_zero <= f_crit else 0
print(f"F at beta=0: {f_at_zero:.6f}, accepts_zero={accepts_zero}")

# Check unbounded: if F at very large betas is below f_crit, set is unbounded
unbounded = 1 if (f_at_1000 <= f_crit or f_at_neg1000 <= f_crit) else 0
print(f"unbounded={unbounded}")

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": [
        {"term": "boundary_low", "estimate": float(boundary_low), "se": None, "n_obs": n},
        {"term": "boundary_high", "estimate": float(boundary_high), "se": None, "n_obs": n},
        {"term": "accepts_zero", "estimate": float(accepts_zero), "se": None, "n_obs": n},
        {"term": "unbounded", "estimate": float(unbounded), "se": None, "n_obs": n},
        {"term": "ar_f_at_one", "estimate": float(ar_f_at_one), "se": None, "n_obs": n},
    ],
    "method_metadata": {
        "estimator": "Anderson-Rubin test inversion",
        "vcov": "homoskedastic"
    },
    "diagnostics": {}
}

with open('./result.json', 'w') as f:
    json.dump(result, f, indent=2)

print("\nresult.json written.")
print(json.dumps(result, indent=2))
