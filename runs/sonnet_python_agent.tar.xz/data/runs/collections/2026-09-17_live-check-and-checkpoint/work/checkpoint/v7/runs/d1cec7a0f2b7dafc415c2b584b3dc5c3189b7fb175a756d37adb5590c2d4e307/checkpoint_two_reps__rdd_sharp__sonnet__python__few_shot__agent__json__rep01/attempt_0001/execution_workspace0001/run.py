import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("./input.csv")

h = 0.5
cutoff = 0.0

# Triangular kernel weights: K(u) = 1 - |u/h| for |u| <= h
df["u"] = (df["z"] - cutoff) / h
df["w"] = np.where(np.abs(df["u"]) <= 1, 1 - np.abs(df["u"]), 0)

# Left side: z in [-h, 0)
left = df[(df["z"] >= cutoff - h) & (df["z"] < cutoff) & (df["w"] > 0)].copy()
# Right side: z in [0, h]
right = df[(df["z"] >= cutoff) & (df["z"] <= cutoff + h) & (df["w"] > 0)].copy()

# Local linear regression on left side: y ~ 1 + z, weighted
X_left = sm.add_constant(left["z"])
model_left = sm.WLS(left["y"], X_left, weights=left["w"]).fit()
intercept_left = model_left.params["const"]

# Local linear regression on right side: y ~ 1 + z, weighted
X_right = sm.add_constant(right["z"])
model_right = sm.WLS(right["y"], X_right, weights=right["w"]).fit()
intercept_right = model_right.params["const"]

# LATE = difference in intercepts (right - left) at the cutoff
late_estimate = intercept_right - intercept_left

# SE via delta method (assuming independence of the two regressions)
# Var(late) = Var(intercept_right) + Var(intercept_left)
se_intercept_left = model_left.bse["const"]
se_intercept_right = model_right.bse["const"]
se_late = np.sqrt(se_intercept_right**2 + se_intercept_left**2)

n_obs = len(left) + len(right)

print(f"Left intercept: {intercept_left:.8f}, SE: {se_intercept_left:.8f}")
print(f"Right intercept: {intercept_right:.8f}, SE: {se_intercept_right:.8f}")
print(f"LATE estimate: {late_estimate:.8f}")
print(f"LATE SE: {se_late:.8f}")
print(f"N obs: {n_obs} (left={len(left)}, right={len(right)})")

out = {
    "task_id": "rdd_sharp",
    "platform": "python",
    "estimates": [
        {
            "term": "late",
            "estimate": float(late_estimate),
            "se": float(se_late),
            "n_obs": int(n_obs)
        }
    ],
    "method_metadata": {
        "estimator": "local linear regression with triangular kernel, h=0.5",
        "vcov": "OLS sandwich (delta method combining both sides)"
    },
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(out, f, indent=2)

print("result.json written.")
