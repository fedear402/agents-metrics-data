import json
import numpy as np
import pandas as pd

# Load and sort data
data = pd.read_csv("input.csv")
data = data.sort_values("date").reset_index(drop=True)

# Construct variables
data["log_sales"] = np.log(data["sales"])
data["log_vix"] = np.log(data["vix"])
data["vix_change"] = data["log_vix"].diff()  # first difference across consecutive rows

# Create 15 lags of vix_change
for k in range(1, 16):
    data[f"lag_{k}"] = data["vix_change"].shift(k)

# Drop rows with any NaN (need complete set of lagged changes)
lag_cols = [f"lag_{k}" for k in range(1, 16)]
sample = data.dropna(subset=["log_sales", "vix_change"] + lag_cols).copy()
N = len(sample)

# Build X and y
X = np.column_stack([np.ones(N)] + [sample[f"lag_{k}"].to_numpy() for k in range(1, 16)])
y = sample["log_sales"].to_numpy()

# OLS
coefficients = np.linalg.lstsq(X, y, rcond=None)[0]
residuals = y - X @ coefficients

# Newey-West HAC covariance
# max lag = 15, Bartlett weights 1 - j/16 for j in 1..15
scores = X * residuals[:, None]
hac_lags = 15
meat = scores.T @ scores
for j in range(1, hac_lags + 1):
    weight = 1 - j / (hac_lags + 1)  # 1 - j/16
    lag_product = scores[j:].T @ scores[:-j]
    meat += weight * (lag_product + lag_product.T)

bread = np.linalg.inv(X.T @ X)
p = X.shape[1]  # intercept + 15 lags = 16 parameters
covariance = (N / (N - p)) * bread @ meat @ bread

# Cumulative response: sum of 15 lag coefficients (excludes intercept)
# contrast: [0, 1, 1, ..., 1] length 16
contrast = np.array([0.0] + [1.0] * 15)
cumulative = float(contrast @ coefficients)
cumulative_se = float(np.sqrt(contrast @ covariance @ contrast))

# lag_1 is coefficients[1], lag_15 is coefficients[15]
lag1_est = float(coefficients[1])
lag1_se = float(np.sqrt(covariance[1, 1]))
lag15_est = float(coefficients[15])
lag15_se = float(np.sqrt(covariance[15, 15]))

rows = [
    {"term": "cumulative_response", "estimate": cumulative, "se": cumulative_se, "n_obs": N},
    {"term": "lag_1", "estimate": lag1_est, "se": lag1_se, "n_obs": N},
    {"term": "lag_15", "estimate": lag15_est, "se": lag15_se, "n_obs": N},
]
output = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": rows,
    "method_metadata": {
        "estimator": "OLS",
        "vcov": "Newey-West HAC, max_lag=15, Bartlett weights 1-j/16, correction N/(N-16)"
    },
    "diagnostics": {}
}
with open("result.json", "w") as f:
    json.dump(output, f, indent=2, allow_nan=False)

print(f"N = {N}")
print(f"p = {p}")
print(f"cumulative_response = {cumulative:.8f}, se = {cumulative_se:.8f}")
print(f"lag_1 = {lag1_est:.8f}, se = {lag1_se:.8f}")
print(f"lag_15 = {lag15_est:.8f}, se = {lag15_se:.8f}")
