import json
import pandas as pd
import numpy as np
from statsmodels.tsa.arima.model import ARIMA

df = pd.read_csv("./input.csv")
y = df["y"].values
n = len(y)

# Fit ARIMA(1,1,1) with no constant/drift (trend='n')
model = ARIMA(y, order=(1, 1, 1), trend='n')
fit = model.fit()

print(fit.summary())

# One-step-ahead forecast for t=251 (one step beyond last obs)
fc_res = fit.get_forecast(steps=1)
fc_mean = float(fc_res.predicted_mean[0])
fc_ci = fc_res.conf_int(alpha=0.05)
lower_95 = float(fc_ci[0, 0])
upper_95 = float(fc_ci[0, 1])
fc_se = float(fc_res.se_mean[0])

print(f"\nForecast: {fc_mean:.8f}")
print(f"Lower 95%: {lower_95:.8f}")
print(f"Upper 95%: {upper_95:.8f}")
print(f"SE: {fc_se:.8f}")
print(f"n_obs: {n}")

out = {
    "task_id": "arima_forecast",
    "platform": "python",
    "estimates": [
        {"term": "forecast", "estimate": fc_mean, "se": fc_se, "n_obs": n},
        {"term": "lower_95", "estimate": lower_95, "se": None, "n_obs": n},
        {"term": "upper_95", "estimate": upper_95, "se": None, "n_obs": n},
    ],
    "method_metadata": {
        "estimator": "ARIMA(1,1,1) by maximum likelihood, no constant",
        "vcov": "MLE"
    },
    "diagnostics": {
        "ar1": float(fit.params[0]),
        "ma1": float(fit.params[1]),
        "sigma2": float(fit.params[2]) if len(fit.params) > 2 else None,
        "aic": float(fit.aic),
        "bic": float(fit.bic),
    },
}

with open("result.json", "w") as f:
    json.dump(out, f, indent=2)

print("\nresult.json written.")
