import pandas as pd
import numpy as np
import json

df = pd.read_csv('input.csv')

# --- Regional-level data (one obs per region) ---
region_df = df.drop_duplicates('region_id')[['region_id', 'region_weight', 'x', 'y']].copy()
region_df = region_df.set_index('region_id')

# Normalize weights
region_df['e'] = region_df['region_weight'] / region_df['region_weight'].sum()

# --- Construct shift-share instrument z_r = sum_n share_rn * shock_n ---
z = df.groupby('region_id').apply(lambda g: (g['share'] * g['shock']).sum())
region_df['z'] = z

# --- Weighted 2SLS at regional level ---
# First, demean by e_r-weighted mean
def wmean(v, w):
    return (v * w).sum() / w.sum()

e = region_df['e']
y = region_df['y']
x = region_df['x']
z_r = region_df['z']

y_mean = wmean(y, e)
x_mean = wmean(x, e)
z_mean = wmean(z_r, e)

y0 = y - y_mean
x0 = x - x_mean
z0 = z_r - z_mean

# 2SLS slope: beta = cov_w(z0, y0) / cov_w(z0, x0)
# where cov_w(a,b) = sum_r e_r * a_r * b_r  (already demeaned)
cov_zy = (e * z0 * y0).sum()
cov_zx = (e * z0 * x0).sum()
beta_2sls = cov_zy / cov_zx

# First-stage slope: gamma = cov_w(z0, x0) / cov_w(z0, z0)
# Actually: FS: x0 = gamma * z0 => gamma = cov_w(z0,x0)/cov_w(z0,z0)
# But per task: "first-stage slope of x_r on z_r" with e_r weights
# This is OLS of x on z: gamma = sum_r e_r*z0_r*x0_r / sum_r e_r*z0_r^2
cov_zz = (e * z0 * z0).sum()
gamma_fs = cov_zx / cov_zz

# --- Shock-level aggregation (Borusyak-Hull-Jaravel) ---
# s_n = sum_r e_r * share_rn
# vbar_n = sum_r e_r * share_rn * v0_r / s_n

# Build region-level residuals
region_df['y0'] = y0.values
region_df['x0'] = x0.values
region_df['z0'] = z0.values

# Merge residuals back to industry-region df
df2 = df.merge(region_df[['e','y0','x0','z0']], left_on='region_id', right_index=True)

# s_n for each industry
df2['e_share'] = df2['e'] * df2['share']
s_n = df2.groupby('industry_id')['e_share'].sum()

# Aggregate residuals
for v in ['y0','x0','z0']:
    df2[f'e_share_{v}'] = df2['e_share'] * df2[v]

ind_df = df2.groupby('industry_id').agg(
    s_n=('e_share','sum'),
    shock=('shock','first'),
    sum_y=('e_share_y0','sum'),
    sum_x=('e_share_x0','sum'),
    sum_z=('e_share_z0','sum'),
).copy()

ind_df['ybar'] = ind_df['sum_y'] / ind_df['s_n']
ind_df['xbar'] = ind_df['sum_x'] / ind_df['s_n']
ind_df['zbar'] = ind_df['sum_z'] / ind_df['s_n']

N = len(ind_df)
s = ind_df['s_n'].values
shock = ind_df['shock'].values
ybar = ind_df['ybar'].values
xbar = ind_df['xbar'].values
zbar = ind_df['zbar'].values

# ---- EFFECT: shock-level IV of ybar on xbar, instrument=shock, weight=s_n ----
# IV slope: beta = sum_n s_n*shock_n*ybar_n / sum_n s_n*shock_n*xbar_n
# (Since we're using shock as instrument for xbar in level form, 
#  need to first demean by s_n-weighted mean)
# Actually the regression has an intercept — need to partial out intercept first

def sw_mean(v, w):
    return (w * v).sum() / w.sum()

# Demean for shock-level regression
shock_mean = sw_mean(shock, s)
ybar_mean = sw_mean(ybar, s)
xbar_mean = sw_mean(xbar, s)
zbar_mean = sw_mean(zbar, s)

shock_d = shock - shock_mean
ybar_d = ybar - ybar_mean
xbar_d = xbar - xbar_mean
zbar_d = zbar - zbar_mean

# EFFECT: IV of ybar on xbar, instrument=shock, weights=s
# slope = sum(s * shock_d * ybar_d) / sum(s * shock_d * xbar_d)
num_effect = (s * shock_d * ybar_d).sum()
den_effect = (s * shock_d * xbar_d).sum()
beta_shock = num_effect / den_effect

# Verify equals regional 2SLS slope
print(f"Regional 2SLS beta: {beta_2sls:.8f}")
print(f"Shock-level IV beta: {beta_shock:.8f}")

# IV residuals for EFFECT: u_n = ybar_d_n - beta_shock * xbar_d_n
u_effect = ybar_d - beta_shock * xbar_d

# HC1 SE for IV: Var(beta) = N/(N-2) * sum(s_n^2 * shock_d_n^2 * u_n^2) / (sum(s_n * shock_d_n * xbar_d_n))^2
# This is the HC1 sandwich for IV
hc1_mult = N / (N - 2)
meat_effect = (s**2 * shock_d**2 * u_effect**2).sum()
se_effect = np.sqrt(hc1_mult * meat_effect / den_effect**2)

# ---- FIRST STAGE: shock-level IV of xbar on zbar, instrument=shock, weight=s ----
# slope = sum(s * shock_d * xbar_d) / sum(s * shock_d * zbar_d)
num_fs = (s * shock_d * xbar_d).sum()
den_fs = (s * shock_d * zbar_d).sum()
gamma_shock = num_fs / den_fs

print(f"Regional FS gamma: {gamma_fs:.8f}")
print(f"Shock-level FS gamma: {gamma_shock:.8f}")

# IV residuals for FS: v_n = xbar_d_n - gamma_shock * zbar_d_n
u_fs = xbar_d - gamma_shock * zbar_d

meat_fs = (s**2 * shock_d**2 * u_fs**2).sum()
se_fs = np.sqrt(hc1_mult * meat_fs / den_fs**2)

# ---- EFFECTIVE SHOCKS ----
effective_shocks = 1.0 / (s**2).sum()

print(f"\nEffect: {beta_shock:.8f}, SE: {se_effect:.8f}")
print(f"First stage: {gamma_shock:.8f}, SE: {se_fs:.8f}")
print(f"Effective shocks: {effective_shocks:.6f}")
print(f"N industries: {N}")

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": float(beta_shock), "se": float(se_effect), "n_obs": int(N)},
        {"term": "first_stage", "estimate": float(gamma_shock), "se": float(se_fs), "n_obs": int(N)},
        {"term": "effective_shocks", "estimate": float(effective_shocks), "se": None, "n_obs": int(N)},
    ],
    "method_metadata": {
        "estimator": "2SLS shift-share IV with Borusyak-Hull-Jaravel shock-level aggregation",
        "vcov": "HC1 heteroskedasticity-robust, N/(N-2) variance multiplier"
    },
    "diagnostics": {}
}

with open('result.json', 'w') as f:
    json.dump(result, f, indent=2)

print("\nresult.json written.")
