import pandas as pd
import numpy as np
import json
import statsmodels.api as sm

df = pd.read_csv('/private/tmp/prospective_task__jfyxlnj/input.csv')
df = df.sort_values('time').reset_index(drop=True)

y = df['y'].values  # index 0..249 corresponds to time 1..250

forecasts = {}

for f in range(101, 251):  # f = 101 to 250
    # Use y_{f-100}, ..., y_{f-1} (100 values)
    # times f-100 to f-1, which are indices f-100-1 to f-1-1 = f-101 to f-2
    # Regression pairs: s = f-99, ..., f-1 (99 pairs)
    # y_s = a + b * y_{s-1}
    # s ranges from f-99 to f-1
    # y_s: indices (f-99-1) to (f-1-1) = f-100 to f-2
    # y_{s-1}: indices (f-100-1) to (f-2-1) = f-101 to f-3
    
    # Let's be explicit:
    # window: y_{f-100}, ..., y_{f-1} -> indices f-101 to f-2 (0-based, time f-100 is index f-101)
    # regression pairs (s, s-1):
    #   s = f-99: y_{f-99} (idx f-100), y_{f-100} (idx f-101)
    #   s = f-1:  y_{f-1}  (idx f-2),   y_{f-2}   (idx f-3)
    # So Y = y[f-100 : f-1]  (indices f-100 to f-2, length 99)
    #    X = y[f-101 : f-2]  (indices f-101 to f-3, length 99)
    
    Y = y[f-100 : f-1]    # 99 values: y_{f-99} to y_{f-1}
    X = y[f-101 : f-2]    # 99 values: y_{f-100} to y_{f-2}
    
    X_with_const = sm.add_constant(X)
    model = sm.OLS(Y, X_with_const).fit()
    a_hat, b_hat = model.params
    
    y_prev = y[f-2]  # y_{f-1}, index f-2
    forecast = a_hat + b_hat * y_prev
    forecasts[f] = forecast

# Compute RMSE
actuals = np.array([y[f-1] for f in range(101, 251)])  # y_f, index f-1
preds = np.array([forecasts[f] for f in range(101, 251)])
rmse = np.sqrt(np.mean((actuals - preds)**2))

result = {
    "task_id": "hard_rolling",
    "platform": "python",
    "estimates": [
        {"term": "rmse", "estimate": float(rmse), "se": None, "n_obs": 150},
        {"term": "forecast_101", "estimate": float(forecasts[101]), "se": None, "n_obs": 99},
        {"term": "forecast_150", "estimate": float(forecasts[150]), "se": None, "n_obs": 99},
        {"term": "forecast_200", "estimate": float(forecasts[200]), "se": None, "n_obs": 99},
        {"term": "forecast_250", "estimate": float(forecasts[250]), "se": None, "n_obs": 99},
    ],
    "method_metadata": {"estimator": "OLS AR(1) rolling window", "vcov": "null"},
    "diagnostics": {}
}

with open('/private/tmp/prospective_task__jfyxlnj/result.json', 'w') as f:
    json.dump(result, f, indent=2)

print("RMSE:", rmse)
print("forecast_101:", forecasts[101])
print("forecast_150:", forecasts[150])
print("forecast_200:", forecasts[200])
print("forecast_250:", forecasts[250])
