import json
import pandas as pd

df = pd.read_csv("./input.csv")

cohorts = [4, 6, 8]
never = df[df["cohort"] == -1]

# Precompute never-treated means by year
nt_means = never.groupby("year")["y_did"].mean()

cell_atts = []

for g in cohorts:
    g_df = df[df["cohort"] == g]
    g_means = g_df.groupby("year")["y_did"].mean()
    
    # Pre-treatment baseline year = g - 1
    base_year = g - 1
    
    # Post-treatment years: t >= g
    post_years = [t for t in range(10) if t >= g]
    
    for t in post_years:
        treated_diff = g_means[t] - g_means[base_year]
        control_diff = nt_means[t] - nt_means[base_year]
        cell_att = treated_diff - control_diff
        cell_atts.append(cell_att)

att = sum(cell_atts) / len(cell_atts)
n_obs = len(df[(df["cohort"].isin(cohorts)) | (df["cohort"] == -1)])

out = {
    "task_id": "staggered_did",
    "platform": "python",
    "estimates": [
        {"term": "att", "estimate": float(att), "se": None, "n_obs": int(n_obs)}
    ],
    "method_metadata": {
        "estimator": "ATT_uniform from group-year cell means, equal-weight average over cohort-time cells",
        "vcov": "none"
    },
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(out, f, indent=2)

print(f"ATT_uniform = {att:.8f}")
print(f"Number of cells: {len(cell_atts)}")
print(f"N obs: {n_obs}")
