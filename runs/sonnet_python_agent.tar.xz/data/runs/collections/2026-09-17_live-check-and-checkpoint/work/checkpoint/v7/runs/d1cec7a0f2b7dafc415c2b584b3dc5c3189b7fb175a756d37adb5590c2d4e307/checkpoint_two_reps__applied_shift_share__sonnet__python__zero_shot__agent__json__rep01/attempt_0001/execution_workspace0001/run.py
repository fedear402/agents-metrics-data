import pandas as pd
import numpy as np
import json

df = pd.read_csv('input.csv')

# One obs per region
reg = df.drop_duplicates('region_id')[['region_id', 'region_weight', 'x', 'y']].copy()
reg['e_r'] = reg['region_weight'] / reg['region_weight'].sum()
reg = reg.set_index('region_id')

# Regional shift-share instrument z_r = sum_n share_rn * shock_n
df_z = df.groupby('region_id').apply(lambda g: (g['share'] * g['shock']).sum()).rename('z')
reg = reg.join(df_z)

# Weighted demeaning
def wmean(v, w):
    return (v * w).sum() / w.sum()

e = reg['e_r']
reg['y0'] = reg['y'] - wmean(reg['y'], e)
reg['x0'] = reg['x'] - wmean(reg['x'], e)
reg['z0'] = reg['z'] - wmean(reg['z'], e)

# Industry-level aggregation
ind_data = df[['region_id', 'industry_id', 'share', 'shock']].copy()
ind_data = ind_data.join(reg[['e_r', 'y0', 'x0', 'z0']], on='region_id')
ind_data['e_share'] = ind_data['e_r'] * ind_data['share']
s_n = ind_data.groupby('industry_id')['e_share'].sum().rename('s_n')
ind_data = ind_data.join(s_n, on='industry_id')

for v in ['y0', 'x0', 'z0']:
    ind_data[f'{v}_num'] = ind_data['e_r'] * ind_data['share'] * ind_data[v]

ind_agg = ind_data.groupby('industry_id').agg(
    s_n=('s_n', 'first'),
    shock=('shock', 'first'),
    ybar=('y0_num', 'sum'),
    xbar=('x0_num', 'sum'),
    zbar=('z0_num', 'sum'),
).reset_index()

ind_agg['ybar'] = ind_agg['ybar'] / ind_agg['s_n']
ind_agg['xbar'] = ind_agg['xbar'] / ind_agg['s_n']
ind_agg['zbar'] = ind_agg['zbar'] / ind_agg['s_n']

N = len(ind_agg)
s = ind_agg['s_n'].values


def wls_iv(y, x, z, w):
    """Weighted IV: y ~ 1 + x, instrument z, weights w. Returns [intercept, slope]."""
    W = np.diag(w)
    X = np.column_stack([np.ones(len(x)), x])
    Z = np.column_stack([np.ones(len(z)), z])
    ZWX = Z.T @ W @ X
    ZWy = Z.T @ W @ y
    return np.linalg.solve(ZWX, ZWy)


def hc1_iv_se(y, x, z, w, beta):
    """HC1 sandwich SE for weighted IV, N/(N-2) scale factor."""
    n = len(y)
    X = np.column_stack([np.ones(n), x])
    Z = np.column_stack([np.ones(n), z])
    W = np.diag(w)
    resid = y - X @ beta
    ZWX = Z.T @ W @ X
    ZWX_inv = np.linalg.inv(ZWX)
    scores = (Z * w[:, None]) * resid[:, None]
    meat = scores.T @ scores * (n / (n - 2))
    vcov = ZWX_inv @ meat @ ZWX_inv.T
    return np.sqrt(np.diag(vcov))


y_arr = ind_agg['ybar'].values
x_arr = ind_agg['xbar'].values
z_arr = ind_agg['shock'].values
w_arr = ind_agg['s_n'].values
zbar_arr = ind_agg['zbar'].values

# Effect: IV of ybar on xbar, instrument shock
beta_effect = wls_iv(y_arr, x_arr, z_arr, w_arr)
se_effect = hc1_iv_se(y_arr, x_arr, z_arr, w_arr, beta_effect)

# First stage: IV of xbar on zbar, instrument shock
beta_fs = wls_iv(x_arr, zbar_arr, z_arr, w_arr)
se_fs = hc1_iv_se(x_arr, zbar_arr, z_arr, w_arr, beta_fs)

# Effective shocks = 1 / sum_n s_n^2
effective_shocks = 1.0 / np.sum(s**2)

print(f"Effect:         {beta_effect[1]:.8f}  SE: {se_effect[1]:.8f}")
print(f"First stage:    {beta_fs[1]:.8f}  SE: {se_fs[1]:.8f}")
print(f"Effective shocks: {effective_shocks:.6f}")
print(f"N industries: {N}")

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect",           "estimate": float(beta_effect[1]), "se": float(se_effect[1]), "n_obs": N},
        {"term": "first_stage",      "estimate": float(beta_fs[1]),     "se": float(se_fs[1]),     "n_obs": N},
        {"term": "effective_shocks", "estimate": float(effective_shocks), "se": None,               "n_obs": N},
    ],
    "method_metadata": {
        "estimator": "shift-share IV (Bartik) with Borusyak-Hull-Jaravel shock-level aggregation",
        "vcov": "HC1 heteroskedasticity-robust (shock-level, N/(N-2) multiplier)"
    },
    "diagnostics": {}
}

with open('result.json', 'w') as f:
    json.dump(result, f, indent=2)

print("result.json written.")
