import pandas as pd
import numpy as np
import json
import statsmodels.api as sm

# Load and sort data
df = pd.read_csv("input.csv")
df["date"] = pd.to_datetime(df["date"])
df = df.sort_values("date").reset_index(drop=True)

# Compute log variables
df["log_sales"] = np.log(df["sales"])
df["log_vix"] = np.log(df["vix"])

# First difference of log_vix (volatility change)
df["d_log_vix"] = df["log_vix"].diff()

# Create lags 1 through 15
for lag in range(1, 16):
    df[f"d_log_vix_lag{lag}"] = df["d_log_vix"].shift(lag)

# Drop rows with any missing values in the regression variables
reg_vars = ["log_sales"] + [f"d_log_vix_lag{lag}" for lag in range(1, 16)]
df_reg = df[reg_vars].dropna().copy()

N = len(df_reg)
print(f"Regression sample size N = {N}")

# Regression: log_sales on intercept + lags 1-15
X = sm.add_constant(df_reg[[f"d_log_vix_lag{lag}" for lag in range(1, 16)]])
y = df_reg["log_sales"]

model = sm.OLS(y, X)
results = model.fit()

# Newey-West HAC with max lag 15, Bartlett weights 1 - j/16
# statsmodels cov_hac uses Bartlett kernel with nlag parameter
# The weight for lag j is 1 - j/(nlag+1) when using 'bartlett' kernel
# We need weights 1 - j/16, so nlag=15 gives 1 - j/16 (since nlag+1=16)
# statsmodels use_correction=False gives the standard NW; we need to multiply by N/(N-16)

# Get NW covariance without the finite-sample correction
# statsmodels nw_cov: by default uses long-run variance estimator
# use_correction=False means no df correction
nw_cov = sm.stats.sandwich_covariance.cov_hac_simple(results, nlags=15, use_correction=False)

# Multiply by N/(N-16)
adj_factor = N / (N - 16)
nw_cov_adj = nw_cov * adj_factor

# Coefficients (skip intercept at index 0)
lag_names = [f"d_log_vix_lag{lag}" for lag in range(1, 16)]
coef = results.params[lag_names].values  # length 15

# Cumulative response: sum of 15 coefficients
cumulative = coef.sum()

# Standard error of cumulative response: sqrt(1' V 1) where V is the 15x15 submatrix
# Indices 1 through 15 in the covariance matrix (index 0 is intercept)
V = nw_cov_adj[1:, 1:]  # 15x15
ones = np.ones(15)
var_cumulative = ones @ V @ ones
se_cumulative = np.sqrt(var_cumulative)

# Individual SEs for lag_1 and lag_15
se_lag1 = np.sqrt(nw_cov_adj[1, 1])
se_lag15 = np.sqrt(nw_cov_adj[15, 15])

coef_lag1 = coef[0]
coef_lag15 = coef[14]

print(f"Cumulative response: {cumulative:.8f}")
print(f"SE cumulative: {se_cumulative:.8f}")
print(f"lag_1 coef: {coef_lag1:.8f}, SE: {se_lag1:.8f}")
print(f"lag_15 coef: {coef_lag15:.8f}, SE: {se_lag15:.8f}")
print(f"N = {N}")

# Write result.json
result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {"term": "cumulative_response", "estimate": float(cumulative), "se": float(se_cumulative), "n_obs": int(N)},
        {"term": "lag_1", "estimate": float(coef_lag1), "se": float(se_lag1), "n_obs": int(N)},
        {"term": "lag_15", "estimate": float(coef_lag15), "se": float(se_lag15), "n_obs": int(N)},
    ],
    "method_metadata": {
        "estimator": "OLS",
        "vcov": "Newey-West HAC, max lag 15, Bartlett weights 1-j/16, scaled by N/(N-16)"
    },
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)

print("\nresult.json written successfully.")
