import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

df = pd.read_csv("input.csv")
y = df["y_twocluster"].values
X = sm.add_constant(df["x"].values)
n, k = X.shape

res = sm.OLS(y, X).fit()
betas = res.params
e = res.resid

XtX_inv = np.linalg.inv(X.T @ X)

def vcov_cluster(X, e, cluster_ids, n, k):
    clusters = np.unique(cluster_ids)
    G = len(clusters)
    B = np.zeros((X.shape[1], X.shape[1]))
    for c in clusters:
        idx = cluster_ids == c
        score = X[idx].T @ e[idx]
        B += np.outer(score, score)
    factor = (n - 1) / (n - k) * G / (G - 1)
    return factor * XtX_inv @ B @ XtX_inv

firm_ids = df["firm"].values
year_ids = df["year"].values
firmyear_ids = firm_ids * 10000 + year_ids  # unique per observation

V_firm = vcov_cluster(X, e, firm_ids, n, k)
V_year = vcov_cluster(X, e, year_ids, n, k)
V_firmyear = vcov_cluster(X, e, firmyear_ids, n, k)

# Cameron-Gelbach-Miller two-way cluster formula
V_cgm = V_firm + V_year - V_firmyear
se_cgm = np.sqrt(np.diag(V_cgm))

print("Coefficients:", betas)
print("SE (CGM two-way cluster):", se_cgm)
print("N:", n)

result = {
    "task_id": "two_way_cluster",
    "platform": "python",
    "estimates": [
        {"term": "const", "estimate": float(betas[0]), "se": float(se_cgm[0]), "n_obs": int(n)},
        {"term": "x", "estimate": float(betas[1]), "se": float(se_cgm[1]), "n_obs": int(n)}
    ],
    "method_metadata": {
        "estimator": "OLS",
        "vcov": "Cameron-Gelbach-Miller two-way cluster (firm, year)"
    },
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)

print("result.json written.")
