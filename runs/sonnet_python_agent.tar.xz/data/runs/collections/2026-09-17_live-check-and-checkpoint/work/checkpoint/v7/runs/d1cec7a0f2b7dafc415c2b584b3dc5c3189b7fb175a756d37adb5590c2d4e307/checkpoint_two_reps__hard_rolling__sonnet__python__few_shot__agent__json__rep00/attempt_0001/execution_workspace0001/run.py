import json
import numpy as np
import pandas as pd

data = pd.read_csv("/private/tmp/prospective_task_boa_qzyt/input.csv")
data = data.sort_values("time").reset_index(drop=True)

assert len(data) == 250
assert data["time"].tolist() == list(range(1, 251))

window = 100
forecast_times = list(range(101, 251))
forecasts = {}

for f in forecast_times:
    # Use observed levels at times f-100 through f-1 (100 levels)
    history = data.loc[data["time"].between(f - window, f - 1), "y"].to_numpy(dtype=float)
    assert len(history) == window
    
    # 99 regression pairs: y_s = a + b*y_{s-1} for s = f-99,...,f-1
    lagged = history[:-1]   # y_{s-1}
    current = history[1:]   # y_s
    assert len(lagged) == window - 1 == 99
    
    X = np.column_stack([np.ones(len(lagged)), lagged])
    coeffs = np.linalg.lstsq(X, current, rcond=None)[0]
    
    # Forecast y_f = a_hat + b_hat * y_{f-1}
    forecasts[f] = float(coeffs[0] + coeffs[1] * history[-1])

# Compute RMSE over all 150 forecast dates
actual = data.set_index("time").loc[forecast_times, "y"].to_numpy(dtype=float)
predicted = np.array([forecasts[f] for f in forecast_times])
rmse = float(np.sqrt(np.mean((actual - predicted) ** 2)))

report_times = [101, 150, 200, 250]
rows = [
    {"term": "rmse", "estimate": rmse, "se": None, "n_obs": 150},
    *[{"term": f"forecast_{f}", "estimate": forecasts[f], "se": None, "n_obs": 99}
      for f in report_times],
]

output = {
    "task_id": "hard_rolling",
    "platform": "python",
    "estimates": rows,
    "method_metadata": {"estimator": "OLS AR(1) with intercept, rolling window 100", "vcov": "null"},
    "diagnostics": {}
}

with open("/private/tmp/prospective_task_boa_qzyt/result.json", "w") as f:
    json.dump(output, f, indent=2, allow_nan=False)

print("RMSE:", rmse)
for t in report_times:
    print(f"forecast_{t}:", forecasts[t])
