import json
import numpy as np
import pandas as pd
from scipy.stats import f

df_data = pd.read_csv('/private/tmp/prospective_task_jtpjbz7z/input.csv')
n = len(df_data)

y = df_data['y'].values
endog = df_data['endog'].values
x = df_data['x'].values
z1 = df_data['z1'].values
z2 = df_data['z2'].values

# Controls (restricted): intercept, x
W = np.column_stack([np.ones(n), x])
# Full (unrestricted): intercept, x, z1, z2
Z = np.column_stack([np.ones(n), x, z1, z2])

q = 2       # excluded instruments
df = n - 4  # denominator df = n - number of regressors in unrestricted

def residual(y_vec, design):
    coef, _, _, _ = np.linalg.lstsq(design, y_vec, rcond=None)
    return y_vec - design @ coef

ry = residual(y, W)       # M_W * y
rd = residual(endog, W)   # M_W * endog
uy = residual(y, Z)       # M_Z * y
ud = residual(endog, Z)   # M_Z * endog

critical = f.ppf(0.95, q, df)
k = q * critical / df

# A*beta^2 + B*beta + C <= 0 is the acceptance region
A = rd @ rd - (1 + k) * (ud @ ud)
B = -2 * (ry @ rd - (1 + k) * (uy @ ud))
C = ry @ ry - (1 + k) * (uy @ uy)

discriminant = B**2 - 4*A*C

def direct_F(beta):
    yb = y - beta * endog
    r = residual(yb, W)
    u = residual(yb, Z)
    return ((r @ r - u @ u) / q) / ((u @ u) / df)

def accepts(beta):
    return A * beta**2 + B * beta + C <= 0

ar_f_at_one = float(direct_F(1.0))

assert discriminant > 0 and abs(A) > 1e-10, "Degenerate case"
boundaries = np.sort(np.roots([A, B, C]).real)
boundary_low = float(boundaries[0])
boundary_high = float(boundaries[1])

# Verify boundaries match critical value
assert np.isclose(direct_F(boundary_low), critical, atol=1e-6), f"Low boundary check failed: {direct_F(boundary_low)} vs {critical}"
assert np.isclose(direct_F(boundary_high), critical, atol=1e-6), f"High boundary check failed: {direct_F(boundary_high)} vs {critical}"

accepts_zero = int(accepts(0.0))
unbounded = int(A < 0)  # A<0 means outer rays accepted (unbounded set)

print(f"n={n}, q={q}, df={df}, critical={critical:.6f}")
print(f"A={A:.6f}, B={B:.6f}, C={C:.6f}")
print(f"discriminant={discriminant:.6f}")
print(f"boundary_low={boundary_low:.8f}")
print(f"boundary_high={boundary_high:.8f}")
print(f"accepts_zero={accepts_zero}")
print(f"unbounded={unbounded}")
print(f"ar_f_at_one={ar_f_at_one:.8f}")
print(f"F at boundary_low={direct_F(boundary_low):.8f}, critical={critical:.8f}")
print(f"F at boundary_high={direct_F(boundary_high):.8f}")
print(f"F at 0={direct_F(0.):.8f}")
print(f"F at 1={direct_F(1.):.8f}")

rows = [
    {'term': 'boundary_low',  'estimate': boundary_low,  'se': None, 'n_obs': n},
    {'term': 'boundary_high', 'estimate': boundary_high, 'se': None, 'n_obs': n},
    {'term': 'accepts_zero',  'estimate': accepts_zero,  'se': None, 'n_obs': n},
    {'term': 'unbounded',     'estimate': unbounded,     'se': None, 'n_obs': n},
    {'term': 'ar_f_at_one',   'estimate': ar_f_at_one,  'se': None, 'n_obs': n},
]

result = {
    'task_id': 'broad_ar_confidence_set',
    'platform': 'python',
    'estimates': rows,
    'method_metadata': {
        'estimator': 'Anderson-Rubin confidence set via quadratic inversion',
        'vcov': 'homoskedastic'
    },
    'diagnostics': {}
}

with open('/private/tmp/prospective_task_jtpjbz7z/result.json', 'w') as fh:
    json.dump(result, fh, indent=2, allow_nan=False)

print("\nresult.json written successfully.")
