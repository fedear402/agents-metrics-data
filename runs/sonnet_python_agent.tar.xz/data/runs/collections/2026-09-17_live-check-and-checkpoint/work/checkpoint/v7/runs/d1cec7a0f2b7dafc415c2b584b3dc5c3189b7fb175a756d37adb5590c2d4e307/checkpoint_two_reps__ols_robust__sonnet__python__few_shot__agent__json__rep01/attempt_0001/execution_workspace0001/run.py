import json
import pandas as pd
import statsmodels.api as sm
import numpy as np

df = pd.read_csv("./input.csv")

X = sm.add_constant(df[["x1", "x2"]])
fit = sm.OLS(df["y_lin"], X).fit(cov_type="HC1")

out = {
    "task_id": "ols_robust",
    "platform": "python",
    "estimates": [
        {"term": "const", "estimate": float(fit.params["const"]),
         "se": float(fit.bse["const"]), "n_obs": int(fit.nobs)},
        {"term": "x1", "estimate": float(fit.params["x1"]),
         "se": float(fit.bse["x1"]), "n_obs": int(fit.nobs)},
        {"term": "x2", "estimate": float(fit.params["x2"]),
         "se": float(fit.bse["x2"]), "n_obs": int(fit.nobs)},
    ],
    "method_metadata": {"estimator": "OLS", "vcov": "HC1"},
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(out, f, indent=2)

print("Done. Params:")
print(fit.params)
print("\nHC1 SE:")
print(fit.bse)
print("\nnobs:", int(fit.nobs))
