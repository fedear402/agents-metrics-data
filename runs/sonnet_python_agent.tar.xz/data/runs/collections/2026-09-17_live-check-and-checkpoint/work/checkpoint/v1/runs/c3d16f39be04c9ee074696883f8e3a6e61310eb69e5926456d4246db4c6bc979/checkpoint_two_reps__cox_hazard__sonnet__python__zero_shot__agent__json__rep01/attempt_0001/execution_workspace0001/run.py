import pandas as pd
import numpy as np
import json
from statsmodels.duration.hazard_regression import PHReg

df = pd.read_csv("input.csv")
n_obs = len(df)

model = PHReg(
    endog=df["t_obs"],
    exog=df[["treat", "x"]],
    status=df["event"],
    ties="breslow"
)
result = model.fit(disp=False)

# params and bse are numpy arrays ordered as [treat, x]
params = result.params
bse = result.bse

estimates = [
    {"term": "treat", "estimate": float(params[0]), "se": float(bse[0]), "n_obs": n_obs},
    {"term": "x",     "estimate": float(params[1]), "se": float(bse[1]), "n_obs": n_obs},
]

output = {
    "task_id": "cox_hazard",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "Cox proportional hazards (partial likelihood, Breslow tie-handling)",
        "vcov": "model-based (observed information matrix)"
    },
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(output, f, indent=2)

print("Done. result.json written.")
