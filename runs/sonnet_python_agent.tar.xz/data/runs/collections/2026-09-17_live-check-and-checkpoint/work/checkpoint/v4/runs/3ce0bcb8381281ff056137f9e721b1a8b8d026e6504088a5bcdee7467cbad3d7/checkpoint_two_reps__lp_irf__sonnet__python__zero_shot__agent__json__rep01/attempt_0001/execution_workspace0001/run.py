import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

# Read data
df = pd.read_csv("input.csv")
df = df.sort_values("t").reset_index(drop=True)

# Construct variables for LP at horizon h=4
# Dependent variable: y_{t+4}
df["y_lead4"] = df["y"].shift(-4)
# Control: y_{t-1}
df["y_lag1"] = df["y"].shift(1)

# Estimation sample: need y_lead4, shock, y_lag1 all non-missing
df_est = df[["y_lead4", "shock", "y_lag1"]].dropna()

# Regressors: intercept, shock_t, y_{t-1}
X = sm.add_constant(df_est[["shock", "y_lag1"]])
y = df_est["y_lead4"]

# OLS with Newey-West SE (lag=4)
model = sm.OLS(y, X).fit(cov_type="HAC", cov_kwds={"maxlags": 4})

print(model.summary())
print("\nCoefficients:")
print(model.params)
print("\nNewey-West SE:")
print(model.bse)
print("\nN obs:", int(model.nobs))

# irf_h4 = coefficient on shock
irf_h4_est = float(model.params["shock"])
irf_h4_se = float(model.bse["shock"])
n_obs = int(model.nobs)

result = {
    "task_id": "lp_irf",
    "platform": "python",
    "estimates": [
        {"term": "irf_h4", "estimate": irf_h4_est, "se": irf_h4_se, "n_obs": n_obs}
    ],
    "method_metadata": {
        "estimator": "OLS local projection at horizon h=4",
        "vcov": "Newey-West HAC (maxlags=4)"
    },
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)

print("\nResult written to result.json")
print(json.dumps(result, indent=2))
