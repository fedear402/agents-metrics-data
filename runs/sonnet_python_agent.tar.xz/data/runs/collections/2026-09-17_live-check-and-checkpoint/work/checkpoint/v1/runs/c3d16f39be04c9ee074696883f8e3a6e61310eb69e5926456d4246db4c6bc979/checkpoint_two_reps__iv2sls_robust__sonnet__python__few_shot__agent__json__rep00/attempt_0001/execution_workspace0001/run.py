import json
import pandas as pd
import numpy as np
from linearmodels.iv import IV2SLS

df = pd.read_csv("./input.csv")
df["const"] = 1.0

# 2SLS: y_iv ~ const + [x1_iv ~ z]
model = IV2SLS(dependent=df["y_iv"],
               exog=df[["const"]],
               endog=df[["x1_iv"]],
               instruments=df[["z"]])
res = model.fit(cov_type="robust")  # HC1 in linearmodels robust

print(res.summary)
print(res.params)
print(res.std_errors)
print("N:", res.nobs)

out = {
    "task_id": "iv2sls_robust",
    "platform": "python",
    "estimates": [
        {"term": "const",  "estimate": float(res.params["const"]),  "se": float(res.std_errors["const"]),  "n_obs": int(res.nobs)},
        {"term": "x1_iv",  "estimate": float(res.params["x1_iv"]),  "se": float(res.std_errors["x1_iv"]),  "n_obs": int(res.nobs)},
    ],
    "method_metadata": {"estimator": "2SLS via linearmodels IV2SLS", "vcov": "HC1 robust"},
    "diagnostics": {},
}
with open("result.json", "w") as f:
    json.dump(out, f, indent=2)
print("Done")
