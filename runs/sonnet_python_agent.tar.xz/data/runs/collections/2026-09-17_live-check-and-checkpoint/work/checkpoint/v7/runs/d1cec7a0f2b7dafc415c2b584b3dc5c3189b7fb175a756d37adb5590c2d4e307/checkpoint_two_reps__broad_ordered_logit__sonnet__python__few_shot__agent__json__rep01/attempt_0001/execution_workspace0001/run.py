import json
import numpy as np
import pandas as pd
from scipy.special import expit
from statsmodels.miscmodels.ordinal_model import OrderedModel

df = pd.read_csv('input.csv')
n = len(df)

model = OrderedModel(df['y'], df[['x', 'z']], distr='logit')
fit = model.fit(method='bfgs', disp=False, gtol=1e-8)

params = fit.params
bse = fit.bse

x_slope = float(params['x'])
z_slope = float(params['z'])
x_se = float(bse['x'])
z_se = float(bse['z'])

# Predict probability of category 3 at x=1, z=0
pred_point = np.array([[1.0, 0.0]])
probs = model.predict(params, exog=pred_point)
prob_high = float(probs[0, 2])  # category 3

# Verify: manual calculation using thresholds
threshold = model.transform_threshold_params(params)
# P(y=3) = 1 - logistic(cutpoint2 - x*beta_x - z*beta_z)
# With x=1, z=0: 1 - expit(threshold[2] - x_slope*1 - z_slope*0)
manual_prob_high = 1 - expit(threshold[2] - x_slope)
print(f"Model predict prob_high: {prob_high}")
print(f"Manual prob_high: {manual_prob_high}")
print(f"Match: {np.isclose(prob_high, manual_prob_high)}")
print(f"\nx slope: {x_slope}, se: {x_se}")
print(f"z slope: {z_slope}, se: {z_se}")
print(f"n_obs: {n}")
print(f"\nFull params:\n{fit.summary()}")

result = {
    "task_id": "broad_ordered_logit",
    "platform": "python",
    "estimates": [
        {"term": "x", "estimate": x_slope, "se": x_se, "n_obs": n},
        {"term": "z", "estimate": z_slope, "se": z_se, "n_obs": n},
        {"term": "prob_high", "estimate": prob_high, "se": None, "n_obs": n}
    ],
    "method_metadata": {"estimator": "OrderedLogit_MLE", "vcov": "observed_information"},
    "diagnostics": {}
}

with open('result.json', 'w') as f:
    json.dump(result, f, indent=2, allow_nan=False)

print("\nresult.json written successfully")
