import pandas as pd
import numpy as np
import json
import statsmodels.api as sm

# Load data
df = pd.read_csv('input.csv', parse_dates=['date'])
df = df.sort_values('date').reset_index(drop=True)

# Construct variables
df['log_sales'] = np.log(df['sales'])
df['log_vix'] = np.log(df['vix'])
df['d_log_vix'] = df['log_vix'].diff()

# Create lags 1-15 of d_log_vix
for lag in range(1, 16):
    df[f'lag_{lag}'] = df['d_log_vix'].shift(lag)

# Drop rows with any NaN
lag_cols = [f'lag_{i}' for i in range(1, 16)]
reg_df = df[['log_sales'] + lag_cols].dropna().copy()

N = len(reg_df)
print(f"N = {N}")

# OLS regression
X = sm.add_constant(reg_df[lag_cols])
y = reg_df['log_sales']
param_names = list(X.columns)

model = sm.OLS(y, X)
results = model.fit()

# Newey-West HAC with max lag 15, Bartlett kernel, use_correction=False
hac_results = results.get_robustcov_results(cov_type='HAC', maxlags=15, use_correction=False)
cov_hac = np.array(hac_results.cov_params())

# Scale by N/(N-16)
cov_scaled = cov_hac * N / (N - 16)

params = results.params.values
print("Params:", dict(zip(param_names, params)))

# Indices of lag columns
lag_idx = [param_names.index(f'lag_{i}') for i in range(1, 16)]

cum_response = params[lag_idx].sum()
sub_cov = cov_scaled[np.ix_(lag_idx, lag_idx)]
cum_var = sub_cov.sum()
cum_se = np.sqrt(cum_var)

idx1 = param_names.index('lag_1')
idx15 = param_names.index('lag_15')
se_lag1 = np.sqrt(cov_scaled[idx1, idx1])
se_lag15 = np.sqrt(cov_scaled[idx15, idx15])

print(f"Cumulative response: {cum_response:.8f}, SE: {cum_se:.8f}")
print(f"lag_1: {params[idx1]:.8f}, SE: {se_lag1:.8f}")
print(f"lag_15: {params[idx15]:.8f}, SE: {se_lag15:.8f}")

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {"term": "cumulative_response", "estimate": float(cum_response), "se": float(cum_se), "n_obs": int(N)},
        {"term": "lag_1", "estimate": float(params[idx1]), "se": float(se_lag1), "n_obs": int(N)},
        {"term": "lag_15", "estimate": float(params[idx15]), "se": float(se_lag15), "n_obs": int(N)},
    ],
    "method_metadata": {
        "estimator": "OLS",
        "vcov": "Newey-West HAC, maxlag=15, Bartlett kernel, scaled by N/(N-16)"
    },
    "diagnostics": {}
}

with open('result.json', 'w') as f:
    json.dump(result, f, indent=2)

print("result.json written.")
