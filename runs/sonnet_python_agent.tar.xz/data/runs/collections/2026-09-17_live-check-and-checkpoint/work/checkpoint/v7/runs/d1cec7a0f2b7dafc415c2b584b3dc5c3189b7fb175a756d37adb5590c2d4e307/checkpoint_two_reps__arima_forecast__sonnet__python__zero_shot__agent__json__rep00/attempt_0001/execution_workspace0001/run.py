import pandas as pd
import numpy as np
import json
from statsmodels.tsa.arima.model import ARIMA

# Load data
df = pd.read_csv("input.csv")
y = df["y"].values
n = len(y)  # should be 250

# Fit ARIMA(1,1,1) with no constant (trend='n')
model = ARIMA(y, order=(1, 1, 1), trend='n')
result = model.fit(method='statespace')

# One-step-ahead forecast for t=251 (one step beyond last obs)
forecast_obj = result.get_forecast(steps=1)
forecast_mean = forecast_obj.predicted_mean[0]
conf_int = forecast_obj.conf_int(alpha=0.05)
lower_95 = conf_int[0, 0]
upper_95 = conf_int[0, 1]

print(f"n_obs: {n}")
print(f"AR(1): {result.arparams[0]:.8f}")
print(f"MA(1): {result.maparams[0]:.8f}")
print(f"sigma2: {result.params[-1]:.8f}")
print(f"forecast: {forecast_mean:.8f}")
print(f"lower_95: {lower_95:.8f}")
print(f"upper_95: {upper_95:.8f}")

# Write result.json
output = {
    "task_id": "arima_forecast",
    "platform": "python",
    "estimates": [
        {"term": "forecast", "estimate": float(forecast_mean), "se": None, "n_obs": n},
        {"term": "lower_95", "estimate": float(lower_95), "se": None, "n_obs": n},
        {"term": "upper_95", "estimate": float(upper_95), "se": None, "n_obs": n}
    ],
    "method_metadata": {
        "estimator": "ARIMA(1,1,1) MLE via Kalman filter (statsmodels state space)",
        "vcov": "OPG/Hessian (statsmodels default)"
    },
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(output, f, indent=2)

print("\nresult.json written.")
