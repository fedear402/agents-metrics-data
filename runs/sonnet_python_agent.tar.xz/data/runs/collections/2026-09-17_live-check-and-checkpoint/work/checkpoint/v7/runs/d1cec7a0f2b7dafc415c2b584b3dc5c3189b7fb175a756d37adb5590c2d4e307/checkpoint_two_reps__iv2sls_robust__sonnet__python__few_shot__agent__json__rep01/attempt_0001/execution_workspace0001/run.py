import json
import pandas as pd
import numpy as np
from linearmodels.iv import IV2SLS

df = pd.read_csv("./input.csv")

# 2SLS: y_iv ~ 1 + [x1_iv ~ z]
res = IV2SLS(
    dependent=df["y_iv"],
    exog=pd.DataFrame({"const": np.ones(len(df))}),
    endog=df[["x1_iv"]],
    instruments=df[["z"]]
).fit(cov_type="robust")  # HC1-equivalent heteroskedasticity robust

# Extract results
params = res.params
se = res.std_errors
n = int(res.nobs)

out = {
    "task_id": "iv2sls_robust",
    "platform": "python",
    "estimates": [
        {"term": "const",  "estimate": float(params["const"]),  "se": float(se["const"]),  "n_obs": n},
        {"term": "x1_iv",  "estimate": float(params["x1_iv"]),  "se": float(se["x1_iv"]),  "n_obs": n},
    ],
    "method_metadata": {
        "estimator": "2SLS via linearmodels IV2SLS",
        "vcov": "HC1 robust (heteroskedasticity-consistent)"
    },
    "diagnostics": {}
}

with open("./result.json", "w") as f:
    json.dump(out, f, indent=2)

print("const:", params["const"], "se:", se["const"])
print("x1_iv:", params["x1_iv"], "se:", se["x1_iv"])
print("n_obs:", n)
