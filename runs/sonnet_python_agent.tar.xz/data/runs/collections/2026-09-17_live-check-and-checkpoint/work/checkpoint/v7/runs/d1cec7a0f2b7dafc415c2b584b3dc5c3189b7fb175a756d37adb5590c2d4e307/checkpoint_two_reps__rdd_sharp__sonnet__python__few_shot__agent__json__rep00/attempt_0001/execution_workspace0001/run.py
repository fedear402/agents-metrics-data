import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("./input.csv")

cutoff = 0.0
h = 0.5

# Triangular kernel weights: w = (1 - |z - c| / h) for |z - c| <= h
df = df.copy()
df["dist"] = np.abs(df["z"] - cutoff)
df = df[df["dist"] <= h].copy()
df["weight"] = 1.0 - df["dist"] / h

# Split into left (z < cutoff) and right (z >= cutoff)
left = df[df["z"] < cutoff].copy()
right = df[df["z"] >= cutoff].copy()

# Local linear regression on each side: y ~ 1 + z
# Left side
X_left = sm.add_constant(left["z"])
wls_left = sm.WLS(left["y"], X_left, weights=left["weight"]).fit()
intercept_left = wls_left.params["const"]

# Right side
X_right = sm.add_constant(right["z"])
wls_right = sm.WLS(right["y"], X_right, weights=right["weight"]).fit()
intercept_right = wls_right.params["const"]

# LATE = difference in intercepts at cutoff (right - left)
late = intercept_right - intercept_left

# SE via delta method: var(late) = var(intercept_right) + var(intercept_left)
se_left = wls_left.bse["const"]
se_right = wls_right.bse["const"]
se_late = np.sqrt(se_right**2 + se_left**2)

n_obs = len(df)

print(f"Left obs: {len(left)}, Right obs: {len(right)}, Total: {n_obs}")
print(f"Intercept left: {intercept_left:.8f}")
print(f"Intercept right: {intercept_right:.8f}")
print(f"LATE: {late:.8f}")
print(f"SE: {se_late:.8f}")

out = {
    "task_id": "rdd_sharp",
    "platform": "python",
    "estimates": [
        {"term": "late", "estimate": float(late), "se": float(se_late), "n_obs": int(n_obs)}
    ],
    "method_metadata": {
        "estimator": "local linear regression, triangular kernel, bandwidth 0.5",
        "vcov": "OLS (separate WLS each side, delta method for SE)"
    },
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(out, f, indent=2)

print("Done. result.json written.")
