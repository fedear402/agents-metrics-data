import pandas as pd
import numpy as np
import json
import statsmodels.api as sm

# Load and sort data
df = pd.read_csv('input.csv')
df = df.sort_values('time').reset_index(drop=True)

y = df['y'].values  # 0-indexed, y[0] = time 1

forecasts = {}

# For forecast f (time f, 1-indexed), use y_{f-100},...,y_{f-1}
# 0-indexed: y[f-101],...,y[f-2], fitting y_s = a + b*y_{s-1}
# for s = f-99,...,f-1 (1-indexed) = indices f-100,...,f-2 (0-indexed)
# regression pairs: (y[f-100], y[f-99]), ..., (y[f-2], y[f-1]) -- 99 pairs

for f in range(101, 251):  # f is 1-indexed time
    # indices 0-based
    # window: y[f-101] to y[f-2] (inclusive) = 100 values
    # regressand: y[f-100] to y[f-2] = indices f-100 to f-2 (99 values)
    # regressor: y[f-101] to y[f-3]... wait let me re-read

    # "use exactly 100 observed levels y_{f-100},...,y_{f-1}"
    # That's y at times f-100 through f-1 (1-indexed)
    # 0-indexed: y[f-101] through y[f-2]  (100 values)
    
    # "Fit y_s = a + b*y_{s-1} with an intercept on s=f-99,...,f-1"
    # That's 99 values of s (1-indexed times)
    # For each s, we have pair (y_{s-1}, y_s)
    # s ranges from f-99 to f-1 (1-indexed)
    # y_{s-1} ranges from y_{f-100} to y_{f-2}
    # y_s ranges from y_{f-99} to y_{f-1}
    
    # 0-indexed:
    # s = f-99 to f-1 (1-indexed) => indices f-100 to f-2 (0-indexed)
    # y_{s-1}: indices f-101 to f-3 (0-indexed)  -- wait that's only using 99 of the 100 values
    # Actually y_{s} at index s-1 (0-based), y_{s-1} at index s-2 (0-based)
    
    # Let me be precise: time t maps to 0-index t-1
    # s goes from (f-99) to (f-1) in 1-indexed time
    # y_s (regressand) = y at 0-index s-1 = y[f-100] to y[f-2]
    # y_{s-1} (regressor) = y at 0-index s-2 = y[f-101] to y[f-3]... 
    # That's 99 pairs, using y[f-101] to y[f-2] from the window
    # But the window says y_{f-100},...,y_{f-1} = y[f-101],...,y[f-2] (0-indexed) = 100 values
    # And y_{f-1} = y[f-2] (0-indexed) is the last regressor lag before y_f
    
    # Regressand (y_s for s=f-99 to f-1, 1-indexed):
    #   0-indexed: y[f-100] to y[f-2], 99 values
    # Regressor (y_{s-1} for s=f-99 to f-1, 1-indexed):
    #   0-indexed: y[f-101] to y[f-3], 99 values
    
    # All within the 100-value window y[f-101] to y[f-2]
    
    # Forecast y_f (0-index f-1) using a_hat + b_hat * y_{f-1} (0-index f-2)
    
    window_start = f - 101  # 0-indexed start of window (= y_{f-100} in 1-indexed)
    window_end = f - 2      # 0-indexed end of window (= y_{f-1} in 1-indexed)
    
    # Regressor: y[window_start] to y[window_end-1] (99 values)
    X_lag = y[window_start:window_end]    # 99 values
    # Regressand: y[window_start+1] to y[window_end] (99 values)
    Y_dep = y[window_start+1:window_end+1]  # 99 values
    
    assert len(X_lag) == 99
    assert len(Y_dep) == 99
    
    X = sm.add_constant(X_lag)
    model = sm.OLS(Y_dep, X).fit()
    
    a_hat = model.params[0]
    b_hat = model.params[1]
    
    y_f_minus_1 = y[f-2]  # y_{f-1} in 1-indexed = 0-indexed f-2
    forecast = a_hat + b_hat * y_f_minus_1
    forecasts[f] = forecast

# Compute RMSE
actual = [y[f-1] for f in range(101, 251)]  # y_f for f=101..250, 0-indexed f-1
pred = [forecasts[f] for f in range(101, 251)]
residuals = np.array(actual) - np.array(pred)
rmse = np.sqrt(np.sum(residuals**2) / 150)

print(f"RMSE: {rmse:.8f}")
print(f"forecast_101: {forecasts[101]:.8f}")
print(f"forecast_150: {forecasts[150]:.8f}")
print(f"forecast_200: {forecasts[200]:.8f}")
print(f"forecast_250: {forecasts[250]:.8f}")

result = {
    "task_id": "hard_rolling",
    "platform": "python",
    "estimates": [
        {"term": "rmse", "estimate": rmse, "se": None, "n_obs": 150},
        {"term": "forecast_101", "estimate": forecasts[101], "se": None, "n_obs": 99},
        {"term": "forecast_150", "estimate": forecasts[150], "se": None, "n_obs": 99},
        {"term": "forecast_200", "estimate": forecasts[200], "se": None, "n_obs": 99},
        {"term": "forecast_250", "estimate": forecasts[250], "se": None, "n_obs": 99},
    ],
    "method_metadata": {"estimator": "OLS AR(1) rolling window", "vcov": "null"},
    "diagnostics": {}
}

with open('result.json', 'w') as f_out:
    json.dump(result, f_out, indent=2)

print("result.json written.")
