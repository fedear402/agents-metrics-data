import json
import pandas as pd
import statsmodels.api as sm
import numpy as np

df = pd.read_csv("./input.csv")
df = df.sort_values("t").reset_index(drop=True)

# Construct variables:
# y_{t+4}: forward shift y by 4
# shock_t: current shock
# y_{t-1}: lag y by 1
df["y_fwd4"] = df["y"].shift(-4)
df["y_lag1"] = df["y"].shift(1)

reg = df[["y_fwd4", "shock", "y_lag1"]].dropna()
Y = reg["y_fwd4"]
X = sm.add_constant(reg[["shock", "y_lag1"]])

fit = sm.OLS(Y, X).fit(cov_type="HAC", cov_kwds={"maxlags": 4})

irf_h4 = float(fit.params["shock"])
se_h4 = float(fit.bse["shock"])
n_obs = int(fit.nobs)

print(f"irf_h4 estimate: {irf_h4}")
print(f"irf_h4 SE (NW-4): {se_h4}")
print(f"n_obs: {n_obs}")

out = {
    "task_id": "lp_irf",
    "platform": "python",
    "estimates": [
        {"term": "irf_h4", "estimate": irf_h4, "se": se_h4, "n_obs": n_obs}
    ],
    "method_metadata": {
        "estimator": "Local Projection OLS, horizon h=4",
        "vcov": "Newey-West HAC, maxlags=4"
    },
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(out, f, indent=2)

print("result.json written.")
