import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")

# Apply bandwidth filter: abs(score) < 1
bw = df[np.abs(df["score"]) < 1].copy()
n_obs = len(bw)

# Triangular weights
bw["w"] = 1 - np.abs(bw["score"])

# Indicator for right side (score >= 0)
bw["above"] = (bw["score"] >= 0).astype(float)

# Design matrix: [1, above, score, above*score]
# This fits separate local-linear slopes on both sides, with separate intercepts
score = bw["score"].values
above = bw["above"].values
w = bw["w"].values
earnings = bw["earnings"].values
participated = bw["participated"].values

X = np.column_stack([
    np.ones(n_obs),   # intercept (left side intercept)
    above,            # right side intercept shift (discontinuity)
    score,            # left side slope
    above * score     # right side slope shift
])

Y = np.column_stack([earnings, participated])

# Weighted WLS
W = w
bread = np.linalg.inv(X.T @ (W[:, None] * X))
coefficients = bread @ X.T @ (W[:, None] * Y)
residuals = Y - X @ coefficients

# The discontinuity is the coefficient on 'above' (index 1)
contrast = np.array([0., 1., 0., 0.])
jumps = contrast @ coefficients
reduced_form_jump = jumps[0]   # earnings discontinuity
first_stage_jump = jumps[1]    # participation discontinuity

# HC0 standard errors: influence functions
loading = W * (X @ bread @ contrast)
influence = loading[:, None] * residuals   # shape (n, 2)

joint = influence.T @ influence  # 2x2 joint covariance

reduced_form_se = float(np.sqrt(joint[0, 0]))
first_stage_se = float(np.sqrt(joint[1, 1]))

# Delta method for treatment_effect = reduced_form / first_stage
rf = float(reduced_form_jump)
fs = float(first_stage_jump)
treatment_effect = rf / fs

gradient = np.array([1.0 / fs, -rf / fs**2])
treatment_effect_se = float(np.sqrt(gradient @ joint @ gradient))

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": treatment_effect, "se": treatment_effect_se, "n_obs": n_obs},
        {"term": "reduced_form", "estimate": rf, "se": reduced_form_se, "n_obs": n_obs},
        {"term": "first_stage", "estimate": fs, "se": first_stage_se, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "fuzzy_rd_local_linear_wls",
        "vcov": "HC0"
    },
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2, allow_nan=False)

print(f"n_obs: {n_obs}")
print(f"reduced_form: {rf:.8f}, se: {reduced_form_se:.8f}")
print(f"first_stage: {fs:.8f}, se: {first_stage_se:.8f}")
print(f"treatment_effect: {treatment_effect:.8f}, se: {treatment_effect_se:.8f}")
print(f"covariance(rf, fs): {joint[0,1]:.8f}")
