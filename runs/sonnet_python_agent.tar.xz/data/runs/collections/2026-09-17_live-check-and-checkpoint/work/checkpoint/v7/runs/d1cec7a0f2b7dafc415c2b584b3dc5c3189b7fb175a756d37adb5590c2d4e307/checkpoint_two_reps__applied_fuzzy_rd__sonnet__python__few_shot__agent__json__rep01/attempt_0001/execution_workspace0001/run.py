import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")

# Apply bandwidth: abs(score) < 1
mask = df["score"].abs() < 1
df_bw = df[mask].copy()
n_obs = len(df_bw)

# Triangular weights
df_bw["w"] = 1 - df_bw["score"].abs()

# Indicator for right side (score >= 0)
df_bw["above"] = (df_bw["score"] >= 0).astype(float)

# Design matrix: intercept, score, above, above*score (separate slopes on each side)
X = np.column_stack([
    np.ones(n_obs),
    df_bw["score"].values,
    df_bw["above"].values,
    df_bw["above"].values * df_bw["score"].values
])

w = df_bw["w"].values
Y_earnings = df_bw["earnings"].values
Y_participated = df_bw["participated"].values

# Stack outcomes
Y = np.column_stack([Y_earnings, Y_participated])

# WLS: beta = (X'WX)^{-1} X'WY
W = np.diag(w)
XtW = X.T * w  # shape (4, n)
bread = np.linalg.inv(XtW @ X)
coefficients = bread @ XtW @ Y

# The discontinuity (right limit - left limit at score=0) is the coefficient on "above"
# contrast: [0, 0, 1, 0]
contrast = np.array([0., 0., 1., 0.])
jumps = contrast @ coefficients  # [earnings_jump, participated_jump]

# Residuals
residuals = Y - X @ coefficients

# HC0 sandwich: each obs contributes loading * residual to influence
# loading = w * (X @ bread @ contrast)
loading = w * (X @ bread @ contrast)  # shape (n,)
influence = loading[:, None] * residuals  # shape (n, 2)
joint = influence.T @ influence  # shape (2, 2)

earnings_jump, participated_jump = jumps
se_rf = float(np.sqrt(joint[0, 0]))
se_fs = float(np.sqrt(joint[1, 1]))

# Delta method for ratio (treatment effect = earnings_jump / participated_jump)
gradient = np.array([1.0 / participated_jump, -earnings_jump / participated_jump**2])
se_te = float(np.sqrt(gradient @ joint @ gradient))
treatment_effect = float(earnings_jump / participated_jump)

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": treatment_effect, "se": se_te, "n_obs": n_obs},
        {"term": "reduced_form", "estimate": float(earnings_jump), "se": se_rf, "n_obs": n_obs},
        {"term": "first_stage", "estimate": float(participated_jump), "se": se_fs, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "fuzzy_RD_local_linear_WLS",
        "vcov": "HC0"
    },
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2, allow_nan=False)

print("n_obs:", n_obs)
print("earnings_jump (reduced_form):", earnings_jump)
print("participated_jump (first_stage):", participated_jump)
print("treatment_effect:", treatment_effect)
print("se_rf:", se_rf)
print("se_fs:", se_fs)
print("se_te:", se_te)
print("covariance:", float(joint[0,1]))
