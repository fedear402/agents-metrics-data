import json
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.stats import norm
from statsmodels.tools.numdiff import approx_hess

df = pd.read_csv('input.csv')
n = len(df)
y = df['y'].values
design = np.column_stack([np.ones(n), df['x'].values, df['z'].values])
censored = y == 0.0

def loss(params):
    beta = params[:3]
    log_sigma = params[3]
    sigma = np.exp(log_sigma)
    mean = design @ beta
    # censored: P(latent<=0) = Phi((0-mean)/sigma)
    a = (0. - mean[censored]) / sigma
    # uncensored: density at y
    r = (y[~censored] - mean[~censored]) / sigma
    ll = norm.logcdf(a).sum() + (norm.logpdf(r) - np.log(sigma)).sum()
    return -ll

def gradient(params):
    """Gradient of negative log-likelihood."""
    beta = params[:3]
    log_sigma = params[3]
    sigma = np.exp(log_sigma)
    mean = design @ beta
    a = (0. - mean[censored]) / sigma
    mills = np.exp(norm.logpdf(a) - norm.logcdf(a))  # phi(a)/Phi(a)
    r = (y[~censored] - mean[~censored]) / sigma

    # d(-ll)/d(beta):
    # censored: -mills * d(a)/d(beta) = -mills * (-1/sigma)*design = mills/sigma * design
    # uncensored: -(-r)*d(r)/d(beta) + 0 = r * (-1/sigma)*design -> wait:
    # d(-ll)/d(beta) uncensored = -d(log phi(r))/d(beta) = r * (1/sigma) * (-design) = -r/sigma * design
    coef_score = design[censored].T @ (mills / sigma) + design[~censored].T @ (-r / sigma)

    # d(-ll)/d(log_sigma):
    # d(a)/d(log_sigma) = sigma * (0-mean)/(-sigma^2) * (-1) ... let's be explicit:
    # a = (0-mean)/sigma => da/d(sigma) = -(0-mean)/sigma^2 = mean/sigma^2 (since 0-mean=-mean)
    # actually da/d(sigma) = (0-mean)*(-1/sigma^2) = mean/sigma^2... no:
    # da/d(sigma) = d/d(sigma)[(0-mean)/sigma] = (0-mean)*(-1/sigma^2) = mean/sigma^2 - wait
    # (0-mean)/sigma differentiated wrt sigma: = (0-mean) * d(1/sigma)/d(sigma) = (0-mean)*(-1/sigma^2)
    # = -(0-mean)/sigma^2 = mean/sigma^2... but mean could be anything
    # Actually simpler: a = -mean/sigma, so da/d(sigma) = mean/sigma^2, da/d(log_sigma) = sigma*da/d(sigma) = mean/sigma
    # But a = -mean/sigma => mean/sigma = -a. So da/d(log_sigma) = -a.
    #
    # censored: d(-ll)/d(log_sigma) from censored = -mills * (-a) = a*mills
    # uncensored: dr/d(log_sigma) = -r (similar reasoning)
    # d(-ll)/d(log_sigma) from uncensored = -(-r)*(-r) + 1 = -r^2+1 = 1-r^2
    sigma_score = np.sum(a * mills) + np.sum(1. - r * r)

    return np.r_[coef_score, sigma_score]

def num_grad(params, eps=1e-6):
    g = np.zeros(len(params))
    for j in range(len(params)):
        dp = np.zeros(len(params)); dp[j] = eps
        g[j] = (loss(params + dp) - loss(params - dp)) / (2 * eps)
    return g

# Check gradient at two points away from optimum
test_points = [
    np.array([0.5, 0.5, 0.5, np.log(0.5)]),
    np.array([1.2, -0.3, 0.8, np.log(0.9)]),
]
print("=== Gradient checks ===")
for pt in test_points:
    ag = gradient(pt)
    ng = num_grad(pt)
    ok = np.allclose(ag, ng, atol=1e-5, rtol=1e-6)
    print(f"  match={ok}  max_diff={np.max(np.abs(ag-ng)):.2e}")
    if not ok:
        print("  analytic:", ag)
        print("  numeric: ", ng)

# Optimize
init = np.array([0.5, 0.5, 0.0, np.log(0.5)])
fit = minimize(loss, init, jac=gradient, method='BFGS', options={'gtol': 1e-9, 'maxiter': 2000})
print("\n=== Optimization ===")
print("Converged:", fit.success, fit.message)
print("Max |grad| analytic:", np.max(np.abs(gradient(fit.x))))
print("Max |grad| numeric: ", np.max(np.abs(num_grad(fit.x))))
print("Params:", fit.x)

# Observed information from actual likelihood
info = approx_hess(fit.x, loss)
print("\nInfo symmetric:", np.allclose(info, info.T, atol=1e-8))
eigvals = np.linalg.eigvalsh(info)
print("Min eigenvalue:", eigvals.min())
cov = np.linalg.inv(info)
ses = np.sqrt(np.diag(cov))

sigma_est = np.exp(fit.x[3])

print(f"\nconst: {fit.x[0]:.8f} +/- {ses[0]:.8f}")
print(f"x:     {fit.x[1]:.8f} +/- {ses[1]:.8f}")
print(f"z:     {fit.x[2]:.8f} +/- {ses[2]:.8f}")
print(f"sigma: {sigma_est:.8f}")

output = {
    "task_id": "broad_tobit",
    "platform": "python",
    "estimates": [
        {"term": "const", "estimate": float(fit.x[0]), "se": float(ses[0]), "n_obs": n},
        {"term": "x",     "estimate": float(fit.x[1]), "se": float(ses[1]), "n_obs": n},
        {"term": "z",     "estimate": float(fit.x[2]), "se": float(ses[2]), "n_obs": n},
        {"term": "sigma", "estimate": float(sigma_est), "se": None, "n_obs": n},
    ],
    "method_metadata": {
        "estimator": "Tobit MLE (left-censored at 0)",
        "vcov": "observed information (numerical Hessian of joint log-likelihood)"
    },
    "diagnostics": {}
}

with open('result.json', 'w') as f:
    json.dump(output, f, indent=2, allow_nan=False)

print("\nresult.json written.")
