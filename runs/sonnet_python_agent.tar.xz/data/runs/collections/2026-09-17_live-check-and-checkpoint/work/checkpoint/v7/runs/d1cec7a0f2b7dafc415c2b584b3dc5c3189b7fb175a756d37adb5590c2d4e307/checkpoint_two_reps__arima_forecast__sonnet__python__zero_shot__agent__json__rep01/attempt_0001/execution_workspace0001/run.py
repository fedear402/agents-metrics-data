import pandas as pd
import numpy as np
import json
from statsmodels.tsa.arima.model import ARIMA

# Load data
df = pd.read_csv("input.csv")
y = df["y"].values
n_obs = len(y)

# Fit ARIMA(1,1,1) with no constant (trend='n')
model = ARIMA(y, order=(1, 1, 1), trend='n')
result = model.fit(method='innovations_mle')

# One-step-ahead forecast for t=251 (one step beyond the sample)
forecast_obj = result.get_forecast(steps=1)
forecast_mean = forecast_obj.predicted_mean[0]
forecast_se = forecast_obj.se_mean[0]
ci = forecast_obj.conf_int(alpha=0.05)
lower_95 = ci[0, 0]
upper_95 = ci[0, 1]

print(f"n_obs: {n_obs}")
print(f"AR(1): {result.params}")
print(f"forecast: {forecast_mean}")
print(f"forecast_se: {forecast_se}")
print(f"lower_95: {lower_95}")
print(f"upper_95: {upper_95}")

output = {
    "task_id": "arima_forecast",
    "platform": "python",
    "estimates": [
        {"term": "forecast", "estimate": float(forecast_mean), "se": float(forecast_se), "n_obs": n_obs},
        {"term": "lower_95", "estimate": float(lower_95), "se": None, "n_obs": n_obs},
        {"term": "upper_95", "estimate": float(upper_95), "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "ARIMA(1,1,1) MLE via statsmodels innovations_mle, no constant",
        "vcov": "OPG (outer product of gradients)"
    },
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(output, f, indent=2)

print("Done. result.json written.")
