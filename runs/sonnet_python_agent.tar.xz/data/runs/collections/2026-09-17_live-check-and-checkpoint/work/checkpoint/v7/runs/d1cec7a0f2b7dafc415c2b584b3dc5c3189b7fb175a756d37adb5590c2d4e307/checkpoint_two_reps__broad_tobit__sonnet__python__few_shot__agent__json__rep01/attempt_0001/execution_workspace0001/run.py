import json
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.stats import norm
from statsmodels.tools.numdiff import approx_hess

df = pd.read_csv('input.csv')
n = len(df)
y = df['y'].values
design = np.column_stack([np.ones(n), df['x'].values, df['z'].values])
censored = y == 0.

def loss(parameter):
    mean = design @ parameter[:3]
    scale = np.exp(parameter[3])
    a = (0. - mean[censored]) / scale
    r = (y[~censored] - mean[~censored]) / scale
    return -norm.logcdf(a).sum() - (norm.logpdf(r) - np.log(scale)).sum()

def gradient(parameter):
    mean = design @ parameter[:3]
    scale = np.exp(parameter[3])
    a = (0. - mean[censored]) / scale
    mills = np.exp(norm.logpdf(a) - norm.logcdf(a))
    r = (y[~censored] - mean[~censored]) / scale
    coef_score = design[censored].T @ (mills / scale)
    coef_score -= design[~censored].T @ (r / scale)
    scale_score = np.sum(a * mills) + np.sum(1. - r * r)
    return np.r_[coef_score, scale_score]

def numerical_gradient(parameter):
    answer = np.zeros(4)
    for j in range(4):
        step = np.zeros(4)
        step[j] = 1e-5
        answer[j] = (loss(parameter + step) - loss(parameter - step)) / 2e-5
    return answer

# Check derivatives at non-stationary points
initial = np.array([0.5, 0.5, 0.5, np.log(1.0)])
for point in [initial, np.array([1.0, 0.3, -0.2, np.log(1.5)])]:
    ag = gradient(point)
    ng = numerical_gradient(point)
    assert np.allclose(ag, ng, atol=1e-5, rtol=1e-6), f"Gradient mismatch: {ag} vs {ng}"

fit = minimize(loss, initial, jac=gradient, method='BFGS', options={'gtol': 1e-8})
assert np.isfinite(loss(fit.x))
assert np.max(np.abs(gradient(fit.x))) < 1e-5
assert np.max(np.abs(numerical_gradient(fit.x))) < 1e-5

# Observed information from actual likelihood
information = approx_hess(fit.x, loss)
assert np.allclose(information, information.T, atol=1e-8)
assert np.linalg.eigvalsh(information).min() > 0
covariance = np.linalg.inv(information)

sigma = float(np.exp(fit.x[3]))
estimates = [
    {'term': 'const', 'estimate': float(fit.x[0]), 'se': float(np.sqrt(covariance[0, 0])), 'n_obs': n},
    {'term': 'x',     'estimate': float(fit.x[1]), 'se': float(np.sqrt(covariance[1, 1])), 'n_obs': n},
    {'term': 'z',     'estimate': float(fit.x[2]), 'se': float(np.sqrt(covariance[2, 2])), 'n_obs': n},
    {'term': 'sigma', 'estimate': sigma,            'se': None,                              'n_obs': n},
]

output = {
    'task_id': 'broad_tobit',
    'platform': 'python',
    'estimates': estimates,
    'method_metadata': {
        'estimator': 'MLE Tobit (left-censored at 0)',
        'vcov': 'observed information (numerical Hessian of joint log-likelihood)'
    },
    'diagnostics': {}
}

with open('result.json', 'w') as f:
    json.dump(output, f, indent=2, allow_nan=False)

print("Optimization success:", fit.success)
print("Max gradient at solution:", np.max(np.abs(gradient(fit.x))))
print("Parameters:", fit.x)
print("Sigma:", sigma)
print("SE(const):", np.sqrt(covariance[0,0]))
print("SE(x):", np.sqrt(covariance[1,1]))
print("SE(z):", np.sqrt(covariance[2,2]))
