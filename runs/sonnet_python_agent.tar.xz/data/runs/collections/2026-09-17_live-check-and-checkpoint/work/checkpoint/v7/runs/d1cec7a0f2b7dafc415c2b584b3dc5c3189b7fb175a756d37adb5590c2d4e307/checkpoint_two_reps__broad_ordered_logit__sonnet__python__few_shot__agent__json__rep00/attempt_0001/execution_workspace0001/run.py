import json
import numpy as np
import pandas as pd
from scipy.special import expit
from statsmodels.miscmodels.ordinal_model import OrderedModel

df = pd.read_csv('input.csv')
n = len(df)

y = df['y'].values
X = df[['x', 'z']].values

model = OrderedModel(y, X, distr='logit')
fit = model.fit(method='bfgs', disp=False, gtol=1e-8)

params = fit.params
bse = fit.bse

x_slope = float(params[0])
z_slope = float(params[1])
x_se = float(bse[0])
z_se = float(bse[1])

# Predict prob of category 3 at x=1, z=0
pred = model.predict(params, exog=np.array([[1.0, 0.0]]))[0, 2]
prob_high = float(pred)

# Verification: check using transform_threshold_params
threshold = model.transform_threshold_params(params)
# P(y=3) = 1 - logistic(cutpoint[2]) where cutpoint is the upper threshold
# For 3 categories, threshold has indices 0 (lower bound=-inf), 1, 2, 3 (upper bound=+inf)
# P(y>=3) = 1 - expit(threshold[2] - x_slope*1 - z_slope*0)
# Actually need to check statsmodels convention
verify_prob = 1 - expit(threshold[2] - x_slope * 1.0 - z_slope * 0.0)
print(f"Direct prediction: {prob_high}")
print(f"Manual calculation: {verify_prob}")
print(f"Match: {np.isclose(prob_high, verify_prob)}")
print(f"x slope: {x_slope}, se: {x_se}")
print(f"z slope: {z_slope}, se: {z_se}")
print(f"n_obs: {n}")
print(f"Thresholds: {threshold}")

result = {
    "task_id": "broad_ordered_logit",
    "platform": "python",
    "estimates": [
        {"term": "x", "estimate": x_slope, "se": x_se, "n_obs": n},
        {"term": "z", "estimate": z_slope, "se": z_se, "n_obs": n},
        {"term": "prob_high", "estimate": prob_high, "se": None, "n_obs": n}
    ],
    "method_metadata": {"estimator": "OrderedLogit_BFGS", "vcov": "observed_information"},
    "diagnostics": {}
}

with open('result.json', 'w') as f:
    json.dump(result, f, indent=2, allow_nan=False)

print("\nresult.json written successfully")
