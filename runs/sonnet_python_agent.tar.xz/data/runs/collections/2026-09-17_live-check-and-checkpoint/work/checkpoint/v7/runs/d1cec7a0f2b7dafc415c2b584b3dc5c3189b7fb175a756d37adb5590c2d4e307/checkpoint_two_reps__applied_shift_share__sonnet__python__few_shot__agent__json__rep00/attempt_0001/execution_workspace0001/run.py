import json
import numpy as np
import pandas as pd

df = pd.read_csv('input.csv')

# Get one obs per region for regional-level variables
regions = df.drop_duplicates('region_id')[['region_id','region_weight','x','y']].copy()
regions = regions.set_index('region_id')

# Normalize regional weights
regions['e'] = regions['region_weight'] / regions['region_weight'].sum()
e = regions['e'].values
x_r = regions['x'].values
y_r = regions['y'].values

# Construct shift-share instrument z_r = sum_n share_rn * shock_n
# Need shares as region x industry matrix
region_ids = regions.index.values
industry_ids = sorted(df['industry_id'].unique())
n_regions = len(region_ids)
n_industries = len(industry_ids)

region_idx = {r: i for i, r in enumerate(region_ids)}
industry_idx = {ind: i for i, ind in enumerate(industry_ids)}

shares = np.zeros((n_regions, n_industries))
for _, row in df.iterrows():
    r = region_idx[row['region_id']]
    n = industry_idx[row['industry_id']]
    shares[r, n] = row['share']

# Get shocks (constant within industry)
shock_by_industry = df.groupby('industry_id')['shock'].first()
shock = np.array([shock_by_industry[ind] for ind in industry_ids])

# Construct instrument
z_r = shares @ shock

# Compute weighted means
mean_x = np.dot(e, x_r)
mean_y = np.dot(e, y_r)
mean_z = np.dot(e, z_r)

# Centered residuals
x0 = x_r - mean_x
y0 = y_r - mean_y
z0 = z_r - mean_z

# Compute industry exposure masses s_n = sum_r e_r * share_rn
s_n = e @ shares  # shape (n_industries,)

# Aggregate residuals at shock level: vbar_n = sum_r e_r * share_rn * v0_r / s_n
ybar = (e[:, None] * shares * y0[:, None]).sum(axis=0) / s_n
xbar = (e[:, None] * shares * x0[:, None]).sum(axis=0) / s_n
zbar = (e[:, None] * shares * z0[:, None]).sum(axis=0) / s_n

N = n_industries  # number of industries

def shock_iv(dependent, endogenous, instrument_vec, weights):
    """IV regression with intercept, HC1 SE, using analytic weights."""
    regressors = np.column_stack([np.ones(N), endogenous])
    instruments = np.column_stack([np.ones(N), instrument_vec])
    # Weighted cross products
    W = weights
    cross = instruments.T @ (W[:, None] * regressors)
    beta = np.linalg.solve(cross, instruments.T @ (W * dependent))
    # Structural residuals
    residual = dependent - regressors @ beta
    scores = instruments * (W * residual)[:, None]
    inverse = np.linalg.inv(cross)
    hc1 = N / (N - 2)
    covariance = hc1 * inverse @ (scores.T @ scores) @ inverse.T
    return float(beta[1]), float(np.sqrt(covariance[1, 1]))

# Effect: 2SLS of ybar on xbar, instrumenting xbar with shock
effect_slope, effect_se = shock_iv(ybar, xbar, shock, s_n)

# First stage: shock-level IV of xbar on zbar, instrumenting zbar with shock
first_stage_slope, first_stage_se = shock_iv(xbar, zbar, shock, s_n)

# Effective shocks
effective_shocks = 1.0 / np.sum(s_n ** 2)

# Verify: regional 2SLS slope
regional_2sls = np.dot(e * z0, y0) / np.dot(e * z0, x0)
regional_fs = np.dot(e * z0, x0) / np.dot(e * z0, z0)
print(f"Effect slope: {effect_slope:.8f}, Regional 2SLS check: {regional_2sls:.8f}")
print(f"First stage slope: {first_stage_slope:.8f}, Regional FS check: {regional_fs:.8f}")

output = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": effect_slope, "se": effect_se, "n_obs": N},
        {"term": "first_stage", "estimate": first_stage_slope, "se": first_stage_se, "n_obs": N},
        {"term": "effective_shocks", "estimate": float(effective_shocks), "se": None, "n_obs": N}
    ],
    "method_metadata": {
        "estimator": "2SLS shift-share IV with exposure-robust HC1 SE (Borusyak-Hull-Jaravel)",
        "vcov": "HC1 shock-level aggregation"
    },
    "diagnostics": {}
}

with open('result.json', 'w') as f:
    json.dump(output, f, indent=2, allow_nan=False)

print("Done. result.json written.")
