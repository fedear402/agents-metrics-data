import pandas as pd
import numpy as np
import json

df = pd.read_csv("input.csv")

# Apply bandwidth filter: abs(score) < 1
mask = df["score"].abs() < 1
data = df[mask].copy()
n_obs = len(data)

# Triangular weights
data["w"] = 1 - data["score"].abs()

# Indicator for right side (score >= 0)
data["D"] = (data["score"] >= 0).astype(float)

# Local linear regression design matrix
# For each side: intercept + slope*score
# Overall: intercept_left, slope_left, jump (D), slope_right_extra (D*score)
# y ~ 1 + score + D + D*score with WLS and triangular weights

# Design matrix
data["score_D"] = data["D"] * data["score"]
X = data[["D", "score", "score_D"]].copy()
X.insert(0, "const", 1.0)
X_mat = X.values
W = np.diag(data["w"].values)

# WLS: (X'WX)^{-1} X'Wy
XtW = X_mat.T @ W
XtWX = XtW @ X_mat
XtWX_inv = np.linalg.inv(XtWX)

# Fit for earnings (reduced form)
y_earn = data["earnings"].values
beta_earn = XtWX_inv @ XtW @ y_earn

# Fit for participation (first stage)
y_part = data["participated"].values
beta_part = XtWX_inv @ XtW @ y_part

# Reduced form and first stage are the coefficients on D (index 1 in [const, D, score, score_D])
rf_est = beta_earn[1]
fs_est = beta_part[1]

# Treatment effect via Wald/IV = RF / FS
te_est = rf_est / fs_est

# HC0 robust standard errors
# Residuals
resid_earn = y_earn - X_mat @ beta_earn
resid_part = y_part - X_mat @ beta_part

# Meat matrices for HC0 (with triangular weights applied to X)
# Score equation: (X'WX)^{-1} [sum_i w_i^2 * x_i x_i' * e_i^2] (X'WX)^{-1}
# But we have WLS, so the weighted residual sandwich:
# Var(beta) = (X'WX)^{-1} [sum_i (w_i * x_i * e_i)^2] (X'WX)^{-1}
# where e_i are OLS residuals from the weighted regression

# Each row contribution: w_i * x_i * e_i
def hc0_cov(X_mat, W_diag, resid):
    # WX weighted rows, then multiply by residuals
    WX = W_diag[:, None] * X_mat  # w_i * x_i
    meat_rows = WX * resid[:, None]  # w_i * x_i * e_i
    meat = meat_rows.T @ meat_rows
    return XtWX_inv @ meat @ XtWX_inv

W_diag = data["w"].values

cov_earn = hc0_cov(X_mat, W_diag, resid_earn)
cov_part = hc0_cov(X_mat, W_diag, resid_part)

# SE for RF and FS (coefficient index 1 = D)
se_rf = np.sqrt(cov_earn[1, 1])
se_fs = np.sqrt(cov_part[1, 1])

# For treatment_effect delta method, need joint covariance of (beta_earn[1], beta_part[1])
# Cross-covariance using sandwich estimator
# Cov(beta_earn, beta_part) = (X'WX)^{-1} [sum_i w_i^2 * x_i x_i' * e_earn_i * e_part_i] (X'WX)^{-1}
cross_meat_rows = (W_diag[:, None] * X_mat * resid_earn[:, None]) 
cross_meat_rows2 = (W_diag[:, None] * X_mat * resid_part[:, None])
cross_meat = cross_meat_rows.T @ cross_meat_rows2
cov_cross = XtWX_inv @ cross_meat @ XtWX_inv

# Cov(rf_est, fs_est) = cross_cov[1,1]
cov_rf_fs = cov_cross[1, 1]

# Delta method for te = rf / fs
# Var(te) = (1/fs)^2 * Var(rf) + (rf/fs^2)^2 * Var(fs) - 2*(1/fs)*(rf/fs^2)*Cov(rf,fs)
var_te = (1/fs_est)**2 * cov_earn[1,1] + (rf_est/fs_est**2)**2 * cov_part[1,1] - 2*(1/fs_est)*(rf_est/fs_est**2)*cov_rf_fs
se_te = np.sqrt(var_te)

print(f"n_obs: {n_obs}")
print(f"RF (earnings discontinuity): {rf_est:.8f}, SE: {se_rf:.8f}")
print(f"FS (participation discontinuity): {fs_est:.8f}, SE: {se_fs:.8f}")
print(f"TE (treatment effect): {te_est:.8f}, SE: {se_te:.8f}")
print(f"Cov(RF,FS): {cov_rf_fs:.8f}")

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": float(te_est), "se": float(se_te), "n_obs": int(n_obs)},
        {"term": "reduced_form", "estimate": float(rf_est), "se": float(se_rf), "n_obs": int(n_obs)},
        {"term": "first_stage", "estimate": float(fs_est), "se": float(se_fs), "n_obs": int(n_obs)}
    ],
    "method_metadata": {
        "estimator": "fuzzy_RD_local_linear_WLS",
        "vcov": "HC0_no_dof_correction"
    },
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)

print("\nresult.json written.")
