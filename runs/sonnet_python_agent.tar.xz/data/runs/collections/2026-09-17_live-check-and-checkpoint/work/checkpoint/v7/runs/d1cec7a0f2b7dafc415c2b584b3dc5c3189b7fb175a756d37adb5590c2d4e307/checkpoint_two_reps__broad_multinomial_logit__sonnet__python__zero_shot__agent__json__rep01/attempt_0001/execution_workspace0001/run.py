import pandas as pd
import numpy as np
import json
from statsmodels.discrete.discrete_model import MNLogit

df = pd.read_csv("input.csv")
n_obs = len(df)

y = df["y"].astype(int)
X = pd.DataFrame({"const": 1.0, "x": df["x"], "z": df["z"]})

model = MNLogit(y, X)
result = model.fit(method="newton", maxiter=200, disp=False)

# params columns: 0 -> y=1, 1 -> y=2 (relative to base y=0)
params = result.params
bse = result.bse

x_cat1 = float(params.loc["x", 0])
z_cat1 = float(params.loc["z", 0])
x_cat2 = float(params.loc["x", 1])
z_cat2 = float(params.loc["z", 1])

se_x_cat1 = float(bse.loc["x", 0])
se_z_cat1 = float(bse.loc["z", 0])
se_x_cat2 = float(bse.loc["x", 1])
se_z_cat2 = float(bse.loc["z", 1])

# Fitted probability of outcome 2 at x=0, z=0
intercept_1 = float(params.loc["const", 0])  # for y=1
intercept_2 = float(params.loc["const", 1])  # for y=2

denom = 1.0 + np.exp(intercept_1) + np.exp(intercept_2)
prob_cat2_zero = float(np.exp(intercept_2) / denom)

output = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": [
        {"term": "x_cat1", "estimate": x_cat1, "se": se_x_cat1, "n_obs": n_obs},
        {"term": "z_cat1", "estimate": z_cat1, "se": se_z_cat1, "n_obs": n_obs},
        {"term": "x_cat2", "estimate": x_cat2, "se": se_x_cat2, "n_obs": n_obs},
        {"term": "z_cat2", "estimate": z_cat2, "se": se_z_cat2, "n_obs": n_obs},
        {"term": "prob_cat2_zero", "estimate": prob_cat2_zero, "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {"estimator": "MNLogit MLE", "vcov": "observed-information"},
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(output, f, indent=2)

print("Parameters:")
print(params)
print("\nSEs:")
print(bse)
print(f"\nprob_cat2_zero = {prob_cat2_zero:.10f}")
print(f"intercept_1={intercept_1:.8f}, intercept_2={intercept_2:.8f}")
