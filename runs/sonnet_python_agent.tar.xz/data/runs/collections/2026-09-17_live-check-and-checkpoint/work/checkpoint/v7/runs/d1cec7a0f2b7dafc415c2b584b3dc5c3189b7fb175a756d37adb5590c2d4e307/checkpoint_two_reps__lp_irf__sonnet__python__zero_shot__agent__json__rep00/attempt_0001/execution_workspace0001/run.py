import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

df = pd.read_csv('./input.csv')
df = df.sort_values('t').reset_index(drop=True)

# Construct variables:
# y_{t+4}: dependent variable shifted back 4 periods
# shock_t: shock at time t
# y_{t-1}: y lagged 1 period

df['y_lead4'] = df['y'].shift(-4)   # y at t+4
df['y_lag1']  = df['y'].shift(1)    # y at t-1

# Drop rows with NaN (first row loses y_lag1, last 4 rows lose y_lead4)
reg_df = df[['y_lead4', 'shock', 'y_lag1']].dropna()

n_obs = len(reg_df)

X = sm.add_constant(reg_df[['shock', 'y_lag1']])
y = reg_df['y_lead4']

model = sm.OLS(y, X)
# Newey-West with lag 4
result = model.fit(cov_type='HAC', cov_kwds={'maxlags': 4})

print(result.summary())
print(f"\nn_obs = {n_obs}")
print(f"shock coef = {result.params['shock']:.8f}")
print(f"shock se   = {result.bse['shock']:.8f}")

irf_h4_est = float(result.params['shock'])
irf_h4_se  = float(result.bse['shock'])

output = {
    "task_id": "lp_irf",
    "platform": "python",
    "estimates": [
        {
            "term": "irf_h4",
            "estimate": round(irf_h4_est, 10),
            "se": round(irf_h4_se, 10),
            "n_obs": n_obs
        }
    ],
    "method_metadata": {
        "estimator": "OLS local projection h=4",
        "vcov": "Newey-West HAC lag=4"
    },
    "diagnostics": {}
}

with open('./result.json', 'w') as f:
    json.dump(output, f, indent=2)

print("\nresult.json written.")
