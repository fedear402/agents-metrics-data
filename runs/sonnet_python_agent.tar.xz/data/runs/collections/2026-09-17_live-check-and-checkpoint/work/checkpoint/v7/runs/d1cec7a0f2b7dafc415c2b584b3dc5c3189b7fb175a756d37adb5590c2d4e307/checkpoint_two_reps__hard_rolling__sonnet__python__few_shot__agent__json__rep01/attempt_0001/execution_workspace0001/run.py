import json
import numpy as np
import pandas as pd

data = pd.read_csv("input.csv").sort_values("time").reset_index(drop=True)
assert len(data) == 250
assert data["time"].tolist() == list(range(1, 251))

forecast_times = list(range(101, 251))
forecasts = {}

for f in forecast_times:
    # Window: times f-100 through f-1 (100 levels)
    window = data.loc[data["time"].between(f - 100, f - 1), "y"].to_numpy(dtype=float)
    assert len(window) == 100
    
    # 99 regression pairs: (y_{s-1}, y_s) for s = f-99,...,f-1
    lagged = window[:-1]   # 99 values
    current = window[1:]   # 99 values
    assert len(lagged) == 99
    
    X = np.column_stack([np.ones(99), lagged])
    coeffs = np.linalg.lstsq(X, current, rcond=None)[0]
    
    # Forecast y_f = a_hat + b_hat * y_{f-1}
    forecasts[f] = float(coeffs[0] + coeffs[1] * window[-1])

# Compute RMSE over f=101..250
actual = data.set_index("time").loc[forecast_times, "y"].to_numpy(dtype=float)
predicted = np.array([forecasts[f] for f in forecast_times])
rmse = float(np.sqrt(np.mean((actual - predicted) ** 2)))

# Independent check: verify forecast_101 manually
f_check = 101
window_check = data.loc[data["time"].between(1, 100), "y"].to_numpy(dtype=float)
X_check = np.column_stack([np.ones(99), window_check[:-1]])
coeffs_check = np.linalg.lstsq(X_check, window_check[1:], rcond=None)[0]
forecast_101_check = float(coeffs_check[0] + coeffs_check[1] * window_check[-1])
print(f"forecast_101: {forecasts[101]:.8f}, check: {forecast_101_check:.8f}, match: {abs(forecasts[101]-forecast_101_check)<1e-10}")
print(f"RMSE: {rmse:.8f}")
print(f"n forecasts: {len(forecasts)}")

report_times = [101, 150, 200, 250]
estimates = [
    {"term": "rmse", "estimate": rmse, "se": None, "n_obs": 150},
    *[{"term": f"forecast_{f}", "estimate": forecasts[f], "se": None, "n_obs": 99}
      for f in report_times],
]

output = {
    "task_id": "hard_rolling",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {"estimator": "OLS AR(1) with intercept, rolling window of 100 levels (99 pairs)", "vcov": "null"},
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(output, f, indent=2, allow_nan=False)

print("result.json written.")
