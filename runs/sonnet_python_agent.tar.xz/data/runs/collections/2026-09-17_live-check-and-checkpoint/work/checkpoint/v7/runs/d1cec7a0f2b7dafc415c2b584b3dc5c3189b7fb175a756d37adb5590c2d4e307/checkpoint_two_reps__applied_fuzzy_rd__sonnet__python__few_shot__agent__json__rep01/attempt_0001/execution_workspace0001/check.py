import numpy as np
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("input.csv")
mask = df["score"].abs() < 1
df_bw = df[mask].copy()
n_obs = len(df_bw)

df_bw["w"] = 1 - df_bw["score"].abs()
df_bw["above"] = (df_bw["score"] >= 0).astype(float)
df_bw["score_above"] = df_bw["above"] * df_bw["score"]

X_cols = ["above", "score", "score_above"]
X = sm.add_constant(df_bw[X_cols])

# Fit WLS for earnings with HC0
mod_earn = sm.WLS(df_bw["earnings"], X, weights=df_bw["w"]).fit(cov_type="HC0")
# Fit WLS for participation with HC0
mod_part = sm.WLS(df_bw["participated"], X, weights=df_bw["w"]).fit(cov_type="HC0")

print("=== Earnings (reduced_form) ===")
print(f"  above coeff: {mod_earn.params['above']:.8f}")
print(f"  above SE (HC0): {mod_earn.bse['above']:.8f}")

print("=== Participation (first_stage) ===")
print(f"  above coeff: {mod_part.params['above']:.8f}")
print(f"  above SE (HC0): {mod_part.bse['above']:.8f}")

# Verify n_obs
print(f"n_obs: {n_obs}")

# Cross check: manually compute HC0 using statsmodels sandwich
# statsmodels HC0 for WLS: uses weights in the bread but NOT in meat — let's check
# Actually statsmodels WLS HC0 may differ from our manual HC0 — let's inspect

# Let's also verify by computing via the formula manually with numpy
df2 = df_bw.copy()
w = df2["w"].values
X2 = np.column_stack([np.ones(n_obs), df2["above"].values, df2["score"].values, df2["score_above"].values])
Y_e = df2["earnings"].values
Y_p = df2["participated"].values

XtW = X2.T * w
bread = np.linalg.inv(XtW @ X2)
coef_e = bread @ XtW @ Y_e
coef_p = bread @ XtW @ Y_p

res_e = Y_e - X2 @ coef_e
res_p = Y_p - X2 @ coef_p

contrast = np.array([0., 1., 0., 0.])
loading = w * (X2 @ bread @ contrast)

infl_e = loading * res_e
infl_p = loading * res_p

var_e = np.sum(infl_e**2)
var_p = np.sum(infl_p**2)
cov_ep = np.sum(infl_e * infl_p)

print("\n=== Manual check ===")
print(f"  reduced_form: {coef_e[1]:.8f}, se: {np.sqrt(var_e):.8f}")
print(f"  first_stage:  {coef_p[1]:.8f}, se: {np.sqrt(var_p):.8f}")
print(f"  covariance:   {cov_ep:.8f}")

te = coef_e[1] / coef_p[1]
grad = np.array([1/coef_p[1], -coef_e[1]/coef_p[1]**2])
J = np.array([[var_e, cov_ep],[cov_ep, var_p]])
se_te = np.sqrt(grad @ J @ grad)
print(f"  treatment_effect: {te:.8f}, se: {se_te:.8f}")
