import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

df = pd.read_csv("input.csv")

cutoff = 0.0
h = 0.5

# Triangular kernel weights: K(u) = (1 - |u|) for |u| <= 1, else 0
# u = (z - cutoff) / h
df["u"] = (df["z"] - cutoff) / h
df["w"] = np.where(np.abs(df["u"]) <= 1, 1 - np.abs(df["u"]), 0.0)

# Left side: z < cutoff, right side: z >= cutoff
left = df[(df["z"] < cutoff) & (df["w"] > 0)].copy()
right = df[(df["z"] >= cutoff) & (df["w"] > 0)].copy()

n_left = len(left)
n_right = len(right)
n_obs = n_left + n_right

# Local linear regression on each side
# y ~ 1 + (z - cutoff)  with triangular weights

def fit_llr(data, wts):
    X = sm.add_constant((data["z"] - cutoff).values)
    y = data["y"].values
    w = wts.values
    model = sm.WLS(y, X, weights=w).fit()
    return model

m_left = fit_llr(left, left["w"])
m_right = fit_llr(right, right["w"])

# LATE = intercept_right - intercept_left
late = m_right.params[0] - m_left.params[0]

# SE via delta method (intercepts are independent since different samples)
se_late = np.sqrt(m_right.bse[0]**2 + m_left.bse[0]**2)

print(f"Left intercept: {m_left.params[0]:.8f} (SE={m_left.bse[0]:.8f}), n={n_left}")
print(f"Right intercept: {m_right.params[0]:.8f} (SE={m_right.bse[0]:.8f}), n={n_right}")
print(f"LATE: {late:.8f}, SE: {se_late:.8f}, n_obs: {n_obs}")

result = {
    "task_id": "rdd_sharp",
    "platform": "python",
    "estimates": [
        {"term": "late", "estimate": float(late), "se": float(se_late), "n_obs": int(n_obs)}
    ],
    "method_metadata": {
        "estimator": "local_linear_regression_triangular_kernel_h0.5",
        "vcov": "OLS_delta_method"
    },
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)

print("result.json written")
