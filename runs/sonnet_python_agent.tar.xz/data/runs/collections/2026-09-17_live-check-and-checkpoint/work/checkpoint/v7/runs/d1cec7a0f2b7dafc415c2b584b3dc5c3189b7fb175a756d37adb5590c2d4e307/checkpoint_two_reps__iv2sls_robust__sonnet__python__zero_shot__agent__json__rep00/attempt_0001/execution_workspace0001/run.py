import pandas as pd
import numpy as np
import json
from linearmodels.iv import IV2SLS

df = pd.read_csv("input.csv")

endog = df["y_iv"]
exog = pd.DataFrame({"const": np.ones(len(df))}, index=df.index)
endog_reg = df[["x1_iv"]]
instruments = df[["z"]]

mod = IV2SLS(endog, exog, endog_reg, instruments)
res = mod.fit(cov_type="robust")

n_obs = int(res.nobs)
params = res.params
ses = res.std_errors

estimates = [
    {"term": "const", "estimate": float(params["const"]), "se": float(ses["const"]), "n_obs": n_obs},
    {"term": "x1_iv", "estimate": float(params["x1_iv"]), "se": float(ses["x1_iv"]), "n_obs": n_obs},
]

result = {
    "task_id": "iv2sls_robust",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {"estimator": "IV2SLS", "vcov": "HC1 robust"},
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)

print(json.dumps(result, indent=2))
