import json
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.linalg import inv

df = pd.read_csv("./input.csv")
n = len(df)

df = df.sort_values("t_obs").reset_index(drop=True)
t = df["t_obs"].values
event = df["event"].values.astype(float)
X = df[["treat", "x"]].values  # n x 2

def neg_log_pl(beta):
    xb = X @ beta
    ll = 0.0
    for i in range(n):
        if event[i] == 1:
            risk = np.where(t >= t[i])[0]
            ll += xb[i] - np.log(np.sum(np.exp(xb[risk])))
    return -ll

def neg_log_pl_grad(beta):
    xb = X @ beta
    exp_xb = np.exp(xb)
    grad = np.zeros(2)
    for i in range(n):
        if event[i] == 1:
            risk = np.where(t >= t[i])[0]
            w = exp_xb[risk]
            S0 = np.sum(w)
            S1 = X[risk].T @ w
            grad += X[i] - S1 / S0
    return -grad

result = minimize(neg_log_pl, x0=np.zeros(2), jac=neg_log_pl_grad,
                  method="L-BFGS-B",
                  options={"ftol": 1e-14, "gtol": 1e-10, "maxiter": 2000})
beta_hat = result.x

# Observed information matrix via numerical Hessian
eps = 1e-5
H = np.zeros((2, 2))
for j in range(2):
    e = np.zeros(2)
    e[j] = eps
    H[:, j] = (neg_log_pl_grad(beta_hat + e) - neg_log_pl_grad(beta_hat - e)) / (2 * eps)

var_cov = inv(H)
se = np.sqrt(np.diag(var_cov))

out = {
    "task_id": "cox_hazard",
    "platform": "python",
    "estimates": [
        {"term": "treat", "estimate": float(beta_hat[0]), "se": float(se[0]), "n_obs": int(n)},
        {"term": "x",     "estimate": float(beta_hat[1]), "se": float(se[1]), "n_obs": int(n)},
    ],
    "method_metadata": {
        "estimator": "Cox proportional hazards (partial likelihood, Breslow ties)",
        "vcov": "observed information (numerical Hessian of partial log-likelihood)"
    },
    "diagnostics": {"converged": bool(result.success), "neg_loglik": float(result.fun)},
}

with open("result.json", "w") as f:
    json.dump(out, f, indent=2)

print("beta_hat:", beta_hat)
print("se:      ", se)
print("converged:", result.success)
print("n_obs:", n, "n_events:", int(event.sum()))
