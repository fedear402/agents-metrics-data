import pandas as pd
import numpy as np
import json
from statsmodels.miscmodels.ordinal_model import OrderedModel

df = pd.read_csv('input.csv')
n_obs = len(df)

# Fit ordered logit model
model = OrderedModel(df['y'], df[['x', 'z']], distr='logit')
result = model.fit(method='bfgs', disp=False)

print(result.summary())

# Extract coefficients and standard errors
params = result.params
bse = result.bse

x_coef = params['x']
z_coef = params['z']
x_se = bse['x']
z_se = bse['z']

print(f"\nx coef: {x_coef}, se: {x_se}")
print(f"z coef: {z_coef}, se: {z_se}")

# Compute prob_high: P(y=3 | x=1, z=0)
# In ordered logit: P(y=3) = 1 - F(c2 - x*beta_x - z*beta_z)
# where c2 is the second cutpoint (threshold between categories 2 and 3)
# statsmodels OrderedModel uses parameterization with thresholds

# Get threshold parameters
threshold_names = [p for p in params.index if 'y/' in p or '/' in p]
print(f"\nThreshold params: {threshold_names}")
print(params[threshold_names])

# Predict for x=1, z=0
new_obs = pd.DataFrame({'x': [1.0], 'z': [0.0]})
pred_probs = result.predict(new_obs)
print(f"\nPredicted probabilities for x=1, z=0:")
print(pred_probs)

prob_high = float(pred_probs.iloc[0, 2])  # category 3 (index 2)
print(f"prob_high (P(y=3|x=1,z=0)): {prob_high}")

output = {
    "task_id": "broad_ordered_logit",
    "platform": "python",
    "estimates": [
        {"term": "x", "estimate": float(x_coef), "se": float(x_se), "n_obs": n_obs},
        {"term": "z", "estimate": float(z_coef), "se": float(z_se), "n_obs": n_obs},
        {"term": "prob_high", "estimate": float(prob_high), "se": None, "n_obs": n_obs}
    ],
    "method_metadata": {
        "estimator": "ordered_logit_mle",
        "vcov": "observed_information"
    },
    "diagnostics": {}
}

with open('result.json', 'w') as f:
    json.dump(output, f, indent=2)

print("\nresult.json written.")
print(json.dumps(output, indent=2))
