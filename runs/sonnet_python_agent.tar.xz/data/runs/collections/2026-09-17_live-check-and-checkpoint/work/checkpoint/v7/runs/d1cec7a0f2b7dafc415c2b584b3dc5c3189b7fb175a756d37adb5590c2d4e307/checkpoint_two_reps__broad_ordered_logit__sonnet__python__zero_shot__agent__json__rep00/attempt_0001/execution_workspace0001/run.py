import pandas as pd
import numpy as np
from scipy import stats
import json
from statsmodels.miscmodels.ordinal_model import OrderedModel

# Load data
df = pd.read_csv('input.csv')
n_obs = len(df)

# Fit ordered logit model
# OrderedModel with distr=stats.logistic is ordered logit
model = OrderedModel(df['y'], df[['x', 'z']], distr=stats.logistic)
result = model.fit(method='bfgs', disp=False)

print(result.summary())

# Extract coefficients and standard errors
params = result.params
bse = result.bse

coef_x = params['x']
coef_z = params['z']
se_x = bse['x']
se_z = bse['z']

print(f"\nCoefficients:")
print(f"x: {coef_x:.8f} (se={se_x:.8f})")
print(f"z: {coef_z:.8f} (se={se_z:.8f})")

# Compute prob_high: P(y=3) for x=1, z=0
# In ordered logit: P(y=3) = 1 - logistic(cutpoint2 - x*beta_x - z*beta_z)
# statsmodels uses: P(y <= j) = logistic(cutpoint_j - X*beta)
# so P(y=3) = 1 - P(y<=2) = 1 - logistic(cutpoint2 - beta_x*1 - beta_z*0)

# Get cutpoints - in statsmodels OrderedModel, thresholds are stored as
# the last parameters (transformed)
# The actual thresholds are obtained via result.model.transform_threshold_params
thresholds = result.model.transform_threshold_params(result.params)
print(f"\nThresholds (cutpoints): {thresholds}")

# For x=1, z=0: linear predictor = beta_x * 1 + beta_z * 0 = beta_x
xb = coef_x * 1 + coef_z * 0

# P(y=3) = 1 - logistic(cutpoint2 - xb)
from scipy.special import expit
cutpoint2 = thresholds[1]  # second cutpoint (boundary between 2 and 3)
prob_high = 1 - expit(cutpoint2 - xb)
print(f"\nprob_high (P(y=3) for x=1, z=0): {prob_high:.8f}")

# Also verify using predict
new_data = pd.DataFrame({'x': [1.0], 'z': [0.0]})
pred_probs = result.predict(new_data)
print(f"Predicted probabilities from model: {pred_probs}")
prob_high_check = pred_probs.iloc[0, 2]  # P(y=3)
print(f"prob_high from predict: {prob_high_check:.8f}")

# Write results
output = {
    "task_id": "broad_ordered_logit",
    "platform": "python",
    "estimates": [
        {"term": "x", "estimate": float(coef_x), "se": float(se_x), "n_obs": n_obs},
        {"term": "z", "estimate": float(coef_z), "se": float(se_z), "n_obs": n_obs},
        {"term": "prob_high", "estimate": float(prob_high_check), "se": None, "n_obs": n_obs}
    ],
    "method_metadata": {
        "estimator": "ordered_logit_mle",
        "vcov": "observed_information"
    },
    "diagnostics": {}
}

with open('result.json', 'w') as f:
    json.dump(output, f, indent=2)

print("\nResult written to result.json")
