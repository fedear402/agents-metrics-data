import numpy as np
import pandas as pd
from scipy import stats, optimize
from numpy.linalg import inv
import json

df = pd.read_csv("input.csv")
y = df["y"].values
X = np.column_stack([np.ones(len(df)), df["x"].values, df["z"].values])
n = len(df)

censored = y == 0
uncensored = ~censored

def neg_log_likelihood(params):
    beta = params[:3]
    log_sigma = params[3]
    sigma = np.exp(log_sigma)
    mu = X @ beta
    ll_unc = stats.norm.logpdf(y[uncensored], loc=mu[uncensored], scale=sigma)
    ll_cen = stats.norm.logcdf(0, loc=mu[censored], scale=sigma)
    return -(np.sum(ll_unc) + np.sum(ll_cen))

# Initial values from OLS on uncensored
beta0, *_ = np.linalg.lstsq(X[uncensored], y[uncensored], rcond=None)
sigma0 = np.std(y[uncensored] - X[uncensored] @ beta0)
params0 = np.append(beta0, np.log(sigma0))

# Optimize with L-BFGS-B
result = optimize.minimize(
    neg_log_likelihood, params0,
    method="L-BFGS-B",
    options={"maxiter": 50000, "ftol": 1e-15, "gtol": 1e-10}
)

params_hat = result.x

# Numerical Hessian for observed information matrix SEs
eps = 1e-5
def hessian_numerical(f, x, eps=1e-5):
    n = len(x)
    H = np.zeros((n, n))
    f0 = f(x)
    for i in range(n):
        for j in range(i, n):
            ei = np.zeros(n); ej = np.zeros(n)
            ei[i] = eps; ej[j] = eps
            H[i, j] = (f(x+ei+ej) - f(x+ei) - f(x+ej) + f0) / (eps**2)
            H[j, i] = H[i, j]
    return H

H = hessian_numerical(neg_log_likelihood, params_hat)
cov = inv(H)  # observed info matrix = H of neg_ll, so inv(H) is the covariance
se_params = np.sqrt(np.diag(cov))

beta_hat = params_hat[:3]
sigma_hat = np.exp(params_hat[3])
se_beta = se_params[:3]

print("Tobit MLE Results:")
print(f"  const = {beta_hat[0]:.8f} (se={se_beta[0]:.8f})")
print(f"  x     = {beta_hat[1]:.8f} (se={se_beta[1]:.8f})")
print(f"  z     = {beta_hat[2]:.8f} (se={se_beta[2]:.8f})")
print(f"  sigma = {sigma_hat:.8f}")
print(f"Log-likelihood: {-result.fun:.6f}")
print(f"Convergence: {result.success}")
print(f"N obs: {n}, N censored: {censored.sum()}, N uncensored: {uncensored.sum()}")

output = {
    "task_id": "broad_tobit",
    "platform": "python",
    "estimates": [
        {"term": "const", "estimate": float(beta_hat[0]), "se": float(se_beta[0]), "n_obs": n},
        {"term": "x",     "estimate": float(beta_hat[1]), "se": float(se_beta[1]), "n_obs": n},
        {"term": "z",     "estimate": float(beta_hat[2]), "se": float(se_beta[2]), "n_obs": n},
        {"term": "sigma", "estimate": float(sigma_hat),   "se": None,              "n_obs": n},
    ],
    "method_metadata": {
        "estimator": "MLE Tobit (left-censored at 0, homoskedastic Gaussian)",
        "vcov": "observed information matrix (numerical Hessian of log-likelihood)"
    },
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(output, f, indent=2)

print("\nresult.json written.")
