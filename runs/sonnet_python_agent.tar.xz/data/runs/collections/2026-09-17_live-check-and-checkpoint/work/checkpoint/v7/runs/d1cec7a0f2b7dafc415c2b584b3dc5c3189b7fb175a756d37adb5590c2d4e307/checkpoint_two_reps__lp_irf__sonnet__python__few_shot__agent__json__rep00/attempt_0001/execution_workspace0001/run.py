import json
import pandas as pd
import statsmodels.api as sm
import numpy as np

df = pd.read_csv("./input.csv")

# Construct variables for LP at horizon h=4:
# y_{t+4} is the dependent variable
# shock_t is the regressor of interest
# y_{t-1} is the control
# Need t, t+4 aligned: create y_lead4 = y.shift(-4) and y_lag1 = y.shift(1)

df["y_lead4"] = df["y"].shift(-4)   # y_{t+4}
df["y_lag1"] = df["y"].shift(1)      # y_{t-1}

est_df = df[["y_lead4", "shock", "y_lag1"]].dropna()

X = sm.add_constant(est_df[["shock", "y_lag1"]])
y_dep = est_df["y_lead4"]

fit = sm.OLS(y_dep, X).fit(cov_type="HAC", cov_kwds={"maxlags": 4})

irf_h4 = float(fit.params["shock"])
se_h4 = float(fit.bse["shock"])
n_obs = int(fit.nobs)

out = {
    "task_id": "lp_irf",
    "platform": "python",
    "estimates": [
        {"term": "irf_h4", "estimate": irf_h4, "se": se_h4, "n_obs": n_obs}
    ],
    "method_metadata": {
        "estimator": "Local Projection OLS, horizon h=4, y_{t+4} on shock_t and y_{t-1}",
        "vcov": "Newey-West HAC, maxlags=4"
    },
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(out, f, indent=2)

print(f"irf_h4 estimate: {irf_h4:.8f}")
print(f"irf_h4 SE:       {se_h4:.8f}")
print(f"n_obs:           {n_obs}")
