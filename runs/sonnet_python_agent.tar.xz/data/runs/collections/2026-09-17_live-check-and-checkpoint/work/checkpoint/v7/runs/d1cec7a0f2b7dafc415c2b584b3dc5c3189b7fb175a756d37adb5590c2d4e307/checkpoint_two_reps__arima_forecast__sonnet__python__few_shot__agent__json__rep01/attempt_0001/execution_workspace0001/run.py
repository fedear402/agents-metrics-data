import json
import pandas as pd
from statsmodels.tsa.arima.model import ARIMA

df = pd.read_csv("./input.csv")
y = df["y"].values
n = len(y)

# Fit ARIMA(1,1,1) with no constant/drift (trend='n')
model = ARIMA(y, order=(1, 1, 1), trend='n')
fit = model.fit()

print(fit.summary())

# One-step-ahead forecast for t=251 (one step beyond the last observation)
fc_result = fit.get_forecast(steps=1)
fc_mean = float(fc_result.predicted_mean[0])
fc_conf = fc_result.conf_int(alpha=0.05)
lower_95 = float(fc_conf[0, 0])
upper_95 = float(fc_conf[0, 1])
fc_se = float(fc_result.se_mean[0])

print(f"Forecast: {fc_mean}")
print(f"Lower 95%: {lower_95}")
print(f"Upper 95%: {upper_95}")
print(f"SE: {fc_se}")
print(f"n_obs: {n}")

out = {
    "task_id": "arima_forecast",
    "platform": "python",
    "estimates": [
        {"term": "forecast", "estimate": fc_mean, "se": fc_se, "n_obs": n},
        {"term": "lower_95", "estimate": lower_95, "se": None, "n_obs": n},
        {"term": "upper_95", "estimate": upper_95, "se": None, "n_obs": n},
    ],
    "method_metadata": {
        "estimator": "ARIMA(1,1,1) by Maximum Likelihood (no constant)",
        "vcov": "MLE"
    },
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(out, f, indent=2)

print("Done. result.json written.")
