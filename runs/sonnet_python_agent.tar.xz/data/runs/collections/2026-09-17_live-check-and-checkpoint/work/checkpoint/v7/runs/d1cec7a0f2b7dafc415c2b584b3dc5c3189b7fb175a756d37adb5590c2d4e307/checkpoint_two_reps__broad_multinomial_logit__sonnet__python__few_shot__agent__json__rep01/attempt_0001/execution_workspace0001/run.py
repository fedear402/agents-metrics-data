import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy.special import softmax

df = pd.read_csv('input.csv')
n = len(df)

X = pd.DataFrame({'const': np.ones(n), 'x': df['x'].values, 'z': df['z'].values})
y = df['y'].values

fit = sm.MNLogit(y, X).fit(disp=False, tol=1e-10)

outcomes = sorted(np.unique(y).tolist())
assert outcomes == [0, 1, 2]
nonbase = [1, 2]

# With pandas input, raw param columns 0 and 1 correspond to outcomes 1 and 2
assert list(fit.params.columns) == [0, 1]
coefs = fit.params.copy()
ses = fit.bse.copy()
coefs.columns = nonbase
ses.columns = nonbase

# Fitted probability at x=0, z=0
pred_input = pd.DataFrame({'const': [1.], 'x': [0.], 'z': [0.]})
predicted = pd.Series(np.asarray(fit.predict(pred_input))[0], index=outcomes)

# Independent check via softmax
manual = softmax(np.r_[0., coefs.loc['const', nonbase]])
assert np.allclose(predicted.to_numpy(), manual), "Prediction mismatch"
assert np.isclose(predicted.sum(), 1.0), "Probabilities don't sum to 1"

estimates = [
    {'term': 'x_cat1',        'estimate': float(coefs.loc['x', 1]),   'se': float(ses.loc['x', 1]),   'n_obs': n},
    {'term': 'z_cat1',        'estimate': float(coefs.loc['z', 1]),   'se': float(ses.loc['z', 1]),   'n_obs': n},
    {'term': 'x_cat2',        'estimate': float(coefs.loc['x', 2]),   'se': float(ses.loc['x', 2]),   'n_obs': n},
    {'term': 'z_cat2',        'estimate': float(coefs.loc['z', 2]),   'se': float(ses.loc['z', 2]),   'n_obs': n},
    {'term': 'prob_cat2_zero','estimate': float(predicted.loc[2]),    'se': None,                      'n_obs': n},
]

output = {
    'task_id': 'broad_multinomial_logit',
    'platform': 'python',
    'estimates': estimates,
    'method_metadata': {'estimator': 'MNLogit_MLE', 'vcov': 'observed_information'},
    'diagnostics': {}
}

with open('result.json', 'w') as f:
    json.dump(output, f, indent=2, allow_nan=False)

print("Done. Estimates:")
for e in estimates:
    print(f"  {e['term']}: {e['estimate']:.8f}  (se={e['se']})")
