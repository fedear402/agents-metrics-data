import pandas as pd
import numpy as np
from scipy.optimize import minimize
from scipy.stats import norm
import json

df = pd.read_csv('input.csv')
n = len(df)
y = df['y'].values
X = np.column_stack([np.ones(n), df['x'].values, df['z'].values])

censored = (y == 0)
uncensored = ~censored

def tobit_nll(params):
    beta = params[:3]
    log_sigma = params[3]
    sigma = np.exp(log_sigma)
    
    xb = X @ beta
    
    # uncensored: log pdf
    ll_unc = np.sum(norm.logpdf(y[uncensored], loc=xb[uncensored], scale=sigma))
    # censored: log Phi(0; xb, sigma) = log Phi(-(xb)/sigma)
    ll_cen = np.sum(norm.logcdf(-xb[censored] / sigma))
    
    return -(ll_unc + ll_cen)

def tobit_grad(params):
    beta = params[:3]
    log_sigma = params[3]
    sigma = np.exp(log_sigma)
    
    xb = X @ beta
    grad = np.zeros(4)
    
    # uncensored contributions
    res_unc = y[uncensored] - xb[uncensored]
    # d/d_beta: sum res/sigma^2 * X
    grad[:3] += X[uncensored].T @ (res_unc / sigma**2)
    # d/d_log_sigma: sigma * d/d_sigma
    # d/d_sigma: -n_unc/sigma + sum res^2/sigma^3
    grad[3] += (-uncensored.sum() + np.sum(res_unc**2) / sigma**2)
    
    # censored contributions
    z_cen = -xb[censored] / sigma
    mills = norm.pdf(z_cen) / norm.cdf(z_cen)  # inverse mills ratio (positive)
    # d/d_beta: sum mills * (-1/sigma) * X
    grad[:3] += X[censored].T @ (mills * (-1/sigma))
    # d/d_log_sigma: sigma * d/d_sigma
    # d/d_sigma: sum mills * (xb/sigma^2)
    grad[3] += np.sum(mills * xb[censored] / sigma)
    
    return -grad

# Initial values using OLS on uncensored
from numpy.linalg import lstsq
beta0, _, _, _ = lstsq(X[uncensored], y[uncensored], rcond=None)
sigma0 = np.std(y[uncensored] - X[uncensored] @ beta0)
params0 = np.append(beta0, np.log(sigma0))
print("Initial params:", params0)

# Use L-BFGS-B with gradient
result = minimize(tobit_nll, params0, jac=tobit_grad, method='L-BFGS-B',
                  options={'maxiter': 50000, 'ftol': 1e-15, 'gtol': 1e-10})
print("Success:", result.success, "| Message:", result.message)
print("Gradient at optimum:", result.jac)

# Try also without gradient if convergence is marginal
if not result.success:
    result2 = minimize(tobit_nll, result.x, method='Nelder-Mead',
                       options={'maxiter': 100000, 'xatol': 1e-10, 'fatol': 1e-10})
    print("NM success:", result2.success, "NLL NM:", result2.fun, "NLL L-BFGS-B:", result.fun)
    if result2.fun < result.fun:
        result = result2
        print("Using Nelder-Mead result")
    # retry L-BFGS-B from NM result
    result3 = minimize(tobit_nll, result.x, jac=tobit_grad, method='L-BFGS-B',
                       options={'maxiter': 50000, 'ftol': 1e-15, 'gtol': 1e-10})
    print("Retry L-BFGS-B success:", result3.success, "NLL:", result3.fun)
    if result3.fun < result.fun:
        result = result3

params_hat = result.x
beta_hat = params_hat[:3]
sigma_hat = np.exp(params_hat[3])

print(f"\nconst: {beta_hat[0]:.10f}")
print(f"x:     {beta_hat[1]:.10f}")
print(f"z:     {beta_hat[2]:.10f}")
print(f"sigma: {sigma_hat:.10f}")
print(f"NLL:   {result.fun:.10f}")

# Numerical Hessian for observed information
def numerical_hessian(f, x0, eps=1e-5):
    n = len(x0)
    H = np.zeros((n, n))
    for i in range(n):
        for j in range(i, n):
            ei = np.zeros(n); ei[i] = eps
            ej = np.zeros(n); ej[j] = eps
            H[i,j] = (f(x0+ei+ej) - f(x0+ei-ej) - f(x0-ei+ej) + f(x0-ei-ej)) / (4*eps**2)
            H[j,i] = H[i,j]
    return H

H = numerical_hessian(tobit_nll, params_hat, eps=1e-4)
print("\nHessian:\n", H)

Hinv = np.linalg.inv(H)
se_params = np.sqrt(np.diag(Hinv))

# SE for beta (in original param space)
se_beta = se_params[:3]
# se for sigma via delta method: se_sigma = sigma * se_log_sigma (but task says null for sigma)

print(f"\nconst: {beta_hat[0]:.8f} (se={se_beta[0]:.8f})")
print(f"x:     {beta_hat[1]:.8f} (se={se_beta[1]:.8f})")
print(f"z:     {beta_hat[2]:.8f} (se={se_beta[2]:.8f})")
print(f"sigma: {sigma_hat:.8f}")

estimates = [
    {"term": "const", "estimate": float(beta_hat[0]), "se": float(se_beta[0]), "n_obs": n},
    {"term": "x",     "estimate": float(beta_hat[1]), "se": float(se_beta[1]), "n_obs": n},
    {"term": "z",     "estimate": float(beta_hat[2]), "se": float(se_beta[2]), "n_obs": n},
    {"term": "sigma", "estimate": float(sigma_hat),   "se": None,              "n_obs": n},
]

output = {
    "task_id": "broad_tobit",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "MLE Tobit (homoskedastic Gaussian, lower censoring at 0)",
        "vcov": "observed information matrix (numerical Hessian of NLL)"
    },
    "diagnostics": {}
}

with open('result.json', 'w') as f:
    json.dump(output, f, indent=2)

print("\nresult.json written.")
