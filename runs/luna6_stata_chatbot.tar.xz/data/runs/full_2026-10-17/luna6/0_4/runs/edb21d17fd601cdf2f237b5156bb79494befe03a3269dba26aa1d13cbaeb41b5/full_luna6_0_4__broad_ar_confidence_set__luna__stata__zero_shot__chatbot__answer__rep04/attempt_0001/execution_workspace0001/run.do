clear all
set more off
set linesize 255

import delimited using "./input.csv", clear
local n = _N
local df_r = `n' - 4

* Joint F statistic is a quadratic-over-quadratic function of beta.
* Evaluate it at three points to recover its coefficients.
tempvar w
quietly generate double `w' = y
quietly regress `w' x z1 z2
scalar f0 = e(F)

quietly replace `w' = y - endog
quietly regress `w' x z1 z2
scalar f1 = e(F)

quietly replace `w' = y + endog
quietly regress `w' x z1 z2
scalar fm1 = e(F)

* The explained sum of squares for the excluded instruments is proportional
* to the Wald F numerator. Recover the quadratic numerator directly.
quietly regress y x
scalar rss_y_restricted = e(rss)
quietly regress y x z1 z2
scalar rss_y_full = e(rss)
scalar q0 = rss_y_restricted - rss_y_full

quietly replace `w' = y - endog
quietly regress `w' x
scalar rss_1_restricted = e(rss)
quietly regress `w' x z1 z2
scalar rss_1_full = e(rss)
scalar q1 = rss_1_restricted - rss_1_full

quietly replace `w' = y + endog
quietly regress `w' x
scalar rss_m1_restricted = e(rss)
quietly regress `w' x z1 z2
scalar rss_m1_full = e(rss)
scalar qm1 = rss_m1_restricted - rss_m1_full

* Obtain full-model residual sums of squares at beta = 0, 1, and -1.
quietly regress y x z1 z2
scalar s0 = e(rss)
quietly replace `w' = y - endog
quietly regress `w' x z1 z2
scalar s1 = e(rss)
quietly replace `w' = y + endog
quietly regress `w' x z1 z2
scalar sm1 = e(rss)

* F(beta) = df_r * q(beta) / (2 * s(beta)).
* q(beta) and s(beta) are quadratic polynomials.
scalar qa = (q1 + qm1 - 2*q0)/2
scalar qb = (q0 - q1 + qa)
scalar qc = q0
scalar sa = (s1 + sm1 - 2*s0)/2
scalar sb = (s0 - s1 + sa)
scalar sc = s0

scalar ar_f_at_one = `df_r' * q1 / (2*s1)
scalar fcrit = invFtail(2, `df_r', .05)

* Solve df_r*q(beta) - 2*fcrit*s(beta) <= 0 over the real line.
scalar A = `df_r'*qa - 2*fcrit*sa
scalar B = `df_r'*qb - 2*fcrit*sb
scalar C = `df_r'*qc - 2*fcrit*sc
scalar disc = B^2 - 4*A*C

scalar boundary_low = .
scalar boundary_high = .
if (disc >= 0 & A != 0) {
    scalar boundary_low = (-B - sqrt(disc))/(2*A)
    scalar boundary_high = (-B + sqrt(disc))/(2*A)
    if (boundary_low > boundary_high) {
        scalar temp = boundary_low
        scalar boundary_low = boundary_high
        scalar boundary_high = temp
    }
}

scalar accepts_zero = (C <= 0)
scalar unbounded = (A < 0)

display "ANSWER: boundary_low estimate=" %21.12f boundary_low " se=." " n_obs=" %12.0f `n'
display "ANSWER: boundary_high estimate=" %21.12f boundary_high " se=." " n_obs=" %12.0f `n'
display "ANSWER: accepts_zero estimate=" %21.12f accepts_zero " se=." " n_obs=" %12.0f `n'
display "ANSWER: unbounded estimate=" %21.12f unbounded " se=." " n_obs=" %12.0f `n'
display "ANSWER: ar_f_at_one estimate=" %21.12f ar_f_at_one " se=." " n_obs=" %12.0f `n'
