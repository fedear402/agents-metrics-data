import delimited using "households.csv", clear
keep if recipient == 0

count
local n_obs = r(N)

generate double ineligible = 1 - eligible
generate double x_ineligible = dose * ineligible
generate double x_eligible = dose * eligible

generate double z_ineligible = instrument * ineligible
generate double z_eligible = instrument * eligible

ivregress 2sls outcome ///
    ineligible eligible ///
    c.baseline#c.ineligible c.baseline#c.eligible ///
    (x_ineligible x_eligible = z_ineligible z_eligible), ///
    noconstant [aweight=weight]

scalar mean_dose_ineligible = .
scalar mean_dose_eligible = .

quietly summarize dose [aweight=weight] if eligible == 0
scalar mean_dose_ineligible = r(mean)

quietly summarize dose [aweight=weight] if eligible == 1
scalar mean_dose_eligible = r(mean)

scalar ineligible_effect = _b[x_ineligible] * mean_dose_ineligible
scalar eligible_nonrecipient_effect = _b[x_eligible] * mean_dose_eligible

preserve
import delimited using "census.csv", clear
quietly summarize nonrecipient_population if eligible == 0, meanonly
scalar pop_ineligible = r(mean)
quietly summarize nonrecipient_population if eligible == 1, meanonly
scalar pop_eligible = r(mean)
restore

scalar population_effect = ///
    (pop_ineligible * ineligible_effect + pop_eligible * eligible_nonrecipient_effect) / ///
    (pop_ineligible + pop_eligible)

display "ANSWER: ineligible_effect estimate=" %21.15g ineligible_effect ///
    " se=NA n_obs=" %12.0f `n_obs'
display "ANSWER: eligible_nonrecipient_effect estimate=" %21.15g eligible_nonrecipient_effect ///
    " se=NA n_obs=" %12.0f `n_obs'
display "ANSWER: population_effect estimate=" %21.15g population_effect ///
    " se=NA n_obs=" %12.0f `n_obs'
