clear all
set more off
set type double

import delimited using "crosswalk.csv", clear
tempfile crosswalk
save `crosswalk'

import delimited using "trade.csv", clear
tempfile trade
save `trade'

import delimited using "areas.csv", clear
tempfile areas
save `areas'

import delimited using "employment.csv", clear
tempfile employment
save `employment'

import delimited using "outcomes.csv", clear
tempfile outcomes
save `outcomes'

* Attach each trade code to its industry, then sum trade changes by industry.
use `trade', clear
joinby code using `crosswalk'
collapse (sum) us_change other_change (first) price_index years, by(period industry)
tempfile industry_trade
save `industry_trade'

* Build a complete area-period-vintage-industry panel.
use `areas', clear
keep area period vintage total_employment population
reshape wide total_employment population, i(area period) j(vintage) string
tempfile area_period
save `area_period'

use `areas', clear
keep area period vintage
duplicates drop
tempfile area_period_vintage
save `area_period_vintage'

use `crosswalk', clear
keep industry
duplicates drop
tempfile industries
save `industries'

use `area_period_vintage', clear
cross using `industries'
merge 1:1 area period vintage industry using `employment', nogen
replace employment = 0 if missing(employment)

* National industry totals by period and vintage.
bysort period vintage industry: egen double national_employment = total(employment)
merge m:1 period industry using `industry_trade', nogen

* Form area-level exposure components.
gen double x_component = employment * us_change / national_employment
gen double z_component = employment * other_change / national_employment
collapse (sum) x_raw=x_component z_raw=z_component, by(area period vintage)
reshape wide x_raw z_raw, i(area period) j(vintage) string
merge 1:1 area period using `area_period', nogen

* Apply period-specific deflator and interval length to each vintage exposure.
merge m:1 period using `trade', keepusing(price_index years) nogen
gen double x = (x_rawbase / total_employmentbase) / (price_index/100) / 1000 * (10/years)
gen double z = (z_rawearly / total_employmentearly) / (price_index/100) / 1000 * (10/years)

merge 1:1 area period using `outcomes', nogen
count
local n_obs = r(N)

ivregress 2sls change_pp i.period control (x = z) [aw=populationbase]
display "ANSWER: iv_slope estimate=" %24.16g _b[x] " se=NA n_obs=72"

quietly summarize x if area==0 & period==0, meanonly
display "ANSWER: exposure_area0_period0 estimate=" %24.16g r(mean) " se=NA n_obs=72"

quietly summarize x if area==0 & period==1, meanonly
display "ANSWER: exposure_area0_period1 estimate=" %24.16g r(mean) " se=NA n_obs=72"

quietly summarize z if area==0 & period==0, meanonly
display "ANSWER: instrument_area0_period0 estimate=" %24.16g r(mean) " se=NA n_obs=72"
