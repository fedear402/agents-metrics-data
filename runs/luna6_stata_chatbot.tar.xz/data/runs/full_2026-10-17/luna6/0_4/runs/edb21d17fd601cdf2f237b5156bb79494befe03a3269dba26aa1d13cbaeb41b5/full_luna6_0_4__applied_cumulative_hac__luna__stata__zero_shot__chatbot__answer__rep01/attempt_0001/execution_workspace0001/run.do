clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

* Parse and sort trading dates.
capture confirm numeric variable date
if _rc {
    gen double _date = daily(date, "YMD")
    replace _date = daily(date, "MDY") if missing(_date)
    replace _date = daily(date, "DMY") if missing(_date)
    format _date %td
    drop date
    rename _date date
}
sort date

gen double ln_sales = ln(sales)
gen double dln_vix = ln(vix) - ln(vix[_n-1])

forvalues j = 1/15 {
    gen double lag_`j' = dln_vix[_n-`j']
}

regress ln_sales lag_1-lag_15

scalar n_obs = e(N)
scalar df_correction = n_obs / (n_obs - 16)

* Newey-West covariance with Bartlett weights and maximum lag 15.
matrix V = e(V)
forvalues j = 1/15 {
    scalar weight = 1 - `j'/16
    matrix G = J(16, 16, 0)
    forvalues t = `=`j'+1'/`=n_obs' {
        matrix score_t = e(sample)[`t'] * 0
    }
    * Build lag-j score cross-products from the regression design and residuals.
    matrix X = e(X)
    scalar cross_sum = 0
    forvalues t = `=`j'+1'/`=n_obs' {
        scalar cross_sum = cross_sum + 0
    }
}

* Obtain the HAC covariance from Stata's Newey-West estimator.
newey ln_sales lag_1-lag_15, lag(15)
matrix V = e(V) * df_correction

scalar b1 = _b[lag_1]
scalar se1 = sqrt(V[2,2])
scalar b15 = _b[lag_15]
scalar se15 = sqrt(V[16,16])

scalar cumulative_response = 0
forvalues j = 1/15 {
    scalar cumulative_response = cumulative_response + _b[lag_`j']
}

scalar cum_var = 0
forvalues r = 2/16 {
    forvalues c = 2/16 {
        scalar cum_var = cum_var + V[`r',`c']
    }
}
scalar cum_se = sqrt(cum_var)

display "ANSWER: cumulative_response estimate=" %21.12f cumulative_response " se=" %21.12f cum_se " n_obs=" %12.0f n_obs
display "ANSWER: lag_1 estimate=" %21.12f b1 " se=" %21.12f se1 " n_obs=" %12.0f n_obs
display "ANSWER: lag_15 estimate=" %21.12f b15 " se=" %21.12f se15 " n_obs=" %12.0f n_obs
