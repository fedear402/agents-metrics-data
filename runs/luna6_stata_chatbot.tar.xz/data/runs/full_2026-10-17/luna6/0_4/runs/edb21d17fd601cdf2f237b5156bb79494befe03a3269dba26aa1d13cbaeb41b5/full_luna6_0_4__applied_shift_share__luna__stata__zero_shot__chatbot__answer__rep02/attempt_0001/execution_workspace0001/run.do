clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

* Retain one observation per region to normalize regional weights.
preserve
    bysort region_id: keep if _n == 1
    egen double total_region_weight = total(region_weight)
    gen double e_region = region_weight / total_region_weight
    keep region_id e_region
    tempfile region_weights
    save `region_weights'
restore

merge m:1 region_id using `region_weights', assert(match) nogen

* Compute regional shift-share exposure and retain one row per region.
gen double share_shock = share * shock
collapse (sum) z=share_shock, by(region_id)
tempfile regional_z
save `regional_z'

import delimited using "./input.csv", clear
merge m:1 region_id using `region_weights', assert(match) nogen
merge m:1 region_id using `regional_z', assert(match) nogen

* Retain one row per region, then demean with normalized regional weights.
bysort region_id: keep if _n == 1
quietly summarize y [aw=e_region]
scalar mean_y = r(mean)
quietly summarize x [aw=e_region]
scalar mean_x = r(mean)
quietly summarize z [aw=e_region]
scalar mean_z = r(mean)

gen double y0 = y - mean_y
gen double x0 = x - mean_x
gen double z0 = z - mean_z

* Aggregate regional residuals to industry exposure units.
preserve
    import delimited using "./input.csv", clear
    merge m:1 region_id using `region_weights', assert(match) nogen
    merge m:1 region_id using `regional_z', assert(match) nogen
    bysort region_id: keep if _n == 1

    quietly summarize y [aw=e_region]
    scalar mean_y = r(mean)
    quietly summarize x [aw=e_region]
    scalar mean_x = r(mean)
    quietly summarize z [aw=e_region]
    scalar mean_z = r(mean)

    gen double y0 = y - mean_y
    gen double x0 = x - mean_x
    gen double z0 = z - mean_z
    tempfile region_residuals
    keep region_id y0 x0 z0
    save `region_residuals'
restore

import delimited using "./input.csv", clear
merge m:1 region_id using `region_weights', assert(match) nogen
merge m:1 region_id using `region_residuals', assert(match) nogen

gen double exposure = e_region * share
collapse (sum) s=exposure (sum) sy=exposure*y0 (sum) sx=exposure*x0 (sum) sz=exposure*z0 (first) shock, by(industry_id)
drop if s <= 0
gen double ybar = sy / s
gen double xbar = sx / s
gen double zbar = sz / s
count
scalar N_industries = r(N)

* Shock-level IV for the regional 2SLS effect.
ivregress 2sls ybar (xbar = shock) [aw=s], vce(robust)
scalar effect_estimate = _b[xbar]
scalar effect_se = _se[xbar]

* Shock-level IV for the regional first-stage slope.
ivregress 2sls xbar (zbar = shock) [aw=s], vce(robust)
scalar first_stage_estimate = _b[zbar]
scalar first_stage_se = _se[zbar]

gen double s_squared = s^2
quietly summarize s_squared
scalar effective_shocks_estimate = 1 / r(sum)

display "ANSWER: effect estimate=" %21.12f effect_estimate " se=" %21.12f effect_se " n_obs=" %12.0f N_industries
display "ANSWER: first_stage estimate=" %21.12f first_stage_estimate " se=" %21.12f first_stage_se " n_obs=" %12.0f N_industries
display "ANSWER: effective_shocks estimate=" %21.12f effective_shocks_estimate " se=. n_obs=" %12.0f N_industries
