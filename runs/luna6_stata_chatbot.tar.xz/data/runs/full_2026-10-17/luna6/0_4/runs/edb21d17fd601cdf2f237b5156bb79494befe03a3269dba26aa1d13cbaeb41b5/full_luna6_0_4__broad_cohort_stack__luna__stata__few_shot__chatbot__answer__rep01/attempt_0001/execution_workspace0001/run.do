clear all
set more off
set type double

import delimited using "input.csv", clear

tempfile source
save `source'

tempname b3 b5 b7 w3 w5 w7 n3 n5 n7
local cohorts 3 5 7

foreach c of local cohorts {
    use `source', clear

    keep if inrange(time, `=`c'-2', `=`c'+2')
    keep if g==`c' | g==0 | g>`=`c'+2'

    bysort id: egen byte nwindow = count(time)
    keep if nwindow==5
    drop nwindow

    gen byte did = (g==`c' & time>=`c')
    quietly regress y did i.id i.time

    if `c'==3 {
        scalar `b3' = _b[did]
        scalar `n3' = e(N)
        quietly count if g==3
        scalar `w3' = r(N)/5
    }
    else if `c'==5 {
        scalar `b5' = _b[did]
        scalar `n5' = e(N)
        quietly count if g==5
        scalar `w5' = r(N)/5
    }
    else {
        scalar `b7' = _b[did]
        scalar `n7' = e(N)
        quietly count if g==7
        scalar `w7' = r(N)/5
    }
}

scalar weighted = (`w3'*`b3' + `w5'*`b5' + `w7'*`b7') / (`w3'+`w5'+`w7')
scalar totalrows = `n3' + `n5' + `n7'

display "ANSWER: att_g3 estimate=" %24.16g `b3'
display "ANSWER: att_g5 estimate=" %24.16g `b5'
display "ANSWER: att_g7 estimate=" %24.16g `b7'
display "ANSWER: att_weighted estimate=" %24.16g weighted
