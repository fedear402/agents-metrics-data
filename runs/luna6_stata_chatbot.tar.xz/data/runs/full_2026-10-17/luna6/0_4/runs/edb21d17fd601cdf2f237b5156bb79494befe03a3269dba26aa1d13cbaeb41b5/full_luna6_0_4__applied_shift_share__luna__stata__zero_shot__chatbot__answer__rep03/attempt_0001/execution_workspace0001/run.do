clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

* Keep one observation per region for regional outcomes and weights.
bysort region_id: keep if _n == 1
quietly summarize region_weight, meanonly
scalar total_weight = r(sum)
generate double e = region_weight / total_weight

* Save regional data, then construct industry exposure aggregates.
tempfile regions industries
keep region_id e x y
save `regions'

import delimited using "./input.csv", clear
collapse (sum) s=share, by(region_id industry_id shock)
merge m:1 region_id using `regions', keep(match) nogen

* Regional shift-share instrument and weighted regional means.
generate double exposure_shock = share * shock
collapse (sum) z=exposure_shock, by(region_id e x y)
quietly summarize y [aw=e], meanonly
scalar mean_y = r(mean)
quietly summarize x [aw=e], meanonly
scalar mean_x = r(mean)
quietly summarize z [aw=e], meanonly
scalar mean_z = r(mean)

generate double y0 = y - mean_y
generate double x0 = x - mean_x
generate double z0 = z - mean_z
save `regions', replace

* Aggregate centered residuals to industries using e-weighted shares.
import delimited using "./input.csv", clear
merge m:1 region_id using `regions', keep(match) nogen
generate double eshare = e * share
collapse (sum) s=eshare ///
    (sum) sy=eshare*y0 (sum) sx=eshare*x0 (sum) sz=eshare*z0 ///
    (firstnm) shock, by(industry_id)
generate double ybar = sy / s
generate double xbar = sx / s
generate double zbar = sz / s
count
scalar N_industries = r(N)

* Shock-level IV for the regional 2SLS slope.
ivregress 2sls ybar (xbar = shock) [aw=s], vce(robust)
scalar effect_est = _b[xbar]
scalar effect_se = _se[xbar]

* Shock-level IV for the regional first-stage slope.
ivregress 2sls xbar (zbar = shock) [aw=s], vce(robust)
scalar first_stage_est = _b[zbar]
scalar first_stage_se = _se[zbar]

* Effective number of industry shocks.
generate double s2 = s^2
quietly summarize s2, meanonly
scalar effective_shocks = 1 / r(sum)

display "ANSWER: effect estimate=" %21.12f effect_est " se=" %21.12f effect_se " n_obs=" %12.0f N_industries
display "ANSWER: first_stage estimate=" %21.12f first_stage_est " se=" %21.12f first_stage_se " n_obs=" %12.0f N_industries
display "ANSWER: effective_shocks estimate=" %21.12f effective_shocks " se=" %21.12f . " n_obs=" %12.0f N_industries
