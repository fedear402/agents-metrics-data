clear all
set more off

import delimited using "households.csv", clear varnames(1)

keep if recipient == 0

generate double ineligible = 1 - eligible
generate double dose_ineligible = dose * ineligible
generate double dose_eligible = dose * eligible
generate double baseline_ineligible = baseline * ineligible
generate double baseline_eligible = baseline * eligible
generate double instrument_ineligible = instrument * ineligible
generate double instrument_eligible = instrument * eligible

quietly count
local n_obs = r(N)

quietly ivregress 2sls outcome ///
    ineligible eligible baseline_ineligible baseline_eligible ///
    (dose_ineligible dose_eligible = ///
     instrument_ineligible instrument_eligible), ///
    noconstant [aweight=weight]

quietly summarize dose if eligible == 0 [aweight=weight], meanonly
local mean_dose_ineligible = r(mean)
quietly summarize dose if eligible == 1 [aweight=weight], meanonly
local mean_dose_eligible = r(mean)

local ineligible_effect = _b[dose_ineligible] * `mean_dose_ineligible'
local eligible_nonrecipient_effect = _b[dose_eligible] * `mean_dose_eligible'

import delimited using "census.csv", clear varnames(1)
quietly summarize nonrecipient_population if eligible == 0, meanonly
local population_ineligible = r(sum)
quietly summarize nonrecipient_population if eligible == 1, meanonly
local population_eligible = r(sum)

local population_effect = ///
    (`ineligible_effect' * `population_ineligible' + ///
     `eligible_nonrecipient_effect' * `population_eligible') / ///
    (`population_ineligible' + `population_eligible')

display "ANSWER: ineligible_effect estimate=" %21.15g `ineligible_effect' ///
    " se=NA n_obs=" %12.0f `n_obs'
display "ANSWER: eligible_nonrecipient_effect estimate=" %21.15g `eligible_nonrecipient_effect' ///
    " se=NA n_obs=" %12.0f `n_obs'
display "ANSWER: population_effect estimate=" %21.15g `population_effect' ///
    " se=NA n_obs=" %12.0f `n_obs'
