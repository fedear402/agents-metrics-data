version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

* Keep one row per region to normalize regional weights once.
preserve
    keep region_id region_weight
    bysort region_id: keep if _n == 1
    egen double total_region_weight = total(region_weight)
    generate double e = region_weight / total_region_weight
    keep region_id e
    tempfile region_weights
    save `region_weights'
restore

merge m:1 region_id using `region_weights', nogen

* Build the regional shift-share instrument and retain one row per region.
generate double share_shock = share * shock
collapse (sum) z=share_shock (first) x y e, by(region_id)

* Weighted regional means and centered variables.
quietly summarize y [aw=e]
scalar mean_y = r(mean)
quietly summarize x [aw=e]
scalar mean_x = r(mean)
quietly summarize z [aw=e]
scalar mean_z = r(mean)

generate double y0 = y - mean_y
generate double x0 = x - mean_x
generate double z0 = z - mean_z

* Aggregate centered variables by industry exposure.
tempfile regional_data
save `regional_data'

use "./input.csv", clear
merge m:1 region_id using `region_weights', nogen
merge m:1 region_id using `regional_data', keepusing(y0 x0 z0) nogen

generate double weighted_share = e * share
generate double weighted_y = weighted_share * y0
generate double weighted_x = weighted_share * x0
generate double weighted_z = weighted_share * z0

collapse (sum) s=weighted_share y_num=weighted_y x_num=weighted_x z_num=weighted_z (first) shock, by(industry_id)
generate double ybar = y_num / s
generate double xbar = x_num / s
generate double zbar = z_num / s

quietly count
scalar N = r(N)
generate double industry_id_num = _n

* Effect: shock-level IV of ybar on xbar, instrumented by shock.
ivregress 2sls ybar (xbar = shock) [aw=s]
scalar effect_est = _b[xbar]
predict double effect_resid, residuals
generate double effect_score = s * shock * effect_resid
quietly summarize effect_score, meanonly
scalar effect_meat = r(sum_of_sq)
scalar effect_se = sqrt((N/(N-2)) * effect_meat / (e(N)*0 + (sum(s*shock*xbar) - sum(s*shock)*sum(s*xbar)/sum(s))^2))

* First stage: shock-level IV of xbar on zbar, instrumented by shock.
ivregress 2sls xbar (zbar = shock) [aw=s]
scalar first_stage_est = _b[zbar]
predict double first_resid, residuals
generate double first_score = s * shock * first_resid
quietly summarize first_score, meanonly
scalar first_meat = r(sum_of_sq)
scalar first_se = sqrt((N/(N-2)) * first_meat / (e(N)*0 + (sum(s*shock*zbar) - sum(s*shock)*sum(s*zbar)/sum(s))^2))

generate double s_squared = s^2
quietly summarize s_squared, meanonly
scalar effective_shocks = 1 / r(sum)

display "ANSWER: effect estimate=" %21.12f effect_est " se=" %21.12f effect_se " n_obs=" %12.0f N
display "ANSWER: first_stage estimate=" %21.12f first_stage_est " se=" %21.12f first_se " n_obs=" %12.0f N
display "ANSWER: effective_shocks estimate=" %21.12f effective_shocks " se=. n_obs=" %12.0f N
