clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

quietly oneway y group
local F = r(F)
local df_num = r(df_m)
local df_den = r(df_r)
local p_value = Ftail(`df_num', `df_den', `F')
local n = r(N)

display "ANSWER: F estimate=" %21.12f `F' " se=. n_obs=" %12.0f `n'
display "ANSWER: df_num estimate=" %21.12f `df_num' " se=. n_obs=" %12.0f `n'
display "ANSWER: df_den estimate=" %21.12f `df_den' " se=. n_obs=" %12.0f `n'
display "ANSWER: p_value estimate=" %21.12f `p_value' " se=. n_obs=" %12.0f `n'
