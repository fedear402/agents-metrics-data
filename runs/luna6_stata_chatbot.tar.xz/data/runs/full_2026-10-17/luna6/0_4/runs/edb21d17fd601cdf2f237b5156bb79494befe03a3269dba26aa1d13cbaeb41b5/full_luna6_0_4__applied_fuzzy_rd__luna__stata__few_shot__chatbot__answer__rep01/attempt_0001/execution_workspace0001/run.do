version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

keep if abs(score) < 1
generate double weight = 1 - abs(score)
generate double right = score >= 0
generate double right_score = right * score
generate double left_score = (1 - right) * score

regress earnings right right_score left_score [aweight=weight], vce(hc0)
scalar reduced_form = _b[right]
scalar var_reduced_form = _se[right]^2
scalar n_obs = e(N)

regress participated right right_score left_score [aweight=weight], vce(hc0)
scalar first_stage = _b[right]
scalar var_first_stage = _se[right]^2

* Obtain the HC0 cross-outcome covariance from the stacked estimating contributions.
mata:
    y1 = st_data(., "earnings")
    y2 = st_data(., "participated")
    w  = st_data(., "weight")
    r  = st_data(., "right")
    rs = st_data(., "right_score")
    ls = st_data(., "left_score")
    X  = (J(rows(r),1,1), r, rs, ls)

    // Weighted least squares with triangular weights.
    bread = invsym(X' * (w :* X))
    b1 = bread * X' * (w :* y1)
    b2 = bread * X' * (w :* y2)
    e1 = y1 - X*b1
    e2 = y2 - X*b2

    // The right-minus-left intercept contrast is the coefficient on right.
    c = (0\1\0\0)
    a = w :* (X * bread * c)
    u1 = a :* e1
    u2 = a :* e2
    V11 = sum(u1:^2)
    V22 = sum(u2:^2)
    V12 = sum(u1 :* u2)

    st_numscalar("var_reduced_form_joint", V11)
    st_numscalar("var_first_stage_joint", V22)
    st_numscalar("cov_rf_fs", V12)
end

scalar treatment_effect = reduced_form / first_stage
scalar gradient_rf = 1 / first_stage
scalar gradient_fs = -reduced_form / (first_stage^2)
scalar var_treatment_effect = gradient_rf^2 * var_reduced_form_joint + ///
    gradient_fs^2 * var_first_stage_joint + ///
    2 * gradient_rf * gradient_fs * cov_rf_fs
scalar se_treatment_effect = sqrt(var_treatment_effect)

display "ANSWER: treatment_effect estimate=" %21.12f treatment_effect ///
    " se=" %21.12f se_treatment_effect " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f reduced_form ///
    " se=" %21.12f sqrt(var_reduced_form_joint) " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f first_stage ///
    " se=" %21.12f sqrt(var_first_stage_joint) " n_obs=" %12.0f n_obs
