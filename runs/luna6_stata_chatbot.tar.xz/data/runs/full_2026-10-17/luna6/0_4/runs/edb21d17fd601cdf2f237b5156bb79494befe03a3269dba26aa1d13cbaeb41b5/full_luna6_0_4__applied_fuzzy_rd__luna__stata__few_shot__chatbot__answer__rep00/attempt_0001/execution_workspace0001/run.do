version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

keep if abs(score) < 1
generate double weight = 1 - abs(score)
generate double right = score >= 0
generate double score_right = score * right

local n = _N

* Fit the same weighted local-linear model for both outcomes.
generate double earnings_fit = .
generate double participation_fit = .

quietly regress earnings right score score_right [aw=weight], vce(robust)
predict double earnings_fit, xb
scalar reduced_form = _b[right]
scalar var_rf = e(V)["right","right"]

quietly regress participated right score score_right [aw=weight], vce(robust)
predict double participation_fit, xb
scalar first_stage = _b[right]
scalar var_fs = e(V)["right","right"]

* The joint covariance uses observation-level HC0 score contributions.
generate double rf_resid = earnings - earnings_fit
generate double fs_resid = participated - participation_fit
quietly regress earnings right score score_right [aw=weight]
matrix Xp = e(b)
matrix Xp = e(V)
* Obtain the weighted design bread and coefficient influence loadings.
generate double x1 = 1
generate double x2 = right
generate double x3 = score
generate double x4 = score_right
matrix accum XtWX = x1 x2 x3 x4 [aw=weight]
matrix bread = syminv(XtWX)
scalar cov_rf_fs = 0
forvalues i = 1/`n' {
    scalar h_rf = 0
    scalar h_fs = 0
    forvalues j = 1/4 {
        scalar h_rf = h_rf + bread[`j',2] * weight[`i'] * x`j'[`i']
        scalar h_fs = h_fs + bread[`j',2] * weight[`i'] * x`j'[`i']
    }
    scalar cov_rf_fs = cov_rf_fs + (h_rf * rf_resid[`i']) * (h_fs * fs_resid[`i'])
}

scalar treatment_effect = reduced_form / first_stage
scalar gradient_rf = 1 / first_stage
scalar gradient_fs = -reduced_form / (first_stage^2)
scalar var_te = gradient_rf^2 * var_rf + gradient_fs^2 * var_fs + 2 * gradient_rf * gradient_fs * cov_rf_fs
scalar se_rf = sqrt(var_rf)
scalar se_fs = sqrt(var_fs)
scalar se_te = sqrt(var_te)

display "ANSWER: treatment_effect estimate=" %21.12f treatment_effect " se=" %21.12f se_te " n_obs=" %12.0f `n'
display "ANSWER: reduced_form estimate=" %21.12f reduced_form " se=" %21.12f se_rf " n_obs=" %12.0f `n'
display "ANSWER: first_stage estimate=" %21.12f first_stage " se=" %21.12f se_fs " n_obs=" %12.0f `n'
