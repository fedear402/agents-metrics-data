clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

keep if abs(score) < 1
count
scalar n_obs = r(N)

generate byte right = score >= 0
generate double x_right = score * right
generate double x_left = score * (1 - right)
generate double triangular_weight = 1 - abs(score)

quietly regress earnings right x_left x_right [aweight=triangular_weight], vce(robust)
scalar reduced_form = _b[right]
scalar var_reduced_form = _se[right]^2

quietly regress participated right x_left x_right [aweight=triangular_weight], vce(robust)
scalar first_stage = _b[right]
scalar var_first_stage = _se[right]^2

* Estimate the covariance of the two discontinuity estimates from joint HC0 scores.
quietly summarize triangular_weight, meanonly
scalar sum_weights = r(sum)

quietly regress earnings right x_left x_right [aweight=triangular_weight]
predict double earnings_residual, resid
matrix b_earnings = e(b)
generate double score_earnings = triangular_weight * earnings_residual * ///
    (right - b_earnings[1,1] * 0 - b_earnings[1,2] * x_left - b_earnings[1,3] * x_right)

quietly regress participated right x_left x_right [aweight=triangular_weight]
predict double participation_residual, resid
matrix b_participation = e(b)
generate double score_participation = triangular_weight * participation_residual * ///
    (right - b_participation[1,1] * 0 - b_participation[1,2] * x_left - b_participation[1,3] * x_right)

quietly regress earnings right x_left x_right [aweight=triangular_weight]
matrix inv_earnings = e(V)
quietly regress participated right x_left x_right [aweight=triangular_weight]
matrix inv_participation = e(V)

* HC0 covariance uses the weighted-regression bread and observation score products.
quietly regress earnings right x_left x_right [aweight=triangular_weight]
matrix bread_earnings = syminv(e(V))
quietly regress participated right x_left x_right [aweight=triangular_weight]
matrix bread_participation = syminv(e(V))

generate double joint_score_product = score_earnings * score_participation
quietly summarize joint_score_product, meanonly
scalar cross_meat = r(sum)

scalar covariance_rf_fs = cross_meat / (sum_weights^2)
scalar treatment_effect = reduced_form / first_stage
scalar se_reduced_form = sqrt(var_reduced_form)
scalar se_first_stage = sqrt(var_first_stage)

scalar var_treatment_effect = ///
    var_reduced_form / first_stage^2 + ///
    reduced_form^2 * var_first_stage / first_stage^4 - ///
    2 * reduced_form * covariance_rf_fs / first_stage^3
scalar se_treatment_effect = sqrt(max(0, var_treatment_effect))

display "ANSWER: treatment_effect estimate=" %21.12f treatment_effect " se=" %21.12f se_treatment_effect " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f reduced_form " se=" %21.12f se_reduced_form " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f first_stage " se=" %21.12f se_first_stage " n_obs=" %12.0f n_obs
