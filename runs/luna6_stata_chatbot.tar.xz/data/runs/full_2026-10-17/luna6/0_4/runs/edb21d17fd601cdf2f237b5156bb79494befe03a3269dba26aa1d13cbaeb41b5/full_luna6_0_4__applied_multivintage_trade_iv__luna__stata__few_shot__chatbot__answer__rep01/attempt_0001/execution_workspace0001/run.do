clear all
set more off
set type double

import delimited using "crosswalk.csv", clear
tempfile crosswalk trade areas employment outcomes
save `crosswalk'

import delimited using "trade.csv", clear
merge m:1 code using `crosswalk', assert(match) nogen
save `trade'

import delimited using "areas.csv", clear
save `areas'

import delimited using "employment.csv", clear
save `employment'

import delimited using "outcomes.csv", clear
save `outcomes'

* Build national industry employment totals within period and vintage.
use `employment', clear
collapse (sum) national_employment=employment, by(period vintage industry)
tempfile national
save `national'

* Complete omitted area-industry cells as zero.
use `areas', clear
keep area period vintage total_employment population
duplicates drop
tempfile area_vintages
save `area_vintages'

use `area_vintages', clear
keep area period vintage
cross using `crosswalk'
rename industry industry
merge 1:1 area period vintage industry using `employment', keep(master match) nogen
replace employment = 0 if missing(employment)
merge m:1 period vintage industry using `national', assert(match) nogen
gen double base_share = employment / national_employment
collapse (sum) exposure_share=base_share, by(area period vintage)
tempfile shares
save `shares'

* Attach vintage-specific total employment and trade totals.
use `areas', clear
keep area period vintage total_employment population
duplicates drop
merge 1:1 area period vintage using `shares', assert(match) nogen
reshape wide total_employment exposure_share, i(area period) j(vintage) string

* Form the industry-weighted trade changes by period.
use `trade', clear
collapse (sum) us_change other_change, by(period)
* The crosswalk has already verified code to industry mappings.
tempfile period_trade
save `period_trade'

use `trade', clear
collapse (mean) price_index years, by(period)
merge 1:1 period using `period_trade', assert(match) nogen
tempfile period_inputs
save `period_inputs'

* Compute industry-level exposure contributions with the correct national denominators.
use `trade', clear
merge m:1 period using `period_inputs', assert(match) nogen
merge m:1 code using `crosswalk', assert(match) nogen
tempfile trade_industry
save `trade_industry'

use `employment', clear
merge m:1 period vintage industry using `national', assert(match) nogen
merge m:1 area period vintage using `areas', keep(match) nogen
merge m:1 industry period using `trade_industry', keep(match) nogen
gen double contribution = (employment / total_employment) * ///
    (us_change / national_employment) / (price_index / 100) / 1000 * (10 / years)
gen double z_contribution = (employment / total_employment) * ///
    (other_change / national_employment) / (price_index / 100) / 1000 * (10 / years)
collapse (sum) x=contribution z=z_contribution, by(area period vintage)
keep if vintage == "base"
keep area period x z
tempfile exposures
save `exposures'

use `outcomes', clear
merge 1:1 area period using `exposures', assert(match) nogen
merge m:1 area period using `areas', keep(match) nogen
gen byte period_indicator = period == 1
ivregress 2sls change_pp period_indicator control (x = z) [aw=population]
scalar iv_slope = _b[x]
scalar exposure_area0_period0 = x[1]
quietly summarize x if area == 0 & period == 0, meanonly
scalar exposure_area0_period0 = r(mean)
quietly summarize x if area == 0 & period == 1, meanonly
scalar exposure_area0_period1 = r(mean)
quietly summarize z if area == 0 & period == 0, meanonly
scalar instrument_area0_period0 = r(mean)
count
local n_obs = r(N)

display "ANSWER: iv_slope estimate=" %24.16g iv_slope " se=NA n_obs=" %3.0f `n_obs'
display "ANSWER: exposure_area0_period0 estimate=" %24.16g exposure_area0_period0 " se=NA n_obs=" %3.0f `n_obs'
display "ANSWER: exposure_area0_period1 estimate=" %24.16g exposure_area0_period1 " se=NA n_obs=" %3.0f `n_obs'
display "ANSWER: instrument_area0_period0 estimate=" %24.16g instrument_area0_period0 " se=NA n_obs=" %3.0f `n_obs'
