clear all
set more off
set linesize 255

import delimited using "./input.csv", clear varnames(1)

tsset t
quietly arima y, arima(1,1,1) noconstant

quietly predict double forecast_y, y
quietly predict double forecast_se, yse

quietly summarize t, meanonly
local n_obs = r(N)
local forecast_t = r(max) + 1

quietly summarize forecast_y if t == `forecast_t', meanonly
scalar forecast_estimate = r(mean)
quietly summarize forecast_se if t == `forecast_t', meanonly
scalar forecast_std_error = r(mean)

scalar lower_95_estimate = forecast_estimate - invnormal(.975) * forecast_std_error
scalar upper_95_estimate = forecast_estimate + invnormal(.975) * forecast_std_error

display "ANSWER: forecast estimate=" %21.12f forecast_estimate " se=" %21.12f forecast_std_error " n_obs=" %12.0f `n_obs'
display "ANSWER: lower_95 estimate=" %21.12f lower_95_estimate " se=" %21.12f . " n_obs=" %12.0f `n_obs'
display "ANSWER: upper_95 estimate=" %21.12f upper_95_estimate " se=" %21.12f . " n_obs=" %12.0f `n_obs'
