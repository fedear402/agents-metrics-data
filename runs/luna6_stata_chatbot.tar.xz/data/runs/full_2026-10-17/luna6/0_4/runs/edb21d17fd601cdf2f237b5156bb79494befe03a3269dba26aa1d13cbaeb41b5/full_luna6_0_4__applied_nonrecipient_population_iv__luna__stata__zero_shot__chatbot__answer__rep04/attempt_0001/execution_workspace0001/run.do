clear all
set more off

import delimited using "households.csv", clear varnames(1)

keep if recipient == 0

generate double ineligible = 1 - eligible
generate double dose_ineligible = dose * ineligible
generate double dose_eligible = dose * eligible
generate double baseline_ineligible = baseline * ineligible
generate double baseline_eligible = baseline * eligible
generate double instrument_ineligible = instrument * ineligible
generate double instrument_eligible = instrument * eligible

ivregress 2sls outcome ineligible eligible baseline_ineligible baseline_eligible ///
    (dose_ineligible dose_eligible = instrument_ineligible instrument_eligible) ///
    [aweight=weight], noconstant

scalar slope_ineligible = _b[dose_ineligible]
scalar slope_eligible = _b[dose_eligible]
scalar n_used = e(N)

quietly summarize dose [aweight=weight] if eligible == 0
scalar mean_dose_ineligible = r(mean)

quietly summarize dose [aweight=weight] if eligible == 1
scalar mean_dose_eligible = r(mean)

scalar ineligible_effect = slope_ineligible * mean_dose_ineligible
scalar eligible_nonrecipient_effect = slope_eligible * mean_dose_eligible

import delimited using "census.csv", clear varnames(1)
quietly summarize nonrecipient_population if eligible == 0, meanonly
scalar population_ineligible = r(mean)
quietly summarize nonrecipient_population if eligible == 1, meanonly
scalar population_eligible = r(mean)

scalar population_effect = ///
    (ineligible_effect * population_ineligible + ///
     eligible_nonrecipient_effect * population_eligible) / ///
    (population_ineligible + population_eligible)

display as text "ANSWER: ineligible_effect estimate=" ///
    as result %21.12g scalar(ineligible_effect) ///
    as text " se=NA n_obs=" as result %12.0f scalar(n_used)

display as text "ANSWER: eligible_nonrecipient_effect estimate=" ///
    as result %21.12g scalar(eligible_nonrecipient_effect) ///
    as text " se=NA n_obs=" as result %12.0f scalar(n_used)

display as text "ANSWER: population_effect estimate=" ///
    as result %21.12g scalar(population_effect) ///
    as text " se=NA n_obs=" as result %12.0f scalar(n_used)
