clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

sort date
gen double log_sales = ln(sales)
gen double dlog_vix = ln(vix) - ln(vix[_n-1])

forvalues j = 1/15 {
    gen double lag_`j' = dlog_vix[_n-`j']
}

regress log_sales lag_1-lag_15 if !missing(log_sales, lag_1, lag_2, lag_3, lag_4, lag_5, lag_6, lag_7, lag_8, lag_9, lag_10, lag_11, lag_12, lag_13, lag_14, lag_15)

scalar N = e(N)
scalar b1 = _b[lag_1]
scalar b15 = _b[lag_15]
scalar cum = 0
forvalues j = 1/15 {
    scalar cum = cum + _b[lag_`j']
}

matrix V = e(V)
matrix S = J(16, 16, 0)
forvalues j = 0/15 {
    forvalues k = 0/15 {
        local d = abs(`j' - `k')
        if `d' <= 15 {
            local w = 1 - `d'/16
            matrix S[`=`j'+1',`=`k'+1'] = `w' * V[`=`j'+1',`=`k'+1']
        }
    }
}
matrix S = (N/(N-16)) * S

scalar se1 = sqrt(S[2,2])
scalar se15 = sqrt(S[16,16])
scalar secum = 0
forvalues j = 1/15 {
    forvalues k = 1/15 {
        scalar secum = secum + S[`=`j'+1',`=`k'+1']
    }
}
scalar secum = sqrt(secum)

display "ANSWER: cumulative_response estimate=" %21.12f cum " se=" %21.12f secum " n_obs=" %12.0f N
display "ANSWER: lag_1 estimate=" %21.12f b1 " se=" %21.12f se1 " n_obs=" %12.0f N
display "ANSWER: lag_15 estimate=" %21.12f b15 " se=" %21.12f se15 " n_obs=" %12.0f N
