clear all
set more off
set linesize 255

import delimited using "./input.csv", clear
tsset t

arima y, arima(1,1,1) noconstant

predict double forecast_level, y
predict double forecast_se, mse

local forecast = forecast_level[_N]
local forecast_sd = forecast_se[_N]
local lower = `forecast' - invnormal(0.975)*`forecast_sd'
local upper = `forecast' + invnormal(0.975)*`forecast_sd'
local n = e(N)

display "ANSWER: forecast estimate=" %21.12f `forecast' " se=" %21.12f `forecast_sd' " n_obs=" %12.0f `n'
display "ANSWER: lower_95 estimate=" %21.12f `lower' " se=. n_obs=" %12.0f `n'
display "ANSWER: upper_95 estimate=" %21.12f `upper' " se=. n_obs=" %12.0f `n'
