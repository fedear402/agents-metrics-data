clear all
set more off
set linesize 255
set type double

import delimited using "./input.csv", clear

local n = _N
local df = `n' - 4
local q = 2
scalar critical = invFtail(`q', `df', .05)
scalar k = `q' * critical / `df'

quietly regress y x
predict double ry, residuals

quietly regress endog x
predict double rd, residuals

quietly regress y x z1 z2
predict double uy, residuals

quietly regress endog x z1 z2
predict double ud, residuals

mata:
ry = st_data(., "ry")
rd = st_data(., "rd")
uy = st_data(., "uy")
ud = st_data(., "ud")
k = st_numscalar("k")

A = quadcross(rd, rd) - (1+k)*quadcross(ud, ud)
B = -2*(quadcross(ry, rd) - (1+k)*quadcross(uy, ud))
C = quadcross(ry, ry) - (1+k)*quadcross(uy, uy)

disc = B^2 - 4*A*C
assert(abs(A)>1e-12 & disc>0)

r1 = (-B-sqrt(disc))/(2*A)
r2 = (-B+sqrt(disc))/(2*A)
low = min((r1,r2))
high = max((r1,r2))

st_numscalar("boundary_low", low)
st_numscalar("boundary_high", high)
st_numscalar("accepts_zero", C<=0)
st_numscalar("unbounded", A<0)

st_numscalar("ar_f_at_one", ///
    ((quadcross(ry-rd, ry-rd)-quadcross(uy-ud, uy-ud))/2) / ///
    (quadcross(uy-ud, uy-ud)/st_numscalar("`df'"))
)
end
