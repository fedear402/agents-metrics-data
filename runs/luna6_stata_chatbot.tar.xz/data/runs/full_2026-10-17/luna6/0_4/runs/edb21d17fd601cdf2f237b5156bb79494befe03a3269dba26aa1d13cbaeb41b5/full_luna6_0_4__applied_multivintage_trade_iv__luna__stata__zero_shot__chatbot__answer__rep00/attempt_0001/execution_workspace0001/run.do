clear all
set more off

import delimited using "crosswalk.csv", clear
tempfile crosswalk trade areas employment outcomes
save `crosswalk'

import delimited using "trade.csv", clear
merge m:1 code using `crosswalk', keep(match) nogen
save `trade'

import delimited using "areas.csv", clear
save `areas'

import delimited using "employment.csv", clear
save `employment'

import delimited using "outcomes.csv", clear
save `outcomes'

* Complete the area-period-vintage-industry cells with zero employment.
use `areas', clear
keep area period vintage total_employment population
joinby period vintage using `employment', unmatched(master)
replace employment = 0 if missing(employment)
keep area period vintage total_employment population industry employment
tempfile area_employment
save `area_employment'

* National employment totals by period, vintage, and industry.
use `area_employment', clear
collapse (sum) national_employment=employment, by(period vintage industry)
tempfile national
save `national'

* Calculate each area's industry employment shares and merge trade changes.
use `area_employment', clear
merge m:1 period vintage industry using `national', nogen
merge m:1 period industry using `trade', keep(match) nogen
gen double x_component = (employment / total_employment) * ///
    (us_change / national_employment) / (price_index / 100) / 1000 * (10 / years) ///
    if vintage == "base"
gen double z_component = (employment / total_employment) * ///
    (other_change / national_employment) / (price_index / 100) / 1000 * (10 / years) ///
    if vintage == "early"

collapse (sum) x=x_component z=z_component, by(area period vintage)
keep if vintage == "base"
drop vintage
tempfile exposures
save `exposures'

* Combine exposure measures with outcomes and base-vintage population weights.
use `outcomes', clear
merge 1:1 area period using `exposures', keep(match) nogen
merge m:1 area period using `areas', keep(match) nogen
keep if vintage == "base"
local n = _N

* Weighted 2SLS; period, control, and intercept are included instruments.
ivregress 2sls change_pp i.period control (x = z) [pw=population], vce(robust)
scalar iv_slope = _b[x]

quietly summarize x if area == 0 & period == 0, meanonly
scalar exposure_area0_period0 = r(mean)
quietly summarize x if area == 0 & period == 1, meanonly
scalar exposure_area0_period1 = r(mean)
quietly summarize z if area == 0 & period == 0, meanonly
scalar instrument_area0_period0 = r(mean)

display "ANSWER: iv_slope estimate=" %21.12g scalar(iv_slope) " se=NA n_obs=" %4.0f `n'
display "ANSWER: exposure_area0_period0 estimate=" %21.12g scalar(exposure_area0_period0) " se=NA n_obs=" %4.0f `n'
display "ANSWER: exposure_area0_period1 estimate=" %21.12g scalar(exposure_area0_period1) " se=NA n_obs=" %4.0f `n'
display "ANSWER: instrument_area0_period0 estimate=" %21.12g scalar(instrument_area0_period0) " se=NA n_obs=" %4.0f `n'
