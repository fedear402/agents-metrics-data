import delimited using "households.csv", clear varnames(1)

keep if recipient == 0

generate byte ineligible = 1 - eligible
generate double dose_ineligible = dose * ineligible
generate double dose_eligible = dose * eligible
generate double base_ineligible = baseline * ineligible
generate double base_eligible = baseline * eligible
generate double instrument_ineligible = instrument * ineligible
generate double instrument_eligible = instrument * eligible

quietly ivregress 2sls outcome ineligible eligible base_ineligible base_eligible ///
    (dose_ineligible dose_eligible = instrument_ineligible instrument_eligible) ///
    [aw=weight], noconstant

local n_obs = e(N)

quietly summarize dose [aw=weight] if eligible == 0
local mean_dose_ineligible = r(mean)
quietly summarize dose [aw=weight] if eligible == 1
local mean_dose_eligible = r(mean)

scalar ineligible_effect = _b[dose_ineligible] * `mean_dose_ineligible'
scalar eligible_nonrecipient_effect = _b[dose_eligible] * `mean_dose_eligible'

import delimited using "census.csv", clear varnames(1)
quietly summarize nonrecipient_population if eligible == 0
scalar population_ineligible = r(sum)
quietly summarize nonrecipient_population if eligible == 1
scalar population_eligible = r(sum)

scalar population_effect = ///
    (population_ineligible * ineligible_effect + ///
     population_eligible * eligible_nonrecipient_effect) / ///
    (population_ineligible + population_eligible)

display as text "ANSWER: ineligible_effect estimate=" ///
    as result %21.12g ineligible_effect ///
    as text " se=NA n_obs=" as result %12.0f `n_obs'
display as text "ANSWER: eligible_nonrecipient_effect estimate=" ///
    as result %21.12g eligible_nonrecipient_effect ///
    as text " se=NA n_obs=" as result %12.0f `n_obs'
display as text "ANSWER: population_effect estimate=" ///
    as result %21.12g population_effect ///
    as text " se=NA n_obs=" as result %12.0f `n_obs'
