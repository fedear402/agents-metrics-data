clear all
set more off
set linesize 255
set type double

import delimited using "./input.csv", clear
quietly count
scalar n = r(N)
scalar df = n - 4
scalar q = 2
scalar critical = invFtail(q, df, .05)
scalar k = q * critical / df

quietly regress y
predict double ry, residuals
quietly regress endog
predict double rd, residuals
quietly regress y x z1 z2
predict double uy, residuals
quietly regress endog x z1 z2
predict double ud, residuals

mata:
ry = st_data(., "ry")
rd = st_data(., "rd")
uy = st_data(., "uy")
ud = st_data(., "ud")
k = st_numscalar("k")

A = quadcross(rd, rd) - (1+k)*quadcross(ud, ud)
B = -2*(quadcross(ry, rd) - (1+k)*quadcross(uy, ud))
C = quadcross(ry, ry) - (1+k)*quadcross(uy, uy)

disc = B^2 - 4*A*C
assert(disc > 0)
bounds = sort(((-B-sqrt(disc))/(2*A) \ (-B+sqrt(disc))/(2*A)), 1)
st_numscalar("boundary_low", bounds[1])
st_numscalar("boundary_high", bounds[2])
st_numscalar("accepts_zero", C <= 0)
st_numscalar("unbounded", A < 0)

quietly regress y endog x z1 z2
scalar ssr_u_one = e(rss)
quietly regress y endog x
scalar ssr_r_one = e(rss)
scalar ar_f_at_one = ((ssr_r_one - ssr_u_one)/q)/(ssr_u_one/df)
end

display "ANSWER: boundary_low estimate=" %21.12f scalar(boundary_low) " se=." " n_obs=" %12.0f scalar(n)
display "ANSWER: boundary_high estimate=" %21.12f scalar(boundary_high) " se=." " n_obs=" %12.0f scalar(n)
display "ANSWER: accepts_zero estimate=" %21.12f scalar(accepts_zero) " se=." " n_obs=" %12.0f scalar(n)
display "ANSWER: unbounded estimate=" %21.12f scalar(unbounded) " se=." " n_obs=" %12.0f scalar(n)
display "ANSWER: ar_f_at_one estimate=" %21.12f scalar(ar_f_at_one) " se=." " n_obs=" %12.0f scalar(n)
