clear all
set more off
set linesize 255

import delimited using "./input.csv", clear
tsset t

arima y, arima(1,1,1) noconstant

predict double forecast_y, y
predict double forecast_se, mse

local n = _N
local forecast_value = forecast_y[_N+1]
local forecast_error = sqrt(forecast_se[_N+1])
local lower_value = `forecast_value' - invnormal(0.975)*`forecast_error'
local upper_value = `forecast_value' + invnormal(0.975)*`forecast_error'

display "ANSWER: forecast estimate=" %21.12f `forecast_value' " se=" %21.12f `forecast_error' " n_obs=" %12.0f `n'
display "ANSWER: lower_95 estimate=" %21.12f `lower_value' " se=. n_obs=" %12.0f `n'
display "ANSWER: upper_95 estimate=" %21.12f `upper_value' " se=. n_obs=" %12.0f `n'
