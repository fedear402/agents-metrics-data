version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

* Keep one row per region to normalize regional weights.
preserve
    bysort region_id: keep if _n == 1
    egen double total_region_weight = total(region_weight)
    gen double e = region_weight / total_region_weight
    keep region_id e
    tempfile region_weights
    save `region_weights'
restore

* Confirm region-level variables and obtain one row per region.
merge m:1 region_id using `region_weights', nogen
bysort region_id: keep if _n == 1

* Regional shift-share instrument.
tempfile regional_data
save `regional_data'

restore
