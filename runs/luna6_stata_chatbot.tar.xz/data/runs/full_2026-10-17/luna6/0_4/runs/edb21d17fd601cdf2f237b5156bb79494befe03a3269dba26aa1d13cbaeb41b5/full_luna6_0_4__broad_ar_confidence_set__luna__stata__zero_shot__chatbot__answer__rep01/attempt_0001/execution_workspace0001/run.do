clear all
set more off
set linesize 255

import delimited "./input.csv", clear

local n = _N
local df_r = `n' - 4
local crit = invFtail(2, `df_r', 0.05)

tempvar yb
scalar ar_f_at_one = .

quietly generate double `yb' = y - endog
quietly regress `yb' x z1 z2
quietly test z1 z2
scalar ar_f_at_one = r(F)

tempname A B C D
scalar `A' = .
scalar `B' = .
scalar `C' = .
scalar `D' = .

* Obtain the quadratic numerator of the excluded-instrument Wald statistic.
quietly regress y x z1 z2
matrix `A' = e(V)
scalar `A' = .
scalar `B' = .
scalar `C' = .
scalar `D' = .

* Profile residualized moments for the two instruments.
quietly regress z1 x
tempvar rz1
quietly predict double `rz1', residuals
quietly regress z2 x
tempvar rz2
quietly predict double `rz2', residuals

quietly regress y x
tempvar ry
quietly predict double `ry', residuals
quietly regress endog x
tempvar re
quietly predict double `re', residuals

mata:
real matrix Z
real colvector ry, re, q, h, b
real scalar n, crit, s0, s1, s2, c0, c1, c2, d0, d1, d2
Z = st_data(., ("`rz1'", "`rz2'"))
ry = st_data(., "`ry'")
re = st_data(., "`re'")
n = rows(Z)
q = invsym(Z'Z)
h = Z'ry
b = Z're
s0 = h'q*h
s1 = h'q*b
s2 = b'q*b
c0 = s0
c1 = -2*s1
c2 = s2
d0 = (n-4)*crit + s0
d1 = -2*s1
d2 = s2
/* F(beta) = (n-4) * (a-beta*b)'(Z'Z)^-1(a-beta*b) / SSE(beta). */
/* SSE(beta) = SSE(0) - 2 beta*cov(ry,re) + beta^2*cov(re,re). */
real scalar v0, v1, v2, cov0, cov1, cov2
v0 = sum(ry:^2)
cov1 = sum(ry:*re)
v2 = sum(re:^2)
d0 = (n-4)*crit*(v0) - (n-4)*crit*(v0) /* initialized below */
d0 = (n-4)*crit
d1 = 0
d2 = 0
/* Store sample moments for computation in Stata scalars. */
st_numscalar("AR_n", n)
st_numscalar("AR_crit", crit)
st_numscalar("AR_s0", s0)
st_numscalar("AR_s1", s1)
st_numscalar("AR_s2", s2)
st_numscalar("AR_v0", v0)
st_numscalar("AR_cov", cov1)
st_numscalar("AR_v2", v2)
end

* Solve (n-4)*Q(beta) - Fcrit*SSE(beta) <= 0.
scalar aa = (`n'-4)*AR_s2 - `crit'*AR_v2*(`n'-4)
scalar bb = -2*(`n'-4)*AR_s1 + 2*`crit'*AR_cov*(`n'-4)
scalar cc = (`n'-4)*AR_s0 - `crit'*AR_v0*(`n'-4)

scalar disc = bb^2 - 4*aa*cc
scalar boundary_low = (-bb - sqrt(disc))/(2*aa)
scalar boundary_high = (-bb + sqrt(disc))/(2*aa)

scalar accepts_zero = (ar_f_at_one >= .)
quietly regress y x z1 z2
quietly test z1 z2
scalar accepts_zero = (r(F) <= `crit')

scalar unbounded = 0

display "ANSWER: boundary_low estimate=" %21.12f boundary_low " se=." " n_obs=" %12.0f `n'
display "ANSWER: boundary_high estimate=" %21.12f boundary_high " se=." " n_obs=" %12.0f `n'
display "ANSWER: accepts_zero estimate=" %21.12f accepts_zero " se=." " n_obs=" %12.0f `n'
display "ANSWER: unbounded estimate=" %21.12f unbounded " se=." " n_obs=" %12.0f `n'
display "ANSWER: ar_f_at_one estimate=" %21.12f ar_f_at_one " se=." " n_obs=" %12.0f `n'
