clear all
set more off

import delimited using "crosswalk.csv", clear
tempfile crosswalk
save `crosswalk'

import delimited using "trade.csv", clear
merge m:1 code using `crosswalk', assert(match) nogen
tempfile trade
save `trade'

import delimited using "areas.csv", clear
tempfile areas
save `areas'

import delimited using "employment.csv", clear
tempfile employment
save `employment'

import delimited using "outcomes.csv", clear
tempfile outcomes
save `outcomes'

* Complete the employment panel so omitted area-industry cells equal zero.
use `areas', clear
keep area period vintage
duplicates drop
cross using `crosswalk'
merge 1:1 area period vintage industry using `employment', nogen
replace employment = 0 if missing(employment)
tempfile complete_employment
save `complete_employment'

* Compute national employment by industry, period, and vintage.
use `complete_employment', clear
collapse (sum) national_employment=employment, by(period vintage industry)
tempfile national_employment
save `national_employment'

* Attach trade changes and national employment to area-industry employment.
use `complete_employment', clear
merge m:1 period industry using `trade', assert(match) nogen
merge m:1 period vintage industry using `national_employment', assert(match) nogen
merge m:1 area period vintage using `areas', keepusing(total_employment population) assert(match) nogen

gen double exposure_component = (employment/total_employment) * ///
    (us_change/national_employment) / (price_index/100) / 1000 * (10/years) ///
    if vintage == "base"
gen double instrument_component = (employment/total_employment) * ///
    (other_change/national_employment) / (price_index/100) / 1000 * (10/years) ///
    if vintage == "early"

collapse (sum) x=exposure_component z=instrument_component, by(area period vintage)
keep if (vintage == "base" & !missing(x)) | (vintage == "early" & !missing(z))
reshape wide x z, i(area period) j(vintage) string
rename xbase x
rename zearly z
drop xearly zbase

merge 1:1 area period using `outcomes', assert(match) nogen
merge m:1 area period vintage using `areas', keepusing(population) nogen
