clear all
set more off
set type double

import delimited using "input.csv", clear

tempfile source results
save `source'

tempname posth
postfile `posth' str12 name double estimate treated_units obs using `results', replace

foreach c in 3 5 7 {
    use `source', clear

    keep if g == `c' | g == 0 | g > `c' + 2
    keep if inrange(time, `c' - 2, `c' + 2)

    bysort id: egen byte n_window = count(y)
    keep if n_window == 5
    drop n_window

    gen byte did = (g == `c' & time >= `c')
    quietly regress y did i.id i.time

    quietly count if g == `c'
    local treated_units = r(N) / 5
    local obs = e(N)
    local estimate = _b[did]

    post `posth' ("att_g`c'") (`estimate') (`treated_units') (`obs')
}

postclose `posth'

use `results', clear
quietly summarize estimate [aw=treated_units]
local weighted = r(mean)
quietly summarize obs
local total_obs = r(sum)

forvalues i = 1/3 {
    display "ANSWER: " name[`i'] " estimate=" %24.16g estimate[`i']
}
display "ANSWER: att_weighted estimate=" %24.16g `weighted'
