clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

tsset t
arima y, arima(1,1,1) noconstant

predict double yhat, y
predict double yse, mse

quietly summarize t
local n = r(N)
local last_t = t[_N]
local next_t = `last_t' + 1

quietly summarize y if t == `last_t'
local last_y = r(mean)

quietly summarize yhat if t == `last_t'
local forecast = `last_y' + r(mean)

quietly summarize yse if t == `last_t'
local forecast_se = sqrt(r(mean))

local lower = `forecast' - invnormal(.975)*`forecast_se'
local upper = `forecast' + invnormal(.975)*`forecast_se'

display "ANSWER: forecast estimate=" %21.12f `forecast' " se=" %21.12f `forecast_se' " n_obs=" %12.0f `n'
display "ANSWER: lower_95 estimate=" %21.12f `lower' " se=. n_obs=" %12.0f `n'
display "ANSWER: upper_95 estimate=" %21.12f `upper' " se=. n_obs=" %12.0f `n'
