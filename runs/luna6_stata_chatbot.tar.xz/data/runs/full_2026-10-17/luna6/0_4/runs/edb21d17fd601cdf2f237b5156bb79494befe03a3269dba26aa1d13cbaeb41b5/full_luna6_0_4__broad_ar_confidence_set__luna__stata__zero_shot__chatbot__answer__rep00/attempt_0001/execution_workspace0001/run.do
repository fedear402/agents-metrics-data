clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

local n = _N
local df2 = `n' - 4
local critical = invFtail(2, `df2', 0.05)

* Fit the reduced form and retain residualized outcome and endogenous regressor.
quietly regress y x
tempvar ry
predict double `ry', residuals

quietly regress endog x
tempvar rendog
predict double `rendog', residuals

* The excluded-instrument F statistic is a quadratic ratio in beta.
quietly regress `ry' z1 z2, noconstant
scalar q0 = e(rss)
scalar rssdf = e(df_r)
predict double e0, residuals

quietly regress `rendog' z1 z2, noconstant
predict double e1, residuals

generate double cross01 = e0 * e1
generate double sq1 = e1^2
quietly summarize cross01, meanonly
scalar c01 = r(sum)
quietly summarize sq1, meanonly
scalar c11 = r(sum)

* For each beta, SSR(beta) = q0 - 2*beta*c01 + beta^2*c11.
* F(beta) = ((q0 - SSR(beta))/2) / (SSR(beta)/(n-4)).
* Solve F(beta)=critical for the two finite boundaries.
scalar cutoff_ssr = q0 / (1 + 2*`critical'/`df2')
scalar disc = c01^2 - c11*(q0-cutoff_ssr)
scalar boundary_low = (c01 - sqrt(disc))/c11
scalar boundary_high = (c01 + sqrt(disc))/c11

scalar accepts_zero = (q0 <= cutoff_ssr)
scalar unbounded = 0

* Compute the conventional joint F statistic at beta=1.
scalar ssr_one = q0 - 2*c01 + c11
scalar ar_f_at_one = ((q0-ssr_one)/2) / (ssr_one/`df2')

scalar missing_se = .
scalar n_obs = `n'

display "ANSWER: boundary_low estimate=" %21.12f boundary_low " se=" %21.12f missing_se " n_obs=" %12.0f n_obs
display "ANSWER: boundary_high estimate=" %21.12f boundary_high " se=" %21.12f missing_se " n_obs=" %12.0f n_obs
display "ANSWER: accepts_zero estimate=" %21.12f accepts_zero " se=" %21.12f missing_se " n_obs=" %12.0f n_obs
display "ANSWER: unbounded estimate=" %21.12f unbounded " se=" %21.12f missing_se " n_obs=" %12.0f n_obs
display "ANSWER: ar_f_at_one estimate=" %21.12f ar_f_at_one " se=" %21.12f missing_se " n_obs=" %12.0f n_obs
