version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

generate double date_num = daily(date, "YMD")
format date_num %td
sort date_num

generate double log_vix = ln(vix)
generate double volatility_change = log_vix - log_vix[_n-1]
generate double log_sales = ln(sales)

forvalues j = 1/15 {
    generate double lag_`j' = volatility_change[_n-`j']
}

keep if !missing(log_sales, lag_1, lag_2, lag_3, lag_4, lag_5, ///
    lag_6, lag_7, lag_8, lag_9, lag_10, lag_11, lag_12, lag_13, ///
    lag_14, lag_15)

mata:
X = (J(st_nobs(), 1, 1), st_data(., ("lag_1","lag_2","lag_3","lag_4","lag_5","lag_6","lag_7","lag_8","lag_9","lag_10","lag_11","lag_12","lag_13","lag_14","lag_15")))
y = st_data(., "log_sales")
b = qrsolve(X, y)
u = y - X*b
N = rows(X)
p = cols(X)
scores = X :* u
meat = scores' * scores
for (j=1; j<=15; j++) {
    lag_product = scores[|j+1,1\N,p|]' * scores[|1,1\N-j,p|]
    meat = meat + (1-j/16) * (lag_product + lag_product')
}
bread = invsym(X' * X)
V = (N/(N-16)) * bread * meat * bread

contrast = J(p, 1, 0)
contrast[|2\16|] = J(15, 1, 1)
cumulative = contrast' * b
cumulative_se = sqrt(contrast' * V * contrast)
lag1 = b[2]
lag1_se = sqrt(V[2,2])
lag15 = b[16]
lag15_se = sqrt(V[16,16])

st_numscalar("cumulative_estimate", cumulative)
st_numscalar("cumulative_se", cumulative_se)
st_numscalar("lag1_estimate", lag1)
st_numscalar("lag1_se", lag1_se)
st_numscalar("lag15_estimate", lag15)
st_numscalar("lag15_se", lag15_se)
st_numscalar("regression_n", N)
end

display "ANSWER: cumulative_response estimate=" %21.12f scalar(cumulative_estimate) " se=" %21.12f scalar(cumulative_se) " n_obs=" %12.0f scalar(regression_n)
display "ANSWER: lag_1 estimate=" %21.12f scalar(lag1_estimate) " se=" %21.12f scalar(lag1_se) " n_obs=" %12.0f scalar(regression_n)
display "ANSWER: lag_15 estimate=" %21.12f scalar(lag15_estimate) " se=" %21.12f scalar(lag15_se) " n_obs=" %12.0f scalar(regression_n)
