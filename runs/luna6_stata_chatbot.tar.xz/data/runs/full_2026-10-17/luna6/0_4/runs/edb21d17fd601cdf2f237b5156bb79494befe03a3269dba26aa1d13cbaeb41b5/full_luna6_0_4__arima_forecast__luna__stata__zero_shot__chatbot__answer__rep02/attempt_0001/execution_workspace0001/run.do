clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

tsset t
arima y, arima(1,1,1) noconstant

predict double forecast_y, y
predict double forecast_se, mse

quietly summarize t
scalar n_obs = r(N)

quietly summarize forecast_y if t == 251
scalar forecast_value = r(mean)

quietly summarize forecast_se if t == 251
scalar forecast_se_value = sqrt(r(mean))

scalar lower_95_value = forecast_value - invnormal(0.975) * forecast_se_value
scalar upper_95_value = forecast_value + invnormal(0.975) * forecast_se_value

display "ANSWER: forecast estimate=" %21.12f forecast_value " se=." " n_obs=" %12.0f n_obs
display "ANSWER: lower_95 estimate=" %21.12f lower_95_value " se=." " n_obs=" %12.0f n_obs
display "ANSWER: upper_95 estimate=" %21.12f upper_95_value " se=." " n_obs=" %12.0f n_obs
