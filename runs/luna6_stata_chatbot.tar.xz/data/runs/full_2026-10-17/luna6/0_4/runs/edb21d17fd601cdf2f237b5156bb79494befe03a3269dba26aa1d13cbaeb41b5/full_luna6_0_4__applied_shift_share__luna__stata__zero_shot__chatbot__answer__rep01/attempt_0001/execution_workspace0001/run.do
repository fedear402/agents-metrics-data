clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

* Keep one row per region for regional outcomes and weights.
egen byte region_tag = tag(region_id)
egen byte industry_tag = tag(industry_id)

* Normalize regional weights once, using one observation per region.
quietly summarize region_weight if region_tag, meanonly
scalar total_region_weight = r(sum)
generate double e = region_weight / total_region_weight

* Regional shift-share instrument.
generate double share_shock = share * shock
bysort region_id: egen double z = total(share_shock)

* Weighted regional means and demeaned variables.
quietly summarize y if region_tag [aw=e], meanonly
scalar mean_y = r(mean)
quietly summarize x if region_tag [aw=e], meanonly
scalar mean_x = r(mean)
quietly summarize z if region_tag [aw=e], meanonly
scalar mean_z = r(mean)

generate double y0 = y - mean_y
generate double x0 = x - mean_x
generate double z0 = z - mean_z

* Industry exposure weights and exposure-weighted residual aggregates.
generate double weighted_share = e * share
bysort industry_id: egen double s = total(weighted_share)
generate double sy0 = weighted_share * y0
generate double sx0 = weighted_share * x0
generate double sz0 = weighted_share * z0
bysort industry_id: egen double sum_sy0 = total(sy0)
bysort industry_id: egen double sum_sx0 = total(sx0)
bysort industry_id: egen double sum_sz0 = total(sz0)
generate double ybar = sum_sy0 / s
generate double xbar = sum_sx0 / s
generate double zbar = sum_sz0 / s

* Retain one observation per industry for shock-level regressions.
keep if industry_tag
count
scalar N_industries = r(N)

* Effect: shock-level weighted IV, with structural residual HC1 uncertainty.
ivregress 2sls ybar (xbar = shock) [aw=s], vce(robust)
scalar effect_est = _b[xbar]
scalar effect_se = _se[xbar]

* First stage: shock-level weighted IV with zbar instrumented by shock.
ivregress 2sls xbar (zbar = shock) [aw=s], vce(robust)
scalar first_stage_est = _b[zbar]
scalar first_stage_se = _se[zbar]

* Effective number of shocks.
generate double s_sq = s^2
quietly summarize s_sq, meanonly
scalar effective_shocks_est = 1 / r(sum)

display "ANSWER: effect estimate=" %21.12f effect_est " se=" %21.12f effect_se " n_obs=" %12.0f N_industries
display "ANSWER: first_stage estimate=" %21.12f first_stage_est " se=" %21.12f first_stage_se " n_obs=" %12.0f N_industries
display "ANSWER: effective_shocks estimate=" %21.12f effective_shocks_est " se=" %21.12f . " n_obs=" %12.0f N_industries
