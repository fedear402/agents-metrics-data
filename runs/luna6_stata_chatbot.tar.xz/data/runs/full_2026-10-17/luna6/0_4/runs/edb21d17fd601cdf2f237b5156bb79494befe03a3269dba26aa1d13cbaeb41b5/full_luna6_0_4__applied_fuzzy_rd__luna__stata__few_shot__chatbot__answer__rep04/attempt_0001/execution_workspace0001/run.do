version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

keep if abs(score) < 1
generate double weight = 1 - abs(score)
generate double right = (score >= 0)
generate double side_score = score * right
generate double right_score = score * right
generate double left_score = score * (1 - right)

* Separate local-linear fits with side-specific intercepts and slopes.
generate double intercept_right = right
generate double intercept_left = 1 - right
regress earnings intercept_right intercept_left right_score left_score [aweight=weight], noconstant
scalar reduced_form = _b[intercept_right] - _b[intercept_left]
predict double resid_earnings, residuals
matrix b_earnings = e(b)
matrix V_earnings = e(V)

regress participated intercept_right intercept_left right_score left_score [aweight=weight], noconstant
scalar first_stage = _b[intercept_right] - _b[intercept_left]
predict double resid_participated, residuals
matrix b_participated = e(b)

* HC0 covariance for both discontinuities, using the same observations and weights.
mata:
X = st_data(., ("intercept_right", "intercept_left", "right_score", "left_score"))
w = st_data(., "weight")
u_y = st_data(., "resid_earnings")
u_d = st_data(., "resid_participated")
bread = invsym(X' * (w :* X))
c = (1 \ -1 \ 0 \ 0)
loading = w :* (X * bread * c)
inf_y = loading :* u_y
inf_d = loading :* u_d
joint = (inf_y, inf_d)' * (inf_y, inf_d)
st_numscalar("var_rf", joint[1,1])
st_numscalar("var_fs", joint[2,2])
st_numscalar("cov_rf_fs", joint[1,2])
end

scalar n_obs = _N
scalar se_reduced_form = sqrt(var_rf)
scalar se_first_stage = sqrt(var_fs)
scalar treatment_effect = reduced_form / first_stage
scalar grad_rf = 1 / first_stage
scalar grad_fs = -reduced_form / (first_stage^2)
scalar se_treatment_effect = sqrt(grad_rf^2 * var_rf + grad_fs^2 * var_fs + 2 * grad_rf * grad_fs * cov_rf_fs)

display "ANSWER: treatment_effect estimate=" %21.12f treatment_effect " se=" %21.12f se_treatment_effect " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f reduced_form " se=" %21.12f se_reduced_form " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f first_stage " se=" %21.12f se_first_stage " n_obs=" %12.0f n_obs
