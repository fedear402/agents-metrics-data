clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

tsset t
arima y, arima(1,1,1) noconstant

scalar forecast_value = .
scalar forecast_se = .
scalar n_value = e(N)

predict double forecast_level, y
predict double forecast_error, mse

quietly summarize t, meanonly
local last_t = r(max)
quietly summarize forecast_level if t == `last_t', meanonly
scalar forecast_value = r(mean)
quietly summarize forecast_error if t == `last_t', meanonly
scalar forecast_se = sqrt(r(mean))

scalar lower_value = forecast_value - invnormal(0.975) * forecast_se
scalar upper_value = forecast_value + invnormal(0.975) * forecast_se

display "ANSWER: forecast estimate=" %21.12f forecast_value " se=" %21.12f forecast_se " n_obs=" %12.0f n_value
display "ANSWER: lower_95 estimate=" %21.12f lower_value " se=." " n_obs=" %12.0f n_value
display "ANSWER: upper_95 estimate=" %21.12f upper_value " se=." " n_obs=" %12.0f n_value
