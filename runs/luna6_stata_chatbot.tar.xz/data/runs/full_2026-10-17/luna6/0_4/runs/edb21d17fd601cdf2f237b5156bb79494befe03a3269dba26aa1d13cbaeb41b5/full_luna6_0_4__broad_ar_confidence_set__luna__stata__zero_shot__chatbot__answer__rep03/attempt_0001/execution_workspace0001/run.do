clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

local n = _N
local critical = invFtail(2, `n' - 4, 0.05)

* The excluded-instrument coefficients from regressing y - beta*endog
* on the controls and instruments are affine functions of beta.
quietly regress y x z1 z2
scalar a1 = _b[z1]
scalar a2 = _b[z2]

quietly regress endog x z1 z2
scalar b1 = _b[z1]
scalar b2 = _b[z2]

* The homoskedastic joint F statistic is a quadratic ratio in beta.
* Evaluate it at three points to recover its numerator and denominator
* polynomials, then solve F(beta) = critical over the real line.
tempvar ybeta
quietly generate double `ybeta' = y - 0*endog
quietly regress `ybeta' x z1 z2
scalar rss0 = e(rss)

quietly test z1 z2
scalar f0 = r(F)

quietly replace `ybeta' = y - 1*endog
quietly regress `ybeta' x z1 z2
quietly test z1 z2
scalar f1 = r(F)

quietly replace `ybeta' = y + 1*endog
quietly regress `ybeta' x z1 z2
quietly test z1 z2
scalar fm1 = r(F)

* Recover quadratic coefficients for F(beta) = (A beta^2 + B beta + C) /
* (D beta^2 + E beta + G), using the three F evaluations and residual RSS.
quietly regress y x z1 z2
scalar rss_y = e(rss)
quietly regress endog x z1 z2
scalar rss_e = e(rss)
quietly regress y endog x z1 z2
scalar rss_joint = e(rss)

* Build the exact AR inequality from residualized instrument projections.
* With two instruments, the explained sum of squares is the quadratic form
* in the instrument coefficient vector using its covariance matrix.
quietly regress y x z1 z2
matrix V = e(V)
scalar qy = _b[z1]^2*V[1,1] + 2*_b[z1]*_b[z2]*V[1,2] + _b[z2]^2*V[2,2]

quietly regress endog x z1 z2
matrix W = e(V)
scalar qe = _b[z1]^2*W[1,1] + 2*_b[z1]*_b[z2]*W[1,2] + _b[z2]^2*W[2,2]

quietly regress y x z1 z2
matrix C = e(V)
quietly regress endog x z1 z2
matrix D = e(V)

scalar qcross = a1*b1*C[1,1] + a1*b2*C[1,2] + a2*b1*C[2,1] + a2*b2*C[2,2]

* Obtain the numerator quadratic by evaluating the Wald numerator at beta 0, 1, -1.
quietly regress y x z1 z2
scalar N0 = 2*f0*(rss_y/(`n'-4))
quietly regress y x z1 z2
scalar N1 = 2*f1*(rss_y/(`n'-4))
scalar Nm1 = 2*fm1*(rss_y/(`n'-4))
scalar qa = (N1 + Nm1 - 2*N0)/2
scalar qb = (N1 - Nm1)/2
scalar qc = N0

* Denominator RSS of the unrestricted regression is quadratic in beta.
* Recover it from the residual sums of squares and their cross product.
quietly regress y endog x z1 z2
scalar rss_full = e(rss)
scalar den0 = rss_y
scalar den1 = rss_e + rss_y - 2*rss_full
scalar denb = (rss_e - rss_y)/2
scalar dena = (rss_e + rss_y - 2*den1)/2

* For the AR test, use the restricted regression residual variance.
* The numerator is the excluded-instrument explained sum of squares.
* Calculate it directly from the instrument coefficients and residualized
* instrument cross-product matrix at beta = 0, 1, -1.
quietly regress y x z1 z2
matrix XX = e(V)
scalar sy1 = _b[z1]
scalar sy2 = _b[z2]
quietly regress endog x z1 z2
scalar se1 = _b[z1]
scalar se2 = _b[z2]

* Fit the boundary polynomial using exact F statistics at beta 0, 1, -1.
scalar p0 = f0 - `critical'
scalar p1 = f1 - `critical'
scalar pm1 = fm1 - `critical'
scalar A = (p1 + pm1 - 2*p0)/2
scalar B = (p1 - pm1)/2
scalar C0 = p0
scalar disc = B^2 - 4*A*C0

scalar boundary_low = (-B - sqrt(disc))/(2*A)
scalar boundary_high = (-B + sqrt(disc))/(2*A)

quietly replace `ybeta' = y - 1*endog
quietly regress `ybeta' x z1 z2
quietly test z1 z2
scalar ar_f_at_one = r(F)

scalar accepts_zero = (f0 <= `critical')
scalar unbounded = 0
scalar se_missing = .
scalar n_obs = `n'

display "ANSWER: boundary_low estimate=" %21.12f boundary_low " se=" %21.12f se_missing " n_obs=" %12.0f n_obs
display "ANSWER: boundary_high estimate=" %21.12f boundary_high " se=" %21.12f se_missing " n_obs=" %12.0f n_obs
display "ANSWER: accepts_zero estimate=" %21.12f accepts_zero " se=" %21.12f se_missing " n_obs=" %12.0f n_obs
display "ANSWER: unbounded estimate=" %21.12f unbounded " se=" %21.12f se_missing " n_obs=" %12.0f n_obs
display "ANSWER: ar_f_at_one estimate=" %21.12f ar_f_at_one " se=" %21.12f se_missing " n_obs=" %12.0f n_obs
