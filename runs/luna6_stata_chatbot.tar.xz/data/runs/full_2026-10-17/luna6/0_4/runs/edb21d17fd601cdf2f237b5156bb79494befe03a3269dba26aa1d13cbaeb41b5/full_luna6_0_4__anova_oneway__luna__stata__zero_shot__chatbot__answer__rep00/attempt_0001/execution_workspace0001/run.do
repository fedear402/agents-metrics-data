clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

encode group, generate(group_id)
oneway y group_id

scalar F_result = e(F)
scalar df_num_result = e(df_m)
scalar df_den_result = e(df_r)
scalar p_value_result = Ftail(df_num_result, df_den_result, F_result)

display "ANSWER: F estimate=" %21.12f F_result " se=." " n_obs=" %12.0f e(N)
display "ANSWER: df_num estimate=" %21.12f df_num_result " se=." " n_obs=" %12.0f e(N)
display "ANSWER: df_den estimate=" %21.12f df_den_result " se=." " n_obs=" %12.0f e(N)
display "ANSWER: p_value estimate=" %21.12f p_value_result " se=." " n_obs=" %12.0f e(N)
