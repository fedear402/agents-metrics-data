version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

keep if abs(score) < 1
generate double rd_weight = 1 - abs(score)
generate double score_right = score * (score >= 0)
generate double score_left = score * (score < 0)
generate double right = (score >= 0)

* Separate local-linear fits on each side, using the same observations and weights.
generate double x_right = right
generate double x_right_slope = score_right
generate double x_left = 1 - right
generate double x_left_slope = score_left
matrix X = (x_right, x_right_slope, x_left, x_left_slope)

mata:
X=st_matrix("X")
w=st_data(.,"rd_weight")
Y=st_data(.,("earnings","participated"))
bread=invsym(X'*(w:*X))
b=bread*X'*(w:*Y)
res=Y-X*b
loading=w:*(X*bread*(1\-1\0\0))
influence=loading:*res
joint=influence'*influence
rf=b[1,1]-b[3,1]
fs=b[1,2]-b[3,2]
cov=joint
// Difference estimates use the right and left intercept coefficients.
contrast=(1\0\-1\0)
loading=w:*(X*bread*contrast)
influence=loading:*res
joint=influence'*influence
rfse=sqrt(joint[1,1])
fsse=sqrt(joint[2,2])
ratio=rf/fs
gradient=(1/fs\-rf/(fs^2))
ratse=sqrt(gradient'*joint*gradient)
st_numscalar("rf",rf)
st_numscalar("fs",fs)
st_numscalar("ratio",ratio)
st_numscalar("rfse",rfse)
st_numscalar("fsse",fsse)
st_numscalar("ratse",ratse)
st_numscalar("nobs",rows(X))
end

display "ANSWER: treatment_effect estimate=" %21.12f scalar(ratio) " se=" %21.12f scalar(ratse) " n_obs=" %12.0f scalar(nobs)
display "ANSWER: reduced_form estimate=" %21.12f scalar(rf) " se=" %21.12f scalar(rfse) " n_obs=" %12.0f scalar(nobs)
display "ANSWER: first_stage estimate=" %21.12f scalar(fs) " se=" %21.12f scalar(fsse) " n_obs=" %12.0f scalar(nobs)
