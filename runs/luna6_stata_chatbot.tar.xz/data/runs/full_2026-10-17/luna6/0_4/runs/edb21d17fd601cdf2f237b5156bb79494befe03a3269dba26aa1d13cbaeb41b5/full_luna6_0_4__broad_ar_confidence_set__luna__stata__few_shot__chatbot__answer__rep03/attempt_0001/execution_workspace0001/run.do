clear all
set more off
set linesize 255
set type double

import delimited using "./input.csv", clear

quietly count
scalar n = r(N)

quietly regress y x
predict double ry, residuals
quietly regress endog x
predict double rd, residuals

quietly regress y x z1 z2
predict double uy, residuals
scalar df = n - 4
scalar critical = invFtail(2, df, .05)
scalar k = 2 * critical / df

mata:
ry = st_data(., "ry")
rd = st_data(., "rd")
uy = st_data(., "uy")
k = st_numscalar("k")

// Restricted residual sum of squares at beta is ||ry - beta*rd||^2.
// Unrestricted residual sum of squares is ||uy||^2.
A = quadcross(rd, rd)
B = -2 * quadcross(ry, rd)
C = quadcross(ry, ry) - (1 + k) * quadcross(uy, uy)

disc = B^2 - 4*A*C
assert(disc > 0 & abs(A) > 1e-12)

r1 = (-B - sqrt(disc)) / (2*A)
r2 = (-B + sqrt(disc)) / (2*A)
bounds = sort((r1 \ r2), 1)

st_numscalar("boundary_low", bounds[1])
st_numscalar("boundary_high", bounds[2])
st_numscalar("accepts_zero", C <= 0)
st_numscalar("unbounded", A < 0)
end

quietly regress y endog x z1 z2
scalar ar_f_at_one = .
quietly generate double y_beta1 = y - endog
quietly regress y_beta1 x z1 z2
test z1 z2
scalar ar_f_at_one = r(F)

display "ANSWER: boundary_low estimate=" %21.12f boundary_low " se=."
display " n_obs=" %12.0f n
display "ANSWER: boundary_high estimate=" %21.12f boundary_high " se=."
display " n_obs=" %12.0f n
display "ANSWER: accepts_zero estimate=" %21.12f accepts_zero " se=."
display " n_obs=" %12.0f n
display "ANSWER: unbounded estimate=" %21.12f unbounded " se=."
display " n_obs=" %12.0f n
display "ANSWER: ar_f_at_one estimate=" %21.12f ar_f_at_one " se=."
display " n_obs=" %12.0f n
