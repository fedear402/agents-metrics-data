clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

tsset t
quietly arima y, arima(1,1,1) noconstant

quietly predict double yhat, y
quietly predict double yse, y se

quietly summarize t, meanonly
local n_obs = r(N)
local forecast_t = 251

quietly summarize yhat if t == `forecast_t', meanonly
scalar forecast_estimate = r(mean)

quietly summarize yse if t == `forecast_t', meanonly
scalar forecast_se = r(mean)

scalar lower_95_estimate = forecast_estimate - invnormal(.975) * forecast_se
scalar upper_95_estimate = forecast_estimate + invnormal(.975) * forecast_se

display "ANSWER: forecast estimate=" %21.12f forecast_estimate " se=" %21.12f forecast_se " n_obs=" %12.0f `n_obs'
display "ANSWER: lower_95 estimate=" %21.12f lower_95_estimate " se=." " n_obs=" %12.0f `n_obs'
display "ANSWER: upper_95 estimate=" %21.12f upper_95_estimate " se=." " n_obs=" %12.0f `n_obs'
