clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

local n = _N
local df2 = `n' - 4
local fcrit = invFtail(2, `df2', 0.05)

* The joint excluded-instrument test is equivalent to a quadratic
* inequality in beta. Recover its coefficients from tests at 0, 1, and -1.
quietly regress y endog x z1 z2
quietly test z1 z2
scalar q0 = r(F) * 2

quietly generate double yb = y - endog
quietly regress yb x z1 z2
quietly test z1 z2
scalar q1 = r(F) * 2

quietly replace yb = y + endog
quietly regress yb x z1 z2
quietly test z1 z2
scalar qm1 = r(F) * 2

scalar a = (q1 + qm1 - 2*q0) / 2
scalar b = (q1 - qm1) / 2
scalar c = q0
scalar disc = b^2 - 4*a*(c - 2*fcrit)

scalar root1 = (-b - sqrt(disc)) / (2*a)
scalar root2 = (-b + sqrt(disc)) / (2*a)
scalar boundary_low = min(root1, root2)
scalar boundary_high = max(root1, root2)

quietly regress y endog x z1 z2
quietly test z1 z2
scalar ar_f_at_one = .
quietly replace yb = y - endog
quietly regress yb x z1 z2
quietly test z1 z2
scalar ar_f_at_one = r(F)

scalar accepts_zero = (q0 <= 2*fcrit)
scalar unbounded = 0
scalar missing_se = .

display "ANSWER: boundary_low estimate=" %21.12f boundary_low " se=" %21.12f missing_se " n_obs=" %12.0f `n'
display "ANSWER: boundary_high estimate=" %21.12f boundary_high " se=" %21.12f missing_se " n_obs=" %12.0f `n'
display "ANSWER: accepts_zero estimate=" %21.12f accepts_zero " se=" %21.12f missing_se " n_obs=" %12.0f `n'
display "ANSWER: unbounded estimate=" %21.12f unbounded " se=" %21.12f missing_se " n_obs=" %12.0f `n'
display "ANSWER: ar_f_at_one estimate=" %21.12f ar_f_at_one " se=" %21.12f missing_se " n_obs=" %12.0f `n'
