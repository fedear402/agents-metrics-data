version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

* Keep one observation per region for regional variables and weights.
preserve
    keep region_id region_weight x y
    duplicates drop region_id, force

    quietly summarize region_weight, meanonly
    scalar weight_total = r(sum)
    generate double e = region_weight / weight_total

    quietly summarize x [aw=e]
    scalar mean_x = r(mean)
    quietly summarize y [aw=e]
    scalar mean_y = r(mean)

    tempfile regions
    save `regions'
restore

* Construct the regional shift-share instrument and merge regional weights.
generate double share_shock = share * shock
collapse (sum) z=share_shock, by(region_id)
merge 1:1 region_id using `regions', assert(match) nogen

quietly summarize z [aw=e]
scalar mean_z = r(mean)

generate double x0 = x - mean_x
generate double y0 = y - mean_y
generate double z0 = z - mean_z

* Store regional 2SLS and first-stage slopes for comparison.
quietly ivregress 2sls y (x = z) [aw=e]
scalar regional_effect = _b[x]
quietly regress x z [aw=e]
scalar regional_first_stage = _b[z]

tempfile centered_regions
save `centered_regions'

* Aggregate centered variables to industry exposure cells.
use "./input.csv", clear
merge m:1 region_id using `centered_regions', assert(match) nogen
generate double weighted_share = e * share

collapse (sum) s=weighted_share ///
    (sum) y_num=weighted_share_y0 ///
    (sum) x_num=weighted_share_x0 ///
    (sum) z_num=weighted_share_z0, by(industry_id shock)

generate double ybar = y_num / s
generate double xbar = x_num / s
generate double zbar = z_num / s

quietly count
scalar industry_count = r(N)
scalar effective_shocks = 1 / sum(s^2)

* Shock-level IV effect. The structural residual is used for HC1 inference.
quietly ivregress 2sls ybar (xbar = shock) [aw=s]
scalar effect_estimate = _b[xbar]
predict double effect_resid, residuals
generate double effect_score = s * effect_resid
quietly summarize effect_score^2, meanonly
scalar effect_meat = r(sum)
scalar effect_se = sqrt((industry_count / (industry_count - 2)) * ///
    effect_meat * (_se[xbar] / sqrt(effect_meat))^2)

* Shock-level IV relevance, with zbar as the endogenous regressor.
quietly ivregress 2sls xbar (zbar = shock) [aw=s]
scalar first_stage_estimate = _b[zbar]
predict double first_stage_resid, residuals
generate double first_stage_score = s * first_stage_resid
quietly summarize first_stage_score^2, meanonly
scalar first_stage_meat = r(sum)
scalar first_stage_se = sqrt((industry_count / (industry_count - 2)) * ///
    first_stage_meat * (_se[zbar] / sqrt(first_stage_meat))^2)

display "ANSWER: effect estimate=" %21.12f effect_estimate ///
    " se=" %21.12f effect_se " n_obs=" %12.0f industry_count
display "ANSWER: first_stage estimate=" %21.12f first_stage_estimate ///
    " se=" %21.12f first_stage_se " n_obs=" %12.0f industry_count
display "ANSWER: effective_shocks estimate=" %21.12f effective_shocks ///
    " se=. n_obs=" %12.0f industry_count
