clear all
set more off
set type double

import delimited "households.csv", clear
keep if recipient == 0
count
local n_obs = r(N)

generate double dose_ineligible = dose * (1 - eligible)
generate double dose_eligible = dose * eligible
generate double exog_ineligible = 1 - eligible
generate double exog_eligible = eligible
generate double baseline_ineligible = baseline * (1 - eligible)
generate double baseline_eligible = baseline * eligible
generate double instrument_ineligible = instrument * (1 - eligible)
generate double instrument_eligible = instrument * eligible

ivregress 2sls outcome ///
    exog_ineligible exog_eligible baseline_ineligible baseline_eligible ///
    (dose_ineligible dose_eligible = instrument_ineligible instrument_eligible) ///
    [aw=weight], noconstant

scalar ineligible_effect = _b[dose_ineligible] * ///
    (sum(weight * dose * (1 - eligible)) / sum(weight * (1 - eligible)))
scalar eligible_nonrecipient_effect = _b[dose_eligible] * ///
    (sum(weight * dose * eligible) / sum(weight * eligible))

import delimited "census.csv", clear
summarize nonrecipient_population if eligible == 0, meanonly
scalar n0 = r(mean)
summarize nonrecipient_population if eligible == 1, meanonly
scalar n1 = r(mean)
scalar population_effect = ///
    (ineligible_effect * n0 + eligible_nonrecipient_effect * n1) / (n0 + n1)

display "ANSWER: ineligible_effect estimate=" %24.16g ineligible_effect ///
    " se=NA n_obs=" %12.0f `n_obs'
display "ANSWER: eligible_nonrecipient_effect estimate=" %24.16g eligible_nonrecipient_effect ///
    " se=NA n_obs=" %12.0f `n_obs'
display "ANSWER: population_effect estimate=" %24.16g population_effect ///
    " se=NA n_obs=" %12.0f `n_obs'
