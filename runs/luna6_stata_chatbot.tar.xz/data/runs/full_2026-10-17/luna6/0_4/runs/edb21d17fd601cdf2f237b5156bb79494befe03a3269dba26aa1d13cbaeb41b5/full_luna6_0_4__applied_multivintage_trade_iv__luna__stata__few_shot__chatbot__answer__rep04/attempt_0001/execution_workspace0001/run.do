clear all
set more off
set type double

import delimited using "crosswalk.csv", clear
tempfile crosswalk
save `crosswalk'

import delimited using "trade.csv", clear
merge m:1 code using `crosswalk', assert(match) nogen
tempfile trade
save `trade'

import delimited using "areas.csv", clear
keep if vintage == "base"
rename total_employment base_total
rename population base_population
tempfile baseareas
save `baseareas'

import delimited using "areas.csv", clear
keep if vintage == "early"
rename total_employment early_total
keep area period early_total
tempfile earlyareas
save `earlyareas'

use `baseareas', clear
merge 1:1 area period using `earlyareas', assert(match) nogen
tempfile area_periods
save `area_periods'

import delimited using "employment.csv", clear
keep if vintage == "base"
rename employment base_emp
tempfile baseemp
save `baseemp'

import delimited using "employment.csv", clear
keep if vintage == "early"
rename employment early_emp
keep area period industry early_emp
merge 1:1 area period industry using `baseemp', nogen
replace base_emp = 0 if missing(base_emp)
replace early_emp = 0 if missing(early_emp)
tempfile employment
save `employment'

use `employment', clear
collapse (sum) national_base=base_emp national_early=early_emp, by(period industry)
tempfile national
save `national'

use `employment', clear
merge m:1 period industry using `national', assert(match) nogen
merge m:1 industry using `crosswalk', keep(master match) nogen
drop code

* Join each industry to its period-specific trade change.
merge m:1 period industry using `trade', assert(match) nogen
gen double base_component = (base_emp/base_total)*(us_change/national_base)/(price_index/100)/1000*(10/years)
