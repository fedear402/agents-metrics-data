clear all
set more off
set varabbrev off

import delimited using "crosswalk.csv", clear
isid code
tempfile crosswalk
save `crosswalk'

import delimited using "trade.csv", clear
isid period code
merge m:1 code using `crosswalk', assert(match) nogen
isid period industry
tempfile trade
save `trade'

import delimited using "areas.csv", clear
keep if vintage == "base"
isid area period
tempfile baseareas
save `baseareas'

import delimited using "areas.csv", clear
keep if vintage == "early"
isid area period
rename total_employment early_total
tempfile earlyareas
save `earlyareas'

use `baseareas', clear
merge 1:1 area period using `earlyareas', assert(match) nogen
tempfile areapairs
save `areapairs'

import delimited using "employment.csv", clear
collapse (sum) employment, by(area period vintage industry)
reshape wide employment, i(area period industry) j(vintage) string
rename employmentbase base_emp
rename employmentearly early_emp
tempfile empwide
save `empwide'

use `areapairs', clear
keep area period total_employment population
cross using `trade'
merge m:1 area period industry using `empwide', nogen
replace base_emp = 0 if missing(base_emp)
replace early_emp = 0 if missing(early_emp)

bysort period industry: egen double national_base = total(base_emp)
bysort period industry: egen double national_early = total(early_emp)

gen double x_component = (base_emp / total_employment) * ///
    (us_change / national_base) / (price_index / 100) / 1000 * (10 / years)
gen double z_component = (early_emp / early_total) * ///
    (other_change / national_early) / (price_index / 100) / 1000 * (10 / years)

collapse (sum) x=x_component z=z_component, by(area period)
tempfile exposures
save `exposures'

import delimited using "outcomes.csv", clear
isid area period
merge 1:1 area period using `exposures', assert(match) nogen
merge 1:1 area period using `baseareas', keepusing(population) assert(match) nogen

gen byte period1 = period == 1
ivregress 2sls change_pp period1 control (x = z) [aweight=population], vce(robust)
scalar iv_slope = _b[x]

quietly summarize x if area == 0 & period == 0, meanonly
scalar exposure_area0_period0 = r(mean)
quietly summarize x if area == 0 & period == 1, meanonly
scalar exposure_area0_period1 = r(mean)
quietly summarize z if area == 0 & period == 0, meanonly
scalar instrument_area0_period0 = r(mean)

local n = e(N)
display "ANSWER: iv_slope estimate=" %24.16g scalar(iv_slope) " se=NA n_obs=`n'"
display "ANSWER: exposure_area0_period0 estimate=" %24.16g scalar(exposure_area0_period0) " se=NA n_obs=`n'"
display "ANSWER: exposure_area0_period1 estimate=" %24.16g scalar(exposure_area0_period1) " se=NA n_obs=`n'"
display "ANSWER: instrument_area0_period0 estimate=" %24.16g scalar(instrument_area0_period0) " se=NA n_obs=`n'"
