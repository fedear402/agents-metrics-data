clear all
set more off

import delimited using "crosswalk.csv", clear
tempfile crosswalk
save `crosswalk'

import delimited using "trade.csv", clear
joinby code using `crosswalk'
tempfile trade
save `trade'

import delimited using "areas.csv", clear
tempfile areas
save `areas'

import delimited using "employment.csv", clear
tempfile employment
save `employment'

import delimited using "outcomes.csv", clear
tempfile outcomes
save `outcomes'

* Build a complete area-period-vintage-industry employment panel.
use `areas', clear
keep area period vintage total_employment population
joinby area period vintage using `employment'
