clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

* Parse and sort by date.
capture confirm numeric variable date
if _rc {
    gen double _date = daily(date, "YMD")
    format _date %td
    drop date
    rename _date date
}
sort date
tsset, clear

* Define consecutive trading-observation time.
gen long obs_time = _n
tsset obs_time

gen double dln_vix = ln(vix) - ln(L.vix)
gen double ln_sales = ln(sales)

* Include observations with all 15 lagged volatility changes.
regress ln_sales L(1/15).dln_vix

scalar n_obs = e(N)
scalar correction = n_obs / (n_obs - 16)

* Newey-West covariance with Bartlett weights and maximum lag 15.
matrix V = e(V)
forvalues j = 1/15 {
    scalar weight = 1 - `j' / 16
    matrix G = J(16, 16, 0)
    forvalues t = `=`j'+1'/`=_N' {
        if e(sample)[`t'] & e(sample)[`=`t'-`j''] {
            matrix G = G + weight * (e(sample)[`t'] * e(sample)[`=`t'-`j''])
        }
    }
}
