clear all
set more off
set linesize 255
set type double

import delimited using "./input.csv", clear
local n = _N
local df = `n' - 4
local q = 2

quietly regress y endog x z1 z2
scalar critical = invFtail(`q', `df', .05)
scalar k = `q' * critical / `df'

tempvar ry rd uy ud
quietly regress y endog x
predict double `ry', residuals
quietly regress endog x
predict double `rd', residuals
quietly regress y endog x z1 z2
predict double `uy', residuals
quietly regress endog x z1 z2
predict double `ud', residuals

mata:
ry = st_data(., "`ry'")
rd = st_data(., "`rd'")
uy = st_data(., "`uy'")
ud = st_data(., "`ud'")
k = st_numscalar("k")

A = quadcross(rd,rd) - (1+k)*quadcross(ud,ud)
B = -2*(quadcross(ry,rd) - (1+k)*quadcross(uy,ud))
C = quadcross(ry,ry) - (1+k)*quadcross(uy,uy)

D = B^2 - 4*A*C
assert(abs(A)>1e-12 & D>0)

r1 = (-B-sqrt(D))/(2*A)
r2 = (-B+sqrt(D))/(2*A)
low = min((r1,r2))
high = max((r1,r2))

st_numscalar("boundary_low", low)
st_numscalar("boundary_high", high)
st_numscalar("accepts_zero", C<=0)
st_numscalar("unbounded", A<0)
end

quietly generate double __ar_resid = y - endog
quietly regress __ar_resid x z1 z2
scalar ssr_u = e(rss)
quietly regress __ar_resid x
scalar ssr_r = e(rss)
scalar ar_f_at_one = ((ssr_r-ssr_u)/`q')/(ssr_u/`df')

scalar missing_se = .
scalar n_obs = `n'

display "ANSWER: boundary_low estimate=" %21.12f boundary_low " se=" %21.12f missing_se " n_obs=" %12.0f n_obs
display "ANSWER: boundary_high estimate=" %21.12f boundary_high " se=" %21.12f missing_se " n_obs=" %12.0f n_obs
display "ANSWER: accepts_zero estimate=" %21.12f accepts_zero " se=" %21.12f missing_se " n_obs=" %12.0f n_obs
display "ANSWER: unbounded estimate=" %21.12f unbounded " se=" %21.12f missing_se " n_obs=" %12.0f n_obs
display "ANSWER: ar_f_at_one estimate=" %21.12f ar_f_at_one " se=" %21.12f missing_se " n_obs=" %12.0f n_obs
