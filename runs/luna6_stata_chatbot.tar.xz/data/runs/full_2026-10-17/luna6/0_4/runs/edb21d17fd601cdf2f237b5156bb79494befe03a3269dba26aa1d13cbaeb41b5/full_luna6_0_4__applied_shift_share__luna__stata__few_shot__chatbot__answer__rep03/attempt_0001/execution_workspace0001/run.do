version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

* Keep one row per region for regional variables and weights.
preserve
keep region_id region_weight x y
bysort region_id: keep if _n == 1
egen double total_weight = total(region_weight)
generate double e = region_weight / total_weight

* Save normalized regional data for use after industry aggregation.
tempfile regions
save `regions'
restore

* Compute each region's shift-share instrument.
generate double share_shock = share * shock
collapse (sum) z=share_shock, by(region_id)
merge 1:1 region_id using `regions', assert(match) nogen

* Weighted regional means and residualized variables.
quietly summarize y [aw=e], meanonly
scalar mean_y = r(mean)
quietly summarize x [aw=e], meanonly
scalar mean_x = r(mean)
quietly summarize z [aw=e], meanonly
scalar mean_z = r(mean)

generate double y0 = y - mean_y
generate double x0 = x - mean_x
generate double z0 = z - mean_z

tempfile regional_residuals
save `regional_residuals'

* Aggregate residuals by industry using exposure masses.
use "./input.csv", clear
merge m:1 region_id using `regional_residuals', keep(match) nogen
generate double weighted_share = e * share
generate double weighted_share_y0 = weighted_share * y0
generate double weighted_share_x0 = weighted_share * x0
generate double weighted_share_z0 = weighted_share * z0

collapse (sum) s=weighted_share sum_y=weighted_share_y0 ///
    sum_x=weighted_share_x0 sum_z=weighted_share_z0 ///
    (mean) shock, by(industry_id)
generate double ybar = sum_y / s
generate double xbar = sum_x / s
generate double zbar = sum_z / s

quietly count
scalar N_industries = r(N)
scalar effective_shocks = 1 / sum(s^2)

* Shock-level IV for the regional 2SLS effect.
ivregress 2sls ybar (xbar = shock) [aw=s]
scalar effect_estimate = _b[xbar]
scalar effect_se = _se[xbar]

* Shock-level IV for instrument relevance.
ivregress 2sls xbar (zbar = shock) [aw=s]
scalar first_stage_estimate = _b[zbar]
scalar first_stage_se = _se[zbar]

display "ANSWER: effect estimate=" %21.12f effect_estimate ///
    " se=" %21.12f effect_se " n_obs=" %12.0f N_industries
display "ANSWER: first_stage estimate=" %21.12f first_stage_estimate ///
    " se=" %21.12f first_stage_se " n_obs=" %12.0f N_industries
display "ANSWER: effective_shocks estimate=" %21.12f effective_shocks ///
    " se=." " n_obs=" %12.0f N_industries
