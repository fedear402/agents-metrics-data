clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

* Keep one row per region for regional variables and weights.
preserve
    keep region_id region_weight x y
    bysort region_id: keep if _n == 1
    egen double total_weight = total(region_weight)
    generate double e = region_weight / total_weight
    quietly summarize e
    scalar n_regions = r(N)

    quietly summarize y [aw=e]
    scalar mean_y = r(mean)
    quietly summarize x [aw=e]
    scalar mean_x = r(mean)
restore

* Construct regional instrument and retain one record per region.
generate double share_shock = share * shock
collapse (sum) z=share_shock, by(region_id)
tempfile regional_z
save `regional_z'

* Rebuild the region-level analysis dataset and merge the instrument.
import delimited using "./input.csv", clear
preserve
    keep region_id region_weight x y
    bysort region_id: keep if _n == 1
    egen double total_weight = total(region_weight)
    generate double e = region_weight / total_weight
    merge 1:1 region_id using `regional_z', nogen

    quietly summarize y [aw=e]
    scalar mean_y = r(mean)
    quietly summarize x [aw=e]
    scalar mean_x = r(mean)
    quietly summarize z [aw=e]
    scalar mean_z = r(mean)

    generate double y0 = y - mean_y
    generate double x0 = x - mean_x
    generate double z0 = z - mean_z

    tempfile region_residuals
    save `region_residuals'
restore

* Aggregate residuals to industry level using exposure weights.
import delimited using "./input.csv", clear
merge m:1 region_id using `region_residuals', keepusing(e y0 x0 z0) nogen
generate double exposure = e * share
collapse (sum) s=exposure sy=exposure*y0 sx=exposure*x0 sz=exposure*z0, by(industry_id shock)
generate double ybar = sy / s
generate double xbar = sx / s
generate double zbar = sz / s
count
scalar n_industries = r(N)
scalar effective_shocks = 1 / sum(s^2)

* Structural shock-level IV regression.
ivregress 2sls ybar (xbar = shock) [aw=s], vce(robust)
scalar effect = _b[xbar]
scalar effect_se = _se[xbar] * sqrt(n_industries / (n_industries - 2))

* First-stage slope and exposure-robust shock-level IV standard error.
ivregress 2sls xbar (zbar = shock) [aw=s], vce(robust)
scalar first_stage = _b[zbar]
scalar first_stage_se = _se[zbar] * sqrt(n_industries / (n_industries - 2))

display "ANSWER: effect estimate=" %21.12f effect " se=" %21.12f effect_se " n_obs=" %12.0f n_industries
display "ANSWER: first_stage estimate=" %21.12f first_stage " se=" %21.12f first_stage_se " n_obs=" %12.0f n_industries
display "ANSWER: effective_shocks estimate=" %21.12f effective_shocks " se=" %21.12f . " n_obs=" %12.0f n_industries
