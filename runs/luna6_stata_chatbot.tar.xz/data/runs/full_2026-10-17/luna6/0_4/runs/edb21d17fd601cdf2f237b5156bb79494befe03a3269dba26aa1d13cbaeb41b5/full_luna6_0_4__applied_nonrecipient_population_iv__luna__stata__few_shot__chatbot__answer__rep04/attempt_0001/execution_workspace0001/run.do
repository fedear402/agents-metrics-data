clear all
set more off
set type double

import delimited using "households.csv", clear
keep if recipient == 0
count
local n_obs = r(N)

generate double dose_ineligible = dose * (1 - eligible)
generate double dose_eligible = dose * eligible
generate double ineligible = 1 - eligible
generate double baseline_ineligible = baseline * ineligible
generate double baseline_eligible = baseline * eligible
generate double instrument_ineligible = instrument * ineligible
generate double instrument_eligible = instrument * eligible

ivregress 2sls outcome ineligible eligible baseline_ineligible baseline_eligible ///
    (dose_ineligible dose_eligible = instrument_ineligible instrument_eligible) ///
    [aw=weight], noconstant

scalar slope0 = _b[dose_ineligible]
scalar slope1 = _b[dose_eligible]

summarize dose [aw=weight] if eligible == 0, meanonly
scalar ineligible_effect = slope0 * r(mean)

summarize dose [aw=weight] if eligible == 1, meanonly
scalar eligible_nonrecipient_effect = slope1 * r(mean)

import delimited using "census.csv", clear
summarize nonrecipient_population if eligible == 0, meanonly
scalar n0 = r(mean)
summarize nonrecipient_population if eligible == 1, meanonly
scalar n1 = r(mean)

scalar population_effect = ///
    (ineligible_effect * n0 + eligible_nonrecipient_effect * n1) / (n0 + n1)

display "ANSWER: ineligible_effect estimate=" %24.16g ineligible_effect " se=NA n_obs=" %12.0f `n_obs'
display "ANSWER: eligible_nonrecipient_effect estimate=" %24.16g eligible_nonrecipient_effect " se=NA n_obs=" %12.0f `n_obs'
display "ANSWER: population_effect estimate=" %24.16g population_effect " se=NA n_obs=" %12.0f `n_obs'
