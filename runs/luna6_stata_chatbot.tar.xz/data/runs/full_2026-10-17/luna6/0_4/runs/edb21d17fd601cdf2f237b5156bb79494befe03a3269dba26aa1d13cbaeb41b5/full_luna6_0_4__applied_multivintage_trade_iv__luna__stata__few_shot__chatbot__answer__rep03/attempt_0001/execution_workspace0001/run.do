clear all
set more off
set type double

import delimited using "crosswalk.csv", clear
tempfile crosswalk
save `crosswalk'

import delimited using "trade.csv", clear
merge m:1 code using `crosswalk', keep(match) nogen
tempfile trade
save `trade'

import delimited using "areas.csv", clear
keep if vintage == "base"
rename total_employment base_total
rename population base_population
tempfile base_areas
save `base_areas'

import delimited using "areas.csv", clear
keep if vintage == "early"
rename total_employment early_total
keep area period early_total
tempfile early_areas
save `early_areas'

use `base_areas', clear
merge 1:1 area period using `early_areas', nogen
tempfile area_totals
save `area_totals'

import delimited using "employment.csv", clear
keep if inlist(vintage, "base", "early")
reshape wide employment, i(area period industry) j(vintage) string
foreach v in base early {
    replace employment`v' = 0 if missing(employment`v')
}
tempfile emp_wide
save `emp_wide'

use `emp_wide', clear
collapse (sum) employmentbase employmentearly, by(area period industry)
tempfile emp
save `emp'

use `emp', clear
collapse (sum) national_base=employmentbase national_early=employmentearly, by(period industry)
tempfile national
save `national'

use `emp', clear
merge m:1 period industry using `national', nogen
merge m:1 industry using `crosswalk', keep(master match) nogen
