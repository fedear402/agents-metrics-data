clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

keep if abs(score) < 1
generate double weight = 1 - abs(score)
generate double right = score >= 0
generate double x_right = score * right
generate double x_left = score * (1 - right)

quietly regress earnings right x_right x_left [aweight=weight], noconstant
scalar reduced_form = _b[right]
scalar var_rf = _se[right]^2

quietly regress participated right x_right x_left [aweight=weight], noconstant
scalar first_stage = _b[right]
scalar var_fs = _se[right]^2

* Joint HC0 covariance from the same observations and weights.
generate double residual_y = .
quietly regress earnings right x_right x_left [aweight=weight], noconstant
predict double residual_y if e(sample), residuals
matrix b_y = e(b)
matrix V_y = e(V)

quietly regress participated right x_right x_left [aweight=weight], noconstant
predict double residual_d if e(sample), residuals
matrix b_d = e(b)
matrix V_d = e(V)

* Compute the cross-equation HC0 covariance for the right-intercept estimates.
generate double score_rf = weight * right * residual_y
generate double score_fs = weight * right * residual_d
quietly summarize score_rf, meanonly
scalar sum_rf = r(sum)
quietly summarize score_fs, meanonly
scalar sum_fs = r(sum)

* Bread element for the right-intercept coefficient in each weighted regression.
matrix X = (right, x_right, x_left)
matrix W = diag(weight)
matrix bread = invsym(X' * W * X)
scalar bread_rf = bread[1,1]
scalar bread_fs = bread[1,1]

generate double cross_score = score_rf * score_fs
quietly summarize cross_score, meanonly
scalar cov_rf_fs = bread_rf * bread_fs * r(sum)

scalar n_obs = _N
scalar se_rf = sqrt(var_rf)
scalar se_fs = sqrt(var_fs)
scalar treatment_effect = reduced_form / first_stage
scalar se_te = .
if first_stage != 0 {
    scalar var_te = (var_rf / first_stage^2) ///
        + (reduced_form^2 * var_fs / first_stage^4) ///
        - (2 * reduced_form * cov_rf_fs / first_stage^3)
    if var_te >= 0 scalar se_te = sqrt(var_te)
}

display "ANSWER: treatment_effect estimate=" %21.12f treatment_effect " se=" %21.12f se_te " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f reduced_form " se=" %21.12f se_rf " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f first_stage " se=" %21.12f se_fs " n_obs=" %12.0f n_obs
