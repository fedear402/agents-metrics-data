clear all
set more off
set type double

import delimited using "households.csv", clear
keep if recipient == 0
local n_obs = _N

generate double dose_ineligible = dose * (1 - eligible)
generate double dose_eligible = dose * eligible
generate double ineligible = 1 - eligible
generate double baseline_ineligible = baseline * ineligible
generate double baseline_eligible = baseline * eligible
generate double instrument_ineligible = instrument * ineligible
generate double instrument_eligible = instrument * eligible

ivregress 2sls outcome ineligible eligible baseline_ineligible baseline_eligible ///
    (dose_ineligible dose_eligible = instrument_ineligible instrument_eligible) ///
    [aw=weight]

quietly summarize dose [aw=weight] if eligible == 0, meanonly
scalar ineligible_effect = _b[dose_ineligible] * r(mean)

quietly summarize dose [aw=weight] if eligible == 1, meanonly
scalar eligible_nonrecipient_effect = _b[dose_eligible] * r(mean)

preserve
import delimited using "census.csv", clear
quietly summarize nonrecipient_population if eligible == 0, meanonly
scalar n0 = r(mean)
quietly summarize nonrecipient_population if eligible == 1, meanonly
scalar n1 = r(mean)
restore

scalar population_effect = ///
    (ineligible_effect * n0 + eligible_nonrecipient_effect * n1) / (n0 + n1)

display "ANSWER: ineligible_effect estimate=" %24.16g ineligible_effect ///
    " se=NA n_obs=" %9.0f `n_obs'
display "ANSWER: eligible_nonrecipient_effect estimate=" %24.16g eligible_nonrecipient_effect ///
    " se=NA n_obs=" %9.0f `n_obs'
display "ANSWER: population_effect estimate=" %24.16g population_effect ///
    " se=NA n_obs=" %9.0f `n_obs'
