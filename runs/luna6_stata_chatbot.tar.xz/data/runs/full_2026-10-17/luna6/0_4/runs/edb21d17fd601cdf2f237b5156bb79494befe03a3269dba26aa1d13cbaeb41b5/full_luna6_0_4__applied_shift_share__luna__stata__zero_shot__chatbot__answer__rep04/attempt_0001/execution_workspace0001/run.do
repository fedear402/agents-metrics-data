clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

* Keep one observation per region for regional variables and weights.
preserve
    keep region_id region_weight x y
    bysort region_id: keep if _n == 1
    egen double total_weight = total(region_weight)
    gen double e = region_weight / total_weight

    quietly summarize e
    scalar sum_e = r(sum)

    quietly summarize y [aw=e]
    scalar mean_y = r(mean)
    quietly summarize x [aw=e]
    scalar mean_x = r(mean)

    tempfile regions
    save `regions'
restore

* Construct regional shift-share exposure using all region-industry rows.
gen double share_shock = share * shock
collapse (sum) z=share_shock, by(region_id)
merge 1:1 region_id using `regions', nogen

quietly summarize z [aw=e]
scalar mean_z = r(mean)

gen double y0 = y - mean_y
gen double x0 = x - mean_x
gen double z0 = z - mean_z

tempfile regional_residuals
save `regional_residuals'

* Form industry exposure shares and shock-level aggregates.
use "./input.csv", clear
merge m:1 region_id using `regional_residuals', nogen keep(match)
gen double weighted_share = e * share
gen double weighted_y0 = weighted_share * y0
gen double weighted_x0 = weighted_share * x0
gen double weighted_z0 = weighted_share * z0

collapse (sum) s=weighted_share y_num=weighted_y0 x_num=weighted_x0 z_num=weighted_z0, by(industry_id shock)
gen double ybar = y_num / s
gen double xbar = x_num / s
gen double zbar = z_num / s

count
scalar N_industries = r(N)
scalar effective_shocks = 1 / sum(s^2)

* Main effect: shock-level weighted IV with HC1 standard error.
ivregress 2sls ybar (xbar = shock) [aw=s], vce(robust)
scalar effect_estimate = _b[xbar]
scalar effect_se = _se[xbar]

* First stage: shock-level IV of xbar on zbar, instrumented by shock.
ivregress 2sls xbar (zbar = shock) [aw=s], vce(robust)
scalar first_stage_estimate = _b[zbar]
scalar first_stage_se = _se[zbar]

display "ANSWER: effect estimate=" %21.12f effect_estimate " se=" %21.12f effect_se " n_obs=" %12.0f N_industries
display "ANSWER: first_stage estimate=" %21.12f first_stage_estimate " se=" %21.12f first_stage_se " n_obs=" %12.0f N_industries
display "ANSWER: effective_shocks estimate=" %21.12f effective_shocks " se=." " n_obs=" %12.0f N_industries
