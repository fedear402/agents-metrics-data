clear all
set more off
set linesize 255

import delimited using "./input.csv", clear
tsset t

arima y, arima(1,1,1) noconstant

predict double forecast_level, y
predict double forecast_se, mse

quietly summarize t, meanonly
local last_t = r(max)
local target_t = 251
local forecast_value = forecast_level[_N]
local forecast_std = sqrt(forecast_se[_N])
local lower_value = `forecast_value' - invnormal(0.975)*`forecast_std'
local upper_value = `forecast_value' + invnormal(0.975)*`forecast_std'
local n = e(N)

display "ANSWER: forecast estimate=" %21.12f `forecast_value' " se=" %21.12f `forecast_std' " n_obs=" %12.0f `n'
display "ANSWER: lower_95 estimate=" %21.12f `lower_value' " se=." " n_obs=" %12.0f `n'
display "ANSWER: upper_95 estimate=" %21.12f `upper_value' " se=." " n_obs=" %12.0f `n'
