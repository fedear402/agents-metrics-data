clear all
set more off

* Read trade data and attach each trade code to its industry.
import delimited using "trade.csv", clear
merge m:1 code using "crosswalk.csv", keep(match) nogen
tempfile trade_industry
save `trade_industry'

* Aggregate nominal trade changes to industry-period values.
collapse (sum) us_change other_change (first) price_index years, by(period industry)
tempfile trade_by_industry
save `trade_by_industry'

* Read area totals and retain base-vintage weights and employment denominators.
import delimited using "areas.csv", clear
keep if vintage == "base"
keep area period total_employment population
tempfile base_areas
save `base_areas'

* Prepare area-industry employment for both vintages.
import delimited using "employment.csv", clear
merge m:1 area period using `base_areas', keep(match) nogen
reshape wide employment, i(area period industry) j(vintage) string

* Fill omitted area-industry cells with zero using the complete industry list.
tempfile observed_employment
save `observed_employment'

use `trade_by_industry', clear
keep industry
duplicates drop
tempfile industries
save `industries'

use `base_areas', clear
cross using `industries'
merge 1:1 area period industry using `observed_employment', nogen
replace employmentbase = 0 if missing(employmentbase)
replace employmentearly = 0 if missing(employmentearly)

* Compute national employment denominators by period, vintage, and industry.
bysort period industry: egen national_base = total(employmentbase)
bysort period industry: egen national_early = total(employmentearly)

merge m:1 period industry using `trade_by_industry', keep(match) nogen

* Sum industry contributions to the area-period exposure and instrument.
gen contribution_x = (employmentbase / total_employment) ///
    * (us_change / national_base) / (price_index / 100) / 1000 ///
    * (10 / years)
gen contribution_z = (employmentearly / total_employment) ///
    * (other_change / national_early) / (price_index / 100) / 1000 ///
    * (10 / years)

collapse (sum) x=contribution_x z=contribution_z, by(area period)
merge 1:1 area period using `base_areas', keep(match) nogen

* Add outcomes and estimate weighted 2SLS with all exogenous variables included.
tempfile exposures
save `exposures'
import delimited using "outcomes.csv", clear
merge 1:1 area period using `exposures', keep(match) nogen

ivregress 2sls change_pp period control (x = z) [aw=population]
scalar iv_slope = _b[x]

quietly summarize x if area == 0 & period == 0, meanonly
scalar exposure_area0_period0 = r(mean)
quietly summarize x if area == 0 & period == 1, meanonly
scalar exposure_area0_period1 = r(mean)
quietly summarize z if area == 0 & period == 0, meanonly
scalar instrument_area0_period0 = r(mean)

display "ANSWER: iv_slope estimate=" %21.15g scalar(iv_slope) " se=NA n_obs=72"
display "ANSWER: exposure_area0_period0 estimate=" %21.15g scalar(exposure_area0_period0) " se=NA n_obs=72"
display "ANSWER: exposure_area0_period1 estimate=" %21.15g scalar(exposure_area0_period1) " se=NA n_obs=72"
display "ANSWER: instrument_area0_period0 estimate=" %21.15g scalar(instrument_area0_period0) " se=NA n_obs=72"
