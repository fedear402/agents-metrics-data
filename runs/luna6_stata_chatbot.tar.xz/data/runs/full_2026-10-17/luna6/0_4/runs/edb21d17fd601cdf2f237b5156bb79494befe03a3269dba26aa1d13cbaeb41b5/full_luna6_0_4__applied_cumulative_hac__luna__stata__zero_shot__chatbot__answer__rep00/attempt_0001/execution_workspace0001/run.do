clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

* Parse dates and sort observations in trading order.
capture confirm numeric variable date
if _rc {
    gen double _parsed_date = daily(date, "YMD")
    replace _parsed_date = date(date, "YMD") if missing(_parsed_date)
    format _parsed_date %td
    drop date
    rename _parsed_date date
}
sort date

gen double dlnvix = ln(vix) - ln(vix[_n-1])
gen double lnsales = ln(sales)

forvalues j = 1/15 {
    gen double lag_`j' = dlnvix[_n-`j']
}

regress lnsales lag_1-lag_15
scalar n_obs = e(N)
scalar cumulative_response = 0
forvalues j = 1/15 {
    scalar cumulative_response = cumulative_response + _b[lag_`j']
}

* Newey-West covariance with Bartlett weights and finite-sample adjustment.
matrix X = e(b)'
predict double uhat if e(sample), residuals
gen double touse = e(sample)
gen double score0 = .
forvalues j = 1/15 {
    gen double score_`j' = .
}
quietly count if touse
scalar n = r(N)
matrix S = J(16,16,0)

* Build per-observation score vectors: regressor times residual.
forvalues i = 1/16 {
    local varname = cond(`i'==1, "_cons", "lag_`=`i'-1'")
    gen double score`i' = uhat * ///
        cond(`i'==1, 1, `varname') if touse
}
forvalues i = 1/16 {
    forvalues k = 1/16 {
        quietly summarize score`i' if touse, meanonly
        scalar mean_i = r(mean)
        quietly summarize score`k' if touse, meanonly
        scalar mean_k = r(mean)
        scalar g0 = 0
        quietly {
            forvalues r = 1/`=n' {
                scalar g0 = g0 + score`i'[`r'] * score`k'[`r']
            }
        }
        matrix S[`i',`k'] = g0
    }
}
forvalues h = 1/15 {
    scalar weight = 1 - `h'/16
    forvalues i = 1/16 {
        forvalues k = 1/16 {
            scalar gh = 0
            quietly {
                forvalues r = `=`h'+1'/`=n' {
                    gh = gh + score`i'[`r'] * score`k'[`r'-`h']
                }
            }
            matrix S[`i',`k'] = S[`i',`k'] + weight * gh
        }
    }
}
matrix XX = e(sample)
matrix Vnw = syminv(X'*X) * S * syminv(X'*X)
matrix Vnw = Vnw * (n/(n-16))

scalar se_cumulative_response = 0
forvalues i = 1/15 {
    forvalues k = 1/15 {
        scalar se_cumulative_response = se_cumulative_response + Vnw[`i'+1,`k'+1]
    }
}
scalar se_cumulative_response = sqrt(se_cumulative_response)
scalar se_lag_1 = sqrt(Vnw[2,2])
scalar se_lag_15 = sqrt(Vnw[16,16])

display "ANSWER: cumulative_response estimate=" %21.12f cumulative_response " se=" %21.12f se_cumulative_response " n_obs=" %12.0f n
display "ANSWER: lag_1 estimate=" %21.12f _b[lag_1] " se=" %21.12f se_lag_1 " n_obs=" %12.0f n
display "ANSWER: lag_15 estimate=" %21.12f _b[lag_15] " se=" %21.12f se_lag_15 " n_obs=" %12.0f n
