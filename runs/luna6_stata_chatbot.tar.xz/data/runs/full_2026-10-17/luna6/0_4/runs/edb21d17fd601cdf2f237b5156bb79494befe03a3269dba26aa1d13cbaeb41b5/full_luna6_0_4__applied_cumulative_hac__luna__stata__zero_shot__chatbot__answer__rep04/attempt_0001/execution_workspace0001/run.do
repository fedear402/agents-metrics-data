clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

* Parse the date, then sort by trading observation.
gen double trading_date = daily(date, "YMD")
format trading_date %td
sort trading_date

gen double log_sales = ln(sales)
gen double log_vix = ln(vix)
gen double d_log_vix = log_vix - log_vix[_n-1]

forvalues j = 1/15 {
    gen double lag_`j' = d_log_vix[_n-`j']
}

regress log_sales lag_1-lag_15

scalar N = e(N)
scalar df_correction = N/(N-16)

* Newey-West covariance with Bartlett weights and maximum lag 15.
matrix V = e(V)
forvalues j = 1/15 {
    scalar bartlett_weight = 1 - `j'/16
    matrix G = J(16, 16, 0)
    forvalues t = `=`j'+1'/`=N' {
        matrix x_now = (1, lag_1[`t'], lag_2[`t'], lag_3[`t'], lag_4[`t'], lag_5[`t'], lag_6[`t'], lag_7[`t'], lag_8[`t'], lag_9[`t'], lag_10[`t'], lag_11[`t'], lag_12[`t'], lag_13[`t'], lag_14[`t'], lag_15[`t'])
        matrix x_lag = (1, lag_1[`=`t'-`j''], lag_2[`=`t'-`j''], lag_3[`=`t'-`j''], lag_4[`=`t'-`j''], lag_5[`=`t'-`j''], lag_6[`=`t'-`j''], lag_7[`=`t'-`j''], lag_8[`=`t'-`j''], lag_9[`=`t'-`j''], lag_10[`=`t'-`j''], lag_11[`=`t'-`j''], lag_12[`=`t'-`j''], lag_13[`=`t'-`j''], lag_14[`=`t'-`j''], lag_15[`=`t'-`j''])
        scalar u_now = log_sales[`t'] - ( _b[_cons] + _b[lag_1]*lag_1[`t'] + _b[lag_2]*lag_2[`t'] + _b[lag_3]*lag_3[`t'] + _b[lag_4]*lag_4[`t'] + _b[lag_5]*lag_5[`t'] + _b[lag_6]*lag_6[`t'] + _b[lag_7]*lag_7[`t'] + _b[lag_8]*lag_8[`t'] + _b[lag_9]*lag_9[`t'] + _b[lag_10]*lag_10[`t'] + _b[lag_11]*lag_11[`t'] + _b[lag_12]*lag_12[`t'] + _b[lag_13]*lag_13[`t'] + _b[lag_14]*lag_14[`t'] + _b[lag_15]*lag_15[`t'] )
        scalar u_lag = log_sales[`=`t'-`j''] - ( _b[_cons] + _b[lag_1]*lag_1[`=`t'-`j''] + _b[lag_2]*lag_2[`=`t'-`j''] + _b[lag_3]*lag_3[`=`t'-`j''] + _b[lag_4]*lag_4[`=`t'-`j''] + _b[lag_5]*lag_5[`=`t'-`j''] + _b[lag_6]*lag_6[`=`t'-`j''] + _b[lag_7]*lag_7[`=`t'-`j''] + _b[lag_8]*lag_8[`=`t'-`j''] + _b[lag_9]*lag_9[`=`t'-`j''] + _b[lag_10]*lag_10[`=`t'-`j''] + _b[lag_11]*lag_11[`=`t'-`j''] + _b[lag_12]*lag_12[`=`t'-`j''] + _b[lag_13]*lag_13[`=`t'-`j''] + _b[lag_14]*lag_14[`=`t'-`j''] + _b[lag_15]*lag_15[`=`t'-`j''] )
        matrix G = G + (u_now*x_now')*(u_lag*x_lag)
    }
    matrix V = V + bartlett_weight*(G + G')
}

matrix V = df_correction*V
scalar cumulative_response = _b[lag_1] + _b[lag_2] + _b[lag_3] + _b[lag_4] + _b[lag_5] + _b[lag_6] + _b[lag_7] + _b[lag_8] + _b[lag_9] + _b[lag_10] + _b[lag_11] + _b[lag_12] + _b[lag_13] + _b[lag_14] + _b[lag_15]
matrix c = (0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1)
scalar se_cumulative = sqrt(c*V*c')
scalar se_lag1 = sqrt(V[2,2])
scalar se_lag15 = sqrt(V[16,16])

display "ANSWER: cumulative_response estimate=" %21.12f scalar(cumulative_response) " se=" %21.12f scalar(se_cumulative) " n_obs=" %12.0f scalar(N)
display "ANSWER: lag_1 estimate=" %21.12f _b[lag_1] " se=" %21.12f scalar(se_lag1) " n_obs=" %12.0f scalar(N)
display "ANSWER: lag_15 estimate=" %21.12f _b[lag_15] " se=" %21.12f scalar(se_lag15) " n_obs=" %12.0f scalar(N)
