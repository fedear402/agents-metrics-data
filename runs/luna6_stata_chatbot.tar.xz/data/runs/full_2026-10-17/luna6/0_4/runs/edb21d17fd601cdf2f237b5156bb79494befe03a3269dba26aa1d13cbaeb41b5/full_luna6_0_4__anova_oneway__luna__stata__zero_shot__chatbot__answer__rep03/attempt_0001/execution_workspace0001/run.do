clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

encode group, gen(group_id)
oneway y group_id

scalar F_result = r(F)
scalar df_num_result = r(df_between)
scalar df_den_result = r(df_within)
scalar p_result = Ftail(df_num_result, df_den_result, F_result)
scalar n_result = r(N)

display "ANSWER: F estimate=" %21.12f F_result " se=." " n_obs=" %12.0f n_result
display "ANSWER: df_num estimate=" %21.12f df_num_result " se=." " n_obs=" %12.0f n_result
display "ANSWER: df_den estimate=" %21.12f df_den_result " se=." " n_obs=" %12.0f n_result
display "ANSWER: p_value estimate=" %21.12f p_result " se=." " n_obs=" %12.0f n_result
