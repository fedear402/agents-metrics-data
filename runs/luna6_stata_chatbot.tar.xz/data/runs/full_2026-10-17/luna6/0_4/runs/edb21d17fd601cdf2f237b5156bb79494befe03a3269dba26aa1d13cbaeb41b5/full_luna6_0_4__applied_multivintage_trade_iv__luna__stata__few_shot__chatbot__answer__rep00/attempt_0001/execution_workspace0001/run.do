clear all
set more off
set type double

tempfile crosswalk trade areas employment outcomes national_base national_early

import delimited using "crosswalk.csv", clear
save `crosswalk'

import delimited using "trade.csv", clear
save `trade'

import delimited using "areas.csv", clear
save `areas'

import delimited using "employment.csv", clear
save `employment'

import delimited using "outcomes.csv", clear
save `outcomes'

use `employment', clear
merge m:1 industry using `crosswalk', nogen
collapse (sum) employment, by(area period vintage industry)
reshape wide employment, i(area period industry) j(vintage) string
rename employmentbase base_emp
rename employmentearly early_emp
foreach v in base_emp early_emp {
    replace `v' = 0 if missing(`v')
}
collapse (sum) base_emp early_emp, by(area period industry)
save `employment', replace

use `employment', clear
collapse (sum) base_emp, by(period industry)
rename base_emp national_base_emp
save `national_base'

use `employment', clear
collapse (sum) early_emp, by(period industry)
rename early_emp national_early_emp
save `national_early'

use `areas', clear
keep if vintage == "base"
rename total_employment base_total
rename population base_population
keep area period base_total base_population
tempfile base_areas
save `base_areas'

use `areas', clear
keep if vintage == "early"
rename total_employment early_total
keep area period early_total
tempfile early_areas
save `early_areas'

use `base_areas', clear
merge 1:1 area period using `early_areas', nogen
merge 1:1 area period using `outcomes', nogen
merge m:1 period using `trade', nogen
merge m:1 code using `crosswalk', nogen

tempfile area_period
save `area_period'

use `area_period', clear
keep area period base_total early_total base_population
joinby area period using `employment'
merge m:1 period industry using `national_base', nogen
merge m:1 period industry using `national_early', nogen
merge m:1 period using `trade', nogen
merge m:1 code using `crosswalk', nogen
replace base_emp = 0 if missing(base_emp)
replace early_emp = 0 if missing(early_emp)

gen double x_component = (base_emp/base_total) * ///
    (us_change/national_base_emp) / (price_index/100) / 1000 * (10/years)
gen double z_component = (early_emp/early_total) * ///
    (other_change/national_early_emp) / (price_index/100) / 1000 * (10/years)
collapse (sum) x=x_component z=z_component, by(area period)
tempfile exposures
save `exposures'

use `area_period', clear
merge 1:1 area period using `exposures', nogen
egen byte period_indicator = group(period)
ivregress 2sls change_pp i.period_indicator control (x=z) [aw=base_population]

local n = e(N)
display "ANSWER: iv_slope estimate=" %24.16g _b[x] " se=NA n_obs=" %9.0f `n'

quietly summarize x if area == 0 & period == 0, meanonly
display "ANSWER: exposure_area0_period0 estimate=" %24.16g r(mean) " se=NA n_obs=" %9.0f `n'

quietly summarize x if area == 0 & period == 1, meanonly
display "ANSWER: exposure_area0_period1 estimate=" %24.16g r(mean) " se=NA n_obs=" %9.0f `n'

quietly summarize z if area == 0 & period == 0, meanonly
display "ANSWER: instrument_area0_period0 estimate=" %24.16g r(mean) " se=NA n_obs=" %9.0f `n'
