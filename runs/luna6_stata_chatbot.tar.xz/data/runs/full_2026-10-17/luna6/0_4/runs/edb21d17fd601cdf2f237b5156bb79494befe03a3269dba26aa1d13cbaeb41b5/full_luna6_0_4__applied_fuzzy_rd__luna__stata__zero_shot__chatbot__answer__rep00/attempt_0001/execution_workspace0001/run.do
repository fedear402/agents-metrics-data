clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

keep if abs(score) < 1
generate double weight = 1 - abs(score)
generate double right = score >= 0
generate double right_score = right * score

quietly summarize earnings
scalar n_obs = r(N)

quietly regress earnings right score right_score [aw=weight], vce(robust)
scalar reduced_form = _b[right]
scalar se_reduced_form = _se[right]

quietly regress participated right score right_score [aw=weight], vce(robust)
scalar first_stage = _b[right]
scalar se_first_stage = _se[right]

scalar treatment_effect = reduced_form / first_stage

* Joint HC0 covariance of the two discontinuity estimates.
quietly generate double rf_resid = earnings - ///
    (_b[_cons] + _b[right]*right + _b[score]*score + _b[right_score]*right_score)
quietly generate double fs_resid = participated - ///
    (_b[_cons] + _b[right]*right + _b[score]*score + _b[right_score]*right_score)

* Refit each equation and save its design matrix and residuals.
quietly regress earnings right score right_score [aw=weight]
matrix X = e(X)
matrix XXinv = syminv(quadcross(X, X, weight))
predict double rf_fit, xb
generate double rf_e = earnings - rf_fit

quietly regress participated right score right_score [aw=weight]
predict double fs_fit, xb
generate double fs_e = participated - fs_fit

* HC0 cross-covariance for the right-intercept coefficients.
scalar cov_rf_fs = 0
forvalues i = 1/`=_N' {
    matrix xi = (1, right[`i'], score[`i'], right_score[`i'])
    matrix ai = XXinv * xi'
    scalar cov_rf_fs = cov_rf_fs + weight[`i']^2 * rf_e[`i'] * fs_e[`i'] * ai[2,1]^2
}

scalar se_treatment = .
if first_stage != 0 {
    scalar var_treatment = (se_reduced_form^2 / first_stage^2) + ///
        (reduced_form^2 * se_first_stage^2 / first_stage^4) - ///
        (2 * reduced_form * cov_rf_fs / first_stage^3)
    if var_treatment >= 0 scalar se_treatment = sqrt(var_treatment)
}

display "ANSWER: treatment_effect estimate=" %21.12f treatment_effect " se=" %21.12f se_treatment " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f reduced_form " se=" %21.12f se_reduced_form " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f first_stage " se=" %21.12f se_first_stage " n_obs=" %12.0f n_obs
