clear all
set more off
set type double

import delimited using "input.csv", clear

tempfile source
save `source'

tempname results
matrix `results' = J(4, 3, .)

local row = 0
local total_weight = 0
local weighted_sum = 0
local total_rows = 0

foreach c in 3 5 7 {
    use `source', clear

    keep if g == `c' | g == 0 | g > `c' + 2
    keep if inrange(time, `c' - 2, `c' + 2)

    bysort id: egen byte window_count = count(y)
    keep if window_count == 5
    drop window_count

    gen byte did = (g == `c' & time >= `c')

    quietly regress y did i.id i.time
    local estimate = _b[did]
    local rows = e(N)

    quietly count if g == `c'
    local treated_units = r(N) / 5

    local ++row
    matrix `results'[`row', 1] = `estimate'
    matrix `results'[`row', 2] = `rows'
    matrix `results'[`row', 3] = `treated_units'

    local weighted_sum = `weighted_sum' + `estimate' * `treated_units'
    local total_weight = `total_weight' + `treated_units'
    local total_rows = `total_rows' + `rows'
}

matrix `results'[4, 1] = `weighted_sum' / `total_weight'
matrix `results'[4, 2] = `total_rows'

display "ANSWER: att_g3 estimate=" %24.16g `results'[1,1]
display "ANSWER: att_g5 estimate=" %24.16g `results'[2,1]
display "ANSWER: att_g7 estimate=" %24.16g `results'[3,1]
display "ANSWER: att_weighted estimate=" %24.16g `results'[4,1]
