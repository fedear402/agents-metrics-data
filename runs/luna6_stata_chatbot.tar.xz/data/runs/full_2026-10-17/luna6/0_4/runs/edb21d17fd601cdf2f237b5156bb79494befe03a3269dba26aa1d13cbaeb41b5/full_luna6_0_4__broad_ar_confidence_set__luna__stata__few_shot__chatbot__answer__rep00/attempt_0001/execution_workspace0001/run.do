clear all
set more off
set linesize 255
set type double

import delimited using "./input.csv", clear
local n = _N

quietly regress y x
predict double ry, residuals
quietly regress endog x
predict double rd, residuals

quietly regress y x z1 z2
predict double uy, residuals
scalar df = e(df_r)

quietly regress endog x z1 z2
predict double ud, residuals

scalar q = 2
scalar critical = invFtail(q, df, .05)
scalar k = q * critical / df

mata:
ry = st_data(., "ry")
rd = st_data(., "rd")
uy = st_data(., "uy")
ud = st_data(., "ud")
k = st_numscalar("k")

A = quadcross(rd, rd) - (1+k)*quadcross(ud, ud)
B = -2*(quadcross(ry, rd) - (1+k)*quadcross(uy, ud))
C = quadcross(ry, ry) - (1+k)*quadcross(uy, uy)

disc = B^2 - 4*A*C
assert(disc >= 0)
r1 = (-B-sqrt(disc))/(2*A)
r2 = (-B+sqrt(disc))/(2*A)
bounds = sort((r1 \ r2), 1)
st_numscalar("boundary_low", bounds[1])
st_numscalar("boundary_high", bounds[2])
st_numscalar("accepts_zero", C <= 0)
st_numscalar("unbounded", A < 0)

st_numscalar("ar_f_at_one", ///
    ((quadcross(ry-rd, ry-rd)-quadcross(uy-ud, uy-ud))/q) / ///
    (quadcross(uy-ud, uy-ud)/st_numscalar("df")))
end

scalar missing_se = .
display "ANSWER: boundary_low estimate=" %21.12f boundary_low " se=" %21.12f missing_se " n_obs=" %12.0f `n'
display "ANSWER: boundary_high estimate=" %21.12f boundary_high " se=" %21.12f missing_se " n_obs=" %12.0f `n'
display "ANSWER: accepts_zero estimate=" %21.12f accepts_zero " se=" %21.12f missing_se " n_obs=" %12.0f `n'
display "ANSWER: unbounded estimate=" %21.12f unbounded " se=" %21.12f missing_se " n_obs=" %12.0f `n'
display "ANSWER: ar_f_at_one estimate=" %21.12f ar_f_at_one " se=" %21.12f missing_se " n_obs=" %12.0f `n'
