version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

generate double day = date(date, "YMD")
format day %td
sort day
generate long observation = _n
tsset observation

generate double log_vix = ln(vix)
generate double vix_change = D.log_vix
generate double log_sales = ln(sales)

forvalues j = 1/15 {
    generate double lag_`j' = L`j'.vix_change
}

keep if !missing(log_sales, lag_1-lag_15)

mata:
X = (J(st_nobs(), 1, 1), st_data(., ("lag_1-lag_15")))
y = st_data(., "log_sales")
b = qrsolve(X, y)
u = y - X*b
N = rows(X)
p = cols(X)
scores = X:*u
hac_lags = 15
meat = scores'*scores

for (j=1; j<=hac_lags; j++) {
    lag_product = scores[|j+1,1\N,p|]'*scores[|1,1\N-j,p|]
    meat = meat + (1-j/(hac_lags+1))*(lag_product+lag_product')
}

bread = invsym(X'*X)
V = N/(N-p)*bread*meat*bread

contrast = J(p, 1, 1)
contrast[1] = 0
cumulative = contrast'*b
cumulative_se = sqrt(contrast'*V*contrast)

st_numscalar("cum_est", cumulative)
st_numscalar("cum_se", cumulative_se)
st_numscalar("lag1_est", b[2])
st_numscalar("lag1_se", sqrt(V[2,2]))
st_numscalar("lag15_est", b[16])
st_numscalar("lag15_se", sqrt(V[16,16]))
st_numscalar("n_obs", N)
end

display "ANSWER: cumulative_response estimate=" %21.12f scalar(cum_est) " se=" %21.12f scalar(cum_se) " n_obs=" %12.0f scalar(n_obs)
display "ANSWER: lag_1 estimate=" %21.12f scalar(lag1_est) " se=" %21.12f scalar(lag1_se) " n_obs=" %12.0f scalar(n_obs)
display "ANSWER: lag_15 estimate=" %21.12f scalar(lag15_est) " se=" %21.12f scalar(lag15_se) " n_obs=" %12.0f scalar(n_obs)
