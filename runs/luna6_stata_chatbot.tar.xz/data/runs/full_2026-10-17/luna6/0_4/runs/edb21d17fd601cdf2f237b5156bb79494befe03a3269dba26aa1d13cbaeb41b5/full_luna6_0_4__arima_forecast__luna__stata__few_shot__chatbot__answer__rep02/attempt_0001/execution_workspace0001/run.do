clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

tsset t
arima y, arima(1,1,1) noconstant

predict double y_forecast, y
predict double y_se, mse

local last_t = 250
local target_t = 251
quietly summarize y_forecast if t == `target_t', meanonly
scalar forecast_value = r(mean)
quietly summarize y_se if t == `target_t', meanonly
scalar forecast_se = sqrt(r(mean))

scalar lower_value = forecast_value - invnormal(0.975)*forecast_se
scalar upper_value = forecast_value + invnormal(0.975)*forecast_se
scalar obs_count = e(N)

display "ANSWER: forecast estimate=" %21.12f forecast_value " se=" %21.12f forecast_se " n_obs=" %12.0f obs_count
display "ANSWER: lower_95 estimate=" %21.12f lower_value " se=. n_obs=" %12.0f obs_count
display "ANSWER: upper_95 estimate=" %21.12f upper_value " se=. n_obs=" %12.0f obs_count
