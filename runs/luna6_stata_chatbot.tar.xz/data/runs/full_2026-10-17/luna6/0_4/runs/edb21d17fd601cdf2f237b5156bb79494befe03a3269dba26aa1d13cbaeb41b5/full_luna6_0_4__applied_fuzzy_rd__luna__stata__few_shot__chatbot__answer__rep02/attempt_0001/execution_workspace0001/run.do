version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

keep if abs(score) < 1
generate double rd_weight = 1 - abs(score)
generate double right_side = score >= 0
generate double score_right = score * right_side
generate double score_left = score * (1 - right_side)

quietly count
scalar n_obs = r(N)

* Fit weighted local-linear models with separate slopes on each side.
generate double intercept = 1
generate double earnings_resid = .
generate double participation_resid = .

quietly regress earnings intercept right_side score_right score_left [aw=rd_weight], noconstant
predict double earnings_fit, xb
replace earnings_resid = earnings - earnings_fit

quietly regress participated intercept right_side score_right score_left [aw=rd_weight], noconstant
predict double participation_fit, xb
replace participation_resid = participated - participation_fit

* HC0 covariance for both fitted coefficient vectors, using the same observations.
mata:
X = st_data(., ("intercept", "right_side", "score_right", "score_left"))
w = st_data(., "rd_weight")
Y = st_data(., ("earnings", "participated"))
e = (st_data(., "earnings_resid"), st_data(., "participation_resid"))

bread = invsym(X' * (w :* X))
B = bread * X' * (w :* Y)
C = (0, 1, 0, 0)

jump = C * B
loading = w :* (X * bread * C')
u = loading :* e
V = u' * u

st_numscalar("reduced_form", jump[1])
st_numscalar("first_stage", jump[2])
st_numscalar("reduced_form_se", sqrt(V[1,1]))
st_numscalar("first_stage_se", sqrt(V[2,2]))

ratio = jump[1] / jump[2]
gradient = (1 / jump[2] \ -jump[1] / jump[2]^2)
ratio_se = sqrt(gradient' * V * gradient)

st_numscalar("treatment_effect", ratio)
st_numscalar("treatment_effect_se", ratio_se)
end

display "ANSWER: treatment_effect estimate=" %21.12f scalar(treatment_effect) " se=" %21.12f scalar(treatment_effect_se) " n_obs=" %12.0f scalar(n_obs)
display "ANSWER: reduced_form estimate=" %21.12f scalar(reduced_form) " se=" %21.12f scalar(reduced_form_se) " n_obs=" %12.0f scalar(n_obs)
display "ANSWER: first_stage estimate=" %21.12f scalar(first_stage) " se=" %21.12f scalar(first_stage_se) " n_obs=" %12.0f scalar(n_obs)
