version 16.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear
sort t
tsset t

arima y, arima(1,1,1) noconstant

scalar forecast_value = y[_N] + _b[L.y] * (y[_N] - y[_N-1]) + _b[L.D.y] * (y[_N] - y[_N-1])
scalar forecast_se = sqrt(e(sigma)^2 * (1 + _b[L.y]^2))
scalar lower_value = forecast_value - invnormal(.975) * forecast_se
scalar upper_value = forecast_value + invnormal(.975) * forecast_se
scalar result_n = e(N)

display "ANSWER: forecast estimate=" %21.12f forecast_value " se=" %21.12f . " n_obs=" %12.0f result_n
display "ANSWER: lower_95 estimate=" %21.12f lower_value " se=" %21.12f . " n_obs=" %12.0f result_n
display "ANSWER: upper_95 estimate=" %21.12f upper_value " se=" %21.12f . " n_obs=" %12.0f result_n
