version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

* Keep one row per region for regional outcomes and weights.
bysort region_id: assert region_weight == region_weight[1]
bysort region_id: assert x == x[1]
bysort region_id: assert y == y[1]

* Compute the regional shift-share instrument.
generate double share_shock = share * shock
bysort region_id: egen double z = total(share_shock)

* Retain one observation per region and normalize weights once.
bysort region_id: keep if _n == 1
quietly summarize region_weight, meanonly
scalar total_weight = r(sum)
generate double e = region_weight / total_weight

* Remove weighted regional means before aggregation.
quietly summarize y [aweight=e], meanonly
generate double y0 = y - r(mean)
quietly summarize x [aweight=e], meanonly
generate double x0 = x - r(mean)
quietly summarize z [aweight=e], meanonly
generate double z0 = z - r(mean)

* Aggregate residuals and exposure masses by industry.
preserve
keep region_id industry_id share shock e y0 x0 z0
generate double weighted_share = e * share
collapse (sum) s=weighted_share ///
    (sum) y_num=weighted_share_y0 ///
    (sum) x_num=weighted_share_x0 ///
    (sum) z_num=weighted_share_z0 ///
    (first) shock, by(industry_id)
restore
