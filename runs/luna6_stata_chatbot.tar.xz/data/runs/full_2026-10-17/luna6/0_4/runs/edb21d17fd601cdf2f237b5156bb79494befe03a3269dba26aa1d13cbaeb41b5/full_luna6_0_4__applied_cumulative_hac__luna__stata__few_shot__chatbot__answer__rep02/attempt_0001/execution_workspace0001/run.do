version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

generate double day = date(date, "YMD")
format day %td
sort day
generate long observation = _n
tsset observation

generate double log_vix = ln(vix)
generate double volatility_change = D.log_vix
generate double log_sales = ln(sales)

forvalues j = 1/15 {
    generate double change_lag`j' = L`j'.volatility_change
}

keep if !missing(log_sales, change_lag1, change_lag2, change_lag3, ///
    change_lag4, change_lag5, change_lag6, change_lag7, change_lag8, ///
    change_lag9, change_lag10, change_lag11, change_lag12, change_lag13, ///
    change_lag14, change_lag15)

mata:
X = (J(st_nobs(), 1, 1), st_data(., ("change_lag1","change_lag2","change_lag3", ///
    "change_lag4","change_lag5","change_lag6","change_lag7","change_lag8", ///
    "change_lag9","change_lag10","change_lag11","change_lag12","change_lag13", ///
    "change_lag14","change_lag15")))
y = st_data(., "log_sales")
b = qrsolve(X, y)
u = y - X*b
N = rows(X)
p = cols(X)
scores = X:*u
meat = scores'*scores
for (j=1; j<=15; j++) {
    lag_product = scores[|j+1,1\N,p|]' * scores[|1,1\N-j,p|]
    meat = meat + (1-j/16)*(lag_product + lag_product')
}
bread = invsym(X'*X)
V = (N/(N-16))*bread*meat*bread

contrast = J(16,1,1)
contrast[1] = 0
cum_est = contrast'*b
cum_se = sqrt(contrast'*V*contrast)
lag1_est = b[2]
lag1_se = sqrt(V[2,2])
lag15_est = b[16]
lag15_se = sqrt(V[16,16])

st_numscalar("cum_est", cum_est)
st_numscalar("cum_se", cum_se)
st_numscalar("lag1_est", lag1_est)
st_numscalar("lag1_se", lag1_se)
st_numscalar("lag15_est", lag15_est)
st_numscalar("lag15_se", lag15_se)
st_numscalar("n_obs", N)
end

display "ANSWER: cumulative_response estimate=" %21.12f scalar(cum_est) ///
    " se=" %21.12f scalar(cum_se) " n_obs=" %12.0f scalar(n_obs)
display "ANSWER: lag_1 estimate=" %21.12f scalar(lag1_est) ///
    " se=" %21.12f scalar(lag1_se) " n_obs=" %12.0f scalar(n_obs)
display "ANSWER: lag_15 estimate=" %21.12f scalar(lag15_est) ///
    " se=" %21.12f scalar(lag15_se) " n_obs=" %12.0f scalar(n_obs)
