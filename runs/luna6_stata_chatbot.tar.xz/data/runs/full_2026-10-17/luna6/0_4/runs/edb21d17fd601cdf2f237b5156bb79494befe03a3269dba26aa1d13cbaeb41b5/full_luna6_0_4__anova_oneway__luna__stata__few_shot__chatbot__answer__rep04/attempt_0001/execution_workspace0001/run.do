clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

oneway y group

local F = r(F)
local df_num = r(df_m)
local df_den = r(df_r)
local p_value = r(p)
local n = e(N)

display "ANSWER: F estimate=" %21.12f `F' " se=."
display "ANSWER: df_num estimate=" %21.12f `df_num' " se=."
display "ANSWER: df_den estimate=" %21.12f `df_den' " se=."
display "ANSWER: p_value estimate=" %21.12f `p_value' " se=."
