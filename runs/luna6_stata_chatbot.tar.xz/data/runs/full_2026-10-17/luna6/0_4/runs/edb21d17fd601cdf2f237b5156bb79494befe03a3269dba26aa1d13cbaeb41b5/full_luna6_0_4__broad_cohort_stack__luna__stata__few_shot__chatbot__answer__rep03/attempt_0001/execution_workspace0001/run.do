clear all
set more off
set type double

import delimited using "input.csv", clear

tempfile source
save `source'

tempname b3 b5 b7 w3 w5 w7 n3 n5 n7
scalar `b3' = .
scalar `b5' = .
scalar `b7' = .
scalar `w3' = 0
scalar `w5' = 0
scalar `w7' = 0
scalar `n3' = 0
scalar `n5' = 0
scalar `n7' = 0

foreach c in 3 5 7 {
    use `source', clear
    keep if g == `c' | g == 0 | g > `c' + 2
    keep if inrange(time, `c' - 2, `c' + 2)

    bysort id: egen byte n_window = total(inrange(time, `c' - 2, `c' + 2))
    keep if n_window == 5
    drop n_window

    gen byte did = (g == `c' & time >= `c')
    quietly regress y did i.id i.time
    scalar effect = _b[did]
    scalar rows = e(N)

    bysort id: gen byte first_unit = (_n == 1)
    quietly count if first_unit & g == `c'
    scalar treated_units = r(N)

    if `c' == 3 {
        scalar `b3' = effect
        scalar `w3' = treated_units
        scalar `n3' = rows
    }
    if `c' == 5 {
        scalar `b5' = effect
        scalar `w5' = treated_units
        scalar `n5' = rows
    }
    if `c' == 7 {
        scalar `b7' = effect
        scalar `w7' = treated_units
        scalar `n7' = rows
    }
}

scalar weighted = (scalar(`b3')*scalar(`w3') + scalar(`b5')*scalar(`w5') + scalar(`b7')*scalar(`w7')) / (scalar(`w3') + scalar(`w5') + scalar(`w7'))

display "ANSWER: att_g3 estimate=" %24.16g scalar(`b3')
display "ANSWER: att_g5 estimate=" %24.16g scalar(`b5')
display "ANSWER: att_g7 estimate=" %24.16g scalar(`b7')
display "ANSWER: att_weighted estimate=" %24.16g weighted
