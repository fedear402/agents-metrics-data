clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

keep if abs(score) < 1
generate double weight = 1 - abs(score)
generate double right = score >= 0
generate double right_score = right * score

quietly count
scalar n_obs = r(N)

quietly regress earnings right score right_score [aw=weight], vce(hc0)
scalar reduced_form = _b[right]
scalar se_reduced_form = _se[right]

quietly regress participated right score right_score [aw=weight], vce(hc0)
scalar first_stage = _b[right]
scalar se_first_stage = _se[right]

* Obtain the joint covariance from a stacked system with side-specific slopes.
generate double y_earnings = earnings
generate double y_participated = participated
reshape long y_, i(id) j(outcome) string
generate double is_earnings = outcome == "earnings"
generate double is_participated = outcome == "participated"
generate double right_earnings = right * is_earnings
generate double right_participated = right * is_participated
generate double score_earnings = score * is_earnings
generate double score_participated = score * is_participated
generate double right_score_earnings = right_score * is_earnings
generate double right_score_participated = right_score * is_participated

quietly regress y_ ///
    is_earnings is_participated ///
    right_earnings right_participated ///
    score_earnings score_participated ///
    right_score_earnings right_score_participated [aw=weight], vce(hc0)

* The stacked HC0 covariance needs the cross-outcome score products.
* Compute the joint covariance directly from the two separate weighted fits.
quietly regress earnings right score right_score [aw=weight]
predict double resid_earnings, resid
quietly regress participated right score right_score [aw=weight]
predict double resid_participated, resid

* Recreate the weighted design cross-products for the two cutoff estimates.
matrix X = (J(_N,1,1), right, score, right_score)
