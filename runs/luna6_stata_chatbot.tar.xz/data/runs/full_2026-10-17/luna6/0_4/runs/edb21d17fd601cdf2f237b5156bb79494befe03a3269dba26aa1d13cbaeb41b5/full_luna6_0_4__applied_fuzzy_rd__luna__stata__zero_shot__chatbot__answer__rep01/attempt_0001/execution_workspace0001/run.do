clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

keep if abs(score) < 1
generate double weight = 1 - abs(score)
generate double right = score >= 0
generate double right_score = right * score

quietly summarize score
local n_obs = r(N)

quietly regress earnings right score right_score [aw=weight], vce(robust)
scalar reduced_form = _b[right]
scalar var_reduced_form = (_se[right])^2

quietly regress participated right score right_score [aw=weight], vce(robust)
scalar first_stage = _b[right]
scalar var_first_stage = (_se[right])^2

* HC0 covariance of the two discontinuity estimates from shared observations.
quietly generate double resid_y = earnings - ///
    (_b[_cons] + _b[right]*right + _b[score]*score + _b[right_score]*right_score)
quietly generate double resid_d = participated - ///
    (_b[_cons] + _b[right]*right + _b[score]*score + _b[right_score]*right_score)

* Refit both models and store their coefficient vectors and residuals.
quietly regress earnings right score right_score [aw=weight]
matrix b_y = e(b)
quietly predict double resid_y2, resid
quietly regress participated right score right_score [aw=weight]
matrix b_d = e(b)
quietly predict double resid_d2, resid

* Build HC0 cross-covariance with the common weighted design.
generate double x0 = 1
generate double x1 = right
generate double x2 = score
generate double x3 = right_score
generate double wx0 = weight*x0
generate double wx1 = weight*x1
generate double wx2 = weight*x2
generate double wx3 = weight*x3

mata:
w = st_data(., "weight")
X = st_data(., ("x0","x1","x2","x3"))
ry = st_data(., "resid_y2")
rd = st_data(., "resid_d2")
A = invsym(X' * (X :* w))
S = X' * ((X :* (w:^2)) :* (ry:*rd))
V = A * S * A
st_numscalar("cov_rf_fs", V[2,2])
end

scalar treatment_effect = reduced_form / first_stage
scalar se_reduced_form = sqrt(var_reduced_form)
scalar se_first_stage = sqrt(var_first_stage)
scalar var_treatment_effect = ///
    var_reduced_form/(first_stage^2) + ///
    (reduced_form^2)*var_first_stage/(first_stage^4) - ///
    2*reduced_form*cov_rf_fs/(first_stage^3)
scalar se_treatment_effect = sqrt(var_treatment_effect)

display "ANSWER: treatment_effect estimate=" %21.12f treatment_effect " se=" %21.12f se_treatment_effect " n_obs=" %12.0f `n_obs'
display "ANSWER: reduced_form estimate=" %21.12f reduced_form " se=" %21.12f se_reduced_form " n_obs=" %12.0f `n_obs'
display "ANSWER: first_stage estimate=" %21.12f first_stage " se=" %21.12f se_first_stage " n_obs=" %12.0f `n_obs'
