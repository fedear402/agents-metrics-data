import json
import numpy as np
import pandas as pd
from scipy.stats import f

df = pd.read_csv("input.csv")

y = df["y"].to_numpy(dtype=float)
endog = df["endog"].to_numpy(dtype=float)
x = df["x"].to_numpy(dtype=float)
z = df[["z1", "z2"]].to_numpy(dtype=float)

n = len(df)
base = np.column_stack([np.ones(n), x])
full = np.column_stack([base, z])

def residualize(v, design):
    return v - design @ np.linalg.lstsq(design, v, rcond=None)[0]

y_base = residualize(y, base)
e_base = residualize(endog, base)
z_base = np.column_stack([residualize(z[:, j], base) for j in range(z.shape[1])])

projection_z = z_base @ np.linalg.pinv(z_base.T @ z_base) @ z_base.T

y_full = residualize(y, full)
e_full = residualize(endog, full)

q0 = y_base @ projection_z @ y_base
q1 = -2.0 * (e_base @ projection_z @ y_base)
q2 = e_base @ projection_z @ e_base

rss0 = y_full @ y_full
rss1 = -2.0 * (e_full @ y_full)
rss2 = e_full @ e_full

f_crit = f.ppf(0.95, 2, n - 4)
scale = 2.0 * f_crit / (n - 4)

polynomial = np.array([
    q2 - scale * rss2,
    q1 - scale * rss1,
    q0 - scale * rss0
])

roots = np.roots(polynomial)
real_roots = sorted(
    float(root.real)
    for root in roots
    if abs(root.imag) <= 1e-8 * max(1.0, abs(root.real))
)

boundary_low = real_roots[0]
boundary_high = real_roots[-1]

def ar_f(beta):
    w = y - beta * endog
    w_base = residualize(w, base)
    numerator = w_base @ projection_z @ w_base
    residual = residualize(w, full)
    denominator = (residual @ residual) / (n - 4)
    return (numerator / 2.0) / denominator

ar_f_at_one = ar_f(1.0)
accepts_zero = float(ar_f(0.0) <= f_crit)

leading = polynomial[0]
linear = polynomial[1]

if leading < -1e-10:
    unbounded = 1.0
elif abs(leading) <= 1e-10 and abs(linear) <= 1e-10:
    unbounded = 1.0
else:
    unbounded = 0.0

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": [
        {
            "term": "boundary_low",
            "estimate": boundary_low,
            "se": None,
            "n_obs": n
        },
        {
            "term": "boundary_high",
            "estimate": boundary_high,
            "se": None,
            "n_obs": n
        },
        {
            "term": "accepts_zero",
            "estimate": accepts_zero,
            "se": None,
            "n_obs": n
        },
        {
            "term": "unbounded",
            "estimate": unbounded,
            "se": None,
            "n_obs": n
        },
        {
            "term": "ar_f_at_one",
            "estimate": ar_f_at_one,
            "se": None,
            "n_obs": n
        }
    ],
    "method_metadata": {
        "estimator": "Anderson-Rubin confidence set inversion with homoskedastic joint F test",
        "vcov": "conventional homoskedastic"
    },
    "diagnostics": {}
}

with open("result.json", "w") as file:
    json.dump(result, file)
