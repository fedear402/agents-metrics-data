import json
import numpy as np
import pandas as pd

data = pd.read_csv("input.csv")

sample = data.loc[data["score"].abs() < 1].copy()
x = sample["score"].to_numpy(dtype=float)
right = (x >= 0).astype(float)
weights = 1.0 - np.abs(x)

X = np.column_stack([
    np.ones(len(sample)),
    x,
    right,
    right * x,
])

W = weights[:, None]
bread = np.linalg.inv(X.T @ (W * X))

outcomes = sample[["earnings", "participated"]].to_numpy(dtype=float)
coefficients = bread @ X.T @ (W * outcomes)
residuals = outcomes - X @ coefficients

contrast = np.array([0.0, 0.0, 1.0, 0.0])
discontinuities = contrast @ coefficients

loading = weights * (X @ bread @ contrast)
influence = loading[:, None] * residuals
joint_covariance = influence.T @ influence

reduced_form, first_stage = discontinuities
treatment_effect = reduced_form / first_stage

gradient = np.array([
    1.0 / first_stage,
    -reduced_form / (first_stage ** 2),
])
treatment_se = np.sqrt(gradient @ joint_covariance @ gradient)

n_obs = int(len(sample))

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {
            "term": "treatment_effect",
            "estimate": float(treatment_effect),
            "se": float(treatment_se),
            "n_obs": n_obs,
        },
        {
            "term": "reduced_form",
            "estimate": float(reduced_form),
            "se": float(np.sqrt(joint_covariance[0, 0])),
            "n_obs": n_obs,
        },
        {
            "term": "first_stage",
            "estimate": float(first_stage),
            "se": float(np.sqrt(joint_covariance[1, 1])),
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "Fuzzy local-linear regression discontinuity with triangular kernel weights",
        "vcov": "Conventional heteroskedasticity-robust HC0 with delta-method ratio standard error",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
