import json
import pandas as pd
from statsmodels.miscmodels.ordinal_model import OrderedModel

df = pd.read_csv("input.csv")

model = OrderedModel(
    endog=df["y"],
    exog=df[["x", "z"]],
    distr="logit",
)

fit = model.fit(method="bfgs", disp=False)

params = fit.params
cov = fit.cov_params()

x_estimate = float(params["x"])
z_estimate = float(params["z"])
x_se = float(cov.loc["x", "x"] ** 0.5)
z_se = float(cov.loc["z", "z"] ** 0.5)

new_data = pd.DataFrame({"x": [1.0], "z": [0.0]})
predicted = model.predict(params=fit.params, exog=new_data)
prob_high = float(predicted.iloc[0, 2])

result = {
    "task_id": "broad_ordered_logit",
    "platform": "python",
    "estimates": [
        {
            "term": "x",
            "estimate": x_estimate,
            "se": x_se,
            "n_obs": int(len(df)),
        },
        {
            "term": "z",
            "estimate": z_estimate,
            "se": z_se,
            "n_obs": int(len(df)),
        },
        {
            "term": "prob_high",
            "estimate": prob_high,
            "se": None,
            "n_obs": int(len(df)),
        },
    ],
    "method_metadata": {
        "estimator": "maximum likelihood ordered logit with two free cutpoints and no intercept",
        "vcov": "conventional observed-information covariance matrix",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
