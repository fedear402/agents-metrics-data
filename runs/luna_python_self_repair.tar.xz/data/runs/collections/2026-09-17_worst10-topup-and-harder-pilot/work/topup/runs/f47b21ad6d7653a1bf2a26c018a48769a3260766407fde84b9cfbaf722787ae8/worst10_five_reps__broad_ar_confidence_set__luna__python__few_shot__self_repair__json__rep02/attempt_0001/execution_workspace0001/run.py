import json
import numpy as np
import pandas as pd
from scipy.stats import f

data = pd.read_csv("input.csv")

y = data["y"].to_numpy(dtype=float)
endog = data["endog"].to_numpy(dtype=float)
x = data["x"].to_numpy(dtype=float)
z1 = data["z1"].to_numpy(dtype=float)
z2 = data["z2"].to_numpy(dtype=float)

n = len(data)
q = 2
df = n - 4

restricted_design = np.column_stack([np.ones(n), x])
unrestricted_design = np.column_stack([np.ones(n), x, z1, z2])

def residuals(response, design):
    coefficients = np.linalg.lstsq(design, response, rcond=None)[0]
    return response - design @ coefficients

ry = residuals(y, restricted_design)
rd = residuals(endog, restricted_design)

uy = residuals(y, unrestricted_design)
ud = residuals(endog, unrestricted_design)

critical = f.ppf(0.95, q, df)
k = q * critical / df

A = rd @ rd - (1.0 + k) * (ud @ ud)
B = -2.0 * (ry @ rd - (1.0 + k) * (uy @ ud))
C = ry @ ry - (1.0 + k) * (uy @ uy)

discriminant = B * B - 4.0 * A * C
roots = np.roots([A, B, C])
boundaries = np.sort(np.real(roots[np.abs(np.imag(roots)) < 1e-8]))

def accepts(beta):
    return A * beta * beta + B * beta + C <= 0.0

def ar_f(beta):
    response = y - beta * endog
    restricted_residual = residuals(response, restricted_design)
    unrestricted_residual = residuals(response, unrestricted_design)
    ssr_restricted = restricted_residual @ restricted_residual
    ssr_unrestricted = unrestricted_residual @ unrestricted_residual
    return ((ssr_restricted - ssr_unrestricted) / q) / (
        ssr_unrestricted / df
    )

unbounded = int(A < 0.0)

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": [
        {
            "term": "boundary_low",
            "estimate": float(boundaries[0]),
            "se": None,
            "n_obs": n,
        },
        {
            "term": "boundary_high",
            "estimate": float(boundaries[-1]),
            "se": None,
            "n_obs": n,
        },
        {
            "term": "accepts_zero",
            "estimate": float(int(accepts(0.0))),
            "se": None,
            "n_obs": n,
        },
        {
            "term": "unbounded",
            "estimate": float(unbounded),
            "se": None,
            "n_obs": n,
        },
        {
            "term": "ar_f_at_one",
            "estimate": float(ar_f(1.0)),
            "se": None,
            "n_obs": n,
        },
    ],
    "method_metadata": {
        "estimator": "Anderson-Rubin confidence set inversion with homoskedastic joint F test",
        "vcov": "homoskedastic",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
