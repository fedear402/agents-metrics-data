import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("input.csv")
df = df.loc[df["score"].abs() < 1].copy()

x = df["score"].to_numpy(dtype=float)
right = (x >= 0).astype(float)
X = np.column_stack([
    np.ones(len(x)),
    x,
    right,
    right * x,
])
weights = 1.0 - np.abs(x)
W = np.diag(weights)

def fit_discontinuity(y):
    y = np.asarray(y, dtype=float)
    model = sm.WLS(y, X, weights=weights).fit()
    beta = model.params
    cov = model.get_robustcov_results(cov_type="HC0").cov_params()
    contrast = np.array([0.0, 0.0, 1.0, 0.0])
    estimate = float(contrast @ beta)
    variance = float(contrast @ cov @ contrast)
    se = float(np.sqrt(max(variance, 0.0)))
    return estimate, se, model, cov, contrast

earnings = df["earnings"].to_numpy(dtype=float)
participated = df["participated"].to_numpy(dtype=float)

reduced_form, _, rf_model, _, contrast = fit_discontinuity(earnings)
first_stage, _, fs_model, _, _ = fit_discontinuity(participated)

bread = np.linalg.inv(X.T @ W @ X)
rf_resid = earnings - X @ rf_model.params
fs_resid = participated - X @ fs_model.params
cross_meat = X.T @ np.diag(weights**2 * rf_resid * fs_resid) @ X
cross_cov = bread @ cross_meat @ bread

rf_cov = rf_model.get_robustcov_results(cov_type="HC0").cov_params()
fs_cov = fs_model.get_robustcov_results(cov_type="HC0").cov_params()

var_rf = float(contrast @ rf_cov @ contrast)
var_fs = float(contrast @ fs_cov @ contrast)
cov_rf_fs = float(contrast @ cross_cov @ contrast)

if first_stage == 0:
    treatment_effect = None
    treatment_se = None
else:
    treatment_effect = float(reduced_form / first_stage)
    treatment_variance = (
        var_rf / first_stage**2
        + reduced_form**2 * var_fs / first_stage**4
        - 2.0 * reduced_form * cov_rf_fs / first_stage**3
    )
    treatment_se = float(np.sqrt(max(treatment_variance, 0.0)))

n_obs = int(len(df))

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {
            "term": "treatment_effect",
            "estimate": treatment_effect,
            "se": treatment_se,
            "n_obs": n_obs,
        },
        {
            "term": "reduced_form",
            "estimate": float(reduced_form),
            "se": float(np.sqrt(max(var_rf, 0.0))),
            "n_obs": n_obs,
        },
        {
            "term": "first_stage",
            "estimate": float(first_stage),
            "se": float(np.sqrt(max(var_fs, 0.0))),
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "Fuzzy local-linear regression discontinuity with triangular weights",
        "vcov": "HC0 heteroskedasticity-robust covariance; delta method with joint covariance",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
