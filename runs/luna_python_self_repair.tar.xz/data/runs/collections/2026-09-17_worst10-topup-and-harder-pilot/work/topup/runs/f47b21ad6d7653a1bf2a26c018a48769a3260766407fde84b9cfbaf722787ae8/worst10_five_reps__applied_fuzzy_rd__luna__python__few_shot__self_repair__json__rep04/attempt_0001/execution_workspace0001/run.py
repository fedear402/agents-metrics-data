import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df = df.loc[df["score"].abs() < 1].copy()

score = df["score"].to_numpy(dtype=float)
right = (score >= 0).astype(float)
weights = 1.0 - np.abs(score)

X = np.column_stack([
    np.ones(len(score)),
    score,
    right,
    right * score,
])

Y = df[["earnings", "participated"]].to_numpy(dtype=float)

wX = weights[:, None] * X
bread = np.linalg.inv(X.T @ wX)
coefficients = bread @ X.T @ (weights[:, None] * Y)
residuals = Y - X @ coefficients

meat = np.einsum(
    "i,ij,ik->jk",
    weights**2,
    X,
    X,
)
# Construct outcome-specific and cross-outcome HC0 covariance matrices.
joint_cov = np.empty((2, 2), dtype=float)
contrast = np.array([0.0, 0.0, 1.0, 0.0])
loading = weights * (X @ bread @ contrast)

influence = loading[:, None] * residuals
joint_cov = influence.T @ influence

discontinuities = contrast @ coefficients
reduced_form = discontinuities[0]
first_stage = discontinuities[1]
treatment_effect = reduced_form / first_stage

gradient = np.array([
    1.0 / first_stage,
    -reduced_form / first_stage**2,
])
treatment_variance = gradient @ joint_cov @ gradient

n_obs = int(len(df))
rows = [
    {
        "term": "treatment_effect",
        "estimate": float(treatment_effect),
        "se": float(np.sqrt(treatment_variance)),
        "n_obs": n_obs,
    },
    {
        "term": "reduced_form",
        "estimate": float(reduced_form),
        "se": float(np.sqrt(joint_cov[0, 0])),
        "n_obs": n_obs,
    },
    {
        "term": "first_stage",
        "estimate": float(first_stage),
        "se": float(np.sqrt(joint_cov[1, 1])),
        "n_obs": n_obs,
    },
]

output = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": rows,
    "method_metadata": {
        "estimator": "local-linear fuzzy regression discontinuity with triangular weights",
        "vcov": "conventional heteroskedasticity-robust HC0 with delta method",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
