import json
import numpy as np
import pandas as pd
from scipy.stats import f
import statsmodels.api as sm

df = pd.read_csv("input.csv")

y = df["y"].to_numpy(dtype=float)
endog = df["endog"].to_numpy(dtype=float)
x = df["x"].to_numpy(dtype=float)
z = df[["z1", "z2"]].to_numpy(dtype=float)

n = len(df)
q = 2
k_full = 4
df_denom = n - k_full

X = np.column_stack([np.ones(n), x])
Z = np.column_stack([X, z])

# Residual-maker for the included regressors: intercept and x.
X_cross = X.T @ X
M_X = np.eye(n) - X @ np.linalg.solve(X_cross, X.T)

z_res = M_X @ z
y_res = M_X @ y
endog_res = M_X @ endog

zzt_inv = np.linalg.inv(z_res.T @ z_res)
P_Z = z_res @ zzt_inv @ z_res.T

# For r(beta) = y - beta * endog, after removing intercept and x:
# restricted SSR = r_res' r_res
# unrestricted SSR = r_res' (I - P_Z) r_res
# explained sum of squares = r_res' P_Z r_res
A = np.column_stack([y_res, endog_res])

restricted_coeff = np.array([
    y_res @ y_res,
    -2.0 * (y_res @ endog_res),
    endog_res @ endog_res
])

explained_matrix = A.T @ P_Z @ A
explained_coeff = np.array([
    explained_matrix[0, 0],
    2.0 * explained_matrix[0, 1],
    explained_matrix[1, 1]
])

unrestricted_coeff = restricted_coeff - explained_coeff

critical_f = f.ppf(0.95, q, df_denom)

# Accept beta when:
# ((n-4)/2) * explained SSR <= critical_f * unrestricted SSR.
inequality_coeff = (
    (df_denom / q) * explained_coeff
    - critical_f * unrestricted_coeff
)

roots = np.roots(inequality_coeff[::-1])
real_roots = sorted(
    float(root.real)
    for root in roots
    if abs(root.imag) <= 1e-8 * max(1.0, abs(root.real))
)

if len(real_roots) >= 2:
    boundary_low = real_roots[0]
    boundary_high = real_roots[-1]
else:
    raise RuntimeError("Expected two finite Anderson-Rubin boundary points.")

def ar_f(beta):
    r = y_res - beta * endog_res
    explained = float(r @ P_Z @ r)
    unrestricted_ssr = float(r @ (np.eye(n) - P_Z) @ r)
    return (explained / q) / (unrestricted_ssr / df_denom)

accepts_zero = float(ar_f(0.0) <= critical_f)
unbounded = 0.0

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": [
        {
            "term": "boundary_low",
            "estimate": boundary_low,
            "se": None,
            "n_obs": n
        },
        {
            "term": "boundary_high",
            "estimate": boundary_high,
            "se": None,
            "n_obs": n
        },
        {
            "term": "accepts_zero",
            "estimate": accepts_zero,
            "se": None,
            "n_obs": n
        },
        {
            "term": "unbounded",
            "estimate": unbounded,
            "se": None,
            "n_obs": n
        },
        {
            "term": "ar_f_at_one",
            "estimate": ar_f(1.0),
            "se": None,
            "n_obs": n
        }
    ],
    "method_metadata": {
        "estimator": "Anderson-Rubin confidence set inversion using conventional homoskedastic joint F test",
        "vcov": "homoskedastic"
    },
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
