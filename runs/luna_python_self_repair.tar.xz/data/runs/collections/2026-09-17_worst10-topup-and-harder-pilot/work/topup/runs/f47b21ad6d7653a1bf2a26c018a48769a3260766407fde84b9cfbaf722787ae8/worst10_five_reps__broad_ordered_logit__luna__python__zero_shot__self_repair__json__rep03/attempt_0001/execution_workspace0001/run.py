import json
import pandas as pd
from statsmodels.miscmodels.ordinal_model import OrderedModel

df = pd.read_csv("input.csv")

model = OrderedModel(
    endog=df["y"],
    exog=df[["x", "z"]],
    distr="logit",
)

fit = model.fit(method="bfgs", disp=False)

params = fit.params
bse = fit.bse

prob_high = float(
    model.predict(
        params=params,
        exog=pd.DataFrame({"x": [1.0], "z": [0.0]})
    )[0, 2]
)

output = {
    "task_id": "broad_ordered_logit",
    "platform": "python",
    "estimates": [
        {
            "term": "x",
            "estimate": float(params["x"]),
            "se": float(bse["x"]),
            "n_obs": int(len(df)),
        },
        {
            "term": "z",
            "estimate": float(params["z"]),
            "se": float(bse["z"]),
            "n_obs": int(len(df)),
        },
        {
            "term": "prob_high",
            "estimate": prob_high,
            "se": None,
            "n_obs": int(len(df)),
        },
    ],
    "method_metadata": {
        "estimator": "maximum likelihood ordered logit with two free cutpoints and no intercept",
        "vcov": "conventional observed-information standard errors",
    },
    "diagnostics": {},
}

with open("result.json", "w") as file:
    json.dump(output, file, indent=2)
