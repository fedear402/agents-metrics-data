import json
import pandas as pd
from statsmodels.miscmodels.ordinal_model import OrderedModel

data = pd.read_csv("input.csv")
n_obs = len(data)

model = OrderedModel(
    data["y"],
    data[["x", "z"]],
    distr="logit"
)

fit = model.fit(method="bfgs", disp=False, gtol=1e-8)

prob_high = float(
    model.predict(
        fit.params,
        exog=pd.DataFrame({"x": [1.0], "z": [0.0]})
    )[0, 2]
)

result = {
    "task_id": "broad_ordered_logit",
    "platform": "python",
    "estimates": [
        {
            "term": "x",
            "estimate": float(fit.params["x"]),
            "se": float(fit.bse["x"]),
            "n_obs": n_obs
        },
        {
            "term": "z",
            "estimate": float(fit.params["z"]),
            "se": float(fit.bse["z"]),
            "n_obs": n_obs
        },
        {
            "term": "prob_high",
            "estimate": prob_high,
            "se": None,
            "n_obs": n_obs
        }
    ],
    "method_metadata": {
        "estimator": "ordered_logit_maximum_likelihood",
        "vcov": "conventional_observed_information"
    },
    "diagnostics": {}
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
