import json
import numpy as np
import pandas as pd
from scipy.stats import f

data = pd.read_csv("input.csv")

y = data["y"].to_numpy(dtype=float)
endog = data["endog"].to_numpy(dtype=float)
x = data["x"].to_numpy(dtype=float)
z1 = data["z1"].to_numpy(dtype=float)
z2 = data["z2"].to_numpy(dtype=float)

n = len(data)
q = 2
df = n - 4

restricted_design = np.column_stack([np.ones(n), x])
unrestricted_design = np.column_stack([np.ones(n), x, z1, z2])

def residual_vector(outcome, design):
    coefficients = np.linalg.lstsq(design, outcome, rcond=None)[0]
    return outcome - design @ coefficients

y_restricted = residual_vector(y, restricted_design)
endog_restricted = residual_vector(endog, restricted_design)

y_unrestricted = residual_vector(y, unrestricted_design)
endog_unrestricted = residual_vector(endog, unrestricted_design)

critical = f.ppf(0.95, q, df)
k = q * critical / df

a = (
    endog_restricted @ endog_restricted
    - (1.0 + k) * (endog_unrestricted @ endog_unrestricted)
)
b = -2.0 * (
    y_restricted @ endog_restricted
    - (1.0 + k) * (y_unrestricted @ endog_unrestricted)
)
c = (
    y_restricted @ y_restricted
    - (1.0 + k) * (y_unrestricted @ y_unrestricted)
)

roots = np.roots([a, b, c])
boundaries = np.sort(roots.real)

def ar_f(beta):
    outcome = y - beta * endog
    restricted_residual = residual_vector(outcome, restricted_design)
    unrestricted_residual = residual_vector(outcome, unrestricted_design)
    ssr_restricted = restricted_residual @ restricted_residual
    ssr_unrestricted = unrestricted_residual @ unrestricted_residual
    return ((ssr_restricted - ssr_unrestricted) / q) / (
        ssr_unrestricted / df
    )

def accepts(beta):
    return a * beta * beta + b * beta + c <= 0.0

rows = [
    {
        "term": "boundary_low",
        "estimate": float(boundaries[0]),
        "se": None,
        "n_obs": n,
    },
    {
        "term": "boundary_high",
        "estimate": float(boundaries[-1]),
        "se": None,
        "n_obs": n,
    },
    {
        "term": "accepts_zero",
        "estimate": float(int(accepts(0.0))),
        "se": None,
        "n_obs": n,
    },
    {
        "term": "unbounded",
        "estimate": float(int(a < 0.0)),
        "se": None,
        "n_obs": n,
    },
    {
        "term": "ar_f_at_one",
        "estimate": float(ar_f(1.0)),
        "se": None,
        "n_obs": n,
    },
]

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": rows,
    "method_metadata": {
        "estimator": "95 percent Anderson-Rubin confidence set inversion",
        "vcov": "conventional homoskedastic joint F test",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
