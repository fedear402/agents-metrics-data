import json
import numpy as np
import pandas as pd

from statsmodels.regression.linear_model import WLS


def main():
    df = pd.read_csv("input.csv")
    df = df.loc[df["score"].abs() < 1].copy()

    score = df["score"].to_numpy(dtype=float)
    earnings = df["earnings"].to_numpy(dtype=float)
    participated = df["participated"].to_numpy(dtype=float)

    right = (score >= 0).astype(float)
    left = 1.0 - right

    X = np.column_stack([
        left,
        left * score,
        right,
        right * score,
    ])

    weights = 1.0 - np.abs(score)
    n_obs = int(len(df))

    def fit_outcome(y):
        model = WLS(y, X, weights=weights).fit(cov_type="HC0")
        contrast = np.array([-1.0, 0.0, 1.0, 0.0])
        estimate = float(contrast @ model.params)
        variance = float(contrast @ model.cov_params() @ contrast)
        se = float(np.sqrt(max(variance, 0.0)))
        return estimate, se, model.resid

    reduced_form, reduced_form_se, residuals_earnings = fit_outcome(earnings)
    first_stage, first_stage_se, residuals_participated = fit_outcome(participated)

    bread = np.linalg.inv(X.T @ (weights[:, None] * X))
    meat_cross = X.T @ (
        ((weights ** 2) * residuals_earnings * residuals_participated)[:, None] * X
    )
    covariance_cross = bread @ meat_cross @ bread

    contrast = np.array([-1.0, 0.0, 1.0, 0.0])
    covariance_discontinuities = float(
        contrast @ covariance_cross @ contrast
    )

    if first_stage == 0.0:
        treatment_effect = None
        treatment_effect_se = None
    else:
        treatment_effect = float(reduced_form / first_stage)
        gradient = np.array([
            1.0 / first_stage,
            -reduced_form / (first_stage ** 2),
        ])
        covariance = np.array([
            [reduced_form_se ** 2, covariance_discontinuities],
            [covariance_discontinuities, first_stage_se ** 2],
        ])
        treatment_variance = float(gradient @ covariance @ gradient)
        treatment_effect_se = float(np.sqrt(max(treatment_variance, 0.0)))

    result = {
        "task_id": "applied_fuzzy_rd",
        "platform": "python",
        "estimates": [
            {
                "term": "treatment_effect",
                "estimate": treatment_effect,
                "se": treatment_effect_se,
                "n_obs": n_obs,
            },
            {
                "term": "reduced_form",
                "estimate": reduced_form,
                "se": reduced_form_se,
                "n_obs": n_obs,
            },
            {
                "term": "first_stage",
                "estimate": first_stage,
                "se": first_stage_se,
                "n_obs": n_obs,
            },
        ],
        "method_metadata": {
            "estimator": "Fuzzy local-linear regression discontinuity with triangular weights, cutoff 0, bandwidth 1",
            "vcov": "Conventional heteroskedasticity-robust HC0; delta method with joint covariance",
        },
        "diagnostics": {},
    }

    with open("result.json", "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
