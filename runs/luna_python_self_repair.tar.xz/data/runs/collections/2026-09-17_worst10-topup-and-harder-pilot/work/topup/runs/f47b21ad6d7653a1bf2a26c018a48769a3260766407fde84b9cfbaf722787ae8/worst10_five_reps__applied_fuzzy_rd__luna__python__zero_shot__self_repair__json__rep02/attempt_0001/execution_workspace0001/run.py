import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df = df.loc[df["score"].abs() < 1].copy()

score = df["score"].to_numpy(dtype=float)
weights = 1.0 - np.abs(score)
right = score >= 0
left = score < 0

def fit_side(y, mask):
    x = score[mask]
    w = weights[mask]
    z = np.column_stack([np.ones(len(x)), x])
    yw = y[mask]

    bread = np.linalg.inv(z.T @ (w[:, None] * z))
    beta = bread @ (z.T @ (w * yw))
    residuals = yw - z @ beta

    meat = np.zeros((2, 2))
    for i in range(len(x)):
        zi = z[i:i + 1].T
        meat += (w[i] ** 2) * (residuals[i] ** 2) * (zi @ zi.T)

    covariance = bread @ meat @ bread
    return beta, covariance

def discontinuity(y):
    beta_r, cov_r = fit_side(y, right)
    beta_l, cov_l = fit_side(y, left)

    estimate = beta_r[0] - beta_l[0]
    variance = cov_r[0, 0] + cov_l[0, 0]
    return estimate, variance, cov_r, cov_l

earnings = df["earnings"].to_numpy(dtype=float)
participated = df["participated"].to_numpy(dtype=float)

reduced_form, var_rf, cov_rf_r, cov_rf_l = discontinuity(earnings)
first_stage, var_fs, cov_fs_r, cov_fs_l = discontinuity(participated)

def cross_covariance(y1, y2, mask):
    x = score[mask]
    w = weights[mask]
    z = np.column_stack([np.ones(len(x)), x])

    beta1, _ = fit_side(y1, mask)
    beta2, _ = fit_side(y2, mask)

    residuals1 = y1[mask] - z @ beta1
    residuals2 = y2[mask] - z @ beta2

    bread = np.linalg.inv(z.T @ (w[:, None] * z))
    meat = np.zeros((2, 2))
    for i in range(len(x)):
        zi = z[i:i + 1].T
        meat += (
            (w[i] ** 2)
            * residuals1[i]
            * residuals2[i]
            * (zi @ zi.T)
        )

    return bread @ meat @ bread

cross_r = cross_covariance(earnings, participated, right)
cross_l = cross_covariance(earnings, participated, left)
cov_rf_fs = cross_r[0, 0] + cross_l[0, 0]

n_obs = int(len(df))
se_rf = float(np.sqrt(var_rf))
se_fs = float(np.sqrt(var_fs))

if first_stage != 0:
    treatment_effect = reduced_form / first_stage
    var_te = (
        var_rf / first_stage**2
        + (reduced_form**2 * var_fs) / first_stage**4
        - 2 * reduced_form * cov_rf_fs / first_stage**3
    )
    se_te = float(np.sqrt(max(var_te, 0.0)))
else:
    treatment_effect = None
    se_te = None

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {
            "term": "treatment_effect",
            "estimate": treatment_effect,
            "se": se_te,
            "n_obs": n_obs,
        },
        {
            "term": "reduced_form",
            "estimate": float(reduced_form),
            "se": se_rf,
            "n_obs": n_obs,
        },
        {
            "term": "first_stage",
            "estimate": float(first_stage),
            "se": se_fs,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "Fuzzy local-linear regression discontinuity with triangular weights",
        "vcov": "Conventional heteroskedasticity-robust HC0 with delta method and joint covariance",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f)
