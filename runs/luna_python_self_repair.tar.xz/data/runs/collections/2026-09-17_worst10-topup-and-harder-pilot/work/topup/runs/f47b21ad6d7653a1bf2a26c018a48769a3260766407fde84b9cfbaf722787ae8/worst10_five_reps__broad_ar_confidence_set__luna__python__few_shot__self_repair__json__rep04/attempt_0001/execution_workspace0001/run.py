import json
import numpy as np
import pandas as pd
from scipy.stats import f

data = pd.read_csv("input.csv")

y = data["y"].to_numpy(dtype=float)
endog = data["endog"].to_numpy(dtype=float)
x = data["x"].to_numpy(dtype=float)
z1 = data["z1"].to_numpy(dtype=float)
z2 = data["z2"].to_numpy(dtype=float)

n = len(data)
controls = np.column_stack([np.ones(n), x])
full = np.column_stack([controls, z1, z2])

q = 2
df = n - 4
critical = f.ppf(0.95, q, df)
k = q * critical / df

def residualize(values, design):
    coefficients = np.linalg.lstsq(design, values, rcond=None)[0]
    return values - design @ coefficients

ry = residualize(y, controls)
re = residualize(endog, controls)
uy = residualize(y, full)
ue = residualize(endog, full)

a = re @ re - (1.0 + k) * (ue @ ue)
b = -2.0 * (ry @ re - (1.0 + k) * (uy @ ue))
c = ry @ ry - (1.0 + k) * (uy @ uy)

roots = np.roots([a, b, c])
boundaries = np.sort(roots.real)

def inequality(beta):
    restricted_ssr = np.sum((ry - beta * re) ** 2)
    unrestricted_ssr = np.sum((uy - beta * ue) ** 2)
    return restricted_ssr - (1.0 + k) * unrestricted_ssr

def ar_f(beta):
    restricted_ssr = np.sum((ry - beta * re) ** 2)
    unrestricted_ssr = np.sum((uy - beta * ue) ** 2)
    return ((restricted_ssr - unrestricted_ssr) / q) / (
        unrestricted_ssr / df
    )

accepts_zero = int(inequality(0.0) <= 0.0)
unbounded = int(a < 0.0)

rows = [
    {
        "term": "boundary_low",
        "estimate": float(boundaries[0]),
        "se": None,
        "n_obs": n,
    },
    {
        "term": "boundary_high",
        "estimate": float(boundaries[1]),
        "se": None,
        "n_obs": n,
    },
    {
        "term": "accepts_zero",
        "estimate": float(accepts_zero),
        "se": None,
        "n_obs": n,
    },
    {
        "term": "unbounded",
        "estimate": float(unbounded),
        "se": None,
        "n_obs": n,
    },
    {
        "term": "ar_f_at_one",
        "estimate": float(ar_f(1.0)),
        "se": None,
        "n_obs": n,
    },
]

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": rows,
    "method_metadata": {
        "estimator": "95 percent Anderson-Rubin confidence set",
        "vcov": "conventional homoskedastic joint F test",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
