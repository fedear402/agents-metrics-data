import json
import numpy as np
import pandas as pd
from scipy.stats import f as f_dist

df = pd.read_csv("input.csv")
n_obs = len(df)

y = df["y"].to_numpy(dtype=float)
endog = df["endog"].to_numpy(dtype=float)
x = df["x"].to_numpy(dtype=float)
z1 = df["z1"].to_numpy(dtype=float)
z2 = df["z2"].to_numpy(dtype=float)

controls = np.column_stack([np.ones(n_obs), x])
full = np.column_stack([np.ones(n_obs), x, z1, z2])

def residual_maker(X):
    q, _ = np.linalg.qr(X, mode="reduced")
    return np.eye(X.shape[0]) - q @ q.T

M_restricted = residual_maker(controls)
M_full = residual_maker(full)

df_num = 2
df_den = n_obs - 4
f_critical = f_dist.ppf(0.95, df_num, df_den)
factor = 1.0 + 2.0 * f_critical / df_den

def quadratic_form_coefficients(M):
    a = endog @ M @ endog
    b = -2.0 * (endog @ M @ y)
    c = y @ M @ y
    return np.array([a, b, c])

# Acceptance condition:
# SSR_restricted(beta) - factor * SSR_full(beta) <= 0
poly = (
    quadratic_form_coefficients(M_restricted)
    - factor * quadratic_form_coefficients(M_full)
)

scale = max(1.0, np.max(np.abs(poly)))
roots = np.roots(poly / scale)
real_roots = sorted(
    float(root.real)
    for root in roots
    if abs(root.imag) <= 1e-8 * max(1.0, abs(root.real))
)

if len(real_roots) >= 2:
    boundary_low = real_roots[0]
    boundary_high = real_roots[-1]
else:
    boundary_low = real_roots[0] if real_roots else float("nan")
    boundary_high = real_roots[-1] if real_roots else float("nan")

def ar_f(beta):
    transformed_y = y - beta * endog
    ssr_restricted = transformed_y @ M_restricted @ transformed_y
    ssr_full = transformed_y @ M_full @ transformed_y
    return ((ssr_restricted - ssr_full) / df_num) / (ssr_full / df_den)

def accepts(beta):
    return ar_f(beta) <= f_critical

leading = poly[0]
linear = poly[1]
tol = 1e-10 * scale

if abs(leading) > tol:
    unbounded = int(leading < 0)
elif abs(linear) > tol:
    unbounded = 1
else:
    unbounded = int(poly[2] <= tol)

estimates = [
    {
        "term": "boundary_low",
        "estimate": boundary_low,
        "se": None,
        "n_obs": n_obs,
    },
    {
        "term": "boundary_high",
        "estimate": boundary_high,
        "se": None,
        "n_obs": n_obs,
    },
    {
        "term": "accepts_zero",
        "estimate": float(int(accepts(0.0))),
        "se": None,
        "n_obs": n_obs,
    },
    {
        "term": "unbounded",
        "estimate": float(unbounded),
        "se": None,
        "n_obs": n_obs,
    },
    {
        "term": "ar_f_at_one",
        "estimate": ar_f(1.0),
        "se": None,
        "n_obs": n_obs,
    },
]

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "Anderson-Rubin confidence set inversion",
        "vcov": "conventional homoskedastic joint F test",
    },
    "diagnostics": {},
}

with open("result.json", "w") as file:
    json.dump(result, file, indent=2, allow_nan=False)
