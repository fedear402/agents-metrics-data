import json
import pandas as pd
from statsmodels.miscmodels.ordinal_model import OrderedModel

df = pd.read_csv("input.csv")

model = OrderedModel(
    endog=df["y"],
    exog=df[["x", "z"]],
    distr="logit",
)

fit = model.fit(method="bfgs", disp=False)

params = fit.params
ses = fit.bse

new_data = pd.DataFrame({"x": [1.0], "z": [0.0]})
prob_high = float(fit.predict(new_data)[0, 2])

result = {
    "task_id": "broad_ordered_logit",
    "platform": "python",
    "estimates": [
        {
            "term": "x",
            "estimate": float(params["x"]),
            "se": float(ses["x"]),
            "n_obs": int(len(df)),
        },
        {
            "term": "z",
            "estimate": float(params["z"]),
            "se": float(ses["z"]),
            "n_obs": int(len(df)),
        },
        {
            "term": "prob_high",
            "estimate": prob_high,
            "se": None,
            "n_obs": int(len(df)),
        },
    ],
    "method_metadata": {
        "estimator": "Maximum likelihood ordered logit",
        "vcov": "Conventional observed-information covariance",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
