import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
from statsmodels.stats.sandwich_covariance import cov_hac

df = pd.read_csv("input.csv")
df["date"] = pd.to_datetime(df["date"])
df = df.sort_values("date").reset_index(drop=True)

df["dlog_vix"] = np.log(df["vix"]).diff()

for lag in range(1, 16):
    df[f"lag_{lag}"] = df["dlog_vix"].shift(lag)

regressors = [f"lag_{lag}" for lag in range(1, 16)]
sample = df[["sales"] + regressors].dropna().copy()

y = np.log(sample["sales"].to_numpy(dtype=float))
X = sm.add_constant(sample[regressors].to_numpy(dtype=float), has_constant="add")

model = sm.OLS(y, X).fit()
n_obs = int(len(sample))

cov = cov_hac(
    model,
    nlags=15,
    weights_func=lambda j: 1.0 - j / 16.0,
    use_correction=False,
)
cov *= n_obs / (n_obs - 16)

params = model.params
se = np.sqrt(np.diag(cov))

lag_indices = np.arange(1, 16)
cumulative_estimate = float(params[lag_indices].sum())
cumulative_variance = float(cov[np.ix_(lag_indices, lag_indices)].sum())
cumulative_se = float(np.sqrt(max(cumulative_variance, 0.0)))

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {
            "term": "cumulative_response",
            "estimate": cumulative_estimate,
            "se": cumulative_se,
            "n_obs": n_obs,
        },
        {
            "term": "lag_1",
            "estimate": float(params[1]),
            "se": float(se[1]),
            "n_obs": n_obs,
        },
        {
            "term": "lag_15",
            "estimate": float(params[15]),
            "se": float(se[15]),
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "OLS of log(sales) on an intercept and lags 1 through 15 of first-differenced log(vix)",
        "vcov": "Newey-West HAC, maximum lag 15, Bartlett weights, covariance scaled by N/(N-16)",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
