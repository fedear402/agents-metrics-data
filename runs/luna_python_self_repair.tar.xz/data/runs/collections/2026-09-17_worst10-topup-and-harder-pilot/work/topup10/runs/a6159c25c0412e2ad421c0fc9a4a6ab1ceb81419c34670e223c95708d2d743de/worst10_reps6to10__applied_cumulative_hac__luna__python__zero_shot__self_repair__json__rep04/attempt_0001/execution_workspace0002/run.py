import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
from statsmodels.stats.sandwich_covariance import cov_hac


def bartlett_weights(nlags):
    j = np.arange(nlags + 1, dtype=float)
    return 1.0 - j / 16.0


df = pd.read_csv("input.csv")
df["date"] = pd.to_datetime(df["date"])
df = df.sort_values("date").reset_index(drop=True)

df["vol_change"] = np.log(df["vix"]).diff()
df["log_sales"] = np.log(df["sales"])

for lag in range(1, 16):
    df[f"lag_{lag}"] = df["vol_change"].shift(lag)

lag_columns = [f"lag_{lag}" for lag in range(1, 16)]
sample = df.dropna(subset=["log_sales"] + lag_columns)

y = sample["log_sales"].to_numpy(dtype=float)
X = sm.add_constant(sample[lag_columns].to_numpy(dtype=float), has_constant="add")

model = sm.OLS(y, X).fit()
n_obs = int(len(sample))

covariance = cov_hac(
    model,
    nlags=15,
    weights_func=bartlett_weights,
    use_correction=False,
)
covariance *= n_obs / (n_obs - 16)

beta = np.asarray(model.params, dtype=float)

cumulative_weights = np.zeros_like(beta)
cumulative_weights[1:] = 1.0

cumulative_estimate = float(cumulative_weights @ beta)
cumulative_variance = float(cumulative_weights @ covariance @ cumulative_weights)
cumulative_se = float(np.sqrt(max(cumulative_variance, 0.0)))

lag_1_index = 1
lag_15_index = 15

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {
            "term": "cumulative_response",
            "estimate": cumulative_estimate,
            "se": cumulative_se,
            "n_obs": n_obs,
        },
        {
            "term": "lag_1",
            "estimate": float(beta[lag_1_index]),
            "se": float(np.sqrt(max(float(covariance[lag_1_index, lag_1_index]), 0.0))),
            "n_obs": n_obs,
        },
        {
            "term": "lag_15",
            "estimate": float(beta[lag_15_index]),
            "se": float(np.sqrt(max(float(covariance[lag_15_index, lag_15_index]), 0.0))),
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "OLS with intercept and trading-observation lags 1 through 15 of first-differenced log volatility",
        "vcov": "Newey-West HAC covariance with maximum lag 15, Bartlett weights 1-j/16, scaled by N/(N-16)",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2)
