import json
import numpy as np
import pandas as pd


df = pd.read_csv("input.csv")
df["date"] = pd.to_datetime(df["date"])
df = df.sort_values("date").reset_index(drop=True)

df["log_sales"] = np.log(df["sales"])
df["vol_change"] = np.log(df["vix"]).diff()

for lag in range(1, 16):
    df[f"lag_{lag}"] = df["vol_change"].shift(lag)

reg = df.dropna(subset=["log_sales"] + [f"lag_{lag}" for lag in range(1, 16)]).copy()

y = reg["log_sales"].to_numpy(dtype=float)
lag_names = [f"lag_{lag}" for lag in range(1, 16)]
X = np.column_stack([
    np.ones(len(reg)),
    reg[lag_names].to_numpy(dtype=float),
])

n_obs = len(y)
beta = np.linalg.solve(X.T @ X, X.T @ y)
resid = y - X @ beta

bread = np.linalg.inv(X.T @ X)
scores = X * resid[:, None]

meat = scores.T @ scores
for j in range(1, 16):
    weight = 1.0 - j / 16.0
    meat += weight * (
        scores[j:].T @ scores[:-j]
        + scores[:-j].T @ scores[j:]
    )

cov = bread @ meat @ bread
cov *= n_obs / (n_obs - 16)

lag_coefficients = beta[1:]
cumulative_response = float(lag_coefficients.sum())
cumulative_se = float(
    np.sqrt(np.ones(15) @ cov[1:, 1:] @ np.ones(15))
)

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {
            "term": "cumulative_response",
            "estimate": cumulative_response,
            "se": cumulative_se,
            "n_obs": int(n_obs),
        },
        {
            "term": "lag_1",
            "estimate": float(beta[1]),
            "se": float(np.sqrt(cov[1, 1])),
            "n_obs": int(n_obs),
        },
        {
            "term": "lag_15",
            "estimate": float(beta[15]),
            "se": float(np.sqrt(cov[15, 15])),
            "n_obs": int(n_obs),
        },
    ],
    "method_metadata": {
        "estimator": "OLS with intercept and lags 1 through 15 of first differences in log volatility",
        "vcov": "Newey-West HAC covariance, maximum lag 15, Bartlett weights, scaled by N/(N-16)",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, ensure_ascii=False, indent=2)
