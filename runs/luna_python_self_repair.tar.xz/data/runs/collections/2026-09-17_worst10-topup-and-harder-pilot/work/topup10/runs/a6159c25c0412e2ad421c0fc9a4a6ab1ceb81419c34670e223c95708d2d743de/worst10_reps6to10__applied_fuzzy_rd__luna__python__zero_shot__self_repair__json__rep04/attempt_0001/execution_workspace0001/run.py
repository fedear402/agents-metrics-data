import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df = df[np.abs(df["score"]) < 1].copy()

x = df["score"].to_numpy(dtype=float)
w = 1.0 - np.abs(x)
side = (x >= 0).astype(int)

X = np.column_stack([np.ones(len(df)), x])
Y = df[["earnings", "participated"]].to_numpy(dtype=float)

coef = np.zeros((2, 2))
residuals = np.zeros_like(Y)
a = np.zeros((len(df), 2))

for s in (0, 1):
    idx = side == s
    Xs = X[idx]
    Ys = Y[idx]
    ws = w[idx]

    XtWX = Xs.T @ (ws[:, None] * Xs)
    inv_XtWX = np.linalg.inv(XtWX)
    betas = inv_XtWX @ (Xs.T @ (ws[:, None] * Ys))

    coef[s] = betas[0]
    residuals[idx] = Ys - Xs @ betas

    sign = -1.0 if s == 0 else 1.0
    a[idx] = sign * (inv_XtWX[0] @ (ws[:, None] * Xs)).ravel()

discontinuities = coef[1] - coef[0]

cov = np.zeros((2, 2))
for i in range(len(df)):
    cov += (a[i, :, None] @ a[i, None, :]) * w[i] * np.outer(
        residuals[i], residuals[i]
    )

reduced_form = discontinuities[0]
first_stage = discontinuities[1]

if np.isclose(first_stage, 0.0):
    treatment_effect = None
    treatment_se = None
else:
    treatment_effect = reduced_form / first_stage
    gradient = np.array([
        1.0 / first_stage,
        -reduced_form / (first_stage ** 2),
    ])
    treatment_variance = gradient @ cov @ gradient
    treatment_se = float(np.sqrt(max(treatment_variance, 0.0)))

n_obs = int(len(df))

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {
            "term": "treatment_effect",
            "estimate": treatment_effect,
            "se": treatment_se,
            "n_obs": n_obs,
        },
        {
            "term": "reduced_form",
            "estimate": float(reduced_form),
            "se": float(np.sqrt(max(cov[0, 0], 0.0))),
            "n_obs": n_obs,
        },
        {
            "term": "first_stage",
            "estimate": float(first_stage),
            "se": float(np.sqrt(max(cov[1, 1], 0.0))),
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "Fuzzy regression discontinuity with separate local-linear fits and triangular weights",
        "vcov": "Conventional heteroskedasticity-robust HC0 with joint delta-method covariance",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
