import json
import numpy as np
import pandas as pd

TASK_ID = "applied_fuzzy_rd"

data = pd.read_csv("input.csv")
sample = data.loc[data["score"].abs() < 1].copy()

score = sample["score"].to_numpy(dtype=float)
weights = 1.0 - np.abs(score)

left = score < 0
right = score >= 0

Z = np.zeros((len(sample), 4), dtype=float)
Z[left, 0] = 1.0
Z[left, 1] = score[left]
Z[right, 2] = 1.0
Z[right, 3] = score[right]

Y = sample[["earnings", "participated"]].to_numpy(dtype=float)
W = weights[:, None]

bread = np.linalg.inv(Z.T @ (W * Z))
coefficients = bread @ Z.T @ (W * Y)
residuals = Y - Z @ coefficients

contrast = np.array([-1.0, 0.0, 1.0, 0.0])
discontinuities = contrast @ coefficients

loading = weights * (Z @ bread @ contrast)
influence = loading[:, None] * residuals
joint_covariance = influence.T @ influence

reduced_form, first_stage = discontinuities
treatment_effect = reduced_form / first_stage

gradient = np.array([
    1.0 / first_stage,
    -reduced_form / (first_stage ** 2),
])
treatment_se = np.sqrt(gradient @ joint_covariance @ gradient)

n_obs = int(len(sample))

result = {
    "task_id": TASK_ID,
    "platform": "python",
    "estimates": [
        {
            "term": "treatment_effect",
            "estimate": float(treatment_effect),
            "se": float(treatment_se),
            "n_obs": n_obs,
        },
        {
            "term": "reduced_form",
            "estimate": float(reduced_form),
            "se": float(np.sqrt(joint_covariance[0, 0])),
            "n_obs": n_obs,
        },
        {
            "term": "first_stage",
            "estimate": float(first_stage),
            "se": float(np.sqrt(joint_covariance[1, 1])),
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "fuzzy local-linear regression discontinuity with triangular kernel",
        "vcov": "conventional heteroskedasticity-robust HC0 with delta method",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
