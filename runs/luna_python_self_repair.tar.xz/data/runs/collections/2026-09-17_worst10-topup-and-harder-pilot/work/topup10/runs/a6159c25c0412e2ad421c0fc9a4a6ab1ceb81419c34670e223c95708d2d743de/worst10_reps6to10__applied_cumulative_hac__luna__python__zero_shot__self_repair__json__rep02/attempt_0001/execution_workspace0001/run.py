import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df["date"] = pd.to_datetime(df["date"])
df = df.sort_values("date").reset_index(drop=True)

df["log_sales"] = np.log(df["sales"])
df["log_vix"] = np.log(df["vix"])
df["vol_change"] = df["log_vix"].diff()

for lag in range(1, 16):
    df[f"lag_{lag}"] = df["vol_change"].shift(lag)

reg_cols = [f"lag_{lag}" for lag in range(1, 16)]
sample = df.dropna(subset=["log_sales"] + reg_cols).copy()

y = sample["log_sales"].to_numpy(dtype=float)
X = np.column_stack(
    [np.ones(len(sample))]
    + [sample[col].to_numpy(dtype=float) for col in reg_cols]
)

n_obs = len(y)
beta = np.linalg.solve(X.T @ X, X.T @ y)
resid = y - X @ beta

bread = np.linalg.inv(X.T @ X)
meat = X.T @ (resid[:, None] * resid[:, None] * X)

for j in range(1, 16):
    weight = 1.0 - j / 16.0
    gamma_j = (X[j:].T * (resid[j:] * resid[:-j])) @ X[:-j]
    meat += weight * (gamma_j + gamma_j.T)

cov = bread @ meat @ bread
cov *= n_obs / (n_obs - 16)

cum_vector = np.zeros(16)
cum_vector[1:] = 1.0
cumulative_response = float(cum_vector @ beta)
cumulative_se = float(np.sqrt(cum_vector @ cov @ cum_vector))

lag_1_index = 1
lag_15_index = 15

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {
            "term": "cumulative_response",
            "estimate": cumulative_response,
            "se": cumulative_se,
            "n_obs": int(n_obs),
        },
        {
            "term": "lag_1",
            "estimate": float(beta[lag_1_index]),
            "se": float(np.sqrt(cov[lag_1_index, lag_1_index])),
            "n_obs": int(n_obs),
        },
        {
            "term": "lag_15",
            "estimate": float(beta[lag_15_index]),
            "se": float(np.sqrt(cov[lag_15_index, lag_15_index])),
            "n_obs": int(n_obs),
        },
    ],
    "method_metadata": {
        "estimator": "OLS with intercept and lags 1 through 15 of first differences in log volatility",
        "vcov": "Newey-West HAC covariance with maximum lag 15, Bartlett weights, and N/(N-16) scaling",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file, ensure_ascii=False, indent=2)
