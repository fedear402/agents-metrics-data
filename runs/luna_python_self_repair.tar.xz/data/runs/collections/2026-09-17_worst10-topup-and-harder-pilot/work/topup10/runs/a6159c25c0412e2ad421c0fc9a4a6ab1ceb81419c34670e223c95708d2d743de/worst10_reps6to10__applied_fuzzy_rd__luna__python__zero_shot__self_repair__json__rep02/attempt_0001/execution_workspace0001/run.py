import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")

sample = df.loc[df["score"].abs() < 1].copy()
x = sample["score"].to_numpy(dtype=float)
right = (x >= 0).astype(float)
weights = 1.0 - np.abs(x)

X = np.column_stack([np.ones(len(x)), right, x, right * x])
W = np.diag(weights)

bread = np.linalg.pinv(X.T @ W @ X)

def fit_outcome(values):
    y = np.asarray(values, dtype=float)
    beta = bread @ (X.T @ W @ y)
    residuals = y - X @ beta
    return beta, residuals

earnings_beta, earnings_resid = fit_outcome(sample["earnings"])
participation_beta, participation_resid = fit_outcome(sample["participated"])

meat_ee = X.T @ np.diag((weights * earnings_resid) ** 2) @ X
meat_pp = X.T @ np.diag((weights * participation_resid) ** 2) @ X
meat_ep = X.T @ np.diag(
    weights ** 2 * earnings_resid * participation_resid
) @ X

cov_ee = bread @ meat_ee @ bread
cov_pp = bread @ meat_pp @ bread
cov_ep = bread @ meat_ep @ bread

reduced_form = float(earnings_beta[1])
first_stage = float(participation_beta[1])

var_reduced_form = float(cov_ee[1, 1])
var_first_stage = float(cov_pp[1, 1])
cov_discontinuities = float(cov_ep[1, 1])

if np.isfinite(first_stage) and first_stage != 0:
    treatment_effect = reduced_form / first_stage
    var_treatment = (
        var_reduced_form / first_stage**2
        + reduced_form**2 * var_first_stage / first_stage**4
        - 2 * reduced_form * cov_discontinuities / first_stage**3
    )
    se_treatment = float(np.sqrt(max(var_treatment, 0.0)))
else:
    treatment_effect = None
    se_treatment = None

n_obs = int(len(sample))

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {
            "term": "treatment_effect",
            "estimate": treatment_effect,
            "se": se_treatment,
            "n_obs": n_obs,
        },
        {
            "term": "reduced_form",
            "estimate": reduced_form,
            "se": float(np.sqrt(max(var_reduced_form, 0.0))),
            "n_obs": n_obs,
        },
        {
            "term": "first_stage",
            "estimate": first_stage,
            "se": float(np.sqrt(max(var_first_stage, 0.0))),
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "fuzzy local-linear regression discontinuity with triangular weights",
        "vcov": "conventional heteroskedasticity-robust HC0 with joint delta method covariance",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file, indent=2, allow_nan=False)
