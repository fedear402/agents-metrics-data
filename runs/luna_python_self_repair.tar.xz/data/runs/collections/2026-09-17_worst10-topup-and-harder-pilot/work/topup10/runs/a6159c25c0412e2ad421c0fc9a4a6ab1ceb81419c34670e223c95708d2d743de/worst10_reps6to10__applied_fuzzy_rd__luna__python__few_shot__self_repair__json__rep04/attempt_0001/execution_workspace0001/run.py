import json
import numpy as np
import pandas as pd

TASK_ID = "applied_fuzzy_rd"

data = pd.read_csv("input.csv")
data = data.loc[data["score"].abs() < 1].copy()

score = data["score"].to_numpy(dtype=float)
weights = 1.0 - np.abs(score)
right = (score >= 0).astype(float)
left = 1.0 - right

X = np.column_stack([
    left,
    left * score,
    right,
    right * score,
])

W = np.diag(weights)
bread = np.linalg.inv(X.T @ W @ X)

outcomes = np.column_stack([
    data["earnings"].to_numpy(dtype=float),
    data["participated"].to_numpy(dtype=float),
])

coefficients = bread @ X.T @ W @ outcomes
fitted = X @ coefficients
residuals = outcomes - fitted

# Right-limit intercept minus left-limit intercept.
contrast = np.array([-1.0, 0.0, 1.0, 0.0])
discontinuities = contrast @ coefficients

# Joint HC0 covariance for the two discontinuity estimates.
loading = X @ bread @ contrast
influence = (weights * loading)[:, None] * residuals
joint_covariance = influence.T @ influence

reduced_form, first_stage = discontinuities
treatment_effect = reduced_form / first_stage

gradient = np.array([
    1.0 / first_stage,
    -reduced_form / (first_stage ** 2),
])
treatment_se = np.sqrt(gradient @ joint_covariance @ gradient)

n_obs = int(len(data))

result = {
    "task_id": TASK_ID,
    "platform": "python",
    "estimates": [
        {
            "term": "treatment_effect",
            "estimate": float(treatment_effect),
            "se": float(treatment_se),
            "n_obs": n_obs,
        },
        {
            "term": "reduced_form",
            "estimate": float(reduced_form),
            "se": float(np.sqrt(joint_covariance[0, 0])),
            "n_obs": n_obs,
        },
        {
            "term": "first_stage",
            "estimate": float(first_stage),
            "se": float(np.sqrt(joint_covariance[1, 1])),
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "Fuzzy local-linear regression discontinuity with triangular weights",
        "vcov": "Conventional heteroskedasticity-robust HC0 with joint delta-method covariance",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
