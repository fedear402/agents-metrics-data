import json
import numpy as np
import pandas as pd

data = pd.read_csv("input.csv")

data = data.loc[data["score"].abs() < 1].copy()
data["right"] = (data["score"] >= 0).astype(float)
data["weight"] = 1.0 - data["score"].abs()

x = data["score"].to_numpy(dtype=float)
r = data["right"].to_numpy(dtype=float)
w = data["weight"].to_numpy(dtype=float)

X = np.column_stack([
    np.ones(len(data)),
    r,
    x,
    r * x,
])

W = np.diag(w)
bread = np.linalg.pinv(X.T @ W @ X)

outcomes = {
    "reduced_form": data["earnings"].to_numpy(dtype=float),
    "first_stage": data["participated"].to_numpy(dtype=float),
}

estimates = {}
covariances = {}

for name, y in outcomes.items():
    beta = bread @ (X.T @ W @ y)
    residuals = y - X @ beta
    meat = X.T @ np.diag((w * residuals) ** 2) @ X
    vcov = bread @ meat @ bread

    estimates[name] = float(beta[1])
    covariances[name] = vcov

reduced_form = estimates["reduced_form"]
first_stage = estimates["first_stage"]

if np.isclose(first_stage, 0.0):
    treatment_effect = None
    treatment_se = None
else:
    treatment_effect = reduced_form / first_stage

    cross_meat = (
        X.T
        @ np.diag(w**2 * (outcomes["reduced_form"] - X @ (
            bread @ (X.T @ W @ outcomes["reduced_form"])
        )) * (outcomes["first_stage"] - X @ (
            bread @ (X.T @ W @ outcomes["first_stage"])
        )))
        @ X
    )
    cross_vcov = bread @ cross_meat @ bread

    var_rf = covariances["reduced_form"][1, 1]
    var_fs = covariances["first_stage"][1, 1]
    cov_rf_fs = cross_vcov[1, 1]

    var_ratio = (
        var_rf / first_stage**2
        + reduced_form**2 * var_fs / first_stage**4
        - 2.0 * reduced_form * cov_rf_fs / first_stage**3
    )
    treatment_se = float(np.sqrt(max(var_ratio, 0.0)))

def se_for(name):
    return float(np.sqrt(max(covariances[name][1, 1], 0.0)))

n_obs = int(len(data))

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {
            "term": "treatment_effect",
            "estimate": treatment_effect,
            "se": treatment_se,
            "n_obs": n_obs,
        },
        {
            "term": "reduced_form",
            "estimate": reduced_form,
            "se": se_for("reduced_form"),
            "n_obs": n_obs,
        },
        {
            "term": "first_stage",
            "estimate": first_stage,
            "se": se_for("first_stage"),
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "fuzzy local-linear regression discontinuity with triangular kernel, bandwidth 1",
        "vcov": "conventional heteroskedasticity-robust HC0 with joint delta-method covariance",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2, allow_nan=False)
