import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df = df.loc[df["score"].abs() < 1].copy()

score = df["score"].to_numpy(dtype=float)
weights = 1.0 - np.abs(score)
side = score >= 0

outcomes = [
    df["earnings"].to_numpy(dtype=float),
    df["participated"].to_numpy(dtype=float),
]

estimates = []
betas = []
residuals = []

for y in outcomes:
    beta = {}
    resid = np.full(len(df), np.nan)

    for label, mask in [("left", ~side), ("right", side)]:
        x = score[mask]
        w = weights[mask]
        yy = y[mask]
        X = np.column_stack((np.ones(len(x)), x))

        xtwx = X.T @ (w[:, None] * X)
        xtwy = X.T @ (w * yy)
        b = np.linalg.solve(xtwx, xtwy)

        beta[label] = b
        resid[mask] = yy - X @ b

    betas.append(beta)
    residuals.append(resid)

    discontinuity = beta["right"][0] - beta["left"][0]
    estimates.append(discontinuity)

# Joint HC0 covariance matrix for the two discontinuity estimates.
joint_cov = np.zeros((2, 2))

for mask in [~side, side]:
    x = score[mask]
    w = weights[mask]
    X = np.column_stack((np.ones(len(x)), x))
    sign = -1.0 if np.array_equal(mask, ~side) else 1.0

    bread = np.linalg.inv(X.T @ (w[:, None] * X))
    q = (bread @ X.T @ np.diag(w)).T

    e_earnings = residuals[0][mask]
    e_participated = residuals[1][mask]

    joint_cov[0, 0] += np.sum((sign * q[:, 0]) ** 2 * e_earnings ** 2)
    joint_cov[1, 1] += np.sum((sign * q[:, 0]) ** 2 * e_participated ** 2)
    joint_cov[0, 1] += np.sum(
        (sign * q[:, 0]) ** 2 * e_earnings * e_participated
    )
    joint_cov[1, 0] = joint_cov[0, 1]

rf = estimates[0]
fs = estimates[1]

rf_se = np.sqrt(joint_cov[0, 0])
fs_se = np.sqrt(joint_cov[1, 1])

if np.isfinite(fs) and fs != 0:
    treatment_effect = rf / fs
    gradient = np.array([1.0 / fs, -rf / (fs ** 2)])
    treatment_var = gradient @ joint_cov @ gradient
    treatment_se = np.sqrt(max(treatment_var, 0.0))
else:
    treatment_effect = None
    treatment_se = None

n_obs = int(len(df))

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {
            "term": "treatment_effect",
            "estimate": treatment_effect,
            "se": treatment_se,
            "n_obs": n_obs,
        },
        {
            "term": "reduced_form",
            "estimate": rf,
            "se": rf_se,
            "n_obs": n_obs,
        },
        {
            "term": "first_stage",
            "estimate": fs,
            "se": fs_se,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "Fuzzy local-linear regression discontinuity with triangular weights",
        "vcov": "Conventional heteroskedasticity-robust HC0 with delta-method treatment-effect standard error",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2, allow_nan=False)
