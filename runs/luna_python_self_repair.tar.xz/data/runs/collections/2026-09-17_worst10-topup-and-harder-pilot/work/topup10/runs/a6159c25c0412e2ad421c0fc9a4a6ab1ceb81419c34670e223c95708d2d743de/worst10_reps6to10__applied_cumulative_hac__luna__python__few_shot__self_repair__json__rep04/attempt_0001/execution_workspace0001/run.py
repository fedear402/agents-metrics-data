import json
import numpy as np
import pandas as pd

data = pd.read_csv("input.csv", parse_dates=["date"])
data = data.sort_values("date").reset_index(drop=True)

data["log_vix_change"] = np.log(data["vix"]).diff()
data["log_sales"] = np.log(data["sales"])

for lag in range(1, 16):
    data[f"lag_{lag}"] = data["log_vix_change"].shift(lag)

lag_columns = [f"lag_{lag}" for lag in range(1, 16)]
sample = data.dropna(subset=["log_sales"] + lag_columns).copy()

N = len(sample)
X = np.column_stack([
    np.ones(N),
    sample[lag_columns].to_numpy()
])
y = sample["log_sales"].to_numpy()

coefficients = np.linalg.lstsq(X, y, rcond=None)[0]
residuals = y - X @ coefficients

scores = X * residuals[:, None]
meat = scores.T @ scores

hac_lags = 15
for j in range(1, hac_lags + 1):
    weight = 1 - j / 16
    lag_product = scores[j:].T @ scores[:-j]
    meat += weight * (lag_product + lag_product.T)

bread = np.linalg.inv(X.T @ X)
p = X.shape[1]
covariance = (N / (N - 16)) * bread @ meat @ bread

contrast = np.zeros(p)
contrast[1:] = 1

cumulative_estimate = float(contrast @ coefficients)
cumulative_se = float(
    np.sqrt(max(0.0, contrast @ covariance @ contrast))
)
lag_1_estimate = float(coefficients[1])
lag_1_se = float(np.sqrt(max(0.0, covariance[1, 1])))
lag_15_estimate = float(coefficients[15])
lag_15_se = float(np.sqrt(max(0.0, covariance[15, 15])))

output = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {
            "term": "cumulative_response",
            "estimate": cumulative_estimate,
            "se": cumulative_se,
            "n_obs": N,
        },
        {
            "term": "lag_1",
            "estimate": lag_1_estimate,
            "se": lag_1_se,
            "n_obs": N,
        },
        {
            "term": "lag_15",
            "estimate": lag_15_estimate,
            "se": lag_15_se,
            "n_obs": N,
        },
    ],
    "method_metadata": {
        "estimator": "OLS with intercept and 15 lags of log volatility changes",
        "vcov": "Newey-West HAC covariance with Bartlett weights through lag 15 and N/(N-16) correction",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
