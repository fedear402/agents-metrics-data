import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df["date"] = pd.to_datetime(df["date"])
df = df.sort_values("date").reset_index(drop=True)

df["log_sales"] = np.log(df["sales"])
df["vol_change"] = np.log(df["vix"]).diff()

for lag in range(1, 16):
    df[f"lag_{lag}"] = df["vol_change"].shift(lag)

reg = df.dropna(subset=["log_sales"] + [f"lag_{lag}" for lag in range(1, 16)]).copy()

y = reg["log_sales"].to_numpy(dtype=float)
X = np.column_stack([
    np.ones(len(reg)),
    reg[[f"lag_{lag}" for lag in range(1, 16)]].to_numpy(dtype=float)
])

n_obs = len(y)
beta = np.linalg.lstsq(X, y, rcond=None)[0]
resid = y - X @ beta

xtx_inv = np.linalg.inv(X.T @ X)
scores = X * resid[:, None]

S = scores.T @ scores
for j in range(1, 16):
    weight = 1.0 - j / 16.0
    S += weight * (
        scores[j:].T @ scores[:-j]
        + scores[:-j].T @ scores[j:]
    )

cov = xtx_inv @ S @ xtx_inv
cov *= n_obs / (n_obs - 16)

cumulative_vector = np.zeros(16)
cumulative_vector[1:] = 1.0

estimates = {
    "cumulative_response": float(cumulative_vector @ beta),
    "lag_1": float(beta[1]),
    "lag_15": float(beta[15]),
}

standard_errors = {
    "cumulative_response": float(
        np.sqrt(cumulative_vector @ cov @ cumulative_vector)
    ),
    "lag_1": float(np.sqrt(cov[1, 1])),
    "lag_15": float(np.sqrt(cov[15, 15])),
}

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {
            "term": term,
            "estimate": estimates[term],
            "se": standard_errors[term],
            "n_obs": int(n_obs),
        }
        for term in ["cumulative_response", "lag_1", "lag_15"]
    ],
    "method_metadata": {
        "estimator": "OLS with intercept and lags 1 through 15 of first differences in log(vix)",
        "vcov": "Newey-West HAC with Bartlett weights through lag 15, scaled by N/(N-16)",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
