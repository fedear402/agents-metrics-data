import json
import numpy as np
import pandas as pd

data = pd.read_csv("input.csv")
data["date"] = pd.to_datetime(data["date"])
data = data.sort_values("date").reset_index(drop=True)

data["log_vix"] = np.log(data["vix"])
data["vix_change"] = data["log_vix"].diff()
data["log_sales"] = np.log(data["sales"])

for lag in range(1, 16):
    data[f"lag_{lag}"] = data["vix_change"].shift(lag)

lag_columns = [f"lag_{lag}" for lag in range(1, 16)]
sample = data.dropna(subset=["log_sales"] + lag_columns).copy()

y = sample["log_sales"].to_numpy()
X = np.column_stack([
    np.ones(len(sample)),
    sample[lag_columns].to_numpy()
])

N = len(sample)
coefficients = np.linalg.lstsq(X, y, rcond=None)[0]
residuals = y - X @ coefficients

scores = X * residuals[:, None]
meat = scores.T @ scores

hac_lags = 15
for j in range(1, hac_lags + 1):
    weight = 1 - j / 16
    lag_product = scores[j:].T @ scores[:-j]
    meat += weight * (lag_product + lag_product.T)

bread = np.linalg.inv(X.T @ X)
covariance = (N / (N - 16)) * bread @ meat @ bread

contrast = np.zeros(16)
contrast[1:] = 1.0

cumulative_response = float(contrast @ coefficients)
cumulative_se = float(np.sqrt(contrast @ covariance @ contrast))

rows = [
    {
        "term": "cumulative_response",
        "estimate": cumulative_response,
        "se": cumulative_se,
        "n_obs": N,
    },
    {
        "term": "lag_1",
        "estimate": float(coefficients[1]),
        "se": float(np.sqrt(covariance[1, 1])),
        "n_obs": N,
    },
    {
        "term": "lag_15",
        "estimate": float(coefficients[15]),
        "se": float(np.sqrt(covariance[15, 15])),
        "n_obs": N,
    },
]

output = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": rows,
    "method_metadata": {
        "estimator": "OLS with intercept and lags 1 through 15 of log volatility changes",
        "vcov": "Bartlett Newey-West HAC covariance with maximum lag 15 and N/(N-16) correction",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
