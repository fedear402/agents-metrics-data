import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df = df.loc[df["score"].abs() < 1].copy()

x = df["score"].to_numpy(dtype=float)
right = (x >= 0).astype(float)
weights = 1.0 - np.abs(x)

X = np.column_stack([
    np.ones(len(df)),
    x,
    right,
    right * x,
])

Y = df[["earnings", "participated"]].to_numpy(dtype=float)

sqrt_w = np.sqrt(weights)
Xw = X * sqrt_w[:, None]
bread = np.linalg.inv(X.T @ (weights[:, None] * X))
coefficients = bread @ X.T @ (weights[:, None] * Y)
residuals = Y - X @ coefficients

# HC0 joint covariance for the two discontinuity estimates.
meat = np.zeros((X.shape[1], X.shape[1], 2, 2))
for i in range(len(df)):
    xi = X[i][:, None]
    residual_outer = np.outer(residuals[i], residuals[i])
    meat[:, :, :, :] += (
        weights[i] ** 2
        * (xi @ xi.T)[:, :, None, None]
        * residual_outer[None, None, :, :]
    )

covariance = np.empty((2, 2))
jump_index = 2

for a in range(2):
    for b in range(2):
        covariance[a, b] = (
            bread @ meat[:, :, a, b] @ bread
        )[jump_index, jump_index]

jumps = coefficients[jump_index, :]
earnings_jump, participation_jump = jumps

gradient = np.array([
    1.0 / participation_jump,
    -earnings_jump / (participation_jump ** 2),
])

treatment_effect = earnings_jump / participation_jump
treatment_variance = gradient @ covariance @ gradient
n_obs = int(len(df))

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {
            "term": "treatment_effect",
            "estimate": float(treatment_effect),
            "se": float(np.sqrt(treatment_variance)),
            "n_obs": n_obs,
        },
        {
            "term": "reduced_form",
            "estimate": float(earnings_jump),
            "se": float(np.sqrt(covariance[0, 0])),
            "n_obs": n_obs,
        },
        {
            "term": "first_stage",
            "estimate": float(participation_jump),
            "se": float(np.sqrt(covariance[1, 1])),
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "triangular-weighted local-linear fuzzy regression discontinuity",
        "vcov": "conventional heteroskedasticity-robust HC0 with joint covariance and delta method",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
