import json
import numpy as np
import pandas as pd

data = pd.read_csv("input.csv")
data["date"] = pd.to_datetime(data["date"])
data = data.sort_values("date").reset_index(drop=True)

data["volatility_change"] = np.log(data["vix"]).diff()

for lag in range(1, 16):
    data[f"lag_{lag}"] = data["volatility_change"].shift(lag)

data["log_sales"] = np.log(data["sales"])
lag_columns = [f"lag_{lag}" for lag in range(1, 16)]
sample = data.dropna(subset=["log_sales"] + lag_columns).reset_index(drop=True)

y = sample["log_sales"].to_numpy(dtype=float)
X = np.column_stack([
    np.ones(len(sample)),
    sample[lag_columns].to_numpy(dtype=float)
])

N = len(sample)
coefficients = np.linalg.lstsq(X, y, rcond=None)[0]
residuals = y - X @ coefficients

scores = X * residuals[:, None]
meat = scores.T @ scores

hac_lags = 15
for j in range(1, hac_lags + 1):
    weight = 1.0 - j / 16.0
    lag_product = scores[j:].T @ scores[:-j]
    meat += weight * (lag_product + lag_product.T)

bread = np.linalg.inv(X.T @ X)
covariance = (N / (N - 16)) * bread @ meat @ bread

contrast = np.zeros(16)
contrast[1:] = 1.0

cumulative_estimate = float(contrast @ coefficients)
cumulative_se = float(np.sqrt(contrast @ covariance @ contrast))
lag_1_estimate = float(coefficients[1])
lag_1_se = float(np.sqrt(covariance[1, 1]))
lag_15_estimate = float(coefficients[15])
lag_15_se = float(np.sqrt(covariance[15, 15]))

output = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {
            "term": "cumulative_response",
            "estimate": cumulative_estimate,
            "se": cumulative_se,
            "n_obs": N
        },
        {
            "term": "lag_1",
            "estimate": lag_1_estimate,
            "se": lag_1_se,
            "n_obs": N
        },
        {
            "term": "lag_15",
            "estimate": lag_15_estimate,
            "se": lag_15_se,
            "n_obs": N
        }
    ],
    "method_metadata": {
        "estimator": "OLS with intercept and lags 1 through 15 of log volatility changes",
        "vcov": "Bartlett Newey-West HAC covariance with maximum lag 15 and N/(N-16) correction"
    },
    "diagnostics": {}
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
