import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df = df.loc[df["score"].abs() < 1].copy()

x = df["score"].to_numpy(dtype=float)
y = df["earnings"].to_numpy(dtype=float)
p = df["participated"].to_numpy(dtype=float)

right = (x >= 0).astype(float)
weights = 1.0 - np.abs(x)

X = np.column_stack([
    np.ones(len(x)),
    x,
    right,
    right * x,
])

bread = np.linalg.inv(X.T @ (weights[:, None] * X))

def fit_outcome(outcome):
    beta = bread @ (X.T @ (weights * outcome))
    residuals = outcome - X @ beta
    meat = X.T @ ((weights ** 2 * residuals ** 2)[:, None] * X)
    covariance = bread @ meat @ bread
    return beta, covariance

beta_rf, vcov_rf = fit_outcome(y)
beta_fs, vcov_fs = fit_outcome(p)

reduced_form = float(beta_rf[2])
first_stage = float(beta_fs[2])

var_rf = float(vcov_rf[2, 2])
var_fs = float(vcov_fs[2, 2])

cross_meat = X.T @ ((weights ** 2 * (y - X @ beta_rf) *
                     (p - X @ beta_fs))[:, None] * X)
cross_vcov = bread @ cross_meat @ bread
cov_rf_fs = float(cross_vcov[2, 2])

if first_stage == 0:
    treatment_effect = None
    treatment_se = None
else:
    treatment_effect = reduced_form / first_stage
    treatment_variance = (
        var_rf
        + treatment_effect ** 2 * var_fs
        - 2.0 * treatment_effect * cov_rf_fs
    ) / first_stage ** 2
    treatment_se = float(np.sqrt(max(treatment_variance, 0.0)))

n_obs = int(len(df))

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {
            "term": "treatment_effect",
            "estimate": treatment_effect,
            "se": treatment_se,
            "n_obs": n_obs,
        },
        {
            "term": "reduced_form",
            "estimate": reduced_form,
            "se": float(np.sqrt(max(var_rf, 0.0))),
            "n_obs": n_obs,
        },
        {
            "term": "first_stage",
            "estimate": first_stage,
            "se": float(np.sqrt(max(var_fs, 0.0))),
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "fuzzy local-linear regression discontinuity with triangular weights",
        "vcov": "HC0 sandwich covariance with delta-method ratio standard error",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2, allow_nan=False)
