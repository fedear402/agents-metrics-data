import json
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.special import log_ndtr
from scipy.optimize._numdiff import approx_derivative

df = pd.read_csv("input.csv")

y = df["y"].to_numpy(dtype=float)
X = np.column_stack([
    np.ones(len(df)),
    df["x"].to_numpy(dtype=float),
    df["z"].to_numpy(dtype=float),
])

censored = y <= 0
uncensored = ~censored
n_obs = int(len(df))

def loglike(theta):
    beta = theta[:3]
    sigma = np.exp(theta[3])
    mu = X @ beta
    ll = np.empty(n_obs)

    residual = (y[uncensored] - mu[uncensored]) / sigma
    ll[uncensored] = (
        -0.5 * np.log(2 * np.pi)
        - np.log(sigma)
        - 0.5 * residual**2
    )

    a = -mu[censored] / sigma
    ll[censored] = log_ndtr(a)

    return np.sum(ll)

def score(theta):
    beta = theta[:3]
    sigma = np.exp(theta[3])
    mu = X @ beta
    grad_beta = np.zeros(3)
    grad_eta = 0.0

    if np.any(uncensored):
        residual = y[uncensored] - mu[uncensored]
        grad_beta += X[uncensored].T @ (residual / sigma**2)
        grad_eta += np.sum(-1.0 + residual**2 / sigma**2)

    if np.any(censored):
        a = -mu[censored] / sigma
        mills_ratio = np.exp(
            -0.5 * a**2 - 0.5 * np.log(2 * np.pi) - log_ndtr(a)
        )
        grad_beta += X[censored].T @ (-mills_ratio / sigma)
        grad_eta += np.sum(mills_ratio * mu[censored] / sigma)

    return np.r_[grad_beta, grad_eta]

beta_start = np.linalg.lstsq(X, np.maximum(y, 1e-8), rcond=None)[0]
sigma_start = np.std(y - X @ beta_start)
if not np.isfinite(sigma_start) or sigma_start <= 0:
    sigma_start = 1.0

theta_start = np.r_[beta_start, np.log(sigma_start)]

fit = minimize(
    lambda t: -loglike(t),
    theta_start,
    jac=lambda t: -score(t),
    method="BFGS",
    options={"gtol": 1e-10, "maxiter": 2000},
)

if not fit.success:
    fit = minimize(
        lambda t: -loglike(t),
        fit.x,
        jac=lambda t: -score(t),
        method="L-BFGS-B",
        options={"ftol": 1e-15, "gtol": 1e-10, "maxiter": 5000},
    )

theta_hat = fit.x
beta_hat = theta_hat[:3]
sigma_hat = float(np.exp(theta_hat[3]))

hessian = approx_derivative(
    score,
    theta_hat,
    method="3-point",
    rel_step=1e-5,
)
hessian = 0.5 * (hessian + hessian.T)
observed_information = -hessian
covariance = np.linalg.pinv(observed_information)
covariance = 0.5 * (covariance + covariance.T)

se_beta = np.sqrt(np.maximum(np.diag(covariance)[:3], 0.0))
se_sigma = float(
    sigma_hat * np.sqrt(max(float(covariance[3, 3]), 0.0))
)

estimates = [
    {
        "term": "const",
        "estimate": float(beta_hat[0]),
        "se": float(se_beta[0]),
        "n_obs": n_obs,
    },
    {
        "term": "x",
        "estimate": float(beta_hat[1]),
        "se": float(se_beta[1]),
        "n_obs": n_obs,
    },
    {
        "term": "z",
        "estimate": float(beta_hat[2]),
        "se": float(se_beta[2]),
        "n_obs": n_obs,
    },
    {
        "term": "sigma",
        "estimate": sigma_hat,
        "se": se_sigma,
        "n_obs": n_obs,
    },
]

result = {
    "task_id": "broad_tobit",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "Homoskedastic Gaussian Tobit maximum likelihood",
        "vcov": "Inverse observed information from the jointly estimated likelihood",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
