import json
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.stats import norm
from statsmodels.tools.numdiff import approx_hess

data = pd.read_csv("input.csv")

y = data["y"].to_numpy(dtype=float)
X = np.column_stack([
    np.ones(len(data)),
    data["x"].to_numpy(dtype=float),
    data["z"].to_numpy(dtype=float),
])

censored = y <= 0
uncensored = ~censored
n_obs = len(y)


def loss(parameter):
    beta = parameter[:3]
    log_sigma = parameter[3]
    sigma = np.exp(log_sigma)
    mu = X @ beta

    value = 0.0

    if censored.any():
        a = -mu[censored] / sigma
        value -= np.sum(norm.logcdf(a))

    if uncensored.any():
        r = (y[uncensored] - mu[uncensored]) / sigma
        value -= np.sum(norm.logpdf(r) - log_sigma)

    return float(value)


def gradient(parameter):
    beta = parameter[:3]
    log_sigma = parameter[3]
    sigma = np.exp(log_sigma)
    mu = X @ beta

    score_beta = np.zeros(3)
    score_log_sigma = 0.0

    if censored.any():
        a = -mu[censored] / sigma
        mills = np.exp(norm.logpdf(a) - norm.logcdf(a))
        score_beta += X[censored].T @ (mills / sigma)
        score_log_sigma += np.sum(a * mills)

    if uncensored.any():
        r = (y[uncensored] - mu[uncensored]) / sigma
        score_beta -= X[uncensored].T @ (r / sigma)
        score_log_sigma += np.sum(1.0 - r * r)

    return np.r_[score_beta, score_log_sigma]


positive_y = y[uncensored]
if uncensored.any():
    beta_start = np.linalg.lstsq(X, np.where(censored, 0.0, y), rcond=None)[0]
    residuals = positive_y - X[uncensored] @ beta_start
    sigma_start = np.std(residuals)
else:
    beta_start = np.zeros(3)
    sigma_start = 1.0

if not np.isfinite(sigma_start) or sigma_start <= 0:
    sigma_start = 1.0

initial = np.r_[beta_start, np.log(sigma_start)]

fit = minimize(
    loss,
    initial,
    jac=gradient,
    method="BFGS",
    options={"gtol": 1e-8, "maxiter": 2000},
)

if not fit.success or not np.isfinite(loss(fit.x)):
    fit = minimize(
        loss,
        initial,
        method="Nelder-Mead",
        options={"maxiter": 10000, "xatol": 1e-10, "fatol": 1e-10},
    )
    fit = minimize(
        loss,
        fit.x,
        jac=gradient,
        method="BFGS",
        options={"gtol": 1e-8, "maxiter": 2000},
    )

information = approx_hess(fit.x, loss)
information = (information + information.T) / 2.0
covariance = np.linalg.inv(information)

beta_hat = fit.x[:3]
sigma_hat = np.exp(fit.x[3])
standard_errors = np.sqrt(np.diag(covariance)[:3])

output = {
    "task_id": "broad_tobit",
    "platform": "python",
    "estimates": [
        {
            "term": "const",
            "estimate": float(beta_hat[0]),
            "se": float(standard_errors[0]),
            "n_obs": n_obs,
        },
        {
            "term": "x",
            "estimate": float(beta_hat[1]),
            "se": float(standard_errors[1]),
            "n_obs": n_obs,
        },
        {
            "term": "z",
            "estimate": float(beta_hat[2]),
            "se": float(standard_errors[2]),
            "n_obs": n_obs,
        },
        {
            "term": "sigma",
            "estimate": float(sigma_hat),
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "Maximum likelihood homoskedastic Gaussian Tobit",
        "vcov": "Inverse observed information from the joint likelihood",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
