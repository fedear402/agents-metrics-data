import json
import numpy as np
import pandas as pd


def weighted_iv_hc1(y, q, instrument, weights):
    y = np.asarray(y, dtype=float)
    q = np.asarray(q, dtype=float)
    instrument = np.asarray(instrument, dtype=float)
    weights = np.asarray(weights, dtype=float)

    X = np.column_stack([np.ones(len(y)), q])
    Z = np.column_stack([np.ones(len(y)), instrument])
    W = np.diag(weights)

    z_w_inv = np.linalg.inv(Z.T @ W @ Z)
    x_hat = Z @ z_w_inv @ Z.T @ W @ X

    bread = np.linalg.inv(x_hat.T @ W @ x_hat)
    beta = bread @ (x_hat.T @ W @ y)
    residuals = y - X @ beta

    meat = x_hat.T @ np.diag((weights ** 2) * (residuals ** 2)) @ x_hat
    covariance = bread @ meat @ bread
    covariance *= len(y) / (len(y) - 2)

    return float(beta[1]), float(np.sqrt(covariance[1, 1]))


df = pd.read_csv("input.csv")

region_cols = ["region_id", "region_weight", "x", "y"]
regions = df[region_cols].drop_duplicates("region_id").copy()
regions["e"] = regions["region_weight"] / regions["region_weight"].sum()

regional_z = (
    df.assign(weighted_share=lambda d: d["share"] * d["shock"])
      .groupby("region_id", as_index=False)["weighted_share"]
      .sum()
      .rename(columns={"weighted_share": "z"})
)

regions = regions.merge(regional_z, on="region_id", how="left")

for variable in ["y", "x", "z"]:
    mean_value = np.sum(regions["e"] * regions[variable])
    regions[f"{variable}0"] = regions[variable] - mean_value

df = df.merge(
    regions[["region_id", "e", "y0", "x0", "z0"]],
    on="region_id",
    how="left",
)

df["industry_weight"] = df["e"] * df["share"]

industry_weights = (
    df.groupby("industry_id", as_index=False)["industry_weight"]
      .sum()
      .rename(columns={"industry_weight": "s"})
)

industry_shocks = df[["industry_id", "shock"]].drop_duplicates("industry_id")

shock_level = industry_weights.merge(industry_shocks, on="industry_id", how="left")

for variable in ["y0", "x0", "z0"]:
    numerator = (
        df.assign(value=lambda d: d["industry_weight"] * d[variable])
          .groupby("industry_id", as_index=False)["value"]
          .sum()
          .rename(columns={"value": f"{variable}_numerator"})
    )
    shock_level = shock_level.merge(numerator, on="industry_id", how="left")
    shock_level[f"{variable}_bar"] = (
        shock_level[f"{variable}_numerator"] / shock_level["s"]
    )

shock_level = shock_level.loc[shock_level["s"] > 0].copy()
n_industries = len(shock_level)

effect_estimate, effect_se = weighted_iv_hc1(
    shock_level["y0_bar"],
    shock_level["x0_bar"],
    shock_level["shock"],
    shock_level["s"],
)

first_stage_estimate, first_stage_se = weighted_iv_hc1(
    shock_level["x0_bar"],
    shock_level["z0_bar"],
    shock_level["shock"],
    shock_level["s"],
)

effective_shocks = 1.0 / np.sum(shock_level["s"] ** 2)

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {
            "term": "effect",
            "estimate": effect_estimate,
            "se": effect_se,
            "n_obs": n_industries,
        },
        {
            "term": "first_stage",
            "estimate": first_stage_estimate,
            "se": first_stage_se,
            "n_obs": n_industries,
        },
        {
            "term": "effective_shocks",
            "estimate": float(effective_shocks),
            "se": None,
            "n_obs": n_industries,
        },
    ],
    "method_metadata": {
        "estimator": "Borusyak-Hull-Jaravel shock-level weighted 2SLS",
        "vcov": "HC1 robust covariance with multiplier N/(N-2)",
    },
    "diagnostics": {},
}

with open("result.json", "w") as file:
    json.dump(result, file, indent=2)
