import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")

region = (
    df[["region_id", "region_weight", "x", "y"]]
    .drop_duplicates("region_id")
    .copy()
)

region["e"] = region["region_weight"] / region["region_weight"].sum()

df["share_shock"] = df["share"] * df["shock"]
z_region = df.groupby("region_id", as_index=False)["share_shock"].sum()
z_region = z_region.rename(columns={"share_shock": "z"})

region = region.merge(z_region, on="region_id", how="left")

for col in ["y", "x", "z"]:
    mean_value = np.sum(region["e"] * region[col])
    region[f"{col}0"] = region[col] - mean_value

industry = (
    df[["industry_id", "region_id", "share", "shock"]]
    .merge(region[["region_id", "e", "y0", "x0", "z0"]], on="region_id")
)

industry["weighted_share"] = industry["e"] * industry["share"]
industry["share_y0"] = industry["weighted_share"] * industry["y0"]
industry["share_x0"] = industry["weighted_share"] * industry["x0"]
industry["share_z0"] = industry["weighted_share"] * industry["z0"]

shock = (
    industry.groupby("industry_id", as_index=False)
    .agg(
        s_n=("weighted_share", "sum"),
        shock_n=("shock", "first"),
        y_num=("share_y0", "sum"),
        x_num=("share_x0", "sum"),
        z_num=("share_z0", "sum"),
    )
)

shock = shock.loc[shock["s_n"] > 0].copy()
shock["ybar"] = shock["y_num"] / shock["s_n"]
shock["xbar"] = shock["x_num"] / shock["s_n"]
shock["zbar"] = shock["z_num"] / shock["s_n"]

n_industries = len(shock)


def weighted_iv_hc1(y, endogenous, instrument, weights):
    y = np.asarray(y, dtype=float)
    endogenous = np.asarray(endogenous, dtype=float)
    instrument = np.asarray(instrument, dtype=float)
    weights = np.asarray(weights, dtype=float)

    X = np.column_stack([np.ones(len(y)), endogenous])
    Z = np.column_stack([np.ones(len(y)), instrument])
    W = np.diag(weights)

    ztwz_inv = np.linalg.pinv(Z.T @ W @ Z)
    PzX = Z @ ztwz_inv @ Z.T @ W @ X
    X_hat = PzX

    bread_base = X_hat.T @ W @ X_hat
    beta = np.linalg.pinv(bread_base) @ (X_hat.T @ W @ y)

    residual = y - X @ beta
    meat = np.zeros((2, 2))

    for i in range(len(y)):
        score = weights[i] * residual[i] * X_hat[i, :]
        meat += np.outer(score, score)

    bread = np.linalg.pinv(bread_base)
    covariance = bread @ meat @ bread
    covariance *= len(y) / (len(y) - 2)

    return float(beta[1]), float(np.sqrt(max(covariance[1, 1], 0.0)))


effect, effect_se = weighted_iv_hc1(
    shock["ybar"],
    shock["xbar"],
    shock["shock_n"],
    shock["s_n"],
)

first_stage, first_stage_se = weighted_iv_hc1(
    shock["xbar"],
    shock["zbar"],
    shock["shock_n"],
    shock["s_n"],
)

effective_shocks = 1.0 / np.sum(shock["s_n"].to_numpy(dtype=float) ** 2)

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {
            "term": "effect",
            "estimate": effect,
            "se": effect_se,
            "n_obs": n_industries,
        },
        {
            "term": "first_stage",
            "estimate": first_stage,
            "se": first_stage_se,
            "n_obs": n_industries,
        },
        {
            "term": "effective_shocks",
            "estimate": float(effective_shocks),
            "se": None,
            "n_obs": n_industries,
        },
    ],
    "method_metadata": {
        "estimator": "weighted two-stage least squares with shock-level aggregation",
        "vcov": "shock-level heteroskedasticity-robust HC1",
    },
    "diagnostics": {},
}

with open("result.json", "w") as file:
    json.dump(result, file, indent=2)
