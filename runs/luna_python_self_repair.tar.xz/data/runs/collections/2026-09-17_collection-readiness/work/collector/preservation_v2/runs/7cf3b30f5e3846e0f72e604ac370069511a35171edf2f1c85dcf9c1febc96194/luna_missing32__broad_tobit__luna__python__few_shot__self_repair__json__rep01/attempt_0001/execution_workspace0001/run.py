import json
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.special import log_ndtr
from scipy.stats import norm
from statsmodels.tools.numdiff import approx_hess

data = pd.read_csv("input.csv")
y = data["y"].to_numpy(dtype=float)
X = np.column_stack([
    np.ones(len(data)),
    data["x"].to_numpy(dtype=float),
    data["z"].to_numpy(dtype=float),
])

censored = y <= 0
uncensored = ~censored
n_obs = len(y)


def loss(parameter):
    beta = parameter[:3]
    sigma = np.exp(parameter[3])
    mu = X @ beta

    a = -mu[censored] / sigma
    r = (y[uncensored] - mu[uncensored]) / sigma

    censored_ll = log_ndtr(a).sum()
    uncensored_ll = (norm.logpdf(r) - np.log(sigma)).sum()

    return float(-(censored_ll + uncensored_ll))


def gradient(parameter):
    beta = parameter[:3]
    sigma = np.exp(parameter[3])
    mu = X @ beta

    a = -mu[censored] / sigma
    mills = np.exp(norm.logpdf(a) - log_ndtr(a))

    r = (y[uncensored] - mu[uncensored]) / sigma

    beta_gradient = X[censored].T @ (mills / sigma)
    beta_gradient -= X[uncensored].T @ (r / sigma)

    eta_gradient = np.sum(a * mills) + np.sum(1.0 - r * r)

    return np.r_[beta_gradient, eta_gradient]


positive_y = y[uncensored]
initial_sigma = np.std(positive_y) if len(positive_y) > 1 else np.std(y)
if not np.isfinite(initial_sigma) or initial_sigma <= 0:
    initial_sigma = 1.0

initial = np.array([
    np.mean(y),
    0.0,
    0.0,
    np.log(initial_sigma),
])

fit = minimize(
    loss,
    initial,
    jac=gradient,
    method="BFGS",
    options={"gtol": 1e-8, "maxiter": 2000},
)

if not np.isfinite(fit.fun):
    raise RuntimeError("Tobit optimization failed.")

if np.max(np.abs(gradient(fit.x))) > 1e-5:
    refined = minimize(
        loss,
        fit.x,
        jac=gradient,
        method="BFGS",
        options={"gtol": 1e-10, "maxiter": 5000},
    )
    if refined.fun < fit.fun:
        fit = refined

information = approx_hess(fit.x, loss)
information = 0.5 * (information + information.T)
covariance = np.linalg.inv(information)

beta_estimates = fit.x[:3]
beta_ses = np.sqrt(np.diag(covariance)[:3])
sigma_estimate = float(np.exp(fit.x[3]))

output = {
    "task_id": "broad_tobit",
    "platform": "python",
    "estimates": [
        {
            "term": "const",
            "estimate": float(beta_estimates[0]),
            "se": float(beta_ses[0]),
            "n_obs": n_obs,
        },
        {
            "term": "x",
            "estimate": float(beta_estimates[1]),
            "se": float(beta_ses[1]),
            "n_obs": n_obs,
        },
        {
            "term": "z",
            "estimate": float(beta_estimates[2]),
            "se": float(beta_ses[2]),
            "n_obs": n_obs,
        },
        {
            "term": "sigma",
            "estimate": sigma_estimate,
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "maximum_likelihood_homoskedastic_gaussian_tobit",
        "vcov": "inverse_observed_information",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
