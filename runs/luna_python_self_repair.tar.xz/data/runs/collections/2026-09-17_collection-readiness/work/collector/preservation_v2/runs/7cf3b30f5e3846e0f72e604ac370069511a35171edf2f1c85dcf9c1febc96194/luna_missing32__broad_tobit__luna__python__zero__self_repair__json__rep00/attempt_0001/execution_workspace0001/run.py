import json
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.special import log_ndtr
from scipy.stats import norm
from statsmodels.tools.numdiff import approx_hess

df = pd.read_csv("input.csv")

y = df["y"].to_numpy(dtype=float)
X = np.column_stack([
    np.ones(len(df)),
    df["x"].to_numpy(dtype=float),
    df["z"].to_numpy(dtype=float),
])

n_obs = len(y)
censored = y <= 0
uncensored = ~censored


def loglike_and_gradient(params):
    beta = params[:3]
    log_sigma = params[3]
    sigma = np.exp(log_sigma)

    eta = X @ beta
    ll = np.zeros(n_obs)
    grad = np.zeros(4)

    if np.any(uncensored):
        residual = y[uncensored] - eta[uncensored]
        standardized = residual / sigma
        ll[uncensored] = (
            -log_sigma
            - 0.5 * np.log(2.0 * np.pi)
            - 0.5 * standardized**2
        )

        grad[:3] += X[uncensored].T @ (residual / sigma**2)
        grad[3] += np.sum(-1.0 + standardized**2)

    if np.any(censored):
        q = -eta[censored] / sigma
        log_cdf = log_ndtr(q)
        ll[censored] = log_cdf

        mills_ratio = np.exp(norm.logpdf(q) - log_cdf)
        grad_eta = -mills_ratio / sigma

        grad[:3] += X[censored].T @ grad_eta
        grad[3] += np.sum(mills_ratio * eta[censored] / sigma)

    return np.sum(ll), grad


def objective(params):
    ll, grad = loglike_and_gradient(params)
    return -ll, -grad


positive_y = y[uncensored]
if len(positive_y) >= 3:
    initial_beta = np.linalg.lstsq(X[uncensored], positive_y, rcond=None)[0]
    initial_residuals = positive_y - X[uncensored] @ initial_beta
    initial_sigma = max(np.std(initial_residuals), 1e-2)
else:
    initial_beta = np.zeros(3)
    initial_sigma = max(np.std(y), 1.0)

initial_params = np.r_[initial_beta, np.log(initial_sigma)]

fit = minimize(
    fun=lambda p: objective(p)[0],
    x0=initial_params,
    jac=lambda p: objective(p)[1],
    method="BFGS",
    options={"gtol": 1e-9, "maxiter": 5000},
)

if not fit.success:
    fit = minimize(
        fun=lambda p: objective(p)[0],
        x0=fit.x,
        jac=lambda p: objective(p)[1],
        method="L-BFGS-B",
        options={"ftol": 1e-14, "gtol": 1e-9, "maxiter": 5000},
    )

params_hat = fit.x
beta_hat = params_hat[:3]
sigma_hat = float(np.exp(params_hat[3]))

hessian = approx_hess(
    params_hat,
    lambda p: loglike_and_gradient(p)[0],
    epsilon=1e-5,
)
observed_information = -hessian
covariance = np.linalg.pinv(observed_information)
se_beta = np.sqrt(np.maximum(np.diag(covariance)[:3], 0.0))

result = {
    "task_id": "broad_tobit",
    "platform": "python",
    "estimates": [
        {
            "term": "const",
            "estimate": float(beta_hat[0]),
            "se": float(se_beta[0]),
            "n_obs": int(n_obs),
        },
        {
            "term": "x",
            "estimate": float(beta_hat[1]),
            "se": float(se_beta[1]),
            "n_obs": int(n_obs),
        },
        {
            "term": "z",
            "estimate": float(beta_hat[2]),
            "se": float(se_beta[2]),
            "n_obs": int(n_obs),
        },
        {
            "term": "sigma",
            "estimate": sigma_hat,
            "se": None,
            "n_obs": int(n_obs),
        },
    ],
    "method_metadata": {
        "estimator": "Homoskedastic Gaussian Tobit maximum likelihood",
        "vcov": "Inverse observed information from the joint likelihood",
    },
    "diagnostics": {},
}

with open("result.json", "w") as file:
    json.dump(result, file, indent=2, allow_nan=False)
