import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
from statsmodels.stats.sandwich_covariance import cov_hac

df = pd.read_csv("input.csv")
df["date"] = pd.to_datetime(df["date"])
df = df.sort_values("date").reset_index(drop=True)

df["log_sales"] = np.log(df["sales"])
df["vol_change"] = np.log(df["vix"]).diff()

for lag in range(1, 16):
    df[f"lag_{lag}"] = df["vol_change"].shift(lag)

lag_columns = [f"lag_{lag}" for lag in range(1, 16)]
sample = df.dropna(subset=["log_sales"] + lag_columns)

y = sample["log_sales"].to_numpy()
X = sm.add_constant(sample[lag_columns].to_numpy(), has_constant="add")

model = sm.OLS(y, X).fit()
n_obs = len(sample)

covariance = cov_hac(
    model,
    nlags=15,
    weights_func=lambda nlags: 1 - np.arange(nlags + 1) / 16,
    use_correction=False,
)
covariance *= n_obs / (n_obs - 16)

params = model.params
lag_indices = np.arange(1, 16)
cumulative_estimate = float(params[lag_indices].sum())
cumulative_se = float(
    np.sqrt(covariance[np.ix_(lag_indices, lag_indices)].sum())
)

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {
            "term": "cumulative_response",
            "estimate": cumulative_estimate,
            "se": cumulative_se,
            "n_obs": int(n_obs),
        },
        {
            "term": "lag_1",
            "estimate": float(params[1]),
            "se": float(np.sqrt(covariance[1, 1])),
            "n_obs": int(n_obs),
        },
        {
            "term": "lag_15",
            "estimate": float(params[15]),
            "se": float(np.sqrt(covariance[15, 15])),
            "n_obs": int(n_obs),
        },
    ],
    "method_metadata": {
        "estimator": "OLS with intercept and lags 1 through 15 of first-differenced log VIX",
        "vcov": "Newey-West HAC covariance, Bartlett weights, maximum lag 15, scaled by N/(N-16)",
    },
    "diagnostics": {},
}

with open("result.json", "w") as file:
    json.dump(result, file, indent=2)
