import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")

regions = (
    df[["region_id", "region_weight", "x", "y"]]
    .drop_duplicates("region_id")
    .copy()
)

regions["e"] = regions["region_weight"] / regions["region_weight"].sum()

df = df.merge(
    regions[["region_id", "e", "x", "y"]],
    on="region_id",
    how="left",
    suffixes=("", "_region"),
)

region_values = (
    df[["region_id", "e", "x_region", "y_region"]]
    .drop_duplicates("region_id")
    .rename(columns={"x_region": "x", "y_region": "y"})
)

z_by_region = (
    df.assign(exposure=df["share"] * df["shock"])
    .groupby("region_id", as_index=False)["exposure"]
    .sum()
    .rename(columns={"exposure": "z"})
)

regional = region_values.merge(z_by_region, on="region_id", how="left")
weights = regional["e"].to_numpy(dtype=float)

means = np.array([
    np.sum(weights * regional["y"].to_numpy(dtype=float)),
    np.sum(weights * regional["x"].to_numpy(dtype=float)),
    np.sum(weights * regional["z"].to_numpy(dtype=float)),
])

regional["y0"] = regional["y"] - means[0]
regional["x0"] = regional["x"] - means[1]
regional["z0"] = regional["z"] - means[2]

df = df.merge(
    regional[["region_id", "y0", "x0", "z0"]],
    on="region_id",
    how="left",
)

industry = (
    df.assign(weighted_share=df["e"] * df["share"])
    .groupby("industry_id", as_index=False)
    .agg(
        s=("weighted_share", "sum"),
        shock=("shock", "first"),
        y_num=("weighted_share", lambda v: 0.0),
    )
)

for variable in ["y0", "x0", "z0"]:
    numerator = (
        df["e"].to_numpy(dtype=float)
        * df["share"].to_numpy(dtype=float)
        * df[variable].to_numpy(dtype=float)
    )
    temp = pd.DataFrame({
        "industry_id": df["industry_id"],
        "numerator": numerator,
    })
    numerators = temp.groupby("industry_id")["numerator"].sum()
    industry[f"{variable}_bar"] = (
        industry["industry_id"].map(numerators).to_numpy(dtype=float)
        / industry["s"].to_numpy(dtype=float)
    )

industry = industry.sort_values("industry_id").reset_index(drop=True)
s = industry["s"].to_numpy(dtype=float)
shock = industry["shock"].to_numpy(dtype=float)
n_industries = len(industry)


def shock_level_iv(dependent, endogenous):
    regressors = np.column_stack([
        np.ones(n_industries),
        endogenous,
    ])
    instruments = np.column_stack([
        np.ones(n_industries),
        shock,
    ])

    cross = instruments.T @ (s[:, None] * regressors)
    rhs = instruments.T @ (s * dependent)
    beta = np.linalg.solve(cross, rhs)

    residual = dependent - regressors @ beta
    scores = instruments * (s * residual)[:, None]
    inverse = np.linalg.inv(cross)

    hc1 = n_industries / (n_industries - 2)
    covariance = hc1 * inverse @ (scores.T @ scores) @ inverse.T

    return float(beta[1]), float(np.sqrt(covariance[1, 1]))


effect, effect_se = shock_level_iv(
    industry["y0_bar"].to_numpy(dtype=float),
    industry["x0_bar"].to_numpy(dtype=float),
)

first_stage, first_stage_se = shock_level_iv(
    industry["x0_bar"].to_numpy(dtype=float),
    industry["z0_bar"].to_numpy(dtype=float),
)

effective_shocks = float(1.0 / np.sum(s ** 2))

output = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {
            "term": "effect",
            "estimate": effect,
            "se": effect_se,
            "n_obs": n_industries,
        },
        {
            "term": "first_stage",
            "estimate": first_stage,
            "se": first_stage_se,
            "n_obs": n_industries,
        },
        {
            "term": "effective_shocks",
            "estimate": effective_shocks,
            "se": None,
            "n_obs": n_industries,
        },
    ],
    "method_metadata": {
        "estimator": "Borusyak-Hull-Jaravel shock-level weighted IV",
        "vcov": "HC1 with structural IV residuals and analytic weights",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
