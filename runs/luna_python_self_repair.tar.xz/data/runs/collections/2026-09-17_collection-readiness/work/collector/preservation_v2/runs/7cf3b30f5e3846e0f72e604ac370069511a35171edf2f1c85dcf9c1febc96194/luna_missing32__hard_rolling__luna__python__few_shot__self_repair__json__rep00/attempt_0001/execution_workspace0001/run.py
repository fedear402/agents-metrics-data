import json
import numpy as np
import pandas as pd

data = pd.read_csv("input.csv").sort_values("time").reset_index(drop=True)

y_by_time = data.set_index("time")["y"].astype(float)
forecasts = {}
errors = []

for f in range(101, 251):
    levels = y_by_time.loc[f - 100:f - 1].to_numpy(dtype=float)

    lagged = levels[:-1]
    current = levels[1:]
    X = np.column_stack([np.ones(len(lagged)), lagged])

    coefficients = np.linalg.lstsq(X, current, rcond=None)[0]
    forecast = float(coefficients @ np.array([1.0, levels[-1]]))

    forecasts[f] = forecast
    errors.append(float(y_by_time.loc[f]) - forecast)

rmse = float(np.sqrt(np.mean(np.asarray(errors) ** 2)))

rows = [
    {"term": "rmse", "estimate": rmse, "se": None, "n_obs": 150},
    *[
        {
            "term": f"forecast_{f}",
            "estimate": forecasts[f],
            "se": None,
            "n_obs": 99,
        }
        for f in [101, 150, 200, 250]
    ],
]

output = {
    "task_id": "hard_rolling",
    "platform": "python",
    "estimates": rows,
    "method_metadata": {
        "estimator": "rolling OLS AR(1) with intercept",
        "vcov": "none",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
