import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")

region = (
    df[["region_id", "region_weight", "x", "y"]]
    .drop_duplicates("region_id")
    .copy()
)

region["e"] = region["region_weight"] / region["region_weight"].sum()

industry = df[["industry_id", "shock"]].drop_duplicates("industry_id").copy()

z = (
    df.assign(z_part=df["share"] * df["shock"])
    .groupby("region_id", as_index=False)["z_part"]
    .sum()
    .rename(columns={"z_part": "z"})
)

region = region.merge(z, on="region_id", validate="one_to_one")

for variable in ["y", "x", "z"]:
    region[f"{variable}0"] = (
        region[variable] - np.sum(region["e"] * region[variable])
    )

df = df.merge(
    region[["region_id", "e", "y0", "x0", "z0"]],
    on="region_id",
    validate="many_to_one",
)

df["weighted_share"] = df["e"] * df["share"]

mass = (
    df.groupby("industry_id")["weighted_share"]
    .sum()
    .rename("s")
)

shock_level = industry.merge(mass, on="industry_id", validate="one_to_one")

for variable in ["y0", "x0", "z0"]:
    numerator = (
        df.assign(value=df["weighted_share"] * df[variable])
        .groupby("industry_id")["value"]
        .sum()
    )
    shock_level[f"{variable}_bar"] = (
        numerator / shock_level.set_index("industry_id")["s"]
    ).reindex(shock_level["industry_id"]).to_numpy()

shock_level = shock_level.sort_values("industry_id").reset_index(drop=True)

n_industries = len(shock_level)
s = shock_level["s"].to_numpy()
shock = shock_level["shock"].to_numpy()


def shock_level_iv(dependent, endogenous):
    y = shock_level[dependent].to_numpy()
    x = shock_level[endogenous].to_numpy()

    regressors = np.column_stack([np.ones(n_industries), x])
    instruments = np.column_stack([np.ones(n_industries), shock])

    cross = instruments.T @ (s[:, None] * regressors)
    rhs = instruments.T @ (s * y)
    beta = np.linalg.solve(cross, rhs)

    residual = y - regressors @ beta
    scores = instruments * (s * residual)[:, None]
    inverse = np.linalg.inv(cross)

    hc1 = n_industries / (n_industries - 2)
    covariance = hc1 * inverse @ (scores.T @ scores) @ inverse.T

    return float(beta[1]), float(np.sqrt(covariance[1, 1]))


effect, effect_se = shock_level_iv("y0_bar", "x0_bar")
first_stage, first_stage_se = shock_level_iv("x0_bar", "z0_bar")
effective_shocks = float(1.0 / np.sum(s**2))

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {
            "term": "effect",
            "estimate": effect,
            "se": effect_se,
            "n_obs": n_industries,
        },
        {
            "term": "first_stage",
            "estimate": first_stage,
            "se": first_stage_se,
            "n_obs": n_industries,
        },
        {
            "term": "effective_shocks",
            "estimate": effective_shocks,
            "se": None,
            "n_obs": n_industries,
        },
    ],
    "method_metadata": {
        "estimator": "Borusyak-Hull-Jaravel shock-level weighted IV",
        "vcov": "HC1 with structural IV residuals and analytic exposure weights",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
