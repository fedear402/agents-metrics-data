import json

import numpy as np
import pandas as pd
import statsmodels.api as sm
from statsmodels.stats.sandwich_covariance import cov_hac


df = pd.read_csv("input.csv")
df["date"] = pd.to_datetime(df["date"])
df = df.sort_values("date").reset_index(drop=True)

df["vol_change"] = np.log(df["vix"]).diff()

for lag in range(1, 16):
    df[f"lag_{lag}"] = df["vol_change"].shift(lag)

df["log_sales"] = np.log(df["sales"])
lag_columns = [f"lag_{lag}" for lag in range(1, 16)]
model_data = df[["log_sales"] + lag_columns].dropna()

y = model_data["log_sales"]
X = sm.add_constant(model_data[lag_columns], has_constant="add")

fit = sm.OLS(y, X).fit()
n_obs = int(len(model_data))

hac_cov = cov_hac(
    fit,
    nlags=15,
    weights_func=lambda j: 1.0 - np.asarray(j, dtype=float) / 16.0,
    use_correction=False,
)
hac_cov *= n_obs / (n_obs - 16)

parameter_names = list(X.columns)
lag_indices = [parameter_names.index(column) for column in lag_columns]
cumulative_vector = np.zeros(len(parameter_names))
cumulative_vector[lag_indices] = 1.0

cumulative_estimate = float(sum(fit.params[column] for column in lag_columns))
cumulative_se = float(
    np.sqrt(cumulative_vector @ hac_cov @ cumulative_vector)
)

lag_1_index = parameter_names.index("lag_1")
lag_15_index = parameter_names.index("lag_15")

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {
            "term": "cumulative_response",
            "estimate": cumulative_estimate,
            "se": cumulative_se,
            "n_obs": n_obs,
        },
        {
            "term": "lag_1",
            "estimate": float(fit.params["lag_1"]),
            "se": float(np.sqrt(hac_cov[lag_1_index, lag_1_index])),
            "n_obs": n_obs,
        },
        {
            "term": "lag_15",
            "estimate": float(fit.params["lag_15"]),
            "se": float(np.sqrt(hac_cov[lag_15_index, lag_15_index])),
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "OLS with intercept and lags 1 through 15 of first-differenced log volatility",
        "vcov": "Newey-West HAC covariance, maximum lag 15, Bartlett weights, scaled by N/(N-16)",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file, indent=2)
