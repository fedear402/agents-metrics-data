import json

import numpy as np
import pandas as pd
import statsmodels.api as sm


df = pd.read_csv("input.csv")
df["date"] = pd.to_datetime(df["date"])
df = df.sort_values("date").reset_index(drop=True)

df["vol_change"] = np.log(df["vix"]).diff()

for lag in range(1, 16):
    df[f"lag_{lag}"] = df["vol_change"].shift(lag)

df["log_sales"] = np.log(df["sales"])
lag_columns = [f"lag_{lag}" for lag in range(1, 16)]
model_data = df[["log_sales"] + lag_columns].dropna()

y = model_data["log_sales"].to_numpy(dtype=float)
X = sm.add_constant(model_data[lag_columns], has_constant="add").to_numpy(dtype=float)

fit = sm.OLS(y, X).fit()
n_obs = int(len(model_data))

residuals = fit.resid
bread = np.linalg.inv(X.T @ X)
score = X * residuals[:, None]

hac_middle = score.T @ score

for j in range(1, 16):
    weight = 1.0 - j / 16.0
    hac_middle += weight * (
        score[j:].T @ score[:-j] + score[:-j].T @ score[j:]
    )

hac_cov = bread @ hac_middle @ bread
hac_cov *= n_obs / (n_obs - 16)

parameter_names = ["const"] + lag_columns
lag_1_index = parameter_names.index("lag_1")
lag_15_index = parameter_names.index("lag_15")
lag_indices = [parameter_names.index(column) for column in lag_columns]

cumulative_vector = np.zeros(len(parameter_names))
cumulative_vector[lag_indices] = 1.0

cumulative_estimate = float(np.sum(fit.params[lag_indices]))
cumulative_se = float(
    np.sqrt(cumulative_vector @ hac_cov @ cumulative_vector)
)

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {
            "term": "cumulative_response",
            "estimate": cumulative_estimate,
            "se": cumulative_se,
            "n_obs": n_obs,
        },
        {
            "term": "lag_1",
            "estimate": float(fit.params[lag_1_index]),
            "se": float(np.sqrt(hac_cov[lag_1_index, lag_1_index])),
            "n_obs": n_obs,
        },
        {
            "term": "lag_15",
            "estimate": float(fit.params[lag_15_index]),
            "se": float(np.sqrt(hac_cov[lag_15_index, lag_15_index])),
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "OLS with intercept and lags 1 through 15 of first-differenced log volatility",
        "vcov": "Newey-West HAC covariance, maximum lag 15, Bartlett weights, scaled by N/(N-16)",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file, indent=2)
