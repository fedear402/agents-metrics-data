import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv").sort_values("time")
y = df["y"].to_numpy(dtype=float)

forecasts = {}

for f in range(101, 251):
    x = y[f - 101:f - 2]
    target = y[f - 100:f - 1]

    design = np.column_stack((np.ones(99), x))
    coefficients = np.linalg.lstsq(design, target, rcond=None)[0]
    forecast = coefficients[0] + coefficients[1] * y[f - 2]

    forecasts[f] = float(forecast)

errors = np.array([y[f - 1] - forecasts[f] for f in range(101, 251)])
rmse = float(np.sqrt(np.sum(errors ** 2) / 150))

result = {
    "task_id": "hard_rolling",
    "platform": "python",
    "estimates": [
        {"term": "rmse", "estimate": rmse, "se": None, "n_obs": 150},
        {"term": "forecast_101", "estimate": forecasts[101], "se": None, "n_obs": 99},
        {"term": "forecast_150", "estimate": forecasts[150], "se": None, "n_obs": 99},
        {"term": "forecast_200", "estimate": forecasts[200], "se": None, "n_obs": 99},
        {"term": "forecast_250", "estimate": forecasts[250], "se": None, "n_obs": 99},
    ],
    "method_metadata": {
        "estimator": "Rolling OLS AR(1) with intercept",
        "vcov": "Not applicable"
    },
    "diagnostics": {}
}

with open("result.json", "w") as file:
    json.dump(result, file, indent=2)
