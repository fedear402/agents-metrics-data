import json
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.special import log_ndtr
from scipy.stats import norm
from statsmodels.tools.numdiff import approx_hess

data = pd.read_csv("input.csv")

y = data["y"].to_numpy(dtype=float)
X = np.column_stack([
    np.ones(len(data)),
    data["x"].to_numpy(dtype=float),
    data["z"].to_numpy(dtype=float),
])

censored = y <= 0
uncensored = ~censored
n_obs = len(y)


def loss(parameter):
    beta = parameter[:3]
    sigma = np.exp(parameter[3])
    mu = X @ beta

    value = 0.0

    if np.any(censored):
        a = -mu[censored] / sigma
        value -= np.sum(log_ndtr(a))

    if np.any(uncensored):
        residual = (y[uncensored] - mu[uncensored]) / sigma
        value -= np.sum(norm.logpdf(residual) - np.log(sigma))

    return float(value)


def gradient(parameter):
    beta = parameter[:3]
    sigma = np.exp(parameter[3])
    mu = X @ beta

    grad_beta = np.zeros(3)
    grad_log_sigma = 0.0

    if np.any(censored):
        a = -mu[censored] / sigma
        mills = np.exp(norm.logpdf(a) - log_ndtr(a))
        grad_beta += X[censored].T @ (mills / sigma)
        grad_log_sigma += np.sum(a * mills)

    if np.any(uncensored):
        residual = (y[uncensored] - mu[uncensored]) / sigma
        grad_beta -= X[uncensored].T @ (residual / sigma)
        grad_log_sigma += np.sum(1.0 - residual**2)

    return np.r_[grad_beta, grad_log_sigma]


initial_beta = np.linalg.lstsq(X, np.maximum(y, 0.0), rcond=None)[0]
initial_sigma = np.std(
    np.maximum(y, 0.0) - X @ initial_beta,
    ddof=max(1, X.shape[1]),
)
if not np.isfinite(initial_sigma) or initial_sigma <= 0:
    initial_sigma = 1.0

initial = np.r_[initial_beta, np.log(initial_sigma)]

fit = minimize(
    loss,
    initial,
    jac=gradient,
    method="BFGS",
    options={"gtol": 1e-9, "maxiter": 2000},
)

if not fit.success or not np.isfinite(loss(fit.x)):
    fit = minimize(
        loss,
        initial,
        method="Nelder-Mead",
        options={"maxiter": 10000, "xatol": 1e-11, "fatol": 1e-11},
    )

parameter = fit.x
information = approx_hess(parameter, loss)
information = 0.5 * (information + information.T)
covariance = np.linalg.inv(information)

beta = parameter[:3]
sigma = np.exp(parameter[3])
se_beta = np.sqrt(np.diag(covariance)[:3])

output = {
    "task_id": "broad_tobit",
    "platform": "python",
    "estimates": [
        {
            "term": "const",
            "estimate": float(beta[0]),
            "se": float(se_beta[0]),
            "n_obs": n_obs,
        },
        {
            "term": "x",
            "estimate": float(beta[1]),
            "se": float(se_beta[1]),
            "n_obs": n_obs,
        },
        {
            "term": "z",
            "estimate": float(beta[2]),
            "se": float(se_beta[2]),
            "n_obs": n_obs,
        },
        {
            "term": "sigma",
            "estimate": float(sigma),
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "Gaussian maximum-likelihood Tobit with left censoring at zero",
        "vcov": "inverse observed information from the joint likelihood",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
