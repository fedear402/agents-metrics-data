import json
import math
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv").sort_values("time").reset_index(drop=True)
y = df["y"].to_numpy(dtype=float)

forecasts = {}

for f in range(101, 251):
    response = y[f - 100:f - 1]
    lagged = y[f - 101:f - 2]

    X = np.column_stack((np.ones(99), lagged))
    coefficients, _, _, _ = np.linalg.lstsq(X, response, rcond=None)

    forecasts[f] = float(coefficients[0] + coefficients[1] * y[f - 2])

errors = np.array([y[f - 1] - forecasts[f] for f in range(101, 251)])
rmse = float(math.sqrt(np.sum(errors ** 2) / 150))

result = {
    "task_id": "hard_rolling",
    "platform": "python",
    "estimates": [
        {
            "term": "rmse",
            "estimate": rmse,
            "se": None,
            "n_obs": 150
        },
        {
            "term": "forecast_101",
            "estimate": forecasts[101],
            "se": None,
            "n_obs": 99
        },
        {
            "term": "forecast_150",
            "estimate": forecasts[150],
            "se": None,
            "n_obs": 99
        },
        {
            "term": "forecast_200",
            "estimate": forecasts[200],
            "se": None,
            "n_obs": 99
        },
        {
            "term": "forecast_250",
            "estimate": forecasts[250],
            "se": None,
            "n_obs": 99
        }
    ],
    "method_metadata": {
        "estimator": "Rolling OLS AR(1) with intercept",
        "vcov": "Not applicable"
    },
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
