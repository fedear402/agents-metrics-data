import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")

regions = (
    df[["region_id", "region_weight", "x", "y"]]
    .drop_duplicates("region_id")
    .copy()
)

regions["e"] = regions["region_weight"] / regions["region_weight"].sum()

shock_by_industry = df.groupby("industry_id")["shock"].first()
df["z_component"] = df["share"] * df["shock"]

z_by_region = df.groupby("region_id")["z_component"].sum()
regions["z"] = regions["region_id"].map(z_by_region)

e = regions["e"].to_numpy(dtype=float)
x = regions["x"].to_numpy(dtype=float)
y = regions["y"].to_numpy(dtype=float)
z = regions["z"].to_numpy(dtype=float)

regional = np.column_stack([y, x, z])
regional_means = e @ regional
centered = regional - regional_means

industry_data = df[["industry_id", "region_id", "share"]].copy()
industry_data["e"] = industry_data["region_id"].map(
    regions.set_index("region_id")["e"]
)
industry_data["y0"] = industry_data["region_id"].map(
    dict(zip(regions["region_id"], centered[:, 0]))
)
industry_data["x0"] = industry_data["region_id"].map(
    dict(zip(regions["region_id"], centered[:, 1]))
)
industry_data["z0"] = industry_data["region_id"].map(
    dict(zip(regions["region_id"], centered[:, 2]))
)

industry_data["weighted_share"] = (
    industry_data["e"] * industry_data["share"]
)

mass = industry_data.groupby("industry_id")["weighted_share"].sum()

industry_data["y_numerator"] = (
    industry_data["weighted_share"] * industry_data["y0"]
)
industry_data["x_numerator"] = (
    industry_data["weighted_share"] * industry_data["x0"]
)
industry_data["z_numerator"] = (
    industry_data["weighted_share"] * industry_data["z0"]
)

aggregated = pd.DataFrame({
    "mass": mass,
    "ybar": industry_data.groupby("industry_id")["y_numerator"].sum() / mass,
    "xbar": industry_data.groupby("industry_id")["x_numerator"].sum() / mass,
    "zbar": industry_data.groupby("industry_id")["z_numerator"].sum() / mass,
})

aggregated["shock"] = aggregated.index.map(shock_by_industry)
aggregated = aggregated.dropna(subset=["mass", "ybar", "xbar", "zbar", "shock"])

n_industries = len(aggregated)
w = aggregated["mass"].to_numpy(dtype=float)
shock = aggregated["shock"].to_numpy(dtype=float)


def shock_level_iv(dependent, endogenous):
    regressors = np.column_stack([
        np.ones(n_industries),
        endogenous,
    ])
    instruments = np.column_stack([
        np.ones(n_industries),
        shock,
    ])

    cross = instruments.T @ (w[:, None] * regressors)
    rhs = instruments.T @ (w * dependent)
    beta = np.linalg.solve(cross, rhs)

    residual = dependent - regressors @ beta
    scores = instruments * (w * residual)[:, None]
    inverse = np.linalg.inv(cross)

    hc1 = n_industries / (n_industries - 2)
    covariance = hc1 * inverse @ (scores.T @ scores) @ inverse.T

    return float(beta[1]), float(np.sqrt(covariance[1, 1]))


effect, effect_se = shock_level_iv(
    aggregated["ybar"].to_numpy(dtype=float),
    aggregated["xbar"].to_numpy(dtype=float),
)

first_stage, first_stage_se = shock_level_iv(
    aggregated["xbar"].to_numpy(dtype=float),
    aggregated["zbar"].to_numpy(dtype=float),
)

effective_shocks = float(1.0 / np.sum(w ** 2))

output = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {
            "term": "effect",
            "estimate": effect,
            "se": effect_se,
            "n_obs": n_industries,
        },
        {
            "term": "first_stage",
            "estimate": first_stage,
            "se": first_stage_se,
            "n_obs": n_industries,
        },
        {
            "term": "effective_shocks",
            "estimate": effective_shocks,
            "se": None,
            "n_obs": n_industries,
        },
    ],
    "method_metadata": {
        "estimator": "shock-level weighted instrumental variables",
        "vcov": "HC1 heteroskedasticity-robust shock-level covariance",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
