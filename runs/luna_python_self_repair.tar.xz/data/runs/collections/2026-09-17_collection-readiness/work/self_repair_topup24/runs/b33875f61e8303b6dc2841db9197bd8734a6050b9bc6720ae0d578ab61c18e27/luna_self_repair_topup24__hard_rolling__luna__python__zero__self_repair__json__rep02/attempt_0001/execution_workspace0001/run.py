import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv").sort_values("time").reset_index(drop=True)
y = df["y"].to_numpy(dtype=float)

forecasts = {}

for f in range(101, 251):
    window = y[f - 101:f - 1]
    x = window[:-1]
    target = window[1:]

    X = np.column_stack([np.ones(len(x)), x])
    coefficients = np.linalg.lstsq(X, target, rcond=None)[0]
    forecast = coefficients[0] + coefficients[1] * y[f - 2]
    forecasts[f] = float(forecast)

errors = np.array([y[f - 1] - forecasts[f] for f in range(101, 251)])
rmse = float(np.sqrt(np.mean(errors ** 2)))

result = {
    "task_id": "hard_rolling",
    "platform": "python",
    "estimates": [
        {"term": "rmse", "estimate": rmse, "se": None, "n_obs": 150},
        {"term": "forecast_101", "estimate": forecasts[101], "se": None, "n_obs": 99},
        {"term": "forecast_150", "estimate": forecasts[150], "se": None, "n_obs": 99},
        {"term": "forecast_200", "estimate": forecasts[200], "se": None, "n_obs": 99},
        {"term": "forecast_250", "estimate": forecasts[250], "se": None, "n_obs": 99},
    ],
    "method_metadata": {
        "estimator": "Rolling OLS AR(1) with intercept",
        "vcov": "None"
    },
    "diagnostics": {}
}

with open("result.json", "w") as output_file:
    json.dump(result, output_file, indent=2)
