import json
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.special import log_ndtr
from scipy.stats import norm
from scipy.optimize._numdiff import approx_derivative

df = pd.read_csv("input.csv")

y = df["y"].to_numpy(dtype=float)
X = np.column_stack([
    np.ones(len(df)),
    df["x"].to_numpy(dtype=float),
    df["z"].to_numpy(dtype=float),
])

censored = y <= 0
uncensored = ~censored
n_obs = len(y)

def loglike_and_score(theta):
    beta = theta[:3]
    log_sigma = theta[3]
    sigma = np.exp(log_sigma)

    mu = X @ beta
    score = np.zeros(4)
    loglike = 0.0

    if np.any(uncensored):
        e = y[uncensored] - mu[uncensored]
        scaled_e = e / sigma
        loglike += np.sum(
            -log_sigma
            - 0.5 * scaled_e**2
            - 0.5 * np.log(2.0 * np.pi)
        )
        score[:3] += X[uncensored].T @ (e / sigma**2)
        score[3] += np.sum(-1.0 + scaled_e**2)

    if np.any(censored):
        mu_c = mu[censored]
        a = -mu_c / sigma
        loglike += np.sum(log_ndtr(a))

        inverse_mills = np.exp(norm.logpdf(a) - log_ndtr(a))
        score[:3] += X[censored].T @ (-inverse_mills / sigma)
        score[3] += np.sum(inverse_mills * mu_c / sigma)

    return loglike, score

def objective(theta):
    loglike, score = loglike_and_score(theta)
    return -loglike, -score

beta_start = np.linalg.lstsq(X, np.maximum(y, 0.0), rcond=None)[0]
residuals = np.maximum(y, 0.0) - X @ beta_start
sigma_start = max(np.std(residuals), 1e-6)
theta_start = np.r_[beta_start, np.log(sigma_start)]

fit = minimize(
    fun=lambda t: objective(t)[0],
    x0=theta_start,
    jac=lambda t: objective(t)[1],
    method="BFGS",
    options={"gtol": 1e-10, "maxiter": 5000},
)

if not fit.success:
    fit = minimize(
        fun=lambda t: objective(t)[0],
        x0=fit.x,
        jac=lambda t: objective(t)[1],
        method="L-BFGS-B",
        options={"ftol": 1e-15, "gtol": 1e-10, "maxiter": 5000},
    )

theta_hat = fit.x
negative_score = lambda t: objective(t)[1]
hessian = approx_derivative(
    negative_score,
    theta_hat,
    method="3-point",
)
covariance = np.linalg.pinv(hessian)

beta_hat = theta_hat[:3]
sigma_hat = float(np.exp(theta_hat[3]))
se_beta = np.sqrt(np.maximum(np.diag(covariance)[:3], 0.0))

result = {
    "task_id": "broad_tobit",
    "platform": "python",
    "estimates": [
        {
            "term": "const",
            "estimate": float(beta_hat[0]),
            "se": float(se_beta[0]),
            "n_obs": int(n_obs),
        },
        {
            "term": "x",
            "estimate": float(beta_hat[1]),
            "se": float(se_beta[1]),
            "n_obs": int(n_obs),
        },
        {
            "term": "z",
            "estimate": float(beta_hat[2]),
            "se": float(se_beta[2]),
            "n_obs": int(n_obs),
        },
        {
            "term": "sigma",
            "estimate": sigma_hat,
            "se": None,
            "n_obs": int(n_obs),
        },
    ],
    "method_metadata": {
        "estimator": "Homoskedastic Gaussian Tobit maximum likelihood",
        "vcov": "Inverse observed information from the jointly estimated likelihood",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file, indent=2)
