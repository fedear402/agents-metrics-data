import json
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.stats import norm

data = pd.read_csv("input.csv")

y = data["y"].to_numpy(dtype=float)
X = np.column_stack([
    np.ones(len(data)),
    data["x"].to_numpy(dtype=float),
    data["z"].to_numpy(dtype=float),
])

censored = y <= 0
uncensored = ~censored
n_obs = len(data)


def loss(parameter):
    beta = parameter[:3]
    sigma = np.exp(parameter[3])
    mean = X @ beta

    a = -mean[censored] / sigma
    r = (y[uncensored] - mean[uncensored]) / sigma

    value = 0.0
    if censored.any():
        value -= np.sum(norm.logcdf(a))
    if uncensored.any():
        value -= np.sum(norm.logpdf(r) - np.log(sigma))
    return float(value)


def gradient(parameter):
    beta = parameter[:3]
    sigma = np.exp(parameter[3])
    mean = X @ beta

    gradient_beta = np.zeros(3)
    gradient_eta = 0.0

    if censored.any():
        a = -mean[censored] / sigma
        mills = np.exp(norm.logpdf(a) - norm.logcdf(a))
        gradient_beta += X[censored].T @ (mills / sigma)
        gradient_eta += np.sum(a * mills)

    if uncensored.any():
        r = (y[uncensored] - mean[uncensored]) / sigma
        gradient_beta -= X[uncensored].T @ (r / sigma)
        gradient_eta += np.sum(1.0 - r * r)

    return np.r_[gradient_beta, gradient_eta]


beta_start = np.linalg.lstsq(X, np.maximum(y, 1e-8), rcond=None)[0]
sigma_start = np.std(y[uncensored] - X[uncensored] @ beta_start)
if not np.isfinite(sigma_start) or sigma_start <= 0:
    sigma_start = np.std(y)
if not np.isfinite(sigma_start) or sigma_start <= 0:
    sigma_start = 1.0

initial = np.r_[beta_start, np.log(sigma_start)]

fit = minimize(
    loss,
    initial,
    jac=gradient,
    method="BFGS",
    options={"gtol": 1e-9, "maxiter": 2000},
)

if not fit.success or np.max(np.abs(gradient(fit.x))) > 1e-5:
    fit = minimize(
        loss,
        fit.x,
        jac=gradient,
        method="L-BFGS-B",
        options={"ftol": 1e-15, "gtol": 1e-10, "maxiter": 5000},
    )

if not np.isfinite(loss(fit.x)):
    raise RuntimeError("Tobit optimization failed.")

def observed_hessian(point):
    dimension = len(point)
    hessian = np.zeros((dimension, dimension))
    for j in range(dimension):
        step = 1e-5 * max(1.0, abs(point[j]))
        direction = np.zeros(dimension)
        direction[j] = step
        hessian[:, j] = (
            gradient(point + direction) - gradient(point - direction)
        ) / (2.0 * step)
    return 0.5 * (hessian + hessian.T)

information = observed_hessian(fit.x)
eigenvalues = np.linalg.eigvalsh(information)
if eigenvalues.min() <= 0:
    raise RuntimeError("Observed information is not positive definite.")

covariance = np.linalg.inv(information)
se = np.sqrt(np.diag(covariance))

output = {
    "task_id": "broad_tobit",
    "platform": "python",
    "estimates": [
        {
            "term": "const",
            "estimate": float(fit.x[0]),
            "se": float(se[0]),
            "n_obs": n_obs,
        },
        {
            "term": "x",
            "estimate": float(fit.x[1]),
            "se": float(se[1]),
            "n_obs": n_obs,
        },
        {
            "term": "z",
            "estimate": float(fit.x[2]),
            "se": float(se[2]),
            "n_obs": n_obs,
        },
        {
            "term": "sigma",
            "estimate": float(np.exp(fit.x[3])),
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "Gaussian Tobit maximum likelihood",
        "vcov": "inverse observed information from joint likelihood",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
