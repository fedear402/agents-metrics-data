import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("input.csv")
df["date"] = pd.to_datetime(df["date"])
df = df.sort_values("date").reset_index(drop=True)

df["dlog_vix"] = np.log(df["vix"]).diff()
df["log_sales"] = np.log(df["sales"])

for lag in range(1, 16):
    df[f"lag_{lag}"] = df["dlog_vix"].shift(lag)

reg_cols = ["log_sales"] + [f"lag_{lag}" for lag in range(1, 16)]
reg = df[reg_cols].dropna()

y = reg["log_sales"].to_numpy(dtype=float)
lag_names = [f"lag_{lag}" for lag in range(1, 16)]
X = sm.add_constant(reg[lag_names].to_numpy(dtype=float), has_constant="add")

model = sm.OLS(y, X).fit()
params = model.params
resid = model.resid
n_obs = len(y)

xx_inv = np.linalg.inv(X.T @ X)
xu = X * resid[:, None]

meat = xu.T @ xu
for j in range(1, 16):
    weight = 1.0 - j / 16.0
    cross = xu[j:].T @ xu[:-j]
    meat += weight * (cross + cross.T)

cov = xx_inv @ meat @ xx_inv
cov *= n_obs / (n_obs - 16)

lag_params = params[1:]
cumulative_estimate = float(lag_params.sum())
cumulative_se = float(np.sqrt(np.ones(15) @ cov[1:, 1:] @ np.ones(15)))

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {
            "term": "cumulative_response",
            "estimate": cumulative_estimate,
            "se": cumulative_se,
            "n_obs": int(n_obs),
        },
        {
            "term": "lag_1",
            "estimate": float(params[1]),
            "se": float(np.sqrt(cov[1, 1])),
            "n_obs": int(n_obs),
        },
        {
            "term": "lag_15",
            "estimate": float(params[15]),
            "se": float(np.sqrt(cov[15, 15])),
            "n_obs": int(n_obs),
        },
    ],
    "method_metadata": {
        "estimator": "OLS with intercept and lags 1 through 15 of first-differenced log volatility",
        "vcov": "Newey-West HAC covariance, maximum lag 15, Bartlett weights, scaled by N/(N-16)",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
