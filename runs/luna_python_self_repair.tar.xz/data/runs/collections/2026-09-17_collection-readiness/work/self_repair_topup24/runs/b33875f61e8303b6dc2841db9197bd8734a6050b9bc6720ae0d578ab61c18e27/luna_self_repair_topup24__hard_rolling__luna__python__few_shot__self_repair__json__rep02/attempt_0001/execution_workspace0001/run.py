import json
import numpy as np
import pandas as pd

data = pd.read_csv("input.csv").sort_values("time").reset_index(drop=True)
y_by_time = data.set_index("time")["y"].astype(float)

forecasts = {}

for f in range(101, 251):
    levels = y_by_time.loc[f - 100:f - 1].to_numpy(dtype=float)

    lagged = levels[:-1]
    current = levels[1:]
    X = np.column_stack([np.ones(len(lagged)), lagged])

    coefficients = np.linalg.lstsq(X, current, rcond=None)[0]
    forecasts[f] = float(coefficients @ np.array([1.0, levels[-1]]))

actual = y_by_time.loc[range(101, 251)].to_numpy(dtype=float)
predicted = np.array([forecasts[f] for f in range(101, 251)])
rmse = float(np.sqrt(np.mean((actual - predicted) ** 2)))

reported_forecasts = [101, 150, 200, 250]

estimates = [
    {
        "term": "rmse",
        "estimate": rmse,
        "se": None,
        "n_obs": 150,
    }
]

estimates.extend(
    {
        "term": f"forecast_{f}",
        "estimate": forecasts[f],
        "se": None,
        "n_obs": 99,
    }
    for f in reported_forecasts
)

result = {
    "task_id": "hard_rolling",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "Rolling OLS AR(1) with intercept",
        "vcov": "Not applicable",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
