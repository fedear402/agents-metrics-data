import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")

region = (
    df[["region_id", "region_weight", "x", "y"]]
    .drop_duplicates("region_id")
    .reset_index(drop=True)
)

region_weight = region["region_weight"].to_numpy(dtype=float)
e = region_weight / region_weight.sum()

industries = pd.Index(sorted(df["industry_id"].unique()))
regions = region["region_id"]

shares = (
    df.pivot_table(
        index="region_id",
        columns="industry_id",
        values="share",
        aggfunc="first",
        fill_value=0.0,
    )
    .reindex(index=regions, columns=industries, fill_value=0.0)
    .to_numpy(dtype=float)
)

shock_map = (
    df[["industry_id", "shock"]]
    .drop_duplicates("industry_id")
    .set_index("industry_id")["shock"]
)
shock = shock_map.reindex(industries).to_numpy(dtype=float)

x = region["x"].to_numpy(dtype=float)
y = region["y"].to_numpy(dtype=float)
z = shares @ shock

regional = np.column_stack([y, x, z])
centered = regional - e @ regional

s = e @ shares
used = s > 0

s_used = s[used]
shock_used = shock[used]
aggregated = (
    shares[:, used].T @ (e[:, None] * centered)
) / s_used[:, None]

n_industries = len(s_used)


def shock_level_iv(dependent, endogenous, instrument):
    regressors = np.column_stack(
        [np.ones(len(dependent)), endogenous]
    )
    instruments = np.column_stack(
        [np.ones(len(instrument)), instrument]
    )

    cross = instruments.T @ (s_used[:, None] * regressors)
    rhs = instruments.T @ (s_used * dependent)
    beta = np.linalg.solve(cross, rhs)

    residual = dependent - regressors @ beta
    scores = instruments * (s_used * residual)[:, None]
    inverse = np.linalg.inv(cross)

    hc1 = n_industries / (n_industries - 2)
    covariance = hc1 * inverse @ (scores.T @ scores) @ inverse.T

    return float(beta[1]), float(np.sqrt(covariance[1, 1]))


effect, effect_se = shock_level_iv(
    aggregated[:, 0],
    aggregated[:, 1],
    shock_used,
)

first_stage, first_stage_se = shock_level_iv(
    aggregated[:, 1],
    aggregated[:, 2],
    shock_used,
)

effective_shocks = float(1.0 / np.sum(s_used**2))

output = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {
            "term": "effect",
            "estimate": effect,
            "se": effect_se,
            "n_obs": n_industries,
        },
        {
            "term": "first_stage",
            "estimate": first_stage,
            "se": first_stage_se,
            "n_obs": n_industries,
        },
        {
            "term": "effective_shocks",
            "estimate": effective_shocks,
            "se": None,
            "n_obs": n_industries,
        },
    ],
    "method_metadata": {
        "estimator": "shock-level weighted IV with regional 2SLS equivalence",
        "vcov": "shock-level HC1 with analytic exposure weights",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
