import json
import numpy as np
import pandas as pd


def weighted_iv_hc1(y, endog, instrument, weights):
    y = np.asarray(y, dtype=float)
    endog = np.asarray(endog, dtype=float)
    instrument = np.asarray(instrument, dtype=float)
    weights = np.asarray(weights, dtype=float)

    n = len(y)
    exog = np.column_stack([np.ones(n), endog])
    instruments = np.column_stack([np.ones(n), instrument])
    w = np.diag(weights)

    z_w_z = instruments.T @ w @ instruments
    z_w_x = instruments.T @ w @ exog
    z_w_y = instruments.T @ w @ y

    middle = np.linalg.solve(z_w_z, z_w_x)
    lhs = z_w_x.T @ np.linalg.solve(z_w_z, z_w_x)
    rhs = z_w_x.T @ np.linalg.solve(z_w_z, z_w_y)
    beta = np.linalg.solve(lhs, rhs)

    residuals = y - exog @ beta
    projection_components = exog.T @ w @ instruments
    bread = np.linalg.inv(lhs)

    meat = np.zeros((2, 2))
    for i in range(n):
        q_i = projection_components @ np.linalg.solve(z_w_z, instruments[i])
        meat += (weights[i] ** 2) * (residuals[i] ** 2) * np.outer(q_i, q_i)

    variance = bread @ meat @ bread
    variance *= n / (n - 2)

    return beta, np.sqrt(np.diag(variance))


df = pd.read_csv("input.csv")

regions = (
    df[["region_id", "region_weight", "x", "y"]]
    .drop_duplicates("region_id")
    .copy()
)

total_weight = regions["region_weight"].sum()
regions["e"] = regions["region_weight"] / total_weight

df = df.merge(regions[["region_id", "e"]], on="region_id", how="left")

df["share_shock"] = df["share"] * df["shock"]
regional = (
    df.groupby("region_id", as_index=False)
    .agg(
        z=("share_shock", "sum"),
        e=("e", "first"),
        x=("x", "first"),
        y=("y", "first"),
    )
)

for variable in ["y", "x", "z"]:
    mean = np.sum(regional["e"] * regional[variable])
    regional[f"{variable}0"] = regional[variable] - mean

industry = (
    df.merge(
        regional[["region_id", "y0", "x0", "z0"]],
        on="region_id",
        how="left",
    )
    .groupby("industry_id", as_index=False)
    .agg(
        shock=("shock", "first"),
        s=("share", lambda v: np.nan),
    )
)

exposure = (
    df.assign(es=df["e"] * df["share"])
    .groupby("industry_id", as_index=False)
    .agg(
        shock=("shock", "first"),
        s=("es", "sum"),
    )
)

residuals = (
    df.merge(
        regional[["region_id", "y0", "x0", "z0"]],
        on="region_id",
        how="left",
    )
    .assign(
        eyshare=lambda d: d["e"] * d["share"] * d["y0"],
        exshare=lambda d: d["e"] * d["share"] * d["x0"],
        ezshare=lambda d: d["e"] * d["share"] * d["z0"],
    )
    .groupby("industry_id", as_index=False)
    .agg(
        y_num=("eyshare", "sum"),
        x_num=("exshare", "sum"),
        z_num=("ezshare", "sum"),
    )
)

shock_level = exposure.merge(residuals, on="industry_id", how="left")
shock_level = shock_level.loc[shock_level["s"] > 0].copy()

shock_level["ybar"] = shock_level["y_num"] / shock_level["s"]
shock_level["xbar"] = shock_level["x_num"] / shock_level["s"]
shock_level["zbar"] = shock_level["z_num"] / shock_level["s"]

n_industries = len(shock_level)

effect_beta, effect_se = weighted_iv_hc1(
    shock_level["ybar"],
    shock_level["xbar"],
    shock_level["shock"],
    shock_level["s"],
)

first_stage_beta, first_stage_se = weighted_iv_hc1(
    shock_level["xbar"],
    shock_level["zbar"],
    shock_level["shock"],
    shock_level["s"],
)

effective_shocks = 1.0 / np.sum(shock_level["s"].to_numpy() ** 2)

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {
            "term": "effect",
            "estimate": float(effect_beta[1]),
            "se": float(effect_se[1]),
            "n_obs": int(n_industries),
        },
        {
            "term": "first_stage",
            "estimate": float(first_stage_beta[1]),
            "se": float(first_stage_se[1]),
            "n_obs": int(n_industries),
        },
        {
            "term": "effective_shocks",
            "estimate": float(effective_shocks),
            "se": None,
            "n_obs": int(n_industries),
        },
    ],
    "method_metadata": {
        "estimator": "Borusyak-Hull-Jaravel shock-level weighted IV",
        "vcov": "HC1 heteroskedasticity-robust shock-level sandwich, multiplier N/(N-2)",
    },
    "diagnostics": {},
}

with open("result.json", "w") as file:
    json.dump(result, file, indent=2)
