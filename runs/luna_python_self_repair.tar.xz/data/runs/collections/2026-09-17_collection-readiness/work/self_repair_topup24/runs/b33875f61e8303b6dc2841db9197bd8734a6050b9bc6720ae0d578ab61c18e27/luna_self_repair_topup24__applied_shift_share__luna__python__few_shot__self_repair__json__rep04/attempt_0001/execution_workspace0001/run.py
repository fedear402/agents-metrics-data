import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")

region_info = (
    df.groupby("region_id", as_index=False)
    .agg(
        region_weight=("region_weight", "first"),
        x=("x", "first"),
        y=("y", "first"),
    )
)

region_info["e"] = (
    region_info["region_weight"] / region_info["region_weight"].sum()
)

shares = (
    df.groupby(["region_id", "industry_id"], as_index=False)["share"]
    .sum()
    .pivot(index="region_id", columns="industry_id", values="share")
    .fillna(0.0)
)

industry_shocks = (
    df.groupby("industry_id", as_index=False)["shock"]
    .first()
    .set_index("industry_id")
)

shares = shares.reindex(
    index=region_info["region_id"],
    columns=industry_shocks.index,
    fill_value=0.0,
).to_numpy(dtype=float)

e = region_info["e"].to_numpy(dtype=float)
x = region_info["x"].to_numpy(dtype=float)
y = region_info["y"].to_numpy(dtype=float)
shock = industry_shocks["shock"].to_numpy(dtype=float)

z = shares @ shock

weighted_mean = lambda v: np.sum(e * v)
y0 = y - weighted_mean(y)
x0 = x - weighted_mean(x)
z0 = z - weighted_mean(z)

mass = e @ shares
valid = mass > 0

mass_used = mass[valid]
shock_used = shock[valid]

def aggregate(residual):
    return (shares[:, valid].T @ (e * residual)) / mass_used

ybar = aggregate(y0)
xbar = aggregate(x0)
zbar = aggregate(z0)

def shock_level_iv(dependent, endogenous, instrument):
    n = len(dependent)
    regressors = np.column_stack([np.ones(n), endogenous])
    instruments = np.column_stack([np.ones(n), instrument])
    weights = mass_used

    cross = instruments.T @ (weights[:, None] * regressors)
    rhs = instruments.T @ (weights * dependent)
    beta = np.linalg.solve(cross, rhs)

    residual = dependent - regressors @ beta
    scores = instruments * (weights * residual)[:, None]
    inverse = np.linalg.inv(cross)

    hc1 = n / (n - 2)
    covariance = hc1 * inverse @ (scores.T @ scores) @ inverse.T

    return float(beta[1]), float(np.sqrt(covariance[1, 1]))

effect, effect_se = shock_level_iv(ybar, xbar, shock_used)
first_stage, first_stage_se = shock_level_iv(xbar, zbar, shock_used)
effective_shocks = float(1.0 / np.sum(mass_used ** 2))
n_obs = int(len(mass_used))

output = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {
            "term": "effect",
            "estimate": effect,
            "se": effect_se,
            "n_obs": n_obs,
        },
        {
            "term": "first_stage",
            "estimate": first_stage,
            "se": first_stage_se,
            "n_obs": n_obs,
        },
        {
            "term": "effective_shocks",
            "estimate": effective_shocks,
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "Borusyak-Hull-Jaravel shock-level weighted IV",
        "vcov": "HC1 with structural IV residuals and analytic shock exposure weights",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
