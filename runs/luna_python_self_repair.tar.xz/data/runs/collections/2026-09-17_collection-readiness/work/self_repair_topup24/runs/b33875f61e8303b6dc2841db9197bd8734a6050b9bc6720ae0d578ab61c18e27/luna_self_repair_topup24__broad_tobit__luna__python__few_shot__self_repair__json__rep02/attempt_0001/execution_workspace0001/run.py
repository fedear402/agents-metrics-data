import json
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.stats import norm
from statsmodels.tools.numdiff import approx_hess

data = pd.read_csv("input.csv")
y = data["y"].to_numpy(dtype=float)
X = np.column_stack([
    np.ones(len(data)),
    data["x"].to_numpy(dtype=float),
    data["z"].to_numpy(dtype=float)
])

censored = y <= 0
uncensored = ~censored
n_obs = len(y)

positive_X = X[uncensored]
positive_y = y[uncensored]

if positive_y.size >= X.shape[1]:
    beta0 = np.linalg.lstsq(positive_X, positive_y, rcond=None)[0]
    residuals = positive_y - positive_X @ beta0
    sigma0 = np.std(residuals, ddof=X.shape[1])
else:
    beta0 = np.zeros(X.shape[1])
    sigma0 = np.std(y[y > 0]) if np.any(y > 0) else 1.0

if not np.isfinite(sigma0) or sigma0 <= 0:
    sigma0 = np.std(y) if np.std(y) > 0 else 1.0

initial = np.r_[beta0, np.log(sigma0)]

def loss(parameter):
    beta = parameter[:3]
    sigma = np.exp(parameter[3])
    mu = X @ beta

    value = 0.0

    if np.any(censored):
        a = -mu[censored] / sigma
        value -= np.sum(norm.logcdf(a))

    if np.any(uncensored):
        r = (y[uncensored] - mu[uncensored]) / sigma
        value -= np.sum(norm.logpdf(r) - np.log(sigma))

    return float(value)

def gradient(parameter):
    beta = parameter[:3]
    sigma = np.exp(parameter[3])
    mu = X @ beta

    score_beta = np.zeros(3)
    score_logsigma = 0.0

    if np.any(censored):
        a = -mu[censored] / sigma
        mills = np.exp(norm.logpdf(a) - norm.logcdf(a))
        score_beta += X[censored].T @ (mills / sigma)
        score_logsigma += np.sum(a * mills)

    if np.any(uncensored):
        r = (y[uncensored] - mu[uncensored]) / sigma
        score_beta -= X[uncensored].T @ (r / sigma)
        score_logsigma += np.sum(1.0 - r * r)

    return np.r_[score_beta, score_logsigma]

fit = minimize(
    loss,
    initial,
    jac=gradient,
    method="BFGS",
    options={"gtol": 1e-8, "maxiter": 2000}
)

if not fit.success or not np.isfinite(loss(fit.x)):
    fit = minimize(
        loss,
        initial,
        jac=gradient,
        method="L-BFGS-B",
        options={"ftol": 1e-15, "gtol": 1e-9, "maxiter": 5000}
    )

information = approx_hess(fit.x, loss, epsilon=1e-5)
information = 0.5 * (information + information.T)
covariance = np.linalg.inv(information)

estimates = [
    {
        "term": "const",
        "estimate": float(fit.x[0]),
        "se": float(np.sqrt(covariance[0, 0])),
        "n_obs": int(n_obs)
    },
    {
        "term": "x",
        "estimate": float(fit.x[1]),
        "se": float(np.sqrt(covariance[1, 1])),
        "n_obs": int(n_obs)
    },
    {
        "term": "z",
        "estimate": float(fit.x[2]),
        "se": float(np.sqrt(covariance[2, 2])),
        "n_obs": int(n_obs)
    },
    {
        "term": "sigma",
        "estimate": float(np.exp(fit.x[3])),
        "se": None,
        "n_obs": int(n_obs)
    }
]

output = {
    "task_id": "broad_tobit",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "maximum_likelihood_gaussian_tobit",
        "vcov": "inverse_observed_information"
    },
    "diagnostics": {}
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
