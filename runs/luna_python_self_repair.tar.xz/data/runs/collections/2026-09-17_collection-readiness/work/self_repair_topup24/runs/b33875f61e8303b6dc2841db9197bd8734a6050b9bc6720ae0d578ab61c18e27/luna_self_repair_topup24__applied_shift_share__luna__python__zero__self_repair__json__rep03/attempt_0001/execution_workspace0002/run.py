import json
import numpy as np
import pandas as pd


def iv_2sls_hc1(y, endogenous, instrument, weights):
    y = np.asarray(y, dtype=float)
    endogenous = np.asarray(endogenous, dtype=float)
    instrument = np.asarray(instrument, dtype=float)
    weights = np.asarray(weights, dtype=float)

    n = len(y)
    X = np.column_stack((np.ones(n), endogenous))
    Z = np.column_stack((np.ones(n), instrument))

    sqrt_w = np.sqrt(weights)
    Xw = X * sqrt_w[:, None]
    Zw = Z * sqrt_w[:, None]
    yw = y * sqrt_w

    ZtZ_inv = np.linalg.pinv(Zw.T @ Zw)
    A = Xw.T @ Zw @ ZtZ_inv @ Zw.T @ Xw
    b = Xw.T @ Zw @ ZtZ_inv @ Zw.T @ yw

    beta = np.linalg.solve(A, b)
    residuals = y - X @ beta

    meat = np.zeros((2, 2))
    for i in range(n):
        zi = Zw[i, :].reshape(2, 1)
        meat += residuals[i] ** 2 * (zi @ zi.T)

    left = Xw.T @ Zw @ ZtZ_inv
    right = ZtZ_inv @ Zw.T @ Xw
    A_inv = np.linalg.pinv(A)

    covariance = A_inv @ left @ meat @ right @ A_inv
    covariance *= n / (n - 2)

    variance = max(float(covariance[1, 1]), 0.0)
    return float(beta[1]), float(np.sqrt(variance))


df = pd.read_csv("input.csv")

regions = (
    df[["region_id", "region_weight", "x", "y"]]
    .drop_duplicates("region_id")
    .copy()
)

regions["e"] = regions["region_weight"] / regions["region_weight"].sum()

df = df.merge(
    regions[["region_id", "e"]],
    on="region_id",
    how="left",
    validate="many_to_one",
)

for variable in ["y", "x"]:
    weighted_mean = np.sum(regions["e"] * regions[variable])
    regions[f"{variable}0"] = regions[variable] - weighted_mean

z_by_region = (
    df.assign(share_shock=df["share"] * df["shock"])
    .groupby("region_id", as_index=False)["share_shock"]
    .sum()
    .rename(columns={"share_shock": "z"})
)

regions = regions.merge(
    z_by_region,
    on="region_id",
    how="left",
    validate="one_to_one",
)

z_mean = np.sum(regions["e"] * regions["z"])
regions["z0"] = regions["z"] - z_mean

df = df.merge(
    regions[["region_id", "y0", "x0", "z0"]],
    on="region_id",
    how="left",
    validate="many_to_one",
)

df["weighted_share"] = df["e"] * df["share"]

industry = (
    df.groupby("industry_id", as_index=False)
    .agg(
        s=("weighted_share", "sum"),
        shock=("shock", "first"),
    )
)

for variable in ["y0", "x0", "z0"]:
    numerator = (
        df.assign(
            weighted_value=df["e"] * df["share"] * df[variable]
        )
        .groupby("industry_id", as_index=False)["weighted_value"]
        .sum()
        .rename(columns={"weighted_value": f"{variable}_numerator"})
    )

    industry = industry.merge(
        numerator,
        on="industry_id",
        how="left",
        validate="one_to_one",
    )

    industry[f"{variable}_bar"] = (
        industry[f"{variable}_numerator"] / industry["s"]
    )

industry = industry.loc[
    (industry["s"] > 0)
    & np.isfinite(industry["s"])
    & np.isfinite(industry["shock"])
    & np.isfinite(industry["y0_bar"])
    & np.isfinite(industry["x0_bar"])
    & np.isfinite(industry["z0_bar"])
].copy()

n_industries = int(len(industry))

effect, effect_se = iv_2sls_hc1(
    industry["y0_bar"],
    industry["x0_bar"],
    industry["shock"],
    industry["s"],
)

first_stage, first_stage_se = iv_2sls_hc1(
    industry["x0_bar"],
    industry["z0_bar"],
    industry["shock"],
    industry["s"],
)

effective_shocks = float(1.0 / np.sum(industry["s"] ** 2))

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {
            "term": "effect",
            "estimate": effect,
            "se": effect_se,
            "n_obs": n_industries,
        },
        {
            "term": "first_stage",
            "estimate": first_stage,
            "se": first_stage_se,
            "n_obs": n_industries,
        },
        {
            "term": "effective_shocks",
            "estimate": effective_shocks,
            "se": None,
            "n_obs": n_industries,
        },
    ],
    "method_metadata": {
        "estimator": "shock-level weighted 2SLS",
        "vcov": "heteroskedasticity-robust HC1 with structural IV residuals",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file, ensure_ascii=False, indent=2)
