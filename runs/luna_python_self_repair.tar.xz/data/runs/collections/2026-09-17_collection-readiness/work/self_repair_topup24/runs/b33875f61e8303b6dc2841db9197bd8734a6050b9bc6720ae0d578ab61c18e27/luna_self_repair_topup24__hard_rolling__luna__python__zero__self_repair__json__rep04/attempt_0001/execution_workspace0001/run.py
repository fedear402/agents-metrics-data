import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv").sort_values("time").reset_index(drop=True)

y_by_time = dict(zip(df["time"], df["y"]))
forecasts = {}

for f in range(101, 251):
    s_times = np.arange(f - 99, f)
    x = np.array([y_by_time[s - 1] for s in s_times], dtype=float)
    target = np.array([y_by_time[s] for s in s_times], dtype=float)

    design = np.column_stack([np.ones(len(x)), x])
    coefficients, _, _, _ = np.linalg.lstsq(design, target, rcond=None)
    intercept, slope = coefficients

    forecasts[f] = float(intercept + slope * y_by_time[f - 1])

errors = np.array(
    [y_by_time[f] - forecasts[f] for f in range(101, 251)],
    dtype=float,
)
rmse = float(np.sqrt(np.sum(errors ** 2) / 150))

result = {
    "task_id": "hard_rolling",
    "platform": "python",
    "estimates": [
        {
            "term": "rmse",
            "estimate": rmse,
            "se": None,
            "n_obs": 150,
        },
        {
            "term": "forecast_101",
            "estimate": forecasts[101],
            "se": None,
            "n_obs": 99,
        },
        {
            "term": "forecast_150",
            "estimate": forecasts[150],
            "se": None,
            "n_obs": 99,
        },
        {
            "term": "forecast_200",
            "estimate": forecasts[200],
            "se": None,
            "n_obs": 99,
        },
        {
            "term": "forecast_250",
            "estimate": forecasts[250],
            "se": None,
            "n_obs": 99,
        },
    ],
    "method_metadata": {
        "estimator": "Rolling OLS AR(1) with intercept",
        "vcov": "none",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output_file:
    json.dump(result, output_file, indent=2)
