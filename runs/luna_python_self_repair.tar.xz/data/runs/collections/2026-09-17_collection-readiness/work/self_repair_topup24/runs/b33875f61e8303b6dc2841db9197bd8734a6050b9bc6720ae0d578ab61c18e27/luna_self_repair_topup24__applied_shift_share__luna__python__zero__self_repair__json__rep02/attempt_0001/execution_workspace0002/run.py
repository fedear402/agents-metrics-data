import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")

region = (
    df[["region_id", "region_weight", "x", "y"]]
    .drop_duplicates("region_id")
    .copy()
)

region["e"] = region["region_weight"] / region["region_weight"].sum()

z = (
    df.assign(exposure=df["share"] * df["shock"])
    .groupby("region_id", as_index=False)["exposure"]
    .sum()
    .rename(columns={"exposure": "z"})
)

region = region.merge(z, on="region_id", how="left")

for col in ["y", "x", "z"]:
    region[f"{col}0"] = region[col] - np.sum(region["e"] * region[col])

work = df[["region_id", "industry_id", "share", "shock"]].merge(
    region[["region_id", "e", "y0", "x0", "z0"]],
    on="region_id",
    how="left",
)

work["weighted_share"] = work["e"] * work["share"]

industry = (
    work.groupby("industry_id", as_index=False)
    .agg(
        s=("weighted_share", "sum"),
        shock=("shock", "first"),
    )
)

for value in ["y0", "x0", "z0"]:
    numerator = (
        work.assign(
            numerator=work["weighted_share"] * work[value]
        )
        .groupby("industry_id")["numerator"]
        .sum()
        .rename(f"{value}bar")
    )
    industry = industry.merge(
        numerator,
        on="industry_id",
        how="left",
    )

industry = industry.loc[industry["s"] > 0].reset_index(drop=True)
n_industries = len(industry)


def iv_hc1(y, endog, instrument, weights):
    y = np.asarray(y, dtype=float)
    endog = np.asarray(endog, dtype=float)
    instrument = np.asarray(instrument, dtype=float)
    weights = np.asarray(weights, dtype=float)

    X = np.column_stack([np.ones(len(y)), endog])
    Z = np.column_stack([np.ones(len(y)), instrument])

    weighted_Z = weights[:, None] * Z
    z_cross_z = Z.T @ weighted_Z
    z_cross_z_inv = np.linalg.pinv(z_cross_z)

    x_hat = Z @ (
        z_cross_z_inv @ (Z.T @ (weights[:, None] * X))
    )

    bread = np.linalg.pinv(
        x_hat.T @ (weights[:, None] * X)
    )

    beta = bread @ (x_hat.T @ (weights * y))
    residuals = y - X @ beta

    meat = np.zeros((2, 2))
    for i in range(len(y)):
        score = weights[i] * residuals[i] * x_hat[i]
        meat += np.outer(score, score)

    vcov = bread @ meat @ bread.T
    vcov *= n_industries / (n_industries - 2)

    return beta, vcov


effect_beta, effect_vcov = iv_hc1(
    industry["y0bar"],
    industry["x0bar"],
    industry["shock"],
    industry["s"],
)

first_beta, first_vcov = iv_hc1(
    industry["x0bar"],
    industry["z0bar"],
    industry["shock"],
    industry["s"],
)

effective_shocks = 1.0 / np.sum(
    industry["s"].to_numpy(dtype=float) ** 2
)

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {
            "term": "effect",
            "estimate": float(effect_beta[1]),
            "se": float(np.sqrt(effect_vcov[1, 1])),
            "n_obs": int(n_industries),
        },
        {
            "term": "first_stage",
            "estimate": float(first_beta[1]),
            "se": float(np.sqrt(first_vcov[1, 1])),
            "n_obs": int(n_industries),
        },
        {
            "term": "effective_shocks",
            "estimate": float(effective_shocks),
            "se": None,
            "n_obs": int(n_industries),
        },
    ],
    "method_metadata": {
        "estimator": "Borusyak-Hull-Jaravel shock-level weighted 2SLS",
        "vcov": "shock-level heteroskedasticity-robust HC1",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
