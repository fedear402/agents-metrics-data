import json
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.special import log_ndtr
from statsmodels.tools.numdiff import approx_hess3

df = pd.read_csv("input.csv")

y = df["y"].to_numpy(dtype=float)
X = np.column_stack([
    np.ones(len(df)),
    df["x"].to_numpy(dtype=float),
    df["z"].to_numpy(dtype=float),
])

censored = y <= 0.0
uncensored = ~censored


def loglike(theta):
    beta = theta[:3]
    sigma = np.exp(theta[3])
    mu = X @ beta
    value = 0.0

    if np.any(uncensored):
        e = (y[uncensored] - mu[uncensored]) / sigma
        value += np.sum(
            -np.log(sigma)
            - 0.5 * np.log(2.0 * np.pi)
            - 0.5 * e**2
        )

    if np.any(censored):
        value += np.sum(log_ndtr(-mu[censored] / sigma))

    return value


def objective(theta):
    return -loglike(theta)


positive = y[uncensored]
if len(positive) >= 3:
    beta0 = np.linalg.lstsq(X[uncensored], positive, rcond=None)[0]
    residuals = positive - X[uncensored] @ beta0
    sigma0 = np.std(residuals, ddof=1)
else:
    beta0 = np.zeros(3)
    sigma0 = np.std(y[y > 0]) if np.any(y > 0) else 1.0

if not np.isfinite(sigma0) or sigma0 <= 0:
    sigma0 = 1.0

theta0 = np.r_[beta0, np.log(sigma0)]

fit = minimize(
    objective,
    theta0,
    method="BFGS",
    options={"gtol": 1e-10, "maxiter": 10000},
)

if not fit.success:
    fit = minimize(
        objective,
        fit.x,
        method="Nelder-Mead",
        options={"maxiter": 20000, "xatol": 1e-12, "fatol": 1e-12},
    )
    fit = minimize(
        objective,
        fit.x,
        method="BFGS",
        options={"gtol": 1e-9, "maxiter": 10000},
    )

theta_hat = fit.x
beta_hat = theta_hat[:3]
sigma_hat = float(np.exp(theta_hat[3]))

hessian = approx_hess3(theta_hat, objective)
cov_theta = np.linalg.pinv(hessian)
se_beta = np.sqrt(np.maximum(np.diag(cov_theta)[:3], 0.0))

n_obs = int(len(df))

result = {
    "task_id": "broad_tobit",
    "platform": "python",
    "estimates": [
        {
            "term": "const",
            "estimate": float(beta_hat[0]),
            "se": float(se_beta[0]),
            "n_obs": n_obs,
        },
        {
            "term": "x",
            "estimate": float(beta_hat[1]),
            "se": float(se_beta[1]),
            "n_obs": n_obs,
        },
        {
            "term": "z",
            "estimate": float(beta_hat[2]),
            "se": float(se_beta[2]),
            "n_obs": n_obs,
        },
        {
            "term": "sigma",
            "estimate": sigma_hat,
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "Homoskedastic Gaussian Tobit maximum likelihood with left censoring at zero",
        "vcov": "Inverse observed information from the jointly estimated likelihood",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file, indent=2, allow_nan=False)
