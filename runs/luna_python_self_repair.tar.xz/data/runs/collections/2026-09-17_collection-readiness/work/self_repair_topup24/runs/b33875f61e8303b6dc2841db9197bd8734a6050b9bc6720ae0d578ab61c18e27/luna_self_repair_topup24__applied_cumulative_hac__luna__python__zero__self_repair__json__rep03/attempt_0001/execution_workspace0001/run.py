import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df["date"] = pd.to_datetime(df["date"])
df = df.sort_values("date").reset_index(drop=True)

df["log_sales"] = np.log(df["sales"])
df["log_vix"] = np.log(df["vix"])
df["vix_change"] = df["log_vix"].diff()

for lag in range(1, 16):
    df[f"lag_{lag}"] = df["vix_change"].shift(lag)

reg_cols = [f"lag_{lag}" for lag in range(1, 16)]
sample = df[["log_sales"] + reg_cols].dropna().reset_index(drop=True)

y = sample["log_sales"].to_numpy(dtype=float)
X = np.column_stack([
    np.ones(len(sample)),
    sample[reg_cols].to_numpy(dtype=float)
])

n_obs = len(sample)
beta = np.linalg.solve(X.T @ X, X.T @ y)
residuals = y - X @ beta
scores = X * residuals[:, None]

meat = scores.T @ scores
max_lag = 15

for j in range(1, max_lag + 1):
    weight = 1.0 - j / 16.0
    meat += weight * (
        scores[j:].T @ scores[:-j] +
        scores[:-j].T @ scores[j:]
    )

bread = np.linalg.inv(X.T @ X)
cov = bread @ meat @ bread
cov *= n_obs / (n_obs - 16)

cumulative_vector = np.zeros(16)
cumulative_vector[1:] = 1.0

cumulative_estimate = float(cumulative_vector @ beta)
cumulative_se = float(
    np.sqrt(cumulative_vector @ cov @ cumulative_vector)
)

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {
            "term": "cumulative_response",
            "estimate": cumulative_estimate,
            "se": cumulative_se,
            "n_obs": int(n_obs)
        },
        {
            "term": "lag_1",
            "estimate": float(beta[1]),
            "se": float(np.sqrt(cov[1, 1])),
            "n_obs": int(n_obs)
        },
        {
            "term": "lag_15",
            "estimate": float(beta[15]),
            "se": float(np.sqrt(cov[15, 15])),
            "n_obs": int(n_obs)
        }
    ],
    "method_metadata": {
        "estimator": "OLS with intercept and lags 1 through 15 of first-differenced log volatility",
        "vcov": "Newey-West HAC covariance, maximum lag 15, Bartlett weights, correction N/(N-16)"
    },
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
