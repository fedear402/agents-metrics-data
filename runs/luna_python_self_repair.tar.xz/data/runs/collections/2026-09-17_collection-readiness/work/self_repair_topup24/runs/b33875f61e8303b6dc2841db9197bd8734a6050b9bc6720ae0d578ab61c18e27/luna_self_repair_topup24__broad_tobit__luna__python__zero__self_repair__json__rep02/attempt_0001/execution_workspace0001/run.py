import json
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.special import log_ndtr
from scipy.stats import norm
from statsmodels.tools.numdiff import approx_hess3

df = pd.read_csv("input.csv")

y = df["y"].to_numpy(dtype=float)
X = np.column_stack([
    np.ones(len(df)),
    df["x"].to_numpy(dtype=float),
    df["z"].to_numpy(dtype=float),
])

censored = y <= 0
uncensored = ~censored
n_obs = len(y)

def loglike(theta):
    beta = theta[:3]
    log_sigma = theta[3]
    sigma = np.exp(log_sigma)
    xb = X @ beta

    ll = 0.0
    if np.any(uncensored):
        residuals = (y[uncensored] - xb[uncensored]) / sigma
        ll += np.sum(norm.logpdf(residuals) - log_sigma)
    if np.any(censored):
        ll += np.sum(log_ndtr(-xb[censored] / sigma))
    return ll

def objective(theta):
    value = -loglike(theta)
    if not np.isfinite(value):
        return 1e100
    return value

beta_start = np.linalg.lstsq(X, y, rcond=None)[0]
residuals_start = y - X @ beta_start
sigma_start = max(np.std(residuals_start), 1e-6)
theta_start = np.r_[beta_start, np.log(sigma_start)]

fit = minimize(
    objective,
    theta_start,
    method="BFGS",
    options={"gtol": 1e-10, "maxiter": 2000},
)

if not fit.success:
    fit = minimize(
        objective,
        theta_start,
        method="L-BFGS-B",
        options={"ftol": 1e-15, "gtol": 1e-10, "maxiter": 5000},
    )

theta_hat = fit.x
beta_hat = theta_hat[:3]
sigma_hat = float(np.exp(theta_hat[3]))

hessian = approx_hess3(theta_hat, objective, epsilon=1e-5)
covariance = np.linalg.pinv(hessian)
se_beta = np.sqrt(np.maximum(np.diag(covariance)[:3], 0.0))

result = {
    "task_id": "broad_tobit",
    "platform": "python",
    "estimates": [
        {
            "term": "const",
            "estimate": float(beta_hat[0]),
            "se": float(se_beta[0]),
            "n_obs": int(n_obs),
        },
        {
            "term": "x",
            "estimate": float(beta_hat[1]),
            "se": float(se_beta[1]),
            "n_obs": int(n_obs),
        },
        {
            "term": "z",
            "estimate": float(beta_hat[2]),
            "se": float(se_beta[2]),
            "n_obs": int(n_obs),
        },
        {
            "term": "sigma",
            "estimate": sigma_hat,
            "se": None,
            "n_obs": int(n_obs),
        },
    ],
    "method_metadata": {
        "estimator": "Homoskedastic Gaussian Tobit maximum likelihood with lower censoring at zero",
        "vcov": "Inverse observed information from the jointly estimated likelihood",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file, indent=2)
