import json

import numpy as np
import pandas as pd
import statsmodels.api as sm
from statsmodels.stats.sandwich_covariance import cov_hac, weights_bartlett


df = pd.read_csv("input.csv")
df["date"] = pd.to_datetime(df["date"])
df = df.sort_values("date").reset_index(drop=True)

df["log_sales"] = np.log(df["sales"])
df["log_vix_change"] = np.log(df["vix"]).diff()

lag_names = [f"lag_{i}" for i in range(1, 16)]
for i, name in enumerate(lag_names, start=1):
    df[name] = df["log_vix_change"].shift(i)

sample = df.dropna(subset=["log_sales"] + lag_names).copy()
y = sample["log_sales"]
X = sm.add_constant(sample[lag_names], has_constant="add")

model = sm.OLS(y, X).fit()
n_obs = int(len(sample))

hac_cov = cov_hac(
    model,
    nlags=15,
    weights_func=weights_bartlett,
    use_correction=False,
)
hac_cov *= n_obs / (n_obs - 16)

param_names = ["const"] + lag_names
params = model.params.reindex(param_names).to_numpy(dtype=float)

lag_indices = [param_names.index(name) for name in lag_names]
cumulative_vector = np.zeros(len(param_names))
cumulative_vector[lag_indices] = 1.0

cumulative_estimate = float(cumulative_vector @ params)
cumulative_se = float(
    np.sqrt(cumulative_vector @ hac_cov @ cumulative_vector)
)

lag_1_index = param_names.index("lag_1")
lag_15_index = param_names.index("lag_15")

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {
            "term": "cumulative_response",
            "estimate": cumulative_estimate,
            "se": cumulative_se,
            "n_obs": n_obs,
        },
        {
            "term": "lag_1",
            "estimate": float(params[lag_1_index]),
            "se": float(np.sqrt(hac_cov[lag_1_index, lag_1_index])),
            "n_obs": n_obs,
        },
        {
            "term": "lag_15",
            "estimate": float(params[lag_15_index]),
            "se": float(np.sqrt(hac_cov[lag_15_index, lag_15_index])),
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "OLS with intercept and lags 1 through 15 of first differences in log VIX",
        "vcov": "Newey-West HAC, maximum lag 15, Bartlett weights, multiplied by N/(N-16)",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file, indent=2, allow_nan=False)
