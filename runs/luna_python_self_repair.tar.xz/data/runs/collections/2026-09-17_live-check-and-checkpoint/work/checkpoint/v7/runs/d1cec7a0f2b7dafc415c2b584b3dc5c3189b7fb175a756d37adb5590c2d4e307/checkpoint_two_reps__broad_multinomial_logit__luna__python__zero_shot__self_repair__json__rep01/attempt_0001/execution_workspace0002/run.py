import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("input.csv")

y = pd.Categorical(df["y"], categories=[0, 1, 2], ordered=False)
X = sm.add_constant(df[["x", "z"]], has_constant="add")

model = sm.MNLogit(y, X)
fit = model.fit(method="newton", disp=False)

params = np.asarray(fit.params)
bse = np.asarray(fit.bse)

if params.shape != (3, 2) or bse.shape != (3, 2):
    raise ValueError("Unexpected parameter shape for multinomial logit.")

beta_cat1 = params[:, 0]
beta_cat2 = params[:, 1]
se_cat1 = bse[:, 0]
se_cat2 = bse[:, 1]

eta_cat1_zero = float(beta_cat1[0])
eta_cat2_zero = float(beta_cat2[0])

exp_cat1 = np.exp(eta_cat1_zero)
exp_cat2 = np.exp(eta_cat2_zero)
prob_cat2_zero = exp_cat2 / (1.0 + exp_cat1 + exp_cat2)

n_obs = int(len(df))

result = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": [
        {
            "term": "x_cat1",
            "estimate": float(beta_cat1[1]),
            "se": float(se_cat1[1]),
            "n_obs": n_obs,
        },
        {
            "term": "z_cat1",
            "estimate": float(beta_cat1[2]),
            "se": float(se_cat1[2]),
            "n_obs": n_obs,
        },
        {
            "term": "x_cat2",
            "estimate": float(beta_cat2[1]),
            "se": float(se_cat2[1]),
            "n_obs": n_obs,
        },
        {
            "term": "z_cat2",
            "estimate": float(beta_cat2[2]),
            "se": float(se_cat2[2]),
            "n_obs": n_obs,
        },
        {
            "term": "prob_cat2_zero",
            "estimate": float(prob_cat2_zero),
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "maximum likelihood multinomial logit",
        "vcov": "conventional observed information",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
