import json
import numpy as np
import pandas as pd


def finite_or_none(value):
    value = float(value)
    return value if np.isfinite(value) else None


data = pd.read_csv("input.csv")
data = data.loc[data["score"].abs() < 1].copy()

score = data["score"].to_numpy(dtype=float)
earnings = data["earnings"].to_numpy(dtype=float)
participated = data["participated"].to_numpy(dtype=float)

side = (score >= 0).astype(float)
weights = 1.0 - np.abs(score)

X = np.column_stack([
    np.ones(len(data)),
    score,
    side,
    side * score,
])

W = np.diag(weights)
XtWX = X.T @ W @ X
bread = np.linalg.inv(XtWX)

def estimate_outcome(y):
    beta = bread @ (X.T @ W @ y)
    residuals = y - X @ beta
    meat = X.T @ np.diag((weights ** 2) * (residuals ** 2)) @ X
    vcov = bread @ meat @ bread
    contrast = np.array([0.0, 0.0, 1.0, 0.0])
    estimate = contrast @ beta
    variance = contrast @ vcov @ contrast
    se = np.sqrt(max(float(variance), 0.0))
    return estimate, se, vcov

reduced_form, reduced_form_se, earnings_vcov = estimate_outcome(earnings)
first_stage, first_stage_se, participation_vcov = estimate_outcome(participated)

cross_meat = (
    X.T
    @ np.diag((weights ** 2) * (earnings - X @ (bread @ (X.T @ W @ earnings)))
      * (participated - X @ (bread @ (X.T @ W @ participated))))
    @ X
)
cross_vcov = bread @ cross_meat @ bread

contrast = np.array([0.0, 0.0, 1.0, 0.0])
var_reduced_form = contrast @ earnings_vcov @ contrast
var_first_stage = contrast @ participation_vcov @ contrast
cov_reduced_first = contrast @ cross_vcov @ contrast

if first_stage == 0 or not np.isfinite(first_stage):
    treatment_effect = None
    treatment_effect_se = None
else:
    treatment_effect = reduced_form / first_stage
    treatment_variance = (
        var_reduced_form / first_stage**2
        + reduced_form**2 * var_first_stage / first_stage**4
        - 2 * reduced_form * cov_reduced_first / first_stage**3
    )
    treatment_effect_se = np.sqrt(max(float(treatment_variance), 0.0))

n_obs = int(len(data))

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {
            "term": "treatment_effect",
            "estimate": finite_or_none(treatment_effect),
            "se": finite_or_none(treatment_effect_se),
            "n_obs": n_obs,
        },
        {
            "term": "reduced_form",
            "estimate": finite_or_none(reduced_form),
            "se": finite_or_none(reduced_form_se),
            "n_obs": n_obs,
        },
        {
            "term": "first_stage",
            "estimate": finite_or_none(first_stage),
            "se": finite_or_none(first_stage_se),
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "Fuzzy local-linear regression discontinuity with triangular weights",
        "vcov": "Conventional heteroskedasticity-robust HC0 with joint delta-method covariance",
    },
    "diagnostics": {},
}

with open("result.json", "w") as output_file:
    json.dump(result, output_file, allow_nan=False)
