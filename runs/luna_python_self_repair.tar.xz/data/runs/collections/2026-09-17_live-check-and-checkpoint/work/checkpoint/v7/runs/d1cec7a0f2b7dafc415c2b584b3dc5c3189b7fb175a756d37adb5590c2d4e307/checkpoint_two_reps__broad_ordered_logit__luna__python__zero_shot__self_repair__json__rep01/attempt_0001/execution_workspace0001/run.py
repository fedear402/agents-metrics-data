import json
import numpy as np
import pandas as pd
from statsmodels.miscmodels.ordinal_model import OrderedModel

df = pd.read_csv("input.csv")

model = OrderedModel(
    df["y"],
    df[["x", "z"]],
    distr="logit",
)

fit = model.fit(method="bfgs", disp=False)

params = np.asarray(fit.params, dtype=float)
hessian = np.asarray(model.hessian(params), dtype=float)
cov = np.linalg.inv(-hessian)
se = np.sqrt(np.diag(cov))

pred = model.predict(params, exog=pd.DataFrame({"x": [1.0], "z": [0.0]}))
prob_high = float(np.asarray(pred)[0, 2])

n_obs = int(len(df))

result = {
    "task_id": "broad_ordered_logit",
    "platform": "python",
    "estimates": [
        {
            "term": "x",
            "estimate": float(params[0]),
            "se": float(se[0]),
            "n_obs": n_obs,
        },
        {
            "term": "z",
            "estimate": float(params[1]),
            "se": float(se[1]),
            "n_obs": n_obs,
        },
        {
            "term": "prob_high",
            "estimate": prob_high,
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "maximum likelihood ordered logit",
        "vcov": "conventional observed-information",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
