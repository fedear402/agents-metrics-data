import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy.stats import f as f_distribution

df = pd.read_csv("input.csv")

y = df["y"].to_numpy(dtype=float)
endog = df["endog"].to_numpy(dtype=float)
x = df["x"].to_numpy(dtype=float)
z = df[["z1", "z2"]].to_numpy(dtype=float)

n_obs = len(df)
q = 2
den_df = n_obs - 4

controls = np.column_stack([np.ones(n_obs), x])
m_controls = np.eye(n_obs) - controls @ np.linalg.inv(controls.T @ controls) @ controls.T

z_resid = m_controls @ z
a_inv = np.linalg.inv(z_resid.T @ z_resid)

def ar_f(beta):
    w = y - beta * endog
    w_resid = m_controls @ w
    b = z_resid.T @ w_resid
    explained = float(b.T @ a_inv @ b)
    total_ss = float(w_resid.T @ w_resid)
    residual_ss = total_ss - explained
    return (explained / q) / (residual_ss / den_df)

f_critical = float(f_distribution.ppf(0.95, q, den_df))

# Construct the quadratic inequality:
# explained(beta) * den_df <= q * f_critical * residual_ss(beta)
def quadratic_value(beta):
    w = y - beta * endog
    w_resid = m_controls @ w
    b = z_resid.T @ w_resid
    explained = float(b.T @ a_inv @ b)
    total_ss = float(w_resid.T @ w_resid)
    residual_ss = total_ss - explained
    return q * f_critical * residual_ss - den_df * explained

v0 = quadratic_value(0.0)
v1 = quadratic_value(1.0)
vm1 = quadratic_value(-1.0)

c0 = v0
c2 = (vm1 + v1 - 2.0 * c0) / 2.0
c1 = (v1 - vm1) / 2.0

roots = np.roots([c2, c1, c0])
real_roots = sorted(float(r.real) for r in roots if abs(r.imag) < 1e-8)

boundary_low = real_roots[0]
boundary_high = real_roots[-1]

tail_positive = c2 < 0 or (abs(c2) < 1e-12 and c1 < 0)
tail_negative = c2 < 0 or (abs(c2) < 1e-12 and c1 > 0)
unbounded = int(tail_positive or tail_negative)

accepts_zero = int(ar_f(0.0) <= f_critical)

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": [
        {
            "term": "boundary_low",
            "estimate": boundary_low,
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "boundary_high",
            "estimate": boundary_high,
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "accepts_zero",
            "estimate": float(accepts_zero),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "unbounded",
            "estimate": float(unbounded),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "ar_f_at_one",
            "estimate": float(ar_f(1.0)),
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "Anderson-Rubin confidence set inversion using conventional homoskedastic joint F test",
        "vcov": "conventional homoskedastic",
    },
    "diagnostics": {},
}

with open("result.json", "w") as output_file:
    json.dump(result, output_file, indent=2)
