import json
import numpy as np
import pandas as pd

TASK_ID = "applied_fuzzy_rd"

df = pd.read_csv("input.csv")
df = df.loc[df["score"].abs() < 1].copy()

score = df["score"].to_numpy(dtype=float)
earnings = df["earnings"].to_numpy(dtype=float)
participated = df["participated"].to_numpy(dtype=float)
weights = 1.0 - np.abs(score)

left = (score < 0).astype(float)
right = (score >= 0).astype(float)

X = np.column_stack([
    left,
    left * score,
    right,
    right * score,
])

W = np.diag(weights)
bread = np.linalg.inv(X.T @ W @ X)

contrast = np.array([-1.0, 0.0, 1.0, 0.0])
loading = weights * (X @ bread @ contrast)

def estimate_discontinuity(y):
    coefficients = bread @ X.T @ (weights * y)
    residuals = y - X @ coefficients
    discontinuity = float(contrast @ coefficients)
    influence = loading * residuals
    return discontinuity, residuals, influence

reduced_form, earnings_resid, earnings_influence = estimate_discontinuity(earnings)
first_stage, participation_resid, participation_influence = estimate_discontinuity(participated)

earnings_variance = float(earnings_influence @ earnings_influence)
participation_variance = float(participation_influence @ participation_influence)
cross_covariance = float(earnings_influence @ participation_influence)

gradient = np.array([
    1.0 / first_stage,
    -reduced_form / (first_stage ** 2),
])

joint_covariance = np.array([
    [earnings_variance, cross_covariance],
    [cross_covariance, participation_variance],
])

treatment_effect = reduced_form / first_stage
treatment_variance = float(gradient @ joint_covariance @ gradient)

n_obs = int(len(df))

result = {
    "task_id": TASK_ID,
    "platform": "python",
    "estimates": [
        {
            "term": "treatment_effect",
            "estimate": float(treatment_effect),
            "se": float(np.sqrt(treatment_variance)),
            "n_obs": n_obs,
        },
        {
            "term": "reduced_form",
            "estimate": float(reduced_form),
            "se": float(np.sqrt(earnings_variance)),
            "n_obs": n_obs,
        },
        {
            "term": "first_stage",
            "estimate": float(first_stage),
            "se": float(np.sqrt(participation_variance)),
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "fuzzy local-linear regression discontinuity with triangular weights",
        "vcov": "HC0 heteroskedasticity-robust covariance with delta method",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
