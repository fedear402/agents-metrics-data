import json
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("input.csv")

df["y"] = pd.Categorical(df["y"], categories=[0, 1, 2], ordered=True)
X = sm.add_constant(df[["x", "z"]], has_constant="add")

model = sm.MNLogit(df["y"], X)
fit = model.fit(method="newton", disp=False)

params = fit.params.to_numpy()
bse = fit.bse.to_numpy()

# Statsmodels uses the first outcome, 0, as the base category.
# Remaining columns correspond to outcomes 1 and 2.
if params.shape[1] != 2:
    raise ValueError("Expected two non-base outcome parameter vectors.")

n_obs = int(len(df))

beta_cat1 = params[:, 0]
beta_cat2 = params[:, 1]
se_cat1 = bse[:, 0]
se_cat2 = bse[:, 1]

eta_cat1_zero = beta_cat1[0]
eta_cat2_zero = beta_cat2[0]

denom = 1.0 + pd.np.exp(eta_cat1_zero) + pd.np.exp(eta_cat2_zero)
prob_cat2_zero = pd.np.exp(eta_cat2_zero) / denom

result = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": [
        {
            "term": "x_cat1",
            "estimate": float(beta_cat1[1]),
            "se": float(se_cat1[1]),
            "n_obs": n_obs,
        },
        {
            "term": "z_cat1",
            "estimate": float(beta_cat1[2]),
            "se": float(se_cat1[2]),
            "n_obs": n_obs,
        },
        {
            "term": "x_cat2",
            "estimate": float(beta_cat2[1]),
            "se": float(se_cat2[1]),
            "n_obs": n_obs,
        },
        {
            "term": "z_cat2",
            "estimate": float(beta_cat2[2]),
            "se": float(se_cat2[2]),
            "n_obs": n_obs,
        },
        {
            "term": "prob_cat2_zero",
            "estimate": float(prob_cat2_zero),
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "maximum likelihood multinomial logit",
        "vcov": "conventional observed information",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
