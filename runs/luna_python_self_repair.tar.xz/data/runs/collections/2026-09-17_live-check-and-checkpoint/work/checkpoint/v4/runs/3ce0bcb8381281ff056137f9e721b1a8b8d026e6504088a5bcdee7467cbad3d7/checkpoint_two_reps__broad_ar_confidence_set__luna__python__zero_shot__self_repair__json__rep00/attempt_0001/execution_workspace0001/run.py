import json
import numpy as np
import pandas as pd
from scipy.stats import f

df = pd.read_csv("input.csv")
n = len(df)

y = df["y"].to_numpy(dtype=float)
endog = df["endog"].to_numpy(dtype=float)
x = df["x"].to_numpy(dtype=float)
z1 = df["z1"].to_numpy(dtype=float)
z2 = df["z2"].to_numpy(dtype=float)

base = np.column_stack([np.ones(n), x])
full = np.column_stack([np.ones(n), x, z1, z2])

def rss(design, response):
    residuals = response - design @ np.linalg.lstsq(design, response, rcond=None)[0]
    return float(residuals @ residuals)

def numerator(beta):
    return rss(base, y - beta * endog) - rss(full, y - beta * endog)

def denominator(beta):
    return rss(full, y - beta * endog)

df_num = 2
df_den = n - 4
f_critical = f.ppf(0.95, df_num, df_den)
scale = 2.0 * f_critical / df_den

def inequality(beta):
    return numerator(beta) - scale * denominator(beta)

p_minus = inequality(-1.0)
p_zero = inequality(0.0)
p_plus = inequality(1.0)

coef_a = 0.5 * (p_plus + p_minus) - p_zero
coef_b = 0.5 * (p_plus - p_minus)
coef_c = p_zero

coefficients = np.array([coef_a, coef_b, coef_c], dtype=float)
scale_coeff = max(1.0, np.max(np.abs(coefficients)))
trimmed = coefficients.copy()

while len(trimmed) > 1 and abs(trimmed[0]) <= 1e-12 * scale_coeff:
    trimmed = trimmed[1:]

roots = np.roots(trimmed)
real_roots = sorted(
    float(root.real)
    for root in roots
    if abs(root.imag) <= 1e-8 * max(1.0, abs(root.real))
)

boundary_low = real_roots[0]
boundary_high = real_roots[-1]

def ar_f(beta):
    den = denominator(beta)
    if den == 0:
        return float("inf")
    return numerator(beta) / 2.0 / (den / df_den)

accepts_zero = int(ar_f(0.0) <= f_critical)

leading = trimmed[0]
degree = len(trimmed) - 1

if degree == 0:
    unbounded = int(trimmed[0] <= 0)
elif degree == 1:
    unbounded = 1
else:
    unbounded = int(leading < 0)

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": [
        {
            "term": "boundary_low",
            "estimate": boundary_low,
            "se": None,
            "n_obs": n,
        },
        {
            "term": "boundary_high",
            "estimate": boundary_high,
            "se": None,
            "n_obs": n,
        },
        {
            "term": "accepts_zero",
            "estimate": float(accepts_zero),
            "se": None,
            "n_obs": n,
        },
        {
            "term": "unbounded",
            "estimate": float(unbounded),
            "se": None,
            "n_obs": n,
        },
        {
            "term": "ar_f_at_one",
            "estimate": ar_f(1.0),
            "se": None,
            "n_obs": n,
        },
    ],
    "method_metadata": {
        "estimator": "Anderson-Rubin confidence set inversion",
        "vcov": "conventional homoskedastic",
    },
    "diagnostics": {},
}

with open("result.json", "w") as file:
    json.dump(result, file)
