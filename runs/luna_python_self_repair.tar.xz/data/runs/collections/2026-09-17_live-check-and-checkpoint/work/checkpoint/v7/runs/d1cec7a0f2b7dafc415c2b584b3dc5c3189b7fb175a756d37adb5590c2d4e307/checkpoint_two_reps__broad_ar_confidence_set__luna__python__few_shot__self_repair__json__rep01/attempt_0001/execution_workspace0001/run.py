import json
import numpy as np
import pandas as pd
from scipy.stats import f

data = pd.read_csv("input.csv")

y = data["y"].to_numpy(dtype=float)
endog = data["endog"].to_numpy(dtype=float)
x = data["x"].to_numpy(dtype=float)
z1 = data["z1"].to_numpy(dtype=float)
z2 = data["z2"].to_numpy(dtype=float)

n = len(data)
q = 2
df = n - 4

restricted_design = np.column_stack([np.ones(n), x])
unrestricted_design = np.column_stack([np.ones(n), x, z1, z2])

def residual_sum_squares(response, design):
    residuals = response - design @ np.linalg.lstsq(
        design, response, rcond=None
    )[0]
    return residuals @ residuals

def ar_statistic(beta):
    response = y - beta * endog
    ssr_restricted = residual_sum_squares(response, restricted_design)
    ssr_unrestricted = residual_sum_squares(response, unrestricted_design)
    return (
        ((ssr_restricted - ssr_unrestricted) / q)
        / (ssr_unrestricted / df)
    )

critical = f.ppf(0.95, q, df)
k = q * critical / df

ry = y - restricted_design @ np.linalg.lstsq(
    restricted_design, y, rcond=None
)[0]
rd = endog - restricted_design @ np.linalg.lstsq(
    restricted_design, endog, rcond=None
)[0]

uy = y - unrestricted_design @ np.linalg.lstsq(
    unrestricted_design, y, rcond=None
)[0]
ud = endog - unrestricted_design @ np.linalg.lstsq(
    unrestricted_design, endog, rcond=None
)[0]

A = rd @ rd - (1 + k) * (ud @ ud)
B = -2 * (ry @ rd - (1 + k) * (uy @ ud))
C = ry @ ry - (1 + k) * (uy @ uy)

roots = np.roots([A, B, C])
boundaries = np.sort(np.real(roots[np.abs(np.imag(roots)) < 1e-8]))

def accepts(beta):
    return A * beta**2 + B * beta + C <= 0

rows = [
    {
        "term": "boundary_low",
        "estimate": float(boundaries[0]),
        "se": None,
        "n_obs": n,
    },
    {
        "term": "boundary_high",
        "estimate": float(boundaries[1]),
        "se": None,
        "n_obs": n,
    },
    {
        "term": "accepts_zero",
        "estimate": float(int(accepts(0.0))),
        "se": None,
        "n_obs": n,
    },
    {
        "term": "unbounded",
        "estimate": float(int(A < 0)),
        "se": None,
        "n_obs": n,
    },
    {
        "term": "ar_f_at_one",
        "estimate": float(ar_statistic(1.0)),
        "se": None,
        "n_obs": n,
    },
]

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": rows,
    "method_metadata": {
        "estimator": "95% Anderson-Rubin confidence set inversion",
        "vcov": "conventional homoskedastic joint F test",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
