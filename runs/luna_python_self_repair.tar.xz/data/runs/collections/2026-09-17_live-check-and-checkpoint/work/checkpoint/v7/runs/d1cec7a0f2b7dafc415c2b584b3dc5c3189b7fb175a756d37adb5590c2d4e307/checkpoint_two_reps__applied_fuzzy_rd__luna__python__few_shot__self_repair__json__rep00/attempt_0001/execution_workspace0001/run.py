import json
import numpy as np
import pandas as pd

data = pd.read_csv("input.csv")

inside = data["score"].abs() < 1
sample = data.loc[inside].copy()

score = sample["score"].to_numpy(dtype=float)
participated = sample["participated"].to_numpy(dtype=float)
earnings = sample["earnings"].to_numpy(dtype=float)

right = (score >= 0).astype(float)
weights = 1.0 - np.abs(score)

X = np.column_stack([
    np.ones(len(sample)),
    score,
    right,
    right * score,
])

weighted_x = weights[:, None] * X
bread = np.linalg.inv(X.T @ weighted_x)

def estimate_and_covariance(y1, y2):
    coefficients_1 = bread @ (X.T @ (weights * y1))
    coefficients_2 = bread @ (X.T @ (weights * y2))

    residuals_1 = y1 - X @ coefficients_1
    residuals_2 = y2 - X @ coefficients_2

    contrast = np.array([0.0, 0.0, 1.0, 0.0])
    jump_1 = float(contrast @ coefficients_1)
    jump_2 = float(contrast @ coefficients_2)

    loading = weights * (X @ bread @ contrast)

    influence_1 = loading * residuals_1
    influence_2 = loading * residuals_2

    covariance = np.array([
        [influence_1 @ influence_1, influence_1 @ influence_2],
        [influence_1 @ influence_2, influence_2 @ influence_2],
    ])

    return jump_1, jump_2, covariance

earnings_jump, participation_jump, joint_covariance = estimate_and_covariance(
    earnings,
    participated,
)

reduced_form_se = float(np.sqrt(joint_covariance[0, 0]))
first_stage_se = float(np.sqrt(joint_covariance[1, 1]))

treatment_effect = earnings_jump / participation_jump
gradient = np.array([
    1.0 / participation_jump,
    -earnings_jump / (participation_jump ** 2),
])
treatment_effect_se = float(
    np.sqrt(gradient @ joint_covariance @ gradient)
)

n_obs = int(len(sample))

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {
            "term": "treatment_effect",
            "estimate": float(treatment_effect),
            "se": treatment_effect_se,
            "n_obs": n_obs,
        },
        {
            "term": "reduced_form",
            "estimate": float(earnings_jump),
            "se": reduced_form_se,
            "n_obs": n_obs,
        },
        {
            "term": "first_stage",
            "estimate": float(participation_jump),
            "se": first_stage_se,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "Fuzzy local-linear regression discontinuity with triangular weights",
        "vcov": "Conventional heteroskedasticity-robust HC0 with joint covariance and delta method",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
