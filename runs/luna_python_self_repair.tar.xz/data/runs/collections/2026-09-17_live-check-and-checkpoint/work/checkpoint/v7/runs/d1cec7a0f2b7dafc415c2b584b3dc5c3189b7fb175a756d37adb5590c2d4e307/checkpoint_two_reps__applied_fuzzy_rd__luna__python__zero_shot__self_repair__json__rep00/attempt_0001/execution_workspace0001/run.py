import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df = df[np.abs(df["score"]) < 1].copy()

x = df["score"].to_numpy(dtype=float)
y = df["earnings"].to_numpy(dtype=float)
d = df["participated"].to_numpy(dtype=float)
w = 1.0 - np.abs(x)

def fit_discontinuity(outcome):
    estimates = {}
    influences = np.zeros(len(x))

    for side, mask in {
        "left": x < 0,
        "right": x >= 0,
    }.items():
        xi = x[mask]
        yi = outcome[mask]
        wi = w[mask]

        X = np.column_stack([np.ones(len(xi)), xi])
        XtWX = X.T @ (wi[:, None] * X)
        bread = np.linalg.pinv(XtWX)
        beta = bread @ (X.T @ (wi * yi))
        residuals = yi - X @ beta

        estimates[side] = beta[0]

        local_influence = (X @ bread[:, 0]) * wi * residuals
        influences[mask] = local_influence

    discontinuity = estimates["right"] - estimates["left"]
    variance = np.sum(influences ** 2)

    return discontinuity, variance, influences

reduced_form, var_rf, infl_rf = fit_discontinuity(y)
first_stage, var_fs, infl_fs = fit_discontinuity(d)

cov_rf_fs = np.sum(infl_rf * infl_fs)

if first_stage == 0:
    treatment_effect = None
    se_treatment = None
else:
    treatment_effect = reduced_form / first_stage
    var_treatment = (
        var_rf / first_stage**2
        + (reduced_form**2 * var_fs) / first_stage**4
        - (2 * reduced_form * cov_rf_fs) / first_stage**3
    )
    se_treatment = float(np.sqrt(max(var_treatment, 0.0)))

n_obs = int(len(df))

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {
            "term": "treatment_effect",
            "estimate": treatment_effect,
            "se": se_treatment,
            "n_obs": n_obs,
        },
        {
            "term": "reduced_form",
            "estimate": float(reduced_form),
            "se": float(np.sqrt(max(var_rf, 0.0))),
            "n_obs": n_obs,
        },
        {
            "term": "first_stage",
            "estimate": float(first_stage),
            "se": float(np.sqrt(max(var_fs, 0.0))),
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "Fuzzy local-linear regression discontinuity with triangular kernel weights",
        "vcov": "Conventional heteroskedasticity-robust HC0 with delta-method treatment-effect standard error",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2, allow_nan=False)
