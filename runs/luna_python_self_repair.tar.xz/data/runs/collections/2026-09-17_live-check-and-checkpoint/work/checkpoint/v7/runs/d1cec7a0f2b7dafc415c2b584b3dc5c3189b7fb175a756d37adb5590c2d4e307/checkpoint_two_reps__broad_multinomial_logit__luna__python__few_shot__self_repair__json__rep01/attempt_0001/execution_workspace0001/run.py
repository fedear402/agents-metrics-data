import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy.special import softmax

data = pd.read_csv("input.csv")

y = data["y"]
X = sm.add_constant(data[["x", "z"]], has_constant="add")

fit = sm.MNLogit(y, X).fit(disp=False, method="newton", maxiter=1000, tol=1e-12)

outcomes = sorted(pd.unique(y))
base_outcome = 0
nonbase_outcomes = [outcome for outcome in outcomes if outcome != base_outcome]

params = fit.params.copy()
bse = fit.bse.copy()
params.columns = nonbase_outcomes
bse.columns = nonbase_outcomes

zero_input = pd.DataFrame({"const": [1.0], "x": [0.0], "z": [0.0]})
probabilities = np.asarray(fit.predict(zero_input))[0]
probability_by_outcome = dict(zip(outcomes, probabilities))

n_obs = int(len(data))

result = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": [
        {
            "term": "x_cat1",
            "estimate": float(params.loc["x", 1]),
            "se": float(bse.loc["x", 1]),
            "n_obs": n_obs,
        },
        {
            "term": "z_cat1",
            "estimate": float(params.loc["z", 1]),
            "se": float(bse.loc["z", 1]),
            "n_obs": n_obs,
        },
        {
            "term": "x_cat2",
            "estimate": float(params.loc["x", 2]),
            "se": float(bse.loc["x", 2]),
            "n_obs": n_obs,
        },
        {
            "term": "z_cat2",
            "estimate": float(params.loc["z", 2]),
            "se": float(bse.loc["z", 2]),
            "n_obs": n_obs,
        },
        {
            "term": "prob_cat2_zero",
            "estimate": float(probability_by_outcome[2]),
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "multinomial logit maximum likelihood",
        "vcov": "conventional observed-information",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
