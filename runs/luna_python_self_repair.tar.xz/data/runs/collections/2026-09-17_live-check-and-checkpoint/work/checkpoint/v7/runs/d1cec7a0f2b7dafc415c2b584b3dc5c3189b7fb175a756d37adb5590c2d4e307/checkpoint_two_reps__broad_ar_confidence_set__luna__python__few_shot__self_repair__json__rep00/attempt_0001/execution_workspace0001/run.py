import json
import numpy as np
import pandas as pd
from scipy.stats import f

data = pd.read_csv("input.csv")

y = data["y"].to_numpy(dtype=float)
endog = data["endog"].to_numpy(dtype=float)
x = data["x"].to_numpy(dtype=float)
z1 = data["z1"].to_numpy(dtype=float)
z2 = data["z2"].to_numpy(dtype=float)

n = len(data)
q = 2
df = n - 4

restricted_design = np.column_stack([np.ones(n), x])
unrestricted_design = np.column_stack([np.ones(n), x, z1, z2])

def residualize(value, design):
    coefficients = np.linalg.lstsq(design, value, rcond=None)[0]
    return value - design @ coefficients

def ssr(beta, design):
    outcome = y - beta * endog
    residual = outcome - design @ np.linalg.lstsq(design, outcome, rcond=None)[0]
    return residual @ residual

critical = f.ppf(0.95, q, df)
factor = 1.0 + q * critical / df

ry = residualize(y, restricted_design)
re = residualize(endog, restricted_design)
uy = residualize(y, unrestricted_design)
ue = residualize(endog, unrestricted_design)

A = re @ re - factor * (ue @ ue)
B = -2.0 * (ry @ re - factor * (uy @ ue))
C = ry @ ry - factor * (uy @ uy)

roots = np.roots([A, B, C])
real_roots = np.sort(roots.real[np.abs(roots.imag) < 1e-8])

if len(real_roots) != 2:
    raise ValueError("Expected two finite real Anderson-Rubin boundaries.")

boundary_low = float(real_roots[0])
boundary_high = float(real_roots[1])

def ar_f(beta):
    outcome = y - beta * endog
    ssr_restricted = ssr(beta, restricted_design)
    ssr_unrestricted = ssr(beta, unrestricted_design)
    return ((ssr_restricted - ssr_unrestricted) / q) / (
        ssr_unrestricted / df
    )

def accepts(beta):
    return A * beta * beta + B * beta + C <= 0.0

rows = [
    {
        "term": "boundary_low",
        "estimate": boundary_low,
        "se": None,
        "n_obs": n,
    },
    {
        "term": "boundary_high",
        "estimate": boundary_high,
        "se": None,
        "n_obs": n,
    },
    {
        "term": "accepts_zero",
        "estimate": float(int(accepts(0.0))),
        "se": None,
        "n_obs": n,
    },
    {
        "term": "unbounded",
        "estimate": float(int(A < 0.0)),
        "se": None,
        "n_obs": n,
    },
    {
        "term": "ar_f_at_one",
        "estimate": float(ar_f(1.0)),
        "se": None,
        "n_obs": n,
    },
]

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": rows,
    "method_metadata": {
        "estimator": "Anderson-Rubin confidence set inversion",
        "vcov": "homoskedastic joint F test",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
