import json
import pandas as pd
from statsmodels.miscmodels.ordinal_model import OrderedModel

df = pd.read_csv("input.csv")

model = OrderedModel(
    endog=df["y"],
    exog=df[["x", "z"]],
    distr="logit"
)

result = model.fit(method="bfgs", disp=False)

pred_data = pd.DataFrame({"x": [1.0], "z": [0.0]})
predicted = result.predict(pred_data)
prob_high = float(predicted.iloc[0, 2])

output = {
    "task_id": "broad_ordered_logit",
    "platform": "python",
    "estimates": [
        {
            "term": "x",
            "estimate": float(result.params["x"]),
            "se": float(result.bse["x"]),
            "n_obs": int(len(df))
        },
        {
            "term": "z",
            "estimate": float(result.params["z"]),
            "se": float(result.bse["z"]),
            "n_obs": int(len(df))
        },
        {
            "term": "prob_high",
            "estimate": prob_high,
            "se": None,
            "n_obs": int(len(df))
        }
    ],
    "method_metadata": {
        "estimator": "maximum likelihood ordered logit",
        "vcov": "conventional observed-information"
    },
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(output, f, indent=2)
