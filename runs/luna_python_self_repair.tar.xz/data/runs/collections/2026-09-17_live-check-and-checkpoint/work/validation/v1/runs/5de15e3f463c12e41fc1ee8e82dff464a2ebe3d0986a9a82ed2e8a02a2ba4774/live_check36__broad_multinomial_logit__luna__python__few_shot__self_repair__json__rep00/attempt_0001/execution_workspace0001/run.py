import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy.special import softmax

data = pd.read_csv("input.csv")
n_obs = len(data)

X = sm.add_constant(data[["x", "z"]], has_constant="add")
y = data["y"]

fit = sm.MNLogit(y, X).fit(disp=False, tol=1e-10)

outcomes = sorted(pd.unique(y))
base_outcome = 0
nonbase_outcomes = [outcome for outcome in outcomes if outcome != base_outcome]

coefficients = fit.params.copy()
standard_errors = fit.bse.copy()
coefficients.columns = nonbase_outcomes
standard_errors.columns = nonbase_outcomes

zero_index = pd.DataFrame({"const": [1.0], "x": [0.0], "z": [0.0]})
linear_indices = [0.0] + [
    coefficients.loc["const", outcome] for outcome in nonbase_outcomes
]
probabilities = softmax(np.asarray(linear_indices, dtype=float))
prob_cat2_zero = probabilities[nonbase_outcomes.index(2) + 1]

rows = [
    {
        "term": "x_cat1",
        "estimate": float(coefficients.loc["x", 1]),
        "se": float(standard_errors.loc["x", 1]),
        "n_obs": int(n_obs),
    },
    {
        "term": "z_cat1",
        "estimate": float(coefficients.loc["z", 1]),
        "se": float(standard_errors.loc["z", 1]),
        "n_obs": int(n_obs),
    },
    {
        "term": "x_cat2",
        "estimate": float(coefficients.loc["x", 2]),
        "se": float(standard_errors.loc["x", 2]),
        "n_obs": int(n_obs),
    },
    {
        "term": "z_cat2",
        "estimate": float(coefficients.loc["z", 2]),
        "se": float(standard_errors.loc["z", 2]),
        "n_obs": int(n_obs),
    },
    {
        "term": "prob_cat2_zero",
        "estimate": float(prob_cat2_zero),
        "se": None,
        "n_obs": int(n_obs),
    },
]

result = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": rows,
    "method_metadata": {
        "estimator": "multinomial logit maximum likelihood",
        "vcov": "conventional observed-information standard errors",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
