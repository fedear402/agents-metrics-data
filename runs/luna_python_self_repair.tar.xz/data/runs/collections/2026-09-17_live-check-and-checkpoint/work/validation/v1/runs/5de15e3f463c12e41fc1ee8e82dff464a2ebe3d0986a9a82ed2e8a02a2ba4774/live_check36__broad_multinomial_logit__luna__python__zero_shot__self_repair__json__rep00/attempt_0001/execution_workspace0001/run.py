import json

import numpy as np
import pandas as pd
import statsmodels.api as sm


df = pd.read_csv("input.csv")

y = df["y"].astype(int)
X = sm.add_constant(df[["x", "z"]], has_constant="add")

model = sm.MNLogit(y, X)
result = model.fit(method="newton", disp=False)

params = np.asarray(result.params)
ses = np.asarray(result.bse)

# Statsmodels orders non-base outcomes as 1 and 2 when outcome 0 is the base.
coef_cat1 = params[:, 0]
coef_cat2 = params[:, 1]
se_cat1 = ses[:, 0]
se_cat2 = ses[:, 1]

# At x = 0 and z = 0, the linear predictors are the intercepts.
eta = np.array([0.0, coef_cat1[0], coef_cat2[0]])
eta -= np.max(eta)
probabilities = np.exp(eta) / np.exp(eta).sum()
prob_cat2_zero = float(probabilities[2])

n_obs = int(len(df))

output = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": [
        {
            "term": "x_cat1",
            "estimate": float(coef_cat1[1]),
            "se": float(se_cat1[1]),
            "n_obs": n_obs,
        },
        {
            "term": "z_cat1",
            "estimate": float(coef_cat1[2]),
            "se": float(se_cat1[2]),
            "n_obs": n_obs,
        },
        {
            "term": "x_cat2",
            "estimate": float(coef_cat2[1]),
            "se": float(se_cat2[1]),
            "n_obs": n_obs,
        },
        {
            "term": "z_cat2",
            "estimate": float(coef_cat2[2]),
            "se": float(se_cat2[2]),
            "n_obs": n_obs,
        },
        {
            "term": "prob_cat2_zero",
            "estimate": prob_cat2_zero,
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "maximum likelihood multinomial logit",
        "vcov": "conventional observed-information",
    },
    "diagnostics": {},
}

with open("result.json", "w") as file:
    json.dump(output, file, indent=2)
