suppressWarnings(suppressMessages(library(jsonlite)))
d <- read.csv("input.csv", stringsAsFactors = FALSE)

reg <- d[!duplicated(d$region_id), c("region_id", "region_weight", "x", "y")]
reg$e <- reg$region_weight / sum(reg$region_weight)
zr <- tapply(d$share * d$shock, d$region_id, sum)
reg$z <- as.numeric(zr[as.character(reg$region_id)])

wm <- function(v, w) sum(w * v) / sum(w)
reg$y0 <- reg$y - wm(reg$y, reg$e)
reg$x0 <- reg$x - wm(reg$x, reg$e)
reg$z0 <- reg$z - wm(reg$z, reg$e)

# regional weighted 2SLS slope and first stage
beta_reg <- sum(reg$e * reg$z0 * reg$y0) / sum(reg$e * reg$z0 * reg$x0)
fs_reg <- sum(reg$e * reg$z0 * reg$x0) / sum(reg$e * reg$z0 * reg$z0)

m <- match(d$region_id, reg$region_id)
d$es <- reg$e[m] * d$share
ind <- sort(unique(d$industry_id))
s <- as.numeric(tapply(d$es, d$industry_id, sum)[as.character(ind)])
agg <- function(v) as.numeric(tapply(d$es * v, d$industry_id, sum)[as.character(ind)]) / s
ybar <- agg(reg$y0[m]); xbar <- agg(reg$x0[m]); zbar <- agg(reg$z0[m])
g <- as.numeric(tapply(d$shock, d$industry_id, mean)[as.character(ind)])
keep <- s > 0
s <- s[keep]; ybar <- ybar[keep]; xbar <- xbar[keep]; zbar <- zbar[keep]; g <- g[keep]
N <- length(s)

wiv <- function(yv, xv, gv, w) {
  X <- cbind(1, xv); Z <- cbind(1, gv)
  A <- crossprod(Z, w * X)
  b <- solve(A, crossprod(Z, w * yv))
  u <- as.numeric(yv - X %*% b)
  Ainv <- solve(A)
  meat <- crossprod(Z * (w * u))
  V <- Ainv %*% meat %*% t(Ainv) * N / (N - 2)
  list(b = as.numeric(b[2]), se = sqrt(V[2, 2]))
}
eff <- wiv(ybar, xbar, g, s)
fs <- wiv(xbar, zbar, g, s)
eff_shocks <- 1 / sum(s^2)

res <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = eff$b, se = eff$se, n_obs = N),
    list(term = "first_stage", estimate = fs$b, se = fs$se, n_obs = N),
    list(term = "effective_shocks", estimate = eff_shocks, se = NULL, n_obs = N)
  ),
  method_metadata = list(estimator = "weighted shift-share 2SLS via BHJ shock-level IV",
                         vcov = "shock-level HC1 (N/(N-2)), structural IV residuals, analytic weights s_n"),
  diagnostics = list(regional_2sls_slope = beta_reg, regional_first_stage_slope = fs_reg)
)
writeLines(toJSON(res, auto_unbox = TRUE, digits = NA, null = "null", pretty = TRUE), "result.json")
