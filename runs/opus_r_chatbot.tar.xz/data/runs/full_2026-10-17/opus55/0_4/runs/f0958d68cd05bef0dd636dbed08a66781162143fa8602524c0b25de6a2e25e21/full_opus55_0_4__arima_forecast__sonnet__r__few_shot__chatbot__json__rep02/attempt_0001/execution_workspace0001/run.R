library(jsonlite)
df <- read.csv("./input.csv")
df <- df[order(df$t), ]
y <- as.numeric(df$y)
y <- y[!is.na(y)]
n <- length(y)
fit <- arima(y, order = c(1, 1, 1), include.mean = FALSE, method = "ML")
p <- predict(fit, n.ahead = 1)
fc <- as.numeric(p$pred[1])
se <- as.numeric(p$se[1])
z <- qnorm(0.975)
lo <- fc - z * se
hi <- fc + z * se
out <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = list(
    list(term = "forecast", estimate = fc, se = se, n_obs = n),
    list(term = "lower_95", estimate = lo, se = NA, n_obs = n),
    list(term = "upper_95", estimate = hi, se = NA, n_obs = n)
  ),
  method_metadata = list(estimator = "ARIMA(1,1,1) exact ML via stats::arima, no constant",
                         vcov = "model-based (Hessian); PI = forecast +/- 1.96*forecast SE"),
  diagnostics = structure(list(), names = character(0))
)
write_json(out, "result.json", auto_unbox = TRUE, digits = NA, na = "null")
