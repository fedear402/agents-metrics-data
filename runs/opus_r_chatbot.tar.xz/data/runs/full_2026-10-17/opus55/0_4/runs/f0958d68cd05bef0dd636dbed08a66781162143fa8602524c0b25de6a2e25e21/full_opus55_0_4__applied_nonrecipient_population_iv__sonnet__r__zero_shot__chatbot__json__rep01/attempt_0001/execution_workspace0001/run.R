suppressPackageStartupMessages(library(jsonlite))
hh <- read.csv("households.csv")
cs <- read.csv("census.csv")
d <- hh[hh$recipient == 0, ]
d <- d[complete.cases(d[, c("eligible","instrument","dose","baseline","weight","outcome")]), ]
e <- d$eligible; ne <- 1 - e
X <- cbind(ne, e, d$baseline*ne, d$baseline*e, d$dose*ne, d$dose*e)
Z <- cbind(ne, e, d$baseline*ne, d$baseline*e, d$instrument*ne, d$instrument*e)
w <- d$weight; y <- d$outcome
ZWZ <- crossprod(Z, Z * w)
ZWX <- crossprod(Z, X * w)
ZWy <- crossprod(Z, y * w)
A <- t(ZWX) %*% solve(ZWZ, ZWX)
b <- t(ZWX) %*% solve(ZWZ, ZWy)
beta <- as.vector(solve(A, b))
s0 <- beta[5]; s1 <- beta[6]
md0 <- weighted.mean(d$dose[e == 0], w[e == 0])
md1 <- weighted.mean(d$dose[e == 1], w[e == 1])
eff0 <- s0 * md0; eff1 <- s1 * md1
p0 <- sum(cs$nonrecipient_population[cs$eligible == 0])
p1 <- sum(cs$nonrecipient_population[cs$eligible == 1])
pop <- (p0 * eff0 + p1 * eff1) / (p0 + p1)
n <- as.integer(nrow(d))
mk <- function(t, v) list(term = t, estimate = v, se = NA, n_obs = n)
res <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = list(mk("ineligible_effect", eff0),
                   mk("eligible_nonrecipient_effect", eff1),
                   mk("population_effect", pop)),
  method_metadata = list(
    estimator = "weighted 2SLS, group-interacted, no common intercept",
    weights = "weight",
    sample = "recipient == 0, both village treatment statuses",
    counterfactual = "dose set to zero for all retained households (synthetic convention)",
    aggregation = "census nonrecipient_population weights"),
  diagnostics = list(
    n_obs = n,
    n_ineligible = as.integer(sum(e == 0)),
    n_eligible_nonrecipient = as.integer(sum(e == 1)),
    dose_slope_ineligible = s0, dose_slope_eligible = s1,
    mean_dose_ineligible = md0, mean_dose_eligible = md1,
    pop_ineligible = p0, pop_eligible = p1,
    coefficients = beta)
)
write_json(res, "result.json", auto_unbox = TRUE, digits = NA, na = "null", pretty = TRUE)
