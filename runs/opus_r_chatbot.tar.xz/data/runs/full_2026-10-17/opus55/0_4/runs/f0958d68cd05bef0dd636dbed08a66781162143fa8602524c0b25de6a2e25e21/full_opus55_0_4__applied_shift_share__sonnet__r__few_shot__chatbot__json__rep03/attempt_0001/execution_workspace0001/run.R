library(jsonlite)
d <- read.csv("input.csv", stringsAsFactors = FALSE)
d$region_id <- as.character(d$region_id)
d$industry_id <- as.character(d$industry_id)
regions <- sort(unique(d$region_id))
inds <- sort(unique(d$industry_id))
R <- length(regions); N <- length(inds)
S <- matrix(0, R, N, dimnames = list(regions, inds))
for (i in seq_len(nrow(d))) S[d$region_id[i], d$industry_id[i]] <- S[d$region_id[i], d$industry_id[i]] + d$share[i]
first_by <- function(v, key, lev) { m <- tapply(v, key, function(a) a[1]); as.numeric(m[lev]) }
w <- first_by(d$region_weight, d$region_id, regions)
x <- first_by(d$x, d$region_id, regions)
y <- first_by(d$y, d$region_id, regions)
g <- first_by(d$shock, d$industry_id, inds)
e <- w / sum(w)
z <- drop(S %*% g)
reg <- cbind(y, x, z)
cen <- sweep(reg, 2, drop(e %*% reg))
s <- drop(e %*% S)
keep <- s > 0
agg <- (t(S) %*% (e * cen)) / s
agg <- agg[keep, , drop = FALSE]; sk <- s[keep]; gk <- g[keep]
Nk <- sum(keep)
shock_iv <- function(dep, endo) {
  X <- cbind(1, endo); Z <- cbind(1, gk)
  cross <- crossprod(Z, sk * X)
  b <- solve(cross, crossprod(Z, sk * dep))
  u <- drop(dep - X %*% b)
  sc <- Z * (sk * u)
  inv <- solve(cross)
  V <- Nk / (Nk - 2) * inv %*% crossprod(sc) %*% t(inv)
  c(b[2], sqrt(V[2, 2]))
}
eff <- shock_iv(agg[, 1], agg[, 2])
fs <- shock_iv(agg[, 2], agg[, 3])
reg_eff <- sum(e * cen[, 3] * cen[, 1]) / sum(e * cen[, 3] * cen[, 2])
reg_fs <- sum(e * cen[, 3] * cen[, 2]) / sum(e * cen[, 3]^2)
row <- function(t, est, se) list(term = t, estimate = unname(as.numeric(est)),
  se = if (is.null(se)) NULL else unname(as.numeric(se)), n_obs = as.integer(Nk))
out <- list(task_id = "applied_shift_share", platform = "r",
  estimates = list(row("effect", reg_eff, eff[2]),
                   row("first_stage", reg_fs, fs[2]),
                   row("effective_shocks", 1 / sum(s^2), NULL)),
  method_metadata = list(estimator = "weighted 2SLS with BHJ shock-level aggregation",
                         vcov = "shock-level HC1, N/(N-2), structural IV residuals"),
  diagnostics = list(shock_level_effect = eff[1], shock_level_first_stage = fs[1],
                     n_regions = R, n_industries = N))
write_json(out, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
