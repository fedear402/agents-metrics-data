suppressPackageStartupMessages(library(jsonlite))

hh <- read.csv("households.csv", stringsAsFactors = FALSE)
cs <- read.csv("census.csv", stringsAsFactors = FALSE)

d <- hh[hh$recipient == 0, ]
d <- d[complete.cases(d[, c("eligible", "instrument", "dose", "baseline", "weight", "outcome")]), ]
d <- d[d$weight > 0, ]
n <- nrow(d)

e <- as.numeric(d$eligible)
ne <- 1 - e
X <- cbind(dose_inel = d$dose * ne, dose_el = d$dose * e,
           c_inel = ne, c_el = e,
           base_inel = d$baseline * ne, base_el = d$baseline * e)
Z <- cbind(c_inel = ne, c_el = e,
           base_inel = d$baseline * ne, base_el = d$baseline * e,
           iv_inel = d$instrument * ne, iv_el = d$instrument * e)
y <- d$outcome
w <- d$weight

ZtWZ <- crossprod(Z, Z * w)
ZtWX <- crossprod(Z, X * w)
ZtWy <- crossprod(Z, y * w)
A <- t(ZtWX) %*% solve(ZtWZ, ZtWX)
b <- t(ZtWX) %*% solve(ZtWZ, ZtWy)
beta <- as.vector(solve(A, b))
names(beta) <- colnames(X)

m0 <- sum(w[e == 0] * d$dose[e == 0]) / sum(w[e == 0])
m1 <- sum(w[e == 1] * d$dose[e == 1]) / sum(w[e == 1])
eff0 <- unname(beta["dose_inel"] * m0)
eff1 <- unname(beta["dose_el"] * m1)

p0 <- sum(cs$nonrecipient_population[cs$eligible == 0])
p1 <- sum(cs$nonrecipient_population[cs$eligible == 1])
pop <- (p0 * eff0 + p1 * eff1) / (p0 + p1)

est <- list(
  list(term = "ineligible_effect", estimate = eff0, se = NA, n_obs = as.integer(n)),
  list(term = "eligible_nonrecipient_effect", estimate = eff1, se = NA, n_obs = as.integer(n)),
  list(term = "population_effect", estimate = pop, se = NA, n_obs = as.integer(n))
)

res <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = est,
  method_metadata = list(
    estimator = "weighted 2SLS, group-interacted, no common intercept",
    sample = "recipient == 0 (all nonrecipients, both village statuses)",
    effect_definition = "dose slope times weight-weighted mean dose within group; zero-dose counterfactual (synthetic convention)",
    aggregation = "census nonrecipient_population weights"
  ),
  diagnostics = list(
    n_obs = as.integer(n),
    n_ineligible = as.integer(sum(e == 0)),
    n_eligible = as.integer(sum(e == 1)),
    beta_dose_ineligible = unname(beta["dose_inel"]),
    beta_dose_eligible = unname(beta["dose_el"]),
    mean_dose_ineligible = m0,
    mean_dose_eligible = m1,
    pop_ineligible = p0,
    pop_eligible = p1
  )
)

write_json(res, "result.json", auto_unbox = TRUE, digits = NA, na = "null", pretty = TRUE)
