library(jsonlite)

dat <- read.csv("./input.csv", stringsAsFactors = FALSE)
dat <- dat[!is.na(dat$y) & !is.na(dat$group) & dat$group != "", ]
dat$y <- as.numeric(dat$y)
dat <- dat[!is.na(dat$y), ]
dat$group <- factor(dat$group)
n <- nrow(dat)

fit <- aov(y ~ group, data = dat)
tab <- summary(fit)[[1]]
F_stat <- unname(tab[1, "F value"])
df_num <- unname(tab[1, "Df"])
df_den <- unname(tab[2, "Df"])
p_val <- unname(tab[1, "Pr(>F)"])

out <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = list(
    list(term = "F", estimate = F_stat, se = NA, n_obs = n),
    list(term = "df_num", estimate = df_num, se = NA, n_obs = n),
    list(term = "df_den", estimate = df_den, se = NA, n_obs = n),
    list(term = "p_value", estimate = p_val, se = NA, n_obs = n)
  ),
  method_metadata = list(estimator = "One-way ANOVA (equal variances, aov)",
                         vcov = "none"),
  diagnostics = structure(list(), names = character(0))
)
write_json(out, "result.json", auto_unbox = TRUE, digits = NA)
