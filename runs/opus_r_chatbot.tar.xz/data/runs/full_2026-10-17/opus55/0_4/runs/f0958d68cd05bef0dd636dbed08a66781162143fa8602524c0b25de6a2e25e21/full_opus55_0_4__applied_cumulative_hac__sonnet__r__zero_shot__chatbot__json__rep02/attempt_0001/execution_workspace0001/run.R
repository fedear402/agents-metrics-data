suppressMessages(library(jsonlite))
d <- read.csv("input.csv", stringsAsFactors = FALSE)
d$date <- as.Date(d$date)
d <- d[order(d$date), ]
n <- nrow(d)
dl <- c(NA, diff(log(d$vix)))
y <- log(d$sales)
L <- 15
X <- sapply(1:L, function(k) c(rep(NA, k), dl[1:(n - k)]))
colnames(X) <- paste0("lag_", 1:L)
ok <- complete.cases(cbind(y, X))
yy <- y[ok]; XX <- cbind(1, X[ok, , drop = FALSE])
N <- length(yy)
fit <- lm.fit(XX, yy)
b <- fit$coefficients
e <- fit$residuals
u <- XX * e
S <- crossprod(u)
for (j in 1:L) {
  w <- 1 - j / (L + 1)
  G <- crossprod(u[(j + 1):N, , drop = FALSE], u[1:(N - j), , drop = FALSE])
  S <- S + w * (G + t(G))
}
Bi <- solve(crossprod(XX))
V <- Bi %*% S %*% Bi * N / (N - 16)
g <- c(0, rep(1, L))
cum <- sum(b[2:(L + 1)])
cse <- sqrt(as.numeric(t(g) %*% V %*% g))
res <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(term = "cumulative_response", estimate = cum, se = cse, n_obs = N),
    list(term = "lag_1", estimate = unname(b[2]), se = sqrt(V[2, 2]), n_obs = N),
    list(term = "lag_15", estimate = unname(b[16]), se = sqrt(V[16, 16]), n_obs = N)
  ),
  method_metadata = list(estimator = "OLS distributed lag of log(sales) on 15 lags of dlog(vix)",
                         vcov = "Newey-West HAC, Bartlett, maxlag 15, scaled N/(N-16)"),
  diagnostics = setNames(list(), character(0))
)
write(toJSON(res, auto_unbox = TRUE, digits = 12, pretty = TRUE), "result.json")
