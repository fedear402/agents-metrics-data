library(jsonlite)

d <- read.csv("input.csv")
cohorts <- c(3, 5, 7)
ests <- list()
atts <- numeric(0); wts <- numeric(0); ns <- numeric(0)

for (c in cohorts) {
  win <- (c - 2):(c + 2)
  s <- d[d$time %in% win & (d$g == c | d$g == 0 | d$g > c + 2), ]
  cnt <- tapply(s$time, s$id, function(t) length(unique(t)))
  keep <- names(cnt)[cnt == length(win)]
  s <- s[as.character(s$id) %in% keep, ]
  s$did <- as.numeric(s$g == c & s$time >= c)
  fit <- lm(y ~ did + factor(id) + factor(time), data = s)
  b <- unname(coef(fit)["did"])
  ntr <- length(unique(s$id[s$g == c]))
  atts <- c(atts, b); wts <- c(wts, ntr); ns <- c(ns, nrow(s))
  ests[[length(ests) + 1]] <- list(term = paste0("att_g", c), estimate = b,
                                   se = NA, n_obs = nrow(s))
}

ests[[4]] <- list(term = "att_weighted", estimate = sum(atts * wts) / sum(wts),
                  se = NA, n_obs = sum(ns))

res <- list(task_id = "broad_cohort_stack", platform = "r",
            estimates = ests,
            method_metadata = setNames(list(), character(0)),
            diagnostics = list(treated_units = setNames(as.list(wts), paste0("g", cohorts))))

write_json(res, "result.json", auto_unbox = TRUE, digits = NA, na = "null", pretty = TRUE)
