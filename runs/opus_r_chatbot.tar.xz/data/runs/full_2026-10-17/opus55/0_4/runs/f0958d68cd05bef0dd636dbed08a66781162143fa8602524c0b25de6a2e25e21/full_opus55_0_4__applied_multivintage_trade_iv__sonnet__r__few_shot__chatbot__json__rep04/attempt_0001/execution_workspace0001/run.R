suppressPackageStartupMessages(library(jsonlite))

cw <- read.csv("crosswalk.csv", colClasses = "character", strip.white = TRUE)
tr <- read.csv("trade.csv", colClasses = c(code = "character"), strip.white = TRUE)
ar <- read.csv("areas.csv", strip.white = TRUE)
em <- read.csv("employment.csv", strip.white = TRUE)
oc <- read.csv("outcomes.csv", strip.white = TRUE)

cw$code <- trimws(cw$code); cw$industry <- trimws(as.character(cw$industry))
tr$code <- trimws(tr$code)
tr <- merge(tr, cw[, c("code", "industry")], by = "code")
em$industry <- trimws(as.character(em$industry))
ar$vintage <- trimws(tolower(ar$vintage)); em$vintage <- trimws(tolower(em$vintage))
ar$pkey <- as.character(ar$period); em$pkey <- as.character(em$period)
tr$pkey <- as.character(tr$period); oc$pkey <- as.character(oc$period)
ar$akey <- as.character(ar$area); em$akey <- as.character(em$area); oc$akey <- as.character(oc$area)
inds <- sort(unique(cw$industry))

exposure <- function(p, vint, chcol) {
  a <- ar[ar$pkey == p & ar$vintage == vint, ]
  e <- em[em$pkey == p & em$vintage == vint, ]
  M <- matrix(0, nrow(a), length(inds), dimnames = list(a$akey, inds))
  for (i in seq_len(nrow(e))) {
    if (e$akey[i] %in% rownames(M) && e$industry[i] %in% inds)
      M[e$akey[i], e$industry[i]] <- M[e$akey[i], e$industry[i]] + e$employment[i]
  }
  N <- colSums(M)
  t <- tr[tr$pkey == p, ]
  t <- t[match(inds, t$industry), ]
  pi <- t$price_index[1]; yrs <- t$years[1]
  w <- t[[chcol]] / N / (pi / 100) / 1000 * (10 / yrs)
  setNames(as.vector(M %*% w) / a$total_employment, a$akey)
}

rows <- list()
for (p in sort(unique(oc$pkey))) {
  xv <- exposure(p, "base", "us_change")
  zv <- exposure(p, "early", "other_change")
  pop <- ar[ar$pkey == p & ar$vintage == "base", ]
  o <- oc[oc$pkey == p, ]
  o$x <- xv[o$akey]; o$z <- zv[o$akey]
  o$w <- pop$population[match(o$akey, pop$akey)]
  rows[[p]] <- o
}
d <- do.call(rbind, rows)
d <- d[complete.cases(d[, c("change_pp", "period", "control", "x", "z", "w")]), ]

iv <- function(y, C, x, z, w) {
  X <- cbind(C, x) * sqrt(w); Z <- cbind(C, z) * sqrt(w)
  fitted <- qr.fitted(qr(Z), X)
  as.numeric(qr.coef(qr(fitted), y * sqrt(w)))[ncol(X)]
}
C <- cbind(1, as.numeric(d$period), d$control)
slope <- iv(d$change_pp, C, d$x, d$z, d$w)
n <- nrow(d)

a0 <- d[d$akey == "0", ]
x00 <- a0$x[a0$pkey == sort(unique(d$pkey))[1]]
x01 <- a0$x[a0$pkey == sort(unique(d$pkey))[2]]
z00 <- a0$z[a0$pkey == sort(unique(d$pkey))[1]]

est <- function(term, v) list(term = term, estimate = unname(v), se = NULL, n_obs = n)
res <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = list(
    est("iv_slope", slope),
    est("exposure_area0_period0", x00),
    est("exposure_area0_period1", x01),
    est("instrument_area0_period0", z00)
  ),
  method_metadata = list(
    estimator = "weighted 2SLS",
    exogenous = c("intercept", "period", "control"),
    endogenous = "x", instrument = "z", weight = "base-vintage population"
  ),
  diagnostics = list(n_obs = n, n_industries = length(inds))
)
write_json(res, "result.json", auto_unbox = TRUE, digits = NA, null = "null", pretty = TRUE)
