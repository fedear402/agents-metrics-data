library(jsonlite)
h <- read.csv("households.csv")
census <- read.csv("census.csv")
d <- subset(h, recipient == 0)
d <- d[complete.cases(d[, c("eligible","dose","instrument","baseline","outcome","weight")]), ]
e <- d$eligible; ne <- 1 - e
w <- d$weight; sw <- sqrt(w)
C <- cbind(ne, e, d$baseline * ne, d$baseline * e)
X <- cbind(C, d$dose * ne, d$dose * e)
Z <- cbind(C, d$instrument * ne, d$instrument * e)
Xw <- X * sw; Zw <- Z * sw; yw <- d$outcome * sw
fitted <- qr.fitted(qr(Zw), Xw)
b <- as.numeric(qr.coef(qr(fitted), yw))
slopes <- b[5:6]
mdose <- c(weighted.mean(d$dose[e == 0], w[e == 0]), weighted.mean(d$dose[e == 1], w[e == 1]))
effect <- slopes * mdose
pop <- census$nonrecipient_population[match(0:1, census$eligible)]
popeff <- weighted.mean(effect, pop)
n <- as.integer(nrow(d))
est <- list(
  list(term = "ineligible_effect", estimate = effect[1], se = NULL, n_obs = n),
  list(term = "eligible_nonrecipient_effect", estimate = effect[2], se = NULL, n_obs = n),
  list(term = "population_effect", estimate = popeff, se = NULL, n_obs = n)
)
res <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = est,
  method_metadata = list(
    estimator = "weighted 2SLS, fully interacted by eligibility, no common intercept",
    sample = "recipient == 0",
    effect_definition = "dose slope times weighted mean dose (zero-dose counterfactual)",
    aggregation = "census nonrecipient_population weights"
  ),
  diagnostics = list(
    n_ineligible = as.integer(sum(e == 0)),
    n_eligible = as.integer(sum(e == 1)),
    slope_ineligible = slopes[1], slope_eligible = slopes[2],
    mean_dose_ineligible = mdose[1], mean_dose_eligible = mdose[2],
    census_weight_ineligible = pop[1], census_weight_eligible = pop[2]
  )
)
write_json(res, "result.json", auto_unbox = TRUE, digits = NA, null = "null", pretty = TRUE)
