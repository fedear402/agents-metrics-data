suppressPackageStartupMessages(library(jsonlite))

dat <- read.csv("./input.csv")
dat <- dat[order(dat$t), ]
y <- as.numeric(dat$y)
n <- length(y)

fit <- arima(y, order = c(1, 1, 1), method = "ML", include.mean = FALSE)
pr <- predict(fit, n.ahead = 1)
fc <- as.numeric(pr$pred[1])
se <- as.numeric(pr$se[1])
z <- qnorm(0.975)
lo <- fc - z * se
hi <- fc + z * se

co <- coef(fit)
res <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = list(
    list(term = "forecast", estimate = fc, se = se, n_obs = n),
    list(term = "lower_95", estimate = lo, se = NULL, n_obs = n),
    list(term = "upper_95", estimate = hi, se = NULL, n_obs = n)
  ),
  method_metadata = list(
    estimator = "ARIMA(1,1,1) exact Gaussian ML (stats::arima, method='ML'), no constant/drift",
    vcov = "inverse Hessian (MLE); forecast SE from state-space prediction"
  ),
  diagnostics = list(
    ar1 = unname(co["ar1"]),
    ma1 = unname(co["ma1"]),
    sigma2 = fit$sigma2,
    loglik = fit$loglik,
    aic = fit$aic,
    last_t = dat$t[n]
  )
)

writeLines(toJSON(res, auto_unbox = TRUE, digits = NA, null = "null", pretty = TRUE),
           "result.json")
