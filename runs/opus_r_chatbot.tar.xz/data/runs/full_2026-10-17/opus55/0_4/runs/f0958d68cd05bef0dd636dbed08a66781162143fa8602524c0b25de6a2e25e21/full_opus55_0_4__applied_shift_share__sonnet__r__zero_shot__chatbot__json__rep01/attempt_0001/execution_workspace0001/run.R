suppressPackageStartupMessages(library(jsonlite))
d <- read.csv("input.csv")
d <- d[order(d$region_id, d$industry_id), ]
reg <- d[!duplicated(d$region_id), c("region_id", "region_weight", "x", "y")]
reg$e <- reg$region_weight / sum(reg$region_weight)
d$z_part <- d$share * d$shock
zr <- tapply(d$z_part, d$region_id, sum)
reg$z <- as.numeric(zr[as.character(reg$region_id)])
e <- reg$e
wm <- function(v) sum(e * v) / sum(e)
reg$y0 <- reg$y - wm(reg$y); reg$x0 <- reg$x - wm(reg$x); reg$z0 <- reg$z - wm(reg$z)

# regional slopes
b_eff <- sum(e * reg$z0 * reg$y0) / sum(e * reg$z0 * reg$x0)
b_fs <- sum(e * reg$z0 * reg$x0) / sum(e * reg$z0 * reg$z0)

d$e <- reg$e[match(d$region_id, reg$region_id)]
d$y0 <- reg$y0[match(d$region_id, reg$region_id)]
d$x0 <- reg$x0[match(d$region_id, reg$region_id)]
d$z0 <- reg$z0[match(d$region_id, reg$region_id)]
d$w <- d$e * d$share
ind <- sort(unique(d$industry_id))
key <- as.character(ind)
s <- as.numeric(tapply(d$w, d$industry_id, sum)[key])
agg <- function(v) as.numeric(tapply(d$w * v, d$industry_id, sum)[key]) / s
ybar <- agg(d$y0); xbar <- agg(d$x0); zbar <- agg(d$z0)
g <- as.numeric(tapply(d$shock, d$industry_id, mean)[key])
keep <- s > 0 & is.finite(ybar)
s <- s[keep]; ybar <- ybar[keep]; xbar <- xbar[keep]; zbar <- zbar[keep]; g <- g[keep]
N <- length(s)

wiv <- function(yv, xv, gv, w) {
  X <- cbind(1, xv); Z <- cbind(1, gv)
  A <- t(Z) %*% (w * X)
  b <- solve(A, t(Z) %*% (w * yv))
  u <- as.numeric(yv - X %*% b)
  Ai <- solve(A)
  meat <- t(Z) %*% ((w * u)^2 * Z)
  V <- Ai %*% meat %*% t(Ai) * N / (N - 2)
  c(b[2], sqrt(V[2, 2]))
}
r1 <- wiv(ybar, xbar, g, s)
r2 <- wiv(xbar, zbar, g, s)
eff_sh <- 1 / sum(s^2)

out <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = r1[1], se = r1[2], n_obs = N),
    list(term = "first_stage", estimate = r2[1], se = r2[2], n_obs = N),
    list(term = "effective_shocks", estimate = eff_sh, se = NULL, n_obs = N)
  ),
  method_metadata = list(estimator = "weighted 2SLS shift-share (BHJ shock-level)",
                         vcov = "shock-level HC1, N/(N-2)"),
  diagnostics = list(regional_effect = b_eff, regional_first_stage = b_fs)
)
writeLines(toJSON(out, auto_unbox = TRUE, digits = NA, null = "null", pretty = TRUE), "result.json")
