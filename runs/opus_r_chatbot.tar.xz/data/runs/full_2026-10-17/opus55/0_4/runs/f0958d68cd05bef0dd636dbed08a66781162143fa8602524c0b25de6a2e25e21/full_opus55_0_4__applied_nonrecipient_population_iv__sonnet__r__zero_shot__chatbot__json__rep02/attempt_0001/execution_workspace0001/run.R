suppressPackageStartupMessages(library(jsonlite))

hh <- read.csv("households.csv", stringsAsFactors = FALSE)
cs <- read.csv("census.csv", stringsAsFactors = FALSE)

d <- hh[!is.na(hh$recipient) & hh$recipient == 0, ]
d <- d[complete.cases(d[, c("eligible", "instrument", "dose", "baseline", "weight", "outcome")]), ]
d <- d[d$weight > 0, ]
n <- nrow(d)

e <- as.numeric(d$eligible)
ne <- 1 - e
X <- cbind(dose_inel = d$dose * ne, dose_el = d$dose * e,
           inel = ne, el = e, base_inel = d$baseline * ne, base_el = d$baseline * e)
Z <- cbind(inel = ne, el = e, base_inel = d$baseline * ne, base_el = d$baseline * e,
           iv_inel = d$instrument * ne, iv_el = d$instrument * e)
y <- d$outcome
w <- d$weight

ZW <- Z * w
ZtWZ <- crossprod(Z, ZW)
ZtWX <- crossprod(ZW, X)
ZtWy <- crossprod(ZW, y)
A <- t(ZtWX) %*% solve(ZtWZ, ZtWX)
b <- t(ZtWX) %*% solve(ZtWZ, ZtWy)
beta <- as.vector(solve(A, b))
names(beta) <- colnames(X)

i0 <- e == 0; i1 <- e == 1
mdose0 <- sum(w[i0] * d$dose[i0]) / sum(w[i0])
mdose1 <- sum(w[i1] * d$dose[i1]) / sum(w[i1])
eff0 <- unname(beta["dose_inel"] * mdose0)
eff1 <- unname(beta["dose_el"] * mdose1)

p0 <- sum(cs$nonrecipient_population[cs$eligible == 0])
p1 <- sum(cs$nonrecipient_population[cs$eligible == 1])
pop <- (p0 * eff0 + p1 * eff1) / (p0 + p1)

mk <- function(t, v) list(term = t, estimate = v, se = NULL, n_obs = as.integer(n))
res <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = list(
    mk("ineligible_effect", eff0),
    mk("eligible_nonrecipient_effect", eff1),
    mk("population_effect", pop)
  ),
  method_metadata = list(
    estimator = "weighted 2SLS, group-interacted, no common intercept",
    sample = "recipient == 0 (all ineligible and eligible nonrecipients, both village statuses)",
    effect_definition = "dose slope times household-weighted mean dose within group; zero-dose counterfactual (synthetic convention)",
    aggregation = "census nonrecipient_population weights"
  ),
  diagnostics = list(
    n_obs = as.integer(n),
    n_ineligible = as.integer(sum(i0)),
    n_eligible_nonrecipient = as.integer(sum(i1)),
    coefficients = as.list(beta),
    mean_dose_ineligible = mdose0,
    mean_dose_eligible = mdose1,
    pop_ineligible = p0,
    pop_eligible = p1
  )
)

write_json(res, "result.json", auto_unbox = TRUE, digits = NA, null = "null", pretty = TRUE)
