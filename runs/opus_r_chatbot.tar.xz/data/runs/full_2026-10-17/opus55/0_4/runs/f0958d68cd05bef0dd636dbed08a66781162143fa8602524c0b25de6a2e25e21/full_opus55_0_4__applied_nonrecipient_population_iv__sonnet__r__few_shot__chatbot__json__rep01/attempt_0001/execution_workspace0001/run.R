library(jsonlite)

d <- read.csv("households.csv")
census <- read.csv("census.csv")
d <- d[d$recipient == 0, ]
d <- d[complete.cases(d[, c("eligible", "dose", "instrument", "baseline", "outcome", "weight")]), ]

e <- d$eligible
ne <- 1 - e
w <- d$weight
sw <- sqrt(w)

C <- cbind(ne = ne, el = e, b0 = d$baseline * ne, b1 = d$baseline * e)
X <- cbind(C, x0 = d$dose * ne, x1 = d$dose * e)
Z <- cbind(C, z0 = d$instrument * ne, z1 = d$instrument * e)

Xw <- X * sw
Zw <- Z * sw
yw <- d$outcome * sw
fitted <- qr.fitted(qr(Zw), Xw)
coef <- as.numeric(qr.coef(qr(fitted), yw))
names(coef) <- colnames(X)

slope <- c(coef["x0"], coef["x1"])
mdose <- sapply(0:1, function(g) {
  a <- d[d$eligible == g, ]
  weighted.mean(a$dose, a$weight)
})
effect <- as.numeric(slope) * mdose
pop <- census$nonrecipient_population[match(0:1, census$eligible)]
population_effect <- sum(effect * pop) / sum(pop)

n <- as.integer(nrow(d))
n0 <- as.integer(sum(d$eligible == 0))
n1 <- as.integer(sum(d$eligible == 1))

est <- list(
  list(term = "ineligible_effect", estimate = effect[1], se = NA, n_obs = n),
  list(term = "eligible_nonrecipient_effect", estimate = effect[2], se = NA, n_obs = n),
  list(term = "population_effect", estimate = population_effect, se = NA, n_obs = n)
)

res <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = est,
  method_metadata = list(
    estimator = "weighted 2SLS, pooled with group-interacted columns",
    endogenous = c("dose*(1-eligible)", "dose*eligible"),
    exogenous = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"),
    excluded_instruments = c("instrument*(1-eligible)", "instrument*eligible"),
    weights = "weight",
    sample = "recipient == 0",
    counterfactual = "dose set to zero for all retained households",
    aggregation = "census nonrecipient_population weights"
  ),
  diagnostics = list(
    n_obs = n,
    n_ineligible = n0,
    n_eligible_nonrecipient = n1,
    dose_slope_ineligible = as.numeric(slope[1]),
    dose_slope_eligible = as.numeric(slope[2]),
    weighted_mean_dose_ineligible = mdose[1],
    weighted_mean_dose_eligible = mdose[2],
    census_weight_ineligible = pop[1],
    census_weight_eligible = pop[2]
  )
)

write_json(res, "result.json", auto_unbox = TRUE, digits = NA, na = "null", pretty = TRUE)
