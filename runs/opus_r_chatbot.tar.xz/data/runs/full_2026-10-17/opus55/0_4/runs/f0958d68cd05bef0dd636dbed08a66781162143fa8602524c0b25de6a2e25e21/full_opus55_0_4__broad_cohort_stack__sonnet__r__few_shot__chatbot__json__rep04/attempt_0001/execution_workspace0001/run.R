d <- read.csv("input.csv")
res <- list(); nobs <- c(); ntr <- c(); est <- c()
for (c in c(3, 5, 7)) {
  w <- d[d$time >= c - 2 & d$time <= c + 2 & (d$g == c | d$g == 0 | d$g > c + 2), ]
  cnt <- table(w$id)
  keep <- names(cnt)[cnt == 5]
  w <- w[as.character(w$id) %in% keep, ]
  w$did <- as.numeric(w$g == c & w$time >= c)
  b <- unname(coef(lm(y ~ did + factor(id) + factor(time), data = w))["did"])
  est <- c(est, b); nobs <- c(nobs, nrow(w))
  ntr <- c(ntr, length(unique(w$id[w$g == c])))
  res[[length(res) + 1]] <- list(term = paste0("att_g", c), estimate = b, se = NULL, n_obs = nrow(w))
}
res[[4]] <- list(term = "att_weighted", estimate = sum(est * ntr) / sum(ntr), se = NULL, n_obs = sum(nobs))
out <- list(task_id = "broad_cohort_stack", platform = "r", estimates = res,
            method_metadata = setNames(list(), character(0)),
            diagnostics = list(treated_units = setNames(as.list(ntr), c("g3", "g5", "g7"))))
jsonlite::write_json(out, "result.json", auto_unbox = TRUE, null = "null", digits = NA)
