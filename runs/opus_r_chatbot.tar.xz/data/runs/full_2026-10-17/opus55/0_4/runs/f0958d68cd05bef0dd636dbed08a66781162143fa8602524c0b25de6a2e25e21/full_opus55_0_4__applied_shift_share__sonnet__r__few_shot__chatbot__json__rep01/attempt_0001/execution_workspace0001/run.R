library(jsonlite)
d <- read.csv("input.csv", stringsAsFactors = FALSE)
d$region_id <- as.character(d$region_id)
d$industry_id <- as.character(d$industry_id)
regions <- sort(unique(d$region_id))
industries <- sort(unique(d$industry_id))
R <- length(regions); N <- length(industries)
S <- matrix(0, R, N, dimnames = list(regions, industries))
idx <- cbind(match(d$region_id, regions), match(d$industry_id, industries))
S[idx] <- d$share
first_r <- d[!duplicated(d$region_id), ]
first_r <- first_r[match(regions, first_r$region_id), ]
first_n <- d[!duplicated(d$industry_id), ]
first_n <- first_n[match(industries, first_n$industry_id), ]
shock <- first_n$shock
e <- first_r$region_weight / sum(first_r$region_weight)
x <- first_r$x; y <- first_r$y
z <- drop(S %*% shock)
reg <- cbind(y, x, z)
cen <- sweep(reg, 2, drop(e %*% reg))
s <- drop(e %*% S)
keep <- s > 0
agg <- (t(S) %*% (e * cen)) / s
agg <- agg[keep, , drop = FALSE]; sk <- s[keep]; shk <- shock[keep]
Nk <- sum(keep)
shock_iv <- function(dep, endo) {
  X <- cbind(1, endo); Z <- cbind(1, shk)
  cross <- crossprod(Z, sk * X)
  b <- solve(cross, crossprod(Z, sk * dep))
  u <- drop(dep - X %*% b)
  sc <- Z * (sk * u)
  inv <- solve(cross)
  V <- Nk / (Nk - 2) * inv %*% crossprod(sc) %*% t(inv)
  c(b[2], sqrt(V[2, 2]))
}
eff <- shock_iv(agg[, 1], agg[, 2])
fs <- shock_iv(agg[, 2], agg[, 3])
reg_eff <- sum(e * cen[, 3] * cen[, 1]) / sum(e * cen[, 3] * cen[, 2])
reg_fs <- sum(e * cen[, 3] * cen[, 2]) / sum(e * cen[, 3]^2)
row <- function(t, est, se) list(term = t, estimate = unname(as.numeric(est)),
  se = if (is.null(se)) NULL else unname(as.numeric(se)), n_obs = as.integer(Nk))
out <- list(
  task_id = "applied_shift_share", platform = "r",
  estimates = list(
    row("effect", reg_eff, eff[2]),
    row("first_stage", reg_fs, fs[2]),
    row("effective_shocks", 1 / sum(s^2), NULL)),
  method_metadata = list(estimator = "weighted 2SLS with BHJ shock-level aggregation",
                         vcov = "shock-level HC1 N/(N-2), structural IV residuals"),
  diagnostics = list(shock_level_effect = unname(eff[1]), shock_level_first_stage = unname(fs[1]),
                     n_regions = R))
write_json(out, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
