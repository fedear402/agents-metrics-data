suppressPackageStartupMessages(library(jsonlite))

d <- read.csv("households.csv")
census <- read.csv("census.csv")
d <- d[d$recipient == 0, ]
d <- d[complete.cases(d[, c("eligible", "dose", "instrument", "baseline", "outcome", "weight")]), ]

e <- d$eligible
ne <- 1 - e
w <- d$weight
C <- cbind(ne = ne, el = e, b_ne = d$baseline * ne, b_el = d$baseline * e)
X <- cbind(C, dose_ne = d$dose * ne, dose_el = d$dose * e)
Z <- cbind(C, z_ne = d$instrument * ne, z_el = d$instrument * e)

sw <- sqrt(w)
Xw <- X * sw; Zw <- Z * sw; yw <- d$outcome * sw
fitted <- qr.fitted(qr(Zw), Xw)
coef <- as.numeric(qr.coef(qr(fitted), yw))
names(coef) <- colnames(X)

slopes <- coef[c("dose_ne", "dose_el")]
mdose <- sapply(0:1, function(g) {
  a <- d[d$eligible == g, ]
  weighted.mean(a$dose, a$weight)
})
effect <- as.numeric(slopes) * mdose
pop <- census$nonrecipient_population[match(0:1, census$eligible)]
population_effect <- sum(effect * pop) / sum(pop)

n <- nrow(d)
est <- list(
  list(term = "ineligible_effect", estimate = effect[1], se = NA, n_obs = n),
  list(term = "eligible_nonrecipient_effect", estimate = effect[2], se = NA, n_obs = n),
  list(term = "population_effect", estimate = population_effect, se = NA, n_obs = n)
)

res <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = est,
  method_metadata = list(
    estimator = "weighted 2SLS, fully interacted by eligibility, no common intercept",
    endogenous = c("dose*(1-eligible)", "dose*eligible"),
    instruments = c("instrument*(1-eligible)", "instrument*eligible"),
    exogenous = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"),
    weights = "weight",
    effect_definition = "dose slope times weighted mean dose (zero-dose counterfactual)",
    aggregation = "census nonrecipient_population weights"
  ),
  diagnostics = list(
    n_obs = n,
    n_ineligible = sum(d$eligible == 0),
    n_eligible = sum(d$eligible == 1),
    dose_slope_ineligible = as.numeric(slopes[1]),
    dose_slope_eligible = as.numeric(slopes[2]),
    weighted_mean_dose_ineligible = mdose[1],
    weighted_mean_dose_eligible = mdose[2],
    census_weights = pop
  )
)

write_json(res, "result.json", auto_unbox = TRUE, digits = NA, na = "null", pretty = TRUE)
