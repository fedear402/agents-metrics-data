library(jsonlite)
d <- read.csv("input.csv")
n <- nrow(d)
y <- d$y; en <- d$endog
W <- cbind(1, d$x)
Z <- cbind(1, d$x, d$z1, d$z2)
resid <- function(X, v) as.numeric(v - X %*% qr.solve(X, v))
yW <- resid(W, y); dW <- resid(W, en)
yZ <- resid(Z, y); dZ <- resid(Z, en)
# Quadratic forms: A = M_W - M_Z, M = M_Z
yAy <- sum(yW^2) - sum(yZ^2)
yAd <- sum(yW*dW) - sum(yZ*dZ)
dAd <- sum(dW^2) - sum(dZ^2)
yMy <- sum(yZ^2); yMd <- sum(yZ*dZ); dMd <- sum(dZ^2)

df2 <- n - 4
crit <- qf(0.95, 2, df2)
arF <- function(b) {
  num <- (yAy - 2*b*yAd + b^2*dAd) / 2
  den <- (yMy - 2*b*yMd + b^2*dMd) / df2
  num / den
}
k <- crit * 2 / df2
a2 <- dAd - k*dMd
a1 <- -2*(yAd - k*yMd)
a0 <- yAy - k*yMy
disc <- a1^2 - 4*a2*a0
if (disc < 0) stop("No real boundary points")
r <- sort(c((-a1 - sqrt(disc))/(2*a2), (-a1 + sqrt(disc))/(2*a2)))
unbounded <- as.numeric(a2 < 0)
accepts_zero <- as.numeric(arF(0) <= crit)
f1 <- arF(1)

mk <- function(t, e) list(term = t, estimate = e, se = NULL, n_obs = n)
res <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = list(
    mk("boundary_low", r[1]),
    mk("boundary_high", r[2]),
    mk("accepts_zero", accepts_zero),
    mk("unbounded", unbounded),
    mk("ar_f_at_one", f1)
  ),
  method_metadata = list(estimator = "Anderson-Rubin test inversion (analytic quadratic)",
                         vcov = "homoskedastic F"),
  diagnostics = list(crit = crit, quad_a2 = a2, quad_a1 = a1, quad_a0 = a0,
                     set_type = if (a2 > 0) "bounded interval" else "union of two rays")
)
writeLines(toJSON(res, auto_unbox = TRUE, digits = NA, null = "null", pretty = TRUE), "result.json")
