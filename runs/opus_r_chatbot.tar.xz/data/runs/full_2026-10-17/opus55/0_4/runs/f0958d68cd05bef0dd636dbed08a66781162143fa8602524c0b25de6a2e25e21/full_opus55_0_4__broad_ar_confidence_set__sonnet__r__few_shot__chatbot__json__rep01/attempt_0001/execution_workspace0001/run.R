d <- read.csv("input.csv")
d <- d[complete.cases(d[, c("y","endog","x","z1","z2")]), ]
n <- nrow(d)
ry <- residuals(lm(y ~ x, data = d)); rd <- residuals(lm(endog ~ x, data = d))
fy <- lm(y ~ x + z1 + z2, data = d); fd <- lm(endog ~ x + z1 + z2, data = d)
uy <- residuals(fy); ud <- residuals(fd)
q <- 2L; df <- n - 4L
critical <- qf(.95, q, df)
k <- q * critical / df
A <- sum(rd^2) - (1 + k) * sum(ud^2)
B <- -2 * (sum(ry * rd) - (1 + k) * sum(uy * ud))
C <- sum(ry^2) - (1 + k) * sum(uy^2)
disc <- B^2 - 4 * A * C
if (abs(A) > 1e-12 && disc > 0) {
  bounds <- sort(c((-B - sqrt(disc)) / (2 * A), (-B + sqrt(disc)) / (2 * A)))
} else {
  bounds <- c(NA_real_, NA_real_)
}
accepts <- function(beta) A * beta^2 + B * beta + C <= 0
unbounded <- as.integer(A < 0 || (abs(A) <= 1e-12 && B != 0) || (A <= 0 && disc <= 0))
arF <- function(beta) {
  t <- d$y - beta * d$endog
  r <- lm(t ~ x, data = d); f <- lm(t ~ x + z1 + z2, data = d)
  ((deviance(r) - deviance(f)) / q) / (deviance(f) / df)
}
rows <- list(
  list(term = "boundary_low", estimate = unname(bounds[1]), se = NULL, n_obs = n),
  list(term = "boundary_high", estimate = unname(bounds[2]), se = NULL, n_obs = n),
  list(term = "accepts_zero", estimate = as.numeric(accepts(0)), se = NULL, n_obs = n),
  list(term = "unbounded", estimate = as.numeric(unbounded), se = NULL, n_obs = n),
  list(term = "ar_f_at_one", estimate = arF(1), se = NULL, n_obs = n))
jsonlite::write_json(list(task_id = "broad_ar_confidence_set", platform = "r", estimates = rows,
  method_metadata = list(estimator = "Anderson-Rubin test inversion (analytic quadratic)", vcov = "homoskedastic"),
  diagnostics = list(A = A, B = B, C = C, critical = critical)),
  "result.json", auto_unbox = TRUE, null = "null", digits = NA, pretty = TRUE)
