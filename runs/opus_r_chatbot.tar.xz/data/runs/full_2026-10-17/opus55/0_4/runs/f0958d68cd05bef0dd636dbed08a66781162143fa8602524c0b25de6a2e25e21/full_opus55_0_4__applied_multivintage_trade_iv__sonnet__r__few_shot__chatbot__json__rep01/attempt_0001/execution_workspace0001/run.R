suppressPackageStartupMessages(library(jsonlite))
cw <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
tr <- read.csv("trade.csv", stringsAsFactors = FALSE)
ar <- read.csv("areas.csv", stringsAsFactors = FALSE)
em <- read.csv("employment.csv", stringsAsFactors = FALSE)
oc <- read.csv("outcomes.csv", stringsAsFactors = FALSE)
for (nm in c("vintage")) { ar[[nm]] <- trimws(tolower(ar[[nm]])); em[[nm]] <- trimws(tolower(em[[nm]])) }
cw$code <- trimws(as.character(cw$code)); tr$code <- trimws(as.character(tr$code))
cw$industry <- trimws(as.character(cw$industry)); em$industry <- trimws(as.character(em$industry))
tr <- merge(tr, cw[, c("code", "industry")], by = "code")
inds <- sort(unique(cw$industry))
key <- function(...) paste(..., sep = "|")

# Aggregate employment (sum duplicates), missing = 0
em$k <- key(em$area, em$period, em$vintage, em$industry)
emp_agg <- tapply(em$employment, em$k, sum)
nat <- tapply(em$employment, key(em$period, em$vintage, em$industry), sum)

obs <- oc
obs$x <- NA_real_; obs$z <- NA_real_; obs$pop <- NA_real_
for (i in seq_len(nrow(obs))) {
  a <- obs$area[i]; p <- obs$period[i]
  rb <- ar[ar$area == a & ar$period == p & ar$vintage == "base", ]
  re <- ar[ar$area == a & ar$period == p & ar$vintage == "early", ]
  obs$pop[i] <- rb$population[1]
  xs <- 0; zs <- 0
  for (j in inds) {
    t <- tr[tr$period == p & tr$industry == j, ][1, ]
    fac <- 1 / (t$price_index / 100) / 1000 * (10 / t$years)
    eb <- emp_agg[key(a, p, "base", j)]; eb <- ifelse(is.na(eb), 0, eb)
    ee <- emp_agg[key(a, p, "early", j)]; ee <- ifelse(is.na(ee), 0, ee)
    nb <- nat[key(p, "base", j)]; ne <- nat[key(p, "early", j)]
    xs <- xs + (eb / rb$total_employment[1]) * (t$us_change / nb) * fac
    zs <- zs + (ee / re$total_employment[1]) * (t$other_change / ne) * fac
  }
  obs$x[i] <- as.numeric(xs); obs$z[i] <- as.numeric(zs)
}
obs <- obs[complete.cases(obs[, c("change_pp", "control", "x", "z", "pop")]), ]

pnum <- suppressWarnings(as.numeric(obs$period))
if (any(is.na(pnum))) pnum <- as.numeric(factor(obs$period)) - 1
C <- cbind(1, pnum, obs$control)
w <- obs$pop
X <- cbind(C, obs$x) * sqrt(w); Z <- cbind(C, obs$z) * sqrt(w)
fitted <- qr.fitted(qr(Z), X)
b <- as.numeric(qr.coef(qr(fitted), obs$change_pp * sqrt(w)))
slope <- b[4]

getv <- function(v, p) { r <- obs[as.character(obs$area) == "0" & as.character(obs$period) == p, ]; r[[v]][1] }
pers <- sort(unique(as.character(obs$period)))
n <- nrow(obs)
est <- list(
  list(term = "iv_slope", estimate = slope, se = NA, n_obs = n),
  list(term = "exposure_area0_period0", estimate = getv("x", pers[1]), se = NA, n_obs = n),
  list(term = "exposure_area0_period1", estimate = getv("x", pers[2]), se = NA, n_obs = n),
  list(term = "instrument_area0_period0", estimate = getv("z", pers[1]), se = NA, n_obs = n)
)
res <- list(
  task_id = "applied_multivintage_trade_iv", platform = "r", estimates = est,
  method_metadata = list(method = "weighted 2SLS", weights = "base population",
                         exogenous = c("intercept", "period", "control"), instrument = "z"),
  diagnostics = list(n_obs = n, n_industries = length(inds))
)
write_json(res, "result.json", auto_unbox = TRUE, digits = NA, na = "null", null = "null", pretty = TRUE)
