library(jsonlite)

cw <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
tr <- read.csv("trade.csv", stringsAsFactors = FALSE)
ar <- read.csv("areas.csv", stringsAsFactors = FALSE)
em <- read.csv("employment.csv", stringsAsFactors = FALSE)
oc <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

ar$vintage <- trimws(tolower(as.character(ar$vintage)))
em$vintage <- trimws(tolower(as.character(em$vintage)))
cw$code <- as.character(cw$code); tr$code <- as.character(tr$code)
cw$industry <- as.character(cw$industry); em$industry <- as.character(em$industry)

tr <- merge(tr, cw[, c("code", "industry")], by = "code")
inds <- sort(unique(cw$industry))

# Full grid of area-period-vintage x industry, missing cells = 0
grid <- merge(unique(ar[, c("area", "period", "vintage")]), data.frame(industry = inds, stringsAsFactors = FALSE))
em_agg <- aggregate(employment ~ area + period + vintage + industry, data = em, FUN = sum)
grid <- merge(grid, em_agg, by = c("area", "period", "vintage", "industry"), all.x = TRUE)
grid$employment[is.na(grid$employment)] <- 0

nat <- aggregate(employment ~ period + vintage + industry, data = grid, FUN = sum)
names(nat)[names(nat) == "employment"] <- "national"
grid <- merge(grid, nat, by = c("period", "vintage", "industry"))
grid <- merge(grid, ar[, c("area", "period", "vintage", "total_employment")],
              by = c("area", "period", "vintage"))
grid <- merge(grid, tr[, c("period", "industry", "us_change", "other_change", "price_index", "years")],
              by = c("period", "industry"))

grid$chg <- ifelse(grid$vintage == "base", grid$us_change, grid$other_change)
grid$term <- (grid$employment / grid$total_employment) * (grid$chg / grid$national) /
  (grid$price_index / 100) / 1000 * (10 / grid$years)

ex <- aggregate(term ~ area + period + vintage, data = grid, FUN = sum)
xb <- ex[ex$vintage == "base", c("area", "period", "term")]; names(xb)[3] <- "x"
ze <- ex[ex$vintage == "early", c("area", "period", "term")]; names(ze)[3] <- "z"
pop <- ar[ar$vintage == "base", c("area", "period", "population")]

d <- merge(oc, xb, by = c("area", "period"))
d <- merge(d, ze, by = c("area", "period"))
d <- merge(d, pop, by = c("area", "period"))
d <- d[order(d$period, d$area), ]

iv <- function(y, C, x, z, w) {
  X <- cbind(C, x) * sqrt(w); Z <- cbind(C, z) * sqrt(w)
  fitted <- qr.fitted(qr(Z), X)
  as.numeric(qr.coef(qr(fitted), y * sqrt(w)))[ncol(X)]
}
C <- cbind(1, as.numeric(d$period), d$control)
slope <- iv(d$change_pp, C, d$x, d$z, d$population)

periods <- sort(unique(d$period))
a0 <- min(d$area)
getv <- function(v, p) d[[v]][d$area == a0 & d$period == p][1]
n <- nrow(d)

est <- list(
  list(term = "iv_slope", estimate = slope, se = NA, n_obs = n),
  list(term = "exposure_area0_period0", estimate = getv("x", periods[1]), se = NA, n_obs = n),
  list(term = "exposure_area0_period1", estimate = getv("x", periods[2]), se = NA, n_obs = n),
  list(term = "instrument_area0_period0", estimate = getv("z", periods[1]), se = NA, n_obs = n)
)

res <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = est,
  method_metadata = list(estimator = "weighted 2SLS", weights = "base-vintage population",
                         exogenous = c("intercept", "period", "control"), instrument = "z"),
  diagnostics = list(n_obs = n, n_industries = length(inds))
)
write_json(res, "result.json", auto_unbox = TRUE, digits = NA, na = "null", pretty = TRUE)
