d <- read.csv("input.csv", stringsAsFactors = FALSE)
d$date <- as.Date(d$date)
d <- d[order(d$date), ]
n <- nrow(d)
ly <- log(d$sales)
dv <- c(NA, diff(log(d$vix)))
L <- 15
X <- sapply(1:L, function(k) c(rep(NA, k), dv[1:(n - k)]))
colnames(X) <- paste0("lag_", 1:L)
df <- data.frame(y = ly, X)
df <- df[complete.cases(df), ]
N <- nrow(df)
Xm <- cbind(1, as.matrix(df[, -1]))
y <- df$y
XtXi <- solve(crossprod(Xm))
b <- drop(XtXi %*% crossprod(Xm, y))
e <- drop(y - Xm %*% b)
u <- Xm * e
S <- crossprod(u)
for (j in 1:L) {
  w <- 1 - j / (L + 1)
  G <- crossprod(u[(j + 1):N, , drop = FALSE], u[1:(N - j), , drop = FALSE])
  S <- S + w * (G + t(G))
}
V <- XtXi %*% S %*% XtXi * N / (N - 16)
a <- c(0, rep(1, L))
cum <- sum(b[-1])
cse <- sqrt(drop(t(a) %*% V %*% a))
se <- sqrt(diag(V))
res <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(term = "cumulative_response", estimate = cum, se = cse, n_obs = N),
    list(term = "lag_1", estimate = unname(b[2]), se = unname(se[2]), n_obs = N),
    list(term = "lag_15", estimate = unname(b[16]), se = unname(se[16]), n_obs = N)
  ),
  method_metadata = list(estimator = "OLS distributed lag",
                         vcov = "Newey-West Bartlett maxlag 15, scaled N/(N-16)"),
  diagnostics = setNames(list(), character(0))
)
jsonlite::write_json(res, "result.json", auto_unbox = TRUE, digits = 12, pretty = TRUE)
