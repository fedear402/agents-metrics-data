library(jsonlite)
d <- read.csv("./input.csv", stringsAsFactors = FALSE)
d <- d[!is.na(d$y) & !is.na(d$group), ]
d$group <- factor(d$group)
fit <- aov(y ~ group, data = d)
tab <- summary(fit)[[1]]
Fv <- unname(tab[["F value"]][1])
df1 <- unname(tab[["Df"]][1])
df2 <- unname(tab[["Df"]][2])
pv <- unname(tab[["Pr(>F)"]][1])
n <- nrow(d)
out <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = list(
    list(term = "F", estimate = Fv, se = NA, n_obs = n),
    list(term = "df_num", estimate = as.numeric(df1), se = NA, n_obs = n),
    list(term = "df_den", estimate = as.numeric(df2), se = NA, n_obs = n),
    list(term = "p_value", estimate = pv, se = NA, n_obs = n)
  ),
  method_metadata = list(estimator = "One-way ANOVA (aov)", vcov = "none"),
  diagnostics = structure(list(), names = character(0))
)
write_json(out, "result.json", auto_unbox = TRUE, digits = NA, na = "null")
