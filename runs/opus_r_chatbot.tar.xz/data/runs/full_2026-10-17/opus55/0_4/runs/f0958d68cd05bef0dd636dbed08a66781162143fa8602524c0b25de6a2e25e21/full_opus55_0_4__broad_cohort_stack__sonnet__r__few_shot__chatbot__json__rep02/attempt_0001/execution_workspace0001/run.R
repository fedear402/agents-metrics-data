d <- read.csv("input.csv")
res <- list(); ests <- c(); ns <- c(); ntr <- c()
for (c in c(3, 5, 7)) {
  win <- (c - 2):(c + 2)
  s <- d[d$time %in% win & (d$g == c | d$g == 0 | d$g > c + 2), ]
  cnt <- tapply(s$time, s$id, function(t) length(unique(t)))
  keep <- names(cnt)[cnt == 5]
  s <- s[as.character(s$id) %in% keep, ]
  s$did <- as.numeric(s$g == c & s$time >= c)
  fit <- lm(y ~ did + factor(id) + factor(time), data = s)
  est <- unname(coef(fit)["did"])
  ests <- c(ests, est); ns <- c(ns, nrow(s))
  ntr <- c(ntr, length(unique(s$id[s$g == c])))
  res[[length(res) + 1]] <- list(term = paste0("att_g", c), estimate = est,
                                 se = NULL, n_obs = nrow(s))
}
w <- sum(ests * ntr) / sum(ntr)
res[[4]] <- list(term = "att_weighted", estimate = w, se = NULL, n_obs = sum(ns))
out <- list(task_id = "broad_cohort_stack", platform = "r", estimates = res,
            method_metadata = setNames(list(), character(0)),
            diagnostics = list(treated_units = setNames(as.list(ntr), c("g3", "g5", "g7"))))
jsonlite::write_json(out, "result.json", auto_unbox = TRUE, null = "null", digits = 16)
