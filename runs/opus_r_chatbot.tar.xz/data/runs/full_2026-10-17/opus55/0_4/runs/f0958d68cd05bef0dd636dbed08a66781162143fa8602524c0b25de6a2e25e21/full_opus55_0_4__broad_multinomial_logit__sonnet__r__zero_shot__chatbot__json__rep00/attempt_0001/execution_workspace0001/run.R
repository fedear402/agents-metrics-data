d <- read.csv("input.csv")
n <- nrow(d)
y <- as.integer(as.character(d$y))
X <- cbind(1, as.numeric(d$x), as.numeric(d$z))
k <- ncol(X)
Y1 <- as.numeric(y == 1); Y2 <- as.numeric(y == 2)
probs <- function(b) {
  e1 <- exp(X %*% b[1:k]); e2 <- exp(X %*% b[(k+1):(2*k)])
  den <- 1 + e1 + e2
  cbind(e1/den, e2/den)
}
nll <- function(b) {
  p <- probs(b); p0 <- 1 - p[,1] - p[,2]
  -sum(Y1*log(p[,1]) + Y2*log(p[,2]) + (1-Y1-Y2)*log(p0))
}
gr <- function(b) {
  p <- probs(b)
  -c(crossprod(X, Y1 - p[,1]), crossprod(X, Y2 - p[,2]))
}
hess <- function(b) {
  p <- probs(b)
  H11 <- crossprod(X * (p[,1]*(1-p[,1])), X)
  H22 <- crossprod(X * (p[,2]*(1-p[,2])), X)
  H12 <- -crossprod(X * (p[,1]*p[,2]), X)
  rbind(cbind(H11, H12), cbind(t(H12), H22))
}
b <- rep(0, 2*k)
for (it in 1:100) {
  step <- solve(hess(b), -gr(b))
  b <- b + step
  if (max(abs(step)) < 1e-12) break
}
V <- solve(hess(b))
se <- sqrt(diag(V))
# order: cat1: int,x,z ; cat2: int,x,z
e1 <- exp(b[1]); e2 <- exp(b[4])
p2 <- e2 / (1 + e1 + e2)
mk <- function(t, e, s) list(term = t, estimate = unname(e), se = s, n_obs = n)
res <- list(
  task_id = "broad_multinomial_logit",
  platform = "r",
  estimates = list(
    mk("x_cat1", b[2], se[2]),
    mk("z_cat1", b[3], se[3]),
    mk("x_cat2", b[5], se[5]),
    mk("z_cat2", b[6], se[6]),
    mk("prob_cat2_zero", p2, NULL)
  ),
  method_metadata = list(estimator = "Multinomial logit MLE (Newton-Raphson), base outcome 0",
                         vcov = "Inverse observed information (Hessian)"),
  diagnostics = list(loglik = -nll(b), iterations = it)
)
jsonlite::write_json(res, "result.json", auto_unbox = TRUE, digits = NA, null = "null", pretty = TRUE)
