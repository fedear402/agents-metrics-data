suppressPackageStartupMessages(library(jsonlite))

df <- read.csv("./input.csv", stringsAsFactors = FALSE)
df$y <- suppressWarnings(as.numeric(df$y))
df <- df[!is.na(df$y) & !is.na(df$group) & trimws(as.character(df$group)) != "", ]
df$group <- factor(trimws(as.character(df$group)))
n <- nrow(df)

fit <- aov(y ~ group, data = df)
tab <- summary(fit)[[1]]
Fstat <- unname(tab[1, "F value"])
df1 <- unname(tab[1, "Df"])
df2 <- unname(tab[2, "Df"])
p <- unname(tab[1, "Pr(>F)"])

grp_n <- as.list(table(df$group))

res <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = list(
    list(term = "F", estimate = Fstat, se = NULL, n_obs = n),
    list(term = "df_num", estimate = as.numeric(df1), se = NULL, n_obs = n),
    list(term = "df_den", estimate = as.numeric(df2), se = NULL, n_obs = n),
    list(term = "p_value", estimate = p, se = NULL, n_obs = n)
  ),
  method_metadata = list(estimator = "one-way ANOVA (aov, equal variances)", vcov = "classical OLS"),
  diagnostics = list(n_groups = nlevels(df$group), group_sizes = grp_n)
)

writeLines(toJSON(res, auto_unbox = TRUE, null = "null", digits = I(15), pretty = TRUE), "result.json")
