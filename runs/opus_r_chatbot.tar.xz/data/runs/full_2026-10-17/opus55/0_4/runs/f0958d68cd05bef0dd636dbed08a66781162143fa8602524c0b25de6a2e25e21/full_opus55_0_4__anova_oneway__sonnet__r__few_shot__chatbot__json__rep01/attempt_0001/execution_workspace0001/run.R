library(jsonlite)
d <- read.csv("./input.csv", stringsAsFactors = FALSE)
d <- d[!is.na(d$y) & !is.na(d$group), ]
d$group <- factor(d$group)
fit <- aov(y ~ group, data = d)
tab <- summary(fit)[[1]]
Fv <- tab[1, "F value"]
dfn <- tab[1, "Df"]
dfd <- tab[2, "Df"]
pv <- tab[1, "Pr(>F)"]
n <- nrow(d)
out <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = list(
    list(term = "F", estimate = unname(Fv), se = NA, n_obs = n),
    list(term = "df_num", estimate = unname(dfn), se = NA, n_obs = n),
    list(term = "df_den", estimate = unname(dfd), se = NA, n_obs = n),
    list(term = "p_value", estimate = unname(pv), se = NA, n_obs = n)
  ),
  method_metadata = list(estimator = "One-way ANOVA (aov, equal variances)",
                         vcov = "none"),
  diagnostics = structure(list(), names = character(0))
)
write_json(out, "result.json", auto_unbox = TRUE, digits = NA, na = "null")
