suppressPackageStartupMessages(library(jsonlite))

df <- read.csv("./input.csv", stringsAsFactors = FALSE)
df$y <- suppressWarnings(as.numeric(df$y))
df <- df[!is.na(df$y) & !is.na(df$group) & trimws(as.character(df$group)) != "", ]
df$group <- factor(trimws(as.character(df$group)))
df <- droplevels(df)

n <- nrow(df)
k <- nlevels(df$group)

fit <- lm(y ~ group, data = df)
tab <- anova(fit)
Fst <- tab[["F value"]][1]
df1 <- tab[["Df"]][1]
df2 <- tab[["Df"]][2]
pv <- tab[["Pr(>F)"]][1]

grp_n <- as.list(table(df$group))
grp_mean <- as.list(tapply(df$y, df$group, mean))
grp_sd <- as.list(tapply(df$y, df$group, sd))

welch <- tryCatch({
  w <- oneway.test(y ~ group, data = df, var.equal = FALSE)
  list(F = unname(w$statistic), df_num = unname(w$parameter[1]),
       df_den = unname(w$parameter[2]), p_value = w$p.value)
}, error = function(e) NULL)

bart <- tryCatch({
  b <- bartlett.test(y ~ group, data = df)
  list(statistic = unname(b$statistic), p_value = b$p.value)
}, error = function(e) NULL)

mk <- function(term, est) list(term = term, estimate = unname(est), se = NULL, n_obs = n)

out <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = list(
    mk("F", Fst), mk("df_num", df1), mk("df_den", df2), mk("p_value", pv)
  ),
  method_metadata = list(
    estimator = "One-way ANOVA (classical, equal variances) via lm/anova",
    vcov = "classical (homoskedastic)"
  ),
  diagnostics = list(
    n_groups = k,
    group_n = grp_n,
    group_mean = grp_mean,
    group_sd = grp_sd,
    ss_between = tab[["Sum Sq"]][1],
    ss_within = tab[["Sum Sq"]][2],
    welch_anova = welch,
    bartlett_test = bart
  )
)

writeLines(toJSON(out, auto_unbox = TRUE, digits = NA, null = "null", pretty = TRUE),
           "result.json")
