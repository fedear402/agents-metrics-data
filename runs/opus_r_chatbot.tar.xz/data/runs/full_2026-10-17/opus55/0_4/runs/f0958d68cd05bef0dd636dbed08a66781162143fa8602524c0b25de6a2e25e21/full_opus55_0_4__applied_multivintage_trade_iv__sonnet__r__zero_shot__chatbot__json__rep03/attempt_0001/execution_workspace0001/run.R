suppressPackageStartupMessages(library(jsonlite))

cw  <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
tr  <- read.csv("trade.csv", stringsAsFactors = FALSE)
ar  <- read.csv("areas.csv", stringsAsFactors = FALSE)
em  <- read.csv("employment.csv", stringsAsFactors = FALSE)
out <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

trim <- function(v) trimws(as.character(v))
cw$code <- trim(cw$code); cw$industry <- trim(cw$industry)
tr$code <- trim(tr$code); tr$period <- trim(tr$period)
ar$area <- trim(ar$area); ar$period <- trim(ar$period); ar$vintage <- tolower(trim(ar$vintage))
em$area <- trim(em$area); em$period <- trim(em$period); em$vintage <- tolower(trim(em$vintage))
em$industry <- trim(em$industry)
out$area <- trim(out$area); out$period <- trim(out$period)

# Trade joined to industries
trj <- merge(tr, unique(cw[, c("code", "industry")]), by = "code")
trj <- aggregate(cbind(us_change, other_change, price_index, years) ~ period + industry,
                 data = trj, FUN = function(v) v[1])
trj <- trj[order(trj$period, trj$industry), ]

inds <- sort(unique(cw$industry))

# Full grid of area-period-vintage-industry, missing = 0
grid <- merge(unique(ar[, c("area", "period", "vintage")]), data.frame(industry = inds))
emagg <- aggregate(employment ~ area + period + vintage + industry, data = em, FUN = sum)
g <- merge(grid, emagg, by = c("area", "period", "vintage", "industry"), all.x = TRUE)
g$employment[is.na(g$employment)] <- 0

nat <- aggregate(employment ~ period + vintage + industry, data = g, FUN = sum)
names(nat)[names(nat) == "employment"] <- "nat_emp"
g <- merge(g, nat, by = c("period", "vintage", "industry"))
tot <- unique(ar[, c("area", "period", "vintage", "total_employment")])
g <- merge(g, tot, by = c("area", "period", "vintage"))
g <- merge(g, trj, by = c("period", "industry"))

g$chg <- ifelse(g$vintage == "base", g$us_change, g$other_change)
g$term <- (g$employment / g$total_employment) * (g$chg / g$nat_emp) /
  (g$price_index / 100) / 1000 * (10 / g$years)

ex <- aggregate(term ~ area + period + vintage, data = g, FUN = sum)
xb <- ex[ex$vintage == "base", c("area", "period", "term")];  names(xb)[3] <- "x"
ze <- ex[ex$vintage == "early", c("area", "period", "term")]; names(ze)[3] <- "z"

pop <- ar[ar$vintage == "base", c("area", "period", "population")]
pop <- pop[!duplicated(pop[, c("area", "period")]), ]

d <- merge(out, xb, by = c("area", "period"))
d <- merge(d, ze, by = c("area", "period"))
d <- merge(d, pop, by = c("area", "period"))
d <- d[complete.cases(d[, c("change_pp", "control", "x", "z", "population")]), ]

pnum <- suppressWarnings(as.numeric(d$period))
if (any(is.na(pnum))) pnum <- as.numeric(factor(d$period)) - 1
X <- cbind(1, pnum, d$control, d$x)
Z <- cbind(1, pnum, d$control, d$z)
y <- d$change_pp
w <- d$population

XWZ <- t(X) %*% (w * Z)
ZWZ <- t(Z) %*% (w * Z)
ZWy <- t(Z) %*% (w * y)
A <- XWZ %*% solve(ZWZ)
beta <- solve(A %*% t(XWZ), A %*% ZWy)
iv_slope <- beta[4]

n_obs <- nrow(d)
getv <- function(df, col, a, p) df[[col]][df$area == a & df$period == p][1]
a0 <- if ("0" %in% d$area) "0" else sort(unique(d$area))[1]
ps <- sort(unique(d$period))
p0 <- if ("0" %in% ps) "0" else ps[1]
p1 <- if ("1" %in% ps) "1" else ps[2]

ests <- list(
  list(term = "iv_slope", estimate = iv_slope, se = NULL, n_obs = n_obs),
  list(term = "exposure_area0_period0", estimate = getv(xb, "x", a0, p0), se = NULL, n_obs = n_obs),
  list(term = "exposure_area0_period1", estimate = getv(xb, "x", a0, p1), se = NULL, n_obs = n_obs),
  list(term = "instrument_area0_period0", estimate = getv(ze, "z", a0, p0), se = NULL, n_obs = n_obs)
)

res <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = ests,
  method_metadata = list(
    estimator = "weighted 2SLS",
    weights = "base-vintage population",
    regressors = c("intercept", "period", "control", "x"),
    instruments = c("intercept", "period", "control", "z")
  ),
  diagnostics = list(
    n_obs = n_obs,
    n_industries = length(inds),
    coefficients = as.numeric(beta)
  )
)

write_json(res, "result.json", auto_unbox = TRUE, digits = NA, null = "null", pretty = TRUE)
