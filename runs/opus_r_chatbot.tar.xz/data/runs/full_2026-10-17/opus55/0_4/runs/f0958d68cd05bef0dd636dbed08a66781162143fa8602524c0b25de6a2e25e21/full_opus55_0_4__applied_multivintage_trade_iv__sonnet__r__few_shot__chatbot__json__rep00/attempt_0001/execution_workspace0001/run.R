library(jsonlite)
cw <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
tr <- read.csv("trade.csv", stringsAsFactors = FALSE)
ar <- read.csv("areas.csv", stringsAsFactors = FALSE)
em <- read.csv("employment.csv", stringsAsFactors = FALSE)
oc <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

cw$code <- as.character(cw$code); tr$code <- as.character(tr$code)
tr <- merge(tr, cw, by = "code")
ar$vintage <- trimws(as.character(ar$vintage)); em$vintage <- trimws(as.character(em$vintage))
em$industry <- as.character(em$industry); tr$industry <- as.character(tr$industry)
inds <- sort(unique(c(as.character(cw$industry))))

keys <- unique(oc[c("area", "period")])
keys <- keys[order(keys$period, keys$area), ]

expo <- function(vint, chg) {
  sapply(seq_len(nrow(keys)), function(i) {
    a <- keys$area[i]; p <- keys$period[i]
    tot <- ar$total_employment[ar$area == a & ar$period == p & ar$vintage == vint][1]
    s <- 0
    for (j in inds) {
      e <- em$employment[em$area == a & em$period == p & em$vintage == vint & em$industry == j]
      e <- if (length(e)) sum(e) else 0
      nat <- sum(em$employment[em$period == p & em$vintage == vint & em$industry == j])
      t <- tr[tr$period == p & tr$industry == j, ][1, ]
      s <- s + (e / tot) * (t[[chg]] / nat) / (t$price_index / 100) / 1000 * (10 / t$years)
    }
    s
  })
}
keys$x <- expo("base", "us_change")
keys$z <- expo("early", "other_change")

d <- merge(keys, oc, by = c("area", "period"))
pop <- ar[ar$vintage == "base", c("area", "period", "population")]
pop <- pop[!duplicated(pop[c("area", "period")]), ]
d <- merge(d, pop, by = c("area", "period"))
d <- d[order(d$period, d$area), ]

w <- d$population
C <- cbind(1, d$period, d$control)
X <- cbind(C, d$x) * sqrt(w); Z <- cbind(C, d$z) * sqrt(w)
fit <- qr.fitted(qr(Z), X)
b <- as.numeric(qr.coef(qr(fit), d$change_pp * sqrt(w)))
slope <- b[4]
n <- nrow(d)

g <- function(a, p, v) d[[v]][d$area == 0 & d$period == p][1]
est <- list(
  list(term = "iv_slope", estimate = slope, se = NA, n_obs = n),
  list(term = "exposure_area0_period0", estimate = g(0, 0, "x"), se = NA, n_obs = n),
  list(term = "exposure_area0_period1", estimate = g(0, 1, "x"), se = NA, n_obs = n),
  list(term = "instrument_area0_period0", estimate = g(0, 0, "z"), se = NA, n_obs = n)
)
res <- list(
  task_id = "applied_multivintage_trade_iv", platform = "r", estimates = est,
  method_metadata = list(estimator = "weighted 2SLS", weights = "base population",
                         exogenous = c("intercept", "period", "control"), instrument = "z"),
  diagnostics = list(n_obs = n, n_industries = length(inds))
)
write_json(res, "result.json", auto_unbox = TRUE, digits = NA, na = "null", null = "null")
