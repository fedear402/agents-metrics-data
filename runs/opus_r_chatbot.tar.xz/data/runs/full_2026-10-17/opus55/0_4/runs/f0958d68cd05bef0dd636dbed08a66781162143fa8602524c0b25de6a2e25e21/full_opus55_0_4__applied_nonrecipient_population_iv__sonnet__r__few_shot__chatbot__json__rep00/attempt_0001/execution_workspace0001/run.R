library(jsonlite)

d <- read.csv("households.csv")
census <- read.csv("census.csv")
d <- d[d$recipient == 0, ]
d <- d[complete.cases(d[, c("eligible", "dose", "instrument", "baseline", "outcome", "weight")]), ]

e <- d$eligible
ne <- 1 - e
w <- d$weight
C <- cbind(ne, e, d$baseline * ne, d$baseline * e)
X <- cbind(C, d$dose * ne, d$dose * e)
Z <- cbind(C, d$instrument * ne, d$instrument * e)

sw <- sqrt(w)
Xw <- X * sw; Zw <- Z * sw; yw <- d$outcome * sw
Xhat <- qr.fitted(qr(Zw), Xw)
beta <- as.numeric(qr.coef(qr(Xhat), yw))
slopes <- beta[5:6]

mdose <- sapply(0:1, function(g) {
  i <- e == g
  weighted.mean(d$dose[i], w[i])
})
effect <- slopes * mdose
pop <- census$nonrecipient_population[match(0:1, census$eligible)]
pop_effect <- sum(effect * pop) / sum(pop)

n <- nrow(d)
n_g <- sapply(0:1, function(g) sum(e == g))

est <- list(
  list(term = "ineligible_effect", estimate = effect[1], se = NULL, n_obs = n),
  list(term = "eligible_nonrecipient_effect", estimate = effect[2], se = NULL, n_obs = n),
  list(term = "population_effect", estimate = pop_effect, se = NULL, n_obs = n)
)

res <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = est,
  method_metadata = list(
    estimator = "weighted 2SLS, interacted by eligibility, no common intercept",
    endogenous = c("dose*(1-eligible)", "dose*eligible"),
    exogenous = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"),
    excluded_instruments = c("instrument*(1-eligible)", "instrument*eligible"),
    weights = "weight",
    effect_definition = "dose slope times household-weighted mean dose (zero-dose counterfactual)",
    aggregation = "census nonrecipient_population weighted mean"
  ),
  diagnostics = list(
    n_retained = n,
    n_ineligible = n_g[1],
    n_eligible = n_g[2],
    dose_slope_ineligible = slopes[1],
    dose_slope_eligible = slopes[2],
    weighted_mean_dose_ineligible = mdose[1],
    weighted_mean_dose_eligible = mdose[2],
    census_weights = pop
  )
)

write_json(res, "result.json", auto_unbox = TRUE, digits = NA, null = "null", pretty = TRUE)
