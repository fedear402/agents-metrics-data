library(jsonlite)

dat <- read.csv("./input.csv")
dat <- dat[order(dat$t), ]
dat <- dat[!is.na(dat$y), ]
y <- as.numeric(dat$y)
n <- length(y)

fit <- arima(y, order = c(1, 1, 1), include.mean = FALSE, method = "ML")
pr <- predict(fit, n.ahead = 1)
fc <- as.numeric(pr$pred[1])
se <- as.numeric(pr$se[1])
z <- qnorm(0.975)
lo <- fc - z * se
hi <- fc + z * se

out <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = list(
    list(term = "forecast", estimate = fc, se = se, n_obs = n),
    list(term = "lower_95", estimate = lo, se = NA, n_obs = n),
    list(term = "upper_95", estimate = hi, se = NA, n_obs = n)
  ),
  method_metadata = list(
    estimator = "ARIMA(1,1,1) by exact maximum likelihood (stats::arima, method='ML'), no constant/drift",
    vcov = "Gaussian forecast error variance from state-space Kalman filter; 95% PI = forecast +/- 1.959964*se"
  ),
  diagnostics = list(
    ar1 = unname(coef(fit)["ar1"]),
    ma1 = unname(coef(fit)["ma1"]),
    sigma2 = fit$sigma2,
    loglik = fit$loglik,
    forecast_t = if ("t" %in% names(dat)) max(dat$t) + 1 else n + 1
  )
)
write_json(out, "result.json", auto_unbox = TRUE, digits = NA, na = "null")
