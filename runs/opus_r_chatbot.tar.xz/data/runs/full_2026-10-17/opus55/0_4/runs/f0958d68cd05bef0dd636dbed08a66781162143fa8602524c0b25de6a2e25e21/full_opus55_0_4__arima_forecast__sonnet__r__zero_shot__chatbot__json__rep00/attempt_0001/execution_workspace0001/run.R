df <- read.csv("./input.csv")
df <- df[order(df$t), ]
y <- as.numeric(df$y)
y <- y[!is.na(y)]
n <- length(y)

fit <- arima(y, order = c(1, 1, 1), method = "ML", include.mean = FALSE)
pr <- predict(fit, n.ahead = 1)
fc <- as.numeric(pr$pred[1])
se <- as.numeric(pr$se[1])
z <- qnorm(0.975)
lo <- fc - z * se
hi <- fc + z * se

fmt <- function(x) if (is.null(x) || is.na(x)) "null" else formatC(x, digits = 12, format = "g")
co <- coef(fit)
json <- paste0(
  '{\n',
  '  "task_id": "arima_forecast",\n',
  '  "platform": "r",\n',
  '  "estimates": [\n',
  '    {"term": "forecast", "estimate": ', fmt(fc), ', "se": ', fmt(se), ', "n_obs": ', n, '},\n',
  '    {"term": "lower_95", "estimate": ', fmt(lo), ', "se": null, "n_obs": ', n, '},\n',
  '    {"term": "upper_95", "estimate": ', fmt(hi), ', "se": null, "n_obs": ', n, '}\n',
  '  ],\n',
  '  "method_metadata": {"estimator": "ARIMA(1,1,1) exact Gaussian ML via stats::arima, no constant/drift", "vcov": "inverse Hessian (ML)"},\n',
  '  "diagnostics": {"ar1": ', fmt(unname(co["ar1"])), ', "ma1": ', fmt(unname(co["ma1"])),
  ', "sigma2": ', fmt(fit$sigma2), ', "loglik": ', fmt(fit$loglik), ', "aic": ', fmt(fit$aic), '}\n',
  '}\n')
writeLines(json, "result.json")
