library(jsonlite)

d <- read.csv("input.csv")
d$g[is.na(d$g)] <- 0

ests <- list()
atts <- c()
wts <- c()
nobs <- c()

for (c in c(3, 5, 7)) {
  win <- (c - 2):(c + 2)
  s <- d[d$time %in% win & (d$g == c | d$g == 0 | d$g > c + 2), ]
  cnt <- table(s$id)
  keep <- names(cnt)[cnt == length(win)]
  s <- s[as.character(s$id) %in% keep, ]
  s$did <- as.numeric(s$g == c & s$time >= c)
  fit <- lm(y ~ did + factor(id) + factor(time), data = s)
  b <- unname(coef(fit)["did"])
  atts <- c(atts, b)
  wts <- c(wts, length(unique(s$id[s$g == c])))
  nobs <- c(nobs, nrow(s))
  ests[[length(ests) + 1]] <- list(term = paste0("att_g", c), estimate = b,
                                   se = NA, n_obs = nrow(s))
}

ests[[4]] <- list(term = "att_weighted", estimate = sum(atts * wts) / sum(wts),
                  se = NA, n_obs = sum(nobs))

res <- list(
  task_id = "broad_cohort_stack",
  platform = "r",
  estimates = ests,
  method_metadata = setNames(list(), character(0)),
  diagnostics = list(treated_units = setNames(as.list(wts), c("g3", "g5", "g7")))
)

write_json(res, "result.json", auto_unbox = TRUE, digits = NA, na = "null", pretty = TRUE)
