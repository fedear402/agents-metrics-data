library(jsonlite)
d <- read.csv("input.csv", stringsAsFactors = FALSE)
d$region_id <- as.character(d$region_id); d$industry_id <- as.character(d$industry_id)
regions <- sort(unique(d$region_id)); inds <- sort(unique(d$industry_id))
R <- length(regions); N <- length(inds)
S <- matrix(0, R, N, dimnames = list(regions, inds))
for (i in seq_len(nrow(d))) S[d$region_id[i], d$industry_id[i]] <- S[d$region_id[i], d$industry_id[i]] + d$share[i]
first_row <- d[!duplicated(d$region_id), ]
first_row <- first_row[match(regions, first_row$region_id), ]
shk <- d[!duplicated(d$industry_id), ]
shock <- shk$shock[match(inds, shk$industry_id)]
e <- first_row$region_weight / sum(first_row$region_weight)
x <- first_row$x; y <- first_row$y
z <- drop(S %*% shock)
reg <- cbind(y, x, z)
cen <- sweep(reg, 2, drop(e %*% reg))
s <- drop(e %*% S)
keep <- s > 0
agg <- (t(S) %*% (e * cen)) / s
agg <- agg[keep, , drop = FALSE]; sk <- s[keep]; shk_k <- shock[keep]
Nk <- sum(keep)
shock_iv <- function(dep, endo) {
  X <- cbind(1, endo); Z <- cbind(1, shk_k)
  cross <- crossprod(Z, sk * X)
  b <- solve(cross, crossprod(Z, sk * dep))
  u <- drop(dep - X %*% b)
  sc <- Z * (sk * u)
  inv <- solve(cross)
  V <- Nk / (Nk - 2) * inv %*% crossprod(sc) %*% t(inv)
  c(b[2], sqrt(V[2, 2]))
}
eff <- shock_iv(agg[, 1], agg[, 2])
fs <- shock_iv(agg[, 2], agg[, 3])
reg_eff <- sum(e * cen[, 3] * cen[, 1]) / sum(e * cen[, 3] * cen[, 2])
reg_fs <- sum(e * cen[, 3] * cen[, 2]) / sum(e * cen[, 3]^2)
res <- list(
  task_id = "applied_shift_share", platform = "r",
  estimates = list(
    list(term = "effect", estimate = reg_eff, se = eff[2], n_obs = Nk),
    list(term = "first_stage", estimate = reg_fs, se = fs[2], n_obs = Nk),
    list(term = "effective_shocks", estimate = 1 / sum(s^2), se = NULL, n_obs = Nk)),
  method_metadata = list(estimator = "weighted 2SLS shift-share with BHJ shock-level aggregation",
                         vcov = "shock-level HC1 N/(N-2), structural IV residuals"),
  diagnostics = list(shock_level_effect = eff[1], shock_level_first_stage = fs[1], n_regions = R))
write_json(res, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
