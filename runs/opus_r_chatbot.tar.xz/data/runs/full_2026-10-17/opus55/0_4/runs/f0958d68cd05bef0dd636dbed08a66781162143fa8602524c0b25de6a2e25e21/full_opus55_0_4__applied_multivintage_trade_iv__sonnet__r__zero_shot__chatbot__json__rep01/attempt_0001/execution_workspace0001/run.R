suppressPackageStartupMessages(library(jsonlite))

cw <- read.csv("crosswalk.csv", colClasses = "character", strip.white = TRUE)
tr <- read.csv("trade.csv", stringsAsFactors = FALSE, strip.white = TRUE)
ar <- read.csv("areas.csv", stringsAsFactors = FALSE, strip.white = TRUE)
em <- read.csv("employment.csv", stringsAsFactors = FALSE, strip.white = TRUE)
oc <- read.csv("outcomes.csv", stringsAsFactors = FALSE, strip.white = TRUE)

tr$code <- trimws(as.character(tr$code))
cw$code <- trimws(cw$code); cw$industry <- trimws(cw$industry)
tr$period <- as.character(tr$period)
ar$period <- as.character(ar$period); ar$area <- as.character(ar$area)
ar$vintage <- trimws(tolower(ar$vintage))
em$period <- as.character(em$period); em$area <- as.character(em$area)
em$vintage <- trimws(tolower(em$vintage)); em$industry <- trimws(as.character(em$industry))
oc$period <- as.character(oc$period); oc$area <- as.character(oc$area)

trj <- merge(tr, cw, by = "code")
trade_pi <- aggregate(cbind(us_change, other_change) ~ period + industry, data = trj, FUN = sum)
pinfo <- aggregate(cbind(price_index, years) ~ period, data = tr, FUN = function(v) v[1])

inds <- sort(unique(cw$industry))
areas <- unique(ar$area); periods <- unique(ar$period)

# full grid with zeros
grid <- expand.grid(area = areas, period = periods, vintage = c("base", "early"),
                    industry = inds, stringsAsFactors = FALSE)
emA <- aggregate(employment ~ area + period + vintage + industry, data = em, FUN = sum)
grid <- merge(grid, emA, all.x = TRUE)
grid$employment[is.na(grid$employment)] <- 0

nat <- aggregate(employment ~ period + vintage + industry, data = grid, FUN = sum)
names(nat)[names(nat) == "employment"] <- "nat_emp"
grid <- merge(grid, nat)
grid <- merge(grid, ar[, c("area", "period", "vintage", "total_employment")])
grid <- merge(grid, trade_pi)
grid <- merge(grid, pinfo)

grid$chg <- ifelse(grid$vintage == "base", grid$us_change, grid$other_change)
grid$term <- (grid$employment / grid$total_employment) * (grid$chg / grid$nat_emp) /
  (grid$price_index / 100) / 1000 * (10 / grid$years)
ex <- aggregate(term ~ area + period + vintage, data = grid, FUN = sum)
xb <- ex[ex$vintage == "base", c("area", "period", "term")]; names(xb)[3] <- "x"
ze <- ex[ex$vintage == "early", c("area", "period", "term")]; names(ze)[3] <- "z"

pop <- ar[ar$vintage == "base", c("area", "period", "population")]
d <- merge(oc, xb); d <- merge(d, ze); d <- merge(d, pop)
d <- d[complete.cases(d[, c("change_pp", "control", "x", "z", "population")]), ]

n <- nrow(d)
pnum <- as.numeric(d$period)
X <- cbind(1, pnum, d$control, d$x)
Z <- cbind(1, pnum, d$control, d$z)
y <- d$change_pp; w <- d$population
XWZ <- t(X) %*% (w * Z); ZWZ <- t(Z) %*% (w * Z); ZWy <- t(Z) %*% (w * y)
A <- XWZ %*% solve(ZWZ)
beta <- solve(A %*% t(XWZ), A %*% ZWy)
iv_slope <- beta[4]

p0 <- sort(unique(pnum))[1]; p1 <- sort(unique(pnum))[2]
sel <- function(df, col, p) df[[col]][df$area == "0" & as.numeric(df$period) == p][1]
ex00 <- sel(d, "x", p0); ex01 <- sel(d, "x", p1); in00 <- sel(d, "z", p0)

mk <- function(t, v) list(term = t, estimate = unname(v), se = NULL, n_obs = as.integer(n))
res <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = list(
    mk("iv_slope", iv_slope),
    mk("exposure_area0_period0", ex00),
    mk("exposure_area0_period1", ex01),
    mk("instrument_area0_period0", in00)
  ),
  method_metadata = list(estimator = "weighted 2SLS", weight = "base-vintage population",
                         instruments = c("intercept", "period", "control", "z")),
  diagnostics = list(n_obs = as.integer(n), coefficients = as.numeric(beta))
)
write_json(res, "result.json", auto_unbox = TRUE, digits = NA, null = "null", pretty = TRUE)
