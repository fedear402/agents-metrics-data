d <- read.csv("./input.csv")
d <- d[order(d$t), ]
y <- as.numeric(d$y)
y <- y[!is.na(y)]
n <- length(y)

fit <- arima(y, order = c(1, 1, 1), include.mean = FALSE, method = "ML")
p <- predict(fit, n.ahead = 1)
fc <- as.numeric(p$pred[1])
se <- as.numeric(p$se[1])
z <- qnorm(0.975)
lo <- fc - z * se
hi <- fc + z * se

fmt <- function(x) if (is.null(x) || is.na(x)) "null" else formatC(x, digits = 12, format = "g")
co <- coef(fit)
est <- function(term, val, s) sprintf('{"term": "%s", "estimate": %s, "se": %s, "n_obs": %d}', term, fmt(val), fmt(s), n)

json <- paste0(
  '{\n  "task_id": "arima_forecast",\n  "platform": "r",\n  "estimates": [\n    ',
  paste(c(est("forecast", fc, se), est("lower_95", lo, NA), est("upper_95", hi, NA)), collapse = ",\n    "),
  '\n  ],\n  "method_metadata": {"estimator": "ARIMA(1,1,1) exact ML via stats::arima, no constant/drift", "vcov": "MLE inverse Hessian; forecast SE from state-space prediction"},\n',
  '  "diagnostics": {"ar1": ', fmt(co["ar1"]), ', "ma1": ', fmt(co["ma1"]),
  ', "sigma2": ', fmt(fit$sigma2), ', "loglik": ', fmt(fit$loglik),
  ', "forecast_se": ', fmt(se), ', "forecast_t": ', fmt(max(d$t) + 1), '}\n}\n'
)
writeLines(json, "result.json")
