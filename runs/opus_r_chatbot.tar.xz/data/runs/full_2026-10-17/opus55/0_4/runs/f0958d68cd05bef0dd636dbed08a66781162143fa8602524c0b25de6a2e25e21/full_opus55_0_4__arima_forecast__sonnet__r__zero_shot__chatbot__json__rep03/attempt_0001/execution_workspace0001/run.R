suppressWarnings(suppressMessages({
  have_json <- requireNamespace("jsonlite", quietly = TRUE)
}))

d <- read.csv("./input.csv")
d <- d[order(d$t), ]
y <- as.numeric(d$y)
ok <- !is.na(y)
y <- y[ok]
n <- length(y)

fit <- arima(y, order = c(1, 1, 1), include.mean = FALSE, method = "ML")
p <- predict(fit, n.ahead = 1)
fc <- as.numeric(p$pred[1])
se <- as.numeric(p$se[1])
z <- qnorm(0.975)
lo <- fc - z * se
hi <- fc + z * se

co <- coef(fit)
est <- list(
  list(term = "forecast", estimate = fc, se = se, n_obs = n),
  list(term = "lower_95", estimate = lo, se = NULL, n_obs = n),
  list(term = "upper_95", estimate = hi, se = NULL, n_obs = n)
)
res <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = est,
  method_metadata = list(
    estimator = "ARIMA(1,1,1) exact ML via stats::arima, no constant/drift",
    vcov = "model-based (inverse Hessian); forecast SE from MSE of one-step prediction"
  ),
  diagnostics = list(
    ar1 = unname(co["ar1"]), ma1 = unname(co["ma1"]),
    sigma2 = fit$sigma2, loglik = fit$loglik, aic = fit$aic,
    last_t = d$t[ok][n]
  )
)

if (have_json) {
  txt <- jsonlite::toJSON(res, auto_unbox = TRUE, digits = 15, null = "null", pretty = TRUE)
  writeLines(txt, "result.json")
} else {
  f <- function(x) formatC(x, digits = 15, format = "g")
  e <- sapply(est, function(r) sprintf('{"term":"%s","estimate":%s,"se":%s,"n_obs":%d}',
    r$term, f(r$estimate), if (is.null(r$se)) "null" else f(r$se), r$n_obs))
  txt <- sprintf('{"task_id":"arima_forecast","platform":"r","estimates":[%s],"method_metadata":{"estimator":"%s","vcov":"%s"},"diagnostics":{}}',
    paste(e, collapse = ","), res$method_metadata$estimator, res$method_metadata$vcov)
  writeLines(txt, "result.json")
}
