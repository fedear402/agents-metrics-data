suppressPackageStartupMessages(library(jsonlite))

d <- read.csv("input.csv", stringsAsFactors = FALSE)

cohorts <- c(3, 5, 7)
res <- list()
atts <- c(); wts <- c(); nobs <- c()

for (c in cohorts) {
  win <- (c - 2):(c + 2)
  s <- d[d$time %in% win & (d$g == c | d$g == 0 | d$g > c + 2), ]
  s <- s[!is.na(s$y), ]
  cnt <- tapply(s$time, s$id, function(t) length(unique(t)))
  keep <- names(cnt)[cnt == length(win)]
  s <- s[as.character(s$id) %in% keep, ]
  s$did <- as.numeric(s$g == c & s$time >= c)
  fit <- lm(y ~ did + factor(id) + factor(time), data = s)
  att <- unname(coef(fit)["did"])
  ntr <- length(unique(s$id[s$g == c]))
  atts <- c(atts, att); wts <- c(wts, ntr); nobs <- c(nobs, nrow(s))
  res[[length(res) + 1]] <- list(term = paste0("att_g", c), estimate = att,
                                 se = NULL, n_obs = nrow(s))
}

attw <- sum(atts * wts) / sum(wts)
res[[length(res) + 1]] <- list(term = "att_weighted", estimate = attw,
                               se = NULL, n_obs = sum(nobs))

out <- list(
  task_id = "broad_cohort_stack",
  platform = "r",
  estimates = res,
  method_metadata = list(
    method = "cohort-specific balanced DiD windows with unit and time FE",
    weights = "number of retained treated units per cohort"
  ),
  diagnostics = list(
    treated_units = setNames(as.list(wts), paste0("g", cohorts)),
    n_obs = setNames(as.list(nobs), paste0("g", cohorts))
  )
)

write_json(out, "result.json", auto_unbox = TRUE, null = "null", digits = NA, pretty = TRUE)
