suppressPackageStartupMessages(library(jsonlite))

dat <- read.csv("input.csv")
dat <- dat[complete.cases(dat[, c("score", "participated", "earnings")]), ]
d <- dat[abs(dat$score) < 1, ]
n <- nrow(d)

x <- d$score
w <- 1 - abs(x)
R <- as.numeric(x >= 0)
X <- cbind(1, R, x, R * x)
y <- d$earnings
t <- d$participated

A <- crossprod(X, X * w)
Ainv <- solve(A)
by <- Ainv %*% crossprod(X, w * y)
bt <- Ainv %*% crossprod(X, w * t)
ey <- as.vector(y - X %*% by)
et <- as.vector(t - X %*% bt)

meat <- function(e1, e2) crossprod(X * (w * e1), X * (w * e2))
Vyy <- Ainv %*% meat(ey, ey) %*% Ainv
Vtt <- Ainv %*% meat(et, et) %*% Ainv
Vyt <- Ainv %*% meat(ey, et) %*% Ainv

rf <- by[2]; fs <- bt[2]
var_rf <- Vyy[2, 2]; var_fs <- Vtt[2, 2]; cov_rf_fs <- Vyt[2, 2]
te <- rf / fs
g <- c(1 / fs, -rf / fs^2)
V <- matrix(c(var_rf, cov_rf_fs, cov_rf_fs, var_fs), 2, 2)
se_te <- sqrt(as.numeric(t(g) %*% V %*% g))

res <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = te, se = se_te, n_obs = n),
    list(term = "reduced_form", estimate = rf, se = sqrt(var_rf), n_obs = n),
    list(term = "first_stage", estimate = fs, se = sqrt(var_fs), n_obs = n)
  ),
  method_metadata = list(
    estimator = "fuzzy RD, local linear, triangular kernel, bandwidth 1, cutoff 0; Wald ratio of reduced form to first stage",
    vcov = "HC0 sandwich, joint covariance of RF and FS, delta method for ratio"
  ),
  diagnostics = list(cov_rf_fs = cov_rf_fs, n_left = sum(R == 0), n_right = sum(R == 1))
)
writeLines(toJSON(res, auto_unbox = TRUE, digits = NA, pretty = TRUE), "result.json")
