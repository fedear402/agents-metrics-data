suppressPackageStartupMessages({
  library(jsonlite)
})

d <- read.csv("input.csv", stringsAsFactors = FALSE)
d$date <- as.Date(d$date)
d <- d[order(d$date), ]
n <- nrow(d)
ly <- log(d$sales)
dv <- c(NA, diff(log(d$vix)))
L <- 15
X <- sapply(1:L, function(k) c(rep(NA, k), dv[seq_len(n - k)]))
colnames(X) <- paste0("lag_", 1:L)
ok <- complete.cases(cbind(ly, X))
y <- ly[ok]
Xm <- cbind(1, X[ok, , drop = FALSE])
N <- length(y)
fit <- lm.fit(Xm, y)
b <- fit$coefficients
e <- fit$residuals
XtXi <- solve(crossprod(Xm))
U <- Xm * e
S <- crossprod(U)
for (j in 1:L) {
  w <- 1 - j / (L + 1)
  G <- crossprod(U[(j + 1):N, , drop = FALSE], U[1:(N - j), , drop = FALSE])
  S <- S + w * (G + t(G))
}
V <- XtXi %*% S %*% XtXi * N / (N - 16)
idx <- 2:(L + 1)
a <- rep(1, L)
cum <- sum(b[idx])
cse <- sqrt(as.numeric(t(a) %*% V[idx, idx] %*% a))
se <- sqrt(diag(V))

res <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(term = "cumulative_response", estimate = cum, se = cse, n_obs = N),
    list(term = "lag_1", estimate = unname(b[2]), se = unname(se[2]), n_obs = N),
    list(term = "lag_15", estimate = unname(b[16]), se = unname(se[16]), n_obs = N)
  ),
  method_metadata = list(estimator = "OLS distributed lag",
                         vcov = "Newey-West HAC, Bartlett, maxlag 15, scaled N/(N-16)"),
  diagnostics = setNames(list(), character(0))
)
writeLines(toJSON(res, auto_unbox = TRUE, digits = 12, pretty = TRUE), "result.json")
