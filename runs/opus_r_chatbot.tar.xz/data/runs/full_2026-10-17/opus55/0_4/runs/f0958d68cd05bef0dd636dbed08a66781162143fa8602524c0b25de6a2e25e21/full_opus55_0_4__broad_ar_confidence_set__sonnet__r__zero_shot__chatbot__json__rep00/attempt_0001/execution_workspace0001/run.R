library(jsonlite)
d <- read.csv("input.csv")
n <- nrow(d)
y <- d$y; e <- d$endog
W <- cbind(1, d$x)
Z <- cbind(1, d$x, d$z1, d$z2)
MW <- diag(n) - W %*% solve(crossprod(W), t(W))
MZ <- diag(n) - Z %*% solve(crossprod(Z), t(Z))
cv <- qf(0.95, 2, n - 4)
A <- (n - 4) / 2 * (MW - MZ) - cv * MZ
qa <- as.numeric(t(e) %*% A %*% e)
qb <- as.numeric(-2 * t(e) %*% A %*% y)
qc <- as.numeric(t(y) %*% A %*% y)
arF <- function(b) {
  u <- y - b * e
  rr <- sum(lm.fit(W, u)$residuals^2)
  ru <- sum(lm.fit(Z, u)$residuals^2)
  ((rr - ru) / 2) / (ru / (n - 4))
}
disc <- qb^2 - 4 * qa * qc
if (disc > 0) {
  r <- sort(c((-qb - sqrt(disc)) / (2 * qa), (-qb + sqrt(disc)) / (2 * qa)))
  lo <- r[1]; hi <- r[2]
} else {
  lo <- NA; hi <- NA
}
unb <- as.numeric(qa < 0 || (qa == 0))
acc0 <- as.numeric(arF(0) <= cv)
f1 <- arF(1)
mk <- function(t, v) list(term = t, estimate = v, se = NULL, n_obs = n)
res <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = list(
    mk("boundary_low", lo), mk("boundary_high", hi),
    mk("accepts_zero", acc0), mk("unbounded", unb),
    mk("ar_f_at_one", f1)
  ),
  method_metadata = list(estimator = "Anderson-Rubin test inversion (analytic quadratic)",
                         vcov = "homoskedastic F"),
  diagnostics = list(crit = cv, quad_a = qa, quad_b = qb, quad_c = qc)
)
writeLines(toJSON(res, auto_unbox = TRUE, null = "null", na = "null", digits = 12, pretty = TRUE),
           "result.json")
