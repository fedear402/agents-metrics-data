suppressPackageStartupMessages(library(jsonlite))

df <- read.csv("input.csv")
df <- df[!is.na(df$score) & !is.na(df$participated) & !is.na(df$earnings), ]
s <- df[abs(df$score) < 1, ]
n <- nrow(s)

w <- 1 - abs(s$score)
D <- as.numeric(s$score >= 0)
X <- cbind(1, D, s$score, D * s$score)
y <- s$earnings
d <- s$participated

XtWX_inv <- solve(crossprod(X, X * w))
by <- XtWX_inv %*% crossprod(X, w * y)
bd <- XtWX_inv %*% crossprod(X, w * d)
ey <- as.vector(y - X %*% by)
ed <- as.vector(d - X %*% bd)

sand <- function(e1, e2) {
  meat <- crossprod(X * (w * e1), X * (w * e2))
  XtWX_inv %*% meat %*% XtWX_inv
}
Vyy <- sand(ey, ey)[2, 2]
Vdd <- sand(ed, ed)[2, 2]
Vyd <- sand(ey, ed)[2, 2]

rf <- by[2]
fs <- bd[2]
te <- rf / fs

g <- c(1 / fs, -rf / fs^2)
V <- matrix(c(Vyy, Vyd, Vyd, Vdd), 2, 2)
se_te <- sqrt(as.numeric(t(g) %*% V %*% g))

res <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = te, se = se_te, n_obs = n),
    list(term = "reduced_form", estimate = rf, se = sqrt(Vyy), n_obs = n),
    list(term = "first_stage", estimate = fs, se = sqrt(Vdd), n_obs = n)
  ),
  method_metadata = list(
    estimator = "fuzzy RD, local linear, triangular kernel, h=1, ratio of WLS discontinuities",
    vcov = "HC0 joint sandwich, delta method with covariance"
  ),
  diagnostics = list(cov_rf_fs = Vyd, n_left = sum(D == 0), n_right = sum(D == 1))
)

write_json(res, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE)
