suppressPackageStartupMessages({library(jsonlite)})
d <- read.csv("input.csv")
d$region_id <- as.character(d$region_id); d$industry_id <- as.character(d$industry_id)
reg <- d[!duplicated(d$region_id), c("region_id","region_weight","x","y")]
reg$e <- reg$region_weight / sum(reg$region_weight)
d$share_shock <- d$share * d$shock
z <- tapply(d$share_shock, d$region_id, sum)
reg$z <- as.numeric(z[reg$region_id])
e <- reg$e
wm <- function(v) sum(e*v)/sum(e)
reg$y0 <- reg$y - wm(reg$y); reg$x0 <- reg$x - wm(reg$x); reg$z0 <- reg$z - wm(reg$z)

# regional weighted 2SLS and first stage
zc <- reg$z0; b_iv <- sum(e*zc*reg$y0)/sum(e*zc*reg$x0)
b_fs <- sum(e*zc*reg$x0)/sum(e*zc*zc)

# shock-level aggregation
d$e <- reg$e[match(d$region_id, reg$region_id)]
d$y0 <- reg$y0[match(d$region_id, reg$region_id)]
d$x0 <- reg$x0[match(d$region_id, reg$region_id)]
d$z0 <- reg$z0[match(d$region_id, reg$region_id)]
d$w <- d$e * d$share
inds <- sort(unique(d$industry_id))
s <- as.numeric(tapply(d$w, d$industry_id, sum)[inds])
agg <- function(v) as.numeric(tapply(d$w*v, d$industry_id, sum)[inds]) / s
ybar <- agg(d$y0); xbar <- agg(d$x0); zbar <- agg(d$z0)
g <- as.numeric(tapply(d$shock, d$industry_id, function(a) a[1])[inds])
keep <- s > 0
s <- s[keep]; ybar <- ybar[keep]; xbar <- xbar[keep]; zbar <- zbar[keep]; g <- g[keep]
N <- length(s)

wiv <- function(yv, xv, gv, w) {
  X <- cbind(1, xv); Z <- cbind(1, gv); W <- w
  A <- t(Z) %*% (W*X); b <- solve(A, t(Z) %*% (W*yv))
  u <- as.numeric(yv - X %*% b)
  Ai <- solve(A)
  meat <- t(Z) %*% (Z * (W^2 * u^2))
  V <- Ai %*% meat %*% t(Ai) * N/(N-2)
  list(b = as.numeric(b), se = sqrt(diag(V)))
}
r1 <- wiv(ybar, xbar, g, s)
r2 <- wiv(xbar, zbar, g, s)
eff_shocks <- 1/sum(s^2)

res <- list(
  task_id = "applied_shift_share", platform = "r",
  estimates = list(
    list(term="effect", estimate=b_iv, se=r1$se[2], n_obs=N),
    list(term="first_stage", estimate=b_fs, se=r2$se[2], n_obs=N),
    list(term="effective_shocks", estimate=eff_shocks, se=NULL, n_obs=N)
  ),
  method_metadata = list(estimator="weighted shift-share 2SLS with BHJ shock-level equivalence",
                         vcov="shock-level HC1 (N/(N-2)), structural IV residuals, analytic weights s_n"),
  diagnostics = list(shock_level_effect=r1$b[2], shock_level_first_stage=r2$b[2], n_regions=nrow(reg))
)
writeLines(toJSON(res, auto_unbox=TRUE, digits=NA, null="null", pretty=TRUE), "result.json")
