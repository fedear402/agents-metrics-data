suppressPackageStartupMessages(library(jsonlite))

cw   <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
tr   <- read.csv("trade.csv", stringsAsFactors = FALSE)
ar   <- read.csv("areas.csv", stringsAsFactors = FALSE)
em   <- read.csv("employment.csv", stringsAsFactors = FALSE)
outc <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

cw$code <- as.character(cw$code); tr$code <- as.character(tr$code)
cw$industry <- as.character(cw$industry); em$industry <- as.character(em$industry)
ar$vintage <- trimws(tolower(ar$vintage)); em$vintage <- trimws(tolower(em$vintage))

trj <- merge(tr, cw, by = "code")
tri <- aggregate(cbind(us_change, other_change) ~ period + industry, data = trj, FUN = sum)
pp <- aggregate(cbind(price_index, years) ~ period, data = trj, FUN = function(v) v[1])

inds <- sort(unique(cw$industry))
ap <- unique(ar[, c("area", "period")])

build <- function(vint, chcol) {
  grid <- merge(ap, data.frame(industry = inds, stringsAsFactors = FALSE))
  e <- em[em$vintage == vint, c("area", "period", "industry", "employment")]
  e <- aggregate(employment ~ area + period + industry, data = e, FUN = sum)
  g <- merge(grid, e, by = c("area", "period", "industry"), all.x = TRUE)
  g$employment[is.na(g$employment)] <- 0
  nat <- aggregate(employment ~ period + industry, data = g, FUN = sum)
  names(nat)[3] <- "nat"
  g <- merge(g, nat, by = c("period", "industry"))
  tot <- ar[ar$vintage == vint, c("area", "period", "total_employment")]
  g <- merge(g, tot, by = c("area", "period"))
  g <- merge(g, tri[, c("period", "industry", chcol)], by = c("period", "industry"))
  g <- merge(g, pp, by = "period")
  g$term <- (g$employment / g$total_employment) * (g[[chcol]] / g$nat) /
    (g$price_index / 100) / 1000 * (10 / g$years)
  aggregate(term ~ area + period, data = g, FUN = sum)
}

xd <- build("base", "us_change");   names(xd)[3] <- "x"
zd <- build("early", "other_change"); names(zd)[3] <- "z"
wd <- ar[ar$vintage == "base", c("area", "period", "population")]

d <- merge(outc, xd, by = c("area", "period"))
d <- merge(d, zd, by = c("area", "period"))
d <- merge(d, wd, by = c("area", "period"))
d <- d[complete.cases(d[, c("change_pp", "period", "control", "x", "z", "population")]), ]

X <- cbind(1, as.numeric(d$period), d$control, d$x)
Z <- cbind(1, as.numeric(d$period), d$control, d$z)
y <- d$change_pp
w <- d$population
XWZ <- t(X) %*% (Z * w)
ZWZi <- solve(t(Z) %*% (Z * w))
ZWy <- t(Z) %*% (y * w)
A <- XWZ %*% ZWZi
beta <- solve(A %*% t(XWZ), A %*% ZWy)
iv_slope <- beta[4]

n <- nrow(d)
g0 <- function(df, col, p) df[[col]][df$area == 0 & df$period == p][1]
x00 <- g0(d, "x", 0); x01 <- g0(d, "x", 1); z00 <- g0(d, "z", 0)

mk <- function(t, e) list(term = t, estimate = unname(e), se = NULL, n_obs = as.integer(n))
res <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = list(
    mk("iv_slope", iv_slope),
    mk("exposure_area0_period0", x00),
    mk("exposure_area0_period1", x01),
    mk("instrument_area0_period0", z00)
  ),
  method_metadata = list(estimator = "weighted 2SLS", weights = "base-vintage population",
                         instruments = c("intercept", "period", "control", "z")),
  diagnostics = list(n_obs = as.integer(n), coefficients = as.numeric(beta))
)
write_json(res, "result.json", auto_unbox = TRUE, digits = NA, null = "null", pretty = TRUE)
