suppressWarnings(suppressMessages(library(jsonlite)))

df <- read.csv("input.csv")
df <- df[is.finite(df$score) & is.finite(df$participated) & is.finite(df$earnings), ]
d <- df[abs(df$score) < 1, ]
n <- nrow(d)

x <- d$score
D <- as.numeric(x >= 0)
w <- 1 - abs(x)
X <- cbind(1, D, x, D * x)
y <- d$earnings
t <- d$participated

XtWX <- crossprod(X, X * w)
A <- solve(XtWX)
by <- A %*% crossprod(X, w * y)
bt <- A %*% crossprod(X, w * t)
ey <- as.vector(y - X %*% by)
et <- as.vector(t - X %*% bt)

# Influence-style scores for the jump coefficient (row 2)
a <- A[2, , drop = FALSE]
sy <- as.vector((X * (w * ey)) %*% t(a))
st <- as.vector((X * (w * et)) %*% t(a))
v_rr <- sum(sy^2)
v_ff <- sum(st^2)
c_rf <- sum(sy * st)

rf <- by[2]
fs <- bt[2]
te <- rf / fs
g <- c(1 / fs, -rf / fs^2)
V <- matrix(c(v_rr, c_rf, c_rf, v_ff), 2, 2)
se_te <- sqrt(as.numeric(t(g) %*% V %*% g))

res <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = te, se = se_te, n_obs = n),
    list(term = "reduced_form", estimate = rf, se = sqrt(v_rr), n_obs = n),
    list(term = "first_stage", estimate = fs, se = sqrt(v_ff), n_obs = n)
  ),
  method_metadata = list(
    estimator = "fuzzy RD, local linear, triangular kernel, bandwidth 1, cutoff 0, ratio of WLS jumps",
    vcov = "HC0 joint sandwich, delta method with covariance, no bias correction"
  ),
  diagnostics = list(cov_rf_fs = c_rf, n_left = sum(D == 0), n_right = sum(D == 1))
)
write(toJSON(res, auto_unbox = TRUE, digits = NA, pretty = TRUE), "result.json")
