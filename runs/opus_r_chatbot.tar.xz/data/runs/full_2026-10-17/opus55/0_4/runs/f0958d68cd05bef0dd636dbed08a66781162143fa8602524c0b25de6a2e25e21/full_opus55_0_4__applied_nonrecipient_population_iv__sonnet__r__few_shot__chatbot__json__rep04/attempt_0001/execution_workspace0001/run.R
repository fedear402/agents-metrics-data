suppressPackageStartupMessages(library(jsonlite))

hh <- read.csv("households.csv")
census <- read.csv("census.csv")

d <- subset(hh, recipient == 0)
d <- d[complete.cases(d[, c("eligible","dose","instrument","baseline","outcome","weight")]), ]
n <- nrow(d)

e <- d$eligible
ne <- 1 - e
C <- cbind(ne, e, d$baseline * ne, d$baseline * e)
X <- cbind(C, d$dose * ne, d$dose * e)
Z <- cbind(C, d$instrument * ne, d$instrument * e)
sw <- sqrt(d$weight)
Xw <- X * sw; Zw <- Z * sw; yw <- d$outcome * sw
fitted <- qr.fitted(qr(Zw), Xw)
coef <- as.numeric(qr.coef(qr(fitted), yw))
slopes <- coef[5:6]

mdose <- sapply(0:1, function(g) {
  a <- d[d$eligible == g, ]
  weighted.mean(a$dose, a$weight)
})
effect <- slopes * mdose
pop <- census$nonrecipient_population[match(0:1, census$eligible)]
pop_eff <- weighted.mean(effect, pop)

est <- list(
  list(term = "ineligible_effect", estimate = effect[1], se = NA, n_obs = as.integer(n)),
  list(term = "eligible_nonrecipient_effect", estimate = effect[2], se = NA, n_obs = as.integer(n)),
  list(term = "population_effect", estimate = pop_eff, se = NA, n_obs = as.integer(n))
)

res <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = est,
  method_metadata = list(
    estimator = "weighted 2SLS, group-interacted, no common intercept",
    weights = "weight",
    counterfactual = "dose set to zero for all retained nonrecipient households",
    aggregation = "census nonrecipient_population weights"
  ),
  diagnostics = list(
    n_obs = as.integer(n),
    n_ineligible = as.integer(sum(e == 0)),
    n_eligible = as.integer(sum(e == 1)),
    dose_slope_ineligible = slopes[1],
    dose_slope_eligible = slopes[2],
    weighted_mean_dose_ineligible = mdose[1],
    weighted_mean_dose_eligible = mdose[2],
    census_weights = as.list(setNames(pop, c("ineligible","eligible")))
  )
)

write_json(res, "result.json", auto_unbox = TRUE, digits = NA, na = "null", pretty = TRUE)
