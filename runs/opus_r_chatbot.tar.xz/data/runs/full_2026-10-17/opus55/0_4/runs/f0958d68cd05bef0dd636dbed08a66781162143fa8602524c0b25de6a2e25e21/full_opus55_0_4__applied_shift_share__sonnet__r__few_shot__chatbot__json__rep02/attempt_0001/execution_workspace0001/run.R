library(jsonlite)
d <- read.csv("input.csv", stringsAsFactors = FALSE)
d$region_id <- as.character(d$region_id)
d$industry_id <- as.character(d$industry_id)
regions <- sort(unique(d$region_id))
industries <- sort(unique(d$industry_id))
R <- length(regions); N <- length(industries)
S <- matrix(0, R, N, dimnames = list(regions, industries))
agg <- aggregate(share ~ region_id + industry_id, data = d, FUN = sum)
S[cbind(match(agg$region_id, regions), match(agg$industry_id, industries))] <- agg$share
ri <- d[!duplicated(d$region_id), ]
ri <- ri[match(regions, ri$region_id), ]
ii <- d[!duplicated(d$industry_id), ]
ii <- ii[match(industries, ii$industry_id), ]
shock <- as.numeric(ii$shock)
e <- ri$region_weight / sum(ri$region_weight)
x <- ri$x; y <- ri$y
z <- drop(S %*% shock)
reg <- cbind(y, x, z)
cen <- sweep(reg, 2, drop(e %*% reg))
s <- drop(e %*% S)
keep <- s > 0
aggm <- (t(S) %*% (e * cen))
aggm <- aggm[keep, , drop = FALSE] / s[keep]
sk <- s[keep]; shk <- shock[keep]; Nk <- sum(keep)
shock_iv <- function(dep, endo) {
  X <- cbind(1, endo); Z <- cbind(1, shk)
  cross <- crossprod(Z, sk * X)
  b <- solve(cross, crossprod(Z, sk * dep))
  res <- drop(dep - X %*% b)
  sc <- Z * (sk * res)
  inv <- solve(cross)
  V <- Nk / (Nk - 2) * inv %*% crossprod(sc) %*% t(inv)
  c(b[2], sqrt(V[2, 2]))
}
eff <- shock_iv(aggm[, 1], aggm[, 2])
fs <- shock_iv(aggm[, 2], aggm[, 3])
reg_eff <- sum(e * cen[, 3] * cen[, 1]) / sum(e * cen[, 3] * cen[, 2])
reg_fs <- sum(e * cen[, 3] * cen[, 2]) / sum(e * cen[, 3]^2)
eff_sh <- 1 / sum(s^2)
row <- function(t, est, se, n) list(term = t, estimate = unname(as.numeric(est)),
  se = if (is.null(se)) NULL else unname(as.numeric(se)), n_obs = as.integer(n))
out <- list(task_id = "applied_shift_share", platform = "r",
  estimates = list(row("effect", reg_eff, eff[2], Nk),
                   row("first_stage", reg_fs, fs[2], Nk),
                   row("effective_shocks", eff_sh, NULL, Nk)),
  method_metadata = list(estimator = "weighted 2SLS with BHJ shock-level aggregation",
                         vcov = "shock-level HC1 (N/(N-2)), structural IV residuals"),
  diagnostics = list(shock_level_effect = unname(eff[1]), shock_level_first_stage = unname(fs[1]),
                     n_regions = R))
write_json(out, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
