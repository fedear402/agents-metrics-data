d <- read.csv('input.csv')
cohorts <- c(3,5,7)
ests <- list(); atts <- numeric(0); ws <- numeric(0); ns <- numeric(0)
for (c in cohorts) {
  s <- d[d$time >= c-2 & d$time <= c+2 & (d$g == c | d$g == 0 | d$g > c+2), ]
  cnt <- table(s$id)
  keep <- names(cnt)[cnt == 5]
  s <- s[as.character(s$id) %in% keep, ]
  s$did <- as.numeric(s$g == c & s$time >= c)
  # lm includes an intercept with the omitted unit and time categories.
  fit <- lm(y ~ did + factor(id) + factor(time), data = s)
  est <- unname(coef(fit)['did'])
  atts <- c(atts, est)
  ws <- c(ws, length(unique(s$id[s$g == c])))
  ns <- c(ns, nrow(s))
  ests[[length(ests)+1]] <- list(term=paste0('att_g',c), estimate=est, se=NULL, n_obs=nrow(s))
}
ests[[length(ests)+1]] <- list(term='att_weighted', estimate=sum(atts*ws)/sum(ws), se=NULL, n_obs=sum(ns))
out <- list(task_id='broad_cohort_stack', platform='r', estimates=ests,
            method_metadata=setNames(list(),character(0)), diagnostics=setNames(list(),character(0)))
jsonlite::write_json(out,'result.json',auto_unbox=TRUE,null='null',digits=16)
