library(jsonlite)
d <- read.csv("input.csv")
d <- d[is.finite(d$score) & is.finite(d$participated) & is.finite(d$earnings), ]
d <- d[abs(d$score) < 1, ]
n <- nrow(d)
w <- 1 - abs(d$score)
right <- as.numeric(d$score >= 0)
X <- cbind(1, right, d$score, right * d$score)
Y <- cbind(d$earnings, d$participated)
bread <- solve(crossprod(X, w * X))
coefficients <- bread %*% crossprod(X, w * Y)
residuals <- Y - X %*% coefficients
contrast <- c(0, 1, 0, 0)
jumps <- drop(contrast %*% coefficients)
loading <- w * drop(X %*% bread %*% contrast)
influence <- loading * residuals
joint <- crossprod(influence)
gradient <- c(1 / jumps[2], -jumps[1] / jumps[2]^2)
te <- jumps[1] / jumps[2]
te_se <- sqrt(drop(t(gradient) %*% joint %*% gradient))
row <- function(term, est, se) list(term = term, estimate = unname(as.numeric(est)),
                                    se = unname(as.numeric(se)), n_obs = as.integer(n))
out <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    row("treatment_effect", te, te_se),
    row("reduced_form", jumps[1], sqrt(joint[1, 1])),
    row("first_stage", jumps[2], sqrt(joint[2, 2]))
  ),
  method_metadata = list(estimator = "fuzzy RD, local linear, triangular kernel, h=1, Wald ratio",
                         vcov = "HC0 joint influence, delta method"),
  diagnostics = list(cov_rf_fs = joint[1, 2])
)
write_json(out, "result.json", auto_unbox = TRUE, digits = 16, pretty = TRUE, null = "null")
