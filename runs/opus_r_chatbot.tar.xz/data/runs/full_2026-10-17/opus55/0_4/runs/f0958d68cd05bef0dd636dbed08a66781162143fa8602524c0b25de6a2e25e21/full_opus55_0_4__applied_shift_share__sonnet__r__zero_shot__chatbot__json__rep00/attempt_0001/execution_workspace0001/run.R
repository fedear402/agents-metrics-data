suppressPackageStartupMessages(library(jsonlite))
d <- read.csv("input.csv", stringsAsFactors = FALSE)
d$region_id <- as.character(d$region_id)
d$industry_id <- as.character(d$industry_id)

reg <- d[!duplicated(d$region_id), c("region_id", "region_weight", "x", "y")]
reg$e <- reg$region_weight / sum(reg$region_weight)
zr <- tapply(d$share * d$shock, d$region_id, sum)
reg$z <- as.numeric(zr[reg$region_id])

wiv <- function(yv, xv, zv, w) {
  X <- cbind(1, xv); Z <- cbind(1, zv)
  b <- solve(t(Z) %*% (w * X), t(Z) %*% (w * yv))
  list(b = b, X = X, Z = Z)
}

e <- reg$e
r_iv <- wiv(reg$y, reg$x, reg$z, e)
beta <- r_iv$b[2]
r_fs <- wiv(reg$x, reg$z, reg$z, e)
pi_hat <- r_fs$b[2]

wm <- function(v) sum(e * v) / sum(e)
reg$y0 <- reg$y - wm(reg$y)
reg$x0 <- reg$x - wm(reg$x)
reg$z0 <- reg$z - wm(reg$z)

m <- match(d$region_id, reg$region_id)
d$e <- reg$e[m]
d$es <- d$e * d$share
inds <- sort(unique(d$industry_id))
s_n <- as.numeric(tapply(d$es, d$industry_id, sum)[inds])
agg <- function(v) as.numeric(tapply(d$es * v[m], d$industry_id, sum)[inds]) / s_n
ybar <- agg(reg$y0); xbar <- agg(reg$x0); zbar <- agg(reg$z0)
g <- as.numeric(tapply(d$shock, d$industry_id, mean)[inds])
N <- length(inds)

shock_iv <- function(yv, xv, gv, w) {
  X <- cbind(1, xv); Z <- cbind(1, gv)
  A <- t(Z) %*% (w * X)
  b <- solve(A, t(Z) %*% (w * yv))
  u <- as.numeric(yv - X %*% b)
  Ai <- solve(A)
  meat <- t(Z) %*% (Z * (w * u)^2)
  V <- Ai %*% meat %*% t(Ai) * N / (N - 2)
  list(b = as.numeric(b), se = sqrt(diag(V)))
}

ok <- s_n > 0
sh_e <- shock_iv(ybar[ok], xbar[ok], g[ok], s_n[ok])
sh_f <- shock_iv(xbar[ok], zbar[ok], g[ok], s_n[ok])
Nu <- sum(ok)
eff <- 1 / sum(s_n^2)

res <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = beta, se = sh_e$se[2], n_obs = Nu),
    list(term = "first_stage", estimate = pi_hat, se = sh_f$se[2], n_obs = Nu),
    list(term = "effective_shocks", estimate = eff, se = NULL, n_obs = Nu)
  ),
  method_metadata = list(
    estimator = "Weighted regional 2SLS with shift-share instrument; BHJ shock-level equivalent IV",
    vcov = "Shock-level HC1 (N/(N-2)), structural IV residuals, analytic weights s_n"
  ),
  diagnostics = list(
    shock_level_effect_slope = sh_e$b[2],
    shock_level_first_stage_slope = sh_f$b[2],
    n_regions = nrow(reg), n_industries = N
  )
)
writeLines(toJSON(res, auto_unbox = TRUE, digits = NA, null = "null", pretty = TRUE), "result.json")
