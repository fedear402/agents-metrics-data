d <- read.csv("input.csv")
cohorts <- c(3, 5, 7)
res <- list()
coefs <- numeric(0); ns <- numeric(0); wts <- numeric(0)
for (c in cohorts) {
  win <- (c - 2):(c + 2)
  s <- d[d$time %in% win & (d$g == c | d$g == 0 | d$g > c + 2), ]
  cnt <- table(s$id)
  keep <- names(cnt)[cnt == length(win)]
  s <- s[as.character(s$id) %in% keep, ]
  s$did <- as.numeric(s$g == c & s$time >= c)
  fit <- lm(y ~ did + factor(id) + factor(time), data = s)
  est <- unname(coef(fit)["did"])
  coefs <- c(coefs, est); ns <- c(ns, nrow(s))
  wts <- c(wts, length(unique(s$id[s$g == c])))
  res[[length(res) + 1]] <- list(term = paste0("att_g", c), estimate = est,
                                 se = NULL, n_obs = nrow(s))
}
res[[length(res) + 1]] <- list(term = "att_weighted",
                               estimate = sum(coefs * wts) / sum(wts),
                               se = NULL, n_obs = sum(ns))
out <- list(task_id = "broad_cohort_stack", platform = "r", estimates = res,
            method_metadata = structure(list(), names = character(0)),
            diagnostics = list(treated_units = setNames(as.list(wts), paste0("g", cohorts))))
jsonlite::write_json(out, "result.json", auto_unbox = TRUE, null = "null", digits = 16)
