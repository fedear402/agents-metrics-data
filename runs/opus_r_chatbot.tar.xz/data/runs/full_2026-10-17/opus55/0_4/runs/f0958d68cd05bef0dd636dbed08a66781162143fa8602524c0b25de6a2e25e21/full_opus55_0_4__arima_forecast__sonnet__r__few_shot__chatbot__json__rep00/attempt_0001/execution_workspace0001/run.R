library(jsonlite)
d <- read.csv("./input.csv")
d <- d[order(d$t), ]
y <- as.numeric(d$y)
y <- y[!is.na(y)]
fit <- tryCatch(arima(y, order = c(1, 1, 1), method = "ML"),
                error = function(e) arima(y, order = c(1, 1, 1), method = "CSS-ML"))
p <- predict(fit, n.ahead = 1)
fc <- as.numeric(p$pred[1])
se <- as.numeric(p$se[1])
z <- qnorm(0.975)
lo <- fc - z * se
hi <- fc + z * se
n <- length(y)
out <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = list(
    list(term = "forecast", estimate = fc, se = se, n_obs = n),
    list(term = "lower_95", estimate = lo, se = NA, n_obs = n),
    list(term = "upper_95", estimate = hi, se = NA, n_obs = n)
  ),
  method_metadata = list(estimator = "ARIMA(1,1,1) by exact ML (stats::arima), no drift",
                         vcov = "ML (inverse Hessian); Gaussian prediction interval"),
  diagnostics = structure(list(), names = character(0))
)
write_json(out, "result.json", auto_unbox = TRUE, digits = NA, na = "null")
