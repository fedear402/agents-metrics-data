suppressWarnings(suppressMessages({
  have_json <- requireNamespace("jsonlite", quietly = TRUE)
}))

d <- read.csv("./input.csv")
d <- d[order(d$t), ]
y <- as.numeric(d$y)
n <- length(y)

fit <- arima(y, order = c(1, 1, 1), include.mean = FALSE, method = "ML")
p <- predict(fit, n.ahead = 1)
fc <- as.numeric(p$pred[1])
se <- as.numeric(p$se[1])
z <- qnorm(0.975)
lo <- fc - z * se
hi <- fc + z * se

co <- coef(fit)
res <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = list(
    list(term = "forecast", estimate = fc, se = se, n_obs = n),
    list(term = "lower_95", estimate = lo, se = NULL, n_obs = n),
    list(term = "upper_95", estimate = hi, se = NULL, n_obs = n)
  ),
  method_metadata = list(
    estimator = "ARIMA(1,1,1) exact Gaussian maximum likelihood (stats::arima, method='ML'), no constant/drift",
    vcov = "model-based forecast standard error; normal 95% interval"
  ),
  diagnostics = list(
    ar1 = unname(co["ar1"]),
    ma1 = unname(co["ma1"]),
    sigma2 = fit$sigma2,
    loglik = fit$loglik,
    aic = fit$aic,
    forecast_t = max(d$t) + 1
  )
)

if (have_json) {
  txt <- jsonlite::toJSON(res, auto_unbox = TRUE, digits = NA, null = "null", pretty = TRUE)
  writeLines(txt, "result.json")
} else {
  f <- function(x) formatC(x, digits = 15, format = "g")
  txt <- sprintf('{"task_id":"arima_forecast","platform":"r","estimates":[{"term":"forecast","estimate":%s,"se":%s,"n_obs":%d},{"term":"lower_95","estimate":%s,"se":null,"n_obs":%d},{"term":"upper_95","estimate":%s,"se":null,"n_obs":%d}],"method_metadata":{"estimator":"ARIMA(1,1,1) ML, no constant","vcov":"model-based forecast SE"},"diagnostics":{}}',
                 f(fc), f(se), n, f(lo), n, f(hi), n)
  writeLines(txt, "result.json")
}
