d <- read.csv("input.csv")
d <- d[complete.cases(d[, c("y","x","z")]), ]
X <- cbind(1, d$x, d$z)
y <- d$y
n <- nrow(X)
Y1 <- as.numeric(y == 1); Y2 <- as.numeric(y == 2)
nll <- function(b) {
  e1 <- X %*% b[1:3]; e2 <- X %*% b[4:6]
  m <- pmax(0, e1, e2)
  lse <- m + log(exp(-m) + exp(e1 - m) + exp(e2 - m))
  -sum(Y1 * e1 + Y2 * e2 - lse)
}
gr <- function(b) {
  e1 <- X %*% b[1:3]; e2 <- X %*% b[4:6]
  den <- 1 + exp(e1) + exp(e2)
  p1 <- exp(e1)/den; p2 <- exp(e2)/den
  -c(colSums(X * as.vector(Y1 - p1)), colSums(X * as.vector(Y2 - p2)))
}
fit <- optim(rep(0, 6), nll, gr, method = "BFGS",
             control = list(maxit = 10000, reltol = 1e-14))
b <- fit$par
for (i in 1:50) {
  e1 <- X %*% b[1:3]; e2 <- X %*% b[4:6]
  den <- 1 + exp(e1) + exp(e2)
  p1 <- as.vector(exp(e1)/den); p2 <- as.vector(exp(e2)/den)
  H11 <- t(X) %*% (X * (p1 * (1 - p1)))
  H22 <- t(X) %*% (X * (p2 * (1 - p2)))
  H12 <- -t(X) %*% (X * (p1 * p2))
  I <- rbind(cbind(H11, H12), cbind(t(H12), H22))
  step <- solve(I, -gr(b))
  b <- b + step
  if (max(abs(step)) < 1e-12) break
}
e1 <- X %*% b[1:3]; e2 <- X %*% b[4:6]
den <- 1 + exp(e1) + exp(e2)
p1 <- as.vector(exp(e1)/den); p2 <- as.vector(exp(e2)/den)
H11 <- t(X) %*% (X * (p1 * (1 - p1)))
H22 <- t(X) %*% (X * (p2 * (1 - p2)))
H12 <- -t(X) %*% (X * (p1 * p2))
I <- rbind(cbind(H11, H12), cbind(t(H12), H22))
V <- solve(I)
se <- sqrt(diag(V))
pc2 <- exp(b[4]) / (1 + exp(b[1]) + exp(b[4]))
N <- nrow(read.csv("input.csv"))
est <- list(
  list(term = "x_cat1", estimate = b[2], se = se[2], n_obs = N),
  list(term = "z_cat1", estimate = b[3], se = se[3], n_obs = N),
  list(term = "x_cat2", estimate = b[5], se = se[5], n_obs = N),
  list(term = "z_cat2", estimate = b[6], se = se[6], n_obs = N),
  list(term = "prob_cat2_zero", estimate = pc2, se = NA, n_obs = N)
)
res <- list(task_id = "broad_multinomial_logit", platform = "r",
            estimates = est,
            method_metadata = list(estimator = "multinomial logit MLE (base outcome 0)",
                                   vcov = "inverse observed information (OIM)"),
            diagnostics = list(logLik = -nll(b), converged = TRUE, n_used = n))
jsonlite::write_json(res, "result.json", auto_unbox = TRUE, digits = NA, na = "null", pretty = TRUE)
