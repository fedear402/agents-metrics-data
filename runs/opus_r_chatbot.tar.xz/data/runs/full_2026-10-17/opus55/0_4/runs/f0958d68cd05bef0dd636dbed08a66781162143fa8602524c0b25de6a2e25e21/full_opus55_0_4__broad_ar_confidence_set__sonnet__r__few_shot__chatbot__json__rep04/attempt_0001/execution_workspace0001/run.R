d <- read.csv("input.csv")
n <- nrow(d)
ry <- residuals(lm(y ~ x, data = d)); rd <- residuals(lm(endog ~ x, data = d))
fy <- lm(y ~ x + z1 + z2, data = d); fd <- lm(endog ~ x + z1 + z2, data = d)
uy <- residuals(fy); ud <- residuals(fd)
q <- 2L; df <- n - 4L
critical <- qf(.95, q, df)
k <- q * critical / df
A <- sum(rd^2) - (1 + k) * sum(ud^2)
B <- -2 * (sum(ry * rd) - (1 + k) * sum(uy * ud))
C <- sum(ry^2) - (1 + k) * sum(uy^2)
disc <- B^2 - 4 * A * C
stopifnot(abs(A) > 1e-12, disc > 0)
bounds <- sort(c((-B - sqrt(disc)) / (2 * A), (-B + sqrt(disc)) / (2 * A)))
accepts <- function(b) A * b^2 + B * b + C <= 0
unbounded <- as.integer(A < 0)
arF <- function(b) {
  t <- d$y - b * d$endog
  r <- lm(t ~ x, data = d); f <- lm(t ~ x + z1 + z2, data = d)
  ((deviance(r) - deviance(f)) / q) / (deviance(f) / df)
}
for (b in bounds) stopifnot(abs(arF(b) - critical) < 1e-6)
mk <- function(term, est) list(term = term, estimate = unname(est), se = NULL, n_obs = n)
res <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = list(
    mk("boundary_low", bounds[1]),
    mk("boundary_high", bounds[2]),
    mk("accepts_zero", as.numeric(accepts(0))),
    mk("unbounded", as.numeric(unbounded)),
    mk("ar_f_at_one", arF(1))
  ),
  method_metadata = list(estimator = "Anderson-Rubin test inversion (quadratic, analytic)",
                         vcov = "homoskedastic joint F"),
  diagnostics = list(A = A, B = B, C = C, critical = critical)
)
jsonlite::write_json(res, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
