library(jsonlite)
d <- read.csv("./input.csv", stringsAsFactors = FALSE)
d <- d[!is.na(d$y) & !is.na(d$group) & d$group != "", ]
d$y <- as.numeric(d$y)
d <- d[!is.na(d$y), ]
d$group <- factor(d$group)
n <- nrow(d)
fit <- aov(y ~ group, data = d)
tab <- summary(fit)[[1]]
Fv <- tab[1, "F value"]
df1 <- tab[1, "Df"]
df2 <- tab[2, "Df"]
pv <- tab[1, "Pr(>F)"]
out <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = list(
    list(term = "F", estimate = unname(Fv), se = NA, n_obs = n),
    list(term = "df_num", estimate = unname(as.numeric(df1)), se = NA, n_obs = n),
    list(term = "df_den", estimate = unname(as.numeric(df2)), se = NA, n_obs = n),
    list(term = "p_value", estimate = unname(pv), se = NA, n_obs = n)
  ),
  method_metadata = list(estimator = "One-way ANOVA (aov, classical F test)",
                         vcov = "none"),
  diagnostics = structure(list(), names = character(0))
)
write_json(out, "result.json", auto_unbox = TRUE, digits = NA, na = "null")
