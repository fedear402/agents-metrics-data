suppressPackageStartupMessages(library(jsonlite))

d <- read.csv("input.csv", stringsAsFactors = FALSE)

# Regional data (one row per region)
reg <- d[!duplicated(d$region_id), c("region_id", "region_weight", "x", "y")]
reg$e <- reg$region_weight / sum(reg$region_weight)

# Shift-share instrument
d$ss <- d$share * d$shock
zr <- tapply(d$ss, d$region_id, sum)
reg$z <- as.numeric(zr[as.character(reg$region_id)])

# Weighted IV helper: y on [1, x], instrument [1, z], weights w; HC1 with N/(N-k)
wiv <- function(y, x, z, w) {
  X <- cbind(1, x); Z <- cbind(1, z)
  A <- crossprod(Z, w * X)
  b <- solve(A, crossprod(Z, w * y))
  u <- as.numeric(y - X %*% b)
  Ainv <- solve(A)
  meat <- crossprod(Z * (w * u))
  n <- length(y)
  V <- Ainv %*% meat %*% t(Ainv) * n / (n - 2)
  list(b = as.numeric(b), se = sqrt(diag(V)))
}

# Regional estimates
reg_iv <- wiv(reg$y, reg$x, reg$z, reg$e)
reg_fs <- wiv(reg$x, reg$z, reg$z, reg$e)

# Demean with e-weighted means
wm <- function(v) sum(reg$e * v)
reg$y0 <- reg$y - wm(reg$y)
reg$x0 <- reg$x - wm(reg$x)
reg$z0 <- reg$z - wm(reg$z)

m <- match(d$region_id, reg$region_id)
d$es <- reg$e[m] * d$share
d$y0 <- reg$y0[m]; d$x0 <- reg$x0[m]; d$z0 <- reg$z0[m]

ind <- sort(unique(d$industry_id))
key <- as.character(ind)
s_n <- as.numeric(tapply(d$es, d$industry_id, sum)[key])
ybar <- as.numeric(tapply(d$es * d$y0, d$industry_id, sum)[key]) / s_n
xbar <- as.numeric(tapply(d$es * d$x0, d$industry_id, sum)[key]) / s_n
zbar <- as.numeric(tapply(d$es * d$z0, d$industry_id, sum)[key]) / s_n
g <- as.numeric(tapply(d$shock, d$industry_id, function(v) v[1])[key])

keep <- s_n > 0
s_k <- s_n[keep]
N <- sum(keep)

sh_iv <- wiv(ybar[keep], xbar[keep], g[keep], s_k)
sh_fs <- wiv(xbar[keep], zbar[keep], g[keep], s_k)

eff_shocks <- 1 / sum(s_n^2)

res <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = reg_iv$b[2], se = sh_iv$se[2], n_obs = N),
    list(term = "first_stage", estimate = reg_fs$b[2], se = sh_fs$se[2], n_obs = N),
    list(term = "effective_shocks", estimate = eff_shocks, se = NULL, n_obs = N)
  ),
  method_metadata = list(
    estimator = "Weighted 2SLS with shift-share instrument; BHJ shock-level equivalent IV",
    vcov = "Shock-level HC1 (N/(N-2)), structural IV residuals, analytic weights s_n"
  ),
  diagnostics = list(
    shock_level_effect_slope = sh_iv$b[2],
    shock_level_first_stage_slope = sh_fs$b[2],
    regional_effect_hc1_se = reg_iv$se[2],
    n_regions = nrow(reg),
    n_industries_total = length(ind)
  )
)

writeLines(toJSON(res, auto_unbox = TRUE, digits = NA, null = "null", pretty = TRUE),
           "result.json")
