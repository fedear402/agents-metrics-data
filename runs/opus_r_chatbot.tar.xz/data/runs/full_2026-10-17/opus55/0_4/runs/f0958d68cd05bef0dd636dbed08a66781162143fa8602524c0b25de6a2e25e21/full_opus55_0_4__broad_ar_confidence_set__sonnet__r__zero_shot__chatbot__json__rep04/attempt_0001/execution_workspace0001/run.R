library(jsonlite)
d <- read.csv("input.csv")
n <- nrow(d)
y <- d$y; e <- d$endog
X <- cbind(1, d$x)
W <- cbind(1, d$x, d$z1, d$z2)
MX <- diag(n) - X %*% solve(crossprod(X), t(X))
MW <- diag(n) - W %*% solve(crossprod(W), t(W))
Pz <- MX - MW  # projection onto M_X Z
crit <- qf(0.95, 2, n - 4)
k <- (n - 4) / 2
A <- k * Pz - crit * MW
qa <- as.numeric(t(e) %*% A %*% e)
qb <- as.numeric(-2 * t(e) %*% A %*% y)
qc <- as.numeric(t(y) %*% A %*% y)
arF <- function(b) {
  u <- y - b * e
  num <- as.numeric(t(u) %*% Pz %*% u) / 2
  den <- as.numeric(t(u) %*% MW %*% u) / (n - 4)
  num / den
}
disc <- qb^2 - 4 * qa * qc
roots <- if (disc >= 0) sort(c((-qb - sqrt(disc)) / (2 * qa), (-qb + sqrt(disc)) / (2 * qa))) else c(NA, NA)
accepts_zero <- as.numeric(arF(0) <= crit)
unbounded <- as.numeric(qa < 0 || (qa == 0))
res <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = list(
    list(term = "boundary_low", estimate = roots[1], se = NULL, n_obs = n),
    list(term = "boundary_high", estimate = roots[2], se = NULL, n_obs = n),
    list(term = "accepts_zero", estimate = accepts_zero, se = NULL, n_obs = n),
    list(term = "unbounded", estimate = unbounded, se = NULL, n_obs = n),
    list(term = "ar_f_at_one", estimate = arF(1), se = NULL, n_obs = n)
  ),
  method_metadata = list(estimator = "Anderson-Rubin test inversion (analytic quadratic)",
                         vcov = "homoskedastic F"),
  diagnostics = list(quad_a = qa, quad_b = qb, quad_c = qc, crit = crit)
)
writeLines(toJSON(res, auto_unbox = TRUE, null = "null", digits = 12, na = "null"), "result.json")
