suppressMessages(library(jsonlite))

crosswalk <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
trade <- read.csv("trade.csv", stringsAsFactors = FALSE)
areas <- read.csv("areas.csv", stringsAsFactors = FALSE)
employment <- read.csv("employment.csv", stringsAsFactors = FALSE)
outcomes <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

crosswalk$code <- as.character(crosswalk$code)
trade$code <- as.character(trade$code)
crosswalk$industry <- as.character(crosswalk$industry)
employment$industry <- as.character(employment$industry)
areas$vintage <- trimws(as.character(areas$vintage))
employment$vintage <- trimws(as.character(employment$vintage))

tr <- merge(trade, crosswalk, by = "code")
industries <- sort(unique(crosswalk$industry))
periods <- sort(unique(outcomes$period))

# Complete employment grid with zeros for missing cells
grid <- expand.grid(area = unique(areas$area), period = periods,
                    vintage = c("base", "early"), industry = industries,
                    stringsAsFactors = FALSE)
emp <- aggregate(employment ~ area + period + vintage + industry, data = employment, FUN = sum)
emp <- merge(grid, emp, by = c("area", "period", "vintage", "industry"), all.x = TRUE)
emp$employment[is.na(emp$employment)] <- 0

nat <- aggregate(employment ~ period + vintage + industry, data = emp, FUN = sum)
names(nat)[names(nat) == "employment"] <- "national"
emp <- merge(emp, nat, by = c("period", "vintage", "industry"))
emp <- merge(emp, tr[, c("period", "industry", "us_change", "other_change", "price_index", "years")],
             by = c("period", "industry"))
tot <- areas[, c("area", "period", "vintage", "total_employment")]
emp <- merge(emp, tot, by = c("area", "period", "vintage"))

scale <- 1 / (emp$price_index / 100) / 1000 * (10 / emp$years)
emp$contrib <- ifelse(emp$vintage == "base",
                      (emp$employment / emp$total_employment) * (emp$us_change / emp$national) * scale,
                      (emp$employment / emp$total_employment) * (emp$other_change / emp$national) * scale)

xb <- aggregate(contrib ~ area + period, data = emp[emp$vintage == "base", ], FUN = sum)
names(xb)[3] <- "x"
ze <- aggregate(contrib ~ area + period, data = emp[emp$vintage == "early", ], FUN = sum)
names(ze)[3] <- "z"

pop <- areas[areas$vintage == "base", c("area", "period", "population")]

d <- merge(outcomes, xb, by = c("area", "period"))
d <- merge(d, ze, by = c("area", "period"))
d <- merge(d, pop, by = c("area", "period"))
d <- d[order(d$period, d$area), ]

iv <- function(y, C, x, z, w) {
  X <- cbind(C, x) * sqrt(w); Z <- cbind(C, z) * sqrt(w)
  fitted <- qr.fitted(qr(Z), X)
  as.numeric(qr.coef(qr(fitted), y * sqrt(w)))[ncol(X)]
}
C <- cbind(1, as.numeric(d$period), d$control)
slope <- iv(d$change_pp, C, d$x, d$z, d$population)
n <- nrow(d)

a0p0 <- d$x[d$area == 0 & d$period == periods[1]]
a0p1 <- d$x[d$area == 0 & d$period == periods[2]]
z0p0 <- d$z[d$area == 0 & d$period == periods[1]]

mk <- function(term, est) list(term = term, estimate = est, se = NA, n_obs = as.integer(n))
res <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = list(
    mk("iv_slope", slope),
    mk("exposure_area0_period0", a0p0),
    mk("exposure_area0_period1", a0p1),
    mk("instrument_area0_period0", z0p0)
  ),
  method_metadata = list(
    estimator = "weighted 2SLS",
    exogenous = c("intercept", "period", "control"),
    endogenous = "x", instrument = "z", weight = "base-vintage population"
  ),
  diagnostics = list(n_obs = as.integer(n), n_industries = length(industries),
                     periods = periods)
)
write_json(res, "result.json", auto_unbox = TRUE, digits = NA, na = "null", pretty = TRUE)
