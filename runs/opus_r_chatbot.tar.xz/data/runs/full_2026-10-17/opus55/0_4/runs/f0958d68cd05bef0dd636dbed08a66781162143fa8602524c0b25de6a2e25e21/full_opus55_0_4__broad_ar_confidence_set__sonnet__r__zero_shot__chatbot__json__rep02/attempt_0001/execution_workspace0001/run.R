library(jsonlite)
d <- read.csv("input.csv")
n <- nrow(d)
Y <- cbind(d$y, d$endog)
X0 <- cbind(1, d$x)
X1 <- cbind(1, d$x, d$z1, d$z2)
Rr <- qr.resid(qr(X0), Y)
Ru <- qr.resid(qr(X1), Y)
Sr <- crossprod(Rr); Su <- crossprod(Ru)
crit <- qf(0.95, 2, n - 4)
k <- 2 * crit / (n - 4)
D <- Sr - (1 + k) * Su
# F(b) <= crit  <=>  Q(b) = D11 - 2 b D12 + b^2 D22 <= 0
a <- D[2, 2]; bq <- -2 * D[1, 2]; cq <- D[1, 1]
disc <- bq^2 - 4 * a * cq
roots <- sort(c((-bq - sqrt(disc)) / (2 * a), (-bq + sqrt(disc)) / (2 * a)))
unbounded <- as.numeric(a < 0)
accepts_zero <- as.numeric(cq <= 0)
Ffun <- function(b) {
  u <- d$y - b * d$endog
  fu <- lm(u ~ d$x + d$z1 + d$z2); fr <- lm(u ~ d$x)
  rssu <- sum(resid(fu)^2); rssr <- sum(resid(fr)^2)
  ((rssr - rssu) / 2) / (rssu / (n - 4))
}
f1 <- Ffun(1)
est <- function(t, v) list(term = t, estimate = v, se = NULL, n_obs = n)
res <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = list(
    est("boundary_low", roots[1]),
    est("boundary_high", roots[2]),
    est("accepts_zero", accepts_zero),
    est("unbounded", unbounded),
    est("ar_f_at_one", f1)
  ),
  method_metadata = list(estimator = "Anderson-Rubin test inversion (analytic quadratic)",
                         vcov = "homoskedastic F"),
  diagnostics = list(crit = crit, quad_a = a, quad_b = bq, quad_c = cq, disc = disc)
)
write(toJSON(res, auto_unbox = TRUE, digits = NA, null = "null", pretty = TRUE), "result.json")
