suppressMessages(library(jsonlite))
h <- read.csv("households.csv")
cs <- read.csv("census.csv")
d <- h[h$recipient == 0, ]
d <- d[complete.cases(d[, c("eligible","instrument","dose","baseline","weight","outcome")]), ]
e <- d$eligible; ne <- 1 - e
X <- cbind(ne = ne, el = e, bne = d$baseline * ne, bel = d$baseline * e,
           dne = d$dose * ne, del = d$dose * e)
Z <- cbind(ne = ne, el = e, bne = d$baseline * ne, bel = d$baseline * e,
           zne = d$instrument * ne, zel = d$instrument * e)
w <- d$weight; y <- d$outcome
ZWZ <- crossprod(Z, Z * w)
ZWX <- crossprod(Z, X * w)
ZWy <- crossprod(Z, y * w)
A <- t(ZWX) %*% solve(ZWZ, ZWX)
b <- t(ZWX) %*% solve(ZWZ, ZWy)
beta <- as.vector(solve(A, b)); names(beta) <- colnames(X)
m0 <- sum(w[e == 0] * d$dose[e == 0]) / sum(w[e == 0])
m1 <- sum(w[e == 1] * d$dose[e == 1]) / sum(w[e == 1])
ie <- beta["dne"] * m0
ee <- beta["del"] * m1
p0 <- sum(cs$nonrecipient_population[cs$eligible == 0])
p1 <- sum(cs$nonrecipient_population[cs$eligible == 1])
pe <- (p0 * ie + p1 * ee) / (p0 + p1)
n <- as.integer(nrow(d))
est <- list(
  list(term = "ineligible_effect", estimate = unname(ie), se = NA, n_obs = n),
  list(term = "eligible_nonrecipient_effect", estimate = unname(ee), se = NA, n_obs = n),
  list(term = "population_effect", estimate = unname(pe), se = NA, n_obs = n))
res <- list(
  task_id = "applied_nonrecipient_population_iv", platform = "r",
  estimates = est,
  method_metadata = list(estimator = "weighted 2SLS, group-interacted, no extra intercept",
                         counterfactual = "dose set to zero for all retained households (synthetic convention)",
                         aggregation = "census nonrecipient_population weights"),
  diagnostics = list(n_obs = n, n_ineligible = as.integer(sum(e == 0)),
                     n_eligible_nonrecipient = as.integer(sum(e == 1)),
                     slope_dose_ineligible = unname(beta["dne"]),
                     slope_dose_eligible = unname(beta["del"]),
                     mean_dose_ineligible = m0, mean_dose_eligible = m1,
                     pop_ineligible = p0, pop_eligible = p1))
write_json(res, "result.json", auto_unbox = TRUE, digits = NA, na = "null", pretty = TRUE)
