suppressPackageStartupMessages({
  library(jsonlite)
})

d <- read.csv("input.csv", stringsAsFactors = FALSE)
d$date <- as.Date(d$date)
d <- d[order(d$date), ]
n <- nrow(d)
ly <- log(d$sales)
dv <- c(NA, diff(log(d$vix)))

L <- 15
X <- sapply(1:L, function(k) c(rep(NA, k), dv[1:(n - k)]))
colnames(X) <- paste0("lag_", 1:L)
ok <- complete.cases(cbind(ly, X))
y <- ly[ok]
Xm <- cbind(1, X[ok, , drop = FALSE])
N <- length(y)
k <- ncol(Xm)

XtXi <- solve(crossprod(Xm))
b <- as.vector(XtXi %*% crossprod(Xm, y))
e <- as.vector(y - Xm %*% b)
U <- Xm * e
S <- crossprod(U)
for (j in 1:L) {
  w <- 1 - j / (L + 1)
  G <- crossprod(U[(j + 1):N, , drop = FALSE], U[1:(N - j), , drop = FALSE])
  S <- S + w * (G + t(G))
}
V <- XtXi %*% S %*% XtXi * (N / (N - k))

g <- c(0, rep(1, L))
cum <- sum(b[2:(L + 1)])
cum_se <- sqrt(as.numeric(t(g) %*% V %*% g))

res <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(term = "cumulative_response", estimate = cum, se = cum_se, n_obs = N),
    list(term = "lag_1", estimate = b[2], se = sqrt(V[2, 2]), n_obs = N),
    list(term = "lag_15", estimate = b[L + 1], se = sqrt(V[L + 1, L + 1]), n_obs = N)
  ),
  method_metadata = list(
    estimator = "OLS distributed lag of log(sales) on lags 1-15 of dlog(vix)",
    vcov = "Newey-West HAC, maxlag 15, Bartlett weights 1-j/16, scaled N/(N-16)"
  ),
  diagnostics = setNames(list(), character(0))
)
writeLines(toJSON(res, auto_unbox = TRUE, digits = NA, pretty = TRUE), "result.json")
