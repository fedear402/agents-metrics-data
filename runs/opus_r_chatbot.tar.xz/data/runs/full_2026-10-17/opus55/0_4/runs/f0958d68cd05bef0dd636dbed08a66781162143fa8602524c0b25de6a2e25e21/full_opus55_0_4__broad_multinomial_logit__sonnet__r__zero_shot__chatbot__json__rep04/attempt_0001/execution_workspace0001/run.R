suppressMessages(library(jsonlite))
d <- read.csv("input.csv")
n_full <- nrow(d)
d <- d[complete.cases(d[, c("y","x","z")]), ]
X <- cbind(1, d$x, d$z)
y <- as.integer(d$y)
Y1 <- as.numeric(y == 1); Y2 <- as.numeric(y == 2)
k <- ncol(X)
probs <- function(b) {
  e1 <- exp(X %*% b[1:k]); e2 <- exp(X %*% b[(k+1):(2*k)])
  den <- 1 + e1 + e2
  cbind(1/den, e1/den, e2/den)
}
nll <- function(b) {
  eta1 <- X %*% b[1:k]; eta2 <- X %*% b[(k+1):(2*k)]
  m <- pmax(0, eta1, eta2)
  lse <- m + log(exp(-m) + exp(eta1 - m) + exp(eta2 - m))
  -sum(Y1*eta1 + Y2*eta2 - lse)
}
grad <- function(b) {
  P <- probs(b)
  -c(crossprod(X, Y1 - P[,2]), crossprod(X, Y2 - P[,3]))
}
hess <- function(b) {
  P <- probs(b); p1 <- P[,2]; p2 <- P[,3]
  H11 <- crossprod(X * (p1*(1-p1)), X)
  H22 <- crossprod(X * (p2*(1-p2)), X)
  H12 <- -crossprod(X * (p1*p2), X)
  rbind(cbind(H11, H12), cbind(t(H12), H22))
}
b <- rep(0, 2*k)
for (it in 1:100) {
  step <- solve(hess(b), -grad(b))
  t <- 1
  while (nll(b + t*step) > nll(b) + 1e-12 && t > 1e-8) t <- t/2
  b <- b + t*step
  if (max(abs(t*step)) < 1e-12) break
}
V <- solve(hess(b))
se <- sqrt(diag(V))
e1 <- exp(b[1]); e2 <- exp(b[k+1])
p2z <- e2/(1+e1+e2)
mk <- function(term, est, s) list(term=term, estimate=unname(est), se=if (is.null(s)) NULL else unname(s), n_obs=n_full)
est <- list(
  mk("x_cat1", b[2], se[2]),
  mk("z_cat1", b[3], se[3]),
  mk("x_cat2", b[k+2], se[k+2]),
  mk("z_cat2", b[k+3], se[k+3]),
  list(term="prob_cat2_zero", estimate=unname(p2z), se=NA, n_obs=n_full)
)
res <- list(task_id="broad_multinomial_logit", platform="r", estimates=est,
  method_metadata=list(estimator="multinomial logit MLE (Newton-Raphson), base outcome 0", vcov="observed information (inverse Hessian)"),
  diagnostics=list(loglik=-nll(b), iterations=it, n_used=nrow(d)))
writeLines(toJSON(res, auto_unbox=TRUE, digits=NA, na="null", null="null", pretty=TRUE), "result.json")
