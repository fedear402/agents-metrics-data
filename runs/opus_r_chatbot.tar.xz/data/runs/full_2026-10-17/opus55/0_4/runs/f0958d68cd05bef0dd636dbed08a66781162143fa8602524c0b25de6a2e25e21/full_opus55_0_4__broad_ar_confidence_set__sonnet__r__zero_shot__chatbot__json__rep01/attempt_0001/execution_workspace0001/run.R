library(jsonlite)
d <- read.csv("input.csv")
n <- nrow(d)
y <- d$y; e <- d$endog
X <- cbind(1, d$x)
W <- cbind(1, d$x, d$z1, d$z2)
res <- function(M, v) qr.resid(qr(M), v)
ry <- res(X, y); re <- res(X, e)
uy <- res(W, y); ue <- res(W, e)
cval <- qf(0.95, 2, n - 4)
k <- 1 + 2 * cval / (n - 4)
A <- sum(re^2) - k * sum(ue^2)
B <- -2 * (sum(ry * re) - k * sum(uy * ue))
C <- sum(ry^2) - k * sum(uy^2)
disc <- B^2 - 4 * A * C
roots <- sort(c((-B - sqrt(disc)) / (2 * A), (-B + sqrt(disc)) / (2 * A)))

arF <- function(b) {
  u <- y - b * e
  rr <- sum(res(X, u)^2); ru <- sum(res(W, u)^2)
  ((rr - ru) / 2) / (ru / (n - 4))
}
accepts_zero <- as.numeric(arF(0) <= cval)
unbounded <- as.numeric(A < 0 || (A == 0 && B != 0))
f1 <- arF(1)

out <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = list(
    list(term = "boundary_low", estimate = roots[1], se = NULL, n_obs = n),
    list(term = "boundary_high", estimate = roots[2], se = NULL, n_obs = n),
    list(term = "accepts_zero", estimate = accepts_zero, se = NULL, n_obs = n),
    list(term = "unbounded", estimate = unbounded, se = NULL, n_obs = n),
    list(term = "ar_f_at_one", estimate = f1, se = NULL, n_obs = n)
  ),
  method_metadata = list(estimator = "Anderson-Rubin test inversion (analytic quadratic)",
                         vcov = "homoskedastic F"),
  diagnostics = list(quad_A = A, quad_B = B, quad_C = C, f_crit = cval)
)
writeLines(toJSON(out, auto_unbox = TRUE, digits = 12, null = "null", pretty = TRUE), "result.json")
