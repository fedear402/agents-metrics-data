suppressPackageStartupMessages(library(jsonlite))

d <- read.csv("input.csv", stringsAsFactors = FALSE)
d <- d[!is.na(d$id) & !is.na(d$time), ]

ests <- list()
atts <- c(); wts <- c(); ns <- c()

for (c in c(3, 5, 7)) {
  win <- (c - 2):(c + 2)
  s <- d[d$time %in% win & (d$g == c | d$g == 0 | d$g > c + 2), ]
  cnt <- tapply(s$time, s$id, function(t) length(unique(t)))
  keep <- names(cnt)[cnt == length(win)]
  s <- s[as.character(s$id) %in% keep, ]
  s <- s[!is.na(s$y), ]
  s$did <- as.numeric(s$g == c & s$time >= c)
  fit <- lm(y ~ did + factor(id) + factor(time), data = s)
  b <- unname(coef(fit)["did"])
  ntr <- length(unique(s$id[s$g == c]))
  atts <- c(atts, b); wts <- c(wts, ntr); ns <- c(ns, nrow(s))
  ests[[length(ests) + 1]] <- list(term = paste0("att_g", c), estimate = b,
                                   se = NULL, n_obs = nrow(s))
}

ests[[4]] <- list(term = "att_weighted", estimate = sum(atts * wts) / sum(wts),
                  se = NULL, n_obs = sum(ns))

res <- list(task_id = "broad_cohort_stack", platform = "r", estimates = ests,
            method_metadata = list(treated_units = as.list(setNames(wts, c("g3", "g5", "g7")))),
            diagnostics = setNames(list(), character(0)))

write_json(res, "result.json", auto_unbox = TRUE, null = "null", digits = NA, pretty = TRUE)
