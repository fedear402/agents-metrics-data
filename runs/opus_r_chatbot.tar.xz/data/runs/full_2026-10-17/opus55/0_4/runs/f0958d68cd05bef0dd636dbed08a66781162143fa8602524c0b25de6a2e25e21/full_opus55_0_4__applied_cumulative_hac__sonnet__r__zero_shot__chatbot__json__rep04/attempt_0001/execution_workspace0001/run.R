d <- read.csv("input.csv", stringsAsFactors = FALSE)
d$date <- as.Date(d$date)
d <- d[order(d$date), ]
n <- nrow(d)
ly <- log(d$sales)
dv <- c(NA, diff(log(d$vix)))
L <- 15
X <- sapply(1:L, function(k) c(rep(NA, k), dv[1:(n - k)]))
colnames(X) <- paste0("lag_", 1:L)
ok <- complete.cases(X) & is.finite(ly)
y <- ly[ok]; Xm <- cbind(1, X[ok, , drop = FALSE])
N <- length(y)
fit <- lm.fit(Xm, y)
b <- fit$coefficients
e <- fit$residuals
u <- Xm * e
S <- crossprod(u)
for (j in 1:L) {
  w <- 1 - j / (L + 1)
  G <- crossprod(u[(j + 1):N, , drop = FALSE], u[1:(N - j), , drop = FALSE])
  S <- S + w * (G + t(G))
}
XtXi <- solve(crossprod(Xm))
V <- XtXi %*% S %*% XtXi * N / (N - 16)
g <- c(0, rep(1, L))
cum <- sum(b[-1]); cse <- sqrt(as.numeric(t(g) %*% V %*% g))
res <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(term = "cumulative_response", estimate = cum, se = cse, n_obs = N),
    list(term = "lag_1", estimate = unname(b[2]), se = sqrt(V[2, 2]), n_obs = N),
    list(term = "lag_15", estimate = unname(b[16]), se = sqrt(V[16, 16]), n_obs = N)
  ),
  method_metadata = list(estimator = "OLS distributed lag",
                         vcov = "Newey-West HAC, Bartlett lag 15, scaled N/(N-16)"),
  diagnostics = setNames(list(), character(0))
)
jsonlite::write_json(res, "result.json", auto_unbox = TRUE, digits = 12, pretty = TRUE)
