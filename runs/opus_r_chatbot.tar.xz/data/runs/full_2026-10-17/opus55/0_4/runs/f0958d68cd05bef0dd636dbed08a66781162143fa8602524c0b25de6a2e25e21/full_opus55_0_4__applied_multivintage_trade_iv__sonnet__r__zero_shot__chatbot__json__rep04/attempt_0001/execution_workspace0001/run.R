suppressPackageStartupMessages(library(jsonlite))

cw <- read.csv("crosswalk.csv", stringsAsFactors = FALSE, colClasses = c(code = "character"))
tr <- read.csv("trade.csv", stringsAsFactors = FALSE, colClasses = c(code = "character"))
ar <- read.csv("areas.csv", stringsAsFactors = FALSE)
em <- read.csv("employment.csv", stringsAsFactors = FALSE)
oc <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

cw$code <- trimws(cw$code); tr$code <- trimws(tr$code)
cw$industry <- as.character(cw$industry)
em$industry <- as.character(em$industry)
ar$vintage <- trimws(as.character(ar$vintage))
em$vintage <- trimws(as.character(em$vintage))

trm <- merge(tr, cw, by = "code")
industries <- sort(unique(cw$industry))

# full grid of area-period-vintage-industry, missing = 0
apv <- unique(ar[, c("area", "period", "vintage")])
grid <- merge(apv, data.frame(industry = industries, stringsAsFactors = FALSE), by = NULL)
emagg <- aggregate(employment ~ area + period + vintage + industry, data = em, FUN = sum)
grid <- merge(grid, emagg, by = c("area", "period", "vintage", "industry"), all.x = TRUE)
grid$employment[is.na(grid$employment)] <- 0

nat <- aggregate(employment ~ period + vintage + industry, data = grid, FUN = sum)
names(nat)[names(nat) == "employment"] <- "nat_emp"
grid <- merge(grid, nat, by = c("period", "vintage", "industry"))
grid <- merge(grid, ar[, c("area", "period", "vintage", "total_employment")],
              by = c("area", "period", "vintage"))
grid <- merge(grid, trm[, c("period", "industry", "us_change", "other_change", "price_index", "years")],
              by = c("period", "industry"))

grid$chg <- ifelse(grid$vintage == "base", grid$us_change, grid$other_change)
grid$term <- (grid$employment / grid$total_employment) * (grid$chg / grid$nat_emp) /
  (grid$price_index / 100) / 1000 * (10 / grid$years)

xb <- aggregate(term ~ area + period, data = grid[grid$vintage == "base", ], FUN = sum)
names(xb)[3] <- "x"
ze <- aggregate(term ~ area + period, data = grid[grid$vintage == "early", ], FUN = sum)
names(ze)[3] <- "z"
pop <- ar[ar$vintage == "base", c("area", "period", "population")]

d <- merge(oc, xb, by = c("area", "period"))
d <- merge(d, ze, by = c("area", "period"))
d <- merge(d, pop, by = c("area", "period"))
d <- d[complete.cases(d[, c("change_pp", "period", "control", "x", "z", "population")]), ]

per <- as.numeric(d$period)
X <- cbind(1, per, d$control, d$x)
Z <- cbind(1, per, d$control, d$z)
y <- d$change_pp
w <- d$population
XWZ <- t(X) %*% (w * Z)
ZWZ <- t(Z) %*% (w * Z)
ZWy <- t(Z) %*% (w * y)
A <- XWZ %*% solve(ZWZ)
beta <- solve(A %*% t(XWZ), A %*% ZWy)
iv_slope <- beta[4]

pk <- sort(unique(d$period))
gx <- function(a, p) d$x[d$area == a & d$period == p][1]
e00 <- gx(0, pk[1]); e01 <- gx(0, pk[2])
z00 <- d$z[d$area == 0 & d$period == pk[1]][1]
n <- nrow(d)

mk <- function(t, v) list(term = t, estimate = unname(v), se = NULL, n_obs = as.integer(n))
res <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = list(
    mk("iv_slope", iv_slope),
    mk("exposure_area0_period0", e00),
    mk("exposure_area0_period1", e01),
    mk("instrument_area0_period0", z00)
  ),
  method_metadata = list(estimator = "weighted 2SLS", weight = "base population",
                         instruments = "intercept, period, control, z"),
  diagnostics = list(n_obs = as.integer(n), n_industries = length(industries),
                     coefficients = unname(as.numeric(beta)))
)
write_json(res, "result.json", auto_unbox = TRUE, digits = NA, null = "null", pretty = TRUE)
