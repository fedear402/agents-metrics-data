d <- read.csv("input.csv")
n <- nrow(d)
d <- d[complete.cases(d[, c("y","x","z")]), ]
X <- cbind(1, d$x, d$z)
y <- as.integer(d$y)
Y1 <- as.numeric(y == 1); Y2 <- as.numeric(y == 2)
k <- ncol(X)
probs <- function(b) {
  e1 <- exp(X %*% b[1:k]); e2 <- exp(X %*% b[(k+1):(2*k)])
  den <- 1 + e1 + e2
  cbind(1/den, e1/den, e2/den)
}
nll <- function(b) {
  P <- probs(b)
  -sum(log(P[cbind(seq_along(y), y + 1)]))
}
gr <- function(b) {
  P <- probs(b)
  -c(crossprod(X, Y1 - P[,2]), crossprod(X, Y2 - P[,3]))
}
fit <- optim(rep(0, 2*k), nll, gr, method = "BFGS",
             control = list(maxit = 10000, reltol = 1e-14))
b <- fit$par
for (it in 1:50) {
  P <- probs(b)
  H <- matrix(0, 2*k, 2*k)
  for (j in 1:2) for (l in 1:2) {
    w <- P[, j+1] * ((j == l) - P[, l+1])
    H[((j-1)*k+1):(j*k), ((l-1)*k+1):(l*k)] <- crossprod(X * w, X)
  }
  step <- solve(H, -gr(b))
  b <- b + step
  if (max(abs(step)) < 1e-12) break
}
P <- probs(b)
H <- matrix(0, 2*k, 2*k)
for (j in 1:2) for (l in 1:2) {
  w <- P[, j+1] * ((j == l) - P[, l+1])
  H[((j-1)*k+1):(j*k), ((l-1)*k+1):(l*k)] <- crossprod(X * w, X)
}
V <- solve(H)
se <- sqrt(diag(V))
p2 <- exp(b[4]) / (1 + exp(b[1]) + exp(b[4]))
mk <- function(t, e, s) list(term = t, estimate = unname(e), se = s, n_obs = n)
res <- list(
  task_id = "broad_multinomial_logit",
  platform = "r",
  estimates = list(
    mk("x_cat1", b[2], se[2]),
    mk("z_cat1", b[3], se[3]),
    mk("x_cat2", b[5], se[5]),
    mk("z_cat2", b[6], se[6]),
    mk("prob_cat2_zero", p2, NA)
  ),
  method_metadata = list(estimator = "multinomial logit MLE (base outcome 0)",
                         vcov = "inverse observed information (OIM)"),
  diagnostics = list(loglik = -nll(b), converged = TRUE)
)
jsonlite::write_json(res, "result.json", auto_unbox = TRUE, digits = NA,
                     pretty = TRUE, na = "null")
