suppressWarnings(suppressMessages(library(jsonlite)))
d <- read.csv("input.csv")
n_full <- nrow(d)
d <- d[complete.cases(d[, c("y","x","z")]), ]
X <- cbind(1, d$x, d$z)
y <- d$y
Y1 <- as.numeric(y == 1); Y2 <- as.numeric(y == 2)
k <- ncol(X)
nll <- function(b) {
  e1 <- X %*% b[1:k]; e2 <- X %*% b[(k+1):(2*k)]
  m <- pmax(0, e1, e2)
  lse <- m + log(exp(-m) + exp(e1 - m) + exp(e2 - m))
  -sum(Y1 * e1 + Y2 * e2 - lse)
}
gr <- function(b) {
  e1 <- X %*% b[1:k]; e2 <- X %*% b[(k+1):(2*k)]
  m <- pmax(0, e1, e2)
  den <- exp(-m) + exp(e1 - m) + exp(e2 - m)
  p1 <- exp(e1 - m) / den; p2 <- exp(e2 - m) / den
  -c(colSums(X * as.numeric(Y1 - p1)), colSums(X * as.numeric(Y2 - p2)))
}
fit <- optim(rep(0, 2*k), nll, gr, method = "BFGS",
             control = list(maxit = 10000, reltol = 1e-14))
fit <- optim(fit$par, nll, gr, method = "BFGS",
             control = list(maxit = 10000, reltol = 1e-16))
b <- fit$par
# analytic observed information (= expected for logit)
e1 <- X %*% b[1:k]; e2 <- X %*% b[(k+1):(2*k)]
den <- 1 + exp(e1) + exp(e2)
p1 <- as.numeric(exp(e1) / den); p2 <- as.numeric(exp(e2) / den)
H11 <- t(X * (p1 * (1 - p1))) %*% X
H22 <- t(X * (p2 * (1 - p2))) %*% X
H12 <- -t(X * (p1 * p2)) %*% X
H <- rbind(cbind(H11, H12), cbind(t(H12), H22))
V <- solve(H)
se <- sqrt(diag(V))
pc2 <- exp(b[k+1]) / (1 + exp(b[1]) + exp(b[k+1]))
mk <- function(t, e, s) list(term = t, estimate = unname(e), se = s, n_obs = n_full)
res <- list(
  task_id = "broad_multinomial_logit",
  platform = "r",
  estimates = list(
    mk("x_cat1", b[2], se[2]),
    mk("z_cat1", b[3], se[3]),
    mk("x_cat2", b[k+2], se[k+2]),
    mk("z_cat2", b[k+3], se[k+3]),
    mk("prob_cat2_zero", pc2, NULL)
  ),
  method_metadata = list(estimator = "multinomial logit MLE (base outcome 0)",
                         vcov = "inverse observed information (Hessian)"),
  diagnostics = list(converged = fit$convergence == 0, loglik = -fit$value,
                     n_used = nrow(d))
)
writeLines(toJSON(res, auto_unbox = TRUE, digits = NA, null = "null", pretty = TRUE),
           "result.json")
