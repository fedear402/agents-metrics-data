suppressMessages(library(jsonlite))
df <- read.csv("input.csv")
df <- df[is.finite(df$score) & is.finite(df$participated) & is.finite(df$earnings), ]
d <- df[abs(df$score) < 1, ]
n <- nrow(d)
w <- 1 - abs(d$score)
R <- as.numeric(d$score >= 0)
X <- cbind(1, R, d$score, R * d$score)
y <- d$earnings
p <- d$participated

XtWX <- crossprod(X, X * w)
Binv <- solve(XtWX)
by <- Binv %*% crossprod(X, w * y)
bp <- Binv %*% crossprod(X, w * p)
ey <- as.vector(y - X %*% by)
ep <- as.vector(p - X %*% bp)

meat <- function(e1, e2) crossprod(X * (w * e1), X * (w * e2))
Vyy <- Binv %*% meat(ey, ey) %*% Binv
Vpp <- Binv %*% meat(ep, ep) %*% Binv
Vyp <- Binv %*% meat(ey, ep) %*% Binv

a <- by[2]; b <- bp[2]
va <- Vyy[2, 2]; vb <- Vpp[2, 2]; cab <- Vyp[2, 2]
tau <- a / b
g <- c(1 / b, -a / b^2)
Vj <- matrix(c(va, cab, cab, vb), 2)
se_tau <- sqrt(as.numeric(t(g) %*% Vj %*% g))

res <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = tau, se = se_tau, n_obs = n),
    list(term = "reduced_form", estimate = a, se = sqrt(va), n_obs = n),
    list(term = "first_stage", estimate = b, se = sqrt(vb), n_obs = n)
  ),
  method_metadata = list(
    estimator = "fuzzy RD, local linear, triangular kernel, h=1, separate slopes; Wald ratio",
    vcov = "HC0 joint sandwich (stacked), delta method with covariance"
  ),
  diagnostics = list(cov_rf_fs = cab, n_left = sum(R == 0), n_right = sum(R == 1))
)
write(toJSON(res, auto_unbox = TRUE, digits = NA, pretty = TRUE), "result.json")
