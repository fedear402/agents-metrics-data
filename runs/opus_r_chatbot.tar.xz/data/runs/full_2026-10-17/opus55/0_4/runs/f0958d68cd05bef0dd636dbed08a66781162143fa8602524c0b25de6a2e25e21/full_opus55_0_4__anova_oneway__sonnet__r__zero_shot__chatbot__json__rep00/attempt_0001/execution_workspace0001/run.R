suppressPackageStartupMessages(library(jsonlite))

df <- read.csv("./input.csv", stringsAsFactors = FALSE)
df$y <- suppressWarnings(as.numeric(df$y))
df$group <- trimws(as.character(df$group))
df <- df[!is.na(df$y) & !is.na(df$group) & df$group != "", ]
df$group <- factor(df$group)

n <- nrow(df)
fit <- lm(y ~ group, data = df)
tab <- anova(fit)

Fval <- as.numeric(tab["group", "F value"])
df_num <- as.numeric(tab["group", "Df"])
df_den <- as.numeric(tab["Residuals", "Df"])
pval <- as.numeric(tab["group", "Pr(>F)"])

mk <- function(term, est) list(term = term, estimate = est, se = NULL, n_obs = n)

res <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = list(
    mk("F", Fval),
    mk("df_num", df_num),
    mk("df_den", df_den),
    mk("p_value", pval)
  ),
  method_metadata = list(estimator = "one-way ANOVA (OLS, classical F test)",
                         vcov = "classical (homoskedastic)"),
  diagnostics = list(n_groups = nlevels(df$group),
                     group_sizes = as.list(table(df$group)))
)

writeLines(toJSON(res, auto_unbox = TRUE, digits = NA, null = "null", pretty = TRUE),
           "result.json")
