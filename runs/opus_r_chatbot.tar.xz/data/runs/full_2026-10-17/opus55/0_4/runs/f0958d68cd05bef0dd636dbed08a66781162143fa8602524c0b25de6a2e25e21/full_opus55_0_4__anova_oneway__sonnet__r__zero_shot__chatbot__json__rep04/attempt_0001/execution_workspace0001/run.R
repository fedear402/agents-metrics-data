suppressPackageStartupMessages(library(jsonlite))

df <- read.csv("./input.csv", stringsAsFactors = FALSE)
df$y <- suppressWarnings(as.numeric(df$y))
df <- df[!is.na(df$y) & !is.na(df$group) & trimws(as.character(df$group)) != "", ]
df$group <- factor(trimws(as.character(df$group)))
df <- droplevels(df)

n <- nrow(df)
fit <- aov(y ~ group, data = df)
tab <- summary(fit)[[1]]
Fval <- as.numeric(tab[1, "F value"])
dfn <- as.numeric(tab[1, "Df"])
dfd <- as.numeric(tab[2, "Df"])
pv <- as.numeric(tab[1, "Pr(>F)"])

grp_sizes <- as.list(table(df$group))
grp_means <- as.list(tapply(df$y, df$group, mean))
grp_sds <- as.list(tapply(df$y, df$group, sd))

mk <- function(term, est) list(term = term, estimate = est, se = NULL, n_obs = n)

res <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = list(
    mk("F", Fval),
    mk("df_num", dfn),
    mk("df_den", dfd),
    mk("p_value", pv)
  ),
  method_metadata = list(
    estimator = "one-way ANOVA (aov, classical equal-variance F test)",
    vcov = "classical (homoskedastic)"
  ),
  diagnostics = list(
    n_groups = nlevels(df$group),
    group_sizes = grp_sizes,
    group_means = grp_means,
    group_sds = grp_sds,
    bartlett_p = tryCatch(bartlett.test(y ~ group, data = df)$p.value, error = function(e) NULL),
    welch_p = tryCatch(oneway.test(y ~ group, data = df, var.equal = FALSE)$p.value, error = function(e) NULL)
  )
)

writeLines(toJSON(res, auto_unbox = TRUE, digits = 15, null = "null", pretty = TRUE), "result.json")
