suppressPackageStartupMessages(library(jsonlite))

cw  <- read.csv("crosswalk.csv", stringsAsFactors = FALSE, colClasses = "character")
tr  <- read.csv("trade.csv", stringsAsFactors = FALSE)
ar  <- read.csv("areas.csv", stringsAsFactors = FALSE)
em  <- read.csv("employment.csv", stringsAsFactors = FALSE)
oc  <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

trim <- function(v) trimws(as.character(v))
cw$code <- trim(cw$code); cw$industry <- trim(cw$industry)
tr$code <- trim(tr$code)
ar$vintage <- tolower(trim(ar$vintage)); em$vintage <- tolower(trim(em$vintage))
em$industry <- trim(em$industry)
ar$area <- trim(ar$area); em$area <- trim(em$area); oc$area <- trim(oc$area)
ar$period <- trim(ar$period); em$period <- trim(em$period)
oc$period <- trim(oc$period); tr$period <- trim(tr$period)

trj <- merge(tr, cw[!duplicated(cw$code), c("code", "industry")], by = "code")
stopifnot(nrow(trj) == nrow(tr))
inds <- sort(unique(cw$industry))

# Full grid of area-period-vintage-industry; missing cells are zero
apv <- unique(ar[, c("area", "period", "vintage")])
grid <- merge(apv, data.frame(industry = inds, stringsAsFactors = FALSE), by = NULL)
emA <- aggregate(employment ~ area + period + vintage + industry, data = em, FUN = sum)
grid <- merge(grid, emA, by = c("area", "period", "vintage", "industry"), all.x = TRUE)
grid$employment[is.na(grid$employment)] <- 0

nat <- aggregate(employment ~ period + vintage + industry, data = grid, FUN = sum)
names(nat)[names(nat) == "employment"] <- "nat_emp"
grid <- merge(grid, nat, by = c("period", "vintage", "industry"))
tot <- ar[, c("area", "period", "vintage", "total_employment")]
grid <- merge(grid, tot, by = c("area", "period", "vintage"))

trA <- aggregate(cbind(us_change, other_change) ~ period + industry, data = trj, FUN = sum)
pt <- unique(trj[, c("period", "price_index", "years")])
pt <- pt[!duplicated(pt$period), ]
grid <- merge(grid, trA, by = c("period", "industry"), all.x = TRUE)
grid$us_change[is.na(grid$us_change)] <- 0
grid$other_change[is.na(grid$other_change)] <- 0
grid <- merge(grid, pt, by = "period")

grid$scale <- 1 / (grid$price_index / 100) / 1000 * (10 / grid$years)
grid$share <- grid$employment / grid$total_employment
gb <- grid[grid$vintage == "base", ]
ge <- grid[grid$vintage == "early", ]
gb$cx <- gb$share * gb$us_change / gb$nat_emp * gb$scale
ge$cz <- ge$share * ge$other_change / ge$nat_emp * ge$scale
xd <- aggregate(cx ~ area + period, data = gb, FUN = sum); names(xd)[3] <- "x"
zd <- aggregate(cz ~ area + period, data = ge, FUN = sum); names(zd)[3] <- "z"

pop <- ar[ar$vintage == "base", c("area", "period", "population")]
pop <- pop[!duplicated(pop[, c("area", "period")]), ]

d <- merge(oc, xd, by = c("area", "period"))
d <- merge(d, zd, by = c("area", "period"))
d <- merge(d, pop, by = c("area", "period"))
d <- d[complete.cases(d[, c("change_pp", "control", "x", "z", "population")]), ]

d$period_num <- as.numeric(d$period)
X <- cbind(1, d$period_num, d$control, d$x)
Z <- cbind(1, d$period_num, d$control, d$z)
y <- d$change_pp
w <- d$population
XWZ <- t(X) %*% (w * Z)
ZWZ <- t(Z) %*% (w * Z)
ZWy <- t(Z) %*% (w * y)
A <- XWZ %*% solve(ZWZ)
beta <- solve(A %*% t(XWZ), A %*% ZWy)
iv_slope <- beta[4]

n_obs <- as.integer(nrow(d))
getv <- function(df, col, a, p) {
  v <- df[[col]][df$area == a & as.numeric(df$period) == p]
  if (length(v)) v[1] else NA_real_
}
x00 <- getv(xd, "x", "0", 0)
x01 <- getv(xd, "x", "0", 1)
z00 <- getv(zd, "z", "0", 0)

mk <- function(term, est) list(term = term, estimate = est, se = NULL, n_obs = n_obs)
res <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = list(
    mk("iv_slope", iv_slope),
    mk("exposure_area0_period0", x00),
    mk("exposure_area0_period1", x01),
    mk("instrument_area0_period0", z00)
  ),
  method_metadata = list(
    estimator = "weighted 2SLS",
    weights = "base-vintage population",
    regressors = c("intercept", "period", "control", "x"),
    instruments = c("intercept", "period", "control", "z")
  ),
  diagnostics = list(
    n_obs = n_obs,
    n_industries = length(inds),
    coefficients = as.numeric(beta)
  )
)
write_json(res, "result.json", auto_unbox = TRUE, digits = NA, null = "null", pretty = TRUE)
