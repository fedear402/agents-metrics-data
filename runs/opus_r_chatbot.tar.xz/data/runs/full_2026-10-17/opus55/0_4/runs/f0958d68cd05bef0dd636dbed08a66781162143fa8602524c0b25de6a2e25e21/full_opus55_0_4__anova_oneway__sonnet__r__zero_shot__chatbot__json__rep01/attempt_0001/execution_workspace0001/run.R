suppressPackageStartupMessages(library(jsonlite))

df <- read.csv("./input.csv", stringsAsFactors = FALSE)
df$y <- suppressWarnings(as.numeric(df$y))
df <- df[!is.na(df$y) & !is.na(df$group) & trimws(as.character(df$group)) != "", ]
df$group <- factor(trimws(as.character(df$group)))

n <- nrow(df)
fit <- aov(y ~ group, data = df)
tab <- summary(fit)[[1]]

F_stat <- unname(tab[1, "F value"])
df_num <- unname(tab[1, "Df"])
df_den <- unname(tab[2, "Df"])
p_val  <- unname(tab[1, "Pr(>F)"])

# Welch's test as a diagnostic (robust to unequal variances)
welch <- tryCatch(oneway.test(y ~ group, data = df, var.equal = FALSE), error = function(e) NULL)
grp_n <- as.list(table(df$group))
grp_mean <- as.list(tapply(df$y, df$group, mean))
grp_sd <- as.list(tapply(df$y, df$group, sd))

mk <- function(term, est) list(term = term, estimate = as.numeric(est), se = NULL, n_obs = n)

res <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = list(
    mk("F", F_stat),
    mk("df_num", df_num),
    mk("df_den", df_den),
    mk("p_value", p_val)
  ),
  method_metadata = list(
    estimator = "One-way ANOVA (aov, classical equal-variance F test)",
    vcov = "classical (homoskedastic)"
  ),
  diagnostics = list(
    n_groups = nlevels(df$group),
    group_n = grp_n,
    group_mean = grp_mean,
    group_sd = grp_sd,
    welch_F = if (!is.null(welch)) unname(welch$statistic) else NULL,
    welch_df_num = if (!is.null(welch)) unname(welch$parameter[1]) else NULL,
    welch_df_den = if (!is.null(welch)) unname(welch$parameter[2]) else NULL,
    welch_p_value = if (!is.null(welch)) unname(welch$p.value) else NULL
  )
)

writeLines(toJSON(res, auto_unbox = TRUE, digits = NA, null = "null", pretty = TRUE), "result.json")
