suppressPackageStartupMessages(library(jsonlite))

d <- read.csv("input.csv")
d <- d[is.finite(d$score) & !is.na(d$participated) & !is.na(d$earnings), ]
d <- d[abs(d$score) < 1, ]
n <- nrow(d)

w <- 1 - abs(d$score)
D <- as.numeric(d$score >= 0)
X <- cbind(1, D, d$score * (1 - D), d$score * D)
colnames(X) <- c("int", "jump", "sl", "sr")

XtWX_inv <- solve(crossprod(X, X * w))
fitwls <- function(y) {
  b <- XtWX_inv %*% crossprod(X, w * y)
  e <- as.vector(y - X %*% b)
  list(b = as.vector(b), e = e)
}
fy <- fitwls(d$earnings)
fd <- fitwls(d$participated)

# Influence-based joint HC0 covariance
Sy <- X * (w * fy$e)
Sd <- X * (w * fd$e)
Ay <- Sy %*% XtWX_inv
Ad <- Sd %*% XtWX_inv
ay <- Ay[, 2]; ad <- Ad[, 2]
v_yy <- sum(ay^2); v_dd <- sum(ad^2); v_yd <- sum(ay * ad)

rf <- fy$b[2]; fs <- fd$b[2]
te <- rf / fs
g <- c(1 / fs, -rf / fs^2)
V <- matrix(c(v_yy, v_yd, v_yd, v_dd), 2)
se_te <- sqrt(as.numeric(t(g) %*% V %*% g))

res <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = te, se = se_te, n_obs = n),
    list(term = "reduced_form", estimate = rf, se = sqrt(v_yy), n_obs = n),
    list(term = "first_stage", estimate = fs, se = sqrt(v_dd), n_obs = n)
  ),
  method_metadata = list(
    estimator = "fuzzy RD local linear, triangular kernel, h=1, separate slopes; Wald ratio",
    vcov = "HC0 joint (stacked influence), delta method for ratio"
  ),
  diagnostics = list(cov_rf_fs = v_yd, n_left = sum(D == 0), n_right = sum(D == 1))
)
write(toJSON(res, auto_unbox = TRUE, digits = 12, pretty = TRUE), "result.json")
