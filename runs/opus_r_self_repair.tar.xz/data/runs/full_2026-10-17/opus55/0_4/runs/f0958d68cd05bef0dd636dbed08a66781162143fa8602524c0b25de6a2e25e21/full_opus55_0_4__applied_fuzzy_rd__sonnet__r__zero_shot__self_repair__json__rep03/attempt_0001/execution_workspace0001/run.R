suppressPackageStartupMessages(library(jsonlite))

df <- read.csv("input.csv")
df <- df[complete.cases(df[, c("score", "participated", "earnings")]), ]
d <- df[abs(df$score) < 1, ]
n <- nrow(d)

x <- d$score
D <- as.numeric(x >= 0)
w <- 1 - abs(x)
X <- cbind(1, D, x, D * x)

XtWX_inv <- solve(crossprod(X, X * w))
fit <- function(y) {
  b <- XtWX_inv %*% crossprod(X, w * y)
  list(b = as.vector(b), e = as.vector(y - X %*% b))
}
ry <- fit(d$earnings)
rd <- fit(d$participated)

# Joint HC0 sandwich: per-observation scores for both equations
Sy <- X * (w * ry$e)
Sd <- X * (w * rd$e)
IFy <- Sy %*% XtWX_inv  # rows: influence contributions (bread symmetric)
IFd <- Sd %*% XtWX_inv
ay <- IFy[, 2]
ad <- IFd[, 2]
V <- matrix(c(sum(ay^2), sum(ay * ad), sum(ay * ad), sum(ad^2)), 2, 2)

rf <- ry$b[2]
fs <- rd$b[2]
te <- rf / fs
g <- c(1 / fs, -rf / fs^2)
se_te <- sqrt(as.numeric(t(g) %*% V %*% g))

res <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = te, se = se_te, n_obs = n),
    list(term = "reduced_form", estimate = rf, se = sqrt(V[1, 1]), n_obs = n),
    list(term = "first_stage", estimate = fs, se = sqrt(V[2, 2]), n_obs = n)
  ),
  method_metadata = list(
    estimator = "fuzzy RD, local linear, triangular kernel, h=1, cutoff 0 (score>=0 right), Wald ratio",
    vcov = "HC0 joint sandwich, delta method with covariance, no bias correction"
  ),
  diagnostics = list(cov_rf_fs = V[1, 2],
                     n_left = sum(D == 0), n_right = sum(D == 1))
)
write_json(res, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE)
