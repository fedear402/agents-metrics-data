suppressMessages(library(jsonlite))

cw <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
tr <- read.csv("trade.csv", stringsAsFactors = FALSE)
ar <- read.csv("areas.csv", stringsAsFactors = FALSE)
em <- read.csv("employment.csv", stringsAsFactors = FALSE)
oc <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

norm <- function(v) tolower(trimws(as.character(v)))
cw$code <- trimws(as.character(cw$code)); tr$code <- trimws(as.character(tr$code))
cw$industry <- trimws(as.character(cw$industry)); em$industry <- trimws(as.character(em$industry))
ar$vintage <- norm(ar$vintage); em$vintage <- norm(em$vintage)

tr <- merge(tr, cw[, c("code", "industry")], by = "code")
inds <- sort(unique(cw$industry))

# full grid: area x period x vintage x industry, missing cells = 0
grid <- unique(ar[, c("area", "period", "vintage")])
grid <- merge(grid, data.frame(industry = inds, stringsAsFactors = FALSE), by = NULL)
em <- aggregate(employment ~ area + period + vintage + industry, data = em, FUN = sum)
g <- merge(grid, em, by = c("area", "period", "vintage", "industry"), all.x = TRUE)
g$employment[is.na(g$employment)] <- 0

nat <- aggregate(employment ~ period + vintage + industry, data = g, FUN = sum)
names(nat)[names(nat) == "employment"] <- "nat_emp"
g <- merge(g, nat, by = c("period", "vintage", "industry"))
g <- merge(g, ar[, c("area", "period", "vintage", "total_employment")],
           by = c("area", "period", "vintage"))
g <- merge(g, tr[, c("period", "industry", "us_change", "other_change", "price_index", "years")],
           by = c("period", "industry"))

scale <- 1 / (g$price_index / 100) / 1000 * (10 / g$years)
share <- g$employment / g$total_employment
g$cx <- ifelse(g$vintage == "base", share * g$us_change / g$nat_emp * scale, 0)
g$cz <- ifelse(g$vintage == "early", share * g$other_change / g$nat_emp * scale, 0)
ex <- aggregate(cbind(x = cx, z = cz) ~ area + period, data = g, FUN = sum)

pop <- ar[ar$vintage == "base", c("area", "period", "population")]
d <- merge(oc, ex, by = c("area", "period"))
d <- merge(d, pop, by = c("area", "period"))
d <- d[complete.cases(d[, c("change_pp", "period", "control", "x", "z", "population")]), ]
d <- d[order(d$period, d$area), ]

w <- sqrt(d$population)
C <- cbind(1, as.numeric(d$period), d$control)
X <- cbind(C, d$x) * w
Z <- cbind(C, d$z) * w
y <- d$change_pp * w
fitted <- qr.fitted(qr(Z), X)
b <- as.numeric(qr.coef(qr(fitted), y))
iv_slope <- b[4]

periods <- sort(unique(d$period))
getv <- function(col, a, p) { v <- ex[[col]][ex$area == a & ex$period == p]; if (length(v)) v[1] else NA }
a0 <- 0
e00 <- getv("x", a0, periods[1]); e01 <- getv("x", a0, periods[2]); z00 <- getv("z", a0, periods[1])
n <- nrow(d)

est <- list(
  list(term = "iv_slope", estimate = iv_slope, se = NULL, n_obs = n),
  list(term = "exposure_area0_period0", estimate = e00, se = NULL, n_obs = n),
  list(term = "exposure_area0_period1", estimate = e01, se = NULL, n_obs = n),
  list(term = "instrument_area0_period0", estimate = z00, se = NULL, n_obs = n)
)
res <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = est,
  method_metadata = list(
    estimator = "weighted 2SLS",
    regressors = c("intercept", "period", "control", "x"),
    instruments = c("intercept", "period", "control", "z"),
    weight = "base-vintage population",
    exposure_units = "thousands of real dollars per worker per decade"
  ),
  diagnostics = list(n_obs = n, n_areas = length(unique(d$area)),
                     n_periods = length(periods), n_industries = length(inds),
                     coefficients = b)
)
write_json(res, "result.json", auto_unbox = TRUE, digits = NA, null = "null", pretty = TRUE)
