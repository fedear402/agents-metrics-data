suppressPackageStartupMessages(library(jsonlite))

hh <- read.csv("households.csv", stringsAsFactors = FALSE)
census <- read.csv("census.csv", stringsAsFactors = FALSE)

d <- hh[hh$recipient == 0, ]
d <- d[complete.cases(d[, c("eligible", "instrument", "dose", "baseline", "weight", "outcome")]), ]
n <- nrow(d)

e <- as.numeric(d$eligible)
ne <- 1 - e
X <- cbind(d_inel = d$dose * ne, d_elig = d$dose * e,
           c_inel = ne, c_elig = e,
           b_inel = d$baseline * ne, b_elig = d$baseline * e)
Z <- cbind(c_inel = ne, c_elig = e,
           b_inel = d$baseline * ne, b_elig = d$baseline * e,
           z_inel = d$instrument * ne, z_elig = d$instrument * e)
y <- d$outcome
w <- d$weight

ZW <- Z * w
ZtWZ <- crossprod(Z, ZW)
ZtWX <- crossprod(ZW, X)
ZtWy <- crossprod(ZW, y)
A <- t(ZtWX) %*% solve(ZtWZ, ZtWX)
b <- t(ZtWX) %*% solve(ZtWZ, ZtWy)
beta <- as.vector(solve(A, b))
names(beta) <- colnames(X)

i0 <- e == 0; i1 <- e == 1
mdose0 <- sum(w[i0] * d$dose[i0]) / sum(w[i0])
mdose1 <- sum(w[i1] * d$dose[i1]) / sum(w[i1])
eff0 <- unname(beta["d_inel"] * mdose0)
eff1 <- unname(beta["d_elig"] * mdose1)

p0 <- sum(census$nonrecipient_population[census$eligible == 0])
p1 <- sum(census$nonrecipient_population[census$eligible == 1])
pop_eff <- (p0 * eff0 + p1 * eff1) / (p0 + p1)

est <- list(
  list(term = "ineligible_effect", estimate = eff0, se = NULL, n_obs = as.integer(n)),
  list(term = "eligible_nonrecipient_effect", estimate = eff1, se = NULL, n_obs = as.integer(n)),
  list(term = "population_effect", estimate = pop_eff, se = NULL, n_obs = as.integer(n))
)

res <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = est,
  method_metadata = list(
    estimator = "weighted 2SLS, group-interacted, no common intercept",
    sample = "recipient == 0 (all nonrecipients, both village statuses)",
    endogenous = c("dose*(1-eligible)", "dose*eligible"),
    exogenous = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"),
    excluded_instruments = c("instrument*(1-eligible)", "instrument*eligible"),
    weights = "weight",
    effect_definition = "dose slope times household-weighted mean dose in group; counterfactual dose = 0 (synthetic convention)",
    aggregation = "census nonrecipient_population weights"
  ),
  diagnostics = list(
    n_obs = as.integer(n),
    n_ineligible = as.integer(sum(i0)),
    n_eligible = as.integer(sum(i1)),
    coefficients = as.list(beta),
    mean_dose_ineligible = mdose0,
    mean_dose_eligible = mdose1,
    census_pop_ineligible = p0,
    census_pop_eligible = p1
  )
)

write_json(res, "result.json", auto_unbox = TRUE, digits = NA, null = "null", pretty = TRUE)
