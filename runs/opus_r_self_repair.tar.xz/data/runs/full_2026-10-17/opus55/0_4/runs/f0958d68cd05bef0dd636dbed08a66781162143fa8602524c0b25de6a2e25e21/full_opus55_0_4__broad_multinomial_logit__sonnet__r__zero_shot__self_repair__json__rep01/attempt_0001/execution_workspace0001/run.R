d <- read.csv("input.csv")
n <- nrow(d)
y <- as.integer(d$y); X <- cbind(1, d$x, d$z)
nll <- function(b) {
  b1 <- b[1:3]; b2 <- b[4:6]
  e1 <- X %*% b1; e2 <- X %*% b2
  m <- pmax(0, e1, e2)
  ld <- m + log(exp(-m) + exp(e1 - m) + exp(e2 - m))
  ll <- ifelse(y == 1, e1, ifelse(y == 2, e2, 0)) - ld
  -sum(ll)
}
gr <- function(b) {
  e1 <- exp(X %*% b[1:3]); e2 <- exp(X %*% b[4:6]); den <- 1 + e1 + e2
  p1 <- as.vector(e1/den); p2 <- as.vector(e2/den)
  -c(colSums(X * ((y == 1) - p1)), colSums(X * ((y == 2) - p2)))
}
fit <- optim(rep(0, 6), nll, gr, method = "BFGS", control = list(reltol = 1e-14, maxit = 10000))
b <- fit$par
e1 <- exp(X %*% b[1:3]); e2 <- exp(X %*% b[4:6]); den <- 1 + e1 + e2
p1 <- as.vector(e1/den); p2 <- as.vector(e2/den)
H <- matrix(0, 6, 6)
H[1:3,1:3] <- crossprod(X * (p1*(1-p1)), X)
H[4:6,4:6] <- crossprod(X * (p2*(1-p2)), X)
H[1:3,4:6] <- -crossprod(X * (p1*p2), X)
H[4:6,1:3] <- t(H[1:3,4:6])
V <- solve(H); se <- sqrt(diag(V))
pz <- exp(b[4]) / (1 + exp(b[1]) + exp(b[4]))
est <- list(
  list(term="x_cat1", estimate=b[2], se=se[2], n_obs=n),
  list(term="z_cat1", estimate=b[3], se=se[3], n_obs=n),
  list(term="x_cat2", estimate=b[5], se=se[5], n_obs=n),
  list(term="z_cat2", estimate=b[6], se=se[6], n_obs=n),
  list(term="prob_cat2_zero", estimate=pz, se=NULL, n_obs=n))
res <- list(task_id="broad_multinomial_logit", platform="r", estimates=est,
  method_metadata=list(estimator="multinomial logit MLE (base outcome 0)", vcov="observed information (inverse Hessian)"),
  diagnostics=list(converged=fit$convergence == 0, loglik=-fit$value))
jsonlite::write_json(res, "result.json", auto_unbox=TRUE, digits=NA, null="null")
