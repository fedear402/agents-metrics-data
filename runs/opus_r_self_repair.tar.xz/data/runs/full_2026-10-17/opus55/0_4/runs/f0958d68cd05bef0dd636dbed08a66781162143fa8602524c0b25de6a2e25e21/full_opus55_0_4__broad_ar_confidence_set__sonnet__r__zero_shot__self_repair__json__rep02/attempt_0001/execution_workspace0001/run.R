library(jsonlite)
d <- read.csv("input.csv")
n <- nrow(d)
y <- d$y; e <- d$endog
W <- cbind(1, d$x)
Z <- cbind(1, d$x, d$z1, d$z2)
MW <- diag(n) - W %*% solve(crossprod(W), t(W))
MZ <- diag(n) - Z %*% solve(crossprod(Z), t(Z))
crit <- qf(0.95, 2, n - 4)
k <- 2 * crit / (n - 4)
P <- (MW - MZ) - k * MZ
a <- as.numeric(t(e) %*% P %*% e)
b <- as.numeric(-2 * t(y) %*% P %*% e)
cc <- as.numeric(t(y) %*% P %*% y)
Ffun <- function(beta) {
  u <- y - beta * e
  rr <- sum((MW %*% u)^2); ru <- sum((MZ %*% u)^2)
  ((rr - ru) / 2) / (ru / (n - 4))
}
accept <- function(beta) Ffun(beta) <= crit
disc <- b^2 - 4 * a * cc
if (disc < 0) stop("No finite boundary points")
r <- sort(c((-b - sqrt(disc)) / (2 * a), (-b + sqrt(disc)) / (2 * a)))
unb <- as.integer(a < 0 || (a == 0))
# verify unboundedness via membership at large values
big <- 1e3 * max(1, abs(r))
unb <- as.integer(accept(big) || accept(-big))
acc0 <- as.integer(accept(0))
f1 <- Ffun(1)
res <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = list(
    list(term = "boundary_low", estimate = r[1], se = NULL, n_obs = n),
    list(term = "boundary_high", estimate = r[2], se = NULL, n_obs = n),
    list(term = "accepts_zero", estimate = acc0, se = NULL, n_obs = n),
    list(term = "unbounded", estimate = unb, se = NULL, n_obs = n),
    list(term = "ar_f_at_one", estimate = f1, se = NULL, n_obs = n)
  ),
  method_metadata = list(estimator = "Anderson-Rubin test inversion (analytic quadratic)",
                         vcov = "homoskedastic F"),
  diagnostics = list(quad_a = a, quad_b = b, quad_c = cc, f_crit = crit)
)
write(toJSON(res, auto_unbox = TRUE, null = "null", digits = 12, pretty = TRUE), "result.json")
