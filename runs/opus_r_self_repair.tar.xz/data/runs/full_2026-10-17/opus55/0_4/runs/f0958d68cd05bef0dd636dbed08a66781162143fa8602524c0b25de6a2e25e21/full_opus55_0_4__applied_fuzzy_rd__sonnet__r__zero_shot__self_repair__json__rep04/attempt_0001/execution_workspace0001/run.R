library(jsonlite)

df <- read.csv("input.csv")
df <- df[!is.na(df$score) & !is.na(df$participated) & !is.na(df$earnings), ]
df <- df[abs(df$score) < 1, ]
n <- nrow(df)

s <- df$score
right <- as.numeric(s >= 0)
w <- 1 - abs(s)
X <- cbind(1, right, s, right * s)
y <- df$earnings
d <- df$participated

XtWX <- crossprod(X, X * w)
B <- solve(XtWX)
by <- B %*% crossprod(X, w * y)
bd <- B %*% crossprod(X, w * d)
ey <- as.vector(y - X %*% by)
ed <- as.vector(d - X %*% bd)

# HC0 influence contributions
Sy <- X * (w * ey)
Sd <- X * (w * ed)
Vyy <- B %*% crossprod(Sy) %*% B
Vdd <- B %*% crossprod(Sd) %*% B
Vyd <- B %*% crossprod(Sy, Sd) %*% B

rf <- by[2]; fs <- bd[2]
v_rf <- Vyy[2, 2]; v_fs <- Vdd[2, 2]; c_rf_fs <- Vyd[2, 2]
te <- rf / fs
g <- c(1 / fs, -rf / fs^2)
v_te <- g[1]^2 * v_rf + g[2]^2 * v_fs + 2 * g[1] * g[2] * c_rf_fs

res <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = te, se = sqrt(v_te), n_obs = n),
    list(term = "reduced_form", estimate = rf, se = sqrt(v_rf), n_obs = n),
    list(term = "first_stage", estimate = fs, se = sqrt(v_fs), n_obs = n)
  ),
  method_metadata = list(
    estimator = "fuzzy RD, local linear, triangular kernel, h=1, Wald ratio",
    vcov = "HC0 joint sandwich, delta method with covariance"
  ),
  diagnostics = list(cov_rf_fs = c_rf_fs, n_left = sum(right == 0), n_right = sum(right == 1))
)
write_json(res, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE)
