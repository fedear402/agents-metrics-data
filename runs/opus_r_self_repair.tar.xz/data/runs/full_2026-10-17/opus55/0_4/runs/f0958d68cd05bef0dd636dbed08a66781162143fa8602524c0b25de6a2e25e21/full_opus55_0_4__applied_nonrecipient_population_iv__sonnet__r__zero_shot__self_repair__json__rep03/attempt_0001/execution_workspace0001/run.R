suppressMessages(library(jsonlite))
hh <- read.csv("households.csv")
cen <- read.csv("census.csv")
d <- hh[hh$recipient == 0, ]
d <- d[complete.cases(d[, c("eligible","instrument","dose","baseline","weight","outcome")]), ]
e <- d$eligible; ne <- 1 - e
X <- cbind(ne, e, d$baseline*ne, d$baseline*e, d$dose*ne, d$dose*e)
Z <- cbind(ne, e, d$baseline*ne, d$baseline*e, d$instrument*ne, d$instrument*e)
w <- d$weight; y <- d$outcome
ZwZ <- crossprod(Z, Z*w)
ZwX <- crossprod(Z, X*w)
Zwy <- crossprod(Z, y*w)
A <- t(ZwX) %*% solve(ZwZ, ZwX)
b <- solve(A, t(ZwX) %*% solve(ZwZ, Zwy))
b0 <- b[5]; b1 <- b[6]
m0 <- weighted.mean(d$dose[e==0], w[e==0])
m1 <- weighted.mean(d$dose[e==1], w[e==1])
eff0 <- b0*m0; eff1 <- b1*m1
p0 <- sum(cen$nonrecipient_population[cen$eligible==0])
p1 <- sum(cen$nonrecipient_population[cen$eligible==1])
pop <- (p0*eff0 + p1*eff1)/(p0+p1)
n <- as.integer(nrow(d))
est <- list(
  list(term="ineligible_effect", estimate=eff0, se=NA, n_obs=n),
  list(term="eligible_nonrecipient_effect", estimate=eff1, se=NA, n_obs=n),
  list(term="population_effect", estimate=pop, se=NA, n_obs=n))
res <- list(task_id="applied_nonrecipient_population_iv", platform="r",
  estimates=est,
  method_metadata=list(estimator="weighted 2SLS, group-interacted, no common intercept",
    counterfactual="dose set to zero for all retained nonrecipient households",
    aggregation="census nonrecipient_population weights"),
  diagnostics=list(n_ineligible=as.integer(sum(e==0)), n_eligible=as.integer(sum(e==1)),
    dose_slope_ineligible=b0, dose_slope_eligible=b1,
    mean_dose_ineligible=m0, mean_dose_eligible=m1,
    census_ineligible=p0, census_eligible=p1))
write_json(res, "result.json", auto_unbox=TRUE, digits=NA, na="null", pretty=TRUE)
