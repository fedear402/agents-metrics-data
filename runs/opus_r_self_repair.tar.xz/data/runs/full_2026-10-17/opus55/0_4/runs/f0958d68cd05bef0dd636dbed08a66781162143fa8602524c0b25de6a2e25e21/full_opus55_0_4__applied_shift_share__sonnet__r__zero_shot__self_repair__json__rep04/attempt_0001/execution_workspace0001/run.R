suppressPackageStartupMessages({ library(jsonlite) })
d <- read.csv("input.csv")
d$region_id <- as.character(d$region_id); d$industry_id <- as.character(d$industry_id)
reg <- d[!duplicated(d$region_id), c("region_id","region_weight","x","y")]
reg$e <- reg$region_weight / sum(reg$region_weight)
d$z_c <- d$share * d$shock
zr <- tapply(d$z_c, d$region_id, sum)
reg$z <- as.numeric(zr[reg$region_id])
e <- reg$e
wm <- function(v) sum(e*v)/sum(e)
reg$y0 <- reg$y - wm(reg$y); reg$x0 <- reg$x - wm(reg$x); reg$z0 <- reg$z - wm(reg$z)

# regional weighted 2SLS (manual)
wiv <- function(yv, xv, zv, w) {
  X <- cbind(1, xv); Z <- cbind(1, zv); W <- w
  b <- solve(t(Z) %*% (W*X), t(Z) %*% (W*yv)); as.numeric(b)
}
b_reg <- wiv(reg$y, reg$x, reg$z, e)
fs_reg <- wiv(reg$x, reg$z, reg$z, e)

# shock-level aggregation
m <- match(d$region_id, reg$region_id)
d$e <- e[m]; d$y0 <- reg$y0[m]; d$x0 <- reg$x0[m]; d$z0 <- reg$z0[m]
d$es <- d$e * d$share
inds <- unique(d$industry_id)
s_n <- as.numeric(tapply(d$es, d$industry_id, sum)[inds])
agg <- function(v) as.numeric(tapply(d$es*v, d$industry_id, sum)[inds]) / s_n
ybar <- agg(d$y0); xbar <- agg(d$x0); zbar <- agg(d$z0)
g <- as.numeric(tapply(d$shock, d$industry_id, function(v) v[1])[inds])
keep <- s_n > 0
s <- s_n[keep]; ybar <- ybar[keep]; xbar <- xbar[keep]; zbar <- zbar[keep]; g <- g[keep]
N <- length(s)

shock_iv <- function(yv, xv, gv, w) {
  X <- cbind(1, xv); Z <- cbind(1, gv)
  A <- solve(t(Z) %*% (w*X))
  b <- A %*% (t(Z) %*% (w*yv))
  u <- as.numeric(yv - X %*% b)
  meat <- t(Z) %*% ((w*u)^2 * Z)
  V <- A %*% meat %*% t(A) * N/(N-2)
  list(b = as.numeric(b), se = sqrt(diag(V)))
}
r1 <- shock_iv(ybar, xbar, g, s)
r2 <- shock_iv(xbar, zbar, g, s)
eff_sh <- 1/sum(s_n^2)

out <- list(
  task_id = "applied_shift_share", platform = "r",
  estimates = list(
    list(term="effect", estimate=b_reg[2], se=r1$se[2], n_obs=N),
    list(term="first_stage", estimate=fs_reg[2], se=r2$se[2], n_obs=N),
    list(term="effective_shocks", estimate=eff_sh, se=NULL, n_obs=N)
  ),
  method_metadata = list(estimator="weighted 2SLS with shift-share instrument; BHJ shock-level equivalent IV",
                         vcov="shock-level HC1 (N/(N-2)), analytic weights s_n, structural IV residuals"),
  diagnostics = list(shock_level_effect=r1$b[2], shock_level_first_stage=r2$b[2], n_regions=nrow(reg))
)
writeLines(toJSON(out, auto_unbox=TRUE, digits=NA, null="null", pretty=TRUE), "result.json")
