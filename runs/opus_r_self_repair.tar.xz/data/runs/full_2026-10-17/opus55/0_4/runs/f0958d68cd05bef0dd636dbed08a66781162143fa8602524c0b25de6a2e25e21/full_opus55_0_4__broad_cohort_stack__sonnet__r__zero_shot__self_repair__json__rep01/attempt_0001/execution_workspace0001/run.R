suppressPackageStartupMessages(library(jsonlite))

d <- read.csv("input.csv", stringsAsFactors = FALSE)
d$g[is.na(d$g)] <- 0

cohorts <- c(3, 5, 7)
est <- list()
for (c in cohorts) {
  win <- (c - 2):(c + 2)
  s <- d[d$time %in% win & (d$g == c | d$g == 0 | d$g > c + 2), ]
  cnt <- tapply(s$time, s$id, function(t) length(unique(t)))
  keep <- names(cnt)[cnt == length(win)]
  s <- s[as.character(s$id) %in% keep, ]
  s$did <- as.numeric(s$g == c & s$time >= c)
  fit <- lm(y ~ did + factor(id) + factor(time), data = s)
  est[[as.character(c)]] <- list(
    att = unname(coef(fit)["did"]),
    n = nrow(s),
    ntr = length(unique(s$id[s$g == c]))
  )
}

atts <- sapply(est, `[[`, "att")
ns <- sapply(est, `[[`, "n")
w <- sapply(est, `[[`, "ntr")
attw <- sum(atts * w) / sum(w)

rows <- list()
for (i in seq_along(cohorts)) {
  rows[[i]] <- list(term = paste0("att_g", cohorts[i]), estimate = atts[[i]],
                    se = NULL, n_obs = as.integer(ns[[i]]))
}
rows[[4]] <- list(term = "att_weighted", estimate = attw, se = NULL,
                  n_obs = as.integer(sum(ns)))

res <- list(
  task_id = "broad_cohort_stack",
  platform = "r",
  estimates = rows,
  method_metadata = list(weights_treated_units = as.list(setNames(as.integer(w), paste0("g", cohorts)))),
  diagnostics = setNames(list(), character(0))
)

write_json(res, "result.json", auto_unbox = TRUE, digits = NA, null = "null", pretty = TRUE)
