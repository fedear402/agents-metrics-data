suppressWarnings(suppressMessages(library(jsonlite)))
d <- read.csv("input.csv")
d <- d[order(d$region_id, d$industry_id), ]

reg <- d[!duplicated(d$region_id), c("region_id", "region_weight", "x", "y")]
reg$e <- reg$region_weight / sum(reg$region_weight)
zr <- tapply(d$share * d$shock, d$region_id, sum)
reg$z <- as.numeric(zr[as.character(reg$region_id)])

wm <- function(v, w) sum(w * v) / sum(w)
reg$y0 <- reg$y - wm(reg$y, reg$e)
reg$x0 <- reg$x - wm(reg$x, reg$e)
reg$z0 <- reg$z - wm(reg$z, reg$e)

# regional estimates
beta_reg <- sum(reg$e * reg$z0 * reg$y0) / sum(reg$e * reg$z0 * reg$x0)
fs_reg <- sum(reg$e * reg$z0 * reg$x0) / sum(reg$e * reg$z0 * reg$z0)

# shock-level aggregation
m <- match(d$region_id, reg$region_id)
d$e <- reg$e[m]
d$ew <- d$e * d$share
ind <- sort(unique(d$industry_id))
s_n <- as.numeric(tapply(d$ew, d$industry_id, sum)[as.character(ind)])
agg <- function(v) as.numeric(tapply(d$ew * v, d$industry_id, sum)[as.character(ind)]) / s_n
ybar <- agg(reg$y0[m]); xbar <- agg(reg$x0[m]); zbar <- agg(reg$z0[m])
shock <- as.numeric(tapply(d$shock, d$industry_id, function(a) a[1])[as.character(ind)])

keep <- s_n > 0
s <- s_n[keep]; ybar <- ybar[keep]; xbar <- xbar[keep]; zbar <- zbar[keep]; shock <- shock[keep]
N <- length(s)

wiv <- function(yv, xv, g, w) {
  X <- cbind(1, xv); Z <- cbind(1, g)
  A <- t(Z) %*% (w * X)
  b <- solve(A, t(Z) %*% (w * yv))
  u <- as.numeric(yv - X %*% b)
  meat <- t(Z) %*% ((w^2 * u^2) * Z)
  Ai <- solve(A)
  V <- Ai %*% meat %*% t(Ai) * N / (N - 2)
  c(b[2], sqrt(V[2, 2]))
}
eff <- wiv(ybar, xbar, shock, s)
fs <- wiv(xbar, zbar, shock, s)
eff_shocks <- 1 / sum(s_n^2)

res <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = eff[1], se = eff[2], n_obs = N),
    list(term = "first_stage", estimate = fs[1], se = fs[2], n_obs = N),
    list(term = "effective_shocks", estimate = eff_shocks, se = NULL, n_obs = N)
  ),
  method_metadata = list(
    estimator = "weighted 2SLS with shift-share instrument; BHJ shock-level equivalent IV",
    vcov = "shock-level HC1 (N/(N-2)), structural IV residuals, analytic weights s_n"
  ),
  diagnostics = list(regional_effect = beta_reg, regional_first_stage = fs_reg,
                     n_regions = nrow(reg), n_industries = N)
)
writeLines(toJSON(res, auto_unbox = TRUE, digits = NA, null = "null", pretty = TRUE), "result.json")
