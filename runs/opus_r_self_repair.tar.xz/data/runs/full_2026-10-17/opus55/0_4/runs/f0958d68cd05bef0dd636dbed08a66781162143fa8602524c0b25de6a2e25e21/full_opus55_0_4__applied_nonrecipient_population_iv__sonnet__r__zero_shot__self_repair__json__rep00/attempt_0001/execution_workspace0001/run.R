suppressPackageStartupMessages(library(jsonlite))

hh <- read.csv("households.csv", stringsAsFactors = FALSE)
cen <- read.csv("census.csv", stringsAsFactors = FALSE)

d <- hh[!is.na(hh$recipient) & hh$recipient == 0, ]
need <- c("eligible", "instrument", "dose", "baseline", "weight", "outcome")
d <- d[complete.cases(d[, need]), ]
n <- nrow(d)

e <- as.numeric(d$eligible)
ne <- 1 - e
X <- cbind(dose_inel = d$dose * ne, dose_el = d$dose * e,
           inel = ne, el = e, base_inel = d$baseline * ne, base_el = d$baseline * e)
Z <- cbind(inel = ne, el = e, base_inel = d$baseline * ne, base_el = d$baseline * e,
           iv_inel = d$instrument * ne, iv_el = d$instrument * e)
y <- d$outcome
w <- d$weight

ZtWZ <- crossprod(Z, Z * w)
ZtWX <- crossprod(Z, X * w)
ZtWy <- crossprod(Z, y * w)
A <- t(ZtWX) %*% solve(ZtWZ, ZtWX)
b <- t(ZtWX) %*% solve(ZtWZ, ZtWy)
beta <- as.vector(solve(A, b))
names(beta) <- colnames(X)

i0 <- e == 0
i1 <- e == 1
md0 <- sum(w[i0] * d$dose[i0]) / sum(w[i0])
md1 <- sum(w[i1] * d$dose[i1]) / sum(w[i1])
eff0 <- unname(beta["dose_inel"] * md0)
eff1 <- unname(beta["dose_el"] * md1)

p0 <- sum(cen$nonrecipient_population[cen$eligible == 0])
p1 <- sum(cen$nonrecipient_population[cen$eligible == 1])
pop <- (p0 * eff0 + p1 * eff1) / (p0 + p1)

est <- list(
  list(term = "ineligible_effect", estimate = eff0, se = NULL, n_obs = as.integer(n)),
  list(term = "eligible_nonrecipient_effect", estimate = eff1, se = NULL, n_obs = as.integer(n)),
  list(term = "population_effect", estimate = pop, se = NULL, n_obs = as.integer(n))
)

res <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = est,
  method_metadata = list(
    estimator = "weighted 2SLS, group-interacted, no extra intercept",
    sample = "recipient == 0 (all nonrecipients incl. ineligible in both village statuses)",
    effect_definition = "dose slope times household-weighted mean dose within group; zero-dose counterfactual (synthetic convention)",
    aggregation = "census nonrecipient_population weights"
  ),
  diagnostics = list(
    n_ineligible = as.integer(sum(i0)), n_eligible = as.integer(sum(i1)),
    slope_ineligible = unname(beta["dose_inel"]), slope_eligible = unname(beta["dose_el"]),
    mean_dose_ineligible = md0, mean_dose_eligible = md1,
    pop_ineligible = p0, pop_eligible = p1,
    coefficients = as.list(beta)
  )
)

write_json(res, "result.json", auto_unbox = TRUE, digits = NA, null = "null", pretty = TRUE)
