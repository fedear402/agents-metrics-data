suppressPackageStartupMessages(library(jsonlite))

df <- read.csv("./input.csv", stringsAsFactors = FALSE)
df <- df[!is.na(df$y) & !is.na(df$group) & df$group != "", c("group", "y")]
df$y <- as.numeric(df$y)
df <- df[is.finite(df$y), ]
df$group <- factor(as.character(df$group))
n <- nrow(df)

fit <- aov(y ~ group, data = df)
tab <- summary(fit)[[1]]
F_stat <- unname(tab[["F value"]][1])
df_num <- unname(tab[["Df"]][1])
df_den <- unname(tab[["Df"]][2])
p_val <- unname(tab[["Pr(>F)"]][1])

grp_n <- as.list(table(df$group))
grp_mean <- as.list(tapply(df$y, df$group, mean))
bart <- tryCatch(bartlett.test(y ~ group, data = df)$p.value, error = function(e) NA)
welch <- tryCatch(oneway.test(y ~ group, data = df, var.equal = FALSE), error = function(e) NULL)

mk <- function(term, est) list(term = term, estimate = est, se = NULL, n_obs = n)

res <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = list(
    mk("F", F_stat),
    mk("df_num", df_num),
    mk("df_den", df_den),
    mk("p_value", p_val)
  ),
  method_metadata = list(
    estimator = "one-way ANOVA (aov, classical equal-variance F test)",
    vcov = "classical (homoskedastic)"
  ),
  diagnostics = list(
    n_groups = nlevels(df$group),
    group_sizes = grp_n,
    group_means = grp_mean,
    bartlett_p_value = bart,
    welch_F = if (!is.null(welch)) unname(welch$statistic) else NA,
    welch_p_value = if (!is.null(welch)) unname(welch$p.value) else NA
  )
)

writeLines(toJSON(res, auto_unbox = TRUE, digits = NA, null = "null", na = "null", pretty = TRUE),
           "result.json")
