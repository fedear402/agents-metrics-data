suppressPackageStartupMessages(library(jsonlite))

df <- read.csv("input.csv")
df <- df[is.finite(df$score) & is.finite(df$participated) & is.finite(df$earnings), ]
sub <- df[abs(df$score) < 1, ]
n <- nrow(sub)

w <- 1 - abs(sub$score)
D <- as.numeric(sub$score >= 0)
X <- cbind(1, D, sub$score, D * sub$score)
colnames(X) <- c("const", "D", "score", "D_score")

y <- sub$earnings
d <- sub$participated

XtWX <- crossprod(X, X * w)
bread <- solve(XtWX)
b_y <- bread %*% crossprod(X, w * y)
b_d <- bread %*% crossprod(X, w * d)
e_y <- as.vector(y - X %*% b_y)
e_d <- as.vector(d - X %*% b_d)

# HC0 sandwich pieces (no dof correction)
sy <- X * (w * e_y)
sd <- X * (w * e_d)
V_yy <- bread %*% crossprod(sy, sy) %*% bread
V_dd <- bread %*% crossprod(sd, sd) %*% bread
V_yd <- bread %*% crossprod(sy, sd) %*% bread

k <- 2  # coefficient on D = right limit minus left limit
rf <- b_y[k]
fs <- b_d[k]
var_rf <- V_yy[k, k]
var_fs <- V_dd[k, k]
cov_rf_fs <- V_yd[k, k]

te <- rf / fs
g <- c(1 / fs, -rf / fs^2)
Vj <- matrix(c(var_rf, cov_rf_fs, cov_rf_fs, var_fs), 2, 2)
var_te <- as.numeric(t(g) %*% Vj %*% g)

res <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = te, se = sqrt(var_te), n_obs = n),
    list(term = "reduced_form", estimate = rf, se = sqrt(var_rf), n_obs = n),
    list(term = "first_stage", estimate = fs, se = sqrt(var_fs), n_obs = n)
  ),
  method_metadata = list(
    estimator = "fuzzy RD: local linear, triangular kernel, bandwidth 1, cutoff 0, separate slopes; Wald ratio",
    vcov = "HC0 joint sandwich; delta method for ratio including RF-FS covariance"
  ),
  diagnostics = list(
    cov_rf_fs = cov_rf_fs,
    n_left = sum(D == 0),
    n_right = sum(D == 1)
  )
)

writeLines(toJSON(res, auto_unbox = TRUE, digits = 12, pretty = TRUE), "result.json")
