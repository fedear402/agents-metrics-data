suppressPackageStartupMessages(library(jsonlite))

df <- read.csv("./input.csv", stringsAsFactors = FALSE)
df$y <- suppressWarnings(as.numeric(df$y))
df <- df[!is.na(df$y) & !is.na(df$group) & trimws(as.character(df$group)) != "", ]
df$group <- factor(trimws(as.character(df$group)))
n <- nrow(df)

fit <- aov(y ~ group, data = df)
tab <- summary(fit)[[1]]
Fv <- tab[["F value"]][1]
dfn <- tab[["Df"]][1]
dfd <- tab[["Df"]][2]
pv <- tab[["Pr(>F)"]][1]

mk <- function(t, e) list(term = t, estimate = unname(as.numeric(e)), se = NULL, n_obs = n)

res <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = list(mk("F", Fv), mk("df_num", dfn), mk("df_den", dfd), mk("p_value", pv)),
  method_metadata = list(estimator = "one-way ANOVA (aov, classical equal-variance F test)",
                         vcov = "classical"),
  diagnostics = list(n_groups = nlevels(df$group),
                     group_sizes = as.list(table(df$group)))
)

writeLines(toJSON(res, auto_unbox = TRUE, digits = NA, null = "null", pretty = TRUE),
           "result.json")
