suppressPackageStartupMessages(library(jsonlite))

cw  <- read.csv("crosswalk.csv", stringsAsFactors = FALSE, colClasses = "character")
tr  <- read.csv("trade.csv", stringsAsFactors = FALSE, colClasses = c(code = "character"))
ar  <- read.csv("areas.csv", stringsAsFactors = FALSE)
em  <- read.csv("employment.csv", stringsAsFactors = FALSE)
oc  <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

cw$code <- trimws(cw$code); cw$industry <- trimws(cw$industry)
tr$code <- trimws(tr$code)
ar$vintage <- tolower(trimws(ar$vintage))
em$vintage <- tolower(trimws(em$vintage))
em$industry <- trimws(as.character(em$industry))
ar$area <- as.character(ar$area); em$area <- as.character(em$area); oc$area <- as.character(oc$area)
ar$period <- as.character(ar$period); em$period <- as.character(em$period)
oc$period <- as.character(oc$period); tr$period <- as.character(tr$period)

trj <- merge(tr, cw, by = "code")
inds <- unique(cw$industry)

# full grid, missing cells are zero
keys <- unique(ar[, c("area", "period", "vintage")])
grid <- merge(keys, data.frame(industry = inds, stringsAsFactors = FALSE), by = NULL)
emA <- aggregate(employment ~ area + period + vintage + industry, data = em, FUN = sum)
grid <- merge(grid, emA, by = c("area", "period", "vintage", "industry"), all.x = TRUE)
grid$employment[is.na(grid$employment)] <- 0

nat <- aggregate(employment ~ period + vintage + industry, data = grid, FUN = sum)
names(nat)[names(nat) == "employment"] <- "nat_emp"
grid <- merge(grid, nat, by = c("period", "vintage", "industry"))
tot <- ar[, c("area", "period", "vintage", "total_employment")]
grid <- merge(grid, tot, by = c("area", "period", "vintage"))
grid <- merge(grid, trj[, c("period", "industry", "us_change", "other_change", "price_index", "years")],
              by = c("period", "industry"))

chg <- ifelse(grid$vintage == "base", grid$us_change, grid$other_change)
grid$term <- (grid$employment / grid$total_employment) * (chg / grid$nat_emp) /
  (grid$price_index / 100) / 1000 * (10 / grid$years)

xb <- aggregate(term ~ area + period, data = grid[grid$vintage == "base", ], FUN = sum)
names(xb)[3] <- "x"
ze <- aggregate(term ~ area + period, data = grid[grid$vintage == "early", ], FUN = sum)
names(ze)[3] <- "z"
pop <- ar[ar$vintage == "base", c("area", "period", "population")]

d <- merge(oc, xb, by = c("area", "period"))
d <- merge(d, ze, by = c("area", "period"))
d <- merge(d, pop, by = c("area", "period"))
d <- d[complete.cases(d[, c("change_pp", "control", "x", "z", "population")]), ]

pnum <- as.numeric(d$period)
X <- cbind(1, pnum, d$control, d$x)
Z <- cbind(1, pnum, d$control, d$z)
y <- d$change_pp
w <- d$population
XWZ <- t(X) %*% (Z * w)
ZWZ <- t(Z) %*% (Z * w)
ZWy <- t(Z) %*% (y * w)
ZWX <- t(Z) %*% (X * w)
A <- XWZ %*% solve(ZWZ)
beta <- solve(A %*% ZWX, A %*% ZWy)
iv_slope <- beta[4]

n <- nrow(d)
p0 <- sort(unique(pnum))
get <- function(col, per) {
  v <- d[[col]][d$area == "0" & pnum == per]
  if (length(v) == 0) NA else v[1]
}
ex0 <- get("x", 0); ex1 <- get("x", 1); iz0 <- get("z", 0)

est <- list(
  list(term = "iv_slope", estimate = iv_slope, se = NULL, n_obs = n),
  list(term = "exposure_area0_period0", estimate = ex0, se = NULL, n_obs = n),
  list(term = "exposure_area0_period1", estimate = ex1, se = NULL, n_obs = n),
  list(term = "instrument_area0_period0", estimate = iz0, se = NULL, n_obs = n)
)
res <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = est,
  method_metadata = list(
    estimator = "weighted 2SLS",
    weights = "base-vintage population",
    regressors = c("intercept", "period", "control", "x"),
    instruments = c("intercept", "period", "control", "z")
  ),
  diagnostics = list(
    n_obs = n,
    n_industries = length(inds),
    coefficients = as.numeric(beta)
  )
)
write_json(res, "result.json", auto_unbox = TRUE, digits = NA, null = "null", pretty = TRUE)
