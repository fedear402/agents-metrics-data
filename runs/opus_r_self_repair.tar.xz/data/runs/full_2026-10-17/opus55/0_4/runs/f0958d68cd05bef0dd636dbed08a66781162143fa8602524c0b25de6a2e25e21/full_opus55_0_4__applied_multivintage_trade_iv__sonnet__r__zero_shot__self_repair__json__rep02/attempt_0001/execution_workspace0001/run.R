suppressPackageStartupMessages(library(jsonlite))

cw  <- read.csv("crosswalk.csv", colClasses = c(code = "character"), stringsAsFactors = FALSE)
tr  <- read.csv("trade.csv", colClasses = c(code = "character"), stringsAsFactors = FALSE)
ar  <- read.csv("areas.csv", stringsAsFactors = FALSE)
em  <- read.csv("employment.csv", stringsAsFactors = FALSE)
out <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

cw$code <- trimws(cw$code); tr$code <- trimws(tr$code)
cw$industry <- as.character(cw$industry); em$industry <- as.character(em$industry)
ar$vintage <- trimws(ar$vintage); em$vintage <- trimws(em$vintage)

# trade joined to industries
td <- merge(tr, cw, by = "code")
td <- aggregate(cbind(us_change, other_change) ~ period + industry + price_index + years,
                data = td, FUN = sum)

inds <- sort(unique(cw$industry))

# full grid with zeros for missing cells
grid <- unique(ar[, c("area", "period", "vintage")])
grid <- merge(grid, data.frame(industry = inds, stringsAsFactors = FALSE), by = NULL)
em_agg <- aggregate(employment ~ area + period + vintage + industry, data = em, FUN = sum)
full <- merge(grid, em_agg, by = c("area", "period", "vintage", "industry"), all.x = TRUE)
full$employment[is.na(full$employment)] <- 0

nat <- aggregate(employment ~ period + vintage + industry, data = full, FUN = sum)
names(nat)[names(nat) == "employment"] <- "nat_emp"
full <- merge(full, nat, by = c("period", "vintage", "industry"))
full <- merge(full, ar[, c("area", "period", "vintage", "total_employment")],
              by = c("area", "period", "vintage"))
full <- merge(full, td, by = c("period", "industry"))

full$chg <- ifelse(full$vintage == "base", full$us_change, full$other_change)
full$term <- (full$employment / full$total_employment) * (full$chg / full$nat_emp) /
  (full$price_index / 100) / 1000 * (10 / full$years)

xb <- aggregate(term ~ area + period, data = full[full$vintage == "base", ], FUN = sum)
names(xb)[3] <- "x"
ze <- aggregate(term ~ area + period, data = full[full$vintage == "early", ], FUN = sum)
names(ze)[3] <- "z"

pop <- ar[ar$vintage == "base", c("area", "period", "population")]
d <- merge(out, xb, by = c("area", "period"))
d <- merge(d, ze, by = c("area", "period"))
d <- merge(d, pop, by = c("area", "period"))
d <- d[order(d$period, d$area), ]

per <- as.numeric(d$period)
X <- cbind(1, per, d$control, d$x)
Z <- cbind(1, per, d$control, d$z)
y <- d$change_pp
w <- d$population
XWZ <- t(X) %*% (w * Z)
ZWZ <- t(Z) %*% (w * Z)
ZWy <- t(Z) %*% (w * y)
ZWX <- t(Z) %*% (w * X)
A <- XWZ %*% solve(ZWZ)
beta <- solve(A %*% ZWX, A %*% ZWy)
iv_slope <- beta[4]

pv <- sort(unique(d$period))
x00 <- d$x[d$area == 0 & d$period == pv[1]]
x01 <- d$x[d$area == 0 & d$period == pv[2]]
z00 <- d$z[d$area == 0 & d$period == pv[1]]
n <- nrow(d)

mk <- function(t, e) list(term = t, estimate = unname(e), se = NULL, n_obs = as.integer(n))
res <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = list(
    mk("iv_slope", iv_slope),
    mk("exposure_area0_period0", x00),
    mk("exposure_area0_period1", x01),
    mk("instrument_area0_period0", z00)
  ),
  method_metadata = list(
    estimator = "weighted 2SLS",
    weights = "base-vintage population",
    instruments = c("intercept", "period", "control", "z"),
    exposure = "base vintage shares, us_change; instrument uses early vintage, other_change"
  ),
  diagnostics = list(
    n_obs = as.integer(n),
    n_industries = length(inds),
    coefficients = unname(as.numeric(beta))
  )
)
write_json(res, "result.json", auto_unbox = TRUE, digits = NA, null = "null", pretty = TRUE)
