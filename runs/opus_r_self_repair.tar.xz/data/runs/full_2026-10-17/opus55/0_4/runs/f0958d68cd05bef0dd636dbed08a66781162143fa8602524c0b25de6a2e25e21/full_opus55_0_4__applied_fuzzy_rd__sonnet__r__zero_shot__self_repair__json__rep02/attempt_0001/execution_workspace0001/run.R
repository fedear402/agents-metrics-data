suppressPackageStartupMessages(library(jsonlite))

df <- read.csv("input.csv")
df <- df[!is.na(df$score) & !is.na(df$participated) & !is.na(df$earnings), ]
d <- df[abs(df$score) < 1, ]
n <- nrow(d)

s <- d$score
right <- as.numeric(s >= 0)
w <- 1 - abs(s)
X <- cbind(1, right, s, right * s)
y <- d$earnings
p <- d$participated

XtWX <- crossprod(X, X * w)
bread <- solve(XtWX)
by <- bread %*% crossprod(X, w * y)
bp <- bread %*% crossprod(X, w * p)
ey <- as.vector(y - X %*% by)
ep <- as.vector(p - X %*% bp)

Sy <- X * (w * ey)
Sp <- X * (w * ep)
Vyy <- bread %*% crossprod(Sy, Sy) %*% bread
Vpp <- bread %*% crossprod(Sp, Sp) %*% bread
Vyp <- bread %*% crossprod(Sy, Sp) %*% bread

rf <- by[2]
fs <- bp[2]
var_rf <- Vyy[2, 2]
var_fs <- Vpp[2, 2]
cov_rf_fs <- Vyp[2, 2]

te <- rf / fs
g <- c(1 / fs, -rf / fs^2)
V <- matrix(c(var_rf, cov_rf_fs, cov_rf_fs, var_fs), 2, 2)
se_te <- sqrt(as.numeric(t(g) %*% V %*% g))

res <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = te, se = se_te, n_obs = n),
    list(term = "reduced_form", estimate = rf, se = sqrt(var_rf), n_obs = n),
    list(term = "first_stage", estimate = fs, se = sqrt(var_fs), n_obs = n)
  ),
  method_metadata = list(
    estimator = "fuzzy RD, local linear, triangular kernel, bandwidth 1, cutoff 0, ratio of WLS discontinuities",
    vcov = "HC0 joint sandwich (no dof correction), delta method with covariance for ratio"
  ),
  diagnostics = list(cov_rf_fs = cov_rf_fs, n_left = sum(right == 0), n_right = sum(right == 1))
)

write_json(res, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE)
