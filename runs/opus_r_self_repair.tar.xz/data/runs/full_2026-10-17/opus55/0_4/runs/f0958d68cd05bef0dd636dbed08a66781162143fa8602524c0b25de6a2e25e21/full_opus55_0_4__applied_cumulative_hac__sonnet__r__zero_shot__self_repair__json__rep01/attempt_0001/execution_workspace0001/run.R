d <- read.csv("input.csv", stringsAsFactors = FALSE)
d$date <- as.Date(d$date)
d <- d[order(d$date), ]
y <- log(d$sales)
dv <- c(NA, diff(log(d$vix)))
T <- length(y)
L <- 15
X <- sapply(1:L, function(k) c(rep(NA, k), dv[1:(T - k)]))
colnames(X) <- paste0("lag_", 1:L)
ok <- complete.cases(cbind(y, X))
yy <- y[ok]; XX <- cbind(1, X[ok, , drop = FALSE])
N <- length(yy); K <- ncol(XX)
XtXi <- solve(crossprod(XX))
b <- drop(XtXi %*% crossprod(XX, yy))
e <- drop(yy - XX %*% b)
U <- XX * e
S <- crossprod(U)
for (j in 1:L) {
  w <- 1 - j / (L + 1)
  G <- crossprod(U[(j + 1):N, , drop = FALSE], U[1:(N - j), , drop = FALSE])
  S <- S + w * (G + t(G))
}
V <- XtXi %*% S %*% XtXi * (N / (N - K))
g <- c(0, rep(1, L))
cum <- sum(b[-1]); cse <- sqrt(drop(t(g) %*% V %*% g))
se <- sqrt(diag(V))
res <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(term = "cumulative_response", estimate = cum, se = cse, n_obs = N),
    list(term = "lag_1", estimate = unname(b[2]), se = unname(se[2]), n_obs = N),
    list(term = "lag_15", estimate = unname(b[16]), se = unname(se[16]), n_obs = N)
  ),
  method_metadata = list(estimator = "OLS distributed lag",
                         vcov = "Newey-West Bartlett maxlag 15, scaled N/(N-16)"),
  diagnostics = setNames(list(), character(0))
)
jsonlite::write_json(res, "result.json", auto_unbox = TRUE, digits = 12, pretty = TRUE)
