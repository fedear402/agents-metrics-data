suppressPackageStartupMessages(library(jsonlite))

d <- read.csv("input.csv", stringsAsFactors = FALSE)
d <- d[order(d$region_id, d$industry_id), ]

reg <- d[!duplicated(d$region_id), c("region_id", "region_weight", "x", "y")]
reg$e <- reg$region_weight / sum(reg$region_weight)

d$sz <- d$share * d$shock
zr <- aggregate(sz ~ region_id, data = d, FUN = sum)
names(zr)[2] <- "z"
reg <- merge(reg, zr, by = "region_id")

wiv <- function(y, x, z, w) {
  X <- cbind(1, x); Z <- cbind(1, z)
  A <- t(Z) %*% (w * X)
  b <- solve(A, t(Z) %*% (w * y))
  list(b = as.vector(b), X = X, Z = Z, A = A)
}

e <- reg$e
b_reg <- wiv(reg$y, reg$x, reg$z, e)$b
fs_reg <- wiv(reg$x, reg$z, reg$z, e)$b

wm <- function(v) sum(e * v)
reg$y0 <- reg$y - wm(reg$y)
reg$x0 <- reg$x - wm(reg$x)
reg$z0 <- reg$z - wm(reg$z)

dd <- merge(d[, c("region_id", "industry_id", "share", "shock")],
            reg[, c("region_id", "e", "y0", "x0", "z0")], by = "region_id")
dd$es <- dd$e * dd$share
ind <- aggregate(cbind(es, es_y = es * y0, es_x = es * x0, es_z = es * z0) ~ industry_id,
                 data = transform(dd, es_y = es * y0, es_x = es * x0, es_z = es * z0),
                 FUN = sum)
shk <- d[!duplicated(d$industry_id), c("industry_id", "shock")]
ind <- merge(ind, shk, by = "industry_id")
ind <- ind[ind$es > 0, ]
s <- ind$es
ybar <- ind$es_y / s; xbar <- ind$es_x / s; zbar <- ind$es_z / s
g <- ind$shock
N <- nrow(ind)

hc1_iv <- function(y, x, z, w) {
  f <- wiv(y, x, z, w)
  u <- as.vector(y - f$X %*% f$b)
  Ainv <- solve(f$A)
  meat <- t(f$Z) %*% (f$Z * (w * u)^2)
  V <- Ainv %*% meat %*% t(Ainv) * N / (N - 2)
  list(b = f$b, se = sqrt(diag(V)))
}

eff <- hc1_iv(ybar, xbar, g, s)
fs <- hc1_iv(xbar, zbar, g, s)
eff_shocks <- 1 / sum(s^2)

res <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = b_reg[2], se = eff$se[2], n_obs = N),
    list(term = "first_stage", estimate = fs_reg[2], se = fs$se[2], n_obs = N),
    list(term = "effective_shocks", estimate = eff_shocks, se = NULL, n_obs = N)
  ),
  method_metadata = list(
    estimator = "Weighted regional 2SLS with shift-share instrument; BHJ shock-level equivalent IV",
    vcov = "Shock-level HC1 (N/(N-2)), structural IV residuals, analytic weights s_n"
  ),
  diagnostics = list(
    shock_level_effect = eff$b[2],
    shock_level_first_stage = fs$b[2],
    n_regions = nrow(reg)
  )
)

writeLines(toJSON(res, auto_unbox = TRUE, digits = 12, null = "null", pretty = TRUE),
           "result.json")
