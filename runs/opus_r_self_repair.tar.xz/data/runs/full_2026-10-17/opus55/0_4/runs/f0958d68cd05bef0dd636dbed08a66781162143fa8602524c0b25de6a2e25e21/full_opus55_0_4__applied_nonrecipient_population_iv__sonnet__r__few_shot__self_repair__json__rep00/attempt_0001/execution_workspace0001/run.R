library(jsonlite)
h <- read.csv("households.csv")
census <- read.csv("census.csv")
d <- h[h$recipient == 0, ]
d <- d[complete.cases(d[, c("eligible","dose","instrument","baseline","outcome","weight")]), ]
e <- d$eligible; ne <- 1 - e
C <- cbind(ne, e, d$baseline * ne, d$baseline * e)
X <- cbind(C, d$dose * ne, d$dose * e)
Z <- cbind(C, d$instrument * ne, d$instrument * e)
sw <- sqrt(d$weight)
Xw <- X * sw; Zw <- Z * sw; yw <- d$outcome * sw
fitted <- qr.fitted(qr(Zw), Xw)
b <- as.numeric(qr.coef(qr(fitted), yw))
slopes <- b[5:6]
mdose <- sapply(0:1, function(g) { a <- d$eligible == g; weighted.mean(d$dose[a], d$weight[a]) })
effect <- slopes * mdose
pop <- census$nonrecipient_population[match(0:1, census$eligible)]
popeff <- sum(effect * pop) / sum(pop)
n <- nrow(d)
est <- list(
  list(term = "ineligible_effect", estimate = effect[1], se = NA, n_obs = n),
  list(term = "eligible_nonrecipient_effect", estimate = effect[2], se = NA, n_obs = n),
  list(term = "population_effect", estimate = popeff, se = NA, n_obs = n)
)
res <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = est,
  method_metadata = list(
    estimator = "weighted 2SLS, group-interacted, no common intercept",
    endogenous = c("dose*(1-eligible)", "dose*eligible"),
    exogenous = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"),
    excluded_instruments = c("instrument*(1-eligible)", "instrument*eligible"),
    effect_definition = "dose slope times weighted mean dose; zero-dose counterfactual",
    aggregation = "census nonrecipient_population weights"
  ),
  diagnostics = list(
    n_obs = n,
    n_ineligible = sum(d$eligible == 0),
    n_eligible = sum(d$eligible == 1),
    dose_slope_ineligible = slopes[1],
    dose_slope_eligible = slopes[2],
    weighted_mean_dose_ineligible = mdose[1],
    weighted_mean_dose_eligible = mdose[2],
    census_weights = pop
  )
)
write_json(res, "result.json", auto_unbox = TRUE, digits = NA, na = "null", pretty = TRUE)
