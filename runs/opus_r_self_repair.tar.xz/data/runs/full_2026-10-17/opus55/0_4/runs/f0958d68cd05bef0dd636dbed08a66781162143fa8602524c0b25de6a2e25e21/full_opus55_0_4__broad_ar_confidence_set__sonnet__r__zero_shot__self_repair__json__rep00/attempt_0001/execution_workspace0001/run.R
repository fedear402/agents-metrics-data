d <- read.csv("input.csv")
n <- nrow(d)
y <- d$y; e <- d$endog
X <- cbind(1, d$x)
W <- cbind(1, d$x, d$z1, d$z2)
resid_on <- function(M, v) as.numeric(qr.resid(qr(M), v))
yX <- resid_on(X, y); eX <- resid_on(X, e)
yW <- resid_on(W, y); eW <- resid_on(W, e)
df2 <- n - 4
cval <- qf(0.95, 2, df2)
k1 <- df2 / 2
# u'(k1*(M_X - M_W) - c*M_W)u <= 0, u = y - b*e
qf2 <- function(a, b, aW, bW) k1 * (sum(a * b) - sum(aW * bW)) - cval * sum(aW * bW)
A <- qf2(eX, eX, eW, eW)
B <- -2 * qf2(yX, eX, yW, eW)
C <- qf2(yX, yX, yW, yW)
Fstat <- function(b) {
  rr <- sum((yX - b * eX)^2); ru <- sum((yW - b * eW)^2)
  ((rr - ru) / 2) / (ru / df2)
}
disc <- B^2 - 4 * A * C
if (disc < 0) stop("No finite boundary points")
r <- sort(c((-B - sqrt(disc)) / (2 * A), (-B + sqrt(disc)) / (2 * A)))
unbounded <- as.numeric(A < 0)
accepts_zero <- as.numeric(Fstat(0) <= cval)
ar1 <- Fstat(1)
library(jsonlite)
est <- function(t, v) list(term = t, estimate = v, se = NULL, n_obs = n)
res <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = list(
    est("boundary_low", r[1]),
    est("boundary_high", r[2]),
    est("accepts_zero", accepts_zero),
    est("unbounded", unbounded),
    est("ar_f_at_one", ar1)
  ),
  method_metadata = list(estimator = "Anderson-Rubin test inversion (analytic quadratic)",
                         vcov = "homoskedastic F"),
  diagnostics = list(quad_A = A, quad_B = B, quad_C = C, crit = cval)
)
write(toJSON(res, auto_unbox = TRUE, digits = NA, null = "null", pretty = TRUE), "result.json")
