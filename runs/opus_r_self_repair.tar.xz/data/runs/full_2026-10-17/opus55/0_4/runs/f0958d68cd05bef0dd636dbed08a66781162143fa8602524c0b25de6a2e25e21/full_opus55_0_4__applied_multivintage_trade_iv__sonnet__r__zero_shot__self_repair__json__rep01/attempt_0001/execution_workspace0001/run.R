suppressPackageStartupMessages(library(jsonlite))

cw  <- read.csv("crosswalk.csv", colClasses = c(code = "character"), stringsAsFactors = FALSE)
tr  <- read.csv("trade.csv", colClasses = c(code = "character"), stringsAsFactors = FALSE)
ar  <- read.csv("areas.csv", stringsAsFactors = FALSE)
em  <- read.csv("employment.csv", stringsAsFactors = FALSE)
out <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

cw$code <- trimws(cw$code); tr$code <- trimws(tr$code)
ar$vintage <- trimws(ar$vintage); em$vintage <- trimws(em$vintage)
cw$industry <- as.character(cw$industry); em$industry <- as.character(em$industry)

trj <- merge(tr, cw, by = "code")
trp <- aggregate(cbind(us_change, other_change) ~ period + industry, data = trj, FUN = sum)
pp  <- aggregate(cbind(price_index, years) ~ period, data = tr, FUN = function(v) v[1])
trp <- merge(trp, pp, by = "period")

em$employment[is.na(em$employment)] <- 0
em <- aggregate(employment ~ area + period + vintage + industry, data = em, FUN = sum)
nat <- aggregate(employment ~ period + vintage + industry, data = em, FUN = sum)
names(nat)[names(nat) == "employment"] <- "nat_emp"

build <- function(vint, chg) {
  e <- em[em$vintage == vint, ]
  n <- nat[nat$vintage == vint, c("period", "industry", "nat_emp")]
  a <- ar[ar$vintage == vint, c("area", "period", "total_employment")]
  e <- merge(e, n, by = c("period", "industry"))
  e <- merge(e, a, by = c("area", "period"))
  e <- merge(e, trp, by = c("period", "industry"))
  e$term <- (e$employment / e$total_employment) * (e[[chg]] / e$nat_emp) /
    (e$price_index / 100) / 1000 * (10 / e$years)
  r <- aggregate(term ~ area + period, data = e, FUN = sum)
  # areas with no rows get zero exposure
  full <- unique(ar[ar$vintage == vint, c("area", "period")])
  r <- merge(full, r, by = c("area", "period"), all.x = TRUE)
  r$term[is.na(r$term)] <- 0
  r
}

xb <- build("base", "us_change");    names(xb)[3] <- "x"
ze <- build("early", "other_change"); names(ze)[3] <- "z"
pop <- ar[ar$vintage == "base", c("area", "period", "population")]

d <- merge(out, xb, by = c("area", "period"))
d <- merge(d, ze, by = c("area", "period"))
d <- merge(d, pop, by = c("area", "period"))
d <- d[complete.cases(d[, c("change_pp", "control", "x", "z", "population")]), ]

per <- as.numeric(d$period)
X <- cbind(1, per, d$control, d$x)
Z <- cbind(1, per, d$control, d$z)
y <- d$change_pp
w <- d$population
XWZ <- t(X) %*% (Z * w)
ZWZ <- t(Z) %*% (Z * w)
ZWy <- t(Z) %*% (y * w)
A <- XWZ %*% solve(ZWZ)
beta <- solve(A %*% t(XWZ), A %*% ZWy)
iv_slope <- beta[4, 1]
n_obs <- as.integer(nrow(d))

g <- function(df, col, a, p) df[[col]][df$area == a & as.numeric(df$period) == p][1]
x00 <- g(xb, "x", 0, 0)
x01 <- g(xb, "x", 0, 1)
z00 <- g(ze, "z", 0, 0)

mk <- function(t, v) list(term = t, estimate = unname(v), se = NULL, n_obs = n_obs)
res <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = list(
    mk("iv_slope", iv_slope),
    mk("exposure_area0_period0", x00),
    mk("exposure_area0_period1", x01),
    mk("instrument_area0_period0", z00)
  ),
  method_metadata = list(
    estimator = "weighted 2SLS",
    weights = "base-vintage population",
    regressors = c("intercept", "period", "control", "x"),
    instruments = c("intercept", "period", "control", "z")
  ),
  diagnostics = list(
    n_obs = n_obs,
    coefficients = as.list(setNames(as.numeric(beta), c("intercept", "period", "control", "x")))
  )
)
write_json(res, "result.json", auto_unbox = TRUE, digits = NA, null = "null", pretty = TRUE)
