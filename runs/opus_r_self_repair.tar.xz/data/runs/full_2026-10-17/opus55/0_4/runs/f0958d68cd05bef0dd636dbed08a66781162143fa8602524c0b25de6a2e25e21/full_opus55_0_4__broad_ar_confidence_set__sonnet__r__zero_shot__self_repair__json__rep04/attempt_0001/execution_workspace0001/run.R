library(jsonlite)
d <- read.csv("input.csv")
n <- nrow(d)
y <- d$y; e <- d$endog
W <- cbind(1, d$x)
Z <- cbind(1, d$x, d$z1, d$z2)
rW <- function(v) qr.resid(qr(W), v)
rZ <- function(v) qr.resid(qr(Z), v)
cv <- qf(0.95, 2, n - 4)
k <- 2 * cv / (n - 4)

# u'Au with A = (M_W - M_Z) - k*M_Z = M_W - (1+k) M_Z
qf_form <- function(a, b) sum(rW(a) * rW(b)) - (1 + k) * sum(rZ(a) * rZ(b))
A2 <- qf_form(e, e); A1 <- qf_form(e, y); A0 <- qf_form(y, y)
# q(beta) = A2*beta^2 - 2*A1*beta + A0 ; accept iff q <= 0
Fstat <- function(b) {
  u <- y - b * e
  rr <- sum(rW(u)^2); ru <- sum(rZ(u)^2)
  ((rr - ru) / 2) / (ru / (n - 4))
}
disc <- A1^2 - A2 * A0
roots <- if (disc >= 0) sort(c((A1 - sqrt(disc)) / A2, (A1 + sqrt(disc)) / A2)) else c(NA, NA)
unbounded <- as.numeric(A2 < 0 || (A2 == 0))
accepts_zero <- as.numeric(Fstat(0) <= cv)
f1 <- Fstat(1)

mk <- function(t, v) list(term = t, estimate = v, se = NULL, n_obs = n)
res <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = list(
    mk("boundary_low", roots[1]),
    mk("boundary_high", roots[2]),
    mk("accepts_zero", accepts_zero),
    mk("unbounded", unbounded),
    mk("ar_f_at_one", f1)
  ),
  method_metadata = list(estimator = "Anderson-Rubin test inversion (analytic quadratic)",
                         vcov = "homoskedastic F"),
  diagnostics = list(quad_a = A2, quad_b = -2 * A1, quad_c = A0, crit = cv,
                     disjoint = as.numeric(A2 < 0 && disc > 0))
)
write(toJSON(res, auto_unbox = TRUE, null = "null", digits = NA, pretty = TRUE), "result.json")
