library(jsonlite)

hh <- read.csv("households.csv")
cen <- read.csv("census.csv")

d <- hh[hh$recipient == 0, ]
d <- d[complete.cases(d[, c("eligible", "instrument", "dose", "baseline", "weight", "outcome")]), ]
n <- nrow(d)

e <- d$eligible
ie <- 1 - e
X <- cbind(dose_inel = d$dose * ie, dose_el = d$dose * e,
           inel = ie, el = e, base_inel = d$baseline * ie, base_el = d$baseline * e)
Z <- cbind(inel = ie, el = e, base_inel = d$baseline * ie, base_el = d$baseline * e,
           z_inel = d$instrument * ie, z_el = d$instrument * e)
y <- d$outcome
w <- d$weight

ZW <- Z * w
A <- crossprod(Z, ZW)
XtZ <- crossprod(X, ZW)
ZtY <- crossprod(ZW, y)
P <- XtZ %*% solve(A)
beta <- solve(P %*% t(XtZ), P %*% ZtY)
beta <- setNames(as.vector(beta), colnames(X))

m0 <- sum(w[e == 0] * d$dose[e == 0]) / sum(w[e == 0])
m1 <- sum(w[e == 1] * d$dose[e == 1]) / sum(w[e == 1])
eff0 <- unname(beta["dose_inel"] * m0)
eff1 <- unname(beta["dose_el"] * m1)

p0 <- sum(cen$nonrecipient_population[cen$eligible == 0])
p1 <- sum(cen$nonrecipient_population[cen$eligible == 1])
pop <- (p0 * eff0 + p1 * eff1) / (p0 + p1)

est <- list(
  list(term = "ineligible_effect", estimate = eff0, se = NA, n_obs = as.integer(n)),
  list(term = "eligible_nonrecipient_effect", estimate = eff1, se = NA, n_obs = as.integer(n)),
  list(term = "population_effect", estimate = pop, se = NA, n_obs = as.integer(n))
)

res <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = est,
  method_metadata = list(
    estimator = "weighted 2SLS, group-interacted, no common intercept",
    sample = "recipient == 0",
    effect_definition = "dose slope times weighted mean dose within group; zero-dose counterfactual (synthetic convention)",
    aggregation = "census nonrecipient_population weights"
  ),
  diagnostics = list(
    n_ineligible = as.integer(sum(e == 0)),
    n_eligible = as.integer(sum(e == 1)),
    slope_ineligible = unname(beta["dose_inel"]),
    slope_eligible = unname(beta["dose_el"]),
    mean_dose_ineligible = m0,
    mean_dose_eligible = m1,
    pop_ineligible = p0,
    pop_eligible = p1
  )
)

write_json(res, "result.json", auto_unbox = TRUE, digits = NA, na = "null", pretty = TRUE)
