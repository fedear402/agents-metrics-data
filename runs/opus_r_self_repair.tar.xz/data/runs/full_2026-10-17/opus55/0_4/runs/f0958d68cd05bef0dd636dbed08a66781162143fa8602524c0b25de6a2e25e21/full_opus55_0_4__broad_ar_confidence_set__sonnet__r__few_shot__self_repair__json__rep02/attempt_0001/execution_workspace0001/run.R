d <- read.csv("input.csv")
d <- d[complete.cases(d[, c("y","endog","x","z1","z2")]), ]
n <- nrow(d)
q <- 2L
ry <- residuals(lm(y ~ x, data = d)); rd <- residuals(lm(endog ~ x, data = d))
fy <- lm(y ~ x + z1 + z2, data = d); fd <- lm(endog ~ x + z1 + z2, data = d)
uy <- residuals(fy); ud <- residuals(fd)
df <- df.residual(fy)
critical <- qf(0.95, q, df)
k <- q * critical / df
A <- sum(rd^2) - (1 + k) * sum(ud^2)
B <- -2 * (sum(ry * rd) - (1 + k) * sum(uy * ud))
C <- sum(ry^2) - (1 + k) * sum(uy^2)
disc <- B^2 - 4 * A * C
if (abs(A) > 1e-10 && disc > 0) {
  r <- c((-B - sqrt(disc)) / (2 * A), (-B + sqrt(disc)) / (2 * A))
  bounds <- sort(r)
} else if (abs(A) <= 1e-10 && abs(B) > 0) {
  bounds <- c(-C / B, NA)
} else {
  bounds <- c(NA, NA)
}
accepts <- function(beta) A * beta^2 + B * beta + C <= 0
unbounded <- as.integer(A < 0 || (abs(A) <= 1e-10 && B != 0))
if (A > 0 && disc <= 0) unbounded <- 0L
arF <- function(beta) {
  t <- d$y - beta * d$endog
  r0 <- lm(t ~ x, data = d); r1 <- lm(t ~ x + z1 + z2, data = d)
  ((deviance(r0) - deviance(r1)) / q) / (deviance(r1) / df)
}
f1 <- arF(1)
mk <- function(term, est) list(term = term, estimate = unname(est), se = NULL, n_obs = n)
res <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = list(
    mk("boundary_low", bounds[1]),
    mk("boundary_high", bounds[2]),
    mk("accepts_zero", as.numeric(accepts(0))),
    mk("unbounded", as.numeric(unbounded)),
    mk("ar_f_at_one", f1)
  ),
  method_metadata = list(estimator = "Anderson-Rubin test inversion (analytic quadratic)",
                         vcov = "homoskedastic F"),
  diagnostics = list(A = A, B = B, C = C, critical = critical, df = df,
                     f_low = if (!is.na(bounds[1])) arF(bounds[1]) else NULL,
                     f_high = if (!is.na(bounds[2])) arF(bounds[2]) else NULL)
)
jsonlite::write_json(res, "result.json", auto_unbox = TRUE, null = "null",
                     digits = 16, pretty = TRUE)
