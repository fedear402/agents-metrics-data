library(jsonlite)
d <- read.csv("input.csv")
d <- d[complete.cases(d[, c("y","endog","x","z1","z2")]), ]
n <- nrow(d)
W <- cbind(1, d$x)
Xf <- cbind(W, d$z1, d$z2)
MW <- function(v) v - W %*% solve(crossprod(W), crossprod(W, v))
Rf <- function(v) v - Xf %*% solve(crossprod(Xf), crossprod(Xf, v))
yt <- MW(d$y); et <- MW(d$endog)
yr <- Rf(d$y); er <- Rf(d$endog)
crit <- qf(0.95, 2, n - 4)

Ffun <- function(b) {
  u <- d$y - b * d$endog
  f1 <- lm(u ~ d$x + d$z1 + d$z2)
  f0 <- lm(u ~ d$x)
  rss1 <- sum(resid(f1)^2); rss0 <- sum(resid(f0)^2)
  ((rss0 - rss1) / 2) / (rss1 / (n - 4))
}

# explained part = M_W - R
Pyy <- sum(yt^2) - sum(yr^2); Pye <- sum(yt*et) - sum(yr*er); Pee <- sum(et^2) - sum(er^2)
Ryy <- sum(yr^2); Rye <- sum(yr*er); Ree <- sum(er^2)
k <- 2 * crit / (n - 4)
a <- Pee - k * Ree
bq <- -2 * (Pye - k * Rye)
cq <- Pyy - k * Ryy
disc <- bq^2 - 4 * a * cq
if (disc >= 0 && a != 0) {
  r <- sort(c((-bq - sqrt(disc)) / (2 * a), (-bq + sqrt(disc)) / (2 * a)))
} else r <- c(NA, NA)
unb <- as.numeric(a < 0 || (a == 0))
acc0 <- as.numeric(Ffun(0) <= crit)
f1v <- Ffun(1)

res <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = list(
    list(term = "boundary_low", estimate = r[1], se = NULL, n_obs = n),
    list(term = "boundary_high", estimate = r[2], se = NULL, n_obs = n),
    list(term = "accepts_zero", estimate = acc0, se = NULL, n_obs = n),
    list(term = "unbounded", estimate = unb, se = NULL, n_obs = n),
    list(term = "ar_f_at_one", estimate = f1v, se = NULL, n_obs = n)
  ),
  method_metadata = list(estimator = "Anderson-Rubin test inversion (analytic quadratic)",
                         vcov = "homoskedastic F"),
  diagnostics = list(quad_a = a, quad_b = bq, quad_c = cq, crit = crit)
)
write(toJSON(res, auto_unbox = TRUE, null = "null", digits = 12, na = "null"), "result.json")
