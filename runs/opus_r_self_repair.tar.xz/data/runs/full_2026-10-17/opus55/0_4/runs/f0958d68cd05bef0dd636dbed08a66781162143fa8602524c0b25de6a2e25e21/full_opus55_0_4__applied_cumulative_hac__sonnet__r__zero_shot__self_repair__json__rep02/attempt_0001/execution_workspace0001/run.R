suppressPackageStartupMessages({
  library(jsonlite)
})

df <- read.csv("input.csv", stringsAsFactors = FALSE)
df$date <- as.Date(df$date)
df <- df[order(df$date), ]
n_all <- nrow(df)

ly <- log(df$sales)
dv <- c(NA, diff(log(df$vix)))

K <- 15
X <- matrix(NA_real_, n_all, K)
for (k in 1:K) {
  X[, k] <- c(rep(NA, k), dv[1:(n_all - k)])
}
colnames(X) <- paste0("lag_", 1:K)

ok <- complete.cases(cbind(ly, X))
y <- ly[ok]
Xm <- cbind(1, X[ok, , drop = FALSE])
colnames(Xm)[1] <- "(Intercept)"
N <- length(y)
p <- ncol(Xm)

XtX_inv <- solve(crossprod(Xm))
beta <- as.vector(XtX_inv %*% crossprod(Xm, y))
names(beta) <- colnames(Xm)
u <- as.vector(y - Xm %*% beta)

S <- Xm * u
L <- 15
meat <- crossprod(S)
for (j in 1:L) {
  w <- 1 - j / (L + 1)
  G <- crossprod(S[(j + 1):N, , drop = FALSE], S[1:(N - j), , drop = FALSE])
  meat <- meat + w * (G + t(G))
}
V <- XtX_inv %*% meat %*% XtX_inv * (N / (N - p))

idx <- 2:(K + 1)
a <- rep(0, p); a[idx] <- 1
cum <- sum(beta[idx])
cum_se <- sqrt(as.numeric(t(a) %*% V %*% a))

se <- sqrt(diag(V))

res <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(term = "cumulative_response", estimate = cum, se = cum_se, n_obs = N),
    list(term = "lag_1", estimate = unname(beta["lag_1"]), se = unname(se[2]), n_obs = N),
    list(term = "lag_15", estimate = unname(beta["lag_15"]), se = unname(se[K + 1]), n_obs = N)
  ),
  method_metadata = list(
    estimator = "OLS distributed lag of log(sales) on lags 1-15 of dlog(vix)",
    vcov = "Newey-West HAC, Bartlett kernel, max lag 15, scaled by N/(N-16)"
  ),
  diagnostics = list()
)

write_json(res, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE)
