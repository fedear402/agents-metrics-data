suppressPackageStartupMessages(library(jsonlite))

d <- read.csv("./input.csv")
d <- d[order(d$t), ]
y <- as.numeric(d$y)
y <- y[!is.na(y)]
n <- length(y)

fit <- arima(y, order = c(1, 1, 1), include.mean = FALSE, method = "ML")
p <- predict(fit, n.ahead = 1)
fc <- as.numeric(p$pred[1])
se <- as.numeric(p$se[1])
z <- qnorm(0.975)
lo <- fc - z * se
hi <- fc + z * se

res <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = list(
    list(term = "forecast", estimate = fc, se = se, n_obs = n),
    list(term = "lower_95", estimate = lo, se = NULL, n_obs = n),
    list(term = "upper_95", estimate = hi, se = NULL, n_obs = n)
  ),
  method_metadata = list(
    estimator = "ARIMA(1,1,1) exact Gaussian ML (stats::arima, method='ML'), no constant/drift",
    vcov = "forecast SE from Kalman filter; normal 95% PI"
  ),
  diagnostics = list(
    ar1 = unname(coef(fit)["ar1"]),
    ma1 = unname(coef(fit)["ma1"]),
    sigma2 = fit$sigma2,
    loglik = fit$loglik,
    aic = fit$aic,
    converged = fit$code == 0
  )
)

writeLines(toJSON(res, auto_unbox = TRUE, digits = NA, null = "null", pretty = TRUE), "result.json")
