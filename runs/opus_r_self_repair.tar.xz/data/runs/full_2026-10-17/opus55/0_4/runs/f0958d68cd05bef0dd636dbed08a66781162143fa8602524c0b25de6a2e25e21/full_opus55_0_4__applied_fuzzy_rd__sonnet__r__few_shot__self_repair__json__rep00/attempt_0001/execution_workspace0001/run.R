library(jsonlite)
d <- read.csv("input.csv")
d <- d[is.finite(d$score) & is.finite(d$participated) & is.finite(d$earnings), ]
d <- d[abs(d$score) < 1, ]
n <- nrow(d)
w <- 1 - abs(d$score)
above <- as.numeric(d$score >= 0)
X <- cbind(1, above, d$score, above * d$score)
Y <- cbind(d$earnings, d$participated)
bread <- solve(crossprod(X, w * X))
coefficients <- bread %*% crossprod(X, w * Y)
residuals <- Y - X %*% coefficients
contrast <- c(0, 1, 0, 0)
jumps <- drop(contrast %*% coefficients)
loading <- w * drop(X %*% bread %*% contrast)
influence <- loading * residuals
joint <- crossprod(influence)
rf <- jumps[1]; fs <- jumps[2]
te <- rf / fs
gradient <- c(1 / fs, -rf / fs^2)
te_se <- sqrt(drop(t(gradient) %*% joint %*% gradient))
row <- function(term, estimate, se) {
  list(term = term, estimate = unname(as.numeric(estimate)),
       se = unname(as.numeric(se)), n_obs = as.integer(n))
}
out <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    row("treatment_effect", te, te_se),
    row("reduced_form", rf, sqrt(joint[1, 1])),
    row("first_stage", fs, sqrt(joint[2, 2]))
  ),
  method_metadata = list(
    estimator = "fuzzy RD, local linear, triangular kernel, bandwidth 1, separate slopes; ratio of reduced form to first stage",
    vcov = "HC0 joint sandwich covariance, delta method for ratio, no bias correction"
  ),
  diagnostics = list(rf_fs_covariance = joint[1, 2], n_left = sum(above == 0), n_right = sum(above == 1))
)
write_json(out, "result.json", auto_unbox = TRUE, digits = 16, pretty = TRUE, null = "null")
