suppressPackageStartupMessages(library(jsonlite))
d <- read.csv("input.csv")
d <- d[complete.cases(d[, c("y", "x", "z")]), ]
n <- nrow(d)
X <- cbind(1, d$x, d$z)
k <- ncol(X)
Y1 <- as.numeric(d$y == 1); Y2 <- as.numeric(d$y == 2)
Ymat <- cbind(Y1, Y2)

probs <- function(b) {
  B <- matrix(b, k, 2)
  e <- exp(X %*% B)
  den <- 1 + rowSums(e)
  e / den
}
b <- rep(0, 2 * k)
for (it in 1:200) {
  P <- probs(b)
  g <- as.vector(crossprod(X, Ymat - P))
  H <- matrix(0, 2 * k, 2 * k)
  for (j in 1:2) for (l in 1:2) {
    w <- if (j == l) P[, j] * (1 - P[, j]) else -P[, j] * P[, l]
    H[((j - 1) * k + 1):(j * k), ((l - 1) * k + 1):(l * k)] <- crossprod(X * w, X)
  }
  step <- solve(H, g)
  b <- b + step
  if (max(abs(step)) < 1e-12) break
}
P <- probs(b)
H <- matrix(0, 2 * k, 2 * k)
for (j in 1:2) for (l in 1:2) {
  w <- if (j == l) P[, j] * (1 - P[, j]) else -P[, j] * P[, l]
  H[((j - 1) * k + 1):(j * k), ((l - 1) * k + 1):(l * k)] <- crossprod(X * w, X)
}
V <- solve(H)
se <- sqrt(diag(V))
p2 <- exp(b[4]) / (1 + exp(b[1]) + exp(b[4]))

mk <- function(t, e, s) list(term = t, estimate = e, se = s, n_obs = n)
res <- list(
  task_id = "broad_multinomial_logit",
  platform = "r",
  estimates = list(
    mk("x_cat1", b[2], se[2]),
    mk("z_cat1", b[3], se[3]),
    mk("x_cat2", b[5], se[5]),
    mk("z_cat2", b[6], se[6]),
    mk("prob_cat2_zero", p2, NULL)
  ),
  method_metadata = list(estimator = "multinomial logit MLE (Newton-Raphson), base outcome 0",
                         vcov = "inverse observed information (OIM)"),
  diagnostics = list(iterations = it, loglik = sum(log(cbind(1 - rowSums(P), P)[cbind(1:n, d$y + 1)])))
)
writeLines(toJSON(res, auto_unbox = TRUE, digits = NA, null = "null", pretty = TRUE), "result.json")
