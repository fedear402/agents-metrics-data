library(jsonlite)
d <- read.csv("input.csv")
n <- nrow(d)
d <- d[complete.cases(d[, c("y","x","z")]), ]
X <- cbind(1, d$x, d$z)
y <- as.integer(d$y)
k <- ncol(X)
Y1 <- as.numeric(y == 1); Y2 <- as.numeric(y == 2)
probs <- function(b) {
  e1 <- exp(X %*% b[1:k]); e2 <- exp(X %*% b[(k+1):(2*k)])
  den <- 1 + e1 + e2
  cbind(1/den, e1/den, e2/den)
}
nll <- function(b) {
  eta1 <- X %*% b[1:k]; eta2 <- X %*% b[(k+1):(2*k)]
  m <- pmax(0, eta1, eta2)
  lse <- m + log(exp(-m) + exp(eta1 - m) + exp(eta2 - m))
  -sum(Y1 * eta1 + Y2 * eta2 - lse)
}
gr <- function(b) {
  P <- probs(b)
  -c(crossprod(X, Y1 - P[,2]), crossprod(X, Y2 - P[,3]))
}
b <- rep(0, 2*k)
for (it in 1:3) {
  o <- optim(b, nll, gr, method = "BFGS", control = list(maxit = 10000, reltol = 1e-14))
  b <- o$par
}
# Newton refinement with analytic Hessian
hess <- function(b) {
  P <- probs(b)
  H <- matrix(0, 2*k, 2*k)
  w11 <- P[,2]*(1-P[,2]); w22 <- P[,3]*(1-P[,3]); w12 <- -P[,2]*P[,3]
  H[1:k,1:k] <- crossprod(X, X*w11)
  H[(k+1):(2*k),(k+1):(2*k)] <- crossprod(X, X*w22)
  H[1:k,(k+1):(2*k)] <- crossprod(X, X*w12)
  H[(k+1):(2*k),1:k] <- t(H[1:k,(k+1):(2*k)])
  H
}
for (it in 1:50) {
  step <- solve(hess(b), -gr(b))
  b <- b + step
  if (max(abs(step)) < 1e-12) break
}
V <- solve(hess(b))
se <- sqrt(diag(V))
p0 <- exp(c(0, b[1], b[k+1])); p0 <- p0 / sum(p0)
res <- list(
  task_id = "broad_multinomial_logit",
  platform = "r",
  estimates = list(
    list(term = "x_cat1", estimate = b[2], se = se[2], n_obs = n),
    list(term = "z_cat1", estimate = b[3], se = se[3], n_obs = n),
    list(term = "x_cat2", estimate = b[k+2], se = se[k+2], n_obs = n),
    list(term = "z_cat2", estimate = b[k+3], se = se[k+3], n_obs = n),
    list(term = "prob_cat2_zero", estimate = p0[3], se = NULL, n_obs = n)
  ),
  method_metadata = list(estimator = "multinomial logit MLE (base outcome 0)",
                         vcov = "inverse observed information (Hessian)"),
  diagnostics = list(loglik = -nll(b), n_used = nrow(d))
)
res$estimates[[5]]["se"] <- list(NULL)
writeLines(toJSON(res, auto_unbox = TRUE, digits = 12, null = "null", pretty = TRUE), "result.json")
