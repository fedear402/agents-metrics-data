df <- read.csv("./input.csv")
df <- df[order(df$t), ]
y <- as.numeric(df$y)
n <- length(y)

fit <- arima(y, order = c(1, 1, 1), method = "ML", include.mean = FALSE)
pr <- predict(fit, n.ahead = 1)
fc <- as.numeric(pr$pred[1])
se <- as.numeric(pr$se[1])
z <- qnorm(0.975)
lo <- fc - z * se
hi <- fc + z * se

num <- function(x) formatC(x, digits = 15, format = "g")
co <- coef(fit)
json <- paste0(
  '{\n',
  '  "task_id": "arima_forecast",\n',
  '  "platform": "r",\n',
  '  "estimates": [\n',
  '    {"term": "forecast", "estimate": ', num(fc), ', "se": ', num(se), ', "n_obs": ', n, '},\n',
  '    {"term": "lower_95", "estimate": ', num(lo), ', "se": null, "n_obs": ', n, '},\n',
  '    {"term": "upper_95", "estimate": ', num(hi), ', "se": null, "n_obs": ', n, '}\n',
  '  ],\n',
  '  "method_metadata": {"estimator": "ARIMA(1,1,1) exact ML via stats::arima, no constant/drift", "vcov": "Hessian-based ML; forecast SE from Kalman filter"},\n',
  '  "diagnostics": {"ar1": ', num(co["ar1"]), ', "ma1": ', num(co["ma1"]),
  ', "sigma2": ', num(fit$sigma2), ', "loglik": ', num(fit$loglik),
  ', "aic": ', num(fit$aic), ', "forecast_t": ', max(df$t) + 1, '}\n',
  '}\n'
)
writeLines(json, "result.json")
