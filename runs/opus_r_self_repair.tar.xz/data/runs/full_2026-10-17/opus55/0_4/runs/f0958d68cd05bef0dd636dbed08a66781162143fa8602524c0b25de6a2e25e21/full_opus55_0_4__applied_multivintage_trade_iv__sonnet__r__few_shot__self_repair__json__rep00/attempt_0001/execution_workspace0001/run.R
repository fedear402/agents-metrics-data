suppressMessages(library(jsonlite))
cw <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
tr <- read.csv("trade.csv", stringsAsFactors = FALSE)
ar <- read.csv("areas.csv", stringsAsFactors = FALSE)
em <- read.csv("employment.csv", stringsAsFactors = FALSE)
oc <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

cw$code <- as.character(cw$code); tr$code <- as.character(tr$code)
tr <- merge(tr, cw, by = "code")
ar$vintage <- trimws(as.character(ar$vintage)); em$vintage <- trimws(as.character(em$vintage))
inds <- sort(unique(as.character(cw$industry)))
em$industry <- as.character(em$industry)
em <- aggregate(employment ~ area + period + vintage + industry, data = em, FUN = sum)

keys <- unique(oc[c("area", "period")])
emp_val <- function(a, p, v, j) {
  s <- em$employment[em$area == a & em$period == p & em$vintage == v & em$industry == j]
  if (length(s) == 0) 0 else sum(s)
}
nat <- function(p, v, j) sum(em$employment[em$period == p & em$vintage == v & em$industry == j])

build <- function(v, chg) {
  sapply(seq_len(nrow(keys)), function(i) {
    a <- keys$area[i]; p <- keys$period[i]
    tot <- ar$total_employment[ar$area == a & ar$period == p & ar$vintage == v][1]
    s <- 0
    for (j in inds) {
      t <- tr[tr$period == p & as.character(tr$industry) == j, ]
      if (nrow(t) == 0) next
      e <- emp_val(a, p, v, j)
      s <- s + (e / tot) * (t[[chg]][1] / nat(p, v, j)) / (t$price_index[1] / 100) / 1000 * (10 / t$years[1])
    }
    s
  })
}
keys$x <- build("base", "us_change")
keys$z <- build("early", "other_change")
d <- merge(oc, keys, by = c("area", "period"))
pop <- ar[ar$vintage == "base", c("area", "period", "population")]
pop <- pop[!duplicated(pop[c("area", "period")]), ]
d <- merge(d, pop, by = c("area", "period"))
d <- d[complete.cases(d[c("change_pp", "control", "x", "z", "population")]), ]

w <- d$population
C <- cbind(1, d$period, d$control)
X <- cbind(C, d$x) * sqrt(w); Z <- cbind(C, d$z) * sqrt(w)
fit <- qr.fitted(qr(Z), X)
b <- as.numeric(qr.coef(qr(fit), d$change_pp * sqrt(w)))
slope <- b[length(b)]
n <- nrow(d)

g <- function(a, p, col) keys[[col]][keys$area == a & keys$period == p][1]
vals <- list(iv_slope = slope,
             exposure_area0_period0 = g(0, 0, "x"),
             exposure_area0_period1 = g(0, 1, "x"),
             instrument_area0_period0 = g(0, 0, "z"))
est <- lapply(names(vals), function(k) list(term = k, estimate = unname(vals[[k]]), se = NULL, n_obs = as.integer(n)))
res <- list(task_id = "applied_multivintage_trade_iv", platform = "r", estimates = est,
            method_metadata = list(estimator = "weighted 2SLS", weights = "base population",
                                   exogenous = c("intercept", "period", "control"), instrument = "z"),
            diagnostics = list(n_obs = as.integer(n), n_industries = length(inds)))
write_json(res, "result.json", auto_unbox = TRUE, digits = NA, null = "null", pretty = TRUE)
