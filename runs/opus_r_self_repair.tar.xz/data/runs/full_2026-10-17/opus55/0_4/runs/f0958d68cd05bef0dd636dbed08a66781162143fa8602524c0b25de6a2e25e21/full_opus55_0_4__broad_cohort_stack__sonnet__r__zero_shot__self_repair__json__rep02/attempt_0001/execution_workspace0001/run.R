library(jsonlite)

d <- read.csv("input.csv")
d$g[is.na(d$g)] <- 0

ests <- list()
total_n <- 0
wsum <- 0
wnum <- 0
diag <- list()

for (c in c(3, 5, 7)) {
  times <- (c - 2):(c + 2)
  s <- d[d$time %in% times & (d$g == c | d$g == 0 | d$g > c + 2), ]
  cnt <- table(s$id)
  keep <- names(cnt)[cnt == length(times)]
  s <- s[as.character(s$id) %in% keep, ]
  s$did <- as.numeric(s$g == c & s$time >= c)
  fit <- lm(y ~ did + factor(id) + factor(time), data = s)
  est <- unname(coef(fit)["did"])
  n <- nrow(s)
  ntr <- length(unique(s$id[s$g == c]))
  total_n <- total_n + n
  wsum <- wsum + ntr
  wnum <- wnum + ntr * est
  diag[[paste0("treated_units_g", c)]] <- ntr
  diag[[paste0("units_g", c)]] <- length(unique(s$id))
  ests[[length(ests) + 1]] <- list(term = paste0("att_g", c), estimate = est,
                                   se = NA, n_obs = n)
}

ests[[length(ests) + 1]] <- list(term = "att_weighted", estimate = wnum / wsum,
                                 se = NA, n_obs = total_n)

res <- list(
  task_id = "broad_cohort_stack",
  platform = "r",
  estimates = ests,
  method_metadata = list(weights = "retained treated units per cohort"),
  diagnostics = diag
)

write_json(res, "result.json", auto_unbox = TRUE, digits = NA, na = "null", pretty = TRUE)
