d <- read.csv("input.csv")
res <- list(); ests <- c(); ns <- c(); ws <- c()
for (cc in c(3,5,7)) {
  s <- d[d$time >= cc-2 & d$time <= cc+2 & (d$g == cc | d$g == 0 | d$g > cc+2), ]
  cnt <- table(s$id)
  keep <- names(cnt)[cnt == 5]
  s <- s[as.character(s$id) %in% keep, ]
  s$did <- as.numeric(s$g == cc & s$time >= cc)
  est <- unname(coef(lm(y ~ did + factor(id) + factor(time), data = s))["did"])
  ests <- c(ests, est); ns <- c(ns, nrow(s))
  ws <- c(ws, length(unique(s$id[s$g == cc])))
  res[[length(res)+1]] <- list(term = paste0("att_g", cc), estimate = est, se = NULL, n_obs = nrow(s))
}
res[[4]] <- list(term = "att_weighted", estimate = sum(ests*ws)/sum(ws), se = NULL, n_obs = sum(ns))
out <- list(task_id = "broad_cohort_stack", platform = "r", estimates = res,
            method_metadata = setNames(list(), character(0)),
            diagnostics = list(treated_units = setNames(as.list(ws), c("g3","g5","g7"))))
jsonlite::write_json(out, "result.json", auto_unbox = TRUE, null = "null", digits = 16)
