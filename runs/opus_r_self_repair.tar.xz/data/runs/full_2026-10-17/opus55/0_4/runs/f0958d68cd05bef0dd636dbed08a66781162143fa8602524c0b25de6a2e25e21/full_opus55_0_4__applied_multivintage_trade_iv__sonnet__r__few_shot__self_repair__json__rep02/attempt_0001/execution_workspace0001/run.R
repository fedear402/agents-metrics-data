suppressPackageStartupMessages(library(jsonlite))
cw <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
tr <- read.csv("trade.csv", stringsAsFactors = FALSE)
ar <- read.csv("areas.csv", stringsAsFactors = FALSE)
em <- read.csv("employment.csv", stringsAsFactors = FALSE)
oc <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

cw$code <- as.character(cw$code); tr$code <- as.character(tr$code)
tr <- merge(tr, cw, by = "code")
tr$industry <- as.character(tr$industry)
em$industry <- as.character(em$industry)
em$vintage <- trimws(as.character(em$vintage)); ar$vintage <- trimws(as.character(ar$vintage))
inds <- sort(unique(as.character(cw$industry)))

keys <- unique(ar[, c("area", "period")])
keys <- keys[order(keys$period, keys$area), ]

emp_of <- function(a, p, v, j) {
  s <- em$employment[em$area == a & em$period == p & em$vintage == v & em$industry == j]
  if (length(s) == 0) 0 else sum(s, na.rm = TRUE)
}
nat_of <- function(p, v, j) sum(em$employment[em$period == p & em$vintage == v & em$industry == j], na.rm = TRUE)

expo <- function(a, p, v, chg) {
  tot <- ar$total_employment[ar$area == a & ar$period == p & ar$vintage == v][1]
  val <- 0
  for (j in inds) {
    t <- tr[tr$period == p & tr$industry == j, ][1, ]
    val <- val + (emp_of(a, p, v, j) / tot) * (t[[chg]] / nat_of(p, v, j)) /
      (t$price_index / 100) / 1000 * (10 / t$years)
  }
  val
}

keys$x <- mapply(function(a, p) expo(a, p, "base", "us_change"), keys$area, keys$period)
keys$z <- mapply(function(a, p) expo(a, p, "early", "other_change"), keys$area, keys$period)
pop <- ar[ar$vintage == "base", c("area", "period", "population")]
pop <- pop[!duplicated(pop[, c("area", "period")]), ]
d <- merge(merge(keys, pop, by = c("area", "period")), oc, by = c("area", "period"))

w <- d$population
C <- cbind(1, d$period, d$control)
X <- cbind(C, d$x) * sqrt(w); Z <- cbind(C, d$z) * sqrt(w)
fitted <- qr.fitted(qr(Z), X)
b <- as.numeric(qr.coef(qr(fitted), d$change_pp * sqrt(w)))
iv_slope <- b[4]
n <- nrow(d)

ps <- sort(unique(d$period))
g <- function(p, col) d[[col]][d$area == 0 & d$period == p][1]
vals <- list(iv_slope = iv_slope,
             exposure_area0_period0 = g(ps[1], "x"),
             exposure_area0_period1 = g(ps[2], "x"),
             instrument_area0_period0 = g(ps[1], "z"))
est <- lapply(names(vals), function(k) list(term = k, estimate = vals[[k]], se = NULL, n_obs = as.integer(n)))
res <- list(task_id = "applied_multivintage_trade_iv", platform = "r", estimates = est,
            method_metadata = list(method = "weighted 2SLS", weight = "base population",
                                   instruments = "intercept, period, control, z"),
            diagnostics = list(n_obs = as.integer(n), n_industries = length(inds)))
write_json(res, "result.json", auto_unbox = TRUE, digits = NA, null = "null", pretty = TRUE)
