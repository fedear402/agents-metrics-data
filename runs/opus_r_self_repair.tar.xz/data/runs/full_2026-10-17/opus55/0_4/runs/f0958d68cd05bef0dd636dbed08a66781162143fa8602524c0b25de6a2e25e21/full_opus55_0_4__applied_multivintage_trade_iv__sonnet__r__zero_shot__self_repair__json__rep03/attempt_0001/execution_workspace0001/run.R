suppressPackageStartupMessages(library(jsonlite))

cw <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
tr <- read.csv("trade.csv", stringsAsFactors = FALSE)
ar <- read.csv("areas.csv", stringsAsFactors = FALSE)
em <- read.csv("employment.csv", stringsAsFactors = FALSE)
oc <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

cw$code <- as.character(cw$code); tr$code <- as.character(tr$code)
cw$industry <- as.character(cw$industry); em$industry <- as.character(em$industry)
ar$vintage <- trimws(tolower(ar$vintage)); em$vintage <- trimws(tolower(em$vintage))

trj <- merge(tr, cw, by = "code")
inds <- sort(unique(cw$industry))

# full grid of area-period-vintage-industry, missing = 0
grid <- expand.grid(area = unique(ar$area), period = unique(ar$period),
                    vintage = c("base", "early"), industry = inds,
                    stringsAsFactors = FALSE)
grid <- merge(grid, unique(ar[, c("area", "period")]), by = c("area", "period"))
emA <- aggregate(employment ~ area + period + vintage + industry, data = em, FUN = sum)
g <- merge(grid, emA, by = c("area", "period", "vintage", "industry"), all.x = TRUE)
g$employment[is.na(g$employment)] <- 0

nat <- aggregate(employment ~ period + vintage + industry, data = g, FUN = sum)
names(nat)[4] <- "nat_emp"
g <- merge(g, nat, by = c("period", "vintage", "industry"))
g <- merge(g, ar[, c("area", "period", "vintage", "total_employment")],
           by = c("area", "period", "vintage"))
g <- merge(g, trj[, c("period", "industry", "us_change", "other_change", "price_index", "years")],
           by = c("period", "industry"))

g$chg <- ifelse(g$vintage == "base", g$us_change, g$other_change)
g$term <- (g$employment / g$total_employment) * (g$chg / g$nat_emp) /
  (g$price_index / 100) / 1000 * (10 / g$years)

xb <- aggregate(term ~ area + period, data = g[g$vintage == "base", ], FUN = sum); names(xb)[3] <- "x"
ze <- aggregate(term ~ area + period, data = g[g$vintage == "early", ], FUN = sum); names(ze)[3] <- "z"

pop <- ar[ar$vintage == "base", c("area", "period", "population")]
d <- merge(oc, xb, by = c("area", "period"))
d <- merge(d, ze, by = c("area", "period"))
d <- merge(d, pop, by = c("area", "period"))
d <- d[order(d$period, d$area), ]

X <- cbind(1, as.numeric(d$period), d$control, d$x)
Z <- cbind(1, as.numeric(d$period), d$control, d$z)
y <- d$change_pp; w <- d$population
W <- diag(w)
ZWZi <- solve(t(Z) %*% W %*% Z)
Pz <- t(X) %*% W %*% Z %*% ZWZi
b <- solve(Pz %*% t(Z) %*% W %*% X, Pz %*% t(Z) %*% W %*% y)
iv <- b[4]

pmin_ <- sort(unique(d$period))
a0 <- min(d$area)
ex0 <- d$x[d$area == a0 & d$period == pmin_[1]]
ex1 <- d$x[d$area == a0 & d$period == pmin_[2]]
in0 <- d$z[d$area == a0 & d$period == pmin_[1]]
n <- nrow(d)

mk <- function(t, e) list(term = t, estimate = e, se = NULL, n_obs = n)
res <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = list(mk("iv_slope", iv), mk("exposure_area0_period0", ex0),
                   mk("exposure_area0_period1", ex1), mk("instrument_area0_period0", in0)),
  method_metadata = list(estimator = "weighted 2SLS", weights = "base population",
                         instruments = c("intercept", "period", "control", "z")),
  diagnostics = list(n_obs = n, n_industries = length(inds),
                     first_stage_coefs = as.numeric(solve(t(Z) %*% W %*% Z, t(Z) %*% W %*% d$x)))
)
write_json(res, "result.json", auto_unbox = TRUE, digits = NA, null = "null")
