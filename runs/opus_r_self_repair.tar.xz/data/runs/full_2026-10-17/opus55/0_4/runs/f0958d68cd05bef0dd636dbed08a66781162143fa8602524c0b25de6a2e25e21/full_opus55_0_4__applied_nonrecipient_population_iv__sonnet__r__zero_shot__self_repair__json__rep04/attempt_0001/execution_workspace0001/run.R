suppressPackageStartupMessages(library(jsonlite))

hh <- read.csv("households.csv", stringsAsFactors = FALSE)
cen <- read.csv("census.csv", stringsAsFactors = FALSE)

d <- hh[hh$recipient == 0, ]
d <- d[complete.cases(d[, c("eligible", "instrument", "dose", "baseline", "weight", "outcome")]), ]
n <- nrow(d)

e <- d$eligible
ne <- 1 - e
X <- cbind(ne = ne, el = e, b_ne = d$baseline * ne, b_el = d$baseline * e,
           dose_ne = d$dose * ne, dose_el = d$dose * e)
Z <- cbind(ne = ne, el = e, b_ne = d$baseline * ne, b_el = d$baseline * e,
           z_ne = d$instrument * ne, z_el = d$instrument * e)
y <- d$outcome
w <- d$weight

ZW <- Z * w
Pz <- solve(crossprod(ZW, Z))
A <- crossprod(X, ZW) %*% Pz
beta <- solve(A %*% crossprod(ZW, X), A %*% crossprod(ZW, y))
beta <- setNames(as.vector(beta), colnames(X))

wm <- function(x, ww) sum(x * ww) / sum(ww)
i0 <- e == 0; i1 <- e == 1
mdose0 <- wm(d$dose[i0], w[i0])
mdose1 <- wm(d$dose[i1], w[i1])
eff0 <- unname(beta["dose_ne"] * mdose0)
eff1 <- unname(beta["dose_el"] * mdose1)

p0 <- sum(cen$nonrecipient_population[cen$eligible == 0])
p1 <- sum(cen$nonrecipient_population[cen$eligible == 1])
pop_eff <- (p0 * eff0 + p1 * eff1) / (p0 + p1)

mk <- function(term, est) list(term = term, estimate = est, se = NULL, n_obs = as.integer(n))
est <- list(
  mk("ineligible_effect", eff0),
  mk("eligible_nonrecipient_effect", eff1),
  mk("population_effect", pop_eff)
)

res <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = est,
  method_metadata = list(
    estimator = "weighted 2SLS, group-interacted, no common intercept",
    endogenous = c("dose*(1-eligible)", "dose*eligible"),
    exogenous = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"),
    excluded_instruments = c("instrument*(1-eligible)", "instrument*eligible"),
    sample = "recipient == 0",
    group_effect = "dose slope times weighted mean dose (zero-dose counterfactual, synthetic convention)",
    aggregation = "census nonrecipient_population weights"
  ),
  diagnostics = list(
    n_obs = as.integer(n),
    n_ineligible = as.integer(sum(i0)),
    n_eligible_nonrecipient = as.integer(sum(i1)),
    coefficients = as.list(beta),
    mean_dose_ineligible = mdose0,
    mean_dose_eligible = mdose1,
    pop_ineligible = p0,
    pop_eligible = p1
  )
)

write_json(res, "result.json", auto_unbox = TRUE, digits = NA, null = "null", pretty = TRUE)
