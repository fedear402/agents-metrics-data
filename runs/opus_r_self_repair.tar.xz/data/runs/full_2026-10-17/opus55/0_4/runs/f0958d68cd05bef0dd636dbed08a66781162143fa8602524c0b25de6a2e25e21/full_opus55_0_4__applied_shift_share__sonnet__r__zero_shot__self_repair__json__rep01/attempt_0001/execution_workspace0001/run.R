suppressPackageStartupMessages({
  library(jsonlite)
})

d <- read.csv("input.csv", stringsAsFactors = FALSE)
d <- d[order(d$region_id, d$industry_id), ]

# Region-level data (one observation per region)
reg <- d[!duplicated(d$region_id), c("region_id", "region_weight", "x", "y")]
reg$e <- reg$region_weight / sum(reg$region_weight)

# Shift-share instrument
d$sz <- d$share * d$shock
zr <- tapply(d$sz, d$region_id, sum)
reg$z <- as.numeric(zr[as.character(reg$region_id)])

# Weighted IV helper: y on intercept + x, instrument w, weights wt
wiv <- function(y, x, w, wt) {
  X <- cbind(1, x); Z <- cbind(1, w)
  W <- diag(wt)
  A <- t(Z) %*% W %*% X
  b <- solve(A, t(Z) %*% W %*% y)
  u <- as.numeric(y - X %*% b)
  n <- length(y); k <- 2
  Ainv <- solve(A)
  meat <- t(Z) %*% diag((wt * u)^2) %*% Z
  V <- Ainv %*% meat %*% t(Ainv) * n / (n - k)
  list(b = as.numeric(b), se = sqrt(diag(V)))
}

# Regional 2SLS and first stage
reg_iv <- wiv(reg$y, reg$x, reg$z, reg$e)
fs_reg <- wiv(reg$x, reg$z, reg$z, reg$e)  # OLS of x on z

# Demean
wm <- function(v) sum(reg$e * v)
reg$y0 <- reg$y - wm(reg$y)
reg$x0 <- reg$x - wm(reg$x)
reg$z0 <- reg$z - wm(reg$z)

m <- match(d$region_id, reg$region_id)
d$e <- reg$e[m]
d$es <- d$e * d$share
d$y0 <- reg$y0[m]; d$x0 <- reg$x0[m]; d$z0 <- reg$z0[m]

inds <- sort(unique(d$industry_id))
s_n <- as.numeric(tapply(d$es, d$industry_id, sum)[as.character(inds)])
agg <- function(v) as.numeric(tapply(d$es * v, d$industry_id, sum)[as.character(inds)]) / s_n
ybar <- agg(d$y0); xbar <- agg(d$x0); zbar <- agg(d$z0)
g <- as.numeric(tapply(d$shock, d$industry_id, function(v) v[1])[as.character(inds)])

keep <- s_n > 0
N <- sum(keep)

ss_eff <- wiv(ybar[keep], xbar[keep], g[keep], s_n[keep])
ss_fs <- wiv(xbar[keep], zbar[keep], g[keep], s_n[keep])

eff_shocks <- 1 / sum((s_n / sum(s_n))^2)

res <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = reg_iv$b[2], se = ss_eff$se[2], n_obs = N),
    list(term = "first_stage", estimate = fs_reg$b[2], se = ss_fs$se[2], n_obs = N),
    list(term = "effective_shocks", estimate = eff_shocks, se = NULL, n_obs = N)
  ),
  method_metadata = list(
    estimator = "weighted 2SLS with shift-share instrument; BHJ shock-level equivalent IV",
    vcov = "shock-level HC1 (N/(N-2)), structural IV residuals, analytic weights s_n"
  ),
  diagnostics = list(
    shock_level_slope = ss_eff$b[2],
    shock_level_first_stage_slope = ss_fs$b[2],
    n_regions = nrow(reg),
    n_industries = length(inds)
  )
)

writeLines(toJSON(res, auto_unbox = TRUE, digits = NA, null = "null", pretty = TRUE), "result.json")
