library(jsonlite)
data <- read.csv("input.csv", stringsAsFactors = FALSE)
data$date <- as.Date(data$date)
data <- data[order(data$date), ]
n <- nrow(data)
dv <- c(NA, diff(log(data$vix)))
L <- 15
lagmat <- sapply(1:L, function(k) c(rep(NA, k), head(dv, n - k)))
colnames(lagmat) <- paste0("lag_", 1:L)
df <- data.frame(y = log(data$sales), lagmat)
df <- df[complete.cases(df), ]
fit <- lm(as.formula(paste("y ~", paste(colnames(lagmat), collapse = "+"))), data = df)
X <- model.matrix(fit)
b <- coef(fit)
N <- nrow(X)
p <- ncol(X)
S <- X * residuals(fit)
meat <- crossprod(S)
hl <- 15
for (j in seq_len(hl)) {
  lp <- crossprod(S[(j + 1):N, , drop = FALSE], S[1:(N - j), , drop = FALSE])
  meat <- meat + (1 - j / (hl + 1)) * (lp + t(lp))
}
bread <- solve(crossprod(X))
V <- N / (N - p) * bread %*% meat %*% bread
cvec <- c(0, rep(1, L))
cum <- sum(cvec * b)
cse <- sqrt(drop(t(cvec) %*% V %*% cvec))
row <- function(term, est, se) list(term = term, estimate = unname(as.numeric(est)),
                                    se = unname(as.numeric(se)), n_obs = as.integer(N))
out <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    row("cumulative_response", cum, cse),
    row("lag_1", b[2], sqrt(V[2, 2])),
    row("lag_15", b[16], sqrt(V[16, 16]))
  ),
  method_metadata = list(estimator = "OLS distributed lag (15 lags of dlog vix)",
                         vcov = "Newey-West Bartlett maxlag 15, scaled N/(N-16)"),
  diagnostics = setNames(list(), character(0))
)
write_json(out, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
