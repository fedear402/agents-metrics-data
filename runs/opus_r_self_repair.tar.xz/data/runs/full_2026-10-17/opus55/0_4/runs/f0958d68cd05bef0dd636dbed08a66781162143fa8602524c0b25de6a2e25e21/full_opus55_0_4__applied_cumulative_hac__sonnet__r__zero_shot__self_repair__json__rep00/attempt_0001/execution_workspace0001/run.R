suppressPackageStartupMessages({
  library(jsonlite)
})

d <- read.csv("input.csv", stringsAsFactors = FALSE)
d$date <- as.Date(d$date)
d <- d[order(d$date), ]
n <- nrow(d)
y <- log(d$sales)
dv <- c(NA, diff(log(d$vix)))
K <- 15
X <- sapply(1:K, function(k) c(rep(NA, k), dv[seq_len(n - k)]))
colnames(X) <- paste0("lag_", 1:K)
ok <- complete.cases(cbind(y, X))
yy <- y[ok]
XX <- cbind(1, X[ok, , drop = FALSE])
N <- length(yy)
p <- ncol(XX)

fit <- lm.fit(XX, yy)
b <- fit$coefficients
e <- fit$residuals

XtXi <- solve(crossprod(XX))
u <- XX * e
S <- crossprod(u)
L <- 15
for (j in 1:L) {
  w <- 1 - j / (L + 1)
  G <- crossprod(u[(j + 1):N, , drop = FALSE], u[1:(N - j), , drop = FALSE])
  S <- S + w * (G + t(G))
}
V <- XtXi %*% S %*% XtXi * (N / (N - p))

idx <- 2:(K + 1)
g <- rep(0, p); g[idx] <- 1
cum <- sum(b[idx])
cum_se <- sqrt(as.numeric(t(g) %*% V %*% g))
se <- sqrt(diag(V))

res <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(term = "cumulative_response", estimate = cum, se = cum_se, n_obs = N),
    list(term = "lag_1", estimate = unname(b[2]), se = unname(se[2]), n_obs = N),
    list(term = "lag_15", estimate = unname(b[16]), se = unname(se[16]), n_obs = N)
  ),
  method_metadata = list(
    estimator = "OLS distributed lag of log(sales) on 15 lags of dlog(vix)",
    vcov = "Newey-West HAC, Bartlett, maxlag 15, scaled N/(N-16)"
  ),
  diagnostics = list()
)
write_json(res, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE)
