suppressPackageStartupMessages(library(jsonlite))

dat <- read.csv("input.csv")
dat <- dat[is.finite(dat$score) & is.finite(dat$participated) & is.finite(dat$earnings), ]
d <- dat[abs(dat$score) < 1, ]
n <- nrow(d)

w <- 1 - abs(d$score)
D <- as.numeric(d$score >= 0)
X <- cbind(1, D, d$score, D * d$score)

A <- crossprod(X, X * w)
Ainv <- solve(A)

fit_wls <- function(y) {
  b <- Ainv %*% crossprod(X, w * y)
  e <- as.vector(y - X %*% b)
  list(b = as.vector(b), e = e)
}

f_rf <- fit_wls(d$earnings)
f_fs <- fit_wls(d$participated)

rf <- f_rf$b[2]
fs <- f_fs$b[2]

# Joint HC0 sandwich for the two D coefficients
S <- X * w
cvec <- c(0, 1, 0, 0)
g <- as.vector(Ainv %*% cvec)
inf_rf <- as.vector(S %*% g) * f_rf$e
inf_fs <- as.vector(S %*% g) * f_fs$e
v_rf <- sum(inf_rf^2)
v_fs <- sum(inf_fs^2)
c_rf_fs <- sum(inf_rf * inf_fs)

tau <- rf / fs
grad <- c(1 / fs, -rf / fs^2)
V <- matrix(c(v_rf, c_rf_fs, c_rf_fs, v_fs), 2, 2)
v_tau <- as.numeric(t(grad) %*% V %*% grad)

res <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = tau, se = sqrt(v_tau), n_obs = n),
    list(term = "reduced_form", estimate = rf, se = sqrt(v_rf), n_obs = n),
    list(term = "first_stage", estimate = fs, se = sqrt(v_fs), n_obs = n)
  ),
  method_metadata = list(
    estimator = "fuzzy RD, local linear, triangular kernel, bandwidth 1, cutoff 0, Wald ratio",
    vcov = "HC0 joint sandwich (no dof correction), delta method for ratio"
  ),
  diagnostics = list(
    n_left = sum(D == 0), n_right = sum(D == 1),
    cov_rf_fs = c_rf_fs
  )
)

writeLines(toJSON(res, auto_unbox = TRUE, digits = 15, pretty = TRUE), "result.json")
