suppressPackageStartupMessages(library(jsonlite))

d <- read.csv("input.csv")
n_full <- nrow(d)
d <- d[complete.cases(d[, c("y", "x", "z")]), ]
y <- as.integer(d$y)
X <- cbind(1, d$x, d$z)
k <- ncol(X)
Y1 <- as.numeric(y == 1)
Y2 <- as.numeric(y == 2)

negll <- function(b) {
  b1 <- b[1:k]; b2 <- b[(k + 1):(2 * k)]
  e1 <- drop(X %*% b1); e2 <- drop(X %*% b2)
  m <- pmax(0, e1, e2)
  lse <- m + log(exp(-m) + exp(e1 - m) + exp(e2 - m))
  -sum(Y1 * e1 + Y2 * e2 - lse)
}
grad <- function(b) {
  b1 <- b[1:k]; b2 <- b[(k + 1):(2 * k)]
  e1 <- drop(X %*% b1); e2 <- drop(X %*% b2)
  m <- pmax(0, e1, e2)
  den <- exp(-m) + exp(e1 - m) + exp(e2 - m)
  p1 <- exp(e1 - m) / den; p2 <- exp(e2 - m) / den
  -c(crossprod(X, Y1 - p1), crossprod(X, Y2 - p2))
}

fit <- optim(rep(0, 2 * k), negll, grad, method = "BFGS",
             control = list(maxit = 10000, reltol = 1e-14))
b <- fit$par
# Newton polish with analytic Hessian
hess <- function(b) {
  b1 <- b[1:k]; b2 <- b[(k + 1):(2 * k)]
  e1 <- drop(X %*% b1); e2 <- drop(X %*% b2)
  m <- pmax(0, e1, e2)
  den <- exp(-m) + exp(e1 - m) + exp(e2 - m)
  p1 <- exp(e1 - m) / den; p2 <- exp(e2 - m) / den
  H11 <- crossprod(X * (p1 * (1 - p1)), X)
  H22 <- crossprod(X * (p2 * (1 - p2)), X)
  H12 <- -crossprod(X * (p1 * p2), X)
  rbind(cbind(H11, H12), cbind(t(H12), H22))
}
for (i in 1:50) {
  g <- grad(b); H <- hess(b)
  step <- solve(H, g)
  b <- b - step
  if (max(abs(step)) < 1e-12) break
}
V <- solve(hess(b))
se <- sqrt(diag(V))

e1 <- b[1]; e2 <- b[k + 1]
p2_zero <- exp(e2) / (1 + exp(e1) + exp(e2))

est <- list(
  list(term = "x_cat1", estimate = b[2], se = se[2], n_obs = n_full),
  list(term = "z_cat1", estimate = b[3], se = se[3], n_obs = n_full),
  list(term = "x_cat2", estimate = b[k + 2], se = se[k + 2], n_obs = n_full),
  list(term = "z_cat2", estimate = b[k + 3], se = se[k + 3], n_obs = n_full),
  list(term = "prob_cat2_zero", estimate = p2_zero, se = NULL, n_obs = n_full)
)

res <- list(
  task_id = "broad_multinomial_logit",
  platform = "r",
  estimates = est,
  method_metadata = list(estimator = "multinomial logit MLE (base outcome 0)",
                         vcov = "inverse observed information (Hessian)"),
  diagnostics = list(loglik = -negll(b), n_used = nrow(d),
                     converged = fit$convergence == 0)
)
writeLines(toJSON(res, auto_unbox = TRUE, digits = NA, null = "null", pretty = TRUE),
           "result.json")
