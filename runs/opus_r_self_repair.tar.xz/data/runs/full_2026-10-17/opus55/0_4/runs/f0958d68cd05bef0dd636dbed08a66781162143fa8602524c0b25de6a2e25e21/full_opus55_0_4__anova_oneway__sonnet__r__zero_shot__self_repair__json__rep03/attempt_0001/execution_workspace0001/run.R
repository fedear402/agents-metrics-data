suppressPackageStartupMessages(library(jsonlite))

df <- read.csv("./input.csv", stringsAsFactors = FALSE)
df$y <- suppressWarnings(as.numeric(df$y))
df <- df[!is.na(df$y) & !is.na(df$group) & trimws(as.character(df$group)) != "", ]
df$group <- factor(trimws(as.character(df$group)))
df <- droplevels(df)

n <- nrow(df)
fit <- aov(y ~ group, data = df)
tab <- summary(fit)[[1]]

F_stat <- unname(tab[1, "F value"])
df_num <- unname(tab[1, "Df"])
df_den <- unname(tab[2, "Df"])
p_val  <- unname(tab[1, "Pr(>F)"])

grp_n <- as.list(table(df$group))
grp_means <- as.list(tapply(df$y, df$group, mean))

res <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = list(
    list(term = "F", estimate = F_stat, se = NULL, n_obs = n),
    list(term = "df_num", estimate = as.numeric(df_num), se = NULL, n_obs = n),
    list(term = "df_den", estimate = as.numeric(df_den), se = NULL, n_obs = n),
    list(term = "p_value", estimate = p_val, se = NULL, n_obs = n)
  ),
  method_metadata = list(
    estimator = "One-way ANOVA (classical, equal variances) via aov(y ~ group)",
    vcov = "classical"
  ),
  diagnostics = list(
    n_groups = nlevels(df$group),
    group_sizes = grp_n,
    group_means = grp_means
  )
)

writeLines(toJSON(res, auto_unbox = TRUE, null = "null", digits = NA, pretty = TRUE),
           "result.json")
