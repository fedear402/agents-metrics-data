suppressPackageStartupMessages(library(jsonlite))

d <- read.csv("input.csv", stringsAsFactors = FALSE)
d$g[is.na(d$g)] <- 0

res <- list()
atts <- c(); wts <- c(); nobs <- c()
for (c in c(3, 5, 7)) {
  win <- (c - 2):(c + 2)
  s <- d[d$time %in% win & (d$g == c | d$g == 0 | d$g > c + 2), ]
  cnt <- table(s$id)
  keep <- names(cnt)[cnt == length(win)]
  s <- s[as.character(s$id) %in% keep, ]
  s$did <- as.numeric(s$g == c & s$time >= c)
  fit <- lm(y ~ did + factor(id) + factor(time), data = s)
  b <- unname(coef(fit)["did"])
  atts <- c(atts, b)
  wts <- c(wts, length(unique(s$id[s$g == c])))
  nobs <- c(nobs, nrow(s))
  res[[length(res) + 1]] <- list(term = paste0("att_g", c), estimate = b,
                                 se = NULL, n_obs = nrow(s))
}
res[[4]] <- list(term = "att_weighted", estimate = sum(atts * wts) / sum(wts),
                 se = NULL, n_obs = sum(nobs))

out <- list(task_id = "broad_cohort_stack", platform = "r", estimates = res,
            method_metadata = list(weights_treated_units = wts),
            diagnostics = list(n_obs_by_cohort = nobs))
write_json(out, "result.json", auto_unbox = TRUE, null = "null", digits = NA, pretty = TRUE)
