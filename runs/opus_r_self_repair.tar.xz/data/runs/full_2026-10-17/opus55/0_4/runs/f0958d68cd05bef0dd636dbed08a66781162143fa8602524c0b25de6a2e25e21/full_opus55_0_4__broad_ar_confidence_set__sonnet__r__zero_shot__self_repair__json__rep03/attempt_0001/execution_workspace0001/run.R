library(jsonlite)
d <- read.csv("input.csv")
n <- nrow(d)
y <- d$y; e <- d$endog
W <- cbind(1, d$x)
Fm <- cbind(1, d$x, d$z1, d$z2)
resid_mat <- function(X, v) qr.resid(qr(X), v)
ry_r <- resid_mat(W, y); re_r <- resid_mat(W, e)
ry_u <- resid_mat(Fm, y); re_u <- resid_mat(Fm, e)
Ry <- sum(ry_r^2); Re <- sum(re_r^2); Rye <- sum(ry_r * re_r)
Uy <- sum(ry_u^2); Ue <- sum(re_u^2); Uye <- sum(ry_u * re_u)
crit <- qf(0.95, 2, n - 4)
k <- 2 * crit / (n - 4)
a2 <- (Re - Ue) - k * Ue
a1 <- -2 * ((Rye - Uye) - k * Uye)
a0 <- (Ry - Uy) - k * Uy
Ffun <- function(b) {
  rss_r <- Ry - 2 * b * Rye + b^2 * Re
  rss_u <- Uy - 2 * b * Uye + b^2 * Ue
  ((rss_r - rss_u) / 2) / (rss_u / (n - 4))
}
disc <- a1^2 - 4 * a2 * a0
if (disc < 0) stop("No real boundary points")
rts <- sort(c((-a1 - sqrt(disc)) / (2 * a2), (-a1 + sqrt(disc)) / (2 * a2)))
lo <- rts[1]; hi <- rts[2]
unbounded <- as.numeric(a2 < 0)
accepts_zero <- as.numeric(Ffun(0) <= crit)
f1 <- Ffun(1)
mk <- function(t, v) list(term = t, estimate = v, se = NULL, n_obs = n)
res <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = list(
    mk("boundary_low", lo), mk("boundary_high", hi),
    mk("accepts_zero", accepts_zero), mk("unbounded", unbounded),
    mk("ar_f_at_one", f1)
  ),
  method_metadata = list(estimator = "Anderson-Rubin test inversion (analytic quadratic)",
                         vcov = "homoskedastic F"),
  diagnostics = list(quad_a2 = a2, quad_a1 = a1, quad_a0 = a0, f_crit = crit,
                     f_at_zero = Ffun(0))
)
write(toJSON(res, auto_unbox = TRUE, digits = NA, null = "null", pretty = TRUE), "result.json")
