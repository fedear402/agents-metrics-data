suppressPackageStartupMessages(library(jsonlite))

cw   <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
tr   <- read.csv("trade.csv", stringsAsFactors = FALSE)
ar   <- read.csv("areas.csv", stringsAsFactors = FALSE)
emp  <- read.csv("employment.csv", stringsAsFactors = FALSE)
outc <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

trim <- function(v) trimws(as.character(v))
cw$code <- trim(cw$code); cw$industry <- trim(cw$industry)
tr$code <- trim(tr$code); tr$period <- trim(tr$period)
ar$area <- trim(ar$area); ar$period <- trim(ar$period); ar$vintage <- tolower(trim(ar$vintage))
emp$area <- trim(emp$area); emp$period <- trim(emp$period)
emp$vintage <- tolower(trim(emp$vintage)); emp$industry <- trim(emp$industry)
outc$area <- trim(outc$area); outc$period <- trim(outc$period)

tr <- merge(tr, cw, by = "code")
inds <- sort(unique(cw$industry))

# Aggregate employment (in case of duplicate rows)
emp <- aggregate(employment ~ area + period + vintage + industry, data = emp, FUN = sum)

# National industry employment within period & vintage
nat <- aggregate(employment ~ period + vintage + industry, data = emp, FUN = sum)
names(nat)[names(nat) == "employment"] <- "national"

get_emp <- function(a, p, v, j) {
  s <- emp$employment[emp$area == a & emp$period == p & emp$vintage == v & emp$industry == j]
  if (length(s) == 0) 0 else sum(s)
}
get_nat <- function(p, v, j) {
  s <- nat$national[nat$period == p & nat$vintage == v & nat$industry == j]
  if (length(s) == 0) NA else sum(s)
}

d <- outc
d$x <- NA_real_; d$z <- NA_real_; d$pop <- NA_real_
for (i in seq_len(nrow(d))) {
  a <- d$area[i]; p <- d$period[i]
  rb <- ar[ar$area == a & ar$period == p & ar$vintage == "base", ]
  re <- ar[ar$area == a & ar$period == p & ar$vintage == "early", ]
  tb <- rb$total_employment[1]; te <- re$total_employment[1]
  d$pop[i] <- rb$population[1]
  xs <- 0; zs <- 0
  for (j in inds) {
    t <- tr[tr$period == p & tr$industry == j, ]
    if (nrow(t) == 0) next
    defl <- (t$price_index[1] / 100) * 1000 / (10 / t$years[1])
    xs <- xs + (get_emp(a, p, "base", j) / tb) * (t$us_change[1] / get_nat(p, "base", j)) / defl
    zs <- zs + (get_emp(a, p, "early", j) / te) * (t$other_change[1] / get_nat(p, "early", j)) / defl
  }
  d$x[i] <- xs; d$z[i] <- zs
}

d <- d[complete.cases(d[, c("change_pp", "control", "x", "z", "pop")]), ]
pnum <- suppressWarnings(as.numeric(d$period))
if (any(is.na(pnum))) pnum <- as.numeric(factor(d$period)) - 1

C <- cbind(1, pnum, d$control)
w <- d$pop
X <- cbind(C, d$x) * sqrt(w)
Z <- cbind(C, d$z) * sqrt(w)
fitted <- qr.fitted(qr(Z), X)
b <- as.numeric(qr.coef(qr(fitted), d$change_pp * sqrt(w)))
iv_slope <- b[4]
n_obs <- nrow(d)

pick <- function(col, p) {
  v <- d[[col]][d$area == "0" & d$period == p]
  if (length(v) == 0) {
    v <- d[[col]][suppressWarnings(as.numeric(d$area)) == 0 & pnum == as.numeric(p)]
  }
  v[1]
}
periods <- sort(unique(d$period))
p0 <- if ("0" %in% periods) "0" else periods[1]
p1 <- if ("1" %in% periods) "1" else periods[2]

est <- list(
  list(term = "iv_slope", estimate = iv_slope, se = NA, n_obs = n_obs),
  list(term = "exposure_area0_period0", estimate = pick("x", p0), se = NA, n_obs = n_obs),
  list(term = "exposure_area0_period1", estimate = pick("x", p1), se = NA, n_obs = n_obs),
  list(term = "instrument_area0_period0", estimate = pick("z", p0), se = NA, n_obs = n_obs)
)

res <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = est,
  method_metadata = list(
    estimator = "weighted 2SLS",
    regressors = c("intercept", "period", "control", "x"),
    instruments = c("intercept", "period", "control", "z"),
    weight = "base-vintage population",
    exposure_units = "thousands of real dollars per worker per decade"
  ),
  diagnostics = list(
    n_obs = n_obs,
    n_industries = length(inds),
    coefficients = b
  )
)

write_json(res, "result.json", auto_unbox = TRUE, digits = NA, na = "null", null = "null", pretty = TRUE)
