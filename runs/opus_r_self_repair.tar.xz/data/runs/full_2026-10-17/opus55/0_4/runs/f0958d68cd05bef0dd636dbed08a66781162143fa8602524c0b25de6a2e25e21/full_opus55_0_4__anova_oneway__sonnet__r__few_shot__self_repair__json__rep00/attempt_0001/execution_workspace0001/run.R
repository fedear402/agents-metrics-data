library(jsonlite)

dat <- read.csv("./input.csv", stringsAsFactors = FALSE)
dat <- dat[!is.na(dat$y) & !is.na(dat$group) & dat$group != "", , drop = FALSE]
dat$y <- as.numeric(dat$y)
dat <- dat[!is.na(dat$y), , drop = FALSE]
dat$group <- factor(dat$group)

fit <- aov(y ~ group, data = dat)
tab <- summary(fit)[[1]]

f_stat <- unname(tab[1, "F value"])
df_num <- unname(tab[1, "Df"])
df_den <- unname(tab[2, "Df"])
p_val <- unname(tab[1, "Pr(>F)"])
n <- nrow(dat)

out <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = list(
    list(term = "F", estimate = f_stat, se = NA, n_obs = n),
    list(term = "df_num", estimate = as.numeric(df_num), se = NA, n_obs = n),
    list(term = "df_den", estimate = as.numeric(df_den), se = NA, n_obs = n),
    list(term = "p_value", estimate = p_val, se = NA, n_obs = n)
  ),
  method_metadata = list(estimator = "One-way ANOVA (aov, equal variances)",
                         vcov = "classical"),
  diagnostics = structure(list(), names = character(0))
)
write_json(out, "result.json", auto_unbox = TRUE, digits = NA, na = "null")
