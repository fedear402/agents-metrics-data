suppressPackageStartupMessages(library(jsonlite))
d <- read.csv("input.csv")
n_full <- nrow(d)
d <- d[complete.cases(d[, c("y", "x", "z")]), ]
y <- as.integer(d$y)
X <- cbind(1, d$x, d$z)
k <- ncol(X)
Y1 <- as.numeric(y == 1); Y2 <- as.numeric(y == 2)

nll <- function(b) {
  e1 <- X %*% b[1:k]; e2 <- X %*% b[(k+1):(2*k)]
  m <- pmax(0, e1, e2)
  lse <- m + log(exp(-m) + exp(e1 - m) + exp(e2 - m))
  -sum(Y1 * e1 + Y2 * e2 - lse)
}
gr <- function(b) {
  e1 <- X %*% b[1:k]; e2 <- X %*% b[(k+1):(2*k)]
  m <- pmax(0, e1, e2)
  den <- exp(-m) + exp(e1 - m) + exp(e2 - m)
  p1 <- exp(e1 - m) / den; p2 <- exp(e2 - m) / den
  -c(crossprod(X, Y1 - p1), crossprod(X, Y2 - p2))
}
fit <- optim(rep(0, 2*k), nll, gr, method = "BFGS",
             control = list(maxit = 10000, reltol = 1e-14))
b <- fit$par
for (it in 1:50) {
  e1 <- X %*% b[1:k]; e2 <- X %*% b[(k+1):(2*k)]
  m <- pmax(0, e1, e2)
  den <- exp(-m) + exp(e1 - m) + exp(e2 - m)
  p1 <- as.vector(exp(e1 - m) / den); p2 <- as.vector(exp(e2 - m) / den)
  H11 <- crossprod(X * (p1 * (1 - p1)), X)
  H22 <- crossprod(X * (p2 * (1 - p2)), X)
  H12 <- -crossprod(X * (p1 * p2), X)
  H <- rbind(cbind(H11, H12), cbind(t(H12), H22))
  g <- -gr(b)
  step <- solve(H, g)
  b <- b + step
  if (max(abs(step)) < 1e-12) break
}
e1 <- X %*% b[1:k]; e2 <- X %*% b[(k+1):(2*k)]
m <- pmax(0, e1, e2)
den <- exp(-m) + exp(e1 - m) + exp(e2 - m)
p1 <- as.vector(exp(e1 - m) / den); p2 <- as.vector(exp(e2 - m) / den)
H11 <- crossprod(X * (p1 * (1 - p1)), X)
H22 <- crossprod(X * (p2 * (1 - p2)), X)
H12 <- -crossprod(X * (p1 * p2), X)
H <- rbind(cbind(H11, H12), cbind(t(H12), H22))
V <- solve(H)
se <- sqrt(diag(V))

prob2 <- exp(b[4]) / (1 + exp(b[1]) + exp(b[4]))

est <- list(
  list(term = "x_cat1", estimate = b[2], se = se[2], n_obs = n_full),
  list(term = "z_cat1", estimate = b[3], se = se[3], n_obs = n_full),
  list(term = "x_cat2", estimate = b[5], se = se[5], n_obs = n_full),
  list(term = "z_cat2", estimate = b[6], se = se[6], n_obs = n_full),
  list(term = "prob_cat2_zero", estimate = prob2, se = NULL, n_obs = n_full)
)
est[[5]]["se"] <- list(NULL)

res <- list(
  task_id = "broad_multinomial_logit",
  platform = "r",
  estimates = est,
  method_metadata = list(estimator = "multinomial logit MLE (base outcome 0)",
                         vcov = "inverse observed information (Hessian)"),
  diagnostics = list(loglik = -nll(b), n_used = nrow(d))
)
writeLines(toJSON(res, auto_unbox = TRUE, digits = NA, null = "null", pretty = TRUE),
           "result.json")
