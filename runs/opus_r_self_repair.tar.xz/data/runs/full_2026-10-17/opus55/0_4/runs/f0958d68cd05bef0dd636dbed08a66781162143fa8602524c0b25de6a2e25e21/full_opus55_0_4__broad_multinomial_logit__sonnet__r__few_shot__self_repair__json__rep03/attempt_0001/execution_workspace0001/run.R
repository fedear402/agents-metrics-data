d <- read.csv("input.csv")
n <- nrow(d)
d <- d[complete.cases(d[, c("y", "x", "z")]), ]
d$y <- factor(d$y, levels = c(0, 1, 2))
fit <- nnet::multinom(y ~ x + z, data = d, Hess = TRUE, trace = FALSE,
                      maxit = 1000, reltol = 1e-12, abstol = 1e-12)
B <- coef(fit)
V <- vcov(fit)
idx <- c(0, B[, "(Intercept)"])
p <- exp(idx - max(idx)) / sum(exp(idx - max(idx)))
mk <- function(term, est, se) list(term = term, estimate = unname(est), se = se, n_obs = as.integer(n))
rows <- list(
  mk("x_cat1", B["1", "x"], sqrt(V["1:x", "1:x"])),
  mk("z_cat1", B["1", "z"], sqrt(V["1:z", "1:z"])),
  mk("x_cat2", B["2", "x"], sqrt(V["2:x", "2:x"])),
  mk("z_cat2", B["2", "z"], sqrt(V["2:z", "2:z"])),
  mk("prob_cat2_zero", p[3], NULL)
)
out <- list(
  task_id = "broad_multinomial_logit",
  platform = "r",
  estimates = rows,
  method_metadata = list(estimator = "multinomial logit MLE (nnet::multinom), base outcome 0",
                         vcov = "inverse observed information (Hessian)"),
  diagnostics = list(loglik = as.numeric(logLik(fit)), n_used = nrow(d))
)
jsonlite::write_json(out, "result.json", auto_unbox = TRUE, null = "null",
                     digits = 16, pretty = TRUE)
