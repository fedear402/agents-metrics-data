suppressPackageStartupMessages(library(jsonlite))

df <- read.csv("./input.csv", stringsAsFactors = FALSE)
df$y <- suppressWarnings(as.numeric(df$y))
df <- df[!is.na(df$y) & !is.na(df$group) & trimws(as.character(df$group)) != "", ]
df$group <- factor(trimws(as.character(df$group)))
df <- droplevels(df)

n <- nrow(df)
fit <- aov(y ~ group, data = df)
tab <- summary(fit)[[1]]

Fval <- unname(tab[1, "F value"])
dfn <- unname(tab[1, "Df"])
dfd <- unname(tab[2, "Df"])
pval <- unname(tab[1, "Pr(>F)"])

mk <- function(term, est) list(term = term, estimate = est, se = NULL, n_obs = n)

group_sizes <- as.list(table(df$group))
group_means <- as.list(tapply(df$y, df$group, mean))

res <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = list(
    mk("F", Fval),
    mk("df_num", dfn),
    mk("df_den", dfd),
    mk("p_value", pval)
  ),
  method_metadata = list(
    estimator = "one-way ANOVA (aov, equal variances, Type I SS)",
    vcov = "classical"
  ),
  diagnostics = list(
    n_groups = nlevels(df$group),
    group_sizes = group_sizes,
    group_means = group_means
  )
)

writeLines(toJSON(res, auto_unbox = TRUE, digits = NA, null = "null", pretty = TRUE),
           "result.json")
