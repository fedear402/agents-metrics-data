library(jsonlite)
d <- read.csv("input.csv")
d <- d[is.finite(d$score) & is.finite(d$participated) & is.finite(d$earnings), ]
d <- d[abs(d$score) < 1, ]
n <- nrow(d)
w <- 1 - abs(d$score)
above <- as.numeric(d$score >= 0)
X <- cbind(1, above, d$score, above * d$score)
Y <- cbind(d$earnings, d$participated)
bread <- solve(crossprod(X, w * X))
coefs <- bread %*% crossprod(X, w * Y)
res <- Y - X %*% coefs
contrast <- c(0, 1, 0, 0)
jumps <- drop(contrast %*% coefs)
loading <- w * drop(X %*% bread %*% contrast)
infl <- loading * res
V <- crossprod(infl)
rf <- jumps[1]; fs <- jumps[2]
te <- rf / fs
g <- c(1 / fs, -rf / fs^2)
te_se <- sqrt(drop(t(g) %*% V %*% g))
row <- function(term, est, se) list(term = term, estimate = unname(as.numeric(est)),
                                    se = unname(as.numeric(se)), n_obs = as.integer(n))
out <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    row("treatment_effect", te, te_se),
    row("reduced_form", rf, sqrt(V[1, 1])),
    row("first_stage", fs, sqrt(V[2, 2]))
  ),
  method_metadata = list(
    estimator = "fuzzy RD, local linear, triangular kernel, bandwidth 1, separate slopes, Wald ratio",
    vcov = "HC0 joint influence-function covariance, delta method, no df correction"
  ),
  diagnostics = list(cov_rf_fs = V[1, 2], n_left = sum(above == 0), n_right = sum(above == 1))
)
write_json(out, "result.json", auto_unbox = TRUE, digits = 16, pretty = TRUE, null = "null")
