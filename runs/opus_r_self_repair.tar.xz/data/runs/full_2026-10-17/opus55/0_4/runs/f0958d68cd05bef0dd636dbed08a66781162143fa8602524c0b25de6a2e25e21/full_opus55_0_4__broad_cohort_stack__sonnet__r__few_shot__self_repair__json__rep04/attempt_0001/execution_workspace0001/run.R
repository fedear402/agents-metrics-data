d <- read.csv("input.csv")
res <- list(); ntr <- c(); nobs <- c()
for (c in c(3,5,7)) {
  w <- d[d$time >= c-2 & d$time <= c+2 & (d$g == c | d$g == 0 | d$g > c+2), ]
  cnt <- table(w$id)
  keep <- names(cnt)[cnt == 5]
  w <- w[as.character(w$id) %in% keep, ]
  w$did <- as.numeric(w$g == c & w$time >= c)
  fit <- lm(y ~ did + factor(id) + factor(time), data = w)
  res[[paste0("att_g", c)]] <- unname(coef(fit)["did"])
  ntr <- c(ntr, length(unique(w$id[w$g == c])))
  nobs <- c(nobs, nrow(w))
}
att <- unlist(res)
wavg <- sum(att * ntr) / sum(ntr)
est <- list()
for (i in 1:3) est[[i]] <- list(term = names(res)[i], estimate = att[[i]], se = NULL, n_obs = nobs[i])
est[[4]] <- list(term = "att_weighted", estimate = wavg, se = NULL, n_obs = sum(nobs))
out <- list(task_id = "broad_cohort_stack", platform = "r", estimates = est,
            method_metadata = structure(list(), names = character(0)),
            diagnostics = structure(list(), names = character(0)))
jsonlite::write_json(out, "result.json", auto_unbox = TRUE, null = "null", digits = 16)
