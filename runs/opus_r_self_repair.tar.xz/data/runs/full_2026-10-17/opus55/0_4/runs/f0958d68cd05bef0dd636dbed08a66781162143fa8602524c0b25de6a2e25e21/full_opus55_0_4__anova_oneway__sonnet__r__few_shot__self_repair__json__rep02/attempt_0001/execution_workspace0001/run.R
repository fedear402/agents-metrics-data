library(jsonlite)
dat <- read.csv("./input.csv", stringsAsFactors = FALSE)
dat <- dat[!is.na(dat$y) & !is.na(dat$group) & dat$group != "", ]
dat$y <- as.numeric(dat$y)
dat <- dat[!is.na(dat$y), ]
dat$group <- factor(dat$group)
n <- nrow(dat)
fit <- lm(y ~ group, data = dat)
tab <- anova(fit)
F_stat <- tab[["F value"]][1]
df_num <- tab[["Df"]][1]
df_den <- tab[["Df"]][2]
p_val <- tab[["Pr(>F)"]][1]
out <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = list(
    list(term = "F", estimate = unname(F_stat), se = NA, n_obs = n),
    list(term = "df_num", estimate = as.numeric(df_num), se = NA, n_obs = n),
    list(term = "df_den", estimate = as.numeric(df_den), se = NA, n_obs = n),
    list(term = "p_value", estimate = unname(p_val), se = NA, n_obs = n)
  ),
  method_metadata = list(estimator = "One-way ANOVA (OLS, classical F test)",
                         vcov = "classical"),
  diagnostics = structure(list(), names = character(0))
)
write_json(out, "result.json", auto_unbox = TRUE, digits = NA, na = "null")
