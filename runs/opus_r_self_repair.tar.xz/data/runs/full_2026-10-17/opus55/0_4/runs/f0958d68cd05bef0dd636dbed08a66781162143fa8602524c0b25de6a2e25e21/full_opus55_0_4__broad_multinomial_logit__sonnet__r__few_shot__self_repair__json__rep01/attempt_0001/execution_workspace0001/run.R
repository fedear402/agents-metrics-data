d <- read.csv("input.csv")
n_full <- nrow(d)
d <- d[complete.cases(d[, c("y", "x", "z")]), ]
d$y <- factor(d$y, levels = c(0, 1, 2))
fit <- nnet::multinom(y ~ x + z, data = d, Hess = TRUE, trace = FALSE,
                      maxit = 1000, reltol = 1e-12, abstol = 1e-12)
B <- coef(fit)
V <- vcov(fit)
se <- function(r, v) sqrt(V[paste0(r, ":", v), paste0(r, ":", v)])
indices <- c(0, B[, "(Intercept)"])
p <- exp(indices - max(indices)) / sum(exp(indices - max(indices)))
rows <- list(
  list(term = "x_cat1", estimate = unname(B["1", "x"]), se = se("1", "x"), n_obs = n_full),
  list(term = "z_cat1", estimate = unname(B["1", "z"]), se = se("1", "z"), n_obs = n_full),
  list(term = "x_cat2", estimate = unname(B["2", "x"]), se = se("2", "x"), n_obs = n_full),
  list(term = "z_cat2", estimate = unname(B["2", "z"]), se = se("2", "z"), n_obs = n_full),
  list(term = "prob_cat2_zero", estimate = unname(p[3]), se = NULL, n_obs = n_full)
)
out <- list(
  task_id = "broad_multinomial_logit",
  platform = "r",
  estimates = rows,
  method_metadata = list(estimator = "multinomial logit MLE (nnet::multinom), base outcome 0",
                         vcov = "inverse observed information (Hessian)"),
  diagnostics = list(converged = fit$convergence == 0, loglik = as.numeric(logLik(fit)))
)
jsonlite::write_json(out, "result.json", auto_unbox = TRUE, null = "null",
                     digits = 16, pretty = TRUE)
