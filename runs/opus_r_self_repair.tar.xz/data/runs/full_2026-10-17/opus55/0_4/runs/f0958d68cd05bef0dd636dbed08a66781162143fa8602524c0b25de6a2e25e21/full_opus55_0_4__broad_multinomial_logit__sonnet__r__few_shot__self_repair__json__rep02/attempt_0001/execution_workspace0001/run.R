d <- read.csv("input.csv")
n <- nrow(d)
d$y <- factor(d$y, levels = c(0, 1, 2))
fit <- nnet::multinom(y ~ x + z, data = d, Hess = TRUE, trace = FALSE,
                      maxit = 1000, reltol = 1e-12, abstol = 1e-12)
B <- coef(fit)
V <- vcov(fit)
indices <- c(0, B[, "(Intercept)"])
p <- exp(indices - max(indices)) / sum(exp(indices - max(indices)))
row <- function(term, est, se) list(term = term, estimate = unname(est),
                                     se = if (is.null(se)) NULL else unname(se), n_obs = n)
rows <- list(
  row("x_cat1", B["1", "x"], sqrt(V["1:x", "1:x"])),
  row("z_cat1", B["1", "z"], sqrt(V["1:z", "1:z"])),
  row("x_cat2", B["2", "x"], sqrt(V["2:x", "2:x"])),
  row("z_cat2", B["2", "z"], sqrt(V["2:z", "2:z"])),
  row("prob_cat2_zero", p[3], NULL)
)
out <- list(task_id = "broad_multinomial_logit", platform = "r", estimates = rows,
            method_metadata = list(estimator = "multinomial logit MLE (nnet::multinom), base outcome 0",
                                   vcov = "inverse observed information (Hessian)"),
            diagnostics = setNames(list(), character(0)))
jsonlite::write_json(out, "result.json", auto_unbox = TRUE, null = "null",
                     digits = 16, pretty = TRUE)
