suppressPackageStartupMessages(library(jsonlite))

cw <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
tr <- read.csv("trade.csv", stringsAsFactors = FALSE)
ar <- read.csv("areas.csv", stringsAsFactors = FALSE)
em <- read.csv("employment.csv", stringsAsFactors = FALSE)
oc <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

ar$vintage <- tolower(trimws(ar$vintage))
em$vintage <- tolower(trimws(em$vintage))
cw$code <- trimws(as.character(cw$code)); tr$code <- trimws(as.character(tr$code))
cw$industry <- trimws(as.character(cw$industry)); em$industry <- trimws(as.character(em$industry))

tr <- merge(tr, cw[, c("code", "industry")], by = "code")
inds <- sort(unique(cw$industry))

em <- aggregate(employment ~ area + period + vintage + industry, data = em, FUN = sum)
keys <- unique(ar[, c("area", "period", "vintage")])
grid <- merge(keys, data.frame(industry = inds, stringsAsFactors = FALSE), by = NULL)
g <- merge(grid, em, by = c("area", "period", "vintage", "industry"), all.x = TRUE)
g$employment[is.na(g$employment)] <- 0
g$nat <- ave(g$employment, g$period, g$vintage, g$industry, FUN = sum)
g <- merge(g, tr[, c("period", "industry", "us_change", "other_change", "price_index", "years")],
           by = c("period", "industry"))
g <- merge(g, ar[, c("area", "period", "vintage", "total_employment")],
           by = c("area", "period", "vintage"))
chg <- ifelse(g$vintage == "base", g$us_change, g$other_change)
g$contrib <- (g$employment / g$total_employment) * (chg / g$nat) /
  (g$price_index / 100) / 1000 * (10 / g$years)
ex <- aggregate(contrib ~ area + period + vintage, data = g, FUN = sum)

xb <- ex[ex$vintage == "base", c("area", "period", "contrib")]; names(xb)[3] <- "x"
ze <- ex[ex$vintage == "early", c("area", "period", "contrib")]; names(ze)[3] <- "z"
pop <- ar[ar$vintage == "base", c("area", "period", "population")]

d <- merge(oc, xb, by = c("area", "period"))
d <- merge(d, ze, by = c("area", "period"))
d <- merge(d, pop, by = c("area", "period"))
d <- d[complete.cases(d[, c("change_pp", "control", "x", "z", "population")]), ]

w <- d$population
C <- cbind(1, as.numeric(d$period), d$control)
X <- cbind(C, d$x) * sqrt(w); Z <- cbind(C, d$z) * sqrt(w)
fitted <- qr.fitted(qr(Z), X)
b <- as.numeric(qr.coef(qr(fitted), d$change_pp * sqrt(w)))
iv_slope <- b[4]

getv <- function(df, col, a, p) df[[col]][df$area == a & df$period == p][1]
n <- nrow(d)
est <- list(
  list(term = "iv_slope", estimate = iv_slope, se = NULL, n_obs = n),
  list(term = "exposure_area0_period0", estimate = getv(xb, "x", 0, 0), se = NULL, n_obs = n),
  list(term = "exposure_area0_period1", estimate = getv(xb, "x", 0, 1), se = NULL, n_obs = n),
  list(term = "instrument_area0_period0", estimate = getv(ze, "z", 0, 0), se = NULL, n_obs = n)
)
res <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = est,
  method_metadata = list(estimator = "weighted 2SLS",
                         exogenous = c("intercept", "period", "control"),
                         instrument = "z", weight = "base population"),
  diagnostics = list(n_obs = n, n_industries = length(inds))
)
write_json(res, "result.json", auto_unbox = TRUE, digits = NA, null = "null", pretty = TRUE)
