suppressPackageStartupMessages(library(jsonlite))

df <- read.csv("./input.csv", stringsAsFactors = FALSE)
df$y <- suppressWarnings(as.numeric(df$y))
df <- df[!is.na(df$y) & !is.na(df$group) & df$group != "", ]
df$group <- factor(df$group)
n <- nrow(df)

fit <- lm(y ~ group, data = df)
a <- anova(fit)
Fv <- a[["F value"]][1]
df1 <- a[["Df"]][1]
df2 <- a[["Df"]][2]
pv <- a[["Pr(>F)"]][1]

mk <- function(t, v) list(term = t, estimate = unname(as.numeric(v)), se = NULL, n_obs = n)

res <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = list(mk("F", Fv), mk("df_num", df1), mk("df_den", df2), mk("p_value", pv)),
  method_metadata = list(estimator = "one-way ANOVA (lm + anova, equal variances)", vcov = "classical OLS"),
  diagnostics = list(n_groups = nlevels(df$group),
                     group_sizes = as.list(table(df$group)))
)

writeLines(toJSON(res, auto_unbox = TRUE, null = "null", digits = NA, pretty = TRUE), "result.json")
