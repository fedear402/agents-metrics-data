suppressPackageStartupMessages(library(jsonlite))

d <- read.csv("input.csv", stringsAsFactors = FALSE)
d$g[is.na(d$g)] <- 0

res <- list()
ests <- c(); nobs <- c(); ntr <- c()
for (c in c(3, 5, 7)) {
  win <- (c - 2):(c + 2)
  s <- d[d$time %in% win & (d$g == c | d$g == 0 | d$g > c + 2), ]
  s <- s[!is.na(s$y), ]
  cnt <- table(s$id)
  keep <- names(cnt)[cnt == length(win)]
  s <- s[as.character(s$id) %in% keep, ]
  s$did <- as.numeric(s$g == c & s$time >= c)
  fit <- lm(y ~ did + factor(id) + factor(time), data = s)
  ests <- c(ests, unname(coef(fit)["did"]))
  nobs <- c(nobs, nrow(s))
  ntr <- c(ntr, length(unique(s$id[s$g == c])))
}

attw <- sum(ests * ntr) / sum(ntr)
terms <- c("att_g3", "att_g5", "att_g7", "att_weighted")
allest <- c(ests, attw)
alln <- c(nobs, sum(nobs))

estimates <- lapply(seq_along(terms), function(i) list(
  term = terms[i],
  estimate = allest[i],
  se = NA,
  n_obs = as.integer(alln[i])
))

out <- list(
  task_id = "broad_cohort_stack",
  platform = "r",
  estimates = estimates,
  method_metadata = list(weights_treated_units = setNames(as.list(ntr), c("g3", "g5", "g7"))),
  diagnostics = setNames(as.list(nobs), c("n_obs_g3", "n_obs_g5", "n_obs_g7"))
)

write_json(out, "result.json", auto_unbox = TRUE, digits = NA, na = "null", pretty = TRUE)
