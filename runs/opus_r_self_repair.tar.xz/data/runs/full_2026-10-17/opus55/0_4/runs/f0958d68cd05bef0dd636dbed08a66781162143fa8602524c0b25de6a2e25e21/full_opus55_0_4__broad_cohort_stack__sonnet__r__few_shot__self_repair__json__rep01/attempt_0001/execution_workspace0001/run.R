d <- read.csv("input.csv")
cohorts <- c(3, 5, 7)
res <- list()
atts <- numeric(0); ws <- numeric(0); ns <- numeric(0)
for (c in cohorts) {
  win <- (c - 2):(c + 2)
  s <- d[d$time %in% win & (d$g == c | d$g == 0 | d$g > c + 2), ]
  cnt <- table(s$id)
  keep <- names(cnt)[cnt == length(win)]
  s <- s[as.character(s$id) %in% keep, ]
  s$did <- as.numeric(s$g == c & s$time >= c)
  fit <- lm(y ~ did + factor(id) + factor(time), data = s)
  est <- unname(coef(fit)["did"])
  ntr <- length(unique(s$id[s$g == c]))
  atts <- c(atts, est); ws <- c(ws, ntr); ns <- c(ns, nrow(s))
  res[[length(res) + 1]] <- list(term = paste0("att_g", c), estimate = est,
                                 se = NULL, n_obs = nrow(s))
}
res[[length(res) + 1]] <- list(term = "att_weighted",
                               estimate = sum(atts * ws) / sum(ws),
                               se = NULL, n_obs = sum(ns))
out <- list(task_id = "broad_cohort_stack", platform = "r", estimates = res,
            method_metadata = structure(list(), names = character(0)),
            diagnostics = structure(list(), names = character(0)))
jsonlite::write_json(out, "result.json", auto_unbox = TRUE, null = "null", digits = 16)
