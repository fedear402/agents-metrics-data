suppressMessages(library(jsonlite))

cw <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
tr <- read.csv("trade.csv", stringsAsFactors = FALSE)
ar <- read.csv("areas.csv", stringsAsFactors = FALSE)
em <- read.csv("employment.csv", stringsAsFactors = FALSE)
oc <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

cw$code <- as.character(cw$code); tr$code <- as.character(tr$code)
cw$industry <- as.character(cw$industry); em$industry <- as.character(em$industry)
ar$vintage <- trimws(tolower(ar$vintage)); em$vintage <- trimws(tolower(em$vintage))

trj <- merge(tr, cw, by = "code")
inds <- sort(unique(cw$industry))
periods <- sort(unique(oc$period))
areas <- sort(unique(ar$area))

# full employment grid with zeros
grid <- expand.grid(area = areas, period = periods, vintage = c("base", "early"),
                    industry = inds, stringsAsFactors = FALSE)
emA <- aggregate(employment ~ area + period + vintage + industry, data = em, FUN = sum)
grid <- merge(grid, emA, all.x = TRUE)
grid$employment[is.na(grid$employment)] <- 0

nat <- aggregate(employment ~ period + vintage + industry, data = grid, FUN = sum)
names(nat)[names(nat) == "employment"] <- "national"
grid <- merge(grid, nat)

tot <- ar[, c("area", "period", "vintage", "total_employment")]
grid <- merge(grid, tot, by = c("area", "period", "vintage"))
grid <- merge(grid, trj[, c("period", "industry", "us_change", "other_change",
                            "price_index", "years")], by = c("period", "industry"))

grid$term <- (grid$employment / grid$total_employment) / grid$national /
  (grid$price_index / 100) / 1000 * (10 / grid$years)
gb <- grid[grid$vintage == "base", ]
ge <- grid[grid$vintage == "early", ]
xb <- aggregate(list(x = gb$term * gb$us_change), by = list(area = gb$area, period = gb$period), FUN = sum)
ze <- aggregate(list(z = ge$term * ge$other_change), by = list(area = ge$area, period = ge$period), FUN = sum)

pop <- ar[ar$vintage == "base", c("area", "period", "population")]
d <- merge(oc, xb, by = c("area", "period"))
d <- merge(d, ze, by = c("area", "period"))
d <- merge(d, pop, by = c("area", "period"))
d <- d[order(d$period, d$area), ]

X <- cbind(1, d$period, d$control, d$x)
Z <- cbind(1, d$period, d$control, d$z)
y <- d$change_pp
w <- d$population
XWZ <- t(X) %*% (w * Z)
ZWZinv <- solve(t(Z) %*% (w * Z))
ZWy <- t(Z) %*% (w * y)
A <- XWZ %*% ZWZinv
beta <- solve(A %*% t(XWZ), A %*% ZWy)
iv_slope <- beta[4]

a0 <- areas[1]
if (0 %in% areas) a0 <- 0
p0 <- periods[1]; p1 <- periods[2]
if (0 %in% periods) p0 <- 0
if (1 %in% periods) p1 <- 1
ex00 <- d$x[d$area == a0 & d$period == p0]
ex01 <- d$x[d$area == a0 & d$period == p1]
iz00 <- d$z[d$area == a0 & d$period == p0]
n <- nrow(d)

mk <- function(t, v) list(term = t, estimate = unname(v), se = NULL, n_obs = as.integer(n))
res <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = list(mk("iv_slope", iv_slope),
                   mk("exposure_area0_period0", ex00),
                   mk("exposure_area0_period1", ex01),
                   mk("instrument_area0_period0", iz00)),
  method_metadata = list(estimator = "weighted 2SLS", weight = "base population",
                         instruments = c("intercept", "period", "control", "z")),
  diagnostics = list(n_obs = as.integer(n), coefficients = as.numeric(beta),
                     first_stage_cor_xz = cor(d$x, d$z))
)
write_json(res, "result.json", auto_unbox = TRUE, digits = NA, null = "null", pretty = TRUE)
