library(jsonlite)
d <- read.csv("input.csv", stringsAsFactors = FALSE)
d$region_id <- as.character(d$region_id); d$industry_id <- as.character(d$industry_id)
regions <- sort(unique(d$region_id)); inds <- sort(unique(d$industry_id))
R <- length(regions); N <- length(inds)
S <- matrix(0, R, N, dimnames = list(regions, inds))
agg <- aggregate(share ~ region_id + industry_id, data = d, FUN = sum)
S[cbind(match(agg$region_id, regions), match(agg$industry_id, inds))] <- agg$share
first_r <- d[!duplicated(d$region_id), ]
first_r <- first_r[match(regions, first_r$region_id), ]
first_n <- d[!duplicated(d$industry_id), ]
shock <- first_n$shock[match(inds, first_n$industry_id)]
e <- first_r$region_weight / sum(first_r$region_weight)
z <- drop(S %*% shock)
reg <- cbind(y = first_r$y, x = first_r$x, z = z)
cen <- sweep(reg, 2, drop(e %*% reg))
s <- drop(e %*% S)
keep <- s > 0
aggm <- (t(S) %*% (e * cen)) / s
aggm <- aggm[keep, , drop = FALSE]; sk <- s[keep]; shk <- shock[keep]
Nn <- sum(keep)
shock_iv <- function(dep, endog) {
  X <- cbind(1, endog); Z <- cbind(1, shk)
  cross <- crossprod(Z, sk * X)
  beta <- solve(cross, crossprod(Z, sk * dep))
  res <- drop(dep - X %*% beta)
  sc <- Z * (sk * res)
  inv <- solve(cross)
  V <- Nn / (Nn - 2) * inv %*% crossprod(sc) %*% t(inv)
  c(beta[2], sqrt(V[2, 2]))
}
eff <- shock_iv(aggm[, "y"], aggm[, "x"])
fs <- shock_iv(aggm[, "x"], aggm[, "z"])
reg_eff <- sum(e * cen[, "z"] * cen[, "y"]) / sum(e * cen[, "z"] * cen[, "x"])
reg_fs <- sum(e * cen[, "z"] * cen[, "x"]) / sum(e * cen[, "z"]^2)
row <- function(term, est, se, n) list(term = term, estimate = unname(as.numeric(est)),
  se = if (is.null(se)) NULL else unname(as.numeric(se)), n_obs = as.integer(n))
out <- list(
  task_id = "applied_shift_share", platform = "r",
  estimates = list(
    row("effect", reg_eff, eff[2], Nn),
    row("first_stage", reg_fs, fs[2], Nn),
    row("effective_shocks", 1 / sum(s^2), NULL, Nn)),
  method_metadata = list(estimator = "weighted 2SLS shift-share with BHJ shock-level IV",
                         vcov = "shock-level HC1 (N/(N-2)), structural IV residuals, s_n weights"),
  diagnostics = list(shock_level_effect = eff[1], shock_level_first_stage = fs[1],
                     n_regions = R, n_industries = N))
write_json(out, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
