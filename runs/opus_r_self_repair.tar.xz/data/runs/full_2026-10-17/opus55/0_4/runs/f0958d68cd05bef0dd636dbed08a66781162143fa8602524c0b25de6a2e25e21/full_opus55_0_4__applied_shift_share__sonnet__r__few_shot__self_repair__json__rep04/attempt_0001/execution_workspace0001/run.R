library(jsonlite)
d <- read.csv("input.csv")
d$region_id <- as.character(d$region_id); d$industry_id <- as.character(d$industry_id)
regions <- sort(unique(d$region_id)); inds <- sort(unique(d$industry_id))
R <- length(regions); N <- length(inds)
S <- matrix(0, R, N, dimnames=list(regions, inds))
for (i in seq_len(nrow(d))) S[d$region_id[i], d$industry_id[i]] <- S[d$region_id[i], d$industry_id[i]] + d$share[i]
first <- d[!duplicated(d$region_id), ]; first <- first[match(regions, first$region_id), ]
shk <- d[!duplicated(d$industry_id), ]; shock <- shk$shock[match(inds, shk$industry_id)]
e <- first$region_weight / sum(first$region_weight)
x <- first$x; y <- first$y
z <- drop(S %*% shock)
reg <- cbind(y, x, z)
cen <- sweep(reg, 2, drop(e %*% reg))
mass <- drop(e %*% S)
keep <- mass > 0
agg <- (t(S) %*% (e * cen)) / mass
agg <- agg[keep, , drop=FALSE]; m <- mass[keep]; g <- shock[keep]; Nk <- sum(keep)
shock_iv <- function(dep, endo) {
  X <- cbind(1, endo); Z <- cbind(1, g)
  cross <- crossprod(Z, m * X)
  b <- solve(cross, crossprod(Z, m * dep))
  u <- drop(dep - X %*% b)
  sc <- Z * (m * u)
  inv <- solve(cross)
  V <- Nk/(Nk-2) * inv %*% crossprod(sc) %*% t(inv)
  c(b[2], sqrt(V[2,2]))
}
eff <- shock_iv(agg[,1], agg[,2])
fs <- shock_iv(agg[,2], agg[,3])
reg_eff <- sum(e*cen[,3]*cen[,1]) / sum(e*cen[,3]*cen[,2])
reg_fs <- sum(e*cen[,3]*cen[,2]) / sum(e*cen[,3]^2)
row <- function(t, est, se) list(term=t, estimate=unname(est), se=if (is.null(se)) NULL else unname(se), n_obs=as.integer(Nk))
out <- list(task_id="applied_shift_share", platform="r",
  estimates=list(row("effect", reg_eff, eff[2]), row("first_stage", reg_fs, fs[2]),
                 row("effective_shocks", 1/sum(mass^2), NULL)),
  method_metadata=list(estimator="weighted 2SLS with BHJ shock-level equivalent IV",
                       vcov="shock-level HC1 N/(N-2), structural IV residuals"),
  diagnostics=list(shock_level_effect=unname(eff[1]), shock_level_first_stage=unname(fs[1]),
                   n_regions=R))
write_json(out, "result.json", auto_unbox=TRUE, null="null", digits=16, pretty=TRUE)
