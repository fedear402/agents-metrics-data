d <- read.csv("input.csv")
cohorts <- c(3, 5, 7)
res <- list()
effs <- numeric(0); ns <- numeric(0); wts <- numeric(0)
for (c in cohorts) {
  s <- d[d$time >= c - 2 & d$time <= c + 2 & (d$g == c | d$g == 0 | d$g > c + 2), ]
  cnt <- table(s$id)
  keep <- names(cnt)[cnt == 5]
  s <- s[as.character(s$id) %in% keep, ]
  s$did <- as.numeric(s$g == c & s$time >= c)
  fit <- lm(y ~ did + factor(id) + factor(time), data = s)
  e <- unname(coef(fit)["did"])
  effs <- c(effs, e); ns <- c(ns, nrow(s))
  wts <- c(wts, length(unique(s$id[s$g == c])))
  res[[length(res) + 1]] <- list(term = paste0("att_g", c), estimate = e, se = NULL, n_obs = nrow(s))
}
res[[length(res) + 1]] <- list(term = "att_weighted", estimate = sum(effs * wts) / sum(wts),
                               se = NULL, n_obs = sum(ns))
out <- list(task_id = "broad_cohort_stack", platform = "r", estimates = res,
            method_metadata = setNames(list(), character(0)),
            diagnostics = setNames(list(), character(0)))
jsonlite::write_json(out, "result.json", auto_unbox = TRUE, null = "null", digits = 16)
