suppressPackageStartupMessages(library(jsonlite))
h <- read.csv("households.csv")
census <- read.csv("census.csv")
d <- h[h$recipient == 0, ]
d <- d[complete.cases(d[, c("eligible","dose","instrument","baseline","outcome","weight")]), ]
e <- d$eligible; ne <- 1 - e
C <- cbind(ne, e, d$baseline * ne, d$baseline * e)
X <- cbind(C, d$dose * ne, d$dose * e)
Z <- cbind(C, d$instrument * ne, d$instrument * e)
sw <- sqrt(d$weight)
Xw <- X * sw; Zw <- Z * sw; yw <- d$outcome * sw
fitted <- qr.fitted(qr(Zw), Xw)
coef <- as.numeric(qr.coef(qr(fitted), yw))
k <- ncol(X)
slopes <- coef[(k - 1):k]
mdose <- sapply(0:1, function(g) {
  a <- d[d$eligible == g, ]
  weighted.mean(a$dose, a$weight)
})
effect <- slopes * mdose
pop <- census$nonrecipient_population[match(0:1, census$eligible)]
population_effect <- sum(effect * pop) / sum(pop)
n <- as.integer(nrow(d))
vals <- c(ineligible_effect = effect[1],
          eligible_nonrecipient_effect = effect[2],
          population_effect = population_effect)
est <- lapply(names(vals), function(t)
  list(term = t, estimate = unname(vals[t]), se = NULL, n_obs = n))
res <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = est,
  method_metadata = list(
    estimator = "weighted 2SLS with group-interacted dose, no common intercept",
    weights = "weight",
    effect_definition = "dose slope times household-weighted mean dose (zero-dose counterfactual)",
    aggregation = "census nonrecipient_population weights"),
  diagnostics = list(
    n_obs = n,
    n_ineligible = as.integer(sum(e == 0)),
    n_eligible = as.integer(sum(e == 1)),
    dose_slope_ineligible = slopes[1],
    dose_slope_eligible = slopes[2],
    mean_dose_ineligible = mdose[1],
    mean_dose_eligible = mdose[2])
)
write_json(res, "result.json", auto_unbox = TRUE, digits = NA, null = "null", pretty = TRUE)
