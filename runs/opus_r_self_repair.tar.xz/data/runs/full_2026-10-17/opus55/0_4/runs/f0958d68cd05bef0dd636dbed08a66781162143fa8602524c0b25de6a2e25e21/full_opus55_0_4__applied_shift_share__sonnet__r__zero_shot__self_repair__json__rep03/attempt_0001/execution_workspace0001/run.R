d <- read.csv("input.csv")
reg <- d[!duplicated(d$region_id), c("region_id","region_weight","x","y")]
reg <- reg[order(reg$region_id),]
reg$e <- reg$region_weight / sum(reg$region_weight)
d$e <- reg$e[match(d$region_id, reg$region_id)]
zr <- tapply(d$share * d$shock, d$region_id, sum)
reg$z <- as.numeric(zr[as.character(reg$region_id)])

wiv <- function(y, x, z, w) {
  X <- cbind(1, x); Z <- cbind(1, z)
  A <- t(Z) %*% (w * X)
  b <- solve(A, t(Z) %*% (w * y))
  u <- as.numeric(y - X %*% b)
  n <- length(y)
  M <- t(Z * (w * u)) %*% (Z * (w * u))
  Ai <- solve(A)
  V <- Ai %*% M %*% t(Ai) * n / (n - 2)
  list(b = b[2], se = sqrt(V[2, 2]))
}

e <- reg$e
y0 <- reg$y - sum(e * reg$y); x0 <- reg$x - sum(e * reg$x); z0 <- reg$z - sum(e * reg$z)
d$y0 <- y0[match(d$region_id, reg$region_id)]
d$x0 <- x0[match(d$region_id, reg$region_id)]
d$z0 <- z0[match(d$region_id, reg$region_id)]
d$es <- d$e * d$share
inds <- sort(unique(d$industry_id))
s <- as.numeric(tapply(d$es, d$industry_id, sum)[as.character(inds)])
agg <- function(v) as.numeric(tapply(d$es * v, d$industry_id, sum)[as.character(inds)]) / s
yb <- agg(d$y0); xb <- agg(d$x0); zb <- agg(d$z0)
g <- as.numeric(tapply(d$shock, d$industry_id, mean)[as.character(inds)])
N <- length(inds)

reg_iv <- wiv(reg$y, reg$x, reg$z, e)
reg_fs <- wiv(reg$x, reg$z, reg$z, e)
sh_iv <- wiv(yb, xb, g, s)
sh_fs <- wiv(xb, zb, g, s)

res <- list(
  task_id = "applied_shift_share", platform = "r",
  estimates = list(
    list(term = "effect", estimate = reg_iv$b, se = sh_iv$se, n_obs = N),
    list(term = "first_stage", estimate = reg_fs$b, se = sh_fs$se, n_obs = N),
    list(term = "effective_shocks", estimate = 1 / sum(s^2), se = NULL, n_obs = N)
  ),
  method_metadata = list(estimator = "weighted 2SLS shift-share (BHJ shock-level)",
                         vcov = "HC1 shock-level, N/(N-2)"),
  diagnostics = list(shock_level_effect = sh_iv$b, shock_level_first_stage = sh_fs$b)
)
writeLines(jsonlite::toJSON(res, auto_unbox = TRUE, digits = 12, null = "null"), "result.json")
