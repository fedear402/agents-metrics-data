d0 <- read.csv('input.csv')
cohorts <- c(3,5,7)
res <- list(); ests <- c(); wts <- c(); ns <- c()
for (c in cohorts) {
  d <- subset(d0, time >= c-2 & time <= c+2 & (g == c | g == 0 | g > c+2))
  cnt <- table(d$id)
  keep <- names(cnt)[cnt == 5]
  d <- d[as.character(d$id) %in% keep, ]
  d$did <- as.numeric(d$g == c & d$time >= c)
  est <- unname(coef(lm(y ~ did + factor(id) + factor(time), data = d))['did'])
  ntr <- length(unique(d$id[d$g == c]))
  ests <- c(ests, est); wts <- c(wts, ntr); ns <- c(ns, nrow(d))
  res[[length(res)+1]] <- list(term = paste0('att_g', c), estimate = est, se = NULL, n_obs = nrow(d))
}
res[[length(res)+1]] <- list(term = 'att_weighted', estimate = sum(ests*wts)/sum(wts),
                             se = NULL, n_obs = sum(ns))
out <- list(task_id = 'broad_cohort_stack', platform = 'r', estimates = res,
            method_metadata = structure(list(), names = character(0)),
            diagnostics = structure(list(), names = character(0)))
jsonlite::write_json(out, 'result.json', auto_unbox = TRUE, null = 'null', digits = 16)
