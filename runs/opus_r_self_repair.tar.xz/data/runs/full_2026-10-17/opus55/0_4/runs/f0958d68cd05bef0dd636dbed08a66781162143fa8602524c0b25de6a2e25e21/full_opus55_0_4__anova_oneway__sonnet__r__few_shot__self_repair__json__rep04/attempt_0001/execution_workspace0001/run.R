library(jsonlite)
d <- read.csv("./input.csv", stringsAsFactors = FALSE)
d <- d[!is.na(d$y) & !is.na(d$group) & d$group != "", c("group", "y")]
d$y <- as.numeric(d$y)
d <- d[!is.na(d$y), ]
d$group <- factor(d$group)
fit <- aov(y ~ group, data = d)
tab <- summary(fit)[[1]]
F_stat <- unname(tab[["F value"]][1])
df_num <- unname(tab[["Df"]][1])
df_den <- unname(tab[["Df"]][2])
p_val <- unname(tab[["Pr(>F)"]][1])
n <- nrow(d)
out <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = list(
    list(term = "F", estimate = F_stat, se = NA, n_obs = n),
    list(term = "df_num", estimate = as.numeric(df_num), se = NA, n_obs = n),
    list(term = "df_den", estimate = as.numeric(df_den), se = NA, n_obs = n),
    list(term = "p_value", estimate = p_val, se = NA, n_obs = n)
  ),
  method_metadata = list(estimator = "One-way ANOVA (classical F test, equal variances)",
                         vcov = "none"),
  diagnostics = structure(list(), names = character(0))
)
write_json(out, "result.json", auto_unbox = TRUE, digits = NA, na = "null")
