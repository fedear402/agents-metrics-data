library(jsonlite)
d <- read.csv("input.csv", stringsAsFactors = FALSE)
d$region_id <- as.character(d$region_id)
d$industry_id <- as.character(d$industry_id)
regions <- sort(unique(d$region_id))
industries <- sort(unique(d$industry_id))
R <- length(regions); N <- length(industries)

S <- matrix(0, R, N, dimnames = list(regions, industries))
S[cbind(match(d$region_id, regions), match(d$industry_id, industries))] <- d$share
ind <- d[!duplicated(d$industry_id), ]
shock <- ind$shock[match(industries, ind$industry_id)]
reg <- d[!duplicated(d$region_id), ]
reg <- reg[match(regions, reg$region_id), ]

e <- reg$region_weight / sum(reg$region_weight)
z <- drop(S %*% shock)
regional <- cbind(y = reg$y, x = reg$x, z = z)
centered <- sweep(regional, 2, drop(e %*% regional))
mass <- drop(e %*% S)
keep <- mass > 0
aggregated <- (t(S) %*% (e * centered))[keep, , drop = FALSE] / mass[keep]
m <- mass[keep]; g <- shock[keep]; Nk <- sum(keep)

shock_iv <- function(dep, endo) {
  X <- cbind(1, endo); Z <- cbind(1, g)
  cross <- crossprod(Z, m * X)
  beta <- solve(cross, crossprod(Z, m * dep))
  res <- drop(dep - X %*% beta)
  sc <- Z * (m * res)
  inv <- solve(cross)
  V <- Nk / (Nk - 2) * inv %*% crossprod(sc) %*% t(inv)
  c(beta[2], sqrt(V[2, 2]))
}
eff <- shock_iv(aggregated[, "y"], aggregated[, "x"])
fs <- shock_iv(aggregated[, "x"], aggregated[, "z"])

reg_eff <- sum(e * centered[, "z"] * centered[, "y"]) / sum(e * centered[, "z"] * centered[, "x"])
reg_fs <- sum(e * centered[, "z"] * centered[, "x"]) / sum(e * centered[, "z"]^2)

row <- function(term, est, se, n) list(term = term, estimate = unname(as.numeric(est)),
  se = if (is.null(se)) NULL else unname(as.numeric(se)), n_obs = as.integer(n))

out <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    row("effect", reg_eff, eff[2], Nk),
    row("first_stage", reg_fs, fs[2], Nk),
    row("effective_shocks", 1 / sum(m^2), NULL, Nk)
  ),
  method_metadata = list(estimator = "weighted 2SLS with BHJ shock-level equivalent IV",
                         vcov = "shock-level HC1 (N/(N-2)), structural IV residuals"),
  diagnostics = list(shock_level_effect = eff[1], shock_level_first_stage = fs[1],
                     n_regions = R, n_industries = Nk)
)
write_json(out, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
