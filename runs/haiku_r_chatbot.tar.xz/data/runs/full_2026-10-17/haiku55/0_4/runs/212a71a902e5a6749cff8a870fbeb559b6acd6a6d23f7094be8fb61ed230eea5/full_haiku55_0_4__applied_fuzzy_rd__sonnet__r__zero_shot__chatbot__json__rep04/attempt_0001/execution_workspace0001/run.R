suppressPackageStartupMessages(library(jsonlite))

d <- read.csv("input.csv")
d <- d[abs(d$score) < 1, ]
d$w <- 1 - abs(d$score)
n_total <- nrow(d)

fit_side <- function(sub) {
  X <- cbind(1, sub$score)
  ww <- sub$w
  Xs <- X * ww
  B <- solve(crossprod(X, Xs))
  y1 <- sub$earnings
  y2 <- sub$participated
  b1 <- B %*% crossprod(Xs, y1)
  b2 <- B %*% crossprod(Xs, y2)
  e1 <- as.vector(y1 - X %*% b1)
  e2 <- as.vector(y2 - X %*% b2)
  M11 <- crossprod(Xs * e1)
  M22 <- crossprod(Xs * e2)
  M12 <- crossprod(Xs * e1, Xs * e2)
  list(
    a1 = as.numeric(b1[1]),
    a2 = as.numeric(b2[1]),
    V11 = as.numeric((B %*% M11 %*% B)[1, 1]),
    V22 = as.numeric((B %*% M22 %*% B)[1, 1]),
    V12 = as.numeric((B %*% M12 %*% B)[1, 1]),
    n = nrow(sub)
  )
}

right <- fit_side(d[d$score >= 0, ])
left  <- fit_side(d[d$score < 0, ])

rf <- right$a1 - left$a1
fs <- right$a2 - left$a2

V_rf <- right$V11 + left$V11
V_fs <- right$V22 + left$V22
C_rf_fs <- right$V12 + left$V12

V <- matrix(c(V_rf, C_rf_fs, C_rf_fs, V_fs), 2, 2)

tau <- rf / fs
g <- c(1 / fs, -rf / fs^2)
V_tau <- as.numeric(t(g) %*% V %*% g)

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = tau, se = sqrt(V_tau), n_obs = n_total),
    list(term = "reduced_form", estimate = rf, se = sqrt(V_rf), n_obs = n_total),
    list(term = "first_stage", estimate = fs, se = sqrt(V_fs), n_obs = n_total)
  ),
  method_metadata = list(
    estimator = "Sharp-bandwidth fuzzy RD, local linear WLS with triangular kernel, bandwidth 1, cutoff 0, separate slopes and intercepts per side, ratio via delta method",
    vcov = "HC0 sandwich (no df correction) for each side, joint covariance across outcomes, delta method for treatment_effect"
  ),
  diagnostics = list(
    bandwidth = 1,
    cutoff = 0,
    n_right = right$n,
    n_left = left$n,
    covariance_reduced_form_first_stage = C_rf_fs
  )
)

write(toJSON(result, auto_unbox = TRUE, digits = NA, pretty = TRUE), "result.json")
