suppressPackageStartupMessages(library(jsonlite))

d <- read.csv("input.csv")
n <- nrow(d)
y <- d$y
en <- d$endog
x <- d$x
z1 <- d$z1
z2 <- d$z2

df2 <- n - 4
c95 <- qf(0.95, 2, df2)
W <- cbind(1, x, z1, z2)
W0 <- cbind(1, x)

Fstat <- function(b) {
  yb <- y - b * en
  r1 <- qr.resid(qr(W), yb)
  r0 <- qr.resid(qr(W0), yb)
  ((sum(r0^2) - sum(r1^2)) / 2) / (sum(r1^2) / df2)
}

u1 <- qr.resid(qr(W), y)
v1 <- qr.resid(qr(W), en)
u0 <- qr.resid(qr(W0), y)
v0 <- qr.resid(qr(W0), en)

k <- 1 + 2 * c95 / df2
a2 <- sum(v0^2) - k * sum(v1^2)
a1 <- -2 * (sum(u0 * v0) - k * sum(u1 * v1))
a0 <- sum(u0^2) - k * sum(u1^2)

disc <- a1^2 - 4 * a2 * a0
if (disc >= 0 && a2 != 0) {
  r <- sort((-a1 + c(-1, 1) * sqrt(disc)) / (2 * a2))
  bl <- r[1]
  bh <- r[2]
} else {
  bl <- NA_real_
  bh <- NA_real_
}

accepts_zero <- as.numeric(Fstat(0) <= c95)
unbounded <- as.numeric(a2 <= 0)
ar_f_at_one <- Fstat(1)

out <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = list(
    list(term = "boundary_low", estimate = bl, se = NA_real_, n_obs = n),
    list(term = "boundary_high", estimate = bh, se = NA_real_, n_obs = n),
    list(term = "accepts_zero", estimate = accepts_zero, se = NA_real_, n_obs = n),
    list(term = "unbounded", estimate = unbounded, se = NA_real_, n_obs = n),
    list(term = "ar_f_at_one", estimate = ar_f_at_one, se = NA_real_, n_obs = n)
  ),
  method_metadata = list(
    estimator = "Anderson-Rubin test inversion, homoskedastic F test of excluded instruments",
    vcov = "homoskedastic"
  ),
  diagnostics = setNames(list(), character(0))
)

writeLines(toJSON(out, auto_unbox = TRUE, digits = NA, na = "null", null = "null", pretty = TRUE), "result.json")
