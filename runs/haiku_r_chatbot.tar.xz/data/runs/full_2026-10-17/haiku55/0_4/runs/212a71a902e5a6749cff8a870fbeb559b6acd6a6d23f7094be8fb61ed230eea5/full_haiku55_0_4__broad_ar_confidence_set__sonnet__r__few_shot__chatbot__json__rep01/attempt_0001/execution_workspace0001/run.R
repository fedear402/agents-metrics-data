d <- read.csv("input.csv")
n <- nrow(d)
q <- 2L
df <- n - 4L
critical <- qf(0.95, q, df)
k <- q * critical / df

ry <- residuals(lm(y ~ x + z1 + z2, data = d))
rd <- residuals(lm(endog ~ x + z1 + z2, data = d))
uy <- residuals(lm(y ~ endog + x + z1 + z2, data = d))
ud <- residuals(lm(endog ~ x + z1 + z2, data = d))

# Residualizing on x, z1, z2 for the restricted/unrestricted SSR comparison
Z <- model.matrix(~ x + z1 + z2, data = d)
P <- Z %*% solve(crossprod(Z), t(Z))
M <- diag(n) - P
yv <- d$y
dv <- d$endog

# SSR_U(beta) = y_b' M y_b with y_b = y - beta*endog; SSR_R(beta) = y_b' M_1 y_b
# where M_1 partials out only the intercept (the restricted model also has x,z1,z2 removed
# under the null, so SSR_R is residual from regressing y_b on intercept only)
# Note: the test regresses y_b on intercept, x, z1, z2 (full) vs intercept only (restricted)
# per the spec's F definition, with q = number of excluded instruments.
ssr_full <- function(beta) {
  yb <- yv - beta * dv
  sum(residuals(lm(yb ~ x + z1 + z2, data = d))^2)
}
ssr_restr <- function(beta) {
  yb <- yv - beta * dv
  sum(residuals(lm(yb ~ x, data = d))^2)
}

# Quadratic form: SSR_R - (1+k)*SSR_U <= 0 over beta, using the exact
# identities for SSR as quadratics in beta.
# Build coefficients via three evaluations of the difference function.
g <- function(beta) ssr_restr(beta) - (1 + k) * ssr_full(beta)
b0 <- 0; b1 <- 1; b2 <- -1
g0 <- g(b0); g1 <- g(b1); g2 <- g(b2)
C <- g0
A <- (g1 + g2 - 2 * g0) / 2
B <- (g1 - g2) / 2

stopifnot(abs(A) > 1e-10, B^2 - 4 * A * C > 0)
roots <- sort(Re(polyroot(c(C, B, A))))
bounds <- roots

accepts <- function(beta) A * beta^2 + B * beta + C <= 0
unbounded <- as.integer(A < 0)
accepts_zero <- as.integer(accepts(0))
ar_f_at_one <- ((ssr_restr(1) - ssr_full(1)) / q) / (ssr_full(1) / df)

out <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = list(
    list(term = "boundary_low", estimate = unname(bounds[1]), se = NULL, n_obs = as.integer(n)),
    list(term = "boundary_high", estimate = unname(bounds[2]), se = NULL, n_obs = as.integer(n)),
    list(term = "accepts_zero", estimate = accepts_zero, se = NULL, n_obs = as.integer(n)),
    list(term = "unbounded", estimate = unbounded, se = NULL, n_obs = as.integer(n)),
    list(term = "ar_f_at_one", estimate = unname(ar_f_at_one), se = NULL, n_obs = as.integer(n))
  ),
  method_metadata = list(
    estimator = "Anderson-Rubin confidence set via homoskedastic joint F test inversion",
    vcov = "homoskedastic"
  ),
  diagnostics = setNames(list(), character(0))
)

jsonlite::write_json(out, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
