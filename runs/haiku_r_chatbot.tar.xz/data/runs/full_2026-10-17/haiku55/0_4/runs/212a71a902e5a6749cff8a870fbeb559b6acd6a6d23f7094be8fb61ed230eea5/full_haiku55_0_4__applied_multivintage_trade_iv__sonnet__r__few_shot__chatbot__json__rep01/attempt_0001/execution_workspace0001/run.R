crosswalk <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
trade <- read.csv("trade.csv", stringsAsFactors = FALSE)
areas <- read.csv("areas.csv", stringsAsFactors = FALSE)
employment <- read.csv("employment.csv", stringsAsFactors = FALSE)
outcomes <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

iv <- function(y, C, x, z, w = rep(1, length(y))) {
  X <- cbind(C, x) * sqrt(w)
  Z <- cbind(C, z) * sqrt(w)
  fitted <- qr.fitted(qr(Z), X)
  as.numeric(qr.coef(qr(fitted), y * sqrt(w)))[ncol(X)]
}

trade$industry <- crosswalk$industry[match(trade$code, crosswalk$code)]
inds <- sort(unique(trade$industry))
tkey <- paste(trade$period, trade$industry, sep = "|")

emp_key <- paste(employment$area, employment$period, employment$vintage, employment$industry, sep = "|")
emp_sum <- tapply(employment$employment, emp_key, sum)
emp_sum <- setNames(as.vector(emp_sum), names(emp_sum))

nat_key <- paste(employment$period, employment$vintage, employment$industry, sep = "|")
nat_sum <- tapply(employment$employment, nat_key, sum)
nat_sum <- setNames(as.vector(nat_sum), names(nat_sum))

popk <- paste(areas$area, areas$period, areas$vintage, sep = "|")
tot <- setNames(areas$total_employment, popk)

get_emp <- function(k) {
  v <- emp_sum[k]
  v[is.na(v)] <- 0
  unname(v)
}

expo <- function(ar, pe, vint, chg) {
  per_scale <- (10 / trade$years[match(pe, trade$period)]) /
    (trade$price_index[match(pe, trade$period)] / 100) / 1000
  total <- unname(tot[paste(ar, pe, vint, sep = "|")])
  s <- numeric(length(ar))
  for (j in inds) {
    e <- get_emp(paste(ar, pe, vint, j, sep = "|"))
    nat <- unname(nat_sum[paste(pe, vint, j, sep = "|")])
    chg_j <- trade[[chg]][match(paste(pe, j, sep = "|"), tkey)]
    s <- s + e / total * chg_j / nat
  }
  unname(s * per_scale)
}

d <- outcomes
d$x <- expo(d$area, d$period, "base", "us_change")
d$z <- expo(d$area, d$period, "early", "other_change")
d$w <- areas$population[match(paste(d$area, d$period, "base", sep = "|"), popk)]

C <- cbind(1, d$period, d$control)
iv_slope <- iv(d$change_pp, C, d$x, d$z, d$w)

i0 <- which(d$area == 0 & d$period == 0)
i1 <- which(d$area == 0 & d$period == 1)

n_obs <- as.integer(nrow(d))

est <- function(term, value) {
  list(term = term, estimate = unname(as.numeric(value)), se = NA_real_, n_obs = n_obs)
}

res <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = list(
    est("iv_slope", iv_slope),
    est("exposure_area0_period0", d$x[i0]),
    est("exposure_area0_period1", d$x[i1]),
    est("instrument_area0_period0", d$z[i0])
  ),
  method_metadata = list(
    estimator = "weighted_2sls",
    weight = "base_vintage_population",
    endogenous = "x",
    instruments = "z",
    exogenous = c("intercept", "period", "control"),
    exposure_units = "thousands of real dollars per worker per decade",
    outcome_units = "percentage points per decade",
    industries = as.character(inds)
  ),
  diagnostics = list(
    n_obs = n_obs,
    n_industries = as.integer(length(inds)),
    n_areas = as.integer(length(unique(d$area))),
    n_periods = as.integer(length(unique(d$period))),
    all_national_employment_positive = all(nat_sum > 0)
  )
)

jsonlite::write_json(res, "result.json", auto_unbox = TRUE, digits = 15, na = "null", pretty = TRUE)
