d <- read.csv("input.csv")
cohorts <- c(3, 5, 7)

comp <- lapply(cohorts, function(cc) {
  w <- d[d$time >= cc - 2 & d$time <= cc + 2 &
           (d$g == cc | d$g == 0 | d$g > cc + 2), ]
  n_times <- tapply(w$time, as.character(w$id), function(x) length(unique(x)))
  keep <- names(n_times)[n_times == 5]
  w <- w[as.character(w$id) %in% keep, ]
  w$did <- as.numeric(w$g == cc & w$time >= cc)
  fit <- lm(y ~ did + factor(id) + factor(time), data = w)
  list(
    att = unname(coef(fit)["did"]),
    n_obs = nrow(w),
    n_treated = length(unique(w$id[w$g == cc]))
  )
})

atts <- vapply(comp, `[[`, numeric(1), "att")
n_obs <- vapply(comp, `[[`, numeric(1), "n_obs")
weights <- vapply(comp, `[[`, numeric(1), "n_treated")
att_weighted <- sum(weights * atts) / sum(weights)

empty_named <- setNames(list(), character(0))

out <- list(
  task_id = "broad_cohort_stack",
  platform = "r",
  estimates = list(
    list(term = "att_g3", estimate = atts[1], se = NULL, n_obs = as.integer(n_obs[1])),
    list(term = "att_g5", estimate = atts[2], se = NULL, n_obs = as.integer(n_obs[2])),
    list(term = "att_g7", estimate = atts[3], se = NULL, n_obs = as.integer(n_obs[3])),
    list(term = "att_weighted", estimate = att_weighted, se = NULL,
         n_obs = as.integer(sum(n_obs)))
  ),
  method_metadata = empty_named,
  diagnostics = empty_named
)

jsonlite::write_json(out, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
