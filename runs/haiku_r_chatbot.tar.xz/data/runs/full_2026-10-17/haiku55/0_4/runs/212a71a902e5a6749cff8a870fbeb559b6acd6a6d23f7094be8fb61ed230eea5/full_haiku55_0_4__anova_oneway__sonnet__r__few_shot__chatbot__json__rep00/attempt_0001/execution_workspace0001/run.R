library(jsonlite)
df <- read.csv("./input.csv", stringsAsFactors = FALSE)
df$group <- factor(df$group)
fit <- aov(y ~ group, data = df)
s <- summary(fit)[[1]]
F_stat <- unname(s[["F value"]][1])
df_num <- unname(s[["Df"]][1])
df_den <- unname(s[["Df"]][2])
p_val <- unname(s[["Pr(>F)"]][1])
n_obs <- nrow(df)
out <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = list(
    list(term = "F", estimate = F_stat, se = NA, n_obs = n_obs),
    list(term = "df_num", estimate = df_num, se = NA, n_obs = n_obs),
    list(term = "df_den", estimate = df_den, se = NA, n_obs = n_obs),
    list(term = "p_value", estimate = p_val, se = NA, n_obs = n_obs)
  ),
  method_metadata = list(estimator = "One-way ANOVA (aov)", vcov = "none"),
  diagnostics = structure(list(), names = character(0))
)
write_json(out, "result.json", auto_unbox = TRUE, digits = NA)
