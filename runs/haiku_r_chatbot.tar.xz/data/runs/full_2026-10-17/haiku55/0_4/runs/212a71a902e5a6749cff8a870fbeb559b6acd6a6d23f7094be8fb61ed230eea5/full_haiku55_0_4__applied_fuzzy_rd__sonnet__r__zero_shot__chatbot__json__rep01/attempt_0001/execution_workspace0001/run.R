library(jsonlite)

df <- read.csv("input.csv")
h <- 1
d <- df[abs(df$score) < h, ]
d$w <- 1 - abs(d$score)
n <- nrow(d)
R <- d$score >= 0
L <- !R

infl <- function(idx, y) {
  sub <- d[idx, ]
  X <- cbind(1, sub$score)
  W <- sub$w
  A <- solve(crossprod(X, X * W))
  b <- as.vector(A %*% crossprod(X, W * y[idx]))
  e <- y[idx] - as.vector(X %*% b)
  g <- as.vector(X %*% A[1, ]) * W
  list(a = b[1], psi = g * e)
}

yv <- d$earnings
dv <- d$participated

rY <- infl(R, yv)
lY <- infl(L, yv)
rD <- infl(R, dv)
lD <- infl(L, dv)

psiY <- numeric(n)
psiY[R] <- rY$psi
psiY[L] <- -lY$psi

psiD <- numeric(n)
psiD[R] <- rD$psi
psiD[L] <- -lD$psi

tauY <- rY$a - lY$a
tauD <- rD$a - lD$a
VY <- sum(psiY^2)
VD <- sum(psiD^2)
CYD <- sum(psiY * psiD)

tau <- tauY / tauD
varTau <- VY / tauD^2 + tauY^2 * VD / tauD^4 - 2 * tauY * CYD / tauD^3
seTau <- sqrt(varTau)

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = tau, se = seTau, n_obs = as.integer(n)),
    list(term = "reduced_form", estimate = tauY, se = sqrt(VY), n_obs = as.integer(n)),
    list(term = "first_stage", estimate = tauD, se = sqrt(VD), n_obs = as.integer(n))
  ),
  method_metadata = list(
    estimator = "Fuzzy RD, local linear with separate intercepts and slopes, triangular kernel, cutoff 0, bandwidth 1",
    vcov = "HC0 heteroskedasticity-robust, delta method for ratio using joint covariance"
  ),
  diagnostics = list(
    n_left = as.integer(sum(L)),
    n_right = as.integer(sum(R))
  )
)

write_json(result, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE)
