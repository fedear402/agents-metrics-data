library(jsonlite)

hh <- read.csv("households.csv", stringsAsFactors = FALSE)
census <- read.csv("census.csv", stringsAsFactors = FALSE)

d <- hh[hh$recipient == 0, , drop = FALSE]
n <- nrow(d)

e <- as.numeric(d$eligible)
ne <- 1 - e
w <- as.numeric(d$weight)
dose <- as.numeric(d$dose)
base <- as.numeric(d$baseline)
inst <- as.numeric(d$instrument)
y <- as.numeric(d$outcome)

exog <- cbind(
  nonelig = ne,
  elig = e,
  base_nonelig = base * ne,
  base_elig = base * e
)

X <- cbind(
  exog,
  dose_nonelig = dose * ne,
  dose_elig = dose * e
)

Z <- cbind(
  exog,
  inst_nonelig = inst * ne,
  inst_elig = inst * e
)

ZW <- Z * w
A <- crossprod(Z, ZW)
Ainv <- solve(A)
XZ <- crossprod(X, ZW)
Zy <- crossprod(ZW, y)
M <- XZ %*% Ainv %*% t(XZ)
beta <- drop(solve(M, XZ %*% Ainv %*% Zy))
names(beta) <- colnames(X)

slope_ne <- beta["dose_nonelig"]
slope_e <- beta["dose_elig"]

idx_ne <- ne == 1
idx_e <- e == 1
mean_dose_ne <- sum(w[idx_ne] * dose[idx_ne]) / sum(w[idx_ne])
mean_dose_e <- sum(w[idx_e] * dose[idx_e]) / sum(w[idx_e])

ineligible_effect <- unname(slope_ne * mean_dose_ne)
eligible_nonrecipient_effect <- unname(slope_e * mean_dose_e)

N_ne <- as.numeric(census$nonrecipient_population[census$eligible == 0])
N_e <- as.numeric(census$nonrecipient_population[census$eligible == 1])
population_effect <- unname((N_ne * ineligible_effect + N_e * eligible_nonrecipient_effect) / (N_ne + N_e))

n_obs <- as.integer(n)

estimates <- list(
  list(term = "ineligible_effect", estimate = ineligible_effect, se = NULL, n_obs = n_obs),
  list(term = "eligible_nonrecipient_effect", estimate = eligible_nonrecipient_effect, se = NULL, n_obs = n_obs),
  list(term = "population_effect", estimate = population_effect, se = NULL, n_obs = n_obs)
)

method_metadata <- list(
  method = "weighted two-stage least squares",
  regression_weight = "weight",
  intercept = FALSE,
  endogenous = c("dose_nonelig", "dose_elig"),
  exogenous = colnames(exog),
  instruments = colnames(Z),
  sample = "households with recipient == 0, both treatment statuses retained",
  group_effect = "dose slope times weighted mean dose within eligibility group",
  population_weights = "census nonrecipient_population by eligible",
  counterfactual = "dose set to zero for every retained household",
  attribution = "stated synthetic convention"
)

diagnostics <- list(
  n_obs = n_obs,
  n_ineligible = as.integer(sum(idx_ne)),
  n_eligible = as.integer(sum(idx_e)),
  slope_ineligible = unname(slope_ne),
  slope_eligible = unname(slope_e),
  weighted_mean_dose_ineligible = mean_dose_ne,
  weighted_mean_dose_eligible = mean_dose_e,
  census_nonrecipient_population_ineligible = N_ne,
  census_nonrecipient_population_eligible = N_e
)

result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = method_metadata,
  diagnostics = diagnostics
)

write_json(result, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE, null = "null")
