suppressPackageStartupMessages(library(jsonlite))

d <- read.csv("./input.csv")
d <- d[order(d$t), ]
y <- as.numeric(d$y)
n_obs <- length(y)

fit <- arima(y, order = c(1, 1, 1), include.mean = FALSE, method = "ML")
pr <- predict(fit, n.ahead = 1)

fc <- as.numeric(pr$pred)
se_fc <- as.numeric(pr$se)
z <- qnorm(0.975)
lower <- fc - z * se_fc
upper <- fc + z * se_fc

coef_fit <- coef(fit)

out <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = list(
    list(term = "forecast", estimate = fc, se = se_fc, n_obs = n_obs),
    list(term = "lower_95", estimate = lower, se = NA_real_, n_obs = n_obs),
    list(term = "upper_95", estimate = upper, se = NA_real_, n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "ARIMA(1,1,1) maximum likelihood on levels, no constant or drift (stats::arima)",
    vcov = "ML observed information (stats::arima)"
  ),
  diagnostics = list(
    ar1 = unname(coef_fit["ar1"]),
    ma1 = unname(coef_fit["ma1"]),
    sigma2 = fit$sigma2,
    loglik = fit$loglik,
    aic = fit$aic
  )
)

json <- toJSON(out, auto_unbox = TRUE, digits = 15, na = "null", pretty = TRUE)
write(json, file = "result.json")
