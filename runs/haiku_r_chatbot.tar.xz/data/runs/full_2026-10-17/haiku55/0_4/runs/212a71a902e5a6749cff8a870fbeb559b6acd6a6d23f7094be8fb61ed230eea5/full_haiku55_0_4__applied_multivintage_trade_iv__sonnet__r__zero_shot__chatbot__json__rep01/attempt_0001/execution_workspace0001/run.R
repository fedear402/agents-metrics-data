library(jsonlite)

crosswalk <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
trade <- read.csv("trade.csv", stringsAsFactors = FALSE)
areas <- read.csv("areas.csv", stringsAsFactors = FALSE)
employment <- read.csv("employment.csv", stringsAsFactors = FALSE)
outcomes <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

crosswalk$code <- as.character(crosswalk$code)
trade$code <- as.character(trade$code)
trade <- merge(trade, crosswalk, by = "code")

inds <- sort(unique(crosswalk$industry))

per <- trade[!duplicated(trade$period), c("period", "price_index", "years")]
trade_key <- paste(trade$period, trade$industry, sep = "|")

employment$employment[is.na(employment$employment)] <- 0
emp_val <- employment$employment
emp_key <- paste(employment$area, employment$period, employment$vintage, employment$industry, sep = "|")

nat <- aggregate(employment ~ period + vintage + industry, data = employment, FUN = sum)
names(nat)[names(nat) == "employment"] <- "emp_val"
nat_key <- paste(nat$period, nat$vintage, nat$industry, sep = "|")

tot_key <- paste(areas$area, areas$period, areas$vintage, sep = "|")
ab <- areas[areas$vintage == "base", ]
pop_key <- paste(ab$area, ab$period, sep = "|")

obs <- outcomes
pop <- ab$population[match(paste(obs$area, obs$period, sep = "|"), pop_key)]

lookup <- function(key, keys, vals) {
  v <- vals[match(key, keys)]
  v[is.na(v)] <- 0
  v
}

exposure <- function(a, p, vint, shock) {
  tot <- areas$total_employment[match(paste(a, p, vint, sep = "|"), tot_key)]
  pr <- per$price_index[match(p, per$period)]
  yr <- per$years[match(p, per$period)]
  s <- 0
  for (j in inds) {
    e <- lookup(paste(a, p, vint, j, sep = "|"), emp_key, emp_val)
    n <- lookup(paste(p, vint, j, sep = "|"), nat_key, nat$emp_val)
    ch <- trade[[shock]][match(paste(p, j, sep = "|"), trade_key)]
    s <- s + (e / tot) * (ch / n) / (pr / 100) / 1000 * (10 / yr)
  }
  s
}

n_obs <- nrow(obs)
x <- vapply(seq_len(n_obs), function(i) exposure(obs$area[i], obs$period[i], "base", "us_change"), numeric(1))
z <- vapply(seq_len(n_obs), function(i) exposure(obs$area[i], obs$period[i], "early", "other_change"), numeric(1))

i0p0 <- which(as.character(obs$area) == "0" & as.character(obs$period) == "0")
i0p1 <- which(as.character(obs$area) == "0" & as.character(obs$period) == "1")

y <- as.numeric(obs$change_pp)
per_v <- as.numeric(obs$period)
ctl <- as.numeric(obs$control)
w <- as.numeric(pop)

X <- cbind(1, per_v, ctl, x)
Z <- cbind(1, per_v, ctl, z)
colnames(X) <- c("intercept", "period", "control", "x")

ZW <- w * Z
ZWZ_inv <- solve(crossprod(Z, ZW))
A <- crossprod(X, ZW) %*% ZWZ_inv %*% crossprod(Z, w * X)
b <- crossprod(X, ZW) %*% ZWZ_inv %*% crossprod(Z, w * y)
beta <- solve(A, b)
iv_slope <- as.numeric(beta[4, 1])

est <- list(
  list(term = "iv_slope", estimate = iv_slope, se = NA_real_, n_obs = as.integer(n_obs)),
  list(term = "exposure_area0_period0", estimate = as.numeric(x[i0p0][1]), se = NA_real_, n_obs = as.integer(n_obs)),
  list(term = "exposure_area0_period1", estimate = as.numeric(x[i0p1][1]), se = NA_real_, n_obs = as.integer(n_obs)),
  list(term = "instrument_area0_period0", estimate = as.numeric(z[i0p0][1]), se = NA_real_, n_obs = as.integer(n_obs))
)

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = est,
  method_metadata = list(
    estimator = "weighted_2sls",
    weight = "base_vintage_population",
    endogenous = "x",
    instruments = "z",
    exogenous = c("intercept", "period", "control"),
    n_obs = as.integer(n_obs)
  ),
  diagnostics = list(
    n_obs = as.integer(n_obs),
    n_industries = as.integer(length(inds)),
    n_areas = as.integer(length(unique(obs$area))),
    n_periods = as.integer(length(unique(obs$period)))
  )
)

write_json(result, "result.json", auto_unbox = TRUE, digits = NA, na = "null", pretty = TRUE)
