hh <- read.csv("households.csv")
census <- read.csv("census.csv")

d <- subset(hh, recipient == 0)
e <- d$eligible
b <- d$baseline
dose <- d$dose
z <- d$instrument
w <- d$weight
y <- d$outcome
n <- nrow(d)

X <- cbind(1 - e, e, b * (1 - e), b * e, dose * (1 - e), dose * e)
Z <- cbind(1 - e, e, b * (1 - e), b * e, z * (1 - e), z * e)

sw <- sqrt(w)
Xw <- X * sw
Zw <- Z * sw
yw <- y * sw

fitted <- qr.fitted(qr(Zw), Xw)
beta <- as.numeric(qr.coef(qr(fitted), yw))
slope <- beta[5:6]

group_effect <- function(g) {
  idx <- e == g
  slope[g + 1] * weighted.mean(dose[idx], w[idx])
}

ineligible_effect <- group_effect(0)
eligible_nonrecipient_effect <- group_effect(1)
effects <- c(ineligible_effect, eligible_nonrecipient_effect)

pop_weights <- census$nonrecipient_population[match(0:1, census$eligible)]
population_effect <- weighted.mean(effects, pop_weights)

est <- function(term, value) {
  list(term = term, estimate = value, se = NULL, n_obs = as.integer(n))
}

result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = list(
    est("ineligible_effect", ineligible_effect),
    est("eligible_nonrecipient_effect", eligible_nonrecipient_effect),
    est("population_effect", population_effect)
  ),
  method_metadata = list(
    estimator = "weighted 2SLS",
    sample = "households with recipient == 0",
    endogenous = c("dose*(1-eligible)", "dose*eligible"),
    exogenous = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"),
    instruments = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible",
                    "instrument*(1-eligible)", "instrument*eligible"),
    intercept = "none; group indicators serve as intercepts",
    regression_weight = "weight",
    group_effect = "dose slope times household-weighted mean dose within eligibility group",
    aggregation_weights = "census nonrecipient_population",
    counterfactual = "dose set to zero for every retained household",
    convention_note = "attribution to a zero-dose counterfactual is a stated synthetic convention"
  ),
  diagnostics = list(
    n_obs = as.integer(n),
    n_ineligible = as.integer(sum(e == 0)),
    n_eligible = as.integer(sum(e == 1)),
    instrument_matrix_rank = qr(Zw)$rank,
    regressor_matrix_columns = ncol(X),
    ineligible_dose_slope = slope[1],
    eligible_dose_slope = slope[2]
  )
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE)
