library(jsonlite)

d <- read.csv("input.csv")
y <- d$y
e <- d$endog
n <- nrow(d)

X <- cbind(1, d$x)
W <- cbind(X, d$z1, d$z2)

rx <- function(v) qr.resid(qr(X), v)
rw <- function(v) qr.resid(qr(W), v)

yx <- rx(y)
ex <- rx(e)
yw <- rw(y)
ew <- rw(e)

cr <- c(sum(yx^2), -2 * sum(yx * ex), sum(ex^2))
cu <- c(sum(yw^2), -2 * sum(yw * ew), sum(ew^2))

c95 <- qf(0.95, 2, n - 4)
k <- 1 + 2 * c95 / (n - 4)

A <- cr[3] - k * cu[3]
B <- cr[2] - k * cu[2]
C <- cr[1] - k * cu[1]

disc <- B^2 - 4 * A * C
if (disc >= 0 && A != 0) {
  r <- sort((-B + c(-1, 1) * sqrt(disc)) / (2 * A))
  boundary_low <- r[1]
  boundary_high <- r[2]
} else {
  boundary_low <- NA_real_
  boundary_high <- NA_real_
}

accepts_zero <- as.integer(C <= 0)
unbounded <- as.integer(A <= 0)

rss_r1 <- sum(rx(y - e)^2)
rss_u1 <- sum(rw(y - e)^2)
ar_f_at_one <- ((rss_r1 - rss_u1) / 2) / (rss_u1 / (n - 4))

est <- function(term, value) {
  list(term = term, estimate = value, se = NA_real_, n_obs = n)
}

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = list(
    est("boundary_low", boundary_low),
    est("boundary_high", boundary_high),
    est("accepts_zero", accepts_zero),
    est("unbounded", unbounded),
    est("ar_f_at_one", ar_f_at_one)
  ),
  method_metadata = list(
    estimator = "Anderson-Rubin test inversion with homoskedastic joint F test",
    vcov = "homoskedastic"
  ),
  diagnostics = list(
    critical_value = c95,
    quadratic_A = A,
    quadratic_B = B,
    quadratic_C = C,
    discriminant = disc
  )
)

write_json(result, "result.json", auto_unbox = TRUE, digits = NA, na = "null", pretty = TRUE)
