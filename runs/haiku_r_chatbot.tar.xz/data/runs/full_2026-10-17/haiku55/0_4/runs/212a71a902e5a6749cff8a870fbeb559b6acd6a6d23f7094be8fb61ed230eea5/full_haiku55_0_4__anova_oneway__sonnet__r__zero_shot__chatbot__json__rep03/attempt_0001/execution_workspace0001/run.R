suppressPackageStartupMessages({
  library(jsonlite)
})

df <- read.csv("./input.csv", stringsAsFactors = FALSE)
df$group <- factor(df$group)
df <- df[!is.na(df$y) & !is.na(df$group), ]

fit <- aov(y ~ group, data = df)
tab <- summary(fit)[[1]]

F_stat <- tab[["F value"]][1]
df_num <- tab[["Df"]][1]
df_den <- tab[["Df"]][2]
p_val  <- tab[["Pr(>F)"]][1]
n_obs  <- nrow(df)

result <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = list(
    list(term = "F",       estimate = as.numeric(F_stat), se = NULL, n_obs = as.integer(n_obs)),
    list(term = "df_num",  estimate = as.numeric(df_num), se = NULL, n_obs = as.integer(n_obs)),
    list(term = "df_den",  estimate = as.numeric(df_den), se = NULL, n_obs = as.integer(n_obs)),
    list(term = "p_value", estimate = as.numeric(p_val),  se = NULL, n_obs = as.integer(n_obs))
  ),
  method_metadata = list(
    estimator = "one-way ANOVA (aov, type I sums of squares)",
    vcov = "classical"
  ),
  diagnostics = setNames(list(), character(0))
)

write(toJSON(result, auto_unbox = TRUE, digits = NA, null = "null", pretty = TRUE),
      file = "result.json")
