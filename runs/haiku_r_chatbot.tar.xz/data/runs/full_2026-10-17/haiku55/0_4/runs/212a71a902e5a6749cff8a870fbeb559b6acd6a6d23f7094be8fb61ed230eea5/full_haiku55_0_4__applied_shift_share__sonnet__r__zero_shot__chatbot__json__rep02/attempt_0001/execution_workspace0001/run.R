wiv_fit <- function(y, X, Z, w) {
  A <- solve(crossprod(Z, w * X))
  b <- as.vector(A %*% crossprod(Z, w * y))
  u <- as.vector(y - X %*% b)
  list(b = b, A = A, u = u, w = w, Z = Z)
}

vcov_hc1 <- function(f) {
  n <- length(f$u)
  meat <- crossprod(f$Z * (f$w * f$u))
  f$A %*% meat %*% t(f$A) * n / (n - 2)
}

df <- read.csv("input.csv", stringsAsFactors = FALSE)

reg_ids <- unique(df$region_id)
first_idx <- match(reg_ids, df$region_id)
rw <- df$region_weight[first_idx]

R <- data.frame(
  region_id = reg_ids,
  e = rw / sum(rw),
  x = df$x[first_idx],
  y = df$y[first_idx]
)
zsum <- tapply(df$share * df$shock, df$region_id, sum)
R$z <- as.numeric(zsum[as.character(R$region_id)])

cen <- function(v, w) v - sum(w * v)
R$y0 <- cen(R$y, R$e)
R$x0 <- cen(R$x, R$e)
R$z0 <- cen(R$z, R$e)

reg_iv <- wiv_fit(R$y0, cbind(1, R$x0), cbind(1, R$z0), R$e)
effect_est <- reg_iv$b[2]

reg_fs_est <- sum(R$e * R$x0 * R$z0) / sum(R$e * R$z0^2)

mi <- match(df$region_id, R$region_id)
er <- R$e[mi]
y0row <- R$y0[mi]
x0row <- R$x0[mi]
z0row <- R$z0[mi]

ids <- unique(df$industry_id)
s_n <- as.numeric(tapply(er * df$share, df$industry_id, sum)[as.character(ids)])

agg <- function(v) {
  as.numeric(tapply(er * df$share * v, df$industry_id, sum)[as.character(ids)]) / s_n
}

ybar <- agg(y0row)
xbar <- agg(x0row)
zbar <- agg(z0row)
shock_n <- as.numeric(df$shock[match(ids, df$industry_id)])

ind_iv <- wiv_fit(ybar, cbind(1, xbar), cbind(1, shock_n), s_n)
effect_se <- sqrt(vcov_hc1(ind_iv)[2, 2])

fs_iv <- wiv_fit(xbar, cbind(1, zbar), cbind(1, shock_n), s_n)
fs_se <- sqrt(vcov_hc1(fs_iv)[2, 2])

eff_shocks <- 1 / sum(s_n^2)

n_ind <- length(ids)
n_reg <- nrow(R)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = as.numeric(effect_est), se = as.numeric(effect_se), n_obs = as.integer(n_ind)),
    list(term = "first_stage", estimate = as.numeric(reg_fs_est), se = as.numeric(fs_se), n_obs = as.integer(n_ind)),
    list(term = "effective_shocks", estimate = as.numeric(eff_shocks), se = NULL, n_obs = as.integer(n_ind))
  ),
  method_metadata = list(
    estimator = "Weighted 2SLS (regional, e_r weights) with shift-share instrument; BHJ shock-level weighted IV for inference",
    vcov = "Shock-level heteroskedasticity-robust HC1 (N/(N-2)), structural residuals, analytic weights s_n, no clustering"
  ),
  diagnostics = list(
    n_regions = as.integer(n_reg),
    n_industries = as.integer(n_ind),
    shock_level_effect_slope = as.numeric(ind_iv$b[2]),
    first_stage_t_hc1 = as.numeric(reg_fs_est / fs_se)
  )
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = NA, na = "null", pretty = TRUE)
