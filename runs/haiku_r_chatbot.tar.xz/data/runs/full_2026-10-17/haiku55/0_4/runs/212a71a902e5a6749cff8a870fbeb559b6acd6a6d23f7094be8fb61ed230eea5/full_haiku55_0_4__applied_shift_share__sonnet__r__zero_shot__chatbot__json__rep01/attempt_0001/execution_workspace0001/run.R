df <- read.csv("input.csv", stringsAsFactors = FALSE)

reg <- df[!duplicated(df$region_id), c("region_id", "region_weight", "x", "y")]
df$sz <- df$share * df$shock
z_tab <- aggregate(sz ~ region_id, data = df, FUN = sum)
reg$z <- z_tab$sz[match(reg$region_id, z_tab$region_id)]

e <- reg$region_weight / sum(reg$region_weight)
wmean <- function(v) sum(e * v) / sum(e)
x0 <- reg$x - wmean(reg$x)
y0 <- reg$y - wmean(reg$y)
z0 <- reg$z - wmean(reg$z)

effect_reg <- sum(e * z0 * y0) / sum(e * z0 * x0)
first_stage_reg <- sum(e * z0 * x0) / sum(e * z0^2)

rowidx <- match(df$region_id, reg$region_id)
e_row <- e[rowidx]
y0_row <- y0[rowidx]
x0_row <- x0[rowidx]
z0_row <- z0[rowidx]

ind_f <- factor(df$industry_id)
s <- as.numeric(tapply(e_row * df$share, ind_f, sum))
agg <- function(v) as.numeric(tapply(e_row * df$share * v, ind_f, sum)) / s
ybar <- agg(y0_row)
xbar <- agg(x0_row)
zbar <- agg(z0_row)
shock <- as.numeric(tapply(df$shock, ind_f, function(v) v[1]))
N <- length(ybar)

iv_hc1 <- function(y, X, Z, w) {
  A <- t(Z) %*% (w * X)
  Ainv <- solve(A)
  beta <- Ainv %*% (t(Z) %*% (w * y))
  u <- as.numeric(y - X %*% beta)
  G <- Z * (w * u)
  M <- t(G) %*% G
  V <- Ainv %*% M %*% t(Ainv) * N / (N - 2)
  list(beta = as.numeric(beta), se = sqrt(diag(V)))
}

Z_mat <- cbind(1, shock)
eff <- iv_hc1(ybar, cbind(1, xbar), Z_mat, s)
fs <- iv_hc1(xbar, cbind(1, zbar), Z_mat, s)

effective_shocks <- 1 / sum(s^2)

fmt <- function(v) sprintf("%.15g", v)

out <- sprintf(
  paste0(
    '{"task_id":"applied_shift_share","platform":"r",',
    '"estimates":[',
    '{"term":"effect","estimate":%s,"se":%s,"n_obs":%d},',
    '{"term":"first_stage","estimate":%s,"se":%s,"n_obs":%d},',
    '{"term":"effective_shocks","estimate":%s,"se":null,"n_obs":%d}],',
    '"method_metadata":{"estimator":"regional weighted 2SLS shift-share; shock-level weighted IV for inference",',
    '"vcov":"shock-level HC1 robust, N/(N-2) multiplier, analytic weights s_n, structural IV residuals, no clustering"},',
    '"diagnostics":{}}'
  ),
  fmt(effect_reg), fmt(eff$se[2]), N,
  fmt(first_stage_reg), fmt(fs$se[2]), N,
  fmt(effective_shocks), N
)

writeLines(out, "result.json")
