suppressPackageStartupMessages(library(jsonlite))

crosswalk <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
trade <- read.csv("trade.csv", stringsAsFactors = FALSE)
areas <- read.csv("areas.csv", stringsAsFactors = FALSE)
employment <- read.csv("employment.csv", stringsAsFactors = FALSE)
outcomes <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

trade <- merge(trade, crosswalk, by = "code")
tp <- unique(trade[, c("period", "industry", "us_change", "other_change")])
per <- unique(trade[, c("period", "price_index", "years")])
per$scale <- (10 / per$years) / (per$price_index / 100) / 1000

ap <- unique(areas[, c("area", "period")])
inds <- sort(unique(crosswalk$industry))
grid <- merge(ap, data.frame(industry = inds, stringsAsFactors = FALSE), by = NULL)

emp_sum <- function(v) {
  s <- aggregate(employment ~ area + period + industry,
                 data = employment[employment$vintage == v, ], FUN = sum)
  names(s)[4] <- v
  s
}
cells <- merge(grid, emp_sum("base"), by = c("area", "period", "industry"), all.x = TRUE)
cells <- merge(cells, emp_sum("early"), by = c("area", "period", "industry"), all.x = TRUE)
cells$base[is.na(cells$base)] <- 0
cells$early[is.na(cells$early)] <- 0

tot_base <- areas[areas$vintage == "base", c("area", "period", "total_employment", "population")]
names(tot_base)[3] <- "base_total"
tot_early <- areas[areas$vintage == "early", c("area", "period", "total_employment")]
names(tot_early)[3] <- "early_total"
tots <- merge(tot_base, tot_early, by = c("area", "period"))

cells <- merge(cells, tots[, c("area", "period", "base_total", "early_total")], by = c("area", "period"))
cells <- merge(cells, tp, by = c("period", "industry"))

nat_base <- aggregate(base ~ period + industry, data = cells, FUN = sum)
names(nat_base)[3] <- "nat_base"
nat_early <- aggregate(early ~ period + industry, data = cells, FUN = sum)
names(nat_early)[3] <- "nat_early"
cells <- merge(cells, nat_base, by = c("period", "industry"))
cells <- merge(cells, nat_early, by = c("period", "industry"))

cells$tx <- cells$base / cells$base_total * cells$us_change / cells$nat_base
cells$tz <- cells$early / cells$early_total * cells$other_change / cells$nat_early

ex <- aggregate(cbind(tx, tz) ~ area + period, data = cells, FUN = sum)
ex <- merge(ex, per[, c("period", "scale")], by = "period")
ex$x <- ex$tx * ex$scale
ex$z <- ex$tz * ex$scale

d <- merge(outcomes, ex[, c("area", "period", "x", "z")], by = c("area", "period"))
d <- merge(d, tot_base[, c("area", "period", "population")], by = c("area", "period"))
n_obs <- as.integer(nrow(d))

y <- d$change_pp
w <- d$population
X <- cbind(1, d$period, d$control, d$x)
Z <- cbind(1, d$period, d$control, d$z)
sw <- sqrt(w)
Xw <- X * sw
Zw <- Z * sw
yw <- y * sw
Xhat <- Zw %*% solve(crossprod(Zw), crossprod(Zw, Xw))
beta <- drop(solve(crossprod(Xhat), crossprod(Xhat, yw)))

iv_slope <- beta[4]
exposure_area0_period0 <- ex$x[ex$area == 0 & ex$period == 0]
exposure_area0_period1 <- ex$x[ex$area == 0 & ex$period == 1]
instrument_area0_period0 <- ex$z[ex$area == 0 & ex$period == 0]

estimates <- list(
  list(term = "iv_slope", estimate = iv_slope, se = NA, n_obs = n_obs),
  list(term = "exposure_area0_period0", estimate = exposure_area0_period0, se = NA, n_obs = n_obs),
  list(term = "exposure_area0_period1", estimate = exposure_area0_period1, se = NA, n_obs = n_obs),
  list(term = "instrument_area0_period0", estimate = instrument_area0_period0, se = NA, n_obs = n_obs)
)

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    method = "weighted 2SLS",
    weight = "base-vintage population",
    endogenous = "x",
    instruments = c("intercept", "period", "control", "z"),
    n_obs = n_obs
  ),
  diagnostics = list(
    n_obs = n_obs,
    n_industries = as.integer(length(inds)),
    periods = sort(unique(d$period))
  )
)

write_json(result, "result.json", auto_unbox = TRUE, pretty = TRUE, digits = NA, na = "null")
