library(jsonlite)

crosswalk <- read.csv("crosswalk.csv", stringsAsFactors = FALSE, strip.white = TRUE)
trade <- read.csv("trade.csv", stringsAsFactors = FALSE, strip.white = TRUE)
areas <- read.csv("areas.csv", stringsAsFactors = FALSE, strip.white = TRUE)
employment <- read.csv("employment.csv", stringsAsFactors = FALSE, strip.white = TRUE)
outcomes <- read.csv("outcomes.csv", stringsAsFactors = FALSE, strip.white = TRUE)

crosswalk$code <- as.character(crosswalk$code)
crosswalk$industry <- as.character(crosswalk$industry)
trade$code <- as.character(trade$code)
trade$period <- as.character(trade$period)
areas$area <- as.character(areas$area)
areas$period <- as.character(areas$period)
areas$vintage <- as.character(areas$vintage)
employment$area <- as.character(employment$area)
employment$period <- as.character(employment$period)
employment$vintage <- as.character(employment$vintage)
employment$industry <- as.character(employment$industry)
outcomes$area <- as.character(outcomes$area)
outcomes$period <- as.character(outcomes$period)

trade_ind <- merge(trade, crosswalk, by = "code")
trade_ind <- trade_ind[, c("period", "industry", "us_change", "other_change", "price_index", "years")]

emp_sum <- aggregate(employment ~ area + period + vintage + industry, data = employment, FUN = sum)
nat <- aggregate(employment ~ period + industry + vintage, data = emp_sum, FUN = sum)

base_areas <- areas[areas$vintage == "base", c("area", "period", "total_employment", "population")]
names(base_areas)[names(base_areas) == "total_employment"] <- "tot_base"
early_areas <- areas[areas$vintage == "early", c("area", "period", "total_employment")]
names(early_areas)[3] <- "tot_early"

ap <- merge(outcomes[, c("area", "period", "control", "change_pp")], base_areas, by = c("area", "period"))
ap <- merge(ap, early_areas, by = c("area", "period"))

grid <- merge(ap[, c("area", "period", "tot_base", "tot_early")], trade_ind, by = "period")

emp_wide <- function(v, nm) {
  e <- emp_sum[emp_sum$vintage == v, c("area", "period", "industry", "employment")]
  names(e)[4] <- nm
  e
}
grid <- merge(grid, emp_wide("base", "emp_base"), by = c("area", "period", "industry"), all.x = TRUE)
grid <- merge(grid, emp_wide("early", "emp_early"), by = c("area", "period", "industry"), all.x = TRUE)
grid$emp_base[is.na(grid$emp_base)] <- 0
grid$emp_early[is.na(grid$emp_early)] <- 0

nat_wide <- function(v, nm) {
  n <- nat[nat$vintage == v, c("period", "industry", "employment")]
  names(n)[3] <- nm
  n
}
grid <- merge(grid, nat_wide("base", "nat_base"), by = c("period", "industry"), all.x = TRUE)
grid <- merge(grid, nat_wide("early", "nat_early"), by = c("period", "industry"), all.x = TRUE)

deflate <- grid$price_index / 100
decade <- 10 / grid$years
grid$term_x <- (grid$emp_base / grid$tot_base) * (grid$us_change / grid$nat_base) / deflate / 1000 * decade
grid$term_z <- (grid$emp_early / grid$tot_early) * (grid$other_change / grid$nat_early) / deflate / 1000 * decade

key_grid <- paste(grid$area, grid$period, sep = "|")
x_sum <- tapply(grid$term_x, key_grid, sum)
z_sum <- tapply(grid$term_z, key_grid, sum)
key_ap <- paste(ap$area, ap$period, sep = "|")
ap$x <- as.numeric(x_sum[key_ap])
ap$z <- as.numeric(z_sum[key_ap])
ap$period_num <- as.numeric(ap$period)
ap$control_num <- as.numeric(ap$control)

y <- as.numeric(ap$change_pp)
w <- as.numeric(ap$population)
X <- cbind(1, ap$period_num, ap$control_num, ap$x)
Z <- cbind(1, ap$period_num, ap$control_num, ap$z)

ZWZ <- crossprod(Z, w * Z)
ZWX <- crossprod(Z, w * X)
ZWy <- crossprod(Z, w * y)
XWZ <- crossprod(X, w * Z)
ZWZi <- solve(ZWZ)
beta <- solve(XWZ %*% ZWZi %*% ZWX, XWZ %*% ZWZi %*% ZWy)
iv_slope <- as.numeric(beta[4, 1])

is_a0 <- ap$area == "0"
exposure_area0_period0 <- ap$x[is_a0 & ap$period_num == 0]
exposure_area0_period1 <- ap$x[is_a0 & ap$period_num == 1]
instrument_area0_period0 <- ap$z[is_a0 & ap$period_num == 0]
n_obs <- as.integer(nrow(ap))

mk <- function(term, est) list(term = term, estimate = as.numeric(est), se = NA_real_, n_obs = n_obs)

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = list(
    mk("iv_slope", iv_slope),
    mk("exposure_area0_period0", exposure_area0_period0),
    mk("exposure_area0_period1", exposure_area0_period1),
    mk("instrument_area0_period0", instrument_area0_period0)
  ),
  method_metadata = list(
    estimator = "weighted 2SLS",
    weight = "base-vintage population",
    outcome = "change_pp",
    endogenous = "x",
    instrument = "z",
    exogenous = c("intercept", "period", "control"),
    se_reported = FALSE
  ),
  diagnostics = list(
    n_obs = n_obs,
    n_industries = as.integer(length(unique(trade_ind$industry))),
    n_periods = as.integer(length(unique(ap$period))),
    n_areas = as.integer(length(unique(ap$area)))
  )
)

write_json(result, "result.json", auto_unbox = TRUE, digits = NA, na = "null", pretty = TRUE)
