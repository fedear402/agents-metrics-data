crosswalk <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
trade <- read.csv("trade.csv", stringsAsFactors = FALSE)
areas <- read.csv("areas.csv", stringsAsFactors = FALSE)
employment <- read.csv("employment.csv", stringsAsFactors = FALSE)
outcomes <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

iv <- function(y, C, x, z, w = rep(1, length(y))) {
  X <- cbind(C, x) * sqrt(w)
  Z <- cbind(C, z) * sqrt(w)
  fitted <- qr.fitted(qr(Z), X)
  as.numeric(qr.coef(qr(fitted), y * sqrt(w)))[ncol(X)]
}

inds <- sort(unique(crosswalk$industry))

tr <- merge(trade, crosswalk, by = "code")
tr <- tr[c("period", "industry", "us_change", "other_change", "price_index", "years")]

cells <- merge(areas[c("area", "period", "vintage")],
               data.frame(industry = inds, stringsAsFactors = FALSE), by = NULL)
cells <- merge(cells,
               employment[c("area", "period", "vintage", "industry", "employment")],
               by = c("area", "period", "vintage", "industry"), all.x = TRUE)
cells$employment[is.na(cells$employment)] <- 0

nat <- aggregate(employment ~ period + vintage + industry, data = cells, FUN = sum)
names(nat)[names(nat) == "employment"] <- "nat_emp"

cells <- merge(cells, nat, by = c("period", "vintage", "industry"))
cells <- merge(cells, tr, by = c("period", "industry"))
cells <- merge(cells, areas[c("area", "period", "vintage", "total_employment")],
               by = c("area", "period", "vintage"))

cells$change <- ifelse(cells$vintage == "base", cells$us_change, cells$other_change)
cells$term <- cells$employment / cells$total_employment * cells$change /
  cells$nat_emp / (cells$price_index / 100) / 1000 * (10 / cells$years)

expo <- aggregate(term ~ area + period + vintage, data = cells, FUN = sum)

xb <- expo[expo$vintage == "base", c("area", "period", "term")]
names(xb)[3] <- "x"
ze <- expo[expo$vintage == "early", c("area", "period", "term")]
names(ze)[3] <- "z"
pop <- areas[areas$vintage == "base", c("area", "period", "population")]

dd <- merge(outcomes, xb, by = c("area", "period"))
dd <- merge(dd, ze, by = c("area", "period"))
dd <- merge(dd, pop, by = c("area", "period"))

n <- as.integer(nrow(dd))

C <- cbind(1, as.numeric(dd$period), dd$control)
est <- iv(dd$change_pp, C, dd$x, dd$z, dd$population)

pick <- function(col, p) {
  dd[[col]][as.character(dd$area) == "0" & as.character(dd$period) == p]
}

x_a0_p0 <- unname(pick("x", "0"))
x_a0_p1 <- unname(pick("x", "1"))
z_a0_p0 <- unname(pick("z", "0"))

res <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = list(
    list(term = "iv_slope", estimate = unname(est), se = NULL, n_obs = n),
    list(term = "exposure_area0_period0", estimate = x_a0_p0, se = NULL, n_obs = n),
    list(term = "exposure_area0_period1", estimate = x_a0_p1, se = NULL, n_obs = n),
    list(term = "instrument_area0_period0", estimate = z_a0_p0, se = NULL, n_obs = n)
  ),
  method_metadata = list(
    estimator = "weighted 2SLS",
    outcome = "change_pp",
    endogenous = "x",
    instruments = "z",
    exogenous = c("intercept", "period", "control"),
    weight = "base-vintage population"
  ),
  diagnostics = list(
    n_area_periods = n,
    n_industries = as.integer(length(inds))
  )
)

jsonlite::write_json(res, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE)
