df <- read.csv("input.csv")
y <- as.integer(df$y)
x <- as.numeric(df$x)
z <- as.numeric(df$z)

X <- cbind(1, x, z)
n_full <- nrow(df)
p <- ncol(X)
K <- 2
D <- cbind(as.numeric(y == 1), as.numeric(y == 2))

idx <- function(k) ((k - 1) * p + 1):(k * p)

f <- function(theta) {
  B <- matrix(theta, p, K)
  E <- X %*% B
  M <- cbind(0, E)
  mx <- apply(M, 1, max)
  lse <- mx + log(rowSums(exp(M - mx)))
  P <- exp(M - lse)
  pk <- P[, 2:3, drop = FALSE]
  ll <- sum(D[, 1] * E[, 1] + D[, 2] * E[, 2] - lse)
  grad <- as.vector(t(X) %*% (D - pk))
  H <- matrix(0, p * K, p * K)
  for (k in 1:K) {
    for (l in 1:K) {
      w <- pk[, k] * ((k == l) - pk[, l])
      H[idx(k), idx(l)] <- -t(X) %*% (X * w)
    }
  }
  list(ll = ll, grad = grad, hess = H)
}

theta <- rep(0, p * K)
converged <- FALSE
iter <- 0
for (it in 1:100) {
  iter <- it
  r <- f(theta)
  step <- solve(r$hess, r$grad)
  theta <- theta - step
  if (max(abs(step)) < 1e-10) {
    converged <- TRUE
    break
  }
}

r <- f(theta)
V <- solve(-r$hess)
se <- sqrt(diag(V))
B <- matrix(theta, p, K)

x0 <- c(1, 0, 0)
e1 <- sum(x0 * B[, 1])
e2 <- sum(x0 * B[, 2])
prob_cat2_zero <- exp(e2) / (1 + exp(e1) + exp(e2))

fmt <- function(v) if (is.null(v) || is.na(v)) "null" else sprintf("%.15g", v)

est_line <- function(term, estimate, s) {
  sprintf('    {"term": "%s", "estimate": %s, "se": %s, "n_obs": %d}',
          term, fmt(estimate), fmt(s), as.integer(n_full))
}

lines <- c(
  est_line("x_cat1", theta[2], se[2]),
  est_line("z_cat1", theta[3], se[3]),
  est_line("x_cat2", theta[p + 2], se[p + 2]),
  est_line("z_cat2", theta[p + 3], se[p + 3]),
  est_line("prob_cat2_zero", prob_cat2_zero, NULL)
)

json <- paste0(
  "{\n",
  '  "task_id": "broad_multinomial_logit",\n',
  '  "platform": "r",\n',
  '  "estimates": [\n',
  paste(lines, collapse = ",\n"), "\n",
  "  ],\n",
  '  "method_metadata": {"estimator": "multinomial logit, maximum likelihood (Newton-Raphson), base outcome 0", ',
  '"vcov": "observed information (inverse of negative Hessian)"},\n',
  '  "diagnostics": {"loglik": ', fmt(r$ll),
  ', "converged": ', if (converged) "true" else "false",
  ', "iterations": ', iter,
  ', "n_obs_used": ', as.integer(n), '}\n',
  "}\n"
)

writeLines(json, "result.json")
