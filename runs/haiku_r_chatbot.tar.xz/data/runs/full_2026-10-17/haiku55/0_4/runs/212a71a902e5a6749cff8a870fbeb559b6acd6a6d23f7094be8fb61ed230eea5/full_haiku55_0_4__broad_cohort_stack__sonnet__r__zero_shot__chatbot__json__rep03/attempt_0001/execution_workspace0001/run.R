library(jsonlite)

df <- read.csv("input.csv", stringsAsFactors = FALSE)
cohorts <- c(3, 5, 7)

att <- numeric(length(cohorts))
n_treated <- integer(length(cohorts))
n_rows <- integer(length(cohorts))

for (k in seq_along(cohorts)) {
  c0 <- cohorts[k]
  win <- (c0 - 2):(c0 + 2)

  d <- df[df$time %in% win & (df$g == c0 | df$g == 0 | df$g > c0 + 2), ]

  n_times <- tapply(d$time, d$id, function(t) length(unique(t)))
  keep_ids <- names(n_times)[n_times == length(win)]
  d <- d[as.character(d$id) %in% keep_ids, ]

  d$did <- as.numeric(d$g == c0 & d$time >= c0)

  n_treated[k] <- length(unique(d$id[d$g == c0]))
  n_rows[k] <- nrow(d)

  fit <- lm(y ~ did + factor(id) + factor(time), data = d)
  att[k] <- unname(coef(fit)["did"])
}

att_weighted <- sum(n_treated * att) / sum(n_treated)

fmt <- function(x) sprintf("%.15g", x)

estimates <- list(
  list(term = "att_g3", estimate = fmt(att[1]), se = NULL, n_obs = n_rows[1]),
  list(term = "att_g5", estimate = fmt(att[2]), se = NULL, n_obs = n_rows[2]),
  list(term = "att_g7", estimate = fmt(att[3]), se = NULL, n_obs = n_rows[3]),
  list(term = "att_weighted", estimate = fmt(att_weighted), se = NULL, n_obs = sum(n_rows))
)

result <- list(
  task_id = "broad_cohort_stack",
  platform = "r",
  estimates = estimates,
  method_metadata = structure(list(), names = character(0)),
  diagnostics = structure(list(), names = character(0))
)

write_json(result, "result.json", auto_unbox = TRUE, pretty = TRUE)
