crosswalk <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
trade <- read.csv("trade.csv", stringsAsFactors = FALSE)
areas <- read.csv("areas.csv", stringsAsFactors = FALSE)
employment <- read.csv("employment.csv", stringsAsFactors = FALSE)
outcomes <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

iv <- function(y, C, x, z, w = rep(1, length(y))) {
  X <- cbind(C, x) * sqrt(w)
  Z <- cbind(C, z) * sqrt(w)
  fitted <- qr.fitted(qr(Z), X)
  as.numeric(qr.coef(qr(fitted), y * sqrt(w)))[ncol(X)]
}

trade <- merge(trade, crosswalk, by = "code")
industries <- sort(unique(crosswalk$industry))
periods <- sort(unique(areas$period))
area_ids <- sort(unique(areas$area))

emp_sum <- aggregate(employment ~ area + period + vintage + industry,
                     data = employment, FUN = sum)
grid <- expand.grid(area = area_ids, period = periods,
                    vintage = c("base", "early"), industry = industries,
                    stringsAsFactors = FALSE)
grid <- merge(grid, emp_sum, by = c("area", "period", "vintage", "industry"), all.x = TRUE)
grid$employment[is.na(grid$employment)] <- 0

nat <- aggregate(employment ~ period + vintage + industry, data = grid, FUN = sum)
names(nat)[names(nat) == "employment"] <- "nat"

exposure <- function(v, chg_col) {
  g <- grid[grid$vintage == v, ]
  nat_v <- nat[nat$vintage == v, c("period", "industry", "nat")]
  g <- merge(g, nat_v, by = c("period", "industry"))
  tr <- trade[, c("period", "industry", chg_col, "price_index", "years")]
  g <- merge(g, tr, by = c("period", "industry"))
  tot <- areas[areas$vintage == v, c("area", "period", "total_employment")]
  g <- merge(g, tot, by = c("area", "period"))
  g$term <- (g$employment / g$total_employment) * (g[[chg_col]] / g$nat) /
    (g$price_index / 100) / 1000 * (10 / g$years)
  aggregate(term ~ area + period, data = g, FUN = sum)
}

xb <- exposure("base", "us_change")
names(xb)[names(xb) == "term"] <- "x"
ze <- exposure("early", "other_change")
names(ze)[names(ze) == "term"] <- "z"

ap <- areas[areas$vintage == "base", c("area", "period", "population")]
oc <- outcomes[, c("area", "period", "control", "change_pp")]
d <- merge(ap, oc, by = c("area", "period"))
d <- merge(d, xb, by = c("area", "period"))
d <- merge(d, ze, by = c("area", "period"))
d <- d[order(d$area, d$period), ]

n <- as.integer(nrow(d))
C <- cbind(1, d$period, d$control)
beta <- iv(d$change_pp, C, d$x, d$z, d$population)

x0p0 <- d$x[d$area == 0 & d$period == 0]
x0p1 <- d$x[d$area == 0 & d$period == 1]
z0p0 <- d$z[d$area == 0 & d$period == 0]

estimates <- list(
  list(term = "iv_slope", estimate = beta, se = NA_real_, n_obs = n),
  list(term = "exposure_area0_period0", estimate = x0p0, se = NA_real_, n_obs = n),
  list(term = "exposure_area0_period1", estimate = x0p1, se = NA_real_, n_obs = n),
  list(term = "instrument_area0_period0", estimate = z0p0, se = NA_real_, n_obs = n)
)

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "weighted_2sls",
    dependent = "change_pp",
    endogenous = "x",
    instrument = "z",
    exogenous = c("intercept", "period", "control"),
    weight = "base_vintage_population",
    exposure_units = "thousands of real dollars per worker per decade",
    outcome_units = "percentage points per decade"
  ),
  diagnostics = list(
    n_obs = n,
    n_areas = as.integer(length(unique(d$area))),
    n_periods = as.integer(length(unique(d$period))),
    n_industries = as.integer(length(industries))
  )
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = 15,
                     na = "null", pretty = TRUE)
