library(jsonlite)

d <- read.csv("input.csv", stringsAsFactors = FALSE)

reg <- d[!duplicated(d$region_id), c("region_id", "region_weight", "x", "y")]
reg <- reg[order(reg$region_id), ]
reg$e <- reg$region_weight / sum(reg$region_weight)

z_reg <- aggregate(share * shock ~ region_id, data = d, FUN = sum)
names(z_reg)[2] <- "z"
reg <- merge(reg, z_reg, by = "region_id")
reg <- reg[order(reg$region_id), ]

wmean <- function(v, w) sum(w * v) / sum(w)
reg$y0 <- reg$y - wmean(reg$y, reg$e)
reg$x0 <- reg$x - wmean(reg$x, reg$e)
reg$z0 <- reg$z - wmean(reg$z, reg$e)

dd <- merge(d, reg[, c("region_id", "e", "y0", "x0", "z0")], by = "region_id")

ind <- aggregate(cbind(
  s = e * share,
  yw = e * share * y0,
  xw = e * share * x0,
  zw = e * share * z0
) ~ industry_id, data = dd, FUN = sum)

shock_by_ind <- aggregate(shock ~ industry_id, data = d, FUN = function(v) v[1])
ind <- merge(ind, shock_by_ind, by = "industry_id")
ind <- ind[order(ind$industry_id), ]

ybar <- ind$yw / ind$s
xbar <- ind$xw / ind$s
zbar <- ind$zw / ind$s
sh <- ind$shock
w <- ind$s
N <- nrow(ind)

shock_iv <- function(dep, endog, inst_shock, wts) {
  X <- cbind(1, endog)
  Z <- cbind(1, inst_shock)
  ZW <- crossprod(Z, wts * X)
  beta <- solve(crossprod(Z, wts * X), crossprod(Z, wts * dep))
  resid <- drop(dep - X %*% beta)
  scores <- Z * (wts * resid)
  Zinv <- solve(ZW)
  V <- N / (N - 2) * Zinv %*% crossprod(scores) %*% t(Zinv)
  c(slope = beta[2], se = sqrt(V[2, 2]))
}

eff <- shock_iv(ybar, xbar, sh, w)
fs <- shock_iv(xbar, zbar, sh, w)

eff_reg <- sum(reg$e * reg$z0 * reg$y0) / sum(reg$e * reg$z0 * reg$x0)
stopifnot(abs(eff["slope"] - eff_reg) < 1e-8)

effective_shocks <- 1 / sum(w^2)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = unname(as.numeric(eff["slope"])),
         se = unname(as.numeric(eff["se"])), n_obs = as.integer(N)),
    list(term = "first_stage", estimate = unname(as.numeric(fs["slope"])),
         se = unname(as.numeric(fs["se"])), n_obs = as.integer(N)),
    list(term = "effective_shocks", estimate = unname(as.numeric(effective_shocks)),
         se = NULL, n_obs = as.integer(N))
  ),
  method_metadata = list(
    estimator = "weighted 2SLS with shift-share instrument; BHJ shock-level weighted IV",
    vcov = "HC1 shock-level robust, N/(N-2) multiplier, structural residuals"
  ),
  diagnostics = setNames(list(), character(0))
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
