d <- read.csv("input.csv")
d$y <- factor(d$y, levels = 0:2)
fit <- nnet::multinom(y ~ x + z, data = d, Hess = TRUE, trace = FALSE,
                      maxit = 1000, reltol = 1e-12, abstol = 1e-12)
B <- coef(fit)
V <- vcov(fit)
cf <- function(row, term) unname(B[row, term])
se <- function(row, term) sqrt(V[paste0(row, ":", term), paste0(row, ":", term)])
b0 <- B[, "(Intercept)"]
xb <- c(0, b0)
p <- exp(xb - max(xb)) / sum(exp(xb - max(xb)))
stopifnot(abs(sum(p) - 1) < 1e-12)
n <- nrow(d)
res <- list(
  task_id = "broad_multinomial_logit",
  platform = "r",
  estimates = list(
    list(term = "x_cat1", estimate = cf("1", "x"), se = se("1", "x"), n_obs = as.integer(n)),
    list(term = "z_cat1", estimate = cf("1", "z"), se = se("1", "z"), n_obs = as.integer(n)),
    list(term = "x_cat2", estimate = cf("2", "x"), se = se("2", "x"), n_obs = as.integer(n)),
    list(term = "z_cat2", estimate = cf("2", "z"), se = se("2", "z"), n_obs = as.integer(n)),
    list(term = "prob_cat2_zero", estimate = unname(p[3]), se = NULL, n_obs = as.integer(n))
  ),
  method_metadata = list(
    estimator = "multinomial logit (nnet::multinom, maximum likelihood, base outcome 0)",
    vcov = "observed information (inverse Hessian)"
  ),
  diagnostics = setNames(list(), character(0))
)
jsonlite::write_json(res, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
