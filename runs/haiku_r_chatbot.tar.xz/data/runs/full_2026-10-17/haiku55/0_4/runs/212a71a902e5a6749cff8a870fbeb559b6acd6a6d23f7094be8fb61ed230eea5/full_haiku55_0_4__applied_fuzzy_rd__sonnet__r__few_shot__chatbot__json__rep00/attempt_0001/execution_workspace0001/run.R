library(jsonlite)

d <- read.csv("input.csv")
d <- d[abs(d$score) < 1, ]
w <- 1 - abs(d$score)
D <- as.numeric(d$score >= 0)
s <- d$score
X <- cbind(1, D, s, D * s)
n <- nrow(X)

B <- solve(crossprod(X, w * X))
Y <- cbind(d$earnings, d$participated)
coef <- B %*% crossprod(X, w * Y)
E <- Y - X %*% coef

loading <- w * drop(X %*% B %*% c(0, 1, 0, 0))
psi <- loading * E
V <- crossprod(psi)

rf <- coef[2, 1]
fs <- coef[2, 2]
se_rf <- sqrt(V[1, 1])
se_fs <- sqrt(V[2, 2])

te <- rf / fs
g <- c(1 / fs, -rf / fs^2)
se_te <- sqrt(drop(t(g) %*% V %*% g))

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = unname(as.numeric(te)),
         se = unname(as.numeric(se_te)), n_obs = as.integer(n)),
    list(term = "reduced_form", estimate = unname(as.numeric(rf)),
         se = unname(as.numeric(se_rf)), n_obs = as.integer(n)),
    list(term = "first_stage", estimate = unname(as.numeric(fs)),
         se = unname(as.numeric(se_fs)), n_obs = as.integer(n))
  ),
  method_metadata = list(
    estimator = "fuzzy RD, local linear with separate slopes, triangular weights, bandwidth 1, WLS",
    vcov = "HC0 heteroskedasticity-robust, delta method for ratio"
  ),
  diagnostics = list(
    bandwidth = 1,
    n_left = as.integer(sum(D == 0)),
    n_right = as.integer(sum(D == 1))
  )
)

write_json(result, "result.json", auto_unbox = TRUE, digits = 16, pretty = TRUE)
