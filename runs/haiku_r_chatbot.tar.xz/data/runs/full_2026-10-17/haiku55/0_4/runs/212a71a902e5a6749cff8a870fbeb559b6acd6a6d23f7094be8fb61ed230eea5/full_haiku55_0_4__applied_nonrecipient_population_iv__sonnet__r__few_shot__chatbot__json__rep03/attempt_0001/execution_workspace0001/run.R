households <- read.csv("households.csv")
census <- read.csv("census.csv")

d <- subset(households, recipient == 0)

iv2sls <- function(y, X, Z, w) {
  sw <- sqrt(w)
  Xw <- X * sw
  Zw <- Z * sw
  fitted <- qr.fitted(qr(Zw), Xw)
  as.numeric(qr.coef(qr(fitted), y * sw))
}

e <- d$eligible
ne <- 1 - e
w <- d$weight

exog <- cbind(ne, e, d$baseline * ne, d$baseline * e)
X <- cbind(exog, d$dose * ne, d$dose * e)
Z <- cbind(exog, d$instrument * ne, d$instrument * e)

b <- iv2sls(d$outcome, X, Z, w)
slope_ineligible <- b[5]
slope_eligible <- b[6]

n_ineligible <- sum(e == 0)
n_eligible <- sum(e == 1)
n_total <- nrow(d)

mean_dose_ineligible <- weighted.mean(d$dose[e == 0], w[e == 0])
mean_dose_eligible <- weighted.mean(d$dose[e == 1], w[e == 1])

ineligible_effect <- slope_ineligible * mean_dose_ineligible
eligible_nonrecipient_effect <- slope_eligible * mean_dose_eligible

group_effects <- c(ineligible_effect, eligible_nonrecipient_effect)
pop_weights <- census$nonrecipient_population[match(0:1, census$eligible)]
population_effect <- weighted.mean(group_effects, pop_weights)

out <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = list(
    list(term = "ineligible_effect", estimate = ineligible_effect, se = NULL, n_obs = as.integer(n_ineligible)),
    list(term = "eligible_nonrecipient_effect", estimate = eligible_nonrecipient_effect, se = NULL, n_obs = as.integer(n_eligible)),
    list(term = "population_effect", estimate = population_effect, se = NULL, n_obs = as.integer(n_total))
  ),
  method_metadata = list(
    estimator = "weighted two-stage least squares, pooled with group-interacted columns",
    endogenous = c("dose*(1-eligible)", "dose*eligible"),
    exogenous = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"),
    instruments = c("exogenous columns", "instrument*(1-eligible)", "instrument*eligible"),
    weights = "weight",
    effect_definition = "dose slope times household-weighted mean dose among retained observations in group",
    counterfactual_convention = "zero dose for every retained household (stated synthetic convention)",
    aggregation = "census nonrecipient_population weights across eligibility groups"
  ),
  diagnostics = list(
    n_retained = as.integer(n_total),
    n_ineligible = as.integer(n_ineligible),
    n_eligible = as.integer(n_eligible),
    rank_X = as.integer(qr(X * sqrt(w))$rank),
    rank_Z = as.integer(qr(Z * sqrt(w))$rank),
    slope_ineligible = slope_ineligible,
    slope_eligible = slope_eligible,
    mean_dose_ineligible = mean_dose_ineligible,
    mean_dose_eligible = mean_dose_eligible
  )
)

jsonlite::write_json(out, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE)
