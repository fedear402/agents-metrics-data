d <- read.csv("input.csv")

cohorts <- c(3, 5, 7)

res <- lapply(cohorts, function(cc) {
  w <- (cc - 2):(cc + 2)
  s <- d[d$time %in% w & (d$g == cc | d$g == 0 | d$g > cc + 2), ]
  n_times <- tapply(s$time, s$id, function(t) length(unique(t)))
  keep_ids <- names(n_times)[n_times == length(w)]
  s <- s[as.character(s$id) %in% keep_ids, ]
  s$did <- as.numeric(s$g == cc & s$time >= cc)
  fit <- lm(y ~ did + factor(id) + factor(time), data = s)
  list(
    att = unname(coef(fit)["did"]),
    n = as.integer(nrow(s)),
    ntr = as.integer(length(unique(s$id[s$g == cc])))
  )
})

att <- sapply(res, `[[`, "att")
n <- sapply(res, `[[`, "n")
ntr <- sapply(res, `[[`, "ntr")
att_weighted <- sum(att * ntr) / sum(ntr)

out <- list(
  task_id = "broad_cohort_stack",
  platform = "r",
  estimates = list(
    list(term = "att_g3", estimate = att[1], se = NULL, n_obs = n[1]),
    list(term = "att_g5", estimate = att[2], se = NULL, n_obs = n[2]),
    list(term = "att_g7", estimate = att[3], se = NULL, n_obs = n[3]),
    list(term = "att_weighted", estimate = att_weighted, se = NULL, n_obs = sum(n))
  ),
  method_metadata = setNames(list(), character(0)),
  diagnostics = setNames(list(), character(0))
)

jsonlite::write_json(out, "result.json", auto_unbox = TRUE, null = "null", digits = 16)
