library(jsonlite)

df <- read.csv("input.csv", stringsAsFactors = FALSE)
df$id <- as.numeric(df$id)
df$time <- as.integer(df$time)
df$g <- as.numeric(df$g)
df$y <- as.numeric(df$y)

cohorts <- c(3, 5, 7)

fits <- lapply(cohorts, function(cc) {
  wt <- (cc - 2):(cc + 2)
  d <- df[df$time %in% wt & (df$g == cc | df$g == 0 | df$g > cc + 2), ]
  n_times <- tapply(d$time, d$id, function(t) length(unique(t)))
  keep_ids <- as.numeric(names(n_times)[n_times == length(wt)])
  d <- d[d$id %in% keep_ids, ]
  d$did <- as.numeric(d$g == cc & d$time >= cc)
  d$id_f <- factor(d$id)
  d$time_f <- factor(d$time)
  fit <- lm(y ~ did + id_f + time_f, data = d)
  list(
    est = unname(coef(fit)["did"]),
    n_obs = nrow(d),
    n_treated = length(unique(d$id[d$g == cc]))
  )
})

att <- sapply(fits, `[[`, "est")
n_obs <- sapply(fits, `[[`, "n_obs")
w <- sapply(fits, `[[`, "n_treated")
att_weighted <- sum(w * att) / sum(w)

estimates <- list(
  list(term = "att_g3", estimate = sprintf("%.15g", att[1]), se = NA_real_, n_obs = as.integer(n_obs[1])),
  list(term = "att_g5", estimate = sprintf("%.15g", att[2]), se = NA_real_, n_obs = as.integer(n_obs[2])),
  list(term = "att_g7", estimate = sprintf("%.15g", att[3]), se = NA_real_, n_obs = as.integer(n_obs[3])),
  list(term = "att_weighted", estimate = sprintf("%.15g", att_weighted), se = NA_real_, n_obs = as.integer(sum(n_obs)))
)

out <- list(
  task_id = "broad_cohort_stack",
  platform = "r",
  estimates = estimates,
  method_metadata = setNames(list(), character(0)),
  diagnostics = setNames(list(), character(0))
)

write_json(out, "result.json", auto_unbox = TRUE, pretty = TRUE, null = "null", na = "null")
