suppressPackageStartupMessages({
  library(sandwich)
  library(jsonlite)
})

df <- read.csv("input.csv", stringsAsFactors = FALSE)
df$date <- as.Date(df$date)
df <- df[order(df$date), ]
df <- df[df$sales > 0 & df$vix > 0, ]
n <- nrow(df)

dvix <- c(NA, diff(log(df$vix)))
L <- 15
dat <- data.frame(y = log(df$sales))
for (k in 1:L) {
  dat[[paste0("lag", k)]] <- c(rep(NA, k), dvix[1:(n - k)])
}
dat <- dat[complete.cases(dat), ]
N <- nrow(dat)

lag_names <- paste0("lag", 1:L)
fml <- as.formula(paste("y ~", paste(lag_names, collapse = " + ")))
fit <- lm(fml, data = dat)

V <- NeweyWest(fit, lag = L, prewhite = FALSE, adjust = FALSE) * N / (N - (L + 1))
b <- coef(fit)

cvec <- as.numeric(names(b) %in% lag_names)
cum_est <- sum(b[lag_names])
cum_se <- sqrt(as.numeric(t(cvec) %*% V %*% cvec))

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(term = "cumulative_response", estimate = unname(cum_est), se = unname(cum_se), n_obs = N),
    list(term = "lag_1", estimate = unname(b["lag1"]), se = unname(sqrt(V["lag1", "lag1"])), n_obs = N),
    list(term = "lag_15", estimate = unname(b["lag15"]), se = unname(sqrt(V["lag15", "lag15"])), n_obs = N)
  ),
  method_metadata = list(
    estimator = "OLS regression of log(sales) on intercept and 15 lags of diff(log(vix))",
    vcov = "Newey-West HAC (Bartlett kernel, max lag 15) scaled by N/(N-16)"
  ),
  diagnostics = setNames(list(), character(0))
)

write_json(result, "result.json", auto_unbox = TRUE, pretty = TRUE, digits = NA)
