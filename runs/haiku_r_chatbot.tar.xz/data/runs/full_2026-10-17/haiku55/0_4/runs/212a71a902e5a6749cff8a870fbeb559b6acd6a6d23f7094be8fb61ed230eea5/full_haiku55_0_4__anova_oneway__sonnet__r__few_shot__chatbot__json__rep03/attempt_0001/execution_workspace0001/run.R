library(jsonlite)
dat <- read.csv("./input.csv", stringsAsFactors = FALSE)
dat$group <- factor(dat$group)
fit <- aov(y ~ group, data = dat)
tab <- summary(fit)[[1]]
F_stat <- unname(tab[["F value"]][1])
df_num <- unname(tab[["Df"]][1])
df_den <- unname(tab[["Df"]][2])
p_val <- unname(tab[["Pr(>F)"]][1])
out <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = list(
    list(term = "F", estimate = F_stat, se = NA, n_obs = nrow(dat)),
    list(term = "df_num", estimate = df_num, se = NA, n_obs = nrow(dat)),
    list(term = "df_den", estimate = df_den, se = NA, n_obs = nrow(dat)),
    list(term = "p_value", estimate = p_val, se = NA, n_obs = nrow(dat))
  ),
  method_metadata = list(estimator = "One-way ANOVA (aov)", vcov = "none"),
  diagnostics = structure(list(), names = character(0))
)
write_json(out, "result.json", auto_unbox = TRUE, digits = NA)
