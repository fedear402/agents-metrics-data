df <- read.csv("input.csv")
keep <- abs(df$score) < 1
d <- df[keep, , drop = FALSE]
w <- 1 - abs(d$score)
isR <- d$score >= 0
iR <- which(isR)
iL <- which(!isR)

side <- function(idx) {
  X <- cbind(1, d$score[idx])
  W <- w[idx]
  B <- solve(crossprod(X, X * W))
  list(X = X, W = W, g = as.vector(X %*% B[, 1]), B = B, idx = idx)
}

fitside <- function(s, y) {
  yy <- y[s$idx]
  beta <- s$B %*% crossprod(s$X, s$W * yy)
  e <- yy - as.vector(s$X %*% beta)
  list(b0 = as.numeric(beta[1]), h = s$W * e * s$g)
}

sR <- side(iR)
sL <- side(iL)

y <- as.numeric(d$earnings)
dd <- as.numeric(d$participated)

yR <- fitside(sR, y)
yL <- fitside(sL, y)
dR <- fitside(sR, dd)
dL <- fitside(sL, dd)

rf <- yR$b0 - yL$b0
fs <- dR$b0 - dL$b0

vRF <- sum(yR$h^2) + sum(yL$h^2)
vFS <- sum(dR$h^2) + sum(dL$h^2)
cRF <- sum(yR$h * dR$h) + sum(yL$h * dL$h)

tau <- rf / fs
vTau <- vRF / fs^2 + rf^2 * vFS / fs^4 - 2 * rf * cRF / fs^3

n_obs <- nrow(d)

fmt <- function(x) sprintf("%.15g", x)

json <- sprintf(
'{
  "task_id": "applied_fuzzy_rd",
  "platform": "r",
  "estimates": [
    {"term": "treatment_effect", "estimate": %s, "se": %s, "n_obs": %d},
    {"term": "reduced_form", "estimate": %s, "se": %s, "n_obs": %d},
    {"term": "first_stage", "estimate": %s, "se": %s, "n_obs": %d}
  ],
  "method_metadata": {"estimator": "fuzzy RD local linear, triangular kernel, bandwidth 1, separate slopes and intercepts, ratio of discontinuities (delta method)", "vcov": "HC0 sandwich, no df correction, joint covariance across outcomes with delta method"},
  "diagnostics": {}
}
',
fmt(tau), fmt(sqrt(vTau)), n_obs,
fmt(rf), fmt(sqrt(vRF)), n_obs,
fmt(fs), fmt(sqrt(vFS)), n_obs
)

writeLines(json, "result.json")
