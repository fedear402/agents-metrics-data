households <- read.csv("households.csv")
census <- read.csv("census.csv")

d <- subset(households, recipient == 0)
n_obs <- as.integer(nrow(d))

e <- d$eligible
w <- d$weight
sw <- sqrt(w)

endog <- cbind(d$dose * (1 - e), d$dose * e)
exog <- cbind(1 - e, e, d$baseline * (1 - e), d$baseline * e)
instr <- cbind(exog, d$instrument * (1 - e), d$instrument * e)
regressors <- cbind(endog, exog)

Rw <- regressors * sw
Zw <- instr * sw
yw <- d$outcome * sw

Pz <- qr.fitted(qr(Zw), Rw)
beta <- as.numeric(qr.coef(qr(Pz), yw))

m0 <- weighted.mean(d$dose[e == 0], w[e == 0])
m1 <- weighted.mean(d$dose[e == 1], w[e == 1])

eff0 <- beta[1] * m0
eff1 <- beta[2] * m1

N <- census$nonrecipient_population[match(0:1, census$eligible)]
pop_effect <- weighted.mean(c(eff0, eff1), N)

estimates <- list(
  list(term = "ineligible_effect", estimate = eff0, se = NA_real_, n_obs = n_obs),
  list(term = "eligible_nonrecipient_effect", estimate = eff1, se = NA_real_, n_obs = n_obs),
  list(term = "population_effect", estimate = pop_effect, se = NA_real_, n_obs = n_obs)
)

method_metadata <- list(
  method = "weighted two-stage least squares, joint fit over all retained nonrecipient rows",
  regression_weight = "weight",
  endogenous = c("dose*(1-eligible)", "dose*eligible"),
  exogenous = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"),
  instruments = c("exogenous terms", "instrument*(1-eligible)", "instrument*eligible"),
  intercept = "none beyond group indicators",
  group_effect = "dose slope times household-weighted mean dose within eligibility group",
  population_weights = "nonrecipient_population from census.csv",
  counterfactual = "dose set to zero for every retained household (synthetic convention)"
)

diagnostics <- list(
  n_rows = n_obs,
  n_regressors = ncol(regressors),
  n_instruments = ncol(instr),
  instrument_rank = qr(Zw)$rank,
  group_weighted_mean_dose = c(ineligible = m0, eligible = m1),
  dose_slopes = c(ineligible = beta[1], eligible = beta[2])
)

jsonlite::write_json(
  list(
    task_id = "applied_nonrecipient_population_iv",
    platform = "r",
    estimates = estimates,
    method_metadata = method_metadata,
    diagnostics = diagnostics
  ),
  "result.json",
  auto_unbox = TRUE,
  digits = NA,
  na = "null",
  pretty = TRUE
)
