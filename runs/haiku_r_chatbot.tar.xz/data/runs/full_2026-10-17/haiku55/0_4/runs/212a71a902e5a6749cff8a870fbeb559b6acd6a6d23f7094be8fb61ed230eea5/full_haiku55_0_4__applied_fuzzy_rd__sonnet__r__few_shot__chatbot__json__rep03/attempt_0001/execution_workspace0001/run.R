library(jsonlite)

d <- read.csv("input.csv")
d <- d[abs(d$score) < 1, ]
s <- d$score
w <- 1 - abs(s)
R <- as.numeric(s >= 0)
L <- 1 - R
X <- cbind(R, L, R * s, L * s)
cvec <- c(1, -1, 0, 0)

XtW <- t(X * w)
bread <- solve(XtW %*% X)
lever <- drop(X %*% bread %*% cvec)
a <- w * lever

fit_outcome <- function(y) {
  b <- bread %*% (XtW %*% y)
  e <- y - X %*% b
  list(est = drop(t(cvec) %*% b), infl = a * e)
}

rf_fit <- fit_outcome(d$earnings)
fs_fit <- fit_outcome(d$participated)

rf <- rf_fit$est
fs <- fs_fit$est
psi <- cbind(rf_fit$infl, fs_fit$infl)
V <- crossprod(psi)

rf_se <- sqrt(V[1, 1])
fs_se <- sqrt(V[2, 2])

te <- rf / fs
g <- c(1 / fs, -rf / fs^2)
te_se <- sqrt(drop(t(g) %*% V %*% g))

n_obs <- nrow(d)

out <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = as.numeric(te), se = as.numeric(te_se), n_obs = as.integer(n_obs)),
    list(term = "reduced_form", estimate = as.numeric(rf), se = as.numeric(rf_se), n_obs = as.integer(n_obs)),
    list(term = "first_stage", estimate = as.numeric(fs), se = as.numeric(fs_se), n_obs = as.integer(n_obs))
  ),
  method_metadata = list(
    estimator = "fuzzy RD, triangular kernel weights 1-|score|, bandwidth 1, local linear WLS with separate slopes on each side",
    vcov = "HC0 sandwich, delta method for ratio using joint covariance of reduced form and first stage"
  ),
  diagnostics = list(
    bandwidth = 1,
    cutoff = 0,
    n_left = as.integer(sum(L == 1)),
    n_right = as.integer(sum(R == 1))
  )
)

write_json(out, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE)
