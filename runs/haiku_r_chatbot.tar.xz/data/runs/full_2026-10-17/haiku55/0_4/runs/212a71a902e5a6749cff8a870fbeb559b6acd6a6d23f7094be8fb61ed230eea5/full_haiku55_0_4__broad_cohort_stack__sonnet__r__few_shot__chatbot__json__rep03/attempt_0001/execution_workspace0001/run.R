d <- read.csv("input.csv")
cohorts <- c(3, 5, 7)

res <- lapply(cohorts, function(cc) {
  w <- d[d$time >= cc - 2 & d$time <= cc + 2 & (d$g == cc | d$g == 0 | d$g > cc + 2), ]
  full_ids <- names(which(table(w$id) == 5))
  w <- w[as.character(w$id) %in% full_ids, ]
  w$did <- as.numeric(w$g == cc & w$time >= cc)
  fit <- lm(y ~ did + factor(id) + factor(time), data = w)
  list(
    estimate = unname(coef(fit)["did"]),
    n_obs = nrow(w),
    n_treated = length(unique(w$id[w$g == cc]))
  )
})

est <- vapply(res, `[[`, numeric(1), "estimate")
n_obs <- vapply(res, `[[`, numeric(1), "n_obs")
n_treated <- vapply(res, `[[`, numeric(1), "n_treated")

att_weighted <- sum(n_treated * est) / sum(n_treated)

out <- list(
  task_id = "broad_cohort_stack",
  platform = "r",
  estimates = list(
    list(term = "att_g3", estimate = est[1], se = NULL, n_obs = as.integer(n_obs[1])),
    list(term = "att_g5", estimate = est[2], se = NULL, n_obs = as.integer(n_obs[2])),
    list(term = "att_g7", estimate = est[3], se = NULL, n_obs = as.integer(n_obs[3])),
    list(term = "att_weighted", estimate = att_weighted, se = NULL, n_obs = as.integer(sum(n_obs)))
  ),
  method_metadata = structure(list(), names = character(0)),
  diagnostics = structure(list(), names = character(0))
)

jsonlite::write_json(out, "result.json", auto_unbox = TRUE, null = "null", digits = 16)
