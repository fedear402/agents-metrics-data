library(jsonlite)

df <- read.csv("input.csv")
n <- nrow(df)
y <- df$y
e <- df$endog
X_r <- cbind(1, df$x)
X_u <- cbind(1, df$x, df$z1, df$z2)
q <- qf(0.95, 2, n - 4)

F_fun <- function(b) {
  y0 <- y - b * e
  rss_r <- sum(qr.resid(qr(X_r), y0)^2)
  rss_u <- sum(qr.resid(qr(X_u), y0)^2)
  ((rss_r - rss_u) / 2) / (rss_u / (n - 4))
}

ry <- qr.resid(qr(X_r), y)
re <- qr.resid(qr(X_r), e)
uy <- qr.resid(qr(X_u), y)
ue <- qr.resid(qr(X_u), e)

a0 <- sum(ry^2); a1 <- sum(ry * re); a2 <- sum(re^2)
u0 <- sum(uy^2); u1 <- sum(uy * ue); u2 <- sum(ue^2)

k <- 1 + 2 * q / (n - 4)
A <- a2 - k * u2
B <- -2 * (a1 - k * u1)
C <- a0 - k * u0
disc <- B^2 - 4 * A * C

if (A != 0) {
  roots <- c((-B - sqrt(disc)) / (2 * A), (-B + sqrt(disc)) / (2 * A))
} else {
  roots <- c(-C / B, -C / B)
}
roots <- sort(roots)

unbounded <- as.integer(A < 0 || (A == 0 && (B != 0 || C <= 0)))
accepts_zero <- as.integer(F_fun(0) <= q)
ar_f_at_one <- F_fun(1)

out <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = list(
    list(term = "boundary_low", estimate = roots[1], se = NA_real_, n_obs = as.integer(n)),
    list(term = "boundary_high", estimate = roots[2], se = NA_real_, n_obs = as.integer(n)),
    list(term = "accepts_zero", estimate = accepts_zero, se = NA_real_, n_obs = as.integer(n)),
    list(term = "unbounded", estimate = unbounded, se = NA_real_, n_obs = as.integer(n)),
    list(term = "ar_f_at_one", estimate = ar_f_at_one, se = NA_real_, n_obs = as.integer(n))
  ),
  method_metadata = list(
    estimator = "Anderson-Rubin confidence set via inversion of homoskedastic joint F test on excluded instruments z1, z2",
    vcov = "homoskedastic"
  ),
  diagnostics = list(
    f_critical = q,
    quadratic_A = A,
    quadratic_B = B,
    quadratic_C = C,
    discriminant = disc,
    df_numerator = 2,
    df_denominator = n - 4
  )
)

write_json(out, "result.json", auto_unbox = TRUE, pretty = TRUE, digits = NA, na = "null")
