df <- read.csv("input.csv", stringsAsFactors = FALSE)
wm <- function(v, w) sum(w * v) / sum(w)

regd <- df[!duplicated(df$region_id), c("region_id", "region_weight", "x", "y")]
regd$e <- regd$region_weight / sum(regd$region_weight)
df$sz <- df$share * df$shock
zr <- tapply(df$sz, df$region_id, sum)
regd$z <- as.numeric(zr[as.character(regd$region_id)])
regd$y0 <- regd$y - wm(regd$y, regd$e)
regd$x0 <- regd$x - wm(regd$x, regd$e)
regd$z0 <- regd$z - wm(regd$z, regd$e)

beta_reg <- sum(regd$e * regd$z0 * regd$y0) / sum(regd$e * regd$z0 * regd$x0)
pi_reg <- sum(regd$e * regd$z0 * regd$x0) / sum(regd$e * regd$z0^2)

m <- match(df$region_id, regd$region_id)
df$w <- regd$e[m] * df$share
df$y0 <- regd$y0[m]
df$x0 <- regd$x0[m]
df$z0 <- regd$z0[m]

s <- as.numeric(tapply(df$w, df$industry_id, sum))
ybar <- as.numeric(tapply(df$w * df$y0, df$industry_id, sum)) / s
xbar <- as.numeric(tapply(df$w * df$x0, df$industry_id, sum)) / s
zbar <- as.numeric(tapply(df$w * df$z0, df$industry_id, sum)) / s
sh <- as.numeric(tapply(df$shock, df$industry_id, function(v) v[1]))

N <- length(s)
mult <- N / (N - 2)

stil <- sh - wm(sh, s)
ytil <- ybar - wm(ybar, s)
xtil <- xbar - wm(xbar, s)
ztil <- zbar - wm(zbar, s)

b <- sum(s * stil * ytil) / sum(s * stil * xtil)
a <- wm(ybar, s) - b * wm(xbar, s)
u <- ybar - a - b * xbar
V_eff <- mult * sum((s * stil * u)^2) / sum(s * stil * xtil)^2
se_eff <- sqrt(V_eff)

c1 <- sum(s * stil * xtil) / sum(s * stil * ztil)
a1 <- wm(xbar, s) - c1 * wm(zbar, s)
v <- xbar - a1 - c1 * zbar
V_fs <- mult * sum((s * stil * v)^2) / sum(s * stil * ztil)^2
se_fs <- sqrt(V_fs)

eff_shocks <- 1 / sum(s^2)

out <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = b, se = se_eff, n_obs = as.integer(N)),
    list(term = "first_stage", estimate = c1, se = se_fs, n_obs = as.integer(N)),
    list(term = "effective_shocks", estimate = eff_shocks, se = NULL, n_obs = as.integer(N))
  ),
  method_metadata = list(
    estimator = "Weighted 2SLS shift-share; BHJ shock-level weighted IV with analytic weights s_n",
    vcov = "BHJ shock-level HC1 with multiplier N/(N-2), structural IV residuals, no clustering"
  ),
  diagnostics = list(
    regional_effect_check = beta_reg,
    regional_first_stage_check = pi_reg,
    n_regions = nrow(regd),
    n_industries = N
  )
)

jsonlite::write_json(out, "result.json", auto_unbox = TRUE, digits = 15, pretty = TRUE, null = "null")
