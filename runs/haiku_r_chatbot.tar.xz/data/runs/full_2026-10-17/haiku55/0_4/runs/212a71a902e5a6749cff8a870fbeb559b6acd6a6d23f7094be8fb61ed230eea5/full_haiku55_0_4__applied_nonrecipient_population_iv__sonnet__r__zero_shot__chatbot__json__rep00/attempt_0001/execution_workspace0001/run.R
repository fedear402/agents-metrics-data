suppressPackageStartupMessages(library(jsonlite))

hh <- read.csv("households.csv", stringsAsFactors = FALSE)
census <- read.csv("census.csv", stringsAsFactors = FALSE)

num <- function(x) as.numeric(x)

d <- hh[num(hh$recipient) == 0, , drop = FALSE]

e <- num(d$eligible)
ne <- 1 - e
dose <- num(d$dose)
base <- num(d$baseline)
inst <- num(d$instrument)
y <- num(d$outcome)
w <- num(d$weight)

X <- cbind(dose * ne, dose * e, ne, e, base * ne, base * e)
Z <- cbind(ne, e, base * ne, base * e, inst * ne, inst * e)

ZWZ <- t(Z) %*% (Z * w)
ZWX <- t(Z) %*% (X * w)
ZWy <- t(Z) %*% (y * w)
ZWZinv <- solve(ZWZ)

A <- t(ZWX) %*% ZWZinv %*% ZWX
b <- t(ZWX) %*% ZWZinv %*% ZWy
beta <- as.numeric(solve(A, b))

slope_ineligible <- beta[1]
slope_eligible <- beta[2]

wmean_dose_ineligible <- sum(w * dose * ne) / sum(w * ne)
wmean_dose_eligible <- sum(w * dose * e) / sum(w * e)

ineligible_effect <- slope_ineligible * wmean_dose_ineligible
eligible_nonrecipient_effect <- slope_eligible * wmean_dose_eligible

pop0 <- sum(num(census$nonrecipient_population[num(census$eligible) == 0]))
pop1 <- sum(num(census$nonrecipient_population[num(census$eligible) == 1]))

population_effect <- (pop0 * ineligible_effect + pop1 * eligible_nonrecipient_effect) / (pop0 + pop1)

n_obs <- as.integer(nrow(d))

result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = list(
    list(term = "ineligible_effect", estimate = ineligible_effect, se = NA_real_, n_obs = n_obs),
    list(term = "eligible_nonrecipient_effect", estimate = eligible_nonrecipient_effect, se = NA_real_, n_obs = n_obs),
    list(term = "population_effect", estimate = population_effect, se = NA_real_, n_obs = n_obs)
  ),
  method_metadata = list(
    method = "weighted 2SLS",
    sample = "households with recipient == 0, both village treatment statuses",
    endogenous = c("dose*(1-eligible)", "dose*eligible"),
    exogenous = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"),
    excluded_instruments = c("instrument*(1-eligible)", "instrument*eligible"),
    intercept = "none added; eligibility indicators span the intercept",
    regression_weight = "weight",
    group_effect = "fitted dose slope times weighted mean dose among retained group observations",
    counterfactual = "dose set to zero for every retained household",
    aggregation_weights = "census nonrecipient_population by eligibility group",
    attribution_convention = "stated synthetic convention"
  ),
  diagnostics = list(
    n_nonrecipient_total = n_obs,
    n_ineligible = as.integer(sum(ne)),
    n_eligible = as.integer(sum(e)),
    slope_ineligible = slope_ineligible,
    slope_eligible = slope_eligible,
    weighted_mean_dose_ineligible = wmean_dose_ineligible,
    weighted_mean_dose_eligible = wmean_dose_eligible,
    census_population_ineligible = pop0,
    census_population_eligible = pop1
  )
)

write_json(result, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE, na = "null")
