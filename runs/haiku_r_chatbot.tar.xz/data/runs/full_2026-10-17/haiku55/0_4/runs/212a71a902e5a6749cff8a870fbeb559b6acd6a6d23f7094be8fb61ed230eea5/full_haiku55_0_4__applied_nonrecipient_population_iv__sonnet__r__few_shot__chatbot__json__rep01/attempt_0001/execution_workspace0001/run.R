households <- read.csv("households.csv")
census <- read.csv("census.csv")

d <- subset(households, recipient == 0)
e <- d$eligible
w <- d$weight
sw <- sqrt(w)

C <- cbind(1 - e, e, d$baseline * (1 - e), d$baseline * e)
X_end <- cbind(d$dose * (1 - e), d$dose * e)
Z <- cbind(C, d$instrument * (1 - e), d$instrument * e)

Xf <- cbind(X_end, C) * sw
Zf <- Z * sw
yf <- d$outcome * sw

fitted <- qr.fitted(qr(Zf), Xf)
b <- as.numeric(qr.coef(qr(fitted), yf))
slopes <- b[1:2]

group_effect <- function(g) {
  idx <- e == g
  slopes[g + 1] * weighted.mean(d$dose[idx], w[idx])
}

eff0 <- group_effect(0)
eff1 <- group_effect(1)

pop_weights <- census$nonrecipient_population[match(0:1, census$eligible)]
population_effect <- weighted.mean(c(eff0, eff1), pop_weights)

n_obs <- as.integer(nrow(d))

estimates <- list(
  list(term = "ineligible_effect", estimate = eff0, se = NULL, n_obs = n_obs),
  list(term = "eligible_nonrecipient_effect", estimate = eff1, se = NULL, n_obs = n_obs),
  list(term = "population_effect", estimate = population_effect, se = NULL, n_obs = n_obs)
)

result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    method = "weighted 2SLS, pooled over nonrecipient households",
    endogenous = c("dose*(1-eligible)", "dose*eligible"),
    exogenous = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"),
    instruments = c("instrument*(1-eligible)", "instrument*eligible"),
    counterfactual = "dose set to zero for every retained household (synthetic attribution convention)",
    aggregation_weights = "nonrecipient_population from census.csv"
  ),
  diagnostics = list(
    n_obs = n_obs,
    n_columns_instruments = as.integer(ncol(Zf)),
    instrument_matrix_rank = as.integer(qr(Zf)$rank),
    regressor_matrix_columns = as.integer(ncol(Xf))
  )
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE)
