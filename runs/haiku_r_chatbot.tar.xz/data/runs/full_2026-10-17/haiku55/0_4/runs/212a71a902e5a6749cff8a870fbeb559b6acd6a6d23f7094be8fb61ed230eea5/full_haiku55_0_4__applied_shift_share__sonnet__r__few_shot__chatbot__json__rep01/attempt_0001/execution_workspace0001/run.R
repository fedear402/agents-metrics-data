library(jsonlite)

df <- read.csv("input.csv", stringsAsFactors = FALSE)
regs <- sort(unique(df$region_id))
inds <- sort(unique(df$industry_id))
R <- length(regs)
N <- length(inds)

ri <- match(df$region_id, regs)
ni <- match(df$industry_id, inds)
S <- matrix(0, R, N)
S[cbind(ri, ni)] <- df$share

first <- function(v) v[1]
rw <- as.numeric(tapply(df$region_weight, df$region_id, first)[regs])
xr <- as.numeric(tapply(df$x, df$region_id, first)[regs])
yr <- as.numeric(tapply(df$y, df$region_id, first)[regs])
shock <- as.numeric(tapply(df$shock, df$industry_id, first)[inds])

e <- rw / sum(rw)
zr <- drop(S %*% shock)

center <- function(v) v - sum(e * v)
y0 <- center(yr)
x0 <- center(xr)
z0 <- center(zr)

s <- drop(crossprod(S, e))
agg <- function(v0) drop(crossprod(S, e * v0)) / s
ybar <- agg(y0)
xbar <- agg(x0)
zbar <- agg(z0)

shock_iv <- function(dep, endo, instr_vals) {
  X <- cbind(1, endo)
  Z <- cbind(1, instr_vals)
  cross <- crossprod(Z, s * X)
  beta <- solve(cross, crossprod(Z, s * dep))
  u <- drop(dep - X %*% beta)
  scores <- Z * (s * u)
  inv <- solve(cross)
  n <- length(dep)
  V <- n / (n - 2) * inv %*% crossprod(scores) %*% t(inv)
  c(slope = as.numeric(beta[2]), se = as.numeric(sqrt(V[2, 2])))
}

effect <- shock_iv(ybar, xbar, shock)
fs_se <- shock_iv(xbar, zbar, shock)[["se"]]
first_stage <- sum(e * z0 * x0) / sum(e * z0^2)
effective_shocks <- 1 / sum(s^2)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = effect[["slope"]], se = effect[["se"]], n_obs = N),
    list(term = "first_stage", estimate = first_stage, se = fs_se, n_obs = N),
    list(term = "effective_shocks", estimate = effective_shocks, se = NULL, n_obs = N)
  ),
  method_metadata = list(
    estimator = "weighted 2SLS with shock-level (BHJ) aggregation",
    vcov = "shock-level HC1 robust, N/(N-2) multiplier, structural residuals"
  ),
  diagnostics = list(n_regions = R, n_industries = N)
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
