library(jsonlite)

d <- read.csv("input.csv", stringsAsFactors = FALSE)
d$date <- as.Date(d$date)
d <- d[order(d$date), ]

d$dlvix <- c(NA, diff(log(d$vix)))
L <- 15
for (k in 1:L) {
  d[[paste0("lag_", k)]] <- c(rep(NA, k), head(d$dlvix, -k))
}
d$log_sales <- log(d$sales)

regcols <- c("log_sales", paste0("lag_", 1:L))
s <- d[complete.cases(d[, regcols]), regcols]

fit <- lm(log_sales ~ ., data = s)
X <- model.matrix(fit)
b <- coef(fit)
e <- residuals(fit)
N <- nrow(X)
p <- ncol(X)

scores <- X * e
meat <- crossprod(scores)
for (j in 1:L) {
  w <- 1 - j / (L + 1)
  gam <- crossprod(scores[(j + 1):N, , drop = FALSE], scores[1:(N - j), , drop = FALSE])
  meat <- meat + w * (gam + t(gam))
}
bread <- solve(crossprod(X))
V <- N / (N - p) * bread %*% meat %*% bread

contrast <- c(0, rep(1, L))
cum_est <- sum(contrast * b)
cum_se <- sqrt(drop(t(contrast) %*% V %*% contrast))

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(term = "cumulative_response", estimate = as.numeric(cum_est),
         se = as.numeric(cum_se), n_obs = as.integer(N)),
    list(term = "lag_1", estimate = as.numeric(b[2]),
         se = as.numeric(sqrt(V[2, 2])), n_obs = as.integer(N)),
    list(term = "lag_15", estimate = as.numeric(b[1 + L]),
         se = as.numeric(sqrt(V[1 + L, 1 + L])), n_obs = as.integer(N))
  ),
  method_metadata = list(
    estimator = "OLS regression of log(sales) on intercept and 15 lags of first difference of log(vix)",
    vcov = "Newey-West HAC, Bartlett weights 1-j/16, max lag 15, scaled by N/(N-16)"
  ),
  diagnostics = list(
    N = as.integer(N),
    parameters = as.integer(p),
    hac_max_lag = as.integer(L)
  )
)

write_json(result, "result.json", auto_unbox = TRUE, digits = 16, pretty = TRUE, null = "null")
