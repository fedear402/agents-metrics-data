library(jsonlite)

df <- read.csv("input.csv", stringsAsFactors = FALSE)

reg <- df[!duplicated(df$region_id), c("region_id", "region_weight", "x", "y")]
z_by_region <- tapply(df$share * df$shock, df$region_id, sum)
reg$z <- as.numeric(z_by_region[as.character(reg$region_id)])
reg$e <- reg$region_weight / sum(reg$region_weight)

center <- function(v, w) v - sum(w * v)
reg$y0 <- center(reg$y, reg$e)
reg$x0 <- center(reg$x, reg$e)
reg$z0 <- center(reg$z, reg$e)

idx <- match(df$region_id, reg$region_id)
df$e <- reg$e[idx]
df$y0 <- reg$y0[idx]
df$x0 <- reg$x0[idx]
df$z0 <- reg$z0[idx]

ind_levels <- sort(unique(df$industry_id))
ind_key <- as.character(ind_levels)
s <- as.numeric(tapply(df$e * df$share, df$industry_id, sum)[ind_key])
shock_n <- as.numeric(tapply(df$shock, df$industry_id, function(v) v[1])[ind_key])

agg <- function(v) as.numeric(tapply(df$e * df$share * v, df$industry_id, sum)[ind_key]) / s
ybar <- agg(df$y0)
xbar <- agg(df$x0)
zbar <- agg(df$z0)

shock_iv <- function(dep, endog, w, instr_shock) {
  Z <- cbind(1, instr_shock)
  X <- cbind(1, endog)
  cross <- crossprod(Z, w * X)
  beta <- solve(cross, crossprod(Z, w * dep))
  resid <- drop(dep - X %*% beta)
  scores <- Z * (w * resid)
  inv <- solve(cross)
  N <- length(dep)
  V <- N / (N - 2) * inv %*% crossprod(scores) %*% t(inv)
  list(slope = as.numeric(beta[2]), se = as.numeric(sqrt(V[2, 2])), n = N)
}

effect <- shock_iv(ybar, xbar, s, shock_n)
fs_shock <- shock_iv(xbar, zbar, s, shock_n)

first_stage_est <- sum(reg$e * reg$z0 * reg$x0) / sum(reg$e * reg$z0^2)
eff_shocks <- 1 / sum(s^2)

N_ind <- length(s)

estimates <- list(
  list(term = "effect", estimate = effect$slope, se = effect$se, n_obs = as.integer(N_ind)),
  list(term = "first_stage", estimate = first_stage_est, se = fs_shock$se, n_obs = as.integer(N_ind)),
  list(term = "effective_shocks", estimate = eff_shocks, se = NULL, n_obs = as.integer(N_ind))
)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "Weighted 2SLS of y on x instrumented by shift-share z (region-level weights e_r), with Borusyak-Hull-Jaravel shock-level IV aggregation (weights s_n, instrument shock_n)",
    vcov = "Shock-level HC1 heteroskedasticity-robust SE with N/(N-2) multiplier, structural IV residuals, analytic weights, no clustering"
  ),
  diagnostics = jsonlite::emptyNamedList
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
