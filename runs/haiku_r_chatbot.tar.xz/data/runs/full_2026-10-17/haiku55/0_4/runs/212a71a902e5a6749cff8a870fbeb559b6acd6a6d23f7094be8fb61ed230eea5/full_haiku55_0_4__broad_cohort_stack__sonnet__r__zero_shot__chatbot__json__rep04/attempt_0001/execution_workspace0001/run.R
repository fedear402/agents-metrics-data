df <- read.csv("input.csv", stringsAsFactors = FALSE)

cohorts <- c(3, 5, 7)

comp <- lapply(cohorts, function(cc) {
  wt <- (cc - 2):(cc + 2)
  d <- df[df$time %in% wt & (df$g == cc | df$g == 0 | df$g > cc + 2), ]
  full <- tapply(d$time, as.character(d$id), function(t) all(wt %in% t))
  keep_ids <- names(full)[full]
  d <- d[as.character(d$id) %in% keep_ids, ]
  d$did <- as.integer(d$g == cc & d$time >= cc)
  fit <- lm(y ~ did + factor(id) + factor(time), data = d)
  list(
    att = unname(coef(fit)["did"]),
    n_obs = nrow(d),
    n_treated = length(unique(as.character(d$id[d$g == cc])))
  )
})

atts <- sapply(comp, `[[`, "att")
ws <- sapply(comp, `[[`, "n_treated")
ns <- sapply(comp, `[[`, "n_obs")

att_weighted <- sum(ws * atts) / sum(ws)

fmt <- function(x) sprintf("%.15g", x)

out <- list(
  task_id = "broad_cohort_stack",
  platform = "r",
  estimates = list(
    list(term = "att_g3", estimate = fmt(atts[1]), se = NULL, n_obs = as.integer(ns[1])),
    list(term = "att_g5", estimate = fmt(atts[2]), se = NULL, n_obs = as.integer(ns[2])),
    list(term = "att_g7", estimate = fmt(atts[3]), se = NULL, n_obs = as.integer(ns[3])),
    list(term = "att_weighted", estimate = fmt(att_weighted), se = NULL, n_obs = as.integer(sum(ns)))
  ),
  method_metadata = setNames(list(), character(0)),
  diagnostics = setNames(list(), character(0))
)

jsonlite::write_json(out, "result.json", auto_unbox = TRUE, pretty = TRUE)
