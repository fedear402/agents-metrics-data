d <- read.csv("input.csv")
d$id <- as.integer(d$id)
d$time <- as.integer(d$time)
d$g <- as.integer(d$g)
d$y <- as.numeric(d$y)

cohorts <- c(3, 5, 7)

res <- lapply(cohorts, function(cc) {
  w <- (cc - 2):(cc + 2)
  x <- d[d$time %in% w & (d$g == cc | d$g == 0 | d$g > cc + 2), ]
  n_times <- tapply(x$time, x$id, function(t) length(unique(t)))
  keep <- names(n_times)[n_times == length(w)]
  x <- x[as.character(x$id) %in% keep, ]
  x$did <- as.numeric(x$g == cc & x$time >= cc)
  fit <- lm(y ~ did + factor(id) + factor(time), data = x)
  list(
    att = unname(coef(fit)["did"]),
    n = nrow(x),
    n_treated = length(unique(x$id[x$g == cc]))
  )
})

atts <- sapply(res, `[[`, "att")
n_rows <- sapply(res, `[[`, "n")
weights <- sapply(res, `[[`, "n_treated")
att_weighted <- sum(weights * atts) / sum(weights)

out <- list(
  task_id = "broad_cohort_stack",
  platform = "r",
  estimates = list(
    list(term = "att_g3", estimate = atts[1], se = NULL, n_obs = n_rows[1]),
    list(term = "att_g5", estimate = atts[2], se = NULL, n_obs = n_rows[2]),
    list(term = "att_g7", estimate = atts[3], se = NULL, n_obs = n_rows[3]),
    list(term = "att_weighted", estimate = att_weighted, se = NULL, n_obs = sum(n_rows))
  ),
  method_metadata = setNames(list(), character(0)),
  diagnostics = setNames(list(), character(0))
)

jsonlite::write_json(out, "result.json", auto_unbox = TRUE, null = "null", digits = 16)
