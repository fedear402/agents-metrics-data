dat <- read.csv("input.csv")
n_obs <- nrow(dat)
dat <- dat[complete.cases(dat[, c("y", "x", "z")]), ]
y <- as.integer(dat$y)
X <- cbind(1, as.numeric(dat$x), as.numeric(dat$z))

nll <- function(theta) {
  b1 <- theta[1:3]
  b2 <- theta[4:6]
  e1 <- as.vector(X %*% b1)
  e2 <- as.vector(X %*% b2)
  m <- pmax(0, e1, e2)
  lse <- m + log(exp(-m) + exp(e1 - m) + exp(e2 - m))
  chosen <- ifelse(y == 1, e1, ifelse(y == 2, e2, 0))
  -sum(chosen - lse)
}

fit <- optim(rep(0, 6), nll, method = "BFGS", hessian = TRUE,
             control = list(maxit = 10000, reltol = 1e-14))
fit <- optim(fit$par, nll, method = "BFGS", hessian = TRUE,
             control = list(maxit = 10000, reltol = 1e-14))

b <- fit$par
V <- solve(fit$hessian)
se <- sqrt(diag(V))

D0 <- 1 + exp(b[1]) + exp(b[4])
p2_zero <- exp(b[4]) / D0

fmt <- function(v) if (is.null(v) || is.na(v)) "null" else sprintf("%.12g", v)

out <- paste0(
  '{"task_id":"broad_multinomial_logit",',
  '"platform":"r",',
  '"estimates":[',
  '{"term":"x_cat1","estimate":', fmt(b[2]), ',"se":', fmt(se[2]), ',"n_obs":', as.integer(n_obs), '},',
  '{"term":"z_cat1","estimate":', fmt(b[3]), ',"se":', fmt(se[3]), ',"n_obs":', as.integer(n_obs), '},',
  '{"term":"x_cat2","estimate":', fmt(b[5]), ',"se":', fmt(se[5]), ',"n_obs":', as.integer(n_obs), '},',
  '{"term":"z_cat2","estimate":', fmt(b[6]), ',"se":', fmt(se[6]), ',"n_obs":', as.integer(n_obs), '},',
  '{"term":"prob_cat2_zero","estimate":', fmt(p2_zero), ',"se":null,"n_obs":', as.integer(n_obs), '}',
  '],',
  '"method_metadata":{"estimator":"multinomial logit, maximum likelihood (base R optim BFGS, reference category 0)",',
  '"vcov":"observed information (inverse of numerical Hessian of negative log-likelihood)"},',
  '"diagnostics":{"converged":', tolower(as.character(fit$convergence == 0)),
  ',"log_likelihood":', fmt(-fit$value),
  ',"n_used":', as.integer(nrow(dat)), '}}'
)

writeLines(out, "result.json")
