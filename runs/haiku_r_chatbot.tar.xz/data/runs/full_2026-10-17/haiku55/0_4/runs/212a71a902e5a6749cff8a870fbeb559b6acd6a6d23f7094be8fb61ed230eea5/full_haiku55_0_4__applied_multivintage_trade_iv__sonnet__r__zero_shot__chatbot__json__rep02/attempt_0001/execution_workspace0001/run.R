library(jsonlite)

crosswalk <- read.csv("crosswalk.csv", stringsAsFactors = FALSE, strip.white = TRUE)
trade <- read.csv("trade.csv", stringsAsFactors = FALSE, strip.white = TRUE)
areas <- read.csv("areas.csv", stringsAsFactors = FALSE, strip.white = TRUE)
employment <- read.csv("employment.csv", stringsAsFactors = FALSE, strip.white = TRUE)
outcomes <- read.csv("outcomes.csv", stringsAsFactors = FALSE, strip.white = TRUE)

trade_ind <- merge(trade, crosswalk, by = "code")
industries <- sort(unique(crosswalk$industry))
periods <- sort(unique(areas$period))
area_ids <- sort(unique(areas$area))

grid <- expand.grid(area = area_ids, period = periods, vintage = c("base", "early"),
                    industry = industries, stringsAsFactors = FALSE)
emp <- merge(grid, employment[, c("area", "period", "vintage", "industry", "employment")],
             by = c("area", "period", "vintage", "industry"), all.x = TRUE)
emp$employment[is.na(emp$employment)] <- 0

nat <- aggregate(employment ~ period + vintage + industry, data = emp, FUN = sum)
names(nat)[names(nat) == "employment"] <- "nat_emp"

tot <- areas[, c("area", "period", "vintage", "total_employment")]
tr <- trade_ind[, c("period", "industry", "us_change", "other_change", "price_index", "years")]

exposure <- function(v, tcol) {
  e <- emp[emp$vintage == v, ]
  e <- merge(e, tot[tot$vintage == v, c("area", "period", "total_employment")], by = c("area", "period"))
  e <- merge(e, nat[nat$vintage == v, c("period", "industry", "nat_emp")], by = c("period", "industry"))
  e <- merge(e, tr[, c("period", "industry", tcol, "price_index", "years")], by = c("period", "industry"))
  e$term <- (e$employment / e$total_employment) * (e[[tcol]] / e$nat_emp) /
    (e$price_index / 100) / 1000 * (10 / e$years)
  out <- aggregate(term ~ area + period, data = e, FUN = sum)
  names(out)[3] <- "value"
  out
}

xdf <- exposure("base", "us_change")
zdf <- exposure("early", "other_change")
names(xdf)[3] <- "x"
names(zdf)[3] <- "z"

pop <- areas[areas$vintage == "base", c("area", "period", "population")]

d <- merge(outcomes[, c("area", "period", "control", "change_pp")], xdf, by = c("area", "period"))
d <- merge(d, zdf, by = c("area", "period"))
d <- merge(d, pop, by = c("area", "period"))
d <- d[order(d$area, d$period), ]

n_obs <- as.integer(nrow(d))
y <- d$change_pp
period <- as.numeric(d$period)
X <- cbind(1, period, d$control, d$x)
Z <- cbind(1, period, d$control, d$z)
w <- d$population

ZtWZ <- crossprod(Z, Z * w)
A <- crossprod(X, Z * w) %*% solve(ZtWZ)
beta <- solve(A %*% crossprod(Z, X * w), A %*% crossprod(Z, y * w))

iv_slope <- as.numeric(beta[4])
exposure_area0_period0 <- d$x[d$area == 0 & d$period == 0]
exposure_area0_period1 <- d$x[d$area == 0 & d$period == 1]
instrument_area0_period0 <- d$z[d$area == 0 & d$period == 0]

out <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = list(
    list(term = "iv_slope", estimate = iv_slope, se = NA, n_obs = n_obs),
    list(term = "exposure_area0_period0", estimate = as.numeric(exposure_area0_period0), se = NA, n_obs = n_obs),
    list(term = "exposure_area0_period1", estimate = as.numeric(exposure_area0_period1), se = NA, n_obs = n_obs),
    list(term = "instrument_area0_period0", estimate = as.numeric(instrument_area0_period0), se = NA, n_obs = n_obs)
  ),
  method_metadata = list(
    method = "weighted 2SLS",
    outcome = "change_pp",
    regressors = c("intercept", "period", "control", "x"),
    instruments = c("intercept", "period", "control", "z"),
    weight = "base-vintage population",
    exposure_units = "thousands of real dollars per worker per decade"
  ),
  diagnostics = list(
    n_obs = n_obs,
    n_areas = as.integer(length(unique(d$area))),
    n_periods = as.integer(length(unique(d$period))),
    n_industries = as.integer(length(industries))
  )
)

write_json(out, "result.json", auto_unbox = TRUE, digits = NA, na = "null", pretty = TRUE)
