library(jsonlite)

hh <- read.csv("households.csv", stringsAsFactors = FALSE)
census <- read.csv("census.csv", stringsAsFactors = FALSE)

d <- hh[hh$recipient == 0, , drop = FALSE]
n_obs <- as.integer(nrow(d))

e <- as.numeric(d$eligible)
ne <- 1 - e
w <- as.numeric(d$weight)
y <- as.numeric(d$outcome)
dose <- as.numeric(d$dose)
base <- as.numeric(d$baseline)
inst <- as.numeric(d$instrument)

X <- cbind(ne, e, base * ne, base * e, dose * ne, dose * e)
Z <- cbind(ne, e, base * ne, base * e, inst * ne, inst * e)
colnames(X) <- c("ne", "e", "base_ne", "base_e", "dose_ne", "dose_e")

XtWZ <- crossprod(X * w, Z)
ZtWZ_inv <- solve(crossprod(Z * w, Z))
M <- XtWZ %*% ZtWZ_inv %*% t(XtWZ)
r <- XtWZ %*% ZtWZ_inv %*% crossprod(Z, w * y)
beta <- as.numeric(solve(M, r))
names(beta) <- colnames(X)

idx0 <- e == 0
idx1 <- e == 1
mean_dose0 <- sum(w[idx0] * dose[idx0]) / sum(w[idx0])
mean_dose1 <- sum(w[idx1] * dose[idx1]) / sum(w[idx1])

ineligible_effect <- as.numeric(beta["dose_ne"] * mean_dose0)
eligible_nonrecipient_effect <- as.numeric(beta["dose_e"] * mean_dose1)

N0 <- sum(census$nonrecipient_population[census$eligible == 0])
N1 <- sum(census$nonrecipient_population[census$eligible == 1])
pop_w0 <- N0 / (N0 + N1)
pop_w1 <- N1 / (N0 + N1)
population_effect <- as.numeric(pop_w0 * ineligible_effect + pop_w1 * eligible_nonrecipient_effect)

terms <- c("ineligible_effect", "eligible_nonrecipient_effect", "population_effect")
values <- c(ineligible_effect, eligible_nonrecipient_effect, population_effect)

estimates <- lapply(seq_along(terms), function(i) {
  list(
    term = terms[i],
    estimate = values[i],
    se = NA_real_,
    n_obs = n_obs
  )
})

method_metadata <- list(
  method = "weighted two-stage least squares",
  implementation = "closed-form matrix 2SLS with analytic weights",
  regression_weight = "weight",
  intercept = "none; 1-eligible and eligible span the intercept",
  endogenous = c("dose*(1-eligible)", "dose*eligible"),
  exogenous = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"),
  instruments = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible",
                  "instrument*(1-eligible)", "instrument*eligible"),
  sample = "households with recipient == 0, both treated statuses retained",
  group_effect = "fitted dose slope times household-weighted mean dose within eligibility group",
  population_weights = "census nonrecipient_population by eligible group",
  counterfactual = "dose set to zero for every retained household",
  counterfactual_convention = "synthetic attribution convention",
  standard_errors = "not computed; se reported as null"
)

diagnostics <- list(
  n_obs = n_obs,
  n_ineligible = as.integer(sum(idx0)),
  n_eligible = as.integer(sum(idx1)),
  n_treated_retained = as.integer(sum(d$treated == 1)),
  n_untreated_retained = as.integer(sum(d$treated == 0)),
  moment_matrix_rank = as.integer(qr(M)$rank),
  mean_dose_ineligible = mean_dose0,
  mean_dose_eligible = mean_dose1,
  slope_dose_ineligible = unname(beta["dose_ne"]),
  slope_dose_eligible = unname(beta["dose_e"]),
  census_population_ineligible = N0,
  census_population_eligible = N1,
  population_weight_ineligible = pop_w0,
  population_weight_eligible = pop_w1
)

result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = method_metadata,
  diagnostics = diagnostics
)

write_json(result, "result.json", auto_unbox = TRUE, digits = NA, na = "null", pretty = TRUE)
