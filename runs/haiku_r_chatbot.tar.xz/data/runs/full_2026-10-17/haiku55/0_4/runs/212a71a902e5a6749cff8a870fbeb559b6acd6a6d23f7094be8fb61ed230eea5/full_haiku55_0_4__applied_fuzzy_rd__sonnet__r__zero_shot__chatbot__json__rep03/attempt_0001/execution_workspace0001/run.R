d <- read.csv("input.csv")
d <- d[abs(d$score) < 1, ]

s <- d$score
w <- 1 - abs(s)
D <- as.numeric(s >= 0)
y_r <- d$earnings
y_d <- d$participated
n <- nrow(d)

X <- cbind(1, D, s, D * s)
XtWX <- t(X) %*% (X * w)
B <- solve(XtWX)

b_y <- B %*% t(X) %*% (w * y_r)
b_d <- B %*% t(X) %*% (w * y_d)
e_y <- as.vector(y_r - X %*% b_y)
e_d <- as.vector(y_d - X %*% b_d)

U_y <- X * (w * e_y)
U_d <- X * (w * e_d)
M_yy <- t(U_y) %*% U_y
M_dd <- t(U_d) %*% U_d
M_yd <- t(U_y) %*% U_d

V_yy <- B %*% M_yy %*% B
V_dd <- B %*% M_dd %*% B
V_yd <- B %*% M_yd %*% B

rf <- as.numeric(b_y[2])
fs <- as.numeric(b_d[2])
v_rf <- as.numeric(V_yy[2, 2])
v_fs <- as.numeric(V_dd[2, 2])
c_rf_fs <- as.numeric(V_yd[2, 2])

te <- rf / fs
v_te <- v_rf / fs^2 + rf^2 * v_fs / fs^4 - 2 * rf * c_rf_fs / fs^3

f <- function(x) sprintf("%.15g", x)

json <- paste0(
  "{\n",
  "  \"task_id\": \"applied_fuzzy_rd\",\n",
  "  \"platform\": \"r\",\n",
  "  \"estimates\": [\n",
  "    {\"term\": \"treatment_effect\", \"estimate\": ", f(te),
  ", \"se\": ", f(sqrt(v_te)), ", \"n_obs\": ", as.integer(n), "},\n",
  "    {\"term\": \"reduced_form\", \"estimate\": ", f(rf),
  ", \"se\": ", f(sqrt(v_rf)), ", \"n_obs\": ", as.integer(n), "},\n",
  "    {\"term\": \"first_stage\", \"estimate\": ", f(fs),
  ", \"se\": ", f(sqrt(v_fs)), ", \"n_obs\": ", as.integer(n), "}\n",
  "  ],\n",
  "  \"method_metadata\": {\"estimator\": \"fuzzy RD local linear, triangular kernel, bandwidth 1, separate slopes by side, Wald ratio\", \"vcov\": \"HC0 sandwich, joint covariance, delta method for treatment_effect\"},\n",
  "  \"diagnostics\": {}\n",
  "}\n"
)

writeLines(json, "result.json")
