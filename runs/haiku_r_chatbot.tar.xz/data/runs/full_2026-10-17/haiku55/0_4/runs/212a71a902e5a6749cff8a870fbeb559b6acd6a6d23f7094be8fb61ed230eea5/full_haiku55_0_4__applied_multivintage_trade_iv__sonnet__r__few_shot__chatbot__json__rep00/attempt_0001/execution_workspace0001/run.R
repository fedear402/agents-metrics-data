library(jsonlite)

crosswalk <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
trade <- read.csv("trade.csv", stringsAsFactors = FALSE)
areas <- read.csv("areas.csv", stringsAsFactors = FALSE)
employment <- read.csv("employment.csv", stringsAsFactors = FALSE)
outcomes <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

iv <- function(y,C,x,z,w=rep(1,length(y))) {
  X <- cbind(C,x)*sqrt(w); Z <- cbind(C,z)*sqrt(w)
  fitted <- qr.fitted(qr(Z),X)
  as.numeric(qr.coef(qr(fitted),y*sqrt(w)))[ncol(X)]
}

trade <- merge(trade, crosswalk[, c("code", "industry")], by = "code")
industries <- sort(unique(crosswalk$industry))

av <- unique(areas[, c("area", "period", "vintage")])
grid <- merge(av, data.frame(industry = industries, stringsAsFactors = FALSE), by = NULL)
grid <- merge(grid,
              employment[, c("area", "period", "vintage", "industry", "employment")],
              by = c("area", "period", "vintage", "industry"), all.x = TRUE)
grid$employment[is.na(grid$employment)] <- 0
grid <- merge(grid, areas[, c("area", "period", "vintage", "total_employment")],
              by = c("area", "period", "vintage"))
grid <- merge(grid,
              trade[, c("period", "industry", "us_change", "other_change", "price_index", "years")],
              by = c("period", "industry"))

natl <- aggregate(employment ~ period + vintage + industry, data = grid, FUN = sum)
names(natl)[names(natl) == "employment"] <- "natl"
grid <- merge(grid, natl, by = c("period", "vintage", "industry"))

share_term <- function(emp, tot, dollars, nat, pi_idx, yrs) {
  emp / tot * dollars / nat / (pi_idx / 100) / 1000 * (10 / yrs)
}

b_rows <- grid[grid$vintage == "base", ]
b_rows$contrib <- share_term(b_rows$employment, b_rows$total_employment,
                             b_rows$us_change, b_rows$natl,
                             b_rows$price_index, b_rows$years)
x_df <- aggregate(contrib ~ area + period, data = b_rows, FUN = sum)
names(x_df)[names(x_df) == "contrib"] <- "x"

e_rows <- grid[grid$vintage == "early", ]
e_rows$contrib <- share_term(e_rows$employment, e_rows$total_employment,
                             e_rows$other_change, e_rows$natl,
                             e_rows$price_index, e_rows$years)
z_df <- aggregate(contrib ~ area + period, data = e_rows, FUN = sum)
names(z_df)[names(z_df) == "contrib"] <- "z"

pop <- areas[areas$vintage == "base", c("area", "period", "population")]

d <- merge(outcomes[, c("area", "period", "control", "change_pp")], x_df, by = c("area", "period"))
d <- merge(d, z_df, by = c("area", "period"))
d <- merge(d, pop, by = c("area", "period"))
d <- d[order(d$area, d$period), ]

n_obs <- nrow(d)
C <- cbind(1, d$period, d$control)
iv_slope <- iv(d$change_pp, C, d$x, d$z, d$population)

pick <- function(v, p) unname(v[d$area == 0 & d$period == p])
exposure_area0_period0 <- pick(d$x, 0)
exposure_area0_period1 <- pick(d$x, 1)
instrument_area0_period0 <- pick(d$z, 0)

estimates <- list(
  list(term = "iv_slope", estimate = unname(iv_slope), se = NULL, n_obs = as.integer(n_obs)),
  list(term = "exposure_area0_period0", estimate = exposure_area0_period0, se = NULL, n_obs = as.integer(n_obs)),
  list(term = "exposure_area0_period1", estimate = exposure_area0_period1, se = NULL, n_obs = as.integer(n_obs)),
  list(term = "instrument_area0_period0", estimate = instrument_area0_period0, se = NULL, n_obs = as.integer(n_obs))
)

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    method = "weighted_two_stage_least_squares",
    weight = "base_vintage_population",
    endogenous = "x",
    instrument = "z",
    exogenous = c("intercept", "period", "control"),
    exposure_units = "thousands of real dollars per worker per decade",
    outcome_units = "percentage points per decade"
  ),
  diagnostics = list(
    n_obs = as.integer(n_obs),
    n_areas = as.integer(length(unique(d$area))),
    n_periods = as.integer(length(unique(d$period))),
    n_industries = as.integer(length(industries))
  )
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = 15, null = "null", pretty = TRUE)
