d <- read.csv("input.csv")
d$y <- factor(d$y, levels = 0:2)
fit <- nnet::multinom(y ~ x + z, data = d, Hess = TRUE, trace = FALSE,
                      maxit = 1000, reltol = 1e-12, abstol = 1e-12)
B <- coef(fit)
V <- vcov(fit)
n <- as.integer(nrow(d))
idx <- c(0, B["1", "(Intercept)"], B["2", "(Intercept)"])
p2 <- exp(idx[3] - max(idx)) / sum(exp(idx - max(idx)))
res <- list(
  task_id = "broad_multinomial_logit",
  platform = "r",
  estimates = list(
    list(term = "x_cat1", estimate = unname(B["1", "x"]), se = unname(sqrt(V["1:x", "1:x"])), n_obs = n),
    list(term = "z_cat1", estimate = unname(B["1", "z"]), se = unname(sqrt(V["1:z", "1:z"])), n_obs = n),
    list(term = "x_cat2", estimate = unname(B["2", "x"]), se = unname(sqrt(V["2:x", "2:x"])), n_obs = n),
    list(term = "z_cat2", estimate = unname(B["2", "z"]), se = unname(sqrt(V["2:z", "2:z"])), n_obs = n),
    list(term = "prob_cat2_zero", estimate = unname(p2), se = NULL, n_obs = n)
  ),
  method_metadata = list(
    estimator = "multinomial logit (nnet::multinom, maximum likelihood, base outcome 0)",
    vcov = "observed information (inverse Hessian from nnet::multinom)"
  ),
  diagnostics = list(convergence = fit$convergence)
)
jsonlite::write_json(res, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
