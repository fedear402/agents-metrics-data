library(jsonlite)

df <- read.csv("input.csv", stringsAsFactors = FALSE)

att_for <- function(c0) {
  w_times <- (c0 - 2):(c0 + 2)
  d <- df[df$time %in% w_times & (df$g == c0 | df$g == 0 | df$g > c0 + 2), ]
  n_times <- tapply(d$time, as.character(d$id), function(x) length(unique(x)))
  keep <- names(n_times)[n_times == length(w_times)]
  d <- d[as.character(d$id) %in% keep, ]
  d$did <- as.numeric(d$g == c0 & d$time >= c0)
  n_treated <- length(unique(d$id[d$g == c0]))
  fit <- lm(y ~ did + factor(id) + factor(time), data = d)
  list(est = unname(coef(fit)["did"]), n_obs = nrow(d), n_treated = n_treated)
}

res3 <- att_for(3)
res5 <- att_for(5)
res7 <- att_for(7)

weights <- c(res3$n_treated, res5$n_treated, res7$n_treated)
ests <- c(res3$est, res5$est, res7$est)
att_weighted <- sum(weights * ests) / sum(weights)
n_total <- res3$n_obs + res5$n_obs + res7$n_obs

fmt <- function(x) sprintf("%.15g", x)

out <- list(
  task_id = "broad_cohort_stack",
  platform = "r",
  estimates = list(
    list(term = "att_g3", estimate = fmt(res3$est), se = NA_real_, n_obs = res3$n_obs),
    list(term = "att_g5", estimate = fmt(res5$est), se = NA_real_, n_obs = res5$n_obs),
    list(term = "att_g7", estimate = fmt(res7$est), se = NA_real_, n_obs = res7$n_obs),
    list(term = "att_weighted", estimate = fmt(att_weighted), se = NA_real_, n_obs = n_total)
  ),
  method_metadata = setNames(list(), character(0)),
  diagnostics = setNames(list(), character(0))
)

write_json(out, "result.json", auto_unbox = TRUE, pretty = TRUE, na = "null", digits = NA)
