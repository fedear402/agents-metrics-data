library(jsonlite)

d <- read.csv("input.csv")
n <- nrow(d)
q <- 2L
df <- n - 4L

ry <- resid(lm(y ~ x, data = d))
re <- resid(lm(endog ~ x, data = d))
uy <- resid(lm(y ~ x + z1 + z2, data = d))
ue <- resid(lm(endog ~ x + z1 + z2, data = d))

critical <- qf(0.95, q, df)
k <- q * critical / df

A <- sum(re^2) - (1 + k) * sum(ue^2)
B <- -2 * (sum(ry * re) - (1 + k) * sum(uy * ue))
C <- sum(ry^2) - (1 + k) * sum(uy^2)

disc <- B^2 - 4 * A * C
if (A == 0 || disc <= 0) stop("Degenerate AR set: expected two finite real boundaries")

roots <- sort((-B + c(-1, 1) * sqrt(disc)) / (2 * A))
unbounded <- as.integer(A < 0)
accepts_zero <- as.integer(C <= 0)

rr <- resid(lm(I(y - endog) ~ x, data = d))
ur <- resid(lm(I(y - endog) ~ x + z1 + z2, data = d))
ar_f_at_one <- ((sum(rr^2) - sum(ur^2)) / q) / (sum(ur^2) / df)

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = list(
    list(term = "boundary_low", estimate = unname(roots[1]), se = NULL, n_obs = as.integer(n)),
    list(term = "boundary_high", estimate = unname(roots[2]), se = NULL, n_obs = as.integer(n)),
    list(term = "accepts_zero", estimate = unname(accepts_zero), se = NULL, n_obs = as.integer(n)),
    list(term = "unbounded", estimate = unname(unbounded), se = NULL, n_obs = as.integer(n)),
    list(term = "ar_f_at_one", estimate = unname(ar_f_at_one), se = NULL, n_obs = as.integer(n))
  ),
  method_metadata = list(
    estimator = "Anderson-Rubin confidence set via inversion of homoskedastic joint F test",
    vcov = "homoskedastic"
  ),
  diagnostics = setNames(list(), character(0))
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
