suppressPackageStartupMessages({
  library(sandwich)
  library(jsonlite)
})

df <- read.csv("input.csv", stringsAsFactors = FALSE)
df <- df[order(as.Date(df$date)), ]

L <- 15
dlvix <- c(NA_real_, diff(log(df$vix)))
n <- nrow(df)

X <- matrix(NA_real_, nrow = n, ncol = L)
for (k in 1:L) {
  X[, k] <- c(rep(NA_real_, k), dlvix[1:(n - k)])
}
colnames(X) <- paste0("lag_", 1:L)

dat <- data.frame(y = log(df$sales), X)
dat <- dat[complete.cases(dat), ]

fml <- as.formula(paste("y ~", paste(colnames(X), collapse = " + ")))
fit <- lm(fml, data = dat)

N <- nrow(dat)
V <- NeweyWest(fit, lag = L, prewhite = FALSE, adjust = FALSE) * N / (N - 16)

b <- coef(fit)
idx <- paste0("lag_", 1:L)
cvec <- as.numeric(names(b) %in% idx)

cum_est <- sum(b[idx])
cum_se <- sqrt(as.numeric(t(cvec) %*% V %*% cvec))

out <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(term = "cumulative_response", estimate = unname(cum_est), se = unname(cum_se), n_obs = as.integer(N)),
    list(term = "lag_1", estimate = unname(b["lag_1"]), se = unname(sqrt(V["lag_1", "lag_1"])), n_obs = as.integer(N)),
    list(term = "lag_15", estimate = unname(b["lag_15"]), se = unname(sqrt(V["lag_15", "lag_15"])), n_obs = as.integer(N))
  ),
  method_metadata = list(
    estimator = "OLS of log(sales) on intercept and lags 1-15 of diff(log(vix))",
    vcov = "Newey-West HAC, max lag 15, Bartlett weights 1-j/16, scaled by N/(N-16)"
  ),
  diagnostics = list(
    N = as.integer(N),
    total_rows = as.integer(n),
    hac_max_lag = L,
    small_sample_factor = N / (N - 16)
  )
)

write_json(out, "result.json", auto_unbox = TRUE, pretty = TRUE, digits = NA)
