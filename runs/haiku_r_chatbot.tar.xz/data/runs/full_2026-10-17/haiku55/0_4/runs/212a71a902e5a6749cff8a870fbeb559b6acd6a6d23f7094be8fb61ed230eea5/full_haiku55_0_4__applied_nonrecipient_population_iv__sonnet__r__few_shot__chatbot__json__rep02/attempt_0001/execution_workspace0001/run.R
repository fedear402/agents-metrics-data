library(jsonlite)

hh <- read.csv("households.csv")
census <- read.csv("census.csv")
d <- subset(hh, recipient == 0)

y <- d$outcome
w <- d$weight
e <- d$eligible

C <- cbind(1 - e, e, d$baseline * (1 - e), d$baseline * e)
endog <- cbind(d$dose * (1 - e), d$dose * e)
instr <- cbind(d$instrument * (1 - e), d$instrument * e)

X <- cbind(C, endog)
Z <- cbind(C, instr)
sw <- sqrt(w)
Xw <- X * sw
Zw <- Z * sw

fitted <- qr.fitted(qr(Zw), Xw)
coefs <- qr.coef(qr(fitted), y * sw)
slopes <- unname(coefs[c(5, 6)])

gm <- function(g) {
  a <- d$eligible == g
  weighted.mean(d$dose[a], w[a])
}

effect_ineligible <- slopes[1] * gm(0)
effect_eligible <- slopes[2] * gm(1)
effect <- c(effect_ineligible, effect_eligible)

pop_w <- census$nonrecipient_population[match(0:1, census$eligible)]
population_effect <- weighted.mean(effect, pop_w)

n_obs <- as.integer(nrow(d))

result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = list(
    list(term = "ineligible_effect", estimate = unname(effect_ineligible), se = NULL, n_obs = n_obs),
    list(term = "eligible_nonrecipient_effect", estimate = unname(effect_eligible), se = NULL, n_obs = n_obs),
    list(term = "population_effect", estimate = unname(population_effect), se = NULL, n_obs = n_obs)
  ),
  method_metadata = list(
    method = "weighted 2SLS",
    endogenous = c("dose_x_ineligible", "dose_x_eligible"),
    exogenous = c("ineligible", "eligible", "baseline_x_ineligible", "baseline_x_eligible"),
    instruments = c("instrument_x_ineligible", "instrument_x_eligible"),
    weight = "weight",
    sample = "recipient == 0",
    counterfactual = "synthetic zero-dose attribution convention",
    group_aggregation = "census nonrecipient_population"
  ),
  diagnostics = list(
    n_obs = n_obs,
    n_ineligible = as.integer(sum(e == 0)),
    n_eligible = as.integer(sum(e == 1)),
    n_regressors = as.integer(ncol(X)),
    n_instruments = as.integer(ncol(Z)),
    rank_instruments = as.integer(qr(Zw)$rank)
  )
)

write_json(result, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE)
