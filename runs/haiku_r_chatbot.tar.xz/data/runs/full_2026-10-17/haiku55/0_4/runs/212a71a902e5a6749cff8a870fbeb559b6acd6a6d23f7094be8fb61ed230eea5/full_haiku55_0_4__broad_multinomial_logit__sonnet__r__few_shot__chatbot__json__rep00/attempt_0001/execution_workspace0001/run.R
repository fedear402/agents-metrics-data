d <- read.csv("input.csv")
d$y <- factor(d$y, levels = 0:2)

fit <- nnet::multinom(y ~ x + z, data = d, Hess = TRUE, trace = FALSE,
                      maxit = 1000, reltol = 1e-12, abstol = 1e-12)

B <- coef(fit)
V <- vcov(fit)

get_se <- function(row, term) sqrt(V[paste(row, term, sep = ":"), paste(row, term, sep = ":")])

x_cat1 <- unname(B["1", "x"])
z_cat1 <- unname(B["1", "z"])
x_cat2 <- unname(B["2", "x"])
z_cat2 <- unname(B["2", "z"])

se_x_cat1 <- get_se("1", "x")
se_z_cat1 <- get_se("1", "z")
se_x_cat2 <- get_se("2", "x")
se_z_cat2 <- get_se("2", "z")

indices <- c(0, B[, "(Intercept)"])
p <- exp(indices - max(indices)) / sum(exp(indices - max(indices)))
prob_cat2_zero <- unname(p[3])

n_obs <- nrow(d)

result <- list(
  task_id = "broad_multinomial_logit",
  platform = "r",
  estimates = list(
    list(term = "x_cat1", estimate = x_cat1, se = se_x_cat1, n_obs = n_obs),
    list(term = "z_cat1", estimate = z_cat1, se = se_z_cat1, n_obs = n_obs),
    list(term = "x_cat2", estimate = x_cat2, se = se_x_cat2, n_obs = n_obs),
    list(term = "z_cat2", estimate = z_cat2, se = se_z_cat2, n_obs = n_obs),
    list(term = "prob_cat2_zero", estimate = prob_cat2_zero, se = NULL, n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "multinomial logit (maximum likelihood, nnet::multinom, base outcome 0)",
    vcov = "conventional observed-information (inverse Hessian)"
  ),
  diagnostics = setNames(list(), character(0))
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
