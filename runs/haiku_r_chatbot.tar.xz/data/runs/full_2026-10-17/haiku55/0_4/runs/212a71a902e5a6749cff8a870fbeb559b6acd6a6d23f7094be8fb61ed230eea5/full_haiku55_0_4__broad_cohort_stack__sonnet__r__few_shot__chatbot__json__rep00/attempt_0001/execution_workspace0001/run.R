df <- read.csv("input.csv")
df$g <- as.numeric(df$g)
df$time <- as.numeric(df$time)
df$y <- as.numeric(df$y)

cohorts <- c(3, 5, 7)

res <- lapply(cohorts, function(cc) {
  win <- (cc - 2):(cc + 2)
  d <- df[df$time %in% win & (df$g == cc | df$g == 0 | df$g > cc + 2), ]
  n_times <- tapply(d$time, d$id, function(x) length(unique(x)))
  keep_ids <- names(n_times)[n_times == length(win)]
  d <- d[as.character(d$id) %in% keep_ids, ]
  d$did <- as.numeric(d$g == cc & d$time >= cc)
  fit <- lm(y ~ did + factor(id) + factor(time), data = d)
  list(
    att = unname(coef(fit)["did"]),
    n_obs = nrow(d),
    n_treated = length(unique(d$id[d$g == cc]))
  )
})

att <- sapply(res, `[[`, "att")
n_obs <- sapply(res, `[[`, "n_obs")
w <- sapply(res, `[[`, "n_treated")
att_weighted <- sum(w * att) / sum(w)

out <- list(
  task_id = "broad_cohort_stack",
  platform = "r",
  estimates = list(
    list(term = "att_g3", estimate = att[1], se = NULL, n_obs = as.integer(n_obs[1])),
    list(term = "att_g5", estimate = att[2], se = NULL, n_obs = as.integer(n_obs[2])),
    list(term = "att_g7", estimate = att[3], se = NULL, n_obs = as.integer(n_obs[3])),
    list(term = "att_weighted", estimate = att_weighted, se = NULL, n_obs = as.integer(sum(n_obs)))
  ),
  method_metadata = setNames(list(), character(0)),
  diagnostics = setNames(list(), character(0))
)

jsonlite::write_json(out, "result.json", auto_unbox = TRUE, null = "null", digits = 16)
