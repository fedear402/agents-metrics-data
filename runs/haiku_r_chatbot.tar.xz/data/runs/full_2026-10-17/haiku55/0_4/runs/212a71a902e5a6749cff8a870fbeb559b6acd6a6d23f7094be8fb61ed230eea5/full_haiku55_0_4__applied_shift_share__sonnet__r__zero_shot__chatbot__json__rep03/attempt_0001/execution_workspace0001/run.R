df <- read.csv("input.csv", stringsAsFactors = FALSE)

regions <- df[!duplicated(df$region_id), c("region_id", "region_weight", "x", "y")]
df$sz <- df$share * df$shock
z_tab <- tapply(df$sz, df$region_id, sum)
regions$z <- as.numeric(z_tab[as.character(regions$region_id)])
regions$e <- regions$region_weight / sum(regions$region_weight)

wm <- function(v, w) sum(w * v) / sum(w)
regions$y0 <- regions$y - wm(regions$y, regions$e)
regions$x0 <- regions$x - wm(regions$x, regions$e)
regions$z0 <- regions$z - wm(regions$z, regions$e)

m <- match(df$region_id, regions$region_id)
df$e <- regions$e[m]
df$y0 <- regions$y0[m]
df$x0 <- regions$x0[m]
df$z0 <- regions$z0[m]
df$w_share <- df$e * df$share

iv_fit <- function(y, X, Z, w) {
  A <- t(Z) %*% (w * X)
  b <- t(Z) %*% (w * y)
  Ainv <- solve(A)
  beta <- Ainv %*% b
  u <- as.vector(y - X %*% beta)
  n <- length(y)
  meat <- crossprod(Z * (w * u))
  V <- Ainv %*% meat %*% t(Ainv) * n / (n - 2)
  list(beta = as.vector(beta), se = sqrt(diag(V)))
}

reg_iv <- iv_fit(regions$y,
                 cbind(1, regions$x),
                 cbind(1, regions$z),
                 regions$e)
effect_est <- reg_iv$beta[2]

ids <- sort(unique(df$industry_id))
key <- as.character(ids)
s_n <- as.numeric(tapply(df$w_share, df$industry_id, sum)[key])
shock_n <- as.numeric(tapply(df$shock, df$industry_id, mean)[key])

agg <- function(v) as.numeric(tapply(df$w_share * v, df$industry_id, sum)[key]) / s_n
ybar <- agg(df$y0)
xbar <- agg(df$x0)
zbar <- agg(df$z0)

N <- length(ids)

sh_effect <- iv_fit(ybar, cbind(1, xbar), cbind(1, shock_n), s_n)
effect_se <- sh_effect$se[2]

first_stage_est <- sum(regions$e * regions$x0 * regions$z0) /
                   sum(regions$e * regions$z0^2)
sh_fs <- iv_fit(xbar, cbind(1, zbar), cbind(1, shock_n), s_n)
first_stage_se <- sh_fs$se[2]

effective_shocks <- 1 / sum(s_n^2)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = effect_est, se = effect_se, n_obs = N),
    list(term = "first_stage", estimate = first_stage_est, se = first_stage_se, n_obs = N),
    list(term = "effective_shocks", estimate = effective_shocks, se = NA_real_, n_obs = N)
  ),
  method_metadata = list(
    estimator = "Weighted 2SLS shift-share; BHJ shock-level weighted IV with analytic weights",
    vcov = "Shock-level heteroskedasticity-robust HC1 (N/(N-2)), no clustering"
  ),
  diagnostics = list(
    n_regions = nrow(regions),
    n_industries = N
  )
)

writeLines(jsonlite::toJSON(result, auto_unbox = TRUE, digits = NA, na = "null", pretty = TRUE),
           "result.json")
