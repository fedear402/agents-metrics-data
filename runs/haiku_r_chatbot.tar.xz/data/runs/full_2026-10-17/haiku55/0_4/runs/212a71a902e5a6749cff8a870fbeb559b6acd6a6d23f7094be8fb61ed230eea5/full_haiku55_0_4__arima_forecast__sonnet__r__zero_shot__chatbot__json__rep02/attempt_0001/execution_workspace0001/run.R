suppressPackageStartupMessages(library(jsonlite))

df <- read.csv("./input.csv")
df <- df[order(df$t), ]
y <- ts(df$y)
n_obs <- length(y)

fit <- arima(y, order = c(1, 1, 1), include.mean = FALSE, method = "ML")
p <- predict(fit, n.ahead = 1)

z <- qnorm(0.975)
fc <- as.numeric(p$pred)
se <- as.numeric(p$se)
lower <- fc - z * se
upper <- fc + z * se

coefs <- as.list(setNames(as.numeric(coef(fit)), names(coef(fit))))
coef_se <- as.list(setNames(sqrt(diag(fit$var.coef)), names(coef(fit))))

result <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = list(
    list(term = "forecast", estimate = fc, se = se, n_obs = n_obs),
    list(term = "lower_95", estimate = lower, se = NULL, n_obs = n_obs),
    list(term = "upper_95", estimate = upper, se = NULL, n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "ARIMA(1,1,1) maximum likelihood, no constant or drift",
    vcov = "model-based inverse observed information (stats::arima)"
  ),
  diagnostics = list(
    coefficients = coefs,
    coefficient_se = coef_se,
    sigma2 = fit$sigma2,
    loglik = as.numeric(fit$loglik),
    aic = fit$aic,
    convergence_code = fit$code,
    forecast_horizon_t = max(df$t) + 1
  )
)

write_json(result, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE)
