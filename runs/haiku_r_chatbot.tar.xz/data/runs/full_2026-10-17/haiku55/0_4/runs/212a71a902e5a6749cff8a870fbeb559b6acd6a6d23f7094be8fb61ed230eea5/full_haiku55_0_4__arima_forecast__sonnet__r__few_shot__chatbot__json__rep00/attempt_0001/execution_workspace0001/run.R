library(jsonlite)

d <- read.csv("./input.csv", stringsAsFactors = FALSE)
d <- d[order(d$t), ]
y <- as.numeric(d$y)

fit <- arima(y, order = c(1, 1, 1), include.mean = FALSE, method = "ML")

h <- 251 - max(d$t)
pr <- predict(fit, n.ahead = h)
fc <- as.numeric(tail(pr$pred, 1))
se <- as.numeric(tail(pr$se, 1))
z <- qnorm(0.975)

out <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = list(
    list(term = "forecast", estimate = fc, se = se, n_obs = fit$nobs),
    list(term = "lower_95", estimate = fc - z * se, se = NA, n_obs = fit$nobs),
    list(term = "upper_95", estimate = fc + z * se, se = NA, n_obs = fit$nobs)
  ),
  method_metadata = list(
    estimator = "ARIMA(1,1,1) maximum likelihood, no constant",
    vcov = "ML information matrix"
  ),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "result.json", auto_unbox = TRUE, digits = NA, na = "null", pretty = TRUE)
