d <- read.csv("input.csv")
n <- nrow(d)

W <- model.matrix(~ x, data = d)
Z <- as.matrix(d[, c("z1", "z2")])
Full <- cbind(W, Z)

resid_on <- function(M, v) lm.fit(M, v)$residuals

ry <- resid_on(W, d$y)
re <- resid_on(W, d$endog)
uy <- resid_on(Full, d$y)
ue <- resid_on(Full, d$endog)

q <- 2L
df <- n - ncol(Full)
critical <- qf(0.95, q, df)
k <- q * critical / df

A <- sum(re^2) - (1 + k) * sum(ue^2)
B <- -2 * (sum(ry * re) - (1 + k) * sum(uy * ue))
C <- sum(ry^2) - (1 + k) * sum(uy^2)
disc <- B^2 - 4 * A * C
stopifnot(abs(A) > 1e-10, disc > 0)

bounds <- sort((-B + c(-1, 1) * sqrt(disc)) / (2 * A))
accepts <- function(b) A * b^2 + B * b + C <= 0

accepts_zero <- as.integer(accepts(0))
unbounded <- as.integer(A < 0)

yt <- d$y - d$endog
ssr_r <- sum(lm.fit(W, yt)$residuals^2)
ssr_u <- sum(lm.fit(Full, yt)$residuals^2)
ar_f_at_one <- ((ssr_r - ssr_u) / q) / (ssr_u / df)

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = list(
    list(term = "boundary_low", estimate = unname(bounds[1]), se = NULL, n_obs = n),
    list(term = "boundary_high", estimate = unname(bounds[2]), se = NULL, n_obs = n),
    list(term = "accepts_zero", estimate = accepts_zero, se = NULL, n_obs = n),
    list(term = "unbounded", estimate = unbounded, se = NULL, n_obs = n),
    list(term = "ar_f_at_one", estimate = unname(ar_f_at_one), se = NULL, n_obs = n)
  ),
  method_metadata = list(
    estimator = "Anderson-Rubin confidence set by inverting homoskedastic joint F test",
    vcov = "homoskedastic"
  ),
  diagnostics = list(
    critical_value = critical,
    df_denominator = df,
    discriminant = disc
  )
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
