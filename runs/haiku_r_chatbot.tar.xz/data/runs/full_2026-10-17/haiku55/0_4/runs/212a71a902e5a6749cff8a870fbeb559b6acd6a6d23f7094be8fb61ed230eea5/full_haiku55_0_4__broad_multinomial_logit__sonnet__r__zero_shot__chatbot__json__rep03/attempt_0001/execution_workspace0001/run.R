df <- read.csv("input.csv")
X <- cbind(1, df$x, df$z)
y <- df$y
n <- nrow(X)
p <- ncol(X)
Y1 <- as.numeric(y == 1)
Y2 <- as.numeric(y == 2)

model_parts <- function(theta) {
  b1 <- theta[1:p]
  b2 <- theta[(p + 1):(2 * p)]
  e1 <- as.vector(X %*% b1)
  e2 <- as.vector(X %*% b2)
  m <- pmax(0, pmax(e1, e2))
  dl <- m + log(exp(-m) + exp(e1 - m) + exp(e2 - m))
  P1 <- exp(e1 - dl)
  P2 <- exp(e2 - dl)
  ll <- sum(Y1 * e1 + Y2 * e2 - dl)
  g <- c(crossprod(X, Y1 - P1), crossprod(X, Y2 - P2))
  I11 <- crossprod(X, X * (P1 * (1 - P1)))
  I22 <- crossprod(X, X * (P2 * (1 - P2)))
  I12 <- crossprod(X, X * (-P1 * P2))
  I <- rbind(cbind(I11, I12), cbind(I12, I22))
  list(ll = ll, g = g, I = I)
}

theta <- rep(0, 2 * p)
converged <- FALSE
iter <- 0
for (k in 1:100) {
  iter <- k
  mp <- model_parts(theta)
  step <- solve(mp$I, mp$g)
  theta <- theta + step
  if (max(abs(step)) < 1e-10) {
    converged <- TRUE
    break
  }
}

mp <- model_parts(theta)
V <- solve(mp$I)
se <- sqrt(diag(V))

b1 <- theta[1:p]
b2 <- theta[(p + 1):(2 * p)]
denom0 <- 1 + exp(b1[1]) + exp(b2[1])
prob_cat2_zero <- exp(b2[1]) / denom0

fmt <- function(v) sprintf("%.15g", v)

est_json <- paste0(
  "[",
  paste0(
    "{\"term\": \"x_cat1\", \"estimate\": ", fmt(theta[2]),
    ", \"se\": ", fmt(se[2]), ", \"n_obs\": ", n, "},\n",
    "    {\"term\": \"z_cat1\", \"estimate\": ", fmt(theta[3]),
    ", \"se\": ", fmt(se[3]), ", \"n_obs\": ", n, "},\n",
    "    {\"term\": \"x_cat2\", \"estimate\": ", fmt(theta[p + 2]),
    ", \"se\": ", fmt(se[p + 2]), ", \"n_obs\": ", n, "},\n",
    "    {\"term\": \"z_cat2\", \"estimate\": ", fmt(theta[p + 3]),
    ", \"se\": ", fmt(se[p + 3]), ", \"n_obs\": ", n, "},\n",
    "    {\"term\": \"prob_cat2_zero\", \"estimate\": ", fmt(prob_cat2_zero),
    ", \"se\": null, \"n_obs\": ", n, "}"
  ),
  "]"
)

json <- paste0(
  "{\n",
  "  \"task_id\": \"broad_multinomial_logit\",\n",
  "  \"platform\": \"r\",\n",
  "  \"estimates\": ", est_json, ",\n",
  "  \"method_metadata\": {\"estimator\": \"multinomial logit maximum likelihood (Newton-Raphson, base R, baseline category 0)\", \"vcov\": \"conventional observed-information (inverse of negative Hessian of log-likelihood)\"},\n",
  "  \"diagnostics\": {\"log_likelihood\": ", fmt(mp$ll),
  ", \"iterations\": ", iter,
  ", \"converged\": ", tolower(as.character(converged)), "}\n",
  "}\n"
)

writeLines(json, "result.json")
