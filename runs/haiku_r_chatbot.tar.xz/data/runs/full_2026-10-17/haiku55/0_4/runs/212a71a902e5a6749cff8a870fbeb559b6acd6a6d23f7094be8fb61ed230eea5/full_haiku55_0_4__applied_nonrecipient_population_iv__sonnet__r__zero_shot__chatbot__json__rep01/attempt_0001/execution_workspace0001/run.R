suppressPackageStartupMessages(library(jsonlite))

hh <- read.csv("households.csv", stringsAsFactors = FALSE)
census <- read.csv("census.csv", stringsAsFactors = FALSE)

num_cols <- c("eligible", "treated", "recipient", "instrument", "dose",
              "baseline", "weight", "outcome")
for (v in num_cols) hh[[v]] <- as.numeric(hh[[v]])

d <- hh[hh$recipient == 0, , drop = FALSE]
n_obs <- as.integer(nrow(d))

e    <- d$eligible
ne   <- 1 - e
dose <- d$dose
base <- d$baseline
inst <- d$instrument
w    <- d$weight
y    <- d$outcome

X <- cbind(dose * ne, dose * e, ne, e, base * ne, base * e)
colnames(X) <- c("dose_ineligible", "dose_eligible",
                 "ineligible", "eligible",
                 "baseline_ineligible", "baseline_eligible")

Z <- cbind(ne, e, base * ne, base * e, inst * ne, inst * e)

ZtWZ <- crossprod(Z, w * Z)
ZtWX <- crossprod(Z, w * X)
ZtWy <- crossprod(Z, w * y)

A      <- solve(ZtWZ)
XtWZA  <- t(ZtWX) %*% A
lhs    <- XtWZA %*% ZtWX
rhs    <- XtWZA %*% ZtWy
beta   <- as.numeric(solve(lhs, rhs))
names(beta) <- colnames(X)

slope_ineligible <- beta[["dose_ineligible"]]
slope_eligible   <- beta[["dose_eligible"]]

mean_dose_ineligible <- sum(w * ne * dose) / sum(w * ne)
mean_dose_eligible   <- sum(w * e * dose) / sum(w * e)

ineligible_effect          <- slope_ineligible * mean_dose_ineligible
eligible_nonrecipient_effect <- slope_eligible * mean_dose_eligible

pop_ineligible <- as.numeric(census$nonrecipient_population[match(0, census$eligible)])
pop_eligible   <- as.numeric(census$nonrecipient_population[match(1, census$eligible)])

population_effect <- (pop_ineligible * ineligible_effect +
                      pop_eligible * eligible_nonrecipient_effect) /
                     (pop_ineligible + pop_eligible)

estimates <- list(
  list(term = "ineligible_effect",
       estimate = unname(ineligible_effect),
       se = NA_real_,
       n_obs = n_obs),
  list(term = "eligible_nonrecipient_effect",
       estimate = unname(eligible_nonrecipient_effect),
       se = NA_real_,
       n_obs = n_obs),
  list(term = "population_effect",
       estimate = unname(population_effect),
       se = NA_real_,
       n_obs = n_obs)
)

method_metadata <- list(
  method = "weighted 2SLS, no intercept",
  endogenous = c("dose*(1-eligible)", "dose*eligible"),
  exogenous = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"),
  instruments = c("exogenous columns", "instrument*(1-eligible)", "instrument*eligible"),
  regression_weight = "weight",
  sample = "recipient == 0, all eligibility and treatment groups",
  counterfactual = "dose set to zero for every retained household; attribution is a stated synthetic convention",
  group_effect = "dose slope times household-weighted mean dose within eligibility group",
  aggregation = "nonrecipient_population from census.csv"
)

diagnostics <- list(
  n_obs = n_obs,
  n_ineligible = as.integer(sum(ne == 1)),
  n_eligible = as.integer(sum(e == 1)),
  rank_lhs = as.integer(qr(lhs)$rank),
  n_parameters = as.integer(ncol(X)),
  n_instruments = as.integer(ncol(Z)),
  slope_dose_ineligible = unname(slope_ineligible),
  slope_dose_eligible = unname(slope_eligible),
  weighted_mean_dose_ineligible = mean_dose_ineligible,
  weighted_mean_dose_eligible = mean_dose_eligible,
  census_nonrecipient_population_ineligible = pop_ineligible,
  census_nonrecipient_population_eligible = pop_eligible
)

result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = method_metadata,
  diagnostics = diagnostics
)

write_json(result, "result.json", auto_unbox = TRUE, digits = NA,
           na = "null", pretty = TRUE)
