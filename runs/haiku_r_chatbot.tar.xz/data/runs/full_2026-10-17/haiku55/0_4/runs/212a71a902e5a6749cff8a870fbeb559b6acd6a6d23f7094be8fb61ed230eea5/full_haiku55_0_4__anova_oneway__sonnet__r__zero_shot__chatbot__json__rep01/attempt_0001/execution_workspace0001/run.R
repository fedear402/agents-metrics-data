suppressWarnings(suppressMessages({
  df <- read.csv("./input.csv", stringsAsFactors = FALSE)
  df$group <- factor(df$group)
  df <- df[is.finite(df$y) & !is.na(df$group), ]
  fit <- aov(y ~ group, data = df)
  s <- summary(fit)[[1]]
  F_stat <- s[["F value"]][1]
  df_num <- s[["Df"]][1]
  df_den <- s[["Df"]][2]
  p_val  <- s[["Pr(>F)"]][1]
  n_obs  <- nrow(df)
  out <- list(
    task_id = "anova_oneway",
    platform = "r",
    estimates = list(
      list(term = "F", estimate = as.numeric(F_stat), se = NULL, n_obs = as.integer(n_obs)),
      list(term = "df_num", estimate = as.numeric(df_num), se = NULL, n_obs = as.integer(n_obs)),
      list(term = "df_den", estimate = as.numeric(df_den), se = NULL, n_obs = as.integer(n_obs)),
      list(term = "p_value", estimate = as.numeric(p_val), se = NULL, n_obs = as.integer(n_obs))
    ),
    method_metadata = list(
      estimator = "one-way ANOVA (aov, type I sums of squares)",
      vcov = "classical"
    ),
    diagnostics = setNames(list(), character(0))
  )
  jsonlite_ok <- requireNamespace("jsonlite", quietly = TRUE)
  if (jsonlite_ok) {
    json <- jsonlite::toJSON(out, auto_unbox = TRUE, digits = NA, null = "null", pretty = TRUE)
  } else {
    fmt <- function(x) format(x, digits = 15, scientific = TRUE)
    est <- sapply(out$estimates, function(e)
      sprintf('{"term": "%s", "estimate": %s, "se": null, "n_obs": %d}',
              e$term, fmt(e$estimate), e$n_obs))
    json <- sprintf(
      '{\n  "task_id": "anova_oneway",\n  "platform": "r",\n  "estimates": [\n    %s\n  ],\n  "method_metadata": {"estimator": "one-way ANOVA (aov, type I sums of squares)", "vcov": "classical"},\n  "diagnostics": {}\n}',
      paste(est, collapse = ",\n    "))
  }
  writeLines(as.character(json), "result.json")
}))
