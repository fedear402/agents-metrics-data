library(jsonlite)

df <- read.csv("input.csv", stringsAsFactors = FALSE)
df$date <- as.Date(df$date)
df <- df[order(df$date), ]

ls_sales <- log(df$sales)
lv <- log(df$vix)
n <- nrow(df)
dv <- c(NA, diff(lv))

L <- 15
idx <- (L + 2):n
y <- ls_sales[idx]
X <- cbind(1, sapply(1:L, function(k) dv[idx - k]))
colnames(X) <- c("(Intercept)", paste0("lag_", 1:L))
N <- length(y)

b <- solve(crossprod(X), crossprod(X, y))
e <- as.vector(y - X %*% b)
U <- X * e
bread <- solve(crossprod(X))

S <- crossprod(U)
for (j in 1:L) {
  w <- 1 - j / (L + 1)
  G <- crossprod(U[(j + 1):N, , drop = FALSE], U[1:(N - j), , drop = FALSE])
  S <- S + w * (G + t(G))
}
V <- bread %*% S %*% bread * N / (N - (L + 1))

slope_idx <- 2:(L + 1)
cvec <- rep(1, L)
cum_est <- sum(b[slope_idx])
cum_se <- sqrt(as.numeric(t(cvec) %*% V[slope_idx, slope_idx] %*% cvec))

res <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(term = "cumulative_response", estimate = as.numeric(cum_est),
         se = cum_se, n_obs = as.integer(N)),
    list(term = "lag_1", estimate = as.numeric(b[2]),
         se = sqrt(V[2, 2]), n_obs = as.integer(N)),
    list(term = "lag_15", estimate = as.numeric(b[L + 1]),
         se = sqrt(V[L + 1, L + 1]), n_obs = as.integer(N))
  ),
  method_metadata = list(
    estimator = "OLS of log(sales) on intercept and 15 lags of first difference of log(vix)",
    vcov = "Newey-West HAC, max lag 15, Bartlett weights 1-j/16, scaled by N/(N-16)"
  ),
  diagnostics = list(
    first_obs_used = as.integer(idx[1]),
    last_obs_used = as.integer(idx[N]),
    total_obs = as.integer(n)
  )
)

write_json(res, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE)
