df <- read.csv("input.csv")
n <- nrow(df)
y <- df$y
e <- df$endog
x <- df$x
z1 <- df$z1
z2 <- df$z2

Xu <- cbind(1, x, z1, z2)
Xr <- cbind(1, x)
Mu <- diag(n) - Xu %*% solve(crossprod(Xu), t(Xu))
Mr <- diag(n) - Xr %*% solve(crossprod(Xr), t(Xr))

quad_terms <- function(M) {
  c(as.numeric(t(y) %*% M %*% y),
    as.numeric(t(e) %*% M %*% y),
    as.numeric(t(e) %*% M %*% e))
}
u <- quad_terms(Mu)
r <- quad_terms(Mr)

crit <- qf(0.95, 2, n - 4)

f_stat <- function(b) {
  yb <- y - b * e
  rss_u <- sum(resid(lm(yb ~ x + z1 + z2))^2)
  rss_r <- sum(resid(lm(yb ~ x))^2)
  ((rss_r - rss_u) / 2) / (rss_u / (n - 4))
}

# Acceptance: F(b) <= crit  <=>  A*b^2 + B*b + C <= 0
A <- (r[3] - u[3]) / 2 - crit * u[3] / (n - 4)
B <- -(r[2] - u[2]) + 2 * crit * u[2] / (n - 4)
C <- (r[1] - u[1]) / 2 - crit * u[1] / (n - 4)

disc <- B^2 - 4 * A * C
if (abs(A) > 1e-12) {
  if (disc >= 0) {
    roots <- sort((-B + c(-1, 1) * sqrt(disc)) / (2 * A))
  } else {
    roots <- c(NA_real_, NA_real_)
  }
} else {
  roots <- c(-C / B, NA_real_)
}

boundary_low <- roots[1]
boundary_high <- roots[2]
unbounded <- as.numeric(A <= 0)
accepts_zero <- as.numeric(f_stat(0) <= crit)
ar_f_at_one <- f_stat(1)

fmt <- function(v) if (is.na(v)) "null" else sprintf("%.10g", v)

json <- c(
  "{",
  '  "task_id": "broad_ar_confidence_set",',
  '  "platform": "r",',
  '  "estimates": [',
  sprintf('    {"term": "boundary_low", "estimate": %s, "se": null, "n_obs": %d},', fmt(boundary_low), n),
  sprintf('    {"term": "boundary_high", "estimate": %s, "se": null, "n_obs": %d},', fmt(boundary_high), n),
  sprintf('    {"term": "accepts_zero", "estimate": %s, "se": null, "n_obs": %d},', fmt(accepts_zero), n),
  sprintf('    {"term": "unbounded", "estimate": %s, "se": null, "n_obs": %d},', fmt(unbounded), n),
  sprintf('    {"term": "ar_f_at_one", "estimate": %s, "se": null, "n_obs": %d}', fmt(ar_f_at_one), n),
  "  ],",
  '  "method_metadata": {"estimator": "Anderson-Rubin test inversion with homoskedastic joint F test (quadratic root solution)", "vcov": "homoskedastic"},',
  '  "diagnostics": {}',
  "}"
)
writeLines(json, "result.json")
