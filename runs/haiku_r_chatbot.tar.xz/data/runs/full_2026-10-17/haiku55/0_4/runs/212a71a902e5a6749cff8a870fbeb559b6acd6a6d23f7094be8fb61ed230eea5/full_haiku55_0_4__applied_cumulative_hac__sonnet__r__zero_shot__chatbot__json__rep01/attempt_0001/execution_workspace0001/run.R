library(jsonlite)

df <- read.csv("input.csv", stringsAsFactors = FALSE)
df$date <- as.Date(df$date)
df <- df[order(df$date), ]

n <- nrow(df)
L <- 15
ls_sales <- log(df$sales)
d_lvix <- c(NA, diff(log(df$vix)))

rows <- (L + 2):n
y <- ls_sales[rows]
X <- cbind(1, sapply(1:L, function(j) d_lvix[rows - j]))
colnames(X) <- c("(Intercept)", paste0("lag_", 1:L))
N <- length(y)

fit <- lm.fit(X, y)
beta <- fit$coefficients
e <- fit$residuals

XtXi <- solve(crossprod(X))
U <- X * as.vector(e)

S <- crossprod(U)
for (j in 1:L) {
  w <- 1 - j / (L + 1)
  G <- crossprod(U[(j + 1):N, , drop = FALSE], U[1:(N - j), , drop = FALSE])
  S <- S + w * (G + t(G))
}

V <- XtXi %*% S %*% XtXi * N / (N - (L + 1))

cvec <- c(0, rep(1, L))
cum_est <- sum(beta[-1])
cum_se <- sqrt(as.numeric(t(cvec) %*% V %*% cvec))

res <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(term = "cumulative_response", estimate = cum_est, se = cum_se, n_obs = as.integer(N)),
    list(term = "lag_1", estimate = as.numeric(beta[2]), se = sqrt(V[2, 2]), n_obs = as.integer(N)),
    list(term = "lag_15", estimate = as.numeric(beta[16]), se = sqrt(V[16, 16]), n_obs = as.integer(N))
  ),
  method_metadata = list(
    estimator = "OLS regression of log(sales) on intercept and 15 lags of diff(log(vix))",
    vcov = "Newey-West HAC, max lag 15, Bartlett weights 1-j/16, scaled by N/(N-16)"
  ),
  diagnostics = setNames(list(), character(0))
)

write_json(res, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE)
