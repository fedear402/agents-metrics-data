df <- read.csv("input.csv")
y <- as.integer(df$y)
X <- cbind(1, df$x, df$z)
n <- as.integer(nrow(df))
Y1 <- as.numeric(y == 1)
Y2 <- as.numeric(y == 2)

lse_fun <- function(e1, e2) {
  m <- pmax(0, pmax(e1, e2))
  m + log(exp(-m) + exp(e1 - m) + exp(e2 - m))
}

negll <- function(theta) {
  e1 <- as.vector(X %*% theta[1:3])
  e2 <- as.vector(X %*% theta[4:6])
  lse <- lse_fun(e1, e2)
  -sum(Y1 * e1 + Y2 * e2 - lse)
}

neggrad <- function(theta) {
  e1 <- as.vector(X %*% theta[1:3])
  e2 <- as.vector(X %*% theta[4:6])
  lse <- lse_fun(e1, e2)
  P1 <- exp(e1 - lse)
  P2 <- exp(e2 - lse)
  c(colSums(-(Y1 - P1) * X), colSums(-(Y2 - P2) * X))
}

fit <- optim(rep(0, 6), negll, neggrad, method = "BFGS",
             hessian = TRUE, control = list(reltol = 1e-14, maxit = 5000))

theta <- fit$par
vcov_mat <- solve(fit$hessian)
se <- sqrt(diag(vcov_mat))

a2 <- theta[4]
a1 <- theta[1]
prob_cat2_zero <- exp(a2) / (1 + exp(a1) + exp(a2))

fmt <- function(v) if (is.null(v) || is.na(v)) "null" else sprintf("%.15g", v)
ent <- function(term, est, s) {
  sprintf('{"term": "%s", "estimate": %s, "se": %s, "n_obs": %d}',
          term, fmt(est), fmt(s), n)
}

ests <- c(
  ent("x_cat1", theta[2], se[2]),
  ent("z_cat1", theta[3], se[3]),
  ent("x_cat2", theta[5], se[5]),
  ent("z_cat2", theta[6], se[6]),
  ent("prob_cat2_zero", prob_cat2_zero, NULL)
)

json <- paste0(
  '{\n',
  '  "task_id": "broad_multinomial_logit",\n',
  '  "platform": "r",\n',
  '  "estimates": [\n    ',
  paste(ests, collapse = ',\n    '),
  '\n  ],\n',
  '  "method_metadata": {"estimator": "multinomial logit, maximum likelihood (base R optim BFGS with analytic gradient)", ',
  '"vcov": "observed information (inverse of numerical Hessian of negative log-likelihood)"},\n',
  '  "diagnostics": {"convergence": ', sprintf("%d", fit$convergence),
  ', "log_likelihood": ', fmt(-fit$value),
  ', "n_obs": ', sprintf("%d", n), '}\n',
  '}\n'
)

writeLines(json, "result.json")
