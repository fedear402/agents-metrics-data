suppressPackageStartupMessages(library(jsonlite))

df <- read.csv("input.csv", stringsAsFactors = FALSE)

reg <- do.call(rbind, lapply(split(df, df$region_id), function(d) {
  data.frame(
    region_id = d$region_id[1],
    w = d$region_weight[1],
    x = d$x[1],
    y = d$y[1],
    z = sum(d$share * d$shock),
    stringsAsFactors = FALSE
  )
}))
reg$e <- reg$w / sum(reg$w)

dm <- function(v, w) v - sum(w * v)
reg$y0 <- dm(reg$y, reg$e)
reg$x0 <- dm(reg$x, reg$e)
reg$z0 <- dm(reg$z, reg$e)

df$e <- reg$e[match(df$region_id, reg$region_id)]
df$y0 <- reg$y0[match(df$region_id, reg$region_id)]
df$x0 <- reg$x0[match(df$region_id, reg$region_id)]
df$z0 <- reg$z0[match(df$region_id, reg$region_id)]

s_tab <- tapply(df$e * df$share, df$industry_id, sum)
ind <- data.frame(
  industry_id = names(s_tab),
  s = as.numeric(s_tab),
  stringsAsFactors = FALSE
)
sh_tab <- tapply(df$shock, df$industry_id, function(v) v[1])
ind$shock <- as.numeric(sh_tab[ind$industry_id])

agg <- function(v) {
  num <- tapply(df$e * df$share * v, df$industry_id, sum)
  as.numeric(num[ind$industry_id]) / ind$s
}
ind$ybar <- agg(df$y0)
ind$xbar <- agg(df$x0)
ind$zbar <- agg(df$z0)

iv_hc1 <- function(y, X, Z, w) {
  sw <- sqrt(w)
  Xw <- X * sw
  Zw <- Z * sw
  yw <- y * sw
  Xhat <- Zw %*% solve(crossprod(Zw), crossprod(Zw, Xw))
  beta <- solve(crossprod(Xhat), crossprod(Xhat, yw))
  eh <- as.vector(yw - Xw %*% beta)
  bread <- solve(crossprod(Xhat))
  meat <- crossprod(Xhat * eh)
  n <- length(y)
  k <- ncol(X)
  V <- bread %*% meat %*% bread * n / (n - k)
  list(beta = as.vector(beta), se = sqrt(diag(V)))
}

N <- nrow(ind)

fit_reg <- iv_hc1(reg$y, cbind(1, reg$x), cbind(1, reg$z), reg$e)
fit_sh <- iv_hc1(ind$ybar, cbind(1, ind$xbar), cbind(1, ind$shock), ind$s)

effect_est <- fit_reg$beta[2]
effect_se <- fit_sh$se[2]

fs_est <- sum(reg$e * reg$z0 * reg$x0) / sum(reg$e * reg$z0^2)
fs_fit <- iv_hc1(ind$xbar, cbind(1, ind$zbar), cbind(1, ind$shock), ind$s)
fs_se <- fs_fit$se[2]

eff_shocks <- 1 / sum(ind$s^2)

out <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = effect_est, se = effect_se, n_obs = as.integer(N)),
    list(term = "first_stage", estimate = fs_est, se = fs_se, n_obs = as.integer(N)),
    list(term = "effective_shocks", estimate = eff_shocks, se = NA_real_, n_obs = as.integer(N))
  ),
  method_metadata = list(
    estimator = "Weighted 2SLS shift-share with BHJ shock-level weighted IV (analytic weights e_r and s_n)",
    vcov = "Shock-level heteroskedasticity-robust HC1 (N/(N-2)), structural IV residuals, no clustering"
  ),
  diagnostics = setNames(list(), character(0))
)

write_json(out, "result.json", auto_unbox = TRUE, digits = NA, na = "null", pretty = TRUE)
