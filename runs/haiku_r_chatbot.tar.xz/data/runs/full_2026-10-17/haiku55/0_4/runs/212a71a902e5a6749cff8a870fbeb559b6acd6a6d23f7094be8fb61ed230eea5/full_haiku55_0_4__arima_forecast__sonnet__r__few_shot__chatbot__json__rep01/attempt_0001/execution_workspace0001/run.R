library(jsonlite)

df <- read.csv("./input.csv")
df <- df[order(df$t), ]
y <- as.numeric(df$y)
n <- length(y)

fit <- arima(y, order = c(1, 1, 1), include.mean = FALSE, method = "ML")
pr <- predict(fit, n.ahead = 1)

fc <- as.numeric(pr$pred[1])
se_fc <- as.numeric(pr$se[1])
z <- qnorm(0.975)
lower <- fc - z * se_fc
upper <- fc + z * se_fc

out <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = list(
    list(term = "forecast", estimate = fc, se = se_fc, n_obs = n),
    list(term = "lower_95", estimate = lower, se = NA, n_obs = n),
    list(term = "upper_95", estimate = upper, se = NA, n_obs = n)
  ),
  method_metadata = list(
    estimator = "ARIMA(1,1,1) by maximum likelihood, no constant",
    vcov = "ML information matrix"
  ),
  diagnostics = list(
    loglik = as.numeric(fit$loglik),
    aic = as.numeric(fit$aic),
    ar1 = as.numeric(coef(fit)["ar1"]),
    ma1 = as.numeric(coef(fit)["ma1"])
  )
)

write_json(out, "result.json", auto_unbox = TRUE, digits = NA, na = "null", pretty = TRUE)
