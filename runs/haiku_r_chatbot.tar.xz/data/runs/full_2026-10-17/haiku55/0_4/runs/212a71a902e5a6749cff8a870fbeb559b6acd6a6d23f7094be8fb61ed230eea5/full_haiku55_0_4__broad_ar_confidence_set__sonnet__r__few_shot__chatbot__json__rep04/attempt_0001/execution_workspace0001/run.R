d <- read.csv("input.csv")
n <- nrow(d)
q <- 2L
df <- n - 4L
crit <- qf(0.95, q, df)
k <- q * crit / df

ssr_pair <- function(b) {
  yt <- d$y - b * d$endog
  ssr_r <- sum(residuals(lm(yt ~ x, data = d))^2)
  ssr_u <- sum(residuals(lm(yt ~ x + z1 + z2, data = d))^2)
  c(ssr_r, ssr_u)
}

g <- function(b) {
  s <- ssr_pair(b)
  s[1] - (1 + k) * s[2]
}

C <- g(0)
g1 <- g(1)
gm1 <- g(-1)
A <- (g1 + gm1) / 2 - C
B <- (g1 - gm1) / 2

disc <- B^2 - 4 * A * C
stopifnot(abs(A) > 1e-12, disc > 0)
roots <- sort((-B + c(-1, 1) * sqrt(disc)) / (2 * A))

s1 <- ssr_pair(1)
f_at_one <- ((s1[1] - s1[2]) / q) / (s1[2] / df)

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = list(
    list(term = "boundary_low", estimate = unname(roots[1]), se = NULL, n_obs = as.integer(n)),
    list(term = "boundary_high", estimate = unname(roots[2]), se = NULL, n_obs = as.integer(n)),
    list(term = "accepts_zero", estimate = as.numeric(C <= 0), se = NULL, n_obs = as.integer(n)),
    list(term = "unbounded", estimate = as.numeric(A < 0), se = NULL, n_obs = as.integer(n)),
    list(term = "ar_f_at_one", estimate = unname(f_at_one), se = NULL, n_obs = as.integer(n))
  ),
  method_metadata = list(
    estimator = "Anderson-Rubin test inversion with homoskedastic joint F test",
    vcov = "homoskedastic"
  ),
  diagnostics = list(
    quadratic_A = A,
    quadratic_B = B,
    quadratic_C = C,
    discriminant = disc,
    critical_value = crit,
    df_residual = df
  )
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
