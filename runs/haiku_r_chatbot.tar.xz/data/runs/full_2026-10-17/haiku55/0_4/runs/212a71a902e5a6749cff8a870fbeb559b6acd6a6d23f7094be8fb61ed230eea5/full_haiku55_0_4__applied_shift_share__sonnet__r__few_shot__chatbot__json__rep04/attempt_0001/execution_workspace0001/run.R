library(jsonlite)

df <- read.csv("input.csv", stringsAsFactors = FALSE)
regions <- sort(unique(df$region_id))
first <- df[match(regions, df$region_id), ]
e <- first$region_weight / sum(first$region_weight)
y <- first$y
x <- first$x
z <- drop(tapply(df$share * df$shock, df$region_id, sum)[as.character(regions)])

wm <- function(v) v - sum(e * v)
y0 <- wm(y)
x0 <- wm(x)
z0 <- wm(z)

idx <- match(df$region_id, regions)
ew <- e[idx] * df$share
industries <- sort(unique(df$industry_id))
s <- drop(tapply(ew, df$industry_id, sum)[as.character(industries)])
agg <- function(v0) drop(tapply(ew * v0[idx], df$industry_id, sum)[as.character(industries)]) / s
ybar <- agg(y0)
xbar <- agg(x0)
zbar <- agg(z0)
sh <- drop(tapply(df$shock, df$industry_id, function(v) v[1])[as.character(industries)])

shock_iv <- function(dep, endog, instr, w) {
  Z <- cbind(1, instr)
  X <- cbind(1, endog)
  cross <- crossprod(Z, w * X)
  beta <- solve(cross, crossprod(Z, w * dep))
  u <- drop(dep - X %*% beta)
  scores <- Z * (w * u)
  N <- length(dep)
  inv <- solve(cross)
  V <- N / (N - 2) * inv %*% crossprod(scores) %*% t(inv)
  c(slope = beta[2], se = sqrt(V[2, 2]))
}

N <- length(industries)
effect <- shock_iv(ybar, xbar, sh, s)
first_stage <- shock_iv(xbar, zbar, sh, s)
effective_shocks <- 1 / sum(s^2)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = unname(as.numeric(effect["slope"])),
         se = unname(as.numeric(effect["se"])), n_obs = as.integer(N)),
    list(term = "first_stage", estimate = unname(as.numeric(first_stage["slope"])),
         se = unname(as.numeric(first_stage["se"])), n_obs = as.integer(N)),
    list(term = "effective_shocks", estimate = unname(as.numeric(effective_shocks)),
         se = NA_real_, n_obs = as.integer(N))
  ),
  method_metadata = list(
    estimator = "Weighted 2SLS of y on x instrumented by shift-share z, with Borusyak-Hull-Jaravel shock-level IV aggregation",
    vcov = "Shock-level HC1 robust (N/(N-2)) with structural IV residuals, analytic weights, no clustering"
  ),
  diagnostics = setNames(list(), character(0))
)

write_json(result, "result.json", auto_unbox = TRUE, digits = 16, pretty = TRUE, na = "null")
