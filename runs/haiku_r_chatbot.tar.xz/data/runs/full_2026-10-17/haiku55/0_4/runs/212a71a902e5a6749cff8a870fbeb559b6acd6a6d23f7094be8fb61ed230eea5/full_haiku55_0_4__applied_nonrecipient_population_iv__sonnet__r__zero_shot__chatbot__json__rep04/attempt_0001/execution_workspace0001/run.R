suppressPackageStartupMessages(library(jsonlite))

hh <- read.csv("households.csv", stringsAsFactors = FALSE)
census <- read.csv("census.csv", stringsAsFactors = FALSE)

num_cols <- c("eligible", "treated", "recipient", "instrument", "dose", "baseline", "weight", "outcome")
for (v in num_cols) hh[[v]] <- as.numeric(hh[[v]])
census$eligible <- as.numeric(census$eligible)
census$nonrecipient_population <- as.numeric(census$nonrecipient_population)

d <- hh[hh$recipient == 0, , drop = FALSE]
n <- nrow(d)

e <- d$eligible
ne <- 1 - e
w <- d$weight
y <- d$outcome

X <- cbind(
  dose_inel = d$dose * ne,
  dose_el = d$dose * e,
  inel = ne,
  el = e,
  base_inel = d$baseline * ne,
  base_el = d$baseline * e
)

Z <- cbind(
  inel = ne,
  el = e,
  base_inel = d$baseline * ne,
  base_el = d$baseline * e,
  inst_inel = d$instrument * ne,
  inst_el = d$instrument * e
)

ZW <- t(Z * w)
ZWZ_inv <- solve(ZW %*% Z)
ZWX <- ZW %*% X
ZWy <- ZW %*% y
A <- t(ZWX) %*% ZWZ_inv %*% ZWX
b <- t(ZWX) %*% ZWZ_inv %*% ZWy
beta <- as.vector(solve(A, b))

slope_inel <- beta[1]
slope_el <- beta[2]

mean_dose_inel <- sum(w * d$dose * ne) / sum(w * ne)
mean_dose_el <- sum(w * d$dose * e) / sum(w * e)

ineligible_effect <- slope_inel * mean_dose_inel
eligible_nonrecipient_effect <- slope_el * mean_dose_el

N0 <- sum(census$nonrecipient_population[census$eligible == 0])
N1 <- sum(census$nonrecipient_population[census$eligible == 1])
population_effect <- (N0 * ineligible_effect + N1 * eligible_nonrecipient_effect) / (N0 + N1)

est <- function(term, value) {
  list(term = term, estimate = as.numeric(value), se = NULL, n_obs = as.integer(n))
}

result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = list(
    est("ineligible_effect", ineligible_effect),
    est("eligible_nonrecipient_effect", eligible_nonrecipient_effect),
    est("population_effect", population_effect)
  ),
  method_metadata = list(
    estimator = "weighted_2SLS",
    weight_variable = "weight",
    intercept = FALSE,
    endogenous = c("dose*(1-eligible)", "dose*eligible"),
    exogenous = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"),
    instruments = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible",
                    "instrument*(1-eligible)", "instrument*eligible"),
    sample = "households with recipient == 0, both treatment statuses retained",
    counterfactual = "dose set to zero for every retained household",
    group_effect = "fitted dose slope times weighted mean dose within eligibility group",
    aggregation = "census nonrecipient_population weights across eligibility groups",
    attribution_convention = "synthetic zero-dose attribution convention"
  ),
  diagnostics = list(
    n_obs = as.integer(n),
    n_ineligible = as.integer(sum(ne)),
    n_eligible = as.integer(sum(e)),
    n_endogenous = 2L,
    n_instruments = as.integer(ncol(Z)),
    slope_ineligible = slope_inel,
    slope_eligible = slope_el,
    weighted_mean_dose_ineligible = mean_dose_inel,
    weighted_mean_dose_eligible = mean_dose_el,
    nonrecipient_population_ineligible = N0,
    nonrecipient_population_eligible = N1
  )
)

write_json(result, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE, null = "null")
