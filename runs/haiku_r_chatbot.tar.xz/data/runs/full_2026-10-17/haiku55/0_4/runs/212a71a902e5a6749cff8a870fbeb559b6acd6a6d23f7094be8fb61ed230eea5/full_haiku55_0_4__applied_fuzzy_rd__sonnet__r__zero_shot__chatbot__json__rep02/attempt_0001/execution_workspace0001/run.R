df <- read.csv("input.csv")
h <- 1
d <- df[abs(df$score) < h, ]
s <- d$score
w <- 1 - abs(s)
D <- as.numeric(s >= 0)
X <- cbind(1, D, s, D * s)
n <- nrow(X)

B <- solve(crossprod(X, X * w))

y <- d$earnings
t <- d$participated
by <- B %*% crossprod(X, w * y)
bt <- B %*% crossprod(X, w * t)
ey <- as.vector(y - X %*% by)
et <- as.vector(t - X %*% bt)

meat <- function(a, b) crossprod(X, X * (w^2 * a * b))
Vyy <- B %*% meat(ey, ey) %*% B
Vtt <- B %*% meat(et, et) %*% B
Vyt <- B %*% meat(ey, et) %*% B

rf <- as.numeric(by[2])
fs <- as.numeric(bt[2])
te <- rf / fs

V2 <- matrix(c(Vyy[2, 2], Vyt[2, 2], Vyt[2, 2], Vtt[2, 2]), 2, 2)
g <- c(1 / fs, -rf / fs^2)
te_se <- sqrt(as.numeric(t(g) %*% V2 %*% g))
rf_se <- sqrt(Vyy[2, 2])
fs_se <- sqrt(Vtt[2, 2])

f <- function(x) format(x, digits = 15)

json <- paste0(
  "{\n",
  "  \"task_id\": \"applied_fuzzy_rd\",\n",
  "  \"platform\": \"r\",\n",
  "  \"estimates\": [\n",
  "    {\"term\": \"treatment_effect\", \"estimate\": ", f(te), ", \"se\": ", f(te_se), ", \"n_obs\": ", n, "},\n",
  "    {\"term\": \"reduced_form\", \"estimate\": ", f(rf), ", \"se\": ", f(rf_se), ", \"n_obs\": ", n, "},\n",
  "    {\"term\": \"first_stage\", \"estimate\": ", f(fs), ", \"se\": ", f(fs_se), ", \"n_obs\": ", n, "}\n",
  "  ],\n",
  "  \"method_metadata\": {\"estimator\": \"fuzzy RD, local linear, triangular kernel, bandwidth 1, separate slopes, ratio of discontinuities (delta method)\", \"vcov\": \"HC0 heteroskedasticity-robust, joint covariance across outcomes\"},\n",
  "  \"diagnostics\": {}\n",
  "}\n"
)
writeLines(json, "result.json")
