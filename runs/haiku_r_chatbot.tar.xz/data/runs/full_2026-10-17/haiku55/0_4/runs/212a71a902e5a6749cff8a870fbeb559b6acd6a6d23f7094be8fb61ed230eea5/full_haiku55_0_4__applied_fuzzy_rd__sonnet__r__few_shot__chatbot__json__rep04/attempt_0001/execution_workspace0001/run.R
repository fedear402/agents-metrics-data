library(jsonlite)

d <- read.csv("input.csv")
h <- 1
d <- d[abs(d$score) < h, ]
n_obs <- nrow(d)
w <- 1 - abs(d$score)
right <- d$score >= 0

hc0_fit <- function(y, x, w, right) {
  X <- cbind(1, right, x, right * x)
  XtWX_inv <- solve(crossprod(X, w * X))
  beta <- XtWX_inv %*% crossprod(X, w * y)
  e <- drop(y - X %*% beta)
  meat <- crossprod(X * (w * e))
  V <- XtWX_inv %*% meat %*% XtWX_inv
  list(beta = beta, V = V, e = e, X = X, A = XtWX_inv, w = w)
}

fit_y <- hc0_fit(d$earnings, d$score, w, right)
fit_t <- hc0_fit(d$participated, d$score, w, right)

rf <- fit_y$beta[2]
fs <- fit_t$beta[2]

# Influence contributions for the discontinuity (coefficient on right)
infl <- function(fit) {
  loading <- fit$w * drop(fit$X %*% fit$A %*% c(0, 1, 0, 0))
  loading * fit$e
}
iy <- infl(fit_y)
it <- infl(fit_t)
J <- crossprod(cbind(iy, it))

te <- rf / fs
g <- c(1 / fs, -rf / fs^2)
te_se <- sqrt(drop(t(g) %*% J %*% g))

rf_se <- sqrt(J[1, 1])
fs_se <- sqrt(J[2, 2])

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = unname(as.numeric(te)),
         se = unname(as.numeric(te_se)), n_obs = as.integer(n_obs)),
    list(term = "reduced_form", estimate = unname(as.numeric(rf)),
         se = unname(as.numeric(rf_se)), n_obs = as.integer(n_obs)),
    list(term = "first_stage", estimate = unname(as.numeric(fs)),
         se = unname(as.numeric(fs_se)), n_obs = as.integer(n_obs))
  ),
  method_metadata = list(
    estimator = "fuzzy RD, local linear, triangular kernel, bandwidth 1, separate slopes, delta method",
    vcov = "HC0"
  ),
  diagnostics = setNames(list(), character(0))
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
