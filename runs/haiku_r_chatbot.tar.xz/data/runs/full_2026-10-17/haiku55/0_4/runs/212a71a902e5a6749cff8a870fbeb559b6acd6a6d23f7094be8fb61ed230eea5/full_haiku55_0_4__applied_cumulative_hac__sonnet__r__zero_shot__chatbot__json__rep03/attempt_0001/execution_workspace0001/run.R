suppressPackageStartupMessages({
  library(sandwich)
  library(jsonlite)
})

L <- 15

d <- read.csv("input.csv", stringsAsFactors = FALSE)
d$date <- as.Date(d$date)
d <- d[order(d$date), ]
d$ls <- log(d$sales)
d$dv <- c(NA, diff(log(d$vix)))

lag_names <- paste0("l", 1:L)
for (k in 1:L) {
  d[[lag_names[k]]] <- c(rep(NA, k), head(d$dv, -k))
}

dd <- d[complete.cases(d[, c("ls", lag_names)]), ]
N <- nrow(dd)

fit <- lm(reformulate(lag_names, response = "ls"), data = dd)

V_nw <- NeweyWest(fit, lag = L, prewhiten = FALSE, adjust = FALSE)
V <- V_nw * N / (N - (L + 1))

b <- coef(fit)

cvec <- c(0, rep(1, L))
cum_est <- sum(b[lag_names])
cum_se <- sqrt(as.numeric(t(cvec) %*% V %*% cvec))

lag1_est <- unname(b["l1"])
lag1_se <- sqrt(V["l1", "l1"])

lag15_est <- unname(b["l15"])
lag15_se <- sqrt(V["l15", "l15"])

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(term = "cumulative_response", estimate = unname(cum_est), se = unname(cum_se), n_obs = N),
    list(term = "lag_1", estimate = lag1_est, se = unname(lag1_se), n_obs = N),
    list(term = "lag_15", estimate = lag15_est, se = unname(lag15_se), n_obs = N)
  ),
  method_metadata = list(
    estimator = "OLS of log(sales) on intercept and 15 lags of dlog(vix), trading-observation lags",
    vcov = "Newey-West HAC, max lag 15, Bartlett weights 1-j/16, scaled by N/(N-16)"
  ),
  diagnostics = setNames(list(), character(0))
)

writeLines(toJSON(result, auto_unbox = TRUE, digits = NA, pretty = TRUE), "result.json")
