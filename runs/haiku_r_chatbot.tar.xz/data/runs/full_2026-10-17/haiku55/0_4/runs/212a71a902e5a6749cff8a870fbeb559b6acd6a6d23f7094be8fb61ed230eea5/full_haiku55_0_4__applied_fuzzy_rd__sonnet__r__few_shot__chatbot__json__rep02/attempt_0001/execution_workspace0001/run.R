library(jsonlite)

d <- read.csv("input.csv")
d <- d[abs(d$score) < 1, ]
n <- nrow(d)
w <- 1 - abs(d$score)
right <- as.numeric(d$score >= 0)
left <- 1 - right
s <- d$score

X <- cbind(right, left, right * s, left * s)
B <- solve(crossprod(X, w * X))

fit_outcome <- function(y) {
  beta <- B %*% crossprod(X, w * y)
  e <- y - X %*% beta
  U <- (X * (w * e)) %*% t(B)
  list(beta = beta, U = U)
}

fy <- fit_outcome(d$earnings)
ft <- fit_outcome(d$participated)

contrast <- c(1, -1, 0, 0)
rf <- as.numeric(t(contrast) %*% fy$beta)
fs <- as.numeric(t(contrast) %*% ft$beta)

infl <- cbind(fy$U %*% contrast, ft$U %*% contrast)
J <- crossprod(infl)

tau <- rf / fs
g <- c(1 / fs, -rf / fs^2)
se_tau <- sqrt(as.numeric(t(g) %*% J %*% g))
se_rf <- sqrt(J[1, 1])
se_fs <- sqrt(J[2, 2])

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = unname(tau), se = unname(se_tau), n_obs = as.integer(n)),
    list(term = "reduced_form", estimate = unname(rf), se = unname(se_rf), n_obs = as.integer(n)),
    list(term = "first_stage", estimate = unname(fs), se = unname(se_fs), n_obs = as.integer(n))
  ),
  method_metadata = list(
    estimator = "Fuzzy RD, local linear with separate slopes, triangular kernel, bandwidth 1, Wald ratio",
    vcov = "HC0 sandwich, weighted, delta method for ratio"
  ),
  diagnostics = list(
    n_left = as.integer(sum(left)),
    n_right = as.integer(sum(right)),
    bandwidth = 1
  )
)

write_json(result, "result.json", auto_unbox = TRUE, digits = 16, pretty = TRUE)
