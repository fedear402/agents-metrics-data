library(jsonlite)

d <- read.csv("input.csv", stringsAsFactors = FALSE)
d$date <- as.Date(d$date)
d <- d[order(d$date), ]

d$dvix <- c(NA, diff(log(d$vix)))
L <- 15
for (k in seq_len(L)) {
  d[[paste0("lag_", k)]] <- c(rep(NA, k), head(d$dvix, -k))
}

lag_cols <- paste0("lag_", seq_len(L))
sample <- d[complete.cases(d[, c("sales", lag_cols)]), ]

sample$log_sales <- log(sample$sales)
fit <- lm(reformulate(lag_cols, response = "log_sales"), data = sample)

X <- model.matrix(fit)
b <- coef(fit)
N <- nrow(X)
p <- ncol(X)
u <- residuals(fit)
scores <- X * u

max_lag <- 15
meat <- crossprod(scores)
for (j in seq_len(max_lag)) {
  w <- 1 - j / (max_lag + 1)
  gamma <- crossprod(scores[(j + 1):N, , drop = FALSE], scores[1:(N - j), , drop = FALSE])
  meat <- meat + w * (gamma + t(gamma))
}

bread <- solve(crossprod(X))
V <- N / (N - p) * bread %*% meat %*% bread

contrast <- c(0, rep(1, L))
cumulative <- sum(contrast * b)
cumulative_se <- sqrt(drop(t(contrast) %*% V %*% contrast))

est <- list(
  list(term = "cumulative_response", estimate = unname(as.numeric(cumulative)),
       se = unname(as.numeric(cumulative_se)), n_obs = as.integer(N)),
  list(term = "lag_1", estimate = unname(as.numeric(b["lag_1"])),
       se = unname(sqrt(V["lag_1", "lag_1"])), n_obs = as.integer(N)),
  list(term = "lag_15", estimate = unname(as.numeric(b["lag_15"])),
       se = unname(sqrt(V["lag_15", "lag_15"])), n_obs = as.integer(N))
)

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = est,
  method_metadata = list(
    estimator = "OLS regression of log(sales) on intercept and 15 lags of first difference of log(vix)",
    vcov = "Newey-West HAC, max lag 15, Bartlett weights 1-j/16, scaled by N/(N-16)"
  ),
  diagnostics = setNames(list(), character(0))
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
