library(jsonlite)

d <- read.csv("input.csv", stringsAsFactors = FALSE)
d$date <- as.Date(d$date)
d <- d[order(d$date), ]

n <- nrow(d)
dl_vix <- c(NA_real_, diff(log(d$vix)))
log_sales <- log(d$sales)

L <- 15
lagmat <- matrix(NA_real_, nrow = n, ncol = L)
for (k in seq_len(L)) {
  lagmat[, k] <- c(rep(NA_real_, k), dl_vix[seq_len(n - k)])
}
colnames(lagmat) <- paste0("lag_", seq_len(L))

keep <- complete.cases(log_sales, lagmat)
y <- log_sales[keep]
X <- cbind(1, lagmat[keep, , drop = FALSE])
N <- length(y)
p <- ncol(X)

beta <- drop(solve(crossprod(X), crossprod(X, y)))
resid_vec <- y - drop(X %*% beta)
scores <- X * resid_vec

S <- crossprod(scores)
for (j in seq_len(L)) {
  w <- 1 - j / (L + 1)
  G <- crossprod(scores[(j + 1):N, , drop = FALSE], scores[1:(N - j), , drop = FALSE])
  S <- S + w * (G + t(G))
}

bread <- solve(crossprod(X))
V <- (N / (N - p)) * bread %*% S %*% bread

contrast <- c(0, rep(1, L))
cumulative <- sum(contrast * beta)
cumulative_se <- sqrt(drop(t(contrast) %*% V %*% contrast))

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(term = "cumulative_response", estimate = as.numeric(cumulative),
         se = as.numeric(cumulative_se), n_obs = as.integer(N)),
    list(term = "lag_1", estimate = as.numeric(beta[2]),
         se = as.numeric(sqrt(V[2, 2])), n_obs = as.integer(N)),
    list(term = "lag_15", estimate = as.numeric(beta[L + 1]),
         se = as.numeric(sqrt(V[L + 1, L + 1])), n_obs = as.integer(N))
  ),
  method_metadata = list(
    estimator = "OLS regression of log(sales) on intercept and 15 lags of log(vix) first differences",
    vcov = "Newey-West HAC, max lag 15, Bartlett weights 1-j/16, scaled by N/(N-16)"
  ),
  diagnostics = list(
    regression_lags = L,
    hac_max_lag = L,
    parameter_count = p,
    usable_sample_size = N
  )
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null",
           digits = 16, pretty = TRUE)
