suppressPackageStartupMessages({
  library(jsonlite)
})

dat <- read.csv("./input.csv", stringsAsFactors = FALSE)
dat$group <- factor(dat$group)
dat <- dat[is.finite(dat$y) & !is.na(dat$group), ]

fit <- aov(y ~ group, data = dat)
tab <- summary(fit)[[1]]

f_stat <- tab[["F value"]][1]
df_num <- tab[["Df"]][1]
df_den <- tab[["Df"]][2]
p_val  <- tab[["Pr(>F)"]][1]
n_obs  <- as.integer(nrow(dat))

result <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = list(
    list(term = "F",       estimate = as.numeric(f_stat), se = NULL, n_obs = n_obs),
    list(term = "df_num",  estimate = as.numeric(df_num), se = NULL, n_obs = n_obs),
    list(term = "df_den",  estimate = as.numeric(df_den), se = NULL, n_obs = n_obs),
    list(term = "p_value", estimate = as.numeric(p_val),  se = NULL, n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "one-way ANOVA (stats::aov, Type I sums of squares)",
    vcov = "none (classical residual variance)"
  ),
  diagnostics = setNames(list(), character(0))
)

write(toJSON(result, auto_unbox = TRUE, digits = NA, pretty = TRUE, null = "null"),
      file = "result.json")
