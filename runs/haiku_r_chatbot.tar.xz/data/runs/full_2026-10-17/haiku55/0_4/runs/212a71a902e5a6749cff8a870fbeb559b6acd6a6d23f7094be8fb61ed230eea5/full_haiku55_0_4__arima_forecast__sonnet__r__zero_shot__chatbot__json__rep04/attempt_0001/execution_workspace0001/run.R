library(jsonlite)

d <- read.csv("./input.csv")
d <- d[order(d$t), ]
train <- d[d$t < 251, ]
y <- ts(train$y)
n <- length(y)

fit <- arima(y, order = c(1, 1, 1), include.mean = FALSE, method = "ML")

fc <- predict(fit, n.ahead = 1)
f <- as.numeric(fc$pred)
s <- as.numeric(fc$se)
z <- qnorm(0.975)

lb <- Box.test(residuals(fit), lag = 10, type = "Ljung-Box", fitdf = 2)

out <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = list(
    list(term = "forecast", estimate = f, se = s, n_obs = n),
    list(term = "lower_95", estimate = f - z * s, se = NULL, n_obs = n),
    list(term = "upper_95", estimate = f + z * s, se = NULL, n_obs = n)
  ),
  method_metadata = list(
    estimator = "ARIMA(1,1,1) maximum likelihood via stats::arima, no constant or drift",
    vcov = "inverse observed information matrix (stats::arima default)"
  ),
  diagnostics = list(
    ar1 = unname(coef(fit)["ar1"]),
    ma1 = unname(coef(fit)["ma1"]),
    sigma2 = fit$sigma2,
    loglik = as.numeric(fit$loglik),
    aic = fit$aic,
    convergence_code = fit$code,
    ljung_box_lag10_pvalue = lb$p.value
  )
)

write_json(out, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE)
