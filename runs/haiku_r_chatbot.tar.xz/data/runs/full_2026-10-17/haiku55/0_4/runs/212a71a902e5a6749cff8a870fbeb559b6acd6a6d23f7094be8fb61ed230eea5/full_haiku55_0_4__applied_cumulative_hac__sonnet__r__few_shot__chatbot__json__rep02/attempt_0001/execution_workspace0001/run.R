library(jsonlite)

d <- read.csv("input.csv", stringsAsFactors = FALSE)
d$date <- as.Date(d$date)
d <- d[order(d$date), ]
d$dvix <- c(NA, diff(log(d$vix)))
d$log_sales <- log(d$sales)

L <- 15
for (k in 1:L) {
  d[[paste0("lag_", k)]] <- c(rep(NA, k), head(d$dvix, -k))
}

lag_cols <- paste0("lag_", 1:L)
sample <- d[complete.cases(d[, c("log_sales", lag_cols)]), ]

fit <- lm(as.formula(paste("log_sales ~", paste(lag_cols, collapse = " + "))), data = sample)
X <- model.matrix(fit)
b <- coef(fit)
N <- nrow(X)
p <- ncol(X)

scores <- X * residuals(fit)
hac_lags <- L
meat <- crossprod(scores)
for (j in seq_len(hac_lags)) {
  w <- 1 - j / (hac_lags + 1)
  gamma <- crossprod(scores[(j + 1):N, , drop = FALSE], scores[1:(N - j), , drop = FALSE])
  meat <- meat + w * (gamma + t(gamma))
}

bread <- solve(crossprod(X))
V <- N / (N - p) * bread %*% meat %*% bread

contrast <- c(0, rep(1, L))
cum_est <- sum(contrast * b)
cum_se <- sqrt(drop(t(contrast) %*% V %*% contrast))

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(term = "cumulative_response", estimate = unname(as.numeric(cum_est)),
         se = unname(as.numeric(cum_se)), n_obs = as.integer(N)),
    list(term = "lag_1", estimate = unname(as.numeric(b[2])),
         se = unname(sqrt(V[2, 2])), n_obs = as.integer(N)),
    list(term = "lag_15", estimate = unname(as.numeric(b[1 + L])),
         se = unname(sqrt(V[1 + L, 1 + L])), n_obs = as.integer(N))
  ),
  method_metadata = list(
    estimator = "OLS",
    vcov = "Newey-West HAC, max lag 15, Bartlett weights, small-sample factor N/(N-16)"
  ),
  diagnostics = setNames(list(), character(0))
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
