library(jsonlite)

d <- read.csv("input.csv", stringsAsFactors = FALSE)

run_cohort <- function(c0) {
  w <- d[d$time >= c0 - 2 & d$time <= c0 + 2 &
         (d$g == c0 | d$g == 0 | d$g > c0 + 2), ]
  n_times <- tapply(w$time, w$id, function(t) length(unique(t)))
  keep_ids <- names(n_times)[n_times == 5]
  w <- w[as.character(w$id) %in% keep_ids, ]
  w$did <- as.numeric(w$g == c0 & w$time >= c0)
  n_treated <- length(unique(w$id[w$g == c0]))
  fit <- lm(y ~ did + factor(id) + factor(time), data = w)
  list(att = unname(coef(fit)["did"]), n_obs = nrow(w), n_treated = n_treated)
}

cohorts <- c(3, 5, 7)
res <- lapply(cohorts, run_cohort)
names(res) <- paste0("g", cohorts)

atts <- sapply(res, function(r) r$att)
wts <- sapply(res, function(r) r$n_treated)
n_rows <- sapply(res, function(r) r$n_obs)

att_weighted <- sum(wts * atts) / sum(wts)

fmt <- function(x) format(x, digits = 15)

result <- list(
  task_id = "broad_cohort_stack",
  platform = "r",
  estimates = list(
    list(term = "att_g3", estimate = fmt(atts[["g3"]]), se = NA_real_, n_obs = as.integer(n_rows[["g3"]])),
    list(term = "att_g5", estimate = fmt(atts[["g5"]]), se = NA_real_, n_obs = as.integer(n_rows[["g5"]])),
    list(term = "att_g7", estimate = fmt(atts[["g7"]]), se = NA_real_, n_obs = as.integer(n_rows[["g7"]])),
    list(term = "att_weighted", estimate = fmt(att_weighted), se = NA_real_, n_obs = as.integer(sum(n_rows)))
  ),
  method_metadata = setNames(list(), character(0)),
  diagnostics = setNames(list(), character(0))
)

write_json(result, "result.json", auto_unbox = TRUE, pretty = TRUE, na = "null")
