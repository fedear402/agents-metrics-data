# Fit ARIMA(1,1,1) with no constant by ML, forecast y at t = 251 in levels, and write result.json
d <- read.csv("./input.csv", stringsAsFactors = FALSE)
y <- as.numeric(d$y)
n_obs <- length(y)

fit <- arima(y, order = c(1, 1, 1), include.mean = FALSE, method = "ML")

h <- 251 - max(as.numeric(d$t))
if (h < 1) h <- 1
fc <- predict(fit, n.ahead = h)
# one-step-ahead at t = 251: if t = 251 is beyond the sample, the first forecast step corresponds to it
point <- as.numeric(fc$pred[1])
se <- as.numeric(fc$se[1])
z <- qnorm(0.975)
lower <- point - z * se
upper <- point + z * se

out <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = list(
    list(term = "forecast", estimate = point, se = se, n_obs = n_obs),
    list(term = "lower_95", estimate = lower, se = NULL, n_obs = n_obs),
    list(term = "upper_95", estimate = upper, se = NULL, n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "ARIMA(1,1,1) maximum likelihood, no constant (stats::arima)",
    vcov = "inverse Hessian of ML log-likelihood (stats::arima)"
  ),
  diagnostics = list(
    coefficients = as.list(setNames(as.numeric(coef(fit)), names(coef(fit)))),
    sigma2 = fit$sigma2,
    loglik = fit$loglik,
    aic = fit$aic
  )
)

if (!requireNamespace("jsonlite", quietly = TRUE)) install.packages("jsonlite", repos = "https://cloud.r-project.org")
writeLines(jsonlite::toJSON(out, auto_unbox = TRUE, digits = NA, pretty = TRUE, null = "null"), "result.json")
