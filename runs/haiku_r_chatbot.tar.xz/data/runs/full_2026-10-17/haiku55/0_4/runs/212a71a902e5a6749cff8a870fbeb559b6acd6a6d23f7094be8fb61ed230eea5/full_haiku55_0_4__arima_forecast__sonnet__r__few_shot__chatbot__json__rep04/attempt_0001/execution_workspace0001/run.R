library(jsonlite)

df <- read.csv("./input.csv")
df <- df[order(df$t), ]
y <- df$y
n <- length(y)

fit <- arima(y, order = c(1, 1, 1), include.mean = FALSE, method = "ML")

h <- 251 - max(df$t)
p <- predict(fit, n.ahead = h)
fc <- as.numeric(p$pred[h])
se <- as.numeric(p$se[h])

out <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = list(
    list(term = "forecast", estimate = fc, se = se, n_obs = n),
    list(term = "lower_95", estimate = fc - 1.96 * se, se = NA_real_, n_obs = n),
    list(term = "upper_95", estimate = fc + 1.96 * se, se = NA_real_, n_obs = n)
  ),
  method_metadata = list(
    estimator = "ARIMA(1,1,1) by maximum likelihood, no constant",
    vcov = "ML (Hessian-based predictive variance)"
  ),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "result.json", auto_unbox = TRUE, digits = NA, na = "null", pretty = TRUE)
