library(jsonlite)

crosswalk <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
trade <- read.csv("trade.csv", stringsAsFactors = FALSE)
areas <- read.csv("areas.csv", stringsAsFactors = FALSE)
employment <- read.csv("employment.csv", stringsAsFactors = FALSE)
outcomes <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

iv <- function(y, C, x, z, w = rep(1, length(y))) {
  X <- cbind(C, x) * sqrt(w)
  Z <- cbind(C, z) * sqrt(w)
  fitted <- qr.fitted(qr(Z), X)
  as.numeric(qr.coef(qr(fitted), y * sqrt(w)))[ncol(X)]
}

tr <- merge(trade, crosswalk, by = "code")
inds <- sort(unique(tr$industry))

emp <- aggregate(employment ~ area + period + vintage + industry,
                 data = employment, FUN = sum)

cells <- expand.grid(area = unique(areas$area),
                     period = unique(areas$period),
                     vintage = c("base", "early"),
                     industry = inds,
                     stringsAsFactors = FALSE)
cells <- merge(cells, emp, by = c("area", "period", "vintage", "industry"), all.x = TRUE)
cells$employment[is.na(cells$employment)] <- 0

build <- function(vint, chg) {
  e <- cells[cells$vintage == vint, c("area", "period", "industry", "employment")]
  nat <- aggregate(employment ~ period + industry, data = e, FUN = sum)
  names(nat)[3] <- "nat"
  tot <- areas[areas$vintage == vint, c("area", "period", "total_employment")]
  m <- merge(e, nat, by = c("period", "industry"))
  m <- merge(m, tr[, c("period", "industry", chg, "price_index", "years")],
             by = c("period", "industry"))
  m <- merge(m, tot, by = c("area", "period"))
  m$term <- m$employment / m$total_employment * (m[[chg]] / m$nat) /
    (m$price_index / 100) / 1000 * (10 / m$years)
  agg <- aggregate(term ~ area + period, data = m, FUN = sum)
  names(agg)[3] <- "value"
  agg
}

x_df <- build("base", "us_change")
z_df <- build("early", "other_change")
pop <- areas[areas$vintage == "base", c("area", "period", "population")]

d <- merge(outcomes, x_df, by = c("area", "period"))
d <- merge(d, z_df, by = c("area", "period"), suffixes = c("_x", "_z"))
d <- merge(d, pop, by = c("area", "period"))
names(d)[names(d) == "value_x"] <- "x"
names(d)[names(d) == "value_z"] <- "z"
d <- d[order(d$area, d$period), ]

C <- cbind(1, as.numeric(d$period), as.numeric(d$control))
iv_slope <- iv(as.numeric(d$change_pp), C, d$x, d$z, as.numeric(d$population))

pick <- function(v, a, p) v[as.character(d$area) == a & as.character(d$period) == p]
n_obs <- as.integer(nrow(d))

res <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = list(
    list(term = "iv_slope", estimate = unname(iv_slope), se = NA, n_obs = n_obs),
    list(term = "exposure_area0_period0", estimate = unname(pick(d$x, "0", "0")), se = NA, n_obs = n_obs),
    list(term = "exposure_area0_period1", estimate = unname(pick(d$x, "0", "1")), se = NA, n_obs = n_obs),
    list(term = "instrument_area0_period0", estimate = unname(pick(d$z, "0", "0")), se = NA, n_obs = n_obs)
  ),
  method_metadata = list(
    method = "weighted 2SLS",
    outcome = "change_pp",
    endogenous = "x",
    instruments = c("intercept", "period", "control", "z"),
    exogenous_controls = c("intercept", "period", "control"),
    weight = "base-vintage population",
    exposure_definition = "sum_j(base or early employment share times national change over national base or early employment, deflated, scaled to thousands of real dollars per worker per decade)"
  ),
  diagnostics = list(
    n_area_period_obs = n_obs,
    n_industries = as.integer(length(inds)),
    n_areas = as.integer(length(unique(d$area))),
    n_periods = as.integer(length(unique(d$period)))
  )
)

write_json(res, "result.json", auto_unbox = TRUE, digits = 15, pretty = TRUE, na = "null")
