d <- read.csv("input.csv")
y <- as.integer(d$y)
X <- cbind(1, as.numeric(d$x), as.numeric(d$z))
n <- nrow(X)
Y <- cbind(as.numeric(y == 1), as.numeric(y == 2))

probs <- function(beta) {
  eta <- X %*% beta
  denom <- 1 + rowSums(exp(eta))
  P <- cbind(exp(eta[, 1]), exp(eta[, 2])) / denom
  list(P = P, P0 = 1 / denom)
}

hessian <- function(P) {
  H <- matrix(0, 6, 6)
  for (k in 1:2) for (l in 1:2) {
    w <- if (k == l) P[, k] * (1 - P[, k]) else -P[, k] * P[, l]
    H[(k - 1) * 3 + 1:3, (l - 1) * 3 + 1:3] <- -crossprod(X * w, X)
  }
  H
}

beta <- matrix(0, 3, 2)
iter <- 0
repeat {
  iter <- iter + 1
  pr <- probs(beta)
  G <- crossprod(X, Y - pr$P)
  H <- hessian(pr$P)
  step <- solve(H, as.vector(G))
  beta <- beta - matrix(step, 3, 2)
  if (max(abs(step)) < 1e-10 || iter >= 100) break
}

pr <- probs(beta)
H <- hessian(pr$P)
ll <- sum(log(ifelse(y == 0, pr$P0, ifelse(y == 1, pr$P[, 1], pr$P[, 2]))))
vcov_mat <- solve(-H)
se <- sqrt(diag(vcov_mat))

p2_zero <- exp(beta[1, 2]) / (1 + exp(beta[1, 1]) + exp(beta[1, 2]))

fmtnum <- function(v) if (is.na(v)) "null" else sprintf("%.15g", v)

rows <- c(
  sprintf('{"term": "x_cat1", "estimate": %s, "se": %s, "n_obs": %d}', fmtnum(beta[2, 1]), fmtnum(se[2]), n),
  sprintf('{"term": "z_cat1", "estimate": %s, "se": %s, "n_obs": %d}', fmtnum(beta[3, 1]), fmtnum(se[3]), n),
  sprintf('{"term": "x_cat2", "estimate": %s, "se": %s, "n_obs": %d}', fmtnum(beta[2, 2]), fmtnum(se[5]), n),
  sprintf('{"term": "z_cat2", "estimate": %s, "se": %s, "n_obs": %d}', fmtnum(beta[3, 2]), fmtnum(se[6]), n),
  sprintf('{"term": "prob_cat2_zero", "estimate": %s, "se": null, "n_obs": %d}', fmtnum(p2_zero), n)
)

json <- paste0(
  '{\n',
  '  "task_id": "broad_multinomial_logit",\n',
  '  "platform": "r",\n',
  '  "estimates": [\n    ',
  paste(rows, collapse = ",\n    "),
  '\n  ],\n',
  '  "method_metadata": {"estimator": "multinomial logit (maximum likelihood, base outcome 0)", "vcov": "observed information (inverse of negative Hessian)"},\n',
  '  "diagnostics": {"log_likelihood": ', fmtnum(ll), ', "iterations": ', iter, ', "n_obs": ', n, '}\n',
  '}\n'
)

writeLines(json, "result.json")
