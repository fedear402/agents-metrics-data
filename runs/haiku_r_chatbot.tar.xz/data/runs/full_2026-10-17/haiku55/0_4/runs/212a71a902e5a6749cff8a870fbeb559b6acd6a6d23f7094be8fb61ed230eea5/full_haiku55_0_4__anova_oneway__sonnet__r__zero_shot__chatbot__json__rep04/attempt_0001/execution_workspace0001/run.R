df <- read.csv("./input.csv", stringsAsFactors = FALSE)
df$group <- factor(df$group)
fit <- aov(y ~ group, data = df)
s <- summary(fit)[[1]]
F_stat <- s[["F value"]][1]
df_num <- s[["Df"]][1]
df_den <- s[["Df"]][2]
p_val <- s[["Pr(>F)"]][1]
n <- nrow(df)
res <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = list(
    list(term = "F", estimate = as.numeric(F_stat), se = NULL, n_obs = as.integer(n)),
    list(term = "df_num", estimate = as.numeric(df_num), se = NULL, n_obs = as.integer(n)),
    list(term = "df_den", estimate = as.numeric(df_den), se = NULL, n_obs = as.integer(n)),
    list(term = "p_value", estimate = as.numeric(p_val), se = NULL, n_obs = as.integer(n))
  ),
  method_metadata = list(estimator = "one-way ANOVA (aov)", vcov = "none"),
  diagnostics = setNames(list(), character(0))
)
if (requireNamespace("jsonlite", quietly = TRUE)) {
  json <- jsonlite::toJSON(res, auto_unbox = TRUE, digits = NA, null = "null", pretty = TRUE)
} else {
  stop("jsonlite package is required")
}
writeLines(as.character(json), "result.json")
