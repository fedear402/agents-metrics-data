df <- read.csv("./input.csv", stringsAsFactors = FALSE)
df$group <- as.factor(df$group)
df <- df[complete.cases(df[, c("group", "y")]), ]

fit <- aov(y ~ group, data = df)
tab <- summary(fit)[[1]]

F_stat  <- tab[["F value"]][1]
df_num  <- tab[["Df"]][1]
df_den  <- tab[["Df"]][2]
p_val   <- tab[["Pr(>F)"]][1]
n_obs   <- nrow(df)

out <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = list(
    list(term = "F",       estimate = as.numeric(F_stat), se = NULL, n_obs = as.integer(n_obs)),
    list(term = "df_num",  estimate = as.numeric(df_num), se = NULL, n_obs = as.integer(n_obs)),
    list(term = "df_den",  estimate = as.numeric(df_den), se = NULL, n_obs = as.integer(n_obs)),
    list(term = "p_value", estimate = as.numeric(p_val),  se = NULL, n_obs = as.integer(n_obs))
  ),
  method_metadata = list(
    estimator = "one-way ANOVA (stats::aov, y ~ group)",
    vcov = "classical (homoskedastic residual variance)"
  ),
  diagnostics = setNames(list(), character(0))
)

if (requireNamespace("jsonlite", quietly = TRUE)) {
  json <- jsonlite::toJSON(out, auto_unbox = TRUE, digits = NA, null = "null", pretty = TRUE)
} else {
  stop("jsonlite package is required to write result.json")
}
writeLines(json, "result.json")
