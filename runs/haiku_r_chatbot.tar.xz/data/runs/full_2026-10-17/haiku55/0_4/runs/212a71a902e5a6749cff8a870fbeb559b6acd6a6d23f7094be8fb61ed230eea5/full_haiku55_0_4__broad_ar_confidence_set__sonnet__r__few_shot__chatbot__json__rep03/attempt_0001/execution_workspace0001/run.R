suppressPackageStartupMessages(library(jsonlite))

d <- read.csv("input.csv")
n <- nrow(d)
q <- 2L
df <- n - 4L
critical <- qf(0.95, q, df)
k <- q * critical / df

rW_y <- residuals(lm(y ~ x, data = d))
rW_e <- residuals(lm(endog ~ x, data = d))
rU_y <- residuals(lm(y ~ x + z1 + z2, data = d))
rU_e <- residuals(lm(endog ~ x + z1 + z2, data = d))

Ruu <- sum(rW_y^2); Ruv <- sum(rW_y * rW_e); Rvv <- sum(rW_e^2)
Uuu <- sum(rU_y^2); Uuv <- sum(rU_y * rU_e); Uvv <- sum(rU_e^2)

A <- Rvv - (1 + k) * Uvv
B <- -2 * (Ruv - (1 + k) * Uuv)
C <- Ruu - (1 + k) * Uuu

disc <- B^2 - 4 * A * C
if (A != 0 && disc >= 0) {
  roots <- sort((-B + c(-1, 1) * sqrt(disc)) / (2 * A))
} else if (A == 0 && B != 0) {
  roots <- -C / B
} else {
  roots <- numeric(0)
}

boundary_low <- if (length(roots) >= 1) roots[1] else NA_real_
boundary_high <- if (length(roots) >= 2) roots[2] else NA_real_

accepts_zero <- as.integer(C <= 0)
unbounded <- as.integer(A < 0 || (A == 0 && B != 0) || (A == 0 && B == 0 && C <= 0))

t1 <- d$y - d$endog
ssr_r1 <- sum(residuals(lm(t1 ~ x, data = d))^2)
ssr_u1 <- sum(residuals(lm(t1 ~ x + z1 + z2, data = d))^2)
ar_f_at_one <- ((ssr_r1 - ssr_u1) / q) / (ssr_u1 / df)

out <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = list(
    list(term = "boundary_low", estimate = unname(boundary_low), se = NULL, n_obs = as.integer(n)),
    list(term = "boundary_high", estimate = unname(boundary_high), se = NULL, n_obs = as.integer(n)),
    list(term = "accepts_zero", estimate = accepts_zero, se = NULL, n_obs = as.integer(n)),
    list(term = "unbounded", estimate = unbounded, se = NULL, n_obs = as.integer(n)),
    list(term = "ar_f_at_one", estimate = unname(ar_f_at_one), se = NULL, n_obs = as.integer(n))
  ),
  method_metadata = list(
    estimator = "Anderson-Rubin confidence set by inverting homoskedastic joint F test of excluded instruments z1, z2",
    vcov = "homoskedastic"
  ),
  diagnostics = list(
    quadratic_A = A,
    quadratic_B = B,
    quadratic_C = C,
    discriminant = disc,
    critical_value = critical,
    numerator_df = q,
    denominator_df = df
  )
)

write_json(out, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
