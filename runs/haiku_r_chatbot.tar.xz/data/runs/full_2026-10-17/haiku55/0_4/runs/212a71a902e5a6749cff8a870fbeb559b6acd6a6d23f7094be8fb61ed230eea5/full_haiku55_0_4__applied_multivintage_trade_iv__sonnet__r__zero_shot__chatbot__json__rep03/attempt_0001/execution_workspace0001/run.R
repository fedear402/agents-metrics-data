library(jsonlite)

rd <- function(f) read.csv(f, stringsAsFactors = FALSE, strip.white = TRUE)
crosswalk <- rd("crosswalk.csv")
trade <- rd("trade.csv")
areas <- rd("areas.csv")
employment <- rd("employment.csv")
outcomes <- rd("outcomes.csv")

crosswalk$code <- as.character(crosswalk$code)
trade$code <- as.character(trade$code)
trade_x <- merge(trade, crosswalk, by = "code")

areas$area <- as.character(areas$area)
areas$vintage <- as.character(areas$vintage)
employment$area <- as.character(employment$area)
employment$vintage <- as.character(employment$vintage)
employment$industry <- as.character(employment$industry)
outcomes$area <- as.character(outcomes$area)
trade_x$industry <- as.character(trade_x$industry)

industries <- sort(unique(trade_x$industry))
periods <- sort(unique(areas$period))
area_ids <- sort(unique(areas$area))

grid <- expand.grid(
  area = area_ids,
  period = periods,
  vintage = c("base", "early"),
  industry = industries,
  stringsAsFactors = FALSE
)
emp <- merge(
  grid,
  employment[, c("area", "period", "vintage", "industry", "employment")],
  by = c("area", "period", "vintage", "industry"),
  all.x = TRUE
)
emp$employment[is.na(emp$employment)] <- 0

key <- c("area", "period", "industry")
b <- emp[emp$vintage == "base", c(key, "employment")]
names(b)[4] <- "base_emp"
e <- emp[emp$vintage == "early", c(key, "employment")]
names(e)[4] <- "early_emp"
cell <- merge(b, e, by = key)

tb <- areas[areas$vintage == "base", c("area", "period", "total_employment")]
names(tb)[3] <- "base_tot"
te <- areas[areas$vintage == "early", c("area", "period", "total_employment")]
names(te)[3] <- "early_tot"
cell <- merge(cell, tb, by = c("area", "period"))
cell <- merge(cell, te, by = c("area", "period"))

nb <- aggregate(base_emp ~ period + industry, data = cell, FUN = sum)
names(nb)[3] <- "nat_base"
ne <- aggregate(early_emp ~ period + industry, data = cell, FUN = sum)
names(ne)[3] <- "nat_early"
cell <- merge(cell, nb, by = c("period", "industry"))
cell <- merge(cell, ne, by = c("period", "industry"))

tr <- trade_x[, c("period", "industry", "us_change", "other_change", "price_index", "years")]
cell <- merge(cell, tr, by = c("period", "industry"))

cell$x_term <- (cell$base_emp / cell$base_tot) *
  (cell$us_change / cell$nat_base) /
  (cell$price_index / 100) / 1000 * (10 / cell$years)
cell$z_term <- (cell$early_emp / cell$early_tot) *
  (cell$other_change / cell$nat_early) /
  (cell$price_index / 100) / 1000 * (10 / cell$years)

xa <- aggregate(x_term ~ area + period, data = cell, FUN = sum)
names(xa)[3] <- "x"
za <- aggregate(z_term ~ area + period, data = cell, FUN = sum)
names(za)[3] <- "z"

pop <- areas[areas$vintage == "base", c("area", "period", "population")]
dat <- merge(outcomes, xa, by = c("area", "period"))
dat <- merge(dat, za, by = c("area", "period"))
dat <- merge(dat, pop, by = c("area", "period"))
dat <- dat[order(dat$area, dat$period), ]

n_obs <- as.integer(nrow(dat))

y <- dat$change_pp
w <- dat$population
X <- cbind(1, dat$period, dat$control, dat$x)
Z <- cbind(1, dat$period, dat$control, dat$z)

ZW <- t(Z * w)
A <- ZW %*% Z
B <- ZW %*% X
zy <- ZW %*% y
Ainv <- solve(A)
beta <- solve(t(B) %*% Ainv %*% B, t(B) %*% Ainv %*% zy)
iv_slope <- unname(beta[4, 1])

is_a0 <- as.character(dat$area) == "0"
exposure_area0_period0 <- dat$x[is_a0 & dat$period == 0]
exposure_area0_period1 <- dat$x[is_a0 & dat$period == 1]
instrument_area0_period0 <- dat$z[is_a0 & dat$period == 0]

estimates <- list(
  list(term = "iv_slope", estimate = iv_slope, se = NA_real_, n_obs = n_obs),
  list(term = "exposure_area0_period0", estimate = exposure_area0_period0, se = NA_real_, n_obs = n_obs),
  list(term = "exposure_area0_period1", estimate = exposure_area0_period1, se = NA_real_, n_obs = n_obs),
  list(term = "instrument_area0_period0", estimate = instrument_area0_period0, se = NA_real_, n_obs = n_obs)
)

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    method = "weighted_2sls",
    dependent = "change_pp",
    endogenous = "x",
    instruments = "z",
    exogenous = c("intercept", "period", "control"),
    weight = "base_vintage_population",
    n_industries = length(industries),
    periods = periods
  ),
  diagnostics = list(
    n_obs = n_obs,
    n_areas = length(area_ids),
    n_periods = length(periods),
    n_instruments = 4L
  )
)

write_json(result, "result.json", auto_unbox = TRUE, pretty = TRUE, digits = NA, na = "null")
