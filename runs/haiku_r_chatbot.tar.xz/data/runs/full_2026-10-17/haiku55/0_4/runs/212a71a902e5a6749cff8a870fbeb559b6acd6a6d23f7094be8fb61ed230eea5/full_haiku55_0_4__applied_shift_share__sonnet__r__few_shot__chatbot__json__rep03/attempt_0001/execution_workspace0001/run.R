library(jsonlite)

dat <- read.csv("input.csv", stringsAsFactors = FALSE)

reg_first <- dat[!duplicated(dat$region_id), c("region_id", "region_weight", "x", "y")]
reg_first <- reg_first[order(reg_first$region_id), ]
rownames(reg_first) <- NULL

zr <- tapply(dat$share * dat$shock, dat$region_id, sum)
z <- as.numeric(zr[as.character(reg_first$region_id)])

e <- reg_first$region_weight / sum(reg_first$region_weight)
wm <- function(v) sum(e * v)

x <- reg_first$x
y <- reg_first$y
y0 <- y - wm(y)
x0 <- x - wm(x)
z0 <- z - wm(z)

idx <- match(dat$region_id, reg_first$region_id)
e_long <- e[idx]
y0_long <- y0[idx]
x0_long <- x0[idx]
z0_long <- z0[idx]

ind <- sort(unique(dat$industry_id))
N <- length(ind)

s <- sapply(ind, function(k) {
  m <- dat$industry_id == k
  sum(e_long[m] * dat$share[m])
})

agg <- function(v) {
  sapply(ind, function(k) {
    m <- dat$industry_id == k
    sum(e_long[m] * dat$share[m] * v[m])
  }) / s
}

ybar <- agg(y0_long)
xbar <- agg(x0_long)
zbar <- agg(z0_long)
shock_n <- sapply(ind, function(k) dat$shock[dat$industry_id == k][1])

shock_iv <- function(dep, endo, inst, w) {
  X <- cbind(1, endo)
  Z <- cbind(1, inst)
  n <- length(dep)
  cross <- crossprod(Z, w * X)
  beta <- solve(cross, crossprod(Z, w * dep))
  resid <- drop(dep - X %*% beta)
  scores <- Z * (w * resid)
  inv <- solve(cross)
  V <- n / (n - 2) * inv %*% crossprod(scores) %*% t(inv)
  c(slope = beta[2], se = sqrt(V[2, 2]))
}

effect <- shock_iv(ybar, xbar, shock_n, s)
fs <- shock_iv(xbar, zbar, shock_n, s)
eff_shocks <- 1 / sum(s^2)

res <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = unname(effect["slope"]),
         se = unname(effect["se"]), n_obs = as.integer(N)),
    list(term = "first_stage", estimate = unname(fs["slope"]),
         se = unname(fs["se"]), n_obs = as.integer(N)),
    list(term = "effective_shocks", estimate = eff_shocks,
         se = NA_real_, n_obs = as.integer(N))
  ),
  method_metadata = list(
    estimator = "Weighted 2SLS shift-share with Borusyak-Hull-Jaravel shock-level aggregation",
    vcov = "Shock-level HC1 robust variance (N/(N-2) multiplier), structural IV residuals, analytic weights, no clustering"
  ),
  diagnostics = list(
    n_regions = length(e),
    n_industries = as.integer(N)
  )
)

write_json(res, "result.json", auto_unbox = TRUE, digits = 16,
           pretty = TRUE, na = "null", null = "null")
