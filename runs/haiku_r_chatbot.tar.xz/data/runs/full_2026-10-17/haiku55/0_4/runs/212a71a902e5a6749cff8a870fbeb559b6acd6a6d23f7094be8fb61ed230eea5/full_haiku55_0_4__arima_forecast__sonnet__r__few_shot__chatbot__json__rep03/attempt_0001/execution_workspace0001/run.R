library(jsonlite)
df <- read.csv("./input.csv")
y <- as.numeric(df$y)
n <- length(y)
fit <- arima(y, order = c(1, 1, 1), include.mean = FALSE, method = "ML")
fc <- predict(fit, n.ahead = 1)
pred <- as.numeric(fc$pred)
se <- as.numeric(fc$se)
# Forecast of y_t (levels) from the differenced ARIMA(1,1,1) with no drift
# Interval uses level-scale prediction standard error from predict()
lower <- pred - qnorm(0.975) * se
upper <- pred + qnorm(0.975) * se
out <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = list(
    list(term = "forecast", estimate = pred, se = se, n_obs = n),
    list(term = "lower_95", estimate = lower, se = NA, n_obs = n),
    list(term = "upper_95", estimate = upper, se = NA, n_obs = n)
  ),
  method_metadata = list(
    estimator = "ARIMA(1,1,1) by maximum likelihood, no constant",
    vcov = "ML information matrix"
  ),
  diagnostics = structure(list(), names = character(0))
)
write_json(out, "result.json", auto_unbox = TRUE, digits = NA)
