library(jsonlite)
df <- read.csv("./input.csv", stringsAsFactors = FALSE)
df$group <- factor(df$group)
fit <- aov(y ~ group, data = df)
s <- summary(fit)[[1]]
F_stat <- s[["F value"]][1]
df_num <- s[["Df"]][1]
df_den <- s[["Df"]][2]
p_val <- s[["Pr(>F)"]][1]
n <- nrow(df)
out <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = list(
    list(term = "F", estimate = unname(F_stat), se = NULL, n_obs = n),
    list(term = "df_num", estimate = unname(df_num), se = NULL, n_obs = n),
    list(term = "df_den", estimate = unname(df_den), se = NULL, n_obs = n),
    list(term = "p_value", estimate = unname(p_val), se = NULL, n_obs = n)
  ),
  method_metadata = list(estimator = "One-way ANOVA (aov, F test of group effect)",
                         vcov = "none"),
  diagnostics = structure(list(), names = character(0))
)
write_json(out, "result.json", auto_unbox = TRUE, digits = NA, null = "null")
