suppressMessages({
  if (!requireNamespace("jsonlite", quietly = TRUE)) install.packages("jsonlite", repos = "https://cloud.r-project.org")
})
library(jsonlite)

d <- read.csv("./input.csv", stringsAsFactors = FALSE)
y <- as.numeric(d$y)
n_obs <- length(y)

fit <- arima(y, order = c(1, 1, 1), include.mean = FALSE, method = "ML")

fc <- predict(fit, n.ahead = 1)
pred <- as.numeric(fc$pred[1])
se_pred <- as.numeric(fc$se[1])

lower <- pred - qnorm(0.975) * se_pred
upper <- pred + qnorm(0.975) * se_pred

ljung <- Box.test(residuals(fit), lag = 10, type = "Ljung-Box", fitdf = 2)

out <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = list(
    list(term = "forecast", estimate = pred, se = se_pred, n_obs = n_obs),
    list(term = "lower_95", estimate = lower, se = NULL, n_obs = n_obs),
    list(term = "upper_95", estimate = upper, se = NULL, n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "ARIMA(1,1,1) maximum likelihood, no constant (stats::arima)",
    vcov = "inverse Hessian of ARIMA log-likelihood"
  ),
  diagnostics = list(
    coefficients = as.list(setNames(as.numeric(coef(fit)), names(coef(fit)))),
    sigma2 = fit$sigma2,
    loglik = as.numeric(fit$loglik),
    aic = fit$aic,
    ljung_box_lag10_p = ljung$p.value
  )
)

write_json(out, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE, null = "null")
