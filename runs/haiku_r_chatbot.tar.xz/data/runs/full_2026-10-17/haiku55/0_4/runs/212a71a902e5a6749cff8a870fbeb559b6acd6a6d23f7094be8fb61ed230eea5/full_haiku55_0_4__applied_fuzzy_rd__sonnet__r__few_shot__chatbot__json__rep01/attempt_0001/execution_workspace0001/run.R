library(jsonlite)

d <- read.csv("input.csv")
d <- d[abs(d$score) < 1, , drop = FALSE]
w <- 1 - abs(d$score)
right <- d$score >= 0
left <- !right
n_obs <- nrow(d)

side_fit <- function(y, x, w) {
  X <- cbind(1, x)
  B <- solve(crossprod(X, w * X))
  beta <- B %*% crossprod(X, w * y)
  e <- y - X %*% beta
  infl <- w * e * drop(X %*% B[, 1])
  list(est = as.numeric(beta[1]), infl = infl)
}

fit_disc <- function(y) {
  fl <- side_fit(y[left], d$score[left], w[left])
  fr <- side_fit(y[right], d$score[right], w[right])
  infl <- numeric(length(y))
  infl[right] <- fr$infl
  infl[left] <- -fl$infl
  list(est = fr$est - fl$est, infl = infl)
}

rf <- fit_disc(d$earnings)
fs <- fit_disc(d$participated)

influence <- cbind(rf$infl, fs$infl)
V <- crossprod(influence)

rf_est <- rf$est
fs_est <- fs$est
tau <- rf_est / fs_est
g <- c(1 / fs_est, -rf_est / fs_est^2)
tau_se <- sqrt(drop(t(g) %*% V %*% g))

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = unname(tau),
         se = unname(tau_se), n_obs = as.integer(n_obs)),
    list(term = "reduced_form", estimate = unname(rf_est),
         se = unname(sqrt(V[1, 1])), n_obs = as.integer(n_obs)),
    list(term = "first_stage", estimate = unname(fs_est),
         se = unname(sqrt(V[2, 2])), n_obs = as.integer(n_obs))
  ),
  method_metadata = list(
    estimator = "fuzzy RD, local linear, triangular kernel, bandwidth 1, separate slopes per side",
    vcov = "HC0 sandwich, delta method for ratio"
  ),
  diagnostics = list(
    bandwidth = 1,
    cutoff = 0,
    n_left = as.integer(sum(left)),
    n_right = as.integer(sum(right)),
    covariance_reduced_form_first_stage = unname(V[1, 2])
  )
)

write_json(result, "result.json", auto_unbox = TRUE, digits = 16, pretty = TRUE, null = "null")
