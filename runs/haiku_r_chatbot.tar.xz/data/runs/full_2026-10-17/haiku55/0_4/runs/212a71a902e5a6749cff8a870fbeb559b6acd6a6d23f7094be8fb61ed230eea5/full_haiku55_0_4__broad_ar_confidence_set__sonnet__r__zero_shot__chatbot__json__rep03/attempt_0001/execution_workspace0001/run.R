d <- read.csv("input.csv")
n <- nrow(d)
W <- cbind(1, d$x)
qrW <- qr(W)
c95 <- qf(0.95, 2, n - 4)

ytil <- qr.resid(qrW, d$y)
etil <- qr.resid(qrW, d$endog)
Ztil <- qr.resid(qrW, cbind(d$z1, d$z2))
ZtZinv <- solve(crossprod(Ztil))

proj <- function(v) as.vector(Ztil %*% (ZtZinv %*% crossprod(Ztil, v)))

bil <- function(u, v) {
  Pu <- proj(u)
  (n - 4) * sum(Pu * v) - 2 * c95 * (sum(u * v) - sum(Pu * v))
}

a0 <- bil(ytil, ytil)
a1 <- bil(etil, ytil)
a2 <- bil(etil, etil)
disc <- a1^2 - a0 * a2

if (disc >= 0 && a2 != 0) {
  r <- sort((a1 + c(-1, 1) * sqrt(disc)) / a2)
  boundary_low <- r[1]
  boundary_high <- r[2]
} else {
  boundary_low <- NA_real_
  boundary_high <- NA_real_
}

accepts_zero <- as.integer(a0 <= 0)
unbounded <- as.integer(a2 < 0 || (a2 == 0 && a1 != 0))

y1 <- d$y - 1 * d$endog
rss1 <- sum(resid(lm(y1 ~ x + z1 + z2, data = d))^2)
rss0 <- sum(resid(lm(y1 ~ x, data = d))^2)
ar_f_at_one <- ((rss0 - rss1) / 2) / (rss1 / (n - 4))

est <- function(term, value) list(term = term, estimate = value, se = NA_real_, n_obs = as.integer(n))

out <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = list(
    est("boundary_low", boundary_low),
    est("boundary_high", boundary_high),
    est("accepts_zero", accepts_zero),
    est("unbounded", unbounded),
    est("ar_f_at_one", ar_f_at_one)
  ),
  method_metadata = list(
    estimator = "Anderson-Rubin test inversion with homoskedastic joint F test",
    vcov = "homoskedastic"
  ),
  diagnostics = setNames(list(), character(0))
)

jsonlite::write_json(out, "result.json", auto_unbox = TRUE, digits = NA, na = "null", pretty = TRUE)
