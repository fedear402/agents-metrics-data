import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("input.csv")
n_full = int(len(df))
d = df[["y", "x", "z"]].dropna().copy()
d["y"] = d["y"].astype(int)

X = sm.add_constant(d[["x", "z"]], has_constant="add")
model = sm.MNLogit(d["y"], X)
res = model.fit(method="newton", maxiter=200, disp=False)
if not res.mle_retvals.get("converged", True):
    res = model.fit(method="bfgs", maxiter=5000, disp=False)

params = res.params  # columns correspond to non-base outcomes sorted
bse = res.bse
cats = sorted(d["y"].unique())
# MNLogit uses the lowest category (0) as base; columns indexed 0..K-2
col_map = {c: i for i, c in enumerate([c for c in cats if c != cats[0]])}
c1 = params.columns[col_map[1]]
c2 = params.columns[col_map[2]]

def g(df_, col, term):
    return float(df_.loc[term, col])

# Fitted probability at x=0, z=0
x0 = pd.DataFrame({"const": [1.0], "x": [0.0], "z": [0.0]})
p0 = np.asarray(res.predict(x0))[0]
prob2 = float(p0[cats.index(2)])

est = []
for term, col, var in [("x_cat1", c1, "x"), ("z_cat1", c1, "z"),
                       ("x_cat2", c2, "x"), ("z_cat2", c2, "z")]:
    est.append({"term": term, "estimate": g(params, col, var),
                "se": g(bse, col, var), "n_obs": n_full})
est.append({"term": "prob_cat2_zero", "estimate": prob2, "se": None, "n_obs": n_full})

out = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": est,
    "method_metadata": {"estimator": "statsmodels MNLogit maximum likelihood, base outcome 0",
                        "vcov": "inverse observed information (Hessian)"},
    "diagnostics": {"converged": bool(res.mle_retvals.get("converged", True)),
                    "llf": float(res.llf), "n_used": int(res.nobs)},
}
with open("result.json", "w") as f:
    json.dump(out, f, indent=2)
