import json
import numpy as np
import pandas as pd
from scipy import stats

df = pd.read_csv("input.csv")
n = len(df)
y = df["y"].to_numpy(float)
d = df["endog"].to_numpy(float)
W = np.column_stack([np.ones(n), df["x"].to_numpy(float)])
Z = df[["z1", "z2"]].to_numpy(float)

def resid(A, v):
    coef, *_ = np.linalg.lstsq(A, v, rcond=None)
    return v - A @ coef

ry, rd = resid(W, y), resid(W, d)
rZ = resid(W, Z)
def proj(v):
    coef, *_ = np.linalg.lstsq(rZ, v, rcond=None)
    return rZ @ coef

dfd = n - 4
crit = stats.f.ppf(0.95, 2, dfd)

def F(b):
    e = ry - b * rd
    pe = proj(e)
    num = pe @ pe
    rss_u = e @ e - num
    return (num / 2) / (rss_u / dfd)

# Q(b) = e'Ke with K = (dfd/2) P - crit (I - P); accept iff Q(b) <= 0
def kform(u, v):
    pu = proj(u)
    return (dfd / 2) * (pu @ v) - crit * (u @ v - pu @ v)

k11, k12, k22 = kform(ry, ry), kform(ry, rd), kform(rd, rd)
a, bq, cq = k22, -2 * k12, k11
disc = bq * bq - 4 * a * cq
r = np.sqrt(disc)
roots = sorted([(-bq - r) / (2 * a), (-bq + r) / (2 * a)])
lo, hi = float(roots[0]), float(roots[1])
unbounded = 1 if a < 0 else 0
accepts_zero = 1 if F(0.0) <= crit else 0
f1 = float(F(1.0))

est = [
    {"term": "boundary_low", "estimate": lo, "se": None, "n_obs": n},
    {"term": "boundary_high", "estimate": hi, "se": None, "n_obs": n},
    {"term": "accepts_zero", "estimate": float(accepts_zero), "se": None, "n_obs": n},
    {"term": "unbounded", "estimate": float(unbounded), "se": None, "n_obs": n},
    {"term": "ar_f_at_one", "estimate": f1, "se": None, "n_obs": n},
]
out = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": est,
    "method_metadata": {"estimator": "Anderson-Rubin test inversion (analytic quadratic)",
                        "vcov": "homoskedastic"},
    "diagnostics": {"crit_F": float(crit), "quad_a": float(a), "quad_b": float(bq),
                    "quad_c": float(cq), "F_at_zero": float(F(0.0))},
}
with open("result.json", "w") as f:
    json.dump(out, f, indent=2)
