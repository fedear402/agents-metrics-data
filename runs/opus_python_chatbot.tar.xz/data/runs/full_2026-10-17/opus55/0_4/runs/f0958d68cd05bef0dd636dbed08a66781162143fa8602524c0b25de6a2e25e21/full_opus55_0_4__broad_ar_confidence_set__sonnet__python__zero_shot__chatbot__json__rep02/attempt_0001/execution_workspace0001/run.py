import json
import numpy as np
import pandas as pd
from scipy import stats

df = pd.read_csv("input.csv")
df = df[["y", "endog", "x", "z1", "z2"]].dropna()
n = len(df)
y = df["y"].to_numpy(float)
e = df["endog"].to_numpy(float)
W = np.column_stack([np.ones(n), df["x"].to_numpy(float)])
Zf = np.column_stack([W, df["z1"].to_numpy(float), df["z2"].to_numpy(float)])

def resid(X, v):
    b, *_ = np.linalg.lstsq(X, v, rcond=None)
    return v - X @ b

yr, er = resid(W, y), resid(W, e)      # restricted residuals
yu, eu = resid(Zf, y), resid(Zf, e)    # unrestricted residuals
dfd = n - 4
crit = stats.f.ppf(0.95, 2, dfd)

def quad(a1, a2, b1, b2):
    return a1 @ b1 - a2 @ b2

# RSS_r(b) - RSS_u(b) = D_yy - 2b D_ye + b^2 D_ee ; RSS_u(b) likewise with M
D_ee, D_ye, D_yy = quad(er, eu, er, eu), quad(yr, yu, er, eu), quad(yr, yu, yr, yu)
M_ee, M_ye, M_yy = eu @ eu, yu @ eu, yu @ yu

def ar_f(b):
    num = (D_yy - 2 * b * D_ye + b * b * D_ee) / 2
    den = (M_yy - 2 * b * M_ye + b * b * M_ee) / dfd
    return num / den

# accept iff dfd*num_raw - 2*crit*den_raw <= 0
qa = dfd * D_ee - 2 * crit * M_ee
qb = -2 * (dfd * D_ye - 2 * crit * M_ye)
qc = dfd * D_yy - 2 * crit * M_yy
disc = qb * qb - 4 * qa * qc
roots = np.sort(np.real(np.roots([qa, qb, qc]))) if disc >= 0 else np.array([np.nan, np.nan])
lo, hi = float(roots[0]), float(roots[1])
unbounded = 1.0 if qa < 0 else 0.0
accepts_zero = 1.0 if ar_f(0.0) <= crit else 0.0

res = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": [
        {"term": "boundary_low", "estimate": lo, "se": None, "n_obs": n},
        {"term": "boundary_high", "estimate": hi, "se": None, "n_obs": n},
        {"term": "accepts_zero", "estimate": accepts_zero, "se": None, "n_obs": n},
        {"term": "unbounded", "estimate": unbounded, "se": None, "n_obs": n},
        {"term": "ar_f_at_one", "estimate": float(ar_f(1.0)), "se": None, "n_obs": n},
    ],
    "method_metadata": {"estimator": "Anderson-Rubin test inversion (analytic quadratic)",
                        "vcov": "homoskedastic F(2, n-4)"},
    "diagnostics": {"critical_value": float(crit), "quad_leading_coef": float(qa),
                    "discriminant": float(disc)},
}
with open("result.json", "w") as f:
    json.dump(res, f, indent=2)
