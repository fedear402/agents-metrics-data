import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df = df[["score", "participated", "earnings"]].dropna()
d = df[np.abs(df["score"]) < 1].copy()
x = d["score"].to_numpy(float)
w = 1.0 - np.abs(x)
D = (x >= 0).astype(float)
X = np.column_stack([np.ones_like(x), x, D, D * x])
n = len(d)

y1 = d["earnings"].to_numpy(float)
y2 = d["participated"].to_numpy(float)

XtWX = X.T @ (X * w[:, None])
bread = np.linalg.inv(XtWX)
b1 = bread @ (X.T @ (w * y1))
b2 = bread @ (X.T @ (w * y2))
e1 = y1 - X @ b1
e2 = y2 - X @ b2

s1 = X * (w * e1)[:, None]
s2 = X * (w * e2)[:, None]
V11 = bread @ (s1.T @ s1) @ bread
V22 = bread @ (s2.T @ s2) @ bread
V12 = bread @ (s1.T @ s2) @ bread

rf, fs = b1[2], b2[2]
v_rf, v_fs, c = V11[2, 2], V22[2, 2], V12[2, 2]
te = rf / fs
g = np.array([1.0 / fs, -rf / fs**2])
Vj = np.array([[v_rf, c], [c, v_fs]])
se_te = float(np.sqrt(g @ Vj @ g))

res = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": float(te), "se": se_te, "n_obs": int(n)},
        {"term": "reduced_form", "estimate": float(rf), "se": float(np.sqrt(v_rf)), "n_obs": int(n)},
        {"term": "first_stage", "estimate": float(fs), "se": float(np.sqrt(v_fs)), "n_obs": int(n)},
    ],
    "method_metadata": {
        "estimator": "fuzzy RD, local linear, triangular kernel, h=1, separate slopes, Wald ratio",
        "vcov": "HC0 joint sandwich, delta method with covariance",
    },
    "diagnostics": {"cov_rf_fs": float(c)},
}
with open("result.json", "w") as f:
    json.dump(res, f, indent=2)
