import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df = df[["score", "participated", "earnings"]].dropna()
df = df[np.abs(df["score"]) < 1].copy()

x = df["score"].to_numpy(dtype=float)
d = (x >= 0).astype(float)
w = 1.0 - np.abs(x)
y = df["earnings"].to_numpy(dtype=float)
t = df["participated"].to_numpy(dtype=float)
n = len(df)

X = np.column_stack([np.ones(n), d, x, d * x])
XtWX = X.T @ (X * w[:, None])
bread = np.linalg.inv(XtWX)

def wls(v):
    b = bread @ (X.T @ (w * v))
    return b, v - X @ b

by, ey = wls(y)
bt, et = wls(t)

Sy = X * (w * ey)[:, None]
St = X * (w * et)[:, None]
V_yy = bread @ (Sy.T @ Sy) @ bread
V_tt = bread @ (St.T @ St) @ bread
V_yt = bread @ (Sy.T @ St) @ bread

rf = by[1]
fs = bt[1]
var_rf = V_yy[1, 1]
var_fs = V_tt[1, 1]
cov = V_yt[1, 1]

te = rf / fs
g = np.array([1.0 / fs, -rf / fs**2])
V = np.array([[var_rf, cov], [cov, var_fs]])
se_te = float(np.sqrt(g @ V @ g))

res = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": float(te), "se": se_te, "n_obs": int(n)},
        {"term": "reduced_form", "estimate": float(rf), "se": float(np.sqrt(var_rf)), "n_obs": int(n)},
        {"term": "first_stage", "estimate": float(fs), "se": float(np.sqrt(var_fs)), "n_obs": int(n)},
    ],
    "method_metadata": {
        "estimator": "fuzzy RD, local linear, triangular kernel, h=1, cutoff 0, ratio of WLS discontinuities",
        "vcov": "HC0 sandwich, joint covariance, delta method for ratio",
    },
    "diagnostics": {
        "cov_reduced_first": float(cov),
        "n_left": int((d == 0).sum()),
        "n_right": int((d == 1).sum()),
    },
}

with open("result.json", "w") as f:
    json.dump(res, f, indent=2)
