import json
import numpy as np
import pandas as pd

cw = pd.read_csv("crosswalk.csv")
tr = pd.read_csv("trade.csv")
ar = pd.read_csv("areas.csv")
em = pd.read_csv("employment.csv")
oc = pd.read_csv("outcomes.csv")

for d in (cw, tr):
    d["code"] = d["code"].astype(str).str.strip()
for d in (ar, em, oc):
    d["vintage"] = d["vintage"].astype(str).str.strip().str.lower() if "vintage" in d else None
cw["industry"] = cw["industry"].astype(str).str.strip()
em["industry"] = em["industry"].astype(str).str.strip()

t = tr.merge(cw, on="code", how="inner")
t = t.groupby(["period", "industry"], as_index=False).agg(
    us_change=("us_change", "sum"), other_change=("other_change", "sum"),
    price_index=("price_index", "first"), years=("years", "first"))

industries = sorted(cw["industry"].unique())
areas = ar[["area", "period"]].drop_duplicates()
periods = sorted(areas["period"].unique())


def exposure(vintage, change_col):
    e = em[em["vintage"] == vintage].groupby(["area", "period", "industry"], as_index=False)["employment"].sum()
    grid = areas.assign(k=1).merge(pd.DataFrame({"industry": industries, "k": 1}), on="k").drop(columns="k")
    g = grid.merge(e, on=["area", "period", "industry"], how="left")
    g["employment"] = g["employment"].fillna(0.0)
    nat = g.groupby(["period", "industry"])["employment"].transform("sum")
    g["nat"] = nat
    tot = ar[ar["vintage"] == vintage][["area", "period", "total_employment"]].drop_duplicates(["area", "period"])
    g = g.merge(tot, on=["area", "period"], how="left")
    g = g.merge(t, on=["period", "industry"], how="left")
    g["term"] = (g["employment"] / g["total_employment"]) * (g[change_col] / g["nat"]) \
        / (g["price_index"] / 100.0) / 1000.0 * (10.0 / g["years"])
    return g.groupby(["area", "period"], as_index=False)["term"].sum()


x = exposure("base", "us_change").rename(columns={"term": "x"})
z = exposure("early", "other_change").rename(columns={"term": "z"})
pop = ar[ar["vintage"] == "base"][["area", "period", "population"]].drop_duplicates(["area", "period"])

df = oc.drop(columns=[c for c in ["vintage"] if c in oc]).merge(x, on=["area", "period"]) \
    .merge(z, on=["area", "period"]).merge(pop, on=["area", "period"])
df = df.dropna(subset=["change_pp", "control", "x", "z", "population"]).sort_values(["period", "area"])

n = len(df)
y = df["change_pp"].to_numpy(float)
ones = np.ones(n)
X = np.column_stack([ones, df["period"].to_numpy(float), df["control"].to_numpy(float), df["x"].to_numpy(float)])
Z = np.column_stack([ones, df["period"].to_numpy(float), df["control"].to_numpy(float), df["z"].to_numpy(float)])
w = df["population"].to_numpy(float)
sw = np.sqrt(w)
Xw, Zw, yw = X * sw[:, None], Z * sw[:, None], y * sw
Pz_X = Zw @ np.linalg.solve(Zw.T @ Zw, Zw.T @ Xw)
beta = np.linalg.solve(Pz_X.T @ Xw, Pz_X.T @ yw)

fs = np.linalg.lstsq(Zw, Xw[:, 3], rcond=None)[0]


def get(dfv, col, a, p):
    r = dfv[(dfv["area"].astype(str) == str(a)) & (dfv["period"].astype(str) == str(p))]
    return float(r[col].iloc[0])


p0, p1 = periods[0], periods[1] if len(periods) > 1 else periods[0]
est = {
    "iv_slope": float(beta[3]),
    "exposure_area0_period0": get(x, "x", 0, p0),
    "exposure_area0_period1": get(x, "x", 0, p1),
    "instrument_area0_period0": get(z, "z", 0, p0),
}

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [{"term": k, "estimate": float(f"{v:.15g}"), "se": None, "n_obs": int(n)} for k, v in est.items()],
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "weights": "base-vintage population",
        "exogenous": ["intercept", "period", "control"],
        "endogenous": "x", "instrument": "z",
        "missing_employment": "zero",
    },
    "diagnostics": {
        "n_obs": int(n),
        "coefficients": [float(b) for b in beta],
        "first_stage_z_coef": float(fs[3]),
        "periods": [str(p) for p in periods],
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
