import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")

regions = sorted(df["region_id"].unique())
industries = sorted(df["industry_id"].unique())
r_idx = {r: i for i, r in enumerate(regions)}
n_idx = {n: j for j, n in enumerate(industries)}
R, N = len(regions), len(industries)

shares = np.zeros((R, N))
for r, n, s in zip(df["region_id"], df["industry_id"], df["share"]):
    shares[r_idx[r], n_idx[n]] += s

shock = df.groupby("industry_id")["shock"].first().reindex(industries).to_numpy(float)
reg = df.groupby("region_id")[["region_weight", "x", "y"]].first().reindex(regions)
weight = reg["region_weight"].to_numpy(float)
weight = weight / weight.sum()
x = reg["x"].to_numpy(float)
y = reg["y"].to_numpy(float)
z = shares @ shock

regional = np.column_stack([y, x, z])
centered = regional - weight @ regional
mass = weight @ shares
keep = mass > 0
aggregated = (shares.T @ (weight[:, None] * centered))[keep] / mass[keep][:, None]
s_n = mass[keep]
g = shock[keep]
n_used = int(keep.sum())


def shock_iv(dependent, endogenous):
    regressors = np.column_stack([np.ones(n_used), endogenous])
    instruments = np.column_stack([np.ones(n_used), g])
    cross = instruments.T @ (s_n[:, None] * regressors)
    beta = np.linalg.solve(cross, instruments.T @ (s_n * dependent))
    residual = dependent - regressors @ beta
    scores = instruments * (s_n * residual)[:, None]
    inverse = np.linalg.inv(cross)
    hc1 = n_used / (n_used - 2)
    covariance = hc1 * inverse @ (scores.T @ scores) @ inverse.T
    return float(beta[1]), float(np.sqrt(covariance[1, 1]))


effect, effect_se = shock_iv(aggregated[:, 0], aggregated[:, 1])
first_stage, first_stage_se = shock_iv(aggregated[:, 1], aggregated[:, 2])

regional_effect = np.sum(weight * centered[:, 2] * centered[:, 0]) / np.sum(weight * centered[:, 2] * centered[:, 1])
regional_fs = np.sum(weight * centered[:, 2] * centered[:, 1]) / np.sum(weight * centered[:, 2] ** 2)

output = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": float(regional_effect), "se": effect_se, "n_obs": n_used},
        {"term": "first_stage", "estimate": float(regional_fs), "se": first_stage_se, "n_obs": n_used},
        {"term": "effective_shocks", "estimate": float(1.0 / np.sum(mass ** 2)), "se": None, "n_obs": n_used},
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS with shift-share instrument; BHJ shock-level equivalent IV",
        "vcov": "shock-level HC1 (N/(N-2)), structural IV residuals, analytic weights s_n",
    },
    "diagnostics": {
        "shock_level_effect": effect,
        "shock_level_first_stage": first_stage,
        "n_regions": R,
        "n_industries": N,
    },
}

with open("result.json", "w") as f:
    json.dump(output, f, indent=2, allow_nan=False)
