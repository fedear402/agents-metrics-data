import json
import numpy as np
import pandas as pd

df = pd.read_csv('input.csv')
df = df.dropna(subset=['id', 'time', 'g'])

rows = []
atts = {}
weights = {}
counts = {}
for c in (3, 5, 7):
    window = list(range(c - 2, c + 3))
    sub = df[df['time'].isin(window)]
    sub = sub[(sub['g'] == c) | (sub['g'] == 0) | (sub['g'] > c + 2)]
    sub = sub.dropna(subset=['y'])
    nt = sub.groupby('id')['time'].nunique()
    keep_ids = nt[nt == len(window)].index
    sub = sub[sub['id'].isin(keep_ids)].copy()
    did = ((sub['g'] == c) & (sub['time'] >= c)).astype(float).to_numpy()
    # An intercept accompanies one omitted category in each fixed-effect set.
    design = np.column_stack([
        np.ones(len(sub)), did,
        pd.get_dummies(sub['id'], drop_first=True, dtype=float).to_numpy(),
        pd.get_dummies(sub['time'], drop_first=True, dtype=float).to_numpy(),
    ])
    beta = np.linalg.lstsq(design, sub['y'].to_numpy(dtype=float), rcond=None)[0]
    atts[c] = float(beta[1])
    weights[c] = int(sub.loc[sub['g'] == c, 'id'].nunique())
    counts[c] = int(len(sub))
    rows.append({'term': f'att_g{c}', 'estimate': atts[c], 'se': None, 'n_obs': counts[c]})

wsum = sum(weights.values())
att_w = sum(atts[c] * weights[c] for c in atts) / wsum
rows.append({'term': 'att_weighted', 'estimate': float(att_w), 'se': None,
             'n_obs': int(sum(counts.values()))})

output = {
    'task_id': 'broad_cohort_stack',
    'platform': 'python',
    'estimates': rows,
    'method_metadata': {},
    'diagnostics': {
        'retained_treated': {f'g{c}': weights[c] for c in weights},
    },
}
with open('result.json', 'w') as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
