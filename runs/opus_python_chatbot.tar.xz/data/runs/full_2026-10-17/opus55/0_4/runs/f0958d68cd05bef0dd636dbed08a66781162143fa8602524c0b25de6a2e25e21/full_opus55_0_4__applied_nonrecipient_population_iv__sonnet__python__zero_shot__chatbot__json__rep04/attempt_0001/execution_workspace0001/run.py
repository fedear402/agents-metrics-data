import json
import numpy as np
import pandas as pd

hh = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

df = hh[hh["recipient"] == 0].copy()
df = df.dropna(subset=["eligible", "instrument", "dose", "baseline", "weight", "outcome"])
df = df[df["weight"] > 0]
e = df["eligible"].astype(float).values
ne = 1.0 - e
d = df["dose"].astype(float).values
b = df["baseline"].astype(float).values
z = df["instrument"].astype(float).values
w = df["weight"].astype(float).values
y = df["outcome"].astype(float).values
n_obs = int(len(df))

X = np.column_stack([d * ne, d * e, ne, e, b * ne, b * e])
Z = np.column_stack([ne, e, b * ne, b * e, z * ne, z * e])

sw = np.sqrt(w)
Xw = X * sw[:, None]
Zw = Z * sw[:, None]
yw = y * sw
ZZ = Zw.T @ Zw
ZX = Zw.T @ Xw
Zy = Zw.T @ yw
ZZinv = np.linalg.pinv(ZZ)
A = ZX.T @ ZZinv @ ZX
bvec = ZX.T @ ZZinv @ Zy
beta = np.linalg.solve(A, bvec)

slope_ine, slope_eli = float(beta[0]), float(beta[1])
m0 = e == 0
m1 = e == 1
mean_d0 = float(np.sum(w[m0] * d[m0]) / np.sum(w[m0]))
mean_d1 = float(np.sum(w[m1] * d[m1]) / np.sum(w[m1]))
eff0 = slope_ine * mean_d0
eff1 = slope_eli * mean_d1

census["eligible"] = census["eligible"].astype(int)
pop = census.groupby("eligible")["nonrecipient_population"].sum()
p0 = float(pop.get(0, 0.0))
p1 = float(pop.get(1, 0.0))
pop_eff = (p0 * eff0 + p1 * eff1) / (p0 + p1)

res = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {"term": "ineligible_effect", "estimate": float(eff0), "se": None, "n_obs": n_obs},
        {"term": "eligible_nonrecipient_effect", "estimate": float(eff1), "se": None, "n_obs": n_obs},
        {"term": "population_effect", "estimate": float(pop_eff), "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS, eligibility-interacted, no common intercept",
        "endogenous": ["dose*(1-eligible)", "dose*eligible"],
        "exogenous": ["1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"],
        "excluded_instruments": ["instrument*(1-eligible)", "instrument*eligible"],
        "weights": "weight",
        "sample": "recipient==0 (all nonrecipients, both village treatment statuses)",
        "counterfactual": "dose set to zero for every retained household (synthetic convention)",
        "aggregation": "census nonrecipient_population weights across eligibility groups",
    },
    "diagnostics": {
        "slope_ineligible": slope_ine,
        "slope_eligible": slope_eli,
        "weighted_mean_dose_ineligible": mean_d0,
        "weighted_mean_dose_eligible": mean_d1,
        "n_ineligible": int(m0.sum()),
        "n_eligible": int(m1.sum()),
        "census_pop_ineligible": p0,
        "census_pop_eligible": p1,
        "coefficients": [float(v) for v in beta],
    },
}

with open("result.json", "w") as f:
    json.dump(res, f, indent=2)
