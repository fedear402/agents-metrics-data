import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df = df[["score", "participated", "earnings"]].apply(pd.to_numeric, errors="coerce").dropna()
d = df[np.abs(df["score"]) < 1].copy()
n = int(len(d))

x = d["score"].to_numpy(dtype=float)
w = 1.0 - np.abs(x)
right = (x >= 0).astype(float)
X = np.column_stack([np.ones(n), x, right, right * x])
Y = np.column_stack([d["earnings"].to_numpy(dtype=float),
                     d["participated"].to_numpy(dtype=float)])

bread = np.linalg.inv(X.T @ (w[:, None] * X))
coefficients = bread @ X.T @ (w[:, None] * Y)
residuals = Y - X @ coefficients
# Coefficient on the right-side indicator is the jump at the cutoff.
contrast = np.array([0., 0., 1., 0.])
jumps = contrast @ coefficients
loading = w * (X @ bread @ contrast)
influence = loading[:, None] * residuals
joint = influence.T @ influence

rf, fs = jumps
te = rf / fs
gradient = np.array([1 / fs, -rf / fs**2])
te_se = float(np.sqrt(gradient @ joint @ gradient))

out = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": float(te), "se": te_se, "n_obs": n},
        {"term": "reduced_form", "estimate": float(rf), "se": float(np.sqrt(joint[0, 0])), "n_obs": n},
        {"term": "first_stage", "estimate": float(fs), "se": float(np.sqrt(joint[1, 1])), "n_obs": n},
    ],
    "method_metadata": {
        "estimator": "fuzzy RD, local linear, triangular kernel, bandwidth 1, cutoff 0, separate slopes",
        "vcov": "HC0 joint covariance, delta method for ratio, no bias correction",
    },
    "diagnostics": {"rf_fs_covariance": float(joint[0, 1])},
}
with open("result.json", "w") as f:
    json.dump(out, f, indent=2, allow_nan=False)
