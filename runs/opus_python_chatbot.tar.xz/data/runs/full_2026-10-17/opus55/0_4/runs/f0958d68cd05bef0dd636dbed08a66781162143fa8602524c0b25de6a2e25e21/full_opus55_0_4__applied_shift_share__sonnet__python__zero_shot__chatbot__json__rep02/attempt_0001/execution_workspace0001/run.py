import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df = df.dropna(subset=["region_id", "industry_id", "share", "shock", "region_weight", "x", "y"])

reg = df.groupby("region_id").agg(region_weight=("region_weight", "first"),
                                  x=("x", "first"), y=("y", "first")).reset_index()
reg["e"] = reg["region_weight"] / reg["region_weight"].sum()
df["z_part"] = df["share"] * df["shock"]
z = df.groupby("region_id")["z_part"].sum().rename("z").reset_index()
reg = reg.merge(z, on="region_id")

e = reg["e"].values
def wmean(v):
    return np.sum(e * v) / np.sum(e)

def wiv(yv, xv, zv, w):
    X = np.column_stack([np.ones_like(xv), xv])
    Z = np.column_stack([np.ones_like(zv), zv])
    W = w
    ZWX = Z.T @ (W[:, None] * X)
    ZWy = Z.T @ (W * yv)
    b = np.linalg.solve(ZWX, ZWy)
    u = yv - X @ b
    n = len(yv)
    A = np.linalg.inv(ZWX)
    meat = (Z * (W * u)[:, None]).T @ (Z * (W * u)[:, None])
    V = A @ meat @ A.T * n / (n - 2)
    return b, np.sqrt(np.diag(V))

# regional estimates
b_eff, _ = wiv(reg["y"].values, reg["x"].values, reg["z"].values, e)
b_fs, _ = wiv(reg["x"].values, reg["z"].values, reg["z"].values, e)

for v in ["y", "x", "z"]:
    reg[v + "0"] = reg[v] - wmean(reg[v].values)

d = df[["region_id", "industry_id", "share", "shock"]].merge(
    reg[["region_id", "e", "y0", "x0", "z0"]], on="region_id")
d["es"] = d["e"] * d["share"]
for v in ["y0", "x0", "z0"]:
    d[v + "w"] = d["es"] * d[v]
ind = d.groupby("industry_id").agg(s=("es", "sum"), shock=("shock", "first"),
                                   yw=("y0w", "sum"), xw=("x0w", "sum"),
                                   zw=("z0w", "sum")).reset_index()
ind = ind[ind["s"] > 0].copy()
ind["ybar"] = ind["yw"] / ind["s"]
ind["xbar"] = ind["xw"] / ind["s"]
ind["zbar"] = ind["zw"] / ind["s"]
N = len(ind)
s = ind["s"].values
g = ind["shock"].values

bs_eff, se_eff = wiv(ind["ybar"].values, ind["xbar"].values, g, s)
bs_fs, se_fs = wiv(ind["xbar"].values, ind["zbar"].values, g, s)

eff_shocks = 1.0 / np.sum(s ** 2)

out = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": float(b_eff[1]), "se": float(se_eff[1]), "n_obs": int(N)},
        {"term": "first_stage", "estimate": float(b_fs[1]), "se": float(se_fs[1]), "n_obs": int(N)},
        {"term": "effective_shocks", "estimate": float(eff_shocks), "se": None, "n_obs": int(N)},
    ],
    "method_metadata": {"estimator": "weighted 2SLS shift-share (BHJ shock-level)",
                        "vcov": "shock-level HC1 N/(N-2)"},
    "diagnostics": {"shock_level_effect": float(bs_eff[1]),
                    "shock_level_first_stage": float(bs_fs[1]),
                    "n_regions": int(len(reg))},
}
with open("result.json", "w") as f:
    json.dump(out, f, indent=2)
