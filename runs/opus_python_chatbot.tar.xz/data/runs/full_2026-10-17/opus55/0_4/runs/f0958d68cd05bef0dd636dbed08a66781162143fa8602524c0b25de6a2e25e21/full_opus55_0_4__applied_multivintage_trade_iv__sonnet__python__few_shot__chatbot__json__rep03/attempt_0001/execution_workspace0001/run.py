import json
import numpy as np
import pandas as pd

cw = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv")
areas = pd.read_csv("areas.csv")
emp = pd.read_csv("employment.csv")
out = pd.read_csv("outcomes.csv")

for d in (cw, trade):
    d["code"] = d["code"].astype(str).str.strip()
for d in (cw, emp):
    d["industry"] = d["industry"].astype(str).str.strip()
for d in (trade, areas, emp, out):
    d["period"] = d["period"].astype(str).str.strip()
for d in (areas, emp, out):
    d["area"] = d["area"].astype(str).str.strip()
for d in (areas, emp):
    d["vintage"] = d["vintage"].astype(str).str.strip().str.lower()

tr = trade.merge(cw[["code", "industry"]], on="code", how="inner")
industries = sorted(cw["industry"].unique())
periods = sorted(out["period"].unique(), key=lambda s: (float(s) if s.replace('.', '', 1).lstrip('-').isdigit() else np.inf, s))
area_list = sorted(out["area"].unique(), key=lambda s: (float(s) if s.replace('.', '', 1).lstrip('-').isdigit() else np.inf, s))

def exposure(vintage, change_col):
    e = emp[emp["vintage"] == vintage].groupby(["area", "period", "industry"])["employment"].sum()
    e = e.unstack("industry").reindex(columns=industries).fillna(0.0)
    full_idx = pd.MultiIndex.from_product([area_list, periods], names=["area", "period"])
    e = e.reindex(full_idx).fillna(0.0)
    tot = areas[areas["vintage"] == vintage].set_index(["area", "period"])["total_employment"].reindex(full_idx)
    res = {}
    for p in periods:
        ep = e.xs(p, level="period")
        nat = ep.sum(axis=0)
        t = tr[tr["period"] == p].set_index("industry").reindex(industries)
        shock = (t[change_col] / nat / (t["price_index"] / 100.0) / 1000.0 * (10.0 / t["years"])).values
        val = ep.values @ shock / tot.xs(p, level="period").reindex(ep.index).values
        for a, v in zip(ep.index, val):
            res[(a, p)] = float(v)
    return res

xd = exposure("base", "us_change")
zd = exposure("early", "other_change")

df = out.copy()
df["x"] = [xd[(a, p)] for a, p in zip(df["area"], df["period"])]
df["z"] = [zd[(a, p)] for a, p in zip(df["area"], df["period"])]
pop = areas[areas["vintage"] == "base"].groupby(["area", "period"])["population"].first()
df["w"] = [pop[(a, p)] for a, p in zip(df["area"], df["period"])]
pmap = {p: i for i, p in enumerate(periods)}
df["pnum"] = df["period"].map(pmap).astype(float)
df = df.dropna(subset=["change_pp", "control", "x", "z", "w"])

y = df["change_pp"].values.astype(float)
X = np.column_stack([np.ones(len(df)), df["pnum"], df["control"], df["x"]]).astype(float)
Z = np.column_stack([np.ones(len(df)), df["pnum"], df["control"], df["z"]]).astype(float)
sw = np.sqrt(df["w"].values.astype(float))
Xw, Zw, yw = X * sw[:, None], Z * sw[:, None], y * sw
Xhat = Zw @ np.linalg.lstsq(Zw, Xw, rcond=None)[0]
beta = np.linalg.solve(Xhat.T @ Xw, Xhat.T @ yw)
n = int(len(df))

a0 = area_list[0] if "0" not in area_list else "0"
est = {
    "iv_slope": float(beta[3]),
    "exposure_area0_period0": xd[(a0, periods[0])],
    "exposure_area0_period1": xd[(a0, periods[1])],
    "instrument_area0_period0": zd[(a0, periods[0])],
}
result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [{"term": k, "estimate": float(f"{v:.15g}"), "se": None, "n_obs": n} for k, v in est.items()],
    "method_metadata": {
        "estimator": "weighted 2SLS (manual)",
        "exogenous": ["intercept", "period", "control"],
        "endogenous": "x", "instrument": "z", "weights": "base-vintage population",
        "period_coding": {p: i for p, i in pmap.items()},
    },
    "diagnostics": {"n_obs": n, "n_areas": len(area_list), "n_periods": len(periods),
                    "coefficients": [float(b) for b in beta]},
}
with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
