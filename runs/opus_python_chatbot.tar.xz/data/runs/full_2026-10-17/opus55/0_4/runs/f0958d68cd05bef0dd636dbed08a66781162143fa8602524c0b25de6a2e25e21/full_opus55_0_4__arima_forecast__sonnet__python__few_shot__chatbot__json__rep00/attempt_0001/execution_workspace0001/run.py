import json
import numpy as np
import pandas as pd
from statsmodels.tsa.arima.model import ARIMA

df = pd.read_csv("./input.csv")
df = df.sort_values("t").reset_index(drop=True)
y = df["y"].astype(float).reset_index(drop=True)

model = ARIMA(y, order=(1, 1, 1), trend="n")
fit = model.fit()

fc = fit.get_forecast(steps=1)
mean = float(np.asarray(fc.predicted_mean)[0])
se = float(np.asarray(fc.se_mean)[0])
ci = np.asarray(fc.conf_int(alpha=0.05))
lower = float(ci[0, 0])
upper = float(ci[0, 1])
n = int(len(y))

params = {str(k): float(v) for k, v in fit.params.items()}

out = {
    "task_id": "arima_forecast",
    "platform": "python",
    "estimates": [
        {"term": "forecast", "estimate": mean, "se": se, "n_obs": n},
        {"term": "lower_95", "estimate": lower, "se": None, "n_obs": n},
        {"term": "upper_95", "estimate": upper, "se": None, "n_obs": n},
    ],
    "method_metadata": {
        "estimator": "ARIMA(1,1,1) exact MLE (statsmodels state space), no constant/drift",
        "vcov": "OPG (statsmodels default); forecast SE from Kalman filter",
    },
    "diagnostics": {
        "params": params,
        "loglik": float(fit.llf),
        "aic": float(fit.aic),
        "forecast_t": int(df["t"].iloc[-1]) + 1,
    },
}
with open("result.json", "w") as f:
    json.dump(out, f)
