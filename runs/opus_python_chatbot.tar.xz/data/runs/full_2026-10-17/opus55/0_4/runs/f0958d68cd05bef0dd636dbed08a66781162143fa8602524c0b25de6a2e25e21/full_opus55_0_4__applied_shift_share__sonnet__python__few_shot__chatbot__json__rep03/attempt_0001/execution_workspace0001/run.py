import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df["region_id"] = df["region_id"].astype(str)
df["industry_id"] = df["industry_id"].astype(str)

regions = sorted(df["region_id"].unique())
industries = sorted(df["industry_id"].unique())
R, N = len(regions), len(industries)

reg = df.groupby("region_id")[["region_weight", "x", "y"]].first().reindex(regions)
shock = df.groupby("industry_id")["shock"].first().reindex(industries).to_numpy(float)
shares = (df.pivot_table(index="region_id", columns="industry_id", values="share",
                         aggfunc="sum", fill_value=0.0)
          .reindex(index=regions, columns=industries, fill_value=0.0).to_numpy(float))

w = reg["region_weight"].to_numpy(float)
e = w / w.sum()
x = reg["x"].to_numpy(float)
y = reg["y"].to_numpy(float)
z = shares @ shock

regional = np.column_stack([y, x, z])
centered = regional - e @ regional
mass = e @ shares
keep = mass > 0
agg = (shares.T @ (e[:, None] * centered))[keep] / mass[keep][:, None]
m = mass[keep]
g = shock[keep]
Nk = int(keep.sum())


def shock_iv(dep, endog):
    X = np.column_stack([np.ones(Nk), endog])
    Z = np.column_stack([np.ones(Nk), g])
    cross = Z.T @ (m[:, None] * X)
    beta = np.linalg.solve(cross, Z.T @ (m * dep))
    resid = dep - X @ beta
    scores = Z * (m * resid)[:, None]
    inv = np.linalg.inv(cross)
    cov = (Nk / (Nk - 2)) * inv @ (scores.T @ scores) @ inv.T
    return float(beta[1]), float(np.sqrt(cov[1, 1]))


effect, effect_se = shock_iv(agg[:, 0], agg[:, 1])
fs, fs_se = shock_iv(agg[:, 1], agg[:, 2])

yc, xc, zc = centered[:, 0], centered[:, 1], centered[:, 2]
reg_effect = np.sum(e * zc * yc) / np.sum(e * zc * xc)
reg_fs = np.sum(e * zc * xc) / np.sum(e * zc ** 2)

eff_shocks = float(1.0 / np.sum(mass ** 2))

out = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": float(reg_effect), "se": effect_se, "n_obs": Nk},
        {"term": "first_stage", "estimate": float(reg_fs), "se": fs_se, "n_obs": Nk},
        {"term": "effective_shocks", "estimate": eff_shocks, "se": None, "n_obs": Nk},
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS with shift-share instrument; BHJ shock-level equivalent IV",
        "vcov": "shock-level HC1 (N/(N-2)), structural IV residuals, analytic weights s_n",
    },
    "diagnostics": {
        "shock_level_effect": effect,
        "shock_level_first_stage": fs,
        "n_regions": R,
        "n_industries": N,
    },
}
with open("result.json", "w") as f:
    json.dump(out, f, indent=2, allow_nan=False)
