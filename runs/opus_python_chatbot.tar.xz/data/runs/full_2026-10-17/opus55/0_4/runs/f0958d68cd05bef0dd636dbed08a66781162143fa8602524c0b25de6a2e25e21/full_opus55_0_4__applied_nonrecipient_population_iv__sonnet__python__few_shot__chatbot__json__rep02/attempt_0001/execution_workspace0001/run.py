import json
import numpy as np
import pandas as pd

h = pd.read_csv("households.csv")
c = pd.read_csv("census.csv")
d = h[h["recipient"] == 0].copy()
cols = ["eligible", "dose", "instrument", "baseline", "weight", "outcome"]
d = d.dropna(subset=cols).reset_index(drop=True)
e = d["eligible"].astype(float).values
ne = 1.0 - e
dose = d["dose"].values.astype(float)
b = d["baseline"].values.astype(float)
z = d["instrument"].values.astype(float)
w = d["weight"].values.astype(float)
y = d["outcome"].values.astype(float)

exog = np.column_stack([ne, e, b * ne, b * e])
endog = np.column_stack([dose * ne, dose * e])
X = np.column_stack([exog, endog])
Z = np.column_stack([exog, z * ne, z * e])

sw = np.sqrt(w)
Xw = X * sw[:, None]
Zw = Z * sw[:, None]
yw = y * sw
# Weighted 2SLS
PzX = Zw @ np.linalg.lstsq(Zw, Xw, rcond=None)[0]
beta = np.linalg.solve(PzX.T @ Xw, PzX.T @ yw)
slope0, slope1 = beta[4], beta[5]

m0 = ne == 1
m1 = e == 1
mean0 = np.average(dose[m0], weights=w[m0])
mean1 = np.average(dose[m1], weights=w[m1])
eff0 = float(slope0 * mean0)
eff1 = float(slope1 * mean1)

c = c.copy()
c["eligible"] = c["eligible"].astype(int)
pop = c.groupby("eligible")["nonrecipient_population"].sum()
p0 = float(pop.loc[0])
p1 = float(pop.loc[1])
popeff = float((p0 * eff0 + p1 * eff1) / (p0 + p1))

n = int(len(d))
res = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {"term": "ineligible_effect", "estimate": eff0, "se": None, "n_obs": n},
        {"term": "eligible_nonrecipient_effect", "estimate": eff1, "se": None, "n_obs": n},
        {"term": "population_effect", "estimate": popeff, "se": None, "n_obs": n},
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS, fully interacted by eligibility, no common intercept",
        "endogenous": ["dose*(1-eligible)", "dose*eligible"],
        "exogenous": ["1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"],
        "excluded_instruments": ["instrument*(1-eligible)", "instrument*eligible"],
        "weights": "weight",
        "sample": "recipient==0",
        "counterfactual": "dose=0 for all retained households",
        "aggregation_weights": "census nonrecipient_population",
    },
    "diagnostics": {
        "n_obs": n,
        "n_ineligible": int(m0.sum()),
        "n_eligible_nonrecipient": int(m1.sum()),
        "slope_ineligible": float(slope0),
        "slope_eligible_nonrecipient": float(slope1),
        "weighted_mean_dose_ineligible": float(mean0),
        "weighted_mean_dose_eligible_nonrecipient": float(mean1),
        "population_ineligible": p0,
        "population_eligible_nonrecipient": p1,
        "coefficients": [float(v) for v in beta],
    },
}
with open("result.json", "w") as f:
    json.dump(res, f, indent=2)
print(json.dumps(res, indent=2))
