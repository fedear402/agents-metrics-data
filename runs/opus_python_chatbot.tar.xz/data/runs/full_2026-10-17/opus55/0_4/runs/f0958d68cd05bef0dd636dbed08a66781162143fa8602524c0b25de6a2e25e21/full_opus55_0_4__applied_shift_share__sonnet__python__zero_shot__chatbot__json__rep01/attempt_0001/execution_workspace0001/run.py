import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")

# Regional data, one row per region
reg = df.groupby("region_id", sort=True).agg(
    region_weight=("region_weight", "first"), x=("x", "first"), y=("y", "first")
)
reg["e"] = reg["region_weight"] / reg["region_weight"].sum()

# Shift-share instrument
df["ss"] = df["share"] * df["shock"]
reg["z"] = df.groupby("region_id")["ss"].sum().reindex(reg.index)

e = reg["e"].values


def wiv(yv, xv, zv, w):
    X = np.column_stack([np.ones_like(xv), xv])
    Z = np.column_stack([np.ones_like(zv), zv])
    ZWX = Z.T @ (w[:, None] * X)
    beta = np.linalg.solve(ZWX, Z.T @ (w * yv))
    u = yv - X @ beta
    bread = np.linalg.inv(ZWX)
    g = Z * (w * u)[:, None]
    meat = g.T @ g
    n = len(yv)
    V = bread @ meat @ bread.T * n / (n - 2)
    return beta, V


# Regional estimates
b_reg, _ = wiv(reg["y"].values, reg["x"].values, reg["z"].values, e)
fs_reg, _ = wiv(reg["x"].values, reg["z"].values, reg["z"].values, e)

# Demeaned residuals
for v in ["y", "x", "z"]:
    reg[v + "0"] = reg[v] - np.sum(e * reg[v].values)

d = df.merge(reg[["e", "y0", "x0", "z0"]], left_on="region_id", right_index=True)
d["es"] = d["e"] * d["share"]
for v in ["y0", "x0", "z0"]:
    d["w_" + v] = d["es"] * d[v]
ind = d.groupby("industry_id", sort=True).agg(
    s=("es", "sum"), shock=("shock", "first"),
    wy=("w_y0", "sum"), wx=("w_x0", "sum"), wz=("w_z0", "sum"),
)
ind = ind[ind["s"] > 0].copy()
ind["ybar"] = ind["wy"] / ind["s"]
ind["xbar"] = ind["wx"] / ind["s"]
ind["zbar"] = ind["wz"] / ind["s"]
N = len(ind)
s = ind["s"].values
g = ind["shock"].values

b_sh, V_sh = wiv(ind["ybar"].values, ind["xbar"].values, g, s)
f_sh, V_f = wiv(ind["xbar"].values, ind["zbar"].values, g, s)

eff_shocks = 1.0 / np.sum(s ** 2)

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": float(b_reg[1]),
         "se": float(np.sqrt(V_sh[1, 1])), "n_obs": int(N)},
        {"term": "first_stage", "estimate": float(fs_reg[1]),
         "se": float(np.sqrt(V_f[1, 1])), "n_obs": int(N)},
        {"term": "effective_shocks", "estimate": float(eff_shocks),
         "se": None, "n_obs": int(N)},
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS with shift-share instrument; BHJ shock-level equivalent IV",
        "vcov": "shock-level HC1 (N/(N-2)), analytic weights s_n, structural IV residuals",
    },
    "diagnostics": {
        "shock_level_effect_slope": float(b_sh[1]),
        "shock_level_first_stage_slope": float(f_sh[1]),
        "n_regions": int(len(reg)),
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
