import json
import numpy as np
import pandas as pd

hh = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

df = hh[hh["recipient"] == 0].copy()
df = df.dropna(subset=["eligible", "instrument", "dose", "baseline", "weight", "outcome"])
df = df[df["weight"] > 0]
n_obs = int(len(df))

e = df["eligible"].astype(float).to_numpy()
ne = 1.0 - e
d = df["dose"].astype(float).to_numpy()
b = df["baseline"].astype(float).to_numpy()
z = df["instrument"].astype(float).to_numpy()
w = df["weight"].astype(float).to_numpy()
y = df["outcome"].astype(float).to_numpy()

X = np.column_stack([d * ne, d * e, ne, e, b * ne, b * e])
Z = np.column_stack([ne, e, b * ne, b * e, z * ne, z * e])

sw = np.sqrt(w)
Xw = X * sw[:, None]
Zw = Z * sw[:, None]
yw = y * sw
# first stage projection
pi, *_ = np.linalg.lstsq(Zw, Xw, rcond=None)
Xhat = Zw @ pi
beta = np.linalg.solve(Xhat.T @ Xw, Xhat.T @ yw)

slope_ineligible = float(beta[0])
slope_eligible = float(beta[1])

m0 = e == 0
m1 = e == 1
mean_dose0 = float(np.sum(w[m0] * d[m0]) / np.sum(w[m0]))
mean_dose1 = float(np.sum(w[m1] * d[m1]) / np.sum(w[m1]))

ineligible_effect = slope_ineligible * mean_dose0
eligible_effect = slope_eligible * mean_dose1

cen = census.groupby("eligible")["nonrecipient_population"].sum()
pop0 = float(cen.get(0, 0.0))
pop1 = float(cen.get(1, 0.0))
population_effect = (pop0 * ineligible_effect + pop1 * eligible_effect) / (pop0 + pop1)

# first-stage diagnostics
def fs_partial_F(col):
    xw = Xw[:, col]
    Zr = Zw[:, :4]
    coef_u, *_ = np.linalg.lstsq(Zw, xw, rcond=None)
    coef_r, *_ = np.linalg.lstsq(Zr, xw, rcond=None)
    rss_u = float(np.sum((xw - Zw @ coef_u) ** 2))
    rss_r = float(np.sum((xw - Zr @ coef_r) ** 2))
    q = 2
    dfree = len(xw) - Zw.shape[1]
    return ((rss_r - rss_u) / q) / (rss_u / dfree) if rss_u > 0 else None

def fmt(v):
    return float(f"{v:.12g}")

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {"term": "ineligible_effect", "estimate": fmt(ineligible_effect), "se": None, "n_obs": n_obs},
        {"term": "eligible_nonrecipient_effect", "estimate": fmt(eligible_effect), "se": None, "n_obs": n_obs},
        {"term": "population_effect", "estimate": fmt(population_effect), "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "sample": "recipient == 0 (all nonrecipients, both eligibility groups, both village treatment statuses)",
        "endogenous": ["dose*(1-eligible)", "dose*eligible"],
        "exogenous": ["1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"],
        "excluded_instruments": ["instrument*(1-eligible)", "instrument*eligible"],
        "intercept": "none beyond group indicators",
        "weights": "weight",
        "group_effect": "dose slope times weighted mean dose within group (zero-dose counterfactual, synthetic convention)",
        "aggregation": "census nonrecipient_population weights",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "n_ineligible": int(m0.sum()),
        "n_eligible_nonrecipient": int(m1.sum()),
        "slope_ineligible": fmt(slope_ineligible),
        "slope_eligible": fmt(slope_eligible),
        "weighted_mean_dose_ineligible": fmt(mean_dose0),
        "weighted_mean_dose_eligible": fmt(mean_dose1),
        "census_pop_ineligible": pop0,
        "census_pop_eligible": pop1,
        "coefficients": [fmt(float(v)) for v in beta],
        "first_stage_partial_F_dose_ineligible": fs_partial_F(0),
        "first_stage_partial_F_dose_eligible": fs_partial_F(1),
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
