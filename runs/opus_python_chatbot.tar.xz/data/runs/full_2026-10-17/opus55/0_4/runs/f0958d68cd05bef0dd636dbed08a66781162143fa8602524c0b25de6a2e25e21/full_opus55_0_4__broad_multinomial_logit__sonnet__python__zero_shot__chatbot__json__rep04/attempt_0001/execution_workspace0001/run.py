import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("input.csv")
n_full = int(len(df))
d = df[["y", "x", "z"]].dropna().copy()
d["y"] = d["y"].astype(int)

X = sm.add_constant(d[["x", "z"]], has_constant="add")
model = sm.MNLogit(d["y"], X)
res = model.fit(method="newton", maxiter=200, disp=False)
if not res.mle_retvals.get("converged", True):
    res = model.fit(method="bfgs", maxiter=5000, disp=False)

params = np.asarray(res.params)  # rows: const,x,z ; cols: outcomes 1,2
bse = np.asarray(res.bse)
cols = list(res.params.columns)
# statsmodels labels columns by index 0..K-2 for outcomes after the base
names = list(X.columns)
ix, iz, ic = names.index("x"), names.index("z"), names.index("const")

def get(j):
    return params[:, j], bse[:, j]

p1, s1 = get(0)
p2, s2 = get(1)

eta = np.array([0.0, p1[ic], p2[ic]])
probs = np.exp(eta - eta.max())
probs /= probs.sum()
prob2 = float(probs[2])

est = [
    {"term": "x_cat1", "estimate": float(p1[ix]), "se": float(s1[ix]), "n_obs": n_full},
    {"term": "z_cat1", "estimate": float(p1[iz]), "se": float(s1[iz]), "n_obs": n_full},
    {"term": "x_cat2", "estimate": float(p2[ix]), "se": float(s2[ix]), "n_obs": n_full},
    {"term": "z_cat2", "estimate": float(p2[iz]), "se": float(s2[iz]), "n_obs": n_full},
    {"term": "prob_cat2_zero", "estimate": prob2, "se": None, "n_obs": n_full},
]

out = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": est,
    "method_metadata": {
        "estimator": "statsmodels MNLogit maximum likelihood, base outcome 0",
        "vcov": "observed information (inverse Hessian)",
    },
    "diagnostics": {
        "converged": bool(res.mle_retvals.get("converged", True)),
        "llf": float(res.llf),
        "n_used": int(res.nobs),
        "outcome_levels": [int(v) for v in sorted(d["y"].unique())],
    },
}

with open("result.json", "w") as f:
    json.dump(out, f, indent=2)
