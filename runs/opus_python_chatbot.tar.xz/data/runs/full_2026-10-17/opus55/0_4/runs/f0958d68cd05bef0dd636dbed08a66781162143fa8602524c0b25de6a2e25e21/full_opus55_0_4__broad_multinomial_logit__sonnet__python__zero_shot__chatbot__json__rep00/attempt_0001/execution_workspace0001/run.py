import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("input.csv")
n_full = int(len(df))

d = df[["y", "x", "z"]].apply(pd.to_numeric, errors="coerce").dropna()
d["y"] = d["y"].astype(int)

X = sm.add_constant(d[["x", "z"]], has_constant="add")
model = sm.MNLogit(d["y"], X)
res = model.fit(method="newton", maxiter=200, disp=False)
if not res.mle_retvals.get("converged", True):
    res = model.fit(method="bfgs", maxiter=5000, disp=False)

params = np.asarray(res.params)  # k x (J-1), columns ordered by sorted outcomes excluding base
bse = np.asarray(res.bse)
outcomes = sorted(d["y"].unique())
assert outcomes[0] == 0
names = list(X.columns)
ix, iz = names.index("x"), names.index("z")
c1 = outcomes.index(1) - 1
c2 = outcomes.index(2) - 1

x0 = np.array([[1.0 if n == "const" else 0.0 for n in names]])
probs = np.asarray(res.predict(x0))[0]
p2 = float(probs[outcomes.index(2)])

est = [
    {"term": "x_cat1", "estimate": float(params[ix, c1]), "se": float(bse[ix, c1]), "n_obs": n_full},
    {"term": "z_cat1", "estimate": float(params[iz, c1]), "se": float(bse[iz, c1]), "n_obs": n_full},
    {"term": "x_cat2", "estimate": float(params[ix, c2]), "se": float(bse[ix, c2]), "n_obs": n_full},
    {"term": "z_cat2", "estimate": float(params[iz, c2]), "se": float(bse[iz, c2]), "n_obs": n_full},
    {"term": "prob_cat2_zero", "estimate": p2, "se": None, "n_obs": n_full},
]

out = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": est,
    "method_metadata": {
        "estimator": "statsmodels MNLogit maximum likelihood, base outcome 0",
        "vcov": "observed information (inverse negative Hessian)",
    },
    "diagnostics": {
        "n_used": int(res.nobs),
        "converged": bool(res.mle_retvals.get("converged", True)),
        "llf": float(res.llf),
    },
}

with open("result.json", "w") as f:
    json.dump(out, f, indent=2)
