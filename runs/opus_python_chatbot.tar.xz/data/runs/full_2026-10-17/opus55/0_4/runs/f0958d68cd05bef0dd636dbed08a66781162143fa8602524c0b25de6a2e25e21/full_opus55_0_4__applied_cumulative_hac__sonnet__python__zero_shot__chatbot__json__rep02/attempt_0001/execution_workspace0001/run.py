import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("input.csv")
df["date"] = pd.to_datetime(df["date"])
df = df.sort_values("date").reset_index(drop=True)

df["dlvix"] = np.log(df["vix"]).diff()
df["lsales"] = np.log(df["sales"])

L = 15
lag_cols = []
for j in range(1, L + 1):
    c = f"lag_{j}"
    df[c] = df["dlvix"].shift(j)
    lag_cols.append(c)

d = df[["lsales"] + lag_cols].dropna()
y = d["lsales"].to_numpy(dtype=float)
X = sm.add_constant(d[lag_cols].to_numpy(dtype=float), has_constant="add")
N, k = X.shape

res = sm.OLS(y, X).fit()
b = res.params
u = res.resid

# Newey-West HAC
Xu = X * u[:, None]
S = Xu.T @ Xu
for j in range(1, L + 1):
    w = 1.0 - j / (L + 1.0)
    G = Xu[j:].T @ Xu[:-j]
    S += w * (G + G.T)
XtX_inv = np.linalg.inv(X.T @ X)
V = XtX_inv @ S @ XtX_inv
V *= N / (N - (L + 1))

a = np.zeros(k)
a[1:] = 1.0
cum = float(a @ b)
cum_se = float(np.sqrt(a @ V @ a))

out = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {"term": "cumulative_response", "estimate": cum, "se": cum_se, "n_obs": int(N)},
        {"term": "lag_1", "estimate": float(b[1]), "se": float(np.sqrt(V[1, 1])), "n_obs": int(N)},
        {"term": "lag_15", "estimate": float(b[15]), "se": float(np.sqrt(V[15, 15])), "n_obs": int(N)},
    ],
    "method_metadata": {
        "estimator": "OLS of log(sales) on intercept and lags 1-15 of diff log(vix)",
        "vcov": "Newey-West HAC, maxlag 15, Bartlett weights 1-j/16, scaled by N/(N-16)",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(out, f, indent=2)
