import json
import numpy as np
import pandas as pd
from scipy import stats

df = pd.read_csv("input.csv")
df = df[["y", "endog", "x", "z1", "z2"]].dropna()
n = len(df)
y = df["y"].to_numpy(float)
e = df["endog"].to_numpy(float)
W = np.column_stack([np.ones(n), df["x"].to_numpy(float)])
X = np.column_stack([W, df["z1"].to_numpy(float), df["z2"].to_numpy(float)])

def resid_maker(M):
    Q, _ = np.linalg.qr(M)
    return lambda v: v - Q @ (Q.T @ v)

rW = resid_maker(W)
rX = resid_maker(X)
yW, eW = rW(y), rW(e)
yX, eX = rX(y), rX(e)

df2 = n - 4
crit = stats.f.ppf(0.95, 2, df2)
k = 2.0 * crit / df2

def F(b):
    rr = np.sum((yW - b * eW) ** 2)
    ru = np.sum((yX - b * eX) ** 2)
    return ((rr - ru) / 2.0) / (ru / df2)

# q(b) = (RSS_r - RSS_u) - k*RSS_u <= 0  <=> accept
# RSS(b) = s_yy - 2b s_ye + b^2 s_ee
def coefs(a, c):
    return np.dot(a, a), np.dot(a, c), np.dot(c, c)

ryy, rye, ree = coefs(yW, eW)
uyy, uye, uee = coefs(yX, eX)
A = (ree - uee) - k * uee
B = -2.0 * ((rye - uye) - k * uye)
C = (ryy - uyy) - k * uyy

disc = B * B - 4 * A * C
roots = []
if disc >= 0 and A != 0:
    sq = np.sqrt(disc)
    roots = sorted([(-B - sq) / (2 * A), (-B + sq) / (2 * A)])
low = float(roots[0]) if roots else None
high = float(roots[1]) if roots else None

accepts_zero = 1.0 if F(0.0) <= crit else 0.0
big = 1e12
unbounded = 1.0 if (F(big) <= crit or F(-big) <= crit or A < 0) else 0.0
f1 = float(F(1.0))

res = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": [
        {"term": "boundary_low", "estimate": low, "se": None, "n_obs": n},
        {"term": "boundary_high", "estimate": high, "se": None, "n_obs": n},
        {"term": "accepts_zero", "estimate": accepts_zero, "se": None, "n_obs": n},
        {"term": "unbounded", "estimate": unbounded, "se": None, "n_obs": n},
        {"term": "ar_f_at_one", "estimate": f1, "se": None, "n_obs": n},
    ],
    "method_metadata": {"estimator": "Anderson-Rubin test inversion (analytic quadratic)",
                        "vcov": "homoskedastic"},
    "diagnostics": {"f_crit": float(crit), "quad_A": float(A), "quad_B": float(B),
                    "quad_C": float(C)},
}
with open("result.json", "w") as fh:
    json.dump(res, fh, indent=2)
