import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("input.csv")
n_full = int(len(df))

d = df[["y", "x", "z"]].apply(pd.to_numeric, errors="coerce").dropna()
d["y"] = d["y"].astype(int)

X = sm.add_constant(d[["x", "z"]], has_constant="add")
model = sm.MNLogit(d["y"], X)
res = model.fit(method="newton", maxiter=200, tol=1e-12, disp=False)
if not res.mle_retvals.get("converged", True):
    res = model.fit(method="bfgs", maxiter=5000, gtol=1e-10, disp=False)

params = res.params
bse = res.bse
# Columns of params correspond to sorted outcomes excluding base (0)
outcomes = sorted(d["y"].unique())
others = [o for o in outcomes if o != 0]
col = {o: params.columns[i] for i, o in enumerate(others)}

c1, c2 = col[1], col[2]

def f(v):
    return float(v)

# Fitted probability of outcome 2 at x=0, z=0
etas = {o: float(params.loc["const", col[o]]) for o in others}
denom = 1.0 + sum(np.exp(v) for v in etas.values())
prob2 = float(np.exp(etas[2]) / denom)

estimates = [
    {"term": "x_cat1", "estimate": f(params.loc["x", c1]), "se": f(bse.loc["x", c1]), "n_obs": n_full},
    {"term": "z_cat1", "estimate": f(params.loc["z", c1]), "se": f(bse.loc["z", c1]), "n_obs": n_full},
    {"term": "x_cat2", "estimate": f(params.loc["x", c2]), "se": f(bse.loc["x", c2]), "n_obs": n_full},
    {"term": "z_cat2", "estimate": f(params.loc["z", c2]), "se": f(bse.loc["z", c2]), "n_obs": n_full},
    {"term": "prob_cat2_zero", "estimate": prob2, "se": None, "n_obs": n_full},
]

result = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "statsmodels MNLogit maximum likelihood, base outcome 0",
        "vcov": "observed information (inverse negative Hessian)",
    },
    "diagnostics": {
        "n_used": int(res.nobs),
        "llf": float(res.llf),
        "converged": bool(res.mle_retvals.get("converged", True)),
    },
}

with open("result.json", "w") as fh:
    json.dump(result, fh, indent=2)
