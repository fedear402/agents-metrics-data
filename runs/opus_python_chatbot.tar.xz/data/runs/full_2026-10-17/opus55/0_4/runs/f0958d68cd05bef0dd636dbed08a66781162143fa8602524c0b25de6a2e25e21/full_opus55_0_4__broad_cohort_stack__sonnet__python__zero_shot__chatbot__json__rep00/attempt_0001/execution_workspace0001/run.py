import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df = df.dropna(subset=["id", "time", "g"])

results = []
atts = {}
weights = {}
nobs = {}

for c in [3, 5, 7]:
    times = list(range(c - 2, c + 3))
    sub = df[df["time"].isin(times)]
    sub = sub[(sub["g"] == c) | (sub["g"] == 0) | (sub["g"] > c + 2)].copy()
    sub = sub.dropna(subset=["y"])
    counts = sub.groupby("id")["time"].nunique()
    keep = counts[counts == len(times)].index
    sub = sub[sub["id"].isin(keep)].copy()
    sub["did"] = ((sub["g"] == c) & (sub["time"] >= c)).astype(float)

    # Two-way within transformation (balanced panel) then OLS
    yv = sub["y"].astype(float)
    dv = sub["did"]
    def demean(v):
        um = v.groupby(sub["id"]).transform("mean")
        tm = v.groupby(sub["time"]).transform("mean")
        return v - um - tm + v.mean()
    yt = demean(yv).to_numpy()
    dt = demean(dv).to_numpy()
    beta = float(np.dot(dt, yt) / np.dot(dt, dt))

    # Cross-check with full dummy regression
    X = pd.get_dummies(sub[["id", "time"]].astype(str), drop_first=True).astype(float)
    X.insert(0, "did", dv.to_numpy())
    X.insert(0, "const", 1.0)
    b, *_ = np.linalg.lstsq(X.to_numpy(), yv.to_numpy(), rcond=None)
    beta = float(b[1])

    atts[c] = beta
    weights[c] = int(sub.loc[sub["g"] == c, "id"].nunique())
    nobs[c] = int(len(sub))
    results.append({"term": f"att_g{c}", "estimate": beta, "se": None, "n_obs": nobs[c]})

wsum = sum(weights.values())
att_w = sum(atts[c] * weights[c] for c in atts) / wsum
results.append({"term": "att_weighted", "estimate": float(att_w), "se": None,
                "n_obs": int(sum(nobs.values()))})

out = {
    "task_id": "broad_cohort_stack",
    "platform": "python",
    "estimates": results,
    "method_metadata": {
        "method": "cohort-specific balanced-window TWFE DiD, treated-unit weighted average",
        "window": "c-2..c+2",
        "controls": "g=0 or g>c+2",
    },
    "diagnostics": {
        "treated_units": {f"g{c}": weights[c] for c in weights},
        "n_obs": {f"g{c}": nobs[c] for c in nobs},
    },
}

with open("result.json", "w") as f:
    json.dump(out, f, indent=2)
