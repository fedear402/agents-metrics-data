import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df = df.drop_duplicates(subset=["id", "time"])

results = []
weights = []
total_n = 0
diag = {}

for c in [3, 5, 7]:
    times = list(range(c - 2, c + 3))
    sub = df[df["time"].isin(times)]
    sub = sub[(sub["g"] == c) | (sub["g"] == 0) | (sub["g"] > c + 2)]
    sub = sub.dropna(subset=["y"])
    counts = sub.groupby("id")["time"].nunique()
    keep = counts[counts == len(times)].index
    sub = sub[sub["id"].isin(keep)].copy()
    sub["did"] = ((sub["g"] == c) & (sub["time"] >= c)).astype(float)

    ids = pd.Categorical(sub["id"])
    tms = pd.Categorical(sub["time"])
    U = pd.get_dummies(ids, drop_first=False).to_numpy(dtype=float)
    T = pd.get_dummies(tms, drop_first=True).to_numpy(dtype=float)
    X = np.column_stack([sub["did"].to_numpy(), U, T])
    y = sub["y"].to_numpy(dtype=float)
    beta, *_ = np.linalg.lstsq(X, y, rcond=None)
    att = float(beta[0])

    n_obs = int(len(sub))
    n_treat = int(sub.loc[sub["g"] == c, "id"].nunique())
    n_ctrl = int(sub.loc[sub["g"] != c, "id"].nunique())
    results.append({"term": f"att_g{c}", "estimate": att, "se": None, "n_obs": n_obs})
    weights.append(n_treat)
    total_n += n_obs
    diag[f"g{c}"] = {"n_treated_units": n_treat, "n_control_units": n_ctrl, "n_obs": n_obs}

w = np.array(weights, dtype=float)
est = np.array([r["estimate"] for r in results])
att_w = float(np.sum(w * est) / np.sum(w))
results.append({"term": "att_weighted", "estimate": att_w, "se": None, "n_obs": int(total_n)})

out = {
    "task_id": "broad_cohort_stack",
    "platform": "python",
    "estimates": results,
    "method_metadata": {
        "method": "cohort-specific two-way fixed effects DiD, windows c-2..c+2, balanced within cohort",
        "weights": "number of retained treated units per cohort",
    },
    "diagnostics": diag,
}

with open("result.json", "w") as f:
    json.dump(out, f, indent=2)
