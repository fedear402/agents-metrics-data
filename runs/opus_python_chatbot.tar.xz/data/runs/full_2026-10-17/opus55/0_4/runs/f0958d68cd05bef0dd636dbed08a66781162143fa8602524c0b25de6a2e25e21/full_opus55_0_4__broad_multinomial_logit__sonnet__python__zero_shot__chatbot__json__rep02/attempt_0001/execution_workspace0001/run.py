import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("input.csv")
n_full = int(len(df))
d = df[["y", "x", "z"]].dropna().copy()
d["y"] = d["y"].astype(int)

X = sm.add_constant(d[["x", "z"]], has_constant="add")
model = sm.MNLogit(d["y"], X)
res = model.fit(method="newton", maxiter=200, disp=False)
if not res.mle_retvals.get("converged", True):
    res = model.fit(method="bfgs", maxiter=2000, disp=False)

params = np.asarray(res.params)  # rows: const,x,z ; cols: outcomes vs base
bse = np.asarray(res.bse)
cats = sorted(d["y"].unique())
# columns correspond to cats[1:]
col = {c: i for i, c in enumerate(cats[1:])}
rows = {"const": 0, "x": 1, "z": 2}

def g(term, cat):
    j = col[cat]
    return float(params[rows[term], j]), float(bse[rows[term], j])

out = []
for cat in (1, 2):
    for term in ("x", "z"):
        est, se = g(term, cat)
        out.append({"term": f"{term}_cat{cat}", "estimate": est, "se": se, "n_obs": n_full})

eta = np.array([0.0] + [params[0, j] for j in range(params.shape[1])])
p = np.exp(eta - eta.max())
p /= p.sum()
p2 = float(p[cats.index(2)])
out.append({"term": "prob_cat2_zero", "estimate": p2, "se": None, "n_obs": n_full})

result = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": out,
    "method_metadata": {
        "estimator": "statsmodels MNLogit maximum likelihood, base outcome 0",
        "vcov": "observed information (inverse Hessian)",
    },
    "diagnostics": {
        "converged": bool(res.mle_retvals.get("converged", True)),
        "llf": float(res.llf),
        "n_used": int(res.nobs),
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
