import json
import numpy as np
import pandas as pd

df = pd.read_csv('input.csv')
df = df.drop_duplicates(subset=['id', 'time'])

results = {}
for c in (3, 5, 7):
    window = list(range(c - 2, c + 3))
    sub = df[df['time'].isin(window)]
    sub = sub[(sub['g'] == c) | (sub['g'] == 0) | (sub['g'] > c + 2)]
    counts = sub.groupby('id')['time'].nunique()
    keep_ids = counts[counts == len(window)].index
    sub = sub[sub['id'].isin(keep_ids)].copy()
    sub['did'] = ((sub['g'] == c) & (sub['time'] >= c)).astype(float)
    # An intercept accompanies one omitted category in each fixed-effect set.
    design = np.column_stack([
        np.ones(len(sub)), sub['did'].to_numpy(),
        pd.get_dummies(sub['id'], drop_first=True, dtype=float).to_numpy(),
        pd.get_dummies(sub['time'], drop_first=True, dtype=float).to_numpy(),
    ])
    coef = np.linalg.lstsq(design, sub['y'].to_numpy(dtype=float), rcond=None)[0]
    n_treated = sub.loc[sub['g'] == c, 'id'].nunique()
    results[c] = (float(coef[1]), int(len(sub)), int(n_treated))

weights = np.array([results[c][2] for c in (3, 5, 7)], dtype=float)
atts = np.array([results[c][0] for c in (3, 5, 7)])
att_weighted = float(np.sum(weights * atts) / np.sum(weights))

estimates = [
    {'term': f'att_g{c}', 'estimate': results[c][0], 'se': None, 'n_obs': results[c][1]}
    for c in (3, 5, 7)
]
estimates.append({'term': 'att_weighted', 'estimate': att_weighted, 'se': None,
                  'n_obs': int(sum(results[c][1] for c in (3, 5, 7)))})

output = {
    'task_id': 'broad_cohort_stack',
    'platform': 'python',
    'estimates': estimates,
    'method_metadata': {},
    'diagnostics': {f'treated_units_g{c}': results[c][2] for c in (3, 5, 7)},
}
with open('result.json', 'w') as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
