import json
import numpy as np
import pandas as pd
from scipy.stats import f

data = pd.read_csv('input.csv')
y = data['y'].to_numpy(float)
d = data['endog'].to_numpy(float)
n = len(y)
controls = np.column_stack([np.ones(n), data['x'].to_numpy(float)])
excluded = data[['z1', 'z2']].to_numpy(float)
full = np.column_stack([controls, excluded])
q = excluded.shape[1]
df = n - full.shape[1]


def residual(v, design):
    return v - design @ np.linalg.lstsq(design, v, rcond=None)[0]


ry, rd = residual(y, controls), residual(d, controls)
uy, ud = residual(y, full), residual(d, full)
critical = f.ppf(.95, q, df)
k = q * critical / df
A = rd @ rd - (1 + k) * (ud @ ud)
B = -2 * (ry @ rd - (1 + k) * (uy @ ud))
C = ry @ ry - (1 + k) * (uy @ uy)


def accepts(beta):
    return A * beta * beta + B * beta + C <= 0


def direct_F(beta):
    r = residual(y - beta * d, controls)
    u = residual(y - beta * d, full)
    return ((r @ r - u @ u) / q) / ((u @ u) / df)


disc = B * B - 4 * A * C
scale = max(abs(A), abs(B), abs(C), 1e-300)
if abs(A) <= 1e-12 * scale or disc <= 0:
    raise RuntimeError('degenerate AR set; expected two finite boundaries')
sq = np.sqrt(disc)
roots = np.sort([(-B - sq) / (2 * A), (-B + sq) / (2 * A)])
low, high = float(roots[0]), float(roots[1])
# A<0: accepted region is the two outer rays (unbounded, disjoint)
unbounded = int(A < 0)
for b in roots:
    assert np.isclose(direct_F(b), critical, rtol=1e-6, atol=1e-6)

rows = [
    {'term': 'boundary_low', 'estimate': low, 'se': None, 'n_obs': n},
    {'term': 'boundary_high', 'estimate': high, 'se': None, 'n_obs': n},
    {'term': 'accepts_zero', 'estimate': int(accepts(0.0)), 'se': None, 'n_obs': n},
    {'term': 'unbounded', 'estimate': unbounded, 'se': None, 'n_obs': n},
    {'term': 'ar_f_at_one', 'estimate': float(direct_F(1.0)), 'se': None, 'n_obs': n},
]
out = {
    'task_id': 'broad_ar_confidence_set',
    'platform': 'python',
    'estimates': rows,
    'method_metadata': {'estimator': 'Anderson-Rubin test inversion (analytic quadratic)',
                        'vcov': 'homoskedastic F(2, n-4)'},
    'diagnostics': {'A': float(A), 'B': float(B), 'C': float(C),
                    'critical_F': float(critical), 'df_denom': int(df)},
}
with open('result.json', 'w') as fh:
    json.dump(out, fh, indent=2, allow_nan=False)
