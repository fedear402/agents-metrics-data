import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df = df.dropna(subset=["id", "time", "g"])

results = []
weights = []
atts = []
nobs_total = 0

for c in [3, 5, 7]:
    times = list(range(c - 2, c + 3))
    sub = df[df["time"].isin(times)]
    sub = sub[(sub["g"] == c) | (sub["g"] == 0) | (sub["g"] > c + 2)].copy()
    sub = sub.dropna(subset=["y"])
    counts = sub.groupby("id")["time"].nunique()
    keep = counts[counts == len(times)].index
    sub = sub[sub["id"].isin(keep)].copy()
    sub["did"] = ((sub["g"] == c) & (sub["time"] >= c)).astype(float)

    unit_d = pd.get_dummies(sub["id"].astype(str), prefix="u", drop_first=False, dtype=float)
    time_d = pd.get_dummies(sub["time"].astype(str), prefix="t", drop_first=True, dtype=float)
    X = np.column_stack([sub["did"].to_numpy(), unit_d.to_numpy(), time_d.to_numpy()])
    yv = sub["y"].to_numpy(dtype=float)
    beta, *_ = np.linalg.lstsq(X, yv, rcond=None)
    att = float(beta[0])

    n_obs = int(len(sub))
    n_treated = int(sub.loc[sub["g"] == c, "id"].nunique())
    results.append({"term": f"att_g{c}", "estimate": att, "se": None, "n_obs": n_obs})
    atts.append(att)
    weights.append(n_treated)
    nobs_total += n_obs

w = np.array(weights, dtype=float)
att_w = float(np.sum(w * np.array(atts)) / np.sum(w))
results.append({"term": "att_weighted", "estimate": att_w, "se": None, "n_obs": int(nobs_total)})

out = {
    "task_id": "broad_cohort_stack",
    "platform": "python",
    "estimates": results,
    "method_metadata": {
        "method": "cohort-specific two-way fixed effects DiD on balanced windows c-2..c+2",
        "weights": "number of retained treated units per cohort",
    },
    "diagnostics": {
        "treated_units": {f"g{c}": int(n) for c, n in zip([3, 5, 7], weights)},
    },
}

with open("result.json", "w") as f:
    json.dump(out, f, indent=2)
