import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df["share"] = df["share"].astype(float)
df["shock"] = df["shock"].astype(float)

reg = df.groupby("region_id", sort=True).agg(
    region_weight=("region_weight", "first"), x=("x", "first"), y=("y", "first")
)
reg["e"] = reg["region_weight"] / reg["region_weight"].sum()
reg["z"] = (df.assign(sz=df["share"] * df["shock"]).groupby("region_id")["sz"].sum()).reindex(reg.index)

e = reg["e"].values
def wmean(v): return np.sum(e * v) / np.sum(e)
for v in ["x", "y", "z"]:
    reg[v + "0"] = reg[v] - wmean(reg[v].values)

def wiv(yv, xv, zv, w):
    yv, xv, zv, w = map(np.asarray, (yv, xv, zv, w))
    X = np.column_stack([np.ones_like(xv), xv])
    Z = np.column_stack([np.ones_like(zv), zv])
    W = w
    ZWX = Z.T @ (W[:, None] * X)
    ZWy = Z.T @ (W * yv)
    b = np.linalg.solve(ZWX, ZWy)
    u = yv - X @ b
    n = len(yv)
    inv = np.linalg.inv(ZWX)
    meat = Z.T @ ((W * u) ** 2)[:, None] * 1.0
    meat = (Z * ((W * u) ** 2)[:, None]).T @ Z
    V = inv @ meat @ inv.T * n / (n - 2)
    return b, np.sqrt(np.diag(V))

b_reg, _ = wiv(reg["y"], reg["x"], reg["z"], e)
b_fs_reg, _ = wiv(reg["x"], reg["z"], reg["z"], e)

m = df.merge(reg[["e", "x0", "y0", "z0"]], left_on="region_id", right_index=True)
m["es"] = m["e"] * m["share"]
g = m.groupby("industry_id", sort=True)
s = g["es"].sum()
shock = g["shock"].first()
bars = {}
for v in ["x0", "y0", "z0"]:
    bars[v] = (m["es"] * m[v]).groupby(m["industry_id"]).sum().reindex(s.index) / s
keep = s > 0
s_k = s[keep].values
sh_k = shock[keep].values
xb, yb, zb = bars["x0"][keep].values, bars["y0"][keep].values, bars["z0"][keep].values
N = int(keep.sum())

b_eff, se_eff = wiv(yb, xb, sh_k, s_k)
b_fs, se_fs = wiv(xb, zb, sh_k, s_k)

eff_shocks = float(1.0 / np.sum(s.values ** 2))

res = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": float(b_reg[1]), "se": float(se_eff[1]), "n_obs": N},
        {"term": "first_stage", "estimate": float(b_fs_reg[1]), "se": float(se_fs[1]), "n_obs": N},
        {"term": "effective_shocks", "estimate": eff_shocks, "se": None, "n_obs": N},
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS with shift-share instrument; BHJ shock-level equivalent IV",
        "vcov": "shock-level HC1 (N/(N-2)), structural IV residuals, analytic weights s_n",
    },
    "diagnostics": {
        "shock_level_effect_slope": float(b_eff[1]),
        "shock_level_first_stage_slope": float(b_fs[1]),
        "n_regions": int(len(reg)),
    },
}
with open("result.json", "w") as f:
    json.dump(res, f, indent=2)
