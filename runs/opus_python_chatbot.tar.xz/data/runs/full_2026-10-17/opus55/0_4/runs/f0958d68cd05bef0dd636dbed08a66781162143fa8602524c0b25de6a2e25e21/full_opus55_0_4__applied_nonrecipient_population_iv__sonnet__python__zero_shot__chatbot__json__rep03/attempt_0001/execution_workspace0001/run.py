import json
import numpy as np
import pandas as pd

hh = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

df = hh[hh["recipient"] == 0].copy()
for c in ["eligible", "dose", "baseline", "instrument", "weight", "outcome"]:
    df[c] = pd.to_numeric(df[c], errors="coerce")
df = df.dropna(subset=["eligible", "dose", "baseline", "instrument", "weight", "outcome"])
df = df[df["weight"] > 0]
df["eligible"] = df["eligible"].astype(int)

e = df["eligible"].values.astype(float)
ne = 1.0 - e
d = df["dose"].values
b = df["baseline"].values
z = df["instrument"].values
w = df["weight"].values
y = df["outcome"].values

X = np.column_stack([d * ne, d * e, ne, e, b * ne, b * e])
Z = np.column_stack([ne, e, b * ne, b * e, z * ne, z * e])

sw = np.sqrt(w)
Xw = X * sw[:, None]
Zw = Z * sw[:, None]
yw = y * sw
PZX = Zw @ np.linalg.lstsq(Zw, Xw, rcond=None)[0]
beta = np.linalg.solve(PZX.T @ Xw, PZX.T @ yw)

n_obs = int(len(df))
mask0 = e == 0
mask1 = e == 1
md0 = float(np.sum(w[mask0] * d[mask0]) / np.sum(w[mask0]))
md1 = float(np.sum(w[mask1] * d[mask1]) / np.sum(w[mask1]))
eff0 = float(beta[0] * md0)
eff1 = float(beta[1] * md1)

census["eligible"] = census["eligible"].astype(int)
pop = census.groupby("eligible")["nonrecipient_population"].sum()
p0 = float(pop.get(0, 0.0))
p1 = float(pop.get(1, 0.0))
pop_eff = float((p0 * eff0 + p1 * eff1) / (p0 + p1))

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {"term": "ineligible_effect", "estimate": eff0, "se": None, "n_obs": n_obs},
        {"term": "eligible_nonrecipient_effect", "estimate": eff1, "se": None, "n_obs": n_obs},
        {"term": "population_effect", "estimate": pop_eff, "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS, group-interacted, no common intercept",
        "endogenous": ["dose*(1-eligible)", "dose*eligible"],
        "exogenous": ["1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"],
        "excluded_instruments": ["instrument*(1-eligible)", "instrument*eligible"],
        "weights": "weight",
        "sample": "recipient == 0",
        "counterfactual": "dose set to zero for every retained household (synthetic convention)",
        "aggregation": "census nonrecipient_population weights",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "n_ineligible": int(mask0.sum()),
        "n_eligible_nonrecipient": int(mask1.sum()),
        "dose_slope_ineligible": float(beta[0]),
        "dose_slope_eligible": float(beta[1]),
        "weighted_mean_dose_ineligible": md0,
        "weighted_mean_dose_eligible": md1,
        "census_pop_ineligible": p0,
        "census_pop_eligible": p1,
        "coefficients": [float(v) for v in beta],
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
