import json
import numpy as np
import pandas as pd

cw = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv")
areas = pd.read_csv("areas.csv")
emp = pd.read_csv("employment.csv")
out = pd.read_csv("outcomes.csv")

for d in (cw, trade):
    d["code"] = d["code"].astype(str).str.strip()
for d in (cw, emp):
    d["industry"] = d["industry"].astype(str).str.strip()
for d in (areas, emp):
    d["vintage"] = d["vintage"].astype(str).str.strip().str.lower()

trade = trade.merge(cw[["code", "industry"]], on="code", how="inner", validate="many_to_one")
industries = sorted(cw["industry"].unique())
periods = sorted(areas["period"].unique())
area_ids = sorted(areas["area"].unique())

def build(vintage, change_col):
    a = areas[areas["vintage"] == vintage].set_index(["area", "period"])
    e = emp[emp["vintage"] == vintage]
    grid = pd.MultiIndex.from_product([area_ids, periods, industries], names=["area", "period", "industry"])
    e = e.groupby(["area", "period", "industry"])["employment"].sum().reindex(grid, fill_value=0.0).reset_index()
    nat = e.groupby(["period", "industry"])["employment"].sum().rename("national").reset_index()
    e = e.merge(nat, on=["period", "industry"])
    e = e.merge(trade[["period", "industry", change_col, "price_index", "years"]],
                on=["period", "industry"], how="left")
    e[change_col] = e[change_col].fillna(0.0)
    e["price_index"] = e.groupby("period")["price_index"].transform(lambda s: s.fillna(s.dropna().iloc[0]))
    e["years"] = e.groupby("period")["years"].transform(lambda s: s.fillna(s.dropna().iloc[0]))
    e["shock"] = e[change_col] / e["national"] / (e["price_index"] / 100) / 1000 * (10 / e["years"])
    e["contrib"] = e["employment"] * e["shock"]
    s = e.groupby(["area", "period"])["contrib"].sum()
    tot = a["total_employment"].reindex(s.index)
    return (s / tot).rename("val")

x = build("base", "us_change").rename("x")
z = build("early", "other_change").rename("z")
pop = areas[areas["vintage"] == "base"].groupby(["area", "period"])["population"].first()

df = out.set_index(["area", "period"]).join(x).join(z).join(pop.rename("w")).reset_index()
df = df.dropna(subset=["change_pp", "control", "x", "z", "w"])

y = df["change_pp"].to_numpy(float)
n = len(df)
ones = np.ones(n)
X = np.column_stack([ones, df["period"].astype(float), df["control"].astype(float), df["x"]])
Z = np.column_stack([ones, df["period"].astype(float), df["control"].astype(float), df["z"]])
sw = np.sqrt(df["w"].to_numpy(float))
Xw, Zw, yw = X * sw[:, None], Z * sw[:, None], y * sw
Xhat = Zw @ np.linalg.lstsq(Zw, Xw, rcond=None)[0]
beta = np.linalg.solve(Xhat.T @ Xw, Xhat.T @ yw)

def get(s, a, p):
    return float(s.loc[(a, p)])

a0 = area_ids[0] if 0 not in area_ids else 0
p0, p1 = periods[0], periods[1]
est = {
    "iv_slope": float(beta[3]),
    "exposure_area0_period0": get(x, a0, p0),
    "exposure_area0_period1": get(x, a0, p1),
    "instrument_area0_period0": get(z, a0, p0),
}
result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [{"term": k, "estimate": float(f"{v:.15g}"), "se": None, "n_obs": int(n)} for k, v in est.items()],
    "method_metadata": {
        "estimator": "weighted 2SLS (numpy)",
        "exogenous": ["intercept", "period", "control"],
        "endogenous": "x", "instrument": "z", "weights": "base-vintage population",
        "exposure_units": "thousands of real dollars per worker per decade",
    },
    "diagnostics": {
        "n_obs": int(n), "n_areas": len(area_ids), "periods": [str(p) for p in periods],
        "n_industries": len(industries), "coefficients": [float(b) for b in beta],
    },
}
with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
