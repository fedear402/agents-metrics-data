import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy.special import softmax

df = pd.read_csv("input.csv")
n_full = int(len(df))
d = df[["y", "x", "z"]].dropna().copy()
y = d["y"].astype(int).to_numpy()
outcomes = sorted(np.unique(y).tolist())
assert outcomes == [0, 1, 2], outcomes

X = pd.DataFrame({"const": np.ones(len(d)), "x": d["x"].to_numpy(dtype=float),
                  "z": d["z"].to_numpy(dtype=float)})
fit = sm.MNLogit(y, X).fit(method="newton", disp=False, tol=1e-10, maxiter=200)

nonbase = outcomes[1:]
coef = fit.params.copy()
se = fit.bse.copy()
assert coef.shape[1] == 2
coef.columns = nonbase
se.columns = nonbase

pred_in = pd.DataFrame({"const": [1.0], "x": [0.0], "z": [0.0]})
pred = pd.Series(np.asarray(fit.predict(pred_in))[0], index=outcomes)
manual = softmax(np.r_[0.0, coef.loc["const", nonbase].to_numpy()])
assert np.allclose(pred.to_numpy(), manual)

def row(term, est, s):
    return {"term": term, "estimate": float(est),
            "se": None if s is None else float(s), "n_obs": n_full}

estimates = [
    row("x_cat1", coef.loc["x", 1], se.loc["x", 1]),
    row("z_cat1", coef.loc["z", 1], se.loc["z", 1]),
    row("x_cat2", coef.loc["x", 2], se.loc["x", 2]),
    row("z_cat2", coef.loc["z", 2], se.loc["z", 2]),
    row("prob_cat2_zero", pred.loc[2], None),
]

out = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {"estimator": "multinomial logit MLE (statsmodels MNLogit), base outcome 0",
                        "vcov": "observed information (inverse Hessian)"},
    "diagnostics": {"converged": bool(fit.mle_retvals.get("converged", True)),
                    "llf": float(fit.llf), "n_used": int(len(d))},
}
with open("result.json", "w") as f:
    json.dump(out, f, indent=2, allow_nan=False)
