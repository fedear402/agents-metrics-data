import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")

reg = df.groupby("region_id").agg(region_weight=("region_weight", "first"),
                                  x=("x", "first"), y=("y", "first")).reset_index()
df = df.copy()
df["sz"] = df["share"] * df["shock"]
z = df.groupby("region_id")["sz"].sum().rename("z").reset_index()
reg = reg.merge(z, on="region_id")
reg["e"] = reg["region_weight"] / reg["region_weight"].sum()

e = reg["e"].values
X = reg["x"].values
Y = reg["y"].values
Z = reg["z"].values


def wiv(yv, xv, zv, w):
    W = np.asarray(w, float)
    Xm = np.column_stack([np.ones_like(xv), xv])
    Zm = np.column_stack([np.ones_like(zv), zv])
    ZWX = Zm.T @ (W[:, None] * Xm)
    ZWy = Zm.T @ (W * yv)
    b = np.linalg.solve(ZWX, ZWy)
    return b, Xm, Zm


def wiv_hc1(yv, xv, zv, w):
    w = np.asarray(w, float)
    b, Xm, Zm = wiv(yv, xv, zv, w)
    u = yv - Xm @ b
    n, k = Xm.shape
    A = np.linalg.inv(Zm.T @ (w[:, None] * Xm))
    meat = (Zm * (w * u)[:, None]).T @ (Zm * (w * u)[:, None])
    V = A @ meat @ A.T * n / (n - k)
    return b, np.sqrt(np.diag(V))


# regional estimates
b_eff, _, _ = wiv(Y, X, Z, e)
b_fs, _, _ = wiv(X, Z, Z, e)

# residualize
y0 = Y - np.sum(e * Y)
x0 = X - np.sum(e * X)
z0 = Z - np.sum(e * Z)
reg["y0"], reg["x0"], reg["z0"] = y0, x0, z0

d = df.merge(reg[["region_id", "e", "y0", "x0", "z0"]], on="region_id")
d["es"] = d["e"] * d["share"]
for v in ["y0", "x0", "z0"]:
    d["w_" + v] = d["es"] * d[v]
ind = d.groupby("industry_id").agg(s=("es", "sum"), wy=("w_y0", "sum"),
                                   wx=("w_x0", "sum"), wz=("w_z0", "sum"),
                                   shock=("shock", "first")).reset_index()
ind = ind[ind["s"] > 0].copy()
s = ind["s"].values
ybar = ind["wy"].values / s
xbar = ind["wx"].values / s
zbar = ind["wz"].values / s
g = ind["shock"].values
N = len(ind)

bs_eff, se_eff = wiv_hc1(ybar, xbar, g, s)
bs_fs, se_fs = wiv_hc1(xbar, zbar, g, s)

eff_shocks = 1.0 / np.sum(s ** 2)

res = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": float(b_eff[1]), "se": float(se_eff[1]), "n_obs": int(N)},
        {"term": "first_stage", "estimate": float(b_fs[1]), "se": float(se_fs[1]), "n_obs": int(N)},
        {"term": "effective_shocks", "estimate": float(eff_shocks), "se": None, "n_obs": int(N)},
    ],
    "method_metadata": {"estimator": "weighted 2SLS shift-share (BHJ shock-level equivalence)",
                        "vcov": "shock-level HC1, N/(N-2), structural IV residuals, analytic weights s_n"},
    "diagnostics": {"shock_level_effect": float(bs_eff[1]),
                    "shock_level_first_stage": float(bs_fs[1]),
                    "n_regions": int(len(reg))},
}
with open("result.json", "w") as f:
    json.dump(res, f, indent=2)
