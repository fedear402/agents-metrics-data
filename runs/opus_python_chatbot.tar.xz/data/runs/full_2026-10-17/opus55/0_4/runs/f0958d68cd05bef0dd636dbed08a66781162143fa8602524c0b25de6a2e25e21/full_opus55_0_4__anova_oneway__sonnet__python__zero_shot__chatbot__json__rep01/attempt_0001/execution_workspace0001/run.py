import json
import numpy as np
import pandas as pd
from scipy import stats

df = pd.read_csv("./input.csv")
n_raw = len(df)
df["y"] = pd.to_numeric(df["y"], errors="coerce")
df = df.dropna(subset=["group", "y"]).copy()
df["group"] = df["group"].astype(str).str.strip()
df = df[df["group"] != ""]
n = len(df)

groups = [g["y"].to_numpy(dtype=float) for _, g in df.groupby("group")]
k = len(groups)
grand = df["y"].mean()
ssb = sum(len(g) * (g.mean() - grand) ** 2 for g in groups)
ssw = sum(((g - g.mean()) ** 2).sum() for g in groups)
df_num = k - 1
df_den = n - k
F = (ssb / df_num) / (ssw / df_den)
p = float(stats.f.sf(F, df_num, df_den))

# cross-check with scipy
F_sp, p_sp = stats.f_oneway(*groups)

result = {
    "task_id": "anova_oneway",
    "platform": "python",
    "estimates": [
        {"term": "F", "estimate": float(F), "se": None, "n_obs": int(n)},
        {"term": "df_num", "estimate": float(df_num), "se": None, "n_obs": int(n)},
        {"term": "df_den", "estimate": float(df_den), "se": None, "n_obs": int(n)},
        {"term": "p_value", "estimate": p, "se": None, "n_obs": int(n)},
    ],
    "method_metadata": {"estimator": "one-way ANOVA (classical, equal variances)", "vcov": "classical"},
    "diagnostics": {
        "n_raw": int(n_raw),
        "n_dropped": int(n_raw - n),
        "n_groups": int(k),
        "group_sizes": {str(name): int(len(g)) for name, g in df.groupby("group")},
        "scipy_F": float(F_sp),
        "scipy_p": float(p_sp),
        "levene_p": float(stats.levene(*groups).pvalue) if k > 1 else None,
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
