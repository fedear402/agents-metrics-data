import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy.special import softmax

df = pd.read_csv("input.csv")
n_full = int(len(df))
d = df[["y", "x", "z"]].dropna().copy()
y = d["y"].astype(int).to_numpy()
outcomes = sorted(np.unique(y).tolist())
assert outcomes == [0, 1, 2]
X = pd.DataFrame({"const": np.ones(len(d)), "x": d["x"].to_numpy(dtype=float),
                  "z": d["z"].to_numpy(dtype=float)})
fit = sm.MNLogit(y, X).fit(method="newton", disp=False, maxiter=200, tol=1e-12)
params = fit.params.copy()
bse = fit.bse.copy()
assert params.shape[1] == 2
params.columns = [1, 2]
bse.columns = [1, 2]

pred_in = pd.DataFrame({"const": [1.0], "x": [0.0], "z": [0.0]})
pred = np.asarray(fit.predict(pred_in))[0]
manual = softmax(np.r_[0.0, params.loc["const", 1], params.loc["const", 2]])
assert np.allclose(pred, manual)
p2 = float(manual[2])

rows = []
for k in (1, 2):
    for v in ("x", "z"):
        rows.append({"term": f"{v}_cat{k}", "estimate": float(params.loc[v, k]),
                     "se": float(bse.loc[v, k]), "n_obs": n_full})
rows.append({"term": "prob_cat2_zero", "estimate": p2, "se": None, "n_obs": n_full})

out = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": rows,
    "method_metadata": {"estimator": "multinomial logit MLE (statsmodels MNLogit), base outcome 0",
                        "vcov": "observed information (inverse Hessian)"},
    "diagnostics": {"converged": bool(fit.mle_retvals.get("converged", True)),
                    "llf": float(fit.llf), "n_used": int(len(d))},
}
with open("result.json", "w") as f:
    json.dump(out, f, indent=2, allow_nan=False)
