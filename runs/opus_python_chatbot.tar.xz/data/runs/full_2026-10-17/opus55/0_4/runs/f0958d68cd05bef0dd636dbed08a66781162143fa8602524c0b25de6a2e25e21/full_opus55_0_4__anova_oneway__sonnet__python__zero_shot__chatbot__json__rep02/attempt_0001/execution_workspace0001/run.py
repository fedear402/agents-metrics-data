import json
import numpy as np
import pandas as pd
from scipy import stats

df = pd.read_csv("./input.csv")
n_raw = len(df)
df["y"] = pd.to_numeric(df["y"], errors="coerce")
df = df.dropna(subset=["group", "y"]).copy()
df["group"] = df["group"].astype(str).str.strip()
df = df[df["group"] != ""]

groups = [g["y"].to_numpy(dtype=float) for _, g in df.groupby("group")]
groups = [g for g in groups if len(g) > 0]
k = len(groups)
n = int(sum(len(g) for g in groups))

grand = np.concatenate(groups).mean()
ssb = sum(len(g) * (g.mean() - grand) ** 2 for g in groups)
ssw = sum(((g - g.mean()) ** 2).sum() for g in groups)
df_num = k - 1
df_den = n - k
if df_num > 0 and df_den > 0 and ssw > 0:
    F = (ssb / df_num) / (ssw / df_den)
    p = float(stats.f.sf(F, df_num, df_den))
else:
    F, p = float("nan"), float("nan")

def num(x):
    x = float(x)
    return None if not np.isfinite(x) else x

res = {
    "task_id": "anova_oneway",
    "platform": "python",
    "estimates": [
        {"term": "F", "estimate": num(F), "se": None, "n_obs": n},
        {"term": "df_num", "estimate": float(df_num), "se": None, "n_obs": n},
        {"term": "df_den", "estimate": float(df_den), "se": None, "n_obs": n},
        {"term": "p_value", "estimate": num(p), "se": None, "n_obs": n},
    ],
    "method_metadata": {"estimator": "one-way ANOVA (classical, equal variances)", "vcov": "classical"},
    "diagnostics": {
        "n_groups": k,
        "n_rows_raw": n_raw,
        "n_dropped": n_raw - n,
        "group_sizes": {str(name): int(len(g)) for name, g in df.groupby("group")},
        "ss_between": float(ssb),
        "ss_within": float(ssw),
    },
}
with open("result.json", "w") as f:
    json.dump(res, f, indent=2)
