import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("input.csv")
df["date"] = pd.to_datetime(df["date"])
df = df.sort_values("date").reset_index(drop=True)

df["lsales"] = np.log(df["sales"].astype(float))
df["dlvix"] = np.log(df["vix"].astype(float)).diff()

L = 15
lag_cols = []
for k in range(1, L + 1):
    c = f"lag_{k}"
    df[c] = df["dlvix"].shift(k)
    lag_cols.append(c)

d = df[["lsales"] + lag_cols].dropna()
y = d["lsales"].to_numpy()
X = sm.add_constant(d[lag_cols].to_numpy(), has_constant="add")
N, K = X.shape

beta, *_ = np.linalg.lstsq(X, y, rcond=None)
u = y - X @ beta

Xu = X * u[:, None]
S = Xu.T @ Xu
for j in range(1, L + 1):
    w = 1.0 - j / (L + 1.0)
    G = Xu[j:].T @ Xu[:-j]
    S += w * (G + G.T)
XtX_inv = np.linalg.inv(X.T @ X)
V = XtX_inv @ S @ XtX_inv
V *= N / (N - K)

r = np.zeros(K)
r[1:] = 1.0
cum = float(r @ beta)
cum_se = float(np.sqrt(r @ V @ r))

lag1 = float(beta[1])
lag1_se = float(np.sqrt(V[1, 1]))
lag15 = float(beta[L])
lag15_se = float(np.sqrt(V[L, L]))

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {"term": "cumulative_response", "estimate": cum, "se": cum_se, "n_obs": int(N)},
        {"term": "lag_1", "estimate": lag1, "se": lag1_se, "n_obs": int(N)},
        {"term": "lag_15", "estimate": lag15, "se": lag15_se, "n_obs": int(N)},
    ],
    "method_metadata": {
        "estimator": "OLS of log(sales) on intercept and lags 1-15 of diff log(vix)",
        "vcov": "Newey-West HAC, maxlag 15, Bartlett weights 1-j/16, scaled by N/(N-16)",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
