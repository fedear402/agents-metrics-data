import json
import numpy as np
import pandas as pd

df = pd.read_csv('input.csv')
df = df.dropna(subset=['id', 'time', 'g'])
df['time'] = df['time'].astype(int)
df['g'] = df['g'].astype(int)

results = {}
for c in (3, 5, 7):
    times = list(range(c - 2, c + 3))
    sub = df[df['time'].isin(times)]
    sub = sub[(sub['g'] == c) | (sub['g'] == 0) | (sub['g'] > c + 2)]
    counts = sub.groupby('id')['time'].nunique()
    keep_ids = counts[counts == len(times)].index
    sub = sub[sub['id'].isin(keep_ids)].sort_values(['id', 'time']).reset_index(drop=True)
    did = ((sub['g'] == c) & (sub['time'] >= c)).astype(float).to_numpy()
    design = np.column_stack([
        np.ones(len(sub)), did,
        pd.get_dummies(sub['id'], drop_first=True, dtype=float).to_numpy(),
        pd.get_dummies(sub['time'], drop_first=True, dtype=float).to_numpy(),
    ])
    coef = np.linalg.lstsq(design, sub['y'].to_numpy(dtype=float), rcond=None)[0]
    n_treated = sub.loc[sub['g'] == c, 'id'].nunique()
    results[c] = (float(coef[1]), int(len(sub)), int(n_treated))

weights = np.array([results[c][2] for c in (3, 5, 7)], dtype=float)
atts = np.array([results[c][0] for c in (3, 5, 7)])
att_weighted = float(np.sum(weights * atts) / np.sum(weights))
total_n = int(sum(results[c][1] for c in (3, 5, 7)))

estimates = [
    {'term': f'att_g{c}', 'estimate': results[c][0], 'se': None, 'n_obs': results[c][1]}
    for c in (3, 5, 7)
]
estimates.append({'term': 'att_weighted', 'estimate': att_weighted, 'se': None, 'n_obs': total_n})

output = {
    'task_id': 'broad_cohort_stack',
    'platform': 'python',
    'estimates': estimates,
    'method_metadata': {
        'window': 'c-2 through c+2',
        'controls': 'g=0 or g>c+2',
        'balance': 'per-cohort, all five window times',
        'weights': 'retained treated units per cohort',
    },
    'diagnostics': {
        f'treated_units_g{c}': results[c][2] for c in (3, 5, 7)
    },
}

with open('result.json', 'w') as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
