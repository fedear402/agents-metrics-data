import json
import numpy as np
import pandas as pd

df = pd.read_csv('input.csv')
regions = df.groupby('region_id').first()[['region_weight', 'x', 'y']].sort_index()
inds = df.groupby('industry_id')['shock'].first().sort_index()
S = df.pivot_table(index='region_id', columns='industry_id', values='share',
                   aggfunc='sum', fill_value=0.0).reindex(index=regions.index, columns=inds.index, fill_value=0.0).values
g = inds.values.astype(float)
e = regions['region_weight'].values.astype(float)
e = e / e.sum()
x = regions['x'].values.astype(float)
y = regions['y'].values.astype(float)
z = S @ g

reg = np.column_stack([y, x, z])
cen = reg - e @ reg
mass = e @ S
keep = mass > 0
agg = (S.T @ (e[:, None] * cen))[keep] / mass[keep][:, None]
m = mass[keep]
gk = g[keep]
N = int(keep.sum())


def shock_iv(dep, endo):
    X = np.column_stack([np.ones(N), endo])
    Z = np.column_stack([np.ones(N), gk])
    cross = Z.T @ (m[:, None] * X)
    beta = np.linalg.solve(cross, Z.T @ (m * dep))
    u = dep - X @ beta
    sc = Z * (m * u)[:, None]
    inv = np.linalg.inv(cross)
    V = N / (N - 2) * inv @ (sc.T @ sc) @ inv.T
    return float(beta[1]), float(np.sqrt(V[1, 1]))


b_eff, se_eff = shock_iv(agg[:, 0], agg[:, 1])
b_fs, se_fs = shock_iv(agg[:, 1], agg[:, 2])
reg_eff = np.sum(e * cen[:, 2] * cen[:, 0]) / np.sum(e * cen[:, 2] * cen[:, 1])
reg_fs = np.sum(e * cen[:, 2] * cen[:, 1]) / np.sum(e * cen[:, 2] ** 2)
eff_shocks = float(1.0 / np.sum(mass ** 2))

out = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": float(reg_eff), "se": se_eff, "n_obs": N},
        {"term": "first_stage", "estimate": float(reg_fs), "se": se_fs, "n_obs": N},
        {"term": "effective_shocks", "estimate": eff_shocks, "se": None, "n_obs": N},
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS with shift-share instrument; BHJ shock-level equivalent IV",
        "vcov": "shock-level HC1 (N/(N-2)), structural IV residuals, analytic weights s_n",
    },
    "diagnostics": {
        "shock_level_effect_slope": b_eff,
        "shock_level_first_stage_slope": b_fs,
        "n_regions": int(len(e)),
    },
}
with open('result.json', 'w') as f:
    json.dump(out, f, indent=2, allow_nan=False)
