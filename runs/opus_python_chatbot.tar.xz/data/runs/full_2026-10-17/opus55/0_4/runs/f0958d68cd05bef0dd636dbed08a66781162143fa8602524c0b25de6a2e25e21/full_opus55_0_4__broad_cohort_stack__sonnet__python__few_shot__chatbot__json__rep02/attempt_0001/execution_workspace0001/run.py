import json
import numpy as np
import pandas as pd

df = pd.read_csv('input.csv')
df = df.dropna(subset=['id', 'time', 'g'])

results = {}
for c in (3, 5, 7):
    window = list(range(c - 2, c + 3))
    sub = df[df['time'].isin(window)].copy()
    sub = sub[(sub['g'] == c) | (sub['g'] == 0) | (sub['g'] > c + 2)]
    sub = sub.dropna(subset=['y'])
    counts = sub.groupby('id')['time'].nunique()
    keep_ids = counts[counts == len(window)].index
    sub = sub[sub['id'].isin(keep_ids)].copy()
    sub['did'] = ((sub['g'] == c) & (sub['time'] >= c)).astype(float)
    # An intercept accompanies one omitted category in each fixed-effect set.
    design = np.column_stack([
        np.ones(len(sub)), sub['did'].to_numpy(),
        pd.get_dummies(sub['id'], drop_first=True, dtype=float).to_numpy(),
        pd.get_dummies(sub['time'], drop_first=True, dtype=float).to_numpy(),
    ])
    coef = np.linalg.lstsq(design, sub['y'].to_numpy(dtype=float), rcond=None)[0]
    n_treated = sub.loc[sub['g'] == c, 'id'].nunique()
    results[c] = (float(coef[1]), int(len(sub)), int(n_treated))

total_w = sum(r[2] for r in results.values())
weighted = sum(r[0] * r[2] for r in results.values()) / total_w
rows = [
    {'term': f'att_g{c}', 'estimate': results[c][0], 'se': None, 'n_obs': results[c][1]}
    for c in (3, 5, 7)
]
rows.append({'term': 'att_weighted', 'estimate': float(weighted), 'se': None,
             'n_obs': int(sum(r[1] for r in results.values()))})

output = {
    'task_id': 'broad_cohort_stack',
    'platform': 'python',
    'estimates': rows,
    'method_metadata': {},
    'diagnostics': {f'treated_units_g{c}': results[c][2] for c in (3, 5, 7)},
}
with open('result.json', 'w') as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
