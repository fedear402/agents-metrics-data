import json
import numpy as np
import pandas as pd
from scipy import stats

df = pd.read_csv("./input.csv")
df = df[["group", "y"]].copy()
df["y"] = pd.to_numeric(df["y"], errors="coerce")
df = df.dropna(subset=["group", "y"])
df["group"] = df["group"].astype(str)

groups = [g["y"].to_numpy(dtype=float) for _, g in df.groupby("group", sort=True)]
groups = [g for g in groups if len(g) > 0]
n = int(sum(len(g) for g in groups))
k = len(groups)

grand = np.concatenate(groups).mean()
ssb = float(sum(len(g) * (g.mean() - grand) ** 2 for g in groups))
ssw = float(sum(((g - g.mean()) ** 2).sum() for g in groups))
df_num = k - 1
df_den = n - k
msb = ssb / df_num
msw = ssw / df_den
F = msb / msw if msw > 0 else float("inf")
p_value = float(stats.f.sf(F, df_num, df_den))

out = {
    "task_id": "anova_oneway",
    "platform": "python",
    "estimates": [
        {"term": "F", "estimate": float(F), "se": None, "n_obs": n},
        {"term": "df_num", "estimate": float(df_num), "se": None, "n_obs": n},
        {"term": "df_den", "estimate": float(df_den), "se": None, "n_obs": n},
        {"term": "p_value", "estimate": p_value, "se": None, "n_obs": n},
    ],
    "method_metadata": {"estimator": "one-way ANOVA (classical F test, equal variances)",
                        "vcov": "none"},
    "diagnostics": {"n_groups": k, "ss_between": ssb, "ss_within": ssw},
}
with open("result.json", "w") as f:
    json.dump(out, f)
