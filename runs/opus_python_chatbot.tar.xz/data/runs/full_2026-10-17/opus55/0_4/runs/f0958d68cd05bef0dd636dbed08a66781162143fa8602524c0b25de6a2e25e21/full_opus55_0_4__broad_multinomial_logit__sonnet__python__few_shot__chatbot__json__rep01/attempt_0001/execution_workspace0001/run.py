import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("input.csv")
n_full = int(len(df))
d = df[["y", "x", "z"]].dropna().copy()
d["y"] = d["y"].astype(int)

outcomes = sorted(d["y"].unique().tolist())
assert outcomes == [0, 1, 2], outcomes

X = pd.DataFrame({"const": np.ones(len(d)), "x": d["x"].to_numpy(float), "z": d["z"].to_numpy(float)})
yv = d["y"].to_numpy()

fit = sm.MNLogit(yv, X).fit(method="newton", disp=False, maxiter=200, tol=1e-12)
params = fit.params.copy()
bse = fit.bse.copy()
# Columns enumerate nonbase outcomes 1 and 2 in order
nonbase = outcomes[1:]
params.columns = nonbase
bse.columns = nonbase

pred_in = pd.DataFrame({"const": [1.0], "x": [0.0], "z": [0.0]})
pred = np.asarray(fit.predict(pred_in))[0]
eta = np.r_[0.0, params.loc["const", 1], params.loc["const", 2]]
manual = np.exp(eta - eta.max())
manual /= manual.sum()
assert np.allclose(pred, manual)
prob2 = float(manual[2])

def row(term, est, se):
    return {"term": term, "estimate": float(est),
            "se": None if se is None else float(se), "n_obs": n_full}

estimates = [
    row("x_cat1", params.loc["x", 1], bse.loc["x", 1]),
    row("z_cat1", params.loc["z", 1], bse.loc["z", 1]),
    row("x_cat2", params.loc["x", 2], bse.loc["x", 2]),
    row("z_cat2", params.loc["z", 2], bse.loc["z", 2]),
    row("prob_cat2_zero", prob2, None),
]

out = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {"estimator": "multinomial logit MLE (statsmodels MNLogit), base outcome 0",
                        "vcov": "observed information (inverse Hessian)"},
    "diagnostics": {"converged": bool(fit.mle_retvals.get("converged", True)),
                    "llf": float(fit.llf), "n_used": int(len(d))},
}
with open("result.json", "w") as f:
    json.dump(out, f, indent=2, allow_nan=False)
