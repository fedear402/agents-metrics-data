import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df["g"] = df["g"].fillna(0)

results = []
atts, weights, nobs_list = [], [], []
diag = {}

for c in (3, 5, 7):
    times = list(range(c - 2, c + 3))
    sub = df[df["time"].isin(times)]
    sub = sub[(sub["g"] == c) | (sub["g"] == 0) | (sub["g"] > c + 2)].copy()
    sub = sub.dropna(subset=["y"])
    cnt = sub.groupby("id")["time"].nunique()
    keep = cnt[cnt == len(times)].index
    sub = sub[sub["id"].isin(keep)].copy()
    sub["did"] = ((sub["g"] == c) & (sub["time"] >= c)).astype(float)

    # Two-way within transformation via dummies (exact OLS)
    X = pd.concat(
        [
            sub[["did"]].reset_index(drop=True),
            pd.get_dummies(sub["id"].astype(str), prefix="u", drop_first=False).reset_index(drop=True).astype(float),
            pd.get_dummies(sub["time"].astype(str), prefix="t", drop_first=True).reset_index(drop=True).astype(float),
        ],
        axis=1,
    )
    yv = sub["y"].to_numpy(dtype=float)
    beta, *_ = np.linalg.lstsq(X.to_numpy(dtype=float), yv, rcond=None)
    att = float(beta[0])
    n_obs = int(len(sub))
    n_treat = int(sub.loc[sub["g"] == c, "id"].nunique())

    atts.append(att)
    weights.append(n_treat)
    nobs_list.append(n_obs)
    diag[f"g{c}"] = {
        "n_treated_units": n_treat,
        "n_units": int(sub["id"].nunique()),
        "n_obs": n_obs,
    }
    results.append(
        {"term": f"att_g{c}", "estimate": att, "se": None, "n_obs": n_obs}
    )

w = np.array(weights, dtype=float)
att_w = float(np.sum(w * np.array(atts)) / w.sum())
results.append(
    {"term": "att_weighted", "estimate": att_w, "se": None, "n_obs": int(sum(nobs_list))}
)

out = {
    "task_id": "broad_cohort_stack",
    "platform": "python",
    "estimates": results,
    "method_metadata": {
        "method": "cohort-specific TWFE DiD, windows c-2..c+2, balanced per cohort",
        "weights": "number of retained treated units per cohort",
    },
    "diagnostics": diag,
}

with open("result.json", "w") as f:
    json.dump(out, f, indent=2)
