import json
import numpy as np
import pandas as pd

cw = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv")
areas = pd.read_csv("areas.csv")
emp = pd.read_csv("employment.csv")
out = pd.read_csv("outcomes.csv")

for df in (cw, trade):
    df["code"] = df["code"].astype(str).str.strip()
for df in (areas, emp):
    df["vintage"] = df["vintage"].astype(str).str.strip().str.lower()

tr = trade.merge(cw, on="code", how="inner")
industries = sorted(cw["industry"].unique().tolist())

def exposure(period, vintage, change_col):
    a = areas[(areas.period == period) & (areas.vintage == vintage)].copy()
    a = a.drop_duplicates("area").set_index("area")
    e = emp[(emp.period == period) & (emp.vintage == vintage)]
    piv = (e.pivot_table(index="area", columns="industry", values="employment",
                         aggfunc="sum")
           .reindex(index=a.index, columns=industries).fillna(0.0))
    national = piv.sum(axis=0)
    t = tr[tr.period == period].groupby("industry").agg(
        change=(change_col, "sum"), price=("price_index", "first"),
        years=("years", "first")).reindex(industries)
    t["change"] = t["change"].fillna(0.0)
    price = t["price"].dropna().iloc[0]
    years = t["years"].dropna().iloc[0]
    shock = t["change"].values / national.values / (price / 100.0) / 1000.0 * (10.0 / years)
    val = piv.values @ shock / a["total_employment"].astype(float).values
    return pd.Series(val, index=a.index)

rows = []
for p in sorted(out["period"].unique()):
    x = exposure(p, "base", "us_change")
    z = exposure(p, "early", "other_change")
    pop = (areas[(areas.period == p) & (areas.vintage == "base")]
           .drop_duplicates("area").set_index("area")["population"])
    d = pd.DataFrame({"x": x, "z": z, "w": pop.reindex(x.index)})
    d["area"] = d.index
    d["period"] = p
    rows.append(d.reset_index(drop=True))
ex = pd.concat(rows, ignore_index=True)
data = out.merge(ex, on=["area", "period"], how="inner").dropna(
    subset=["change_pp", "control", "x", "z", "w"])

n = len(data)
y = data["change_pp"].values.astype(float)
const = np.ones(n)
X = np.column_stack([const, data["period"].astype(float), data["control"].astype(float), data["x"]])
Z = np.column_stack([const, data["period"].astype(float), data["control"].astype(float), data["z"]])
sw = np.sqrt(data["w"].values.astype(float))
Xw, Zw, yw = X * sw[:, None], Z * sw[:, None], y * sw
Pz_X = Zw @ np.linalg.lstsq(Zw, Xw, rcond=None)[0]
beta = np.linalg.solve(Pz_X.T @ Xw, Pz_X.T @ yw)
iv_slope = float(beta[-1])

def get(p, col):
    r = data[(data.area == 0) & (data.period == p)]
    if len(r) == 0:
        r = ex[(ex.area == 0) & (ex.period == p)]
    return float(r[col].iloc[0])

periods = sorted(out["period"].unique())
est = {
    "iv_slope": iv_slope,
    "exposure_area0_period0": get(periods[0], "x"),
    "exposure_area0_period1": get(periods[1], "x"),
    "instrument_area0_period0": get(periods[0], "z"),
}
result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [{"term": k, "estimate": float(f"{v:.15g}"), "se": None, "n_obs": int(n)}
                  for k, v in est.items()],
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "dependent": "change_pp",
        "exogenous": ["intercept", "period", "control"],
        "endogenous": "x", "instrument": "z",
        "weights": "base-vintage population",
    },
    "diagnostics": {"n_obs": int(n), "n_industries": len(industries),
                    "coefficients": [float(b) for b in beta]},
}
with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
