import json
import numpy as np
import pandas as pd
from scipy import stats

df = pd.read_csv("./input.csv")
df = df[["group", "y"]].copy()
df["y"] = pd.to_numeric(df["y"], errors="coerce")
df = df.dropna(subset=["group", "y"])
df["group"] = df["group"].astype(str)

groups = [g["y"].to_numpy(dtype=float) for _, g in df.groupby("group", sort=True)]
groups = [g for g in groups if len(g) > 0]
n = int(sum(len(g) for g in groups))
k = len(groups)

grand_mean = df["y"].mean()
ss_between = sum(len(g) * (g.mean() - grand_mean) ** 2 for g in groups)
ss_within = sum(((g - g.mean()) ** 2).sum() for g in groups)
df_num = k - 1
df_den = n - k
ms_between = ss_between / df_num
ms_within = ss_within / df_den
F = ms_between / ms_within
p_value = float(stats.f.sf(F, df_num, df_den))

out = {
    "task_id": "anova_oneway",
    "platform": "python",
    "estimates": [
        {"term": "F", "estimate": float(F), "se": None, "n_obs": n},
        {"term": "df_num", "estimate": float(df_num), "se": None, "n_obs": n},
        {"term": "df_den", "estimate": float(df_den), "se": None, "n_obs": n},
        {"term": "p_value", "estimate": p_value, "se": None, "n_obs": n},
    ],
    "method_metadata": {"estimator": "One-way ANOVA (classical F test, equal variances)",
                        "vcov": "none"},
    "diagnostics": {"n_groups": k, "ss_between": float(ss_between),
                    "ss_within": float(ss_within)},
}
with open("result.json", "w") as f:
    json.dump(out, f)
