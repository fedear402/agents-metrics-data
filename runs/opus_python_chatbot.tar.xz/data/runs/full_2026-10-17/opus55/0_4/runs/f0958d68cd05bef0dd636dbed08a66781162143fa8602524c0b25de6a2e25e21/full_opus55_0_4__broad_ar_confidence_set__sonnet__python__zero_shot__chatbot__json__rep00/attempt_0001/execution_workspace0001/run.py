import json
import numpy as np
import pandas as pd
from scipy import stats

df = pd.read_csv("input.csv")
df = df[["y", "endog", "x", "z1", "z2"]].dropna()
n = len(df)
y = df["y"].to_numpy(float)
d = df["endog"].to_numpy(float)
W = np.column_stack([np.ones(n), df["x"].to_numpy(float)])
Z = np.column_stack([W, df["z1"].to_numpy(float), df["z2"].to_numpy(float)])

def resid_maker(X):
    Q, _ = np.linalg.qr(X)
    return lambda v: v - Q @ (Q.T @ v)

MW = resid_maker(W)
MZ = resid_maker(Z)
dfd = n - 4
crit = stats.f.ppf(0.95, 2, dfd)
k = 2.0 * crit / dfd

def AR_F(b):
    e = y - b * d
    ru = MZ(e); rr = MW(e)
    rss_u = ru @ ru; rss_r = rr @ rr
    return ((rss_r - rss_u) / 2.0) / (rss_u / dfd)

# quadratic form: e'(M_W - (1+k) M_Z)e <= 0
def qf(u, v):
    return MW(u) @ MW(v) - (1 + k) * (MZ(u) @ MZ(v))

a = qf(d, d)
bq = -2.0 * qf(d, y)
cq = qf(y, y)
disc = bq * bq - 4 * a * cq

def accepted(b):
    return AR_F(b) <= crit

roots = []
if disc >= 0 and a != 0:
    s = np.sqrt(disc)
    roots = sorted([(-bq - s) / (2 * a), (-bq + s) / (2 * a)])

if len(roots) == 2:
    lo, hi = float(roots[0]), float(roots[1])
else:
    lo, hi = float("nan"), float("nan")

# unbounded: large |beta| accepted iff leading coef a <= 0
unbounded = 1 if a <= 0 else 0
accepts_zero = 1 if accepted(0.0) else 0
f1 = float(AR_F(1.0))

if a > 0 and len(roots) == 2:
    settype = "bounded_interval"
elif a < 0 and len(roots) == 2:
    settype = "union_of_two_rays"
elif a < 0:
    settype = "real_line"
else:
    settype = "empty_or_degenerate"

out = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": [
        {"term": "boundary_low", "estimate": lo, "se": None, "n_obs": n},
        {"term": "boundary_high", "estimate": hi, "se": None, "n_obs": n},
        {"term": "accepts_zero", "estimate": float(accepts_zero), "se": None, "n_obs": n},
        {"term": "unbounded", "estimate": float(unbounded), "se": None, "n_obs": n},
        {"term": "ar_f_at_one", "estimate": f1, "se": None, "n_obs": n},
    ],
    "method_metadata": {
        "estimator": "Anderson-Rubin test inversion (analytic quadratic)",
        "vcov": "homoskedastic F(2, n-4)",
    },
    "diagnostics": {
        "critical_value": float(crit),
        "quad_a": float(a), "quad_b": float(bq), "quad_c": float(cq),
        "set_type": settype,
    },
}
with open("result.json", "w") as f:
    json.dump(out, f, indent=2)
