import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy.special import softmax

df = pd.read_csv("input.csv")
df = df[["y", "x", "z"]].dropna()
y = df["y"].astype(int).to_numpy()
n = int(len(df))

outcomes = sorted(np.unique(y).tolist())
assert outcomes == [0, 1, 2]
nonbase = outcomes[1:]

X = pd.DataFrame({"const": np.ones(n), "x": df["x"].to_numpy(float), "z": df["z"].to_numpy(float)})
fit = sm.MNLogit(y, X).fit(method="newton", maxiter=200, tol=1e-10, disp=False)

params = fit.params.copy()
bse = fit.bse.copy()
assert params.shape[1] == 2
params.columns = nonbase
bse.columns = nonbase

pred = np.asarray(fit.predict(pd.DataFrame({"const": [1.0], "x": [0.0], "z": [0.0]})))[0]
manual = softmax(np.r_[0.0, params.loc["const", nonbase].to_numpy()])
assert np.allclose(pred, manual)
prob2 = float(manual[2])

def row(term, est, se):
    return {"term": term, "estimate": float(est), "se": None if se is None else float(se), "n_obs": n}

estimates = [
    row("x_cat1", params.loc["x", 1], bse.loc["x", 1]),
    row("z_cat1", params.loc["z", 1], bse.loc["z", 1]),
    row("x_cat2", params.loc["x", 2], bse.loc["x", 2]),
    row("z_cat2", params.loc["z", 2], bse.loc["z", 2]),
    row("prob_cat2_zero", prob2, None),
]

out = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {"estimator": "multinomial logit MLE (statsmodels MNLogit), base outcome 0",
                        "vcov": "observed information (inverse Hessian)"},
    "diagnostics": {"converged": bool(fit.mle_retvals.get("converged", True)),
                    "llf": float(fit.llf)},
}
with open("result.json", "w") as f:
    json.dump(out, f, indent=2, allow_nan=False)
