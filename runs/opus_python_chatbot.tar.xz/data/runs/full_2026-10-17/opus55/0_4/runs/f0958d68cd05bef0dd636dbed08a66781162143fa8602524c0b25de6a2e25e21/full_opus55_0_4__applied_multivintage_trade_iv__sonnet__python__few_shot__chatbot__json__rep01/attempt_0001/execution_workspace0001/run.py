import json
import numpy as np
import pandas as pd

cw = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv")
areas = pd.read_csv("areas.csv")
emp = pd.read_csv("employment.csv")
out = pd.read_csv("outcomes.csv")

for d in (cw, trade):
    d["code"] = d["code"].astype(str).str.strip()
for d in (areas, emp):
    d["vintage"] = d["vintage"].astype(str).str.strip().str.lower()

tr = trade.merge(cw[["code", "industry"]], on="code", how="left")
if tr["industry"].isna().any():
    raise ValueError("unmatched trade codes")
tr = tr.groupby(["period", "industry"], as_index=False).agg(
    us_change=("us_change", "sum"), other_change=("other_change", "sum"),
    price_index=("price_index", "first"), years=("years", "first"))

industries = sorted(set(cw["industry"]) | set(emp["industry"]) | set(tr["industry"]))
area_ids = sorted(areas["area"].unique())
periods = sorted(out["period"].unique())

def build(vintage, change_col):
    e = emp[emp["vintage"] == vintage]
    a = areas[areas["vintage"] == vintage].groupby(["area", "period"])["total_employment"].first()
    res = {}
    for p in periods:
        ep = e[e["period"] == p].pivot_table(index="area", columns="industry",
                                              values="employment", aggfunc="sum")
        ep = ep.reindex(index=area_ids, columns=industries).fillna(0.0)
        national = ep.sum(axis=0)
        tp = tr[tr["period"] == p].set_index("industry").reindex(industries)
        shock = (tp[change_col] / national / (tp["price_index"] / 100.0) / 1000.0
                 * (10.0 / tp["years"])).fillna(0.0)
        num = ep.values @ shock.values
        for i, ar in enumerate(area_ids):
            res[(ar, p)] = num[i] / a.loc[(ar, p)]
    return res

xd = build("base", "us_change")
zd = build("early", "other_change")

pop = areas[areas["vintage"] == "base"].groupby(["area", "period"])["population"].first()
df = out.copy()
df["x"] = [xd[(a, p)] for a, p in zip(df["area"], df["period"])]
df["z"] = [zd[(a, p)] for a, p in zip(df["area"], df["period"])]
df["w"] = [pop.loc[(a, p)] for a, p in zip(df["area"], df["period"])]
df = df.dropna(subset=["change_pp", "control", "x", "z", "w"])

per = pd.to_numeric(df["period"], errors="coerce")
if per.isna().any():
    per = pd.Series(pd.factorize(df["period"], sort=True)[0], index=df.index)
y = df["change_pp"].values.astype(float)
X = np.column_stack([np.ones(len(df)), per.values.astype(float),
                     df["control"].values.astype(float), df["x"].values])
Z = np.column_stack([X[:, :3], df["z"].values])
sw = np.sqrt(df["w"].values.astype(float))
Xw, Zw, yw = X * sw[:, None], Z * sw[:, None], y * sw
Pz = Zw @ np.linalg.pinv(Zw.T @ Zw) @ Zw.T
beta = np.linalg.solve(Xw.T @ Pz @ Xw, Xw.T @ Pz @ yw)
n = int(len(df))

p0, p1 = periods[0], periods[1]
a0 = area_ids[0]
est = {
    "iv_slope": float(beta[3]),
    "exposure_area0_period0": float(xd[(a0, p0)]),
    "exposure_area0_period1": float(xd[(a0, p1)]),
    "instrument_area0_period0": float(zd[(a0, p0)]),
}
first = np.linalg.lstsq(Zw, Xw[:, 3], rcond=None)[0]
result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [{"term": k, "estimate": v, "se": None, "n_obs": n} for k, v in est.items()],
    "method_metadata": {
        "estimator": "weighted 2SLS (manual)",
        "exogenous": ["intercept", "period", "control"],
        "endogenous": "x", "instrument": "z", "weights": "base-vintage population",
        "missing_employment": "zero",
    },
    "diagnostics": {
        "n_obs": n, "n_areas": len(area_ids), "periods": [str(p) for p in periods],
        "n_industries": len(industries),
        "coefficients": [float(b) for b in beta],
        "first_stage_z_coef": float(first[3]),
    },
}
with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
