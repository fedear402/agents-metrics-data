import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df = df.dropna(subset=["score", "participated", "earnings"])
d = df[np.abs(df["score"]) < 1].copy()

s = d["score"].to_numpy(dtype=float)
w = 1.0 - np.abs(s)
right = (s >= 0).astype(float)
X = np.column_stack([np.ones_like(s), right, s, right * s])
y = d["earnings"].to_numpy(dtype=float)
t = d["participated"].to_numpy(dtype=float)
n = len(s)

XtWX = X.T @ (X * w[:, None])
bread = np.linalg.inv(XtWX)

def fit(v):
    b = bread @ (X.T @ (w * v))
    return b, v - X @ b

by, ey = fit(y)
bt, et = fit(t)

def cov(e1, e2):
    meat = (X * (w * w * e1 * e2)[:, None]).T @ X
    return bread @ meat @ bread

k = 1
rf = by[k]
fs = bt[k]
v_rf = cov(ey, ey)[k, k]
v_fs = cov(et, et)[k, k]
c_rf_fs = cov(ey, et)[k, k]

te = rf / fs
g = np.array([1.0 / fs, -rf / fs ** 2])
V = np.array([[v_rf, c_rf_fs], [c_rf_fs, v_fs]])
v_te = float(g @ V @ g)

res = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": float(te), "se": float(np.sqrt(v_te)), "n_obs": int(n)},
        {"term": "reduced_form", "estimate": float(rf), "se": float(np.sqrt(v_rf)), "n_obs": int(n)},
        {"term": "first_stage", "estimate": float(fs), "se": float(np.sqrt(v_fs)), "n_obs": int(n)},
    ],
    "method_metadata": {
        "estimator": "fuzzy RD, local linear, triangular kernel, h=1, cutoff 0, ratio of WLS discontinuities",
        "vcov": "HC0 sandwich; delta method with joint RF/FS covariance",
    },
    "diagnostics": {
        "cov_rf_fs": float(c_rf_fs),
        "n_left": int((s < 0).sum()),
        "n_right": int((s >= 0).sum()),
    },
}

with open("result.json", "w") as f:
    json.dump(res, f, indent=2)
