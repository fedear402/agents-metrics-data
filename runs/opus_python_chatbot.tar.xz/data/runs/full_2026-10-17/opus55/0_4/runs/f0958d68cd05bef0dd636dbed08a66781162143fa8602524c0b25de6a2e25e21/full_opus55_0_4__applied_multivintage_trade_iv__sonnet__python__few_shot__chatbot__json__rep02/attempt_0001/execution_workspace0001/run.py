import json
import numpy as np
import pandas as pd

cw = pd.read_csv("crosswalk.csv")
tr = pd.read_csv("trade.csv")
ar = pd.read_csv("areas.csv")
em = pd.read_csv("employment.csv")
oc = pd.read_csv("outcomes.csv")

for d in (cw, tr):
    d["code"] = d["code"].astype(str).str.strip()
for d in (ar, em):
    d["vintage"] = d["vintage"].astype(str).str.strip().str.lower()
cw["industry"] = cw["industry"].astype(str).str.strip()
em["industry"] = em["industry"].astype(str).str.strip()

tr = tr.merge(cw[["code", "industry"]], on="code", how="left")
industries = sorted(set(cw["industry"]) | set(em["industry"]))
areas = sorted(ar["area"].unique())
periods = sorted(ar["period"].unique())

def exposures(vintage, change_col):
    out = {}
    for p in periods:
        e = em[(em.period == p) & (em.vintage == vintage)]
        mat = (e.groupby(["area", "industry"])["employment"].sum()
                .unstack(fill_value=0.0)
                .reindex(index=areas, columns=industries, fill_value=0.0)
                .fillna(0.0))
        national = mat.sum(axis=0)
        t = tr[tr.period == p].groupby("industry").first().reindex(industries)
        change = t[change_col].fillna(0.0).astype(float)
        price = float(tr.loc[tr.period == p, "price_index"].iloc[0])
        yrs = float(tr.loc[tr.period == p, "years"].iloc[0])
        shock = change / national / (price / 100.0) / 1000.0 * (10.0 / yrs)
        shock = shock.fillna(0.0)
        tot = (ar[(ar.period == p) & (ar.vintage == vintage)]
               .set_index("area")["total_employment"].reindex(areas).astype(float))
        val = mat.values @ shock.values / tot.values
        for a, v in zip(areas, val):
            out[(a, p)] = float(v)
    return out

xd = exposures("base", "us_change")
zd = exposures("early", "other_change")

pop = (ar[ar.vintage == "base"][["area", "period", "population"]]
       .drop_duplicates(["area", "period"]))
df = oc.merge(pop, on=["area", "period"], how="inner")
df["x"] = [xd[(a, p)] for a, p in zip(df.area, df.period)]
df["z"] = [zd[(a, p)] for a, p in zip(df.area, df.period)]
df = df.dropna(subset=["change_pp", "control", "population", "x", "z"])

n = len(df)
w = np.sqrt(df["population"].values.astype(float))
one = np.ones(n)
X = np.column_stack([one, df["period"].astype(float), df["control"].astype(float), df["x"]]) * w[:, None]
Z = np.column_stack([one, df["period"].astype(float), df["control"].astype(float), df["z"]]) * w[:, None]
y = df["change_pp"].values.astype(float) * w
PzX = Z @ np.linalg.lstsq(Z, X, rcond=None)[0]
beta = np.linalg.solve(PzX.T @ X, PzX.T @ y)

a0 = areas[0] if 0 not in areas else 0
res = {
    "iv_slope": float(beta[3]),
    "exposure_area0_period0": xd[(a0, periods[0])],
    "exposure_area0_period1": xd[(a0, periods[1])],
    "instrument_area0_period0": zd[(a0, periods[0])],
}
out = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [{"term": k, "estimate": float(f"{v:.15g}"), "se": None, "n_obs": int(n)}
                  for k, v in res.items()],
    "method_metadata": {"estimator": "weighted 2SLS", "weights": "base-vintage population",
                        "exog": ["intercept", "period", "control"], "endog": "x", "instrument": "z"},
    "diagnostics": {"n_obs": int(n), "n_areas": len(areas), "periods": [str(p) for p in periods],
                    "industries": industries},
}
with open("result.json", "w") as f:
    json.dump(out, f, indent=2)
