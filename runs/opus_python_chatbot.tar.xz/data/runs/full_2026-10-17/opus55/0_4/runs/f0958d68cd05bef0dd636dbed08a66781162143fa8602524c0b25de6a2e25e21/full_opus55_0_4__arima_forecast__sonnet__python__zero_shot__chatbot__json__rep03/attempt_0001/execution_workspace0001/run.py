import json
import numpy as np
import pandas as pd
from statsmodels.tsa.arima.model import ARIMA

df = pd.read_csv("./input.csv")
df = df.sort_values("t").reset_index(drop=True)
y = df["y"].astype(float).to_numpy()
n = len(y)

model = ARIMA(y, order=(1, 1, 1), trend="n")
res = model.fit()

fc = res.get_forecast(steps=1)
mean = float(np.asarray(fc.predicted_mean)[0])
se = float(np.asarray(fc.se_mean)[0])
ci = np.asarray(fc.conf_int(alpha=0.05))
lower = float(ci[0, 0])
upper = float(ci[0, 1])

params = dict(zip(res.model.param_names, np.asarray(res.params).tolist()))

out = {
    "task_id": "arima_forecast",
    "platform": "python",
    "estimates": [
        {"term": "forecast", "estimate": mean, "se": se, "n_obs": int(n)},
        {"term": "lower_95", "estimate": lower, "se": None, "n_obs": int(n)},
        {"term": "upper_95", "estimate": upper, "se": None, "n_obs": int(n)},
    ],
    "method_metadata": {
        "estimator": "ARIMA(1,1,1) exact Gaussian MLE via state space (statsmodels), no constant/drift",
        "vcov": "OPG (statsmodels default); forecast SE from Kalman filter",
    },
    "diagnostics": {
        "params": {k: float(v) for k, v in params.items()},
        "loglik": float(res.llf),
        "aic": float(res.aic),
        "last_t": float(df["t"].iloc[-1]),
        "forecast_se": se,
    },
}

with open("result.json", "w") as f:
    json.dump(out, f, indent=2)
