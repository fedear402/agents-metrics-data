import json
import numpy as np
import pandas as pd
from scipy.stats import f

df_data = pd.read_csv('input.csv')
cols = ['y', 'endog', 'x', 'z1', 'z2']
df_data = df_data[cols].dropna()
y = df_data['y'].to_numpy(float)
d = df_data['endog'].to_numpy(float)
x = df_data['x'].to_numpy(float)
z1 = df_data['z1'].to_numpy(float)
z2 = df_data['z2'].to_numpy(float)
n = len(y)

controls = np.column_stack([np.ones(n), x])
excluded = np.column_stack([z1, z2])
full = np.column_stack([controls, excluded])
q = excluded.shape[1]
dfree = n - full.shape[1]


def residual(v, design):
    return v - design @ np.linalg.lstsq(design, v, rcond=None)[0]


ry, rd = residual(y, controls), residual(d, controls)
uy, ud = residual(y, full), residual(d, full)
critical = f.ppf(0.95, q, dfree)
k = q * critical / dfree
A = rd @ rd - (1 + k) * (ud @ ud)
B = -2 * (ry @ rd - (1 + k) * (uy @ ud))
C = ry @ ry - (1 + k) * (uy @ uy)


def direct_F(beta):
    r = residual(y - beta * d, controls)
    u = residual(y - beta * d, full)
    return ((r @ r - u @ u) / q) / ((u @ u) / dfree)


def accepts(beta):
    return A * beta * beta + B * beta + C <= 0


disc = B * B - 4 * A * C
diagnostics = {'A': float(A), 'B': float(B), 'C': float(C),
               'discriminant': float(disc), 'critical': float(critical)}

if abs(A) > 1e-12 and disc > 0:
    sq = np.sqrt(disc)
    roots = np.sort([(-B - sq) / (2 * A), (-B + sq) / (2 * A)])
    low, high = float(roots[0]), float(roots[1])
    unbounded = int(A < 0)
elif abs(A) <= 1e-12 and abs(B) > 0:
    low = high = float(-C / B)
    unbounded = 1
else:
    low = high = float('nan')
    unbounded = int(A < 0)

accepts_zero = int(accepts(0.0))
ar_one = float(direct_F(1.0))


def clean(v):
    return None if (v is None or not np.isfinite(v)) else float(v)


rows = [
    {'term': 'boundary_low', 'estimate': clean(low), 'se': None, 'n_obs': int(n)},
    {'term': 'boundary_high', 'estimate': clean(high), 'se': None, 'n_obs': int(n)},
    {'term': 'accepts_zero', 'estimate': float(accepts_zero), 'se': None, 'n_obs': int(n)},
    {'term': 'unbounded', 'estimate': float(unbounded), 'se': None, 'n_obs': int(n)},
    {'term': 'ar_f_at_one', 'estimate': ar_one, 'se': None, 'n_obs': int(n)},
]

out = {
    'task_id': 'broad_ar_confidence_set',
    'platform': 'python',
    'estimates': rows,
    'method_metadata': {'estimator': 'Anderson-Rubin test inversion (analytic quadratic)',
                        'vcov': 'homoskedastic F'},
    'diagnostics': diagnostics,
}
with open('result.json', 'w') as fh:
    json.dump(out, fh, indent=2, allow_nan=False)
