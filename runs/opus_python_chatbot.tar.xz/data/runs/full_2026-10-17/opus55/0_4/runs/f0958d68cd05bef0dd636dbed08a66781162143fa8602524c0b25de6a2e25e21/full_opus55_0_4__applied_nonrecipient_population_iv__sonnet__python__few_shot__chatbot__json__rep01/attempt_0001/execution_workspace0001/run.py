import json
import numpy as np
import pandas as pd

h = pd.read_csv("households.csv")
c = pd.read_csv("census.csv")
d = h[h["recipient"] == 0].copy().reset_index(drop=True)
for col in ["eligible", "dose", "instrument", "baseline", "weight", "outcome"]:
    d[col] = pd.to_numeric(d[col], errors="coerce")
d = d.dropna(subset=["eligible", "dose", "instrument", "baseline", "weight", "outcome"]).reset_index(drop=True)
d["eligible"] = d["eligible"].astype(int)
e = d["eligible"].values.astype(float)
ne = 1.0 - e
y = d["outcome"].values
w = d["weight"].values
X_ex = np.column_stack([ne, e, d["baseline"].values * ne, d["baseline"].values * e])
X_en = np.column_stack([d["dose"].values * ne, d["dose"].values * e])
Z = np.column_stack([X_ex, d["instrument"].values * ne, d["instrument"].values * e])
X = np.column_stack([X_en, X_ex])

sw = np.sqrt(w)
Xw, Zw, yw = X * sw[:, None], Z * sw[:, None], y * sw
Pz_X = Zw @ np.linalg.lstsq(Zw, Xw, rcond=None)[0]
beta = np.linalg.solve(Pz_X.T @ Xw, Pz_X.T @ yw)
slope0, slope1 = beta[0], beta[1]

m0 = d["eligible"] == 0
m1 = d["eligible"] == 1
md0 = float(np.average(d.loc[m0, "dose"], weights=d.loc[m0, "weight"]))
md1 = float(np.average(d.loc[m1, "dose"], weights=d.loc[m1, "weight"]))
eff0 = float(slope0 * md0)
eff1 = float(slope1 * md1)

c["eligible"] = pd.to_numeric(c["eligible"]).astype(int)
pop = c.groupby("eligible")["nonrecipient_population"].sum()
p0, p1 = float(pop.get(0, 0.0)), float(pop.get(1, 0.0))
pe = float((p0 * eff0 + p1 * eff1) / (p0 + p1))

n = int(len(d))
res = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {"term": "ineligible_effect", "estimate": eff0, "se": None, "n_obs": n},
        {"term": "eligible_nonrecipient_effect", "estimate": eff1, "se": None, "n_obs": n},
        {"term": "population_effect", "estimate": pe, "se": None, "n_obs": n},
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS, pooled with group-interacted terms, no common intercept",
        "endogenous": ["dose*(1-eligible)", "dose*eligible"],
        "exogenous": ["1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"],
        "excluded_instruments": ["instrument*(1-eligible)", "instrument*eligible"],
        "weights": "weight",
        "sample": "recipient==0",
        "counterfactual": "dose=0 for all retained households (synthetic convention)",
        "aggregation_weights": "census nonrecipient_population",
    },
    "diagnostics": {
        "slope_ineligible": float(slope0),
        "slope_eligible": float(slope1),
        "weighted_mean_dose_ineligible": md0,
        "weighted_mean_dose_eligible": md1,
        "n_ineligible": int(m0.sum()),
        "n_eligible": int(m1.sum()),
        "population_ineligible": p0,
        "population_eligible": p1,
        "coefficients": [float(b) for b in beta],
    },
}
with open("result.json", "w") as f:
    json.dump(res, f, indent=2)
