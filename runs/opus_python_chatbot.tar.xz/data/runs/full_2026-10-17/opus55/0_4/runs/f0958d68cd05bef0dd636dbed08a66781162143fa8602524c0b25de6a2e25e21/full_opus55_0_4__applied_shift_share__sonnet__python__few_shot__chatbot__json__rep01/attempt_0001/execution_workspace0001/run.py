import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")

regions = df.groupby("region_id")[["region_weight", "x", "y"]].first().sort_index()
region_ids = regions.index.to_numpy()
shock_s = df.groupby("industry_id")["shock"].first().sort_index()
industry_ids = shock_s.index.to_numpy()
shock = shock_s.to_numpy(dtype=float)

shares = (df.pivot_table(index="region_id", columns="industry_id", values="share",
                         aggfunc="sum", fill_value=0.0)
          .reindex(index=region_ids, columns=industry_ids, fill_value=0.0)
          .to_numpy(dtype=float))

e = regions["region_weight"].to_numpy(dtype=float)
e = e / e.sum()
x = regions["x"].to_numpy(dtype=float)
y = regions["y"].to_numpy(dtype=float)
z = shares @ shock

regional = np.column_stack([y, x, z])
centered = regional - e @ regional
mass = e @ shares
keep = mass > 0
shares_k = shares[:, keep]
mass_k = mass[keep]
shock_k = shock[keep]
aggregated = (shares_k.T @ (e[:, None] * centered)) / mass_k[:, None]
N = len(shock_k)


def shock_iv(dep, endog):
    X = np.column_stack([np.ones(N), endog])
    Z = np.column_stack([np.ones(N), shock_k])
    cross = Z.T @ (mass_k[:, None] * X)
    beta = np.linalg.solve(cross, Z.T @ (mass_k * dep))
    resid = dep - X @ beta
    scores = Z * (mass_k * resid)[:, None]
    inv = np.linalg.inv(cross)
    cov = (N / (N - 2)) * inv @ (scores.T @ scores) @ inv.T
    return float(beta[1]), float(np.sqrt(cov[1, 1]))


effect, effect_se = shock_iv(aggregated[:, 0], aggregated[:, 1])
fs_shock, fs_se = shock_iv(aggregated[:, 1], aggregated[:, 2])

yc, xc, zc = centered[:, 0], centered[:, 1], centered[:, 2]
regional_effect = np.sum(e * zc * yc) / np.sum(e * zc * xc)
regional_fs = np.sum(e * zc * xc) / np.sum(e * zc * zc)

eff_shocks = float(1.0 / np.sum(mass ** 2))

output = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": float(regional_effect), "se": effect_se, "n_obs": int(N)},
        {"term": "first_stage", "estimate": float(regional_fs), "se": fs_se, "n_obs": int(N)},
        {"term": "effective_shocks", "estimate": eff_shocks, "se": None, "n_obs": int(N)},
    ],
    "method_metadata": {
        "estimator": "weighted shift-share 2SLS with BHJ shock-level equivalent IV",
        "vcov": "shock-level HC1 (N/(N-2)), structural IV residuals, analytic weights s_n",
    },
    "diagnostics": {
        "shock_level_effect": effect,
        "shock_level_first_stage": fs_shock,
        "n_regions": int(len(region_ids)),
    },
}

with open("result.json", "w") as f:
    json.dump(output, f, indent=2, allow_nan=False)
