import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df["g"] = df["g"].fillna(0)

results = []
atts = []
weights = []
nobs_list = []
diag = {}

for c in [3, 5, 7]:
    times = list(range(c - 2, c + 3))
    sub = df[df["time"].isin(times)]
    sub = sub[(sub["g"] == c) | (sub["g"] == 0) | (sub["g"] > c + 2)].copy()
    sub = sub.dropna(subset=["y"])
    counts = sub.groupby("id")["time"].nunique()
    keep = counts[counts == len(times)].index
    sub = sub[sub["id"].isin(keep)].copy()
    sub["did"] = ((sub["g"] == c) & (sub["time"] >= c)).astype(float)

    # two-way within transformation is exact for balanced panel
    y = sub["y"].astype(float)
    d = sub["did"]
    def demean(v):
        return (v - v.groupby(sub["id"]).transform("mean")
                  - v.groupby(sub["time"]).transform("mean") + v.mean())
    yd = demean(y)
    dd = demean(d)
    beta = float((dd * yd).sum() / (dd * dd).sum())

    n_treated = int(sub.loc[sub["g"] == c, "id"].nunique())
    n_obs = int(len(sub))
    atts.append(beta)
    weights.append(n_treated)
    nobs_list.append(n_obs)
    diag[f"g{c}"] = {"n_treated_units": n_treated,
                     "n_control_units": int(sub.loc[sub["g"] != c, "id"].nunique()),
                     "n_obs": n_obs}
    results.append({"term": f"att_g{c}", "estimate": beta, "se": None, "n_obs": n_obs})

w = np.array(weights, dtype=float)
att_w = float(np.dot(w, atts) / w.sum())
results.append({"term": "att_weighted", "estimate": att_w, "se": None,
                "n_obs": int(sum(nobs_list))})

out = {
    "task_id": "broad_cohort_stack",
    "platform": "python",
    "estimates": results,
    "method_metadata": {
        "method": "cohort-specific TWFE DiD, windows c-2..c+2, balanced within cohort",
        "weights": "number of retained treated units per cohort",
    },
    "diagnostics": diag,
}

with open("result.json", "w") as f:
    json.dump(out, f, indent=2)
