import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")

regions = np.sort(df["region_id"].unique())
industries = np.sort(df["industry_id"].unique())
R, N = len(regions), len(industries)
r_idx = {r: i for i, r in enumerate(regions)}
n_idx = {n: j for j, n in enumerate(industries)}

shares = np.zeros((R, N))
for r, n, s in zip(df["region_id"], df["industry_id"], df["share"]):
    shares[r_idx[r], n_idx[n]] += s

shock = df.groupby("industry_id")["shock"].first().reindex(industries).to_numpy(float)
reg = df.groupby("region_id")[["region_weight", "x", "y"]].first().reindex(regions)
w = reg["region_weight"].to_numpy(float)
e = w / w.sum()
x = reg["x"].to_numpy(float)
y = reg["y"].to_numpy(float)
z = shares @ shock

regional = np.column_stack([y, x, z])
centered = regional - e @ regional
mass = e @ shares
keep = mass > 0
shares_k = shares[:, keep]
shock_k = shock[keep]
mass_k = mass[keep]
Nk = int(keep.sum())
aggregated = (shares_k.T @ (e[:, None] * centered)) / mass_k[:, None]


def shock_iv(dep, endog):
    X = np.column_stack([np.ones(Nk), endog])
    Z = np.column_stack([np.ones(Nk), shock_k])
    cross = Z.T @ (mass_k[:, None] * X)
    beta = np.linalg.solve(cross, Z.T @ (mass_k * dep))
    resid = dep - X @ beta
    scores = Z * (mass_k * resid)[:, None]
    inv = np.linalg.inv(cross)
    cov = (Nk / (Nk - 2)) * inv @ (scores.T @ scores) @ inv.T
    return float(beta[1]), float(np.sqrt(cov[1, 1]))


effect, effect_se = shock_iv(aggregated[:, 0], aggregated[:, 1])
fs, fs_se = shock_iv(aggregated[:, 1], aggregated[:, 2])

yc, xc, zc = centered[:, 0], centered[:, 1], centered[:, 2]
reg_effect = np.sum(e * zc * yc) / np.sum(e * zc * xc)
reg_fs = np.sum(e * zc * xc) / np.sum(e * zc ** 2)

eff_shocks = float(1.0 / np.sum(mass ** 2))

out = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": float(reg_effect), "se": effect_se, "n_obs": Nk},
        {"term": "first_stage", "estimate": float(reg_fs), "se": fs_se, "n_obs": Nk},
        {"term": "effective_shocks", "estimate": eff_shocks, "se": None, "n_obs": Nk},
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS with shift-share instrument; BHJ shock-level equivalent IV",
        "vcov": "shock-level HC1 (N/(N-2)), structural IV residuals, analytic weights s_n",
    },
    "diagnostics": {
        "shock_level_effect": effect,
        "shock_level_first_stage": fs,
        "n_regions": int(R),
    },
}
with open("result.json", "w") as f:
    json.dump(out, f, indent=2, allow_nan=False)
