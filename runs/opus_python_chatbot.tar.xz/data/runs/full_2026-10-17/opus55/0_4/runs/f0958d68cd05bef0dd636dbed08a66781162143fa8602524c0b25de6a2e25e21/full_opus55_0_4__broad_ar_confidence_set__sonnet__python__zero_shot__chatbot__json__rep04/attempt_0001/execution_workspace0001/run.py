import json
import numpy as np
import pandas as pd
from scipy import stats

df = pd.read_csv("input.csv")
df = df[["y", "endog", "x", "z1", "z2"]].dropna()
n = len(df)
y = df["y"].to_numpy(float)
d = df["endog"].to_numpy(float)
X1 = np.column_stack([np.ones(n), df["x"].to_numpy(float)])
XF = np.column_stack([X1, df["z1"].to_numpy(float), df["z2"].to_numpy(float)])

def resid_maker(X):
    Q, _ = np.linalg.qr(X)
    return lambda v: v - Q @ (Q.T @ v)

M1 = resid_maker(X1)
MF = resid_maker(XF)
dfd = n - 4
crit = stats.f.ppf(0.95, 2, dfd)

def ar_f(b):
    u = y - b * d
    rss_u = float(MF(u) @ MF(u))
    rss_r = float(M1(u) @ M1(u))
    return ((rss_r - rss_u) / 2.0) / (rss_u / dfd)

# Quadratic forms: u = y - b d; u'Au = yAy - 2b yAd + b^2 dAd
def qf(Mfun, a, c):
    return float(Mfun(a) @ Mfun(c))

def coefs(Mfun):
    return qf(Mfun, d, d), -2 * qf(Mfun, y, d), qf(Mfun, y, y)

r1 = coefs(M1)
rf = coefs(MF)
# Accept iff (r1 - rf)/2 - crit/dfd * rf <= 0
k = crit / dfd
A, B, C = [(r1[i] - rf[i]) / 2.0 - k * rf[i] for i in range(3)]
disc = B * B - 4 * A * C
roots = []
if disc >= 0 and A != 0:
    s = np.sqrt(disc)
    roots = sorted([(-B - s) / (2 * A), (-B + s) / (2 * A)])
elif A == 0 and B != 0:
    roots = [-C / B]

def accepts(b):
    return ar_f(b) <= crit

low = float(roots[0]) if roots else None
high = float(roots[-1]) if roots else None
unbounded = 1 if A <= 0 else 0
acc0 = 1 if accepts(0.0) else 0
f1 = ar_f(1.0)

res = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": [
        {"term": "boundary_low", "estimate": low, "se": None, "n_obs": n},
        {"term": "boundary_high", "estimate": high, "se": None, "n_obs": n},
        {"term": "accepts_zero", "estimate": float(acc0), "se": None, "n_obs": n},
        {"term": "unbounded", "estimate": float(unbounded), "se": None, "n_obs": n},
        {"term": "ar_f_at_one", "estimate": float(f1), "se": None, "n_obs": n},
    ],
    "method_metadata": {
        "estimator": "Anderson-Rubin test inversion (analytic quadratic)",
        "vcov": "homoskedastic F(2, n-4)",
    },
    "diagnostics": {
        "critical_value": float(crit),
        "quad_A": A, "quad_B": B, "quad_C": C,
        "discriminant": disc,
    },
}
with open("result.json", "w") as f:
    json.dump(res, f, indent=2)
