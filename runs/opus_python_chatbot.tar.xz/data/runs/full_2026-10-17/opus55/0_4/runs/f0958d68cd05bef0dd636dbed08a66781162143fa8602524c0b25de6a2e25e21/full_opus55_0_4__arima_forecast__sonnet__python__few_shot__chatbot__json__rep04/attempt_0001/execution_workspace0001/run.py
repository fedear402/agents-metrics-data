import json
import numpy as np
import pandas as pd
from statsmodels.tsa.arima.model import ARIMA

df = pd.read_csv("./input.csv").sort_values("t").reset_index(drop=True)
y = df["y"].astype(float).to_numpy()

model = ARIMA(y, order=(1, 1, 1), trend="n")
fit = model.fit()
fc = fit.get_forecast(steps=1)
mean = float(np.asarray(fc.predicted_mean)[0])
se = float(np.asarray(fc.se_mean)[0])
ci = np.asarray(fc.conf_int(alpha=0.05))
lo, hi = float(ci[0, 0]), float(ci[0, 1])
n = int(len(y))

params = dict(zip(fit.model.param_names, [float(p) for p in fit.params]))

out = {
    "task_id": "arima_forecast",
    "platform": "python",
    "estimates": [
        {"term": "forecast", "estimate": mean, "se": se, "n_obs": n},
        {"term": "lower_95", "estimate": lo, "se": None, "n_obs": n},
        {"term": "upper_95", "estimate": hi, "se": None, "n_obs": n},
    ],
    "method_metadata": {
        "estimator": "ARIMA(1,1,1) exact MLE (state space), no constant/drift; one-step forecast for t=%s" % (
            str(int(df["t"].iloc[-1]) + 1) if np.issubdtype(df["t"].dtype, np.number) else "next"),
        "vcov": "opg",
    },
    "diagnostics": {
        "params": params,
        "loglik": float(fit.llf),
        "aic": float(fit.aic),
    },
}
with open("result.json", "w") as f:
    json.dump(out, f)
