import json
import numpy as np
import pandas as pd

hh = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

d = hh[hh["recipient"] == 0].copy()
d = d.dropna(subset=["eligible", "instrument", "dose", "baseline", "weight", "outcome"])
d = d[d["weight"] > 0]
e = d["eligible"].astype(float).values
ne = 1.0 - e
dose = d["dose"].astype(float).values
base = d["baseline"].astype(float).values
z = d["instrument"].astype(float).values
w = d["weight"].astype(float).values
y = d["outcome"].astype(float).values
n_obs = int(len(d))

X = np.column_stack([dose * ne, dose * e, ne, e, base * ne, base * e])
Z = np.column_stack([ne, e, base * ne, base * e, z * ne, z * e])

sw = np.sqrt(w)
Xw = X * sw[:, None]
Zw = Z * sw[:, None]
yw = y * sw
# First stage projection
pi, *_ = np.linalg.lstsq(Zw, Xw, rcond=None)
Xhat = Zw @ pi
beta, *_ = np.linalg.lstsq(Xhat, yw, rcond=None)

b_inel, b_el = float(beta[0]), float(beta[1])
m0 = e == 0
m1 = e == 1
mean_dose_inel = float(np.sum(w[m0] * dose[m0]) / np.sum(w[m0]))
mean_dose_el = float(np.sum(w[m1] * dose[m1]) / np.sum(w[m1]))
eff_inel = b_inel * mean_dose_inel
eff_el = b_el * mean_dose_el

pop0 = float(census.loc[census["eligible"] == 0, "nonrecipient_population"].sum())
pop1 = float(census.loc[census["eligible"] == 1, "nonrecipient_population"].sum())
pop_eff = (pop0 * eff_inel + pop1 * eff_el) / (pop0 + pop1)

# First-stage diagnostics
fs_rank = int(np.linalg.matrix_rank(Zw))

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {"term": "ineligible_effect", "estimate": float(eff_inel), "se": None, "n_obs": n_obs},
        {"term": "eligible_nonrecipient_effect", "estimate": float(eff_el), "se": None, "n_obs": n_obs},
        {"term": "population_effect", "estimate": float(pop_eff), "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS, eligibility-interacted, no common intercept",
        "sample": "recipient == 0 (all villages)",
        "endogenous": ["dose*(1-eligible)", "dose*eligible"],
        "exogenous": ["1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"],
        "excluded_instruments": ["instrument*(1-eligible)", "instrument*eligible"],
        "weights": "weight",
        "group_effect": "dose slope times weighted mean dose (zero-dose counterfactual, synthetic convention)",
        "aggregation": "census nonrecipient_population weights",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "n_ineligible": int(m0.sum()),
        "n_eligible": int(m1.sum()),
        "slope_ineligible": b_inel,
        "slope_eligible": b_el,
        "weighted_mean_dose_ineligible": mean_dose_inel,
        "weighted_mean_dose_eligible": mean_dose_el,
        "census_pop_ineligible": pop0,
        "census_pop_eligible": pop1,
        "instrument_matrix_rank": fs_rank,
        "coefficients": [float(b) for b in beta],
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
