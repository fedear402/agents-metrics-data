import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df = df[np.abs(df["score"]) < 1].copy()
s = df["score"].to_numpy(float)
w = 1 - np.abs(s)
d = (s >= 0).astype(float)
X = np.column_stack([np.ones_like(s), d, s, d * s])
y = df["earnings"].to_numpy(float)
t = df["participated"].to_numpy(float)
n = len(df)

XtW = X.T * w
A_inv = np.linalg.inv(XtW @ X)
by = A_inv @ (XtW @ y)
bt = A_inv @ (XtW @ t)
ey = y - X @ by
et = t - X @ bt

def meat(e1, e2):
    return (X * (w**2 * e1 * e2)[:, None]).T @ X

V_yy = A_inv @ meat(ey, ey) @ A_inv
V_tt = A_inv @ meat(et, et) @ A_inv
V_yt = A_inv @ meat(ey, et) @ A_inv

rf, fs = by[1], bt[1]
var_rf, var_fs, cov = V_yy[1, 1], V_tt[1, 1], V_yt[1, 1]
te = rf / fs
g = np.array([1 / fs, -rf / fs**2])
Sigma = np.array([[var_rf, cov], [cov, var_fs]])
se_te = float(np.sqrt(g @ Sigma @ g))

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": float(te), "se": se_te, "n_obs": int(n)},
        {"term": "reduced_form", "estimate": float(rf), "se": float(np.sqrt(var_rf)), "n_obs": int(n)},
        {"term": "first_stage", "estimate": float(fs), "se": float(np.sqrt(var_fs)), "n_obs": int(n)},
    ],
    "method_metadata": {
        "estimator": "fuzzy RD, local linear, triangular kernel, bandwidth 1, cutoff 0, ratio of WLS discontinuities",
        "vcov": "HC0 joint sandwich, delta method with RF-FS covariance",
    },
    "diagnostics": {"cov_rf_fs": float(cov)},
}
with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
