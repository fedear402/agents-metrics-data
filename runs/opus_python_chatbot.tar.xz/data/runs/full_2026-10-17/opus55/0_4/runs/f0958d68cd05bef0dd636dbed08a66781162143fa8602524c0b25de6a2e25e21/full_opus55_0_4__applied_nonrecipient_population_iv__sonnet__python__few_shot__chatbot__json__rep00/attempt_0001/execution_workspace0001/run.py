import json
import numpy as np
import pandas as pd

h = pd.read_csv("households.csv")
c = pd.read_csv("census.csv")
d = h[h["recipient"] == 0].copy()
d = d.dropna(subset=["eligible", "dose", "instrument", "baseline", "weight", "outcome"])
e = d["eligible"].astype(float).values
ne = 1.0 - e
dose = d["dose"].astype(float).values
base = d["baseline"].astype(float).values
z = d["instrument"].astype(float).values
w = d["weight"].astype(float).values
y = d["outcome"].astype(float).values

X = np.column_stack([dose * ne, dose * e, ne, e, base * ne, base * e])
Z = np.column_stack([ne, e, base * ne, base * e, z * ne, z * e])
sw = np.sqrt(w)
Xw, Zw, yw = X * sw[:, None], Z * sw[:, None], y * sw
Pz_X = Zw @ np.linalg.lstsq(Zw, Xw, rcond=None)[0]
beta = np.linalg.solve(Pz_X.T @ Xw, Pz_X.T @ yw)

n_obs = int(len(d))
effects = {}
group_info = {}
for g, slope in [(0, beta[0]), (1, beta[1])]:
    m = e == g
    md = float(np.average(dose[m], weights=w[m]))
    effects[g] = float(slope * md)
    group_info[str(g)] = {"slope": float(slope), "weighted_mean_dose": md, "n_group": int(m.sum())}

pop = c.groupby("eligible")["nonrecipient_population"].sum()
p0, p1 = float(pop.loc[0]), float(pop.loc[1])
population_effect = (p0 * effects[0] + p1 * effects[1]) / (p0 + p1)

res = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {"term": "ineligible_effect", "estimate": effects[0], "se": None, "n_obs": n_obs},
        {"term": "eligible_nonrecipient_effect", "estimate": effects[1], "se": None, "n_obs": n_obs},
        {"term": "population_effect", "estimate": float(population_effect), "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS, fully interacted by eligibility, no extra intercept",
        "endogenous": ["dose*(1-eligible)", "dose*eligible"],
        "exogenous": ["1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"],
        "excluded_instruments": ["instrument*(1-eligible)", "instrument*eligible"],
        "weights": "weight",
        "sample": "recipient==0",
        "counterfactual": "dose=0 for all retained households (synthetic convention)",
        "aggregation_weights": {"0": p0, "1": p1},
    },
    "diagnostics": {
        "coefficients": dict(zip(["dose_inel", "dose_elig", "const_inel", "const_elig",
                                  "base_inel", "base_elig"], [float(b) for b in beta])),
        "groups": group_info,
        "n_obs": n_obs,
    },
}
with open("result.json", "w") as f:
    json.dump(res, f, indent=2)
