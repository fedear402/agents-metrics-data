import json
import numpy as np
import pandas as pd

hh = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

d = hh[hh["recipient"] == 0].copy()
d = d.dropna(subset=["eligible", "instrument", "dose", "baseline", "weight", "outcome"])
d["eligible"] = d["eligible"].astype(int)
e = d["eligible"].to_numpy(dtype=float)
ne = 1.0 - e
dose = d["dose"].to_numpy(dtype=float)
base = d["baseline"].to_numpy(dtype=float)
z = d["instrument"].to_numpy(dtype=float)
w = d["weight"].to_numpy(dtype=float)
y = d["outcome"].to_numpy(dtype=float)

X = np.column_stack([dose * ne, dose * e, ne, e, base * ne, base * e])
Z = np.column_stack([ne, e, base * ne, base * e, z * ne, z * e])

sw = np.sqrt(w)
Xw = X * sw[:, None]
Zw = Z * sw[:, None]
yw = y * sw
ZtZ = Zw.T @ Zw
ZtX = Zw.T @ Xw
Zty = Zw.T @ yw
A = ZtX.T @ np.linalg.solve(ZtZ, ZtX)
b = ZtX.T @ np.linalg.solve(ZtZ, Zty)
beta = np.linalg.solve(A, b)

n_obs = int(len(d))
effects = {}
means = {}
for g, idx in [(0, 0), (1, 1)]:
    m = e == g
    md = float(np.sum(w[m] * dose[m]) / np.sum(w[m]))
    means[g] = md
    effects[g] = float(beta[idx] * md)

pop = census.groupby("eligible")["nonrecipient_population"].sum()
p0 = float(pop.loc[0]); p1 = float(pop.loc[1])
pop_eff = (p0 * effects[0] + p1 * effects[1]) / (p0 + p1)

def fmt(v):
    return float(f"{v:.15g}")

estimates = [
    {"term": "ineligible_effect", "estimate": fmt(effects[0]), "se": None, "n_obs": n_obs},
    {"term": "eligible_nonrecipient_effect", "estimate": fmt(effects[1]), "se": None, "n_obs": n_obs},
    {"term": "population_effect", "estimate": fmt(pop_eff), "se": None, "n_obs": n_obs},
]

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "sample": "recipient == 0 (all nonrecipient households, both village statuses)",
        "endogenous": ["dose*(1-eligible)", "dose*eligible"],
        "exogenous": ["1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"],
        "excluded_instruments": ["instrument*(1-eligible)", "instrument*eligible"],
        "weights": "weight",
        "effect_definition": "dose slope times weighted mean dose within group; zero-dose counterfactual (synthetic convention)",
        "aggregation": "census nonrecipient_population weights",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "n_ineligible": int(np.sum(e == 0)),
        "n_eligible": int(np.sum(e == 1)),
        "dose_slope_ineligible": fmt(float(beta[0])),
        "dose_slope_eligible": fmt(float(beta[1])),
        "weighted_mean_dose_ineligible": fmt(means[0]),
        "weighted_mean_dose_eligible": fmt(means[1]),
        "census_pop_ineligible": p0,
        "census_pop_eligible": p1,
        "coefficients": [fmt(float(v)) for v in beta],
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
