import json
import numpy as np
import pandas as pd

cw = pd.read_csv("crosswalk.csv")
tr = pd.read_csv("trade.csv")
ar = pd.read_csv("areas.csv")
em = pd.read_csv("employment.csv")
oc = pd.read_csv("outcomes.csv")

for d in (cw, tr):
    d["code"] = d["code"].astype(str).str.strip()
for d in (cw, em):
    d["industry"] = d["industry"].astype(str).str.strip()
for d in (ar, em):
    d["vintage"] = d["vintage"].astype(str).str.strip().str.lower()

tr = tr.merge(cw, on="code", how="inner")
tr = tr.groupby(["period", "industry"], as_index=False).agg(
    us_change=("us_change", "sum"), other_change=("other_change", "sum"),
    price_index=("price_index", "first"), years=("years", "first"))
industries = sorted(cw["industry"].unique())

areas_list = sorted(ar["area"].unique())
periods = sorted(ar["period"].unique())


def exposure(vintage, change_col):
    e = em[em["vintage"] == vintage].groupby(["area", "period", "industry"])["employment"].sum()
    idx = pd.MultiIndex.from_product([areas_list, periods, industries],
                                     names=["area", "period", "industry"])
    e = e.reindex(idx, fill_value=0.0).reset_index()
    nat = e.groupby(["period", "industry"])["employment"].sum().rename("nat").reset_index()
    e = e.merge(nat, on=["period", "industry"])
    e = e.merge(tr, on=["period", "industry"], how="left")
    e[change_col] = e[change_col].fillna(0.0)
    tot = ar[ar["vintage"] == vintage][["area", "period", "total_employment"]]
    e = e.merge(tot, on=["area", "period"], how="left")
    e["c"] = (e["employment"] / e["total_employment"]) * (e[change_col] / e["nat"]) \
        / (e["price_index"] / 100.0) / 1000.0 * (10.0 / e["years"])
    return e.groupby(["area", "period"])["c"].sum()


x = exposure("base", "us_change").rename("x").reset_index()
z = exposure("early", "other_change").rename("z").reset_index()

pop = ar[ar["vintage"] == "base"][["area", "period", "population"]]
df = oc.merge(x, on=["area", "period"]).merge(z, on=["area", "period"]).merge(pop, on=["area", "period"])
df = df.sort_values(["area", "period"]).reset_index(drop=True)

n = len(df)
y = df["change_pp"].to_numpy(float)
X = np.column_stack([np.ones(n), df["period"].astype(float), df["control"].astype(float), df["x"]])
Z = np.column_stack([np.ones(n), df["period"].astype(float), df["control"].astype(float), df["z"]])
w = df["population"].to_numpy(float)
sw = np.sqrt(w)
Xw, Zw, yw = X * sw[:, None], Z * sw[:, None], y * sw
beta = np.linalg.solve(Zw.T @ Xw, Zw.T @ yw)


def get(d, col, a, p):
    r = d[(d["area"] == a) & (d["period"] == p)]
    return float(r[col].iloc[0])


a0 = areas_list[0]
p0, p1 = periods[0], periods[1]
ests = {
    "iv_slope": float(beta[3]),
    "exposure_area0_period0": get(df, "x", a0, p0),
    "exposure_area0_period1": get(df, "x", a0, p1),
    "instrument_area0_period0": get(df, "z", a0, p0),
}
out = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [{"term": k, "estimate": float(f"{v:.12g}"), "se": None, "n_obs": int(n)}
                  for k, v in ests.items()],
    "method_metadata": {"estimator": "weighted 2SLS (just-identified)",
                        "weights": "base-vintage population",
                        "exogenous": ["intercept", "period", "control"],
                        "instrument": "z (early vintage, other_change)"},
    "diagnostics": {"n_obs": int(n), "coefficients": [float(b) for b in beta],
                    "first_stage_corr_xz": float(np.corrcoef(df["x"], df["z"])[0, 1])},
}
with open("result.json", "w") as f:
    json.dump(out, f, indent=2)
