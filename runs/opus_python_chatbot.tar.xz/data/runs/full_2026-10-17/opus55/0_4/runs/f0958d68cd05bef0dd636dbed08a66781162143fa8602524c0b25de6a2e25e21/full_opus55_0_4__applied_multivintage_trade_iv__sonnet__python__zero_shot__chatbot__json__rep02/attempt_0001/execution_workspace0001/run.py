import json
import numpy as np
import pandas as pd

cw = pd.read_csv("crosswalk.csv")
tr = pd.read_csv("trade.csv")
ar = pd.read_csv("areas.csv")
em = pd.read_csv("employment.csv")
oc = pd.read_csv("outcomes.csv")

for d in (cw, tr):
    d["code"] = d["code"].astype(str).str.strip()
for d in (cw, em):
    d["industry"] = d["industry"].astype(str).str.strip()
for d in (ar, em):
    d["vintage"] = d["vintage"].astype(str).str.strip().str.lower()

tr = tr.merge(cw[["code", "industry"]], on="code", how="inner")
tr = tr.groupby(["period", "industry"], as_index=False).agg(
    us_change=("us_change", "sum"), other_change=("other_change", "sum"),
    price_index=("price_index", "first"), years=("years", "first"))

industries = sorted(cw["industry"].unique())
keys = ar[["area", "period"]].drop_duplicates()


def exposure(vintage, change_col):
    a = ar[ar["vintage"] == vintage][["area", "period", "total_employment"]]
    e = em[em["vintage"] == vintage].groupby(["area", "period", "industry"], as_index=False)["employment"].sum()
    grid = a[["area", "period"]].assign(k=1).merge(
        pd.DataFrame({"industry": industries, "k": 1}), on="k").drop(columns="k")
    g = grid.merge(e, on=["area", "period", "industry"], how="left")
    g["employment"] = g["employment"].fillna(0.0)
    nat = g.groupby(["period", "industry"])["employment"].sum().rename("nat").reset_index()
    g = g.merge(nat, on=["period", "industry"]).merge(a, on=["area", "period"])
    g = g.merge(tr, on=["period", "industry"], how="left")
    g[change_col] = g[change_col].fillna(0.0)
    g["c"] = (g["employment"] / g["total_employment"]) * (g[change_col] / g["nat"]) \
        / (g["price_index"] / 100.0) / 1000.0 * (10.0 / g["years"])
    g["c"] = g["c"].fillna(0.0)
    return g.groupby(["area", "period"])["c"].sum()


x = exposure("base", "us_change").rename("x").reset_index()
z = exposure("early", "other_change").rename("z").reset_index()
w = ar[ar["vintage"] == "base"][["area", "period", "population"]]

df = oc.merge(x, on=["area", "period"]).merge(z, on=["area", "period"]).merge(w, on=["area", "period"])
df = df.sort_values(["period", "area"]).reset_index(drop=True)

y = df["change_pp"].to_numpy(float)
ones = np.ones(len(df))
X = np.column_stack([ones, df["period"].astype(float), df["control"].astype(float), df["x"]])
Z = np.column_stack([ones, df["period"].astype(float), df["control"].astype(float), df["z"]])
sw = np.sqrt(df["population"].to_numpy(float))
Xw, Zw, yw = X * sw[:, None], Z * sw[:, None], y * sw
Pz = Zw @ np.linalg.pinv(Zw.T @ Zw) @ Zw.T
beta = np.linalg.solve(Xw.T @ Pz @ Xw, Xw.T @ Pz @ yw)

# first stage
fs = np.linalg.lstsq(Zw, Xw[:, 3], rcond=None)[0]

n = int(len(df))


def val(col, a, p):
    r = df[(df["area"] == a) & (df["period"] == p)][col]
    return float(r.iloc[0]) if len(r) else None


periods = sorted(df["period"].unique())
p0, p1 = periods[0], periods[1] if len(periods) > 1 else periods[0]
a0 = sorted(df["area"].unique())[0]

est = [
    ("iv_slope", float(beta[3])),
    ("exposure_area0_period0", val("x", a0, p0)),
    ("exposure_area0_period1", val("x", a0, p1)),
    ("instrument_area0_period0", val("z", a0, p0)),
]

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [{"term": t, "estimate": v, "se": None, "n_obs": n} for t, v in est],
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "weights": "base-vintage population",
        "regressors": ["intercept", "period", "control", "x"],
        "instruments": ["intercept", "period", "control", "z"],
        "missing_employment": "zero",
    },
    "diagnostics": {
        "n_obs": n,
        "coefficients": [float(b) for b in beta],
        "first_stage_z_coef": float(fs[3]),
        "n_industries": len(industries),
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
