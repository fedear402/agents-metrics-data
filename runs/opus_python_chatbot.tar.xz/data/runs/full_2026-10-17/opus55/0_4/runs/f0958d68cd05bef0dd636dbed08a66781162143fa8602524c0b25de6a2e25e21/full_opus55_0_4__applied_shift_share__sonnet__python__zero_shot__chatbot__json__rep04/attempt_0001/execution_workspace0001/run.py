import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")

reg = df.groupby("region_id").agg(region_weight=("region_weight", "first"),
                                  x=("x", "first"), y=("y", "first")).reset_index()
reg["e"] = reg["region_weight"] / reg["region_weight"].sum()

df = df.merge(reg[["region_id", "e"]], on="region_id", how="left")
df["zc"] = df["share"] * df["shock"]
reg = reg.merge(df.groupby("region_id")["zc"].sum().rename("z").reset_index(), on="region_id")

e = reg["e"].values
for v in ["y", "x", "z"]:
    reg[v + "0"] = reg[v] - np.sum(e * reg[v].values)

df = df.merge(reg[["region_id", "y0", "x0", "z0"]], on="region_id", how="left")
df["es"] = df["e"] * df["share"]
for v in ["y0", "x0", "z0"]:
    df["w_" + v] = df["es"] * df[v]

ind = df.groupby("industry_id").agg(s=("es", "sum"), shock=("shock", "first"),
                                    wy=("w_y0", "sum"), wx=("w_x0", "sum"),
                                    wz=("w_z0", "sum")).reset_index()
ind = ind[ind["s"] > 0].copy()
ind["ybar"] = ind["wy"] / ind["s"]
ind["xbar"] = ind["wx"] / ind["s"]
ind["zbar"] = ind["wz"] / ind["s"]
N = len(ind)


def wiv(yv, xv, zv, w):
    n = len(yv)
    X = np.column_stack([np.ones(n), xv])
    Z = np.column_stack([np.ones(n), zv])
    ZWX = Z.T @ (w[:, None] * X)
    b = np.linalg.solve(ZWX, Z.T @ (w * yv))
    u = yv - X @ b
    A = np.linalg.inv(ZWX)
    meat = (Z * (w * u)[:, None]).T @ (Z * (w * u)[:, None])
    V = A @ meat @ A.T * n / (n - 2)
    return b[1], np.sqrt(V[1, 1])


s = ind["s"].values
sh = ind["shock"].values
b_eff, se_eff = wiv(ind["ybar"].values, ind["xbar"].values, sh, s)
b_fs, se_fs = wiv(ind["xbar"].values, ind["zbar"].values, sh, s)

# Regional checks
x0, z0, y0 = reg["x0"].values, reg["z0"].values, reg["y0"].values
b_eff_reg = np.sum(e * z0 * y0) / np.sum(e * z0 * x0)
b_fs_reg = np.sum(e * z0 * x0) / np.sum(e * z0 * z0)

eff_shocks = 1.0 / np.sum(s ** 2)

out = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": float(b_eff_reg), "se": float(se_eff), "n_obs": int(N)},
        {"term": "first_stage", "estimate": float(b_fs_reg), "se": float(se_fs), "n_obs": int(N)},
        {"term": "effective_shocks", "estimate": float(eff_shocks), "se": None, "n_obs": int(N)},
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS with shift-share instrument; BHJ shock-level equivalent IV",
        "vcov": "shock-level HC1 (N/(N-2)), structural IV residuals, analytic weights s_n",
    },
    "diagnostics": {
        "shock_level_effect": float(b_eff),
        "shock_level_first_stage": float(b_fs),
        "n_regions": int(len(reg)),
    },
}

with open("result.json", "w") as f:
    json.dump(out, f, indent=2)
