import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df = df[["score", "participated", "earnings"]].apply(pd.to_numeric, errors="coerce").dropna()
d = df[np.abs(df["score"]) < 1].copy()
s = d["score"].to_numpy(float)
w = 1.0 - np.abs(s)
r = (s >= 0).astype(float)
X = np.column_stack([np.ones_like(s), r, s, r * s])
n = len(d)

XtWX = X.T @ (X * w[:, None])
bread = np.linalg.inv(XtWX)

def fit(y):
    b = bread @ (X.T @ (w * y))
    e = y - X @ b
    return b, e

y_rf = d["earnings"].to_numpy(float)
y_fs = d["participated"].to_numpy(float)
b_rf, e_rf = fit(y_rf)
b_fs, e_fs = fit(y_fs)

def cov(e1, e2):
    S = (X * (w * e1)[:, None]).T @ (X * (w * e2)[:, None])
    return bread @ S @ bread

V_rr = cov(e_rf, e_rf)[1, 1]
V_ff = cov(e_fs, e_fs)[1, 1]
V_rf = cov(e_rf, e_fs)[1, 1]

rf = b_rf[1]
fs = b_fs[1]
te = rf / fs
g = np.array([1.0 / fs, -rf / fs**2])
V = np.array([[V_rr, V_rf], [V_rf, V_ff]])
se_te = float(np.sqrt(g @ V @ g))

out = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": float(te), "se": se_te, "n_obs": int(n)},
        {"term": "reduced_form", "estimate": float(rf), "se": float(np.sqrt(V_rr)), "n_obs": int(n)},
        {"term": "first_stage", "estimate": float(fs), "se": float(np.sqrt(V_ff)), "n_obs": int(n)},
    ],
    "method_metadata": {
        "estimator": "fuzzy RD, local linear, triangular kernel, h=1, cutoff 0, Wald ratio",
        "vcov": "HC0 robust, joint covariance, delta method for ratio",
    },
    "diagnostics": {"cov_rf_fs": float(V_rf), "n_left": int((r == 0).sum()), "n_right": int((r == 1).sum())},
}
with open("result.json", "w") as f:
    json.dump(out, f, indent=2)
