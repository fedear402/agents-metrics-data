import json
import numpy as np
import pandas as pd

cw = pd.read_csv("crosswalk.csv")
tr = pd.read_csv("trade.csv")
ar = pd.read_csv("areas.csv")
em = pd.read_csv("employment.csv")
oc = pd.read_csv("outcomes.csv")

for d in (cw, tr):
    d["code"] = d["code"].astype(str).str.strip()
for d in (cw, em):
    d["industry"] = d["industry"].astype(str).str.strip()
for d in (ar, em):
    d["vintage"] = d["vintage"].astype(str).str.strip().str.lower()

tr = tr.merge(cw, on="code", how="inner")
tg = tr.groupby(["period", "industry"], as_index=False).agg(
    us_change=("us_change", "sum"), other_change=("other_change", "sum"),
    price_index=("price_index", "first"), years=("years", "first"))

industries = sorted(cw["industry"].unique())
areas = ar[["area", "period"]].drop_duplicates()


def exposure(vintage, change_col, name):
    a = ar[ar["vintage"] == vintage][["area", "period", "total_employment"]]
    grid = areas.assign(key=1).merge(pd.DataFrame({"industry": industries, "key": 1}), on="key").drop(columns="key")
    e = em[em["vintage"] == vintage].groupby(["area", "period", "industry"], as_index=False)["employment"].sum()
    g = grid.merge(e, on=["area", "period", "industry"], how="left")
    g["employment"] = g["employment"].fillna(0.0)
    nat = g.groupby(["period", "industry"], as_index=False)["employment"].sum().rename(columns={"employment": "nat"})
    g = g.merge(nat, on=["period", "industry"]).merge(a, on=["area", "period"]).merge(tg, on=["period", "industry"], how="left")
    g[change_col] = g[change_col].fillna(0.0)
    g["c"] = (g["employment"] / g["total_employment"]) * (g[change_col] / g["nat"]) \
        / (g["price_index"] / 100.0) / 1000.0 * (10.0 / g["years"])
    g["c"] = g["c"].fillna(0.0)
    return g.groupby(["area", "period"], as_index=False)["c"].sum().rename(columns={"c": name})


x = exposure("base", "us_change", "x")
z = exposure("early", "other_change", "z")
pop = ar[ar["vintage"] == "base"][["area", "period", "population"]]
df = oc.merge(x, on=["area", "period"]).merge(z, on=["area", "period"]).merge(pop, on=["area", "period"])
df = df.sort_values(["period", "area"]).reset_index(drop=True)

n = len(df)
y = df["change_pp"].to_numpy(float)
w = df["population"].to_numpy(float)
X = np.column_stack([np.ones(n), df["period"].astype(float), df["control"].astype(float), df["x"]])
Z = np.column_stack([np.ones(n), df["period"].astype(float), df["control"].astype(float), df["z"]])
sw = np.sqrt(w)
Xw, Zw, yw = X * sw[:, None], Z * sw[:, None], y * sw
Pz = Zw @ np.linalg.pinv(Zw.T @ Zw) @ Zw.T
Xh = Pz @ Xw
beta = np.linalg.solve(Xh.T @ Xw, Xh.T @ yw)


def val(col, a, p):
    r = df[(df["area"] == a) & (df["period"] == p)]
    return float(r[col].iloc[0])


periods = sorted(df["period"].unique())
a0 = sorted(df["area"].unique())[0]
est = {
    "iv_slope": float(beta[3]),
    "exposure_area0_period0": val("x", a0, periods[0]),
    "exposure_area0_period1": val("x", a0, periods[1]),
    "instrument_area0_period0": val("z", a0, periods[0]),
}
fs = np.linalg.lstsq(Zw, Xw[:, 3], rcond=None)[0]
out = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [{"term": k, "estimate": float(f"{v:.12g}"), "se": None, "n_obs": int(n)} for k, v in est.items()],
    "method_metadata": {"estimator": "weighted 2SLS", "weights": "base-vintage population",
                        "exogenous": ["intercept", "period", "control"], "endogenous": "x", "instrument": "z"},
    "diagnostics": {"n_obs": int(n), "coefficients": [float(b) for b in beta],
                    "first_stage_z_coef": float(fs[3])},
}
with open("result.json", "w") as f:
    json.dump(out, f, indent=2)
