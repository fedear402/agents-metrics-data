import json
import numpy as np
import pandas as pd
from scipy import stats

df = pd.read_csv("./input.csv")
df = df[["group", "y"]].copy()
df["y"] = pd.to_numeric(df["y"], errors="coerce")
n_raw = len(df)
df = df.dropna(subset=["group", "y"])
df["group"] = df["group"].astype(str).str.strip()

groups = [g["y"].to_numpy(dtype=float) for _, g in df.groupby("group", sort=True)]
group_sizes = {str(k): int(len(v)) for k, v in df.groupby("group", sort=True)["y"]}
k = len(groups)
n = int(len(df))

grand = df["y"].mean()
ssb = sum(len(g) * (g.mean() - grand) ** 2 for g in groups)
ssw = sum(((g - g.mean()) ** 2).sum() for g in groups)
df_num = k - 1
df_den = n - k
msb = ssb / df_num
msw = ssw / df_den
F = msb / msw
p = float(stats.f.sf(F, df_num, df_den))

# cross-check
F_sp, p_sp = stats.f_oneway(*groups)

res = {
    "task_id": "anova_oneway",
    "platform": "python",
    "estimates": [
        {"term": "F", "estimate": float(F), "se": None, "n_obs": n},
        {"term": "df_num", "estimate": float(df_num), "se": None, "n_obs": n},
        {"term": "df_den", "estimate": float(df_den), "se": None, "n_obs": n},
        {"term": "p_value", "estimate": p, "se": None, "n_obs": n},
    ],
    "method_metadata": {"estimator": "one-way ANOVA (classical F test, equal variances)", "vcov": "classical"},
    "diagnostics": {
        "n_groups": k,
        "group_sizes": group_sizes,
        "rows_dropped_missing": int(n_raw - n),
        "ss_between": float(ssb),
        "ss_within": float(ssw),
        "scipy_F": float(F_sp),
        "scipy_p": float(p_sp),
        "levene_p": float(stats.levene(*groups).pvalue) if k > 1 and all(len(g) > 1 for g in groups) else None,
    },
}

with open("result.json", "w") as f:
    json.dump(res, f, indent=2)
