import json
import numpy as np
import pandas as pd

cw = pd.read_csv("crosswalk.csv")
tr = pd.read_csv("trade.csv")
ar = pd.read_csv("areas.csv")
em = pd.read_csv("employment.csv")
oc = pd.read_csv("outcomes.csv")

for d in (cw, tr):
    d["code"] = d["code"].astype(str).str.strip()
for d in (ar, em, oc):
    d["vintage"] = d["vintage"].astype(str).str.strip().str.lower() if "vintage" in d else None
cw["industry"] = cw["industry"].astype(str).str.strip()
em["industry"] = em["industry"].astype(str).str.strip()

tr = tr.merge(cw, on="code", how="inner", validate="many_to_one")
inds = sorted(cw["industry"].unique())

areas = sorted(oc["area"].unique())
periods = sorted(oc["period"].unique())

def build(vintage, change_col):
    e = em[em["vintage"] == vintage].groupby(["area", "period", "industry"], as_index=False)["employment"].sum()
    grid = pd.MultiIndex.from_product([areas, periods, inds], names=["area", "period", "industry"]).to_frame(index=False)
    e = grid.merge(e, on=["area", "period", "industry"], how="left")
    e["employment"] = e["employment"].fillna(0.0)
    nat = e.groupby(["period", "industry"], as_index=False)["employment"].sum().rename(columns={"employment": "nat"})
    e = e.merge(nat, on=["period", "industry"])
    tot = ar[ar["vintage"] == vintage][["area", "period", "total_employment"]]
    e = e.merge(tot, on=["area", "period"], how="left")
    t = tr[["period", "industry", change_col, "price_index", "years"]]
    e = e.merge(t, on=["period", "industry"], how="left")
    e[change_col] = e[change_col].fillna(0.0)
    e["c"] = (e["employment"] / e["total_employment"]) * (e[change_col] / e["nat"]) \
        / (e["price_index"] / 100.0) / 1000.0 * (10.0 / e["years"])
    e["c"] = e["c"].fillna(0.0)
    return e.groupby(["area", "period"], as_index=False)["c"].sum()

x = build("base", "us_change").rename(columns={"c": "x"})
z = build("early", "other_change").rename(columns={"c": "z"})
pop = ar[ar["vintage"] == "base"][["area", "period", "population"]]

df = oc.drop(columns=["vintage"], errors="ignore").merge(x, on=["area", "period"]).merge(z, on=["area", "period"]).merge(pop, on=["area", "period"])
df = df.sort_values(["area", "period"]).reset_index(drop=True)

n = len(df)
y = df["change_pp"].to_numpy(float)
X = np.column_stack([np.ones(n), df["period"].astype(float), df["control"].astype(float), df["x"]])
Z = np.column_stack([np.ones(n), df["period"].astype(float), df["control"].astype(float), df["z"]])
w = df["population"].to_numpy(float)
sw = np.sqrt(w)
Xw, Zw, yw = X * sw[:, None], Z * sw[:, None], y * sw
Pz = Zw @ np.linalg.pinv(Zw.T @ Zw) @ Zw.T
beta = np.linalg.solve(Xw.T @ Pz @ Xw, Xw.T @ Pz @ yw)

# first stage
fs = np.linalg.lstsq(Zw, Xw[:, 3], rcond=None)[0]

def g(a, p, col):
    return float(df.loc[(df["area"] == a) & (df["period"] == p), col].iloc[0])

a0 = 0 if 0 in set(df["area"]) else areas[0]
p0, p1 = periods[0], periods[1]
est = {
    "iv_slope": float(beta[3]),
    "exposure_area0_period0": g(a0, p0, "x"),
    "exposure_area0_period1": g(a0, p1, "x"),
    "instrument_area0_period0": g(a0, p0, "z"),
}
res = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [{"term": k, "estimate": float(f"{v:.15g}"), "se": None, "n_obs": int(n)} for k, v in est.items()],
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "weights": "base-vintage population",
        "exogenous": ["intercept", "period", "control"],
        "endogenous": "x", "instrument": "z",
    },
    "diagnostics": {
        "n_obs": int(n),
        "coefficients": [float(b) for b in beta],
        "first_stage_z_coef": float(fs[3]),
        "n_industries": len(inds),
    },
}
with open("result.json", "w") as f:
    json.dump(res, f, indent=2)
