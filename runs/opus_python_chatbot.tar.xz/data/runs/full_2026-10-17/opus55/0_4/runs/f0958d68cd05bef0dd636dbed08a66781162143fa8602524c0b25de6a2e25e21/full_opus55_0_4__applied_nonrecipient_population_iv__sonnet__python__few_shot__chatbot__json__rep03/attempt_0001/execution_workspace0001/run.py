import json
import numpy as np
import pandas as pd

hh = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

d = hh[hh["recipient"] == 0].copy()
d = d.dropna(subset=["eligible", "dose", "instrument", "baseline", "weight", "outcome"]).reset_index(drop=True)
e = d["eligible"].astype(float).values
ne = 1.0 - e
dose = d["dose"].astype(float).values
base = d["baseline"].astype(float).values
inst = d["instrument"].astype(float).values
w = d["weight"].astype(float).values
y = d["outcome"].astype(float).values
n = len(d)

X = np.column_stack([dose * ne, dose * e, ne, e, base * ne, base * e])
Z = np.column_stack([ne, e, base * ne, base * e, inst * ne, inst * e])

sw = np.sqrt(w)
Xw = X * sw[:, None]
Zw = Z * sw[:, None]
yw = y * sw
# Weighted 2SLS
PzX = Zw @ np.linalg.lstsq(Zw, Xw, rcond=None)[0]
beta = np.linalg.solve(PzX.T @ Xw, PzX.T @ yw)
slope0, slope1 = float(beta[0]), float(beta[1])

m0 = e == 0
m1 = e == 1
mean_dose0 = float(np.average(dose[m0], weights=w[m0]))
mean_dose1 = float(np.average(dose[m1], weights=w[m1]))
eff0 = slope0 * mean_dose0
eff1 = slope1 * mean_dose1

cen = census.copy()
cen["eligible"] = cen["eligible"].astype(int)
pop = cen.groupby("eligible")["nonrecipient_population"].sum()
p0 = float(pop.get(0, 0.0))
p1 = float(pop.get(1, 0.0))
pop_eff = (p0 * eff0 + p1 * eff1) / (p0 + p1)

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {"term": "ineligible_effect", "estimate": float(eff0), "se": None, "n_obs": int(n)},
        {"term": "eligible_nonrecipient_effect", "estimate": float(eff1), "se": None, "n_obs": int(n)},
        {"term": "population_effect", "estimate": float(pop_eff), "se": None, "n_obs": int(n)},
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS, fully interacted by eligibility, no extra intercept",
        "endogenous": ["dose*(1-eligible)", "dose*eligible"],
        "exogenous": ["1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"],
        "excluded_instruments": ["instrument*(1-eligible)", "instrument*eligible"],
        "weights": "weight",
        "sample": "recipient == 0",
        "counterfactual": "dose set to zero (synthetic convention)",
        "aggregation_weights": "census nonrecipient_population",
    },
    "diagnostics": {
        "n_obs": int(n),
        "n_ineligible": int(m0.sum()),
        "n_eligible_nonrecipient": int(m1.sum()),
        "slope_ineligible": slope0,
        "slope_eligible_nonrecipient": slope1,
        "weighted_mean_dose_ineligible": mean_dose0,
        "weighted_mean_dose_eligible_nonrecipient": mean_dose1,
        "census_population_ineligible": p0,
        "census_population_eligible": p1,
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
