clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

capture confirm string variable group
if _rc == 0 {
    encode group, generate(group_id)
}
else {
    generate long group_id = group
}

quietly oneway y group_id

scalar F_value = r(F)
scalar df_num_value = r(df_m)
scalar df_den_value = r(df_r)
scalar p_value_result = Ftail(df_num_value, df_den_value, F_value)
scalar n_value = r(N)

display "ANSWER: F estimate=" %21.12f F_value " se=." " n_obs=" %12.0f n_value
display "ANSWER: df_num estimate=" %21.12f df_num_value " se=." " n_obs=" %12.0f n_value
display "ANSWER: df_den estimate=" %21.12f df_den_value " se=." " n_obs=" %12.0f n_value
display "ANSWER: p_value estimate=" %21.12f p_value_result " se=." " n_obs=" %12.0f n_value
