clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

* Parse dates and sort the trading observations.
capture confirm numeric variable date
if _rc {
    gen double _parsed_date = daily(date, "YMD")
    replace _parsed_date = daily(date, "MDY") if missing(_parsed_date)
    replace _parsed_date = daily(date, "DMY") if missing(_parsed_date)
    format _parsed_date %td
    drop date
    rename _parsed_date date
}
sort date

* Set the trading-observation time index for Newey-West estimation.
gen long obs_id = _n
tsset obs_id

* Calculate log sales and the first difference of log volatility.
gen double log_sales = ln(sales)
gen double log_vix = ln(vix)
gen double dlog_vix = D.log_vix

* Generate lags across consecutive trading observations.
forvalues j = 1/15 {
    gen double lag_`j' = L`j'.dlog_vix
}

* Keep observations with a complete set of lagged changes.
drop if missing(log_sales, lag_1, lag_2, lag_3, lag_4, lag_5, lag_6, lag_7, lag_8, lag_9, lag_10, lag_11, lag_12, lag_13, lag_14, lag_15)

quietly count
scalar N_obs = r(N)

* Estimate the model with an intercept.
quietly newey log_sales lag_1-lag_15, lag(15)

* Save coefficients and apply the requested covariance correction.
matrix V_adj = e(V) * (N_obs / (N_obs - 16))

scalar b_cumulative = 0
forvalues j = 1/15 {
    scalar b_cumulative = b_cumulative + _b[lag_`j']
}

* Use the full coefficient covariance matrix for the cumulative standard error.
scalar var_cumulative = 0
forvalues j = 1/15 {
    scalar var_cumulative = var_cumulative + V_adj[`=`j'+1',`=`j'+1']
    forvalues k = `=`j'+1'/15 {
        scalar var_cumulative = var_cumulative + 2 * V_adj[`=`j'+1',`=`k'+1']
    }
}
scalar se_cumulative = sqrt(var_cumulative)

scalar b_lag1 = _b[lag_1]
scalar se_lag1 = sqrt(V_adj[2,2])
scalar b_lag15 = _b[lag_15]
scalar se_lag15 = sqrt(V_adj[16,16])

display "ANSWER: cumulative_response estimate=" %21.12f b_cumulative " se=" %21.12f se_cumulative " n_obs=" %12.0f N_obs
display "ANSWER: lag_1 estimate=" %21.12f b_lag1 " se=" %21.12f se_lag1 " n_obs=" %12.0f N_obs
display "ANSWER: lag_15 estimate=" %21.12f b_lag15 " se=" %21.12f se_lag15 " n_obs=" %12.0f N_obs
