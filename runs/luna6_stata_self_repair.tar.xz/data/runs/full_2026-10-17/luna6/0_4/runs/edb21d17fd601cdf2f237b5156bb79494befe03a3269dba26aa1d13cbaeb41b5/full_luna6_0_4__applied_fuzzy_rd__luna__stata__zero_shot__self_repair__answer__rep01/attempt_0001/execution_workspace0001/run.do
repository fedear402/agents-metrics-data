clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

keep if abs(score) < 1
generate double weight = 1 - abs(score)
generate double right = score >= 0
generate double right_score = right * score

quietly count
scalar N = r(N)

quietly regress earnings right score right_score [aw=weight], vce(robust)
scalar rf = _b[right]
matrix V_y = e(V)
scalar var_rf = V_y[1,1]

quietly regress participated right score right_score [aw=weight], vce(robust)
scalar fs = _b[right]
matrix V_d = e(V)
scalar var_fs = V_d[1,1]

quietly summarize earnings, meanonly
generate double residual_y = earnings - (_b[_cons] + _b[right]*right + _b[score]*score + _b[right_score]*right_score)
quietly summarize participated, meanonly
generate double residual_d = participated - (_b[_cons] + _b[right]*right + _b[score]*score + _b[right_score]*right_score)

* Joint HC0 covariance for the two right-minus-left intercept estimates.
generate double score0 = 1
generate double w2 = weight^2
quietly generate double s_y = weight * residual_y
quietly generate double s_d = weight * residual_d
quietly generate double z1 = right
quietly generate double z2 = score
quietly generate double z3 = right_score

* Estimate each model's weighted design matrix and HC0 meat cross-covariance.
quietly regress earnings right score right_score [aw=weight]
matrix Xy = e(V)
matrix Ay = invsym(Xy)
quietly regress participated right score right_score [aw=weight]
matrix Xd = e(V)
matrix Ad = invsym(Xd)

* The robust regressions above use the same regressors and weights. Recover
* the cross-equation HC0 sandwich covariance from paired observation scores.
quietly summarize w2, meanonly
scalar S11 = r(sum)
quietly summarize w2 if right == 1, meanonly
scalar S22 = r(sum)
quietly summarize w2 if score != 0, meanonly
scalar S33 = r(sum)

* Build the cross-product of weighted regressors times paired residuals.
mata:
    st_view(R=., ., ("right","score","right_score","weight","residual_y","residual_d"))
    X = (J(rows(R),1,1), R[,1..3])
    w = R[,4]
    uy = R[,5]
    ud = R[,6]
    B = quadcross(X, X :* (w:^2 :* uy :* ud))
    st_matrix("B", B)
end

matrix Cy = e(V)
* Obtain the bread matrices from the weighted least-squares normal equations.
mata:
    st_view(R=., ., ("right","score","right_score","weight"))
    X = (J(rows(R),1,1), R[,1..3])
    w = R[,4]
    A = invsym(quadcross(X, X :* w))
    st_matrix("A", A)
end

matrix C = A * B * A'
scalar cov_rf_fs = C[2,2]

scalar te = rf/fs
scalar var_te = (var_rf/(fs^2)) + ((rf^2)*var_fs/(fs^4)) - (2*rf*cov_rf_fs/(fs^3))
scalar se_te = sqrt(var_te)

display "ANSWER: treatment_effect estimate=" %21.12f te " se=" %21.12f se_te " n_obs=" %12.0f N
display "ANSWER: reduced_form estimate=" %21.12f rf " se=" %21.12f sqrt(var_rf) " n_obs=" %12.0f N
display "ANSWER: first_stage estimate=" %21.12f fs " se=" %21.12f sqrt(var_fs) " n_obs=" %12.0f N
