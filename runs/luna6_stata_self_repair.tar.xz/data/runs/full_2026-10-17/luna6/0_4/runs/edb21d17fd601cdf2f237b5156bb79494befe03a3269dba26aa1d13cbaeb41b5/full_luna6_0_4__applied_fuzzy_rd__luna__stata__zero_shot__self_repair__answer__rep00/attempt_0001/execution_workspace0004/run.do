clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

keep if abs(score) < 1
generate double weight = 1 - abs(score)
generate byte right = score >= 0
generate double slope = score * right
generate double left_slope = score * (1 - right)

quietly count
scalar n_obs = r(N)

* Fit weighted local-linear regressions on the same observations.
quietly regress earnings right slope left_slope [aw=weight], noconstant
scalar reduced_form = _b[right]
predict double resid_y, residuals

quietly regress participated right slope left_slope [aw=weight], noconstant
scalar first_stage = _b[right]
predict double resid_d, residuals

* HC0 sandwich covariance for the right-side intercept estimates.
generate double score_y = weight * resid_y * right
generate double score_d = weight * resid_d * right
generate double score_yy = score_y^2
generate double score_dd = score_d^2
generate double score_yd = score_y * score_d

quietly summarize score_yy, meanonly
scalar meat_yy = r(sum)
quietly summarize score_dd, meanonly
scalar meat_dd = r(sum)
quietly summarize score_yd, meanonly
scalar meat_yd = r(sum)

quietly generate double w_right = weight * right
quietly generate double w_right_slope = weight * right * slope
quietly generate double w_right_slope2 = weight * right * slope^2

quietly summarize w_right, meanonly
scalar s0 = r(sum)
quietly summarize w_right_slope, meanonly
scalar s1 = r(sum)
quietly summarize w_right_slope2, meanonly
scalar s2 = r(sum)

scalar det = s0*s2 - s1^2
scalar bread11 = s2/det

scalar var_rf = bread11^2 * meat_yy
scalar var_fs = bread11^2 * meat_dd
scalar cov_rf_fs = bread11^2 * meat_yd

scalar se_rf = sqrt(var_rf)
scalar se_fs = sqrt(var_fs)
scalar treatment_effect = reduced_form / first_stage
scalar se_te = sqrt(var_rf / first_stage^2 + reduced_form^2 * var_fs / first_stage^4 - 2 * reduced_form * cov_rf_fs / first_stage^3)

display "ANSWER: treatment_effect estimate=" %21.12f treatment_effect " se=" %21.12f se_te " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f reduced_form " se=" %21.12f se_rf " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f first_stage " se=" %21.12f se_fs " n_obs=" %12.0f n_obs
