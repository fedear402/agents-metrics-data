version 16.0
clear all
set more off

tempfile crosswalk trade areas employment outcomes national_area national_trade estimation

import delimited using "crosswalk.csv", clear varnames(1) stringcols(_all)
destring code industry, replace
isid code
save `crosswalk'

import delimited using "trade.csv", clear varnames(1) stringcols(_all)
destring period code us_change other_change price_index years, replace
isid period code
merge m:1 code using `crosswalk', assert(match) nogen
collapse (sum) us_change other_change (mean) price_index years, by(period industry)
isid period industry
save `trade'

import delimited using "areas.csv", clear varnames(1) stringcols(_all)
destring area period total_employment population, replace
isid area period vintage
reshape wide total_employment population, i(area period) j(vintage) string
rename total_employmentbase base_total_employment
rename total_employmentearly early_total_employment
rename populationbase population
keep area period base_total_employment early_total_employment population
isid area period
save `areas'

import delimited using "employment.csv", clear varnames(1) stringcols(_all)
destring area period industry employment, replace
collapse (sum) employment, by(area period vintage industry)
reshape wide employment, i(area period industry) j(vintage) string
foreach v in base early {
    capture confirm variable employment`v'
    if _rc generate double employment`v' = 0
    replace employment`v' = 0 if missing(employment`v')
}
save `employment'

use `areas', clear
joinby area period using `employment'
merge m:1 period industry using `trade', assert(match) nogen
generate double base_share = employmentbase / base_total_employment
generate double early_share = employmentearly / early_total_employment
generate double x_component = base_share * (us_change / price_index) / 1000 * (10 / years)
generate double z_component = early_share * (other_change / price_index) / 1000 * (10 / years)
collapse (sum) x=x_component z=z_component, by(area period)
save `national_area'

use `employment', clear
collapse (sum) national_base=employmentbase national_early=employmentearly, by(period industry)
isid period industry
save `national_trade'

use `areas', clear
joinby area period using `employment'
merge m:1 period industry using `trade', assert(match) nogen
merge m:1 period industry using `national_trade', assert(match) nogen
generate double x_component = (employmentbase / base_total_employment) * (us_change / national_base) / (price_index / 100) / 1000 * (10 / years)
generate double z_component = (employmentearly / early_total_employment) * (other_change / national_early) / (price_index / 100) / 1000 * (10 / years)
collapse (sum) x=x_component z=z_component, by(area period)
merge 1:1 area period using `areas', assert(match) nogen
save `national_area', replace

import delimited using "outcomes.csv", clear varnames(1) stringcols(_all)
destring area period control change_pp, replace
isid area period
merge 1:1 area period using `national_area', assert(match) nogen
isid area period
count
assert r(N) == 72
save `estimation'

quietly ivregress 2sls change_pp (x = z) i.period control [pw=population]
scalar iv_slope = _b[x]

use `estimation', clear
quietly summarize x if area == 0 & period == 0, meanonly
scalar exposure_area0_period0 = r(mean)
quietly summarize x if area == 0 & period == 1, meanonly
scalar exposure_area0_period1 = r(mean)
quietly summarize z if area == 0 & period == 0, meanonly
scalar instrument_area0_period0 = r(mean)

display as text "ANSWER: iv_slope estimate=" as result %21.12g scalar(iv_slope) as text " se=NA n_obs=72"
display as text "ANSWER: exposure_area0_period0 estimate=" as result %21.12g scalar(exposure_area0_period0) as text " se=NA n_obs=72"
display as text "ANSWER: exposure_area0_period1 estimate=" as result %21.12g scalar(exposure_area0_period1) as text " se=NA n_obs=72"
display as text "ANSWER: instrument_area0_period0 estimate=" as result %21.12g scalar(instrument_area0_period0) as text " se=NA n_obs=72"
