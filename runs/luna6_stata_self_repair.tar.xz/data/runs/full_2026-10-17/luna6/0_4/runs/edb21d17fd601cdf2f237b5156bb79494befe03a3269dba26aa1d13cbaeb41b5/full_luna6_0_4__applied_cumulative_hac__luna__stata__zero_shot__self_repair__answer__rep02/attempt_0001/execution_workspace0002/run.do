clear all
set more off
set linesize 255

import delimited "./input.csv", clear

sort date

generate double log_vix = ln(vix)
generate double delta_log_vix = log_vix - log_vix[_n-1] if _n > 1
generate double log_sales = ln(sales)

forvalues j = 1/15 {
    generate double lag_`j' = delta_log_vix[_n-`j']
}

regress log_sales lag_1-lag_15

scalar N = e(N)
scalar cumulative_response = 0
forvalues j = 1/15 {
    scalar cumulative_response = cumulative_response + _b[lag_`j']
}

* Build the full design matrix, including the intercept.
matrix XX = e(V)
matrix XX_inv = syminv(XX)
matrix S = J(16,16,0)

predict double residual, resid
forvalues j = 1/15 {
    generate double score_`j' = lag_`j' * residual
}
generate double score_0 = residual

* Add lag-zero score cross-products.
forvalues j = 0/15 {
    forvalues k = 0/15 {
        quietly summarize score_`j' * score_`k', meanonly
        matrix S[`=`j'+1',`=`k'+1'] = r(sum)
    }
}

* Add Bartlett-weighted autocovariances at lags 1 through 15.
forvalues h = 1/15 {
    scalar weight = 1 - `h'/16
    forvalues j = 0/15 {
        forvalues k = 0/15 {
            quietly generate double __cross = score_`j' * score_`k'[_n-`h']
            quietly summarize __cross, meanonly
            matrix S[`=`j'+1',`=`k'+1'] = S[`=`j'+1',`=`k'+1'] + weight*r(sum)
            matrix S[`=`k'+1',`=`j'+1'] = S[`=`k'+1',`=`j'+1'] + weight*r(sum)
            drop __cross
        }
    }
}

matrix V_NW = XX_inv * S * XX_inv
matrix V_NW = V_NW * (N/(N-16))

scalar nw_var_cumulative = 0
forvalues j = 1/15 {
    forvalues k = 1/15 {
        scalar nw_var_cumulative = nw_var_cumulative + V_NW[`=`j'+1',`=`k'+1']
    }
}
scalar nw_se_cumulative = sqrt(nw_var_cumulative)
scalar nw_se_lag1 = sqrt(V_NW[2,2])
scalar nw_se_lag15 = sqrt(V_NW[16,16])

display "ANSWER: cumulative_response estimate=" %21.12f cumulative_response " se=" %21.12f nw_se_cumulative " n_obs=" %12.0f N
display "ANSWER: lag_1 estimate=" %21.12f _b[lag_1] " se=" %21.12f nw_se_lag1 " n_obs=" %12.0f N
display "ANSWER: lag_15 estimate=" %21.12f _b[lag_15] " se=" %21.12f nw_se_lag15 " n_obs=" %12.0f N
