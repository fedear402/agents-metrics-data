clear all
set more off
set linesize 255

import delimited "./input.csv", clear
sort date

generate double log_vix = ln(vix)
generate double delta_log_vix = log_vix - log_vix[_n-1] if _n > 1
generate double log_sales = ln(sales)

forvalues j = 1/15 {
    generate double lag_`j' = delta_log_vix[_n-`j']
}

quietly regress log_sales lag_1-lag_15
scalar N = e(N)

scalar cumulative_response = 0
forvalues j = 1/15 {
    scalar cumulative_response = cumulative_response + _b[lag_`j']
}

* Build the design matrix on the regression sample. Include the intercept.
generate byte reg_sample = e(sample)
mkmat lag_1-lag_15 if reg_sample, matrix(Xlags)
matrix X = J(rowsof(Xlags), 1, 1), Xlags

predict double residual if reg_sample, resid
mkmat residual if reg_sample, matrix(U)
matrix scores = X :* U
matrix meat = scores' * scores

* Add Bartlett-weighted score cross-products for lags 1 through 15.
forvalues h = 1/15 {
    local w = 1 - `h'/16
    forvalues t = `=`h'+1'/`=rowsof(scores)' {
        forvalues j = 1/16 {
            forvalues k = 1/16 {
                matrix meat[`j',`k'] = meat[`j',`k'] + ///
                    `w' * (scores[`t',`j'] * scores[`=`t'-`h'',`k'] + ///
                    scores[`=`t'-`h'',`j'] * scores[`t',`k'])
            }
        }
    }
}

matrix bread = syminv(X' * X)
matrix V_NW = bread * meat * bread
matrix V_NW = V_NW * (N/(N-16))

scalar nw_var_cumulative = 0
forvalues j = 2/16 {
    forvalues k = 2/16 {
        scalar nw_var_cumulative = nw_var_cumulative + V_NW[`j',`k']
    }
}
scalar nw_se_cumulative = sqrt(nw_var_cumulative)
scalar nw_se_lag1 = sqrt(V_NW[2,2])
scalar nw_se_lag15 = sqrt(V_NW[16,16])

display "ANSWER: cumulative_response estimate=" %21.12f cumulative_response " se=" %21.12f nw_se_cumulative " n_obs=" %12.0f N
display "ANSWER: lag_1 estimate=" %21.12f _b[lag_1] " se=" %21.12f nw_se_lag1 " n_obs=" %12.0f N
display "ANSWER: lag_15 estimate=" %21.12f _b[lag_15] " se=" %21.12f nw_se_lag15 " n_obs=" %12.0f N
