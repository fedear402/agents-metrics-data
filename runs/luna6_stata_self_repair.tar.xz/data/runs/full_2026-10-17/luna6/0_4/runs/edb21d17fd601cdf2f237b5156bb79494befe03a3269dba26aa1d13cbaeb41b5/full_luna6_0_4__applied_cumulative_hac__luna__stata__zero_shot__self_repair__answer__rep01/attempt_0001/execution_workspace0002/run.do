clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

gen double date_num = daily(date, "YMD")
format date_num %td
sort date_num

gen long trading_index = _n
tsset trading_index

gen double ln_vix = ln(vix)
gen double d_ln_vix = D.ln_vix

forvalues j = 1/15 {
    gen double lag_`j' = L`j'.d_ln_vix
}

gen double ln_sales = ln(sales)

newey ln_sales lag_1-lag_15, lag(15)

scalar n_obs = e(N)
matrix b = e(b)
matrix V = e(V)

scalar correction = n_obs / (n_obs - 16)
scalar cumulative_response = 0
scalar cumulative_variance = 0

forvalues i = 1/15 {
    local name_i lag_`i'
    scalar cumulative_response = cumulative_response + b[1, "`name_i'"]
    forvalues j = 1/15 {
        local name_j lag_`j'
        scalar cumulative_variance = cumulative_variance + ///
            correction * V["`name_i'", "`name_j'"]
    }
}

scalar cumulative_se = sqrt(cumulative_variance)
scalar lag1_estimate = b[1, "lag_1"]
scalar lag1_se = sqrt(correction * V["lag_1", "lag_1"])
scalar lag15_estimate = b[1, "lag_15"]
scalar lag15_se = sqrt(correction * V["lag_15", "lag_15"])

display "ANSWER: cumulative_response estimate=" %21.12f cumulative_response " se=" %21.12f cumulative_se " n_obs=" %12.0f n_obs
display "ANSWER: lag_1 estimate=" %21.12f lag1_estimate " se=" %21.12f lag1_se " n_obs=" %12.0f n_obs
display "ANSWER: lag_15 estimate=" %21.12f lag15_estimate " se=" %21.12f lag15_se " n_obs=" %12.0f n_obs
