clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

sort date

generate double ln_sales = ln(sales)
generate double d_ln_vix = ln(vix) - ln(vix[_n-1])

forvalues j = 1/15 {
    generate double lag_`j' = d_ln_vix[_n-`j']
}

regress ln_sales lag_1-lag_15 if !missing(ln_sales, lag_1, lag_2, lag_3, lag_4, lag_5, lag_6, lag_7, lag_8, lag_9, lag_10, lag_11, lag_12, lag_13, lag_14, lag_15)

local N = e(N)
matrix b = e(b)
matrix V = e(V)

scalar scale = `N' / (`N' - 16)
matrix Vnw = J(16, 16, 0)
matrix Vnw = V

* Newey-West covariance with Bartlett weights and maximum lag 15.
newey ln_sales lag_1-lag_15 if !missing(ln_sales, lag_1, lag_2, lag_3, lag_4, lag_5, lag_6, lag_7, lag_8, lag_9, lag_10, lag_11, lag_12, lag_13, lag_14, lag_15), lag(15)

matrix Vnw = e(V)
scalar cumulative_response = 0
forvalues j = 1/15 {
    scalar cumulative_response = cumulative_response + _b[lag_`j']
}

* Apply the requested finite-sample covariance multiplier.
scalar se_cumulative = .
scalar variance_cumulative = 0
forvalues i = 1/15 {
    forvalues j = 1/15 {
        scalar variance_cumulative = variance_cumulative + Vnw[`i'+1,`j'+1]
    }
}
scalar se_cumulative = sqrt(variance_cumulative * scale)

scalar se_lag1 = sqrt(Vnw[2,2] * scale)
scalar se_lag15 = sqrt(Vnw[16,16] * scale)

display "ANSWER: cumulative_response estimate=" %21.12f cumulative_response " se=" %21.12f se_cumulative " n_obs=" %12.0f `N'
display "ANSWER: lag_1 estimate=" %21.12f _b[lag_1] " se=" %21.12f se_lag1 " n_obs=" %12.0f `N'
display "ANSWER: lag_15 estimate=" %21.12f _b[lag_15] " se=" %21.12f se_lag15 " n_obs=" %12.0f `N'
