clear all
set more off
version 16.0

import delimited using "crosswalk.csv", clear varnames(1) stringcols(_all)
tempfile crosswalk
save `crosswalk'

import delimited using "trade.csv", clear varnames(1)
merge m:1 code using `crosswalk', keep(match) nogen
tempfile trade
save `trade'

import delimited using "areas.csv", clear varnames(1)
tempfile areas
save `areas'

import delimited using "employment.csv", clear varnames(1)
tempfile employment
save `employment'

import delimited using "outcomes.csv", clear varnames(1)
tempfile outcomes
save `outcomes'

* Build area-period employment shares for each vintage and industry.
use `areas', clear
keep area period vintage total_employment population
joinby area period vintage using `employment'
collapse (sum) employment, by(area period vintage industry)
tempfile observed_emp
save `observed_emp'

* Add zero-employment industry cells omitted from employment.csv.
use `areas', clear
keep area period vintage total_employment population
duplicates drop
tempfile area_vintage
save `area_vintage'

use `crosswalk', clear
keep industry
duplicates drop
tempfile industries
save `industries'

use `area_vintage', clear
cross using `industries'
merge 1:1 area period vintage industry using `observed_emp', nogen
replace employment = 0 if missing(employment)

* National employment by period, vintage, and industry sums all areas.
bysort period vintage industry: egen national_employment = total(employment)
gen share = employment / total_employment
keep area period vintage population industry share national_employment
duplicates drop
tempfile shares
save `shares'

* Prepare trade changes by period and industry.
use `trade', clear
collapse (sum) us_change other_change (mean) price_index years, by(period industry)
tempfile trade_industry
save `trade_industry'

* Compute exposure components and sum across the four industries.
use `shares', clear
merge m:1 period industry using `trade_industry', keep(match) nogen
gen x_component = share * (us_change / national_employment) ///
    / (price_index / 100) / 1000 * (10 / years) if vintage == "base"
gen z_component = share * (other_change / national_employment) ///
    / (price_index / 100) / 1000 * (10 / years) if vintage == "early"
collapse (sum) x=x_component z=z_component, by(area period vintage population)
keep if vintage == "base"
keep area period population x
tempfile base_exposure
save `base_exposure'

use `shares', clear
merge m:1 period industry using `trade_industry', keep(match) nogen
gen z_component = share * (other_change / national_employment) ///
    / (price_index / 100) / 1000 * (10 / years) if vintage == "early"
collapse (sum) z=z_component, by(area period vintage)
keep if vintage == "early"
keep area period z
tempfile early_exposure
save `early_exposure'

* Combine base-vintage x and early-vintage z with outcomes.
use `base_exposure', clear
merge 1:1 area period using `early_exposure', keep(match) nogen
merge 1:1 area period using `outcomes', keep(match) nogen

* Set period indicator to one for the later period.
egen period_id = group(period)
gen period_indicator = period_id - 1

* Weighted 2SLS; include all exogenous regressors as instruments.
ivregress 2sls change_pp period_indicator control (x = z) [aw=population], vce(robust)
scalar iv_slope = _b[x]

quietly summarize x if area == 0 & period_indicator == 0, meanonly
scalar exposure_area0_period0 = r(mean)

quietly summarize x if area == 0 & period_indicator == 1, meanonly
scalar exposure_area0_period1 = r(mean)

quietly summarize z if area == 0 & period_indicator == 0, meanonly
scalar instrument_area0_period0 = r(mean)

local n = e(N)
display "ANSWER: iv_slope estimate=" %21.12g scalar(iv_slope) " se=NA n_obs=" %3.0f `n'
display "ANSWER: exposure_area0_period0 estimate=" %21.12g scalar(exposure_area0_period0) " se=NA n_obs=" %3.0f `n'
display "ANSWER: exposure_area0_period1 estimate=" %21.12g scalar(exposure_area0_period1) " se=NA n_obs=" %3.0f `n'
display "ANSWER: instrument_area0_period0 estimate=" %21.12g scalar(instrument_area0_period0) " se=NA n_obs=" %3.0f `n'
