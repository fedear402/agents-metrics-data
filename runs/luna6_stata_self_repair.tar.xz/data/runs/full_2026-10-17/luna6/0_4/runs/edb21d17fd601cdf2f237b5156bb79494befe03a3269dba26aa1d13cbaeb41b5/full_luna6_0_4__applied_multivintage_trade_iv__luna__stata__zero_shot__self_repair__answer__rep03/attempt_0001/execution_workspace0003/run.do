version 16.0
clear all
set more off

* Read and validate the trade-code crosswalk.
import delimited using "crosswalk.csv", clear
isid code
tempfile crosswalk
save `crosswalk'

* Join every trade row to its industry.
import delimited using "trade.csv", clear
merge m:1 code using `crosswalk', assert(match) nogen
isid period industry
tempfile trade
save `trade'

* Read supplied area and outcome rows.
import delimited using "areas.csv", clear
isid area period vintage
tempfile areas
save `areas'

import delimited using "employment.csv", clear
isid area period vintage industry
tempfile employment
save `employment'

import delimited using "outcomes.csv", clear
isid area period
tempfile outcomes
save `outcomes'

* Create four industry cells per supplied area-period-vintage.
use `areas', clear
keep area period vintage total_employment population
expand 4
bysort area period vintage: gen industry = _n
merge 1:1 area period vintage industry using `employment', ///
    keep(master match) nogen
replace employment = 0 if missing(employment)

* Compute national employment by period, vintage, and industry.
bysort period vintage industry: egen double national_employment = total(employment)
tempfile cells
save `cells'

* Save base-vintage area employment and total employment.
use `cells', clear
keep if vintage == "base"
rename employment base_employment
rename total_employment base_total_employment
keep area period industry base_employment base_total_employment population
tempfile basecells
save `basecells'

* Save early-vintage area employment.
use `cells', clear
keep if vintage == "early"
rename employment early_employment
keep area period industry early_employment
tempfile earlycells
save `earlycells'

* Save national employment denominators for both vintages.
use `cells', clear
keep period vintage industry national_employment
duplicates drop
reshape wide national_employment, i(period industry) j(vintage) string
rename national_employmentbase national_base_employment
rename national_employmentearly national_early_employment
tempfile national
save `national'

* Save the trade changes and period-specific deflator inputs.
use `trade', clear
keep period industry us_change other_change price_index years
isid period industry
tempfile tradekey
save `tradekey'

* Combine area employment, national employment, and trade data.
use `basecells', clear
merge 1:1 area period industry using `earlycells', assert(match) nogen
merge m:1 period industry using `national', assert(match) nogen
merge m:1 period industry using `tradekey', assert(match) nogen

* Construct the requested exposure and instrument.
gen double x_component = ///
    (base_employment / base_total_employment) * ///
    (us_change / national_base_employment) / ///
    (price_index / 100) / 1000 * (10 / years)

gen double z_component = ///
    (early_employment / base_total_employment) * ///
    (other_change / national_early_employment) / ///
    (price_index / 100) / 1000 * (10 / years)

collapse (sum) x=x_component z=z_component, by(area period)
merge 1:1 area period using `outcomes', assert(match) nogen

* Use a numeric period variable while retaining the supplied period ordering.
capture confirm numeric variable period
if _rc {
    encode period, gen(period_numeric)
}
else {
    gen double period_numeric = period
}

* Estimate weighted 2SLS with all exogenous regressors as instruments.
quietly count
local n_obs = r(N)
ivregress 2sls change_pp period_numeric control ///
    (x = z) [aweight=population], vce(robust)
scalar iv_slope = _b[x]

quietly summarize x if area == 0 & period == 0, meanonly
scalar exposure_area0_period0 = r(mean)

quietly summarize x if area == 0 & period == 1, meanonly
scalar exposure_area0_period1 = r(mean)

quietly summarize z if area == 0 & period == 0, meanonly
scalar instrument_area0_period0 = r(mean)

display "ANSWER: iv_slope estimate=" %21.12g scalar(iv_slope) " se=NA n_obs=`n_obs'"
display "ANSWER: exposure_area0_period0 estimate=" %21.12g scalar(exposure_area0_period0) " se=NA n_obs=`n_obs'"
display "ANSWER: exposure_area0_period1 estimate=" %21.12g scalar(exposure_area0_period1) " se=NA n_obs=`n_obs'"
display "ANSWER: instrument_area0_period0 estimate=" %21.12g scalar(instrument_area0_period0) " se=NA n_obs=`n_obs'"
