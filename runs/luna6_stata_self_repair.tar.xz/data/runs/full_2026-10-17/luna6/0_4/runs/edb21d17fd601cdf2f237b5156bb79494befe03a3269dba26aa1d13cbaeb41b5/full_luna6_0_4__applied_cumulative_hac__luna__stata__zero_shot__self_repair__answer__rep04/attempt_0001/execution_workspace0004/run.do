clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

gen double date_num = date(date, "YMD")
format date_num %td
sort date_num

gen double ln_sales = ln(sales)
gen double dln_vix = ln(vix) - ln(vix[_n-1])

forvalues j = 1/15 {
    gen double lag_`j' = dln_vix[_n-`j']
}

regress ln_sales lag_1-lag_15
local N = e(N)

predict double uhat if e(sample), residuals

mata:
    st_view(X=., ., tokens("lag_1 lag_2 lag_3 lag_4 lag_5 lag_6 lag_7 lag_8 lag_9 lag_10 lag_11 lag_12 lag_13 lag_14 lag_15"), "uhat")
    st_view(u=., ., "uhat")
    n = rows(X)
    Z = J(n,1,1), X
    bread = invsym(Z'Z)
    S = J(cols(Z), cols(Z), 0)

    for (t=1; t<=n; t++) {
        zt = Z[t,.]'
        S = S + (u[t]^2)*(zt*zt')
    }

    for (j=1; j<=15; j++) {
        w = 1-j/16
        Gj = J(cols(Z), cols(Z), 0)
        for (t=j+1; t<=n; t++) {
            zt = Z[t,.]'
            zlag = Z[t-j,.]'
            Gj = Gj + u[t]*u[t-j]*(zt*zlag')
        }
        S = S + w*(Gj + Gj')
    }

    Vnw = bread*S*bread * (n/(n-16))
    st_matrix("Vnw", Vnw)
end

matrix b = e(b)
scalar cumulative_response = 0
forvalues j = 1/15 {
    scalar beta_`j' = b[1, "lag_`j'"]
    scalar cumulative_response = cumulative_response + beta_`j'
}

scalar variance_cumulative = 0
forvalues i = 2/16 {
    forvalues j = 2/16 {
        scalar variance_cumulative = variance_cumulative + Vnw[`i',`j']
    }
}

scalar se_cumulative = sqrt(variance_cumulative)
scalar se_lag1 = sqrt(Vnw[2,2])
scalar se_lag15 = sqrt(Vnw[16,16])

display "ANSWER: cumulative_response estimate=" %21.12f cumulative_response " se=" %21.12f se_cumulative " n_obs=" %12.0f `N'
display "ANSWER: lag_1 estimate=" %21.12f beta_1 " se=" %21.12f se_lag1 " n_obs=" %12.0f `N'
display "ANSWER: lag_15 estimate=" %21.12f beta_15 " se=" %21.12f se_lag15 " n_obs=" %12.0f `N'
