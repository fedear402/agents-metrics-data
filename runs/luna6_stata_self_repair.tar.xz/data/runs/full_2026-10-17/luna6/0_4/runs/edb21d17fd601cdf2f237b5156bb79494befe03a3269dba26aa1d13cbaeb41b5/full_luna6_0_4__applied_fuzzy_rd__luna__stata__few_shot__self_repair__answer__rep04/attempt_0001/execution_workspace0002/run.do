version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

keep if abs(score) < 1
generate double weight = 1 - abs(score)
generate double right = score >= 0
generate double right_score = right * score

quietly count
scalar n_obs = r(N)

* Fit weighted local-linear models with side-specific intercepts and slopes.
quietly regress earnings right score right_score [aweight=weight]
scalar reduced_form = _b[right]
predict double resid_y, residuals

quietly regress participated right score right_score [aweight=weight]
scalar first_stage = _b[right]
predict double resid_d, residuals

* Build the shared HC0 sandwich for both outcomes.
generate double q1 = weight
generate double q2 = weight * right
generate double q3 = weight * score
generate double q4 = weight * right_score

matrix XWX = J(4,4,0)
forvalues i = 1/4 {
    forvalues j = 1/4 {
        quietly generate double product = q`i' * q`j'
        quietly summarize product, meanonly
        matrix XWX[`i',`j'] = r(sum)
        drop product
    }
}
matrix B = syminv(XWX)

generate double score_y1 = weight * resid_y
generate double score_y2 = weight * right * resid_y
generate double score_y3 = weight * score * resid_y
generate double score_y4 = weight * right_score * resid_y
generate double score_d1 = weight * resid_d
generate double score_d2 = weight * right * resid_d
generate double score_d3 = weight * score * resid_d
generate double score_d4 = weight * right_score * resid_d

matrix MeatYY = J(4,4,0)
matrix MeatDD = J(4,4,0)
matrix MeatYD = J(4,4,0)
forvalues i = 1/4 {
    forvalues j = 1/4 {
        quietly generate double prod_yy = score_y`i' * score_y`j'
        quietly summarize prod_yy, meanonly
        matrix MeatYY[`i',`j'] = r(sum)
        drop prod_yy

        quietly generate double prod_dd = score_d`i' * score_d`j'
        quietly summarize prod_dd, meanonly
        matrix MeatDD[`i',`j'] = r(sum)
        drop prod_dd

        quietly generate double prod_yd = score_y`i' * score_d`j'
        quietly summarize prod_yd, meanonly
        matrix MeatYD[`i',`j'] = r(sum)
        drop prod_yd
    }
}

matrix VYY = B * MeatYY * B
matrix VDD = B * MeatDD * B
matrix VYD = B * MeatYD * B

scalar var_rf = el(VYY,2,2)
scalar var_fs = el(VDD,2,2)
scalar cov_rf_fs = el(VYD,2,2)
scalar se_rf = sqrt(var_rf)
scalar se_fs = sqrt(var_fs)

scalar treatment_effect = reduced_form / first_stage
scalar delta_var = var_rf / (first_stage^2) + ///
    (reduced_form^2 * var_fs / (first_stage^4)) - ///
    (2 * reduced_form * cov_rf_fs / (first_stage^3))
scalar delta_se = sqrt(delta_var)

display "ANSWER: treatment_effect estimate=" %21.12f treatment_effect " se=" %21.12f delta_se " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f reduced_form " se=" %21.12f se_rf " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f first_stage " se=" %21.12f se_fs " n_obs=" %12.0f n_obs
