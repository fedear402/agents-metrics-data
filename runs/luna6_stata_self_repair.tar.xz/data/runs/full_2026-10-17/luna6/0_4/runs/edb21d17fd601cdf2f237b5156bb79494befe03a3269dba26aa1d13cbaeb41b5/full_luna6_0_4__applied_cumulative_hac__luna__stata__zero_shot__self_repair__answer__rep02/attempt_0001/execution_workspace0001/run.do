clear all
set more off
set linesize 255

import delimited "./input.csv", clear

sort date

generate double log_vix = ln(vix)
generate double delta_log_vix = log_vix - log_vix[_n-1] if _n > 1
generate double log_sales = ln(sales)

forvalues j = 1/15 {
    generate double lag_`j' = delta_log_vix[_n-`j']
}

regress log_sales lag_1-lag_15

scalar N = e(N)
scalar cumulative_response = 0
forvalues j = 1/15 {
    scalar cumulative_response = cumulative_response + _b[lag_`j']
}

matrix V = e(V)
scalar nw_var_cumulative = 0
forvalues j = 1/15 {
    forvalues k = 1/15 {
        scalar nw_var_cumulative = nw_var_cumulative + V[lag_`j',lag_`k']
    }
}
scalar nw_se_cumulative = sqrt(nw_var_cumulative * N/(N-16))

* Newey-West covariance with Bartlett weights and maximum lag 15.
predict double residual, resid
generate double one = 1
matrix X = e(b)
matrix accum XX = lag_1-lag_15, nocons
matrix XX_inv = syminv(XX)
matrix S = J(15,15,0)

forvalues t = 1/`=_N' {
    if !missing(residual[`t']) {
        forvalues j = 1/15 {
            forvalues k = 1/15 {
                scalar score_j = lag_`j'[`t'] * residual[`t']
                scalar score_k = lag_`k'[`t'] * residual[`t']
                matrix S[`j',`k'] = S[`j',`k'] + score_j*score_k
            }
        }
    }
}
forvalues h = 1/15 {
    scalar weight = 1 - `h'/16
    forvalues t = 1/`=_N' {
        if !missing(residual[`t'], residual[`t'+`h']) {
            forvalues j = 1/15 {
                forvalues k = 1/15 {
                    scalar score_now = lag_`j'[`t'] * residual[`t']
                    scalar score_lag = lag_`k'[`t'+`h'] * residual[`t'+`h']
                    matrix S[`j',`k'] = S[`j',`k'] + weight*score_now*score_lag
                    matrix S[`k',`j'] = S[`k',`j'] + weight*score_now*score_lag
                }
            }
        }
    }
}
matrix V_NW = XX_inv * S * XX_inv
scalar nw_se_lag1 = sqrt(V_NW[1,1] * N/(N-16))
scalar nw_se_lag15 = sqrt(V_NW[15,15] * N/(N-16))

display "ANSWER: cumulative_response estimate=" %21.12f cumulative_response " se=" %21.12f nw_se_cumulative " n_obs=" %12.0f N
display "ANSWER: lag_1 estimate=" %21.12f _b[lag_1] " se=" %21.12f nw_se_lag1 " n_obs=" %12.0f N
display "ANSWER: lag_15 estimate=" %21.12f _b[lag_15] " se=" %21.12f nw_se_lag15 " n_obs=" %12.0f N
