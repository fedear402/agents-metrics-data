clear all
set more off

import delimited using "crosswalk.csv", clear
tempfile crosswalk
save `crosswalk'

import delimited using "trade.csv", clear
merge m:1 code using `crosswalk', assert(match) nogen

tempfile trade
save `trade'

import delimited using "areas.csv", clear
keep if vintage == "base"
tempfile base
save `base'

import delimited using "areas.csv", clear
keep if vintage == "early"
rename total_employment early_total_employment
tempfile early
save `early'

import delimited using "employment.csv", clear
tempfile all_employment
save `all_employment'

use `base', clear
merge 1:1 area period using `early', assert(match) nogen
keep area period total_employment early_total_employment population
tempfile area_period
save `area_period'

* Add explicit zero employment rows for every area-period-industry-vintage cell.
use `area_period', clear
expand 8
bysort area period: gen byte cell = _n
gen str6 vintage = cond(cell <= 4, "base", "early")
gen int industry = mod(cell - 1, 4) + 1
drop cell
merge 1:1 area period vintage industry using `all_employment', keep(master match) nogen
replace employment = 0 if missing(employment)
tempfile complete_employment
save `complete_employment'

* Calculate national industry employment within each period and vintage.
use `complete_employment', clear
collapse (sum) national_employment=employment, by(period vintage industry)
tempfile national
save `national'

* Combine area employment, national denominators, and trade shocks.
use `complete_employment', clear
merge m:1 period vintage industry using `national', assert(match) nogen
merge m:1 period industry using `trade', assert(match) nogen

gen double base_share = .
replace base_share = employment / total_employment if vintage == "base"
gen double early_share = .
replace early_share = employment / early_total_employment if vintage == "early"

gen double x_component = base_share * (us_change / national_employment) ///
    / (price_index / 100) / 1000 * (10 / years) if vintage == "base"
gen double z_component = early_share * (other_change / national_employment) ///
    / (price_index / 100) / 1000 * (10 / years) if vintage == "early"

preserve
    keep if vintage == "base"
    collapse (sum) x=x_component, by(area period)
    tempfile x_values
    save `x_values'
restore

keep if vintage == "early"
collapse (sum) z=z_component, by(area period)
tempfile z_values
save `z_values'

use `area_period', clear
merge 1:1 area period using `x_values', assert(match) nogen
merge 1:1 area period using `z_values', assert(match) nogen
merge 1:1 area period using "outcomes.csv", assert(match) nogen

gen byte period_indicator = period == 1
gen double weight = population
count
local n_obs = r(N)

ivregress 2sls change_pp period_indicator control (x = z) [aw=weight], vce(unadjusted)
scalar iv_slope = _b[x]

quietly summarize x if area == 0 & period == 0, meanonly
scalar exposure_area0_period0 = r(mean)

quietly summarize x if area == 0 & period == 1, meanonly
scalar exposure_area0_period1 = r(mean)

quietly summarize z if area == 0 & period == 0, meanonly
scalar instrument_area0_period0 = r(mean)

display "ANSWER: iv_slope estimate=" %24.16g scalar(iv_slope) " se=NA n_obs=" %9.0f `n_obs'
display "ANSWER: exposure_area0_period0 estimate=" %24.16g scalar(exposure_area0_period0) " se=NA n_obs=" %9.0f `n_obs'
display "ANSWER: exposure_area0_period1 estimate=" %24.16g scalar(exposure_area0_period1) " se=NA n_obs=" %9.0f `n_obs'
display "ANSWER: instrument_area0_period0 estimate=" %24.16g scalar(instrument_area0_period0) " se=NA n_obs=" %9.0f `n_obs'
