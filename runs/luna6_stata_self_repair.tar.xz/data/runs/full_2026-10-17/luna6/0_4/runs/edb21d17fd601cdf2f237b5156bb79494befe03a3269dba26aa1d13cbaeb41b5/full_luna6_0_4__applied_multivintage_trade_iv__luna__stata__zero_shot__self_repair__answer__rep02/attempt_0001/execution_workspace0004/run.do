clear all
set more off

* Read and validate the trade crosswalk.
import delimited using "crosswalk.csv", clear
isid code
tempfile crosswalk
save `crosswalk'

* Join trade rows to industries by code.
import delimited using "trade.csv", clear
merge m:1 code using `crosswalk', assert(match) nogen
isid period industry
tempfile trade
save `trade'

* Save area totals and population for both employment vintages.
import delimited using "areas.csv", clear
keep if vintage == "base"
rename total_employment base_total_employment
keep area period base_total_employment population
isid area period
tempfile base_areas
save `base_areas'

import delimited using "areas.csv", clear
keep if vintage == "early"
rename total_employment early_total_employment
keep area period early_total_employment
isid area period
tempfile early_areas
save `early_areas'

use `base_areas', clear
merge 1:1 area period using `early_areas', assert(match) nogen
tempfile area_period
save `area_period'

* Save supplied employment cells.
import delimited using "employment.csv", clear
keep area period vintage industry employment
isid area period vintage industry
tempfile employment
save `employment'

* Create every area-period-vintage-industry cell, then fill omitted cells with zero.
use `area_period', clear
expand 2
bysort area period: gen str6 vintage = cond(_n == 1, "base", "early")
tempfile area_vintages
save `area_vintages'

use `crosswalk', clear
keep industry
duplicates drop
isid industry
tempfile industries
save `industries'

use `area_vintages', clear
cross using `industries'
merge 1:1 area period vintage industry using `employment', ///
    keep(master match) nogen
replace employment = 0 if missing(employment)
tempfile complete_employment
save `complete_employment'

* Calculate national employment by period, vintage, and industry.
use `complete_employment', clear
collapse (sum) national_employment=employment, by(period vintage industry)
isid period vintage industry
tempfile national_employment
save `national_employment'

* Calculate base-vintage exposure x.
use `complete_employment', clear
keep if vintage == "base"
merge m:1 period vintage industry using `national_employment', ///
    assert(match) nogen
merge m:1 period industry using `trade', assert(match) nogen
merge m:1 area period using `area_period', ///
    keepusing(base_total_employment) assert(match) nogen
gen double x_component = ///
    (employment / base_total_employment) * ///
    (us_change / national_employment) / ///
    (price_index / 100) / 1000 * (10 / years)
collapse (sum) x=x_component, by(area period)
tempfile x_values
save `x_values'

* Calculate early-vintage instrument z.
use `complete_employment', clear
keep if vintage == "early"
merge m:1 period vintage industry using `national_employment', ///
    assert(match) nogen
merge m:1 period industry using `trade', assert(match) nogen
merge m:1 area period using `area_period', ///
    keepusing(early_total_employment) assert(match) nogen
gen double z_component = ///
    (employment / early_total_employment) * ///
    (other_change / national_employment) / ///
    (price_index / 100) / 1000 * (10 / years)
collapse (sum) z=z_component, by(area period)
tempfile z_values
save `z_values'

* Assemble the estimation data.
import delimited using "outcomes.csv", clear
isid area period
tempfile outcomes
save `outcomes'

use `area_period', clear
merge 1:1 area period using `x_values', assert(match) nogen
merge 1:1 area period using `z_values', assert(match) nogen
merge 1:1 area period using `outcomes', assert(match) nogen

gen byte period_indicator = (period == 1)
count
local n_obs = r(N)
assert `n_obs' == 72

* Instrument x with z and include all exogenous regressors as instruments.
ivregress 2sls change_pp period_indicator control ///
    (x = z) [aw=population], vce(unadjusted)

scalar iv_slope = _b[x]

quietly summarize x if area == 0 & period == 0, meanonly
scalar exposure_area0_period0 = r(mean)

quietly summarize x if area == 0 & period == 1, meanonly
scalar exposure_area0_period1 = r(mean)

quietly summarize z if area == 0 & period == 0, meanonly
scalar instrument_area0_period0 = r(mean)

display "ANSWER: iv_slope estimate=" %24.16g scalar(iv_slope) " se=NA n_obs=" %9.0f `n_obs'
display "ANSWER: exposure_area0_period0 estimate=" %24.16g scalar(exposure_area0_period0) " se=NA n_obs=" %9.0f `n_obs'
display "ANSWER: exposure_area0_period1 estimate=" %24.16g scalar(exposure_area0_period1) " se=NA n_obs=" %9.0f `n_obs'
display "ANSWER: instrument_area0_period0 estimate=" %24.16g scalar(instrument_area0_period0) " se=NA n_obs=" %9.0f `n_obs'
