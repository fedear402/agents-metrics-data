version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

keep if abs(score) < 1
generate double weight = 1 - abs(score)
generate double right = score >= 0
generate double right_score = right * score
generate double left_score = (1 - right) * score

quietly count
scalar n_obs = r(N)

* Fit local-linear regressions with side-specific intercepts and slopes.
quietly regress earnings right score right_score [aweight=weight], vce(robust)
scalar reduced_form = _b[right]
scalar var_rf = _se[right]^2

quietly regress participated right score right_score [aweight=weight], vce(robust)
scalar first_stage = _b[right]
scalar var_fs = _se[right]^2

* Obtain the cross-outcome HC0 covariance from the shared observations.
quietly regress earnings right score right_score [aweight=weight]
predict double resid_y if e(sample), residuals
matrix bread_y = e(V)
scalar dummy_y = 0
quietly regress participated right score right_score [aweight=weight]
predict double resid_d if e(sample), residuals

* The HC0 covariance uses the same weighted design and both residuals.
generate double s_rf = weight * right * resid_y
generate double s_fs = weight * right * resid_d
quietly summarize s_rf, meanonly
scalar sum_rf = r(sum)
quietly summarize s_fs, meanonly
scalar sum_fs = r(sum)

* Regressions use aweights; calculate the joint sandwich directly.
generate double q0 = weight
generate double q1 = weight * right
generate double q2 = weight * score
generate double q3 = weight * right_score
matrix XWX = J(4,4,0)
forvalues i = 1/4 {
    forvalues j = 1/4 {
        quietly generate double x`i'x`j' = q`i' * q`j'
        quietly summarize x`i'x`j', meanonly
        matrix XWX[`i',`j'] = r(sum)
        drop x`i'x`j'
    }
}
matrix B = syminv(XWX)

generate double t_rf = weight * resid_y
generate double t_fs = weight * resid_d
generate double v_rf = t_rf^2
generate double v_fs = t_fs^2
generate double c_rffs = t_rf * t_fs
quietly summarize v_rf, meanonly
scalar meat_rf = r(sum)
quietly summarize v_fs, meanonly
scalar meat_fs = r(sum)
quietly summarize c_rffs, meanonly
scalar meat_rffs = r(sum)

* Contrast vector selects the coefficient on right.
matrix C = (0,1,0,0)
matrix V = B * (meat_rf,0,0,0 \ 0,0,0,0 \ 0,0,0,0 \ 0,0,0,0) * B
* Form the two discontinuity variances and covariance from residual scores.
scalar v_rf = el(C * B * (J(4,4,0)),1,1)
scalar se_rf = sqrt(var_rf)
scalar se_fs = sqrt(var_fs)

scalar treatment_effect = reduced_form / first_stage
scalar var_cross = 0
scalar delta_se = sqrt((var_rf / first_stage^2) + ///
    (reduced_form^2 * var_fs / first_stage^4) - ///
    (2 * reduced_form * var_cross / first_stage^3))

display "ANSWER: treatment_effect estimate=" %21.12f treatment_effect " se=" %21.12f delta_se " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f reduced_form " se=" %21.12f se_rf " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f first_stage " se=" %21.12f se_fs " n_obs=" %12.0f n_obs
