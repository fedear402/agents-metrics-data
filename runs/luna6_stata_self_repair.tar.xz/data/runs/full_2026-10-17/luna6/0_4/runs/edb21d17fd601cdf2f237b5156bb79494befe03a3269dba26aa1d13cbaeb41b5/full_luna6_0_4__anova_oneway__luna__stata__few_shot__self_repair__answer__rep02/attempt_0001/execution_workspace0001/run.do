clear all
set more off
set linesize 255

import delimited "./input.csv", clear

oneway y group
scalar F_stat = e(F)
scalar df_num = e(df_m)
scalar df_den = e(df_r)
scalar p_value = Ftail(df_num, df_den, F_stat)
scalar n_obs = e(N)

display "ANSWER: F estimate=" %21.12f scalar(F_stat) " se=." " n_obs=" %12.0f scalar(n_obs)
display "ANSWER: df_num estimate=" %21.12f scalar(df_num) " se=." " n_obs=" %12.0f scalar(n_obs)
display "ANSWER: df_den estimate=" %21.12f scalar(df_den) " se=." " n_obs=" %12.0f scalar(n_obs)
display "ANSWER: p_value estimate=" %21.12f scalar(p_value) " se=." " n_obs=" %12.0f scalar(n_obs)
