clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

gen double date_num = daily(date, "YMD")
format date_num %td
sort date_num

gen double ln_vix = ln(vix)
gen double d_ln_vix = D.ln_vix
forvalues j = 1/15 {
    gen double lag_`j' = L`j'.d_ln_vix
}

gen double ln_sales = ln(sales)
regress ln_sales lag_1-lag_15 if !missing(lag_1, lag_2, lag_3, lag_4, lag_5, lag_6, lag_7, lag_8, lag_9, lag_10, lag_11, lag_12, lag_13, lag_14, lag_15)

scalar N = e(N)
matrix b = e(b)
matrix V = e(V)

* Bartlett Newey-West covariance with maximum lag 15.
matrix S = J(16, 16, 0)
predict double uhat if e(sample), resid
gen double t_index = _n
forvalues j = 0/15 {
    scalar w = 1 - `j'/16
    forvalues i = 1/16 {
        forvalues k = 1/16 {
            if `j' == 0 {
                quietly summarize uhat, meanonly
                matrix S[`i', `k'] = r(sum_of_sq)
            }
            else {
                quietly summarize uhat if t_index > `j', meanonly
                scalar cross = 0
                forvalues t = `=`j'+1'/`=_N' {
                    scalar cross = cross + uhat[`t'] * uhat[`=`t'-`j'']
                }
                matrix S[`i', `k'] = S[`i', `k'] + w * cross
            }
        }
    }
}

* Use Stata's Newey-West estimator for the requested HAC covariance.
newey ln_sales lag_1-lag_15 if !missing(lag_1, lag_2, lag_3, lag_4, lag_5, lag_6, lag_7, lag_8, lag_9, lag_10, lag_11, lag_12, lag_13, lag_14, lag_15), lag(15)
matrix b = e(b)
matrix V = e(V)
scalar correction = e(N)/(e(N)-16)
matrix V = correction * V

scalar cumulative_response = 0
scalar cumulative_variance = 0
forvalues j = 1/15 {
    scalar cumulative_response = cumulative_response + b[1, "`: word `j' of lag_1 lag_2 lag_3 lag_4 lag_5 lag_6 lag_7 lag_8 lag_9 lag_10 lag_11 lag_12 lag_13 lag_14 lag_15'"]
}
forvalues i = 1/15 {
    forvalues j = 1/15 {
        local name_i : word `i' of lag_1 lag_2 lag_3 lag_4 lag_5 lag_6 lag_7 lag_8 lag_9 lag_10 lag_11 lag_12 lag_13 lag_14 lag_15
        local name_j : word `j' of lag_1 lag_2 lag_3 lag_4 lag_5 lag_6 lag_7 lag_8 lag_9 lag_10 lag_11 lag_12 lag_13 lag_14 lag_15
        scalar cumulative_variance = cumulative_variance + V[1, "`name_i'"] * 0 + V["`name_i'", "`name_j'"]
    }
}
scalar cumulative_se = sqrt(cumulative_variance)
scalar lag1_estimate = b[1, "lag_1"]
scalar lag1_se = sqrt(V["lag_1", "lag_1"])
scalar lag15_estimate = b[1, "lag_15"]
scalar lag15_se = sqrt(V["lag_15", "lag_15"])
scalar n_obs = e(N)

display "ANSWER: cumulative_response estimate=" %21.12f cumulative_response " se=" %21.12f cumulative_se " n_obs=" %12.0f n_obs
display "ANSWER: lag_1 estimate=" %21.12f lag1_estimate " se=" %21.12f lag1_se " n_obs=" %12.0f n_obs
display "ANSWER: lag_15 estimate=" %21.12f lag15_estimate " se=" %21.12f lag15_se " n_obs=" %12.0f n_obs
