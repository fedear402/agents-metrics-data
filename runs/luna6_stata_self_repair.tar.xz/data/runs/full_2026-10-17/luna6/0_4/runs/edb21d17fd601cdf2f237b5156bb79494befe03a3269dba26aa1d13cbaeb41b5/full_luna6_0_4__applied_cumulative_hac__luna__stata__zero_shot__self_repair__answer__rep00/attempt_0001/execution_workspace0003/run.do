clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

sort date

generate double ln_sales = ln(sales)
generate double ln_vix = ln(vix)
generate double d_ln_vix = ln_vix - ln_vix[_n-1]

forvalues j = 1/15 {
    generate double lag_`j' = d_ln_vix[_n-`j']
}

quietly regress ln_sales lag_1-lag_15 if !missing(ln_sales, lag_1-lag_15)

local N = e(N)
matrix b = e(b)

* Recover (X'X)^(-1) from the conventional OLS covariance.
matrix XXinv = e(V) / e(rmse)^2
matrix meat = J(16, 16, 0)

tempvar sample residual
generate byte `sample' = e(sample)
predict double `residual' if `sample', resid

* Build the score matrix for the estimation sample.
matrix G = J(`N', 16, 0)
forvalues t = 1/`N' {
    local row = `t' + 15
    matrix G[`t',1] = `residual'[`row']
    forvalues k = 1/15 {
        matrix G[`t',`k'+1] = `residual'[`row'] * lag_`k'[`row']
    }
}

* Newey-West meat with Bartlett weights through lag 15.
matrix meat = G' * G
forvalues j = 1/15 {
    local weight = 1 - `j'/16
    forvalues t = 1/`=`N'-`j'' {
        matrix gt = G[`t',1...16]'
        matrix gj = G[`=`t'+`j'',1...16]'
        matrix meat = meat + `weight' * (gt * gj' + gj * gt')
    }
}

matrix Vnw = XXinv * meat * XXinv
matrix Vnw = (`N' / (`N' - 16)) * Vnw

scalar cumulative_response = 0
forvalues j = 1/15 {
    scalar cumulative_response = cumulative_response + b[1,`j']
}

scalar variance_cumulative = 0
forvalues i = 1/15 {
    forvalues j = 1/15 {
        scalar variance_cumulative = variance_cumulative + Vnw[`i',`j']
    }
}

scalar se_cumulative = sqrt(variance_cumulative)
scalar se_lag1 = sqrt(Vnw[2,2])
scalar se_lag15 = sqrt(Vnw[16,16])

display "ANSWER: cumulative_response estimate=" %21.12f cumulative_response " se=" %21.12f se_cumulative " n_obs=" %12.0f `N'
display "ANSWER: lag_1 estimate=" %21.12f b[1,1] " se=" %21.12f se_lag1 " n_obs=" %12.0f `N'
display "ANSWER: lag_15 estimate=" %21.12f b[1,15] " se=" %21.12f se_lag15 " n_obs=" %12.0f `N'
