clear all
set more off

* Import and save all supplied files.
import delimited using "crosswalk.csv", clear
isid code
tempfile crosswalk
save `crosswalk'

import delimited using "trade.csv", clear
merge m:1 code using `crosswalk', assert(match) nogen
isid period code
tempfile trade
save `trade'

import delimited using "areas.csv", clear
tempfile areas
save `areas'

import delimited using "employment.csv", clear
isid area period vintage industry
tempfile employment
save `employment'

import delimited using "outcomes.csv", clear
isid area period
tempfile outcomes
save `outcomes'

* Calculate national employment by period, vintage, and industry.
use `employment', clear
collapse (sum) national_employment=employment, by(period vintage industry)
tempfile national
save `national'

* Store area-period totals and population for both vintages.
use `areas', clear
keep if vintage == "base"
keep area period total_employment population
isid area period
tempfile base_areas
save `base_areas'

use `areas', clear
keep if vintage == "early"
keep area period total_employment
rename total_employment early_total_employment
isid area period
tempfile early_areas
save `early_areas'

* Build every area-period-industry-vintage cell.
use `base_areas', clear
keep area period
cross using `crosswalk'
keep area period industry
expand 2
bysort area period industry: gen str5 vintage = cond(_n == 1, "base", "early")
isid area period industry vintage
merge 1:1 area period industry vintage using `employment', keep(master match) nogen
replace employment = 0 if missing(employment)

* Add denominators and trade data, then calculate x and z components.
merge m:1 period vintage industry using `national', assert(match) nogen
merge m:1 industry using `crosswalk', assert(match) nogen
merge m:1 period code using `trade', assert(match) nogen
merge m:1 area period using `base_areas', keepusing(total_employment population) nogen
merge m:1 area period using `early_areas', assert(match) nogen

gen double x_component = 0
gen double z_component = 0
replace x_component = (employment / total_employment) * ///
    (us_change / national_employment) / (price_index / 100) / 1000 * (10 / years) ///
    if vintage == "base"
replace z_component = (employment / early_total_employment) * ///
    (other_change / national_employment) / (price_index / 100) / 1000 * (10 / years) ///
    if vintage == "early"

collapse (sum) x=x_component z=z_component, by(area period)
merge 1:1 area period using `outcomes', assert(match) nogen
merge 1:1 area period using `base_areas', keepusing(population) assert(match) nogen

* Estimate weighted 2SLS with period and control as included instruments.
gen byte period_indicator = (period == 1)
ivregress 2sls change_pp period_indicator control (x = z) [pweight=population]
scalar iv_slope = _b[x]
local n_obs = e(N)

quietly summarize x if area == 0 & period == 0, meanonly
scalar exposure_area0_period0 = r(mean)
quietly summarize x if area == 0 & period == 1, meanonly
scalar exposure_area0_period1 = r(mean)
quietly summarize z if area == 0 & period == 0, meanonly
scalar instrument_area0_period0 = r(mean)

display as text "ANSWER: iv_slope estimate=" %21.15g scalar(iv_slope) " se=NA n_obs=" %3.0f `n_obs'
display as text "ANSWER: exposure_area0_period0 estimate=" %21.15g scalar(exposure_area0_period0) " se=NA n_obs=" %3.0f `n_obs'
display as text "ANSWER: exposure_area0_period1 estimate=" %21.15g scalar(exposure_area0_period1) " se=NA n_obs=" %3.0f `n_obs'
display as text "ANSWER: instrument_area0_period0 estimate=" %21.15g scalar(instrument_area0_period0) " se=NA n_obs=" %3.0f `n_obs'
