clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

keep if abs(score) < 1
generate double rd_right = score >= 0
generate double rd_x = score * rd_right
generate double rd_weight = 1 - abs(score)
generate double rd_y_earnings = earnings
generate double rd_y_participated = participated

local n_obs = _N

* Estimate both outcomes jointly so the covariance between discontinuities
* is available for the delta-method standard error.
regress rd_y_earnings rd_right score rd_x [aweight=rd_weight], vce(robust)
scalar rf = _b[rd_right]
scalar rf_var = _se[rd_right]^2

regress rd_y_participated rd_right score rd_x [aweight=rd_weight], vce(robust)
scalar fs = _b[rd_right]
scalar fs_var = _se[rd_right]^2

* HC0 cross-equation covariance, using the same observations and weights.
* Regressions above use analytic weights, so recover the weighted least-squares
* score contributions and form the sandwich covariance without a df correction.
tempvar e_rf e_fs
quietly regress rd_y_earnings rd_right score rd_x [aweight=rd_weight]
predict double `e_rf', residuals
matrix X = e(b)
quietly regress rd_y_participated rd_right score rd_x [aweight=rd_weight]
predict double `e_fs', residuals

mata:
    X = st_data(., ("rd_right", "score", "rd_x"))
    w = st_data(., "rd_weight")
    e1 = st_data(., "`e_rf'")
    e2 = st_data(., "`e_fs'")
    X = (J(rows(X),1,1), X)
    bread = invsym(X' * diag(w) * X)
    meat12 = X' * diag(w:^2 :* e1 :* e2) * X
    V12 = bread * meat12 * bread
    st_numscalar("rf_fs_cov", V12[2,2])
end

scalar te = rf / fs
scalar te_var = rf_var/(fs^2) + (rf^2)*fs_var/(fs^4) - 2*rf*rf_fs_cov/(fs^3)
scalar te_se = sqrt(max(0, te_var))

display "ANSWER: treatment_effect estimate=" %21.12f te " se=" %21.12f te_se " n_obs=" %12.0f `n_obs'
display "ANSWER: reduced_form estimate=" %21.12f rf " se=" %21.12f sqrt(rf_var) " n_obs=" %12.0f `n_obs'
display "ANSWER: first_stage estimate=" %21.12f fs " se=" %21.12f sqrt(fs_var) " n_obs=" %12.0f `n_obs'
