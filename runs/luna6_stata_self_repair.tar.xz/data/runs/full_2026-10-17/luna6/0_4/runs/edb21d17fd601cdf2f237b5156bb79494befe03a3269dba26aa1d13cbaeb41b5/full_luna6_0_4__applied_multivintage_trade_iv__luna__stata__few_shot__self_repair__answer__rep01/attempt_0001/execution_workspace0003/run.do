clear all
set more off
set type double

import delimited using "crosswalk.csv", clear
isid code
tempfile crosswalk trade baseareas earlyareas employment_wide
save `crosswalk'

import delimited using "trade.csv", clear
merge m:1 code using `crosswalk', assert(match) nogen
isid period industry
save `trade'

import delimited using "areas.csv", clear
keep if vintage == "base"
rename total_employment base_total
rename population base_population
isid area period
tempfile baseareas
save `baseareas'

import delimited using "areas.csv", clear
keep if vintage == "early"
rename total_employment early_total
keep area period early_total
isid area period
tempfile earlyareas
save `earlyareas'

import delimited using "employment.csv", clear
collapse (sum) employment, by(area period vintage industry)
reshape wide employment, i(area period industry) j(vintage) string
foreach v in base early {
    capture confirm variable employment`v'
    if _rc {
        gen double employment`v' = 0
    }
    replace employment`v' = 0 if missing(employment`v')
}
save `employment_wide'

use `baseareas', clear
merge 1:1 area period using `earlyareas', assert(match) nogen

* Expand each area-period across the four crosswalk industries.
joinby using `crosswalk'
isid area period industry

merge 1:1 area period industry using `employment_wide', keep(master match) nogen
foreach v in base early {
    replace employment`v' = 0 if missing(employment`v')
}

bysort period industry: egen double national_base = total(employmentbase)
bysort period industry: egen double national_early = total(employmentearly)

merge m:1 period industry using `trade', assert(match) nogen

gen double xpart = (employmentbase / base_total) * ///
    (us_change / national_base) / (price_index / 100) / 1000 * (10 / years)
gen double zpart = (employmentearly / early_total) * ///
    (other_change / national_early) / (price_index / 100) / 1000 * (10 / years)

collapse (sum) x=xpart z=zpart, by(area period)
isid area period

merge 1:1 area period using `baseareas', keepusing(base_population) assert(match) nogen
import delimited using "outcomes.csv", clear
merge 1:1 area period using `baseareas', keepusing(base_population) assert(match) nogen

* Rebuild exposures after loading outcomes.
tempfile outcomes exposures
save `outcomes'

use `baseareas', clear
merge 1:1 area period using `earlyareas', assert(match) nogen
joinby using `crosswalk'
merge 1:1 area period industry using `employment_wide', keep(master match) nogen
foreach v in base early {
    replace employment`v' = 0 if missing(employment`v')
}
bysort period industry: egen double national_base = total(employmentbase)
bysort period industry: egen double national_early = total(employmentearly)
merge m:1 period industry using `trade', assert(match) nogen
gen double xpart = (employmentbase / base_total) * ///
    (us_change / national_base) / (price_index / 100) / 1000 * (10 / years)
gen double zpart = (employmentearly / early_total) * ///
    (other_change / national_early) / (price_index / 100) / 1000 * (10 / years)
collapse (sum) x=xpart z=zpart, by(area period)
save `exposures'

use `outcomes', clear
merge 1:1 area period using `exposures', assert(match) nogen
encode period, gen(period_id)
quietly count
local n_obs = r(N)
assert `n_obs' == 72

ivregress 2sls change_pp i.period_id control (x = z) [aw=base_population]
display "ANSWER: iv_slope estimate=" %24.16g _b[x] " se=NA n_obs=" %12.0f `n_obs'

quietly summarize x if area == 0 & period_id == 1, meanonly
display "ANSWER: exposure_area0_period0 estimate=" %24.16g r(mean) " se=NA n_obs=" %12.0f `n_obs'

quietly summarize x if area == 0 & period_id == 2, meanonly
display "ANSWER: exposure_area0_period1 estimate=" %24.16g r(mean) " se=NA n_obs=" %12.0f `n_obs'

quietly summarize z if area == 0 & period_id == 1, meanonly
display "ANSWER: instrument_area0_period0 estimate=" %24.16g r(mean) " se=NA n_obs=" %12.0f `n_obs'
