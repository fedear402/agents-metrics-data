clear all
set more off

import delimited using "crosswalk.csv", clear
tempfile crosswalk
save `crosswalk'

import delimited using "trade.csv", clear
merge m:1 code using `crosswalk', assert(match) nogen
tempfile trade
save `trade'

import delimited using "areas.csv", clear
tempfile areas
save `areas'

import delimited using "employment.csv", clear
tempfile employment
save `employment'

import delimited using "outcomes.csv", clear
tempfile outcomes
save `outcomes'

* Compute national industry employment within period and vintage.
use `employment', clear
collapse (sum) national_employment=employment, by(period vintage industry)
tempfile national
save `national'

* Attach area-level employment and totals to the area-period records.
use `areas', clear
keep if vintage == "base"
keep area period total_employment population
isid area period
tempfile base_areas
save `base_areas'

use `areas', clear
keep if vintage == "early"
keep area period total_employment
rename total_employment early_total_employment
isid area period
tempfile early_areas
save `early_areas'

use `base_areas', clear
merge 1:1 area period using `early_areas', assert(match) nogen

* Build a complete four-industry grid so omitted employment cells equal zero.
cross using `crosswalk'
rename industry industry
tempfile grid
save `grid'

use `grid', clear
merge 1:1 area period industry using `employment', keepusing(vintage employment) nogen
replace employment = 0 if missing(employment)
tempfile grid_employment
save `grid_employment'

* Reshape employment vintages, then attach national denominators.
use `grid_employment', clear
reshape wide employment, i(area period industry code) j(vintage) string
rename employmentbase base_employment
rename employmentearly early_employment
replace base_employment = 0 if missing(base_employment)
replace early_employment = 0 if missing(early_employment)
merge m:1 period industry using `national', keepusing(national_employment) nogen
rename national_employment national_base_employment
tempfile area_industry
save `area_industry'

* Merge trade changes by period and industry, then calculate exposures.
merge m:1 period code using `trade', assert(match) nogen
merge m:1 area period using `base_areas', keepusing(total_employment population) nogen
merge m:1 area period using `early_areas', keepusing(early_total_employment) nogen

gen double x_component = (base_employment / total_employment) * ///
    (us_change / national_base_employment) / (price_index / 100) / 1000 * (10 / years)
gen double z_component = (early_employment / early_total_employment) * ///
    (other_change / national_employment) / (price_index / 100) / 1000 * (10 / years)

collapse (sum) x=x_component z=z_component, by(area period)
merge 1:1 area period using `outcomes', assert(match) nogen
merge 1:1 area period using `base_areas', keepusing(population) assert(match) nogen

* Weighted 2SLS with all exogenous regressors included as instruments.
gen byte period_indicator = period == 1
ivregress 2sls change_pp period_indicator control (x = z) [pweight=population]
scalar iv_slope = _b[x]

quietly summarize x if area == 0 & period == 0, meanonly
scalar exposure_area0_period0 = r(mean)
quietly summarize x if area == 0 & period == 1, meanonly
scalar exposure_area0_period1 = r(mean)
quietly summarize z if area == 0 & period == 0, meanonly
scalar instrument_area0_period0 = r(mean)

count
local n_obs = r(N)
display as text "ANSWER: iv_slope estimate=" %21.15g scalar(iv_slope) " se=NA n_obs=" %3.0f `n_obs'
display as text "ANSWER: exposure_area0_period0 estimate=" %21.15g scalar(exposure_area0_period0) " se=NA n_obs=" %3.0f `n_obs'
display as text "ANSWER: exposure_area0_period1 estimate=" %21.15g scalar(exposure_area0_period1) " se=NA n_obs=" %3.0f `n_obs'
display as text "ANSWER: instrument_area0_period0 estimate=" %21.15g scalar(instrument_area0_period0) " se=NA n_obs=" %3.0f `n_obs'
