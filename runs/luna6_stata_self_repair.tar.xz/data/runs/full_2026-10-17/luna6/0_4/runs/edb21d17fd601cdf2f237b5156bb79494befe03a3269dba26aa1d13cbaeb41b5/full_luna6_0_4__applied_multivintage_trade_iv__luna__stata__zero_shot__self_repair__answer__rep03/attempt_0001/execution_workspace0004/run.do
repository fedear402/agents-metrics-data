version 16.0
clear all
set more off

* Read the crosswalk and attach an industry to every trade row.
import delimited using "crosswalk.csv", clear
isid code
tempfile crosswalk
save `crosswalk'

import delimited using "trade.csv", clear
merge m:1 code using `crosswalk', assert(match) nogen
isid period industry
tempfile trade
save `trade'

* Read all supplied area, employment, and outcome rows.
import delimited using "areas.csv", clear
isid area period vintage
tempfile areas
save `areas'

import delimited using "employment.csv", clear
isid area period vintage industry
tempfile employment
save `employment'

import delimited using "outcomes.csv", clear
isid area period
tempfile outcomes
save `outcomes'

* Make four industry cells for every supplied area-period-vintage.
use `areas', clear
keep area period vintage total_employment population
expand 4
bysort area period vintage: gen industry = _n
merge 1:1 area period vintage industry using `employment', ///
    keep(master match) nogen
replace employment = 0 if missing(employment)

* Sum employment across all supplied areas for each period, vintage, and industry.
bysort period vintage industry: egen double national_employment = total(employment)
tempfile cells
save `cells'

* Keep base-vintage employment, totals, and population.
use `cells', clear
keep if vintage == "base"
rename employment base_employment
rename total_employment base_total_employment
keep area period industry base_employment base_total_employment population
tempfile basecells
save `basecells'

* Keep early-vintage employment.
use `cells', clear
keep if vintage == "early"
rename employment early_employment
keep area period industry early_employment
tempfile earlycells
save `earlycells'

* Keep national employment denominators for both vintages.
use `cells', clear
keep period vintage industry national_employment
duplicates drop
reshape wide national_employment, i(period industry) j(vintage) string
rename national_employmentbase national_base_employment
rename national_employmentearly national_early_employment
tempfile national
save `national'

* Keep trade changes and period-specific deflator inputs.
use `trade', clear
keep period industry us_change other_change price_index years
isid period industry
tempfile tradekey
save `tradekey'

* Combine employment, national denominators, and trade rows.
use `basecells', clear
merge 1:1 area period industry using `earlycells', assert(match) nogen
merge m:1 period industry using `national', assert(match) nogen
merge m:1 period industry using `tradekey', assert(match) nogen

* Construct area-industry exposure and instrument components.
gen double x_component = ///
    (base_employment / base_total_employment) * ///
    (us_change / national_base_employment) / ///
    (price_index / 100) / 1000 * (10 / years)

gen double z_component = ///
    (early_employment / base_total_employment) * ///
    (other_change / national_early_employment) / ///
    (price_index / 100) / 1000 * (10 / years)

collapse (sum) x=x_component z=z_component, by(area period)
merge 1:1 area period using `outcomes', assert(match) nogen

* Encode period as a numeric regressor, preserving its sorted order.
capture confirm numeric variable period
if _rc {
    encode period, gen(period_numeric)
}
else {
    gen double period_numeric = period
}

* Estimate weighted 2SLS with population weights.
quietly count
local n_obs = r(N)
ivregress 2sls change_pp period_numeric control ///
    (x = z) [aweight=population]
scalar iv_slope = _b[x]

quietly summarize x if area == 0 & period_numeric == 1, meanonly
scalar exposure_area0_period0 = r(mean)

quietly summarize x if area == 0 & period_numeric == 2, meanonly
scalar exposure_area0_period1 = r(mean)

quietly summarize z if area == 0 & period_numeric == 1, meanonly
scalar instrument_area0_period0 = r(mean)

display "ANSWER: iv_slope estimate=" %24.16g scalar(iv_slope) " se=NA n_obs=`n_obs'"
display "ANSWER: exposure_area0_period0 estimate=" %24.16g scalar(exposure_area0_period0) " se=NA n_obs=`n_obs'"
display "ANSWER: exposure_area0_period1 estimate=" %24.16g scalar(exposure_area0_period1) " se=NA n_obs=`n_obs'"
display "ANSWER: instrument_area0_period0 estimate=" %24.16g scalar(instrument_area0_period0) " se=NA n_obs=`n_obs'"
