clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

keep if abs(score) < 1
generate double rd_weight = 1 - abs(score)
generate double score_right = score * (score >= 0)
generate double score_left = score * (score < 0)
generate double right = score >= 0

quietly count
scalar n_obs = r(N)

* Fit weighted local-linear regressions with separate side slopes.
quietly regress earnings right score_right score_left [aweight=rd_weight]
scalar reduced_form = _b[right]
predict double rf_resid, resid

quietly regress participated right score_right score_left [aweight=rd_weight]
scalar first_stage = _b[right]
predict double fs_resid, resid

* Compute joint HC0 covariance from the common observations and weights.
mata:
    X = J(st_nobs(), 1, 1), st_data(., "right"), ///
        st_data(., "score_right"), st_data(., "score_left")
    w = st_data(., "rd_weight")
    ur = st_data(., "rf_resid")
    uf = st_data(., "fs_resid")
    bread = invsym(X' * diag(w) * X)
    meat_rf = X' * diag(w:^2 :* ur:^2) * X
    meat_fs = X' * diag(w:^2 :* uf:^2) * X
    meat_cross = X' * diag(w:^2 :* ur :* uf) * X
    Vrf = bread * meat_rf * bread
    Vfs = bread * meat_fs * bread
    Vcross = bread * meat_cross * bread
    st_numscalar("var_rf_hc0", Vrf[2,2])
    st_numscalar("var_fs_hc0", Vfs[2,2])
    st_numscalar("cov_rf_fs", Vcross[2,2])
end

scalar reduced_form_se = sqrt(var_rf_hc0)
scalar first_stage_se = sqrt(var_fs_hc0)
scalar treatment_effect = reduced_form / first_stage
scalar treatment_var = var_rf_hc0 / first_stage^2 + ///
    reduced_form^2 * var_fs_hc0 / first_stage^4 - ///
    2 * reduced_form * cov_rf_fs / first_stage^3
scalar treatment_se = sqrt(treatment_var)

display "ANSWER: treatment_effect estimate=" %21.12f treatment_effect " se=" %21.12f treatment_se " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f reduced_form " se=" %21.12f reduced_form_se " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f first_stage " se=" %21.12f first_stage_se " n_obs=" %12.0f n_obs
