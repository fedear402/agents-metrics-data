clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

encode group, generate(group_id)
oneway y group_id

scalar F_value = r(F)
scalar df_num_value = r(df1)
scalar df_den_value = r(df2)
scalar p_value = r(p)

display "ANSWER: F estimate=" %21.12f F_value " se=" %21.12f . " n_obs=" %12.0f e(N)
display "ANSWER: df_num estimate=" %21.12f df_num_value " se=" %21.12f . " n_obs=" %12.0f e(N)
display "ANSWER: df_den estimate=" %21.12f df_den_value " se=" %21.12f . " n_obs=" %12.0f e(N)
display "ANSWER: p_value estimate=" %21.12f p_value " se=" %21.12f . " n_obs=" %12.0f e(N)
