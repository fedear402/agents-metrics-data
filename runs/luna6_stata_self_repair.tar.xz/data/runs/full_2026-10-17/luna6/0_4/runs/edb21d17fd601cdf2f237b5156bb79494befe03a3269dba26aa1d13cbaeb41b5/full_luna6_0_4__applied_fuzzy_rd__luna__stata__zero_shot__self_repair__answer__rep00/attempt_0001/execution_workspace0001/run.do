clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

keep if abs(score) < 1
generate double weight = 1 - abs(score)
generate double right = score >= 0
generate double slope = score * right
generate double left_slope = score * (1 - right)

quietly count
scalar n_obs = r(N)

quietly regress earnings right slope left_slope [aw=weight], noconstant vce(hc0)
scalar reduced_form = _b[right]
scalar var_rf = _se[right]^2

quietly regress participated right slope left_slope [aw=weight], noconstant vce(hc0)
scalar first_stage = _b[right]
scalar var_fs = _se[right]^2

* Joint HC0 covariance for the two discontinuity estimates.
quietly regress earnings right slope left_slope [aw=weight], noconstant
predict double resid_y, residuals
quietly regress participated right slope left_slope [aw=weight], noconstant
predict double resid_d, residuals

generate double w2 = weight^2
generate double score_y = w2 * resid_y * right
generate double score_d = w2 * resid_d * right
quietly summarize score_y, meanonly
scalar meat_yy = r(sum)
quietly summarize score_d, meanonly
scalar meat_dd = r(sum)
generate double score_yd = score_y * score_d / w2
quietly summarize score_yd, meanonly
scalar meat_yd = r(sum)

* HC0 sandwich element for the right-side intercept in each weighted regression.
matrix XWX = J(3,3,0)
generate double x1 = right
generate double x2 = slope
generate double x3 = left_slope
forvalues i = 1/3 {
    forvalues j = 1/3 {
        quietly summarize weight * x`i' * x`j', meanonly
        matrix XWX[`i',`j'] = r(sum)
    }
}
matrix bread = invsym(XWX)
scalar b11 = bread[1,1]
scalar cov_rf_fs = b11^2 * meat_yd

scalar treatment_effect = reduced_form / first_stage
scalar se_rf = sqrt(var_rf)
scalar se_fs = sqrt(var_fs)
scalar se_te = sqrt(var_rf / first_stage^2 + reduced_form^2 * var_fs / first_stage^4 - 2 * reduced_form * cov_rf_fs / first_stage^3)

display "ANSWER: treatment_effect estimate=" %21.12f treatment_effect " se=" %21.12f se_te " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f reduced_form " se=" %21.12f se_rf " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f first_stage " se=" %21.12f se_fs " n_obs=" %12.0f n_obs
