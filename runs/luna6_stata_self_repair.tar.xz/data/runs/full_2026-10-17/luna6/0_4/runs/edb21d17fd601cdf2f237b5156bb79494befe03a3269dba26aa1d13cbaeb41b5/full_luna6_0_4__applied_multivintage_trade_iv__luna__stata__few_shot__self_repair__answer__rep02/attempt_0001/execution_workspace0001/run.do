clear all
set more off
set type double

import delimited using "crosswalk.csv", clear
tempfile crosswalk
save `crosswalk'

import delimited using "trade.csv", clear
merge m:1 code using `crosswalk', keep(match) nogen
tempfile trade
save `trade'

import delimited using "areas.csv", clear
keep if vintage == "base"
rename total_employment base_total
rename population base_population
tempfile base_areas
save `base_areas'

import delimited using "areas.csv", clear
keep if vintage == "early"
rename total_employment early_total
keep area period early_total
tempfile early_areas
save `early_areas'

use `base_areas', clear
merge 1:1 area period using `early_areas', assert(match) nogen
tempfile area_totals
save `area_totals'

import delimited using "employment.csv", clear
keep if vintage == "base"
rename employment base_employment
keep area period industry base_employment
tempfile base_employment
save `base_employment'

import delimited using "employment.csv", clear
keep if vintage == "early"
rename employment early_employment
keep area period industry early_employment
tempfile early_employment
save `early_employment'

use `base_employment', clear
merge 1:1 area period industry using `early_employment', nogen
replace base_employment = 0 if missing(base_employment)
replace early_employment = 0 if missing(early_employment)
tempfile employment_cells
save `employment_cells'

use `area_totals', clear
joinby area period using `employment_cells'
merge m:1 period using `trade', assert(match) nogen

bysort period industry: egen double national_base = total(base_employment)
bysort period industry: egen double national_early = total(early_employment)

gen double base_component = (base_employment / national_base) * us_change / (price_index / 100) / 1000 * (10 / years)
gen double early_component = (early_employment / national_early) * other_change / (price_index / 100) / 1000 * (10 / years)
bysort area period: egen double x = total(base_component / base_total)
bysort area period: egen double z = total(early_component / early_total)

keep area period x z
duplicates drop area period, force
tempfile exposures
save `exposures'

import delimited using "outcomes.csv", clear
merge 1:1 area period using `exposures', assert(match) nogen
merge 1:1 area period using `base_areas', keepusing(base_population) assert(match) nogen

quietly ivregress 2sls change_pp period control (x = z) [aw=base_population]
local iv_slope = _b[x]

quietly summarize x if area == 0 & period == 0, meanonly
local exposure00 = r(mean)
quietly summarize x if area == 0 & period == 1, meanonly
local exposure01 = r(mean)
quietly summarize z if area == 0 & period == 0, meanonly
local instrument00 = r(mean)

display "ANSWER: iv_slope estimate=" %24.16g `iv_slope' " se=NA n_obs=72"
display "ANSWER: exposure_area0_period0 estimate=" %24.16g `exposure00' " se=NA n_obs=72"
display "ANSWER: exposure_area0_period1 estimate=" %24.16g `exposure01' " se=NA n_obs=72"
display "ANSWER: instrument_area0_period0 estimate=" %24.16g `instrument00' " se=NA n_obs=72"
