clear all
set more off
set type double

tempfile crosswalk trade base_areas early_areas base_emp early_emp xdata zdata outdata

import delimited using "crosswalk.csv", clear varnames(1) case(preserve)
isid code
isid industry
save `crosswalk'

import delimited using "trade.csv", clear varnames(1) case(preserve)
isid period code
merge m:1 code using `crosswalk', assert(match) nogen
isid period industry
save `trade'

import delimited using "areas.csv", clear varnames(1) case(preserve)
keep if vintage == "base"
isid area period
rename total_employment base_total
rename population base_population
keep area period base_total base_population
save `base_areas'

import delimited using "areas.csv", clear varnames(1) case(preserve)
keep if vintage == "early"
isid area period
rename total_employment early_total
keep area period early_total
save `early_areas'

import delimited using "employment.csv", clear varnames(1) case(preserve)
keep if vintage == "base"
isid area period industry
collapse (sum) base_employment=employment, by(area period industry)
save `base_emp'

import delimited using "employment.csv", clear varnames(1) case(preserve)
keep if vintage == "early"
isid area period industry
collapse (sum) early_employment=employment, by(area period industry)
save `early_emp'

* Build the complete area-period-industry grid so omitted employment cells are zero.
use `base_areas', clear
joinby period using `crosswalk'
isid area period industry
merge 1:1 area period industry using `base_emp', keep(master match) nogen
replace base_employment = 0 if missing(base_employment)
merge m:1 period industry using `trade', assert(match) nogen
bysort period industry: egen double national_base_industry = total(base_employment)
gen double x_component = (base_employment / base_total) * ///
    (us_change / national_base_industry) / (price_index / 100) / 1000 * (10 / years)
collapse (sum) x=x_component, by(area period)
save `xdata'

use `early_areas', clear
joinby period using `crosswalk'
isid area period industry
merge 1:1 area period industry using `early_emp', keep(master match) nogen
replace early_employment = 0 if missing(early_employment)
merge m:1 period industry using `trade', assert(match) nogen
bysort period industry: egen double national_early_industry = total(early_employment)
gen double z_component = (early_employment / early_total) * ///
    (other_change / national_early_industry) / (price_index / 100) / 1000 * (10 / years)
collapse (sum) z=z_component, by(area period)
save `zdata'

use `base_areas', clear
merge 1:1 area period using `xdata', assert(match) nogen
merge 1:1 area period using `zdata', assert(match) nogen
import delimited using "outcomes.csv", clear varnames(1) case(preserve)
isid area period
save `outdata'

use `base_areas', clear
merge 1:1 area period using `xdata', assert(match) nogen
merge 1:1 area period using `zdata', assert(match) nogen
merge 1:1 area period using `outdata', assert(match) nogen
count
local n_obs = r(N)
assert `n_obs' == 72

ivregress 2sls change_pp control i.period (x=z) [aw=base_population]
display "ANSWER: iv_slope estimate=" %24.16g _b[x] " se=NA n_obs=" %3.0f `n_obs'

quietly summarize x if area==0 & period==0, meanonly
display "ANSWER: exposure_area0_period0 estimate=" %24.16g r(mean) " se=NA n_obs=" %3.0f `n_obs'

quietly summarize x if area==0 & period==1, meanonly
display "ANSWER: exposure_area0_period1 estimate=" %24.16g r(mean) " se=NA n_obs=" %3.0f `n_obs'

quietly summarize z if area==0 & period==0, meanonly
display "ANSWER: instrument_area0_period0 estimate=" %24.16g r(mean) " se=NA n_obs=" %3.0f `n_obs'
