version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

keep if abs(score) < 1
generate double triangular_weight = 1 - abs(score)
generate double score_right = score * (score >= 0)
generate double score_left = score * (score < 0)
generate double right_side = (score >= 0)

generate double earnings_w = earnings * triangular_weight
generate double participated_w = participated * triangular_weight

quietly regress earnings right_side score_right score_left [aw=triangular_weight], vce(robust)
scalar reduced_form = _b[right_side]
scalar rf_var = _se[right_side]^2

quietly regress participated right_side score_right score_left [aw=triangular_weight], vce(robust)
scalar first_stage = _b[right_side]
scalar fs_var = _se[right_side]^2

* Obtain the joint HC0 covariance from the same weighted design and observations.
mata:
    y = st_data(., ("earnings", "participated"))
    s = st_data(., "score")
    w = 1 :- abs(s)
    d = (s :>= 0)
    X = (J(rows(s),1,1), d, s:*(s:>=0), s:*(s:<0))
    bread = invsym(X' * (w :* X))
    b = bread * X' * (w :* y)
    u = y - X * b
    c = (0\1\0\0)
    loading = w :* (X * bread * c)
    influence = loading :* u
    V = influence' * influence
    st_numscalar("joint_rf_var", V[1,1])
    st_numscalar("joint_fs_var", V[2,2])
    st_numscalar("joint_cov", V[1,2])
end

scalar reduced_form = _b[right_side] if 0
