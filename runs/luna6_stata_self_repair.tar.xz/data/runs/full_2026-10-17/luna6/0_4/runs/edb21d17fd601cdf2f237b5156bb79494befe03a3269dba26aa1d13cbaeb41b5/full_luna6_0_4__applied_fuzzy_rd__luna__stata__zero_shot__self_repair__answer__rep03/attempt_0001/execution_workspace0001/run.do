clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

keep if abs(score) < 1
generate double rd_weight = 1 - abs(score)
generate double score_right = score * (score >= 0)
generate double score_left = score * (score < 0)
generate double right = score >= 0

* Fit the same weighted local-linear design for both outcomes.
generate double earnings_y = earnings
generate double participated_y = participated
quietly regress earnings_y right score_right score_left [aweight=rd_weight], vce(robust)
scalar reduced_form = _b[right]
scalar var_rf = _se[right]^2
scalar n_obs = e(N)

quietly regress participated_y right score_right score_left [aweight=rd_weight], vce(robust)
scalar first_stage = _b[right]
scalar var_fs = _se[right]^2

* Estimate covariance of the two discontinuities from joint HC0 scores.
quietly regress earnings_y right score_right score_left [aweight=rd_weight]
predict double rf_resid, resid
quietly regress participated_y right score_right score_left [aweight=rd_weight]
predict double fs_resid, resid

matrix X = (J(_N,1,1), right, score_right, score_left)
mata:
    X = st_matrix("X")
    w = st_data(., "rd_weight")
    ur = st_data(., "rf_resid")
    uf = st_data(., "fs_resid")
    bread = invsym(X' * diag(w) * X)
    ar = bread * (X' * diag(w:^2 :* ur:^2) * X) * bread
    af = bread * (X' * diag(w:^2 :* uf:^2) * X) * bread
    cross = bread * (X' * diag(w:^2 :* ur :* uf) * X) * bread
    st_numscalar("var_rf_hc0", ar[2,2])
    st_numscalar("var_fs_hc0", af[2,2])
    st_numscalar("cov_rf_fs", cross[2,2])
end

scalar reduced_form_se = sqrt(var_rf_hc0)
scalar first_stage_se = sqrt(var_fs_hc0)
scalar treatment_effect = reduced_form / first_stage
scalar treatment_var = (var_rf_hc0 / first_stage^2) + ///
    (reduced_form^2 * var_fs_hc0 / first_stage^4) - ///
    (2 * reduced_form * cov_rf_fs / first_stage^3)
scalar treatment_se = sqrt(treatment_var)

display "ANSWER: treatment_effect estimate=" %21.12f treatment_effect " se=" %21.12f treatment_se " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f reduced_form " se=" %21.12f reduced_form_se " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f first_stage " se=" %21.12f first_stage_se " n_obs=" %12.0f n_obs
