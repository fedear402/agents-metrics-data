clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

* Parse dates and sort trading observations.
capture confirm numeric variable date
if _rc {
    gen double _parsed_date = daily(date, "YMD")
    replace _parsed_date = daily(date, "MDY") if missing(_parsed_date)
    replace _parsed_date = daily(date, "DMY") if missing(_parsed_date)
    format _parsed_date %td
    drop date
    rename _parsed_date date
}
sort date

* Log sales and the first difference of log volatility.
gen double log_sales = ln(sales)
gen double log_vix = ln(vix)
gen double dlog_vix = log_vix - log_vix[_n-1]

* Generate trading-observation lags.
forvalues j = 1/15 {
    gen double lag_`j' = dlog_vix[_n-`j']
}

* Keep observations with the full set of 15 lagged changes.
drop if missing(log_sales, lag_1, lag_2, lag_3, lag_4, lag_5, lag_6, lag_7, lag_8, lag_9, lag_10, lag_11, lag_12, lag_13, lag_14, lag_15)

quietly count
scalar N_obs = r(N)

quietly regress log_sales lag_1-lag_15
scalar b_cumulative = 0
forvalues j = 1/15 {
    scalar b_cumulative = b_cumulative + _b[lag_`j']
}

* Newey-West covariance with Bartlett weights through lag 15.
matrix X = e(sample)
quietly newey log_sales lag_1-lag_15, lag(15)
matrix V_nw = e(V)

* Apply the requested finite-sample covariance multiplier.
matrix V_adj = V_nw * (N_obs / (N_obs - 16))

scalar se_cumulative = sqrt(0)
forvalues j = 1/15 {
    scalar se_cumulative = se_cumulative + V_adj[`j', `j']
    forvalues k = `=`j'+1'/15 {
        scalar se_cumulative = se_cumulative + 2 * V_adj[`j', `k']
    }
}
scalar se_cumulative = sqrt(se_cumulative)

scalar b_lag1 = _b[lag_1]
scalar se_lag1 = sqrt(V_adj[1,1])
scalar b_lag15 = _b[lag_15]
scalar se_lag15 = sqrt(V_adj[15,15])

display "ANSWER: cumulative_response estimate=" %21.12f b_cumulative " se=" %21.12f se_cumulative " n_obs=" %12.0f N_obs
display "ANSWER: lag_1 estimate=" %21.12f b_lag1 " se=" %21.12f se_lag1 " n_obs=" %12.0f N_obs
display "ANSWER: lag_15 estimate=" %21.12f b_lag15 " se=" %21.12f se_lag15 " n_obs=" %12.0f N_obs
