clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

keep if abs(score) < 1
generate double weight = 1 - abs(score)
generate double right = score >= 0
generate double slope = score * right
generate double left_slope = score * (1 - right)

quietly count
scalar n_obs = r(N)

* Fit both weighted regressions and retain residuals for joint HC0 covariance.
quietly regress earnings right slope left_slope [aw=weight], noconstant
scalar reduced_form = _b[right]
predict double resid_y, residuals

quietly regress participated right slope left_slope [aw=weight], noconstant
scalar first_stage = _b[right]
predict double resid_d, residuals

* HC0 covariance uses the weighted-regression scores: weight * x * residual.
generate double score_y = weight * resid_y * right
generate double score_d = weight * resid_d * right
quietly summarize score_y, meanonly
scalar meat_yy = sum(score_y^2)
quietly summarize score_d, meanonly
scalar meat_dd = sum(score_d^2)
scalar meat_yd = sum(score_y * score_d)

matrix XWX = J(3,3,0)
generate double x1 = right
generate double x2 = slope
generate double x3 = left_slope
forvalues i = 1/3 {
    forvalues j = 1/3 {
        quietly summarize weight * x`i' * x`j', meanonly
        matrix XWX[`i',`j'] = r(sum)
    }
}
matrix bread = invsym(XWX)
scalar b11 = bread[1,1]

scalar var_rf = b11^2 * meat_yy
scalar var_fs = b11^2 * meat_dd
scalar cov_rf_fs = b11^2 * meat_yd

scalar se_rf = sqrt(var_rf)
scalar se_fs = sqrt(var_fs)
scalar treatment_effect = reduced_form / first_stage
scalar se_te = sqrt(var_rf / first_stage^2 + reduced_form^2 * var_fs / first_stage^4 - 2 * reduced_form * cov_rf_fs / first_stage^3)

display "ANSWER: treatment_effect estimate=" %21.12f treatment_effect " se=" %21.12f se_te " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f reduced_form " se=" %21.12f se_rf " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f first_stage " se=" %21.12f se_fs " n_obs=" %12.0f n_obs
