clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

keep if abs(score) < 1
generate double weight = 1 - abs(score)
generate byte right = score >= 0
generate double x_right = score * right
generate double x_left = score * (1 - right)

quietly count
scalar n_obs = r(N)

* Save the common design columns for HC0 covariance calculations.
generate double c0 = 1
generate double c1 = right
generate double c2 = x_right
generate double c3 = x_left

quietly regress earnings right x_right x_left [aw=weight]
scalar reduced_form = _b[right]
predict double fitted_y, xb
generate double resid_y = earnings - fitted_y

quietly regress participated right x_right x_left [aw=weight]
scalar first_stage = _b[right]
predict double fitted_d, xb
generate double resid_d = participated - fitted_d

matrix XWX = J(4,4,0)
matrix meat_y = J(4,4,0)
matrix meat_d = J(4,4,0)
matrix meat_yd = J(4,4,0)

local cols "c0 c1 c2 c3"
forvalues i = 1/4 {
    local ci : word `i' of `cols'
    forvalues j = 1/4 {
        local cj : word `j' of `cols'
        quietly summarize weight * `ci' * `cj', meanonly
        matrix XWX[`i',`j'] = r(sum)
        quietly summarize weight^2 * `ci' * `cj' * resid_y^2, meanonly
        matrix meat_y[`i',`j'] = r(sum)
        quietly summarize weight^2 * `ci' * `cj' * resid_d^2, meanonly
        matrix meat_d[`i',`j'] = r(sum)
        quietly summarize weight^2 * `ci' * `cj' * resid_y * resid_d, meanonly
        matrix meat_yd[`i',`j'] = r(sum)
    }
}

matrix Ai = syminv(XWX)
matrix V_y = Ai * meat_y * Ai'
matrix V_d = Ai * meat_d * Ai'
matrix V_yd = Ai * meat_yd * Ai'

scalar var_reduced_form = V_y[2,2]
scalar var_first_stage = V_d[2,2]
scalar cov_rf_fs = V_yd[2,2]

scalar treatment_effect = reduced_form / first_stage
scalar var_treatment = var_reduced_form / first_stage^2 ///
    + reduced_form^2 * var_first_stage / first_stage^4 ///
    - 2 * reduced_form * cov_rf_fs / first_stage^3

scalar se_reduced_form = sqrt(max(0, var_reduced_form))
scalar se_first_stage = sqrt(max(0, var_first_stage))
scalar se_treatment = sqrt(max(0, var_treatment))

display "ANSWER: treatment_effect estimate=" %21.12f treatment_effect " se=" %21.12f se_treatment " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f reduced_form " se=" %21.12f se_reduced_form " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f first_stage " se=" %21.12f se_first_stage " n_obs=" %12.0f n_obs
