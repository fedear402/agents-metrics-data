clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

keep if abs(score) < 1
generate double weight = 1 - abs(score)
generate double right = score >= 0
generate double x_right = score * right
generate double x_left = score * (1 - right)

quietly regress earnings right x_right x_left [aw=weight], vce(hc0)
scalar reduced_form = _b[right]
scalar var_reduced_form = _se[right]^2
scalar n_obs = e(N)

quietly regress participated right x_right x_left [aw=weight], vce(hc0)
scalar first_stage = _b[right]
scalar var_first_stage = _se[right]^2

quietly generate byte sample_mark = e(sample)
quietly regress earnings right x_right x_left [aw=weight] if sample_mark, vce(hc0)
scalar var_reduced_form = _se[right]^2

quietly regress participated right x_right x_left [aw=weight] if sample_mark, vce(hc0)
scalar var_first_stage = _se[right]^2

quietly generate double resid_y = earnings - (_b[_cons] + _b[right]*right + _b[x_right]*x_right + _b[x_left]*x_left)
quietly generate double resid_d = participated - (_b[_cons] + _b[right]*right + _b[x_right]*x_right + _b[x_left]*x_left)

quietly regress earnings right x_right x_left [aw=weight] if sample_mark, vce(hc0)
matrix b_y = e(b)
matrix V_y = e(V)
quietly regress participated right x_right x_left [aw=weight] if sample_mark, vce(hc0)
matrix b_d = e(b)
matrix V_d = e(V)

quietly generate double fitted_y = b_y[1,1] + b_y[1,2]*right + b_y[1,3]*x_right + b_y[1,4]*x_left
quietly generate double fitted_d = b_d[1,1] + b_d[1,2]*right + b_d[1,3]*x_right + b_d[1,4]*x_left
quietly generate double u_y = earnings - fitted_y
quietly generate double u_d = participated - fitted_d

* HC0 cross-covariance for the right-indicator coefficients.
quietly generate double z0 = 1
quietly generate double z1 = right
quietly generate double z2 = x_right
quietly generate double z3 = x_left
quietly generate double wz0 = weight*z0
quietly generate double wz1 = weight*z1
quietly generate double wz2 = weight*z2
quietly generate double wz3 = weight*z3
quietly generate double s00 = weight*z0*z0
quietly generate double s01 = weight*z0*z1
quietly generate double s02 = weight*z0*z2
quietly generate double s03 = weight*z0*z3
quietly generate double s11 = weight*z1*z1
quietly generate double s12 = weight*z1*z2
quietly generate double s13 = weight*z1*z3
quietly generate double s22 = weight*z2*z2
quietly generate double s23 = weight*z2*z3
quietly generate double s33 = weight*z3*z3

quietly summarize s00, meanonly
scalar A00 = r(sum)
quietly summarize s01, meanonly
scalar A01 = r(sum)
quietly summarize s02, meanonly
scalar A02 = r(sum)
quietly summarize s03, meanonly
scalar A03 = r(sum)
quietly summarize s11, meanonly
scalar A11 = r(sum)
quietly summarize s12, meanonly
scalar A12 = r(sum)
quietly summarize s13, meanonly
scalar A13 = r(sum)
quietly summarize s22, meanonly
scalar A22 = r(sum)
quietly summarize s23, meanonly
scalar A23 = r(sum)
quietly summarize s33, meanonly
scalar A33 = r(sum)

matrix A = (A00,A01,A02,A03 \ A01,A11,A12,A13 \ A02,A12,A22,A23 \ A03,A13,A23,A33)
matrix Ai = syminv(A)
matrix cross = J(4,4,0)

forvalues i = 1/4 {
    forvalues j = 1/4 {
        quietly summarize u_y*u_d*weight^2*z`=`i'-1'*z`=`j'-1', meanonly
        matrix cross[`i',`j'] = r(sum)
    }
}

matrix C = Ai*cross*Ai'
scalar cov_rf_fs = C[2,2]
scalar treatment_effect = reduced_form/first_stage
scalar var_treatment = var_reduced_form/(first_stage^2) + (reduced_form^2)*var_first_stage/(first_stage^4) - 2*reduced_form*cov_rf_fs/(first_stage^3)
scalar se_treatment = sqrt(max(0,var_treatment))

display "ANSWER: treatment_effect estimate=" %21.12f treatment_effect " se=" %21.12f se_treatment " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f reduced_form " se=" %21.12f sqrt(var_reduced_form) " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f first_stage " se=" %21.12f sqrt(var_first_stage) " n_obs=" %12.0f n_obs
