version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

keep if abs(score) < 1
generate double triangular_weight = 1 - abs(score)
generate double score_right = score * (score >= 0)
generate double score_left = score * (score < 0)
generate double right_side = (score >= 0)

quietly count
scalar n_obs = r(N)

mata:
    y = st_data(., ("earnings", "participated"))
    s = st_data(., "score")
    w = 1 :- abs(s)
    d = (s :>= 0)
    X = (J(rows(s),1,1), d, s:*(s:>=0), s:*(s:<0))

    bread = invsym(X' * (w :* X))
    b = bread * X' * (w :* y)
    u = y - X * b

    // The second design coefficient is the right-minus-left discontinuity.
    c = (0\1\0\0)
    loading = w :* (X * bread * c)
    influence = loading :* u
    V = influence' * influence

    st_numscalar("reduced_form", b[2,1])
    st_numscalar("first_stage", b[2,2])
    st_numscalar("rf_var", V[1,1])
    st_numscalar("fs_var", V[2,2])
    st_numscalar("rf_fs_cov", V[1,2])
end

scalar reduced_form_se = sqrt(rf_var)
scalar first_stage_se = sqrt(fs_var)
scalar treatment_effect = reduced_form / first_stage
scalar treatment_effect_se = sqrt( ///
    rf_var / first_stage^2 + ///
    reduced_form^2 * fs_var / first_stage^4 - ///
    2 * reduced_form * rf_fs_cov / first_stage^3)

display "ANSWER: treatment_effect estimate=" %21.12f treatment_effect ///
    " se=" %21.12f treatment_effect_se " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f reduced_form ///
    " se=" %21.12f reduced_form_se " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f first_stage ///
    " se=" %21.12f first_stage_se " n_obs=" %12.0f n_obs
