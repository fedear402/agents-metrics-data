clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

quietly anova y group

scalar F_value = e(F)
scalar df_num_value = e(df_m)
scalar df_den_value = e(df_r)
scalar p_value = Ftail(df_num_value, df_den_value, F_value)

display "ANSWER: F estimate=" %21.12f F_value " se=" %21.12f . " n_obs=" %12.0f e(N)
display "ANSWER: df_num estimate=" %21.12f df_num_value " se=" %21.12f . " n_obs=" %12.0f e(N)
display "ANSWER: df_den estimate=" %21.12f df_den_value " se=" %21.12f . " n_obs=" %12.0f e(N)
display "ANSWER: p_value estimate=" %21.12f p_value " se=" %21.12f . " n_obs=" %12.0f e(N)
