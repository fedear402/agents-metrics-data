version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

generate double day = date(date, "YMD")
format day %td
sort day
generate long observation = _n
tsset observation

generate double log_vix = log(vix)
generate double vix_change = D.log_vix
generate double log_sales = log(sales)

forvalues j = 1/15 {
    generate double lag_`j' = L`j'.vix_change
}

keep if !missing(log_sales, lag_1, lag_2, lag_3, lag_4, lag_5, ///
    lag_6, lag_7, lag_8, lag_9, lag_10, lag_11, lag_12, ///
    lag_13, lag_14, lag_15)

mata:
X = (J(st_nobs(), 1, 1), st_data(., ("lag_1","lag_2","lag_3","lag_4", ///
    "lag_5","lag_6","lag_7","lag_8","lag_9","lag_10","lag_11", ///
    "lag_12","lag_13","lag_14","lag_15")))
y = st_data(., "log_sales")
b = qrsolve(X, y)
e = y - X*b
N = rows(X)
p = cols(X)
scores = X:*e
meat = scores'*scores

for (j = 1; j <= 15; j++) {
    lag_product = scores[|j+1,1\N,p|]' * scores[|1,1\N-j,p|]
    meat = meat + (1-j/16)*(lag_product + lag_product')
}

bread = invsym(X'*X)
V = (N/(N-16))*bread*meat*bread
contrast = J(16, 1, 1)
contrast[1] = 0
cum_est = contrast'*b
cum_se = sqrt(contrast'*V*contrast)
lag1_est = b[2]
lag1_se = sqrt(V[2,2])
lag15_est = b[16]
lag15_se = sqrt(V[16,16])

st_numscalar("cum_est", cum_est)
st_numscalar("cum_se", cum_se)
st_numscalar("lag1_est", lag1_est)
st_numscalar("lag1_se", lag1_se)
st_numscalar("lag15_est", lag15_est)
st_numscalar("lag15_se", lag15_se)
st_numscalar("reg_n", N)
end

display "ANSWER: cumulative_response estimate=" %21.12f scalar(cum_est) ///
    " se=" %21.12f scalar(cum_se) " n_obs=" %12.0f scalar(reg_n)
display "ANSWER: lag_1 estimate=" %21.12f scalar(lag1_est) ///
    " se=" %21.12f scalar(lag1_se) " n_obs=" %12.0f scalar(reg_n)
display "ANSWER: lag_15 estimate=" %21.12f scalar(lag15_est) ///
    " se=" %21.12f scalar(lag15_se) " n_obs=" %12.0f scalar(reg_n)
