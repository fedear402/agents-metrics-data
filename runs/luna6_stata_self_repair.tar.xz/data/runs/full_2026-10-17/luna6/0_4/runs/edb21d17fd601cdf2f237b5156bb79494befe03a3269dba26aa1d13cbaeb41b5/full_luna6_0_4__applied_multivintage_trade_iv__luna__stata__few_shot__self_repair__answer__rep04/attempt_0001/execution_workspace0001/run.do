clear all
set more off
set type double

import delimited using "crosswalk.csv", clear
isid code
tempfile crosswalk
save `crosswalk'

import delimited using "trade.csv", clear
merge m:1 code using `crosswalk', assert(match) nogen
isid period industry
tempfile trade
save `trade'

import delimited using "areas.csv", clear
isid area period vintage
tempfile areas
save `areas'

import delimited using "employment.csv", clear
collapse (sum) employment, by(area period vintage industry)
tempfile employment
save `employment'

use `areas', clear
keep if vintage == "base"
rename total_employment base_total
rename population weight
keep area period base_total weight
tempfile baseareas
save `baseareas'

use `areas', clear
keep if vintage == "early"
rename total_employment early_total
keep area period early_total
tempfile earlyareas
save `earlyareas'

use `baseareas', clear
merge 1:1 area period using `earlyareas', assert(match) nogen
tempfile area_totals
save `area_totals'

* Build the complete area-period-industry grid so omitted employment cells are zero.
use `area_totals', clear
keep area period
cross using `crosswalk'
tempfile grid
save `grid'

use `employment', clear
reshape wide employment, i(area period industry) j(vintage) string
rename employmentbase base_emp
rename employmentearly early_emp
tempfile empwide
save `empwide'

use `grid', clear
merge 1:1 area period industry using `empwide', nogen
replace base_emp = 0 if missing(base_emp)
replace early_emp = 0 if missing(early_emp)
merge m:1 area period using `area_totals', assert(match) nogen
merge m:1 period industry using `trade', assert(match) nogen

* National industry employment sums areas within period and vintage.
bysort period industry: egen double national_base = total(base_emp)
bysort period industry: egen double national_early = total(early_emp)

gen double x_part = (base_emp/base_total)*(us_change/national_base)/(price_index/100)/1000*(10/years)
gen double z_part = (early_emp/early_total)*(other_change/national_early)/(price_index/100)/1000*(10/years)
collapse (sum) x=x_part z=z_part (first) base_total early_total weight us_change other_change price_index years, by(area period)

tempfile exposures
save `exposures'

import delimited using "outcomes.csv", clear
merge 1:1 area period using `exposures', assert(match) nogen
count
local n = r(N)

* Estimate weighted 2SLS with period, control, and intercept as exogenous instruments.
ivregress 2sls change_pp i.period control (x = z) [aw=weight]
display "ANSWER: iv_slope estimate=" %24.16g _b[x] " se=NA n_obs=" `n'

quietly summarize x if area == 0 & period == 0, meanonly
display "ANSWER: exposure_area0_period0 estimate=" %24.16g r(mean) " se=NA n_obs=" `n'

quietly summarize x if area == 0 & period == 1, meanonly
display "ANSWER: exposure_area0_period1 estimate=" %24.16g r(mean) " se=NA n_obs=" `n'

quietly summarize z if area == 0 & period == 0, meanonly
display "ANSWER: instrument_area0_period0 estimate=" %24.16g r(mean) " se=NA n_obs=" `n'
