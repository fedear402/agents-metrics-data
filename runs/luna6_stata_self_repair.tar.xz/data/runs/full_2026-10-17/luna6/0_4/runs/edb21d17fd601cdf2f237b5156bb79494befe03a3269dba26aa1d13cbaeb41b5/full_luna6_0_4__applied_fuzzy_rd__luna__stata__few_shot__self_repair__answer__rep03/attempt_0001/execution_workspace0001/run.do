version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

keep if abs(score) < 1
generate double weight = 1 - abs(score)
generate double right = score >= 0
generate double score_right = score * right
generate double score_left = score * (1 - right)

local n = _N

mata:
y = st_data(., ("earnings", "participated"))
w = st_data(., "weight")
s = st_data(., "score")
r = (s :>= 0)
X = (J(rows(y),1,1), r, s:*(1:-r), s:*r)

W = diag(w)
bread = invsym(X' * W * X)
b = bread * X' * W * y
e = y - X*b

// Right limit minus left limit for each outcome.
C = (0, 1, 0, 0)
jump = C*b
loading = (w :* (X*bread*C'))
infl = loading :* e
V = infl' * infl

rf = jump[1]
fs = jump[2]
ratio = rf/fs
g = (1/fs \ -rf/(fs^2))
ratio_se = sqrt(g' * V * g)

st_numscalar("rf", rf)
st_numscalar("rf_se", sqrt(V[1,1]))
st_numscalar("fs", fs)
st_numscalar("fs_se", sqrt(V[2,2]))
st_numscalar("ratio", ratio)
st_numscalar("ratio_se", ratio_se)
st_numscalar("n_obs", rows(y))
end

display "ANSWER: treatment_effect estimate=" %21.12f scalar(ratio) " se=" %21.12f scalar(ratio_se) " n_obs=" %12.0f scalar(n_obs)
display "ANSWER: reduced_form estimate=" %21.12f scalar(rf) " se=" %21.12f scalar(rf_se) " n_obs=" %12.0f scalar(n_obs)
display "ANSWER: first_stage estimate=" %21.12f scalar(fs) " se=" %21.12f scalar(fs_se) " n_obs=" %12.0f scalar(n_obs)
