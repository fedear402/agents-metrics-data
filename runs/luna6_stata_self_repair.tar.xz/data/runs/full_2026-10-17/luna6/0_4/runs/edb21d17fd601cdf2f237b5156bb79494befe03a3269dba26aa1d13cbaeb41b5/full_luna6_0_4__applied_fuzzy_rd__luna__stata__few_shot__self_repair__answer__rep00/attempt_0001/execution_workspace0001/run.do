version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

keep if abs(score) < 1
generate double weight = 1 - abs(score)
generate double right = score >= 0
generate double right_score = right * score
generate double left_score = (1 - right) * score

local n = _N

mata:
y = st_data(., ("earnings", "participated"))
s = st_data(., "score")
r = (s :>= 0)
w = 1 :- abs(s)
n = rows(y)

X = (J(n,1,1), r, s :* (1 :- r), s :* r)
bread = invsym(X' * (w :* X))
b = bread * X' * (w :* y)
u = y - X * b

// Right limit minus left limit is the coefficient on the right indicator.
c = (0 \ 1 \ 0 \ 0)
jumps = c' * b

loading = w :* (X * bread * c)
influence = loading :* u
joint = influence' * influence

rf = jumps[1]
fs = jumps[2]
rf_se = sqrt(joint[1,1])
fs_se = sqrt(joint[2,2])

ratio = rf / fs
gradient = (1 / fs \ -rf / (fs^2))
ratio_se = sqrt(gradient' * joint * gradient)

st_numscalar("rf", rf)
st_numscalar("fs", fs)
st_numscalar("ratio", ratio)
st_numscalar("rf_se", rf_se)
st_numscalar("fs_se", fs_se)
st_numscalar("ratio_se", ratio_se)
st_numscalar("n_obs", n)
end

display "ANSWER: treatment_effect estimate=" %21.12f scalar(ratio) " se=" %21.12f scalar(ratio_se) " n_obs=" %12.0f scalar(n_obs)
display "ANSWER: reduced_form estimate=" %21.12f scalar(rf) " se=" %21.12f scalar(rf_se) " n_obs=" %12.0f scalar(n_obs)
display "ANSWER: first_stage estimate=" %21.12f scalar(fs) " se=" %21.12f scalar(fs_se) " n_obs=" %12.0f scalar(n_obs)
