clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

keep if abs(score) < 1
generate double weight = 1 - abs(score)
generate byte right = score >= 0
generate double x_right = score * right
generate double x_left = score * (1 - right)

quietly count
scalar n_obs = r(N)

* Fit the weighted local-linear models.
quietly regress earnings right x_right x_left [aw=weight]
scalar reduced_form = _b[right]

quietly regress participated right x_right x_left [aw=weight]
scalar first_stage = _b[right]

* HC0 covariance calculations use the same design matrix and observations.
matrix X = (J(_N,1,1), right, x_right, x_left)
matrix W = diag(weight)
matrix Ai = syminv(X' * W * X)

quietly regress earnings right x_right x_left [aw=weight]
predict double fitted_y, xb
generate double resid_y = earnings - fitted_y

quietly regress participated right x_right x_left [aw=weight]
predict double fitted_d, xb
generate double resid_d = participated - fitted_d

matrix meat_y = J(4,4,0)
matrix meat_d = J(4,4,0)
matrix meat_yd = J(4,4,0)

forvalues i = 1/4 {
    forvalues j = 1/4 {
        quietly summarize weight^2 * resid_y^2 * X[1,`i']^2, meanonly
        * Accumulate HC0 meat terms using explicit design columns.
    }
}

generate double q00 = weight^2
generate double q01 = weight^2 * right
generate double q02 = weight^2 * x_right
generate double q03 = weight^2 * x_left
generate double q11 = weight^2 * right^2
generate double q12 = weight^2 * right * x_right
generate double q13 = weight^2 * right * x_left
generate double q22 = weight^2 * x_right^2
generate double q23 = weight^2 * x_right * x_left
generate double q33 = weight^2 * x_left^2

local pairs "00 01 02 03 11 12 13 22 23 33"
foreach p of local pairs {
    local a = real(substr("`p'",1,1)) + 1
    local b = real(substr("`p'",2,1)) + 1
    quietly summarize q`p' * resid_y^2, meanonly
    matrix meat_y[`a',`b'] = r(sum)
    matrix meat_y[`b',`a'] = r(sum)
    quietly summarize q`p' * resid_d^2, meanonly
    matrix meat_d[`a',`b'] = r(sum)
    matrix meat_d[`b',`a'] = r(sum)
    quietly summarize q`p' * resid_y * resid_d, meanonly
    matrix meat_yd[`a',`b'] = r(sum)
    matrix meat_yd[`b',`a'] = r(sum)
}

matrix V_y = Ai * meat_y * Ai'
matrix V_d = Ai * meat_d * Ai'
matrix V_yd = Ai * meat_yd * Ai'

scalar var_reduced_form = V_y[2,2]
scalar var_first_stage = V_d[2,2]
scalar cov_rf_fs = V_yd[2,2]

scalar treatment_effect = reduced_form / first_stage
scalar var_treatment = var_reduced_form / first_stage^2 ///
    + reduced_form^2 * var_first_stage / first_stage^4 ///
    - 2 * reduced_form * cov_rf_fs / first_stage^3

scalar se_reduced_form = sqrt(max(0, var_reduced_form))
scalar se_first_stage = sqrt(max(0, var_first_stage))
scalar se_treatment = sqrt(max(0, var_treatment))

display "ANSWER: treatment_effect estimate=" %21.12f treatment_effect " se=" %21.12f se_treatment " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f reduced_form " se=" %21.12f se_reduced_form " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f first_stage " se=" %21.12f se_first_stage " n_obs=" %12.0f n_obs
