version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

keep if abs(score) < 1
generate double triangular_weight = 1 - abs(score)

generate double right = score >= 0
generate double score_left = score * (1 - right)
generate double score_right = score * right

quietly count
scalar n_obs = r(N)

quietly regress earnings right score_left score_right [aw=triangular_weight], vce(robust)
scalar reduced_form = _b[right]
scalar var_reduced_form = _se[right]^2

quietly regress participated right score_left score_right [aw=triangular_weight], vce(robust)
scalar first_stage = _b[right]
scalar var_first_stage = _se[right]^2

* Obtain the HC0 cross-equation covariance from the same weighted design.
mata:
X = st_data(., ("right", "score_left", "score_right"))
w = st_data(., "triangular_weight")
Y = st_data(., ("earnings", "participated"))

bread = invsym(X' * (w :* X))
B = bread * X' * (w :* Y)
E = Y - X * B
influence = (w :* (X * bread[.,1])) :* E
joint = influence' * influence

st_numscalar("var_reduced_form", joint[1,1])
st_numscalar("var_first_stage", joint[2,2])
st_numscalar("cov_rf_fs", joint[1,2])
end

scalar treatment_effect = reduced_form / first_stage
scalar gradient_rf = 1 / first_stage
scalar gradient_fs = -reduced_form / (first_stage^2)
scalar var_treatment_effect = gradient_rf^2 * var_reduced_form + gradient_fs^2 * var_first_stage + 2 * gradient_rf * gradient_fs * cov_rf_fs
scalar se_treatment_effect = sqrt(var_treatment_effect)
scalar se_reduced_form = sqrt(var_reduced_form)
scalar se_first_stage = sqrt(var_first_stage)

display "ANSWER: treatment_effect estimate=" %21.12f treatment_effect " se=" %21.12f se_treatment_effect " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f reduced_form " se=" %21.12f se_reduced_form " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f first_stage " se=" %21.12f se_first_stage " n_obs=" %12.0f n_obs
