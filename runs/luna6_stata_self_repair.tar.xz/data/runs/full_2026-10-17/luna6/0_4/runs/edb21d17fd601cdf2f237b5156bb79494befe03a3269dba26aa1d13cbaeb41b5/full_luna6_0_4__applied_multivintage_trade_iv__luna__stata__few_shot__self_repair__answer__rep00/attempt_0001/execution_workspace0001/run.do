clear all
set more off
set type double

import delimited using "crosswalk.csv", clear
tempfile crosswalk
save `crosswalk'

import delimited using "trade.csv", clear
merge m:1 code using `crosswalk', assert(match) nogen
tempfile trade
save `trade'

import delimited using "areas.csv", clear
keep if vintage == "base"
keep area period total_employment population
tempfile baseareas
save `baseareas'

import delimited using "areas.csv", clear
keep if vintage == "early"
keep area period total_employment
rename total_employment early_total
tempfile earlyareas
save `earlyareas'

use `baseareas', clear
merge 1:1 area period using `earlyareas', assert(match) nogen
tempfile area_totals
save `area_totals'

import delimited using "employment.csv", clear
keep if vintage == "base"
rename employment base_emp
keep area period industry base_emp
tempfile baseemp
save `baseemp'

import delimited using "employment.csv", clear
keep if vintage == "early"
rename employment early_emp
keep area period industry early_emp
tempfile earlyemp
save `earlyemp'

use `baseemp', clear
merge 1:1 area period industry using `earlyemp', nogen
replace base_emp = 0 if missing(base_emp)
replace early_emp = 0 if missing(early_emp)
tempfile emp
save `emp'

use `emp', clear
collapse (sum) national_base=base_emp national_early=early_emp, by(period industry)
tempfile national
save `national'

use `emp', clear
merge m:1 period industry using `national', assert(match) nogen
merge m:1 industry using `crosswalk', keep(master match) nogen
merge m:1 period industry using `trade', assert(match) nogen
merge m:1 area period using `area_totals', assert(match) nogen

gen double x_part = (base_emp/base_total_employment) * ///
    (us_change/national_base) / (price_index/100) / 1000 * (10/years)
gen double z_part = (early_emp/early_total) * ///
    (other_change/national_early) / (price_index/100) / 1000 * (10/years)

collapse (sum) x=x_part z=z_part, by(area period)
tempfile exposures
save `exposures'

import delimited using "outcomes.csv", clear
merge 1:1 area period using `exposures', assert(match) nogen
merge 1:1 area period using `area_totals', assert(match) nogen

quietly count
local n = r(N)
ivregress 2sls change_pp control i.period (x=z) [aw=population]
display "ANSWER: iv_slope estimate=" %24.16g _b[x] " se=NA n_obs=`n'"

quietly summarize x if area == 0 & period == 0, meanonly
display "ANSWER: exposure_area0_period0 estimate=" %24.16g r(mean) " se=NA n_obs=`n'"

quietly summarize x if area == 0 & period == 1, meanonly
display "ANSWER: exposure_area0_period1 estimate=" %24.16g r(mean) " se=NA n_obs=`n'"

quietly summarize z if area == 0 & period == 0, meanonly
display "ANSWER: instrument_area0_period0 estimate=" %24.16g r(mean) " se=NA n_obs=`n'"
