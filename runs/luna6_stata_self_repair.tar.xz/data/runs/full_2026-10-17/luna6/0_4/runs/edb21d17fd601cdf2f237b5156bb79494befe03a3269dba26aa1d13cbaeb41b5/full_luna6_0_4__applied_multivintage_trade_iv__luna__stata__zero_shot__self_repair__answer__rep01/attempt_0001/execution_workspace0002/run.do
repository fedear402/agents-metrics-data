clear all
set more off

* Read all supplied CSV files.
import delimited using "crosswalk.csv", clear
isid code
tempfile crosswalk
save `crosswalk'

import delimited using "trade.csv", clear
merge m:1 code using `crosswalk', assert(match) nogen
tempfile trade
save `trade'

import delimited using "areas.csv", clear
tempfile areas
save `areas'

import delimited using "employment.csv", clear
tempfile employment
save `employment'

import delimited using "outcomes.csv", clear
tempfile outcomes
save `outcomes'

* Sum employment across all supplied areas for each period, vintage, and industry.
use `employment', clear
collapse (sum) national_employment=employment, by(period vintage industry)
tempfile national
save `national'

* Save area-period totals and population by vintage.
use `areas', clear
keep if vintage == "base"
keep area period total_employment population
isid area period
tempfile base_areas
save `base_areas'

use `areas', clear
keep if vintage == "early"
keep area period total_employment
rename total_employment early_total_employment
isid area period
tempfile early_areas
save `early_areas'

* Create one row for each area-period-industry-vintage combination.
use `base_areas', clear
keep area period
cross using `crosswalk'
keep area period industry
tempfile area_industry_grid
save `area_industry_grid'

use `area_industry_grid', clear
expand 2
bysort area period industry: gen str5 vintage = cond(_n == 1, "base", "early")
merge 1:1 area period industry vintage using `employment', keep(master match) nogen
replace employment = 0 if missing(employment)
tempfile complete_employment
save `complete_employment'

* Add national denominators, trade data, and area-period values.
use `complete_employment', clear
merge m:1 period vintage industry using `national', assert(match) nogen
merge m:1 industry using `crosswalk', assert(match) nogen
merge m:1 period code using `trade', assert(match) nogen
merge m:1 area period using `base_areas', keepusing(total_employment population) nogen
merge m:1 area period using `early_areas', keepusing(early_total_employment) nogen

gen double x_component = .
gen double z_component = .
replace x_component = (employment / total_employment) * ///
    (us_change / national_employment) / (price_index / 100) / 1000 * (10 / years) ///
    if vintage == "base"
replace z_component = (employment / early_total_employment) * ///
    (other_change / national_employment) / (price_index / 100) / 1000 * (10 / years) ///
    if vintage == "early"

collapse (sum) x=x_component z=z_component, by(area period)
merge 1:1 area period using `outcomes', assert(match) nogen
merge 1:1 area period using `base_areas', keepusing(population) assert(match) nogen

* Estimate weighted 2SLS with all exogenous regressors as instruments.
gen byte period_indicator = (period == 1)
ivregress 2sls change_pp period_indicator control (x = z) [pweight=population]
scalar iv_slope = _b[x]

quietly summarize x if area == 0 & period == 0, meanonly
scalar exposure_area0_period0 = r(mean)
quietly summarize x if area == 0 & period == 1, meanonly
scalar exposure_area0_period1 = r(mean)
quietly summarize z if area == 0 & period == 0, meanonly
scalar instrument_area0_period0 = r(mean)

local n_obs = 72
display as text "ANSWER: iv_slope estimate=" %21.15g scalar(iv_slope) " se=NA n_obs=" %3.0f `n_obs'
display as text "ANSWER: exposure_area0_period0 estimate=" %21.15g scalar(exposure_area0_period0) " se=NA n_obs=" %3.0f `n_obs'
display as text "ANSWER: exposure_area0_period1 estimate=" %21.15g scalar(exposure_area0_period1) " se=NA n_obs=" %3.0f `n_obs'
display as text "ANSWER: instrument_area0_period0 estimate=" %21.15g scalar(instrument_area0_period0) " se=NA n_obs=" %3.0f `n_obs'
