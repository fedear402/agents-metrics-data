clear all
set more off

import delimited using "households.csv", clear
keep if recipient == 0

tempfile households
save `households'

import delimited using "census.csv", clear
quietly summarize nonrecipient_population if eligible == 0, meanonly
scalar pop_ineligible = r(sum)
quietly summarize nonrecipient_population if eligible == 1, meanonly
scalar pop_eligible = r(sum)
scalar pop_total = pop_ineligible + pop_eligible

use `households', clear
generate byte ineligible = 1 - eligible
generate double dose_ineligible = dose * ineligible
generate double dose_eligible = dose * eligible
generate double baseline_ineligible = baseline * ineligible
generate double baseline_eligible = baseline * eligible
generate double instrument_ineligible = instrument * ineligible
generate double instrument_eligible = instrument * eligible

quietly count
scalar n_obs = r(N)

quietly summarize dose [aw=weight] if eligible == 0, meanonly
scalar mean_dose_ineligible = r(mean)
quietly summarize dose [aw=weight] if eligible == 1, meanonly
scalar mean_dose_eligible = r(mean)

quietly ivregress 2sls outcome ineligible eligible baseline_ineligible baseline_eligible ///
    (dose_ineligible dose_eligible = ineligible eligible baseline_ineligible baseline_eligible instrument_ineligible instrument_eligible) ///
    [aw=weight], noconstant

scalar ineligible_effect = _b[dose_ineligible] * mean_dose_ineligible
scalar eligible_nonrecipient_effect = _b[dose_eligible] * mean_dose_eligible
scalar population_effect = (pop_ineligible * ineligible_effect + pop_eligible * eligible_nonrecipient_effect) / pop_total

display "ANSWER: ineligible_effect estimate=" %21.15g scalar(ineligible_effect) " se=NA n_obs=" %12.0f scalar(n_obs)
display "ANSWER: eligible_nonrecipient_effect estimate=" %21.15g scalar(eligible_nonrecipient_effect) " se=NA n_obs=" %12.0f scalar(n_obs)
display "ANSWER: population_effect estimate=" %21.15g scalar(population_effect) " se=NA n_obs=" %12.0f scalar(n_obs)
