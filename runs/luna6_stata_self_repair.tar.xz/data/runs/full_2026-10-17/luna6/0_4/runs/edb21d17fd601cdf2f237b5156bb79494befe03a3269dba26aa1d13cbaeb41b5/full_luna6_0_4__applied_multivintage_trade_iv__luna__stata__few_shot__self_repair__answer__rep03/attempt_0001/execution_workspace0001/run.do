clear all
set more off
set type double

tempfile crosswalk trade areas employment outcomes panel

import delimited using "crosswalk.csv", clear varnames(1) case(preserve)
isid code
save `crosswalk'

import delimited using "trade.csv", clear varnames(1) case(preserve)
isid period code
merge m:1 code using `crosswalk', assert(match) nogen
isid period industry
save `trade'

import delimited using "areas.csv", clear varnames(1) case(preserve)
keep if vintage == "base"
isid area period
rename total_employment base_total
rename population base_population
keep area period base_total base_population
save `areas'

import delimited using "employment.csv", clear varnames(1) case(preserve)
keep if vintage == "base"
isid area period industry
merge m:1 industry using `crosswalk', assert(match) nogen
collapse (sum) base_employment=employment, by(area period industry)
save `employment'

use `employment', clear
merge m:1 period industry using `trade', assert(match) nogen
bysort period industry: egen double national_base_industry = total(base_employment)
gen double x_component = (base_employment / base_total) * ///
    (us_change / national_base_industry) / (price_index / 100) / 1000 * (10 / years)
collapse (sum) x=x_component, by(area period)
save `panel'

import delimited using "employment.csv", clear varnames(1) case(preserve)
keep if vintage == "early"
isid area period industry
merge m:1 industry using `crosswalk', assert(match) nogen
collapse (sum) early_employment=employment, by(area period industry)
merge m:1 period industry using `trade', assert(match) nogen
bysort period industry: egen double national_early_industry = total(early_employment)
gen double z_component = (early_employment / total_employment) * ///
    (other_change / national_early_industry) / (price_index / 100) / 1000 * (10 / years)
collapse (sum) z=z_component, by(area period)
tempfile zdata
save `zdata'

use `panel', clear
merge 1:1 area period using `zdata', assert(match) nogen
merge 1:1 area period using `areas', assert(match) nogen
import delimited using "outcomes.csv", clear varnames(1) case(preserve)
tempfile outdata
save `outdata'
use `panel', clear
merge 1:1 area period using `outdata', assert(match) nogen
count
local n_obs = r(N)

ivregress 2sls change_pp control i.period (x=z) [aw=base_population]
display "ANSWER: iv_slope estimate=" %24.16g _b[x] " se=NA n_obs=" `n_obs'

quietly summarize x if area==0 & period==0, meanonly
display "ANSWER: exposure_area0_period0 estimate=" %24.16g r(mean) " se=NA n_obs=" `n_obs'

quietly summarize x if area==0 & period==1, meanonly
display "ANSWER: exposure_area0_period1 estimate=" %24.16g r(mean) " se=NA n_obs=" `n_obs'

quietly summarize z if area==0 & period==0, meanonly
display "ANSWER: instrument_area0_period0 estimate=" %24.16g r(mean) " se=NA n_obs=" `n_obs'
