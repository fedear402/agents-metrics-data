version 16.0
clear all
set more off

import delimited using "crosswalk.csv", clear
isid code
tempfile crosswalk
save `crosswalk'

import delimited using "trade.csv", clear
merge m:1 code using `crosswalk', assert(match) nogen
isid period industry
tempfile trade
save `trade'

import delimited using "areas.csv", clear
isid area period vintage
tempfile areas
save `areas'

import delimited using "employment.csv", clear
isid area period vintage industry
tempfile employment
save `employment'

import delimited using "outcomes.csv", clear
isid area period
tempfile outcomes
save `outcomes'

* Build area-period-vintage-industry employment cells, setting omitted cells to zero.
use `areas', clear
keep area period vintage total_employment population
expand 4
bysort area period vintage: gen industry = _n
merge 1:1 area period vintage industry using `employment', keep(master match) nogen
replace employment = 0 if missing(employment)

* Calculate national industry employment by period and vintage across supplied areas.
bysort period vintage industry: egen double national_employment = total(employment)
keep if vintage == "base" | vintage == "early"
tempfile cells
save `cells'

* Create base and early area-industry shares and merge period trade changes.
use `cells', clear
keep if vintage == "base"
rename employment base_employment
rename total_employment base_total_employment
keep area period industry base_employment base_total_employment population
tempfile basecells
save `basecells'

use `cells', clear
keep if vintage == "early"
rename employment early_employment
rename total_employment early_total_employment
keep area period industry early_employment
tempfile earlycells
save `earlycells'

use `basecells', clear
merge 1:1 area period industry using `earlycells', assert(match) nogen
merge m:1 period industry using `trade', assert(match) nogen

* Obtain national denominators for both vintages.
preserve
use `cells', clear
keep period vintage industry national_employment
duplicates drop
keep if vintage == "base"
rename national_employment national_base_employment
keep period industry national_base_employment
tempfile nationalbase
save `nationalbase'
restore
merge m:1 period industry using `nationalbase', assert(match) nogen

preserve
use `cells', clear
keep period vintage industry national_employment
duplicates drop
keep if vintage == "early"
rename national_employment national_early_employment
keep period industry national_early_employment
tempfile nationalearly
save `nationalearly'
restore
merge m:1 period industry using `nationalearly', assert(match) nogen

gen double x_component = (base_employment/base_total_employment) * ///
    (us_change/national_base_employment) / (price_index/100) / 1000 * (10/years)
gen double z_component = (early_employment/early_total_employment) * ///
    (other_change/national_early_employment) / (price_index/100) / 1000 * (10/years)

collapse (sum) x=x_component z=z_component, by(area period)
merge 1:1 area period using `outcomes', assert(match) nogen

* Encode period as a numeric regressor when its source representation is text.
capture confirm numeric variable period
if _rc {
    encode period, gen(period_numeric)
}
else {
    gen double period_numeric = period
}

* Weighted 2SLS, using all exogenous regressors as instruments.
ivregress 2sls change_pp control period_numeric (x = z) [aweight=population], vce(robust)
scalar iv_slope = _b[x]

quietly summarize x if area == 0 & period == 0, meanonly
scalar exposure_area0_period0 = r(mean)
quietly summarize x if area == 0 & period == 1, meanonly
scalar exposure_area0_period1 = r(mean)
quietly summarize z if area == 0 & period == 0, meanonly
scalar instrument_area0_period0 = r(mean)

display "ANSWER: iv_slope estimate=" %21.12g scalar(iv_slope) " se=NA n_obs=72"
display "ANSWER: exposure_area0_period0 estimate=" %21.12g scalar(exposure_area0_period0) " se=NA n_obs=72"
display "ANSWER: exposure_area0_period1 estimate=" %21.12g scalar(exposure_area0_period1) " se=NA n_obs=72"
display "ANSWER: instrument_area0_period0 estimate=" %21.12g scalar(instrument_area0_period0) " se=NA n_obs=72"
