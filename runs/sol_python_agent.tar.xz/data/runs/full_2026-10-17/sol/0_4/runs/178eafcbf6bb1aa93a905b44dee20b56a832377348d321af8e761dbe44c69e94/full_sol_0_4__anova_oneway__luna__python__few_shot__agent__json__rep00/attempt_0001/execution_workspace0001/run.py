import json

import pandas as pd
from scipy import stats


data = pd.read_csv("input.csv")
sample = data.loc[:, ["group", "y"]].dropna().copy()
sample["y"] = pd.to_numeric(sample["y"], errors="raise")
groups = [values.to_numpy(dtype=float) for _, values in sample.groupby("group", sort=True)["y"]]

n_obs = len(sample)
n_groups = len(groups)
if n_groups < 2 or n_obs <= n_groups:
    raise ValueError("ANOVA requires at least two groups and residual degrees of freedom")

f_stat, p_value = stats.f_oneway(*groups)
df_num = n_groups - 1
df_den = n_obs - n_groups

result = {
    "task_id": "anova_oneway",
    "platform": "python",
    "estimates": [
        {"term": "F", "estimate": float(f_stat), "se": None, "n_obs": n_obs},
        {"term": "df_num", "estimate": float(df_num), "se": None, "n_obs": n_obs},
        {"term": "df_den", "estimate": float(df_den), "se": None, "n_obs": n_obs},
        {"term": "p_value", "estimate": float(p_value), "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {"estimator": "One-way ANOVA", "vcov": "none"},
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output, indent=2, allow_nan=False)
