import json

import numpy as np
import pandas as pd


data = pd.read_csv('input.csv')
assert not data.isna().any().any()
assert not data.duplicated(['region_id', 'industry_id']).any()
regions = data.groupby('region_id', sort=True)
industries = data.groupby('industry_id', sort=True)
for name in ['region_weight', 'x', 'y']:
    assert (regions[name].max() == regions[name].min()).all()
assert (industries['shock'].max() == industries['shock'].min()).all()

share = data.pivot(index='region_id', columns='industry_id', values='share')
assert share.notna().all().all()
assert np.allclose(share.sum(axis=1).to_numpy(), 1, atol=1e-12)
assert (share.to_numpy() >= 0).all()
regional = regions[['region_weight', 'x', 'y']].first().loc[share.index]
shock = industries['shock'].first().loc[share.columns].to_numpy(dtype=float)
shares = share.to_numpy(dtype=float)
weight = regional['region_weight'].to_numpy(dtype=float)
assert (weight > 0).all()
weight = weight / weight.sum()
x = regional['x'].to_numpy(dtype=float)
y = regional['y'].to_numpy(dtype=float)
z = shares @ shock
values = np.column_stack([y, x, z])
centered = values - weight @ values
mass = weight @ shares
assert (mass > 0).all()
aggregated = (shares.T @ (weight[:, None] * centered)) / mass[:, None]
assert np.allclose(mass @ aggregated, 0, atol=1e-12)
n = len(shock)
assert n > 2


def shock_iv(dependent, endogenous):
    regressors = np.column_stack([np.ones(n), endogenous])
    instruments = np.column_stack([np.ones(n), shock])
    cross = instruments.T @ (mass[:, None] * regressors)
    beta = np.linalg.solve(cross, instruments.T @ (mass * dependent))
    residual = dependent - regressors @ beta
    scores = instruments * (mass * residual)[:, None]
    inverse = np.linalg.inv(cross)
    covariance = n / (n - 2) * inverse @ (scores.T @ scores) @ inverse.T
    return float(beta[1]), float(np.sqrt(covariance[1, 1])), residual


effect, effect_se, effect_residual = shock_iv(aggregated[:, 0], aggregated[:, 1])
first_stage, first_stage_se, first_residual = shock_iv(aggregated[:, 1], aggregated[:, 2])

# Independent regional covariance identities for the two slopes.
regional_effect = np.sum(weight * centered[:, 2] * centered[:, 0]) / np.sum(
    weight * centered[:, 2] * centered[:, 1]
)
regional_first = np.sum(weight * centered[:, 2] * centered[:, 1]) / np.sum(
    weight * centered[:, 2] ** 2
)
assert np.isclose(effect, regional_effect, rtol=1e-10, atol=1e-12)
assert np.isclose(first_stage, regional_first, rtol=1e-10, atol=1e-12)

# Separate scalar HC1 calculation after removing the weighted shock mean.
shock_centered = shock - np.sum(mass * shock) / mass.sum()
def scalar_se(endogenous, residual):
    end_centered = endogenous - np.sum(mass * endogenous) / mass.sum()
    denominator = np.sum(mass * shock_centered * end_centered)
    numerator = np.sum((mass * shock_centered * residual) ** 2)
    return float(np.sqrt((n / (n - 2)) * numerator / denominator**2))

assert np.isclose(effect_se, scalar_se(aggregated[:, 1], effect_residual), rtol=1e-10)
assert np.isclose(first_stage_se, scalar_se(aggregated[:, 2], first_residual), rtol=1e-10)

result = {
    'task_id': 'applied_shift_share',
    'platform': 'python',
    'estimates': [
        {'term': 'effect', 'estimate': effect, 'se': effect_se, 'n_obs': n},
        {'term': 'first_stage', 'estimate': first_stage, 'se': first_stage_se, 'n_obs': n},
        {'term': 'effective_shocks', 'estimate': float(1 / np.sum(mass**2)), 'se': None, 'n_obs': n},
    ],
    'method_metadata': {
        'estimator': 'Regional weighted 2SLS; shock-level weighted IV with intercept',
        'vcov': 'Industry-level heteroskedastic HC1, N/(N-2), analytic weights',
    },
    'diagnostics': {},
}
with open('result.json', 'w') as stream:
    json.dump(result, stream, indent=2, allow_nan=False)

with open('verification.txt', 'w') as stream:
    stream.write(f'Sample: {len(data)} region-industry rows, {len(regional)} regions, {n} industries.\n')
    stream.write('Each pair is unique; the panel is complete; shares sum to one per region.\n')
    stream.write('Regional weight, x, and y are constant within region; shock is constant within industry.\n')
    stream.write('Weights were normalized once across regions. All regional variables were weighted-mean centered before aggregation.\n')
    stream.write('Shock IV includes an intercept and uses structural residuals with analytic-weight HC1 scores and N/(N-2).\n')
    stream.write(f'Effect: shock IV {effect:.15g}; independent regional ratio {regional_effect:.15g}; difference {abs(effect-regional_effect):.3g}.\n')
    stream.write(f'First stage: shock IV {first_stage:.15g}; independent regional ratio {regional_first:.15g}; difference {abs(first_stage-regional_first):.3g}.\n')
    stream.write(f'Effect SE: matrix {effect_se:.15g}; scalar score {scalar_se(aggregated[:, 1], effect_residual):.15g}.\n')
    stream.write(f'First-stage SE: matrix {first_stage_se:.15g}; scalar score {scalar_se(aggregated[:, 2], first_residual):.15g}.\n')
