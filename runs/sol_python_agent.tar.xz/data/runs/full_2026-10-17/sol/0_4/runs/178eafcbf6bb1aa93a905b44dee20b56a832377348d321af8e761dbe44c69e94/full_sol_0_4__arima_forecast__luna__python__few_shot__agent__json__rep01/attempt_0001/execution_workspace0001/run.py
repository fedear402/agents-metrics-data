import json

import pandas as pd
from statsmodels.tsa.arima.model import ARIMA


data = pd.read_csv("input.csv")
if list(data.columns) != ["t", "y"]:
    raise ValueError("Expected t and y columns")
if data["t"].tolist() != list(range(1, 251)):
    raise ValueError("Expected consecutive observations t=1,...,250")
levels = pd.to_numeric(data["y"], errors="raise")
if levels.isna().any():
    raise ValueError("Missing y values")

fit = ARIMA(levels, order=(1, 1, 1), trend="n").fit()
prediction = fit.get_forecast(steps=1)
forecast = float(prediction.predicted_mean.iloc[0])
bounds = prediction.conf_int(alpha=0.05).iloc[0]
forecast_se = float(prediction.se_mean.iloc[0])

output = {
    "task_id": "arima_forecast",
    "platform": "python",
    "estimates": [
        {"term": "forecast", "estimate": forecast, "se": forecast_se, "n_obs": int(fit.nobs)},
        {"term": "lower_95", "estimate": float(bounds.iloc[0]), "se": None, "n_obs": int(fit.nobs)},
        {"term": "upper_95", "estimate": float(bounds.iloc[1]), "se": None, "n_obs": int(fit.nobs)},
    ],
    "method_metadata": {"estimator": "ARIMA(1,1,1) maximum likelihood, no drift", "vcov": "model-based Gaussian prediction variance"},
    "diagnostics": {},
}
with open("result.json", "w") as file:
    json.dump(output, file, indent=2)
