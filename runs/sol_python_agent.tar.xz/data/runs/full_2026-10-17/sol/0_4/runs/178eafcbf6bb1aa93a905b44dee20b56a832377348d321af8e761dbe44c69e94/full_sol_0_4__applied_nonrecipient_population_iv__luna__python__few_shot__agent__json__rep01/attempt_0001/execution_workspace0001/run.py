import json

import numpy as np
import pandas as pd


households = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")
sample = households.loc[households["recipient"].eq(0)].copy()
n_obs = len(sample)

g0 = 1.0 - sample["eligible"].to_numpy(dtype=float)
g1 = sample["eligible"].to_numpy(dtype=float)
baseline = sample["baseline"].to_numpy(dtype=float)
dose = sample["dose"].to_numpy(dtype=float)
instrument = sample["instrument"].to_numpy(dtype=float)
weight = sample["weight"].to_numpy(dtype=float)
outcome = sample["outcome"].to_numpy(dtype=float)

exogenous = np.column_stack((g0, g1, baseline * g0, baseline * g1))
endogenous = np.column_stack((dose * g0, dose * g1))
excluded = np.column_stack((instrument * g0, instrument * g1))
x = np.column_stack((exogenous, endogenous))
z = np.column_stack((exogenous, excluded))

# Weighted 2SLS normal equations. Columns 4 and 5 are the two dose slopes.
z_w_z = z.T @ (weight[:, None] * z)
x_w_z = x.T @ (weight[:, None] * z)
z_w_y = z.T @ (weight * outcome)
beta = np.linalg.solve(x_w_z @ np.linalg.solve(z_w_z, x_w_z.T),
                       x_w_z @ np.linalg.solve(z_w_z, z_w_y))

group_effects = {}
weighted_mean_dose = {}
for group, slope in ((0, beta[4]), (1, beta[5])):
    mask = sample["eligible"].to_numpy() == group
    weighted_mean_dose[group] = float(np.average(dose[mask], weights=weight[mask]))
    group_effects[group] = float(slope * weighted_mean_dose[group])

population = census.set_index("eligible")["nonrecipient_population"]
population_effect = float(np.average(
    [group_effects[0], group_effects[1]],
    weights=[population.loc[0], population.loc[1]],
))

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {"term": "ineligible_effect", "estimate": group_effects[0], "se": None, "n_obs": n_obs},
        {"term": "eligible_nonrecipient_effect", "estimate": group_effects[1], "se": None, "n_obs": n_obs},
        {"term": "population_effect", "estimate": population_effect, "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "sample": "recipient == 0, both village treatment statuses retained",
        "exogenous": ["1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"],
        "endogenous": ["dose*(1-eligible)", "dose*eligible"],
        "excluded_instruments": ["instrument*(1-eligible)", "instrument*eligible"],
        "counterfactual": "dose set to zero for every retained household; synthetic attribution convention",
        "within_group_aggregation": "household-weighted mean dose",
        "between_group_aggregation": "nonrecipient_population census counts",
    },
    "diagnostics": {
        "group_counts": {str(g): int((sample["eligible"] == g).sum()) for g in (0, 1)},
        "group_counts_by_treated": {
            f"eligible_{g}_treated_{t}": int(((sample["eligible"] == g) & (sample["treated"] == t)).sum())
            for g in (0, 1) for t in (0, 1)
        },
        "dose_slopes": {"0": float(beta[4]), "1": float(beta[5])},
        "weighted_mean_dose": {str(g): weighted_mean_dose[g] for g in (0, 1)},
        "census_nonrecipient_population": {str(g): int(population.loc[g]) for g in (0, 1)},
        "rank_x": int(np.linalg.matrix_rank(x)),
        "rank_z": int(np.linalg.matrix_rank(z)),
    },
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file, indent=2, allow_nan=False)
    file.write("\n")
