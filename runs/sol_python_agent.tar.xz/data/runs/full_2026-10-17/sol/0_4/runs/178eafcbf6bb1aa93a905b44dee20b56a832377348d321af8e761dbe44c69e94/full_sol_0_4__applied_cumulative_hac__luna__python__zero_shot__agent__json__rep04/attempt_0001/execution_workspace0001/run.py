import json

import numpy as np
import pandas as pd
import statsmodels.api as sm
from statsmodels.stats.sandwich_covariance import cov_hac


data = pd.read_csv("input.csv", parse_dates=["date"]).sort_values("date")
change = np.log(data["vix"]).diff()
regression = pd.DataFrame({"log_sales": np.log(data["sales"])})
for lag in range(1, 16):
    regression[f"lag_{lag}"] = change.shift(lag)
regression = regression.dropna()

columns = [f"lag_{lag}" for lag in range(1, 16)]
x = sm.add_constant(regression[columns])
fit = sm.OLS(regression["log_sales"], x).fit()
n = int(fit.nobs)
covariance = cov_hac(fit, nlags=15, use_correction=False) * n / (n - 16)
beta = fit.params.to_numpy()
sum_vector = np.r_[0.0, np.ones(15)]

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {
            "term": "cumulative_response",
            "estimate": float(sum_vector @ beta),
            "se": float(np.sqrt(sum_vector @ covariance @ sum_vector)),
            "n_obs": n,
        },
        {
            "term": "lag_1",
            "estimate": float(fit.params["lag_1"]),
            "se": float(np.sqrt(covariance[1, 1])),
            "n_obs": n,
        },
        {
            "term": "lag_15",
            "estimate": float(fit.params["lag_15"]),
            "se": float(np.sqrt(covariance[15, 15])),
            "n_obs": n,
        },
    ],
    "method_metadata": {
        "estimator": "OLS with intercept and 15 trading-observation lags of delta log(vix)",
        "vcov": "Newey-West HAC, Bartlett weights, maximum lag 15, multiplied by N/(N-16)",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output, indent=2)
