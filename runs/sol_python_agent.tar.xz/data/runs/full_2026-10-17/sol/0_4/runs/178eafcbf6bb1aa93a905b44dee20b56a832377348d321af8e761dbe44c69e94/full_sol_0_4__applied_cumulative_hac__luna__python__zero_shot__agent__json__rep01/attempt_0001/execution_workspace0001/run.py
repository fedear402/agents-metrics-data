import json

import numpy as np
import pandas as pd
import statsmodels.api as sm
from statsmodels.stats.sandwich_covariance import cov_hac


df = pd.read_csv("input.csv", parse_dates=["date"]).sort_values("date")
change = np.log(df["vix"]).diff()
lags = pd.concat({f"lag_{k}": change.shift(k) for k in range(1, 16)}, axis=1)
sample = pd.concat([np.log(df["sales"]).rename("log_sales"), lags], axis=1).dropna()
y = sample["log_sales"].to_numpy()
X = sm.add_constant(sample[[f"lag_{k}" for k in range(1, 16)]]).to_numpy()
n = len(y)
fit = sm.OLS(y, X).fit()
cov = cov_hac(fit, nlags=15, weights_func=lambda m: 1 - np.arange(m + 1) / 16, use_correction=False)
cov *= n / (n - 16)
weights = np.r_[0, np.ones(15)]

terms = [
    ("cumulative_response", float(weights @ fit.params), float(np.sqrt(weights @ cov @ weights))),
    ("lag_1", float(fit.params[1]), float(np.sqrt(cov[1, 1]))),
    ("lag_15", float(fit.params[15]), float(np.sqrt(cov[15, 15]))),
]
result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [{"term": name, "estimate": value, "se": se, "n_obs": n} for name, value, se in terms],
    "method_metadata": {"estimator": "OLS with intercept and 15 lagged log VIX changes", "vcov": "Newey-West HAC, Bartlett maximum lag 15, multiplied by N/(N-16)"},
    "diagnostics": {},
}
with open("result.json", "w") as file:
    json.dump(result, file, indent=2)

# Independent least-squares and HAC sandwich calculations.
beta_check = np.linalg.lstsq(X, y, rcond=None)[0]
u = y - X @ beta_check
scores = X * u[:, None]
meat = scores.T @ scores
for j in range(1, 16):
    cross = scores[j:].T @ scores[:-j]
    meat += (1 - j / 16) * (cross + cross.T)
inverse = np.linalg.inv(X.T @ X)
cov_check = inverse @ meat @ inverse * n / (n - 16)
assert n == len(df) - 16
assert sample.index[0] == df.index[16]
assert np.allclose(beta_check, fit.params, rtol=1e-10, atol=1e-10)
assert np.allclose(cov_check, cov, rtol=1e-8, atol=1e-10)
with open("verification.txt", "w") as file:
    file.write(f"Input rows: {len(df)}. Regression rows: {n}. First complete row is sorted row 17.\n")
    file.write("Log VIX change uses adjacent sorted trading rows; lag 1 is the previous change and lag 15 is the fifteenth previous change.\n")
    file.write(f"Independent least-squares maximum coefficient difference: {np.max(np.abs(beta_check - fit.params)):.3g}.\n")
    file.write(f"Independent Bartlett HAC maximum covariance difference: {np.max(np.abs(cov_check - cov)):.3g}.\n")
    file.write("The cumulative standard error uses the full 15 by 15 coefficient covariance block. All checks passed.\n")
