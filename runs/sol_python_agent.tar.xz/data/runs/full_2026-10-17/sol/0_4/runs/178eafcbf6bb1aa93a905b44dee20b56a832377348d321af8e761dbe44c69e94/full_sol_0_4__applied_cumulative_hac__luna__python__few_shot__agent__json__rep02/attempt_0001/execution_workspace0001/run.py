import json

import numpy as np
import pandas as pd


data = pd.read_csv("input.csv", parse_dates=["date"])
data = data.sort_values("date").reset_index(drop=True)
change = np.log(data["vix"]).diff()
lag_names = [f"lag_{j}" for j in range(1, 16)]
for j, name in enumerate(lag_names, start=1):
    data[name] = change.shift(j)
data["log_sales"] = np.log(data["sales"])
sample = data.dropna(subset=["log_sales", *lag_names])

n = len(sample)
x = np.column_stack((np.ones(n), sample[lag_names].to_numpy()))
y = sample["log_sales"].to_numpy()
beta = np.linalg.lstsq(x, y, rcond=None)[0]
residuals = y - x @ beta
scores = x * residuals[:, None]
meat = scores.T @ scores
for j in range(1, 16):
    product = scores[j:].T @ scores[:-j]
    meat += (1 - j / 16) * (product + product.T)
bread = np.linalg.inv(x.T @ x)
covariance = (n / (n - 16)) * bread @ meat @ bread

contrast = np.r_[0.0, np.ones(15)]
rows = [
    {"term": "cumulative_response", "estimate": float(contrast @ beta),
     "se": float(np.sqrt(contrast @ covariance @ contrast)), "n_obs": n},
    {"term": "lag_1", "estimate": float(beta[1]),
     "se": float(np.sqrt(covariance[1, 1])), "n_obs": n},
    {"term": "lag_15", "estimate": float(beta[15]),
     "se": float(np.sqrt(covariance[15, 15])), "n_obs": n},
]
output = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": rows,
    "method_metadata": {
        "estimator": "OLS with intercept and 15 observed-row lags of log VIX changes",
        "vcov": "Newey-West Bartlett HAC, maximum lag 15, multiplied by N/(N-16)",
    },
    "diagnostics": {},
}
with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
