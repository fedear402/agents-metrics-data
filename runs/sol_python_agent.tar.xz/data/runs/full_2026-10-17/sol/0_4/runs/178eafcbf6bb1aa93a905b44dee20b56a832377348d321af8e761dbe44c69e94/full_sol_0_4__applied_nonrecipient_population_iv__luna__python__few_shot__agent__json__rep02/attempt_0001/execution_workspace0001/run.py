import json

import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS


households = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")
sample = households.loc[households["recipient"].eq(0)].copy()
n_obs = int(len(sample))

ineligible = 1 - sample["eligible"]
eligible = sample["eligible"]
exog = pd.DataFrame({
    "ineligible": ineligible,
    "eligible": eligible,
    "baseline_ineligible": sample["baseline"] * ineligible,
    "baseline_eligible": sample["baseline"] * eligible,
})
endog = pd.DataFrame({
    "dose_ineligible": sample["dose"] * ineligible,
    "dose_eligible": sample["dose"] * eligible,
})
excluded = pd.DataFrame({
    "instrument_ineligible": sample["instrument"] * ineligible,
    "instrument_eligible": sample["instrument"] * eligible,
})

fit = IV2SLS(
    sample["outcome"], exog, endog, excluded, weights=sample["weight"]
).fit()

group_effects = {}
group_details = {}
for group in (0, 1):
    group_sample = sample.loc[sample["eligible"].eq(group)]
    mean_dose = float(np.average(group_sample["dose"], weights=group_sample["weight"]))
    slope = float(fit.params["dose_ineligible" if group == 0 else "dose_eligible"])
    group_effects[group] = slope * mean_dose
    group_details[str(group)] = {
        "n_obs": int(len(group_sample)),
        "dose_slope": slope,
        "weighted_mean_dose": mean_dose,
    }

population = census.set_index("eligible")["nonrecipient_population"]
population_effect = float(np.average(
    [group_effects[0], group_effects[1]],
    weights=[population.loc[0], population.loc[1]],
))

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {"term": "ineligible_effect", "estimate": group_effects[0], "se": None, "n_obs": n_obs},
        {"term": "eligible_nonrecipient_effect", "estimate": group_effects[1], "se": None, "n_obs": n_obs},
        {"term": "population_effect", "estimate": population_effect, "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "sample": "recipient == 0, including both village treatment statuses",
        "exogenous": list(exog.columns),
        "endogenous": list(endog.columns),
        "instruments": list(exog.columns) + list(excluded.columns),
        "intercept": "none beyond eligibility-group indicators",
        "regression_weight": "weight",
        "counterfactual": "dose = 0 for every retained household; synthetic convention",
        "group_effect": "fitted group dose slope times household-weighted group mean dose",
        "aggregation_weight": "nonrecipient_population from census.csv",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "group_details": group_details,
        "census_nonrecipient_population": {str(k): int(population.loc[k]) for k in (0, 1)},
        "village_treatment_counts": {
            str(int(k)): int(v) for k, v in sample["treated"].value_counts().sort_index().items()
        },
    },
}

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output, indent=2, allow_nan=False)
    output.write("\n")
