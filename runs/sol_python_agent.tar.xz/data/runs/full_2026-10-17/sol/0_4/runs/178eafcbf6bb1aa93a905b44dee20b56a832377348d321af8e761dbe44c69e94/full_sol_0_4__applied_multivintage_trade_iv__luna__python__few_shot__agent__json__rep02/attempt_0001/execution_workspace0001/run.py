import json
from pathlib import Path

import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS


ROOT = Path(__file__).resolve().parent
crosswalk = pd.read_csv(ROOT / "crosswalk.csv")
trade = pd.read_csv(ROOT / "trade.csv")
areas = pd.read_csv(ROOT / "areas.csv")
employment = pd.read_csv(ROOT / "employment.csv")
outcomes = pd.read_csv(ROOT / "outcomes.csv")

assert crosswalk.code.is_unique
assert not trade.duplicated(["period", "code"]).any()
assert not areas.duplicated(["area", "period", "vintage"]).any()
assert not outcomes.duplicated(["area", "period"]).any()
assert not employment.duplicated(["area", "period", "vintage", "industry"]).any()

trade = trade.merge(crosswalk, on="code", validate="many_to_one")
assert not trade.duplicated(["period", "industry"]).any()
assert trade.groupby("period").industry.nunique().eq(4).all()
assert trade.groupby("period")[["price_index", "years"]].nunique().eq(1).all().all()

# The complete grid makes omitted area-industry employment cells equal zero.
grid = areas[["area", "period", "vintage"]].merge(
    trade[["period", "industry"]].drop_duplicates(), on="period", validate="many_to_many"
)
grid = grid.merge(
    employment,
    on=["area", "period", "vintage", "industry"],
    how="left",
    validate="one_to_one",
)
grid["employment"] = grid.employment.fillna(0.0)
national = grid.groupby(["period", "vintage", "industry"], as_index=False).employment.sum()
national = national.rename(columns={"employment": "national_employment"})
assert (national.national_employment > 0).all()

cells = grid.merge(national, on=["period", "vintage", "industry"], validate="many_to_one")
cells = cells.merge(areas, on=["area", "period", "vintage"], validate="many_to_one")
cells = cells.merge(trade, on=["period", "industry"], validate="many_to_one")
cells["change"] = np.where(cells.vintage.eq("base"), cells.us_change, cells.other_change)
cells["contribution"] = (
    cells.employment / cells.total_employment
    * cells.change / cells.national_employment
    / (cells.price_index / 100)
    / 1000
    * (10 / cells.years)
)
exposure = cells.groupby(["area", "period", "vintage"], as_index=False).contribution.sum()
wide = exposure.pivot(index=["area", "period"], columns="vintage", values="contribution")
wide = wide.rename(columns={"base": "x", "early": "z"}).reset_index()
sample = outcomes.merge(wide, on=["area", "period"], validate="one_to_one")
weights = areas.loc[areas.vintage.eq("base"), ["area", "period", "population"]]
sample = sample.merge(weights, on=["area", "period"], validate="one_to_one")
sample = sample.sort_values(["period", "area"]).reset_index(drop=True)
assert len(sample) == 72
assert sample[["change_pp", "period", "control", "x", "z", "population"]].notna().all().all()
assert (sample.population > 0).all()

exog = pd.DataFrame({"intercept": np.ones(len(sample)), "period": sample.period, "control": sample.control})
fit = IV2SLS(sample.change_pp, exog, sample[["x"]], sample[["z"]], weights=sample.population).fit()
slope = float(fit.params["x"])

# Independent Frisch-Waugh-Lovell calculation for one endogenous regressor.
c = exog.to_numpy(dtype=float)
w = sample.population.to_numpy(dtype=float)
y = sample.change_pp.to_numpy(dtype=float)
x = sample.x.to_numpy(dtype=float)
z = sample.z.to_numpy(dtype=float)
def residual(v):
    return v - c @ np.linalg.solve(c.T @ (w[:, None] * c), c.T @ (w * v))
rx, rz, ry = residual(x), residual(z), residual(y)
manual_slope = float(np.dot(w * rz, ry) / np.dot(w * rz, rx))
assert np.isclose(slope, manual_slope, rtol=1e-10, atol=1e-10)

# Check one exposure using a separate scalar loop over the four industries.
def direct_exposure(area, period, vintage, change_name):
    a = areas.set_index(["area", "period", "vintage"]).loc[(area, period, vintage)]
    value = 0.0
    for row in trade.loc[trade.period.eq(period)].itertuples():
        e = employment.loc[
            employment.area.eq(area) & employment.period.eq(period)
            & employment.vintage.eq(vintage) & employment.industry.eq(row.industry), "employment"
        ].sum()
        n = employment.loc[
            employment.period.eq(period) & employment.vintage.eq(vintage)
            & employment.industry.eq(row.industry), "employment"
        ].sum()
        value += (e / a.total_employment) * (getattr(row, change_name) / n) / (row.price_index / 100) / 1000 * (10 / row.years)
    return float(value)

x00 = float(sample.loc[sample.area.eq(0) & sample.period.eq(0), "x"].iloc[0])
x01 = float(sample.loc[sample.area.eq(0) & sample.period.eq(1), "x"].iloc[0])
z00 = float(sample.loc[sample.area.eq(0) & sample.period.eq(0), "z"].iloc[0])
assert np.isclose(x00, direct_exposure(0, 0, "base", "us_change"), rtol=1e-12)
assert np.isclose(x01, direct_exposure(0, 1, "base", "us_change"), rtol=1e-12)
assert np.isclose(z00, direct_exposure(0, 0, "early", "other_change"), rtol=1e-12)

terms = {
    "iv_slope": slope,
    "exposure_area0_period0": x00,
    "exposure_area0_period1": x01,
    "instrument_area0_period0": z00,
}
result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [{"term": term, "estimate": value, "se": None, "n_obs": 72} for term, value in terms.items()],
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "outcome": "change_pp",
        "endogenous": "x",
        "excluded_instrument": "z",
        "exogenous_instruments": ["intercept", "period", "control"],
        "weight": "base-vintage population",
        "exposure_unit": "thousands of real dollars per worker per decade",
    },
    "diagnostics": {
        "estimation_rows": len(sample),
        "periods": sorted(int(p) for p in sample.period.unique()),
        "industries_per_period": 4,
        "independent_iv_slope": manual_slope,
        "iv_slope_check_absolute_error": abs(slope - manual_slope),
    },
}
with (ROOT / "result.json").open("w") as f:
    json.dump(result, f, indent=2, allow_nan=False)
    f.write("\n")

checks = (
    "Read crosswalk.csv, trade.csv, areas.csv, employment.csv, and outcomes.csv.\n"
    "The complete area-period-vintage-industry grid assigns zero to omitted employment cells.\n"
    f"Estimation sample: {len(sample)} distinct area-period rows across {sample.period.nunique()} periods.\n"
    "National denominators sum all supplied areas within period, vintage, and industry.\n"
    "Exposure factors use the matched vintage, trade change, price index, and interval length.\n"
    "Weighted 2SLS uses change_pp, intercept, period, control, x, z, and base population.\n"
    "No uncertainty measure was requested; all se values are null.\n"
    f"Independent weighted residualization slope: {manual_slope:.15g}.\n"
    f"Package IV slope: {slope:.15g}; absolute difference: {abs(slope-manual_slope):.3g}.\n"
    "Separate scalar sums across four industries match the three requested exposure values.\n"
)
(ROOT / "verification.txt").write_text(checks)
print(json.dumps(terms, indent=2))
