import json

import numpy as np
import pandas as pd
import statsmodels.api as sm


data = pd.read_csv("input.csv")
sample = data.loc[data["score"].abs() < 1].copy()
score = sample["score"].to_numpy(dtype=float)
right = (score >= 0).astype(float)
weights = 1 - np.abs(score)
design = np.column_stack((np.ones(len(sample)), right, score, right * score))
earnings = sample["earnings"].to_numpy(dtype=float)
participation = sample["participated"].to_numpy(dtype=float)

fit_y = sm.WLS(earnings, design, weights=weights).fit()
fit_d = sm.WLS(participation, design, weights=weights).fit()
reduced_form = float(fit_y.params[1])
first_stage = float(fit_d.params[1])
treatment_effect = reduced_form / first_stage

# HC0 joint sandwich: the same design and weights apply to both outcomes.
bread = np.linalg.inv(design.T @ (weights[:, None] * design))
influence_y = (weights * fit_y.resid)[:, None] * design @ bread[:, 1]
influence_d = (weights * fit_d.resid)[:, None] * design @ bread[:, 1]
joint_cov = np.array(
    [[influence_y @ influence_y, influence_y @ influence_d],
     [influence_d @ influence_y, influence_d @ influence_d]]
)
gradient = np.array([1 / first_stage, -reduced_form / first_stage**2])
se_effect = float(np.sqrt(gradient @ joint_cov @ gradient))

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": treatment_effect, "se": se_effect, "n_obs": len(sample)},
        {"term": "reduced_form", "estimate": reduced_form, "se": float(np.sqrt(joint_cov[0, 0])), "n_obs": len(sample)},
        {"term": "first_stage", "estimate": first_stage, "se": float(np.sqrt(joint_cov[1, 1])), "n_obs": len(sample)},
    ],
    "method_metadata": {
        "estimator": "Fuzzy RD Wald ratio; local linear on each side; triangular weights; bandwidth 1",
        "vcov": "Conventional fixed-bandwidth HC0 sandwich; joint outcome-treatment covariance; delta method",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output, indent=2, allow_nan=False)
