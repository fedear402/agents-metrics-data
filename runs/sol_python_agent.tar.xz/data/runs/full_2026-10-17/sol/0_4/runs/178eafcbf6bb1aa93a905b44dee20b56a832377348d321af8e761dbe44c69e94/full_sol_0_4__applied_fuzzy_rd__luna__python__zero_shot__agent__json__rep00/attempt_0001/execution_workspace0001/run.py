import json

import numpy as np
import pandas as pd


data = pd.read_csv("input.csv")
sample = data.loc[data["score"].abs() < 1].copy()
x = sample["score"].to_numpy(dtype=float)
w = 1 - np.abs(x)
right = (x >= 0).astype(float)
# Left intercept and slope, followed by the right intercept and slope.
design = np.column_stack((1 - right, x * (1 - right), right, x * right))
outcomes = sample[["earnings", "participated"]].to_numpy(dtype=float)

bread = design.T @ (w[:, None] * design)
coefficients = np.linalg.solve(bread, design.T @ (w[:, None] * outcomes))
residuals = outcomes - design @ coefficients
contrast = np.array([-1.0, 0.0, 1.0, 0.0])
influence_multiplier = w * (design @ np.linalg.solve(bread, contrast))
influence = influence_multiplier[:, None] * residuals
joint_covariance = influence.T @ influence
discontinuities = contrast @ coefficients
reduced_form, first_stage = discontinuities
treatment_effect = reduced_form / first_stage
gradient = np.array([1 / first_stage, -reduced_form / first_stage**2])
effect_variance = gradient @ joint_covariance @ gradient
n_obs = int(len(sample))

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": float(treatment_effect),
         "se": float(np.sqrt(effect_variance)), "n_obs": n_obs},
        {"term": "reduced_form", "estimate": float(reduced_form),
         "se": float(np.sqrt(joint_covariance[0, 0])), "n_obs": n_obs},
        {"term": "first_stage", "estimate": float(first_stage),
         "se": float(np.sqrt(joint_covariance[1, 1])), "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "Fuzzy RD Wald ratio; separate weighted local-linear fits by side; bandwidth 1; triangular kernel",
        "vcov": "Fixed-bandwidth HC0 sandwich; joint outcome covariance; delta method for ratio",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output, indent=2, allow_nan=False)
    output.write("\n")
