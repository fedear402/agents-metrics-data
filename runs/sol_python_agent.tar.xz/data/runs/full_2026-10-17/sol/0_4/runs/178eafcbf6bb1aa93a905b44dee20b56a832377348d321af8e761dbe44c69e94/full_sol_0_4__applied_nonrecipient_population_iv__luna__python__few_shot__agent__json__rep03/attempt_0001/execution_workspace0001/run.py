import json

import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS


households = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")
sample = households.loc[households["recipient"] == 0].copy()
assert set(sample["eligible"].unique()) == {0, 1}
assert (sample["weight"] > 0).all()
assert set(census["eligible"]) == {0, 1}

ineligible = 1 - sample["eligible"]
eligible = sample["eligible"]
exog = pd.DataFrame({
    "ineligible": ineligible,
    "eligible": eligible,
    "baseline_ineligible": sample["baseline"] * ineligible,
    "baseline_eligible": sample["baseline"] * eligible,
}, index=sample.index)
endog = pd.DataFrame({
    "dose_ineligible": sample["dose"] * ineligible,
    "dose_eligible": sample["dose"] * eligible,
}, index=sample.index)
excluded = pd.DataFrame({
    "instrument_ineligible": sample["instrument"] * ineligible,
    "instrument_eligible": sample["instrument"] * eligible,
}, index=sample.index)

fit = IV2SLS(sample["outcome"], exog, endog, excluded,
            weights=sample["weight"]).fit()
effects = {}
group_details = {}
for group, term, name in [
    (0, "dose_ineligible", "ineligible_effect"),
    (1, "dose_eligible", "eligible_nonrecipient_effect"),
]:
    rows = sample.loc[sample["eligible"] == group]
    mean_dose = float(np.average(rows["dose"], weights=rows["weight"]))
    effects[name] = float(fit.params[term] * mean_dose)
    group_details[str(group)] = {
        "slope": float(fit.params[term]),
        "weighted_mean_dose": mean_dose,
        "sample_rows": int(len(rows)),
        "treated_statuses": sorted(int(x) for x in rows["treated"].unique()),
    }

pop = census.set_index("eligible")["nonrecipient_population"]
population_effect = float(np.average(
    [effects["ineligible_effect"], effects["eligible_nonrecipient_effect"]],
    weights=[pop.loc[0], pop.loc[1]],
))
n_obs = int(len(sample))
result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {"term": term, "estimate": value, "se": None, "n_obs": n_obs}
        for term, value in [
            ("ineligible_effect", effects["ineligible_effect"]),
            ("eligible_nonrecipient_effect", effects["eligible_nonrecipient_effect"]),
            ("population_effect", population_effect),
        ]
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "sample": "recipient == 0, all village treatment statuses",
        "exogenous": list(exog.columns),
        "endogenous": list(endog.columns),
        "excluded_instruments": list(excluded.columns),
        "intercept": "group indicators only; no other intercept",
        "regression_weight": "weight",
        "within_group_dose_mean_weight": "weight",
        "aggregation_weight": "nonrecipient_population",
        "counterfactual": "dose = 0 for every retained household; synthetic attribution convention",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "group_details": group_details,
        "nonrecipient_population": {str(k): int(v) for k, v in pop.items()},
    },
}
with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file, indent=2, allow_nan=False)
    file.write("\n")
