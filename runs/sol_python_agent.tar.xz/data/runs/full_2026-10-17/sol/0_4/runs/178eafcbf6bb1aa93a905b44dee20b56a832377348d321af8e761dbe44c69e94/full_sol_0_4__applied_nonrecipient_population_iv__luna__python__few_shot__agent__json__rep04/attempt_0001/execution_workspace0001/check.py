import json
import numpy as np
import pandas as pd

h = pd.read_csv('households.csv')
c = pd.read_csv('census.csv').set_index('eligible')
r = json.load(open('result.json'))
s = h[h.recipient.eq(0)]
assert len(s) == 300
assert s.groupby('eligible').size().to_dict() == {0: 120, 1: 180}
assert s.groupby(['eligible', 'treated']).size().to_dict() == {(0, 0): 60, (0, 1): 60, (1, 0): 180}
computed = {}
for g in (0, 1):
    q = s[s.eligible.eq(g)]
    X = np.column_stack([np.ones(len(q)), q.baseline.to_numpy(), q.dose.to_numpy()])
    Z = np.column_stack([np.ones(len(q)), q.baseline.to_numpy(), q.instrument.to_numpy()])
    W = q.weight.to_numpy()
    beta = np.linalg.solve(Z.T @ (W[:, None] * X), Z.T @ (W * q.outcome.to_numpy()))
    assert np.max(np.abs(Z.T @ (W * (q.outcome.to_numpy() - X @ beta)))) < 1e-9
    computed[g] = float(beta[2] * np.average(q.dose, weights=W))
expected = [computed[0], computed[1], (8400 * computed[0] + 1600 * computed[1]) / 10000]
actual = [x['estimate'] for x in r['estimates']]
assert np.allclose(expected, actual, rtol=0, atol=1e-11), (expected, actual)
assert all(x['n_obs'] == 300 and x['se'] is None for x in r['estimates'])
print('Independent weighted IV moment calculation:', expected)
print('Result estimates:', actual)
print('Maximum absolute difference:', max(abs(a-b) for a,b in zip(actual, expected)))
