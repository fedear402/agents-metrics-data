import csv
import json

import numpy as np


with open('households.csv', newline='') as file:
    rows = [row for row in csv.DictReader(file) if int(row['recipient']) == 0]
with open('census.csv', newline='') as file:
    population = {int(row['eligible']): int(row['nonrecipient_population']) for row in csv.DictReader(file)}

eligible = np.array([int(row['eligible']) for row in rows])
ineligible = 1 - eligible
dose = np.array([float(row['dose']) for row in rows])
baseline = np.array([float(row['baseline']) for row in rows])
instrument = np.array([float(row['instrument']) for row in rows])
weight = np.array([float(row['weight']) for row in rows])
outcome = np.array([float(row['outcome']) for row in rows])

exogenous = np.column_stack((ineligible, eligible, baseline * ineligible, baseline * eligible))
endogenous = np.column_stack((dose * ineligible, dose * eligible))
x = np.column_stack((exogenous, endogenous))
z = np.column_stack((exogenous, instrument * ineligible, instrument * eligible))

# The model is exactly identified. These are the weighted IV moment equations.
coefficient = np.linalg.solve(z.T @ (weight[:, None] * x), z.T @ (weight * outcome))
mean_dose = {
    group: np.average(dose[eligible == group], weights=weight[eligible == group])
    for group in (0, 1)
}
effects = {group: float(coefficient[4 + group] * mean_dose[group]) for group in (0, 1)}
population_effect = sum(population[group] * effects[group] for group in (0, 1)) / sum(population.values())

terms = (
    ('ineligible_effect', effects[0]),
    ('eligible_nonrecipient_effect', effects[1]),
    ('population_effect', population_effect),
)
result = {
    'task_id': 'applied_nonrecipient_population_iv',
    'platform': 'python',
    'estimates': [
        {'term': term, 'estimate': value, 'se': None, 'n_obs': len(rows)}
        for term, value in terms
    ],
    'method_metadata': {
        'estimator': 'weighted exactly identified 2SLS',
        'sample': 'recipient=0, all village treatment statuses',
        'counterfactual': 'dose=0 for all retained households; synthetic attribution convention',
        'group_effect': 'fitted group dose slope times household-weighted group mean dose',
        'population_aggregation': 'nonrecipient_population census counts used only between groups',
    },
    'diagnostics': {
        'n_obs': len(rows),
        'group_n_obs': {str(group): int(np.sum(eligible == group)) for group in (0, 1)},
        'group_weighted_mean_dose': {str(group): mean_dose[group] for group in (0, 1)},
        'dose_slopes': {str(group): float(coefficient[4 + group]) for group in (0, 1)},
        'census_nonrecipient_population': {str(group): population[group] for group in (0, 1)},
        'weighted_moment_max_abs': float(np.max(np.abs(z.T @ (weight * (outcome - x @ coefficient))))),
    },
}
with open('result.json', 'w') as file:
    json.dump(result, file, indent=2)
    file.write('\n')
