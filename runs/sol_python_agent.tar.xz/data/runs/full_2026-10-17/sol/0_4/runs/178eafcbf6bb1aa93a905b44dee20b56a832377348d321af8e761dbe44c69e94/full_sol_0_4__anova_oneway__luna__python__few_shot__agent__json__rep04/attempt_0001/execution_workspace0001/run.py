import json

import pandas as pd
from scipy import stats


data = pd.read_csv("input.csv")
sample = data[["group", "y"]].copy()
sample["y"] = pd.to_numeric(sample["y"], errors="raise")
sample = sample.dropna(subset=["group", "y"])

groups = [part["y"].to_numpy() for _, part in sample.groupby("group")]
n_obs = len(sample)
n_groups = len(groups)
if n_groups < 2 or n_obs <= n_groups:
    raise ValueError("ANOVA requires at least two groups and positive residual degrees of freedom")

f_stat, p_value = stats.f_oneway(*groups)
values = {
    "F": float(f_stat),
    "df_num": float(n_groups - 1),
    "df_den": float(n_obs - n_groups),
    "p_value": float(p_value),
}
result = {
    "task_id": "anova_oneway",
    "platform": "python",
    "estimates": [
        {"term": term, "estimate": value, "se": None, "n_obs": n_obs}
        for term, value in values.items()
    ],
    "method_metadata": {"estimator": "Classical one-way ANOVA", "vcov": "pooled within-group variance"},
    "diagnostics": {},
}
with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output, indent=2)
