import json

import numpy as np
import pandas as pd


data = pd.read_csv("input.csv")
required = ["score", "participated", "earnings"]
if data[required].isna().any().any():
    raise ValueError("Required variables contain missing values")

sample = data.loc[data["score"].abs() < 1].copy()
score = sample["score"].to_numpy(dtype=float)
right = (score >= 0).astype(float)
weight = 1 - np.abs(score)
x = np.column_stack((np.ones(len(sample)), right, score, right * score))
y = sample[["earnings", "participated"]].to_numpy(dtype=float)

bread = np.linalg.inv(x.T @ (weight[:, None] * x))
beta = bread @ (x.T @ (weight[:, None] * y))
residual = y - x @ beta

# Each row of influence contains both discontinuity contributions from one applicant.
influence = (weight * (x @ bread[:, 1]))[:, None] * residual
joint_covariance = influence.T @ influence
reduced_form, first_stage = beta[1]
treatment_effect = reduced_form / first_stage
gradient = np.array([1 / first_stage, -reduced_form / first_stage**2])
effect_variance = gradient @ joint_covariance @ gradient

n_obs = int(len(sample))
result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": float(treatment_effect), "se": float(np.sqrt(effect_variance)), "n_obs": n_obs},
        {"term": "reduced_form", "estimate": float(reduced_form), "se": float(np.sqrt(joint_covariance[0, 0])), "n_obs": n_obs},
        {"term": "first_stage", "estimate": float(first_stage), "se": float(np.sqrt(joint_covariance[1, 1])), "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "Fuzzy RD ratio of right-minus-left local-linear intercept discontinuities; cutoff 0, bandwidth 1, triangular weights",
        "vcov": "HC0 joint sandwich covariance with fixed bandwidth and weights; delta method for ratio",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output, indent=2)
