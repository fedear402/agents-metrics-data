import json

import numpy as np
import pandas as pd
from statsmodels.tsa.arima.model import ARIMA


data = pd.read_csv("input.csv")
if list(data.columns) != ["t", "y"]:
    raise ValueError("Expected columns t and y")
if data[["t", "y"]].isna().any().any():
    raise ValueError("Missing observations")
if not np.array_equal(data["t"].to_numpy(), np.arange(1, len(data) + 1)):
    raise ValueError("Expected consecutive time labels starting at 1")
if len(data) != 250:
    raise ValueError("Expected observations through t = 250")

levels = data["y"].astype(float).to_numpy()
fit = ARIMA(levels, order=(1, 1, 1), trend="n").fit()
prediction = fit.get_forecast(steps=1)
forecast = float(prediction.predicted_mean[0])
forecast_se = float(prediction.se_mean[0])
interval = prediction.conf_int(alpha=0.05)[0]

output = {
    "task_id": "arima_forecast",
    "platform": "python",
    "estimates": [
        {"term": "forecast", "estimate": forecast, "se": forecast_se, "n_obs": len(levels)},
        {"term": "lower_95", "estimate": float(interval[0]), "se": None, "n_obs": len(levels)},
        {"term": "upper_95", "estimate": float(interval[1]), "se": None, "n_obs": len(levels)},
    ],
    "method_metadata": {
        "estimator": "ARIMA(1,1,1) maximum likelihood, no constant or drift",
        "vcov": "Gaussian one-step forecast variance; normal 95% prediction interval",
    },
    "diagnostics": {},
}
with open("result.json", "w") as file:
    json.dump(output, file, indent=2)
