import json
from pathlib import Path

import numpy as np
import pandas as pd


root = Path(__file__).resolve().parent
crosswalk = pd.read_csv(root / "crosswalk.csv")
trade = pd.read_csv(root / "trade.csv")
areas = pd.read_csv(root / "areas.csv")
employment = pd.read_csv(root / "employment.csv")
outcomes = pd.read_csv(root / "outcomes.csv")

assert crosswalk["code"].is_unique
assert crosswalk["industry"].nunique() == 4
assert not trade.duplicated(["period", "code"]).any()
assert not areas.duplicated(["area", "period", "vintage"]).any()
assert not employment.duplicated(["area", "period", "vintage", "industry"]).any()
assert not outcomes.duplicated(["area", "period"]).any()

trade = trade.merge(crosswalk, on="code", validate="many_to_one")
assert not trade[["period", "industry"]].duplicated().any()
assert trade.groupby("period")["industry"].nunique().eq(4).all()
assert trade.groupby("period")[["price_index", "years"]].nunique().eq(1).all().all()

grid = areas[["area", "period", "vintage"]].merge(
    crosswalk[["industry"]].drop_duplicates(), how="cross"
)
cells = grid.merge(
    employment, on=["area", "period", "vintage", "industry"], how="left", validate="one_to_one"
)
assert len(cells) == len(grid)
cells["employment"] = cells["employment"].fillna(0)
national = cells.groupby(["period", "vintage", "industry"], as_index=False)["employment"].sum()
national = national.rename(columns={"employment": "national_employment"})
assert national["national_employment"].gt(0).all()
cells = cells.merge(areas, on=["area", "period", "vintage"], validate="many_to_one")
cells = cells.merge(national, on=["period", "vintage", "industry"], validate="many_to_one")
cells = cells.merge(trade, on=["period", "industry"], validate="many_to_one")
assert cells[["total_employment", "price_index", "years"]].gt(0).all().all()
change = np.where(cells["vintage"].eq("base"), cells["us_change"], cells["other_change"])
cells["contribution"] = (
    cells["employment"] / cells["total_employment"]
    * change / cells["national_employment"]
    / (cells["price_index"] / 100)
    / 1000 * (10 / cells["years"])
)
exposures = cells.groupby(["area", "period", "vintage"], as_index=False)["contribution"].sum()
exposures = exposures.pivot(index=["area", "period"], columns="vintage", values="contribution")
exposures = exposures.rename(columns={"base": "x", "early": "z"}).reset_index()
base_areas = areas.loc[areas["vintage"].eq("base"), ["area", "period", "population"]]
sample = outcomes.merge(exposures, on=["area", "period"], validate="one_to_one")
sample = sample.merge(base_areas, on=["area", "period"], validate="one_to_one")
assert len(sample) == len(outcomes) == 72
assert sample[["change_pp", "period", "control", "x", "z", "population"]].notna().all().all()
assert sample["population"].gt(0).all()

y = sample["change_pp"].to_numpy(float)
x = np.column_stack((np.ones(len(sample)), sample[["period", "control", "x"]].to_numpy(float)))
z = np.column_stack((np.ones(len(sample)), sample[["period", "control", "z"]].to_numpy(float)))
w = sample["population"].to_numpy(float)
zwz = z.T @ (w[:, None] * z)
zwy = z.T @ (w * y)
zwx = z.T @ (w[:, None] * x)
beta = np.linalg.solve(zwx, zwy)
assert np.linalg.matrix_rank(zwz) == 4

# Independent weighted Frisch-Waugh-Lovell calculation for the one endogenous slope.
controls = x[:, :3]
wx = np.sqrt(w)
cw = controls * wx[:, None]
def residual(v):
    return v - controls @ np.linalg.lstsq(cw, wx * v, rcond=None)[0]

rx, rz, ry = (residual(v) for v in (sample["x"].to_numpy(float), sample["z"].to_numpy(float), y))
independent_slope = np.dot(w * rz, ry) / np.dot(w * rz, rx)
assert np.isclose(beta[3], independent_slope, rtol=1e-11, atol=1e-11)
moment_error = np.max(np.abs(z.T @ (w * (y - x @ beta))))
assert moment_error < 1e-5

def get_exposure(area, period, field):
    row = sample.loc[sample["area"].eq(area) & sample["period"].eq(period)]
    assert len(row) == 1
    return float(row[field].iloc[0])

values = {
    "iv_slope": float(beta[3]),
    "exposure_area0_period0": get_exposure(0, 0, "x"),
    "exposure_area0_period1": get_exposure(0, 1, "x"),
    "instrument_area0_period0": get_exposure(0, 0, "z"),
}
result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [
        {"term": term, "estimate": value, "se": None, "n_obs": 72}
        for term, value in values.items()
    ],
    "method_metadata": {
        "estimator": "population-weighted 2SLS",
        "regressors": ["intercept", "period", "control", "x"],
        "instruments": ["intercept", "period", "control", "z"],
        "weight": "base-vintage population",
        "missing_employment": "zero",
    },
    "diagnostics": {
        "sample_rows": len(sample),
        "industry_count": int(crosswalk["industry"].nunique()),
        "independent_slope": float(independent_slope),
        "maximum_weighted_moment_error": float(moment_error),
    },
}
with (root / "result.json").open("w") as f:
    json.dump(result, f, indent=2, allow_nan=False)
    f.write("\n")
with (root / "verification.txt").open("w") as f:
    f.write("Sample: 72 area-period rows, all outcome rows, with positive base population.\n")
    f.write("Construction: four industries per area-period-vintage; omitted employment set to zero.\n")
    f.write("National denominators sum employment across supplied areas by period, vintage, and industry.\n")
    f.write("Weighted 2SLS: intercept, period, and control enter both regressor and instrument matrices.\n")
    f.write(f"Independent residualized IV slope: {independent_slope:.15g}; matrix IV slope: {beta[3]:.15g}.\n")
    f.write(f"Maximum absolute weighted instrument moment: {moment_error:.9g}.\n")
    f.write("Uncertainty measures were not requested; estimate se fields are null.\n")
