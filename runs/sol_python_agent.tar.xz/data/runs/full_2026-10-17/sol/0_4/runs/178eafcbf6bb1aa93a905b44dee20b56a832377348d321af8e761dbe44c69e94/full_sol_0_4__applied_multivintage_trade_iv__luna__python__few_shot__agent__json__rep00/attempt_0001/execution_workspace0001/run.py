import json

import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS


crosswalk = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv").merge(crosswalk, on="code", validate="many_to_one")
areas = pd.read_csv("areas.csv")
employment = pd.read_csv("employment.csv")
outcomes = pd.read_csv("outcomes.csv")

assert crosswalk["code"].is_unique and crosswalk["industry"].nunique() == 4
assert trade.groupby(["period", "industry"]).size().eq(1).all()
assert areas.groupby(["area", "period", "vintage"]).size().eq(1).all()

grid = areas[["area", "period", "vintage"]].merge(
    crosswalk[["industry"]].drop_duplicates(), how="cross"
)
cells = grid.merge(
    employment, on=["area", "period", "vintage", "industry"], how="left", validate="one_to_one"
)
cells["employment"] = cells["employment"].fillna(0)
national = cells.groupby(["period", "vintage", "industry"])["employment"].sum().rename("national")
cells = cells.join(national, on=["period", "vintage", "industry"])
assert cells["national"].gt(0).all()
cells = cells.merge(areas, on=["area", "period", "vintage"], validate="many_to_one")
cells = cells.merge(trade, on=["period", "industry"], validate="many_to_one")
change = np.where(cells["vintage"].eq("base"), cells["us_change"], cells["other_change"])
cells["contribution"] = (
    cells["employment"] / cells["total_employment"]
    * change / cells["national"]
    / (cells["price_index"] / 100)
    / 1000
    * (10 / cells["years"])
)
exposures = cells.groupby(["area", "period", "vintage"], as_index=False)["contribution"].sum()
wide = exposures.pivot(index=["area", "period"], columns="vintage", values="contribution")
wide = wide.rename(columns={"base": "x", "early": "z"}).reset_index()
base_areas = areas.loc[areas["vintage"].eq("base"), ["area", "period", "population"]]
sample = outcomes.merge(wide, on=["area", "period"], validate="one_to_one").merge(
    base_areas, on=["area", "period"], validate="one_to_one"
)
assert len(sample) == 72 and sample[["change_pp", "control", "x", "z", "population"]].notna().all().all()
sample = sample.sort_values(["period", "area"]).reset_index(drop=True)
exog = pd.DataFrame({"intercept": 1.0, "period": sample["period"], "control": sample["control"]})
fit = IV2SLS(sample["change_pp"], exog, sample[["x"]], sample[["z"]], weights=sample["population"]).fit()

# Independent weighted IV normal-equation calculation with all exogenous columns as instruments.
X = np.column_stack([np.ones(len(sample)), sample["period"], sample["control"], sample["x"]])
Z = np.column_stack([np.ones(len(sample)), sample["period"], sample["control"], sample["z"]])
w = sample["population"].to_numpy()
y = sample["change_pp"].to_numpy()
manual = np.linalg.solve(Z.T @ (w[:, None] * X), Z.T @ (w * y))
assert np.isclose(manual[-1], fit.params["x"], rtol=1e-11, atol=1e-11)

def value(area, period, column):
    return float(sample.loc[sample["area"].eq(area) & sample["period"].eq(period), column].iloc[0])

estimates = [
    ("iv_slope", float(fit.params["x"])),
    ("exposure_area0_period0", value(0, 0, "x")),
    ("exposure_area0_period1", value(0, 1, "x")),
    ("instrument_area0_period0", value(0, 0, "z")),
]
result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [{"term": term, "estimate": estimate, "se": None, "n_obs": len(sample)} for term, estimate in estimates],
    "method_metadata": {"estimator": "weighted 2SLS", "endogenous": "x", "excluded_instrument": "z", "exogenous": ["intercept", "period", "control"], "weight": "base-vintage population"},
    "diagnostics": {"estimation_rows": len(sample), "manual_iv_slope": float(manual[-1]), "absolute_iv_difference": float(abs(manual[-1] - fit.params["x"]))},
}
with open("result.json", "w") as handle:
    json.dump(result, handle, indent=2)
    handle.write("\n")

with open("verification.txt", "w") as handle:
    handle.write("All five requested CSV files were read. Missing employment cells were filled with zero.\n")
    handle.write(f"The estimation sample has {len(sample)} area-period rows. All model fields are present.\n")
    handle.write("National employment sums use all supplied areas within period, vintage, and industry.\n")
    handle.write("The weighted IV normal equations use intercept, period, control, and z as instruments.\n")
    handle.write(f"Independent matrix IV slope: {manual[-1]:.15g}. Package slope: {fit.params['x']:.15g}.\n")
    handle.write(f"Absolute difference: {abs(manual[-1] - fit.params['x']):.3g}. Standard errors were not requested and are null.\n")
