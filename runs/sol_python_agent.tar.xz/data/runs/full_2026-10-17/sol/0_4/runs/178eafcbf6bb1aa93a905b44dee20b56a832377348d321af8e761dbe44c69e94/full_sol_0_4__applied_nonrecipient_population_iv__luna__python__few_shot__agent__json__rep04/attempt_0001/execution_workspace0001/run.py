import json

import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS

households = pd.read_csv('households.csv')
census = pd.read_csv('census.csv')
sample = households.loc[households['recipient'].eq(0)].copy()
assert set(sample['eligible'].unique()) == {0, 1}
assert set(census['eligible']) == {0, 1}
assert sample[['dose', 'instrument', 'baseline', 'outcome', 'weight']].notna().all().all()
assert (sample['weight'] > 0).all()

g0 = 1 - sample['eligible']
g1 = sample['eligible']
x = pd.DataFrame({
    'ineligible': g0,
    'eligible': g1,
    'baseline_ineligible': sample['baseline'] * g0,
    'baseline_eligible': sample['baseline'] * g1,
}, index=sample.index)
endog = pd.DataFrame({
    'dose_ineligible': sample['dose'] * g0,
    'dose_eligible': sample['dose'] * g1,
}, index=sample.index)
excluded = pd.DataFrame({
    'instrument_ineligible': sample['instrument'] * g0,
    'instrument_eligible': sample['instrument'] * g1,
}, index=sample.index)
fit = IV2SLS(sample['outcome'], x, endog, excluded, weights=sample['weight']).fit()

slopes = {0: float(fit.params['dose_ineligible']), 1: float(fit.params['dose_eligible'])}
mean_dose = {
    group: float(np.average(h['dose'], weights=h['weight']))
    for group in (0, 1)
    for h in [sample.loc[sample['eligible'].eq(group)]]
}
effects = {group: slopes[group] * mean_dose[group] for group in (0, 1)}
population = census.set_index('eligible')['nonrecipient_population']
population_effect = float(np.average([effects[0], effects[1]], weights=[population.loc[0], population.loc[1]]))
n_obs = int(len(sample))
result = {
    'task_id': 'applied_nonrecipient_population_iv',
    'platform': 'python',
    'estimates': [
        {'term': 'ineligible_effect', 'estimate': effects[0], 'se': None, 'n_obs': n_obs},
        {'term': 'eligible_nonrecipient_effect', 'estimate': effects[1], 'se': None, 'n_obs': n_obs},
        {'term': 'population_effect', 'estimate': population_effect, 'se': None, 'n_obs': n_obs},
    ],
    'method_metadata': {
        'estimator': 'weighted 2SLS',
        'sample': 'recipient == 0, including both village treatment statuses',
        'exogenous': list(x.columns),
        'endogenous': list(endog.columns),
        'excluded_instruments': list(excluded.columns),
        'intercept': 'group indicators only; no additional intercept',
        'counterfactual': 'dose set to zero for every retained household (synthetic convention)',
        'within_group_aggregation': 'dose slope times household-weighted mean dose',
        'between_group_aggregation': 'census nonrecipient_population only',
    },
    'diagnostics': {
        'n_obs': n_obs,
        'group_n_obs': {str(group): int(sample['eligible'].eq(group).sum()) for group in (0, 1)},
        'treated_counts': {str(group): int((sample['eligible'].eq(group) & sample['treated'].eq(1)).sum()) for group in (0, 1)},
        'dose_slopes': {str(k): v for k, v in slopes.items()},
        'weighted_mean_dose': {str(k): v for k, v in mean_dose.items()},
        'census_nonrecipient_population': {str(k): int(population.loc[k]) for k in (0, 1)},
    },
}
with open('result.json', 'w') as handle:
    json.dump(result, handle, indent=2, allow_nan=False)
