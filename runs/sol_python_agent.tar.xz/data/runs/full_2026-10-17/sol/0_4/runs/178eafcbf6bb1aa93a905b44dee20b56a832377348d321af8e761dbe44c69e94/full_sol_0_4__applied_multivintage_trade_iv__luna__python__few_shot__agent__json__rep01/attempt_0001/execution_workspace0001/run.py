import json
import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS

crosswalk = pd.read_csv('crosswalk.csv')
trade = pd.read_csv('trade.csv').merge(crosswalk, on='code', validate='many_to_one')
areas = pd.read_csv('areas.csv')
employment = pd.read_csv('employment.csv')
outcomes = pd.read_csv('outcomes.csv')

assert crosswalk.code.is_unique
assert trade.groupby(['period', 'industry']).size().eq(1).all()
assert trade.groupby('period')[['price_index', 'years']].nunique().eq(1).all().all()
assert areas.groupby(['area', 'period', 'vintage']).size().eq(1).all()
assert employment.groupby(['area', 'period', 'vintage', 'industry']).size().eq(1).all()
assert outcomes.groupby(['area', 'period']).size().eq(1).all()
assert set(areas.vintage) == {'base', 'early'}

industries = crosswalk[['industry']].drop_duplicates()
cells = areas[['area', 'period', 'vintage']].merge(industries, how='cross')
missing_cell_count = int(cells.merge(employment, on=['area', 'period', 'vintage', 'industry'], how='left').employment.isna().sum())
cells = cells.merge(employment, on=['area', 'period', 'vintage', 'industry'], how='left', validate='one_to_one')
cells['employment'] = cells.employment.fillna(0)
cells = cells.merge(areas, on=['area', 'period', 'vintage'], validate='many_to_one')
national = cells.groupby(['period', 'vintage', 'industry']).employment.transform('sum')
assert (national > 0).all()
cells = cells.merge(trade[['period', 'industry', 'us_change', 'other_change', 'price_index', 'years']], on=['period', 'industry'], validate='many_to_one')
change = np.where(cells.vintage.eq('base'), cells.us_change, cells.other_change)
cells['contribution'] = (cells.employment / cells.total_employment * change / national
                         / (cells.price_index / 100) / 1000 * (10 / cells.years))
exposures = cells.groupby(['area', 'period', 'vintage'], as_index=False).contribution.sum()
wide = exposures.pivot(index=['area', 'period'], columns='vintage', values='contribution').reset_index()
wide = wide.rename(columns={'base': 'x', 'early': 'z'})
base_areas = areas.loc[areas.vintage.eq('base'), ['area', 'period', 'population']]
sample = outcomes.merge(wide, on=['area', 'period'], validate='one_to_one')
sample = sample.merge(base_areas, on=['area', 'period'], validate='one_to_one').sort_values(['period', 'area'])
assert len(sample) == 72 and sample[['change_pp', 'period', 'control', 'x', 'z', 'population']].notna().all().all()
assert (sample.population > 0).all()
exog = pd.DataFrame({'intercept': 1.0, 'period': sample.period.to_numpy(), 'control': sample.control.to_numpy()}, index=sample.index)
fit = IV2SLS(sample.change_pp, exog, sample[['x']], sample[['z']], weights=sample.population).fit()

values = {
    'iv_slope': float(fit.params['x']),
    'exposure_area0_period0': float(sample.set_index(['area', 'period']).loc[(0, 0), 'x']),
    'exposure_area0_period1': float(sample.set_index(['area', 'period']).loc[(0, 1), 'x']),
    'instrument_area0_period0': float(sample.set_index(['area', 'period']).loc[(0, 0), 'z']),
}
result = {
    'task_id': 'applied_multivintage_trade_iv',
    'platform': 'python',
    'estimates': [{'term': term, 'estimate': value, 'se': None, 'n_obs': 72} for term, value in values.items()],
    'method_metadata': {
        'estimator': 'weighted 2SLS',
        'outcome': 'change_pp',
        'endogenous': 'x',
        'excluded_instrument': 'z',
        'exogenous_instruments': ['intercept', 'period', 'control'],
        'weight': 'base-vintage population',
        'exposure_unit': 'thousands of real dollars per worker per decade',
    },
    'diagnostics': {
        'estimation_rows': len(sample),
        'areas': int(sample.area.nunique()),
        'periods': int(sample.period.nunique()),
        'industries': int(crosswalk.industry.nunique()),
        'missing_employment_cells_filled_with_zero': missing_cell_count,
    },
}
with open('result.json', 'w') as file:
    json.dump(result, file, indent=2, allow_nan=False)
print(json.dumps(result, indent=2))
