import json

import numpy as np
import pandas as pd


data = pd.read_csv("input.csv")
sample = data.loc[data["score"].abs() < 1].copy()
score = sample["score"].to_numpy(dtype=float)
right = (score >= 0).astype(float)
weight = 1 - np.abs(score)
X = np.column_stack((np.ones(len(score)), right, score, right * score))
Y = sample[["earnings", "participated"]].to_numpy(dtype=float)

# The right-minus-left intercept difference is the coefficient on right.
bread = np.linalg.inv(X.T @ (weight[:, None] * X))
beta = bread @ X.T @ (weight[:, None] * Y)
residual = Y - X @ beta
contrast = np.array([0.0, 1.0, 0.0, 0.0])
jumps = contrast @ beta
loading = weight * (X @ bread @ contrast)
influence = loading[:, None] * residual
joint_covariance = influence.T @ influence

reduced_form, first_stage = jumps
if first_stage == 0:
    raise ValueError("First-stage discontinuity is zero")
effect = reduced_form / first_stage
gradient = np.array([1 / first_stage, -reduced_form / first_stage**2])
effect_variance = gradient @ joint_covariance @ gradient
n_obs = int(len(sample))

rows = [
    {"term": "treatment_effect", "estimate": float(effect),
     "se": float(np.sqrt(effect_variance)), "n_obs": n_obs},
    {"term": "reduced_form", "estimate": float(reduced_form),
     "se": float(np.sqrt(joint_covariance[0, 0])), "n_obs": n_obs},
    {"term": "first_stage", "estimate": float(first_stage),
     "se": float(np.sqrt(joint_covariance[1, 1])), "n_obs": n_obs},
]
output = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": rows,
    "method_metadata": {
        "estimator": "Triangular-weighted local linear fuzzy RD, separate slopes by side, bandwidth 1",
        "vcov": "Fixed-weight HC0 joint sandwich; delta method for ratio",
    },
    "diagnostics": {},
}
with open("result.json", "w", encoding="utf-8") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
