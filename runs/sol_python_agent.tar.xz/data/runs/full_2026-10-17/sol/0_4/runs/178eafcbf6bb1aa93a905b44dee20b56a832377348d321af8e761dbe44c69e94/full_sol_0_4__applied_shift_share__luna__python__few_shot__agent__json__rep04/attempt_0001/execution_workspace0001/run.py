import json

import numpy as np
import pandas as pd


data = pd.read_csv("input.csv")
required = ["region_id", "industry_id", "share", "shock", "region_weight", "x", "y"]
assert list(data.columns) == required
assert data[required].notna().all().all()
assert not data.duplicated(["region_id", "industry_id"]).any()
for variable in ["region_weight", "x", "y"]:
    assert data.groupby("region_id")[variable].nunique().eq(1).all()
assert data.groupby("industry_id").shock.nunique().eq(1).all()

shares = data.pivot(index="region_id", columns="industry_id", values="share")
assert not shares.isna().any().any()
assert np.allclose(shares.sum(axis=1), 1, atol=1e-12)
regions = data.drop_duplicates("region_id").set_index("region_id").loc[shares.index]
shocks = data.drop_duplicates("industry_id").set_index("industry_id").loc[shares.columns, "shock"].to_numpy()
S = shares.to_numpy()
e = regions.region_weight.to_numpy(dtype=float).copy()
assert np.all(e > 0)
e /= e.sum()
x = regions.x.to_numpy(dtype=float)
y = regions.y.to_numpy(dtype=float)
z = S @ shocks
regional = np.column_stack((y, x, z))
centered = regional - e @ regional
mass = e @ S
assert np.all(mass > 0)
aggregated = (S.T @ (e[:, None] * centered)) / mass[:, None]
N = len(shocks)
assert N > 2


def shock_iv(dependent, endogenous):
    regressors = np.column_stack((np.ones(N), endogenous))
    instruments = np.column_stack((np.ones(N), shocks))
    cross = instruments.T @ (mass[:, None] * regressors)
    coefficient = np.linalg.solve(cross, instruments.T @ (mass * dependent))
    residual = dependent - regressors @ coefficient
    scores = instruments * (mass * residual)[:, None]
    inverse = np.linalg.inv(cross)
    covariance = (N / (N - 2)) * inverse @ (scores.T @ scores) @ inverse.T
    return float(coefficient[1]), float(np.sqrt(covariance[1, 1]))


effect, effect_se = shock_iv(aggregated[:, 0], aggregated[:, 1])
first_stage, first_stage_se = shock_iv(aggregated[:, 1], aggregated[:, 2])

# Independent regional moment calculations verify the shock-level slopes.
regional_effect = np.sum(e * centered[:, 2] * centered[:, 0]) / np.sum(e * centered[:, 2] * centered[:, 1])
regional_first_stage = np.sum(e * centered[:, 2] * centered[:, 1]) / np.sum(e * centered[:, 2] ** 2)
assert np.allclose([effect, first_stage], [regional_effect, regional_first_stage], rtol=1e-10)
assert np.allclose(mass @ aggregated, 0, atol=1e-12)
assert np.isclose(mass.sum(), 1)

output = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": effect, "se": effect_se, "n_obs": N},
        {"term": "first_stage", "estimate": first_stage, "se": first_stage_se, "n_obs": N},
        {"term": "effective_shocks", "estimate": float(1 / np.sum(mass ** 2)), "se": None, "n_obs": N},
    ],
    "method_metadata": {"estimator": "weighted regional 2SLS; equivalent shock-level weighted IV", "vcov": "shock-level heteroskedasticity-robust HC1, N/(N-2)"},
    "diagnostics": {},
}
with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)

with open("verification.txt", "w") as stream:
    stream.write(f"Input: {len(data)} region-industry rows, {len(e)} regions, {N} industries; complete region-industry grid and unique keys.\n")
    stream.write("Region variables and industry shocks are constant within their groups; regional shares sum to one.\n")
    stream.write(f"Normalized region weights sum to {e.sum():.16g}; industry exposure masses sum to {mass.sum():.16g}.\n")
    stream.write(f"Regional weighted moment effect: {regional_effect:.16g}; shock-level IV effect: {effect:.16g}.\n")
    stream.write(f"Regional weighted moment first stage: {regional_first_stage:.16g}; shock-level IV first stage: {first_stage:.16g}.\n")
    stream.write(f"Maximum absolute difference between slopes: {max(abs(effect-regional_effect), abs(first_stage-regional_first_stage)):.3g}.\n")
    stream.write("Shock-level SEs use structural IV residuals, squared analytic-weight instrument scores, and HC1 factor N/(N-2).\n")
