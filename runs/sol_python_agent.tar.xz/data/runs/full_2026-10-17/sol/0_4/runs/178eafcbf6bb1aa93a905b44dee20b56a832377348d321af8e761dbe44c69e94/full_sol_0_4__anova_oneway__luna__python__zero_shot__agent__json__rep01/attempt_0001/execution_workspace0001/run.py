import json

import pandas as pd
import statsmodels.api as sm
from statsmodels.formula.api import ols


data = pd.read_csv("input.csv", usecols=["group", "y"])
sample = data.dropna(subset=["group", "y"]).copy()
sample["y"] = pd.to_numeric(sample["y"], errors="raise")

model = ols("y ~ C(group)", data=sample).fit()
anova = sm.stats.anova_lm(model, typ=1)
term = anova.loc["C(group)"]
values = {
    "F": float(term["F"]),
    "df_num": float(term["df"]),
    "df_den": float(anova.loc["Residual", "df"]),
    "p_value": float(term["PR(>F)"]),
}

result = {
    "task_id": "anova_oneway",
    "platform": "python",
    "estimates": [
        {"term": name, "estimate": value, "se": None, "n_obs": int(model.nobs)}
        for name, value in values.items()
    ],
    "method_metadata": {"estimator": "OLS one-way ANOVA", "vcov": "classical pooled within-group variance"},
    "diagnostics": {},
}
with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output, indent=2)
