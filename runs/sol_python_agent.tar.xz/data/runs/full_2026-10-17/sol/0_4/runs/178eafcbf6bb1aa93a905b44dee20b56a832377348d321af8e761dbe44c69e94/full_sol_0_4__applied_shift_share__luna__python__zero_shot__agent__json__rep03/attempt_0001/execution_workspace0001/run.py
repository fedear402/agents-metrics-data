import json

import numpy as np
import pandas as pd


def weighted_iv(y, x, instrument, weight):
    design = np.column_stack((np.ones(len(x)), x))
    instruments = np.column_stack((np.ones(len(x)), instrument))
    zwx = instruments.T @ (weight[:, None] * design)
    zwy = instruments.T @ (weight * y)
    beta = np.linalg.solve(zwx, zwy)
    residual = y - design @ beta
    scores = instruments * (weight * residual)[:, None]
    meat = scores.T @ scores
    inverse = np.linalg.inv(zwx)
    variance = len(x) / (len(x) - 2) * inverse @ meat @ inverse.T
    return float(beta[1]), float(np.sqrt(variance[1, 1]))


data = pd.read_csv('input.csv')
required = ['region_id', 'industry_id', 'share', 'shock', 'region_weight', 'x', 'y']
assert data[required].notna().all().all()
assert not data.duplicated(['region_id', 'industry_id']).any()
assert (data['share'] >= 0).all()

regions = data.groupby('region_id', sort=True)
industries = data.groupby('industry_id', sort=True)
for column in ['region_weight', 'x', 'y']:
    assert regions[column].nunique().eq(1).all()
assert industries['shock'].nunique().eq(1).all()
assert np.allclose(regions['share'].sum().to_numpy(), 1, atol=1e-10)

regional = regions[['region_weight', 'x', 'y']].first()
regional['e'] = regional['region_weight'] / regional['region_weight'].sum()
assert (regional['e'] > 0).all()
regional['z'] = data.assign(exposure=data['share'] * data['shock']).groupby('region_id')['exposure'].sum()
for variable in ['y', 'x', 'z']:
    regional[variable + '0'] = regional[variable] - np.dot(regional['e'], regional[variable])

work = data[['region_id', 'industry_id', 'share']].merge(
    regional[['e', 'y0', 'x0', 'z0']], left_on='region_id', right_index=True,
    validate='many_to_one'
)
work['exposure_weight'] = work['e'] * work['share']
for variable in ['y0', 'x0', 'z0']:
    work[variable + '_numerator'] = work['exposure_weight'] * work[variable]
shock = industries['shock'].first().to_frame()
aggregates = work.groupby('industry_id')[
    ['exposure_weight', 'y0_numerator', 'x0_numerator', 'z0_numerator']
].sum()
shock = shock.join(aggregates)
shock = shock.loc[shock['exposure_weight'] > 0].copy()
shock['s'] = shock['exposure_weight']
for variable in ['y', 'x', 'z']:
    shock[variable + 'bar'] = shock[variable + '0_numerator'] / shock['s']

s = shock['s'].to_numpy()
n = len(shock)
effect, effect_se = weighted_iv(
    shock['ybar'].to_numpy(), shock['xbar'].to_numpy(),
    shock['shock'].to_numpy(), s
)
first_stage, first_stage_se = weighted_iv(
    shock['xbar'].to_numpy(), shock['zbar'].to_numpy(),
    shock['shock'].to_numpy(), s
)
effective_shocks = float(1 / np.sum(s * s))

result = {
    'task_id': 'applied_shift_share',
    'platform': 'python',
    'estimates': [
        {'term': 'effect', 'estimate': effect, 'se': effect_se, 'n_obs': n},
        {'term': 'first_stage', 'estimate': first_stage, 'se': first_stage_se, 'n_obs': n},
        {'term': 'effective_shocks', 'estimate': effective_shocks, 'se': None, 'n_obs': n},
    ],
    'method_metadata': {
        'estimator': 'Regional weighted 2SLS; equivalent shock-level weighted IV',
        'vcov': 'Shock-level heteroskedasticity-robust HC1, N/(N-2), analytic weights',
    },
    'diagnostics': {},
}
with open('result.json', 'w') as output:
    json.dump(result, output, indent=2)

# Independent regional weighted covariance identities check both point estimates.
e = regional['e'].to_numpy()
z0 = regional['z0'].to_numpy()
x0 = regional['x0'].to_numpy()
y0 = regional['y0'].to_numpy()
regional_effect = np.dot(e * z0, y0) / np.dot(e * z0, x0)
regional_first_stage = np.dot(e * z0, x0) / np.dot(e * z0, z0)
assert np.isclose(effect, regional_effect, rtol=1e-10, atol=1e-12)
assert np.isclose(first_stage, regional_first_stage, rtol=1e-10, atol=1e-12)
assert np.isclose(s.sum(), 1, atol=1e-10)

with open('verification.txt', 'w') as output:
    output.write(f'Input: {len(data)} region-industry rows; {len(regional)} regions; {n} industries used.\n')
    output.write('Each region-industry pair is unique. Regional values and industry shocks are constant within their groups. Shares sum to one per region.\n')
    output.write(f'Regional weights were normalized once; sum(e)={e.sum():.16g}. Industry exposure weights sum(s)={s.sum():.16g}.\n')
    output.write('Shock-level IV uses an intercept, analytic weights s, structural IV residuals, and HC1 multiplier N/(N-2).\n')
    output.write(f'Independent regional covariance effect={regional_effect:.16g}; shock-level IV effect={effect:.16g}.\n')
    output.write(f'Independent regional covariance first stage={regional_first_stage:.16g}; shock-level IV first stage={first_stage:.16g}.\n')
    output.write('Both identities pass at relative tolerance 1e-10.\n')
