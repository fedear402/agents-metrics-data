import json
import numpy as np
import pandas as pd

raw = pd.read_csv('input.csv')
required = ['region_id', 'industry_id', 'share', 'shock', 'region_weight', 'x', 'y']
assert raw[required].notna().all().all()
assert not raw.duplicated(['region_id', 'industry_id']).any()
for col in ['region_weight', 'x', 'y']:
    assert (raw.groupby('region_id')[col].nunique() == 1).all()
assert (raw.groupby('industry_id')['shock'].nunique() == 1).all()
assert np.allclose(raw.groupby('region_id')['share'].sum(), 1, rtol=0, atol=1e-12)
regions = raw.groupby('region_id', sort=True)[['region_weight', 'x', 'y']].first()
assert (regions.region_weight > 0).all()
regions['e'] = regions.region_weight / regions.region_weight.sum()
raw['weighted_shock'] = raw.share * raw.shock
regions['z'] = raw.groupby('region_id').weighted_shock.sum()
for col in ['x', 'y', 'z']:
    regions[col + '0'] = regions[col] - np.dot(regions.e, regions[col])
raw = raw.join(regions[['e', 'x0', 'y0', 'z0']], on='region_id')
raw['exposure'] = raw.e * raw.share
for col in ['x', 'y', 'z']:
    raw[col + '_numerator'] = raw.exposure * raw[col + '0']
industry = raw.groupby('industry_id', sort=True).agg(
    s=('exposure', 'sum'), shock=('shock', 'first'),
    xnum=('x_numerator', 'sum'), ynum=('y_numerator', 'sum'),
    znum=('z_numerator', 'sum'))
assert (industry.s > 0).all()
assert np.isclose(industry.s.sum(), 1)
for col in ['x', 'y', 'z']:
    industry[col + 'bar'] = industry[col + 'num'] / industry.s
N = len(industry)
w = industry.s.to_numpy()
g = industry.shock.to_numpy()

def iv_fit(outcome, endogenous):
    y = industry[outcome].to_numpy()
    x = industry[endogenous].to_numpy()
    X = np.column_stack((np.ones(N), x))
    Z = np.column_stack((np.ones(N), g))
    zwx = Z.T @ (w[:, None] * X)
    beta = np.linalg.solve(zwx, Z.T @ (w * y))
    residual = y - X @ beta
    influence = (w * residual)[:, None] * Z
    inv = np.linalg.inv(zwx)
    vcov = (N / (N - 2)) * inv @ (influence.T @ influence) @ inv.T
    return float(beta[1]), float(np.sqrt(vcov[1, 1]))

effect, effect_se = iv_fit('ybar', 'xbar')
first_stage, first_stage_se = iv_fit('xbar', 'zbar')

# Independent regional just-identified IV identity.
e = regions.e.to_numpy()
z0 = regions.z0.to_numpy()
regional_effect = np.dot(e * z0, regions.y0) / np.dot(e * z0, regions.x0)
regional_first_stage = np.dot(e * z0, regions.x0) / np.dot(e * z0, regions.z0)
assert np.isclose(effect, regional_effect, rtol=1e-10, atol=1e-10)
assert np.isclose(first_stage, regional_first_stage, rtol=1e-10, atol=1e-10)

# Independent scalar HC1 identity for a just-identified IV with an intercept.
def scalar_se(outcome, endogenous, slope):
    y = industry[outcome].to_numpy()
    x = industry[endogenous].to_numpy()
    gm = np.dot(w, g) / w.sum()
    xm = np.dot(w, x) / w.sum()
    ym = np.dot(w, y) / w.sum()
    u = y - ym - slope * (x - xm)
    denominator = np.dot(w * (g - gm), x - xm)
    return float(np.sqrt(N / (N - 2) * np.sum((w * (g - gm) * u) ** 2) / denominator ** 2))
assert np.isclose(effect_se, scalar_se('ybar', 'xbar', effect), rtol=1e-10)
assert np.isclose(first_stage_se, scalar_se('xbar', 'zbar', first_stage), rtol=1e-10)

result = {
    'task_id': 'applied_shift_share', 'platform': 'python',
    'estimates': [
        {'term': 'effect', 'estimate': effect, 'se': effect_se, 'n_obs': N},
        {'term': 'first_stage', 'estimate': first_stage, 'se': first_stage_se, 'n_obs': N},
        {'term': 'effective_shocks', 'estimate': float(1 / np.dot(w, w)), 'se': None, 'n_obs': N},
    ],
    'method_metadata': {
        'estimator': 'Regional weighted 2SLS; equivalent BHJ shock-level weighted IV',
        'vcov': 'Shock-level heteroskedasticity-robust HC1, N/(N-2), analytic weights'},
    'diagnostics': {}
}
with open('result.json', 'w') as file:
    json.dump(result, file, indent=2)
print(json.dumps({'regions': len(regions), 'industries': N, 'rows': len(raw), 'result': result['estimates']}, indent=2))
