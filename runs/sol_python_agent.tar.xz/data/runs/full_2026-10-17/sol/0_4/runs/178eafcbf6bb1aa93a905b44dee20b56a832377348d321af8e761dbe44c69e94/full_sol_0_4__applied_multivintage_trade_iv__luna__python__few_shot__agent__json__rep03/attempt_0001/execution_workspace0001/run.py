import json
import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS

crosswalk = pd.read_csv('crosswalk.csv')
trade = pd.read_csv('trade.csv').merge(crosswalk, on='code', validate='many_to_one')
areas = pd.read_csv('areas.csv')
employment = pd.read_csv('employment.csv')
outcomes = pd.read_csv('outcomes.csv')

assert crosswalk.code.is_unique
assert trade.groupby(['period', 'industry']).size().eq(1).all()
assert areas.groupby(['area', 'period', 'vintage']).size().eq(1).all()
assert outcomes.groupby(['area', 'period']).size().eq(1).all()
assert employment.groupby(['area', 'period', 'vintage', 'industry']).size().eq(1).all()
assert trade.groupby('period')[['price_index', 'years']].nunique().eq(1).all().all()

# Build the complete area-period-vintage-industry grid. Omitted employment cells are zero.
industries = trade[['period', 'industry']].drop_duplicates()
grid = areas.merge(industries, on='period', validate='many_to_many')
grid = grid.merge(employment, on=['area', 'period', 'vintage', 'industry'], how='left', validate='one_to_one')
imputed_zero_cells = int(grid.employment.isna().sum())
grid['employment'] = grid['employment'].fillna(0)
national = grid.groupby(['period', 'vintage', 'industry'], as_index=False)['employment'].sum()
national = national.rename(columns={'employment': 'national_employment'})
grid = grid.merge(national, on=['period', 'vintage', 'industry'], validate='many_to_one')
grid = grid.merge(trade[['period', 'industry', 'us_change', 'other_change', 'price_index', 'years']], on=['period', 'industry'], validate='many_to_one')
assert grid.national_employment.gt(0).all()
assert grid.total_employment.gt(0).all()
assert grid.groupby(['area', 'period', 'vintage']).size().eq(4).all()
change = np.where(grid.vintage.eq('base'), grid.us_change, grid.other_change)
grid['contribution'] = (grid.employment / grid.total_employment * change / grid.national_employment /
                        (grid.price_index / 100) / 1000 * (10 / grid.years))
exposure = grid.groupby(['area', 'period', 'vintage'], as_index=False)['contribution'].sum()
exposure = exposure.pivot(index=['area', 'period'], columns='vintage', values='contribution').reset_index().rename(columns={'base': 'x', 'early': 'z'})
base_areas = areas.loc[areas.vintage.eq('base'), ['area', 'period', 'population']]
sample = outcomes.merge(exposure, on=['area', 'period'], validate='one_to_one').merge(base_areas, on=['area', 'period'], validate='one_to_one')
assert len(sample) == 72 and sample[['change_pp', 'period', 'control', 'x', 'z', 'population']].notna().all().all()
assert sample.population.gt(0).all()
sample = sample.sort_values(['period', 'area']).reset_index(drop=True)
exog = pd.DataFrame({'intercept': np.ones(len(sample)), 'period': sample.period, 'control': sample.control})
fit = IV2SLS(sample.change_pp, exog, sample[['x']], sample[['z']], weights=sample.population).fit()
slope = float(fit.params['x'])

# Independent weighted IV normal-equation check, with all exogenous columns as instruments.
X = np.column_stack([np.ones(len(sample)), sample.period, sample.control, sample.x])
Z = np.column_stack([np.ones(len(sample)), sample.period, sample.control, sample.z])
w = sample.population.to_numpy()
y = sample.change_pp.to_numpy()
manual = np.linalg.solve(Z.T @ (w[:, None] * X), Z.T @ (w * y))
assert abs(slope - manual[-1]) < 1e-9

lookup = sample.set_index(['area', 'period'])
def estimate(term, value):
    return {'term': term, 'estimate': float(value), 'se': None, 'n_obs': 72}
result = {
    'task_id': 'applied_multivintage_trade_iv',
    'platform': 'python',
    'estimates': [
        estimate('iv_slope', slope),
        estimate('exposure_area0_period0', lookup.loc[(0, 0), 'x']),
        estimate('exposure_area0_period1', lookup.loc[(0, 1), 'x']),
        estimate('instrument_area0_period0', lookup.loc[(0, 0), 'z']),
    ],
    'method_metadata': {'estimator': 'weighted 2SLS', 'outcome': 'change_pp', 'endogenous': 'x', 'instrument': 'z', 'exogenous': ['intercept', 'period', 'control'], 'weight': 'base-vintage population', 'exposure_units': 'thousands of real dollars per worker per decade'},
    'diagnostics': {'estimation_rows': len(sample), 'periods': sorted(int(p) for p in sample.period.unique()), 'areas_per_period': {str(int(p)): int(n) for p, n in sample.groupby('period').size().items()}, 'complete_employment_grid_rows': len(grid), 'imputed_zero_cells': imputed_zero_cells, 'independent_iv_slope': float(manual[-1]), 'iv_check_absolute_difference': float(abs(slope - manual[-1]))}
}
with open('result.json', 'w') as handle:
    json.dump(result, handle, indent=2, allow_nan=False)
