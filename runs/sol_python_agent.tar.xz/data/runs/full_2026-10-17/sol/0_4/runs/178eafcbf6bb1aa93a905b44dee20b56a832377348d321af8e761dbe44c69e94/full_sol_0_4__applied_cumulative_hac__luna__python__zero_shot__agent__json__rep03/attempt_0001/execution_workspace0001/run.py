import json

import numpy as np
import pandas as pd
import statsmodels.api as sm


data = pd.read_csv("input.csv", parse_dates=["date"]).sort_values("date")
change = np.log(data["vix"]).diff()
lags = pd.DataFrame({f"lag_{j}": change.shift(j) for j in range(1, 16)})
sample = pd.concat([np.log(data["sales"]).rename("log_sales"), lags], axis=1).dropna()
y = sample["log_sales"]
X = sm.add_constant(sample[[f"lag_{j}" for j in range(1, 16)]])
fit = sm.OLS(y, X).fit()
cov = sm.stats.sandwich_covariance.cov_hac(fit, nlags=15, weights_func=sm.stats.sandwich_covariance.weights_bartlett, use_correction=False)
n = len(sample)
cov *= n / (n - 16)
beta = fit.params.to_numpy()
weights = np.r_[0.0, np.ones(15)]


def row(term, estimate, variance):
    return {"term": term, "estimate": float(estimate), "se": float(np.sqrt(variance)), "n_obs": n}


result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        row("cumulative_response", weights @ beta, weights @ cov @ weights),
        row("lag_1", beta[1], cov[1, 1]),
        row("lag_15", beta[15], cov[15, 15]),
    ],
    "method_metadata": {
        "estimator": "OLS of log(sales) on intercept and lags 1-15 of delta log(vix)",
        "vcov": "Newey-West HAC, Bartlett lag 15, multiplied by N/(N-16)",
    },
    "diagnostics": {},
}
with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output, indent=2)
    output.write("\n")
