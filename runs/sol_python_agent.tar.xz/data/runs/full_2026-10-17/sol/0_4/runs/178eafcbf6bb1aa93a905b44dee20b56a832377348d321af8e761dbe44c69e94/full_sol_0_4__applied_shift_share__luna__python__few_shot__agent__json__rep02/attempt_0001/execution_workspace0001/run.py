import json

import numpy as np
import pandas as pd


data = pd.read_csv("input.csv")
columns = ["region_id", "industry_id", "share", "shock", "region_weight", "x", "y"]
assert list(data.columns) == columns
assert not data[columns].isna().any().any()
assert not data.duplicated(["region_id", "industry_id"]).any()
for name in ["region_weight", "x", "y"]:
    assert data.groupby("region_id")[name].nunique().eq(1).all()
assert data.groupby("industry_id")["shock"].nunique().eq(1).all()

shares = data.pivot(index="region_id", columns="industry_id", values="share")
assert not shares.isna().any().any()
assert np.allclose(shares.sum(axis=1), 1, atol=1e-12)
assert (shares.to_numpy() >= 0).all()
regions = data.drop_duplicates("region_id").set_index("region_id").loc[shares.index]
industries = data.drop_duplicates("industry_id").set_index("industry_id").loc[shares.columns]
e = regions["region_weight"].to_numpy(dtype=float).copy()
assert (e > 0).all()
e /= e.sum()
S = shares.to_numpy(dtype=float)
g = industries["shock"].to_numpy(dtype=float)
x = regions["x"].to_numpy(dtype=float)
y = regions["y"].to_numpy(dtype=float)
z = S @ g
V = np.column_stack((y, x, z))
V0 = V - e @ V
mass = e @ S
assert (mass > 0).all()
assert np.isclose(mass.sum(), 1)
aggregated = (S.T @ (e[:, None] * V0)) / mass[:, None]
assert np.allclose(mass @ aggregated, 0, atol=1e-12)
N = len(g)
assert N > 2


def shock_iv(dependent, endogenous):
    regressors = np.column_stack((np.ones(N), endogenous))
    instruments = np.column_stack((np.ones(N), g))
    cross = instruments.T @ (mass[:, None] * regressors)
    beta = np.linalg.solve(cross, instruments.T @ (mass * dependent))
    residual = dependent - regressors @ beta
    scores = instruments * (mass * residual)[:, None]
    inverse = np.linalg.inv(cross)
    covariance = (N / (N - 2)) * inverse @ (scores.T @ scores) @ inverse.T
    return float(beta[1]), float(np.sqrt(covariance[1, 1]))


effect, effect_se = shock_iv(aggregated[:, 0], aggregated[:, 1])
first_stage, first_stage_se = shock_iv(aggregated[:, 1], aggregated[:, 2])
effective_shocks = float(1 / np.sum(mass**2))

# Independent regional moment checks for both shock-level slopes.
regional_effect = np.sum(e * V0[:, 2] * V0[:, 0]) / np.sum(e * V0[:, 2] * V0[:, 1])
regional_first_stage = np.sum(e * V0[:, 2] * V0[:, 1]) / np.sum(e * V0[:, 2] ** 2)
assert np.isclose(effect, regional_effect, rtol=1e-10, atol=1e-12)
assert np.isclose(first_stage, regional_first_stage, rtol=1e-10, atol=1e-12)

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": effect, "se": effect_se, "n_obs": N},
        {"term": "first_stage", "estimate": first_stage, "se": first_stage_se, "n_obs": N},
        {"term": "effective_shocks", "estimate": effective_shocks, "se": None, "n_obs": N},
    ],
    "method_metadata": {
        "estimator": "Regional weighted 2SLS; equivalent industry-level weighted IV",
        "vcov": "Industry-level heteroskedasticity-robust HC1, N/(N-2), structural IV residuals",
    },
    "diagnostics": {},
}
with open("result.json", "w", encoding="utf-8") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)

with open("verification.txt", "w", encoding="utf-8") as stream:
    stream.write(f"Input: {len(data)} region-industry rows; {len(e)} regions; {N} industries.\n")
    stream.write("Complete region-industry grid; unique pair keys; region variables and industry shocks constant within groups.\n")
    stream.write(f"Regional share sum range: {shares.sum(axis=1).min():.16g} to {shares.sum(axis=1).max():.16g}.\n")
    stream.write(f"Normalized region weight sum: {e.sum():.16g}; industry exposure mass sum: {mass.sum():.16g}.\n")
    stream.write("Centered regional y, x, and z before exposure aggregation; included intercepts in both IV matrices.\n")
    stream.write("SE: industry-level structural IV residual scores, analytic weights squared in score outer products, HC1 N/(N-2).\n")
    stream.write(f"Effect: shock IV {effect:.15g}; independent regional IV moment {regional_effect:.15g}; difference {effect-regional_effect:.3g}.\n")
    stream.write(f"First stage: shock IV {first_stage:.15g}; independent regional WLS moment {regional_first_stage:.15g}; difference {first_stage-regional_first_stage:.3g}.\n")
    stream.write(f"Effective shocks: {effective_shocks:.15g}; all {N} positive exposure masses used.\n")
