import json
import numpy as np
import pandas as pd

crosswalk = pd.read_csv('crosswalk.csv')
trade = pd.read_csv('trade.csv')
areas = pd.read_csv('areas.csv')
employment = pd.read_csv('employment.csv')
outcomes = pd.read_csv('outcomes.csv')

assert crosswalk['code'].is_unique
assert trade[['period', 'code']].duplicated().sum() == 0
assert areas[['area', 'period', 'vintage']].duplicated().sum() == 0
assert outcomes[['area', 'period']].duplicated().sum() == 0
assert employment[['area', 'period', 'vintage', 'industry']].duplicated().sum() == 0
assert set(areas.vintage) == {'base', 'early'}
assert crosswalk.industry.nunique() == 4

trade = trade.merge(crosswalk, on='code', validate='many_to_one')
assert len(trade) == 8 and trade.groupby(['period', 'industry']).size().eq(1).all()
assert trade.groupby('period')[['price_index', 'years']].nunique().eq(1).all().all()

# Form every area-period-vintage-industry cell, including omitted zero cells.
industries = pd.DataFrame({'industry': sorted(crosswalk.industry.unique())})
cells = areas.merge(industries, how='cross').merge(
    employment, on=['area', 'period', 'vintage', 'industry'], how='left',
    validate='one_to_one')
missing_cells = int(cells['employment'].isna().sum())
cells['employment'] = cells['employment'].fillna(0)
assert len(cells) == len(areas) * 4
national = cells.groupby(['period', 'vintage', 'industry'], as_index=False)['employment'].sum()
national = national.rename(columns={'employment': 'national_employment'})
assert (national.national_employment > 0).all()
cells = cells.merge(national, on=['period', 'vintage', 'industry'], validate='many_to_one')
cells = cells.merge(trade, on=['period', 'industry'], validate='many_to_one')
assert (cells.total_employment > 0).all() and (cells.years > 0).all()

change = np.where(cells.vintage.eq('base'), cells.us_change, cells.other_change)
cells['component'] = (cells.employment / cells.total_employment
                      * change / cells.national_employment
                      / (cells.price_index / 100) / 1000 * (10 / cells.years))
exposures = cells.groupby(['area', 'period', 'vintage'], as_index=False)['component'].sum()
exposures = exposures.pivot(index=['area', 'period'], columns='vintage', values='component').reset_index()
exposures = exposures.rename(columns={'base': 'x', 'early': 'z'})
base = areas.loc[areas.vintage.eq('base'), ['area', 'period', 'population']]
sample = outcomes.merge(exposures, on=['area', 'period'], validate='one_to_one').merge(
    base, on=['area', 'period'], validate='one_to_one').sort_values(['period', 'area'])
assert len(sample) == 72 and sample[['change_pp', 'period', 'control', 'x', 'z', 'population']].notna().all().all()
assert (sample.population > 0).all()

# Weighted 2SLS: endogenous x; exogenous intercept, period, and control.
y = sample.change_pp.to_numpy(float)
X = np.column_stack([np.ones(len(sample)), sample.period, sample.control, sample.x]).astype(float)
Z = np.column_stack([np.ones(len(sample)), sample.period, sample.control, sample.z]).astype(float)
w = sample.population.to_numpy(float)
swx, swz, swy = X * np.sqrt(w)[:, None], Z * np.sqrt(w)[:, None], y * np.sqrt(w)
first_stage = np.linalg.lstsq(swz, swx, rcond=None)[0]
projected_x = swz @ first_stage
beta = np.linalg.lstsq(projected_x, swy, rcond=None)[0]
assert np.linalg.matrix_rank(swz) == 4 and np.linalg.matrix_rank(projected_x) == 4
assert np.max(np.abs(swz.T @ (swy - swx @ beta))) < 1e-6

look = sample.set_index(['area', 'period'])
estimates = [
    ('iv_slope', beta[3]),
    ('exposure_area0_period0', look.loc[(0, 0), 'x']),
    ('exposure_area0_period1', look.loc[(0, 1), 'x']),
    ('instrument_area0_period0', look.loc[(0, 0), 'z']),
]
result = {
    'task_id': 'applied_multivintage_trade_iv',
    'platform': 'python',
    'estimates': [{'term': term, 'estimate': float(value), 'se': None, 'n_obs': 72}
                  for term, value in estimates],
    'method_metadata': {
        'estimator': 'population-weighted 2SLS',
        'outcome': 'change_pp',
        'endogenous_regressor': 'x',
        'excluded_instrument': 'z',
        'exogenous_regressors_and_instruments': ['intercept', 'period', 'control'],
        'weight': 'base-vintage population',
        'exposure_unit': 'thousands of real dollars per worker per decade'
    },
    'diagnostics': {
        'estimation_rows': int(len(sample)),
        'periods': sorted(int(v) for v in sample.period.unique()),
        'areas_per_period': {str(k): int(v) for k, v in sample.groupby('period').size().items()},
        'missing_employment_cells_filled': missing_cells,
        'instrument_rank': int(np.linalg.matrix_rank(swz))
    }
}
with open('result.json', 'w') as f:
    json.dump(result, f, indent=2, allow_nan=False)
    f.write('\n')

# Independent weighted Frisch-Waugh-Lovell identity for the one-instrument slope.
C = swx[:, :3]
x_res = swx[:, 3] - C @ np.linalg.lstsq(C, swx[:, 3], rcond=None)[0]
z_res = swz[:, 3] - C @ np.linalg.lstsq(C, swz[:, 3], rcond=None)[0]
y_res = swy - C @ np.linalg.lstsq(C, swy, rcond=None)[0]
fwl_slope = (z_res @ y_res) / (z_res @ x_res)
assert np.isclose(fwl_slope, beta[3], rtol=1e-12, atol=1e-12)

# Separate direct sums for the requested area, using source rows and zero fill.
checks = {}
for period, vintage, change_column in [(0, 'base', 'us_change'), (1, 'base', 'us_change'), (0, 'early', 'other_change')]:
    area_row = areas.query('area == 0 and period == @period and vintage == @vintage').iloc[0]
    total = 0.0
    for row in trade.query('period == @period').itertuples():
        local = employment.query('area == 0 and period == @period and vintage == @vintage and industry == @row.industry').employment.sum()
        national_direct = employment.query('period == @period and vintage == @vintage and industry == @row.industry').employment.sum()
        total += local / area_row.total_employment * getattr(row, change_column) / national_direct / (row.price_index / 100) / 1000 * 10 / row.years
    target = look.loc[(0, period), 'x' if vintage == 'base' else 'z']
    assert np.isclose(total, target, rtol=1e-12, atol=1e-12)
    checks[f'{vintage}_period{period}'] = total

with open('verification.txt', 'w') as f:
    f.write('Estimation sample: 72 area-period rows, 36 in each period; all outcome rows joined once.\n')
    f.write('Employment: four industries per area-period-vintage; omitted cells filled with zero. National denominators sum all supplied areas within period and vintage.\n')
    f.write('Construction: base uses us_change and base employment; early uses other_change and early employment. Both use period price index and years.\n')
    f.write('Estimator: population-weighted 2SLS includes intercept, period, and control as regressors and instruments; instrument matrix rank is 4.\n')
    f.write(f'Independent FWL slope: {fwl_slope:.15g}; matrix 2SLS slope: {beta[3]:.15g}; absolute difference: {abs(fwl_slope-beta[3]):.3g}.\n')
    f.write('Direct source-row sums agree with constructed exposures: ' + ', '.join(f'{k}={v:.15g}' for k, v in checks.items()) + '.\n')
    f.write('No uncertainty measure was requested; all se fields are null.\n')
