import json

import numpy as np
import pandas as pd
import statsmodels.api as sm


data = pd.read_csv("input.csv", parse_dates=["date"]).sort_values("date", kind="stable")
log_vix = np.log(data["vix"])
change = log_vix.diff()
regression = pd.DataFrame({"log_sales": np.log(data["sales"])})
for lag in range(1, 16):
    regression[f"lag_{lag}"] = change.shift(lag)
regression = regression.dropna()

y = regression["log_sales"].to_numpy()
x = sm.add_constant(regression[[f"lag_{lag}" for lag in range(1, 16)]].to_numpy())
fit = sm.OLS(y, x).fit()
n = len(y)

# Bartlett HAC meat. The requested N/(N-16) factor is applied to the covariance.
score = x * fit.resid[:, None]
meat = score.T @ score
for lag in range(1, 16):
    cross = score[lag:].T @ score[:-lag]
    meat += (1 - lag / 16) * (cross + cross.T)
bread = np.linalg.inv(x.T @ x)
covariance = (n / (n - 16)) * bread @ meat @ bread

weights = np.zeros(16)
weights[1:] = 1
total = float(weights @ fit.params)
total_se = float(np.sqrt(weights @ covariance @ weights))

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {"term": "cumulative_response", "estimate": total, "se": total_se, "n_obs": n},
        {"term": "lag_1", "estimate": float(fit.params[1]), "se": float(np.sqrt(covariance[1, 1])), "n_obs": n},
        {"term": "lag_15", "estimate": float(fit.params[15]), "se": float(np.sqrt(covariance[15, 15])), "n_obs": n},
    ],
    "method_metadata": {"estimator": "OLS of log sales on intercept and 15 lagged log VIX changes", "vcov": "Newey-West HAC, Bartlett maximum lag 15, multiplied by N/(N-16)"},
    "diagnostics": {},
}
with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output, indent=2)
