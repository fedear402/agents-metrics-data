import json
import numpy as np
import pandas as pd

raw = pd.read_csv('input.csv')
required = ['region_id', 'industry_id', 'share', 'shock', 'region_weight', 'x', 'y']
assert list(raw.columns) == required
assert raw[required].notna().all().all()
assert not raw.duplicated(['region_id', 'industry_id']).any()
for col, key in [('region_weight', 'region_id'), ('x', 'region_id'), ('y', 'region_id'), ('shock', 'industry_id')]:
    assert raw.groupby(key)[col].nunique().eq(1).all(), f'{col} varies within {key}'
regions = raw.drop_duplicates('region_id').set_index('region_id').sort_index()
industries = raw.drop_duplicates('industry_id').set_index('industry_id').sort_index()
shares = raw.pivot(index='region_id', columns='industry_id', values='share').reindex(index=regions.index, columns=industries.index).fillna(0.0)
assert np.allclose(shares.sum(axis=1), 1.0, atol=1e-10)
assert (regions.region_weight > 0).all()
e = regions.region_weight.to_numpy(dtype=float).copy()
e /= e.sum()
S = shares.to_numpy(dtype=float)
g = industries.shock.to_numpy(dtype=float)
x = regions.x.to_numpy(dtype=float)
y = regions.y.to_numpy(dtype=float)
z = S @ g
regional = np.column_stack((y, x, z))
centered = regional - e @ regional
s = e @ S
assert np.all(s > 0)
bar = (S.T @ (e[:, None] * centered)) / s[:, None]
N = len(industries)
assert N > 2
assert np.allclose(s @ bar, 0, atol=1e-12)

def shock_iv(dependent, endogenous):
    X = np.column_stack((np.ones(N), endogenous))
    Z = np.column_stack((np.ones(N), g))
    cross = Z.T @ (s[:, None] * X)
    beta = np.linalg.solve(cross, Z.T @ (s * dependent))
    residual = dependent - X @ beta
    scores = Z * (s * residual)[:, None]
    inverse = np.linalg.inv(cross)
    covariance = (N / (N - 2)) * inverse @ (scores.T @ scores) @ inverse.T
    return float(beta[1]), float(np.sqrt(covariance[1, 1]))

effect, effect_se = shock_iv(bar[:, 0], bar[:, 1])
first_stage, first_stage_se = shock_iv(bar[:, 1], bar[:, 2])
effective = float(1 / np.sum(s**2))

# Independent regional weighted moment calculations.
effect_regional = float(np.sum(e * centered[:, 2] * centered[:, 0]) / np.sum(e * centered[:, 2] * centered[:, 1]))
first_stage_regional = float(np.sum(e * centered[:, 2] * centered[:, 1]) / np.sum(e * centered[:, 2]**2))
assert np.isclose(effect, effect_regional, rtol=1e-10, atol=1e-12)
assert np.isclose(first_stage, first_stage_regional, rtol=1e-10, atol=1e-12)

result = {
    'task_id': 'applied_shift_share',
    'platform': 'python',
    'estimates': [
        {'term': 'effect', 'estimate': effect, 'se': effect_se, 'n_obs': N},
        {'term': 'first_stage', 'estimate': first_stage, 'se': first_stage_se, 'n_obs': N},
        {'term': 'effective_shocks', 'estimate': effective, 'se': None, 'n_obs': N},
    ],
    'method_metadata': {'estimator': 'Weighted regional 2SLS; BHJ shock-level IV aggregation', 'vcov': 'Shock-level heteroskedastic HC1, analytic-weight scores, N/(N-2)'},
    'diagnostics': {},
}
with open('result.json', 'w') as f:
    json.dump(result, f, indent=2, allow_nan=False)
with open('verification.txt', 'w') as f:
    f.write(f'Input rows: {len(raw)}; regions: {len(regions)}; industries: {N}.\n')
    f.write('Region-industry pairs are unique; regional variables and industry shocks are constant within their groups.\n')
    f.write(f'Maximum regional share-sum error: {np.max(np.abs(S.sum(axis=1)-1)):.3g}.\n')
    f.write(f'Sum of normalized regional weights: {e.sum():.17g}; sum of exposure masses: {s.sum():.17g}.\n')
    f.write('Shock regressions use all industries, an intercept, structural IV residuals, squared analytic-weight scores, and HC1 N/(N-2).\n')
    f.write(f'Effect: shock-level {effect:.15g}; independent regional weighted IV moments {effect_regional:.15g}; absolute difference {abs(effect-effect_regional):.3g}.\n')
    f.write(f'First stage: shock-level {first_stage:.15g}; independent regional weighted slope {first_stage_regional:.15g}; absolute difference {abs(first_stage-first_stage_regional):.3g}.\n')
    f.write(f'Effect SE: {effect_se:.15g}; first-stage SE: {first_stage_se:.15g}; effective shocks: {effective:.15g}.\n')
