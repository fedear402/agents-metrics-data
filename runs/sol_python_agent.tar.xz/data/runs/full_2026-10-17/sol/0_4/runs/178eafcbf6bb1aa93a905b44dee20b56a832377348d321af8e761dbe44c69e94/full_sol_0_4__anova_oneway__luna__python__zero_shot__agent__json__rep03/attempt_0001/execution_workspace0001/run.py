import json

import pandas as pd
from scipy.stats import f


data = pd.read_csv("input.csv")
sample = data.loc[:, ["group", "y"]].dropna()
if sample.empty:
    raise ValueError("The estimation sample is empty")

groups = sample.groupby("group", sort=False)["y"]
counts = groups.size()
if len(counts) < 2:
    raise ValueError("ANOVA requires at least two groups")

n = int(len(sample))
df_num = len(counts) - 1
df_den = n - len(counts)
if df_den <= 0:
    raise ValueError("ANOVA requires positive residual degrees of freedom")

grand_mean = sample["y"].mean()
group_means = groups.mean()
ss_between = float(((group_means - grand_mean) ** 2 * counts).sum())
ss_within = float(groups.apply(lambda values: ((values - values.mean()) ** 2).sum()).sum())
f_stat = (ss_between / df_num) / (ss_within / df_den)
p_value = float(f.sf(f_stat, df_num, df_den))

result = {
    "task_id": "anova_oneway",
    "platform": "python",
    "estimates": [
        {"term": term, "estimate": float(value), "se": None, "n_obs": n}
        for term, value in (
            ("F", f_stat),
            ("df_num", df_num),
            ("df_den", df_den),
            ("p_value", p_value),
        )
    ],
    "method_metadata": {"estimator": "classical one-way ANOVA", "vcov": "pooled within-group variance"},
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output, indent=2, allow_nan=False)
    output.write("\n")
