import json

import pandas as pd
from scipy import stats


data = pd.read_csv("input.csv", usecols=["group", "y"])
sample = data.dropna(subset=["group", "y"])
groups = [part["y"].to_numpy(dtype=float) for _, part in sample.groupby("group")]
n_obs = len(sample)
df_num = len(groups) - 1
df_den = n_obs - len(groups)
if df_num < 1 or df_den < 1:
    raise ValueError("One-way ANOVA requires at least two groups and residual degrees of freedom")

f_stat, p_value = stats.f_oneway(*groups)
out = {
    "task_id": "anova_oneway",
    "platform": "python",
    "estimates": [
        {"term": "F", "estimate": float(f_stat), "se": None, "n_obs": n_obs},
        {"term": "df_num", "estimate": float(df_num), "se": None, "n_obs": n_obs},
        {"term": "df_den", "estimate": float(df_den), "se": None, "n_obs": n_obs},
        {"term": "p_value", "estimate": float(p_value), "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {"estimator": "Classical one-way ANOVA", "vcov": "pooled within-group variance"},
    "diagnostics": {},
}
with open("result.json", "w") as file:
    json.dump(out, file)
