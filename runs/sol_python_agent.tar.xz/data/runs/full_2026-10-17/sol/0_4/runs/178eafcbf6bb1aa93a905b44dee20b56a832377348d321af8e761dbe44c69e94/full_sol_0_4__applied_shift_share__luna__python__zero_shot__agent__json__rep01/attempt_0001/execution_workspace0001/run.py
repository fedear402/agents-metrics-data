import json

import numpy as np
import pandas as pd


df = pd.read_csv("input.csv")
columns = ["region_id", "industry_id", "share", "shock", "region_weight", "x", "y"]
assert list(df.columns) == columns
assert df[columns[2:]].notna().all().all()
assert not df.duplicated(["region_id", "industry_id"]).any()
assert df.groupby("region_id")[["region_weight", "x", "y"]].nunique().eq(1).all().all()
assert df.groupby("industry_id")["shock"].nunique().eq(1).all()

regions = df.groupby("region_id", sort=True)[["region_weight", "x", "y"]].first()
industries = df.groupby("industry_id", sort=True)["shock"].first()
shares = df.pivot(index="region_id", columns="industry_id", values="share")
assert not shares.isna().any().any()
assert np.allclose(shares.sum(axis=1), 1, rtol=0, atol=1e-10)
assert (regions.region_weight > 0).all()

e = regions.region_weight.to_numpy() / regions.region_weight.sum()
a = shares.to_numpy()
g = industries.to_numpy()
x = regions.x.to_numpy()
y = regions.y.to_numpy()
z = a @ g
n = len(g)
s = a.T @ e
assert (s > 0).all() and np.isclose(s.sum(), 1)

def centered(v):
    return v - e @ v

x0, y0, z0 = (centered(v) for v in (x, y, z))
xbar, ybar, zbar = (a.T @ (e * v) / s for v in (x0, y0, z0))

def weighted_iv(outcome, endogenous):
    # One instrument and one endogenous regressor, with a weighted intercept.
    gc = g - s @ g
    yc = outcome - s @ outcome
    dc = endogenous - s @ endogenous
    denominator = np.sum(s * gc * dc)
    assert abs(denominator) > 1e-12
    beta = np.sum(s * gc * yc) / denominator
    alpha = s @ outcome - beta * (s @ endogenous)
    residual = outcome - alpha - beta * endogenous
    hc0 = np.sum((s * gc * residual) ** 2) / denominator**2
    return float(beta), float(np.sqrt(hc0 * n / (n - 2)))

effect, effect_se = weighted_iv(ybar, xbar)
first_stage, first_stage_se = weighted_iv(xbar, zbar)
effective_shocks = float(1 / np.sum(s**2))

# Independent regional moment checks for the two reported slopes.
regional_effect = (e * z0) @ y0 / ((e * z0) @ x0)
regional_first_stage = (e * z0) @ x0 / ((e * z0) @ z0)
assert np.isclose(effect, regional_effect, rtol=1e-10, atol=1e-12)
assert np.isclose(first_stage, regional_first_stage, rtol=1e-10, atol=1e-12)

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": effect, "se": effect_se, "n_obs": n},
        {"term": "first_stage", "estimate": first_stage, "se": first_stage_se, "n_obs": n},
        {"term": "effective_shocks", "estimate": effective_shocks, "se": None, "n_obs": n},
    ],
    "method_metadata": {
        "estimator": "Regional weighted 2SLS; equivalent shock-level weighted IV with intercept",
        "vcov": "Shock-level heteroskedasticity-robust HC1, structural IV residuals, multiplier N/(N-2)",
    },
    "diagnostics": {},
}
with open("result.json", "w") as file:
    json.dump(result, file, indent=2)

print(f"regions={len(regions)}, industries={n}, rows={len(df)}")
print(f"share_sum_max_error={np.max(np.abs(a.sum(axis=1)-1)):.3g}")
print(f"effect={effect:.12g}, regional_check={regional_effect:.12g}, se={effect_se:.12g}")
print(f"first_stage={first_stage:.12g}, regional_check={regional_first_stage:.12g}, se={first_stage_se:.12g}")
print(f"effective_shocks={effective_shocks:.12g}")
