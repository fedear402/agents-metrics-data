import csv
import json
import numpy as np

with open('households.csv', newline='') as f:
    rows = list(csv.DictReader(f))
with open('census.csv', newline='') as f:
    census_rows = list(csv.DictReader(f))

sample = [r for r in rows if int(r['recipient']) == 0]
assert len(sample) > 0
assert {int(r['eligible']) for r in sample} == {0, 1}
assert all(float(r['weight']) > 0 for r in sample)
assert len(census_rows) == 2 and {int(r['eligible']) for r in census_rows} == {0, 1}

get = lambda name: np.array([float(r[name]) for r in sample], dtype=float)
e = get('eligible')
i = 1.0 - e
b = get('baseline')
d = get('dose')
z = get('instrument')
w = get('weight')
y = get('outcome')
X = np.column_stack((i, e, b*i, b*e, d*i, d*e))
Z = np.column_stack((i, e, b*i, b*e, z*i, z*e))
assert np.linalg.matrix_rank(X) == 6 and np.linalg.matrix_rank(Z) == 6
# Exactly identified weighted 2SLS. The normal equations are Z'W(y-X beta)=0.
beta = np.linalg.solve(Z.T @ (w[:, None]*X), Z.T @ (w*y))
assert np.max(np.abs(Z.T @ (w*(y-X@beta)))) < 1e-7
mean_dose = {g: float(np.sum(w[e == g]*d[e == g])/np.sum(w[e == g])) for g in (0, 1)}
effects = {g: float(beta[4+g]*mean_dose[g]) for g in (0, 1)}
population = {int(r['eligible']): int(r['nonrecipient_population']) for r in census_rows}
assert all(v > 0 for v in population.values())
population_effect = sum(population[g]*effects[g] for g in (0, 1))/sum(population.values())

# Independent grouped, scalar IV check: remove each group's weighted intercept and baseline.
checks = {}
for g in (0, 1):
    m = e == g
    C = np.column_stack((np.ones(int(m.sum())), b[m]))
    W = w[m]
    def residual(v):
        return v - C @ np.linalg.solve(C.T @ (W[:, None]*C), C.T @ (W*v))
    zr, dr, yr = residual(z[m]), residual(d[m]), residual(y[m])
    slope = float(np.dot(W*zr, yr)/np.dot(W*zr, dr))
    assert np.isclose(slope, beta[4+g], rtol=1e-10, atol=1e-10)
    checks[str(g)] = {'group_n_obs': int(m.sum()), 'weighted_mean_dose': mean_dose[g], 'dose_slope': float(beta[4+g]), 'independent_dose_slope': slope}

n = len(sample)
result = {
    'task_id': 'applied_nonrecipient_population_iv',
    'platform': 'python',
    'estimates': [
        {'term': 'ineligible_effect', 'estimate': effects[0], 'se': None, 'n_obs': n},
        {'term': 'eligible_nonrecipient_effect', 'estimate': effects[1], 'se': None, 'n_obs': n},
        {'term': 'population_effect', 'estimate': population_effect, 'se': None, 'n_obs': n}
    ],
    'method_metadata': {
        'estimator': 'weighted 2SLS, exactly identified',
        'sample': 'recipient == 0, all village treatment statuses',
        'endogenous_columns': ['dose*(1-eligible)', 'dose*eligible'],
        'exogenous_columns': ['1-eligible', 'eligible', 'baseline*(1-eligible)', 'baseline*eligible'],
        'excluded_instruments': ['instrument*(1-eligible)', 'instrument*eligible'],
        'regression_weight': 'weight',
        'group_dose_average_weight': 'weight',
        'counterfactual': 'dose set to zero for every retained household; synthetic convention',
        'final_aggregation_weight': 'census nonrecipient_population only'
    },
    'diagnostics': {
        'n_obs': n,
        'group_checks': checks,
        'census_nonrecipient_population': population,
        'weighted_iv_moment_max_abs': float(np.max(np.abs(Z.T @ (w*(y-X@beta))))),
        'treated_values_in_sample': sorted({int(r['treated']) for r in sample})
    }
}
with open('result.json', 'w') as f:
    json.dump(result, f, indent=2, allow_nan=False)
    f.write('\n')
