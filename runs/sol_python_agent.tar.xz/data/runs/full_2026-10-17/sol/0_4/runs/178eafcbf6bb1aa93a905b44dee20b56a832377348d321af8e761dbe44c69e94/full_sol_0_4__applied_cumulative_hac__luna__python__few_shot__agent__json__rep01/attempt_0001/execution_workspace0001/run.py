import json

import numpy as np
import pandas as pd


data = pd.read_csv("input.csv", parse_dates=["date"]).sort_values("date").reset_index(drop=True)
change = np.log(data["vix"]).diff()
lag_columns = [change.shift(j).rename(f"lag_{j}") for j in range(1, 16)]
regression = pd.concat([np.log(data["sales"]).rename("log_sales"), *lag_columns], axis=1).dropna()

n = len(regression)
x = np.column_stack([np.ones(n), regression[[f"lag_{j}" for j in range(1, 16)]].to_numpy()])
y = regression["log_sales"].to_numpy()
beta = np.linalg.lstsq(x, y, rcond=None)[0]
residual = y - x @ beta
scores = x * residual[:, None]

meat = scores.T @ scores
for j in range(1, 16):
    weight = 1 - j / 16
    cross = scores[j:].T @ scores[:-j]
    meat += weight * (cross + cross.T)

bread = np.linalg.inv(x.T @ x)
covariance = (n / (n - x.shape[1])) * bread @ meat @ bread
contrast = np.r_[0.0, np.ones(15)]

def row(term, estimate, variance):
    return {"term": term, "estimate": float(estimate), "se": float(np.sqrt(variance)), "n_obs": n}

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        row("cumulative_response", contrast @ beta, contrast @ covariance @ contrast),
        row("lag_1", beta[1], covariance[1, 1]),
        row("lag_15", beta[15], covariance[15, 15]),
    ],
    "method_metadata": {
        "estimator": "OLS with intercept and 15 lagged log VIX changes",
        "vcov": "Newey-West HAC, Bartlett maximum lag 15, correction N/(N-16)",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
