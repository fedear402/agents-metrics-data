import json

import pandas as pd
from scipy import stats


data = pd.read_csv("input.csv", usecols=["group", "y"])
data["y"] = pd.to_numeric(data["y"], errors="raise")
sample = data.dropna(subset=["group", "y"])
groups = [part["y"].to_numpy() for _, part in sample.groupby("group")]
n_obs = len(sample)
n_groups = len(groups)
if n_groups < 2 or n_obs <= n_groups:
    raise ValueError("ANOVA needs at least two groups and residual degrees of freedom")

f_stat, p_value = stats.f_oneway(*groups)
results = {
    "task_id": "anova_oneway",
    "platform": "python",
    "estimates": [
        {"term": "F", "estimate": float(f_stat), "se": None, "n_obs": n_obs},
        {"term": "df_num", "estimate": float(n_groups - 1), "se": None, "n_obs": n_obs},
        {"term": "df_den", "estimate": float(n_obs - n_groups), "se": None, "n_obs": n_obs},
        {"term": "p_value", "estimate": float(p_value), "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {"estimator": "Classical one-way ANOVA", "vcov": "Pooled within-group variance"},
    "diagnostics": {},
}
with open("result.json", "w", encoding="utf-8") as output:
    json.dump(results, output, allow_nan=False, indent=2)
