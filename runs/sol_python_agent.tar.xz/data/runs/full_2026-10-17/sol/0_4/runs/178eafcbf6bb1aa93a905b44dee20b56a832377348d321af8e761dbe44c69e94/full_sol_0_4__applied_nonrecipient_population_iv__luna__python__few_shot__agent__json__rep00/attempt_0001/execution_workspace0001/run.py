import json

import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS


households = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")
sample = households.loc[households["recipient"].eq(0)].copy()
if sample.empty or set(sample["eligible"].unique()) != {0, 1}:
    raise ValueError("The nonrecipient sample must contain both eligibility groups")
if sample[["dose", "instrument", "baseline", "weight", "outcome"]].isna().any().any():
    raise ValueError("The estimation sample contains missing values")
if not sample["weight"].gt(0).all():
    raise ValueError("Regression weights must be positive")

g0 = 1 - sample["eligible"]
g1 = sample["eligible"]
exog = pd.DataFrame({
    "ineligible": g0,
    "eligible": g1,
    "baseline_ineligible": sample["baseline"] * g0,
    "baseline_eligible": sample["baseline"] * g1,
}, index=sample.index)
endog = pd.DataFrame({
    "dose_ineligible": sample["dose"] * g0,
    "dose_eligible": sample["dose"] * g1,
}, index=sample.index)
excluded = pd.DataFrame({
    "instrument_ineligible": sample["instrument"] * g0,
    "instrument_eligible": sample["instrument"] * g1,
}, index=sample.index)

fit = IV2SLS(sample["outcome"], exog, endog, excluded,
             weights=sample["weight"]).fit()
effects = {}
weighted_mean_dose = {}
for group, slope_name in [(0, "dose_ineligible"), (1, "dose_eligible")]:
    rows = sample["eligible"].eq(group)
    weighted_mean_dose[group] = float(np.average(sample.loc[rows, "dose"],
                                                  weights=sample.loc[rows, "weight"]))
    effects[group] = float(fit.params[slope_name] * weighted_mean_dose[group])

pop = census.set_index("eligible")["nonrecipient_population"]
if set(pop.index) != {0, 1} or pop.isna().any() or not pop.gt(0).all():
    raise ValueError("Census must contain one positive count for each group")
population_effect = float(np.average([effects[0], effects[1]],
                                     weights=[pop.loc[0], pop.loc[1]]))
n_obs = int(len(sample))
result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {"term": "ineligible_effect", "estimate": effects[0], "se": None, "n_obs": n_obs},
        {"term": "eligible_nonrecipient_effect", "estimate": effects[1], "se": None, "n_obs": n_obs},
        {"term": "population_effect", "estimate": population_effect, "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "sample": "all households with recipient=0",
        "counterfactual": "dose=0 for every retained household; synthetic attribution convention",
        "group_effect": "group dose slope times household-weighted mean dose",
        "population_aggregation": "nonrecipient_population census counts used only between groups",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "group_n_obs": {str(g): int(sample["eligible"].eq(g).sum()) for g in (0, 1)},
        "group_weighted_mean_dose": {str(g): weighted_mean_dose[g] for g in (0, 1)},
        "dose_slopes": {"ineligible": float(fit.params["dose_ineligible"]),
                        "eligible": float(fit.params["dose_eligible"])},
        "census_nonrecipient_population": {str(g): int(pop.loc[g]) for g in (0, 1)},
    },
}
with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output, indent=2, allow_nan=False)
    output.write("\n")
