import json
import numpy as np
import pandas as pd

crosswalk = pd.read_csv('crosswalk.csv')
trade = pd.read_csv('trade.csv')
areas = pd.read_csv('areas.csv')
employment = pd.read_csv('employment.csv')
outcomes = pd.read_csv('outcomes.csv')

assert crosswalk.code.is_unique
assert crosswalk.industry.nunique() == 4
assert not trade.duplicated(['period', 'code']).any()
assert not areas.duplicated(['area', 'period', 'vintage']).any()
assert not outcomes.duplicated(['area', 'period']).any()
assert not employment.duplicated(['area', 'period', 'vintage', 'industry']).any()
assert set(areas.vintage) == {'base', 'early'}
trade = trade.merge(crosswalk, on='code', validate='many_to_one')
assert len(trade) == 8
assert not trade.duplicated(['period', 'industry']).any()
assert (trade.groupby('period').price_index.nunique() == 1).all()
assert (trade.groupby('period').years.nunique() == 1).all()

cells = areas[['area', 'period', 'vintage']].merge(
    crosswalk[['industry']].drop_duplicates(), how='cross'
).merge(employment, on=['area', 'period', 'vintage', 'industry'], how='left', validate='one_to_one')
cells['employment'] = cells.employment.fillna(0)
national = cells.groupby(['period', 'vintage', 'industry'], as_index=False).employment.sum().rename(columns={'employment': 'national_employment'})
assert (national.national_employment > 0).all()
cells = cells.merge(national, on=['period', 'vintage', 'industry'], validate='many_to_one')
cells = cells.merge(areas, on=['area', 'period', 'vintage'], validate='many_to_one')
cells = cells.merge(trade, on=['period', 'industry'], validate='many_to_one')
change = np.where(cells.vintage.eq('base'), cells.us_change, cells.other_change)
cells['contribution'] = (cells.employment / cells.total_employment) * (change / cells.national_employment) / (cells.price_index / 100) / 1000 * (10 / cells.years)
exposures = cells.groupby(['area', 'period', 'vintage'], as_index=False).contribution.sum()
x = exposures.query("vintage == 'base'")[['area', 'period', 'contribution']].rename(columns={'contribution':'x'})
z = exposures.query("vintage == 'early'")[['area', 'period', 'contribution']].rename(columns={'contribution':'z'})
sample = outcomes.merge(x, on=['area', 'period'], validate='one_to_one').merge(z, on=['area', 'period'], validate='one_to_one')
base = areas.query("vintage == 'base'")[['area', 'period', 'population']]
sample = sample.merge(base, on=['area', 'period'], validate='one_to_one').sort_values(['area', 'period'])
assert len(sample) == 72
assert sample[['change_pp','period','control','x','z','population']].notna().all().all()
assert (sample.population > 0).all()

Y = sample.change_pp.to_numpy(float)
X = np.column_stack([np.ones(len(sample)), sample.period, sample.control, sample.x])
Z = np.column_stack([np.ones(len(sample)), sample.period, sample.control, sample.z])
w = sample.population.to_numpy(float)
ZX = Z.T @ (w[:, None] * X)
ZY = Z.T @ (w * Y)
beta = np.linalg.solve(ZX, ZY)

# Independent Frisch-Waugh-Lovell check for the just-identified IV slope.
C = X[:, :3]
cr_x = np.linalg.lstsq(C * np.sqrt(w[:, None]), sample.x.to_numpy(float) * np.sqrt(w), rcond=None)[0]
cr_z = np.linalg.lstsq(C * np.sqrt(w[:, None]), sample.z.to_numpy(float) * np.sqrt(w), rcond=None)[0]
cr_y = np.linalg.lstsq(C * np.sqrt(w[:, None]), Y * np.sqrt(w), rcond=None)[0]
rx = sample.x.to_numpy(float) - C @ cr_x
rz = sample.z.to_numpy(float) - C @ cr_z
ry = Y - C @ cr_y
check_slope = np.dot(w * rz, ry) / np.dot(w * rz, rx)
assert np.isclose(beta[3], check_slope, rtol=1e-10, atol=1e-10)

lookup = sample.set_index(['area', 'period'])
values = {
    'iv_slope': float(beta[3]),
    'exposure_area0_period0': float(lookup.loc[(0, 0), 'x']),
    'exposure_area0_period1': float(lookup.loc[(0, 1), 'x']),
    'instrument_area0_period0': float(lookup.loc[(0, 0), 'z']),
}
result = {
    'task_id': 'applied_multivintage_trade_iv',
    'platform': 'python',
    'estimates': [{'term': key, 'estimate': val, 'se': None, 'n_obs': 72} for key, val in values.items()],
    'method_metadata': {'estimator': 'population-weighted, just-identified 2SLS', 'regressors': ['intercept', 'period', 'control', 'x'], 'instruments': ['intercept', 'period', 'control', 'z'], 'employment_missing_cells': 'zero'},
    'diagnostics': {'estimation_rows': int(len(sample)), 'industry_count': int(crosswalk.industry.nunique()), 'trade_rows': int(len(trade)), 'iv_slope_fwl_check': float(check_slope), 'iv_slope_check_abs_difference': float(abs(beta[3] - check_slope))},
}
with open('result.json', 'w') as f:
    json.dump(result, f, indent=2)
    f.write('\n')
with open('verification.txt', 'w') as f:
    f.write('Checked five supplied CSV files. Crosswalk has four unique industries; trade has one row per period and industry.\n')
    f.write('Filled omitted area-industry employment cells with zero before national employment sums. All national denominators are positive.\n')
    f.write('Estimation sample has 72 complete area-period rows with positive base population weights.\n')
    f.write('Weighted just-identified IV normal equations use intercept, period, control, and z as instruments.\n')
    f.write(f'Independent weighted residualization ratio gives slope {check_slope:.15g}; direct IV gives {beta[3]:.15g}. Absolute difference {abs(check_slope-beta[3]):.3g}.\n')
    f.write('Uncertainty measures were not requested; each standard error is null.\n')
print(json.dumps(result, indent=2))
