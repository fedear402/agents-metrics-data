import json

import numpy as np
import pandas as pd


crosswalk = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv").merge(crosswalk, on="code", validate="many_to_one")
areas = pd.read_csv("areas.csv")
employment = pd.read_csv("employment.csv")
outcomes = pd.read_csv("outcomes.csv")

assert len(crosswalk.industry.unique()) == 4
assert not trade.industry.isna().any()
assert not trade.duplicated(["period", "industry"]).any()
assert areas.groupby(["area", "period"]).vintage.nunique().eq(2).all()

national = employment.groupby(["period", "vintage", "industry"], as_index=False).employment.sum()
national = national.rename(columns={"employment": "national_employment"})
assert national.national_employment.gt(0).all()

# The full grid makes omitted employment cells equal to zero.
grid = areas[["area", "period", "vintage", "total_employment"]].merge(
    crosswalk[["industry"]].drop_duplicates(), how="cross"
)
grid = grid.merge(employment, on=["area", "period", "vintage", "industry"], how="left", validate="one_to_one")
grid["employment"] = grid.employment.fillna(0)
grid = grid.merge(national, on=["period", "vintage", "industry"], validate="many_to_one")
grid = grid.merge(trade.drop(columns="code"), on=["period", "industry"], validate="many_to_one")
grid["change"] = np.where(grid.vintage.eq("base"), grid.us_change, grid.other_change)
grid["component"] = (
    grid.employment / grid.total_employment
    * grid.change / grid.national_employment
    / (grid.price_index / 100)
    / 1000
    * (10 / grid.years)
)
exposures = grid.groupby(["area", "period", "vintage"], as_index=False).component.sum()
exposures = exposures.pivot(index=["area", "period"], columns="vintage", values="component").reset_index()
exposures = exposures.rename(columns={"base": "x", "early": "z"})

sample = outcomes.merge(exposures, on=["area", "period"], validate="one_to_one")
sample = sample.merge(
    areas.loc[areas.vintage.eq("base"), ["area", "period", "population"]],
    on=["area", "period"], validate="one_to_one"
)
assert len(sample) == 72 and not sample.isna().any().any()

w = sample.population.to_numpy(dtype=float)
y = sample.change_pp.to_numpy(dtype=float)
X = np.column_stack((np.ones(len(sample)), sample.period, sample.control, sample.x))
Z = np.column_stack((np.ones(len(sample)), sample.period, sample.control, sample.z))
assert np.linalg.matrix_rank(Z.T @ (w[:, None] * X)) == 4

# Exactly identified weighted 2SLS: Z' W (y - X beta) = 0.
beta = np.linalg.solve(Z.T @ (w[:, None] * X), Z.T @ (w * y))

def value(area, period, column):
    return float(sample.loc[sample.area.eq(area) & sample.period.eq(period), column].iloc[0])

terms = {
    "iv_slope": float(beta[3]),
    "exposure_area0_period0": value(0, 0, "x"),
    "exposure_area0_period1": value(0, 1, "x"),
    "instrument_area0_period0": value(0, 0, "z"),
}
result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [
        {"term": term, "estimate": estimate, "se": None, "n_obs": 72}
        for term, estimate in terms.items()
    ],
    "method_metadata": {
        "estimator": "weighted exactly identified 2SLS",
        "outcome": "change_pp",
        "endogenous_regressor": "x",
        "instrument": "z",
        "exogenous_columns": ["intercept", "period", "control"],
        "weight": "base-vintage population",
        "exposure_units": "thousands of real dollars per worker per decade",
    },
    "diagnostics": {
        "n_obs": len(sample),
        "n_areas": int(sample.area.nunique()),
        "n_periods": int(sample.period.nunique()),
        "weighted_iv_moment_max_abs": float(np.max(np.abs(Z.T @ (w * (y - X @ beta))))),
    },
}
with open("result.json", "w") as file:
    json.dump(result, file, indent=2, allow_nan=False)
