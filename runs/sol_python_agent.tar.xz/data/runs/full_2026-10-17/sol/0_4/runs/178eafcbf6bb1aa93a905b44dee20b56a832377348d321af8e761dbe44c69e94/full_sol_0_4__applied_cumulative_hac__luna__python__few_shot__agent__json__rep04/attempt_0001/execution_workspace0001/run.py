import json

import numpy as np
import pandas as pd


data = pd.read_csv("input.csv", parse_dates=["date"])
data = data.sort_values("date").reset_index(drop=True)
change = np.log(data["vix"]).diff()
regressors = pd.concat(
    [change.shift(lag).rename(f"lag_{lag}") for lag in range(1, 16)], axis=1
)
sample = pd.concat([np.log(data["sales"]).rename("log_sales"), regressors], axis=1).dropna()
n = len(sample)
x = np.column_stack((np.ones(n), sample[[f"lag_{lag}" for lag in range(1, 16)]].to_numpy()))
y = sample["log_sales"].to_numpy()
beta = np.linalg.lstsq(x, y, rcond=None)[0]
scores = x * (y - x @ beta)[:, None]
meat = scores.T @ scores
for lag in range(1, 16):
    product = scores[lag:].T @ scores[:-lag]
    meat += (1 - lag / 16) * (product + product.T)
bread = np.linalg.inv(x.T @ x)
covariance = (n / (n - 16)) * bread @ meat @ bread

contrast = np.r_[0.0, np.ones(15)]
def row(term, estimate, variance):
    return {"term": term, "estimate": float(estimate), "se": float(np.sqrt(variance)), "n_obs": n}

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        row("cumulative_response", contrast @ beta, contrast @ covariance @ contrast),
        row("lag_1", beta[1], covariance[1, 1]),
        row("lag_15", beta[15], covariance[15, 15]),
    ],
    "method_metadata": {
        "estimator": "OLS of log(sales) on intercept and 15 observed-row lags of diff(log(vix))",
        "vcov": "Newey-West Bartlett HAC, maxlag=15, correction=N/(N-16)",
    },
    "diagnostics": {},
}
with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
