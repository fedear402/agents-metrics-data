import json

import numpy as np
import pandas as pd


data = pd.read_csv("input.csv")
sample = data.loc[data["score"].abs() < 1].copy()
score = sample["score"].to_numpy(dtype=float)
right = (score >= 0).astype(float)
weights = 1 - np.abs(score)
outcomes = sample[["earnings", "participated"]].to_numpy(dtype=float)
design = np.column_stack((np.ones(len(score)), right, score, right * score))
contrast = np.array([0.0, 1.0, 0.0, 0.0])

bread = np.linalg.inv(design.T @ (weights[:, None] * design))
coefficients = bread @ design.T @ (weights[:, None] * outcomes)
residuals = outcomes - design @ coefficients
jumps = contrast @ coefficients
loading = weights * (design @ bread @ contrast)
influence = loading[:, None] * residuals
joint = influence.T @ influence
reduced_form, first_stage = jumps
gradient = np.array([1 / first_stage, -reduced_form / first_stage**2])
treatment_effect = reduced_form / first_stage
treatment_variance = float(gradient @ joint @ gradient)

# Independent point-estimate check: fit each side with its own weighted line.
side_limits = []
for is_right in (False, True):
    selected = (right == 1) if is_right else (right == 0)
    side_design = np.column_stack((np.ones(selected.sum()), score[selected]))
    root_weights = np.sqrt(weights[selected])
    side_coef = np.linalg.lstsq(
        root_weights[:, None] * side_design,
        root_weights[:, None] * outcomes[selected],
        rcond=None,
    )[0]
    side_limits.append(side_coef[0])
side_jumps = side_limits[1] - side_limits[0]
assert np.allclose(jumps, side_jumps, rtol=1e-10, atol=1e-10)

# Independent variance check: the ratio influence equals a single combined
# outcome influence divided by the first-stage jump.
combined_residual = residuals[:, 0] - treatment_effect * residuals[:, 1]
identity_variance = np.sum((loading * combined_residual / first_stage) ** 2)
assert np.isclose(treatment_variance, identity_variance, rtol=1e-10, atol=1e-10)

n_obs = int(len(sample))
rows = [
    {"term": "treatment_effect", "estimate": float(treatment_effect),
     "se": float(np.sqrt(treatment_variance)), "n_obs": n_obs},
    {"term": "reduced_form", "estimate": float(reduced_form),
     "se": float(np.sqrt(joint[0, 0])), "n_obs": n_obs},
    {"term": "first_stage", "estimate": float(first_stage),
     "se": float(np.sqrt(joint[1, 1])), "n_obs": n_obs},
]
output = {
    "task_id": "applied_fuzzy_rd", "platform": "python", "estimates": rows,
    "method_metadata": {
        "estimator": "Triangular-weighted local linear fuzzy RD; separate slopes by cutoff side; bandwidth 1",
        "vcov": "Joint heteroskedasticity-robust HC0 sandwich and delta method; no degrees-of-freedom correction",
    },
    "diagnostics": {},
}
with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)

with open("verification.txt", "w") as stream:
    stream.write(f"Input observations: {len(data)}; estimation observations: {n_obs}.\n")
    stream.write(f"Left: {int((right == 0).sum())}; right: {int((right == 1).sum())}.\n")
    stream.write("Sample uses abs(score) < 1; right means score >= 0; weights equal 1 - abs(score).\n")
    stream.write("Design columns: intercept, right, score, right times score; right coefficient is the jump.\n")
    stream.write(f"Joint-model jumps (earnings, participation): {jumps.tolist()}.\n")
    stream.write(f"Separate-side weighted-line jumps: {side_jumps.tolist()}; agreement passed.\n")
    stream.write(f"Joint HC0 covariance: {joint.tolist()}.\n")
    stream.write(f"Delta-method ratio variance: {treatment_variance:.15g}.\n")
    stream.write(f"Combined-outcome influence variance: {identity_variance:.15g}; agreement passed.\n")
    stream.write("No bias correction or degrees-of-freedom correction applied.\n")
