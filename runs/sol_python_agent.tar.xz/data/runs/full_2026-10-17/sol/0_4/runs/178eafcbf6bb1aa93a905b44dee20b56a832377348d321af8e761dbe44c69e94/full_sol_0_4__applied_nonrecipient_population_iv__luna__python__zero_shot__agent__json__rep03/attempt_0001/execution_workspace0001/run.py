import csv
import json
import numpy as np

with open('households.csv', newline='') as handle:
    rows = list(csv.DictReader(handle))
with open('census.csv', newline='') as handle:
    census = {int(r['eligible']): int(r['nonrecipient_population']) for r in csv.DictReader(handle)}

sample = [r for r in rows if int(r['recipient']) == 0]
n = len(sample)
def col(name):
    return np.array([float(r[name]) for r in sample], dtype=float)
e = col('eligible')
d = col('dose')
b = col('baseline')
z = col('instrument')
w = col('weight')
y = col('outcome')
g0, g1 = 1 - e, e
X_exog = np.column_stack((g0, g1, b*g0, b*g1))
X = np.column_stack((X_exog, d*g0, d*g1))
Z = np.column_stack((X_exog, z*g0, z*g1))
# The exactly identified weighted IV normal equations are Z'W(y-X beta)=0.
beta = np.linalg.solve(Z.T @ (w[:, None]*X), Z.T @ (w*y))
mean_dose = {g: float(np.sum(w[e == g]*d[e == g])/np.sum(w[e == g])) for g in (0, 1)}
effects = {0: float(beta[4]*mean_dose[0]), 1: float(beta[5]*mean_dose[1])}
population = sum(census[g]*effects[g] for g in (0, 1))/sum(census.values())

# Independent calculation: within each group, partial out the constant and baseline
# from dose, instrument, and outcome using weighted least squares.
independent_slopes = {}
for group in (0, 1):
    mask = e == group
    controls = np.column_stack((np.ones(mask.sum()), b[mask]))
    wg = w[mask]
    def residual(v):
        coef = np.linalg.solve(controls.T @ (wg[:, None]*controls), controls.T @ (wg*v))
        return v-controls @ coef
    rz, rd, ry = residual(z[mask]), residual(d[mask]), residual(y[mask])
    independent_slopes[group] = float(np.sum(wg*rz*ry)/np.sum(wg*rz*rd))
assert np.allclose([beta[4], beta[5]], [independent_slopes[0], independent_slopes[1]], rtol=1e-10, atol=1e-10)
assert set(census) == {0, 1} and np.all(w > 0)

result = {
    'task_id': 'applied_nonrecipient_population_iv',
    'platform': 'python',
    'estimates': [
        {'term': 'ineligible_effect', 'estimate': effects[0], 'se': None, 'n_obs': n},
        {'term': 'eligible_nonrecipient_effect', 'estimate': effects[1], 'se': None, 'n_obs': n},
        {'term': 'population_effect', 'estimate': population, 'se': None, 'n_obs': n},
    ],
    'method_metadata': {
        'estimator': 'Exactly identified weighted 2SLS',
        'sample': 'All household rows with recipient=0',
        'regressors': ['1-eligible', 'eligible', 'baseline*(1-eligible)', 'baseline*eligible', 'dose*(1-eligible)', 'dose*eligible'],
        'excluded_instruments': ['instrument*(1-eligible)', 'instrument*eligible'],
        'weight': 'weight',
        'counterfactual': 'Dose set to zero for every retained household; synthetic attribution convention',
        'aggregation': 'Group slopes times household-weighted group mean dose, then census nonrecipient_population weighting'
    },
    'diagnostics': {
        'n_obs': n,
        'n_by_eligibility': {str(g): int(np.sum(e == g)) for g in (0, 1)},
        'n_by_eligibility_and_treated': {f'{g},{t}': int(np.sum((e == g) & (col('treated') == t))) for g in (0, 1) for t in (0, 1)},
        'dose_slopes': {str(g): float(beta[4+g]) for g in (0, 1)},
        'weighted_mean_dose': {str(g): mean_dose[g] for g in (0, 1)},
        'census_nonrecipient_population': {str(g): census[g] for g in (0, 1)},
        'weighted_moment_max_abs': float(np.max(np.abs(Z.T @ (w*(y-X@beta))))),
        'independent_residualized_iv_slopes': {str(g): independent_slopes[g] for g in (0, 1)}
    }
}
with open('result.json', 'w') as handle:
    json.dump(result, handle, indent=2, allow_nan=False)
    handle.write('\n')
