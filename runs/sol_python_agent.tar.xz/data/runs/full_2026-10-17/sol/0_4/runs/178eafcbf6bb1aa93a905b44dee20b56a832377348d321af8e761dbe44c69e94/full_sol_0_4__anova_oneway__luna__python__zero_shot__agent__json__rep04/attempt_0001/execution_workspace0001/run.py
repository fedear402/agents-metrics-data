import json

import pandas as pd
from scipy import stats


data = pd.read_csv("input.csv", usecols=["group", "y"])
sample = data.dropna(subset=["group", "y"])
groups = [part["y"].to_numpy(dtype=float) for _, part in sample.groupby("group")]
n_obs = len(sample)
df_num = len(groups) - 1
df_den = n_obs - len(groups)
if df_num < 1 or df_den < 1:
    raise ValueError("One-way ANOVA requires at least two groups and residual degrees of freedom")

f_stat, p_value = stats.f_oneway(*groups)
values = {"F": f_stat, "df_num": df_num, "df_den": df_den, "p_value": p_value}
result = {
    "task_id": "anova_oneway",
    "platform": "python",
    "estimates": [
        {"term": term, "estimate": float(value), "se": None, "n_obs": n_obs}
        for term, value in values.items()
    ],
    "method_metadata": {"estimator": "Classical one-way ANOVA", "vcov": "Pooled within-group variance"},
    "diagnostics": {},
}
with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output, indent=2, allow_nan=False)
