import csv
import json

import numpy as np


with open("households.csv", newline="") as handle:
    households = list(csv.DictReader(handle))
with open("census.csv", newline="") as handle:
    census = list(csv.DictReader(handle))

rows = [row for row in households if int(row["recipient"]) == 0]
n_obs = len(rows)
eligible = np.array([int(row["eligible"]) for row in rows])
assert set(eligible) == {0, 1}
ineligible = 1 - eligible
dose = np.array([float(row["dose"]) for row in rows])
baseline = np.array([float(row["baseline"]) for row in rows])
instrument = np.array([float(row["instrument"]) for row in rows])
weight = np.array([float(row["weight"]) for row in rows])
outcome = np.array([float(row["outcome"]) for row in rows])
assert np.all(weight > 0)

exogenous = np.column_stack((ineligible, eligible, baseline * ineligible, baseline * eligible))
endogenous = np.column_stack((dose * ineligible, dose * eligible))
excluded = np.column_stack((instrument * ineligible, instrument * eligible))
x = np.column_stack((exogenous, endogenous))
z = np.column_stack((exogenous, excluded))
sqrt_weight = np.sqrt(weight)[:, None]
weighted_x = x * sqrt_weight
weighted_z = z * sqrt_weight
weighted_y = outcome * sqrt_weight[:, 0]
first_stage = np.linalg.lstsq(weighted_z, weighted_x, rcond=None)[0]
projected_x = weighted_z @ first_stage
coefficients = np.linalg.lstsq(projected_x, weighted_y, rcond=None)[0]
assert np.linalg.matrix_rank(weighted_z) == 6
assert np.linalg.matrix_rank(projected_x) == 6

group_effects = []
group_counts = {}
group_mean_dose = {}
for group in (0, 1):
    selection = eligible == group
    mean_dose = np.average(dose[selection], weights=weight[selection])
    group_effects.append(float(coefficients[4 + group] * mean_dose))
    group_counts[str(group)] = int(selection.sum())
    group_mean_dose[str(group)] = float(mean_dose)

population = {int(row["eligible"]): int(row["nonrecipient_population"]) for row in census}
assert set(population) == {0, 1}
population_effect = sum(population[group] * group_effects[group] for group in (0, 1)) / sum(population.values())
terms = ("ineligible_effect", "eligible_nonrecipient_effect", "population_effect")
values = (*group_effects, population_effect)
result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {"term": term, "estimate": float(value), "se": None, "n_obs": n_obs}
        for term, value in zip(terms, values)
    ],
    "method_metadata": {
        "estimator": "weighted two-stage least squares",
        "sample": "all household rows with recipient=0",
        "exogenous": ["1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"],
        "endogenous": ["dose*(1-eligible)", "dose*eligible"],
        "excluded_instruments": ["instrument*(1-eligible)", "instrument*eligible"],
        "intercept": "none beyond the two eligibility indicators",
        "regression_weight": "weight",
        "group_effect": "fitted group dose slope times household-weighted mean dose among retained rows",
        "counterfactual": "dose=0 for every retained household; synthetic attribution convention",
        "population_aggregation": "census nonrecipient_population counts weight the two group effects only",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "group_n_obs": group_counts,
        "group_weighted_mean_dose": group_mean_dose,
        "dose_slopes": {str(group): float(coefficients[4 + group]) for group in (0, 1)},
        "census_nonrecipient_population": {str(group): population[group] for group in (0, 1)},
        "maximum_absolute_weighted_instrument_moment": float(np.max(np.abs(z.T @ (weight * (outcome - x @ coefficients))))),
    },
}
with open("result.json", "w") as handle:
    json.dump(result, handle, indent=2)
    handle.write("\n")
