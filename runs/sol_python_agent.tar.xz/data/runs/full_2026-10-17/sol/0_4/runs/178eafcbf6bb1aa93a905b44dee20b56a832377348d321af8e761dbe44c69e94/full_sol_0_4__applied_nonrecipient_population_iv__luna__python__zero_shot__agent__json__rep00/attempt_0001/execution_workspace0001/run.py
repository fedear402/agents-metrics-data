import csv
import json
import numpy as np

with open('households.csv', newline='') as file:
    households = list(csv.DictReader(file))
with open('census.csv', newline='') as file:
    census = list(csv.DictReader(file))

rows = [row for row in households if int(row['recipient']) == 0]
n_obs = len(rows)
eligible = np.array([int(row['eligible']) for row in rows], dtype=int)
assert set(eligible) == {0, 1}
assert all(int(row['recipient']) == 0 for row in rows)
assert {(int(row['eligible']), int(row['treated'])) for row in rows} == {(0, 0), (0, 1), (1, 0)}
dose = np.array([float(row['dose']) for row in rows])
baseline = np.array([float(row['baseline']) for row in rows])
instrument = np.array([float(row['instrument']) for row in rows])
weight = np.array([float(row['weight']) for row in rows])
outcome = np.array([float(row['outcome']) for row in rows])
assert np.all(weight > 0)
ineligible = 1 - eligible
x = np.column_stack((ineligible, eligible, baseline * ineligible,
                     baseline * eligible, dose * ineligible, dose * eligible))
z = np.column_stack((ineligible, eligible, baseline * ineligible,
                     baseline * eligible, instrument * ineligible,
                     instrument * eligible))
assert np.linalg.matrix_rank(z) == 6
# Just-identified weighted 2SLS: X'WZ(Z'WZ)^-1Z'WX beta = X'WZ(Z'WZ)^-1Z'Wy.
# Its moment-equation equivalent avoids an explicit matrix inverse.
beta = np.linalg.solve(z.T @ (weight[:, None] * x), z.T @ (weight * outcome))
mean_dose = {
    group: float(np.average(dose[eligible == group], weights=weight[eligible == group]))
    for group in (0, 1)
}
effects = {0: float(beta[4] * mean_dose[0]), 1: float(beta[5] * mean_dose[1])}
population = {int(row['eligible']): int(row['nonrecipient_population']) for row in census}
assert set(population) == {0, 1} and all(value > 0 for value in population.values())
population_effect = sum(population[group] * effects[group] for group in (0, 1)) / sum(population.values())
results = [('ineligible_effect', effects[0]),
           ('eligible_nonrecipient_effect', effects[1]),
           ('population_effect', population_effect)]
output = {
    'task_id': 'applied_nonrecipient_population_iv',
    'platform': 'python',
    'estimates': [{'term': term, 'estimate': value, 'se': None, 'n_obs': n_obs}
                  for term, value in results],
    'method_metadata': {
        'estimator': 'weighted 2SLS, just identified',
        'sample': 'recipient=0 households in both village treatment statuses',
        'regressors': ['1-eligible', 'eligible', 'baseline*(1-eligible)',
                       'baseline*eligible', 'dose*(1-eligible)', 'dose*eligible'],
        'excluded_instruments': ['instrument*(1-eligible)', 'instrument*eligible'],
        'weight': 'household weight for estimation and within-group dose means',
        'counterfactual': 'dose=0 for every retained household, by stated synthetic convention',
        'aggregation': 'census nonrecipient_population used only between eligibility groups'
    },
    'diagnostics': {
        'n_obs': n_obs,
        'group_n_obs': {str(group): int(np.sum(eligible == group)) for group in (0, 1)},
        'village_status_n_obs': {
            f'{group},{status}': sum(int(row['eligible']) == group and int(row['treated']) == status for row in rows)
            for group in (0, 1) for status in (0, 1)
        },
        'weighted_mean_dose': {str(group): mean_dose[group] for group in (0, 1)},
        'dose_slopes': {'0': float(beta[4]), '1': float(beta[5])},
        'census_nonrecipient_population': {str(group): population[group] for group in (0, 1)},
        'max_weighted_instrument_moment': float(np.max(np.abs(z.T @ (weight * (outcome - x @ beta)))))
    }
}
with open('result.json', 'w') as file:
    json.dump(output, file, indent=2, allow_nan=False)
    file.write('\n')
