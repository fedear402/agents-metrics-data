import csv
import json
from collections import defaultdict
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent

def read_csv(name):
    with (ROOT / name).open(newline='') as handle:
        return list(csv.DictReader(handle))

crosswalk = {r['code']: int(r['industry']) for r in read_csv('crosswalk.csv')}
trade = read_csv('trade.csv')
areas = read_csv('areas.csv')
employment = read_csv('employment.csv')
outcomes = read_csv('outcomes.csv')
assert len(set(crosswalk.values())) == 4

trade_by_period = defaultdict(dict)
for r in trade:
    p = int(r['period'])
    j = crosswalk[r['code']]
    assert j not in trade_by_period[p]
    trade_by_period[p][j] = r
assert all(set(rows) == set(crosswalk.values()) for rows in trade_by_period.values())

area_data = {}
for r in areas:
    key = (int(r['area']), int(r['period']), r['vintage'])
    assert key not in area_data
    area_data[key] = r

jobs = defaultdict(float)
for r in employment:
    key = (int(r['area']), int(r['period']), r['vintage'], int(r['industry']))
    assert key[:3] in area_data
    assert key[3] in crosswalk.values()
    jobs[key] += float(r['employment'])

national = defaultdict(float)
for (a, p, v, j), count in jobs.items():
    national[p, v, j] += count
assert all(national[p, v, j] > 0 for p in trade_by_period for v in ('base', 'early') for j in crosswalk.values())

exposures = {}
for a, p, v in area_data:
    rows = trade_by_period[p]
    assert len({float(r['price_index']) for r in rows.values()}) == 1
    assert len({float(r['years']) for r in rows.values()}) == 1
    total = float(area_data[a, p, v]['total_employment'])
    change_field = 'us_change' if v == 'base' else 'other_change'
    exposures[a, p, v] = sum(
        jobs[a, p, v, j] / total
        * float(rows[j][change_field]) / national[p, v, j]
        / (float(rows[j]['price_index']) / 100.0) / 1000.0
        * (10.0 / float(rows[j]['years']))
        for j in crosswalk.values()
    )

records = []
for r in outcomes:
    a, p = int(r['area']), int(r['period'])
    assert (a, p, 'base') in area_data and (a, p, 'early') in area_data
    records.append((a, p, float(r['control']), float(r['change_pp']),
                    exposures[a, p, 'base'], exposures[a, p, 'early'],
                    float(area_data[a, p, 'base']['population'])))
records.sort()
assert len(records) == 72 and len({(r[0], r[1]) for r in records}) == 72

D = np.asarray(records, dtype=float)
C = np.column_stack((np.ones(len(D)), D[:, 1], D[:, 2]))
X = np.column_stack((C, D[:, 4]))
Z = np.column_stack((C, D[:, 5]))
y = D[:, 3]
w = D[:, 6]
assert np.all(w > 0)
# Weighted IV normal equations, including every exogenous regressor as an instrument.
beta = np.linalg.solve(Z.T @ (w[:, None] * X), Z.T @ (w * y))

# Independent check: weighted Frisch-Waugh-Lovell residualization.
gram = C.T @ (w[:, None] * C)
resid = lambda vector: vector - C @ np.linalg.solve(gram, C.T @ (w * vector))
x_tilde, z_tilde, y_tilde = map(resid, (D[:, 4], D[:, 5], y))
independent_slope = np.dot(w * z_tilde, y_tilde) / np.dot(w * z_tilde, x_tilde)
assert np.isclose(beta[3], independent_slope, rtol=1e-11, atol=1e-11)
assert abs(np.dot(w * z_tilde, x_tilde)) > 0

estimates = [
    ('iv_slope', beta[3]),
    ('exposure_area0_period0', exposures[0, 0, 'base']),
    ('exposure_area0_period1', exposures[0, 1, 'base']),
    ('instrument_area0_period0', exposures[0, 0, 'early']),
]
result = {
    'task_id': 'applied_multivintage_trade_iv',
    'platform': 'python',
    'estimates': [{'term': term, 'estimate': float(value), 'se': None, 'n_obs': len(records)}
                  for term, value in estimates],
    'method_metadata': {
        'estimator': 'weighted exactly identified 2SLS',
        'regressors': ['intercept', 'period', 'control', 'x'],
        'instruments': ['intercept', 'period', 'control', 'z'],
        'weight': 'base-vintage population',
        'exposure_unit': 'thousands of real dollars per worker per decade',
    },
    'diagnostics': {
        'n_obs': len(records),
        'n_industries': len(set(crosswalk.values())),
        'independent_fwl_slope': float(independent_slope),
        'weighted_first_stage_residual_covariance': float(np.dot(w * z_tilde, x_tilde)),
    },
}
with (ROOT / 'result.json').open('w') as handle:
    json.dump(result, handle, indent=2, allow_nan=False)
    handle.write('\n')
print(json.dumps(result, indent=2))
