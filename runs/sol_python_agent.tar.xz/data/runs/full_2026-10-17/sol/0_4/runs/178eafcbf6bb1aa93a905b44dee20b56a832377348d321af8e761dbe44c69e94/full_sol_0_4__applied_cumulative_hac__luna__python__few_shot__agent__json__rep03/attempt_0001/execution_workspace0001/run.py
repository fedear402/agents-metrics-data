import json

import numpy as np
import pandas as pd


data = pd.read_csv("input.csv", parse_dates=["date"])
data = data.sort_values("date").reset_index(drop=True)
change = np.log(data["vix"]).diff()
regressors = pd.DataFrame({f"lag_{j}": change.shift(j) for j in range(1, 16)})
sample = regressors.assign(log_sales=np.log(data["sales"])).dropna()
N = len(sample)
X = np.column_stack((np.ones(N), sample[[f"lag_{j}" for j in range(1, 16)]].to_numpy()))
y = sample["log_sales"].to_numpy()
beta = np.linalg.lstsq(X, y, rcond=None)[0]
scores = X * (y - X @ beta)[:, None]
meat = scores.T @ scores
for j in range(1, 16):
    product = scores[j:].T @ scores[:-j]
    meat += (1 - j / 16) * (product + product.T)
bread = np.linalg.inv(X.T @ X)
covariance = (N / (N - 16)) * bread @ meat @ bread
contrast = np.r_[0.0, np.ones(15)]


def row(term, estimate, variance):
    return {"term": term, "estimate": float(estimate), "se": float(np.sqrt(variance)), "n_obs": N}


result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        row("cumulative_response", contrast @ beta, contrast @ covariance @ contrast),
        row("lag_1", beta[1], covariance[1, 1]),
        row("lag_15", beta[15], covariance[15, 15]),
    ],
    "method_metadata": {
        "estimator": "OLS of log sales on intercept and 15 lagged log VIX changes",
        "vcov": "Bartlett Newey-West HAC, max lag 15, correction N/(N-16)",
    },
    "diagnostics": {},
}
with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
