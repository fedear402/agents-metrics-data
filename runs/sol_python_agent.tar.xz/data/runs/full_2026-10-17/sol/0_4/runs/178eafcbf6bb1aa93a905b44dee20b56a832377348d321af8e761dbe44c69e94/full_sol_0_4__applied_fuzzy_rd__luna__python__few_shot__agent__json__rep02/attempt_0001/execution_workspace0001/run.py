import json

import numpy as np
import pandas as pd


data = pd.read_csv("input.csv")
sample = data.loc[data["score"].abs() < 1].copy()
score = sample["score"].to_numpy(dtype=float)
right = (score >= 0).astype(float)
weights = 1 - np.abs(score)
design = np.column_stack((np.ones(len(sample)), score, right, right * score))
outcomes = sample[["earnings", "participated"]].to_numpy(dtype=float)

bread = np.linalg.inv(design.T @ (weights[:, None] * design))
coefficients = bread @ design.T @ (weights[:, None] * outcomes)
residuals = outcomes - design @ coefficients
contrast = np.array([0.0, 0.0, 1.0, 0.0])
jumps = contrast @ coefficients
loading = weights * (design @ bread @ contrast)
influence = loading[:, None] * residuals
joint_covariance = influence.T @ influence

reduced_form, first_stage = jumps
gradient = np.array([1 / first_stage, -reduced_form / first_stage**2])
treatment_effect = reduced_form / first_stage
treatment_se = np.sqrt(gradient @ joint_covariance @ gradient)
n_obs = len(sample)

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": float(treatment_effect), "se": float(treatment_se), "n_obs": n_obs},
        {"term": "reduced_form", "estimate": float(reduced_form), "se": float(np.sqrt(joint_covariance[0, 0])), "n_obs": n_obs},
        {"term": "first_stage", "estimate": float(first_stage), "se": float(np.sqrt(joint_covariance[1, 1])), "n_obs": n_obs},
    ],
    "method_metadata": {"estimator": "triangular-weighted local-linear fuzzy RD, bandwidth 1", "vcov": "joint empirical HC0 sandwich; delta method for ratio"},
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
