import json
import numpy as np
import pandas as pd

DATA = pd.read_csv('input.csv')
required = ['region_id', 'industry_id', 'share', 'shock', 'region_weight', 'x', 'y']
assert list(DATA.columns) == required
assert DATA[required].notna().all().all()
for column, group in [('shock', 'industry_id'), ('region_weight', 'region_id'),
                      ('x', 'region_id'), ('y', 'region_id')]:
    assert DATA.groupby(group)[column].nunique().eq(1).all()
regions = DATA[['region_id', 'region_weight', 'x', 'y']].drop_duplicates('region_id').sort_values('region_id')
industries = DATA[['industry_id', 'shock']].drop_duplicates('industry_id').sort_values('industry_id')
shares = DATA.pivot(index='region_id', columns='industry_id', values='share')
shares = shares.reindex(index=regions.region_id, columns=industries.industry_id)
assert shares.notna().all().all() and len(DATA) == shares.size
S = shares.to_numpy(dtype=float)
assert np.allclose(S.sum(axis=1), 1, rtol=0, atol=1e-10)
e = regions.region_weight.to_numpy(dtype=float).copy()
assert np.all(e > 0)
e /= e.sum()
g = industries.shock.to_numpy(dtype=float)
x = regions.x.to_numpy(dtype=float)
y = regions.y.to_numpy(dtype=float)
z = S @ g
regional = np.column_stack((y, x, z))
centered = regional - e @ regional
mass = e @ S
assert np.all(mass > 0)
aggregated = (S.T @ (e[:, None] * centered)) / mass[:, None]
N = len(g)
assert N > 2

def shock_iv(dependent, endogenous):
    X = np.column_stack((np.ones(N), endogenous))
    Z = np.column_stack((np.ones(N), g))
    cross = Z.T @ (mass[:, None] * X)
    beta = np.linalg.solve(cross, Z.T @ (mass * dependent))
    residual = dependent - X @ beta
    scores = Z * (mass * residual)[:, None]
    bread = np.linalg.inv(cross)
    cov = (N / (N - 2)) * bread @ (scores.T @ scores) @ bread.T
    return float(beta[1]), float(np.sqrt(cov[1, 1]))

effect, effect_se = shock_iv(aggregated[:, 0], aggregated[:, 1])
first_stage, first_stage_se = shock_iv(aggregated[:, 1], aggregated[:, 2])
regional_effect = np.dot(e * centered[:, 2], centered[:, 0]) / np.dot(e * centered[:, 2], centered[:, 1])
regional_first_stage = np.dot(e * centered[:, 2], centered[:, 1]) / np.dot(e * centered[:, 2], centered[:, 2])
assert np.allclose([effect, first_stage], [regional_effect, regional_first_stage], rtol=1e-10, atol=1e-10)
assert np.allclose(mass @ aggregated, 0, atol=1e-10)
result = {
    'task_id': 'applied_shift_share', 'platform': 'python',
    'estimates': [
        {'term': 'effect', 'estimate': effect, 'se': effect_se, 'n_obs': N},
        {'term': 'first_stage', 'estimate': first_stage, 'se': first_stage_se, 'n_obs': N},
        {'term': 'effective_shocks', 'estimate': float(1 / np.sum(mass ** 2)), 'se': None, 'n_obs': N},
    ],
    'method_metadata': {
        'estimator': 'Regional weighted 2SLS; equivalent shock-level weighted IV with intercept',
        'vcov': 'Industry-level heteroskedasticity-robust HC1, structural IV scores, N/(N-2)'
    },
    'diagnostics': {}
}
with open('result.json', 'w') as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
