import json

import numpy as np
import pandas as pd


def weighted_iv(y, x, instrument, weight):
    """Just-identified weighted IV with structural-residual HC1 covariance."""
    n = len(y)
    design = np.column_stack((np.ones(n), x))
    instruments = np.column_stack((np.ones(n), instrument))
    cross = instruments.T @ (weight[:, None] * design)
    moment = instruments.T @ (weight * y)
    beta = np.linalg.solve(cross, moment)
    residual = y - design @ beta
    meat = instruments.T @ ((weight * residual)[:, None] ** 2 * instruments)
    bread = np.linalg.inv(cross)
    covariance = (n / (n - 2)) * bread @ meat @ bread.T
    return beta, np.sqrt(np.diag(covariance))


data = pd.read_csv("input.csv")
required = ["region_id", "industry_id", "share", "shock", "region_weight", "x", "y"]
assert data[required].notna().all().all()
assert not data.duplicated(["region_id", "industry_id"]).any()
for name in ["region_weight", "x", "y"]:
    assert data.groupby("region_id")[name].nunique().eq(1).all()
assert data.groupby("industry_id")["shock"].nunique().eq(1).all()
assert np.allclose(data.groupby("region_id")["share"].sum(), 1.0)

regions = data.groupby("region_id", sort=True)[["region_weight", "x", "y"]].first()
regions["e"] = regions["region_weight"] / regions["region_weight"].sum()
data = data.join(regions["e"], on="region_id")
regions["z"] = (data["share"] * data["shock"]).groupby(data["region_id"]).sum()
for name in ["y", "x", "z"]:
    regions[name + "0"] = regions[name] - np.dot(regions["e"], regions[name])
data = data.join(regions[["y0", "x0", "z0"]], on="region_id")
data["exposure"] = data["e"] * data["share"]

industries = data.groupby("industry_id", sort=True).agg(
    s=("exposure", "sum"), shock=("shock", "first")
)
assert (industries["s"] > 0).all()
for name in ["y", "x", "z"]:
    numerator = (data["exposure"] * data[name + "0"]).groupby(data["industry_id"]).sum()
    industries[name + "bar"] = numerator / industries["s"]

n = len(industries)
weight = industries["s"].to_numpy()
shock = industries["shock"].to_numpy()
yb = industries["ybar"].to_numpy()
xb = industries["xbar"].to_numpy()
zb = industries["zbar"].to_numpy()
effect, effect_se = weighted_iv(yb, xb, shock, weight)
first_stage, first_stage_se = weighted_iv(xb, zb, shock, weight)
effective_shocks = 1.0 / np.sum(weight**2)

# Independent regional weighted moment calculation checks both slopes.
e = regions["e"].to_numpy()
z0 = regions["z0"].to_numpy()
regional_effect = np.dot(e * z0, regions["y0"]) / np.dot(e * z0, regions["x0"])
regional_first_stage = np.dot(e * z0, regions["x0"]) / np.dot(e * z0, z0)
assert np.isclose(effect[1], regional_effect, rtol=1e-10, atol=1e-12)
assert np.isclose(first_stage[1], regional_first_stage, rtol=1e-10, atol=1e-12)
assert np.isclose(weight.sum(), 1.0)

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": float(effect[1]), "se": float(effect_se[1]), "n_obs": n},
        {"term": "first_stage", "estimate": float(first_stage[1]), "se": float(first_stage_se[1]), "n_obs": n},
        {"term": "effective_shocks", "estimate": float(effective_shocks), "se": None, "n_obs": n},
    ],
    "method_metadata": {
        "estimator": "Regional weighted 2SLS; BHJ shock-level weighted IV",
        "vcov": "Shock-level heteroskedasticity-robust HC1, N/(N-2), structural IV residuals",
    },
    "diagnostics": {},
}
with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output, indent=2, allow_nan=False)

print(f"regions={len(regions)} industries={n} rows={len(data)}")
print(f"effect: shock={effect[1]:.15g}, regional={regional_effect:.15g}, se={effect_se[1]:.15g}")
print(f"first_stage: shock={first_stage[1]:.15g}, regional={regional_first_stage:.15g}, se={first_stage_se[1]:.15g}")
print(f"effective_shocks={effective_shocks:.15g}; exposure_sum={weight.sum():.15g}")
