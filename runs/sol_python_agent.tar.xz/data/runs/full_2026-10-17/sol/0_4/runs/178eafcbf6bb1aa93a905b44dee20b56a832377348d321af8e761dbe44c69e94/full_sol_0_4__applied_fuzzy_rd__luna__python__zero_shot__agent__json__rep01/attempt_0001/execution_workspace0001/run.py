import json

import numpy as np
import pandas as pd
import statsmodels.api as sm


data = pd.read_csv("input.csv")
sample = data.loc[data["score"].abs() < 1].copy()
sample = sample.dropna(subset=["score", "participated", "earnings"])
x = sample["score"].to_numpy(dtype=float)
w = 1 - np.abs(x)
right = (x >= 0).astype(float)
X = np.column_stack([np.ones(len(x)), x, right, x * right])
Y = sample[["earnings", "participated"]].to_numpy(dtype=float)

fits = [sm.WLS(Y[:, j], X, weights=w).fit() for j in range(2)]
rf, fs = (float(f.params[2]) for f in fits)
residuals = np.column_stack([f.resid for f in fits])
bread = np.linalg.inv(X.T @ (w[:, None] * X))
# HC0 joint sandwich: each observation contributes to both outcomes.
influence = (w[:, None] * residuals)[:, :, None] * X[:, None, :]
joint_jump_influence = (influence @ bread[:, 2]).reshape(len(x), 2)
jump_cov = joint_jump_influence.T @ joint_jump_influence
gradient = np.array([1 / fs, -rf / fs**2])
effect = rf / fs
effect_var = float(gradient @ jump_cov @ gradient)

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": effect, "se": float(np.sqrt(effect_var)), "n_obs": len(x)},
        {"term": "reduced_form", "estimate": rf, "se": float(np.sqrt(jump_cov[0, 0])), "n_obs": len(x)},
        {"term": "first_stage", "estimate": fs, "se": float(np.sqrt(jump_cov[1, 1])), "n_obs": len(x)},
    ],
    "method_metadata": {
        "estimator": "Fuzzy RD Wald ratio; triangular weighted local linear regression with separate side slopes, cutoff 0, bandwidth 1",
        "vcov": "Fixed-bandwidth HC0 sandwich; joint outcome covariance and delta method for ratio",
    },
    "diagnostics": {},
}
with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output, indent=2, allow_nan=False)
    output.write("\n")
