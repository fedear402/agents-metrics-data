import json

import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS

TASK_ID = "applied_multivintage_trade_iv"

crosswalk = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv")
areas = pd.read_csv("areas.csv")
employment = pd.read_csv("employment.csv")
outcomes = pd.read_csv("outcomes.csv")

assert not crosswalk.duplicated("code").any()
assert not crosswalk.duplicated(["code", "industry"]).any()
assert not trade.duplicated(["period", "code"]).any()
assert not areas.duplicated(["area", "period", "vintage"]).any()
assert not employment.duplicated(["area", "period", "vintage", "industry"]).any()
assert not outcomes.duplicated(["area", "period"]).any()
assert set(areas.vintage) == {"base", "early"}
assert crosswalk.industry.nunique() == 4

trade = trade.merge(crosswalk, on="code", validate="many_to_one", indicator=True)
assert (trade._merge == "both").all()
trade = trade.drop(columns="_merge")
assert not trade.duplicated(["period", "industry"]).any()
assert (trade.groupby("period").industry.nunique() == 4).all()
assert (trade.groupby("period")[["price_index", "years"]].nunique() == 1).all().all()

# Complete every area-period-vintage-industry cell before computing national totals.
industry_grid = areas[["area", "period", "vintage"]].merge(
    trade[["period", "industry"]], on="period", validate="many_to_many"
)
cells = industry_grid.merge(
    employment, on=["area", "period", "vintage", "industry"],
    how="left", validate="one_to_one", indicator=True
)
assert len(cells) == len(industry_grid)
assert len(employment) == (cells._merge == "both").sum()
missing_cells = int(cells.employment.isna().sum())
cells["employment"] = cells.employment.fillna(0.0)
national = cells.groupby(["period", "vintage", "industry"], as_index=False).employment.sum()
national = national.rename(columns={"employment": "national_employment"})
assert (national.national_employment > 0).all()
cells = cells.merge(national, on=["period", "vintage", "industry"], validate="many_to_one")
cells = cells.merge(trade, on=["period", "industry"], validate="many_to_one")
cells = cells.merge(areas, on=["area", "period", "vintage"], validate="many_to_one")
assert (cells.total_employment > 0).all()

change = np.where(cells.vintage.eq("base"), cells.us_change, cells.other_change)
cells["contribution"] = (
    cells.employment / cells.total_employment
    * change / cells.national_employment
    / (cells.price_index / 100)
    / 1000
    * (10 / cells.years)
)
exposure = cells.groupby(["area", "period", "vintage"], as_index=False).contribution.sum()
wide = exposure.pivot(index=["area", "period"], columns="vintage", values="contribution")
wide = wide.rename(columns={"base": "x", "early": "z"}).reset_index()
base_areas = areas.loc[areas.vintage.eq("base"), ["area", "period", "population"]]
frame = outcomes.merge(wide, on=["area", "period"], validate="one_to_one")
frame = frame.merge(base_areas, on=["area", "period"], validate="one_to_one")
assert len(frame) == len(outcomes) == len(base_areas) == 72
assert frame[["change_pp", "period", "control", "x", "z", "population"]].notna().all().all()
assert (frame.population > 0).all()
frame = frame.sort_values(["period", "area"]).reset_index(drop=True)

exog = pd.DataFrame({"intercept": 1.0, "period": frame.period.astype(float),
                     "control": frame.control.astype(float)})
fit = IV2SLS(frame.change_pp, exog, frame[["x"]], frame[["z"]],
            weights=frame.population).fit()
assert fit.nobs == 72

# Independent weighted IV check: residualize y, x, and z on the weighted exogenous columns.
q = exog.to_numpy()
w = frame.population.to_numpy(dtype=float)
y = frame.change_pp.to_numpy(dtype=float)
x = frame.x.to_numpy(dtype=float)
z = frame.z.to_numpy(dtype=float)
def residualize(v):
    return v - q @ np.linalg.solve(q.T @ (w[:, None] * q), q.T @ (w * v))
ry, rx, rz = (residualize(v) for v in (y, x, z))
identity_slope = np.dot(w * rz, ry) / np.dot(w * rz, rx)
assert np.isclose(fit.params["x"], identity_slope, rtol=1e-11, atol=1e-11)

lookup = frame.set_index(["area", "period"])
requested = {
    "iv_slope": float(fit.params["x"]),
    "exposure_area0_period0": float(lookup.loc[(0, 0), "x"]),
    "exposure_area0_period1": float(lookup.loc[(0, 1), "x"]),
    "instrument_area0_period0": float(lookup.loc[(0, 0), "z"]),
}
result = {
    "task_id": TASK_ID,
    "platform": "python",
    "estimates": [
        {"term": term, "estimate": value, "se": None, "n_obs": 72}
        for term, value in requested.items()
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "outcome": "change_pp",
        "endogenous": "x",
        "excluded_instrument": "z",
        "exogenous_included_instruments": ["intercept", "period", "control"],
        "weight": "base-vintage population",
        "exposure_unit": "thousands of real dollars per worker per decade",
    },
    "diagnostics": {
        "estimation_rows": int(fit.nobs),
        "missing_employment_cells_set_to_zero": missing_cells,
        "independent_weighted_iv_slope": float(identity_slope),
        "independent_check_absolute_difference": float(abs(fit.params["x"] - identity_slope)),
    },
}
with open("result.json", "w", encoding="utf-8") as handle:
    json.dump(result, handle, indent=2, allow_nan=False)
    handle.write("\n")
print(json.dumps(result, indent=2))
