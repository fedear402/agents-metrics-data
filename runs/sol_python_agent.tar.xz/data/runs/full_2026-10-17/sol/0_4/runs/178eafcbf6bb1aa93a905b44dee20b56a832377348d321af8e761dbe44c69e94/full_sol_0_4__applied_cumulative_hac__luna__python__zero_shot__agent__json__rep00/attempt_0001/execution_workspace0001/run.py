import json

import numpy as np
import pandas as pd
import statsmodels.api as sm
from statsmodels.stats.sandwich_covariance import cov_hac


data = pd.read_csv("input.csv", parse_dates=["date"]).sort_values("date")
data = data.reset_index(drop=True)
change = np.log(data["vix"]).diff()
lags = pd.DataFrame({f"lag_{j}": change.shift(j) for j in range(1, 16)})
sample = pd.concat([np.log(data["sales"]).rename("log_sales"), lags], axis=1).dropna()

y = sample["log_sales"]
x = sm.add_constant(sample[lags.columns])
fit = sm.OLS(y, x).fit()
n = len(sample)
assert x.shape[1] == 16 and n > 16
cov = cov_hac(fit, nlags=15, weights_func=lambda nlags: 1 - np.arange(nlags + 1) / 16, use_correction=True)
beta = fit.params.to_numpy()
weights = np.r_[0.0, np.ones(15)]
terms = [
    ("cumulative_response", float(weights @ beta), float(np.sqrt(weights @ cov @ weights))),
    ("lag_1", float(fit.params["lag_1"]), float(np.sqrt(cov[1, 1]))),
    ("lag_15", float(fit.params["lag_15"]), float(np.sqrt(cov[15, 15]))),
]
result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [{"term": term, "estimate": estimate, "se": se, "n_obs": n} for term, estimate, se in terms],
    "method_metadata": {
        "estimator": "OLS of log(sales) on intercept and trading-observation lags 1-15 of diff(log(vix))",
        "vcov": "Newey-West HAC, Bartlett lag 15, full matrix, N/(N-16) correction",
    },
    "diagnostics": {},
}
with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output, indent=2, allow_nan=False)
