import json

import numpy as np
import pandas as pd


df = pd.read_csv("input.csv")
required = ["region_id", "industry_id", "share", "shock", "region_weight", "x", "y"]
assert df[required].notna().all().all()
assert not df.duplicated(["region_id", "industry_id"]).any()
for field in ["region_weight", "x", "y"]:
    assert df.groupby("region_id")[field].nunique().eq(1).all()
assert df.groupby("industry_id")["shock"].nunique().eq(1).all()
assert np.allclose(df.groupby("region_id")["share"].sum(), 1, atol=1e-10)

regions = df.groupby("region_id", sort=True)[["region_weight", "x", "y"]].first()
regions["e"] = regions.region_weight / regions.region_weight.sum()
df = df.join(regions["e"], on="region_id")
regions["z"] = (df.share * df.shock).groupby(df.region_id).sum()
for field in ["y", "x", "z"]:
    regions[field + "0"] = regions[field] - np.dot(regions.e, regions[field])
df = df.join(regions[["y0", "x0", "z0"]], on="region_id")
df["exposure"] = df.e * df.share
industries = df.groupby("industry_id", sort=True).agg(s=("exposure", "sum"), shock=("shock", "first"))
assert (industries.s > 0).all()
for field in ["y0", "x0", "z0"]:
    industries[field[0] + "bar"] = (df.exposure * df[field]).groupby(df.industry_id).sum() / industries.s


def shock_iv(outcome, endogenous):
    weight = industries.s.to_numpy()
    x = np.column_stack((np.ones(len(industries)), industries[endogenous].to_numpy()))
    z = np.column_stack((np.ones(len(industries)), industries.shock.to_numpy()))
    y = industries[outcome].to_numpy()
    zx = z.T @ (weight[:, None] * x)
    zy = z.T @ (weight * y)
    beta = np.linalg.solve(zx, zy)
    residual = y - x @ beta
    bread = np.linalg.inv(zx)
    meat = z.T @ ((weight * residual)[:, None] ** 2 * z)
    variance = bread @ meat @ bread.T * len(industries) / (len(industries) - 2)
    return float(beta[1]), float(np.sqrt(variance[1, 1]))


effect, effect_se = shock_iv("ybar", "xbar")
first_stage, first_stage_se = shock_iv("xbar", "zbar")
n = len(industries)
result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": effect, "se": effect_se, "n_obs": n},
        {"term": "first_stage", "estimate": first_stage, "se": first_stage_se, "n_obs": n},
        {"term": "effective_shocks", "estimate": float(1 / np.square(industries.s).sum()), "se": None, "n_obs": n},
    ],
    "method_metadata": {
        "estimator": "Weighted regional 2SLS via BHJ shock-level IV aggregation",
        "vcov": "Shock-level heteroskedasticity-robust HC1, N/(N-2), analytic weights",
    },
    "diagnostics": {},
}
with open("result.json", "w") as file:
    json.dump(result, file, indent=2, allow_nan=False)
