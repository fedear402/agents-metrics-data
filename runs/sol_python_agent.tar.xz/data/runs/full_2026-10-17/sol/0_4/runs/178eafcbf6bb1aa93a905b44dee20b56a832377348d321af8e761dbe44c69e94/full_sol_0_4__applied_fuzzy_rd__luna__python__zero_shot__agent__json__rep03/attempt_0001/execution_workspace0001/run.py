import json

import numpy as np
import pandas as pd


data = pd.read_csv("input.csv")
sample = data.loc[data["score"].abs() < 1].copy()
x = sample["score"].to_numpy(dtype=float)
w = 1 - np.abs(x)
right = (x >= 0).astype(float)
design = np.column_stack((1 - right, (1 - right) * x, right, right * x))
outcomes = sample[["earnings", "participated"]].to_numpy(dtype=float)

xtwx_inv = np.linalg.inv(design.T @ (w[:, None] * design))
coefficients = xtwx_inv @ design.T @ (w[:, None] * outcomes)
residuals = outcomes - design @ coefficients
contrast = np.array([-1.0, 0.0, 1.0, 0.0])
discontinuities = contrast @ coefficients

# HC0 joint covariance uses weighted score products from both outcomes.
influence = (design @ xtwx_inv @ contrast)[:, None] * w[:, None] * residuals
joint_vcov = influence.T @ influence
reduced_form, first_stage = discontinuities
treatment_effect = reduced_form / first_stage
gradient = np.array([1 / first_stage, -reduced_form / first_stage**2])
effect_variance = gradient @ joint_vcov @ gradient
n_obs = len(sample)

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": float(treatment_effect), "se": float(np.sqrt(effect_variance)), "n_obs": n_obs},
        {"term": "reduced_form", "estimate": float(reduced_form), "se": float(np.sqrt(joint_vcov[0, 0])), "n_obs": n_obs},
        {"term": "first_stage", "estimate": float(first_stage), "se": float(np.sqrt(joint_vcov[1, 1])), "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "Fuzzy RD ratio of weighted local-linear right-minus-left intercept discontinuities; triangular kernel, bandwidth 1",
        "vcov": "Conventional HC0 joint sandwich covariance and delta method; fixed bandwidth and weights",
    },
    "diagnostics": {},
}
with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output, indent=2)
