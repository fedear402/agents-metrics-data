import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")

estimates = []
cohort_results = []

for cohort in (3, 5, 7):
    window_times = list(range(cohort - 2, cohort + 3))
    max_control_cohort = cohort + 2

    eligible = (
        (df["g"] == cohort)
        | (df["g"] == 0)
        | (df["g"] > max_control_cohort)
    )

    comparison = df[
        eligible & df["time"].isin(window_times)
    ].copy()

    complete_units = (
        comparison.groupby("id")["time"]
        .nunique()
        .loc[lambda s: s == len(window_times)]
        .index
    )

    comparison = comparison[
        comparison["id"].isin(complete_units)
    ].copy()

    comparison["did"] = (
        (comparison["g"] == cohort)
        & (comparison["time"] >= cohort)
    ).astype(float)

    y = comparison["y"].to_numpy(dtype=float)
    did = comparison["did"].to_numpy(dtype=float)

    y_unit_mean = comparison.groupby("id")["y"].transform("mean").to_numpy()
    y_time_mean = comparison.groupby("time")["y"].transform("mean").to_numpy()
    y_grand_mean = y.mean()

    did_unit_mean = comparison.groupby("id")["did"].transform("mean").to_numpy()
    did_time_mean = comparison.groupby("time")["did"].transform("mean").to_numpy()
    did_grand_mean = did.mean()

    y_residual = y - y_unit_mean - y_time_mean + y_grand_mean
    did_residual = did - did_unit_mean - did_time_mean + did_grand_mean

    coefficient = float(
        np.dot(did_residual, y_residual)
        / np.dot(did_residual, did_residual)
    )

    n_obs = int(len(comparison))
    n_treated_units = int((comparison["g"] == cohort).sum() / len(window_times))

    cohort_results.append({
        "cohort": cohort,
        "estimate": coefficient,
        "n_obs": n_obs,
        "n_treated_units": n_treated_units,
    })

    estimates.append({
        "term": f"att_g{cohort}",
        "estimate": coefficient,
        "se": None,
        "n_obs": n_obs,
    })

weighted_estimate = float(
    sum(
        result["estimate"] * result["n_treated_units"]
        for result in cohort_results
    )
    / sum(result["n_treated_units"] for result in cohort_results)
)

estimates.append({
    "term": "att_weighted",
    "estimate": weighted_estimate,
    "se": None,
    "n_obs": sum(result["n_obs"] for result in cohort_results),
})

result = {
    "task_id": "broad_cohort_stack",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {},
    "diagnostics": {},
}

with open("result.json", "w") as file:
    json.dump(result, file, indent=2)
