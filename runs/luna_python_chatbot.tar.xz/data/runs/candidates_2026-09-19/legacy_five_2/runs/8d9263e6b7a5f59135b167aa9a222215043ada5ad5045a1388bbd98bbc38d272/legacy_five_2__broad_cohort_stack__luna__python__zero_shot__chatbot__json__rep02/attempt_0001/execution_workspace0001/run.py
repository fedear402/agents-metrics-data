import csv
import json
import numpy as np

cohorts = [3, 5, 7]

with open("input.csv", newline="") as f:
    rows = list(csv.DictReader(f))

for row in rows:
    row["id"] = row["id"]
    row["time"] = int(row["time"])
    row["g"] = int(row["g"])
    row["y"] = float(row["y"])

estimates = []
comparison_counts = []

for cohort in cohorts:
    window = set(range(cohort - 2, cohort + 3))

    eligible = [
        row for row in rows
        if row["time"] in window
        and (row["g"] == cohort or row["g"] == 0 or row["g"] > cohort + 2)
    ]

    by_id = {}
    for row in eligible:
        by_id.setdefault(row["id"], set()).add(row["time"])

    retained_ids = {
        unit_id for unit_id, times in by_id.items()
        if times == window
    }

    comparison = [
        row for row in eligible
        if row["id"] in retained_ids
    ]
    comparison.sort(key=lambda row: (row["id"], row["time"]))

    units = sorted({row["id"] for row in comparison})
    times = sorted({row["time"] for row in comparison})

    unit_index = {unit_id: i for i, unit_id in enumerate(units)}
    time_index = {time: i for i, time in enumerate(times)}

    n = len(comparison)
    k = 1 + (len(units) - 1) + (len(times) - 1) + 1
    X = np.zeros((n, k), dtype=float)
    y = np.zeros(n, dtype=float)

    for i, row in enumerate(comparison):
        X[i, 0] = 1.0

        unit_col = 1 + unit_index[row["id"]] - 1
        if unit_index[row["id"]] > 0:
            X[i, unit_col] = 1.0

        time_col = 1 + (len(units) - 1) + time_index[row["time"]] - 1
        if time_index[row["time"]] > 0:
            X[i, time_col] = 1.0

        did_col = k - 1
        X[i, did_col] = float(
            row["g"] == cohort and row["time"] >= cohort
        )
        y[i] = row["y"]

    beta = np.linalg.lstsq(X, y, rcond=None)[0]
    estimate = float(beta[-1])

    term = f"att_g{cohort}"
    estimates.append({
        "term": term,
        "estimate": estimate,
        "se": None,
        "n_obs": n
    })

    treated_units = len({
        row["id"] for row in comparison
        if row["g"] == cohort
    })
    comparison_counts.append((estimate, treated_units, n))

weighted_numerator = sum(
    estimate * treated_units
    for estimate, treated_units, _ in comparison_counts
)
weighted_denominator = sum(
    treated_units for _, treated_units, _ in comparison_counts
)
weighted_estimate = weighted_numerator / weighted_denominator
total_n_obs = sum(n for _, _, n in comparison_counts)

estimates.append({
    "term": "att_weighted",
    "estimate": float(weighted_estimate),
    "se": None,
    "n_obs": total_n_obs
})

result = {
    "task_id": "broad_cohort_stack",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {},
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
