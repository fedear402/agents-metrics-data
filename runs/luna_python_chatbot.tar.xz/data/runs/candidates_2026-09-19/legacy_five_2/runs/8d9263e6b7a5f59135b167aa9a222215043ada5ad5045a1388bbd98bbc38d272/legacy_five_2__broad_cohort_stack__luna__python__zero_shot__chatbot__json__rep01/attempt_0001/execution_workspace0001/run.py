import csv
import json
import numpy as np

rows = []

with open("input.csv", newline="") as f:
    reader = csv.DictReader(f)
    for row in reader:
        rows.append({
            "id": row["id"],
            "time": int(row["time"]),
            "g": int(row["g"]),
            "y": float(row["y"]),
        })


def cohort_estimate(cohort):
    window = set(range(cohort - 2, cohort + 3))

    eligible = [
        row for row in rows
        if row["time"] in window
        and (row["g"] == cohort or row["g"] == 0 or row["g"] > cohort + 2)
    ]

    by_unit = {}
    for row in eligible:
        by_unit.setdefault(row["id"], set()).add(row["time"])

    complete_units = {
        unit for unit, times in by_unit.items()
        if times == window
    }

    retained = [
        row for row in eligible
        if row["id"] in complete_units
    ]

    retained.sort(key=lambda row: (row["id"], row["time"]))

    units = sorted({row["id"] for row in retained})
    times = sorted({row["time"] for row in retained})

    unit_index = {unit: i for i, unit in enumerate(units[1:])}
    time_index = {time: i for i, time in enumerate(times[1:])}

    X = []
    y = []

    for row in retained:
        design_row = [float(row["g"] == cohort and row["time"] >= cohort)]

        design_row.extend(
            1.0 if unit_index.get(row["id"]) == i else 0.0
            for i in range(len(units) - 1)
        )

        design_row.extend(
            1.0 if time_index.get(row["time"]) == i else 0.0
            for i in range(len(times) - 1)
        )

        X.append(design_row)
        y.append(row["y"])

    X = np.asarray(X, dtype=float)
    y = np.asarray(y, dtype=float)

    coefficient = np.linalg.lstsq(X, y, rcond=None)[0][0]
    treated_units = len({
        row["id"] for row in retained
        if row["g"] == cohort
    })

    return float(coefficient), len(retained), treated_units


estimates = {}
comparison_rows = {}
treated_weights = {}

for cohort in (3, 5, 7):
    estimate, n_obs, treated_units = cohort_estimate(cohort)
    estimates[cohort] = estimate
    comparison_rows[cohort] = n_obs
    treated_weights[cohort] = treated_units

weighted_estimate = sum(
    estimates[cohort] * treated_weights[cohort]
    for cohort in (3, 5, 7)
) / sum(treated_weights.values())

result = {
    "task_id": "broad_cohort_stack",
    "platform": "python",
    "estimates": [
        {
            "term": "att_g3",
            "estimate": estimates[3],
            "se": None,
            "n_obs": comparison_rows[3],
        },
        {
            "term": "att_g5",
            "estimate": estimates[5],
            "se": None,
            "n_obs": comparison_rows[5],
        },
        {
            "term": "att_g7",
            "estimate": estimates[7],
            "se": None,
            "n_obs": comparison_rows[7],
        },
        {
            "term": "att_weighted",
            "estimate": weighted_estimate,
            "se": None,
            "n_obs": sum(comparison_rows.values()),
        },
    ],
    "method_metadata": {},
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
