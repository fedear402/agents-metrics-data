import csv
import json
import numpy as np

rows = []

with open("input.csv", newline="") as f:
    reader = csv.DictReader(f)
    for row in reader:
        rows.append({
            "id": row["id"],
            "time": int(row["time"]),
            "g": int(row["g"]),
            "y": float(row["y"]),
        })

unit_info = {}
for row in rows:
    unit_info.setdefault(row["id"], {"g": row["g"], "times": {}})
    unit_info[row["id"]]["times"][row["time"]] = row["y"]

def estimate_for_cohort(cohort):
    window = set(range(cohort - 2, cohort + 3))

    eligible_units = [
        unit_id
        for unit_id, info in unit_info.items()
        if info["g"] == cohort
        or info["g"] == 0
        or info["g"] > cohort + 2
    ]

    retained_units = [
        unit_id
        for unit_id in eligible_units
        if window.issubset(unit_info[unit_id]["times"].keys())
    ]

    comparison_rows = []
    for unit_id in retained_units:
        g = unit_info[unit_id]["g"]
        for time in sorted(window):
            comparison_rows.append({
                "id": unit_id,
                "time": time,
                "did": int(g == cohort and time >= cohort),
                "y": unit_info[unit_id]["times"][time],
            })

    unit_levels = sorted({row["id"] for row in comparison_rows})
    time_levels = sorted({row["time"] for row in comparison_rows})

    unit_ref = unit_levels[0]
    time_ref = time_levels[0]

    X = []
    y = []

    for row in comparison_rows:
        design_row = [1.0, float(row["did"])]

        for unit_id in unit_levels[1:]:
            design_row.append(float(row["id"] == unit_id))

        for time in time_levels[1:]:
            design_row.append(float(row["time"] == time))

        X.append(design_row)
        y.append(row["y"])

    coefficients = np.linalg.lstsq(
        np.asarray(X, dtype=float),
        np.asarray(y, dtype=float),
        rcond=None
    )[0]

    treated_units = sum(
        unit_info[unit_id]["g"] == cohort
        for unit_id in retained_units
    )

    return float(coefficients[1]), len(comparison_rows), treated_units

estimates = {}
comparison_counts = {}
treated_counts = {}

for cohort in (3, 5, 7):
    estimate, n_obs, n_treated = estimate_for_cohort(cohort)
    estimates[cohort] = estimate
    comparison_counts[cohort] = n_obs
    treated_counts[cohort] = n_treated

total_treated = sum(treated_counts.values())
weighted_estimate = sum(
    estimates[cohort] * treated_counts[cohort]
    for cohort in (3, 5, 7)
) / total_treated

result = {
    "task_id": "broad_cohort_stack",
    "platform": "python",
    "estimates": [
        {
            "term": "att_g3",
            "estimate": estimates[3],
            "se": None,
            "n_obs": comparison_counts[3],
        },
        {
            "term": "att_g5",
            "estimate": estimates[5],
            "se": None,
            "n_obs": comparison_counts[5],
        },
        {
            "term": "att_g7",
            "estimate": estimates[7],
            "se": None,
            "n_obs": comparison_counts[7],
        },
        {
            "term": "att_weighted",
            "estimate": weighted_estimate,
            "se": None,
            "n_obs": sum(comparison_counts.values),
        },
    ],
    "method_metadata": {},
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
