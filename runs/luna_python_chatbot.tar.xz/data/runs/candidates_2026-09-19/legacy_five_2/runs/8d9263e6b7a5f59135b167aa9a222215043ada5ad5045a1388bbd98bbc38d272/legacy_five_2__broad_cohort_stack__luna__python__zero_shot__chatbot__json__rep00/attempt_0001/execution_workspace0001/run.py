import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")

cohort_estimates = []
treated_counts = []

for cohort in (3, 5, 7):
    window_times = set(range(cohort - 2, cohort + 3))

    comparison = df[
        df["time"].isin(window_times)
        & ((df["g"] == cohort) | (df["g"] == 0) | (df["g"] > cohort + 2))
    ].copy()

    eligible_ids = []
    for unit_id, unit_data in comparison.groupby("id"):
        if set(unit_data["time"]) == window_times:
            eligible_ids.append(unit_id)

    comparison = comparison[comparison["id"].isin(eligible_ids)].copy()
    comparison["did"] = (
        (comparison["g"] == cohort) & (comparison["time"] >= cohort)
    ).astype(float)

    unit_dummies = pd.get_dummies(comparison["id"], drop_first=True, dtype=float)
    time_dummies = pd.get_dummies(comparison["time"], drop_first=True, dtype=float)

    X = np.column_stack(
        [
            np.ones(len(comparison)),
            comparison["did"].to_numpy(dtype=float),
            unit_dummies.to_numpy(dtype=float),
            time_dummies.to_numpy(dtype=float),
        ]
    )
    y = comparison["y"].to_numpy(dtype=float)

    coefficients = np.linalg.lstsq(X, y, rcond=None)[0]
    did_coefficient = float(coefficients[1])

    cohort_estimates.append(did_coefficient)
    treated_counts.append(comparison.loc[comparison["g"] == cohort, "id"].nunique())

    term = f"att_g{cohort}"
    if "estimates" not in locals():
        estimates = []

    estimates.append(
        {
            "term": term,
            "estimate": did_coefficient,
            "se": None,
            "n_obs": int(len(comparison)),
        }
    )

weighted_estimate = float(
    np.average(np.asarray(cohort_estimates), weights=np.asarray(treated_counts))
)

estimates.append(
    {
        "term": "att_weighted",
        "estimate": weighted_estimate,
        "se": None,
        "n_obs": int(sum(item["n_obs"] for item in estimates)),
    }
)

result = {
    "task_id": "broad_cohort_stack",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {},
    "diagnostics": {},
}

with open("result.json", "w") as file:
    json.dump(result, file, indent=2)
