import csv
import json
import numpy as np


def read_csv(path):
    with open(path, newline="") as f:
        return list(csv.DictReader(f))


crosswalk_rows = read_csv("crosswalk.csv")
trade_rows = read_csv("trade.csv")
area_rows = read_csv("areas.csv")
employment_rows = read_csv("employment.csv")
outcome_rows = read_csv("outcomes.csv")

code_to_industry = {
    row["code"]: row["industry"] for row in crosswalk_rows
}

trade = {}
for row in trade_rows:
    period = row["period"]
    trade[(period, code_to_industry[row["code"]])] = {
        "us_change": float(row["us_change"]),
        "other_change": float(row["other_change"]),
        "price_index": float(row["price_index"]),
        "years": float(row["years"]),
    }

areas = {}
for row in area_rows:
    key = (row["area"], row["period"], row["vintage"])
    areas[key] = {
        "total_employment": float(row["total_employment"]),
        "population": float(row["population"]),
    }

employment = {}
for row in employment_rows:
    key = (row["area"], row["period"], row["vintage"], row["industry"])
    employment[key] = employment.get(key, 0.0) + float(row["employment"])

industries = sorted(set(code_to_industry.values()))

national = {}
for period in sorted({row["period"] for row in trade_rows}):
    for vintage in ("base", "early"):
        for industry in industries:
            total = 0.0
            for row in area_rows:
                if row["period"] == period and row["vintage"] == vintage:
                    total += employment.get(
                        (row["area"], period, vintage, industry), 0.0
                    )
            national[(period, vintage, industry)] = total

outcomes = {
    (row["area"], row["period"]): {
        "control": float(row["control"]),
        "change_pp": float(row["change_pp"]),
    }
    for row in outcome_rows
}


def exposure(area, period, source_vintage, change_field):
    area_info = areas[(area, period, source_vintage)]
    total_employment = area_info["total_employment"]
    trade_info = {
        industry: trade[(period, industry)]
        for industry in industries
    }

    value = 0.0
    for industry in industries:
        area_employment = employment.get(
            (area, period, source_vintage, industry), 0.0
        )
        national_employment = national[(period, source_vintage, industry)]
        change = trade_info[industry][change_field]
        price_index = trade_info[industry]["price_index"]
        years = trade_info[industry]["years"]

        value += (
            (area_employment / total_employment)
            * (change / national_employment)
            / (price_index / 100.0)
            / 1000.0
            * (10.0 / years)
        )
    return value


rows = []
for row in outcome_rows:
    area = row["area"]
    period = row["period"]
    base_info = areas[(area, period, "base")]

    rows.append({
        "area": area,
        "period": period,
        "period_num": float(period),
        "control": float(row["control"]),
        "outcome": float(row["change_pp"]),
        "weight": base_info["population"],
        "x": exposure(area, period, "base", "us_change"),
        "z": exposure(area, period, "early", "other_change"),
    })

n_obs = len(rows)

y = np.array([row["outcome"] for row in rows], dtype=float)
x = np.array([
    [1.0, row["period_num"], row["control"], row["x"]]
    for row in rows
], dtype=float)
z = np.array([
    [1.0, row["period_num"], row["control"], row["z"]]
    for row in rows
], dtype=float)
weights = np.array([row["weight"] for row in rows], dtype=float)

sqrt_weights = np.sqrt(weights)
x_weighted = x * sqrt_weights[:, None]
z_weighted = z * sqrt_weights[:, None]
y_weighted = y * sqrt_weights

first_stage_projection = z_weighted @ np.linalg.pinv(z_weighted)
x_hat_weighted = first_stage_projection @ x_weighted

second_stage_projection = x_hat_weighted @ np.linalg.pinv(
    x_hat_weighted.T @ x_hat_weighted
)
beta = np.linalg.pinv(
    x_hat_weighted.T @ x_weighted
) @ (x_hat_weighted.T @ y_weighted)

area0_period0 = next(
    row["x"] for row in rows
    if row["area"] == "0" and row["period"] == "0"
)
area0_period1 = next(
    row["x"] for row in rows
    if row["area"] == "0" and row["period"] == "1"
)
instrument_area0_period0 = next(
    row["z"] for row in rows
    if row["area"] == "0" and row["period"] == "0"
)

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "iv_slope",
            "estimate": float(beta[3]),
            "se": None,
            "n_obs": 72,
        },
        {
            "term": "exposure_area0_period0",
            "estimate": float(area0_period0),
            "se": None,
            "n_obs": 72,
        },
        {
            "term": "exposure_area0_period1",
            "estimate": float(area0_period1),
            "se": None,
            "n_obs": 72,
        },
        {
            "term": "instrument_area0_period0",
            "estimate": float(instrument_area0_period0),
            "se": None,
            "n_obs": 72,
        },
    ],
    "method_metadata": {
        "estimator": "weighted_two_stage_least_squares",
        "outcome": "change_pp",
        "endogenous_regressor": "x",
        "excluded_instrument": "z",
        "exogenous_regressors": ["intercept", "period", "control"],
        "weight": "base_vintage_population",
        "sample_definition": "all area-period observations",
    },
    "diagnostics": {
        "n_obs": 72,
        "n_rows_read": len(outcome_rows),
        "industries": 4,
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
