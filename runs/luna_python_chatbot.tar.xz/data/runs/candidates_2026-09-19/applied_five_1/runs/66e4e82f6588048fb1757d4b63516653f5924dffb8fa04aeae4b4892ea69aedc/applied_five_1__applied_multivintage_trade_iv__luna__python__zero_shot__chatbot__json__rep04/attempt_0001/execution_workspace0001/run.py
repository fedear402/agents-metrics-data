import csv
import json
import math
from collections import defaultdict

import numpy as np


def read_csv(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def number(value):
    return float(value)


crosswalk_rows = read_csv("crosswalk.csv")
trade_rows = read_csv("trade.csv")
area_rows = read_csv("areas.csv")
employment_rows = read_csv("employment.csv")
outcome_rows = read_csv("outcomes.csv")

code_to_industry = {
    row["code"]: row["industry"] for row in crosswalk_rows
}

# Use supplied industry identifiers and preserve their declared mapping.
industries = sorted({row["industry"] for row in crosswalk_rows})

# National base-vintage employment by period and industry.
national_base_employment = defaultdict(float)
for row in employment_rows:
    if row["vintage"] == "base":
        key = (row["period"], row["industry"])
        national_base_employment[key] += number(row["employment"])

trade_by_period_industry = {}
for row in trade_rows:
    industry = code_to_industry[row["code"]]
    trade_by_period_industry[(row["period"], industry)] = row

employment_by_area_period_vintage_industry = defaultdict(float)
for row in employment_rows:
    key = (
        row["area"],
        row["period"],
        row["vintage"],
        row["industry"],
    )
    employment_by_area_period_vintage_industry[key] += number(row["employment"])

area_period_rows = {}
for row in area_rows:
    area_period_rows[(row["area"], row["period"])] = row

outcome_by_area_period = {
    (row["area"], row["period"]): row for row in outcome_rows
}

def period_value(period):
    try:
        return float(period)
    except ValueError:
        return None


periods = sorted({row["period"] for row in outcome_rows})
period_numeric = {p: period_value(p) for p in periods}

if any(v is None for v in period_numeric.values()):
    period_order = {p: i for i, p in enumerate(periods)}
    period_numeric = {p: float(period_order[p]) for p in periods}


def exposure(area, period, area_vintage, trade_change):
    area_row = area_period_rows[(area, period)]
    total_employment = number(area_row["total_employment"])
    trade_by_industry = {}

    for industry in industries:
        trade_row = trade_by_period_industry[(period, industry)]
        trade_by_industry[industry] = number(trade_row[trade_change])

    price_index = number(next(
        row["price_index"]
        for row in trade_rows
        if row["period"] == period
    ))
    years = number(next(
        row["years"]
        for row in trade_rows
        if row["period"] == period
    ))

    value = 0.0
    for industry in industries:
        area_employment = employment_by_area_period_vintage_industry[
            (area, period, area_vintage, industry)
        ]
        national_employment = national_base_employment[(period, industry)]

        value += (
            (area_employment / total_employment)
            * (trade_by_industry[industry] / national_employment)
            / (price_index / 100.0)
            / 1000.0
            * (10.0 / years)
        )

    return value


rows = []
for outcome in outcome_rows:
    area = outcome["area"]
    period = outcome["period"]
    area_row = area_period_rows[(area, period)]

    rows.append({
        "area": area,
        "period": period,
        "period_value": period_numeric[period],
        "control": number(outcome["control"]),
        "change_pp": number(outcome["change_pp"]),
        "x": exposure(area, period, "base", "us_change"),
        "z": exposure(area, period, "early", "other_change"),
        "weight": number(area_row["population"]),
    })

n_obs = len(rows)

y = np.array([row["change_pp"] for row in rows], dtype=float)
x = np.array([
    [1.0, row["period_value"], row["control"], row["x"]]
    for row in rows
], dtype=float)
z = np.array([
    [1.0, row["period_value"], row["control"], row["z"]]
    for row in rows
], dtype=float)
weights = np.array([row["weight"] for row in rows], dtype=float)

sqrt_weights = np.sqrt(weights)
x_weighted = x * sqrt_weights[:, None]
z_weighted = z * sqrt_weights[:, None]
y_weighted = y * sqrt_weights

z_cross = z_weighted.T @ z_weighted
projection_cross = z_weighted @ np.linalg.inv(z_cross) @ z_weighted.T

normal_matrix = x_weighted.T @ projection_cross @ x_weighted
right_hand_side = x_weighted.T @ projection_cross @ y_weighted
beta = np.linalg.solve(normal_matrix, right_hand_side)

area0_candidates = [
    row for row in rows
    if str(row["area"]) == "0"
]

def find_area0_period(target):
    for row in area0_candidates:
        if str(row["period"]) == str(target):
            return row
    raise KeyError(f"Area 0, period {target} not found")

area0_period0 = find_area0_period(0)
area0_period1 = find_area0_period(1)

estimates = [
    {
        "term": "iv_slope",
        "estimate": float(beta[3]),
        "se": None,
        "n_obs": int(n_obs),
    },
    {
        "term": "exposure_area0_period0",
        "estimate": float(area0_period0["x"]),
        "se": None,
        "n_obs": int(n_obs),
    },
    {
        "term": "exposure_area0_period1",
        "estimate": float(area0_period1["x"]),
        "se": None,
        "n_obs": int(n_obs),
    },
    {
        "term": "instrument_area0_period0",
        "estimate": float(area0_period0["z"]),
        "se": None,
        "n_obs": int(n_obs),
    },
]

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "weighted two-stage least squares",
        "outcome": "change_pp",
        "endogenous_regressor": "x",
        "instrument": "z",
        "exogenous_instruments": [
            "intercept",
            "period",
            "control",
        ],
        "weight": "base-vintage population",
        "exposure_units": "thousands of real dollars per worker per decade",
    },
    "diagnostics": {
        "n_obs": int(n_obs),
        "n_industries": int(len(industries)),
        "weight_sum": float(weights.sum()),
    },
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, allow_nan=False)
