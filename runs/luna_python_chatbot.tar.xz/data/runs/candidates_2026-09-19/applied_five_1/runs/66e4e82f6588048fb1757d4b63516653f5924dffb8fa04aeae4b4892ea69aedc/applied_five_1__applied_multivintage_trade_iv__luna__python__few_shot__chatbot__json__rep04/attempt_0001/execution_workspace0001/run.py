import csv
import json
from pathlib import Path

import numpy as np


def read_csv(name):
    with open(Path(name), newline="") as f:
        return list(csv.DictReader(f))


def numeric(value):
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


crosswalk = read_csv("crosswalk.csv")
trade = read_csv("trade.csv")
areas = read_csv("areas.csv")
employment = read_csv("employment.csv")
outcomes = read_csv("outcomes.csv")

code_to_industry = {
    row["code"]: row["industry"] for row in crosswalk
}

trade_by_period_industry = {}
for row in trade:
    period = row["period"]
    industry = code_to_industry[row["code"]]
    trade_by_period_industry[(period, industry)] = {
        "us_change": float(row["us_change"]),
        "other_change": float(row["other_change"]),
        "price_index": float(row["price_index"]),
        "years": float(row["years"]),
    }

area_rows = {}
for row in areas:
    key = (row["area"], row["period"], row["vintage"])
    area_rows[key] = row

outcome_rows = {
    (row["area"], row["period"]): row for row in outcomes
}

periods = sorted({row["period"] for row in areas})
areas_list = sorted({row["area"] for row in areas})

period_value = {}
for i, period in enumerate(periods):
    value = numeric(period)
    period_value[period] = value if value is not None else float(i)

industries = sorted({row["industry"] for row in crosswalk})

employment_by_key = {}
for row in employment:
    key = (row["area"], row["period"], row["vintage"], row["industry"])
    employment_by_key[key] = float(row["employment"])

national = {}
for period in periods:
    for vintage in ("base", "early"):
        for industry in industries:
            national[(period, vintage, industry)] = sum(
                employment_by_key.get(
                    (area, period, vintage, industry), 0.0
                )
                for area in areas_list
            )

def exposure(area, period, vintage, change_key):
    area_info = area_rows[(area, period, vintage)]
    total_employment = float(area_info["total_employment"])
    trade_info = {
        industry: trade_by_period_industry[(period, industry)]
        for industry in industries
    }
    price_index = next(iter(trade_info.values()))["price_index"]
    years = next(iter(trade_info.values()))["years"]

    value = 0.0
    for industry in industries:
        employment_value = employment_by_key.get(
            (area, period, vintage, industry), 0.0
        )
        national_employment = national[(period, vintage, industry)]
        trade_change = trade_info[industry][change_key]
        value += (
            (employment_value / total_employment)
            * (trade_change / national_employment)
            / (price_index / 100.0)
            / 1000.0
            * (10.0 / years)
        )
    return value


rows = []
for period in periods:
    for area in areas_list:
        outcome = outcome_rows[(area, period)]
        rows.append(
            {
                "area": area,
                "period": period,
                "y": float(outcome["change_pp"]),
                "control": float(outcome["control"]),
                "weight": float(area_rows[(area, period, "base")]["population"]),
                "x": exposure(area, period, "base", "us_change"),
                "z": exposure(area, period, "early", "other_change"),
            }
        )

y = np.array([row["y"] for row in rows], dtype=float)
x = np.array(
    [
        [1.0, period_value[row["period"]], row["control"], row["x"]]
        for row in rows
    ],
    dtype=float,
)
z = np.array(
    [
        [1.0, period_value[row["period"]], row["control"], row["z"]]
        for row in rows
    ],
    dtype=float,
)
weights = np.array([row["weight"] for row in rows], dtype=float)
sqrt_weights = np.sqrt(weights)

yw = y * sqrt_weights
xw = x * sqrt_weights[:, None]
zw = z * sqrt_weights[:, None]

projection = zw @ np.linalg.pinv(zw.T @ zw) @ zw.T
beta = np.linalg.pinv(xw.T @ projection @ xw) @ (xw.T @ projection @ yw)
iv_slope = float(beta[3])

area0 = 0
if area0 not in areas_list:
    area0 = "0"

period0, period1 = periods[0], periods[1]

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "iv_slope",
            "estimate": iv_slope,
            "se": None,
            "n_obs": 72,
        },
        {
            "term": "exposure_area0_period0",
            "estimate": exposure(area0, period0, "base", "us_change"),
            "se": None,
            "n_obs": 72,
        },
        {
            "term": "exposure_area0_period1",
            "estimate": exposure(area0, period1, "base", "us_change"),
            "se": None,
            "n_obs": 72,
        },
        {
            "term": "instrument_area0_period0",
            "estimate": exposure(area0, period0, "early", "other_change"),
            "se": None,
            "n_obs": 72,
        },
    ],
    "method_metadata": {
        "estimator": "weighted_2sls",
        "outcome": "change_pp",
        "endogenous": ["x"],
        "instruments": ["z"],
        "exogenous_regressors": ["intercept", "period", "control"],
        "weight": "base-vintage population",
        "missing_area_industry_employment": "zero",
        "exposure_units": "thousands of real dollars per worker per decade",
    },
    "diagnostics": {
        "n_obs": 72,
        "n_areas": len(areas_list),
        "n_periods": len(periods),
        "n_industries": len(industries),
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2, allow_nan=False)
