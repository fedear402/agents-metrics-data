import json
import numpy as np
import pandas as pd

households = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

data = households.loc[households["recipient"] == 0].copy()
n_obs = int(len(data))

eligible = data["eligible"].to_numpy(dtype=float)
dose = data["dose"].to_numpy(dtype=float)
instrument = data["instrument"].to_numpy(dtype=float)
baseline = data["baseline"].to_numpy(dtype=float)
outcome = data["outcome"].to_numpy(dtype=float)
weight = data["weight"].to_numpy(dtype=float)

ineligible = 1.0 - eligible

endogenous = np.column_stack([
    dose * ineligible,
    dose * eligible,
])

exogenous = np.column_stack([
    ineligible,
    eligible,
    baseline * ineligible,
    baseline * eligible,
])

instruments = np.column_stack([
    ineligible,
    eligible,
    baseline * ineligible,
    baseline * eligible,
    instrument * ineligible,
    instrument * eligible,
])

x = np.column_stack([exogenous, endogenous])
z = instruments
w = np.diag(weight)

ztwz = z.T @ w @ z
projection_x = z @ np.linalg.pinv(ztwz) @ z.T @ w @ x

beta = np.linalg.pinv(x.T @ w @ projection_x) @ (x.T @ w @ projection_x.T @ outcome)

ineligible_slope = float(beta[4])
eligible_slope = float(beta[5])

ineligible_mask = eligible == 0
eligible_mask = eligible == 1

ineligible_weighted_mean_dose = float(
    np.sum(weight[ineligible_mask] * dose[ineligible_mask])
    / np.sum(weight[ineligible_mask])
)
eligible_weighted_mean_dose = float(
    np.sum(weight[eligible_mask] * dose[eligible_mask])
    / np.sum(weight[eligible_mask])
)

ineligible_effect = ineligible_slope * ineligible_weighted_mean_dose
eligible_nonrecipient_effect = eligible_slope * eligible_weighted_mean_dose

census_totals = (
    census.groupby("eligible", as_index=False)["nonrecipient_population"]
    .sum()
    .set_index("eligible")["nonrecipient_population"]
)

ineligible_population = float(census_totals.get(0, 0.0))
eligible_population = float(census_totals.get(1, 0.0))
population_total = ineligible_population + eligible_population

population_effect = (
    ineligible_effect * ineligible_population
    + eligible_nonrecipient_effect * eligible_population
) / population_total

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "ineligible_effect",
            "estimate": float(ineligible_effect),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "eligible_nonrecipient_effect",
            "estimate": float(eligible_nonrecipient_effect),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "population_effect",
            "estimate": float(population_effect),
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "weighted_2sls",
        "intercept": False,
        "retained_sample": "recipient == 0",
        "endogenous_columns": [
            "dose*(1-eligible)",
            "dose*eligible",
        ],
        "exogenous_columns": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
        ],
        "instrument_columns": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
            "instrument*(1-eligible)",
            "instrument*eligible",
        ],
        "weight_column": "weight",
        "counterfactual": "dose set to zero for every retained household",
        "group_effect_convention": "fitted dose slope multiplied by the household-weighted mean dose",
        "population_aggregation": "census nonrecipient_population weights",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "n_ineligible": int(ineligible_mask.sum()),
        "n_eligible_nonrecipient": int(eligible_mask.sum()),
        "ineligible_population": ineligible_population,
        "eligible_population": eligible_population,
    },
}

with open("result.json", "w", encoding="utf-8") as output_file:
    json.dump(result, output_file, indent=2, allow_nan=False)
