import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
from linearmodels.iv import IV2SLS

households = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

d = households.loc[households["recipient"] == 0].copy()
d["one_minus_eligible"] = 1 - d["eligible"]
d["dose_ineligible"] = d["dose"] * d["one_minus_eligible"]
d["dose_eligible"] = d["dose"] * d["eligible"]
d["baseline_ineligible"] = d["baseline"] * d["one_minus_eligible"]
d["baseline_eligible"] = d["baseline"] * d["eligible"]
d["instrument_ineligible"] = d["instrument"] * d["one_minus_eligible"]
d["instrument_eligible"] = d["instrument"] * d["eligible"]

exog = d[
    [
        "one_minus_eligible",
        "eligible",
        "baseline_ineligible",
        "baseline_eligible",
    ]
]
endog = d[["dose_ineligible", "dose_eligible"]]
instruments = d[
    [
        "one_minus_eligible",
        "eligible",
        "baseline_ineligible",
        "baseline_eligible",
        "instrument_ineligible",
        "instrument_eligible",
    ]
]

fit = IV2SLS(
    dependent=d["outcome"],
    exog=exog,
    endog=endog,
    instruments=instruments,
    weights=d["weight"],
).fit()

ineligible_slope = float(fit.params["dose_ineligible"])
eligible_slope = float(fit.params["dose_eligible"])

ineligible = d.loc[d["eligible"] == 0]
eligible = d.loc[d["eligible"] == 1]

ineligible_mean_dose = float(
    np.average(ineligible["dose"], weights=ineligible["weight"])
)
eligible_mean_dose = float(
    np.average(eligible["dose"], weights=eligible["weight"])
)

ineligible_effect = ineligible_slope * ineligible_mean_dose
eligible_nonrecipient_effect = eligible_slope * eligible_mean_dose

population_counts = (
    census.groupby("eligible", as_index=True)["nonrecipient_population"]
    .sum()
)

population_effect = float(
    np.average(
        [ineligible_effect, eligible_nonrecipient_effect],
        weights=[
            population_counts.loc[0],
            population_counts.loc[1],
        ],
    )
)

n_obs = int(len(d))

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "ineligible_effect",
            "estimate": float(ineligible_effect),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "eligible_nonrecipient_effect",
            "estimate": float(eligible_nonrecipient_effect),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "population_effect",
            "estimate": float(population_effect),
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "outcome": "outcome",
        "endogenous_variables": [
            "dose*(1-eligible)",
            "dose*eligible",
        ],
        "exogenous_variables": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
        ],
        "instruments": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
            "instrument*(1-eligible)",
            "instrument*eligible",
        ],
        "weight_variable": "weight",
        "retained_condition": "recipient == 0",
        "intercept": False,
        "group_effect_definition": (
            "fitted dose slope times household-weighted mean dose"
        ),
        "counterfactual": "dose equals zero for every retained household",
        "attribution_convention": "synthetic zero-dose counterfactual",
        "population_weight_variable": "nonrecipient_population",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "n_ineligible_nonrecipient": int(len(ineligible)),
        "n_eligible_nonrecipient": int(len(eligible)),
        "ineligible_slope": float(ineligible_slope),
        "eligible_nonrecipient_slope": float(eligible_slope),
        "ineligible_weighted_mean_dose": ineligible_mean_dose,
        "eligible_nonrecipient_weighted_mean_dose": eligible_mean_dose,
        "ineligible_population": int(population_counts.loc[0]),
        "eligible_nonrecipient_population": int(population_counts.loc[1]),
    },
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file, indent=2, allow_nan=False)
