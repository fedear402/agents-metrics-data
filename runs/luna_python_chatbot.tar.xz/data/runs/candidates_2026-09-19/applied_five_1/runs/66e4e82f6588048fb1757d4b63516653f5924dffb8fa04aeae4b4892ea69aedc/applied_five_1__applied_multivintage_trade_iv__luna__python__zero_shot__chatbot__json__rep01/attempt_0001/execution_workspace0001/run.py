import csv
import json
import numpy as np


def read_csv(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def numeric_or_ordered(values):
    try:
        return {v: float(v) for v in values}
    except ValueError:
        ordered = sorted(set(values))
        return {v: float(i) for i, v in enumerate(ordered)}


crosswalk_rows = read_csv("crosswalk.csv")
trade_rows = read_csv("trade.csv")
area_rows = read_csv("areas.csv")
employment_rows = read_csv("employment.csv")
outcome_rows = read_csv("outcomes.csv")

code_to_industry = {
    row["code"]: row["industry"] for row in crosswalk_rows
}

period_values = (
    [row["period"] for row in area_rows]
    + [row["period"] for row in trade_rows]
    + [row["period"] for row in outcome_rows]
)
period_map = numeric_or_ordered(period_values)

area_period_keys = sorted(
    {(row["area"], row["period"]) for row in outcome_rows},
    key=lambda k: (float(k[0]), period_map[k[1]])
)

trade = {}
for row in trade_rows:
    trade[(row["period"], code_to_industry[row["code"]])] = {
        "us_change": float(row["us_change"]),
        "other_change": float(row["other_change"]),
        "price_index": float(row["price_index"]),
        "years": float(row["years"]),
    }

areas = {}
for row in area_rows:
    areas[(row["area"], row["period"], row["vintage"])] = {
        "total_employment": float(row["total_employment"]),
        "population": float(row["population"]),
    }

employment = {}
for row in employment_rows:
    employment[
        (row["area"], row["period"], row["vintage"], row["industry"])
    ] = float(row["employment"])

outcomes = {
    (row["area"], row["period"]): {
        "control": float(row["control"]),
        "change_pp": float(row["change_pp"]),
    }
    for row in outcome_rows
}

industries = sorted(set(code_to_industry.values()))

national_employment = {}
for period in sorted({p for _, p in area_period_keys}, key=lambda p: period_map[p]):
    for vintage in ("base", "early"):
        for industry in industries:
            national_employment[(period, vintage, industry)] = sum(
                employment.get((area, period, vintage, industry), 0.0)
                for area, p in area_period_keys
                if p == period
            )

def make_exposure(area, period, area_vintage, trade_change_key):
    area_info = areas[(area, period, area_vintage)]
    total = area_info["total_employment"]
    trade_info_by_industry = {
        industry: trade[(period, industry)]
        for industry in industries
    }

    value = 0.0
    for industry in industries:
        area_industry = employment.get(
            (area, period, area_vintage, industry), 0.0
        )
        national_industry = national_employment[
            (period, area_vintage, industry)
        ]
        trade_info = trade_info_by_industry[industry]

        value += (
            (area_industry / total)
            * (
                trade_info[trade_change_key]
                / national_industry
            )
            / (trade_info["price_index"] / 100.0)
            / 1000.0
            * (10.0 / trade_info["years"])
        )
    return value


rows = []
for area, period in area_period_keys:
    area_base = areas[(area, period, "base")]
    outcome = outcomes[(area, period)]

    rows.append({
        "area": area,
        "period": period,
        "period_numeric": period_map[period],
        "control": outcome["control"],
        "change_pp": outcome["change_pp"],
        "x": make_exposure(area, period, "base", "us_change"),
        "z": make_exposure(area, period, "early", "other_change"),
        "weight": area_base["population"],
    })

y = np.array([r["change_pp"] for r in rows], dtype=float)
x = np.array([
    [1.0, r["period_numeric"], r["control"], r["x"]]
    for r in rows
], dtype=float)
z = np.array([
    [1.0, r["period_numeric"], r["control"], r["z"]]
    for r in rows
], dtype=float)
weights = np.array([r["weight"] for r in rows], dtype=float)

sqrt_weights = np.sqrt(weights)
yw = y * sqrt_weights
xw = x * sqrt_weights[:, None]
zw = z * sqrt_weights[:, None]

projection = zw @ np.linalg.inv(zw.T @ zw) @ zw.T
beta = np.linalg.solve(
    xw.T @ projection @ xw,
    xw.T @ projection @ yw
)

area0_period0 = next(
    r["x"] for r in rows if float(r["area"]) == 0.0 and period_map[r["period"]] == 0.0
)
area0_period1 = next(
    r["x"] for r in rows if float(r["area"]) == 0.0 and period_map[r["period"]] == 1.0
)
instrument_area0_period0 = next(
    r["z"] for r in rows if float(r["area"]) == 0.0 and period_map[r["period"]] == 0.0
)

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "iv_slope",
            "estimate": float(beta[3]),
            "se": None,
            "n_obs": int(len(rows)),
        },
        {
            "term": "exposure_area0_period0",
            "estimate": float(area0_period0),
            "se": None,
            "n_obs": int(len(rows)),
        },
        {
            "term": "exposure_area0_period1",
            "estimate": float(area0_period1),
            "se": None,
            "n_obs": int(len(rows)),
        },
        {
            "term": "instrument_area0_period0",
            "estimate": float(instrument_area0_period0),
            "se": None,
            "n_obs": int(len(rows)),
        },
    ],
    "method_metadata": {
        "estimator": "weighted_two_stage_least_squares",
        "outcome": "change_pp",
        "endogenous_regressor": "x",
        "instrument": "z",
        "exogenous_regressors": ["intercept", "period", "control"],
        "weight": "base-vintage population",
        "sample_definition": "all supplied area-period outcome rows",
    },
    "diagnostics": {
        "n_obs": int(len(rows)),
        "n_industries": int(len(industries)),
        "n_periods": int(len(set(r["period"] for r in rows))),
    },
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2)
