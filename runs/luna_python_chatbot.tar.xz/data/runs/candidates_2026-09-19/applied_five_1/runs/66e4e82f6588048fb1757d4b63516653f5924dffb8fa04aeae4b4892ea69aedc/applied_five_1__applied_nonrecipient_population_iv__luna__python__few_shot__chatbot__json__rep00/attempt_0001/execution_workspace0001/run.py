import json
import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS

households = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

d = households.loc[households["recipient"] == 0].copy()
d["eligible"] = d["eligible"].astype(int)
d["ineligible"] = 1 - d["eligible"]

d["dose_ineligible"] = d["dose"] * d["ineligible"]
d["dose_eligible"] = d["dose"] * d["eligible"]
d["baseline_ineligible"] = d["baseline"] * d["ineligible"]
d["baseline_eligible"] = d["baseline"] * d["eligible"]
d["instrument_ineligible"] = d["instrument"] * d["ineligible"]
d["instrument_eligible"] = d["instrument"] * d["eligible"]

exog = d[
    [
        "ineligible",
        "eligible",
        "baseline_ineligible",
        "baseline_eligible",
    ]
]
endog = d[["dose_ineligible", "dose_eligible"]]
instruments = d[["instrument_ineligible", "instrument_eligible"]]

fit = IV2SLS(
    dependent=d["outcome"],
    exog=exog,
    endog=endog,
    instruments=instruments,
    weights=d["weight"],
).fit()

group_slopes = {
    0: float(fit.params["dose_ineligible"]),
    1: float(fit.params["dose_eligible"]),
}

group_effects = {}
for group in [0, 1]:
    h = d.loc[d["eligible"] == group]
    mean_dose = np.average(h["dose"], weights=h["weight"])
    group_effects[group] = group_slopes[group] * mean_dose

population_counts = (
    census.groupby("eligible", as_index=True)["nonrecipient_population"].sum()
)
population_effect = np.average(
    [group_effects[0], group_effects[1]],
    weights=[
        population_counts.loc[0],
        population_counts.loc[1],
    ],
)

n_obs = int(len(d))

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "ineligible_effect",
            "estimate": float(group_effects[0]),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "eligible_nonrecipient_effect",
            "estimate": float(group_effects[1]),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "population_effect",
            "estimate": float(population_effect),
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "dependent_variable": "outcome",
        "sample": "households with recipient == 0",
        "endogenous_variables": [
            "dose*(1-eligible)",
            "dose*eligible",
        ],
        "exogenous_variables": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
        ],
        "excluded_instruments": [
            "instrument*(1-eligible)",
            "instrument*eligible",
        ],
        "weight_variable": "weight",
        "group_effect_definition": (
            "fitted group dose slope multiplied by the household-weighted "
            "mean dose among retained observations"
        ),
        "counterfactual": (
            "synthetic zero-dose counterfactual for every retained household"
        ),
        "population_aggregation": (
            "census nonrecipient_population determines final group weights"
        ),
    },
    "diagnostics": {
        "n_obs": n_obs,
        "group_counts": {
            "ineligible": int((d["eligible"] == 0).sum()),
            "eligible_nonrecipient": int((d["eligible"] == 1).sum()),
        },
        "census_population_totals": {
            "ineligible": int(population_counts.loc[0]),
            "eligible": int(population_counts.loc[1]),
        },
    },
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, allow_nan=False)
