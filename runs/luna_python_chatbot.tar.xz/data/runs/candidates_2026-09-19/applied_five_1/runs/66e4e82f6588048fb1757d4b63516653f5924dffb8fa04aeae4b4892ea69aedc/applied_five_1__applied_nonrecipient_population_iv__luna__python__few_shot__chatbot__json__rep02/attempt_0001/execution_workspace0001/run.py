import json
import numpy as np
import pandas as pd


def main():
    households = pd.read_csv("households.csv")
    census = pd.read_csv("census.csv")

    data = households.loc[households["recipient"] == 0].copy()
    n_obs = int(len(data))

    eligible = data["eligible"].to_numpy(dtype=float)
    dose = data["dose"].to_numpy(dtype=float)
    baseline = data["baseline"].to_numpy(dtype=float)
    instrument = data["instrument"].to_numpy(dtype=float)
    outcome = data["outcome"].to_numpy(dtype=float)
    weights = data["weight"].to_numpy(dtype=float)

    ineligible = 1.0 - eligible

    exog = np.column_stack([
        ineligible,
        eligible,
        baseline * ineligible,
        baseline * eligible,
    ])

    endog = np.column_stack([
        dose * ineligible,
        dose * eligible,
    ])

    instruments = np.column_stack([
        ineligible,
        eligible,
        baseline * ineligible,
        baseline * eligible,
        instrument * ineligible,
        instrument * eligible,
    ])

    regressors = np.column_stack([exog, endog])

    sqrt_weights = np.sqrt(weights)
    weighted_regressors = regressors * sqrt_weights[:, None]
    weighted_instruments = instruments * sqrt_weights[:, None]
    weighted_outcome = outcome * sqrt_weights

    ztz = weighted_instruments.T @ weighted_instruments
    projection = weighted_instruments @ np.linalg.solve(ztz, weighted_instruments.T)
    projected_regressors = projection @ weighted_regressors
    projected_outcome = projection @ weighted_outcome

    beta = np.linalg.solve(
        weighted_regressors.T @ projected_regressors,
        weighted_regressors.T @ projected_outcome,
    )

    ineligible_slope = float(beta[4])
    eligible_slope = float(beta[5])

    ineligible_mean_dose = float(
        np.average(dose[eligible == 0], weights=weights[eligible == 0])
    )
    eligible_mean_dose = float(
        np.average(dose[eligible == 1], weights=weights[eligible == 1])
    )

    ineligible_effect = ineligible_slope * ineligible_mean_dose
    eligible_nonrecipient_effect = eligible_slope * eligible_mean_dose

    census_weights = (
        census.set_index("eligible")["nonrecipient_population"]
        .reindex([0, 1])
        .to_numpy(dtype=float)
    )
    population_effect = float(
        np.average(
            [ineligible_effect, eligible_nonrecipient_effect],
            weights=census_weights,
        )
    )

    result = {
        "task_id": "applied_nonrecipient_population_iv",
        "platform": "python",
        "estimates": [
            {
                "term": "ineligible_effect",
                "estimate": float(ineligible_effect),
                "se": None,
                "n_obs": n_obs,
            },
            {
                "term": "eligible_nonrecipient_effect",
                "estimate": float(eligible_nonrecipient_effect),
                "se": None,
                "n_obs": n_obs,
            },
            {
                "term": "population_effect",
                "estimate": float(population_effect),
                "se": None,
                "n_obs": n_obs,
            },
        ],
        "method_metadata": {
            "estimator": "weighted_2sls",
            "counterfactual": "dose set to zero for every retained household",
            "effect_definition": "fitted group dose slope times household-weighted mean dose",
            "retained_sample": "recipient == 0",
            "intercept": False,
            "census_usage": "final between-group aggregation weights only",
        },
        "diagnostics": {
            "n_obs": n_obs,
            "n_ineligible": int(np.sum(eligible == 0)),
            "n_eligible_nonrecipient": int(np.sum(eligible == 1)),
            "census_nonrecipient_population_ineligible": int(census_weights[0]),
            "census_nonrecipient_population_eligible": int(census_weights[1]),
        },
    }

    with open("result.json", "w", encoding="utf-8") as file:
        json.dump(result, file, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
