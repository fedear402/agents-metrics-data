import json
from pathlib import Path

import numpy as np
import pandas as pd


def period_sort_key(value):
    try:
        return (0, float(value))
    except (TypeError, ValueError):
        return (1, str(value))


def main():
    crosswalk = pd.read_csv("crosswalk.csv")
    trade = pd.read_csv("trade.csv")
    areas = pd.read_csv("areas.csv")
    employment = pd.read_csv("employment.csv")
    outcomes = pd.read_csv("outcomes.csv")

    trade = trade.merge(crosswalk, on="code", how="inner", validate="many_to_one")

    industries = sorted(crosswalk["industry"].unique().tolist())
    periods = sorted(areas["period"].unique().tolist(), key=period_sort_key)

    base_areas = areas.loc[areas["vintage"].eq("base")].copy()
    early_areas = areas.loc[areas["vintage"].eq("early")].copy()

    employment = employment.copy()
    employment["employment"] = employment["employment"].astype(float)

    national = (
        employment.groupby(["period", "vintage", "industry"], as_index=False)["employment"]
        .sum()
        .rename(columns={"employment": "national_employment"})
    )

    def build_exposure(area_table, vintage, change_column):
        rows = area_table.copy()
        rows["vintage"] = vintage

        emp = employment.loc[employment["vintage"].eq(vintage)].copy()
        emp = emp.merge(
            rows[["area", "period"]],
            on=["area", "period"],
            how="right",
        )
        emp["employment"] = emp["employment"].fillna(0.0)

        grid = (
            rows[["area", "period", "total_employment"]]
            .drop_duplicates(["area", "period"])
            .assign(key=1)
            .merge(pd.DataFrame({"industry": industries, "key": 1}), on="key")
            .drop(columns="key")
        )

        emp = grid.merge(
            emp[["area", "period", "industry", "employment"]],
            on=["area", "period", "industry"],
            how="left",
        )
        emp["employment"] = emp["employment"].fillna(0.0)

        emp = emp.merge(
            national.loc[national["vintage"].eq(vintage)],
            on=["period", "industry"],
            how="left",
            validate="many_to_one",
        )
        emp = emp.merge(
            trade[["period", "industry", change_column, "price_index", "years"]],
            on=["period", "industry"],
            how="left",
            validate="many_to_one",
        )

        emp["component"] = (
            emp["employment"]
            / emp["total_employment"]
            * emp[change_column]
            / emp["national_employment"]
            / (emp["price_index"] / 100.0)
            / 1000.0
            * (10.0 / emp["years"])
        )

        return (
            emp.groupby(["area", "period"], as_index=False)["component"]
            .sum()
            .rename(columns={"component": "exposure"})
        )

    x = build_exposure(base_areas, "base", "us_change").rename(
        columns={"exposure": "x"}
    )
    z = build_exposure(early_areas, "early", "other_change").rename(
        columns={"exposure": "z"}
    )

    data = (
        outcomes.merge(
            base_areas[
                ["area", "period", "population"]
            ],
            on=["area", "period"],
            how="inner",
            validate="one_to_one",
        )
        .merge(x, on=["area", "period"], how="inner", validate="one_to_one")
        .merge(z, on=["area", "period"], how="inner", validate="one_to_one")
    )

    data["period_numeric"] = pd.to_numeric(data["period"])
    n_obs = int(len(data))

    y = data["change_pp"].to_numpy(dtype=float)
    exog = np.column_stack(
        [
            np.ones(n_obs),
            data["period_numeric"].to_numpy(dtype=float),
            data["control"].to_numpy(dtype=float),
        ]
    )
    endogenous = data[["x"]].to_numpy(dtype=float)
    excluded_instrument = data[["z"]].to_numpy(dtype=float)
    instruments = np.column_stack([exog, excluded_instrument])

    weights = data["population"].to_numpy(dtype=float)
    root_weights = np.sqrt(weights)

    y_w = root_weights * y
    xreg = np.column_stack([exog, endogenous])
    xreg_w = root_weights[:, None] * xreg
    instruments_w = root_weights[:, None] * instruments

    projection = instruments_w @ np.linalg.pinv(instruments_w)
    fitted_regressors = projection @ xreg_w
    coefficients = np.linalg.lstsq(fitted_regressors, y_w, rcond=None)[0]
    iv_slope = float(coefficients[-1])

    period_values = sorted(data["period"].unique().tolist(), key=period_sort_key)

    def area_zero_value(column, period):
        match = data.loc[
            data["area"].astype(str).eq("0") & data["period"].eq(period), column
        ]
        if len(match) != 1:
            raise ValueError(f"Expected one area 0 row for period {period}")
        return float(match.iloc[0])

    period0 = period_values[0]
    period1 = period_values[1]

    result = {
        "task_id": "applied_multivintage_trade_iv",
        "platform": "python",
        "estimates": [
            {
                "term": "iv_slope",
                "estimate": iv_slope,
                "se": None,
                "n_obs": 72,
            },
            {
                "term": "exposure_area0_period0",
                "estimate": area_zero_value("x", period0),
                "se": None,
                "n_obs": 72,
            },
            {
                "term": "exposure_area0_period1",
                "estimate": area_zero_value("x", period1),
                "se": None,
                "n_obs": 72,
            },
            {
                "term": "instrument_area0_period0",
                "estimate": area_zero_value("z", period0),
                "se": None,
                "n_obs": 72,
            },
        ],
        "method_metadata": {
            "estimator": "weighted two-stage least squares",
            "dependent_variable": "change_pp",
            "endogenous_variable": "x",
            "excluded_instrument": "z",
            "exogenous_variables": ["intercept", "period", "control"],
            "weight": "base-vintage population",
        },
        "diagnostics": {
            "n_obs": n_obs,
            "n_exogenous": 3,
            "n_instruments": 4,
        },
    }

    with Path("result.json").open("w", encoding="utf-8") as file:
        json.dump(result, file, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
