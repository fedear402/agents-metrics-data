import json
import numpy as np
import pandas as pd

crosswalk = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv")
areas = pd.read_csv("areas.csv")
employment = pd.read_csv("employment.csv")
outcomes = pd.read_csv("outcomes.csv")

trade = trade.merge(crosswalk, on="code", how="inner")

employment = employment.merge(
    areas[["area", "period", "vintage", "total_employment"]],
    on=["area", "period", "vintage"],
    how="right",
)
employment = employment.merge(crosswalk, on="industry", how="left") if "industry" in employment.columns else employment

if "industry" not in employment.columns:
    employment = employment.merge(crosswalk, on="code", how="left")

employment["employment"] = employment["employment"].fillna(0.0)

all_industries = sorted(crosswalk["industry"].dropna().unique())
all_areas = sorted(areas["area"].dropna().unique())
all_periods = sorted(areas["period"].dropna().unique())

employment_grid = pd.MultiIndex.from_product(
    [all_areas, all_periods, ["base", "early"], all_industries],
    names=["area", "period", "vintage", "industry"],
).to_frame(index=False)

employment_grid = employment_grid.merge(
    employment[["area", "period", "vintage", "industry", "employment"]],
    on=["area", "period", "vintage", "industry"],
    how="left",
)
employment_grid["employment"] = employment_grid["employment"].fillna(0.0)

employment_grid = employment_grid.merge(
    areas[["area", "period", "vintage", "total_employment"]],
    on=["area", "period", "vintage"],
    how="left",
)

national = (
    employment_grid.groupby(["period", "vintage", "industry"], as_index=False)["employment"]
    .sum()
    .rename(columns={"employment": "national_employment"})
)

employment_grid = employment_grid.merge(
    national,
    on=["period", "vintage", "industry"],
    how="left",
)

trade_period = trade[
    ["period", "industry", "us_change", "other_change", "price_index", "years"]
].copy()

def calculate_exposure(vintage, change_column):
    df = employment_grid[employment_grid["vintage"] == vintage].copy()
    df = df.merge(trade_period, on=["period", "industry"], how="left")
    df["component"] = (
        (df["employment"] / df["total_employment"])
        * (df[change_column] / df["national_employment"])
        / (df["price_index"] / 100.0)
        / 1000.0
        * (10.0 / df["years"])
    )
    return (
        df.groupby(["area", "period"], as_index=False)["component"]
        .sum()
        .rename(columns={"component": "exposure"})
    )

x_df = calculate_exposure("base", "us_change").rename(columns={"exposure": "x"})
z_df = calculate_exposure("early", "other_change").rename(columns={"exposure": "z"})

base_population = areas[areas["vintage"] == "base"][
    ["area", "period", "population"]
].drop_duplicates()

sample = (
    outcomes.merge(base_population, on=["area", "period"], how="inner")
    .merge(x_df, on=["area", "period"], how="inner")
    .merge(z_df, on=["area", "period"], how="inner")
)

sample["period_numeric"] = pd.to_numeric(sample["period"], errors="raise")

y = sample["change_pp"].to_numpy(dtype=float)
x = sample["x"].to_numpy(dtype=float)
z = sample["z"].to_numpy(dtype=float)
weights = sample["population"].to_numpy(dtype=float)

period_values = sorted(sample["period_numeric"].unique())
period_column = (
    (sample["period_numeric"].to_numpy() == period_values[1]).astype(float)
    if len(period_values) == 2
    else sample["period_numeric"].to_numpy(dtype=float)
)

exog = np.column_stack([
    np.ones(len(sample)),
    period_column,
    sample["control"].to_numpy(dtype=float),
])
instruments = np.column_stack([exog, z])
regressors = np.column_stack([exog, x])

sqrt_weights = np.sqrt(weights)
weighted_instruments = instruments * sqrt_weights[:, None]
weighted_regressors = regressors * sqrt_weights[:, None]
weighted_y = y * sqrt_weights

projection_coefficients = np.linalg.lstsq(
    weighted_instruments,
    weighted_regressors,
    rcond=None,
)[0]
fitted_regressors = instruments @ projection_coefficients
weighted_fitted_regressors = fitted_regressors * sqrt_weights[:, None]

iv_coefficients = np.linalg.lstsq(
    weighted_fitted_regressors,
    weighted_y,
    rcond=None,
)[0]

iv_slope = float(iv_coefficients[-1])

def value_for(area_value, period_value, column):
    row = sample[
        (sample["area"].astype(str) == str(area_value))
        & (sample["period"].astype(str) == str(period_value))
    ]
    return float(row.iloc[0][column])

n_obs = int(len(sample))

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "iv_slope",
            "estimate": iv_slope,
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "exposure_area0_period0",
            "estimate": value_for(0, 0, "x"),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "exposure_area0_period1",
            "estimate": value_for(0, 1, "x"),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "instrument_area0_period0",
            "estimate": value_for(0, 0, "z"),
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "weighted_two_stage_least_squares",
        "outcome": "change_pp",
        "endogenous_variable": "x",
        "instrument": "z",
        "exogenous_variables": ["intercept", "period", "control"],
        "weight": "base-vintage population",
        "exposure_units": "thousands of real dollars per worker per decade",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "specified_n_obs": 72,
        "all_exogenous_variables_instrumented": True,
    },
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, allow_nan=False)
