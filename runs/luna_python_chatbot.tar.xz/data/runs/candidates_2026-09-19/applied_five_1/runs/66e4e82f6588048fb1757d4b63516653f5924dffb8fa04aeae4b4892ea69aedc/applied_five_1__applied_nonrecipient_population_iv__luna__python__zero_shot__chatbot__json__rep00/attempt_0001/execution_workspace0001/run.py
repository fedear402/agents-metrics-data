import csv
import json
import numpy as np


def read_csv(path):
    with open(path, newline="") as f:
        return list(csv.DictReader(f))


households = read_csv("households.csv")
census = read_csv("census.csv")

retained = [row for row in households if int(float(row["recipient"])) == 0]
n_obs = len(retained)

eligible = np.array([float(row["eligible"]) for row in retained])
dose = np.array([float(row["dose"]) for row in retained])
instrument = np.array([float(row["instrument"]) for row in retained])
baseline = np.array([float(row["baseline"]) for row in retained])
weight = np.array([float(row["weight"]) for row in retained])
outcome = np.array([float(row["outcome"]) for row in retained])

ineligible = 1.0 - eligible

exogenous = np.column_stack([
    ineligible,
    eligible,
    baseline * ineligible,
    baseline * eligible,
])

endogenous = np.column_stack([
    dose * ineligible,
    dose * eligible,
])

instruments = np.column_stack([
    exogenous,
    instrument * ineligible,
    instrument * eligible,
])

sqrt_weight = np.sqrt(weight)
z_weighted = instruments * sqrt_weight[:, None]
x_weighted = np.column_stack([exogenous, endogenous]) * sqrt_weight[:, None]
y_weighted = outcome * sqrt_weight

first_stage_coefficients = np.linalg.lstsq(
    z_weighted,
    x_weighted,
    rcond=None,
)[0]

fitted_x = instruments @ first_stage_coefficients
fitted_x_weighted = fitted_x * sqrt_weight[:, None]

second_stage_coefficients = np.linalg.lstsq(
    fitted_x_weighted,
    y_weighted,
    rcond=None,
)[0]

ineligible_slope = second_stage_coefficients[4]
eligible_slope = second_stage_coefficients[5]

ineligible_mask = eligible == 0
eligible_mask = eligible == 1

ineligible_mean_dose = np.average(
    dose[ineligible_mask],
    weights=weight[ineligible_mask],
)
eligible_mean_dose = np.average(
    dose[eligible_mask],
    weights=weight[eligible_mask],
)

ineligible_effect = ineligible_slope * ineligible_mean_dose
eligible_nonrecipient_effect = eligible_slope * eligible_mean_dose

census_ineligible_population = sum(
    float(row["nonrecipient_population"])
    for row in census
    if int(float(row["eligible"])) == 0
)
census_eligible_population = sum(
    float(row["nonrecipient_population"])
    for row in census
    if int(float(row["eligible"])) == 1
)

total_population = census_ineligible_population + census_eligible_population
population_effect = (
    ineligible_effect * census_ineligible_population
    + eligible_nonrecipient_effect * census_eligible_population
) / total_population

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "ineligible_effect",
            "estimate": float(ineligible_effect),
            "se": None,
            "n_obs": int(n_obs),
        },
        {
            "term": "eligible_nonrecipient_effect",
            "estimate": float(eligible_nonrecipient_effect),
            "se": None,
            "n_obs": int(n_obs),
        },
        {
            "term": "population_effect",
            "estimate": float(population_effect),
            "se": None,
            "n_obs": int(n_obs),
        },
    ],
    "method_metadata": {
        "estimator": "weighted_2sls",
        "endogenous_columns": [
            "dose*(1-eligible)",
            "dose*eligible",
        ],
        "exogenous_columns": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
        ],
        "instrument_columns": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
            "instrument*(1-eligible)",
            "instrument*eligible",
        ],
        "intercept": False,
        "weight_variable": "weight",
        "retained_condition": "recipient == 0",
        "counterfactual": "dose equals zero for every retained household",
        "group_effect_convention": (
            "dose slope multiplied by the household-weighted mean dose "
            "among retained observations"
        ),
        "population_weight_variable": "nonrecipient_population",
        "population_weight_source": "census.csv",
        "census_used_for_estimation": False,
    },
    "diagnostics": {
        "n_obs": int(n_obs),
        "n_retained_ineligible": int(np.sum(ineligible_mask)),
        "n_retained_eligible": int(np.sum(eligible_mask)),
        "ineligible_weighted_mean_dose": float(ineligible_mean_dose),
        "eligible_weighted_mean_dose": float(eligible_mean_dose),
        "ineligible_census_population": float(census_ineligible_population),
        "eligible_census_population": float(census_eligible_population),
        "attribution": (
            "Effects are attributed to the zero-dose counterfactual "
            "under the stated synthetic convention."
        ),
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
