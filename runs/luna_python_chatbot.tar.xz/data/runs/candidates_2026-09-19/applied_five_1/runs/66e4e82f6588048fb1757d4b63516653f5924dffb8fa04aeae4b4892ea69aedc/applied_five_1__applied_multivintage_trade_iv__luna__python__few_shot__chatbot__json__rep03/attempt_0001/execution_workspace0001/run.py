import json
from pathlib import Path

import numpy as np
import pandas as pd


def period_values(series):
    numeric = pd.to_numeric(series, errors="coerce")
    if numeric.notna().all():
        return numeric.to_numpy(dtype=float)
    codes, _ = pd.factorize(series, sort=True)
    return codes.astype(float)


def main():
    root = Path.cwd()

    crosswalk = pd.read_csv(root / "crosswalk.csv")
    trade = pd.read_csv(root / "trade.csv")
    areas = pd.read_csv(root / "areas.csv")
    employment = pd.read_csv(root / "employment.csv")
    outcomes = pd.read_csv(root / "outcomes.csv")

    trade = trade.merge(crosswalk, on="code", how="inner", validate="many_to_one")

    area_period = (
        areas.loc[areas["vintage"].eq("base"),
                  ["area", "period", "total_employment", "population"]]
        .drop_duplicates(["area", "period"])
    )

    panel = area_period.merge(
        outcomes[["area", "period", "control", "change_pp"]],
        on=["area", "period"],
        how="inner",
        validate="one_to_one",
    )

    industries = crosswalk["industry"].drop_duplicates().tolist()

    employment = employment.copy()
    employment["employment"] = employment["employment"].fillna(0.0)

    def calculate_exposure(vintage, change_column):
        e = employment.loc[employment["vintage"].eq(vintage)].copy()

        keys = ["area", "period"]
        e = (
            area_period[keys]
            .assign(_key=1)
            .merge(pd.DataFrame({"industry": industries, "_key": 1}),
                   on="_key", how="outer")
            .drop(columns="_key")
            .merge(
                e[keys + ["industry", "employment"]],
                on=keys + ["industry"],
                how="left",
            )
        )
        e["employment"] = e["employment"].fillna(0.0)

        national = (
            e.groupby(["period", "industry"], as_index=False)["employment"]
            .sum()
            .rename(columns={"employment": "national_employment"})
        )

        e = e.merge(national, on=["period", "industry"], how="left")
        e = e.merge(
            trade[["period", "industry", change_column, "price_index", "years"]],
            on=["period", "industry"],
            how="left",
            validate="many_to_one",
        )
        e = e.merge(
            area_period[keys + ["total_employment"]],
            on=keys,
            how="left",
            validate="many_to_one",
            suffixes=("", "_area"),
        )

        e["component"] = (
            e["employment"] / e["total_employment"]
            * e[change_column] / e["national_employment"]
            / (e["price_index"] / 100.0)
            / 1000.0
            * (10.0 / e["years"])
        )

        return (
            e.groupby(keys, as_index=False)["component"]
            .sum()
            .rename(columns={"component": "exposure"})
        )

    x = calculate_exposure("base", "us_change").rename(columns={"exposure": "x"})
    z = calculate_exposure("early", "other_change").rename(columns={"exposure": "z"})

    panel = panel.merge(x, on=["area", "period"], how="inner", validate="one_to_one")
    panel = panel.merge(z, on=["area", "period"], how="inner", validate="one_to_one")

    period_numeric = period_values(panel["period"])
    exog = np.column_stack([
        np.ones(len(panel)),
        period_numeric,
        panel["control"].to_numpy(dtype=float),
    ])
    x_values = panel["x"].to_numpy(dtype=float)
    z_values = panel["z"].to_numpy(dtype=float)
    y_values = panel["change_pp"].to_numpy(dtype=float)
    weights = panel["population"].to_numpy(dtype=float)

    sqrt_weights = np.sqrt(weights)

    instruments = np.column_stack([exog, z_values])
    weighted_instruments = instruments * sqrt_weights[:, None]
    weighted_x = x_values * sqrt_weights
    first_stage_coefficients = np.linalg.lstsq(
        weighted_instruments, weighted_x, rcond=None
    )[0]
    x_fitted = instruments @ first_stage_coefficients

    second_stage = np.column_stack([exog, x_fitted])
    weighted_second_stage = second_stage * sqrt_weights[:, None]
    weighted_y = y_values * sqrt_weights
    coefficients = np.linalg.lstsq(
        weighted_second_stage, weighted_y, rcond=None
    )[0]

    area_zero = panel[panel["area"].astype(str).eq("0")].copy()
    periods = sorted(area_zero["period"].unique(), key=lambda value: str(value))
    period_zero = periods[0]
    period_one = periods[1]

    x_area0_period0 = float(
        area_zero.loc[area_zero["period"].eq(period_zero), "x"].iloc[0]
    )
    x_area0_period1 = float(
        area_zero.loc[area_zero["period"].eq(period_one), "x"].iloc[0]
    )
    z_area0_period0 = float(
        area_zero.loc[area_zero["period"].eq(period_zero), "z"].iloc[0]
    )

    n_obs = int(len(panel))
    result = {
        "task_id": "applied_multivintage_trade_iv",
        "platform": "python",
        "estimates": [
            {
                "term": "iv_slope",
                "estimate": float(coefficients[-1]),
                "se": None,
                "n_obs": n_obs,
            },
            {
                "term": "exposure_area0_period0",
                "estimate": x_area0_period0,
                "se": None,
                "n_obs": n_obs,
            },
            {
                "term": "exposure_area0_period1",
                "estimate": x_area0_period1,
                "se": None,
                "n_obs": n_obs,
            },
            {
                "term": "instrument_area0_period0",
                "estimate": z_area0_period0,
                "se": None,
                "n_obs": n_obs,
            },
        ],
        "method_metadata": {
            "estimator": "weighted two-stage least squares",
            "outcome": "change_pp",
            "endogenous_regressor": "x",
            "excluded_instrument": "z",
            "exogenous_instruments": ["intercept", "period", "control"],
            "weight": "base-vintage population",
        },
        "diagnostics": {
            "n_obs": n_obs,
            "n_areas": int(panel["area"].nunique()),
            "n_periods": int(panel["period"].nunique()),
        },
    }

    with open(root / "result.json", "w", encoding="utf-8") as handle:
        json.dump(result, handle, indent=2)


if __name__ == "__main__":
    main()
