import json
from pathlib import Path

import numpy as np
import pandas as pd


def main():
    households = pd.read_csv(Path("households.csv"))
    census = pd.read_csv(Path("census.csv"))

    data = households.loc[households["recipient"] == 0].copy()
    n_obs = int(len(data))

    eligible = data["eligible"].to_numpy(dtype=float)
    ineligible = 1.0 - eligible
    dose = data["dose"].to_numpy(dtype=float)
    instrument = data["instrument"].to_numpy(dtype=float)
    baseline = data["baseline"].to_numpy(dtype=float)
    outcome = data["outcome"].to_numpy(dtype=float)
    weight = data["weight"].to_numpy(dtype=float)

    endogenous = np.column_stack(
        [
            dose * ineligible,
            dose * eligible,
        ]
    )

    exogenous = np.column_stack(
        [
            ineligible,
            eligible,
            baseline * ineligible,
            baseline * eligible,
        ]
    )

    instruments = np.column_stack(
        [
            exogenous,
            instrument * ineligible,
            instrument * eligible,
        ]
    )

    sqrt_weight = np.sqrt(weight)

    weighted_z = instruments * sqrt_weight[:, None]
    weighted_x = np.column_stack([exogenous, endogenous]) * sqrt_weight[:, None]
    weighted_y = outcome * sqrt_weight

    ztz_inv = np.linalg.pinv(weighted_z.T @ weighted_z)
    projection_x = weighted_z @ ztz_inv @ weighted_z.T @ weighted_x
    projection_y = weighted_z @ ztz_inv @ weighted_z.T @ weighted_y

    second_stage_x = weighted_x.T @ projection_x
    second_stage_y = weighted_x.T @ projection_y
    coefficients = np.linalg.pinv(second_stage_x) @ second_stage_y

    ineligible_slope = float(coefficients[4])
    eligible_slope = float(coefficients[5])

    ineligible_mean_dose = float(
        np.sum(weight * dose * ineligible) / np.sum(weight * ineligible)
    )
    eligible_mean_dose = float(
        np.sum(weight * dose * eligible) / np.sum(weight * eligible)
    )

    ineligible_effect = ineligible_slope * ineligible_mean_dose
    eligible_nonrecipient_effect = eligible_slope * eligible_mean_dose

    census_group = (
        census.groupby("eligible", as_index=False)["nonrecipient_population"]
        .sum()
    )
    population_by_group = {
        int(row["eligible"]): float(row["nonrecipient_population"])
        for _, row in census_group.iterrows()
    }

    ineligible_population = population_by_group.get(0, 0.0)
    eligible_population = population_by_group.get(1, 0.0)
    total_population = ineligible_population + eligible_population

    population_effect = (
        (
            ineligible_population * ineligible_effect
            + eligible_population * eligible_nonrecipient_effect
        )
        / total_population
    )

    result = {
        "task_id": "applied_nonrecipient_population_iv",
        "platform": "python",
        "estimates": [
            {
                "term": "ineligible_effect",
                "estimate": float(ineligible_effect),
                "se": None,
                "n_obs": n_obs,
            },
            {
                "term": "eligible_nonrecipient_effect",
                "estimate": float(eligible_nonrecipient_effect),
                "se": None,
                "n_obs": n_obs,
            },
            {
                "term": "population_effect",
                "estimate": float(population_effect),
                "se": None,
                "n_obs": n_obs,
            },
        ],
        "method_metadata": {
            "estimator": "weighted_two_stage_least_squares",
            "endogenous_columns": [
                "dose*(1-eligible)",
                "dose*eligible",
            ],
            "exogenous_columns": [
                "1-eligible",
                "eligible",
                "baseline*(1-eligible)",
                "baseline*eligible",
            ],
            "instrument_columns": [
                "1-eligible",
                "eligible",
                "baseline*(1-eligible)",
                "baseline*eligible",
                "instrument*(1-eligible)",
                "instrument*eligible",
            ],
            "intercept": False,
            "weight_column": "weight",
            "retained_sample": "recipient == 0",
            "group_effect_definition": "fitted dose slope times household-weighted mean dose",
            "population_weight_column": "nonrecipient_population",
            "counterfactual": "dose set to zero for every retained household",
            "attribution_convention": "synthetic attribution to the zero-dose counterfactual",
        },
        "diagnostics": {
            "n_obs": n_obs,
            "n_ineligible_retained": int(np.sum(ineligible)),
            "n_eligible_retained": int(np.sum(eligible)),
            "ineligible_mean_dose": ineligible_mean_dose,
            "eligible_mean_dose": eligible_mean_dose,
            "ineligible_population": ineligible_population,
            "eligible_population": eligible_population,
            "total_population": total_population,
        },
    }

    with open("result.json", "w", encoding="utf-8") as output_file:
        json.dump(result, output_file, indent=2)


if __name__ == "__main__":
    main()
