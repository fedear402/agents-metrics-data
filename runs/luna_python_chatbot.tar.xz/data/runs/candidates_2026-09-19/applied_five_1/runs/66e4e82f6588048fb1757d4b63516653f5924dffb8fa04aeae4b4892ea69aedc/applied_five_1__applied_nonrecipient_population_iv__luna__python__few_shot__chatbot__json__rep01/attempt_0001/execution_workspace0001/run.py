import json
import numpy as np
import pandas as pd


def weighted_2sls(y, exog, endog, excluded_instruments, weights):
    y = np.asarray(y, dtype=float).reshape(-1, 1)
    exog = np.asarray(exog, dtype=float)
    endog = np.asarray(endog, dtype=float)
    excluded_instruments = np.asarray(excluded_instruments, dtype=float)
    weights = np.asarray(weights, dtype=float).reshape(-1)

    x = np.column_stack([exog, endog])
    z = np.column_stack([exog, excluded_instruments])

    sqrt_w = np.sqrt(weights).reshape(-1, 1)
    x_w = x * sqrt_w
    y_w = y * sqrt_w
    z_w = z * sqrt_w

    z_pseudoinverse = np.linalg.pinv(z_w)
    projected_x = z_w @ z_pseudoinverse @ x_w
    projected_y = z_w @ z_pseudoinverse @ y_w

    beta = np.linalg.lstsq(projected_x, projected_y, rcond=None)[0].reshape(-1)
    return beta, x, z


households = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

data = households.loc[households["recipient"] == 0].copy()
data["ineligible"] = 1.0 - data["eligible"].astype(float)
data["eligible_group"] = data["eligible"].astype(float)

data["dose_ineligible"] = data["dose"] * data["ineligible"]
data["dose_eligible"] = data["dose"] * data["eligible_group"]
data["baseline_ineligible"] = data["baseline"] * data["ineligible"]
data["baseline_eligible"] = data["baseline"] * data["eligible_group"]
data["instrument_ineligible"] = data["instrument"] * data["ineligible"]
data["instrument_eligible"] = data["instrument"] * data["eligible_group"]

exog_columns = [
    "ineligible",
    "eligible_group",
    "baseline_ineligible",
    "baseline_eligible",
]
endog_columns = ["dose_ineligible", "dose_eligible"]
instrument_columns = ["instrument_ineligible", "instrument_eligible"]

beta, x_matrix, z_matrix = weighted_2sls(
    y=data["outcome"],
    exog=data[exog_columns],
    endog=data[endog_columns],
    excluded_instruments=data[instrument_columns],
    weights=data["weight"],
)

ineligible_slope = float(beta[len(exog_columns)])
eligible_slope = float(beta[len(exog_columns) + 1])

ineligible = data["eligible"] == 0
eligible = data["eligible"] == 1

ineligible_mean_dose = float(
    np.average(data.loc[ineligible, "dose"], weights=data.loc[ineligible, "weight"])
)
eligible_mean_dose = float(
    np.average(data.loc[eligible, "dose"], weights=data.loc[eligible, "weight"])
)

ineligible_effect = ineligible_slope * ineligible_mean_dose
eligible_nonrecipient_effect = eligible_slope * eligible_mean_dose

population_counts = (
    census.groupby("eligible", as_index=False)["nonrecipient_population"].sum()
)
population_weights = {
    int(row["eligible"]): float(row["nonrecipient_population"])
    for _, row in population_counts.iterrows()
}

total_population = population_weights[0] + population_weights[1]
population_effect = (
    ineligible_effect * population_weights[0]
    + eligible_nonrecipient_effect * population_weights[1]
) / total_population

n_obs = int(len(data))

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "ineligible_effect",
            "estimate": float(ineligible_effect),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "eligible_nonrecipient_effect",
            "estimate": float(eligible_nonrecipient_effect),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "population_effect",
            "estimate": float(population_effect),
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "endogenous_columns": endog_columns,
        "exogenous_columns": exog_columns,
        "instrument_columns": exog_columns + instrument_columns,
        "weight_column": "weight",
        "retained_condition": "recipient == 0",
        "counterfactual": "dose set to zero for every retained household",
        "group_effect_definition": "dose slope times household-weighted mean dose",
        "population_weight_column": "nonrecipient_population",
        "population_weight_source": "census.csv",
        "intercept": "none beyond the specified group indicators",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "n_ineligible": int(ineligible.sum()),
        "n_eligible_nonrecipient": int(eligible.sum()),
        "ineligible_mean_dose": float(ineligible_mean_dose),
        "eligible_mean_dose": float(eligible_mean_dose),
        "ineligible_slope": float(ineligible_slope),
        "eligible_nonrecipient_slope": float(eligible_slope),
        "ineligible_population": population_weights[0],
        "eligible_nonrecipient_population": population_weights[1],
        "population_total": total_population,
    },
}

with open("result.json", "w", encoding="utf-8") as output_file:
    json.dump(result, output_file, indent=2, allow_nan=False)
