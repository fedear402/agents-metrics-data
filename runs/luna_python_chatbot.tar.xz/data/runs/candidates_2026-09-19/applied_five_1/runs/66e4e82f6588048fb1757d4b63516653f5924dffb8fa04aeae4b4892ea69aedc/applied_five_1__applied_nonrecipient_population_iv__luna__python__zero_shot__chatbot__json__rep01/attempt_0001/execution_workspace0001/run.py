import json
from pathlib import Path

import numpy as np
import pandas as pd


def weighted_least_squares(y, x, weights):
    sqrt_w = np.sqrt(np.asarray(weights, dtype=float))
    x_w = x * sqrt_w[:, None]
    y_w = np.asarray(y, dtype=float) * sqrt_w
    beta = np.linalg.pinv(x_w) @ y_w
    return beta


def main():
    households = pd.read_csv("households.csv")
    census = pd.read_csv("census.csv")

    retained = households.loc[households["recipient"] == 0].copy()
    n_obs = int(len(retained))

    eligible = retained["eligible"].to_numpy(dtype=float)
    ineligible = 1.0 - eligible
    dose = retained["dose"].to_numpy(dtype=float)
    instrument = retained["instrument"].to_numpy(dtype=float)
    baseline = retained["baseline"].to_numpy(dtype=float)
    outcome = retained["outcome"].to_numpy(dtype=float)
    weights = retained["weight"].to_numpy(dtype=float)

    endogenous = np.column_stack([
        dose * ineligible,
        dose * eligible,
    ])

    exogenous = np.column_stack([
        ineligible,
        eligible,
        baseline * ineligible,
        baseline * eligible,
    ])

    instruments = np.column_stack([
        ineligible,
        eligible,
        baseline * ineligible,
        baseline * eligible,
        instrument * ineligible,
        instrument * eligible,
    ])

    first_stage_coefficients = weighted_least_squares(
        endogenous,
        instruments,
        weights,
    )
    fitted_endogenous = instruments @ first_stage_coefficients

    second_stage_regressors = np.column_stack([
        exogenous,
        fitted_endogenous,
    ])
    second_stage_coefficients = weighted_least_squares(
        outcome,
        second_stage_regressors,
        weights,
    )

    ineligible_slope = float(second_stage_coefficients[4])
    eligible_slope = float(second_stage_coefficients[5])

    ineligible_mask = eligible == 0
    eligible_mask = eligible == 1

    ineligible_mean_dose = float(
        np.average(dose[ineligible_mask], weights=weights[ineligible_mask])
    )
    eligible_mean_dose = float(
        np.average(dose[eligible_mask], weights=weights[eligible_mask])
    )

    ineligible_effect = ineligible_slope * ineligible_mean_dose
    eligible_nonrecipient_effect = eligible_slope * eligible_mean_dose

    census_group_population = (
        census.groupby("eligible", as_index=False)["nonrecipient_population"]
        .sum()
        .set_index("eligible")["nonrecipient_population"]
    )

    ineligible_population = float(census_group_population.get(0, 0.0))
    eligible_population = float(census_group_population.get(1, 0.0))
    total_population = ineligible_population + eligible_population

    if total_population == 0:
        raise ValueError("Census nonrecipient_population total must be positive.")

    population_effect = (
        ineligible_effect * ineligible_population
        + eligible_nonrecipient_effect * eligible_population
    ) / total_population

    estimates = [
        {
            "term": "ineligible_effect",
            "estimate": float(ineligible_effect),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "eligible_nonrecipient_effect",
            "estimate": float(eligible_nonrecipient_effect),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "population_effect",
            "estimate": float(population_effect),
            "se": None,
            "n_obs": n_obs,
        },
    ]

    result = {
        "task_id": "applied_nonrecipient_population_iv",
        "platform": "python",
        "estimates": estimates,
        "method_metadata": {
            "estimator": "weighted_two_stage_least_squares",
            "endogenous_columns": [
                "dose*(1-eligible)",
                "dose*eligible",
            ],
            "exogenous_columns": [
                "1-eligible",
                "eligible",
                "baseline*(1-eligible)",
                "baseline*eligible",
            ],
            "instrument_columns": [
                "1-eligible",
                "eligible",
                "baseline*(1-eligible)",
                "baseline*eligible",
                "instrument*(1-eligible)",
                "instrument*eligible",
            ],
            "intercept_included": False,
            "weight_variable": "weight",
            "retention_rule": "recipient == 0",
            "counterfactual": "dose set to zero for every retained household",
            "effect_convention": (
                "Synthetic attribution equals fitted dose slope times "
                "the household-weighted mean dose in each eligibility group."
            ),
            "population_aggregation_weight": "census.nonrecipient_population",
        },
        "diagnostics": {
            "n_obs": n_obs,
            "ineligible_households": int(ineligible_mask.sum()),
            "eligible_nonrecipient_households": int(eligible_mask.sum()),
            "ineligible_population": ineligible_population,
            "eligible_nonrecipient_population": eligible_population,
            "total_population": total_population,
            "ineligible_weighted_mean_dose": ineligible_mean_dose,
            "eligible_weighted_mean_dose": eligible_mean_dose,
            "ineligible_dose_slope": ineligible_slope,
            "eligible_dose_slope": eligible_slope,
        },
    }

    with Path("result.json").open("w", encoding="utf-8") as output_file:
        json.dump(result, output_file, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
