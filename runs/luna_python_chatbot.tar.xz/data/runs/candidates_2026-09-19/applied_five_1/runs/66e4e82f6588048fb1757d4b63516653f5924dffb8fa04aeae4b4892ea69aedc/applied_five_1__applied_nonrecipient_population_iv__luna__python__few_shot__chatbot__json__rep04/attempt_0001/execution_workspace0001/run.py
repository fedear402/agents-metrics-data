import json
import numpy as np
import pandas as pd


def weighted_lstsq(X, y, weights):
    sqrt_w = np.sqrt(np.asarray(weights, dtype=float))
    Xw = X * sqrt_w[:, None]
    yw = np.asarray(y, dtype=float) * sqrt_w
    beta, _, _, _ = np.linalg.lstsq(Xw, yw, rcond=None)
    return beta


households = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

retained = households.loc[households["recipient"] == 0].copy()
n_obs = int(len(retained))

eligible = retained["eligible"].to_numpy(dtype=float)
ineligible = 1.0 - eligible
dose = retained["dose"].to_numpy(dtype=float)
instrument = retained["instrument"].to_numpy(dtype=float)
baseline = retained["baseline"].to_numpy(dtype=float)
outcome = retained["outcome"].to_numpy(dtype=float)
weights = retained["weight"].to_numpy(dtype=float)

exog = np.column_stack([
    ineligible,
    eligible,
    baseline * ineligible,
    baseline * eligible,
])

endogenous = np.column_stack([
    dose * ineligible,
    dose * eligible,
])

instruments = np.column_stack([
    ineligible,
    eligible,
    baseline * ineligible,
    baseline * eligible,
    instrument * ineligible,
    instrument * eligible,
])

first_stage_fitted = np.column_stack([
    instruments @ weighted_lstsq(instruments, endogenous[:, j], weights)
    for j in range(endogenous.shape[1])
])

second_stage_design = np.column_stack([exog, first_stage_fitted])
second_stage_coefficients = weighted_lstsq(
    second_stage_design,
    outcome,
    weights,
)

ineligible_slope = float(second_stage_coefficients[4])
eligible_slope = float(second_stage_coefficients[5])

ineligible_mask = eligible == 0
eligible_mask = eligible == 1

ineligible_mean_dose = float(np.average(
    dose[ineligible_mask],
    weights=weights[ineligible_mask],
))
eligible_mean_dose = float(np.average(
    dose[eligible_mask],
    weights=weights[eligible_mask],
))

ineligible_effect = ineligible_slope * ineligible_mean_dose
eligible_nonrecipient_effect = eligible_slope * eligible_mean_dose

census_weights = (
    census.set_index("eligible")["nonrecipient_population"]
    .reindex([0, 1])
    .to_numpy(dtype=float)
)

population_effect = float(np.average(
    [ineligible_effect, eligible_nonrecipient_effect],
    weights=census_weights,
))

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "ineligible_effect",
            "estimate": float(ineligible_effect),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "eligible_nonrecipient_effect",
            "estimate": float(eligible_nonrecipient_effect),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "population_effect",
            "estimate": float(population_effect),
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "weighted_2sls",
        "retained_condition": "recipient == 0",
        "counterfactual": "dose set to zero for every retained household",
        "group_effect_definition": "fitted dose slope times household-weighted mean dose",
        "population_aggregation": "census nonrecipient_population weights",
        "intercept": "none",
        "weight_variable": "weight",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "n_ineligible": int(ineligible_mask.sum()),
        "n_eligible_nonrecipient": int(eligible_mask.sum()),
        "census_nonrecipient_population_ineligible": int(census_weights[0]),
        "census_nonrecipient_population_eligible": int(census_weights[1]),
    },
}

with open("result.json", "w", encoding="utf-8") as output_file:
    json.dump(result, output_file, indent=2, allow_nan=False)
