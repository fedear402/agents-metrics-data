import json
from pathlib import Path

import numpy as np
import pandas as pd


def period_codes(series):
    numeric = pd.to_numeric(series, errors="coerce")
    if numeric.notna().all():
        return numeric.astype(float)
    return pd.Series(pd.Categorical(series).codes, index=series.index, dtype=float)


def main():
    root = Path.cwd()

    crosswalk = pd.read_csv(root / "crosswalk.csv")
    trade = pd.read_csv(root / "trade.csv")
    areas = pd.read_csv(root / "areas.csv")
    employment = pd.read_csv(root / "employment.csv")
    outcomes = pd.read_csv(root / "outcomes.csv")

    trade = trade.merge(crosswalk, on="code", how="inner", validate="many_to_one")

    national = (
        employment.merge(crosswalk, on="industry", how="inner")
        .groupby(["period", "vintage", "industry"], as_index=False)["employment"]
        .sum()
        .rename(columns={"employment": "national_employment"})
    )

    trade_industry = (
        trade.groupby(["period", "industry"], as_index=False)
        .agg(
            us_change=("us_change", "first"),
            other_change=("other_change", "first"),
            price_index=("price_index", "first"),
            years=("years", "first"),
        )
    )

    area_periods = outcomes[["area", "period"]].drop_duplicates()

    area_info = (
        areas[["area", "period", "vintage", "total_employment", "population"]]
        .drop_duplicates()
    )

    base_info = (
        area_info[area_info["vintage"].eq("base")]
        .drop(columns=["vintage"])
        .rename(
            columns={
                "total_employment": "base_total_employment",
                "population": "base_population",
            }
        )
    )

    early_info = (
        area_info[area_info["vintage"].eq("early")]
        .drop(columns=["vintage", "population"])
        .rename(columns={"total_employment": "early_total_employment"})
    )

    panel = (
        area_periods.merge(base_info, on=["area", "period"], how="left")
        .merge(early_info, on=["area", "period"], how="left")
        .merge(outcomes, on=["area", "period"], how="inner", validate="one_to_one")
    )

    industries = sorted(crosswalk["industry"].drop_duplicates().tolist())

    emp = employment.merge(crosswalk, on="industry", how="inner")
    emp = emp[["area", "period", "vintage", "industry", "employment"]]

    panel_long = (
        area_periods.assign(_key=1)
        .merge(pd.DataFrame({"industry": industries, "_key": 1}), on="_key")
        .drop(columns="_key")
        .merge(
            emp[emp["vintage"].eq("base")][
                ["area", "period", "industry", "employment"]
            ].rename(columns={"employment": "base_employment"}),
            on=["area", "period", "industry"],
            how="left",
        )
        .merge(
            emp[emp["vintage"].eq("early")][
                ["area", "period", "industry", "employment"]
            ].rename(columns={"employment": "early_employment"}),
            on=["area", "period", "industry"],
            how="left",
        )
        .fillna({"base_employment": 0.0, "early_employment": 0.0})
        .merge(
            trade_industry,
            on=["period", "industry"],
            how="inner",
            validate="many_to_one",
        )
        .merge(
            national[
                national["vintage"].eq("base")
            ][["period", "industry", "national_employment"]].rename(
                columns={"national_employment": "national_base_employment"}
            ),
            on=["period", "industry"],
            how="inner",
            validate="many_to_one",
        )
        .merge(
            national[
                national["vintage"].eq("early")
            ][["period", "industry", "national_employment"]].rename(
                columns={"national_employment": "national_early_employment"}
            ),
            on=["period", "industry"],
            how="inner",
            validate="many_to_one",
        )
        .merge(
            panel[
                [
                    "area",
                    "period",
                    "base_total_employment",
                    "early_total_employment",
                ]
            ],
            on=["area", "period"],
            how="inner",
        )
    )

    scale = (
        panel_long["price_index"].astype(float).rdiv(100.0)
        * 1000.0
    )

    base_component = (
        panel_long["base_employment"]
        / panel_long["base_total_employment"]
        * panel_long["us_change"]
        / panel_long["national_base_employment"]
        / scale
        * (10.0 / panel_long["years"])
    )

    early_component = (
        panel_long["early_employment"]
        / panel_long["early_total_employment"]
        * panel_long["other_change"]
        / panel_long["national_early_employment"]
        / scale
        * (10.0 / panel_long["years"])
    )

    exposures = (
        panel_long.assign(
            base_component=base_component,
            early_component=early_component,
        )
        .groupby(["area", "period"], as_index=False)
        .agg(x=("base_component", "sum"), z=("early_component", "sum"))
    )

    panel = panel.merge(exposures, on=["area", "period"], how="inner", validate="one_to_one")
    panel["period_reg"] = period_codes(panel["period"])

    y = panel["change_pp"].to_numpy(dtype=float)
    x = panel["x"].to_numpy(dtype=float)
    z = panel["z"].to_numpy(dtype=float)
    control = panel["control"].to_numpy(dtype=float)
    period_reg = panel["period_reg"].to_numpy(dtype=float)
    weights = panel["base_population"].to_numpy(dtype=float)

    regressors = np.column_stack(
        [np.ones(len(panel)), period_reg, control, x]
    )
    instruments = np.column_stack(
        [np.ones(len(panel)), period_reg, control, z]
    )

    sqrt_w = np.sqrt(weights)
    rw = regressors * sqrt_w[:, None]
    qw = instruments * sqrt_w[:, None]
    yw = y * sqrt_w

    q_cross = qw.T @ qw
    projection = qw @ np.linalg.pinv(q_cross) @ qw.T
    beta = np.linalg.pinv(rw.T @ projection @ rw) @ (rw.T @ projection @ yw)

    area0 = panel[panel["area"].eq(0)]
    x0 = area0.set_index("period")["x"]
    z00 = area0.loc[area0["period"].eq(0), "z"].iloc[0]

    n_obs = int(len(panel))

    result = {
        "task_id": "applied_multivintage_trade_iv",
        "platform": "python",
        "estimates": [
            {
                "term": "iv_slope",
                "estimate": float(beta[3]),
                "se": None,
                "n_obs": n_obs,
            },
            {
                "term": "exposure_area0_period0",
                "estimate": float(x0.loc[0]),
                "se": None,
                "n_obs": n_obs,
            },
            {
                "term": "exposure_area0_period1",
                "estimate": float(x0.loc[1]),
                "se": None,
                "n_obs": n_obs,
            },
            {
                "term": "instrument_area0_period0",
                "estimate": float(z00),
                "se": None,
                "n_obs": n_obs,
            },
        ],
        "method_metadata": {
            "estimator": "weighted_two_stage_least_squares",
            "dependent_variable": "change_pp",
            "endogenous_variable": "x",
            "instrument": "z",
            "exogenous_instruments": ["intercept", "period", "control"],
            "weight": "base-vintage population",
            "exposure_units": "thousands of real dollars per worker per decade",
        },
        "diagnostics": {
            "n_obs": n_obs,
            "n_industries": int(len(industries)),
            "n_area_periods": n_obs,
        },
    }

    with open(root / "result.json", "w", encoding="utf-8") as handle:
        json.dump(result, handle, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
