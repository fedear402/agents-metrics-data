import json
import numpy as np
import pandas as pd

crosswalk = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv")
areas = pd.read_csv("areas.csv")
employment = pd.read_csv("employment.csv")
outcomes = pd.read_csv("outcomes.csv")

trade = trade.merge(crosswalk, on="code", how="inner", validate="many_to_one")

keys = areas[["area", "period"]].drop_duplicates()
industries = crosswalk["industry"].drop_duplicates().tolist()
vintages = ["base", "early"]

grid = (
    keys.assign(_key=1)
    .merge(pd.DataFrame({"vintage": vintages, "_key": 1}), on="_key")
    .merge(pd.DataFrame({"industry": industries, "_key": 1}), on="_key")
    .drop(columns="_key")
)

employment_full = grid.merge(
    employment,
    on=["area", "period", "vintage", "industry"],
    how="left",
)
employment_full["employment"] = employment_full["employment"].fillna(0.0)

area_data = areas.merge(outcomes, on=["area", "period"], how="inner", validate="one_to_one")
area_data = area_data.merge(
    trade[["period", "industry", "us_change", "other_change", "price_index", "years"]],
    on="period",
    how="left",
)

national = (
    employment_full.groupby(["period", "vintage", "industry"], as_index=False)["employment"]
    .sum()
    .rename(columns={"employment": "national_employment"})
)

employment_full = employment_full.merge(
    national,
    on=["period", "vintage", "industry"],
    how="left",
    validate="many_to_one",
)

area_data = area_data.merge(
    employment_full[
        [
            "area",
            "period",
            "vintage",
            "industry",
            "employment",
            "national_employment",
        ]
    ],
    on=["area", "period"],
    how="left",
)

def calculate_exposure(frame, vintage, change_column):
    subset = frame[frame["vintage"] == vintage].copy()
    contribution = (
        subset["employment"]
        / subset["total_employment"]
        * subset[change_column]
        / subset["national_employment"]
        / (subset["price_index"] / 100.0)
        / 1000.0
        * (10.0 / subset["years"])
    )
    return contribution.groupby([subset["area"], subset["period"]]).sum()

trade_by_period_industry = trade[
    ["period", "industry", "us_change", "other_change", "price_index", "years"]
].drop_duplicates()

area_data = area_data.drop(
    columns=["us_change", "other_change", "price_index", "years"],
    errors="ignore",
).merge(
    trade_by_period_industry,
    on=["period", "industry"],
    how="left",
    validate="many_to_many",
)

x_series = calculate_exposure(area_data, "base", "us_change")
z_series = calculate_exposure(area_data, "early", "other_change")

estimation = areas[["area", "period", "population"]].drop_duplicates()
estimation = estimation.merge(
    outcomes,
    on=["area", "period"],
    how="inner",
    validate="one_to_one",
)

period_numeric = pd.to_numeric(estimation["period"], errors="coerce")
if period_numeric.isna().any():
    period_numeric = pd.Series(
        pd.factorize(estimation["period"])[0],
        index=estimation.index,
        dtype=float,
    )

estimation["period_regressor"] = period_numeric.to_numpy()
estimation["x"] = [
    x_series.loc[(row.area, row.period)] for row in estimation.itertuples()
]
estimation["z"] = [
    z_series.loc[(row.area, row.period)] for row in estimation.itertuples()
]

n_obs = len(estimation)
assert n_obs == 72

y = estimation["change_pp"].to_numpy(dtype=float)
x = estimation[["period_regressor", "control", "x"]].to_numpy(dtype=float)
X = np.column_stack([np.ones(n_obs), x])

Z = np.column_stack(
    [
        np.ones(n_obs),
        estimation["period_regressor"].to_numpy(dtype=float),
        estimation["control"].to_numpy(dtype=float),
        estimation["z"].to_numpy(dtype=float),
    ]
)

weights = estimation["population"].to_numpy(dtype=float)
sqrt_weights = np.sqrt(weights)

yw = y * sqrt_weights
Xw = X * sqrt_weights[:, None]
Zw = Z * sqrt_weights[:, None]

Q, _ = np.linalg.qr(Zw, mode="reduced")
Xhatw = Q @ (Q.T @ Xw)
beta = np.linalg.lstsq(Xhatw, yw, rcond=None)[0]

area0_period0 = float(
    x_series.loc[
        (
            estimation.loc[estimation["area"].eq(0), "area"].iloc[0],
            estimation.loc[estimation["period"].eq(0), "period"].iloc[0],
        )
    ]
)
area0_period1 = float(
    x_series.loc[
        (
            estimation.loc[estimation["area"].eq(0), "area"].iloc[0],
            estimation.loc[estimation["period"].eq(1), "period"].iloc[0],
        )
    ]
)
instrument_area0_period0 = float(
    z_series.loc[
        (
            estimation.loc[estimation["area"].eq(0), "area"].iloc[0],
            estimation.loc[estimation["period"].eq(0), "period"].iloc[0],
        )
    ]
)

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "iv_slope",
            "estimate": float(beta[-1]),
            "se": None,
            "n_obs": 72,
        },
        {
            "term": "exposure_area0_period0",
            "estimate": area0_period0,
            "se": None,
            "n_obs": 72,
        },
        {
            "term": "exposure_area0_period1",
            "estimate": area0_period1,
            "se": None,
            "n_obs": 72,
        },
        {
            "term": "instrument_area0_period0",
            "estimate": instrument_area0_period0,
            "se": None,
            "n_obs": 72,
        },
    ],
    "method_metadata": {
        "estimator": "weighted_two_stage_least_squares",
        "outcome": "change_pp",
        "endogenous_regressor": "x",
        "excluded_instrument": "z",
        "exogenous_regressors": ["intercept", "period", "control"],
        "weight": "base-vintage population",
        "exposure_units": "thousands of real dollars per worker per decade",
    },
    "diagnostics": {
        "n_obs": 72,
        "n_exogenous_instruments": 3,
        "n_excluded_instruments": 1,
    },
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file, indent=2)
