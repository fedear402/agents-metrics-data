import csv
import json
import numpy as np


def read_csv(path):
    with open(path, newline="", encoding="utf-8") as file:
        return list(csv.DictReader(file))


households = read_csv("households.csv")
census = read_csv("census.csv")

retained = [
    row for row in households
    if int(float(row["recipient"])) == 0
]

n_obs = len(retained)

eligible = np.array(
    [float(row["eligible"]) for row in retained],
    dtype=float,
)
ineligible = 1.0 - eligible
dose = np.array(
    [float(row["dose"]) for row in retained],
    dtype=float,
)
instrument = np.array(
    [float(row["instrument"]) for row in retained],
    dtype=float,
)
baseline = np.array(
    [float(row["baseline"]) for row in retained],
    dtype=float,
)
outcome = np.array(
    [float(row["outcome"]) for row in retained],
    dtype=float,
)
weight = np.array(
    [float(row["weight"]) for row in retained],
    dtype=float,
)

# Endogenous regressors.
endogenous = np.column_stack([
    dose * ineligible,
    dose * eligible,
])

# Exogenous regressors, with no intercept.
exogenous = np.column_stack([
    ineligible,
    eligible,
    baseline * ineligible,
    baseline * eligible,
])

# Excluded instruments plus all exogenous regressors.
instruments = np.column_stack([
    exogenous,
    instrument * ineligible,
    instrument * eligible,
])

sqrt_weight = np.sqrt(weight)
weighted_instruments = instruments * sqrt_weight[:, None]
weighted_endogenous = endogenous * sqrt_weight[:, None]
weighted_exogenous = exogenous * sqrt_weight[:, None]
weighted_outcome = outcome * sqrt_weight

# First-stage fitted values for all endogenous regressors.
first_stage_coefficients = (
    np.linalg.pinv(weighted_instruments)
    @ weighted_endogenous
)
fitted_endogenous = instruments @ first_stage_coefficients

# Second-stage weighted least squares using fitted endogenous regressors.
second_stage_regressors = np.column_stack([
    exogenous,
    fitted_endogenous,
])
weighted_second_stage_regressors = (
    second_stage_regressors * sqrt_weight[:, None]
)
coefficients = (
    np.linalg.pinv(weighted_second_stage_regressors)
    @ weighted_outcome
)

ineligible_slope = float(coefficients[4])
eligible_slope = float(coefficients[5])

ineligible_mean_dose = float(
    np.sum(weight[ineligible == 1.0] * dose[ineligible == 1.0])
    / np.sum(weight[ineligible == 1.0])
)
eligible_mean_dose = float(
    np.sum(weight[eligible == 1.0] * dose[eligible == 1.0])
    / np.sum(weight[eligible == 1.0])
)

ineligible_effect = ineligible_slope * ineligible_mean_dose
eligible_nonrecipient_effect = eligible_slope * eligible_mean_dose

census_totals = {0: 0.0, 1: 0.0}
for row in census:
    group = int(float(row["eligible"]))
    census_totals[group] += float(row["nonrecipient_population"])

total_population = census_totals[0] + census_totals[1]
population_effect = (
    ineligible_effect * census_totals[0]
    + eligible_nonrecipient_effect * census_totals[1]
) / total_population

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "ineligible_effect",
            "estimate": float(ineligible_effect),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "eligible_nonrecipient_effect",
            "estimate": float(eligible_nonrecipient_effect),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "population_effect",
            "estimate": float(population_effect),
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "weighted_2sls",
        "endogenous_columns": [
            "dose*(1-eligible)",
            "dose*eligible",
        ],
        "exogenous_columns": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
        ],
        "instrument_columns": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
            "instrument*(1-eligible)",
            "instrument*eligible",
        ],
        "intercept": False,
        "weight_column": "weight",
        "retained_condition": "recipient == 0",
        "counterfactual": "dose == 0 for every retained household",
        "group_effect_definition": (
            "fitted dose slope multiplied by the household-weighted "
            "mean dose among retained observations"
        ),
        "population_aggregation_weight": "census.nonrecipient_population",
        "attribution_convention": (
            "synthetic attribution to a zero-dose counterfactual"
        ),
    },
    "diagnostics": {
        "n_obs": n_obs,
        "n_retained_ineligible": int(np.sum(ineligible == 1.0)),
        "n_retained_eligible": int(np.sum(eligible == 1.0)),
        "census_nonrecipient_population_ineligible": census_totals[0],
        "census_nonrecipient_population_eligible": census_totals[1],
    },
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file, indent=2)
