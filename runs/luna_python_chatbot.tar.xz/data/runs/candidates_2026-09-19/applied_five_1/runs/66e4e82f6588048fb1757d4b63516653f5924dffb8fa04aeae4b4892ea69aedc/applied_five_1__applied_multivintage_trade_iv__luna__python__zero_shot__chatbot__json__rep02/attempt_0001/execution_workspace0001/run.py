import json
from pathlib import Path

import numpy as np
import pandas as pd


def main():
    crosswalk = pd.read_csv("crosswalk.csv")
    trade = pd.read_csv("trade.csv")
    areas = pd.read_csv("areas.csv")
    employment = pd.read_csv("employment.csv")
    outcomes = pd.read_csv("outcomes.csv")

    trade = trade.merge(crosswalk, on="code", how="inner", validate="many_to_one")

    area_periods = areas[["area", "period"]].drop_duplicates()
    industries = crosswalk["industry"].drop_duplicates().tolist()

    emp_grid = (
        area_periods.assign(_key=1)
        .merge(pd.DataFrame({"industry": industries, "_key": 1}), on="_key")
        .drop(columns="_key")
    )

    employment_full = emp_grid.merge(
        employment,
        on=["area", "period", "industry"],
        how="left",
    )
    employment_full["employment"] = employment_full["employment"].fillna(0.0)

    area_data = areas.copy()
    employment_full = employment_full.merge(
        area_data,
        on=["area", "period", "vintage"],
        how="left",
        validate="many_to_one",
    )

    national = (
        employment_full.groupby(["period", "vintage", "industry"], as_index=False)
        ["employment"]
        .sum()
        .rename(columns={"employment": "national_employment"})
    )

    employment_full = employment_full.merge(
        national,
        on=["period", "vintage", "industry"],
        how="left",
        validate="many_to_one",
    )

    trade_period = trade[
        ["period", "industry", "us_change", "other_change", "price_index", "years"]
    ]

    employment_full = employment_full.merge(
        trade_period,
        on=["period", "industry"],
        how="left",
        validate="many_to_one",
    )

    def make_exposure(vintage, trade_change):
        d = employment_full[employment_full["vintage"] == vintage].copy()
        d["component"] = (
            (d["employment"] / d["total_employment"])
            * (d[trade_change] / d["national_employment"])
            / (d["price_index"] / 100.0)
            / 1000.0
            * (10.0 / d["years"])
        )
        return (
            d.groupby(["area", "period"], as_index=False)["component"]
            .sum()
            .rename(columns={"component": "exposure"})
        )

    x = make_exposure("base", "us_change").rename(columns={"exposure": "x"})
    z = make_exposure("early", "other_change").rename(columns={"exposure": "z"})

    regressions = (
        areas[areas["vintage"] == "base"]
        [["area", "period", "population"]]
        .drop_duplicates()
        .merge(outcomes, on=["area", "period"], how="inner", validate="one_to_one")
        .merge(x, on=["area", "period"], how="inner", validate="one_to_one")
        .merge(z, on=["area", "period"], how="inner", validate="one_to_one")
    )

    period_numeric = pd.to_numeric(regressions["period"], errors="coerce")
    if period_numeric.isna().any():
        period_numeric = pd.Series(
            pd.Categorical(regressions["period"]).codes,
            index=regressions.index,
            dtype=float,
        )

    y = regressions["change_pp"].to_numpy(dtype=float)
    x_value = regressions["x"].to_numpy(dtype=float)
    z_value = regressions["z"].to_numpy(dtype=float)
    control = regressions["control"].to_numpy(dtype=float)
    period_value = period_numeric.to_numpy(dtype=float)
    weights = regressions["population"].to_numpy(dtype=float)

    X = np.column_stack(
        [
            np.ones(len(regressions)),
            period_value,
            control,
            x_value,
        ]
    )
    Z = np.column_stack(
        [
            np.ones(len(regressions)),
            period_value,
            control,
            z_value,
        ]
    )

    sqrt_w = np.sqrt(weights)
    Xw = X * sqrt_w[:, None]
    Zw = Z * sqrt_w[:, None]
    yw = y * sqrt_w

    projection = Zw @ np.linalg.pinv(Zw.T @ Zw) @ Zw.T
    beta = np.linalg.pinv(Xw.T @ projection @ Xw) @ (Xw.T @ projection @ yw)
    iv_slope = float(beta[3])

    def value_for(area, period, column):
        match = regressions[
            (regressions["area"] == area)
            & (regressions["period"] == period)
        ]
        if match.empty:
            raise ValueError(f"Missing area-period row: area={area}, period={period}")
        return float(match.iloc[0][column])

    periods = sorted(regressions["period"].unique().tolist())
    period0 = periods[0]
    period1 = periods[1]

    result = {
        "task_id": "applied_multivintage_trade_iv",
        "platform": "python",
        "estimates": [
            {
                "term": "iv_slope",
                "estimate": iv_slope,
                "se": None,
                "n_obs": int(len(regressions)),
            },
            {
                "term": "exposure_area0_period0",
                "estimate": value_for(0, period0, "x"),
                "se": None,
                "n_obs": int(len(regressions)),
            },
            {
                "term": "exposure_area0_period1",
                "estimate": value_for(0, period1, "x"),
                "se": None,
                "n_obs": int(len(regressions)),
            },
            {
                "term": "instrument_area0_period0",
                "estimate": value_for(0, period0, "z"),
                "se": None,
                "n_obs": int(len(regressions)),
            },
        ],
        "method_metadata": {
            "estimator": "weighted_two_stage_least_squares",
            "outcome": "change_pp",
            "endogenous_regressor": "x",
            "instrument": "z",
            "exogenous_instruments": ["intercept", "period", "control"],
            "weight": "base_vintage_population",
            "sample_definition": "all area-period estimation rows",
        },
        "diagnostics": {
            "n_obs": int(len(regressions)),
            "n_industries": int(len(industries)),
            "n_periods": int(regressions["period"].nunique()),
            "n_areas": int(regressions["area"].nunique()),
        },
    }

    with Path("result.json").open("w", encoding="utf-8") as handle:
        json.dump(result, handle, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
