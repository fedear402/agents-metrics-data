import json
import numpy as np

data = np.genfromtxt("./input.csv", delimiter=",", names=True)

y = np.asarray(data["y"], dtype=float)
x = np.asarray(data["x"], dtype=float)
z = np.asarray(data["z"], dtype=float)
group = np.asarray(data["group"])

mask0 = group == 0
mask1 = group == 1

X0 = np.column_stack([np.ones(mask0.sum()), x[mask0], z[mask0]])
X1 = np.column_stack([np.ones(mask1.sum()), x[mask1], z[mask1]])

beta0 = np.linalg.lstsq(X0, y[mask0], rcond=None)[0]
beta1 = np.linalg.lstsq(X1, y[mask1], rcond=None)[0]

Xbar0 = X0.mean(axis=0)
Xbar1 = X1.mean(axis=0)

gap = y[mask1].mean() - y[mask0].mean()
explained = (Xbar1 - Xbar0) @ beta0
unexplained = Xbar1 @ (beta1 - beta0)
explained_x = (x[mask1].mean() - x[mask0].mean()) * beta0[1]

n_obs = len(y)

output = {
    "task_id": "broad_oaxaca",
    "platform": "python",
    "estimates": [
        {
            "term": "gap",
            "estimate": float(gap),
            "se": None,
            "n_obs": n_obs
        },
        {
            "term": "explained",
            "estimate": float(explained),
            "se": None,
            "n_obs": n_obs
        },
        {
            "term": "unexplained",
            "estimate": float(unexplained),
            "se": None,
            "n_obs": n_obs
        },
        {
            "term": "explained_x",
            "estimate": float(explained_x),
            "se": None,
            "n_obs": n_obs
        }
    ],
    "method_metadata": {},
    "diagnostics": {}
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
