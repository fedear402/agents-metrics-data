import csv
import json

def solve_linear_system(matrix, vector):
    n = len(vector)
    augmented = [list(matrix[i]) + [vector[i]] for i in range(n)]

    for col in range(n):
        pivot = max(range(col, n), key=lambda row: abs(augmented[row][col]))
        if abs(augmented[pivot][col]) < 1e-12:
            raise ValueError("Singular regression design matrix")
        augmented[col], augmented[pivot] = augmented[pivot], augmented[col]

        pivot_value = augmented[col][col]
        for j in range(col, n + 1):
            augmented[col][j] /= pivot_value

        for row in range(n):
            if row == col:
                continue
            factor = augmented[row][col]
            for j in range(col, n + 1):
                augmented[row][j] -= factor * augmented[col][j]

    return [augmented[i][n] for i in range(n)]

def fit_ols(rows):
    xtx = [[0.0] * 3 for _ in range(3)]
    xty = [0.0] * 3

    for y, x, z in rows:
        design = [1.0, x, z]
        for i in range(3):
            xty[i] += design[i] * y
            for j in range(3):
                xtx[i][j] += design[i] * design[j]

    return solve_linear_system(xtx, xty)

with open("input.csv", newline="") as file:
    reader = csv.DictReader(file)
    data = [
        (
            float(row["y"]),
            float(row["x"]),
            float(row["z"]),
            int(float(row["group"]))
        )
        for row in reader
    ]

n_obs = len(data)
group_0 = [(y, x, z) for y, x, z, g in data if g == 0]
group_1 = [(y, x, z) for y, x, z, g in data if g == 1]

beta_0 = fit_ols(group_0)
beta_1 = fit_ols(group_1)

mean_0 = [
    sum(row[i] for row in group_0) / len(group_0)
    for i in range(3)
]
mean_1 = [
    sum(row[i] for row in group_1) / len(group_1)
    for i in range(3)
]

gap = mean_1[0] - mean_0[0]
mean_difference = [mean_1[i] - mean_0[i] for i in range(3)]
explained = sum(mean_difference[i] * beta_0[i] for i in range(3))
unexplained = sum(mean_1[i] * (beta_1[i] - beta_0[i]) for i in range(3))
explained_x = (mean_1[1] - mean_0[1]) * beta_0[1]

result = {
    "task_id": "broad_oaxaca",
    "platform": "python",
    "estimates": [
        {
            "term": "gap",
            "estimate": gap,
            "se": None,
            "n_obs": n_obs
        },
        {
            "term": "explained",
            "estimate": explained,
            "se": None,
            "n_obs": n_obs
        },
        {
            "term": "unexplained",
            "estimate": unexplained,
            "se": None,
            "n_obs": n_obs
        },
        {
            "term": "explained_x",
            "estimate": explained_x,
            "se": None,
            "n_obs": n_obs
        }
    ],
    "method_metadata": {},
    "diagnostics": {}
}

with open("result.json", "w") as file:
    json.dump(result, file, indent=2)
