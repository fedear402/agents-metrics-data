import csv
import json
import math

def solve_linear_system(matrix, vector):
    n = len(vector)
    augmented = [list(matrix[i]) + [vector[i]] for i in range(n)]

    for col in range(n):
        pivot = max(range(col, n), key=lambda row: abs(augmented[row][col]))
        if abs(augmented[pivot][col]) < 1e-12:
            raise ValueError("Singular regression design matrix")

        augmented[col], augmented[pivot] = augmented[pivot], augmented[col]

        pivot_value = augmented[col][col]
        for j in range(col, n + 1):
            augmented[col][j] /= pivot_value

        for row in range(n):
            if row == col:
                continue
            factor = augmented[row][col]
            for j in range(col, n + 1):
                augmented[row][j] -= factor * augmented[col][j]

    return [augmented[i][n] for i in range(n)]

def fit_group(rows):
    xtx = [[0.0] * 3 for _ in range(3)]
    xty = [0.0] * 3

    for row in rows:
        x_vector = [1.0, row["x"], row["z"]]
        y_value = row["y"]

        for i in range(3):
            xty[i] += x_vector[i] * y_value
            for j in range(3):
                xtx[i][j] += x_vector[i] * x_vector[j]

    return solve_linear_system(xtx, xty)

with open("input.csv", newline="", encoding="utf-8") as input_file:
    reader = csv.DictReader(input_file)
    rows = [
        {
            "group": int(float(row["group"])),
            "y": float(row["y"]),
            "x": float(row["x"]),
            "z": float(row["z"]),
        }
        for row in reader
    ]

group_0 = [row for row in rows if row["group"] == 0]
group_1 = [row for row in rows if row["group"] == 1]

beta_0 = fit_group(group_0)
beta_1 = fit_group(group_1)

mean_y_0 = sum(row["y"] for row in group_0) / len(group_0)
mean_y_1 = sum(row["y"] for row in group_1) / len(group_1)
mean_x_0 = sum(row["x"] for row in group_0) / len(group_0)
mean_x_1 = sum(row["x"] for row in group_1) / len(group_1)
mean_z_0 = sum(row["z"] for row in group_0) / len(group_0)
mean_z_1 = sum(row["z"] for row in group_1) / len(group_1)

gap = mean_y_1 - mean_y_0
explained = (
    (mean_x_1 - mean_x_0) * beta_0[1]
    + (mean_z_1 - mean_z_0) * beta_0[2]
)
unexplained = (
    (beta_1[0] - beta_0[0])
    + mean_x_1 * (beta_1[1] - beta_0[1])
    + mean_z_1 * (beta_1[2] - beta_0[2])
)
explained_x = (mean_x_1 - mean_x_0) * beta_0[1]

n_obs = len(rows)

result = {
    "task_id": "broad_oaxaca",
    "platform": "python",
    "estimates": [
        {
            "term": "gap",
            "estimate": gap,
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "explained",
            "estimate": explained,
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "unexplained",
            "estimate": unexplained,
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "explained_x",
            "estimate": explained_x,
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {},
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output_file:
    json.dump(result, output_file, indent=2)
