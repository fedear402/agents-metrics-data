import csv
import json
import math


def solve_linear_system(matrix, vector):
    n = len(vector)
    a = [row[:] + [vector[i]] for i, row in enumerate(matrix)]

    for col in range(n):
        pivot = max(range(col, n), key=lambda row: abs(a[row][col]))
        if abs(a[pivot][col]) < 1e-12:
            raise ValueError("Singular regression design matrix")

        a[col], a[pivot] = a[pivot], a[col]

        pivot_value = a[col][col]
        for j in range(col, n + 1):
            a[col][j] /= pivot_value

        for row in range(n):
            if row == col:
                continue
            factor = a[row][col]
            for j in range(col, n + 1):
                a[row][j] -= factor * a[col][j]

    return [a[i][n] for i in range(n)]


with open("input.csv", newline="", encoding="utf-8") as file:
    rows = list(csv.DictReader(file))

n_obs = len(rows)

data = [
    {
        "group": int(row["group"]),
        "y": float(row["y"]),
        "x": float(row["x"]),
        "z": float(row["z"]),
    }
    for row in rows
]


def group_mean(group, variable):
    values = [row[variable] for row in data if row["group"] == group]
    return sum(values) / len(values)


def fit_group(group):
    group_rows = [row for row in data if row["group"] == group]
    design = [[1.0, row["x"], row["z"]] for row in group_rows]
    outcomes = [row["y"] for row in group_rows]

    xtx = [
        [sum(row[i] * row[j] for row in design) for j in range(3)]
        for i in range(3)
    ]
    xty = [sum(design[k][i] * outcomes[k] for k in range(len(design))) for i in range(3)]

    return solve_linear_system(xtx, xty)


beta_0 = fit_group(0)
beta_1 = fit_group(1)

mean_y_0 = group_mean(0, "y")
mean_y_1 = group_mean(1, "y")
mean_x_0 = group_mean(0, "x")
mean_x_1 = group_mean(1, "x")
mean_z_0 = group_mean(0, "z")
mean_z_1 = group_mean(1, "z")

gap = mean_y_1 - mean_y_0

explained = (
    (mean_x_1 - mean_x_0) * beta_0[1]
    + (mean_z_1 - mean_z_0) * beta_0[2]
)

unexplained = (
    beta_1[0] - beta_0[0]
    + mean_x_1 * (beta_1[1] - beta_0[1])
    + mean_z_1 * (beta_1[2] - beta_0[2])
)

explained_x = (mean_x_1 - mean_x_0) * beta_0[1]

result = {
    "task_id": "broad_oaxaca",
    "platform": "python",
    "estimates": [
        {
            "term": "gap",
            "estimate": gap,
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "explained",
            "estimate": explained,
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "unexplained",
            "estimate": unexplained,
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "explained_x",
            "estimate": explained_x,
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {},
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file, indent=2)
