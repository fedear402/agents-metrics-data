import csv
import json
import numpy as np

with open("./input.csv", newline="") as stream:
    rows = list(csv.DictReader(stream))

y = np.array([float(row["y"]) for row in rows])
x = np.array([float(row["x"]) for row in rows])
z = np.array([float(row["z"]) for row in rows])
group = np.array([int(row["group"]) for row in rows])

mask0 = group == 0
mask1 = group == 1

X0 = np.column_stack((np.ones(mask0.sum()), x[mask0], z[mask0]))
X1 = np.column_stack((np.ones(mask1.sum()), x[mask1], z[mask1]))

beta0 = np.linalg.lstsq(X0, y[mask0], rcond=None)[0]
beta1 = np.linalg.lstsq(X1, y[mask1], rcond=None)[0]

Xbar0 = np.array([1.0, x[mask0].mean(), z[mask0].mean()])
Xbar1 = np.array([1.0, x[mask1].mean(), z[mask1].mean()])

gap = y[mask1].mean() - y[mask0].mean()
explained = (Xbar1 - Xbar0) @ beta0
unexplained = Xbar1 @ (beta1 - beta0)
explained_x = (x[mask1].mean() - x[mask0].mean()) * beta0[1]

n_obs = len(rows)

result = {
    "task_id": "broad_oaxaca",
    "platform": "python",
    "estimates": [
        {
            "term": "gap",
            "estimate": float(gap),
            "se": None,
            "n_obs": n_obs
        },
        {
            "term": "explained",
            "estimate": float(explained),
            "se": None,
            "n_obs": n_obs
        },
        {
            "term": "unexplained",
            "estimate": float(unexplained),
            "se": None,
            "n_obs": n_obs
        },
        {
            "term": "explained_x",
            "estimate": float(explained_x),
            "se": None,
            "n_obs": n_obs
        }
    ],
    "method_metadata": {},
    "diagnostics": {}
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
