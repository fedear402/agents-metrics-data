import csv
import json

def solve_linear_system(matrix, vector):
    n = len(vector)
    a = [matrix[i][:] + [vector[i]] for i in range(n)]

    for col in range(n):
        pivot = max(range(col, n), key=lambda row: abs(a[row][col]))
        a[col], a[pivot] = a[pivot], a[col]

        pivot_value = a[col][col]
        for j in range(col, n + 1):
            a[col][j] /= pivot_value

        for row in range(n):
            if row != col:
                factor = a[row][col]
                for j in range(col, n + 1):
                    a[row][j] -= factor * a[col][j]

    return [a[i][n] for i in range(n)]

with open("input.csv", newline="") as csv_file:
    rows = list(csv.DictReader(csv_file))

n_obs = len(rows)

data = [
    {
        "group": int(float(row["group"])),
        "y": float(row["y"]),
        "x": float(row["x"]),
        "z": float(row["z"]),
    }
    for row in rows
]

def mean(values):
    return sum(values) / len(values)

def fit_group(group):
    group_rows = [row for row in data if row["group"] == group]

    xtx = [[0.0] * 3 for _ in range(3)]
    xty = [0.0] * 3

    for row in group_rows:
        features = [1.0, row["x"], row["z"]]
        for i in range(3):
            xty[i] += features[i] * row["y"]
            for j in range(3):
                xtx[i][j] += features[i] * features[j]

    return solve_linear_system(xtx, xty)

group_0 = [row for row in data if row["group"] == 0]
group_1 = [row for row in data if row["group"] == 1]

beta_0 = fit_group(0)
beta_1 = fit_group(1)

mean_y_0 = mean([row["y"] for row in group_0])
mean_y_1 = mean([row["y"] for row in group_1])
mean_x_0 = mean([row["x"] for row in group_0])
mean_x_1 = mean([row["x"] for row in group_1])
mean_z_0 = mean([row["z"] for row in group_0])
mean_z_1 = mean([row["z"] for row in group_1])

gap = mean_y_1 - mean_y_0

explained = (
    (mean_x_1 - mean_x_0) * beta_0[1]
    + (mean_z_1 - mean_z_0) * beta_0[2]
)

unexplained = (
    (beta_1[0] - beta_0[0])
    + mean_x_1 * (beta_1[1] - beta_0[1])
    + mean_z_1 * (beta_1[2] - beta_0[2])
)

explained_x = (mean_x_1 - mean_x_0) * beta_0[1]

result = {
    "task_id": "broad_oaxaca",
    "platform": "python",
    "estimates": [
        {
            "term": "gap",
            "estimate": gap,
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "explained",
            "estimate": explained,
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "unexplained",
            "estimate": unexplained,
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "explained_x",
            "estimate": explained_x,
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {},
    "diagnostics": {},
}

with open("result.json", "w") as output_file:
    json.dump(result, output_file, indent=2)
