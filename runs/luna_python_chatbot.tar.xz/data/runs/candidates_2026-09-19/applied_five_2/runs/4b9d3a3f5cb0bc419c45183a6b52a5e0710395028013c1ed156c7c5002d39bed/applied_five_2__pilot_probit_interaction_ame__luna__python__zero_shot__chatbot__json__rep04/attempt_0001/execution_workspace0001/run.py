import csv
import json
import numpy as np
from scipy.optimize import minimize
from scipy.special import log_ndtr, ndtr


def main():
    rows = []
    with open("input.csv", newline="") as file:
        reader = csv.DictReader(file)
        for row in reader:
            rows.append(row)

    y = np.array([float(row["y"]) for row in rows], dtype=float)
    x = np.array([float(row["x"]) for row in rows], dtype=float)
    d = np.array([float(row["d"]) for row in rows], dtype=float)
    z = np.array([float(row["z"]) for row in rows], dtype=float)
    target = np.array([float(row["target"]) for row in rows], dtype=float)

    xd = x * d
    x_squared = x * x
    design = np.column_stack((np.ones(len(rows)), x, d, xd, z, x_squared))

    def objective(beta):
        eta = design @ beta
        return -np.sum(y * log_ndtr(eta) + (1.0 - y) * log_ndtr(-eta))

    def gradient(beta):
        eta = design @ beta
        log_pdf = -0.5 * eta * eta - 0.5 * np.log(2.0 * np.pi)
        p = ndtr(eta)
        log_p = log_ndtr(eta)
        log_one_minus_p = log_ndtr(-eta)

        ratio_y = np.exp(log_pdf - log_p)
        ratio_one_minus_y = np.exp(log_pdf - log_one_minus_p)
        score = y * ratio_y - (1.0 - y) * ratio_one_minus_y

        return -(design.T @ score)

    initial = np.zeros(design.shape[1], dtype=float)
    fit = minimize(
        objective,
        initial,
        jac=gradient,
        method="BFGS",
        options={"maxiter": 10000, "gtol": 1e-10},
    )

    if not fit.success:
        fit = minimize(
            objective,
            fit.x,
            jac=gradient,
            method="L-BFGS-B",
            options={"maxiter": 10000, "ftol": 1e-15, "gtol": 1e-10},
        )

    beta = fit.x
    target_mask = target == 1
    n_target = int(np.sum(target_mask))
    n_obs = int(len(rows))

    x_target = x[target_mask]
    d_target = d[target_mask]
    z_target = z[target_mask]

    eta_target = (
        beta[0]
        + beta[1] * x_target
        + beta[2] * d_target
        + beta[3] * x_target * d_target
        + beta[4] * z_target
        + beta[5] * x_target * x_target
    )

    normal_pdf = np.exp(-0.5 * eta_target * eta_target) / np.sqrt(2.0 * np.pi)
    individual_x_effects = normal_pdf * (
        beta[1] + beta[3] * d_target + 2.0 * beta[5] * x_target
    )
    ame_x = float(np.mean(individual_x_effects))

    eta_d0 = (
        beta[0]
        + beta[1] * x_target
        + beta[4] * z_target
        + beta[5] * x_target * x_target
    )
    eta_d1 = eta_d0 + beta[2] + beta[3] * x_target
    individual_d_effects = ndtr(eta_d1) - ndtr(eta_d0)
    effect_d = float(np.mean(individual_d_effects))

    result = {
        "task_id": "pilot_probit_interaction_ame",
        "platform": "python",
        "estimates": [
            {
                "term": "ame_x",
                "estimate": ame_x,
                "se": None,
                "n_obs": n_obs,
            },
            {
                "term": "effect_d",
                "estimate": effect_d,
                "se": None,
                "n_obs": n_obs,
            },
        ],
        "method_metadata": {
            "model": "Bernoulli probit maximum likelihood",
            "formula": "y ~ 1 + x + d + x*d + z + x^2",
            "weighting": "none",
            "estimation_sample": "full sample",
            "effect_subset": "target == 1",
            "effect_evaluation": "observed target-row covariates",
        },
        "diagnostics": {
            "optimizer_success": bool(fit.success),
            "optimizer_message": str(fit.message),
            "log_likelihood": float(-objective(beta)),
            "n_target": n_target,
        },
    }

    with open("result.json", "w") as file:
        json.dump(result, file, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
