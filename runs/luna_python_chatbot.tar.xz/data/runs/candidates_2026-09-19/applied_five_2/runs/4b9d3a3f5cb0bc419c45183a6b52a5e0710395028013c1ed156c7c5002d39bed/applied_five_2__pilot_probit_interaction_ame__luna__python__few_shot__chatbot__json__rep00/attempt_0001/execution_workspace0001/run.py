import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy.stats import norm

data = pd.read_csv("input.csv")

y = data["y"].to_numpy(dtype=float)
x = data["x"].to_numpy(dtype=float)
d = data["d"].to_numpy(dtype=float)
z = data["z"].to_numpy(dtype=float)
target = data["target"].to_numpy() == 1

X = np.column_stack([
    np.ones(len(data)),
    x,
    d,
    x * d,
    z,
    x ** 2,
])

model = sm.Probit(y, X)
fit = model.fit(disp=False)
beta = fit.params

eta = X @ beta
x_derivative = norm.pdf(eta) * (
    beta[1] + beta[3] * d + 2.0 * beta[5] * x
)
ame_x = float(np.mean(x_derivative[target]))

X0 = np.column_stack([
    np.ones(len(data)),
    x,
    np.zeros(len(data)),
    np.zeros(len(data)),
    z,
    x ** 2,
])

X1 = np.column_stack([
    np.ones(len(data)),
    x,
    np.ones(len(data)),
    x,
    z,
    x ** 2,
])

discrete_effect = norm.cdf(X1 @ beta) - norm.cdf(X0 @ beta)
effect_d = float(np.mean(discrete_effect[target]))

n_obs = int(len(data))

result = {
    "task_id": "pilot_probit_interaction_ame",
    "platform": "python",
    "estimates": [
        {
            "term": "ame_x",
            "estimate": ame_x,
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "effect_d",
            "estimate": effect_d,
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "model": "Bernoulli probit maximum likelihood",
        "regressors": ["intercept", "x", "d", "x*d", "z", "x_squared"],
        "effect_population": "rows with target == 1",
        "weighting": "none",
        "fit_sample": "all rows",
        "ame_x_definition": "Average individual continuous-x derivative",
        "effect_d_definition": "Average individual discrete change from d=0 to d=1",
    },
    "diagnostics": {
        "converged": bool(fit.mle_retvals.get("converged", True)),
        "target_count": int(np.sum(target)),
        "sample_count": n_obs,
    },
}

with open("result.json", "w", encoding="utf-8") as output_file:
    json.dump(result, output_file, indent=2, allow_nan=False)
