import csv
import json
import numpy as np
from scipy.optimize import minimize
from scipy.special import log_ndtr


def main():
    with open("input.csv", newline="") as f:
        rows = list(csv.DictReader(f))

    y = np.array([float(r["y"]) for r in rows], dtype=float)
    x = np.array([float(r["x"]) for r in rows], dtype=float)
    d = np.array([float(r["d"]) for r in rows], dtype=float)
    z = np.array([float(r["z"]) for r in rows], dtype=float)
    target = np.array([float(r["target"]) for r in rows], dtype=float)

    X = np.column_stack([
        np.ones(len(rows)),
        x,
        d,
        x * d,
        z,
        x ** 2,
    ])

    def objective(beta):
        eta = X @ beta
        log_likelihood = np.sum(
            y * log_ndtr(eta) + (1.0 - y) * log_ndtr(-eta)
        )
        return -log_likelihood

    def gradient(beta):
        eta = X @ beta
        cdf = np.exp(log_ndtr(eta))
        pdf = np.exp(-0.5 * eta ** 2) / np.sqrt(2.0 * np.pi)
        score_multiplier = pdf * (y - cdf) / (cdf * (1.0 - cdf))
        return -(X.T @ score_multiplier)

    beta0 = np.zeros(X.shape[1], dtype=float)
    fit = minimize(
        objective,
        beta0,
        jac=gradient,
        method="BFGS",
        options={"maxiter": 2000, "gtol": 1e-10},
    )

    if not fit.success:
        fit = minimize(
            objective,
            fit.x,
            jac=gradient,
            method="L-BFGS-B",
            options={"maxiter": 5000, "ftol": 1e-15, "gtol": 1e-10},
        )

    beta = fit.x
    target_mask = target == 1
    x_t = x[target_mask]
    d_t = d[target_mask]
    z_t = z[target_mask]

    eta_t = (
        beta[0]
        + beta[1] * x_t
        + beta[2] * d_t
        + beta[3] * x_t * d_t
        + beta[4] * z_t
        + beta[5] * x_t ** 2
    )
    phi_t = np.exp(-0.5 * eta_t ** 2) / np.sqrt(2.0 * np.pi)

    derivative_x = phi_t * (
        beta[1] + beta[3] * d_t + 2.0 * beta[5] * x_t
    )
    ame_x = float(np.mean(derivative_x))

    eta_d0 = (
        beta[0]
        + beta[1] * x_t
        + beta[4] * z_t
        + beta[5] * x_t ** 2
    )
    eta_d1 = (
        beta[0]
        + beta[1] * x_t
        + beta[2]
        + beta[3] * x_t
        + beta[4] * z_t
        + beta[5] * x_t ** 2
    )
    effect_d = float(np.mean(
        np.exp(log_ndtr(eta_d1)) - np.exp(log_ndtr(eta_d0))
    ))

    result = {
        "task_id": "pilot_probit_interaction_ame",
        "platform": "python",
        "estimates": [
            {
                "term": "ame_x",
                "estimate": ame_x,
                "se": None,
                "n_obs": int(len(rows)),
            },
            {
                "term": "effect_d",
                "estimate": effect_d,
                "se": None,
                "n_obs": int(len(rows)),
            },
        ],
        "method_metadata": {
            "model": "Bernoulli probit maximum likelihood",
            "formula": "y ~ 1 + x + d + x*d + z + x^2",
            "weights": None,
            "estimation_sample": "all rows",
            "effect_subset": "target == 1",
            "ame_x_definition": "Average individual derivative with respect to x",
            "effect_d_definition": "Average prediction difference for d=1 versus d=0",
        },
        "diagnostics": {
            "converged": bool(fit.success),
            "optimizer": fit.method,
            "log_likelihood": float(-objective(beta)),
            "n_target": int(np.sum(target_mask)),
            "optimizer_message": str(fit.message),
        },
    }

    with open("result.json", "w") as f:
        json.dump(result, f, indent=2)


if __name__ == "__main__":
    main()
