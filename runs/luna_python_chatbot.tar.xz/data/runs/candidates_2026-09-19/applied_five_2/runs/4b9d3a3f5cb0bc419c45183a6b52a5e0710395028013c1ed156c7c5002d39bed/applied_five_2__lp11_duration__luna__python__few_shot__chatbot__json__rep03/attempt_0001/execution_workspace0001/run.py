import csv
import itertools
import json
import math
from collections import defaultdict
from scipy.optimize import minimize_scalar


def logsumexp(values):
    if not values:
        return float("-inf")
    maximum = max(values)
    return maximum + math.log(sum(math.exp(v - maximum) for v in values))


def log_combination(n, k):
    if k < 0 or k > n:
        return float("-inf")
    return math.lgamma(n + 1) - math.lgamma(k + 1) - math.lgamma(n - k + 1)


def denominator_log(risk_training, d, beta):
    trained = sum(risk_training)
    untrained = len(risk_training) - trained
    terms = []
    for k in range(d + 1):
        if k <= trained and d - k <= untrained:
            terms.append(
                log_combination(trained, k)
                + log_combination(untrained, d - k)
                + beta * k
            )
    return logsumexp(terms)


def read_input(path):
    rows = []
    with open(path, newline="") as handle:
        for row in csv.DictReader(handle):
            rows.append(
                {
                    "cohort": row["cohort"],
                    "worker": row["worker"],
                    "training": int(float(row["training"])),
                    "end_month": int(float(row["end_month"])),
                    "event": int(float(row["event"])),
                }
            )
    return rows


rows = read_input("input.csv")
n_obs = len(rows)

cohorts = defaultdict(list)
for row in rows:
    cohorts[row["cohort"]].append(row)


def contribution(cohort_rows, month, beta, return_observed=False):
    risk = [row for row in cohort_rows if row["end_month"] >= month]
    exits = [row for row in risk if row["event"] == 1 and row["end_month"] == month]
    d = len(exits)
    if d == 0:
        return 0.0

    observed_sum = sum(row["training"] for row in exits)
    log_denominator = denominator_log(
        [row["training"] for row in risk],
        d,
        beta,
    )
    value = beta * observed_sum - log_denominator

    if return_observed:
        return value, observed_sum, d, risk, exits
    return value


event_months = []
for cohort_rows in cohorts.values():
    event_months.extend(
        row["end_month"]
        for row in cohort_rows
        if row["event"] == 1
    )


def log_likelihood(beta):
    total = 0.0
    for cohort_rows in cohorts.values():
        months = {
            row["end_month"]
            for row in cohort_rows
            if row["event"] == 1
        }
        for month in months:
            total += contribution(cohort_rows, month, beta)
    return float(total)


fit = minimize_scalar(
    lambda beta: -log_likelihood(float(beta)),
    bounds=(-4.0, 4.0),
    method="bounded",
    options={"xatol": 1e-14},
)

beta = float(fit.x)
ll = float(log_likelihood(beta))
conditional_odds_ratio = float(math.exp(beta))

cohort_zero_key = None
for key in cohorts:
    try:
        if float(key) == 0.0:
            cohort_zero_key = key
            break
    except ValueError:
        continue

if cohort_zero_key is None:
    raise ValueError("Cohort 0 is missing from input.csv")

first_value, first_sum, first_d, first_risk, first_exits = contribution(
    cohorts[cohort_zero_key],
    1,
    beta,
    return_observed=True,
)

first_event_set_log_probability = float(first_value)
first_event_set_probability = float(math.exp(first_event_set_log_probability))

estimates = [
    {
        "term": "training_coefficient",
        "estimate": beta,
        "se": None,
        "n_obs": n_obs,
    },
    {
        "term": "conditional_odds_ratio",
        "estimate": conditional_odds_ratio,
        "se": None,
        "n_obs": n_obs,
    },
    {
        "term": "log_likelihood",
        "estimate": ll,
        "se": None,
        "n_obs": n_obs,
    },
    {
        "term": "first_event_set_probability",
        "estimate": first_event_set_probability,
        "se": None,
        "n_obs": n_obs,
    },
    {
        "term": "first_event_set_log_probability",
        "estimate": first_event_set_log_probability,
        "se": None,
        "n_obs": n_obs,
    },
]

result = {
    "task_id": "lp11_duration",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "model": "Cox discrete-time conditional odds model",
        "risk_set_unit": "cohort-month",
        "denominator": "exact enumeration by elementary symmetric polynomial counts",
        "optimization_interval": [-4, 4],
        "probability_definition": "named observed exit set conditional on its exit count",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "n_cohorts": len(cohorts),
        "n_event_months": len(event_months),
        "first_event_set_exit_count": int(first_d),
        "first_event_set_training_sum": int(first_sum),
        "optimizer_success": bool(fit.success),
    },
}

with open("result.json", "w") as handle:
    json.dump(result, handle, indent=2)
