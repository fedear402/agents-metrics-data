import csv
import json
import numpy as np
import statsmodels.api as sm
from scipy.stats import norm

with open("input.csv", newline="", encoding="utf-8") as f:
    rows = list(csv.DictReader(f))

y = np.array([float(r["y"]) for r in rows])
x = np.array([float(r["x"]) for r in rows])
d = np.array([float(r["d"]) for r in rows])
z = np.array([float(r["z"]) for r in rows])
target = np.array([float(r["target"]) for r in rows]) == 1

n_obs = len(y)

X = np.column_stack([
    np.ones(n_obs),
    x,
    d,
    x * d,
    z,
    x ** 2,
])

model = sm.Probit(y, X)
fit = model.fit(disp=False)
beta = fit.params

eta = X @ beta
dx_eta = beta[1] + beta[3] * d + 2.0 * beta[5] * x
marginal_x = norm.pdf(eta) * dx_eta
ame_x = float(np.mean(marginal_x[target]))

X0 = np.column_stack([
    np.ones(n_obs),
    x,
    np.zeros(n_obs),
    np.zeros(n_obs),
    z,
    x ** 2,
])

X1 = np.column_stack([
    np.ones(n_obs),
    x,
    np.ones(n_obs),
    x,
    z,
    x ** 2,
])

discrete_d = norm.cdf(X1 @ beta) - norm.cdf(X0 @ beta)
effect_d = float(np.mean(discrete_d[target]))

result = {
    "task_id": "pilot_probit_interaction_ame",
    "platform": "python",
    "estimates": [
        {
            "term": "ame_x",
            "estimate": ame_x,
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "effect_d",
            "estimate": effect_d,
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "model": "Bernoulli probit maximum likelihood",
        "formula": "y ~ 1 + x + d + x*d + z + x^2",
        "estimation_sample": "full sample",
        "effect_subset": "target == 1",
        "weights": None,
    },
    "diagnostics": {
        "converged": bool(fit.mle_retvals.get("converged", True)),
        "iterations": int(fit.mle_retvals.get("iterations", 0)),
        "target_count": int(np.sum(target)),
    },
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, allow_nan=False)
