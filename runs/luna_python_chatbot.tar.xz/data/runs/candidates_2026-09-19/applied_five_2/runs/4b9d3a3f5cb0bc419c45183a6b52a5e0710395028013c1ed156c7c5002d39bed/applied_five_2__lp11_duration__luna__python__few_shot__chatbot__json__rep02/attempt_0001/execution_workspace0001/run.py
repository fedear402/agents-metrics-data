import csv
import json
import math
from pathlib import Path

import numpy as np
from scipy.optimize import minimize_scalar


def as_int(value):
    return int(float(value))


def log_elementary_symmetric(training_values, degree, beta):
    if degree == 0:
        return 0.0

    dp = np.full(degree + 1, -np.inf, dtype=float)
    dp[0] = 0.0

    for value in training_values:
        weight = beta * float(value)
        upper = min(degree, len(training_values))
        for k in range(upper, 0, -1):
            dp[k] = np.logaddexp(dp[k], dp[k - 1] + weight)

    return float(dp[degree])


rows = []
with Path("input.csv").open(newline="") as handle:
    for row in csv.DictReader(handle):
        rows.append(
            {
                "cohort": row["cohort"],
                "worker": row["worker"],
                "training": as_int(row["training"]),
                "end_month": as_int(row["end_month"]),
                "event": as_int(row["event"]),
            }
        )

n_obs = len(rows)
cohorts = sorted({row["cohort"] for row in rows})
risk_sets = []

for cohort in cohorts:
    cohort_rows = [row for row in rows if row["cohort"] == cohort]
    max_month = max(row["end_month"] for row in cohort_rows)

    for month in range(1, max_month + 1):
        risk = [row for row in cohort_rows if row["end_month"] >= month]
        exits = [
            row
            for row in risk
            if row["event"] == 1 and row["end_month"] == month
        ]

        if exits:
            risk_sets.append(
                {
                    "cohort": cohort,
                    "month": month,
                    "risk": risk,
                    "exits": exits,
                    "exit_training_sum": sum(row["training"] for row in exits),
                    "exit_count": len(exits),
                }
            )


def log_likelihood(beta):
    value = 0.0
    for risk_set in risk_sets:
        training_values = [row["training"] for row in risk_set["risk"]]
        d = risk_set["exit_count"]
        observed_sum = risk_set["exit_training_sum"]
        value += beta * observed_sum
        value -= log_elementary_symmetric(training_values, d, beta)
    return float(value)


fit = minimize_scalar(
    lambda beta: -log_likelihood(beta),
    bounds=(-4.0, 4.0),
    method="bounded",
    options={"xatol": 1e-14},
)

beta = float(fit.x)
log_likelihood_at_fit = log_likelihood(beta)
conditional_odds_ratio = float(math.exp(beta))

first_set = None
for risk_set in risk_sets:
    if as_int(risk_set["cohort"]) == 0 and risk_set["month"] == 1:
        first_set = risk_set
        break

if first_set is None:
    raise ValueError("The required cohort 0, month 1 risk set is missing.")

first_training_sum = sum(row["training"] for row in first_set["exits"])
first_log_probability = (
    beta * first_training_sum
    - log_elementary_symmetric(
        [row["training"] for row in first_set["risk"]],
        first_set["exit_count"],
        beta,
    )
)
first_probability = float(math.exp(first_log_probability))

estimates = [
    {
        "term": "training_coefficient",
        "estimate": beta,
        "se": None,
        "n_obs": n_obs,
    },
    {
        "term": "conditional_odds_ratio",
        "estimate": conditional_odds_ratio,
        "se": None,
        "n_obs": n_obs,
    },
    {
        "term": "log_likelihood",
        "estimate": log_likelihood_at_fit,
        "se": None,
        "n_obs": n_obs,
    },
    {
        "term": "first_event_set_probability",
        "estimate": first_probability,
        "se": None,
        "n_obs": n_obs,
    },
    {
        "term": "first_event_set_log_probability",
        "estimate": float(first_log_probability),
        "se": None,
        "n_obs": n_obs,
    },
]

result = {
    "task_id": "lp11_duration",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "model": "Cox discrete-time conditional odds model",
        "optimization_interval": [-4, 4],
        "risk_set_construction": "cohort-month risk sets with joint same-month exits",
        "denominator": "exact elementary symmetric polynomial recursion",
        "likelihood_constants": "excluded",
        "conditional_odds_ratio_definition": "exp(training_coefficient)",
    },
    "diagnostics": {
        "optimizer_success": bool(fit.success),
        "optimizer_message": str(fit.message),
        "risk_sets_with_exits": len(risk_sets),
        "n_obs": n_obs,
    },
}

with Path("result.json").open("w") as handle:
    json.dump(result, handle, indent=2, allow_nan=False)
