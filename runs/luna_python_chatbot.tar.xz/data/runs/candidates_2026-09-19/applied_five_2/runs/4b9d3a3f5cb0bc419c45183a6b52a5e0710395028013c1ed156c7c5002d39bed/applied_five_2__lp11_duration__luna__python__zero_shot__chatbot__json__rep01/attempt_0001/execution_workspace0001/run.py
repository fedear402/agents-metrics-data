import csv
import json
import math


def log_combination(n, k):
    if k < 0 or k > n:
        return float("-inf")
    return math.lgamma(n + 1) - math.lgamma(k + 1) - math.lgamma(n - k + 1)


def risk_set_terms(rows):
    groups = {}
    for row in rows:
        cohort = row["cohort"]
        month = row["end_month"]
        groups.setdefault(cohort, {}).setdefault(month, []).append(row)

    terms = []
    for cohort, months in groups.items():
        max_month = max(months)
        for month in range(1, max_month + 1):
            risk = [
                row
                for row in rows
                if row["cohort"] == cohort and row["end_month"] >= month
            ]
            exits = [
                row
                for row in risk
                if row["event"] == 1 and row["end_month"] == month
            ]
            d = len(exits)
            if d == 0:
                continue

            n1 = sum(row["training"] for row in risk)
            n0 = len(risk) - n1
            s = sum(row["training"] for row in exits)
            terms.append((cohort, month, n0, n1, d, s))

    return terms


def log_denominator(beta, n0, n1, d):
    values = []
    lower = max(0, d - n0)
    upper = min(d, n1)

    for k in range(lower, upper + 1):
        value = (
            log_combination(n1, k)
            + log_combination(n0, d - k)
            + beta * k
        )
        values.append(value)

    maximum = max(values)
    return maximum + math.log(sum(math.exp(value - maximum) for value in values))


def expected_treated(beta, n0, n1, d):
    values = []
    lower = max(0, d - n0)
    upper = min(d, n1)

    for k in range(lower, upper + 1):
        values.append(
            (
                k,
                log_combination(n1, k)
                + log_combination(n0, d - k)
                + beta * k,
            )
        )

    maximum = max(value for _, value in values)
    weights = [(k, math.exp(value - maximum)) for k, value in values]
    total = sum(weight for _, weight in weights)
    return sum(k * weight for k, weight in weights) / total


def log_likelihood(beta, terms):
    return sum(
        beta * s - log_denominator(beta, n0, n1, d)
        for _, _, n0, n1, d, s in terms
    )


def score(beta, terms):
    return sum(
        s - expected_treated(beta, n0, n1, d)
        for _, _, n0, n1, d, s in terms
    )


def fit_beta(terms):
    lower = -4.0
    upper = 4.0
    score_lower = score(lower, terms)
    score_upper = score(upper, terms)

    if score_lower <= 0:
        return lower
    if score_upper >= 0:
        return upper

    for _ in range(200):
        middle = (lower + upper) / 2.0
        middle_score = score(middle, terms)
        if middle_score > 0:
            lower = middle
        else:
            upper = middle

    return (lower + upper) / 2.0


def find_first_event_set(rows):
    risk = [
        row
        for row in rows
        if row["cohort"] in {"0", "0.0"} and row["end_month"] >= 1
    ]
    exits = [
        row
        for row in risk
        if row["event"] == 1 and row["end_month"] == 1
    ]

    n1 = sum(row["training"] for row in risk)
    n0 = len(risk) - n1
    d = len(exits)
    observed_training_sum = sum(row["training"] for row in exits)

    return n0, n1, d, observed_training_sum


def main():
    rows = []
    with open("input.csv", newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        for raw in reader:
            rows.append(
                {
                    "cohort": raw["cohort"],
                    "worker": raw["worker"],
                    "training": int(raw["training"]),
                    "end_month": int(raw["end_month"]),
                    "event": int(raw["event"]),
                }
            )

    terms = risk_set_terms(rows)
    beta = fit_beta(terms)
    odds_ratio = math.exp(beta)
    ll = log_likelihood(beta, terms)

    n0, n1, d, first_sum = find_first_event_set(rows)
    first_log_probability = (
        first_sum * beta - log_denominator(beta, n0, n1, d)
    )
    first_probability = math.exp(first_log_probability)

    n_obs = len(rows)
    result = {
        "task_id": "lp11_duration",
        "estimates": [
            {
                "term": "training_coefficient",
                "estimate": beta,
                "se": None,
                "n_obs": n_obs,
            },
            {
                "term": "conditional_odds_ratio",
                "estimate": odds_ratio,
                "se": None,
                "n_obs": n_obs,
            },
            {
                "term": "log_likelihood",
                "estimate": ll,
                "se": None,
                "n_obs": n_obs,
            },
            {
                "term": "first_event_set_probability",
                "estimate": first_probability,
                "se": None,
                "n_obs": n_obs,
            },
            {
                "term": "first_event_set_log_probability",
                "estimate": first_log_probability,
                "se": None,
                "n_obs": n_obs,
            },
        ],
        "method_metadata": {
            "model": "Cox discrete-time conditional odds model",
            "covariate": "training",
            "risk_set_definition": "cohort-month with end_month at least month",
            "denominator": "exact elementary symmetric polynomial enumeration",
            "optimization_interval": [-4, 4],
            "probability_definition": "named observed exit set conditional on its exit count",
        },
        "diagnostics": {
            "n_obs": n_obs,
            "n_contributing_cohort_months": len(terms),
            "first_event_set_risk_set_size": n0 + n1,
            "first_event_set_exit_count": d,
        },
    }

    with open("result.json", "w", encoding="utf-8") as handle:
        json.dump(result, handle, indent=2, ensure_ascii=False)


if __name__ == "__main__":
    main()
