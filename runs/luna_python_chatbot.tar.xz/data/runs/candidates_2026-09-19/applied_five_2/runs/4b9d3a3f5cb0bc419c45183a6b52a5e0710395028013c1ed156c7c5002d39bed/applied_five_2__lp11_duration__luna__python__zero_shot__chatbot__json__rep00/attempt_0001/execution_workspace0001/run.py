import csv
import json
import math


def logaddexp(a, b):
    if a == -math.inf:
        return b
    if b == -math.inf:
        return a
    if a > b:
        return a + math.log1p(math.exp(b - a))
    return b + math.log1p(math.exp(a - b))


def conditional_log_partition_and_mean(training_values, d):
    log_e = [-math.inf] * (d + 1)
    deriv = [0.0] * (d + 1)
    log_e[0] = 0.0

    for tr in training_values:
        for k in range(d, 0, -1):
            if log_e[k - 1] == -math.inf:
                continue

            old_log = log_e[k]
            add_log = log_e[k - 1]
            new_log = logaddexp(old_log, add_log)

            old_weight = 0.0 if old_log == -math.inf else math.exp(old_log - new_log)
            add_weight = math.exp(add_log - new_log)

            old_deriv = 0.0 if old_log == -math.inf else deriv[k]
            add_deriv = deriv[k - 1] + float(tr)

            log_e[k] = new_log
            deriv[k] = old_weight * old_deriv + add_weight * add_deriv

    return log_e[d], deriv[d]


def build_contributions(rows):
    cohorts = {}
    for row in rows:
        cohort = row["cohort"]
        cohorts.setdefault(cohort, []).append(row)

    contributions = []
    first_event_set = None

    for cohort, cohort_rows in cohorts.items():
        event_months = sorted(
            {r["end_month"] for r in cohort_rows if r["event"] == 1}
        )

        for month in event_months:
            risk = [r for r in cohort_rows if r["end_month"] >= month]
            exits = [r for r in risk if r["event"] == 1 and r["end_month"] == month]
            d = len(exits)

            if d == 0:
                continue

            training_values = [r["training"] for r in risk]
            observed_training_sum = sum(r["training"] for r in exits)

            contributions.append(
                (training_values, d, observed_training_sum)
            )

            if cohort in {"0", 0, 0.0} and month == 1:
                first_event_set = (
                    [r["training"] for r in exits],
                    d,
                    observed_training_sum,
                )

    return contributions, first_event_set


def log_likelihood_and_score(beta, contributions):
    ll = 0.0
    score = 0.0

    for training_values, d, observed_training_sum in contributions:
        log_z, expected_training_sum = (
            conditional_log_partition_and_mean(training_values, d)
        )
        ll += beta * observed_training_sum - log_z
        score += observed_training_sum - expected_training_sum

    return ll, score


def fit_beta(contributions):
    lower = -4.0
    upper = 4.0

    _, lower_score = log_likelihood_and_score(lower, contributions)
    _, upper_score = log_likelihood_and_score(upper, contributions)

    if lower_score <= 0.0:
        return lower
    if upper_score >= 0.0:
        return upper

    for _ in range(200):
        midpoint = (lower + upper) / 2.0
        _, midpoint_score = log_likelihood_and_score(midpoint, contributions)

        if midpoint_score > 0.0:
            lower = midpoint
        else:
            upper = midpoint

        if upper - lower < 1e-14:
            break

    return (lower + upper) / 2.0


def main():
    rows = []

    with open("input.csv", newline="") as file:
        reader = csv.DictReader(file)

        for row in reader:
            rows.append(
                {
                    "cohort": row["cohort"],
                    "worker": row["worker"],
                    "training": int(row["training"]),
                    "end_month": int(row["end_month"]),
                    "event": int(row["event"]),
                }
            )

    n_obs = len(rows)
    contributions, first_event_set = build_contributions(rows)
    beta = fit_beta(contributions)
    log_likelihood, _ = log_likelihood_and_score(beta, contributions)
    odds_ratio = math.exp(beta)

    if first_event_set is None:
        first_event_set_probability = None
        first_event_set_log_probability = None
    else:
        observed_training, d, observed_training_sum = first_event_set
        log_z, _ = conditional_log_partition_and_mean(
            [r["training"] for r in rows if False],
            d,
        )

        first_risk = []
        for row in rows:
            if row["cohort"] in {"0", 0, 0.0} and row["end_month"] >= 1:
                first_risk.append(row)

        log_z, _ = conditional_log_partition_and_mean(
            [r["training"] for r in first_risk],
            d,
        )
        first_event_set_log_probability = (
            beta * observed_training_sum - log_z
        )
        first_event_set_probability = math.exp(
            first_event_set_log_probability
        )

    result = {
        "task_id": "lp11_duration",
        "platform": "python",
        "estimates": [
            {
                "term": "training_coefficient",
                "estimate": beta,
                "se": None,
                "n_obs": n_obs,
            },
            {
                "term": "conditional_odds_ratio",
                "estimate": odds_ratio,
                "se": None,
                "n_obs": n_obs,
            },
            {
                "term": "log_likelihood",
                "estimate": log_likelihood,
                "se": None,
                "n_obs": n_obs,
            },
            {
                "term": "first_event_set_probability",
                "estimate": first_event_set_probability,
                "se": None,
                "n_obs": n_obs,
            },
            {
                "term": "first_event_set_log_probability",
                "estimate": first_event_set_log_probability,
                "se": None,
                "n_obs": n_obs,
            },
        ],
        "method_metadata": {
            "model": "Cox discrete-time conditional odds model",
            "optimization_interval": [-4, 4],
            "partition_function": "elementary symmetric polynomial recursion",
            "same_month_exits_evaluated_jointly": True,
            "conditional_probability_targets_named_exit_set": True,
        },
        "diagnostics": {
            "n_obs": n_obs,
            "n_contributions": len(contributions),
        },
    }

    with open("result.json", "w") as file:
        json.dump(result, file, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
