import csv
import json
import math
from collections import defaultdict

import numpy as np
from scipy.optimize import minimize_scalar
from scipy.special import gammaln, logsumexp


def log_combination(n, k):
    if k < 0 or k > n:
        return -math.inf
    return float(
        gammaln(n + 1.0)
        - gammaln(k + 1.0)
        - gammaln(n - k + 1.0)
    )


def log_denominator(beta, training_values, d):
    n_one = int(sum(training_values))
    n_zero = len(training_values) - n_one

    terms = []
    lower = max(0, d - n_zero)
    upper = min(d, n_one)

    for k in range(lower, upper + 1):
        terms.append(
            log_combination(n_one, k)
            + log_combination(n_zero, d - k)
            + beta * k
        )

    return float(logsumexp(terms))


def main():
    rows = []

    with open("input.csv", newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            rows.append(
                {
                    "cohort": str(row["cohort"]),
                    "worker": row["worker"],
                    "training": int(row["training"]),
                    "end_month": int(row["end_month"]),
                    "event": int(row["event"]),
                }
            )

    n_obs = len(rows)

    cohorts = defaultdict(list)
    for row in rows:
        cohorts[row["cohort"]].append(row)

    contributions = []

    for cohort, cohort_rows in cohorts.items():
        months = sorted(
            {
                row["end_month"]
                for row in cohort_rows
                if row["event"] == 1
            }
        )

        for month in months:
            risk_set = [
                row
                for row in cohort_rows
                if row["end_month"] >= month
            ]
            exits = [
                row
                for row in risk_set
                if row["event"] == 1
                and row["end_month"] == month
            ]

            d = len(exits)
            if d == 0:
                continue

            observed_sum = sum(row["training"] for row in exits)
            training_values = [row["training"] for row in risk_set]

            contributions.append(
                {
                    "cohort": cohort,
                    "month": month,
                    "d": d,
                    "observed_sum": observed_sum,
                    "training_values": training_values,
                }
            )

    def log_likelihood(beta):
        total = 0.0
        for contribution in contributions:
            total += (
                beta * contribution["observed_sum"]
                - log_denominator(
                    beta,
                    contribution["training_values"],
                    contribution["d"],
                )
            )
        return float(total)

    fit = minimize_scalar(
        lambda beta: -log_likelihood(float(beta)),
        bounds=(-4.0, 4.0),
        method="bounded",
        options={"xatol": 1e-14, "maxiter": 1000},
    )

    candidates = [float(fit.x), -4.0, 4.0]
    beta = max(candidates, key=log_likelihood)
    fitted_log_likelihood = log_likelihood(beta)

    first_cohort_candidates = [
        row
        for row in rows
        if row["cohort"] in {"0", "0.0"}
    ]

    first_risk_set = [
        row
        for row in first_cohort_candidates
        if row["end_month"] >= 1
    ]
    first_event_set = [
        row
        for row in first_risk_set
        if row["event"] == 1 and row["end_month"] == 1
    ]

    if first_event_set:
        first_d = len(first_event_set)
        first_sum = sum(row["training"] for row in first_event_set)
        first_training_values = [
            row["training"] for row in first_risk_set
        ]
        first_event_set_log_probability = (
            beta * first_sum
            - log_denominator(
                beta,
                first_training_values,
                first_d,
            )
        )
        first_event_set_probability = math.exp(
            first_event_set_log_probability
        )
    else:
        first_event_set_probability = None
        first_event_set_log_probability = None

    estimates = [
        {
            "term": "training_coefficient",
            "estimate": float(beta),
            "se": None,
            "n_obs": int(n_obs),
        },
        {
            "term": "conditional_odds_ratio",
            "estimate": float(math.exp(beta)),
            "se": None,
            "n_obs": int(n_obs),
        },
        {
            "term": "log_likelihood",
            "estimate": float(fitted_log_likelihood),
            "se": None,
            "n_obs": int(n_obs),
        },
        {
            "term": "first_event_set_probability",
            "estimate": first_event_set_probability,
            "se": None,
            "n_obs": int(n_obs),
        },
        {
            "term": "first_event_set_log_probability",
            "estimate": first_event_set_log_probability,
            "se": None,
            "n_obs": int(n_obs),
        },
    ]

    result = {
        "task_id": "lp11_duration",
        "platform": "python",
        "estimates": estimates,
        "method_metadata": {
            "model": "Cox discrete-time conditional odds model",
            "estimation": "Exact conditional likelihood",
            "risk_set_unit": "cohort-month",
            "subset_denominator": "Elementary symmetric polynomial",
            "optimization_bounds": [-4.0, 4.0],
            "odds_ratio_interpretation": (
                "Conditional discrete-time odds ratio"
            ),
        },
        "diagnostics": {
            "n_obs": int(n_obs),
            "n_cohort_month_contributions": int(len(contributions)),
            "optimizer_success": bool(fit.success),
            "optimizer_message": str(fit.message),
        },
    }

    with open("result.json", "w", encoding="utf-8") as handle:
        json.dump(result, handle, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
