import csv
import json
import math


def logaddexp(a, b):
    if a == -math.inf:
        return b
    if b == -math.inf:
        return a
    if a < b:
        a, b = b, a
    return a + math.log1p(math.exp(b - a))


def log_elementary_symmetric(training_values, beta, degree):
    log_coeff = [-math.inf] * (degree + 1)
    mean_coeff = [0.0] * (degree + 1)
    log_coeff[0] = 0.0

    for x in training_values:
        weight_log = beta * x
        upper = min(degree, len(training_values))
        for k in range(upper, 0, -1):
            old_log = log_coeff[k]
            old_mean = mean_coeff[k]
            previous_log = log_coeff[k - 1]
            previous_mean = mean_coeff[k - 1] + x

            candidate_log = previous_log + weight_log
            combined_log = logaddexp(old_log, candidate_log)

            if combined_log == -math.inf:
                combined_mean = 0.0
            else:
                old_weight = 0.0 if old_log == -math.inf else math.exp(old_log - combined_log)
                candidate_weight = math.exp(candidate_log - combined_log)
                combined_mean = old_weight * old_mean + candidate_weight * previous_mean

            log_coeff[k] = combined_log
            mean_coeff[k] = combined_mean

    return log_coeff[degree], mean_coeff[degree]


def risk_set_contribution(training_values, exits, beta):
    d = len(exits)
    observed_sum = sum(exits)
    log_denominator, expected_sum = log_elementary_symmetric(
        training_values, beta, d
    )
    return beta * observed_sum - log_denominator, observed_sum - expected_sum


def main():
    rows = []
    with open("input.csv", newline="") as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            rows.append(
                {
                    "cohort": row["cohort"],
                    "worker": row["worker"],
                    "training": int(float(row["training"])),
                    "end_month": int(float(row["end_month"])),
                    "event": int(float(row["event"])),
                }
            )

    n_obs = len(rows)
    cohorts = {}
    for row in rows:
        cohorts.setdefault(row["cohort"], []).append(row)

    risk_sets = []
    first_event_data = None

    for cohort, cohort_rows in cohorts.items():
        event_months = sorted(
            {
                row["end_month"]
                for row in cohort_rows
                if row["event"] == 1
            }
        )

        for month in event_months:
            risk_rows = [
                row for row in cohort_rows
                if row["end_month"] >= month
            ]
            exit_rows = [
                row for row in risk_rows
                if row["event"] == 1 and row["end_month"] == month
            ]

            if not exit_rows:
                continue

            training_values = [row["training"] for row in risk_rows]
            exits = [row["training"] for row in exit_rows]
            risk_sets.append((training_values, exits))

            if str(cohort) == "0" and month == 1:
                first_event_data = (training_values, exits)

    def objective(beta):
        return sum(
            risk_set_contribution(training_values, exits, beta)[0]
            for training_values, exits in risk_sets
        )

    def score(beta):
        return sum(
            risk_set_contribution(training_values, exits, beta)[1]
            for training_values, exits in risk_sets
        )

    lower = -4.0
    upper = 4.0
    lower_score = score(lower)
    upper_score = score(upper)

    if lower_score <= 0:
        beta_hat = lower
    elif upper_score >= 0:
        beta_hat = upper
    else:
        for _ in range(160):
            midpoint = (lower + upper) / 2.0
            midpoint_score = score(midpoint)
            if midpoint_score > 0:
                lower = midpoint
            else:
                upper = midpoint
        beta_hat = (lower + upper) / 2.0

    log_likelihood = objective(beta_hat)
    conditional_odds_ratio = math.exp(beta_hat)

    if first_event_data is None:
        first_probability = None
        first_log_probability = None
    else:
        training_values, exits = first_event_data
        d = len(exits)
        observed_sum = sum(exits)
        log_denominator, _ = log_elementary_symmetric(
            training_values, beta_hat, d
        )
        first_log_probability = beta_hat * observed_sum - log_denominator
        first_probability = math.exp(first_log_probability)

    result = {
        "task_id": "lp11_duration",
        "platform": "python",
        "estimates": [
            {
                "term": "training_coefficient",
                "estimate": beta_hat,
                "se": None,
                "n_obs": n_obs,
            },
            {
                "term": "conditional_odds_ratio",
                "estimate": conditional_odds_ratio,
                "se": None,
                "n_obs": n_obs,
            },
            {
                "term": "log_likelihood",
                "estimate": log_likelihood,
                "se": None,
                "n_obs": n_obs,
            },
            {
                "term": "first_event_set_probability",
                "estimate": first_probability,
                "se": None,
                "n_obs": n_obs,
            },
            {
                "term": "first_event_set_log_probability",
                "estimate": first_log_probability,
                "se": None,
                "n_obs": n_obs,
            },
        ],
        "method_metadata": {
            "model": "Cox discrete-time conditional odds model",
            "optimization_interval": [-4, 4],
            "denominator": "Exact elementary symmetric polynomial",
            "same_month_exits_evaluated_jointly": True,
            "right_censoring_removed_after_same_month_exits": True,
        },
        "diagnostics": {
            "risk_sets_with_exits": len(risk_sets),
            "n_obs": n_obs,
            "optimization_score": score(beta_hat),
        },
    }

    with open("result.json", "w") as handle:
        json.dump(result, handle, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
