import json
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.special import log_ndtr, ndtr


def main():
    data = pd.read_csv("input.csv")

    y = data["y"].to_numpy(dtype=float)
    x = data["x"].to_numpy(dtype=float)
    d = data["d"].to_numpy(dtype=float)
    z = data["z"].to_numpy(dtype=float)
    target = data["target"].to_numpy()

    xd = x * d
    x2 = x * x

    X = np.column_stack([
        np.ones(len(data)),
        x,
        d,
        xd,
        z,
        x2,
    ])

    def objective(beta):
        eta = X @ beta
        log_likelihood = np.sum(
            y * log_ndtr(eta) + (1.0 - y) * log_ndtr(-eta)
        )
        return -log_likelihood

    def gradient(beta):
        eta = X @ beta
        log_pdf = -0.5 * eta * eta - 0.5 * np.log(2.0 * np.pi)
        p = np.exp(log_ndtr(log_pdf) - log_ndtr(eta))
        score = X.T @ (y - p)
        return -score

    beta0 = np.zeros(X.shape[1], dtype=float)
    fit = minimize(
        objective,
        beta0,
        jac=gradient,
        method="BFGS",
        options={"gtol": 1e-10, "maxiter": 10000},
    )

    beta = fit.x

    subset = target == 1
    X_sub = X[subset]
    x_sub = x[subset]
    d_sub = d[subset]
    z_sub = z[subset]

    eta_sub = X_sub @ beta
    phi_sub = np.exp(-0.5 * eta_sub * eta_sub) / np.sqrt(2.0 * np.pi)

    derivative_x = phi_sub * (
        beta[1] + beta[3] * d_sub + 2.0 * beta[5] * x_sub
    )
    ame_x = float(np.mean(derivative_x))

    eta_d0 = (
        beta[0]
        + beta[1] * x_sub
        + beta[3] * 0.0
        + beta[4] * z_sub
        + beta[5] * x_sub * x_sub
    )
    eta_d1 = (
        beta[0]
        + beta[1] * x_sub
        + beta[2]
        + beta[3] * x_sub
        + beta[4] * z_sub
        + beta[5] * x_sub * x_sub
    )
    effect_d = float(np.mean(ndtr(eta_d1) - ndtr(eta_d0)))

    result = {
        "task_id": "pilot_probit_interaction_ame",
        "platform": "python",
        "estimates": [
            {
                "term": "ame_x",
                "estimate": ame_x,
                "se": None,
                "n_obs": int(len(data)),
            },
            {
                "term": "effect_d",
                "estimate": effect_d,
                "se": None,
                "n_obs": int(len(data)),
            },
        ],
        "method_metadata": {
            "model": "Bernoulli probit maximum likelihood",
            "regressors": ["intercept", "x", "d", "x*d", "z", "x^2"],
            "weighted": False,
            "estimation_sample": "all rows",
            "effect_sample": "target == 1",
            "x_effect_definition": "average individual derivative at observed x, d, and z",
            "d_effect_definition": "average individual discrete change from d=0 to d=1",
        },
        "diagnostics": {
            "converged": bool(fit.success),
            "optimizer_status": int(fit.status),
            "optimizer_message": str(fit.message),
            "log_likelihood": float(-fit.fun),
            "n_estimation_obs": int(len(data)),
            "n_effect_obs": int(np.sum(subset)),
        },
    }

    with open("result.json", "w", encoding="utf-8") as output_file:
        json.dump(result, output_file, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
