import csv
import json
import math


def logaddexp(a, b):
    if a == -math.inf:
        return b
    if b == -math.inf:
        return a
    if a < b:
        a, b = b, a
    return a + math.log1p(math.exp(b - a))


def log_elementary_symmetric(training_values, degree, beta):
    dp = [-math.inf] * (degree + 1)
    dp[0] = 0.0

    for x in training_values:
        contribution = beta * x
        upper = min(degree, len(training_values))
        for k in range(upper, 0, -1):
            dp[k] = logaddexp(dp[k], dp[k - 1] + contribution)

    return dp[degree]


def build_contributions(rows):
    contributions = []
    first_event_training_sum = None
    first_event_training_values = None

    cohorts = sorted({row["cohort"] for row in rows})
    for cohort in cohorts:
        cohort_rows = [row for row in rows if row["cohort"] == cohort]
        months = sorted({row["end_month"] for row in cohort_rows})

        for month in months:
            risk_set = [
                row for row in cohort_rows
                if row["end_month"] >= month
            ]
            exits = [
                row for row in risk_set
                if row["event"] == 1 and row["end_month"] == month
            ]

            if not exits:
                continue

            training_values = [row["training"] for row in risk_set]
            observed_training_sum = sum(row["training"] for row in exits)
            degree = len(exits)

            contributions.append(
                (training_values, degree, observed_training_sum)
            )

            if cohort == 0 and month == 1:
                first_event_training_sum = observed_training_sum
                first_event_training_values = training_values

    return contributions, first_event_training_sum, first_event_training_values


def log_likelihood(beta, contributions):
    value = 0.0
    for training_values, degree, observed_training_sum in contributions:
        value += (
            beta * observed_training_sum
            - log_elementary_symmetric(training_values, degree, beta)
        )
    return value


def maximize_on_interval(objective, lower=-4.0, upper=4.0):
    for _ in range(220):
        left = lower + (upper - lower) / 3.0
        right = upper - (upper - lower) / 3.0

        if objective(left) < objective(right):
            lower = left
        else:
            upper = right

    beta = (lower + upper) / 2.0
    candidates = [lower, beta, upper]
    return max(candidates, key=objective)


def main():
    rows = []

    with open("input.csv", newline="") as handle:
        reader = csv.DictReader(handle)
        for record in reader:
            rows.append(
                {
                    "cohort": int(record["cohort"]),
                    "worker": record["worker"],
                    "training": int(record["training"]),
                    "end_month": int(record["end_month"]),
                    "event": int(record["event"]),
                }
            )

    n_obs = len(rows)
    contributions, first_sum, first_values = build_contributions(rows)

    if not contributions:
        beta = 0.0
        fitted_log_likelihood = 0.0
        first_log_probability = 0.0
    else:
        beta = maximize_on_interval(
            lambda value: log_likelihood(value, contributions)
        )
        fitted_log_likelihood = log_likelihood(beta, contributions)

        if first_values is None:
            first_log_probability = None
        else:
            degree = sum(
                1 for row in rows
                if row["cohort"] == 0
                and row["end_month"] == 1
                and row["event"] == 1
            )
            first_log_probability = (
                beta * first_sum
                - log_elementary_symmetric(first_values, degree, beta)
            )

    first_probability = (
        None
        if first_log_probability is None
        else math.exp(first_log_probability)
    )

    estimates = [
        {
            "term": "training_coefficient",
            "estimate": beta,
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "conditional_odds_ratio",
            "estimate": math.exp(beta),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "log_likelihood",
            "estimate": fitted_log_likelihood,
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "first_event_set_probability",
            "estimate": first_probability,
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "first_event_set_log_probability",
            "estimate": first_log_probability,
            "se": None,
            "n_obs": n_obs,
        },
    ]

    result = {
        "task_id": "lp11_duration",
        "platform": "python",
        "estimates": estimates,
        "method_metadata": {
            "model": "Cox discrete-time conditional odds model",
            "likelihood": "Exact conditional likelihood using elementary symmetric polynomials",
            "optimization_interval": [-4, 4],
            "same_month_exits_evaluated_jointly": True,
            "right_censoring_removed_after_same_month_exits": True,
        },
        "diagnostics": {
            "sample_count": n_obs,
            "risk_set_contributions": len(contributions),
            "first_event_set_defined": first_values is not None,
        },
    }

    with open("result.json", "w") as handle:
        json.dump(result, handle, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
