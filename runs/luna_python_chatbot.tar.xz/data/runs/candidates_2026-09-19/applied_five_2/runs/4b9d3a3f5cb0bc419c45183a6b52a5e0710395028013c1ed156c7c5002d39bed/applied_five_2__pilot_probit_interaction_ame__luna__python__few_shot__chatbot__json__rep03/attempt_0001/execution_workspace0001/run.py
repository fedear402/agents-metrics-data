import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy.special import ndtr
from scipy.stats import norm

data = pd.read_csv("input.csv")

y = data["y"].to_numpy(dtype=float)
x = data["x"].to_numpy(dtype=float)
d = data["d"].to_numpy(dtype=float)
z = data["z"].to_numpy(dtype=float)
target = data["target"].to_numpy() == 1

X = np.column_stack([
    np.ones(len(data)),
    x,
    d,
    x * d,
    z,
    x ** 2,
])

model = sm.Probit(y, X).fit(disp=False)
beta = model.params

eta = X @ beta
subset = target

x_derivative = (
    beta[1]
    + beta[3] * d
    + 2.0 * beta[5] * x
)
individual_ame_x = norm.pdf(eta) * x_derivative
ame_x = float(individual_ame_x[subset].mean())

X0 = np.column_stack([
    np.ones(len(data)),
    x,
    np.zeros(len(data)),
    np.zeros(len(data)),
    z,
    x ** 2,
])

X1 = np.column_stack([
    np.ones(len(data)),
    x,
    np.ones(len(data)),
    x,
    z,
    x ** 2,
])

effect_d_individual = ndtr(X1 @ beta) - ndtr(X0 @ beta)
effect_d = float(effect_d_individual[subset].mean())

result = {
    "task_id": "pilot_probit_interaction_ame",
    "platform": "python",
    "estimates": [
        {
            "term": "ame_x",
            "estimate": ame_x,
            "se": None,
            "n_obs": int(len(data)),
        },
        {
            "term": "effect_d",
            "estimate": effect_d,
            "se": None,
            "n_obs": int(len(data)),
        },
    ],
    "method_metadata": {
        "model": "Bernoulli probit maximum likelihood",
        "regressors": ["intercept", "x", "d", "x*d", "z", "x_squared"],
        "weights": None,
        "effect_subset": "target == 1",
        "ame_x_definition": "Average individual derivative with respect to x",
        "effect_d_definition": "Average discrete change from d=0 to d=1",
    },
    "diagnostics": {
        "converged": bool(model.mle_retvals.get("converged", True)),
        "n_obs": int(len(data)),
        "n_target": int(subset.sum()),
    },
}

with open("result.json", "w", encoding="utf-8") as output_file:
    json.dump(result, output_file, indent=2, allow_nan=False)
