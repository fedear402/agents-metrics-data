import json
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.special import log_ndtr
from scipy.stats import norm

TASK_ID = "pilot_probit_interaction_ame"

data = pd.read_csv("input.csv")

y = data["y"].to_numpy(dtype=float)
x = data["x"].to_numpy(dtype=float)
d = data["d"].to_numpy(dtype=float)
z = data["z"].to_numpy(dtype=float)
target = data["target"].to_numpy()

X = np.column_stack([
    np.ones(len(data)),
    x,
    d,
    x * d,
    z,
    x ** 2,
])

sign_y = 2.0 * y - 1.0


def objective(beta):
    eta = X @ beta
    log_likelihood = np.sum(log_ndtr(sign_y * eta))
    return -log_likelihood


def gradient(beta):
    eta = X @ beta
    signed_eta = sign_y * eta
    log_pdf = -0.5 * signed_eta ** 2 - 0.5 * np.log(2.0 * np.pi)
    log_cdf = log_ndtr(signed_eta)
    inverse_mills = np.exp(log_pdf - log_cdf)
    return -(X.T @ (sign_y * inverse_mills))


beta_start = np.linalg.lstsq(X, y, rcond=None)[0]

fit = minimize(
    objective,
    beta_start,
    jac=gradient,
    method="BFGS",
    options={"maxiter": 2000, "gtol": 1e-10},
)

if not fit.success:
    fit = minimize(
        objective,
        fit.x,
        jac=gradient,
        method="L-BFGS-B",
        options={"maxiter": 5000, "ftol": 1e-15, "gtol": 1e-10},
    )

beta = fit.x
subset = target == 1

eta_subset = X[subset] @ beta
phi_subset = norm.pdf(eta_subset)

x_subset = x[subset]
d_subset = d[subset]
z_subset = z[subset]

x_derivative_index = (
    beta[1]
    + beta[3] * d_subset
    + 2.0 * beta[5] * x_subset
)
individual_x_effects = phi_subset * x_derivative_index
ame_x = float(np.mean(individual_x_effects))

eta_d0 = (
    beta[0]
    + beta[1] * x_subset
    + beta[4] * z_subset
    + beta[5] * x_subset ** 2
)
eta_d1 = eta_d0 + beta[2] + beta[3] * x_subset
individual_d_effects = norm.cdf(eta_d1) - norm.cdf(eta_d0)
effect_d = float(np.mean(individual_d_effects))

result = {
    "task_id": TASK_ID,
    "platform": "python",
    "estimates": [
        {
            "term": "ame_x",
            "estimate": ame_x,
            "se": None,
            "n_obs": int(len(data)),
        },
        {
            "term": "effect_d",
            "estimate": effect_d,
            "se": None,
            "n_obs": int(len(data)),
        },
    ],
    "method_metadata": {
        "model": "Bernoulli probit maximum likelihood",
        "formula": "y ~ intercept + x + d + x*d + z + x^2",
        "estimation_sample": "all rows",
        "weighting": "none",
        "effect_subset": "target == 1",
        "ame_x_definition": "Average individual derivative with respect to x, including x*d and x^2 terms",
        "effect_d_definition": "Average discrete change from d=0 to d=1, updating x*d consistently",
        "covariate_evaluation": "Observed x, d, and z values for each target row",
    },
    "diagnostics": {
        "optimizer_success": bool(fit.success),
        "optimizer_message": str(fit.message),
        "log_likelihood": float(-objective(beta)),
        "n_target": int(np.sum(subset)),
    },
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file, indent=2)
