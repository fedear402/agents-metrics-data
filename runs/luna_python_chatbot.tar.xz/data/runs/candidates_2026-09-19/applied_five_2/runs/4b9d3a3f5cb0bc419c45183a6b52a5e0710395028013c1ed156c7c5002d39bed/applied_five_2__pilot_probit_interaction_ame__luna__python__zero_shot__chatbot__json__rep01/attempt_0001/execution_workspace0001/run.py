import json
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.special import log_ndtr, ndtr


def main():
    data = pd.read_csv("input.csv")

    y = data["y"].to_numpy(dtype=float)
    x = data["x"].to_numpy(dtype=float)
    d = data["d"].to_numpy(dtype=float)
    z = data["z"].to_numpy(dtype=float)
    target = data["target"].to_numpy()

    X = np.column_stack([
        np.ones(len(data)),
        x,
        d,
        x * d,
        z,
        x ** 2,
    ])

    def negative_log_likelihood(beta):
        eta = X @ beta
        log_prob_1 = log_ndtr(eta)
        log_prob_0 = log_ndtr(-eta)
        return -np.sum(y * log_prob_1 + (1.0 - y) * log_prob_0)

    def gradient(beta):
        eta = X @ beta
        pdf = np.exp(-0.5 * eta ** 2) / np.sqrt(2.0 * np.pi)
        p = ndtr(eta)
        score_weight = pdf * (y - p) / (p * (1.0 - p) + 1e-15)
        return -(X.T @ score_weight)

    result = minimize(
        negative_log_likelihood,
        np.zeros(X.shape[1]),
        jac=gradient,
        method="BFGS",
        options={"maxiter": 10000, "gtol": 1e-10},
    )

    beta = result.x
    target_mask = target == 1

    x_target = x[target_mask]
    d_target = d[target_mask]
    z_target = z[target_mask]

    eta_target = (
        beta[0]
        + beta[1] * x_target
        + beta[2] * d_target
        + beta[3] * x_target * d_target
        + beta[4] * z_target
        + beta[5] * x_target ** 2
    )

    ame_x_values = (
        np.exp(-0.5 * eta_target ** 2) / np.sqrt(2.0 * np.pi)
        * (beta[1] + beta[3] * d_target + 2.0 * beta[5] * x_target)
    )
    ame_x = float(np.mean(ame_x_values))

    eta_d0 = (
        beta[0]
        + beta[1] * x_target
        + beta[4] * z_target
        + beta[5] * x_target ** 2
    )
    eta_d1 = (
        beta[0]
        + beta[1] * x_target
        + beta[2]
        + beta[3] * x_target
        + beta[4] * z_target
        + beta[5] * x_target ** 2
    )
    effect_d = float(np.mean(ndtr(eta_d1) - ndtr(eta_d0)))

    n_obs = int(len(data))

    output = {
        "task_id": "pilot_probit_interaction_ame",
        "platform": "python",
        "estimates": [
            {
                "term": "ame_x",
                "estimate": ame_x,
                "se": None,
                "n_obs": n_obs,
            },
            {
                "term": "effect_d",
                "estimate": effect_d,
                "se": None,
                "n_obs": n_obs,
            },
        ],
        "method_metadata": {
            "model": "Bernoulli probit maximum likelihood",
            "regressors": ["intercept", "x", "d", "x*d", "z", "x_squared"],
            "estimation_sample": "all rows",
            "effect_population": "target == 1",
            "weights": "none",
            "ame_x_definition": "Average individual marginal derivative with respect to x",
            "effect_d_definition": "Average individual discrete change from d=0 to d=1",
        },
        "diagnostics": {
            "converged": bool(result.success),
            "optimizer_status": int(result.status),
            "optimizer_message": str(result.message),
            "log_likelihood": float(-result.fun),
            "n_target": int(np.sum(target_mask)),
        },
    }

    with open("result.json", "w", encoding="utf-8") as file:
        json.dump(output, file, indent=2)


if __name__ == "__main__":
    main()
