import csv
import json
import math
from collections import defaultdict
from scipy.optimize import minimize_scalar


def read_input(path):
    with open(path, newline="") as f:
        rows = []
        for row in csv.DictReader(f):
            rows.append(
                {
                    "cohort": row["cohort"],
                    "worker": row["worker"],
                    "training": int(row["training"]),
                    "end_month": int(row["end_month"]),
                    "event": int(row["event"]),
                }
            )
    return rows


def log_combination(n, k):
    if k < 0 or k > n:
        return float("-inf")
    return math.lgamma(n + 1) - math.lgamma(k + 1) - math.lgamma(n - k + 1)


def log_denominator(training_values, d, beta):
    n1 = sum(training_values)
    n0 = len(training_values) - n1

    terms = []
    for k1 in range(max(0, d - n0), min(d, n1) + 1):
        k0 = d - k1
        terms.append(
            log_combination(n1, k1)
            + log_combination(n0, k0)
            + beta * k1
        )

    maximum = max(terms)
    return maximum + math.log(sum(math.exp(t - maximum) for t in terms))


def event_contribution(risk_set, exits, beta):
    d = len(exits)
    if d == 0:
        return 0.0
    observed_sum = sum(w["training"] for w in exits)
    training_values = [w["training"] for w in risk_set]
    return beta * observed_sum - log_denominator(training_values, d, beta)


def build_contributions(rows):
    by_cohort = defaultdict(list)
    for row in rows:
        by_cohort[row["cohort"]].append(row)

    contributions = []
    first_event = None

    for cohort, workers in by_cohort.items():
        months = sorted({w["end_month"] for w in workers})
        for month in months:
            risk_set = [w for w in workers if w["end_month"] >= month]
            exits = [
                w for w in risk_set
                if w["event"] == 1 and w["end_month"] == month
            ]

            if exits:
                contributions.append((risk_set, exits))

                if str(cohort) == "0" and month == 1:
                    first_event = (risk_set, exits)

    return contributions, first_event


def main():
    rows = read_input("input.csv")
    contributions, first_event = build_contributions(rows)

    def log_likelihood(beta):
        return sum(
            event_contribution(risk_set, exits, beta)
            for risk_set, exits in contributions
        )

    fit = minimize_scalar(
        lambda b: -log_likelihood(float(b)),
        bounds=(-4.0, 4.0),
        method="bounded",
        options={"xatol": 1e-14},
    )

    beta = float(fit.x)
    ll = float(log_likelihood(beta))

    risk_set, exits = first_event
    d = len(exits)
    observed_sum = sum(w["training"] for w in exits)
    denominator_log = log_denominator(
        [w["training"] for w in risk_set],
        d,
        beta,
    )
    first_log_probability = float(beta * observed_sum - denominator_log)
    first_probability = float(math.exp(first_log_probability))

    estimates = [
        {
            "term": "training_coefficient",
            "estimate": beta,
            "se": None,
            "n_obs": len(rows),
        },
        {
            "term": "conditional_odds_ratio",
            "estimate": float(math.exp(beta)),
            "se": None,
            "n_obs": len(rows),
        },
        {
            "term": "log_likelihood",
            "estimate": ll,
            "se": None,
            "n_obs": len(rows),
        },
        {
            "term": "first_event_set_probability",
            "estimate": first_probability,
            "se": None,
            "n_obs": len(rows),
        },
        {
            "term": "first_event_set_log_probability",
            "estimate": first_log_probability,
            "se": None,
            "n_obs": len(rows),
        },
    ]

    result = {
        "task_id": "lp11_duration",
        "platform": "python",
        "estimates": estimates,
        "method_metadata": {
            "model": "Cox discrete-time conditional odds model",
            "optimization_bounds": [-4, 4],
            "denominator": "Exact elementary symmetric polynomial by training count",
            "probability_definition": "Named observed exit set conditional on its exit count",
        },
        "diagnostics": {
            "optimizer_success": bool(fit.success),
            "optimizer_message": str(fit.message),
            "risk_set_contributions": len(contributions),
        },
    }

    with open("result.json", "w") as f:
        json.dump(result, f, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
