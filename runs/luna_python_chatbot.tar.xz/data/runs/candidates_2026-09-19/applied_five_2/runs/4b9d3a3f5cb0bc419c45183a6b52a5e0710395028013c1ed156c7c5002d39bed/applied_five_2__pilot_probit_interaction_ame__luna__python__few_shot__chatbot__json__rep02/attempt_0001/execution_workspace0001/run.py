import json
import csv
import numpy as np
from scipy.optimize import minimize
from scipy.special import log_ndtr
from scipy.stats import norm

with open("input.csv", newline="") as f:
    rows = list(csv.DictReader(f))

y = np.array([float(r["y"]) for r in rows], dtype=float)
x = np.array([float(r["x"]) for r in rows], dtype=float)
d = np.array([float(r["d"]) for r in rows], dtype=float)
z = np.array([float(r["z"]) for r in rows], dtype=float)
target = np.array([float(r["target"]) for r in rows], dtype=float)

X = np.column_stack([
    np.ones(len(rows)),
    x,
    d,
    x * d,
    z,
    x ** 2,
])

def objective(beta):
    eta = X @ beta
    loglik = y * log_ndtr(eta) + (1.0 - y) * log_ndtr(-eta)
    return -np.sum(loglik)

def gradient(beta):
    eta = X @ beta
    log_phi = norm.logpdf(eta)
    score_factor = (
        y * np.exp(log_phi - log_ndtr(eta))
        - (1.0 - y) * np.exp(log_phi - log_ndtr(-eta))
    )
    return -(X.T @ score_factor)

fit = minimize(
    objective,
    np.zeros(X.shape[1]),
    jac=gradient,
    method="BFGS",
    options={"gtol": 1e-10, "maxiter": 2000},
)

if not fit.success:
    fit = minimize(
        objective,
        fit.x,
        jac=gradient,
        method="L-BFGS-B",
        options={"ftol": 1e-15, "gtol": 1e-10, "maxiter": 5000},
    )

beta = fit.x
idx = target == 1
eta_target = X[idx] @ beta

marginal_x = norm.pdf(eta_target) * (
    beta[1] + beta[3] * d[idx] + 2.0 * beta[5] * x[idx]
)
ame_x = float(np.mean(marginal_x))

x_t = x[idx]
z_t = z[idx]

eta_d0 = (
    beta[0]
    + beta[1] * x_t
    + beta[2] * 0.0
    + beta[3] * x_t * 0.0
    + beta[4] * z_t
    + beta[5] * x_t ** 2
)
eta_d1 = (
    beta[0]
    + beta[1] * x_t
    + beta[2]
    + beta[3] * x_t
    + beta[4] * z_t
    + beta[5] * x_t ** 2
)
effect_d = float(np.mean(norm.cdf(eta_d1) - norm.cdf(eta_d0)))

result = {
    "task_id": "pilot_probit_interaction_ame",
    "platform": "python",
    "estimates": [
        {
            "term": "ame_x",
            "estimate": ame_x,
            "se": None,
            "n_obs": int(len(rows)),
        },
        {
            "term": "effect_d",
            "estimate": effect_d,
            "se": None,
            "n_obs": int(len(rows)),
        },
    ],
    "method_metadata": {
        "model": "Bernoulli probit maximum likelihood",
        "regressors": ["intercept", "x", "d", "x*d", "z", "x_squared"],
        "estimation_sample": "all rows",
        "effect_subset": "target == 1",
        "weights": None,
    },
    "diagnostics": {
        "optimizer_success": bool(fit.success),
        "optimizer_message": str(fit.message),
        "log_likelihood": float(-objective(beta)),
        "n_target": int(np.sum(idx)),
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2, allow_nan=False)
