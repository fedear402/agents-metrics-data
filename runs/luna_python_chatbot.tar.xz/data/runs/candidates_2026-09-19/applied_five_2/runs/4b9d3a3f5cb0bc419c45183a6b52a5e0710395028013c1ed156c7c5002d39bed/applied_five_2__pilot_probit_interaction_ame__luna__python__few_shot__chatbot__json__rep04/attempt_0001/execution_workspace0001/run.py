import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy.stats import norm

data = pd.read_csv("input.csv")

y = data["y"].to_numpy(dtype=float)
x = data["x"].to_numpy(dtype=float)
d = data["d"].to_numpy(dtype=float)
z = data["z"].to_numpy(dtype=float)
target = data["target"].to_numpy(dtype=int)

X = np.column_stack([
    np.ones(len(data)),
    x,
    d,
    x * d,
    z,
    x ** 2,
])

model = sm.Probit(y, X)
fit = model.fit(disp=False)
beta = np.asarray(fit.params, dtype=float)

target_mask = target == 1

linear_predictor = X @ beta
x_derivative = norm.pdf(linear_predictor) * (
    beta[1] + beta[3] * d + 2.0 * beta[5] * x
)
ame_x = float(np.mean(x_derivative[target_mask]))

X0 = np.column_stack([
    np.ones(len(data)),
    x,
    np.zeros(len(data)),
    np.zeros(len(data)),
    z,
    x ** 2,
])

X1 = np.column_stack([
    np.ones(len(data)),
    x,
    np.ones(len(data)),
    x,
    z,
    x ** 2,
])

effect_d_individual = norm.cdf(X1 @ beta) - norm.cdf(X0 @ beta)
effect_d = float(np.mean(effect_d_individual[target_mask]))

result = {
    "task_id": "pilot_probit_interaction_ame",
    "platform": "python",
    "estimates": [
        {
            "term": "ame_x",
            "estimate": ame_x,
            "se": None,
            "n_obs": int(len(data)),
        },
        {
            "term": "effect_d",
            "estimate": effect_d,
            "se": None,
            "n_obs": int(len(data)),
        },
    ],
    "method_metadata": {
        "model": "Bernoulli probit maximum likelihood",
        "regressors": ["intercept", "x", "d", "x*d", "z", "x_squared"],
        "estimation_sample": "full_sample",
        "effect_subset": "target == 1",
        "ame_x_formula": "phi(Xb) * (beta_x + beta_xd*d + 2*beta_x_squared*x)",
        "effect_d_definition": "Phi(X1b) - Phi(X0b), with observed x and z",
        "weighted": False,
    },
    "diagnostics": {
        "converged": bool(getattr(fit, "mle_retvals", {}).get("converged", True)),
        "n_target": int(np.sum(target_mask)),
        "n_obs": int(len(data)),
    },
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, allow_nan=False)
