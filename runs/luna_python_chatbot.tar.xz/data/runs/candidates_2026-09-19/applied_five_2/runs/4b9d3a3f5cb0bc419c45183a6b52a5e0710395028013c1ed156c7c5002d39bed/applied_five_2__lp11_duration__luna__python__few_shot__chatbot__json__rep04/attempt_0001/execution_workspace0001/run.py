import csv
import itertools
import json
import math
from collections import defaultdict

import numpy as np
from scipy.optimize import minimize_scalar
from scipy.special import logsumexp


def read_data(path):
    rows = []
    with open(path, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            rows.append(
                {
                    "cohort": row["cohort"],
                    "worker": row["worker"],
                    "training": int(row["training"]),
                    "end_month": int(row["end_month"]),
                    "event": int(row["event"]),
                }
            )
    return rows


def cohort_key(value):
    try:
        return int(value)
    except ValueError:
        return value


def risk_set_contribution(beta, risk_training, observed_training):
    d = len(observed_training)
    if d == 0:
        return 0.0

    observed_sum = float(sum(observed_training))
    subset_scores = []
    for subset in itertools.combinations(range(len(risk_training)), d):
        subset_scores.append(beta * sum(risk_training[i] for i in subset))

    return beta * observed_sum - float(logsumexp(subset_scores))


def build_contributions(rows):
    by_cohort = defaultdict(list)
    for row in rows:
        by_cohort[cohort_key(row["cohort"])].append(row)

    contributions = []
    first_risk_training = None
    first_observed_training = None

    for cohort, cohort_rows in by_cohort.items():
        max_month = max(row["end_month"] for row in cohort_rows)

        for month in range(1, max_month + 1):
            risk_rows = [
                row for row in cohort_rows if row["end_month"] >= month
            ]
            observed_rows = [
                row
                for row in risk_rows
                if row["event"] == 1 and row["end_month"] == month
            ]

            if observed_rows:
                risk_training = [row["training"] for row in risk_rows]
                observed_training = [row["training"] for row in observed_rows]
                contributions.append((risk_training, observed_training))

            if cohort == 0 and month == 1:
                first_risk_training = [row["training"] for row in risk_rows]
                first_observed_training = [
                    row["training"] for row in observed_rows
                ]

    if first_risk_training is None or first_observed_training is None:
        raise ValueError("Cohort 0, month 1 is missing from the input data.")

    return contributions, first_risk_training, first_observed_training


def main():
    rows = read_data("input.csv")
    contributions, first_risk_training, first_observed_training = (
        build_contributions(rows)
    )

    def log_likelihood(beta):
        return float(
            sum(
                risk_set_contribution(
                    beta, risk_training, observed_training
                )
                for risk_training, observed_training in contributions
            )
        )

    fit = minimize_scalar(
        lambda beta: -log_likelihood(beta),
        bounds=(-4.0, 4.0),
        method="bounded",
        options={"xatol": 1e-14},
    )

    beta = float(fit.x)
    ll = log_likelihood(beta)

    first_observed_sum = sum(first_observed_training)
    first_denominator = float(
        logsumexp(
            beta * sum(first_risk_training[i] for i in subset)
            for subset in itertools.combinations(
                range(len(first_risk_training)),
                len(first_observed_training),
            )
        )
    )
    first_log_probability = beta * first_observed_sum - first_denominator
    first_probability = math.exp(first_log_probability)

    estimates = [
        {
            "term": "training_coefficient",
            "estimate": beta,
            "se": None,
            "n_obs": len(rows),
        },
        {
            "term": "conditional_odds_ratio",
            "estimate": math.exp(beta),
            "se": None,
            "n_obs": len(rows),
        },
        {
            "term": "log_likelihood",
            "estimate": ll,
            "se": None,
            "n_obs": len(rows),
        },
        {
            "term": "first_event_set_probability",
            "estimate": first_probability,
            "se": None,
            "n_obs": len(rows),
        },
        {
            "term": "first_event_set_log_probability",
            "estimate": first_log_probability,
            "se": None,
            "n_obs": len(rows),
        },
    ]

    result = {
        "task_id": "lp11_duration",
        "platform": "python",
        "estimates": estimates,
        "method_metadata": {
            "model": "Cox discrete-time conditional odds model",
            "optimization_interval": [-4, 4],
            "risk_set_rule": "end_month >= month",
            "same_month_exit_rule": "event == 1 and end_month == month",
            "denominator": "exact enumeration of all distinct size-d subsets",
            "first_event_set": "cohort 0, month 1 named observed exit set",
        },
        "diagnostics": {
            "contributing_risk_sets": len(contributions),
            "sample_count": len(rows),
            "optimizer_success": bool(fit.success),
            "optimizer_message": str(fit.message),
        },
    }

    with open("result.json", "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
