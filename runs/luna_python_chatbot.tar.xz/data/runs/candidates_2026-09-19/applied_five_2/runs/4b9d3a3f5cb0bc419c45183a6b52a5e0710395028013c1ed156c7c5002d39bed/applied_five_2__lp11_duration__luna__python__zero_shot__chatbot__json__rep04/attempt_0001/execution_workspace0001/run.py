import csv
import json
import math


def logsumexp(values):
    maximum = max(values)
    return maximum + math.log(sum(math.exp(value - maximum) for value in values))


def log_combination(n, k):
    if k < 0 or k > n:
        return float("-inf")
    return (
        math.lgamma(n + 1)
        - math.lgamma(k + 1)
        - math.lgamma(n - k + 1)
    )


def risk_set_terms(rows, month):
    risk = [row for row in rows if row["end_month"] >= month]
    exits = [row for row in risk if row["event"] == 1]
    d = len(exits)

    if d == 0:
        return None

    n_training = sum(row["training"] for row in risk)
    n_untrained = len(risk) - n_training
    observed_training = sum(row["training"] for row in exits)

    return d, n_training, n_untrained, observed_training


def denominator_log_and_expected(beta, d, n_training, n_untrained):
    terms = []
    ks = []

    lower = max(0, d - n_untrained)
    upper = min(d, n_training)

    for k in range(lower, upper + 1):
        terms.append(
            log_combination(n_training, k)
            + log_combination(n_untrained, d - k)
            + beta * k
        )
        ks.append(k)

    log_denominator = logsumexp(terms)
    probabilities = [math.exp(term - log_denominator) for term in terms]
    expected_training = sum(k * probability for k, probability in zip(ks, probabilities))

    return log_denominator, expected_training


def score_and_log_likelihood(beta, contributions):
    score = 0.0
    log_likelihood = 0.0

    for d, n_training, n_untrained, observed_training in contributions:
        log_denominator, expected_training = denominator_log_and_expected(
            beta, d, n_training, n_untrained
        )
        score += observed_training - expected_training
        log_likelihood += beta * observed_training - log_denominator

    return score, log_likelihood


def main():
    rows = []

    with open("input.csv", newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        for raw in reader:
            end_month_text = raw["end_month"].strip()
            end_month = int(float(end_month_text))

            rows.append(
                {
                    "cohort": raw["cohort"].strip(),
                    "worker": raw["worker"].strip(),
                    "training": int(raw["training"]),
                    "end_month": end_month,
                    "event": int(raw["event"]),
                }
            )

    n_obs = len(rows)
    cohorts = {}
    for row in rows:
        cohorts.setdefault(row["cohort"], []).append(row)

    contributions = []

    for cohort_rows in cohorts.values():
        event_months = sorted(
            {
                row["end_month"]
                for row in cohort_rows
                if row["event"] == 1
            }
        )

        for month in event_months:
            terms = risk_set_terms(cohort_rows, month)
            if terms is not None:
                contributions.append(terms)

    lower_beta = -4.0
    upper_beta = 4.0
    lower_score, _ = score_and_log_likelihood(lower_beta, contributions)
    upper_score, _ = score_and_log_likelihood(upper_beta, contributions)

    if lower_score <= 0:
        beta = lower_beta
    elif upper_score >= 0:
        beta = upper_beta
    else:
        for _ in range(200):
            midpoint = (lower_beta + upper_beta) / 2.0
            midpoint_score, _ = score_and_log_likelihood(midpoint, contributions)

            if midpoint_score > 0:
                lower_beta = midpoint
            else:
                upper_beta = midpoint

        beta = (lower_beta + upper_beta) / 2.0

    _, log_likelihood = score_and_log_likelihood(beta, contributions)
    conditional_odds_ratio = math.exp(beta)

    first_rows = cohorts.get("0", [])
    first_month_risk = [
        row for row in first_rows
        if row["end_month"] >= 1
    ]
    first_month_exits = [
        row for row in first_month_risk
        if row["event"] == 1 and row["end_month"] == 1
    ]

    if first_month_exits:
        first_d = len(first_month_exits)
        first_n_training = sum(row["training"] for row in first_month_risk)
        first_n_untrained = len(first_month_risk) - first_n_training
        first_observed_training = sum(row["training"] for row in first_month_exits)

        first_log_denominator, _ = denominator_log_and_expected(
            beta,
            first_d,
            first_n_training,
            first_n_untrained,
        )

        first_event_set_log_probability = (
            beta * first_observed_training - first_log_denominator
        )
        first_event_set_probability = math.exp(first_event_set_log_probability)
    else:
        first_event_set_probability = None
        first_event_set_log_probability = None

    estimates = [
        {
            "term": "training_coefficient",
            "estimate": beta,
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "conditional_odds_ratio",
            "estimate": conditional_odds_ratio,
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "log_likelihood",
            "estimate": log_likelihood,
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "first_event_set_probability",
            "estimate": first_event_set_probability,
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "first_event_set_log_probability",
            "estimate": first_event_set_log_probability,
            "se": None,
            "n_obs": n_obs,
        },
    ]

    result = {
        "task_id": "lp11_duration",
        "estimates": estimates,
        "method_metadata": {
            "model": "Cox discrete-time conditional odds model",
            "optimization_interval": [-4, 4],
            "likelihood_constant": "excluded",
            "denominator_method": "exact elementary symmetric polynomial via combinatorial summation",
        },
        "diagnostics": {
            "n_obs": n_obs,
            "n_cohorts": len(cohorts),
            "n_risk_set_contributions": len(contributions),
        },
    }

    with open("result.json", "w", encoding="utf-8") as handle:
        json.dump(result, handle, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
