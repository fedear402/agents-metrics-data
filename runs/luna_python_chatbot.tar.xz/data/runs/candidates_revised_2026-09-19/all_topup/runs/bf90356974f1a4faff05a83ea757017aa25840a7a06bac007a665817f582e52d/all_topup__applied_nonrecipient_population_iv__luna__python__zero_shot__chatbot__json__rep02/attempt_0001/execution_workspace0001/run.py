import csv
import json
import numpy as np


def read_csv(path):
    with open(path, newline="", encoding="utf-8") as file:
        return list(csv.DictReader(file))


def value(row, key):
    return float(row[key])


households = read_csv("households.csv")
census = read_csv("census.csv")

retained = [row for row in households if value(row, "recipient") == 0]
n_obs = len(retained)

eligible = np.array([value(row, "eligible") for row in retained], dtype=float)
instrument = np.array([value(row, "instrument") for row in retained], dtype=float)
dose = np.array([value(row, "dose") for row in retained], dtype=float)
baseline = np.array([value(row, "baseline") for row in retained], dtype=float)
weight = np.array([value(row, "weight") for row in retained], dtype=float)
outcome = np.array([value(row, "outcome") for row in retained], dtype=float)

ineligible = 1.0 - eligible

endogenous = np.column_stack([
    dose * ineligible,
    dose * eligible,
])

exogenous = np.column_stack([
    ineligible,
    eligible,
    baseline * ineligible,
    baseline * eligible,
])

instruments = np.column_stack([
    ineligible,
    eligible,
    baseline * ineligible,
    baseline * eligible,
    instrument * ineligible,
    instrument * eligible,
])

sqrt_weight = np.sqrt(weight)

weighted_instruments = instruments * sqrt_weight[:, None]
weighted_endogenous = endogenous * sqrt_weight[:, None]
weighted_outcome = outcome * sqrt_weight

first_stage_coefficients = np.linalg.lstsq(
    weighted_instruments,
    weighted_endogenous,
    rcond=None,
)[0]

fitted_endogenous = instruments @ first_stage_coefficients
second_stage_regressors = np.column_stack([
    exogenous,
    fitted_endogenous,
])

weighted_regressors = second_stage_regressors * sqrt_weight[:, None]

second_stage_coefficients = np.linalg.lstsq(
    weighted_regressors,
    weighted_outcome,
    rcond=None,
)[0]

ineligible_slope = float(second_stage_coefficients[4])
eligible_slope = float(second_stage_coefficients[5])


def weighted_mean(values, weights):
    return float(np.sum(values * weights) / np.sum(weights))


ineligible_mean_dose = weighted_mean(
    dose[eligible == 0],
    weight[eligible == 0],
)
eligible_mean_dose = weighted_mean(
    dose[eligible == 1],
    weight[eligible == 1],
)

ineligible_effect = ineligible_slope * ineligible_mean_dose
eligible_nonrecipient_effect = eligible_slope * eligible_mean_dose

population_by_group = {0.0: 0.0, 1.0: 0.0}
for row in census:
    group = value(row, "eligible")
    population_by_group[group] += value(row, "nonrecipient_population")

total_population = sum(population_by_group.values())
population_effect = (
    ineligible_effect * population_by_group[0.0]
    + eligible_nonrecipient_effect * population_by_group[1.0]
) / total_population

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "ineligible_effect",
            "estimate": float(ineligible_effect),
            "se": None,
            "n_obs": int(n_obs),
        },
        {
            "term": "eligible_nonrecipient_effect",
            "estimate": float(eligible_nonrecipient_effect),
            "se": None,
            "n_obs": int(n_obs),
        },
        {
            "term": "population_effect",
            "estimate": float(population_effect),
            "se": None,
            "n_obs": int(n_obs),
        },
    ],
    "method_metadata": {
        "estimator": "weighted_2SLS",
        "endogenous_columns": [
            "dose*(1-eligible)",
            "dose*eligible",
        ],
        "exogenous_columns": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
        ],
        "instrument_columns": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
            "instrument*(1-eligible)",
            "instrument*eligible",
        ],
        "intercept": False,
        "weight_column": "weight",
        "retained_condition": "recipient == 0",
        "counterfactual": "dose == 0 for every retained household",
        "group_effect_convention": "fitted dose slope times household-weighted mean dose",
        "population_aggregation_weight": "census.nonrecipient_population",
        "n_obs": int(n_obs),
    },
    "diagnostics": {
        "retained_household_rows": int(n_obs),
        "ineligible_retained_rows": int(np.sum(eligible == 0)),
        "eligible_retained_rows": int(np.sum(eligible == 1)),
        "ineligible_weighted_mean_dose": float(ineligible_mean_dose),
        "eligible_weighted_mean_dose": float(eligible_mean_dose),
        "ineligible_dose_slope": float(ineligible_slope),
        "eligible_dose_slope": float(eligible_slope),
        "census_ineligible_population": float(population_by_group[0.0]),
        "census_eligible_population": float(population_by_group[1.0]),
    },
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file, indent=2, allow_nan=False)
