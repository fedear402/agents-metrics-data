import csv
import json
from collections import defaultdict
from pathlib import Path

import numpy as np


def read_csv(name):
    with open(Path(name), newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def number(value):
    return float(value)


def key_value(value):
    try:
        x = float(value)
        return int(x) if x.is_integer() else x
    except ValueError:
        return value


crosswalk = read_csv("crosswalk.csv")
trade = read_csv("trade.csv")
areas = read_csv("areas.csv")
employment = read_csv("employment.csv")
outcomes = read_csv("outcomes.csv")

code_to_industry = {
    row["code"]: row["industry"] for row in crosswalk
}

trade_by_period_code = {
    (row["period"], row["code"]): row for row in trade
}

area_rows = {
    (row["area"], row["period"], row["vintage"]): row
    for row in areas
}

outcome_rows = {
    (row["area"], row["period"]): row
    for row in outcomes
}

employment_by_key = defaultdict(float)
for row in employment:
    employment_by_key[
        (row["area"], row["period"], row["vintage"], row["industry"])
    ] += number(row["employment"])

industries = sorted(set(code_to_industry.values()))

national_employment = defaultdict(float)
for row in employment:
    national_employment[
        (row["period"], row["vintage"], row["industry"])
    ] += number(row["employment"])

periods = sorted({row["period"] for row in areas}, key=key_value)
areas_ids = sorted({row["area"] for row in areas}, key=key_value)

rows = []
for area in areas_ids:
    for period in periods:
        base_area = area_rows[(area, period, "base")]
        early_area = area_rows[(area, period, "early")]
        outcome = outcome_rows[(area, period)]

        x = 0.0
        z = 0.0

        for code, industry in code_to_industry.items():
            tr = trade_by_period_code[(period, code)]
            price_factor = number(tr["price_index"]) / 100.0
            interval_factor = 10.0 / number(tr["years"])

            base_emp = employment_by_key[
                (area, period, "base", industry)
            ]
            early_emp = employment_by_key[
                (area, period, "early", industry)
            ]

            national_base = national_employment[
                (period, "base", industry)
            ]
            national_early = national_employment[
                (period, "early", industry)
            ]

            x += (
                (base_emp / number(base_area["total_employment"]))
                * (number(tr["us_change"]) / national_base)
                / price_factor
                / 1000.0
                * interval_factor
            )

            z += (
                (early_emp / number(early_area["total_employment"]))
                * (number(tr["other_change"]) / national_early)
                / price_factor
                / 1000.0
                * interval_factor
            )

        rows.append(
            {
                "area": area,
                "period": period,
                "period_numeric": key_value(period),
                "control": number(outcome["control"]),
                "change_pp": number(outcome["change_pp"]),
                "x": x,
                "z": z,
                "weight": number(base_area["population"]),
            }
        )

n_obs = len(rows)

y = np.array([r["change_pp"] for r in rows], dtype=float)
x = np.array([r["x"] for r in rows], dtype=float)
z = np.array([r["z"] for r in rows], dtype=float)
control = np.array([r["control"] for r in rows], dtype=float)
period = np.array([r["period_numeric"] for r in rows], dtype=float)
weights = np.array([r["weight"] for r in rows], dtype=float)

exog = np.column_stack([np.ones(n_obs), period, control])
instruments = np.column_stack([exog, z])

sqrt_weights = np.sqrt(weights)
weighted_instruments = instruments * sqrt_weights[:, None]
weighted_x = x * sqrt_weights
first_stage_coefficients = np.linalg.lstsq(
    weighted_instruments, weighted_x, rcond=None
)[0]
x_hat = instruments @ first_stage_coefficients

second_stage_regressors = np.column_stack([exog, x_hat])
weighted_second_stage_regressors = second_stage_regressors * sqrt_weights[:, None]
weighted_y = y * sqrt_weights
second_stage_coefficients = np.linalg.lstsq(
    weighted_second_stage_regressors, weighted_y, rcond=None
)[0]

iv_slope = float(second_stage_coefficients[-1])

area0_period0 = next(
    r["x"] for r in rows
    if key_value(r["area"]) == 0 and key_value(r["period"]) == 0
)
area0_period1 = next(
    r["x"] for r in rows
    if key_value(r["area"]) == 0 and key_value(r["period"]) == 1
)
instrument_area0_period0 = next(
    r["z"] for r in rows
    if key_value(r["area"]) == 0 and key_value(r["period"]) == 0
)

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "iv_slope",
            "estimate": iv_slope,
            "se": None,
            "n_obs": 72,
        },
        {
            "term": "exposure_area0_period0",
            "estimate": float(area0_period0),
            "se": None,
            "n_obs": 72,
        },
        {
            "term": "exposure_area0_period1",
            "estimate": float(area0_period1),
            "se": None,
            "n_obs": 72,
        },
        {
            "term": "instrument_area0_period0",
            "estimate": float(instrument_area0_period0),
            "se": None,
            "n_obs": 72,
        },
    ],
    "method_metadata": {
        "estimator": "weighted_2sls",
        "outcome": "change_pp",
        "endogenous_regressor": "x",
        "instrument": "z",
        "exogenous_regressors": ["intercept", "period", "control"],
        "weight": "base-vintage population",
        "sample_definition": "all area-period observations",
    },
    "diagnostics": {
        "n_obs": 72,
        "n_areas": len(areas_ids),
        "n_periods": len(periods),
        "n_industries": len(industries),
    },
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2)
