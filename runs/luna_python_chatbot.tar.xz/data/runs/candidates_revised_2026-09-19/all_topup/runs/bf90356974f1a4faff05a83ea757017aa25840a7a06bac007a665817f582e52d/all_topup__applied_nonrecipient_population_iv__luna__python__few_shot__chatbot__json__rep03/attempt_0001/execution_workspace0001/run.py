import json
from pathlib import Path

import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS


def main():
    households = pd.read_csv(Path("households.csv"))
    census = pd.read_csv(Path("census.csv"))

    data = households.loc[households["recipient"] == 0].copy()
    data["_ineligible"] = 1 - data["eligible"]
    data["_eligible"] = data["eligible"]

    exog = pd.DataFrame(
        {
            "ineligible": data["_ineligible"],
            "eligible": data["_eligible"],
            "baseline_ineligible": data["baseline"] * data["_ineligible"],
            "baseline_eligible": data["baseline"] * data["_eligible"],
        },
        index=data.index,
    )

    endog = pd.DataFrame(
        {
            "dose_ineligible": data["dose"] * data["_ineligible"],
            "dose_eligible": data["dose"] * data["_eligible"],
        },
        index=data.index,
    )

    excluded_instruments = pd.DataFrame(
        {
            "instrument_ineligible": data["instrument"] * data["_ineligible"],
            "instrument_eligible": data["instrument"] * data["_eligible"],
        },
        index=data.index,
    )

    fit = IV2SLS(
        dependent=data["outcome"],
        exog=exog,
        endog=endog,
        instruments=excluded_instruments,
        weights=data["weight"],
    ).fit()

    ineligible_slope = float(fit.params["dose_ineligible"])
    eligible_slope = float(fit.params["dose_eligible"])

    ineligible_data = data.loc[data["eligible"] == 0]
    eligible_data = data.loc[data["eligible"] == 1]

    ineligible_mean_dose = float(
        np.average(ineligible_data["dose"], weights=ineligible_data["weight"])
    )
    eligible_mean_dose = float(
        np.average(eligible_data["dose"], weights=eligible_data["weight"])
    )

    ineligible_effect = ineligible_slope * ineligible_mean_dose
    eligible_nonrecipient_effect = eligible_slope * eligible_mean_dose

    population_weights = (
        census.groupby("eligible", as_index=True)["nonrecipient_population"].sum()
    )
    ineligible_population = float(population_weights.loc[0])
    eligible_population = float(population_weights.loc[1])

    population_effect = float(
        np.average(
            [ineligible_effect, eligible_nonrecipient_effect],
            weights=[ineligible_population, eligible_population],
        )
    )

    n_obs = int(len(data))

    result = {
        "task_id": "applied_nonrecipient_population_iv",
        "platform": "python",
        "estimates": [
            {
                "term": "ineligible_effect",
                "estimate": float(ineligible_effect),
                "se": None,
                "n_obs": n_obs,
            },
            {
                "term": "eligible_nonrecipient_effect",
                "estimate": float(eligible_nonrecipient_effect),
                "se": None,
                "n_obs": n_obs,
            },
            {
                "term": "population_effect",
                "estimate": float(population_effect),
                "se": None,
                "n_obs": n_obs,
            },
        ],
        "method_metadata": {
            "estimator": "weighted 2SLS",
            "counterfactual": "dose set to zero for every retained household",
            "retained_sample": "households with recipient equal to zero",
            "group_effect_definition": "fitted dose slope times household-weighted mean dose",
            "population_aggregation_variable": "nonrecipient_population",
            "population_aggregation_source": "census.csv",
            "intercept": "none",
        },
        "diagnostics": {
            "n_obs": n_obs,
            "n_ineligible": int(len(ineligible_data)),
            "n_eligible_nonrecipient": int(len(eligible_data)),
            "ineligible_population": ineligible_population,
            "eligible_population": eligible_population,
        },
    }

    with open("result.json", "w", encoding="utf-8") as file:
        json.dump(result, file, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
