import csv
import json
from collections import defaultdict
from pathlib import Path

import numpy as np


def read_csv(name):
    with Path(name).open(newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def number(value):
    try:
        return int(value)
    except ValueError:
        return float(value)


crosswalk = read_csv("crosswalk.csv")
trade = read_csv("trade.csv")
areas = read_csv("areas.csv")
employment = read_csv("employment.csv")
outcomes = read_csv("outcomes.csv")

code_to_industry = {
    row["code"]: row["industry"] for row in crosswalk
}

industries = sorted({row["industry"] for row in crosswalk})
periods = sorted({row["period"] for row in trade}, key=lambda x: number(x))
period_value = {p: number(p) for p in periods}

trade_values = {}
for row in trade:
    period = row["period"]
    industry = code_to_industry[row["code"]]
    trade_values[(period, industry)] = {
        "us_change": float(row["us_change"]),
        "other_change": float(row["other_change"]),
        "price_index": float(row["price_index"]),
        "years": float(row["years"]),
    }

area_rows = {}
for row in areas:
    key = (row["area"], row["period"], row["vintage"])
    area_rows[key] = {
        "total_employment": float(row["total_employment"]),
        "population": float(row["population"]),
    }

area_periods = sorted(
    {(row["area"], row["period"]) for row in areas},
    key=lambda x: (number(x[0]), number(x[1])),
)

employment_values = defaultdict(float)
for row in employment:
    employment_values[
        (row["area"], row["period"], row["vintage"], row["industry"])
    ] += float(row["employment"])

national = defaultdict(float)
for key, value in employment_values.items():
    _, period, vintage, industry = key
    national[(period, vintage, industry)] += value

def exposure(area, period, vintage, change_key):
    area_info = area_rows[(area, period, vintage)]
    total = area_info["total_employment"]
    trade_info = trade_values
    price_index = trade_info[(period, industries[0])]["price_index"]
    years = trade_info[(period, industries[0])]["years"]

    result = 0.0
    for industry in industries:
        employment_value = employment_values[
            (area, period, vintage, industry)
        ]
        national_employment = national[(period, vintage, industry)]
        change = trade_info[(period, industry)][change_key]
        result += (
            employment_value / total
            * change / national_employment
            / (price_index / 100.0)
            / 1000.0
            * (10.0 / years)
        )
    return result


outcome_values = {}
for row in outcomes:
    outcome_values[(row["area"], row["period"])] = {
        "control": float(row["control"]),
        "change_pp": float(row["change_pp"]),
    }

rows = []
for area, period in area_periods:
    base_info = area_rows[(area, period, "base")]
    rows.append(
        {
            "area": area,
            "period": period,
            "y": outcome_values[(area, period)]["change_pp"],
            "control": outcome_values[(area, period)]["control"],
            "weight": base_info["population"],
            "x": exposure(area, period, "base", "us_change"),
            "z": exposure(area, period, "early", "other_change"),
        }
    )

n_obs = len(rows)

y = np.array([row["y"] for row in rows], dtype=float)
period_column = np.array(
    [period_value[row["period"]] for row in rows], dtype=float
)
control = np.array([row["control"] for row in rows], dtype=float)
x = np.array([row["x"] for row in rows], dtype=float)
z = np.array([row["z"] for row in rows], dtype=float)
weights = np.array([row["weight"] for row in rows], dtype=float)

X = np.column_stack((np.ones(n_obs), period_column, control, x))
Q = np.column_stack((np.ones(n_obs), period_column, control, z))

sqrt_weights = np.sqrt(weights)
Xw = X * sqrt_weights[:, None]
Qw = Q * sqrt_weights[:, None]
yw = y * sqrt_weights

q_cross = Qw.T @ Qw
q_cross_inv = np.linalg.inv(q_cross)
projection = Qw @ q_cross_inv @ Qw.T
beta = np.linalg.solve(Xw.T @ projection @ Xw, Xw.T @ projection @ yw)

area0_periods = sorted(
    [row for row in rows if number(row["area"]) == 0],
    key=lambda row: number(row["period"]),
)

estimates = [
    {
        "term": "iv_slope",
        "estimate": float(beta[3]),
        "se": None,
        "n_obs": int(n_obs),
    },
    {
        "term": "exposure_area0_period0",
        "estimate": float(
            next(row["x"] for row in area0_periods if number(row["period"]) == 0)
        ),
        "se": None,
        "n_obs": int(n_obs),
    },
    {
        "term": "exposure_area0_period1",
        "estimate": float(
            next(row["x"] for row in area0_periods if number(row["period"]) == 1)
        ),
        "se": None,
        "n_obs": int(n_obs),
    },
    {
        "term": "instrument_area0_period0",
        "estimate": float(
            next(row["z"] for row in area0_periods if number(row["period"]) == 0)
        ),
        "se": None,
        "n_obs": int(n_obs),
    },
]

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "weighted two-stage least squares",
        "outcome": "change_pp",
        "endogenous": ["x"],
        "instruments": ["z"],
        "exogenous_regressors": ["intercept", "period", "control"],
        "weight": "base-vintage population",
        "exposure_units": "thousands of real dollars per worker per decade",
    },
    "diagnostics": {
        "n_obs": int(n_obs),
        "n_industries": int(len(industries)),
        "n_periods": int(len(periods)),
    },
}

with Path("result.json").open("w", encoding="utf-8") as f:
    json.dump(result, f, indent=2)
