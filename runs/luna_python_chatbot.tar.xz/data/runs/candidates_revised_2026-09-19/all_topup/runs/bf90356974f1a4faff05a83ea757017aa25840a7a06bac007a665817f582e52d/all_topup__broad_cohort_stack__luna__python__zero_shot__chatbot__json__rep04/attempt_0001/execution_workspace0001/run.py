import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")

cohorts = [3, 5, 7]
estimates = []
comparison_results = []

for cohort in cohorts:
    window_times = list(range(cohort - 2, cohort + 3))

    eligible = df[
        (df["g"] == cohort)
        | (df["g"] == 0)
        | (df["g"] > cohort + 2)
    ].copy()

    window = eligible[eligible["time"].isin(window_times)].copy()

    balanced_ids = (
        window.groupby("id")["time"]
        .nunique()
        .loc[lambda s: s == len(window_times)]
        .index
    )

    comparison = window[window["id"].isin(balanced_ids)].copy()
    comparison["did"] = (
        (comparison["g"] == cohort)
        & (comparison["time"] >= cohort)
    ).astype(float)

    unit_dummies = pd.get_dummies(
        comparison["id"].astype(str),
        prefix="unit",
        drop_first=True,
        dtype=float,
    )
    time_dummies = pd.get_dummies(
        comparison["time"],
        prefix="time",
        drop_first=True,
        dtype=float,
    )

    X = pd.concat(
        [
            pd.Series(1.0, index=comparison.index, name="intercept"),
            comparison[["did"]].astype(float),
            unit_dummies,
            time_dummies,
        ],
        axis=1,
    )

    y = comparison["y"].to_numpy(dtype=float)
    beta = np.linalg.lstsq(X.to_numpy(dtype=float), y, rcond=None)[0]
    did_index = X.columns.get_loc("did")
    estimate = float(beta[did_index])

    treated_units = comparison.loc[
        comparison["g"] == cohort, "id"
    ].nunique()

    comparison_results.append(
        {
            "cohort": cohort,
            "estimate": estimate,
            "n_obs": int(len(comparison)),
            "treated_units": int(treated_units),
        }
    )

    estimates.append(
        {
            "term": f"att_g{cohort}",
            "estimate": estimate,
            "se": None,
            "n_obs": int(len(comparison)),
        }
    )

total_treated_units = sum(
    result["treated_units"] for result in comparison_results
)
weighted_estimate = sum(
    result["estimate"] * result["treated_units"]
    for result in comparison_results
) / total_treated_units

estimates.append(
    {
        "term": "att_weighted",
        "estimate": float(weighted_estimate),
        "se": None,
        "n_obs": int(sum(result["n_obs"] for result in comparison_results)),
    }
)

result = {
    "task_id": "broad_cohort_stack",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {},
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file, indent=2)
