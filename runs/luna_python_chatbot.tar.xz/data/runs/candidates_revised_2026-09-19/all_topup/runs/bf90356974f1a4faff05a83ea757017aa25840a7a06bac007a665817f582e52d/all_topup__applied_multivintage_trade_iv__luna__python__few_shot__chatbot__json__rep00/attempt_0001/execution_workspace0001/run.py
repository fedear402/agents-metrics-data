import json
from pathlib import Path

import numpy as np
import pandas as pd


def main():
    crosswalk = pd.read_csv("crosswalk.csv")
    trade = pd.read_csv("trade.csv")
    areas = pd.read_csv("areas.csv")
    employment = pd.read_csv("employment.csv")
    outcomes = pd.read_csv("outcomes.csv")

    trade = trade.merge(crosswalk, on="code", how="inner", validate="many_to_one")

    area_period = (
        areas[areas["vintage"].eq("base")]
        .loc[:, ["area", "period", "total_employment", "population"]]
        .drop_duplicates(["area", "period"])
    )

    totals = (
        areas.loc[:, ["area", "period", "vintage", "total_employment"]]
        .drop_duplicates(["area", "period", "vintage"])
    )

    periods = sorted(area_period["period"].unique())
    industries = sorted(crosswalk["industry"].unique())

    employment_full = (
        areas.loc[:, ["area", "period", "vintage"]]
        .drop_duplicates()
        .assign(_key=1)
        .merge(pd.DataFrame({"industry": industries, "_key": 1}), on="_key")
        .drop(columns="_key")
        .merge(
            employment,
            on=["area", "period", "vintage", "industry"],
            how="left",
        )
    )
    employment_full["employment"] = employment_full["employment"].fillna(0.0)

    national = (
        employment_full.groupby(["period", "vintage", "industry"], as_index=False)
        ["employment"]
        .sum()
        .rename(columns={"employment": "national_employment"})
    )

    employment_full = employment_full.merge(
        national,
        on=["period", "vintage", "industry"],
        how="left",
        validate="many_to_one",
    )

    changes = trade.loc[
        :, ["period", "industry", "us_change", "other_change", "price_index", "years"]
    ]

    employment_full = employment_full.merge(
        changes,
        on=["period", "industry"],
        how="left",
        validate="many_to_one",
    )

    employment_full["shock_us"] = (
        employment_full["us_change"]
        / employment_full["national_employment"]
        / (employment_full["price_index"] / 100.0)
        / 1000.0
        * (10.0 / employment_full["years"])
    )
    employment_full["shock_other"] = (
        employment_full["other_change"]
        / employment_full["national_employment"]
        / (employment_full["price_index"] / 100.0)
        / 1000.0
        * (10.0 / employment_full["years"])
    )

    exposures = (
        employment_full.merge(
            totals,
            on=["area", "period", "vintage"],
            how="left",
            validate="many_to_one",
            suffixes=("", "_area"),
        )
        .assign(
            contribution_x=lambda d: (
                d["employment"] / d["total_employment_area"] * d["shock_us"]
            ),
            contribution_z=lambda d: (
                d["employment"] / d["total_employment_area"] * d["shock_other"]
            ),
        )
        .groupby(["area", "period", "vintage"], as_index=False)[
            ["contribution_x", "contribution_z"]
        ]
        .sum()
        .pivot(index=["area", "period"], columns="vintage")
    )

    exposures.columns = [
        f"{value}_{vintage}" for value, vintage in exposures.columns
    ]
    exposures = exposures.reset_index().rename(
        columns={
            "contribution_x_base": "x",
            "contribution_z_early": "z",
        }
    )

    data = (
        area_period.merge(outcomes, on=["area", "period"], how="inner", validate="one_to_one")
        .merge(exposures[["area", "period", "x", "z"]], on=["area", "period"], how="inner")
    )

    period_numeric = pd.to_numeric(data["period"], errors="coerce")
    if period_numeric.notna().all():
        period_column = period_numeric.to_numpy(dtype=float)
        period_names = ["period"]
    else:
        period_dummies = pd.get_dummies(
            data["period"].astype(str), prefix="period", drop_first=True, dtype=float
        )
        period_column = period_dummies.to_numpy(dtype=float)
        period_names = list(period_dummies.columns)

    exog = np.column_stack(
        [
            np.ones(len(data)),
            period_column,
            data["control"].to_numpy(dtype=float),
        ]
    )
    endogenous = data[["x"]].to_numpy(dtype=float)
    instruments = np.column_stack(
        [
            exog,
            data[["z"]].to_numpy(dtype=float),
        ]
    )
    regressors = np.column_stack([exog, endogenous])
    weights = data["population"].to_numpy(dtype=float)
    sqrt_weights = np.sqrt(weights)

    z_weighted = instruments * sqrt_weights[:, None]
    x_weighted = regressors * sqrt_weights[:, None]

    projection_coefficients = np.linalg.pinv(z_weighted) @ x_weighted
    fitted_weighted = z_weighted @ projection_coefficients

    beta = np.linalg.pinv(fitted_weighted.T @ fitted_weighted) @ (
        fitted_weighted.T @ (data["change_pp"].to_numpy(dtype=float) * sqrt_weights)
    )

    area0 = data[data["area"].astype(str).eq("0")]
    exposure_area0_period0 = float(
        area0.loc[area0["period"].astype(str).eq("0"), "x"].iloc[0]
    )
    exposure_area0_period1 = float(
        area0.loc[area0["period"].astype(str).eq("1"), "x"].iloc[0]
    )
    instrument_area0_period0 = float(
        area0.loc[area0["period"].astype(str).eq("0"), "z"].iloc[0]
    )

    result = {
        "task_id": "applied_multivintage_trade_iv",
        "platform": "python",
        "estimates": [
            {
                "term": "iv_slope",
                "estimate": float(beta[-1]),
                "se": None,
                "n_obs": int(len(data)),
            },
            {
                "term": "exposure_area0_period0",
                "estimate": exposure_area0_period0,
                "se": None,
                "n_obs": int(len(data)),
            },
            {
                "term": "exposure_area0_period1",
                "estimate": exposure_area0_period1,
                "se": None,
                "n_obs": int(len(data)),
            },
            {
                "term": "instrument_area0_period0",
                "estimate": instrument_area0_period0,
                "se": None,
                "n_obs": int(len(data)),
            },
        ],
        "method_metadata": {
            "estimator": "weighted_two_stage_least_squares",
            "outcome": "change_pp",
            "endogenous": "x",
            "instrument": "z",
            "exogenous": ["intercept", *period_names, "control"],
            "weight": "base-vintage population",
        },
        "diagnostics": {
            "n_obs": int(len(data)),
            "n_areas": int(data["area"].nunique()),
            "n_periods": int(data["period"].nunique()),
        },
    }

    with Path("result.json").open("w", encoding="utf-8") as file:
        json.dump(result, file, indent=2)


if __name__ == "__main__":
    main()
