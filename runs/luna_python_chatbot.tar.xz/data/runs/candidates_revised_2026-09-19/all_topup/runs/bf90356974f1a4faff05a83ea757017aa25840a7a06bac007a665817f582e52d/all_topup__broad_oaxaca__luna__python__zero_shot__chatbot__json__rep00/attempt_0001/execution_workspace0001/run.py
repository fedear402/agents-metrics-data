import csv
import json


def solve_linear_system(matrix, vector):
    n = len(vector)
    a = [row[:] + [vector[i]] for i, row in enumerate(matrix)]

    for col in range(n):
        pivot = max(range(col, n), key=lambda row: abs(a[row][col]))
        if abs(a[pivot][col]) < 1e-12:
            raise ValueError("Singular design matrix")
        a[col], a[pivot] = a[pivot], a[col]

        pivot_value = a[col][col]
        for j in range(col, n + 1):
            a[col][j] /= pivot_value

        for row in range(n):
            if row == col:
                continue
            factor = a[row][col]
            for j in range(col, n + 1):
                a[row][j] -= factor * a[col][j]

    return [a[i][n] for i in range(n)]


def fit_group(rows):
    n = len(rows)
    xbar = [
        sum(row["y"] for row in rows) / n,
        sum(row["x"] for row in rows) / n,
        sum(row["z"] for row in rows) / n,
    ]

    xtx = [[0.0] * 3 for _ in range(3)]
    xty = [0.0] * 3

    for row in rows:
        design = [1.0, row["x"], row["z"]]
        for i in range(3):
            xty[i] += design[i] * row["y"]
            for j in range(3):
                xtx[i][j] += design[i] * design[j]

    beta = solve_linear_system(xtx, xty)
    return xbar, beta


rows = []
with open("input.csv", newline="") as handle:
    reader = csv.DictReader(handle)
    for record in reader:
        rows.append(
            {
                "y": float(record["y"]),
                "x": float(record["x"]),
                "z": float(record["z"]),
                "group": int(record["group"]),
            }
        )

group_0 = [row for row in rows if row["group"] == 0]
group_1 = [row for row in rows if row["group"] == 1]

xbar_0, beta_0 = fit_group(group_0)
xbar_1, beta_1 = fit_group(group_1)

gap = xbar_1[0] - xbar_0[0]
explained = sum((xbar_1[i] - xbar_0[i]) * beta_0[i] for i in range(3))
unexplained = sum(xbar_1[i] * (beta_1[i] - beta_0[i]) for i in range(3))
explained_x = (xbar_1[1] - xbar_0[1]) * beta_0[1]

n_obs = len(rows)

result = {
    "task_id": "broad_oaxaca",
    "platform": "python",
    "estimates": [
        {
            "term": "gap",
            "estimate": gap,
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "explained",
            "estimate": explained,
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "unexplained",
            "estimate": unexplained,
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "explained_x",
            "estimate": explained_x,
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {},
    "diagnostics": {},
}

with open("result.json", "w") as handle:
    json.dump(result, handle, indent=2)
