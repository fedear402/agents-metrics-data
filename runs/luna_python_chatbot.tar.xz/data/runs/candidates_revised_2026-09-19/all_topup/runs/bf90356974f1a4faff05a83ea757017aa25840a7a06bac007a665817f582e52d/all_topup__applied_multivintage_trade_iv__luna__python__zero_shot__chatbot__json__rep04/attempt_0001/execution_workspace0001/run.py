import csv
import json
import numpy as np


def read_csv(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def num(value):
    return float(value)


def key(value):
    try:
        return int(value)
    except ValueError:
        try:
            return float(value)
        except ValueError:
            return value


crosswalk = read_csv("crosswalk.csv")
trade = read_csv("trade.csv")
areas = read_csv("areas.csv")
employment = read_csv("employment.csv")
outcomes = read_csv("outcomes.csv")

code_to_industry = {row["code"]: row["industry"] for row in crosswalk}

trade_by_period = {}
for row in trade:
    period = key(row["period"])
    trade_by_period.setdefault(period, {})[code_to_industry[row["code"]]] = {
        "us_change": num(row["us_change"]),
        "other_change": num(row["other_change"]),
        "price_index": num(row["price_index"]),
        "years": num(row["years"]),
    }

area_rows = {}
for row in areas:
    area = key(row["area"])
    period = key(row["period"])
    vintage = row["vintage"]
    area_rows[(area, period, vintage)] = {
        "total_employment": num(row["total_employment"]),
        "population": num(row["population"]),
    }

employment_by_key = {}
for row in employment:
    employment_by_key[
        (key(row["area"]), key(row["period"]), row["vintage"], row["industry"])
    ] = num(row["employment"])

periods = sorted({key(row["period"]) for row in outcomes})
areas_in_sample = sorted({key(row["area"]) for row in outcomes})
industries = sorted({row["industry"] for row in crosswalk})

national_employment = {}
for period in periods:
    for vintage in ("base", "early"):
        for industry in industries:
            national_employment[(period, vintage, industry)] = sum(
                employment_by_key.get((area, period, vintage, industry), 0.0)
                for area in areas_in_sample
            )

observations = []
for row in outcomes:
    area = key(row["area"])
    period = key(row["period"])
    trade_period = trade_by_period[period]
    base_area = area_rows[(area, period, "base")]
    early_area = area_rows[(area, period, "early")]

    x = 0.0
    z = 0.0

    for industry in industries:
        base_emp = employment_by_key.get(
            (area, period, "base", industry), 0.0
        )
        early_emp = employment_by_key.get(
            (area, period, "early", industry), 0.0
        )

        trade_row = next(
            trade_period[code_to_industry[code]]
            for code in trade_period
            if code_to_industry[code] == industry
        )

        x += (
            (base_emp / base_area["total_employment"])
            * (
                trade_row["us_change"]
                / national_employment[(period, "base", industry)]
            )
            / (trade_row["price_index"] / 100.0)
            / 1000.0
            * (10.0 / trade_row["years"])
        )

        z += (
            (early_emp / early_area["total_employment"])
            * (
                trade_row["other_change"]
                / national_employment[(period, "early", industry)]
            )
            / (trade_row["price_index"] / 100.0)
            / 1000.0
            * (10.0 / trade_row["years"])
        )

    observations.append(
        {
            "area": area,
            "period": period,
            "control": num(row["control"]),
            "change_pp": num(row["change_pp"]),
            "x": x,
            "z": z,
            "weight": base_area["population"],
        }
    )

y = np.array([obs["change_pp"] for obs in observations], dtype=float)
x = np.array([obs["x"] for obs in observations], dtype=float)
z = np.array([obs["z"] for obs in observations], dtype=float)
control = np.array([obs["control"] for obs in observations], dtype=float)
period_values = np.array([obs["period"] for obs in observations], dtype=float)
weights = np.array([obs["weight"] for obs in observations], dtype=float)

sqrt_weights = np.sqrt(weights)
exog = np.column_stack(
    [
        np.ones(len(observations)),
        period_values,
        control,
    ]
)

weighted_exog = exog * sqrt_weights[:, None]
weighted_y = y * sqrt_weights
weighted_x = x * sqrt_weights
weighted_z = z * sqrt_weights

projection_exog = weighted_exog @ np.linalg.pinv(weighted_exog)
residual_y = weighted_y - projection_exog @ weighted_y
residual_x = weighted_x - projection_exog @ weighted_x
residual_z = weighted_z - projection_exog @ weighted_z

z_cross_x = float(residual_z @ residual_x)
z_cross_y = float(residual_z @ residual_y)
iv_slope = z_cross_x and z_cross_y / z_cross_x

def find_exposure(area_value, period_value, variable):
    for obs in observations:
        if obs["area"] == area_value and obs["period"] == period_value:
            return obs[variable]
    raise KeyError((area_value, period_value, variable))


area0 = 0
period0 = 0
period1 = 1

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "iv_slope",
            "estimate": float(iv_slope),
            "se": None,
            "n_obs": int(len(observations)),
        },
        {
            "term": "exposure_area0_period0",
            "estimate": float(find_exposure(area0, period0, "x")),
            "se": None,
            "n_obs": int(len(observations)),
        },
        {
            "term": "exposure_area0_period1",
            "estimate": float(find_exposure(area0, period1, "x")),
            "se": None,
            "n_obs": int(len(observations)),
        },
        {
            "term": "instrument_area0_period0",
            "estimate": float(find_exposure(area0, period0, "z")),
            "se": None,
            "n_obs": int(len(observations)),
        },
    ],
    "method_metadata": {
        "estimator": "weighted_two_stage_least_squares",
        "dependent_variable": "change_pp",
        "endogenous_variable": "x",
        "instrument": "z",
        "exogenous_variables": ["intercept", "period", "control"],
        "weight": "base-vintage population",
        "missing_area_industry_employment": "zero",
        "exposure_units": "thousands of real dollars per worker per decade",
    },
    "diagnostics": {
        "n_obs": int(len(observations)),
        "n_exogenous": 3,
        "n_instruments": 4,
    },
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, allow_nan=False)
