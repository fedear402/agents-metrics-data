import csv
import json
import numpy as np

with open("input.csv", newline="") as f:
    rows = list(csv.DictReader(f))

cohorts = [3, 5, 7]
estimates = []
results = {}

for c in cohorts:
    window = list(range(c - 2, c + 3))

    eligible = [
        r for r in rows
        if int(r["g"]) == c or int(r["g"]) == 0 or int(r["g"]) > c + 2
    ]

    by_id = {}
    for r in eligible:
        by_id.setdefault(r["id"], {})[int(r["time"])] = r

    retained_ids = [
        unit_id
        for unit_id, observations in by_id.items()
        if all(t in observations for t in window)
    ]

    retained = [
        by_id[unit_id][t]
        for unit_id in retained_ids
        for t in window
    ]

    unit_levels = sorted(retained_ids)
    time_levels = window

    unit_index = {unit_id: i for i, unit_id in enumerate(unit_levels)}
    time_index = {t: i for i, t in enumerate(time_levels)}

    y = np.array([float(r["y"]) for r in retained], dtype=float)
    did = np.array(
        [
            1.0
            if int(r["g"]) == c and int(r["time"]) >= c
            else 0.0
            for r in retained
        ],
        dtype=float,
    )

    x = np.zeros((len(retained), 1 + len(unit_levels) - 1 + len(time_levels) - 1))
    x[:, 0] = did

    for row_index, r in enumerate(retained):
        unit_col = unit_index[r["id"]]
        time_col = time_index[int(r["time"])]

        if unit_col > 0:
            x[row_index, unit_col] = 1.0

        if time_col > 0:
            x[row_index, len(unit_levels) - 1 + time_col] = 1.0

    coefficient = float(np.linalg.lstsq(x, y, rcond=None)[0][0])
    n_obs = len(retained)
    n_treated = sum(int(r["g"]) == c for r in retained)

    term = f"att_g{c}"
    results[term] = {
        "estimate": coefficient,
        "n_obs": n_obs,
        "n_treated": n_treated,
    }

    estimates.append(
        {
            "term": term,
            "estimate": coefficient,
            "se": None,
            "n_obs": n_obs,
        }
    )

total_treated = sum(results[f"att_g{c}"]["n_treated"] for c in cohorts)
weighted_estimate = sum(
    results[f"att_g{c}"]["estimate"] * results[f"att_g{c}"]["n_treated"]
    for c in cohorts
) / total_treated

estimates.append(
    {
        "term": "att_weighted",
        "estimate": weighted_estimate,
        "se": None,
        "n_obs": sum(results[f"att_g{c}"]["n_obs"] for c in cohorts),
    }
)

with open("result.json", "w") as f:
    json.dump(
        {
            "task_id": "broad_cohort_stack",
            "platform": "python",
            "estimates": estimates,
            "method_metadata": {},
            "diagnostics": {},
        },
        f,
        indent=2,
    )
