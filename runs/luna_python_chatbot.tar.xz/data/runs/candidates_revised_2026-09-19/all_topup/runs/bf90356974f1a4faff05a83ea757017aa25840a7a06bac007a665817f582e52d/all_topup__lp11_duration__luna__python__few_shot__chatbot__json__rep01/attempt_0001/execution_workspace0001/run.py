import csv
import json
import math


INPUT_FILE = "input.csv"
OUTPUT_FILE = "result.json"
TASK_ID = "lp11_duration"


def logsumexp(values):
    maximum = max(values)
    return maximum + math.log(sum(math.exp(value - maximum) for value in values))


def log_combination(n, k):
    if k < 0 or k > n:
        return float("-inf")
    return (
        math.lgamma(n + 1)
        - math.lgamma(k + 1)
        - math.lgamma(n - k + 1)
    )


def parse_int(value):
    return int(float(value))


def is_cohort_zero(value):
    try:
        return float(value) == 0.0
    except ValueError:
        return str(value).strip() == "0"


with open(INPUT_FILE, newline="") as file:
    rows = list(csv.DictReader(file))

for row in rows:
    row["training"] = parse_int(row["training"])
    row["end_month"] = parse_int(row["end_month"])
    row["event"] = parse_int(row["event"])

risk_sets = []

cohorts = sorted(set(row["cohort"] for row in rows))
for cohort in cohorts:
    cohort_rows = [row for row in rows if row["cohort"] == cohort]
    maximum_month = max(row["end_month"] for row in cohort_rows)

    for month in range(1, maximum_month + 1):
        risk = [row for row in cohort_rows if row["end_month"] >= month]
        exits = [
            row for row in risk
            if row["event"] == 1 and row["end_month"] == month
        ]

        if exits:
            n_training = sum(row["training"] for row in risk)
            n_untrained = len(risk) - n_training
            d = len(exits)
            observed_sum = sum(row["training"] for row in exits)

            terms = []
            feasible_low = max(0, d - n_untrained)
            feasible_high = min(d, n_training)

            for k in range(feasible_low, feasible_high + 1):
                terms.append(
                    log_combination(n_training, k)
                    + log_combination(n_untrained, d - k)
                )

            risk_sets.append(
                {
                    "n_training": n_training,
                    "n_untrained": n_untrained,
                    "d": d,
                    "observed_sum": observed_sum,
                    "denominator_terms": terms,
                }
            )


def contribution(beta, risk_set):
    denominator = logsumexp(
        beta * k + log_count
        for k, log_count in enumerate_denominator_terms(risk_set)
    )
    return beta * risk_set["observed_sum"] - denominator


def enumerate_denominator_terms(risk_set):
    n_training = risk_set["n_training"]
    n_untrained = risk_set["n_untrained"]
    d = risk_set["d"]

    feasible_low = max(0, d - n_untrained)
    feasible_high = min(d, n_training)

    for k in range(feasible_low, feasible_high + 1):
        yield k, (
            log_combination(n_training, k)
            + log_combination(n_untrained, d - k)
        )


def log_likelihood(beta):
    return sum(contribution(beta, risk_set) for risk_set in risk_sets)


def score(beta):
    total = 0.0

    for risk_set in risk_sets:
        weighted_terms = []
        for k, log_count in enumerate_denominator_terms(risk_set):
            weighted_terms.append((k, beta * k + log_count))

        denominator = logsumexp(value for _, value in weighted_terms)
        expected_sum = sum(
            k * math.exp(value - denominator)
            for k, value in weighted_terms
        )
        total += risk_set["observed_sum"] - expected_sum

    return total


lower = -4.0
upper = 4.0
score_lower = score(lower)
score_upper = score(upper)

if score_lower <= 0:
    beta = lower
elif score_upper >= 0:
    beta = upper
else:
    for _ in range(200):
        midpoint = (lower + upper) / 2.0
        if score(midpoint) > 0:
            lower = midpoint
        else:
            upper = midpoint
    beta = (lower + upper) / 2.0

fitted_log_likelihood = log_likelihood(beta)
conditional_odds_ratio = math.exp(beta)

first_cohort_rows = [
    row for row in rows
    if is_cohort_zero(row["cohort"])
]
first_risk = [
    row for row in first_cohort_rows
    if row["end_month"] >= 1
]
first_exits = [
    row for row in first_risk
    if row["event"] == 1 and row["end_month"] == 1
]

if not first_exits:
    raise ValueError("No exits found for cohort 0 in month 1.")

first_d = len(first_exits)
first_observed_sum = sum(row["training"] for row in first_exits)
first_n_training = sum(row["training"] for row in first_risk)
first_n_untrained = len(first_risk) - first_n_training

first_denominator_terms = []
first_low = max(0, first_d - first_n_untrained)
first_high = min(first_d, first_n_training)

for k in range(first_low, first_high + 1):
    first_denominator_terms.append(
        beta * k
        + log_combination(first_n_training, k)
        + log_combination(first_n_untrained, first_d - k)
    )

first_denominator_log = logsumexp(first_denominator_terms)
first_event_set_log_probability = (
    beta * first_observed_sum - first_denominator_log
)
first_event_set_probability = math.exp(first_event_set_log_probability)

estimates = [
    {
        "term": "training_coefficient",
        "estimate": beta,
        "se": None,
        "n_obs": len(rows),
    },
    {
        "term": "conditional_odds_ratio",
        "estimate": conditional_odds_ratio,
        "se": None,
        "n_obs": len(rows),
    },
    {
        "term": "log_likelihood",
        "estimate": fitted_log_likelihood,
        "se": None,
        "n_obs": len(rows),
    },
    {
        "term": "first_event_set_probability",
        "estimate": first_event_set_probability,
        "se": None,
        "n_obs": len(rows),
    },
    {
        "term": "first_event_set_log_probability",
        "estimate": first_event_set_log_probability,
        "se": None,
        "n_obs": len(rows),
    },
]

result = {
    "task_id": TASK_ID,
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "model": "Cox discrete-time conditional odds model",
        "optimization_interval": [-4, 4],
        "risk_set_unit": "cohort-month",
        "denominator": "exact enumeration by training-count combinations",
        "same_month_censoring_rule": "censoring is excluded from the next month",
    },
    "diagnostics": {
        "sample_count": len(rows),
        "risk_sets_with_exits": len(risk_sets),
        "first_event_count": first_d,
        "first_risk_set_count": len(first_risk),
    },
}

with open(OUTPUT_FILE, "w") as file:
    json.dump(result, file, indent=2, allow_nan=False)
