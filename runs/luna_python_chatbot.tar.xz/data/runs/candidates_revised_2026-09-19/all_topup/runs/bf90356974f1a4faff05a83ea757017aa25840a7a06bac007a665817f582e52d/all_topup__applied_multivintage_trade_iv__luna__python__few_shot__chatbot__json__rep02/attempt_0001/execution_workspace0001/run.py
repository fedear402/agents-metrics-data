import json
from pathlib import Path

import numpy as np
import pandas as pd


def read_csv(name):
    return pd.read_csv(Path(name))


crosswalk = read_csv("crosswalk.csv")
trade = read_csv("trade.csv")
areas = read_csv("areas.csv")
employment = read_csv("employment.csv")
outcomes = read_csv("outcomes.csv")

trade = trade.merge(crosswalk, on="code", how="inner")

base_areas = areas.loc[areas["vintage"].eq("base")].copy()
early_areas = areas.loc[areas["vintage"].eq("early")].copy()

base_emp = employment.loc[employment["vintage"].eq("base")].copy()
early_emp = employment.loc[employment["vintage"].eq("early")].copy()

industries = sorted(crosswalk["industry"].unique())

def make_exposure(area, period, vintage, area_table, employment_table, change_col):
    area_info = area_table[
        (area_table["area"] == area) & (area_table["period"] == period)
    ].iloc[0]

    total_employment = float(area_info["total_employment"])
    period_trade = trade[trade["period"] == period].set_index("industry")
    national = (
        employment_table[employment_table["period"] == period]
        .groupby("industry")["employment"]
        .sum()
    )
    local = employment_table[
        (employment_table["area"] == area)
        & (employment_table["period"] == period)
    ].groupby("industry")["employment"].sum()

    exposure = 0.0
    price_index = float(period_trade["price_index"].iloc[0])
    years = float(period_trade["years"].iloc[0])

    for industry in industries:
        area_employment = float(local.get(industry, 0.0))
        national_employment = float(national.get(industry, 0.0))
        trade_row = period_trade.loc[industry]
        trade_change = float(trade_row[change_col])

        exposure += (
            (area_employment / total_employment)
            * (trade_change / national_employment)
            / (price_index / 100.0)
            / 1000.0
            * (10.0 / years)
        )

    return exposure


rows = []
for _, area_row in base_areas.iterrows():
    area = area_row["area"]
    period = area_row["period"]

    rows.append(
        {
            "area": area,
            "period": period,
            "population": float(area_row["population"]),
            "x": make_exposure(
                area, period, "base", base_areas, base_emp, "us_change"
            ),
            "z": make_exposure(
                area, period, "early", early_areas, early_emp, "other_change"
            ),
        }
    )

design = pd.DataFrame(rows)
design = design.merge(
    outcomes[["area", "period", "control", "change_pp"]],
    on=["area", "period"],
    how="inner",
)

period_values = sorted(design["period"].unique())
if len(period_values) != 2:
    raise ValueError("Expected exactly two periods.")

period_numeric = pd.to_numeric(design["period"], errors="coerce")
if period_numeric.isna().any():
    period_codes = pd.Categorical(
        design["period"], categories=period_values, ordered=True
    ).codes.astype(float)
else:
    period_codes = period_numeric.to_numpy(dtype=float)

y = design["change_pp"].to_numpy(dtype=float)
x = design["x"].to_numpy(dtype=float)
z = design["z"].to_numpy(dtype=float)
control = design["control"].to_numpy(dtype=float)
weights = design["population"].to_numpy(dtype=float)

X = np.column_stack(
    [
        np.ones(len(design), dtype=float),
        period_codes,
        control,
        x,
    ]
)
W = np.column_stack(
    [
        np.ones(len(design), dtype=float),
        period_codes,
        control,
        z,
    ]
)

sqrt_weights = np.sqrt(weights)
Xw = X * sqrt_weights[:, None]
Ww = W * sqrt_weights[:, None]
yw = y * sqrt_weights

middle = Ww.T @ Ww
projection_terms = np.linalg.solve(middle, Ww.T @ Xw)
projected_x = Ww @ projection_terms

beta = np.linalg.solve(
    Xw.T @ projected_x,
    projected_x.T @ yw,
)

area0 = design[design["area"] == 0].set_index("period")

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "iv_slope",
            "estimate": float(beta[3]),
            "se": None,
            "n_obs": 72,
        },
        {
            "term": "exposure_area0_period0",
            "estimate": float(area0.loc[0, "x"]),
            "se": None,
            "n_obs": 72,
        },
        {
            "term": "exposure_area0_period1",
            "estimate": float(area0.loc[1, "x"]),
            "se": None,
            "n_obs": 72,
        },
        {
            "term": "instrument_area0_period0",
            "estimate": float(area0.loc[0, "z"]),
            "se": None,
            "n_obs": 72,
        },
    ],
    "method_metadata": {
        "estimator": "weighted_two_stage_least_squares",
        "dependent_variable": "change_pp",
        "endogenous_variable": "x",
        "instrument": "z",
        "exogenous_variables": ["intercept", "period", "control"],
        "weight_variable": "base_vintage_population",
        "missing_area_industry_employment": "zero",
        "sample_definition": "all_area_period_observations",
    },
    "diagnostics": {
        "n_obs": 72,
        "n_regressors": 4,
        "n_instruments": 4,
    },
}

with open("result.json", "w", encoding="utf-8") as output_file:
    json.dump(result, output_file, indent=2, allow_nan=False)
