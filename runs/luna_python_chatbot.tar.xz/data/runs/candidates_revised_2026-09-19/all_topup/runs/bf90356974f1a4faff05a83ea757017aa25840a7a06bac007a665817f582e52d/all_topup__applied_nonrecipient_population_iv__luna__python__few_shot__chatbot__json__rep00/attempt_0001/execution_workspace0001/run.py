import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
from linearmodels.iv import IV2SLS

households = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

d = households.loc[households["recipient"] == 0].copy()
d["dose_ineligible"] = d["dose"] * (1 - d["eligible"])
d["dose_eligible"] = d["dose"] * d["eligible"]
d["baseline_ineligible"] = d["baseline"] * (1 - d["eligible"])
d["baseline_eligible"] = d["baseline"] * d["eligible"]
d["instrument_ineligible"] = d["instrument"] * (1 - d["eligible"])
d["instrument_eligible"] = d["instrument"] * d["eligible"]

exog_cols = [
    "ineligible",
    "eligible",
    "baseline_ineligible",
    "baseline_eligible",
]

d["ineligible"] = 1 - d["eligible"]

endog_cols = ["dose_ineligible", "dose_eligible"]
excluded_instrument_cols = ["instrument_ineligible", "instrument_eligible"]

fit = IV2SLS(
    dependent=d["outcome"],
    exog=d[exog_cols],
    endog=d[endog_cols],
    instruments=d[excluded_instrument_cols],
    weights=d["weight"],
).fit()

ineligible_slope = float(fit.params["dose_ineligible"])
eligible_slope = float(fit.params["dose_eligible"])

ineligible_rows = d["eligible"] == 0
eligible_rows = d["eligible"] == 1

ineligible_mean_dose = float(
    np.average(
        d.loc[ineligible_rows, "dose"],
        weights=d.loc[ineligible_rows, "weight"],
    )
)
eligible_mean_dose = float(
    np.average(
        d.loc[eligible_rows, "dose"],
        weights=d.loc[eligible_rows, "weight"],
    )
)

ineligible_effect = ineligible_slope * ineligible_mean_dose
eligible_nonrecipient_effect = eligible_slope * eligible_mean_dose

population_weights = (
    census.groupby("eligible", as_index=True)["nonrecipient_population"].sum()
)
population_effect = float(
    np.average(
        [ineligible_effect, eligible_nonrecipient_effect],
        weights=[
            population_weights.loc[0],
            population_weights.loc[1],
        ],
    )
)

n_obs = int(len(d))

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "ineligible_effect",
            "estimate": float(ineligible_effect),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "eligible_nonrecipient_effect",
            "estimate": float(eligible_nonrecipient_effect),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "population_effect",
            "estimate": float(population_effect),
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "weighted_2sls",
        "counterfactual": "dose set to zero for every retained household",
        "retained_sample": "recipient == 0",
        "exogenous_columns": exog_cols,
        "endogenous_columns": endog_cols,
        "instrument_columns": exog_cols + excluded_instrument_cols,
        "weight_column": "weight",
        "population_weight_column": "nonrecipient_population",
        "group_effect_definition": "dose slope times household-weighted mean dose",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "n_ineligible": int(ineligible_rows.sum()),
        "n_eligible_nonrecipient": int(eligible_rows.sum()),
        "census_ineligible_population": int(population_weights.loc[0]),
        "census_eligible_population": int(population_weights.loc[1]),
    },
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2)
