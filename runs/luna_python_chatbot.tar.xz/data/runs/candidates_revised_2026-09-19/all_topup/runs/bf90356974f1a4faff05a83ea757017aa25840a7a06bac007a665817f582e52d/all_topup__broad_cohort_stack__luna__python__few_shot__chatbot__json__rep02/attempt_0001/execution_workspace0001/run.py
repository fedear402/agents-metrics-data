import csv
import json
import numpy as np

with open("input.csv", newline="") as stream:
    rows = list(csv.DictReader(stream))

records = [
    {
        "id": row["id"],
        "time": int(row["time"]),
        "g": int(row["g"]),
        "y": float(row["y"]),
    }
    for row in rows
]

estimates = []
comparison_counts = []

for cohort in (3, 5, 7):
    window = set(range(cohort - 2, cohort + 3))

    units = {}
    for row in records:
        units.setdefault(row["id"], []).append(row)

    retained_ids = []
    for unit_id, unit_rows in units.items():
        adoption = unit_rows[0]["g"]
        eligible = adoption == cohort or adoption == 0 or adoption > cohort + 2
        observed_times = {row["time"] for row in unit_rows}
        if eligible and window.issubset(observed_times):
            retained_ids.append(unit_id)

    retained = [
        row for row in records
        if row["id"] in retained_ids and row["time"] in window
    ]

    ids = sorted({row["id"] for row in retained}, key=str)
    times = sorted(window)

    did = np.array(
        [
            1.0 if row["g"] == cohort and row["time"] >= cohort else 0.0
            for row in retained
        ]
    )
    outcome = np.array([row["y"] for row in retained], dtype=float)

    design_parts = [np.ones(len(retained)), did]

    for unit_id in ids[1:]:
        design_parts.append(
            np.array([1.0 if row["id"] == unit_id else 0.0 for row in retained])
        )

    for time in times[1:]:
        design_parts.append(
            np.array([1.0 if row["time"] == time else 0.0 for row in retained])
        )

    design = np.column_stack(design_parts)
    coefficient = float(np.linalg.lstsq(design, outcome, rcond=None)[0][1])

    treated_count = sum(
        1 for unit_id in retained_ids
        if units[unit_id][0]["g"] == cohort
    )
    row_count = len(retained)

    estimates.append(
        {
            "term": f"att_g{cohort}",
            "estimate": coefficient,
            "se": None,
            "n_obs": row_count,
        }
    )
    comparison_counts.append((coefficient, treated_count, row_count))

weighted_numerator = sum(
    coefficient * treated_count
    for coefficient, treated_count, _ in comparison_counts
)
weight_total = sum(
    treated_count for _, treated_count, _ in comparison_counts
)
weighted_effect = weighted_numerator / weight_total

estimates.append(
    {
        "term": "att_weighted",
        "estimate": float(weighted_effect),
        "se": None,
        "n_obs": sum(row_count for _, _, row_count in comparison_counts),
    }
)

output = {
    "task_id": "broad_cohort_stack",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {},
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
