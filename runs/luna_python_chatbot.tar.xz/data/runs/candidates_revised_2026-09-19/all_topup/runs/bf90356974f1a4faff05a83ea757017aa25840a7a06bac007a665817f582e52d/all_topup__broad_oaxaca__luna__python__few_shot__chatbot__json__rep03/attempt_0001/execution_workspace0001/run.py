import csv
import json
import numpy as np

with open("./input.csv", newline="") as stream:
    rows = list(csv.DictReader(stream))

y = np.array([float(row["y"]) for row in rows], dtype=float)
x = np.array([float(row["x"]) for row in rows], dtype=float)
z = np.array([float(row["z"]) for row in rows], dtype=float)
group = np.array([int(row["group"]) for row in rows], dtype=int)

mask0 = group == 0
mask1 = group == 1

X = np.column_stack([np.ones(len(rows)), x, z])
X0 = X[mask0]
X1 = X[mask1]
y0 = y[mask0]
y1 = y[mask1]

beta0 = np.linalg.lstsq(X0, y0, rcond=None)[0]
beta1 = np.linalg.lstsq(X1, y1, rcond=None)[0]

Xbar0 = X0.mean(axis=0)
Xbar1 = X1.mean(axis=0)

gap = y1.mean() - y0.mean()
explained = (Xbar1 - Xbar0) @ beta0
unexplained = Xbar1 @ (beta1 - beta0)
explained_x = (x[mask1].mean() - x[mask0].mean()) * beta0[1]

output = {
    "task_id": "broad_oaxaca",
    "platform": "python",
    "estimates": [
        {
            "term": "gap",
            "estimate": float(gap),
            "se": None,
            "n_obs": len(rows)
        },
        {
            "term": "explained",
            "estimate": float(explained),
            "se": None,
            "n_obs": len(rows)
        },
        {
            "term": "unexplained",
            "estimate": float(unexplained),
            "se": None,
            "n_obs": len(rows)
        },
        {
            "term": "explained_x",
            "estimate": float(explained_x),
            "se": None,
            "n_obs": len(rows)
        }
    ],
    "method_metadata": {},
    "diagnostics": {}
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
