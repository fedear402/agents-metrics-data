import json
import numpy as np
import pandas as pd

households = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

retained = households.loc[households["recipient"] == 0].copy()
n_obs = int(len(retained))

eligible = retained["eligible"].to_numpy(dtype=float)
ineligible = 1.0 - eligible
dose = retained["dose"].to_numpy(dtype=float)
instrument = retained["instrument"].to_numpy(dtype=float)
baseline = retained["baseline"].to_numpy(dtype=float)
outcome = retained["outcome"].to_numpy(dtype=float)
weight = retained["weight"].to_numpy(dtype=float)

# Endogenous regressors.
endogenous = np.column_stack([
    dose * ineligible,
    dose * eligible,
])

# Exogenous regressors, with no intercept.
exogenous = np.column_stack([
    ineligible,
    eligible,
    baseline * ineligible,
    baseline * eligible,
])

# Instruments: exogenous regressors plus the two excluded interactions.
instruments = np.column_stack([
    exogenous,
    instrument * ineligible,
    instrument * eligible,
])

def weighted_projection(y, x, w):
    sqrt_w = np.sqrt(w)
    xw = x * sqrt_w[:, None]
    yw = y * sqrt_w
    coefficients = np.linalg.pinv(xw) @ yw
    return x @ coefficients

# First-stage fitted values for both endogenous regressors.
endogenous_fitted = np.column_stack([
    weighted_projection(endogenous[:, j], instruments, weight)
    for j in range(endogenous.shape[1])
])

# Second-stage weighted regression without an intercept.
second_stage_design = np.column_stack([
    exogenous,
    endogenous_fitted,
])

sqrt_w = np.sqrt(weight)
design_w = second_stage_design * sqrt_w[:, None]
outcome_w = outcome * sqrt_w
second_stage_coefficients = (
    np.linalg.pinv(design_w) @ outcome_w
)

ineligible_slope = float(second_stage_coefficients[4])
eligible_slope = float(second_stage_coefficients[5])

ineligible_mask = eligible == 0
eligible_mask = eligible == 1

ineligible_mean_dose = float(
    np.average(dose[ineligible_mask], weights=weight[ineligible_mask])
)
eligible_mean_dose = float(
    np.average(dose[eligible_mask], weights=weight[eligible_mask])
)

ineligible_effect = ineligible_slope * ineligible_mean_dose
eligible_nonrecipient_effect = eligible_slope * eligible_mean_dose

census_group_population = (
    census.groupby("eligible", as_index=True)["nonrecipient_population"]
    .sum()
)

ineligible_population = float(census_group_population.get(0, 0.0))
eligible_population = float(census_group_population.get(1, 0.0))
total_population = ineligible_population + eligible_population

population_effect = (
    (ineligible_population * ineligible_effect
     + eligible_population * eligible_nonrecipient_effect)
    / total_population
)

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "ineligible_effect",
            "estimate": float(ineligible_effect),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "eligible_nonrecipient_effect",
            "estimate": float(eligible_nonrecipient_effect),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "population_effect",
            "estimate": float(population_effect),
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "weighted_2sls",
        "endogenous_columns": [
            "dose*(1-eligible)",
            "dose*eligible",
        ],
        "exogenous_columns": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
        ],
        "instrument_columns": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
            "instrument*(1-eligible)",
            "instrument*eligible",
        ],
        "weight_column": "weight",
        "intercept": False,
        "retained_condition": "recipient == 0",
        "counterfactual": "dose = 0 for every retained household",
        "group_effect_convention": (
            "fitted dose slope multiplied by the household-weighted "
            "mean dose among retained observations"
        ),
        "population_aggregation": (
            "census nonrecipient_population determines final group weights only"
        ),
    },
    "diagnostics": {
        "n_obs": n_obs,
        "n_ineligible_retained": int(ineligible_mask.sum()),
        "n_eligible_retained": int(eligible_mask.sum()),
        "ineligible_mean_dose": ineligible_mean_dose,
        "eligible_mean_dose": eligible_mean_dose,
        "ineligible_dose_slope": ineligible_slope,
        "eligible_dose_slope": eligible_slope,
        "ineligible_population": ineligible_population,
        "eligible_population": eligible_population,
        "total_population": total_population,
    },
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file, indent=2, allow_nan=False)
