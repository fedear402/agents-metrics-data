import json
import numpy as np

data = np.genfromtxt("./input.csv", delimiter=",", names=True)

group0 = data["group"] == 0
group1 = data["group"] == 1

y0 = data["y"][group0]
y1 = data["y"][group1]
x0 = data["x"][group0]
x1 = data["x"][group1]
z0 = data["z"][group0]
z1 = data["z"][group1]

X0 = np.column_stack([np.ones(len(y0)), x0, z0])
X1 = np.column_stack([np.ones(len(y1)), x1, z1])

beta0 = np.linalg.lstsq(X0, y0, rcond=None)[0]
beta1 = np.linalg.lstsq(X1, y1, rcond=None)[0]

Xbar0 = X0.mean(axis=0)
Xbar1 = X1.mean(axis=0)

gap = y1.mean() - y0.mean()
explained = (Xbar1 - Xbar0) @ beta0
unexplained = Xbar1 @ (beta1 - beta0)
explained_x = (x1.mean() - x0.mean()) * beta0[1]

n_obs = len(data)

result = {
    "task_id": "broad_oaxaca",
    "platform": "python",
    "estimates": [
        {
            "term": "gap",
            "estimate": float(gap),
            "se": None,
            "n_obs": n_obs
        },
        {
            "term": "explained",
            "estimate": float(explained),
            "se": None,
            "n_obs": n_obs
        },
        {
            "term": "unexplained",
            "estimate": float(unexplained),
            "se": None,
            "n_obs": n_obs
        },
        {
            "term": "explained_x",
            "estimate": float(explained_x),
            "se": None,
            "n_obs": n_obs
        }
    ],
    "method_metadata": {},
    "diagnostics": {}
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
