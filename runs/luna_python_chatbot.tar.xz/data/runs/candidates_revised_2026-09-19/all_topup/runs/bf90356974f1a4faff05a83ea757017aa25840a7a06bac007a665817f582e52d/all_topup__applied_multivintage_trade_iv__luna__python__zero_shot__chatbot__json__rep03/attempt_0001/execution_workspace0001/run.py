import csv
import json
from collections import defaultdict
import numpy as np


def read_csv(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


crosswalk = read_csv("crosswalk.csv")
trade = read_csv("trade.csv")
areas = read_csv("areas.csv")
employment = read_csv("employment.csv")
outcomes = read_csv("outcomes.csv")

code_to_industry = {row["code"]: row["industry"] for row in crosswalk}

trade_by_period_industry = {}
for row in trade:
    period = row["period"]
    industry = code_to_industry[row["code"]]
    trade_by_period_industry[(period, industry)] = {
        "us_change": float(row["us_change"]),
        "other_change": float(row["other_change"]),
        "price_index": float(row["price_index"]),
        "years": float(row["years"]),
    }

area_period = {}
population_by_area_period = {}
total_employment = {}

for row in areas:
    area = row["area"]
    period = row["period"]
    vintage = row["vintage"]
    key = (area, period, vintage)
    total_employment[key] = float(row["total_employment"])
    if vintage == "base":
        population_by_area_period[(area, period)] = float(row["population"])
    area_period[(area, period)] = True

employment_by_key = defaultdict(float)
for row in employment:
    key = (
        row["area"],
        row["period"],
        row["vintage"],
        row["industry"],
    )
    employment_by_key[key] += float(row["employment"])

industries = sorted({row["industry"] for row in crosswalk})

national_employment = defaultdict(float)
for (area, period, vintage, industry), value in employment_by_key.items():
    national_employment[(period, vintage, industry)] += value

outcome_by_key = {}
for row in outcomes:
    outcome_by_key[(row["area"], row["period"])] = {
        "control": float(row["control"]),
        "change_pp": float(row["change_pp"]),
    }

periods = sorted(
    {period for _, period in area_period},
    key=lambda value: float(value)
)
period_numeric = {period: float(period) for period in periods}


def exposure(area, period, vintage, change_field):
    total = total_employment[(area, period, vintage)]
    trade_factor = trade_by_period_industry
    result = 0.0

    for industry in industries:
        employment_value = employment_by_key[
            (area, period, vintage, industry)
        ]
        national_value = national_employment[(period, vintage, industry)]
        trade_row = trade_factor[(period, industry)]

        result += (
            (employment_value / total)
            * (trade_row[change_field] / national_value)
            / (trade_row["price_index"] / 100.0)
            / 1000.0
            * (10.0 / trade_row["years"])
        )

    return result


rows = []
for area, period in sorted(
    area_period,
    key=lambda key: (float(key[1]), float(key[0]))
):
    outcome = outcome_by_key[(area, period)]
    rows.append(
        {
            "area": area,
            "period": period,
            "control": outcome["control"],
            "change_pp": outcome["change_pp"],
            "x": exposure(area, period, "base", "us_change"),
            "z": exposure(area, period, "early", "other_change"),
            "weight": population_by_area_period[(area, period)],
        }
    )

y = np.array([row["change_pp"] for row in rows], dtype=float)
x = np.array(
    [
        [1.0, period_numeric[row["period"]], row["control"], row["x"]]
        for row in rows
    ],
    dtype=float,
)
z = np.array(
    [
        [1.0, period_numeric[row["period"]], row["control"], row["z"]]
        for row in rows
    ],
    dtype=float,
)
weights = np.array([row["weight"] for row in rows], dtype=float)
sqrt_weights = np.sqrt(weights)

x_weighted = x * sqrt_weights[:, None]
z_weighted = z * sqrt_weights[:, None]
y_weighted = y * sqrt_weights

z_wxz = z_weighted.T @ z_weighted
z_wxy = z_weighted.T @ y_weighted
z_wxx = z_weighted.T @ x_weighted
z_wxy_reg = z_weighted.T @ x_weighted

projection_cross = z_wxx.T @ np.linalg.pinv(z_wxz) @ z_wxy_reg
projection_outcome = z_wxx.T @ np.linalg.pinv(z_wxz) @ z_wxy
beta = np.linalg.solve(projection_cross, projection_outcome)

area0_period0 = next(
    row["x"]
    for row in rows
    if row["area"] == "0" and row["period"] == "0"
)
area0_period1 = next(
    row["x"]
    for row in rows
    if row["area"] == "0" and row["period"] == "1"
)
instrument_area0_period0 = next(
    row["z"]
    for row in rows
    if row["area"] == "0" and row["period"] == "0"
)

n_obs = len(rows)

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "iv_slope",
            "estimate": float(beta[3]),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "exposure_area0_period0",
            "estimate": float(area0_period0),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "exposure_area0_period1",
            "estimate": float(area0_period1),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "instrument_area0_period0",
            "estimate": float(instrument_area0_period0),
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "weighted_two_stage_least_squares",
        "dependent_variable": "change_pp",
        "endogenous_variable": "x",
        "instrument": "z",
        "exogenous_instruments": [
            "intercept",
            "period",
            "control",
        ],
        "weight": "base-vintage population",
        "exposure_units": "thousands of real dollars per worker per decade",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "n_areas": len({row["area"] for row in rows}),
        "n_periods": len({row["period"] for row in rows}),
    },
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2)
