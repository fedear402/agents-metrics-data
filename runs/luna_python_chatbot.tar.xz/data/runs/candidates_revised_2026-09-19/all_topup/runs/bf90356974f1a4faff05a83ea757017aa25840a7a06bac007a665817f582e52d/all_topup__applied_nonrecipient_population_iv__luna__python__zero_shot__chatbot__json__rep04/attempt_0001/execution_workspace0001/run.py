import csv
import json
import os

import numpy as np


def read_csv(path):
    with open(path, newline="", encoding="utf-8") as file:
        return list(csv.DictReader(file))


households = read_csv("households.csv")
census = read_csv("census.csv")

retained = [
    row for row in households
    if int(float(row["recipient"])) == 0
]

n_obs = len(retained)

eligible = np.array([float(row["eligible"]) for row in retained], dtype=float)
ineligible = 1.0 - eligible
dose = np.array([float(row["dose"]) for row in retained], dtype=float)
instrument = np.array([float(row["instrument"]) for row in retained], dtype=float)
baseline = np.array([float(row["baseline"]) for row in retained], dtype=float)
weight = np.array([float(row["weight"]) for row in retained], dtype=float)
outcome = np.array([float(row["outcome"]) for row in retained], dtype=float)

# Endogenous regressors.
X = np.column_stack([
    dose * ineligible,
    dose * eligible,
    ineligible,
    eligible,
    baseline * ineligible,
    baseline * eligible,
])

# Instruments and included exogenous regressors.
Z = np.column_stack([
    ineligible,
    eligible,
    baseline * ineligible,
    baseline * eligible,
    instrument * ineligible,
    instrument * eligible,
])

# Weighted 2SLS, with no intercept.
sqrt_weight = np.sqrt(weight)
Z_weighted = Z * sqrt_weight[:, None]
X_weighted = X * sqrt_weight[:, None]
y_weighted = outcome * sqrt_weight

projection_coefficients = np.linalg.solve(
    Z_weighted.T @ Z_weighted,
    Z_weighted.T @ X_weighted,
)
X_hat_weighted = Z_weighted @ projection_coefficients

beta = np.linalg.solve(
    X_hat_weighted.T @ X_hat_weighted,
    X_hat_weighted.T @ y_weighted,
)

ineligible_slope = float(beta[0])
eligible_slope = float(beta[1])

ineligible_mean_dose = float(
    np.sum(weight * dose * ineligible) / np.sum(weight * ineligible)
)
eligible_mean_dose = float(
    np.sum(weight * dose * eligible) / np.sum(weight * eligible)
)

ineligible_effect = ineligible_slope * ineligible_mean_dose
eligible_nonrecipient_effect = eligible_slope * eligible_mean_dose

census_population = {0: 0, 1: 0}
for row in census:
    group = int(float(row["eligible"]))
    census_population[group] += int(float(row["nonrecipient_population"]))

total_population = census_population[0] + census_population[1]
population_effect = (
    census_population[0] * ineligible_effect
    + census_population[1] * eligible_nonrecipient_effect
) / total_population

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "ineligible_effect",
            "estimate": float(ineligible_effect),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "eligible_nonrecipient_effect",
            "estimate": float(eligible_nonrecipient_effect),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "population_effect",
            "estimate": float(population_effect),
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "weighted_2sls",
        "endogenous_columns": [
            "dose*(1-eligible)",
            "dose*eligible",
        ],
        "exogenous_columns": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
        ],
        "instrument_columns": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
            "instrument*(1-eligible)",
            "instrument*eligible",
        ],
        "intercept": False,
        "regression_weight": "weight",
        "retained_sample": "recipient == 0",
        "counterfactual": "dose set to zero for every retained household",
        "group_effect_definition": (
            "fitted dose slope times the household-weighted mean dose "
            "among retained observations in the group"
        ),
        "population_aggregation_weight": "census nonrecipient_population",
        "attribution_convention": (
            "synthetic attribution to a zero-dose counterfactual"
        ),
    },
    "diagnostics": {
        "n_obs": n_obs,
        "n_ineligible": int(np.sum(ineligible)),
        "n_eligible": int(np.sum(eligible)),
        "ineligible_census_population": int(census_population[0]),
        "eligible_census_population": int(census_population[1]),
    },
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file, indent=2, allow_nan=False)
