import json
import numpy as np
import pandas as pd

df = pd.read_csv("./input.csv")

estimates = []
cohort_results = []

for cohort in (3, 5, 7):
    window = list(range(cohort - 2, cohort + 3))
    eligible = (df["g"] == cohort) | (df["g"] == 0) | (df["g"] > cohort + 2)

    cohort_df = df.loc[
        eligible & df["time"].isin(window),
        ["id", "time", "g", "y"]
    ].copy()

    observed_counts = cohort_df.groupby("id")["time"].nunique()
    retained_ids = observed_counts[observed_counts == len(window)].index

    cohort_df = cohort_df[cohort_df["id"].isin(retained_ids)].copy()
    cohort_df["did"] = (
        (cohort_df["g"] == cohort) &
        (cohort_df["time"] >= cohort)
    ).astype(float)

    unit_dummies = pd.get_dummies(
        cohort_df["id"], drop_first=True, dtype=float
    )
    time_dummies = pd.get_dummies(
        cohort_df["time"], drop_first=True, dtype=float
    )

    design = np.column_stack([
        np.ones(len(cohort_df)),
        cohort_df["did"].to_numpy(dtype=float),
        unit_dummies.to_numpy(dtype=float),
        time_dummies.to_numpy(dtype=float),
    ])

    outcome = cohort_df["y"].to_numpy(dtype=float)
    coefficient = np.linalg.lstsq(design, outcome, rcond=None)[0][1]

    retained_treated = cohort_df.loc[
        cohort_df["g"] == cohort, "id"
    ].nunique()
    n_obs = len(cohort_df)

    cohort_results.append({
        "estimate": float(coefficient),
        "treated": int(retained_treated),
        "n_obs": int(n_obs),
    })

    estimates.append({
        "term": f"att_g{cohort}",
        "estimate": float(coefficient),
        "se": None,
        "n_obs": int(n_obs),
    })

total_treated = sum(result["treated"] for result in cohort_results)
weighted_effect = sum(
    result["estimate"] * result["treated"]
    for result in cohort_results
) / total_treated

estimates.append({
    "term": "att_weighted",
    "estimate": float(weighted_effect),
    "se": None,
    "n_obs": int(sum(result["n_obs"] for result in cohort_results)),
})

output = {
    "task_id": "broad_cohort_stack",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {},
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
