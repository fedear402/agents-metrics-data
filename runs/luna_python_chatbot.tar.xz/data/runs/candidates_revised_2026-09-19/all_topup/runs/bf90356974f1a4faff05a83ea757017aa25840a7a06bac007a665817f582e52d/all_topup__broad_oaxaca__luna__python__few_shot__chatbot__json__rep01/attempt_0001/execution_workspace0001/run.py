import csv
import json
import numpy as np

with open("input.csv", newline="") as stream:
    rows = list(csv.DictReader(stream))

y = np.array([float(row["y"]) for row in rows], dtype=float)
x = np.array([float(row["x"]) for row in rows], dtype=float)
z = np.array([float(row["z"]) for row in rows], dtype=float)
group = np.array([int(row["group"]) for row in rows], dtype=int)

def fit_group(g):
    mask = group == g
    X = np.column_stack([
        np.ones(mask.sum(), dtype=float),
        x[mask],
        z[mask],
    ])
    beta = np.linalg.lstsq(X, y[mask], rcond=None)[0]
    xbar = X.mean(axis=0)
    return beta, xbar

beta0, xbar0 = fit_group(0)
beta1, xbar1 = fit_group(1)

gap = y[group == 1].mean() - y[group == 0].mean()
explained = (xbar1 - xbar0) @ beta0
unexplained = xbar1 @ (beta1 - beta0)
explained_x = (x[group == 1].mean() - x[group == 0].mean()) * beta0[1]

n_obs = len(rows)

result = {
    "task_id": "broad_oaxaca",
    "platform": "python",
    "estimates": [
        {
            "term": "gap",
            "estimate": float(gap),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "explained",
            "estimate": float(explained),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "unexplained",
            "estimate": float(unexplained),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "explained_x",
            "estimate": float(explained_x),
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {},
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
