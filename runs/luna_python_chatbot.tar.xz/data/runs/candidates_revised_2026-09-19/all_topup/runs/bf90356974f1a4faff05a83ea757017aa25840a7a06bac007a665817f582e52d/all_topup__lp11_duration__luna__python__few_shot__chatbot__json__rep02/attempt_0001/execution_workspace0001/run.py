import csv
import json
import math
from collections import defaultdict
from scipy.optimize import minimize_scalar


def read_input(path):
    rows = []
    with open(path, newline="") as f:
        for row in csv.DictReader(f):
            rows.append(
                {
                    "cohort": row["cohort"],
                    "worker": row["worker"],
                    "training": int(row["training"]),
                    "end_month": int(float(row["end_month"])),
                    "event": int(row["event"]),
                }
            )
    return rows


def log_elementary_symmetric(training_values, degree, beta):
    neg_inf = float("-inf")
    log_dp = [neg_inf] * (degree + 1)
    log_dp[0] = 0.0

    for training in training_values:
        log_weight = beta * training
        upper = min(degree, len(training_values))
        for k in range(upper, 0, -1):
            log_dp[k] = math.logaddexp(
                log_dp[k], log_dp[k - 1] + log_weight
            )

    return log_dp[degree]


def build_contributions(rows):
    by_cohort = defaultdict(list)
    for row in rows:
        by_cohort[row["cohort"]].append(row)

    contributions = []
    for cohort_rows in by_cohort.values():
        max_month = max(row["end_month"] for row in cohort_rows)

        for month in range(1, max_month + 1):
            risk = [
                row for row in cohort_rows
                if row["end_month"] >= month
            ]
            exits = [
                row for row in risk
                if row["event"] == 1 and row["end_month"] == month
            ]

            if exits:
                contributions.append(
                    (
                        [row["training"] for row in risk],
                        len(exits),
                        sum(row["training"] for row in exits),
                    )
                )

    return contributions


def log_likelihood(beta, contributions):
    value = 0.0
    for training_values, exit_count, observed_sum in contributions:
        denominator = log_elementary_symmetric(
            training_values, exit_count, beta
        )
        value += beta * observed_sum - denominator
    return float(value)


def main():
    rows = read_input("input.csv")
    contributions = build_contributions(rows)

    fit = minimize_scalar(
        lambda beta: -log_likelihood(beta, contributions),
        bounds=(-4.0, 4.0),
        method="bounded",
        options={"xatol": 1e-14},
    )

    beta = float(fit.x)
    fitted_log_likelihood = log_likelihood(beta, contributions)

    target_rows = [
        row for row in rows
        if str(row["cohort"]) == "0"
        and row["end_month"] == 1
        and row["event"] == 1
    ]

    target_risk = [
        row for row in rows
        if str(row["cohort"]) == "0"
        and row["end_month"] >= 1
    ]

    if not target_rows or not target_risk:
        raise ValueError(
            "Cohort 0, month 1 must contain at least one observed exit."
        )

    target_exit_count = len(target_rows)
    target_observed_sum = sum(row["training"] for row in target_rows)
    target_denominator = log_elementary_symmetric(
        [row["training"] for row in target_risk],
        target_exit_count,
        beta,
    )
    first_event_set_log_probability = (
        beta * target_observed_sum - target_denominator
    )
    first_event_set_probability = math.exp(
        first_event_set_log_probability
    )

    estimates = [
        {
            "term": "training_coefficient",
            "estimate": beta,
            "se": None,
            "n_obs": len(rows),
        },
        {
            "term": "conditional_odds_ratio",
            "estimate": math.exp(beta),
            "se": None,
            "n_obs": len(rows),
        },
        {
            "term": "log_likelihood",
            "estimate": fitted_log_likelihood,
            "se": None,
            "n_obs": len(rows),
        },
        {
            "term": "first_event_set_probability",
            "estimate": first_event_set_probability,
            "se": None,
            "n_obs": len(rows),
        },
        {
            "term": "first_event_set_log_probability",
            "estimate": first_event_set_log_probability,
            "se": None,
            "n_obs": len(rows),
        },
    ]

    result = {
        "task_id": "lp11_duration",
        "platform": "python",
        "estimates": estimates,
        "method_metadata": {
            "model": "Cox discrete-time conditional odds model",
            "estimation": "Exact elementary symmetric polynomial recursion",
            "optimization_bounds": [-4.0, 4.0],
            "conditional_odds_ratio_definition": (
                "exp(training_coefficient)"
            ),
            "first_event_set_definition": (
                "Probability of the named observed exit set in cohort 0, "
                "month 1, conditional on its exit count"
            ),
        },
        "diagnostics": {
            "converged": bool(fit.success),
            "optimizer_message": str(fit.message),
            "risk_set_contribution_count": len(contributions),
            "sample_count": len(rows),
        },
    }

    with open("result.json", "w") as f:
        json.dump(result, f, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
