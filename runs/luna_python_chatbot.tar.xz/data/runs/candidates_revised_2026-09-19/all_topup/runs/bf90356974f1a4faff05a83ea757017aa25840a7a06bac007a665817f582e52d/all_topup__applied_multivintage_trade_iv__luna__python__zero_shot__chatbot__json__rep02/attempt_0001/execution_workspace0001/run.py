import csv
import json
from pathlib import Path

import numpy as np


def read_csv(name):
    with open(Path.cwd() / name, newline="", encoding="utf-8") as file:
        return list(csv.DictReader(file))


crosswalk = read_csv("crosswalk.csv")
trade = read_csv("trade.csv")
areas = read_csv("areas.csv")
employment = read_csv("employment.csv")
outcomes = read_csv("outcomes.csv")

code_to_industry = {row["code"]: row["industry"] for row in crosswalk}

trade_by_period = {}
for row in trade:
    period = row["period"]
    trade_by_period.setdefault(period, {})[code_to_industry[row["code"]]] = {
        "us_change": float(row["us_change"]),
        "other_change": float(row["other_change"]),
        "price_index": float(row["price_index"]),
        "years": float(row["years"]),
    }

area_rows = {}
population = {}
for row in areas:
    area = row["area"]
    period = row["period"]
    vintage = row["vintage"]
    area_rows.setdefault((area, period), {})[vintage] = {
        "total_employment": float(row["total_employment"]),
        "population": float(row["population"]),
    }
    if vintage == "base":
        population[(area, period)] = float(row["population"])

employment_by_key = {}
for row in employment:
    key = (row["area"], row["period"], row["vintage"], row["industry"])
    employment_by_key[key] = float(row["employment"])

outcome_by_key = {}
for row in outcomes:
    outcome_by_key[(row["area"], row["period"])] = {
        "control": float(row["control"]),
        "change_pp": float(row["change_pp"]),
    }

industries = sorted(code_to_industry.values(), key=str)
periods = list(dict.fromkeys(row["period"] for row in outcomes))

national = {}
for period in periods:
    for vintage in ("base", "early"):
        for industry in industries:
            national[(period, vintage, industry)] = sum(
                employment_by_key.get((area, period, vintage, industry), 0.0)
                for area, p in area_rows
                if p == period
            )

def period_value(period):
    try:
        return float(period)
    except ValueError:
        return float(periods.index(period))

rows = []
for area, period in outcome_by_key:
    area_data = area_rows[(area, period)]
    trade_data = trade_by_period[period]
    price_index = next(iter(trade_data.values()))["price_index"]
    years = next(iter(trade_data.values()))["years"]

    x = 0.0
    z = 0.0
    for industry in industries:
        base_area = employment_by_key.get((area, period, "base", industry), 0.0)
        early_area = employment_by_key.get((area, period, "early", industry), 0.0)

        base_national = national[(period, "base", industry)]
        early_national = national[(period, "early", industry)]

        us_change = next(
            value["us_change"]
            for code, value in trade_data.items()
            if code_to_industry[code] == industry
        )
        other_change = next(
            value["other_change"]
            for code, value in trade_data.items()
            if code_to_industry[code] == industry
        )

        x += (
            (base_area / area_data["base"]["total_employment"])
            * (us_change / base_national)
            / (price_index / 100.0)
            / 1000.0
            * (10.0 / years)
        )
        z += (
            (early_area / area_data["early"]["total_employment"])
            * (other_change / early_national)
            / (price_index / 100.0)
            / 1000.0
            * (10.0 / years)
        )

    outcome = outcome_by_key[(area, period)]
    rows.append({
        "area": area,
        "period": period,
        "period_value": period_value(period),
        "control": outcome["control"],
        "y": outcome["change_pp"],
        "x": x,
        "z": z,
        "weight": population[(area, period)],
    })

n_obs = len(rows)

y = np.array([row["y"] for row in rows], dtype=float)
x = np.array([
    [1.0, row["period_value"], row["control"], row["x"]]
    for row in rows
], dtype=float)
z = np.array([
    [1.0, row["period_value"], row["control"], row["z"]]
    for row in rows
], dtype=float)
weights = np.array([row["weight"] for row in rows], dtype=float)
sqrt_weights = np.sqrt(weights)

yw = y * sqrt_weights
xw = x * sqrt_weights[:, None]
zw = z * sqrt_weights[:, None]

ztz_inv = np.linalg.pinv(zw.T @ zw)
iv_normal = xw.T @ zw @ ztz_inv @ zw.T @ xw
iv_rhs = xw.T @ zw @ ztz_inv @ zw.T @ yw
beta = np.linalg.pinv(iv_normal) @ iv_rhs

area0_candidates = [row for row in rows if str(row["area"]) == "0"]
area0_period0 = next(row["x"] for row in area0_candidates if str(row["period"]) == "0")
area0_period1 = next(row["x"] for row in area0_candidates if str(row["period"]) == "1")
instrument_area0_period0 = next(
    row["z"] for row in area0_candidates if str(row["period"]) == "0"
)

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "iv_slope",
            "estimate": float(beta[3]),
            "se": None,
            "n_obs": 72,
        },
        {
            "term": "exposure_area0_period0",
            "estimate": float(area0_period0),
            "se": None,
            "n_obs": 72,
        },
        {
            "term": "exposure_area0_period1",
            "estimate": float(area0_period1),
            "se": None,
            "n_obs": 72,
        },
        {
            "term": "instrument_area0_period0",
            "estimate": float(instrument_area0_period0),
            "se": None,
            "n_obs": 72,
        },
    ],
    "method_metadata": {
        "estimator": "weighted_two_stage_least_squares",
        "outcome": "change_pp",
        "endogenous_regressor": "x",
        "instrument": "z",
        "exogenous_regressors": ["intercept", "period", "control"],
        "weight": "base-vintage population",
        "exposure_units": "thousands of real dollars per worker per decade",
    },
    "diagnostics": {
        "n_obs": 72,
        "sample_count": n_obs,
    },
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file, indent=2)
