import json
import numpy as np
import pandas as pd

data = pd.read_csv("./input.csv")

estimates = []
comparison_results = []

for cohort in (3, 5, 7):
    window_times = set(range(cohort - 2, cohort + 3))

    eligible = (
        (data["g"] == cohort)
        | (data["g"] == 0)
        | (data["g"] > cohort + 2)
    )

    eligible_data = data.loc[eligible & data["time"].isin(window_times)].copy()

    complete_units = (
        eligible_data.groupby("id")["time"]
        .nunique()
        .loc[lambda s: s == len(window_times)]
        .index
    )

    comparison = eligible_data[eligible_data["id"].isin(complete_units)].copy()
    comparison["did"] = (
        (comparison["g"] == cohort)
        & (comparison["time"] >= cohort)
    ).astype(float)

    unit_dummies = pd.get_dummies(
        comparison["id"], drop_first=True, dtype=float
    )
    time_dummies = pd.get_dummies(
        comparison["time"], drop_first=True, dtype=float
    )

    design = np.column_stack([
        np.ones(len(comparison)),
        comparison["did"].to_numpy(dtype=float),
        unit_dummies.to_numpy(dtype=float),
        time_dummies.to_numpy(dtype=float),
    ])

    outcome = comparison["y"].to_numpy(dtype=float)
    coefficient = np.linalg.lstsq(design, outcome, rcond=None)[0][1]

    retained_treated = comparison.loc[
        comparison["g"] == cohort, "id"
    ].nunique()

    comparison_results.append({
        "cohort": cohort,
        "estimate": float(coefficient),
        "n_obs": int(len(comparison)),
        "retained_treated": int(retained_treated),
    })

for result in comparison_results:
    estimates.append({
        "term": f"att_g{result['cohort']}",
        "estimate": result["estimate"],
        "se": None,
        "n_obs": result["n_obs"],
    })

total_treated = sum(
    result["retained_treated"] for result in comparison_results
)
weighted_effect = sum(
    result["estimate"] * result["retained_treated"]
    for result in comparison_results
) / total_treated

estimates.append({
    "term": "att_weighted",
    "estimate": float(weighted_effect),
    "se": None,
    "n_obs": sum(result["n_obs"] for result in comparison_results),
})

output = {
    "task_id": "broad_cohort_stack",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {},
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
