import json
from pathlib import Path

import numpy as np
import pandas as pd


def read_csv(name):
    return pd.read_csv(Path.cwd() / name)


crosswalk = read_csv("crosswalk.csv")
trade = read_csv("trade.csv")
areas = read_csv("areas.csv")
employment = read_csv("employment.csv")
outcomes = read_csv("outcomes.csv")

trade = trade.merge(crosswalk, on="code", how="inner")

area_periods = areas[["area", "period"]].drop_duplicates()
industries = crosswalk["industry"].drop_duplicates().tolist()
vintages = ["base", "early"]

grid = (
    area_periods.assign(key=1)
    .merge(pd.DataFrame({"industry": industries, "key": 1}), on="key")
    .merge(pd.DataFrame({"vintage": vintages, "key": 1}), on="key")
    .drop(columns="key")
)

employment_full = grid.merge(
    employment,
    on=["area", "period", "industry", "vintage"],
    how="left",
)
employment_full["employment"] = employment_full["employment"].fillna(0.0)

national = (
    employment_full.groupby(["period", "vintage", "industry"], as_index=False)
    ["employment"]
    .sum()
    .rename(columns={"employment": "national_employment"})
)

employment_full = employment_full.merge(
    national,
    on=["period", "vintage", "industry"],
    how="left",
)

area_meta = areas.pivot_table(
    index=["area", "period"],
    columns="vintage",
    values="total_employment",
    aggfunc="first",
).reset_index()

area_meta.columns.name = None
area_meta = area_meta.rename(
    columns={"base": "base_total_employment", "early": "early_total_employment"}
)

trade_cols = [
    "period",
    "industry",
    "us_change",
    "other_change",
    "price_index",
    "years",
]
trade_period_industry = trade[trade_cols].drop_duplicates(
    ["period", "industry"]
)

employment_full = employment_full.merge(
    trade_period_industry,
    on=["period", "industry"],
    how="left",
)

employment_full["base_component"] = (
    employment_full["employment"]
    / employment_full["national_employment"]
    * employment_full["us_change"]
)
employment_full["early_component"] = (
    employment_full["employment"]
    / employment_full["national_employment"]
    * employment_full["other_change"]
)

exposure_components = (
    employment_full.groupby(["area", "period", "vintage"], as_index=False)
    [["base_component", "early_component", "price_index", "years"]]
    .first()
)

employment_sums = (
    employment_full.groupby(["area", "period", "vintage"], as_index=False)
    [["base_component", "early_component"]]
    .sum()
)

exposure_components = exposure_components.drop(
    columns=["base_component", "early_component"]
).merge(
    employment_sums,
    on=["area", "period", "vintage"],
    how="left",
)

exposure_components["exposure"] = np.where(
    exposure_components["vintage"].eq("base"),
    exposure_components["base_component"],
    exposure_components["early_component"],
)
exposure_components["exposure"] = (
    exposure_components["exposure"]
    / exposure_components["price_index"].div(100)
    / 1000
    * (10 / exposure_components["years"])
)

exposures = (
    exposure_components.pivot_table(
        index=["area", "period"],
        columns="vintage",
        values="exposure",
        aggfunc="first",
    )
    .reset_index()
    .rename(columns={"base": "x", "early": "z"})
)

data = (
    area_meta.merge(exposures, on=["area", "period"], how="inner")
    .merge(outcomes, on=["area", "period"], how="inner")
)

period_numeric = pd.to_numeric(data["period"], errors="coerce")
if period_numeric.isna().any():
    period_numeric = pd.Series(
        pd.Categorical(data["period"]).codes,
        index=data.index,
        dtype=float,
    )

X = np.column_stack(
    [
        np.ones(len(data)),
        period_numeric.to_numpy(dtype=float),
        data["control"].to_numpy(dtype=float),
        data["x"].to_numpy(dtype=float),
    ]
)
Z = np.column_stack(
    [
        np.ones(len(data)),
        period_numeric.to_numpy(dtype=float),
        data["control"].to_numpy(dtype=float),
        data["z"].to_numpy(dtype=float),
    ]
)
y = data["change_pp"].to_numpy(dtype=float)
weights = data["population"].to_numpy(dtype=float)
sqrt_weights = np.sqrt(weights)

Z_w = Z * sqrt_weights[:, None]
X_w = X * sqrt_weights[:, None]
y_w = y * sqrt_weights

X_hat_w = Z_w @ np.linalg.lstsq(Z_w, X_w, rcond=None)[0]
beta = np.linalg.lstsq(X_hat_w, y_w, rcond=None)[0]
iv_slope = float(beta[3])

def value_for_area_period(column, area_value, period_value):
    rows = data[
        data["area"].astype(str).eq(str(area_value))
        & data["period"].astype(str).eq(str(period_value))
    ]
    return float(rows.iloc[0][column])

n_obs = int(len(data))

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "iv_slope",
            "estimate": iv_slope,
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "exposure_area0_period0",
            "estimate": value_for_area_period("x", 0, 0),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "exposure_area0_period1",
            "estimate": value_for_area_period("x", 0, 1),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "instrument_area0_period0",
            "estimate": value_for_area_period("z", 0, 0),
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "weighted_2sls",
        "dependent_variable": "change_pp",
        "endogenous_variable": "x",
        "instrument": "z",
        "exogenous_variables": ["intercept", "period", "control"],
        "weight": "base-vintage population",
        "n_obs": n_obs,
    },
    "diagnostics": {
        "sample_count": n_obs,
        "expected_sample_count": 72,
    },
}

with open(Path.cwd() / "result.json", "w", encoding="utf-8") as handle:
    json.dump(result, handle, indent=2, allow_nan=False)
