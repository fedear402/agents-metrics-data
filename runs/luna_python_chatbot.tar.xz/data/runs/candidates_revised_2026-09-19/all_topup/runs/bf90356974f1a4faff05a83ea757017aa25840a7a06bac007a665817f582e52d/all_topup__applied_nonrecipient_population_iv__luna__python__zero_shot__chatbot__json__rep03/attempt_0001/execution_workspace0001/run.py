import csv
import json
import numpy as np


def read_csv(path):
    with open(path, newline="", encoding="utf-8") as file:
        return list(csv.DictReader(file))


households = read_csv("households.csv")
census = read_csv("census.csv")

retained = [row for row in households if int(row["recipient"]) == 0]
n_obs = len(retained)

eligible = np.array([float(row["eligible"]) for row in retained])
dose = np.array([float(row["dose"]) for row in retained])
instrument = np.array([float(row["instrument"]) for row in retained])
baseline = np.array([float(row["baseline"]) for row in retained])
weight = np.array([float(row["weight"]) for row in retained])
outcome = np.array([float(row["outcome"]) for row in retained])

ineligible = 1.0 - eligible

endogenous = np.column_stack([
    dose * ineligible,
    dose * eligible,
])

exogenous = np.column_stack([
    ineligible,
    eligible,
    baseline * ineligible,
    baseline * eligible,
])

instruments = np.column_stack([
    ineligible,
    eligible,
    baseline * ineligible,
    baseline * eligible,
    instrument * ineligible,
    instrument * eligible,
])

sqrt_weight = np.sqrt(weight)
z_weighted = instruments * sqrt_weight[:, None]
x_weighted = endogenous * sqrt_weight[:, None]
y_weighted = outcome * sqrt_weight

first_stage_projection = (
    z_weighted
    @ np.linalg.pinv(z_weighted.T @ z_weighted)
    @ z_weighted.T
)
fitted_endogenous_weighted = first_stage_projection @ x_weighted
fitted_endogenous = fitted_endogenous_weighted / sqrt_weight[:, None]

second_stage_design = np.column_stack([
    exogenous,
    fitted_endogenous,
])
second_stage_weighted = second_stage_design * sqrt_weight[:, None]

coefficients = np.linalg.pinv(
    second_stage_weighted.T @ second_stage_weighted
) @ (
    second_stage_weighted.T @ y_weighted
)

ineligible_slope = coefficients[4]
eligible_slope = coefficients[5]

ineligible_mask = eligible == 0
eligible_mask = eligible == 1

ineligible_mean_dose = np.average(
    dose[ineligible_mask],
    weights=weight[ineligible_mask],
)
eligible_mean_dose = np.average(
    dose[eligible_mask],
    weights=weight[eligible_mask],
)

ineligible_effect = ineligible_slope * ineligible_mean_dose
eligible_nonrecipient_effect = eligible_slope * eligible_mean_dose

census_population = {0: 0.0, 1: 0.0}
for row in census:
    group = int(row["eligible"])
    census_population[group] += float(row["nonrecipient_population"])

total_population = census_population[0] + census_population[1]
population_effect = (
    census_population[0] / total_population * ineligible_effect
    + census_population[1] / total_population * eligible_nonrecipient_effect
)

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "ineligible_effect",
            "estimate": float(ineligible_effect),
            "se": None,
            "n_obs": int(n_obs),
        },
        {
            "term": "eligible_nonrecipient_effect",
            "estimate": float(eligible_nonrecipient_effect),
            "se": None,
            "n_obs": int(n_obs),
        },
        {
            "term": "population_effect",
            "estimate": float(population_effect),
            "se": None,
            "n_obs": int(n_obs),
        },
    ],
    "method_metadata": {
        "estimator": "weighted_2sls",
        "endogenous_columns": [
            "dose*(1-eligible)",
            "dose*eligible",
        ],
        "exogenous_columns": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
        ],
        "instrument_columns": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
            "instrument*(1-eligible)",
            "instrument*eligible",
        ],
        "intercept": False,
        "weight_column": "weight",
        "retained_condition": "recipient == 0",
        "counterfactual": "dose set to zero for every retained household",
        "group_effect_definition": "fitted dose slope times household-weighted mean dose",
        "population_aggregation_weight": "census nonrecipient_population",
        "synthetic_attribution_convention": True,
    },
    "diagnostics": {
        "n_obs": int(n_obs),
        "n_ineligible": int(np.sum(ineligible_mask)),
        "n_eligible_nonrecipient": int(np.sum(eligible_mask)),
        "census_ineligible_population": int(census_population[0]),
        "census_eligible_population": int(census_population[1]),
        "census_total_population": int(total_population),
    },
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file, indent=2, allow_nan=False)
