import csv
import json
import os
import numpy as np


def read_csv(name):
    with open(name, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def as_float(value):
    return float(value)


crosswalk_rows = read_csv("crosswalk.csv")
trade_rows = read_csv("trade.csv")
area_rows = read_csv("areas.csv")
employment_rows = read_csv("employment.csv")
outcome_rows = read_csv("outcomes.csv")

code_to_industry = {
    row["code"]: row["industry"] for row in crosswalk_rows
}

industries = sorted({row["industry"] for row in crosswalk_rows})
periods = sorted({row["period"] for row in outcome_rows})

trade = {}
for row in trade_rows:
    industry = code_to_industry[row["code"]]
    trade[(row["period"], industry)] = {
        "us_change": as_float(row["us_change"]),
        "other_change": as_float(row["other_change"]),
        "price_index": as_float(row["price_index"]),
        "years": as_float(row["years"]),
    }

area_info = {}
for row in area_rows:
    key = (row["area"], row["period"], row["vintage"])
    area_info[key] = {
        "total_employment": as_float(row["total_employment"]),
        "population": as_float(row["population"]),
    }

employment = {}
for row in employment_rows:
    employment[
        (row["area"], row["period"], row["vintage"], row["industry"])
    ] = as_float(row["employment"])

national = {}
for period in periods:
    for vintage in ("base", "early"):
        for industry in industries:
            total = 0.0
            for row in area_rows:
                if row["period"] == period and row["vintage"] == vintage:
                    total += employment.get(
                        (row["area"], period, vintage, industry), 0.0
                    )
            national[(period, vintage, industry)] = total

def period_value(period):
    try:
        return float(period)
    except ValueError:
        return float(periods.index(period))


rows = []
for outcome in outcome_rows:
    area = outcome["area"]
    period = outcome["period"]

    base_area = area_info[(area, period, "base")]
    early_area = area_info[(area, period, "early")]

    x = 0.0
    z = 0.0

    trade_info = {
        industry: trade[(period, industry)]
        for industry in industries
    }

    for industry in industries:
        base_emp = employment.get(
            (area, period, "base", industry), 0.0
        )
        early_emp = employment.get(
            (area, period, "early", industry), 0.0
        )

        base_national_emp = national[(period, "base", industry)]
        early_national_emp = national[(period, "early", industry)]

        t = trade_info[industry]
        scale = 1.0 / (t["price_index"] / 100.0) / 1000.0
        decade = 10.0 / t["years"]

        x += (
            (base_emp / base_area["total_employment"])
            * (t["us_change"] / base_national_emp)
            * scale
            * decade
        )

        z += (
            (early_emp / early_area["total_employment"])
            * (t["other_change"] / early_national_emp)
            * scale
            * decade
        )

    rows.append({
        "area": area,
        "period": period,
        "period_value": period_value(period),
        "control": as_float(outcome["control"]),
        "change_pp": as_float(outcome["change_pp"]),
        "x": x,
        "z": z,
        "weight": base_area["population"],
    })

y = np.array([row["change_pp"] for row in rows], dtype=float)
period_col = np.array([row["period_value"] for row in rows], dtype=float)
control = np.array([row["control"] for row in rows], dtype=float)
x = np.array([row["x"] for row in rows], dtype=float)
z = np.array([row["z"] for row in rows], dtype=float)
weights = np.array([row["weight"] for row in rows], dtype=float)

X = np.column_stack([np.ones(len(rows)), period_col, control, x])
Z = np.column_stack([np.ones(len(rows)), period_col, control, z])

sqrt_w = np.sqrt(weights)
X_w = X * sqrt_w[:, None]
Z_w = Z * sqrt_w[:, None]
y_w = y * sqrt_w

first_stage_projection = Z_w @ np.linalg.pinv(Z_w)
X_hat_w = first_stage_projection @ X_w

beta = np.linalg.pinv(X_hat_w.T @ X_hat_w) @ (X_hat_w.T @ y_w)
iv_slope = float(beta[3])

area0_period0 = next(
    row["x"] for row in rows
    if row["area"] == "0" and row["period"] == "0"
)
area0_period1 = next(
    row["x"] for row in rows
    if row["area"] == "0" and row["period"] == "1"
)
instrument_area0_period0 = next(
    row["z"] for row in rows
    if row["area"] == "0" and row["period"] == "0"
)

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "iv_slope",
            "estimate": iv_slope,
            "se": None,
            "n_obs": 72,
        },
        {
            "term": "exposure_area0_period0",
            "estimate": float(area0_period0),
            "se": None,
            "n_obs": 72,
        },
        {
            "term": "exposure_area0_period1",
            "estimate": float(area0_period1),
            "se": None,
            "n_obs": 72,
        },
        {
            "term": "instrument_area0_period0",
            "estimate": float(instrument_area0_period0),
            "se": None,
            "n_obs": 72,
        },
    ],
    "method_metadata": {
        "estimator": "weighted_two_stage_least_squares",
        "outcome": "change_pp",
        "endogenous_regressor": "x",
        "excluded_instrument": "z",
        "exogenous_instruments": ["intercept", "period", "control"],
        "weight": "base-vintage population",
        "sample_definition": "all area-period estimation rows",
    },
    "diagnostics": {
        "n_obs": 72,
        "n_industries": 4,
    },
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, allow_nan=False)
