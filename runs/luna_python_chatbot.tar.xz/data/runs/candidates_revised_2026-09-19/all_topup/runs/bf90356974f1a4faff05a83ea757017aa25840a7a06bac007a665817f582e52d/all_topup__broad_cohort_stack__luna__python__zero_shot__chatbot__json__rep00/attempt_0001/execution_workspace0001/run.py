import csv
import json
import numpy as np

with open("input.csv", newline="") as f:
    rows = list(csv.DictReader(f))

for row in rows:
    row["id"] = row["id"]
    row["time"] = int(row["time"])
    row["g"] = int(row["g"])
    row["y"] = float(row["y"])

def estimate_cohort(cohort):
    window = set(range(cohort - 2, cohort + 3))

    eligible_rows = [
        r for r in rows
        if r["time"] in window
        and (r["g"] == cohort or r["g"] == 0 or r["g"] > cohort + 2)
    ]

    required_times = window
    times_by_unit = {}
    for r in eligible_rows:
        times_by_unit.setdefault(r["id"], set()).add(r["time"])

    retained_units = {
        unit for unit, observed_times in times_by_unit.items()
        if observed_times == required_times
    }

    retained = [
        r for r in eligible_rows
        if r["id"] in retained_units
    ]

    unit_levels = sorted(retained_units)
    time_levels = sorted(window)

    unit_base = unit_levels[0]
    time_base = time_levels[0]

    X = []
    y = []

    for r in retained:
        row_x = [1.0]

        row_x.extend(
            1.0 if r["id"] == unit else 0.0
            for unit in unit_levels[1:]
        )

        row_x.extend(
            1.0 if r["time"] == time else 0.0
            for time in time_levels[1:]
        )

        did = 1.0 if r["g"] == cohort and r["time"] >= cohort else 0.0
        row_x.append(did)

        X.append(row_x)
        y.append(r["y"])

    coefficients = np.linalg.lstsq(
        np.asarray(X, dtype=float),
        np.asarray(y, dtype=float),
        rcond=None
    )[0]

    treated_units = {
        r["id"] for r in retained if r["g"] == cohort
    }

    did_coefficient = float(coefficients[-1])
    n_obs = len(retained)
    n_treated = len(treated_units)

    return did_coefficient, n_obs, n_treated

results = {}
for cohort in (3, 5, 7):
    results[cohort] = estimate_cohort(cohort)

weighted_estimate = sum(
    results[c][0] * results[c][2] for c in (3, 5, 7)
) / sum(
    results[c][2] for c in (3, 5, 7)
)

estimates = [
    {
        "term": "att_g3",
        "estimate": results[3][0],
        "se": None,
        "n_obs": results[3][1]
    },
    {
        "term": "att_g5",
        "estimate": results[5][0],
        "se": None,
        "n_obs": results[5][1]
    },
    {
        "term": "att_g7",
        "estimate": results[7][0],
        "se": None,
        "n_obs": results[7][1]
    },
    {
        "term": "att_weighted",
        "estimate": weighted_estimate,
        "se": None,
        "n_obs": sum(results[c][1] for c in (3, 5, 7))
    }
]

with open("result.json", "w") as f:
    json.dump(
        {
            "task_id": "broad_cohort_stack",
            "platform": "python",
            "estimates": estimates,
            "method_metadata": {},
            "diagnostics": {}
        },
        f,
        indent=2
    )
