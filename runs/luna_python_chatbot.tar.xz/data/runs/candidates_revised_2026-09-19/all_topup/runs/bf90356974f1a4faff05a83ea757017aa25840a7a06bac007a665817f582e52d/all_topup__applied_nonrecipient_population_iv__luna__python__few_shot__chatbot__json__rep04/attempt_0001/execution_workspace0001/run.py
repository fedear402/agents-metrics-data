import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
from linearmodels.iv import IV2SLS

households = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

d = households.loc[households["recipient"] == 0].copy()
d["ineligible"] = 1 - d["eligible"]
d["dose_ineligible"] = d["dose"] * d["ineligible"]
d["dose_eligible"] = d["dose"] * d["eligible"]
d["baseline_ineligible"] = d["baseline"] * d["ineligible"]
d["baseline_eligible"] = d["baseline"] * d["eligible"]
d["instrument_ineligible"] = d["instrument"] * d["ineligible"]
d["instrument_eligible"] = d["instrument"] * d["eligible"]

exog = d[
    [
        "ineligible",
        "eligible",
        "baseline_ineligible",
        "baseline_eligible",
    ]
]
endog = d[["dose_ineligible", "dose_eligible"]]
instruments = d[["instrument_ineligible", "instrument_eligible"]]

fit = IV2SLS(
    dependent=d["outcome"],
    exog=exog,
    endog=endog,
    instruments=instruments,
    weights=d["weight"],
).fit()

slope_ineligible = float(fit.params["dose_ineligible"])
slope_eligible = float(fit.params["dose_eligible"])

ineligible = d["eligible"] == 0
eligible = d["eligible"] == 1

mean_dose_ineligible = float(
    np.average(d.loc[ineligible, "dose"], weights=d.loc[ineligible, "weight"])
)
mean_dose_eligible = float(
    np.average(d.loc[eligible, "dose"], weights=d.loc[eligible, "weight"])
)

ineligible_effect = slope_ineligible * mean_dose_ineligible
eligible_nonrecipient_effect = slope_eligible * mean_dose_eligible

population_counts = (
    census.groupby("eligible", as_index=True)["nonrecipient_population"].sum()
)
population_effect = float(
    np.average(
        [ineligible_effect, eligible_nonrecipient_effect],
        weights=[
            population_counts.loc[0],
            population_counts.loc[1],
        ],
    )
)

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "ineligible_effect",
            "estimate": float(ineligible_effect),
            "se": None,
            "n_obs": int(len(d)),
        },
        {
            "term": "eligible_nonrecipient_effect",
            "estimate": float(eligible_nonrecipient_effect),
            "se": None,
            "n_obs": int(len(d)),
        },
        {
            "term": "population_effect",
            "estimate": float(population_effect),
            "se": None,
            "n_obs": int(len(d)),
        },
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "dependent_variable": "outcome",
        "endogenous_columns": [
            "dose*(1-eligible)",
            "dose*eligible",
        ],
        "exogenous_columns": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
        ],
        "excluded_instruments": [
            "instrument*(1-eligible)",
            "instrument*eligible",
        ],
        "weight_column": "weight",
        "sample_definition": "households with recipient=0",
        "counterfactual": "dose=0 for every retained household",
        "attribution_convention": "synthetic zero-dose counterfactual",
        "group_effect_definition": "fitted dose slope times household-weighted mean dose",
        "population_weight_source": "census nonrecipient_population",
    },
    "diagnostics": {
        "n_obs": int(len(d)),
        "n_ineligible": int(ineligible.sum()),
        "n_eligible_nonrecipient": int(eligible.sum()),
        "ineligible_population": int(population_counts.loc[0]),
        "eligible_nonrecipient_population": int(population_counts.loc[1]),
        "ineligible_slope": float(slope_ineligible),
        "eligible_nonrecipient_slope": float(slope_eligible),
        "ineligible_weighted_mean_dose": float(mean_dose_ineligible),
        "eligible_nonrecipient_weighted_mean_dose": float(mean_dose_eligible),
    },
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, allow_nan=False)
