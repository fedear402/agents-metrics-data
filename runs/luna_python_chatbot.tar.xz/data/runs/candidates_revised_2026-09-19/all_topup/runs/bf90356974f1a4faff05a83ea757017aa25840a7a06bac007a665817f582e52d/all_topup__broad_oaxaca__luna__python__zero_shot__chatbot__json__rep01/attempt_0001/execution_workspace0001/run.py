import csv
import json
import numpy as np

with open("input.csv", newline="") as f:
    rows = list(csv.DictReader(f))

y = np.array([float(row["y"]) for row in rows], dtype=float)
x = np.array([float(row["x"]) for row in rows], dtype=float)
z = np.array([float(row["z"]) for row in rows], dtype=float)
group = np.array([int(float(row["group"])) for row in rows], dtype=int)

def fit_ols(mask):
    design = np.column_stack([
        np.ones(mask.sum()),
        x[mask],
        z[mask],
    ])
    return np.linalg.lstsq(design, y[mask], rcond=None)[0]

mask0 = group == 0
mask1 = group == 1

beta0 = fit_ols(mask0)
beta1 = fit_ols(mask1)

xbar0 = np.array([1.0, x[mask0].mean(), z[mask0].mean()])
xbar1 = np.array([1.0, x[mask1].mean(), z[mask1].mean()])

gap = y[mask1].mean() - y[mask0].mean()
explained = np.dot(xbar1 - xbar0, beta0)
unexplained = np.dot(xbar1, beta1 - beta0)
explained_x = (x[mask1].mean() - x[mask0].mean()) * beta0[1]

result = {
    "task_id": "broad_oaxaca",
    "platform": "python",
    "estimates": [
        {
            "term": "gap",
            "estimate": float(gap),
            "se": None,
            "n_obs": len(rows)
        },
        {
            "term": "explained",
            "estimate": float(explained),
            "se": None,
            "n_obs": len(rows)
        },
        {
            "term": "unexplained",
            "estimate": float(unexplained),
            "se": None,
            "n_obs": len(rows)
        },
        {
            "term": "explained_x",
            "estimate": float(explained_x),
            "se": None,
            "n_obs": len(rows)
        }
    ],
    "method_metadata": {},
    "diagnostics": {}
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
