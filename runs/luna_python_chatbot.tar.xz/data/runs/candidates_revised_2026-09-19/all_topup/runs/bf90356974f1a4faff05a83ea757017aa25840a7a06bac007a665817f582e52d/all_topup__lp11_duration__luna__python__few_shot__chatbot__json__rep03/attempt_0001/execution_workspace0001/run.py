import csv
import json
import math
from collections import defaultdict

import numpy as np
from scipy.optimize import minimize_scalar
from scipy.special import logsumexp


TASK_ID = "lp11_duration"
INPUT_FILE = "input.csv"
OUTPUT_FILE = "result.json"


def log_combination(n, k):
    if k < 0 or k > n:
        return -np.inf
    return math.lgamma(n + 1) - math.lgamma(k + 1) - math.lgamma(n - k + 1)


def subset_log_denominator(beta, n_training, n_untrained, d):
    terms = []
    for k in range(d + 1):
        if k <= n_training and d - k <= n_untrained:
            terms.append(
                log_combination(n_training, k)
                + log_combination(n_untrained, d - k)
                + beta * k
            )
    return float(logsumexp(terms))


def read_data(path):
    with open(path, newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))

    data = []
    for row in rows:
        data.append(
            {
                "cohort": row["cohort"],
                "worker": row["worker"],
                "training": int(row["training"]),
                "end_month": int(row["end_month"]),
                "event": int(row["event"]),
            }
        )
    return data


def build_contributions(data):
    cohorts = defaultdict(list)
    for row in data:
        cohorts[row["cohort"]].append(row)

    contributions = []

    for cohort, workers in cohorts.items():
        months = sorted({row["end_month"] for row in workers if row["event"] == 1})

        for month in months:
            risk_set = [
                row for row in workers
                if row["end_month"] >= month
            ]
            exits = [
                row for row in risk_set
                if row["event"] == 1 and row["end_month"] == month
            ]

            d = len(exits)
            if d == 0:
                continue

            n_training = sum(row["training"] for row in risk_set)
            n_untrained = len(risk_set) - n_training
            observed_sum = sum(row["training"] for row in exits)

            contributions.append(
                {
                    "cohort": cohort,
                    "month": month,
                    "d": d,
                    "n_training": n_training,
                    "n_untrained": n_untrained,
                    "observed_sum": observed_sum,
                    "exit_workers": exits,
                }
            )

    return contributions


def log_likelihood(beta, contributions):
    total = 0.0
    for item in contributions:
        denominator = subset_log_denominator(
            beta,
            item["n_training"],
            item["n_untrained"],
            item["d"],
        )
        total += beta * item["observed_sum"] - denominator
    return float(total)


def main():
    data = read_data(INPUT_FILE)
    contributions = build_contributions(data)

    fit = minimize_scalar(
        lambda beta: -log_likelihood(beta, contributions),
        bounds=(-4.0, 4.0),
        method="bounded",
        options={"xatol": 1e-14},
    )

    beta = float(fit.x)
    ll = log_likelihood(beta, contributions)

    first_event = None
    for item in contributions:
        if str(item["cohort"]) == "0" and item["month"] == 1:
            first_event = item
            break

    if first_event is None:
        raise ValueError("No exits found for cohort 0 in month 1.")

    first_log_probability = (
        beta * first_event["observed_sum"]
        - subset_log_denominator(
            beta,
            first_event["n_training"],
            first_event["n_untrained"],
            first_event["d"],
        )
    )
    first_probability = float(math.exp(first_log_probability))

    n_obs = len(data)

    estimates = [
        {
            "term": "training_coefficient",
            "estimate": beta,
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "conditional_odds_ratio",
            "estimate": float(math.exp(beta)),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "log_likelihood",
            "estimate": ll,
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "first_event_set_probability",
            "estimate": first_probability,
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "first_event_set_log_probability",
            "estimate": float(first_log_probability),
            "se": None,
            "n_obs": n_obs,
        },
    ]

    result = {
        "task_id": TASK_ID,
        "platform": "python",
        "estimates": estimates,
        "method_metadata": {
            "model": "Cox discrete-time conditional odds model",
            "covariate": "training",
            "risk_set_unit": "cohort-month",
            "denominator": "exact elementary symmetric polynomial",
            "optimization_interval": [-4, 4],
            "probability_definition": (
                "Probability of the named observed exit set conditional on its exit count"
            ),
        },
        "diagnostics": {
            "optimizer_success": bool(fit.success),
            "optimizer_message": str(fit.message),
            "n_cohorts": len({row["cohort"] for row in data}),
            "n_contributing_cohort_months": len(contributions),
        },
    }

    with open(OUTPUT_FILE, "w", encoding="utf-8") as handle:
        json.dump(result, handle, indent=2)


if __name__ == "__main__":
    main()
