import json
import numpy as np
import pandas as pd

data = pd.read_csv("./input.csv")

cohorts = [3, 5, 7]
results = []
weighted_sum = 0.0
total_treated = 0
total_rows = 0

for cohort in cohorts:
    window_times = list(range(cohort - 2, cohort + 3))

    eligible = (
        (data["g"] == cohort)
        | (data["g"] == 0)
        | (data["g"] > cohort + 2)
    )

    window = data[
        eligible & data["time"].isin(window_times)
    ].copy()

    complete_ids = (
        window.groupby("id")["time"]
        .nunique()
        .loc[lambda s: s == len(window_times)]
        .index
    )

    comparison = window[window["id"].isin(complete_ids)].copy()
    comparison["did"] = (
        (comparison["g"] == cohort)
        & (comparison["time"] >= cohort)
    ).astype(float)

    unit_dummies = pd.get_dummies(
        comparison["id"], drop_first=True, dtype=float
    )
    time_dummies = pd.get_dummies(
        comparison["time"], drop_first=True, dtype=float
    )

    design = np.column_stack(
        [
            np.ones(len(comparison)),
            comparison["did"].to_numpy(dtype=float),
            unit_dummies.to_numpy(dtype=float),
            time_dummies.to_numpy(dtype=float),
        ]
    )

    outcome = comparison["y"].to_numpy(dtype=float)
    coefficient = np.linalg.lstsq(design, outcome, rcond=None)[0][1]

    retained_treated = comparison.loc[
        comparison["g"] == cohort, "id"
    ].nunique()
    n_rows = len(comparison)

    results.append(
        {
            "term": f"att_g{cohort}",
            "estimate": float(coefficient),
            "se": None,
            "n_obs": int(n_rows),
        }
    )

    weighted_sum += coefficient * retained_treated
    total_treated += retained_treated
    total_rows += n_rows

weighted_effect = weighted_sum / total_treated

results.append(
    {
        "term": "att_weighted",
        "estimate": float(weighted_effect),
        "se": None,
        "n_obs": int(total_rows),
    }
)

output = {
    "task_id": "broad_cohort_stack",
    "platform": "python",
    "estimates": results,
    "method_metadata": {},
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
