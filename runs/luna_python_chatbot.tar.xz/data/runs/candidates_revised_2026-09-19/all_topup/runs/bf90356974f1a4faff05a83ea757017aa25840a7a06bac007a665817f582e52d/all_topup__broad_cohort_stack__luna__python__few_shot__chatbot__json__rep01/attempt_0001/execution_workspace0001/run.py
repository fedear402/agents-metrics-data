import json
import numpy as np
import pandas as pd

df = pd.read_csv("./input.csv")

estimates = []
cohort_results = []

for cohort in (3, 5, 7):
    window = list(range(cohort - 2, cohort + 3))

    eligible = (
        (df["g"] == cohort)
        | (df["g"] == 0)
        | (df["g"] > cohort + 2)
    )

    subset = df.loc[
        eligible & df["time"].isin(window),
        ["id", "time", "g", "y"],
    ].copy()

    complete_ids = (
        subset.groupby("id")["time"]
        .nunique()
        .loc[lambda s: s == len(window)]
        .index
    )

    subset = subset[subset["id"].isin(complete_ids)].copy()
    subset["did"] = (
        (subset["g"] == cohort) & (subset["time"] >= cohort)
    ).astype(float)

    design_parts = [
        np.ones((len(subset), 1)),
        subset[["did"]].to_numpy(dtype=float),
        pd.get_dummies(
            subset["id"],
            drop_first=True,
            dtype=float,
        ).to_numpy(),
        pd.get_dummies(
            subset["time"],
            drop_first=True,
            dtype=float,
        ).to_numpy(),
    ]
    design = np.column_stack(design_parts)

    coefficients = np.linalg.lstsq(
        design,
        subset["y"].to_numpy(dtype=float),
        rcond=None,
    )[0]

    estimate = float(coefficients[1])
    n_obs = int(len(subset))
    retained_treated = int((subset["g"] == cohort).sum() // len(window))

    estimates.append(
        {
            "term": f"att_g{cohort}",
            "estimate": estimate,
            "se": None,
            "n_obs": n_obs,
        }
    )
    cohort_results.append(
        {
            "estimate": estimate,
            "n_obs": n_obs,
            "retained_treated": retained_treated,
        }
    )

total_treated = sum(
    result["retained_treated"] for result in cohort_results
)
weighted_estimate = sum(
    result["estimate"] * result["retained_treated"]
    for result in cohort_results
) / total_treated

estimates.append(
    {
        "term": "att_weighted",
        "estimate": float(weighted_estimate),
        "se": None,
        "n_obs": int(sum(result["n_obs"] for result in cohort_results)),
    }
)

result = {
    "task_id": "broad_cohort_stack",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {},
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
