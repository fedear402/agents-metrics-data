import json
from pathlib import Path

import numpy as np
import pandas as pd


def weighted_2sls(y, x, z, weights):
    sqrt_w = np.sqrt(np.asarray(weights, dtype=float))
    yw = np.asarray(y, dtype=float) * sqrt_w
    xw = np.asarray(x, dtype=float) * sqrt_w[:, None]
    zw = np.asarray(z, dtype=float) * sqrt_w[:, None]

    ztz_inv = np.linalg.pinv(zw.T @ zw)
    middle = xw.T @ zw @ ztz_inv @ zw.T @ xw
    rhs = xw.T @ zw @ ztz_inv @ zw.T @ yw

    return np.linalg.pinv(middle) @ rhs


households = pd.read_csv(Path("households.csv"))
census = pd.read_csv(Path("census.csv"))

retained = households.loc[households["recipient"] == 0].copy()
retained["ineligible"] = 1 - retained["eligible"]
retained["dose_ineligible"] = retained["dose"] * retained["ineligible"]
retained["dose_eligible"] = retained["dose"] * retained["eligible"]
retained["baseline_ineligible"] = retained["baseline"] * retained["ineligible"]
retained["baseline_eligible"] = retained["baseline"] * retained["eligible"]
retained["instrument_ineligible"] = retained["instrument"] * retained["ineligible"]
retained["instrument_eligible"] = retained["instrument"] * retained["eligible"]

exog_columns = [
    "ineligible",
    "eligible",
    "baseline_ineligible",
    "baseline_eligible",
]
endog_columns = [
    "dose_ineligible",
    "dose_eligible",
]
instrument_columns = exog_columns + [
    "instrument_ineligible",
    "instrument_eligible",
]

y = retained["outcome"].to_numpy(dtype=float)
x = retained[exog_columns + endog_columns].to_numpy(dtype=float)
z = retained[instrument_columns].to_numpy(dtype=float)
weights = retained["weight"].to_numpy(dtype=float)

beta = weighted_2sls(y, x, z, weights)

ineligible_slope = float(beta[x.shape[1] - 2])
eligible_slope = float(beta[x.shape[1] - 1])

ineligible_rows = retained["eligible"] == 0
eligible_rows = retained["eligible"] == 1

ineligible_mean_dose = np.average(
    retained.loc[ineligible_rows, "dose"],
    weights=retained.loc[ineligible_rows, "weight"],
)
eligible_mean_dose = np.average(
    retained.loc[eligible_rows, "dose"],
    weights=retained.loc[eligible_rows, "weight"],
)

ineligible_effect = ineligible_slope * ineligible_mean_dose
eligible_nonrecipient_effect = eligible_slope * eligible_mean_dose

census_group_totals = (
    census.groupby("eligible", as_index=False)["nonrecipient_population"].sum()
)
population_weights = {
    int(row["eligible"]): float(row["nonrecipient_population"])
    for _, row in census_group_totals.iterrows()
}

population_effect = np.average(
    [ineligible_effect, eligible_nonrecipient_effect],
    weights=[
        population_weights.get(0, 0.0),
        population_weights.get(1, 0.0),
    ],
)

n_obs = int(len(retained))

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "ineligible_effect",
            "estimate": float(ineligible_effect),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "eligible_nonrecipient_effect",
            "estimate": float(eligible_nonrecipient_effect),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "population_effect",
            "estimate": float(population_effect),
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "weighted_2SLS",
        "retained_sample": "recipient == 0",
        "endogenous_columns": [
            "dose*(1-eligible)",
            "dose*eligible",
        ],
        "exogenous_columns": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
        ],
        "instrument_columns": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
            "instrument*(1-eligible)",
            "instrument*eligible",
        ],
        "weight_column": "weight",
        "counterfactual": "dose set to zero for every retained household",
        "group_effect_definition": "fitted dose slope times household-weighted mean dose",
        "population_weight_source": "census.nonrecipient_population",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "n_retained_ineligible": int(ineligible_rows.sum()),
        "n_retained_eligible": int(eligible_rows.sum()),
        "census_nonrecipient_population_ineligible": population_weights.get(0, 0.0),
        "census_nonrecipient_population_eligible": population_weights.get(1, 0.0),
    },
}

with open("result.json", "w", encoding="utf-8") as output_file:
    json.dump(result, output_file, indent=2, ensure_ascii=False)
