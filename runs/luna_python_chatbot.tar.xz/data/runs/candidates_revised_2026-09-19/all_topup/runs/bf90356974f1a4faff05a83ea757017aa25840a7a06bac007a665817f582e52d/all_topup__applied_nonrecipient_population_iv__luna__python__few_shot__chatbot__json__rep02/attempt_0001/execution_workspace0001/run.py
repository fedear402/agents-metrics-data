import json
import numpy as np
import pandas as pd


def main():
    households = pd.read_csv("households.csv")
    census = pd.read_csv("census.csv")

    d = households.loc[households["recipient"] == 0].copy()
    n_obs = int(len(d))

    eligible = d["eligible"].to_numpy(dtype=float)
    dose = d["dose"].to_numpy(dtype=float)
    baseline = d["baseline"].to_numpy(dtype=float)
    instrument = d["instrument"].to_numpy(dtype=float)
    outcome = d["outcome"].to_numpy(dtype=float)
    weight = d["weight"].to_numpy(dtype=float)

    ineligible = 1.0 - eligible

    exog = np.column_stack([
        ineligible,
        eligible,
        baseline * ineligible,
        baseline * eligible,
    ])

    endogenous = np.column_stack([
        dose * ineligible,
        dose * eligible,
    ])

    instruments = np.column_stack([
        exog,
        instrument * ineligible,
        instrument * eligible,
    ])

    x = np.column_stack([exog, endogenous])

    sqrt_weight = np.sqrt(weight)
    x_w = x * sqrt_weight[:, None]
    y_w = outcome * sqrt_weight
    z_w = instruments * sqrt_weight[:, None]

    first_stage_projection = z_w @ np.linalg.pinv(z_w) 
    x_fitted_w = first_stage_projection @ x_w
    beta = np.linalg.lstsq(x_fitted_w, y_w, rcond=None)[0]

    ineligible_slope = float(beta[4])
    eligible_slope = float(beta[5])

    ineligible_mask = eligible == 0
    eligible_mask = eligible == 1

    ineligible_mean_dose = float(
        np.average(dose[ineligible_mask], weights=weight[ineligible_mask])
    )
    eligible_mean_dose = float(
        np.average(dose[eligible_mask], weights=weight[eligible_mask])
    )

    ineligible_effect = ineligible_slope * ineligible_mean_dose
    eligible_nonrecipient_effect = eligible_slope * eligible_mean_dose

    census_group = (
        census.groupby("eligible", as_index=False)["nonrecipient_population"]
        .sum()
    )
    population_weights = {
        int(row["eligible"]): float(row["nonrecipient_population"])
        for _, row in census_group.iterrows()
    }

    total_population = (
        population_weights.get(0, 0.0) + population_weights.get(1, 0.0)
    )
    population_effect = (
        ineligible_effect * population_weights.get(0, 0.0)
        + eligible_nonrecipient_effect * population_weights.get(1, 0.0)
    ) / total_population

    result = {
        "task_id": "applied_nonrecipient_population_iv",
        "platform": "python",
        "estimates": [
            {
                "term": "ineligible_effect",
                "estimate": float(ineligible_effect),
                "se": None,
                "n_obs": n_obs,
            },
            {
                "term": "eligible_nonrecipient_effect",
                "estimate": float(eligible_nonrecipient_effect),
                "se": None,
                "n_obs": n_obs,
            },
            {
                "term": "population_effect",
                "estimate": float(population_effect),
                "se": None,
                "n_obs": n_obs,
            },
        ],
        "method_metadata": {
            "estimator": "weighted two-stage least squares",
            "counterfactual": "dose set to zero for every retained nonrecipient household",
            "retained_sample": "recipient == 0",
            "endogenous_columns": [
                "dose*(1-eligible)",
                "dose*eligible",
            ],
            "exogenous_columns": [
                "1-eligible",
                "eligible",
                "baseline*(1-eligible)",
                "baseline*eligible",
            ],
            "instrument_columns": [
                "1-eligible",
                "eligible",
                "baseline*(1-eligible)",
                "baseline*eligible",
                "instrument*(1-eligible)",
                "instrument*eligible",
            ],
            "weight_variable": "weight",
            "population_weight_variable": "nonrecipient_population",
        },
        "diagnostics": {
            "n_obs": n_obs,
            "n_retained_nonrecipients": n_obs,
            "ineligible_households": int(ineligible_mask.sum()),
            "eligible_nonrecipient_households": int(eligible_mask.sum()),
            "population_counts": {
                "ineligible": population_weights.get(0, 0.0),
                "eligible": population_weights.get(1, 0.0),
            },
        },
    }

    with open("result.json", "w", encoding="utf-8") as file:
        json.dump(result, file, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
