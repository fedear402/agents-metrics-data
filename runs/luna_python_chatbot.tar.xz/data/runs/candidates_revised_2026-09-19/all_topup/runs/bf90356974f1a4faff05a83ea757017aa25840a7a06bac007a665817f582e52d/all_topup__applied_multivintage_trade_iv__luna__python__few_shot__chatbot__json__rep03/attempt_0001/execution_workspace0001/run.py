import json
import numpy as np
import pandas as pd


def exposure_for_group(emp, areas_group, trade_group, crosswalk, change_col):
    industries = crosswalk["industry"].drop_duplicates().tolist()
    area_ids = areas_group["area"].drop_duplicates().tolist()

    emp_group = emp.merge(
        crosswalk[["code", "industry"]],
        on="industry",
        how="right",
    )

    matrix = (
        emp_group.pivot_table(
            index="area",
            columns="industry",
            values="employment",
            aggfunc="sum",
            fill_value=0.0,
        )
        .reindex(index=area_ids, columns=industries, fill_value=0.0)
        .fillna(0.0)
    )

    national = matrix.sum(axis=0)

    trade_by_industry = (
        trade_group.merge(crosswalk, on="code", how="inner")
        .groupby("industry", as_index=True)[change_col]
        .first()
        .reindex(industries)
    )

    price_index = float(trade_group["price_index"].iloc[0])
    years = float(trade_group["years"].iloc[0])

    shock = (
        trade_by_industry.to_numpy(dtype=float)
        / national.to_numpy(dtype=float)
        / (price_index / 100.0)
        / 1000.0
        * (10.0 / years)
    )

    totals = (
        areas_group.set_index("area")["total_employment"]
        .reindex(area_ids)
        .to_numpy(dtype=float)
    )

    values = matrix.to_numpy(dtype=float) @ shock / totals
    return pd.Series(values, index=area_ids)


crosswalk = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv")
areas = pd.read_csv("areas.csv")
employment = pd.read_csv("employment.csv")
outcomes = pd.read_csv("outcomes.csv")

trade = trade.merge(crosswalk, on="code", how="inner")

period_values = list(pd.unique(areas["period"]))
period_numeric = pd.to_numeric(pd.Series(period_values), errors="coerce")
if period_numeric.notna().all():
    period_order = sorted(period_values, key=lambda value: float(value))
else:
    period_order = sorted(period_values, key=lambda value: str(value))

exposure_rows = []

for period in period_order:
    area_period = areas.loc[areas["period"] == period].copy()
    trade_period = trade.loc[trade["period"] == period].copy()

    base_areas = area_period.loc[area_period["vintage"] == "base"].copy()
    early_areas = area_period.loc[area_period["vintage"] == "early"].copy()

    base_emp = employment.loc[
        (employment["period"] == period)
        & (employment["vintage"] == "base")
    ].copy()
    early_emp = employment.loc[
        (employment["period"] == period)
        & (employment["vintage"] == "early")
    ].copy()

    x_values = exposure_for_group(
        base_emp,
        base_areas,
        trade_period,
        crosswalk,
        "us_change",
    )
    z_values = exposure_for_group(
        early_emp,
        early_areas,
        trade_period,
        crosswalk,
        "other_change",
    )

    for area in base_areas["area"]:
        exposure_rows.append(
            {
                "area": area,
                "period": period,
                "x": float(x_values.loc[area]),
                "z": float(z_values.loc[area]),
            }
        )

exposures = pd.DataFrame(exposure_rows)

base_population = (
    areas.loc[areas["vintage"] == "base", ["area", "period", "population"]]
    .drop_duplicates(["area", "period"])
)

panel = (
    outcomes.merge(exposures, on=["area", "period"], how="inner")
    .merge(base_population, on=["area", "period"], how="inner")
)

if pd.to_numeric(panel["period"], errors="coerce").notna().all():
    panel["period_reg"] = pd.to_numeric(panel["period"], errors="coerce")
else:
    period_codes = {value: index for index, value in enumerate(period_order)}
    panel["period_reg"] = panel["period"].map(period_codes).astype(float)

y = panel["change_pp"].to_numpy(dtype=float)
x_exog = np.column_stack(
    [
        np.ones(len(panel)),
        panel["period_reg"].to_numpy(dtype=float),
        panel["control"].to_numpy(dtype=float),
    ]
)
endog = panel["x"].to_numpy(dtype=float)
z_instrument = panel["z"].to_numpy(dtype=float)
weights = panel["population"].to_numpy(dtype=float)

regressors = np.column_stack([x_exog, endog])
instruments = np.column_stack([x_exog, z_instrument])

sqrt_weights = np.sqrt(weights)
weighted_regressors = regressors * sqrt_weights[:, None]
weighted_instruments = instruments * sqrt_weights[:, None]
weighted_outcome = y * sqrt_weights

instrument_crossproduct = weighted_instruments.T @ weighted_instruments
projection = (
    weighted_instruments
    @ np.linalg.inv(instrument_crossproduct)
    @ weighted_instruments.T
)
estimated = np.linalg.solve(
    weighted_regressors.T @ projection @ weighted_regressors,
    weighted_regressors.T @ projection @ weighted_outcome,
)

area0 = panel.loc[panel["area"] == 0].copy()
if area0.empty:
    area0 = panel.loc[panel["area"].astype(str) == "0"].copy()

def value_for_period(frame, period):
    match = frame.loc[frame["period"].astype(str) == str(period)]
    return float(match.iloc[0]["x"])

period0 = period_order[0]
period1 = period_order[1]

results = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "iv_slope",
            "estimate": float(estimated[-1]),
            "se": None,
            "n_obs": 72,
        },
        {
            "term": "exposure_area0_period0",
            "estimate": value_for_period(area0, period0),
            "se": None,
            "n_obs": 72,
        },
        {
            "term": "exposure_area0_period1",
            "estimate": value_for_period(area0, period1),
            "se": None,
            "n_obs": 72,
        },
        {
            "term": "instrument_area0_period0",
            "estimate": float(
                area0.loc[
                    area0["period"].astype(str) == str(period0)
                ].iloc[0]["z"]
            ),
            "se": None,
            "n_obs": 72,
        },
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "outcome": "change_pp",
        "endogenous_regressor": "x",
        "instrument": "z",
        "exogenous_regressors": ["intercept", "period", "control"],
        "weight": "base-vintage population",
    },
    "diagnostics": {
        "n_obs": 72,
        "sample_count": int(len(panel)),
    },
}

with open("result.json", "w", encoding="utf-8") as output_file:
    json.dump(results, output_file, indent=2)
