import csv
import json
import itertools
from math import comb, exp, log
from scipy.optimize import minimize_scalar
from scipy.special import logsumexp


def log_binomial(n, k):
    if k < 0 or k > n:
        return float("-inf")
    return log(comb(n, k))


def risk_set_contribution(risk_training, exit_training, beta):
    n1 = sum(risk_training)
    n0 = len(risk_training) - n1
    d = len(exit_training)
    observed_sum = sum(exit_training)

    terms = []
    for k in range(max(0, d - n0), min(d, n1) + 1):
        terms.append(
            log_binomial(n1, k)
            + log_binomial(n0, d - k)
            + beta * k
        )

    denominator_log = logsumexp(terms)
    contribution = beta * observed_sum - denominator_log
    return contribution, observed_sum, denominator_log


def build_contributions(rows):
    cohorts = {}
    for row in rows:
        cohort = row["cohort"]
        cohorts.setdefault(cohort, []).append(row)

    contributions = []
    first_event = None

    for cohort, cohort_rows in cohorts.items():
        event_months = sorted(
            {
                row["end_month"]
                for row in cohort_rows
                if row["event"] == 1
            }
        )

        for month in event_months:
            risk_rows = [
                row for row in cohort_rows
                if row["end_month"] >= month
            ]
            exit_rows = [
                row for row in risk_rows
                if row["event"] == 1 and row["end_month"] == month
            ]

            if not exit_rows:
                continue

            risk_training = [row["training"] for row in risk_rows]
            exit_training = [row["training"] for row in exit_rows]

            item = {
                "cohort": cohort,
                "month": month,
                "risk_training": risk_training,
                "exit_training": exit_training,
            }
            contributions.append(item)

            if cohort == 0 and month == 1:
                first_event = item

    return contributions, first_event


def main():
    rows = []
    with open("input.csv", newline="") as handle:
        reader = csv.DictReader(handle)
        for raw in reader:
            rows.append(
                {
                    "cohort": int(raw["cohort"]),
                    "worker": raw["worker"],
                    "training": int(raw["training"]),
                    "end_month": int(raw["end_month"]),
                    "event": int(raw["event"]),
                }
            )

    contributions, first_event = build_contributions(rows)

    def log_likelihood(beta):
        return sum(
            risk_set_contribution(
                item["risk_training"],
                item["exit_training"],
                beta,
            )[0]
            for item in contributions
        )

    fit = minimize_scalar(
        lambda beta: -log_likelihood(beta),
        bounds=(-4.0, 4.0),
        method="bounded",
        options={"xatol": 1e-14},
    )

    candidates = [(-4.0, log_likelihood(-4.0)),
                  (float(fit.x), log_likelihood(float(fit.x))),
                  (4.0, log_likelihood(4.0))]
    beta, fitted_log_likelihood = max(candidates, key=lambda item: item[1])
    conditional_odds_ratio = exp(beta)

    if first_event is None:
        raise ValueError("The input has no exits in cohort 0 at month 1.")

    _, first_sum, first_denominator_log = risk_set_contribution(
        first_event["risk_training"],
        first_event["exit_training"],
        beta,
    )
    first_event_log_probability = (
        beta * first_sum - first_denominator_log
    )
    first_event_probability = exp(first_event_log_probability)

    n_obs = len(rows)
    result = {
        "task_id": "lp11_duration",
        "platform": "python",
        "estimates": [
            {
                "term": "training_coefficient",
                "estimate": float(beta),
                "se": None,
                "n_obs": n_obs,
            },
            {
                "term": "conditional_odds_ratio",
                "estimate": float(conditional_odds_ratio),
                "se": None,
                "n_obs": n_obs,
            },
            {
                "term": "log_likelihood",
                "estimate": float(fitted_log_likelihood),
                "se": None,
                "n_obs": n_obs,
            },
            {
                "term": "first_event_set_probability",
                "estimate": float(first_event_probability),
                "se": None,
                "n_obs": n_obs,
            },
            {
                "term": "first_event_set_log_probability",
                "estimate": float(first_event_log_probability),
                "se": None,
                "n_obs": n_obs,
            },
        ],
        "method_metadata": {
            "model": "Cox discrete-time conditional odds model",
            "optimization_interval": [-4.0, 4.0],
            "risk_set_denominator": "Exact elementary symmetric polynomial by training count",
            "same_month_exits_evaluated_jointly": True,
            "right_censoring_rule": "Workers with end_month at least the current month enter the risk set",
            "probability_target": "Named observed exit set in cohort 0, month 1",
        },
        "diagnostics": {
            "n_obs": n_obs,
            "n_cohort_month_exit_sets": len(contributions),
            "first_event_set_found": True,
            "optimizer_success": bool(fit.success),
        },
    }

    with open("result.json", "w") as handle:
        json.dump(result, handle, indent=2)


if __name__ == "__main__":
    main()
