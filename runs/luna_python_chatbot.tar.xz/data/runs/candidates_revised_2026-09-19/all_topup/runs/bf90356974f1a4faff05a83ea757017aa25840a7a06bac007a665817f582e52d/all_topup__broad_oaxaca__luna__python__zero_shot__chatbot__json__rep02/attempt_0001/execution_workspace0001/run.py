import csv
import json

def solve_linear_system(matrix, vector):
    n = len(vector)
    a = [row[:] + [vector[i]] for i, row in enumerate(matrix)]

    for col in range(n):
        pivot = max(range(col, n), key=lambda row: abs(a[row][col]))
        a[col], a[pivot] = a[pivot], a[col]

        pivot_value = a[col][col]
        for j in range(col, n + 1):
            a[col][j] /= pivot_value

        for row in range(n):
            if row == col:
                continue
            factor = a[row][col]
            for j in range(col, n + 1):
                a[row][j] -= factor * a[col][j]

    return [a[i][n] for i in range(n)]

rows = []

with open("./input.csv", newline="") as input_file:
    reader = csv.DictReader(input_file)
    for row in reader:
        rows.append({
            "y": float(row["y"]),
            "x": float(row["x"]),
            "z": float(row["z"]),
            "group": int(row["group"]),
        })

n_obs = len(rows)

def mean(values):
    return sum(values) / len(values)

def fit_group(group_value):
    group_rows = [row for row in rows if row["group"] == group_value]

    matrix = [[0.0] * 3 for _ in range(3)]
    vector = [0.0] * 3

    for row in group_rows:
        features = [1.0, row["x"], row["z"]]
        for i in range(3):
            vector[i] += features[i] * row["y"]
            for j in range(3):
                matrix[i][j] += features[i] * features[j]

    return solve_linear_system(matrix, vector)

group_0 = [row for row in rows if row["group"] == 0]
group_1 = [row for row in rows if row["group"] == 1]

beta_0 = fit_group(0)
beta_1 = fit_group(1)

xbar_0 = [1.0, mean([row["x"] for row in group_0]), mean([row["z"] for row in group_0])]
xbar_1 = [1.0, mean([row["x"] for row in group_1]), mean([row["z"] for row in group_1])]

gap = mean([row["y"] for row in group_1]) - mean([row["y"] for row in group_0])

explained = sum((xbar_1[i] - xbar_0[i]) * beta_0[i] for i in range(3))
unexplained = sum(xbar_1[i] * (beta_1[i] - beta_0[i]) for i in range(3))
explained_x = (xbar_1[1] - xbar_0[1]) * beta_0[1]

result = {
    "task_id": "broad_oaxaca",
    "platform": "python",
    "estimates": [
        {
            "term": "gap",
            "estimate": gap,
            "se": None,
            "n_obs": n_obs
        },
        {
            "term": "explained",
            "estimate": explained,
            "se": None,
            "n_obs": n_obs
        },
        {
            "term": "unexplained",
            "estimate": unexplained,
            "se": None,
            "n_obs": n_obs
        },
        {
            "term": "explained_x",
            "estimate": explained_x,
            "se": None,
            "n_obs": n_obs
        }
    ],
    "method_metadata": {},
    "diagnostics": {}
}

with open("result.json", "w") as output_file:
    json.dump(result, output_file, indent=2)
