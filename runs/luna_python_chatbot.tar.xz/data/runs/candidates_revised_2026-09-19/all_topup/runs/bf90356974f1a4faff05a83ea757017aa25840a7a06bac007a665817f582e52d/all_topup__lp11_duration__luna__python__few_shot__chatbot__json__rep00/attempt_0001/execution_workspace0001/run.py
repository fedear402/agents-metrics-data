import csv
import itertools
import json
import math
from collections import defaultdict

import numpy as np
from scipy.optimize import minimize_scalar
from scipy.special import logsumexp


INPUT_FILE = "input.csv"
OUTPUT_FILE = "result.json"


def read_input(path):
    rows = []
    with open(path, newline="") as f:
        for row in csv.DictReader(f):
            rows.append(
                {
                    "cohort": row["cohort"],
                    "worker": row["worker"],
                    "training": int(row["training"]),
                    "end_month": int(row["end_month"]),
                    "event": int(row["event"]),
                }
            )
    return rows


def subset_logsum(beta, training_values, d):
    n = len(training_values)
    if d == 0:
        return 0.0

    scores = []
    for subset in itertools.combinations(range(n), d):
        scores.append(beta * sum(training_values[i] for i in subset))
    return float(logsumexp(np.asarray(scores, dtype=float)))


def build_contributions(rows):
    cohorts = defaultdict(list)
    for row in rows:
        cohorts[row["cohort"]].append(row)

    contributions = []
    first_event_rows = None

    for cohort, cohort_rows in cohorts.items():
        max_month = max(row["end_month"] for row in cohort_rows)

        for month in range(1, max_month + 1):
            risk_rows = [
                row for row in cohort_rows if row["end_month"] >= month
            ]
            event_rows = [
                row
                for row in risk_rows
                if row["end_month"] == month and row["event"] == 1
            ]

            if event_rows:
                training_values = [row["training"] for row in risk_rows]
                d = len(event_rows)
                observed_sum = sum(row["training"] for row in event_rows)
                contributions.append(
                    {
                        "cohort": cohort,
                        "month": month,
                        "training_values": training_values,
                        "d": d,
                        "observed_sum": observed_sum,
                        "event_rows": event_rows,
                    }
                )

                if str(cohort) == "0" and month == 1:
                    first_event_rows = event_rows

    return contributions, first_event_rows


def log_likelihood(beta, contributions):
    total = 0.0
    for item in contributions:
        total += (
            beta * item["observed_sum"]
            - subset_logsum(beta, item["training_values"], item["d"])
        )
    return float(total)


def main():
    rows = read_input(INPUT_FILE)
    contributions, first_event_rows = build_contributions(rows)

    fit = minimize_scalar(
        lambda beta: -log_likelihood(float(beta), contributions),
        bounds=(-4.0, 4.0),
        method="bounded",
        options={"xatol": 1e-14},
    )

    candidates = [-4.0, 4.0, float(fit.x)]
    beta = max(candidates, key=lambda value: log_likelihood(value, contributions))
    ll = log_likelihood(beta, contributions)

    if first_event_rows is None:
        raise ValueError("No exits found for cohort 0 in month 1.")

    first_risk_rows = next(
        item["event_rows"]
        for item in contributions
        if str(item["cohort"]) == "0" and item["month"] == 1
    )
    first_item = next(
        item
        for item in contributions
        if str(item["cohort"]) == "0" and item["month"] == 1
    )

    observed_first_sum = sum(row["training"] for row in first_risk_rows)
    first_log_probability = (
        beta * observed_first_sum
        - subset_logsum(
            beta,
            first_item["training_values"],
            first_item["d"],
        )
    )
    first_probability = math.exp(first_log_probability)

    estimates = [
        {
            "term": "training_coefficient",
            "estimate": float(beta),
            "se": None,
            "n_obs": int(len(rows)),
        },
        {
            "term": "conditional_odds_ratio",
            "estimate": float(math.exp(beta)),
            "se": None,
            "n_obs": int(len(rows)),
        },
        {
            "term": "log_likelihood",
            "estimate": float(ll),
            "se": None,
            "n_obs": int(len(rows)),
        },
        {
            "term": "first_event_set_probability",
            "estimate": float(first_probability),
            "se": None,
            "n_obs": int(len(rows)),
        },
        {
            "term": "first_event_set_log_probability",
            "estimate": float(first_log_probability),
            "se": None,
            "n_obs": int(len(rows)),
        },
    ]

    result = {
        "task_id": "lp11_duration",
        "platform": "python",
        "estimates": estimates,
        "method_metadata": {
            "model": "Cox discrete-time conditional odds model",
            "covariate": "training",
            "optimization_interval": [-4, 4],
            "risk_set_unit": "cohort-month",
            "subset_method": "exact enumeration",
            "likelihood_constants": "none added",
            "odds_ratio_interpretation": (
                "conditional discrete-time odds ratio"
            ),
        },
        "diagnostics": {
            "sample_count": int(len(rows)),
            "cohort_month_contributions": int(len(contributions)),
            "first_event_set": {
                "cohort": 0,
                "month": 1,
                "event_count": int(first_item["d"]),
                "observed_training_sum": int(observed_first_sum),
            },
            "optimizer_success": bool(fit.success),
            "optimizer_message": str(fit.message),
        },
    }

    with open(OUTPUT_FILE, "w") as f:
        json.dump(result, f, indent=2)


if __name__ == "__main__":
    main()
