import csv
import json
import os
import numpy as np


def read_csv(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


households = read_csv("households.csv")
census = read_csv("census.csv")

rows = [r for r in households if int(float(r["recipient"])) == 0]
n_obs = len(rows)

eligible = np.array([float(r["eligible"]) for r in rows], dtype=float)
instrument = np.array([float(r["instrument"]) for r in rows], dtype=float)
dose = np.array([float(r["dose"]) for r in rows], dtype=float)
baseline = np.array([float(r["baseline"]) for r in rows], dtype=float)
weight = np.array([float(r["weight"]) for r in rows], dtype=float)
outcome = np.array([float(r["outcome"]) for r in rows], dtype=float)

ineligible = 1.0 - eligible

# Endogenous regressors.
X_endogenous = np.column_stack([
    dose * ineligible,
    dose * eligible,
])

# Exogenous regressors, with no intercept.
X_exogenous = np.column_stack([
    ineligible,
    eligible,
    baseline * ineligible,
    baseline * eligible,
])

# Instrument matrix.
Z = np.column_stack([
    ineligible,
    eligible,
    baseline * ineligible,
    baseline * eligible,
    instrument * ineligible,
    instrument * eligible,
])

X = np.column_stack([X_exogenous, X_endogenous])

sqrt_weight = np.sqrt(weight)
Z_w = Z * sqrt_weight[:, None]
X_w = X * sqrt_weight[:, None]
y_w = outcome * sqrt_weight

# Weighted first-stage fitted regressors.
ZTZ_inv = np.linalg.pinv(Z_w.T @ Z_w)
X_hat_w = Z_w @ ZTZ_inv @ (Z_w.T @ X_w)

# Weighted second stage.
beta = np.linalg.pinv(X_hat_w.T @ X_hat_w) @ (X_hat_w.T @ y_w)

ineligible_slope = float(beta[4])
eligible_slope = float(beta[5])

ineligible_mean_dose = float(
    np.sum(weight[eligible == 0] * dose[eligible == 0])
    / np.sum(weight[eligible == 0])
)
eligible_mean_dose = float(
    np.sum(weight[eligible == 1] * dose[eligible == 1])
    / np.sum(weight[eligible == 1])
)

ineligible_effect = ineligible_slope * ineligible_mean_dose
eligible_nonrecipient_effect = eligible_slope * eligible_mean_dose

census_ineligible = sum(
    float(r["nonrecipient_population"])
    for r in census
    if int(float(r["eligible"])) == 0
)
census_eligible = sum(
    float(r["nonrecipient_population"])
    for r in census
    if int(float(r["eligible"])) == 1
)
census_total = census_ineligible + census_eligible

population_effect = (
    ineligible_effect * census_ineligible / census_total
    + eligible_nonrecipient_effect * census_eligible / census_total
)

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "ineligible_effect",
            "estimate": float(ineligible_effect),
            "se": None,
            "n_obs": int(n_obs),
        },
        {
            "term": "eligible_nonrecipient_effect",
            "estimate": float(eligible_nonrecipient_effect),
            "se": None,
            "n_obs": int(n_obs),
        },
        {
            "term": "population_effect",
            "estimate": float(population_effect),
            "se": None,
            "n_obs": int(n_obs),
        },
    ],
    "method_metadata": {
        "estimator": "weighted_2sls",
        "outcome": "outcome",
        "endogenous_columns": [
            "dose*(1-eligible)",
            "dose*eligible",
        ],
        "exogenous_columns": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
        ],
        "instrument_columns": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
            "instrument*(1-eligible)",
            "instrument*eligible",
        ],
        "weight_column": "weight",
        "intercept": False,
        "retained_condition": "recipient == 0",
        "counterfactual": "dose == 0 for every retained household",
        "effect_convention": (
            "Each group effect equals its fitted dose slope multiplied by "
            "the household-weighted mean dose among retained observations."
        ),
        "population_aggregation": (
            "Census nonrecipient_population determines the final between-group weights."
        ),
    },
    "diagnostics": {
        "n_obs": int(n_obs),
        "n_retained_households": int(n_obs),
        "ineligible_weighted_mean_dose": ineligible_mean_dose,
        "eligible_weighted_mean_dose": eligible_mean_dose,
        "ineligible_dose_slope": ineligible_slope,
        "eligible_dose_slope": eligible_slope,
        "ineligible_population": float(census_ineligible),
        "eligible_population": float(census_eligible),
        "population_total": float(census_total),
    },
}

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, allow_nan=False)
