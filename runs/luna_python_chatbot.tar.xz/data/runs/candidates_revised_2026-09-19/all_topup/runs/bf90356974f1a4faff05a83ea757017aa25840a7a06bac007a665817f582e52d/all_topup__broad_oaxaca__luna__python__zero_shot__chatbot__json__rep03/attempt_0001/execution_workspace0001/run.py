import csv
import json
import math

def solve_ols(rows):
    n = len(rows)
    sx = sum(row[0] for row in rows)
    sz = sum(row[1] for row in rows)
    sy = sum(row[2] for row in rows)
    sxx = sum(row[0] * row[0] for row in rows)
    sxz = sum(row[0] * row[1] for row in rows)
    szz = sum(row[1] * row[1] for row in rows)
    sxy = sum(row[0] * row[2] for row in rows)
    szy = sum(row[1] * row[2] for row in rows)

    matrix = [
        [float(n), sx, sx and sz, sy],
        [sx, sxx, sxz, sxy],
        [sz, sxz, szz, szy],
    ]

    for i in range(3):
        pivot = max(range(i, 3), key=lambda r: abs(matrix[r][i]))
        matrix[i], matrix[pivot] = matrix[pivot], matrix[i]

        divisor = matrix[i][i]
        for j in range(i, 4):
            matrix[i][j] /= divisor

        for r in range(3):
            if r == i:
                continue
            factor = matrix[r][i]
            for j in range(i, 4):
                matrix[r][j] -= factor * matrix[i][j]

    return [matrix[i][3] for i in range(3)]

with open("input.csv", newline="") as infile:
    reader = csv.DictReader(infile)
    data = [
        (
            int(row["group"]),
            float(row["x"]),
            float(row["z"]),
            float(row["y"]),
        )
        for row in reader
    ]

full_n = len(data)
group0 = [(x, z, y) for group, x, z, y in data if group == 0]
group1 = [(x, z, y) for group, x, z, y in data if group == 1]

beta0 = solve_ols(group0)
beta1 = solve_ols(group1)

mean_y0 = sum(y for _, _, y in group0) / len(group0)
mean_y1 = sum(y for _, _, y in group1) / len(group1)
mean_x0 = sum(x for x, _, _ in group0) / len(group0)
mean_x1 = sum(x for x, _, _ in group1) / len(group1)
mean_z0 = sum(z for _, z, _ in group0) / len(group0)
mean_z1 = sum(z for _, z, _ in group1) / len(group1)

gap = mean_y1 - mean_y0
explained = (
    (1.0 - 1.0) * beta0[0]
    + (mean_x1 - mean_x0) * beta0[1]
    + (mean_z1 - mean_z0) * beta0[2]
)
unexplained = (
    1.0 * (beta1[0] - beta0[0])
    + mean_x1 * (beta1[1] - beta0[1])
    + mean_z1 * (beta1[2] - beta0[2])
)
explained_x = (mean_x1 - mean_x0) * beta0[1]

result = {
    "task_id": "broad_oaxaca",
    "platform": "python",
    "estimates": [
        {"term": "gap", "estimate": gap, "se": None, "n_obs": full_n},
        {"term": "explained", "estimate": explained, "se": None, "n_obs": full_n},
        {"term": "unexplained", "estimate": unexplained, "se": None, "n_obs": full_n},
        {"term": "explained_x", "estimate": explained_x, "se": None, "n_obs": full_n},
    ],
    "method_metadata": {},
    "diagnostics": {},
}

with open("result.json", "w") as outfile:
    json.dump(result, outfile, indent=2)
