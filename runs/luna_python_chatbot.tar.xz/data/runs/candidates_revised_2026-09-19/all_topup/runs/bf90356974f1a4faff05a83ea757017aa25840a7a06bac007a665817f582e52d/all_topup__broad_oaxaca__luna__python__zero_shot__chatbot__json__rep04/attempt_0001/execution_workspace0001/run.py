import csv
import json
import numpy as np

with open("input.csv", newline="") as f:
    rows = list(csv.DictReader(f))

y = np.array([float(row["y"]) for row in rows], dtype=float)
x = np.array([float(row["x"]) for row in rows], dtype=float)
z = np.array([float(row["z"]) for row in rows], dtype=float)
group = np.array([int(row["group"]) for row in rows], dtype=int)

def fit_ols(mask):
    design = np.column_stack([
        np.ones(mask.sum()),
        x[mask],
        z[mask],
    ])
    return np.linalg.lstsq(design, y[mask], rcond=None)[0]

beta_0 = fit_ols(group == 0)
beta_1 = fit_ols(group == 1)

xbar_0 = np.array([
    1.0,
    x[group == 0].mean(),
    z[group == 0].mean(),
])
xbar_1 = np.array([
    1.0,
    x[group == 1].mean(),
    z[group == 1].mean(),
])

gap = y[group == 1].mean() - y[group == 0].mean()
explained = float((xbar_1 - xbar_0) @ beta_0)
unexplained = float(xbar_1 @ (beta_1 - beta_0))
explained_x = float((xbar_1[1] - xbar_0[1]) * beta_0[1])

n_obs = len(rows)

result = {
    "task_id": "broad_oaxaca",
    "platform": "python",
    "estimates": [
        {
            "term": "gap",
            "estimate": float(gap),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "explained",
            "estimate": explained,
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "unexplained",
            "estimate": unexplained,
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "explained_x",
            "estimate": explained_x,
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {},
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
