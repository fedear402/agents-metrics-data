import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")

estimates = []
cohort_results = []

for cohort in (3, 5, 7):
    window = list(range(cohort - 2, cohort + 3))

    eligible = df[
        (df["g"] == cohort) |
        (df["g"] == 0) |
        (df["g"] > cohort + 2)
    ].copy()

    eligible = eligible[eligible["time"].isin(window)]

    complete_ids = (
        eligible.groupby("id")["time"]
        .nunique()
        .loc[lambda s: s == len(window)]
        .index
    )

    comparison = eligible[eligible["id"].isin(complete_ids)].copy()
    comparison["did"] = (
        (comparison["g"] == cohort) &
        (comparison["time"] >= cohort)
    ).astype(float)

    unit_dummies = pd.get_dummies(
        comparison["id"], prefix="unit", drop_first=True, dtype=float
    )
    time_dummies = pd.get_dummies(
        comparison["time"], prefix="time", drop_first=True, dtype=float
    )

    X = pd.concat(
        [
            comparison[["did"]].reset_index(drop=True),
            unit_dummies.reset_index(drop=True),
            time_dummies.reset_index(drop=True),
        ],
        axis=1,
    )

    y = comparison["y"].to_numpy(dtype=float)
    beta = np.linalg.lstsq(X.to_numpy(dtype=float), y, rcond=None)[0]
    did_estimate = float(beta[0])

    treated_units = comparison.loc[
        comparison["g"] == cohort, "id"
    ].nunique()

    estimates.append(
        {
            "term": f"att_g{cohort}",
            "estimate": did_estimate,
            "se": None,
            "n_obs": int(len(comparison)),
        }
    )

    cohort_results.append(
        {
            "estimate": did_estimate,
            "treated_units": treated_units,
            "n_obs": len(comparison),
        }
    )

total_weight = sum(result["treated_units"] for result in cohort_results)
weighted_estimate = sum(
    result["estimate"] * result["treated_units"]
    for result in cohort_results
) / total_weight

estimates.append(
    {
        "term": "att_weighted",
        "estimate": float(weighted_estimate),
        "se": None,
        "n_obs": int(sum(result["n_obs"] for result in cohort_results)),
    }
)

result = {
    "task_id": "broad_cohort_stack",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {},
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
