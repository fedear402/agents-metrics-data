import json
import numpy as np
import pandas as pd

df = pd.read_csv("./input.csv")

estimates = []
cohort_results = []

for c in (3, 5, 7):
    window = list(range(c - 2, c + 3))

    comp = df[
        df["time"].isin(window)
        & ((df["g"] == c) | (df["g"] == 0) | (df["g"] > c + 2))
    ].copy()

    complete_units = (
        comp.groupby("id")["time"]
        .nunique()
        .loc[lambda s: s == len(window)]
        .index
    )

    comp = comp[comp["id"].isin(complete_units)].copy()
    comp["did"] = ((comp["g"] == c) & (comp["time"] >= c)).astype(float)

    y = comp["y"].to_numpy(dtype=float)
    did = comp["did"].to_numpy(dtype=float)

    unit_means_y = comp.groupby("id")["y"].transform("mean").to_numpy()
    time_means_y = comp.groupby("time")["y"].transform("mean").to_numpy()
    grand_mean_y = y.mean()
    y_resid = y - unit_means_y - time_means_y + grand_mean_y

    unit_means_did = comp.groupby("id")["did"].transform("mean").to_numpy()
    time_means_did = comp.groupby("time")["did"].transform("mean").to_numpy()
    grand_mean_did = did.mean()
    did_resid = did - unit_means_did - time_means_did + grand_mean_did

    coefficient = float(np.dot(did_resid, y_resid) / np.dot(did_resid, did_resid))
    n_obs = int(len(comp))
    n_treated = int(comp.loc[comp["g"] == c, "id"].nunique())

    cohort_results.append(
        {
            "coefficient": coefficient,
            "n_obs": n_obs,
            "n_treated": n_treated,
        }
    )

    estimates.append(
        {
            "term": f"att_g{c}",
            "estimate": coefficient,
            "se": None,
            "n_obs": n_obs,
        }
    )

weighted_estimate = sum(
    result["coefficient"] * result["n_treated"] for result in cohort_results
) / sum(result["n_treated"] for result in cohort_results)

estimates.append(
    {
        "term": "att_weighted",
        "estimate": float(weighted_estimate),
        "se": None,
        "n_obs": sum(result["n_obs"] for result in cohort_results),
    }
)

result = {
    "task_id": "broad_cohort_stack",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {},
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
