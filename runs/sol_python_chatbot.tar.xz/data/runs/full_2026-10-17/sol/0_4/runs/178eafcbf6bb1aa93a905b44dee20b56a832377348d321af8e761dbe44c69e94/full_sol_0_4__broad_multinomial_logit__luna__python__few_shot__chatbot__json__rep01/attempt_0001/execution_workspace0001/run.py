import json

import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy.special import softmax

data = pd.read_csv("input.csv")
outcomes = [0, 1, 2]
assert data["y"].notna().all()
assert sorted(data["y"].unique().tolist()) == outcomes

X = sm.add_constant(data[["x", "z"]], has_constant="add")
fit = sm.MNLogit(data["y"], X).fit(method="newton", disp=False, tol=1e-10)

coefficients = fit.params.copy()
errors = fit.bse.copy()
assert list(coefficients.columns) == [0, 1]
coefficients.columns = [1, 2]
errors.columns = [1, 2]

prob_cat2_zero = float(
    softmax(
        np.array([
            0.0,
            coefficients.loc["const", 1],
            coefficients.loc["const", 2],
        ])
    )[2]
)

n_obs = int(len(data))
estimates = [
    {
        "term": f"{variable}_cat{category}",
        "estimate": float(coefficients.loc[variable, category]),
        "se": float(errors.loc[variable, category]),
        "n_obs": n_obs,
    }
    for category in (1, 2)
    for variable in ("x", "z")
]
estimates.append({
    "term": "prob_cat2_zero",
    "estimate": prob_cat2_zero,
    "se": None,
    "n_obs": n_obs,
})

result = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "multinomial logit maximum likelihood",
        "vcov": "inverse observed information",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
