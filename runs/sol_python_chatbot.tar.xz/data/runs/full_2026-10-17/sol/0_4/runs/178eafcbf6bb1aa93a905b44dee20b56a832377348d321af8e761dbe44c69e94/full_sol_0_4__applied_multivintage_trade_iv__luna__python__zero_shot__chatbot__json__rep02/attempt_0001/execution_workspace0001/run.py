import json

import numpy as np
import pandas as pd


TASK_ID = "applied_multivintage_trade_iv"
N_OBS = 72


def require_unique(frame, keys, name):
    if frame.duplicated(keys).any():
        raise ValueError(f"{name} has duplicate keys: {keys}")


crosswalk = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv")
areas = pd.read_csv("areas.csv")
employment = pd.read_csv("employment.csv")
outcomes = pd.read_csv("outcomes.csv")

require_unique(crosswalk, ["code"], "crosswalk")
require_unique(trade, ["period", "code"], "trade")
require_unique(areas, ["area", "period", "vintage"], "areas")
require_unique(
    employment, ["area", "period", "vintage", "industry"], "employment"
)
require_unique(outcomes, ["area", "period"], "outcomes")

if crosswalk["industry"].nunique() != 4:
    raise ValueError("Expected four industries.")

trade = trade.merge(crosswalk, on="code", how="left", validate="many_to_one")
if trade["industry"].isna().any():
    raise ValueError("A trade code has no industry match.")
require_unique(trade, ["period", "industry"], "mapped trade")

period_values = sorted(areas["period"].unique())
if len(period_values) != 2:
    raise ValueError("Expected two periods.")
period_indicator = {period_values[0]: 0.0, period_values[1]: 1.0}

area_vintages = areas[["area", "period", "vintage"]].copy()
industries = crosswalk[["industry"]].drop_duplicates().copy()
cells = area_vintages.merge(industries, how="cross")
cells = cells.merge(
    employment,
    on=["area", "period", "vintage", "industry"],
    how="left",
    validate="one_to_one",
)
cells["employment"] = cells["employment"].fillna(0.0)

national = (
    cells.groupby(["period", "vintage", "industry"], as_index=False)["employment"]
    .sum()
    .rename(columns={"employment": "national_employment"})
)
if (national["national_employment"] <= 0).any():
    raise ValueError("National industry employment must be positive.")

cells = cells.merge(
    areas,
    on=["area", "period", "vintage"],
    how="left",
    validate="many_to_one",
)
cells = cells.merge(
    national,
    on=["period", "vintage", "industry"],
    how="left",
    validate="many_to_one",
)
cells = cells.merge(
    trade[
        [
            "period",
            "industry",
            "us_change",
            "other_change",
            "price_index",
            "years",
        ]
    ],
    on=["period", "industry"],
    how="left",
    validate="many_to_one",
)
if cells[
    [
        "total_employment",
        "national_employment",
        "us_change",
        "other_change",
        "price_index",
        "years",
    ]
].isna().any().any():
    raise ValueError("Required employment or trade data are missing.")
if (
    (cells["total_employment"] <= 0).any()
    or (cells["price_index"] <= 0).any()
    or (cells["years"] <= 0).any()
):
    raise ValueError("Employment totals, price indexes, and years must be positive.")

cells["change"] = np.where(
    cells["vintage"].eq("base"), cells["us_change"], cells["other_change"]
)
cells["contribution"] = (
    (cells["employment"] / cells["total_employment"])
    * (cells["change"] / cells["national_employment"])
    / (cells["price_index"] / 100.0)
    / 1000.0
    * (10.0 / cells["years"])
)
exposures = (
    cells.groupby(["area", "period", "vintage"], as_index=False)["contribution"]
    .sum()
    .pivot(index=["area", "period"], columns="vintage", values="contribution")
    .rename(columns={"base": "x", "early": "z"})
    .reset_index()
)
if not {"x", "z"}.issubset(exposures.columns):
    raise ValueError("Both employment vintages are required.")

base_areas = areas.loc[
    areas["vintage"].eq("base"), ["area", "period", "population"]
]
sample = outcomes.merge(
    exposures, on=["area", "period"], how="inner", validate="one_to_one"
).merge(
    base_areas, on=["area", "period"], how="inner", validate="one_to_one"
)
if len(sample) != N_OBS:
    raise ValueError(f"Expected {N_OBS} estimation rows; found {len(sample)}.")
if sample[
    ["change_pp", "control", "x", "z", "population"]
].isna().any().any():
    raise ValueError("Estimation data contain missing values.")
if (sample["population"] <= 0).any():
    raise ValueError("Regression weights must be positive.")

sample["period_indicator"] = sample["period"].map(period_indicator)
exog = np.column_stack(
    [
        np.ones(len(sample)),
        sample["period_indicator"].to_numpy(dtype=float),
        sample["control"].to_numpy(dtype=float),
    ]
)
regressors = np.column_stack([exog, sample["x"].to_numpy(dtype=float)])
instruments = np.column_stack([exog, sample["z"].to_numpy(dtype=float)])
outcome = sample["change_pp"].to_numpy(dtype=float)
sqrt_weight = np.sqrt(sample["population"].to_numpy(dtype=float))

weighted_regressors = regressors * sqrt_weight[:, None]
weighted_instruments = instruments * sqrt_weight[:, None]
weighted_outcome = outcome * sqrt_weight

if np.linalg.matrix_rank(weighted_instruments) != 4:
    raise ValueError("The weighted instrument matrix lacks full rank.")
moment_matrix = weighted_instruments.T @ weighted_regressors
if np.linalg.matrix_rank(moment_matrix) != 4:
    raise ValueError("The weighted 2SLS model is unidentified.")

coefficients = np.linalg.solve(
    moment_matrix, weighted_instruments.T @ weighted_outcome
)
iv_slope = float(coefficients[3])

def exposure_for(area, period, column):
    match = exposures.loc[
        exposures["area"].eq(area) & exposures["period"].eq(period), column
    ]
    if len(match) != 1:
        raise ValueError(f"Expected one exposure for area {area}, period {period}.")
    return float(match.iloc[0])


estimate_values = {
    "iv_slope": iv_slope,
    "exposure_area0_period0": exposure_for(0, period_values[0], "x"),
    "exposure_area0_period1": exposure_for(0, period_values[1], "x"),
    "instrument_area0_period0": exposure_for(0, period_values[0], "z"),
}
result = {
    "task_id": TASK_ID,
    "platform": "python",
    "estimates": [
        {
            "term": term,
            "estimate": value,
            "se": None,
            "n_obs": N_OBS,
        }
        for term, value in estimate_values.items()
    ],
    "method_metadata": {
        "estimator": "population-weighted two-stage least squares",
        "outcome": "change_pp",
        "endogenous_regressor": "x",
        "excluded_instrument": "z",
        "exogenous_instruments": ["intercept", "period", "control"],
        "weight": "base-vintage population",
        "period_indicator": period_indicator,
        "exposure_units": "thousands of real dollars per worker per decade",
        "missing_employment_cells": "zero",
    },
    "diagnostics": {
        "estimation_rows": int(len(sample)),
        "industry_count": int(crosswalk["industry"].nunique()),
        "period_count": int(len(period_values)),
        "weighted_instrument_rank": int(
            np.linalg.matrix_rank(weighted_instruments)
        ),
    },
}

with open("result.json", "w", encoding="utf-8") as output_file:
    json.dump(result, output_file, indent=2, allow_nan=False)
