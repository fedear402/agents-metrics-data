import json

import numpy as np
import pandas as pd


def main():
    data = pd.read_csv("input.csv")
    estimates = []
    weighted_sum = 0.0
    treated_total = 0
    rows_total = 0

    for cohort in (3, 5, 7):
        window = data.loc[data["time"].between(cohort - 2, cohort + 2)].copy()
        eligible = (
            window["g"].eq(cohort)
            | window["g"].eq(0)
            | window["g"].gt(cohort + 2)
        )
        window = window.loc[eligible]

        balanced_ids = window.groupby("id")["time"].nunique()
        balanced_ids = balanced_ids.index[balanced_ids.eq(5)]
        window = window.loc[window["id"].isin(balanced_ids)].copy()

        treated_ids = window.loc[window["g"].eq(cohort), "id"].nunique()
        window["did"] = (
            window["g"].eq(cohort) & window["time"].ge(cohort)
        ).astype(float)

        design = pd.concat(
            [
                window["did"].rename("did"),
                pd.get_dummies(window["id"], prefix="unit", drop_first=True, dtype=float),
                pd.get_dummies(window["time"], prefix="time", drop_first=True, dtype=float),
            ],
            axis=1,
        )
        design.insert(0, "intercept", 1.0)
        coefficient = float(
            np.linalg.lstsq(
                design.to_numpy(dtype=float),
                window["y"].to_numpy(dtype=float),
                rcond=None,
            )[0][design.columns.get_loc("did")]
        )

        row_count = len(window)
        estimates.append(
            {
                "term": f"att_g{cohort}",
                "estimate": coefficient,
                "se": None,
                "n_obs": row_count,
            }
        )
        weighted_sum += treated_ids * coefficient
        treated_total += treated_ids
        rows_total += row_count

    estimates.append(
        {
            "term": "att_weighted",
            "estimate": weighted_sum / treated_total,
            "se": None,
            "n_obs": rows_total,
        }
    )

    result = {
        "task_id": "broad_cohort_stack",
        "platform": "python",
        "estimates": estimates,
        "method_metadata": {},
        "diagnostics": {},
    }
    with open("result.json", "w") as stream:
        json.dump(result, stream, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
