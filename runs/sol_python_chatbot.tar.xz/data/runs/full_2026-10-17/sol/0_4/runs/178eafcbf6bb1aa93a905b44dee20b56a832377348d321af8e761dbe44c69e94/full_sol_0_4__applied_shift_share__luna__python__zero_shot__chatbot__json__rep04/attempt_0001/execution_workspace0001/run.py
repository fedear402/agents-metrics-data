import json

import numpy as np
import pandas as pd


def weighted_iv(outcome, endogenous, instrument, weights):
    """Return the IV slope and shock-level HC1 standard error."""
    design = np.column_stack((np.ones(len(weights)), endogenous))
    instruments = np.column_stack((np.ones(len(weights)), instrument))

    bread = instruments.T @ (weights[:, None] * design)
    rhs = instruments.T @ (weights * outcome)
    coefficients = np.linalg.solve(bread, rhs)

    residuals = outcome - design @ coefficients
    scores = instruments * (weights * residuals)[:, None]
    meat = scores.T @ scores
    inverse_bread = np.linalg.inv(bread)
    covariance = inverse_bread @ meat @ inverse_bread.T
    covariance *= len(weights) / (len(weights) - 2)

    return float(coefficients[1]), float(np.sqrt(covariance[1, 1]))


data = pd.read_csv("input.csv")
regions = data.drop_duplicates("region_id").set_index("region_id")
industries = data.drop_duplicates("industry_id").set_index("industry_id")

e = regions["region_weight"].astype(float)
e /= e.sum()

shares = data.pivot(
    index="region_id", columns="industry_id", values="share"
).loc[e.index, industries.index].astype(float)
shocks = industries.loc[shares.columns, "shock"].to_numpy(dtype=float)

z = shares.to_numpy() @ shocks
x = regions.loc[e.index, "x"].to_numpy(dtype=float)
y = regions.loc[e.index, "y"].to_numpy(dtype=float)
weights = e.to_numpy(dtype=float)

y0 = y - np.dot(weights, y)
x0 = x - np.dot(weights, x)
z0 = z - np.dot(weights, z)

weighted_shares = weights[:, None] * shares.to_numpy()
s = weighted_shares.sum(axis=0)
ybar = (weighted_shares.T @ y0) / s
xbar = (weighted_shares.T @ x0) / s
zbar = (weighted_shares.T @ z0) / s

effect, effect_se = weighted_iv(ybar, xbar, shocks, s)
first_stage, first_stage_se = weighted_iv(xbar, zbar, shocks, s)
effective_shocks = float(1.0 / np.dot(s, s))
n_industries = len(s)

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {
            "term": "effect",
            "estimate": effect,
            "se": effect_se,
            "n_obs": n_industries,
        },
        {
            "term": "first_stage",
            "estimate": first_stage,
            "se": first_stage_se,
            "n_obs": n_industries,
        },
        {
            "term": "effective_shocks",
            "estimate": effective_shocks,
            "se": None,
            "n_obs": n_industries,
        },
    ],
    "method_metadata": {
        "estimator": "Weighted regional 2SLS via shock-level IV aggregation",
        "vcov": "Shock-level heteroskedasticity-robust HC1, N/(N-2)",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output)
