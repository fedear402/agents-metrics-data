import json

import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy.special import softmax

data = pd.read_csv("input.csv")
outcomes = [0, 1, 2]
assert set(data["y"].unique()) == set(outcomes)
assert data[["y", "x", "z"]].notna().all().all()

design = sm.add_constant(data[["x", "z"]], has_constant="add")
fit = sm.MNLogit(data["y"], design).fit(disp=False, maxiter=1000, tol=1e-10)
assert fit.mle_retvals["converged"]

coefficients = fit.params.copy()
errors = fit.bse.copy()
assert list(coefficients.columns) == [0, 1]
coefficients.columns = outcomes[1:]
errors.columns = outcomes[1:]

prob_cat2_zero = float(
    softmax([0.0, coefficients.loc["const", 1], coefficients.loc["const", 2]])[2]
)
n_obs = int(len(data))

def row(term, variable, outcome):
    return {
        "term": term,
        "estimate": float(coefficients.loc[variable, outcome]),
        "se": float(errors.loc[variable, outcome]),
        "n_obs": n_obs,
    }

result = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": [
        row("x_cat1", "x", 1),
        row("z_cat1", "z", 1),
        row("x_cat2", "x", 2),
        row("z_cat2", "z", 2),
        {
            "term": "prob_cat2_zero",
            "estimate": prob_cat2_zero,
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "multinomial logit maximum likelihood; outcome 0 base",
        "vcov": "inverse observed information",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
