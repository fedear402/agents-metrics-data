import json

import numpy as np
import pandas as pd


def weighted_iv(y, x, instrument, weights):
    """Return the IV slope and shock-level HC1 standard error."""
    y = np.asarray(y, dtype=float)
    x = np.asarray(x, dtype=float)
    instrument = np.asarray(instrument, dtype=float)
    weights = np.asarray(weights, dtype=float)

    n = len(y)
    if n <= 2:
        raise ValueError("HC1 requires more than two industries.")

    regressors = np.column_stack((np.ones(n), x))
    instruments = np.column_stack((np.ones(n), instrument))

    cross_product = instruments.T @ (weights[:, None] * regressors)
    moment = instruments.T @ (weights * y)
    coefficients = np.linalg.solve(cross_product, moment)

    residuals = y - regressors @ coefficients
    weighted_scores = instruments * (weights * residuals)[:, None]
    meat = weighted_scores.T @ weighted_scores
    inverse_cross_product = np.linalg.inv(cross_product)
    covariance = inverse_cross_product @ meat @ inverse_cross_product.T
    covariance *= n / (n - 2)

    return float(coefficients[1]), float(np.sqrt(max(covariance[1, 1], 0.0)))


data = pd.read_csv("input.csv")

regions = data.drop_duplicates("region_id").set_index("region_id")
region_weights = regions["region_weight"].astype(float)
region_weights = region_weights / region_weights.sum()

shares = data.pivot(index="region_id", columns="industry_id", values="share")
shares = shares.loc[regions.index].astype(float)
shocks = data.drop_duplicates("industry_id").set_index("industry_id")["shock"]
shocks = shocks.loc[shares.columns].astype(float)

y = regions["y"].astype(float).to_numpy()
x = regions["x"].astype(float).to_numpy()
e = region_weights.to_numpy()
z = shares.to_numpy() @ shocks.to_numpy()

y0 = y - np.dot(e, y)
x0 = x - np.dot(e, x)
z0 = z - np.dot(e, z)

exposure = e[:, None] * shares.to_numpy()
s = exposure.sum(axis=0)
if np.any(s <= 0):
    raise ValueError("Every industry must have positive weighted exposure.")

ybar = exposure.T @ y0 / s
xbar = exposure.T @ x0 / s
zbar = exposure.T @ z0 / s

effect, effect_se = weighted_iv(ybar, xbar, shocks.to_numpy(), s)
first_stage, first_stage_se = weighted_iv(
    xbar, zbar, shocks.to_numpy(), s
)
effective_shocks = float(1.0 / np.sum(s**2))
n_industries = len(s)

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {
            "term": "effect",
            "estimate": effect,
            "se": effect_se,
            "n_obs": n_industries,
        },
        {
            "term": "first_stage",
            "estimate": first_stage,
            "se": first_stage_se,
            "n_obs": n_industries,
        },
        {
            "term": "effective_shocks",
            "estimate": effective_shocks,
            "se": None,
            "n_obs": n_industries,
        },
    ],
    "method_metadata": {
        "estimator": "Weighted regional 2SLS via BHJ shock-level aggregation",
        "vcov": "Shock-level heteroskedasticity-robust HC1, N/(N-2)",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output, indent=2, allow_nan=False)
