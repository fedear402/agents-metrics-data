import json

import numpy as np
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("input.csv")
X = sm.add_constant(df[["x", "z"]], has_constant="add")
model = sm.MNLogit(df["y"], X)
fit = model.fit(method="newton", disp=False)

params = fit.params
ses = fit.bse
n_obs = len(df)

def row(term, variable, column):
    return {
        "term": term,
        "estimate": float(params.loc[variable, column]),
        "se": float(ses.loc[variable, column]),
        "n_obs": n_obs,
    }

eta1 = float(params.loc["const", 0])
eta2 = float(params.loc["const", 1])
scores = np.array([0.0, eta1, eta2])
scores -= scores.max()
prob_cat2_zero = float(np.exp(scores[2]) / np.exp(scores).sum())

result = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": [
        row("x_cat1", "x", 0),
        row("z_cat1", "z", 0),
        row("x_cat2", "x", 1),
        row("z_cat2", "z", 1),
        {
            "term": "prob_cat2_zero",
            "estimate": prob_cat2_zero,
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "Multinomial logit maximum likelihood; base outcome 0",
        "vcov": "Inverse observed information",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output, indent=2)
