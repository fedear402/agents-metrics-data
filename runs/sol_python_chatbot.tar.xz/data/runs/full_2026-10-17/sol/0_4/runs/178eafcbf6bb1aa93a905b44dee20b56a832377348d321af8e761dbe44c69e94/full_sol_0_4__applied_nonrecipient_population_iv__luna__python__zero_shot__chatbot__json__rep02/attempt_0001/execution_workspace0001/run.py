import csv
import json


def solve(matrix, vector):
    """Solve a square linear system with partial pivoting."""
    n = len(vector)
    a = [list(map(float, row)) + [float(vector[i])] for i, row in enumerate(matrix)]

    for col in range(n):
        pivot = max(range(col, n), key=lambda row: abs(a[row][col]))
        if abs(a[pivot][col]) < 1e-12:
            raise ValueError("The IV system is singular.")
        a[col], a[pivot] = a[pivot], a[col]

        scale = a[col][col]
        for j in range(col, n + 1):
            a[col][j] /= scale

        for row in range(col + 1, n):
            factor = a[row][col]
            for j in range(col, n + 1):
                a[row][j] -= factor * a[col][j]

    solution = [0.0] * n
    for row in range(n - 1, -1, -1):
        solution[row] = a[row][n] - sum(
            a[row][col] * solution[col] for col in range(row + 1, n)
        )
    return solution


with open("households.csv", newline="") as file:
    households = [
        row for row in csv.DictReader(file) if int(row["recipient"]) == 0
    ]

n_obs = len(households)
if n_obs == 0:
    raise ValueError("No nonrecipient households were found.")

# The six instruments and six regressors make this IV model exactly identified.
# Its weighted 2SLS coefficients solve Z' W X beta = Z' W y.
cross = [[0.0] * 6 for _ in range(6)]
rhs = [0.0] * 6
group_weight = [0.0, 0.0]
group_weighted_dose = [0.0, 0.0]

for row in households:
    eligible = int(row["eligible"])
    if eligible not in (0, 1):
        raise ValueError("eligible must equal zero or one.")

    ineligible = 1 - eligible
    dose = float(row["dose"])
    baseline = float(row["baseline"])
    instrument = float(row["instrument"])
    weight = float(row["weight"])
    outcome = float(row["outcome"])

    if weight <= 0:
        raise ValueError("All regression weights must be positive.")

    exogenous = [
        float(ineligible),
        float(eligible),
        baseline * ineligible,
        baseline * eligible,
    ]
    regressors = exogenous + [dose * ineligible, dose * eligible]
    instruments = exogenous + [
        instrument * ineligible,
        instrument * eligible,
    ]

    for i in range(6):
        rhs[i] += weight * instruments[i] * outcome
        for j in range(6):
            cross[i][j] += weight * instruments[i] * regressors[j]

    group_weight[eligible] += weight
    group_weighted_dose[eligible] += weight * dose

if any(total == 0 for total in group_weight):
    raise ValueError("Both eligibility groups need nonrecipient observations.")

coefficients = solve(cross, rhs)
mean_dose = [
    group_weighted_dose[group] / group_weight[group] for group in (0, 1)
]
group_effect = [
    coefficients[4] * mean_dose[0],
    coefficients[5] * mean_dose[1],
]

population = {0: 0, 1: 0}
with open("census.csv", newline="") as file:
    for row in csv.DictReader(file):
        group = int(row["eligible"])
        if group not in (0, 1):
            raise ValueError("Census eligible must equal zero or one.")
        population[group] += int(row["nonrecipient_population"])

total_population = population[0] + population[1]
if total_population <= 0:
    raise ValueError("The nonrecipient census population must be positive.")

population_effect = (
    population[0] * group_effect[0] + population[1] * group_effect[1]
) / total_population

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "ineligible_effect",
            "estimate": group_effect[0],
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "eligible_nonrecipient_effect",
            "estimate": group_effect[1],
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "population_effect",
            "estimate": population_effect,
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "weighted exactly identified 2SLS",
        "sample": "households with recipient=0 in both village treatment statuses",
        "regression_weight": "weight",
        "exogenous_columns": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
        ],
        "endogenous_columns": [
            "dose*(1-eligible)",
            "dose*eligible",
        ],
        "excluded_instruments": [
            "instrument*(1-eligible)",
            "instrument*eligible",
        ],
        "intercept": "no additional intercept",
        "counterfactual": "dose=0 for every retained household; synthetic attribution convention",
        "group_aggregation": "dose slope times household-weighted mean dose",
        "population_aggregation": "census nonrecipient_population weights",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "weighted_mean_dose": {
            "ineligible": mean_dose[0],
            "eligible_nonrecipient": mean_dose[1],
        },
        "census_nonrecipient_population": {
            "ineligible": population[0],
            "eligible_nonrecipient": population[1],
        },
    },
}

with open("result.json", "w") as file:
    json.dump(result, file, indent=2, allow_nan=False)
