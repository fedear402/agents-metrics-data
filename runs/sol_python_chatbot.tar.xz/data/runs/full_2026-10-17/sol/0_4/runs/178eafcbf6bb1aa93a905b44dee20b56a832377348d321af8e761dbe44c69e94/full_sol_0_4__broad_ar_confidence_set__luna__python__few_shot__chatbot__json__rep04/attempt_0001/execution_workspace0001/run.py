import json

import numpy as np
import pandas as pd
from scipy.stats import f

data = pd.read_csv("input.csv")
required = ["y", "endog", "x", "z1", "z2"]
if data[required].isna().any().any():
    raise ValueError("Required variables contain missing values.")

y = data["y"].to_numpy(dtype=float)
d = data["endog"].to_numpy(dtype=float)
x = data["x"].to_numpy(dtype=float)
z1 = data["z1"].to_numpy(dtype=float)
z2 = data["z2"].to_numpy(dtype=float)

n = len(data)
q = 2
df = n - 4
restricted = np.column_stack((np.ones(n), x))
unrestricted = np.column_stack((restricted, z1, z2))

if df <= 0 or np.linalg.matrix_rank(unrestricted) != 4:
    raise ValueError("The unrestricted regression requires full rank and positive residual degrees of freedom.")

def residual(values, design):
    coefficients = np.linalg.lstsq(design, values, rcond=None)[0]
    return values - design @ coefficients

ry = residual(y, restricted)
rd = residual(d, restricted)
uy = residual(y, unrestricted)
ud = residual(d, unrestricted)

critical = f.ppf(0.95, q, df)
scale = 1.0 + q * critical / df

# The acceptance condition is A*beta**2 + B*beta + C <= 0.
A = float(rd @ rd - scale * (ud @ ud))
B = float(-2.0 * (ry @ rd - scale * (uy @ ud)))
C = float(ry @ ry - scale * (uy @ uy))
discriminant = B * B - 4.0 * A * C

if A == 0.0 or discriminant <= 0.0:
    raise ValueError("The data must yield two distinct finite boundaries.")

roots = np.sort(np.roots([A, B, C]).real)
boundary_low, boundary_high = map(float, roots)

def ar_f(beta):
    restricted_residual = ry - beta * rd
    unrestricted_residual = uy - beta * ud
    ssr_r = float(restricted_residual @ restricted_residual)
    ssr_u = float(unrestricted_residual @ unrestricted_residual)
    return ((ssr_r - ssr_u) / q) / (ssr_u / df)

def row(term, estimate):
    return {
        "term": term,
        "estimate": float(estimate),
        "se": None,
        "n_obs": n,
    }

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": [
        row("boundary_low", boundary_low),
        row("boundary_high", boundary_high),
        row("accepts_zero", int(C <= 0.0)),
        row("unbounded", int(A < 0.0)),
        row("ar_f_at_one", ar_f(1.0)),
    ],
    "method_metadata": {
        "estimator": "Anderson-Rubin test inversion",
        "vcov": "conventional homoskedastic OLS",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
