import csv
import json


def solve(matrix, values):
    """Solve a square linear system with partial pivoting."""
    n = len(values)
    a = [list(map(float, row)) + [float(values[i])] for i, row in enumerate(matrix)]

    for col in range(n):
        pivot = max(range(col, n), key=lambda row: abs(a[row][col]))
        if abs(a[pivot][col]) < 1e-12:
            raise ValueError("The IV system is singular.")
        a[col], a[pivot] = a[pivot], a[col]

        scale = a[col][col]
        for j in range(col, n + 1):
            a[col][j] /= scale

        for row in range(n):
            if row == col:
                continue
            factor = a[row][col]
            for j in range(col, n + 1):
                a[row][j] -= factor * a[col][j]

    return [a[i][n] for i in range(n)]


with open("households.csv", newline="") as file:
    households = list(csv.DictReader(file))

with open("census.csv", newline="") as file:
    census = list(csv.DictReader(file))

rows = [row for row in households if int(row["recipient"]) == 0]
if not rows:
    raise ValueError("No nonrecipient households were found.")

# X contains four exogenous columns and two endogenous dose columns.
# Z contains the same four exogenous columns and two excluded instruments.
x_rows = []
z_rows = []
outcomes = []
weights = []
dose_totals = [0.0, 0.0]
group_weights = [0.0, 0.0]

for row in rows:
    group = int(row["eligible"])
    if group not in (0, 1):
        raise ValueError("eligible must equal zero or one.")

    ineligible = 1 - group
    eligible = group
    baseline = float(row["baseline"])
    dose = float(row["dose"])
    instrument = float(row["instrument"])
    weight = float(row["weight"])
    if weight <= 0:
        raise ValueError("All estimation weights must be positive.")

    common = [
        ineligible,
        eligible,
        baseline * ineligible,
        baseline * eligible,
    ]
    x_rows.append(common + [dose * ineligible, dose * eligible])
    z_rows.append(
        common + [instrument * ineligible, instrument * eligible]
    )
    outcomes.append(float(row["outcome"]))
    weights.append(weight)

    group_weights[group] += weight
    dose_totals[group] += weight * dose

if any(total == 0 for total in group_weights):
    raise ValueError("Both eligibility groups need retained observations.")

k = 6
ztwz = [[0.0] * k for _ in range(k)]
ztwx = [[0.0] * k for _ in range(k)]
ztwy = [0.0] * k

for x, z, y, weight in zip(x_rows, z_rows, outcomes, weights):
    for i in range(k):
        ztwy[i] += weight * z[i] * y
        for j in range(k):
            ztwz[i][j] += weight * z[i] * z[j]
            ztwx[i][j] += weight * z[i] * x[j]

projected_x_columns = [
    solve(ztwz, [ztwx[i][j] for i in range(k)])
    for j in range(k)
]
projected_y = solve(ztwz, ztwy)

normal_matrix = [
    [
        sum(ztwx[i][a] * projected_x_columns[b][i] for i in range(k))
        for b in range(k)
    ]
    for a in range(k)
]
normal_vector = [
    sum(ztwx[i][a] * projected_y[i] for i in range(k))
    for a in range(k)
]
coefficients = solve(normal_matrix, normal_vector)

mean_dose = [
    dose_totals[group] / group_weights[group]
    for group in (0, 1)
]
ineligible_effect = coefficients[4] * mean_dose[0]
eligible_effect = coefficients[5] * mean_dose[1]

population = [0, 0]
for row in census:
    group = int(row["eligible"])
    if group not in (0, 1):
        raise ValueError("Census eligible must equal zero or one.")
    count = int(row["nonrecipient_population"])
    if count < 0:
        raise ValueError("Census counts cannot be negative.")
    population[group] += count

population_total = sum(population)
if population_total == 0:
    raise ValueError("The nonrecipient census population is zero.")

population_effect = (
    population[0] * ineligible_effect
    + population[1] * eligible_effect
) / population_total

n_obs = len(rows)
result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "ineligible_effect",
            "estimate": ineligible_effect,
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "eligible_nonrecipient_effect",
            "estimate": eligible_effect,
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "population_effect",
            "estimate": population_effect,
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "method": "weighted 2SLS",
        "sample": "households with recipient=0",
        "endogenous_columns": [
            "dose*(1-eligible)",
            "dose*eligible",
        ],
        "exogenous_columns": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
        ],
        "excluded_instruments": [
            "instrument*(1-eligible)",
            "instrument*eligible",
        ],
        "weight": "weight",
        "group_effect": "fitted dose slope times household-weighted mean dose",
        "counterfactual": (
            "Dose is set to zero for every retained household as a "
            "stated synthetic attribution convention."
        ),
        "population_aggregation": (
            "Group effects are averaged using census "
            "nonrecipient_population counts."
        ),
    },
    "diagnostics": {
        "n_obs": n_obs,
        "group_weighted_mean_dose": {
            "ineligible": mean_dose[0],
            "eligible": mean_dose[1],
        },
        "dose_slopes": {
            "ineligible": coefficients[4],
            "eligible": coefficients[5],
        },
        "nonrecipient_population": {
            "ineligible": population[0],
            "eligible": population[1],
        },
    },
}

with open("result.json", "w") as file:
    json.dump(result, file, indent=2, allow_nan=False)
