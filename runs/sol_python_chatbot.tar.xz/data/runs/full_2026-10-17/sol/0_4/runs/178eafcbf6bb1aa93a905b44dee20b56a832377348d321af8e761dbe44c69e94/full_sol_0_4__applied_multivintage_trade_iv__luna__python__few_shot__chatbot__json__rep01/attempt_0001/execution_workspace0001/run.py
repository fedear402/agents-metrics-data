import json

import numpy as np
import pandas as pd


TASK_ID = "applied_multivintage_trade_iv"
N_OBS = 72

crosswalk = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv")
areas = pd.read_csv("areas.csv")
employment = pd.read_csv("employment.csv")
outcomes = pd.read_csv("outcomes.csv")

trade = trade.merge(crosswalk, on="code", how="inner", validate="many_to_one")

# Add zero employment for omitted area-industry cells.
industries = crosswalk[["industry"]].drop_duplicates()
area_industries = areas.merge(industries, how="cross")
employment_full = area_industries.merge(
    employment,
    on=["area", "period", "vintage", "industry"],
    how="left",
    validate="one_to_one",
)
employment_full["employment"] = employment_full["employment"].fillna(0.0)

national = (
    employment_full.groupby(["period", "vintage", "industry"], as_index=False)[
        "employment"
    ]
    .sum()
    .rename(columns={"employment": "national_employment"})
)

cells = employment_full.merge(
    national,
    on=["period", "vintage", "industry"],
    how="left",
    validate="many_to_one",
).merge(
    trade[
        ["period", "industry", "us_change", "other_change", "price_index", "years"]
    ],
    on=["period", "industry"],
    how="left",
    validate="many_to_one",
)

change = np.where(
    cells["vintage"].eq("base"),
    cells["us_change"],
    cells["other_change"],
)
cells["exposure_component"] = (
    cells["employment"].to_numpy(dtype=float)
    / cells["total_employment"].to_numpy(dtype=float)
    * change
    / cells["national_employment"].to_numpy(dtype=float)
    / (cells["price_index"].to_numpy(dtype=float) / 100.0)
    / 1000.0
    * (10.0 / cells["years"].to_numpy(dtype=float))
)

exposures = (
    cells.groupby(["area", "period", "vintage"], as_index=False)[
        "exposure_component"
    ]
    .sum()
    .pivot(index=["area", "period"], columns="vintage", values="exposure_component")
    .rename(columns={"base": "x", "early": "z"})
    .reset_index()
)

base_areas = areas.loc[
    areas["vintage"].eq("base"), ["area", "period", "population"]
]
sample = (
    outcomes.merge(exposures, on=["area", "period"], validate="one_to_one")
    .merge(base_areas, on=["area", "period"], validate="one_to_one")
    .sort_values(["area", "period"])
    .reset_index(drop=True)
)
assert len(sample) == N_OBS

# Weighted 2SLS includes the intercept, period, and control in both matrices.
exog = np.column_stack(
    [
        np.ones(N_OBS),
        sample["period"].to_numpy(dtype=float),
        sample["control"].to_numpy(dtype=float),
    ]
)
X = np.column_stack([exog, sample["x"].to_numpy(dtype=float)])
Z = np.column_stack([exog, sample["z"].to_numpy(dtype=float)])
y = sample["change_pp"].to_numpy(dtype=float)
sqrt_weight = np.sqrt(sample["population"].to_numpy(dtype=float))

Xw = X * sqrt_weight[:, None]
Zw = Z * sqrt_weight[:, None]
yw = y * sqrt_weight

# The model is exactly identified: solve Z' W X beta = Z' W y.
beta = np.linalg.solve(Zw.T @ Xw, Zw.T @ yw)
iv_slope = float(beta[-1])


def value(area, period, column):
    row = sample.loc[
        sample["area"].eq(area) & sample["period"].eq(period), column
    ]
    assert len(row) == 1
    return float(row.iloc[0])


estimates = [
    {"term": "iv_slope", "estimate": iv_slope, "se": None, "n_obs": N_OBS},
    {
        "term": "exposure_area0_period0",
        "estimate": value(0, 0, "x"),
        "se": None,
        "n_obs": N_OBS,
    },
    {
        "term": "exposure_area0_period1",
        "estimate": value(0, 1, "x"),
        "se": None,
        "n_obs": N_OBS,
    },
    {
        "term": "instrument_area0_period0",
        "estimate": value(0, 0, "z"),
        "se": None,
        "n_obs": N_OBS,
    },
]

result = {
    "task_id": TASK_ID,
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "dependent_variable": "change_pp",
        "endogenous_variable": "x",
        "excluded_instrument": "z",
        "exogenous_variables": ["intercept", "period", "control"],
        "weight": "base-vintage population",
        "exposure_units": "thousands of real dollars per worker per decade",
    },
    "diagnostics": {
        "n_obs": N_OBS,
        "n_industries": int(len(industries)),
        "exactly_identified": True,
    },
}

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output, indent=2, allow_nan=False)
