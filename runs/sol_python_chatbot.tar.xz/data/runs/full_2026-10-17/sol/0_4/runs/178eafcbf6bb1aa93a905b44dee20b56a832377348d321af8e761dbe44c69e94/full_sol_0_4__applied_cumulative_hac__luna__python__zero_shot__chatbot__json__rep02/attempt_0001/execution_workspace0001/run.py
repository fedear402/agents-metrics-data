import json

import numpy as np
import pandas as pd
import statsmodels.api as sm

data = pd.read_csv("input.csv")
data["date"] = pd.to_datetime(data["date"])
data = data.sort_values("date").reset_index(drop=True)

change = np.log(data["vix"]).diff()
lags = pd.DataFrame(
    {f"lag_{lag}": change.shift(lag) for lag in range(1, 16)}
)
sample = pd.concat(
    [np.log(data["sales"]).rename("log_sales"), lags], axis=1
).dropna()

y = sample["log_sales"]
X = sm.add_constant(sample[lags.columns])
model = sm.OLS(y, X).fit()
n_obs = len(sample)

# Bartlett weights for lags 1 through 15.
cov = sm.stats.sandwich_covariance.cov_hac(
    model, nlags=15, weights_func=sm.stats.sandwich_covariance.weights_bartlett,
    use_correction=False,
)
cov *= n_obs / (n_obs - 16)
cov = pd.DataFrame(cov, index=X.columns, columns=X.columns)

lag_names = list(lags.columns)
cumulative_estimate = float(model.params[lag_names].sum())
cumulative_se = float(
    np.sqrt(cov.loc[lag_names, lag_names].to_numpy().sum())
)

def row(term, estimate, se):
    return {
        "term": term,
        "estimate": float(estimate),
        "se": float(se),
        "n_obs": int(n_obs),
    }

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        row("cumulative_response", cumulative_estimate, cumulative_se),
        row("lag_1", model.params["lag_1"], np.sqrt(cov.loc["lag_1", "lag_1"])),
        row("lag_15", model.params["lag_15"], np.sqrt(cov.loc["lag_15", "lag_15"])),
    ],
    "method_metadata": {
        "estimator": "OLS of log sales on an intercept and lags 1 through 15 of the first difference of log VIX",
        "vcov": "Newey-West HAC, maximum lag 15, Bartlett weights 1-j/16, scaled by N/(N-16)",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output, indent=2)
