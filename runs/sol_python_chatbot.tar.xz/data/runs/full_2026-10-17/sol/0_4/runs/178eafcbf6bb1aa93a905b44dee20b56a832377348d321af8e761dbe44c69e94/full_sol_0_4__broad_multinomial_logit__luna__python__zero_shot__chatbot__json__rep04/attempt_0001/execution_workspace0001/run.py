import json

import pandas as pd
import statsmodels.api as sm

data = pd.read_csv("input.csv")
X = sm.add_constant(data[["x", "z"]], has_constant="add")
model = sm.MNLogit(data["y"], X)
fit = model.fit(method="newton", disp=False)

n_obs = len(data)
estimates = []
for category, column in [(1, 0), (2, 1)]:
    for variable in ("x", "z"):
        estimates.append({
            "term": f"{variable}_cat{category}",
            "estimate": float(fit.params.loc[variable, column]),
            "se": float(fit.bse.loc[variable, column]),
            "n_obs": n_obs,
        })

at_zero = pd.DataFrame({"const": [1.0], "x": [0.0], "z": [0.0]})
prob_cat2_zero = float(fit.predict(at_zero).iloc[0, 2])
estimates.append({
    "term": "prob_cat2_zero",
    "estimate": prob_cat2_zero,
    "se": None,
    "n_obs": n_obs,
})

result = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "multinomial logit maximum likelihood; outcome 0 as base",
        "vcov": "inverse observed information",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file, indent=2)
