import json

import numpy as np
import pandas as pd


def main():
    crosswalk = pd.read_csv("crosswalk.csv")
    trade = pd.read_csv("trade.csv").merge(
        crosswalk, on="code", how="left", validate="many_to_one"
    )
    areas = pd.read_csv("areas.csv")
    employment = pd.read_csv("employment.csv")
    outcomes = pd.read_csv("outcomes.csv")

    industries = crosswalk["industry"].drop_duplicates()
    area_industry = areas.merge(
        industries.to_frame(), how="cross"
    ).merge(
        employment,
        on=["area", "period", "vintage", "industry"],
        how="left",
        validate="one_to_one",
    )
    area_industry["employment"] = area_industry["employment"].fillna(0.0)

    national = (
        area_industry.groupby(["period", "vintage", "industry"], as_index=False)[
            "employment"
        ]
        .sum()
        .rename(columns={"employment": "national_employment"})
    )
    area_industry = area_industry.merge(
        national,
        on=["period", "vintage", "industry"],
        validate="many_to_one",
    ).merge(
        trade[
            [
                "period",
                "industry",
                "us_change",
                "other_change",
                "price_index",
                "years",
            ]
        ],
        on=["period", "industry"],
        validate="many_to_one",
    )

    change = np.where(
        area_industry["vintage"].eq("base"),
        area_industry["us_change"],
        area_industry["other_change"],
    )
    area_industry["contribution"] = (
        area_industry["employment"]
        / area_industry["total_employment"]
        * change
        / area_industry["national_employment"]
        / (area_industry["price_index"] / 100.0)
        / 1000.0
        * (10.0 / area_industry["years"])
    )
    exposures = (
        area_industry.groupby(["area", "period", "vintage"], as_index=False)[
            "contribution"
        ]
        .sum()
        .pivot(index=["area", "period"], columns="vintage", values="contribution")
        .rename(columns={"base": "x", "early": "z"})
        .reset_index()
    )

    base_areas = areas.loc[
        areas["vintage"].eq("base"), ["area", "period", "population"]
    ]
    data = (
        outcomes.merge(exposures, on=["area", "period"], validate="one_to_one")
        .merge(base_areas, on=["area", "period"], validate="one_to_one")
        .sort_values(["period", "area"])
    )
    if len(data) != 72 or data[["change_pp", "period", "control", "x", "z", "population"]].isna().any().any():
        raise ValueError("The estimation sample must contain 72 complete rows.")

    y = data["change_pp"].to_numpy(dtype=float)
    x_matrix = np.column_stack(
        [np.ones(len(data)), data["period"], data["control"], data["x"]]
    ).astype(float)
    z_matrix = np.column_stack(
        [np.ones(len(data)), data["period"], data["control"], data["z"]]
    ).astype(float)
    weights = data["population"].to_numpy(dtype=float)

    # With one endogenous regressor and one excluded instrument, weighted
    # 2SLS is exactly identified by these four weighted moment equations.
    coefficients = np.linalg.solve(
        z_matrix.T @ (weights[:, None] * x_matrix),
        z_matrix.T @ (weights * y),
    )

    def exposure_at(area, period, column):
        row = data.loc[(data["area"] == area) & (data["period"] == period)]
        if len(row) != 1:
            raise ValueError(f"Expected one row for area {area}, period {period}.")
        return float(row.iloc[0][column])

    estimates = [
        ("iv_slope", float(coefficients[-1])),
        ("exposure_area0_period0", exposure_at(0, 0, "x")),
        ("exposure_area0_period1", exposure_at(0, 1, "x")),
        ("instrument_area0_period0", exposure_at(0, 0, "z")),
    ]
    result = {
        "task_id": "applied_multivintage_trade_iv",
        "platform": "python",
        "estimates": [
            {"term": term, "estimate": value, "se": None, "n_obs": 72}
            for term, value in estimates
        ],
        "method_metadata": {
            "estimator": "population-weighted 2SLS",
            "outcome": "change_pp",
            "endogenous_regressor": "x",
            "excluded_instrument": "z",
            "exogenous_columns": ["intercept", "period", "control"],
            "exposure_units": "thousands of real dollars per worker per decade",
        },
        "diagnostics": {
            "n_obs": 72,
            "number_of_industries": int(len(industries)),
        },
    }
    with open("result.json", "w", encoding="utf-8") as file:
        json.dump(result, file, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
