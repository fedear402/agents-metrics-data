import json

import pandas as pd
from scipy.stats import f

data = pd.read_csv("./input.csv")
data["y"] = pd.to_numeric(data["y"], errors="coerce")
data = data.dropna(subset=["group", "y"])

groups = list(data.groupby("group", sort=False)["y"])
n_obs = len(data)
df_num = len(groups) - 1
df_den = n_obs - len(groups)

if df_num < 1 or df_den < 1:
    raise ValueError("ANOVA requires at least two groups and positive residual degrees of freedom.")

grand_mean = data["y"].mean()
ss_between = sum(len(values) * (values.mean() - grand_mean) ** 2 for _, values in groups)
ss_within = sum(((values - values.mean()) ** 2).sum() for _, values in groups)

if ss_within == 0:
    raise ValueError("The F statistic is undefined when within-group variation is zero.")

f_stat = float((ss_between / df_num) / (ss_within / df_den))
p_value = float(f.sf(f_stat, df_num, df_den))

result = {
    "task_id": "anova_oneway",
    "platform": "python",
    "estimates": [
        {"term": term, "estimate": float(value), "se": None, "n_obs": n_obs}
        for term, value in (
            ("F", f_stat),
            ("df_num", df_num),
            ("df_den", df_den),
            ("p_value", p_value),
        )
    ],
    "method_metadata": {
        "estimator": "Classical one-way ANOVA",
        "vcov": "Pooled within-group variance",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output, allow_nan=False)
