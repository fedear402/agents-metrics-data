import csv
import json

import numpy as np


def read_csv(path):
    with open(path, newline="", encoding="utf-8-sig") as file:
        return list(csv.DictReader(file))


crosswalk = read_csv("crosswalk.csv")
trade = read_csv("trade.csv")
areas = read_csv("areas.csv")
employment = read_csv("employment.csv")
outcomes = read_csv("outcomes.csv")

industry_by_code = {row["code"]: row["industry"] for row in crosswalk}
industries = set(industry_by_code.values())
assert len(industries) == 4

trade_by_period_industry = {}
for row in trade:
    key = (row["period"], industry_by_code[row["code"]])
    assert key not in trade_by_period_industry
    trade_by_period_industry[key] = row

area_by_key = {
    (row["area"], row["period"], row["vintage"]): row
    for row in areas
}

employment_by_key = {
    (row["area"], row["period"], row["vintage"], row["industry"]):
        float(row["employment"])
    for row in employment
}

national_employment = {}
for (area, period, vintage, industry), value in employment_by_key.items():
    key = (period, vintage, industry)
    national_employment[key] = national_employment.get(key, 0.0) + value


def exposure(area, period, vintage, change_column):
    area_row = area_by_key[(area, period, vintage)]
    total_employment = float(area_row["total_employment"])
    result = 0.0

    for industry in industries:
        trade_row = trade_by_period_industry[(period, industry)]
        area_employment = employment_by_key.get(
            (area, period, vintage, industry), 0.0
        )
        national_base = national_employment[(period, vintage, industry)]
        price_index = float(trade_row["price_index"])
        years = float(trade_row["years"])
        trade_change = float(trade_row[change_column])

        result += (
            (area_employment / total_employment)
            * (trade_change / national_base)
            / (price_index / 100.0)
            / 1000.0
            * (10.0 / years)
        )

    return result


X_rows = []
Z_rows = []
y_values = []
weights = []
exposures = {}

for row in outcomes:
    area = row["area"]
    period = row["period"]
    x = exposure(area, period, "base", "us_change")
    z = exposure(area, period, "early", "other_change")
    exposures[(area, period)] = (x, z)

    period_value = float(period)
    control = float(row["control"])
    exogenous = [1.0, period_value, control]

    X_rows.append(exogenous + [x])
    Z_rows.append(exogenous + [z])
    y_values.append(float(row["change_pp"]))
    weights.append(
        float(area_by_key[(area, period, "base")]["population"])
    )

n_obs = len(y_values)
assert n_obs == 72

X = np.asarray(X_rows, dtype=float)
Z = np.asarray(Z_rows, dtype=float)
y = np.asarray(y_values, dtype=float)
w = np.asarray(weights, dtype=float)

# The model is exactly identified. Weighted 2SLS solves Z' W X beta = Z' W y.
beta = np.linalg.solve(Z.T @ (w[:, None] * X), Z.T @ (w * y))


def estimate(term, value):
    return {
        "term": term,
        "estimate": float(value),
        "se": None,
        "n_obs": n_obs,
    }


result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [
        estimate("iv_slope", beta[3]),
        estimate("exposure_area0_period0", exposures[("0", "0")][0]),
        estimate("exposure_area0_period1", exposures[("0", "1")][0]),
        estimate("instrument_area0_period0", exposures[("0", "0")][1]),
    ],
    "method_metadata": {
        "estimator": "population-weighted 2SLS",
        "regressors": ["intercept", "period", "control", "x"],
        "instruments": ["intercept", "period", "control", "z"],
        "weight": "base-vintage population",
        "exposure_units": "thousands of real dollars per worker per decade",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "n_industries": len(industries),
        "weighted_iv_matrix_rank": int(
            np.linalg.matrix_rank(Z.T @ (w[:, None] * X))
        ),
    },
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file, indent=2, allow_nan=False)
