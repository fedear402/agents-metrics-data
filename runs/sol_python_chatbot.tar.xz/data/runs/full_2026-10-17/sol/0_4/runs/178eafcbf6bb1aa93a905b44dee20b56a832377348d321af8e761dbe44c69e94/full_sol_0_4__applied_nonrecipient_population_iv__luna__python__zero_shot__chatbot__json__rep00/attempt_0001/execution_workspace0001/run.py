import csv
import json

import numpy as np


def read_csv(path):
    with open(path, newline="", encoding="utf-8-sig") as file:
        return list(csv.DictReader(file))


households = [row for row in read_csv("households.csv") if int(row["recipient"]) == 0]
census = read_csv("census.csv")

eligible = np.array([int(row["eligible"]) for row in households])
dose = np.array([float(row["dose"]) for row in households])
instrument = np.array([float(row["instrument"]) for row in households])
baseline = np.array([float(row["baseline"]) for row in households])
weight = np.array([float(row["weight"]) for row in households])
outcome = np.array([float(row["outcome"]) for row in households])

if len(households) == 0 or np.any(weight <= 0):
    raise ValueError("The estimation sample must be nonempty and have positive weights.")
if not np.all(np.isin(eligible, [0, 1])):
    raise ValueError("Eligibility indicators must be zero or one.")

ineligible = 1 - eligible
exogenous = np.column_stack(
    (
        ineligible,
        eligible,
        baseline * ineligible,
        baseline * eligible,
    )
)
endogenous = np.column_stack((dose * ineligible, dose * eligible))
excluded = np.column_stack((instrument * ineligible, instrument * eligible))

X = np.column_stack((exogenous, endogenous))
Z = np.column_stack((exogenous, excluded))

# The six instruments identify the six regression coefficients.
coefficients = np.linalg.solve(Z.T @ (weight[:, None] * X), Z.T @ (weight * outcome))

mean_dose = {}
for group in (0, 1):
    mask = eligible == group
    if not np.any(mask):
        raise ValueError(f"No retained households have eligible={group}.")
    mean_dose[group] = float(np.average(dose[mask], weights=weight[mask]))

effects = {
    0: float(coefficients[4] * mean_dose[0]),
    1: float(coefficients[5] * mean_dose[1]),
}

population = {0: 0, 1: 0}
for row in census:
    group = int(row["eligible"])
    if group not in population:
        raise ValueError("Census eligibility indicators must be zero or one.")
    population[group] += int(row["nonrecipient_population"])

total_population = sum(population.values())
if total_population <= 0:
    raise ValueError("Total nonrecipient population must be positive.")

population_effect = sum(
    effects[group] * population[group] / total_population for group in (0, 1)
)
n_obs = len(households)

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {"term": "ineligible_effect", "estimate": effects[0], "se": None, "n_obs": n_obs},
        {
            "term": "eligible_nonrecipient_effect",
            "estimate": effects[1],
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "population_effect",
            "estimate": population_effect,
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "method": "Weighted, exactly identified two-stage least squares",
        "sample": "All households with recipient=0",
        "regression_weight": "weight",
        "counterfactual": "Set dose to zero for every retained household; attribution uses this synthetic convention.",
        "group_effect": "Fitted group dose slope times the household-weighted mean dose among retained households in that group.",
        "population_aggregation": "Census nonrecipient_population determines only the final between-group weights.",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "group_n_obs": {
            str(group): int(np.count_nonzero(eligible == group)) for group in (0, 1)
        },
        "group_weighted_mean_dose": {str(group): mean_dose[group] for group in (0, 1)},
        "group_dose_slope": {
            "0": float(coefficients[4]),
            "1": float(coefficients[5]),
        },
        "census_nonrecipient_population": {
            str(group): population[group] for group in (0, 1)
        },
    },
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file, indent=2, allow_nan=False)
