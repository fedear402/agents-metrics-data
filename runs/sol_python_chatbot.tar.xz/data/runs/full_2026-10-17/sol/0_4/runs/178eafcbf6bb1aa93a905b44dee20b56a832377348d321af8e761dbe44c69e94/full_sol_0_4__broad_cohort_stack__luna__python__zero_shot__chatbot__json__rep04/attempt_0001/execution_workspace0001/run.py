import csv
import json
from collections import defaultdict

with open("input.csv", newline="") as file:
    rows = [
        {
            "id": row["id"],
            "time": int(row["time"]),
            "g": int(row["g"]),
            "y": float(row["y"]),
        }
        for row in csv.DictReader(file)
    ]

estimates = []
weighted_sum = 0.0
total_weight = 0
total_obs = 0

for cohort in (3, 5, 7):
    times = tuple(range(cohort - 2, cohort + 3))
    eligible = defaultdict(dict)

    for row in rows:
        if row["time"] in times and (
            row["g"] == cohort or row["g"] == 0 or row["g"] > cohort + 2
        ):
            eligible[row["id"]][row["time"]] = row

    units = {
        unit_id: observations
        for unit_id, observations in eligible.items()
        if all(time in observations for time in times)
    }

    n_units = len(units)
    n_obs = n_units * len(times)
    treated_units = sum(
        observations[times[0]]["g"] == cohort
        for observations in units.values()
    )

    unit_y_mean = {
        unit_id: sum(observations[t]["y"] for t in times) / len(times)
        for unit_id, observations in units.items()
    }
    unit_did_mean = {
        unit_id: sum(
            observations[t]["g"] == cohort and t >= cohort for t in times
        ) / len(times)
        for unit_id, observations in units.items()
    }
    time_y_mean = {
        t: sum(observations[t]["y"] for observations in units.values()) / n_units
        for t in times
    }
    time_did_mean = {
        t: sum(
            observations[t]["g"] == cohort
            for observations in units.values()
        ) / n_units
        if t >= cohort else 0.0
        for t in times
    }

    grand_y_mean = sum(unit_y_mean.values()) / n_units
    grand_did_mean = sum(unit_did_mean.values()) / n_units

    numerator = 0.0
    denominator = 0.0
    for unit_id, observations in units.items():
        for t in times:
            did = float(observations[t]["g"] == cohort and t >= cohort)
            residual_did = (
                did - unit_did_mean[unit_id] - time_did_mean[t]
                + grand_did_mean
            )
            residual_y = (
                observations[t]["y"] - unit_y_mean[unit_id]
                - time_y_mean[t] + grand_y_mean
            )
            numerator += residual_did * residual_y
            denominator += residual_did * residual_did

    estimate = numerator / denominator
    estimates.append({
        "term": f"att_g{cohort}",
        "estimate": estimate,
        "se": None,
        "n_obs": n_obs,
    })
    weighted_sum += treated_units * estimate
    total_weight += treated_units
    total_obs += n_obs

estimates.append({
    "term": "att_weighted",
    "estimate": weighted_sum / total_weight,
    "se": None,
    "n_obs": total_obs,
})

result = {
    "task_id": "broad_cohort_stack",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {},
    "diagnostics": {},
}

with open("result.json", "w") as file:
    json.dump(result, file, indent=2)
