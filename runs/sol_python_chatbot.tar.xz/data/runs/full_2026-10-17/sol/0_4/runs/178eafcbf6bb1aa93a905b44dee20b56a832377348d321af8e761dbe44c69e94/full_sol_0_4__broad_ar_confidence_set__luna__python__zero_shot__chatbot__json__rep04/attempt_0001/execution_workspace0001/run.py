import json

import numpy as np
import pandas as pd
from scipy.stats import f

data = pd.read_csv("input.csv")
n = len(data)

y = data["y"].to_numpy(dtype=float)
d = data["endog"].to_numpy(dtype=float)
x = data["x"].to_numpy(dtype=float)
z = data[["z1", "z2"]].to_numpy(dtype=float)

w = np.column_stack((np.ones(n), x))
full = np.column_stack((w, z))

def residual(v, design):
    return v - design @ np.linalg.lstsq(design, v, rcond=None)[0]

ry, rd = residual(y, w), residual(d, w)
uy, ud = residual(y, full), residual(d, full)

# The restricted-minus-unrestricted sum of squares is quadratic in beta.
py, pd_ = ry - uy, rd - ud
num = np.array([pd_ @ pd_, -2 * py @ pd_, py @ py])
den = np.array([ud @ ud, -2 * uy @ ud, uy @ uy])

critical = f.ppf(0.95, 2, n - 4)
coeff = (n - 4) * num - 2 * critical * den
roots = np.roots(coeff)
if len(roots) != 2 or np.any(np.abs(roots.imag) > 1e-8):
    raise ValueError("Expected two finite real confidence-set boundaries")
boundary_low, boundary_high = sorted(roots.real.tolist())

def ar_f(beta):
    numerator = np.polyval(num, beta)
    denominator = np.polyval(den, beta)
    return float((n - 4) * numerator / (2 * denominator))

accepts_zero = float(ar_f(0.0) <= critical)
unbounded = float(coeff[0] < 0)

values = {
    "boundary_low": boundary_low,
    "boundary_high": boundary_high,
    "accepts_zero": accepts_zero,
    "unbounded": unbounded,
    "ar_f_at_one": ar_f(1.0),
}

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": [
        {"term": term, "estimate": float(value), "se": None, "n_obs": n}
        for term, value in values.items()
    ],
    "method_metadata": {
        "estimator": "Anderson-Rubin confidence set by analytic inversion of the joint F test",
        "vcov": "Conventional homoskedastic OLS",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file)
