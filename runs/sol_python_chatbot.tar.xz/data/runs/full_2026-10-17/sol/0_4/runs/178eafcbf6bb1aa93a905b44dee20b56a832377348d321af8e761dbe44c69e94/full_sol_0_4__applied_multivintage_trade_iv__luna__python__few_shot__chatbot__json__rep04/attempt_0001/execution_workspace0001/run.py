import json

import numpy as np
import pandas as pd

TASK_ID = "applied_multivintage_trade_iv"
N_OBS = 72

crosswalk = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv")
areas = pd.read_csv("areas.csv")
employment = pd.read_csv("employment.csv")
outcomes = pd.read_csv("outcomes.csv")

trade = trade.merge(crosswalk, on="code", how="inner", validate="many_to_one")

# Omitted area-industry employment cells have zero employment.
area_keys = areas[["area", "period", "vintage"]].drop_duplicates()
industries = crosswalk[["industry"]].drop_duplicates()
cells = area_keys.merge(industries, how="cross")
cells = cells.merge(
    employment,
    on=["area", "period", "vintage", "industry"],
    how="left",
    validate="one_to_one",
)
cells["employment"] = cells["employment"].fillna(0.0)

national = (
    cells.groupby(["period", "vintage", "industry"], as_index=False)["employment"]
    .sum()
    .rename(columns={"employment": "national_employment"})
)
cells = cells.merge(
    national,
    on=["period", "vintage", "industry"],
    validate="many_to_one",
)
cells = cells.merge(
    areas,
    on=["area", "period", "vintage"],
    validate="many_to_one",
)
cells = cells.merge(
    trade[["period", "industry", "us_change", "other_change", "price_index", "years"]],
    on=["period", "industry"],
    validate="many_to_one",
)

change_column = np.where(cells["vintage"].eq("base"), "us_change", "other_change")
change = np.where(
    change_column == "us_change",
    cells["us_change"],
    cells["other_change"],
)
cells["contribution"] = (
    (cells["employment"] / cells["total_employment"])
    * (change / cells["national_employment"])
    / (cells["price_index"] / 100.0)
    / 1000.0
    * (10.0 / cells["years"])
)

exposures = (
    cells.groupby(["area", "period", "vintage"], as_index=False)["contribution"]
    .sum()
    .rename(columns={"contribution": "exposure"})
)
wide = exposures.pivot(
    index=["area", "period"], columns="vintage", values="exposure"
).reset_index()
wide.columns.name = None
wide = wide.rename(columns={"base": "x", "early": "z"})

base_areas = areas.loc[
    areas["vintage"].eq("base"), ["area", "period", "population"]
]
sample = (
    outcomes.merge(wide, on=["area", "period"], validate="one_to_one")
    .merge(base_areas, on=["area", "period"], validate="one_to_one")
    .sort_values(["area", "period"])
    .reset_index(drop=True)
)
assert len(sample) == N_OBS
assert sample[["change_pp", "period", "control", "x", "z", "population"]].notna().all().all()

# Weighted 2SLS includes the intercept, period, and control in both matrices.
y = sample["change_pp"].to_numpy(dtype=float)
X = np.column_stack((
    np.ones(N_OBS),
    sample["period"].to_numpy(dtype=float),
    sample["control"].to_numpy(dtype=float),
    sample["x"].to_numpy(dtype=float),
))
Z = np.column_stack((
    np.ones(N_OBS),
    sample["period"].to_numpy(dtype=float),
    sample["control"].to_numpy(dtype=float),
    sample["z"].to_numpy(dtype=float),
))
sqrt_weight = np.sqrt(sample["population"].to_numpy(dtype=float))
Xw = X * sqrt_weight[:, None]
Zw = Z * sqrt_weight[:, None]
yw = y * sqrt_weight

projected_X = Zw @ np.linalg.solve(Zw.T @ Zw, Zw.T @ Xw)
beta = np.linalg.solve(projected_X.T @ Xw, projected_X.T @ yw)

def exposure_at(area, period, column):
    row = sample.loc[
        sample["area"].eq(area) & sample["period"].eq(period), column
    ]
    assert len(row) == 1
    return float(row.iloc[0])

values = {
    "iv_slope": float(beta[-1]),
    "exposure_area0_period0": exposure_at(0, 0, "x"),
    "exposure_area0_period1": exposure_at(0, 1, "x"),
    "instrument_area0_period0": exposure_at(0, 0, "z"),
}

result = {
    "task_id": TASK_ID,
    "platform": "python",
    "estimates": [
        {"term": term, "estimate": value, "se": None, "n_obs": N_OBS}
        for term, value in values.items()
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "outcome": "change_pp",
        "endogenous_regressor": "x",
        "excluded_instrument": "z",
        "exogenous_instruments": ["intercept", "period", "control"],
        "weight": "base-vintage population",
        "exposure_unit": "thousands of real dollars per worker per decade",
    },
    "diagnostics": {"estimation_rows": N_OBS},
}

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output, indent=2, allow_nan=False)
