import csv
import json
import math

import numpy as np


def read_csv(path):
    with open(path, newline="", encoding="utf-8-sig") as file:
        return list(csv.DictReader(file))


households = read_csv("households.csv")
census = read_csv("census.csv")

rows = [row for row in households if int(row["recipient"]) == 0]
n_obs = len(rows)

eligible = np.array([int(row["eligible"]) for row in rows], dtype=int)
dose = np.array([float(row["dose"]) for row in rows], dtype=float)
baseline = np.array([float(row["baseline"]) for row in rows], dtype=float)
instrument = np.array([float(row["instrument"]) for row in rows], dtype=float)
weight = np.array([float(row["weight"]) for row in rows], dtype=float)
outcome = np.array([float(row["outcome"]) for row in rows], dtype=float)

if n_obs == 0 or not np.all(np.isin(eligible, [0, 1])):
    raise ValueError("The estimation sample must contain valid eligibility groups.")
if not np.all(np.isfinite(weight)) or np.any(weight <= 0):
    raise ValueError("Regression weights must be finite and positive.")

ineligible = 1 - eligible
group_columns = np.column_stack(
    (
        ineligible,
        eligible,
        baseline * ineligible,
        baseline * eligible,
    )
)
endogenous = np.column_stack((dose * ineligible, dose * eligible))
excluded = np.column_stack(
    (instrument * ineligible, instrument * eligible)
)

x = np.column_stack((group_columns, endogenous))
z = np.column_stack((group_columns, excluded))

sqrt_weight = np.sqrt(weight)
x_weighted = x * sqrt_weight[:, None]
z_weighted = z * sqrt_weight[:, None]
y_weighted = outcome * sqrt_weight

if np.linalg.matrix_rank(z_weighted) < z.shape[1]:
    raise ValueError("The weighted instrument matrix lacks full column rank.")

first_stage = np.linalg.lstsq(z_weighted, x_weighted, rcond=None)[0]
fitted_x = z_weighted @ first_stage
if np.linalg.matrix_rank(fitted_x) < x.shape[1]:
    raise ValueError("The weighted 2SLS design lacks full column rank.")

coefficients = np.linalg.lstsq(fitted_x, y_weighted, rcond=None)[0]
weighted_mean_dose = {
    group: float(np.average(dose[eligible == group], weights=weight[eligible == group]))
    for group in (0, 1)
}
group_effect = {
    0: float(coefficients[4] * weighted_mean_dose[0]),
    1: float(coefficients[5] * weighted_mean_dose[1]),
}

population = {0: 0, 1: 0}
for row in census:
    group = int(row["eligible"])
    count = int(row["nonrecipient_population"])
    if group not in population or count < 0:
        raise ValueError("Census groups and counts must be valid.")
    population[group] += count

total_population = population[0] + population[1]
if total_population <= 0:
    raise ValueError("Total nonrecipient population must be positive.")

population_effect = sum(
    group_effect[group] * population[group] / total_population
    for group in (0, 1)
)

estimates = [
    {
        "term": "ineligible_effect",
        "estimate": group_effect[0],
        "se": None,
        "n_obs": n_obs,
    },
    {
        "term": "eligible_nonrecipient_effect",
        "estimate": group_effect[1],
        "se": None,
        "n_obs": n_obs,
    },
    {
        "term": "population_effect",
        "estimate": float(population_effect),
        "se": None,
        "n_obs": n_obs,
    },
]

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "weighted_2sls",
        "sample": "all household rows with recipient=0",
        "exogenous_columns": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
        ],
        "endogenous_columns": [
            "dose*(1-eligible)",
            "dose*eligible",
        ],
        "excluded_instruments": [
            "instrument*(1-eligible)",
            "instrument*eligible",
        ],
        "additional_intercept": False,
        "weight_column": "weight",
        "group_effect": "fitted group dose slope times household-weighted group mean dose",
        "counterfactual": "dose=0 for every retained household; synthetic attribution convention",
        "population_aggregation": "census nonrecipient_population weights only",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "weighted_mean_dose": {
            "ineligible": weighted_mean_dose[0],
            "eligible_nonrecipient": weighted_mean_dose[1],
        },
        "dose_slopes": {
            "ineligible": float(coefficients[4]),
            "eligible_nonrecipient": float(coefficients[5]),
        },
        "nonrecipient_population": {
            "ineligible": population[0],
            "eligible_nonrecipient": population[1],
            "total": total_population,
        },
    },
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file, indent=2, allow_nan=False)
