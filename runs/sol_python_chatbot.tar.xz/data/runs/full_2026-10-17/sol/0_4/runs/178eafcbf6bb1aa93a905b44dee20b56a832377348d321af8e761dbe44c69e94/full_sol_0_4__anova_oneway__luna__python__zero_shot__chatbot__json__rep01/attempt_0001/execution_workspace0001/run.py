import json

import pandas as pd
from scipy.stats import f

data = pd.read_csv("./input.csv")
data["y"] = pd.to_numeric(data["y"], errors="coerce")
data = data.dropna(subset=["group", "y"])

groups = data.groupby("group")["y"]
n_obs = len(data)
n_groups = groups.ngroups
df_num = n_groups - 1
df_den = n_obs - n_groups

if df_num <= 0 or df_den <= 0:
    raise ValueError("One-way ANOVA requires at least two groups and residual degrees of freedom.")

grand_mean = data["y"].mean()
between_ss = sum(len(values) * (values.mean() - grand_mean) ** 2 for _, values in groups)
within_ss = sum(((values - values.mean()) ** 2).sum() for _, values in groups)

if within_ss == 0:
    f_stat = float("inf") if between_ss > 0 else float("nan")
else:
    f_stat = float((between_ss / df_num) / (within_ss / df_den))

p_value = float(f.sf(f_stat, df_num, df_den))

def row(term, estimate):
    return {"term": term, "estimate": float(estimate), "se": None, "n_obs": n_obs}

result = {
    "task_id": "anova_oneway",
    "platform": "python",
    "estimates": [
        row("F", f_stat),
        row("df_num", df_num),
        row("df_den", df_den),
        row("p_value", p_value),
    ],
    "method_metadata": {
        "estimator": "Classical one-way ANOVA",
        "vcov": "Pooled within-group variance",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output, allow_nan=False)
