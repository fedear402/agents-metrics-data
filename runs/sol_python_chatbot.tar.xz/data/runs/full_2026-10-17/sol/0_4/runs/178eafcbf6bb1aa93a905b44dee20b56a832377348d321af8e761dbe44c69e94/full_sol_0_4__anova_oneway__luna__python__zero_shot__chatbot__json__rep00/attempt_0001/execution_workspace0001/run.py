import json

import pandas as pd
from scipy.stats import f

data = pd.read_csv("./input.csv")
data["y"] = pd.to_numeric(data["y"], errors="coerce")
data = data.dropna(subset=["group", "y"])

groups = [values["y"].to_numpy() for _, values in data.groupby("group")]
n_obs = sum(len(values) for values in groups)
df_num = len(groups) - 1
df_den = n_obs - len(groups)

if df_num < 1 or df_den < 1:
    raise ValueError("ANOVA requires at least two groups and positive residual degrees of freedom.")

grand_mean = data["y"].mean()
ss_between = sum(len(values) * (values.mean() - grand_mean) ** 2 for values in groups)
ss_within = sum(((values - values.mean()) ** 2).sum() for values in groups)
f_stat = float((ss_between / df_num) / (ss_within / df_den))
p_value = float(f.sf(f_stat, df_num, df_den))

result = {
    "task_id": "anova_oneway",
    "platform": "python",
    "estimates": [
        {"term": "F", "estimate": f_stat, "se": None, "n_obs": n_obs},
        {"term": "df_num", "estimate": float(df_num), "se": None, "n_obs": n_obs},
        {"term": "df_den", "estimate": float(df_den), "se": None, "n_obs": n_obs},
        {"term": "p_value", "estimate": p_value, "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "Classical one-way ANOVA",
        "vcov": "Pooled within-group variance",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output, indent=2, allow_nan=False)
