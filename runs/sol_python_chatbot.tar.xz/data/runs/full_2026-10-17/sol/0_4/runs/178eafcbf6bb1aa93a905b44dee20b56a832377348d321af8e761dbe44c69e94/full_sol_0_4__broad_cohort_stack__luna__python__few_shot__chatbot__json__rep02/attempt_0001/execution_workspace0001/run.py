import json

import numpy as np
import pandas as pd


def main():
    data = pd.read_csv("input.csv")
    estimates = []
    weighted_sum = 0.0
    treated_total = 0
    row_total = 0

    for cohort in (3, 5, 7):
        window = range(cohort - 2, cohort + 3)
        eligible = data["g"].eq(cohort) | data["g"].eq(0) | data["g"].gt(cohort + 2)
        subset = data.loc[eligible & data["time"].isin(window)].copy()

        balanced_ids = subset.groupby("id")["time"].nunique()
        balanced_ids = balanced_ids[balanced_ids.eq(5)].index
        subset = subset.loc[subset["id"].isin(balanced_ids)].copy()

        treated_count = subset.loc[subset["g"].eq(cohort), "id"].nunique()
        if treated_count == 0 or subset.loc[subset["g"].ne(cohort)].empty:
            raise ValueError(f"Cohort {cohort} lacks retained treated units or controls")

        subset["did"] = (
            subset["g"].eq(cohort) & subset["time"].ge(cohort)
        ).astype(float)

        unit_fe = pd.get_dummies(subset["id"], prefix="unit", drop_first=True, dtype=float)
        time_fe = pd.get_dummies(subset["time"], prefix="time", drop_first=True, dtype=float)
        design = np.column_stack(
            (
                np.ones(len(subset)),
                subset["did"].to_numpy(dtype=float),
                unit_fe.to_numpy(),
                time_fe.to_numpy(),
            )
        )
        outcome = subset["y"].to_numpy(dtype=float)
        coefficient = float(np.linalg.lstsq(design, outcome, rcond=None)[0][1])

        rows = len(subset)
        estimates.append(
            {"term": f"att_g{cohort}", "estimate": coefficient, "se": None, "n_obs": rows}
        )
        weighted_sum += treated_count * coefficient
        treated_total += treated_count
        row_total += rows

    estimates.append(
        {
            "term": "att_weighted",
            "estimate": weighted_sum / treated_total,
            "se": None,
            "n_obs": row_total,
        }
    )

    result = {
        "task_id": "broad_cohort_stack",
        "platform": "python",
        "estimates": estimates,
        "method_metadata": {},
        "diagnostics": {},
    }
    with open("result.json", "w", encoding="utf-8") as stream:
        json.dump(result, stream, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
