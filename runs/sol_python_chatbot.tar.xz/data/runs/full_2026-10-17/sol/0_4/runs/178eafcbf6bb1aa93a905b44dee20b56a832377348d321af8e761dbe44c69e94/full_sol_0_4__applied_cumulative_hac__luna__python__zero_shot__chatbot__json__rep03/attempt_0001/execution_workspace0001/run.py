import json

import numpy as np
import pandas as pd
import statsmodels.api as sm

data = pd.read_csv("input.csv")
data["date"] = pd.to_datetime(data["date"])
data = data.sort_values("date").reset_index(drop=True)

change = np.log(data["vix"]).diff()
lag_names = [f"lag_{i}" for i in range(1, 16)]
for i, name in enumerate(lag_names, start=1):
    data[name] = change.shift(i)

sample = data.dropna(subset=lag_names).copy()
y = np.log(sample["sales"])
X = sm.add_constant(sample[lag_names], has_constant="add")
fit = sm.OLS(y, X).fit()

n_obs = len(sample)
if n_obs <= 16:
    raise ValueError("The regression requires more than 16 complete observations.")

cov = np.asarray(
    sm.stats.sandwich_covariance.cov_hac(
        fit, nlags=15, weights_func=sm.stats.sandwich_covariance.weights_bartlett,
        use_correction=False,
    )
)
cov *= n_obs / (n_obs - 16)

params = np.asarray(fit.params)
positions = {name: i for i, name in enumerate(fit.params.index)}
weights = np.zeros(len(params))
for name in lag_names:
    weights[positions[name]] = 1.0

def row(term, estimate, variance):
    return {
        "term": term,
        "estimate": float(estimate),
        "se": float(np.sqrt(max(float(variance), 0.0))),
        "n_obs": int(n_obs),
    }

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        row("cumulative_response", weights @ params, weights @ cov @ weights),
        row("lag_1", params[positions["lag_1"]], cov[positions["lag_1"], positions["lag_1"]]),
        row("lag_15", params[positions["lag_15"]], cov[positions["lag_15"], positions["lag_15"]]),
    ],
    "method_metadata": {
        "estimator": "OLS of log(sales) on an intercept and lags 1–15 of Δlog(vix)",
        "vcov": "Newey-West HAC, maximum lag 15, Bartlett weights, scaled by N/(N-16)",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output)
