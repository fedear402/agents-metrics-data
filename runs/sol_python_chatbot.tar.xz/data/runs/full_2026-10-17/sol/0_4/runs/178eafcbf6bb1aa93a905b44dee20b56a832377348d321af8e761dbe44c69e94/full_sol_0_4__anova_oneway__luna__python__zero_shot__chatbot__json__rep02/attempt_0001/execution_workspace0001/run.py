import json

import pandas as pd
from scipy.stats import f

data = pd.read_csv("./input.csv")
data = data[["group", "y"]].dropna().copy()
data["y"] = pd.to_numeric(data["y"], errors="raise")

n_obs = len(data)
groups = data.groupby("group", observed=True)["y"]
k = groups.ngroups

if k < 2 or n_obs <= k:
    raise ValueError("ANOVA requires at least two groups and residual degrees of freedom.")

grand_mean = data["y"].mean()
between_ss = sum(len(values) * (values.mean() - grand_mean) ** 2 for _, values in groups)
within_ss = sum(((values - values.mean()) ** 2).sum() for _, values in groups)

df_num = k - 1
df_den = n_obs - k
if within_ss <= 0:
    raise ValueError("ANOVA requires positive within-group variation.")

f_stat = float((between_ss / df_num) / (within_ss / df_den))
p_value = float(f.sf(f_stat, df_num, df_den))

result = {
    "task_id": "anova_oneway",
    "platform": "python",
    "estimates": [
        {"term": "F", "estimate": f_stat, "se": None, "n_obs": n_obs},
        {"term": "df_num", "estimate": float(df_num), "se": None, "n_obs": n_obs},
        {"term": "df_den", "estimate": float(df_den), "se": None, "n_obs": n_obs},
        {"term": "p_value", "estimate": p_value, "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "Classical one-way ANOVA",
        "vcov": "Pooled within-group variance",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output, allow_nan=False)
