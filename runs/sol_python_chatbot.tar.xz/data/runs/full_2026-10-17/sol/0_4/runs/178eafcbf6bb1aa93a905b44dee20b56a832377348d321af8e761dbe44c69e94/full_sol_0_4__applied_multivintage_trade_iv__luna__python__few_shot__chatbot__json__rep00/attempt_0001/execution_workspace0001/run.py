import json

import numpy as np
import pandas as pd


crosswalk = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv")
areas = pd.read_csv("areas.csv")
employment = pd.read_csv("employment.csv")
outcomes = pd.read_csv("outcomes.csv")

trade = trade.merge(crosswalk, on="code", how="left", validate="many_to_one")

national = (
    employment.groupby(["period", "vintage", "industry"], as_index=False)["employment"]
    .sum()
    .rename(columns={"employment": "national_employment"})
)

area_industry = areas.merge(
    trade[
        [
            "period",
            "industry",
            "us_change",
            "other_change",
            "price_index",
            "years",
        ]
    ],
    on="period",
    how="inner",
    validate="many_to_many",
)

area_industry = area_industry.merge(
    employment,
    on=["area", "period", "vintage", "industry"],
    how="left",
    validate="one_to_one",
)
area_industry["employment"] = area_industry["employment"].fillna(0.0)

area_industry = area_industry.merge(
    national,
    on=["period", "vintage", "industry"],
    how="left",
    validate="many_to_one",
)

change_column = np.where(
    area_industry["vintage"].eq("base"),
    area_industry["us_change"],
    area_industry["other_change"],
)
area_industry["contribution"] = (
    area_industry["employment"]
    / area_industry["total_employment"]
    * change_column
    / area_industry["national_employment"]
    / (area_industry["price_index"] / 100.0)
    / 1000.0
    * (10.0 / area_industry["years"])
)

exposures = (
    area_industry.groupby(["area", "period", "vintage"], as_index=False)[
        "contribution"
    ]
    .sum()
    .pivot(index=["area", "period"], columns="vintage", values="contribution")
    .rename(columns={"base": "x", "early": "z"})
    .reset_index()
)

base_areas = areas.loc[
    areas["vintage"].eq("base"), ["area", "period", "population"]
]
sample = (
    outcomes.merge(exposures, on=["area", "period"], validate="one_to_one")
    .merge(base_areas, on=["area", "period"], validate="one_to_one")
)

n_obs = len(sample)
if n_obs != 72:
    raise ValueError(f"Expected 72 area-period observations, found {n_obs}")

y = sample["change_pp"].to_numpy(dtype=float)
w_sqrt = np.sqrt(sample["population"].to_numpy(dtype=float))
exogenous = np.column_stack(
    [
        np.ones(n_obs),
        sample["period"].to_numpy(dtype=float),
        sample["control"].to_numpy(dtype=float),
    ]
)
X = np.column_stack([exogenous, sample["x"].to_numpy(dtype=float)])
Z = np.column_stack([exogenous, sample["z"].to_numpy(dtype=float)])

Xw = X * w_sqrt[:, None]
Zw = Z * w_sqrt[:, None]
yw = y * w_sqrt

# The model is exactly identified: three exogenous columns and one instrument.
first_stage = np.linalg.solve(Zw.T @ Zw, Zw.T @ Xw)
fitted_Xw = Zw @ first_stage
coefficients = np.linalg.solve(fitted_Xw.T @ Xw, fitted_Xw.T @ yw)

def exposure_value(area, period, column):
    row = exposures.loc[
        exposures["area"].eq(area) & exposures["period"].eq(period),
        column,
    ]
    if len(row) != 1:
        raise ValueError(f"Expected one exposure for area {area}, period {period}")
    return float(row.iloc[0])


values = {
    "iv_slope": float(coefficients[-1]),
    "exposure_area0_period0": exposure_value(0, 0, "x"),
    "exposure_area0_period1": exposure_value(0, 1, "x"),
    "instrument_area0_period0": exposure_value(0, 0, "z"),
}

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [
        {"term": term, "estimate": value, "se": None, "n_obs": n_obs}
        for term, value in values.items()
    ],
    "method_metadata": {
        "estimator": "weighted two-stage least squares",
        "outcome": "change_pp",
        "endogenous_regressor": "x",
        "excluded_instrument": "z",
        "exogenous_columns": ["intercept", "period", "control"],
        "weight": "base-vintage population",
        "exposure_units": "thousands of real dollars per worker per decade",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "n_periods": int(sample["period"].nunique()),
        "n_areas": int(sample["area"].nunique()),
    },
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file, indent=2, allow_nan=False)
