import json

import numpy as np
import pandas as pd

data = pd.read_csv("input.csv", parse_dates=["date"]).sort_values("date")
data = data.reset_index(drop=True)

change = np.log(data["vix"]).diff()
regressors = pd.DataFrame(
    {f"lag_{j}": change.shift(j) for j in range(1, 16)}
)
sample = regressors.copy()
sample["log_sales"] = np.log(data["sales"])
sample = sample.dropna()

N = len(sample)
X = np.column_stack(
    [np.ones(N), sample[[f"lag_{j}" for j in range(1, 16)]].to_numpy()]
)
y = sample["log_sales"].to_numpy()

beta = np.linalg.lstsq(X, y, rcond=None)[0]
residuals = y - X @ beta
scores = X * residuals[:, None]

meat = scores.T @ scores
for j in range(1, 16):
    cross = scores[j:].T @ scores[:-j]
    meat += (1 - j / 16) * (cross + cross.T)

bread = np.linalg.inv(X.T @ X)
covariance = (N / (N - 16)) * bread @ meat @ bread

contrast = np.r_[0.0, np.ones(15)]
results = [
    (
        "cumulative_response",
        float(contrast @ beta),
        float(np.sqrt(contrast @ covariance @ contrast)),
    ),
    ("lag_1", float(beta[1]), float(np.sqrt(covariance[1, 1]))),
    ("lag_15", float(beta[15]), float(np.sqrt(covariance[15, 15]))),
]

output = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {"term": term, "estimate": estimate, "se": se, "n_obs": N}
        for term, estimate, se in results
    ],
    "method_metadata": {
        "estimator": "OLS with intercept and 15 observed-row lags of log VIX changes",
        "vcov": "Newey-West, Bartlett weights, maximum lag 15, N/(N-16) correction",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
