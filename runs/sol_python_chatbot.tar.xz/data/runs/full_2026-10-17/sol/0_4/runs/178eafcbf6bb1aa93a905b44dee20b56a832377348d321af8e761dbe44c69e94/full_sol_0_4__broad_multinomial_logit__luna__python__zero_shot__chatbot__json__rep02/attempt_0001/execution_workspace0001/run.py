import json

import pandas as pd
import statsmodels.api as sm


data = pd.read_csv("input.csv")
y = data["y"].astype(int)
X = sm.add_constant(data[["x", "z"]], has_constant="add")

model = sm.MNLogit(y, X)
fit = model.fit(method="newton", disp=False)
n_obs = int(len(data))

estimates = []
for outcome in (1, 2):
    column = outcome - 1
    for variable in ("x", "z"):
        estimates.append(
            {
                "term": f"{variable}_cat{outcome}",
                "estimate": float(fit.params.iloc[X.columns.get_loc(variable), column]),
                "se": float(fit.bse.iloc[X.columns.get_loc(variable), column]),
                "n_obs": n_obs,
            }
        )

zero = pd.DataFrame({"const": [1.0], "x": [0.0], "z": [0.0]})
prob_cat2_zero = float(fit.predict(zero)[2].iloc[0])
estimates.append(
    {
        "term": "prob_cat2_zero",
        "estimate": prob_cat2_zero,
        "se": None,
        "n_obs": n_obs,
    }
)

result = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "multinomial logit maximum likelihood; base outcome 0",
        "vcov": "inverse observed information",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output, indent=2)
