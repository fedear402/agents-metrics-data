import json

import numpy as np
import pandas as pd


def main():
    households = pd.read_csv("households.csv")
    census = pd.read_csv("census.csv")

    sample = households.loc[households["recipient"] == 0].copy()
    ineligible = (sample["eligible"] == 0).to_numpy(dtype=float)
    eligible = (sample["eligible"] == 1).to_numpy(dtype=float)
    baseline = sample["baseline"].to_numpy(dtype=float)
    dose = sample["dose"].to_numpy(dtype=float)
    instrument = sample["instrument"].to_numpy(dtype=float)
    outcome = sample["outcome"].to_numpy(dtype=float)
    weight = sample["weight"].to_numpy(dtype=float)

    exogenous = np.column_stack(
        [ineligible, eligible, baseline * ineligible, baseline * eligible]
    )
    endogenous = np.column_stack([dose * ineligible, dose * eligible])
    excluded = np.column_stack(
        [instrument * ineligible, instrument * eligible]
    )
    regressors = np.column_stack([exogenous, endogenous])
    instruments = np.column_stack([exogenous, excluded])

    sqrt_weight = np.sqrt(weight)
    weighted_regressors = regressors * sqrt_weight[:, None]
    weighted_instruments = instruments * sqrt_weight[:, None]
    weighted_outcome = outcome * sqrt_weight

    first_stage = np.linalg.lstsq(
        weighted_instruments, weighted_regressors, rcond=None
    )[0]
    fitted_regressors = weighted_instruments @ first_stage
    coefficients = np.linalg.lstsq(
        fitted_regressors, weighted_outcome, rcond=None
    )[0]

    group_effects = {}
    group_slopes = {}
    group_mean_doses = {}
    for group, indicator, slope_index in (
        (0, ineligible.astype(bool), 4),
        (1, eligible.astype(bool), 5),
    ):
        mean_dose = float(np.average(dose[indicator], weights=weight[indicator]))
        slope = float(coefficients[slope_index])
        group_mean_doses[group] = mean_dose
        group_slopes[group] = slope
        group_effects[group] = slope * mean_dose

    population = census.groupby("eligible")["nonrecipient_population"].sum()
    population_effect = float(
        np.average(
            [group_effects[0], group_effects[1]],
            weights=[population.loc[0], population.loc[1]],
        )
    )

    n_obs = int(len(sample))
    estimates = [
        {
            "term": term,
            "estimate": float(value),
            "se": None,
            "n_obs": n_obs,
        }
        for term, value in (
            ("ineligible_effect", group_effects[0]),
            ("eligible_nonrecipient_effect", group_effects[1]),
            ("population_effect", population_effect),
        )
    ]

    result = {
        "task_id": "applied_nonrecipient_population_iv",
        "platform": "python",
        "estimates": estimates,
        "method_metadata": {
            "estimator": "weighted two-stage least squares",
            "sample": "households with recipient == 0 in both village treatment statuses",
            "exogenous_columns": [
                "1-eligible",
                "eligible",
                "baseline*(1-eligible)",
                "baseline*eligible",
            ],
            "endogenous_columns": [
                "dose*(1-eligible)",
                "dose*eligible",
            ],
            "excluded_instruments": [
                "instrument*(1-eligible)",
                "instrument*eligible",
            ],
            "additional_intercept": False,
            "regression_weight": "weight",
            "group_effect": "group dose slope times household-weighted group mean dose",
            "population_aggregation": "nonrecipient_population census counts",
            "counterfactual": "dose set to zero for every retained household",
            "attribution": "zero-dose attribution is a stated synthetic convention",
        },
        "diagnostics": {
            "n_obs": n_obs,
            "group_slopes": {
                "ineligible": group_slopes[0],
                "eligible_nonrecipient": group_slopes[1],
            },
            "weighted_mean_dose": {
                "ineligible": group_mean_doses[0],
                "eligible_nonrecipient": group_mean_doses[1],
            },
        },
    }

    with open("result.json", "w", encoding="utf-8") as output:
        json.dump(result, output, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
