import json

import numpy as np
import pandas as pd
import statsmodels.api as sm
from statsmodels.stats.sandwich_covariance import cov_hac

df = pd.read_csv("input.csv")
df["date"] = pd.to_datetime(df["date"])
df = df.sort_values("date").reset_index(drop=True)

change = np.log(df["vix"]).diff()
lag_columns = [f"lag_{j}" for j in range(1, 16)]
for j, column in enumerate(lag_columns, start=1):
    df[column] = change.shift(j)

sample = df.dropna(subset=lag_columns).copy()
y = np.log(sample["sales"])
X = sm.add_constant(sample[lag_columns], has_constant="add")
fit = sm.OLS(y, X).fit()

n_obs = len(sample)
covariance = cov_hac(fit, nlags=15, use_correction=False)
covariance *= n_obs / (n_obs - 16)

parameters = fit.params
positions = {name: i for i, name in enumerate(parameters.index)}
lag_positions = [positions[name] for name in lag_columns]

cumulative_estimate = float(parameters[lag_columns].sum())
cumulative_variance = float(
    covariance[np.ix_(lag_positions, lag_positions)].sum()
)

def row(term, estimate, variance):
    return {
        "term": term,
        "estimate": float(estimate),
        "se": float(np.sqrt(max(variance, 0.0))),
        "n_obs": n_obs,
    }

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        row("cumulative_response", cumulative_estimate, cumulative_variance),
        row(
            "lag_1",
            parameters["lag_1"],
            covariance[positions["lag_1"], positions["lag_1"]],
        ),
        row(
            "lag_15",
            parameters["lag_15"],
            covariance[positions["lag_15"], positions["lag_15"]],
        ),
    ],
    "method_metadata": {
        "estimator": "OLS with intercept and lags 1 through 15 of log(vix) changes",
        "vcov": "Newey-West HAC, Bartlett weights, maximum lag 15, scaled by N/(N-16)",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output, indent=2)
