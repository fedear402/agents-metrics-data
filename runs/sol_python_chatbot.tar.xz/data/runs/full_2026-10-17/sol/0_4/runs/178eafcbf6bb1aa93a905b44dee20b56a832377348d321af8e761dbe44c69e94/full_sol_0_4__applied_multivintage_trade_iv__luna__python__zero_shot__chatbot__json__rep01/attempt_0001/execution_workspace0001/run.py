import json

import numpy as np
import pandas as pd


TASK_ID = "applied_multivintage_trade_iv"


def main():
    crosswalk = pd.read_csv("crosswalk.csv")
    trade = pd.read_csv("trade.csv")
    areas = pd.read_csv("areas.csv")
    employment = pd.read_csv("employment.csv")
    outcomes = pd.read_csv("outcomes.csv")

    trade = trade.merge(crosswalk, on="code", how="left", validate="many_to_one")
    if trade["industry"].isna().any():
        raise ValueError("Every trade code must map to an industry.")

    keys = ["area", "period", "vintage"]
    industries = crosswalk["industry"].drop_duplicates()
    if len(industries) != 4:
        raise ValueError("Expected four industries.")

    cells = areas[keys].merge(
        pd.DataFrame({"industry": industries}), how="cross"
    )
    cells = cells.merge(
        employment[keys + ["industry", "employment"]],
        on=keys + ["industry"],
        how="left",
        validate="one_to_one",
    )
    cells["employment"] = cells["employment"].fillna(0.0)

    national = (
        cells.groupby(["period", "vintage", "industry"], as_index=False)["employment"]
        .sum()
        .rename(columns={"employment": "national_employment"})
    )
    cells = cells.merge(
        national,
        on=["period", "vintage", "industry"],
        validate="many_to_one",
    ).merge(
        areas[keys + ["total_employment"]],
        on=keys,
        validate="many_to_one",
    ).merge(
        trade[
            [
                "period",
                "industry",
                "us_change",
                "other_change",
                "price_index",
                "years",
            ]
        ],
        on=["period", "industry"],
        validate="many_to_one",
    )

    if (cells["national_employment"] <= 0).any():
        raise ValueError("National industry employment must be positive.")

    common = (
        (cells["employment"] / cells["total_employment"])
        / cells["national_employment"]
        / (cells["price_index"] / 100.0)
        / 1000.0
        * (10.0 / cells["years"])
    )
    cells["contribution"] = np.where(
        cells["vintage"].eq("base"),
        common * cells["us_change"],
        common * cells["other_change"],
    )

    exposure = (
        cells.groupby(keys, as_index=False)["contribution"]
        .sum()
        .pivot(index=["area", "period"], columns="vintage", values="contribution")
        .rename(columns={"base": "x", "early": "z"})
        .reset_index()
    )

    base_areas = areas.loc[
        areas["vintage"].eq("base"),
        ["area", "period", "population"],
    ]
    sample = (
        outcomes.merge(
            exposure[["area", "period", "x", "z"]],
            on=["area", "period"],
            validate="one_to_one",
        )
        .merge(
            base_areas,
            on=["area", "period"],
            validate="one_to_one",
        )
    )
    if len(sample) != 72:
        raise ValueError(f"Expected 72 estimation rows, found {len(sample)}.")
    if sample[["change_pp", "period", "control", "x", "z", "population"]].isna().any().any():
        raise ValueError("Estimation sample contains missing values.")

    exogenous = np.column_stack(
        [
            np.ones(len(sample)),
            sample["period"].to_numpy(dtype=float),
            sample["control"].to_numpy(dtype=float),
        ]
    )
    regressors = np.column_stack(
        [exogenous, sample["x"].to_numpy(dtype=float)]
    )
    instruments = np.column_stack(
        [exogenous, sample["z"].to_numpy(dtype=float)]
    )
    outcome = sample["change_pp"].to_numpy(dtype=float)
    weights = sample["population"].to_numpy(dtype=float)
    if (weights <= 0).any():
        raise ValueError("Regression weights must be positive.")

    # Exactly identified weighted 2SLS: Z' W X beta = Z' W y.
    beta = np.linalg.solve(
        instruments.T @ (weights[:, None] * regressors),
        instruments.T @ (weights * outcome),
    )

    def exposure_value(area, period, column):
        rows = exposure.loc[
            exposure["area"].eq(area) & exposure["period"].eq(period),
            column,
        ]
        if len(rows) != 1:
            raise ValueError(f"Expected one exposure for area {area}, period {period}.")
        return float(rows.iloc[0])

    estimates = [
        ("iv_slope", float(beta[-1])),
        ("exposure_area0_period0", exposure_value(0, 0, "x")),
        ("exposure_area0_period1", exposure_value(0, 1, "x")),
        ("instrument_area0_period0", exposure_value(0, 0, "z")),
    ]
    result = {
        "task_id": TASK_ID,
        "platform": "python",
        "estimates": [
            {"term": term, "estimate": value, "se": None, "n_obs": 72}
            for term, value in estimates
        ],
        "method_metadata": {
            "estimator": "weighted 2SLS",
            "outcome": "change_pp",
            "endogenous_regressor": "x",
            "excluded_instrument": "z",
            "exogenous_instruments": ["intercept", "period", "control"],
            "weight": "base-vintage population",
            "exposure_units": "thousands of real dollars per worker per decade",
        },
        "diagnostics": {
            "estimation_rows": int(len(sample)),
            "industries": int(len(industries)),
        },
    }
    with open("result.json", "w", encoding="utf-8") as output:
        json.dump(result, output, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
