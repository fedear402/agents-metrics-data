import csv
import json
from collections import defaultdict

import numpy as np


def read_csv(path):
    with open(path, newline="", encoding="utf-8-sig") as file:
        return list(csv.DictReader(file))


crosswalk = {row["code"]: row["industry"] for row in read_csv("crosswalk.csv")}
trade = read_csv("trade.csv")
areas = read_csv("areas.csv")
employment = read_csv("employment.csv")
outcomes = read_csv("outcomes.csv")

trade_by_period = defaultdict(dict)
for row in trade:
    trade_by_period[row["period"]][crosswalk[row["code"]]] = row

area_data = {
    (row["area"], row["period"], row["vintage"]): row for row in areas
}
employment_by_cell = defaultdict(float)
national_employment = defaultdict(float)

for row in employment:
    key = (row["area"], row["period"], row["vintage"], row["industry"])
    value = float(row["employment"])
    employment_by_cell[key] += value
    national_employment[(row["period"], row["vintage"], row["industry"])] += value


def exposure(area, period, vintage, change_column):
    total = float(area_data[(area, period, vintage)]["total_employment"])
    result = 0.0
    for industry, trade_row in trade_by_period[period].items():
        local = employment_by_cell[(area, period, vintage, industry)]
        national = national_employment[(period, vintage, industry)]
        result += (
            (local / total)
            * (float(trade_row[change_column]) / national)
            / (float(trade_row["price_index"]) / 100.0)
            / 1000.0
            * (10.0 / float(trade_row["years"]))
        )
    return result


periods = sorted(
    {row["period"] for row in outcomes},
    key=lambda value: (0, float(value)) if value.replace(".", "", 1).isdigit()
    else (1, value),
)
period_zero, period_one = periods

observations = sorted(
    outcomes,
    key=lambda row: (periods.index(row["period"]), int(row["area"])),
)
assert len(observations) == 72

y = []
regressors = []
instruments = []
weights = []

for row in observations:
    area, period = row["area"], row["period"]
    period_indicator = float(period == period_one)
    control = float(row["control"])
    x = exposure(area, period, "base", "us_change")
    z = exposure(area, period, "early", "other_change")

    y.append(float(row["change_pp"]))
    regressors.append([1.0, period_indicator, control, x])
    instruments.append([1.0, period_indicator, control, z])
    weights.append(float(area_data[(area, period, "base")]["population"]))

y = np.asarray(y, dtype=float)
X = np.asarray(regressors, dtype=float)
Z = np.asarray(instruments, dtype=float)
w = np.asarray(weights, dtype=float)

# The model is exactly identified. These are the weighted IV normal equations.
beta = np.linalg.solve(Z.T @ (w[:, None] * X), Z.T @ (w * y))

estimates = [
    ("iv_slope", float(beta[3])),
    ("exposure_area0_period0", exposure("0", period_zero, "base", "us_change")),
    ("exposure_area0_period1", exposure("0", period_one, "base", "us_change")),
    ("instrument_area0_period0", exposure("0", period_zero, "early", "other_change")),
]

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [
        {"term": term, "estimate": value, "se": None, "n_obs": 72}
        for term, value in estimates
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "regressors": ["intercept", "period", "control", "x"],
        "instruments": ["intercept", "period", "control", "z"],
        "weight": "base-vintage population",
        "period0": period_zero,
        "period1": period_one,
    },
    "diagnostics": {
        "n_obs": 72,
        "n_industries": len(set(crosswalk.values())),
    },
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file, indent=2, allow_nan=False)
