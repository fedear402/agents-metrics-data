import json

import numpy as np
import pandas as pd

data = pd.read_csv("input.csv")
data = data.loc[data["score"].abs() < 1].copy()

score = data["score"].to_numpy(dtype=float)
right = (score >= 0).astype(float)
weights = 1 - np.abs(score)
X = np.column_stack((np.ones(len(data)), score, right, score * right))
Y = data[["earnings", "participated"]].to_numpy(dtype=float)

bread = np.linalg.inv(X.T @ (weights[:, None] * X))
coefficients = bread @ (X.T @ (weights[:, None] * Y))
residuals = Y - X @ coefficients

# The coefficient on right is the right limit minus the left limit.
jump = coefficients[2, :]
influence = (weights * X[:, 2])[:, None]  # Replaced below with full HC0 influence.
influence = (X @ bread[:, 2])[:, None] * weights[:, None] * residuals
jump_covariance = influence.T @ influence

reduced_form, first_stage = map(float, jump)
treatment_effect = reduced_form / first_stage
gradient = np.array([1 / first_stage, -reduced_form / first_stage**2])
treatment_variance = float(gradient @ jump_covariance @ gradient)

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {
            "term": "treatment_effect",
            "estimate": treatment_effect,
            "se": float(np.sqrt(max(0.0, treatment_variance))),
            "n_obs": len(data),
        },
        {
            "term": "reduced_form",
            "estimate": reduced_form,
            "se": float(np.sqrt(max(0.0, jump_covariance[0, 0]))),
            "n_obs": len(data),
        },
        {
            "term": "first_stage",
            "estimate": first_stage,
            "se": float(np.sqrt(max(0.0, jump_covariance[1, 1]))),
            "n_obs": len(data),
        },
    ],
    "method_metadata": {
        "estimator": "Fuzzy RD ratio of triangular-weighted local-linear discontinuities",
        "vcov": "Joint heteroskedasticity-robust HC0; delta method for ratio",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file)
