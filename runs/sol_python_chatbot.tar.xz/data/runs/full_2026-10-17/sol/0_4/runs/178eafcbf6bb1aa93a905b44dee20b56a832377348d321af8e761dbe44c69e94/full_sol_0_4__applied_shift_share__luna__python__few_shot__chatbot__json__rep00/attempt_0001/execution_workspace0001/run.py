import json

import numpy as np
import pandas as pd

data = pd.read_csv("input.csv")
required = ["region_id", "industry_id", "share", "shock", "region_weight", "x", "y"]
if data[required].isna().any().any():
    raise ValueError("Required columns contain missing values.")

for column in ["region_weight", "x", "y"]:
    if data.groupby("region_id")[column].nunique().gt(1).any():
        raise ValueError(f"{column} must be constant within each region.")
if data.groupby("industry_id")["shock"].nunique().gt(1).any():
    raise ValueError("shock must be constant within each industry.")
if data.duplicated(["region_id", "industry_id"]).any():
    raise ValueError("Each region-industry pair must occur once.")

shares = data.pivot(index="region_id", columns="industry_id", values="share")
if shares.isna().any().any():
    raise ValueError("Every region must have a share for every industry.")
if not np.allclose(shares.sum(axis=1).to_numpy(), 1.0):
    raise ValueError("Shares must sum to one within each region.")

regions = data.drop_duplicates("region_id").set_index("region_id").loc[shares.index]
shocks = data.drop_duplicates("industry_id").set_index("industry_id").loc[shares.columns, "shock"].to_numpy(dtype=float)
S = shares.to_numpy(dtype=float)
N = len(shocks)
if N <= 2:
    raise ValueError("HC1 requires more than two industries.")

weights = regions["region_weight"].to_numpy(dtype=float)
if np.any(weights < 0) or weights.sum() <= 0:
    raise ValueError("Regional weights must be nonnegative and have a positive sum.")
e = weights / weights.sum()

x = regions["x"].to_numpy(dtype=float)
y = regions["y"].to_numpy(dtype=float)
z = S @ shocks

regional = np.column_stack((y, x, z))
centered = regional - e @ regional
mass = e @ S
if np.any(mass <= 0):
    raise ValueError("Each industry must have positive exposure mass.")
aggregated = (S.T @ (e[:, None] * centered)) / mass[:, None]

def shock_iv(dependent, endogenous):
    regressors = np.column_stack((np.ones(N), endogenous))
    instruments = np.column_stack((np.ones(N), shocks))
    cross = instruments.T @ (mass[:, None] * regressors)
    inverse = np.linalg.inv(cross)
    beta = inverse @ (instruments.T @ (mass * dependent))
    residual = dependent - regressors @ beta
    scores = instruments * (mass * residual)[:, None]
    covariance = (N / (N - 2)) * inverse @ (scores.T @ scores) @ inverse.T
    return float(beta[1]), float(np.sqrt(max(covariance[1, 1], 0.0)))

effect, effect_se = shock_iv(aggregated[:, 0], aggregated[:, 1])
first_stage, first_stage_se = shock_iv(aggregated[:, 1], aggregated[:, 2])

regional_effect = np.sum(e * centered[:, 2] * centered[:, 0]) / np.sum(e * centered[:, 2] * centered[:, 1])
regional_first_stage = np.sum(e * centered[:, 2] * centered[:, 1]) / np.sum(e * centered[:, 2] ** 2)
if not np.allclose([effect, first_stage], [regional_effect, regional_first_stage]):
    raise ArithmeticError("Shock-level and regional slopes differ.")

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": effect, "se": effect_se, "n_obs": N},
        {"term": "first_stage", "estimate": first_stage, "se": first_stage_se, "n_obs": N},
        {"term": "effective_shocks", "estimate": float(1 / np.sum(mass ** 2)), "se": None, "n_obs": N},
    ],
    "method_metadata": {
        "estimator": "Regional weighted 2SLS with Borusyak-Hull-Jaravel shock-level aggregation",
        "vcov": "Shock-level analytic-weight HC1, N/(N-2), structural IV residuals",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
