import json

import numpy as np
import pandas as pd


def main():
    households = pd.read_csv("households.csv")
    census = pd.read_csv("census.csv")

    sample = households.loc[households["recipient"] == 0].copy()
    eligible = sample["eligible"].to_numpy(dtype=int)
    if len(sample) == 0 or not set(np.unique(eligible)).issubset({0, 1}):
        raise ValueError("The nonrecipient sample must contain eligibility groups 0 and 1.")

    ineligible = 1 - eligible
    dose = sample["dose"].to_numpy(dtype=float)
    baseline = sample["baseline"].to_numpy(dtype=float)
    instrument = sample["instrument"].to_numpy(dtype=float)
    weight = sample["weight"].to_numpy(dtype=float)
    outcome = sample["outcome"].to_numpy(dtype=float)

    if not np.all(np.isfinite(weight)) or np.any(weight <= 0):
        raise ValueError("Regression weights must be finite and positive.")

    exogenous = np.column_stack(
        (ineligible, eligible, baseline * ineligible, baseline * eligible)
    )
    endogenous = np.column_stack((dose * ineligible, dose * eligible))
    excluded = np.column_stack(
        (instrument * ineligible, instrument * eligible)
    )

    x = np.column_stack((exogenous, endogenous))
    z = np.column_stack((exogenous, excluded))

    # The six instrument columns identify the six regression coefficients.
    coefficients = np.linalg.solve(z.T @ (weight[:, None] * x), z.T @ (weight * outcome))
    slopes = coefficients[-2:]

    group_effects = {}
    group_counts = {}
    for group in (0, 1):
        mask = eligible == group
        group_counts[group] = int(mask.sum())
        if group_counts[group] == 0:
            raise ValueError(f"No nonrecipient observations for eligibility group {group}.")
        mean_dose = np.average(dose[mask], weights=weight[mask])
        group_effects[group] = float(slopes[group] * mean_dose)

    census_counts = census.groupby("eligible")["nonrecipient_population"].sum()
    if not {0, 1}.issubset(census_counts.index):
        raise ValueError("Census data must contain eligibility groups 0 and 1.")
    population_weights = census_counts.loc[[0, 1]].to_numpy(dtype=float)
    if not np.all(np.isfinite(population_weights)) or np.any(population_weights < 0):
        raise ValueError("Census population counts must be finite and nonnegative.")
    if population_weights.sum() <= 0:
        raise ValueError("The total nonrecipient census population must be positive.")

    population_effect = float(
        np.average([group_effects[0], group_effects[1]], weights=population_weights)
    )
    n_obs = int(len(sample))

    result = {
        "task_id": "applied_nonrecipient_population_iv",
        "platform": "python",
        "estimates": [
            {
                "term": "ineligible_effect",
                "estimate": group_effects[0],
                "se": None,
                "n_obs": n_obs,
            },
            {
                "term": "eligible_nonrecipient_effect",
                "estimate": group_effects[1],
                "se": None,
                "n_obs": n_obs,
            },
            {
                "term": "population_effect",
                "estimate": population_effect,
                "se": None,
                "n_obs": n_obs,
            },
        ],
        "method_metadata": {
            "estimator": "weighted exactly identified 2SLS",
            "sample": "all households with recipient == 0",
            "counterfactual": "dose set to zero for every retained household",
            "group_effect": "fitted group dose slope times household-weighted group mean dose",
            "population_aggregation": "group effects weighted by census nonrecipient_population",
            "standard_errors": "not requested; se is null",
        },
        "diagnostics": {
            "n_obs": n_obs,
            "group_n_obs": {
                "ineligible": group_counts[0],
                "eligible_nonrecipient": group_counts[1],
            },
            "dose_slopes": {
                "ineligible": float(slopes[0]),
                "eligible_nonrecipient": float(slopes[1]),
            },
            "census_nonrecipient_population": {
                "ineligible": float(population_weights[0]),
                "eligible_nonrecipient": float(population_weights[1]),
            },
        },
    }

    with open("result.json", "w", encoding="utf-8") as file:
        json.dump(result, file, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
