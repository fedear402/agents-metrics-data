import json

import numpy as np
import pandas as pd


def cohort_estimate(data, cohort):
    window = list(range(cohort - 2, cohort + 3))
    eligible = data[
        data["time"].isin(window)
        & ((data["g"] == cohort) | (data["g"] == 0) | (data["g"] > cohort + 2))
    ]

    complete_ids = eligible.groupby("id")["time"].nunique()
    complete_ids = complete_ids[complete_ids == 5].index
    retained = eligible[eligible["id"].isin(complete_ids)]

    outcomes = retained.pivot(index="id", columns="time", values="y")[window]
    adoption = retained.drop_duplicates("id").set_index("id").loc[outcomes.index, "g"]
    treated = (adoption.to_numpy() == cohort).astype(float)

    did = treated[:, None] * (np.asarray(window) >= cohort)[None, :]
    y = outcomes.to_numpy(dtype=float)

    def remove_fixed_effects(values):
        return (
            values
            - values.mean(axis=1, keepdims=True)
            - values.mean(axis=0, keepdims=True)
            + values.mean()
        )

    did_residual = remove_fixed_effects(did)
    y_residual = remove_fixed_effects(y)
    estimate = np.sum(did_residual * y_residual) / np.sum(did_residual**2)

    return float(estimate), int(y.size), int(treated.sum())


data = pd.read_csv("input.csv")

results = {}
for cohort in (3, 5, 7):
    results[cohort] = cohort_estimate(data, cohort)

total_treated = sum(results[c][2] for c in (3, 5, 7))
weighted = sum(results[c][0] * results[c][2] for c in (3, 5, 7)) / total_treated

estimates = [
    {
        "term": f"att_g{cohort}",
        "estimate": results[cohort][0],
        "se": None,
        "n_obs": results[cohort][1],
    }
    for cohort in (3, 5, 7)
]
estimates.append(
    {
        "term": "att_weighted",
        "estimate": float(weighted),
        "se": None,
        "n_obs": sum(results[c][1] for c in (3, 5, 7)),
    }
)

with open("result.json", "w") as stream:
    json.dump(
        {
            "task_id": "broad_cohort_stack",
            "platform": "python",
            "estimates": estimates,
            "method_metadata": {},
            "diagnostics": {},
        },
        stream,
        indent=2,
        allow_nan=False,
    )
