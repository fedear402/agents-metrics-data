import json

import pandas as pd
from statsmodels.tsa.arima.model import ARIMA

data = pd.read_csv("./input.csv").sort_values("t")
y = pd.to_numeric(data["y"], errors="raise")

fit = ARIMA(y, order=(1, 1, 1), trend="n").fit()
prediction = fit.get_forecast(steps=1)
forecast = float(prediction.predicted_mean.iloc[0])
forecast_se = float(prediction.se_mean.iloc[0])
interval = prediction.conf_int(alpha=0.05).iloc[0]

result = {
    "task_id": "arima_forecast",
    "platform": "python",
    "estimates": [
        {"term": "forecast", "estimate": forecast, "se": forecast_se, "n_obs": int(fit.nobs)},
        {"term": "lower_95", "estimate": float(interval.iloc[0]), "se": None, "n_obs": int(fit.nobs)},
        {"term": "upper_95", "estimate": float(interval.iloc[1]), "se": None, "n_obs": int(fit.nobs)},
    ],
    "method_metadata": {
        "estimator": "ARIMA(1,1,1) maximum likelihood without constant or drift",
        "vcov": "model-based forecast variance",
    },
    "diagnostics": {},
}

with open("./result.json", "w", encoding="utf-8") as file:
    json.dump(result, file)
