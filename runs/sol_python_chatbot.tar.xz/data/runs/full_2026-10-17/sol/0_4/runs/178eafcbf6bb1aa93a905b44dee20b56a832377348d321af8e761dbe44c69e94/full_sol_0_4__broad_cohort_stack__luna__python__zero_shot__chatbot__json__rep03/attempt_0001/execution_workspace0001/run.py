import csv
import json
from collections import defaultdict

COHORTS = (3, 5, 7)

with open("input.csv", newline="", encoding="utf-8") as file:
    rows = [
        {
            "id": row["id"],
            "time": int(row["time"]),
            "g": int(row["g"]),
            "y": float(row["y"]),
        }
        for row in csv.DictReader(file)
    ]


def estimate_cohort(cohort):
    window = set(range(cohort - 2, cohort + 3))
    by_unit = defaultdict(list)

    for row in rows:
        if row["time"] in window and (
            row["g"] == cohort or row["g"] == 0 or row["g"] > cohort + 2
        ):
            by_unit[row["id"]].append(row)

    retained = [
        unit_rows
        for unit_rows in by_unit.values()
        if {row["time"] for row in unit_rows} == window
        and len(unit_rows) == len(window)
    ]
    comparison = [row for unit_rows in retained for row in unit_rows]

    if not comparison:
        raise ValueError(f"No balanced units for cohort {cohort}")

    treated_units = sum(
        unit_rows[0]["g"] == cohort for unit_rows in retained
    )

    unit_means = {}
    for unit_rows in retained:
        unit_means[unit_rows[0]["id"]] = (
            sum(row["y"] for row in unit_rows) / len(window),
            sum(
                int(row["g"] == cohort and row["time"] >= cohort)
                for row in unit_rows
            ) / len(window),
        )

    time_means = {}
    for time in window:
        time_rows = [row for row in comparison if row["time"] == time]
        time_means[time] = (
            sum(row["y"] for row in time_rows) / len(time_rows),
            sum(
                int(row["g"] == cohort and row["time"] >= cohort)
                for row in time_rows
            ) / len(time_rows),
        )

    overall_y = sum(row["y"] for row in comparison) / len(comparison)
    overall_did = sum(
        int(row["g"] == cohort and row["time"] >= cohort)
        for row in comparison
    ) / len(comparison)

    numerator = 0.0
    denominator = 0.0
    for row in comparison:
        did = int(row["g"] == cohort and row["time"] >= cohort)
        y_residual = (
            row["y"]
            - unit_means[row["id"]][0]
            - time_means[row["time"]][0]
            + overall_y
        )
        did_residual = (
            did
            - unit_means[row["id"]][1]
            - time_means[row["time"]][1]
            + overall_did
        )
        numerator += did_residual * y_residual
        denominator += did_residual**2

    if denominator == 0:
        raise ValueError(f"did is unidentified for cohort {cohort}")

    return numerator / denominator, len(comparison), treated_units


results = {cohort: estimate_cohort(cohort) for cohort in COHORTS}
total_treated = sum(results[cohort][2] for cohort in COHORTS)
if total_treated == 0:
    raise ValueError("No retained treated units")

estimates = [
    {
        "term": f"att_g{cohort}",
        "estimate": results[cohort][0],
        "se": None,
        "n_obs": results[cohort][1],
    }
    for cohort in COHORTS
]
estimates.append(
    {
        "term": "att_weighted",
        "estimate": sum(
            results[cohort][0] * results[cohort][2] for cohort in COHORTS
        ) / total_treated,
        "se": None,
        "n_obs": sum(results[cohort][1] for cohort in COHORTS),
    }
)

output = {
    "task_id": "broad_cohort_stack",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {},
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(output, file, indent=2)
