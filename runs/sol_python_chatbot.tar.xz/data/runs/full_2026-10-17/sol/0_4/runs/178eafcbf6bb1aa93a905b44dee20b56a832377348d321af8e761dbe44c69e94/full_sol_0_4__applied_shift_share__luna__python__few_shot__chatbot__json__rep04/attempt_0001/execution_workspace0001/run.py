import json

import numpy as np
import pandas as pd

data = pd.read_csv("input.csv")

regions = data.drop_duplicates("region_id").set_index("region_id")
industries = data.drop_duplicates("industry_id").set_index("industry_id")

weights = regions["region_weight"].to_numpy(dtype=float)
weights /= weights.sum()

shares = data.pivot(
    index="region_id", columns="industry_id", values="share"
).reindex(index=regions.index, columns=industries.index).to_numpy(dtype=float)

shocks = industries["shock"].to_numpy(dtype=float)
x = regions["x"].to_numpy(dtype=float)
y = regions["y"].to_numpy(dtype=float)
z = shares @ shocks

centered = np.column_stack((y, x, z))
centered -= weights @ centered

mass = weights @ shares
aggregated = (shares.T @ (weights[:, None] * centered)) / mass[:, None]
n_industries = len(shocks)

def shock_iv(dependent, endogenous):
    regressors = np.column_stack((np.ones(n_industries), endogenous))
    instruments = np.column_stack((np.ones(n_industries), shocks))
    cross = instruments.T @ (mass[:, None] * regressors)
    coefficients = np.linalg.solve(
        cross, instruments.T @ (mass * dependent)
    )
    residuals = dependent - regressors @ coefficients
    scores = instruments * (mass * residuals)[:, None]
    inverse = np.linalg.inv(cross)
    covariance = (
        n_industries / (n_industries - 2)
        * inverse @ (scores.T @ scores) @ inverse.T
    )
    return float(coefficients[1]), float(np.sqrt(covariance[1, 1]))

effect, effect_se = shock_iv(aggregated[:, 0], aggregated[:, 1])
first_stage, first_stage_se = shock_iv(
    aggregated[:, 1], aggregated[:, 2]
)

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {
            "term": "effect",
            "estimate": effect,
            "se": effect_se,
            "n_obs": n_industries,
        },
        {
            "term": "first_stage",
            "estimate": first_stage,
            "se": first_stage_se,
            "n_obs": n_industries,
        },
        {
            "term": "effective_shocks",
            "estimate": float(1 / np.sum(mass ** 2)),
            "se": None,
            "n_obs": n_industries,
        },
    ],
    "method_metadata": {
        "estimator": "Regional weighted 2SLS via shock-level IV aggregation",
        "vcov": "Shock-level heteroskedasticity-robust HC1",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
