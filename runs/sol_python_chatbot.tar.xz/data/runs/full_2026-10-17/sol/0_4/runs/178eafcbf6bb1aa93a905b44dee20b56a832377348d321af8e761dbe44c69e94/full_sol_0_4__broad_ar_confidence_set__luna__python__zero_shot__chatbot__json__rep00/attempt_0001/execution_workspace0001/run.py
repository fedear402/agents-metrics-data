import json

import numpy as np
import pandas as pd
from scipy.stats import f

data = pd.read_csv("input.csv")
n = len(data)

y = data["y"].to_numpy(dtype=float)
endog = data["endog"].to_numpy(dtype=float)
restricted = np.column_stack((np.ones(n), data["x"].to_numpy(dtype=float)))
unrestricted = np.column_stack(
    (
        restricted,
        data["z1"].to_numpy(dtype=float),
        data["z2"].to_numpy(dtype=float),
    )
)

def residual(vector, design):
    return vector - design @ np.linalg.lstsq(design, vector, rcond=None)[0]

ry = residual(y, restricted)
re = residual(endog, restricted)
uy = residual(y, unrestricted)
ue = residual(endog, unrestricted)

def rss_coefficients(a, b):
    return np.array([b @ b, -2.0 * (a @ b), a @ a])

rss_r = rss_coefficients(ry, re)
rss_u = rss_coefficients(uy, ue)
critical = f.ppf(0.95, 2, n - 4)

# The AR test accepts beta when this quadratic is at most zero.
q = (rss_r - rss_u) / 2.0 - critical * rss_u / (n - 4)
roots = np.roots(q)
real_roots = sorted(float(root.real) for root in roots if abs(root.imag) < 1e-8)
if len(real_roots) != 2:
    raise ValueError("Expected two finite AR boundary points")

def ar_f(beta):
    r = rss_r[0] * beta**2 + rss_r[1] * beta + rss_r[2]
    u = rss_u[0] * beta**2 + rss_u[1] * beta + rss_u[2]
    return ((r - u) / 2.0) / (u / (n - 4))

values = {
    "boundary_low": real_roots[0],
    "boundary_high": real_roots[1],
    "accepts_zero": float(q[2] <= 0.0),
    "unbounded": float(q[0] <= 0.0),
    "ar_f_at_one": float(ar_f(1.0)),
}

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": [
        {"term": term, "estimate": value, "se": None, "n_obs": n}
        for term, value in values.items()
    ],
    "method_metadata": {
        "estimator": "Anderson-Rubin confidence set by quadratic inversion of the joint F test",
        "vcov": "Conventional homoskedastic OLS",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output)
