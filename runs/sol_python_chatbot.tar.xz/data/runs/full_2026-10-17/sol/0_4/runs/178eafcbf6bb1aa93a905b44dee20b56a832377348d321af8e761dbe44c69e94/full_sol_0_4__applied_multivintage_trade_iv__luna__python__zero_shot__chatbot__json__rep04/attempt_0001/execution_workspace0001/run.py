import json

import numpy as np
import pandas as pd


TASK_ID = "applied_multivintage_trade_iv"

crosswalk = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv")
areas = pd.read_csv("areas.csv")
employment = pd.read_csv("employment.csv")
outcomes = pd.read_csv("outcomes.csv")

trade = trade.merge(crosswalk, on="code", how="left", validate="many_to_one")
if trade["industry"].isna().any():
    raise ValueError("Every trade code must map to an industry.")

trade_industry = trade.groupby(["period", "industry"], as_index=False).agg(
    us_change=("us_change", "sum"),
    other_change=("other_change", "sum"),
    price_index=("price_index", "first"),
    years=("years", "first"),
)

industry_ids = crosswalk["industry"].drop_duplicates()
if len(industry_ids) != 4:
    raise ValueError("Expected four industries.")

area_keys = areas[["area", "period", "vintage"]].drop_duplicates()
cells = area_keys.merge(pd.DataFrame({"industry": industry_ids}), how="cross")
cells = cells.merge(
    employment,
    on=["area", "period", "vintage", "industry"],
    how="left",
    validate="one_to_one",
)
cells["employment"] = cells["employment"].fillna(0.0)

national = cells.groupby(
    ["period", "vintage", "industry"], as_index=False
)["employment"].sum()
national = national.rename(columns={"employment": "national_employment"})
cells = cells.merge(
    national,
    on=["period", "vintage", "industry"],
    validate="many_to_one",
).merge(
    areas,
    on=["area", "period", "vintage"],
    validate="many_to_one",
).merge(
    trade_industry,
    on=["period", "industry"],
    validate="many_to_one",
)

if (cells["national_employment"] <= 0).any():
    raise ValueError("National industry employment must be positive.")

base = cells.loc[cells["vintage"] == "base"].copy()
early = cells.loc[cells["vintage"] == "early"].copy()

def exposure(frame, change_column, output_column):
    component = (
        (frame["employment"] / frame["total_employment"])
        * (frame[change_column] / frame["national_employment"])
        / (frame["price_index"] / 100.0)
        / 1000.0
        * (10.0 / frame["years"])
    )
    result = frame[["area", "period"]].copy()
    result[output_column] = component
    return result.groupby(["area", "period"], as_index=False)[output_column].sum()

x = exposure(base, "us_change", "x")
z = exposure(early, "other_change", "z")

sample = (
    outcomes.merge(x, on=["area", "period"], validate="one_to_one")
    .merge(z, on=["area", "period"], validate="one_to_one")
    .merge(
        areas.loc[areas["vintage"] == "base", ["area", "period", "population"]],
        on=["area", "period"],
        validate="one_to_one",
    )
    .sort_values(["period", "area"])
    .reset_index(drop=True)
)

if len(sample) != 72:
    raise ValueError(f"Expected 72 estimation rows; found {len(sample)}.")
if sample[["change_pp", "period", "control", "x", "z", "population"]].isna().any().any():
    raise ValueError("Estimation data contain missing values.")

y = sample["change_pp"].to_numpy(dtype=float)
exog = np.column_stack(
    (
        np.ones(len(sample)),
        sample["period"].to_numpy(dtype=float),
        sample["control"].to_numpy(dtype=float),
    )
)
X = np.column_stack((exog, sample["x"].to_numpy(dtype=float)))
Z = np.column_stack((exog, sample["z"].to_numpy(dtype=float)))
weights = sample["population"].to_numpy(dtype=float)

if (weights <= 0).any():
    raise ValueError("Regression weights must be positive.")

sqrt_weights = np.sqrt(weights)
Xw = X * sqrt_weights[:, None]
Zw = Z * sqrt_weights[:, None]
yw = y * sqrt_weights

# Exactly identified weighted 2SLS with the intercept, period, and control
# included as both regressors and instruments.
coefficients = np.linalg.solve(Zw.T @ Xw, Zw.T @ yw)
iv_slope = float(coefficients[-1])

def value_for(area, period, column):
    rows = sample.loc[
        (sample["area"] == area) & (sample["period"] == period),
        column,
    ]
    if len(rows) != 1:
        raise ValueError(f"Expected one row for area {area}, period {period}.")
    return float(rows.iloc[0])

estimates = [
    {
        "term": "iv_slope",
        "estimate": iv_slope,
        "se": None,
        "n_obs": 72,
    },
    {
        "term": "exposure_area0_period0",
        "estimate": value_for(0, 0, "x"),
        "se": None,
        "n_obs": 72,
    },
    {
        "term": "exposure_area0_period1",
        "estimate": value_for(0, 1, "x"),
        "se": None,
        "n_obs": 72,
    },
    {
        "term": "instrument_area0_period0",
        "estimate": value_for(0, 0, "z"),
        "se": None,
        "n_obs": 72,
    },
]

result = {
    "task_id": TASK_ID,
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "weighted two-stage least squares",
        "outcome": "change_pp",
        "endogenous_regressor": "x",
        "excluded_instrument": "z",
        "exogenous_regressors_and_instruments": ["intercept", "period", "control"],
        "weight": "base-vintage population",
        "exposure_units": "thousands of real dollars per worker per decade",
        "missing_employment_cells": "zero",
    },
    "diagnostics": {
        "n_obs": 72,
        "n_industries": 4,
        "instrument_matrix_rank": int(np.linalg.matrix_rank(Zw)),
        "regressor_matrix_rank": int(np.linalg.matrix_rank(Xw)),
    },
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file, indent=2, allow_nan=False)
