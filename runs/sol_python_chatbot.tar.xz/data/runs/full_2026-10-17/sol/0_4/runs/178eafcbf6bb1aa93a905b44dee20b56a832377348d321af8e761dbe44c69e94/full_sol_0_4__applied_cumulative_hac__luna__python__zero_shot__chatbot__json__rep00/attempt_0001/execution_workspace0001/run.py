import json

import numpy as np
import pandas as pd
import statsmodels.api as sm

data = pd.read_csv("input.csv", parse_dates=["date"]).sort_values("date")
change = np.log(data["vix"].astype(float)).diff()

regression = pd.DataFrame({"log_sales": np.log(data["sales"].astype(float))})
for lag in range(1, 16):
    regression[f"lag_{lag}"] = change.shift(lag)
regression = regression.dropna()

terms = [f"lag_{lag}" for lag in range(1, 16)]
x = sm.add_constant(regression[terms])
model = sm.OLS(regression["log_sales"], x).fit(
    cov_type="HAC",
    cov_kwds={"maxlags": 15, "kernel": "bartlett", "use_correction": False},
)

n_obs = len(regression)
covariance = model.cov_params() * n_obs / (n_obs - 16)
cumulative_estimate = float(model.params[terms].sum())
cumulative_se = float(np.sqrt(covariance.loc[terms, terms].to_numpy().sum()))

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {
            "term": "cumulative_response",
            "estimate": cumulative_estimate,
            "se": cumulative_se,
            "n_obs": n_obs,
        },
        *[
            {
                "term": term,
                "estimate": float(model.params[term]),
                "se": float(np.sqrt(covariance.loc[term, term])),
                "n_obs": n_obs,
            }
            for term in ("lag_1", "lag_15")
        ],
    ],
    "method_metadata": {
        "estimator": "OLS of log sales on intercept and lags 1–15 of differenced log VIX",
        "vcov": "Newey-West HAC, Bartlett kernel, max lag 15, multiplied by N/(N-16)",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output, allow_nan=False)
