import json

import numpy as np
import pandas as pd

data = pd.read_csv("input.csv")
data = data.loc[data["score"].abs() < 1].copy()

score = data["score"].to_numpy(dtype=float)
right = (score >= 0).astype(float)
weights = 1 - np.abs(score)
X = np.column_stack((np.ones(len(data)), score, right, right * score))
Y = data[["earnings", "participated"]].to_numpy(dtype=float)

weighted_X = weights[:, None] * X
bread = np.linalg.inv(X.T @ weighted_X)
coefficients = bread @ (X.T @ (weights[:, None] * Y))
residuals = Y - X @ coefficients

# Joint HC0 covariance for the two discontinuities.
influence = (weighted_X @ bread[:, 2])[:, None] * residuals
covariance = influence.T @ influence

reduced_form = float(coefficients[2, 0])
first_stage = float(coefficients[2, 1])
treatment_effect = reduced_form / first_stage

gradient = np.array([1 / first_stage, -reduced_form / first_stage**2])
treatment_variance = float(gradient @ covariance @ gradient)
n_obs = int(len(data))

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {
            "term": "treatment_effect",
            "estimate": treatment_effect,
            "se": float(np.sqrt(max(treatment_variance, 0))),
            "n_obs": n_obs,
        },
        {
            "term": "reduced_form",
            "estimate": reduced_form,
            "se": float(np.sqrt(max(covariance[0, 0], 0))),
            "n_obs": n_obs,
        },
        {
            "term": "first_stage",
            "estimate": first_stage,
            "se": float(np.sqrt(max(covariance[1, 1], 0))),
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "Fuzzy RD Wald ratio using triangular-weighted local linear regressions",
        "vcov": "Joint HC0 sandwich covariance; delta method for Wald ratio",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file)
