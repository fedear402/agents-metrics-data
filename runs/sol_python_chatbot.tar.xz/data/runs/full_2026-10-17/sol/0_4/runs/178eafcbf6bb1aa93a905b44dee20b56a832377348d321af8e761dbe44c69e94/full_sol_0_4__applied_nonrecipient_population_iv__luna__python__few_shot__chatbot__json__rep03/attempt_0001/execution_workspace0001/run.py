import json

import numpy as np
import pandas as pd


def main():
    households = pd.read_csv("households.csv")
    census = pd.read_csv("census.csv")

    sample = households.loc[households["recipient"] == 0].copy()
    if sample.empty:
        raise ValueError("No nonrecipient households were found.")

    eligible = sample["eligible"].to_numpy(dtype=int)
    if not np.isin(eligible, [0, 1]).all():
        raise ValueError("eligible must contain only 0 and 1.")

    ineligible = 1 - eligible
    dose = sample["dose"].to_numpy(dtype=float)
    baseline = sample["baseline"].to_numpy(dtype=float)
    instrument = sample["instrument"].to_numpy(dtype=float)
    outcome = sample["outcome"].to_numpy(dtype=float)
    weight = sample["weight"].to_numpy(dtype=float)

    if not np.isfinite(weight).all() or (weight <= 0).any():
        raise ValueError("Regression weights must be positive and finite.")

    exogenous = np.column_stack(
        (
            ineligible,
            eligible,
            baseline * ineligible,
            baseline * eligible,
        )
    )
    endogenous = np.column_stack(
        (dose * ineligible, dose * eligible)
    )
    excluded = np.column_stack(
        (instrument * ineligible, instrument * eligible)
    )

    # Column order: four exogenous columns, then two endogenous columns.
    x = np.column_stack((exogenous, endogenous))
    z = np.column_stack((exogenous, excluded))
    root_weight = np.sqrt(weight)
    xw = x * root_weight[:, None]
    zw = z * root_weight[:, None]
    yw = outcome * root_weight

    if np.linalg.matrix_rank(zw) != z.shape[1]:
        raise ValueError("The weighted instrument matrix lacks full rank.")

    fitted_xw = zw @ np.linalg.lstsq(zw, xw, rcond=None)[0]
    if np.linalg.matrix_rank(fitted_xw) != x.shape[1]:
        raise ValueError("The weighted 2SLS model is unidentified.")

    coefficients = np.linalg.lstsq(fitted_xw, yw, rcond=None)[0]

    group_effects = {}
    group_mean_doses = {}
    for group, slope_index in ((0, 4), (1, 5)):
        mask = eligible == group
        if not mask.any():
            raise ValueError(f"No nonrecipient households in eligibility group {group}.")
        mean_dose = np.average(dose[mask], weights=weight[mask])
        group_mean_doses[group] = float(mean_dose)
        group_effects[group] = float(coefficients[slope_index] * mean_dose)

    census_counts = census.groupby("eligible")["nonrecipient_population"].sum()
    if not {0, 1}.issubset(census_counts.index):
        raise ValueError("Census counts are required for both eligibility groups.")
    populations = census_counts.loc[[0, 1]].to_numpy(dtype=float)
    if not np.isfinite(populations).all() or (populations < 0).any():
        raise ValueError("Census counts must be finite and nonnegative.")
    if populations.sum() <= 0:
        raise ValueError("The total nonrecipient population must be positive.")

    population_effect = float(
        np.average(
            [group_effects[0], group_effects[1]],
            weights=populations,
        )
    )
    n_obs = int(len(sample))

    result = {
        "task_id": "applied_nonrecipient_population_iv",
        "platform": "python",
        "estimates": [
            {
                "term": "ineligible_effect",
                "estimate": group_effects[0],
                "se": None,
                "n_obs": n_obs,
            },
            {
                "term": "eligible_nonrecipient_effect",
                "estimate": group_effects[1],
                "se": None,
                "n_obs": n_obs,
            },
            {
                "term": "population_effect",
                "estimate": population_effect,
                "se": None,
                "n_obs": n_obs,
            },
        ],
        "method_metadata": {
            "estimator": "weighted 2SLS",
            "sample": "All households with recipient=0, regardless of village treatment status",
            "exogenous_columns": [
                "1-eligible",
                "eligible",
                "baseline*(1-eligible)",
                "baseline*eligible",
            ],
            "endogenous_columns": [
                "dose*(1-eligible)",
                "dose*eligible",
            ],
            "excluded_instruments": [
                "instrument*(1-eligible)",
                "instrument*eligible",
            ],
            "additional_intercept": False,
            "regression_weight": "weight",
            "group_effect": "Fitted group dose slope times the household-weighted mean dose among retained group observations",
            "counterfactual": "Dose is set to zero for every retained household; this attribution is a stated synthetic convention.",
            "population_aggregation": "Group effects weighted by census nonrecipient_population counts",
        },
        "diagnostics": {
            "n_obs": n_obs,
            "group_dose_slopes": {
                "ineligible": float(coefficients[4]),
                "eligible_nonrecipient": float(coefficients[5]),
            },
            "group_weighted_mean_dose": {
                "ineligible": group_mean_doses[0],
                "eligible_nonrecipient": group_mean_doses[1],
            },
            "census_nonrecipient_population": {
                "ineligible": int(census_counts.loc[0]),
                "eligible_nonrecipient": int(census_counts.loc[1]),
            },
        },
    }

    with open("result.json", "w", encoding="utf-8") as output:
        json.dump(result, output, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
