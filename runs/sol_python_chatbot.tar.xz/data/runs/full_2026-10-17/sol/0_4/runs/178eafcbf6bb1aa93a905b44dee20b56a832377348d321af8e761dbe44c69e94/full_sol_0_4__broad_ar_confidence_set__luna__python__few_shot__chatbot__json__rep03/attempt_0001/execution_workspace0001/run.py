import json

import numpy as np
import pandas as pd
from scipy.stats import f

data = pd.read_csv("input.csv")
y = data["y"].to_numpy(dtype=float)
d = data["endog"].to_numpy(dtype=float)
x = data["x"].to_numpy(dtype=float)
z1 = data["z1"].to_numpy(dtype=float)
z2 = data["z2"].to_numpy(dtype=float)

n = len(data)
q = 2
df = n - 4

restricted = np.column_stack((np.ones(n), x))
unrestricted = np.column_stack((restricted, z1, z2))


def residual(vector, design):
    coefficients = np.linalg.lstsq(design, vector, rcond=None)[0]
    return vector - design @ coefficients


ry = residual(y, restricted)
rd = residual(d, restricted)
uy = residual(y, unrestricted)
ud = residual(d, unrestricted)

critical = f.ppf(0.95, q, df)
factor = 1.0 + q * critical / df

a = float(rd @ rd - factor * (ud @ ud))
b = float(-2.0 * (ry @ rd - factor * (uy @ ud)))
c = float(ry @ ry - factor * (uy @ uy))

roots = np.roots([a, b, c])
if len(roots) != 2 or np.any(np.abs(roots.imag) > 1e-8):
    raise ValueError("Expected two finite real Anderson-Rubin boundaries.")
boundary_low, boundary_high = sorted(float(root.real) for root in roots)

def test_inequality(beta):
    return a * beta * beta + b * beta + c <= 0.0


def ar_f(beta):
    restricted_residual = ry - beta * rd
    unrestricted_residual = uy - beta * ud
    ssr_r = restricted_residual @ restricted_residual
    ssr_u = unrestricted_residual @ unrestricted_residual
    return float(((ssr_r - ssr_u) / q) / (ssr_u / df))


values = {
    "boundary_low": boundary_low,
    "boundary_high": boundary_high,
    "accepts_zero": int(test_inequality(0.0)),
    "unbounded": int(a < 0.0),
    "ar_f_at_one": ar_f(1.0),
}

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": [
        {"term": term, "estimate": value, "se": None, "n_obs": n}
        for term, value in values.items()
    ],
    "method_metadata": {
        "estimator": "Anderson-Rubin test inversion",
        "vcov": "Conventional homoskedastic joint F test",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
