import json

import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS

households = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

sample = households.loc[households["recipient"] == 0].copy()
eligible = sample["eligible"].to_numpy()
ineligible = 1 - eligible

exog = pd.DataFrame(
    {
        "ineligible": ineligible,
        "eligible": eligible,
        "baseline_ineligible": sample["baseline"].to_numpy() * ineligible,
        "baseline_eligible": sample["baseline"].to_numpy() * eligible,
    },
    index=sample.index,
)
endog = pd.DataFrame(
    {
        "dose_ineligible": sample["dose"].to_numpy() * ineligible,
        "dose_eligible": sample["dose"].to_numpy() * eligible,
    },
    index=sample.index,
)
excluded_instruments = pd.DataFrame(
    {
        "instrument_ineligible": sample["instrument"].to_numpy() * ineligible,
        "instrument_eligible": sample["instrument"].to_numpy() * eligible,
    },
    index=sample.index,
)

fit = IV2SLS(
    dependent=sample["outcome"],
    exog=exog,
    endog=endog,
    instruments=excluded_instruments,
    weights=sample["weight"],
).fit()

effects = {}
mean_doses = {}
for group, slope_term in ((0, "dose_ineligible"), (1, "dose_eligible")):
    group_rows = sample.loc[sample["eligible"] == group]
    mean_dose = np.average(
        group_rows["dose"].to_numpy(),
        weights=group_rows["weight"].to_numpy(),
    )
    mean_doses[group] = float(mean_dose)
    effects[group] = float(fit.params[slope_term] * mean_dose)

population = census.groupby("eligible")["nonrecipient_population"].sum()
population_effect = float(
    np.average(
        [effects[0], effects[1]],
        weights=[population.loc[0], population.loc[1]],
    )
)

n_obs = int(len(sample))
result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {"term": "ineligible_effect", "estimate": effects[0], "se": None, "n_obs": n_obs},
        {
            "term": "eligible_nonrecipient_effect",
            "estimate": effects[1],
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "population_effect",
            "estimate": population_effect,
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "sample": "All households with recipient=0, across both village treatment statuses",
        "exogenous_columns": list(exog.columns),
        "endogenous_columns": list(endog.columns),
        "excluded_instrument_columns": list(excluded_instruments.columns),
        "regression_weight": "weight",
        "within_group_exposure": "Household-weighted mean dose among retained observations",
        "population_aggregation_weight": "nonrecipient_population from census.csv",
        "counterfactual": "Dose is set to zero for every retained household as a synthetic attribution convention",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "group_slopes": {
            "ineligible": float(fit.params["dose_ineligible"]),
            "eligible_nonrecipient": float(fit.params["dose_eligible"]),
        },
        "group_weighted_mean_dose": {
            "ineligible": mean_doses[0],
            "eligible_nonrecipient": mean_doses[1],
        },
    },
}

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output, indent=2, allow_nan=False)
