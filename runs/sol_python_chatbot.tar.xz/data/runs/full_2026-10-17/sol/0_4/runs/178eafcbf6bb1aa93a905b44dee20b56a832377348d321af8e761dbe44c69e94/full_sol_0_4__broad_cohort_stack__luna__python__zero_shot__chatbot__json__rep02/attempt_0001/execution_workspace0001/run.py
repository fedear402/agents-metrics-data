import csv
import json

COHORTS = (3, 5, 7)

with open("input.csv", newline="", encoding="utf-8-sig") as file:
    data = [
        {
            "id": row["id"],
            "time": int(float(row["time"])),
            "g": int(float(row["g"])),
            "y": float(row["y"]),
        }
        for row in csv.DictReader(file)
    ]

estimates = []
weighted_sum = 0.0
total_treated_units = 0
total_rows = 0

for cohort in COHORTS:
    times = range(cohort - 2, cohort + 3)
    units = {}

    for row in data:
        if row["time"] in times and (
            row["g"] == cohort or row["g"] == 0 or row["g"] > cohort + 2
        ):
            units.setdefault(row["id"], {})[row["time"]] = row

    balanced = {
        unit_id: observations
        for unit_id, observations in units.items()
        if all(time in observations for time in times)
    }

    rows = []
    treated_units = 0

    for observations in balanced.values():
        treated = observations[cohort]["g"] == cohort
        treated_units += int(treated)

        for time in times:
            rows.append({
                "time": time,
                "did": float(treated and time >= cohort),
                "y": observations[time]["y"],
                "unit": id(observations),
            })

    if not rows:
        raise ValueError(f"No balanced observations for cohort {cohort}")

    unit_means = {}
    for row in rows:
        unit_means.setdefault(row["unit"], []).append(row)

    for unit_rows in unit_means.values():
        mean_did = sum(row["did"] for row in unit_rows) / len(unit_rows)
        mean_y = sum(row["y"] for row in unit_rows) / len(unit_rows)
        for row in unit_rows:
            row["did_unit"] = row["did"] - mean_did
            row["y_unit"] = row["y"] - mean_y

    time_means = {}
    for time in times:
        time_rows = [row for row in rows if row["time"] == time]
        time_means[time] = (
            sum(row["did_unit"] for row in time_rows) / len(time_rows),
            sum(row["y_unit"] for row in time_rows) / len(time_rows),
        )

    numerator = 0.0
    denominator = 0.0
    for row in rows:
        mean_did, mean_y = time_means[row["time"]]
        residual_did = row["did_unit"] - mean_did
        residual_y = row["y_unit"] - mean_y
        numerator += residual_did * residual_y
        denominator += residual_did * residual_did

    if denominator == 0:
        raise ValueError(f"The did coefficient is unidentified for cohort {cohort}")

    coefficient = numerator / denominator
    n_obs = len(rows)
    estimates.append({
        "term": f"att_g{cohort}",
        "estimate": coefficient,
        "se": None,
        "n_obs": n_obs,
    })

    weighted_sum += treated_units * coefficient
    total_treated_units += treated_units
    total_rows += n_obs

if total_treated_units == 0:
    raise ValueError("No treated units were retained")

estimates.append({
    "term": "att_weighted",
    "estimate": weighted_sum / total_treated_units,
    "se": None,
    "n_obs": total_rows,
})

result = {
    "task_id": "broad_cohort_stack",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {},
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file, indent=2)
