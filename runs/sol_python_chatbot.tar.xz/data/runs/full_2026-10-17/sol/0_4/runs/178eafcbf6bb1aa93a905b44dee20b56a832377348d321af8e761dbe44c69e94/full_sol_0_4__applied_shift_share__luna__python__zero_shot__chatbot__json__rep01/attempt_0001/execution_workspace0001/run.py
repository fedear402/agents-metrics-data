import json

import numpy as np
import pandas as pd


def shock_level_iv(dependent, endogenous, shock, weights):
    X = np.column_stack((np.ones(len(endogenous)), endogenous))
    Z = np.column_stack((np.ones(len(shock)), shock))
    weighted_Z = Z * weights[:, None]

    A = weighted_Z.T @ X
    beta = np.linalg.solve(A, weighted_Z.T @ dependent)

    residual = dependent - X @ beta
    scores = weighted_Z * residual[:, None]
    inverse_A = np.linalg.inv(A)
    covariance = inverse_A @ (scores.T @ scores) @ inverse_A.T
    covariance *= len(shock) / (len(shock) - 2)

    return float(beta[1]), float(np.sqrt(covariance[1, 1]))


data = pd.read_csv("input.csv")

regions = data.drop_duplicates("region_id").set_index("region_id")
region_weights = regions["region_weight"].to_numpy(dtype=float)
e = region_weights / region_weights.sum()

shares = data.pivot(
    index="region_id", columns="industry_id", values="share"
).loc[regions.index]
industries = shares.columns

shocks = data.drop_duplicates("industry_id").set_index("industry_id")
g = shocks.loc[industries, "shock"].to_numpy(dtype=float)

S = shares.to_numpy(dtype=float)
z = S @ g
x = regions["x"].to_numpy(dtype=float)
y = regions["y"].to_numpy(dtype=float)

def demean(values):
    return values - np.dot(e, values)


y0 = demean(y)
x0 = demean(x)
z0 = demean(z)

s = e @ S
ybar = ((e * y0) @ S) / s
xbar = ((e * x0) @ S) / s
zbar = ((e * z0) @ S) / s

effect, effect_se = shock_level_iv(ybar, xbar, g, s)
first_stage, first_stage_se = shock_level_iv(xbar, zbar, g, s)
n_industries = len(g)

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {
            "term": "effect",
            "estimate": effect,
            "se": effect_se,
            "n_obs": n_industries,
        },
        {
            "term": "first_stage",
            "estimate": first_stage,
            "se": first_stage_se,
            "n_obs": n_industries,
        },
        {
            "term": "effective_shocks",
            "estimate": float(1.0 / np.dot(s, s)),
            "se": None,
            "n_obs": n_industries,
        },
    ],
    "method_metadata": {
        "estimator": "Weighted regional 2SLS via BHJ shock-level IV aggregation",
        "vcov": "Shock-level heteroskedasticity-robust HC1, multiplier N/(N-2)",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output, indent=2)
