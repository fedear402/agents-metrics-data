import json

import numpy as np
import pandas as pd
from scipy.stats import f


df = pd.read_csv("input.csv")
n = len(df)

y = df["y"].to_numpy(dtype=float)
endog = df["endog"].to_numpy(dtype=float)
restricted = np.column_stack((np.ones(n), df["x"].to_numpy(dtype=float)))
unrestricted = np.column_stack(
    (
        restricted,
        df["z1"].to_numpy(dtype=float),
        df["z2"].to_numpy(dtype=float),
    )
)


def residuals(design, values):
    coefficients = np.linalg.lstsq(design, values, rcond=None)[0]
    return values - design @ coefficients


ry, re = residuals(restricted, y), residuals(restricted, endog)
uy, ue = residuals(unrestricted, y), residuals(unrestricted, endog)

# Each residual sum of squares has the form a*beta**2 + b*beta + c.
rss_r = np.array([re @ re, -2.0 * (ry @ re), ry @ ry])
rss_u = np.array([ue @ ue, -2.0 * (uy @ ue), uy @ uy])

df_den = n - 4
critical = f.ppf(0.95, 2, df_den)

# The Anderson-Rubin test accepts beta exactly when this polynomial is <= 0.
inequality = df_den * (rss_r - rss_u) - 2.0 * critical * rss_u
roots = np.sort(np.roots(inequality))
if len(roots) != 2 or np.max(np.abs(np.imag(roots))) > 1e-8:
    raise ValueError("Expected two finite real confidence-set boundaries")
boundary_low, boundary_high = np.real(roots)

def accepted(beta):
    return bool(np.polyval(inequality, beta) <= 0.0)


f_at_one = (
    (np.polyval(rss_r, 1.0) - np.polyval(rss_u, 1.0)) / 2.0
) / (np.polyval(rss_u, 1.0) / df_den)

# The sign of the leading coefficient determines membership in both tails.
unbounded = float(inequality[0] < 0.0)

terms = [
    ("boundary_low", float(boundary_low)),
    ("boundary_high", float(boundary_high)),
    ("accepts_zero", float(accepted(0.0))),
    ("unbounded", unbounded),
    ("ar_f_at_one", float(f_at_one)),
]

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": [
        {"term": term, "estimate": estimate, "se": None, "n_obs": n}
        for term, estimate in terms
    ],
    "method_metadata": {
        "estimator": "Anderson-Rubin confidence set by exact quadratic inversion",
        "vcov": "Conventional homoskedastic OLS F test",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output, indent=2)
