import json

import numpy as np
import pandas as pd


def estimate_cohort(data, cohort):
    window = range(cohort - 2, cohort + 3)
    subset = data[
        data["time"].isin(window)
        & (
            (data["g"] == cohort)
            | (data["g"] == 0)
            | (data["g"] > cohort + 2)
        )
    ].copy()

    counts = subset.groupby("id")["time"].nunique()
    retained_ids = counts.index[counts == 5]
    subset = subset[subset["id"].isin(retained_ids)].copy()
    subset["did"] = (
        (subset["g"] == cohort) & (subset["time"] >= cohort)
    ).astype(float)

    treated_count = subset.loc[subset["g"] == cohort, "id"].nunique()
    if treated_count == 0 or subset.loc[subset["g"] != cohort, "id"].nunique() == 0:
        raise ValueError(f"Cohort {cohort} lacks retained treated units or controls")

    design = pd.concat(
        [
            subset[["did"]].reset_index(drop=True),
            pd.get_dummies(subset["id"], drop_first=True, dtype=float).reset_index(drop=True),
            pd.get_dummies(subset["time"], drop_first=True, dtype=float).reset_index(drop=True),
        ],
        axis=1,
    )
    design.insert(0, "intercept", 1.0)
    coefficients = np.linalg.lstsq(
        design.to_numpy(dtype=float),
        subset["y"].to_numpy(dtype=float),
        rcond=None,
    )[0]
    return float(coefficients[1]), int(treated_count), int(len(subset))


data = pd.read_csv("input.csv")
results = {cohort: estimate_cohort(data, cohort) for cohort in (3, 5, 7)}
total_treated = sum(results[cohort][1] for cohort in results)
weighted = sum(
    results[cohort][0] * results[cohort][1] for cohort in results
) / total_treated

estimates = [
    {
        "term": f"att_g{cohort}",
        "estimate": results[cohort][0],
        "se": None,
        "n_obs": results[cohort][2],
    }
    for cohort in (3, 5, 7)
]
estimates.append(
    {
        "term": "att_weighted",
        "estimate": float(weighted),
        "se": None,
        "n_obs": sum(results[cohort][2] for cohort in results),
    }
)

with open("result.json", "w") as stream:
    json.dump(
        {
            "task_id": "broad_cohort_stack",
            "platform": "python",
            "estimates": estimates,
            "method_metadata": {},
            "diagnostics": {},
        },
        stream,
        indent=2,
        allow_nan=False,
    )
