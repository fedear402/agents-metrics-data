import csv
import json
from collections import defaultdict

with open("input.csv", newline="") as file:
    rows = [
        {
            "id": row["id"],
            "time": int(row["time"]),
            "g": int(row["g"]),
            "y": float(row["y"]),
        }
        for row in csv.DictReader(file)
    ]

units = defaultdict(dict)
for row in rows:
    units[row["id"]][row["time"]] = row

estimates = []
weighted_sum = 0.0
total_treated_units = 0
total_rows = 0

for cohort in (3, 5, 7):
    window = range(cohort - 2, cohort + 3)
    sample = []
    treated_units = 0

    for unit_rows in units.values():
        if not all(time in unit_rows for time in window):
            continue

        g = unit_rows[cohort]["g"]
        if g != cohort and g != 0 and g <= cohort + 2:
            continue

        treated_units += int(g == cohort)
        sample.extend(
            (
                unit_rows[time]["id"],
                time,
                int(g == cohort and time >= cohort),
                unit_rows[time]["y"],
            )
            for time in window
        )

    unit_totals = defaultdict(lambda: [0.0, 0.0, 0])
    time_totals = defaultdict(lambda: [0.0, 0.0, 0])

    for unit_id, time, did, y in sample:
        for totals in (unit_totals[unit_id], time_totals[time]):
            totals[0] += did
            totals[1] += y
            totals[2] += 1

    mean_did = sum(row[2] for row in sample) / len(sample)
    mean_y = sum(row[3] for row in sample) / len(sample)
    numerator = denominator = 0.0

    for unit_id, time, did, y in sample:
        unit = unit_totals[unit_id]
        period = time_totals[time]
        residual_did = did - unit[0] / unit[2] - period[0] / period[2] + mean_did
        residual_y = y - unit[1] / unit[2] - period[1] / period[2] + mean_y
        numerator += residual_did * residual_y
        denominator += residual_did**2

    estimate = numerator / denominator
    estimates.append({
        "term": f"att_g{cohort}",
        "estimate": estimate,
        "se": None,
        "n_obs": len(sample),
    })
    weighted_sum += treated_units * estimate
    total_treated_units += treated_units
    total_rows += len(sample)

estimates.append({
    "term": "att_weighted",
    "estimate": weighted_sum / total_treated_units,
    "se": None,
    "n_obs": total_rows,
})

result = {
    "task_id": "broad_cohort_stack",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {},
    "diagnostics": {},
}

with open("result.json", "w") as file:
    json.dump(result, file, indent=2)
