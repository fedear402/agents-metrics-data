import json

import numpy as np
import pandas as pd


def weighted_iv(y, x, instrument, weight):
    """Return the IV slope and shock-level HC1 standard error."""
    y = np.asarray(y, dtype=float)
    x = np.asarray(x, dtype=float)
    instrument = np.asarray(instrument, dtype=float)
    weight = np.asarray(weight, dtype=float)
    n = len(y)

    X = np.column_stack((np.ones(n), x))
    Z = np.column_stack((np.ones(n), instrument))

    zx = Z.T @ (weight[:, None] * X)
    zy = Z.T @ (weight * y)
    beta = np.linalg.solve(zx, zy)

    residual = y - X @ beta
    meat = Z.T @ ((weight**2 * residual**2)[:, None] * Z)
    inverse = np.linalg.inv(zx)
    covariance = (n / (n - 2)) * inverse @ meat @ inverse.T

    return float(beta[1]), float(np.sqrt(covariance[1, 1]))


df = pd.read_csv("input.csv")
region_columns = ["region_weight", "x", "y"]

regions = df.groupby("region_id", sort=False)[region_columns].first()
weight = regions["region_weight"].to_numpy(dtype=float)
e = weight / weight.sum()

shares = df.pivot(index="region_id", columns="industry_id", values="share")
shares = shares.reindex(index=regions.index)
shocks = df.groupby("industry_id")["shock"].first().reindex(shares.columns)
A = shares.to_numpy(dtype=float)
g = shocks.to_numpy(dtype=float)

z = A @ g
x = regions["x"].to_numpy(dtype=float)
y = regions["y"].to_numpy(dtype=float)

y0 = y - e @ y
x0 = x - e @ x
z0 = z - e @ z

s = A.T @ e
ybar = (A.T @ (e * y0)) / s
xbar = (A.T @ (e * x0)) / s
zbar = (A.T @ (e * z0)) / s

effect, effect_se = weighted_iv(ybar, xbar, g, s)
first_stage, first_stage_se = weighted_iv(xbar, zbar, g, s)
effective_shocks = float(1.0 / np.sum(s**2))
n_industries = int(len(s))

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {
            "term": "effect",
            "estimate": effect,
            "se": effect_se,
            "n_obs": n_industries,
        },
        {
            "term": "first_stage",
            "estimate": first_stage,
            "se": first_stage_se,
            "n_obs": n_industries,
        },
        {
            "term": "effective_shocks",
            "estimate": effective_shocks,
            "se": None,
            "n_obs": n_industries,
        },
    ],
    "method_metadata": {
        "estimator": "Weighted shift-share 2SLS with BHJ shock-level aggregation",
        "vcov": "Shock-level heteroskedasticity-robust HC1; N/(N-2)",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file, allow_nan=False)
