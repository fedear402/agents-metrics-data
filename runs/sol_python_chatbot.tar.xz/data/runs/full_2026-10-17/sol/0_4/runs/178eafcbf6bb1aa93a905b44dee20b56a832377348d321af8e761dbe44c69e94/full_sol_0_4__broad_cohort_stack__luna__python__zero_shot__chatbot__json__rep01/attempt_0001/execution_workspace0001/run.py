import csv
import json
from collections import defaultdict

WINDOW_LENGTH = 5
cohorts = (3, 5, 7)

with open("input.csv", newline="", encoding="utf-8-sig") as file:
    rows = [
        {
            "id": row["id"],
            "time": int(row["time"]),
            "g": int(row["g"]),
            "y": float(row["y"]),
        }
        for row in csv.DictReader(file)
    ]

results = []
treated_weights = []

for cohort in cohorts:
    times = set(range(cohort - 2, cohort + 3))
    by_unit = defaultdict(list)

    for row in rows:
        if row["time"] in times and (
            row["g"] == cohort or row["g"] == 0 or row["g"] > cohort + 2
        ):
            by_unit[row["id"]].append(row)

    balanced = [
        unit_rows
        for unit_rows in by_unit.values()
        if len(unit_rows) == WINDOW_LENGTH
        and {row["time"] for row in unit_rows} == times
    ]

    comparison = [row for unit_rows in balanced for row in unit_rows]
    treated_units = sum(
        unit_rows[0]["g"] == cohort for unit_rows in balanced
    )
    treated_weights.append(treated_units)

    unit_sums = defaultdict(lambda: [0.0, 0.0])
    time_sums = defaultdict(lambda: [0.0, 0.0])
    total_y = 0.0
    total_did = 0.0

    for row in comparison:
        did = float(row["g"] == cohort and row["time"] >= cohort)
        row["did"] = did
        unit_sums[row["id"]][0] += row["y"]
        unit_sums[row["id"]][1] += did
        time_sums[row["time"]][0] += row["y"]
        time_sums[row["time"]][1] += did
        total_y += row["y"]
        total_did += did

    n_obs = len(comparison)
    mean_y = total_y / n_obs
    mean_did = total_did / n_obs
    numerator = 0.0
    denominator = 0.0

    for row in comparison:
        unit_y, unit_did = unit_sums[row["id"]]
        time_y, time_did = time_sums[row["time"]]

        y_residual = (
            row["y"]
            - unit_y / WINDOW_LENGTH
            - time_y / len(balanced)
            + mean_y
        )
        did_residual = (
            row["did"]
            - unit_did / WINDOW_LENGTH
            - time_did / len(balanced)
            + mean_did
        )
        numerator += did_residual * y_residual
        denominator += did_residual * did_residual

    if denominator == 0:
        raise ValueError(f"did is not identified for cohort {cohort}")

    results.append(
        {
            "term": f"att_g{cohort}",
            "estimate": numerator / denominator,
            "se": None,
            "n_obs": n_obs,
        }
    )

weight_sum = sum(treated_weights)
if weight_sum == 0:
    raise ValueError("No treated units were retained")

weighted_att = sum(
    result["estimate"] * weight
    for result, weight in zip(results, treated_weights)
) / weight_sum

results.append(
    {
        "term": "att_weighted",
        "estimate": weighted_att,
        "se": None,
        "n_obs": sum(result["n_obs"] for result in results),
    }
)

output = {
    "task_id": "broad_cohort_stack",
    "platform": "python",
    "estimates": results,
    "method_metadata": {},
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(output, file, indent=2)
