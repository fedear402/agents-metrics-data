import json

import numpy as np
import pandas as pd
from scipy.stats import f

data = pd.read_csv("input.csv")
n = len(data)
y = data["y"].to_numpy(dtype=float)
d = data["endog"].to_numpy(dtype=float)
x = data["x"].to_numpy(dtype=float)
z1 = data["z1"].to_numpy(dtype=float)
z2 = data["z2"].to_numpy(dtype=float)

restricted = np.column_stack((np.ones(n), x))
unrestricted = np.column_stack((restricted, z1, z2))
q = 2
df = n - unrestricted.shape[1]
critical = f.ppf(0.95, q, df)


def residual(vector, design):
    coefficients = np.linalg.lstsq(design, vector, rcond=None)[0]
    return vector - design @ coefficients


ry = residual(y, restricted)
rd = residual(d, restricted)
uy = residual(y, unrestricted)
ud = residual(d, unrestricted)

factor = 1.0 + q * critical / df
a = float(rd @ rd - factor * (ud @ ud))
b = float(-2.0 * (ry @ rd - factor * (uy @ ud)))
c = float(ry @ ry - factor * (uy @ uy))

discriminant = b * b - 4.0 * a * c
if a == 0.0 or discriminant <= 0.0:
    raise ValueError("Expected two distinct finite Anderson-Rubin boundaries")

roots = np.sort(np.roots([a, b, c]).real)
boundary_low, boundary_high = map(float, roots)

def ar_f(beta):
    r = ry - beta * rd
    u = uy - beta * ud
    ssr_r = float(r @ r)
    ssr_u = float(u @ u)
    return ((ssr_r - ssr_u) / q) / (ssr_u / df)


rows = [
    ("boundary_low", boundary_low),
    ("boundary_high", boundary_high),
    ("accepts_zero", float(c <= 0.0)),
    ("unbounded", float(a < 0.0)),
    ("ar_f_at_one", float(ar_f(1.0))),
]

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": [
        {"term": term, "estimate": estimate, "se": None, "n_obs": n}
        for term, estimate in rows
    ],
    "method_metadata": {
        "estimator": "Anderson-Rubin confidence set by inversion of the joint F test",
        "vcov": "Conventional homoskedastic OLS",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
