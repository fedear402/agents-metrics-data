import json

import numpy as np
import pandas as pd
import statsmodels.api as sm

data = pd.read_csv("input.csv")
outcomes = [0, 1, 2]
assert len(data) == 480
assert sorted(data["y"].unique().tolist()) == outcomes
assert data[["y", "x", "z"]].notna().all().all()

design = sm.add_constant(data[["x", "z"]], has_constant="add")
fit = sm.MNLogit(data["y"], design).fit(
    method="newton", maxiter=1000, tol=1e-12, disp=False
)
assert fit.mle_retvals["converged"]

coefficients = fit.params.copy()
errors = fit.bse.copy()
assert list(coefficients.columns) == [0, 1]
coefficients.columns = [1, 2]
errors.columns = [1, 2]

zero = pd.DataFrame({"const": [1.0], "x": [0.0], "z": [0.0]})
probability_cat2 = float(np.asarray(fit.predict(zero))[0, 2])
n_obs = int(len(data))

def row(term, estimate, se):
    return {
        "term": term,
        "estimate": float(estimate),
        "se": None if se is None else float(se),
        "n_obs": n_obs,
    }

result = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": [
        row("x_cat1", coefficients.loc["x", 1], errors.loc["x", 1]),
        row("z_cat1", coefficients.loc["z", 1], errors.loc["z", 1]),
        row("x_cat2", coefficients.loc["x", 2], errors.loc["x", 2]),
        row("z_cat2", coefficients.loc["z", 2], errors.loc["z", 2]),
        row("prob_cat2_zero", probability_cat2, None),
    ],
    "method_metadata": {
        "estimator": "Multinomial logit maximum likelihood",
        "vcov": "Inverse observed information",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
