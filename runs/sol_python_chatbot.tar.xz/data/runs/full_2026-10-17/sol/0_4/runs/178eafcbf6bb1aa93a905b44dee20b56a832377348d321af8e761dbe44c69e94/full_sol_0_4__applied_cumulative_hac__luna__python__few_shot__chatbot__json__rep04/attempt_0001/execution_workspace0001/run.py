import json

import numpy as np
import pandas as pd

data = pd.read_csv("input.csv", parse_dates=["date"])
data = data.sort_values("date").reset_index(drop=True)

change = np.log(data["vix"]).diff()
regressors = pd.DataFrame(
    {f"lag_{k}": change.shift(k) for k in range(1, 16)}
)
sample = regressors.copy()
sample["log_sales"] = np.log(data["sales"])
sample = sample.dropna()

n = len(sample)
x = np.column_stack(
    [np.ones(n), sample[[f"lag_{k}" for k in range(1, 16)]].to_numpy()]
)
y = sample["log_sales"].to_numpy()

coefficients = np.linalg.lstsq(x, y, rcond=None)[0]
residuals = y - x @ coefficients
scores = x * residuals[:, None]

meat = scores.T @ scores
for j in range(1, 16):
    weight = 1.0 - j / 16.0
    lag_product = scores[j:].T @ scores[:-j]
    meat += weight * (lag_product + lag_product.T)

bread = np.linalg.inv(x.T @ x)
covariance = (n / (n - 16)) * bread @ meat @ bread

contrast = np.r_[0.0, np.ones(15)]
cumulative = float(contrast @ coefficients)
cumulative_variance = float(contrast @ covariance @ contrast)

def standard_error(variance):
    return float(np.sqrt(max(variance, 0.0)))

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {
            "term": "cumulative_response",
            "estimate": cumulative,
            "se": standard_error(cumulative_variance),
            "n_obs": n,
        },
        {
            "term": "lag_1",
            "estimate": float(coefficients[1]),
            "se": standard_error(covariance[1, 1]),
            "n_obs": n,
        },
        {
            "term": "lag_15",
            "estimate": float(coefficients[15]),
            "se": standard_error(covariance[15, 15]),
            "n_obs": n,
        },
    ],
    "method_metadata": {
        "estimator": "OLS with intercept and 15 observed-row lags of log VIX changes",
        "vcov": "Bartlett Newey-West HAC, maximum lag 15, multiplied by N/(N-16)",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
