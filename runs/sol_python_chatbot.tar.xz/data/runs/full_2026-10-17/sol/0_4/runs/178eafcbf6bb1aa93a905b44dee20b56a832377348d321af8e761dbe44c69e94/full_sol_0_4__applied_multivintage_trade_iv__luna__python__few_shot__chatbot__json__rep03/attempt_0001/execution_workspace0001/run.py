import json

import numpy as np
import pandas as pd


def exposure(areas, employment, trade, industry_order, vintage, change_column):
    area_rows = areas.loc[areas["vintage"] == vintage].copy()
    emp_rows = employment.loc[employment["vintage"] == vintage]

    keys = ["area", "period"]
    grid = area_rows[keys].merge(
        pd.DataFrame({"industry": industry_order}), how="cross"
    )
    grid = grid.merge(
        emp_rows[keys + ["industry", "employment"]],
        on=keys + ["industry"],
        how="left",
        validate="one_to_one",
    )
    grid["employment"] = grid["employment"].fillna(0.0)

    national = (
        grid.groupby(["period", "industry"], as_index=False)["employment"]
        .sum()
        .rename(columns={"employment": "national_employment"})
    )
    grid = grid.merge(national, on=["period", "industry"], validate="many_to_one")
    grid = grid.merge(
        trade[["period", "industry", change_column, "price_index", "years"]],
        on=["period", "industry"],
        validate="many_to_one",
    )
    grid = grid.merge(
        area_rows[keys + ["total_employment"]],
        on=keys,
        validate="many_to_one",
    )

    grid["contribution"] = (
        grid["employment"]
        / grid["total_employment"]
        * grid[change_column]
        / grid["national_employment"]
        / (grid["price_index"] / 100.0)
        / 1000.0
        * (10.0 / grid["years"])
    )
    return grid.groupby(keys, as_index=False)["contribution"].sum()


def main():
    crosswalk = pd.read_csv("crosswalk.csv")
    trade = pd.read_csv("trade.csv").merge(
        crosswalk[["code", "industry"]],
        on="code",
        validate="many_to_one",
    )
    areas = pd.read_csv("areas.csv")
    employment = pd.read_csv("employment.csv")
    outcomes = pd.read_csv("outcomes.csv")

    industries = crosswalk["industry"].drop_duplicates().tolist()
    x = exposure(areas, employment, trade, industries, "base", "us_change")
    z = exposure(areas, employment, trade, industries, "early", "other_change")

    data = outcomes.merge(
        x.rename(columns={"contribution": "x"}),
        on=["area", "period"],
        validate="one_to_one",
    ).merge(
        z.rename(columns={"contribution": "z"}),
        on=["area", "period"],
        validate="one_to_one",
    ).merge(
        areas.loc[areas["vintage"] == "base", ["area", "period", "population"]],
        on=["area", "period"],
        validate="one_to_one",
    )
    assert len(data) == 72

    exog = np.column_stack(
        [np.ones(len(data)), data["period"], data["control"]]
    ).astype(float)
    regressors = np.column_stack([exog, data["x"]])
    instruments = np.column_stack([exog, data["z"]])
    response = data["change_pp"].to_numpy(dtype=float)
    sqrt_weight = np.sqrt(data["population"].to_numpy(dtype=float))

    weighted_regressors = regressors * sqrt_weight[:, None]
    weighted_instruments = instruments * sqrt_weight[:, None]
    weighted_response = response * sqrt_weight
    projected_regressors = weighted_instruments @ np.linalg.solve(
        weighted_instruments.T @ weighted_instruments,
        weighted_instruments.T @ weighted_regressors,
    )
    coefficients = np.linalg.solve(
        projected_regressors.T @ weighted_regressors,
        projected_regressors.T @ weighted_response,
    )

    def value(column, period):
        row = data.loc[(data["area"] == 0) & (data["period"] == period)]
        assert len(row) == 1
        return float(row[column].iloc[0])

    estimates = [
        ("iv_slope", float(coefficients[-1])),
        ("exposure_area0_period0", value("x", 0)),
        ("exposure_area0_period1", value("x", 1)),
        ("instrument_area0_period0", value("z", 0)),
    ]
    result = {
        "task_id": "applied_multivintage_trade_iv",
        "platform": "python",
        "estimates": [
            {"term": term, "estimate": estimate, "se": None, "n_obs": 72}
            for term, estimate in estimates
        ],
        "method_metadata": {
            "estimator": "weighted 2SLS",
            "regressors": ["intercept", "period", "control", "x"],
            "instruments": ["intercept", "period", "control", "z"],
            "weight": "base-vintage population",
            "exposure_unit": "thousands of real dollars per worker per decade",
        },
        "diagnostics": {"estimation_rows": 72},
    }
    with open("result.json", "w", encoding="utf-8") as output:
        json.dump(result, output, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
