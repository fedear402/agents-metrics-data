import json

import numpy as np
import pandas as pd
from scipy.stats import f

data = pd.read_csv("input.csv")
n = len(data)

y = data["y"].to_numpy(dtype=float)
endog = data["endog"].to_numpy(dtype=float)
x = data["x"].to_numpy(dtype=float)
z1 = data["z1"].to_numpy(dtype=float)
z2 = data["z2"].to_numpy(dtype=float)

restricted = np.column_stack((np.ones(n), x))
unrestricted = np.column_stack((restricted, z1, z2))


def residual(vector, design):
    coefficients = np.linalg.lstsq(design, vector, rcond=None)[0]
    return vector - design @ coefficients


ry = residual(y, restricted)
re = residual(endog, restricted)
uy = residual(y, unrestricted)
ue = residual(endog, unrestricted)

critical = f.ppf(0.95, 2, n - 4)
scale = 2 * critical / (n - 4)

# F(beta) <= critical is equivalent to polynomial(beta) <= 0.
a = (re @ re - ue @ ue) - scale * (ue @ ue)
b = -2 * ((ry @ re - uy @ ue) - scale * (uy @ ue))
c = (ry @ ry - uy @ uy) - scale * (uy @ uy)

roots = np.sort(np.roots([a, b, c]))
if len(roots) != 2 or np.any(np.abs(roots.imag) > 1e-8):
    raise ValueError("Expected two finite real confidence-set boundaries.")

boundary_low, boundary_high = roots.real
accepts_zero = float(c <= 0)
unbounded = float(a < 0)

restricted_ssr_at_one = np.sum((ry - re) ** 2)
unrestricted_ssr_at_one = np.sum((uy - ue) ** 2)
ar_f_at_one = (
    (restricted_ssr_at_one - unrestricted_ssr_at_one) / 2
) / (unrestricted_ssr_at_one / (n - 4))

terms = {
    "boundary_low": float(boundary_low),
    "boundary_high": float(boundary_high),
    "accepts_zero": accepts_zero,
    "unbounded": unbounded,
    "ar_f_at_one": float(ar_f_at_one),
}

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": [
        {"term": term, "estimate": value, "se": None, "n_obs": n}
        for term, value in terms.items()
    ],
    "method_metadata": {
        "estimator": "Anderson-Rubin confidence set by exact quadratic F-test inversion",
        "vcov": "Conventional homoskedastic OLS",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output)
