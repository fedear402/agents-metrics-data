import json

import numpy as np
import pandas as pd

data = pd.read_csv("input.csv")
data = data.loc[data["score"].abs() < 1].copy()

score = data["score"].to_numpy(dtype=float)
right = (score >= 0).astype(float)
weights = 1 - np.abs(score)

# Separate intercepts and slopes for the left and right limits.
X = np.column_stack((1 - right, (1 - right) * score, right, right * score))
Y = data[["earnings", "participated"]].to_numpy(dtype=float)

bread = np.linalg.inv(X.T @ (weights[:, None] * X))
coefficients = bread @ X.T @ (weights[:, None] * Y)
residuals = Y - X @ coefficients

contrast = np.array([-1.0, 0.0, 1.0, 0.0])
jumps = contrast @ coefficients
loading = weights * (X @ bread @ contrast)
influence = loading[:, None] * residuals
joint_covariance = influence.T @ influence

reduced_form, first_stage = jumps
treatment_effect = reduced_form / first_stage
gradient = np.array([
    1 / first_stage,
    -reduced_form / first_stage**2,
])

n_obs = int(len(data))
result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {
            "term": "treatment_effect",
            "estimate": float(treatment_effect),
            "se": float(np.sqrt(gradient @ joint_covariance @ gradient)),
            "n_obs": n_obs,
        },
        {
            "term": "reduced_form",
            "estimate": float(reduced_form),
            "se": float(np.sqrt(joint_covariance[0, 0])),
            "n_obs": n_obs,
        },
        {
            "term": "first_stage",
            "estimate": float(first_stage),
            "se": float(np.sqrt(joint_covariance[1, 1])),
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "Fuzzy regression discontinuity; local linear with separate side slopes, bandwidth 1, triangular weights",
        "vcov": "Joint heteroskedasticity-robust HC0; delta method for ratio",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
