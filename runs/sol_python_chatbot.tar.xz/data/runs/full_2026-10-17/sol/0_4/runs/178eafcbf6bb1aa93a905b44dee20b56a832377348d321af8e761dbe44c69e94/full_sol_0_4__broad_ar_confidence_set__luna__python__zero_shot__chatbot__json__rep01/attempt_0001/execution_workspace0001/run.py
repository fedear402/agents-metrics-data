import json

import numpy as np
import pandas as pd
from scipy.stats import f


def residualize(v, design):
    coefficients = np.linalg.lstsq(design, v, rcond=None)[0]
    return v - design @ coefficients


data = pd.read_csv("input.csv")
n = len(data)

y = data["y"].to_numpy(dtype=float)
endog = data["endog"].to_numpy(dtype=float)
x = data["x"].to_numpy(dtype=float)
z1 = data["z1"].to_numpy(dtype=float)
z2 = data["z2"].to_numpy(dtype=float)

restricted_design = np.column_stack((np.ones(n), x))
unrestricted_design = np.column_stack((np.ones(n), x, z1, z2))

ry = residualize(y, restricted_design)
rd = residualize(endog, restricted_design)
uy = residualize(y, unrestricted_design)
ud = residualize(endog, unrestricted_design)

restricted_ssr = np.array([
    rd @ rd,
    -2 * ry @ rd,
    ry @ ry,
])
unrestricted_ssr = np.array([
    ud @ ud,
    -2 * uy @ ud,
    uy @ uy,
])

critical_value = f.ppf(0.95, 2, n - 4)
test_polynomial = (
    (n - 4) * (restricted_ssr - unrestricted_ssr)
    - 2 * critical_value * unrestricted_ssr
)

roots = np.roots(test_polynomial)
if len(roots) != 2 or np.any(np.abs(roots.imag) > 1e-8):
    raise ValueError("Expected two finite real Anderson-Rubin boundaries.")

boundary_low, boundary_high = sorted(roots.real)

def ssr_at_one(coefficients):
    return float(np.sum(coefficients))

ar_f_at_one = (
    (restricted_ssr.sum() - unrestricted_ssr.sum()) / 2
) / (unrestricted_ssr.sum() / (n - 4))

accepts_zero = float(test_polynomial[2] <= 0)
unbounded = float(test_polynomial[0] < 0)

values = {
    "boundary_low": float(boundary_low),
    "boundary_high": float(boundary_high),
    "accepts_zero": accepts_zero,
    "unbounded": unbounded,
    "ar_f_at_one": float(ar_f_at_one),
}

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": [
        {"term": term, "estimate": estimate, "se": None, "n_obs": n}
        for term, estimate in values.items()
    ],
    "method_metadata": {
        "estimator": "Anderson-Rubin test inversion",
        "vcov": "Conventional homoskedastic OLS",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output)
