import json

import numpy as np
import pandas as pd


def main():
    households = pd.read_csv("households.csv")
    census = pd.read_csv("census.csv")
    sample = households.loc[households["recipient"] == 0].copy()

    eligible = sample["eligible"].to_numpy(dtype=float)
    ineligible = 1.0 - eligible
    baseline = sample["baseline"].to_numpy(dtype=float)
    dose = sample["dose"].to_numpy(dtype=float)
    instrument = sample["instrument"].to_numpy(dtype=float)
    outcome = sample["outcome"].to_numpy(dtype=float)
    weight = sample["weight"].to_numpy(dtype=float)

    # Column order: four exogenous terms, then two endogenous dose terms.
    exogenous = np.column_stack(
        (ineligible, eligible, baseline * ineligible, baseline * eligible)
    )
    endogenous = np.column_stack((dose * ineligible, dose * eligible))
    x = np.column_stack((exogenous, endogenous))
    z = np.column_stack(
        (exogenous, instrument * ineligible, instrument * eligible)
    )

    # Weighted, exactly identified 2SLS.
    sqrt_weight = np.sqrt(weight)
    xw = x * sqrt_weight[:, None]
    zw = z * sqrt_weight[:, None]
    yw = outcome * sqrt_weight
    projected_x = zw @ np.linalg.solve(zw.T @ zw, zw.T @ xw)
    coefficients = np.linalg.solve(projected_x.T @ xw, projected_x.T @ yw)

    group_effects = {}
    for group in (0, 1):
        mask = eligible == group
        mean_dose = np.average(dose[mask], weights=weight[mask])
        group_effects[group] = float(coefficients[4 + group] * mean_dose)

    populations = census.groupby("eligible")["nonrecipient_population"].sum()
    population_effect = float(
        np.average(
            [group_effects[0], group_effects[1]],
            weights=[populations.loc[0], populations.loc[1]],
        )
    )

    n_obs = int(len(sample))
    estimates = [
        {
            "term": term,
            "estimate": value,
            "se": None,
            "n_obs": n_obs,
        }
        for term, value in (
            ("ineligible_effect", group_effects[0]),
            ("eligible_nonrecipient_effect", group_effects[1]),
            ("population_effect", population_effect),
        )
    ]

    result = {
        "task_id": "applied_nonrecipient_population_iv",
        "platform": "python",
        "estimates": estimates,
        "method_metadata": {
            "estimator": "weighted 2SLS",
            "sample": "All households with recipient=0, in both village treatment statuses",
            "exogenous_columns": [
                "1-eligible",
                "eligible",
                "baseline*(1-eligible)",
                "baseline*eligible",
            ],
            "endogenous_columns": [
                "dose*(1-eligible)",
                "dose*eligible",
            ],
            "excluded_instruments": [
                "instrument*(1-eligible)",
                "instrument*eligible",
            ],
            "regression_weight": "weight",
            "group_effect": "Group dose slope times its household-weighted mean dose",
            "population_weight": "nonrecipient_population from census.csv",
            "counterfactual": "Dose is zero for every retained household; attribution follows the stated synthetic convention",
        },
        "diagnostics": {
            "n_obs": n_obs,
            "n_ineligible": int(np.count_nonzero(eligible == 0)),
            "n_eligible_nonrecipient": int(np.count_nonzero(eligible == 1)),
        },
    }

    with open("result.json", "w", encoding="utf-8") as output:
        json.dump(result, output, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
