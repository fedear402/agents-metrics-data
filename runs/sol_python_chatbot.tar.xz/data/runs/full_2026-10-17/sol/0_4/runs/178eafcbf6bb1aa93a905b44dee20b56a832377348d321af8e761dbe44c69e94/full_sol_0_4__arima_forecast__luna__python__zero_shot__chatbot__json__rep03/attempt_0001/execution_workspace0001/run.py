import json

import pandas as pd
from statsmodels.tsa.arima.model import ARIMA

data = pd.read_csv("./input.csv")
data = data.sort_values("t")
y = pd.to_numeric(data["y"], errors="raise")
if y.isna().any():
    raise ValueError("Column y contains missing values.")
if int(data["t"].iloc[-1]) != 250:
    raise ValueError("The last observed time must be t = 250.")

model = ARIMA(y, order=(1, 1, 1), trend="n")
fit = model.fit()
prediction = fit.get_forecast(steps=1)
forecast = float(prediction.predicted_mean.iloc[0])
se = float(prediction.se_mean.iloc[0])
interval = prediction.conf_int(alpha=0.05)
lower = float(interval.iloc[0, 0])
upper = float(interval.iloc[0, 1])
n_obs = int(len(y))

result = {
    "task_id": "arima_forecast",
    "platform": "python",
    "estimates": [
        {"term": "forecast", "estimate": forecast, "se": se, "n_obs": n_obs},
        {"term": "lower_95", "estimate": lower, "se": None, "n_obs": n_obs},
        {"term": "upper_95", "estimate": upper, "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "ARIMA(1,1,1) maximum likelihood, no constant or drift",
        "vcov": "Model-based forecast variance; 95% Gaussian prediction interval",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output, allow_nan=False, indent=2)
