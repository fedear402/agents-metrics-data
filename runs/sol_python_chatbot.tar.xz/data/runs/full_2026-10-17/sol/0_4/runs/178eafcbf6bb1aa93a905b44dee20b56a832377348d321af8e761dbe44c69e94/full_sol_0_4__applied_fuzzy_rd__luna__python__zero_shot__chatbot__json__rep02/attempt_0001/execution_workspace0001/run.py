import json

import numpy as np
import pandas as pd


def main():
    data = pd.read_csv("input.csv")
    sample = data.loc[data["score"].abs() < 1].dropna(
        subset=["score", "participated", "earnings"]
    )

    x = sample["score"].to_numpy(dtype=float)
    y = sample["earnings"].to_numpy(dtype=float)
    d = sample["participated"].to_numpy(dtype=float)
    w = 1.0 - np.abs(x)

    left = (x < 0).astype(float)
    right = (x >= 0).astype(float)
    X = np.column_stack((left, left * x, right, right * x))

    bread = np.linalg.inv(X.T @ (w[:, None] * X))
    beta_y = bread @ (X.T @ (w * y))
    beta_d = bread @ (X.T @ (w * d))

    residual_y = y - X @ beta_y
    residual_d = d - X @ beta_d
    contrast = np.array([-1.0, 0.0, 1.0, 0.0])
    influence = (w[:, None] * X) @ bread.T @ contrast

    reduced_form = float(contrast @ beta_y)
    first_stage = float(contrast @ beta_d)
    var_y = float(np.sum((influence * residual_y) ** 2))
    var_d = float(np.sum((influence * residual_d) ** 2))
    cov_yd = float(np.sum(influence**2 * residual_y * residual_d))

    treatment_effect = reduced_form / first_stage
    var_effect = (
        var_y / first_stage**2
        + reduced_form**2 * var_d / first_stage**4
        - 2.0 * reduced_form * cov_yd / first_stage**3
    )

    n_obs = int(len(sample))
    result = {
        "task_id": "applied_fuzzy_rd",
        "platform": "python",
        "estimates": [
            {
                "term": "treatment_effect",
                "estimate": treatment_effect,
                "se": float(np.sqrt(max(var_effect, 0.0))),
                "n_obs": n_obs,
            },
            {
                "term": "reduced_form",
                "estimate": reduced_form,
                "se": float(np.sqrt(max(var_y, 0.0))),
                "n_obs": n_obs,
            },
            {
                "term": "first_stage",
                "estimate": first_stage,
                "se": float(np.sqrt(max(var_d, 0.0))),
                "n_obs": n_obs,
            },
        ],
        "method_metadata": {
            "estimator": "Fuzzy RD ratio of triangular-weighted local-linear discontinuities; cutoff 0; bandwidth 1",
            "vcov": "HC0 sandwich; joint outcome-participation covariance; delta method; no degrees-of-freedom correction",
        },
        "diagnostics": {},
    }

    with open("result.json", "w", encoding="utf-8") as output:
        json.dump(result, output, allow_nan=False)


if __name__ == "__main__":
    main()
