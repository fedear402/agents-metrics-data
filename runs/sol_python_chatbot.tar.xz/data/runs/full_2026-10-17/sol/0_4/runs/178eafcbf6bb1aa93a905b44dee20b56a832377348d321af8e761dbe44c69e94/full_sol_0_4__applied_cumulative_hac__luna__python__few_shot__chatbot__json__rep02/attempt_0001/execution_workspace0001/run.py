import json

import numpy as np
import pandas as pd


data = pd.read_csv("input.csv", parse_dates=["date"])
data = data.sort_values("date").reset_index(drop=True)

change = np.log(data["vix"]).diff()
lag_columns = []
for lag in range(1, 16):
    column = f"lag_{lag}"
    data[column] = change.shift(lag)
    lag_columns.append(column)

data["log_sales"] = np.log(data["sales"])
sample = data.dropna(subset=["log_sales", *lag_columns])
n_obs = len(sample)

X = np.column_stack(
    [np.ones(n_obs), sample[lag_columns].to_numpy(dtype=float)]
)
y = sample["log_sales"].to_numpy(dtype=float)

coefficients = np.linalg.lstsq(X, y, rcond=None)[0]
residuals = y - X @ coefficients
scores = X * residuals[:, None]

meat = scores.T @ scores
for lag in range(1, 16):
    weight = 1 - lag / 16
    product = scores[lag:].T @ scores[:-lag]
    meat += weight * (product + product.T)

bread = np.linalg.inv(X.T @ X)
covariance = (n_obs / (n_obs - 16)) * bread @ meat @ bread

contrast = np.r_[0.0, np.ones(15)]
cumulative_estimate = float(contrast @ coefficients)
cumulative_se = float(np.sqrt(contrast @ covariance @ contrast))

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {
            "term": "cumulative_response",
            "estimate": cumulative_estimate,
            "se": cumulative_se,
            "n_obs": n_obs,
        },
        {
            "term": "lag_1",
            "estimate": float(coefficients[1]),
            "se": float(np.sqrt(covariance[1, 1])),
            "n_obs": n_obs,
        },
        {
            "term": "lag_15",
            "estimate": float(coefficients[15]),
            "se": float(np.sqrt(covariance[15, 15])),
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "OLS of log sales on an intercept and 15 observed-row lags of log VIX changes",
        "vcov": "Bartlett Newey-West HAC, maximum lag 15, scaled by N/(N-16)",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
