import json

import pandas as pd
from statsmodels.tsa.arima.model import ARIMA


def main():
    data = pd.read_csv("./input.csv").sort_values("t")
    y = pd.to_numeric(data["y"], errors="raise")

    if y.isna().any():
        raise ValueError("The level series y contains missing values.")
    if int(data["t"].iloc[-1]) != 250:
        raise ValueError("The last observed time must be t = 250.")

    fitted = ARIMA(y, order=(1, 1, 1), trend="n").fit(method="statespace")
    prediction = fitted.get_forecast(steps=1)
    interval = prediction.conf_int(alpha=0.05).iloc[0]

    result = {
        "task_id": "arima_forecast",
        "platform": "python",
        "estimates": [
            {
                "term": "forecast",
                "estimate": float(prediction.predicted_mean.iloc[0]),
                "se": float(prediction.se_mean.iloc[0]),
                "n_obs": int(len(y)),
            },
            {
                "term": "lower_95",
                "estimate": float(interval.iloc[0]),
                "se": None,
                "n_obs": int(len(y)),
            },
            {
                "term": "upper_95",
                "estimate": float(interval.iloc[1]),
                "se": None,
                "n_obs": int(len(y)),
            },
        ],
        "method_metadata": {
            "estimator": "ARIMA(1,1,1) maximum likelihood; no constant or drift",
            "vcov": "95% Gaussian one-step-ahead prediction interval",
        },
        "diagnostics": {},
    }

    with open("result.json", "w", encoding="utf-8") as output:
        json.dump(result, output, allow_nan=False, indent=2)


if __name__ == "__main__":
    main()
