import json

import pandas as pd
import statsmodels.api as sm

data = pd.read_csv("input.csv")
n_obs = len(data)

X = sm.add_constant(data[["x", "z"]], has_constant="add")
model = sm.MNLogit(data["y"], X)
fit = model.fit(method="newton", disp=False, maxiter=200)

params = fit.params
ses = fit.bse
prob_cat2_zero = float(
    fit.predict(pd.DataFrame({"const": [1.0], "x": [0.0], "z": [0.0]})).iloc[0, 2]
)

estimates = [
    {
        "term": f"{variable}_cat{category}",
        "estimate": float(params.iloc[X.columns.get_loc(variable), category - 1]),
        "se": float(ses.iloc[X.columns.get_loc(variable), category - 1]),
        "n_obs": n_obs,
    }
    for category in (1, 2)
    for variable in ("x", "z")
]
estimates.append(
    {
        "term": "prob_cat2_zero",
        "estimate": prob_cat2_zero,
        "se": None,
        "n_obs": n_obs,
    }
)

result = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "Multinomial logit maximum likelihood; outcome 0 base",
        "vcov": "Inverse observed information",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output)
