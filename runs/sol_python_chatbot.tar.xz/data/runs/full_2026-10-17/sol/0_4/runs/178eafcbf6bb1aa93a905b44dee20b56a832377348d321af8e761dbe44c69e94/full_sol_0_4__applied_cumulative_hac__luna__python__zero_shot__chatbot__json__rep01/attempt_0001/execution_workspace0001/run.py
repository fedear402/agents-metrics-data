import json
import math

import pandas as pd
import statsmodels.api as sm
from statsmodels.stats.sandwich_covariance import cov_hac

data = pd.read_csv("input.csv", parse_dates=["date"]).sort_values("date")
data["log_sales"] = data["sales"].map(math.log)
data["vix_change"] = data["vix"].map(math.log).diff()

lag_names = [f"lag_{i}" for i in range(1, 16)]
for i, name in enumerate(lag_names, start=1):
    data[name] = data["vix_change"].shift(i)

sample = data[["log_sales", *lag_names]].dropna()
n_obs = len(sample)
if n_obs <= 16:
    raise ValueError("The regression requires more than 16 complete observations.")

x = sm.add_constant(sample[lag_names])
fit = sm.OLS(sample["log_sales"], x).fit()

cov = cov_hac(fit, nlags=15, weights_func=lambda nlags: [
    1 - j / 16 for j in range(nlags + 1)
], use_correction=False)
cov *= n_obs / (n_obs - 16)

positions = [x.columns.get_loc(name) for name in lag_names]
cumulative_variance = cov[positions][:, positions].sum()

def row(term, estimate, variance):
    return {
        "term": term,
        "estimate": float(estimate),
        "se": float(math.sqrt(max(0.0, variance))),
        "n_obs": n_obs,
    }

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        row("cumulative_response", fit.params[lag_names].sum(), cumulative_variance),
        row("lag_1", fit.params["lag_1"], cov[x.columns.get_loc("lag_1"), x.columns.get_loc("lag_1")]),
        row("lag_15", fit.params["lag_15"], cov[x.columns.get_loc("lag_15"), x.columns.get_loc("lag_15")]),
    ],
    "method_metadata": {
        "estimator": "OLS with intercept and 15 trading-observation lags of log VIX changes",
        "vcov": "Newey-West HAC, 15 lags, Bartlett weights 1-j/16, scaled by N/(N-16)",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output, indent=2)
