import csv
import json

import numpy as np


def read_csv(path):
    with open(path, newline="", encoding="utf-8") as file:
        return list(csv.DictReader(file))


def main():
    households = [
        row for row in read_csv("households.csv")
        if int(row["recipient"]) == 0
    ]
    if not households:
        raise ValueError("No nonrecipient households were found.")

    eligible = np.array([int(row["eligible"]) for row in households])
    if not np.all(np.isin(eligible, [0, 1])):
        raise ValueError("eligible must contain only zero and one.")

    dose = np.array([float(row["dose"]) for row in households])
    baseline = np.array([float(row["baseline"]) for row in households])
    instrument = np.array([float(row["instrument"]) for row in households])
    weight = np.array([float(row["weight"]) for row in households])
    outcome = np.array([float(row["outcome"]) for row in households])

    if not np.all(weight > 0):
        raise ValueError("All observation weights must be positive.")

    ineligible = 1 - eligible
    exogenous = np.column_stack((
        ineligible,
        eligible,
        baseline * ineligible,
        baseline * eligible,
    ))
    endogenous = np.column_stack((
        dose * ineligible,
        dose * eligible,
    ))
    excluded = np.column_stack((
        instrument * ineligible,
        instrument * eligible,
    ))

    x = np.column_stack((exogenous, endogenous))
    z = np.column_stack((exogenous, excluded))
    sqrt_weight = np.sqrt(weight)
    x_weighted = x * sqrt_weight[:, None]
    z_weighted = z * sqrt_weight[:, None]
    y_weighted = outcome * sqrt_weight

    if np.linalg.matrix_rank(z_weighted) != z.shape[1]:
        raise ValueError("The instrument matrix lacks full column rank.")

    projected_x = z_weighted @ np.linalg.lstsq(
        z_weighted, x_weighted, rcond=None
    )[0]
    if np.linalg.matrix_rank(projected_x) != x.shape[1]:
        raise ValueError("The weighted 2SLS model is underidentified.")

    coefficients = np.linalg.lstsq(
        projected_x, y_weighted, rcond=None
    )[0]

    group_effects = {}
    group_mean_doses = {}
    group_counts = {}
    for group in (0, 1):
        mask = eligible == group
        if not np.any(mask):
            raise ValueError(f"No retained households in eligibility group {group}.")
        mean_dose = float(np.average(dose[mask], weights=weight[mask]))
        group_mean_doses[group] = mean_dose
        group_counts[group] = int(np.sum(mask))
        group_effects[group] = float(coefficients[4 + group] * mean_dose)

    census_population = {}
    for row in read_csv("census.csv"):
        group = int(row["eligible"])
        if group not in (0, 1) or group in census_population:
            raise ValueError("Census must contain one row per eligibility group.")
        count = int(row["nonrecipient_population"])
        if count < 0:
            raise ValueError("Census population counts must be nonnegative.")
        census_population[group] = count

    if set(census_population) != {0, 1}:
        raise ValueError("Census must contain both eligibility groups.")
    total_population = sum(census_population.values())
    if total_population == 0:
        raise ValueError("Total nonrecipient census population must be positive.")

    population_effect = sum(
        census_population[group] * group_effects[group]
        for group in (0, 1)
    ) / total_population

    n_obs = len(households)
    result = {
        "task_id": "applied_nonrecipient_population_iv",
        "platform": "python",
        "estimates": [
            {
                "term": "ineligible_effect",
                "estimate": group_effects[0],
                "se": None,
                "n_obs": n_obs,
            },
            {
                "term": "eligible_nonrecipient_effect",
                "estimate": group_effects[1],
                "se": None,
                "n_obs": n_obs,
            },
            {
                "term": "population_effect",
                "estimate": population_effect,
                "se": None,
                "n_obs": n_obs,
            },
        ],
        "method_metadata": {
            "method": "weighted 2SLS",
            "sample": "All households with recipient=0",
            "counterfactual": (
                "Synthetic convention: dose is zero for every retained household."
            ),
            "group_effect": (
                "Fitted group-specific dose slope multiplied by the "
                "observation-weighted mean dose in that group."
            ),
            "population_aggregation": (
                "Group effects weighted by census nonrecipient_population; "
                "census counts are used only for this final aggregation."
            ),
            "intercept": "No additional intercept",
        },
        "diagnostics": {
            "n_obs": n_obs,
            "group_n_obs": {"0": group_counts[0], "1": group_counts[1]},
            "group_weighted_mean_dose": {
                "0": group_mean_doses[0],
                "1": group_mean_doses[1],
            },
            "group_dose_slopes": {
                "0": float(coefficients[4]),
                "1": float(coefficients[5]),
            },
            "census_nonrecipient_population": {
                "0": census_population[0],
                "1": census_population[1],
            },
        },
    }

    with open("result.json", "w", encoding="utf-8") as file:
        json.dump(result, file, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
