import json

import numpy as np
import pandas as pd
from scipy.stats import f

data = pd.read_csv("input.csv")
y = data["y"].to_numpy(dtype=float)
d = data["endog"].to_numpy(dtype=float)
x = data["x"].to_numpy(dtype=float)
z = data[["z1", "z2"]].to_numpy(dtype=float)

n = len(data)
q = 2
df = n - 4
restricted = np.column_stack((np.ones(n), x))
unrestricted = np.column_stack((restricted, z))


def residual(values, design):
    return values - design @ np.linalg.lstsq(design, values, rcond=None)[0]


ry = residual(y, restricted)
rd = residual(d, restricted)
uy = residual(y, unrestricted)
ud = residual(d, unrestricted)

critical = f.ppf(0.95, q, df)
k = q * critical / df
a = float(rd @ rd - (1 + k) * (ud @ ud))
b = float(-2 * (ry @ rd - (1 + k) * (uy @ ud)))
c = float(ry @ ry - (1 + k) * (uy @ uy))

discriminant = b * b - 4 * a * c
if a == 0 or discriminant <= 0:
    raise ValueError("Expected two distinct finite Anderson-Rubin boundaries")

boundaries = sorted(
    (
        (-b - np.sqrt(discriminant)) / (2 * a),
        (-b + np.sqrt(discriminant)) / (2 * a),
    )
)

u_one = uy - ud
r_one = ry - rd
ssr_u_one = float(u_one @ u_one)
ar_f_at_one = float(
    ((r_one @ r_one - ssr_u_one) / q) / (ssr_u_one / df)
)

values = {
    "boundary_low": float(boundaries[0]),
    "boundary_high": float(boundaries[1]),
    "accepts_zero": int(c <= 0),
    "unbounded": int(a < 0),
    "ar_f_at_one": ar_f_at_one,
}

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": [
        {"term": term, "estimate": value, "se": None, "n_obs": n}
        for term, value in values.items()
    ],
    "method_metadata": {
        "estimator": "Anderson-Rubin confidence set by joint F-test inversion",
        "vcov": "Conventional homoskedastic OLS",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
