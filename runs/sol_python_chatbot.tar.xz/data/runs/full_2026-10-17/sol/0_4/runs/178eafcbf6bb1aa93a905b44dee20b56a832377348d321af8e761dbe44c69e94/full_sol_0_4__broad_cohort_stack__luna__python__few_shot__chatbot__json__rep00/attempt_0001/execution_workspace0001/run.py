import json

import numpy as np
import pandas as pd


def cohort_estimate(data, cohort):
    window = list(range(cohort - 2, cohort + 3))
    eligible = data[
        data["time"].isin(window)
        & (
            (data["g"] == cohort)
            | (data["g"] == 0)
            | (data["g"] > cohort + 2)
        )
    ].copy()

    complete_ids = eligible.groupby("id")["time"].nunique()
    complete_ids = complete_ids[complete_ids == len(window)].index
    sample = eligible[eligible["id"].isin(complete_ids)].copy()

    sample["did"] = (
        (sample["g"] == cohort) & (sample["time"] >= cohort)
    ).astype(float)

    # A balanced panel permits two-way demeaning for unit and time fixed effects.
    for column in ("y", "did"):
        sample[f"{column}_residual"] = (
            sample[column]
            - sample.groupby("id")[column].transform("mean")
            - sample.groupby("time")[column].transform("mean")
            + sample[column].mean()
        )

    x = sample["did_residual"].to_numpy()
    y = sample["y_residual"].to_numpy()
    estimate = float(np.dot(x, y) / np.dot(x, x))
    treated_count = int(sample.loc[sample["g"] == cohort, "id"].nunique())

    return estimate, len(sample), treated_count


data = pd.read_csv("input.csv")
results = {cohort: cohort_estimate(data, cohort) for cohort in (3, 5, 7)}

weighted_estimate = sum(
    results[cohort][0] * results[cohort][2] for cohort in results
) / sum(results[cohort][2] for cohort in results)

estimates = [
    {
        "term": f"att_g{cohort}",
        "estimate": results[cohort][0],
        "se": None,
        "n_obs": results[cohort][1],
    }
    for cohort in (3, 5, 7)
]
estimates.append(
    {
        "term": "att_weighted",
        "estimate": float(weighted_estimate),
        "se": None,
        "n_obs": sum(results[cohort][1] for cohort in results),
    }
)

output = {
    "task_id": "broad_cohort_stack",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {},
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
