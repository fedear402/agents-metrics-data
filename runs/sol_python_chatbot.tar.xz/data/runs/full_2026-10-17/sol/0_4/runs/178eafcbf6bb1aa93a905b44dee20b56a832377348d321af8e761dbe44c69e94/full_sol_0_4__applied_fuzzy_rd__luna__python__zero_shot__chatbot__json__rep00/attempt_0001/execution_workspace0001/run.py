import json

import numpy as np
import pandas as pd

data = pd.read_csv("input.csv")
data = data.loc[data["score"].abs() < 1].copy()

x = data["score"].to_numpy(dtype=float)
w = 1.0 - np.abs(x)
right = (x >= 0).astype(float)
X = np.column_stack((np.ones(len(x)), right, x, x * right))
Y = data[["earnings", "participated"]].to_numpy(dtype=float)

bread = np.linalg.inv(X.T @ (w[:, None] * X))
beta = bread @ (X.T @ (w[:, None] * Y))
residuals = Y - X @ beta

# The right-side indicator coefficient is each discontinuity.
jumps = beta[1, :]
influence = (w * (X @ bread[:, 1]))[:, None] * residuals
joint_cov = influence.T @ influence  # HC0, including cross-outcome covariance

reduced_form, first_stage = jumps
treatment_effect = reduced_form / first_stage
gradient = np.array([1.0 / first_stage, -reduced_form / first_stage**2])
treatment_variance = gradient @ joint_cov @ gradient
n_obs = len(data)

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {
            "term": "treatment_effect",
            "estimate": float(treatment_effect),
            "se": float(np.sqrt(treatment_variance)),
            "n_obs": n_obs,
        },
        {
            "term": "reduced_form",
            "estimate": float(reduced_form),
            "se": float(np.sqrt(joint_cov[0, 0])),
            "n_obs": n_obs,
        },
        {
            "term": "first_stage",
            "estimate": float(first_stage),
            "se": float(np.sqrt(joint_cov[1, 1])),
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "Fuzzy RD, triangular-weighted local linear regression, bandwidth 1",
        "vcov": "HC0 sandwich; joint covariance and delta method for ratio",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as file:
    json.dump(result, file, allow_nan=False)
