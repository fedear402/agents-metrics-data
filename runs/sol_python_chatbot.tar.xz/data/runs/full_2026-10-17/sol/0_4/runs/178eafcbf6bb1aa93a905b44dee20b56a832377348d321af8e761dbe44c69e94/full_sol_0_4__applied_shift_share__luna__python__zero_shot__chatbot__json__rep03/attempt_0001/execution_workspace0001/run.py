import json

import numpy as np
import pandas as pd


def weighted_iv(y, x, instrument, weights):
    X = np.column_stack((np.ones(len(x)), x))
    Z = np.column_stack((np.ones(len(x)), instrument))
    w = weights[:, None]

    bread = Z.T @ (w * X)
    beta = np.linalg.solve(bread, Z.T @ (weights * y))
    residual = y - X @ beta

    scores = Z * (weights * residual)[:, None]
    covariance = np.linalg.solve(
        bread,
        (scores.T @ scores) @ np.linalg.inv(bread.T),
    )
    covariance *= len(y) / (len(y) - 2)
    return float(beta[1]), float(np.sqrt(covariance[1, 1]))


data = pd.read_csv("input.csv")
regions = data.groupby("region_id", sort=False)
industries = data.groupby("industry_id", sort=False)

regional = regions[["region_weight", "x", "y"]].first()
regional["e"] = regional["region_weight"] / regional["region_weight"].sum()

data = data.join(regional["e"], on="region_id")
data["weighted_share"] = data["e"] * data["share"]

regional["z"] = (
    (data["share"] * data["shock"])
    .groupby(data["region_id"])
    .sum()
    .reindex(regional.index)
)

for variable in ("y", "x", "z"):
    regional[variable + "0"] = (
        regional[variable]
        - np.sum(regional["e"] * regional[variable])
    )

data = data.join(regional[["y0", "x0", "z0"]], on="region_id")

industry = pd.DataFrame(index=industries.size().index)
industry["s"] = data.groupby("industry_id")["weighted_share"].sum()
industry["shock"] = industries["shock"].first()
for variable in ("y0", "x0", "z0"):
    numerator = (
        data["weighted_share"] * data[variable]
    ).groupby(data["industry_id"]).sum()
    industry[variable + "bar"] = numerator / industry["s"]

industry = industry.loc[industry["s"] > 0]
N = len(industry)

s = industry["s"].to_numpy(dtype=float)
shock = industry["shock"].to_numpy(dtype=float)
ybar = industry["y0bar"].to_numpy(dtype=float)
xbar = industry["x0bar"].to_numpy(dtype=float)
zbar = industry["z0bar"].to_numpy(dtype=float)

effect, effect_se = weighted_iv(ybar, xbar, shock, s)
first_stage, first_stage_se = weighted_iv(xbar, zbar, shock, s)
effective_shocks = float(1.0 / np.sum(s**2))

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": effect, "se": effect_se, "n_obs": N},
        {
            "term": "first_stage",
            "estimate": first_stage,
            "se": first_stage_se,
            "n_obs": N,
        },
        {
            "term": "effective_shocks",
            "estimate": effective_shocks,
            "se": None,
            "n_obs": N,
        },
    ],
    "method_metadata": {
        "estimator": "Weighted shift-share 2SLS via shock-level aggregation",
        "vcov": "Shock-level heteroskedasticity-robust HC1, N/(N-2)",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output:
    json.dump(result, output)
