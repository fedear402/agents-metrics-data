import json

import numpy as np
import pandas as pd
import statsmodels.api as sm

data = pd.read_csv("input.csv")
outcomes = [0, 1, 2]
if len(data) != 480 or not np.array_equal(np.sort(data["y"].unique()), outcomes):
    raise ValueError("Expected 480 observations with outcomes 0, 1, and 2.")

X = sm.add_constant(data[["x", "z"]], has_constant="add")
fit = sm.MNLogit(data["y"], X).fit(method="newton", disp=False, tol=1e-10)

coefficients = fit.params.copy()
errors = fit.bse.copy()
coefficients.columns = outcomes[1:]
errors.columns = outcomes[1:]

zero = pd.DataFrame({"const": [1.0], "x": [0.0], "z": [0.0]})
prob_cat2_zero = float(np.asarray(fit.predict(zero))[0, 2])
n_obs = len(data)

def row(term, variable, category):
    return {
        "term": term,
        "estimate": float(coefficients.loc[variable, category]),
        "se": float(errors.loc[variable, category]),
        "n_obs": n_obs,
    }

result = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": [
        row("x_cat1", "x", 1),
        row("z_cat1", "z", 1),
        row("x_cat2", "x", 2),
        row("z_cat2", "z", 2),
        {
            "term": "prob_cat2_zero",
            "estimate": prob_cat2_zero,
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "multinomial logit maximum likelihood",
        "vcov": "inverse observed information",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
