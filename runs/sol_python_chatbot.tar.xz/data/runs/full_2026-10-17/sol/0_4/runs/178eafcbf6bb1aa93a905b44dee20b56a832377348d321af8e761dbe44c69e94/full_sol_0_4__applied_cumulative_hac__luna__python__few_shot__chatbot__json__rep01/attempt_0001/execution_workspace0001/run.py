import json

import numpy as np
import pandas as pd

data = pd.read_csv("input.csv", parse_dates=["date"]).sort_values("date").reset_index(drop=True)
change = np.log(data["vix"]).diff()
lagged = {f"lag_{j}": change.shift(j) for j in range(1, 16)}
sample = pd.concat(
    [np.log(data["sales"]).rename("log_sales"), pd.DataFrame(lagged)],
    axis=1,
).dropna()

N = len(sample)
p = 16
if N <= p:
    raise ValueError("The regression requires more than 16 complete observations.")

X = np.column_stack(
    [np.ones(N), sample[[f"lag_{j}" for j in range(1, 16)]].to_numpy()]
)
y = sample["log_sales"].to_numpy()
coefficients = np.linalg.lstsq(X, y, rcond=None)[0]
residuals = y - X @ coefficients

scores = X * residuals[:, None]
meat = scores.T @ scores
for j in range(1, 16):
    weight = 1 - j / 16
    lag_product = scores[j:].T @ scores[:-j]
    meat += weight * (lag_product + lag_product.T)

bread = np.linalg.inv(X.T @ X)
covariance = (N / (N - p)) * bread @ meat @ bread

contrast = np.r_[0.0, np.ones(15)]
cumulative_variance = float(contrast @ covariance @ contrast)
cumulative_se = float(np.sqrt(max(cumulative_variance, 0.0)))

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {
            "term": "cumulative_response",
            "estimate": float(contrast @ coefficients),
            "se": cumulative_se,
            "n_obs": N,
        },
        {
            "term": "lag_1",
            "estimate": float(coefficients[1]),
            "se": float(np.sqrt(max(covariance[1, 1], 0.0))),
            "n_obs": N,
        },
        {
            "term": "lag_15",
            "estimate": float(coefficients[15]),
            "se": float(np.sqrt(max(covariance[15, 15], 0.0))),
            "n_obs": N,
        },
    ],
    "method_metadata": {
        "estimator": "OLS with intercept and 15 trading-observation lags of log VIX changes",
        "vcov": "Bartlett Newey-West, maximum lag 15, scaled by N/(N-16)",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
