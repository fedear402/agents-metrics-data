import json

import pandas as pd
from scipy.stats import f as f_distribution

data = pd.read_csv("./input.csv")
data["y"] = pd.to_numeric(data["y"], errors="coerce")
data = data.dropna(subset=["group", "y"])

groups = list(data.groupby("group")["y"])
n_obs = len(data)
df_num = len(groups) - 1
df_den = n_obs - len(groups)

if df_num <= 0 or df_den <= 0:
    raise ValueError("One-way ANOVA requires at least two groups and positive residual degrees of freedom.")

grand_mean = data["y"].mean()
ss_between = sum(
    len(values) * (values.mean() - grand_mean) ** 2
    for _, values in groups
)
ss_within = sum(
    ((values - values.mean()) ** 2).sum()
    for _, values in groups
)

if ss_within == 0:
    raise ValueError("The F statistic is undefined because within-group variation is zero.")

f_statistic = (ss_between / df_num) / (ss_within / df_den)
p_value = f_distribution.sf(f_statistic, df_num, df_den)

result = {
    "task_id": "anova_oneway",
    "platform": "python",
    "estimates": [
        {"term": "F", "estimate": float(f_statistic), "se": None, "n_obs": n_obs},
        {"term": "df_num", "estimate": float(df_num), "se": None, "n_obs": n_obs},
        {"term": "df_den", "estimate": float(df_den), "se": None, "n_obs": n_obs},
        {"term": "p_value", "estimate": float(p_value), "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "Classical one-way ANOVA",
        "vcov": "Pooled within-group variance",
    },
    "diagnostics": {},
}

with open("result.json", "w", encoding="utf-8") as output_file:
    json.dump(result, output_file, allow_nan=False)
