import json

import numpy as np
import pandas as pd
import statsmodels.api as sm


def main():
    data = pd.read_csv("input.csv")
    y = data["y"].astype(int)
    X = sm.add_constant(data[["x", "z"]], has_constant="add")

    model = sm.MNLogit(y, X)
    fit = model.fit(method="newton", disp=False)

    params = fit.params
    standard_errors = fit.bse
    categories = sorted(y.unique())
    n_obs = len(data)

    estimates = []
    for category in (1, 2):
        column = categories.index(category) - 1
        for variable in ("x", "z"):
            estimates.append(
                {
                    "term": f"{variable}_cat{category}",
                    "estimate": float(params.iloc[X.columns.get_loc(variable), column]),
                    "se": float(
                        standard_errors.iloc[X.columns.get_loc(variable), column]
                    ),
                    "n_obs": n_obs,
                }
            )

    X_zero = pd.DataFrame({"const": [1.0], "x": [0.0], "z": [0.0]})
    probability_cat2 = float(
        np.asarray(fit.predict(X_zero))[0, categories.index(2)]
    )
    estimates.append(
        {
            "term": "prob_cat2_zero",
            "estimate": probability_cat2,
            "se": None,
            "n_obs": n_obs,
        }
    )

    result = {
        "task_id": "broad_multinomial_logit",
        "platform": "python",
        "estimates": estimates,
        "method_metadata": {
            "estimator": "Multinomial logit maximum likelihood; outcome 0 base",
            "vcov": "Inverse observed information",
        },
        "diagnostics": {},
    }

    with open("result.json", "w", encoding="utf-8") as output:
        json.dump(result, output, allow_nan=False)


if __name__ == "__main__":
    main()
