library(MASS)
library(jsonlite)

d <- read.csv("input.csv")
n <- nrow(d)

d$y <- ordered(d$y, levels=1:3)

fit <- MASS::polr(y ~ x + z, data=d, method="logistic", Hess=TRUE,
                  control=list(reltol=1e-12, maxit=1000))

V <- vcov(fit)

# Coefficients and SEs
x_est <- unname(coef(fit)["x"])
z_est <- unname(coef(fit)["z"])
x_se <- sqrt(V["x","x"])
z_se <- sqrt(V["z","z"])

# Probability of category 3 at x=1, z=0
# P(Y=3) = 1 - logistic(zeta[2] - beta_x*1 - beta_z*0)
eta <- fit$zeta[2] - coef(fit)["x"]*1 - coef(fit)["z"]*0
prob_high <- 1 - plogis(eta)

cat("Coefficients:\n")
print(coef(fit))
cat("\nCutpoints:\n")
print(fit$zeta)
cat("\nProb(y=3 | x=1, z=0):", prob_high, "\n")
cat("N:", n, "\n")

results <- list(
  task_id = "broad_ordered_logit",
  platform = "r",
  estimates = list(
    list(term="x", estimate=x_est, se=x_se, n_obs=n),
    list(term="z", estimate=z_est, se=z_se, n_obs=n),
    list(term="prob_high", estimate=unname(prob_high), se=NULL, n_obs=n)
  ),
  method_metadata = list(estimator="ordered logit (polr)", vcov="observed information (native)"),
  diagnostics = setNames(list(), character(0))
)

write_json(results, "result.json", auto_unbox=TRUE, null="null", digits=16, pretty=TRUE)
cat("\nresult.json written.\n")
