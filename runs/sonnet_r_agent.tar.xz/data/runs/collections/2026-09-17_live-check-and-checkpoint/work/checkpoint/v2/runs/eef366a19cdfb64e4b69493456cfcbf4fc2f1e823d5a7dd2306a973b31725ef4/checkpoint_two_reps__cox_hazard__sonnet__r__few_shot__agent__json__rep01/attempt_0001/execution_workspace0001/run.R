library(jsonlite)
library(survival)

df <- read.csv("./input.csv")

fit <- coxph(Surv(t_obs, event) ~ treat + x, data = df)

s <- summary(fit)
coefs <- s$coefficients

loghr_treat <- unname(coefs["treat", "coef"])
se_treat    <- unname(coefs["treat", "se(coef)"])
loghr_x     <- unname(coefs["x",     "coef"])
se_x        <- unname(coefs["x",     "se(coef)"])
n_obs       <- fit$n

out <- list(
  task_id  = "cox_hazard",
  platform = "r",
  estimates = list(
    list(term = "treat", estimate = loghr_treat, se = se_treat, n_obs = n_obs),
    list(term = "x",     estimate = loghr_x,     se = se_x,     n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "Cox proportional hazards",
    vcov      = "model-based (Fisher information)"
  ),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "./result.json", auto_unbox = TRUE, digits = 10)
