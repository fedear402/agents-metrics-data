library(survival)
library(jsonlite)

dat <- read.csv("input.csv")

fit <- coxph(Surv(t_obs, event) ~ treat + x, data = dat, ties = "efron")

s <- summary(fit)
coefs <- s$coefficients

n_obs <- fit$n

result <- list(
  task_id = "cox_hazard",
  platform = "r",
  estimates = list(
    list(term = "treat", estimate = coefs["treat", "coef"], se = coefs["treat", "se(coef)"], n_obs = n_obs),
    list(term = "x",     estimate = coefs["x",     "coef"], se = coefs["x",     "se(coef)"], n_obs = n_obs)
  ),
  method_metadata = list(estimator = "Cox PH (coxph, Efron ties)", vcov = "model-based (Fisher information)"),
  diagnostics = list()
)

write(toJSON(result, auto_unbox = TRUE, digits = 10), "result.json")
cat("Done\n")
print(coefs)
