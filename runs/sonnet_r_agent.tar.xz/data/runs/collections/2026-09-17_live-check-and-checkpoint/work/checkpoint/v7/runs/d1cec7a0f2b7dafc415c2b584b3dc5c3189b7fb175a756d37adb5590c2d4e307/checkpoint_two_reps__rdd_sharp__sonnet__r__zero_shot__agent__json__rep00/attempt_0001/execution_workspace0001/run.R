library(jsonlite)

dat <- read.csv("input.csv")

# Bandwidth and cutoff
h <- 0.5
cutoff <- 0

# Subset to bandwidth window
in_bw <- abs(dat$z - cutoff) <= h
dat_bw <- dat[in_bw, ]

# Running variable centered at cutoff
dat_bw$z_c <- dat_bw$z - cutoff

# Triangular kernel weights
dat_bw$w <- (1 - abs(dat_bw$z_c) / h)

# Indicator for right side
dat_bw$right <- as.integer(dat_bw$z_c >= 0)

# Local linear regression on each side
# Left side: z_c < 0
left <- dat_bw[dat_bw$right == 0, ]
fit_left <- lm(y ~ z_c, data = left, weights = w)
intercept_left <- coef(fit_left)[1]

# Right side: z_c >= 0
right <- dat_bw[dat_bw$right == 1, ]
fit_right <- lm(y ~ z_c, data = right, weights = w)
intercept_right <- coef(fit_right)[1]

# LATE = difference in intercepts (right - left)
late <- as.numeric(intercept_right - intercept_left)

# SE via pooled regression with interaction
# y = a + b*z_c + c*right + d*(right*z_c) + e
# c is the jump (LATE), se(c) is what we want
fit_pooled <- lm(y ~ z_c * right, data = dat_bw, weights = w)
se_late <- sqrt(vcov(fit_pooled)["right", "right"])

n_obs <- nrow(dat_bw)

cat("Intercept left:", intercept_left, "\n")
cat("Intercept right:", intercept_right, "\n")
cat("LATE:", late, "\n")
cat("SE:", se_late, "\n")
cat("N obs in bandwidth:", n_obs, "\n")

# Verify LATE from pooled regression matches
late_pooled <- coef(fit_pooled)["right"]
cat("LATE from pooled:", as.numeric(late_pooled), "\n")

result <- list(
  task_id = "rdd_sharp",
  platform = "r",
  estimates = list(
    list(
      term = "late",
      estimate = round(late, 10),
      se = round(se_late, 10),
      n_obs = as.integer(n_obs)
    )
  ),
  method_metadata = list(
    estimator = "local_linear_regression",
    vcov = "OLS_homoskedastic"
  ),
  diagnostics = list()
)

write(toJSON(result, auto_unbox = TRUE, digits = 10), "result.json")
cat("result.json written\n")
