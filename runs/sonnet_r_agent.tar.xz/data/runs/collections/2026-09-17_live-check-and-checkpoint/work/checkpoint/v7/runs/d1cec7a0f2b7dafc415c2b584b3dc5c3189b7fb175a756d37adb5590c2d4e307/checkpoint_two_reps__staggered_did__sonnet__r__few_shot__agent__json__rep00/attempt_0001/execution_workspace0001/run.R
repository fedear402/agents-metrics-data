library(jsonlite)

df <- read.csv("./input.csv")

cohorts <- c(4, 6, 8)
never <- df[df$cohort == -1, ]

att_cells <- c()
n_obs_total <- 0

for (g in cohorts) {
  g_data <- df[df$cohort == g, ]
  # Pre-treatment base period is year g-1
  base_year <- g - 1
  
  # Post-treatment years: t >= g
  post_years <- (g):9
  
  mean_g_base <- mean(g_data$y_did[g_data$year == base_year])
  mean_nt_base <- mean(never$y_did[never$year == base_year])
  
  for (t in post_years) {
    mean_g_t <- mean(g_data$y_did[g_data$year == t])
    mean_nt_t <- mean(never$y_did[never$year == t])
    
    att_gt <- (mean_g_t - mean_g_base) - (mean_nt_t - mean_nt_base)
    att_cells <- c(att_cells, att_gt)
  }
  
  # Count treated obs: firms in cohort g across post years
  n_obs_total <- n_obs_total + nrow(g_data[g_data$year >= g, ])
}

att_uniform <- mean(att_cells)
n_cells <- length(att_cells)

cat("Number of (g,t) cells:", n_cells, "\n")
cat("ATT_uniform:", att_uniform, "\n")
cat("Cell values:\n"); print(att_cells)

out <- list(
  task_id = "staggered_did",
  platform = "r",
  estimates = list(
    list(term = "att", estimate = att_uniform, se = NA, n_obs = as.integer(n_obs_total))
  ),
  method_metadata = list(
    estimator = "ATT_uniform: equal-weight average of ATT(g,t) from group-year means",
    vcov = "none"
  ),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "./result.json", auto_unbox = TRUE)
cat("Done. result.json written.\n")
