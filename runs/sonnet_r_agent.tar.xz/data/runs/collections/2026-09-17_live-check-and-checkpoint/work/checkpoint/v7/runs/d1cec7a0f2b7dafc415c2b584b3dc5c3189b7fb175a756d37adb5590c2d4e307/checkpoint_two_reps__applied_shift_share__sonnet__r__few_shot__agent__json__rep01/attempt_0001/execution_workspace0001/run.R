library(jsonlite)

d <- read.csv("input.csv")

# Step 1: normalize regional weights
reg <- unique(d[, c("region_id", "region_weight", "x", "y")])
reg <- reg[order(reg$region_id), ]
reg$e <- reg$region_weight / sum(reg$region_weight)

# Step 2: shift-share instrument
d$share_shock <- d$share * d$shock
z_df <- aggregate(share_shock ~ region_id, data=d, FUN=sum)
names(z_df)[2] <- "z"
reg <- merge(reg, z_df, by="region_id")

# Step 3: demean
reg$y0 <- reg$y - sum(reg$e * reg$y)
reg$x0 <- reg$x - sum(reg$e * reg$x)
reg$z0 <- reg$z - sum(reg$e * reg$z)

# Step 4: shock-level aggregation
d3 <- merge(d[, c("region_id","industry_id","share","shock")],
            reg[, c("region_id","e","y0","x0","z0")], by="region_id")
d3$esn <- d3$e * d3$share

sn_df <- aggregate(esn ~ industry_id, data=d3, FUN=sum)
names(sn_df)[2] <- "s_n"
d3 <- merge(d3, sn_df, by="industry_id")

agg_y <- aggregate(I(e * share * y0) ~ industry_id, data=d3, FUN=sum)
agg_x <- aggregate(I(e * share * x0) ~ industry_id, data=d3, FUN=sum)
agg_z <- aggregate(I(e * share * z0) ~ industry_id, data=d3, FUN=sum)
names(agg_y)[2] <- "sum_ey0"
names(agg_x)[2] <- "sum_ex0"
names(agg_z)[2] <- "sum_ez0"

ind_shock <- unique(d[, c("industry_id", "shock")])
agg <- Reduce(function(a,b) merge(a,b,by="industry_id"),
              list(sn_df, ind_shock, agg_y, agg_x, agg_z))
agg$ybar <- agg$sum_ey0 / agg$s_n
agg$xbar <- agg$sum_ex0 / agg$s_n
agg$zbar <- agg$sum_ez0 / agg$s_n
N <- nrow(agg)

# Step 5: shock-level weighted IV
shock_iv <- function(dep, endog, instr, wt) {
  Z  <- cbind(1, instr)
  X  <- cbind(1, endog)
  dep <- as.numeric(dep)
  ZtWX <- t(Z) %*% (wt * X)
  ZtWy <- t(Z) %*% (wt * dep)
  beta <- solve(ZtWX, ZtWy)
  resid <- dep - drop(X %*% beta)
  scores <- Z * (wt * resid)        # N x 2 matrix
  meat <- t(scores) %*% scores
  inv  <- solve(ZtWX)
  cov_mat <- N / (N - 2) * inv %*% meat %*% t(inv)
  list(slope = beta[2,1], se = sqrt(cov_mat[2, 2]))
}

effect      <- shock_iv(agg$ybar, agg$xbar, agg$shock, agg$s_n)
first_stage <- shock_iv(agg$xbar, agg$zbar, agg$shock, agg$s_n)
eff_shocks  <- 1 / sum(agg$s_n^2)

# Verification: regional counterparts
reg_2sls <- sum(reg$e * reg$z0 * reg$y0) / sum(reg$e * reg$z0 * reg$x0)
reg_fs   <- sum(reg$e * reg$z0 * reg$x0) / sum(reg$e * reg$z0 * reg$z0)

cat("Effect   - shock-level:", effect$slope,      "| regional:", reg_2sls, "| match:", abs(effect$slope - reg_2sls) < 1e-8, "\n")
cat("FS       - shock-level:", first_stage$slope, "| regional:", reg_fs,   "| match:", abs(first_stage$slope - reg_fs) < 1e-8, "\n")
cat("Effective shocks:", eff_shocks, "\n")
cat("N industries:", N, "\n")

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term="effect",           estimate=unname(effect$slope),      se=unname(effect$se),      n_obs=N),
    list(term="first_stage",      estimate=unname(first_stage$slope), se=unname(first_stage$se), n_obs=N),
    list(term="effective_shocks", estimate=eff_shocks,                se=NULL,                   n_obs=N)
  ),
  method_metadata = list(
    estimator = "shift-share 2SLS (BHJ shock-level aggregation)",
    vcov      = "HC1 shock-level robust"
  ),
  diagnostics = list()
)
write_json(result, "result.json", auto_unbox=TRUE, null="null", digits=16, pretty=TRUE)
cat("result.json written.\n")
