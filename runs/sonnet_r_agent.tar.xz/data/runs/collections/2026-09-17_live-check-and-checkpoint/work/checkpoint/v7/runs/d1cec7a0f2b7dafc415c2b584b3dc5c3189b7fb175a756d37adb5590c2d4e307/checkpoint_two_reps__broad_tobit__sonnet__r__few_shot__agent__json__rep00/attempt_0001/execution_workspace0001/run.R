library(survival)
library(jsonlite)

d <- read.csv("input.csv")
n <- nrow(d)

# Left-censored at 0: y=0 means censored, y>0 is observed
fit <- survreg(Surv(y, y > 0, type = "left") ~ x + z,
               data = d, dist = "gaussian",
               control = survreg.control(rel.tolerance = 1e-12))

V <- vcov(fit)
coefs <- coef(fit)

se_intercept <- sqrt(V["(Intercept)", "(Intercept)"])
se_x <- sqrt(V["x", "x"])
se_z <- sqrt(V["z", "z"])

estimates <- list(
  list(term = "const",  estimate = unname(coefs["(Intercept)"]), se = se_intercept, n_obs = n),
  list(term = "x",      estimate = unname(coefs["x"]),           se = se_x,         n_obs = n),
  list(term = "z",      estimate = unname(coefs["z"]),           se = se_z,         n_obs = n),
  list(term = "sigma",  estimate = unname(fit$scale),            se = NULL,         n_obs = n)
)

result <- list(
  task_id = "broad_tobit",
  platform = "r",
  estimates = estimates,
  method_metadata = list(estimator = "MLE Tobit (survreg, gaussian, left-censored at 0)",
                         vcov = "observed information (survreg vcov)"),
  diagnostics = setNames(list(), character(0))
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
cat("Done. Coefficients:\n")
print(coef(fit))
cat("Scale:", fit$scale, "\n")
cat("n =", n, "\n")
