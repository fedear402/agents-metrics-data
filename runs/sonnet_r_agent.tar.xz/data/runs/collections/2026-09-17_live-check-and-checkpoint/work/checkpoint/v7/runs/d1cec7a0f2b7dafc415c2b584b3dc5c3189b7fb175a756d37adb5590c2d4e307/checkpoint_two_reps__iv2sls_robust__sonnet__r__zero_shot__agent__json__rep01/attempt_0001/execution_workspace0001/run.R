library(AER)
library(sandwich)
library(lmtest)
library(jsonlite)

dat <- read.csv("input.csv")

# 2SLS: y_iv ~ x1_iv | z (with intercept)
iv_model <- ivreg(y_iv ~ x1_iv | z, data = dat)

# HC1 robust standard errors
vcov_hc1 <- vcovHC(iv_model, type = "HC1")
ct <- coeftest(iv_model, vcov = vcov_hc1)

n_obs <- nobs(iv_model)

# Extract estimates
coef_names <- rownames(ct)
const_idx <- which(coef_names == "(Intercept)")
x1iv_idx  <- which(coef_names == "x1_iv")

result <- list(
  task_id  = "iv2sls_robust",
  platform = "r",
  estimates = list(
    list(term = "const",  estimate = ct[const_idx, 1], se = ct[const_idx, 2], n_obs = n_obs),
    list(term = "x1_iv",  estimate = ct[x1iv_idx,  1], se = ct[x1iv_idx,  2], n_obs = n_obs)
  ),
  method_metadata = list(estimator = "AER::ivreg 2SLS", vcov = "HC1"),
  diagnostics = list()
)

write(toJSON(result, auto_unbox = TRUE, digits = 10), "result.json")
cat("Done. n_obs =", n_obs, "\n")
print(ct)
