library(AER)
library(sandwich)
library(lmtest)
library(jsonlite)

d <- read.csv("input.csv")

# --- Step 1: Regional data (one obs per region) ---
reg <- unique(d[, c("region_id","region_weight","x","y")])
reg <- reg[order(reg$region_id), ]

# Normalize weights
reg$e_r <- reg$region_weight / sum(reg$region_weight)

# --- Step 2: Construct shift-share instrument ---
# z_r = sum_n share_rn * shock_n
shock_lookup <- unique(d[, c("industry_id","shock")])
z_list <- tapply(1:nrow(d), d$region_id, function(idx) {
  sum(d$share[idx] * d$shock[idx])
})
reg$z_r <- z_list[as.character(reg$region_id)]

# --- Step 3: Weighted 2SLS at regional level ---
iv_reg <- ivreg(y ~ x | z_r, data=reg, weights=reg$e_r)
beta_2sls <- coef(iv_reg)["x"]
cat("Regional 2SLS slope:", beta_2sls, "\n")

# --- Step 4: Shock-level aggregation (BHJ exposure-robust SE) ---

# Weighted means
wmean <- function(v, w) sum(v * w) / sum(w)

y_mean <- wmean(reg$y, reg$e_r)
x_mean <- wmean(reg$x, reg$e_r)
z_mean <- wmean(reg$z_r, reg$e_r)

reg$y0 <- reg$y - y_mean
reg$x0 <- reg$x - x_mean
reg$z0 <- reg$z_r - z_mean

# For each industry n: s_n = sum_r e_r * share_rn
# Merge e_r into d
d2 <- merge(d, reg[, c("region_id","e_r","y0","x0","z0")], by="region_id")

# Aggregate by industry
industries <- unique(d2$industry_id)
N <- length(industries)
cat("Number of industries:", N, "\n")

agg <- data.frame(
  industry_id = industries,
  shock = NA_real_,
  s_n = NA_real_,
  ybar = NA_real_,
  xbar = NA_real_,
  zbar = NA_real_
)

for (i in seq_along(industries)) {
  n <- industries[i]
  idx <- d2$industry_id == n
  s_n <- sum(d2$e_r[idx] * d2$share[idx])
  agg$s_n[i] <- s_n
  agg$shock[i] <- d2$shock[idx][1]
  agg$ybar[i] <- sum(d2$e_r[idx] * d2$share[idx] * d2$y0[idx]) / s_n
  agg$xbar[i] <- sum(d2$e_r[idx] * d2$share[idx] * d2$x0[idx]) / s_n
  agg$zbar[i] <- sum(d2$e_r[idx] * d2$share[idx] * d2$z0[idx]) / s_n
}

# --- Shock-level IV for effect: ybar ~ xbar | shock, weights=s_n ---
iv_shock <- ivreg(ybar ~ xbar | shock, data=agg, weights=agg$s_n)
beta_shock <- coef(iv_shock)["xbar"]
cat("Shock-level 2SLS slope:", beta_shock, "\n")

# HC1 SE with structural IV residuals
# IV residuals: uhat = ybar - beta0 - beta_shock * xbar
iv_resid <- resid(iv_shock)

# HC1 variance: N/(N-2) * sum(w_n^2 * u_n^2 * x_n^2) / (sum(w_n * x_n * z_n))^2
# where x_n here is xbar_n (endogenous), z_n is shock_n (instrument)
# More precisely, use sandwich formula for IV
# For weighted IV: V = (X'PZ X)^{-1} * HC * (X'PZ X)^{-1}
# Use vcovHC from sandwich

vcov_shock <- vcovHC(iv_shock, type="HC1")
se_effect <- sqrt(vcov_shock["xbar","xbar"])
cat("Effect SE (HC1):", se_effect, "\n")

# --- First stage: x_r on z_r, weights=e_r ---
fs_reg <- lm(x ~ z_r, data=reg, weights=reg$e_r)
beta_fs <- coef(fs_reg)["z_r"]
cat("Regional first-stage slope:", beta_fs, "\n")

# Shock-level first-stage IV: xbar ~ zbar | shock, weights=s_n
# zbar is endogenous, shock is instrument
iv_fs_shock <- ivreg(xbar ~ zbar | shock, data=agg, weights=agg$s_n)
beta_fs_shock <- coef(iv_fs_shock)["zbar"]
cat("Shock-level first-stage slope:", beta_fs_shock, "\n")

vcov_fs_shock <- vcovHC(iv_fs_shock, type="HC1")
se_fs <- sqrt(vcov_fs_shock["zbar","zbar"])
cat("First-stage SE (HC1):", se_fs, "\n")

# --- Effective shocks ---
eff_shocks <- 1 / sum(agg$s_n^2)
cat("Effective shocks:", eff_shocks, "\n")

# --- Output ---
result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term="effect", estimate=as.numeric(beta_shock), se=as.numeric(se_effect), n_obs=as.integer(N)),
    list(term="first_stage", estimate=as.numeric(beta_fs_shock), se=as.numeric(se_fs), n_obs=as.integer(N)),
    list(term="effective_shocks", estimate=as.numeric(eff_shocks), se=NULL, n_obs=as.integer(N))
  ),
  method_metadata = list(
    estimator = "2SLS shift-share IV with BHJ exposure-robust SE",
    vcov = "HC1 shock-level"
  ),
  diagnostics = list()
)

write(toJSON(result, auto_unbox=TRUE, null="null", digits=10), "result.json")
cat("Done. result.json written.\n")
