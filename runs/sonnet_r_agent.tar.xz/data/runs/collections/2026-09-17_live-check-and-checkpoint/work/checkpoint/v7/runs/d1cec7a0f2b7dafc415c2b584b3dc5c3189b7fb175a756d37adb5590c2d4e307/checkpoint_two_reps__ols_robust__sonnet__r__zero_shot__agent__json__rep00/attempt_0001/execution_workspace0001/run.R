library(sandwich)
library(lmtest)
library(jsonlite)

dat <- read.csv("input.csv")
n <- nrow(dat)

mod <- lm(y_lin ~ x1 + x2, data = dat)
vcov_hc1 <- vcovHC(mod, type = "HC1")
ct <- coeftest(mod, vcov = vcov_hc1)

# Extract estimates and SEs
terms <- c("(Intercept)", "x1", "x2")
labels <- c("const", "x1", "x2")

estimates <- lapply(seq_along(terms), function(i) {
  list(
    term = labels[i],
    estimate = unname(ct[terms[i], "Estimate"]),
    se = unname(ct[terms[i], "Std. Error"]),
    n_obs = n
  )
})

result <- list(
  task_id = "ols_robust",
  platform = "r",
  estimates = estimates,
  method_metadata = list(estimator = "OLS", vcov = "HC1"),
  diagnostics = setNames(list(), character(0))
)

write(toJSON(result, auto_unbox = TRUE, digits = 10), "result.json")
cat("Done. Estimates:\n")
print(ct)
