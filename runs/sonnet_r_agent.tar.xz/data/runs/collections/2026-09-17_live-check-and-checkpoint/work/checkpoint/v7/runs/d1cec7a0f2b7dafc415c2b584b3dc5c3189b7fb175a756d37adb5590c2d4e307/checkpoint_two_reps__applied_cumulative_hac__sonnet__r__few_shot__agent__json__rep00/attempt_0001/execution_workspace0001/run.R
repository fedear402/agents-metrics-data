library(jsonlite)

data <- read.csv("/private/tmp/prospective_task_xbwh0cts/input.csv", stringsAsFactors=FALSE)
data$date <- as.Date(data$date)
data <- data[order(data$date),]

data$log_sales <- log(data$sales)
data$log_vix <- log(data$vix)
data$vix_change <- c(NA, diff(data$log_vix))

# Create 15 lags of vix_change
for (k in 1:15) {
  data[[paste0("lag_", k)]] <- c(rep(NA, k), head(data$vix_change, -k))
}

lag_cols <- paste0("lag_", 1:15)
complete_cols <- c("log_sales", lag_cols)
sample <- data[complete.cases(data[, complete_cols]), ]

N <- nrow(sample)
cat("N =", N, "\n")

formula_str <- paste("log_sales ~", paste(lag_cols, collapse=" + "))
fit <- lm(as.formula(formula_str), data=sample)

X <- model.matrix(fit)
coefs <- coef(fit)
resids <- residuals(fit)
scores <- X * resids

hac_lags <- 15
p <- ncol(X)  # 16 parameters (intercept + 15 lags)

meat <- crossprod(scores)
for (j in seq_len(hac_lags)) {
  lag_prod <- crossprod(scores[(j+1):N,,drop=FALSE], scores[1:(N-j),,drop=FALSE])
  w <- 1 - j/(hac_lags + 1)
  meat <- meat + w * (lag_prod + t(lag_prod))
}

bread <- solve(crossprod(X))
covariance <- (N/(N-16)) * bread %*% meat %*% bread

# Contrast: sum of lag_1 through lag_15 (exclude intercept)
contrast <- c(0, rep(1, 15))
cumulative <- sum(contrast * coefs)
cumulative_se <- sqrt(drop(t(contrast) %*% covariance %*% contrast))

lag1_idx <- 2
lag15_idx <- 16
lag1_est <- coefs[lag1_idx]
lag1_se <- sqrt(covariance[lag1_idx, lag1_idx])
lag15_est <- coefs[lag15_idx]
lag15_se <- sqrt(covariance[lag15_idx, lag15_idx])

cat("cumulative_response:", cumulative, "se:", cumulative_se, "\n")
cat("lag_1:", lag1_est, "se:", lag1_se, "\n")
cat("lag_15:", lag15_est, "se:", lag15_se, "\n")

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(term="cumulative_response", estimate=unname(as.numeric(cumulative)), se=unname(as.numeric(cumulative_se)), n_obs=as.integer(N)),
    list(term="lag_1", estimate=unname(as.numeric(lag1_est)), se=unname(as.numeric(lag1_se)), n_obs=as.integer(N)),
    list(term="lag_15", estimate=unname(as.numeric(lag15_est)), se=unname(as.numeric(lag15_se)), n_obs=as.integer(N))
  ),
  method_metadata = list(estimator="OLS", vcov="Newey-West HAC, Bartlett kernel, max lag 15, correction N/(N-16)"),
  diagnostics = list()
)

write_json(result, "/private/tmp/prospective_task_xbwh0cts/result.json",
           auto_unbox=TRUE, null="null", digits=16, pretty=TRUE)
cat("Done. Written result.json\n")
