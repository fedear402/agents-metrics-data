library(sandwich)
library(lmtest)
library(jsonlite)

dat <- read.csv("input.csv")
dat <- dat[order(dat$t), ]
n <- nrow(dat)

# Construct variables for LP at horizon h=4
# y_{t+4} is the dependent variable
# shock_t and y_{t-1} are regressors
# Valid rows: need t+4 <= max(t) and t-1 >= min(t)
# i.e., rows where we can get both y[t+4] and y[t-1]

y_lead4 <- c(dat$y[5:n], rep(NA, 4))   # y_{t+4}
y_lag1  <- c(NA, dat$y[1:(n-1)])        # y_{t-1}
shock   <- dat$shock

df <- data.frame(y_lead4 = y_lead4, shock = shock, y_lag1 = y_lag1)
df <- df[complete.cases(df), ]

# Estimate OLS
fit <- lm(y_lead4 ~ shock + y_lag1, data = df)

# Newey-West SE with lag 4
nw_vcov <- NeweyWest(fit, lag = 4, prewhite = FALSE, adjust = FALSE)
ct <- coeftest(fit, vcov = nw_vcov)

# Extract shock coefficient (irf_h4)
est <- ct["shock", "Estimate"]
se  <- ct["shock", "Std. Error"]
n_obs <- nrow(df)

cat("Estimate:", est, "\n")
cat("SE:", se, "\n")
cat("N obs:", n_obs, "\n")
cat("Coefficients:\n")
print(ct)

result <- list(
  task_id = "lp_irf",
  platform = "r",
  estimates = list(
    list(term = "irf_h4", estimate = est, se = se, n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "OLS local projection h=4",
    vcov = "Newey-West lag=4"
  ),
  diagnostics = list()
)

write(toJSON(result, auto_unbox = TRUE, digits = 10), "result.json")
cat("Done. result.json written.\n")
