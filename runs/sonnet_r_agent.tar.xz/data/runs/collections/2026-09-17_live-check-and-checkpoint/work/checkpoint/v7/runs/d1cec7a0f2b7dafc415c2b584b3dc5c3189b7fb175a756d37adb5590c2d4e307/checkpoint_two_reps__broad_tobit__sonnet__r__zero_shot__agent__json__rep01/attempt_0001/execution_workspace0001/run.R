library(AER)
library(jsonlite)

d <- read.csv("input.csv")

# Fit Tobit model: left-censored at 0
fit <- tobit(y ~ x + z, data = d, left = 0, right = Inf)

s <- summary(fit)
coef_table <- s$coefficients

const_est <- coef_table["(Intercept)", "Estimate"]
const_se  <- coef_table["(Intercept)", "Std. Error"]
x_est     <- coef_table["x", "Estimate"]
x_se      <- coef_table["x", "Std. Error"]
z_est     <- coef_table["z", "Estimate"]
z_se      <- coef_table["z", "Std. Error"]

# sigma from the model (log(sigma) is estimated; get sigma)
# AER::tobit stores scale as "Log(scale)" in coef
# The loglik-based sigma
sigma_est <- fit$scale
n_obs <- nrow(d)

cat("Coefficients:\n")
print(coef_table)
cat("sigma:", sigma_est, "\n")
cat("n_obs:", n_obs, "\n")

result <- list(
  task_id = "broad_tobit",
  platform = "r",
  estimates = list(
    list(term = "const",  estimate = const_est, se = const_se,  n_obs = n_obs),
    list(term = "x",      estimate = x_est,     se = x_se,      n_obs = n_obs),
    list(term = "z",      estimate = z_est,     se = z_se,      n_obs = n_obs),
    list(term = "sigma",  estimate = sigma_est, se = NULL,       n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "Tobit MLE (homoskedastic Gaussian, left-censored at 0)",
    vcov = "observed information (default AER::tobit)"
  ),
  diagnostics = setNames(list(), character(0))
)

write(toJSON(result, auto_unbox = TRUE, digits = 10, null = "null"), "result.json")
cat("Done.\n")
