data <- read.csv("/private/tmp/prospective_task_2s92cuqs/input.csv")
data <- data[order(data$time),]

f <- 101
levels <- data$y[(f-100):(f-1)]
X <- cbind(1, head(levels,-1))
y_vec <- tail(levels,-1)
beta <- solve(t(X) %*% X) %*% t(X) %*% y_vec
fc_manual <- beta[1] + beta[2] * tail(levels,1)
cat("Manual forecast_101:", fc_manual, "\n")

fit <- lm(tail(levels,-1) ~ head(levels,-1))
fc_lm <- coef(fit)[1] + coef(fit)[2] * tail(levels,1)
cat("lm forecast_101:", fc_lm, "\n")
cat("n forecast times:", length(101:250), "\n")
