library(jsonlite)

df <- read.csv("./input.csv")

cohorts <- c(4, 6, 8)
never <- df[df$cohort == -1, ]

att_cells <- c()
n_total <- 0

for (g in cohorts) {
  g_firms <- df[df$cohort == g, ]
  # pre-treatment baseline year: g-1
  base_year <- g - 1
  
  # post-treatment years: t >= g, up to max year
  post_years <- unique(df$year[df$year >= g])
  
  # means for never-treated at baseline
  nt_base <- mean(never$y_did[never$year == base_year])
  
  # mean for cohort g at baseline
  g_base <- mean(g_firms$y_did[g_firms$year == base_year])
  
  for (t in post_years) {
    # mean for cohort g at year t
    g_t <- mean(g_firms$y_did[g_firms$year == t])
    
    # mean for never-treated at year t
    nt_t <- mean(never$y_did[never$year == t])
    
    # ATT(g,t) = [g_t - g_base] - [nt_t - nt_base]
    att_gt <- (g_t - g_base) - (nt_t - nt_base)
    att_cells <- c(att_cells, att_gt)
    n_total <- n_total + nrow(g_firms[g_firms$year == t, ])
  }
}

att_uniform <- mean(att_cells)

# n_obs: total observations in post-treatment cohort-time cells
# Count unique firms in treated cohorts * post-treatment years
n_obs <- 0
for (g in cohorts) {
  g_firms <- df[df$cohort == g, ]
  post_years <- unique(df$year[df$year >= g])
  n_obs <- n_obs + nrow(g_firms[g_firms$year %in% post_years, ])
}

out <- list(
  task_id = "staggered_did",
  platform = "r",
  estimates = list(
    list(term = "att", estimate = att_uniform, se = NA, n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "ATT_uniform: equal-weight average over cohort-time cells, group-year means",
    vcov = "none"
  ),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "result.json", auto_unbox = TRUE)
cat("ATT_uniform:", att_uniform, "\n")
cat("Number of cells:", length(att_cells), "\n")
cat("n_obs:", n_obs, "\n")
