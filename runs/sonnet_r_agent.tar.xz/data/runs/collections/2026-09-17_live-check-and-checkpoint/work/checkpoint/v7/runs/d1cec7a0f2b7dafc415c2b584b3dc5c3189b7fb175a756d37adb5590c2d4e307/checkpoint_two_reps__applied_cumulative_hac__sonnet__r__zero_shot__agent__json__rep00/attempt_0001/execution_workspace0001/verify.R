library(sandwich)

df <- read.csv("input.csv")
df$date <- as.Date(df$date)
df <- df[order(df$date), ]
df$log_sales <- log(df$sales)
df$log_vix <- log(df$vix)
n <- nrow(df)
df$d_log_vix <- c(NA, diff(df$log_vix))

for (k in 1:15) {
  df[[paste0("lag_", k)]] <- c(rep(NA, k), df$d_log_vix[1:(n - k)])
}

lag_cols <- paste0("lag_", 1:15)
df_reg <- df[complete.cases(df[, c("log_sales", lag_cols)]), ]
N <- nrow(df_reg)

# Verify N: first 15 obs have NAs from d_log_vix (1 NA) + lags up to 15 more
# lag_15 needs obs 16 (index 16 in original sorted) as first valid
cat("Expected N:", n - 16, "Got:", N, "\n")  # Should be 720-16=704

# Manual Newey-West check
# Compute sandwich using manual formula
X <- model.matrix(~ lag_1 + lag_2 + lag_3 + lag_4 + lag_5 + lag_6 + lag_7 +
                    lag_8 + lag_9 + lag_10 + lag_11 + lag_12 + lag_13 + lag_14 + lag_15,
                  data = df_reg)
y <- df_reg$log_sales
beta <- solve(t(X) %*% X) %*% t(X) %*% y
e <- y - X %*% beta

# Bread
bread <- solve(t(X) %*% X)

# Meat: Newey-West with Bartlett weights 1 - j/16 for j=1..15, plus j=0 term
L <- 15
Gamma0 <- t(X * as.vector(e)) %*% (X * as.vector(e))  # N x 1 outer products summed
meat <- Gamma0
for (j in 1:L) {
  w <- 1 - j/16
  Xj_early <- X[1:(N-j), ] * as.vector(e[1:(N-j)])
  Xj_late  <- X[(j+1):N, ] * as.vector(e[(j+1):N])
  Gammaj <- t(Xj_early) %*% Xj_late
  meat <- meat + w * (Gammaj + t(Gammaj))
}

vcov_manual <- (N / (N - 16)) * bread %*% meat %*% bread

# Compare with sandwich result
model <- lm(log_sales ~ lag_1+lag_2+lag_3+lag_4+lag_5+lag_6+lag_7+lag_8+lag_9+lag_10+lag_11+lag_12+lag_13+lag_14+lag_15, data=df_reg)
nw_vcov_raw <- NeweyWest(model, lag=15, prewhite=FALSE, adjust=FALSE)
nw_scaled <- nw_vcov_raw * (N/(N-16))

cat("SE lag_1 manual:", sqrt(vcov_manual["lag_1","lag_1"]), "\n")
cat("SE lag_1 sandwich:", sqrt(nw_scaled["lag_1","lag_1"]), "\n")
cat("Max abs diff in vcov:", max(abs(vcov_manual - nw_scaled)), "\n")

# Cumulative response from manual
lag_names <- paste0("lag_", 1:15)
cum_manual <- sum(beta[lag_names,])
V_lags_manual <- vcov_manual[lag_names, lag_names]
ones <- rep(1, 15)
se_cum_manual <- sqrt(as.numeric(t(ones) %*% V_lags_manual %*% ones))
cat("Cum response manual:", cum_manual, "SE:", se_cum_manual, "\n")
