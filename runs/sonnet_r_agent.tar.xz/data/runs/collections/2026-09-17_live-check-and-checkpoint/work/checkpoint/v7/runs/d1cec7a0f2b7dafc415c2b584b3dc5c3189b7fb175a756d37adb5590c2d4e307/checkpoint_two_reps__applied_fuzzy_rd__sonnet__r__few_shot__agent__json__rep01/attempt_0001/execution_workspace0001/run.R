library(jsonlite)

# Load data
dat <- read.csv("input.csv")

# Apply bandwidth filter: abs(score) < 1
bw_dat <- dat[abs(dat$score) < 1, ]
n_obs <- nrow(bw_dat)

# Triangular weights
bw_dat$w <- 1 - abs(bw_dat$score)

# Indicator for above cutoff
bw_dat$above <- as.integer(bw_dat$score >= 0)

# Design matrix: separate slopes on each side
# Variables: intercept, score_left (score*(1-above)), score_right (score*above), above
# i.e., X = [1, score*(1-above), above, score*above]
# The "above" coefficient is the discontinuity at cutoff

score <- bw_dat$score
above <- bw_dat$above
w <- bw_dat$w

X <- cbind(
  intercept = 1,
  score_left = score * (1 - above),
  above = above,
  score_right = score * above
)

Y <- cbind(earnings = bw_dat$earnings, participated = bw_dat$participated)

# Weighted least squares
W <- w
bread <- solve(crossprod(X, W * X))
coefficients <- bread %*% crossprod(X, W * Y)

# Residuals
resid <- Y - X %*% coefficients

# The discontinuity is the "above" coefficient (row 3 of coef matrix)
# contrast = c(0, 0, 1, 0)
contrast <- c(0, 0, 1, 0)
jumps <- drop(contrast %*% coefficients)

# HC0 sandwich variance
# loading = w * (X %*% bread %*% contrast)
loading <- W * drop(X %*% bread %*% contrast)

# Influence = loading * residuals (each row scaled by its loading)
influence <- loading * resid  # n x 2 matrix

# Joint covariance matrix (HC0, no df correction)
joint <- crossprod(influence)  # 2x2

# Standard errors
se_rf <- sqrt(joint[1, 1])
se_fs <- sqrt(joint[2, 2])

# Delta method for ratio: treatment_effect = jumps[1] / jumps[2]
te <- jumps[1] / jumps[2]
gradient <- c(1/jumps[2], -jumps[1]/jumps[2]^2)
se_te <- sqrt(drop(t(gradient) %*% joint %*% gradient))

cat("n_obs:", n_obs, "\n")
cat("reduced_form (earnings disc):", jumps[1], "se:", se_rf, "\n")
cat("first_stage (participation disc):", jumps[2], "se:", se_fs, "\n")
cat("treatment_effect:", te, "se:", se_te, "\n")
cat("covariance:", joint[1,2], "\n")

# Write result
result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = unname(te), se = unname(se_te), n_obs = as.integer(n_obs)),
    list(term = "reduced_form", estimate = unname(jumps[1]), se = unname(se_rf), n_obs = as.integer(n_obs)),
    list(term = "first_stage", estimate = unname(jumps[2]), se = unname(se_fs), n_obs = as.integer(n_obs))
  ),
  method_metadata = list(
    estimator = "fuzzy_RD_local_linear_WLS",
    vcov = "HC0"
  ),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
cat("Done. result.json written.\n")
