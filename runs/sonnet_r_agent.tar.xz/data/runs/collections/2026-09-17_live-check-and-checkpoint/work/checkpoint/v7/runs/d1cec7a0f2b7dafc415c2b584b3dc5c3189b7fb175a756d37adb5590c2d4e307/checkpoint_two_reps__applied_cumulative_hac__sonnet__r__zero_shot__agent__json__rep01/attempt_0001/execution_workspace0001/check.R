# Independent verification
library(sandwich)

df <- read.csv("input.csv")
df$date <- as.Date(df$date)
df <- df[order(df$date), ]
df$log_sales <- log(df$sales)
df$log_vix <- log(df$vix)
df$dlvix <- c(NA, diff(df$log_vix))

for (k in 1:15) {
  df[[paste0("lag_", k)]] <- c(rep(NA, k), head(df$dlvix, nrow(df) - k))
}

lag_cols <- paste0("lag_", 1:15)
complete_rows <- complete.cases(df[, c("log_sales", lag_cols)])
df_reg <- df[complete_rows, ]
N <- nrow(df_reg)

# Manual matrix OLS
X <- as.matrix(cbind(1, df_reg[, lag_cols]))
y <- df_reg$log_sales
b <- solve(t(X) %*% X) %*% t(X) %*% y
cat("Manual OLS cumulative response (lags 1-15):", sum(b[2:16]), "\n")
cat("Manual lag_1:", b[2], "lag_15:", b[16], "\n")

# Manual Newey-West: compute residuals, then HAC
resid <- y - X %*% b
n <- length(resid)
p <- ncol(X)
XXinv <- solve(t(X) %*% X)

# Build S matrix (Newey-West HAC, Bartlett, max lag = 15)
S <- matrix(0, p, p)
# j=0
S <- S + t(X * as.vector(resid)) %*% (X * as.vector(resid))
for (j in 1:15) {
  w <- 1 - j/16
  xr_t <- X[(j+1):n, ] * resid[(j+1):n]
  xr_s <- X[1:(n-j), ] * resid[1:(n-j)]
  Gamma_j <- t(xr_t) %*% xr_s
  S <- S + w * (Gamma_j + t(Gamma_j))
}

# Sandwich vcov
vcov_manual <- XXinv %*% S %*% XXinv
# Scale by N/(N-16)
vcov_manual_adj <- vcov_manual * (N / (N - 16))

ones <- rep(1, 15)
lag_vcov_manual <- vcov_manual_adj[2:16, 2:16]
cum_var_manual <- as.numeric(t(ones) %*% lag_vcov_manual %*% ones)
cat("Manual cumulative response SE:", sqrt(cum_var_manual), "\n")
cat("Manual SE lag_1:", sqrt(vcov_manual_adj[2,2]), "\n")
cat("Manual SE lag_15:", sqrt(vcov_manual_adj[16,16]), "\n")
