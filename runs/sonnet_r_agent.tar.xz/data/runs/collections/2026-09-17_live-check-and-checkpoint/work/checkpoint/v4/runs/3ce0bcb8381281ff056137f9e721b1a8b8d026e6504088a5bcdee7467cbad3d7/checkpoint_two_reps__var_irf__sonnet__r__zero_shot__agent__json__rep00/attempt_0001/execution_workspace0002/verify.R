library(vars)
dat <- read.csv("input.csv")
y <- dat[, c("y1", "y2")]
var_model <- VAR(y, p = 2, type = "const")

# Manual Cholesky IRF computation
# Get coefficient matrices
A1 <- Bcoef(var_model)[, 1:2]  # lag 1 coefficients for both equations
A2 <- Bcoef(var_model)[, 3:4]  # lag 2 coefficients

# Get residual covariance matrix
sigma <- summary(var_model)$covres

# Cholesky decomposition of sigma (lower triangular)
P <- t(chol(sigma))  # lower triangular Cholesky factor

cat("Cholesky P matrix:\n"); print(P)
cat("Sigma:\n"); print(sigma)

# Companion matrix for VAR(2): 4x4
k <- 2
Jmat <- rbind(cbind(A1, A2), cbind(diag(k), matrix(0, k, k)))

# Shock: unit shock to y2 (column 2) after Cholesky
# The shock vector is the 2nd column of P
shock <- P[, 2]
cat("Shock vector (col 2 of P):", shock, "\n")

# IRF at horizon h: J^h * e_k * shock_col, extract y1 response (row 1)
# Initial state at h=0
state0 <- c(shock, 0, 0)  # first k elements are the shock, lags are zero

# Propagate using companion matrix
state <- state0
for (h in 1:4) {
  state <- Jmat %*% state
}
irf_y1_h4_manual <- state[1]
cat("Manual IRF y1 to y2 shock at h=4:", irf_y1_h4_manual, "\n")

# Compare with vars package result
irf_result <- irf(var_model, impulse = "y2", response = "y1", n.ahead = 4,
                  ortho = TRUE, boot = FALSE)
irf_vars <- irf_result$irf$y2[5, "y1"]
cat("vars package IRF:", irf_vars, "\n")
cat("Difference:", abs(irf_y1_h4_manual - irf_vars), "\n")
