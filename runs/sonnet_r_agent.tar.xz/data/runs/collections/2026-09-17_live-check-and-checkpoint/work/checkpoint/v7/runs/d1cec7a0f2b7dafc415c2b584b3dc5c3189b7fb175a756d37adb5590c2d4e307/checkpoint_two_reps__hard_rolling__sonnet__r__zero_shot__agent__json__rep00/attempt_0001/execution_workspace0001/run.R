library(jsonlite)

# Read and sort data
dat <- read.csv("input.csv")
dat <- dat[order(dat$time), ]
y <- dat$y

# Rolling AR(1) forecasts for f = 101, ..., 250
forecasts <- numeric(150)

for (i in seq_along(101:250)) {
  f <- 100 + i  # forecast date: 101 to 250
  
  # Window: y_(f-100), ..., y_(f-1) => indices (f-100) to (f-1)
  # Regression pairs: s = f-99, ..., f-1
  # y_s = a + b * y_(s-1)
  # s ranges from f-99 to f-1 (99 pairs)
  
  s_indices <- (f - 99):(f - 1)  # indices of y_s (response)
  s_lag_indices <- (f - 100):(f - 2)  # indices of y_(s-1) (predictor)
  
  y_s <- y[s_indices]
  y_lag <- y[s_lag_indices]
  
  fit <- lm(y_s ~ y_lag)
  a_hat <- coef(fit)[1]
  b_hat <- coef(fit)[2]
  
  # Forecast y_f using y_(f-1)
  forecasts[i] <- a_hat + b_hat * y[f - 1]
}

# Compute RMSE over f=101,...,250
actual <- y[101:250]
errors <- actual - forecasts
rmse <- sqrt(sum(errors^2) / 150)

# Build result
estimates <- list(
  list(term = "rmse", estimate = rmse, se = NULL, n_obs = 150L),
  list(term = "forecast_101", estimate = forecasts[1], se = NULL, n_obs = 99L),
  list(term = "forecast_150", estimate = forecasts[50], se = NULL, n_obs = 99L),
  list(term = "forecast_200", estimate = forecasts[100], se = NULL, n_obs = 99L),
  list(term = "forecast_250", estimate = forecasts[150], se = NULL, n_obs = 99L)
)

result <- list(
  task_id = "hard_rolling",
  platform = "r",
  estimates = estimates,
  method_metadata = list(estimator = "OLS AR(1) rolling window", vcov = "none"),
  diagnostics = setNames(list(), character(0))
)

write(toJSON(result, auto_unbox = TRUE, digits = 10, null = "null"), "result.json")
cat("RMSE:", rmse, "\n")
cat("forecast_101:", forecasts[1], "\n")
cat("forecast_150:", forecasts[50], "\n")
cat("forecast_200:", forecasts[100], "\n")
cat("forecast_250:", forecasts[150], "\n")
