# Anderson-Rubin Confidence Set
# y = intercept + beta*endog + gamma*x + error
# For each beta: regress (y - beta*endog) on intercept, x, z1, z2
# F-test of joint significance of z1, z2 coefficients (numerator df=2, denom df=n-4)

library(jsonlite)

dat <- read.csv("input.csv")
n <- nrow(dat)
y <- dat$y
endog <- dat$endog
x <- dat$x
z1 <- dat$z1
z2 <- dat$z2

# Matrices for projection
# Full regressors: intercept, x, z1, z2
X_full <- cbind(1, x, z1, z2)
# Restricted regressors: intercept, x
X_rest <- cbind(1, x)

# Precompute projections
# For a given beta, y_tilde = y - beta*endog
# We need F-stat for joint test of z1, z2 in regression of y_tilde on X_full
# 
# The F-stat = [(RSS_r - RSS_f)/2] / [RSS_f/(n-4)]
# where RSS_r = residuals from regressing y_tilde on X_rest
#       RSS_f = residuals from regressing y_tilde on X_full

# Projection matrices
P_full <- X_full %*% solve(t(X_full) %*% X_full) %*% t(X_full)
P_rest <- X_rest %*% solve(t(X_rest) %*% X_rest) %*% t(X_rest)
M_full <- diag(n) - P_full
M_rest <- diag(n) - P_rest

# For y_tilde = y - beta*endog:
# RSS_f = t(y_tilde) %*% M_full %*% y_tilde
# RSS_r = t(y_tilde) %*% M_rest %*% y_tilde
# 
# Let a = M_full %*% y, b = M_full %*% endog, then:
# RSS_f = t(y - beta*endog) %*% M_full %*% (y - beta*endog)
#       = (a - beta*b_f)^2 summed = t(a)a - 2*beta*t(a)b_f + beta^2*t(b_f)b_f
# where a = M_full %*% y, b_f = M_full %*% endog

a_f <- M_full %*% y
b_f <- M_full %*% endog
a_r <- M_rest %*% y
b_r <- M_rest %*% endog

# RSS_f(beta) = aa_f - 2*beta*ab_f + beta^2*bb_f
aa_f <- as.numeric(t(a_f) %*% a_f)
ab_f <- as.numeric(t(a_f) %*% b_f)
bb_f <- as.numeric(t(b_f) %*% b_f)

# RSS_r(beta) = aa_r - 2*beta*ab_r + beta^2*bb_r
aa_r <- as.numeric(t(a_r) %*% a_r)
ab_r <- as.numeric(t(a_r) %*% b_r)
bb_r <- as.numeric(t(b_r) %*% b_r)

# F(beta) = [(RSS_r - RSS_f)/2] / [RSS_f/(n-4)]
# F(beta) = [(n-4)/2] * (RSS_r - RSS_f) / RSS_f
# 
# F(beta) <= F_crit iff:
# [(n-4)/2] * (RSS_r - RSS_f) <= F_crit * RSS_f
# (n-4)/2 * RSS_r - (n-4)/2 * RSS_f <= F_crit * RSS_f
# (n-4)/2 * RSS_r <= [F_crit + (n-4)/2] * RSS_f
# Let k = F_crit * 2/(n-4)
# RSS_r <= (1 + k) * RSS_f  -- only valid if RSS_f > 0

F_crit <- qf(0.95, 2, n-4)
cat("F_crit:", F_crit, "\n")
cat("n:", n, "\n")

# Compute F as function of beta
f_stat <- function(beta) {
  rss_f <- aa_f - 2*beta*ab_f + beta^2*bb_f
  rss_r <- aa_r - 2*beta*ab_r + beta^2*bb_r
  f <- ((rss_r - rss_f)/2) / (rss_f/(n-4))
  return(f)
}

# F(beta) <= F_crit
# (n-4)/2 * (RSS_r - RSS_f) <= F_crit * RSS_f
# (n-4)/2 * RSS_r <= [F_crit + (n-4)/2] * RSS_f
# 
# Expand quadratics:
# Let c1 = (n-4)/2, c2 = F_crit + c1
# c1*(aa_r - 2*beta*ab_r + beta^2*bb_r) <= c2*(aa_f - 2*beta*ab_f + beta^2*bb_f)
# Rearrange to: A*beta^2 + B*beta + C <= 0
# where A = c1*bb_r - c2*bb_f
#       B = -2*c1*ab_r + 2*c2*ab_f
#       C = c1*aa_r - c2*aa_f

c1 <- (n-4)/2
c2 <- F_crit + c1

A <- c1*bb_r - c2*bb_f
B <- -2*c1*ab_r + 2*c2*ab_f
C <- c1*aa_r - c2*aa_f

cat("Quadratic coefficients A:", A, "B:", B, "C:", C, "\n")

disc <- B^2 - 4*A*C
cat("Discriminant:", disc, "\n")

# Find roots
if (disc < 0) {
  cat("No real roots - set is either entire real line or empty\n")
} else {
  root1 <- (-B - sqrt(disc)) / (2*A)
  root2 <- (-B + sqrt(disc)) / (2*A)
  cat("Roots:", root1, root2, "\n")
}

# Determine the confidence set structure
# If A > 0: parabola opens up, set is [root1, root2] (finite interval)
# If A < 0: parabola opens down, set is (-inf, root1] U [root2, inf) (two-sided unbounded)
# If A = 0: linear
cat("A:", A, "\n")

boundary_low <- min(root1, root2)
boundary_high <- max(root1, root2)

cat("boundary_low:", boundary_low, "\n")
cat("boundary_high:", boundary_high, "\n")

# Check if set is bounded or unbounded
unbounded <- ifelse(A < 0, 1, 0)
cat("unbounded:", unbounded, "\n")

# Check if zero is in the confidence set
f_at_zero <- f_stat(0)
cat("F at beta=0:", f_at_zero, "\n")
accepts_zero <- ifelse(f_at_zero <= F_crit, 1, 0)
cat("accepts_zero:", accepts_zero, "\n")

# F statistic at beta=1
f_at_one <- f_stat(1)
cat("F at beta=1:", f_at_one, "\n")

# Verification: check a few points
cat("\nVerification checks:\n")
cat("F at boundary_low:", f_stat(boundary_low), "vs F_crit:", F_crit, "\n")
cat("F at boundary_high:", f_stat(boundary_high), "vs F_crit:", F_crit, "\n")
cat("F at midpoint:", f_stat((boundary_low+boundary_high)/2), "\n")

# Direct regression check at beta=1
beta_check <- 1
y_tilde_check <- y - beta_check * endog
lm_full <- lm(y_tilde_check ~ x + z1 + z2)
lm_rest <- lm(y_tilde_check ~ x)
anova_result <- anova(lm_rest, lm_full)
cat("Direct F test at beta=1 via anova:", anova_result$F[2], "\n")

# Write results
estimates <- list(
  list(term="boundary_low", estimate=boundary_low, se=NULL, n_obs=n),
  list(term="boundary_high", estimate=boundary_high, se=NULL, n_obs=n),
  list(term="accepts_zero", estimate=as.numeric(accepts_zero), se=NULL, n_obs=n),
  list(term="unbounded", estimate=as.numeric(unbounded), se=NULL, n_obs=n),
  list(term="ar_f_at_one", estimate=f_at_one, se=NULL, n_obs=n)
)

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "Anderson-Rubin confidence set via F-test inversion",
    vcov = "homoskedastic OLS"
  ),
  diagnostics = list()
)

write(toJSON(result, auto_unbox=TRUE, null="null", digits=10), "result.json")
cat("\nResult written to result.json\n")
