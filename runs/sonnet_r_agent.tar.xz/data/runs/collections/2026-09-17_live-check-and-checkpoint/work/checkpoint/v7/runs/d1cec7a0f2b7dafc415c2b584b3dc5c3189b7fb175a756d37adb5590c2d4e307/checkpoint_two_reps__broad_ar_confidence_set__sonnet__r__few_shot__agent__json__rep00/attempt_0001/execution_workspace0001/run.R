d <- read.csv("input.csv")
n <- nrow(d)

# Unrestricted: y ~ 1 + x + z1 + z2
full_y <- lm(y ~ x + z1 + z2, data=d)
full_e <- lm(endog ~ x + z1 + z2, data=d)
uy <- residuals(full_y)
ud <- residuals(full_e)

# Restricted: y ~ 1 + x (exclude z1, z2)
rest_y <- lm(y ~ x, data=d)
rest_e <- lm(endog ~ x, data=d)
ry <- residuals(rest_y)
rd <- residuals(rest_e)

q <- 2L         # excluded instruments
df <- n - 4L    # n - (intercept + x + z1 + z2)
critical <- qf(0.95, q, df)

# Expand F(beta) <= critical:
# (SSR_R(beta) - SSR_U(beta)) / q <= critical * SSR_U(beta) / df
# SSR_R(beta) - (1 + q*critical/df) * SSR_U(beta) <= 0
# A*beta^2 + B*beta + C <= 0
k <- q * critical / df

A <- sum(rd^2) - (1+k)*sum(ud^2)
B <- -2*(sum(ry*rd) - (1+k)*sum(uy*ud))
C <- sum(ry^2) - (1+k)*sum(uy^2)

cat("A =", A, "\nB =", B, "\nC =", C, "\n")
cat("discriminant =", B^2 - 4*A*C, "\n")

disc <- B^2 - 4*A*C
stopifnot(disc > 0)

bounds <- sort(Re(polyroot(c(C, B, A))))
cat("Bounds:", bounds, "\n")

accepts <- function(beta) A*beta^2 + B*beta + C <= 0
cat("accepts(0):", accepts(0), "\n")
cat("A > 0 (bounded interval):", A > 0, "\n")

# Verify boundaries: F should equal critical at each bound
for (b in bounds) {
  td <- d$y - b * d$endog
  r_fit <- lm(td ~ x, data=d)
  u_fit <- lm(td ~ x + z1 + z2, data=d)
  F <- ((deviance(r_fit) - deviance(u_fit))/q) / (deviance(u_fit)/df)
  cat("At beta =", b, "F =", F, "(critical =", critical, ")\n")
}

# Compute F at beta = 1
b1 <- 1.0
td1 <- d$y - b1 * d$endog
r_fit1 <- lm(td1 ~ x, data=d)
u_fit1 <- lm(td1 ~ x + z1 + z2, data=d)
F_at_one <- ((deviance(r_fit1) - deviance(u_fit1))/q) / (deviance(u_fit1)/df)
cat("F at beta=1:", F_at_one, "\n")

unbounded <- as.integer(A < 0)
accepts_zero <- as.integer(accepts(0))

library(jsonlite)
result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = list(
    list(term="boundary_low",  estimate=unname(bounds[1]),    se=NULL, n_obs=n),
    list(term="boundary_high", estimate=unname(bounds[2]),    se=NULL, n_obs=n),
    list(term="accepts_zero",  estimate=as.numeric(accepts_zero), se=NULL, n_obs=n),
    list(term="unbounded",     estimate=as.numeric(unbounded),    se=NULL, n_obs=n),
    list(term="ar_f_at_one",   estimate=unname(F_at_one),    se=NULL, n_obs=n)
  ),
  method_metadata = list(estimator="Anderson-Rubin", vcov="homoskedastic"),
  diagnostics = list()
)
write_json(result, "result.json", auto_unbox=TRUE, null="null", digits=16, pretty=TRUE)
cat("Done. result.json written.\n")
