# Anderson-Rubin confidence set for beta in y = intercept + beta*endog + gamma*x + error
# Excluded instruments: z1, z2

library(jsonlite)

dat <- read.csv("input.csv")
n <- nrow(dat)
cat("n =", n, "\n")

y <- dat$y
endog <- dat$endog
x <- dat$x
z1 <- dat$z1
z2 <- dat$z2

# Degrees of freedom: numerator=2, denominator=n-4
df1 <- 2
df2 <- n - 4

# Critical value at 95th percentile
f_crit <- qf(0.95, df1, df2)
cat("F critical =", f_crit, "\n")

# Function to compute AR F-statistic for a given beta
ar_f_stat <- function(beta) {
  y_tilde <- y - beta * endog
  
  # Unrestricted: y_tilde ~ 1 + x + z1 + z2
  fit_unres <- lm(y_tilde ~ x + z1 + z2)
  rss_unres <- sum(fit_unres$residuals^2)
  
  # Restricted: y_tilde ~ 1 + x (z1 and z2 excluded)
  fit_res <- lm(y_tilde ~ x)
  rss_res <- sum(fit_res$residuals^2)
  
  # F statistic
  f_stat <- ((rss_res - rss_unres) / df1) / (rss_unres / df2)
  return(f_stat)
}

# Compute F at beta=1
f_at_one <- ar_f_stat(1)
cat("F at beta=1:", f_at_one, "\n")

# Find the boundary points by scanning a wide grid first
# The F statistic is quadratic in beta, so there can be 0 or 2 crossings
# (or the set could be empty or unbounded)

beta_grid <- seq(-1000, 1000, by=0.1)
f_vals <- sapply(beta_grid, ar_f_stat)

# Find where F crosses f_crit
# Below threshold means accepted
accepts <- f_vals <= f_crit

# Check if the set is unbounded (accepts at extreme values)
unbounded_flag <- accepts[1] || accepts[length(accepts)]
cat("Accepts at beta=-1000:", accepts[1], "\n")
cat("Accepts at beta=+1000:", accepts[length(accepts)], "\n")

# Find sign changes in (f_vals - f_crit)
diff_vals <- f_vals - f_crit
sign_changes <- which(diff(sign(diff_vals)) != 0)
cat("Number of sign changes found in grid:", length(sign_changes), "\n")

# Use uniroot to find exact boundary points
boundaries <- c()
for (i in sign_changes) {
  b_lo <- beta_grid[i]
  b_hi <- beta_grid[i + 1]
  root <- uniroot(function(b) ar_f_stat(b) - f_crit, lower=b_lo, upper=b_hi, tol=1e-10)
  boundaries <- c(boundaries, root$root)
  cat("Boundary found at beta =", root$root, "\n")
}

cat("Boundaries:", boundaries, "\n")

# Determine if zero is in the confidence set
f_at_zero <- ar_f_stat(0)
cat("F at beta=0:", f_at_zero, "\n")
accepts_zero <- as.integer(f_at_zero <= f_crit)

# Sort boundaries
if (length(boundaries) == 2) {
  boundary_low <- min(boundaries)
  boundary_high <- max(boundaries)
} else if (length(boundaries) > 2) {
  # Disjoint set possible - report outermost
  boundary_low <- min(boundaries)
  boundary_high <- max(boundaries)
  cat("WARNING: More than 2 boundaries found:", boundaries, "\n")
} else {
  stop("Unexpected number of boundary points: ", length(boundaries))
}

cat("boundary_low =", boundary_low, "\n")
cat("boundary_high =", boundary_high, "\n")
cat("accepts_zero =", accepts_zero, "\n")
cat("unbounded =", as.integer(unbounded_flag), "\n")
cat("ar_f_at_one =", f_at_one, "\n")

# Build result
result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = list(
    list(term = "boundary_low", estimate = boundary_low, se = NULL, n_obs = n),
    list(term = "boundary_high", estimate = boundary_high, se = NULL, n_obs = n),
    list(term = "accepts_zero", estimate = accepts_zero, se = NULL, n_obs = n),
    list(term = "unbounded", estimate = as.integer(unbounded_flag), se = NULL, n_obs = n),
    list(term = "ar_f_at_one", estimate = f_at_one, se = NULL, n_obs = n)
  ),
  method_metadata = list(
    estimator = "Anderson-Rubin test inversion",
    vcov = "homoskedastic (conventional F-test)"
  ),
  diagnostics = list()
)

write(toJSON(result, auto_unbox=TRUE, digits=10, null="null"), "result.json")
cat("result.json written\n")
