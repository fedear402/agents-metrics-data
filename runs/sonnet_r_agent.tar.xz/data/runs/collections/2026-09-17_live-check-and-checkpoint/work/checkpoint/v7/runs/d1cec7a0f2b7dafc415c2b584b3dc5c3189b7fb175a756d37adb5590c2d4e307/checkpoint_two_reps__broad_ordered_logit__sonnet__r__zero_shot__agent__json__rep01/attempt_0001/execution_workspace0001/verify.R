library(MASS)

data <- read.csv("input.csv")
data$y <- factor(data$y, levels = c(1, 2, 3), ordered = TRUE)

model <- polr(y ~ x + z, data = data, method = "logistic", Hess = TRUE)

# Manual check: P(y=3 | x=1, z=0)
# polr: P(y <= j) = logistic(zeta[j] - eta) where eta = beta*x
# P(y=3) = 1 - P(y<=2) = 1 - logistic(zeta[2] - (beta_x*1 + beta_z*0))
bx <- coef(model)["x"]
bz <- coef(model)["z"]
zeta <- model$zeta

eta <- bx * 1 + bz * 0
p_leq2 <- plogis(zeta[2] - eta)
p3_manual <- 1 - p_leq2

cat("Manual P(y=3|x=1,z=0):", p3_manual, "\n")
cat("Model predicted P(y=3|x=1,z=0):", predict(model, data.frame(x=1,z=0), type="probs")["3"], "\n")

# Check log-likelihood
cat("Log-likelihood:", logLik(model), "\n")

# Verify distribution of y
cat("Table of y:\n")
print(table(data$y))
