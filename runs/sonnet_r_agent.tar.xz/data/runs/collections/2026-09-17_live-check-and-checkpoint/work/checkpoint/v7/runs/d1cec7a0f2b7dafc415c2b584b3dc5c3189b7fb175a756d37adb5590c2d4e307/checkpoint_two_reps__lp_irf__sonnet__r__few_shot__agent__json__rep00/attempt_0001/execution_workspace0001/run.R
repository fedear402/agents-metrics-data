library(jsonlite)
library(sandwich)
library(lmtest)

df <- read.csv("./input.csv")

# Local projection: y_{t+4} on shock_t and y_{t-1}, with intercept
# horizon h=4
h <- 4

n <- nrow(df)

# Construct variables
# y_{t+4}: dependent variable - shift y forward by 4
y_lead4 <- df$y[(h+1):n]          # y at t+4, for t=1,...,n-4
shock_t  <- df$shock[1:(n-h)]     # shock at t
y_lag1   <- c(NA, df$y)[1:(n-h)]  # y_{t-1} at t

# y_{t-1}: for t=1, this is y_0 which we don't have, so t starts from 2
# Actually t=1 means y_{t-1} = y_0 which is not in the data
# So we need t >= 2, meaning we drop the first observation
lp_df <- data.frame(
  y_lead4 = y_lead4,
  shock_t  = shock_t,
  y_lag1   = y_lag1
)

# Remove rows with NA (t=1 has no y_{t-1})
lp_df <- na.omit(lp_df)

fit <- lm(y_lead4 ~ shock_t + y_lag1, data = lp_df)

# Newey-West SE with lag 4
nw_vcov <- NeweyWest(fit, lag = 4, prewhite = FALSE, adjust = FALSE)
ct <- coeftest(fit, vcov = nw_vcov)

irf_h4_est <- unname(ct["shock_t", "Estimate"])
irf_h4_se  <- unname(ct["shock_t", "Std. Error"])
n_obs      <- nrow(lp_df)

out <- list(
  task_id  = "lp_irf",
  platform = "r",
  estimates = list(
    list(term = "irf_h4", estimate = irf_h4_est, se = irf_h4_se, n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "Local Projection OLS, horizon h=4",
    vcov = "Newey-West, lag=4"
  ),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "./result.json", auto_unbox = TRUE, digits = 10)
cat("Done. irf_h4 =", irf_h4_est, " se =", irf_h4_se, " n_obs =", n_obs, "\n")
