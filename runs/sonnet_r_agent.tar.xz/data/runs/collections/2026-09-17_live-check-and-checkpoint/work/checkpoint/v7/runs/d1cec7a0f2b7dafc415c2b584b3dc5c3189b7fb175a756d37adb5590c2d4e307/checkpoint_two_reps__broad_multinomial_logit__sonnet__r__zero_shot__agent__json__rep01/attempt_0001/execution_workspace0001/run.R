library(nnet)
library(jsonlite)

dat <- read.csv("input.csv")
dat$y <- factor(dat$y, levels = c(0, 1, 2))

# Fit multinomial logit with base outcome = 0
fit <- multinom(y ~ x + z, data = dat, trace = FALSE)

# Coefficients and standard errors
coef_mat <- summary(fit)$coefficients
se_mat   <- summary(fit)$standard.errors

x_cat1 <- coef_mat["1", "x"]
z_cat1 <- coef_mat["1", "z"]
x_cat2 <- coef_mat["2", "x"]
z_cat2 <- coef_mat["2", "z"]

se_x1 <- se_mat["1", "x"]
se_z1 <- se_mat["1", "z"]
se_x2 <- se_mat["2", "x"]
se_z2 <- se_mat["2", "z"]

# Fitted probability of outcome 2 at x=0, z=0
newdata <- data.frame(x = 0, z = 0)
probs <- predict(fit, newdata = newdata, type = "probs")
prob_cat2_zero <- probs["2"]

n_obs <- nrow(dat)

result <- list(
  task_id  = "broad_multinomial_logit",
  platform = "r",
  estimates = list(
    list(term = "x_cat1",       estimate = x_cat1,       se = se_x1, n_obs = n_obs),
    list(term = "z_cat1",       estimate = z_cat1,       se = se_z1, n_obs = n_obs),
    list(term = "x_cat2",       estimate = x_cat2,       se = se_x2, n_obs = n_obs),
    list(term = "z_cat2",       estimate = z_cat2,       se = se_z2, n_obs = n_obs),
    list(term = "prob_cat2_zero", estimate = prob_cat2_zero, se = NULL, n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "multinomial logit (nnet::multinom)",
    vcov      = "observed information (default)"
  ),
  diagnostics = list()
)

write(toJSON(result, auto_unbox = TRUE, digits = 10, null = "null"),
      file = "result.json")

cat("x_cat1:", x_cat1, "\n")
cat("z_cat1:", z_cat1, "\n")
cat("x_cat2:", x_cat2, "\n")
cat("z_cat2:", z_cat2, "\n")
cat("prob_cat2_zero:", prob_cat2_zero, "\n")
cat("n_obs:", n_obs, "\n")
