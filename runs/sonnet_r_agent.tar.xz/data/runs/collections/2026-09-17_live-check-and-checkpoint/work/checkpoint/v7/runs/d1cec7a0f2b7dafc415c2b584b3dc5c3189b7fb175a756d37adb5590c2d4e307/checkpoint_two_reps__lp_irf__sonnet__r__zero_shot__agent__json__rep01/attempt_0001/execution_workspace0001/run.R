library(sandwich)
library(lmtest)
library(jsonlite)

# Read data
df <- read.csv("input.csv")

# Local projection: y_{t+4} on shock_t and y_{t-1}, with intercept
# Create lead of y by 4 periods and lag of y by 1 period
n <- nrow(df)

# y_{t+4}: shift y forward by 4 (i.e., for obs t, use y[t+4])
df$y_lead4 <- c(df$y[5:n], rep(NA, 4))

# y_{t-1}: lag y by 1
df$y_lag1 <- c(NA, df$y[1:(n-1)])

# Drop rows with NA
df_clean <- na.omit(df[, c("y_lead4", "shock", "y_lag1")])

# Estimate OLS
fit <- lm(y_lead4 ~ shock + y_lag1, data = df_clean)

# Newey-West SE with lag 4
nw_vcov <- NeweyWest(fit, lag = 4, prewhite = FALSE)
ct <- coeftest(fit, vcov = nw_vcov)

# Extract shock coefficient (irf_h4)
est <- ct["shock", "Estimate"]
se  <- ct["shock", "Std. Error"]
n_obs <- nobs(fit)

cat("Estimate (irf_h4):", est, "\n")
cat("SE (NW lag 4):", se, "\n")
cat("N obs:", n_obs, "\n")
cat("Coefficients:\n")
print(ct)

# Write result
result <- list(
  task_id = "lp_irf",
  platform = "r",
  estimates = list(
    list(term = "irf_h4", estimate = est, se = se, n_obs = as.integer(n_obs))
  ),
  method_metadata = list(
    estimator = "OLS local projection",
    vcov = "Newey-West lag 4"
  ),
  diagnostics = list()
)

write(toJSON(result, auto_unbox = TRUE, digits = 10), "result.json")
cat("result.json written\n")
