library(forecast)
library(jsonlite)

dat <- read.csv("input.csv")
y   <- dat$y
n   <- length(y)  # 250

# Fit ARIMA(1,1,1) with no constant (include.constant=FALSE)
fit <- Arima(y, order = c(1,1,1), include.constant = FALSE, method = "ML")

cat("Coefficients:\n"); print(coef(fit))
cat("Log-likelihood:", fit$loglik, "\n")
cat("AIC:", fit$aic, "\n")
cat("n_obs:", n, "\n")

# One-step-ahead forecast for t=251 (h=1)
fc <- forecast(fit, h = 1, level = 95)

forecast_val <- as.numeric(fc$mean)
lower_val    <- as.numeric(fc$lower)
upper_val    <- as.numeric(fc$upper)

cat("Forecast:", forecast_val, "\n")
cat("Lower 95%:", lower_val, "\n")
cat("Upper 95%:", upper_val, "\n")

# Independent check: manual one-step forecast
# ARIMA(1,1,1): (1-phi*B)(1-B)y_t = (1+theta*B)e_t
# => delta_y_t = phi*delta_y_{t-1} + e_t + theta*e_{t-1}
phi   <- coef(fit)["ar1"]
theta <- coef(fit)["ma1"]
resid <- residuals(fit)
dy    <- diff(y)

# Forecast of delta_y at t=251: phi*dy[250] + theta*resid[250]
delta_fc <- phi * dy[n-1] + theta * resid[n]
manual_fc <- y[n] + delta_fc
cat("Manual forecast check:", manual_fc, "\n")
cat("Discrepancy:", abs(manual_fc - forecast_val), "\n")

result <- list(
  task_id  = "arima_forecast",
  platform = "r",
  estimates = list(
    list(term = "forecast",  estimate = forecast_val, se = NULL, n_obs = n),
    list(term = "lower_95",  estimate = lower_val,    se = NULL, n_obs = n),
    list(term = "upper_95",  estimate = upper_val,    se = NULL, n_obs = n)
  ),
  method_metadata = list(
    estimator = "ARIMA(1,1,1) ML via forecast::Arima, no constant",
    vcov      = "MLE asymptotic, prediction interval from forecast package"
  ),
  diagnostics = list()
)

write(toJSON(result, auto_unbox = TRUE, digits = 10, null = "null"),
      "result.json")
cat("result.json written.\n")
