library(vars)
library(jsonlite)

dat <- read.csv("input.csv")
n_obs <- nrow(dat)

# Fit VAR(2) with constant, y1 ordered first
y <- dat[, c("y1", "y2")]
var_model <- VAR(y, p = 2, type = "const")

# Cholesky IRF of y1 to shock in y2 at horizon 4
irf_result <- irf(var_model, impulse = "y2", response = "y1", n.ahead = 4,
                  ortho = TRUE, boot = FALSE)

# horizon 4 is index 5 (0-indexed: h0, h1, h2, h3, h4)
irf_val <- irf_result$irf$y2[5, "y1"]

cat("IRF y1 to y2 shock at h=4:", irf_val, "\n")
cat("N obs:", n_obs, "\n")

result <- list(
  task_id = "var_irf",
  platform = "r",
  estimates = list(
    list(term = "irf_y1_to_y2_h4", estimate = irf_val, se = NULL, n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "VAR(2) OLS with constant",
    vcov = "Cholesky orthogonalization (y1 ordered first)"
  ),
  diagnostics = list()
)

write(toJSON(result, auto_unbox = TRUE, digits = 10, null = "null"),
      "result.json")
cat("result.json written\n")
