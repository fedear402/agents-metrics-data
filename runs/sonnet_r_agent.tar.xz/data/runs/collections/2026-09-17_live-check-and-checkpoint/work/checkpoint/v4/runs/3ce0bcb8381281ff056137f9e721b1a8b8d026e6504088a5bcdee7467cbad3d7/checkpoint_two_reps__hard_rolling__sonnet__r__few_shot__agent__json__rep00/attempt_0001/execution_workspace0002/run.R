library(jsonlite)

data <- read.csv("input.csv")
data <- data[order(data$time), ]
stopifnot(nrow(data) == 250)
stopifnot(all(data$time == 1:250))

forecast_times <- 101:250
forecasts <- numeric(length(forecast_times))

for (i in seq_along(forecast_times)) {
  f <- forecast_times[i]
  # Use y_(f-100) through y_(f-1): 100 levels
  history <- data$y[data$time >= (f - 100) & data$time <= (f - 1)]
  stopifnot(length(history) == 100)
  # 99 regression pairs: lagged and current
  lagged <- head(history, -1)
  current <- tail(history, -1)
  stopifnot(length(current) == 99)
  fit <- lm(current ~ lagged)
  # Forecast using y_(f-1)
  forecasts[i] <- coef(fit)[1] + coef(fit)[2] * tail(history, 1)
}

actual <- data$y[data$time %in% forecast_times]
rmse <- sqrt(mean((actual - forecasts)^2))

row <- function(term, estimate, se, n_obs) {
  list(term = term, estimate = unname(as.numeric(estimate)),
       se = se, n_obs = as.integer(n_obs))
}

estimates <- list(
  row("rmse", rmse, NULL, 150L),
  row("forecast_101", forecasts[which(forecast_times == 101)], NULL, 99L),
  row("forecast_150", forecasts[which(forecast_times == 150)], NULL, 99L),
  row("forecast_200", forecasts[which(forecast_times == 200)], NULL, 99L),
  row("forecast_250", forecasts[which(forecast_times == 250)], NULL, 99L)
)

result <- list(
  task_id = "hard_rolling",
  platform = "r",
  estimates = estimates,
  method_metadata = list(estimator = "OLS AR(1) rolling window", vcov = "none"),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
cat("RMSE:", rmse, "\n")
cat("forecast_101:", forecasts[1], "\n")
cat("forecast_150:", forecasts[50], "\n")
cat("forecast_200:", forecasts[100], "\n")
cat("forecast_250:", forecasts[150], "\n")
