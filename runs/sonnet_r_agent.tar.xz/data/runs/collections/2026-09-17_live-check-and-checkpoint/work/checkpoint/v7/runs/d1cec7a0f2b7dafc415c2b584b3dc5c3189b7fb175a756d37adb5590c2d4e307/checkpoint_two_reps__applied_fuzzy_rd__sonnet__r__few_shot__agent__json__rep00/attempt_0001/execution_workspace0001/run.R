library(jsonlite)

# Load data
dat <- read.csv("input.csv")

# Filter to bandwidth abs(score) < 1
bw_dat <- dat[abs(dat$score) < 1, ]
n_obs <- nrow(bw_dat)

# Triangular weights
bw_dat$w <- 1 - abs(bw_dat$score)

# Indicator for right side (score >= 0)
bw_dat$above <- as.integer(bw_dat$score >= 0)

# Design matrix for local linear RD:
# X = [1, score, above, score*above]
# The discontinuity is captured by the 'above' coefficient
# with separate slopes on each side
X <- cbind(1, bw_dat$score, bw_dat$above, bw_dat$score * bw_dat$above)
w <- bw_dat$w

# Weighted least squares for earnings (reduced form) and participation (first stage)
Y_earn <- bw_dat$earnings
Y_part <- bw_dat$participated

# WLS via normal equations
WX <- w * X
bread <- solve(crossprod(X, WX))  # (X'WX)^{-1}

# Coefficients
coef_earn <- bread %*% crossprod(X, w * Y_earn)
coef_part <- bread %*% crossprod(X, w * Y_part)

# Residuals
resid_earn <- Y_earn - X %*% coef_earn
resid_part <- Y_part - X %*% coef_part

# Discontinuity = coefficient on 'above' (index 3, 0-based: column 3)
# contrast vector selects the 'above' coefficient
contrast <- c(0, 0, 1, 0)

jump_earn <- drop(contrast %*% coef_earn)  # reduced form
jump_part <- drop(contrast %*% coef_part)  # first stage

# HC0 sandwich standard errors
# loading = w * X (bread %*% contrast) -- the "hat" for the contrast
loading <- w * drop(X %*% (bread %*% contrast))

# Influence functions for each outcome
inf_earn <- loading * resid_earn
inf_part <- loading * resid_part

# Joint covariance matrix (2x2)
infl_mat <- cbind(inf_earn, inf_part)
joint_cov <- crossprod(infl_mat)

se_earn <- sqrt(joint_cov[1, 1])
se_part <- sqrt(joint_cov[2, 2])

# Delta method for ratio = jump_earn / jump_part
# d(ratio)/d(jump_earn) = 1/jump_part
# d(ratio)/d(jump_part) = -jump_earn/jump_part^2
gradient <- c(1/jump_part, -jump_earn/jump_part^2)
se_ratio <- sqrt(drop(t(gradient) %*% joint_cov %*% gradient))

ratio <- jump_earn / jump_part

cat("n_obs:", n_obs, "\n")
cat("reduced_form (earnings jump):", jump_earn, "\n")
cat("first_stage (participation jump):", jump_part, "\n")
cat("treatment_effect (ratio):", ratio, "\n")
cat("se_earn:", se_earn, "\n")
cat("se_part:", se_part, "\n")
cat("se_ratio:", se_ratio, "\n")
cat("covariance:", joint_cov[1,2], "\n")

# Write result
result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = unname(ratio), se = unname(se_ratio), n_obs = as.integer(n_obs)),
    list(term = "reduced_form", estimate = unname(jump_earn), se = unname(se_earn), n_obs = as.integer(n_obs)),
    list(term = "first_stage", estimate = unname(jump_part), se = unname(se_part), n_obs = as.integer(n_obs))
  ),
  method_metadata = list(
    estimator = "fuzzy_RD_local_linear_WLS",
    vcov = "HC0_sandwich_no_dof_correction"
  ),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, digits = 16, pretty = TRUE)
cat("Done. Result written to result.json\n")
