library(sandwich)
library(jsonlite)

# Load data
dat <- read.csv("input.csv")

# Apply bandwidth filter: abs(score) < 1
dat <- dat[abs(dat$score) < 1, ]
n_obs <- nrow(dat)

# Triangular weights
dat$w <- 1 - abs(dat$score)

# Indicator: right side (score >= 0)
dat$D <- as.integer(dat$score >= 0)

# Design matrix for local linear with separate slopes on each side
# y = a0 + a1*score*(1-D) + b0*D + b1*score*D
# i.e.: intercept, score_left, D, score_right
# score_left = score*(1-D), score_right = score*D
dat$score_left  <- dat$score * (1 - dat$D)
dat$score_right <- dat$score * dat$D

X <- cbind(1, dat$score_left, dat$D, dat$score_right)
colnames(X) <- c("intercept", "score_left", "D", "score_right")

W <- diag(dat$w)

# WLS: beta = (X'WX)^{-1} X'Wy
XtW <- t(X) %*% W
XtWX <- XtW %*% X
XtWX_inv <- solve(XtWX)

# Fit for earnings (reduced form)
y_earn <- dat$earnings
beta_earn <- XtWX_inv %*% XtW %*% y_earn
resid_earn <- y_earn - X %*% beta_earn

# Fit for participation (first stage)
y_part <- dat$participated
beta_part <- XtWX_inv %*% XtW %*% y_part
resid_part <- y_part - X %*% beta_part

# HC0 sandwich variance (treating weights as fixed)
# V = (X'WX)^{-1} * (X'W * diag(e^2) * W'X) * (X'WX)^{-1}
# But with fixed weights, the "meat" uses weighted residuals
# Standard HC0: V = (X'WX)^{-1} * sum_i w_i^2 * e_i^2 * x_i x_i' * (X'WX)^{-1}

# Meat for earnings
meat_earn <- matrix(0, 4, 4)
for (i in 1:n_obs) {
  xi <- X[i, , drop=FALSE]
  meat_earn <- meat_earn + dat$w[i]^2 * resid_earn[i]^2 * t(xi) %*% xi
}
V_earn <- XtWX_inv %*% meat_earn %*% XtWX_inv

# Meat for participation
meat_part <- matrix(0, 4, 4)
for (i in 1:n_obs) {
  xi <- X[i, , drop=FALSE]
  meat_part <- meat_part + dat$w[i]^2 * resid_part[i]^2 * t(xi) %*% xi
}
V_part <- XtWX_inv %*% meat_part %*% XtWX_inv

# Cross-meat for delta method
meat_cross <- matrix(0, 4, 4)
for (i in 1:n_obs) {
  xi <- X[i, , drop=FALSE]
  meat_cross <- meat_cross + dat$w[i]^2 * resid_earn[i] * resid_part[i] * t(xi) %*% xi
}
V_cross <- XtWX_inv %*% meat_cross %*% XtWX_inv

# Discontinuities are the coefficient on D (index 3, 1-based = row/col 3)
# reduced_form = beta_earn[3] (right intercept minus left intercept for earnings)
# first_stage  = beta_part[3]
rf_est  <- beta_earn[3]
fs_est  <- beta_part[3]

rf_se   <- sqrt(V_earn[3, 3])
fs_se   <- sqrt(V_part[3, 3])

# Treatment effect = rf / fs
te_est <- rf_est / fs_est

# Delta method: Var(rf/fs) = (1/fs)^2 * Var(rf) + (rf/fs^2)^2 * Var(fs) - 2*(rf/fs^3)*Cov(rf,fs)
cov_rf_fs <- V_cross[3, 3]
te_var <- (1/fs_est)^2 * V_earn[3,3] + (rf_est/fs_est^2)^2 * V_part[3,3] - 2*(rf_est/fs_est^3)*cov_rf_fs
te_se <- sqrt(te_var)

cat("n_obs:", n_obs, "\n")
cat("reduced_form estimate:", rf_est, "se:", rf_se, "\n")
cat("first_stage estimate:", fs_est, "se:", fs_se, "\n")
cat("treatment_effect estimate:", te_est, "se:", te_se, "\n")

# Build result JSON
result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = as.numeric(te_est), se = as.numeric(te_se), n_obs = as.integer(n_obs)),
    list(term = "reduced_form",     estimate = as.numeric(rf_est),  se = as.numeric(rf_se),  n_obs = as.integer(n_obs)),
    list(term = "first_stage",      estimate = as.numeric(fs_est),  se = as.numeric(fs_se),  n_obs = as.integer(n_obs))
  ),
  method_metadata = list(
    estimator = "fuzzy_RD_local_linear_triangular",
    vcov = "HC0_no_dof_correction"
  ),
  diagnostics = list()
)

write(toJSON(result, auto_unbox = TRUE, digits = 10), "result.json")
cat("result.json written\n")
