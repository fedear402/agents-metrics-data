library(jsonlite)
library(sandwich)
library(lmtest)

df <- read.csv("./input.csv")

# Local projection: y_{t+4} on shock_t and y_{t-1}, with intercept
# Construct variables:
# - y_lead4: y at t+4
# - shock: shock at t
# - y_lag1: y at t-1

n <- nrow(df)

# y_{t+4}: lead y by 4 periods
y_lead4 <- c(df$y[5:n], rep(NA, 4))

# y_{t-1}: lag y by 1 period
y_lag1 <- c(NA, df$y[1:(n-1)])

lp_df <- data.frame(
  y_lead4 = y_lead4,
  shock   = df$shock,
  y_lag1  = y_lag1
)

# Drop rows with NA
lp_df <- na.omit(lp_df)

# OLS regression
fit <- lm(y_lead4 ~ shock + y_lag1, data = lp_df)

# Newey-West standard errors with lag 4
nw_vcov <- NeweyWest(fit, lag = 4, prewhite = FALSE, adjust = FALSE)
ct <- coeftest(fit, vcov = nw_vcov)

# Extract shock coefficient (irf_h4)
irf_h4_est <- unname(ct["shock", "Estimate"])
irf_h4_se  <- unname(ct["shock", "Std. Error"])
n_obs <- nrow(lp_df)

out <- list(
  task_id = "lp_irf",
  platform = "r",
  estimates = list(
    list(term = "irf_h4", estimate = irf_h4_est, se = irf_h4_se, n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "Local Projection OLS, horizon h=4",
    vcov = "Newey-West (lag=4)"
  ),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "result.json", auto_unbox = TRUE, digits = 10)
cat("Done. irf_h4 =", irf_h4_est, "se =", irf_h4_se, "n_obs =", n_obs, "\n")
