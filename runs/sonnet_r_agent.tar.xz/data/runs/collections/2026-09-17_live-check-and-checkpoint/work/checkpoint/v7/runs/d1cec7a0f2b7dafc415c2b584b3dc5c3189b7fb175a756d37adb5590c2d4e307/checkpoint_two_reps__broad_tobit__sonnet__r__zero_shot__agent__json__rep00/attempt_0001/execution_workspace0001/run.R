library(survival)
library(jsonlite)

dat <- read.csv("input.csv")
cat("Rows:", nrow(dat), "\n")
cat("y==0 count:", sum(dat$y == 0), "\n")

# Fit Tobit model using survreg with left censoring at 0
# survreg parameterizes as latent y*; left censored at 0
# Create survival object: left censored at 0
surv_obj <- Surv(time = dat$y, event = (dat$y > 0), type = "left")

fit <- survreg(surv_obj ~ x + z, data = dat, dist = "gaussian")
summary(fit)

# Extract coefficients and SEs
coef_vec <- coef(fit)
vcov_mat <- vcov(fit)
se_vec <- sqrt(diag(vcov_mat))

# survreg output: intercept, x, z, log(scale)
# sigma = exp(log(scale))
sigma_est <- fit$scale

cat("\nCoefficients:\n")
print(coef_vec)
cat("\nSEs:\n")
print(se_vec)
cat("\nScale (sigma):", sigma_est, "\n")

n_obs <- nrow(dat)

result <- list(
  task_id = "broad_tobit",
  platform = "r",
  estimates = list(
    list(term = "const", estimate = unname(coef_vec["(Intercept)"]), se = unname(se_vec["(Intercept)"]), n_obs = n_obs),
    list(term = "x", estimate = unname(coef_vec["x"]), se = unname(se_vec["x"]), n_obs = n_obs),
    list(term = "z", estimate = unname(coef_vec["z"]), se = unname(se_vec["z"]), n_obs = n_obs),
    list(term = "sigma", estimate = sigma_est, se = NULL, n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "Tobit MLE via survreg (Gaussian, left-censored at 0)",
    vcov = "observed-information (default survreg)"
  ),
  diagnostics = setNames(list(), character(0))
)

write(toJSON(result, auto_unbox = TRUE, null = "null", digits = 10), "result.json")
cat("\nresult.json written.\n")
