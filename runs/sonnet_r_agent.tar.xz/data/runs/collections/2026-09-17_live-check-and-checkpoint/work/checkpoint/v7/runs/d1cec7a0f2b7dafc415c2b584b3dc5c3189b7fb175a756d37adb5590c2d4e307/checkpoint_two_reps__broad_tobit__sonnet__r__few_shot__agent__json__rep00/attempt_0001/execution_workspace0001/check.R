library(survival)
d <- read.csv("input.csv")

b0 <- 0.20029163999458119
bx <- 0.83508989624040242
bz <- -0.65088889270670403
sig <- 1.0896911717917142

mu <- b0 + bx * d$x + bz * d$z
cens <- d$y == 0
ll_obs <- sum(dnorm(d$y[!cens], mean = mu[!cens], sd = sig, log = TRUE))
ll_cens <- sum(pnorm(0, mean = mu[cens], sd = sig, log.p = TRUE))
ll_total <- ll_obs + ll_cens
cat("Manual log-likelihood:", ll_total, "\n")

fit <- survreg(Surv(y, y > 0, type = "left") ~ x + z, data = d, dist = "gaussian",
               control = survreg.control(rel.tolerance = 1e-12))
cat("survreg loglik:", fit$loglik[2], "\n")
cat("Censored obs:", sum(cens), "/ Uncensored:", sum(!cens), "\n")
cat("Match:", abs(ll_total - fit$loglik[2]) < 1e-4, "\n")
