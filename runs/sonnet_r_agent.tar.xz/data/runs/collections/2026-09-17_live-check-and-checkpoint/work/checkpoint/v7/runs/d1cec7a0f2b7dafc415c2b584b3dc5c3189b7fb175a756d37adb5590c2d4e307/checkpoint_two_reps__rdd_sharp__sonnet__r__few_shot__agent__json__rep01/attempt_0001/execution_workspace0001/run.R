library(jsonlite)

df <- read.csv("./input.csv")

# Bandwidth and cutoff
h <- 0.5
cutoff <- 0

# Subset to bandwidth window
df_bw <- df[abs(df$z - cutoff) <= h, ]

# Triangular kernel weights: K(u) = (1 - |u|) for |u| <= 1
df_bw$dist <- df_bw$z - cutoff
df_bw$w <- 1 - abs(df_bw$dist) / h

# Split into left and right sides
left  <- df_bw[df_bw$z < cutoff, ]
right <- df_bw[df_bw$z >= cutoff, ]

# Local linear regression on each side using WLS
fit_left  <- lm(y ~ dist, data = left,  weights = w)
fit_right <- lm(y ~ dist, data = right, weights = w)

# Intercepts at cutoff
int_left  <- coef(fit_left)["(Intercept)"]
int_right <- coef(fit_right)["(Intercept)"]

late_est <- as.numeric(int_right - int_left)

# SE via delta method / combined model approach
# Fit a single pooled model with indicator for right side
df_bw$above <- as.integer(df_bw$z >= cutoff)
df_bw$above_dist <- df_bw$above * df_bw$dist

fit_pooled <- lm(y ~ dist + above + above_dist, data = df_bw, weights = w)
# 'above' coefficient is the LATE (jump at cutoff)
late_pooled <- coef(fit_pooled)["above"]
se_pooled   <- sqrt(vcov(fit_pooled)["above", "above"])

n_obs <- nrow(df_bw)

cat("late (two separate models):", late_est, "\n")
cat("late (pooled model):", late_pooled, "\n")
cat("se:", se_pooled, "\n")
cat("n_obs:", n_obs, "\n")

out <- list(
  task_id = "rdd_sharp",
  platform = "r",
  estimates = list(
    list(term = "late", estimate = as.numeric(late_pooled), se = as.numeric(se_pooled), n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "local linear regression, triangular kernel, h=0.5",
    vcov = "OLS standard errors from pooled model"
  ),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "./result.json", auto_unbox = TRUE, digits = 10)
