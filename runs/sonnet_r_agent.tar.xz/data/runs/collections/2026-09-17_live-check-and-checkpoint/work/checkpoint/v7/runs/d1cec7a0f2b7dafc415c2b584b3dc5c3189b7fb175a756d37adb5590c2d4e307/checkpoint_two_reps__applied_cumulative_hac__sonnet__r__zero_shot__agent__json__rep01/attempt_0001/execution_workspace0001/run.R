library(sandwich)
library(jsonlite)

# Load and sort data
df <- read.csv("input.csv")
df$date <- as.Date(df$date)
df <- df[order(df$date), ]

# Compute log transformations
df$log_sales <- log(df$sales)
df$log_vix <- log(df$vix)

# Compute first difference of log(vix) across consecutive trading observations
df$dlvix <- c(NA, diff(df$log_vix))

# Create lags 1-15 of dlvix
for (k in 1:15) {
  df[[paste0("lag_", k)]] <- c(rep(NA, k), head(df$dlvix, nrow(df) - k))
}

# Keep only complete cases (lags 1-15 all available)
lag_cols <- paste0("lag_", 1:15)
complete_rows <- complete.cases(df[, c("log_sales", lag_cols)])
df_reg <- df[complete_rows, ]
N <- nrow(df_reg)
cat("N (regression sample):", N, "\n")

# Run OLS regression
formula_str <- paste("log_sales ~", paste(lag_cols, collapse = " + "))
fit <- lm(as.formula(formula_str), data = df_reg)

cat("Coefficients:\n")
print(coef(fit))

# Newey-West HAC covariance with max lag 15, Bartlett weights 1-j/16
# sandwich::NeweyWest uses prewhite=FALSE by default
# Bartlett weights 1-j/16 means bandwidth parameter = 16 (lag/(bandwidth))
# sandwich::NeweyWest with bw=16 uses weights 1 - j/bw = 1 - j/16
vcov_nw <- NeweyWest(fit, lag = 15, prewhite = FALSE, adjust = FALSE)

# Multiply by N/(N-16)
vcov_adj <- vcov_nw * (N / (N - 16))

cat("Diagonal of adjusted vcov (intercept, lag1..lag15):\n")
print(diag(vcov_adj))

# Extract coefficients (indices: 1=intercept, 2=lag_1, ..., 16=lag_15)
coefs <- coef(fit)
lag_coef_names <- paste0("lag_", 1:15)

# Cumulative response: sum of lag_1 through lag_15 coefficients
cum_response <- sum(coefs[lag_coef_names])
cat("Cumulative response:", cum_response, "\n")

# SE for cumulative response using full covariance matrix
# sum of all 15 lag coefficients
ones <- rep(1, 15)
lag_vcov <- vcov_adj[lag_coef_names, lag_coef_names]
cum_var <- as.numeric(t(ones) %*% lag_vcov %*% ones)
cum_se <- sqrt(cum_var)
cat("Cumulative response SE:", cum_se, "\n")

# SE for individual lags
se_lag1 <- sqrt(vcov_adj["lag_1", "lag_1"])
se_lag15 <- sqrt(vcov_adj["lag_15", "lag_15"])
cat("SE lag_1:", se_lag1, "\n")
cat("SE lag_15:", se_lag15, "\n")

# Build result
result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(term = "cumulative_response", estimate = cum_response, se = cum_se, n_obs = N),
    list(term = "lag_1", estimate = unname(coefs["lag_1"]), se = se_lag1, n_obs = N),
    list(term = "lag_15", estimate = unname(coefs["lag_15"]), se = se_lag15, n_obs = N)
  ),
  method_metadata = list(
    estimator = "OLS",
    vcov = "Newey-West HAC, max lag 15, Bartlett weights 1-j/16, scaled by N/(N-16)"
  ),
  diagnostics = list()
)

write(toJSON(result, auto_unbox = TRUE, digits = 10), "result.json")
cat("result.json written.\n")
