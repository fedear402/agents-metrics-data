library(MASS)
library(jsonlite)

dat <- read.csv("input.csv")
n_obs <- nrow(dat)
dat$y <- factor(dat$y, levels = c(1, 2, 3), ordered = TRUE)

fit <- polr(y ~ x + z, data = dat, method = "logistic", Hess = TRUE)
s <- summary(fit)
coefs <- s$coefficients

x_est <- coefs["x", "Value"]
x_se  <- coefs["x", "Std. Error"]
z_est <- coefs["z", "Value"]
z_se  <- coefs["z", "Std. Error"]

newdata <- data.frame(x = 1, z = 0)
probs <- predict(fit, newdata = newdata, type = "probs")
cat("probs structure:\n")
print(probs)
prob_high <- as.numeric(probs["3"])

result <- list(
  task_id = "broad_ordered_logit",
  platform = "r",
  estimates = list(
    list(term = "x", estimate = x_est, se = x_se, n_obs = n_obs),
    list(term = "z", estimate = z_est, se = z_se, n_obs = n_obs),
    list(term = "prob_high", estimate = prob_high, se = NULL, n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "ordered logit (polr)",
    vcov = "observed information (default)"
  ),
  diagnostics = list()
)

write(toJSON(result, auto_unbox = TRUE, digits = 10, null = "null"), "result.json")
cat("Done. n_obs =", n_obs, "\n")
cat("x:", x_est, "se:", x_se, "\n")
cat("z:", z_est, "se:", z_se, "\n")
cat("prob_high:", prob_high, "\n")
print(coefs)
