library(jsonlite)

# Load data
dat <- read.csv("input.csv")

# RDD parameters
cutoff <- 0
h <- 0.5

# Subset to bandwidth
in_bw <- abs(dat$z - cutoff) <= h
dat_bw <- dat[in_bw, ]
n_obs <- nrow(dat_bw)

# Triangular kernel weights
dat_bw$w <- (1 - abs(dat_bw$z - cutoff) / h)

# Indicator for right side
dat_bw$above <- as.integer(dat_bw$z >= cutoff)

# Local linear regression: y ~ (z - cutoff) * side, allowing different slopes
# Model: y = alpha_L + beta_L*(z) + tau*above + beta_R_diff*(z*above) + error
# where tau = difference in intercepts at cutoff (LATE for sharp RDD)
dat_bw$z_c <- dat_bw$z - cutoff
dat_bw$z_above <- dat_bw$z_c * dat_bw$above

fit <- lm(y ~ z_c + above + z_above, data = dat_bw, weights = w)
summary(fit)

late_est <- coef(fit)["above"]
late_se <- sqrt(diag(vcov(fit)))["above"]

cat("LATE estimate:", late_est, "\n")
cat("LATE SE:", late_se, "\n")
cat("N obs in bandwidth:", n_obs, "\n")

# Write result
result <- list(
  task_id = "rdd_sharp",
  platform = "r",
  estimates = list(
    list(term = "late", estimate = as.numeric(late_est), se = as.numeric(late_se), n_obs = as.integer(n_obs))
  ),
  method_metadata = list(
    estimator = "local linear regression with triangular kernel",
    vcov = "OLS default (homoskedastic)"
  ),
  diagnostics = list()
)

write(toJSON(result, auto_unbox = TRUE, digits = 10), "result.json")
cat("result.json written\n")
