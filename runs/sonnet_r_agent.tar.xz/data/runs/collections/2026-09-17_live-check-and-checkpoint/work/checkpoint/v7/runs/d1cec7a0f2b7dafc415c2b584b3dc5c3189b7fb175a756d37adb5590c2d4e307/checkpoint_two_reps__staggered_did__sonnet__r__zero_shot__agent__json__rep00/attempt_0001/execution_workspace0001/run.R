library(jsonlite)

d <- read.csv("input.csv")

# Never-treated: cohort == -1
nt <- d[d$cohort == -1, ]

# Treated cohorts
cohorts <- c(4, 6, 8)

# For each cohort g, supported post-treatment cells: t >= g (first treatment year = g)
# Cell (g,t): DiD = [E(y|g,t) - E(y|g,g-1)] - [E(y|NT,t) - E(y|NT,g-1)]

att_cells <- c()
n_cells <- 0

for (g in cohorts) {
  g_data <- d[d$cohort == g, ]
  baseline_g  <- mean(g_data$y_did[g_data$year == (g - 1)])
  baseline_nt <- mean(nt$y_did[nt$year == (g - 1)])
  
  post_years <- unique(d$year[d$year >= g])
  
  for (t in post_years) {
    mu_gt  <- mean(g_data$y_did[g_data$year == t])
    mu_ntt <- mean(nt$y_did[nt$year == t])
    
    cell_att <- (mu_gt - baseline_g) - (mu_ntt - baseline_nt)
    att_cells <- c(att_cells, cell_att)
    n_cells <- n_cells + 1
  }
}

ATT_uniform <- mean(att_cells)
cat("ATT_uniform:", ATT_uniform, "\n")
cat("Number of cells:", n_cells, "\n")

# Total obs: all firms x all years (used in estimation)
n_obs <- nrow(d)

result <- list(
  task_id = "staggered_did",
  platform = "r",
  estimates = list(
    list(term = "att", estimate = ATT_uniform, se = NULL, n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "ATT_uniform_group_year_means",
    vcov = "none"
  ),
  diagnostics = setNames(list(), character(0))
)

write(toJSON(result, auto_unbox = TRUE, null = "null", digits = 10), "result.json")
cat("Written result.json\n")
