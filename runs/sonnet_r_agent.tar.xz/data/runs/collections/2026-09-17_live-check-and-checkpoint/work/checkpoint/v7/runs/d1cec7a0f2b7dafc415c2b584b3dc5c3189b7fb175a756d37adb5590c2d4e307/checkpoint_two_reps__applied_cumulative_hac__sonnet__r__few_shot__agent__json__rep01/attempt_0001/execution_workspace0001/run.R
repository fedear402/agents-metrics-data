library(jsonlite)

data <- read.csv("input.csv")
data <- data[order(as.Date(data$date)), ]

data$log_sales <- log(data$sales)
data$log_vix <- log(data$vix)
data$vix_change <- c(NA, diff(data$log_vix))

# Create 15 lags of vix_change
for (k in 1:15) {
  data[[paste0("lag_", k)]] <- c(rep(NA, k), head(data$vix_change, -k))
}

lag_cols <- paste0("lag_", 1:15)
complete_cols <- c("log_sales", lag_cols)
sample <- data[complete.cases(data[, complete_cols]), ]

N <- nrow(sample)
cat("N =", N, "\n")

formula <- as.formula(paste("log_sales ~", paste(lag_cols, collapse = "+")))
fit <- lm(formula, data = sample)
coefficients <- coef(fit)

X <- model.matrix(fit)
residuals <- residuals(fit)
scores <- X * residuals

hac_lags <- 15
meat <- crossprod(scores)
for (j in seq_len(hac_lags)) {
  w <- 1 - j / (hac_lags + 1)
  lag_product <- crossprod(scores[(j+1):N, , drop=FALSE], scores[1:(N-j), , drop=FALSE])
  meat <- meat + w * (lag_product + t(lag_product))
}

bread <- solve(crossprod(X))
p <- ncol(X)  # 16 (intercept + 15 lags)
covariance <- N / (N - p) * bread %*% meat %*% bread

# Cumulative response: sum of lag_1 through lag_15
contrast <- c(0, rep(1, 15))
cumulative <- sum(contrast * coefficients)
cumulative_se <- sqrt(drop(t(contrast) %*% covariance %*% contrast))

lag1_idx <- 2
lag15_idx <- 16
lag1_coef <- coefficients[lag1_idx]
lag1_se <- sqrt(covariance[lag1_idx, lag1_idx])
lag15_coef <- coefficients[lag15_idx]
lag15_se <- sqrt(covariance[lag15_idx, lag15_idx])

cat("cumulative_response:", cumulative, "se:", cumulative_se, "\n")
cat("lag_1:", lag1_coef, "se:", lag1_se, "\n")
cat("lag_15:", lag15_coef, "se:", lag15_se, "\n")
cat("N:", N, "\n")

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(term = "cumulative_response", estimate = unname(cumulative), se = unname(cumulative_se), n_obs = as.integer(N)),
    list(term = "lag_1", estimate = unname(lag1_coef), se = unname(lag1_se), n_obs = as.integer(N)),
    list(term = "lag_15", estimate = unname(lag15_coef), se = unname(lag15_se), n_obs = as.integer(N))
  ),
  method_metadata = list(estimator = "OLS", vcov = "Newey-West HAC, Bartlett kernel, max lag 15, correction N/(N-16)"),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
cat("Done. result.json written.\n")
