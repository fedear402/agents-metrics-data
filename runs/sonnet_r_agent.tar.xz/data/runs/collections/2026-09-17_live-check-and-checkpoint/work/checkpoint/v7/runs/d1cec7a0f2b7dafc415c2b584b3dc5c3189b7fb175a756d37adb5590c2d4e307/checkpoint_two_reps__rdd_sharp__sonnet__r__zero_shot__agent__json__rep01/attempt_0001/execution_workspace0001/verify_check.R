# Independent verification: fit left and right sides separately
dat <- read.csv("input.csv")
cutoff <- 0; h <- 0.5

in_bw <- abs(dat$z - cutoff) <= h
dat_bw <- dat[in_bw, ]
dat_bw$w <- 1 - abs(dat_bw$z - cutoff) / h
dat_bw$z_c <- dat_bw$z - cutoff

left  <- dat_bw[dat_bw$z < cutoff, ]
right <- dat_bw[dat_bw$z >= cutoff, ]

fit_L <- lm(y ~ z_c, data = left,  weights = w)
fit_R <- lm(y ~ z_c, data = right, weights = w)

int_L <- coef(fit_L)["(Intercept)"]
int_R <- coef(fit_R)["(Intercept)"]
late_check <- int_R - int_L

cat("Intercept left:", int_L, "\n")
cat("Intercept right:", int_R, "\n")
cat("LATE (right - left):", late_check, "\n")
cat("n left:", nrow(left), "  n right:", nrow(right), "\n")
