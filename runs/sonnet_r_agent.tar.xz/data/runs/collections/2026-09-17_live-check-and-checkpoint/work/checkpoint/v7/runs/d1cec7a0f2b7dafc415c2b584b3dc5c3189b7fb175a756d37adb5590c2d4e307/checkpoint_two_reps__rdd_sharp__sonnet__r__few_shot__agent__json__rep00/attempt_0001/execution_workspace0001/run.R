library(jsonlite)

df <- read.csv("./input.csv")

h <- 0.5
cutoff <- 0

# Triangular kernel weights
df$w <- (1 - abs(df$z) / h)

# Restrict to bandwidth
df_bw <- df[abs(df$z) <= h, ]

# Left side: z < cutoff
df_left <- df_bw[df_bw$z < cutoff, ]
# Right side: z >= cutoff
df_right <- df_bw[df_bw$z >= cutoff, ]

# Local linear on left side
fit_left <- lm(y ~ z, data = df_left, weights = w)
# Local linear on right side
fit_right <- lm(y ~ z, data = df_right, weights = w)

intercept_left <- coef(fit_left)[["(Intercept)"]]
intercept_right <- coef(fit_right)[["(Intercept)"]]

late <- intercept_right - intercept_left

n_obs <- nrow(df_left) + nrow(df_right)

# SE via delta method / combined regression approach
# Fit combined model with indicator for right side and interaction
df_bw2 <- df_bw
df_bw2$above <- as.integer(df_bw2$z >= cutoff)
df_bw2$z_centered <- df_bw2$z  # already centered at 0
df_bw2$z_above <- df_bw2$z_centered * df_bw2$above

fit_combined <- lm(y ~ z_centered + above + z_above, data = df_bw2, weights = w)
# 'above' coefficient = difference in intercepts = LATE
late_check <- coef(fit_combined)[["above"]]
se_late <- sqrt(vcov(fit_combined)["above", "above"])

cat("Late (separate):", late, "\n")
cat("Late (combined):", late_check, "\n")
cat("SE:", se_late, "\n")
cat("N obs:", n_obs, "\n")

out <- list(
  task_id = "rdd_sharp",
  platform = "r",
  estimates = list(
    list(term = "late", estimate = late_check, se = se_late, n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "local linear RDD, triangular kernel, h=0.5",
    vcov = "OLS standard errors from combined regression"
  ),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "./result.json", auto_unbox = TRUE, digits = 10)
cat("Done.\n")
