library(AER)
library(sandwich)
library(lmtest)
library(jsonlite)

df <- read.csv("./input.csv")

# 2SLS: y_iv ~ x1_iv | z (with intercept)
fit <- ivreg(y_iv ~ x1_iv | z, data = df)

# HC1 robust standard errors
vcov_hc1 <- vcovHC(fit, type = "HC1")
ct <- coeftest(fit, vcov = vcov_hc1)

n_obs <- nrow(df)
est_const <- ct["(Intercept)", "Estimate"]
se_const  <- ct["(Intercept)", "Std. Error"]
est_x1iv  <- ct["x1_iv", "Estimate"]
se_x1iv   <- ct["x1_iv", "Std. Error"]

out <- list(
  task_id = "iv2sls_robust",
  platform = "r",
  estimates = list(
    list(term = "const",  estimate = est_const, se = se_const,  n_obs = n_obs),
    list(term = "x1_iv",  estimate = est_x1iv,  se = se_x1iv,   n_obs = n_obs)
  ),
  method_metadata = list(estimator = "2SLS via AER::ivreg", vcov = "HC1"),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "./result.json", auto_unbox = TRUE, digits = 10)
