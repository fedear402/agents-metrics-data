library(AER)
library(sandwich)
library(lmtest)
library(jsonlite)

dat <- read.csv("input.csv")

# 2SLS: y_iv ~ x1_iv | z (instrument)
iv_fit <- ivreg(y_iv ~ x1_iv | z, data = dat)

n_obs <- nobs(iv_fit)

# HC1 robust standard errors
vcov_hc1 <- vcovHC(iv_fit, type = "HC1")
ct <- coeftest(iv_fit, vcov = vcov_hc1)

# Extract estimates
coef_names <- rownames(ct)
# Map (Intercept) -> const
term_map <- c("(Intercept)" = "const", "x1_iv" = "x1_iv")

estimates <- list()
for (orig in names(term_map)) {
  mapped <- term_map[[orig]]
  est <- ct[orig, "Estimate"]
  se  <- ct[orig, "Std. Error"]
  estimates[[length(estimates)+1]] <- list(
    term    = mapped,
    estimate = round(est, 10),
    se      = round(se, 10),
    n_obs   = n_obs
  )
}

result <- list(
  task_id  = "iv2sls_robust",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "AER::ivreg 2SLS",
    vcov      = "sandwich::vcovHC HC1"
  ),
  diagnostics = list()
)

write(toJSON(result, auto_unbox = TRUE, digits = 10), "result.json")
cat("Done. n_obs =", n_obs, "\n")
print(ct)
