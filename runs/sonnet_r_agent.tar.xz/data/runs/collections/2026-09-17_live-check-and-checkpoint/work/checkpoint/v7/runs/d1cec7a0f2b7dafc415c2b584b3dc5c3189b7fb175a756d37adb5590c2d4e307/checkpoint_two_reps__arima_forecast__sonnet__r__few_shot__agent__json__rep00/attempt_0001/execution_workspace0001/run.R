library(forecast)
library(jsonlite)

dat <- read.csv("./input.csv")
y <- dat$y
n <- length(y)

# Fit ARIMA(1,1,1) with no constant/drift
fit <- Arima(y, order = c(1, 1, 1), include.constant = FALSE, method = "ML")

# One-step-ahead forecast for t=251
fc <- forecast(fit, h = 1, level = 95)

fc_val    <- as.numeric(fc$mean[1])
lower_val <- as.numeric(fc$lower[1, 1])
upper_val <- as.numeric(fc$upper[1, 1])

# 1-step ahead SE = sqrt(sigma^2) for ARIMA(1,1,1)
se_val <- sqrt(fit$sigma2)

cat("AR1 coef:", coef(fit)["ar1"], "\n")
cat("MA1 coef:", coef(fit)["ma1"], "\n")
cat("Sigma^2:", fit$sigma2, "\n")
cat("SE (sqrt sigma2):", se_val, "\n")
cat("Forecast:", fc_val, "\n")
cat("Lower 95%:", lower_val, "\n")
cat("Upper 95%:", upper_val, "\n")
cat("PI check lower:", fc_val - 1.959964 * se_val, "\n")
cat("PI check upper:", fc_val + 1.959964 * se_val, "\n")
cat("N obs:", n, "\n")

# Independent manual forecast check
phi   <- coef(fit)["ar1"]
theta <- coef(fit)["ma1"]
resid_vals <- residuals(fit)
delta_y250 <- y[250] - y[249]
eps250 <- resid_vals[250]
fc_check <- y[250] + phi * delta_y250 + theta * eps250
cat("Manual forecast check:", fc_check, "\n")
cat("Discrepancy:", abs(fc_val - fc_check), "\n")

out <- list(
  task_id  = "arima_forecast",
  platform = "r",
  estimates = list(
    list(term = "forecast",  estimate = fc_val,    se = se_val, n_obs = n),
    list(term = "lower_95",  estimate = lower_val, se = NA_real_, n_obs = n),
    list(term = "upper_95",  estimate = upper_val, se = NA_real_, n_obs = n)
  ),
  method_metadata = list(
    estimator = "ARIMA(1,1,1) by ML, no constant",
    vcov      = "ML asymptotic"
  ),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "./result.json", auto_unbox = TRUE, digits = 10, na = "null")
