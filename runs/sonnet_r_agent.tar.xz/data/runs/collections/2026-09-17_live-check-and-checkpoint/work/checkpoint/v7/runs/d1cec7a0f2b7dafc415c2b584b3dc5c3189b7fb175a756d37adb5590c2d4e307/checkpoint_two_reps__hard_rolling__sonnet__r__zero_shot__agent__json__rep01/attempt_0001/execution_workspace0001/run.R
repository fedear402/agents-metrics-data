library(jsonlite)

# Load and sort data
data <- read.csv("input.csv")
data <- data[order(data$time), ]

y <- data$y
n <- nrow(data)  # should be 250

forecasts <- numeric(150)
forecast_times <- 101:250

for (f in forecast_times) {
  # Use observations y_(f-100),...,y_(f-1): indices f-100 to f-1
  # Regression pairs: s = f-99,...,f-1 (99 pairs)
  # y_s = a + b*y_(s-1)
  # s goes from f-99 to f-1, so y_(s-1) goes from y_(f-100) to y_(f-2)
  
  y_response <- y[(f-99):(f-1)]      # y_s for s = f-99,...,f-1 (length 99)
  y_predictor <- y[(f-100):(f-2)]    # y_(s-1) for s = f-99,...,f-1 (length 99)
  
  fit <- lm(y_response ~ y_predictor)
  a_hat <- coef(fit)[1]
  b_hat <- coef(fit)[2]
  
  forecasts[f - 100] <- a_hat + b_hat * y[f-1]
}

# Actual y values for times 101:250
y_actual <- y[101:250]

# RMSE
rmse <- sqrt(sum((y_actual - forecasts)^2) / 150)

# Build result
estimates <- list(
  list(term = "rmse", estimate = rmse, se = NULL, n_obs = 150L),
  list(term = "forecast_101", estimate = forecasts[1], se = NULL, n_obs = 99L),
  list(term = "forecast_150", estimate = forecasts[50], se = NULL, n_obs = 99L),
  list(term = "forecast_200", estimate = forecasts[100], se = NULL, n_obs = 99L),
  list(term = "forecast_250", estimate = forecasts[150], se = NULL, n_obs = 99L)
)

result <- list(
  task_id = "hard_rolling",
  platform = "r",
  estimates = estimates,
  method_metadata = list(estimator = "OLS AR(1) rolling window", vcov = "none"),
  diagnostics = list()
)

write(toJSON(result, auto_unbox = TRUE, digits = 10, null = "null"), "result.json")

cat("RMSE:", rmse, "\n")
cat("forecast_101:", forecasts[1], "\n")
cat("forecast_150:", forecasts[50], "\n")
cat("forecast_200:", forecasts[100], "\n")
cat("forecast_250:", forecasts[150], "\n")
