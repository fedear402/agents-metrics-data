library(nnet)
library(jsonlite)

d <- read.csv("input.csv")
d$y <- factor(d$y, levels=0:2)

fit <- multinom(y ~ x + z, data=d, Hess=TRUE, trace=FALSE, maxit=2000, reltol=1e-14)

B <- coef(fit)
V <- vcov(fit)

# B rows: "1", "2"; cols: "(Intercept)", "x", "z"
# V: rows/cols named like "1:(Intercept)", "1:x", "1:z", "2:(Intercept)", "2:x", "2:z"

x_cat1  <- B["1","x"]
z_cat1  <- B["1","z"]
x_cat2  <- B["2","x"]
z_cat2  <- B["2","z"]

se_x_cat1 <- sqrt(V["1:x","1:x"])
se_z_cat1 <- sqrt(V["1:z","1:z"])
se_x_cat2 <- sqrt(V["2:x","2:x"])
se_z_cat2 <- sqrt(V["2:z","2:z"])

# prob_cat2 at x=0, z=0: use only intercepts
int0 <- 0
int1 <- B["1","(Intercept)"]
int2 <- B["2","(Intercept)"]
indices <- c(int0, int1, int2)
probs <- exp(indices - max(indices)) / sum(exp(indices - max(indices)))
prob_cat2_zero <- probs[3]

n <- nrow(d)

estimates <- list(
  list(term="x_cat1",       estimate=unname(x_cat1),       se=unname(se_x_cat1), n_obs=n),
  list(term="z_cat1",       estimate=unname(z_cat1),       se=unname(se_z_cat1), n_obs=n),
  list(term="x_cat2",       estimate=unname(x_cat2),       se=unname(se_x_cat2), n_obs=n),
  list(term="z_cat2",       estimate=unname(z_cat2),       se=unname(se_z_cat2), n_obs=n),
  list(term="prob_cat2_zero", estimate=unname(prob_cat2_zero), se=NULL, n_obs=n)
)

result <- list(
  task_id="broad_multinomial_logit",
  platform="r",
  estimates=estimates,
  method_metadata=list(estimator="multinomial logit (nnet::multinom)", vcov="observed information (Hessian)"),
  diagnostics=list()
)

write_json(result, "result.json", auto_unbox=TRUE, null="null", digits=16, pretty=TRUE)
cat("Done\n")
print(B)
print(prob_cat2_zero)
