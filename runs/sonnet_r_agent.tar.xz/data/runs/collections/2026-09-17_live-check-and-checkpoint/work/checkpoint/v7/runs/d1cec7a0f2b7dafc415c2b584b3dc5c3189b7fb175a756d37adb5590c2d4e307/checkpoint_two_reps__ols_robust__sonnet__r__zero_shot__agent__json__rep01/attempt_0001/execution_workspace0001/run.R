library(sandwich)
library(lmtest)
library(jsonlite)

dat <- read.csv("input.csv")

# OLS regression
model <- lm(y_lin ~ x1 + x2, data = dat)

# HC1 robust covariance matrix
vcov_hc1 <- vcovHC(model, type = "HC1")
ct <- coeftest(model, vcov = vcov_hc1)

n_obs <- nobs(model)
coefs <- ct[, 1]
ses   <- ct[, 2]

estimates <- list(
  list(term = "const", estimate = unname(coefs["(Intercept)"]), se = unname(ses["(Intercept)"]), n_obs = n_obs),
  list(term = "x1",    estimate = unname(coefs["x1"]),          se = unname(ses["x1"]),          n_obs = n_obs),
  list(term = "x2",    estimate = unname(coefs["x2"]),          se = unname(ses["x2"]),          n_obs = n_obs)
)

result <- list(
  task_id  = "ols_robust",
  platform = "r",
  estimates = estimates,
  method_metadata = list(estimator = "OLS", vcov = "HC1"),
  diagnostics = setNames(list(), character(0))
)

write(toJSON(result, auto_unbox = TRUE, digits = 10), "result.json")
cat("Done\n")
print(ct)
