library(forecast)
library(jsonlite)

df <- read.csv("input.csv")
y  <- df$y
n  <- length(y)

fit <- Arima(y, order = c(1, 1, 1), include.constant = FALSE, method = "ML")
fc  <- forecast(fit, h = 1, level = 95)

forecast_val <- as.numeric(fc$mean[1])
lower_val    <- as.numeric(fc$lower[1, "95%"])
upper_val    <- as.numeric(fc$upper[1, "95%"])

cat("AR1 coef:", coef(fit)["ar1"], "\n")
cat("MA1 coef:", coef(fit)["ma1"], "\n")
cat("Forecast:", forecast_val, "\n")
cat("Lower 95:", lower_val, "\n")
cat("Upper 95:", upper_val, "\n")
cat("N obs:", n, "\n")

out <- list(
  task_id  = "arima_forecast",
  platform = "r",
  estimates = list(
    list(term = "forecast",  estimate = forecast_val, se = NA_real_, n_obs = n),
    list(term = "lower_95",  estimate = lower_val,    se = NA_real_, n_obs = n),
    list(term = "upper_95",  estimate = upper_val,    se = NA_real_, n_obs = n)
  ),
  method_metadata = list(
    estimator = "ARIMA(1,1,1) by ML, no constant",
    vcov      = "MLE"
  ),
  diagnostics = structure(list(), names = character(0))
)

write_json(out, "result.json", auto_unbox = TRUE, digits = 10, na = "null")
