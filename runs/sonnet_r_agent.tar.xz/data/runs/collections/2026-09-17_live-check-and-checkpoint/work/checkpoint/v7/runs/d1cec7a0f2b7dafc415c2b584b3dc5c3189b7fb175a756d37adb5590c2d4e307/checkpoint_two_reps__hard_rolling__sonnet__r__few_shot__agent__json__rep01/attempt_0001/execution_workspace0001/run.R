library(jsonlite)

data <- read.csv("input.csv")
data <- data[order(data$time),]
stopifnot(nrow(data) == 250)
stopifnot(all(data$time == 1:250))

forecast_times <- 101:250
forecasts <- numeric(length(forecast_times))

for (i in seq_along(forecast_times)) {
  f <- forecast_times[i]
  # Use y_(f-100) through y_(f-1): 100 levels
  idx <- (f-100):(f-1)
  levels <- data$y[idx]
  # 99 regression pairs
  lagged <- head(levels, -1)
  current <- tail(levels, -1)
  fit <- lm(current ~ lagged)
  stopifnot(length(current) == 99)
  forecasts[i] <- coef(fit)[1] + coef(fit)[2] * tail(levels, 1)
}

actual <- data$y[forecast_times]
rmse <- sqrt(mean((actual - forecasts)^2))
stopifnot(length(actual) == 150)

row <- function(term, estimate, se=NULL, n_obs) {
  list(term=term, estimate=unname(as.numeric(estimate)),
       se=if (is.null(se)) NULL else unname(as.numeric(se)), n_obs=as.integer(n_obs))
}

report_times <- c(101, 150, 200, 250)
estimates <- list(row("rmse", rmse, NULL, 150L))
for (ft in report_times) {
  idx <- ft - 100  # position in forecast_times (1-based)
  estimates[[length(estimates)+1]] <- row(paste0("forecast_", ft), forecasts[idx], NULL, 99L)
}

result <- list(
  task_id = "hard_rolling",
  platform = "r",
  estimates = estimates,
  method_metadata = list(estimator = "OLS AR(1) rolling window", vcov = "none"),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox=TRUE, null="null", digits=16, pretty=TRUE)
cat("Done. RMSE =", rmse, "\n")
