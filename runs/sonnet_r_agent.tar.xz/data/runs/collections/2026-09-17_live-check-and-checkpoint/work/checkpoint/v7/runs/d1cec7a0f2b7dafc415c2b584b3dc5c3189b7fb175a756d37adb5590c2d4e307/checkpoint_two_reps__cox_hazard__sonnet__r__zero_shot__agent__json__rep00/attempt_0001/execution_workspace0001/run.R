library(survival)
library(jsonlite)

dat <- read.csv("input.csv")

fit <- coxph(Surv(t_obs, event) ~ treat + x, data = dat, ties = "efron")

s <- summary(fit)
coef_table <- s$coefficients

treat_est <- coef_table["treat", "coef"]
treat_se  <- coef_table["treat", "se(coef)"]
x_est     <- coef_table["x", "coef"]
x_se      <- coef_table["x", "se(coef)"]
n_obs     <- fit$n

result <- list(
  task_id  = "cox_hazard",
  platform = "r",
  estimates = list(
    list(term = "treat", estimate = treat_est, se = treat_se, n_obs = n_obs),
    list(term = "x",     estimate = x_est,     se = x_se,     n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "Cox proportional hazards (coxph, Efron ties)",
    vcov      = "model-based (Fisher information)"
  ),
  diagnostics = setNames(list(), character(0))
)

write(toJSON(result, auto_unbox = TRUE, digits = 10), "result.json")
cat("Done.\n")
print(coef_table[, c("coef","se(coef)","z","Pr(>|z|)")])
