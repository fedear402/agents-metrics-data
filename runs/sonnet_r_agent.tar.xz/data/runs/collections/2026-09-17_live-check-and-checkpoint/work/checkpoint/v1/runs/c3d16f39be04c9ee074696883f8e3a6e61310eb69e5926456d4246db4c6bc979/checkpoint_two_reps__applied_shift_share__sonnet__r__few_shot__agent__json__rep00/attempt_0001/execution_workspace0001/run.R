library(jsonlite)

d <- read.csv("input.csv")

# One row per region for regional-level variables
regions <- unique(d$region_id)
region_df <- do.call(rbind, lapply(regions, function(r) {
  sub <- d[d$region_id == r, ]
  data.frame(
    region_id = r,
    region_weight = sub$region_weight[1],
    x = sub$x[1],
    y = sub$y[1],
    z = sum(sub$share * sub$shock)
  )
}))

# Normalize regional weights
region_df$e <- region_df$region_weight / sum(region_df$region_weight)

# Weighted means
wmean <- function(v, w) sum(w * v)
ym <- wmean(region_df$y, region_df$e)
xm <- wmean(region_df$x, region_df$e)
zm <- wmean(region_df$z, region_df$e)

# Demeaned regional variables
region_df$y0 <- region_df$y - ym
region_df$x0 <- region_df$x - xm
region_df$z0 <- region_df$z - zm

# Industry exposure masses s_n
industries <- unique(d$industry_id)
N <- length(industries)

# Merge e_r into data
d$e <- region_df$e[match(d$region_id, region_df$region_id)]

shock_df <- do.call(rbind, lapply(industries, function(n) {
  sub <- d[d$industry_id == n, ]
  s_n <- sum(sub$e * sub$share)
  # Aggregate demeaned regional residuals
  y0_r <- region_df$y0[match(sub$region_id, region_df$region_id)]
  x0_r <- region_df$x0[match(sub$region_id, region_df$region_id)]
  z0_r <- region_df$z0[match(sub$region_id, region_df$region_id)]
  ybar <- sum(sub$e * sub$share * y0_r) / s_n
  xbar <- sum(sub$e * sub$share * x0_r) / s_n
  zbar <- sum(sub$e * sub$share * z0_r) / s_n
  shock_n <- sub$shock[1]
  data.frame(industry_id=n, s_n=s_n, ybar=ybar, xbar=xbar, zbar=zbar, shock=shock_n)
}))

# Shock-level IV regression: ybar ~ 1 + xbar, instrument=shock, weights=s_n
# Slope equals regional 2SLS slope
shock_iv <- function(dependent, endogenous, instrument, weights, N) {
  regressors <- cbind(1, endogenous)
  instruments <- cbind(1, instrument)
  cross <- crossprod(instruments, weights * regressors)
  beta <- solve(cross, crossprod(instruments, weights * dependent))
  residual <- drop(dependent - regressors %*% beta)
  scores <- instruments * (weights * residual)
  inverse <- solve(cross)
  # HC1 with multiplier N/(N-2)
  covariance <- N / (N - 2) * inverse %*% crossprod(scores) %*% t(inverse)
  c(slope = beta[2], se = sqrt(covariance[2, 2]))
}

s <- shock_df$s_n

# Effect: ybar ~ xbar, instrument=shock
effect <- shock_iv(shock_df$ybar, shock_df$xbar, shock_df$shock, s, N)

# First stage: xbar ~ zbar, instrument=shock (zbar is endogenous)
first_stage <- shock_iv(shock_df$xbar, shock_df$zbar, shock_df$shock, s, N)

# Effective shocks
effective_shocks <- 1 / sum(s^2)

# Verification: regional 2SLS slope
reg_effect <- sum(region_df$e * region_df$z0 * region_df$y0) / sum(region_df$e * region_df$z0 * region_df$x0)
reg_fs <- sum(region_df$e * region_df$z0 * region_df$x0) / sum(region_df$e * region_df$z0^2)
cat("Regional 2SLS slope:", reg_effect, "\n")
cat("Shock-level IV slope:", effect["slope"], "\n")
cat("Regional first-stage:", reg_fs, "\n")
cat("Shock-level first-stage:", first_stage["slope"], "\n")
cat("Match effect:", isTRUE(all.equal(reg_effect, effect["slope"])), "\n")
cat("Match FS:", isTRUE(all.equal(reg_fs, first_stage["slope"])), "\n")

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = unname(effect["slope"]), se = unname(effect["se"]), n_obs = N),
    list(term = "first_stage", estimate = unname(first_stage["slope"]), se = unname(first_stage["se"]), n_obs = N),
    list(term = "effective_shocks", estimate = effective_shocks, se = NULL, n_obs = N)
  ),
  method_metadata = list(estimator = "shock_level_IV", vcov = "HC1_N_over_Nminus2"),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
cat("Done. result.json written.\n")
