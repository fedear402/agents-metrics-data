library(survival)
library(jsonlite)

d <- read.csv("input.csv")
n <- nrow(d)

# Left-censored Tobit: y is censored at 0 (y=0 means latent y* <= 0)
# Surv with type="left": event indicator is (y > 0), censoring at 0
fit <- survreg(Surv(y, y > 0, type = "left") ~ x + z,
               data = d, dist = "gaussian",
               control = survreg.control(rel.tolerance = 1e-12))

V <- vcov(fit)
coefs <- coef(fit)

const_est <- unname(coefs["(Intercept)"])
x_est     <- unname(coefs["x"])
z_est     <- unname(coefs["z"])
sigma_est <- unname(fit$scale)

const_se <- sqrt(V["(Intercept)", "(Intercept)"])
x_se     <- sqrt(V["x", "x"])
z_se     <- sqrt(V["z", "z"])

cat("Intercept:", const_est, "SE:", const_se, "\n")
cat("x:", x_est, "SE:", x_se, "\n")
cat("z:", z_est, "SE:", z_se, "\n")
cat("sigma:", sigma_est, "\n")
cat("n:", n, "\n")

result <- list(
  task_id = "broad_tobit",
  platform = "r",
  estimates = list(
    list(term = "const",  estimate = const_est, se = const_se, n_obs = n),
    list(term = "x",      estimate = x_est,     se = x_se,     n_obs = n),
    list(term = "z",      estimate = z_est,     se = z_se,     n_obs = n),
    list(term = "sigma",  estimate = sigma_est, se = NULL,      n_obs = n)
  ),
  method_metadata = list(
    estimator = "survreg Gaussian left-censored Tobit MLE",
    vcov = "observed information (survreg vcov)"
  ),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
cat("result.json written.\n")
