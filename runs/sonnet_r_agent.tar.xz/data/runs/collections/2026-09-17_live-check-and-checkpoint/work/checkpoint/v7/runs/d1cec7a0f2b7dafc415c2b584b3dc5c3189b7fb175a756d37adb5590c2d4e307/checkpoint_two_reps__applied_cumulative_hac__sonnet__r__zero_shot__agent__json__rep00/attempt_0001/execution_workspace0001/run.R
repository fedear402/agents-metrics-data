library(sandwich)
library(jsonlite)

# Load and sort data
df <- read.csv("input.csv")
df$date <- as.Date(df$date)
df <- df[order(df$date), ]

# Compute log variables
df$log_sales <- log(df$sales)
df$log_vix <- log(df$vix)

# First difference of log(vix) - consecutive trading observations
n <- nrow(df)
df$d_log_vix <- c(NA, diff(df$log_vix))

# Create lagged differences (lags 1 through 15)
for (k in 1:15) {
  df[[paste0("lag_", k)]] <- c(rep(NA, k), df$d_log_vix[1:(n - k)])
}

# Keep complete cases (obs with all 15 lags available)
lag_cols <- paste0("lag_", 1:15)
complete_idx <- complete.cases(df[, c("log_sales", lag_cols)])
df_reg <- df[complete_idx, ]
N <- nrow(df_reg)
cat("N obs:", N, "\n")

# OLS regression
formula_str <- paste("log_sales ~", paste(lag_cols, collapse = " + "))
model <- lm(as.formula(formula_str), data = df_reg)
coefs <- coef(model)
cat("Coefficients:\n")
print(coefs)

# Newey-West HAC with max lag 15, Bartlett weights 1 - j/16
# sandwich::NeweyWest with prewhite=FALSE, adjust=FALSE, then manually scale
# Default Bartlett: w(j) = 1 - j/(lag+1) where lag=15 means w(j)=1-j/16 ✓
# sandwich::NeweyWest uses bwNeweyWest or fixed bandwidth
# We need to use fixed bandwidth = 15 with Bartlett kernel

# Using vcovHAC with custom weights
nw_vcov_raw <- NeweyWest(model, lag = 15, prewhite = FALSE, adjust = FALSE)

# Scale by N/(N-16)
scale_factor <- N / (N - 16)
nw_vcov <- nw_vcov_raw * scale_factor

cat("Scale factor:", scale_factor, "\n")

# Extract individual SEs
se_all <- sqrt(diag(nw_vcov))

# Cumulative response: sum of lag_1 through lag_15 coefficients
lag_names <- paste0("lag_", 1:15)
cum_response <- sum(coefs[lag_names])

# SE for cumulative response using delta method: se = sqrt(1'V1) where 1 is vector of ones
# for the lag coefficients
idx <- match(lag_names, names(coefs))
V_lags <- nw_vcov[idx, idx]
ones <- rep(1, 15)
var_cum <- as.numeric(t(ones) %*% V_lags %*% ones)
se_cum <- sqrt(var_cum)

cat("Cumulative response:", cum_response, "\n")
cat("SE cumulative:", se_cum, "\n")
cat("lag_1 coef:", coefs["lag_1"], "SE:", se_all["lag_1"], "\n")
cat("lag_15 coef:", coefs["lag_15"], "SE:", se_all["lag_15"], "\n")

# Build result
result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(term = "cumulative_response", estimate = cum_response, se = se_cum, n_obs = N),
    list(term = "lag_1", estimate = unname(coefs["lag_1"]), se = unname(se_all["lag_1"]), n_obs = N),
    list(term = "lag_15", estimate = unname(coefs["lag_15"]), se = unname(se_all["lag_15"]), n_obs = N)
  ),
  method_metadata = list(
    estimator = "OLS",
    vcov = "Newey-West HAC, max lag 15, Bartlett weights 1-j/16, scaled N/(N-16)"
  ),
  diagnostics = list()
)

write(toJSON(result, auto_unbox = TRUE, digits = 10), "result.json")
cat("Done. result.json written.\n")
