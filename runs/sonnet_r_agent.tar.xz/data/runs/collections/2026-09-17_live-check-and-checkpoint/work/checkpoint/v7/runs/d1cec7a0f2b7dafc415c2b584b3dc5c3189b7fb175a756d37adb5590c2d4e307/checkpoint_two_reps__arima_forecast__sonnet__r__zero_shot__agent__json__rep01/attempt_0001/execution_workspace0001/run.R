library(forecast)
library(jsonlite)

# Read data
dat <- read.csv("input.csv")
y <- dat$y
n <- length(y)

# Fit ARIMA(1,1,1) with no constant (include.constant=FALSE)
fit <- Arima(y, order=c(1,1,1), include.constant=FALSE, method="ML")

# Summary
cat("Coefficients:\n")
print(coef(fit))
cat("Log-likelihood:", fit$loglik, "\n")
cat("n_obs:", n, "\n")

# One-step-ahead forecast for t=251
fc <- forecast(fit, h=1, level=95)
forecast_val <- as.numeric(fc$mean)
lower_val    <- as.numeric(fc$lower[1, "95%"])
upper_val    <- as.numeric(fc$upper[1, "95%"])

cat("Forecast:", forecast_val, "\n")
cat("Lower 95%:", lower_val, "\n")
cat("Upper 95%:", upper_val, "\n")

# Build result
result <- list(
  task_id  = "arima_forecast",
  platform = "r",
  estimates = list(
    list(term="forecast", estimate=forecast_val, se=NULL, n_obs=n),
    list(term="lower_95", estimate=lower_val,    se=NULL, n_obs=n),
    list(term="upper_95", estimate=upper_val,    se=NULL, n_obs=n)
  ),
  method_metadata = list(
    estimator = "ARIMA(1,1,1) ML via forecast::Arima, no constant",
    vcov      = "none"
  ),
  diagnostics = list()
)

write(toJSON(result, auto_unbox=TRUE, digits=10, null="null"),
      file="result.json")
cat("result.json written\n")
