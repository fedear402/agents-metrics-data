library(jsonlite)

d <- read.csv("input.csv")

cohorts <- c(4, 6, 8)
never   <- d[d$cohort == -1, ]

# Pre-compute never-treated means by year
nt_means <- tapply(never$y_did, never$year, mean)

att_cells <- numeric(0)

for (g in cohorts) {
  g_data     <- d[d$cohort == g, ]
  g_pre_mean <- mean(g_data$y_did[g_data$year == (g - 1)])
  nt_pre_mean <- nt_means[as.character(g - 1)]
  
  post_years <- (g):9
  for (t in post_years) {
    g_t_mean  <- mean(g_data$y_did[g_data$year == t])
    nt_t_mean <- nt_means[as.character(t)]
    
    att_gt <- (g_t_mean - g_pre_mean) - (nt_t_mean - nt_pre_mean)
    att_cells <- c(att_cells, att_gt)
  }
}

att_uniform <- mean(att_cells)
n_cells <- length(att_cells)
cat("Number of (g,t) cells:", n_cells, "\n")
cat("ATT_uniform:", att_uniform, "\n")

# n_obs: total firm-year obs in the treated cohorts post-treatment
treated_post_obs <- sum(d$cohort %in% cohorts & d$year >= d$cohort)
cat("Treated post obs:", treated_post_obs, "\n")

result <- list(
  task_id  = "staggered_did",
  platform = "r",
  estimates = list(
    list(term = "att", estimate = att_uniform, se = NULL, n_obs = treated_post_obs)
  ),
  method_metadata = list(
    estimator = "ATT_uniform_group_year_means",
    vcov      = "null"
  ),
  diagnostics = setNames(list(), character(0))
)

write(toJSON(result, auto_unbox = TRUE, null = "null", digits = 10), "result.json")
cat("result.json written.\n")
