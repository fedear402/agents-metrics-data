library(sandwich)
library(jsonlite)

# Load data
dat <- read.csv("input.csv")

# Apply bandwidth filter: abs(score) < 1
bw <- dat[abs(dat$score) < 1, ]
n_obs <- nrow(bw)

# Triangular weights
bw$w <- 1 - abs(bw$score)

# Create treatment indicator (right of cutoff)
bw$D <- as.integer(bw$score >= 0)

# Local linear regression: separate slopes on each side
# X matrix: intercept, D (right side indicator), score, D*score
# This gives: left intercept, right-left intercept jump, left slope, right-left slope jump
bw$score_D <- bw$score * bw$D

# Design matrix
X <- cbind(1, bw$D, bw$score, bw$score_D)

# WLS fit for earnings (reduced form)
W <- diag(bw$w)
XtW <- t(X) %*% W
XtWX <- XtW %*% X
XtWX_inv <- solve(XtWX)

# Earnings
XtWy_earn <- XtW %*% bw$earnings
beta_earn <- XtWX_inv %*% XtWy_earn
resid_earn <- bw$earnings - X %*% beta_earn

# HC0 sandwich covariance for earnings
# Meat: sum_i w_i^2 * e_i^2 * x_i x_i'
# But since we're using WLS with weights w_i:
# bread = (X'WX)^{-1}
# meat = X' W diag(e^2) W X  (HC0, no df correction)
# Actually, for WLS with triangular weights treated as fixed:
# The score equation is w_i * x_i * e_i
# So meat = sum_i (w_i * x_i * e_i)^2 outer product
WX <- W %*% X
We <- bw$w * as.vector(resid_earn)
meat_earn <- t(WX * We) %*% (WX * We)  # wrong

# Let me redo: each row contribution is w_i * x_i * e_i
# meat = sum_i (w_i e_i)^2 x_i x_i'
score_earn <- sweep(X, 1, bw$w * as.vector(resid_earn), "*")
meat_earn <- t(score_earn) %*% score_earn
vcov_earn <- XtWX_inv %*% meat_earn %*% XtWX_inv

# Participation (first stage)
XtWy_part <- XtW %*% bw$participated
beta_part <- XtWX_inv %*% XtWy_part
resid_part <- bw$participated - X %*% beta_part

score_part <- sweep(X, 1, bw$w * as.vector(resid_part), "*")
meat_part <- t(score_part) %*% score_part
vcov_part <- XtWX_inv %*% meat_part %*% XtWX_inv

# Cross-covariance (for delta method on ratio)
meat_cross <- t(score_earn) %*% score_part
vcov_cross <- XtWX_inv %*% meat_cross %*% XtWX_inv

# Discontinuity estimates are the coefficient on D (index 2, i.e., beta[2])
rf_est <- beta_earn[2]
fs_est <- beta_part[2]
te_est <- rf_est / fs_est

# Standard errors
se_rf <- sqrt(vcov_earn[2, 2])
se_fs <- sqrt(vcov_part[2, 2])

# Delta method for treatment effect = rf/fs
# Var(rf/fs) = (1/fs)^2 * Var(rf) + (rf/fs^2)^2 * Var(fs) - 2*(rf/fs^3)*Cov(rf,fs)
cov_rf_fs <- vcov_cross[2, 2]
var_te <- (1/fs_est)^2 * vcov_earn[2,2] + 
          (rf_est/fs_est^2)^2 * vcov_part[2,2] - 
          2 * (rf_est/fs_est^3) * cov_rf_fs
se_te <- sqrt(var_te)

cat("n_obs:", n_obs, "\n")
cat("reduced_form:", rf_est, "se:", se_rf, "\n")
cat("first_stage:", fs_est, "se:", se_fs, "\n")
cat("treatment_effect:", te_est, "se:", se_te, "\n")
cat("cov_rf_fs:", cov_rf_fs, "\n")

# Write result.json
result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = as.numeric(te_est), se = as.numeric(se_te), n_obs = n_obs),
    list(term = "reduced_form", estimate = as.numeric(rf_est), se = as.numeric(se_rf), n_obs = n_obs),
    list(term = "first_stage", estimate = as.numeric(fs_est), se = as.numeric(se_fs), n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "fuzzy_rd_local_linear_wls",
    vcov = "HC0_sandwich_no_df_correction"
  ),
  diagnostics = list()
)

write(toJSON(result, auto_unbox = TRUE, digits = 10), "result.json")
cat("Done. result.json written.\n")
