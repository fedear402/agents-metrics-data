library(AER)
library(sandwich)
library(lmtest)
library(jsonlite)

d <- read.csv("input.csv")

# --- Regional data (one obs per region) ---
reg <- unique(d[, c("region_id","region_weight","x","y")])
reg <- reg[order(reg$region_id), ]

# Normalize weights
reg$e_r <- reg$region_weight / sum(reg$region_weight)

# Construct shift-share instrument z_r = sum_n share_rn * shock_n
shock_map <- unique(d[, c("industry_id","shock")])
z_vec <- tapply(seq_len(nrow(d)), d$region_id, function(idx) {
  sum(d$share[idx] * d$shock[idx])
})
reg$z_r <- z_vec[as.character(reg$region_id)]

# --- Weighted 2SLS: y_r ~ x_r, instrument z_r, weights e_r ---
iv_reg <- ivreg(y ~ x_r | z_r, data = data.frame(y = reg$y, x_r = reg$x, z_r = reg$z_r),
                weights = reg$e_r)
beta_2sls <- coef(iv_reg)["x_r"]

# --- Shock-level aggregation for exposure-robust SE ---
N_ind <- length(unique(d$industry_id))

# Weighted means
wmean <- function(v, w) sum(v * w) / sum(w)

e_r <- reg$e_r
xr  <- reg$x
yr  <- reg$y
zr  <- reg$z_r

# Demean each variable by e_r-weighted mean
x0 <- xr - wmean(xr, e_r)
y0 <- yr - wmean(yr, e_r)
z0 <- zr - wmean(zr, e_r)

# Industry-level aggregation
industries <- unique(d$industry_id)
N <- length(industries)

# For each industry n: s_n = sum_r e_r * share_rn
# vbar_n = sum_r e_r * share_rn * v0_r / s_n

# Map region e_r onto d
e_r_map <- setNames(e_r, reg$region_id)
x0_map  <- setNames(x0,  reg$region_id)
y0_map  <- setNames(y0,  reg$region_id)
z0_map  <- setNames(z0,  reg$region_id)

d$e_r  <- e_r_map[as.character(d$region_id)]
d$x0_r <- x0_map[as.character(d$region_id)]
d$y0_r <- y0_map[as.character(d$region_id)]
d$z0_r <- z0_map[as.character(d$region_id)]

d$ew <- d$e_r * d$share  # e_r * share_rn

agg <- lapply(industries, function(n) {
  sub <- d[d$industry_id == n, ]
  sn  <- sum(sub$ew)
  xbar <- sum(sub$ew * sub$x0_r) / sn
  ybar <- sum(sub$ew * sub$y0_r) / sn
  zbar <- sum(sub$ew * sub$z0_r) / sn
  shock_n <- sub$shock[1]
  list(industry = n, sn = sn, xbar = xbar, ybar = ybar, zbar = zbar, shock = shock_n)
})

shock_df <- do.call(rbind.data.frame, agg)
names(shock_df) <- c("industry","sn","xbar","ybar","zbar","shock")
shock_df$sn    <- as.numeric(shock_df$sn)
shock_df$xbar  <- as.numeric(shock_df$xbar)
shock_df$ybar  <- as.numeric(shock_df$ybar)
shock_df$zbar  <- as.numeric(shock_df$zbar)
shock_df$shock <- as.numeric(shock_df$shock)

# Shock-level IV for effect: ybar ~ xbar, instrument shock, weights sn
# HC1 with N/(N-2) multiplier
iv_shock_effect <- ivreg(ybar ~ xbar | shock, data = shock_df, weights = sn)
beta_effect <- coef(iv_shock_effect)["xbar"]

# HC1 SE: sandwich with HC1 (uses (N-1)/N correction, then multiply by sqrt(N/(N-2)) adjustment)
# AER ivreg with sandwich vcovHC HC1
vc_effect <- vcovHC(iv_shock_effect, type = "HC1")
# HC1 uses N/(N-K) = N/(N-2), same as what we want
se_effect <- sqrt(vc_effect["xbar","xbar"])

# Shock-level IV for first_stage: xbar ~ zbar, instrument shock, weights sn
iv_shock_fs <- ivreg(xbar ~ zbar | shock, data = shock_df, weights = sn)
beta_fs <- coef(iv_shock_fs)["zbar"]
vc_fs <- vcovHC(iv_shock_fs, type = "HC1")
se_fs <- sqrt(vc_fs["zbar","zbar"])

# Effective shocks
eff_shocks <- 1 / sum(shock_df$sn^2)

cat("2SLS effect:", beta_effect, "SE:", se_effect, "\n")
cat("First stage:", beta_fs, "SE:", se_fs, "\n")
cat("Effective shocks:", eff_shocks, "\n")
cat("N industries:", N, "\n")

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect",          estimate = unname(beta_effect), se = unname(se_effect), n_obs = N),
    list(term = "first_stage",     estimate = unname(beta_fs),     se = unname(se_fs),     n_obs = N),
    list(term = "effective_shocks",estimate = eff_shocks,          se = NULL,               n_obs = N)
  ),
  method_metadata = list(
    estimator = "2SLS shift-share with Borusyak-Hull-Jaravel shock-level exposure-robust SE",
    vcov = "HC1 heteroskedasticity-robust (shock-level aggregation)"
  ),
  diagnostics = list()
)

write(toJSON(result, auto_unbox = TRUE, digits = 10, null = "null"), "result.json")
cat("result.json written\n")
