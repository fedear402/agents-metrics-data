d <- read.csv("input.csv")
n <- nrow(d)
# p = 4 (intercept, x, z1, z2), q = 2 excluded instruments
q <- 2L
df <- n - 4L  # n - p

critical <- qf(0.95, q, df)
k <- q * critical / df

# Residuals from restricted model: y ~ intercept + x
ry <- residuals(lm(y ~ x, data = d))
rd <- residuals(lm(endog ~ x, data = d))

# Residuals from unrestricted model: y ~ intercept + x + z1 + z2
uy <- residuals(lm(y ~ x + z1 + z2, data = d))
ud <- residuals(lm(endog ~ x + z1 + z2, data = d))

# AR quadratic: A*beta^2 + B*beta + C <= 0 means accept
A <- sum(rd^2) - (1 + k) * sum(ud^2)
B <- -2 * (sum(ry * rd) - (1 + k) * sum(uy * ud))
C <- sum(ry^2) - (1 + k) * sum(uy^2)

cat("A =", A, "\nB =", B, "\nC =", C, "\n")
cat("Discriminant =", B^2 - 4*A*C, "\n")

stopifnot(abs(A) > 1e-10, B^2 - 4*A*C > 0)

bounds <- sort(Re(polyroot(c(C, B, A))))
cat("Boundary low:", bounds[1], "\nBoundary high:", bounds[2], "\n")

accepts <- function(beta) A * beta^2 + B * beta + C <= 0
unbounded <- as.integer(A < 0)
accepts_zero <- as.integer(accepts(0))

cat("Accepts zero:", accepts_zero, "\nUnbounded:", unbounded, "\n")

# Verify boundaries using F test directly
for (b in bounds) {
  transformed <- d$y - b * d$endog
  restricted_fit <- lm(transformed ~ x, data = d)
  full_fit <- lm(transformed ~ x + z1 + z2, data = d)
  F_val <- ((deviance(restricted_fit) - deviance(full_fit)) / q) / (deviance(full_fit) / df)
  cat("At boundary", b, "F =", F_val, "critical =", critical, "diff =", abs(F_val - critical), "\n")
}

# Compute F at beta = 1
beta1 <- 1.0
transformed1 <- d$y - beta1 * d$endog
restricted1 <- lm(transformed1 ~ x, data = d)
full1 <- lm(transformed1 ~ x + z1 + z2, data = d)
ar_f_at_one <- ((deviance(restricted1) - deviance(full1)) / q) / (deviance(full1) / df)
cat("AR F at beta=1:", ar_f_at_one, "\n")

# Also verify using quadratic formula
ar_f_quad <- (A * beta1^2 + B * beta1 + C) / (sum(ud^2) / df) * df / q
# Actually compute directly from definition
ry1 <- ry - 1 * rd
uy1 <- uy - 1 * ud
SSR_R1 <- sum(ry1^2); SSR_U1 <- sum(uy1^2)
ar_f_check <- ((SSR_R1 - SSR_U1) / q) / (SSR_U1 / df)
cat("AR F at beta=1 (check):", ar_f_check, "\n")

library(jsonlite)
rows <- list(
  list(term = "boundary_low",   estimate = unname(bounds[1]),   se = NULL, n_obs = n),
  list(term = "boundary_high",  estimate = unname(bounds[2]),   se = NULL, n_obs = n),
  list(term = "accepts_zero",   estimate = unname(accepts_zero), se = NULL, n_obs = n),
  list(term = "unbounded",      estimate = unname(unbounded),   se = NULL, n_obs = n),
  list(term = "ar_f_at_one",    estimate = unname(ar_f_at_one), se = NULL, n_obs = n)
)

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = rows,
  method_metadata = list(estimator = "Anderson-Rubin", vcov = "homoskedastic"),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
cat("Done. result.json written.\n")
