library(MASS)
library(jsonlite)

data <- read.csv("input.csv")
data$y <- factor(data$y, levels = c(1, 2, 3), ordered = TRUE)

n_obs <- nrow(data)

model <- polr(y ~ x + z, data = data, method = "logistic", Hess = TRUE)

s <- summary(model)
coef_table <- s$coefficients

x_est <- coef_table["x", "Value"]
x_se  <- coef_table["x", "Std. Error"]
z_est <- coef_table["z", "Value"]
z_se  <- coef_table["z", "Std. Error"]

newdata <- data.frame(x = 1, z = 0)
probs <- predict(model, newdata = newdata, type = "probs")
cat("probs structure:\n")
print(probs)
prob_high <- probs["3"]

cat("x estimate:", x_est, "\n")
cat("x se:", x_se, "\n")
cat("z estimate:", z_est, "\n")
cat("z se:", z_se, "\n")
cat("prob_high:", prob_high, "\n")
cat("n_obs:", n_obs, "\n")
cat("Cutpoints:\n")
print(model$zeta)

result <- list(
  task_id = "broad_ordered_logit",
  platform = "r",
  estimates = list(
    list(term = "x", estimate = x_est, se = x_se, n_obs = n_obs),
    list(term = "z", estimate = z_est, se = z_se, n_obs = n_obs),
    list(term = "prob_high", estimate = prob_high, se = NULL, n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "ordered_logit_polr",
    vcov = "observed_information"
  ),
  diagnostics = list()
)

write(toJSON(result, auto_unbox = TRUE, digits = 10, null = "null"), "result.json")
cat("Done. result.json written.\n")
