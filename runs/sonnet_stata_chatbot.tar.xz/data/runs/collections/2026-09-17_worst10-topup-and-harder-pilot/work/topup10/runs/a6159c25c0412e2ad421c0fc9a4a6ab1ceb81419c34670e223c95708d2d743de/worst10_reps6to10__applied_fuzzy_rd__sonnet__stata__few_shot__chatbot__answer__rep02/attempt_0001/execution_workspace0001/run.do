version 16
clear all
set more off
set linesize 255

import delimited "./input.csv", clear

keep if abs(score) < 1
gen weight = 1 - abs(score)
gen above = (score >= 0)
gen score_low = score * (1 - above)
gen score_high = score * above

mata:
    y = st_data(., "earnings")
    d = st_data(., "participated")
    w = st_data(., "weight")
    above = st_data(., "above")
    score_low = st_data(., "score_low")
    score_high = st_data(., "score_high")
    
    n = rows(y)
    X = (J(n,1,1), above, score_low, score_high)
    
    WX = w :* X
    bread = invsym(X' * WX)
    
    coef_y = bread * (WX' * y)
    coef_d = bread * (WX' * d)
    
    resid_y = y - X * coef_y
    resid_d = d - X * coef_d
    
    // contrast selects the "above" coefficient = right limit minus left limit
    contrast = (0 \ 1 \ 0 \ 0)
    
    jump_y = (contrast' * coef_y)[1,1]
    jump_d = (contrast' * coef_d)[1,1]
    
    loading = w :* (X * bread * contrast)
    
    inf_y = loading :* resid_y
    inf_d = loading :* resid_d
    
    V_yy = (inf_y' * inf_y)[1,1]
    V_dd = (inf_d' * inf_d)[1,1]
    V_yd = (inf_y' * inf_d)[1,1]
    
    se_y = sqrt(V_yy)
    se_d = sqrt(V_dd)
    
    ratio = jump_y / jump_d
    grad = (1/jump_d \ -jump_y/jump_d^2)
    joint = (V_yy, V_yd \ V_yd, V_dd)
    se_ratio = sqrt((grad' * joint * grad)[1,1])
    
    st_numscalar("est_rf", jump_y)
    st_numscalar("se_rf", se_y)
    st_numscalar("est_fs", jump_d)
    st_numscalar("se_fs", se_d)
    st_numscalar("est_te", ratio)
    st_numscalar("se_te", se_ratio)
    st_numscalar("nobs", n)
end

display "ANSWER: treatment_effect estimate=" %21.12f est_te " se=" %21.12f se_te " n_obs=" %12.0f nobs
display "ANSWER: reduced_form estimate=" %21.12f est_rf " se=" %21.12f se_rf " n_obs=" %12.0f nobs
display "ANSWER: first_stage estimate=" %21.12f est_fs " se=" %21.12f se_fs " n_obs=" %12.0f nobs
