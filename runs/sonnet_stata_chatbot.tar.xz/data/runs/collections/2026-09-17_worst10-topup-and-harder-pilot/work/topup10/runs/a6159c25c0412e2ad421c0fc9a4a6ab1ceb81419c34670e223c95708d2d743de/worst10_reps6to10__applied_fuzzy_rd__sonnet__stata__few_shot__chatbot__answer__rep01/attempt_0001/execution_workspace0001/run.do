version 17.0
clear all
set more off
set linesize 255

import delimited "./input.csv", clear

keep if abs(score) < 1
gen w = 1 - abs(score)
gen above = (score >= 0)
gen score_above = score * above
gen score_below = score * (1 - above)

mata:
    st_view(Y=., ., ("earnings", "participated"))
    st_view(X=., ., ("w"))
    above = st_data(., "above")
    score = st_data(., "score")
    w = st_data(., "w")
    n = rows(Y)
    
    // Design matrix: intercept_low, slope_low, intercept_high, slope_high
    // intercept_low = 1-above, slope_low = score*(1-above), intercept_high = above, slope_high = score*above
    Xmat = ((1:-above), score:*(1:-above), above, score:*above)
    
    // WLS
    Xw = w :* Xmat
    XwX = Xw' * Xmat
    XwXinv = invsym(XwX)
    
    coef = XwXinv * (Xw' * Y)
    
    resid = Y - Xmat * coef
    
    // Contrast: right intercept minus left intercept = [0,0,1,0] - [1,0,0,0] = [-1,0,1,0]
    contrast = (-1 \ 0 \ 1 \ 0)
    
    jumps = contrast' * coef
    
    // Influence functions
    loading = w :* (Xmat * XwXinv * contrast)
    influence = loading :* resid
    
    // Joint sandwich covariance
    joint = influence' * influence
    
    // Estimates
    rf = jumps[1]
    fs = jumps[2]
    te = rf / fs
    
    // Delta method gradient for ratio
    grad = (1/fs \ -rf/fs^2)
    te_var = grad' * joint * grad
    te_se = sqrt(te_var)
    
    rf_se = sqrt(joint[1,1])
    fs_se = sqrt(joint[2,2])
    
    nobs = n
    
    st_numscalar("te_est", te)
    st_numscalar("te_se", te_se)
    st_numscalar("rf_est", rf)
    st_numscalar("rf_se", rf_se)
    st_numscalar("fs_est", fs)
    st_numscalar("fs_se", fs_se)
    st_numscalar("nobs", nobs)
end

display "ANSWER: treatment_effect estimate=" %21.12f te_est " se=" %21.12f te_se " n_obs=" %12.0f nobs
display "ANSWER: reduced_form estimate=" %21.12f rf_est " se=" %21.12f rf_se " n_obs=" %12.0f nobs
display "ANSWER: first_stage estimate=" %21.12f fs_est " se=" %21.12f fs_se " n_obs=" %12.0f nobs
