set linesize 255
import delimited "./input.csv", clear

gen log_sales = ln(sales)
gen log_vix = ln(vix)

sort date

gen d_log_vix = log_vix - log_vix[_n-1]

forvalues k = 1/15 {
    gen d_log_vix_lag`k' = d_log_vix[_n-`k']
}

regress log_sales d_log_vix_lag1 d_log_vix_lag2 d_log_vix_lag3 d_log_vix_lag4 d_log_vix_lag5 d_log_vix_lag6 d_log_vix_lag7 d_log_vix_lag8 d_log_vix_lag9 d_log_vix_lag10 d_log_vix_lag11 d_log_vix_lag12 d_log_vix_lag13 d_log_vix_lag14 d_log_vix_lag15

scalar N = e(N)

* Store coefficients
scalar b1  = _b[d_log_vix_lag1]
scalar b2  = _b[d_log_vix_lag2]
scalar b3  = _b[d_log_vix_lag3]
scalar b4  = _b[d_log_vix_lag4]
scalar b5  = _b[d_log_vix_lag5]
scalar b6  = _b[d_log_vix_lag6]
scalar b7  = _b[d_log_vix_lag7]
scalar b8  = _b[d_log_vix_lag8]
scalar b9  = _b[d_log_vix_lag9]
scalar b10 = _b[d_log_vix_lag10]
scalar b11 = _b[d_log_vix_lag11]
scalar b12 = _b[d_log_vix_lag12]
scalar b13 = _b[d_log_vix_lag13]
scalar b14 = _b[d_log_vix_lag14]
scalar b15 = _b[d_log_vix_lag15]

scalar cum_resp = b1+b2+b3+b4+b5+b6+b7+b8+b9+b10+b11+b12+b13+b14+b15

* Newey-West with lag 15
newey log_sales d_log_vix_lag1 d_log_vix_lag2 d_log_vix_lag3 d_log_vix_lag4 d_log_vix_lag5 d_log_vix_lag6 d_log_vix_lag7 d_log_vix_lag8 d_log_vix_lag9 d_log_vix_lag10 d_log_vix_lag11 d_log_vix_lag12 d_log_vix_lag13 d_log_vix_lag14 d_log_vix_lag15, lag(15)

* Get the Newey-West covariance matrix and scale by N/(N-16)
matrix V_nw = e(V)
scalar scale = N / (N - 16)
matrix V = V_nw * scale

* SE for lag_1 and lag_15
scalar se_lag1  = sqrt(V[1,1])
scalar se_lag15 = sqrt(V[15,15])

* SE for cumulative response: sum of all lag coefficients (indices 1-15)
* V is 16x16 (15 lags + intercept), lags are indices 1-15
scalar var_cum = 0
forvalues i = 1/15 {
    forvalues j = 1/15 {
        scalar var_cum = var_cum + V[`i',`j']
    }
}
scalar se_cum = sqrt(var_cum)

display "ANSWER: cumulative_response estimate=" %21.12f cum_resp " se=" %21.12f se_cum " n_obs=" %12.0f N
display "ANSWER: lag_1 estimate=" %21.12f b1 " se=" %21.12f se_lag1 " n_obs=" %12.0f N
display "ANSWER: lag_15 estimate=" %21.12f b15 " se=" %21.12f se_lag15 " n_obs=" %12.0f N
