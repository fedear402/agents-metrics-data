version 17
clear all
set more off
set linesize 255

import delimited "./input.csv", clear

keep if abs(score) < 1
gen w = 1 - abs(score)
gen above = (score >= 0)

mata:
    score = st_data(., "score")
    above = st_data(., "above")
    w = st_data(., "w")
    earnings = st_data(., "earnings")
    participated = st_data(., "participated")
    
    n = rows(score)
    
    // Design matrix: intercept_low, slope_low, intercept_high, slope_high
    // intercept_low = 1 if below, intercept_high = 1 if above
    // slope_low = score if below, slope_high = score if above
    X = J(n, 4, 0)
    for (i=1; i<=n; i++) {
        if (above[i] == 0) {
            X[i,1] = 1
            X[i,2] = score[i]
        } else {
            X[i,3] = 1
            X[i,4] = score[i]
        }
    }
    
    Y = (earnings, participated)
    
    bread = invsym(X' * (w :* X))
    coefs = bread * X' * (w :* Y)
    resid = Y - X * coefs
    
    // Discontinuity contrast: right intercept minus left intercept
    // coef[3] - coef[1]
    contrast = (-1 \ 0 \ 1 \ 0)
    
    jumps = contrast' * coefs
    
    loading = w :* (X * bread * contrast)
    influence = loading :* resid
    
    joint = influence' * influence
    
    gradient = (1/jumps[2] \ -jumps[1]/jumps[2]^2)
    ratio_se = sqrt(gradient' * joint * gradient)
    
    rf_est = jumps[1]
    fs_est = jumps[2]
    te_est = jumps[1] / jumps[2]
    
    rf_se = sqrt(joint[1,1])
    fs_se = sqrt(joint[2,2])
    
    st_numscalar("rf_est", rf_est)
    st_numscalar("fs_est", fs_est)
    st_numscalar("te_est", te_est)
    st_numscalar("rf_se", rf_se)
    st_numscalar("fs_se", fs_se)
    st_numscalar("te_se", ratio_se)
    st_numscalar("n_obs", n)
end

display "ANSWER: treatment_effect estimate=" %21.12f te_est " se=" %21.12f te_se " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f rf_est " se=" %21.12f rf_se " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f fs_est " se=" %21.12f fs_se " n_obs=" %12.0f n_obs
