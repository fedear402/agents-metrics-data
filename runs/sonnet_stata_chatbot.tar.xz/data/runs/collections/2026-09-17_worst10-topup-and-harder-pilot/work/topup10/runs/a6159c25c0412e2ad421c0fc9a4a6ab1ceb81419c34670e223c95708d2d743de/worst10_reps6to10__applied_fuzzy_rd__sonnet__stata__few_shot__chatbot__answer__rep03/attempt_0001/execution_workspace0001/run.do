version 16
clear all
set more off
set linesize 255

import delimited "./input.csv", clear

keep if abs(score) < 1

gen w = 1 - abs(score)
gen above = (score >= 0)
gen score_left = score * (1 - above)
gen score_right = score * above

mata:
    st_view(Y=., ., ("earnings", "participated"))
    st_view(X=., ., ("above", "score_left", "score_right"))
    w = st_data(., "w")
    n = rows(Y)
    Xf = (J(n,1,1), X)
    
    WX = w :* Xf
    bread = invsym(Xf' * WX)
    coef = bread * (WX' * Y)
    resid = Y - Xf * coef
    
    // contrast selects right intercept minus left intercept = above coefficient
    contrast = (0 \ 1 \ 0 \ 0)
    jumps = contrast' * coef
    
    loading = w :* (Xf * bread * contrast)
    influence = loading :* resid
    
    joint = influence' * influence
    
    rf = jumps[1]
    fs = jumps[2]
    se_rf = sqrt(joint[1,1])
    se_fs = sqrt(joint[2,2])
    cov12 = joint[1,2]
    
    te = rf / fs
    grad = (1/fs \ -rf/fs^2)
    se_te = sqrt(grad' * joint * grad)
    
    st_numscalar("rf_est", rf)
    st_numscalar("rf_se", se_rf)
    st_numscalar("fs_est", fs)
    st_numscalar("fs_se", se_fs)
    st_numscalar("te_est", te)
    st_numscalar("te_se", se_te)
    st_numscalar("nobs", n)
end

display "ANSWER: treatment_effect estimate=" %21.12f te_est " se=" %21.12f te_se " n_obs=" %12.0f nobs
display "ANSWER: reduced_form estimate=" %21.12f rf_est " se=" %21.12f rf_se " n_obs=" %12.0f nobs
display "ANSWER: first_stage estimate=" %21.12f fs_est " se=" %21.12f fs_se " n_obs=" %12.0f nobs
