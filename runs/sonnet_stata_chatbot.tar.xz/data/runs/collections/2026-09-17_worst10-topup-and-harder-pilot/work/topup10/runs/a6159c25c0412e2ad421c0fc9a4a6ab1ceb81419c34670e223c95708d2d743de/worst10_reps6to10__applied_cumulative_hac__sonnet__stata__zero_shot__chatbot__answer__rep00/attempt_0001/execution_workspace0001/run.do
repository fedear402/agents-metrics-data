set linesize 255
import delimited "./input.csv", clear

gen log_sales = ln(sales)
gen log_vix = ln(vix)
sort date
gen d_log_vix = log_vix - log_vix[_n-1]

forvalues j = 1/15 {
    gen d_log_vix_lag`j' = d_log_vix[_n-`j']
}

reg log_sales d_log_vix_lag1-d_log_vix_lag15
scalar N = e(N)

newey log_sales d_log_vix_lag1-d_log_vix_lag15, lag(15)

scalar N2 = e(N)
matrix b = e(b)
matrix V = e(V)

scalar factor = N2 / (N2 - 16)
matrix V_adj = V * factor

scalar cum_resp = 0
forvalues j = 1/15 {
    scalar cum_resp = cum_resp + b[1, `j']
}

scalar se_lag1 = sqrt(V_adj[1,1])
scalar se_lag15 = sqrt(V_adj[15,15])

matrix ones = J(1,16,0)
forvalues j = 1/15 {
    matrix ones[1,`j'] = 1
}

matrix var_cum = ones * V_adj * ones'
scalar se_cum = sqrt(var_cum[1,1])

scalar est_lag1 = b[1,1]
scalar est_lag15 = b[1,15]

display "ANSWER: cumulative_response estimate=" %21.12f cum_resp " se=" %21.12f se_cum " n_obs=" %12.0f N2
display "ANSWER: lag_1 estimate=" %21.12f est_lag1 " se=" %21.12f se_lag1 " n_obs=" %12.0f N2
display "ANSWER: lag_15 estimate=" %21.12f est_lag15 " se=" %21.12f se_lag15 " n_obs=" %12.0f N2
