set linesize 255
import delimited "./input.csv", clear

gen date_d = date(date, "YMD")
sort date_d

gen ln_sales = ln(sales)
gen ln_vix = ln(vix)
gen d_ln_vix = ln_vix - ln_vix[_n-1]

forvalues k = 1/15 {
    gen d_ln_vix_lag`k' = d_ln_vix[_n-`k']
}

reg ln_sales d_ln_vix_lag1-d_ln_vix_lag15

scalar N = e(N)

newey ln_sales d_ln_vix_lag1-d_ln_vix_lag15, lag(15)

scalar N2 = e(N)

* Get the coefficient vector and covariance matrix
matrix b = e(b)
matrix V = e(V)

* Multiply V by N/(N-16)
scalar adj = N2 / (N2 - 16)
matrix V_adj = V * adj

* Coefficients for lag_1 and lag_15
scalar b_lag1 = b[1,1]
scalar b_lag15 = b[1,15]

* Standard errors for lag_1 and lag_15
scalar se_lag1 = sqrt(V_adj[1,1])
scalar se_lag15 = sqrt(V_adj[15,15])

* Cumulative response: sum of all 15 lag coefficients
* Create a row vector of ones (1x15) to sum coefficients
matrix L = J(1, 15, 1)
* Append zero for constant
matrix L_full = L, 0

scalar cum_resp = 0
forvalues k = 1/15 {
    scalar cum_resp = cum_resp + b[1,`k']
}

* Variance of cumulative response using full covariance matrix
* Only need 15x15 submatrix (exclude constant)
matrix V15 = V_adj[1..15, 1..15]
matrix L15 = J(1, 15, 1)
matrix var_cum = L15 * V15 * L15'
scalar se_cum = sqrt(var_cum[1,1])

display "ANSWER: cumulative_response estimate=" %21.12f cum_resp " se=" %21.12f se_cum " n_obs=" %12.0f N2
display "ANSWER: lag_1 estimate=" %21.12f b_lag1 " se=" %21.12f se_lag1 " n_obs=" %12.0f N2
display "ANSWER: lag_15 estimate=" %21.12f b_lag15 " se=" %21.12f se_lag15 " n_obs=" %12.0f N2
