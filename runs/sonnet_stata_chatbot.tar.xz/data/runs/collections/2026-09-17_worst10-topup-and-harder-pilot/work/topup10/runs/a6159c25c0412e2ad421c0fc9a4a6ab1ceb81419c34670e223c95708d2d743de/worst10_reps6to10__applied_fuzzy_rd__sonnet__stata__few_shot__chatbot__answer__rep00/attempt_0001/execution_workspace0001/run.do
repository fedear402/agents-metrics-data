version 16
clear all
set more off
set linesize 255

import delimited "./input.csv", clear

keep if abs(score) < 1
gen w = 1 - abs(score)
gen above = (score >= 0)

mata:
    st_view(score=., ., "score")
    st_view(w=., ., "w")
    st_view(above=., ., "above")
    earned = st_data(., "earnings")
    part = st_data(., "participated")
    
    n = rows(score)
    
    // Design matrix: intercept_left, slope_left, intercept_right, slope_right
    // but parameterized as: 1, score, above, above*score
    X = J(n, 4, 0)
    X[.,1] = J(n,1,1)
    X[.,2] = score
    X[.,3] = above
    X[.,4] = above :* score
    
    Y = (earned, part)
    
    Xw = w :* X
    bread = invsym(X' * Xw)
    coef = bread * (Xw' * Y)
    
    resid = Y - X * coef
    
    // Contrast for right minus left limit at score=0:
    // right limit: coef[1] + coef[3] (intercept + above indicator)
    // left limit: coef[1]
    // difference: coef[3], so contrast = (0, 0, 1, 0)
    contrast = (0 \ 0 \ 1 \ 0)
    
    jumps = contrast' * coef
    
    loading = w :* (X * bread * contrast)
    influence = loading :* resid
    
    joint = influence' * influence
    
    rf_est = jumps[1,1]
    fs_est = jumps[1,2]
    rf_se = sqrt(joint[1,1])
    fs_se = sqrt(joint[2,2])
    cov12 = joint[1,2]
    
    te_est = rf_est / fs_est
    gradient = (1/fs_est \ -rf_est/fs_est^2)
    te_se = sqrt(gradient' * joint * gradient)
    
    st_numscalar("rf_est", rf_est)
    st_numscalar("rf_se", rf_se)
    st_numscalar("fs_est", fs_est)
    st_numscalar("fs_se", fs_se)
    st_numscalar("te_est", te_est)
    st_numscalar("te_se", te_se)
    st_numscalar("n_obs", n)
end

display "ANSWER: treatment_effect estimate=" %21.12f te_est " se=" %21.12f te_se " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f rf_est " se=" %21.12f rf_se " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f fs_est " se=" %21.12f fs_se " n_obs=" %12.0f n_obs
