set linesize 255
import delimited "./input.csv", clear

gen date2 = date(date, "YMD")
sort date2

gen ln_sales = ln(sales)
gen ln_vix = ln(vix)
gen d_ln_vix = ln_vix - ln_vix[_n-1]

forvalues j = 1/15 {
    gen d_ln_vix_lag`j' = d_ln_vix[_n-`j']
}

reg ln_sales d_ln_vix_lag1-d_ln_vix_lag15

scalar N = e(N)

newey ln_sales d_ln_vix_lag1-d_ln_vix_lag15, lag(15)

scalar N2 = e(N)

matrix V = e(V)
matrix V_adj = V * (N2 / (N2 - 16))

scalar b1 = _b[d_ln_vix_lag1]
scalar b15 = _b[d_ln_vix_lag15]

scalar cum_resp = 0
forvalues j = 1/15 {
    scalar cum_resp = cum_resp + _b[d_ln_vix_lag`j']
}

scalar se1 = sqrt(V_adj[1,1])
scalar se15 = sqrt(V_adj[15,15])

scalar var_cum = 0
forvalues i = 1/15 {
    forvalues j = 1/15 {
        scalar var_cum = var_cum + V_adj[`i',`j']
    }
}
scalar se_cum = sqrt(var_cum)

display "ANSWER: cumulative_response estimate=" %21.12f cum_resp " se=" %21.12f se_cum " n_obs=" %12.0f N2
display "ANSWER: lag_1 estimate=" %21.12f b1 " se=" %21.12f se1 " n_obs=" %12.0f N2
display "ANSWER: lag_15 estimate=" %21.12f b15 " se=" %21.12f se15 " n_obs=" %12.0f N2
