clear all
set more off
set linesize 255
set type double

import delimited "./input.csv", clear

quietly regress y
predict double ry, residuals
quietly regress endog
predict double rd, residuals
quietly regress y x z1 z2
predict double uy, residuals
scalar df = e(df_r)
quietly regress endog x z1 z2
predict double ud, residuals

scalar q = 2
scalar n_obs = _N
scalar critical = invFtail(q, df, .05)
scalar k = q * critical / df

mata:
ry = st_data(., "ry")
rd = st_data(., "rd")
uy = st_data(., "uy")
ud = st_data(., "ud")
k = st_numscalar("k")

A = quadcross(rd,rd) - (1+k)*quadcross(ud,ud)
B = -2*(quadcross(ry,rd) - (1+k)*quadcross(uy,ud))
C = quadcross(ry,ry) - (1+k)*quadcross(uy,uy)

disc = B^2 - 4*A*C

if (abs(A) > 1e-10 & disc > 0) {
    b1 = (-B - sqrt(disc)) / (2*A)
    b2 = (-B + sqrt(disc)) / (2*A)
    bounds = sort((b1 \ b2), 1)
    st_numscalar("low", bounds[1])
    st_numscalar("high", bounds[2])
    st_numscalar("unbounded", A < 0)
} else {
    st_numscalar("low", .)
    st_numscalar("high", .)
    st_numscalar("unbounded", .)
}

// accepts_zero: C <= 0 means beta=0 is accepted
st_numscalar("accepts_zero", C <= 0)

// F statistic at beta=1
y_adj = st_data(., "y") - 1 * st_data(., "endog")
// We need to run restricted and unrestricted for beta=1
// SSR_R = residuals from regressing y-endog on intercept,x (restricted: no z1,z2 coeffs)
// SSR_U = residuals from regressing y-endog on intercept,x,z1,z2 (unrestricted)
st_view(y_adj_v=., ., .)
end

quietly {
    gen double y_adj1 = y - 1*endog
    regress y_adj1 x
    scalar SSR_R1 = e(rss)
    scalar df_r1 = e(df_r)
    regress y_adj1 x z1 z2
    scalar SSR_U1 = e(rss)
    scalar df_u1 = e(df_r)
}

scalar ar_f_at_one = ((SSR_R1 - SSR_U1)/q) / (SSR_U1/df_u1)

display "ANSWER: boundary_low estimate=" %21.12f low " se=" %21.12f . " n_obs=" %12.0f n_obs
display "ANSWER: boundary_high estimate=" %21.12f high " se=" %21.12f . " n_obs=" %12.0f n_obs
display "ANSWER: accepts_zero estimate=" %21.12f accepts_zero " se=" %21.12f . " n_obs=" %12.0f n_obs
display "ANSWER: unbounded estimate=" %21.12f unbounded " se=" %21.12f . " n_obs=" %12.0f n_obs
display "ANSWER: ar_f_at_one estimate=" %21.12f ar_f_at_one " se=" %21.12f . " n_obs=" %12.0f n_obs
