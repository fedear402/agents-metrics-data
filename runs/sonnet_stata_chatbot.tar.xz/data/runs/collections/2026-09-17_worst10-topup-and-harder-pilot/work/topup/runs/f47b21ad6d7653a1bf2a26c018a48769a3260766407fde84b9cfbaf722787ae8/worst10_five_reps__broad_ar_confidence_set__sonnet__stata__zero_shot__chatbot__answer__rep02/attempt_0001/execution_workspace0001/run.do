set linesize 255
clear all

import delimited "./input.csv", clear

* Get sample size
quietly count
local n = r(N)

* Critical value: F(2, n-4) at 95th percentile
local df1 = 2
local df2 = `n' - 4
local fcrit = invFtail(`df1', `df2', 0.05)

* Anderson-Rubin: for each beta, regress (y - beta*endog) on intercept, x, z1, z2
* F test of joint significance of z1 and z2 coefficients
* Accept beta if F <= fcrit

* The AR statistic as function of beta:
* Let w = y - beta*endog
* Regress w on 1, x, z1, z2
* F = (RSS_r - RSS_u)/2 / (RSS_u/(n-4))
* where RSS_r is from regressing w on 1, x only
* and RSS_u is from regressing w on 1, x, z1, z2

* Precompute needed quantities using matrix algebra
* y - beta*endog = y - beta*endog
* We need to find the quadratic in beta

* Let's set up matrices
mkmat y endog x z1 z2, matrix(DATA)

matrix Y = DATA[1...,1]
matrix E = DATA[1...,2]
matrix X = DATA[1...,3]
matrix Z1 = DATA[1...,4]
matrix Z2 = DATA[1...,5]

* Create matrices for regressors
* Unrestricted: [1, x, z1, z2]
* Restricted: [1, x]

* Create constant vector
matrix ONES = J(`n', 1, 1)

* Xu = [1, x, z1, z2]
matrix Xu = (ONES, X, Z1, Z2)
* Xr = [1, x]
matrix Xr = (ONES, X)

* Projection matrices
matrix PXu = Xu * invsym(Xu'*Xu) * Xu'
matrix PXr = Xr * invsym(Xr'*Xr) * Xr'
matrix MXu = I(`n') - PXu
matrix MXr = I(`n') - PXr

* w = y - beta*endog = Y - beta*E
* RSS_u = w' MXu w
* RSS_r = w' MXr w

* w = Y - beta*E
* RSS_u = (Y - beta*E)' MXu (Y - beta*E)
*       = Y'MXu Y - 2*beta * Y'MXu E + beta^2 * E'MXu E

* Let Au = Y'MXu Y, Bu = Y'MXu E, Cu = E'MXu E
* RSS_u = Au - 2*beta*Bu + beta^2*Cu

matrix tmp = Y' * MXu * Y
scalar Au = tmp[1,1]
matrix tmp = Y' * MXu * E
scalar Bu = tmp[1,1]
matrix tmp = E' * MXu * E
scalar Cu = tmp[1,1]

matrix tmp = Y' * MXr * Y
scalar Ar = tmp[1,1]
matrix tmp = Y' * MXr * E
scalar Br = tmp[1,1]
matrix tmp = E' * MXr * E
scalar Cr = tmp[1,1]

* RSS_u(beta) = Au - 2*Bu*beta + Cu*beta^2
* RSS_r(beta) = Ar - 2*Br*beta + Cr*beta^2

* F(beta) = (RSS_r - RSS_u) / 2 / (RSS_u / (n-4))
* F(beta) <= fcrit iff
* (RSS_r - RSS_u) * (n-4) <= 2 * fcrit * RSS_u
* (RSS_r - RSS_u) * (n-4) - 2*fcrit*RSS_u <= 0

* Let D(beta) = RSS_r - RSS_u = (Ar-Au) - 2*(Br-Bu)*beta + (Cr-Cu)*beta^2

* Condition: D*(n-4) <= 2*fcrit*RSS_u
* D*(n-4) - 2*fcrit*RSS_u <= 0
* [(Ar-Au) - 2*(Br-Bu)*b + (Cr-Cu)*b^2]*(n-4) - 2*fcrit*[Au - 2*Bu*b + Cu*b^2] <= 0

* Quadratic in beta: A2*b^2 + A1*b + A0 <= 0
scalar A2 = (Cr - Cu)*(`n'-4) - 2*`fcrit'*Cu
scalar A1 = -2*(Br - Bu)*(`n'-4) + 4*`fcrit'*Bu
scalar A0 = (Ar - Au)*(`n'-4) - 2*`fcrit'*Au

* Discriminant
scalar disc = A1^2 - 4*A2*A0

* If A2 > 0: parabola opens upward, CI is between roots (bounded)
* If A2 < 0: parabola opens downward, CI is outside roots (unbounded or all reals)
* If A2 = 0: linear

scalar boundary_low = .
scalar boundary_high = .
scalar unbounded_val = 0

if disc < 0 {
    * No real roots
    if A2 > 0 {
        * Always positive, never accepted -> empty set
        scalar unbounded_val = 0
        scalar boundary_low = .
        scalar boundary_high = .
    }
    else {
        * Always negative, always accepted -> all real line
        scalar unbounded_val = 1
        scalar boundary_low = .
        scalar boundary_high = .
    }
}
else if abs(A2) < 1e-10 {
    * Essentially linear: A1*b + A0 <= 0
    * b <= -A0/A1 if A1 > 0, b >= -A0/A1 if A1 < 0
    scalar unbounded_val = 1
    scalar boundary_low = .
    scalar boundary_high = .
}
else {
    scalar root1 = (-A1 - sqrt(disc)) / (2*A2)
    scalar root2 = (-A1 + sqrt(disc)) / (2*A2)
    scalar rlo = min(root1, root2)
    scalar rhi = max(root1, root2)
    
    if A2 > 0 {
        * CI is [rlo, rhi] - bounded
        scalar boundary_low = rlo
        scalar boundary_high = rhi
        scalar unbounded_val = 0
    }
    else {
        * A2 < 0: CI is (-inf, rlo] union [rhi, +inf) - unbounded
        scalar boundary_low = rlo
        scalar boundary_high = rhi
        scalar unbounded_val = 1
    }
}

* Compute F at beta=0 to check if zero is in CI
scalar rss_u_0 = Au
scalar rss_r_0 = Ar
scalar F_at_0 = (rss_r_0 - rss_u_0) / 2 / (rss_u_0 / (`n'-4))
scalar accepts_zero_val = (F_at_0 <= `fcrit')

* Compute F at beta=1
scalar beta_test = 1
scalar rss_u_1 = Au - 2*Bu*beta_test + Cu*beta_test^2
scalar rss_r_1 = Ar - 2*Br*beta_test + Cr*beta_test^2
scalar ar_f_at_one = (rss_r_1 - rss_u_1) / 2 / (rss_u_1 / (`n'-4))

display "ANSWER: boundary_low estimate=" %21.12f boundary_low " se=" %21.12f . " n_obs=" %12.0f `n'
display "ANSWER: boundary_high estimate=" %21.12f boundary_high " se=" %21.12f . " n_obs=" %12.0f `n'
display "ANSWER: accepts_zero estimate=" %21.12f accepts_zero_val " se=" %21.12f . " n_obs=" %12.0f `n'
display "ANSWER: unbounded estimate=" %21.12f unbounded_val " se=" %21.12f . " n_obs=" %12.0f `n'
display "ANSWER: ar_f_at_one estimate=" %21.12f ar_f_at_one " se=" %21.12f . " n_obs=" %12.0f `n'
