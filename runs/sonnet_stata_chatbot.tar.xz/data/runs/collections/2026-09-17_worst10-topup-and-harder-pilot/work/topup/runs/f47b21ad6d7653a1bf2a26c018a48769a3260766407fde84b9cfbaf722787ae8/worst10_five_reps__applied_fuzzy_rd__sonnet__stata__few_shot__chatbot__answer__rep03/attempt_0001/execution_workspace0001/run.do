version 16
clear all
set more off
set linesize 255

import delimited "./input.csv", clear

keep if abs(score) < 1
gen w = 1 - abs(score)
gen above = (score >= 0)
gen score_low = score * (1 - above)
gen score_high = score * above

count
local n_obs = r(N)

mata:
    st_view(Y=., ., ("earnings","participated"))
    st_view(X=., ., ("above","score_low","score_high"))
    st_view(w=., ., "w")
    
    n = rows(Y)
    Xd = (J(n,1,1), X)
    
    WX = w :* Xd
    bread = invsym(cross(Xd, WX))
    coef = bread * cross(WX, Y)
    resid = Y - Xd * coef
    
    // contrast: selects the coefficient on "above" (index 2)
    contrast = (0 \ 1 \ 0 \ 0)
    
    jumps = contrast' * coef
    
    loading = w :* (Xd * bread * contrast)
    influence = loading :* resid
    
    joint = cross(influence, influence)
    
    jump_earnings = jumps[1,1]
    jump_partic   = jumps[1,2]
    ratio = jump_earnings / jump_partic
    
    gradient = (1/jump_partic \ -jump_earnings/jump_partic^2)
    
    se_rf = sqrt(joint[1,1])
    se_fs = sqrt(joint[2,2])
    se_te = sqrt(gradient' * joint * gradient)
    
    st_numscalar("jump_earnings", jump_earnings)
    st_numscalar("jump_partic",   jump_partic)
    st_numscalar("ratio",         ratio)
    st_numscalar("se_rf",         se_rf)
    st_numscalar("se_fs",         se_fs)
    st_numscalar("se_te",         se_te)
end

display "ANSWER: treatment_effect estimate=" %21.12f ratio " se=" %21.12f se_te " n_obs=" %12.0f `n_obs'
display "ANSWER: reduced_form estimate=" %21.12f jump_earnings " se=" %21.12f se_rf " n_obs=" %12.0f `n_obs'
display "ANSWER: first_stage estimate=" %21.12f jump_partic " se=" %21.12f se_fs " n_obs=" %12.0f `n_obs'
