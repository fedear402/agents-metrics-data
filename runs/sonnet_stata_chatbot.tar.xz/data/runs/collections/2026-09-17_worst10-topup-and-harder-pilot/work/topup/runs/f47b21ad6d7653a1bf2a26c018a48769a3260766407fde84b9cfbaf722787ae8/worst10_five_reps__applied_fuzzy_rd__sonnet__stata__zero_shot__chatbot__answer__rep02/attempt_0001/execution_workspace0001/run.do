set linesize 255
import delimited "./input.csv", clear

* Keep observations within bandwidth
keep if abs(score) < 1

* Count observations
count
scalar n_obs = r(N)

* Generate triangular weights
gen weight = 1 - abs(score)

* Generate indicator for right side (score >= 0)
gen right = (score >= 0)

* Generate interaction terms for local linear regression
gen score_right = score * right
gen score_left = score * (1 - right)

* Stack system: run WLS for earnings (reduced form) and participated (first stage)
* We need joint estimation to get covariance between discontinuity estimates

* For reduced form: regress earnings on right + score_left + score_right with weights
reg earnings right score_left score_right [aw=weight], vce(hc0) nocons

* But we need intercepts on both sides
* Parameterize as: left_intercept + right*disc + score_left*slope_left + score_right*slope_right
* where disc = right limit - left limit (the discontinuity)

* Actually, let's use: intercept_left*(1-right) + intercept_right*right + slope_left*score_left + slope_right*score_right
* Then disc = intercept_right - intercept_left = coefficient on "right"
* We need a left intercept variable
gen left = 1 - right

* Reduced form: earnings
reg earnings left right score_left score_right [aw=weight], vce(hc0) nocons
scalar rf_est = _b[right] - _b[left]
* Need SE of right - left
* Var(right - left) = Var(right) + Var(left) - 2*Cov(right,left)
matrix V_rf = e(V)
scalar var_rf = V_rf[1,1] + V_rf[2,2] - 2*V_rf[1,2]
* Find positions: need to check ordering
* Let's store the estimates
scalar b_right_rf = _b[right]
scalar b_left_rf = _b[left]

* Get variance-covariance
* Columns: left, right, score_left, score_right (alphabetical order in Stata)
* Actually Stata orders by appearance in the regression
* left=1, right=2, score_left=3, score_right=4
matrix V_rf = e(V)
* Check: position of left and right
local pos_left_rf = 0
local pos_right_rf = 0
local names_rf : colnames V_rf
local i = 1
foreach v of local names_rf {
    if "`v'" == "left" local pos_left_rf = `i'
    if "`v'" == "right" local pos_right_rf = `i'
    local i = `i' + 1
}
scalar var_rf = V_rf[`pos_right_rf',`pos_right_rf'] + V_rf[`pos_left_rf',`pos_left_rf'] - 2*V_rf[`pos_right_rf',`pos_left_rf']
scalar se_rf = sqrt(var_rf)
scalar rf_disc = b_right_rf - b_left_rf

* Store full coefficient vector and VCV for joint delta method
matrix b_rf = e(b)
matrix V_full_rf = e(V)

* First stage: participated
reg participated left right score_left score_right [aw=weight], vce(hc0) nocons
scalar b_right_fs = _b[right]
scalar b_left_fs = _b[left]
matrix V_fs = e(V)
local pos_left_fs = 0
local pos_right_fs = 0
local names_fs : colnames V_fs
local i = 1
foreach v of local names_fs {
    if "`v'" == "left" local pos_left_fs = `i'
    if "`v'" == "right" local pos_right_fs = `i'
    local i = `i' + 1
}
scalar var_fs = V_fs[`pos_right_fs',`pos_right_fs'] + V_fs[`pos_left_fs',`pos_left_fs'] - 2*V_fs[`pos_right_fs',`pos_left_fs']
scalar se_fs = sqrt(var_fs)
scalar fs_disc = b_right_fs - b_left_fs
matrix b_fs = e(b)
matrix V_full_fs = e(V)

* Treatment effect = rf_disc / fs_disc
scalar te = rf_disc / fs_disc

* Delta method for treatment effect SE
* te = alpha / beta
* Var(te) = (1/beta)^2 * Var(alpha) + (alpha/beta^2)^2 * Var(beta) - 2*(alpha/beta^3)*Cov(alpha,beta)
* where alpha = rf_disc, beta = fs_disc

* Need Cov(rf_disc, fs_disc)
* rf_disc = b_right_rf - b_left_rf
* fs_disc = b_right_fs - b_left_fs
* Need cross-equation covariance

* Manually compute cross-covariance using sandwich estimator
* Score for each obs in reduced form: e_i * x_i (weighted)
* Score for each obs in first stage: u_i * x_i (weighted)

* Get residuals from both regressions
quietly reg earnings left right score_left score_right [aw=weight], vce(hc0) nocons
predict double resid_rf, residuals

quietly reg participated left right score_left score_right [aw=weight], vce(hc0) nocons  
predict double resid_fs, residuals

* Compute bread matrices (X'WX)^{-1} for each equation
* We need to compute cross-covariance: Cov(alpha_hat, beta_hat) where alpha and beta come from different equations
* Joint sandwich: need cross meat E[score_rf * score_fs']

* X matrix columns: left, right, score_left, score_right
* Weight is w_i = weight (analytic weights in WLS scale residuals)

* For HC0 with analytic weights (WLS), the sandwich is:
* V = (X'WX)^{-1} * (sum_i w_i^2 * e_i^2 * x_i x_i') * (X'WX)^{-1}
* Cross covariance uses sum_i w_i^2 * e_i_rf * e_i_fs * x_i x_i'

* Compute (X'WX)^{-1} for the system
* Since X is same for both equations, bread is same

* Build X matrix
mkmat left right score_left score_right [if e(sample)], matrix(X)
mkmat weight, matrix(W_vec)

* X'WX
matrix XtWX = X' * diag(W_vec) * X
matrix B = inv(XtWX)  /* bread = (X'WX)^{-1} */

* Cross meat: sum_i w_i * resid_rf_i * resid_fs_i * x_i x_i'
* Note: with analytic weights in Stata WLS, the effective residual for sandwich is w_i^{1/2} * e_i
* Actually need to be careful about what Stata does with analytic weights for HC0

* Let's compute manually
* Get vectors
mkmat resid_rf, matrix(R_rf)
mkmat resid_fs, matrix(R_fs)

* Cross meat = X' * diag(w * resid_rf * resid_fs) * X
* Element-wise: for each obs i, contribution is w_i * r_rf_i * r_fs_i * x_i x_i'

* Compute w_i * resid_rf_i * resid_fs_i
gen double cross_score = weight * resid_rf * resid_fs
mkmat cross_score, matrix(CS)

* Cross meat
matrix CrossMeat = X' * diag(CS) * X

* Cross covariance of coefficient vectors
matrix CrossV = B * CrossMeat * B

* rf_disc = b_right_rf - b_left_rf corresponds to contrast c_rf = (c1=-1, c2=1, c3=0, c4=0) in (left,right,score_left,score_right)
* fs_disc = similarly c_fs = (-1,1,0,0)
matrix c = J(1,4,0)
matrix c[1,1] = -1
matrix c[1,2] = 1

* Var(rf_disc) = c * V_rf_coeff * c'
* But V_rf_coeff from Stata HC0 with aweights...
* Let's recompute using our manual sandwich to be consistent

* Meat for rf
gen double meat_rf = weight * resid_rf^2
mkmat meat_rf, matrix(M_rf)
matrix Meat_rf = X' * diag(M_rf) * X
matrix V_rf_manual = B * Meat_rf * B

* Meat for fs
gen double meat_fs = weight * resid_fs^2
mkmat meat_fs, matrix(M_fs)
matrix Meat_fs = X' * diag(M_fs) * X
matrix V_fs_manual = B * Meat_fs * B

* Variances of discontinuity estimates
matrix var_rf_mat = c * V_rf_manual * c'
matrix var_fs_mat = c * V_fs_manual * c'
matrix cov_cross_mat = c * CrossV * c'

scalar var_rf2 = var_rf_mat[1,1]
scalar var_fs2 = var_fs_mat[1,1]
scalar cov_cross = cov_cross_mat[1,1]

scalar se_rf = sqrt(var_rf2)
scalar se_fs = sqrt(var_fs2)

* Delta method for te = rf_disc / fs_disc
* Var(te) = (1/fs)^2 * var_rf + (rf/fs^2)^2 * var_fs - 2*(rf/fs^3)*cov_cross
scalar var_te = (1/fs_disc)^2 * var_rf2 + (rf_disc/fs_disc^2)^2 * var_fs2 - 2*(rf_disc/fs_disc^3)*cov_cross
scalar se_te = sqrt(var_te)

display "ANSWER: treatment_effect estimate=" %21.12f te " se=" %21.12f se_te " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f rf_disc " se=" %21.12f se_rf " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f fs_disc " se=" %21.12f se_fs " n_obs=" %12.0f n_obs
