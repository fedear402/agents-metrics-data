version 17.0
clear all
set more off
set linesize 255

import delimited "./input.csv", clear varnames(1)

// Normalize regional weights (one obs per region)
bysort region_id: keep if _n == 1
egen total_weight = total(region_weight)
gen e_r = region_weight / total_weight
keep region_id e_r
tempfile weights
save `weights'

import delimited "./input.csv", clear varnames(1)
merge m:1 region_id using `weights', nogenerate

// Weighted regional means
egen double mean_y = total(e_r * y / region_weight * region_weight), by(region_id)
// Actually compute weighted means properly
// First get one obs per region for means
bysort region_id: gen first_obs = (_n == 1)

// Compute e_r-weighted means across regions (sum e_r * v_r)
// Since x, y, z are constant within region, weighted mean = sum_r e_r * v_r
// Construct z_r first
bysort region_id: gen z_r = sum(share * shock)
// Wait, need full sum within region
bysort region_id: egen z_r2 = total(share * shock)
drop z_r
rename z_r2 z_r

// Get region-level dataset
preserve
bysort region_id: keep if _n == 1
// Weighted means
egen double wmean_y = total(e_r * y)
egen double wmean_x = total(e_r * x)
egen double wmean_z = total(e_r * z_r)

gen y0 = y - wmean_y
gen x0 = x - wmean_x
gen z0 = z_r - wmean_z

keep region_id e_r y0 x0 z0
tempfile region_data
save `region_data'
restore

// Get industry-level aggregation
// s_n = sum_r e_r * share_rn
// vbar_n = sum_r e_r * share_rn * v0_r / s_n

merge m:1 region_id using `region_data', nogenerate keepusing(y0 x0 z0)

// Aggregate to industry level
bysort industry_id: gen s_n = sum(e_r * share)
bysort industry_id: replace s_n = s_n[_N]

// Weighted aggregates per industry
bysort industry_id: gen ybar_num = sum(e_r * share * y0)
bysort industry_id: replace ybar_num = ybar_num[_N]

bysort industry_id: gen xbar_num = sum(e_r * share * x0)
bysort industry_id: replace xbar_num = xbar_num[_N]

bysort industry_id: gen zbar_num = sum(e_r * share * z0)
bysort industry_id: replace zbar_num = zbar_num[_N]

gen ybar = ybar_num / s_n
gen xbar = xbar_num / s_n
gen zbar = zbar_num / s_n

// Keep one obs per industry
bysort industry_id: keep if _n == 1
// shock is constant within industry - keep it
keep industry_id shock s_n ybar xbar zbar

// Number of industries
count
local N = r(N)

// Shock-level IV regression for effect: ybar on intercept + xbar, instrument = shock, weights = s_n
// 2SLS by hand
// Instruments: (1, shock), Regressors: (1, xbar), Dependent: ybar

mata:
    st_view(ybar=., ., "ybar")
    st_view(xbar=., ., "xbar")
    st_view(zbar=., ., "zbar")
    st_view(shock=., ., "shock")
    st_view(s_n=., ., "s_n")
    
    N = rows(ybar)
    
    // Matrices
    Z = (J(N,1,1), shock)    // instruments
    X = (J(N,1,1), xbar)     // regressors
    W = s_n                   // weights (analytic)
    
    // Weighted 2SLS: beta = (Z'WX)^-1 Z'Wy
    ZtW = Z' :* W'
    beta_effect = luinv(ZtW * X) * ZtW * ybar
    
    // Structural residuals
    resid_effect = ybar - X * beta_effect
    
    // Scores: Z_i * w_i * resid_i
    scores_effect = Z :* (W :* resid_effect)
    
    // HC1 variance
    bread = luinv(ZtW * X)
    meat = scores_effect' * scores_effect
    V_effect = N / (N - 2) * bread * meat * bread'
    
    se_effect = sqrt(V_effect[2,2])
    est_effect = beta_effect[2]
    
    // First stage: xbar on intercept + zbar, instrument = shock, weights = s_n
    // endogenous regressor is zbar
    X2 = (J(N,1,1), zbar)
    
    ZtW2 = Z' :* W'
    beta_fs = luinv(ZtW2 * X2) * ZtW2 * xbar
    
    resid_fs = xbar - X2 * beta_fs
    scores_fs = Z :* (W :* resid_fs)
    
    bread2 = luinv(ZtW2 * X2)
    meat2 = scores_fs' * scores_fs
    V_fs = N / (N - 2) * bread2 * meat2 * bread2'
    
    se_fs = sqrt(V_fs[2,2])
    est_fs = beta_fs[2]
    
    // Effective shocks
    eff_shocks = 1 / sum(s_n :^ 2)
    
    st_numscalar("est_effect", est_effect)
    st_numscalar("se_effect", se_effect)
    st_numscalar("est_fs", est_fs)
    st_numscalar("se_fs", se_fs)
    st_numscalar("eff_shocks", eff_shocks)
    st_numscalar("N_ind", N)
end

display "ANSWER: effect estimate=" %21.12f est_effect " se=" %21.12f se_effect " n_obs=" %12.0f N_ind
display "ANSWER: first_stage estimate=" %21.12f est_fs " se=" %21.12f se_fs " n_obs=" %12.0f N_ind
display "ANSWER: effective_shocks estimate=" %21.12f eff_shocks " se=" %21.12f . " n_obs=" %12.0f N_ind
