version 17.0
clear all
set more off
set linesize 255

import delimited "./input.csv", clear varnames(1)

// Normalize regional weights (one obs per region)
bysort region_id: keep if _n == 1
egen total_weight = total(region_weight)
gen e_r = region_weight / total_weight
keep region_id e_r x y
tempfile region_data
save `region_data'

import delimited "./input.csv", clear varnames(1)
merge m:1 region_id using `region_data', nogenerate

// Construct shift-share instrument z_r = sum_n share_rn * shock_n
bysort region_id: egen z_r = total(share * shock)

// Keep one obs per region for regional-level computations
bysort region_id: keep if _n == 1

// Weighted means
summarize y [aw=e_r]
local mean_y = r(mean)
summarize x [aw=e_r]
local mean_x = r(mean)
summarize z_r [aw=e_r]
local mean_z = r(mean)

// Demeaned residuals
gen y0 = y - `mean_y'
gen x0 = x - `mean_x'
gen z0 = z_r - `mean_z'

// Save region-level data
keep region_id e_r x0 y0 z0 share
tempfile region_level
save `region_level'

// Now go back to full data to compute industry-level aggregates
import delimited "./input.csv", clear varnames(1)
merge m:1 region_id using `region_level', nogenerate

// s_n = sum_r e_r * share_rn
bysort industry_id: egen s_n = total(e_r * share)

// Aggregate residuals: vbar_n = sum_r e_r * share_rn * v0_r / s_n
bysort industry_id: egen num_ybar = total(e_r * share * y0)
bysort industry_id: egen num_xbar = total(e_r * share * x0)
bysort industry_id: egen num_zbar = total(e_r * share * z0)

gen ybar = num_ybar / s_n
gen xbar = num_xbar / s_n
gen zbar = num_zbar / s_n

// Keep one obs per industry
bysort industry_id: keep if _n == 1

// shock is constant within industry
keep industry_id shock s_n ybar xbar zbar
count
local N_ind = r(N)

// Mata: shock-level IV regressions
mata:
    st_view(ybar, ., "ybar")
    st_view(xbar, ., "xbar")
    st_view(zbar, ., "zbar")
    st_view(shock, ., "shock")
    st_view(s_n, ., "s_n")
    
    N = rows(ybar)
    
    // Effect: IV of ybar on (1, xbar), instrument (1, shock), weights s_n
    // Endogenous: xbar
    dep = ybar
    endog = xbar
    inst = shock
    w = s_n
    
    regressors = (J(N,1,1), endog)
    instruments = (J(N,1,1), inst)
    
    WZ = instruments :* w
    cross = WZ' * regressors
    inv_cross = luinv(cross)
    beta_effect = inv_cross * (WZ' * dep)
    resid_effect = dep - regressors * beta_effect
    scores_effect = instruments :* (w :* resid_effect)
    meat_effect = scores_effect' * scores_effect
    cov_effect = (N/(N-2)) * inv_cross * meat_effect * inv_cross'
    se_effect = sqrt(cov_effect[2,2])
    
    // First stage: IV of xbar on (1, zbar), instrument (1, shock), weights s_n
    // Endogenous: zbar
    dep2 = xbar
    endog2 = zbar
    
    regressors2 = (J(N,1,1), endog2)
    instruments2 = (J(N,1,1), inst)
    
    WZ2 = instruments2 :* w
    cross2 = WZ2' * regressors2
    inv_cross2 = luinv(cross2)
    beta_fs = inv_cross2 * (WZ2' * dep2)
    resid_fs = dep2 - regressors2 * beta_fs
    scores_fs = instruments2 :* (w :* resid_fs)
    meat_fs = scores_fs' * scores_fs
    cov_fs = (N/(N-2)) * inv_cross2 * meat_fs * inv_cross2'
    se_fs = sqrt(cov_fs[2,2])
    
    // Effective shocks
    eff_shocks = 1 / sum(s_n:^2)
    
    st_numscalar("effect_est", beta_effect[2])
    st_numscalar("effect_se", se_effect)
    st_numscalar("fs_est", beta_fs[2])
    st_numscalar("fs_se", se_fs)
    st_numscalar("eff_shocks", eff_shocks)
    st_numscalar("N_ind", N)
end

display "ANSWER: effect estimate=" %21.12f effect_est " se=" %21.12f effect_se " n_obs=" %12.0f N_ind
display "ANSWER: first_stage estimate=" %21.12f fs_est " se=" %21.12f fs_se " n_obs=" %12.0f N_ind
display "ANSWER: effective_shocks estimate=" %21.12f eff_shocks " se=" %21.12f . " n_obs=" %12.0f N_ind
