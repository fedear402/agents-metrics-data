set linesize 255
import delimited "./input.csv", clear

// Keep observations within bandwidth
keep if abs(score) < 1

// Count observations
quietly count
scalar n_obs = r(N)

// Generate triangular weights
gen weight = 1 - abs(score)

// Generate right-side indicator
gen right = (score >= 0)

// Generate interactions for local linear regression
gen score_right = score * right
gen score_left = score * (1 - right)

// WLS for earnings (reduced form)
quietly reg earnings right score_left score_right [aw=weight], robust
scalar rf_est = _b[right]
scalar rf_se = _se[right]

// WLS for participation (first stage)
quietly reg participated right score_left score_right [aw=weight], robust
scalar fs_est = _b[right]
scalar fs_se = _se[right]

// Treatment effect via delta method
// te = rf / fs
// Var(te) = (1/fs)^2 * Var(rf) + (rf/fs^2)^2 * Var(fs) - 2*(rf/fs^3)*Cov(rf,fs)

// To get the joint covariance, stack both regressions using sureg or system approach
// Use seemingly unrelated regression to get joint covariance matrix
quietly sureg (earnings right score_left score_right) (participated right score_left score_right) [aw=weight]

// Get estimates
scalar rf_est2 = _b[earnings:right]
scalar fs_est2 = _b[participated:right]

// Get variance-covariance elements
scalar var_rf = e(V)[1,1]
scalar var_fs = e(V)[5,5]
scalar cov_rf_fs = e(V)[1,5]

// But sureg doesn't give HC0 robust errors by default
// Need to manually compute HC0 robust joint covariance

// Manual approach: stack the system
// For HC0, compute meat of sandwich manually

// Re-do with manual HC0 robust covariance
// Stack both outcomes in a system: [earnings; participated] = X*[B_earn; B_part]
// The regressors are the same for both equations

// Generate regressors
gen x1 = 1
gen x2 = right
gen x3 = score_left
gen x4 = score_right

// Compute WLS (weighted) X matrix and residuals manually
// Weight the data
gen sw = sqrt(weight)
gen y_earn_w = earnings * sw
gen y_part_w = participated * sw
gen x1w = x1 * sw
gen x2w = x2 * sw
gen x3w = x3 * sw
gen x4w = x4 * sw

// Run WLS for earnings
quietly reg y_earn_w x1w x2w x3w x4w, nocons robust
// This gives HC0 robust se for the weighted regression
// But we need joint cov

// Better approach: use mata for manual computation
mata:
    st_view(Y_earn=., ., "earnings")
    st_view(Y_part=., ., "participated")
    st_view(W=., ., "weight")
    st_view(X=., ., ("x1","x2","x3","x4"))
    
    n = rows(X)
    k = cols(X)
    
    // Weighted X'X
    XtWX = cross(X, W, X)
    XtWX_inv = invsym(XtWX)
    
    // Weighted X'y
    XtWY_earn = cross(X, W, Y_earn)
    XtWY_part = cross(X, W, Y_part)
    
    // Coefficients
    b_earn = XtWX_inv * XtWY_earn
    b_part = XtWX_inv * XtWY_part
    
    // Residuals
    e_earn = Y_earn - X * b_earn
    e_part = Y_part - X * b_part
    
    // HC0 meat for earnings
    We_earn = W :* e_earn
    meat_earn = cross(X, We_earn:^2, X)
    V_earn = XtWX_inv * meat_earn * XtWX_inv
    
    // HC0 meat for participation
    We_part = W :* e_part
    meat_part = cross(X, We_part:^2, X)
    V_part = XtWX_inv * meat_part * XtWX_inv
    
    // Cross-equation HC0 covariance (same observations)
    // Cov(b_earn, b_part) = (X'WX)^-1 * (sum_i w_i^2 * e_earn_i * e_part_i * x_i * x_i') * (X'WX)^-1
    meat_cross = cross(X, (W:^2):*(e_earn:*e_part), X)
    V_cross = XtWX_inv * meat_cross * XtWX_inv
    
    // b2 is the coefficient on "right" (2nd element)
    rf_est = b_earn[2]
    fs_est = b_part[2]
    
    var_rf = V_earn[2,2]
    var_fs = V_part[2,2]
    cov_rf_fs = V_cross[2,2]
    
    se_rf = sqrt(var_rf)
    se_fs = sqrt(var_fs)
    
    // Delta method for treatment effect
    // te = rf / fs
    // Var(te) = (dte/drf)^2 * Var(rf) + (dte/dfs)^2 * Var(fs) + 2*(dte/drf)*(dte/dfs)*Cov(rf,fs)
    // dte/drf = 1/fs
    // dte/dfs = -rf/fs^2
    te = rf_est / fs_est
    var_te = (1/fs_est)^2 * var_rf + (rf_est/fs_est^2)^2 * var_fs - 2*(1/fs_est)*(rf_est/fs_est^2)*cov_rf_fs
    se_te = sqrt(var_te)
    
    st_numscalar("rf_est_m", rf_est)
    st_numscalar("fs_est_m", fs_est)
    st_numscalar("te_est_m", te)
    st_numscalar("se_rf_m", se_rf)
    st_numscalar("se_fs_m", se_fs)
    st_numscalar("se_te_m", se_te)
end

display "ANSWER: treatment_effect estimate=" %21.12f te_est_m " se=" %21.12f se_te_m " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f rf_est_m " se=" %21.12f se_rf_m " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f fs_est_m " se=" %21.12f se_fs_m " n_obs=" %12.0f n_obs
