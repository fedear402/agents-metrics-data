set linesize 255
import delimited "./input.csv", clear

count
scalar n = r(N)

* Residuals from projecting onto restricted regressors [1, x]
reg y x
predict double ry, resid

reg endog x
predict double rendog_r, resid

* Residuals from projecting onto unrestricted regressors [1, x, z1, z2]
reg y x z1 z2
predict double ry_u, resid

reg endog x z1 z2
predict double rendog_u, resid

* Quadratic form coefficients:
* RSS_r(beta) = A_r*beta^2 - 2*B_r*beta + C_r
* RSS_u(beta) = A_u*beta^2 - 2*B_u*beta + C_u
quietly {
    gen double tmp = ry^2
    sum tmp
    scalar C_r = r(sum)
    replace tmp = rendog_r^2
    sum tmp
    scalar A_r = r(sum)
    replace tmp = ry * rendog_r
    sum tmp
    scalar B_r = r(sum)

    replace tmp = ry_u^2
    sum tmp
    scalar C_u = r(sum)
    replace tmp = rendog_u^2
    sum tmp
    scalar A_u = r(sum)
    replace tmp = ry_u * rendog_u
    sum tmp
    scalar B_u = r(sum)
}
drop tmp

* 95th percentile of F(2, n-4)
scalar F_crit = invFtail(2, n-4, 0.05)
scalar kk = (n-4) + 2*F_crit

* Boundary condition: g(beta) = qa*beta^2 + qb*beta + qc <= 0
* where g(beta) = (n-4)*RSS_r(beta) - kk*RSS_u(beta)
scalar qa = (n-4)*A_r - kk*A_u
scalar qb = -2*((n-4)*B_r - kk*B_u)
scalar qc = (n-4)*C_r - kk*C_u

scalar disc = qb^2 - 4*qa*qc

scalar root1 = (-qb - sqrt(disc)) / (2*qa)
scalar root2 = (-qb + sqrt(disc)) / (2*qa)

scalar boundary_low  = min(root1, root2)
scalar boundary_high = max(root1, root2)

* If qa < 0, parabola opens downward: g(beta) <= 0 outside the roots => unbounded
scalar unbounded = (qa < 0)

* accepts_zero: check g(0) = qc <= 0
scalar accepts_zero = (qc <= 0)

* AR F statistic at beta = 1
scalar RSS_r_1 = A_r - 2*B_r + C_r
scalar RSS_u_1 = A_u - 2*B_u + C_u
scalar ar_f_at_one = ((RSS_r_1 - RSS_u_1)/2) / (RSS_u_1/(n-4))

display "ANSWER: boundary_low estimate="  %21.12f boundary_low  " se=" %21.12f . " n_obs=" %12.0f n
display "ANSWER: boundary_high estimate=" %21.12f boundary_high " se=" %21.12f . " n_obs=" %12.0f n
display "ANSWER: accepts_zero estimate="  %21.12f accepts_zero  " se=" %21.12f . " n_obs=" %12.0f n
display "ANSWER: unbounded estimate="     %21.12f unbounded     " se=" %21.12f . " n_obs=" %12.0f n
display "ANSWER: ar_f_at_one estimate="   %21.12f ar_f_at_one   " se=" %21.12f . " n_obs=" %12.0f n
