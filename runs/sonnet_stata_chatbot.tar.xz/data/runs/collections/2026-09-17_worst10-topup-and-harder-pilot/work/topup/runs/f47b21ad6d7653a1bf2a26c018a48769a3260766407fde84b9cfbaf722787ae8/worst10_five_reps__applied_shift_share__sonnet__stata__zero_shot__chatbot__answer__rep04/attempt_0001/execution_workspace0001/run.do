set linesize 255
clear all

import delimited "./input.csv", varnames(1)

* Step 1: Normalize regional weights using one obs per region
bysort region_id: gen first_obs = (_n == 1)
egen total_weight = total(region_weight * first_obs)
gen e_r = region_weight / total_weight

* Step 2: Construct shift-share instrument z_r = sum_n share_rn * shock_n
bysort region_id: gen z_r_contrib = share * shock
bysort region_id: egen z_r = total(z_r_contrib)

* Step 3: Get one obs per region for regional-level regression
* x, y, z_r, e_r are constant within region
preserve
keep if first_obs == 1
keep region_id e_r x y z_r

* Normalize weights sum to 1
egen sum_e = total(e_r)
replace e_r = e_r / sum_e

* Compute e_r-weighted means
egen mean_y = total(e_r * y)
egen mean_x = total(e_r * x)
egen mean_z = total(e_r * z_r)

gen y0 = y - mean_y
gen x0 = x - mean_x
gen z0 = z_r - mean_z

save "/tmp/region_level.dta", replace
restore

* Step 4: Construct industry-level aggregates
* Merge region-level residuals back
merge m:1 region_id using "/tmp/region_level.dta", keepusing(e_r y0 x0 z0) nogenerate

* s_n = sum_r e_r * share_rn
bysort industry_id: egen s_n = total(e_r * share)

* ybar_n = sum_r e_r*share_rn*y0_r / s_n
bysort industry_id: egen ybar_num = total(e_r * share * y0)
gen ybar_n = ybar_num / s_n

* xbar_n = sum_r e_r*share_rn*x0_r / s_n
bysort industry_id: egen xbar_num = total(e_r * share * x0)
gen xbar_n = xbar_num / s_n

* zbar_n = sum_r e_r*share_rn*z0_r / s_n
bysort industry_id: egen zbar_num = total(e_r * share * z0)
gen zbar_n = zbar_num / s_n

* Keep one obs per industry
bysort industry_id: keep if (_n == 1)
keep industry_id s_n ybar_n xbar_n zbar_n shock

count
local N_ind = r(N)

* Step 5: Shock-level IV regression for effect
* Regress ybar_n on intercept + xbar_n, instrumenting xbar_n with shock_n, weighting by s_n
* HC1 variance: multiply by N/(N-2)

* Manual 2SLS
* First stage: xbar_n on intercept + shock_n, weighted by s_n
* Get fitted xbar_hat_n
reg xbar_n shock [aw=s_n]
predict xbar_hat, xb

* Second stage: ybar_n on intercept + xbar_hat_n, weighted by s_n
reg ybar_n xbar_hat [aw=s_n]
local beta_2sls = _b[xbar_hat]

* Compute structural IV residuals: u_n = ybar_n - beta_2sls * xbar_n - alpha
* alpha = weighted mean of (ybar_n - beta_2sls * xbar_n)
gen resid_struct_y = ybar_n - `beta_2sls' * xbar_n
reg resid_struct_y [aw=s_n]
local alpha_2sls = _b[_cons]
gen u_n = ybar_n - `beta_2sls' * xbar_n - `alpha_2sls'

* HC1 SE for 2SLS effect
* Var(beta) = [sum_n s_n * xbar_hat_n^2]^(-2) * sum_n s_n^2 * xbar_hat_n^2 * u_n^2 * (N/(N-2))
* Wait - need to be careful. Using analytic weights.

* For weighted IV with instrument z=shock:
* beta = (sum s_n * shock_n * ybar_n) / (sum s_n * shock_n * xbar_n) [after demeaning]
* But we have intercept, so need to partial out intercept first

* Demean by weighted mean using s_n weights
egen sum_s = total(s_n)
gen w_n = s_n / sum_s

egen wmean_ybar = total(w_n * ybar_n)
egen wmean_xbar = total(w_n * xbar_n)
egen wmean_zbar = total(w_n * zbar_n)
egen wmean_shock = total(w_n * shock)

gen ybar_dm = ybar_n - wmean_ybar
gen xbar_dm = xbar_n - wmean_xbar
gen zbar_dm = zbar_n - wmean_zbar
gen shock_dm = shock - wmean_shock

* 2SLS slope (effect): beta = (sum s_n * shock_dm * ybar_dm) / (sum s_n * shock_dm * xbar_dm)
gen s_shock_y = s_n * shock_dm * ybar_dm
gen s_shock_x = s_n * shock_dm * xbar_dm

egen num_beta = total(s_shock_y)
egen den_beta = total(s_shock_x)
local beta_effect = num_beta[1] / den_beta[1]

* Structural residuals for effect
gen alpha_effect = wmean_ybar - `beta_effect' * wmean_xbar
gen resid_effect = ybar_n - `alpha_effect' - `beta_effect' * xbar_n

* HC1 SE for effect
* V(beta) = (1/den_beta^2) * sum_n [s_n * shock_dm_n]^2 * resid_effect_n^2 * (N/(N-2))
gen meat_effect = (s_n * shock_dm)^2 * resid_effect^2
egen sum_meat_effect = total(meat_effect)
local var_effect = (1 / den_beta[1]^2) * sum_meat_effect[1] * (`N_ind' / (`N_ind' - 2))
local se_effect = sqrt(`var_effect')

* Step 6: First-stage slope: x on z using regional data
* Shock-level regression: xbar_n on intercept + zbar_n, instrumenting zbar_n with shock_n, weighting by s_n
* beta_fs = (sum s_n * shock_dm * xbar_dm) / (sum s_n * shock_dm * zbar_dm)
gen s_shock_z = s_n * shock_dm * zbar_dm
egen den_fs = total(s_shock_z)
local beta_fs = den_beta[1] / den_fs[1]

* Structural residuals for first stage
gen alpha_fs = wmean_xbar - `beta_fs' * wmean_zbar
gen resid_fs = xbar_n - `alpha_fs' - `beta_fs' * zbar_n

* HC1 SE for first stage
gen meat_fs = (s_n * shock_dm)^2 * resid_fs^2
egen sum_meat_fs = total(meat_fs)
local var_fs = (1 / den_fs[1]^2) * sum_meat_fs[1] * (`N_ind' / (`N_ind' - 2))
local se_fs = sqrt(`var_fs')

* Step 7: Effective shocks
gen s_n_sq = s_n^2
egen sum_s_sq = total(s_n_sq)
local eff_shocks = 1 / sum_s_sq[1]

* Report results
display "ANSWER: effect estimate=" %21.12f `beta_effect' " se=" %21.12f `se_effect' " n_obs=" %12.0f `N_ind'
display "ANSWER: first_stage estimate=" %21.12f `beta_fs' " se=" %21.12f `se_fs' " n_obs=" %12.0f `N_ind'
display "ANSWER: effective_shocks estimate=" %21.12f `eff_shocks' " se=" %21.12f . " n_obs=" %12.0f `N_ind'
