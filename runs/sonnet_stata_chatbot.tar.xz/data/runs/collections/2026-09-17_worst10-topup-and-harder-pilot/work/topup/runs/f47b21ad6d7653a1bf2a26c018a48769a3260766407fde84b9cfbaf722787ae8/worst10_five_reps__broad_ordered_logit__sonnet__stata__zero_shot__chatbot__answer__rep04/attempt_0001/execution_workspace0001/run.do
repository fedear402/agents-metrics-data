set linesize 255
import delimited "./input.csv", clear

ologit y x z

scalar b_x = _b[x]
scalar b_z = _b[z]
scalar se_x = _se[x]
scalar se_z = _se[z]
scalar n_obs = e(N)

* Compute fitted probability of category 3 for x=1, z=0
* P(y=3) = 1 - invlogit(cut2 - (b_x*1 + b_z*0))
scalar cut2 = _b[/cut2]
scalar xb = b_x * 1 + b_z * 0
scalar prob_high = 1 - invlogit(cut2 - xb)

display "ANSWER: x estimate=" %21.12f b_x " se=" %21.12f se_x " n_obs=" %12.0f n_obs
display "ANSWER: z estimate=" %21.12f b_z " se=" %21.12f se_z " n_obs=" %12.0f n_obs
display "ANSWER: prob_high estimate=" %21.12f prob_high " se=" %21.12f . " n_obs=" %12.0f n_obs
