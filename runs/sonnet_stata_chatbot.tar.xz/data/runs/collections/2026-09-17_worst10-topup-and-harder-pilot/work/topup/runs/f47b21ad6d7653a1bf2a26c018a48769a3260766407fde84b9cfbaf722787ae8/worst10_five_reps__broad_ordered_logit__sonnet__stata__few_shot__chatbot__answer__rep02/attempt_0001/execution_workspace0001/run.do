clear all
set more off
set linesize 255
set type double

import delimited "./input.csv", clear

ologit y x z, tolerance(1e-10) nrtolerance(1e-10)

scalar n = e(N)
scalar b_x = _b[x]
scalar se_x = _se[x]
scalar b_z = _b[z]
scalar se_z = _se[z]

* P(y=3 | x=1, z=0) = 1 - logistic(cut2 - x*b_x - z*b_z) evaluated at x=1,z=0
* = 1 - logistic(cut2 - b_x)
scalar xb = _b[x]*1 + _b[z]*0
scalar prob_high = 1 - invlogit(_b[/cut2] - xb)

display "ANSWER: x estimate=" %21.12f b_x " se=" %21.12f se_x " n_obs=" %12.0f n
display "ANSWER: z estimate=" %21.12f b_z " se=" %21.12f se_z " n_obs=" %12.0f n
display "ANSWER: prob_high estimate=" %21.12f prob_high " se=" %21.12f . " n_obs=" %12.0f n
