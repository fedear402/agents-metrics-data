version 16
clear all
set more off
set linesize 255

import delimited "./input.csv", clear

keep if abs(score) < 1
gen w = 1 - abs(score)
gen above = (score >= 0)

mata:
    st_view(Y=., ., ("earnings","participated"))
    st_view(X=., ., ("score","above","w"))
    
    n = rows(Y)
    w = X[.,3]
    above = X[.,2]
    score = X[.,1]
    
    // Design matrix: intercept, score_left, score_right, above, score_left*above... 
    // Separate local linear on each side:
    // left side: intercept + slope*score
    // right side: (intercept + jump) + (slope + slope_diff)*score
    // X = [1, score, above, score*above]
    Xmat = J(n, 4, 0)
    Xmat[.,1] = J(n,1,1)
    Xmat[.,2] = score
    Xmat[.,3] = above
    Xmat[.,4] = score :* above
    
    // Weighted WLS
    Xw = w :* Xmat
    bread = invsym(Xw' * Xmat)
    
    // Coefficients for each outcome
    coef = bread * (Xw' * Y)
    
    // Residuals
    resid = Y - Xmat * coef
    
    // Contrast for discontinuity: coefficient on "above" (column 3)
    contrast = (0 \ 0 \ 1 \ 0)
    
    jumps = contrast' * coef
    
    // Influence: loading = w * (Xmat * bread * contrast)
    loading = w :* (Xmat * bread * contrast)
    
    // Influence functions for each outcome
    infl = loading :* resid
    
    // Joint sandwich covariance
    joint = infl' * infl
    
    // Delta method for ratio = jumps[1]/jumps[2]
    rf = jumps[1,1]
    fs = jumps[1,2]
    grad = (1/fs \ -rf/fs^2)
    ratio_se = sqrt(grad' * joint * grad)
    
    st_numscalar("rf_est", rf)
    st_numscalar("fs_est", fs)
    st_numscalar("te_est", rf/fs)
    st_numscalar("rf_se", sqrt(joint[1,1]))
    st_numscalar("fs_se", sqrt(joint[2,2]))
    st_numscalar("te_se", ratio_se)
    st_numscalar("nobs", n)
end

display "ANSWER: treatment_effect estimate=" %21.12f te_est " se=" %21.12f te_se " n_obs=" %12.0f nobs
display "ANSWER: reduced_form estimate=" %21.12f rf_est " se=" %21.12f rf_se " n_obs=" %12.0f nobs
display "ANSWER: first_stage estimate=" %21.12f fs_est " se=" %21.12f fs_se " n_obs=" %12.0f nobs
