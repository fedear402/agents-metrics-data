set linesize 255
clear all

import delimited "./input.csv", varnames(1)

// Step 1: Normalize regional weights (one obs per region)
bysort region_id: gen region_first = (_n == 1)
quietly sum region_weight if region_first
scalar total_weight = r(sum)
gen e_r = region_weight / total_weight

// Step 2: Construct shift-share instrument z_r = sum_n share_rn * shock_n
bysort region_id: gen z_r_contrib = share * shock
bysort region_id: egen z_r = sum(z_r_contrib)

// Step 3: Get unique region-level variables
// x, y, z_r, e_r are constant within region

// Compute e_r-weighted means
quietly sum x [aw=e_r] if region_first
scalar mean_x = r(mean)
quietly sum y [aw=e_r] if region_first
scalar mean_y = r(mean)
quietly sum z_r [aw=e_r] if region_first
scalar mean_z = r(mean)

// Demeaned residuals
gen x0 = x - mean_x
gen y0 = y - mean_y
gen z0 = z_r - mean_z

// Step 4: Compute s_n = sum_r e_r * share_rn
// and aggregate residuals: vbar_n = sum_r e_r * share_rn * v0_r / s_n
gen e_share = e_r * share

bysort industry_id: egen s_n = sum(e_share)

gen ey0 = e_r * share * y0
gen ex0 = e_r * share * x0
gen ez0 = e_r * share * z0

bysort industry_id: egen sum_ey0 = sum(ey0)
bysort industry_id: egen sum_ex0 = sum(ex0)
bysort industry_id: egen sum_ez0 = sum(ez0)

gen ybar_n = sum_ey0 / s_n
gen xbar_n = sum_ex0 / s_n
gen zbar_n = sum_ez0 / s_n

// Keep one observation per industry
bysort industry_id: gen ind_first = (_n == 1)
keep if ind_first

// Get shock (constant within industry)
// shock is already in the data

quietly count
scalar N_ind = r(N)

// Step 5: Shock-level IV regression for EFFECT
// Reg ybar_n on xbar_n (instrumented by shock_n), weighted by s_n
// HC1 with N/(N-2) multiplier

// 2SLS by hand:
// First stage: xbar_n ~ intercept + shock_n, weighted by s_n
quietly reg xbar_n shock [aw=s_n]
scalar fs_coef_xz = _b[shock]

// Predicted xbar_n from first stage
predict xbar_hat, xresid
drop xbar_hat
quietly reg xbar_n shock [aw=s_n]
predict xbar_hat

// Second stage: ybar_n ~ intercept + xbar_hat, weighted by s_n
// But we need IV residuals using actual xbar_n coefficient

// Manual 2SLS: beta_2sls = (Z'WX)^{-1} Z'Wy
// where Z = [1, shock_n], W = diag(s_n), X = [1, xbar_n], y = ybar_n
// With intercept already demeaned out (since we demeaned), 
// but let's do it properly with intercept

// Weighted sums
quietly sum s_n
scalar sum_s = r(sum)

gen ws = s_n  // weights

// Compute weighted means
quietly sum ybar_n [aw=s_n]
scalar wm_y = r(mean)
quietly sum xbar_n [aw=s_n]
scalar wm_x = r(mean)
quietly sum shock [aw=s_n]
scalar wm_shock = r(mean)
quietly sum zbar_n [aw=s_n]
scalar wm_zbar = r(mean)

// Demeaned for cross-products
gen yd = ybar_n - wm_y
gen xd = xbar_n - wm_x
gen sd = shock - wm_shock
gen zd = zbar_n - wm_zbar

// 2SLS slope for effect: beta = sum(s_n * sd * yd) / sum(s_n * sd * xd)
gen szd_yd = s_n * sd * yd
gen szd_xd = s_n * sd * xd

quietly sum szd_yd
scalar num_beta = r(sum)
quietly sum szd_xd
scalar den_beta = r(sum)

scalar beta_effect = num_beta / den_beta

// IV residual: u_n = ybar_n - intercept - beta_effect * xbar_n
scalar intercept_effect = wm_y - beta_effect * wm_x
gen u_effect = ybar_n - intercept_effect - beta_effect * xbar_n

// HC1 SE for beta_effect
// Var(beta) = (N/(N-2)) * sum(s_n^2 * sd^2 * u^2) / (sum(s_n * sd * xd))^2
gen hc_term_effect = s_n^2 * sd^2 * u_effect^2

quietly sum hc_term_effect
scalar hc_sum_effect = r(sum)

scalar var_beta_effect = (N_ind / (N_ind - 2)) * hc_sum_effect / (den_beta^2)
scalar se_effect = sqrt(var_beta_effect)

// Step 6: First-stage slope: x_r on z_r, weighted by e_r
// Shock-level: xbar_n on zbar_n (instrumented by shock_n), weighted by s_n

// 2SLS slope for first stage: beta_fs = sum(s_n * sd * xd) / sum(s_n * sd * zd)
gen szd_zd = s_n * sd * zd

quietly sum szd_zd
scalar den_fs = r(sum)

scalar beta_fs = den_beta / den_fs  // num = sum(s_n*sd*xd), den = sum(s_n*sd*zd)

// IV residual for first stage: xbar_n - intercept_fs - beta_fs * zbar_n
scalar intercept_fs = wm_x - beta_fs * wm_zbar
gen u_fs = xbar_n - intercept_fs - beta_fs * zbar_n

// HC1 SE for beta_fs
gen hc_term_fs = s_n^2 * sd^2 * u_fs^2

quietly sum hc_term_fs
scalar hc_sum_fs = r(sum)

scalar var_beta_fs = (N_ind / (N_ind - 2)) * hc_sum_fs / (den_fs^2)
scalar se_fs = sqrt(var_beta_fs)

// Step 7: Effective shocks = 1 / sum(s_n^2)
gen s_n_sq = s_n^2
quietly sum s_n_sq
scalar eff_shocks = 1 / r(sum)

// Report results
display "ANSWER: effect estimate=" %21.12f beta_effect " se=" %21.12f se_effect " n_obs=" %12.0f N_ind
display "ANSWER: first_stage estimate=" %21.12f beta_fs " se=" %21.12f se_fs " n_obs=" %12.0f N_ind
display "ANSWER: effective_shocks estimate=" %21.12f eff_shocks " se=" %21.12f . " n_obs=" %12.0f N_ind
