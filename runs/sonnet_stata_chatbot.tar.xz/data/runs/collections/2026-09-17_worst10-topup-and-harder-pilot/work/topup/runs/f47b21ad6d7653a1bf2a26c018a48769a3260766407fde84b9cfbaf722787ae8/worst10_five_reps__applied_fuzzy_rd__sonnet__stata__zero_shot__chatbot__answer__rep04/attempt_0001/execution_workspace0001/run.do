set linesize 255
import delimited "./input.csv", clear

* Keep observations within bandwidth
keep if abs(score) < 1

* Count observations
count
scalar n_obs = r(N)

* Generate triangular weights
gen weight = 1 - abs(score)

* Generate right-side indicator
gen right = (score >= 0)

* Generate interaction terms for local linear
gen score_right = score * right
gen score_left = score * (1 - right)

* Stack the system: estimate reduced form and first stage jointly
* We need joint covariance, so we use seemingly unrelated regression approach
* But since same regressors, OLS equation by equation with shared X is fine
* Use matrix approach for joint covariance

* Create design matrix columns
gen x1 = 1        // intercept left
gen x2 = right    // jump (right intercept - left intercept)
gen x3 = score_left   // slope left
gen x4 = score_right  // slope right

* WLS for earnings (reduced form)
* Need HC0 robust SE
* Use matrix algebra

* Convert to matrices
mkmat x1 x2 x3 x4, matrix(X)
mkmat earnings, matrix(Y_earn)
mkmat participated, matrix(Y_part)
mkmat weight, matrix(W_vec)

* Create diagonal weight matrix via elementwise
* Use mata for matrix computations

mata:
    X = st_matrix("X")
    Y_earn = st_matrix("Y_earn")
    Y_part = st_matrix("Y_part")
    W_vec = st_matrix("W_vec")
    
    n = rows(X)
    k = cols(X)
    
    // Weight matrix (diagonal)
    W = diag(W_vec)
    
    // WLS: beta = (X'WX)^-1 X'WY
    XtW = X' * W
    XtWX = XtW * X
    XtWX_inv = invsym(XtWX)
    
    // Earnings equation
    XtWY_earn = XtW * Y_earn
    beta_earn = XtWX_inv * XtWY_earn
    
    // Participation equation
    XtWY_part = XtW * Y_part
    beta_part = XtWX_inv * XtWY_part
    
    // Residuals
    e_earn = Y_earn - X * beta_earn
    e_part = Y_part - X * beta_part
    
    // HC0 sandwich for each equation
    // V = (X'WX)^-1 * (X'W * diag(e^2) * W * X) * (X'WX)^-1
    // With weights: weighted residuals
    // The weighted residual for HC0: e_i * w_i already in WLS
    // For HC0 robust in WLS context:
    // Score for obs i: w_i * x_i * e_i
    // Meat = sum_i (w_i * x_i * e_i)^2 ... no, HC0 uses outer product of scores
    
    // Standard WLS HC0:
    // Let S_i = w_i * x_i * e_i (score vector for obs i)
    // Meat = sum_i S_i S_i'
    // V = (X'WX)^-1 * Meat * (X'WX)^-1
    
    // Earnings meat
    meat_earn = J(k, k, 0)
    meat_part = J(k, k, 0)
    meat_cross = J(k, k, 0)
    
    for (i = 1; i <= n; i++) {
        xi = X[i,]'
        wi = W_vec[i,1]
        ei_earn = e_earn[i,1]
        ei_part = e_part[i,1]
        
        score_earn_i = wi * xi * ei_earn
        score_part_i = wi * xi * ei_part
        
        meat_earn = meat_earn + score_earn_i * score_earn_i'
        meat_part = meat_part + score_part_i * score_part_i'
        meat_cross = meat_cross + score_earn_i * score_part_i'
    }
    
    V_earn = XtWX_inv * meat_earn * XtWX_inv
    V_part = XtWX_inv * meat_part * XtWX_inv
    V_cross = XtWX_inv * meat_cross * XtWX_inv
    
    // The discontinuity is beta[2] (coefficient on x2 = right)
    // index 2 in 1-based indexing
    
    rf_est = beta_earn[2,1]
    fs_est = beta_part[2,1]
    
    rf_var = V_earn[2,2]
    fs_var = V_part[2,2]
    rf_fs_cov = V_cross[2,2]
    
    rf_se = sqrt(rf_var)
    fs_se = sqrt(fs_var)
    
    // Delta method for treatment effect = rf / fs
    // te = rf_est / fs_est
    // Var(te) = (1/fs)^2 * Var(rf) + (rf/fs^2)^2 * Var(fs) - 2*(rf/fs^3)*Cov(rf,fs) 
    // Wait: d(te)/d(rf) = 1/fs, d(te)/d(fs) = -rf/fs^2
    // Var(te) = (1/fs)^2 * Var_rf + (rf/fs^2)^2 * Var_fs - 2*(1/fs)*(rf/fs^2)*Cov
    
    te_est = rf_est / fs_est
    
    grad_rf = 1 / fs_est
    grad_fs = -rf_est / (fs_est^2)
    
    te_var = grad_rf^2 * rf_var + grad_fs^2 * fs_var + 2 * grad_rf * grad_fs * rf_fs_cov
    te_se = sqrt(te_var)
    
    st_numscalar("rf_est", rf_est)
    st_numscalar("rf_se", rf_se)
    st_numscalar("fs_est", fs_est)
    st_numscalar("fs_se", fs_se)
    st_numscalar("te_est", te_est)
    st_numscalar("te_se", te_se)
end

display "ANSWER: treatment_effect estimate=" %21.12f te_est " se=" %21.12f te_se " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f rf_est " se=" %21.12f rf_se " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f fs_est " se=" %21.12f fs_se " n_obs=" %12.0f n_obs
