clear all
set more off
set linesize 255
set type double

import delimited "./input.csv", clear

ologit y x z, tolerance(1e-10) nrtolerance(1e-10)

scalar b_x = _b[x]
scalar se_x = _se[x]
scalar b_z = _b[z]
scalar se_z = _se[z]
scalar cut2 = _b[/cut2]
scalar b_x_val = _b[x]
scalar b_z_val = _b[z]

* P(y=3 | x=1, z=0) = 1 - logistic(cut2 - b_x*1 - b_z*0)
scalar xb = b_x_val * 1 + b_z_val * 0
scalar prob_high = 1 - invlogit(cut2 - xb)

scalar n = e(N)

display "ANSWER: x estimate=" %21.12f b_x " se=" %21.12f se_x " n_obs=" %12.0f n
display "ANSWER: z estimate=" %21.12f b_z " se=" %21.12f se_z " n_obs=" %12.0f n
display "ANSWER: prob_high estimate=" %21.12f prob_high " se=" %21.12f . " n_obs=" %12.0f n
