set linesize 255
import delimited "./input.csv", clear

gen log_sales = log(sales)
gen log_vix = log(vix)

sort date

gen d_log_vix = log_vix - log_vix[_n-1]

forvalues k = 1/15 {
    gen lag`k'_d_log_vix = d_log_vix[_n-`k']
}

regress log_sales lag1_d_log_vix lag2_d_log_vix lag3_d_log_vix lag4_d_log_vix lag5_d_log_vix lag6_d_log_vix lag7_d_log_vix lag8_d_log_vix lag9_d_log_vix lag10_d_log_vix lag11_d_log_vix lag12_d_log_vix lag13_d_log_vix lag14_d_log_vix lag15_d_log_vix

scalar N = e(N)

* Newey-West with max lag 15, Bartlett weights 1-j/16
newey log_sales lag1_d_log_vix lag2_d_log_vix lag3_d_log_vix lag4_d_log_vix lag5_d_log_vix lag6_d_log_vix lag7_d_log_vix lag8_d_log_vix lag9_d_log_vix lag10_d_log_vix lag11_d_log_vix lag12_d_log_vix lag13_d_log_vix lag14_d_log_vix lag15_d_log_vix, lag(15) force

scalar N = e(N)

* Extract coefficients
matrix b = e(b)
matrix V = e(V)

* Multiply V by N/(N-16)
matrix V_adj = V * (N / (N - 16))

* Coefficients
scalar b_lag1  = b[1,1]
scalar b_lag15 = b[1,15]

* Sum of lag 1 through 15 coefficients
scalar cum_resp = 0
forvalues k = 1/15 {
    scalar cum_resp = cum_resp + b[1,`k']
}

* SE for individual lags
scalar se_lag1  = sqrt(V_adj[1,1])
scalar se_lag15 = sqrt(V_adj[15,15])

* SE for cumulative response: sqrt(sum of all elements of submatrix V_adj[1:15,1:15])
matrix V_sub = V_adj[1..15, 1..15]
matrix ones = J(15,1,1)
matrix var_cum = ones' * V_sub * ones
scalar se_cum = sqrt(var_cum[1,1])

display "ANSWER: cumulative_response estimate=" %21.12f cum_resp " se=" %21.12f se_cum " n_obs=" %12.0f N
display "ANSWER: lag_1 estimate=" %21.12f b_lag1 " se=" %21.12f se_lag1 " n_obs=" %12.0f N
display "ANSWER: lag_15 estimate=" %21.12f b_lag15 " se=" %21.12f se_lag15 " n_obs=" %12.0f N
