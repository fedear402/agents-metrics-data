version 17.0
clear all
set more off
set linesize 255

import delimited "./input.csv", clear

keep if abs(score) < 1
gen w = 1 - abs(score)
gen above = (score >= 0)
gen score_above = score * above
gen score_below = score * (1 - above)

count
scalar n_obs = r(N)

mata:
    st_view(Y=., ., ("earnings", "participated"))
    st_view(score=., ., "score")
    st_view(above=., ., "above")
    st_view(score_above=., ., "score_above")
    st_view(score_below=., ., "score_below")
    st_view(w=., ., "w")
    
    n = rows(Y)
    
    // Design matrix: intercept, above, score_below, score_above
    X = (J(n,1,1), above, score_below, score_above)
    
    // Weighted WLS
    WX = w :* X
    bread = invsym(X' * WX)
    coef = bread * (WX' * Y)
    
    // Residuals
    resid = Y - X * coef
    
    // Contrast for discontinuity: [0,1,0,0] selects coefficient on 'above'
    contrast = (0 \ 1 \ 0 \ 0)
    
    jumps = contrast' * coef  // 1x2 matrix: [earnings_jump, participated_jump]
    
    // Influence functions
    loading = w :* (X * bread * contrast)  // nx1
    influence = loading :* resid            // nx2
    
    // Joint sandwich covariance
    joint = influence' * influence          // 2x2
    
    // Delta method for ratio
    rf = jumps[1,1]
    fs = jumps[1,2]
    gradient = (1/fs \ -rf/fs^2)
    ratio_se = sqrt(gradient' * joint * gradient)
    
    st_numscalar("rf_est", rf)
    st_numscalar("fs_est", fs)
    st_numscalar("te_est", rf/fs)
    st_numscalar("rf_se", sqrt(joint[1,1]))
    st_numscalar("fs_se", sqrt(joint[2,2]))
    st_numscalar("te_se", ratio_se)
end

display "ANSWER: treatment_effect estimate=" %21.12f te_est " se=" %21.12f te_se " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f rf_est " se=" %21.12f rf_se " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f fs_est " se=" %21.12f fs_se " n_obs=" %12.0f n_obs
