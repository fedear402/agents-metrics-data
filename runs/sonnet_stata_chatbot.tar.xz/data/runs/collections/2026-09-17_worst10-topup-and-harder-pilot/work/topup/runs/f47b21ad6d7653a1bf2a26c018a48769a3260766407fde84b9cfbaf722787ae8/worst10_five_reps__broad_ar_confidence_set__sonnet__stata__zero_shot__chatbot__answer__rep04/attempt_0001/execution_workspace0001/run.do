set linesize 255
clear all

import delimited "./input.csv", clear

* Get sample size
quietly count
local n = r(N)

* Critical value from F(2, n-4) at 95th percentile
local df1 = 2
local df2 = `n' - 4
local fcrit = invFtail(`df1', `df2', 0.05)

* Anderson-Rubin test: for each beta, regress y - beta*endog on intercept, x, z1, z2
* F test of joint significance of z1 and z2

* The AR F-statistic as function of beta is a quadratic in beta
* F(beta) <= fcrit defines the confidence set
* We need to find the boundary points

* Let's derive analytically:
* y - beta*endog = a + b*x + c*z1 + d*z2 + e
* We want to test H0: c=0, d=0

* Partition: regress y on intercept, x, z1, z2 -> get RSS_y
* regress endog on intercept, x, z1, z2 -> get RSS_e
* Also need cross terms

* More systematic: 
* Let W = [1, x, z1, z2], X0 = [1, x]
* M_W = I - W(W'W)^{-1}W'
* M_X0 = I - X0(X0'X0)^{-1}X0'
* P_W - P_X0 projects onto instruments conditional on exog

* AR F stat = [(y - beta*endog)'(M_X0 - M_W)(y - beta*endog) / 2] / 
*             [(y - beta*endog)'M_W(y - beta*endog) / (n-4)]

* Let a = y'M_X0 y - y'M_W y  (scalar, function of data only)
* Let b_cross = endog'M_X0 y - endog'M_W y
* Let c = endog'M_X0 endog - endog'M_W endog

* Numerator = (1/2)[a - 2*beta*b_cross + beta^2 * c]
* Denominator = (1/(n-4))[(y'M_W y) - 2*beta*(endog'M_W y) + beta^2*(endog'M_W endog)]

* F(beta) = (n-4)/2 * [a - 2*beta*b + beta^2*c] / [d - 2*beta*e + beta^2*f]
* where a,b,c,d,e,f are quadratic form scalars

* Compute these via regressions
tempvar yhat_w yhat_x0 endoghat_w endoghat_x0
tempvar res_y_w res_y_x0 res_endog_w res_endog_x0

* Residuals from W = [1, x, z1, z2]
quietly regress y x z1 z2
predict double `res_y_w', residuals

quietly regress endog x z1 z2
predict double `res_endog_w', residuals

* Residuals from X0 = [1, x]
quietly regress y x
predict double `res_y_x0', residuals

quietly regress endog x
predict double `res_endog_x0', residuals

* Compute quadratic form coefficients
* Numerator part (M_X0 - M_W):
* y'(M_X0-M_W)y = y'M_X0 y - y'M_W y = res_y_x0'res_y_x0 - res_y_w'res_y_w
quietly {
    generate double _yy_x0 = `res_y_x0'^2
    generate double _yy_w = `res_y_w'^2
    generate double _ye_x0 = `res_y_x0'*`res_endog_x0'
    generate double _ye_w = `res_y_w'*`res_endog_w'
    generate double _ee_x0 = `res_endog_x0'^2
    generate double _ee_w = `res_endog_w'^2
    
    summarize _yy_x0, meanonly
    scalar syy_x0 = r(sum)
    summarize _yy_w, meanonly
    scalar syy_w = r(sum)
    summarize _ye_x0, meanonly
    scalar sye_x0 = r(sum)
    summarize _ye_w, meanonly
    scalar sye_w = r(sum)
    summarize _ee_x0, meanonly
    scalar see_x0 = r(sum)
    summarize _ee_w, meanonly
    scalar see_w = r(sum)
}

* Numerator quadratic: A - 2*beta*B + beta^2*C where
scalar A_num = syy_x0 - syy_w
scalar B_num = sye_x0 - sye_w
scalar C_num = see_x0 - see_w

* Denominator quadratic: A_d - 2*beta*B_d + beta^2*C_d where
scalar A_den = syy_w
scalar B_den = sye_w
scalar C_den = see_w

* F(beta) = (n-4)/2 * (A_num - 2*beta*B_num + beta^2*C_num) / (A_den - 2*beta*B_den + beta^2*C_den)
* Set F(beta) = Fcrit:
* (n-4)/2 * Num(beta) = Fcrit * Den(beta)
* (n-4)/2 * (A_num - 2*beta*B_num + beta^2*C_num) = Fcrit*(A_den - 2*beta*B_den + beta^2*C_den)
* Rearranging:
* [C_num*(n-4)/2 - Fcrit*C_den]*beta^2 + [-2*B_num*(n-4)/2 + 2*Fcrit*B_den]*beta + [A_num*(n-4)/2 - Fcrit*A_den] = 0

scalar factor = (`n'-4)/2

scalar qa = factor*C_num - `fcrit'*C_den
scalar qb = -2*factor*B_num + 2*`fcrit'*B_den
scalar qc = factor*A_num - `fcrit'*A_den

scalar discriminant = qb^2 - 4*qa*qc

display "Quadratic coefficients: qa=" qa " qb=" qb " qc=" qc
display "Discriminant=" discriminant
display "fcrit=" `fcrit'

* Compute boundary points
scalar bnd_low = .
scalar bnd_high = .
scalar is_unbounded = 0
scalar is_disjoint = 0

if discriminant >= 0 {
    scalar root1 = (-qb - sqrt(discriminant)) / (2*qa)
    scalar root2 = (-qb + sqrt(discriminant)) / (2*qa)
    
    * Sort roots
    if root1 <= root2 {
        scalar bnd_low = root1
        scalar bnd_high = root2
    }
    else {
        scalar bnd_low = root2
        scalar bnd_high = root1
    }
    
    * Check if qa > 0: parabola opens up, set is between roots (bounded interval)
    * Check if qa < 0: parabola opens down, set is outside roots (unbounded - two disjoint rays or all reals)
    if qa < 0 {
        scalar is_unbounded = 1
    }
}
else {
    * No real roots - either all beta accepted or none
    * Check sign of F at beta=0 vs fcrit
    scalar F_at_0 = factor * A_num / A_den
    if F_at_0 <= `fcrit' {
        * All beta accepted (though this means unbounded)
        scalar is_unbounded = 1
    }
    else {
        * No beta accepted (empty set)
        scalar is_disjoint = 1
    }
}

* Compute F at beta=0 and beta=1
scalar F_at_0_num = factor * A_num
scalar F_at_0_den = A_den
scalar F_at_0 = F_at_0_num / F_at_0_den

scalar F_at_1_num = factor * (A_num - 2*B_num + C_num)
scalar F_at_1_den = (A_den - 2*B_den + C_den)
scalar F_at_1 = F_at_1_num / F_at_1_den

display "F at beta=0: " F_at_0
display "F at beta=1: " F_at_1
display "boundary_low: " bnd_low
display "boundary_high: " bnd_high

* Determine accepts_zero
scalar accepts_zero = 0
if F_at_0 <= `fcrit' {
    scalar accepts_zero = 1
}

display "ANSWER: boundary_low estimate=" %21.12f bnd_low " se=" %21.12f . " n_obs=" %12.0f `n'
display "ANSWER: boundary_high estimate=" %21.12f bnd_high " se=" %21.12f . " n_obs=" %12.0f `n'
display "ANSWER: accepts_zero estimate=" %21.12f accepts_zero " se=" %21.12f . " n_obs=" %12.0f `n'
display "ANSWER: unbounded estimate=" %21.12f is_unbounded " se=" %21.12f . " n_obs=" %12.0f `n'
display "ANSWER: ar_f_at_one estimate=" %21.12f F_at_1 " se=" %21.12f . " n_obs=" %12.0f `n'
