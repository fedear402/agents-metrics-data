set linesize 255
import delimited "./input.csv", clear

sort date

gen log_sales = log(sales)
gen log_vix = log(vix)
gen d_log_vix = log_vix - log_vix[_n-1]

forvalues k = 1/15 {
    gen d_log_vix_lag`k' = d_log_vix[_n-`k']
}

reg log_sales d_log_vix_lag1-d_log_vix_lag15

scalar N = e(N)

newey log_sales d_log_vix_lag1-d_log_vix_lag15, lag(15)

scalar N2 = e(N)

matrix V = e(V)
matrix b = e(b)

* Scale covariance matrix by N/(N-16)
scalar scale = N2 / (N2 - 16)
matrix V_adj = V * scale

* Cumulative response = sum of lag_1 through lag_15 coefficients
scalar cum_resp = 0
forvalues k = 1/15 {
    scalar cum_resp = cum_resp + _b[d_log_vix_lag`k']
}

* SE for cumulative response using full covariance matrix
* sum of all elements in submatrix of V_adj for lags 1-15
scalar var_cum = 0
forvalues i = 1/15 {
    forvalues j = 1/15 {
        scalar var_cum = var_cum + V_adj[`i', `j']
    }
}
scalar se_cum = sqrt(var_cum)

scalar est_lag1 = _b[d_log_vix_lag1]
scalar se_lag1 = sqrt(V_adj[1,1])

scalar est_lag15 = _b[d_log_vix_lag15]
scalar se_lag15 = sqrt(V_adj[15,15])

display "ANSWER: cumulative_response estimate=" %21.12f cum_resp " se=" %21.12f se_cum " n_obs=" %12.0f N2
display "ANSWER: lag_1 estimate=" %21.12f est_lag1 " se=" %21.12f se_lag1 " n_obs=" %12.0f N2
display "ANSWER: lag_15 estimate=" %21.12f est_lag15 " se=" %21.12f se_lag15 " n_obs=" %12.0f N2
