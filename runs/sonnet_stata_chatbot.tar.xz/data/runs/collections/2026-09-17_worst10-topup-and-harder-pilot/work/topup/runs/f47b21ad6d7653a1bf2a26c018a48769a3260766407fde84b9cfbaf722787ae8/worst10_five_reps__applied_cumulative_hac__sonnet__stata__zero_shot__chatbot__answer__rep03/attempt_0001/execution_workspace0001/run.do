set linesize 255
import delimited "./input.csv", clear

* Sort by date
sort date

* Generate log variables
gen log_sales = ln(sales)
gen log_vix = ln(vix)

* Generate first difference of log vix
gen d_log_vix = log_vix - log_vix[_n-1]

* Generate lags 1 through 15
forvalues k = 1/15 {
    gen d_log_vix_lag`k' = d_log_vix[_n-`k']
}

* Run OLS regression with Newey-West SE (lag 15)
* Use every observation with complete set of lagged changes
regress log_sales d_log_vix_lag1-d_log_vix_lag15, nocons
* Actually need intercept
regress log_sales d_log_vix_lag1-d_log_vix_lag15

* Get N
scalar N = e(N)

* Store coefficients
matrix b = e(b)

* Compute Newey-West covariance matrix with Bartlett weights
* We need to compute this manually since Stata's newey uses slightly different formula
* First get residuals from OLS
predict resid, residuals

* Get X matrix
mkmat d_log_vix_lag1-d_log_vix_lag15, matrix(X_vars)
* Add constant
matrix ones = J(rowsof(X_vars), 1, 1)
matrix X = X_vars, ones

* We'll use newey command and then adjust
newey log_sales d_log_vix_lag1-d_log_vix_lag15, lag(15) force

* Get the VCV from newey
matrix V_newey = e(V)

* Newey-West in Stata uses N/(N-k) by default where k is number of regressors
* We need N/(N-16) scaling
* Stata's newey already applies a degrees-of-freedom correction
* Stata newey VCV = sandwich with (N/(N-k)) scaling where k = number of params
* We need (N/(N-16)) scaling
* Number of parameters k = 16 (15 lags + intercept)
* So Stata's default correction is already N/(N-16), which is what we want

scalar N_obs = e(N)
matrix b_newey = e(b)

* Sum of coefficients for lags 1-15 (not including constant)
* b_newey has columns: d_log_vix_lag1 ... d_log_vix_lag15, _cons
* Cumulative response = sum of lag 1 to 15 coefficients
scalar cum_resp = 0
forvalues k = 1/15 {
    scalar cum_resp = cum_resp + b_newey[1, `k']
}

* SE for cumulative response using full covariance matrix
* c'Vc where c is vector of ones for first 15 elements, 0 for constant
matrix c = J(1, 16, 0)
forvalues k = 1/15 {
    matrix c[1, `k'] = 1
}
matrix V_cum = c * V_newey * c'
scalar se_cum = sqrt(V_cum[1,1])

* SE for lag_1 (first coefficient)
scalar se_lag1 = sqrt(V_newey[1,1])

* SE for lag_15 (15th coefficient)
scalar se_lag15 = sqrt(V_newey[15,15])

* Coefficients
scalar coef_lag1 = b_newey[1,1]
scalar coef_lag15 = b_newey[1,15]

* Display results
display "ANSWER: cumulative_response estimate=" %21.12f cum_resp " se=" %21.12f se_cum " n_obs=" %12.0f N_obs
display "ANSWER: lag_1 estimate=" %21.12f coef_lag1 " se=" %21.12f se_lag1 " n_obs=" %12.0f N_obs
display "ANSWER: lag_15 estimate=" %21.12f coef_lag15 " se=" %21.12f se_lag15 " n_obs=" %12.0f N_obs
