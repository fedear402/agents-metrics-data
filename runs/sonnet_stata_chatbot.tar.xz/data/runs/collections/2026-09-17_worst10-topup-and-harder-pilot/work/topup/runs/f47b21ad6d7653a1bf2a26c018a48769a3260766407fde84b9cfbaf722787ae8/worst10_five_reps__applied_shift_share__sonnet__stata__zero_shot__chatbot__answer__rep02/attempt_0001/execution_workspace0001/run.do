set linesize 255
clear all

import delimited "./input.csv", varnames(1)

* Step 1: Normalize regional weights (one obs per region)
bysort region_id: gen first_obs = (_n == 1)
egen total_weight = total(region_weight * first_obs)
gen e_r = region_weight / total_weight

* Step 2: Construct shift-share instrument z_r = sum_n share_rn * shock_n
bysort region_id: gen z_r = .
* For each region, z_r = sum over industries of share * shock
bysort region_id (industry_id): replace z_r = sum(share * shock)
bysort region_id: replace z_r = z_r[_N]

* Verify x, y, z are constant within region (they should be)
* Keep region-level data for weighted means

* Step 3: Compute e_r-weighted regional means
* Use one obs per region
preserve
keep if first_obs == 1

* Weighted means
egen double sum_e = total(e_r)
* Should be 1 after normalization, but let's compute means properly
gen double mean_y = 0
gen double mean_x = 0
gen double mean_z = 0
quietly {
    summarize y [aw=e_r], meanonly
    replace mean_y = r(mean)
    summarize x [aw=e_r], meanonly
    replace mean_x = r(mean)
    summarize z_r [aw=e_r], meanonly
    replace mean_z = r(mean)
}

gen double y0_r = y - mean_y[1]
gen double x0_r = x - mean_x[1]
gen double z0_r = z_r - mean_z[1]

save "/tmp/region_level.dta", replace
restore

* Step 4: Merge region-level residuals back to full data
merge m:1 region_id using "/tmp/region_level.dta", keepusing(y0_r x0_r z0_r e_r) update

* Step 5: Construct industry-level aggregates
* s_n = sum_r e_r * share_rn
bysort industry_id: gen double s_n = .
bysort industry_id: replace s_n = sum(e_r * share)
bysort industry_id: replace s_n = s_n[_N]

* ybar_n = sum_r e_r * share_rn * y0_r / s_n
bysort industry_id: gen double ybar_n = .
bysort industry_id: gen double xbar_n = .
bysort industry_id: gen double zbar_n = .

bysort industry_id: gen double num_y = sum(e_r * share * y0_r)
bysort industry_id: gen double num_x = sum(e_r * share * x0_r)
bysort industry_id: gen double num_z = sum(e_r * share * z0_r)

bysort industry_id: replace ybar_n = num_y[_N] / s_n[_N]
bysort industry_id: replace xbar_n = num_x[_N] / s_n[_N]
bysort industry_id: replace zbar_n = num_z[_N] / s_n[_N]

* Keep one obs per industry
bysort industry_id: keep if (_n == 1)

* Get shock (constant within industry)
* shock is already in data

count
local N_ind = r(N)

* Step 6: Shock-level IV regression for effect
* Regress ybar_n on xbar_n, instrumenting with shock, weighting by s_n
* HC1 variance with multiplier N/(N-2)

* Manual 2SLS at shock level
* First stage: xbar_n on intercept + shock, weights s_n
reg xbar_n shock [aw=s_n]
predict double xbar_hat, xb

* Second stage: ybar_n on intercept + xbar_hat, weights s_n
reg ybar_n xbar_hat [aw=s_n]
scalar beta_effect = _b[xbar_hat]

* Compute IV residuals: u_n = ybar_n - beta_effect * xbar_n - alpha
* alpha = weighted mean of (ybar_n - beta_effect * xbar_n)
gen double fitted_iv = ybar_n - beta_effect * xbar_n
summarize fitted_iv [aw=s_n], meanonly
scalar alpha_effect = r(mean)
gen double resid_iv = ybar_n - alpha_effect - beta_effect * xbar_n

* HC1 SE for shock-level IV
* Variance of beta = (Z'X)^{-1} Z'Omega Z (X'Z)^{-1} * N/(N-2)
* where Z = shock (demeaned), X = xbar_n (demeaned), weights s_n

* Demean shock and xbar_n by s_n weights
summarize shock [aw=s_n], meanonly
scalar mean_shock = r(mean)
gen double shock_dm = shock - mean_shock

summarize xbar_n [aw=s_n], meanonly
scalar mean_xbar = r(mean)
gen double xbar_dm = xbar_n - mean_xbar

* ZX = sum s_n * shock_dm * xbar_dm
gen double zx_term = s_n * shock_dm * xbar_dm
summarize zx_term, meanonly
scalar ZX = r(sum)

* ZZ = sum s_n * shock_dm^2
gen double zz_term = s_n * shock_dm^2
summarize zz_term, meanonly
scalar ZZ = r(sum)

* Sandwich: sum s_n^2 * shock_dm^2 * resid_iv^2 (HC1 meat, weighted)
* HC1: multiply by N/(N-2)
gen double meat_term = s_n * shock_dm * resid_iv
gen double meat_sq = meat_term^2
summarize meat_sq, meanonly
scalar meat_effect = r(sum)

* Var(beta) = (1/ZX)^2 * meat * N/(N-2)
scalar var_effect = (1/ZX)^2 * meat_effect * (`N_ind' / (`N_ind' - 2))
scalar se_effect = sqrt(var_effect)

* Step 7: First-stage regression
* Regional first-stage: x_r on z_r, weights e_r
* At shock level: xbar_n on zbar_n, instrumenting with shock_n, weights s_n

* First stage of shock-level IV for first_stage
* Instrument: shock, endogenous: zbar_n, dependent: xbar_n
reg zbar_n shock [aw=s_n]
predict double zbar_hat, xb

reg xbar_n zbar_hat [aw=s_n]
scalar beta_fs = _b[zbar_hat]

* IV residuals for first stage
gen double fitted_fs_iv = xbar_n - beta_fs * zbar_n
summarize fitted_fs_iv [aw=s_n], meanonly
scalar alpha_fs = r(mean)
gen double resid_fs_iv = xbar_n - alpha_fs - beta_fs * zbar_n

* HC1 SE
* Z = shock_dm, X = zbar_n demeaned
summarize zbar_n [aw=s_n], meanonly
scalar mean_zbar = r(mean)
gen double zbar_dm = zbar_n - mean_zbar

* ZX_fs = sum s_n * shock_dm * zbar_dm
gen double zx_fs_term = s_n * shock_dm * zbar_dm
summarize zx_fs_term, meanonly
scalar ZX_fs = r(sum)

gen double meat_fs_term = s_n * shock_dm * resid_fs_iv
gen double meat_fs_sq = meat_fs_term^2
summarize meat_fs_sq, meanonly
scalar meat_fs = r(sum)

scalar var_fs = (1/ZX_fs)^2 * meat_fs * (`N_ind' / (`N_ind' - 2))
scalar se_fs = sqrt(var_fs)

* Step 8: Effective shocks = 1 / sum_n s_n^2
gen double s_n_sq = s_n^2
summarize s_n_sq, meanonly
scalar eff_shocks = 1 / r(sum)

* Report results
display "ANSWER: effect estimate=" %21.12f beta_effect " se=" %21.12f se_effect " n_obs=" %12.0f `N_ind'
display "ANSWER: first_stage estimate=" %21.12f beta_fs " se=" %21.12f se_fs " n_obs=" %12.0f `N_ind'
display "ANSWER: effective_shocks estimate=" %21.12f eff_shocks " se=" %21.12f . " n_obs=" %12.0f `N_ind'
