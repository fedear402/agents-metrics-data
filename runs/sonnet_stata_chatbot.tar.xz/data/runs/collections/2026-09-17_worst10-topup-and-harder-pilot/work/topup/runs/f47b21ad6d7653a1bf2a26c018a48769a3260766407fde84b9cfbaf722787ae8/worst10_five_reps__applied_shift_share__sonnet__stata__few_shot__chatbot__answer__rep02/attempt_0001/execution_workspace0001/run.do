version 16
clear all
set more off
set linesize 255

import delimited "./input.csv", clear varnames(1)

// Normalize regional weights (one obs per region)
bysort region_id: keep if _n == 1
egen total_weight = total(region_weight)
gen e_r = region_weight / total_weight
keep region_id e_r
tempfile weights
save `weights'

import delimited "./input.csv", clear varnames(1)
merge m:1 region_id using `weights', nogen

// Compute regional means weighted by e_r (one obs per region for means)
// First get unique region-level data
bysort region_id: gen region_tag = (_n == 1)

// Weighted means of y, x, z at region level
// z_r = sum_n share_rn * shock_n (region-level instrument)
bysort region_id: egen z_r = total(share * shock)

// Get region-level variables (y, x, z are constant within region)
// Compute weighted means
gen ey = e_r * y
gen ex_val = e_r * x
gen ez = e_r * z_r

// Sum over regions (using region_tag to avoid double counting)
egen mean_y = total(ey * region_tag)
egen mean_x = total(ex_val * region_tag)
egen mean_z = total(ez * region_tag)

// Demeaned variables
gen y0 = y - mean_y
gen x0 = x - mean_x
gen z0 = z_r - mean_z

// Industry-level aggregation
// s_n = sum_r e_r * share_rn
bysort industry_id: egen s_n = total(e_r * share)

// Aggregate residuals: vbar_n = sum_r e_r * share_rn * v0_r / s_n
gen ey0_contrib = e_r * share * y0
gen ex0_contrib = e_r * share * x0
gen ez0_contrib = e_r * share * z0

bysort industry_id: egen ybar_num = total(ey0_contrib)
bysort industry_id: egen xbar_num = total(ex0_contrib)
bysort industry_id: egen zbar_num = total(ez0_contrib)

gen ybar_n = ybar_num / s_n
gen xbar_n = xbar_num / s_n
gen zbar_n = zbar_num / s_n

// Keep one obs per industry
bysort industry_id: keep if _n == 1
// Get shock (constant within industry)
keep industry_id s_n ybar_n xbar_n zbar_n shock

// Number of industries
count
local N = r(N)

// Now run shock-level IV regressions using mata
mata:
    st_view(s_n, ., "s_n")
    st_view(ybar, ., "ybar_n")
    st_view(xbar, ., "xbar_n")
    st_view(zbar, ., "zbar_n")
    st_view(shk, ., "shock")
    
    N = rows(s_n)
    
    // === Effect: IV of ybar on (1, xbar), instrument (1, shock), weights s_n ===
    dep = ybar
    endog = xbar
    regressors = (J(N,1,1), endog)
    instruments = (J(N,1,1), shk)
    
    cross = instruments' * (s_n :* regressors)
    inv_cross = luinv(cross)
    beta_effect = inv_cross * (instruments' * (s_n :* dep))
    
    resid_effect = dep - regressors * beta_effect
    scores_effect = instruments :* (s_n :* resid_effect)
    V_effect = N/(N-2) * inv_cross * (scores_effect' * scores_effect) * inv_cross'
    
    effect_est = beta_effect[2]
    effect_se = sqrt(V_effect[2,2])
    
    // === First stage: IV of xbar on (1, zbar), instrument (1, shock), weights s_n ===
    // Here zbar is the endogenous regressor
    dep2 = xbar
    endog2 = zbar
    regressors2 = (J(N,1,1), endog2)
    instruments2 = (J(N,1,1), shk)
    
    cross2 = instruments2' * (s_n :* regressors2)
    inv_cross2 = luinv(cross2)
    beta_fs = inv_cross2 * (instruments2' * (s_n :* dep2))
    
    resid_fs = dep2 - regressors2 * beta_fs
    scores_fs = instruments2 :* (s_n :* resid_fs)
    V_fs = N/(N-2) * inv_cross2 * (scores_fs' * scores_fs) * inv_cross2'
    
    fs_est = beta_fs[2]
    fs_se = sqrt(V_fs[2,2])
    
    // === Effective shocks = 1/sum(s_n^2) ===
    eff_shocks = 1 / sum(s_n:^2)
    
    st_numscalar("effect_est", effect_est)
    st_numscalar("effect_se", effect_se)
    st_numscalar("fs_est", fs_est)
    st_numscalar("fs_se", fs_se)
    st_numscalar("eff_shocks", eff_shocks)
    st_numscalar("N_ind", N)
end

display "ANSWER: effect estimate=" %21.12f effect_est " se=" %21.12f effect_se " n_obs=" %12.0f N_ind
display "ANSWER: first_stage estimate=" %21.12f fs_est " se=" %21.12f fs_se " n_obs=" %12.0f N_ind
display "ANSWER: effective_shocks estimate=" %21.12f eff_shocks " se=" %21.12f . " n_obs=" %12.0f N_ind
