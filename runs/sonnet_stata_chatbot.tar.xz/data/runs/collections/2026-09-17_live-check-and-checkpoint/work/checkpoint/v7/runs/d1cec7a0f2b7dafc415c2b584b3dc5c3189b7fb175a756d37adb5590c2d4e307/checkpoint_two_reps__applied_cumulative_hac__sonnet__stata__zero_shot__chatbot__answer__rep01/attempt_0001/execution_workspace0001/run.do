set linesize 255
import delimited "./input.csv", clear

gen log_sales = log(sales)
gen log_vix = log(vix)

sort date

gen d_log_vix = log_vix - log_vix[_n-1]

forvalues k = 1/15 {
    gen d_log_vix_lag`k' = d_log_vix[_n-`k']
}

regress log_sales d_log_vix_lag1 d_log_vix_lag2 d_log_vix_lag3 d_log_vix_lag4 d_log_vix_lag5 d_log_vix_lag6 d_log_vix_lag7 d_log_vix_lag8 d_log_vix_lag9 d_log_vix_lag10 d_log_vix_lag11 d_log_vix_lag12 d_log_vix_lag13 d_log_vix_lag14 d_log_vix_lag15

scalar N = e(N)

* Get coefficients
scalar b1  = _b[d_log_vix_lag1]
scalar b2  = _b[d_log_vix_lag2]
scalar b3  = _b[d_log_vix_lag3]
scalar b4  = _b[d_log_vix_lag4]
scalar b5  = _b[d_log_vix_lag5]
scalar b6  = _b[d_log_vix_lag6]
scalar b7  = _b[d_log_vix_lag7]
scalar b8  = _b[d_log_vix_lag8]
scalar b9  = _b[d_log_vix_lag9]
scalar b10 = _b[d_log_vix_lag10]
scalar b11 = _b[d_log_vix_lag11]
scalar b12 = _b[d_log_vix_lag12]
scalar b13 = _b[d_log_vix_lag13]
scalar b14 = _b[d_log_vix_lag14]
scalar b15 = _b[d_log_vix_lag15]

scalar cum_response = b1 + b2 + b3 + b4 + b5 + b6 + b7 + b8 + b9 + b10 + b11 + b12 + b13 + b14 + b15

* Compute Newey-West HAC covariance with max lag 15, Bartlett weights 1-j/16
* Manual implementation
* First get OLS residuals
predict double resid, residuals

* Get X matrix - need to work with the estimation sample
* Use matrix approach
matrix b_vec = e(b)
local varlist d_log_vix_lag1 d_log_vix_lag2 d_log_vix_lag3 d_log_vix_lag4 d_log_vix_lag5 d_log_vix_lag6 d_log_vix_lag7 d_log_vix_lag8 d_log_vix_lag9 d_log_vix_lag10 d_log_vix_lag11 d_log_vix_lag12 d_log_vix_lag13 d_log_vix_lag14 d_log_vix_lag15

* Mark estimation sample
gen byte esample = e(sample)

* We need X'X and the meat of the sandwich
* X includes intercept + 15 regressors = 16 columns
* Number of regressors p = 16
local p = 16

* Create temporary variables for X*e (score variables)
* intercept * resid
gen double score0 = resid if esample

forvalues k = 1/15 {
    gen double score`k' = d_log_vix_lag`k' * resid if esample
}

* Compute X'X inverse (already have from OLS: (X'X)^{-1} = e(V) * (N-p) / scalar(N) ... 
* Actually e(V) = s^2 * (X'X)^{-1} where s^2 = RSS/(N-p)
* So (X'X)^{-1} = e(V) / e(rmse)^2

matrix V_ols = e(V)
scalar rmse = e(rmse)
matrix XtXinv = V_ols / (rmse^2)

* Now compute the meat: S = sum_t score_t score_t' + sum_{j=1}^{15} w_j * sum_t (score_t score_{t-j}' + score_{t-j} score_t')
* where w_j = 1 - j/16

* Store scores in a matrix
* First, figure out the observations in the estimation sample
* We'll compute this numerically

* Compute S matrix (16x16)
* Initialize S as zero matrix
matrix S = J(16, 16, 0)

* Contemporaneous term
forvalues i = 0/15 {
    forvalues j = 0/15 {
        quietly summarize score`i' if esample, meanonly
        * Need sum of products
        quietly gen double tmp_ij = score`i' * score`j' if esample
        quietly summarize tmp_ij if esample, meanonly
        matrix S[`i'+1, `j'+1] = r(sum)
        drop tmp_ij
    }
}

* Cross terms for lags 1 through 15
forvalues lag = 1/15 {
    scalar w`lag' = 1 - `lag'/16
    
    * Create lagged scores
    forvalues k = 0/15 {
        quietly gen double score`k'_lag`lag' = score`k'[_n-`lag'] if esample
        * But need to be careful: only use obs where both t and t-lag are in esample
        quietly replace score`k'_lag`lag' = . if esample[_n-`lag'] != 1 | _n <= `lag'
    }
    
    * Add cross terms
    forvalues i = 0/15 {
        forvalues j = 0/15 {
            quietly gen double tmp_cross = score`i' * score`j'_lag`lag' if esample
            quietly summarize tmp_cross if esample, meanonly
            scalar cross_ij = r(sum)
            matrix S[`i'+1, `j'+1] = S[`i'+1, `j'+1] + w`lag' * (cross_ij + cross_ij)
            drop tmp_cross
        }
    }
    
    forvalues k = 0/15 {
        drop score`k'_lag`lag'
    }
}

* Adjust S: multiply by N/(N-16)
scalar adj = N / (N - 16)
matrix S = S * adj

* Compute NW covariance: V_NW = (X'X)^{-1} S (X'X)^{-1}
matrix V_NW = XtXinv * S * XtXinv

* Now compute standard errors
* lag_1 is coefficient 2 (index 2, after intercept)
* lag_15 is coefficient 16 (index 16)
scalar se_lag1  = sqrt(V_NW[2, 2])
scalar se_lag15 = sqrt(V_NW[16, 16])

* Cumulative response SE: c = vector of ones for lags 1-15, zeros for intercept
* c'V_NW c where c = (0, 1, 1, ..., 1) with 1s in positions 2-16
matrix c = J(1, 16, 1)
matrix c[1,1] = 0
matrix var_cum = c * V_NW * c'
scalar se_cum = sqrt(var_cum[1,1])

display "ANSWER: cumulative_response estimate=" %21.12f cum_response " se=" %21.12f se_cum " n_obs=" %12.0f N
display "ANSWER: lag_1 estimate=" %21.12f b1 " se=" %21.12f se_lag1 " n_obs=" %12.0f N
display "ANSWER: lag_15 estimate=" %21.12f b15 " se=" %21.12f se_lag15 " n_obs=" %12.0f N
