version 17.0
clear all
set more off
set linesize 255

import delimited "./input.csv", clear

keep if abs(score) < 1
gen w = 1 - abs(score)
gen above = (score >= 0)
gen score_above = score * above
gen score_below = score * (1 - above)

local n = _N

mata:
    st_view(Y=., ., ("earnings","participated"))
    st_view(w=., ., "w")
    st_view(above=., ., "above")
    st_view(score_above=., ., "score_above")
    st_view(score_below=., ., "score_below")
    
    n = rows(Y)
    
    // Design matrix: intercept, above, score_below, score_above
    X = (J(n,1,1), above, score_below, score_above)
    
    WX = w :* X
    bread = invsym(X' * WX)
    coefficients = bread * (WX' * Y)
    residuals = Y - X * coefficients
    
    // Contrast for right minus left at cutoff: coefficient on "above"
    contrast = (0 \ 1 \ 0 \ 0)
    
    jumps = contrast' * coefficients
    
    loading = w :* (X * bread * contrast)
    influence = loading :* residuals
    
    joint = influence' * influence
    
    gradient = (1/jumps[2] \ -jumps[1]/jumps[2]^2)
    ratio_se = sqrt(gradient' * joint * gradient)
    
    st_numscalar("b_reduced", jumps[1])
    st_numscalar("b_first", jumps[2])
    st_numscalar("b_ratio", jumps[1]/jumps[2])
    st_numscalar("se_reduced", sqrt(joint[1,1]))
    st_numscalar("se_first", sqrt(joint[2,2]))
    st_numscalar("se_ratio", ratio_se)
end

display "ANSWER: treatment_effect estimate=" %21.12f b_ratio " se=" %21.12f se_ratio " n_obs=" %12.0f `n'
display "ANSWER: reduced_form estimate=" %21.12f b_reduced " se=" %21.12f se_reduced " n_obs=" %12.0f `n'
display "ANSWER: first_stage estimate=" %21.12f b_first " se=" %21.12f se_first " n_obs=" %12.0f `n'
