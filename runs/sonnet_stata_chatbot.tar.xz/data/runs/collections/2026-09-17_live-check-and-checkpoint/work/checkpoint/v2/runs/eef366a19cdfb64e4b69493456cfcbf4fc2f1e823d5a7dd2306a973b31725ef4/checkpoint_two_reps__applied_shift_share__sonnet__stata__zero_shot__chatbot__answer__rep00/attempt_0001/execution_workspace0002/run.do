set linesize 255
clear all

* Load data
import delimited "./input.csv", clear

* Step 1: Normalize regional weights (one obs per region)
* Get unique region-level data
bysort region_id: keep if _n == 1
keep region_id region_weight x y
rename region_weight rw

* Normalize weights
quietly sum rw
scalar total_w = r(sum)
gen e_r = rw / total_w

* Save region-level data
tempfile region_data
save `region_data'

* Reload full data
import delimited "./input.csv", clear

* Merge normalized weights
merge m:1 region_id using `region_data', keepusing(e_r) nogenerate

* Step 2: Construct shift-share instrument z_r = sum_n share_rn * shock_n
* Compute z_r for each region
bysort region_id: gen weighted_shock = share * shock
bysort region_id: egen z_r = sum(weighted_shock)

* Step 3: Get one obs per region for regional regression
bysort region_id: keep if _n == 1
keep region_id e_r x y z_r

* Step 4: Weighted 2SLS - compute e_r weighted means
quietly sum x [aw=e_r]
scalar mean_x = r(mean)
quietly sum y [aw=e_r]
scalar mean_y = r(mean)
quietly sum z_r [aw=e_r]
scalar mean_z = r(mean)

* Demean
gen x0 = x - mean_x
gen y0 = y - mean_y
gen z0 = z_r - mean_z

* Regional 2SLS slope: beta = (sum e_r * z0 * y0) / (sum e_r * z0 * x0)
gen ez0y0 = e_r * z0 * y0
gen ez0x0 = e_r * z0 * x0
quietly sum ez0y0
scalar num_2sls = r(sum)
quietly sum ez0x0
scalar den_2sls = r(sum)
scalar beta_2sls = num_2sls / den_2sls

* Regional first-stage slope: gamma = (sum e_r * z0 * z0) / (sum e_r * z0 * x0) -- wait
* First stage: x_r on z_r, so slope = (sum e_r * z0 * x0) / (sum e_r * z0^2)
* Actually first stage: x on z, instrument z with z (OLS of x on z weighted by e_r)
gen ez0z0 = e_r * z0 * z0
quietly sum ez0z0
scalar den_fs = r(sum)
* For first stage: slope = Cov(z,x)/Var(z) with e_r weights
scalar gamma_fs = den_2sls / den_fs

* Step 5: Shock-level aggregation for SE
* Need to merge back with industry data
* Reload full data
import delimited "./input.csv", clear
merge m:1 region_id using `region_data', keepusing(e_r) nogenerate

* Construct z_r
bysort region_id: gen weighted_shock = share * shock
bysort region_id: egen z_r = sum(weighted_shock)

* Get regional means
bysort region_id: keep if _n == 1
keep region_id e_r x y z_r

quietly sum x [aw=e_r]
scalar mean_x2 = r(mean)
quietly sum y [aw=e_r]
scalar mean_y2 = r(mean)
quietly sum z_r [aw=e_r]
scalar mean_z2 = r(mean)

gen x0 = x - mean_x2
gen y0 = y - mean_y2
gen z0 = z_r - mean_z2

tempfile region_demeaned
save `region_demeaned'

* Reload full data for industry aggregation
import delimited "./input.csv", clear
merge m:1 region_id using `region_data', keepusing(e_r) nogenerate

* Merge demeaned regional vars
merge m:1 region_id using `region_demeaned', keepusing(x0 y0 z0) nogenerate

* Compute s_n = sum_r e_r * share_rn
gen e_share = e_r * share
bysort industry_id: egen s_n = sum(e_share)

* Aggregate residuals: vbar_n = sum_r e_r * share_rn * v0_r / s_n
gen ey0 = e_r * share * y0
gen ex0 = e_r * share * x0
gen ez0 = e_r * share * z0

bysort industry_id: egen sum_ey0 = sum(ey0)
bysort industry_id: egen sum_ex0 = sum(ex0)
bysort industry_id: egen sum_ez0 = sum(ez0)

gen ybar_n = sum_ey0 / s_n
gen xbar_n = sum_ex0 / s_n
gen zbar_n = sum_ez0 / s_n

* Keep one obs per industry
bysort industry_id: keep if _n == 1
keep industry_id s_n ybar_n xbar_n zbar_n shock

* Number of industries
quietly count
scalar N_ind = r(N)

* Effective shocks
gen sn2 = s_n^2
quietly sum sn2
scalar eff_shocks = 1 / r(sum)

* Shock-level IV for effect: regress ybar_n on xbar_n, instrument with shock_n, weight s_n
* Slope = beta_2sls (should match)
* First stage of shock-level IV: xbar_n on shock_n
gen s_shock = s_n * shock
gen s_shock2 = s_n * shock^2
gen s_xbar_shock = s_n * xbar_n * shock

quietly sum s_shock
scalar sum_sw = r(sum)
quietly sum s_n
scalar sum_s = r(sum)
* Weighted mean of shock
scalar mean_shock_w = sum_sw / sum_s
gen shock_dm = shock - mean_shock_w

* Weighted mean of xbar
gen s_xbar = s_n * xbar_n
quietly sum s_xbar
scalar sum_sxbar = r(sum)
scalar mean_xbar_w = sum_sxbar / sum_s
gen xbar_dm = xbar_n - mean_xbar_w

* Weighted mean of ybar
gen s_ybar = s_n * ybar_n
quietly sum s_ybar
scalar sum_sybar = r(sum)
scalar mean_ybar_w = sum_sybar / sum_s
gen ybar_dm = ybar_n - mean_ybar_w

* Weighted mean of zbar
gen s_zbar = s_n * zbar_n
quietly sum s_zbar
scalar sum_szbar = r(sum)
scalar mean_zbar_w = sum_szbar / sum_s
gen zbar_dm = zbar_n - mean_zbar_w

* Shock-level IV for effect: instrument xbar_dm with shock_dm
gen sn_shock_dm_ybar_dm = s_n * shock_dm * ybar_dm
gen sn_shock_dm_xbar_dm = s_n * shock_dm * xbar_dm
quietly sum sn_shock_dm_ybar_dm
scalar num_iv = r(sum)
quietly sum sn_shock_dm_xbar_dm
scalar den_iv = r(sum)
scalar beta_iv_check = num_iv / den_iv

* HC1 SE for effect
* IV residuals: u_n = ybar_dm - beta_2sls * xbar_dm
gen u_n = ybar_dm - beta_2sls * xbar_dm

* Meat of sandwich: sum_n s_n^2 * shock_dm_n^2 * u_n^2
gen meat_term = s_n^2 * shock_dm^2 * u_n^2
quietly sum meat_term
scalar meat_eff = r(sum)

* Bread: (sum_n s_n * shock_dm_n * xbar_dm_n)^2
scalar bread_eff = den_iv^2

* HC1 multiplier: N/(N-2)
scalar hc1_mult = N_ind / (N_ind - 2)

* Variance of beta
scalar var_beta = hc1_mult * meat_eff / bread_eff
scalar se_beta = sqrt(var_beta)

* Shock-level IV for first stage: xbar_n on zbar_n, instrument with shock_n
* First stage slope: gamma = (sum s_n * shock_dm * xbar_dm) / (sum s_n * shock_dm * zbar_dm)
gen sn_shock_dm_zbar_dm = s_n * shock_dm * zbar_dm
quietly sum sn_shock_dm_zbar_dm
scalar den_fs2 = r(sum)
scalar gamma_iv = den_iv / den_fs2

* HC1 SE for first stage
* First stage IV residuals: v_n = xbar_dm - gamma_fs * zbar_dm
gen v_n = xbar_dm - gamma_fs * zbar_dm

gen meat_fs = s_n^2 * shock_dm^2 * v_n^2
quietly sum meat_fs
scalar meat_fs_val = r(sum)

scalar bread_fs = den_fs2^2
scalar var_gamma = hc1_mult * meat_fs_val / bread_fs
scalar se_gamma = sqrt(var_gamma)

* Report results
display "ANSWER: effect estimate=" %21.12f beta_2sls " se=" %21.12f se_beta " n_obs=" %12.0f N_ind
display "ANSWER: first_stage estimate=" %21.12f gamma_fs " se=" %21.12f se_gamma " n_obs=" %12.0f N_ind
display "ANSWER: effective_shocks estimate=" %21.12f eff_shocks " se=" %21.12f . " n_obs=" %12.0f N_ind
