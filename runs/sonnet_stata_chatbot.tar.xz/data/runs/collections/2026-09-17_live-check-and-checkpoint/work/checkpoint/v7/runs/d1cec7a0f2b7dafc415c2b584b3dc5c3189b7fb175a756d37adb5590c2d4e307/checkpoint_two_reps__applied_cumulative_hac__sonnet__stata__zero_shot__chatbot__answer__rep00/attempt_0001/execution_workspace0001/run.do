set linesize 255
import delimited "./input.csv", clear

gen log_sales = ln(sales)
gen log_vix = ln(vix)

sort date
gen d_log_vix = log_vix - log_vix[_n-1]

forvalues k = 1/15 {
    gen dlv_lag`k' = d_log_vix[_n-`k']
}

regress log_sales dlv_lag1-dlv_lag15

scalar N = e(N)

* Newey-West with manual Bartlett weights, max lag 15, multiplied by N/(N-16)
* Use newey command with lag(15)
newey log_sales dlv_lag1-dlv_lag15, lag(15)

scalar N = e(N)

* Get coefficient matrix
matrix b = e(b)
matrix V = e(V)

* Adjust variance by N/(N-16)
matrix V_adj = V * (N / (N - 16))

* Cumulative response = sum of all 15 lag coefficients
scalar cum_resp = 0
forvalues k = 1/15 {
    scalar cum_resp = cum_resp + _b[dlv_lag`k']
}

* SE for cumulative response using full covariance matrix
* sum of coefficients variance = sum_i sum_j V[i,j] for i,j in 1..15
scalar var_cum = 0
forvalues i = 1/15 {
    forvalues j = 1/15 {
        scalar var_cum = var_cum + V_adj[`i', `j']
    }
}
scalar se_cum = sqrt(var_cum)

* SE for lag_1 (position 1 in coefficient vector)
scalar se_lag1 = sqrt(V_adj[1,1])

* SE for lag_15 (position 15 in coefficient vector)
scalar se_lag15 = sqrt(V_adj[15,15])

scalar b_lag1 = _b[dlv_lag1]
scalar b_lag15 = _b[dlv_lag15]

display "ANSWER: cumulative_response estimate=" %21.12f cum_resp " se=" %21.12f se_cum " n_obs=" %12.0f N
display "ANSWER: lag_1 estimate=" %21.12f b_lag1 " se=" %21.12f se_lag1 " n_obs=" %12.0f N
display "ANSWER: lag_15 estimate=" %21.12f b_lag15 " se=" %21.12f se_lag15 " n_obs=" %12.0f N
