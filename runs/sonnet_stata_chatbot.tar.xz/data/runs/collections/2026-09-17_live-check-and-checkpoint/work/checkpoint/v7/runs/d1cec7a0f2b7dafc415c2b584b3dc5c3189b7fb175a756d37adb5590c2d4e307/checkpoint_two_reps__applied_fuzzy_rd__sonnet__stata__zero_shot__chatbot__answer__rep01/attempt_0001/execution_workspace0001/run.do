set linesize 255
import delimited "./input.csv", clear

// Keep observations within bandwidth
keep if abs(score) < 1

// Count observations
quietly count
scalar n_obs = r(N)

// Triangular weights
generate weight = 1 - abs(score)

// Indicator for right side (score >= 0)
generate right = (score >= 0)

// Interactions for local linear regression
generate score_right = score * right
generate score_left = score * (1 - right)

// WLS regression for earnings (reduced form)
regress earnings right score_left score_right [aw=weight], vce(hc0)
scalar rf_est = _b[right]
scalar rf_se = _se[right]

// Save coefficient vector and variance matrix for earnings
matrix b_rf = e(b)
matrix V_rf = e(V)

// WLS regression for participation (first stage)
regress participated right score_left score_right [aw=weight], vce(hc0)
scalar fs_est = _b[right]
scalar fs_se = _se[right]

matrix b_fs = e(b)
matrix V_fs = e(V)

// For delta method, need joint covariance of rf and fs discontinuity estimates
// Stack the two regressions to get joint covariance
// Use seemingly unrelated regression approach via sureg

sureg (earnings right score_left score_right) (participated right score_left score_right) [aw=weight], vce(hc0)

// Extract estimates
scalar rf_est2 = _b[earnings:right]
scalar fs_est2 = _b[participated:right]

// Get variance-covariance
matrix V_joint = e(V)

// Indices: earnings eq has right at position 1 (after constant? let's check)
// In sureg, ordering is: eq1 vars then eq2 vars
// earnings: right score_left score_right _cons = positions 1,2,3,4
// participated: right score_left score_right _cons = positions 5,6,7,8

scalar var_rf = V_joint[1,1]
scalar var_fs = V_joint[5,5]
scalar cov_rf_fs = V_joint[1,5]

// Treatment effect via delta method
// TE = rf/fs
// d(TE)/d(rf) = 1/fs
// d(TE)/d(fs) = -rf/fs^2
scalar te_est = rf_est2 / fs_est2
scalar d_rf = 1 / fs_est2
scalar d_fs = -rf_est2 / (fs_est2^2)
scalar var_te = d_rf^2 * var_rf + d_fs^2 * var_fs + 2 * d_rf * d_fs * cov_rf_fs
scalar te_se = sqrt(var_te)

scalar rf_se2 = sqrt(var_rf)
scalar fs_se2 = sqrt(var_fs)

display "ANSWER: treatment_effect estimate=" %21.12f te_est " se=" %21.12f te_se " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f rf_est2 " se=" %21.12f rf_se2 " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f fs_est2 " se=" %21.12f fs_se2 " n_obs=" %12.0f n_obs
