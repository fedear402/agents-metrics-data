version 17.0
clear all
set more off
set linesize 255

import delimited "./input.csv", clear varnames(1)

// Normalize regional weights (one obs per region)
bysort region_id: gen first_in_region = (_n == 1)
quietly sum region_weight if first_in_region
local sum_w = r(sum)
gen e_r = region_weight / `sum_w'

// Construct shift-share instrument z_r = sum_n share_rn * shock_n
bysort region_id: gen z_r_contrib = share * shock
bysort region_id: egen z_r = sum(z_r_contrib)

// Keep one observation per region for regional-level computations
// but we need region-level variables
// Weighted regional means
quietly sum y [aw=e_r] if first_in_region
local mean_y = r(mean)
quietly sum x [aw=e_r] if first_in_region
local mean_x = r(mean)
quietly sum z_r [aw=e_r] if first_in_region
local mean_z = r(mean)

// Demeaned regional variables
gen y0 = y - `mean_y'
gen x0 = x - `mean_x'
gen z0 = z_r - `mean_z'

// Industry-level aggregation
// s_n = sum_r e_r * share_rn
gen e_share = e_r * share
bysort industry_id: egen s_n = sum(e_share)

// ybar_n = sum_r e_r * share_rn * y0_r / s_n
gen e_share_y0 = e_r * share * y0
gen e_share_x0 = e_r * share * x0
gen e_share_z0 = e_r * share * z0

bysort industry_id: egen num_ybar = sum(e_share_y0)
bysort industry_id: egen num_xbar = sum(e_share_x0)
bysort industry_id: egen num_zbar = sum(e_share_z0)

gen ybar = num_ybar / s_n
gen xbar = num_xbar / s_n
gen zbar = num_zbar / s_n

// Keep one obs per industry
bysort industry_id: gen first_in_industry = (_n == 1)
keep if first_in_industry

// Number of industries
count
local N = r(N)

// === Shock-level IV regression: ybar on intercept + xbar, IV = shock, weight = s_n ===
// This gives the effect (2SLS slope)
// Manual IV: beta = (Z'WX)^{-1} Z'Wy where Z includes intercept and shock
// Regressors: (1, xbar), Instruments: (1, shock), Weights: s_n

mata:
    st_view(ybar, ., "ybar")
    st_view(xbar, ., "xbar")
    st_view(zbar, ., "zbar")
    st_view(shock, ., "shock")
    st_view(s_n, ., "s_n")
    
    N = rows(ybar)
    
    // Effect regression: y on (1,x), IV (1,shock), weights s_n
    X_reg = (J(N,1,1), xbar)
    Z_inst = (J(N,1,1), shock)
    W = s_n
    
    ZWX = Z_inst' * (W :* X_reg)
    ZWy = Z_inst' * (W :* ybar)
    beta_effect = luinv(ZWX) * ZWy
    
    resid_effect = ybar - X_reg * beta_effect
    scores_effect = Z_inst :* (W :* resid_effect)
    meat_effect = scores_effect' * scores_effect
    bread_effect = luinv(ZWX)
    // HC1: N/(N-2)
    V_effect = (N/(N-2)) * bread_effect * meat_effect * bread_effect'
    
    se_effect = sqrt(V_effect[2,2])
    est_effect = beta_effect[2]
    
    // First-stage regression: x on (1,z), IV (1,shock), weights s_n
    // Endogenous regressor is zbar, instrument is shock
    X_fs = (J(N,1,1), zbar)
    Z_fs = (J(N,1,1), shock)
    
    ZWX_fs = Z_fs' * (W :* X_fs)
    ZWy_fs = Z_fs' * (W :* xbar)
    beta_fs = luinv(ZWX_fs) * ZWy_fs
    
    resid_fs = xbar - X_fs * beta_fs
    scores_fs = Z_fs :* (W :* resid_fs)
    meat_fs = scores_fs' * scores_fs
    bread_fs = luinv(ZWX_fs)
    V_fs = (N/(N-2)) * bread_fs * meat_fs * bread_fs'
    
    se_fs = sqrt(V_fs[2,2])
    est_fs = beta_fs[2]
    
    // Effective shocks = 1/sum(s_n^2)
    eff_shocks = 1/sum(s_n:^2)
    
    st_numscalar("est_effect", est_effect)
    st_numscalar("se_effect", se_effect)
    st_numscalar("est_fs", est_fs)
    st_numscalar("se_fs", se_fs)
    st_numscalar("eff_shocks", eff_shocks)
    st_numscalar("N_ind", N)
end

display "ANSWER: effect estimate=" %21.12f est_effect " se=" %21.12f se_effect " n_obs=" %12.0f N_ind
display "ANSWER: first_stage estimate=" %21.12f est_fs " se=" %21.12f se_fs " n_obs=" %12.0f N_ind
display "ANSWER: effective_shocks estimate=" %21.12f eff_shocks " se=" %21.12f . " n_obs=" %12.0f N_ind
