clear all
set more off
set linesize 255
set type double

import delimited "./input.csv", clear

quietly regress y
predict double ry, residuals
quietly regress endog
predict double rd, residuals
quietly regress y x z1 z2
predict double uy, residuals
scalar df = e(df_r)
quietly regress endog x z1 z2
predict double ud, residuals

scalar q = 2
scalar critical = invFtail(q, df, .05)
scalar k = q * critical / df
scalar n_obs = _N

mata:
    ry = st_data(., "ry")
    rd = st_data(., "rd")
    uy = st_data(., "uy")
    ud = st_data(., "ud")
    k  = st_numscalar("k")

    A = quadcross(rd, rd) - (1 + k) * quadcross(ud, ud)
    B = -2 * (quadcross(ry, rd) - (1 + k) * quadcross(uy, ud))
    C = quadcross(ry, ry) - (1 + k) * quadcross(uy, uy)

    disc = B^2 - 4*A*C

    if (abs(A) > 1e-10 & disc > 0) {
        r1 = (-B - sqrt(disc)) / (2*A)
        r2 = (-B + sqrt(disc)) / (2*A)
        bounds = sort((r1 \ r2), 1)
        st_numscalar("low",  bounds[1])
        st_numscalar("high", bounds[2])
        st_numscalar("unbounded", A < 0)
        st_numscalar("accepts_zero", C <= 0)
    }

    // F stat at beta=1
    y_adj = st_data(., "y") - st_data(., "endog")
    X_full = J(rows(y_adj), 1, 1), st_data(., "x"), st_data(., "z1"), st_data(., "z2")
    X_rest = J(rows(y_adj), 1, 1), st_data(., "x")
    b_full = invsym(cross(X_full, X_full)) * cross(X_full, y_adj)
    b_rest = invsym(cross(X_rest, X_rest)) * cross(X_rest, y_adj)
    e_full = y_adj - X_full * b_full
    e_rest = y_adj - X_rest * b_rest
    SSR_U = quadcross(e_full, e_full)
    SSR_R = quadcross(e_rest, e_rest)
    df_r = rows(y_adj) - cols(X_full)
    F_at_one = ((SSR_R - SSR_U) / 2) / (SSR_U / df_r)
    st_numscalar("ar_f_at_one", F_at_one)
end

display "ANSWER: boundary_low estimate=" %21.12f (low) " se=" %21.12f (.) " n_obs=" %12.0f (n_obs)
display "ANSWER: boundary_high estimate=" %21.12f (high) " se=" %21.12f (.) " n_obs=" %12.0f (n_obs)
display "ANSWER: accepts_zero estimate=" %21.12f (accepts_zero) " se=" %21.12f (.) " n_obs=" %12.0f (n_obs)
display "ANSWER: unbounded estimate=" %21.12f (unbounded) " se=" %21.12f (.) " n_obs=" %12.0f (n_obs)
display "ANSWER: ar_f_at_one estimate=" %21.12f (ar_f_at_one) " se=" %21.12f (.) " n_obs=" %12.0f (n_obs)
