set linesize 255
import delimited "./input.csv", clear

// Keep observations within bandwidth
keep if abs(score) < 1

// Count observations
count
scalar n_obs = r(N)

// Triangular weights
gen weight = 1 - abs(score)

// Indicator for right side (score >= 0)
gen right = (score >= 0)

// Interactions for local linear on each side
gen score_left = score * (1 - right)
gen score_right = score * right

// Stack the system: estimate reduced form and first stage jointly
// using seemingly unrelated regression approach via sureg

// We need joint estimation to get covariance between RF and FS discontinuities
// Use sureg with aweights for triangular weights

sureg (earnings right score_left score_right) (participated right score_left score_right) [aw=weight], corr

// Extract reduced form discontinuity (coefficient on 'right' in earnings equation)
scalar rf_est = _b[earnings:right]
scalar rf_se = _se[earnings:right]

// Extract first stage discontinuity (coefficient on 'right' in participated equation)
scalar fs_est = _b[participated:right]
scalar fs_se = _se[participated:right]

// Delta method for treatment effect = RF / FS
// Var(RF/FS) = (1/FS)^2 * Var(RF) + (RF/FS^2)^2 * Var(FS) - 2*(RF/FS^3)*Cov(RF,FS)
scalar te_est = rf_est / fs_est

// Get covariance between the two 'right' coefficients
matrix V = e(V)
// Need to find positions of earnings:right and participated:right in V
// In sureg, equations are stacked, earnings first then participated
// Variables in each equation: right score_left score_right _cons (4 vars)
// earnings:right is position 1, participated:right is position 5

scalar var_rf = V[1,1]
scalar var_fs = V[5,5]
scalar cov_rf_fs = V[1,5]

scalar te_var = (1/fs_est)^2 * var_rf + (rf_est/fs_est^2)^2 * var_fs - 2*(rf_est/fs_est^3)*cov_rf_fs
scalar te_se = sqrt(te_var)

display "ANSWER: treatment_effect estimate=" %21.12f te_est " se=" %21.12f te_se " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f rf_est " se=" %21.12f rf_se " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f fs_est " se=" %21.12f fs_se " n_obs=" %12.0f n_obs
