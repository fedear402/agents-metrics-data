version 17.0
clear all
set more off
set linesize 255

import delimited "./input.csv", clear varnames(1)

// Normalize regional weights (one obs per region)
bysort region_id: keep if _n == 1
egen total_weight = total(region_weight)
gen e_r = region_weight / total_weight
keep region_id e_r x y
tempfile region_data
save `region_data'

// Reload full data
import delimited "./input.csv", clear varnames(1)
merge m:1 region_id using `region_data', nogenerate

// Construct shift-share instrument
bysort region_id: gen z_r = sum(share * shock)
bysort region_id: replace z_r = z_r[_N]

// Weighted regional means
quietly sum y [aw=e_r]
gen y0 = y - r(mean)
quietly sum x [aw=e_r]
gen x0 = x - r(mean)
quietly sum z_r [aw=e_r]
gen z0 = z_r - r(mean)

// Keep one obs per region for verification
// Now construct shock-level aggregates
// s_n = sum_r e_r * share_rn
// vbar_n = sum_r e_r * share_rn * v0_r / s_n

bysort industry_id: gen s_n = sum(e_r * share)
bysort industry_id: replace s_n = s_n[_N]

gen ey_n = e_r * share * y0
gen ex_n = e_r * share * x0
gen ez_n = e_r * share * z0

bysort industry_id: gen ybar_num = sum(ey_n)
bysort industry_id: replace ybar_num = ybar_num[_N]
bysort industry_id: gen xbar_num = sum(ex_n)
bysort industry_id: replace xbar_num = xbar_num[_N]
bysort industry_id: gen zbar_num = sum(ez_n)
bysort industry_id: replace zbar_num = zbar_num[_N]

gen ybar_n = ybar_num / s_n
gen xbar_n = xbar_num / s_n
gen zbar_n = zbar_num / s_n

// Keep one obs per industry
bysort industry_id: keep if _n == 1

// shock is constant within industry - keep it
// N = number of industries
count
local N = r(N)

// ---- Shock-level IV for effect (y on x, instrument: shock) ----
// Weighted IV: weight s_n, endogenous xbar_n, instrument shock
// regressors: (1, xbar_n), instruments: (1, shock)
// beta = (Z'WX)^{-1} Z'Wy

mata:
    st_view(ybar, ., "ybar_n")
    st_view(xbar, ., "xbar_n")
    st_view(zbar, ., "zbar_n")
    st_view(sh,   ., "shock")
    st_view(sn,   ., "s_n")
    
    N = rows(ybar)
    
    // ---- Effect regression ----
    X = J(N,1,1), xbar
    Z = J(N,1,1), sh
    W = sn
    
    ZtWX = Z' * (W :* X)
    ZtWy = Z' * (W :* ybar)
    beta_effect = luinv(ZtWX) * ZtWy
    
    resid_effect = ybar - X * beta_effect
    scores_effect = Z :* (W :* resid_effect)
    meat_effect = scores_effect' * scores_effect
    inv_ZtWX = luinv(ZtWX)
    V_effect = (N / (N-2)) * inv_ZtWX * meat_effect * inv_ZtWX'
    
    effect_est = beta_effect[2]
    effect_se  = sqrt(V_effect[2,2])
    
    // ---- First-stage regression (x on z, instrument: shock) ----
    // endogenous: zbar_n, instrument: shock
    X2 = J(N,1,1), zbar
    Z2 = J(N,1,1), sh
    
    ZtWX2 = Z2' * (W :* X2)
    ZtWy2 = Z2' * (W :* xbar)
    beta_fs = luinv(ZtWX2) * ZtWy2
    
    resid_fs = xbar - X2 * beta_fs
    scores_fs = Z2 :* (W :* resid_fs)
    meat_fs = scores_fs' * scores_fs
    inv_ZtWX2 = luinv(ZtWX2)
    V_fs = (N / (N-2)) * inv_ZtWX2 * meat_fs * inv_ZtWX2'
    
    fs_est = beta_fs[2]
    fs_se  = sqrt(V_fs[2,2])
    
    // ---- Effective shocks ----
    eff_shocks = 1 / sum(sn :^ 2)
    
    st_numscalar("effect_est",   effect_est)
    st_numscalar("effect_se",    effect_se)
    st_numscalar("fs_est",       fs_est)
    st_numscalar("fs_se",        fs_se)
    st_numscalar("eff_shocks",   eff_shocks)
end

display "ANSWER: effect estimate=" %21.12f effect_est " se=" %21.12f effect_se " n_obs=" %12.0f `N'
display "ANSWER: first_stage estimate=" %21.12f fs_est " se=" %21.12f fs_se " n_obs=" %12.0f `N'
display "ANSWER: effective_shocks estimate=" %21.12f eff_shocks " se=" %21.12f . " n_obs=" %12.0f `N'
