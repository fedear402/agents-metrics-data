set linesize 255
clear all

import delimited "./input.csv", clear

quietly {
    local n = _N
    scalar df2 = `n' - 4
    scalar df1 = 2

    * Residuals from restricted projection (annihilator of [1, x])
    reg y x
    predict e_y_r, resid
    reg endog x
    predict e_endog_r, resid

    gen double tmp1 = e_y_r^2
    gen double tmp2 = e_endog_r^2
    gen double tmp3 = e_y_r * e_endog_r

    summ tmp1, meanonly
    scalar c_r = r(sum)
    summ tmp2, meanonly
    scalar a_r = r(sum)
    summ tmp3, meanonly
    scalar b_r = r(sum)

    drop tmp1 tmp2 tmp3

    * Residuals from unrestricted projection (annihilator of [1, x, z1, z2])
    reg y x z1 z2
    predict e_y_u, resid
    reg endog x z1 z2
    predict e_endog_u, resid

    gen double tmp1 = e_y_u^2
    gen double tmp2 = e_endog_u^2
    gen double tmp3 = e_y_u * e_endog_u

    summ tmp1, meanonly
    scalar c_u = r(sum)
    summ tmp2, meanonly
    scalar a_u = r(sum)
    summ tmp3, meanonly
    scalar b_u = r(sum)

    drop tmp1 tmp2 tmp3

    * Critical F value
    scalar F_crit = invFtail(df1, df2, 0.05)

    * Boundary condition: RSS_r(beta) = k * RSS_u(beta)
    * where k = (df2 + 2*F_crit) / df2
    scalar k = (df2 + 2 * scalar(F_crit)) / df2

    * Quadratic: A*beta^2 + B*beta + C = 0
    scalar A_coef = a_r - k * a_u
    scalar B_coef = -2 * (b_r - k * b_u)
    scalar C_coef = c_r - k * c_u

    scalar disc = B_coef^2 - 4 * A_coef * C_coef

    * Roots
    scalar root1 = (-B_coef - sqrt(disc)) / (2 * A_coef)
    scalar root2 = (-B_coef + sqrt(disc)) / (2 * A_coef)

    if scalar(root1) < scalar(root2) {
        scalar boundary_low  = root1
        scalar boundary_high = root2
    }
    else {
        scalar boundary_low  = root2
        scalar boundary_high = root1
    }

    * F at beta = 1
    scalar RSS_r_1 = c_r - 2 * b_r * 1 + a_r * 1
    scalar RSS_u_1 = c_u - 2 * b_u * 1 + a_u * 1
    scalar ar_f_at_one = ((RSS_r_1 - RSS_u_1) / df1) / (RSS_u_1 / df2)

    * F at beta = 0
    scalar F_at_zero = ((c_r - c_u) / df1) / (c_u / df2)
    scalar accepts_zero = (scalar(F_at_zero) <= scalar(F_crit))

    * Unbounded: when A_coef < 0 the confidence set is outside the two roots
    scalar unbounded = (scalar(A_coef) < 0)
}

display "ANSWER: boundary_low estimate="  %21.12f scalar(boundary_low)  " se=" %21.12f . " n_obs=" %12.0f `n'
display "ANSWER: boundary_high estimate=" %21.12f scalar(boundary_high) " se=" %21.12f . " n_obs=" %12.0f `n'
display "ANSWER: accepts_zero estimate="  %21.12f scalar(accepts_zero)  " se=" %21.12f . " n_obs=" %12.0f `n'
display "ANSWER: unbounded estimate="     %21.12f scalar(unbounded)     " se=" %21.12f . " n_obs=" %12.0f `n'
display "ANSWER: ar_f_at_one estimate="   %21.12f scalar(ar_f_at_one)   " se=" %21.12f . " n_obs=" %12.0f `n'
