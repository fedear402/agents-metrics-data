set linesize 255
clear all

import delimited "./input.csv", varnames(1)

local n = _N
local k = 4  // intercept, x, z1, z2
local df1 = 2
local df2 = `n' - 4

// Critical value from F(2, n-4) at 95%
local fcrit = invFtail(`df1', `df2', 0.05)

// AR test: for a given beta, regress (y - beta*endog) on intercept, x, z1, z2
// F-test of joint significance of z1 and z2 coefficients
// We need to find the boundary points of the confidence set

// The AR statistic as a function of beta is a ratio of quadratics in beta
// F(beta) = [RSS_restricted(beta) - RSS_unrestricted(beta)] / (df1 * s2_unrestricted(beta))
// where restricted means z1=z2=0 (only intercept and x)
// unrestricted includes z1 and z2

// Let's set up the algebra:
// y - beta*endog = a0 + a1*x + a2*z1 + a3*z2 + e   (unrestricted)
// y - beta*endog = b0 + b1*x + e                     (restricted, no z1, z2)

// F = (RSS_r - RSS_ur) / 2  / (RSS_ur / (n-4))

// Since y - beta*endog = y - beta*endog, let w = y - beta*endog
// Define matrices for projection

// We can express this analytically
// Let M_X = I - X(X'X)^-1 X' where X = [1, x]
// Let M_Z = I - Z(Z'Z)^-1 Z' where Z = [1, x, z1, z2]

// RSS_r(beta) = (y - beta*endog)' M_X (y - beta*endog)
// RSS_ur(beta) = (y - beta*endog)' M_Z (y - beta*endog)

// RSS_r - RSS_ur = (y - beta*endog)' (M_X - M_Z) (y - beta*endog)

// F(beta) = [(y-beta*endog)'(M_X - M_Z)(y-beta*endog)/2] / [(y-beta*endog)' M_Z (y-beta*endog)/(n-4)]

// Let a = M_X - M_Z (projection onto z1,z2 after x), b = M_Z
// y - beta*endog = y - beta*endog, call vectors: e_vec = y - beta*endog

// Numerically: 
// Let's compute by defining components:
// e = y - beta*endog
// e'(M_X - M_Z)e = e'M_X e - e'M_Z e = RSS_r - RSS_ur

// We can write everything as quadratics in beta:
// e = y - beta*endog
// e'Ae = y'Ay - 2*beta*endog'Ay + beta^2 * endog'A*endog
// where A is any symmetric idempotent matrix

// For the F statistic:
// F(beta) = [N(beta)/2] / [D(beta)/(n-4)]
//         = (n-4)/2 * N(beta)/D(beta)
// where N(beta) = e'(M_X - M_Z)e, D(beta) = e'M_Z e

// F(beta) <= fcrit
// (n-4)/2 * N/D <= fcrit
// (n-4)*N <= 2*fcrit*D
// (n-4)*N - 2*fcrit*D <= 0
// This is a quadratic in beta

// Compute needed quantities using data
mkmat y endog x z1 z2, matrix(data)

matrix Y = data[1...,1]
matrix EN = data[1...,2]
matrix X1 = data[1...,3]
matrix Z1m = data[1...,4]
matrix Z2m = data[1...,5]

// Create design matrices
matrix iota = J(`n',1,1)
matrix Xmat = iota, X1          // [1, x] n x 2
matrix Zmat = iota, X1, Z1m, Z2m  // [1, x, z1, z2] n x 4

// Projection matrices
matrix PX = Xmat * invsym(Xmat'*Xmat) * Xmat'
matrix MX = I(`n') - PX
matrix PZ = Zmat * invsym(Zmat'*Zmat) * Zmat'
matrix MZ = I(`n') - PZ

matrix A = MX - MZ  // = PZ - PX, projects onto instrument space after x
// A = M_X - M_Z

// Compute quadratic coefficients
// N(beta) = e'Ae where e = Y - beta*EN
// N(beta) = Y'AY - 2*beta*EN'AY + beta^2*EN'AEN

matrix yAy = Y'*A*Y
matrix enAy = EN'*A*Y
matrix enAen = EN'*A*EN

matrix yMZy = Y'*MZ*Y
matrix enMZy = EN'*MZ*Y
matrix enMZen = EN'*MZ*EN

scalar c_yAy = yAy[1,1]
scalar c_enAy = enAy[1,1]
scalar c_enAen = enAen[1,1]

scalar c_yMZy = yMZy[1,1]
scalar c_enMZy = enMZy[1,1]
scalar c_enMZen = enMZen[1,1]

// N(beta) = c_enAen * beta^2 - 2*c_enAy * beta + c_yAy
// D(beta) = c_enMZen * beta^2 - 2*c_enMZy * beta + c_yMZy

// F(beta) = (n-4)/2 * N(beta)/D(beta) <= fcrit
// => (`df2')/2 * N(beta) <= fcrit * D(beta)
// => (`df2')*N(beta) - 2*fcrit*D(beta) <= 0

// (`df2'*c_enAen - 2*fcrit*c_enMZen)*beta^2 
//   + (-2*`df2'*c_enAy + 2*2*fcrit*c_enMZy)*beta 
//   + (`df2'*c_yAy - 2*fcrit*c_yMZy) <= 0

scalar qa = `df2'*c_enAen - 2*`fcrit'*c_enMZen
scalar qb = -2*`df2'*c_enAy + 4*`fcrit'*c_enMZy
scalar qc = `df2'*c_yAy - 2*`fcrit'*c_yMZy

// Quadratic: qa*beta^2 + qb*beta + qc <= 0
// Discriminant:
scalar disc = qb^2 - 4*qa*qc

// If qa > 0: parabola opens up, solution is between roots (if disc>0)
// If qa < 0: parabola opens down, solution is outside roots
// If qa = 0: linear

scalar root1 = .
scalar root2 = .

if disc >= 0 {
    scalar root1 = (-qb - sqrt(disc)) / (2*qa)
    scalar root2 = (-qb + sqrt(disc)) / (2*qa)
}

// Determine boundary_low and boundary_high
scalar boundary_low = min(root1, root2)
scalar boundary_high = max(root1, root2)

// F statistic at beta = 0 to check accepts_zero
scalar N0 = c_yAy
scalar D0 = c_yMZy
scalar F0 = (`df2'/2) * N0/D0
scalar accepts_zero = (F0 <= `fcrit')

// F statistic at beta = 1
scalar e1_enAen = c_enAen
scalar e1_enAy = c_enAy
scalar e1_yAy = c_yAy
scalar N1 = c_enAen - 2*c_enAy + c_yAy
scalar D1 = c_enMZen - 2*c_enMZy + c_yMZy
scalar ar_f_at_one = (`df2'/2) * N1/D1

// Unbounded: if qa < 0, set extends to infinity; if qa > 0 and disc < 0, set is empty
// If qa < 0: quadratic <= 0 outside the roots (so unbounded)
// If qa > 0: bounded between roots
// If qa = 0: depends on sign of linear coefficient
scalar unbounded = (qa < 0)

display "ANSWER: boundary_low estimate=" %21.12f boundary_low " se=" %21.12f . " n_obs=" %12.0f `n'
display "ANSWER: boundary_high estimate=" %21.12f boundary_high " se=" %21.12f . " n_obs=" %12.0f `n'
display "ANSWER: accepts_zero estimate=" %21.12f accepts_zero " se=" %21.12f . " n_obs=" %12.0f `n'
display "ANSWER: unbounded estimate=" %21.12f unbounded " se=" %21.12f . " n_obs=" %12.0f `n'
display "ANSWER: ar_f_at_one estimate=" %21.12f ar_f_at_one " se=" %21.12f . " n_obs=" %12.0f `n'
