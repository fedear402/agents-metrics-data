set linesize 255
import delimited "./input.csv", clear
sort time

* Store y values in a matrix for easy access
mkmat y, matrix(Y)

* Initialize storage for forecasts
local n_fore = 150
matrix forecasts = J(150, 2, .)

forvalues f = 101/250 {
    local idx = `f' - 100
    
    * Use observations f-100 to f-1 (indices f-100 through f-1 in time)
    * Regression pairs: s = f-99,...,f-1 (99 pairs)
    * y_s = a + b*y_{s-1}
    
    * Create temporary dataset
    preserve
    keep if time >= `f'-100 & time <= `f'-1
    
    * Create lagged y
    gen y_lag = y[_n-1] if _n > 1
    * But we need y_{s-1} where s starts at f-99
    * time f-100 gives y_{f-100} which is lag for s=f-99
    
    * Drop the first observation (time f-100) since it's only used as lag
    drop if time == `f'-100
    
    * Now we have times f-99 to f-1 with y and need lag
    * Sort and create proper lag
    sort time
    gen y_lag2 = y[_n-1]
    * But y[_n-1] when _n=1 would be missing - we need to bring in the f-100 value
    * Actually let's redo this properly
    restore
    
    preserve
    keep if time >= `f'-100 & time <= `f'-1
    sort time
    gen y_lag = y[_n-1]
    * First obs has missing lag - drop it
    drop if _n == 1
    * Now have 99 obs: times f-99 to f-1, y and y_lag
    
    reg y y_lag
    local a_hat = _b[_cons]
    local b_hat = _b[y_lag]
    restore
    
    * Get y_{f-1}
    quietly summarize y if time == `f'-1
    local y_prev = r(mean)
    
    local fore = `a_hat' + `b_hat' * `y_prev'
    local row = `f' - 100
    matrix forecasts[`row', 1] = `f'
    matrix forecasts[`row', 2] = `fore'
}

* Now compute RMSE
* Merge forecasts back
svmat forecasts, names(col)
rename c1 fore_time
rename c2 fore_val

* Merge with actual y
gen actual_y = .
forvalues f = 101/250 {
    local row = `f' - 100
    quietly summarize y if time == `f'
    local actual = r(mean)
    replace actual_y = `actual' if fore_time == `f'
}

gen sq_err = (actual_y - fore_val)^2
quietly summarize sq_err if fore_time != .
local rmse = sqrt(r(sum)/150)

* Get specific forecasts
quietly summarize fore_val if fore_time == 101
local f101 = r(mean)
quietly summarize fore_val if fore_time == 150
local f150 = r(mean)
quietly summarize fore_val if fore_time == 200
local f200 = r(mean)
quietly summarize fore_val if fore_time == 250
local f250 = r(mean)

display "ANSWER: rmse estimate=" %21.12f `rmse' " se=" %21.12f . " n_obs=" %12.0f 150
display "ANSWER: forecast_101 estimate=" %21.12f `f101' " se=" %21.12f . " n_obs=" %12.0f 99
display "ANSWER: forecast_150 estimate=" %21.12f `f150' " se=" %21.12f . " n_obs=" %12.0f 99
display "ANSWER: forecast_200 estimate=" %21.12f `f200' " se=" %21.12f . " n_obs=" %12.0f 99
display "ANSWER: forecast_250 estimate=" %21.12f `f250' " se=" %21.12f . " n_obs=" %12.0f 99
