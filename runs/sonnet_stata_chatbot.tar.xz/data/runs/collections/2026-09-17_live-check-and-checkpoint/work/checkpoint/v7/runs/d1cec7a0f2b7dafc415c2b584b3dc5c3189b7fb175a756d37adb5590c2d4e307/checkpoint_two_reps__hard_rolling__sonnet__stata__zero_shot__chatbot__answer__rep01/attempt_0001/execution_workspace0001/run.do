set linesize 255
import delimited "./input.csv", clear
sort time

* Store y values in a mata matrix for easy access
mata: y = st_data(., "y")

* We need forecasts for f=101,...,250
* For each f, use observations at positions f-100 through f-1 (1-indexed)
* Fit AR(1): y_s = a + b*y_(s-1) for s = f-99,...,f-1 (99 pairs)

local nforecasts = 150
matrix forecasts = J(150, 2, .)  // col1=f, col2=forecast

mata {
    y = st_data(., "y")
    n = rows(y)
    forecasts = J(150, 2, .)
    
    for (fi = 1; fi <= 150; fi++) {
        f = 100 + fi  // forecast index (101 to 250)
        
        // Window: positions f-100 to f-1 in 1-indexed = fi to fi+99
        // Regression pairs: s = f-99,...,f-1 => positions fi+1 to fi+99
        // y_s vs y_(s-1): pairs (y[fi+1],y[fi]), ..., (y[fi+99],y[fi+98])
        
        // Build X (with intercept) and Y for regression
        nobs = 99
        Y = J(nobs, 1, .)
        X = J(nobs, 2, .)
        
        for (i = 1; i <= nobs; i++) {
            s = fi + i  // position of y_s
            Y[i,1] = y[s]
            X[i,1] = 1
            X[i,2] = y[s-1]
        }
        
        // OLS: b = (X'X)^-1 X'Y
        b = invsym(X'X) * X'Y
        
        // Forecast y_f = a + b*y_(f-1)
        // y_(f-1) is at position f-1 = fi+99
        ylag = y[fi+99]
        forecast_val = b[1,1] + b[2,1] * ylag
        
        forecasts[fi, 1] = f
        forecasts[fi, 2] = forecast_val
    }
    
    st_matrix("forecasts", forecasts)
}

* Compute RMSE
mata {
    y = st_data(., "y")
    fc = st_matrix("forecasts")
    
    sse = 0
    for (fi = 1; fi <= 150; fi++) {
        f = 100 + fi
        actual = y[f]
        pred = fc[fi, 2]
        sse = sse + (actual - pred)^2
    }
    rmse = sqrt(sse / 150)
    st_numscalar("rmse_val", rmse)
    st_numscalar("fc101", fc[1,2])
    st_numscalar("fc150", fc[50,2])
    st_numscalar("fc200", fc[100,2])
    st_numscalar("fc250", fc[150,2])
}

display "ANSWER: rmse estimate=" %21.12f rmse_val " se=" %21.12f . " n_obs=" %12.0f 150
display "ANSWER: forecast_101 estimate=" %21.12f fc101 " se=" %21.12f . " n_obs=" %12.0f 99
display "ANSWER: forecast_150 estimate=" %21.12f fc150 " se=" %21.12f . " n_obs=" %12.0f 99
display "ANSWER: forecast_200 estimate=" %21.12f fc200 " se=" %21.12f . " n_obs=" %12.0f 99
display "ANSWER: forecast_250 estimate=" %21.12f fc250 " se=" %21.12f . " n_obs=" %12.0f 99
