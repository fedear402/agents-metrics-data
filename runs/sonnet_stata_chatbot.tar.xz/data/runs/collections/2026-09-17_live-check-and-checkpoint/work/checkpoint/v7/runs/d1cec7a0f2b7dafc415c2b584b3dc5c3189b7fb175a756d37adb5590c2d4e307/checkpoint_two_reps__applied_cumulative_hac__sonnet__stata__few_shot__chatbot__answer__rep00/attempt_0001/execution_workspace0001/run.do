version 17.0
clear all
set more off
set linesize 255

import delimited "./input.csv", clear

generate double day = date(date, "YMD")
sort day
generate int observation = _n
tsset observation

generate double log_sales = log(sales)
generate double log_vix = log(vix)
generate double dvix = D.log_vix

forvalues k = 1/15 {
    generate double dvix_lag`k' = L`k'.dvix
}

keep if !missing(log_sales, dvix_lag1, dvix_lag2, dvix_lag3, dvix_lag4, dvix_lag5, dvix_lag6, dvix_lag7, dvix_lag8, dvix_lag9, dvix_lag10, dvix_lag11, dvix_lag12, dvix_lag13, dvix_lag14, dvix_lag15)

mata:
    varlist = ("dvix_lag1","dvix_lag2","dvix_lag3","dvix_lag4","dvix_lag5","dvix_lag6","dvix_lag7","dvix_lag8","dvix_lag9","dvix_lag10","dvix_lag11","dvix_lag12","dvix_lag13","dvix_lag14","dvix_lag15")
    X = (J(st_nobs(),1,1), st_data(., varlist))
    y = st_data(., "log_sales")
    
    N = rows(X)
    p = cols(X)
    
    coefficients = qrsolve(X, y)
    residuals = y - X * coefficients
    
    scores = X :* residuals
    hac_lags = 15
    
    meat = scores' * scores
    for (j = 1; j <= hac_lags; j++) {
        lag_product = scores[|j+1,1 \ N,p|]' * scores[|1,1 \ N-j,p|]
        w = 1 - j/(hac_lags + 1)
        meat = meat + w * (lag_product + lag_product')
    }
    
    bread = invsym(X'*X)
    covariance = (N/(N-p)) * bread * meat * bread
    
    // cumulative response: sum of lag1 through lag15 (indices 2 through 16)
    contrast = J(p, 1, 0)
    for (k = 2; k <= 16; k++) {
        contrast[k] = 1
    }
    
    cumulative = contrast' * coefficients
    cumulative_se = sqrt(contrast' * covariance * contrast)
    
    lag1_est = coefficients[2]
    lag1_se = sqrt(covariance[2,2])
    
    lag15_est = coefficients[16]
    lag15_se = sqrt(covariance[16,16])
    
    printf("ANSWER: cumulative_response estimate=%21.12f se=%21.12f n_obs=%12.0f\n", cumulative, cumulative_se, N)
    printf("ANSWER: lag_1 estimate=%21.12f se=%21.12f n_obs=%12.0f\n", lag1_est, lag1_se, N)
    printf("ANSWER: lag_15 estimate=%21.12f se=%21.12f n_obs=%12.0f\n", lag15_est, lag15_se, N)
end
