set linesize 255
clear all

import delimited "./input.csv", varnames(1)

* Step 1: One obs per region for weights
bysort region_id: keep if _n == 1
keep region_id region_weight x y
tempfile region_data
save `region_data'

* Reload full data
import delimited "./input.csv", varnames(1) clear

* Step 2: Construct shift-share instrument z_r = sum_n share_rn * shock_n
gen share_shock = share * shock
bysort region_id: egen z = sum(share_shock)

* Step 3: Normalize regional weights (one obs per region)
* Get unique regions
preserve
bysort region_id: keep if _n == 1
keep region_id region_weight x y z
sum region_weight
local sum_w = r(sum)
gen e_r = region_weight / `sum_w'
tempfile region_level
save `region_level'
restore

* Step 4: Compute s_n = sum_r e_r * share_rn
* Merge e_r into full data
merge m:1 region_id using `region_level', keepusing(e_r) nogen

* Step 5: Compute weighted means (e_r-weighted) for y, x, z at region level
* First get region-level data
use `region_level', clear

* Compute e_r-weighted means
sum y [aw=e_r]
local mean_y = r(mean)
sum x [aw=e_r]
local mean_x = r(mean)
sum z [aw=e_r]
local mean_z = r(mean)

* Demean
gen y0 = y - `mean_y'
gen x0 = x - `mean_x'
gen z0 = z - `mean_z'

* Step 6: Aggregate to industry level
* Need to merge back with full data to get share and shock info
* Merge region-level residuals into full data
tempfile region_resid
save `region_resid'

import delimited "./input.csv", varnames(1) clear
merge m:1 region_id using `region_resid', keepusing(e_r y0 x0 z0) nogen

* Step 7: For each industry n, compute s_n = sum_r e_r*share_rn
gen e_share = e_r * share

bysort industry_id: egen s_n = sum(e_share)

* Aggregate residuals: vbar_n = sum_r e_r*share_rn*v0_r / s_n
gen ey_contrib = e_r * share * y0
gen ex_contrib = e_r * share * x0
gen ez_contrib = e_r * share * z0

bysort industry_id: egen sum_ey = sum(ey_contrib)
bysort industry_id: egen sum_ex = sum(ex_contrib)
bysort industry_id: egen sum_ez = sum(ez_contrib)

gen ybar_n = sum_ey / s_n
gen xbar_n = sum_ex / s_n
gen zbar_n = sum_ez / s_n

* Keep one obs per industry
bysort industry_id: keep if _n == 1
keep industry_id shock s_n ybar_n xbar_n zbar_n

* Number of industries
count
local N_ind = r(N)

* Step 8: Shock-level IV regression of ybar_n on xbar_n, instrumenting with shock_n, weighted by s_n
* This gives the 2SLS slope (same as regional 2SLS slope)

* Manual 2SLS at shock level
* First stage: regress xbar_n on shock_n with s_n weights
reg xbar_n shock_n [aw=s_n]
local fs_slope = _b[shock_n]

* Get predicted xbar_n from first stage
predict xbar_hat, xb

* Second stage: regress ybar_n on xbar_hat with s_n weights
reg ybar_n xbar_hat [aw=s_n]
local tsls_slope = _b[xbar_hat]

* Step 9: Compute HC1 SE for the 2SLS slope using structural IV residuals
* Structural residual: u_n = ybar_n - tsls_slope * xbar_n - intercept
* Need intercept: weighted mean of ybar_n - tsls_slope * weighted mean of xbar_n
* Since ybar_n and xbar_n are already demeaned (from e_r weighting), 
* the intercept should be ~0, but let's compute it properly

* For IV regression: y = a + b*x + u, instrumented by z
* The IV estimator uses z as instrument
* Structural residuals: u_n = ybar_n - a_iv - b_iv*xbar_n

* Compute weighted means for intercept
sum ybar_n [aw=s_n]
local wmean_y = r(mean)
sum xbar_n [aw=s_n]
local wmean_x = r(mean)

local intercept_iv = `wmean_y' - `tsls_slope' * `wmean_x'

gen u_iv = ybar_n - `intercept_iv' - `tsls_slope' * xbar_n

* HC1 variance for 2SLS slope
* V(b_iv) = (1/(Szx)^2) * sum_n s_n^2 * u_iv_n^2 * (N/(N-2))
* where Szx = sum_n s_n * zbar_n * xbar_n (numerator pieces)
* Actually the formula for weighted IV HC1 SE:
* b_iv = sum_n s_n*zbar_n*ybar_n / sum_n s_n*zbar_n*xbar_n

* Let Szx = sum_n s_n * zbar_n * xbar_n (denominator of IV estimator, up to weighting)
* Actually: b_iv = [sum_n w_n * z_n * y_n] / [sum_n w_n * z_n * x_n]
* where w_n = s_n (analytic weights)

gen w_zx = s_n * zbar_n * xbar_n
gen w_zy = s_n * zbar_n * ybar_n
gen w_z2 = s_n * zbar_n^2

sum w_zx
local Szx = r(sum)
sum w_zy  
local Szy = r(sum)

* HC1 SE: sqrt( N/(N-2) * sum_n (s_n * zbar_n * u_iv_n)^2 / Szx^2 )
gen score_iv = s_n * zbar_n * u_iv
gen score_iv2 = score_iv^2
sum score_iv2
local sum_score2 = r(sum)

local var_iv = (`N_ind' / (`N_ind' - 2)) * `sum_score2' / (`Szx'^2)
local se_iv = sqrt(`var_iv')

* Step 10: First stage slope with HC1 SE
* First stage: xbar_n on intercept + zbar_n, instrumenting zbar_n with shock_n
* This is an IV regression where zbar_n is endogenous, instrumented by shock_n

* IV estimator: b_fs = sum_n s_n*shock_n*xbar_n / sum_n s_n*shock_n*zbar_n
gen w_sz = s_n * shock_n * zbar_n
gen w_sx = s_n * shock_n * xbar_n
gen w_ss = s_n * shock_n^2

sum w_sz
local Ssz = r(sum)
sum w_sx
local Ssx = r(sum)

local fs_iv_slope = `Ssx' / `Ssz'

* Intercept: weighted mean of xbar_n - fs_iv_slope * weighted mean of zbar_n
sum xbar_n [aw=s_n]
local wmean_xbar = r(mean)
sum zbar_n [aw=s_n]
local wmean_zbar = r(mean)

local intercept_fs = `wmean_xbar' - `fs_iv_slope' * `wmean_zbar'

* Structural residual for first stage IV
gen u_fs = xbar_n - `intercept_fs' - `fs_iv_slope' * zbar_n

* HC1 SE for first stage IV
gen score_fs = s_n * shock_n * u_fs
gen score_fs2 = score_fs^2
sum score_fs2
local sum_score_fs2 = r(sum)

local var_fs = (`N_ind' / (`N_ind' - 2)) * `sum_score_fs2' / (`Ssz'^2)
local se_fs = sqrt(`var_fs')

* Step 11: Effective shocks = 1/sum_n s_n^2
gen s_n2 = s_n^2
sum s_n2
local eff_shocks = 1 / r(sum)

* Report results
display "ANSWER: effect estimate=" %21.12f `tsls_slope' " se=" %21.12f `se_iv' " n_obs=" %12.0f `N_ind'
display "ANSWER: first_stage estimate=" %21.12f `fs_iv_slope' " se=" %21.12f `se_fs' " n_obs=" %12.0f `N_ind'
display "ANSWER: effective_shocks estimate=" %21.12f `eff_shocks' " se=" %21.12f . " n_obs=" %12.0f `N_ind'
