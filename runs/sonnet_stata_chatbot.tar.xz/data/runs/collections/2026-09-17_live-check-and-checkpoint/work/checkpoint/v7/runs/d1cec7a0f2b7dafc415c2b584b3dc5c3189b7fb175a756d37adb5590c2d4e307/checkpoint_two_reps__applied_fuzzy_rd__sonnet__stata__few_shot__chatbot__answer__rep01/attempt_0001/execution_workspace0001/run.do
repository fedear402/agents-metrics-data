version 17.0
clear all
set more off
set linesize 255

import delimited "./input.csv", clear

keep if abs(score) < 1
gen w = 1 - abs(score)
gen above = (score >= 0)
gen score_left = score * (1 - above)
gen score_right = score * above

local n = _N

mata:
    above = st_data(., "above")
    w = st_data(., "w")
    Y = st_data(., ("earnings", "participated"))
    score_left = st_data(., "score_left")
    score_right = st_data(., "score_right")
    
    n = rows(Y)
    
    // Design matrix: intercept, above, slope_left, slope_right
    X = (J(n,1,1), above, score_left, score_right)
    
    // WLS
    Xw = w :* X
    bread = invsym(X' * Xw)
    coef = bread * (Xw' * Y)
    resid = Y - X * coef
    
    // Contrast for right-minus-left discontinuity at cutoff (above coef)
    contrast = (0 \ 1 \ 0 \ 0)
    
    jumps = contrast' * coef
    
    loading = w :* (X * bread * contrast)
    influence = loading :* resid
    
    joint = influence' * influence
    
    // Delta method for ratio
    rf = jumps[1]
    fs = jumps[2]
    gradient = (1/fs \ -rf/fs^2)
    ratio_se = sqrt(gradient' * joint * gradient)
    
    st_numscalar("rf_est", rf)
    st_numscalar("fs_est", fs)
    st_numscalar("te_est", rf/fs)
    st_numscalar("rf_se", sqrt(joint[1,1]))
    st_numscalar("fs_se", sqrt(joint[2,2]))
    st_numscalar("te_se", ratio_se)
end

display "ANSWER: treatment_effect estimate=" %21.12f te_est " se=" %21.12f te_se " n_obs=" %12.0f `n'
display "ANSWER: reduced_form estimate=" %21.12f rf_est " se=" %21.12f rf_se " n_obs=" %12.0f `n'
display "ANSWER: first_stage estimate=" %21.12f fs_est " se=" %21.12f fs_se " n_obs=" %12.0f `n'
