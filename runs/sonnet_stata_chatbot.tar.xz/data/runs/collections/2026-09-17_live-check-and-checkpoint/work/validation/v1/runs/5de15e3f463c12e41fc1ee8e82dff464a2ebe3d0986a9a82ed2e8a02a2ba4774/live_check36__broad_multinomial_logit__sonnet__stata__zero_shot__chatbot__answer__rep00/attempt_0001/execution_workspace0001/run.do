set linesize 255
import delimited "./input.csv", clear

mlogit y x z, base(0)

matrix b = e(b)
matrix V = e(V)

scalar x_cat1_est = b[1, colnumb(b, "y=1:x")]
scalar z_cat1_est = b[1, colnumb(b, "y=1:z")]
scalar x_cat2_est = b[1, colnumb(b, "y=2:x")]
scalar z_cat2_est = b[1, colnumb(b, "y=2:z")]

scalar x_cat1_se = sqrt(V[colnumb(b, "y=1:x"), colnumb(b, "y=1:x")])
scalar z_cat1_se = sqrt(V[colnumb(b, "y=1:z"), colnumb(b, "y=1:z")])
scalar x_cat2_se = sqrt(V[colnumb(b, "y=2:x"), colnumb(b, "y=2:x")])
scalar z_cat2_se = sqrt(V[colnumb(b, "y=2:z"), colnumb(b, "y=2:z")])

scalar n_obs = e(N)

* Fitted probability of outcome 2 at x=0, z=0
* P(y=2|x=0,z=0) = exp(cons2) / (1 + exp(cons1) + exp(cons2))
scalar cons1 = b[1, colnumb(b, "y=1:_cons")]
scalar cons2 = b[1, colnumb(b, "y=2:_cons")]
scalar prob_cat2_zero = exp(cons2) / (1 + exp(cons1) + exp(cons2))

display "ANSWER: x_cat1 estimate=" %21.12f x_cat1_est " se=" %21.12f x_cat1_se " n_obs=" %12.0f n_obs
display "ANSWER: z_cat1 estimate=" %21.12f z_cat1_est " se=" %21.12f z_cat1_se " n_obs=" %12.0f n_obs
display "ANSWER: x_cat2 estimate=" %21.12f x_cat2_est " se=" %21.12f x_cat2_se " n_obs=" %12.0f n_obs
display "ANSWER: z_cat2 estimate=" %21.12f z_cat2_est " se=" %21.12f z_cat2_se " n_obs=" %12.0f n_obs
display "ANSWER: prob_cat2_zero estimate=" %21.12f prob_cat2_zero " se=" %21.12f . " n_obs=" %12.0f n_obs
