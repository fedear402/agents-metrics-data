library(jsonlite)
d <- read.csv("input.csv")
h <- 1
s <- d$score
keep <- abs(s) < h
d <- d[keep, ]
s <- d$score
w <- 1 - abs(s)
right <- s >= 0
Y <- cbind(reduced_form = d$earnings, first_stage = d$participated)

side_fit <- function(idx, sign_jump) {
  X <- cbind(1, s[idx])
  W <- w[idx]
  B <- solve(crossprod(X, W * X))
  coef <- B %*% crossprod(X, W * Y[idx, , drop = FALSE])
  E <- Y[idx, , drop = FALSE] - X %*% coef
  loading <- W * drop(X %*% B[, 1])
  infl <- loading * E
  list(intercept = coef[1, ], infl = sign_jump * infl, idx = idx)
}
R <- side_fit(which(right), 1)
L <- side_fit(which(!right), -1)

jump <- R$intercept - L$intercept
n_inf <- nrow(Y)
Phi <- matrix(0, n_inf, 2)
Phi[R$idx, ] <- R$infl
Phi[L$idx, ] <- L$infl
V <- crossprod(Phi)
se <- sqrt(diag(V))

rf <- unname(jump["reduced_form"]); fs <- unname(jump["first_stage"])
tau <- rf / fs
g <- c(1 / fs, -rf / fs^2)
tau_se <- sqrt(drop(t(g) %*% V %*% g))

n_obs <- nrow(Y)
res <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = unname(tau), se = unname(tau_se), n_obs = n_obs),
    list(term = "reduced_form", estimate = rf, se = unname(se[1]), n_obs = n_obs),
    list(term = "first_stage", estimate = fs, se = unname(se[2]), n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "Fuzzy RD, local linear with separate slopes per side, triangular kernel, bandwidth 1, Wald ratio",
    vcov = "HC0 sandwich, delta method for ratio, joint covariance from stacked influence functions"
  ),
  diagnostics = list(
    bandwidth = h, cutoff = 0,
    n_left = length(L$idx), n_right = length(R$idx),
    reduced_form_cov_with_first_stage = unname(V[1, 2])
  )
)
write_json(res, "result.json", auto_unbox = TRUE, digits = 16, pretty = TRUE)
