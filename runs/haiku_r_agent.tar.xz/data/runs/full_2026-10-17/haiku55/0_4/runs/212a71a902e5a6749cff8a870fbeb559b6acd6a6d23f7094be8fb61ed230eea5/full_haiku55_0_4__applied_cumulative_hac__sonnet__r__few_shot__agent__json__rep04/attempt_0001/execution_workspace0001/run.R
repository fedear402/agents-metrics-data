library(jsonlite)

d <- read.csv("input.csv", stringsAsFactors = FALSE)
d$date <- as.Date(d$date)
d <- d[order(d$date), ]
d$dlvix <- c(NA, diff(log(d$vix)))
L <- 15
for (k in 1:L) d[[paste0("lag", k)]] <- c(rep(NA, k), head(d$dlvix, -k))
d$log_sales <- log(d$sales)

vars <- paste0("lag", 1:L)
s <- d[complete.cases(d[, c("log_sales", vars)]), ]
fit <- lm(log_sales ~ ., data = s[, c("log_sales", vars)])
b <- coef(fit)
X <- model.matrix(fit)
N <- nrow(X)
p <- ncol(X)
u <- residuals(fit)
scores <- X * u
meat <- crossprod(scores)
for (j in 1:L) {
  w <- 1 - j / (L + 1)
  G <- crossprod(scores[(j + 1):N, , drop = FALSE], scores[1:(N - j), , drop = FALSE])
  meat <- meat + w * (G + t(G))
}
bread <- solve(crossprod(X))
V <- N / (N - p) * bread %*% meat %*% bread
rownames(V) <- colnames(V) <- names(b)

cvec <- c(0, rep(1, L))
cum <- sum(cvec * b)
cum_se <- sqrt(drop(t(cvec) %*% V %*% cvec))

res <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(term = "cumulative_response", estimate = unname(cum), se = unname(cum_se), n_obs = as.integer(N)),
    list(term = "lag_1", estimate = unname(b["lag1"]), se = unname(sqrt(V["lag1", "lag1"])), n_obs = as.integer(N)),
    list(term = "lag_15", estimate = unname(b["lag15"]), se = unname(sqrt(V["lag15", "lag15"])), n_obs = as.integer(N))
  ),
  method_metadata = list(
    estimator = "OLS of log(sales) on intercept and 15 lags of diff(log(vix))",
    vcov = "Newey-West HAC, Bartlett weights 1-j/16, max lag 15, scaled by N/(N-16)"
  ),
  diagnostics = list(
    sample_rows = N,
    regressors = p,
    first_date = as.character(min(s$date)),
    last_date = as.character(max(s$date))
  )
)
write_json(res, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE, null = "null")

if (requireNamespace("sandwich", quietly = TRUE)) {
  V2 <- sandwich::NeweyWest(fit, lag = L, prewhite = FALSE, adjust = TRUE)
  cum2 <- sum(b[-1])
  se2 <- sqrt(sum(V2[-1, -1]))
  cat(sprintf("CHECK sandwich: cum_se=%.10f manual=%.10f\n", se2, cum_se))
  cat(sprintf("CHECK sandwich lag1 se=%.10f manual=%.10f\n", sqrt(V2[2, 2]), sqrt(V["lag1", "lag1"])))
  cat(sprintf("CHECK sandwich lag15 se=%.10f manual=%.10f\n", sqrt(V2[16, 16]), sqrt(V["lag15", "lag15"])))
}
cat(sprintf("N=%d p=%d cum=%.10f se=%.10f\n", N, p, cum, cum_se))
