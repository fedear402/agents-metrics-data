e <- new.env(); source("run.R", local = e)
d <- e$d; w <- d$population
X <- cbind(1, d$period, d$control, d$x); Z <- cbind(1, d$period, d$control, d$z)
W <- diag(w)
A <- t(X) %*% W %*% Z %*% solve(t(Z) %*% W %*% Z) %*% t(Z) %*% W
b <- solve(A %*% X, A %*% d$change_pp)
cat("explicit 2SLS slope:", sprintf("%.12f", b[4]), "\n")
cat("script slope:      ", sprintf("%.12f", e$slope), "\n")
ar <- read.csv("areas.csv"); em <- read.csv("employment.csv"); tr <- unique(rbind(read.csv("crosswalk.csv"), read.csv("input.csv")))
tt <- read.csv("trade.csv")
calc <- function(vint, a, p) {
  tot <- ar$total_employment[ar$area==a & ar$period==p & ar$vintage==vint]
  s <- 0
  for (j in 0:3) {
    ej <- em$employment[em$area==a & em$period==p & em$vintage==vint & em$industry==j]
    ej <- if (length(ej)) ej else 0
    nat <- sum(em$employment[em$period==p & em$vintage==vint & em$industry==j])
    row <- tt[tt$period==p & tt$code %in% tr$code[tr$industry==j], ][1,]
    chg <- if (vint=="base") row$us_change else row$other_change
    s <- s + ej/tot * chg/nat / (row$price_index/100) / 1000 * (10/row$years)
  }
  s
}
cat("x a0p0 manual:", calc("base",0,0), " script:", e$d$x[e$d$area==0 & e$d$period==0], "\n")
cat("x a0p1 manual:", calc("base",0,1), " script:", e$d$x[e$d$area==0 & e$d$period==1], "\n")
cat("z a0p0 manual:", calc("early",0,0), " script:", e$d$z[e$d$area==0 & e$d$period==0], "\n")
