suppressMessages({library(sandwich)})
d <- read.csv("input.csv", stringsAsFactors = FALSE)
d$date <- as.Date(d$date)
d <- d[order(d$date), ]
cat("rows:", nrow(d), " sorted:", !is.unsorted(d$date), " no NA:", !anyNA(d[, c("sales","vix")]), "\n")
cat("weekdays only:", all(as.POSIXlt(d$date)$wday %in% 1:5), " dup dates:", anyDuplicated(d$date) > 0, "\n")
dlv <- c(NA, diff(log(d$vix)))
X <- data.frame(ls = log(d$sales))
for (k in 1:15) X[[paste0("l", k)]] <- c(rep(NA, k), head(dlv, -k))
s <- X[complete.cases(X), ]
cat("sample rows:", nrow(s), " expected 720-16=704\n")
fit <- lm(ls ~ ., data = s)
N <- nrow(s); p <- 16
nw <- NeweyWest(fit, lag = 15, prewhite = FALSE, adjust = FALSE)
V_sand <- nw * N / (N - p)
cvec <- c(0, rep(1, 15))
cat("sandwich cum:", sum(cvec * coef(fit)), " se:", sqrt(drop(t(cvec) %*% V_sand %*% cvec)), "\n")
cat("sandwich lag1 se:", sqrt(V_sand[2,2]), " lag15 se:", sqrt(V_sand[16,16]), "\n")
# Identity check: cumulative response equals the regression of ls on the summed lag regressor
Z <- rowSums(s[, paste0("l", 1:15)])
fit2 <- lm(s$ls ~ Z)
cat("reparam slope:", coef(fit2)[2], "  equals cum:", sum(coef(fit)[-1]), "\n")
