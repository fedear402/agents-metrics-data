library(jsonlite)
library(AER)

hh <- read.csv("households.csv")
census <- read.csv("census.csv")

d <- hh[hh$recipient == 0, ]
n_obs <- nrow(d)

e <- d$eligible
ne <- 1 - e
d$dose_ne <- d$dose * ne
d$dose_e <- d$dose * e
d$base_ne <- d$baseline * ne
d$base_e <- d$baseline * e
d$inst_ne <- d$instrument * ne
d$inst_e <- d$instrument * e

endog <- c("dose_ne", "dose_e")
exog <- c("ne", "e", "base_ne", "base_e")
instr <- c("ne", "e", "base_ne", "base_e", "inst_ne", "inst_e")

f <- as.formula(paste("outcome ~ -1 +", paste(c(endog, exog), collapse = " + "),
                      "|", paste(c(exog, instr[5:6]), collapse = " + ")))
fit <- ivreg(f, data = d, weights = d$weight)
b <- coef(fit)

group_effect <- function(g, slope_name) {
  sub <- d[e == g, ]
  wmean_dose <- sum(sub$weight * sub$dose) / sum(sub$weight)
  unname(b[slope_name]) * wmean_dose
}

ineligible_effect <- group_effect(0, "dose_ne")
eligible_nonrecipient_effect <- group_effect(1, "dose_e")

pop <- setNames(census$nonrecipient_population, census$eligible)
population_effect <- (pop["0"] * ineligible_effect + pop["1"] * eligible_nonrecipient_effect) / sum(pop)

n_ne <- sum(e == 0)
n_e <- sum(e == 1)

est <- list(
  list(term = "ineligible_effect", estimate = ineligible_effect, se = NA_real_, n_obs = n_obs),
  list(term = "eligible_nonrecipient_effect", estimate = eligible_nonrecipient_effect, se = NA_real_, n_obs = n_obs),
  list(term = "population_effect", estimate = population_effect, se = NA_real_, n_obs = n_obs)
)

out <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = est,
  method_metadata = list(
    estimator = "weighted 2SLS (AER::ivreg, no intercept)",
    sample = "households with recipient == 0, both treatment statuses",
    endogenous = endog,
    exogenous = exog,
    instruments = instr,
    weight = "weight",
    counterfactual = "dose set to zero for every retained household; effect = dose slope x weighted mean dose",
    population_weights = list(ineligible = unname(pop["0"]), eligible = unname(pop["1"])),
    se_note = "standard errors not reported (se set to null)"
  ),
  diagnostics = list(
    n_obs = n_obs,
    n_ineligible = n_ne,
    n_eligible = n_e,
    slopes = list(dose_ineligible = unname(b["dose_ne"]), dose_eligible = unname(b["dose_e"])),
    weighted_mean_dose = list(
      ineligible = sum(d$weight[e == 0] * d$dose[e == 0]) / sum(d$weight[e == 0]),
      eligible = sum(d$weight[e == 1] * d$dose[e == 1]) / sum(d$weight[e == 1])
    )
  )
)

write_json(out, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE, na = "null")
print(unlist(lapply(est, function(x) setNames(x$estimate, x$term))), digits = 12)
cat("n_obs:", n_obs, " ineligible n:", n_ne, " eligible n:", n_e, "\n")
