suppressPackageStartupMessages(library(jsonlite))
d <- read.csv("input.csv", stringsAsFactors = FALSE)
d <- d[order(as.Date(d$date)), ]
y <- log(d$sales)
dv <- c(NA, diff(log(d$vix)))
L <- 15
n <- length(y)
idx <- (L + 2):n
X <- cbind(1, sapply(1:L, function(k) dv[idx - k]))
colnames(X) <- c("(Intercept)", paste0("lag_", 1:L))
yy <- y[idx]
N <- length(yy)
fit <- lm.fit(X, yy)
b <- fit$coefficients
u <- fit$residuals
XtXi <- solve(crossprod(X))
S <- crossprod(X * u)
for (j in 1:L) {
  w <- 1 - j / (L + 1)
  G <- crossprod(X[(j + 1):N, , drop = FALSE] * u[(j + 1):N],
                 X[1:(N - j), , drop = FALSE] * u[1:(N - j)])
  S <- S + w * (G + t(G))
}
V <- XtXi %*% S %*% XtXi * N / (N - L - 1)
R <- c(0, rep(1, L))
cum <- sum(b[-1])
cum_se <- sqrt(as.numeric(t(R) %*% V %*% R))
se <- sqrt(diag(V))
cat(sprintf("N=%d cum=%.8f se=%.8f lag1=%.8f se=%.8f lag15=%.8f se=%.8f\n",
            N, cum, cum_se, b[2], se[2], b[16], se[16]))

# independent check: sandwich::NeweyWest on the same lm fit
suppressPackageStartupMessages(library(sandwich))
lmfit <- lm(yy ~ X[, -1])
Vs <- NeweyWest(lmfit, lag = L, prewhite = FALSE, adjust = FALSE) * N / (N - L - 1)
Rs <- c(0, rep(1, L))
cat(sprintf("sandwich check: cum_se=%.8f lag1_se=%.8f lag15_se=%.8f maxabsdiff=%.3e\n",
            sqrt(as.numeric(t(Rs) %*% Vs %*% Rs)), sqrt(Vs[2, 2]), sqrt(Vs[16, 16]),
            max(abs(Vs - V))))

est <- list(
  list(term = "cumulative_response", estimate = cum, se = cum_se, n_obs = N),
  list(term = "lag_1", estimate = unname(b[2]), se = unname(se[2]), n_obs = N),
  list(term = "lag_15", estimate = unname(b[16]), se = unname(se[16]), n_obs = N)
)
out <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = est,
  method_metadata = list(
    estimator = "OLS of log(sales) on intercept and 15 lags of diff(log(vix)) (trading-day lags)",
    vcov = "Newey-West HAC, max lag 15, Bartlett weights 1-j/16, scaled by N/(N-16)"
  ),
  diagnostics = list(sample_rows = n, first_used_row = L + 2, n_obs = N)
)
write(toJSON(out, auto_unbox = TRUE, digits = NA, pretty = TRUE), "result.json")
