d <- read.csv("input.csv")
dd <- d[abs(d$score) < 1, ]
dd$w <- 1 - abs(dd$score)
dd$R <- as.numeric(dd$score >= 0)
dd$Rs <- dd$R * dd$score
dd$Ls <- (1 - dd$R) * dd$score
# Fully interacted WLS: coefficient on R is the discontinuity
rf_fit <- lm(earnings ~ R + Rs + Ls, data = dd, weights = w)
fs_fit <- lm(participated ~ R + Rs + Ls, data = dd, weights = w)
V_rf <- sandwich::vcovHC(rf_fit, type = "HC0")
V_fs <- sandwich::vcovHC(fs_fit, type = "HC0")
cat("rf:", coef(rf_fit)["R"], sqrt(V_rf["R","R"]), "\n")
cat("fs:", coef(fs_fit)["R"], sqrt(V_fs["R","R"]), "\n")
# Wald via IV with fully interacted instruments (just-identified, same point estimate)
iv <- AER::ivreg(earnings ~ R + Rs + Ls | R + Rs + Ls, data = dd, weights = w)
iv2 <- AER::ivreg(earnings ~ participated + Rs + Ls | R + Rs + Ls, data = dd, weights = w)
cat("tau via ivreg:", coef(iv2)["participated"], "\n")
cat("n:", nrow(dd), "\n")
