d <- read.csv("input.csv")
d$group <- factor(d$group)
fit <- aov(y ~ group, data = d)
tab <- summary(fit)[[1]]
F_stat <- tab[["F value"]][1]
df_num <- tab[["Df"]][1]
df_den <- tab[["Df"]][2]
p_val <- tab[["Pr(>F)"]][1]
n <- nrow(d)
out <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = list(
    list(term = "F", estimate = F_stat, se = NULL, n_obs = n),
    list(term = "df_num", estimate = df_num, se = NULL, n_obs = n),
    list(term = "df_den", estimate = df_den, se = NULL, n_obs = n),
    list(term = "p_value", estimate = p_val, se = NULL, n_obs = n)
  ),
  method_metadata = list(estimator = "one-way ANOVA (F test, aov)", vcov = "classical"),
  diagnostics = setNames(list(), character(0))
)
jsonlite::write_json(out, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE, null = "null")
