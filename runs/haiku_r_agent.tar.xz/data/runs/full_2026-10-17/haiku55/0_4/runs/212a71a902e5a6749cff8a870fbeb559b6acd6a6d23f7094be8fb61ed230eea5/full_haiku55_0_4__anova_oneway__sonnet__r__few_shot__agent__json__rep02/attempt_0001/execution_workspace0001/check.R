d <- read.csv("./input.csv")
g <- factor(d$group); k <- nlevels(g); N <- nrow(d)
gm <- mean(d$y); means <- tapply(d$y, g, mean); ns <- tapply(d$y, g, length)
ssb <- sum(ns * (means - gm)^2); ssw <- sum((d$y - means[as.character(g)])^2)
F_manual <- (ssb/(k-1)) / (ssw/(N-k))
r2 <- summary(lm(y ~ g, d))$r.squared
F_r2 <- (r2/(k-1)) / ((1-r2)/(N-k))
p_manual <- pf(F_manual, k-1, N-k, lower.tail=FALSE)
cat(sprintf("F manual=%.10f  F via R2=%.10f  p manual=%.10g\n", F_manual, F_r2, p_manual))
cat(sprintf("N=%d k=%d df=(%d,%d)\n", N, k, k-1, N-k))
r <- jsonlite::fromJSON("result.json")$estimates
print(r)
