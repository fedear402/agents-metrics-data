suppressPackageStartupMessages(library(jsonlite))

d <- read.csv("input.csv")
h <- 1
d <- d[abs(d$score) < h, ]
d$w <- 1 - abs(d$score)
d$right <- as.integer(d$score >= 0)

side_fit <- function(s) {
  r <- d[d$right == s, ]
  X <- cbind(1, r$score)
  w <- r$w
  XtWX_inv <- solve(t(X) %*% (X * w))
  Ymat <- cbind(r$earnings, r$participated)
  B <- XtWX_inv %*% t(X) %*% (w * Ymat)
  E <- Ymat - X %*% B
  meat <- function(a, b) t(X) %*% (X * (w^2 * a * b))
  V_rr <- XtWX_inv %*% meat(E[, 1], E[, 1]) %*% XtWX_inv
  V_ff <- XtWX_inv %*% meat(E[, 2], E[, 2]) %*% XtWX_inv
  V_rf <- XtWX_inv %*% meat(E[, 1], E[, 2]) %*% XtWX_inv
  list(
    n = nrow(r),
    a_rf = B[1, 1], a_ff = B[1, 2],
    V_rr = V_rr[1, 1], V_ff = V_ff[1, 1], V_rf = V_rf[1, 1]
  )
}

R <- side_fit(1)
L <- side_fit(0)

rf <- R$a_rf - L$a_rf
fs <- R$a_ff - L$a_ff
V_rf_var <- R$V_rr + L$V_rr
V_fs_var <- R$V_ff + L$V_ff
V_cov <- R$V_rf + L$V_rf

tau <- rf / fs
g <- c(1 / fs, -rf / fs^2)
Vmat <- matrix(c(V_rf_var, V_cov, V_cov, V_fs_var), 2, 2)
tau_se <- sqrt(as.numeric(t(g) %*% Vmat %*% g))

n_obs <- nrow(d)
res <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = tau, se = tau_se, n_obs = n_obs),
    list(term = "reduced_form", estimate = rf, se = sqrt(V_rf_var), n_obs = n_obs),
    list(term = "first_stage", estimate = fs, se = sqrt(V_fs_var), n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "Fuzzy RD, local linear, triangular kernel, bandwidth 1, separate slopes per side",
    vcov = "HC0 heteroskedasticity-robust sandwich, weights fixed; delta method for ratio"
  ),
  diagnostics = list(
    cutoff = 0, bandwidth = h,
    n_left = L$n, n_right = R$n
  )
)
writeLines(toJSON(res, auto_unbox = TRUE, digits = NA, pretty = TRUE), "result.json")

cat(sprintf("treatment_effect=%.10f se=%.10f\nreduced_form=%.10f se=%.10f\nfirst_stage=%.10f se=%.10f\nn_left=%d n_right=%d\n",
  tau, tau_se, rf, sqrt(V_rf_var), fs, sqrt(V_fs_var), L$n, R$n))

# Independent check: WLS intercepts via lm, and 2SLS with the same local sample and weights
fitL <- lm(earnings ~ score, data = d[d$right == 0, ], weights = w)
fitR <- lm(earnings ~ score, data = d[d$right == 1, ], weights = w)
fsL <- lm(participated ~ score, data = d[d$right == 0, ], weights = w)
fsR <- lm(participated ~ score, data = d[d$right == 1, ], weights = w)
rf_lm <- coef(fitR)[1] - coef(fitL)[1]
fs_lm <- coef(fsR)[1] - coef(fsL)[1]
cat(sprintf("check_lm rf=%.10f fs=%.10f ratio=%.10f\n", rf_lm, fs_lm, rf_lm / fs_lm))

suppressPackageStartupMessages(library(AER))
iv <- ivreg(earnings ~ participated + score + I(right * score) |
              score + right + I(right * score),
            data = d, weights = w)
cat(sprintf("check_2sls tau=%.10f\n", coef(iv)["participated"]))
