a <- read.csv("areas.csv"); e <- read.csv("employment.csv"); t <- read.csv("trade.csv"); cw <- read.csv("crosswalk.csv")
t$ind <- cw$industry[match(t$code, cw$code)]
emp_of <- function(ar, p, v, j) { r <- e[e$area==ar & e$period==p & e$vintage==v & e$industry==j, "employment"]; if (length(r)) r else 0 }
tot <- function(ar,p,v) a$total_employment[a$area==ar & a$period==p & a$vintage==v]
natv <- function(p,v,j) sum(sapply(unique(a$area), function(ar) emp_of(ar,p,v,j)))
expo <- function(ar, p, base, chg) {
  s <- 0
  for (j in 0:3) {
    r <- t[t$period==p & t$ind==j, ]
    s <- s + emp_of(ar,p,base,j)/tot(ar,p,base) * (r[[chg]]/natv(p,base,j)) / (r$price_index/100) / 1000 * (10/r$years)
  }
  s
}
cat(sprintf("hand x a0p0 %.12f\nhand x a0p1 %.12f\nhand z a0p0 %.12f\n",
  expo(0,0,"base","us_change"), expo(0,1,"base","us_change"), expo(0,0,"early","other_change")))
