suppressMessages(library(AER))
hh <- read.csv("households.csv"); d <- hh[hh$recipient == 0, ]
e <- d$eligible
d$d0 <- d$dose*(1-e); d$d1 <- d$dose*e; d$x0 <- 1-e; d$x1 <- e
d$b0 <- d$baseline*(1-e); d$b1 <- d$baseline*e
d$z0 <- d$instrument*(1-e); d$z1 <- d$instrument*e
f <- outcome ~ d0 + d1 + x0 + x1 + b0 + b1 - 1 | x0 + x1 + b0 + b1 + z0 + z1 - 1
m <- ivreg(f, data = d, weights = weight)
b <- coef(m)
m0 <- weighted.mean(d$dose[e==0], d$weight[e==0]); m1 <- weighted.mean(d$dose[e==1], d$weight[e==1])
ie <- b["d0"]*m0; ee <- b["d1"]*m1
N <- c(8400,1600)
cat(sprintf("%.12f %.12f %.12f\n", ie, ee, (N[1]*ie+N[2]*ee)/sum(N)))
