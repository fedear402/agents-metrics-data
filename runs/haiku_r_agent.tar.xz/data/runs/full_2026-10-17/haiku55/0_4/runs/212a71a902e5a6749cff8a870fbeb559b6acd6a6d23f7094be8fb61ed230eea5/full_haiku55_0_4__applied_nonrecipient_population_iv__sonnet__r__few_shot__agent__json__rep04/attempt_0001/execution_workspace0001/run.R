hh <- read.csv("households.csv")
census <- read.csv("census.csv")
d <- subset(hh, recipient == 0)
n_obs <- nrow(d)
d$g0 <- 1 - d$eligible
d$g1 <- d$eligible
d$d0 <- d$dose * d$g0
d$d1 <- d$dose * d$g1
X <- cbind(d0 = d$d0, d1 = d$d1, e0 = d$g0, e1 = d$g1, b0 = d$baseline * d$g0, b1 = d$baseline * d$g1)
Z <- cbind(e0 = d$g0, e1 = d$g1, b0 = d$baseline * d$g0, b1 = d$baseline * d$g1,
           z0 = d$instrument * d$g0, z1 = d$instrument * d$g1)
sw <- sqrt(d$weight)
Xw <- X * sw
Zw <- Z * sw
fitted <- qr.fitted(qr(Zw), Xw)
beta <- as.numeric(qr.coef(qr(fitted), d$outcome * sw))
names(beta) <- colnames(X)
slope0 <- beta["d0"]
slope1 <- beta["d1"]
mean_dose <- function(g) {
  a <- d[d$eligible == g, ]
  weighted.mean(a$dose, a$weight)
}
ineligible_effect <- unname(slope0 * mean_dose(0))
eligible_nonrecipient_effect <- unname(slope1 * mean_dose(1))
pop <- census$nonrecipient_population[match(0:1, census$eligible)]
population_effect <- weighted.mean(c(ineligible_effect, eligible_nonrecipient_effect), pop)
est <- c(ineligible_effect = ineligible_effect,
         eligible_nonrecipient_effect = eligible_nonrecipient_effect,
         population_effect = population_effect)
cat(sprintf("%s %.12g\n", names(est), est), sep = "")
res <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = lapply(names(est), function(t)
    list(term = t, estimate = unname(est[[t]]), se = NULL, n_obs = as.integer(n_obs))),
  method_metadata = list(
    estimator = "weighted 2SLS, pooled with full group interactions",
    endogenous = c("dose*(1-eligible)", "dose*eligible"),
    exogenous = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"),
    instruments = c("exogenous set", "instrument*(1-eligible)", "instrument*eligible"),
    weight = "weight",
    sample = "recipient == 0",
    counterfactual = "dose set to zero for all retained households (synthetic convention)",
    population_weights = as.numeric(pop)
  ),
  diagnostics = list(
    n_obs = as.integer(n_obs),
    slopes = list(dose_ineligible = unname(slope0), dose_eligible = unname(slope1)),
    weighted_mean_dose = list(ineligible = unname(mean_dose(0)), eligible = unname(mean_dose(1)))
  )
)
jsonlite::write_json(res, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE, null = "null")
