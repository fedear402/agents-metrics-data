suppressMessages(library(AER))
d <- read.csv("input.csv")
d <- d[abs(d$score) < 1, ]
d$w <- 1 - abs(d$score)
d$R <- as.numeric(d$score >= 0)
d$sR <- d$score * d$R
fs <- lm(participated ~ R + score + sR, data = d, weights = w)
rf <- lm(earnings ~ R + score + sR, data = d, weights = w)
iv <- ivreg(earnings ~ participated + score + sR | R + score + sR, data = d, weights = w)
cat(sprintf("FS R coef: %.8f\nRF R coef: %.8f\nIV ratio: %.8f\nRF/FS: %.8f\n",
  coef(fs)["R"], coef(rf)["R"], coef(iv)["participated"], coef(rf)["R"]/coef(fs)["R"]))
