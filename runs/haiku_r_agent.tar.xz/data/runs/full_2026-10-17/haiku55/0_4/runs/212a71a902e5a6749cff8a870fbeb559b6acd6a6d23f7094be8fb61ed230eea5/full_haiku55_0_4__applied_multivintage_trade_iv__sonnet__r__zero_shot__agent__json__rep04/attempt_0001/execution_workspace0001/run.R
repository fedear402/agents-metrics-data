suppressMessages(library(jsonlite))
cw  <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
tr  <- read.csv("trade.csv", stringsAsFactors = FALSE)
ar  <- read.csv("areas.csv", stringsAsFactors = FALSE)
em  <- read.csv("employment.csv", stringsAsFactors = FALSE)
oc  <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

tr <- merge(tr, cw, by = "code", all.x = TRUE)
stopifnot(!anyNA(tr$industry))
inds <- sort(unique(cw$industry))

grid <- merge(unique(ar[, c("area", "period")]), data.frame(vintage = rep(c("base", "early"), each = length(inds)), industry = rep(inds, 2)), by = NULL)
emf <- merge(grid, em, by = c("area", "period", "vintage", "industry"), all.x = TRUE)
emf$employment[is.na(emf$employment)] <- 0

nat <- aggregate(employment ~ period + vintage + industry, data = emf, FUN = sum)
names(nat)[4] <- "natemp"

d <- merge(emf, ar[, c("area", "period", "vintage", "total_employment")],
           by = c("area", "period", "vintage"))
d <- merge(d, nat, by = c("period", "vintage", "industry"))
d <- merge(d, tr[, c("period", "industry", "us_change", "other_change", "price_index", "years")],
           by = c("period", "industry"))
stopifnot(all(d$natemp > 0))

exposure <- function(vint, chg) {
  s <- d[d$vintage == vint, ]
  s$term <- (s$employment / s$total_employment) * (s[[chg]] / s$natemp) /
    (s$price_index / 100) / 1000 * (10 / s$years)
  aggregate(term ~ area + period, data = s, FUN = sum)
}
xv <- exposure("base", "us_change");   names(xv)[3] <- "x"
zv <- exposure("early", "other_change"); names(zv)[3] <- "z"

pop <- ar[ar$vintage == "base", c("area", "period", "population")]
est <- Reduce(function(a, b) merge(a, b, by = c("area", "period")),
              list(oc, xv, zv, pop))
stopifnot(nrow(est) == 72)

library(AER)
fit <- ivreg(change_pp ~ period + control + x | period + control + z,
             weights = population, data = est)
b <- coef(fit)
iv_slope <- unname(b["x"])

ex0p0 <- est$x[est$area == 0 & est$period == 0]
ex0p1 <- est$x[est$area == 0 & est$period == 1]
iz0p0 <- est$z[est$area == 0 & est$period == 0]

fmt <- function(v) format(v, digits = 15)
est_list <- list(
  list(term = "iv_slope", estimate = iv_slope, se = NULL, n_obs = nrow(est)),
  list(term = "exposure_area0_period0", estimate = ex0p0, se = NULL, n_obs = nrow(est)),
  list(term = "exposure_area0_period1", estimate = ex0p1, se = NULL, n_obs = nrow(est)),
  list(term = "instrument_area0_period0", estimate = iz0p0, se = NULL, n_obs = nrow(est))
)
out <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = est_list,
  method_metadata = list(estimator = "weighted 2SLS", weights = "base population",
                         instruments = "period, control, z", endogenous = "x"),
  diagnostics = list(n_area_period = nrow(est), periods = sort(unique(est$period)))
)
write_json(out, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE, null = "null")
cat(sprintf("iv_slope=%.12f x00=%.12f x01=%.12f z00=%.12f\n", iv_slope, ex0p0, ex0p1, iz0p0))
