hh <- read.csv("households.csv")
census <- read.csv("census.csv")

d <- subset(hh, recipient == 0)
n_obs <- nrow(d)
e <- d$eligible
ne <- 1 - e
w <- d$weight

Xend <- cbind(d$dose * ne, d$dose * e)
Cex <- cbind(ne, e, d$baseline * ne, d$baseline * e)
Zins <- cbind(d$instrument * ne, d$instrument * e)
X <- cbind(Cex, Xend)
Z <- cbind(Cex, Zins)

sw <- sqrt(w)
Xw <- X * sw
Zw <- Z * sw
fitted <- qr.fitted(qr(Zw), Xw)
beta <- as.numeric(qr.coef(qr(fitted), d$outcome * sw))
slopes <- beta[(ncol(Cex) + 1):ncol(X)]

group_mean_dose <- function(g) weighted.mean(d$dose[e == g], w[e == g])
effect <- c(slopes[1] * group_mean_dose(0), slopes[2] * group_mean_dose(1))
pop <- census$nonrecipient_population[match(0:1, census$eligible)]
population_effect <- weighted.mean(effect, pop)

est <- list(
  list(term = "ineligible_effect", estimate = effect[1], se = NA_real_, n_obs = as.integer(n_obs)),
  list(term = "eligible_nonrecipient_effect", estimate = effect[2], se = NA_real_, n_obs = as.integer(n_obs)),
  list(term = "population_effect", estimate = population_effect, se = NA_real_, n_obs = as.integer(n_obs))
)

result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = est,
  method_metadata = list(
    estimator = "weighted 2SLS, joint over recipient==0 rows",
    endogenous = c("dose*(1-eligible)", "dose*eligible"),
    exogenous = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"),
    instruments = c("exogenous", "instrument*(1-eligible)", "instrument*eligible"),
    weight = "weight",
    counterfactual = "dose set to zero for all retained households",
    group_population_weights = as.numeric(pop),
    se_note = "standard errors not requested; se reported as null"
  ),
  diagnostics = list(
    n_total_rows = nrow(hh),
    n_recipient_zero = n_obs,
    n_by_eligible = as.integer(table(factor(e, levels = 0:1))),
    dose_slopes = as.numeric(slopes),
    group_weighted_mean_dose = c(group_mean_dose(0), group_mean_dose(1)),
    rank_Z = qr(Zw)$rank,
    ncol_X = ncol(X)
  )
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE, na = "null")
cat(jsonlite::toJSON(as.list(setNames(c(effect, population_effect), c("ineligible_effect", "eligible_nonrecipient_effect", "population_effect"))), auto_unbox = TRUE, digits = 12), "\n")
