suppressPackageStartupMessages({library(jsonlite); library(AER)})

cw <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
tr <- read.csv("trade.csv", stringsAsFactors = FALSE)
ar <- read.csv("areas.csv", stringsAsFactors = FALSE)
em <- read.csv("employment.csv", stringsAsFactors = FALSE)
oc <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

tr <- merge(tr, cw, by = "code", all.x = TRUE)
stopifnot(!anyNA(tr$industry))

grid <- merge(ar, expand.grid(area = unique(ar$area), period = unique(ar$period),
                              industry = unique(tr$industry)), by = c("area", "period"))
emp <- merge(grid, em, by = c("area", "period", "vintage", "industry"), all.x = TRUE)
emp$employment[is.na(emp$employment)] <- 0

nat <- aggregate(employment ~ period + vintage + industry, data = emp, FUN = sum)
names(nat)[4] <- "nat_emp"
stopifnot(all(nat$nat_emp > 0))

emp <- merge(emp, tr, by = c("period", "industry"))
emp <- merge(emp, nat, by = c("period", "vintage", "industry"))

build <- function(base_v, change_col) {
  d <- emp[emp$vintage == base_v, ]
  nat_d <- nat[nat$vintage == base_v, c("period", "industry", "nat_emp")]
  d <- merge(d, nat_d, by = c("period", "industry"), suffixes = c("", ".n"))
  d$term <- (d$employment / d$total_employment) *
            (d[[change_col]] / d$nat_emp.n) /
            (d$price_index / 100) / 1000 * (10 / d$years)
  agg <- aggregate(term ~ area + period, data = d, FUN = sum)
  names(agg)[3] <- "val"
  agg
}

x_df <- build("base", "us_change")
z_df <- build("early", "other_change")
names(x_df)[3] <- "x"; names(z_df)[3] <- "z"

pan <- merge(oc, ar[ar$vintage == "base", c("area", "period", "population")], by = c("area", "period"))
pan <- merge(pan, x_df, by = c("area", "period"))
pan <- merge(pan, z_df, by = c("area", "period"))
stopifnot(nrow(pan) == 72)

fit <- ivreg(change_pp ~ period + control + x | period + control + z,
             data = pan, weights = population)
b <- coef(fit)

# Matrix-form weighted 2SLS check
w <- sqrt(pan$population)
X <- cbind(1, pan$period, pan$control, pan$x)
Z <- cbind(1, pan$period, pan$control, pan$z)
y <- pan$change_pp
Xw <- X * w; Zw <- Z * w; yw <- y * w
PZ <- Zw %*% solve(crossprod(Zw), t(Zw))
b_manual <- solve(t(Xw) %*% PZ %*% Xw, t(Xw) %*% PZ %*% yw)
stopifnot(max(abs(b - as.vector(b_manual))) < 1e-8)

a0p0 <- pan$x[pan$area == 0 & pan$period == 0]
a0p1 <- pan$x[pan$area == 0 & pan$period == 1]
z0p0 <- pan$z[pan$area == 0 & pan$period == 0]

cat(sprintf("iv_slope %.12f\nx a0p0 %.12f\nx a0p1 %.12f\nz a0p0 %.12f\nmanual slope %.12f\n",
            b["x"], a0p0, a0p1, z0p0, b_manual[4]))

n <- nrow(pan)
mk <- function(term, est) list(term = term, estimate = unname(est), se = NA_real_, n_obs = as.integer(n))
res <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = list(
    mk("iv_slope", b["x"]),
    mk("exposure_area0_period0", a0p0),
    mk("exposure_area0_period1", a0p1),
    mk("instrument_area0_period0", z0p0)
  ),
  method_metadata = list(
    estimator = "weighted 2SLS (AER::ivreg)",
    outcome = "change_pp",
    endogenous = "x",
    instrument = "z",
    exogenous = c("intercept", "period", "control"),
    weight = "base-vintage population",
    n_obs = as.integer(n)
  ),
  diagnostics = list(
    matrix_check_max_abs_diff = max(abs(b - as.vector(b_manual))),
    n_area_period_rows = as.integer(n),
    price_index_by_period = as.list(setNames(tapply(tr$price_index, tr$period, unique), NULL))
  )
)
write_json(res, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE, na = "null")
