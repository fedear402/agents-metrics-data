library(jsonlite)
d <- read.csv("./input.csv")
d <- d[complete.cases(d[, c("group", "y")]), ]
d$group <- factor(d$group)
fit <- aov(y ~ group, data = d)
s <- summary(fit)[[1]]
F_stat <- s[["F value"]][1]
df_num <- s[["Df"]][1]
df_den <- s[["Df"]][2]
p_val <- s[["Pr(>F)"]][1]
n <- nrow(d)
out <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = list(
    list(term = "F", estimate = unname(F_stat), se = NA, n_obs = n),
    list(term = "df_num", estimate = unname(df_num), se = NA, n_obs = n),
    list(term = "df_den", estimate = unname(df_den), se = NA, n_obs = n),
    list(term = "p_value", estimate = unname(p_val), se = NA, n_obs = n)
  ),
  method_metadata = list(estimator = "One-way ANOVA (F test, aov)", vcov = "none"),
  diagnostics = structure(list(), names = character(0))
)
write_json(out, "result.json", auto_unbox = TRUE, digits = NA)
