suppressMessages(library(sandwich))
d <- read.csv("input.csv"); d <- d[abs(d$score) < 1, ]
side <- function(df, y) {
  w <- 1 - abs(df$score)
  f <- lm(as.formula(paste(y, "~ score")), data = df, weights = w)
  V <- vcovHC(f, type = "HC0")
  c(a = unname(coef(f)[1]), v = unname(V[1, 1]))
}
L <- d[d$score < 0, ]; Rt <- d[d$score >= 0, ]
rf_l <- side(L, "earnings"); rf_r <- side(Rt, "earnings")
fs_l <- side(L, "participated"); fs_r <- side(Rt, "participated")
rf <- rf_r["a"] - rf_l["a"]; vrf <- rf_r["v"] + rf_l["v"]
fs <- fs_r["a"] - fs_l["a"]; vfs <- fs_r["v"] + fs_l["v"]
ratio <- rf / fs
se <- sqrt(vrf / fs^2 + rf^2 * vfs / fs^4)
print(c(rf = unname(rf), fs = unname(fs), ratio = unname(ratio), se = unname(se)))
