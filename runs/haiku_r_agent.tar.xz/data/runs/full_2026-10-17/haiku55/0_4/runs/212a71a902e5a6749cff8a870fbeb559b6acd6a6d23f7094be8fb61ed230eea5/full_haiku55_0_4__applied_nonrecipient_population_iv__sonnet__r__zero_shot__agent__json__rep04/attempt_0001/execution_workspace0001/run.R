library(jsonlite)

hh <- read.csv("households.csv")
census <- read.csv("census.csv")

d <- hh[hh$recipient == 0, ]
n <- nrow(d)
e <- d$eligible
w <- d$weight
dose <- d$dose
base <- d$baseline
inst <- d$instrument
y <- d$outcome

X <- cbind(dose * (1 - e), dose * e, 1 - e, e, base * (1 - e), base * e)
Z <- cbind(1 - e, e, base * (1 - e), base * e, inst * (1 - e), inst * e)

ZW <- t(Z * w)
beta <- solve(ZW %*% X, ZW %*% y)[, 1]
slope0 <- beta[1]
slope1 <- beta[2]

wmean_dose <- function(g) {
  s <- e == g
  sum(w[s] * dose[s]) / sum(w[s])
}
m0 <- wmean_dose(0)
m1 <- wmean_dose(1)

ineligible_effect <- slope0 * m0
eligible_nonrecipient_effect <- slope1 * m1

pop <- setNames(census$nonrecipient_population, census$eligible)
population_effect <- (pop["0"] * ineligible_effect + pop["1"] * eligible_nonrecipient_effect) /
  (pop["0"] + pop["1"])

est <- function(term, value) {
  list(term = term, estimate = unname(as.numeric(value)), se = NULL, n_obs = as.integer(n))
}

result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = list(
    est("ineligible_effect", ineligible_effect),
    est("eligible_nonrecipient_effect", eligible_nonrecipient_effect),
    est("population_effect", population_effect)
  ),
  method_metadata = list(
    estimator = "weighted just-identified 2SLS, no intercept",
    sample = "households with recipient == 0",
    regression_weight = "weight",
    endogenous = c("dose*(1-eligible)", "dose*eligible"),
    exogenous = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"),
    instruments = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible",
                    "instrument*(1-eligible)", "instrument*eligible"),
    group_effect = "dose slope times household-weighted mean dose in group",
    counterfactual = "dose set to zero for every retained household (synthetic attribution convention)",
    population_weights = "census nonrecipient_population by eligible group"
  ),
  diagnostics = list(
    n_retained = as.integer(n),
    n_eligible0 = as.integer(sum(e == 0)),
    n_eligible1 = as.integer(sum(e == 1)),
    dose_slope_ineligible = unname(slope0),
    dose_slope_eligible = unname(slope1),
    weighted_mean_dose_ineligible = m0,
    weighted_mean_dose_eligible = m1,
    se_note = "standard errors not requested; se set to null"
  )
)

write_json(result, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE, null = "null")
print(unlist(lapply(result$estimates, function(x) c(term = x$term, estimate = format(x$estimate, digits = 12), n_obs = x$n_obs))))
cat(sprintf("slopes: %.12f %.12f\nmeans: %.12f %.12f\n", slope0, slope1, m0, m1))
