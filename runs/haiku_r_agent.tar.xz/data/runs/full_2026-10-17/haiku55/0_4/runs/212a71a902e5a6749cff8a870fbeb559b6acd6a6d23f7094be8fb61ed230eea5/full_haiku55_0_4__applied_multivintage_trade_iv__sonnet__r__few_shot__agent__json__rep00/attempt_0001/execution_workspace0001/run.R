cw <- read.csv("crosswalk.csv")
tr <- read.csv("trade.csv")
ar <- read.csv("areas.csv")
em <- read.csv("employment.csv")
oc <- read.csv("outcomes.csv")

tr$industry <- cw$industry[match(tr$code, cw$code)]

grid <- expand.grid(area = unique(ar$area), period = unique(ar$period),
                    vintage = c("base", "early"), industry = sort(unique(cw$industry)),
                    stringsAsFactors = FALSE)
emp <- merge(grid, em, by = c("area", "period", "vintage", "industry"), all.x = TRUE)
emp$employment[is.na(emp$employment)] <- 0

nat <- aggregate(employment ~ period + vintage + industry, data = emp, FUN = sum)
names(nat)[4] <- "nat_employment"

emp <- merge(emp, nat, by = c("period", "vintage", "industry"))
emp <- merge(emp, ar[, c("area", "period", "vintage", "total_employment")],
             by = c("area", "period", "vintage"))
emp <- merge(emp, tr[, c("period", "industry", "us_change", "other_change", "price_index", "years")],
             by = c("period", "industry"))

emp$chg <- ifelse(emp$vintage == "base", emp$us_change, emp$other_change)
emp$term <- (emp$employment / emp$total_employment) * (emp$chg / emp$nat_employment) /
  (emp$price_index / 100) / 1000 * (10 / emp$years)

expo <- aggregate(term ~ area + period + vintage, data = emp, FUN = sum)
x_df <- expo[expo$vintage == "base", c("area", "period", "term")]
z_df <- expo[expo$vintage == "early", c("area", "period", "term")]
names(x_df)[3] <- "x"; names(z_df)[3] <- "z"

pop <- ar[ar$vintage == "base", c("area", "period", "population")]
d <- merge(oc, x_df, by = c("area", "period"))
d <- merge(d, z_df, by = c("area", "period"))
d <- merge(d, pop, by = c("area", "period"))
d <- d[order(d$period, d$area), ]

iv <- function(y, C, x, z, w = rep(1, length(y))) {
  X <- cbind(C, x) * sqrt(w); Z <- cbind(C, z) * sqrt(w)
  fitted <- qr.fitted(qr(Z), X)
  as.numeric(qr.coef(qr(fitted), y * sqrt(w)))[ncol(X)]
}

C <- cbind(1, d$period, d$control)
slope <- iv(d$change_pp, C, d$x, d$z, d$population)

n_obs <- nrow(d)
a0p0 <- d[d$area == 0 & d$period == 0, ]
a0p1 <- d[d$area == 0 & d$period == 1, ]

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = list(
    list(term = "iv_slope", estimate = slope, se = NULL, n_obs = as.integer(n_obs)),
    list(term = "exposure_area0_period0", estimate = a0p0$x, se = NULL, n_obs = as.integer(n_obs)),
    list(term = "exposure_area0_period1", estimate = a0p1$x, se = NULL, n_obs = as.integer(n_obs)),
    list(term = "instrument_area0_period0", estimate = a0p0$z, se = NULL, n_obs = as.integer(n_obs))
  ),
  method_metadata = list(
    estimator = "weighted 2SLS",
    outcome = "change_pp",
    endogenous = "x",
    instrument = "z",
    exogenous = c("intercept", "period", "control"),
    weight = "base-vintage population",
    sample = "all area-period observations"
  ),
  diagnostics = list(
    n_obs = as.integer(n_obs),
    national_denominators_positive = all(nat$nat_employment > 0)
  )
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = 15, pretty = TRUE, null = "null")
cat(sprintf("iv_slope %.12f\nx00 %.12f\nx01 %.12f\nz00 %.12f\nn %d\n",
            slope, a0p0$x, a0p1$x, a0p0$z, n_obs))
