d <- read.csv("households.csv"); d <- d[d$recipient == 0, ]
e <- d$eligible; ne <- 1 - e; w <- d$weight; y <- d$outcome
X <- cbind(d$dose*ne, d$dose*e, ne, e, d$baseline*ne, d$baseline*e)
Z <- cbind(ne, e, d$baseline*ne, d$baseline*e, d$instrument*ne, d$instrument*e)
ZW <- t(Z * w)
XZ <- t(X) %*% t(ZW)
A <- solve(ZW %*% Z)
beta <- solve(XZ %*% A %*% t(XZ), XZ %*% A %*% (ZW %*% y))
print(beta[1:2], digits = 12)
wm0 <- sum(w[e==0]*d$dose[e==0])/sum(w[e==0]); wm1 <- sum(w[e==1]*d$dose[e==1])/sum(w[e==1])
i0 <- beta[1]*wm0; i1 <- beta[2]*wm1
print(c(i0, i1, (8400*i0 + 1600*i1)/10000), digits = 12)
