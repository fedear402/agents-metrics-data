d <- read.csv("input.csv")
h <- 1
d <- d[abs(d$score) < h, ]
d$w <- 1 - abs(d$score)
n_obs <- nrow(d)

side_fit <- function(s) {
  ss <- d[(s == 1 & d$score >= 0) | (s == 0 & d$score < 0), ]
  X <- cbind(1, ss$score)
  w <- ss$w
  XtWX_inv <- solve(t(X) %*% (X * w))
  a <- XtWX_inv[1, ]
  xa <- as.vector(X %*% a)
  b_y <- sum(a * colSums(X * w * ss$earnings))
  b_d <- sum(a * colSums(X * w * ss$participated))
  ey <- ss$earnings - X %*% (XtWX_inv %*% colSums(X * w * ss$earnings))
  ed <- ss$participated - X %*% (XtWX_inv %*% colSums(X * w * ss$participated))
  k <- w^2 * xa^2
  list(
    by = b_y, bd = b_d,
    Vyy = sum(k * ey^2), Vdd = sum(k * ed^2), Vyd = sum(k * ey * ed),
    n = nrow(ss), ss = ss, X = X, w = w
  )
}

R <- side_fit(1)
L <- side_fit(0)

rf <- R$by - L$by
fs <- R$bd - L$bd
V_rf <- R$Vyy + L$Vyy
V_fs <- R$Vdd + L$Vdd
C <- R$Vyd + L$Vyd

tau <- rf / fs
grad <- c(1 / fs, -rf / fs^2)
V_tau <- grad[1]^2 * V_rf + grad[2]^2 * V_fs + 2 * grad[1] * grad[2] * C

est <- list(
  list(term = "treatment_effect", estimate = tau, se = sqrt(V_tau), n_obs = n_obs),
  list(term = "reduced_form", estimate = rf, se = sqrt(V_rf), n_obs = n_obs),
  list(term = "first_stage", estimate = fs, se = sqrt(V_fs), n_obs = n_obs)
)

out <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = est,
  method_metadata = list(
    estimator = "Fuzzy RD, local linear WLS with triangular kernel, bandwidth 1, separate slopes and intercepts per side, Wald ratio",
    vcov = "HC0 heteroskedasticity-robust sandwich, delta method for ratio with joint covariance"
  ),
  diagnostics = list(
    n_left = L$n, n_right = R$n,
    cov_rf_fs = C,
    bandwidth = h, cutoff = 0
  )
)
jsonlite_ok <- requireNamespace("jsonlite", quietly = TRUE)
if (jsonlite_ok) {
  txt <- jsonlite::toJSON(out, auto_unbox = TRUE, digits = NA, pretty = TRUE)
} else {
  stop("jsonlite required")
}
writeLines(txt, "result.json")

# Independent checks
ref_side <- function(ss, yvar) {
  f <- lm(as.formula(paste(yvar, "~ score")), data = ss, weights = w)
  V <- sandwich::vcovHC(f, type = "HC0")
  c(coef(f)[1], sqrt(V[1, 1]))
}
rR_y <- ref_side(R$ss, "earnings"); rL_y <- ref_side(L$ss, "earnings")
rR_d <- ref_side(R$ss, "participated"); rL_d <- ref_side(L$ss, "participated")
chk <- list(
  rf_lm = rR_y[1] - rL_y[1],
  fs_lm = rR_d[1] - rL_d[1],
  rf_se_lm = sqrt(rR_y[2]^2 + rL_y[2]^2),
  fs_se_lm = sqrt(rR_d[2]^2 + rL_d[2]^2)
)
dd <- d
dd$right <- as.numeric(dd$score >= 0)
dd$sR <- dd$score * dd$right
dd$sL <- dd$score * (1 - dd$right)
iv <- AER::ivreg(earnings ~ participated + sR + sL | right + sR + sL,
                 data = dd, weights = dd$w)
chk$tau_ivreg <- unname(coef(iv)["participated"])
chk$tau_wald <- tau
chk$rf_diff <- chk$rf_lm - rf
chk$fs_diff <- chk$fs_lm - fs
chk$se_rf_diff <- chk$rf_se_lm - sqrt(V_rf)
print(chk)
