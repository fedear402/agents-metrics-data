d <- read.csv("input.csv"); d <- d[abs(d$score) < 1, ]; d$w <- 1 - abs(d$score); d$right <- as.integer(d$score >= 0)
infl <- function(s, y) {
  r <- d[d$right == s, ]; X <- cbind(1, r$score); w <- r$w
  A <- solve(t(X) %*% (X * w))
  b <- A %*% t(X) %*% (w * r[[y]])
  e <- r[[y]] - X %*% b
  # influence on intercept: row1 of A times x_i w_i e_i
  phi <- (X %*% t(A[1, , drop = FALSE])) * w * e
  list(a = b[1], phi = as.numeric(phi), idx = r$id)
}
ar <- infl(1, "earnings"); al <- infl(0, "earnings")
fr <- infl(1, "participated"); fl <- infl(0, "participated")
rf <- ar$a - al$a; fs <- fr$a - fl$a
se_rf <- sqrt(sum(ar$phi^2) + sum(al$phi^2))
se_fs <- sqrt(sum(fr$phi^2) + sum(fl$phi^2))
cov_rf_fs <- sum(ar$phi * fr$phi) + sum(al$phi * fl$phi)
tau <- rf / fs
se_tau <- sqrt((se_rf^2)/fs^2 + rf^2*se_fs^2/fs^4 - 2*rf*cov_rf_fs/fs^3)
cat(sprintf("check_se rf_se=%.10f fs_se=%.10f tau=%.10f tau_se=%.10f\n", se_rf, se_fs, tau, se_tau))
