suppressMessages(library(AER))
hh <- read.csv("households.csv")
d <- hh[hh$recipient == 0, ]
e <- d$eligible; ne <- 1 - e; w <- d$weight; dose <- d$dose; base <- d$baseline; inst <- d$instrument
d$ne <- ne; d$de <- d$dose * ne; d$de1 <- d$dose * e; d$bne <- base * ne; d$be <- base * e
d$ine <- inst * ne; d$ie <- inst * e
fit <- ivreg(outcome ~ -1 + de + de1 + ne + e + bne + be | -1 + ne + e + bne + be + ine + ie,
             weights = weight, data = d)
b <- coef(fit)
m0 <- sum(w[e == 0] * dose[e == 0]) / sum(w[e == 0])
m1 <- sum(w[e == 1] * dose[e == 1]) / sum(w[e == 1])
ie0 <- b["de"] * m0; ie1 <- b["de1"] * m1
cat(sprintf("AER ineligible=%.10f eligible=%.10f population=%.10f\n", ie0, ie1, (8400*ie0 + 1600*ie1)/10000))
