d <- read.csv("./input.csv")
d <- d[!is.na(d$y) & !is.na(d$group), ]
d$group <- factor(d$group)

fit <- aov(y ~ group, data = d)
tab <- summary(fit)[[1]]
F_stat <- tab[["F value"]][1]
df_num <- tab[["Df"]][1]
df_den <- tab[["Df"]][2]
p_val <- tab[["Pr(>F)"]][1]

est <- function(term, value) {
  list(term = term, estimate = unname(as.numeric(value)), se = NULL, n_obs = nrow(d))
}
out <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = list(est("F", F_stat), est("df_num", df_num), est("df_den", df_den), est("p_value", p_val)),
  method_metadata = list(estimator = "One-way ANOVA (aov, Type I SS) of y on group",
                         vcov = "not applicable (classical F test)"),
  diagnostics = setNames(list(), character(0))
)
jsonlite::write_json(out, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE, null = "null")
print(tab)
