suppressMessages(library(AER))
hh <- read.csv("households.csv")
d <- hh[hh$recipient == 0, ]
e <- d$eligible
d$d0 <- d$dose * (1 - e); d$d1 <- d$dose * e
d$x0 <- 1 - e; d$x1 <- e
d$b0 <- d$baseline * (1 - e); d$b1 <- d$baseline * e
d$z4 <- d$instrument * (1 - e); d$z5 <- d$instrument * e
fit <- ivreg(outcome ~ d0 + d1 + x0 + x1 + b0 + b1 - 1 |
               x0 + x1 + b0 + b1 + z4 + z5 - 1, data = d, weights = weight)
b <- coef(fit)
cat(sprintf("ivreg slopes: %.12f %.12f\n", b["d0"], b["d1"]))
m0 <- weighted.mean(d$dose[e == 0], d$weight[e == 0])
m1 <- weighted.mean(d$dose[e == 1], d$weight[e == 1])
ie <- b["d0"] * m0; ee <- b["d1"] * m1
cat(sprintf("ineligible %.12f eligible %.12f population %.12f\n", ie, ee, (8400 * ie + 1600 * ee) / 10000))
cat("n retained:", nrow(d), " any NA in used cols:", anyNA(d[, c("outcome","d0","d1","x0","x1","b0","b1","z4","z5","weight")]), "\n")
