ar <- read.csv("areas.csv"); em <- read.csv("employment.csv"); tr <- read.csv("trade.csv")
cw <- read.csv("crosswalk.csv"); oc <- read.csv("outcomes.csv")
tr <- merge(tr, cw, by = "code")
emp <- function(a, p, v, j) { r <- em[em$area==a & em$period==p & em$vintage==v & em$industry==j, "employment"]; if (length(r)==0) 0 else r }
tot <- function(a, p, v) ar$total_employment[ar$area==a & ar$period==p & ar$vintage==v]
natE <- function(p, v, j) sum(sapply(unique(ar$area), function(a) emp(a,p,v,j)))
ex <- function(a, p, v, chg) {
  s <- 0
  for (j in 0:3) {
    t <- tr[tr$period==p & tr$industry==j,]
    s <- s + (emp(a,p,v,j)/tot(a,p,v)) * (t[[chg]]/natE(p,v,j)) / (t$price_index/100) / 1000 * (10/t$years)
  }
  s
}
X <- sapply(0:1, function(p) sapply(unique(ar$area), function(a) ex(a,p,"base","us_change")))
cat(sprintf("manual x a0p0=%.12f a0p1=%.12f z a0p0=%.12f\n", ex(0,0,"base","us_change"), ex(0,1,"base","us_change"), ex(0,0,"early","other_change")))
# manual weighted 2SLS via matrix algebra
rows <- merge(oc, ar[ar$vintage=="base", c("area","period","population")], by=c("area","period"))
xs <- mapply(function(a,p) ex(a,p,"base","us_change"), rows$area, rows$period)
zs <- mapply(function(a,p) ex(a,p,"early","other_change"), rows$area, rows$period)
y <- rows$change_pp; W <- diag(rows$population)
X1 <- cbind(1, rows$period, rows$control, xs); Z <- cbind(1, rows$period, rows$control, zs)
Pz <- Z %*% solve(t(Z) %*% W %*% Z) %*% t(Z) %*% W
Xh <- Pz %*% X1; b <- solve(t(Xh) %*% W %*% Xh) %*% t(Xh) %*% W %*% y
cat(sprintf("manual iv_slope=%.12f n=%d\n", b[4], nrow(rows)))
