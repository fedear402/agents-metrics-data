d <- read.csv("input.csv")
regions <- d[!duplicated(d$region_id), c("region_id", "region_weight", "x", "y")]
e <- regions$region_weight / sum(regions$region_weight)
S <- xtabs(share ~ region_id + industry_id, data = d)
S <- S[as.character(regions$region_id), ]
shock_n <- sapply(colnames(S), function(k) unique(d$shock[d$industry_id == as.integer(k)]))
z <- drop(S %*% shock_n)
x <- regions$x; y <- regions$y
# Independent regional weighted IV via the closed form on centered data
w <- e
cw <- function(v) v - sum(w * v)
yc <- cw(y); xc <- cw(x); zc <- cw(z)
iv_slope <- sum(w * zc * yc) / sum(w * zc * xc)
fs_slope <- sum(w * zc * xc) / sum(w * zc^2)
cat(sprintf("regional IV slope closed form: %.12f\n", iv_slope))
cat(sprintf("regional first stage closed form: %.12f\n", fs_slope))
# Independent check using lm weighted regressions
fs_lm <- coef(lm(x ~ z, weights = e))[2]
cat(sprintf("regional first stage lm: %.12f\n", fs_lm))
# Reduced form / first stage ratio via lm
rf <- coef(lm(y ~ z, weights = e))[2]
cat(sprintf("reduced form / first stage ratio: %.12f\n", rf / fs_lm))
s <- colSums(e * S)
cat(sprintf("sum s_n = %.12f, effective_shocks identity: %.12f\n", sum(s), 1/sum(s^2)))
