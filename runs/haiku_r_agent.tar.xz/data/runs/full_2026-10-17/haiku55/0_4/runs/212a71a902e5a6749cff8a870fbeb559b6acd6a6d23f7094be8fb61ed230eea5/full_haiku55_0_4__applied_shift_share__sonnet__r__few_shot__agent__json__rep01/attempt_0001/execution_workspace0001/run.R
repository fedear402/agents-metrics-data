suppressPackageStartupMessages(library(jsonlite))

d <- read.csv("input.csv", stringsAsFactors = FALSE)
stopifnot(!anyNA(d))

share_sums <- tapply(d$share, d$region_id, sum)
stopifnot(max(abs(share_sums - 1)) < 1e-8)
stopifnot(all(tapply(d$region_weight, d$region_id, function(v) length(unique(v))) == 1))
stopifnot(all(tapply(d$x, d$region_id, function(v) length(unique(v))) == 1))
stopifnot(all(tapply(d$y, d$region_id, function(v) length(unique(v))) == 1))
stopifnot(all(tapply(d$shock, d$industry_id, function(v) length(unique(v))) == 1))

# Regional variables: one row per region
d$z_part <- d$share * d$shock
reg <- aggregate(cbind(region_weight, x, y, z = z_part) ~ region_id, data = d, FUN = function(v) v[1])
zsum <- aggregate(z_part ~ region_id, data = d, FUN = sum)
reg$z <- zsum$z_part[match(reg$region_id, zsum$region_id)]
reg$e <- reg$region_weight / sum(reg$region_weight)

wmean <- function(v, w) sum(w * v) / sum(w)
reg$y0 <- reg$y - wmean(reg$y, reg$e)
reg$x0 <- reg$x - wmean(reg$x, reg$e)
reg$z0 <- reg$z - wmean(reg$z, reg$e)

# Industry-level shift-share aggregates
d <- merge(d, reg[, c("region_id", "e", "y0", "x0", "z0")], by = "region_id")
ind_list <- split(d, d$industry_id)
ind <- do.call(rbind, lapply(ind_list, function(g) {
  s <- sum(g$e * g$share)
  data.frame(industry_id = g$industry_id[1], shock = g$shock[1], s = s,
             ybar = sum(g$e * g$share * g$y0) / s,
             xbar = sum(g$e * g$share * g$x0) / s,
             zbar = sum(g$e * g$share * g$z0) / s)
}))
N <- nrow(ind)
stopifnot(all(ind$s > 0))

# Weighted IV with intercept and endogenous regressor, exactly identified.
# Shock-level HC1 sandwich with structural residuals and analytic weights s_n.
shock_iv <- function(dep, endo) {
  X <- cbind(1, endo)
  Z <- cbind(1, ind$shock)
  w <- ind$s
  A <- crossprod(Z, w * X)
  beta <- solve(A, crossprod(Z, w * dep))
  u <- drop(dep - X %*% beta)
  scores <- Z * (w * u)
  Ainv <- solve(A)
  V <- N / (N - 2) * Ainv %*% crossprod(scores) %*% t(Ainv)
  c(slope = beta[2], se = sqrt(V[2, 2]))
}

eff <- shock_iv(ind$ybar, ind$xbar)
fs <- shock_iv(ind$xbar, ind$zbar)

# Regional counterparts for verification
w_e <- reg$e
reg_effect <- sum(w_e * reg$z0 * reg$y0) / sum(w_e * reg$z0 * reg$x0)
reg_fs <- sum(w_e * reg$z0 * reg$x0) / sum(w_e * reg$z0^2)
eff_shocks <- 1 / sum(ind$s^2)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = unname(eff["slope"]), se = unname(eff["se"]), n_obs = as.integer(N)),
    list(term = "first_stage", estimate = unname(fs["slope"]), se = unname(fs["se"]), n_obs = as.integer(N)),
    list(term = "effective_shocks", estimate = eff_shocks, se = NULL, n_obs = as.integer(N))
  ),
  method_metadata = list(
    estimator = "Weighted 2SLS of regional y on intercept and x, instrumented by shift-share z; equivalent Borusyak-Hull-Jaravel shock-level IV weighted by s_n",
    vcov = "Shock-level HC1 sandwich (N/(N-2) multiplier), structural residuals, analytic weights, no clustering"
  ),
  diagnostics = list(
    n_regions = nrow(reg),
    n_industries = N,
    regional_effect_check = unname(reg_effect),
    regional_first_stage_check = unname(reg_fs),
    shock_effect_minus_regional = unname(eff["slope"] - reg_effect),
    shock_first_stage_minus_regional = unname(fs["slope"] - reg_fs),
    sum_s = sum(ind$s)
  )
)
write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
print(result$estimates)
print(result$diagnostics)
