library(jsonlite)

cw <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
tr <- read.csv("trade.csv", stringsAsFactors = FALSE)
ar <- read.csv("areas.csv", stringsAsFactors = FALSE)
em <- read.csv("employment.csv", stringsAsFactors = FALSE)
oc <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

tr <- merge(tr, cw, by = "code")
ind <- sort(unique(cw$industry))
areas <- sort(unique(ar$area))
periods <- sort(unique(ar$period))

full_emp <- function(v) {
  e <- em[em$vintage == v, c("area", "period", "industry", "employment")]
  g <- expand.grid(area = areas, period = periods, industry = ind)
  m <- merge(g, e, by = c("area", "period", "industry"), all.x = TRUE)
  m$employment[is.na(m$employment)] <- 0
  m
}

calc_exposure <- function(v, amt_col) {
  Em <- full_emp(v)
  nat <- aggregate(employment ~ period + industry, Em, sum)
  names(nat)[3] <- "natl"
  m <- merge(Em, nat, by = c("period", "industry"))
  m <- merge(m, tr[, c("period", "industry", amt_col, "price_index", "years")],
             by = c("period", "industry"))
  tot <- ar[ar$vintage == v, c("area", "period", "total_employment")]
  m <- merge(m, tot, by = c("area", "period"))
  m$term <- m$employment / m$total_employment * m[[amt_col]] / m$natl /
    (m$price_index / 100) / 1000 * (10 / m$years)
  aggregate(term ~ area + period, m, sum)
}

x <- calc_exposure("base", "us_change")
names(x)[3] <- "x"
z <- calc_exposure("early", "other_change")
names(z)[3] <- "z"
pop <- ar[ar$vintage == "base", c("area", "period", "population")]

d <- merge(merge(merge(x, z, by = c("area", "period")), oc, by = c("area", "period")), pop,
           by = c("area", "period"))
d <- d[order(d$area, d$period), ]
n_obs <- nrow(d)

iv <- function(y, C, x, z, w) {
  X <- cbind(C, x) * sqrt(w)
  Z <- cbind(C, z) * sqrt(w)
  fitted <- qr.fitted(qr(Z), X)
  as.numeric(qr.coef(qr(fitted), y * sqrt(w)))[ncol(X)]
}

C <- cbind(1, d$period, d$control)
iv_slope <- iv(d$change_pp, C, d$x, d$z, d$population)

pick <- function(col, a, p) d[[col]][d$area == a & d$period == p]
exp00 <- pick("x", 0, 0)
exp01 <- pick("x", 0, 1)
ins00 <- pick("z", 0, 0)

est <- function(term, value) list(term = term, estimate = value, se = NULL, n_obs = n_obs)

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = list(
    est("iv_slope", iv_slope),
    est("exposure_area0_period0", exp00),
    est("exposure_area0_period1", exp01),
    est("instrument_area0_period0", ins00)
  ),
  method_metadata = list(
    estimator = "weighted 2SLS",
    outcome = "change_pp",
    endogenous = "x",
    instruments = c("intercept", "period", "control", "z"),
    exogenous = c("intercept", "period", "control"),
    weight = "base-vintage population",
    sample = "all area-period observations"
  ),
  diagnostics = list(
    n_obs = as.integer(n_obs),
    n_areas = length(areas),
    n_periods = length(periods),
    n_industries = length(ind)
  )
)

write_json(result, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE, null = "null")
cat(toJSON(result$estimates, auto_unbox = TRUE, digits = NA, null = "null"), "\n")
