suppressMessages(library(sandwich))
d <- read.csv("input.csv"); d <- d[abs(d$score) < 1, ]
d$w <- 1 - abs(d$score); d$R <- as.numeric(d$score >= 0)
d$sR <- d$score * d$R; d$sL <- d$score * (1 - d$R)
se_of <- function(y) {
  m <- lm(reformulate(c("R", "sR", "sL", "-1"), y) , data = d, weights = w)
  m2 <- lm(reformulate(c("R", "sR", "sL"), y), data = d, weights = w)
  V <- vcovHC(m2, type = "HC0")
  c(est = unname(coef(m2)["R"]), se = unname(sqrt(V["R", "R"])))
}
print(se_of("earnings")); print(se_of("participated"))
