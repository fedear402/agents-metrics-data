library(jsonlite)
d <- read.csv("input.csv")
h <- 1
s <- d$score
keep <- abs(s) < h
dd <- d[keep, ]
s <- dd$score
w <- 1 - abs(s)
right <- as.numeric(s >= 0)
left <- 1 - right
X <- cbind(right, right * s, left, left * s)
Y <- cbind(earnings = dd$earnings, participated = dd$participated)
B <- solve(crossprod(X, w * X))
beta <- B %*% crossprod(X, w * Y)
E <- Y - X %*% beta
cvec <- c(1, 0, -1, 0)
rf <- sum(cvec * beta[, 1])
fs <- sum(cvec * beta[, 2])
loading <- w * drop(X %*% B %*% cvec)
psi <- loading * E
V <- crossprod(psi)
g <- c(1 / fs, -rf / fs^2)
te <- rf / fs
te_se <- sqrt(drop(t(g) %*% V %*% g))
n <- nrow(dd)
out <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = unname(te), se = unname(te_se), n_obs = n),
    list(term = "reduced_form", estimate = unname(rf), se = unname(sqrt(V[1, 1])), n_obs = n),
    list(term = "first_stage", estimate = unname(fs), se = unname(sqrt(V[2, 2])), n_obs = n)
  ),
  method_metadata = list(
    estimator = "Fuzzy RD, local linear, triangular kernel, bandwidth 1, separate slopes per side",
    vcov = "HC0 sandwich, delta method for ratio"
  ),
  diagnostics = list(
    cov_reduced_form_first_stage = unname(V[1, 2]),
    n_left = sum(left == 1), n_right = sum(right == 1)
  )
)
write_json(out, "result.json", auto_unbox = TRUE, digits = 16, pretty = TRUE)
cat(sprintf("te=%.10f se=%.10f rf=%.10f fs=%.10f n=%d\n", te, te_se, rf, fs, n))
