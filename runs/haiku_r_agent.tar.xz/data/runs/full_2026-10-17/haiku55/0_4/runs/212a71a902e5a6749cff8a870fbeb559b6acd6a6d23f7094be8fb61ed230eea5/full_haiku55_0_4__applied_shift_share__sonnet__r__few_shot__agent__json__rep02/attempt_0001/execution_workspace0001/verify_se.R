suppressPackageStartupMessages({library(AER); library(sandwich)})
d <- read.csv("input.csv")
regions <- d[!duplicated(d$region_id), c("region_id", "region_weight", "x", "y")]
e <- regions$region_weight / sum(regions$region_weight)
S <- xtabs(share ~ region_id + industry_id, data = d)
S <- S[as.character(regions$region_id), ]
inds <- colnames(S)
shock_n <- sapply(inds, function(k) unique(d$shock[d$industry_id == as.integer(k)]))
z <- drop(S %*% shock_n); x <- regions$x; y <- regions$y
wm <- function(v) v - sum(e * v)
s <- colSums(e * S)
agg <- function(v0) drop(t(S) %*% (e * v0)) / s
dat <- data.frame(ybar = agg(wm(y)), xbar = agg(wm(x)), zbar = agg(wm(z)), shock = shock_n, s = s)
m1 <- ivreg(ybar ~ xbar | shock, weights = s, data = dat)
v1 <- vcovHC(m1, type = "HC1")
m2 <- ivreg(xbar ~ zbar | shock, weights = s, data = dat)
v2 <- vcovHC(m2, type = "HC1")
cat(sprintf("AER effect: %.12f se %.12f\n", coef(m1)[2], sqrt(v1[2,2])))
cat(sprintf("AER first stage: %.12f se %.12f\n", coef(m2)[2], sqrt(v2[2,2])))
