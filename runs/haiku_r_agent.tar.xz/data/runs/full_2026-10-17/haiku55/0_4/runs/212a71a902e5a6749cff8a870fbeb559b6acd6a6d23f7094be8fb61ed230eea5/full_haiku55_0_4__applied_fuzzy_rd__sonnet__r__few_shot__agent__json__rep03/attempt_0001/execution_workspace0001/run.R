library(jsonlite)
d <- read.csv("input.csv")
d <- d[abs(d$score) < 1, ]
s <- d$score
R <- as.numeric(s >= 0)
w <- 1 - abs(s)
X <- cbind(1 - R, R, (1 - R) * s, R * s)
bread <- solve(crossprod(X, w * X))
Y <- cbind(earnings = d$earnings, participated = d$participated)
B <- bread %*% crossprod(X, w * Y)
E <- Y - X %*% B
contrast <- c(-1, 1, 0, 0)
jumps <- drop(t(contrast) %*% B)
loading <- w * drop(X %*% bread %*% contrast)
infl <- loading * E
joint <- crossprod(infl)
rf <- jumps[1]; fs <- jumps[2]
g <- c(1 / fs, -rf / fs^2)
te_se <- sqrt(drop(t(g) %*% joint %*% g))
te <- rf / fs
n <- nrow(d)
res <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = unname(te), se = unname(te_se), n_obs = n),
    list(term = "reduced_form", estimate = unname(rf), se = unname(sqrt(joint[1, 1])), n_obs = n),
    list(term = "first_stage", estimate = unname(fs), se = unname(sqrt(joint[2, 2])), n_obs = n)
  ),
  method_metadata = list(
    estimator = "Fuzzy RD, local linear, triangular kernel, bandwidth 1, separate slopes per side, Wald ratio",
    vcov = "HC0 sandwich, delta method for ratio, joint covariance of discontinuities"
  ),
  diagnostics = list(reduced_form_vs_first_stage_cov = unname(joint[1, 2]), n_left = sum(R == 0), n_right = sum(R == 1))
)
write_json(res, "result.json", auto_unbox = TRUE, digits = 16, pretty = TRUE)
print(jumps); print(c(te, te_se, n))
