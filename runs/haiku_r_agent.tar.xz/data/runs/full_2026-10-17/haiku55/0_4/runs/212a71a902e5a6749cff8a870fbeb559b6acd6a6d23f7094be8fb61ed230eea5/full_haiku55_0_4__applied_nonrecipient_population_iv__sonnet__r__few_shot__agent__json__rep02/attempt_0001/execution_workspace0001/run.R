hh <- read.csv("households.csv")
census <- read.csv("census.csv")
d <- subset(hh, recipient == 0)
e <- d$eligible
ne <- 1 - e
w <- d$weight
y <- d$outcome
X <- cbind(ne, e, d$baseline * ne, d$baseline * e, d$dose * ne, d$dose * e)
Z <- cbind(ne, e, d$baseline * ne, d$baseline * e, d$instrument * ne, d$instrument * e)
ZWX <- crossprod(Z * w, X)
ZWy <- crossprod(Z, w * y)
beta <- as.numeric(solve(ZWX, ZWy))
slope_inel <- beta[5]
slope_el <- beta[6]
mean_dose <- function(g) weighted.mean(d$dose[e == g], w[e == g])
eff_inel <- slope_inel * mean_dose(0)
eff_el <- slope_el * mean_dose(1)
pop <- census$nonrecipient_population[match(0:1, census$eligible)]
pop_eff <- weighted.mean(c(eff_inel, eff_el), pop)
out <- c(ineligible_effect = eff_inel,
         eligible_nonrecipient_effect = eff_el,
         population_effect = pop_eff)
n <- nrow(d)
estimates <- lapply(names(out), function(k) list(term = k, estimate = unname(out[[k]]), se = NA_real_, n_obs = n))
res <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "weighted just-identified 2SLS, recipient==0 sample",
    endogenous = c("dose*(1-eligible)", "dose*eligible"),
    exogenous = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"),
    instruments = c("exogenous four", "instrument*(1-eligible)", "instrument*eligible"),
    weight = "weight",
    counterfactual = "dose set to zero; group effect = dose slope x weighted mean dose",
    aggregation_weights = "census nonrecipient_population"
  ),
  diagnostics = list(
    n_obs = n,
    n_ineligible = sum(e == 0),
    n_eligible = sum(e == 1),
    slope_ineligible = unname(slope_inel),
    slope_eligible = unname(slope_el),
    mean_dose_ineligible = mean_dose(0),
    mean_dose_eligible = mean_dose(1),
    rank_ZWX = qr(ZWX)$rank
  )
)
jsonlite::write_json(res, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE, na = "null")
print(out, digits = 12)
print(res$diagnostics)
