suppressMessages(library(sandwich))
d <- read.csv("input.csv", stringsAsFactors = FALSE)
d <- d[order(as.Date(d$date)), ]
dl <- c(NA, diff(log(d$vix)))
n <- nrow(d)
rows <- 17:n
y <- log(d$sales[rows])
X <- sapply(1:15, function(k) dl[rows - k])
fit <- lm(y ~ X)
N <- length(rows)
cat("N check:", N, " expected", n - 16, "\n")
nw <- NeweyWest(fit, lag = 15, prewhite = FALSE, adjust = FALSE,
                sandwich = TRUE)
V_pkg <- nw * N / (N - 16)
b <- coef(fit)
cum <- sum(b[-1])
cs <- sqrt(sum(V_pkg[-1, -1]))
cat(sprintf("pkg cum=%.10f se=%.10f lag1=%.10f se=%.10f lag15=%.10f se=%.10f\n",
  cum, cs, b[2], sqrt(V_pkg[2,2]), b[16], sqrt(V_pkg[16,16])))
