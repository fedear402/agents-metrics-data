suppressMessages(library(sandwich))
d <- read.csv("input.csv", stringsAsFactors = FALSE)
d <- d[order(as.Date(d$date)), ]
d$dlvix <- c(NA, diff(log(d$vix)))
L <- 15
for (k in 1:L) d[[paste0("l", k)]] <- c(rep(NA, k), head(d$dlvix, -k))
s <- d[complete.cases(d[, c("sales", paste0("l", 1:L))]), ]
f <- lm(log(sales) ~ ., data = cbind(sales = s$sales, s[, paste0("l", 1:L)]))
N <- nobs(f); p <- length(coef(f))
cvec <- c(0, rep(1, L))
est_lm <- sum(coef(f)[-1])
V <- NeweyWest(f, lag = L, prewhite = FALSE, adjust = FALSE) * N / (N - p)
se_lm <- sqrt(drop(t(cvec[-1]) %*% V[-1, -1] %*% cvec[-1]))
cat(sprintf("N=%d p=%d\n", N, p))
cat(sprintf("cumulative lm: %.10f  (script: 2.6366572344)\n", est_lm))
cat(sprintf("cumulative se sandwich: %.10f  (script: 0.4659528278)\n", se_lm))
cat(sprintf("lag_1 se sandwich: %.10f (script: 0.0339560098)\n", sqrt(V[2,2])))
cat(sprintf("lag_15 se sandwich: %.10f (script: 0.0350924939)\n", sqrt(V[L+1,L+1])))
