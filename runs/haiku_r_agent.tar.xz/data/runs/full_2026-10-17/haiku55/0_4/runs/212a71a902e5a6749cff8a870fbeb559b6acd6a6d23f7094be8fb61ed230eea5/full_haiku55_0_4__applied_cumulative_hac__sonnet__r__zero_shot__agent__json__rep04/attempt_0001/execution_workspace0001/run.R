suppressPackageStartupMessages(library(jsonlite))
df <- read.csv("input.csv", stringsAsFactors = FALSE)
df <- df[order(as.Date(df$date)), ]
y <- log(df$sales)
d <- c(NA, diff(log(df$vix)))
L <- 15
Tn <- nrow(df)
idx <- (L + 2):Tn
X <- cbind(1, sapply(1:L, function(k) d[idx - k]))
yy <- y[idx]
N <- length(yy)
XtXi <- solve(crossprod(X))
b <- as.vector(XtXi %*% crossprod(X, yy))
e <- as.vector(yy - X %*% b)
Xe <- X * e
S <- crossprod(Xe)
for (j in 1:L) {
  w <- 1 - j / (L + 1)
  G <- crossprod(Xe[(j + 1):N, , drop = FALSE], Xe[1:(N - j), , drop = FALSE])
  S <- S + w * (G + t(G))
}
V <- XtXi %*% S %*% XtXi * N / (N - (L + 1))
cvec <- c(0, rep(1, L))
cum_est <- sum(b[-1])
cum_se <- sqrt(as.numeric(t(cvec) %*% V %*% cvec))
se <- sqrt(diag(V))
res <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(term = "cumulative_response", estimate = cum_est, se = cum_se, n_obs = N),
    list(term = "lag_1", estimate = b[2], se = se[2], n_obs = N),
    list(term = "lag_15", estimate = b[16], se = se[16], n_obs = N)
  ),
  method_metadata = list(
    estimator = "OLS of log(sales) on intercept and 15 lags of first difference of log(vix)",
    vcov = "Newey-West HAC, max lag 15, Bartlett weights 1-j/16, scaled by N/(N-16)"
  ),
  diagnostics = list(n_total = Tn, first_index_used = idx[1], n_obs = N)
)
write(toJSON(res, auto_unbox = TRUE, digits = NA, pretty = TRUE), "result.json")
cat(sprintf("cum=%.8f se=%.8f lag1=%.8f se=%.8f lag15=%.8f se=%.8f N=%d\n",
  cum_est, cum_se, b[2], se[2], b[16], se[16], N))
# Independent check: sandwich::NeweyWest on same model (lag=15, Bartlett, no prewhite)
suppressPackageStartupMessages(library(sandwich))
fit <- lm(yy ~ X[, -1])
nw <- NeweyWest(fit, lag = L, prewhite = FALSE, adjust = TRUE)
V2 <- nw * N / (N - (L + 1)) / (N / (N - (L + 1)))
cat(sprintf("sandwich NW (adjust=TRUE) cum se=%.8f; lag1 se=%.8f\n",
  sqrt(as.numeric(t(cvec) %*% vcov(fit) %*% cvec)) * 0 + sqrt(as.numeric(t(cvec) %*% NeweyWest(fit, lag = L, prewhite = FALSE, adjust = TRUE) %*% cvec)),
  sqrt(NeweyWest(fit, lag = L, prewhite = FALSE, adjust = TRUE)[2, 2])))
