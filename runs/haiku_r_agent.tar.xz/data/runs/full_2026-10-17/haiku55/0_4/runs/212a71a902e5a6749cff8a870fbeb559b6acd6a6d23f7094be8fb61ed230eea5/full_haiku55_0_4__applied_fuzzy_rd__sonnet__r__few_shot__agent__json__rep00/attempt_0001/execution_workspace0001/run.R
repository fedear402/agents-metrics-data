library(jsonlite)
d <- read.csv("input.csv")
d <- d[abs(d$score) < 1, ]
s <- d$score
R <- as.numeric(s >= 0)
w <- 1 - abs(s)
X <- cbind(1 - R, R, s * (1 - R), s * R)
Y <- cbind(earnings = d$earnings, participated = d$participated)
n <- nrow(X)
bread <- solve(crossprod(X, w * X))
B <- bread %*% crossprod(X, w * Y)
E <- Y - X %*% B
contrast <- c(-1, 1, 0, 0)
jumps <- drop(t(B) %*% contrast)
loading <- w * drop(X %*% bread %*% contrast)
infl <- loading * E
joint <- crossprod(infl)
ratio <- jumps[1] / jumps[2]
g <- c(1 / jumps[2], -jumps[1] / jumps[2]^2)
ratio_se <- sqrt(drop(t(g) %*% joint %*% g))
est <- list(
  list(term = "treatment_effect", estimate = unname(ratio), se = unname(ratio_se), n_obs = n),
  list(term = "reduced_form", estimate = unname(jumps[1]), se = unname(sqrt(joint[1, 1])), n_obs = n),
  list(term = "first_stage", estimate = unname(jumps[2]), se = unname(sqrt(joint[2, 2])), n_obs = n)
)
out <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = est,
  method_metadata = list(
    estimator = "Fuzzy RD, local linear WLS with triangular kernel, bandwidth 1, separate slopes, ratio of jumps",
    vcov = "HC0 sandwich, delta method for ratio"
  ),
  diagnostics = list(
    bandwidth = 1, n_left = sum(R == 0), n_right = sum(R == 1),
    covariance_reduced_form_first_stage = unname(joint[1, 2])
  )
)
write_json(out, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
print(unlist(lapply(est, function(e) c(e$term, e$estimate, e$se, e$n_obs))))
