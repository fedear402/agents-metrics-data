h <- read.csv("households.csv"); census <- read.csv("census.csv")
d <- h[h$recipient == 0, ]
e <- d$eligible; w <- d$weight; y <- d$outcome
C <- cbind(1 - e, e, d$baseline * (1 - e), d$baseline * e)
Xend <- cbind(d$dose * (1 - e), d$dose * e)
Z <- cbind(C, d$instrument * (1 - e), d$instrument * e)
cat("n retained:", nrow(d), " total rows:", nrow(h), " recipient values:", paste(unique(h$recipient), collapse=","), "\n")
fs1 <- lm(Xend[,1] ~ Z - 1, weights = w)
fs2 <- lm(Xend[,2] ~ Z - 1, weights = w)
ss <- lm(y ~ fitted(fs1) + fitted(fs2) + C - 1, weights = w)
b2 <- coef(ss)[1:2]
W <- diag(w)
X <- cbind(Xend, C)
b_just <- solve(t(Z) %*% W %*% X, t(Z) %*% W %*% y)[1:2]
cat("two-stage slopes:", b2, "\n")
cat("just-identified IV slopes:", b_just, "\n")
wm <- function(g) { k <- e == g; sum(w[k]*d$dose[k])/sum(w[k]) }
eff <- c(b2[1]*wm(0), b2[2]*wm(1))
pw <- census$nonrecipient_population[match(0:1, census$eligible)]
cat("effects:", eff, " population:", sum(eff*pw)/sum(pw), "\n")
r <- jsonlite::fromJSON("result.json")
cat("result.json estimates:", r$estimates$estimate, "\n")
cat("max abs diff two-stage vs run.R:", max(abs(c(eff, sum(eff*pw)/sum(pw)) - r$estimates$estimate)), "\n")
