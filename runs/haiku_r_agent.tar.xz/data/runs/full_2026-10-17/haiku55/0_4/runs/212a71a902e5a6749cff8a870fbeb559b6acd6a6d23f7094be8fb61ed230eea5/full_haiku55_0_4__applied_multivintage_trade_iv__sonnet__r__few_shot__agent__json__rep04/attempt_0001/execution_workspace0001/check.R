cw <- rbind(read.csv("crosswalk.csv"), read.csv("input.csv"))
tr <- merge(read.csv("trade.csv"), cw, by = "code")
emp <- read.csv("employment.csv"); ar <- read.csv("areas.csv"); oc <- read.csv("outcomes.csv")
key <- function(a,p,v,j) paste(a,p,v,j)
E <- setNames(emp$employment, key(emp$area,emp$period,emp$vintage,emp$industry))
get <- function(a,p,v,j){ k<-key(a,p,v,j); if(k %in% names(E)) E[[k]] else 0 }
TOT <- setNames(ar$total_employment, key(ar$area,ar$period,ar$vintage,"")); 
tot <- function(a,p,v) TOT[[key(a,p,v,"")]]
pop <- function(a,p) ar$population[ar$area==a & ar$period==p & ar$vintage=="base"]
nat <- function(p,v,j) sum(sapply(0:35, function(a) get(a,p,v,j)))
expo <- function(a,p,vint,chg){
  r <- tr[tr$period==p,]; s <- 0
  for (i in seq_len(nrow(r))) { j <- r$industry[i]
    s <- s + get(a,p,vint,j)/tot(a,p,vint) * (r[[chg]][i]/nat(p,vint,j)) / (r$price_index[i]/100)/1000*(10/r$years[i]) }
  s }
X <- do.call(rbind, lapply(0:1, function(p) do.call(rbind, lapply(0:35, function(a)
  c(1, p, oc$control[oc$area==a & oc$period==p], expo(a,p,"base","us_change"), expo(a,p,"early","other_change"), oc$change_pp[oc$area==a & oc$period==p], pop(a,p))))))
colnames(X) <- c("c","per","ctl","x","z","y","w")
cat("area0 x p0,p1:", expo(0,0,"base","us_change"), expo(0,1,"base","us_change"), " z p0:", expo(0,0,"early","other_change"), "\n")
Xm <- X[,c("c","per","ctl","x")]; Zm <- X[,c("c","per","ctl","z")]; y <- X[,"y"]; w <- X[,"w"]
Wd <- diag(w)
# Weighted 2SLS via normal equations: beta = (X'W Pz X)^-1 X'W Pz y, Pz projection in W-metric
G <- t(Zm) %*% Wd %*% Zm
Xh <- Zm %*% solve(G) %*% t(Zm) %*% Wd %*% Xm
beta <- solve(t(Xh) %*% Wd %*% Xh, t(Xh) %*% Wd %*% y)
cat("beta (normal eq):", format(beta[4], digits=15), "\n")
cat("n rows:", nrow(X), "\n")
