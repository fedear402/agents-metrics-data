d <- subset(read.csv("households.csv"), recipient == 0)
e <- d$eligible; ne <- 1 - e; w <- d$weight
Xex <- cbind(ne, e, d$baseline*ne, d$baseline*e)
Zi <- cbind(d$instrument*ne, d$instrument*e)
Xen <- cbind(d$dose*ne, d$dose*e)
fs <- lm(Xen ~ Xex + Zi - 1, weights = w)
Xhat <- fitted(fs)
ss <- lm(d$outcome ~ Xex + Xhat - 1, weights = w)
b2 <- unname(coef(ss))
s <- b2[5:6]
print(s, digits = 12)
print(c(weighted.mean(d$dose[e==0], w[e==0]) * s[1], weighted.mean(d$dose[e==1], w[e==1]) * s[2]), digits = 12)
