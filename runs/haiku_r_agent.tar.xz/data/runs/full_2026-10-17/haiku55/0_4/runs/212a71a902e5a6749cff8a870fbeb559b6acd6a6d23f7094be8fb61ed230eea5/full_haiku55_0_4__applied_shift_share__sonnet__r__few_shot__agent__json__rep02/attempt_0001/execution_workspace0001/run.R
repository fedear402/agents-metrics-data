suppressPackageStartupMessages(library(jsonlite))
d <- read.csv("input.csv")
stopifnot(!anyDuplicated(d[, c("region_id", "industry_id")]))

regions <- d[!duplicated(d$region_id), c("region_id", "region_weight", "x", "y")]
regions <- regions[order(regions$region_id), ]
e <- regions$region_weight / sum(regions$region_weight)
stopifnot(all(tapply(d$share, d$region_id, sum) - 1 < 1e-8))

sh <- d[order(d$region_id, d$industry_id), ]
shares_wide <- xtabs(share ~ region_id + industry_id, data = sh)
shares_wide <- shares_wide[as.character(regions$region_id), , drop = FALSE]
industries <- sort(unique(d$industry_id))
shock_n <- sapply(industries, function(k) unique(d$shock[d$industry_id == k]))
stopifnot(all(sapply(industries, function(k) length(unique(d$shock[d$industry_id == k]))) == 1))
S <- shares_wide[, as.character(industries), drop = FALSE]

z <- drop(S %*% shock_n)
x <- regions$x
y <- regions$y
wm <- function(v) v - sum(e * v)
y0 <- wm(y); x0 <- wm(x); z0 <- wm(z)

s <- colSums(e * S)
agg <- function(v0) drop(t(S) %*% (e * v0)) / s
ybar <- agg(y0); xbar <- agg(x0); zbar <- agg(z0)

N <- length(industries)
shock_iv <- function(dep, endo) {
  X <- cbind(1, endo)
  Z <- cbind(1, shock_n)
  cross <- crossprod(Z, s * X)
  beta <- solve(cross, crossprod(Z, s * dep))
  res <- drop(dep - X %*% beta)
  scores <- Z * (s * res)
  bread <- solve(cross)
  V <- N / (N - 2) * bread %*% crossprod(scores) %*% t(bread)
  c(slope = beta[2], se = sqrt(V[2, 2]))
}

effect <- shock_iv(ybar, xbar)
first <- shock_iv(xbar, zbar)
eff_shocks <- 1 / sum(s^2)

res <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = unname(effect["slope"]), se = unname(effect["se"]), n_obs = as.integer(N)),
    list(term = "first_stage", estimate = unname(first["slope"]), se = unname(first["se"]), n_obs = as.integer(N)),
    list(term = "effective_shocks", estimate = unname(eff_shocks), se = NULL, n_obs = as.integer(N))
  ),
  method_metadata = list(
    estimator = "Weighted 2SLS of regional y on x instrumented by z, with BHJ shock-level weighted IV inference",
    vcov = "Shock-level structural-residual HC1 sandwich with N/(N-2) multiplier, no clustering"
  ),
  diagnostics = list(
    n_regions = nrow(regions), n_industries = N,
    sum_s = sum(s), min_s = min(s)
  )
)
write_json(res, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
print(effect); print(first); print(eff_shocks)
