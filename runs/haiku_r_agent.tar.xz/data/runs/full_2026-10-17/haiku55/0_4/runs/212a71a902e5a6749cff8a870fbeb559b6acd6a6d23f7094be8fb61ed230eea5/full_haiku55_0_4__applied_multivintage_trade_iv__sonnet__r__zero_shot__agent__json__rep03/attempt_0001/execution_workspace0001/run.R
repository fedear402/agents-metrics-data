suppressPackageStartupMessages(library(jsonlite))

crosswalk <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
trade <- read.csv("trade.csv", stringsAsFactors = FALSE)
areas <- read.csv("areas.csv", stringsAsFactors = FALSE)
employment <- read.csv("employment.csv", stringsAsFactors = FALSE)
outcomes <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

trade <- merge(trade, crosswalk, by = "code", all.x = TRUE)
stopifnot(!any(is.na(trade$industry)))

periods <- sort(unique(areas$period))
areas_ids <- sort(unique(areas$area))
industries <- sort(unique(crosswalk$industry))
stopifnot(length(industries) == 4)

grid <- expand.grid(area = areas_ids, period = periods, vintage = c("base", "early"),
                    industry = industries, stringsAsFactors = FALSE)
emp <- merge(grid, employment, by = c("area", "period", "vintage", "industry"), all.x = TRUE)
emp$employment[is.na(emp$employment)] <- 0

nat <- aggregate(employment ~ period + vintage + industry, data = emp, FUN = sum)
names(nat)[names(nat) == "employment"] <- "national"

tot <- areas[, c("area", "period", "vintage", "total_employment", "population")]

# Exposure builder: 'vint' is base for x and early for z; 'chg' is us_change or other_change
build_exposure <- function(vint, chg) {
  out <- data.frame(area = integer(0), period = integer(0), value = numeric(0))
  for (p in periods) {
    tp <- trade[trade$period == p, ]
    stopifnot(nrow(tp) == 4, all(tp$industry %in% industries))
    price <- unique(tp$price_index); yrs <- unique(tp$years)
    stopifnot(length(price) == 1, length(yrs) == 1)
    for (a in areas_ids) {
      te <- tot$total_employment[tot$area == a & tot$period == p & tot$vintage == vint]
      s <- 0
      for (j in industries) {
        e <- emp$employment[emp$area == a & emp$period == p & emp$vintage == vint & emp$industry == j]
        n <- nat$national[nat$period == p & nat$vintage == vint & nat$industry == j]
        d <- tp[tp$industry == j, ]
        stopifnot(n > 0)
        s <- s + (e / te) * (d[[chg]] / n) / (price / 100) / 1000 * (10 / yrs)
      }
      out <- rbind(out, data.frame(area = a, period = p, value = s))
    }
  }
  out
}

xdf <- build_exposure("base", "us_change")
zdf <- build_exposure("early", "other_change")
names(xdf)[3] <- "x"; names(zdf)[3] <- "z"

d <- merge(outcomes, xdf, by = c("area", "period"))
d <- merge(d, zdf, by = c("area", "period"))
d <- merge(d, tot[tot$vintage == "base", c("area", "period", "population")], by = c("area", "period"))
d <- d[order(d$period, d$area), ]
n_obs <- nrow(d)
stopifnot(n_obs == 72)

y <- d$change_pp
X <- cbind(1, d$period, d$control, d$x)
Z <- cbind(1, d$period, d$control, d$z)
w <- d$population
W <- diag(w)

Xhat <- Z %*% solve(t(Z) %*% W %*% Z, t(Z) %*% W %*% X)
beta <- solve(t(Xhat) %*% W %*% X, t(Xhat) %*% W %*% y)
iv_slope <- beta[4]

get_val <- function(v, a, p) d[[v]][d$area == a & d$period == p]

res <- list(
  iv_slope = iv_slope,
  exposure_area0_period0 = get_val("x", 0, 0),
  exposure_area0_period1 = get_val("x", 0, 1),
  instrument_area0_period0 = get_val("z", 0, 0)
)

estimates <- lapply(names(res), function(nm) {
  list(term = nm, estimate = as.numeric(res[[nm]]), se = NA, n_obs = as.integer(n_obs))
})

out <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "weighted 2SLS",
    weights = "base-vintage population",
    endogenous = "x",
    instrument = "z",
    exogenous = c("intercept", "period", "control"),
    sample = "all area-period observations",
    exposure_units = "thousands of real dollars per worker per decade"
  ),
  diagnostics = list(
    n_area_periods = as.integer(n_obs),
    n_areas = as.integer(length(areas_ids)),
    n_periods = as.integer(length(periods)),
    n_industries = as.integer(length(industries))
  )
)

write_json(out, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE, na = "null")

cat(sprintf("iv_slope %.12f\nx0p0 %.12f\nx0p1 %.12f\nz0p0 %.12f\nn %d\n",
            iv_slope, res$exposure_area0_period0, res$exposure_area0_period1,
            res$instrument_area0_period0, n_obs))
