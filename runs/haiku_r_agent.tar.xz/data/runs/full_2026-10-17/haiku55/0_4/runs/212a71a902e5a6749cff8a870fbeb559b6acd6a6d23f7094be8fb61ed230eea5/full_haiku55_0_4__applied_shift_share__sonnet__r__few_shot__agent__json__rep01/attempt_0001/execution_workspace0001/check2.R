suppressPackageStartupMessages(library(jsonlite))
d <- read.csv("input.csv")
reg <- aggregate(cbind(region_weight, x, y) ~ region_id, data = d, FUN = function(v) v[1])
d$zp <- d$share * d$shock
reg$z <- aggregate(zp ~ region_id, data = d, FUN = sum)$zp
reg$e <- reg$region_weight / sum(reg$region_weight)
m <- function(v) sum(reg$e * v)
reg$y0 <- reg$y - m(reg$y); reg$x0 <- reg$x - m(reg$x); reg$z0 <- reg$z - m(reg$z)
dd <- merge(d, reg[, c("region_id","e","y0","x0","z0")], by = "region_id")
dd$w <- dd$e * dd$share
agg <- function(v) tapply(dd$w * dd[[v]], dd$industry_id, sum)
s <- tapply(dd$w, dd$industry_id, sum)
shock <- tapply(dd$shock, dd$industry_id, `[`, 1)
ybar <- as.numeric(agg("y0") / s); xbar <- as.numeric(agg("x0") / s); zbar <- as.numeric(agg("z0") / s)
s <- as.numeric(s); shock <- as.numeric(shock)
N <- length(s)
# 2SLS via first-stage fitted values (weights s)
fs1 <- lm(xbar ~ shock, weights = s)
xhat <- fitted(fs1)
ss <- lm(ybar ~ xhat, weights = s)
b <- coef(ss)[2]
u <- ybar - (coef(ss)[1] + b * xbar)  # structural residuals
X2 <- model.matrix(ss)              # 1, xhat
Zs <- cbind(1, shock)               # instruments
# Score: Z' weighted-residual; bread from projected regressors
A <- crossprod(cbind(1, xhat), s * cbind(1, xhat))
Ainv <- solve(A)
meat <- crossprod(cbind(1, xhat) * (s * u))
V <- N/(N-2) * Ainv %*% meat %*% t(Ainv)
cat("indep effect:", b, " se:", sqrt(V[2,2]), "\n")
# Alternative: sandwich via explicit IV score with instruments
Ainv2 <- solve(crossprod(Zs, s*cbind(1,xbar)))
Vi <- N/(N-2) * Ainv2 %*% crossprod(Zs * (s*u)) %*% t(Ainv2)
cat("alt effect se:", sqrt(Vi[2,2]), "\n")
# First stage
cat("first stage (IV form, zbar on shock):\n")
zhat <- fitted(lm(zbar ~ shock, weights = s))
f2 <- lm(xbar ~ zhat, weights = s)
g <- coef(f2)[2]
uf <- xbar - (coef(f2)[1] + g * zbar)
A2 <- solve(crossprod(cbind(1, zhat), s*cbind(1,zhat)))
Vf <- N/(N-2) * A2 %*% crossprod(cbind(1,zhat) * (s*uf)) %*% t(A2)
cat("indep first stage:", g, " se:", sqrt(Vf[2,2]), "\n")
res <- fromJSON("result.json")
print(res$estimates)
