library(jsonlite)
d <- read.csv("input.csv")
d <- d[abs(d$score) < 1, ]
s <- d$score
w <- 1 - abs(s)
right <- as.numeric(s >= 0)
X <- cbind(1, right, s, right * s)
Y <- cbind(earnings = d$earnings, participated = d$participated)
n <- nrow(X)
bread <- solve(crossprod(X, w * X))
B <- bread %*% crossprod(X, w * Y)
E <- Y - X %*% B
contrast <- c(0, 1, 0, 0)
jumps <- drop(contrast %*% B)
loading <- w * drop(X %*% bread %*% contrast)
infl <- loading * E
joint <- crossprod(infl)
rf <- jumps[1]; fs <- jumps[2]
g <- c(1 / fs, -rf / fs^2)
te <- rf / fs
te_se <- sqrt(drop(t(g) %*% joint %*% g))
result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = unname(te), se = unname(te_se), n_obs = as.integer(n)),
    list(term = "reduced_form", estimate = unname(rf), se = unname(sqrt(joint[1, 1])), n_obs = as.integer(n)),
    list(term = "first_stage", estimate = unname(fs), se = unname(sqrt(joint[2, 2])), n_obs = as.integer(n))
  ),
  method_metadata = list(
    estimator = "Fuzzy RD, triangular kernel, bandwidth 1, local linear with separate slopes, weighted least squares, Wald ratio",
    vcov = "HC0 sandwich (no degrees-of-freedom correction), delta method for ratio with joint covariance"
  ),
  diagnostics = list(
    bandwidth = 1, cutoff = 0, n_left = sum(right == 0), n_right = sum(right == 1),
    reduced_form_cov_with_first_stage = unname(joint[1, 2])
  )
)
write_json(result, "result.json", auto_unbox = TRUE, digits = 16, pretty = TRUE, null = "null")
print(unlist(lapply(result$estimates, function(e) c(e$term, e$estimate, e$se, e$n_obs))))
