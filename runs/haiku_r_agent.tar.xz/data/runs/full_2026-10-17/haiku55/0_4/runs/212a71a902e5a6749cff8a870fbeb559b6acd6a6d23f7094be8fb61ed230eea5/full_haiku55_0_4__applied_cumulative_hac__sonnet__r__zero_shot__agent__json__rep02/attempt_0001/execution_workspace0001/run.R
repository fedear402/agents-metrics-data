suppressMessages(library(sandwich))
d <- read.csv("input.csv", stringsAsFactors = FALSE)
d <- d[order(as.Date(d$date)), ]
n <- nrow(d)
dv <- c(NA, diff(log(d$vix)))
y <- log(d$sales)
L <- 15
rows <- (L + 2):n
X <- cbind(1, sapply(1:L, function(j) dv[rows - j]))
colnames(X) <- c("intercept", paste0("lag_", 1:L))
yy <- y[rows]
N <- length(yy)
fit <- lm.fit(X, yy)
b <- fit$coefficients
u <- fit$residuals
XtXi <- solve(crossprod(X))
G <- X * u
S <- crossprod(G)
for (j in 1:L) {
  w <- 1 - j / (L + 1)
  Gj <- G[(j + 1):N, , drop = FALSE]
  Gl <- G[1:(N - j), , drop = FALSE]
  S <- S + w * (crossprod(Gj, Gl) + crossprod(Gl, Gj))
}
V <- XtXi %*% S %*% XtXi * N / (N - (L + 1))
R <- c(0, rep(1, L))
cum_est <- sum(b[-1])
cum_se <- sqrt(as.numeric(t(R) %*% V %*% R))
# Independent check: sandwich::NeweyWest (no small-sample adjustment), scaled by N/(N-16)
Vs <- NeweyWest(lm(yy ~ X[, -1]), lag = L, prewhite = FALSE, adjust = FALSE) * N / (N - (L + 1))
chk_se_lag1 <- sqrt(Vs[2, 2]); chk_se_cum <- sqrt(as.numeric(t(R) %*% Vs %*% R))
cat(sprintf("N=%d cum=%.8f se=%.8f | lag1=%.8f se=%.8f | lag15=%.8f se=%.8f\n",
  N, cum_est, cum_se, b[2], sqrt(V[2,2]), b[16], sqrt(V[16,16])))
cat(sprintf("sandwich check: lag1 se=%.8f cum se=%.8f\n", chk_se_lag1, chk_se_cum))
res <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(term = "cumulative_response", estimate = cum_est, se = cum_se, n_obs = N),
    list(term = "lag_1", estimate = unname(b[2]), se = sqrt(V[2, 2]), n_obs = N),
    list(term = "lag_15", estimate = unname(b[16]), se = sqrt(V[16, 16]), n_obs = N)
  ),
  method_metadata = list(
    estimator = "OLS regression of log(sales) on intercept and 15 lags of first difference of log(vix)",
    vcov = "Newey-West HAC, max lag 15, Bartlett weights 1-j/16, scaled by N/(N-16)"
  ),
  diagnostics = list(sample_start_row = rows[1], sample_end_row = n, dropped_first_obs = 1)
)
jsonlite_ok <- requireNamespace("jsonlite", quietly = TRUE)
if (jsonlite_ok) {
  writeLines(jsonlite::toJSON(res, auto_unbox = TRUE, digits = NA, pretty = TRUE), "result.json")
} else {
  stop("jsonlite required")
}
