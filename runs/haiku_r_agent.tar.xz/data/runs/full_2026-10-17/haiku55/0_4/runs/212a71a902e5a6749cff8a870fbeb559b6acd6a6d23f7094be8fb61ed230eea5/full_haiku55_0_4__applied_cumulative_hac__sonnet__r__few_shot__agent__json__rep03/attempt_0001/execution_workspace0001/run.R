library(jsonlite)
d <- read.csv("input.csv", stringsAsFactors = FALSE)
d$date <- as.Date(d$date)
d <- d[order(d$date), ]
L <- 15
d$dlvix <- c(NA, diff(log(d$vix)))
n <- nrow(d)
rows <- (L + 2):n
X <- cbind(1, sapply(1:L, function(k) d$dlvix[rows - k]))
colnames(X) <- c("(Intercept)", paste0("lag", 1:L))
y <- log(d$sales[rows])
fit <- lm.fit(X, y)
b <- fit$coefficients
e <- y - X %*% b
N <- nrow(X); p <- ncol(X)
scores <- X * as.vector(e)
meat <- crossprod(scores)
for (j in 1:L) {
  G <- crossprod(scores[(j + 1):N, , drop = FALSE], scores[1:(N - j), , drop = FALSE])
  meat <- meat + (1 - j / (L + 1)) * (G + t(G))
}
bread <- solve(crossprod(X))
V <- N / (N - p) * bread %*% meat %*% bread
cvec <- c(0, rep(1, L))
cum <- sum(cvec * b)
cum_se <- sqrt(drop(t(cvec) %*% V %*% cvec))
res <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(term = "cumulative_response", estimate = cum, se = cum_se, n_obs = N),
    list(term = "lag_1", estimate = unname(b[2]), se = sqrt(V[2, 2]), n_obs = N),
    list(term = "lag_15", estimate = unname(b[L + 1]), se = sqrt(V[L + 1, L + 1]), n_obs = N)
  ),
  method_metadata = list(
    estimator = "OLS of log(sales) on intercept and 15 lags of diff(log(vix))",
    vcov = "Newey-West HAC, max lag 15, Bartlett weights 1-j/16, scaled by N/(N-16)"
  ),
  diagnostics = list(
    sample_start_date = as.character(d$date[rows[1]]),
    sample_end_date = as.character(d$date[rows[N]]),
    total_rows = n,
    regression_lags = L,
    hac_max_lag = L,
    parameter_count = p
  )
)
write_json(res, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
print(fit$coefficients[1:3]); print(cum); print(cum_se); print(N)
