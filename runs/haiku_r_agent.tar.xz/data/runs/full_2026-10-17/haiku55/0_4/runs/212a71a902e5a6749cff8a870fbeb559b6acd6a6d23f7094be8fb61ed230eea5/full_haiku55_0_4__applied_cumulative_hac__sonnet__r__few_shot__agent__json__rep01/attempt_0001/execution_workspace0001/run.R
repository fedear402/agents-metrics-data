library(jsonlite)
d <- read.csv("input.csv", stringsAsFactors = FALSE)
d$date <- as.Date(d$date)
d <- d[order(d$date), ]
L <- 15
d$dlvix <- c(NA, diff(log(d$vix)))
for (k in seq_len(L)) d[[paste0("lag", k)]] <- c(rep(NA, k), head(d$dlvix, -k))
d$log_sales <- log(d$sales)
sample <- d[complete.cases(d[, c("log_sales", paste0("lag", 1:L))]), ]
lag_names <- paste0("lag", 1:L)
fit <- lm(reformulate(lag_names, response = "log_sales"), data = sample)
X <- model.matrix(fit)
b <- coef(fit)
N <- nrow(X)
scores <- X * residuals(fit)
meat <- crossprod(scores)
for (j in seq_len(L)) {
  G <- crossprod(scores[(j + 1):N, , drop = FALSE], scores[1:(N - j), , drop = FALSE])
  meat <- meat + (1 - j / (L + 1)) * (G + t(G))
}
bread <- solve(crossprod(X))
p <- ncol(X)
V <- N / (N - p) * bread %*% meat %*% bread
contrast <- c(0, rep(1, L))
cum <- sum(contrast * b)
cum_se <- sqrt(drop(t(contrast) %*% V %*% contrast))
row <- function(term, est, se, n) list(term = term, estimate = unname(as.numeric(est)),
  se = unname(as.numeric(se)), n_obs = as.integer(n))
out <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    row("cumulative_response", cum, cum_se, N),
    row("lag_1", b[2], sqrt(V[2, 2]), N),
    row("lag_15", b[1 + L], sqrt(V[1 + L, 1 + L]), N)
  ),
  method_metadata = list(
    estimator = "OLS of log(sales) on intercept and 15 lags of diff(log(vix))",
    vcov = "Newey-West HAC, max lag 15, Bartlett weights 1-j/16, scaled by N/(N-16)"
  ),
  diagnostics = list(n_obs = N, n_params = p, first_date = as.character(min(sample$date)),
    last_date = as.character(max(sample$date)))
)
write_json(out, "result.json", auto_unbox = TRUE, digits = 16, pretty = TRUE)
print(sprintf("N=%d cum=%.10f se=%.10f lag1=%.10f lag15=%.10f", N, cum, cum_se, b[2], b[1 + L]))
