h <- read.csv("households.csv")
census <- read.csv("census.csv")
d <- h[h$recipient == 0, ]
n <- nrow(d)
e <- d$eligible
w <- d$weight
y <- d$outcome

C <- cbind(1 - e, e, d$baseline * (1 - e), d$baseline * e)
Xend <- cbind(d$dose * (1 - e), d$dose * e)
X <- cbind(Xend, C)
Z <- cbind(C, d$instrument * (1 - e), d$instrument * e)

sw <- sqrt(w)
Xs <- X * sw; Zs <- Z * sw; ys <- y * sw
Xhat <- Zs %*% qr.coef(qr(Zs), Xs)
beta <- as.numeric(solve(crossprod(Xhat, Xs), crossprod(Xhat, ys)))
slope0 <- beta[1]
slope1 <- beta[2]

wmean_dose <- function(g) {
  k <- e == g
  sum(w[k] * d$dose[k]) / sum(w[k])
}
eff0 <- slope0 * wmean_dose(0)
eff1 <- slope1 * wmean_dose(1)

pop_w <- census$nonrecipient_population[match(0:1, census$eligible)]
pop_eff <- sum(c(eff0, eff1) * pop_w) / sum(pop_w)

est <- list(
  list(term = "ineligible_effect", estimate = eff0, se = NULL, n_obs = as.integer(n)),
  list(term = "eligible_nonrecipient_effect", estimate = eff1, se = NULL, n_obs = as.integer(n)),
  list(term = "population_effect", estimate = pop_eff, se = NULL, n_obs = as.integer(n))
)
est <- lapply(est, function(x) { x$se <- NA; x })

result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = est,
  method_metadata = list(
    estimator = "joint weighted 2SLS, exactly identified (6 regressors, 6 instruments)",
    sample = "households with recipient == 0, both eligibility groups",
    regression_weight = "weight",
    counterfactual = "dose set to zero for all retained households",
    group_effect = "dose slope times household-weighted mean dose within group",
    aggregation = "census nonrecipient_population weights across eligible groups",
    se_reported = FALSE
  ),
  diagnostics = list(
    n_obs = as.integer(n),
    rank_Z = as.integer(qr(Zs)$rank),
    rank_X = as.integer(qr(Xs)$rank),
    dose_slope_ineligible = slope0,
    dose_slope_eligible = slope1,
    weighted_mean_dose_ineligible = wmean_dose(0),
    weighted_mean_dose_eligible = wmean_dose(1),
    census_weights = pop_w
  )
)
jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE)
cat(jsonlite::toJSON(as.list(c(ineligible_effect = eff0, eligible_nonrecipient_effect = eff1, population_effect = pop_eff)), auto_unbox = TRUE, digits = 12), "\n")
