suppressMessages({library(AER); library(sandwich)})
d <- read.csv("input.csv")
regions <- d[!duplicated(d$region_id), c("region_id","region_weight","x","y")]
regions <- regions[order(regions$region_id), ]
e <- regions$region_weight/sum(regions$region_weight)
st <- d[!duplicated(d$industry_id), c("industry_id","shock")]; st <- st[order(st$industry_id),]
ri <- match(d$region_id, regions$region_id); ni <- match(d$industry_id, st$industry_id)
S <- matrix(0, nrow(regions), nrow(st)); S[cbind(ri,ni)] <- d$share
z <- drop(S %*% st$shock); s <- drop(t(S) %*% e)
cen <- function(v) v - sum(e*v)
y0 <- cen(regions$y); x0 <- cen(regions$x); z0 <- cen(z)
agg <- function(v) drop(t(S) %*% (e*v))/s
df <- data.frame(yb=agg(y0), xb=agg(x0), zb=agg(z0), sh=st$shock, s=s)
f1 <- ivreg(yb ~ xb | sh, weights = s, data = df)
f2 <- ivreg(xb ~ zb | sh, weights = s, data = df)
v1 <- vcovHC(f1, type="HC1"); v2 <- vcovHC(f2, type="HC1")
cat(sprintf("effect %.10f se %.10f\n", coef(f1)[2], sqrt(v1[2,2])))
cat(sprintf("first  %.10f se %.10f\n", coef(f2)[2], sqrt(v2[2,2])))
cat(sprintf("effsh  %.10f\n", 1/sum(s^2)))
