hh <- read.csv("households.csv")
census <- read.csv("census.csv")

d <- hh[hh$recipient == 0, ]
n <- nrow(d)
e <- d$eligible
ne <- 1 - e
w <- d$weight
dose <- d$dose
base <- d$baseline
inst <- d$instrument
y <- d$outcome

X <- cbind(dose * ne, dose * e)
Xexog <- cbind(ne, e, base * ne, base * e)
Z <- cbind(Xexog, inst * ne, inst * e)
Xall <- cbind(X, Xexog)

sw <- sqrt(w)
Xw <- Xall * sw
Zw <- Z * sw
yw <- y * sw
PZ <- Zw %*% solve(crossprod(Zw), t(Zw))
beta <- solve(t(Xw) %*% PZ %*% Xw, t(Xw) %*% PZ %*% yw)

b_ineligible <- beta[1]
b_eligible <- beta[2]

mean_dose <- function(mask) sum(w[mask] * dose[mask]) / sum(w[mask])
m0 <- mean_dose(e == 0)
m1 <- mean_dose(e == 1)

ineligible_effect <- b_ineligible * m0
eligible_nonrecipient_effect <- b_eligible * m1

pop <- setNames(census$nonrecipient_population, census$eligible)
population_effect <- (pop["0"] * ineligible_effect + pop["1"] * eligible_nonrecipient_effect) /
  (pop["0"] + pop["1"])

est <- function(term, value) list(term = term, estimate = unname(value), se = NA_real_, n_obs = as.integer(n))
estimates <- list(
  est("ineligible_effect", ineligible_effect),
  est("eligible_nonrecipient_effect", eligible_nonrecipient_effect),
  est("population_effect", population_effect)
)

out <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "weighted 2SLS, no intercept, weight as regression weight",
    sample = "households with recipient == 0, all treated statuses",
    endogenous = c("dose*(1-eligible)", "dose*eligible"),
    exogenous = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"),
    instruments = c("exogenous set", "instrument*(1-eligible)", "instrument*eligible"),
    group_effect = "dose slope times household-weighted mean dose within eligibility group",
    population_weights = "census nonrecipient_population by eligibility group",
    counterfactual = "dose set to zero for all retained households (synthetic attribution convention)",
    se_note = "standard errors not requested; se set to null"
  ),
  diagnostics = list(
    n_retained = as.integer(n),
    n_ineligible = as.integer(sum(e == 0)),
    n_eligible = as.integer(sum(e == 1)),
    slope_ineligible = unname(b_ineligible),
    slope_eligible = unname(b_eligible),
    weighted_mean_dose_ineligible = unname(m0),
    weighted_mean_dose_eligible = unname(m1)
  )
)

jsonlite::write_json(out, "result.json", auto_unbox = TRUE, digits = NA, na = "null", pretty = TRUE)
print(out$estimates)
print(out$diagnostics)
