library(jsonlite)

cw <- read.csv("crosswalk.csv")
tr <- merge(read.csv("trade.csv"), cw, by = "code")
ar <- read.csv("areas.csv")
em <- read.csv("employment.csv")
oc <- read.csv("outcomes.csv")

areas <- sort(unique(ar$area))
periods <- sort(unique(ar$period))
inds <- sort(unique(cw$industry))

grid <- expand.grid(area = areas, period = periods, vintage = c("base", "early"),
                    industry = inds, stringsAsFactors = FALSE)
grid <- merge(grid, em[, c("area", "period", "vintage", "industry", "employment")],
              by = c("area", "period", "vintage", "industry"), all.x = TRUE)
grid$employment[is.na(grid$employment)] <- 0

tot <- ar[, c("area", "period", "vintage", "total_employment")]
grid <- merge(grid, tot, by = c("area", "period", "vintage"))

nat <- aggregate(employment ~ period + vintage + industry, data = grid, FUN = sum)
names(nat)[4] <- "nat_emp"
grid <- merge(grid, nat, by = c("period", "vintage", "industry"))
stopifnot(all(grid$nat_emp > 0))

grid <- merge(grid, tr[, c("period", "industry", "us_change", "other_change", "price_index", "years")],
              by = c("period", "industry"))

exposure <- function(g, vint, change_col) {
  g <- g[g$vintage == vint, ]
  term <- (g$employment / g$total_employment) *
    (g[[change_col]] / g$nat_emp) /
    (g$price_index / 100) / 1000 * (10 / g$years)
  g$term <- term
  aggregate(term ~ area + period, data = g, FUN = sum)
}

xe <- exposure(grid, "base", "us_change")
ze <- exposure(grid, "early", "other_change")
names(xe)[3] <- "x"
names(ze)[3] <- "z"

d <- merge(oc, ar[ar$vintage == "base", c("area", "period", "population")], by = c("area", "period"))
d <- merge(d, xe, by = c("area", "period"))
d <- merge(d, ze, by = c("area", "period"))
d <- d[order(d$area, d$period), ]
stopifnot(nrow(d) == 72)

y <- d$change_pp
X <- cbind(1, d$period, d$control, d$x)
Z <- cbind(1, d$period, d$control, d$z)
w <- d$population
W <- diag(w)

ZWZinv <- solve(t(Z) %*% W %*% Z)
A <- t(X) %*% W %*% Z %*% ZWZinv %*% t(Z) %*% W
beta <- solve(A %*% X, A %*% y)
iv_slope <- beta[4]

x_a0 <- d$x[d$area == 0 & d$period == periods[1]]
x_a0p1 <- d$x[d$area == 0 & d$period == periods[2]]
z_a0 <- d$z[d$area == 0 & d$period == periods[1]]

est <- function(term, value) list(term = term, estimate = value, se = NA_real_, n_obs = 72L)

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = list(
    est("iv_slope", iv_slope),
    est("exposure_area0_period0", x_a0),
    est("exposure_area0_period1", x_a0p1),
    est("instrument_area0_period0", z_a0)
  ),
  method_metadata = list(
    estimator = "weighted 2SLS",
    weights = "base-vintage population",
    outcome = "change_pp",
    endogenous = "x",
    instrument = "z",
    exogenous = c("intercept", "period", "control"),
    n_obs = 72L
  ),
  diagnostics = list(
    n_areas = length(areas),
    n_periods = length(periods),
    n_industries = length(inds),
    n_obs = 72L
  )
)

write_json(result, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE, na = "null")
cat(sprintf("iv_slope %.12f\nexposure_area0_period0 %.12f\nexposure_area0_period1 %.12f\ninstrument_area0_period0 %.12f\n",
            iv_slope, x_a0, x_a0p1, z_a0))
