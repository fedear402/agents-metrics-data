hh <- read.csv("households.csv")
census <- read.csv("census.csv")
d <- hh[hh$recipient == 0, ]
n <- nrow(d)
e <- d$eligible
d$d0 <- d$dose * (1 - e)
d$d1 <- d$dose * e
d$x0 <- 1 - e
d$x1 <- e
d$b0 <- d$baseline * (1 - e)
d$b1 <- d$baseline * e
d$z0 <- d$instrument * (1 - e)
d$z1 <- d$instrument * e
X <- as.matrix(d[, c("d0", "d1", "x0", "x1", "b0", "b1")])
Z <- as.matrix(d[, c("x0", "x1", "b0", "b1", "z0", "z1")])
y <- d$outcome
w <- d$weight
sw <- sqrt(w)
Xw <- X * sw
Zw <- Z * sw
yw <- y * sw
PZ <- Zw %*% solve(crossprod(Zw), t(Zw))
beta <- solve(t(Xw) %*% PZ %*% Xw, t(Xw) %*% PZ %*% yw)
b <- as.numeric(beta)
names(b) <- colnames(X)
mean_dose <- function(mask) sum(w[mask] * d$dose[mask]) / sum(w[mask])
m0 <- mean_dose(e == 0)
m1 <- mean_dose(e == 1)
ineligible_effect <- b["d0"] * m0
eligible_nonrecipient_effect <- b["d1"] * m1
N0 <- census$nonrecipient_population[census$eligible == 0]
N1 <- census$nonrecipient_population[census$eligible == 1]
population_effect <- (N0 * ineligible_effect + N1 * eligible_nonrecipient_effect) / (N0 + N1)
est <- function(term, value) list(term = term, estimate = unname(value), se = NA_real_, n_obs = as.integer(n))
out <- list(
  estimates = list(
    est("ineligible_effect", ineligible_effect),
    est("eligible_nonrecipient_effect", eligible_nonrecipient_effect),
    est("population_effect", population_effect)
  ),
  method_metadata = list(
    estimator = "weighted 2SLS, no intercept, manual sqrt-weight projection",
    sample = "households with recipient == 0, all treatment statuses",
    endogenous = c("dose*(1-eligible)", "dose*eligible"),
    exogenous = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"),
    instruments = c("exogenous set", "instrument*(1-eligible)", "instrument*eligible"),
    weights = "weight",
    aggregation = "population weights from census nonrecipient_population",
    counterfactual = "dose set to zero for all retained households (synthetic convention)"
  ),
  diagnostics = list(
    n_obs = as.integer(n),
    n_ineligible = as.integer(sum(e == 0)),
    n_eligible = as.integer(sum(e == 1)),
    slopes = as.list(b[c("d0", "d1")]),
    weighted_mean_dose = list(ineligible = m0, eligible = m1),
    census_population = list(ineligible = N0, eligible = N1)
  )
)
jsonlite::write_json(c(list(task_id = "applied_nonrecipient_population_iv", platform = "r"), out),
                     "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE, na = "null")
print(unlist(lapply(out$estimates, function(z) c(term = z$term, estimate = format(z$estimate, digits = 12)))))
cat("n_obs =", n, "\n")
