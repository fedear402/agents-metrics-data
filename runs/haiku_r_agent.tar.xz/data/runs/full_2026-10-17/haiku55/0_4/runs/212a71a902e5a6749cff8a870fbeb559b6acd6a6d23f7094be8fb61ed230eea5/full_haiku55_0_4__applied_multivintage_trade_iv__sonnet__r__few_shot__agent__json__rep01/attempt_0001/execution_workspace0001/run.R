library(jsonlite)

tr <- read.csv("trade.csv")
cw <- read.csv("crosswalk.csv")
ar <- read.csv("areas.csv")
em <- read.csv("employment.csv")
oc <- read.csv("outcomes.csv")

tr <- merge(tr, cw, by = "code")
stopifnot(nrow(tr) == 8, !anyDuplicated(tr[c("period", "industry")]))

grid <- expand.grid(area = sort(unique(ar$area)), period = sort(unique(ar$period)),
                    vintage = c("base", "early"), industry = sort(unique(cw$industry)),
                    stringsAsFactors = FALSE)
emp <- merge(grid, em, by = c("area", "period", "vintage", "industry"), all.x = TRUE)
emp$employment[is.na(emp$employment)] <- 0

nat <- aggregate(employment ~ period + vintage + industry, data = emp, FUN = sum)
names(nat)[4] <- "national"
emp <- merge(emp, nat, by = c("period", "vintage", "industry"))
emp <- merge(emp, tr[c("period", "industry", "us_change", "other_change", "price_index", "years")],
             by = c("period", "industry"))
emp <- merge(emp, ar[c("area", "period", "vintage", "total_employment")],
             by = c("area", "period", "vintage"))
stopifnot(all(emp$national > 0))

scale_term <- with(emp, (10 / years) / (price_index / 100) / 1000)
emp$x_term <- with(emp, employment / total_employment * us_change / national * scale_term)
emp$z_term <- with(emp, employment / total_employment * other_change / national * scale_term)

x_df <- aggregate(x_term ~ area + period, data = emp[emp$vintage == "base", ], FUN = sum)
z_df <- aggregate(z_term ~ area + period, data = emp[emp$vintage == "early", ], FUN = sum)
pop <- ar[ar$vintage == "base", c("area", "period", "population")]

d <- merge(oc, x_df, by = c("area", "period"))
d <- merge(d, z_df, by = c("area", "period"))
d <- merge(d, pop, by = c("area", "period"))
d <- d[order(d$period, d$area), ]
stopifnot(nrow(d) == 72)
names(d)[names(d) == "x_term"] <- "x"
names(d)[names(d) == "z_term"] <- "z"

iv <- function(y, C, x, z, w = rep(1, length(y))) {
  X <- cbind(C, x) * sqrt(w); Z <- cbind(C, z) * sqrt(w)
  fitted <- qr.fitted(qr(Z), X)
  as.numeric(qr.coef(qr(fitted), y * sqrt(w)))[ncol(X)]
}
C <- cbind(1, d$period, d$control)
b <- iv(d$change_pp, C, d$x, d$z, d$population)

pick <- function(v, a, p) d[[v]][d$area == a & d$period == p]
n_obs <- nrow(d)

res <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = list(
    list(term = "iv_slope", estimate = b, se = NA, n_obs = n_obs),
    list(term = "exposure_area0_period0", estimate = pick("x", 0, 0), se = NA, n_obs = n_obs),
    list(term = "exposure_area0_period1", estimate = pick("x", 0, 1), se = NA, n_obs = n_obs),
    list(term = "instrument_area0_period0", estimate = pick("z", 0, 0), se = NA, n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "weighted 2SLS",
    outcome = "change_pp",
    endogenous = "x",
    excluded_instrument = "z",
    exogenous = c("intercept", "period", "control"),
    weight = "base-vintage population",
    se_reported = FALSE
  ),
  diagnostics = list(
    n_areas = length(unique(d$area)),
    n_periods = length(unique(d$period)),
    n_obs = n_obs
  )
)
write_json(res, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE, na = "null")
cat(sprintf("iv_slope %.12f\nx00 %.12f\nx01 %.12f\nz00 %.12f\nn %d\n",
            b, pick("x", 0, 0), pick("x", 0, 1), pick("z", 0, 0), n_obs))
