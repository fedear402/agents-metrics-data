suppressPackageStartupMessages({
  library(sandwich)
  library(jsonlite)
})

d <- read.csv("input.csv", stringsAsFactors = FALSE)
d$date <- as.Date(d$date)
d <- d[order(d$date), ]
stopifnot(all(d$sales > 0), all(d$vix > 0), !anyDuplicated(d$date))

L <- 15
dv <- c(NA, diff(log(d$vix)))
ls <- log(d$sales)
n_tot <- nrow(d)

rows <- (L + 2):n_tot
X <- cbind(1, sapply(1:L, function(j) dv[rows - j]))
colnames(X) <- c("(Intercept)", paste0("lag_", 1:L))
y <- ls[rows]
keep <- complete.cases(X) & is.finite(y)
X <- X[keep, , drop = FALSE]
y <- y[keep]
N <- length(y)
k <- ncol(X)

fit <- lm.fit(X, y)
b <- fit$coefficients
u <- y - X %*% b
XtX_inv <- solve(crossprod(X))

S <- crossprod(X * as.numeric(u))
for (j in 1:L) {
  w <- 1 - j / (L + 1)
  idx <- (j + 1):N
  G <- crossprod(X[idx, , drop = FALSE] * as.numeric(u[idx]),
                 X[idx - j, , drop = FALSE] * as.numeric(u[idx - j]))
  S <- S + w * (G + t(G))
}
V <- XtX_inv %*% S %*% XtX_inv * N / (N - (L + 1))

cvec <- c(0, rep(1, L))
cum_est <- sum(b[-1])
cum_se <- sqrt(as.numeric(t(cvec) %*% V %*% cvec))

V_pkg <- NeweyWest(fit_lm <- lm(y ~ X[, -1]), lag = L, prewhite = FALSE, adjust = FALSE) * N / (N - (L + 1))
V_pkg_coef <- V_pkg
cum_se_pkg <- sqrt(as.numeric(t(cvec) %*% V_pkg_coef %*% cvec))

res <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(term = "cumulative_response", estimate = cum_est, se = cum_se, n_obs = N),
    list(term = "lag_1", estimate = unname(b[2]), se = sqrt(V[2, 2]), n_obs = N),
    list(term = "lag_15", estimate = unname(b[16]), se = sqrt(V[16, 16]), n_obs = N)
  ),
  method_metadata = list(
    estimator = "OLS regression of log(sales) on intercept and 15 lags of diff(log(vix))",
    vcov = "Newey-West HAC, max lag 15, Bartlett weights 1-j/16, scaled by N/(N-16)"
  ),
  diagnostics = list(
    total_rows = n_tot,
    first_obs_used = as.character(d$date[rows[keep][1]]),
    last_obs_used = as.character(d$date[rows[keep][N]]),
    cumulative_se_sandwich_check = cum_se_pkg,
    all_coefs = as.list(setNames(unname(b), colnames(X)))
  )
)
write(toJSON(res, auto_unbox = TRUE, digits = NA, pretty = TRUE), "result.json")
cat(toJSON(res, auto_unbox = TRUE, digits = NA, pretty = TRUE), "\n")
