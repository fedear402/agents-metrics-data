iv <- function(y, C, x, z, w = rep(1, length(y))) {
  X <- cbind(C, x) * sqrt(w); Z <- cbind(C, z) * sqrt(w)
  fitted <- qr.fitted(qr(Z), X)
  as.numeric(qr.coef(qr(fitted), y * sqrt(w)))[ncol(X)]
}

crosswalk <- unique(rbind(read.csv("crosswalk.csv"), read.csv("input.csv")))
trade <- read.csv("trade.csv")
areas <- read.csv("areas.csv")
emp <- read.csv("employment.csv")
outcomes <- read.csv("outcomes.csv")

trade <- merge(trade, crosswalk, by = "code", all.x = TRUE)
stopifnot(!anyNA(trade$industry))

grid <- merge(areas, data.frame(industry = sort(unique(crosswalk$industry))))
emp_full <- merge(grid, emp, by = c("area", "period", "vintage", "industry"), all.x = TRUE)
emp_full$employment[is.na(emp_full$employment)] <- 0

nat <- aggregate(employment ~ period + vintage + industry, data = emp_full, FUN = sum)
names(nat)[4] <- "national"

ap <- merge(emp_full, nat, by = c("period", "vintage", "industry"))
ap <- merge(ap, trade[, c("period", "industry", "us_change", "other_change", "price_index", "years")],
            by = c("period", "industry"))
ap$chg <- ifelse(ap$vintage == "base", ap$us_change, ap$other_change)
ap$share_num <- ap$employment / ap$national * ap$chg
ap$term <- ap$share_num / (ap$price_index / 100) / 1000 * (10 / ap$years)

ap$contrib <- ap$employment / ap$total_employment * ap$chg / ap$national /
  (ap$price_index / 100) / 1000 * (10 / ap$years)

agg <- aggregate(contrib ~ area + period + vintage, data = ap, FUN = sum)
expo <- reshape(agg, idvar = c("area", "period"), timevar = "vintage", direction = "wide")
names(expo)[names(expo) == "contrib.base"] <- "x"
names(expo)[names(expo) == "contrib.early"] <- "z"

d <- merge(expo, outcomes, by = c("area", "period"))
d <- merge(d, areas[areas$vintage == "base", c("area", "period", "population")], by = c("area", "period"))
stopifnot(nrow(d) == 72)

d <- d[order(d$area, d$period), ]
C <- cbind(1, d$period, d$control)
slope <- iv(d$change_pp, C, d$x, d$z, d$population)

x_at <- function(a, p) d$x[d$area == a & d$period == p]
z_at <- function(a, p) d$z[d$area == a & d$period == p]

out <- list(
  iv_slope = slope,
  exposure_area0_period0 = x_at(0, 0),
  exposure_area0_period1 = x_at(0, 1),
  instrument_area0_period0 = z_at(0, 0)
)
cat(sprintf("%s %.12g\n", names(out), unlist(out)), sep = "")

res <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = lapply(names(out), function(n) list(
    term = n, estimate = unname(out[[n]]), se = NA, n_obs = 72L
  )),
  method_metadata = list(
    estimator = "weighted 2SLS",
    weight = "base-vintage population",
    instruments = "intercept, period, control, z",
    exposure = "sum over industries of base (or early) share times US (or other) change / national employment / (price_index/100) / 1000 * (10/years)",
    sample = "all area-period observations"
  ),
  diagnostics = list(
    n_areas = length(unique(d$area)),
    n_periods = length(unique(d$period)),
    n_industries = length(unique(crosswalk$industry)),
    n_obs = 72L
  )
)
jsonlite::write_json(res, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE, na = "null")
