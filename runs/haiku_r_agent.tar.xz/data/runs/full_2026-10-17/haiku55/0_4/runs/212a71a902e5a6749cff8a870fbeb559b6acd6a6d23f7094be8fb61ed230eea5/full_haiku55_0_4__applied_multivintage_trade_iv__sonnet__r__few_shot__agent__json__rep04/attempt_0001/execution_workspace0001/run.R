iv <- function(y, C, x, z, w = rep(1, length(y))) {
  X <- cbind(C, x) * sqrt(w); Z <- cbind(C, z) * sqrt(w)
  fitted <- qr.fitted(qr(Z), X)
  as.numeric(qr.coef(qr(fitted), y * sqrt(w)))[ncol(X)]
}

cw <- rbind(read.csv("crosswalk.csv"), read.csv("input.csv"))
trade <- merge(read.csv("trade.csv"), cw, by = "code", all.x = TRUE)
areas <- read.csv("areas.csv")
emp <- read.csv("employment.csv")
outc <- read.csv("outcomes.csv")

industries <- sort(unique(cw$industry))
periods <- sort(unique(areas$period))
areas_ids <- sort(unique(areas$area))

grid <- expand.grid(area = areas_ids, period = periods, vintage = c("base", "early"),
                    industry = industries, stringsAsFactors = FALSE)
emp_full <- merge(grid, emp, by = c("area", "period", "vintage", "industry"), all.x = TRUE)
emp_full$employment[is.na(emp_full$employment)] <- 0

nat <- aggregate(employment ~ period + vintage + industry, data = emp_full, FUN = sum)
names(nat)[4] <- "national"
emp_full <- merge(emp_full, nat, by = c("period", "vintage", "industry"))
stopifnot(all(emp_full$national > 0))

emp_full <- merge(emp_full, areas[, c("area", "period", "vintage", "total_employment")],
                  by = c("area", "period", "vintage"))
emp_full <- merge(emp_full, trade[, c("period", "industry", "us_change", "other_change", "price_index", "years")],
                  by = c("period", "industry"))

emp_full$x_term <- emp_full$employment / emp_full$total_employment *
  (emp_full$us_change / emp_full$national) / (emp_full$price_index / 100) / 1000 * (10 / emp_full$years)
emp_full$z_term <- emp_full$employment / emp_full$total_employment *
  (emp_full$other_change / emp_full$national) / (emp_full$price_index / 100) / 1000 * (10 / emp_full$years)

expo <- aggregate(cbind(x_term, z_term) ~ area + period + vintage, data = emp_full, FUN = sum)
base_x <- expo[expo$vintage == "base", c("area", "period", "x_term")]
early_z <- expo[expo$vintage == "early", c("area", "period", "z_term")]
names(base_x)[3] <- "x"
names(early_z)[3] <- "z"

pop <- areas[areas$vintage == "base", c("area", "period", "population")]
d <- Reduce(function(a, b) merge(a, b, by = c("area", "period")),
            list(outc, base_x, early_z, pop))
stopifnot(nrow(d) == 72)

est <- iv(d$change_pp, cbind(1, d$period, d$control), d$x, d$z, d$population)

pick <- function(a, p) d$x[d$area == a & d$period == p]
pickz <- function(a, p) d$z[d$area == a & d$period == p]

out <- list(
  iv_slope = est,
  exposure_area0_period0 = pick(0, 0),
  exposure_area0_period1 = pick(0, 1),
  instrument_area0_period0 = pickz(0, 0)
)

res <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = lapply(names(out), function(nm) list(
    term = nm, estimate = unname(out[[nm]]), se = NA_real_, n_obs = as.integer(nrow(d))
  )),
  method_metadata = list(
    estimator = "population-weighted 2SLS",
    outcome = "change_pp",
    exogenous = c("intercept", "period", "control"),
    endogenous = "x",
    instrument = "z",
    weight = "base-vintage population",
    exposure_units = "thousands of real dollars per worker per decade",
    crosswalk = "crosswalk.csv stacked with input.csv"
  ),
  diagnostics = list(
    n_obs = nrow(d),
    n_areas = length(areas_ids),
    n_periods = length(periods),
    n_industries = length(industries)
  )
)


jsonlite::write_json(res, "result.json", auto_unbox = TRUE, digits = 15, pretty = TRUE, na = "null")
cat(jsonlite::toJSON(out, auto_unbox = TRUE, digits = 15), "\n")
