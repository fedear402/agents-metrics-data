d <- read.csv("input.csv")
h <- 1
d <- d[abs(d$score) < h, ]
d$w <- 1 - abs(d$score)
d$right <- as.numeric(d$score >= 0)
n_obs <- nrow(d)

side_fit <- function(s, y) {
  k <- d$right == s
  X <- cbind(1, d$score[k])
  w <- d$w[k]
  yy <- y[k]
  XtWX_inv <- solve(crossprod(X, X * w))
  b <- XtWX_inv %*% crossprod(X, w * yy)
  e <- as.vector(yy - X %*% b)
  list(b0 = as.numeric(b[1]), A = XtWX_inv, X = X, w = w, e = e)
}

# Cross-covariance of intercept estimates on one side (HC0 sandwich, WLS)
cov_side <- function(F1, F2) {
  meat <- crossprod(F1$X * (F1$w^2 * F1$e * F2$e), F2$X)
  (F1$A %*% meat %*% F2$A)[1, 1]
}

FY <- list(r = side_fit(1, d$earnings), l = side_fit(0, d$earnings))
FD <- list(r = side_fit(1, d$participated), l = side_fit(0, d$participated))

rf <- FY$r$b0 - FY$l$b0
fs <- FD$r$b0 - FD$l$b0
var_rf <- cov_side(FY$r, FY$r) + cov_side(FY$l, FY$l)
var_fs <- cov_side(FD$r, FD$r) + cov_side(FD$l, FD$l)
cov_rf_fs <- cov_side(FY$r, FD$r) + cov_side(FY$l, FD$l)

tau <- rf / fs
var_tau <- (1 / fs^2) * var_rf + (rf^2 / fs^4) * var_fs - 2 * rf / fs^3 * cov_rf_fs

res <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = tau, se = sqrt(var_tau), n_obs = n_obs),
    list(term = "reduced_form", estimate = rf, se = sqrt(var_rf), n_obs = n_obs),
    list(term = "first_stage", estimate = fs, se = sqrt(var_fs), n_obs = n_obs)
  ),
  method_metadata = list(
    estimator = "Fuzzy RD, local linear WLS (triangular kernel, bandwidth 1, separate slopes per side), ratio of discontinuities",
    vcov = "HC0 sandwich per side; delta method with joint covariance of reduced-form and first-stage intercepts"
  ),
  diagnostics = list(n_left = sum(d$right == 0), n_right = sum(d$right == 1), bandwidth = h, cutoff = 0)
)
jsonlite::write_json(res, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE)
print(c(tau = tau, se_tau = sqrt(var_tau), rf = rf, se_rf = sqrt(var_rf), fs = fs, se_fs = sqrt(var_fs), n = n_obs))
