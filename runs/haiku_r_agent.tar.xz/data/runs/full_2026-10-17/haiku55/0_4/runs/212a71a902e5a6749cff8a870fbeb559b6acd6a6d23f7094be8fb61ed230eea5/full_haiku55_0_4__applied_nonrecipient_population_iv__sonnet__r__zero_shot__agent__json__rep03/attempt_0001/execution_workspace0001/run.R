suppressPackageStartupMessages(library(jsonlite))
hh <- read.csv("households.csv")
cen <- read.csv("census.csv")
d <- hh[hh$recipient == 0, ]
n <- nrow(d)
e <- d$eligible; ne <- 1 - e
dose <- d$dose; b <- d$baseline; z <- d$instrument; w <- d$weight; y <- d$outcome

X <- cbind(dose * ne, dose * e, ne, e, b * ne, b * e)
Z <- cbind(ne, e, b * ne, b * e, z * ne, z * e)

# weighted 2SLS: sqrt-weight rows, then beta = (X'P X)^{-1} X'P y with P = Z(Z'Z)^{-1}Z'
sw <- sqrt(w)
Xw <- X * sw; Zw <- Z * sw; yw <- y * sw
PX <- Zw %*% solve(crossprod(Zw), crossprod(Zw, Xw))
beta <- solve(crossprod(PX, Xw), crossprod(PX, yw))
slope_ineligible <- beta[1]
slope_eligible <- beta[2]

wmean <- function(x, wt) sum(x * wt) / sum(wt)
dose_ineligible <- wmean(dose[ne == 1], w[ne == 1])
dose_eligible <- wmean(dose[e == 1], w[e == 1])
ineligible_effect <- slope_ineligible * dose_ineligible
eligible_nonrecipient_effect <- slope_eligible * dose_eligible

N0 <- cen$nonrecipient_population[cen$eligible == 0]
N1 <- cen$nonrecipient_population[cen$eligible == 1]
population_effect <- (N0 * ineligible_effect + N1 * eligible_nonrecipient_effect) / (N0 + N1)

n0 <- sum(ne == 1); n1 <- sum(e == 1)
est <- list(
  list(term = "ineligible_effect", estimate = unname(ineligible_effect), se = NA_real_, n_obs = as.integer(n)),
  list(term = "eligible_nonrecipient_effect", estimate = unname(eligible_nonrecipient_effect), se = NA_real_, n_obs = as.integer(n)),
  list(term = "population_effect", estimate = unname(population_effect), se = NA_real_, n_obs = as.integer(n))
)
out <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = est,
  method_metadata = list(
    estimator = "weighted 2SLS, no intercept, manual projection",
    regression_weight = "weight",
    endogenous = c("dose*(1-eligible)", "dose*eligible"),
    exogenous = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"),
    instruments = c("exogenous set", "instrument*(1-eligible)", "instrument*eligible"),
    sample = "recipient == 0, both treated statuses",
    counterfactual = "dose set to zero for all retained households",
    group_weights = "census nonrecipient_population"
  ),
  diagnostics = list(
    n_obs = as.integer(n),
    n_ineligible = as.integer(n0),
    n_eligible = as.integer(n1),
    slope_ineligible = unname(slope_ineligible),
    slope_eligible = unname(slope_eligible),
    weighted_mean_dose_ineligible = unname(dose_ineligible),
    weighted_mean_dose_eligible = unname(dose_eligible),
    census_N_ineligible = N0,
    census_N_eligible = N1
  )
)
write_json(out, "result.json", auto_unbox = TRUE, pretty = TRUE, digits = NA, na = "null")
print(unlist(out$diagnostics))
print(c(ineligible_effect = ineligible_effect, eligible_nonrecipient_effect = eligible_nonrecipient_effect, population_effect = population_effect), digits = 12)
