library(jsonlite)

d <- read.csv("input.csv")
stopifnot(all(abs(tapply(d$share, d$region_id, sum) - 1) < 1e-8))

regions <- d[!duplicated(d$region_id), c("region_id", "region_weight", "x", "y")]
regions <- regions[order(regions$region_id), ]
e <- regions$region_weight / sum(regions$region_weight)

shock_tab <- d[!duplicated(d$industry_id), c("industry_id", "shock")]
shock_tab <- shock_tab[order(shock_tab$industry_id), ]
industries <- shock_tab$industry_id
shock <- shock_tab$shock

share_mat <- matrix(0, nrow = nrow(regions), ncol = length(industries))
ri <- match(d$region_id, regions$region_id)
ni <- match(d$industry_id, industries)
share_mat[cbind(ri, ni)] <- d$share

z <- drop(share_mat %*% shock)
wm <- function(v) sum(e * v)
y0 <- regions$y - wm(regions$y)
x0 <- regions$x - wm(regions$x)
z0 <- z - wm(z)

s <- drop(t(share_mat) %*% e)
agg <- function(v0) drop(t(share_mat) %*% (e * v0)) / s
ybar <- agg(y0)
xbar <- agg(x0)
zbar <- agg(z0)

N <- length(industries)
shock_iv <- function(dep, endog) {
  X <- cbind(1, endog)
  Z <- cbind(1, shock)
  cross <- crossprod(Z, s * X)
  beta <- solve(cross, crossprod(Z, s * dep))
  resid <- drop(dep - X %*% beta)
  scores <- Z * (s * resid)
  inv <- solve(cross)
  V <- N / (N - 2) * inv %*% crossprod(scores) %*% t(inv)
  c(slope = beta[2], se = sqrt(V[2, 2]))
}

effect <- shock_iv(ybar, xbar)
first <- shock_iv(xbar, zbar)

reg_effect <- sum(e * z0 * y0) / sum(e * z0 * x0)
reg_first <- sum(e * z0 * x0) / sum(e * z0^2)
stopifnot(abs(effect["slope"] - reg_effect) < 1e-8,
          abs(first["slope"] - reg_first) < 1e-8)

eff_shocks <- 1 / sum(s^2)

res <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = unname(effect["slope"]), se = unname(effect["se"]), n_obs = N),
    list(term = "first_stage", estimate = unname(first["slope"]), se = unname(first["se"]), n_obs = N),
    list(term = "effective_shocks", estimate = eff_shocks, se = NULL, n_obs = N)
  ),
  method_metadata = list(
    estimator = "Shift-share weighted 2SLS with BHJ shock-level weighted IV (HC1, N/(N-2))",
    vcov = "Shock-level HC1 robust, structural residuals, analytic weights s_n, N/(N-2) multiplier"
  ),
  diagnostics = list(
    n_regions = nrow(regions),
    n_industries = N,
    regional_effect_check = reg_effect,
    regional_first_stage_check = reg_first
  )
)
write_json(res, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
print(res$estimates)
