suppressPackageStartupMessages({library(AER); library(sandwich)})
d <- read.csv("input.csv")
h <- 1
d <- d[abs(d$score) < h, ]
d$R <- as.numeric(d$score >= 0)
d$L <- 1 - d$R
d$w <- 1 - abs(d$score)

side_fit <- function(df) {
  X <- cbind(1, df$score)
  W <- df$w
  XtWX_inv <- solve(t(X) %*% (X * W))
  b_y <- XtWX_inv %*% t(X) %*% (W * df$earnings)
  b_d <- XtWX_inv %*% t(X) %*% (W * df$participated)
  e_y <- df$earnings - X %*% b_y
  e_d <- df$participated - X %*% b_d
  meat <- function(a, b) t(X) %*% (X * (W^2 * as.vector(a * b)))
  list(
    int_y = b_y[1], int_d = b_d[1],
    V_yy = (XtWX_inv %*% meat(e_y, e_y) %*% XtWX_inv)[1, 1],
    V_dd = (XtWX_inv %*% meat(e_d, e_d) %*% XtWX_inv)[1, 1],
    V_yd = (XtWX_inv %*% meat(e_y, e_d) %*% XtWX_inv)[1, 1]
  )
}

fr <- side_fit(d[d$R == 1, ])
fl <- side_fit(d[d$R == 0, ])

rf <- fr$int_y - fl$int_y
fs <- fr$int_d - fl$int_d
V_rf <- fr$V_yy + fl$V_yy
V_fs <- fr$V_dd + fl$V_dd
C_rf_fs <- fr$V_yd + fl$V_yd
te <- rf / fs
g <- c(1 / fs, -rf / fs^2)
V <- matrix(c(V_rf, C_rf_fs, C_rf_fs, V_fs), 2, 2)
te_se <- sqrt(as.numeric(t(g) %*% V %*% g))

n_left <- sum(d$L == 1)
n_right <- sum(d$R == 1)
n_tot <- nrow(d)

# Independent check: fully interacted 2SLS (HC0), equivalent to the Wald ratio
d$sR <- d$score * d$R
d$sL <- d$score * d$L
d$wv <- d$w
ivfit <- ivreg(earnings ~ participated + sL + sR | R + sL + sR,
               weights = wv, data = d)
iv_est <- coef(ivfit)["participated"]
iv_se <- sqrt(vcovHC(ivfit, type = "HC0")["participated", "participated"])

res <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = te, se = te_se, n_obs = n_tot),
    list(term = "reduced_form", estimate = rf, se = sqrt(V_rf), n_obs = n_tot),
    list(term = "first_stage", estimate = fs, se = sqrt(V_fs), n_obs = n_tot)
  ),
  method_metadata = list(
    estimator = "Fuzzy RD, local linear WLS, triangular kernel, bandwidth 1, separate slopes per side, Wald ratio",
    vcov = "HC0 sandwich per side; delta method for ratio with joint covariance"
  ),
  diagnostics = list(
    n_left = n_left, n_right = n_right,
    iv_check_estimate = unname(iv_est), iv_check_se_HC0 = unname(iv_se),
    cov_rf_fs = C_rf_fs
  )
)
writeLines(jsonlite::toJSON(res, auto_unbox = TRUE, digits = 12, pretty = TRUE), "result.json")
print(str(res))
