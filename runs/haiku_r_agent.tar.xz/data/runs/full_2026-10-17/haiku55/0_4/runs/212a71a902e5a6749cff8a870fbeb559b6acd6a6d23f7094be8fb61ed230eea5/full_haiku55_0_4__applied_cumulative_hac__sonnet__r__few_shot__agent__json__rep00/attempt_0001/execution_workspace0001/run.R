library(jsonlite)
d <- read.csv("input.csv", stringsAsFactors = FALSE)
d$date <- as.Date(d$date)
d <- d[order(d$date), ]
L <- 15
d$dlv <- c(NA, diff(log(d$vix)))
for (k in 1:L) d[[paste0("l", k)]] <- c(rep(NA, k), head(d$dlv, -k))
s <- d[complete.cases(d[, c("sales", paste0("l", 1:L))]), ]
s$ls <- log(s$sales)
fit <- lm(ls ~ ., data = s[, c("ls", paste0("l", 1:L))])
X <- model.matrix(fit)
b <- coef(fit)
N <- nrow(X)
p <- ncol(X)
scores <- X * residuals(fit)
meat <- crossprod(scores)
for (j in 1:L) {
  G <- crossprod(scores[(j + 1):N, , drop = FALSE], scores[1:(N - j), , drop = FALSE])
  meat <- meat + (1 - j / (L + 1)) * (G + t(G))
}
bread <- solve(crossprod(X))
V <- N / (N - p) * bread %*% meat %*% bread
idx <- 2:(L + 1)
cvec <- c(0, rep(1, L))
cum <- sum(cvec * b)
cum_se <- sqrt(drop(t(cvec) %*% V %*% cvec))
res <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(term = "cumulative_response", estimate = unname(cum), se = unname(cum_se), n_obs = N),
    list(term = "lag_1", estimate = unname(b[2]), se = unname(sqrt(V[2, 2])), n_obs = N),
    list(term = "lag_15", estimate = unname(b[16]), se = unname(sqrt(V[16, 16])), n_obs = N)
  ),
  method_metadata = list(
    estimator = "OLS of log(sales) on intercept and 15 lags of dlog(vix)",
    vcov = "Newey-West HAC, max lag 15, Bartlett weights 1-j/16, scaled by N/(N-16)"
  ),
  diagnostics = list(
    first_outcome_date = as.character(s$date[1]),
    last_outcome_date = as.character(s$date[N]),
    regression_sample_size = N,
    parameter_count = p
  )
)
write_json(res, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE)
print(c(cum = cum, cum_se = cum_se, lag1 = b[2], lag1_se = sqrt(V[2, 2]), lag15 = b[16], lag15_se = sqrt(V[16, 16]), N = N))
