d <- read.csv("input.csv")
d$group <- factor(d$group)
n <- nrow(d)
k <- nlevels(d$group)

fit <- aov(y ~ group, data = d)
tab <- summary(fit)[[1]]
F_stat <- tab[["F value"]][1]
df_num <- tab[["Df"]][1]
df_den <- tab[["Df"]][2]
p_val <- tab[["Pr(>F)"]][1]

fmt <- function(x) format(x, digits = 15, scientific = TRUE)
est <- function(term, value) {
  sprintf('{"term": "%s", "estimate": %s, "se": null, "n_obs": %d}', term, fmt(value), n)
}

json <- paste0(
  "{\n",
  '  "task_id": "anova_oneway",', "\n",
  '  "platform": "r",', "\n",
  '  "estimates": [\n',
  "    ", est("F", F_stat), ",\n",
  "    ", est("df_num", df_num), ",\n",
  "    ", est("df_den", df_den), ",\n",
  "    ", est("p_value", p_val), "\n",
  "  ],\n",
  '  "method_metadata": {"estimator": "one-way ANOVA (F-test, type I sums of squares, equal-variance)", "vcov": "not applicable"},', "\n",
  '  "diagnostics": {}', "\n",
  "}\n"
)
writeLines(json, "result.json")

cat(sprintf("F=%s df_num=%g df_den=%g p=%s\n", fmt(F_stat), df_num, df_den, fmt(p_val)))
