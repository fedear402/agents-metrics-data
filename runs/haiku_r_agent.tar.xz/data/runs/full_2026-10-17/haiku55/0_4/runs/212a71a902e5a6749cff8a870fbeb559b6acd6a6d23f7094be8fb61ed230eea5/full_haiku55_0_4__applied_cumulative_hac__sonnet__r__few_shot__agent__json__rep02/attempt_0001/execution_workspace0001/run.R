library(jsonlite)
d <- read.csv("input.csv", stringsAsFactors = FALSE)
d$date <- as.Date(d$date)
d <- d[order(d$date), ]
d$dlvix <- c(NA, diff(log(d$vix)))
L <- 15
for (k in 1:L) d[[paste0("lag", k)]] <- c(rep(NA, k), head(d$dlvix, -k))
d$log_sales <- log(d$sales)
vars <- c("log_sales", paste0("lag", 1:L))
s <- d[complete.cases(d[, vars]), ]
fit <- lm(log_sales ~ ., data = s[, vars])
X <- model.matrix(fit)
b <- coef(fit)
N <- nrow(X)
p <- ncol(X)
scores <- X * residuals(fit)
hac <- L
meat <- crossprod(scores)
for (j in seq_len(hac)) {
  G <- crossprod(scores[(j + 1):N, , drop = FALSE], scores[1:(N - j), , drop = FALSE])
  meat <- meat + (1 - j / (hac + 1)) * (G + t(G))
}
bread <- solve(crossprod(X))
V <- N / (N - p) * bread %*% meat %*% bread
cvec <- c(0, rep(1, L))
cum <- sum(cvec * b)
cum_se <- sqrt(drop(t(cvec) %*% V %*% cvec))
out <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(term = "cumulative_response", estimate = unname(cum), se = unname(cum_se), n_obs = as.integer(N)),
    list(term = "lag_1", estimate = unname(b["lag1"]), se = unname(sqrt(V["lag1", "lag1"])), n_obs = as.integer(N)),
    list(term = "lag_15", estimate = unname(b["lag15"]), se = unname(sqrt(V["lag15", "lag15"])), n_obs = as.integer(N))
  ),
  method_metadata = list(
    estimator = "OLS regression of log(sales) on intercept and 15 lags of dlog(vix)",
    vcov = "Newey-West HAC, max lag 15, Bartlett weights 1-j/16, scaled by N/(N-16)"
  ),
  diagnostics = list(
    n_input_rows = nrow(d),
    n_regression_rows = N,
    n_parameters = p,
    n_hac_lags = hac
  )
)
write_json(out, "result.json", auto_unbox = TRUE, digits = 16, pretty = TRUE, null = "null")
cat(sprintf("cum=%.10f se=%.10f N=%d\n", cum, cum_se, N))
print(V["lag1","lag1"]); 
