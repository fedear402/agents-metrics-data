hh <- read.csv("households.csv")
census <- read.csv("census.csv")

d <- subset(hh, recipient == 0)
e <- d$eligible
ne <- 1 - e
w <- d$weight
y <- d$outcome

X <- cbind(dose_ne = d$dose * ne, dose_e = d$dose * e,
           ne = ne, e = e,
           base_ne = d$baseline * ne, base_e = d$baseline * e)
Z <- cbind(ne = ne, e = e,
           base_ne = d$baseline * ne, base_e = d$baseline * e,
           inst_ne = d$instrument * ne, inst_e = d$instrument * e)

sw <- sqrt(w)
Xw <- X * sw
Zw <- Z * sw
fitted <- qr.fitted(qr(Zw), Xw)
beta <- as.numeric(qr.coef(qr(fitted), y * sw))
slope_ne <- beta[1]
slope_e <- beta[2]

mean_dose_ne <- weighted.mean(d$dose[ne == 1], w[ne == 1])
mean_dose_e <- weighted.mean(d$dose[e == 1], w[e == 1])

ineligible_effect <- slope_ne * mean_dose_ne
eligible_nonrecipient_effect <- slope_e * mean_dose_e

pop <- census$nonrecipient_population[match(c(0, 1), census$eligible)]
population_effect <- weighted.mean(c(ineligible_effect, eligible_nonrecipient_effect), pop)

n_obs <- nrow(d)

estimates <- list(
  list(term = "ineligible_effect", estimate = ineligible_effect, se = NA_real_, n_obs = n_obs),
  list(term = "eligible_nonrecipient_effect", estimate = eligible_nonrecipient_effect, se = NA_real_, n_obs = n_obs),
  list(term = "population_effect", estimate = population_effect, se = NA_real_, n_obs = n_obs)
)

result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "weighted 2SLS, joint over recipient==0 rows, no added intercept",
    endogenous = c("dose*(1-eligible)", "dose*eligible"),
    exogenous = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"),
    instruments = c("exogenous columns", "instrument*(1-eligible)", "instrument*eligible"),
    weights = "weight",
    effect_definition = "group dose slope times household-weighted mean dose among retained rows in group",
    aggregation_weights = "census nonrecipient_population by eligible group",
    counterfactual = "dose set to zero for all retained households (synthetic convention)",
    standard_errors = "not requested; se reported as null"
  ),
  diagnostics = list(
    n_obs_total = n_obs,
    n_obs_ineligible = sum(ne == 1),
    n_obs_eligible = sum(e == 1),
    dose_slope_ineligible = slope_ne,
    dose_slope_eligible = slope_e,
    weighted_mean_dose_ineligible = mean_dose_ne,
    weighted_mean_dose_eligible = mean_dose_e,
    population_weights = pop,
    instrument_count = ncol(Z),
    endogenous_count = ncol(X)
  )
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE, na = "null")
cat(jsonlite::toJSON(list(ineligible_effect = ineligible_effect,
                          eligible_nonrecipient_effect = eligible_nonrecipient_effect,
                          population_effect = population_effect,
                          n_obs = n_obs), auto_unbox = TRUE, digits = 12), "\n")
