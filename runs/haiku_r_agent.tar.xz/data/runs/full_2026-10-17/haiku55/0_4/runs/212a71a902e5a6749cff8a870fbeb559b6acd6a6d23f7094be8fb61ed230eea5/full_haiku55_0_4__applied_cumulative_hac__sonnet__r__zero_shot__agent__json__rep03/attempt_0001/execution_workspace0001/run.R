suppressMessages(library(sandwich))
d <- read.csv("input.csv", stringsAsFactors = FALSE)
d <- d[order(as.Date(d$date)), ]
y <- log(d$sales)
dv <- c(NA, diff(log(d$vix)))
L <- 15
n <- length(y)
rows <- (L + 2):n
X <- sapply(1:L, function(k) dv[rows - k])
colnames(X) <- paste0("lag_", 1:L)
Y <- y[rows]
N <- length(Y)
fit <- lm(Y ~ X)
b <- coef(fit)[-1]
XX <- cbind(1, X)
u <- residuals(fit)
XtXi <- solve(crossprod(XX))
S <- crossprod(XX * u)
for (j in 1:L) {
  w <- 1 - j / (L + 1)
  idx <- (j + 1):N
  G <- crossprod(XX[idx, , drop = FALSE] * u[idx], XX[idx - j, , drop = FALSE] * u[idx - j])
  S <- S + w * (G + t(G))
}
V <- XtXi %*% S %*% XtXi * N / (N - L - 1)
Vb <- V[-1, -1]
cvec <- rep(1, L)
cum <- sum(b)
cum_se <- sqrt(as.numeric(t(cvec) %*% Vb %*% cvec))
res <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(term = "cumulative_response", estimate = cum, se = cum_se, n_obs = N),
    list(term = "lag_1", estimate = unname(b[1]), se = sqrt(Vb[1, 1]), n_obs = N),
    list(term = "lag_15", estimate = unname(b[L]), se = sqrt(Vb[L, L]), n_obs = N)
  ),
  method_metadata = list(
    estimator = "OLS of log(sales) on intercept and 15 lags of diff(log(vix))",
    vcov = "Newey-West HAC, max lag 15, Bartlett weights 1-j/16, scaled by N/(N-16)"
  ),
  diagnostics = list(sample_start_row = rows[1], N = N)
)
jsonlite::write_json(res, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE)
cat(sprintf("cum=%.10f se=%.10f lag1=%.10f lag15=%.10f N=%d\n", cum, cum_se, b[1], b[L], N))
# Checks
Vs <- NeweyWest(fit, lag = L, prewhite = FALSE, adjust = TRUE)[-1, -1]
cat(sprintf("sandwich NW cum se (via c'Vc)=%.10f\n", sqrt(sum(Vs))))
Z <- cbind(X[, 1], sapply(2:L, function(k) X[, k] - X[, 1]))
fit2 <- lm(Y ~ Z)
S2 <- NeweyWest(fit2, lag = L, prewhite = FALSE, adjust = TRUE)
cat(sprintf("reparam coef on cum=%.10f se=%.10f\n", coef(fit2)[2], sqrt(S2[2, 2])))
