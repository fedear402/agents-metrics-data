d <- read.csv("input.csv")
h <- 1
s <- d$score
keep <- abs(s) < h
dd <- d[keep, ]
w <- 1 - abs(dd$score)
right <- dd$score >= 0

# Per-side WLS with intercept and slope; returns bread, and per-obs scores for y and d
side_fit <- function(idx) {
  X <- cbind(1, dd$score[idx])
  W <- w[idx]
  y1 <- dd$earnings[idx]; y2 <- dd$participated[idx]
  A <- crossprod(X * W, X)
  Ainv <- solve(A)
  b1 <- Ainv %*% crossprod(X * W, y1)
  b2 <- Ainv %*% crossprod(X * W, y2)
  e1 <- y1 - X %*% b1
  e2 <- y2 - X %*% b2
  # meat: sum w^2 x x' e_a e_b
  M <- function(ea, eb) {
    Z <- X * as.vector(W * ea); Z2 <- X * as.vector(W * eb)
    crossprod(Z, Z2)
  }
  list(a1 = b1[1], a2 = b2[1],
       V11 = Ainv %*% M(e1, e1) %*% Ainv,
       V22 = Ainv %*% M(e2, e2) %*% Ainv,
       V12 = Ainv %*% M(e1, e2) %*% Ainv,
       n = length(idx))
}

R <- side_fit(which(right))
L <- side_fit(which(!right))

rf <- R$a1 - L$a1
fs <- R$a2 - L$a2
V_rf <- R$V11[1,1] + L$V11[1,1]
V_fs <- R$V22[1,1] + L$V22[1,1]
C    <- R$V12[1,1] + L$V12[1,1]
tau  <- rf / fs
# delta method: grad = (1/fs, -rf/fs^2)
g <- c(1/fs, -rf/fs^2)
Vjoint <- matrix(c(V_rf, C, C, V_fs), 2, 2)
se_tau <- sqrt(as.numeric(t(g) %*% Vjoint %*% g))

n_all <- nrow(dd)
res <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = unname(tau), se = se_tau, n_obs = n_all),
    list(term = "reduced_form", estimate = unname(rf), se = sqrt(V_rf), n_obs = n_all),
    list(term = "first_stage", estimate = unname(fs), se = sqrt(V_fs), n_obs = n_all)
  ),
  method_metadata = list(
    estimator = "Fuzzy RD, local linear WLS (triangular kernel, h=1), separate slopes and intercepts per side, Wald ratio",
    vcov = "HC0 sandwich per side; delta method for ratio with joint covariance"
  ),
  diagnostics = list(n_left = L$n, n_right = R$n, cutoff = 0, bandwidth = h)
)
jsonlite::write_json(res, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE)
print(unlist(lapply(res$estimates, function(e) c(e$term, e$estimate, e$se, e$n_obs))))
