suppressPackageStartupMessages(library(jsonlite))

crosswalk <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
trade <- read.csv("trade.csv", stringsAsFactors = FALSE)
areas <- read.csv("areas.csv", stringsAsFactors = FALSE)
employment <- read.csv("employment.csv", stringsAsFactors = FALSE)
outcomes <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

trade <- merge(trade, crosswalk, by = "code", all.x = TRUE)
stopifnot(!anyNA(trade$industry))

grid <- merge(
  merge(unique(areas[, c("area", "period")]),
        expand.grid(vintage = c("base", "early"), stringsAsFactors = FALSE)),
  unique(trade[, c("period", "industry")])
)
emp <- merge(grid, employment, by = c("area", "period", "vintage", "industry"), all.x = TRUE)
emp$employment[is.na(emp$employment)] <- 0

natl <- aggregate(employment ~ period + vintage + industry, emp, sum)
names(natl)[4] <- "natl_emp"

emp <- merge(emp, natl, by = c("period", "vintage", "industry"))
emp <- merge(emp, trade[, c("period", "industry", "us_change", "other_change", "price_index", "years")],
             by = c("period", "industry"))
emp <- merge(emp, areas[, c("area", "period", "vintage", "total_employment")],
             by = c("area", "period", "vintage"))
stopifnot(all(emp$natl_emp > 0))

build_exposure <- function(v, change) {
  s <- emp[emp$vintage == v, ]
  s$term <- (s$employment / s$total_employment) *
    (s[[change]] / s$natl_emp) /
    (s$price_index / 100) / 1000 * (10 / s$years)
  out <- aggregate(term ~ area + period, s, sum)
  names(out)[3] <- "value"
  out
}
x_df <- build_exposure("base", "us_change")
z_df <- build_exposure("early", "other_change")

base_areas <- areas[areas$vintage == "base", c("area", "period", "population")]
d <- merge(outcomes, base_areas, by = c("area", "period"))
d <- merge(d, x_df, by = c("area", "period"))
names(d)[names(d) == "value"] <- "x"
d <- merge(d, z_df, by = c("area", "period"))
names(d)[names(d) == "value"] <- "z"
d <- d[order(d$area, d$period), ]
stopifnot(nrow(d) == 72)

X <- cbind(1, d$period, d$control, d$x)
Z <- cbind(1, d$period, d$control, d$z)
y <- d$change_pp
w <- d$population
Xw <- X * sqrt(w); Zw <- Z * sqrt(w); yw <- y * sqrt(w)
PZ <- Zw %*% solve(crossprod(Zw), t(Zw))
beta <- solve(t(Xw) %*% PZ %*% Xw, t(Xw) %*% PZ %*% yw)
iv_slope <- beta[4]

x_a0_p0 <- d$x[d$area == 0 & d$period == 0]
x_a0_p1 <- d$x[d$area == 0 & d$period == 1]
z_a0_p0 <- d$z[d$area == 0 & d$period == 0]

n_obs <- as.integer(nrow(d))
mk <- function(term, est) list(term = term, estimate = est, se = NA_real_, n_obs = n_obs)

result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = list(
    mk("iv_slope", as.numeric(iv_slope)),
    mk("exposure_area0_period0", as.numeric(x_a0_p0)),
    mk("exposure_area0_period1", as.numeric(x_a0_p1)),
    mk("instrument_area0_period0", as.numeric(z_a0_p0))
  ),
  method_metadata = list(
    estimator = "weighted 2SLS",
    weight = "base-vintage population",
    regressors = c("intercept", "period", "control", "x"),
    instruments = c("intercept", "period", "control", "z"),
    industries = 4L,
    periods = 2L,
    se = "not reported"
  ),
  diagnostics = list(
    n_area_period_obs = n_obs,
    rows_with_zero_employment_cells = sum(emp$employment == 0)
  )
)
write_json(result, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE, na = "null")
cat(sprintf("iv_slope=%.10f x0p0=%.10f x0p1=%.10f z0p0=%.10f n=%d\n",
            iv_slope, x_a0_p0, x_a0_p1, z_a0_p0, n_obs))
