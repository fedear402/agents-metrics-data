d <- read.csv("input.csv"); d <- d[abs(d$score) < 1, ]
side <- function(keep) {
  x <- d[keep, ]; w <- 1 - abs(x$score)
  f <- lm(cbind(earnings, participated) ~ score, data = x, weights = w)
  Xm <- model.matrix(~score, x); Ey <- resid(f)
  bread <- solve(crossprod(Xm, w * Xm)); a <- bread[1, ] 
  infl <- (w * drop(Xm %*% a)) * Ey
  list(b = coef(f)[1, ], V = crossprod(infl))
}
R <- side(d$score >= 0); L <- side(d$score < 0)
rf <- R$b["earnings"] - L$b["earnings"]; fs <- R$b["participated"] - L$b["participated"]
V <- R$V + L$V
g <- c(1/fs, -rf/fs^2)
cat("RF", rf, sqrt(V[1,1]), "\nFS", fs, sqrt(V[2,2]), "\nTE", rf/fs, sqrt(drop(t(g)%*%V%*%g)), "\n")
library(AER)
w <- 1 - abs(d$score); z <- as.numeric(d$score >= 0)
iv <- ivreg(earnings ~ participated + score + I(z*score) | z + score + I(z*score), weights = w, data = d)
cat("2SLS TE", coef(iv)["participated"], "\n")
