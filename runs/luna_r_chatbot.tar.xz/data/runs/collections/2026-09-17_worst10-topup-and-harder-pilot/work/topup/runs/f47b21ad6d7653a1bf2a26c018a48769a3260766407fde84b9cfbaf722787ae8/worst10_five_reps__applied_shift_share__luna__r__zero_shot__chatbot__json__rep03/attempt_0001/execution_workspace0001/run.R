# applied_shift_share.R

options(stringsAsFactors = FALSE)

dat <- read.csv("input.csv", check.names = FALSE)

required <- c("region_id", "industry_id", "share", "shock",
              "region_weight", "x", "y")
missing_cols <- setdiff(required, names(dat))
if (length(missing_cols) > 0) {
  stop("Missing required columns: ", paste(missing_cols, collapse = ", "))
}

regions <- !duplicated(dat$region_id)
rdat <- dat[regions, c("region_id", "region_weight", "x", "y")]

rdat$e <- rdat$region_weight / sum(rdat$region_weight)
rdat$x0 <- rdat$x - sum(rdat$e * rdat$x)
rdat$y0 <- rdat$y - sum(rdat$e * rdat$y)

dat <- merge(
  dat,
  rdat[, c("region_id", "e", "x0", "y0")],
  by = "region_id",
  all.x = TRUE,
  sort = FALSE
)

z_by_region <- aggregate(
  share * shock ~ region_id,
  data = dat,
  FUN = sum
)
names(z_by_region)[2] <- "z"

rdat <- merge(rdat, z_by_region, by = "region_id", sort = FALSE)
rdat$z0 <- rdat$z - sum(rdat$e * rdat$z)

dat <- merge(
  dat,
  rdat[, c("region_id", "z0")],
  by = "region_id",
  all.x = TRUE,
  sort = FALSE
)

dat$exposure <- dat$e * dat$share

s_by_industry <- aggregate(exposure ~ industry_id, data = dat, FUN = sum)
names(s_by_industry)[2] <- "s"

shock_by_industry <- aggregate(shock ~ industry_id, data = dat, FUN = function(v) v[1])
names(shock_by_industry)[2] <- "shock_n"

aggregate_weighted <- function(value, d) {
  num <- aggregate(d$exposure * value ~ d$industry_id, FUN = sum)
  den <- aggregate(d$exposure ~ d$industry_id, FUN = sum)
  out <- num[[2]] / den[[2]]
  names(out) <- den[[1]]
  out
}

xbar <- aggregate_weighted(dat$x0, dat)
ybar <- aggregate_weighted(dat$y0, dat)
zbar <- aggregate_weighted(dat$z0, dat)

shock_level <- merge(s_by_industry, shock_by_industry,
                     by = "industry_id", sort = FALSE)
shock_level$xbar <- unname(xbar[as.character(shock_level$industry_id)])
shock_level$ybar <- unname(ybar[as.character(shock_level$industry_id)])
shock_level$zbar <- unname(zbar[as.character(shock_level$industry_id)])

shock_level <- shock_level[
  is.finite(shock_level$s) &
  shock_level$s > 0 &
  is.finite(shock_level$shock_n) &
  is.finite(shock_level$xbar) &
  is.finite(shock_level$ybar) &
  is.finite(shock_level$zbar),
]

N <- nrow(shock_level)

if (N <= 2) {
  stop("At least three industries are required for HC1 standard errors.")
}

if (!requireNamespace("ivreg", quietly = TRUE)) {
  stop("The ivreg package is required.")
}
if (!requireNamespace("sandwich", quietly = TRUE)) {
  stop("The sandwich package is required.")
}

effect_fit <- ivreg::ivreg(
  ybar ~ xbar | shock_n,
  data = shock_level,
  weights = s
)

first_stage_fit <- ivreg::ivreg(
  xbar ~ zbar | shock_n,
  data = shock_level,
  weights = s
)

effect_vcov <- sandwich::vcovHC(effect_fit, type = "HC1")
first_stage_vcov <- sandwich::vcovHC(first_stage_fit, type = "HC1")

effect_estimate <- unname(stats::coef(effect_fit)["xbar"])
effect_se <- sqrt(effect_vcov["xbar", "xbar"])

first_stage_estimate <- unname(stats::coef(first_stage_fit)["zbar"])
first_stage_se <- sqrt(first_stage_vcov["zbar", "zbar"])

effective_shocks <- 1 / sum(shock_level$s^2)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(
      term = "effect",
      estimate = as.numeric(effect_estimate),
      se = as.numeric(effect_se),
      n_obs = as.integer(N)
    ),
    list(
      term = "first_stage",
      estimate = as.numeric(first_stage_estimate),
      se = as.numeric(first_stage_se),
      n_obs = as.integer(N)
    ),
    list(
      term = "effective_shocks",
      estimate = as.numeric(effective_shocks),
      se = NULL,
      n_obs = as.integer(N)
    )
  ),
  method_metadata = list(
    estimator = "Borusyak-Hull-Jaravel shock-level weighted 2SLS",
    vcov = "Shock-level heteroskedasticity-robust HC1 with analytic weights"
  ),
  diagnostics = list()
)

if (!requireNamespace("jsonlite", quietly = TRUE)) {
  stop("The jsonlite package is required.")
}

jsonlite::write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 17
)
