d <- read.csv("input.csv")

n <- nrow(d)
q <- 2
df <- n - 4
critical <- qf(0.95, q, df)
k <- q * critical / df

y <- d$y
endog <- d$endog

Xr <- cbind("(Intercept)" = 1, x = d$x)
Xu <- cbind("(Intercept)" = 1, x = d$x, z1 = d$z1, z2 = d$z2)

ssr <- function(response, X) {
  fit <- lm.fit(X, response)
  sum(fit$residuals^2)
}

ar_components <- function(beta) {
  transformed <- y - beta * endog
  ssr_r <- ssr(transformed, Xr)
  ssr_u <- ssr(transformed, Xu)
  c(ssr_r = ssr_r, ssr_u = ssr_u)
}

g <- function(beta) {
  s <- ar_components(beta)
  s[["ssr_r"]] - (1 + k) * s[["ssr_u"]]
}

g0 <- g(0)
g1 <- g(1)
gm1 <- g(-1)

A <- (g1 + gm1) / 2 - g0
B <- (g1 - gm1) / 2
C <- g0

roots <- polyroot(c(C, B, A))
real_roots <- sort(Re(roots[abs(Im(roots)) < 1e-8]))

if (length(real_roots) != 2L) {
  stop("Expected two finite real boundary points.")
}

bounds <- real_roots

accepts <- function(beta) {
  A * beta^2 + B * beta + C <= 0
}

unbounded <- as.integer(A < 0)
accepts_zero <- as.integer(accepts(0))

s_one <- ar_components(1)
ar_f_at_one <- ((s_one[["ssr_r"]] - s_one[["ssr_u"]]) / q) /
  (s_one[["ssr_u"]] / df)

rows <- list(
  list(
    term = "boundary_low",
    estimate = unname(bounds[1]),
    se = NULL,
    n_obs = n
  ),
  list(
    term = "boundary_high",
    estimate = unname(bounds[2]),
    se = NULL,
    n_obs = n
  ),
  list(
    term = "accepts_zero",
    estimate = accepts_zero,
    se = NULL,
    n_obs = n
  ),
  list(
    term = "unbounded",
    estimate = unbounded,
    se = NULL,
    n_obs = n
  ),
  list(
    term = "ar_f_at_one",
    estimate = unname(ar_f_at_one),
    se = NULL,
    n_obs = n
  )
)

jsonlite::write_json(
  list(
    task_id = "broad_ar_confidence_set",
    platform = "r",
    estimates = rows,
    method_metadata = list(
      estimator = "Anderson-Rubin confidence-set inversion with homoskedastic joint F test",
      vcov = "homoskedastic"
    ),
    diagnostics = list()
  ),
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
