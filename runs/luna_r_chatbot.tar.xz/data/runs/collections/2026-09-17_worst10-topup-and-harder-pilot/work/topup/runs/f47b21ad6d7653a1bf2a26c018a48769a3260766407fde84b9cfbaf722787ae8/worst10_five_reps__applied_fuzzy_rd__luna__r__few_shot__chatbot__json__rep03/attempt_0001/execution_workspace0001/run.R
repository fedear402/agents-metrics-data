library(jsonlite)

dat <- read.csv("input.csv")

keep <- abs(dat$score) < 1
dat <- dat[keep, ]

x <- dat$score
right <- as.numeric(x >= 0)
w <- 1 - abs(x)

X <- cbind(
  intercept = 1,
  score = x,
  right = right,
  right_score = right * x
)

Y <- cbind(
  earnings = dat$earnings,
  participated = dat$participated
)

W <- diag(w)
bread <- solve(crossprod(X, W %*% X))
beta <- bread %*% crossprod(X, W %*% Y)
residuals <- Y - X %*% beta

contrast <- c(0, 0, 1, 0)
discontinuities <- drop(contrast %*% beta)

loading <- as.vector(w * (X %*% bread %*% contrast))
influence <- loading * residuals
joint_covariance <- crossprod(influence)

reduced_form <- discontinuities[1]
first_stage <- discontinuities[2]
treatment_effect <- reduced_form / first_stage

gradient <- c(
  1 / first_stage,
  -reduced_form / first_stage^2
)
treatment_variance <- drop(
  t(gradient) %*% joint_covariance %*% gradient
)

n_obs <- nrow(dat)

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(
      term = "treatment_effect",
      estimate = unname(as.numeric(treatment_effect)),
      se = unname(as.numeric(sqrt(treatment_variance))),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "reduced_form",
      estimate = unname(as.numeric(reduced_form)),
      se = unname(as.numeric(sqrt(joint_covariance[1, 1]))),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "first_stage",
      estimate = unname(as.numeric(first_stage)),
      se = unname(as.numeric(sqrt(joint_covariance[2, 2]))),
      n_obs = as.integer(n_obs)
    )
  ),
  method_metadata = list(
    estimator = "fuzzy local-linear regression discontinuity with triangular weights",
    vcov = "conventional heteroskedasticity-robust HC0 with joint delta method"
  ),
  diagnostics = list()
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
