#!/usr/bin/env Rscript

options(warn = 1)

dat <- read.csv("input.csv", stringsAsFactors = FALSE)
dat <- dat[complete.cases(dat[, c("y", "x", "z")]), ]

y <- as.integer(dat$y)
X <- cbind(x = as.numeric(dat$x), z = as.numeric(dat$z))
n <- nrow(dat)

logistic <- function(q) {
  plogis(q)
}

negloglik <- function(par) {
  beta <- par[1:2]
  cut1 <- par[3]
  cut2 <- cut1 + exp(par[4])
  eta <- drop(X %*% beta)

  p1 <- logistic(cut1 - eta)
  p2 <- logistic(cut2 - eta) - p1
  p3 <- 1 - logistic(cut2 - eta)

  probs <- cbind(p1, p2, p3)
  selected <- probs[cbind(seq_len(n), y)]

  if (any(!is.finite(selected)) || any(selected <= 0)) {
    return(1e100)
  }

  -sum(log(selected))
}

starts <- list(
  c(0, 0, -0.5, 0),
  c(0, 0, 0, 0),
  c(0, 0, 0.5, 0),
  c(1, 1, -0.5, 0),
  c(-1, -1, 0.5, 0)
)

fits <- lapply(
  starts,
  function(s) optim(
    s,
    negloglik,
    method = "BFGS",
    hessian = TRUE,
    control = list(maxit = 10000, reltol = 1e-12)
  )
)

fit <- fits[[which.min(vapply(fits, function(f) f$value, numeric(1)))]]
par_hat <- fit$par

H <- fit$hessian
V <- tryCatch(solve(H), error = function(e) qr.solve(H))
se_par <- sqrt(pmax(diag(V), 0))

beta_hat <- par_hat[1:2]
beta_se <- se_par[1:2]

cut2_hat <- par_hat[3] + exp(par_hat[4])
eta_high <- beta_hat[1]
prob_high <- plogis(eta_high - cut2_hat)

estimates <- list(
  list(
    term = "x",
    estimate = unname(beta_hat[1]),
    se = unname(beta_se[1]),
    n_obs = n
  ),
  list(
    term = "z",
    estimate = unname(beta_hat[2]),
    se = unname(beta_se[2]),
    n_obs = n
  ),
  list(
    term = "prob_high",
    estimate = unname(prob_high),
    se = NULL,
    n_obs = n
  )
)

result <- list(
  task_id = "broad_ordered_logit",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "maximum likelihood ordered logit",
    vcov = "inverse observed information"
  ),
  diagnostics = list()
)

if (requireNamespace("jsonlite", quietly = TRUE)) {
  jsonlite::write_json(
    result,
    "result.json",
    auto_unbox = TRUE,
    digits = 17,
    null = "null"
  )
} else {
  esc <- function(x) {
    gsub('"', '\\"', as.character(x), fixed = TRUE)
  }

  fmt <- function(x) {
    if (is.null(x)) "null" else formatC(x, digits = 17, format = "fg", flag = "#")
  }

  json <- paste0(
    '{',
    '"task_id":"broad_ordered_logit",',
    '"platform":"r",',
    '"estimates":[',
    '{"term":"x","estimate":', fmt(beta_hat[1]),
    ',"se":', fmt(beta_se[1]), ',"n_obs":', n, '},',
    '{"term":"z","estimate":', fmt(beta_hat[2]),
    ',"se":', fmt(beta_se[2]), ',"n_obs":', n, '},',
    '{"term":"prob_high","estimate":', fmt(prob_high),
    ',"se":null,"n_obs":', n, '}',
    '],',
    '"method_metadata":{"estimator":"maximum likelihood ordered logit",',
    '"vcov":"inverse observed information"},',
    '"diagnostics":{}',
    '}'
  )

  writeLines(json, "result.json")
}
