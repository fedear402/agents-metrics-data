dat <- read.csv("input.csv")

y <- as.integer(dat$y)
x <- as.numeric(dat$x)
z <- as.numeric(dat$z)
n <- length(y)

negloglik <- function(par) {
  beta <- par[1:2]
  c1 <- par[3]
  c2 <- c1 + exp(par[4])
  eta <- beta[1] * x + beta[2] * z

  p1 <- plogis(c1 - eta)
  p2 <- plogis(c2 - eta) - p1
  p3 <- 1 - plogis(c2 - eta)

  p <- cbind(p1, p2, p3)[cbind(seq_len(n), y)]
  if (any(!is.finite(p)) || any(p <= 0)) return(1e100)

  -sum(log(p))
}

start <- c(0, 0, 0, 0)
fit <- optim(
  par = start,
  fn = negloglik,
  method = "BFGS",
  hessian = TRUE,
  control = list(maxit = 10000, reltol = 1e-12)
)

par_hat <- fit$par
vcov_hat <- solve(fit$hessian)

se_x <- sqrt(vcov_hat[1, 1])
se_z <- sqrt(vcov_hat[2, 2])

c1_hat <- par_hat[3]
c2_hat <- c1_hat + exp(par_hat[4])

lp_high <- par_hat[1]
prob_high <- plogis(lp_high - c2_hat)

p_high <- prob_high * (1 - prob_high)
grad_high <- c(
  p_high,
  0,
  -p_high,
  -exp(par_hat[4]) * p_high
)

var_prob_high <- as.numeric(t(grad_high) %*% vcov_hat %*% grad_high)
if (var_prob_high < 0 && abs(var_prob_high) < 1e-12) {
  var_prob_high <- 0
}

result <- sprintf(
  paste0(
    '{',
    '"task_id":"broad_ordered_logit",',
    '"platform":"r",',
    '"estimates":[',
    '{"term":"x","estimate":%.17g,"se":%.17g,"n_obs":%d},',
    '{"term":"z","estimate":%.17g,"se":%.17g,"n_obs":%d},',
    '{"term":"prob_high","estimate":%.17g,"se":null,"n_obs":%d}',
    '],',
    '"method_metadata":{',
    '"estimator":"maximum likelihood ordered logit",',
    '"vcov":"conventional observed information"',
    '},',
    '"diagnostics":{}',
    '}'
  ),
  par_hat[1], se_x, n,
  par_hat[2], se_z, n,
  prob_high, n
)

writeLines(result, "result.json")
