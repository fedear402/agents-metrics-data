#!/usr/bin/env Rscript

dat <- read.csv("input.csv")
n <- nrow(dat)

y <- dat$y
endog <- dat$endog
x <- dat$x
z <- as.matrix(dat[c("z1", "z2")])

controls <- cbind(1, x)
z_res <- qr.resid(qr(controls), z)
y_res <- qr.resid(qr(controls), y)
e_res <- qr.resid(qr(controls), endog)

p_z <- z_res %*% solve(crossprod(z_res), t(z_res))

full_design <- cbind(controls, z)
y_full_res <- qr.resid(qr(full_design), y)
e_full_res <- qr.resid(qr(full_design), endog)

diff_coef <- c(
  crossprod(y_res, p_z %*% y_res),
  -2 * crossprod(e_res, p_z %*% y_res),
  crossprod(e_res, p_z %*% e_res)
)

rss_coef <- c(
  crossprod(y_full_res),
  -2 * crossprod(e_full_res, y_full_res),
  crossprod(e_full_res)
)

f_crit <- qf(0.95, df1 = 2, df2 = n - 4)

ineq_coef <- (n - 4) * diff_coef - 2 * f_crit * rss_coef

tol <- 1e-10 * max(1, abs(ineq_coef))
a <- as.numeric(ineq_coef[3])
b <- as.numeric(ineq_coef[2])
cc <- as.numeric(ineq_coef[1])

if (abs(a) > tol) {
  discr <- b^2 - 4 * a * cc
  roots <- sort(as.numeric(polyroot(c(cc, b, a))))
  roots <- sort(Re(roots[abs(Im(roots)) < 1e-8]))
} else if (abs(b) > tol) {
  roots <- -cc / b
} else {
  roots <- numeric(0)
}

boundary_low <- min(roots)
boundary_high <- max(roots)

ar_f <- function(beta) {
  q <- y - beta * endog
  q_res <- qr.resid(qr(controls), q)
  q_full_res <- qr.resid(qr(full_design), q)
  restricted_rss <- sum(q_res^2)
  unrestricted_rss <- sum(q_full_res^2)
  ((restricted_rss - unrestricted_rss) / 2) /
    (unrestricted_rss / (n - 4))
}

accepts_zero <- as.numeric(ar_f(0) <= f_crit)

if (abs(a) > tol) {
  unbounded <- as.numeric(a < 0)
} else if (abs(b) > tol) {
  unbounded <- as.numeric(b < 0 || b > 0)
} else {
  unbounded <- as.numeric(cc <= tol)
}

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = list(
    list(term = "boundary_low", estimate = as.numeric(boundary_low),
         se = NA_real_, n_obs = as.integer(n)),
    list(term = "boundary_high", estimate = as.numeric(boundary_high),
         se = NA_real_, n_obs = as.integer(n)),
    list(term = "accepts_zero", estimate = accepts_zero,
         se = NA_real_, n_obs = as.integer(n)),
    list(term = "unbounded", estimate = unbounded,
         se = NA_real_, n_obs = as.integer(n)),
    list(term = "ar_f_at_one", estimate = as.numeric(ar_f(1)),
         se = NA_real_, n_obs = as.integer(n))
  ),
  method_metadata = list(
    estimator = "Anderson-Rubin confidence set with homoskedastic joint F test",
    vcov = "conventional homoskedastic"
  ),
  diagnostics = list()
)

jsonlite::write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  na = "null",
  pretty = FALSE
)
