d <- read.csv("input.csv")

d <- d[abs(d$score) < 1, , drop = FALSE]
n_obs <- nrow(d)

x <- d$score
right <- as.numeric(x >= 0)
w <- 1 - abs(x)

X <- cbind(1, right, x, right * x)
Y <- cbind(d$earnings, d$participated)

XtWX <- crossprod(X, w * X)
bread <- solve(XtWX)
beta <- bread %*% crossprod(X, w * Y)

resid <- Y - X %*% beta

meat_rf <- matrix(0, ncol(X), ncol(X))
meat_fs <- matrix(0, ncol(X), ncol(X))
meat_cross <- matrix(0, ncol(X), ncol(X))

for (i in seq_len(n_obs)) {
  xi <- X[i, , drop = FALSE]
  xx <- crossprod(xi)
  meat_rf <- meat_rf + w[i]^2 * resid[i, 1]^2 * xx
  meat_fs <- meat_fs + w[i]^2 * resid[i, 2]^2 * xx
  meat_cross <- meat_cross + w[i]^2 * resid[i, 1] * resid[i, 2] * xx
}

vcov_rf <- bread %*% meat_rf %*% bread
vcov_fs <- bread %*% meat_fs %*% bread
vcov_cross <- bread %*% meat_cross %*% bread

reduced_form <- unname(beta[2, 1])
first_stage <- unname(beta[2, 2])

se_reduced_form <- sqrt(vcov_rf[2, 2])
se_first_stage <- sqrt(vcov_fs[2, 2])

treatment_effect <- reduced_form / first_stage

g <- c(1 / first_stage, -reduced_form / first_stage^2)
cov_disc <- matrix(
  c(vcov_rf[2, 2], vcov_cross[2, 2],
    vcov_cross[2, 2], vcov_fs[2, 2]),
  nrow = 2,
  byrow = TRUE
)
se_treatment_effect <- sqrt(as.numeric(t(g) %*% cov_disc %*% g))

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(
      term = "treatment_effect",
      estimate = as.numeric(treatment_effect),
      se = as.numeric(se_treatment_effect),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "reduced_form",
      estimate = as.numeric(reduced_form),
      se = as.numeric(se_reduced_form),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "first_stage",
      estimate = as.numeric(first_stage),
      se = as.numeric(se_first_stage),
      n_obs = as.integer(n_obs)
    )
  ),
  method_metadata = list(
    estimator = "Fuzzy local-linear regression discontinuity with triangular weights",
    vcov = "Conventional heteroskedasticity-robust HC0 with joint delta method covariance"
  ),
  diagnostics = list()
)

jsonlite::write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  pretty = TRUE,
  na = "null"
)
