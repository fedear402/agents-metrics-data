dat <- read.csv("input.csv")

y <- dat$y
d <- dat$endog
base <- cbind(1, dat$x)
z <- as.matrix(dat[, c("z1", "z2")])

resid_matrix <- function(v, X) {
  qr.resid(qr(X), v)
}

yr <- resid_matrix(y, base)
dr <- resid_matrix(d, base)
zr <- resid_matrix(z, base)

A <- crossprod(zr)
Ainv <- solve(A)

yr_full <- resid_matrix(y, cbind(base, z))
dr_full <- resid_matrix(d, cbind(base, z))

b0 <- crossprod(zr, yr)
bd <- crossprod(zr, dr)

explained0 <- as.numeric(crossprod(b0, Ainv %*% b0))
explained1 <- as.numeric(crossprod(bd, Ainv %*% bd))
explained_cross <- as.numeric(crossprod(b0, Ainv %*% bd))

sse0 <- as.numeric(crossprod(yr_full))
sse1 <- as.numeric(crossprod(dr_full))
sse_cross <- as.numeric(crossprod(yr_full, dr_full))

n <- nrow(dat)
df_num <- 2
df_den <- n - 4
f_crit <- qf(0.95, df_num, df_den)

f_stat <- function(beta) {
  b <- b0 - beta * bd
  explained <- as.numeric(crossprod(b, Ainv %*% b))
  e <- yr_full - beta * dr_full
  sse <- as.numeric(crossprod(e))
  (explained / df_num) / (sse / df_den)
}

poly <- c(
  explained0 - f_crit * df_num / df_den * sse0,
  -2 * explained_cross + f_crit * df_num / df_den * 2 * sse_cross,
  explained1 - f_crit * df_num / df_den * sse1
)

roots <- polyroot(poly)
real_roots <- sort(Re(roots[abs(Im(roots)) < 1e-7]))

boundary_low <- real_roots[1]
boundary_high <- real_roots[length(real_roots)]

accepts_zero <- as.numeric(f_stat(0) <= f_crit)
unbounded <- as.numeric(poly[3] < 0)

num <- function(x) sprintf("%.15g", as.numeric(x))

json <- paste0(
  '{',
  '"task_id":"broad_ar_confidence_set",',
  '"platform":"r",',
  '"estimates":[',
  '{"term":"boundary_low","estimate":', num(boundary_low), ',"se":null,"n_obs":', n, '},',
  '{"term":"boundary_high","estimate":', num(boundary_high), ',"se":null,"n_obs":', n, '},',
  '{"term":"accepts_zero","estimate":', num(accepts_zero), ',"se":null,"n_obs":', n, '},',
  '{"term":"unbounded","estimate":', num(unbounded), ',"se":null,"n_obs":', n, '},',
  '{"term":"ar_f_at_one","estimate":', num(f_stat(1)), ',"se":null,"n_obs":', n, '}',
  '],',
  '"method_metadata":{',
  '"estimator":"Anderson-Rubin confidence set with conventional homoskedastic joint F test",',
  '"vcov":"homoskedastic"',
  '},',
  '"diagnostics":{}',
  '}'
)

writeLines(json, "result.json")
