dat <- read.csv("input.csv")

keep <- abs(dat$score) < 1
dat <- dat[keep, , drop = FALSE]

s <- dat$score
right <- as.numeric(s >= 0)
w <- 1 - abs(s)

X <- cbind(
  intercept = 1,
  discontinuity = right,
  score = s,
  right_score = right * s
)

fit_outcome <- function(y) {
  fit <- lm.wfit(x = X, y = y, w = w)
  beta <- fit$coefficients
  residuals <- fit$residuals

  bread <- solve(crossprod(X, w * X))
  meat <- crossprod(
    X,
    (w^2 * residuals^2) * X
  )
  vcov <- bread %*% meat %*% bread

  list(
    estimate = unname(beta[2]),
    variance = unname(vcov[2, 2]),
    residuals = residuals,
    bread = bread
  )
}

rf <- fit_outcome(dat$earnings)
fs <- fit_outcome(dat$participated)

cross_meat <- crossprod(
  X,
  (w^2 * rf$residuals * fs$residuals) * X
)
cross_vcov <- rf$bread %*% cross_meat %*% fs$bread
cov_rf_fs <- unname(cross_vcov[2, 2])

treatment_effect <- rf$estimate / fs$estimate
var_treatment_effect <-
  rf$variance / fs$estimate^2 +
  rf$estimate^2 * fs$variance / fs$estimate^4 -
  2 * rf$estimate * cov_rf_fs / fs$estimate^3

n_obs <- nrow(dat)

num <- function(x) {
  if (is.finite(x)) sprintf("%.15g", x) else "null"
}

result <- sprintf(
  paste0(
    '{\n',
    '  "task_id": "applied_fuzzy_rd",\n',
    '  "platform": "r",\n',
    '  "estimates": [\n',
    '    {"term": "treatment_effect", "estimate": %s, "se": %s, "n_obs": %d},\n',
    '    {"term": "reduced_form", "estimate": %s, "se": %s, "n_obs": %d},\n',
    '    {"term": "first_stage", "estimate": %s, "se": %s, "n_obs": %d}\n',
    '  ],\n',
    '  "method_metadata": {\n',
    '    "estimator": "Fuzzy local-linear regression discontinuity with triangular kernel weights and delta-method ratio",\n',
    '    "vcov": "HC0 heteroskedasticity-robust joint sandwich covariance with fixed bandwidth and weights"\n',
    '  },\n',
    '  "diagnostics": {}\n',
    '}\n'
  ),
  num(treatment_effect),
  num(sqrt(max(var_treatment_effect, 0))),
  n_obs,
  num(rf$estimate),
  num(sqrt(max(rf$variance, 0))),
  n_obs,
  num(fs$estimate),
  num(sqrt(max(fs$variance, 0))),
  n_obs
)

writeLines(result, "result.json")
