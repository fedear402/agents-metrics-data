library(jsonlite)

data <- read.csv("input.csv", stringsAsFactors = FALSE)
data <- data[order(as.Date(data$date)), ]

log_vix <- log(data$vix)
log_sales <- log(data$sales)
vol_change <- c(NA_real_, diff(log_vix))

lagged <- sapply(1:15, function(j) {
  c(rep(NA_real_, j), vol_change[1:(length(vol_change) - j)])
})
colnames(lagged) <- paste0("lag_", 1:15)

sample <- data.frame(log_sales = log_sales, lagged)
sample <- sample[complete.cases(sample), ]

X <- cbind("(Intercept)" = 1, as.matrix(sample[, paste0("lag_", 1:15)]))
y <- sample$log_sales
fit <- lm.fit(x = X, y = y)

beta <- fit$coefficients
resid <- fit$residuals
N <- nrow(X)
p <- ncol(X)

scores <- X * resid
meat <- crossprod(scores)

hac_lags <- 15
for (j in 1:hac_lags) {
  lag_product <- crossprod(
    scores[(j + 1):N, , drop = FALSE],
    scores[1:(N - j), , drop = FALSE]
  )
  weight <- 1 - j / 16
  meat <- meat + weight * (lag_product + t(lag_product))
}

bread <- solve(crossprod(X))
covariance <- N / (N - 16) * bread %*% meat %*% bread

contrast <- c(0, rep(1, 15))
cumulative <- sum(contrast * beta)
cumulative_se <- sqrt(drop(t(contrast) %*% covariance %*% contrast))

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(
      term = "cumulative_response",
      estimate = unname(as.numeric(cumulative)),
      se = unname(as.numeric(cumulative_se)),
      n_obs = as.integer(N)
    ),
    list(
      term = "lag_1",
      estimate = unname(as.numeric(beta[2])),
      se = unname(as.numeric(sqrt(covariance[2, 2]))),
      n_obs = as.integer(N)
    ),
    list(
      term = "lag_15",
      estimate = unname(as.numeric(beta[16])),
      se = unname(as.numeric(sqrt(covariance[16, 16]))),
      n_obs = as.integer(N)
    )
  ),
  method_metadata = list(
    estimator = "OLS",
    vcov = "Newey-West HAC, Bartlett maximum lag 15, N/(N-16) correction"
  ),
  diagnostics = list()
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  digits = 16,
  pretty = TRUE
)
