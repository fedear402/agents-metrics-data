#!/usr/bin/env Rscript

library(jsonlite)

data <- read.csv("input.csv", stringsAsFactors = FALSE)
data$date <- as.Date(data$date)
data <- data[order(data$date), ]

log_vix <- log(data$vix)
log_sales <- log(data$sales)
vix_change <- c(NA_real_, diff(log_vix))

N_total <- nrow(data)
usable_idx <- 17:N_total
N <- length(usable_idx)

y <- log_sales[usable_idx]
X <- cbind("(Intercept)" = 1, sapply(1:15, function(j) {
  vix_change[usable_idx - j]
}))
colnames(X) <- c("(Intercept)", paste0("lag_", 1:15))

coefficients <- solve(crossprod(X), crossprod(X, y))
residuals <- as.vector(y - X %*% coefficients)
scores <- X * residuals

hac_lags <- 15
meat <- crossprod(scores)

for (j in 1:hac_lags) {
  lag_product <- crossprod(
    scores[(j + 1):N, , drop = FALSE],
    scores[1:(N - j), , drop = FALSE]
  )
  weight <- 1 - j / 16
  meat <- meat + weight * (lag_product + t(lag_product))
}

bread <- solve(crossprod(X))
p <- ncol(X)
covariance <- N / (N - 16) * bread %*% meat %*% bread

contrast <- c(0, rep(1, 15))
cumulative_response <- sum(coefficients[2:16])
cumulative_se <- sqrt(drop(t(contrast) %*% covariance %*% contrast))

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(
      term = "cumulative_response",
      estimate = unname(as.numeric(cumulative_response)),
      se = unname(as.numeric(cumulative_se)),
      n_obs = as.integer(N)
    ),
    list(
      term = "lag_1",
      estimate = unname(as.numeric(coefficients[2])),
      se = unname(as.numeric(sqrt(covariance[2, 2]))),
      n_obs = as.integer(N)
    ),
    list(
      term = "lag_15",
      estimate = unname(as.numeric(coefficients[16])),
      se = unname(as.numeric(sqrt(covariance[16, 16]))),
      n_obs = as.integer(N)
    )
  ),
  method_metadata = list(
    estimator = "OLS with intercept and lags 1 through 15 of log volatility changes",
    vcov = "Bartlett Newey-West HAC covariance, maximum lag 15, correction N/(N-16)"
  ),
  diagnostics = list()
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
