#!/usr/bin/env Rscript

dat <- read.csv("input.csv", stringsAsFactors = FALSE)

dat <- dat[is.finite(dat$score) &
           is.finite(dat$participated) &
           is.finite(dat$earnings) &
           abs(dat$score) < 1, , drop = FALSE]

n_obs <- nrow(dat)

right <- as.numeric(dat$score >= 0)
x <- cbind(
  intercept = 1,
  right = right,
  score = dat$score,
  right_score = right * dat$score
)

w <- 1 - abs(dat$score)
W <- diag(w, nrow = n_obs)
bread <- solve(crossprod(x, W %*% x))

fit_wls <- function(y) {
  beta <- bread %*% crossprod(x, W %*% y)
  residuals <- as.numeric(y - x %*% beta)
  meat <- crossprod(x, (w^2 * residuals^2) * x)
  vcov <- bread %*% meat %*% bread
  list(beta = as.numeric(beta), residuals = residuals, vcov = vcov)
}

fit_earnings <- fit_wls(dat$earnings)
fit_participated <- fit_wls(dat$participated)

reduced_form <- fit_earnings$beta[2]
first_stage <- fit_participated$beta[2]
treatment_effect <- reduced_form / first_stage

var_reduced_form <- fit_earnings$vcov[2, 2]
var_first_stage <- fit_participated$vcov[2, 2]

cross_meat <- crossprod(
  x,
  (w^2 * fit_earnings$residuals * fit_participated$residuals) * x
)
cross_vcov <- bread %*% cross_meat %*% bread
cov_discontinuities <- cross_vcov[2, 2]

se_reduced_form <- sqrt(max(0, var_reduced_form))
se_first_stage <- sqrt(max(0, var_first_stage))

var_treatment_effect <- (
  var_reduced_form +
    treatment_effect^2 * var_first_stage -
    2 * treatment_effect * cov_discontinuities
) / first_stage^2

se_treatment_effect <- if (var_treatment_effect >= 0) {
  sqrt(var_treatment_effect)
} else {
  NA_real_
}

clean_num <- function(x) {
  if (length(x) == 0 || !is.finite(x)) NULL else as.numeric(x)
}

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(
      term = "treatment_effect",
      estimate = clean_num(treatment_effect),
      se = clean_num(se_treatment_effect),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "reduced_form",
      estimate = clean_num(reduced_form),
      se = clean_num(se_reduced_form),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "first_stage",
      estimate = clean_num(first_stage),
      se = clean_num(se_first_stage),
      n_obs = as.integer(n_obs)
    )
  ),
  method_metadata = list(
    estimator = "Fuzzy regression discontinuity with local-linear WLS and triangular weights",
    vcov = "Conventional heteroskedasticity-robust HC0; delta method with joint covariance"
  ),
  diagnostics = list()
)

if (requireNamespace("jsonlite", quietly = TRUE)) {
  jsonlite::write_json(
    result,
    "result.json",
    auto_unbox = TRUE,
    null = "null",
    digits = 17
  )
} else {
  esc <- function(x) {
    gsub('"', '\\"', x, fixed = TRUE)
  }
  num_json <- function(x) {
    if (is.null(x) || !is.finite(x)) "null" else formatC(x, format = "fg", digits = 17)
  }
  output <- paste0(
    '{',
    '"task_id":"applied_fuzzy_rd",',
    '"platform":"r",',
    '"estimates":[',
    '{"term":"treatment_effect","estimate":', num_json(treatment_effect),
    ',"se":', num_json(se_treatment_effect),
    ',"n_obs":', n_obs, '},',
    '{"term":"reduced_form","estimate":', num_json(reduced_form),
    ',"se":', num_json(se_reduced_form),
    ',"n_obs":', n_obs, '},',
    '{"term":"first_stage","estimate":', num_json(first_stage),
    ',"se":', num_json(se_first_stage),
    ',"n_obs":', n_obs, '}',
    '],',
    '"method_metadata":{',
    '"estimator":"Fuzzy regression discontinuity with local-linear WLS and triangular weights",',
    '"vcov":"Conventional heteroskedasticity-robust HC0; delta method with joint covariance"',
    '},',
    '"diagnostics":{}',
    '}'
  )
  writeLines(output, "result.json")
}
