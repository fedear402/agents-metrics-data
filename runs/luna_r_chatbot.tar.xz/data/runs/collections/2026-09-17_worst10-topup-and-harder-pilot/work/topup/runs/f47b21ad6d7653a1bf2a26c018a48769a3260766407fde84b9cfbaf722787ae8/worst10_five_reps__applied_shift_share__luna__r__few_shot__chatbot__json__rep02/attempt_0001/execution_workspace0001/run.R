library(jsonlite)

dat <- read.csv("input.csv", stringsAsFactors = FALSE)

regions <- unique(dat$region_id)
industries <- unique(dat$industry_id)

region_data <- do.call(rbind, lapply(regions, function(r) {
  d <- dat[dat$region_id == r, ]
  data.frame(
    region_id = r,
    region_weight = d$region_weight[1],
    x = d$x[1],
    y = d$y[1],
    z = sum(d$share * d$shock)
  )
}))

e <- region_data$region_weight / sum(region_data$region_weight)

center_weighted <- function(v) {
  v - sum(e * v)
}

y0 <- center_weighted(region_data$y)
x0 <- center_weighted(region_data$x)
z0 <- center_weighted(region_data$z)

industry_data <- do.call(rbind, lapply(industries, function(n) {
  d <- dat[dat$industry_id == n, ]
  matched <- match(d$region_id, region_data$region_id)
  weights <- e[matched] * d$share
  s_n <- sum(weights)

  if (s_n <= 0) {
    return(NULL)
  }

  data.frame(
    industry_id = n,
    shock = d$shock[1],
    s = s_n,
    ybar = sum(weights * y0[matched]) / s_n,
    xbar = sum(weights * x0[matched]) / s_n,
    zbar = sum(weights * z0[matched]) / s_n
  )
}))

industry_data <- industry_data[is.finite(industry_data$s) & industry_data$s > 0, ]
N <- nrow(industry_data)

shock_iv <- function(dependent, endogenous) {
  X <- cbind(1, endogenous)
  Q <- cbind(1, industry_data$shock)
  W <- industry_data$s

  cross <- crossprod(Q, W * X)
  beta <- solve(cross, crossprod(Q, W * dependent))

  residual <- drop(dependent - X %*% beta)
  scores <- Q * (W * residual)
  inverse <- solve(cross)

  covariance <- (N / (N - 2)) *
    inverse %*% crossprod(scores) %*% t(inverse)

  c(estimate = beta[2], se = sqrt(covariance[2, 2]))
}

effect <- shock_iv(industry_data$ybar, industry_data$xbar)
first_stage <- shock_iv(industry_data$xbar, industry_data$zbar)
effective_shocks <- 1 / sum(industry_data$s^2)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(
      term = "effect",
      estimate = unname(as.numeric(effect["estimate"])),
      se = unname(as.numeric(effect["se"])),
      n_obs = as.integer(N)
    ),
    list(
      term = "first_stage",
      estimate = unname(as.numeric(first_stage["estimate"])),
      se = unname(as.numeric(first_stage["se"])),
      n_obs = as.integer(N)
    ),
    list(
      term = "effective_shocks",
      estimate = as.numeric(effective_shocks),
      se = NULL,
      n_obs = as.integer(N)
    )
  ),
  method_metadata = list(
    estimator = "Shock-level weighted IV with intercept",
    vcov = "HC1 exposure-robust covariance using structural IV residuals"
  ),
  diagnostics = list()
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
