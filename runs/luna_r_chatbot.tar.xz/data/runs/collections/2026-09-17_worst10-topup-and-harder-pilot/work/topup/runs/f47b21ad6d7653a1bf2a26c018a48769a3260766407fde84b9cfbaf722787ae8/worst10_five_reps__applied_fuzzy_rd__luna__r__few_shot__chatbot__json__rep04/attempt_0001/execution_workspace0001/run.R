library(jsonlite)

dat <- read.csv("input.csv")

keep <- abs(dat$score) < 1
dat <- dat[keep, ]

s <- dat$score
w <- 1 - abs(s)

left <- s < 0
right <- s >= 0

X <- cbind(
  left_intercept = as.numeric(left),
  left_slope = s * as.numeric(left),
  right_intercept = as.numeric(right),
  right_slope = s * as.numeric(right)
)

bread <- solve(crossprod(X, w * X))
contrast <- c(-1, 0, 1, 0)

estimate_and_influence <- function(y) {
  beta <- bread %*% crossprod(X, w * y)
  residuals <- y - drop(X %*% beta)
  discontinuity <- drop(t(contrast) %*% beta)
  loading <- w * drop(X %*% bread %*% contrast)
  influence <- loading * residuals
  list(estimate = discontinuity, influence = influence)
}

earnings_fit <- estimate_and_influence(dat$earnings)
participation_fit <- estimate_and_influence(dat$participated)

joint_covariance <- crossprod(
  cbind(earnings_fit$influence, participation_fit$influence)
)

reduced_form <- earnings_fit$estimate
first_stage <- participation_fit$estimate

gradient <- c(
  1 / first_stage,
  -reduced_form / first_stage^2
)

treatment_effect <- reduced_form / first_stage
treatment_se <- sqrt(drop(t(gradient) %*% joint_covariance %*% gradient))

n_obs <- nrow(dat)

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(
      term = "treatment_effect",
      estimate = unname(as.numeric(treatment_effect)),
      se = unname(as.numeric(treatment_se)),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "reduced_form",
      estimate = unname(as.numeric(reduced_form)),
      se = unname(as.numeric(sqrt(joint_covariance[1, 1]))),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "first_stage",
      estimate = unname(as.numeric(first_stage)),
      se = unname(as.numeric(sqrt(joint_covariance[2, 2]))),
      n_obs = as.integer(n_obs)
    )
  ),
  method_metadata = list(
    estimator = "fuzzy local-linear regression discontinuity with triangular weights",
    vcov = "conventional heteroskedasticity-robust HC0 with delta-method treatment-effect standard error"
  ),
  diagnostics = list()
)

writeLines(
  toJSON(result, auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE),
  "result.json"
)
