#!/usr/bin/env Rscript

dat <- read.csv("input.csv", stringsAsFactors = FALSE)

y <- dat$y
X <- cbind(const = 1, x = dat$x, z = dat$z)
n <- nrow(dat)
censored <- y <= 0

loglik <- function(par) {
  beta <- par[1:3]
  sigma <- exp(par[4])
  mu <- drop(X %*% beta)

  ll <- numeric(n)

  if (any(censored)) {
    ll[censored] <- pnorm(
      -mu[censored] / sigma,
      log.p = TRUE
    )
  }

  if (any(!censored)) {
    ll[!censored] <- dnorm(
      y[!censored],
      mean = mu[!censored],
      sd = sigma,
      log = TRUE
    )
  }

  if (any(!is.finite(ll))) return(-Inf)
  sum(ll)
}

beta_start <- tryCatch(
  coef(lm(y ~ x + z, data = dat)),
  error = function(e) c("(Intercept)" = mean(y), x = 0, z = 0)
)

beta_start <- as.numeric(beta_start)
if (length(beta_start) != 3 || any(!is.finite(beta_start))) {
  beta_start <- c(mean(y), 0, 0)
}

sigma_start <- sd(y)
if (!is.finite(sigma_start) || sigma_start <= 0) {
  sigma_start <- 1
}

start <- c(beta_start, log(sigma_start))

fit <- optim(
  par = start,
  fn = function(par) -loglik(par),
  method = "BFGS",
  hessian = TRUE,
  control = list(maxit = 10000, reltol = 1e-12)
)

if (fit$convergence != 0 || any(!is.finite(fit$par))) {
  fit <- optim(
    par = start,
    fn = function(par) -loglik(par),
    method = "Nelder-Mead",
    control = list(maxit = 20000, reltol = 1e-12)
  )

  fit <- optim(
    par = fit$par,
    fn = function(par) -loglik(par),
    method = "BFGS",
    hessian = TRUE,
    control = list(maxit = 10000, reltol = 1e-12)
  )
}

par_hat <- fit$par
beta_hat <- par_hat[1:3]
sigma_hat <- exp(par_hat[4])

vcov_par <- tryCatch(
  solve(fit$hessian),
  error = function(e) qr.solve(fit$hessian)
)

se_beta <- sqrt(pmax(diag(vcov_par)[1:3], 0))

num <- function(x) {
  formatC(as.numeric(x), format = "fg", digits = 15)
}

result <- sprintf(
  paste0(
    '{',
    '"task_id":"broad_tobit",',
    '"platform":"r",',
    '"estimates":[',
    '{"term":"const","estimate":%s,"se":%s,"n_obs":%d},',
    '{"term":"x","estimate":%s,"se":%s,"n_obs":%d},',
    '{"term":"z","estimate":%s,"se":%s,"n_obs":%d},',
    '{"term":"sigma","estimate":%s,"se":null,"n_obs":%d}',
    '],',
    '"method_metadata":{',
    '"estimator":"Homoskedastic Gaussian Tobit maximum likelihood",',
    '"vcov":"Inverse observed information from the joint likelihood Hessian"',
    '},',
    '"diagnostics":{}',
    '}'
  ),
  num(beta_hat[1]), num(se_beta[1]), n,
  num(beta_hat[2]), num(se_beta[2]), n,
  num(beta_hat[3]), num(se_beta[3]), n,
  num(sigma_hat), n
)

writeLines(result, "result.json")
