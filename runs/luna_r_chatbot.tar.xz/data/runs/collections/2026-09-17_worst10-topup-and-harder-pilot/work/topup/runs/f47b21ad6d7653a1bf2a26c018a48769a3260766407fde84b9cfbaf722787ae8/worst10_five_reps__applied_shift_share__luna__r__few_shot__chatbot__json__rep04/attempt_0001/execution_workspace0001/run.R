library(jsonlite)

dat <- read.csv("input.csv", stringsAsFactors = FALSE)

regions <- unique(dat$region_id)
industries <- unique(dat$industry_id)

region_data <- do.call(rbind, lapply(regions, function(r) {
  d <- dat[dat$region_id == r, ]
  data.frame(
    region_id = r,
    x = d$x[1],
    y = d$y[1],
    region_weight = d$region_weight[1],
    stringsAsFactors = FALSE
  )
}))

e <- region_data$region_weight / sum(region_data$region_weight)

shares <- matrix(
  0,
  nrow = length(regions),
  ncol = length(industries),
  dimnames = list(as.character(regions), as.character(industries))
)

for (i in seq_len(nrow(dat))) {
  shares[as.character(dat$region_id[i]), as.character(dat$industry_id[i])] <-
    dat$share[i]
}

shock <- sapply(industries, function(n) {
  unique(dat$shock[dat$industry_id == n])[1]
})

z <- drop(shares %*% shock)

weighted_mean <- function(v) sum(e * v)

y0 <- region_data$y - weighted_mean(region_data$y)
x0 <- region_data$x - weighted_mean(region_data$x)
z0 <- z - weighted_mean(z)

s <- drop(t(shares) %*% e)

aggregate_exposure <- function(v0) {
  drop(t(shares) %*% (e * v0)) / s
}

ybar <- aggregate_exposure(y0)
xbar <- aggregate_exposure(x0)
zbar <- aggregate_exposure(z0)

shock_iv <- function(dependent, endogenous, instrument, weights) {
  regressors <- cbind(1, endogenous)
  instruments <- cbind(1, instrument)

  cross <- crossprod(instruments, weights * regressors)
  beta <- solve(
    cross,
    crossprod(instruments, weights * dependent)
  )

  residual <- drop(dependent - regressors %*% beta)
  scores <- instruments * (weights * residual)
  inverse <- solve(cross)

  n <- length(dependent)
  covariance <- n / (n - 2) *
    inverse %*% crossprod(scores) %*% t(inverse)

  c(
    estimate = beta[2],
    se = sqrt(covariance[2, 2])
  )
}

effect_fit <- shock_iv(ybar, xbar, shock, s)
first_stage_fit <- shock_iv(xbar, zbar, shock, s)

effective_shocks <- 1 / sum(s^2)
n_industries <- length(industries)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(
      term = "effect",
      estimate = unname(effect_fit["estimate"]),
      se = unname(effect_fit["se"]),
      n_obs = n_industries
    ),
    list(
      term = "first_stage",
      estimate = unname(first_stage_fit["estimate"]),
      se = unname(first_stage_fit["se"]),
      n_obs = n_industries
    ),
    list(
      term = "effective_shocks",
      estimate = effective_shocks,
      se = NULL,
      n_obs = n_industries
    )
  ),
  method_metadata = list(
    estimator = "Weighted shock-level IV with intercept",
    vcov = "Exposure-robust HC1, multiplier N/(N-2), structural IV residuals"
  ),
  diagnostics = list()
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
