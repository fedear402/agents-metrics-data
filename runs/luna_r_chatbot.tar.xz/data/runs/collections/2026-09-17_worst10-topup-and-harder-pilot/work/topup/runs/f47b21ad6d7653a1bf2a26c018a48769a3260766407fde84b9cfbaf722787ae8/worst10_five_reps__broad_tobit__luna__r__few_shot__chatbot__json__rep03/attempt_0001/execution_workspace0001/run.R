d <- read.csv("input.csv")

n_obs <- nrow(d)

fit <- survival::survreg(
  survival::Surv(y, y > 0, type = "left") ~ x + z,
  data = d,
  dist = "gaussian",
  control = survival::survreg.control(rel.tolerance = 1e-12)
)

V <- stats::vcov(fit)

estimates <- list(
  list(
    term = "const",
    estimate = unname(stats::coef(fit)["(Intercept)"]),
    se = sqrt(V["(Intercept)", "(Intercept)"]),
    n_obs = n_obs
  ),
  list(
    term = "x",
    estimate = unname(stats::coef(fit)["x"]),
    se = sqrt(V["x", "x"]),
    n_obs = n_obs
  ),
  list(
    term = "z",
    estimate = unname(stats::coef(fit)["z"]),
    se = sqrt(V["z", "z"]),
    n_obs = n_obs
  ),
  list(
    term = "sigma",
    estimate = unname(fit$scale),
    se = NULL,
    n_obs = n_obs
  )
)

result <- list(
  task_id = "broad_tobit",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "Gaussian Tobit maximum likelihood with left censoring at zero",
    vcov = "Observed information covariance from jointly estimated beta and log(sigma)"
  ),
  diagnostics = list()
)

jsonlite::write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
