df <- read.csv("input.csv")

keep <- abs(df$score) < 1
d <- df[keep, , drop = FALSE]

x <- d$score
right <- as.numeric(x >= 0)
w <- 1 - abs(x)

X <- cbind(
  intercept = 1,
  score = x,
  right = right,
  score_right = x * right
)

W <- diag(w)
bread <- solve(crossprod(X, W %*% X))
contrast <- c(0, 0, 1, 0)

Y <- cbind(
  earnings = d$earnings,
  participated = d$participated
)

beta <- bread %*% crossprod(X, W %*% Y)
resid <- Y - X %*% beta

discontinuities <- drop(crossprod(contrast, beta))

loading <- drop(X %*% bread %*% contrast)
influence <- loading * resid

joint_covariance <- crossprod(influence)

reduced_form <- discontinuities[1]
first_stage <- discontinuities[2]
treatment_effect <- reduced_form / first_stage

gradient <- c(
  1 / first_stage,
  -reduced_form / first_stage^2
)

treatment_var <- drop(
  t(gradient) %*% joint_covariance %*% gradient
)

n_obs <- nrow(d)

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(
      term = "treatment_effect",
      estimate = unname(as.numeric(treatment_effect)),
      se = unname(as.numeric(sqrt(treatment_var))),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "reduced_form",
      estimate = unname(as.numeric(reduced_form)),
      se = unname(as.numeric(sqrt(joint_covariance[1, 1]))),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "first_stage",
      estimate = unname(as.numeric(first_stage)),
      se = unname(as.numeric(sqrt(joint_covariance[2, 2]))),
      n_obs = as.integer(n_obs)
    )
  ),
  method_metadata = list(
    estimator = "Weighted local-linear fuzzy regression discontinuity",
    vcov = "Conventional heteroskedasticity-robust HC0 with fixed triangular weights"
  ),
  diagnostics = list()
)

jsonlite::write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  digits = 16,
  pretty = TRUE,
  null = "null"
)
