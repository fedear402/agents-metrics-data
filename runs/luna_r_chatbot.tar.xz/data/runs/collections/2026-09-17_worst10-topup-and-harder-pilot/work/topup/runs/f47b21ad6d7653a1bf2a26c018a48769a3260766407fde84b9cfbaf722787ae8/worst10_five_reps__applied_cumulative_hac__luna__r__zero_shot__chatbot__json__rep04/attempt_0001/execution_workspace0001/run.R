dat <- read.csv("input.csv", stringsAsFactors = FALSE)

dat$date_order <- as.Date(dat$date)
dat <- dat[order(dat$date_order), ]

dlog_vix <- diff(log(dat$vix))
log_sales <- log(dat$sales)

n_total <- nrow(dat)
max_lag <- 15L
idx <- seq.int(max_lag + 1L, n_total)

y <- log_sales[idx]
X <- cbind(
  intercept = 1,
  sapply(seq_len(max_lag), function(l) dlog_vix[idx - l])
)
colnames(X) <- c("intercept", paste0("lag_", seq_len(max_lag)))

fit <- lm.fit(x = X, y = y)
beta <- as.numeric(fit$coefficients)
names(beta) <- colnames(X)

resid <- as.numeric(y - X %*% beta)
n_obs <- nrow(X)
k <- ncol(X)

bread <- solve(crossprod(X))
meat <- matrix(0, nrow = k, ncol = k)

for (j in 0:max_lag) {
  weight <- 1 - j / (max_lag + 1)
  
  if (j == 0) {
    z <- X * resid
    meat <- meat + crossprod(z)
  } else {
    z_current <- X[(j + 1):n_obs, , drop = FALSE] *
      resid[(j + 1):n_obs]
    z_lagged <- X[1:(n_obs - j), , drop = FALSE] *
      resid[1:(n_obs - j)]
    
    gamma_j <- crossprod(z_current, z_lagged)
    meat <- meat + weight * (gamma_j + t(gamma_j))
  }
}

vcov_hac <- bread %*% meat %*% bread
vcov_hac <- vcov_hac * n_obs / (n_obs - 16)

cum_vector <- c(0, rep(1, max_lag))
cum_estimate <- sum(beta[paste0("lag_", seq_len(max_lag))])
cum_se <- sqrt(as.numeric(t(cum_vector) %*% vcov_hac %*% cum_vector))

lag1_index <- match("lag_1", colnames(X))
lag15_index <- match("lag_15", colnames(X))

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(
      term = "cumulative_response",
      estimate = unname(cum_estimate),
      se = unname(cum_se),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "lag_1",
      estimate = unname(beta[lag1_index]),
      se = unname(sqrt(vcov_hac[lag1_index, lag1_index])),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "lag_15",
      estimate = unname(beta[lag15_index]),
      se = unname(sqrt(vcov_hac[lag15_index, lag15_index])),
      n_obs = as.integer(n_obs)
    )
  ),
  method_metadata = list(
    estimator = "OLS with intercept and lags 1 through 15 of first-differenced log volatility",
    vcov = "Newey-West HAC covariance, maximum lag 15, Bartlett weights, scaled by N/(N-16)"
  ),
  diagnostics = list()
)

if (requireNamespace("jsonlite", quietly = TRUE)) {
  jsonlite::write_json(
    result,
    "result.json",
    auto_unbox = TRUE,
    digits = 16,
    pretty = TRUE
  )
} else {
  stop("The jsonlite package is required.")
}
