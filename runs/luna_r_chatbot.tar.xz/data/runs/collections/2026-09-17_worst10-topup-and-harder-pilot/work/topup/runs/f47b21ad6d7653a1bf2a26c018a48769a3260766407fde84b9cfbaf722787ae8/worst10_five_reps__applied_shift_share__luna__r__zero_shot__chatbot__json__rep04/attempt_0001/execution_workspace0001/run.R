dat <- read.csv("input.csv", stringsAsFactors = FALSE)

regions <- unique(dat$region_id)
industries <- unique(dat$industry_id)

region_data <- dat[match(regions, dat$region_id), ]
e <- region_data$region_weight / sum(region_data$region_weight)

y <- region_data$y
x <- region_data$x
z <- numeric(length(regions))

for (i in seq_along(regions)) {
  rows <- dat$region_id == regions[i]
  z[i] <- sum(dat$share[rows] * dat$shock[rows])
}

weighted_mean <- function(v, w) {
  sum(w * v) / sum(w)
}

y0 <- y - weighted_mean(y, e)
x0 <- x - weighted_mean(x, e)
z0 <- z - weighted_mean(z, e)

shock_rows <- vector("list", length(industries))

for (j in seq_along(industries)) {
  rows <- dat$industry_id == industries[j]
  share_j <- dat$share[rows]
  regions_j <- match(dat$region_id[rows], regions)
  weights_j <- e[regions_j] * share_j
  s_j <- sum(weights_j)

  if (s_j > 0) {
    shock_rows[[j]] <- data.frame(
      industry_id = industries[j],
      shock = dat$shock[which(rows)[1]],
      s = s_j,
      ybar = sum(weights_j * y0[regions_j]) / s_j,
      xbar = sum(weights_j * x0[regions_j]) / s_j,
      zbar = sum(weights_j * z0[regions_j]) / s_j
    )
  }
}

shock_data <- do.call(rbind, shock_rows)
rownames(shock_data) <- NULL

iv_hc1 <- function(y, endogenous, instrument, weights) {
  n <- length(y)
  X <- cbind(1, endogenous)
  Z <- cbind(1, instrument)
  W <- diag(weights, nrow = n, ncol = n)

  ZWZ_inv <- solve(crossprod(Z, W %*% Z))
  PZX <- Z %*% ZWZ_inv %*% crossprod(Z, W %*% X)
  PZY <- Z %*% ZWZ_inv %*% crossprod(Z, W %*% y)

  bread <- crossprod(PZX, W %*% PZX)
  beta <- solve(bread, crossprod(PZX, W %*% y))

  residuals <- as.vector(y - X %*% beta)
  meat <- matrix(0, nrow = 2, ncol = 2)

  for (i in seq_len(n)) {
    xi <- matrix(PZX[i, ], ncol = 1)
    meat <- meat + weights[i]^2 * residuals[i]^2 * (xi %*% t(xi))
  }

  vcov <- solve(bread) %*% meat %*% solve(bread)
  vcov <- vcov * n / (n - 2)

  list(
    estimate = unname(beta[2]),
    se = sqrt(unname(vcov[2, 2]))
  )
}

n_industries <- nrow(shock_data)

effect_fit <- iv_hc1(
  y = shock_data$ybar,
  endogenous = shock_data$xbar,
  instrument = shock_data$shock,
  weights = shock_data$s
)

first_stage_fit <- iv_hc1(
  y = shock_data$xbar,
  endogenous = shock_data$zbar,
  instrument = shock_data$shock,
  weights = shock_data$s
)

effective_shocks <- 1 / sum(shock_data$s^2)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(
      term = "effect",
      estimate = effect_fit$estimate,
      se = effect_fit$se,
      n_obs = n_industries
    ),
    list(
      term = "first_stage",
      estimate = first_stage_fit$estimate,
      se = first_stage_fit$se,
      n_obs = n_industries
    ),
    list(
      term = "effective_shocks",
      estimate = effective_shocks,
      se = NULL,
      n_obs = n_industries
    )
  ),
  method_metadata = list(
    estimator = "Borusyak-Hull-Jaravel shock-level weighted 2SLS",
    vcov = "Shock-level heteroskedasticity-robust HC1 with N/(N-2) multiplier"
  ),
  diagnostics = list()
)

if (requireNamespace("jsonlite", quietly = TRUE)) {
  jsonlite::write_json(
    result,
    "result.json",
    auto_unbox = TRUE,
    null = "null",
    digits = 15
  )
} else {
  esc <- function(x) {
    if (is.null(x)) return("null")
    format(x, scientific = FALSE, digits = 15, trim = TRUE)
  }

  output <- paste0(
    '{',
    '"task_id":"applied_shift_share",',
    '"platform":"r",',
    '"estimates":[',
    '{"term":"effect","estimate":', esc(effect_fit$estimate),
    ',"se":', esc(effect_fit$se),
    ',"n_obs":', n_industries, '},',
    '{"term":"first_stage","estimate":', esc(first_stage_fit$estimate),
    ',"se":', esc(first_stage_fit$se),
    ',"n_obs":', n_industries, '},',
    '{"term":"effective_shocks","estimate":', esc(effective_shocks),
    ',"se":null,"n_obs":', n_industries, '}',
    '],',
    '"method_metadata":{"estimator":"Borusyak-Hull-Jaravel shock-level weighted 2SLS",',
    '"vcov":"Shock-level heteroskedasticity-robust HC1 with N/(N-2) multiplier"},',
    '"diagnostics":{}',
    '}'
  )

  writeLines(output, "result.json")
}
