df <- read.csv("input.csv", stringsAsFactors = FALSE)

df$date_parsed <- as.Date(df$date)
df <- df[order(df$date_parsed, df$date), ]

log_vix <- log(df$vix)
log_sales <- log(df$sales)
delta_vix <- diff(log_vix)

m <- nrow(df)
idx <- 17:m
n_obs <- length(idx)

y <- log_sales[idx]
X <- cbind(
  intercept = 1,
  sapply(1:15, function(j) delta_vix[idx - j])
)
colnames(X) <- c("intercept", paste0("lag_", 1:15))

beta <- solve(crossprod(X), crossprod(X, y))
resid <- as.vector(y - X %*% beta)

bread <- solve(crossprod(X))
scores <- X * resid

meat <- crossprod(scores)

for (j in 1:15) {
  weight <- 1 - j / 16
  gamma_j <- crossprod(scores[(j + 1):n_obs, , drop = FALSE],
                       scores[1:(n_obs - j), , drop = FALSE])
  meat <- meat + weight * (gamma_j + t(gamma_j))
}

vcov_nw <- bread %*% meat %*% bread
vcov_nw <- vcov_nw * n_obs / (n_obs - 16)
se_beta <- sqrt(diag(vcov_nw))

cum_idx <- 2:16
cum_est <- sum(beta[cum_idx])
cum_var <- sum(vcov_nw[cum_idx, cum_idx])
cum_se <- sqrt(cum_var)

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(
      term = "cumulative_response",
      estimate = unname(cum_est),
      se = unname(cum_se),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "lag_1",
      estimate = unname(beta["lag_1"]),
      se = unname(se_beta["lag_1"]),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "lag_15",
      estimate = unname(beta["lag_15"]),
      se = unname(se_beta["lag_15"]),
      n_obs = as.integer(n_obs)
    )
  ),
  method_metadata = list(
    estimator = "OLS with intercept and lags 1 through 15 of first-differenced log(vix)",
    vcov = "Newey-West HAC, maximum lag 15, Bartlett weights, scaled by N/(N-16)"
  ),
  diagnostics = list()
)

if (requireNamespace("jsonlite", quietly = TRUE)) {
  jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = 17)
} else {
  num <- function(x) format(x, digits = 17, scientific = TRUE)
  esc <- function(x) gsub('"', '\\"', x, fixed = TRUE)
  lines <- c(
    "{",
    '  "task_id": "applied_cumulative_hac",',
    '  "platform": "r",',
    '  "estimates": [',
    sprintf('    {"term": "cumulative_response", "estimate": %s, "se": %s, "n_obs": %d},',
            num(cum_est), num(cum_se), n_obs),
    sprintf('    {"term": "lag_1", "estimate": %s, "se": %s, "n_obs": %d},',
            num(beta["lag_1"]), num(se_beta["lag_1"]), n_obs),
    sprintf('    {"term": "lag_15", "estimate": %s, "se": %s, "n_obs": %d}',
            num(beta["lag_15"]), num(se_beta["lag_15"]), n_obs),
    "  ],",
    '  "method_metadata": {"estimator": "OLS with intercept and lags 1 through 15 of first-differenced log(vix)", "vcov": "Newey-West HAC, maximum lag 15, Bartlett weights, scaled by N/(N-16)"},',
    '  "diagnostics": {}',
    "}"
  )
  writeLines(lines, "result.json")
}
