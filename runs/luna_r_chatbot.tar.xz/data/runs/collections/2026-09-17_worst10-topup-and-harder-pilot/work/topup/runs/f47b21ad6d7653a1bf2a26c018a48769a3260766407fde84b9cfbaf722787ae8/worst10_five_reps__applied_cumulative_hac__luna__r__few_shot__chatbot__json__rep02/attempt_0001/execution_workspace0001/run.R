library(jsonlite)

data <- read.csv("input.csv", stringsAsFactors = FALSE)
data$date <- as.Date(data$date)
data <- data[order(data$date), ]

log_vix <- log(data$vix)
vol_change <- c(NA_real_, diff(log_vix))

lagged_changes <- sapply(
  1:15,
  function(j) c(rep(NA_real_, j), vol_change[seq_len(length(vol_change) - j)])
)
colnames(lagged_changes) <- paste0("lag_", 1:15)

log_sales <- log(data$sales)
complete <- complete.cases(log_sales, lagged_changes)

y <- log_sales[complete]
X <- cbind("(Intercept)" = 1, lagged_changes[complete, , drop = FALSE])

N <- nrow(X)
p <- ncol(X)

beta <- solve(crossprod(X), crossprod(X, y))
residuals <- y - X %*% beta
scores <- X * as.vector(residuals)

meat <- crossprod(scores)
hac_lags <- 15

for (j in seq_len(hac_lags)) {
  lag_product <- crossprod(
    scores[(j + 1):N, , drop = FALSE],
    scores[1:(N - j), , drop = FALSE]
  )
  weight <- 1 - j / 16
  meat <- meat + weight * (lag_product + t(lag_product))
}

bread <- solve(crossprod(X))
covariance <- (N / (N - 16)) * bread %*% meat %*% bread

contrast <- c(0, rep(1, 15))
cumulative_response <- sum(contrast * beta)
cumulative_se <- sqrt(drop(t(contrast) %*% covariance %*% contrast))

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(
      term = "cumulative_response",
      estimate = as.numeric(cumulative_response),
      se = as.numeric(cumulative_se),
      n_obs = as.integer(N)
    ),
    list(
      term = "lag_1",
      estimate = as.numeric(beta[2]),
      se = as.numeric(sqrt(covariance[2, 2])),
      n_obs = as.integer(N)
    ),
    list(
      term = "lag_15",
      estimate = as.numeric(beta[16]),
      se = as.numeric(sqrt(covariance[16, 16])),
      n_obs = as.integer(N)
    )
  ),
  method_metadata = list(
    estimator = "OLS with intercept and 15 lagged log volatility changes",
    vcov = "Bartlett Newey-West HAC, maximum lag 15, correction N/(N-16)"
  ),
  diagnostics = list()
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
