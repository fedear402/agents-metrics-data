#!/usr/bin/env Rscript

dat <- read.csv("input.csv")
y <- as.integer(dat$y)
X <- as.matrix(dat[, c("x", "z")])
n <- nrow(dat)

logdiffexp <- function(a, b) {
  d <- b - a
  a + log1p(-exp(d))
}

negloglik <- function(par) {
  beta <- par[1:2]
  c1 <- par[3]
  c2 <- c1 + exp(par[4])
  eta <- drop(X %*% beta)

  lp1 <- plogis(c1 - eta, log.p = TRUE)
  lp2 <- logdiffexp(
    plogis(c2 - eta, log.p = TRUE),
    plogis(c1 - eta, log.p = TRUE)
  )
  lp3 <- plogis(eta - c2, log.p = TRUE)

  lp <- ifelse(y == 1L, lp1, ifelse(y == 2L, lp2, lp3))
  if (any(!is.finite(lp))) return(1e100)
  -sum(lp)
}

tab <- table(y)
p1 <- max(0.01, min(0.98, as.numeric(tab["1"] %||% 0) / n))
p2 <- max(0.01, min(0.98, as.numeric(tab["2"] %||% 0) / n))
start <- c(
  0,
  0,
  qlogis(p1),
  log(max(0.1, qlogis(p1 + p2) - qlogis(p1)))
)

fit <- optim(
  par = start,
  fn = negloglik,
  method = "BFGS",
  hessian = TRUE,
  control = list(maxit = 10000, reltol = 1e-12)
)

if (fit$convergence != 0) {
  fit <- optim(
    par = fit$par,
    fn = negloglik,
    method = "BFGS",
    hessian = TRUE,
    control = list(maxit = 10000, reltol = 1e-10)
  )
}

V <- solve(fit$hessian)
beta_hat <- fit$par[1:2]
se_beta <- sqrt(pmax(0, diag(V)[1:2]))

c2_hat <- fit$par[3] + exp(fit$par[4])
eta_high <- sum(beta_hat * c(1, 0))
prob_high <- plogis(eta_high - c2_hat)

g <- c(1, 0, 0, -exp(fit$par[4]))
se_prob_high <- sqrt(as.numeric(t(g) %*% V %*% g))

fmt <- function(x) sprintf("%.15g", as.numeric(x))

json <- paste0(
  "{\n",
  '  "task_id": "broad_ordered_logit",\n',
  '  "platform": "r",\n',
  '  "estimates": [\n',
  '    {"term": "x", "estimate": ', fmt(beta_hat[1]),
  ', "se": ', fmt(se_beta[1]), ', "n_obs": ', n, "},\n",
  '    {"term": "z", "estimate": ', fmt(beta_hat[2]),
  ', "se": ', fmt(se_beta[2]), ', "n_obs": ', n, "},\n",
  '    {"term": "prob_high", "estimate": ', fmt(prob_high),
  ', "se": null, "n_obs": ', n, "}\n',
  "  ],\n",
  '  "method_metadata": {"estimator": "maximum likelihood ordered logit", "vcov": "conventional observed information"},',
  "\n  \"diagnostics\": {}\n",
  "}\n"
)

writeLines(json, "result.json")
