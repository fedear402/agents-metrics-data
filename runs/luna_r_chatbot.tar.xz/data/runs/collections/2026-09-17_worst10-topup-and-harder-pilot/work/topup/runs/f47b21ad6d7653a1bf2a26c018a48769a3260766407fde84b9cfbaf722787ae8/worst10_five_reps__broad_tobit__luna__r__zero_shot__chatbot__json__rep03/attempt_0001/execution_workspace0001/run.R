dat <- read.csv("input.csv")

y <- dat$y
x <- dat$x
z <- dat$z
n <- nrow(dat)

X <- cbind(const = 1, x = x, z = z)
uncensored <- y > 0

loglik <- function(par) {
  beta <- par[1:3]
  sigma <- exp(par[4])
  mu <- drop(X %*% beta)

  ll_unc <- dnorm(y[uncensored], mean = mu[uncensored],
                  sd = sigma, log = TRUE)

  a <- (0 - mu[!uncensored]) / sigma
  ll_cens <- pnorm(a, log.p = TRUE)

  sum(ll_unc) + sum(ll_cens)
}

neg_loglik <- function(par) -loglik(par)

ols_fit <- lm(y ~ x + z, data = dat)
beta_start <- coef(ols_fit)
beta_start[is.na(beta_start)] <- 0
sigma_start <- sd(residuals(ols_fit))
if (!is.finite(sigma_start) || sigma_start <= 0) {
  sigma_start <- sd(y[y > 0])
}
if (!is.finite(sigma_start) || sigma_start <= 0) {
  sigma_start <- 1
}

start <- c(beta_start, log(sigma_start))

fit <- optim(
  par = start,
  fn = neg_loglik,
  method = "BFGS",
  hessian = TRUE,
  control = list(maxit = 10000, reltol = 1e-12)
)

theta_hat <- fit$par
beta_hat <- theta_hat[1:3]
sigma_hat <- exp(theta_hat[4])

V_theta <- solve(fit$hessian)
se_beta <- sqrt(pmax(diag(V_theta)[1:3], 0))

fmt <- function(value) {
  if (!is.finite(value)) "null" else formatC(value, format = "fg", digits = 15)
}

json <- paste0(
  "{\n",
  '  "task_id": "broad_tobit",\n',
  '  "platform": "r",\n',
  '  "estimates": [\n',
  '    {"term": "const", "estimate": ', fmt(beta_hat[1]),
  ', "se": ', fmt(se_beta[1]), ', "n_obs": ', n, "},\n",
  '    {"term": "x", "estimate": ', fmt(beta_hat[2]),
  ', "se": ', fmt(se_beta[2]), ', "n_obs": ', n, "},\n",
  '    {"term": "z", "estimate": ', fmt(beta_hat[3]),
  ', "se": ', fmt(se_beta[3]), ', "n_obs": ', n, "},\n",
  '    {"term": "sigma", "estimate": ', fmt(sigma_hat),
  ', "se": null, "n_obs": ', n, "}\n",
  "  ],\n",
  '  "method_metadata": {"estimator": "Homoskedastic Gaussian Tobit maximum likelihood", ',
  '"vcov": "Inverse observed information matrix"},\n',
  '  "diagnostics": {}\n',
  "}\n"
)

writeLines(json, "result.json")
