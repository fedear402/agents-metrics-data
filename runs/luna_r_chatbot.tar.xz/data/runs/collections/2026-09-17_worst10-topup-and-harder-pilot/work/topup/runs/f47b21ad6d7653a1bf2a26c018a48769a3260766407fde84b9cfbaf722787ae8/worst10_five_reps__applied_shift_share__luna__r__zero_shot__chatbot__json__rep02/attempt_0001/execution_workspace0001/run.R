d <- read.csv("./input.csv", stringsAsFactors = FALSE)

region_key <- as.character(d$region_id)
industry_key <- as.character(d$industry_id)

region_ids <- unique(region_key)
industry_ids <- unique(industry_key)

first_region <- match(region_ids, region_key)
region_weight <- d$region_weight[first_region]
x_r <- d$x[first_region]
y_r <- d$y[first_region]

e_r <- region_weight / sum(region_weight)

z_r <- as.numeric(tapply(
  d$share * d$shock,
  region_key,
  sum
)[region_ids])

weighted_mean <- function(v, w) {
  sum(w * v) / sum(w)
}

y0_r <- y_r - weighted_mean(y_r, e_r)
x0_r <- x_r - weighted_mean(x_r, e_r)
z0_r <- z_r - weighted_mean(z_r, e_r)

industry_index <- match(industry_key, industry_ids)
n_industries <- length(industry_ids)

s_n <- numeric(n_industries)
ybar_n <- numeric(n_industries)
xbar_n <- numeric(n_industries)
zbar_n <- numeric(n_industries)
shock_n <- numeric(n_industries)

for (j in seq_len(n_industries)) {
  rows_j <- which(industry_index == j)
  regions_j <- match(region_key[rows_j], region_ids)
  weights_j <- e_r[regions_j] * d$share[rows_j]

  s_n[j] <- sum(weights_j)
  ybar_n[j] <- sum(weights_j * y0_r[regions_j]) / s_n[j]
  xbar_n[j] <- sum(weights_j * x0_r[regions_j]) / s_n[j]
  zbar_n[j] <- sum(weights_j * z0_r[regions_j]) / s_n[j]
  shock_n[j] <- d$shock[rows_j[1]]
}

keep <- is.finite(s_n) & s_n > 0 &
  is.finite(ybar_n) & is.finite(xbar_n) &
  is.finite(zbar_n) & is.finite(shock_n)

s_n <- s_n[keep]
ybar_n <- ybar_n[keep]
xbar_n <- xbar_n[keep]
zbar_n <- zbar_n[keep]
shock_n <- shock_n[keep]

N <- length(s_n)

iv_fit <- function(y, endogenous, instrument, weights) {
  X <- cbind(1, endogenous)
  Z <- cbind(1, instrument)
  W <- diag(weights, nrow = N, ncol = N)

  ZWZ_inv <- solve(crossprod(Z, W %*% Z))
  PZX <- Z %*% ZWZ_inv %*% crossprod(Z, W %*% X)
  PZy <- Z %*% ZWZ_inv %*% crossprod(Z, W %*% y)

  A <- crossprod(X, W %*% PZX)
  b <- solve(A, crossprod(X, W %*% PZy))
  residuals <- as.vector(y - X %*% b)

  meat <- matrix(0, nrow = 2, ncol = 2)
  for (i in seq_len(N)) {
    qi <- PZX[i, , drop = FALSE]
    meat <- meat +
      (weights[i]^2 * residuals[i]^2) *
      crossprod(qi)
  }

  vcov_hc1 <- solve(A) %*% meat %*% solve(t(A)) * N / (N - 2)

  list(
    estimate = as.numeric(b[2]),
    se = sqrt(vcov_hc1[2, 2])
  )
}

effect_fit <- iv_fit(
  y = ybar_n,
  endogenous = xbar_n,
  instrument = shock_n,
  weights = s_n
)

first_stage_fit <- iv_fit(
  y = xbar_n,
  endogenous = zbar_n,
  instrument = shock_n,
  weights = s_n
)

effective_shocks <- 1 / sum(s_n^2)

result <- sprintf(
  paste0(
    '{\n',
    '  "task_id": "applied_shift_share",\n',
    '  "platform": "r",\n',
    '  "estimates": [\n',
    '    {"term": "effect", "estimate": %.15g, "se": %.15g, "n_obs": %d},\n',
    '    {"term": "first_stage", "estimate": %.15g, "se": %.15g, "n_obs": %d},\n',
    '    {"term": "effective_shocks", "estimate": %.15g, "se": null, "n_obs": %d}\n',
    '  ],\n',
    '  "method_metadata": {\n',
    '    "estimator": "Borusyak-Hull-Jaravel shock-level weighted 2SLS",\n',
    '    "vcov": "shock-level heteroskedasticity-robust HC1 with structural IV residuals"\n',
    '  },\n',
    '  "diagnostics": {}\n',
    '}'
  ),
  effect_fit$estimate,
  effect_fit$se,
  N,
  first_stage_fit$estimate,
  first_stage_fit$se,
  N,
  effective_shocks,
  N
)

writeLines(result, "./result.json")
