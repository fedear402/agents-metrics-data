d <- read.csv("input.csv")

n <- nrow(d)
q <- 2L
df <- n - 4L
critical <- qf(0.95, q, df)
k <- q * critical / df

restricted_y <- lm(y ~ x, data = d)
restricted_d <- lm(endog ~ x, data = d)

unrestricted_y <- lm(y ~ x + z1 + z2, data = d)
unrestricted_d <- lm(endog ~ x + z1 + z2, data = d)

ry <- residuals(restricted_y)
rd <- residuals(restricted_d)
uy <- residuals(unrestricted_y)
ud <- residuals(unrestricted_d)

A <- sum(rd^2) - (1 + k) * sum(ud^2)
B <- -2 * (sum(ry * rd) - (1 + k) * sum(uy * ud))
C <- sum(ry^2) - (1 + k) * sum(uy^2)

discriminant <- B^2 - 4 * A * C
roots <- Re(polyroot(c(C, B, A)))
bounds <- sort(roots)

ar_f <- function(beta) {
  transformed <- d$y - beta * d$endog
  restricted_fit <- lm(transformed ~ x, data = d)
  unrestricted_fit <- lm(transformed ~ x + z1 + z2, data = d)

  ssr_r <- deviance(restricted_fit)
  ssr_u <- deviance(unrestricted_fit)

  ((ssr_r - ssr_u) / q) / (ssr_u / df)
}

accepts_zero <- as.integer(C <= 0)
unbounded <- as.integer(A < 0)

rows <- list(
  list(
    term = "boundary_low",
    estimate = unname(bounds[1]),
    se = NULL,
    n_obs = n
  ),
  list(
    term = "boundary_high",
    estimate = unname(bounds[2]),
    se = NULL,
    n_obs = n
  ),
  list(
    term = "accepts_zero",
    estimate = accepts_zero,
    se = NULL,
    n_obs = n
  ),
  list(
    term = "unbounded",
    estimate = unbounded,
    se = NULL,
    n_obs = n
  ),
  list(
    term = "ar_f_at_one",
    estimate = ar_f(1),
    se = NULL,
    n_obs = n
  )
)

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = rows,
  method_metadata = list(
    estimator = "Anderson-Rubin inversion with homoskedastic joint F test",
    vcov = "conventional homoskedastic"
  ),
  diagnostics = list(
    numerator_df = q,
    denominator_df = df,
    critical_value = critical,
    quadratic_A = A,
    quadratic_B = B,
    quadratic_C = C,
    discriminant = discriminant
  )
)

jsonlite::write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
