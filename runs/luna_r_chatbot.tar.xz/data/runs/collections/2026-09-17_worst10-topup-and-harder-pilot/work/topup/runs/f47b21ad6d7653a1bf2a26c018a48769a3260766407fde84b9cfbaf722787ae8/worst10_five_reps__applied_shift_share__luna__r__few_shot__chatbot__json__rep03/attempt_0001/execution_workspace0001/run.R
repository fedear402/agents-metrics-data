library(jsonlite)

dat <- read.csv("input.csv", stringsAsFactors = FALSE)

regions <- unique(dat$region_id)
industries <- unique(dat$industry_id)

region_data <- dat[match(regions, dat$region_id), ]
region_weight <- region_data$region_weight
e <- region_weight / sum(region_weight)

R <- length(regions)
N <- length(industries)

share_matrix <- matrix(
  0,
  nrow = R,
  ncol = N,
  dimnames = list(as.character(regions), as.character(industries))
)

for (i in seq_len(nrow(dat))) {
  r <- match(dat$region_id[i], regions)
  n <- match(dat$industry_id[i], industries)
  share_matrix[r, n] <- dat$share[i]
}

shock_by_industry <- dat$shock[match(industries, dat$industry_id)]

x <- region_data$x
y <- region_data$y
z <- drop(share_matrix %*% shock_by_industry)

weighted_mean <- function(value, weights) {
  sum(weights * value)
}

y0 <- y - weighted_mean(y, e)
x0 <- x - weighted_mean(x, e)
z0 <- z - weighted_mean(z, e)

s <- drop(crossprod(e, share_matrix))

aggregate_exposure <- function(value0) {
  numerators <- drop(crossprod(share_matrix, e * value0))
  numerators / s
}

ybar <- aggregate_exposure(y0)
xbar <- aggregate_exposure(x0)
zbar <- aggregate_exposure(z0)

shock_level_iv <- function(dependent, endogenous, instrument, weights) {
  regressors <- cbind(1, endogenous)
  instruments <- cbind(1, instrument)

  cross <- crossprod(instruments, weights * regressors)
  moment <- crossprod(instruments, weights * dependent)
  beta <- solve(cross, moment)

  residual <- drop(dependent - regressors %*% beta)
  scores <- instruments * (weights * residual)
  inverse_cross <- solve(cross)

  n <- length(dependent)
  covariance <- (n / (n - 2)) *
    inverse_cross %*% crossprod(scores) %*% t(inverse_cross)

  list(
    estimate = unname(beta[2]),
    se = sqrt(covariance[2, 2])
  )
}

effect_fit <- shock_level_iv(ybar, xbar, shock_by_industry, s)
first_stage_fit <- shock_level_iv(xbar, zbar, shock_by_industry, s)

effective_shocks <- 1 / sum(s^2)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(
      term = "effect",
      estimate = as.numeric(effect_fit$estimate),
      se = as.numeric(effect_fit$se),
      n_obs = as.integer(N)
    ),
    list(
      term = "first_stage",
      estimate = as.numeric(first_stage_fit$estimate),
      se = as.numeric(first_stage_fit$se),
      n_obs = as.integer(N)
    ),
    list(
      term = "effective_shocks",
      estimate = as.numeric(effective_shocks),
      se = NULL,
      n_obs = as.integer(N)
    )
  ),
  method_metadata = list(
    estimator = "Borusyak-Hull-Jaravel shock-level weighted IV",
    vcov = "HC1 with structural IV residuals and analytic exposure weights"
  ),
  diagnostics = list()
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
