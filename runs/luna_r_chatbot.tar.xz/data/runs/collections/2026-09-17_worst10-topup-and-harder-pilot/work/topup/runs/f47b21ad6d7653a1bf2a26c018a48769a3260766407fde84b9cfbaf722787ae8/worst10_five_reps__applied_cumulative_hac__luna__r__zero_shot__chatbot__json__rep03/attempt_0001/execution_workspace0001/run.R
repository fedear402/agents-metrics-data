#!/usr/bin/env Rscript

dat <- read.csv("input.csv", stringsAsFactors = FALSE)
dat <- dat[order(as.Date(dat$date)), ]

n_total <- nrow(dat)
log_sales <- log(dat$sales)
log_vix <- log(dat$vix)
vol_change <- diff(log_vix)

lag_count <- 15L
rows <- (lag_count + 2L):n_total
y <- log_sales[rows]

X_lags <- sapply(seq_len(lag_count), function(k) {
  vol_change[rows - k]
})
colnames(X_lags) <- paste0("lag_", seq_len(lag_count))

X <- cbind("(Intercept)" = 1, X_lags)
n_obs <- nrow(X)
p <- ncol(X)

XtX_inv <- solve(crossprod(X))
beta <- XtX_inv %*% crossprod(X, y)
residuals <- as.vector(y - X %*% beta)
scores <- X * residuals

meat <- crossprod(scores)

if (lag_count > 0L) {
  for (j in seq_len(lag_count)) {
    weight <- 1 - j / 16
    gamma_j <- crossprod(scores[(j + 1L):n_obs, , drop = FALSE],
                         scores[1L:(n_obs - j), , drop = FALSE])
    meat <- meat + weight * (gamma_j + t(gamma_j))
  }
}

vcov_nw <- XtX_inv %*% meat %*% XtX_inv
vcov_nw <- vcov_nw * n_obs / (n_obs - 16)
se_beta <- sqrt(pmax(diag(vcov_nw), 0))

cumulative_indices <- 2:(lag_count + 1L)
cumulative_estimate <- sum(beta[cumulative_indices])
cumulative_variance <- sum(vcov_nw[cumulative_indices, cumulative_indices])
cumulative_se <- sqrt(max(cumulative_variance, 0))

json_number <- function(x) {
  if (length(x) != 1L || !is.finite(x)) {
    "null"
  } else {
    sprintf("%.15g", as.numeric(x))
  }
}

result <- paste0(
  '{\n',
  '  "task_id": "applied_cumulative_hac",\n',
  '  "platform": "r",\n',
  '  "estimates": [\n',
  '    {"term": "cumulative_response", "estimate": ',
  json_number(cumulative_estimate),
  ', "se": ', json_number(cumulative_se),
  ', "n_obs": ', n_obs, '},\n',
  '    {"term": "lag_1", "estimate": ',
  json_number(beta["lag_1"]),
  ', "se": ', json_number(se_beta["lag_1"]),
  ', "n_obs": ', n_obs, '},\n',
  '    {"term": "lag_15", "estimate": ',
  json_number(beta["lag_15"]),
  ', "se": ', json_number(se_beta["lag_15"]),
  ', "n_obs": ', n_obs, '}\n',
  '  ],\n',
  '  "method_metadata": {\n',
  '    "estimator": "OLS with intercept and lags 1 through 15 of first-differenced log volatility",\n',
  '    "vcov": "Newey-West HAC, maximum lag 15, Bartlett weights, scaled by N/(N-16)"\n',
  '  },\n',
  '  "diagnostics": {}\n',
  '}\n'
)

writeLines(result, "result.json")
