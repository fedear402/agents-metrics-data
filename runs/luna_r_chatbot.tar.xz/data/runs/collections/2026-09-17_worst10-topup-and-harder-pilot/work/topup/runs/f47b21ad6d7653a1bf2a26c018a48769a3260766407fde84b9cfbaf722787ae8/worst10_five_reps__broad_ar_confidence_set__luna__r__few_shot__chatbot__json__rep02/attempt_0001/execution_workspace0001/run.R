d <- read.csv("input.csv")

n <- nrow(d)
q <- 2L
df <- n - 4L
critical <- qf(0.95, q, df)
k <- q * critical / df

restricted_y <- lm(y ~ x, data = d)
restricted_endog <- lm(endog ~ x, data = d)

unrestricted_y <- lm(y ~ x + z1 + z2, data = d)
unrestricted_endog <- lm(endog ~ x + z1 + z2, data = d)

ry <- residuals(restricted_y)
rd <- residuals(restricted_endog)
uy <- residuals(unrestricted_y)
ud <- residuals(unrestricted_endog)

A <- sum(rd^2) - (1 + k) * sum(ud^2)
B <- -2 * (sum(ry * rd) - (1 + k) * sum(uy * ud))
C <- sum(ry^2) - (1 + k) * sum(uy^2)

discriminant <- B^2 - 4 * A * C
roots <- sort(Re(polyroot(c(C, B, A))))

accepts <- function(beta) {
  A * beta^2 + B * beta + C <= 0
}

transformed_one <- d$y - d$endog
restricted_one <- lm(transformed_one ~ x, data = d)
unrestricted_one <- lm(transformed_one ~ x + z1 + z2, data = d)

ar_f_at_one <- (
  (deviance(restricted_one) - deviance(unrestricted_one)) / q
) / (
  deviance(unrestricted_one) / df
)

unbounded <- as.integer(A < 0)

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = list(
    list(
      term = "boundary_low",
      estimate = unname(roots[1]),
      se = NULL,
      n_obs = n
    ),
    list(
      term = "boundary_high",
      estimate = unname(roots[2]),
      se = NULL,
      n_obs = n
    ),
    list(
      term = "accepts_zero",
      estimate = as.numeric(accepts(0)),
      se = NULL,
      n_obs = n
    ),
    list(
      term = "unbounded",
      estimate = unbounded,
      se = NULL,
      n_obs = n
    ),
    list(
      term = "ar_f_at_one",
      estimate = unname(ar_f_at_one),
      se = NULL,
      n_obs = n
    )
  ),
  method_metadata = list(
    estimator = "Anderson-Rubin inversion with homoskedastic joint F test",
    vcov = "Homoskedastic OLS residual variance"
  ),
  diagnostics = list(
    numerator_df = q,
    denominator_df = df,
    critical_value = critical,
    quadratic_A = A,
    quadratic_B = B,
    quadratic_C = C,
    discriminant = discriminant
  )
)

jsonlite::write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
