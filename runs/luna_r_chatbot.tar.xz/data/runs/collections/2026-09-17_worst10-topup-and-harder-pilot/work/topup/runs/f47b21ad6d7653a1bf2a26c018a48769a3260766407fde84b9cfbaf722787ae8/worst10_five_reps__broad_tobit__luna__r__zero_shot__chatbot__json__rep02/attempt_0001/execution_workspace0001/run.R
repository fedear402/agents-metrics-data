dat <- read.csv("input.csv")

y <- dat$y
X <- cbind(const = 1, x = dat$x, z = dat$z)
n <- nrow(dat)
censored <- y <= 0

loglik <- function(par) {
  beta <- par[1:3]
  sigma <- exp(par[4])
  mu <- drop(X %*% beta)

  ll <- numeric(n)
  ll[censored] <- pnorm((0 - mu[censored]) / sigma, log.p = TRUE)
  ll[!censored] <- dnorm(
    y[!censored],
    mean = mu[!censored],
    sd = sigma,
    log = TRUE
  )

  if (any(!is.finite(ll))) return(-Inf)
  sum(ll)
}

objective <- function(par) {
  val <- loglik(par)
  if (!is.finite(val)) return(1e100)
  -val
}

beta_start <- tryCatch(
  coef(lm(y ~ x + z, data = dat)),
  error = function(e) c(mean(y), 0, 0)
)

beta_start[is.na(beta_start)] <- 0
sigma_start <- sd(y[y > 0])
if (!is.finite(sigma_start) || sigma_start <= 0) sigma_start <- sd(y)
if (!is.finite(sigma_start) || sigma_start <= 0) sigma_start <- 1

starts <- list(
  c(beta_start, log(sigma_start)),
  c(c(mean(y), 0, 0), log(sigma_start)),
  c(beta_start, log(max(sigma_start / 2, 1e-6))),
  c(beta_start, log(sigma_start * 2))
)

fits <- lapply(
  starts,
  function(s) optim(
    par = s,
    fn = objective,
    method = "BFGS",
    hessian = TRUE,
    control = list(maxit = 10000, reltol = 1e-12)
  )
)

fits <- fits[vapply(fits, function(f) is.finite(f$value), logical(1))]
fit <- fits[[which.min(vapply(fits, function(f) f$value, numeric(1)))]]

par_hat <- fit$par
beta_hat <- par_hat[1:3]
sigma_hat <- exp(par_hat[4])

H <- fit$hessian
if (!all(is.finite(H))) {
  H <- optimHess(par_hat, objective)
}

V <- tryCatch(solve(H), error = function(e) MASS::ginv(H))
se_beta <- sqrt(pmax(diag(V)[1:3], 0))
se_sigma <- NA_real_

estimates <- list(
  list(term = "const", estimate = unname(beta_hat[1]),
       se = unname(se_beta[1]), n_obs = n),
  list(term = "x", estimate = unname(beta_hat[2]),
       se = unname(se_beta[2]), n_obs = n),
  list(term = "z", estimate = unname(beta_hat[3]),
       se = unname(se_beta[3]), n_obs = n),
  list(term = "sigma", estimate = unname(sigma_hat),
       se = NULL, n_obs = n)
)

num <- function(x) {
  if (is.null(x)) "null" else sprintf("%.17g", as.numeric(x))
}

estimate_json <- vapply(
  estimates,
  function(e) sprintf(
    '{"term":"%s","estimate":%s,"se":%s,"n_obs":%d}',
    e$term, num(e$estimate), num(e$se), e$n_obs
  ),
  character(1)
)

json <- paste0(
  '{',
  '"task_id":"broad_tobit",',
  '"platform":"r",',
  '"estimates":[', paste(estimate_json, collapse = ","), '],',
  '"method_metadata":{',
  '"estimator":"Homoskedastic Gaussian Tobit maximum likelihood",',
  '"vcov":"Inverse observed information from the joint likelihood"',
  '},',
  '"diagnostics":{}',
  '}'
)

writeLines(json, "result.json")
