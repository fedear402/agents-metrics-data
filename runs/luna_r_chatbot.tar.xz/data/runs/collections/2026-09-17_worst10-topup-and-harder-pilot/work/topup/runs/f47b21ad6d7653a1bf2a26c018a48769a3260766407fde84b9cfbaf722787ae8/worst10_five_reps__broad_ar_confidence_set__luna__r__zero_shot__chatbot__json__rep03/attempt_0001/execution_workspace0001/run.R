dat <- read.csv("input.csv")

n <- nrow(dat)
df2 <- n - 4
crit <- qf(0.95, df1 = 2, df2 = df2)

rss_pair <- function(beta) {
  response <- dat$y - beta * dat$endog
  
  restricted <- lm(response ~ dat$x)
  unrestricted <- lm(response ~ dat$x + dat$z1 + dat$z2)
  
  c(
    rss_restricted = sum(resid(restricted)^2),
    rss_unrestricted = sum(resid(unrestricted)^2)
  )
}

rss_at <- sapply(c(-1, 0, 1), rss_pair)

quadratic_coefficients <- function(values) {
  vm1 <- values[1]
  v0 <- values[2]
  v1 <- values[3]
  
  c(
    a = (v1 + vm1 - 2 * v0) / 2,
    b = (v1 - vm1) / 2,
    c = v0
  )
}

delta_coef <- quadratic_coefficients(
  rss_at["rss_restricted", ]
) - quadratic_coefficients(
  rss_at["rss_unrestricted", ]
)

rssu_coef <- quadratic_coefficients(
  rss_at["rss_unrestricted", ]
)

k <- 2 * crit / df2
ineq_coef <- delta_coef - k * rssu_coef

roots <- if (abs(ineq_coef["a"]) < 1e-12) {
  if (abs(ineq_coef["b"]) < 1e-12) numeric(0) else {
    -ineq_coef["c"] / ineq_coef["b"]
  }
} else {
  uniroot_candidates <- polyroot(
    c(ineq_coef["c"], ineq_coef["b"], ineq_coef["a"])
  )
  Re(uniroot_candidates[abs(Im(uniroot_candidates)) < 1e-8])
}

roots <- sort(unique(round(roots, 12)))

if (length(roots) < 2) {
  stop("Expected two finite Anderson-Rubin confidence-set boundaries.")
}

boundary_low <- roots[1]
boundary_high <- roots[length(roots)]

ar_f <- function(beta) {
  rss <- rss_pair(beta)
  ((rss["rss_restricted"] - rss["rss_unrestricted"]) / 2) /
    (rss["rss_unrestricted"] / df2)
}

accepted <- function(beta) {
  ar_f(beta) <= crit
}

accepts_zero <- as.numeric(accepted(0))

unbounded <- as.numeric(
  accepted(-1e8) || accepted(1e8)
)

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = list(
    list(
      term = "boundary_low",
      estimate = as.numeric(boundary_low),
      se = NULL,
      n_obs = as.integer(n)
    ),
    list(
      term = "boundary_high",
      estimate = as.numeric(boundary_high),
      se = NULL,
      n_obs = as.integer(n)
    ),
    list(
      term = "accepts_zero",
      estimate = as.numeric(accepts_zero),
      se = NULL,
      n_obs = as.integer(n)
    ),
    list(
      term = "unbounded",
      estimate = as.numeric(unbounded),
      se = NULL,
      n_obs = as.integer(n)
    ),
    list(
      term = "ar_f_at_one",
      estimate = as.numeric(ar_f(1)),
      se = NULL,
      n_obs = as.integer(n)
    )
  ),
  method_metadata = list(
    estimator = "Anderson-Rubin inversion with conventional homoskedastic joint F test",
    vcov = "Homoskedastic"
  ),
  diagnostics = list()
)

jsonlite::write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 17
)
