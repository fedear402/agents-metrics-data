d <- read.csv("input.csv")

d$y <- ordered(d$y, levels = c(1, 2, 3))

fit <- MASS::polr(
  y ~ x + z,
  data = d,
  method = "logistic",
  Hess = TRUE,
  control = list(reltol = 1e-12, maxit = 1000)
)

V <- vcov(fit)
beta <- coef(fit)
n <- nrow(d)

eta_high <- unname(beta["x"])
prob_high <- 1 - plogis(unname(fit$zeta[2]) - eta_high)

result <- list(
  task_id = "broad_ordered_logit",
  platform = "r",
  estimates = list(
    list(
      term = "x",
      estimate = unname(beta["x"]),
      se = sqrt(V["x", "x"]),
      n_obs = n
    ),
    list(
      term = "z",
      estimate = unname(beta["z"]),
      se = sqrt(V["z", "z"]),
      n_obs = n
    ),
    list(
      term = "prob_high",
      estimate = unname(prob_high),
      se = NULL,
      n_obs = n
    )
  ),
  method_metadata = list(
    estimator = "maximum_likelihood_ordered_logit",
    vcov = "conventional_observed_information"
  ),
  diagnostics = list()
)

jsonlite::write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
