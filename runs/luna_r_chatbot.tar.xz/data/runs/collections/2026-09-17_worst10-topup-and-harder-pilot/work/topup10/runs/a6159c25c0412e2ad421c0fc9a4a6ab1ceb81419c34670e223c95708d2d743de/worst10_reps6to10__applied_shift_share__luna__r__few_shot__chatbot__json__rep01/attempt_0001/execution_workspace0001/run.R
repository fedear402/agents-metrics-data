library(jsonlite)

dat <- read.csv("input.csv", stringsAsFactors = FALSE)

regions <- unique(dat$region_id)
industries <- unique(dat$industry_id)

region_rows <- match(regions, dat$region_id)
region_weight <- dat$region_weight[region_rows]
e <- region_weight / sum(region_weight)

R <- length(regions)
N <- length(industries)

share_mat <- matrix(
  0,
  nrow = R,
  ncol = N,
  dimnames = list(as.character(regions), as.character(industries))
)

for (i in seq_len(nrow(dat))) {
  r <- match(dat$region_id[i], regions)
  n <- match(dat$industry_id[i], industries)
  share_mat[r, n] <- dat$share[i]
}

x <- dat$x[region_rows]
y <- dat$y[region_rows]
shock <- dat$shock[match(industries, dat$industry_id)]

z <- drop(share_mat %*% shock)

weighted_mean <- function(v, w) {
  sum(w * v)
}

y0 <- y - weighted_mean(y, e)
x0 <- x - weighted_mean(x, e)
z0 <- z - weighted_mean(z, e)

s <- drop(crossprod(e, share_mat))

if (any(s <= 0)) {
  stop("Every industry must have positive aggregate exposure.")
}

aggregate_exposure <- function(v0) {
  drop(crossprod(share_mat, e * v0)) / s
}

ybar <- aggregate_exposure(y0)
xbar <- aggregate_exposure(x0)
zbar <- aggregate_exposure(z0)

shock_iv <- function(dependent, endogenous) {
  regressors <- cbind(1, endogenous)
  instruments <- cbind(1, shock)

  cross <- crossprod(instruments, s * regressors)
  rhs <- crossprod(instruments, s * dependent)
  beta <- solve(cross, rhs)

  residual <- drop(dependent - regressors %*% beta)
  scores <- instruments * (s * residual)
  inverse <- solve(cross)

  covariance <- (N / (N - 2)) *
    inverse %*% crossprod(scores) %*% t(inverse)

  c(
    slope = beta[2],
    se = sqrt(covariance[2, 2])
  )
}

effect <- shock_iv(ybar, xbar)
first_stage <- shock_iv(xbar, zbar)
effective_shocks <- 1 / sum(s^2)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(
      term = "effect",
      estimate = unname(as.numeric(effect["slope"])),
      se = unname(as.numeric(effect["se"])),
      n_obs = as.integer(N)
    ),
    list(
      term = "first_stage",
      estimate = unname(as.numeric(first_stage["slope"])),
      se = unname(as.numeric(first_stage["se"])),
      n_obs = as.integer(N)
    ),
    list(
      term = "effective_shocks",
      estimate = unname(as.numeric(effective_shocks)),
      se = NULL,
      n_obs = as.integer(N)
    )
  ),
  method_metadata = list(
    estimator = "shock-level weighted IV with regional shift-share aggregation",
    vcov = "HC1 with structural IV residuals and N/(N-2) multiplier"
  ),
  diagnostics = list()
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
