dat <- read.csv("input.csv", stringsAsFactors = FALSE)

dat <- dat[
  is.finite(dat$score) &
    is.finite(dat$participated) &
    is.finite(dat$earnings) &
    abs(dat$score) < 1,
]

x <- dat$score
right <- as.numeric(x >= 0)
w <- 1 - abs(x)

X <- cbind(
  intercept = 1,
  side = right,
  score = x,
  side_score = right * x
)

fit_hc0 <- function(y, X, w) {
  XtWX <- crossprod(X, w * X)
  bread <- solve(XtWX)
  beta <- bread %*% crossprod(X, w * y)
  residuals <- as.vector(y - X %*% beta)

  meat <- matrix(0, ncol = ncol(X), nrow = ncol(X))
  for (i in seq_along(y)) {
    xi <- matrix(X[i, ], ncol = 1)
    meat <- meat + (w[i]^2 * residuals[i]^2) * (xi %*% t(xi))
  }

  vcov <- bread %*% meat %*% bread

  list(
    estimate = as.numeric(beta),
    vcov = vcov,
    residuals = residuals
  )
}

earnings_fit <- fit_hc0(dat$earnings, X, w)
participation_fit <- fit_hc0(dat$participated, X, w)

reduced_form <- earnings_fit$estimate[2]
first_stage <- participation_fit$estimate[2]
treatment_effect <- reduced_form / first_stage

cross_meat <- matrix(0, ncol = ncol(X), nrow = ncol(X))
for (i in seq_len(nrow(X))) {
  xi <- matrix(X[i, ], ncol = 1)
  cross_meat <- cross_meat +
    (w[i]^2 *
       earnings_fit$residuals[i] *
       participation_fit$residuals[i]) *
    (xi %*% t(xi))
}

bread <- solve(crossprod(X, w * X))
cross_vcov <- bread %*% cross_meat %*% bread

var_reduced_form <- earnings_fit$vcov[2, 2]
var_first_stage <- participation_fit$vcov[2, 2]
cov_reduced_first <- cross_vcov[2, 2]

gradient <- c(1 / first_stage, -reduced_form / first_stage^2)
joint_vcov <- matrix(
  c(
    var_reduced_form, cov_reduced_first,
    cov_reduced_first, var_first_stage
  ),
  nrow = 2,
  byrow = TRUE
)

var_treatment_effect <- as.numeric(
  t(gradient) %*% joint_vcov %*% gradient
)

n_obs <- nrow(dat)

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(
      term = "treatment_effect",
      estimate = as.numeric(treatment_effect),
      se = sqrt(max(0, var_treatment_effect)),
      n_obs = n_obs
    ),
    list(
      term = "reduced_form",
      estimate = as.numeric(reduced_form),
      se = sqrt(max(0, var_reduced_form)),
      n_obs = n_obs
    ),
    list(
      term = "first_stage",
      estimate = as.numeric(first_stage),
      se = sqrt(max(0, var_first_stage)),
      n_obs = n_obs
    )
  ),
  method_metadata = list(
    estimator = "Fuzzy regression discontinuity with local-linear weighted least squares",
    vcov = "Conventional heteroskedasticity-robust HC0 with joint covariance delta method"
  ),
  diagnostics = list()
)

json_escape <- function(x) {
  x <- gsub("\\\\", "\\\\\\\\", x)
  x <- gsub('"', '\\"', x, fixed = TRUE)
  x
}

json_num <- function(x) {
  if (is.null(x) || !is.finite(x)) "null" else format(x, digits = 17, scientific = FALSE)
}

json_text <- function(x) paste0('"', json_escape(x), '"')

json_output <- paste0(
  "{",
  '"task_id":', json_text(result$task_id), ",",
  '"platform":', json_text(result$platform), ",",
  '"estimates":[',
  paste(
    vapply(result$estimates, function(e) paste0(
      "{",
      '"term":', json_text(e$term), ",",
      '"estimate":', json_num(e$estimate), ",",
      '"se":', json_num(e$se), ",",
      '"n_obs":', e$n_obs,
      "}"
    ), character(1)),
    collapse = ","
  ),
  "],",
  '"method_metadata":{',
  '"estimator":', json_text(result$method_metadata$estimator), ",",
  '"vcov":', json_text(result$method_metadata$vcov),
  "},",
  '"diagnostics":{}',
  "}"
)

writeLines(json_output, "result.json")
