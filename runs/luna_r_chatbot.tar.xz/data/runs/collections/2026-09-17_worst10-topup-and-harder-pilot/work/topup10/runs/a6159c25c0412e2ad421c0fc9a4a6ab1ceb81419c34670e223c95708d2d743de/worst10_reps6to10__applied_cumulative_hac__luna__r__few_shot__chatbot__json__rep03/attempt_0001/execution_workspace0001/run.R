library(jsonlite)

data <- read.csv("input.csv", stringsAsFactors = FALSE)
data$date <- as.Date(data$date)
data <- data[order(data$date), ]

data$log_sales <- log(data$sales)
data$vol_change <- c(NA_real_, diff(log(data$vix)))

for (j in 1:15) {
  data[[paste0("lag_", j)]] <- c(
    rep(NA_real_, j),
    head(data$vol_change, -j)
  )
}

regressors <- paste0("lag_", 1:15)
sample <- data[complete.cases(data[, c("log_sales", regressors)]), ]

fit <- lm(
  as.formula(
    paste("log_sales ~", paste(regressors, collapse = " + "))
  ),
  data = sample
)

X <- model.matrix(fit)
u <- residuals(fit)
N <- nrow(X)
p <- ncol(X)

scores <- X * u
meat <- crossprod(scores)

hac_lags <- 15
for (j in seq_len(hac_lags)) {
  lag_product <- crossprod(
    scores[(j + 1):N, , drop = FALSE],
    scores[1:(N - j), , drop = FALSE]
  )
  weight <- 1 - j / 16
  meat <- meat + weight * (lag_product + t(lag_product))
}

bread <- solve(crossprod(X))
covariance <- (N / (N - 16)) * bread %*% meat %*% bread
coefficients <- coef(fit)

contrast <- c(0, rep(1, 15))
cumulative_response <- sum(contrast * coefficients)
cumulative_se <- sqrt(drop(t(contrast) %*% covariance %*% contrast))

lag1_se <- sqrt(covariance["lag_1", "lag_1"])
lag15_se <- sqrt(covariance["lag_15", "lag_15"])

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(
      term = "cumulative_response",
      estimate = unname(as.numeric(cumulative_response)),
      se = unname(as.numeric(cumulative_se)),
      n_obs = as.integer(N)
    ),
    list(
      term = "lag_1",
      estimate = unname(as.numeric(coefficients["lag_1"])),
      se = unname(as.numeric(lag1_se)),
      n_obs = as.integer(N)
    ),
    list(
      term = "lag_15",
      estimate = unname(as.numeric(coefficients["lag_15"])),
      se = unname(as.numeric(lag15_se)),
      n_obs = as.integer(N)
    )
  ),
  method_metadata = list(
    estimator = "OLS",
    vcov = "Newey-West HAC with Bartlett lag 15 and N/(N-16) correction"
  ),
  diagnostics = list()
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
