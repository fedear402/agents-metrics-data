library(jsonlite)

dat <- read.csv("input.csv", stringsAsFactors = FALSE)

regions <- unique(dat$region_id)
industries <- unique(dat$industry_id)

region_data <- do.call(rbind, lapply(regions, function(r) {
  d <- dat[dat$region_id == r, ]
  data.frame(
    region_id = r,
    region_weight = d$region_weight[1],
    x = d$x[1],
    y = d$y[1],
    stringsAsFactors = FALSE
  )
}))

e <- region_data$region_weight / sum(region_data$region_weight)

share_matrix <- matrix(
  0,
  nrow = length(regions),
  ncol = length(industries),
  dimnames = list(as.character(regions), as.character(industries))
)

shock <- numeric(length(industries))
names(shock) <- as.character(industries)

for (i in seq_len(nrow(dat))) {
  r <- as.character(dat$region_id[i])
  n <- as.character(dat$industry_id[i])
  share_matrix[r, n] <- dat$share[i]
  shock[n] <- dat$shock[i]
}

z <- drop(share_matrix %*% shock)

weighted_mean <- function(v, w) {
  sum(w * v)
}

y0 <- region_data$y - weighted_mean(region_data$y, e)
x0 <- region_data$x - weighted_mean(region_data$x, e)
z0 <- z - weighted_mean(z, e)

s <- drop(crossprod(e, share_matrix))

keep <- s > 0
s_used <- s[keep]
shock_used <- shock[keep]

aggregate_residual <- function(v0) {
  as.numeric(
    crossprod(share_matrix[, keep], e * v0) / s_used
  )
}

ybar <- aggregate_residual(y0)
xbar <- aggregate_residual(x0)
zbar <- aggregate_residual(z0)

shock_iv <- function(dependent, endogenous, instrument, weights) {
  regressors <- cbind(1, endogenous)
  instruments <- cbind(1, instrument)

  cross <- crossprod(instruments, weights * regressors)
  beta <- solve(
    cross,
    crossprod(instruments, weights * dependent)
  )

  residual <- drop(dependent - regressors %*% beta)
  scores <- instruments * (weights * residual)
  inverse <- solve(cross)

  n_industries <- length(weights)
  covariance <- n_industries / (n_industries - 2) *
    inverse %*% crossprod(scores) %*% t(inverse)

  c(
    estimate = beta[2],
    se = sqrt(covariance[2, 2])
  )
}

effect <- shock_iv(ybar, xbar, shock_used, s_used)
first_stage <- shock_iv(xbar, zbar, shock_used, s_used)
effective_shocks <- 1 / sum(s_used^2)
n_obs <- length(s_used)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(
      term = "effect",
      estimate = unname(effect["estimate"]),
      se = unname(effect["se"]),
      n_obs = n_obs
    ),
    list(
      term = "first_stage",
      estimate = unname(first_stage["estimate"]),
      se = unname(first_stage["se"]),
      n_obs = n_obs
    ),
    list(
      term = "effective_shocks",
      estimate = effective_shocks,
      se = NULL,
      n_obs = n_obs
    )
  ),
  method_metadata = list(
    estimator = "Shock-level weighted IV with regional shift-share exposure",
    vcov = "HC1 exposure-robust covariance with N/(N-2) multiplier"
  ),
  diagnostics = list()
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
