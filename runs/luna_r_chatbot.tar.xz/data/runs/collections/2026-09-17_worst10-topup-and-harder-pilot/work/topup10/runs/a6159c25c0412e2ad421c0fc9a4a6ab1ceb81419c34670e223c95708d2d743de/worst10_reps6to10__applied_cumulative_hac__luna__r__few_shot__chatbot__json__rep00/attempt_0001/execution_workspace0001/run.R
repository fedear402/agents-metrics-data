library(jsonlite)

data <- read.csv("input.csv", stringsAsFactors = FALSE)
data$date <- as.Date(data$date)
data <- data[order(data$date), ]

data$log_sales <- log(data$sales)
data$vix_change <- c(NA_real_, diff(log(data$vix)))

for (j in 1:15) {
  data[[paste0("lag_", j)]] <- c(
    rep(NA_real_, j + 1),
    data$vix_change[seq_len(nrow(data) - j - 1)]
  )
}

regressors <- paste0("lag_", 1:15)
sample <- data[complete.cases(data[, c("log_sales", regressors)]), ]

fit <- lm(
  log_sales ~ lag_1 + lag_2 + lag_3 + lag_4 + lag_5 +
    lag_6 + lag_7 + lag_8 + lag_9 + lag_10 +
    lag_11 + lag_12 + lag_13 + lag_14 + lag_15,
  data = sample
)

X <- model.matrix(fit)
u <- residuals(fit)
N <- nrow(X)
p <- ncol(X)
hac_lags <- 15

scores <- X * u
meat <- crossprod(scores)

for (j in seq_len(hac_lags)) {
  lag_product <- crossprod(
    scores[(j + 1):N, , drop = FALSE],
    scores[1:(N - j), , drop = FALSE]
  )
  weight <- 1 - j / 16
  meat <- meat + weight * (lag_product + t(lag_product))
}

bread <- solve(crossprod(X))
covariance <- (N / (N - 16)) * bread %*% meat %*% bread
coefficients <- coef(fit)

contrast <- c(0, rep(1, 15))
cumulative_estimate <- sum(contrast * coefficients)
cumulative_se <- sqrt(drop(t(contrast) %*% covariance %*% contrast))

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(
      term = "cumulative_response",
      estimate = unname(as.numeric(cumulative_estimate)),
      se = unname(as.numeric(cumulative_se)),
      n_obs = as.integer(N)
    ),
    list(
      term = "lag_1",
      estimate = unname(as.numeric(coefficients["lag_1"])),
      se = unname(as.numeric(sqrt(covariance["lag_1", "lag_1"]))),
      n_obs = as.integer(N)
    ),
    list(
      term = "lag_15",
      estimate = unname(as.numeric(coefficients["lag_15"])),
      se = unname(as.numeric(sqrt(covariance["lag_15", "lag_15"]))),
      n_obs = as.integer(N)
    )
  ),
  method_metadata = list(
    estimator = "OLS with fifteen lagged log volatility changes",
    vcov = "Bartlett Newey-West HAC, maximum lag 15, correction N/(N-16)"
  ),
  diagnostics = list()
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
