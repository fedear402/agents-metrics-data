dat <- read.csv("input.csv")

dat <- dat[abs(dat$score) < 1, ]
dat$right <- as.numeric(dat$score >= 0)
dat$x_right <- dat$score * dat$right
dat$weight <- 1 - abs(dat$score)

X <- cbind(
  intercept = 1,
  score = dat$score,
  right = dat$right,
  score_right = dat$x_right
)

w <- dat$weight
XtWX_inv <- solve(crossprod(X, w * X))
fit_outcome <- function(y) {
  beta <- XtWX_inv %*% crossprod(X, w * y)
  residual <- as.numeric(y - X %*% beta)
  estimate <- as.numeric(beta[3])
  list(beta = beta, residual = residual, estimate = estimate)
}

fit_earnings <- fit_outcome(dat$earnings)
fit_participation <- fit_outcome(dat$participated)

meat <- function(resid_a, resid_b) {
  crossprod(X, (w^2 * resid_a * resid_b) * X)
}

vcov_earnings <- XtWX_inv %*% meat(
  fit_earnings$residual,
  fit_earnings$residual
) %*% XtWX_inv

vcov_participation <- XtWX_inv %*% meat(
  fit_participation$residual,
  fit_participation$residual
) %*% XtWX_inv

cov_cross <- XtWX_inv %*% meat(
  fit_earnings$residual,
  fit_participation$residual
) %*% XtWX_inv

reduced_form <- fit_earnings$estimate
first_stage <- fit_participation$estimate

var_reduced_form <- vcov_earnings[3, 3]
var_first_stage <- vcov_participation[3, 3]
cov_reduced_first <- cov_cross[3, 3]

treatment_effect <- reduced_form / first_stage
gradient <- c(1 / first_stage, -reduced_form / first_stage^2)
joint_cov <- matrix(
  c(
    var_reduced_form,
    cov_reduced_first,
    cov_reduced_first,
    var_first_stage
  ),
  nrow = 2,
  byrow = TRUE
)
var_treatment_effect <- as.numeric(
  t(gradient) %*% joint_cov %*% gradient
)

n_obs <- nrow(dat)

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(
      term = "treatment_effect",
      estimate = treatment_effect,
      se = sqrt(max(var_treatment_effect, 0)),
      n_obs = n_obs
    ),
    list(
      term = "reduced_form",
      estimate = reduced_form,
      se = sqrt(max(var_reduced_form, 0)),
      n_obs = n_obs
    ),
    list(
      term = "first_stage",
      estimate = first_stage,
      se = sqrt(max(var_first_stage, 0)),
      n_obs = n_obs
    )
  ),
  method_metadata = list(
    estimator = "Fuzzy local-linear regression discontinuity with triangular weights",
    vcov = "HC0 sandwich covariance with delta-method treatment-effect standard error"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = 17)
