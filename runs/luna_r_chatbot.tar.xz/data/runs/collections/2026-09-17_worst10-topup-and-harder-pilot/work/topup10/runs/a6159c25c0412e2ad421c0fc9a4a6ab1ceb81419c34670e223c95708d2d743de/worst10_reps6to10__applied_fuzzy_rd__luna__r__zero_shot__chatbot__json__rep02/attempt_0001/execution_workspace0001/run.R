#!/usr/bin/env Rscript

df <- read.csv("input.csv", stringsAsFactors = FALSE)

df <- df[is.finite(df$score) &
         is.finite(df$participated) &
         is.finite(df$earnings) &
         abs(df$score) < 1, ]

n_obs <- nrow(df)

if (n_obs == 0) {
  stop("No observations inside the bandwidth.")
}

right <- as.numeric(df$score >= 0)
x <- cbind(
  intercept = 1,
  discontinuity = right,
  score = df$score,
  score_right = df$score * right
)

weights <- 1 - abs(df$score)
sqrt_weights <- sqrt(weights)

fit_wls <- function(y) {
  xtw <- t(x * sqrt_weights)
  xtwy <- xtw %*% (y * sqrt_weights)
  beta <- solve(xtw %*% (x * sqrt_weights), xtwy)
  residuals <- as.numeric(y - x %*% beta)

  bread <- solve(t(x) %*% (weights * x))
  meat <- matrix(0, ncol = ncol(x), nrow = ncol(x))

  for (i in seq_len(n_obs)) {
    xi <- x[i, , drop = FALSE]
    meat <- meat + weights[i]^2 * residuals[i]^2 * t(xi) %*% xi
  }

  vcov <- bread %*% meat %*% bread

  list(
    estimate = as.numeric(beta[2]),
    variance = as.numeric(vcov[2, 2]),
    beta = as.numeric(beta),
    residuals = residuals,
    bread = bread
  )
}

earnings_fit <- fit_wls(df$earnings)
participation_fit <- fit_wls(df$participated)

cross_meat <- matrix(0, ncol = ncol(x), nrow = ncol(x))

for (i in seq_len(n_obs)) {
  xi <- x[i, , drop = FALSE]
  cross_meat <- cross_meat +
    weights[i]^2 *
    earnings_fit$residuals[i] *
    participation_fit$residuals[i] *
    t(xi) %*% xi
}

cross_vcov <- earnings_fit$bread %*% cross_meat %*%
  participation_fit$bread

reduced_form <- earnings_fit$estimate
first_stage <- participation_fit$estimate

cov_rf_fs <- as.numeric(cross_vcov[2, 2])

treatment_effect <- reduced_form / first_stage

delta_gradient <- c(
  1 / first_stage,
  -reduced_form / first_stage^2
)

joint_vcov <- matrix(
  c(
    earnings_fit$variance, cov_rf_fs,
    cov_rf_fs, participation_fit$variance
  ),
  nrow = 2,
  byrow = TRUE
)

treatment_variance <- as.numeric(
  t(delta_gradient) %*% joint_vcov %*% delta_gradient
)

if (treatment_variance < 0 && treatment_variance > -1e-12) {
  treatment_variance <- 0
}

output <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(
      term = "treatment_effect",
      estimate = treatment_effect,
      se = sqrt(treatment_variance),
      n_obs = n_obs
    ),
    list(
      term = "reduced_form",
      estimate = reduced_form,
      se = sqrt(earnings_fit$variance),
      n_obs = n_obs
    ),
    list(
      term = "first_stage",
      estimate = first_stage,
      se = sqrt(participation_fit$variance),
      n_obs = n_obs
    )
  ),
  method_metadata = list(
    estimator = "Fuzzy regression discontinuity with local-linear weighted least squares",
    vcov = "Conventional heteroskedasticity-robust HC0 with joint delta-method covariance"
  ),
  diagnostics = list()
)

if (!requireNamespace("jsonlite", quietly = TRUE)) {
  stop("The jsonlite package is required.")
}

jsonlite::write_json(
  output,
  "result.json",
  auto_unbox = TRUE,
  digits = 15,
  pretty = FALSE,
  na = "null"
)
