d <- read.csv("input.csv", stringsAsFactors = FALSE, check.names = FALSE)

required <- c("region_id", "industry_id", "share", "shock",
              "region_weight", "x", "y")
stopifnot(all(required %in% names(d)))

region_key <- as.character(d$region_id)
industry_key <- as.character(d$industry_id)

region_ids <- unique(region_key)
region_first <- match(region_ids, region_key)

region_weight <- d$region_weight[region_first]
e <- region_weight / sum(region_weight)

region_index <- match(region_key, region_ids)
industry_ids <- unique(industry_key)
industry_index <- match(industry_key, industry_ids)

share <- as.numeric(d$share)
shock_by_industry <- d$shock[match(industry_ids, industry_key)]

x_region <- d$x[region_first]
y_region <- d$y[region_first]

z_region <- as.numeric(rowsum(share * d$shock, region_index,
                               reorder = FALSE))

weighted_mean <- function(v, w) {
  sum(w * v) / sum(w)
}

y0 <- y_region - weighted_mean(y_region, e)
x0 <- x_region - weighted_mean(x_region, e)
z0 <- z_region - weighted_mean(z_region, e)

s_all <- as.numeric(rowsum(share * e[region_index], industry_index,
                           reorder = FALSE))

keep <- s_all > 0
s <- s_all[keep]
shock <- shock_by_industry[keep]

aggregate_residual <- function(v0) {
  numerator <- as.numeric(rowsum(
    share * e[region_index] * v0[region_index],
    industry_index,
    reorder = FALSE
  ))
  numerator[keep] / s
}

ybar <- aggregate_residual(y0)
xbar <- aggregate_residual(x0)
zbar <- aggregate_residual(z0)

iv_hc1 <- function(outcome, endogenous, instrument, weight) {
  n <- length(outcome)
  X <- cbind(1, endogenous)
  Z <- cbind(1, instrument)
  W <- diag(weight, nrow = n, ncol = n)

  ZWZ <- crossprod(Z, W %*% Z)
  Pz <- Z %*% solve(ZWZ, crossprod(Z, W))
  A <- crossprod(X, W %*% Pz %*% X)

  beta <- solve(A, crossprod(X, W %*% Pz %*% outcome))
  residual <- as.numeric(outcome - X %*% beta)

  weighted_Z <- Z * weight
  meat <- crossprod(weighted_Z, weighted_Z * (residual^2))
  middle <- solve(ZWZ, meat) %*% solve(ZWZ)
  bread_left <- solve(A, crossprod(X, W %*% Z))
  bread_right <- crossprod(Z, W %*% X) %*% solve(A)

  vcov <- bread_left %*% middle %*% bread_right
  vcov <- vcov * n / (n - ncol(X))

  list(coef = beta, se = sqrt(diag(vcov)))
}

effect_fit <- iv_hc1(ybar, xbar, shock, s)
first_stage_fit <- iv_hc1(xbar, zbar, shock, s)

n_industries <- length(s)
effective_shocks <- 1 / sum(s^2)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(
      term = "effect",
      estimate = unname(effect_fit$coef[2]),
      se = unname(effect_fit$se[2]),
      n_obs = n_industries
    ),
    list(
      term = "first_stage",
      estimate = unname(first_stage_fit$coef[2]),
      se = unname(first_stage_fit$se[2]),
      n_obs = n_industries
    ),
    list(
      term = "effective_shocks",
      estimate = effective_shocks,
      se = NULL,
      n_obs = n_industries
    )
  ),
  method_metadata = list(
    estimator = "Weighted shock-level 2SLS with industry shocks",
    vcov = "Shock-level heteroskedasticity-robust HC1, multiplier N/(N-2)"
  ),
  diagnostics = list()
)

if (requireNamespace("jsonlite", quietly = TRUE)) {
  jsonlite::write_json(result, "result.json", auto_unbox = TRUE,
                       null = "null", digits = 17)
} else {
  esc <- function(x) {
    x <- gsub("\\\\", "\\\\\\\\", x)
    gsub('"', '\\"', x, fixed = TRUE)
  }
  num <- function(x) {
    if (is.null(x)) "null" else format(x, digits = 17, scientific = FALSE,
                                       trim = TRUE)
  }
  txt <- paste0(
    '{',
    '"task_id":"applied_shift_share",',
    '"platform":"r",',
    '"estimates":[',
    '{"term":"effect","estimate":', num(effect_fit$coef[2]),
    ',"se":', num(effect_fit$se[2]),
    ',"n_obs":', n_industries, '},',
    '{"term":"first_stage","estimate":', num(first_stage_fit$coef[2]),
    ',"se":', num(first_stage_fit$se[2]),
    ',"n_obs":', n_industries, '},',
    '{"term":"effective_shocks","estimate":', num(effective_shocks),
    ',"se":null,"n_obs":', n_industries, '}',
    '],',
    '"method_metadata":{"estimator":"Weighted shock-level 2SLS with industry shocks",',
    '"vcov":"Shock-level heteroskedasticity-robust HC1, multiplier N/(N-2)"},',
    '"diagnostics":{}',
    '}'
  )
  writeLines(txt, "result.json")
}
