library(jsonlite)

data <- read.csv("input.csv", stringsAsFactors = FALSE)
data$date <- as.Date(data$date)
data <- data[order(data$date), ]

vol_change <- c(NA_real_, diff(log(data$vix)))
log_sales <- log(data$sales)

n_total <- nrow(data)
usable <- (16 + 1):n_total

sample <- data.frame(
  log_sales = log_sales[usable],
  lag_1 = vol_change[usable - 1],
  lag_2 = vol_change[usable - 2],
  lag_3 = vol_change[usable - 3],
  lag_4 = vol_change[usable - 4],
  lag_5 = vol_change[usable - 5],
  lag_6 = vol_change[usable - 6],
  lag_7 = vol_change[usable - 7],
  lag_8 = vol_change[usable - 8],
  lag_9 = vol_change[usable - 9],
  lag_10 = vol_change[usable - 10],
  lag_11 = vol_change[usable - 11],
  lag_12 = vol_change[usable - 12],
  lag_13 = vol_change[usable - 13],
  lag_14 = vol_change[usable - 14],
  lag_15 = vol_change[usable - 15]
)

sample <- sample[complete.cases(sample), ]
fit <- lm(log_sales ~ ., data = sample)

X <- model.matrix(fit)
u <- residuals(fit)
N <- nrow(X)
p <- ncol(X)
scores <- X * u

hac_lags <- 15
meat <- crossprod(scores)

for (j in seq_len(hac_lags)) {
  lag_product <- crossprod(
    scores[(j + 1):N, , drop = FALSE],
    scores[1:(N - j), , drop = FALSE]
  )
  weight <- 1 - j / 16
  meat <- meat + weight * (lag_product + t(lag_product))
}

bread <- solve(crossprod(X))
covariance <- (N / (N - 16)) * bread %*% meat %*% bread
coefficient <- coef(fit)

contrast <- c(0, rep(1, 15))
cumulative_response <- sum(contrast * coefficient)
cumulative_se <- sqrt(drop(t(contrast) %*% covariance %*% contrast))

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(
      term = "cumulative_response",
      estimate = unname(as.numeric(cumulative_response)),
      se = unname(as.numeric(cumulative_se)),
      n_obs = as.integer(N)
    ),
    list(
      term = "lag_1",
      estimate = unname(as.numeric(coefficient["lag_1"])),
      se = unname(as.numeric(sqrt(covariance["lag_1", "lag_1"]))),
      n_obs = as.integer(N)
    ),
    list(
      term = "lag_15",
      estimate = unname(as.numeric(coefficient["lag_15"])),
      se = unname(as.numeric(sqrt(covariance["lag_15", "lag_15"]))),
      n_obs = as.integer(N)
    )
  ),
  method_metadata = list(
    estimator = "OLS with intercept and fifteen lagged log volatility changes",
    vcov = "Bartlett Newey-West HAC, maximum lag 15, correction N/(N-16)"
  ),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, digits = 16, pretty = TRUE)
