dat <- read.csv("input.csv", stringsAsFactors = FALSE)
dat <- dat[order(as.Date(dat$date)), ]

log_sales <- log(dat$sales)
delta_vix <- diff(log(dat$vix))

n <- nrow(dat)
idx <- 16:n
N <- length(idx)

y <- log_sales[idx]
X <- cbind(
  intercept = 1,
  lag_1 = delta_vix[idx - 1],
  lag_2 = delta_vix[idx - 2],
  lag_3 = delta_vix[idx - 3],
  lag_4 = delta_vix[idx - 4],
  lag_5 = delta_vix[idx - 5],
  lag_6 = delta_vix[idx - 6],
  lag_7 = delta_vix[idx - 7],
  lag_8 = delta_vix[idx - 8],
  lag_9 = delta_vix[idx - 9],
  lag_10 = delta_vix[idx - 10],
  lag_11 = delta_vix[idx - 11],
  lag_12 = delta_vix[idx - 12],
  lag_13 = delta_vix[idx - 13],
  lag_14 = delta_vix[idx - 14],
  lag_15 = delta_vix[idx - 15]
)

fit <- lm.fit(x = X, y = y)
beta <- as.numeric(fit$coefficients)
resid <- as.numeric(fit$residuals)

bread <- solve(crossprod(X))
omega <- crossprod(X, X * resid^2)

max_lag <- 15
for (j in seq_len(max_lag)) {
  weight <- 1 - j / 16
  if (j < N) {
    x_lead <- X[(j + 1):N, , drop = FALSE]
    x_lag <- X[1:(N - j), , drop = FALSE]
    e_lead <- resid[(j + 1):N]
    e_lag <- resid[1:(N - j)]
    
    cross_term <- crossprod(x_lead, x_lag * e_lead * e_lag)
    omega <- omega + weight * (cross_term + t(cross_term))
  }
}

vcov_nw <- (N / (N - 16)) * bread %*% omega %*% bread
se <- sqrt(pmax(diag(vcov_nw), 0))

cumulative_weights <- c(0, rep(1, 15))
cumulative_estimate <- sum(beta[-1])
cumulative_se <- sqrt(as.numeric(
  t(cumulative_weights) %*% vcov_nw %*% cumulative_weights
))

fmt_num <- function(x) {
  if (is.na(x) || is.nan(x) || is.infinite(x)) "null"
  else format(x, scientific = TRUE, digits = 15, trim = TRUE)
}

result_text <- paste0(
  '{',
  '"task_id":"applied_cumulative_hac",',
  '"platform":"r",',
  '"estimates":[',
  '{"term":"cumulative_response","estimate":', fmt_num(cumulative_estimate),
  ',"se":', fmt_num(cumulative_se), ',"n_obs":', N, '},',
  '{"term":"lag_1","estimate":', fmt_num(beta[2]),
  ',"se":', fmt_num(se[2]), ',"n_obs":', N, '},',
  '{"term":"lag_15","estimate":', fmt_num(beta[16]),
  ',"se":', fmt_num(se[16]), ',"n_obs":', N, '}',
  '],',
  '"method_metadata":{',
  '"estimator":"OLS with intercept and 15 trading-observation lags",',
  '"vcov":"Newey-West HAC, Bartlett weights through lag 15, scaled by N/(N-16)"',
  '},',
  '"diagnostics":{}',
  '}'
)

writeLines(result_text, "result.json")
