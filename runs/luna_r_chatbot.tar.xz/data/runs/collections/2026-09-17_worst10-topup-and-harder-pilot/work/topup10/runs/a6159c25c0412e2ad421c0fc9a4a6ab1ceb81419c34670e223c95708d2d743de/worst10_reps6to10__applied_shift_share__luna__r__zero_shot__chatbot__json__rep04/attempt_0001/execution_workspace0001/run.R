d <- read.csv("input.csv", stringsAsFactors = FALSE)

region_ids <- unique(d$region_id)
region_info <- d[match(region_ids, d$region_id), c("region_id", "region_weight")]
e <- region_info$region_weight / sum(region_info$region_weight)

d$e <- e[match(d$region_id, region_ids)]

wmean <- function(v, w) sum(w * v) / sum(w)

y_mean <- wmean(d$y, d$e)
x_mean <- wmean(d$x, d$e)

z_region <- aggregate(
  share * shock,
  by = list(region_id = d$region_id),
  FUN = sum
)
names(z_region)[2] <- "z"

d <- merge(d, z_region, by = "region_id", sort = FALSE)

z_mean <- wmean(d$z, d$e)

region_data <- d[!duplicated(d$region_id), c("region_id", "e", "x", "y", "z")]
region_data$y0 <- region_data$y - y_mean
region_data$x0 <- region_data$x - x_mean
region_data$z0 <- region_data$z - z_mean

industry_data <- aggregate(
  cbind(e_share = d$e * d$share,
        ey = d$e * d$share * (d$y - y_mean),
        ex = d$e * d$share * (d$x - x_mean),
        ez = d$e * d$share * (d$z - z_mean)),
  by = list(industry_id = d$industry_id, shock = d$shock),
  FUN = sum
)

industry_data$s <- industry_data$e_share
industry_data$ybar <- industry_data$ey / industry_data$s
industry_data$xbar <- industry_data$ex / industry_data$s
industry_data$zbar <- industry_data$ez / industry_data$s

industry_data <- industry_data[is.finite(industry_data$s) & industry_data$s > 0, ]
N <- nrow(industry_data)

iv_fit <- function(y, endogenous, instrument, weight) {
  X <- cbind(1, endogenous)
  Z <- cbind(1, instrument)
  W <- diag(weight, nrow = length(weight))
  
  ZWZ <- crossprod(Z, W %*% Z)
  ZWZ_inv <- solve(ZWZ)
  A <- crossprod(X, W %*% Z) %*% ZWZ_inv %*% crossprod(Z, W %*% X)
  A_inv <- solve(A)
  
  beta <- A_inv %*%
    crossprod(X, W %*% Z) %*% ZWZ_inv %*%
    crossprod(Z, W %*% y)
  
  residual <- as.vector(y - X %*% beta)
  
  meat <- crossprod(
    Z,
    (weight^2 * residual^2) * Z
  )
  
  middle <- ZWZ_inv %*% meat %*% ZWZ_inv
  vcov <- A_inv %*%
    crossprod(X, W %*% Z) %*% middle %*%
    crossprod(Z, W %*% X) %*% A_inv
  
  vcov <- vcov * N / (N - 2)
  
  list(
    estimate = as.numeric(beta[2]),
    se = sqrt(as.numeric(vcov[2, 2]))
  )
}

effect_fit <- iv_fit(
  y = industry_data$ybar,
  endogenous = industry_data$xbar,
  instrument = industry_data$shock,
  weight = industry_data$s
)

first_stage_fit <- iv_fit(
  y = industry_data$xbar,
  endogenous = industry_data$zbar,
  instrument = industry_data$shock,
  weight = industry_data$s
)

effective_shocks <- 1 / sum(industry_data$s^2)

fmt <- function(x) {
  if (is.null(x) || is.na(x)) "null" else formatC(x, digits = 15, format = "fg", flag = "#")
}

json <- paste0(
  "{\n",
  '  "task_id": "applied_shift_share",\n',
  '  "platform": "r",\n',
  '  "estimates": [\n',
  '    {"term": "effect", "estimate": ', fmt(effect_fit$estimate),
  ', "se": ', fmt(effect_fit$se), ', "n_obs": ', N, '},\n',
  '    {"term": "first_stage", "estimate": ', fmt(first_stage_fit$estimate),
  ', "se": ', fmt(first_stage_fit$se), ', "n_obs": ', N, '},\n',
  '    {"term": "effective_shocks", "estimate": ', fmt(effective_shocks),
  ', "se": null, "n_obs": ', N, '}\n',
  '  ],\n',
  '  "method_metadata": {\n',
  '    "estimator": "shock-level weighted 2SLS with analytic weights",\n',
  '    "vcov": "shock-level heteroskedasticity-robust HC1"\n',
  '  },\n',
  '  "diagnostics": {}\n',
  "}\n"
)

writeLines(json, "result.json")
