dat <- read.csv("input.csv", stringsAsFactors = FALSE)

dat <- dat[order(dat$date), ]
n <- nrow(dat)

dlog_vix <- c(NA_real_, diff(log(dat$vix)))
log_sales <- log(dat$sales)

idx <- 17:n
y <- log_sales[idx]

X <- cbind(
  intercept = 1,
  lag_1 = dlog_vix[idx - 1],
  lag_2 = dlog_vix[idx - 2],
  lag_3 = dlog_vix[idx - 3],
  lag_4 = dlog_vix[idx - 4],
  lag_5 = dlog_vix[idx - 5],
  lag_6 = dlog_vix[idx - 6],
  lag_7 = dlog_vix[idx - 7],
  lag_8 = dlog_vix[idx - 8],
  lag_9 = dlog_vix[idx - 9],
  lag_10 = dlog_vix[idx - 10],
  lag_11 = dlog_vix[idx - 11],
  lag_12 = dlog_vix[idx - 12],
  lag_13 = dlog_vix[idx - 13],
  lag_14 = dlog_vix[idx - 14],
  lag_15 = dlog_vix[idx - 15]
)

complete <- complete.cases(y, X)
y <- y[complete]
X <- X[complete, , drop = FALSE]

N <- nrow(X)
K <- ncol(X)

fit <- lm.fit(x = X, y = y)
beta <- as.numeric(fit$coefficients)
resid <- as.numeric(y - X %*% beta)

bread <- solve(crossprod(X))
meat <- matrix(0, K, K)

for (j in 0:15) {
  weight <- if (j == 0) 1 else 1 - j / 16
  
  if (j == 0) {
    for (i in seq_len(N)) {
      xi <- X[i, , drop = FALSE]
      meat <- meat + as.numeric(resid[i]^2) * crossprod(xi)
    }
  } else {
    for (i in (j + 1):N) {
      xi <- X[i, , drop = FALSE]
      xj <- X[i - j, , drop = FALSE]
      cross_term <- as.numeric(resid[i] * resid[i - j]) *
        (t(xi) %*% xj + t(xj) %*% xi)
      meat <- meat + weight * cross_term
    }
  }
}

vcov_hac <- bread %*% meat %*% bread
vcov_hac <- vcov_hac * N / (N - 16)

cumulative_response <- sum(beta[2:16])
cumulative_se <- sqrt(sum(vcov_hac[2:16, 2:16]))

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(
      term = "cumulative_response",
      estimate = cumulative_response,
      se = cumulative_se,
      n_obs = as.integer(N)
    ),
    list(
      term = "lag_1",
      estimate = beta[2],
      se = sqrt(vcov_hac[2, 2]),
      n_obs = as.integer(N)
    ),
    list(
      term = "lag_15",
      estimate = beta[16],
      se = sqrt(vcov_hac[16, 16]),
      n_obs = as.integer(N)
    )
  ),
  method_metadata = list(
    estimator = "OLS with intercept and lags 1 through 15 of first-differenced log volatility",
    vcov = "Newey-West HAC, maximum lag 15, Bartlett weights, multiplied by N/(N-16)"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = 17)
