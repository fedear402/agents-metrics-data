library(jsonlite)

dat <- read.csv("input.csv", stringsAsFactors = FALSE)

regions <- unique(dat$region_id)
industries <- unique(dat$industry_id)

region_data <- do.call(rbind, lapply(regions, function(r) {
  d <- dat[dat$region_id == r, ]
  data.frame(
    region_id = r,
    region_weight = d$region_weight[1],
    x = d$x[1],
    y = d$y[1],
    z = sum(d$share * d$shock)
  )
}))

e <- region_data$region_weight / sum(region_data$region_weight)

industry_data <- do.call(rbind, lapply(industries, function(n) {
  d <- dat[dat$industry_id == n, ]
  data.frame(
    industry_id = n,
    shock = d$shock[1],
    s = sum(e[match(d$region_id, region_data$region_id)] * d$share)
  )
}))

shares <- matrix(
  0,
  nrow = nrow(region_data),
  ncol = nrow(industry_data),
  dimnames = list(region_data$region_id, industry_data$industry_id)
)

for (i in seq_len(nrow(dat))) {
  r <- match(dat$region_id[i], region_data$region_id)
  n <- match(dat$industry_id[i], industry_data$industry_id)
  shares[r, n] <- shares[r, n] + dat$share[i]
}

weighted_mean <- function(v) {
  sum(e * v)
}

y0 <- region_data$y - weighted_mean(region_data$y)
x0 <- region_data$x - weighted_mean(region_data$x)
z0 <- region_data$z - weighted_mean(region_data$z)

mass <- industry_data$s
shock <- industry_data$shock

aggregate_exposure <- function(v0) {
  numerator <- drop(t(shares) %*% (e * v0))
  numerator / mass
}

ybar <- aggregate_exposure(y0)
xbar <- aggregate_exposure(x0)
zbar <- aggregate_exposure(z0)

shock_iv <- function(dependent, endogenous) {
  regressors <- cbind(1, endogenous)
  instruments <- cbind(1, shock)

  cross <- crossprod(instruments, mass * regressors)
  beta <- solve(
    cross,
    crossprod(instruments, mass * dependent)
  )

  residual <- drop(dependent - regressors %*% beta)
  scores <- instruments * (mass * residual)
  inverse <- solve(cross)

  n_industries <- length(shock)
  covariance <- n_industries / (n_industries - 2) *
    inverse %*% crossprod(scores) %*% t(inverse)

  c(
    estimate = beta[2],
    se = sqrt(covariance[2, 2])
  )
}

effect_result <- shock_iv(ybar, xbar)
first_stage_result <- shock_iv(xbar, zbar)

effective_shocks <- 1 / sum(mass^2)
n_industries <- length(shock)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(
      term = "effect",
      estimate = unname(as.numeric(effect_result["estimate"])),
      se = unname(as.numeric(effect_result["se"])),
      n_obs = as.integer(n_industries)
    ),
    list(
      term = "first_stage",
      estimate = unname(as.numeric(first_stage_result["estimate"])),
      se = unname(as.numeric(first_stage_result["se"])),
      n_obs = as.integer(n_industries)
    ),
    list(
      term = "effective_shocks",
      estimate = unname(as.numeric(effective_shocks)),
      se = NULL,
      n_obs = as.integer(n_industries)
    )
  ),
  method_metadata = list(
    estimator = "weighted shock-level IV with intercept",
    vcov = "shock-level HC1, multiplier N/(N-2)"
  ),
  diagnostics = list()
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
