d <- read.csv("input.csv", stringsAsFactors = FALSE)

d <- d[order(as.Date(d$date)), ]
log_sales <- log(d$sales)
dlog_vix <- diff(log(d$vix))

n_total <- nrow(d)
lag_matrix <- sapply(1:15, function(k) {
  dlog_vix[(16 - k):(length(dlog_vix) - k)]
})

y <- log_sales[17:n_total]
x <- cbind("(Intercept)" = 1, lag_matrix)
colnames(x) <- c("(Intercept)", paste0("lag_", 1:15))

complete <- complete.cases(y, x)
y <- y[complete]
x <- x[complete, , drop = FALSE]

n_obs <- nrow(x)
beta <- solve(crossprod(x), crossprod(x, y))
resid <- as.vector(y - x %*% beta)

bread <- solve(crossprod(x))
meat <- matrix(0, ncol = ncol(x), nrow = ncol(x))

for (t in seq_len(n_obs)) {
  meat <- meat + resid[t]^2 * tcrossprod(x[t, ])
}

for (j in 1:15) {
  weight <- 1 - j / 16
  for (t in (j + 1):n_obs) {
    meat <- meat +
      weight * resid[t] * resid[t - j] *
      (tcrossprod(x[t, ], x[t - j, ]) +
         tcrossprod(x[t - j, ], x[t, ]))
  }
}

vcov_hac <- bread %*% meat %*% bread
vcov_hac <- vcov_hac * n_obs / (n_obs - 16)

cumulative_weights <- c(0, rep(1, 15))
cumulative_estimate <- sum(beta[2:16])
cumulative_se <- sqrt(as.numeric(
  t(cumulative_weights) %*% vcov_hac %*% cumulative_weights
))

lag1_estimate <- beta[2]
lag1_se <- sqrt(vcov_hac[2, 2])

lag15_estimate <- beta[16]
lag15_se <- sqrt(vcov_hac[16, 16])

fmt <- function(x) sprintf("%.17g", as.numeric(x))

json <- paste0(
  "{\n",
  '  "task_id": "applied_cumulative_hac",',
  "\n",
  '  "platform": "r",',
  "\n",
  '  "estimates": [',
  "\n",
  '    {"term": "cumulative_response", "estimate": ', fmt(cumulative_estimate),
  ', "se": ', fmt(cumulative_se), ', "n_obs": ', n_obs, "},",
  "\n",
  '    {"term": "lag_1", "estimate": ', fmt(lag1_estimate),
  ', "se": ', fmt(lag1_se), ', "n_obs": ', n_obs, "},",
  "\n",
  '    {"term": "lag_15", "estimate": ', fmt(lag15_estimate),
  ', "se": ', fmt(lag15_se), ', "n_obs": ', n_obs, "}",
  "\n",
  "  ],\n",
  '  "method_metadata": {"estimator": "OLS with 15 trading-observation lags", "vcov": "Newey-West HAC, Bartlett weights, maximum lag 15, scaled by N/(N-16)"},',
  "\n",
  '  "diagnostics": {}',
  "\n",
  "}\n"
)

writeLines(json, "result.json")
