d <- read.csv("input.csv", stringsAsFactors = FALSE)

d$date_order <- as.Date(d$date)
d <- d[order(d$date_order), ]

log_vix <- log(d$vix)
delta_vix <- c(NA_real_, diff(log_vix))
log_sales <- log(d$sales)

n_total <- nrow(d)
idx <- 17:n_total

y <- log_sales[idx]
X <- cbind(
  "(Intercept)" = 1,
  sapply(1:15, function(k) delta_vix[idx - k])
)
colnames(X)[2:16] <- paste0("lag_", 1:15)

complete <- complete.cases(y, X)
y <- y[complete]
X <- X[complete, , drop = FALSE]

n <- nrow(X)
p <- ncol(X)

beta <- solve(crossprod(X), crossprod(X, y))
resid <- as.vector(y - X %*% beta)

S <- matrix(0, p, p)

for (j in 0:15) {
  weight <- 1 - j / 16
  
  if (j == 0) {
    z <- X * resid
    S <- S + crossprod(z)
  } else {
    z_current <- X[(j + 1):n, , drop = FALSE] * resid[(j + 1):n]
    z_lagged <- X[1:(n - j), , drop = FALSE] * resid[1:(n - j)]
    cross_term <- crossprod(z_current, z_lagged)
    S <- S + weight * (cross_term + t(cross_term))
  }
}

bread <- solve(crossprod(X))
vcov_hac <- bread %*% S %*% bread
vcov_hac <- vcov_hac * n / (n - 16)
se_beta <- sqrt(pmax(diag(vcov_hac), 0))

cumulative_weights <- c(0, rep(1, 15))
cumulative_estimate <- sum(beta[2:16])
cumulative_se <- sqrt(as.numeric(
  t(cumulative_weights) %*% vcov_hac %*% cumulative_weights
))

fmt_num <- function(x) {
  if (is.finite(x)) sprintf("%.15g", x) else "null"
}

json <- paste0(
  "{\n",
  '  "task_id": "applied_cumulative_hac",\n',
  '  "platform": "r",\n',
  '  "estimates": [\n',
  '    {"term": "cumulative_response", "estimate": ', fmt_num(cumulative_estimate),
  ', "se": ', fmt_num(cumulative_se), ', "n_obs": ', n, '},\n',
  '    {"term": "lag_1", "estimate": ', fmt_num(beta[2]),
  ', "se": ', fmt_num(se_beta[2]), ', "n_obs": ', n, '},\n',
  '    {"term": "lag_15", "estimate": ', fmt_num(beta[16]),
  ', "se": ', fmt_num(se_beta[16]), ', "n_obs": ', n, '}\n',
  "  ],\n",
  '  "method_metadata": {"estimator": "OLS with intercept and 15 trading-observation lags", ',
  '"vcov": "Newey-West HAC with maximum lag 15, Bartlett weights, and N/(N-16) correction"},\n',
  '  "diagnostics": {}\n',
  "}\n"
)

writeLines(json, "result.json")
