library(jsonlite)

dat <- read.csv("input.csv", stringsAsFactors = FALSE)

regions <- unique(dat$region_id)
industries <- unique(dat$industry_id)

R <- length(regions)
N <- length(industries)

region_index <- match(dat$region_id, regions)
industry_index <- match(dat$industry_id, industries)

region_weight_raw <- tapply(dat$region_weight, region_index, function(v) v[1])
e <- as.numeric(region_weight_raw / sum(region_weight_raw))

x <- as.numeric(tapply(dat$x, region_index, function(v) v[1]))
y <- as.numeric(tapply(dat$y, region_index, function(v) v[1]))

shock <- numeric(N)
shock_values <- tapply(dat$shock, industry_index, function(v) v[1])
shock[] <- as.numeric(shock_values)

shares <- matrix(
  0,
  nrow = R,
  ncol = N,
  dimnames = list(as.character(regions), as.character(industries))
)
shares[cbind(region_index, industry_index)] <- dat$share

z <- drop(shares %*% shock)

weighted_mean <- function(v, weights) {
  sum(weights * v)
}

y0 <- y - weighted_mean(y, e)
x0 <- x - weighted_mean(x, e)
z0 <- z - weighted_mean(z, e)

s <- drop(crossprod(e, shares))

valid <- s > 0
s_used <- s[valid]
shock_used <- shock[valid]

aggregate_exposure <- function(v0) {
  drop(crossprod(shares[, valid], e * v0)) / s_used
}

ybar <- aggregate_exposure(y0)
xbar <- aggregate_exposure(x0)
zbar <- aggregate_exposure(z0)

shock_iv <- function(dependent, endogenous, instrument, weights) {
  regressors <- cbind(1, endogenous)
  instruments <- cbind(1, instrument)

  cross <- crossprod(instruments, weights * regressors)
  inverse_cross <- solve(cross)

  beta <- drop(
    inverse_cross %*%
      crossprod(instruments, weights * dependent)
  )

  residual <- drop(dependent - regressors %*% beta)
  scores <- instruments * (weights * residual)

  covariance <- length(weights) / (length(weights) - 2) *
    inverse_cross %*% crossprod(scores) %*% t(inverse_cross)

  list(
    estimate = beta[2],
    se = sqrt(covariance[2, 2])
  )
}

effect_fit <- shock_iv(
  dependent = ybar,
  endogenous = xbar,
  instrument = shock_used,
  weights = s_used
)

first_stage_fit <- shock_iv(
  dependent = xbar,
  endogenous = zbar,
  instrument = shock_used,
  weights = s_used
)

effective_shocks <- 1 / sum(s_used^2)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(
      term = "effect",
      estimate = unname(as.numeric(effect_fit$estimate)),
      se = unname(as.numeric(effect_fit$se)),
      n_obs = as.integer(length(s_used))
    ),
    list(
      term = "first_stage",
      estimate = unname(as.numeric(first_stage_fit$estimate)),
      se = unname(as.numeric(first_stage_fit$se)),
      n_obs = as.integer(length(s_used))
    ),
    list(
      term = "effective_shocks",
      estimate = unname(as.numeric(effective_shocks)),
      se = NULL,
      n_obs = as.integer(length(s_used))
    )
  ),
  method_metadata = list(
    estimator = "Shock-level weighted IV with regional shift-share aggregation",
    vcov = "HC1 exposure-robust covariance using structural IV residuals"
  ),
  diagnostics = list()
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
