library(jsonlite)

dat <- read.csv("input.csv")

keep <- abs(dat$score) < 1
dat <- dat[keep, , drop = FALSE]

score <- dat$score
right <- as.numeric(score >= 0)
weights <- 1 - abs(score)

X <- cbind(
  intercept = 1,
  right = right,
  score = score,
  right_score = right * score
)

Y <- cbind(
  earnings = dat$earnings,
  participated = dat$participated
)

W <- diag(weights)
bread <- solve(crossprod(X, W %*% X))
beta <- bread %*% crossprod(X, W %*% Y)
residuals <- Y - X %*% beta

contrast <- c(0, 1, 0, 0)
discontinuities <- drop(contrast %*% beta)

loading <- drop(X %*% bread %*% contrast)
influence <- loading * weights * residuals
joint_covariance <- crossprod(influence)

reduced_form <- discontinuities[1]
first_stage <- discontinuities[2]
treatment_effect <- reduced_form / first_stage

gradient <- c(
  1 / first_stage,
  -reduced_form / first_stage^2
)

treatment_variance <- drop(
  t(gradient) %*% joint_covariance %*% gradient
)

n_obs <- nrow(dat)

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(
      term = "treatment_effect",
      estimate = unname(as.numeric(treatment_effect)),
      se = unname(as.numeric(sqrt(treatment_variance))),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "reduced_form",
      estimate = unname(as.numeric(reduced_form)),
      se = unname(as.numeric(sqrt(joint_covariance[1, 1]))),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "first_stage",
      estimate = unname(as.numeric(first_stage)),
      se = unname(as.numeric(sqrt(joint_covariance[2, 2]))),
      n_obs = as.integer(n_obs)
    )
  ),
  method_metadata = list(
    estimator = "weighted local-linear fuzzy regression discontinuity",
    vcov = "conventional heteroskedasticity-robust HC0 with joint delta-method covariance"
  ),
  diagnostics = list()
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  digits = 16,
  pretty = TRUE,
  null = "null"
)
