library(jsonlite)

data <- read.csv("input.csv", stringsAsFactors = FALSE)
data$date <- as.Date(data$date)
data <- data[order(data$date), ]

data$log_sales <- log(data$sales)
data$vol_change <- c(NA, diff(log(data$vix)))

for (j in 1:15) {
  data[[paste0("lag_", j)]] <- c(
    rep(NA, j + 1),
    head(data$vol_change, -j - 1)
  )
}

regressors <- paste0("lag_", 1:15)
sample <- data[complete.cases(data[, c("log_sales", regressors)]), ]

fit <- lm(
  log_sales ~ lag_1 + lag_2 + lag_3 + lag_4 + lag_5 +
    lag_6 + lag_7 + lag_8 + lag_9 + lag_10 +
    lag_11 + lag_12 + lag_13 + lag_14 + lag_15,
  data = sample
)

X <- model.matrix(fit)
beta <- coef(fit)
residuals <- residuals(fit)
N <- nrow(X)
p <- ncol(X)

scores <- X * residuals
meat <- crossprod(scores)

hac_lags <- 15
for (j in 1:hac_lags) {
  lag_product <- crossprod(
    scores[(j + 1):N, , drop = FALSE],
    scores[1:(N - j), , drop = FALSE]
  )
  weight <- 1 - j / 16
  meat <- meat + weight * (lag_product + t(lag_product))
}

bread <- solve(crossprod(X))
covariance <- (N / (N - 16)) * bread %*% meat %*% bread

contrast <- c(0, rep(1, 15))
cumulative <- sum(contrast * beta)
cumulative_se <- sqrt(drop(t(contrast) %*% covariance %*% contrast))

lag1_index <- which(names(beta) == "lag_1")
lag15_index <- which(names(beta) == "lag_15")

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(
      term = "cumulative_response",
      estimate = unname(as.numeric(cumulative)),
      se = unname(as.numeric(cumulative_se)),
      n_obs = as.integer(N)
    ),
    list(
      term = "lag_1",
      estimate = unname(as.numeric(beta[lag1_index])),
      se = unname(as.numeric(sqrt(covariance[lag1_index, lag1_index]))),
      n_obs = as.integer(N)
    ),
    list(
      term = "lag_15",
      estimate = unname(as.numeric(beta[lag15_index])),
      se = unname(as.numeric(sqrt(covariance[lag15_index, lag15_index]))),
      n_obs = as.integer(N)
    )
  ),
  method_metadata = list(
    estimator = "OLS with intercept and lags 1 through 15 of log volatility changes",
    vcov = "Bartlett Newey-West HAC covariance, maximum lag 15, correction N/(N-16)"
  ),
  diagnostics = list()
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  digits = 16,
  pretty = TRUE
)
