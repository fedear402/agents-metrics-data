input <- read.csv("input.csv", stringsAsFactors = FALSE)

required <- c("region_id", "industry_id", "share", "shock",
              "region_weight", "x", "y")
missing <- setdiff(required, names(input))
if (length(missing) > 0) stop("Missing required columns")

region_key <- !duplicated(input$region_id)
regions <- input[region_key, c("region_id", "region_weight", "x", "y")]
rownames(regions) <- as.character(regions$region_id)

if (anyDuplicated(input$region_id[!duplicated(input[, c("region_id", "x", "y")])])) {
  stop("Regional variables are not constant within region")
}

regions$e <- regions$region_weight / sum(regions$region_weight)

shock_by_industry <- tapply(input$shock, input$industry_id, function(v) {
  if (length(unique(v)) != 1) stop("Shock is not constant within industry")
  v[1]
})

input$e <- regions$e[match(input$region_id, regions$region_id)]

z_by_region <- tapply(input$share * input$shock, input$region_id, sum)
regions$z <- as.numeric(z_by_region[as.character(regions$region_id)])

weighted_mean <- function(v, w) sum(w * v) / sum(w)

regions$y0 <- regions$y - weighted_mean(regions$y, regions$e)
regions$x0 <- regions$x - weighted_mean(regions$x, regions$e)
regions$z0 <- regions$z - weighted_mean(regions$z, regions$e)

input$y0 <- regions$y0[match(input$region_id, regions$region_id)]
input$x0 <- regions$x0[match(input$region_id, regions$region_id)]
input$z0 <- regions$z0[match(input$region_id, regions$region_id)]

s_n <- tapply(input$e * input$share, input$industry_id, sum)
ybar <- tapply(input$e * input$share * input$y0, input$industry_id, sum) / s_n
xbar <- tapply(input$e * input$share * input$x0, input$industry_id, sum) / s_n
zbar <- tapply(input$e * input$share * input$z0, input$industry_id, sum) / s_n

valid <- is.finite(s_n) & s_n > 0 &
  is.finite(ybar) & is.finite(xbar) & is.finite(zbar)

s <- as.numeric(s_n[valid])
yb <- as.numeric(ybar[valid])
xb <- as.numeric(xbar[valid])
zb <- as.numeric(zbar[valid])
shock <- as.numeric(shock_by_industry[names(s_n)[valid]])

n_ind <- length(s)

iv_hc1 <- function(y, endogenous, instrument, w) {
  X <- cbind(1, endogenous)
  Z <- cbind(1, instrument)

  WZ <- Z * w
  ZWZ <- crossprod(Z, WZ)
  M <- solve(ZWZ)

  XWZ <- crossprod(X, WZ)
  A <- XWZ %*% M %*% t(XWZ)
  Ainv <- solve(A)

  beta <- Ainv %*% XWZ %*% M %*% crossprod(Z, w * y)
  residual <- as.numeric(y - X %*% beta)

  H <- Ainv %*% XWZ %*% M
  meat <- matrix(0, nrow = ncol(X), ncol = ncol(X))

  for (i in seq_along(y)) {
    gi <- H %*% (Z[i, , drop = FALSE] * w[i])
    meat <- meat + (residual[i]^2) * tcrossprod(gi)
  }

  vcov <- Ainv %*% meat %*% Ainv
  vcov <- vcov * n_ind / (n_ind - ncol(X))
  se <- sqrt(diag(vcov))

  list(beta = as.numeric(beta), se = as.numeric(se))
}

effect_fit <- iv_hc1(yb, xb, shock, s)
first_stage_fit <- iv_hc1(xb, zb, shock, s)

effective_shocks <- 1 / sum(s^2)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(
      term = "effect",
      estimate = effect_fit$beta[2],
      se = effect_fit$se[2],
      n_obs = n_ind
    ),
    list(
      term = "first_stage",
      estimate = first_stage_fit$beta[2],
      se = first_stage_fit$se[2],
      n_obs = n_ind
    ),
    list(
      term = "effective_shocks",
      estimate = effective_shocks,
      se = NULL,
      n_obs = n_ind
    )
  ),
  method_metadata = list(
    estimator = "Borusyak-Hull-Jaravel shock-level weighted IV with analytic weights",
    vcov = "HC1 heteroskedasticity-robust shock-level covariance, multiplier N/(N-2)"
  ),
  diagnostics = list()
)

if (!requireNamespace("jsonlite", quietly = TRUE)) {
  stop("Package jsonlite is required")
}

jsonlite::write_json(result, "result.json", auto_unbox = TRUE,
                     digits = 17, pretty = FALSE, null = "null")
