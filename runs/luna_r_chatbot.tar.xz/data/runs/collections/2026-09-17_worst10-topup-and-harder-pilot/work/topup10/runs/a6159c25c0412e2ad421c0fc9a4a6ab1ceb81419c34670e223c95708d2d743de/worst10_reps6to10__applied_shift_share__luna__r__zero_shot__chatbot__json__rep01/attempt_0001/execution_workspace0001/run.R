d <- read.csv("input.csv", stringsAsFactors = FALSE)

region_rows <- !duplicated(d$region_id)
regions <- d[region_rows, c("region_id", "region_weight", "x", "y")]

regions$e <- regions$region_weight / sum(regions$region_weight)

z_r <- tapply(
  d$share * d$shock,
  d$region_id,
  sum
)

regions$z <- as.numeric(z_r[as.character(regions$region_id)])

weighted_mean <- function(v, w) {
  sum(w * v) / sum(w)
}

regions$y0 <- regions$y - weighted_mean(regions$y, regions$e)
regions$x0 <- regions$x - weighted_mean(regions$x, regions$e)
regions$z0 <- regions$z - weighted_mean(regions$z, regions$e)

region_index <- match(d$region_id, regions$region_id)

s_n <- tapply(
  regions$e[region_index] * d$share,
  d$industry_id,
  sum
)

y_num <- tapply(
  regions$e[region_index] * d$share * regions$y0[region_index],
  d$industry_id,
  sum
)

x_num <- tapply(
  regions$e[region_index] * d$share * regions$x0[region_index],
  d$industry_id,
  sum
)

z_num <- tapply(
  regions$e[region_index] * d$share * regions$z0[region_index],
  d$industry_id,
  sum
)

shock_n <- tapply(d$shock, d$industry_id, function(v) v[1])

keep <- is.finite(s_n) & s_n > 0 &
  is.finite(y_num) & is.finite(x_num) & is.finite(z_num) &
  is.finite(shock_n)

s_n <- as.numeric(s_n[keep])
ybar <- as.numeric(y_num[keep] / s_n)
xbar <- as.numeric(x_num[keep] / s_n)
zbar <- as.numeric(z_num[keep] / s_n)
shock_n <- as.numeric(shock_n[keep])

iv_hc1 <- function(y, endogenous, instrument, weights) {
  n <- length(y)
  X <- cbind(1, endogenous)
  Z <- cbind(1, instrument)
  W <- diag(weights, nrow = n, ncol = n)

  ZwZ <- crossprod(Z, W %*% Z)
  C <- solve(ZwZ)

  A <- crossprod(X, W %*% Z) %*% C %*% crossprod(Z, W %*% X)
  rhs <- crossprod(X, W %*% Z) %*% C %*% crossprod(Z, W %*% y)
  beta <- solve(A, rhs)

  residuals <- as.numeric(y - X %*% beta)

  B <- crossprod(X, W %*% Z) %*% C %*% crossprod(Z, W)
  meat <- B %*% diag(residuals^2, nrow = n, ncol = n) %*% t(B)

  vcov <- solve(A) %*% meat %*% solve(A)
  vcov <- vcov * n / (n - ncol(X))

  list(
    estimate = as.numeric(beta[2]),
    se = sqrt(as.numeric(vcov[2, 2]))
  )
}

n_industries <- length(s_n)

effect_fit <- iv_hc1(
  y = ybar,
  endogenous = xbar,
  instrument = shock_n,
  weights = s_n
)

first_stage_fit <- iv_hc1(
  y = xbar,
  endogenous = zbar,
  instrument = shock_n,
  weights = s_n
)

effective_shocks <- 1 / sum(s_n^2)

json_number <- function(x) {
  if (is.finite(x)) {
    sprintf("%.15g", x)
  } else {
    "null"
  }
}

result_text <- paste0(
  "{\n",
  '  "task_id": "applied_shift_share",\n',
  '  "platform": "r",\n',
  '  "estimates": [\n',
  '    {"term": "effect", "estimate": ', json_number(effect_fit$estimate),
  ', "se": ', json_number(effect_fit$se),
  ', "n_obs": ', n_industries, '},\n',
  '    {"term": "first_stage", "estimate": ', json_number(first_stage_fit$estimate),
  ', "se": ', json_number(first_stage_fit$se),
  ', "n_obs": ', n_industries, '},\n',
  '    {"term": "effective_shocks", "estimate": ', json_number(effective_shocks),
  ', "se": null, "n_obs": ', n_industries, '}\n',
  "  ],\n",
  '  "method_metadata": {"estimator": "shock-level weighted 2SLS", "vcov": "shock-level HC1 heteroskedasticity-robust"},\n',
  '  "diagnostics": {}\n',
  "}\n"
)

writeLines(result_text, "result.json")
