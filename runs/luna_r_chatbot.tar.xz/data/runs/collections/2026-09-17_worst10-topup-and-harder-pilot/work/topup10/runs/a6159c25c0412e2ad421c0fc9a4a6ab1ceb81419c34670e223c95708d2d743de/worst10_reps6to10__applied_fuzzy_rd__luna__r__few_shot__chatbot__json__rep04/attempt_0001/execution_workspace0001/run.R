#!/usr/bin/env Rscript

library(jsonlite)

dat <- read.csv("input.csv", stringsAsFactors = FALSE)

keep <- abs(dat$score) < 1
d <- dat[keep, , drop = FALSE]

x <- d$score
above <- as.numeric(x >= 0)
w <- 1 - abs(x)

X <- cbind(
  intercept = 1,
  side = above,
  score_left = x * (1 - above),
  score_right = x * above
)

W <- diag(w)
bread <- solve(crossprod(X, W %*% X))

Y <- cbind(
  earnings = d$earnings,
  participated = d$participated
)

beta <- bread %*% crossprod(X, W %*% Y)
resid <- Y - X %*% beta

meat <- matrix(0, nrow = ncol(X), ncol = ncol(X))
for (i in seq_len(nrow(X))) {
  xi <- X[i, , drop = FALSE]
  meat <- meat + w[i]^2 * crossprod(xi) * tcrossprod(resid[i, ])
}

vcov_joint <- matrix(0, 2, 2)

for (j in seq_len(2)) {
  for (k in seq_len(2)) {
    contribution <- matrix(0, nrow = ncol(X), ncol = ncol(X))
    for (i in seq_len(nrow(X))) {
      xi <- X[i, , drop = FALSE]
      contribution <- contribution +
        w[i]^2 * resid[i, j] * resid[i, k] * crossprod(xi)
    }
    vcov_joint[j, k] <- drop(
      c(0, 1, 0, 0) %*% bread %*% contribution %*%
        bread %*% c(0, 1, 0, 0)
    )
  }
}

discontinuities <- as.numeric(beta[2, ])
se_discontinuities <- sqrt(diag(vcov_joint))

ratio <- discontinuities[1] / discontinuities[2]
gradient <- c(
  1 / discontinuities[2],
  -discontinuities[1] / discontinuities[2]^2
)
ratio_se <- sqrt(drop(t(gradient) %*% vcov_joint %*% gradient))

n_obs <- nrow(d)

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(
      term = "treatment_effect",
      estimate = unname(ratio),
      se = unname(ratio_se),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "reduced_form",
      estimate = unname(discontinuities[1]),
      se = unname(se_discontinuities[1]),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "first_stage",
      estimate = unname(discontinuities[2]),
      se = unname(se_discontinuities[2]),
      n_obs = as.integer(n_obs)
    )
  ),
  method_metadata = list(
    estimator = "weighted local-linear fuzzy regression discontinuity",
    vcov = "HC0"
  ),
  diagnostics = list()
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  digits = 16,
  pretty = TRUE,
  null = "null"
)
