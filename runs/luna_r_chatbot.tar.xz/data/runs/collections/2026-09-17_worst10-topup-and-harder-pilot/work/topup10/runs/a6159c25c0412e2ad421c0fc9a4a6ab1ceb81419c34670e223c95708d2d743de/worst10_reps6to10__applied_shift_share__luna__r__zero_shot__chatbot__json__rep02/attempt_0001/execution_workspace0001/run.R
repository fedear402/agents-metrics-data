dat <- read.csv("input.csv", stringsAsFactors = FALSE)

region_rows <- !duplicated(dat$region_id)
regions <- dat[region_rows, c("region_id", "region_weight", "x", "y")]
regions$e <- regions$region_weight / sum(regions$region_weight)

dat$e <- regions$e[match(dat$region_id, regions$region_id)]

y_mean <- sum(regions$e * regions$y)
x_mean <- sum(regions$e * regions$x)

dat$y0_region <- dat$y - y_mean
dat$x0_region <- dat$x - x_mean

z_region <- aggregate(
  share * shock,
  by = list(region_id = dat$region_id),
  FUN = sum
)
names(z_region)[2] <- "z"

regions <- merge(regions, z_region, by = "region_id", sort = FALSE)
regions$z0 <- regions$z - sum(regions$e * regions$z)

dat$z0_region <- regions$z0[match(dat$region_id, regions$region_id)]

industry_ids <- unique(dat$industry_id)
industry_shock <- aggregate(
  shock ~ industry_id,
  data = dat,
  FUN = function(v) v[1]
)

s_n <- aggregate(
  e * share,
  by = list(industry_id = dat$industry_id),
  FUN = sum
)
names(s_n)[2] <- "s"

aggregate_weighted <- function(v) {
  numerator <- aggregate(
    dat$e * dat$share * v,
    by = list(industry_id = dat$industry_id),
    FUN = sum
  )
  names(numerator)[2] <- "num"
  out <- merge(s_n, numerator, by = "industry_id", sort = FALSE)
  out$value <- out$num / out$s
  out
}

ybar <- aggregate_weighted(dat$y0_region)
xbar <- aggregate_weighted(dat$x0_region)
zbar <- aggregate_weighted(dat$z0_region)

shock <- merge(s_n, industry_shock, by = "industry_id", sort = FALSE)
shock <- merge(shock, ybar[, c("industry_id", "value")],
               by = "industry_id", sort = FALSE)
names(shock)[names(shock) == "value"] <- "ybar"
shock <- merge(shock, xbar[, c("industry_id", "value")],
               by = "industry_id", sort = FALSE)
names(shock)[names(shock) == "value"] <- "xbar"
shock <- merge(shock, zbar[, c("industry_id", "value")],
               by = "industry_id", sort = FALSE)
names(shock)[names(shock) == "value"] <- "zbar"

shock <- shock[is.finite(shock$s) & shock$s > 0, ]
N <- nrow(shock)

iv_hc1 <- function(y, endogenous, instrument, weight) {
  X <- cbind(1, endogenous)
  Z <- cbind(1, instrument)
  W <- diag(weight, nrow = length(weight))
  
  H <- crossprod(Z, W %*% Z)
  H_inv <- solve(H)
  G <- crossprod(Z, W %*% X)
  Q <- crossprod(G, H_inv %*% G)
  
  beta <- solve(Q, crossprod(G, H_inv %*% crossprod(Z, W %*% y)))
  residual <- as.vector(y - X %*% beta)
  
  meat_inner <- crossprod(
    Z,
    (weight^2 * residual^2) * Z
  )
  middle <- G %*% H_inv %*% meat_inner %*% H_inv %*% t(G)
  vcov <- solve(Q) %*% middle %*% solve(Q)
  vcov <- vcov * N / (N - ncol(X))
  
  list(beta = as.vector(beta), se = sqrt(diag(vcov)))
}

effect_fit <- iv_hc1(
  y = shock$ybar,
  endogenous = shock$xbar,
  instrument = shock$shock,
  weight = shock$s
)

first_stage_fit <- iv_hc1(
  y = shock$xbar,
  endogenous = shock$zbar,
  instrument = shock$shock,
  weight = shock$s
)

effective_shocks <- 1 / sum(shock$s^2)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(
      term = "effect",
      estimate = unname(effect_fit$beta[2]),
      se = unname(effect_fit$se[2]),
      n_obs = N
    ),
    list(
      term = "first_stage",
      estimate = unname(first_stage_fit$beta[2]),
      se = unname(first_stage_fit$se[2]),
      n_obs = N
    ),
    list(
      term = "effective_shocks",
      estimate = effective_shocks,
      se = NULL,
      n_obs = N
    )
  ),
  method_metadata = list(
    estimator = "Borusyak-Hull-Jaravel shock-level weighted 2SLS",
    vcov = "Shock-level heteroskedasticity-robust HC1, structural IV residuals, analytic weights"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = 15)
