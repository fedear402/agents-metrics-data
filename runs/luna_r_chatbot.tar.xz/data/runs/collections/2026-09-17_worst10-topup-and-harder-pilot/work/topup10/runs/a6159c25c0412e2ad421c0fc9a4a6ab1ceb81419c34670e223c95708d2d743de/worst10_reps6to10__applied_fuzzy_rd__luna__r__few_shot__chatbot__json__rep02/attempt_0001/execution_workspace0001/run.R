library(jsonlite)

dat <- read.csv("input.csv")

keep <- abs(dat$score) < 1
dat <- dat[keep, , drop = FALSE]

score <- dat$score
right <- as.numeric(score >= 0)
weights <- 1 - abs(score)

X <- cbind(
  intercept = 1,
  score = score,
  right = right,
  right_score = right * score
)

fit_hc0 <- function(y) {
  bread <- solve(crossprod(X, weights * X))
  beta <- bread %*% crossprod(X, weights * y)
  residuals <- drop(y - X %*% beta)
  meat <- crossprod(X * (weights * residuals))
  vcov <- bread %*% meat %*% bread
  list(beta = drop(beta), vcov = vcov, residuals = residuals)
}

earnings_fit <- fit_hc0(dat$earnings)
participation_fit <- fit_hc0(dat$participated)

reduced_form <- earnings_fit$beta[3]
first_stage <- participation_fit$beta[3]

rf_var <- earnings_fit$vcov[3, 3]
fs_var <- participation_fit$vcov[3, 3]

cross_meat <- crossprod(
  X * (weights * earnings_fit$residuals),
  X * (weights * participation_fit$residuals)
)
bread <- solve(crossprod(X, weights * X))
cross_vcov <- bread %*% cross_meat %*% bread
rf_fs_cov <- cross_vcov[3, 3]

gradient <- c(1 / first_stage, -reduced_form / first_stage^2)
joint_cov <- matrix(
  c(rf_var, rf_fs_cov, rf_fs_cov, fs_var),
  nrow = 2,
  byrow = TRUE
)

treatment_effect <- reduced_form / first_stage
treatment_se <- sqrt(drop(t(gradient) %*% joint_cov %*% gradient))

n_obs <- nrow(dat)

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(
      term = "treatment_effect",
      estimate = unname(as.numeric(treatment_effect)),
      se = unname(as.numeric(treatment_se)),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "reduced_form",
      estimate = unname(as.numeric(reduced_form)),
      se = unname(as.numeric(sqrt(rf_var))),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "first_stage",
      estimate = unname(as.numeric(first_stage)),
      se = unname(as.numeric(sqrt(fs_var))),
      n_obs = as.integer(n_obs)
    )
  ),
  method_metadata = list(
    estimator = "Fuzzy local-linear regression discontinuity with triangular weights",
    vcov = "Conventional heteroskedasticity-robust HC0 with joint delta-method covariance"
  ),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, digits = 16, pretty = TRUE)
