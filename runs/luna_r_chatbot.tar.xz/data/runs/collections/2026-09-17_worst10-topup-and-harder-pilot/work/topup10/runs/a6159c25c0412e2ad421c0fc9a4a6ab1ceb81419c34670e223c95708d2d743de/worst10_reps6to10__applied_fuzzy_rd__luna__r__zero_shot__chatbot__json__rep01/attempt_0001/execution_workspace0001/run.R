dat <- read.csv("input.csv")

keep <- abs(dat$score) < 1
dat <- dat[keep, , drop = FALSE]

x <- dat$score
w <- 1 - abs(x)
z <- as.numeric(x >= 0)

X <- cbind(1, z, x, z * x)
colnames(X) <- c("intercept", "right", "score", "right_score")

hc0_fit <- function(y) {
  W <- diag(w)
  bread <- solve(crossprod(X, W %*% X))
  beta <- bread %*% crossprod(X, w * y)
  resid <- as.numeric(y - X %*% beta)
  meat <- crossprod(X, (w^2 * resid^2) * X)
  vcov <- bread %*% meat %*% bread
  list(
    estimate = as.numeric(beta[2]),
    variance = as.numeric(vcov[2, 2]),
    residuals = resid
  )
}

earn_fit <- hc0_fit(dat$earnings)
part_fit <- hc0_fit(dat$participated)

rf <- earn_fit$estimate
fs <- part_fit$estimate
te <- rf / fs

bread <- solve(crossprod(X, diag(w) %*% X))
cross_meat <- crossprod(
  X,
  (w^2 * earn_fit$residuals * part_fit$residuals) * X
)
cross_vcov <- bread %*% cross_meat %*% bread
cov_rf_fs <- as.numeric(cross_vcov[2, 2])

var_te <- (
  earn_fit$variance +
    te^2 * part_fit$variance -
    2 * te * cov_rf_fs
) / fs^2

n_obs <- nrow(dat)

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(
      term = "treatment_effect",
      estimate = te,
      se = sqrt(max(var_te, 0)),
      n_obs = n_obs
    ),
    list(
      term = "reduced_form",
      estimate = rf,
      se = sqrt(max(earn_fit$variance, 0)),
      n_obs = n_obs
    ),
    list(
      term = "first_stage",
      estimate = fs,
      se = sqrt(max(part_fit$variance, 0)),
      n_obs = n_obs
    )
  ),
  method_metadata = list(
    estimator = "fuzzy regression discontinuity with local-linear weighted least squares",
    vcov = "HC0 heteroskedasticity-robust covariance with joint delta method"
  ),
  diagnostics = list()
)

if (requireNamespace("jsonlite", quietly = TRUE)) {
  jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = 17)
} else {
  esc <- function(s) gsub('"', '\\"', s, fixed = TRUE)
  txt <- sprintf(
    paste0(
      '{"task_id":"%s","platform":"r","estimates":[',
      '{"term":"treatment_effect","estimate":%.17g,"se":%.17g,"n_obs":%d},',
      '{"term":"reduced_form","estimate":%.17g,"se":%.17g,"n_obs":%d},',
      '{"term":"first_stage","estimate":%.17g,"se":%.17g,"n_obs":%d}],',
      '"method_metadata":{"estimator":"%s","vcov":"%s"},"diagnostics":{}}'
    ),
    esc(result$task_id),
    te, sqrt(max(var_te, 0)), n_obs,
    rf, sqrt(max(earn_fit$variance, 0)), n_obs,
    fs, sqrt(max(part_fit$variance, 0)), n_obs,
    esc(result$method_metadata$estimator),
    esc(result$method_metadata$vcov)
  )
  writeLines(txt, "result.json")
}
