library(jsonlite)

d <- read.csv("input.csv", stringsAsFactors = FALSE)

region_ids <- unique(d$region_id)
industry_ids <- unique(d$industry_id)

R <- length(region_ids)
N <- length(industry_ids)

region_index <- match(d$region_id, region_ids)
industry_index <- match(d$industry_id, industry_ids)

region_rows <- !duplicated(region_index)
regions <- d[region_rows, ]

e <- regions$region_weight
e <- e / sum(e)

shares <- matrix(
  0,
  nrow = R,
  ncol = N,
  dimnames = list(region_ids, industry_ids)
)
shares[cbind(region_index, industry_index)] <- d$share

shock_by_industry <- numeric(N)
shock_by_industry[industry_index] <- d$shock
shock_by_industry <- shock_by_industry[seq_len(N)]

x <- regions$x
y <- regions$y
z <- drop(shares %*% shock_by_industry)

weighted_mean <- function(v, w) {
  sum(w * v)
}

y0 <- y - weighted_mean(y, e)
x0 <- x - weighted_mean(x, e)
z0 <- z - weighted_mean(z, e)

mass <- drop(crossprod(e, shares))

ybar <- numeric(N)
xbar <- numeric(N)
zbar <- numeric(N)

for (n in seq_len(N)) {
  if (mass[n] > 0) {
    ybar[n] <- sum(e * shares[, n] * y0) / mass[n]
    xbar[n] <- sum(e * shares[, n] * x0) / mass[n]
    zbar[n] <- sum(e * shares[, n] * z0) / mass[n]
  }
}

shock_iv <- function(dependent, endogenous, instrument, weights, shock_count) {
  X <- cbind(1, endogenous)
  Z <- cbind(1, instrument)
  W <- weights

  cross <- crossprod(Z, W * X)
  rhs <- crossprod(Z, W * dependent)
  inverse <- solve(cross)
  beta <- drop(inverse %*% rhs)

  residual <- drop(dependent - X %*% beta)
  scores <- Z * (W * residual)

  covariance <- shock_count / (shock_count - 2) *
    inverse %*% crossprod(scores) %*% t(inverse)

  list(
    estimate = beta[2],
    se = sqrt(covariance[2, 2])
  )
}

effect_fit <- shock_iv(
  dependent = ybar,
  endogenous = xbar,
  instrument = shock_by_industry,
  weights = mass,
  shock_count = N
)

first_stage_fit <- shock_iv(
  dependent = xbar,
  endogenous = zbar,
  instrument = shock_by_industry,
  weights = mass,
  shock_count = N
)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(
      term = "effect",
      estimate = unname(effect_fit$estimate),
      se = unname(effect_fit$se),
      n_obs = as.integer(N)
    ),
    list(
      term = "first_stage",
      estimate = unname(first_stage_fit$estimate),
      se = unname(first_stage_fit$se),
      n_obs = as.integer(N)
    ),
    list(
      term = "effective_shocks",
      estimate = unname(1 / sum(mass^2)),
      se = NULL,
      n_obs = as.integer(N)
    )
  ),
  method_metadata = list(
    estimator = "Borusyak-Hull-Jaravel shock-level weighted IV",
    vcov = "HC1 exposure-robust shock-level covariance using structural IV residuals"
  ),
  diagnostics = list()
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
