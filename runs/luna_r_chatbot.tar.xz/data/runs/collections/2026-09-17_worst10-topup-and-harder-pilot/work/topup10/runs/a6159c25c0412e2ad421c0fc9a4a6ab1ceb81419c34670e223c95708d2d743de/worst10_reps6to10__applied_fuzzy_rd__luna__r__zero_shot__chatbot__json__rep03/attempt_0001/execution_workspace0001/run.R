d <- read.csv("input.csv", stringsAsFactors = FALSE)

d <- d[is.finite(d$score) &
       is.finite(d$participated) &
       is.finite(d$earnings) &
       abs(d$score) < 1, ]

n_obs <- nrow(d)
right <- as.numeric(d$score >= 0)
x <- cbind(
  intercept = 1,
  discontinuity = right,
  score = d$score,
  score_right = d$score * right
)
w <- 1 - abs(d$score)

fit_robust <- function(y) {
  bread <- solve(crossprod(x, w * x))
  beta <- bread %*% crossprod(x, w * y)
  residuals <- as.numeric(y - x %*% beta)
  meat <- crossprod(x, (w^2 * residuals^2) * x)
  vcov <- bread %*% meat %*% bread
  list(beta = as.numeric(beta), vcov = vcov, residuals = residuals)
}

fit_y <- fit_robust(d$earnings)
fit_d <- fit_robust(d$participated)

reduced_form <- fit_y$beta[2]
first_stage <- fit_d$beta[2]

var_rf <- fit_y$vcov[2, 2]
var_fs <- fit_d$vcov[2, 2]

cross_meat <- crossprod(
  x,
  (w^2 * fit_y$residuals * fit_d$residuals) * x
)
cross_vcov <- solve(crossprod(x, w * x)) %*%
  cross_meat %*%
  solve(crossprod(x, w * x))

cov_rf_fs <- cross_vcov[2, 2]

if (is.finite(first_stage) && first_stage != 0) {
  treatment_effect <- reduced_form / first_stage
  var_te <- (
    var_rf +
      treatment_effect^2 * var_fs -
      2 * treatment_effect * cov_rf_fs
  ) / first_stage^2
  se_te <- sqrt(max(var_te, 0))
} else {
  treatment_effect <- NA_real_
  se_te <- NA_real_
}

fmt <- function(x) {
  if (length(x) == 0 || !is.finite(x)) "null" else formatC(x, format = "fg", digits = 17)
}

json <- paste0(
  '{',
  '"task_id":"applied_fuzzy_rd",',
  '"platform":"r",',
  '"estimates":[',
  '{"term":"treatment_effect","estimate":', fmt(treatment_effect),
  ',"se":', fmt(se_te), ',"n_obs":', n_obs, '},',
  '{"term":"reduced_form","estimate":', fmt(reduced_form),
  ',"se":', fmt(sqrt(max(var_rf, 0))), ',"n_obs":', n_obs, '},',
  '{"term":"first_stage","estimate":', fmt(first_stage),
  ',"se":', fmt(sqrt(max(var_fs, 0))), ',"n_obs":', n_obs, '}',
  '],',
  '"method_metadata":{',
  '"estimator":"Fuzzy local-linear regression discontinuity with triangular weights",',
  '"vcov":"Conventional heteroskedasticity-robust HC0; delta method with joint covariance"',
  '},',
  '"diagnostics":{}',
  '}'
)

writeLines(json, "result.json")
