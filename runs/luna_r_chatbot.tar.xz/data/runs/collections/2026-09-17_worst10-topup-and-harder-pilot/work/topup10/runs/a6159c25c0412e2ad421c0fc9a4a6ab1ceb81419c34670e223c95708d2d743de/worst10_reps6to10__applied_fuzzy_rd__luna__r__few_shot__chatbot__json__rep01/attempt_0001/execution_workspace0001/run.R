library(jsonlite)

dat <- read.csv("input.csv")

keep <- abs(dat$score) < 1
d <- dat[keep, ]

s <- d$score
w <- 1 - abs(s)

left <- as.numeric(s < 0)
right <- as.numeric(s >= 0)

X <- cbind(
  left_intercept = left,
  left_slope = left * s,
  right_intercept = right,
  right_slope = right * s
)

W <- crossprod(X, w * X)
bread <- solve(W)

Y <- cbind(
  earnings = d$earnings,
  participated = d$participated
)

beta <- bread %*% crossprod(X, w * Y)
residuals <- Y - X %*% beta

contrast <- c(-1, 0, 1, 0)
discontinuities <- drop(contrast %*% beta)

loading <- w * drop(X %*% bread %*% contrast)
influence <- loading * residuals
joint_covariance <- crossprod(influence)

gradient <- c(
  1 / discontinuities[2],
  -discontinuities[1] / discontinuities[2]^2
)

treatment_effect <- discontinuities[1] / discontinuities[2]
treatment_se <- sqrt(drop(t(gradient) %*% joint_covariance %*% gradient))

n_obs <- nrow(d)

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(
      term = "treatment_effect",
      estimate = unname(as.numeric(treatment_effect)),
      se = unname(as.numeric(treatment_se)),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "reduced_form",
      estimate = unname(as.numeric(discontinuities[1])),
      se = unname(as.numeric(sqrt(joint_covariance[1, 1]))),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "first_stage",
      estimate = unname(as.numeric(discontinuities[2])),
      se = unname(as.numeric(sqrt(joint_covariance[2, 2]))),
      n_obs = as.integer(n_obs)
    )
  ),
  method_metadata = list(
    estimator = "fuzzy local-linear regression discontinuity with triangular weights",
    vcov = "conventional heteroskedasticity-robust HC0"
  ),
  diagnostics = list()
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
