library(jsonlite)

data <- read.csv("input.csv", stringsAsFactors = FALSE)
data$date <- as.Date(data$date)
data <- data[order(data$date), ]

log_vix <- log(data$vix)
data$log_sales <- log(data$sales)
data$vol_change <- c(NA_real_, diff(log_vix))

for (j in 1:15) {
  data[[paste0("lag_", j)]] <- c(
    rep(NA_real_, j + 1),
    head(data$vol_change, -j - 1)
  )
}

lag_names <- paste0("lag_", 1:15)
sample <- data[complete.cases(data[, c("log_sales", lag_names)]), ]

formula_text <- paste(
  "log_sales ~",
  paste(lag_names, collapse = " + ")
)
fit <- lm(as.formula(formula_text), data = sample)

X <- model.matrix(fit)
u <- residuals(fit)
N <- nrow(X)
p <- ncol(X)
hac_lags <- 15

scores <- X * u
meat <- crossprod(scores)

for (j in 1:hac_lags) {
  lag_product <- crossprod(
    scores[(j + 1):N, , drop = FALSE],
    scores[1:(N - j), , drop = FALSE]
  )
  weight <- 1 - j / 16
  meat <- meat + weight * (lag_product + t(lag_product))
}

bread <- solve(crossprod(X))
covariance <- (N / (N - 16)) * bread %*% meat %*% bread
coefficients <- coef(fit)

contrast <- c(1, rep(0, 15))
contrast[2:16] <- 1
cumulative_response <- sum(coefficients[2:16])
cumulative_se <- sqrt(drop(t(contrast) %*% covariance %*% contrast))

lag1_index <- which(names(coefficients) == "lag_1")
lag15_index <- which(names(coefficients) == "lag_15")

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(
      term = "cumulative_response",
      estimate = unname(as.numeric(cumulative_response)),
      se = unname(as.numeric(cumulative_se)),
      n_obs = as.integer(N)
    ),
    list(
      term = "lag_1",
      estimate = unname(as.numeric(coefficients[lag1_index])),
      se = unname(as.numeric(sqrt(covariance[lag1_index, lag1_index]))),
      n_obs = as.integer(N)
    ),
    list(
      term = "lag_15",
      estimate = unname(as.numeric(coefficients[lag15_index])),
      se = unname(as.numeric(sqrt(covariance[lag15_index, lag15_index]))),
      n_obs = as.integer(N)
    )
  ),
  method_metadata = list(
    estimator = "OLS with intercept and fifteen lagged log-volatility changes",
    vcov = "Bartlett Newey-West HAC, maximum lag 15, finite-sample correction N/(N-16)"
  ),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, digits = 16, pretty = TRUE)
