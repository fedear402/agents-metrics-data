library(jsonlite)

dat <- read.csv("input.csv")
dat <- dat[abs(dat$score) < 1, ]

n_obs <- nrow(dat)
z <- as.numeric(dat$score >= 0)
x <- dat$score
w <- 1 - abs(x)

X <- cbind(
  intercept = 1,
  score = x,
  above = z,
  above_score = z * x
)

W <- diag(w, nrow = n_obs)
bread <- solve(crossprod(X, W %*% X))

Y <- cbind(
  earnings = dat$earnings,
  participated = dat$participated
)

beta <- bread %*% crossprod(X, W %*% Y)
residuals <- Y - X %*% beta

scores <- X * (w * residuals)
joint_cov <- matrix(0, 2, 2)

for (a in 1:2) {
  for (b in 1:2) {
    joint_cov[a, b] <- sum(
      (scores[, a] %*% bread[, 3]) *
      (scores[, b] %*% bread[, 3])
    )
  }
}

reduced_form <- beta[3, 1]
first_stage <- beta[3, 2]

reduced_form_se <- sqrt(joint_cov[1, 1])
first_stage_se <- sqrt(joint_cov[2, 2])

treatment_effect <- reduced_form / first_stage
gradient <- c(1 / first_stage, -reduced_form / first_stage^2)
treatment_effect_se <- sqrt(drop(t(gradient) %*% joint_cov %*% gradient))

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(
      term = "treatment_effect",
      estimate = unname(as.numeric(treatment_effect)),
      se = unname(as.numeric(treatment_effect_se)),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "reduced_form",
      estimate = unname(as.numeric(reduced_form)),
      se = unname(as.numeric(reduced_form_se)),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "first_stage",
      estimate = unname(as.numeric(first_stage)),
      se = unname(as.numeric(first_stage_se)),
      n_obs = as.integer(n_obs)
    )
  ),
  method_metadata = list(
    estimator = "weighted local-linear fuzzy regression discontinuity",
    vcov = "HC0"
  ),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, digits = 16, pretty = TRUE)
