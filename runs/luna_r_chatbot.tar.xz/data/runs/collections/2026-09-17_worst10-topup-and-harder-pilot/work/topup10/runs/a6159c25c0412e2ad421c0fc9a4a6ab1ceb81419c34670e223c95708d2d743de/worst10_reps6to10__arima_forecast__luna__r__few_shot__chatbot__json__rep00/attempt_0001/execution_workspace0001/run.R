library(jsonlite)

dat <- read.csv("./input.csv", stringsAsFactors = FALSE)
dat <- dat[order(dat$t), ]

y <- as.numeric(dat$y)
y <- y[is.finite(y)]

fit <- stats::arima(
  y,
  order = c(1, 1, 1),
  include.mean = FALSE,
  method = "ML"
)

pred <- stats::predict(fit, n.ahead = 1)
forecast_value <- as.numeric(pred$pred[1])
forecast_se <- as.numeric(pred$se[1])

out <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = list(
    list(
      term = "forecast",
      estimate = forecast_value,
      se = forecast_se,
      n_obs = length(y)
    ),
    list(
      term = "lower_95",
      estimate = forecast_value - qnorm(0.975) * forecast_se,
      se = NA_real_,
      n_obs = length(y)
    ),
    list(
      term = "upper_95",
      estimate = forecast_value + qnorm(0.975) * forecast_se,
      se = NA_real_,
      n_obs = length(y)
    )
  ),
  method_metadata = list(
    estimator = "ARIMA(1,1,1) by maximum likelihood without constant or drift",
    vcov = "model-based prediction interval"
  ),
  diagnostics = list()
)

jsonlite::write_json(out, "./result.json", auto_unbox = TRUE, na = "null")
