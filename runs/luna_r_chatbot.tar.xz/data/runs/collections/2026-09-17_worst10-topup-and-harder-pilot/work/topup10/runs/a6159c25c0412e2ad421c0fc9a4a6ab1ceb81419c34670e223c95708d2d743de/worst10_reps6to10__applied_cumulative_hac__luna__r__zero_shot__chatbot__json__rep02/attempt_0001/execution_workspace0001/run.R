#!/usr/bin/env Rscript

input <- read.csv("input.csv", stringsAsFactors = FALSE)

parsed_date <- as.Date(input$date)
if (all(!is.na(parsed_date))) {
  input <- input[order(parsed_date), , drop = FALSE]
} else {
  input <- input[order(input$date), , drop = FALSE]
}

log_sales <- log(input$sales)
log_vix <- log(input$vix)
vol_change <- c(NA_real_, diff(log_vix))

n_total <- nrow(input)
lag_matrix <- sapply(1:15, function(k) {
  c(rep(NA_real_, k), vol_change[1:(n_total - k)])
})
colnames(lag_matrix) <- paste0("lag_", 1:15)

reg_data <- data.frame(
  y = log_sales,
  lag_matrix,
  check.names = FALSE
)
reg_data <- reg_data[complete.cases(reg_data), , drop = FALSE]

y <- as.numeric(reg_data$y)
X <- cbind("(Intercept)" = 1, as.matrix(reg_data[, paste0("lag_", 1:15)]))
N <- nrow(X)
K <- ncol(X)

XtX_inv <- solve(crossprod(X))
beta <- XtX_inv %*% crossprod(X, y)
residuals <- as.numeric(y - X %*% beta)

S <- crossprod(X * residuals)

if (N > 1) {
  for (j in 1:15) {
    weight <- 1 - j / 16
    X_lead <- X[(j + 1):N, , drop = FALSE]
    X_lag <- X[1:(N - j), , drop = FALSE]
    e_lead <- residuals[(j + 1):N]
    e_lag <- residuals[1:(N - j)]
    
    gamma_j <- crossprod(X_lead * e_lead, X_lag * e_lag)
    S <- S + weight * (gamma_j + t(gamma_j))
  }
}

vcov_hac <- XtX_inv %*% S %*% XtX_inv
vcov_hac <- vcov_hac * N / (N - 16)

cumulative_weights <- c(0, rep(1, 15))
cumulative_estimate <- sum(as.numeric(beta[2:16]))
cumulative_se <- sqrt(as.numeric(
  t(cumulative_weights) %*% vcov_hac %*% cumulative_weights
))

lag1_estimate <- as.numeric(beta[2])
lag1_se <- sqrt(vcov_hac[2, 2])

lag15_estimate <- as.numeric(beta[16])
lag15_se <- sqrt(vcov_hac[16, 16])

fmt <- function(x) {
  if (is.null(x) || is.na(x) || !is.finite(x)) "null" else
    formatC(x, format = "fg", digits = 17)
}

json <- paste0(
  '{',
  '"task_id":"applied_cumulative_hac",',
  '"platform":"r",',
  '"estimates":[',
  '{"term":"cumulative_response","estimate":', fmt(cumulative_estimate),
  ',"se":', fmt(cumulative_se), ',"n_obs":', N, '},',
  '{"term":"lag_1","estimate":', fmt(lag1_estimate),
  ',"se":', fmt(lag1_se), ',"n_obs":', N, '},',
  '{"term":"lag_15","estimate":', fmt(lag15_estimate),
  ',"se":', fmt(lag15_se), ',"n_obs":', N, '}',
  '],',
  '"method_metadata":{',
  '"estimator":"OLS with intercept and lags 1 through 15 of first-differenced log volatility",',
  '"vcov":"Newey-West HAC, maximum lag 15, Bartlett weights, scaled by N/(N-16)"',
  '},',
  '"diagnostics":{}',
  '}'
)

writeLines(json, "result.json")
