dat <- read.csv("input.csv", stringsAsFactors = FALSE)

y <- as.integer(dat$y)
xmat <- cbind(1, dat$x, dat$z)
n <- nrow(dat)

loglik <- function(beta) {
  b1 <- beta[1:3]
  b2 <- beta[4:6]
  eta1 <- drop(xmat %*% b1)
  eta2 <- drop(xmat %*% b2)
  m <- pmax(0, eta1, eta2)
  den <- exp(-m) + exp(eta1 - m) + exp(eta2 - m)
  logp0 <- -m - log(den)
  logp1 <- eta1 - m - log(den)
  logp2 <- eta2 - m - log(den)
  -sum(ifelse(y == 0, logp0, ifelse(y == 1, logp1, logp2)))
}

fit <- optim(
  par = rep(0, 6),
  fn = loglik,
  method = "BFGS",
  hessian = FALSE,
  control = list(reltol = 1e-12, maxit = 10000)
)

beta <- fit$par
b1 <- beta[1:3]
b2 <- beta[4:6]

eta1 <- drop(xmat %*% b1)
eta2 <- drop(xmat %*% b2)

m <- pmax(0, eta1, eta2)
e0 <- exp(-m)
e1 <- exp(eta1 - m)
e2 <- exp(eta2 - m)
den <- e0 + e1 + e2
p1 <- e1 / den
p2 <- e2 / den

H <- matrix(0, 6, 6)

for (i in seq_len(n)) {
  xi <- matrix(xmat[i, ], nrow = 1)
  pp <- matrix(c(p1[i], p2[i]), nrow = 2)
  W <- diag(c(p1[i], p2[i])) - pp %*% t(pp)
  Xi <- matrix(0, nrow = 2, ncol = 6)
  Xi[1, 1:3] <- xi
  Xi[2, 4:6] <- xi
  H <- H + t(Xi) %*% W %*% Xi
}

V <- solve(H)
se <- sqrt(pmax(0, diag(V)))

p2_zero <- exp(b2[1]) / (1 + exp(b1[1]) + exp(b2[1]))

fmt <- function(v) {
  if (is.null(v)) "null" else formatC(v, digits = 15, format = "fg", flag = "#")
}

json <- paste0(
  "{\n",
  '  "task_id": "broad_multinomial_logit",\n',
  '  "platform": "r",\n',
  '  "estimates": [\n',
  '    {"term": "x_cat1", "estimate": ', fmt(beta[2]), ', "se": ', fmt(se[2]), ', "n_obs": ', n, '},\n',
  '    {"term": "z_cat1", "estimate": ', fmt(beta[3]), ', "se": ', fmt(se[3]), ', "n_obs": ', n, '},\n',
  '    {"term": "x_cat2", "estimate": ', fmt(beta[5]), ', "se": ', fmt(se[5]), ', "n_obs": ', n, '},\n',
  '    {"term": "z_cat2", "estimate": ', fmt(beta[6]), ', "se": ', fmt(se[6]), ', "n_obs": ', n, '},\n',
  '    {"term": "prob_cat2_zero", "estimate": ', fmt(p2_zero), ', "se": null, "n_obs": ', n, '}\n',
  '  ],\n',
  '  "method_metadata": {"estimator": "multinomial logit maximum likelihood", "vcov": "conventional observed information"},\n',
  '  "diagnostics": {}\n',
  "}\n"
)

writeLines(json, "result.json")
