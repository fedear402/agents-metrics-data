d <- read.csv("input.csv")

d$y <- factor(d$y, levels = c(0, 1, 2))

fit <- nnet::multinom(
  y ~ x + z,
  data = d,
  Hess = TRUE,
  trace = FALSE,
  maxit = 1000,
  reltol = 1e-12,
  abstol = 1e-12
)

B <- coef(fit)
V <- vcov(fit)
n <- nrow(d)

get_se <- function(category, term) {
  candidates <- c(
    paste0(category, ":", term),
    paste0(term, ":", category)
  )
  nm <- intersect(candidates, rownames(V))
  if (length(nm) == 0L) {
    stop("Variance-covariance term not found")
  }
  sqrt(V[nm[1L], nm[1L]])
}

intercepts <- c(0, B["1", "(Intercept)"], B["2", "(Intercept)"])
weights <- exp(intercepts - max(intercepts))
prob_cat2_zero <- weights[3L] / sum(weights)

estimates <- list(
  list(
    term = "x_cat1",
    estimate = unname(B["1", "x"]),
    se = get_se("1", "x"),
    n_obs = n
  ),
  list(
    term = "z_cat1",
    estimate = unname(B["1", "z"]),
    se = get_se("1", "z"),
    n_obs = n
  ),
  list(
    term = "x_cat2",
    estimate = unname(B["2", "x"]),
    se = get_se("2", "x"),
    n_obs = n
  ),
  list(
    term = "z_cat2",
    estimate = unname(B["2", "z"]),
    se = get_se("2", "z"),
    n_obs = n
  ),
  list(
    term = "prob_cat2_zero",
    estimate = unname(prob_cat2_zero),
    se = NULL,
    n_obs = n
  )
)

result <- list(
  task_id = "broad_multinomial_logit",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "Multinomial logit maximum likelihood",
    vcov = "Conventional observed-information standard errors"
  ),
  diagnostics = list()
)

jsonlite::write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
