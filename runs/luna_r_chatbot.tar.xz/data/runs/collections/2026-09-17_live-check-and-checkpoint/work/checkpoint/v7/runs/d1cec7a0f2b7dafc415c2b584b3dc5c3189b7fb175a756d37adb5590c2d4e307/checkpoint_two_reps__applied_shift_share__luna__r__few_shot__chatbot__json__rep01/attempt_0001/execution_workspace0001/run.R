library(jsonlite)

dat <- read.csv("input.csv", stringsAsFactors = FALSE)

regions <- unique(dat[, c("region_id", "region_weight")])
regions$e <- regions$region_weight / sum(regions$region_weight)

dat <- merge(dat, regions[, c("region_id", "e")], by = "region_id", sort = FALSE)

reg <- unique(dat[, c("region_id", "e", "x", "y")])
reg$z <- sapply(reg$region_id, function(r) {
  d <- dat[dat$region_id == r, ]
  sum(d$share * d$shock)
})

e <- reg$e
reg_vars <- cbind(y = reg$y, x = reg$x, z = reg$z)
centered <- sweep(reg_vars, 2, colSums(e * reg_vars), "-")

industries <- unique(dat[, c("industry_id", "shock")])
industry_ids <- industries$industry_id

s <- numeric(length(industry_ids))
ybar <- numeric(length(industry_ids))
xbar <- numeric(length(industry_ids))
zbar <- numeric(length(industry_ids))

for (j in seq_along(industry_ids)) {
  n <- industry_ids[j]
  d <- dat[dat$industry_id == n, ]
  idx <- match(d$region_id, reg$region_id)
  s[j] <- sum(e[idx] * d$share)
  ybar[j] <- sum(e[idx] * d$share * centered[idx, "y"]) / s[j]
  xbar[j] <- sum(e[idx] * d$share * centered[idx, "x"]) / s[j]
  zbar[j] <- sum(e[idx] * d$share * centered[idx, "z"]) / s[j]
}

keep <- s > 0
s <- s[keep]
shock <- industries$shock[keep]
ybar <- ybar[keep]
xbar <- xbar[keep]
zbar <- zbar[keep]

shock_iv <- function(dependent, endogenous, instrument, weights) {
  regressors <- cbind(1, endogenous)
  instruments <- cbind(1, instrument)

  cross <- crossprod(instruments, weights * regressors)
  beta <- solve(cross, crossprod(instruments, weights * dependent))

  residual <- drop(dependent - regressors %*% beta)
  scores <- instruments * (weights * residual)
  inverse <- solve(cross)

  n_industries <- length(weights)
  covariance <- n_industries / (n_industries - 2) *
    inverse %*% crossprod(scores) %*% t(inverse)

  c(estimate = beta[2], se = sqrt(covariance[2, 2]))
}

effect <- shock_iv(ybar, xbar, shock, s)
first_stage <- shock_iv(xbar, zbar, shock, s)
effective_shocks <- 1 / sum(s^2)
n_industries <- length(s)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(
      term = "effect",
      estimate = unname(as.numeric(effect["estimate"])),
      se = unname(as.numeric(effect["se"])),
      n_obs = as.integer(n_industries)
    ),
    list(
      term = "first_stage",
      estimate = unname(as.numeric(first_stage["estimate"])),
      se = unname(as.numeric(first_stage["se"])),
      n_obs = as.integer(n_industries)
    ),
    list(
      term = "effective_shocks",
      estimate = as.numeric(effective_shocks),
      se = NULL,
      n_obs = as.integer(n_industries)
    )
  ),
  method_metadata = list(
    estimator = "Weighted regional 2SLS with BHJ shock-level aggregation",
    vcov = "Shock-level heteroskedastic HC1 with structural IV residuals"
  ),
  diagnostics = list()
)

write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
