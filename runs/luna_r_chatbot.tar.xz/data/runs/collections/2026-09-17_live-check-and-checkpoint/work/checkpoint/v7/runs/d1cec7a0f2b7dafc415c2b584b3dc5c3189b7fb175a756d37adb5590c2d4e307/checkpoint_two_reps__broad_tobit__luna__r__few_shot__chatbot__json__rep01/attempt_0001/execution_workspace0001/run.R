d <- read.csv("input.csv")

fit <- survival::survreg(
  survival::Surv(y, y > 0, type = "left") ~ x + z,
  data = d,
  dist = "gaussian",
  control = survival::survreg.control(rel.tolerance = 1e-12)
)

V <- stats::vcov(fit)
n <- nrow(d)
b <- stats::coef(fit)

rows <- list(
  list(
    term = "const",
    estimate = unname(b["(Intercept)"]),
    se = sqrt(V["(Intercept)", "(Intercept)"]),
    n_obs = as.integer(n)
  ),
  list(
    term = "x",
    estimate = unname(b["x"]),
    se = sqrt(V["x", "x"]),
    n_obs = as.integer(n)
  ),
  list(
    term = "z",
    estimate = unname(b["z"]),
    se = sqrt(V["z", "z"]),
    n_obs = as.integer(n)
  ),
  list(
    term = "sigma",
    estimate = unname(fit$scale),
    se = NULL,
    n_obs = as.integer(n)
  )
)

jsonlite::write_json(
  list(
    task_id = "broad_tobit",
    platform = "r",
    estimates = rows,
    method_metadata = list(
      estimator = "Gaussian Tobit maximum likelihood with left censoring at zero",
      vcov = "Observed information from jointly estimated Gaussian likelihood"
    ),
    diagnostics = list()
  ),
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
