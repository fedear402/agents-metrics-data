dat <- read.csv("input.csv", stringsAsFactors = FALSE)
dat <- dat[order(as.Date(dat$date)), ]

n <- nrow(dat)
log_vix <- log(dat$vix)
delta_vix <- diff(log_vix)

idx <- 17:n
y <- log(dat$sales[idx])

X <- cbind(
  intercept = 1,
  sapply(1:15, function(j) delta_vix[idx - j - 1])
)
colnames(X) <- c("intercept", paste0("lag_", 1:15))

fit <- lm.fit(x = X, y = y)
beta <- fit$coefficients
resid <- fit$residuals
N <- nrow(X)

bread <- solve(crossprod(X))
scores <- X * resid

meat <- crossprod(scores)
if (15 > 0) {
  for (j in 1:15) {
    weight <- 1 - j / 16
    gamma_j <- crossprod(scores[(j + 1):N, , drop = FALSE],
                         scores[1:(N - j), , drop = FALSE])
    meat <- meat + weight * (gamma_j + t(gamma_j))
  }
}

vcov_hac <- bread %*% meat %*% bread * N / (N - 16)
se <- sqrt(diag(vcov_hac))

cumulative_response <- sum(beta[paste0("lag_", 1:15)])
cumulative_var <- sum(vcov_hac[paste0("lag_", 1:15),
                                paste0("lag_", 1:15)])
cumulative_se <- sqrt(cumulative_var)

fmt <- function(x) sprintf("%.17g", x)

json <- paste0(
  "{\n",
  '  "task_id": "applied_cumulative_hac",\n',
  '  "platform": "r",\n',
  '  "estimates": [\n',
  '    {"term": "cumulative_response", "estimate": ', fmt(cumulative_response),
  ', "se": ', fmt(cumulative_se), ', "n_obs": ', N, "},\n",
  '    {"term": "lag_1", "estimate": ', fmt(beta["lag_1"]),
  ', "se": ', fmt(se["lag_1"]), ', "n_obs": ', N, "},\n",
  '    {"term": "lag_15", "estimate": ', fmt(beta["lag_15"]),
  ', "se": ', fmt(se["lag_15"]), ', "n_obs": ', N, "}\n",
  "  ],\n",
  '  "method_metadata": {"estimator": "OLS with lags 1 through 15 of first-differenced log volatility", ',
  '"vcov": "Newey-West HAC, maximum lag 15, Bartlett weights, scaled by N/(N-16)"},\n',
  '  "diagnostics": {}\n',
  "}\n"
)

writeLines(json, "result.json")
