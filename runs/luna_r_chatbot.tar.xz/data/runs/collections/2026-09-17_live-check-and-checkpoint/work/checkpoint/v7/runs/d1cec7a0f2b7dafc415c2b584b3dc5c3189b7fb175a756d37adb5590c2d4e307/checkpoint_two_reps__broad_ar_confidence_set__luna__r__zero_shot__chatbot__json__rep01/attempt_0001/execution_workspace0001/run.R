dat <- read.csv("input.csv")

n <- nrow(dat)
df <- n - 4
q <- 2
fcrit <- qf(0.95, q, df)

y <- dat$y
e <- dat$endog
controls <- cbind(1, dat$x)
all_controls <- cbind(1, dat$x, dat$z1, dat$z2)

rss <- function(response, design) {
  fit <- lm.fit(design, response)
  sum(fit$residuals^2)
}

ar_f <- function(beta) {
  response <- y - beta * e
  rss_restricted <- rss(response, controls)
  rss_full <- rss(response, all_controls)
  ((rss_restricted - rss_full) / q) / (rss_full / df)
}

h <- function(beta) {
  response <- y - beta * e
  rss_restricted <- rss(response, controls)
  rss_full <- rss(response, all_controls)
  df * (rss_restricted - rss_full) - fcrit * q * rss_full
}

h0 <- h(0)
h1 <- h(1)
hm1 <- h(-1)

a <- (h1 + hm1) / 2 - h0
b <- (h1 - hm1) / 2
c <- h0

roots <- polyroot(c(c, b, a))
real_roots <- sort(Re(roots[abs(Im(roots)) < 1e-7]))

boundary_low <- real_roots[1]
boundary_high <- real_roots[length(real_roots)]

accepts_zero <- as.numeric(ar_f(0) <= fcrit)

scale_h <- max(abs(c), abs(b), abs(a), 1)
tol <- 1e-10 * scale_h
unbounded <- as.numeric(a > tol | (abs(a) <= tol & abs(b) > tol))

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = list(
    list(term = "boundary_low", estimate = as.numeric(boundary_low), se = NULL, n_obs = n),
    list(term = "boundary_high", estimate = as.numeric(boundary_high), se = NULL, n_obs = n),
    list(term = "accepts_zero", estimate = as.numeric(accepts_zero), se = NULL, n_obs = n),
    list(term = "unbounded", estimate = as.numeric(unbounded), se = NULL, n_obs = n),
    list(term = "ar_f_at_one", estimate = as.numeric(ar_f(1)), se = NULL, n_obs = n)
  ),
  method_metadata = list(
    estimator = "Anderson-Rubin homoskedastic joint F test",
    vcov = "conventional homoskedastic"
  ),
  diagnostics = list(
    numerator_df = q,
    denominator_df = df,
    critical_value = fcrit
  )
)

if (requireNamespace("jsonlite", quietly = TRUE)) {
  jsonlite::write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 17)
} else {
  esc <- function(x) {
    if (is.null(x)) return("null")
    if (is.character(x)) return(paste0("\"", x, "\""))
    if (is.numeric(x)) return(format(x, digits = 17, scientific = FALSE))
    as.character(x)
  }
  lines <- c(
    "{",
    "\"task_id\":\"broad_ar_confidence_set\",",
    "\"platform\":\"r\",",
    "\"estimates\":[",
    paste0("{\"term\":\"boundary_low\",\"estimate\":", esc(boundary_low), ",\"se\":null,\"n_obs\":", n, "},"),
    paste0("{\"term\":\"boundary_high\",\"estimate\":", esc(boundary_high), ",\"se\":null,\"n_obs\":", n, "},"),
    paste0("{\"term\":\"accepts_zero\",\"estimate\":", esc(accepts_zero), ",\"se\":null,\"n_obs\":", n, "},"),
    paste0("{\"term\":\"unbounded\",\"estimate\":", esc(unbounded), ",\"se\":null,\"n_obs\":", n, "},"),
    paste0("{\"term\":\"ar_f_at_one\",\"estimate\":", esc(ar_f(1)), ",\"se\":null,\"n_obs\":", n, "}",
    "],",
    "\"method_metadata\":{\"estimator\":\"Anderson-Rubin homoskedastic joint F test\",\"vcov\":\"conventional homoskedastic\"},",
    "\"diagnostics\":{}",
    "}"
  )
  writeLines(lines, "result.json")
}
