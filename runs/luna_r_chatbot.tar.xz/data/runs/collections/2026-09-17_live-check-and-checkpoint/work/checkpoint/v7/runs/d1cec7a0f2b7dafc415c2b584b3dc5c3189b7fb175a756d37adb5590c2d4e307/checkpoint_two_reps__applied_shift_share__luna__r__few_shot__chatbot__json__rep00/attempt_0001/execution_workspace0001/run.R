library(jsonlite)

dat <- read.csv("input.csv", stringsAsFactors = FALSE)

region_ids <- unique(dat$region_id)
industry_ids <- unique(dat$industry_id)

region_data <- do.call(rbind, lapply(region_ids, function(r) {
  d <- dat[dat$region_id == r, ]
  d[1, c("region_id", "region_weight", "x", "y")]
}))

e <- region_data$region_weight / sum(region_data$region_weight)

x <- region_data$x
y <- region_data$y

z <- sapply(region_ids, function(r) {
  d <- dat[dat$region_id == r, ]
  sum(d$share * d$shock)
})

weighted_mean <- function(v, w) {
  sum(w * v)
}

y0 <- y - weighted_mean(y, e)
x0 <- x - weighted_mean(x, e)
z0 <- z - weighted_mean(z, e)

shock_data <- do.call(rbind, lapply(industry_ids, function(n) {
  d <- dat[dat$industry_id == n, ]
  idx <- match(d$region_id, region_ids)
  mass <- sum(e[idx] * d$share)

  data.frame(
    industry_id = n,
    shock = d$shock[1],
    s = mass,
    ybar = sum(e[idx] * d$share * y0[idx]) / mass,
    xbar = sum(e[idx] * d$share * x0[idx]) / mass,
    zbar = sum(e[idx] * d$share * z0[idx]) / mass
  )
}))

shock_iv <- function(dependent, endogenous, instrument, weights) {
  n <- length(dependent)

  regressors <- cbind(1, endogenous)
  instruments <- cbind(1, instrument)

  cross <- crossprod(instruments, weights * regressors)
  beta <- solve(
    cross,
    crossprod(instruments, weights * dependent)
  )

  residual <- drop(dependent - regressors %*% beta)
  scores <- instruments * (weights * residual)
  inverse <- solve(cross)

  covariance <- n / (n - 2) *
    inverse %*% crossprod(scores) %*% t(inverse)

  c(
    estimate = beta[2],
    se = sqrt(covariance[2, 2])
  )
}

n_industries <- nrow(shock_data)
s <- shock_data$s
shock <- shock_data$shock

effect <- shock_iv(
  dependent = shock_data$ybar,
  endogenous = shock_data$xbar,
  instrument = shock,
  weights = s
)

first_stage <- shock_iv(
  dependent = shock_data$xbar,
  endogenous = shock_data$zbar,
  instrument = shock,
  weights = s
)

effective_shocks <- 1 / sum(s^2)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(
      term = "effect",
      estimate = unname(as.numeric(effect["estimate"])),
      se = unname(as.numeric(effect["se"])),
      n_obs = as.integer(n_industries)
    ),
    list(
      term = "first_stage",
      estimate = unname(as.numeric(first_stage["estimate"])),
      se = unname(as.numeric(first_stage["se"])),
      n_obs = as.integer(n_industries)
    ),
    list(
      term = "effective_shocks",
      estimate = as.numeric(effective_shocks),
      se = NULL,
      n_obs = as.integer(n_industries)
    )
  ),
  method_metadata = list(
    estimator = "Shock-level weighted instrumental variables regression",
    vcov = "Exposure-robust HC1 with N/(N-2) multiplier"
  ),
  diagnostics = list()
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
