library(jsonlite)

dat <- read.csv("input.csv", stringsAsFactors = FALSE)

keep <- is.finite(dat$score) &
  is.finite(dat$participated) &
  is.finite(dat$earnings) &
  abs(dat$score) < 1

d <- dat[keep, , drop = FALSE]
s <- d$score
w <- 1 - abs(s)
right <- as.integer(s >= 0)

X <- cbind(
  left_intercept = 1 - right,
  left_slope = s * (1 - right),
  right_intercept = right,
  right_slope = s * right
)

W <- diag(w, nrow = nrow(X))
bread <- solve(crossprod(X, W %*% X))

estimate_outcome <- function(y) {
  beta <- drop(bread %*% crossprod(X, w * y))
  residuals <- drop(y - X %*% beta)
  beta
}

y_earnings <- d$earnings
y_participated <- d$participated

beta_earnings <- estimate_outcome(y_earnings)
beta_participated <- estimate_outcome(y_participated)

contrast <- c(-1, 0, 1, 0)

reduced_form <- sum(contrast * beta_earnings)
first_stage <- sum(contrast * beta_participated)
treatment_effect <- reduced_form / first_stage

loading <- drop(X %*% bread %*% contrast) * w

influence_earnings <- loading * drop(
  y_earnings - X %*% beta_earnings
)
influence_participated <- loading * drop(
  y_participated - X %*% beta_participated
)

joint_covariance <- crossprod(
  cbind(influence_earnings, influence_participated)
)

gradient <- c(
  1 / first_stage,
  -reduced_form / first_stage^2
)

treatment_effect_se <- sqrt(
  drop(t(gradient) %*% joint_covariance %*% gradient)
)

reduced_form_se <- sqrt(joint_covariance[1, 1])
first_stage_se <- sqrt(joint_covariance[2, 2])
n_obs <- nrow(d)

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(
      term = "treatment_effect",
      estimate = unname(as.numeric(treatment_effect)),
      se = unname(as.numeric(treatment_effect_se)),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "reduced_form",
      estimate = unname(as.numeric(reduced_form)),
      se = unname(as.numeric(reduced_form_se)),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "first_stage",
      estimate = unname(as.numeric(first_stage)),
      se = unname(as.numeric(first_stage_se)),
      n_obs = as.integer(n_obs)
    )
  ),
  method_metadata = list(
    estimator = "fuzzy local-linear regression discontinuity with triangular weights",
    vcov = "conventional heteroskedasticity-robust HC0 with delta-method ratio standard error"
  ),
  diagnostics = list()
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
