library(jsonlite)

data <- read.csv("input.csv")
data <- data[order(data$time), ]

forecast_times <- 101:250
forecasts <- numeric(length(forecast_times))

for (i in seq_along(forecast_times)) {
  f <- forecast_times[i]
  history <- data[data$time >= f - 100 & data$time <= f - 1, ]

  levels <- history$y
  lagged <- levels[-length(levels)]
  current <- levels[-1]

  fit <- lm(current ~ lagged)
  forecasts[i] <- coef(fit)[1] + coef(fit)[2] * tail(levels, 1)
}

actual <- data$y[match(forecast_times, data$time)]
rmse <- sqrt(mean((actual - forecasts)^2))

selected_times <- c(101, 150, 200, 250)
selected_forecasts <- forecasts[match(selected_times, forecast_times)]

result <- list(
  task_id = "hard_rolling",
  platform = "r",
  estimates = list(
    list(term = "rmse", estimate = unname(as.numeric(rmse)), se = NULL, n_obs = 150L),
    list(term = "forecast_101", estimate = unname(as.numeric(selected_forecasts[1])), se = NULL, n_obs = 99L),
    list(term = "forecast_150", estimate = unname(as.numeric(selected_forecasts[2])), se = NULL, n_obs = 99L),
    list(term = "forecast_200", estimate = unname(as.numeric(selected_forecasts[3])), se = NULL, n_obs = 99L),
    list(term = "forecast_250", estimate = unname(as.numeric(selected_forecasts[4])), se = NULL, n_obs = 99L)
  ),
  method_metadata = list(
    estimator = "Rolling OLS AR(1) with intercept",
    vcov = "Not applicable"
  ),
  diagnostics = list()
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
