dat <- read.csv("input.csv", stringsAsFactors = FALSE)

y <- dat$y
xmat <- cbind(const = 1, x = dat$x, z = dat$z)
n <- nrow(dat)
censored <- y <= 0
uncensored <- !censored

loglik <- function(par) {
  beta <- par[1:3]
  sigma <- exp(par[4])
  eta <- as.vector(xmat %*% beta)

  ll_cens <- if (any(censored)) {
    pnorm(eta[censored] / sigma, log.p = TRUE)
  } else {
    numeric(0)
  }

  ll_uncens <- if (any(uncensored)) {
    dnorm(y[uncensored], mean = eta[uncensored],
          sd = sigma, log = TRUE)
  } else {
    numeric(0)
  }

  total <- sum(ll_cens) + sum(ll_uncens)
  if (!is.finite(total)) return(1e100)
  -total
}

if (any(uncensored)) {
  ols <- lm(y[uncensored] ~ x[uncensored] + z[uncensored])
  b0 <- coef(ols)
  b0 <- c(
    ifelse(is.finite(b0[1]), b0[1], mean(y[uncensored])),
    ifelse(is.finite(b0[2]), b0[2], 0),
    ifelse(is.finite(b0[3]), b0[3], 0)
  )
  s0 <- sd(residuals(ols))
  if (!is.finite(s0) || s0 <= 0) {
    s0 <- sd(y[uncensored])
  }
} else {
  b0 <- c(0, 0, 0)
  s0 <- 1
}

if (!is.finite(s0) || s0 <= 0) s0 <- 1

fit <- optim(
  par = c(b0, log(s0)),
  fn = loglik,
  method = "BFGS",
  hessian = TRUE,
  control = list(maxit = 10000, reltol = 1e-12)
)

par_hat <- fit$par
beta_hat <- par_hat[1:3]
sigma_hat <- exp(par_hat[4])

info <- fit$hessian
vcov_par <- tryCatch(
  solve(info),
  error = function(e) qr.solve(info)
)

se_beta <- sqrt(pmax(diag(vcov_par)[1:3], 0))
se_sigma <- NA_real_

estimates <- list(
  list(term = "const", estimate = unname(beta_hat[1]),
       se = unname(se_beta[1]), n_obs = n),
  list(term = "x", estimate = unname(beta_hat[2]),
       se = unname(se_beta[2]), n_obs = n),
  list(term = "z", estimate = unname(beta_hat[3]),
       se = unname(se_beta[3]), n_obs = n),
  list(term = "sigma", estimate = unname(sigma_hat),
       se = NULL, n_obs = n)
)

if (requireNamespace("jsonlite", quietly = TRUE)) {
  jsonlite::write_json(
    list(
      task_id = "broad_tobit",
      platform = "r",
      estimates = estimates,
      method_metadata = list(
        estimator = "Homoskedastic Gaussian Tobit maximum likelihood",
        vcov = "Inverse observed information matrix"
      ),
      diagnostics = list()
    ),
    "result.json",
    auto_unbox = TRUE,
    digits = 17,
    pretty = TRUE,
    null = "null"
  )
} else {
  esc <- function(v) {
    if (is.null(v)) "null" else formatC(v, digits = 17, format = "fg")
  }

  lines <- c(
    "{",
    '  "task_id": "broad_tobit",',
    '  "platform": "r",',
    '  "estimates": [',
    sprintf('    {"term":"const","estimate":%s,"se":%s,"n_obs":%d},',
            esc(beta_hat[1]), esc(se_beta[1]), n),
    sprintf('    {"term":"x","estimate":%s,"se":%s,"n_obs":%d},',
            esc(beta_hat[2]), esc(se_beta[2]), n),
    sprintf('    {"term":"z","estimate":%s,"se":%s,"n_obs":%d},',
            esc(beta_hat[3]), esc(se_beta[3]), n),
    sprintf('    {"term":"sigma","estimate":%s,"se":null,"n_obs":%d}',
            esc(sigma_hat), n),
    "  ],",
    '  "method_metadata": {"estimator":"Homoskedastic Gaussian Tobit maximum likelihood","vcov":"Inverse observed information matrix"},',
    '  "diagnostics": {}',
    "}"
  )
  writeLines(lines, "result.json")
}
