library(jsonlite)

data <- read.csv("input.csv", stringsAsFactors = FALSE)
data$date <- as.Date(data$date)
data <- data[order(data$date), ]

data$log_sales <- log(data$sales)
data$vol_change <- c(NA_real_, diff(log(data$vix)))

for (j in 1:15) {
  data[[paste0("lag_", j)]] <- c(
    rep(NA_real_, j),
    head(data$vol_change, -j)
  )
}

regressors <- paste0("lag_", 1:15)
sample <- data[complete.cases(data[, c("log_sales", regressors)]), ]

formula <- as.formula(
  paste("log_sales ~", paste(regressors, collapse = " + "))
)

fit <- lm(formula, data = sample)
X <- model.matrix(fit)
beta <- coef(fit)
N <- nrow(X)
p <- ncol(X)

scores <- X * residuals(fit)

meat <- crossprod(scores)
hac_lags <- 15

for (j in 1:hac_lags) {
  lag_product <- crossprod(
    scores[(j + 1):N, , drop = FALSE],
    scores[1:(N - j), , drop = FALSE]
  )
  weight <- 1 - j / 16
  meat <- meat + weight * (lag_product + t(lag_product))
}

bread <- solve(crossprod(X))
covariance <- (N / (N - 16)) * bread %*% meat %*% bread

contrast <- c(0, rep(1, 15))
cumulative_response <- sum(contrast * beta)
cumulative_se <- sqrt(drop(t(contrast) %*% covariance %*% contrast))

se_lag_1 <- sqrt(covariance["lag_1", "lag_1"])
se_lag_15 <- sqrt(covariance["lag_15", "lag_15"])

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(
      term = "cumulative_response",
      estimate = unname(as.numeric(cumulative_response)),
      se = unname(as.numeric(cumulative_se)),
      n_obs = as.integer(N)
    ),
    list(
      term = "lag_1",
      estimate = unname(as.numeric(beta["lag_1"])),
      se = unname(as.numeric(se_lag_1)),
      n_obs = as.integer(N)
    ),
    list(
      term = "lag_15",
      estimate = unname(as.numeric(beta["lag_15"])),
      se = unname(as.numeric(se_lag_15)),
      n_obs = as.integer(N)
    )
  ),
  method_metadata = list(
    estimator = "OLS with intercept and lags 1 through 15 of log volatility changes",
    vcov = "Bartlett Newey-West HAC, maximum lag 15, correction N/(N-16)"
  ),
  diagnostics = list()
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
