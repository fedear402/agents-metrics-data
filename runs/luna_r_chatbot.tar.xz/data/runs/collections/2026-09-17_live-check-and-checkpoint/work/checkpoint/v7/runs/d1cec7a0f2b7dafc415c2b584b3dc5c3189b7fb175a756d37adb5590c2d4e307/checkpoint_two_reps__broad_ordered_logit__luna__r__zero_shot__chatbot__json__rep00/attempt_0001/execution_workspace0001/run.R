dat <- read.csv("input.csv", stringsAsFactors = FALSE)

y <- as.integer(dat$y)
x <- as.numeric(dat$x)
z <- as.numeric(dat$z)
n <- length(y)

if (!all(y %in% c(1L, 2L, 3L))) {
  stop("y must contain categories 1, 2, and 3")
}

loglik <- function(par) {
  beta <- par[1:2]
  cut1 <- par[3]
  gap <- exp(par[4])
  cut2 <- cut1 + gap
  eta <- beta[1] * x + beta[2] * z
  
  p1 <- plogis(cut1 - eta)
  p2 <- plogis(cut2 - eta) - plogis(cut1 - eta)
  p3 <- plogis(eta - cut2)
  
  p <- ifelse(y == 1L, p1, ifelse(y == 2L, p2, p3))
  if (any(!is.finite(p)) || any(p <= 0)) return(1e100)
  -sum(log(p))
}

start <- c(0, 0, 0, log(1))
fit <- optim(
  par = start,
  fn = loglik,
  method = "BFGS",
  hessian = TRUE,
  control = list(maxit = 10000, reltol = 1e-12)
)

if (fit$convergence != 0) {
  fit <- optim(
    par = fit$par,
    fn = loglik,
    method = "Nelder-Mead",
    control = list(maxit = 20000, reltol = 1e-12)
  )
  fit <- optim(
    par = fit$par,
    fn = loglik,
    method = "BFGS",
    hessian = TRUE,
    control = list(maxit = 10000, reltol = 1e-12)
  )
}

par_hat <- fit$par
vcov_hat <- tryCatch(
  solve(fit$hessian),
  error = function(e) solve(fit$hessian + diag(1e-8, length(par_hat)))
)

se_beta <- sqrt(pmax(diag(vcov_hat)[1:2], 0))

beta <- par_hat[1:2]
cut1 <- par_hat[3]
gap <- exp(par_hat[4])
cut2 <- cut1 + gap

eta_high <- beta[1] * 1 + beta[2] * 0
prob_high <- plogis(eta_high - cut2)

result <- list(
  task_id = "broad_ordered_logit",
  platform = "r",
  estimates = list(
    list(
      term = "x",
      estimate = unname(beta[1]),
      se = unname(se_beta[1]),
      n_obs = n
    ),
    list(
      term = "z",
      estimate = unname(beta[2]),
      se = unname(se_beta[2]),
      n_obs = n
    ),
    list(
      term = "prob_high",
      estimate = unname(prob_high),
      se = NULL,
      n_obs = n
    )
  ),
  method_metadata = list(
    estimator = "maximum likelihood ordered logit",
    vcov = "conventional observed information"
  ),
  diagnostics = list()
)

json_num <- function(x) {
  if (is.null(x)) "null" else sprintf("%.12g", as.numeric(x))
}

json_text <- paste0(
  "{",
  "\"task_id\":\"broad_ordered_logit\",",
  "\"platform\":\"r\",",
  "\"estimates\":[",
  "{\"term\":\"x\",\"estimate\":", json_num(beta[1]),
  ",\"se\":", json_num(se_beta[1]), ",\"n_obs\":", n, "},",
  "{\"term\":\"z\",\"estimate\":", json_num(beta[2]),
  ",\"se\":", json_num(se_beta[2]), ",\"n_obs\":", n, "},",
  "{\"term\":\"prob_high\",\"estimate\":", json_num(prob_high),
  ",\"se\":null,\"n_obs\":", n, "}",
  "],",
  "\"method_metadata\":{",
  "\"estimator\":\"maximum likelihood ordered logit\",",
  "\"vcov\":\"conventional observed information\"",
  "},",
  "\"diagnostics\":{}",
  "}"
)

writeLines(json_text, "result.json")
