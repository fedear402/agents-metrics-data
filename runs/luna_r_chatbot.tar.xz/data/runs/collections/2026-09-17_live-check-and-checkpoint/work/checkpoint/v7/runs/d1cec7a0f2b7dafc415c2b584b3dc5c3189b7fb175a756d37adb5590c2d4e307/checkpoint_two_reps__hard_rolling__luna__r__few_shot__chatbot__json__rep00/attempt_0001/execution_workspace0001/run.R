library(jsonlite)

data <- read.csv("input.csv")
data <- data[order(data$time), ]

forecast_times <- 101:250
forecasts <- numeric(length(forecast_times))

for (i in seq_along(forecast_times)) {
  f <- forecast_times[i]
  history <- data[data$time >= f - 100 & data$time <= f - 1, ]
  history <- history[order(history$time), ]

  levels <- history$y
  lagged <- levels[-length(levels)]
  current <- levels[-1]

  fit <- lm(current ~ lagged)
  coefficients <- coef(fit)

  forecasts[i] <- coefficients[1] + coefficients[2] * tail(levels, 1)
}

actual <- data$y[match(forecast_times, data$time)]
rmse <- sqrt(sum((actual - forecasts)^2) / length(forecast_times))

result <- list(
  task_id = "hard_rolling",
  platform = "r",
  estimates = list(
    list(term = "rmse", estimate = unname(as.numeric(rmse)),
         se = NULL, n_obs = 150L),
    list(term = "forecast_101", estimate = unname(as.numeric(forecasts[1])),
         se = NULL, n_obs = 99L),
    list(term = "forecast_150", estimate = unname(as.numeric(forecasts[which(forecast_times == 150)])),
         se = NULL, n_obs = 99L),
    list(term = "forecast_200", estimate = unname(as.numeric(forecasts[which(forecast_times == 200)])),
         se = NULL, n_obs = 99L),
    list(term = "forecast_250", estimate = unname(as.numeric(forecasts[which(forecast_times == 250)])),
         se = NULL, n_obs = 99L)
  ),
  method_metadata = list(
    estimator = "Rolling OLS AR(1) with intercept",
    vcov = "Not applicable"
  ),
  diagnostics = list()
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
