library(jsonlite)

data <- read.csv("input.csv", stringsAsFactors = FALSE)
data$date <- as.Date(data$date)
data <- data[order(data$date), ]

data$log_vix_change <- c(NA, diff(log(data$vix)))
data$log_sales <- log(data$sales)

for (j in 1:15) {
  data[[paste0("lag_", j)]] <- c(rep(NA, j), head(data$log_vix_change, -j))
}

regressors <- c("log_sales", paste0("lag_", 1:15))
sample <- data[complete.cases(data[, regressors]), regressors]

fit <- lm(log_sales ~ ., data = sample)
X <- model.matrix(fit)
beta <- coef(fit)
residuals <- residuals(fit)
N <- nrow(X)

scores <- X * residuals
hac_lags <- 15
meat <- crossprod(scores)

for (j in seq_len(hac_lags)) {
  lag_product <- crossprod(
    scores[(j + 1):N, , drop = FALSE],
    scores[1:(N - j), , drop = FALSE]
  )
  weight <- 1 - j / 16
  meat <- meat + weight * (lag_product + t(lag_product))
}

bread <- solve(crossprod(X))
covariance <- N / (N - 16) * bread %*% meat %*% bread

contrast <- c(0, rep(1, 15))
cumulative_response <- sum(contrast * beta)
cumulative_se <- sqrt(drop(t(contrast) %*% covariance %*% contrast))

lag_1_index <- which(names(beta) == "lag_1")
lag_15_index <- which(names(beta) == "lag_15")

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(
      term = "cumulative_response",
      estimate = unname(as.numeric(cumulative_response)),
      se = unname(as.numeric(cumulative_se)),
      n_obs = as.integer(N)
    ),
    list(
      term = "lag_1",
      estimate = unname(as.numeric(beta[lag_1_index])),
      se = unname(as.numeric(sqrt(covariance[lag_1_index, lag_1_index]))),
      n_obs = as.integer(N)
    ),
    list(
      term = "lag_15",
      estimate = unname(as.numeric(beta[lag_15_index])),
      se = unname(as.numeric(sqrt(covariance[lag_15_index, lag_15_index]))),
      n_obs = as.integer(N)
    )
  ),
  method_metadata = list(
    estimator = "OLS with lagged log volatility changes",
    vcov = "Bartlett Newey-West HAC, maximum lag 15, scaled by N/(N-16)"
  ),
  diagnostics = list()
)

write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
