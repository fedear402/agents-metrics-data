dat <- read.csv("input.csv", stringsAsFactors = FALSE)

region_key <- !duplicated(dat$region_id)
regions <- dat[region_key, c("region_id", "region_weight", "x", "y")]
rownames(regions) <- as.character(regions$region_id)

weight_sum <- sum(regions$region_weight)
regions$e <- regions$region_weight / weight_sum

e_map <- regions$e
names(e_map) <- as.character(regions$region_id)

x_map <- regions$x
names(x_map) <- as.character(regions$region_id)

y_map <- regions$y
names(y_map) <- as.character(regions$region_id)

dat$e <- unname(e_map[as.character(dat$region_id)])
dat$x_r <- unname(x_map[as.character(dat$region_id)])
dat$y_r <- unname(y_map[as.character(dat$region_id)])

z_region <- aggregate(
  share * shock,
  by = list(region_id = dat$region_id),
  FUN = sum
)
names(z_region)[2] <- "z_r"
z_map <- z_region$z_r
names(z_map) <- as.character(z_region$region_id)
dat$z_r <- unname(z_map[as.character(dat$region_id)])

weighted_mean <- function(v, w) {
  sum(w * v) / sum(w)
}

y_mean <- weighted_mean(regions$y, regions$e)
x_mean <- weighted_mean(regions$x, regions$e)
z_mean <- weighted_mean(z_region$z_r, regions$e)

dat$y0 <- dat$y_r - y_mean
dat$x0 <- dat$x_r - x_mean
dat$z0 <- dat$z_r - z_mean

dat$exposure <- dat$e * dat$share

industry_s <- aggregate(
  exposure,
  by = list(industry_id = dat$industry_id),
  FUN = sum
)
names(industry_s)[2] <- "s"

industry_shock <- aggregate(
  shock,
  by = list(industry_id = dat$industry_id),
  FUN = function(v) v[1]
)
names(industry_shock)[2] <- "shock"

aggregate_bar <- function(value_name) {
  numerator <- aggregate(
    dat$exposure * dat[[value_name]],
    by = list(industry_id = dat$industry_id),
    FUN = sum
  )
  names(numerator)[2] <- "numerator"
  out <- merge(industry_s, numerator, by = "industry_id", sort = FALSE)
  out[[paste0(value_name, "_bar")]] <- out$numerator / out$s
  out
}

y_bar <- aggregate_bar("y0")
x_bar <- aggregate_bar("x0")
z_bar <- aggregate_bar("z0")

shock_data <- Reduce(
  function(a, b) merge(a, b, by = "industry_id", sort = FALSE),
  list(
    industry_s,
    industry_shock,
    y_bar[, c("industry_id", "y0_bar")],
    x_bar[, c("industry_id", "x0_bar")],
    z_bar[, c("industry_id", "z0_bar")]
  )
)

shock_data <- shock_data[is.finite(shock_data$s) & shock_data$s > 0, ]
N <- nrow(shock_data)

iv_hc1 <- function(y, endogenous, instrument, weights) {
  X <- cbind(1, endogenous)
  Z <- cbind(1, instrument)

  sqrt_w <- sqrt(weights)
  Xw <- X * sqrt_w
  Zw <- Z * sqrt_w
  yw <- y * sqrt_w

  cross_z <- crossprod(Zw)
  PzXw <- Zw %*% solve(cross_z, crossprod(Zw, Xw))
  Pzyw <- Zw %*% solve(cross_z, crossprod(Zw, yw))

  A <- crossprod(PzXw, PzXw)
  beta <- solve(A, crossprod(PzXw, Pzyw))

  residuals <- as.numeric(y - X %*% beta)
  PX <- PzXw
  meat <- crossprod(PX * residuals, PX * residuals)

  vcov <- solve(A, meat) %*% solve(A)
  vcov <- vcov * N / (N - ncol(X))

  list(
    estimate = as.numeric(beta[2]),
    se = sqrt(vcov[2, 2])
  )
}

effect_fit <- iv_hc1(
  y = shock_data$y0_bar,
  endogenous = shock_data$x0_bar,
  instrument = shock_data$shock,
  weights = shock_data$s
)

first_stage_fit <- iv_hc1(
  y = shock_data$x0_bar,
  endogenous = shock_data$z0_bar,
  instrument = shock_data$shock,
  weights = shock_data$s
)

effective_shocks <- 1 / sum(shock_data$s^2)

result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(
      term = "effect",
      estimate = effect_fit$estimate,
      se = effect_fit$se,
      n_obs = N
    ),
    list(
      term = "first_stage",
      estimate = first_stage_fit$estimate,
      se = first_stage_fit$se,
      n_obs = N
    ),
    list(
      term = "effective_shocks",
      estimate = effective_shocks,
      se = NULL,
      n_obs = N
    )
  ),
  method_metadata = list(
    estimator = "shock-level weighted 2SLS with intercept",
    vcov = "heteroskedasticity-robust HC1 using structural IV residuals and analytic weights"
  ),
  diagnostics = list()
)

writeLines(
  jsonlite::toJSON(result, auto_unbox = TRUE, null = "null", digits = 17),
  "result.json"
)
