#!/usr/bin/env Rscript

if (!requireNamespace("jsonlite", quietly = TRUE)) {
  stop("Package 'jsonlite' is required.")
}

dat <- read.csv("input.csv", stringsAsFactors = FALSE)
n <- nrow(dat)

y <- as.numeric(dat$y)
xmat <- cbind(const = 1, x = as.numeric(dat$x), z = as.numeric(dat$z))

negloglik <- function(par) {
  beta <- par[1:3]
  sigma <- exp(par[4])
  mu <- drop(xmat %*% beta)

  uncensored <- y > 0
  ll <- numeric(length(y))

  ll[uncensored] <- dnorm(
    y[uncensored],
    mean = mu[uncensored],
    sd = sigma,
    log = TRUE
  )

  ll[!uncensored] <- pnorm(
    0,
    mean = mu[!uncensored],
    sd = sigma,
    lower.tail = TRUE,
    log.p = TRUE
  )

  if (any(!is.finite(ll))) return(.Machine$double.xmax)
  -sum(ll)
}

ols_fit <- lm(y ~ x + z, data = dat)
beta_start <- coef(ols_fit)
beta_start[is.na(beta_start)] <- 0
sigma_start <- max(sd(residuals(ols_fit)), 1e-6)

starts <- list(
  c(beta_start, log(sigma_start)),
  c(rep(0, 3), log(max(sd(y), 1e-6))),
  c(beta_start, log(max(sd(y[y > 0]), 1e-6)))
)

fits <- lapply(
  starts,
  function(s) optim(
    par = s,
    fn = negloglik,
    method = "BFGS",
    hessian = TRUE,
    control = list(maxit = 5000, reltol = 1e-12)
  )
)

fit <- fits[[which.min(vapply(fits, `[[`, numeric(1), "value"))]]

beta_hat <- fit$par[1:3]
sigma_hat <- exp(fit$par[4])

hessian <- fit$hessian
hessian <- (hessian + t(hessian)) / 2

eig <- eigen(hessian, symmetric = TRUE)
eig$values[eig$values < 1e-10] <- 1e-10
hessian_reg <- eig$vectors %*% diag(eig$values) %*% t(eig$vectors)
vcov_transformed <- solve(hessian_reg)

se_beta <- sqrt(pmax(diag(vcov_transformed)[1:3], 0))

estimates <- list(
  list(
    term = "const",
    estimate = unname(beta_hat[1]),
    se = unname(se_beta[1]),
    n_obs = n
  ),
  list(
    term = "x",
    estimate = unname(beta_hat[2]),
    se = unname(se_beta[2]),
    n_obs = n
  ),
  list(
    term = "z",
    estimate = unname(beta_hat[3]),
    se = unname(se_beta[3]),
    n_obs = n
  ),
  list(
    term = "sigma",
    estimate = unname(sigma_hat),
    se = NULL,
    n_obs = n
  )
)

result <- list(
  task_id = "broad_tobit",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "Homoskedastic Gaussian Tobit maximum likelihood",
    vcov = "Inverse observed information from the jointly estimated likelihood"
  ),
  diagnostics = list(
    convergence = fit$convergence,
    log_likelihood = -fit$value
  )
)

jsonlite::write_json(
  result,
  path = "result.json",
  auto_unbox = TRUE,
  digits = 15,
  na = "null"
)
