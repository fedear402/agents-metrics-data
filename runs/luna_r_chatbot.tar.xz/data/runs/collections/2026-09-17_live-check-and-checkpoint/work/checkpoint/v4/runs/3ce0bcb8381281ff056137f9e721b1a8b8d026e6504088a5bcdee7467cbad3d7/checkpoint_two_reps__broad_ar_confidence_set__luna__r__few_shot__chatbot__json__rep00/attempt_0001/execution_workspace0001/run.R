d <- read.csv("input.csv")

n <- nrow(d)
q <- 2
df <- n - 4
critical <- qf(0.95, q, df)
k <- q * critical / df

restricted_y <- lm(y ~ x, data = d)
restricted_d <- lm(endog ~ x, data = d)

unrestricted_y <- lm(y ~ x + z1 + z2, data = d)
unrestricted_d <- lm(endog ~ x + z1 + z2, data = d)

ry <- residuals(restricted_y)
rd <- residuals(restricted_d)
uy <- residuals(unrestricted_y)
ud <- residuals(unrestricted_d)

ssr_r <- function(beta) sum((ry - beta * rd)^2)
ssr_u <- function(beta) sum((uy - beta * ud)^2)

A <- sum(rd^2) - (1 + k) * sum(ud^2)
B <- -2 * (sum(ry * rd) - (1 + k) * sum(uy * ud))
C <- sum(ry^2) - (1 + k) * sum(uy^2)

tol <- 1e-10

if (abs(A) > tol) {
  discriminant <- B^2 - 4 * A * C
  
  if (discriminant < 0 && discriminant > -tol) {
    discriminant <- 0
  }
  
  if (discriminant < 0) {
    stop("The AR confidence set has no real boundary points.")
  }
  
  bounds <- sort(c(
    (-B - sqrt(discriminant)) / (2 * A),
    (-B + sqrt(discriminant)) / (2 * A)
  ))
  
  unbounded <- as.integer(A < 0)
} else if (abs(B) > tol) {
  root <- -C / B
  bounds <- c(root, root)
  unbounded <- 1L
} else {
  if (C <= 0) {
    bounds <- c(-Inf, Inf)
    unbounded <- 1L
  } else {
    bounds <- c(NA_real_, NA_real_)
    unbounded <- 0L
  }
}

accepts <- function(beta) {
  A * beta^2 + B * beta + C <= 0
}

ar_f <- function(beta) {
  ((ssr_r(beta) - ssr_u(beta)) / q) /
    (ssr_u(beta) / df)
}

rows <- list(
  list(
    term = "boundary_low",
    estimate = unname(bounds[1]),
    se = NULL,
    n_obs = n
  ),
  list(
    term = "boundary_high",
    estimate = unname(bounds[2]),
    se = NULL,
    n_obs = n
  ),
  list(
    term = "accepts_zero",
    estimate = as.numeric(accepts(0)),
    se = NULL,
    n_obs = n
  ),
  list(
    term = "unbounded",
    estimate = unname(unbounded),
    se = NULL,
    n_obs = n
  ),
  list(
    term = "ar_f_at_one",
    estimate = unname(ar_f(1)),
    se = NULL,
    n_obs = n
  )
)

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = rows,
  method_metadata = list(
    estimator = "Anderson-Rubin confidence set inversion",
    vcov = "Conventional homoskedastic joint F test"
  ),
  diagnostics = list(
    numerator_df = q,
    denominator_df = df,
    critical_value = critical,
    quadratic_A = A,
    quadratic_B = B,
    quadratic_C = C
  )
)

jsonlite::write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
