dat <- read.csv("input.csv", stringsAsFactors = FALSE)

region_rows <- !duplicated(dat$region_id)
reg <- dat[region_rows, c("region_id", "region_weight", "x", "y")]

e <- reg$region_weight / sum(reg$region_weight)

share_mat <- xtabs(share ~ region_id + industry_id, data = dat)
industries <- colnames(share_mat)

shock_map <- tapply(dat$shock, dat$industry_id, function(v) v[1])
shock <- as.numeric(shock_map[industries])

z <- as.numeric(share_mat %*% shock)
x <- reg$x
y <- reg$y

weighted_mean <- function(v, w) sum(w * v)

y0 <- y - weighted_mean(y, e)
x0 <- x - weighted_mean(x, e)
z0 <- z - weighted_mean(z, e)

s <- as.numeric(colSums(share_mat * e))
keep <- s > 0

share_use <- share_mat[, keep, drop = FALSE]
s_use <- s[keep]
shock_use <- shock[keep]

aggregate_residual <- function(v0) {
  as.numeric(colSums(share_use * (e * v0))) / s_use
}

ybar <- aggregate_residual(y0)
xbar <- aggregate_residual(x0)
zbar <- aggregate_residual(z0)

iv_hc1 <- function(y, endog, instrument, weights) {
  n <- length(y)
  X <- cbind(1, endog)
  Z <- cbind(1, instrument)
  WZ <- Z * weights
  H <- crossprod(Z, WZ)
  G <- crossprod(X, WZ)
  PZX <- Z %*% solve(H, crossprod(Z, X))
  Xhat <- PZX
  beta <- solve(crossprod(X, Xhat * weights), crossprod(X, y * weights))
  residual <- as.numeric(y - X %*% beta)
  
  K <- crossprod(Z, Z * (weights^2 * residual^2))
  B <- G %*% solve(H, t(G))
  middle <- G %*% solve(H, K) %*% solve(H, t(G))
  vcov <- solve(B) %*% middle %*% solve(B) * n / (n - 2)
  
  list(estimate = unname(beta[2]), se = sqrt(vcov[2, 2]))
}

n_industries <- sum(keep)

effect_fit <- iv_hc1(ybar, xbar, shock_use, s_use)
first_stage_fit <- iv_hc1(xbar, zbar, shock_use, s_use)

effective_shocks <- 1 / sum(s_use^2)

json_num <- function(x) {
  format(x, digits = 17, scientific = FALSE, trim = TRUE)
}

result <- sprintf(
  paste0(
    '{\n',
    '  "task_id": "applied_shift_share",\n',
    '  "platform": "r",\n',
    '  "estimates": [\n',
    '    {"term": "effect", "estimate": %s, "se": %s, "n_obs": %d},\n',
    '    {"term": "first_stage", "estimate": %s, "se": %s, "n_obs": %d},\n',
    '    {"term": "effective_shocks", "estimate": %s, "se": null, "n_obs": %d}\n',
    '  ],\n',
    '  "method_metadata": {"estimator": "Borusyak-Hull-Jaravel shock-level weighted 2SLS", "vcov": "HC1 shock-level robust variance with multiplier N/(N-2)"},\n',
    '  "diagnostics": {}\n',
    '}'
  ),
  json_num(effect_fit$estimate),
  json_num(effect_fit$se),
  n_industries,
  json_num(first_stage_fit$estimate),
  json_num(first_stage_fit$se),
  n_industries,
  json_num(effective_shocks),
  n_industries
)

writeLines(result, "result.json")
