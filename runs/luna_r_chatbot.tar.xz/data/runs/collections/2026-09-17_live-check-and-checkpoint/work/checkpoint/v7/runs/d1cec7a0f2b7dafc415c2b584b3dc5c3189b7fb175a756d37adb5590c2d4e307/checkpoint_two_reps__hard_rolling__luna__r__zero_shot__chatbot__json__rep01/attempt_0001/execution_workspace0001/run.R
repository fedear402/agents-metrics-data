dat <- read.csv("input.csv", stringsAsFactors = FALSE)
dat <- dat[order(dat$time), ]

y <- dat$y
forecasts <- numeric(150)

for (f in 101:250) {
  s <- (f - 99):(f - 1)
  fit <- lm(y[s] ~ y[s - 1])
  forecasts[f - 100] <- unname(coef(fit)[1] + coef(fit)[2] * y[f - 1])
}

actual <- y[101:250]
rmse <- sqrt(mean((actual - forecasts)^2))

fmt <- function(x) sprintf("%.15g", x)

json <- paste0(
  "{\n",
  '  "task_id": "hard_rolling",', "\n",
  '  "platform": "r",', "\n",
  '  "estimates": [', "\n",
  '    {"term": "rmse", "estimate": ', fmt(rmse), ', "se": null, "n_obs": 150},', "\n",
  '    {"term": "forecast_101", "estimate": ', fmt(forecasts[1]), ', "se": null, "n_obs": 99},', "\n",
  '    {"term": "forecast_150", "estimate": ', fmt(forecasts[50]), ', "se": null, "n_obs": 99},', "\n",
  '    {"term": "forecast_200", "estimate": ', fmt(forecasts[100]), ', "se": null, "n_obs": 99},', "\n",
  '    {"term": "forecast_250", "estimate": ', fmt(forecasts[150]), ', "se": null, "n_obs": 99}', "\n",
  "  ],\n",
  '  "method_metadata": {"estimator": "rolling OLS AR(1) with intercept", "vcov": "not applicable"},', "\n",
  '  "diagnostics": {}', "\n",
  "}\n"
)

writeLines(json, "result.json")
