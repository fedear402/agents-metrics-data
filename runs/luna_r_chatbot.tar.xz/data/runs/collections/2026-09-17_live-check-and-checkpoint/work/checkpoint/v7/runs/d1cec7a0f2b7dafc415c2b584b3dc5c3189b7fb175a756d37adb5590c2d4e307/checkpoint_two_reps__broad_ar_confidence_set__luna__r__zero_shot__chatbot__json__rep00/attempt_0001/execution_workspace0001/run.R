dat <- read.csv("input.csv")

y <- dat$y
endog <- dat$endog
x <- dat$x
z1 <- dat$z1
z2 <- dat$z2

n <- nrow(dat)
q <- 2
df_resid <- n - 4

X_restricted <- cbind(1, x)
X_full <- cbind(1, x, z1, z2)

residualize <- function(v, X) {
  fit <- lm.fit(X, v)
  fit$residuals
}

ry_r <- residualize(y, X_restricted)
re_r <- residualize(endog, X_restricted)
ry_f <- residualize(y, X_full)
re_f <- residualize(endog, X_full)

rss_coefficients <- function(ry, re) {
  c(
    a = sum(re^2),
    b = -2 * sum(ry * re),
    c = sum(ry^2)
  )
}

coef_r <- rss_coefficients(ry_r, re_r)
coef_f <- rss_coefficients(ry_f, re_f)

crit <- qf(0.95, q, df_resid)

ineq <- c(
  a = df_resid * (coef_r["a"] - coef_f["a"]) -
    crit * q * coef_f["a"],
  b = df_resid * (coef_r["b"] - coef_f["b"]) -
    crit * q * coef_f["b"],
  c = df_resid * (coef_r["c"] - coef_f["c"]) -
    crit * q * coef_f["c"]
)

scale_ineq <- max(1, max(abs(ineq)))
tol <- 1e-12 * scale_ineq

if (abs(ineq["a"]) <= tol) {
  if (abs(ineq["b"]) <= tol) {
    roots <- numeric(0)
  } else {
    roots <- -ineq["c"] / ineq["b"]
  }
} else {
  discriminant <- ineq["b"]^2 - 4 * ineq["a"] * ineq["c"]
  if (discriminant < -tol) {
    roots <- numeric(0)
  } else {
    discriminant <- max(0, discriminant)
    roots <- sort(c(
      (-ineq["b"] - sqrt(discriminant)) / (2 * ineq["a"]),
      (-ineq["b"] + sqrt(discriminant)) / (2 * ineq["a"])
    ))
  }
}

boundary_low <- if (length(roots) >= 1) roots[1] else NA_real_
boundary_high <- if (length(roots) >= 2) roots[length(roots)] else NA_real_

poly_value <- function(beta) {
  ineq["a"] * beta^2 + ineq["b"] * beta + ineq["c"]
}

accepts_zero <- as.numeric(poly_value(0) <= 0)

unbounded <- if (abs(ineq["a"]) > tol) {
  as.numeric(ineq["a"] < 0)
} else if (abs(ineq["b"]) > tol) {
  1
} else {
  as.numeric(ineq["c"] <= 0)
}

ar_f <- function(beta) {
  y_transformed <- y - beta * endog
  rss_r <- sum(residualize(y_transformed, X_restricted)^2)
  rss_f <- sum(residualize(y_transformed, X_full)^2)
  ((rss_r - rss_f) / q) / (rss_f / df_resid)
}

result <- list(
  task_id = "broad_ar_confidence_set",
  platform = "r",
  estimates = list(
    list(term = "boundary_low", estimate = boundary_low,
         se = NA_real_, n_obs = as.integer(n)),
    list(term = "boundary_high", estimate = boundary_high,
         se = NA_real_, n_obs = as.integer(n)),
    list(term = "accepts_zero", estimate = as.numeric(accepts_zero),
         se = NA_real_, n_obs = as.integer(n)),
    list(term = "unbounded", estimate = as.numeric(unbounded),
         se = NA_real_, n_obs = as.integer(n)),
    list(term = "ar_f_at_one", estimate = as.numeric(ar_f(1)),
         se = NA_real_, n_obs = as.integer(n))
  ),
  method_metadata = list(
    estimator = "Anderson-Rubin confidence set using conventional homoskedastic joint F test",
    vcov = "Conventional homoskedastic"
  ),
  diagnostics = list()
)

if (requireNamespace("jsonlite", quietly = TRUE)) {
  jsonlite::write_json(result, "result.json", auto_unbox = TRUE, na = "null")
} else {
  esc <- function(x) {
    if (is.na(x)) "null" else format(x, digits = 17, scientific = FALSE, trim = TRUE)
  }
  txt <- paste0(
    '{',
    '"task_id":"broad_ar_confidence_set",',
    '"platform":"r",',
    '"estimates":[',
    '{"term":"boundary_low","estimate":', esc(boundary_low), ',"se":null,"n_obs":', n, '},',
    '{"term":"boundary_high","estimate":', esc(boundary_high), ',"se":null,"n_obs":', n, '},',
    '{"term":"accepts_zero","estimate":', esc(accepts_zero), ',"se":null,"n_obs":', n, '},',
    '{"term":"unbounded","estimate":', esc(unbounded), ',"se":null,"n_obs":', n, '},',
    '{"term":"ar_f_at_one","estimate":', esc(ar_f(1)), ',"se":null,"n_obs":', n, '}',
    '],',
    '"method_metadata":{"estimator":"Anderson-Rubin confidence set using conventional homoskedastic joint F test","vcov":"Conventional homoskedastic"},',
    '"diagnostics":{}',
    '}'
  )
  writeLines(txt, "result.json")
}
