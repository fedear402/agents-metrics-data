dat <- read.csv("input.csv", stringsAsFactors = FALSE)
dat <- dat[order(dat$time), ]

y <- dat$y
forecast_dates <- 101:250
forecasts <- numeric(length(forecast_dates))

for (i in seq_along(forecast_dates)) {
  f <- forecast_dates[i]
  levels <- y[(f - 100):(f - 1)]
  response <- levels[2:100]
  predictor <- levels[1:99]

  model <- lm(response ~ predictor)
  forecasts[i] <- predict(
    model,
    newdata = data.frame(predictor = levels[100])
  )
}

actual <- y[forecast_dates]
rmse <- sqrt(mean((actual - forecasts)^2))

estimates <- list(
  list(term = "rmse", estimate = unname(rmse), se = NULL, n_obs = 150L),
  list(term = "forecast_101", estimate = unname(forecasts[forecast_dates == 101]), se = NULL, n_obs = 99L),
  list(term = "forecast_150", estimate = unname(forecasts[forecast_dates == 150]), se = NULL, n_obs = 99L),
  list(term = "forecast_200", estimate = unname(forecasts[forecast_dates == 200]), se = NULL, n_obs = 99L),
  list(term = "forecast_250", estimate = unname(forecasts[forecast_dates == 250]), se = NULL, n_obs = 99L)
)

json_escape <- function(x) {
  x <- format(x, digits = 17, scientific = FALSE, trim = TRUE)
  if (!is.finite(as.numeric(x))) "null" else x
}

json_estimate <- function(x) {
  estimate <- if (is.null(x$estimate)) "null" else json_escape(x$estimate)
  se <- if (is.null(x$se)) "null" else json_escape(x$se)

  paste0(
    '{"term":"', x$term,
    '","estimate":', estimate,
    ',"se":', se,
    ',"n_obs":', x$n_obs,
    '}'
  )
}

json <- paste0(
  '{',
  '"task_id":"hard_rolling",',
  '"platform":"r",',
  '"estimates":[',
  paste(vapply(estimates, json_estimate, character(1)), collapse = ","),
  '],',
  '"method_metadata":{"estimator":"Rolling OLS AR(1) with intercept","vcov":"Not applicable"},',
  '"diagnostics":{}',
  '}'
)

writeLines(json, "result.json")
