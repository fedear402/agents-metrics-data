d <- read.csv("input.csv")

n <- nrow(d)
q <- 2L
df <- n - 4L
critical <- qf(0.95, q, df)
k <- q * critical / df

y <- d$y
endog <- d$endog
R <- cbind(1, d$x)
U <- cbind(1, d$x, d$z1, d$z2)

resid_from <- function(v, X) {
  v - X %*% qr.coef(qr(X), v)
}

ry_R <- resid_from(y, R)
rd_R <- resid_from(endog, R)
ry_U <- resid_from(y, U)
rd_U <- resid_from(endog, U)

ss <- function(a, b) sum(a * b)

A <- ss(rd_R, rd_R) - (1 + k) * ss(rd_U, rd_U)
B <- -2 * (ss(ry_R, rd_R) - (1 + k) * ss(ry_U, rd_U))
C <- ss(ry_R, ry_R) - (1 + k) * ss(ry_U, ry_U)

roots <- polyroot(c(C, B, A))
bounds <- sort(Re(roots[abs(Im(roots)) < 1e-8]))

accepts <- function(beta) {
  A * beta^2 + B * beta + C <= 0
}

ar_f <- function(beta) {
  restricted <- y - beta * endog
  rr <- resid_from(restricted, R)
  ru <- resid_from(restricted, U)
  ((sum(rr^2) - sum(ru^2)) / q) / (sum(ru^2) / df)
}

rows <- list(
  list(term = "boundary_low", estimate = bounds[1], se = NULL, n_obs = n),
  list(term = "boundary_high", estimate = bounds[2], se = NULL, n_obs = n),
  list(term = "accepts_zero", estimate = as.numeric(accepts(0)), se = NULL, n_obs = n),
  list(term = "unbounded", estimate = as.numeric(A < 0), se = NULL, n_obs = n),
  list(term = "ar_f_at_one", estimate = ar_f(1), se = NULL, n_obs = n)
)

jsonlite::write_json(
  list(
    task_id = "broad_ar_confidence_set",
    platform = "r",
    estimates = rows,
    method_metadata = list(
      estimator = "Anderson-Rubin inversion with homoskedastic joint F test",
      vcov = "conventional homoskedastic"
    ),
    diagnostics = list()
  ),
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 16,
  pretty = TRUE
)
