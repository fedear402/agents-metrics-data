dat <- read.csv("input.csv")

dat <- dat[
  is.finite(dat$score) &
    is.finite(dat$participated) &
    is.finite(dat$earnings) &
    abs(dat$score) < 1,
]

x <- dat$score
right <- as.numeric(x >= 0)
w <- 1 - abs(x)

X <- cbind(
  intercept = 1,
  discontinuity = right,
  score = x,
  score_right = x * right
)

fit_hc0 <- function(y) {
  xtw <- t(X * w)
  bread <- solve(xtw %*% X)
  beta <- bread %*% (xtw %*% y)
  residuals <- as.numeric(y - X %*% beta)
  meat <- t(X * (w^2 * residuals)) %*% X
  vcov <- bread %*% meat %*% bread
  list(beta = as.numeric(beta), vcov = vcov)
}

fit_earnings <- fit_hc0(dat$earnings)
fit_participation <- fit_hc0(dat$participated)

reduced_form <- fit_earnings$beta[2]
first_stage <- fit_participation$beta[2]

var_reduced_form <- fit_earnings$vcov[2, 2]
var_first_stage <- fit_participation$vcov[2, 2]

u_earnings <- as.numeric(dat$earnings - X %*% fit_earnings$beta)
u_participation <- as.numeric(dat$participated - X %*% fit_participation$beta)

bread_earnings <- solve(t(X * w) %*% X)
bread_participation <- solve(t(X * w) %*% X)

cross_meat <- t(X * (w^2 * u_earnings * u_participation)) %*% X
cross_vcov <- bread_earnings %*% cross_meat %*% bread_participation
cov_discontinuities <- cross_vcov[2, 2]

treatment_effect <- reduced_form / first_stage

var_treatment_effect <-
  var_reduced_form / first_stage^2 +
  reduced_form^2 * var_first_stage / first_stage^4 -
  2 * reduced_form * cov_discontinuities / first_stage^3

se_treatment_effect <- sqrt(max(0, var_treatment_effect))
n_obs <- nrow(dat)

fmt <- function(x) {
  if (is.finite(x)) formatC(x, format = "fg", digits = 15)
  else "null"
}

result <- paste0(
  '{',
  '"task_id":"applied_fuzzy_rd",',
  '"platform":"r",',
  '"estimates":[',
  '{"term":"treatment_effect","estimate":', fmt(treatment_effect),
  ',"se":', fmt(se_treatment_effect), ',"n_obs":', n_obs, '},',
  '{"term":"reduced_form","estimate":', fmt(reduced_form),
  ',"se":', fmt(sqrt(max(0, var_reduced_form))), ',"n_obs":', n_obs, '},',
  '{"term":"first_stage","estimate":', fmt(first_stage),
  ',"se":', fmt(sqrt(max(0, var_first_stage))), ',"n_obs":', n_obs, '}',
  '],',
  '"method_metadata":{',
  '"estimator":"fuzzy regression discontinuity with weighted local-linear fits and delta-method ratio",',
  '"vcov":"conventional heteroskedasticity-robust HC0 with joint cross-outcome covariance"',
  '},',
  '"diagnostics":{}',
  '}'
)

writeLines(result, "result.json")
