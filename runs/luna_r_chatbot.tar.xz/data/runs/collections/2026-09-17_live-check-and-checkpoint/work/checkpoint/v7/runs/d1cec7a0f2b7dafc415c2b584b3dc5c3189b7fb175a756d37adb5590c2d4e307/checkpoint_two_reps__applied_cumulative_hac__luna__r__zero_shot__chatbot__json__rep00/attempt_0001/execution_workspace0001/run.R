d <- read.csv("input.csv", stringsAsFactors = FALSE)
d <- d[order(as.Date(d$date)), ]

n_total <- nrow(d)
log_sales <- log(d$sales)
log_vix <- log(d$vix)
vol_change <- c(NA_real_, diff(log_vix))

idx <- 17:n_total
y <- log_sales[idx]

X <- cbind(
  intercept = 1,
  sapply(1:15, function(k) vol_change[idx - k])
)
colnames(X) <- c("intercept", paste0("lag_", 1:15))

keep <- complete.cases(y, X)
y <- y[keep]
X <- X[keep, , drop = FALSE]

n_obs <- nrow(X)
p <- ncol(X)

beta <- solve(crossprod(X), crossprod(X, y))
resid <- as.numeric(y - X %*% beta)
scores <- X * resid

meat <- crossprod(scores) / n_obs

for (j in 1:15) {
  weight <- 1 - j / 16
  gamma_j <- crossprod(scores[(j + 1):n_obs, , drop = FALSE],
                       scores[1:(n_obs - j), , drop = FALSE]) / n_obs
  meat <- meat + weight * (gamma_j + t(gamma_j))
}

bread <- solve(crossprod(X) / n_obs)
vcov_nw <- bread %*% meat %*% bread / n_obs
vcov_nw <- vcov_nw * n_obs / (n_obs - 16)

cumulative_response <- sum(beta[2:16])
cumulative_se <- sqrt(sum(vcov_nw[2:16, 2:16]))

fmt <- function(x) sprintf("%.15g", as.numeric(x))

json <- paste0(
  "{",
  "\"task_id\":\"applied_cumulative_hac\",",
  "\"platform\":\"r\",",
  "\"estimates\":[",
  "{\"term\":\"cumulative_response\",\"estimate\":", fmt(cumulative_response),
  ",\"se\":", fmt(cumulative_se), ",\"n_obs\":", n_obs, "},",
  "{\"term\":\"lag_1\",\"estimate\":", fmt(beta[2]),
  ",\"se\":", fmt(sqrt(vcov_nw[2, 2])), ",\"n_obs\":", n_obs, "},",
  "{\"term\":\"lag_15\",\"estimate\":", fmt(beta[16]),
  ",\"se\":", fmt(sqrt(vcov_nw[16, 16])), ",\"n_obs\":", n_obs, "}",
  "],",
  "\"method_metadata\":{",
  "\"estimator\":\"OLS with intercept and lags 1 through 15 of first-differenced log volatility\",",
  "\"vcov\":\"Newey-West HAC covariance, maximum lag 15, Bartlett weights, scaled by N/(N-16)\"",
  "},",
  "\"diagnostics\":{}",
  "}"
)

writeLines(json, "result.json")
