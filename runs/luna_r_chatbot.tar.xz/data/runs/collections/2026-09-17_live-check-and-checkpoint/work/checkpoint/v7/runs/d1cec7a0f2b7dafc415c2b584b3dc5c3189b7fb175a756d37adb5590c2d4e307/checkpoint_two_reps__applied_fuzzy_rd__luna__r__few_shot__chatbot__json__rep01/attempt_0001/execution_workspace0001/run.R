library(jsonlite)

dat <- read.csv("input.csv")

keep <- abs(dat$score) < 1
dat <- dat[keep, , drop = FALSE]

score <- dat$score
weights <- 1 - abs(score)
left <- as.numeric(score < 0)
right <- as.numeric(score >= 0)

X <- cbind(
  left_intercept = left,
  left_slope = left * score,
  right_intercept = right,
  right_slope = right * score
)

W <- diag(weights)
bread <- solve(crossprod(X, W %*% X))

Y <- cbind(
  earnings = dat$earnings,
  participated = dat$participated
)

coefficients <- bread %*% crossprod(X, W %*% Y)
residuals <- Y - X %*% coefficients

meat <- matrix(0, nrow = 4, ncol = 4)
joint_covariance <- matrix(0, nrow = 2, ncol = 2)

for (i in seq_len(nrow(X))) {
  xi <- matrix(X[i, ], ncol = 1)
  ri <- matrix(residuals[i, ], ncol = 1)
  joint_covariance <- joint_covariance +
    (weights[i]^2) * crossprod(ri) *
    (xi %*% t(xi))
}

covariance_by_coefficient <- array(0, dim = c(4, 4, 2, 2))

for (a in 1:2) {
  for (b in 1:2) {
    meat_ab <- matrix(0, nrow = 4, ncol = 4)
    for (i in seq_len(nrow(X))) {
      xi <- matrix(X[i, ], ncol = 1)
      meat_ab <- meat_ab +
        weights[i]^2 * residuals[i, a] * residuals[i, b] *
        (xi %*% t(xi))
    }
    covariance_by_coefficient[, , a, b] <-
      bread %*% meat_ab %*% bread
  }
}

contrast <- c(-1, 0, 1, 0)
discontinuities <- numeric(2)
discontinuity_covariance <- matrix(0, nrow = 2, ncol = 2)

for (a in 1:2) {
  discontinuities[a] <- sum(contrast * coefficients[, a])
  for (b in 1:2) {
    discontinuity_covariance[a, b] <-
      drop(t(contrast) %*%
             covariance_by_coefficient[, , a, b] %*%
             contrast)
  }
}

reduced_form <- discontinuities[1]
first_stage <- discontinuities[2]

gradient <- c(
  1 / first_stage,
  -reduced_form / first_stage^2
)

treatment_effect <- reduced_form / first_stage
treatment_variance <- drop(
  t(gradient) %*% discontinuity_covariance %*% gradient
)

n_obs <- nrow(dat)

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(
      term = "treatment_effect",
      estimate = unname(treatment_effect),
      se = unname(sqrt(treatment_variance)),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "reduced_form",
      estimate = unname(reduced_form),
      se = unname(sqrt(discontinuity_covariance[1, 1])),
      n_obs = as.integer(n_obs)
    ),
    list(
      term = "first_stage",
      estimate = unname(first_stage),
      se = unname(sqrt(discontinuity_covariance[2, 2])),
      n_obs = as.integer(n_obs)
    )
  ),
  method_metadata = list(
    estimator = "Fuzzy local-linear regression discontinuity with triangular kernel weights",
    vcov = "Heteroskedasticity-robust HC0 with joint delta-method covariance"
  ),
  diagnostics = list()
)

writeLines(
  toJSON(result, auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE),
  "result.json"
)
