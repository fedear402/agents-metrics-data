dat <- read.csv("input.csv")

y <- as.integer(dat$y)
xmat <- cbind(1, dat$x, dat$z)
n <- nrow(dat)

negloglik <- function(beta) {
  b1 <- beta[1:3]
  b2 <- beta[4:6]
  eta1 <- drop(xmat %*% b1)
  eta2 <- drop(xmat %*% b2)
  m <- pmax(0, pmax(eta1, eta2))
  den <- exp(-m) + exp(eta1 - m) + exp(eta2 - m)
  logp0 <- -m - log(den)
  logp1 <- eta1 - m - log(den)
  logp2 <- eta2 - m - log(den)
  ll <- ifelse(y == 0L, logp0,
               ifelse(y == 1L, logp1, logp2))
  value <- -sum(ll)
  if (!is.finite(value)) 1e100 else value
}

fit <- optim(
  par = rep(0, 6),
  fn = negloglik,
  method = "BFGS",
  hessian = FALSE,
  control = list(maxit = 10000, reltol = 1e-12)
)

beta <- fit$par
b1 <- beta[1:3]
b2 <- beta[4:6]

eta1 <- drop(xmat %*% b1)
eta2 <- drop(xmat %*% b2)
m <- pmax(0, pmax(eta1, eta2))
e1 <- exp(eta1 - m)
e2 <- exp(eta2 - m)
e0 <- exp(-m)
den <- e0 + e1 + e2
p1 <- e1 / den
p2 <- e2 / den

info <- matrix(0, 6, 6)

for (i in seq_len(n)) {
  xi <- xmat[i, , drop = FALSE]
  p <- c(p1[i], p2[i])
  v <- diag(p) - tcrossprod(p)
  zi <- matrix(0, 2, 6)
  zi[1, 1:3] <- xi
  zi[2, 4:6] <- xi
  info <- info + crossprod(zi, v %*% zi)
}

vcov <- solve(info)
se <- sqrt(pmax(0, diag(vcov)))

p2_zero <- 1 / (1 + exp(-b2[1]) + exp(-b1[1]))

esc <- function(v) {
  if (is.null(v) || length(v) == 0L || is.na(v)) "null"
  else formatC(as.numeric(v), format = "fg", digits = 17)
}

json_terms <- paste0(
  '{"term":"', c("x_cat1", "z_cat1", "x_cat2", "z_cat2", "prob_cat2_zero"),
  '","estimate":', c(
    esc(b1[2]), esc(b1[3]), esc(b2[2]), esc(b2[3]), esc(p2_zero)
  ),
  ',"se":', c(
    esc(se[2]), esc(se[3]), esc(se[5]), esc(se[6]), "null"
  ),
  ',"n_obs":', n, "}"
)

result <- paste0(
  '{"task_id":"broad_multinomial_logit",',
  '"platform":"r",',
  '"estimates":[', paste(json_terms, collapse = ","), "],",
  '"method_metadata":{"estimator":"multinomial logit maximum likelihood",',
  '"vcov":"conventional observed information"},',
  '"diagnostics":{}}'
)

writeLines(result, "result.json")
