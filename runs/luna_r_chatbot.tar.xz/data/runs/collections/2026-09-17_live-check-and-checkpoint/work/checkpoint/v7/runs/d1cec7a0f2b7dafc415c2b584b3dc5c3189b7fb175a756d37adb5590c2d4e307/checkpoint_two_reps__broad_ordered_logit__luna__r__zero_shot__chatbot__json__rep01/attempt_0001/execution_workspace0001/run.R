#!/usr/bin/env Rscript

df <- read.csv("input.csv")

df$y <- ordered(df$y, levels = c(1, 2, 3))

fit <- MASS::polr(
  y ~ x + z,
  data = df,
  method = "logistic",
  Hess = TRUE,
  model = FALSE
)

vc <- vcov(fit)
co <- coef(fit)

eta <- unname(co["x"] * 1 + co["z"] * 0)
cut2 <- unname(fit$zeta[2])
prob_high <- plogis(eta - cut2)

n_obs <- nrow(df)

result <- list(
  task_id = "broad_ordered_logit",
  platform = "r",
  estimates = list(
    list(
      term = "x",
      estimate = unname(co["x"]),
      se = sqrt(vc["x", "x"]),
      n_obs = n_obs
    ),
    list(
      term = "z",
      estimate = unname(co["z"]),
      se = sqrt(vc["z", "z"]),
      n_obs = n_obs
    ),
    list(
      term = "prob_high",
      estimate = prob_high,
      se = NULL,
      n_obs = n_obs
    )
  ),
  method_metadata = list(
    estimator = "Maximum likelihood ordered logit with two free cutpoints and no intercept",
    vcov = "Conventional observed-information standard errors"
  ),
  diagnostics = list()
)

jsonlite::write_json(
  result,
  "result.json",
  auto_unbox = TRUE,
  null = "null",
  digits = 17
)
