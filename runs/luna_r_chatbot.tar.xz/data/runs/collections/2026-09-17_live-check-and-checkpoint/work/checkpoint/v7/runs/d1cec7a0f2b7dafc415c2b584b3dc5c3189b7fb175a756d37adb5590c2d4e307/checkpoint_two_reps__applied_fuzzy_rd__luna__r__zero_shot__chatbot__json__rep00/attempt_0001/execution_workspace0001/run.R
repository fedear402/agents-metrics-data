dat <- read.csv("input.csv")

dat <- dat[is.finite(dat$score) &
           is.finite(dat$participated) &
           is.finite(dat$earnings) &
           abs(dat$score) < 1, ]

n_obs <- nrow(dat)

right <- as.numeric(dat$score >= 0)
x <- cbind(
  intercept = 1,
  right = right,
  score = dat$score,
  right_score = right * dat$score
)

w <- 1 - abs(dat$score)

fit_local <- function(y) {
  xtwx <- crossprod(x, w * x)
  beta <- solve(xtwx, crossprod(x, w * y))
  residuals <- as.numeric(y - x %*% beta)

  meat <- matrix(0, nrow = ncol(x), ncol = ncol(x))
  for (i in seq_len(nrow(x))) {
    xi <- matrix(x[i, ], ncol = 1)
    meat <- meat + (w[i]^2 * residuals[i]^2) * (xi %*% t(xi))
  }

  vcov <- solve(xtwx) %*% meat %*% solve(xtwx)

  list(
    estimate = as.numeric(beta[2]),
    vcov = vcov,
    residuals = residuals
  )
}

rf_fit <- fit_local(dat$earnings)
fs_fit <- fit_local(dat$participated)

reduced_form <- rf_fit$estimate
first_stage <- fs_fit$estimate

var_rf <- rf_fit$vcov[2, 2]
var_fs <- fs_fit$vcov[2, 2]

cross_meat <- matrix(0, nrow = ncol(x), ncol = ncol(x))
for (i in seq_len(nrow(x))) {
  xi <- matrix(x[i, ], ncol = 1)
  cross_meat <- cross_meat +
    (w[i]^2 * rf_fit$residuals[i] * fs_fit$residuals[i]) *
    (xi %*% t(xi))
}

bread <- solve(crossprod(x, w * x))
cross_vcov <- bread %*% cross_meat %*% bread
cov_rf_fs <- cross_vcov[2, 2]

treatment_effect <- reduced_form / first_stage
var_treatment_effect <-
  var_rf / first_stage^2 +
  reduced_form^2 * var_fs / first_stage^4 -
  2 * reduced_form * cov_rf_fs / first_stage^3

se_rf <- sqrt(max(var_rf, 0))
se_fs <- sqrt(max(var_fs, 0))
se_treatment_effect <- sqrt(max(var_treatment_effect, 0))

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(
      term = "treatment_effect",
      estimate = treatment_effect,
      se = se_treatment_effect,
      n_obs = n_obs
    ),
    list(
      term = "reduced_form",
      estimate = reduced_form,
      se = se_rf,
      n_obs = n_obs
    ),
    list(
      term = "first_stage",
      estimate = first_stage,
      se = se_fs,
      n_obs = n_obs
    )
  ),
  method_metadata = list(
    estimator = "Fuzzy local-linear regression discontinuity with triangular weights",
    vcov = "HC0 heteroskedasticity-robust covariance with delta-method treatment-effect standard error"
  ),
  diagnostics = list()
)

jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = 17)
