import json
import os

import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
hh = pd.read_csv(os.path.join(HERE, "households.csv"))
census = pd.read_csv(os.path.join(HERE, "census.csv")).set_index("eligible")["nonrecipient_population"]

df = hh[hh["recipient"] == 0].copy()
e = df["eligible"].to_numpy(float)
ne = 1.0 - e
dose = df["dose"].to_numpy(float)
base = df["baseline"].to_numpy(float)
inst = df["instrument"].to_numpy(float)
w = df["weight"].to_numpy(float)
y = df["outcome"].to_numpy(float)

X = np.column_stack([dose * ne, dose * e, ne, e, base * ne, base * e])
Z = np.column_stack([ne, e, base * ne, base * e, inst * ne, inst * e])

A = np.linalg.inv((X.T * w) @ Z @ np.linalg.inv(Z.T @ (Z * w[:, None])) @ (Z.T * w) @ X)
beta = A @ (X.T * w) @ Z @ np.linalg.inv(Z.T @ (Z * w[:, None])) @ (Z.T * w) @ y

slope0, slope1 = beta[0], beta[1]


def wmean(mask):
    return float(np.sum(w[mask] * dose[mask]) / np.sum(w[mask]))


inel = e == 0
el = e == 1
mean0 = wmean(inel)
mean1 = wmean(el)
ineligible_effect = float(slope0 * mean0)
eligible_effect = float(slope1 * mean1)

n0 = float(census.loc[0])
n1 = float(census.loc[1])
population_effect = float((n0 * ineligible_effect + n1 * eligible_effect) / (n0 + n1))

n_obs = int(len(df))
result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {"term": "ineligible_effect", "estimate": ineligible_effect, "se": None, "n_obs": n_obs},
        {"term": "eligible_nonrecipient_effect", "estimate": eligible_effect, "se": None, "n_obs": n_obs},
        {"term": "population_effect", "estimate": population_effect, "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS, no intercept, weight = weight column",
        "endogenous": ["dose*(1-eligible)", "dose*eligible"],
        "exogenous": ["1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"],
        "instruments": [
            "1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible",
            "instrument*(1-eligible)", "instrument*eligible",
        ],
        "sample": "households with recipient == 0 (both treatment statuses)",
        "group_effect": "fitted dose slope times household-weighted mean dose in group",
        "counterfactual": "dose set to zero for every retained household (synthetic convention)",
        "population_weights": {"ineligible": n0, "eligible": n1},
    },
    "diagnostics": {
        "n_retained": n_obs,
        "n_ineligible": int(inel.sum()),
        "n_eligible": int(el.sum()),
        "slope_ineligible": float(slope0),
        "slope_eligible": float(slope1),
        "weighted_mean_dose_ineligible": mean0,
        "weighted_mean_dose_eligible": mean1,
        "all_other_coefficients": {
            "baseline*(1-eligible)": float(beta[4]),
            "baseline*eligible": float(beta[5]),
            "1-eligible": float(beta[2]),
            "eligible": float(beta[3]),
        },
    },
}

with open(os.path.join(HERE, "result.json"), "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result["estimates"], indent=2))
print(json.dumps(result["diagnostics"], indent=2))
