import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
h = 1.0
d = df[df["score"].abs() < h].copy()
d["w"] = 1 - d["score"].abs()
right = d[d["score"] >= 0]
left = d[d["score"] < 0]


def side_fit(s):
    X = np.column_stack([np.ones(len(s)), s["score"].to_numpy()])
    w = s["w"].to_numpy()
    Y = s["earnings"].to_numpy()
    D = s["participated"].to_numpy().astype(float)
    XtWX_inv = np.linalg.inv(X.T @ (X * w[:, None]))
    bY = XtWX_inv @ (X.T @ (w * Y))
    bD = XtWX_inv @ (X.T @ (w * D))
    eY = Y - X @ bY
    eD = D - X @ bD
    meat = np.zeros((2, 2, 2, 2))
    # blocks: (outcome Y/D) x (outcome Y/D) cross-covariances, each 2x2 for coefficient vectors
    scores = {"Y": w[:, None] * X * eY[:, None], "D": w[:, None] * X * eD[:, None]}
    V = {}
    for a in ("Y", "D"):
        for b in ("Y", "D"):
            M = scores[a].T @ scores[b]
            V[(a, b)] = XtWX_inv @ M @ XtWX_inv
    return {"Y": bY[0], "D": bD[0]}, V, len(s)


rR, VR, nR = side_fit(right)
rL, VL, nL = side_fit(left)

rf = rR["Y"] - rL["Y"]
fs = rR["D"] - rL["D"]
var_rf = VR[("Y", "Y")][0, 0] + VL[("Y", "Y")][0, 0]
var_fs = VR[("D", "D")][0, 0] + VL[("D", "D")][0, 0]
cov_rf_fs = VR[("Y", "D")][0, 0] + VL[("Y", "D")][0, 0]

te = rf / fs
var_te = (var_rf / fs**2 + rf**2 * var_fs / fs**4 - 2 * rf * cov_rf_fs / fs**3)
se_te = float(np.sqrt(var_te))

n_total = nR + nL
result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": float(te), "se": se_te, "n_obs": int(n_total)},
        {"term": "reduced_form", "estimate": float(rf), "se": float(np.sqrt(var_rf)), "n_obs": int(n_total)},
        {"term": "first_stage", "estimate": float(fs), "se": float(np.sqrt(var_fs)), "n_obs": int(n_total)},
    ],
    "method_metadata": {
        "estimator": "Sharp-style local linear fuzzy RD, triangular kernel, bandwidth 1, separate slopes per side, weighted least squares; treatment effect = reduced form / first stage (delta method)",
        "vcov": "HC0 heteroskedasticity-robust sandwich (no small-sample correction), joint covariance across outcome and treatment regressions, delta method for ratio",
    },
    "diagnostics": {
        "n_right": int(nR),
        "n_left": int(nL),
        "bandwidth": h,
        "cutoff": 0,
    },
}
with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))
