import csv, numpy as np
from collections import defaultdict
d = "/private/tmp/prospective_task_mv6ml8zp/"
ind = {r["code"]: int(r["industry"]) for r in csv.DictReader(open(d+"crosswalk.csv"))}
tr = {}
for r in csv.DictReader(open(d+"trade.csv")):
    tr[(int(r["period"]), ind[r["code"]])] = r
emp = defaultdict(float)
for r in csv.DictReader(open(d+"employment.csv")):
    emp[(int(r["area"]), int(r["period"]), r["vintage"], int(r["industry"]))] += float(r["employment"])
tot = {}; pop = {}
for r in csv.DictReader(open(d+"areas.csv")):
    k = (int(r["area"]), int(r["period"]), r["vintage"])
    tot[k] = float(r["total_employment"])
    if r["vintage"] == "base": pop[(int(r["area"]), int(r["period"]))] = float(r["population"])
areas = sorted({k[0] for k in tot})
def nat(p, v, j): return sum(emp[(a, p, v, j)] for a in areas)
def expo(v, chg, a, p):
    s = 0.0
    for j in range(4):
        t = tr[(p, j)]
        shock = float(t[chg]) / nat(p, v, j) / (float(t["price_index"])/100) / 1000 * (10/float(t["years"]))
        s += emp[(a, p, v, j)] / tot[(a, p, v)] * shock
    return s
rows = []
for r in csv.DictReader(open(d+"outcomes.csv")):
    a, p = int(r["area"]), int(r["period"])
    rows.append((float(r["change_pp"]), p, float(r["control"]), expo("base","us_change",a,p), expo("early","other_change",a,p), pop[(a,p)]))
y = np.array([r[0] for r in rows]); per = np.array([r[1] for r in rows], float); c = np.array([r[2] for r in rows])
x = np.array([r[3] for r in rows]); z = np.array([r[4] for r in rows]); w = np.array([r[5] for r in rows])
X = np.column_stack([np.ones(len(y)), per, c, x]); Z = np.column_stack([np.ones(len(y)), per, c, z])
A = Z.T @ (w[:, None] * Z)
beta = np.linalg.solve(X.T @ Z @ np.linalg.solve(A, Z.T @ X), X.T @ Z @ np.linalg.solve(A, Z.T @ (w*y)))
print("n", len(y), "iv_slope", repr(beta[-1]))
print("x a0p0", repr(expo("base","us_change",0,0)), "x a0p1", repr(expo("base","us_change",0,1)), "z a0p0", repr(expo("early","other_change",0,0)))
ZWX = Z.T @ (w[:, None] * X); ZWy = Z.T @ (w*y)
M = ZWX.T @ np.linalg.solve(A, ZWX)
beta2 = np.linalg.solve(M, ZWX.T @ np.linalg.solve(A, ZWy))
print("corrected iv_slope", repr(beta2[-1]))
