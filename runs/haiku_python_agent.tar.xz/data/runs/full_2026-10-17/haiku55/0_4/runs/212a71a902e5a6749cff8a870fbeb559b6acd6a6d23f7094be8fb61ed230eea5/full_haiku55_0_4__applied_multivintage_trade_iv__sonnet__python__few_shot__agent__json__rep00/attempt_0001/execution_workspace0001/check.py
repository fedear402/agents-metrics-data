import numpy as np, pandas as pd, json
A = pd.read_csv("areas.csv"); E = pd.read_csv("employment.csv"); T = pd.read_csv("trade.csv")
C = pd.read_csv("crosswalk.csv"); O = pd.read_csv("outcomes.csv")
T = T.merge(C, on="code")
def expo(vint, col):
    out = {}
    for p in [0, 1]:
        t = T[T.period == p].set_index("industry")
        e = E[(E.period == p) & (E.vintage == vint)].groupby(["area", "industry"]).employment.sum()
        natl = e.groupby("industry").sum()
        tot = A[(A.period == p) & (A.vintage == vint)].set_index("area").total_employment
        for a in range(36):
            s = 0.0
            for j in range(4):
                emp = e.get((a, j), 0)
                s += emp / tot[a] * (t.loc[j, col] / natl[j]) / (t.loc[j, "price_index"] / 100) / 1000 * (10 / t.loc[j, "years"])
            out[(a, p)] = s
    return out
x = expo("base", "us_change"); z = expo("early", "other_change")
df = O.copy()
df["x"] = [x[(a, p)] for a, p in zip(df.area, df.period)]
df["z"] = [z[(a, p)] for a, p in zip(df.area, df.period)]
df["w"] = [A[(A.area == a) & (A.period == p) & (A.vintage == "base")].population.item() for a, p in zip(df.area, df.period)]
X = np.column_stack([np.ones(72), df.period, df.control, df.x])
Zm = np.column_stack([np.ones(72), df.period, df.control, df.z])
y = df.change_pp.values; w = df.w.values.astype(float)
W = np.diag(w)
Pz = Zm @ np.linalg.solve(Zm.T @ W @ Zm, Zm.T @ W)
b = np.linalg.solve(X.T @ W @ Pz @ X, X.T @ W @ Pz @ y)
print("manual iv_slope", repr(b[-1]))
print("manual x a0p0", x[(0,0)], "x a0p1", x[(0,1)], "z a0p0", z[(0,0)])
# identity: first stage with weights reproduces slope via Wald-type ratio when only x and z present
Xr = np.column_stack([np.ones(72), df.period, df.control]); 
ry = np.linalg.solve(Xr.T@W@Xr, Xr.T@W@y); rx = np.linalg.solve(Xr.T@W@Xr, Xr.T@W@df.x.values)
rz = np.linalg.solve(Xr.T@W@Xr, Xr.T@W@df.z.values)
ry_res = y - Xr@ry; rx_res = df.x.values - Xr@rx; rz_res = df.z.values - Xr@rz
print("partialled ratio", (rz_res*w)@ry_res/((rz_res*w)@rx_res))
r = json.load(open("result.json"))
print("result.json iv_slope", r["estimates"][0]["estimate"], "n", r["estimates"][0]["n_obs"])
