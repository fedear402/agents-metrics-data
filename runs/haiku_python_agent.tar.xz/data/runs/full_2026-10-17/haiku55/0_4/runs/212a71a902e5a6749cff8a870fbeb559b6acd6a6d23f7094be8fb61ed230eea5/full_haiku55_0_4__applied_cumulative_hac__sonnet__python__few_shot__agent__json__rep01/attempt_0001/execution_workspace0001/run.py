import json
import numpy as np
import pandas as pd

LAGS = 15
df = pd.read_csv("input.csv")
df["date"] = pd.to_datetime(df["date"])
df = df.sort_values("date").reset_index(drop=True)
df["dlog_vix"] = np.log(df["vix"]).diff()
for k in range(1, LAGS + 1):
    df[f"lag_{k}"] = df["dlog_vix"].shift(k)
df["log_sales"] = np.log(df["sales"])

sample = df.dropna(subset=["log_sales"] + [f"lag_{k}" for k in range(1, LAGS + 1)])
N = len(sample)
X = np.column_stack([np.ones(N)] + [sample[f"lag_{k}"].to_numpy() for k in range(1, LAGS + 1)])
y = sample["log_sales"].to_numpy()
p = X.shape[1]

beta = np.linalg.lstsq(X, y, rcond=None)[0]
resid = y - X @ beta
scores = X * resid[:, None]
meat = scores.T @ scores
for j in range(1, LAGS + 1):
    w = 1 - j / (LAGS + 1)
    gamma = scores[j:].T @ scores[:-j]
    meat += w * (gamma + gamma.T)
bread = np.linalg.inv(X.T @ X)
V = (N / (N - p)) * bread @ meat @ bread

c = np.zeros(p)
c[1:] = 1.0
cum = float(c @ beta)
cum_se = float(np.sqrt(c @ V @ c))

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {"term": "cumulative_response", "estimate": cum, "se": cum_se, "n_obs": N},
        {"term": "lag_1", "estimate": float(beta[1]), "se": float(np.sqrt(V[1, 1])), "n_obs": N},
        {"term": "lag_15", "estimate": float(beta[LAGS]), "se": float(np.sqrt(V[LAGS, LAGS])), "n_obs": N},
    ],
    "method_metadata": {
        "estimator": "OLS of log(sales) on intercept and 15 lags of first difference of log(vix)",
        "vcov": "Newey-West HAC, Bartlett weights 1-j/16, maxlag 15, scaled by N/(N-16)",
    },
    "diagnostics": {"sample_rows_total": int(len(df)), "regression_n": int(N), "parameters": int(p)},
}
with open("result.json", "w") as f:
    json.dump(result, f, indent=2, allow_nan=False)
print(json.dumps(result, indent=2))
