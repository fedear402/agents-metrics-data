import json
import numpy as np
import pandas as pd

crosswalk = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv").merge(crosswalk, on="code", how="left", validate="one_to_one")
areas = pd.read_csv("areas.csv")
emp = pd.read_csv("employment.csv")
outcomes = pd.read_csv("outcomes.csv")

assert trade["industry"].notna().all()
trade = trade.set_index(["period", "industry"])

emp_full = (emp.groupby(["area", "period", "vintage", "industry"], as_index=False)["employment"].sum())
areas_idx = areas.set_index(["area", "period", "vintage"])

periods = sorted(areas["period"].unique())
area_ids = sorted(areas["area"].unique())
industries = sorted(crosswalk["industry"].unique())

emp_grid = (emp_full.set_index(["area", "period", "vintage", "industry"])["employment"]
            .reindex(pd.MultiIndex.from_product([area_ids, periods, ["base", "early"], industries],
                                                names=["area", "period", "vintage", "industry"]))
            .fillna(0.0))


def exposure(vintage, change_col):
    rows = []
    for p in periods:
        t = trade.loc[p]
        e = emp_grid.xs((p, vintage), level=("period", "vintage"))  # area x industry
        e = e.unstack("industry")[industries]
        national = e.sum(axis=0)
        assert (national > 0).all()
        total = areas_idx.xs(vintage, level="vintage").loc[(slice(None), p), "total_employment"]
        total = total.reset_index(level="period", drop=True).reindex(area_ids).astype(float)
        shock = t[change_col].reindex(industries).astype(float).values / national.values
        shock = shock / (t["price_index"].iloc[0] / 100) / 1000 * (10 / t["years"].iloc[0])
        val = (e.values @ shock) / total.values
        rows.append(pd.DataFrame({"area": area_ids, "period": p, "value": val}))
    return pd.concat(rows, ignore_index=True)


x_df = exposure("base", "us_change").rename(columns={"value": "x"})
z_df = exposure("early", "other_change").rename(columns={"value": "z"})
pop = areas[areas["vintage"] == "base"][["area", "period", "population"]]

df = (outcomes.merge(x_df, on=["area", "period"], validate="one_to_one")
      .merge(z_df, on=["area", "period"], validate="one_to_one")
      .merge(pop, on=["area", "period"], validate="one_to_one")
      .sort_values(["period", "area"]).reset_index(drop=True))
n_obs = int(len(df))
assert n_obs == 72

y = df["change_pp"].to_numpy(float)
w = df["population"].to_numpy(float)
const = np.ones(n_obs)
period = df["period"].to_numpy(float)
control = df["control"].to_numpy(float)
X = np.column_stack([const, period, control, df["x"].to_numpy(float)])
Z = np.column_stack([const, period, control, df["z"].to_numpy(float)])

ZtWZ_inv = np.linalg.inv(Z.T @ (w[:, None] * Z))
A = X.T @ (w[:, None] * Z) @ ZtWZ_inv @ Z.T @ (w[:, None] * X)
b = X.T @ (w[:, None] * Z) @ ZtWZ_inv @ Z.T @ (w * y)
beta = np.linalg.solve(A, b)
iv_slope = float(beta[-1])

def exp_at(col, p):
    return float(df.loc[(df["area"] == 0) & (df["period"] == p), col].iloc[0])

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [
        {"term": "iv_slope", "estimate": iv_slope, "se": None, "n_obs": n_obs},
        {"term": "exposure_area0_period0", "estimate": exp_at("x", 0), "se": None, "n_obs": n_obs},
        {"term": "exposure_area0_period1", "estimate": exp_at("x", 1), "se": None, "n_obs": n_obs},
        {"term": "instrument_area0_period0", "estimate": exp_at("z", 0), "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "weights": "base-vintage population",
        "outcome": "change_pp",
        "endogenous": "x",
        "instrument": "z",
        "exogenous": ["intercept", "period", "control"],
        "exposure_units": "thousands of real dollars per worker per decade",
    },
    "diagnostics": {
        "n_areas": int(df["area"].nunique()),
        "n_periods": len(periods),
        "industries": [int(i) for i in industries],
        "national_denominators": "sum over all areas within period and vintage",
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)

print(json.dumps(result["estimates"], indent=2))
