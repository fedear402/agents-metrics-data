import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("input.csv")
df = df.sort_values("date").reset_index(drop=True)
df["dlogvix"] = np.log(df["vix"]).diff()
df["logsales"] = np.log(df["sales"])
L = 15
for k in range(1, L + 1):
    df[f"lag_{k}"] = df["dlogvix"].shift(k)
d = df.dropna(subset=["dlogvix"] + [f"lag_{k}" for k in range(1, L + 1)]).copy()

X = sm.add_constant(d[[f"lag_{k}" for k in range(1, L + 1)]])
y = d["logsales"]
N = len(d)
fit = sm.OLS(y, X).fit(cov_type="HAC", cov_kwds={"maxlags": L, "use_correction": False})
V = fit.cov_params().values * N / (N - (L + 1))
names = list(X.columns)
b = fit.params.values

R = np.zeros(L + 1)
R[1:] = 1.0
cum = float(R @ b)
cum_se = float(np.sqrt(R @ V @ R))

def idx(name):
    return names.index(name)

out = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {"term": "cumulative_response", "estimate": cum, "se": cum_se, "n_obs": int(N)},
        {"term": "lag_1", "estimate": float(b[idx("lag_1")]), "se": float(np.sqrt(V[idx("lag_1"), idx("lag_1")])), "n_obs": int(N)},
        {"term": "lag_15", "estimate": float(b[idx("lag_15")]), "se": float(np.sqrt(V[idx("lag_15"), idx("lag_15")])), "n_obs": int(N)},
    ],
    "method_metadata": {
        "estimator": "OLS of log(sales) on intercept and 15 lags of first difference of log(vix)",
        "vcov": "Newey-West HAC, maxlags=15, Bartlett weights 1-j/16, scaled by N/(N-16)",
    },
    "diagnostics": {"sample_start_row_index": 16, "sample_end_row_index": int(d.index[-1]), "total_rows": int(len(df))},
}
with open("result.json", "w") as f:
    json.dump(out, f, indent=2)
print(json.dumps(out, indent=2))
