import json
import pandas as pd
from scipy import stats
import statsmodels.formula.api as smf
import statsmodels.api as sm

df = pd.read_csv("./input.csv")
groups = [g["y"].values for _, g in df.groupby("group")]
F, p_val = stats.f_oneway(*groups)
k = len(groups)
n = len(df)
df_num = k - 1
df_den = n - k

out = {
    "task_id": "anova_oneway",
    "platform": "python",
    "estimates": [
        {"term": "F", "estimate": float(F), "se": None, "n_obs": n},
        {"term": "df_num", "estimate": float(df_num), "se": None, "n_obs": n},
        {"term": "df_den", "estimate": float(df_den), "se": None, "n_obs": n},
        {"term": "p_value", "estimate": float(p_val), "se": None, "n_obs": n},
    ],
    "method_metadata": {"estimator": "One-way ANOVA F test (scipy f_oneway)", "vcov": "none"},
    "diagnostics": {},
}
with open("result.json", "w") as f:
    json.dump(out, f)
