import csv, json
import numpy as np

def read(name):
    with open(name, newline="") as f:
        return list(csv.DictReader(f))

cross = {r["code"]: int(r["industry"]) for r in read("crosswalk.csv")}
trade = read("trade.csv")
areas = read("areas.csv")
emp = read("employment.csv")
outs = read("outcomes.csv")

trade_row = {}
for t in trade:
    p = int(t["period"]); j = cross[t["code"]]
    trade_row[(p, j)] = t

E = {}
for r in emp:
    key = (int(r["area"]), int(r["period"]), r["vintage"], int(r["industry"]))
    E[key] = E.get(key, 0.0) + float(r["employment"])

TOT = {}
POP = {}
for r in areas:
    a, p, v = int(r["area"]), int(r["period"]), r["vintage"]
    TOT[(a, p, v)] = float(r["total_employment"])
    if v == "base":
        POP[(a, p)] = float(r["population"])

areas_ids = sorted({a for a, _, _ in TOT})
periods = sorted({p for _, p in POP})
industries = sorted(set(cross.values()))

def natl(p, v):
    return {j: sum(E.get((a, p, v, j), 0.0) for a in areas_ids) for j in industries}

NB = {p: natl(p, "base") for p in periods}
NE = {p: natl(p, "early") for p in periods}

def exposure(p, a, src, nat, other):
    s = 0.0
    base_tot = TOT[(a, p, "base")] if src == "base" else TOT[(a, p, "early")]
    for j in industries:
        t = trade_row[(p, j)]
        price = float(t["price_index"]); years = float(t["years"])
        chg = float(t[other])
        s += (E.get((a, p, src, j), 0.0) / base_tot) * (chg / nat[p][j]) / (price / 100) / 1000 * (10 / years)
    return s

rows = []
for o in outs:
    a, p = int(o["area"]), int(o["period"])
    x = exposure(p, a, "base", NB, "us_change")
    z = exposure(p, a, "early", NE, "other_change")
    rows.append((a, p, float(o["control"]), float(o["change_pp"]), x, z, POP[(a, p)]))
rows.sort()

y = np.array([r[3] for r in rows])
X = np.array([[1.0, r[1], r[2], r[4]] for r in rows])
Z = np.array([[1.0, r[1], r[2], r[5]] for r in rows])
w = np.sqrt(np.array([r[6] for r in rows]))
Xw, Zw, yw = X * w[:, None], Z * w[:, None], y * w
P = np.linalg.pinv(Zw.T @ Zw)
A = Xw.T @ Zw @ P @ Zw.T
beta = np.linalg.solve(A @ Xw, A @ yw)
iv_slope = float(beta[3])

x_of = {(r[0], r[1]): r[4] for r in rows}
z_of = {(r[0], r[1]): r[5] for r in rows}
n_obs = len(rows)

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [
        {"term": "iv_slope", "estimate": iv_slope, "se": None, "n_obs": n_obs},
        {"term": "exposure_area0_period0", "estimate": x_of[(0, 0)], "se": None, "n_obs": n_obs},
        {"term": "exposure_area0_period1", "estimate": x_of[(0, 1)], "se": None, "n_obs": n_obs},
        {"term": "instrument_area0_period0", "estimate": z_of[(0, 0)], "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "weights": "base-vintage population",
        "outcome": "change_pp",
        "endogenous": "x",
        "instrument": "z",
        "exogenous": ["intercept", "period", "control"],
        "exposure_units": "thousands of real dollars per worker per decade",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "periods": periods,
        "industries": industries,
        "national_denominator_min": min(min(NB[p].values()) for p in periods),
    },
}
with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))
