import json
import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS

crosswalk = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv")
areas = pd.read_csv("areas.csv")
employment = pd.read_csv("employment.csv")
outcomes = pd.read_csv("outcomes.csv")

trade = trade.merge(crosswalk, on="code", how="left", validate="many_to_one")
assert trade["industry"].notna().all()

emp = employment.groupby(["area", "period", "vintage", "industry"], as_index=False)["employment"].sum()
all_keys = pd.MultiIndex.from_product(
    [areas["area"].unique(), areas["period"].unique(), ["base", "early"], crosswalk["industry"].unique()],
    names=["area", "period", "vintage", "industry"],
)
emp = emp.set_index(["area", "period", "vintage", "industry"]).reindex(all_keys, fill_value=0).reset_index()

national = emp.groupby(["period", "vintage", "industry"])["employment"].sum().rename("national")
emp = emp.merge(national.reset_index(), on=["period", "vintage", "industry"])
assert (emp["national"] > 0).all()

tot = areas.pivot_table(index=["area", "period"], columns="vintage", values="total_employment")
tot.columns = [f"total_{c}" for c in tot.columns]
pop = areas[areas["vintage"] == "base"].set_index(["area", "period"])["population"].rename("population")

def exposure(vintage, change_col):
    t = trade.set_index(["period", "industry"])
    e = emp[emp["vintage"] == vintage].copy()
    e = e.merge(trade[["period", "industry", change_col, "price_index", "years"]], on=["period", "industry"])
    e["shock"] = e[change_col] / e["national"] / (e["price_index"] / 100) / 1000 * (10 / e["years"])
    e = e.merge(tot.reset_index()[["area", "period", f"total_{vintage}"]], on=["area", "period"])
    e["term"] = e["employment"] / e[f"total_{vintage}"] * e["shock"]
    return e.groupby(["area", "period"])["term"].sum()

x = exposure("base", "us_change").rename("x")
z = exposure("early", "other_change").rename("z")

df = outcomes.set_index(["area", "period"]).join([x, z, pop]).reset_index()
assert len(df) == 72 and df[["x", "z", "population"]].notna().all().all()

df["const"] = 1.0
fit = IV2SLS(
    dependent=df["change_pp"],
    exog=df[["const", "period", "control"]],
    endog=df[["x"]],
    instruments=df[["z"]],
    weights=df["population"],
).fit()

def get(area, period, col):
    return float(df.loc[(df["area"] == area) & (df["period"] == period), col].iloc[0])

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [
        {"term": "iv_slope", "estimate": float(fit.params["x"]), "se": None, "n_obs": int(len(df))},
        {"term": "exposure_area0_period0", "estimate": get(0, 0, "x"), "se": None, "n_obs": int(len(df))},
        {"term": "exposure_area0_period1", "estimate": get(0, 1, "x"), "se": None, "n_obs": int(len(df))},
        {"term": "instrument_area0_period0", "estimate": get(0, 0, "z"), "se": None, "n_obs": int(len(df))},
    ],
    "method_metadata": {
        "estimator": "weighted IV2SLS",
        "outcome": "change_pp",
        "exogenous": ["const", "period", "control"],
        "endogenous": ["x"],
        "instruments": ["z"],
        "weight": "base-vintage population",
    },
    "diagnostics": {
        "n_areas": int(df["area"].nunique()),
        "n_periods": int(df["period"].nunique()),
        "n_obs": int(len(df)),
    },
}
with open("result.json", "w") as f:
    json.dump(result, f, indent=2)

print(json.dumps(result["estimates"], indent=2))
