import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

LAGS = 15

data = pd.read_csv("input.csv", parse_dates=["date"]).sort_values("date").reset_index(drop=True)
data["dlvix"] = np.log(data["vix"]).diff()
data["log_sales"] = np.log(data["sales"])
for k in range(1, LAGS + 1):
    data[f"lag_{k}"] = data["dlvix"].shift(k)

cols = [f"lag_{k}" for k in range(1, LAGS + 1)]
sample = data.dropna(subset=["log_sales"] + cols).reset_index(drop=True)
N = len(sample)
X = np.column_stack([np.ones(N), sample[cols].to_numpy()])
y = sample["log_sales"].to_numpy()

beta = np.linalg.lstsq(X, y, rcond=None)[0]
resid = y - X @ beta
scores = X * resid[:, None]
meat = scores.T @ scores
for j in range(1, LAGS + 1):
    w = 1 - j / (LAGS + 1)
    gamma = scores[j:].T @ scores[:-j]
    meat += w * (gamma + gamma.T)
bread = np.linalg.inv(X.T @ X)
p = X.shape[1]
V = (N / (N - p)) * bread @ meat @ bread

c = np.zeros(p)
c[1:] = 1.0
cum = float(c @ beta)
cum_se = float(np.sqrt(c @ V @ c))

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {"term": "cumulative_response", "estimate": cum, "se": cum_se, "n_obs": N},
        {"term": "lag_1", "estimate": float(beta[1]), "se": float(np.sqrt(V[1, 1])), "n_obs": N},
        {"term": "lag_15", "estimate": float(beta[15]), "se": float(np.sqrt(V[15, 15])), "n_obs": N},
    ],
    "method_metadata": {
        "estimator": "OLS of log(sales) on intercept and 15 lags of diff log(vix)",
        "vcov": "Newey-West HAC, max lag 15, Bartlett weights, scaled by N/(N-16)",
    },
    "diagnostics": {"N": N, "first_date": str(sample["date"].iloc[0].date()), "last_date": str(sample["date"].iloc[-1].date())},
}
with open("result.json", "w") as f:
    json.dump(result, f, indent=2, allow_nan=False)

# Independent check: statsmodels HAC, rescaled to the same N/(N-16) correction.
sm_res = sm.OLS(y, X).fit(cov_type="HAC", cov_kwds={"maxlags": LAGS, "use_correction": False})
V_sm = sm_res.cov_params() * (N / (N - p))
print("N", N, "cum", cum, "se", cum_se)
print("lag_1", beta[1], np.sqrt(V[1, 1]), "lag_15", beta[15], np.sqrt(V[15, 15]))
print("statsmodels cum", float(c @ sm_res.params), float(np.sqrt(c @ V_sm @ c)))
print("max |V - V_sm|", np.max(np.abs(V - V_sm)))
print("max |beta - beta_sm|", np.max(np.abs(beta - sm_res.params)))
