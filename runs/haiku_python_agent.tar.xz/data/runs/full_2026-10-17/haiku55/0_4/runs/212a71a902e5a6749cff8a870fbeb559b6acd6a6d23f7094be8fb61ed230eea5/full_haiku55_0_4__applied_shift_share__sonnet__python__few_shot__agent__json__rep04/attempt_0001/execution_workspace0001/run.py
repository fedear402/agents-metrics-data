import json
import numpy as np
import pandas as pd

df = pd.read_csv('input.csv')

for col in ['region_weight', 'x', 'y']:
    assert (df.groupby('region_id')[col].nunique() == 1).all()
assert (df.groupby('industry_id')['shock'].nunique() == 1).all()
assert np.allclose(df.groupby('region_id')['share'].sum(), 1.0)

reg = df.groupby('region_id').agg(w=('region_weight', 'first'), x=('x', 'first'), y=('y', 'first'))
reg['z'] = (df.assign(p=df.share * df.shock).groupby('region_id')['p'].sum())
reg['e'] = reg['w'] / reg['w'].sum()

for col in ['y', 'x', 'z']:
    reg[col + '0'] = reg[col] - np.sum(reg['e'] * reg[col])

m = df.merge(reg[['e', 'y0', 'x0', 'z0']], left_on='region_id', right_index=True)
m['ep'] = m['e'] * m['share']
ind = m.groupby('industry_id').apply(
    lambda g: pd.Series({
        'shock': g['shock'].iloc[0],
        's': g['ep'].sum(),
        'ybar': (g['ep'] * g['y0']).sum() / g['ep'].sum(),
        'xbar': (g['ep'] * g['x0']).sum() / g['ep'].sum(),
        'zbar': (g['ep'] * g['z0']).sum() / g['ep'].sum(),
    }),
    include_groups=False,
)
N = len(ind)


def shock_iv(dep, endo, inst, w):
    X = np.column_stack([np.ones(N), endo])
    Z = np.column_stack([np.ones(N), inst])
    cross = Z.T @ (w[:, None] * X)
    beta = np.linalg.solve(cross, Z.T @ (w * dep))
    resid = dep - X @ beta
    scores = Z * (w * resid)[:, None]
    inv = np.linalg.inv(cross)
    hc1 = N / (N - 2)
    cov = hc1 * inv @ (scores.T @ scores) @ inv.T
    return float(beta[1]), float(np.sqrt(cov[1, 1]))


s = ind['s'].to_numpy()
shock = ind['shock'].to_numpy()
effect, effect_se = shock_iv(ind['ybar'].to_numpy(), ind['xbar'].to_numpy(), shock, s)
first, first_se = shock_iv(ind['xbar'].to_numpy(), ind['zbar'].to_numpy(), shock, s)
effective = float(1.0 / np.sum(s ** 2))

reg_effect = np.sum(reg['e'] * reg['z0'] * reg['y0']) / np.sum(reg['e'] * reg['z0'] * reg['x0'])
reg_first = np.sum(reg['e'] * reg['z0'] * reg['x0']) / np.sum(reg['e'] * reg['z0'] ** 2)
assert np.isclose(effect, reg_effect, rtol=1e-9, atol=1e-12)
assert np.isclose(first, reg_first, rtol=1e-9, atol=1e-12)

output = {
    'task_id': 'applied_shift_share',
    'platform': 'python',
    'estimates': [
        {'term': 'effect', 'estimate': effect, 'se': effect_se, 'n_obs': N},
        {'term': 'first_stage', 'estimate': first, 'se': first_se, 'n_obs': N},
        {'term': 'effective_shocks', 'estimate': effective, 'se': None, 'n_obs': N},
    ],
    'method_metadata': {
        'estimator': 'Weighted 2SLS of y on x instrumenting x with shift-share z, regional weights e_r; shock-level (BHJ) weighted IV with industry weights s_n',
        'vcov': 'Shock-level heteroskedasticity-robust HC1 (N/(N-2)), structural IV residuals, analytic weights, no clustering',
    },
    'diagnostics': {
        'n_regions': int(len(reg)),
        'n_industries': int(N),
        'n_rows': int(len(df)),
        'regional_effect_check': reg_effect,
        'regional_first_stage_check': reg_first,
    },
}
with open('result.json', 'w') as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
print(json.dumps(output, indent=2))
