import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

L = 15
df = pd.read_csv("input.csv").sort_values("date").reset_index(drop=True)
df["dlvix"] = np.log(df["vix"]).diff()
df["ly"] = np.log(df["sales"])
for k in range(1, L + 1):
    df[f"lag_{k}"] = df["dlvix"].shift(k)
d = df.dropna(subset=["dlvix"] + [f"lag_{k}" for k in range(1, L + 1)]).reset_index(drop=True)

X = sm.add_constant(d[[f"lag_{k}" for k in range(1, L + 1)]])
y = d["ly"]
N = len(d)
res = sm.OLS(y, X).fit(cov_type="HAC", cov_kwds={"maxlags": L, "use_correction": False, "kernel": "bartlett"})
V = res.cov_params().values * N / (N - (L + 1))
b = res.params.values

c = np.zeros(len(b)); c[1:] = 1.0
cum = float(c @ b)
cum_se = float(np.sqrt(c @ V @ c))
names = list(X.columns)
i1, i15 = names.index("lag_1"), names.index("lag_15")

out = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {"term": "cumulative_response", "estimate": cum, "se": cum_se, "n_obs": N},
        {"term": "lag_1", "estimate": float(b[i1]), "se": float(np.sqrt(V[i1, i1])), "n_obs": N},
        {"term": "lag_15", "estimate": float(b[i15]), "se": float(np.sqrt(V[i15, i15])), "n_obs": N},
    ],
    "method_metadata": {
        "estimator": "OLS of log(sales) on intercept and 15 lags of first difference of log(vix)",
        "vcov": "Newey-West HAC, maxlags=15, Bartlett weights 1-j/16, small-sample factor N/(N-16)",
    },
    "diagnostics": {"N": N, "first_date": d["date"].iloc[0], "last_date": d["date"].iloc[-1]},
}
with open("result.json", "w") as f:
    json.dump(out, f, indent=2)
print(json.dumps(out, indent=2))
