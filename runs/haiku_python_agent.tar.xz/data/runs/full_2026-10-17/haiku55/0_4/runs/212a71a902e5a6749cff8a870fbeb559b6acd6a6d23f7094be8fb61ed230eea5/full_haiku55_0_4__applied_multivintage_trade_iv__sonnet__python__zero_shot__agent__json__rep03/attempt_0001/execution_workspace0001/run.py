import json
import numpy as np
import pandas as pd

crosswalk = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv")
areas = pd.read_csv("areas.csv")
emp = pd.read_csv("employment.csv")
outcomes = pd.read_csv("outcomes.csv")

trade = trade.merge(crosswalk, on="code", how="left", validate="many_to_one")
assert trade["industry"].notna().all()
industries = sorted(crosswalk["industry"].unique())

periods = sorted(areas["period"].unique())
area_ids = sorted(areas["area"].unique())
vintages = ["base", "early"]

grid = pd.MultiIndex.from_product(
    [area_ids, periods, vintages, industries],
    names=["area", "period", "vintage", "industry"],
)
emp_full = (
    emp.set_index(["area", "period", "vintage", "industry"])["employment"]
    .reindex(grid, fill_value=0)
    .rename("employment")
    .reset_index()
)

total = areas.set_index(["area", "period", "vintage"])["total_employment"]
pop = areas[areas["vintage"] == "base"].set_index(["area", "period"])["population"]

national = emp_full.groupby(["period", "vintage", "industry"])["employment"].sum()
assert (national > 0).all()

trade_idx = trade.set_index(["period", "industry"])
years = trade.groupby("period")["years"].first()
price = trade.groupby("period")["price_index"].first()
assert trade.groupby("period")["years"].nunique().eq(1).all()
assert trade.groupby("period")["price_index"].nunique().eq(1).all()


def exposure(vintage_base, vintage_change):
    rows = []
    for (area, period), _ in emp_full.groupby(["area", "period"]):
        sub = emp_full[(emp_full["area"] == area) & (emp_full["period"] == period)
                       & (emp_full["vintage"] == vintage_base)].set_index("industry")["employment"]
        te = total.loc[(area, period, vintage_base)]
        s = 0.0
        for j in industries:
            nat = national.loc[(period, vintage_base, j)]
            change = trade_idx.loc[(period, j), vintage_change]
            s += (sub.loc[j] / te) * (change / nat)
        s = s / (price[period] / 100) / 1000 * (10 / years[period])
        rows.append({"area": area, "period": period, "value": s})
    return pd.DataFrame(rows)


x_df = exposure("base", "us_change").rename(columns={"value": "x"})
z_df = exposure("early", "other_change").rename(columns={"value": "z"})
df = x_df.merge(z_df, on=["area", "period"]).merge(
    outcomes, on=["area", "period"], how="inner", validate="one_to_one"
)
df["w"] = [pop.loc[(a, p)] for a, p in zip(df["area"], df["period"])]
n_obs = int(len(df))
assert n_obs == 72

y = df["change_pp"].to_numpy(float)
X = np.column_stack([np.ones(n_obs), df["period"].to_numpy(float),
                     df["control"].to_numpy(float), df["x"].to_numpy(float)])
Z = np.column_stack([np.ones(n_obs), df["period"].to_numpy(float),
                     df["control"].to_numpy(float), df["z"].to_numpy(float)])
W = np.diag(df["w"].to_numpy(float))

ZWZ_inv = np.linalg.inv(Z.T @ W @ Z)
A = X.T @ W @ Z @ ZWZ_inv @ Z.T @ W @ X
beta = np.linalg.solve(A, X.T @ W @ Z @ ZWZ_inv @ Z.T @ W @ y)
iv_slope = float(beta[3])

def get(col, a, p):
    return float(df.loc[(df["area"] == a) & (df["period"] == p), col].iloc[0])

exposure_area0_period0 = get("x", 0, 0)
exposure_area0_period1 = get("x", 0, 1)
instrument_area0_period0 = get("z", 0, 0)

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [
        {"term": "iv_slope", "estimate": iv_slope, "se": None, "n_obs": n_obs},
        {"term": "exposure_area0_period0", "estimate": exposure_area0_period0, "se": None, "n_obs": n_obs},
        {"term": "exposure_area0_period1", "estimate": exposure_area0_period1, "se": None, "n_obs": n_obs},
        {"term": "instrument_area0_period0", "estimate": instrument_area0_period0, "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "weighted two-stage least squares",
        "dependent": "change_pp",
        "endogenous": ["x"],
        "instruments": ["z"],
        "exogenous": ["intercept", "period", "control"],
        "weights": "base-vintage population",
        "exposure_definition": "sum over industries of base area-industry share times US change over national base industry employment, deflated and scaled to thousands of real dollars per worker per decade",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "n_areas": int(len(area_ids)),
        "periods": [int(p) for p in periods],
        "industries": [int(j) for j in industries],
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)

print(json.dumps(result["estimates"], indent=2))
print("beta", beta.tolist())
