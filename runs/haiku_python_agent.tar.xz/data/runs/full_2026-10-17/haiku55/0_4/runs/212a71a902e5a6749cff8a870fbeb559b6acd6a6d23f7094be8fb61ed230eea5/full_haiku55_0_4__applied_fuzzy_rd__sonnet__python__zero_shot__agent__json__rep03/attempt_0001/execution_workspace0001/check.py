import numpy as np, pandas as pd, statsmodels.api as sm
from statsmodels.sandbox.regression.gmm import IV2SLS

df = pd.read_csv("input.csv")
df = df[df.score.abs() < 1].copy()
df["w"] = 1 - df.score.abs()
df["R"] = (df.score >= 0).astype(float)
out = {}
for name, m in [("R", df.R == 1), ("L", df.R == 0)]:
    sub = df[m]
    X = sm.add_constant(sub[["score"]])
    for yv in ["earnings", "participated"]:
        fit = sm.WLS(sub[yv], X, weights=sub["w"]).fit(cov_type="HC0")
        out[(name, yv)] = (fit.params["const"], fit.bse["const"])
rf = out[("R","earnings")][0] - out[("L","earnings")][0]
fs = out[("R","participated")][0] - out[("L","participated")][0]
print("statsmodels WLS per side: rf", rf, "fs", fs, "ratio", rf/fs)
print("SE rf (uncorrelated side-sum)", np.sqrt(out[("R","earnings")][1]**2+out[("L","earnings")][1]**2))
print("SE fs (uncorrelated side-sum)", np.sqrt(out[("R","participated")][1]**2+out[("L","participated")][1]**2))

sw = np.sqrt(df.w.values)
s = df.score.values; R = df.R.values
Xs = np.column_stack([np.ones_like(s), s, s*R])
endog = df.participated.values
Z = np.column_stack([np.ones_like(s), s, s*R, R])
X = np.column_stack([np.ones_like(s), s, s*R, endog])
y = df.earnings.values
iv = IV2SLS(y*sw, X*sw[:,None], Z*sw[:,None]).fit()
print("2SLS weighted tau", iv.params[-1])
