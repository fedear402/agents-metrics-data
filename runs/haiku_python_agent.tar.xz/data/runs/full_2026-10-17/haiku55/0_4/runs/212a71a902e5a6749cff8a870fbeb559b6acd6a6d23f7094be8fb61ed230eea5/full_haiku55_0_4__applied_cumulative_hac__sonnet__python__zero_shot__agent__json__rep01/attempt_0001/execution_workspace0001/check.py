import numpy as np, pandas as pd, statsmodels.api as sm
L=15
df=pd.read_csv("input.csv").sort_values("date").reset_index(drop=True)
dl=np.log(df.vix).diff().values; ly=np.log(df.sales).values
T=len(df); rows=range(L+1,T)
X=np.column_stack([np.ones(len(rows))]+[[dl[t-k] for t in rows] for k in range(1,L+1)])
y=np.array([ly[t] for t in rows]); N=len(y)
XtXi=np.linalg.inv(X.T@X); b=XtXi@X.T@y; e=y-X@b
S=(X*e[:,None]).T@(X*e[:,None])
for j in range(1,L+1):
    w=1-j/(L+1); G=(X[j:]*e[j:,None]).T@(X[:-j]*e[:-j,None]); S+=w*(G+G.T)
V=XtXi@S@XtXi*N/(N-(L+1))
R=np.r_[0,np.ones(L)]
print("N",N)
print("manual cum",R@b, "se",np.sqrt(R@V@R))
print("manual lag1",b[1],np.sqrt(V[1,1]),"lag15",b[15],np.sqrt(V[15,15]))
# identity: cumulative = coefficient on sum of lags, from reparameterized regression
Z=np.column_stack([X[:,0],X[:,1],X[:,2:]-X[:,[1]]])
Xs=np.column_stack([np.ones(N)]+[X[:,k] for k in range(1,L+1)])
Zc=np.column_stack([np.ones(N),X[:,1]]+[X[:,k]-X[:,1] for k in range(2,L+1)])
Zc=np.column_stack([np.ones(N),sum(X[:,k] for k in range(1,L+1))]+[X[:,1]]*0)
Zc=np.column_stack([np.ones(N),sum(X[:,k] for k in range(1,L+1))]+[X[:,k]-X[:,1] for k in range(2,L+1)])
Zc=np.column_stack([np.ones(N),sum(X[:,k] for k in range(1,L+1))]+[X[:,k] for k in range(2,L+1)])
r=sm.OLS(y,Zc).fit(cov_type="HAC",cov_kwds={"maxlags":L,"use_correction":False})
print("reparam cum",r.params[1],"se",r.bse[1]*np.sqrt(N/(N-16)))
