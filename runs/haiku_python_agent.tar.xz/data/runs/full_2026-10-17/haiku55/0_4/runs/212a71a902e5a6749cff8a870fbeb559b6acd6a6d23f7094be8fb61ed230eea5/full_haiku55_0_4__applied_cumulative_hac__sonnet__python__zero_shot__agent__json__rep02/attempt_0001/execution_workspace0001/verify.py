import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv").sort_values("date").reset_index(drop=True)
dl = np.diff(np.log(df["vix"].values))  # dl[i] = change at row i+1
y_all = np.log(df["sales"].values)
rows = range(16, len(df))
y = np.array([y_all[t] for t in rows])
X = np.column_stack([np.ones(len(y))] + [np.array([dl[t - k - 1] for t in rows]) for k in range(1, 16)])
N, K = X.shape
XtX_inv = np.linalg.inv(X.T @ X)
b = XtX_inv @ X.T @ y
u = y - X @ b
S = (X * u[:, None]).T @ (X * u[:, None]) / N
for j in range(1, 16):
    w = 1 - j / 16
    G = (X[j:] * u[j:, None]).T @ (X[:-j] * u[:-j, None]) / N
    S += w * (G + G.T)
V = XtX_inv @ (N * S) @ XtX_inv * N / (N - 16)
R = np.zeros(K); R[1:] = 1
res = json.load(open("result.json"))
est = {e["term"]: e for e in res["estimates"]}
checks = {
    "cumulative_response": (R @ b, np.sqrt(R @ V @ R)),
    "lag_1": (b[1], np.sqrt(V[1, 1])),
    "lag_15": (b[15], np.sqrt(V[15, 15])),
}
for k, (c, s) in checks.items():
    print(k, "indep:", c, s, "| script:", est[k]["estimate"], est[k]["se"], "| diff:", abs(c - est[k]["estimate"]), abs(s - est[k]["se"]))
print("N", N, est["lag_1"]["n_obs"])
