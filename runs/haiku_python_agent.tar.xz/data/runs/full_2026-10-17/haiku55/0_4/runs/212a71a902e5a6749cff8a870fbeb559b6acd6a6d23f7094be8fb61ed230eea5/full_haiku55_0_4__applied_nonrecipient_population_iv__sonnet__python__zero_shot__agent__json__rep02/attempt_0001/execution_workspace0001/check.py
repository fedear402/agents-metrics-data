import json
from pathlib import Path
import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
hh = pd.read_csv(HERE / "households.csv")
df = hh[hh.recipient == 0]
e = df.eligible.to_numpy(float); ne = 1 - e
d = df.dose.to_numpy(float); b = df.baseline.to_numpy(float)
i = df.instrument.to_numpy(float); w = df.weight.to_numpy(float); y = df.outcome.to_numpy(float)
X = np.column_stack([d * ne, d * e, ne, e, b * ne, b * e])
Z = np.column_stack([ne, e, b * ne, b * e, i * ne, i * e])
sw = np.sqrt(w)
Pz = Z @ np.linalg.lstsq(Z * sw[:, None], X * sw[:, None], rcond=None)[0]
bh = np.linalg.lstsq(Pz * sw[:, None], y * sw, rcond=None)[0]
s0, s1 = bh[0], bh[1]
m0 = e == 0; m1 = e == 1
mu0 = np.sum(w[m0] * d[m0]) / np.sum(w[m0]); mu1 = np.sum(w[m1] * d[m1]) / np.sum(w[m1])
eff0 = s0 * mu0; eff1 = s1 * mu1
pop = (8400 * eff0 + 1600 * eff1) / 10000
res = {r["term"]: r["estimate"] for r in json.load(open(HERE / "result.json"))["estimates"]}
for k, v in [("ineligible_effect", eff0), ("eligible_nonrecipient_effect", eff1), ("population_effect", pop)]:
    print(k, v, res[k], abs(v - res[k]))
