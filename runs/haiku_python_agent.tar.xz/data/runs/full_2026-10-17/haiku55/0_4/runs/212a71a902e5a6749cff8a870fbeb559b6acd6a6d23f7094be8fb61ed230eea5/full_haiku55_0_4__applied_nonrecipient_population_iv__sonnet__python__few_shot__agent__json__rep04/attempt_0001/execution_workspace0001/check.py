import json
import numpy as np
import pandas as pd

h = pd.read_csv('households.csv')
c = pd.read_csv('census.csv')
print('rows', len(h), 'recipient counts', h.recipient.value_counts().to_dict())
print('eligible values', sorted(h.eligible.unique()), 'weight min', h.weight.min(), 'NaN', int(h.isna().sum().sum()))
d = h[h.recipient == 0]
e = d.eligible.values.astype(float); ne = 1 - e
dose = d.dose.values; base = d.baseline.values; ins = d.instrument.values
w = d.weight.values.astype(float); y = d.outcome.values
X = np.column_stack([dose*ne, dose*e, ne, e, base*ne, base*e])
Z = np.column_stack([ne, e, base*ne, base*e, ins*ne, ins*e])
# weighted 2SLS via closed form: b = (X'WZ A Z'WX)^-1 X'WZ A Z'Wy, A=(Z'WZ)^-1
W = w
ZWZ = Z.T @ (Z * W[:, None]); A = np.linalg.inv(ZWZ)
XZ = X.T @ (Z * W[:, None]); ZX = Z.T @ (X * W[:, None]); Zy = Z.T @ (W*y)
b = np.linalg.solve(XZ @ A @ ZX, XZ @ A @ Zy)
print('closed-form slopes dose_ne, dose_e:', b[0], b[1])
eff = []
for g, slope in [(0, b[0]), (1, b[1])]:
    m = d.eligible.values == g
    eff.append(slope * np.average(dose[m], weights=w[m]))
pop = np.average(eff, weights=[8400, 1600])
print('closed-form effects', eff, 'population', pop)
r = json.load(open('result.json'))
est = {x['term']: x['estimate'] for x in r['estimates']}
print('diff ineligible', est['ineligible_effect'] - eff[0])
print('diff eligible', est['eligible_nonrecipient_effect'] - eff[1])
print('diff population', est['population_effect'] - pop)
# Check: a weighted mean of residuals in the instrument space should be zero (2SLS orthogonality)
u = y - X @ b
print('max |Z\'W u| (should be ~0):', np.max(np.abs(Z.T @ (W*u))))
