import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
h = 1.0
s = df["score"].to_numpy(float)
inside = np.abs(s) < h
d = df[inside].reset_index(drop=True)
s = d["score"].to_numpy(float)
w = 1.0 - np.abs(s)
right = (s >= 0).astype(float)
Y = np.column_stack([d["earnings"].to_numpy(float), d["participated"].to_numpy(float)])

def side_fit(mask):
    sv = s[mask]
    X = np.column_stack([np.ones(mask.sum()), sv])
    wv = w[mask]
    bread = np.linalg.inv(X.T @ (wv[:, None] * X))
    beta = bread @ X.T @ (wv[:, None] * Y[mask])
    resid = Y[mask] - X @ beta
    loading = wv * (X @ bread[:, 0])
    infl = loading[:, None] * resid
    return beta[0], infl, mask

rt, infl_r, mr = side_fit(right == 1)
lt, infl_l, ml = side_fit(right == 0)

jump = rt - lt
n = len(d)
contrib = np.zeros((n, 2))
contrib[np.where(mr)[0]] = infl_r
contrib[np.where(ml)[0]] = -infl_l
V = contrib.T @ contrib

rf, fs = jump
se_rf, se_fs = np.sqrt(V[0, 0]), np.sqrt(V[1, 1])
g = np.array([1 / fs, -rf / fs**2])
te = rf / fs
se_te = np.sqrt(g @ V @ g)

out = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": float(te), "se": float(se_te), "n_obs": int(n)},
        {"term": "reduced_form", "estimate": float(rf), "se": float(se_rf), "n_obs": int(n)},
        {"term": "first_stage", "estimate": float(fs), "se": float(se_fs), "n_obs": int(n)},
    ],
    "method_metadata": {
        "estimator": "Fuzzy RD, local linear, triangular kernel, bandwidth 1, separate slopes by side, Wald ratio",
        "vcov": "HC0 sandwich, delta method for ratio, joint covariance across outcomes",
    },
    "diagnostics": {
        "n_left": int((right == 0).sum()),
        "n_right": int((right == 1).sum()),
        "covariance_reduced_form_first_stage": float(V[0, 1]),
    },
}
with open("result.json", "w") as f:
    json.dump(out, f, indent=2, allow_nan=False)
print(json.dumps(out, indent=2))
