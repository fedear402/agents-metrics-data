import csv, json
import numpy as np

hh = list(csv.DictReader(open("households.csv")))
census = {int(r["eligible"]): float(r["nonrecipient_population"]) for r in csv.DictReader(open("census.csv"))}

rows = [r for r in hh if int(r["recipient"]) == 0]
col = lambda k: np.array([float(r[k]) for r in rows])
e = col("eligible"); ne = 1 - e
dose = col("dose"); base = col("baseline"); inst = col("instrument")
w = col("weight"); y = col("outcome")

X = np.column_stack([dose * ne, dose * e, ne, e, base * ne, base * e])
Z = np.column_stack([ne, e, base * ne, base * e, inst * ne, inst * e])

W = w
ZtWZ_inv = np.linalg.inv(Z.T @ (Z * W[:, None]))
XtZ = X.T @ (Z * W[:, None])
ZtWy = Z.T @ (y * W)
A = XtZ @ ZtWZ_inv @ XtZ.T
beta = np.linalg.solve(A, XtZ @ ZtWZ_inv @ ZtWy)

b_ine, b_elig = beta[0], beta[1]

def wmean(mask):
    return np.sum(w[mask] * dose[mask]) / np.sum(w[mask])

m0 = ne == 1
m1 = e == 1
mean0 = wmean(m0)
mean1 = wmean(m1)
ineligible_effect = b_ine * mean0
eligible_effect = b_elig * mean1

N0 = census[0]; N1 = census[1]
population_effect = (N0 * ineligible_effect + N1 * eligible_effect) / (N0 + N1)

n_obs = int(len(rows))
n0 = int(m0.sum()); n1 = int(m1.sum())

out = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {"term": "ineligible_effect", "estimate": float(ineligible_effect), "se": None, "n_obs": n_obs},
        {"term": "eligible_nonrecipient_effect", "estimate": float(eligible_effect), "se": None, "n_obs": n_obs},
        {"term": "population_effect", "estimate": float(population_effect), "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS, analytic weights, no added intercept",
        "endogenous": ["dose*(1-eligible)", "dose*eligible"],
        "exogenous": ["1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"],
        "instruments": ["exogenous four", "instrument*(1-eligible)", "instrument*eligible"],
        "sample": "households with recipient==0, both treated statuses, both eligibility groups",
        "effect_definition": "group dose slope times household-weighted mean dose of retained group rows; counterfactual dose=0 (synthetic convention)",
        "population_weights": {"ineligible": N0, "eligible": N1},
        "dose_slopes": {"ineligible": float(b_ine), "eligible": float(b_elig)},
    },
    "diagnostics": {
        "n_rows_input": len(hh),
        "n_obs": n_obs,
        "n_ineligible": n0,
        "n_eligible": n1,
        "weighted_mean_dose_ineligible": float(mean0),
        "weighted_mean_dose_eligible": float(mean1),
        "rank_Z": int(np.linalg.matrix_rank(Z)),
        "columns_X": X.shape[1],
        "columns_Z": Z.shape[1],
    },
}
json.dump(out, open("result.json", "w"), indent=2)
print(json.dumps(out["estimates"], indent=2))
print(json.dumps(out["diagnostics"], indent=2))
