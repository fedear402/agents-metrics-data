import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

L = 15
df = pd.read_csv("input.csv")
df = df.sort_values("date").reset_index(drop=True)
df["dlvix"] = np.log(df["vix"]).diff()
df["ly"] = np.log(df["sales"])
for k in range(1, L + 1):
    df[f"lag_{k}"] = df["dlvix"].shift(k)
d = df.dropna(subset=["ly"] + [f"lag_{k}" for k in range(1, L + 1)]).copy()
N = len(d)
X = sm.add_constant(d[[f"lag_{k}" for k in range(1, L + 1)]])
y = d["ly"]
res = sm.OLS(y, X).fit(cov_type="HAC", cov_kwds={"maxlags": L, "use_correction": False})
V = res.cov_params().values * N / (N - (L + 1))
b = res.params.values
R = np.zeros(len(b)); R[1:] = 1.0
cum = float(R @ b)
cum_se = float(np.sqrt(R @ V @ R))
idx = {f"lag_{k}": i for i, k in enumerate(range(1, L + 1), start=1)}
i1, i15 = idx["lag_1"], idx["lag_15"]
out = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {"term": "cumulative_response", "estimate": cum, "se": cum_se, "n_obs": N},
        {"term": "lag_1", "estimate": float(b[i1]), "se": float(np.sqrt(V[i1, i1])), "n_obs": N},
        {"term": "lag_15", "estimate": float(b[i15]), "se": float(np.sqrt(V[i15, i15])), "n_obs": N},
    ],
    "method_metadata": {
        "estimator": "OLS of log(sales) on intercept and lags 1-15 of diff log(vix), trading-day lags",
        "vcov": "Newey-West HAC, maxlags=15, Bartlett weights 1-j/16, scaled by N/(N-16)",
    },
    "diagnostics": {"sample_start_row": 16, "n_rows_raw": int(len(df)), "n_regression": N},
}
with open("result.json", "w") as f:
    json.dump(out, f, indent=2)
print(json.dumps(out, indent=2))
