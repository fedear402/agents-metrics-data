import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df = df[df["score"].abs() < 1].copy()
s = df["score"].to_numpy()
w = 1 - np.abs(s)
R = (s >= 0).astype(float)
L = 1 - R
X = np.column_stack([R, L, R * s, L * s])
A_inv = np.linalg.inv(X.T @ (X * w[:, None]))

def fit(y):
    beta = A_inv @ (X.T @ (w * y))
    e = y - X @ beta
    return beta, e

def disc_and_var(y):
    beta, e = fit(y)
    return beta[0] - beta[1], e

yE = df["earnings"].to_numpy()
yP = df["participated"].to_numpy().astype(float)
bE, eE = fit(yE)
bP, eP = fit(yP)
rf = bE[0] - bE[1]
fs = bP[0] - bP[1]

# c_k = e_1' C_k: gradient of discontinuity wrt beta
c = np.array([1.0, -1.0, 0.0, 0.0])
G = A_inv @ (X * w[:, None]).T  # 4 x n, maps y -> beta
Mw = (w ** 2)[:, None] * X       # n x 4
def meat(e1, e2):
    # sum_i w_i^2 x_i x_i' e1_i e2_i
    return (X * (w ** 2 * e1 * e2)[:, None]).T @ X
V_E = A_inv @ meat(eE, eE) @ A_inv
V_P = A_inv @ meat(eP, eP) @ A_inv
V_EP = A_inv @ meat(eE, eP) @ A_inv
var_rf = c @ V_E @ c
var_fs = c @ V_P @ c
cov = c @ V_EP @ c

te = rf / fs
grad = np.array([1 / fs, -rf / fs**2])
Vpair = np.array([[var_rf, cov], [cov, var_fs]])
var_te = grad @ Vpair @ grad
n = int(len(df))

out = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": float(te), "se": float(np.sqrt(var_te)), "n_obs": n},
        {"term": "reduced_form", "estimate": float(rf), "se": float(np.sqrt(var_rf)), "n_obs": n},
        {"term": "first_stage", "estimate": float(fs), "se": float(np.sqrt(var_fs)), "n_obs": n},
    ],
    "method_metadata": {
        "estimator": "Fuzzy RD, local linear WLS (triangular kernel, h=1, separate slopes and intercepts per side), Wald ratio via delta method",
        "vcov": "HC0 sandwich, joint covariance of reduced form and first stage from same observations, delta method for ratio",
    },
    "diagnostics": {
        "n_left": int((L == 1).sum()),
        "n_right": int((R == 1).sum()),
        "bandwidth": 1.0,
        "cutoff": 0.0,
    },
}
with open("result.json", "w") as f:
    json.dump(out, f, indent=2)
print(json.dumps(out, indent=2))
