import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
s = df["score"].to_numpy(float)
d = df["participated"].to_numpy(float)
y = df["earnings"].to_numpy(float)

h = 1.0
inside = np.abs(s) < h
w_all = np.where(inside, 1.0 - np.abs(s), 0.0)


def side_fit(mask):
    sv, w = s[mask], w_all[mask]
    X = np.column_stack([np.ones(len(sv)), sv])
    bread = np.linalg.inv(X.T @ (w[:, None] * X))
    b = bread @ X.T @ (w[:, None] * np.column_stack([y[mask], d[mask]]))
    resid = np.column_stack([y[mask], d[mask]]) - X @ b
    loading = w * (X @ bread[:, 0])
    infl = loading[:, None] * resid
    return b[0], infl, int(mask.sum())


right = inside & (s >= 0)
left = inside & (s < 0)
bR, iR, nR = side_fit(right)
bL, iL, nL = side_fit(left)

jump = bR - bL
V = iR.T @ iR + iL.T @ iL
rf, fs = jump
se_rf, se_fs = np.sqrt(V[0, 0]), np.sqrt(V[1, 1])

grad = np.array([1 / fs, -rf / fs**2])
tau = rf / fs
se_tau = np.sqrt(grad @ V @ grad)

n_obs = nL + nR
out = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": float(tau), "se": float(se_tau), "n_obs": n_obs},
        {"term": "reduced_form", "estimate": float(rf), "se": float(se_rf), "n_obs": n_obs},
        {"term": "first_stage", "estimate": float(fs), "se": float(se_fs), "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "Fuzzy RD, local linear, triangular kernel, bandwidth 1, cutoff 0, separate slopes by side (WLS)",
        "vcov": "HC0 heteroskedasticity-robust sandwich, no df correction; delta method for ratio with joint covariance",
    },
    "diagnostics": {
        "n_left": nL,
        "n_right": nR,
        "cov_reduced_form_first_stage": float(V[0, 1]),
        "intercept_left": float(bL[0]),
        "intercept_right": float(bR[0]),
    },
}
with open("result.json", "w") as f:
    json.dump(out, f, indent=2, allow_nan=False)
print(json.dumps(out["estimates"], indent=2))
