import json
import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS

h = pd.read_csv('households.csv')
census = pd.read_csv('census.csv')
r = h[h.recipient == 0].copy()

e = r.eligible.astype(float)
X = pd.DataFrame({
    'ineligible_const': 1 - e,
    'eligible_const': e,
    'baseline_ineligible': r.baseline * (1 - e),
    'baseline_eligible': r.baseline * e,
}, index=r.index)
endog = pd.DataFrame({
    'dose_ineligible': r.dose * (1 - e),
    'dose_eligible': r.dose * e,
}, index=r.index)
Z = pd.concat([X, pd.DataFrame({
    'instrument_ineligible': r.instrument * (1 - e),
    'instrument_eligible': r.instrument * e,
}, index=r.index)], axis=1)

fit = IV2SLS(r.outcome, X, endog, Z[['instrument_ineligible', 'instrument_eligible']],
             weights=r.weight).fit(cov_type='unadjusted')

n_obs = int(len(r))
effects = {}
for g, name in [(0, 'dose_ineligible'), (1, 'dose_eligible')]:
    rg = r[r.eligible == g]
    mean_dose = np.average(rg.dose, weights=rg.weight)
    effects[g] = float(fit.params[name] * mean_dose)

pop = census.set_index('eligible').nonrecipient_population
w = [float(pop[0]), float(pop[1])]
population_effect = float(np.average([effects[0], effects[1]], weights=w))

estimates = [
    {'term': 'ineligible_effect', 'estimate': effects[0], 'se': None, 'n_obs': n_obs},
    {'term': 'eligible_nonrecipient_effect', 'estimate': effects[1], 'se': None, 'n_obs': n_obs},
    {'term': 'population_effect', 'estimate': population_effect, 'se': None, 'n_obs': n_obs},
]
out = {
    'task_id': 'applied_nonrecipient_population_iv',
    'platform': 'python',
    'estimates': estimates,
    'method_metadata': {
        'estimator': 'weighted 2SLS (linearmodels IV2SLS, unadjusted covariance)',
        'sample': 'households with recipient == 0',
        'regression_weight': 'weight',
        'endogenous': ['dose*(1-eligible)', 'dose*eligible'],
        'exogenous': ['1-eligible', 'eligible', 'baseline*(1-eligible)', 'baseline*eligible'],
        'instruments_excluded': ['instrument*(1-eligible)', 'instrument*eligible'],
        'group_effect': 'dose slope times weighted mean dose among retained group rows',
        'population_weights': {'ineligible': w[0], 'eligible': w[1]},
        'counterfactual': 'dose set to zero for every retained household (synthetic convention)',
        'se_note': 'no uncertainty requested; se reported as null',
    },
    'diagnostics': {
        'n_obs': n_obs,
        'n_by_eligible': {str(k): int(v) for k, v in r.eligible.value_counts().sort_index().items()},
        'dose_slopes': {'ineligible': float(fit.params['dose_ineligible']),
                        'eligible': float(fit.params['dose_eligible'])},
        'group_mean_dose': {'ineligible': float(np.average(r[r.eligible == 0].dose, weights=r[r.eligible == 0].weight)),
                            'eligible': float(np.average(r[r.eligible == 1].dose, weights=r[r.eligible == 1].weight))},
    },
}
with open('result.json', 'w') as f:
    json.dump(out, f, indent=2)
print(json.dumps(out, indent=2))
