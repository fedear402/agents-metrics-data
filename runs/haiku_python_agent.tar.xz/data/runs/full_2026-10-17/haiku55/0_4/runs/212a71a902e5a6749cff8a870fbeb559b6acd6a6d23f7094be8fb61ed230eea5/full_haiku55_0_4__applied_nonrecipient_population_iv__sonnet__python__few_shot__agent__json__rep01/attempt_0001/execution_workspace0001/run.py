import json

import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS

hh = pd.read_csv("households.csv")
census = pd.read_csv("census.csv").set_index("eligible")["nonrecipient_population"]

d = hh[hh.recipient == 0].copy()
e = d.eligible.astype(float)
ne = 1.0 - e

X = pd.DataFrame({
    "dose_inel": d.dose * ne,
    "dose_elig": d.dose * e,
})
exog = pd.DataFrame({
    "inel": ne,
    "elig": e,
    "baseline_inel": d.baseline * ne,
    "baseline_elig": d.baseline * e,
})
Z_extra = pd.DataFrame({
    "instrument_inel": d.instrument * ne,
    "instrument_elig": d.instrument * e,
})
instruments = Z_extra

fit = IV2SLS(
    dependent=d.outcome,
    exog=exog,
    endog=X,
    instruments=instruments,
    weights=d.weight,
).fit(cov_type="unadjusted")

slope_inel = float(fit.params["dose_inel"])
slope_elig = float(fit.params["dose_elig"])

mean_dose = {}
for g in [0, 1]:
    h = d[d.eligible == g]
    mean_dose[g] = float(np.average(h.dose, weights=h.weight))

ineligible_effect = slope_inel * mean_dose[0]
eligible_effect = slope_elig * mean_dose[1]

pop_w = np.array([census[0], census[1]], dtype=float)
population_effect = float(np.average([ineligible_effect, eligible_effect], weights=pop_w))

n_obs = int(len(d))

estimates = [
    {"term": "ineligible_effect", "estimate": float(ineligible_effect), "se": None, "n_obs": n_obs},
    {"term": "eligible_nonrecipient_effect", "estimate": float(eligible_effect), "se": None, "n_obs": n_obs},
    {"term": "population_effect", "estimate": population_effect, "se": None, "n_obs": n_obs},
]

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "weighted 2SLS (linearmodels IV2SLS, unadjusted covariance)",
        "regression_weight": "weight",
        "sample": "households with recipient == 0 (both village treatment statuses, both eligibility groups)",
        "endogenous": ["dose*(1-eligible)", "dose*eligible"],
        "exogenous": ["1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"],
        "excluded_instruments": ["instrument*(1-eligible)", "instrument*eligible"],
        "intercept": "none added; 1-eligible and eligible span the intercept",
        "group_effect": "dose slope times household-weighted mean dose among retained group rows",
        "counterfactual": "dose set to zero for every retained household (synthetic convention)",
        "population_weights": {"ineligible": int(census[0]), "eligible": int(census[1])},
    },
    "diagnostics": {
        "n_obs": n_obs,
        "n_ineligible": int((d.eligible == 0).sum()),
        "n_eligible": int((d.eligible == 1).sum()),
        "slope_ineligible": slope_inel,
        "slope_eligible": slope_elig,
        "weighted_mean_dose_ineligible": mean_dose[0],
        "weighted_mean_dose_eligible": mean_dose[1],
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)

print(json.dumps(result, indent=2))
