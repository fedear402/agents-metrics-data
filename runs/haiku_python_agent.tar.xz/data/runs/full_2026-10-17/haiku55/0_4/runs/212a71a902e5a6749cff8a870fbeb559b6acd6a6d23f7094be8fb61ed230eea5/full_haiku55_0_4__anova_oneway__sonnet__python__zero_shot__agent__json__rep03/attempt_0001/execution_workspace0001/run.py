import json
import pandas as pd
import statsmodels.formula.api as smf
from statsmodels.stats.anova import anova_lm

df = pd.read_csv("./input.csv")
model = smf.ols("y ~ C(group)", data=df).fit()
table = anova_lm(model, typ=1)
row = table.loc["C(group)"]
F = float(row["F"])
df_num = float(row["df"])
df_den = float(table.loc["Residual", "df"])
p = float(row["PR(>F)"])
n = int(model.nobs)

est = lambda term, v: {"term": term, "estimate": v, "se": None, "n_obs": n}
result = {
    "task_id": "anova_oneway",
    "platform": "python",
    "estimates": [
        est("F", F),
        est("df_num", df_num),
        est("df_den", df_den),
        est("p_value", p),
    ],
    "method_metadata": {
        "estimator": "One-way ANOVA (OLS of y on group dummies, Type I SS)",
        "vcov": "classical OLS residual variance",
    },
    "diagnostics": {},
}
with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))
