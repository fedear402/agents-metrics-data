import json

import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS

h = pd.read_csv('households.csv')
census = pd.read_csv('census.csv')

d = h[h.recipient == 0].copy()
e = d.eligible.astype(float)
ne = 1.0 - e
d['ne'] = ne
d['e'] = e
d['dose_ne'] = d.dose * ne
d['dose_e'] = d.dose * e
d['base_ne'] = d.baseline * ne
d['base_e'] = d.baseline * e
d['inst_ne'] = d.instrument * ne
d['inst_e'] = d.instrument * e

exog = d[['ne', 'e', 'base_ne', 'base_e']]
endog = d[['dose_ne', 'dose_e']]
instr = d[['inst_ne', 'inst_e']]

fit = IV2SLS(d.outcome, exog, endog, instr, weights=d.weight).fit()

slope_ne = float(fit.params['dose_ne'])
slope_e = float(fit.params['dose_e'])

mean_dose_ne = float(np.average(d.loc[d.eligible == 0, 'dose'], weights=d.loc[d.eligible == 0, 'weight']))
mean_dose_e = float(np.average(d.loc[d.eligible == 1, 'dose'], weights=d.loc[d.eligible == 1, 'weight']))

ineligible_effect = slope_ne * mean_dose_ne
eligible_effect = slope_e * mean_dose_e

pop = census.set_index('eligible').nonrecipient_population
population_effect = float(np.average([ineligible_effect, eligible_effect],
                                     weights=[pop[0], pop[1]]))

n_obs = int(len(d))

result = {
    'task_id': 'applied_nonrecipient_population_iv',
    'platform': 'python',
    'estimates': [
        {'term': 'ineligible_effect', 'estimate': ineligible_effect, 'se': None, 'n_obs': n_obs},
        {'term': 'eligible_nonrecipient_effect', 'estimate': eligible_effect, 'se': None, 'n_obs': n_obs},
        {'term': 'population_effect', 'estimate': population_effect, 'se': None, 'n_obs': n_obs},
    ],
    'method_metadata': {
        'estimator': 'weighted 2SLS (linearmodels IV2SLS, no added intercept)',
        'sample': 'households with recipient == 0',
        'endogenous': ['dose*(1-eligible)', 'dose*eligible'],
        'exogenous': ['1-eligible', 'eligible', 'baseline*(1-eligible)', 'baseline*eligible'],
        'instruments': ['instrument*(1-eligible)', 'instrument*eligible'],
        'regression_weight': 'weight',
        'group_effect': 'dose slope times household-weighted mean dose within eligibility group',
        'counterfactual': 'dose set to zero for all retained households (synthetic convention)',
        'population_weights': {'ineligible': int(pop[0]), 'eligible': int(pop[1])},
    },
    'diagnostics': {
        'n_obs_by_group': {'ineligible': int((d.eligible == 0).sum()), 'eligible': int((d.eligible == 1).sum())},
        'slopes': {'dose_ineligible': slope_ne, 'dose_eligible': slope_e},
        'weighted_mean_dose': {'ineligible': mean_dose_ne, 'eligible': mean_dose_e},
    },
}

with open('result.json', 'w') as f:
    json.dump(result, f, indent=2)

print(json.dumps(result, indent=2))
