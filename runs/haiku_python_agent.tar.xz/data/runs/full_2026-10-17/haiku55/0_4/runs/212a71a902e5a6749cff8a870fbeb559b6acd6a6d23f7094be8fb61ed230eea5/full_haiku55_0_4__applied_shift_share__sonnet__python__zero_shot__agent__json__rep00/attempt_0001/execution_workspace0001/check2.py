import numpy as np, pandas as pd
from linearmodels.iv import IV2SLS
df = pd.read_csv("input.csv")
reg = df.groupby("region_id").first().reset_index()
reg["e"] = reg.region_weight / reg.region_weight.sum()
reg["z"] = reg.region_id.map((df.share*df.shock).groupby(df.region_id).sum())
for v in ["y","x","z"]:
    reg[v+"0"] = reg[v] - np.sum(reg.e*reg[v])
m = df[["region_id","industry_id","share","shock"]].merge(reg[["region_id","e","x0","y0","z0"]], on="region_id")
m["ew"] = m.e*m.share
sh = m.groupby("industry_id").apply(lambda d: pd.Series({
    "s": d.ew.sum(), "shock": d.shock.iloc[0],
    "ybar": np.sum(d.ew*d.y0)/d.ew.sum(), "xbar": np.sum(d.ew*d.x0)/d.ew.sum(),
    "zbar": np.sum(d.ew*d.z0)/d.ew.sum()}), include_groups=False)
N = len(sh)
r = IV2SLS(sh.ybar, sm.add_constant(pd.DataFrame(index=sh.index)) if False else np.ones((N,1)), sh.xbar, sh.shock, weights=sh.s).fit(cov_type="robust")
print("effect", r.params.iloc[1], r.std_errors.iloc[1]*np.sqrt(N/(N-2)))
r2 = IV2SLS(sh.xbar, np.ones((N,1)), sh.zbar, sh.shock, weights=sh.s).fit(cov_type="robust")
print("first_stage", r2.params.iloc[1], r2.std_errors.iloc[1]*np.sqrt(N/(N-2)))
