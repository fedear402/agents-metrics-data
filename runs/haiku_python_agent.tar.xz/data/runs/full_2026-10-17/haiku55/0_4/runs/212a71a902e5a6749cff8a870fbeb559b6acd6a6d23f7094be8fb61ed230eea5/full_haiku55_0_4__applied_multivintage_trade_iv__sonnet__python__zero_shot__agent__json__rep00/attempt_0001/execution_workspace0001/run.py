import json
import numpy as np
import pandas as pd

crosswalk = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv")
areas = pd.read_csv("areas.csv")
emp = pd.read_csv("employment.csv")
outcomes = pd.read_csv("outcomes.csv")

trade = trade.merge(crosswalk, on="code", how="left", validate="one_to_one")
assert trade["industry"].notna().all()

areas_idx = areas.set_index(["area", "period", "vintage"])
emp_full = (
    emp.groupby(["area", "period", "vintage", "industry"])["employment"].sum()
)
grid = pd.MultiIndex.from_product(
    [sorted(areas["area"].unique()), sorted(areas["period"].unique()),
     ["base", "early"], sorted(crosswalk["industry"].unique())],
    names=["area", "period", "vintage", "industry"],
)
emp_full = emp_full.reindex(grid, fill_value=0).astype(float)

trade_idx = trade.set_index(["period", "industry"])
periods = sorted(areas["period"].unique())
industries = sorted(crosswalk["industry"].unique())


def exposure(num_vintage, change_col):
    rows = []
    for p in periods:
        t = trade[trade["period"] == p]
        price = t["price_index"].iloc[0]
        years = t["years"].iloc[0]
        ch = t.set_index("industry")[change_col].reindex(industries).to_numpy(float)
        E = np.array([[emp_full.loc[(a, p, num_vintage, j)] for j in industries]
                      for a in sorted(areas["area"].unique())])
        T = np.array([areas_idx.loc[(a, p, num_vintage), "total_employment"]
                      for a in sorted(areas["area"].unique())], dtype=float)
        N = E.sum(axis=0)
        assert (N > 0).all()
        share = E / T[:, None]
        x = (share * (ch / N)[None, :]).sum(axis=1) / (price / 100) / 1000 * (10 / years)
        rows.append(pd.DataFrame({"area": sorted(areas["area"].unique()), "period": p, "value": x}))
    return pd.concat(rows, ignore_index=True)


x_df = exposure("base", "us_change").rename(columns={"value": "x"})
z_df = exposure("early", "other_change").rename(columns={"value": "z"})
pop = areas[areas["vintage"] == "base"][["area", "period", "population"]]

df = (outcomes.merge(x_df, on=["area", "period"])
      .merge(z_df, on=["area", "period"])
      .merge(pop, on=["area", "period"]))
n_obs = int(len(df))
assert n_obs == 72

y = df["change_pp"].to_numpy(float)
X = np.column_stack([np.ones(n_obs), df["period"].to_numpy(float),
                     df["control"].to_numpy(float), df["x"].to_numpy(float)])
Zf = np.column_stack([np.ones(n_obs), df["period"].to_numpy(float),
                      df["control"].to_numpy(float), df["z"].to_numpy(float)])
w = df["population"].to_numpy(float)
W = np.diag(w)

A = X.T @ W @ Zf
B = np.linalg.inv(Zf.T @ W @ Zf)
beta = np.linalg.solve(A @ B @ A.T, A @ B @ (Zf.T @ W @ y))

def exp_val(frame, col, a, p):
    return float(frame[(frame["area"] == a) & (frame["period"] == p)][col].iloc[0])

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [
        {"term": "iv_slope", "estimate": float(beta[3]), "se": None, "n_obs": n_obs},
        {"term": "exposure_area0_period0", "estimate": exp_val(x_df, "x", 0, 0), "se": None, "n_obs": n_obs},
        {"term": "exposure_area0_period1", "estimate": exp_val(x_df, "x", 0, 1), "se": None, "n_obs": n_obs},
        {"term": "instrument_area0_period0", "estimate": exp_val(z_df, "z", 0, 0), "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "outcome": "change_pp",
        "endogenous": ["x"],
        "instruments": ["z"],
        "exogenous": ["intercept", "period", "control"],
        "weights": "base-vintage population",
        "exposure_units": "thousands of real dollars per worker per decade",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "n_areas": int(areas["area"].nunique()),
        "n_periods": len(periods),
        "n_industries": len(industries),
        "weight_sum": float(w.sum()),
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))
