import json
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent

crosswalk = pd.concat(
    [pd.read_csv(HERE / "crosswalk.csv"), pd.read_csv(HERE / "input.csv")]
).drop_duplicates()
assert crosswalk.code.is_unique
trade = pd.read_csv(HERE / "trade.csv").merge(crosswalk, on="code", how="left", validate="one_to_one")
assert trade.industry.notna().all()
areas = pd.read_csv(HERE / "areas.csv")
emp = pd.read_csv(HERE / "employment.csv")
outcomes = pd.read_csv(HERE / "outcomes.csv")

industries = sorted(crosswalk.industry.unique())
area_ids = sorted(areas.area.unique())
periods = sorted(trade.period.unique())
ai = {a: i for i, a in enumerate(area_ids)}
ji = {j: k for k, j in enumerate(industries)}

E = {}
T = {}
for (v, p), g in emp.groupby(["vintage", "period"]):
    arr = np.zeros((len(area_ids), len(industries)))
    for a, j, e in zip(g.area, g.industry, g.employment):
        arr[ai[a], ji[j]] += e
    E[(v, p)] = arr
for (v, p), g in areas.groupby(["vintage", "period"]):
    vec = np.zeros(len(area_ids))
    vec[[ai[a] for a in g.area]] = g.total_employment
    T[(v, p)] = vec
pop = areas[areas.vintage == "base"].set_index(["period", "area"]).population

tr = trade.set_index(["period", "industry"])


def exposure(vintage, change_col):
    X = np.zeros((len(area_ids), len(periods)))
    for p in periods:
        emp_m = E[(vintage, p)]
        national = emp_m.sum(axis=0)
        t = tr.loc[p].sort_index()
        pi = t.price_index.iloc[0]
        yrs = t.years.iloc[0]
        change = t[change_col].reindex(industries).to_numpy(dtype=float)
        shock = change / national / (pi / 100) / 1000 * (10 / yrs)
        X[:, periods.index(p)] = (emp_m @ shock) / T[(vintage, p)]
    return X


x_mat = exposure("base", "us_change")
z_mat = exposure("early", "other_change")

rows = outcomes.sort_values(["period", "area"]).reset_index(drop=True)
rows["x"] = [x_mat[ai[a], periods.index(p)] for a, p in zip(rows.area, rows.period)]
rows["z"] = [z_mat[ai[a], periods.index(p)] for a, p in zip(rows.area, rows.period)]
rows["w"] = [pop.loc[(p, a)] for a, p in zip(rows.area, rows.period)]
n_obs = len(rows)
assert n_obs == 72

y = rows.change_pp.to_numpy(float)
const = np.ones(n_obs)
period_col = rows.period.to_numpy(float)
control = rows.control.to_numpy(float)
Xmat = np.column_stack([const, period_col, control, rows.x.to_numpy(float)])
Zmat = np.column_stack([const, period_col, control, rows.z.to_numpy(float)])
sw = np.sqrt(rows.w.to_numpy(float))
Xw, Zw, yw = Xmat * sw[:, None], Zmat * sw[:, None], y * sw
Pz_X = Zw @ np.linalg.lstsq(Zw, Xw, rcond=None)[0]
beta = np.linalg.lstsq(Pz_X, yw, rcond=None)[0]
iv_slope = float(beta[-1])

exp_a0_p0 = float(x_mat[ai[0], periods.index(0)])
exp_a0_p1 = float(x_mat[ai[0], periods.index(1)])
inst_a0_p0 = float(z_mat[ai[0], periods.index(0)])

estimates = [
    {"term": "iv_slope", "estimate": iv_slope, "se": None, "n_obs": n_obs},
    {"term": "exposure_area0_period0", "estimate": exp_a0_p0, "se": None, "n_obs": n_obs},
    {"term": "exposure_area0_period1", "estimate": exp_a0_p1, "se": None, "n_obs": n_obs},
    {"term": "instrument_area0_period0", "estimate": inst_a0_p0, "se": None, "n_obs": n_obs},
]
result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "weighted two-stage least squares",
        "outcome": "change_pp",
        "endogenous": ["x"],
        "instruments": ["z"],
        "exogenous": ["intercept", "period", "control"],
        "weights": "base-vintage population",
        "crosswalk_sources": ["crosswalk.csv", "input.csv"],
        "sample": "all area-period observations in outcomes.csv",
    },
    "diagnostics": {
        "n_areas": len(area_ids),
        "n_periods": len(periods),
        "n_industries": len(industries),
        "n_obs": n_obs,
    },
}
with open(HERE / "result.json", "w") as fh:
    json.dump(result, fh, indent=2)
print(json.dumps(estimates, indent=2))
