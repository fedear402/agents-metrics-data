import json

import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS

h = pd.read_csv('households.csv')
census = pd.read_csv('census.csv')

d = h[h.recipient == 0].copy()
e = d.eligible.astype(float)
ne = 1.0 - e

X = pd.DataFrame({
    'ineligible_dose': d.dose * ne,
    'eligible_dose': d.dose * e,
})
exog = pd.DataFrame({
    'ineligible': ne,
    'eligible': e,
    'baseline_ineligible': d.baseline * ne,
    'baseline_eligible': d.baseline * e,
}, index=d.index)
instr = pd.DataFrame({
    'instrument_ineligible': d.instrument * ne,
    'instrument_eligible': d.instrument * e,
}, index=d.index)

fit = IV2SLS(d.outcome, exog, X, instr, weights=d.weight).fit()

groups = {}
for name, flag, slope in [('ineligible', 0, 'ineligible_dose'), ('eligible', 1, 'eligible_dose')]:
    g = d[d.eligible == flag]
    mean_dose = np.average(g.dose, weights=g.weight)
    groups[name] = float(fit.params[slope] * mean_dose)

pop = census.set_index('eligible').nonrecipient_population
population_effect = float(np.average(
    [groups['ineligible'], groups['eligible']],
    weights=[pop.loc[0], pop.loc[1]],
))

n_obs = int(len(d))
ineligible_effect = groups['ineligible']
eligible_effect = groups['eligible']

result = {
    'task_id': 'applied_nonrecipient_population_iv',
    'platform': 'python',
    'estimates': [
        {'term': 'ineligible_effect', 'estimate': ineligible_effect, 'se': None, 'n_obs': n_obs},
        {'term': 'eligible_nonrecipient_effect', 'estimate': eligible_effect, 'se': None, 'n_obs': n_obs},
        {'term': 'population_effect', 'estimate': population_effect, 'se': None, 'n_obs': n_obs},
    ],
    'method_metadata': {
        'estimator': 'weighted 2SLS (linearmodels IV2SLS), no added intercept',
        'sample': 'households with recipient == 0',
        'endogenous': ['dose*(1-eligible)', 'dose*eligible'],
        'exogenous': ['1-eligible', 'eligible', 'baseline*(1-eligible)', 'baseline*eligible'],
        'instruments': ['exogenous columns', 'instrument*(1-eligible)', 'instrument*eligible'],
        'weights': 'weight',
        'group_effect': 'dose slope times household-weighted mean dose within eligibility group',
        'population_weights': {'ineligible': int(pop.loc[0]), 'eligible': int(pop.loc[1])},
        'counterfactual': 'dose set to zero for every retained household (synthetic convention)',
    },
    'diagnostics': {
        'n_obs': n_obs,
        'n_ineligible': int((d.eligible == 0).sum()),
        'n_eligible': int((d.eligible == 1).sum()),
        'ineligible_dose_slope': float(fit.params['ineligible_dose']),
        'eligible_dose_slope': float(fit.params['eligible_dose']),
        'mean_dose_ineligible': float(np.average(d[d.eligible == 0].dose, weights=d[d.eligible == 0].weight)),
        'mean_dose_eligible': float(np.average(d[d.eligible == 1].dose, weights=d[d.eligible == 1].weight)),
    },
}

with open('result.json', 'w') as f:
    json.dump(result, f, indent=2)

print(json.dumps(result['estimates'], indent=2))
print(json.dumps(result['diagnostics'], indent=2))
