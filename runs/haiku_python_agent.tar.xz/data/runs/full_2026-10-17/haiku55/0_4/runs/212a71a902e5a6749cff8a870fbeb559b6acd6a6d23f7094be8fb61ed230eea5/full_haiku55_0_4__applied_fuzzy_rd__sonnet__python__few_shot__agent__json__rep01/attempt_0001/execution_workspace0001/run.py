import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
h = 1.0
sub = df[df["score"].abs() < h].copy()
s = sub["score"].to_numpy()
w = 1.0 - np.abs(s)
right = (s >= 0).astype(float)
Y = sub[["earnings", "participated"]].to_numpy(dtype=float)
n = len(sub)

def side_fit(mask):
    x = s[mask]
    X = np.column_stack([np.ones(mask.sum()), x])
    ww = w[mask]
    A = X.T @ (ww[:, None] * X)
    Ainv = np.linalg.inv(A)
    B = Ainv @ X.T @ (ww[:, None] * Y[mask])
    E = Y[mask] - X @ B
    # influence on intercept: e1' A^{-1} x_i w_i e_i
    infl = (ww[:, None] * (X @ Ainv[:, 0])[:, None]) * E
    return B[0], infl, mask

rb, ir, mr = side_fit(right == 1)
lb, il, ml = side_fit(right == 0)

disc = rb - lb
G = np.zeros((n, 2))
G[mr] = ir
G[ml] = -il
V = G.T @ G  # HC0 sandwich, no df correction

rf, fs = disc[0], disc[1]
te = rf / fs
grad = np.array([1.0 / fs, -rf / fs**2])
se_te = float(np.sqrt(grad @ V @ grad))

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": float(te), "se": se_te, "n_obs": int(n)},
        {"term": "reduced_form", "estimate": float(rf), "se": float(np.sqrt(V[0, 0])), "n_obs": int(n)},
        {"term": "first_stage", "estimate": float(fs), "se": float(np.sqrt(V[1, 1])), "n_obs": int(n)},
    ],
    "method_metadata": {
        "estimator": "Fuzzy RD, local linear, triangular kernel, bandwidth 1, separate slopes by side, cutoff 0",
        "vcov": "HC0 sandwich (no df correction), delta method for ratio using joint covariance",
    },
    "diagnostics": {},
}
with open("result.json", "w") as f:
    json.dump(result, f, indent=2, allow_nan=False)
print(json.dumps(result, indent=2))
