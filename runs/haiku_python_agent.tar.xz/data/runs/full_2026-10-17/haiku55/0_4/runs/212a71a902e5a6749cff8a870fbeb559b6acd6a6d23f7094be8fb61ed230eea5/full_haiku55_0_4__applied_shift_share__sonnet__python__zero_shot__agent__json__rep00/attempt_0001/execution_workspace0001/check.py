import numpy as np, pandas as pd, statsmodels.api as sm
from linearmodels.iv import IV2SLS
df = pd.read_csv("input.csv")
reg = df.groupby("region_id").first().reset_index()
reg["e"] = reg.region_weight / reg.region_weight.sum()
z = (df.share*df.shock).groupby(df.region_id).sum()
reg["z"] = reg.region_id.map(z)
# regional WLS-style 2SLS by hand via sandwich-free route: weighted 2SLS with sqrt(e) scaling
w = np.sqrt(reg.e.values)
X = np.column_stack([np.ones(len(reg)), reg.x.values]) * w[:, None]
Z = np.column_stack([np.ones(len(reg)), reg.z.values]) * w[:, None]
y = reg.y.values * w
PZ = Z @ np.linalg.solve(Z.T @ Z, Z.T)
b_ivw = np.linalg.solve(X.T @ PZ @ X, X.T @ PZ @ y)
print("regional 2SLS slope (sqrt-weight projection):", b_ivw[1])
# first stage via WLS of x on const, z
Zc = np.column_stack([np.ones(len(reg)), reg.z.values])
fs = sm.WLS(reg.x.values, Zc, weights=reg.e.values).fit()
print("regional first stage slope:", fs.params[1])
# shock-level identity: sum_n s_n * shock_n * ybar_n equals sum_r e_r z0 y0
