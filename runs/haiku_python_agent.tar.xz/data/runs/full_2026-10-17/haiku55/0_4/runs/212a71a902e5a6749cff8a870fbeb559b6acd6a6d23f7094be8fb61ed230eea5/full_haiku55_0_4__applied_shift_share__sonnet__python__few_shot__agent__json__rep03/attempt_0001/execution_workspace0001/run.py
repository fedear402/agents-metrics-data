import json
import numpy as np
import pandas as pd

df = pd.read_csv('input.csv')
assert not df[['region_id','industry_id','share','shock','region_weight','x','y']].isna().any().any()
assert not df.duplicated(['region_id','industry_id']).any()
assert np.allclose(df.groupby('region_id')['share'].sum(), 1.0, atol=1e-6)
assert (df.groupby('industry_id')['shock'].nunique() == 1).all()
for c in ['region_weight','x','y']:
    assert (df.groupby('region_id')[c].nunique() == 1).all()

reg = df.groupby('region_id').agg(w=('region_weight','first'), x=('x','first'), y=('y','first'))
e = (reg['w'] / reg['w'].sum()).reindex(df['region_id']).values
df['e'] = e
df['sh_e'] = df['share'] * df['e']
z_reg = df.assign(zz=df['share']*df['shock']).groupby('region_id')['zz'].sum()
reg['z'] = z_reg

e_r = reg['w'].values / reg['w'].sum()
Y, X, Z = reg['y'].values, reg['x'].values, reg['z'].values
Y0 = Y - e_r @ Y
X0 = X - e_r @ X
Z0 = Z - e_r @ Z
C = pd.DataFrame({'region_id': reg.index, 'y0': Y0, 'x0': X0, 'z0': Z0})
d = df.merge(C, on='region_id')

g = d.assign(sy=d['sh_e']*d['y0'], sx=d['sh_e']*d['x0'], sz=d['sh_e']*d['z0']).groupby('industry_id')
agg = g.agg(s=('sh_e','sum'), sy=('sy','sum'), sx=('sx','sum'), sz=('sz','sum'), shock=('shock','first'))
N = len(agg)
s = agg['s'].values
ybar = agg['sy'].values / s
xbar = agg['sx'].values / s
zbar = agg['sz'].values / s
shock = agg['shock'].values

def shock_iv(dep, endog, instr_vals, weights):
    n = len(dep)
    R = np.column_stack([np.ones(n), endog])
    Zm = np.column_stack([np.ones(n), instr_vals])
    cross = Zm.T @ (weights[:, None] * R)
    beta = np.linalg.solve(cross, Zm.T @ (weights * dep))
    u = dep - R @ beta
    scores = Zm * (weights * u)[:, None]
    inv = np.linalg.inv(cross)
    hc1 = n / (n - 2)
    V = hc1 * inv @ (scores.T @ scores) @ inv.T
    return float(beta[1]), float(np.sqrt(V[1, 1]))

effect, effect_se = shock_iv(ybar, xbar, shock, s)
first, first_se = shock_iv(xbar, zbar, shock, s)
eff_shocks = float(1.0 / np.sum(s**2))

# Independent regional checks: weighted 2SLS via projection, and weighted OLS first stage
iv_reg = np.sum(e_r * Z0 * Y0) / np.sum(e_r * Z0 * X0)
fs_reg = np.sum(e_r * Z0 * X0) / np.sum(e_r * Z0**2)
assert np.isclose(effect, iv_reg, rtol=1e-8), (effect, iv_reg)
assert np.isclose(first, fs_reg, rtol=1e-8), (first, fs_reg)

out = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": effect, "se": effect_se, "n_obs": int(N)},
        {"term": "first_stage", "estimate": first, "se": first_se, "n_obs": int(N)},
        {"term": "effective_shocks", "estimate": eff_shocks, "se": None, "n_obs": int(N)},
    ],
    "method_metadata": {
        "estimator": "Shock-level weighted IV (BHJ) equivalent to regional weighted 2SLS of y on x instrumented by z; first stage via shock-level IV",
        "vcov": "HC1 shock-level robust, multiplier N/(N-2), structural residuals, analytic weights s_n",
    },
    "diagnostics": {
        "n_regions": int(len(reg)),
        "n_industries": int(N),
        "regional_iv_check": iv_reg,
        "regional_first_stage_check": fs_reg,
    },
}
with open('result.json', 'w') as f:
    json.dump(out, f, indent=2, allow_nan=False)
print(json.dumps(out, indent=2))
