import json

import pandas as pd
import statsmodels.formula.api as smf
from statsmodels.stats.anova import anova_lm

df = pd.read_csv("input.csv")
df["group"] = df["group"].astype("category")

model = smf.ols("y ~ C(group)", data=df).fit()
table = anova_lm(model, typ=1)
row = table.loc["C(group)"]

F = float(row["F"])
df_num = float(row["df"])
df_den = float(table.loc["Residual", "df"])
p_value = float(row["PR(>F)"])
n_obs = int(model.nobs)

result = {
    "task_id": "anova_oneway",
    "platform": "python",
    "estimates": [
        {"term": "F", "estimate": F, "se": None, "n_obs": n_obs},
        {"term": "df_num", "estimate": df_num, "se": None, "n_obs": n_obs},
        {"term": "df_den", "estimate": df_den, "se": None, "n_obs": n_obs},
        {"term": "p_value", "estimate": p_value, "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "one-way ANOVA via OLS of y on group dummies, Type I sums of squares, F-test of group effect",
        "vcov": "nonrobust (classical residual variance)",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
