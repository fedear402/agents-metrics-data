import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")

reg = df.groupby("region_id").agg(
    region_weight=("region_weight", "first"), x=("x", "first"), y=("y", "first")
).reset_index()
reg["e"] = reg["region_weight"] / reg["region_weight"].sum()

shock_df = df.groupby("industry_id")["shock"].first().rename("shock")
df = df.join(shock_df.rename("shock_chk"), on="industry_id")
df = df.join(reg.set_index("region_id")["e"], on="region_id")
z_reg = df.assign(sw=df["share"] * df["shock"]).groupby("region_id")["sw"].sum().rename("z")
reg = reg.merge(z_reg, left_on="region_id", right_index=True)

e = reg["e"].values
def wmean(v):
    return np.sum(e * v)
y0 = reg["y"].values - wmean(reg["y"].values)
x0 = reg["x"].values - wmean(reg["x"].values)
z0 = reg["z"].values - wmean(reg["z"].values)

beta_reg = np.sum(e * z0 * y0) / np.sum(e * z0 * x0)
fs_reg = np.sum(e * z0 * x0) / np.sum(e * z0 * z0)

ind = df[["region_id", "industry_id", "share", "shock"]].copy()
ind = ind.merge(reg[["region_id", "e"]].assign(y0=y0, x0=x0, z0=z0), on="region_id")
ind["ew"] = ind["e"] * ind["share"]
g = ind.groupby("industry_id")
s = g["ew"].sum()
def agg(col):
    return g.apply(lambda d: np.sum(d["ew"] * d[col]) / d["ew"].sum(), include_groups=False)
ybar = agg("y0")
xbar = agg("x0")
zbar = agg("z0")
shock = g["shock"].first()

ids = s.index
sw = s.values
Y = ybar.loc[ids].values
X_end_x = xbar.loc[ids].values
X_end_z = zbar.loc[ids].values
S = shock.loc[ids].values
N = len(ids)

def iv_hc1(y, endog, instr, w):
    Z = np.column_stack([np.ones(N), instr])
    X = np.column_stack([np.ones(N), endog])
    W = w
    ZWZinv = np.linalg.inv(Z.T @ (Z * W[:, None]))
    Xhat = Z @ (ZWZinv @ (Z.T @ (X * W[:, None])))
    A = np.linalg.inv(Xhat.T @ (X * W[:, None]))
    b = A @ (Xhat.T @ (y * W))
    u = y - X @ b
    meat = (Xhat * (W**2 * u**2)[:, None]).T @ Xhat
    V = A @ meat @ A.T * N / (N - 2)
    return b, np.sqrt(np.diag(V))

b_eff, se_eff = iv_hc1(Y, X_end_x, S, sw)
b_fs, se_fs = iv_hc1(X_end_x, X_end_z, S, sw)
eff_shocks = 1.0 / np.sum(sw**2)

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": float(b_eff[1]), "se": float(se_eff[1]), "n_obs": int(N)},
        {"term": "first_stage", "estimate": float(b_fs[1]), "se": float(se_fs[1]), "n_obs": int(N)},
        {"term": "effective_shocks", "estimate": float(eff_shocks), "se": None, "n_obs": int(N)},
    ],
    "method_metadata": {
        "estimator": "Weighted 2SLS shift-share (regional), shock-level weighted IV for inference (Borusyak-Hull-Jaravel)",
        "vcov": "Shock-level heteroskedasticity-robust HC1 (N/(N-2)), structural IV residuals, analytic weights s_n",
    },
    "diagnostics": {
        "regional_effect": float(beta_reg),
        "regional_first_stage": float(fs_reg),
        "n_regions": int(len(reg)),
        "n_industries": int(N),
        "sum_s": float(np.sum(sw)),
    },
}
with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))
