import json
import numpy as np
import pandas as pd

hh = pd.read_csv("households.csv")
census = pd.read_csv("census.csv").set_index("eligible")

df = hh[hh["recipient"] == 0].copy()
n_obs = int(len(df))

e = df["eligible"].to_numpy(float)
ne = 1.0 - e
dose = df["dose"].to_numpy(float)
base = df["baseline"].to_numpy(float)
inst = df["instrument"].to_numpy(float)
w = df["weight"].to_numpy(float)
y = df["outcome"].to_numpy(float)

X = np.column_stack([dose * ne, dose * e, ne, e, base * ne, base * e])
Z = np.column_stack([ne, e, base * ne, base * e, inst * ne, inst * e])

sw = np.sqrt(w)
Xw = X * sw[:, None]
Zw = Z * sw[:, None]
yw = y * sw
PzX = Zw @ np.linalg.solve(Zw.T @ Zw, Zw.T @ Xw)
beta = np.linalg.solve(PzX.T @ Xw, PzX.T @ yw)
slope_ineligible, slope_eligible = beta[0], beta[1]

def wmean(mask):
    return float(np.sum(w[mask] * dose[mask]) / np.sum(w[mask]))

mean_dose_ineligible = wmean(e == 0)
mean_dose_eligible = wmean(e == 1)

ineligible_effect = slope_ineligible * mean_dose_ineligible
eligible_nonrecipient_effect = slope_eligible * mean_dose_eligible

n0 = float(census.loc[0, "nonrecipient_population"])
n1 = float(census.loc[1, "nonrecipient_population"])
population_effect = (n0 * ineligible_effect + n1 * eligible_nonrecipient_effect) / (n0 + n1)

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {"term": "ineligible_effect", "estimate": float(ineligible_effect), "se": None, "n_obs": n_obs},
        {"term": "eligible_nonrecipient_effect", "estimate": float(eligible_nonrecipient_effect), "se": None, "n_obs": n_obs},
        {"term": "population_effect", "estimate": float(population_effect), "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS, regression weight = weight, no added intercept",
        "endogenous": ["dose*(1-eligible)", "dose*eligible"],
        "exogenous": ["1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"],
        "instruments": ["exogenous four", "instrument*(1-eligible)", "instrument*eligible"],
        "sample": "households with recipient == 0, both treated statuses kept",
        "group_effect": "dose slope times household-weighted mean dose within eligibility group",
        "counterfactual": "dose set to zero for every retained household",
        "aggregation_weights": "census nonrecipient_population (eligible 0: 8400, eligible 1: 1600)",
        "se": "not reported (null)",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "n_ineligible": int(np.sum(e == 0)),
        "n_eligible": int(np.sum(e == 1)),
        "slope_ineligible": float(slope_ineligible),
        "slope_eligible": float(slope_eligible),
        "weighted_mean_dose_ineligible": mean_dose_ineligible,
        "weighted_mean_dose_eligible": mean_dose_eligible,
        "aggregation_weight_ineligible": n0,
        "aggregation_weight_eligible": n1,
        "instrument_matrix_rank": int(np.linalg.matrix_rank(Zw)),
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))
