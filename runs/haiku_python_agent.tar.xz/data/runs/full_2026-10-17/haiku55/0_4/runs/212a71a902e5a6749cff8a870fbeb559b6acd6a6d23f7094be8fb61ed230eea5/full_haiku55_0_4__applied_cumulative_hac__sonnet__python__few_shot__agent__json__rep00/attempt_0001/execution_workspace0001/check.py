import numpy as np, pandas as pd, statsmodels.api as sm
d = pd.read_csv("input.csv").sort_values("date").reset_index(drop=True)
d["dl"] = np.log(d["vix"]).diff()
for k in range(1, 16): d[f"l{k}"] = d["dl"].shift(k)
d["y"] = np.log(d["sales"])
s = d.dropna(subset=["y"] + [f"l{k}" for k in range(1, 16)])
N = len(s)
X = sm.add_constant(s[[f"l{k}" for k in range(1, 16)]])
m = sm.OLS(s["y"], X).fit(cov_type="HAC", cov_kwds={"maxlags": 15, "kernel": "bartlett", "use_correction": False})
V = m.cov_params().to_numpy() * N / (N - 16)
c = np.r_[0, np.ones(15)]
print("N", N, "sum check", c @ m.params.to_numpy(), "se", np.sqrt(c @ V @ c))
print("lag1", m.params.iloc[1], np.sqrt(V[1,1]), "lag15", m.params.iloc[15], np.sqrt(V[15,15]))
# Identity: a constant regressor shift: sum of lag coefs equals long-run effect; check by regressing on the cumulative sum directly
cum_x = s[[f"l{k}" for k in range(1, 16)]].sum(axis=1)
m2 = sm.OLS(s["y"], sm.add_constant(cum_x)).fit()
print("OLS with summed regressor slope (should differ from sum, only sanity):", m2.params.iloc[1])
