import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
s = df["score"].to_numpy()
d = df["participated"].to_numpy(dtype=float)
y = df["earnings"].to_numpy(dtype=float)

inb = np.abs(s) < 1
s, d, y = s[inb], d[inb], y[inb]
w = 1 - np.abs(s)
right = s >= 0
n_obs = int(inb.sum())


def side_fit(mask):
    x = s[mask]
    X = np.column_stack([np.ones_like(x), x])
    wt = w[mask]
    XtWX_inv = np.linalg.inv(X.T @ (X * wt[:, None]))
    by = XtWX_inv @ (X.T @ (wt * y[mask]))
    bd = XtWX_inv @ (X.T @ (wt * d[mask]))
    ey = y[mask] - X @ by
    ed = d[mask] - X @ bd
    S_yy = (X * (wt**2 * ey**2)[:, None]).T @ X
    S_dd = (X * (wt**2 * ed**2)[:, None]).T @ X
    S_yd = (X * (wt**2 * ey * ed)[:, None]).T @ X
    V_yy = XtWX_inv @ S_yy @ XtWX_inv
    V_dd = XtWX_inv @ S_dd @ XtWX_inv
    V_yd = XtWX_inv @ S_yd @ XtWX_inv
    return by[0], bd[0], V_yy[0, 0], V_dd[0, 0], V_yd[0, 0]


yR, dR, vyyR, vddR, vydR = side_fit(right)
yL, dL, vyyL, vddL, vydL = side_fit(~right)

rf = yR - yL
fs = dR - dL
v_rf = vyyR + vyyL
v_fs = vddR + vddL
c_rf_fs = vydR + vydL

te = rf / fs
grad = np.array([1 / fs, -rf / fs**2])
V = np.array([[v_rf, c_rf_fs], [c_rf_fs, v_fs]])
se_te = float(np.sqrt(grad @ V @ grad))

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": float(te), "se": se_te, "n_obs": n_obs},
        {"term": "reduced_form", "estimate": float(rf), "se": float(np.sqrt(v_rf)), "n_obs": n_obs},
        {"term": "first_stage", "estimate": float(fs), "se": float(np.sqrt(v_fs)), "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "Fuzzy RD, local linear, cutoff 0, bandwidth 1, triangular weights 1-|score|, separate slopes and intercepts per side",
        "vcov": "HC0 heteroskedasticity-robust sandwich (no dof correction); delta method for treatment_effect using joint covariance of reduced_form and first_stage",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))
