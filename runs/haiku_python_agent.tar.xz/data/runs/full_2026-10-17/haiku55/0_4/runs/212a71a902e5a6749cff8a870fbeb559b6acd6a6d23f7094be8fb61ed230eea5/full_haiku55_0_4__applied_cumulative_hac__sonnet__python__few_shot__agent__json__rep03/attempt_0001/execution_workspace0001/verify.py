import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

raw = pd.read_csv("input.csv")
raw["date"] = pd.to_datetime(raw["date"])
d = raw.sort_values("date").reset_index(drop=True)
d["dl"] = np.log(d["vix"]).diff()
for k in range(1, 16):
    d[f"l{k}"] = d["dl"].shift(k)
s = d.dropna(subset=["dl"] + [f"l{k}" for k in range(1, 16)]).copy()
N = len(s)
print("rows", len(raw), "N", N, "expected", len(raw) - 1 - 15, "dates monotone", d["date"].is_monotonic_increasing)

X = sm.add_constant(s[[f"l{k}" for k in range(1, 16)]])
y = np.log(s["sales"])
res = sm.OLS(y, X).fit(cov_type="HAC", cov_kwds={"maxlags": 15, "kernel": "bartlett", "use_correction": False})
V = res.cov_params().to_numpy() * N / (N - 16)
b = res.params.to_numpy()
c = np.zeros(16); c[1:] = 1
print("sm cum", c @ b, "se", np.sqrt(c @ V @ c))
print("sm lag1", b[1], np.sqrt(V[1, 1]))
print("sm lag15", b[15], np.sqrt(V[15, 15]))

r = json.load(open("result.json"))
for row in r["estimates"]:
    print(row["term"], row["estimate"], row["se"])
