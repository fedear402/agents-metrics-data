import json
import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS

crosswalk = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv").merge(crosswalk, on="code", how="left")
areas = pd.read_csv("areas.csv")
emp = pd.read_csv("employment.csv")
outcomes = pd.read_csv("outcomes.csv")

industries = sorted(crosswalk["industry"].unique())
grid = pd.MultiIndex.from_product(
    [sorted(areas["area"].unique()), sorted(areas["period"].unique()), ["base", "early"], industries],
    names=["area", "period", "vintage", "industry"],
)
emp_full = (
    emp.set_index(["area", "period", "vintage", "industry"])["employment"]
    .reindex(grid, fill_value=0)
    .reset_index()
)
national = emp_full.groupby(["period", "vintage", "industry"])["employment"].sum().rename("national")
emp_full = emp_full.merge(national.reset_index(), on=["period", "vintage", "industry"])
emp_full = emp_full.merge(
    areas[["area", "period", "vintage", "total_employment"]], on=["area", "period", "vintage"]
)
emp_full = emp_full.merge(trade, on=["period", "industry"], how="left")
assert emp_full["us_change"].notna().all() and (emp_full["national"] > 0).all()


def exposure(vintage, change_col):
    d = emp_full[emp_full["vintage"] == vintage].copy()
    d["term"] = (
        (d["employment"] / d["total_employment"])
        * (d[change_col] / d["national"])
        / (d["price_index"] / 100)
        / 1000
        * (10 / d["years"])
    )
    return d.groupby(["area", "period"])["term"].sum().rename("x")


x = exposure("base", "us_change")
z = exposure("early", "other_change")

df = outcomes.merge(x.reset_index(), on=["area", "period"]).merge(
    z.reset_index().rename(columns={"x": "z"}), on=["area", "period"]
)
df = df.merge(
    areas.loc[areas["vintage"] == "base", ["area", "period", "population"]],
    on=["area", "period"],
)
assert len(df) == 72

df["const"] = 1.0
exog = df[["const", "period", "control"]]
fit = IV2SLS(
    dependent=df["change_pp"],
    exog=exog,
    endog=df["x"],
    instruments=df[["z"]],
    weights=df["population"],
).fit(cov_type="unadjusted")

x_row = df.set_index(["area", "period"])
iv_slope = float(fit.params["x"])
ex00 = float(x_row.loc[(0, 0), "x"])
ex01 = float(x_row.loc[(0, 1), "x"])
z00 = float(x_row.loc[(0, 0), "z"])

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [
        {"term": "iv_slope", "estimate": iv_slope, "se": None, "n_obs": len(df)},
        {"term": "exposure_area0_period0", "estimate": ex00, "se": None, "n_obs": len(df)},
        {"term": "exposure_area0_period1", "estimate": ex01, "se": None, "n_obs": len(df)},
        {"term": "instrument_area0_period0", "estimate": z00, "se": None, "n_obs": len(df)},
    ],
    "method_metadata": {
        "estimator": "weighted IV2SLS",
        "outcome": "change_pp",
        "exogenous": ["const", "period", "control"],
        "endogenous": ["x"],
        "instruments": ["z"],
        "weights": "base-vintage population",
        "n_obs": int(len(df)),
    },
    "diagnostics": {
        "n_obs": int(len(df)),
        "n_areas": int(df["area"].nunique()),
        "n_periods": int(df["period"].nunique()),
    },
}
with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result["estimates"], indent=2))
