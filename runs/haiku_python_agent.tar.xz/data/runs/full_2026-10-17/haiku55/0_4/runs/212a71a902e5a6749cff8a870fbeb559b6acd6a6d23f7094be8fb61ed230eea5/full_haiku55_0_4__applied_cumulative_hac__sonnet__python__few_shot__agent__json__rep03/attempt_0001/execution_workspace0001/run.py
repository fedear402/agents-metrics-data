import json
import numpy as np
import pandas as pd

data = pd.read_csv("input.csv")
data["date"] = pd.to_datetime(data["date"])
data = data.sort_values("date").reset_index(drop=True)
data["dlog_vix"] = np.log(data["vix"]).diff()
L = 15
for k in range(1, L + 1):
    data[f"lag_{k}"] = data["dlog_vix"].shift(k)
sample = data.dropna(subset=["dlog_vix"] + [f"lag_{k}" for k in range(1, L + 1)]).copy()
sample["log_sales"] = np.log(sample["sales"])
N = len(sample)

X = np.column_stack([np.ones(N)] + [sample[f"lag_{k}"].to_numpy() for k in range(1, L + 1)])
y = sample["log_sales"].to_numpy()
beta = np.linalg.solve(X.T @ X, X.T @ y)
resid = y - X @ beta

scores = X * resid[:, None]
meat = scores.T @ scores
for j in range(1, L + 1):
    w = 1 - j / (L + 1)
    gamma = scores[j:].T @ scores[:-j]
    meat += w * (gamma + gamma.T)
bread = np.linalg.inv(X.T @ X)
p = X.shape[1]
V = (N / (N - p)) * bread @ meat @ bread

c = np.zeros(p)
c[1:] = 1.0
cum = float(c @ beta)
cum_se = float(np.sqrt(c @ V @ c))

rows = [
    {"term": "cumulative_response", "estimate": cum, "se": cum_se, "n_obs": N},
    {"term": "lag_1", "estimate": float(beta[1]), "se": float(np.sqrt(V[1, 1])), "n_obs": N},
    {"term": "lag_15", "estimate": float(beta[15]), "se": float(np.sqrt(V[15, 15])), "n_obs": N},
]
out = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": rows,
    "method_metadata": {
        "estimator": "OLS of log(sales) on intercept and 15 lags of first difference of log(vix), trading-observation lags",
        "vcov": "Newey-West HAC, Bartlett weights 1-j/16, max lag 15, scaled by N/(N-16)",
    },
    "diagnostics": {"n_rows_input": int(len(data)), "n_regression": int(N), "n_params": int(p)},
}
with open("result.json", "w") as f:
    json.dump(out, f, indent=2, allow_nan=False)
print(json.dumps(out, indent=2))
