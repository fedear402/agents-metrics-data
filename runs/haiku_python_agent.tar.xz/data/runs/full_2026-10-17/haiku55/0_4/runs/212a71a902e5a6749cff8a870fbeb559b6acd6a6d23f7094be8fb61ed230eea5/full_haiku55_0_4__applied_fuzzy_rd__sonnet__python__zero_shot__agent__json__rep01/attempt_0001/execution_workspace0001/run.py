import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
h = 1.0
s_all = df["score"].to_numpy()
sel = np.abs(s_all) < h
d = df.loc[sel].copy()
s = d["score"].to_numpy()
w = 1.0 - np.abs(s)
right = (s >= 0).astype(float)
left = 1.0 - right
n_obs = int(sel.sum())

X = np.column_stack([right, left, right * s, left * s])
XtWX = X.T @ (w[:, None] * X)
bread = np.linalg.inv(XtWX)


def side_fit(y):
    beta = bread @ (X.T @ (w * y))
    e = y - X @ beta
    # influence of each intercept: row of bread times x_i * w_i * e_i
    G = bread[:2, :]
    psi = (X * (w * e)[:, None]) @ G.T  # n x 2: contributions to (aR, aL)
    return beta[:2], psi


ay, psi_y = side_fit(d["earnings"].to_numpy())
ad, psi_d = side_fit(d["participated"].to_numpy())

rf = ay[0] - ay[1]
fs = ad[0] - ad[1]
cr = np.array([1.0, -1.0])
psi_rf = psi_y @ cr
psi_fs = psi_d @ cr
var_rf = np.sum(psi_rf ** 2)
var_fs = np.sum(psi_fs ** 2)
cov_rf_fs = np.sum(psi_rf * psi_fs)

te = rf / fs
var_te = (var_rf / fs**2 + rf**2 * var_fs / fs**4 - 2 * rf * cov_rf_fs / fs**3)
se_te = float(np.sqrt(var_te))

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": float(te), "se": se_te, "n_obs": n_obs},
        {"term": "reduced_form", "estimate": float(rf), "se": float(np.sqrt(var_rf)), "n_obs": n_obs},
        {"term": "first_stage", "estimate": float(fs), "se": float(np.sqrt(var_fs)), "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "Fuzzy RD, local linear WLS, triangular kernel, bandwidth 1, separate slopes and intercepts per side; treatment effect = reduced form / first stage",
        "vcov": "HC0 heteroskedasticity-robust sandwich per side; delta method with cross-covariance between reduced form and first stage",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)

print(json.dumps(result, indent=2))
