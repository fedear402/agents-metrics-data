import json
import numpy as np
import pandas as pd
from scipy import stats

df = pd.read_csv("input.csv")
df = df.dropna(subset=["group", "y"])
groups = [g["y"].to_numpy() for _, g in df.groupby("group")]
k = len(groups)
n = len(df)
F, p_val = stats.f_oneway(*groups)
df_num = k - 1
df_den = n - k

out = {
    "task_id": "anova_oneway",
    "platform": "python",
    "estimates": [
        {"term": "F", "estimate": float(F), "se": None, "n_obs": n},
        {"term": "df_num", "estimate": float(df_num), "se": None, "n_obs": n},
        {"term": "df_den", "estimate": float(df_den), "se": None, "n_obs": n},
        {"term": "p_value", "estimate": float(p_val), "se": None, "n_obs": n},
    ],
    "method_metadata": {"estimator": "One-way ANOVA F test (y ~ C(group))", "vcov": "none"},
    "diagnostics": {"n_groups": int(k), "group_sizes": {str(g): int(len(v)) for g, v in zip(sorted(df["group"].unique()), groups)}},
}
with open("result.json", "w") as f:
    json.dump(out, f)
