import csv
import json
from collections import defaultdict

import numpy as np

D = "/private/tmp/prospective_task_r9gsv02n/"


def rows(name):
    with open(D + name, newline="") as f:
        return list(csv.DictReader(f))


crosswalk = {r["code"]: int(r["industry"]) for r in rows("crosswalk.csv")}
trade = {}
for r in rows("trade.csv"):
    trade[(int(r["period"]), crosswalk[r["code"]])] = r
areas = {}
for r in rows("areas.csv"):
    areas[(int(r["area"]), int(r["period"]), r["vintage"])] = r
emp = defaultdict(float)
for r in rows("employment.csv"):
    emp[(int(r["area"]), int(r["period"]), r["vintage"], int(r["industry"]))] += float(r["employment"])
outcomes = {}
for r in rows("outcomes.csv"):
    outcomes[(int(r["area"]), int(r["period"]))] = r

INDUSTRIES = sorted({j for (_, j) in trade})
PERIODS = sorted({p for (p, _) in trade})
AREAS = sorted({a for (a, _, _) in areas})

national = {}
for p in PERIODS:
    for v in ("base", "early"):
        for j in INDUSTRIES:
            national[(p, v, j)] = sum(emp.get((a, p, v, j), 0.0) for a in AREAS)
            assert national[(p, v, j)] > 0


def exposure(a, p, vintage, change_key):
    t = areas[(a, p, vintage)]
    total = float(t["total_employment"])
    tr = trade
    total_x = 0.0
    for j in INDUSTRIES:
        row = tr[(p, j)]
        price = float(row["price_index"])
        years = float(row["years"])
        share = emp.get((a, p, vintage, j), 0.0) / total
        nat_share = float(row[change_key]) / national[(p, vintage, j)]
        total_x += share * nat_share / (price / 100) / 1000 * (10 / years)
    return total_x


obs = []
for a in AREAS:
    for p in PERIODS:
        o = outcomes[(a, p)]
        obs.append(dict(
            area=a,
            period=p,
            y=float(o["change_pp"]),
            control=float(o["control"]),
            x=exposure(a, p, "base", "us_change"),
            z=exposure(a, p, "early", "other_change"),
            w=float(areas[(a, p, "base")]["population"]),
        ))

n = len(obs)
y = np.array([o["y"] for o in obs])
period = np.array([float(o["period"]) for o in obs])
control = np.array([o["control"] for o in obs])
x = np.array([o["x"] for o in obs])
z = np.array([o["z"] for o in obs])
w = np.array([o["w"] for o in obs])

one = np.ones(n)
X = np.column_stack([one, period, control, x])
Z = np.column_stack([one, period, control, z])
sw = np.sqrt(w)
Xw = X * sw[:, None]
Zw = Z * sw[:, None]
yw = y * sw
PZ = Zw @ np.linalg.pinv(Zw.T @ Zw) @ Zw.T
beta = np.linalg.solve(Xw.T @ PZ @ Xw, Xw.T @ PZ @ yw)
iv_slope = float(beta[3])

# Independent check: explicit two-stage least squares
first_coef = np.linalg.lstsq(Zw, X[:, 3] * sw, rcond=None)[0]
xhat = Z @ first_coef
W2 = np.column_stack([one, period, control, xhat]) * sw[:, None]
second = np.linalg.lstsq(W2, yw, rcond=None)[0]
iv_check = float(second[3])

def get(a, p):
    return next(o for o in obs if o["area"] == a and o["period"] == p)

exp00 = get(0, 0)["x"]
exp01 = get(0, 1)["x"]
ins00 = get(0, 0)["z"]

out = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [
        {"term": "iv_slope", "estimate": iv_slope, "se": None, "n_obs": n},
        {"term": "exposure_area0_period0", "estimate": float(exp00), "se": None, "n_obs": n},
        {"term": "exposure_area0_period1", "estimate": float(exp01), "se": None, "n_obs": n},
        {"term": "instrument_area0_period0", "estimate": float(ins00), "se": None, "n_obs": n},
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "outcome": "change_pp",
        "endogenous": ["x"],
        "exogenous": ["intercept", "period", "control"],
        "instruments": ["z"],
        "weight": "base-vintage population",
        "n_areas": len(AREAS),
        "n_periods": len(PERIODS),
        "industries": INDUSTRIES,
    },
    "diagnostics": {
        "n_obs": n,
        "iv_slope_two_stage_check": iv_check,
        "iv_slope_check_abs_diff": abs(iv_check - iv_slope),
        "first_stage_coef_on_z": float(first_coef[3]),
    },
}

with open(D + "result.json", "w") as f:
    json.dump(out, f, indent=2)

print(json.dumps(out, indent=2))
