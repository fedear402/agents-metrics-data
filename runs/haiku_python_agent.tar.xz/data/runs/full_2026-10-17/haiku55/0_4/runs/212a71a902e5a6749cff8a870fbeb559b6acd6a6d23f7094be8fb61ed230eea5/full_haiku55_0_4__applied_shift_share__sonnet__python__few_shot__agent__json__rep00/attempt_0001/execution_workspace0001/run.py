import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
reg = df.groupby("region_id").agg(region_weight=("region_weight", "first"),
                                  x=("x", "first"), y=("y", "first")).reset_index()
e = reg["region_weight"].to_numpy(float)
e = e / e.sum()
x = reg["x"].to_numpy(float)
y = reg["y"].to_numpy(float)

df = df.sort_values(["region_id", "industry_id"])
piv_share = df.pivot(index="region_id", columns="industry_id", values="share").loc[reg["region_id"]]
S = piv_share.to_numpy(float)
shock_by_ind = df.groupby("industry_id")["shock"].first().loc[piv_share.columns].to_numpy(float)
z = S @ shock_by_ind

def wmean(v):
    return v - e @ v

y0, x0, z0 = wmean(y), wmean(x), wmean(z)

s = e @ S
vbar = lambda v0: (S.T @ (e * v0)) / s
ybar, xbar, zbar = vbar(y0), vbar(x0), vbar(z0)
N = len(s)

def shock_iv(dep, endog, instr_exog, w):
    X = np.column_stack([np.ones(N), endog])
    Z = np.column_stack([np.ones(N), instr_exog])
    cross = Z.T @ (w[:, None] * X)
    beta = np.linalg.solve(cross, Z.T @ (w * dep))
    resid = dep - X @ beta
    scores = Z * (w * resid)[:, None]
    inv = np.linalg.inv(cross)
    hc1 = N / (N - 2)
    V = hc1 * inv @ (scores.T @ scores) @ inv.T
    return float(beta[1]), float(np.sqrt(V[1, 1]))

effect, effect_se = shock_iv(ybar, xbar, shock_by_ind, s)
first, first_se = shock_iv(xbar, zbar, shock_by_ind, s)
eff_shocks = float(1.0 / np.sum(s ** 2))

# Regional cross-checks
reg_effect = np.sum(e * z0 * y0) / np.sum(e * z0 * x0)
reg_first = np.sum(e * z0 * x0) / np.sum(e * z0 ** 2)

out = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": effect, "se": effect_se, "n_obs": int(N)},
        {"term": "first_stage", "estimate": first, "se": first_se, "n_obs": int(N)},
        {"term": "effective_shocks", "estimate": eff_shocks, "se": None, "n_obs": int(N)},
    ],
    "method_metadata": {
        "estimator": "Regional weighted 2SLS; shift-share IV; shock-level weighted IV (BHJ)",
        "vcov": "Shock-level HC1 sandwich, N/(N-2), structural residuals, analytic weights, no clustering",
    },
    "diagnostics": {
        "n_regions": int(len(e)),
        "n_industries": int(N),
        "min_s": float(s.min()),
        "regional_effect_check": float(reg_effect),
        "regional_first_stage_check": float(reg_first),
    },
}
with open("result.json", "w") as f:
    json.dump(out, f, indent=2, allow_nan=False)
print(json.dumps(out, indent=2))
