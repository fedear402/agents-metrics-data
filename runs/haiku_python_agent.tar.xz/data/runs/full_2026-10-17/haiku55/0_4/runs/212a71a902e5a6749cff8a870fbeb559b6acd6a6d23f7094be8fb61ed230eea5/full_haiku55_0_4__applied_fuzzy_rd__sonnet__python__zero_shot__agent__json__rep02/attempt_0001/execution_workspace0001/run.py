import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
h = 1.0
sub = df[df["score"].abs() < h].copy()
sub["w"] = 1.0 - sub["score"].abs()
sub["right"] = (sub["score"] >= 0).astype(float)

def side_fit(d, y):
    x = d["score"].values
    w = d["w"].values
    yy = d[y].values
    X = np.column_stack([np.ones_like(x), x])
    XtWX = X.T @ (w[:, None] * X)
    bread = np.linalg.inv(XtWX)
    beta = bread @ (X.T @ (w * yy))
    e = yy - X @ beta
    # influence of intercept: w_i * (x_i' bread e1) * e_i
    g = X @ bread[:, 0]
    infl = w * g * e
    return beta[0], np.sum(infl ** 2), infl

def discontinuity(y):
    R = sub[sub["right"] == 1]
    L = sub[sub["right"] == 0]
    aR, vR, iR = side_fit(R, y)
    aL, vL, iL = side_fit(L, y)
    infl = np.zeros(len(sub))
    infl[sub["right"].values == 1] = iR
    infl[sub["right"].values == 0] = -iL
    return aR - aL, infl

rf, inf_y = discontinuity("earnings")
fs, inf_d = discontinuity("participated")
n = len(sub)
V_rf = np.sum(inf_y ** 2)
V_fs = np.sum(inf_d ** 2)
C = np.sum(inf_y * inf_d)

tau = rf / fs
var_tau = V_rf / fs**2 + rf**2 * V_fs / fs**4 - 2 * rf * C / fs**3
se_tau = np.sqrt(var_tau)

out = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": float(tau), "se": float(se_tau), "n_obs": int(n)},
        {"term": "reduced_form", "estimate": float(rf), "se": float(np.sqrt(V_rf)), "n_obs": int(n)},
        {"term": "first_stage", "estimate": float(fs), "se": float(np.sqrt(V_fs)), "n_obs": int(n)},
    ],
    "method_metadata": {
        "estimator": "Fuzzy RD, local linear, triangular kernel, bandwidth 1, cutoff 0, separate slopes and intercepts per side; treatment effect = reduced form / first stage",
        "vcov": "HC0 heteroskedasticity-robust sandwich per side; delta method with covariance between reduced form and first stage",
    },
    "diagnostics": {
        "n_left": int((sub["right"] == 0).sum()),
        "n_right": int((sub["right"] == 1).sum()),
        "bandwidth": h,
        "cov_rf_fs": float(C),
    },
}
with open("result.json", "w") as f:
    json.dump(out, f, indent=2)
print(json.dumps(out, indent=2))
