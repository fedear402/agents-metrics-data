import json

import numpy as np
import pandas as pd
import statsmodels.api as sm

LAGS = 15
df = pd.read_csv("input.csv")
df["date"] = pd.to_datetime(df["date"])
df = df.sort_values("date").reset_index(drop=True)
df["dlvix"] = np.log(df["vix"]).diff()
df["lsales"] = np.log(df["sales"])
for k in range(1, LAGS + 1):
    df[f"lag_{k}"] = df["dlvix"].shift(k)

sample = df.dropna(subset=["lsales"] + [f"lag_{k}" for k in range(1, LAGS + 1)])
N = len(sample)
X = sm.add_constant(sample[[f"lag_{k}" for k in range(1, LAGS + 1)]])
y = sample["lsales"]

ols = sm.OLS(y, X).fit(
    cov_type="HAC",
    cov_kwds={"maxlags": LAGS, "use_correction": False, "kernel": "bartlett"},
)
V = ols.cov_params().values * N / (N - (LAGS + 1))
b = ols.params.values

names = list(X.columns)
R = np.zeros(len(names))
R[1:] = 1.0
cum = float(R @ b)
cum_se = float(np.sqrt(R @ V @ R))

def se_of(name):
    return float(np.sqrt(V[names.index(name), names.index(name)]))

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {"term": "cumulative_response", "estimate": cum, "se": cum_se, "n_obs": N},
        {"term": "lag_1", "estimate": float(b[names.index("lag_1")]), "se": se_of("lag_1"), "n_obs": N},
        {"term": "lag_15", "estimate": float(b[names.index("lag_15")]), "se": se_of("lag_15"), "n_obs": N},
    ],
    "method_metadata": {
        "estimator": "OLS of log(sales) on intercept and 15 lags of diff log(vix)",
        "vcov": "Newey-West HAC, maxlags=15, Bartlett weights 1-j/16, scaled by N/(N-16)",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))
