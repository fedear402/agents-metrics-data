import json
import numpy as np
import pandas as pd

BANDWIDTH = 1.0
df = pd.read_csv("input.csv")
df = df[df["score"].notna() & df["participated"].notna() & df["earnings"].notna()]
inside = df[df["score"].abs() < BANDWIDTH].copy()
s = inside["score"].to_numpy()
w = 1.0 - np.abs(s)
right = (s >= 0).astype(float)
left = 1.0 - right
X = np.column_stack([left, left * s, right, right * s])
Y = np.column_stack([inside["earnings"].to_numpy(), inside["participated"].to_numpy()])

XtWX = X.T @ (w[:, None] * X)
bread = np.linalg.inv(XtWX)
beta = bread @ (X.T @ (w[:, None] * Y))
resid = Y - X @ beta

# Contrast: right intercept minus left intercept
c = np.array([-1.0, 0.0, 1.0, 0.0])
loading = w * (X @ bread @ c)
h = loading[:, None] * resid
V = h.T @ h

rf, fs = c @ beta[:, 0], c @ beta[:, 1]
rf_se, fs_se = np.sqrt(V[0, 0]), np.sqrt(V[1, 1])
te = rf / fs
grad = np.array([1.0 / fs, -rf / fs**2])
te_se = np.sqrt(grad @ V @ grad)

n_total = int(len(inside))
result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": float(te), "se": float(te_se), "n_obs": n_total},
        {"term": "reduced_form", "estimate": float(rf), "se": float(rf_se), "n_obs": n_total},
        {"term": "first_stage", "estimate": float(fs), "se": float(fs_se), "n_obs": n_total},
    ],
    "method_metadata": {
        "estimator": "Fuzzy RD, local linear, triangular kernel weights 1-|score|, bandwidth 1, separate slopes by side, Wald ratio",
        "vcov": "HC0 sandwich, delta method for ratio, no degrees-of-freedom correction",
    },
    "diagnostics": {"n_left": int(left.sum()), "n_right": int(right.sum())},
}
with open("result.json", "w") as f:
    json.dump(result, f, indent=2, allow_nan=False)
print(json.dumps(result, indent=2))
