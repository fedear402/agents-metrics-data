import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("input.csv")
sub = df[df["score"].abs() < 1].copy()
s = sub["score"].to_numpy(); w = 1 - np.abs(s); I = (s >= 0).astype(float)
y = sub["earnings"].to_numpy(); d = sub["participated"].to_numpy(float)
res = json.load(open("result.json"))["estimates"]
est = {r["term"]: r for r in res}

# Check 1: statsmodels WLS per side, HC0
out = {}
for name, yv in [("reduced_form", y), ("first_stage", d)]:
    fits = {}
    for side, m in [("R", I == 1), ("L", I == 0)]:
        X = sm.add_constant(s[m])
        fits[side] = sm.WLS(yv[m], X, weights=w[m]).fit(cov_type="HC0")
    diff = fits["R"].params[0] - fits["L"].params[0]
    var = fits["R"].cov_HC0[0, 0] + fits["L"].cov_HC0[0, 0]
    out[name] = (diff, np.sqrt(var))
    print(name, "statsmodels", diff, np.sqrt(var), "script", est[name]["estimate"], est[name]["se"])

# Check 2: exact IV identity. Just-identified weighted IV with
# X=[1,D,s*(1-I),s*I], Z=[1,I,s*(1-I),s*I] gives the ratio RF/FS.
X = np.column_stack([np.ones(len(s)), d, s * (1 - I), s * I])
Z = np.column_stack([np.ones(len(s)), I, s * (1 - I), s * I])
ZWX = Z.T @ (w[:, None] * X)
inv = np.linalg.inv(ZWX)
beta = inv @ (Z.T @ (w * y))
print("IV ratio", beta[1], "script", est["treatment_effect"]["estimate"])

# Check 3: IV HC0 sandwich for the D coefficient (independent SE)
e = y - X @ beta
meat_scores = (w * e)[:, None] * Z
Vb = inv @ (meat_scores.T @ meat_scores) @ inv.T
print("IV sandwich SE", np.sqrt(Vb[1, 1]), "script", est["treatment_effect"]["se"])
