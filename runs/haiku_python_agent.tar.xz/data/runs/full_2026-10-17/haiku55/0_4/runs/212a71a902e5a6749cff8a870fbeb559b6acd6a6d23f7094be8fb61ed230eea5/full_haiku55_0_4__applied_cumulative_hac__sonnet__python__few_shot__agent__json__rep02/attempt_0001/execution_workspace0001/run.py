import json
import numpy as np
import pandas as pd

data = pd.read_csv("input.csv")
data["date"] = pd.to_datetime(data["date"])
data = data.sort_values("date").reset_index(drop=True)
data["vol_change"] = np.log(data["vix"]).diff()
L = 15
for k in range(1, L + 1):
    data[f"lag_{k}"] = data["vol_change"].shift(k)
data["log_sales"] = np.log(data["sales"])

cols = [f"lag_{k}" for k in range(1, L + 1)]
sample = data.dropna(subset=["log_sales"] + cols)
N = len(sample)
X = np.column_stack([np.ones(N), sample[cols].to_numpy()])
y = sample["log_sales"].to_numpy()
beta = np.linalg.lstsq(X, y, rcond=None)[0]
resid = y - X @ beta

scores = X * resid[:, None]
hac_lags = L
meat = scores.T @ scores
for j in range(1, hac_lags + 1):
    w = 1 - j / (hac_lags + 1)
    gamma = scores[j:].T @ scores[:-j]
    meat += w * (gamma + gamma.T)
bread = np.linalg.inv(X.T @ X)
p = X.shape[1]
V = (N / (N - p)) * bread @ meat @ bread

c = np.zeros(p)
c[1:] = 1.0
cum = float(c @ beta)
cum_se = float(np.sqrt(c @ V @ c))

output = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {"term": "cumulative_response", "estimate": cum, "se": cum_se, "n_obs": N},
        {"term": "lag_1", "estimate": float(beta[1]), "se": float(np.sqrt(V[1, 1])), "n_obs": N},
        {"term": "lag_15", "estimate": float(beta[15]), "se": float(np.sqrt(V[15, 15])), "n_obs": N},
    ],
    "method_metadata": {
        "estimator": "OLS of log(sales) on intercept and 15 lags of first difference of log(vix)",
        "vcov": "Newey-West HAC, max lag 15, Bartlett weights, times N/(N-16)",
    },
    "diagnostics": {"sample_start": str(sample["date"].iloc[0].date()), "sample_end": str(sample["date"].iloc[-1].date())},
}
with open("result.json", "w") as f:
    json.dump(output, f, indent=2, allow_nan=False)
print(json.dumps(output, indent=2))
