import numpy as np, pandas as pd, json
from linearmodels.iv import IV2SLS
cw = pd.concat([pd.read_csv("crosswalk.csv"), pd.read_csv("input.csv")]).drop_duplicates()
tr = pd.read_csv("trade.csv").merge(cw, on="code")
ar = pd.read_csv("areas.csv"); em = pd.read_csv("employment.csv"); oc = pd.read_csv("outcomes.csv")

def emp(a, p, v, j):
    m = em[(em.area==a)&(em.period==p)&(em.vintage==v)&(em.industry==j)].employment
    return float(m.sum())
def tot(a, p, v):
    return float(ar[(ar.area==a)&(ar.period==p)&(ar.vintage==v)].total_employment.iloc[0])
def natl(p, v, j):
    return float(em[(em.period==p)&(em.vintage==v)&(em.industry==j)].employment.sum())
def expo(a, p, v, col):
    t = tr[tr.period==p]
    s = 0.0
    for _, r in t.iterrows():
        j = r.industry
        sh = emp(a,p,v,j)/tot(a,p,v)
        shock = r[col]/natl(p,v,j)/(r.price_index/100)/1000*(10/r.years)
        s += sh*shock
    return s
print("x a0p0", expo(0,0,"base","us_change"), "x a0p1", expo(0,1,"base","us_change"))
print("z a0p0", expo(0,0,"early","other_change"))

rows = oc.sort_values(["period","area"]).reset_index(drop=True)
rows["x"] = [expo(a,p,"base","us_change") for a,p in zip(rows.area, rows.period)]
rows["z"] = [expo(a,p,"early","other_change") for a,p in zip(rows.area, rows.period)]
rows["w"] = [float(ar[(ar.area==a)&(ar.period==p)&(ar.vintage=="base")].population.iloc[0]) for a,p in zip(rows.area, rows.period)]
print("n rows", len(rows))
fit = IV2SLS(rows.change_pp, rows[["period","control"]].assign(const=1.0)[["const","period","control"]],
             rows[["x"]], rows[["z"]], weights=rows.w).fit()
print("linearmodels iv_slope", float(fit.params["x"]))
print("linearmodels first-stage check: n", fit.nobs)
