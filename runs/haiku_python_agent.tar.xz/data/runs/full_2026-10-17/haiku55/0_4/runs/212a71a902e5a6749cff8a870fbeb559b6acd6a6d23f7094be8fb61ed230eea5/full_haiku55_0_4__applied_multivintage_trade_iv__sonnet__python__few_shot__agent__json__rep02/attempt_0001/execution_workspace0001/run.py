import json
import numpy as np
import pandas as pd

crosswalk = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv").merge(crosswalk, on="code", how="left")
areas = pd.read_csv("areas.csv")
employment = pd.read_csv("employment.csv")
outcomes = pd.read_csv("outcomes.csv")

industries = sorted(crosswalk["industry"].unique())
emp = (employment.groupby(["area", "period", "vintage", "industry"])["employment"]
       .sum().unstack("industry").reindex(columns=industries, fill_value=0.0).fillna(0.0))
national = emp.groupby(level=["period", "vintage"]).sum()


def exposure(vintage, change_col):
    rows = []
    for (area, period), _ in areas.groupby(["area", "period"]):
        e = emp.loc[(area, period, vintage)].reindex(industries).to_numpy(float)
        total = areas.loc[(areas.area == area) & (areas.period == period) & (areas.vintage == vintage),
                          "total_employment"].iloc[0]
        t = trade[trade.period == period].set_index("industry").loc[industries]
        nat = national.loc[(period, vintage)].reindex(industries).to_numpy(float)
        shock = (t[change_col].to_numpy(float) / nat / (t["price_index"].to_numpy(float) / 100)
                 / 1000 * (10 / t["years"].to_numpy(float)))
        rows.append({"area": area, "period": period, "value": float(e @ shock / total)})
    return pd.DataFrame(rows)


x = exposure("base", "us_change")
z = exposure("early", "other_change")
df = outcomes.merge(x.rename(columns={"value": "x"}), on=["area", "period"])
df = df.merge(z.rename(columns={"value": "z"}), on=["area", "period"])
df = df.merge(areas[areas.vintage == "base"][["area", "period", "population"]], on=["area", "period"])
df = df.sort_values(["period", "area"]).reset_index(drop=True)

w = np.sqrt(df["population"].to_numpy(float))
y = df["change_pp"].to_numpy(float) * w
ones = np.ones(len(df))
X = np.column_stack([ones, df["period"], df["control"], df["x"]]) * w[:, None]
Z = np.column_stack([ones, df["period"], df["control"], df["z"]]) * w[:, None]
P = Z @ np.linalg.pinv(Z.T @ Z) @ Z.T
beta = np.linalg.solve(X.T @ P @ X, X.T @ P @ y)
iv_slope = float(beta[-1])

def get(table, area, period):
    return float(table.loc[(table.area == area) & (table.period == period), "value"].iloc[0])

n_obs = int(len(df))
result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [
        {"term": "iv_slope", "estimate": iv_slope, "se": None, "n_obs": n_obs},
        {"term": "exposure_area0_period0", "estimate": get(x, 0, 0), "se": None, "n_obs": n_obs},
        {"term": "exposure_area0_period1", "estimate": get(x, 0, 1), "se": None, "n_obs": n_obs},
        {"term": "instrument_area0_period0", "estimate": get(z, 0, 0), "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "outcome": "change_pp",
        "endogenous": "x",
        "instrument": "z",
        "exogenous": ["intercept", "period", "control"],
        "weights": "base-vintage population",
        "n_obs": n_obs,
    },
    "diagnostics": {"n_obs": n_obs},
}
with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))
