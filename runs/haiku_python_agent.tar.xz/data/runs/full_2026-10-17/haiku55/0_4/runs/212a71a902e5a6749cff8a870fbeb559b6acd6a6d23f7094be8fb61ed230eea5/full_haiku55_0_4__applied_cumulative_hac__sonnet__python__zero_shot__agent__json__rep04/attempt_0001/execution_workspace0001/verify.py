import json
import numpy as np
import pandas as pd

L = 15
df = pd.read_csv("input.csv").sort_values("date").reset_index(drop=True)
lv = np.log(df["vix"].values); ly = np.log(df["sales"].values)
dl = np.diff(lv)  # dl[i] = change at obs i+1
T = len(ly)
rows = range(L + 1, T)  # obs t needs dl[t-1-15..t-1-1], i.e. t-15 >= 1
Y = np.array([ly[t] for t in rows])
X = np.array([[1.0] + [dl[t - k - 1] for k in range(1, L + 1)] for t in rows])
N, K = X.shape
XtX_inv = np.linalg.inv(X.T @ X)
b = XtX_inv @ X.T @ Y
u = Y - X @ b
# Newey-West meat, Bartlett weights 1-j/(L+1)
S = (X * u[:, None]).T @ (X * u[:, None])
for j in range(1, L + 1):
    w = 1 - j / (L + 1)
    G = (X[j:] * u[j:, None]).T @ (X[:-j] * u[:-j, None])
    S += w * (G + G.T)
V = XtX_inv @ S @ XtX_inv * N / (N - (L + 1))
c = np.r_[0.0, np.ones(L)]
res = json.load(open("result.json"))["estimates"]
checks = {
    "N": (N, res[0]["n_obs"]),
    "cum": (c @ b, res[0]["estimate"]),
    "cum_se": (np.sqrt(c @ V @ c), res[0]["se"]),
    "lag_1": (b[1], res[1]["estimate"]),
    "lag_1_se": (np.sqrt(V[1, 1]), res[1]["se"]),
    "lag_15": (b[15], res[2]["estimate"]),
    "lag_15_se": (np.sqrt(V[15, 15]), res[2]["se"]),
}
for k, (a, bb) in checks.items():
    print(f"{k:10s} numpy={a:.10g} result={bb:.10g} diff={abs(a-bb):.2e}")
