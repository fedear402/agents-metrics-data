import json
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
hh = pd.read_csv(HERE / "households.csv")
census = pd.read_csv(HERE / "census.csv")

df = hh[hh["recipient"] == 0].copy()
n = len(df)
e = df["eligible"].to_numpy(float)
ne = 1.0 - e
dose = df["dose"].to_numpy(float)
base = df["baseline"].to_numpy(float)
inst = df["instrument"].to_numpy(float)
w = df["weight"].to_numpy(float)
y = df["outcome"].to_numpy(float)

X = np.column_stack([dose * ne, dose * e, ne, e, base * ne, base * e])
Z = np.column_stack([ne, e, base * ne, base * e, inst * ne, inst * e])
W = w

ZtWX = Z.T @ (W[:, None] * X)
ZtWy = Z.T @ (W * y)
beta = np.linalg.solve(ZtWX, ZtWy)
slope0, slope1 = beta[0], beta[1]


def wmean_dose(mask):
    return float(np.sum(w[mask] * dose[mask]) / np.sum(w[mask]))


m0 = e == 0
m1 = e == 1
eff0 = slope0 * wmean_dose(m0)
eff1 = slope1 * wmean_dose(m1)

pop = census.set_index("eligible")["nonrecipient_population"]
N0 = float(pop.loc[0])
N1 = float(pop.loc[1])
pop_eff = (N0 * eff0 + N1 * eff1) / (N0 + N1)

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {"term": "ineligible_effect", "estimate": float(eff0), "se": None, "n_obs": int(n)},
        {"term": "eligible_nonrecipient_effect", "estimate": float(eff1), "se": None, "n_obs": int(n)},
        {"term": "population_effect", "estimate": float(pop_eff), "se": None, "n_obs": int(n)},
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS, exactly identified (6 instruments, 6 regressors), no added intercept",
        "regression_weight": "weight",
        "endogenous": ["dose*(1-eligible)", "dose*eligible"],
        "exogenous": ["1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"],
        "excluded_instruments": ["instrument*(1-eligible)", "instrument*eligible"],
        "sample": "recipient == 0, all eligibility and treatment statuses",
        "group_effect": "fitted dose slope times household-weighted mean dose within eligibility group",
        "population_weights": {"eligible=0": N0, "eligible=1": N1},
        "counterfactual": "dose set to zero for every retained household",
        "uncertainty": "not requested; se reported as null",
    },
    "diagnostics": {
        "n_retained": int(n),
        "n_by_eligible": {"0": int(m0.sum()), "1": int(m1.sum())},
        "dose_slope_ineligible": float(slope0),
        "dose_slope_eligible": float(slope1),
        "weighted_mean_dose_ineligible": wmean_dose(m0),
        "weighted_mean_dose_eligible": wmean_dose(m1),
        "rank_ZtWX": int(np.linalg.matrix_rank(ZtWX)),
    },
}

with open(HERE / "result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result["estimates"], indent=2))
print(json.dumps(result["diagnostics"], indent=2))
