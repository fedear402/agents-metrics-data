import json

import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS

households = pd.read_csv('households.csv')
census = pd.read_csv('census.csv')

d = households[households.recipient == 0].copy()
e = d.eligible.astype(float)
ne = 1.0 - e

endog = pd.DataFrame({
    'dose_ineligible': d.dose * ne,
    'dose_eligible': d.dose * e,
})
exog = pd.DataFrame({
    'ineligible': ne,
    'eligible': e,
    'baseline_ineligible': d.baseline * ne,
    'baseline_eligible': d.baseline * e,
})
excluded = pd.DataFrame({
    'instrument_ineligible': d.instrument * ne,
    'instrument_eligible': d.instrument * e,
})

fit = IV2SLS(d.outcome, exog, endog, excluded, weights=d.weight).fit(cov_type='unadjusted')

group_effects = {}
group_slopes = {}
group_counts = {}
for g, col in [(0, 'dose_ineligible'), (1, 'dose_eligible')]:
    mask = d.eligible == g
    mean_dose = np.average(d.dose[mask], weights=d.weight[mask])
    group_slopes[g] = float(fit.params[col])
    group_effects[g] = float(fit.params[col] * mean_dose)
    group_counts[g] = int(mask.sum())

pop = census.set_index('eligible').nonrecipient_population
population_effect = float(np.average(
    [group_effects[0], group_effects[1]],
    weights=[float(pop.loc[0]), float(pop.loc[1])],
))

n_obs = int(len(d))
result = {
    'task_id': 'applied_nonrecipient_population_iv',
    'platform': 'python',
    'estimates': [
        {'term': 'ineligible_effect', 'estimate': group_effects[0], 'se': None, 'n_obs': n_obs},
        {'term': 'eligible_nonrecipient_effect', 'estimate': group_effects[1], 'se': None, 'n_obs': n_obs},
        {'term': 'population_effect', 'estimate': population_effect, 'se': None, 'n_obs': n_obs},
    ],
    'method_metadata': {
        'estimator': 'weighted 2SLS (linearmodels IV2SLS, unadjusted covariance)',
        'sample': 'households with recipient == 0, all village treatment statuses',
        'endogenous': ['dose*(1-eligible)', 'dose*eligible'],
        'exogenous': ['1-eligible', 'eligible', 'baseline*(1-eligible)', 'baseline*eligible'],
        'excluded_instruments': ['instrument*(1-eligible)', 'instrument*eligible'],
        'regression_weight': 'weight',
        'group_effect': 'dose slope times household-weighted mean dose within eligibility group',
        'counterfactual': 'dose set to zero for every retained household (synthetic convention)',
        'population_weights': {'0': float(pop.loc[0]), '1': float(pop.loc[1])},
    },
    'diagnostics': {
        'n_obs': n_obs,
        'group_counts': {'0': group_counts[0], '1': group_counts[1]},
        'group_dose_slopes': {'0': group_slopes[0], '1': group_slopes[1]},
        'group_effects': {'0': group_effects[0], '1': group_effects[1]},
    },
}

with open('result.json', 'w') as f:
    json.dump(result, f, indent=2)

print(json.dumps(result, indent=2))
