import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
h = 1.0
s = df["score"].to_numpy()
mask = np.abs(s) < h
d = df[mask].reset_index(drop=True)
s = d["score"].to_numpy()
w = 1 - np.abs(s)
D = (s >= 0).astype(float)
X = np.column_stack([np.ones_like(s), D, s, D * s])
Y = np.column_stack([d["earnings"].to_numpy(), d["participated"].to_numpy().astype(float)])

XtWX = X.T @ (w[:, None] * X)
bread = np.linalg.inv(XtWX)
B = bread @ X.T @ (w[:, None] * Y)
E = Y - X @ B

contrast = np.array([0.0, 1.0, 0.0, 0.0])
jumps = contrast @ B
rf, fs = jumps
loading = w * (X @ bread @ contrast)
G = loading[:, None] * E
V = G.T @ G

gradient = np.array([1 / fs, -rf / fs**2])
te = rf / fs
te_se = float(np.sqrt(gradient @ V @ gradient))
n = int(mask.sum())

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": float(te), "se": te_se, "n_obs": n},
        {"term": "reduced_form", "estimate": float(rf), "se": float(np.sqrt(V[0, 0])), "n_obs": n},
        {"term": "first_stage", "estimate": float(fs), "se": float(np.sqrt(V[1, 1])), "n_obs": n},
    ],
    "method_metadata": {
        "estimator": "Fuzzy RD, local linear WLS with triangular kernel, separate slopes, bandwidth 1, cutoff 0",
        "vcov": "HC0 sandwich, delta method for ratio, joint covariance of reduced form and first stage",
    },
    "diagnostics": {},
}
with open("result.json", "w") as f:
    json.dump(result, f, indent=2, allow_nan=False)
print(json.dumps(result, indent=2))
