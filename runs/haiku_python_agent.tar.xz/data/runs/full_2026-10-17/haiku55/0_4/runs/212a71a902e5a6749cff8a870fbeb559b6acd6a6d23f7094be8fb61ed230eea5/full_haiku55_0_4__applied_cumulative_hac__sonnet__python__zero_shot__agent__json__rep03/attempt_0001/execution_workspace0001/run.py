import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

L = 15
df = pd.read_csv("input.csv")
df = df.sort_values("date").reset_index(drop=True)
df["dlvix"] = np.log(df["vix"]).diff()
df["lsales"] = np.log(df["sales"])
for k in range(1, L + 1):
    df[f"lag_{k}"] = df["dlvix"].shift(k)
d = df.dropna(subset=["lsales"] + [f"lag_{k}" for k in range(1, L + 1)]).copy()

X = sm.add_constant(d[[f"lag_{k}" for k in range(1, L + 1)]].values)
y = d["lsales"].values
N, K = X.shape
XtX_inv = np.linalg.inv(X.T @ X)
b = XtX_inv @ X.T @ y
u = y - X @ b

# Newey-West with Bartlett weights 1-j/(L+1)
S = (X * u[:, None]).T @ (X * u[:, None])
for j in range(1, L + 1):
    w = 1 - j / (L + 1)
    G = (X[j:] * u[j:, None]).T @ (X[:-j] * u[:-j, None])
    S += w * (G + G.T)
V = XtX_inv @ S @ XtX_inv * N / (N - (L + 1))

R = np.zeros(K)
R[1:] = 1.0
cum = float(R @ b)
cum_se = float(np.sqrt(R @ V @ R))

est = [
    {"term": "cumulative_response", "estimate": cum, "se": cum_se, "n_obs": int(N)},
    {"term": "lag_1", "estimate": float(b[1]), "se": float(np.sqrt(V[1, 1])), "n_obs": int(N)},
    {"term": "lag_15", "estimate": float(b[L]), "se": float(np.sqrt(V[L, L])), "n_obs": int(N)},
]
out = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": est,
    "method_metadata": {
        "estimator": "OLS of log(sales) on intercept and 15 lags of diff log(vix)",
        "vcov": "Newey-West HAC, maxlags=15, Bartlett weights 1-j/16, scaled by N/(N-16)",
    },
    "diagnostics": {},
}
with open("result.json", "w") as f:
    json.dump(out, f, indent=2)

# Independent check via statsmodels HAC (no small-sample correction, then scaled)
res = sm.OLS(y, X).fit(cov_type="HAC", cov_kwds={"maxlags": L, "use_correction": False})
V_sm = res.cov_params() * N / (N - (L + 1))
print("N =", N)
print("manual  cum", cum, cum_se)
print("statsm  cum", float(R @ res.params), float(np.sqrt(R @ V_sm @ R)))
print("max |coef diff|", np.max(np.abs(res.params - b)))
print("max |cov diff|", np.max(np.abs(V_sm - V)))
print(json.dumps(out, indent=2))
