import csv, json
import numpy as np
hh=[r for r in csv.DictReader(open("households.csv")) if int(r["recipient"])==0]
f=lambda k: np.array([float(r[k]) for r in hh])
e=f("eligible"); ne=1-e; d=f("dose"); b=f("baseline"); z=f("instrument"); w=f("weight"); y=f("outcome")
X=np.column_stack([d*ne,d*e,ne,e,b*ne,b*e]); Z=np.column_stack([ne,e,b*ne,b*e,z*ne,z*e])
sw=np.sqrt(w)
Xs,Zs,ys=X*sw[:,None],Z*sw[:,None],y*sw
Q,_=np.linalg.qr(Zs); Xh=Q@(Q.T@Xs)
bet2=np.linalg.lstsq(Xh,ys,rcond=None)[0]
bet_exact=np.linalg.solve(Z.T@(X*w[:,None]), Z.T@(y*w))
r=json.load(open("result.json"))
print("2SLS-fitted-values beta:",bet2[:2]); print("exact IV beta:",bet_exact[:2])
ie=bet2[0]*np.sum(w[ne==1]*d[ne==1])/np.sum(w[ne==1])
ee=bet2[1]*np.sum(w[e==1]*d[e==1])/np.sum(w[e==1])
pe=(8400*ie+1600*ee)/10000
print("check ineligible",ie, "ee",ee,"pop",pe)
print("result.json:",[x["estimate"] for x in r["estimates"]])
print("max abs diff:",max(abs(ie-r["estimates"][0]["estimate"]),abs(ee-r["estimates"][1]["estimate"]),abs(pe-r["estimates"][2]["estimate"])))
