import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
from statsmodels.sandbox.regression.gmm import IV2SLS

df = pd.read_csv('input.csv')
reg = df.groupby('region_id').agg(w=('region_weight', 'first'), x=('x', 'first'), y=('y', 'first'))
reg['z'] = df.assign(p=df.share * df.shock).groupby('region_id')['p'].sum()
reg['e'] = reg['w'] / reg['w'].sum()
sw = np.sqrt(reg['e'].to_numpy())
ones = np.ones(len(reg))
yv, xv, zv = reg['y'].to_numpy(), reg['x'].to_numpy(), reg['z'].to_numpy()
# Regional weighted 2SLS via statsmodels, weights absorbed by sqrt(e)
iv = IV2SLS(sw * yv, np.column_stack([sw, sw * xv]), np.column_stack([sw, sw * zv])).fit()
print('regional 2SLS (statsmodels):', iv.params[1])
fs = IV2SLS(sw * xv, np.column_stack([sw, sw * zv]) , np.column_stack([sw, sw * zv])).fit()
print('regional first stage (OLS, statsmodels):', fs.params[1])

# Industry-level: rebuild with pandas independently
m = df.merge(reg[['e', 'y', 'x', 'z']].rename(columns={'y': 'yr', 'x': 'xr', 'z': 'zr'}), left_on='region_id', right_index=True)
for c in ['yr', 'xr', 'zr']:
    m[c + 'c'] = m[c] - np.sum(reg['e'] * reg[{'yr': 'y', 'xr': 'x', 'zr': 'z'}[c]])
m['ep'] = m.e * m.share
g = m.groupby('industry_id')
s = g['ep'].sum()
shock = g['shock'].first()
ybar = g.apply(lambda d: (d.ep * d.yrc).sum() / d.ep.sum(), include_groups=False)
xbar = g.apply(lambda d: (d.ep * d.xrc).sum() / d.ep.sum(), include_groups=False)
zbar = g.apply(lambda d: (d.ep * d.zrc).sum() / d.ep.sum(), include_groups=False)
N = len(s)
print('N industries:', N, 'sum s:', s.sum())

def manual_iv_sw(dep, endo, inst, w):
    rw = np.sqrt(w)
    Xo = np.column_stack([np.ones(N), endo])
    Zo = np.column_stack([np.ones(N), inst])
    Xt, Zt, yt = Xo * rw[:, None], Zo * rw[:, None], dep * rw
    PZ = Zt @ np.linalg.inv(Zt.T @ Zt) @ Zt.T
    A = np.linalg.inv(Xt.T @ PZ @ Xt)
    b = A @ (Xt.T @ PZ @ yt)
    u = dep - Xo @ b
    ut = rw * u
    bread = A @ Xt.T @ PZ
    meat = (bread * ut[None, :] ** 2) @ bread.T
    cov = (N / (N - 2)) * meat
    return b[1], np.sqrt(cov[1, 1])

eff_b, eff_se = manual_iv_sw(ybar.to_numpy(), xbar.to_numpy(), shock.to_numpy(), s.to_numpy())
fs_b, fs_se = manual_iv_sw(xbar.to_numpy(), zbar.to_numpy(), shock.to_numpy(), s.to_numpy())
print('shock-level effect (independent):', eff_b, eff_se)
print('shock-level first stage (independent):', fs_b, fs_se)
print('effective shocks (independent):', 1 / np.sum(s.to_numpy() ** 2))

out = json.load(open('result.json'))
est = {e['term']: e for e in out['estimates']}
checks = {
    'effect_estimate': abs(est['effect']['estimate'] - eff_b),
    'effect_se': abs(est['effect']['se'] - eff_se),
    'first_stage_estimate': abs(est['first_stage']['estimate'] - fs_b),
    'first_stage_se': abs(est['first_stage']['se'] - fs_se),
    'regional_effect_vs_statsmodels': abs(est['effect']['estimate'] - iv.params[1]),
}
for k, v in checks.items():
    print(f'{k}: abs diff {v:.3e}')
    assert v < 1e-8, k
print('ALL CHECKS PASSED')
