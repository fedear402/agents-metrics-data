import numpy as np, pandas as pd, statsmodels.api as sm, json

df = pd.read_csv("input.csv")
s = df.score.to_numpy(); d = df.participated.to_numpy(float); y = df.earnings.to_numpy()
m = np.abs(s) < 1
s, d, y, ids = s[m], d[m], y[m], df.id.to_numpy()[m]
w = 1 - np.abs(s)
D = (s >= 0).astype(float)
X = np.column_stack([np.ones_like(s), D, s, D * s])

# Check 1: full-interaction WLS with HC0 for each outcome separately
res = {}
for name, yy in [("rf", y), ("fs", d)]:
    f = sm.WLS(yy, X, weights=w).fit(cov_type="HC0")
    res[name] = (f.params[1], f.bse[1])
    print(name, "statsmodels jump", f.params[1], "se", f.bse[1])

# Check 2: stacked regression, clustered by id without df correction -> includes cross-covariance
Xs = np.vstack([np.column_stack([X, np.zeros_like(X)]), np.column_stack([np.zeros_like(X), X])])
ys = np.concatenate([y, d]); ws = np.concatenate([w, w])
eq = np.concatenate([np.zeros(len(y)), np.ones(len(d))])
g = np.concatenate([ids, ids])
fit = sm.WLS(ys, Xs, weights=ws).fit(cov_type="cluster", cov_kwds={"groups": g, "use_correction": False})
# indices: rf jump = col 1, fs jump = col 5
b = fit.params; V = fit.cov_params()
rf, fs = b[1], b[5 + 1 - 1 + 0] if False else b[X.shape[1] + 1]
cov = V[np.ix_([1, X.shape[1] + 1], [1, X.shape[1] + 1])]
print("stacked rf", rf, "fs", fs, "cov", cov[0, 1])
tau = rf / fs
grad = np.array([1 / fs, -rf / fs**2])
print("stacked tau", tau, "se", np.sqrt(grad @ cov @ grad))

out = json.load(open("result.json"))
print("result.json:", [(e["term"], e["estimate"], e["se"], e["n_obs"]) for e in out["estimates"]])
print("n inside:", len(y), "left:", (s < 0).sum(), "right:", (s >= 0).sum())
