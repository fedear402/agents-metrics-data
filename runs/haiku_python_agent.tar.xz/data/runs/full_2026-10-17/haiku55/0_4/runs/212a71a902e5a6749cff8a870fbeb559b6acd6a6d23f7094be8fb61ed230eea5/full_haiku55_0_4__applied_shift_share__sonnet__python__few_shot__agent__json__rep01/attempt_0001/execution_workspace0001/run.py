import json
import numpy as np
import pandas as pd

df = pd.read_csv('input.csv')
reg = df.groupby('region_id').agg(region_weight=('region_weight', 'first'),
                                  x=('x', 'first'), y=('y', 'first')).sort_index()
shares = df.pivot(index='region_id', columns='industry_id', values='share').loc[reg.index]
shock = df.groupby('industry_id')['shock'].first().loc[shares.columns].values
S = shares.values

e = reg['region_weight'].values
e = e / e.sum()
X, Y = reg['x'].values, reg['y'].values
Z = S @ shock

def dm(v):
    return v - e @ v

x0, y0, z0 = dm(X), dm(Y), dm(Z)

s = e @ S
N = len(s)
def agg(v0):
    return (S.T @ (e * v0)) / s

ybar, xbar, zbar = agg(y0), agg(x0), agg(z0)

def shock_iv(dep, endog, w, shk):
    Xr = np.column_stack([np.ones(N), endog])
    Zi = np.column_stack([np.ones(N), shk])
    cross = Zi.T @ (w[:, None] * Xr)
    beta = np.linalg.solve(cross, Zi.T @ (w * dep))
    resid = dep - Xr @ beta
    scores = Zi * (w * resid)[:, None]
    inv = np.linalg.inv(cross)
    hc1 = N / (N - 2)
    V = hc1 * inv @ (scores.T @ scores) @ inv.T
    return float(beta[1]), float(np.sqrt(V[1, 1]))

effect, effect_se = shock_iv(ybar, xbar, s, shock)
first_shock, first_se = shock_iv(xbar, zbar, s, shock)

first_stage = float(np.sum(e * z0 * x0) / np.sum(e * z0 ** 2))
effect_reg = float(np.sum(e * z0 * y0) / np.sum(e * z0 * x0))
assert np.isclose(effect, effect_reg, rtol=1e-8, atol=1e-10)
assert np.isclose(first_shock, first_stage, rtol=1e-8, atol=1e-10)

effective = float(1 / np.sum(s ** 2))

out = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": effect_reg, "se": effect_se, "n_obs": N},
        {"term": "first_stage", "estimate": first_stage, "se": first_se, "n_obs": N},
        {"term": "effective_shocks", "estimate": effective, "se": None, "n_obs": N},
    ],
    "method_metadata": {
        "estimator": "Weighted 2SLS of y on intercept and x, instrumented by z (regional), region weights normalized once; shock-level BHJ aggregation equivalence",
        "vcov": "Shock-level weighted IV, HC1 (N/(N-2)) robust, industries as independent units, no clustering",
    },
    "diagnostics": {
        "n_regions": int(len(e)),
        "n_industries": int(N),
        "weights_sum": float(e.sum()),
        "share_row_sum_max_dev": float(np.max(np.abs(S.sum(axis=1) - 1))),
    },
}
with open('result.json', 'w') as f:
    json.dump(out, f, indent=2, allow_nan=False)
print(json.dumps(out, indent=2))
