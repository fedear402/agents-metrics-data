import json
import numpy as np
import pandas as pd

crosswalk = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv")
areas = pd.read_csv("areas.csv")
emp = pd.read_csv("employment.csv")
outcomes = pd.read_csv("outcomes.csv")

industries = sorted(crosswalk["industry"].unique())
assert len(industries) == 4

trade = trade.merge(crosswalk, on="code", how="left", validate="many_to_one")
assert trade["industry"].notna().all()

area_periods = outcomes[["area", "period"]].drop_duplicates().sort_values(["period", "area"]).reset_index(drop=True)
assert len(area_periods) == 72

grid = pd.MultiIndex.from_product(
    [sorted(areas["area"].unique()), sorted(areas["period"].unique()), ["base", "early"], industries],
    names=["area", "period", "vintage", "industry"],
)
emp_full = (
    emp.groupby(["area", "period", "vintage", "industry"])["employment"].sum()
    .reindex(grid, fill_value=0)
    .rename("employment")
    .reset_index()
)

tot = areas.set_index(["area", "period", "vintage"])["total_employment"]
pop = areas[areas["vintage"] == "base"].set_index(["area", "period"])["population"]

tr = trade.set_index(["period", "industry"])


def build(prefix_vintage, change_col):
    e = emp_full[emp_full["vintage"] == prefix_vintage].set_index(["area", "period", "industry"])["employment"]
    nat = e.groupby(level=["period", "industry"]).sum()
    rows = []
    for a, p in area_periods.itertuples(index=False):
        total = tot.loc[(a, p, prefix_vintage)]
        t = tr.loc[(p,)]
        val = 0.0
        for j in industries:
            share = e.loc[(a, p, j)] / total
            nat_j = nat.loc[(p, j)]
            row = tr.loc[(p, j)]
            val += share * (row[change_col] / nat_j) / (row["price_index"] / 100) / 1000 * (10 / row["years"])
        rows.append(val)
    return np.array(rows)


x = build("base", "us_change")
z = build("early", "other_change")

df = area_periods.copy()
df["change_pp"] = outcomes.set_index(["area", "period"]).loc[list(map(tuple, area_periods.values)), "change_pp"].values
df["control"] = outcomes.set_index(["area", "period"]).loc[list(map(tuple, area_periods.values)), "control"].values
df["x"] = x
df["z"] = z
df["w"] = pop.loc[list(map(tuple, area_periods.values))].values
n = len(df)

y = df["change_pp"].values
X_end = df["x"].values.reshape(-1, 1)
W_exog = np.column_stack([np.ones(n), df["period"].values, df["control"].values])
Z = np.column_stack([W_exog, df["z"].values])
X = np.column_stack([W_exog, X_end])
w_sqrt = np.sqrt(df["w"].values)

ys = y * w_sqrt
Xs = X * w_sqrt[:, None]
Zs = Z * w_sqrt[:, None]
PZ = Zs @ np.linalg.pinv(Zs.T @ Zs) @ Zs.T
beta = np.linalg.solve(Xs.T @ PZ @ Xs, Xs.T @ PZ @ ys)
iv_slope = float(beta[-1])

# Independent check: Frisch-Waugh-Lovell partialling out exogenous columns
def wls_resid(v, C, w):
    sw = np.sqrt(w)
    coef = np.linalg.lstsq(C * sw[:, None], v * sw, rcond=None)[0]
    return v - C @ coef

w = df["w"].values
xt = wls_resid(df["x"].values, W_exog, w)
zt = wls_resid(df["z"].values, W_exog, w)
yt = wls_resid(y, W_exog, w)
fwl_slope = float((zt * w) @ yt / ((zt * w) @ xt))

def exposure(a, p):
    return float(df[(df["area"] == a) & (df["period"] == p)]["x"].iloc[0])

def instrument(a, p):
    return float(df[(df["area"] == a) & (df["period"] == p)]["z"].iloc[0])

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [
        {"term": "iv_slope", "estimate": iv_slope, "se": None, "n_obs": n},
        {"term": "exposure_area0_period0", "estimate": exposure(0, 0), "se": None, "n_obs": n},
        {"term": "exposure_area0_period1", "estimate": exposure(0, 1), "se": None, "n_obs": n},
        {"term": "instrument_area0_period0", "estimate": instrument(0, 0), "se": None, "n_obs": n},
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "outcome": "change_pp",
        "exogenous": ["intercept", "period", "control"],
        "endogenous": ["x"],
        "instruments": ["z"],
        "weight": "base-vintage population",
        "exposure_units": "thousands of real dollars per worker per decade",
    },
    "diagnostics": {
        "n_obs": n,
        "fwl_iv_slope": fwl_slope,
        "fwl_abs_diff": abs(fwl_slope - iv_slope),
        "first_stage_corr_x_z": float(np.corrcoef(df["x"], df["z"])[0, 1]),
        "industries": [int(i) for i in industries],
    },
}
with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))
