import json
import numpy as np
import pandas as pd

h = pd.read_csv("households.csv")
c = pd.read_csv("census.csv")

s = h[h["recipient"] == 0].copy()
e = s["eligible"].to_numpy(float)
ne = 1.0 - e
dose = s["dose"].to_numpy(float)
base = s["baseline"].to_numpy(float)
inst = s["instrument"].to_numpy(float)
w = s["weight"].to_numpy(float)
y = s["outcome"].to_numpy(float)

X = np.column_stack([dose * ne, dose * e, ne, e, base * ne, base * e])
Z = np.column_stack([ne, e, base * ne, base * e, inst * ne, inst * e])

ZW = Z * w[:, None]
A = X.T @ ZW
b = ZW.T @ y
Pz = np.linalg.inv(Z.T @ ZW)
beta = np.linalg.solve(A @ Pz @ A.T, A @ Pz @ b)

slope_ineligible, slope_eligible = beta[0], beta[1]
mean_dose_ne = np.sum(w[ne == 1] * dose[ne == 1]) / np.sum(w[ne == 1])
mean_dose_e = np.sum(w[e == 1] * dose[e == 1]) / np.sum(w[e == 1])
ineligible_effect = slope_ineligible * mean_dose_ne
eligible_effect = slope_eligible * mean_dose_e

n0 = float(c.loc[c["eligible"] == 0, "nonrecipient_population"].iloc[0])
n1 = float(c.loc[c["eligible"] == 1, "nonrecipient_population"].iloc[0])
population_effect = (n0 * ineligible_effect + n1 * eligible_effect) / (n0 + n1)

n_obs = int(len(s))
out = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {"term": "ineligible_effect", "estimate": float(ineligible_effect), "se": None, "n_obs": n_obs},
        {"term": "eligible_nonrecipient_effect", "estimate": float(eligible_effect), "se": None, "n_obs": n_obs},
        {"term": "population_effect", "estimate": float(population_effect), "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS, exactly identified (6 instruments, 6 regressors, no intercept)",
        "regression_weight": "weight",
        "sample": "households with recipient == 0 (both village treatment statuses)",
        "counterfactual": "dose set to zero for every retained household (synthetic attribution convention)",
        "group_weights": "census nonrecipient_population (final aggregation only)",
    },
    "diagnostics": {
        "n_ineligible": int(np.sum(ne == 1)),
        "n_eligible": int(np.sum(e == 1)),
        "dose_slope_ineligible": float(slope_ineligible),
        "dose_slope_eligible": float(slope_eligible),
        "weighted_mean_dose_ineligible": float(mean_dose_ne),
        "weighted_mean_dose_eligible": float(mean_dose_e),
        "census_population_ineligible": n0,
        "census_population_eligible": n1,
    },
}
with open("result.json", "w") as f:
    json.dump(out, f, indent=2)
print(json.dumps(out, indent=2))
