import json
import numpy as np
import pandas as pd

df = pd.read_csv('input.csv')
reg = df.groupby('region_id').agg(region_weight=('region_weight', 'first'),
                                  x=('x', 'first'), y=('y', 'first'))
z = (df.assign(sx=df['share'] * df['shock'])
       .groupby('region_id')['sx'].sum())
reg['z'] = z
e = reg['region_weight'] / reg['region_weight'].sum()
reg['e'] = e

def wmean(v):
    return float(np.sum(reg['e'] * reg[v]))

for v in ['y', 'x', 'z']:
    reg[v + '0'] = reg[v] - wmean(v)

w = df.assign(e=df['region_id'].map(reg['e']))
s = w.assign(es=w['e'] * w['share']).groupby('industry_id')['es'].sum()
shock = df.groupby('industry_id')['shock'].first()
shock = shock.loc[s.index]

def agg(v0):
    tmp = w.assign(num=w['e'] * w['share'] * w['region_id'].map(reg[v0]))
    num = tmp.groupby('industry_id')['num'].sum()
    return (num / s).loc[s.index].values

ybar = agg('y0')
xbar = agg('x0')
zbar = agg('z0')
sv = s.values
shk = shock.values
N = len(sv)

def shock_iv(dep, endog, instr_col):
    X = np.column_stack([np.ones(N), endog])
    Z = np.column_stack([np.ones(N), instr_col])
    cross = Z.T @ (sv[:, None] * X)
    beta = np.linalg.solve(cross, Z.T @ (sv * dep))
    u = dep - X @ beta
    scores = Z * (sv * u)[:, None]
    inv = np.linalg.inv(cross)
    hc1 = N / (N - 2)
    V = hc1 * inv @ (scores.T @ scores) @ inv.T
    return float(beta[1]), float(np.sqrt(V[1, 1]))

effect, effect_se = shock_iv(ybar, xbar, shk)
fs, fs_se = shock_iv(xbar, zbar, shk)
eff_shocks = float(1.0 / np.sum(sv ** 2))

# Regional cross-checks
ew = reg['e'].values
x0, y0, z0 = reg['x0'].values, reg['y0'].values, reg['z0'].values
reg_2sls = np.sum(ew * z0 * y0) / np.sum(ew * z0 * x0)
reg_fs = np.sum(ew * z0 * x0) / np.sum(ew * z0 ** 2)
assert np.allclose([effect, fs], [reg_2sls, reg_fs], rtol=1e-8, atol=1e-10), (effect, reg_2sls, fs, reg_fs)

out = {
    'task_id': 'applied_shift_share',
    'platform': 'python',
    'estimates': [
        {'term': 'effect', 'estimate': effect, 'se': effect_se, 'n_obs': N},
        {'term': 'first_stage', 'estimate': fs, 'se': fs_se, 'n_obs': N},
        {'term': 'effective_shocks', 'estimate': eff_shocks, 'se': None, 'n_obs': N},
    ],
    'method_metadata': {
        'estimator': 'Regional weighted 2SLS of y on x instrumented by z; shock-level weighted IV (BHJ) for inference',
        'vcov': 'Shock-level HC1 robust (N/(N-2)), structural residuals, analytic weights s_n, no clustering',
    },
    'diagnostics': {
        'n_regions': int(len(reg)),
        'n_industries': int(N),
        'regional_2sls_check': float(reg_2sls),
        'regional_first_stage_check': float(reg_fs),
    },
}
with open('result.json', 'w') as f:
    json.dump(out, f, indent=2, allow_nan=False)
