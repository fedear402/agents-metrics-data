import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

data = pd.read_csv("input.csv")
data["date"] = pd.to_datetime(data["date"])
data = data.sort_values("date").reset_index(drop=True)
data["dlvix"] = np.log(data["vix"]).diff()
L = 15
for k in range(1, L + 1):
    data[f"lag_{k}"] = data["dlvix"].shift(k)
data["log_sales"] = np.log(data["sales"])
sample = data.dropna(subset=["log_sales"] + [f"lag_{k}" for k in range(1, L + 1)])
N = len(sample)
lag_cols = [f"lag_{k}" for k in range(1, L + 1)]
X = np.column_stack([np.ones(N), sample[lag_cols].to_numpy()])
y = sample["log_sales"].to_numpy()
beta = np.linalg.lstsq(X, y, rcond=None)[0]
resid = y - X @ beta

scores = X * resid[:, None]
meat = scores.T @ scores
for j in range(1, L + 1):
    w = 1 - j / (L + 1)
    G = scores[j:].T @ scores[:-j]
    meat += w * (G + G.T)
bread = np.linalg.inv(X.T @ X)
p = X.shape[1]
V = (N / (N - p)) * bread @ meat @ bread

c = np.zeros(p)
c[1:] = 1.0
cum = float(c @ beta)
cum_se = float(np.sqrt(c @ V @ c))

def row(term, est, se):
    return {"term": term, "estimate": float(est), "se": float(se), "n_obs": int(N)}

output = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        row("cumulative_response", cum, cum_se),
        row("lag_1", beta[1], np.sqrt(V[1, 1])),
        row("lag_15", beta[L], np.sqrt(V[L, L])),
    ],
    "method_metadata": {
        "estimator": "OLS of log(sales) on intercept and lags 1-15 of first difference of log(vix)",
        "vcov": "Newey-West HAC, maxlags=15, Bartlett weights 1-j/16, scaled by N/(N-16)",
    },
    "diagnostics": {
        "N": int(N),
        "first_obs_date": sample["date"].iloc[0].strftime("%Y-%m-%d"),
        "last_obs_date": sample["date"].iloc[-1].strftime("%Y-%m-%d"),
    },
}
with open("result.json", "w") as f:
    json.dump(output, f, indent=2, allow_nan=False)
print(json.dumps(output["estimates"], indent=2))
print("N =", N)
