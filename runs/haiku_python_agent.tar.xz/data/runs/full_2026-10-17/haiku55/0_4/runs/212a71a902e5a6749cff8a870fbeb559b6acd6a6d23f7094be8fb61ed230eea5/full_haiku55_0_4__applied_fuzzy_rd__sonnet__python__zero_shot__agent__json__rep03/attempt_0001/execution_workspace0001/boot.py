import numpy as np, pandas as pd
df = pd.read_csv("input.csv")
df = df[df.score.abs() < 1].reset_index(drop=True)
s = df.score.values; d = df.participated.values.astype(float); y = df.earnings.values
R = (s >= 0); w = 1 - np.abs(s)

def est(idx):
    out = []
    for side in [R, ~R]:
        m = side[idx]
        x = s[idx][m]; ww = w[idx][m]
        X = np.column_stack([np.ones_like(x), x])
        A = np.linalg.solve(X.T @ (X*ww[:,None]), X.T)
        out.append((A @ (ww*y[idx][m]))[0]); out.append((A @ (ww*d[idx][m]))[0])
    rf = out[0]-out[2]; fs = out[1]-out[3]
    return rf/fs

rng = np.random.default_rng(1)
n = len(s)
bs = np.array([est(rng.integers(0, n, n)) for _ in range(2000)])
print("bootstrap sd of treatment_effect:", bs.std(ddof=1))
print("bootstrap 2.5/97.5%:", np.percentile(bs, [2.5, 97.5]))

def parts(idx):
    out = []
    for side in [R, ~R]:
        m = side[idx]
        x = s[idx][m]; ww = w[idx][m]
        X = np.column_stack([np.ones_like(x), x])
        A = np.linalg.solve(X.T @ (X*ww[:,None]), X.T)
        out.append((A @ (ww*y[idx][m]))[0]); out.append((A @ (ww*d[idx][m]))[0])
    return out[0]-out[2], out[1]-out[3]

P = np.array([parts(rng.integers(0, n, n)) for _ in range(2000)])
print("bootstrap sd rf:", P[:,0].std(ddof=1), " analytic 0.2245347")
print("bootstrap sd fs:", P[:,1].std(ddof=1), " analytic 0.0805757")
print("bootstrap corr(rf,fs):", np.corrcoef(P[:,0], P[:,1])[0,1])
q = np.percentile(bs, [25, 75]); print("bootstrap IQR-based sd of ratio:", (q[1]-q[0])/1.349)
