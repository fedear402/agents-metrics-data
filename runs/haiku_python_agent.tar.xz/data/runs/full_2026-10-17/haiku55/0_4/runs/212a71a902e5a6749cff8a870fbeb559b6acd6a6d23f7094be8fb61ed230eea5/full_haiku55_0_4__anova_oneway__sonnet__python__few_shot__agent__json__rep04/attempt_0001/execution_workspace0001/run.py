import json
import pandas as pd
from scipy import stats
import statsmodels.formula.api as smf
from statsmodels.stats.anova import anova_lm

df = pd.read_csv("./input.csv").dropna(subset=["group", "y"])
df["group"] = df["group"].astype(str)
n = len(df)
k = df["group"].nunique()

model = smf.ols("y ~ C(group)", data=df).fit()
table = anova_lm(model, typ=1)
F = float(table.loc["C(group)", "F"])
df_num = float(table.loc["C(group)", "df"])
df_den = float(table.loc["Residual", "df"])
p_value = float(table.loc["C(group)", "PR(>F)"])

out = {
    "task_id": "anova_oneway",
    "platform": "python",
    "estimates": [
        {"term": "F", "estimate": F, "se": None, "n_obs": n},
        {"term": "df_num", "estimate": df_num, "se": None, "n_obs": n},
        {"term": "df_den", "estimate": df_den, "se": None, "n_obs": n},
        {"term": "p_value", "estimate": p_value, "se": None, "n_obs": n},
    ],
    "method_metadata": {"estimator": "One-way ANOVA (OLS on group dummies, Type I SS)",
                        "vcov": "none"},
    "diagnostics": {"n_groups": int(k)},
}
with open("result.json", "w") as f:
    json.dump(out, f)
