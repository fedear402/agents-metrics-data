dat <- read.csv("input.csv", stringsAsFactors = FALSE)

## One observation per region defines the regional sample and its normalized weight.
reg <- dat[!duplicated(dat$region_id), c("region_id", "region_weight", "x", "y")]
reg$e <- reg$region_weight / sum(reg$region_weight)

## Shift-share instrument, using every region-industry row.
dat$zpart <- dat$share * dat$shock
zreg <- aggregate(zpart ~ region_id, dat, sum)
reg <- merge(reg, zreg, by = "region_id", sort = FALSE)
reg$z <- reg$zpart
reg$y0 <- reg$y - sum(reg$e * reg$y)
reg$x0 <- reg$x - sum(reg$e * reg$x)
reg$z0 <- reg$z - sum(reg$e * reg$z)

## Industry exposure weights and exposure-weighted regional residual averages.
sdat <- aggregate(cbind(s = reg$e[match(dat$region_id, reg$region_id)] * dat$share,
                         ynum = reg$e[match(dat$region_id, reg$region_id)] * dat$share * reg$y0[match(dat$region_id, reg$region_id)],
                         xnum = reg$e[match(dat$region_id, reg$region_id)] * dat$share * reg$x0[match(dat$region_id, reg$region_id)],
                         znum = reg$e[match(dat$region_id, reg$region_id)] * dat$share * reg$z0[match(dat$region_id, reg$region_id)]),
                  by = list(industry_id = dat$industry_id), sum)
ishock <- aggregate(shock ~ industry_id, dat, function(v) v[1])
sh <- merge(sdat, ishock, by = "industry_id")
sh <- sh[sh$s > 0, ]
sh$ybar <- sh$ynum / sh$s
sh$xbar <- sh$xnum / sh$s
sh$zbar <- sh$znum / sh$s

iv_robust <- function(y, endog, instr, w) {
  X <- cbind(1, endog); Z <- cbind(1, instr)
  sw <- sqrt(w)
  Xw <- X * sw; Zw <- Z * sw; yw <- y * sw
  H <- crossprod(Zw); G <- crossprod(Zw, Xw)
  beta <- solve(crossprod(G, solve(H, G)), crossprod(G, solve(H, crossprod(Zw, yw))))
  u <- as.vector(y - X %*% beta)
  bread <- solve(crossprod(G, solve(H, G)))
  meat0 <- matrix(0, ncol(Z), ncol(Z))
  for (i in seq_along(u)) meat0 <- meat0 + w[i] * u[i]^2 * tcrossprod(Z[i, ])
  meat <- t(G) %*% solve(H) %*% meat0 %*% solve(H) %*% G
  vc <- bread %*% meat %*% bread * nrow(X) / (nrow(X) - ncol(X))
  c(beta = beta[2], se = sqrt(vc[2, 2]))
}

eff <- iv_robust(sh$ybar, sh$xbar, sh$shock, sh$s)
fst <- iv_robust(sh$xbar, sh$zbar, sh$shock, sh$s)
effective_shocks <- 1 / sum(sh$s^2)
n <- nrow(sh)

out <- list(task_id = "applied_shift_share", platform = "r",
            estimates = list(
              list(term = "effect", estimate = unname(eff["beta"]), se = unname(eff["se"]), n_obs = n),
              list(term = "first_stage", estimate = unname(fst["beta"]), se = unname(fst["se"]), n_obs = n),
              list(term = "effective_shocks", estimate = effective_shocks, se = NULL, n_obs = n)),
            method_metadata = list(estimator = "shock-level weighted 2SLS", vcov = "heteroskedasticity-robust HC1, structural IV residuals, analytic weights"),
            diagnostics = list())
json_escape <- function(x) { paste0('{"task_id":"', x$task_id, '","platform":"r","estimates":[',
  paste(sapply(x$estimates, function(a) sprintf('{"term":"%s","estimate":%.15g,"se":%s,"n_obs":%d}', a$term, a$estimate, ifelse(is.null(a$se), "null", sprintf("%.15g", a$se)), a$n_obs)), collapse=","),
  '],"method_metadata":{"estimator":"shock-level weighted 2SLS","vcov":"heteroskedasticity-robust HC1, structural IV residuals, analytic weights"},"diagnostics":{}}') }
writeLines(json_escape(out), "result.json")

## Independent check: regional weighted 2SLS using the direct matrix formula.
X <- cbind(1, reg$x); Z <- cbind(1, reg$z); W <- diag(reg$e)
breg <- solve(t(X)%*%W%*%Z%*%solve(t(Z)%*%W%*%Z)%*%t(Z)%*%W%*%X,
              t(X)%*%W%*%Z%*%solve(t(Z)%*%W%*%Z)%*%t(Z)%*%W%*%reg$y)
share_sums <- aggregate(share ~ region_id, dat, sum)$share
writeLines(sprintf("regions=%d\nindustries=%d\nnormalized_weight_sum=%0.15g\nmax_share_sum_error=%0.5g\neffect_shock=%0.15g\neffect_regional=%0.15g\nidentity_difference=%0.5g\nfirst_stage=%0.15g\neffective_shocks=%0.15g", nrow(reg), n, sum(reg$e), max(abs(share_sums - 1)), eff["beta"], breg[2], eff["beta"]-breg[2], fst["beta"], effective_shocks), "verification.txt")
