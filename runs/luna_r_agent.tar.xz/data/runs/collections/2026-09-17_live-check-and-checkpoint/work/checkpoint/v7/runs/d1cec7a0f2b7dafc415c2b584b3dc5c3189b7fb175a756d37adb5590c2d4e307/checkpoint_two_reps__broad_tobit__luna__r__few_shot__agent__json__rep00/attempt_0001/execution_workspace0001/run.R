dat <- read.csv("input.csv", stringsAsFactors = FALSE)
stopifnot(all(c("id", "y", "x", "z") %in% names(dat)))
n <- nrow(dat)
stopifnot(n == 400L, all(dat$y >= 0), all(is.finite(as.matrix(dat[, c("y", "x", "z")] ))))

# Left-censored Gaussian Tobit: y=0 contributes P(Y* <= 0), y>0 contributes
# the Gaussian density.  survreg estimates beta and log(sigma) jointly.
fit <- survival::survreg(survival::Surv(y, y > 0, type = "left") ~ x + z,
                         data = dat, dist = "gaussian",
                         control = survival::survreg.control(rel.tolerance = 1e-12))
V <- vcov(fit)
beta <- coef(fit)
se <- sqrt(diag(V)[names(beta)])

# Independent numerical check: direct likelihood optimization in (beta, log sigma).
X <- cbind(1, dat$x, dat$z)
left <- dat$y == 0
nll <- function(par) {
  sig <- exp(par[4])
  eta <- drop(X %*% par[1:3])
  val <- sum(pnorm(-eta[left] / sig, log.p = TRUE))
  if (any(!left)) val <- val + sum(dnorm((dat$y[!left] - eta[!left]) / sig, log = TRUE) - log(sig))
  -val
}
op <- optim(c(unname(beta), log(fit$scale)), nll, method = "BFGS",
            hessian = TRUE, control = list(reltol = 1e-12, maxit = 10000))
stopifnot(op$convergence == 0L, max(abs(op$par[1:3] - unname(beta))) < 1e-6,
          abs(exp(op$par[4]) - fit$scale) < 1e-6)

out <- list(
  task_id = "broad_tobit", platform = "r",
  estimates = list(
    list(term = "const", estimate = unname(beta["(Intercept)"]), se = unname(se["(Intercept)"]), n_obs = n),
    list(term = "x", estimate = unname(beta["x"]), se = unname(se["x"]), n_obs = n),
    list(term = "z", estimate = unname(beta["z"]), se = unname(se["z"]), n_obs = n),
    list(term = "sigma", estimate = unname(fit$scale), se = NULL, n_obs = n)
  ),
  method_metadata = list(estimator = "Gaussian left-censored Tobit by maximum likelihood", vcov = "survreg observed information, joint beta and log(sigma) likelihood"),
  diagnostics = list(n_total = n, n_censored = sum(left), n_uncensored = sum(!left), direct_optim_convergence = op$convergence,
                     direct_loglik = -op$value, survreg_loglik = as.numeric(logLik(fit)))
)
jsonlite::write_json(out, "result.json", auto_unbox = TRUE, pretty = TRUE, digits = 16, null = "null")

# Plain-text audit record, including an independent likelihood check and the
# censored/uncensored sample accounting.
audit <- c(
  paste0("rows=", n, "; censored_y_zero=", sum(left), "; uncensored_y_positive=", sum(!left)),
  paste0("survreg_beta=", paste(format(unname(beta), digits=12), collapse=","), "; sigma=", format(fit$scale, digits=12)),
  paste0("direct_optim_beta=", paste(format(op$par[1:3], digits=12), collapse=","), "; sigma=", format(exp(op$par[4]), digits=12)),
  paste0("max_abs_beta_difference=", format(max(abs(op$par[1:3] - unname(beta))), digits=12)),
  paste0("sigma_difference=", format(abs(exp(op$par[4]) - fit$scale), digits=12)),
  paste0("loglik_difference=", format(abs((-op$value) - as.numeric(logLik(fit))), digits=12)),
  "check_status=PASS"
)
writeLines(audit, "verification.txt")
