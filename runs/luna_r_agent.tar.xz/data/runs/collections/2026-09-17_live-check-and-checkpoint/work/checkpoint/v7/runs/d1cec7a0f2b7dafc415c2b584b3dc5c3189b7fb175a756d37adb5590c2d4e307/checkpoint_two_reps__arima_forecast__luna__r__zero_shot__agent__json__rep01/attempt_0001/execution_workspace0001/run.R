dat <- read.csv("input.csv", stringsAsFactors = FALSE)
stopifnot(identical(names(dat), c("t", "y")))
stopifnot(nrow(dat) == 250L, all(dat$t == seq_len(nrow(dat))))
y <- as.numeric(dat$y)

# Exact maximum likelihood ARIMA(1,1,1), with no constant or drift.
fit <- stats::arima(y, order = c(1L, 1L, 1L), include.mean = FALSE,
                    method = "ML")
pr <- stats::predict(fit, n.ahead = 1L)
fc <- as.numeric(pr$pred[1L])
se <- as.numeric(pr$se[1L])
lo <- fc - stats::qnorm(0.975) * se
hi <- fc + stats::qnorm(0.975) * se

# Independent numerical checks: the interval identity and a second forecast
# implementation, when the common forecast package is available.
stopifnot(is.finite(fc), is.finite(se), se > 0)
stopifnot(all.equal(lo, fc - qnorm(0.975) * se, tolerance = 1e-12))
stopifnot(all.equal(hi, fc + qnorm(0.975) * se, tolerance = 1e-12))
if (requireNamespace("forecast", quietly = TRUE)) {
  fc2 <- as.numeric(forecast::forecast(fit, h = 1L)$mean[1L])
  stopifnot(all.equal(fc, fc2, tolerance = 1e-8))
}

fmt <- function(x) formatC(x, digits = 17, format = "fg", flag = "#")
result <- paste0(
  '{"task_id":"arima_forecast","platform":"r","estimates":[',
  '{"term":"forecast","estimate":', fmt(fc), ',"se":', fmt(se), ',"n_obs":250},',
  '{"term":"lower_95","estimate":', fmt(lo), ',"se":null,"n_obs":250},',
  '{"term":"upper_95","estimate":', fmt(hi), ',"se":null,"n_obs":250}',
  '],"method_metadata":{"estimator":"Gaussian maximum likelihood ARIMA(1,1,1), no constant or drift","vcov":"model-based one-step prediction variance"},"diagnostics":{}}'
)
writeLines(result, "result.json")
