dat <- read.csv("input.csv", stringsAsFactors = FALSE)

required <- c("firm", "year", "cohort", "y_did")
stopifnot(all(required %in% names(dat)))
stopifnot(nrow(dat) == 2000L)
stopifnot(length(unique(dat$firm)) == 200L)
stopifnot(all(table(dat$firm) == 10L))
stopifnot(setequal(unique(dat$year), 0:9))
stopifnot(all(unique(dat$cohort) %in% c(-1, 4, 6, 8)))

treated_cohorts <- c(4L, 6L, 8L)
never <- dat$cohort == -1L
cell_effects <- numeric(0)

for (g in treated_cohorts) {
  baseline <- dat$cohort == g & dat$year == (g - 1L)
  control_baseline <- never & dat$year == (g - 1L)
  stopifnot(sum(baseline) > 0L, sum(control_baseline) > 0L)
  for (tt in g:9L) {
    treated_post <- dat$cohort == g & dat$year == tt
    control_post <- never & dat$year == tt
    stopifnot(sum(treated_post) > 0L, sum(control_post) > 0L)
    treated_change <- mean(dat$y_did[treated_post]) - mean(dat$y_did[baseline])
    control_change <- mean(dat$y_did[control_post]) - mean(dat$y_did[control_baseline])
    cell_effects <- c(cell_effects, treated_change - control_change)
  }
}

att <- mean(cell_effects)
result <- list(
  task_id = "staggered_did",
  platform = "r",
  estimates = list(list(term = "att", estimate = unname(att), se = NULL,
                        n_obs = as.integer(nrow(dat)))),
  method_metadata = list(
    estimator = "Equal-weight ATT over supported cohort-year cells from group-year means",
    vcov = "None; standard error not requested"
  ),
  diagnostics = list()
)

if (!requireNamespace("jsonlite", quietly = TRUE)) stop("jsonlite is required")
jsonlite::write_json(result, "result.json", auto_unbox = TRUE, null = "null",
                     digits = 17, pretty = TRUE)
