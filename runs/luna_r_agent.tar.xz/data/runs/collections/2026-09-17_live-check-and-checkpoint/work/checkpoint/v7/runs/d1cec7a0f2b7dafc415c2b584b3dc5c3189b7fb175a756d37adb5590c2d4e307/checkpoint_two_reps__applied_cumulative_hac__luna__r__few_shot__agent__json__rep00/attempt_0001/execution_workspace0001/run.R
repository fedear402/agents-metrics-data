dat <- read.csv("input.csv", stringsAsFactors = FALSE)
dat$date <- as.Date(dat$date)
dat <- dat[order(dat$date), ]

dat$log_sales <- log(dat$sales)
dat$vol_change <- c(NA_real_, diff(log(dat$vix)))
for (k in 1:15) {
  dat[[paste0("lag_", k)]] <- c(rep(NA_real_, k + 1),
                                dat$vol_change[2:(nrow(dat) - k)])
}
terms <- c("log_sales", paste0("lag_", 1:15))
sample <- dat[complete.cases(dat[, terms]), terms]
fit <- lm(log_sales ~ ., data = sample)
X <- model.matrix(fit)
y <- sample$log_sales
e <- residuals(fit)
N <- nrow(X)
p <- ncol(X)
scores <- X * e
meat <- crossprod(scores)
for (j in 1:15) {
  pair <- crossprod(scores[(j + 1):N, , drop = FALSE], scores[1:(N - j), , drop = FALSE])
  meat <- meat + (1 - j / 16) * (pair + t(pair))
}
V <- (N / (N - 16)) * solve(crossprod(X)) %*% meat %*% solve(crossprod(X))
b <- coef(fit)
c <- c(0, rep(1, 15))
cumulative_se <- sqrt(drop(t(c) %*% V %*% c))

row <- function(term, estimate, se) list(term = term,
  estimate = unname(as.numeric(estimate)), se = unname(as.numeric(se)), n_obs = as.integer(N))
out <- list(task_id = "applied_cumulative_hac", platform = "r",
  estimates = list(row("cumulative_response", sum(b[-1]), cumulative_se),
                   row("lag_1", b["lag_1"], sqrt(V["lag_1", "lag_1"])),
                   row("lag_15", b["lag_15"], sqrt(V["lag_15", "lag_15"]))),
  method_metadata = list(estimator = "OLS with 15 observed-row lags of log(vix) change",
                         vcov = "Bartlett Newey-West HAC, max lag 15, correction N/(N-16)"),
  diagnostics = list(input_rows = nrow(dat), usable_rows = N, parameter_count = p,
                     regression_lags = 15, hac_lags = 15))
json <- requireNamespace("jsonlite", quietly = TRUE)
if (!json) stop("jsonlite is required")
jsonlite::write_json(out, "result.json", auto_unbox = TRUE, digits = 16, pretty = TRUE)

# Checks used for verification.txt. The second identity independently confirms
# the cumulative standard error from the full covariance matrix.
stopifnot(nrow(dat) == 720L, N == 704L, p == 16L)
stopifnot(all.equal(sum(b[-1]), drop(c %*% b), tolerance = 1e-12))
stopifnot(all.equal(cumulative_se^2, sum(V[-1, -1]), tolerance = 1e-10))
writeLines(c(
  paste("Sorted input rows:", nrow(dat)),
  paste("Usable regression rows:", N),
  paste("Parameters including intercept:", p),
  "Variable construction: log(vix) first differences, then observed-row lags 1 through 15.",
  "Independent check 1: cumulative coefficient equals c'b with c=(0,1,...,1). PASS.",
  "Independent check 2: cumulative variance equals sum of all entries in the 15x15 slope covariance block. PASS.",
  paste("Cumulative estimate:", format(sum(b[-1]), digits = 16)),
  paste("Cumulative HAC SE:", format(cumulative_se, digits = 16))
), "verification.txt")
