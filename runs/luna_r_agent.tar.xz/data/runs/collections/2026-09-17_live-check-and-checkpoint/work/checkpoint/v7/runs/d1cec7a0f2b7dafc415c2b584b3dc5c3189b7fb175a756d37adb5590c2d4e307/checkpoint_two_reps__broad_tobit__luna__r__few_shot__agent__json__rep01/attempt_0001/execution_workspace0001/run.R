dat <- read.csv("input.csv", stringsAsFactors = FALSE)
stopifnot(nrow(dat) == 400L, all(dat$y >= 0), all(c("id", "y", "x", "z") %in% names(dat)))
N <- nrow(dat)
if (!requireNamespace("survival", quietly = TRUE) || !requireNamespace("jsonlite", quietly = TRUE)) stop("Required packages are unavailable")

# y=0 is left censored. Positive y values are observed continuously.
fit <- survival::survreg(survival::Surv(y, y > 0, type = "left") ~ x + z,
  data = dat, dist = "gaussian", control = survival::survreg.control(rel.tolerance = 1e-12))
V <- stats::vcov(fit)
beta <- stats::coef(fit)
stopifnot(all(c("(Intercept)", "x", "z") %in% names(beta)))
stopifnot(min(eigen(V, symmetric = TRUE, only.values = TRUE)$values) > 0)

# Independent check: optimize the same censored-normal likelihood directly.
X <- cbind(1, dat$x, dat$z)
y <- dat$y
ll <- function(par) {
  sig <- exp(par[4]); eta <- drop(X %*% par[1:3]); unc <- y > 0
  sum(stats::dnorm((y[unc] - eta[unc]) / sig, log = TRUE) - log(sig)) +
    sum(stats::pnorm(-eta[!unc] / sig, log.p = TRUE))
}
chk <- stats::optim(c(unname(beta), log(fit$scale)), function(p) -ll(p),
  method = "BFGS", control = list(reltol = 1e-12))
if (max(abs(chk$par[1:3] - unname(beta))) > 1e-5 || abs(exp(chk$par[4]) - fit$scale) > 1e-5) stop("Independent likelihood check failed")

rows <- list(
  list(term = "const", estimate = unname(beta["(Intercept)"]), se = sqrt(V["(Intercept)", "(Intercept)"]), n_obs = N),
  list(term = "x", estimate = unname(beta["x"]), se = sqrt(V["x", "x"]), n_obs = N),
  list(term = "z", estimate = unname(beta["z"]), se = sqrt(V["z", "z"]), n_obs = N),
  list(term = "sigma", estimate = unname(fit$scale), se = NULL, n_obs = N))
out <- list(task_id = "broad_tobit", platform = "r", estimates = rows,
  method_metadata = list(estimator = "Gaussian Tobit maximum likelihood with left censoring at zero",
    vcov = "inverse observed information, jointly estimating beta and log(sigma)"),
  diagnostics = list(n_censored = sum(dat$y == 0), n_uncensored = sum(dat$y > 0),
    independent_likelihood_max_abs_diff = max(abs(chk$par - c(unname(beta), log(fit$scale))))))
jsonlite::write_json(out, "result.json", auto_unbox = TRUE, digits = 16, pretty = TRUE, null = "null")

writeLines(c(
  paste0("Rows checked: ", N), paste0("Censored observations (y=0): ", sum(dat$y == 0)),
  paste0("Uncensored observations (y>0): ", sum(dat$y > 0)),
  "Variable construction: Surv(y, y > 0, type='left') with formula y ~ x + z; intercept included.",
  "Independent check: direct censored-normal log-likelihood optimized over beta and log(sigma).",
  paste0("Maximum absolute parameter difference from survreg: ", format(max(abs(chk$par - c(unname(beta), log(fit$scale)))), digits = 12)),
  paste0("Observed-information covariance positive definite: ", min(eigen(V, symmetric = TRUE, only.values = TRUE)$values) > 0)),
  "verification.txt")
