d <- read.csv("input.csv", stringsAsFactors = FALSE)
stopifnot(nrow(d) == 480L, all(d$y %in% 0:2), all(complete.cases(d[, c("y", "x", "z")])) )
d$y <- factor(d$y, levels = 0:2)

fit <- nnet::multinom(y ~ x + z, data = d, Hess = TRUE, trace = FALSE,
                      maxit = 1000, reltol = 1e-12, abstol = 1e-12)
B <- coef(fit)
V <- vcov(fit)
stopifnot(identical(rownames(B), c("1", "2")))
terms <- c("x_cat1", "z_cat1", "x_cat2", "z_cat2")
est <- c(B["1", "x"], B["1", "z"], B["2", "x"], B["2", "z"])
se <- c(sqrt(V["1:x", "1:x"]), sqrt(V["1:z", "1:z"]),
        sqrt(V["2:x", "2:x"]), sqrt(V["2:z", "2:z"]))

at0 <- c(0, B["1", "(Intercept)"], B["2", "(Intercept)"])
pr <- exp(at0 - max(at0)); pr <- pr / sum(pr)
stopifnot(abs(sum(pr) - 1) < 1e-12)

rows <- lapply(seq_along(terms), function(i) list(term=terms[i], estimate=unname(est[i]),
  se=unname(se[i]), n_obs=as.integer(nrow(d))))
rows[[5]] <- list(term="prob_cat2_zero", estimate=unname(pr[3]), se=NULL,
                  n_obs=as.integer(nrow(d)))
out <- list(task_id="broad_multinomial_logit", platform="r", estimates=rows,
            method_metadata=list(estimator="multinomial logit maximum likelihood, outcome 0 base",
                                 vcov="conventional observed information (Hessian)"),
            diagnostics=jsonlite::fromJSON("{}"))
jsonlite::write_json(out, "result.json", auto_unbox=TRUE, null="null", digits=16, pretty=TRUE)

# Independent checks: direct softmax and score at the fitted coefficients.
eta <- cbind(0, model.matrix(~ x + z, d) %*% t(B))
pall <- exp(eta - apply(eta, 1, max)); pall <- pall / rowSums(pall)
direct0 <- exp(at0 - max(at0)); direct0 <- direct0 / sum(direct0)
Y <- sapply(0:2, function(k) as.integer(d$y == k))
score <- colSums((Y[, 2:3] - pall[, 2:3]) * 1) # intercept score
writeLines(c(
  sprintf("n_obs=%d; complete_cases=%d", nrow(d), sum(complete.cases(d[,c('y','x','z')]))),
  sprintf("coefficient_rows=%s", paste(rownames(B), collapse=",")),
  sprintf("softmax_sum_at_zero=%.16g", sum(direct0)),
  sprintf("prob_cat2_zero_result=%.16g; direct_softmax=%.16g; absolute_difference=%.3g", pr[3], direct0[3], abs(pr[3]-direct0[3])),
  sprintf("max_absolute_intercept_score=%.3g", max(abs(score)))
), "verification.txt")
