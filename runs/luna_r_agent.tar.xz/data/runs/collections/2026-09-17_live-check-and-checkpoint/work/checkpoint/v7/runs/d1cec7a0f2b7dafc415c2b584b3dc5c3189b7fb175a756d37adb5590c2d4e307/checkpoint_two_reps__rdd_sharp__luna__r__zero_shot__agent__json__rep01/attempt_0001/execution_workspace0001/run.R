dat <- read.csv("input.csv", stringsAsFactors = FALSE)

h <- 0.5
keep <- is.finite(dat$z) & is.finite(dat$y) & abs(dat$z) <= h
dat <- dat[keep, , drop = FALSE]
dat$w <- 1 - abs(dat$z) / h

fit_side <- function(x) {
  x <- x[x$w > 0, , drop = FALSE]
  fit <- lm(y ~ z, data = x, weights = w)
  list(fit = fit, n = nrow(x))
}

left <- fit_side(dat[dat$z < 0, , drop = FALSE])
right <- fit_side(dat[dat$z >= 0, , drop = FALSE])

## The conventional weighted-least-squares covariance is used.
beta_l <- coef(left$fit)
beta_r <- coef(right$fit)
vc_l <- vcov(left$fit)
vc_r <- vcov(right$fit)
estimate <- unname(beta_r[1] - beta_l[1])
se <- sqrt(unname(vc_r[1, 1] + vc_l[1, 1]))

out <- list(
  task_id = "rdd_sharp",
  platform = "r",
  estimates = list(list(term = "late", estimate = as.numeric(estimate),
                        se = as.numeric(se), n_obs = as.integer(nrow(dat)))),
  method_metadata = list(estimator = "local linear regression with triangular kernel weights, h=0.5, cutoff=0",
                         vcov = "conventional weighted-least-squares covariance"),
  diagnostics = list(n_left = as.integer(left$n), n_right = as.integer(right$n))
)

if (requireNamespace("jsonlite", quietly = TRUE)) {
  jsonlite::write_json(out, "result.json", auto_unbox = TRUE, pretty = TRUE, digits = 16)
} else {
  stop("jsonlite is required to write result.json")
}
