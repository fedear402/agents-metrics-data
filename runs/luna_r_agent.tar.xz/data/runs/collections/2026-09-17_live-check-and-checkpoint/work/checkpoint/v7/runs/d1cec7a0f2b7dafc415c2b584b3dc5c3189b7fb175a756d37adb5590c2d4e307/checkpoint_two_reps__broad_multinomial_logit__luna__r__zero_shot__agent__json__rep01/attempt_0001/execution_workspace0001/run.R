dat <- read.csv("input.csv", stringsAsFactors = FALSE)
stopifnot(nrow(dat) == 480L, all(dat$y %in% c(0, 1, 2)), all(is.finite(dat$x)), all(is.finite(dat$z)))
n <- nrow(dat)
X <- cbind(1, dat$x, dat$z)
y <- as.integer(dat$y)

loglik <- function(b) {
  B <- matrix(b, nrow = 3, ncol = 2)
  eta <- X %*% B
  den <- 1 + exp(eta[,1]) + exp(eta[,2])
  lp <- cbind(-log(den), eta[,1] - log(den), eta[,2] - log(den))
  sum(lp[cbind(seq_len(n), y + 1L)])
}
score <- function(b) {
  B <- matrix(b, nrow = 3, ncol = 2)
  eta <- X %*% B
  ee <- exp(eta)
  den <- 1 + rowSums(ee)
  P <- ee / den
  D <- cbind(y == 1L, y == 2L) - P
  as.vector(crossprod(X, D))
}
fit <- optim(rep(0, 6), function(b) -loglik(b), gr = function(b) -score(b), method = "BFGS", hessian = FALSE,
             control = list(reltol = 1e-12, maxit = 2000))
if (fit$convergence != 0) stop("optimization did not converge")
b <- fit$par

# Analytic observed information at the MLE.
B <- matrix(b, nrow = 3, ncol = 2)
eta <- X %*% B
ee <- exp(eta); den <- 1 + rowSums(ee); P <- ee / den
I <- matrix(0, 6, 6)
for (i in seq_len(n)) {
  q <- P[i, ]
  W <- diag(q) - tcrossprod(q)
  I <- I + kronecker(W, tcrossprod(X[i, ]))
}
V <- solve(I)
se <- sqrt(diag(V))

# Parameter vector is (intercept, x, z) for alternative 1, then alternative 2.
terms <- c("x_cat1", "z_cat1", "x_cat2", "z_cat2")
idx <- c(2L, 3L, 5L, 6L)
estimates <- lapply(seq_along(terms), function(j) list(term = terms[j], estimate = unname(b[idx[j]]),
                                                        se = unname(se[idx[j]]), n_obs = n))
p20 <- exp(b[4L]) / (1 + exp(b[1L]) + exp(b[4L]))
estimates[[5L]] <- list(term = "prob_cat2_zero", estimate = unname(p20), se = NULL, n_obs = n)
out <- list(task_id = "broad_multinomial_logit", platform = "r", estimates = estimates,
            method_metadata = list(estimator = "multinomial logit maximum likelihood, base outcome 0",
                                   vcov = "inverse analytic observed information"), diagnostics = list())
json_escape <- function(x) {
  if (is.null(x)) return("null")
  if (is.numeric(x)) return(format(x, digits = 17, scientific = FALSE, trim = TRUE))
  paste0('"', x, '"')
}
lines <- c('{', '  "task_id": "broad_multinomial_logit",', '  "platform": "r",', '  "estimates": [')
for (j in seq_along(estimates)) {
  e <- estimates[[j]]
  comma <- if (j < length(estimates)) "," else ""
  lines <- c(lines, sprintf('    {"term":"%s","estimate":%s,"se":%s,"n_obs":%d}%s',
                           e$term, json_escape(e$estimate), json_escape(e$se), e$n_obs, comma))
}
lines <- c(lines, '  ],', '  "method_metadata": {"estimator":"multinomial logit maximum likelihood, base outcome 0","vcov":"inverse analytic observed information"},', '  "diagnostics": {}', '}')
writeLines(lines, "result.json")

# Independent checks: score, probability identity, and numerical Hessian comparison.
numH <- optimHess(b, function(bb) -loglik(bb), gr = function(bb) -score(bb))
max_score <- max(abs(score(b)))
max_hess_diff <- max(abs(numH - I))
eta0 <- c(b[1L], b[4L])
p0 <- exp(eta0) / (1 + sum(exp(eta0)))
verification <- c(
  sprintf("Rows and estimation sample: n=%d; all %d rows used; y values are 0, 1, and 2.", n, n),
  sprintf("Optimization convergence code: %d; maximum absolute score at solution: %.3e.", fit$convergence, max_score),
  sprintf("Independent Hessian check: maximum absolute difference between analytic and optimHess information: %.3e.", max_hess_diff),
  sprintf("Probability identity check at x=z=0: p0=(%.15g, %.15g, %.15g), sum=%.15g.", 1-sum(p0), p0[1], p0[2], (1-sum(p0))+sum(p0)),
  sprintf("Reported probability check: prob_cat2_zero=%.15g; direct calculation=%.15g.", p20, p0[2]),
  "The model uses intercept, x, and z for alternatives 1 and 2, with outcome 0 as the base.",
  "Standard errors use the inverse analytic observed information at the maximum-likelihood estimate."
)
writeLines(verification, "verification.txt")
