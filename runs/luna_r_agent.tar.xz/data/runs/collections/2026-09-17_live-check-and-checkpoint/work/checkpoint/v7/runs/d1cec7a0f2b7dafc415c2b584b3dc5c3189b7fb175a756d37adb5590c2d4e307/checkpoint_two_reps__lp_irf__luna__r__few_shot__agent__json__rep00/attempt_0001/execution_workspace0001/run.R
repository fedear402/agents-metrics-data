library(jsonlite)
library(sandwich)

dat <- read.csv("input.csv", stringsAsFactors = FALSE)
stopifnot(all(c("t", "y", "shock") %in% names(dat)))
dat <- dat[order(dat$t), ]
n <- nrow(dat)

# The estimation sample has y[t+4], shock[t], and y[t-1] available.
idx <- 2:(n - 4)
est <- data.frame(
  y_h4 = dat$y[idx + 4],
  shock = dat$shock[idx],
  y_lag1 = dat$y[idx - 1]
)
fit <- lm(y_h4 ~ shock + y_lag1, data = est)

# Newey-West HAC covariance with Bartlett weights and lag 4.
nw <- sandwich::NeweyWest(fit, lag = 4, prewhite = FALSE, adjust = FALSE)
co <- coef(fit)
se <- sqrt(diag(nw))

out <- list(
  task_id = "lp_irf",
  platform = "r",
  estimates = list(list(
    term = "irf_h4",
    estimate = unname(co["shock"]),
    se = unname(se["shock"]),
    n_obs = nrow(est)
  )),
  method_metadata = list(
    estimator = "Local projection OLS: y[t+4] on shock[t], y[t-1], and intercept",
    vcov = "Newey-West HAC, Bartlett lag 4, no finite-sample adjustment"
  ),
  diagnostics = structure(list(), names = character(0))
)
write_json(out, "result.json", auto_unbox = TRUE, na = "null", digits = 17)
