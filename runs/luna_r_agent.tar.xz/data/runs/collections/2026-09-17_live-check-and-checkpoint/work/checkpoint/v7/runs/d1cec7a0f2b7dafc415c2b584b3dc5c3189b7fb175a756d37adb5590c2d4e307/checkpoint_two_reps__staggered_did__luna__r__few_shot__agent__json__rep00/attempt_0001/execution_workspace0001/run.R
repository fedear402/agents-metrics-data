library(jsonlite)

df <- read.csv("input.csv", stringsAsFactors = FALSE)

cohorts <- c(4, 6, 8)
never <- df$cohort == -1
cell_values <- numeric(0)

for (g in cohorts) {
  baseline <- mean(df$y_did[df$cohort == g & df$year == g - 1])
  never_baseline <- mean(df$y_did[never & df$year == g - 1])
  for (t in g:9) {
    treated_change <- mean(df$y_did[df$cohort == g & df$year == t]) - baseline
    control_change <- mean(df$y_did[never & df$year == t]) - never_baseline
    cell_values <- c(cell_values, treated_change - control_change)
  }
}

att <- mean(cell_values)
out <- list(
  task_id = "staggered_did",
  platform = "r",
  estimates = list(list(term = "att", estimate = att, se = NA, n_obs = nrow(df))),
  method_metadata = list(
    estimator = "Equal-weight ATT from supported cohort-year group means",
    vcov = "none"
  ),
  diagnostics = structure(list(), names = character(0))
)
write_json(out, "result.json", auto_unbox = TRUE, na = "null", digits = 17)
