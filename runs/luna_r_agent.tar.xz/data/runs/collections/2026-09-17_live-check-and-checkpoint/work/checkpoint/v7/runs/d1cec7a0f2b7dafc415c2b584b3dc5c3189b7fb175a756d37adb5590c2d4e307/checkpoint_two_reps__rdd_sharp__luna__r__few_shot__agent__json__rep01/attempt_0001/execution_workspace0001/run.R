args <- commandArgs(trailingOnly = TRUE)
if (!requireNamespace("jsonlite", quietly = TRUE)) stop("jsonlite is required")

dat <- read.csv("input.csv", stringsAsFactors = FALSE)
needed <- c("z", "d", "y")
if (!all(needed %in% names(dat))) stop("input.csv must contain z, d, and y")
dat <- dat[complete.cases(dat[, needed]), ]
h <- 0.5
c0 <- 0
inside <- abs(dat$z - c0) <= h
left <- inside & dat$z < c0
right <- inside & dat$z >= c0

fit_side <- function(z, y, side) {
  X <- cbind(1, z - c0)
  w <- 1 - abs(z - c0) / h
  sw <- sqrt(w)
  beta <- solve(crossprod(X * sw, X * sw), crossprod(X * sw, y * sw))
  resid <- as.vector(y - X %*% beta)
  bread <- solve(crossprod(X * sw, X * sw))
  # HC1 sandwich covariance for the weighted least-squares fit.
  meat <- crossprod(X, X * as.vector(w^2 * resid^2))
  n <- length(y)
  p <- ncol(X)
  vcov <- bread %*% meat %*% bread * n / (n - p)
  list(beta = beta, vcov = vcov, n = n)
}

fl <- fit_side(dat$z[left], dat$y[left], "left")
fr <- fit_side(dat$z[right], dat$y[right], "right")
late <- unname(fr$beta[1] - fl$beta[1])
se <- sqrt(unname(fr$vcov[1, 1] + fl$vcov[1, 1]))
n_obs <- fl$n + fr$n

out <- list(
  task_id = "rdd_sharp",
  platform = "r",
  estimates = list(list(term = "late", estimate = late, se = se, n_obs = n_obs)),
  method_metadata = list(estimator = "local linear regression with triangular kernel, bandwidth 0.5",
                         vcov = "HC1 sandwich, sides treated as independent"),
  diagnostics = structure(list(), names = character(0))
)
jsonlite::write_json(out, "result.json", auto_unbox = TRUE, digits = 16)
