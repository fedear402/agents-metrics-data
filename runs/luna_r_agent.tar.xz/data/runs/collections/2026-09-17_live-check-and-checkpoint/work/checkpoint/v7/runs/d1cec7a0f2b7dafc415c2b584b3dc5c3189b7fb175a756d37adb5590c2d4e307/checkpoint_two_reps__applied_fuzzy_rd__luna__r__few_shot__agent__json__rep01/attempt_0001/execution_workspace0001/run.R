dat <- read.csv("input.csv", stringsAsFactors = FALSE)
keep <- abs(dat$score) < 1
d <- dat[keep, , drop = FALSE]
z <- d$score
right <- as.numeric(z >= 0)
w <- 1 - abs(z)
X <- cbind(1, z, right, right*z)
Y <- cbind(d$earnings, d$participated)

XtWX <- crossprod(X, w * X)
bread <- solve(XtWX)
B <- bread %*% crossprod(X, w * Y)
E <- Y - X %*% B
cvec <- c(0, 0, 1, 0)
jump <- drop(cvec %*% B)

# HC0 joint covariance for the two discontinuity estimates.
# The weighted score contribution uses w*x*residual.
loading <- drop(X %*% bread %*% cvec)
joint <- matrix(0, 2, 2)
for (a in 1:2) for (b in 1:2)
  joint[a,b] <- sum((w * loading * E[,a]) * (w * loading * E[,b]))
se <- sqrt(diag(joint))
ratio <- jump[1] / jump[2]
grad <- c(1/jump[2], -jump[1]/jump[2]^2)
ratio_se <- sqrt(drop(t(grad) %*% joint %*% grad))

out <- list(task_id="applied_fuzzy_rd", platform="r",
  estimates=list(
    list(term="treatment_effect", estimate=unname(ratio), se=unname(ratio_se), n_obs=nrow(d)),
    list(term="reduced_form", estimate=unname(jump[1]), se=unname(se[1]), n_obs=nrow(d)),
    list(term="first_stage", estimate=unname(jump[2]), se=unname(se[2]), n_obs=nrow(d))),
  method_metadata=list(estimator="weighted local-linear fuzzy regression discontinuity", vcov="HC0, fixed triangular weights, delta method"),
  diagnostics=structure(list(), names=character(0)))
jsonlite::write_json(out, "result.json", auto_unbox=TRUE, digits=16, pretty=TRUE)
