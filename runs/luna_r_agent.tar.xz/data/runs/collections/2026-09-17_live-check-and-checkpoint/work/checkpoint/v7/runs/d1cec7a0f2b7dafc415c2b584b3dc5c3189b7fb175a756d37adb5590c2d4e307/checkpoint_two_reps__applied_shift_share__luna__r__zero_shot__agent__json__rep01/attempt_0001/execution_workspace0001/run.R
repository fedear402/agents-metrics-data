#!/usr/bin/env Rscript
options(stringsAsFactors = FALSE)
library(jsonlite)
d <- read.csv("input.csv", check.names=FALSE)
ri <- !duplicated(d$region_id)
r <- d[ri, c("region_id","region_weight","x","y")]
names(r) <- c("region_id","rw","x","y")
r$e <- r$rw/sum(r$rw)
zr <- aggregate(d$share*d$shock, list(d$region_id), sum)
names(zr) <- c("region_id","z")
r <- merge(r,zr,by="region_id",sort=FALSE)
wm <- function(a,w) sum(a*w)
r$y0 <- r$y-wm(r$y,r$e); r$x0 <- r$x-wm(r$x,r$e); r$z0 <- r$z-wm(r$z,r$e)
d$e <- r$e[match(d$region_id,r$region_id)]
ex <- d$e*d$share
sn <- aggregate(ex,list(d$industry_id),sum); names(sn) <- c("industry_id","s")
sn <- sn[sn$s>0,]
yb <- aggregate(ex*r$y0[match(d$region_id,r$region_id)],list(d$industry_id),sum)
xb <- aggregate(ex*r$x0[match(d$region_id,r$region_id)],list(d$industry_id),sum)
zb <- aggregate(ex*r$z0[match(d$region_id,r$region_id)],list(d$industry_id),sum)
names(yb) <- c("industry_id","ybnum"); names(xb) <- c("industry_id","xbnum"); names(zb) <- c("industry_id","zbnum")
sh <- aggregate(d$shock,list(d$industry_id),function(v)v[1]); names(sh)<-c("industry_id","shock")
a <- Reduce(function(x,y)merge(x,y,by="industry_id"),list(sn,yb,xb,zb,sh))
a$yb <- a$ybnum/a$s; a$xb <- a$xbnum/a$s; a$zb <- a$zbnum/a$s
iv <- function(dep,endog,inst,w) {
 n<-length(dep); X<-cbind(1,endog); Z<-cbind(1,inst); W<-diag(w)
 Q<-solve(crossprod(Z,W%*%Z)); G<-crossprod(X,W%*%Z)%*%Q%*%crossprod(Z,W%*%X)
 b<-solve(G,crossprod(X,W%*%Z)%*%Q%*%crossprod(Z,W%*%dep)); u<-as.vector(dep-X%*%b)
 H<-crossprod(X,W%*%Z)%*%Q
 meat<-H%*%crossprod(Z,(W%*%diag(u^2)%*%W)%*%Z)%*%t(H)
 V<-solve(G)%*%meat%*%solve(G)*n/(n-2)
 list(b=as.vector(b),se=sqrt(diag(V)))
}
ef<-iv(a$yb,a$xb,a$shock,a$s); fs<-iv(a$xb,a$zb,a$shock,a$s); N<-nrow(a)
o<-list(task_id="applied_shift_share",platform="r",estimates=list(
 list(term="effect",estimate=ef$b[2],se=ef$se[2],n_obs=N),
 list(term="first_stage",estimate=fs$b[2],se=fs$se[2],n_obs=N),
 list(term="effective_shocks",estimate=1/sum(a$s^2),se=NULL,n_obs=N)),
 method_metadata=list(estimator="BHJ shock-level weighted IV 2SLS",vcov="HC1 structural IV residuals, multiplier N/(N-2)"),diagnostics=list(n_regions=nrow(r),n_industries=N))
write(toJSON(o,auto_unbox=TRUE,digits=17,null="null",pretty=TRUE),"result.json")
# Independent identity check: direct regional weighted IV slopes.
regional_iv <- function(dep,endog,inst,w) {
 X<-cbind(1,endog); Z<-cbind(1,inst); W<-diag(w)
 solve(crossprod(X,W%*%Z)%*%solve(crossprod(Z,W%*%Z))%*%crossprod(Z,W%*%X),
       crossprod(X,W%*%Z)%*%solve(crossprod(Z,W%*%Z))%*%crossprod(Z,W%*%dep))[2]
}
rd_eff <- regional_iv(r$y,r$x,r$z,r$e)
rd_fs <- regional_iv(r$x,r$z,r$z,r$e)
checks <- c(sprintf("regions=%d industries=%d",nrow(r),N),
 sprintf("sum_e=%.17g",sum(r$e)),
 sprintf("effect_shock_level=%.17g effect_regional=%.17g abs_diff=%.3g",ef$b[2],rd_eff,abs(ef$b[2]-rd_eff)),
 sprintf("first_stage_shock_level=%.17g first_stage_regional=%.17g abs_diff=%.3g",fs$b[2],rd_fs,abs(fs$b[2]-rd_fs)),
 sprintf("effective_shocks=%.17g",1/sum(a$s^2)))
writeLines(checks,"verification.txt")
