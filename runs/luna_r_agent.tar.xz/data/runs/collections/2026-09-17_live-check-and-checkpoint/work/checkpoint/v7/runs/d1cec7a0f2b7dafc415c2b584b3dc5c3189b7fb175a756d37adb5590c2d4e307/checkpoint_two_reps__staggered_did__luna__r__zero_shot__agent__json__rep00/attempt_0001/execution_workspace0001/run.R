data <- read.csv("input.csv", stringsAsFactors = FALSE)

required <- c("firm", "year", "cohort", "y_did")
if (!all(required %in% names(data))) stop("Required columns are missing")
if (anyNA(data[, required])) stop("Required columns contain missing values")

cohorts <- c(4, 6, 8)
years <- 0:9
if (!all(years %in% data$year)) stop("Unexpected year support")
if (any(table(data$firm) != 10)) stop("Panel is not complete")

never <- data$cohort == -1
cell_effects <- numeric(0)
for (g in cohorts) {
  for (t in years[years >= g]) {
    treated_t <- data$cohort == g & data$year == t
    treated_b <- data$cohort == g & data$year == (g - 1)
    never_t <- never & data$year == t
    never_b <- never & data$year == (g - 1)
    if (!all(vapply(list(treated_t, treated_b, never_t, never_b), any,
                    FUN.VALUE = logical(1)))) {
      stop("An ATT cell lacks support")
    }
    cell_effects <- c(cell_effects,
      mean(data$y_did[treated_t]) - mean(data$y_did[treated_b]) -
      (mean(data$y_did[never_t]) - mean(data$y_did[never_b])))
  }
}

att <- mean(cell_effects)
result <- list(
  task_id = "staggered_did",
  platform = "r",
  estimates = list(list(term = "att", estimate = unname(att), se = NULL,
                        n_obs = nrow(data))),
  method_metadata = list(estimator = "ATT_uniform from group-year means",
                         vcov = "none"),
  diagnostics = list(n_cells = length(cell_effects), cohorts = cohorts,
                     supported_post_cells = length(cell_effects))
)
jsonlite::write_json(result, "result.json", auto_unbox = TRUE, null = "null",
                     digits = 17)
