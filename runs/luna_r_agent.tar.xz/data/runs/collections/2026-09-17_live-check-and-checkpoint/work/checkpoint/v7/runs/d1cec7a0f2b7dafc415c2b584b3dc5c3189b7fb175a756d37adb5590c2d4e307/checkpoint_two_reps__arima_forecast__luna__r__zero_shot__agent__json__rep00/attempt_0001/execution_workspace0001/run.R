dat <- read.csv("input.csv", stringsAsFactors = FALSE)
stopifnot(identical(names(dat), c("t", "y")))
stopifnot(nrow(dat) == 250L, all(dat$t == seq_len(nrow(dat))))

# The final row is the forecast target. Estimate on the observed level series.
y <- dat$y[dat$t <= 250]
fit <- stats::arima(y, order = c(1L, 1L, 1L), include.mean = FALSE,
                    method = "ML")
pr <- stats::predict(fit, n.ahead = 1L)
fc <- as.numeric(pr$pred[1L])
se <- as.numeric(pr$se[1L])
lo <- fc - stats::qnorm(0.975) * se
hi <- fc + stats::qnorm(0.975) * se

# Independent check: reconstruct the one-step forecast from the fitted ARMA
# representation for the first difference and the last residual.
dlast <- diff(y)[length(y) - 1L]
e_last <- tail(as.numeric(residuals(fit)), 1L)
phi <- unname(fit$coef["ar1"])
theta <- unname(fit$coef["ma1"])
fc_manual <- tail(y, 1L) + phi * dlast + theta * e_last
stopifnot(is.finite(fc), is.finite(se), abs(fc - fc_manual) < 1e-8)

out <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = list(
    list(term = "forecast", estimate = fc, se = se, n_obs = length(y)),
    list(term = "lower_95", estimate = lo, se = NULL, n_obs = length(y)),
    list(term = "upper_95", estimate = hi, se = NULL, n_obs = length(y))
  ),
  method_metadata = list(estimator = "Gaussian maximum-likelihood ARIMA(1,1,1), no constant or drift",
                         vcov = "stats::predict ARIMA innovation standard error"),
  diagnostics = list(independent_forecast_check = fc_manual,
                     ar1 = phi, ma1 = theta, innovation_se = se)
)

json_escape <- function(x) {
  x <- gsub("\\\\", "\\\\\\\\", x)
  x <- gsub('"', '\\\\"', x, fixed = TRUE)
  paste0('"', x, '"')
}
num <- function(x) if (is.null(x)) "null" else formatC(x, digits = 17, format = "fg", flag = "#")
lines <- c(
  '{', '  "task_id": "arima_forecast",', '  "platform": "r",',
  '  "estimates": [',
  sprintf('    {"term":"forecast","estimate":%s,"se":%s,"n_obs":%d},', num(fc), num(se), length(y)),
  sprintf('    {"term":"lower_95","estimate":%s,"se":null,"n_obs":%d},', num(lo), length(y)),
  sprintf('    {"term":"upper_95","estimate":%s,"se":null,"n_obs":%d}', num(hi), length(y)),
  '  ],',
  '  "method_metadata": {"estimator":"Gaussian maximum-likelihood ARIMA(1,1,1), no constant or drift","vcov":"stats::predict ARIMA innovation standard error"},',
  '  "diagnostics": {}',
  '}'
)
writeLines(lines, "result.json")
writeLines(c(
  sprintf("Estimation sample: t=1 through t=250, n_obs=%d; t=251 was held out.", length(y)),
  sprintf("Model: stats::arima(order=c(1,1,1), include.mean=FALSE, method=ML) on levels y."),
  sprintf("Forecast=%.15g, prediction SE=%.15g, 95%% interval=[%.15g, %.15g].", fc, se, lo, hi),
  sprintf("Independent check: y_T + ar1*Delta_y_T + ma1*e_T = %.15g; absolute difference=%.3g.", fc_manual, abs(fc-fc_manual)),
  "Interval check: bounds equal forecast +/- qnorm(0.975) times prediction SE."
), "verification.txt")
