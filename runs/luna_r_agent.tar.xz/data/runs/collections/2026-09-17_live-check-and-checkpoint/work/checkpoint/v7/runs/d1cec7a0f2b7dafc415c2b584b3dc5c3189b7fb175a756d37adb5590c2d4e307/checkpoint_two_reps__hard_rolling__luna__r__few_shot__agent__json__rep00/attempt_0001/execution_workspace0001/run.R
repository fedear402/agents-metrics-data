library(jsonlite)

dat <- read.csv("input.csv", stringsAsFactors = FALSE)
dat <- dat[order(dat$time), ]
stopifnot(nrow(dat) == 250L, identical(as.integer(dat$time), 1:250))
y <- as.numeric(dat$y)

forecast_times <- 101:250
fc <- numeric(length(forecast_times))
for (i in seq_along(forecast_times)) {
  f <- forecast_times[i]
  levels <- y[(f - 100):(f - 1)]
  lagged <- levels[1:99]
  current <- levels[2:100]
  fit <- lm(current ~ lagged)
  stopifnot(length(current) == 99L)
  fc[i] <- coef(fit)[1] + coef(fit)[2] * levels[100]
}

rmse <- sqrt(mean((y[forecast_times] - fc)^2))
selected <- c(101L, 150L, 200L, 250L)
selected_fc <- fc[match(selected, forecast_times)]
row <- function(term, estimate, n_obs) {
  list(term = term, estimate = unname(as.numeric(estimate)), se = NULL,
       n_obs = as.integer(n_obs))
}
estimates <- list(row("rmse", rmse, 150L))
for (j in seq_along(selected)) {
  estimates[[length(estimates) + 1L]] <-
    row(paste0("forecast_", selected[j]), selected_fc[j], 99L)
}
result <- list(task_id = "hard_rolling", platform = "r", estimates = estimates,
               method_metadata = list(estimator = "rolling OLS AR(1) with intercept",
                                      vcov = "none; forecast point estimates"),
               diagnostics = list())
write_json(result, "result.json.tmp", auto_unbox = TRUE, null = "null",
           digits = 16, pretty = TRUE)
json_text <- readLines("result.json.tmp", warn = FALSE)
json_text <- sub('("diagnostics": )\\[\\]', '\\1{}', json_text)
writeLines(json_text, "result.json")
unlink("result.json.tmp")

# Independent check: closed-form OLS coefficients and direct squared-error sum.
fc_closed <- numeric(length(forecast_times))
for (i in seq_along(forecast_times)) {
  f <- forecast_times[i]
  z <- y[(f - 100):(f - 1)]
  x <- z[1:99]
  yy <- z[2:100]
  b <- sum((x - mean(x)) * (yy - mean(yy))) / sum((x - mean(x))^2)
  a <- mean(yy) - b * mean(x)
  fc_closed[i] <- a + b * z[100]
}
max_fc_diff <- max(abs(fc - fc_closed))
rmse_direct <- sqrt(sum((y[forecast_times] - fc_closed)^2) / 150)
writeLines(c(
  paste0("Sorted observations: ", nrow(dat), "; time range: ", min(dat$time), " to ", max(dat$time)),
  "Each forecast used 100 observed levels and 99 consecutive regression pairs.",
  paste0("Independent closed-form OLS maximum forecast difference: ", format(max_fc_diff, digits = 16)),
  paste0("RMSE from direct squared-error identity: ", format(rmse_direct, digits = 16)),
  paste0("RMSE reported by rolling forecasts: ", format(rmse, digits = 16)),
  paste0("RMSE absolute difference: ", format(abs(rmse - rmse_direct), digits = 16))
), "verification.txt")
