dat <- read.csv("input.csv", stringsAsFactors = FALSE)
stopifnot(all(c("id", "y", "x", "z") %in% names(dat)))
dat <- dat[complete.cases(dat[, c("y", "x", "z")]), ]
stopifnot(all(dat$y %in% 1:3))
y <- as.integer(dat$y); X <- cbind(dat$x, dat$z); n <- nrow(dat)

logistic <- function(a) plogis(a)
unpack <- function(p) {
  c1 <- p[3]; c2 <- c1 + exp(p[4])
  list(beta=p[1:2], c1=c1, c2=c2)
}
nll <- function(p) {
  q <- unpack(p); eta <- drop(X %*% q$beta)
  pr <- numeric(n)
  pr[y == 1] <- logistic(q$c1 - eta[y == 1])
  pr[y == 2] <- logistic(q$c2 - eta[y == 2]) - logistic(q$c1 - eta[y == 2])
  pr[y == 3] <- 1 - logistic(q$c2 - eta[y == 3])
  if (any(!is.finite(pr)) || any(pr <= 0)) return(1e100)
  -sum(log(pr))
}

fit <- optim(c(0, 0, 0, 0), nll, method="BFGS", hessian=TRUE,
             control=list(maxit=10000, reltol=1e-12))
if (fit$convergence != 0) stop("optim failed: ", fit$message)
q <- unpack(fit$par)
V_u <- solve(fit$hessian)
V <- V_u # beta coordinates are unchanged by the cutpoint transformation
se <- sqrt(diag(V)[1:2])
eta0 <- drop(c(1, 0) %*% q$beta)
prob_high <- logistic(eta0 - q$c2)

out <- list(task_id="broad_ordered_logit", platform="r",
  estimates=list(
    list(term="x", estimate=unname(q$beta[1]), se=unname(se[1]), n_obs=n),
    list(term="z", estimate=unname(q$beta[2]), se=unname(se[2]), n_obs=n),
    list(term="prob_high", estimate=unname(prob_high), se=NULL, n_obs=n)),
  method_metadata=list(estimator="maximum likelihood ordered logit", vcov="inverse observed information"),
  diagnostics=list())
if (!requireNamespace("jsonlite", quietly=TRUE)) stop("jsonlite is required")
jsonlite::write_json(out, "result.json", auto_unbox=TRUE, digits=17, null="null")

# Independent checks: direct probability identity and centered numerical scores.
fd_score <- function(p, h=1e-5) vapply(seq_along(p), function(j) {
  d <- rep(0, length(p)); d[j] <- h
  (nll(p+d)-nll(p-d))/(2*h)
}, numeric(1))
identity_check <- prob_high - plogis(drop(eta0 - q$c2))
score_check <- max(abs(fd_score(fit$par)))
writeLines(c(
  paste("Rows used:", n),
  paste("Outcome counts:", paste(table(y), collapse=",")),
  paste("Optimizer convergence:", fit$convergence),
  paste("Maximum absolute centered finite-difference score:", format(score_check, digits=10)),
  paste("Probability identity difference:", format(identity_check, digits=10)),
  "Independent check: category-3 probability equals plogis(x beta_x + z beta_z - upper cutpoint) at (x,z)=(1,0).",
  "Uncertainty check: slope standard errors use the slope block of the inverse full observed Hessian, including cutpoint nuisance parameters."
), "verification.txt")
