dat <- read.csv("input.csv", check.names = FALSE)
stopifnot(nrow(dat) == 240, identical(names(dat), c("y", "endog", "x", "z1", "z2")))
n <- nrow(dat)
W <- cbind(1, dat$x)
Z <- cbind(dat$z1, dat$z2)
Xfull <- cbind(W, Z)
df2 <- 2
df2den <- n - ncol(Xfull)
crit <- qf(0.95, df2, df2den)

ar_f <- function(beta) {
  q <- dat$y - beta * dat$endog
  fit_u <- lm.fit(Xfull, q)
  fit_r <- lm.fit(W, q)
  rss_u <- sum(fit_u$residuals^2)
  rss_r <- sum(fit_r$residuals^2)
  ((rss_r - rss_u) / df2) / (rss_u / df2den)
}

# RSS(beta) is quadratic. Compute its coefficients from three evaluations.
rss_pair <- function(beta) {
  q <- dat$y - beta * dat$endog
  ru <- lm.fit(Xfull, q)$residuals
  rr <- lm.fit(W, q)$residuals
  c(sum(ru^2), sum(rr^2))
}
r0 <- rss_pair(0); r1 <- rss_pair(1); rm1 <- rss_pair(-1)
quad <- function(v0, v1, vm1) c(a = (v1 + vm1 - 2*v0)/2, b = (v1-vm1)/2, c = v0)
cu <- quad(r0[1], r1[1], rm1[1]); cr <- quad(r0[2], r1[2], rm1[2])
# Acceptance is (RSSr-RSSu)/2 <= crit*RSSu/df2den.
poly <- (cr - cu) / 2 - crit * cu / df2den
roots <- sort(Re(polyroot(c(poly[3], poly[2], poly[1]))))
if (any(abs(Im(polyroot(c(poly[3], poly[2], poly[1])))) > 1e-7)) stop("Non-real boundary")
if (length(roots) != 2 || !all(is.finite(roots))) stop("Expected two finite boundaries")
mid <- mean(roots)
accepts_zero <- as.integer(ar_f(0) <= crit)
unbounded <- as.integer(ar_f(1e10) <= crit || ar_f(-1e10) <= crit)

# Independent check: direct quadratic-form calculation using projection matrices.
M <- diag(n) - W %*% solve(crossprod(W), crossprod(W, diag(n)))
Pz <- M %*% Z %*% solve(crossprod(Z, M %*% Z)) %*% t(Z) %*% M
q1 <- dat$y - dat$endog
f_check <- (as.numeric(crossprod(q1, Pz %*% q1))/df2) /
  (as.numeric(crossprod(q1, (M-Pz) %*% q1))/df2den)
if (max(abs(f_check - ar_f(1))) > 1e-8) stop("Independent F check failed")
if (abs(ar_f(roots[1]) - crit) > 1e-5 || abs(ar_f(roots[2]) - crit) > 1e-5) stop("Boundary check failed")

num <- function(term, estimate) sprintf('{"term":"%s","estimate":%.15g,"se":null,"n_obs":%d}', term, estimate, n)
out <- paste0('{"task_id":"broad_ar_confidence_set","platform":"r","estimates":[',
  paste(c(num("boundary_low", roots[1]), num("boundary_high", roots[2]),
          num("accepts_zero", accepts_zero), num("unbounded", unbounded),
          num("ar_f_at_one", ar_f(1))), collapse=","),
  '],"method_metadata":{"estimator":"Anderson-Rubin homoskedastic joint F inversion","vcov":"conventional homoskedastic OLS F statistic"},"diagnostics":{}}')
writeLines(out, "result.json")
verification <- sprintf("n_obs=%d; df_den=%d; F_critical=%.15g\nF(beta=1)=%.15g; independent quadratic-form F=%.15g; absolute difference=%.3g\nboundaries=(%.15g, %.15g); F at boundaries=(%.15g, %.15g)\naccepts_zero=%d; unbounded=%d; residual RSS quadratic coefficients checked from beta=-1,0,1.\n", n, df2den, crit, ar_f(1), f_check, abs(ar_f(1)-f_check), roots[1], roots[2], ar_f(roots[1]), ar_f(roots[2]), accepts_zero, unbounded)
writeLines(verification, "verification.txt")
