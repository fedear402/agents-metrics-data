dat <- read.csv("input.csv", stringsAsFactors = FALSE)
vars <- c("y_lin", "x1", "x2")
keep <- complete.cases(dat[, vars])
y <- dat$y_lin[keep]
X <- cbind(const = 1, x1 = dat$x1[keep], x2 = dat$x2[keep])
n <- length(y)
k <- ncol(X)

fit <- lm.fit(x = X, y = y)
beta <- as.numeric(fit$coefficients)
names(beta) <- colnames(X)
u <- as.numeric(y - X %*% beta)
bread <- solve(crossprod(X))
meat <- crossprod(X * u)
vcov_hc1 <- (n / (n - k)) * bread %*% meat %*% bread
se <- sqrt(diag(vcov_hc1))

if (any(!is.finite(beta)) || any(!is.finite(se))) stop("Non-finite estimate or standard error")

esc <- function(x) {
  if (is.null(x) || length(x) == 0 || !is.finite(x)) "null" else formatC(x, digits = 17, format = "fg", flag = "#")
}
terms <- c("const", "x1", "x2")
est_json <- vapply(seq_along(terms), function(i) {
  sprintf('{"term":"%s","estimate":%s,"se":%s,"n_obs":%d}',
          terms[i], esc(beta[i]), esc(se[i]), n)
}, character(1))
json <- paste0(
  '{"task_id":"ols_robust","platform":"r","estimates":[',
  paste(est_json, collapse = ","),
  '],"method_metadata":{"estimator":"OLS with intercept","vcov":"HC1 heteroskedasticity-robust"},"diagnostics":{}}'
)
writeLines(json, "result.json")
