library(jsonlite)

df <- read.csv("input.csv", stringsAsFactors = FALSE)
required <- c("firm", "year", "cohort", "y_did")
if (!all(required %in% names(df))) stop("Required columns are missing")
if (nrow(df) != 2000L) stop("Unexpected observation count")
if (length(unique(df$firm)) != 200L || length(unique(df$year)) != 10L) {
  stop("Unexpected panel dimensions")
}
if (any(table(df$firm) != 10L) || any(table(df$year) != 200L)) {
  stop("Panel is not balanced")
}

cohorts <- c(4L, 6L, 8L)
cell_effects <- numeric(0)
cell_labels <- character(0)
for (g in cohorts) {
  base <- df$y_did[df$cohort == g & df$year == g - 1L]
  never_base <- df$y_did[df$cohort == -1 & df$year == g - 1L]
  if (length(base) == 0L || length(never_base) == 0L) stop("Missing baseline cell")
  for (t in g:9L) {
    treated_t <- df$y_did[df$cohort == g & df$year == t]
    never_t <- df$y_did[df$cohort == -1 & df$year == t]
    if (length(treated_t) == 0L || length(never_t) == 0L) stop("Missing post cell")
    cell_effects <- c(cell_effects,
      (mean(treated_t) - mean(base)) - (mean(never_t) - mean(never_base)))
    cell_labels <- c(cell_labels, paste0("g", g, "_t", t))
  }
}
att <- mean(cell_effects)

out <- list(
  task_id = "staggered_did",
  platform = "r",
  estimates = list(list(term = "att", estimate = unname(att), se = NA_real_,
                        n_obs = nrow(df))),
  method_metadata = list(estimator = "ATT_uniform from group-year means",
                         vcov = "none"),
  diagnostics = structure(list(), names = character(0))
)
write_json(out, "result.json", auto_unbox = TRUE, na = "null", digits = 17)

# Independent algebraic check: reproduce the same cells from aggregated means.
means <- aggregate(y_did ~ cohort + year, data = df, FUN = mean)
cell_effects_agg <- numeric(0)
for (g in cohorts) {
  tg <- means$y_did[means$cohort == g & means$year == g - 1L]
  ng <- means$y_did[means$cohort == -1 & means$year == g - 1L]
  for (t in g:9L) {
    cell_effects_agg <- c(cell_effects_agg,
      (means$y_did[means$cohort == g & means$year == t] - tg) -
      (means$y_did[means$cohort == -1 & means$year == t] - ng))
  }
}
if (!isTRUE(all.equal(cell_effects, cell_effects_agg, tolerance = 1e-12))) {
  stop("Independent group-year aggregation check failed")
}
if (length(cell_effects) != 12L) stop("Unexpected number of supported cells")

verification <- c(
  paste("Rows:", nrow(df), "firms:", length(unique(df$firm)),
        "years:", length(unique(df$year))),
  paste("Supported cells:", length(cell_effects),
        "(cohorts 4, 6, 8; post years through 9)"),
  paste("ATT from direct cell loop:", format(att, digits = 17)),
  paste("ATT from aggregate means:", format(mean(cell_effects_agg), digits = 17)),
  paste("Absolute difference:", format(abs(att - mean(cell_effects_agg)), digits = 17)),
  "Check passed: direct cell means equal independently aggregated group-year means."
)
writeLines(verification, "verification.txt")
