library(jsonlite)

dat <- read.csv("input.csv", stringsAsFactors = FALSE)
stopifnot(all(c("t", "y") %in% names(dat)))
dat <- dat[order(dat$t), , drop = FALSE]
y <- as.numeric(dat$y)
n <- length(y)
stopifnot(n > 3L, identical(as.integer(dat$t), seq_len(n)))

fit <- stats::arima(
  y, order = c(1L, 1L, 1L),
  include.mean = FALSE, method = "ML"
)
pred <- predict(fit, n.ahead = 1L)
forecast_value <- as.numeric(pred$pred[1L])
se_value <- as.numeric(pred$se[1L])
lower_value <- forecast_value - qnorm(0.975) * se_value
upper_value <- forecast_value + qnorm(0.975) * se_value

out <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = list(
    list(term = "forecast", estimate = forecast_value, se = se_value, n_obs = n),
    list(term = "lower_95", estimate = lower_value, se = NA_real_, n_obs = n),
    list(term = "upper_95", estimate = upper_value, se = NA_real_, n_obs = n)
  ),
  method_metadata = list(
    estimator = "ARIMA(1,1,1) by maximum likelihood without constant or drift",
    vcov = "model-based Gaussian prediction variance"
  ),
  diagnostics = structure(list(), names = character(0))
)
write_json(out, "result.json", auto_unbox = TRUE, na = "null", digits = 17)
