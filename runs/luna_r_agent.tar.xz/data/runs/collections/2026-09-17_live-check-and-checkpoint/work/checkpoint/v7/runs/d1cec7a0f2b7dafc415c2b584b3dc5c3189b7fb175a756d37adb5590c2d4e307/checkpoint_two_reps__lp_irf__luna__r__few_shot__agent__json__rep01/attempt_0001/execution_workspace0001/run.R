library(jsonlite)
library(sandwich)

dat <- read.csv("input.csv", stringsAsFactors = FALSE)
dat <- dat[order(dat$t), ]
n <- nrow(dat)

# Construct the horizon-four lead and one-period lag.
dat$y_lead4 <- c(dat$y[5:n], rep(NA_real_, 4))
dat$y_lag1 <- c(NA_real_, dat$y[1:(n - 1)])
sample <- dat[complete.cases(dat[, c("y_lead4", "shock", "y_lag1")]), ]

fit <- lm(y_lead4 ~ shock + y_lag1, data = sample)
nw <- NeweyWest(fit, lag = 4, prewhite = FALSE, adjust = FALSE)
co <- coef(summary(fit))
term <- "shock"

out <- list(
  task_id = "lp_irf",
  platform = "r",
  estimates = list(list(
    term = "irf_h4",
    estimate = unname(co[term, "Estimate"]),
    se = unname(sqrt(nw[term, term])),
    n_obs = nrow(sample)
  )),
  method_metadata = list(
    estimator = "Local projection OLS: y[t+4] on shock[t] and y[t-1] with intercept",
    vcov = "Newey-West HAC, lag 4"
  ),
  diagnostics = structure(list(), names = character(0))
)
write_json(out, "result.json", auto_unbox = TRUE, na = "null", digits = 17)
