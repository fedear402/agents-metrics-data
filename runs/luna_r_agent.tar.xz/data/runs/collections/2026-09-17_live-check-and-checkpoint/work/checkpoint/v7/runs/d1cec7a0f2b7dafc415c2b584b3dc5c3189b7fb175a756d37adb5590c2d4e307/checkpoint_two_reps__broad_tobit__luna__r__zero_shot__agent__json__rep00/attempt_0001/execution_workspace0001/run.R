dat <- read.csv("input.csv", stringsAsFactors = FALSE)
stopifnot(all(c("id", "y", "x", "z") %in% names(dat)), nrow(dat) == 400L)
X <- cbind(const = 1, x = dat$x, z = dat$z)
y <- dat$y
if (any(y < 0) || any(!is.finite(y))) stop("Invalid outcome")
is_pos <- y > 0

loglik <- function(par) {
  b <- par[1:3]; sigma <- exp(par[4])
  eta <- drop(X %*% b)
  ll <- numeric(length(y))
  ll[is_pos] <- dnorm((y[is_pos] - eta[is_pos]) / sigma, log = TRUE) - log(sigma)
  ll[!is_pos] <- pnorm(-eta[!is_pos] / sigma, log.p = TRUE)
  if (any(!is.finite(ll))) return(-1e100)
  sum(ll)
}
negll <- function(p) -loglik(p)

# Use several sensible starts to guard against dependence on initial values.
starts <- list(c(coef(lm(y ~ x + z, data = dat[is_pos, ])), log(sd(y[is_pos]))),
               c(0, 0, 0, log(sd(y[is_pos]))), c(0, 1, 1, 0))
fits <- lapply(starts, function(s) optim(s, negll, method = "BFGS", hessian = TRUE,
                                         control = list(maxit = 2000, reltol = 1e-12)))
fit <- fits[[which.min(vapply(fits, `[[`, numeric(1), "value"))]]
if (fit$convergence != 0) warning("optim convergence code: ", fit$convergence)
par <- fit$par; beta <- par[1:3]; sigma <- exp(par[4])

# Numerical observed information for (beta, log sigma), then delta method for sigma.
Vpar <- solve(fit$hessian)
if (any(!is.finite(Vpar)) || any(diag(Vpar) < 0)) stop("Invalid observed information")
se <- sqrt(diag(Vpar))
se_sigma <- sigma * se[4]

# Independent score check: analytic score evaluated at the solution.
eta <- drop(X %*% beta); a <- eta / sigma
score_b <- numeric(3); score_lsig <- 0
score_b <- colSums(X[is_pos, , drop=FALSE] * ((y[is_pos] - eta[is_pos]) / sigma^2))
lam <- dnorm(a[!is_pos]) / pnorm(-a[!is_pos])
score_b <- score_b + colSums(X[!is_pos, , drop=FALSE] * (-lam / sigma))
score_lsig <- sum((y[is_pos] - eta[is_pos])^2 / sigma^2 - 1) + sum(lam * a[!is_pos])
score_norm <- sqrt(sum(c(score_b, score_lsig)^2))

out <- list(task_id = "broad_tobit", platform = "r",
  estimates = list(
    list(term="const", estimate=unname(beta[1]), se=unname(se[1]), n_obs=nrow(dat)),
    list(term="x", estimate=unname(beta[2]), se=unname(se[2]), n_obs=nrow(dat)),
    list(term="z", estimate=unname(beta[3]), se=unname(se[3]), n_obs=nrow(dat)),
    list(term="sigma", estimate=unname(sigma), se=unname(se_sigma), n_obs=nrow(dat))),
  method_metadata = list(estimator="Homoskedastic Gaussian Tobit MLE, left censoring at 0",
                         vcov="Inverse observed Hessian of joint likelihood; delta method for sigma"),
  diagnostics = list(log_likelihood=unname(loglik(par)), n_obs=nrow(dat), n_censored=sum(!is_pos),
                     score_norm=unname(score_norm), optimizer_convergence=fit$convergence))
json <- function(x) { if (requireNamespace("jsonlite", quietly=TRUE) ) jsonlite::toJSON(x, auto_unbox=TRUE, digits=17) else stop("jsonlite required") }
writeLines(json(out), "result.json")
writeLines(c(sprintf("Rows checked: %d; censored observations: %d; positive observations: %d.", nrow(dat), sum(!is_pos), sum(is_pos)),
  "Tobit MLE used all rows with y=0 contributing log Phi(-X beta/sigma), and y>0 contributing the Gaussian density.",
  sprintf("Independent analytic score check at the optimum: Euclidean score norm = %.8g.", score_norm),
  sprintf("Independent numerical check: %d starts converged to the same best log likelihood %.12f (range %.3g).", length(fits), loglik(par), max(vapply(fits, function(f) loglik(f$par), numeric(1))) - min(vapply(fits, function(f) loglik(f$par), numeric(1)))),
  sprintf("Observed-information covariance came from solve(optim Hessian); sigma SE uses sigma*SE(log sigma) = %.12g.", se_sigma)), "verification.txt")
