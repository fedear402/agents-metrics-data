dat <- read.csv("input.csv", stringsAsFactors = FALSE)
h <- 0.5
cutoff <- 0

keep <- is.finite(dat$z) & is.finite(dat$y) & abs(dat$z - cutoff) <= h
dat <- dat[keep, , drop = FALSE]
dat$side <- ifelse(dat$z < cutoff, "left", "right")
dat$weight <- 1 - abs(dat$z - cutoff) / h
dat <- dat[dat$weight > 0, , drop = FALSE]

fit_side <- function(x) {
  # The intercept is the fitted limit at the cutoff.
  lm(y ~ z, data = x, weights = weight)
}

left <- dat[dat$side == "left", , drop = FALSE]
right <- dat[dat$side == "right", , drop = FALSE]
fit_l <- fit_side(left)
fit_r <- fit_side(right)

late <- unname(coef(fit_r)["(Intercept)"] - coef(fit_l)["(Intercept)"])
se_l <- sqrt(vcov(fit_l)["(Intercept)", "(Intercept)"])
se_r <- sqrt(vcov(fit_r)["(Intercept)", "(Intercept)"])
se_late <- sqrt(se_l^2 + se_r^2)

out <- list(
  task_id = "rdd_sharp",
  platform = "r",
  estimates = list(list(term = "late", estimate = as.numeric(late),
                        se = as.numeric(se_late), n_obs = as.integer(nrow(dat)))),
  method_metadata = list(estimator = "Weighted local linear regression on each side of cutoff; triangular kernel, h=0.5",
                         vcov = "Conventional weighted-least-squares covariance, independent sides"),
  diagnostics = list(n_left = nrow(left), n_right = nrow(right), bandwidth = h,
                     cutoff = cutoff)
)
json <- function(x) {
  if (requireNamespace("jsonlite", quietly = TRUE)) return(jsonlite::toJSON(x, auto_unbox = TRUE, pretty = TRUE, digits = 17))
  stop("jsonlite is required")
}
writeLines(json(out), "result.json")
