library(jsonlite)
library(sandwich)

df <- read.csv("input.csv", stringsAsFactors = FALSE)
needed <- c("x1", "x2", "y_lin")
sample <- complete.cases(df[, needed])
d <- df[sample, needed, drop = FALSE]

fit <- lm(y_lin ~ x1 + x2, data = d)
v <- sandwich::vcovHC(fit, type = "HC1")
b <- coef(fit)
se <- sqrt(diag(v))
n <- nrow(d)

out <- list(
  task_id = "ols_robust",
  platform = "r",
  estimates = list(
    list(term = "const", estimate = unname(b["(Intercept)"]), se = unname(se["(Intercept)"]), n_obs = n),
    list(term = "x1", estimate = unname(b["x1"]), se = unname(se["x1"]), n_obs = n),
    list(term = "x2", estimate = unname(b["x2"]), se = unname(se["x2"]), n_obs = n)
  ),
  method_metadata = list(estimator = "OLS", vcov = "HC1 heteroskedasticity-robust"),
  diagnostics = structure(list(), names = character(0))
)
write_json(out, "result.json", auto_unbox = TRUE, digits = 15)
