dat <- read.csv("input.csv", stringsAsFactors = FALSE)

# Estimation sample: complete observations for the variables in the requested model.
keep <- complete.cases(dat[, c("y_twocluster", "x", "firm", "year")])
d <- dat[keep, , drop = FALSE]
X <- cbind(const = 1, x = d$x)
y <- d$y_twocluster
n <- nrow(d)

fit <- lm.fit(X, y)
b <- as.numeric(fit$coefficients)
u <- as.numeric(y - X %*% b)

# Cameron-Gelbach-Miller two-way cluster covariance, HC0 form:
# V = (X'X)^(-1) [M_firm + M_year - M_intersection] (X'X)^(-1).
cluster_meat <- function(g) {
  S <- matrix(0, ncol(X), ncol(X))
  for (lev in unique(g)) {
    ix <- which(g == lev)
    z <- crossprod(X[ix, , drop = FALSE], u[ix])
    S <- S + tcrossprod(z)
  }
  S
}

XtX_inv <- solve(crossprod(X))
meat <- cluster_meat(d$firm) + cluster_meat(d$year) - cluster_meat(interaction(d$firm, d$year, drop = TRUE))
V <- XtX_inv %*% meat %*% XtX_inv
se <- sqrt(pmax(diag(V), 0))

out <- list(
  task_id = "two_way_cluster",
  platform = "r",
  estimates = list(
    list(term = "const", estimate = unname(b[1]), se = unname(se[1]), n_obs = as.integer(n)),
    list(term = "x", estimate = unname(b[2]), se = unname(se[2]), n_obs = as.integer(n))
  ),
  method_metadata = list(estimator = "OLS with intercept", vcov = "Cameron-Gelbach-Miller two-way cluster-robust HC0, clustered by firm and year"),
  diagnostics = list()
)

json_escape <- function(x) {
  x <- gsub("\\\\", "\\\\\\\\", x)
  gsub('"', '\\\\"', x, fixed = TRUE)
}
json_num <- function(x) format(x, digits = 17, scientific = TRUE)
json <- paste0(
  '{"task_id":"', out$task_id, '","platform":"', out$platform, '","estimates":[',
  '{"term":"const","estimate":', json_num(b[1]), ',"se":', json_num(se[1]), ',"n_obs":', n, '},',
  '{"term":"x","estimate":', json_num(b[2]), ',"se":', json_num(se[2]), ',"n_obs":', n, '}',
  '],"method_metadata":{"estimator":"', json_escape(out$method_metadata$estimator), '","vcov":"', json_escape(out$method_metadata$vcov), '"},"diagnostics":{}}'
)
writeLines(json, "result.json")
