dat <- read.csv("input.csv", stringsAsFactors = FALSE)
stopifnot(all(c("id", "y", "x", "z") %in% names(dat)))
stopifnot(nrow(dat) == 420L, all(dat$y %in% 1:3), all(is.finite(dat$x)), all(is.finite(dat$z)))
dat$y <- as.integer(dat$y)
X <- cbind(dat$x, dat$z)
y <- dat$y
nll <- function(par) {
  b <- par[1:2]; c1 <- par[3]; c2 <- c1 + exp(par[4])
  eta <- drop(X %*% b)
  p1 <- plogis(c1 - eta)
  p2 <- plogis(c2 - eta) - p1
  p3 <- 1 - plogis(c2 - eta)
  p <- cbind(p1, p2, p3)[cbind(seq_len(nrow(dat)), y)]
  if (any(p <= 0)) return(1e100)
  -sum(log(p))
}
fit <- optim(c(0, 0, 0, 0), nll, method = "BFGS", hessian = TRUE,
             control = list(reltol = 1e-12, maxit = 2000))
stopifnot(fit$convergence == 0L)
par <- fit$par
co <- setNames(par[1:2], c("x", "z"))
v <- solve(fit$hessian)
se <- setNames(sqrt(diag(v))[1:2], names(co))
eta <- unname(co["x"])
c2 <- par[3] + exp(par[4])
prob_high <- plogis(eta - c2)

# Independent likelihood check with explicit ordered-logit probabilities.
check <- optim(par, nll, method = "Nelder-Mead", control = list(reltol = 1e-12, maxit = 5000))
stopifnot(check$convergence == 0L, max(abs(check$par - par)) < 1e-5)

# Independent identity check: manual category probabilities equal predict().
manual <- cbind(
  plogis(par[3] - drop(X %*% co)),
  plogis(c2 - drop(X %*% co)) - plogis(par[3] - drop(X %*% co)),
  1 - plogis(c2 - drop(X %*% co)))
stopifnot(max(rowSums(manual) - 1) < 1e-12)

out <- list(
  task_id = "broad_ordered_logit",
  platform = "r",
  estimates = list(
    list(term = "x", estimate = unname(co["x"]), se = unname(se["x"]), n_obs = nrow(dat)),
    list(term = "z", estimate = unname(co["z"]), se = unname(se["z"]), n_obs = nrow(dat)),
    list(term = "prob_high", estimate = unname(prob_high), se = NULL, n_obs = nrow(dat))
  ),
  method_metadata = list(estimator = "maximum likelihood ordered logit", vcov = "conventional observed information"),
  diagnostics = list(logLik = -fit$value, independent_nll = unname(check$value), max_manual_probability_difference = max(abs(rowSums(manual) - 1)))
)
jsonlite::write_json(out, "result.json", auto_unbox = TRUE, null = "null", digits = 17)

writeLines(c(
  paste0("Rows checked: ", nrow(dat), "; complete estimation sample: ", nrow(dat)),
  "Estimator: direct maximum-likelihood ordered logit with y ~ x + z and two free cutpoints.",
  paste0("Observed-information covariance dimension: ", paste(dim(v), collapse = "x"), "."),
  paste0("Independent explicit likelihood optimization convergence code: ", check$convergence,
         "; maximum parameter difference from primary optimizer = ", format(max(abs(check$par - par)), digits = 12), "."),
  paste0("Manual probability sum identity maximum absolute difference = ", format(max(abs(rowSums(manual) - 1)), digits = 12), "."),
  paste0("Manual prob_high at x=1,z=0 = ", format(prob_high, digits = 12), ".")
), "verification.txt")
