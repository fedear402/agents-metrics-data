#!/usr/bin/env Rscript

suppressPackageStartupMessages(library(jsonlite))

df <- read.csv("input.csv", stringsAsFactors = FALSE)
needed <- c("z", "d", "y")
if (!all(needed %in% names(df))) stop("input.csv must contain z, d, and y")
keep <- is.finite(df$z) & is.finite(df$y) & abs(df$z) <= 0.5
est <- df[keep, c("z", "y")]
est$side <- ifelse(est$z < 0, "left", "right")
if (any(est$z == 0)) stop("The cutoff observation must be assigned explicitly")
est$w <- 1 - abs(est$z) / 0.5

fit_side <- function(dat) {
  X <- cbind(1, dat$z)
  b <- solve(crossprod(X, dat$w * X), crossprod(X, dat$w * dat$y))
  as.numeric(b[1])
}

left <- est[est$side == "left", ]
right <- est[est$side == "right", ]
left_intercept <- fit_side(left)
right_intercept <- fit_side(right)
late <- right_intercept - left_intercept

out <- list(
  task_id = "rdd_sharp",
  platform = "r",
  estimates = list(list(term = "late", estimate = late, se = NA,
                        n_obs = nrow(est))),
  method_metadata = list(
    estimator = "local linear regression with triangular kernel, h = 0.5",
    vcov = "none"
  ),
  diagnostics = structure(list(), names = character(0))
)
write_json(out, "result.json", auto_unbox = TRUE, na = "null", digits = 17)
