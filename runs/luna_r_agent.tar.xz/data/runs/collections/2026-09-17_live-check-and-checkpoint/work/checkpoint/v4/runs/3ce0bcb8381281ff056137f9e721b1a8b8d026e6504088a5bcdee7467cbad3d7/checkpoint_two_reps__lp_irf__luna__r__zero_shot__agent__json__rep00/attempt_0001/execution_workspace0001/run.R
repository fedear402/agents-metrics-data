dat <- read.csv("input.csv", stringsAsFactors = FALSE)

# Construct the local-projection sample: y[t+4] on shock[t] and y[t-1].
n <- nrow(dat)
target <- dat$y[5:n]
shock_t <- dat$shock[1:(n - 4)]
y_lag1 <- dat$y[1:(n - 4)]
lp_t <- 1:(n - 4)
keep <- lp_t >= 2 & is.finite(target) & is.finite(shock_t) & is.finite(y_lag1)
df <- data.frame(target = target[keep], shock_t = shock_t[keep], y_lag1 = y_lag1[keep])

fit <- lm(target ~ shock_t + y_lag1, data = df)
X <- model.matrix(fit)
e <- residuals(fit)
Tn <- nrow(X)

# Bartlett Newey-West covariance with four lags, without finite-sample adjustment.
meat <- crossprod(X * e)
for (j in 1:4) {
  cross <- t(X[(j + 1):Tn, , drop = FALSE] * e[(j + 1):Tn]) %*%
    (X[1:(Tn - j), , drop = FALSE] * e[1:(Tn - j)])
  meat <- meat + (1 - j / 5) * (cross + t(cross))
}
vcov_nw <- solve(crossprod(X), meat) %*% solve(crossprod(X))
estimate <- unname(coef(fit)["shock_t"])
se <- sqrt(unname(vcov_nw["shock_t", "shock_t"]))

json <- sprintf('{"task_id":"lp_irf","platform":"r","estimates":[{"term":"irf_h4","estimate":%.17g,"se":%.17g,"n_obs":%d}],"method_metadata":{"estimator":"OLS local projection","vcov":"Newey-West HAC, Bartlett lag 4"},"diagnostics":{}}\n', estimate, se, Tn)
writeLines(json, "result.json")
