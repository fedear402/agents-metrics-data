library(jsonlite)

df <- read.csv("input.csv", stringsAsFactors = FALSE)
vars <- c("y_iv", "x1_iv", "z")
keep <- complete.cases(df[, vars])
d <- df[keep, vars]
n <- nrow(d)

# Structural regressors and excluded-instrument matrix.
X <- cbind(const = 1, x1_iv = d$x1_iv)
Z <- cbind(const = 1, z = d$z)
y <- d$y_iv

# Two-stage least squares: beta = (X'P_Z X)^(-1) X'P_Z y.
ZtZ_inv <- solve(crossprod(Z))
PZX <- Z %*% ZtZ_inv %*% crossprod(Z, X)
PZy <- Z %*% ZtZ_inv %*% crossprod(Z, y)
beta <- solve(crossprod(X, PZX), crossprod(X, PZy))
resid <- as.vector(y - X %*% beta)

# Heteroskedasticity-consistent HC1 covariance for 2SLS.
A <- crossprod(X, PZX)
W <- ZtZ_inv
Zu <- Z * resid
meat <- crossprod(Zu) # sum_i z_i z_i' u_i^2
B <- crossprod(X, Z) %*% W %*% meat %*% W %*% crossprod(Z, X)
vcov_hc1 <- (n / (n - ncol(X))) * solve(A) %*% B %*% solve(A)
se <- sqrt(pmax(diag(vcov_hc1), 0))

out <- list(
  task_id = "iv2sls_robust",
  platform = "r",
  estimates = list(
    list(term = "const", estimate = unname(beta[1]), se = unname(se[1]), n_obs = n),
    list(term = "x1_iv", estimate = unname(beta[2]), se = unname(se[2]), n_obs = n)
  ),
  method_metadata = list(estimator = "Two-stage least squares (2SLS)", vcov = "HC1 robust"),
  diagnostics = structure(list(), names = character(0))
)
write_json(out, "result.json", auto_unbox = TRUE, digits = 17)
