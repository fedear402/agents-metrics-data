d <- read.csv("input.csv", stringsAsFactors = FALSE)
stopifnot(identical(names(d), c("id", "y", "x", "z")))
stopifnot(all(d$y %in% c(1, 2, 3)), nrow(d) == 420L)
d$y <- ordered(d$y, levels = 1:3)

fit <- MASS::polr(y ~ x + z, data = d, method = "logistic", Hess = TRUE,
                  control = list(reltol = 1e-12, maxit = 2000))
V <- vcov(fit)
beta <- unname(coef(fit)[c("x", "z")])
se <- sqrt(diag(V)[c("x", "z")])
eta0 <- beta[1] * 1 + beta[2] * 0
prob_high <- plogis(eta0 - unname(fit$zeta[2]))

rows <- list(
  list(term = "x", estimate = unname(beta[1]), se = unname(se[1]), n_obs = nrow(d)),
  list(term = "z", estimate = unname(beta[2]), se = unname(se[2]), n_obs = nrow(d)),
  list(term = "prob_high", estimate = unname(prob_high), se = NULL, n_obs = nrow(d))
)
out <- list(task_id = "broad_ordered_logit", platform = "r", estimates = rows,
            method_metadata = list(estimator = "maximum-likelihood ordered logit with two free cutpoints and no intercept",
                                   vcov = "inverse observed information (Hessian of the log-likelihood)"),
            diagnostics = list(cutpoints = unname(fit$zeta)))
jsonlite::write_json(out, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)

# Independent checks: direct category-3 identity and an independently coded likelihood.
stopifnot(abs(prob_high - (1 - plogis(unname(fit$zeta[2]) - eta0))) < 1e-12)
ll <- function(p) {
  b <- p[1:2]; c1 <- p[3]; c2 <- c1 + exp(p[4])
  q1 <- plogis(c1 - (b[1] * d$x + b[2] * d$z))
  q2 <- plogis(c2 - (b[1] * d$x + b[2] * d$z))
  pr <- cbind(q1, q2 - q1, 1 - q2)
  -sum(log(pr[cbind(seq_len(nrow(d)), as.integer(d$y))]))
}
pfit <- c(beta, unname(fit$zeta[1]), log(unname(fit$zeta[2] - fit$zeta[1])))
stopifnot(abs(ll(pfit) + as.numeric(logLik(fit))) < 1e-8)
writeLines(c(
  paste0("Rows and estimation sample: ", nrow(d), "; all 420 rows used."),
  paste0("Categories: ", paste(sort(unique(as.integer(d$y))), collapse = ", "), "; x and z are used directly."),
  paste0("Independent probability identity check: direct plogis(eta - cutpoint2) = ", format(prob_high, digits = 16)),
  paste0("Independent likelihood check: coded negative log likelihood differs from -logLik by ", format(abs(ll(pfit) + as.numeric(logLik(fit))), scientific = TRUE)),
  paste0("Cutpoints: ", paste(format(unname(fit$zeta), digits = 16), collapse = ", "))
), "verification.txt")
