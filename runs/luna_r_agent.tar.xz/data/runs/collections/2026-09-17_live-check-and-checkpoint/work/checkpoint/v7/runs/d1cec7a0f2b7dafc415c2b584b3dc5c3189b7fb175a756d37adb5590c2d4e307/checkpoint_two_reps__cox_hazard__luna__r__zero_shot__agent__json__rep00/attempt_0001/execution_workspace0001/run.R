#!/usr/bin/env Rscript

options(stringsAsFactors = FALSE)
dat <- read.csv("input.csv", check.names = FALSE)
needed <- c("subject", "treat", "x", "t_obs", "event")
stopifnot(all(needed %in% names(dat)))
est_dat <- dat[complete.cases(dat[, c("treat", "x", "t_obs", "event")]), ]
stopifnot(all(est_dat$t_obs > 0), all(est_dat$event %in% c(0, 1)))

library(survival)
fit <- coxph(Surv(t_obs, event) ~ treat + x, data = est_dat,
             ties = "efron", model = TRUE, x = TRUE, y = TRUE)
co <- coef(fit)
se <- sqrt(diag(vcov(fit)))
n <- nrow(est_dat)

json_num <- function(x) format(x, digits = 17, scientific = TRUE, trim = TRUE)
result_text <- paste0(
  '{"task_id":"cox_hazard","platform":"r","estimates":[',
  '{"term":"treat","estimate":', json_num(co["treat"]),
  ',"se":', json_num(se["treat"]), ',"n_obs":', n, '},',
  '{"term":"x","estimate":', json_num(co["x"]),
  ',"se":', json_num(se["x"]), ',"n_obs":', n, '}],',
  '"method_metadata":{"estimator":"Cox proportional hazards partial likelihood (Efron ties)",',
  '"vcov":"model-based observed information"},"diagnostics":{}}')
writeLines(result_text, "result.json")

# Independent check: maximize the Efron partial log-likelihood directly.
z <- as.matrix(est_dat[, c("treat", "x")])
y <- est_dat$event
tt <- est_dat$t_obs
efron_loglik <- function(beta) {
  ord <- order(tt)
  tt_o <- tt[ord]; y_o <- y[ord]; z_o <- z[ord, , drop = FALSE]
  eta <- drop(z_o %*% beta); ee <- exp(eta)
  ll <- 0
  event_times <- sort(unique(tt_o[y_o == 1]))
  for (time in event_times) {
    deaths <- which(tt_o == time & y_o == 1)
    risk <- which(tt_o >= time)
    d <- length(deaths)
    sum_death_eta <- sum(eta[deaths])
    sum_death_exp <- sum(ee[deaths])
    for (j in 0:(d - 1)) ll <- ll + sum_death_eta / d -
      log(sum(ee[risk]) - j * sum_death_exp / d)
  }
  ll
}
direct <- optim(c(0, 0), function(b) -efron_loglik(b), method = "BFGS",
                control = list(reltol = 1e-12))
direct_beta <- direct$par
check_diff <- max(abs(direct_beta - unname(co[c("treat", "x")])))

writeLines(c(
  paste0("Rows in input: ", nrow(dat)),
  paste0("Complete-case estimation rows: ", n),
  paste0("Events in estimation sample: ", sum(est_dat$event)),
  "Estimator: survival::coxph with Efron ties and model-based observed-information SEs.",
  paste0("Independent check: direct optimization of the Efron partial log-likelihood.") ,
  paste0("coxph coefficients: ", paste(format(unname(co[c("treat", "x")]), digits=12), collapse = ", ")),
  paste0("direct coefficients: ", paste(format(direct_beta, digits=12), collapse = ", ")),
  paste0("maximum absolute coefficient difference: ", format(check_diff, digits=12)),
  paste0("Direct optimizer convergence code: ", direct$convergence)
), "verification.txt")
stopifnot(direct$convergence == 0, check_diff < 2e-6,
          all(is.finite(co)), all(is.finite(se)))
