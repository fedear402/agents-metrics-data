library(jsonlite)

df <- read.csv("input.csv", stringsAsFactors = FALSE)
vars <- c("y_lin", "x1", "x2")
keep <- complete.cases(df[, vars])
est <- df[keep, vars]
n <- nrow(est)
X <- cbind(const = 1, x1 = est$x1, x2 = est$x2)
y <- est$y_lin
fit <- lm(y ~ x1 + x2, data = est)
b <- coef(fit)
u <- residuals(fit)
k <- ncol(X)
bread <- solve(crossprod(X))
meat <- crossprod(X, X * as.numeric(u^2))
V_HC1 <- (n / (n - k)) * bread %*% meat %*% bread
se <- sqrt(diag(V_HC1))
terms <- c("const", "x1", "x2")
out <- list(
  task_id = "ols_robust",
  platform = "r",
  estimates = lapply(seq_along(terms), function(j) list(
    term = terms[j], estimate = unname(b[c("(Intercept)", "x1", "x2")[j]]),
    se = unname(se[j]), n_obs = n
  )),
  method_metadata = list(estimator = "OLS", vcov = "HC1 heteroskedasticity-robust"),
  diagnostics = structure(list(), names = character(0))
)
write_json(out, "result.json", auto_unbox = TRUE, digits = 15)
