library(jsonlite)

dat <- read.csv("input.csv", stringsAsFactors = FALSE)
vars <- c("firm", "year", "x", "y_twocluster")
dat <- dat[complete.cases(dat[, vars]), vars]

fit <- lm(y_twocluster ~ x, data = dat)
X <- model.matrix(fit)
u <- residuals(fit)
n <- nrow(X)

# Cameron-Gelbach-Miller two-way cluster covariance.
cluster_meat <- function(groups) {
  score <- X * as.numeric(u)
  sums <- rowsum(score, groups, reorder = FALSE)
  crossprod(sums)
}

bread <- solve(crossprod(X))
meat <- cluster_meat(dat$firm) + cluster_meat(dat$year) -
  cluster_meat(interaction(dat$firm, dat$year, drop = TRUE, lex.order = TRUE))
V <- bread %*% meat %*% bread
se <- sqrt(pmax(diag(V), 0))
co <- coef(fit)

out <- list(
  task_id = "two_way_cluster",
  platform = "r",
  estimates = list(
    list(term = "const", estimate = unname(co["(Intercept)"]),
         se = unname(se[1]), n_obs = n),
    list(term = "x", estimate = unname(co["x"]),
         se = unname(se[2]), n_obs = n)
  ),
  method_metadata = list(estimator = "OLS", vcov = "Cameron-Gelbach-Miller two-way cluster (firm, year)"),
  diagnostics = structure(list(), names = character(0))
)
write_json(out, "result.json", auto_unbox = TRUE, digits = 17)

