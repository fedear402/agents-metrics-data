dat <- read.csv("input.csv", stringsAsFactors = FALSE)
dat$date <- as.Date(dat$date)
dat <- dat[order(dat$date), ]
stopifnot(all(dat$sales > 0), all(dat$vix > 0), !anyDuplicated(dat$date))

n <- nrow(dat)
lv <- log(dat$vix)
d <- diff(lv)
ly <- log(dat$sales)

# At original observation i, lag j is d[i-j].
idx <- 17:n
y <- ly[idx]
X <- cbind(Intercept = 1, sapply(1:15, function(j) d[idx - j]))
colnames(X)[2:16] <- paste0("lag_", 1:15)
N <- nrow(X)
stopifnot(N == n - 16, all(dim(X) == c(N, 16)))

beta <- solve(crossprod(X), crossprod(X, y))
resid <- as.vector(y - X %*% beta)
XXi <- solve(crossprod(X))
scores <- X * resid
S <- crossprod(scores)
for (j in 1:15) {
  w <- 1 - j / 16
  Gj <- crossprod(scores[(j + 1):N, , drop = FALSE], scores[1:(N - j), , drop = FALSE])
  S <- S + w * (Gj + t(Gj))
}
V <- (N / (N - 16)) * XXi %*% S %*% XXi

cvec <- c(0, rep(1, 15))
cum <- sum(beta[2:16])
cum_se <- sqrt(as.numeric(t(cvec) %*% V %*% cvec))
lag1_se <- sqrt(V[2, 2])
lag15_se <- sqrt(V[16, 16])

fmt <- function(x) format(x, digits = 17, scientific = FALSE, trim = TRUE)
json <- paste0(
  '{\n',
  '  "task_id": "applied_cumulative_hac",\n',
  '  "platform": "r",\n',
  '  "estimates": [\n',
  '    {"term": "cumulative_response", "estimate": ', fmt(cum), ', "se": ', fmt(cum_se), ', "n_obs": ', N, '},\n',
  '    {"term": "lag_1", "estimate": ', fmt(beta[2]), ', "se": ', fmt(lag1_se), ', "n_obs": ', N, '},\n',
  '    {"term": "lag_15", "estimate": ', fmt(beta[16]), ', "se": ', fmt(lag15_se), ', "n_obs": ', N, '}\n',
  '  ],\n',
  '  "method_metadata": {"estimator": "OLS with intercept and 15 trading-observation lags", "vcov": "Newey-West HAC max lag 15, Bartlett weights, scaled by N/(N-16)"},\n',
  '  "diagnostics": {}\n',
  '}\n')
writeLines(json, "result.json")

# Independent checks: direct lag construction and an explicit score-loop HAC.
direct_lag1 <- d[idx - 1]
direct_lag15 <- d[idx - 15]
S2 <- matrix(0, 16, 16)
for (t in 1:N) S2 <- S2 + tcrossprod(scores[t, ])
for (j in 1:15) for (t in (j + 1):N) {
  w <- 1 - j / 16
  S2 <- S2 + w * (tcrossprod(scores[t, ], scores[t - j, ]) + tcrossprod(scores[t - j, ], scores[t, ]))
}
V2 <- (N / (N - 16)) * XXi %*% S2 %*% XXi
check <- c(
  paste("sorted_dates=", all(diff(dat$date) > 0)),
  paste("n_input=", n), paste("n_diff=", length(d)), paste("n_obs=", N),
  paste("lag1_construction_max_abs_error=", max(abs(X[, 2] - direct_lag1))),
  paste("lag15_construction_max_abs_error=", max(abs(X[, 16] - direct_lag15))),
  paste("cumulative_identity_abs_error=", abs(cum - sum(beta[2:16]))),
  paste("hac_loop_max_abs_error=", max(abs(V - V2))),
  paste("cumulative_se_from_full_covariance=", cum_se)
)
writeLines(check, "verification.txt")
