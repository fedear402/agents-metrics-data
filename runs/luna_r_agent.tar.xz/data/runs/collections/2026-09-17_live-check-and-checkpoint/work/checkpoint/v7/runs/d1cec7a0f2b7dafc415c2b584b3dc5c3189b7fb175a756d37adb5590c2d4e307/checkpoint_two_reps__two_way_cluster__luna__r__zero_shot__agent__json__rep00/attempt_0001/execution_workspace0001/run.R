dat <- read.csv("input.csv", stringsAsFactors = FALSE)

# OLS on the requested variables. Complete cases define the estimation sample.
keep <- complete.cases(dat[, c("y_twocluster", "x", "firm", "year")])
d <- dat[keep, c("y_twocluster", "x", "firm", "year")]
y <- d$y_twocluster
X <- cbind(const = 1, x = d$x)
n <- nrow(X)
beta <- solve(crossprod(X), crossprod(X, y))
u <- as.numeric(y - X %*% beta)

# Cameron-Gelbach-Miller inclusion-exclusion meat:
# firm clusters + year clusters - firm-by-year intersections.
cluster_meat <- function(g) {
  s <- rowsum(X * u, g, reorder = FALSE)
  crossprod(s)
}
meat <- cluster_meat(d$firm) + cluster_meat(d$year) -
  cluster_meat(interaction(d$firm, d$year, drop = TRUE))
 bread_inv <- solve(crossprod(X))
V <- bread_inv %*% meat %*% bread_inv
se <- sqrt(pmax(diag(V), 0))

out <- list(
  task_id = "two_way_cluster",
  platform = "r",
  estimates = list(
    list(term = "const", estimate = unname(beta[1]), se = unname(se[1]), n_obs = n),
    list(term = "x", estimate = unname(beta[2]), se = unname(se[2]), n_obs = n)
  ),
  method_metadata = list(
    estimator = "OLS with intercept",
    vcov = "Cameron-Gelbach-Miller two-way cluster-robust (firm + year - firm-by-year)"
  ),
  diagnostics = list()
)

json_escape <- function(z) {
  z <- gsub("\\\\", "\\\\\\\\", z)
  gsub('"', '\\\\"', z, fixed = TRUE)
}
num <- function(z) format(z, digits = 17, scientific = TRUE)
json <- paste0(
  '{"task_id":"two_way_cluster","platform":"r","estimates":[',
  '{"term":"const","estimate":', num(beta[1]), ',"se":', num(se[1]), ',"n_obs":', n, '},',
  '{"term":"x","estimate":', num(beta[2]), ',"se":', num(se[2]), ',"n_obs":', n, '}],',
  '"method_metadata":{"estimator":"OLS with intercept","vcov":"Cameron-Gelbach-Miller two-way cluster-robust (firm + year - firm-by-year)"},"diagnostics":{}}'
)
writeLines(json, "result.json")

# Independent checks: normal equations and an explicit cluster-sum loop.
normal_eq_error <- max(abs(crossprod(X, u)))
explicit <- matrix(0, 2, 2)
for (f in unique(d$firm)) {
  q <- colSums(X[d$firm == f, , drop = FALSE] * u[d$firm == f])
  explicit <- explicit + tcrossprod(q)
}
for (yr in unique(d$year)) {
  q <- colSums(X[d$year == yr, , drop = FALSE] * u[d$year == yr])
  explicit <- explicit + tcrossprod(q)
}
for (cell in unique(interaction(d$firm, d$year, drop = TRUE))) {
  q <- colSums(X[interaction(d$firm, d$year, drop = TRUE) == cell, , drop = FALSE] *
              u[interaction(d$firm, d$year, drop = TRUE) == cell])
  explicit <- explicit - tcrossprod(q)
}
vcov_check_error <- max(abs(explicit - meat))
writeLines(c(
  paste("Rows read:", nrow(dat), "complete-case estimation rows:", n),
  paste("Normal-equation max absolute error:", format(normal_eq_error, digits = 6)),
  paste("Independent explicit CGM meat max absolute difference:", format(vcov_check_error, digits = 6)),
  "Checks passed: complete cases were used; X includes an intercept and x; covariance uses firm + year - firm-by-year."
), "verification.txt")
