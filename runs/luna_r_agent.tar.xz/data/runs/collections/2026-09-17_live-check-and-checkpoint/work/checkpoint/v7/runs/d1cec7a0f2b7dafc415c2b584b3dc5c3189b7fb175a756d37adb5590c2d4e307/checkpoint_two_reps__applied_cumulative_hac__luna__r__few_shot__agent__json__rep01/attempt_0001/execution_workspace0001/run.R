options(stringsAsFactors = FALSE)

if (!requireNamespace("jsonlite", quietly = TRUE)) stop("jsonlite is required")

dat <- read.csv("input.csv", stringsAsFactors = FALSE)
dat$date <- as.Date(dat$date)
dat <- dat[order(dat$date), ]

dat$log_vix <- log(dat$vix)
dat$vol_change <- c(NA_real_, diff(dat$log_vix))
for (j in 1:15) {
  dat[[paste0("lag_", j)]] <- c(rep(NA_real_, j),
                                head(dat$vol_change, -j))
}
dat$log_sales <- log(dat$sales)
lag_names <- paste0("lag_", 1:15)
sample <- dat[complete.cases(dat[, c("log_sales", lag_names)]), ]

y <- sample$log_sales
X <- cbind(intercept = 1, as.matrix(sample[, lag_names]))
beta <- solve(crossprod(X), crossprod(X, y))
resid <- as.vector(y - X %*% beta)
N <- nrow(X)
p <- ncol(X)

# Bartlett Newey-West covariance, with the requested finite-sample correction.
scores <- X * resid
meat <- crossprod(scores)
for (j in 1:15) {
  g <- crossprod(scores[(j + 1):N, , drop = FALSE], scores[1:(N - j), , drop = FALSE])
  meat <- meat + (1 - j / 16) * (g + t(g))
}
bread <- solve(crossprod(X))
V <- (N / (N - 16)) * bread %*% meat %*% bread

# Independent HAC check: calculate each lag covariance by explicit row pairs.
meat_direct <- crossprod(scores)
for (j in 1:15) {
  for (t in (j + 1):N) {
    meat_direct <- meat_direct + (1 - j / 16) *
      (tcrossprod(scores[t, ], scores[t - j, ]) +
         tcrossprod(scores[t - j, ], scores[t, ]))
  }
}
hac_error <- max(abs(meat - meat_direct))
if (hac_error > 1e-10) stop("Independent HAC check failed")

contrast <- c(0, rep(1, 15))
est <- as.numeric(crossprod(contrast, beta))
se <- sqrt(as.numeric(t(contrast) %*% V %*% contrast))
rows <- list(
  list(term = "cumulative_response", estimate = est, se = se, n_obs = N),
  list(term = "lag_1", estimate = beta[2], se = sqrt(V[2, 2]), n_obs = N),
  list(term = "lag_15", estimate = beta[16], se = sqrt(V[16, 16]), n_obs = N)
)
result <- list(task_id = "applied_cumulative_hac", platform = "r",
               estimates = rows,
               method_metadata = list(
                 estimator = "OLS log(sales) on intercept and trading-observation lags 1-15 of diff(log(vix))",
                 vcov = "Bartlett Newey-West maximum lag 15, correction N/(N-16)"),
               diagnostics = list())
jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = 16,
                     pretty = TRUE, null = "null")

# Verification: direct normal equations and the equivalent contrast identity.
beta_direct <- solve(crossprod(X), t(X) %*% y)
identity_error <- abs(est - sum(beta[2:16]))
normal_equation_error <- max(abs(beta - beta_direct))
if (N != nrow(dat) - 16) stop("Unexpected usable sample size")
if (identity_error > 1e-12 || normal_equation_error > 1e-12) stop("Independent checks failed")
writeLines(c(
  paste("Sorted rows:", nrow(dat)),
  paste("Usable sample N:", N, "= total rows minus 16"),
  paste("First usable date:", as.character(sample$date[1])),
  paste("Last usable date:", as.character(sample$date[N])),
  paste("Lag construction:", "lag_j[t] = log(vix[t-j]) - log(vix[t-j-1])"),
  paste("Independent check 1, cumulative identity error:", format(identity_error, digits = 16)),
  paste("Independent check 2, normal-equation coefficient error:", format(normal_equation_error, digits = 16)),
  paste("Independent check 3, HAC meat matrix error:", format(hac_error, digits = 16)),
  paste("Cumulative estimate:", format(est, digits = 16)),
  paste("Cumulative HAC SE:", format(se, digits = 16))
), "verification.txt")
