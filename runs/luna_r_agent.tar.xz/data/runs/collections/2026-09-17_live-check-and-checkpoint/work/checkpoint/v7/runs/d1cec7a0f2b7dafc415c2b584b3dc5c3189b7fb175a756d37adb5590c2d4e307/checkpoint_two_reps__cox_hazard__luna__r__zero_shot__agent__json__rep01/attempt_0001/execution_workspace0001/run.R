#!/usr/bin/env Rscript

options(stringsAsFactors = FALSE)
dat <- read.csv("input.csv", check.names = FALSE)
required <- c("subject", "treat", "x", "t_obs", "event")
if (!all(required %in% names(dat))) stop("Required columns are missing")

estimation_data <- dat[complete.cases(dat[, c("treat", "x", "t_obs", "event")]), ]
if (any(estimation_data$t_obs <= 0)) stop("Cox times must be positive")
if (!all(estimation_data$event %in% c(0, 1))) stop("event must be binary")

if (!requireNamespace("survival", quietly = TRUE)) stop("Package survival is required")
fit <- survival::coxph(survival::Surv(t_obs, event) ~ treat + x,
                       data = estimation_data, ties = "efron", x = TRUE)
co <- stats::coef(fit)
se <- sqrt(diag(stats::vcov(fit)))
terms <- c("treat", "x")
n <- nrow(estimation_data)
out <- list(
  task_id = "cox_hazard",
  platform = "r",
  estimates = lapply(terms, function(term) {
    list(term = term, estimate = unname(as.numeric(co[term])),
         se = unname(as.numeric(se[term])), n_obs = as.integer(n))
  }),
  method_metadata = list(estimator = "Cox proportional-hazards partial likelihood (Efron ties)",
                         vcov = "model-based inverse observed information"),
  diagnostics = list(n_input = as.integer(nrow(dat)), n_estimation = as.integer(n),
                     n_events = as.integer(sum(estimation_data$event)))
)
if (!requireNamespace("jsonlite", quietly = TRUE)) stop("Package jsonlite is required")
jsonlite::write_json(out, "result.json", auto_unbox = TRUE, digits = 17,
                     na = "null", pretty = TRUE)
