dat <- read.csv("input.csv", stringsAsFactors = FALSE)
dat$date <- as.Date(dat$date)
dat <- dat[order(dat$date), ]
stopifnot(all(dat$sales > 0), all(dat$vix > 0), all(diff(dat$date) > 0))
z <- diff(log(dat$vix)); y_all <- log(dat$sales); n_all <- length(y_all)
first <- 17L; idx <- first:n_all; y <- y_all[idx]
Xlags <- sapply(1:15, function(k) z[idx-k]); colnames(Xlags) <- paste0("lag_",1:15)
X <- cbind(`(Intercept)`=1, Xlags); n <- nrow(X); stopifnot(n == n_all-16L)
fit <- lm.fit(X,y); beta <- as.numeric(fit$coefficients); e <- as.numeric(y-X%*%beta)
Xe <- sweep(X, 1, e, "*")
XtX_inv <- solve(crossprod(X)); S <- crossprod(Xe)
for (j in 1:15) {
  A <- crossprod(Xe[(j+1):n,,drop=FALSE], Xe[1:(n-j),,drop=FALSE])
  S <- S + (1-j/16)*(A+t(A))
}
V <- (n/(n-16))*XtX_inv%*%S%*%XtX_inv
cvec <- c(0,rep(1,15)); cum <- sum(beta[2:16]); se_cum <- sqrt(as.numeric(t(cvec)%*%V%*%cvec))
se1 <- sqrt(V[2,2]); se15 <- sqrt(V[16,16])
fmt <- function(x) format(x, scientific=FALSE, digits=17, trim=TRUE)
writeLines(c('{','  "task_id": "applied_cumulative_hac",','  "platform": "r",','  "estimates": [',
 sprintf('    {"term": "cumulative_response", "estimate": %s, "se": %s, "n_obs": %d},',fmt(cum),fmt(se_cum),n),
 sprintf('    {"term": "lag_1", "estimate": %s, "se": %s, "n_obs": %d},',fmt(beta[2]),fmt(se1),n),
 sprintf('    {"term": "lag_15", "estimate": %s, "se": %s, "n_obs": %d}',fmt(beta[16]),fmt(se15),n),
 '  ],','  "method_metadata": {"estimator": "OLS with intercept and lags 1-15 of diff(log(vix))", "vcov": "Newey-West HAC max lag 15, Bartlett weights, scaled by N/(N-16)"},','  "diagnostics": {}','}'), 'result.json')
# Independent checks: coefficient identity and explicit double-sum HAC.
V_loop <- matrix(0,16,16)
for (a in 1:n) for (b in 1:n) { d <- a-b; if (abs(d)<=15) V_loop <- V_loop + (if(d==0) 1 else 1-abs(d)/16)*tcrossprod(X[a,]*e[a],X[b,]*e[b]) }
V_loop <- n/(n-16)*XtX_inv%*%V_loop%*%XtX_inv
writeLines(c(sprintf('Rows in input: %d',n_all),sprintf('Complete-case regression observations: %d (rows %d through %d)',n,first,n_all),sprintf('First volatility change: %.17g',z[1]),sprintf('Cumulative coefficient: %.17g',cum),sprintf('Cumulative identity check absolute difference: %.3g',abs(cum-sum(beta[2:16]))),sprintf('Explicit double-sum HAC max covariance difference: %.3g',max(abs(V-V_loop))),sprintf("SE identity check sqrt(c' V c): %.17g",se_cum)), 'verification.txt')
