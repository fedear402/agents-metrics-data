data <- read.csv("input.csv", stringsAsFactors = FALSE)
data <- data[order(data$time), ]
stopifnot(nrow(data) == 250L, identical(as.integer(data$time), 1:250))
y <- data$y

forecast <- numeric(150L)
for (f in 101:250) {
  s <- (f - 99):(f - 1)
  fit <- lm(y[s] ~ y[s - 1])
  forecast[f - 100L] <- unname(coef(fit)[1L] + coef(fit)[2L] * y[f - 1L])
  stopifnot(length(s) == 99L, nobs(fit) == 99L)
}

errors <- y[101:250] - forecast
rmse <- sqrt(sum(errors^2) / length(errors))
needed <- c(101L, 150L, 200L, 250L)
terms <- list(
  list(term = "rmse", estimate = unname(rmse), se = NULL, n_obs = 150L),
  list(term = "forecast_101", estimate = unname(forecast[1L]), se = NULL, n_obs = 99L),
  list(term = "forecast_150", estimate = unname(forecast[50L]), se = NULL, n_obs = 99L),
  list(term = "forecast_200", estimate = unname(forecast[100L]), se = NULL, n_obs = 99L),
  list(term = "forecast_250", estimate = unname(forecast[150L]), se = NULL, n_obs = 99L)
)

result <- list(
  task_id = "hard_rolling",
  platform = "r",
  estimates = terms,
  method_metadata = list(estimator = "rolling OLS AR(1) with intercept", vcov = "none"),
  diagnostics = list()
)
if (!requireNamespace("jsonlite", quietly = TRUE)) stop("jsonlite is required")
writeLines(jsonlite::toJSON(result, auto_unbox = TRUE, null = "null", digits = 17), "result.json")
