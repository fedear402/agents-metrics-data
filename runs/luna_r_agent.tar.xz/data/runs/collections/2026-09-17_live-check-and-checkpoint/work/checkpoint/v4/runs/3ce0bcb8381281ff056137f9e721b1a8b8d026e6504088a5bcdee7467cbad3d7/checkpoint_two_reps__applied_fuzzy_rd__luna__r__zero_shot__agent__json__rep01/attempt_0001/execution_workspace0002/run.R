dat <- read.csv("input.csv")
keep <- abs(dat$score) < 1
d <- dat[keep, ]
x <- d$score
side <- as.numeric(x >= 0)
w <- 1 - abs(x)
X <- cbind(1, side, x, side*x)

fit_hc0 <- function(y) {
  A <- crossprod(X, w * X)
  bh <- solve(A, crossprod(X, w * y))
  e <- as.numeric(y - X %*% bh)
  meat <- matrix(0, 4, 4)
  for (i in seq_along(y)) {
    z <- X[i, ]
    meat <- meat + w[i]^2 * e[i]^2 * tcrossprod(z)
  }
  V <- solve(A, meat) %*% solve(A)
  list(beta=bh, V=V, residual=e)
}

fy <- fit_hc0(d$earnings)
fp <- fit_hc0(d$participated)
rf <- fy$beta[2]
fs <- fp$beta[2]
se_rf <- sqrt(fy$V[2,2])
se_fs <- sqrt(fp$V[2,2])

cross_meat <- matrix(0, 4, 4)
for (i in seq_len(nrow(d))) {
  z <- X[i, ]
  cross_meat <- cross_meat + w[i]^2 * fy$residual[i] * fp$residual[i] * tcrossprod(z)
}
A <- crossprod(X, w * X)
cross_V <- solve(A) %*% cross_meat %*% solve(A)
cov_rf_fs <- cross_V[2,2]

te <- rf / fs
var_te <- se_rf^2 / fs^2 + rf^2 * se_fs^2 / fs^4 - 2 * rf * cov_rf_fs / fs^3
se_te <- sqrt(max(0, var_te))

out <- list(
  task_id="applied_fuzzy_rd", platform="r",
  estimates=list(
    list(term="treatment_effect", estimate=unname(te), se=unname(se_te), n_obs=nrow(d)),
    list(term="reduced_form", estimate=unname(rf), se=unname(se_rf), n_obs=nrow(d)),
    list(term="first_stage", estimate=unname(fs), se=unname(se_fs), n_obs=nrow(d))
  ),
  method_metadata=list(estimator="fuzzy local-linear RD, triangular kernel, bandwidth 1", vcov="HC0 fixed-sample weighted least squares; delta method with joint covariance"),
  diagnostics=list(covariance_rf_first_stage=unname(cov_rf_fs))
)
if (requireNamespace("jsonlite", quietly=TRUE)) {
  writeLines(jsonlite::toJSON(out, auto_unbox=TRUE, digits=17, pretty=TRUE), "result.json")
} else stop("jsonlite is required")
