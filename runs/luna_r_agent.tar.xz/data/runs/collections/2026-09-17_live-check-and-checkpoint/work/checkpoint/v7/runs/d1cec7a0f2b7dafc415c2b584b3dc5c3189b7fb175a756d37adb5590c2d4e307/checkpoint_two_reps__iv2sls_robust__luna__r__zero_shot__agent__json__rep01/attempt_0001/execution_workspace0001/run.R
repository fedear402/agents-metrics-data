dat <- read.csv("input.csv", stringsAsFactors = FALSE)
vars <- c("y_iv", "x1_iv", "z")
keep <- complete.cases(dat[, vars])
d <- dat[keep, vars]

fit <- ivreg::ivreg(y_iv ~ x1_iv | z, data = d)
V <- sandwich::vcovHC(fit, type = "HC1")
co <- stats::coef(fit)
se <- sqrt(diag(V))
n <- nrow(d)

out <- list(
  task_id = "iv2sls_robust",
  platform = "r",
  estimates = list(
    list(term = "const", estimate = unname(co[["(Intercept)"]]), se = unname(se[["(Intercept)"]]), n_obs = n),
    list(term = "x1_iv", estimate = unname(co[["x1_iv"]]), se = unname(se[["x1_iv"]]), n_obs = n)
  ),
  method_metadata = list(estimator = "2SLS (ivreg)", vcov = "HC1 heteroskedasticity-robust"),
  diagnostics = structure(list(), names = character(0))
)
jsonlite::write_json(out, "result.json", auto_unbox = TRUE, digits = 17)

# Independent verification: direct projection-matrix 2SLS and HC1 sandwich.
y <- d$y_iv
X <- cbind(const = 1, x1_iv = d$x1_iv)
Z <- cbind(const = 1, z = d$z)
PZ <- Z %*% solve(crossprod(Z)) %*% t(Z)
beta_direct <- solve(crossprod(X, PZ %*% X), crossprod(X, PZ %*% y))
e <- as.vector(y - X %*% beta_direct)
B <- solve(crossprod(X, PZ %*% X))
M <- crossprod(X, PZ %*% (diag(e^2) %*% PZ) %*% X)
V_direct <- (n / (n - ncol(X))) * B %*% M %*% B
se_direct <- sqrt(diag(V_direct))

writeLines(c(
  sprintf("observations: %d", n),
  sprintf("complete_case_check: %s", all(keep)),
  sprintf("ivreg_coefficients: %.15g %.15g", co[["(Intercept)"]], co[["x1_iv"]]),
  sprintf("direct_2sls_coefficients: %.15g %.15g", beta_direct[1], beta_direct[2]),
  sprintf("coefficient_max_abs_difference: %.15g", max(abs(co - beta_direct))),
  sprintf("ivreg_HC1_se: %.15g %.15g", se[1], se[2]),
  sprintf("direct_HC1_se: %.15g %.15g", se_direct[1], se_direct[2]),
  sprintf("se_max_abs_difference: %.15g", max(abs(se - se_direct))),
  "construction: intercept and x1_iv are the structural regressors; intercept and z form the instrument matrix.",
  "result: direct 2SLS and HC1 calculations agree with ivreg::ivreg and sandwich::vcovHC."
), "verification.txt")
