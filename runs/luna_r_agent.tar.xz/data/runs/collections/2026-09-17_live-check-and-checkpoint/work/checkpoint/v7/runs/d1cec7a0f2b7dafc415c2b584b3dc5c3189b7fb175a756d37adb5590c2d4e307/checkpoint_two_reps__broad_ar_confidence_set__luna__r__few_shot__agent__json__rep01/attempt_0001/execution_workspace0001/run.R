d <- read.csv("input.csv")
n <- nrow(d)
stopifnot(n == 240L, all(c("y", "endog", "x", "z1", "z2") %in% names(d)))
q <- 2L
df <- n - 4L
Xr <- cbind(1, d$x)
Xu <- cbind(1, d$x, d$z1, d$z2)
ssr <- function(v, X) sum((v - X %*% qr.coef(qr(X), v))^2)
critical <- qf(0.95, q, df)
k <- 1 + q * critical / df
quad <- function(beta) ssr(d$y - beta * d$endog, Xr) - k * ssr(d$y - beta * d$endog, Xu)
A <- (quad(1) + quad(-1) - 2 * quad(0)) / 2
B <- (quad(1) - quad(-1)) / 2
C <- quad(0)
roots <- sort(polyroot(c(C, B, A)))
stopifnot(max(abs(Im(roots))) < 1e-8, B^2 - 4 * A * C > 0)
bounds <- Re(roots)
accepts <- function(beta) quad(beta) <= 0
ar_f <- function(beta) {
  rr <- ssr(d$y - beta * d$endog, Xr)
  uu <- ssr(d$y - beta * d$endog, Xu)
  ((rr - uu) / q) / (uu / df)
}
direct_f <- function(beta) {
  v <- d$y - beta * d$endog
  rr <- deviance(lm(v ~ d$x))
  uu <- deviance(lm(v ~ d$x + d$z1 + d$z2))
  ((rr - uu) / q) / (uu / df)
}
stopifnot(abs(ar_f(1) - direct_f(1)) < 1e-9)
stopifnot(max(abs(vapply(bounds, direct_f, numeric(1)) - critical)) < 1e-7)
if (!requireNamespace("jsonlite", quietly = TRUE)) stop("jsonlite is required")
rows <- list(
  list(term="boundary_low", estimate=unname(bounds[1]), se=NULL, n_obs=n),
  list(term="boundary_high", estimate=unname(bounds[2]), se=NULL, n_obs=n),
  list(term="accepts_zero", estimate=as.numeric(accepts(0)), se=NULL, n_obs=n),
  list(term="unbounded", estimate=as.numeric(A < 0), se=NULL, n_obs=n),
  list(term="ar_f_at_one", estimate=ar_f(1), se=NULL, n_obs=n)
)
out <- list(task_id="broad_ar_confidence_set", platform="r", estimates=rows,
            method_metadata=list(estimator="Anderson-Rubin inverted homoskedastic joint F test",
                                 vcov="homoskedastic OLS residual variance"), diagnostics=list())
jsonlite::write_json(out, "result.json", auto_unbox=TRUE, null="null", digits=16, pretty=TRUE)
identity_error <- max(abs(c(quad(-1), quad(0), quad(1)) - c(A-B+C, C, A+B+C)))
writeLines(c(sprintf("n=%d; df=%d; q=%d", n, df, q),
  sprintf("critical_F=%.15g", critical), sprintf("quadratic A=%.15g B=%.15g C=%.15g", A, B, C),
  sprintf("bounds=%.15g, %.15g", bounds[1], bounds[2]),
  sprintf("direct_lm_F_at_one=%.15g; quadratic_F_at_one=%.15g", direct_f(1), ar_f(1)),
  sprintf("direct_lm_F_at_bounds=%.15g, %.15g", direct_f(bounds[1]), direct_f(bounds[2])),
  sprintf("quadratic_identity_max_error=%.3g", identity_error),
  sprintf("accepts_zero=%d; set_is_bounded=%s", as.integer(accepts(0)), ifelse(A > 0, "yes", "no"))),
  "verification.txt")
