library(survival)
library(jsonlite)

df <- read.csv("input.csv", stringsAsFactors = FALSE)
vars <- c("treat", "x", "t_obs", "event")
df <- df[complete.cases(df[, vars]), ]
fit <- coxph(Surv(t_obs, event) ~ treat + x, data = df,
             ties = "efron", model = TRUE, x = TRUE, y = TRUE)
co <- coef(fit)
se <- sqrt(diag(vcov(fit)))
out <- list(
  task_id = "cox_hazard",
  platform = "r",
  estimates = list(
    list(term = "treat", estimate = unname(co["treat"]), se = unname(se["treat"]), n_obs = nrow(df)),
    list(term = "x", estimate = unname(co["x"]), se = unname(se["x"]), n_obs = nrow(df))
  ),
  method_metadata = list(estimator = "Cox proportional hazards regression",
                         vcov = "model-based observed information"),
  diagnostics = structure(list(), names = character(0))
)
write_json(out, "result.json", auto_unbox = TRUE, digits = 17)

# Independent check: evaluate the Efron partial-likelihood score at the fit.
# For each event time, remove censored observations at that time from the risk
# set, and average tied event covariates over the Efron fractional risk sets.
z <- as.matrix(df[, c("treat", "x")])
eta <- drop(z %*% co)
score <- c(0, 0)
for (tt in sort(unique(df$t_obs[df$event == 1]))) {
  deaths <- which(df$t_obs == tt & df$event == 1)
  risk <- which(df$t_obs >= tt)
  m <- length(deaths)
  dsum <- colSums(z[deaths, , drop = FALSE])
  for (j in 0:(m - 1)) {
    frac <- j / m
    denom <- sum(exp(eta[risk])) - frac * sum(exp(eta[deaths]))
    numer <- colSums(z[risk, , drop = FALSE] * exp(eta[risk])) -
      frac * colSums(z[deaths, , drop = FALSE] * exp(eta[deaths]))
    score <- score + dsum / m - numer / denom
  }
}
writeLines(c(
  paste("rows_used", nrow(df)),
  paste("events", sum(df$event == 1)),
  paste("coxph_coefficients", paste(format(co, digits = 16), collapse = ", ")), 
  paste("coxph_standard_errors", paste(format(se, digits = 16), collapse = ", ")),
  paste("independent_efron_score_at_estimate", paste(format(score, digits = 8), collapse = ", ")),
  paste("max_abs_score", format(max(abs(score)), digits = 8))
), "verification.txt")
