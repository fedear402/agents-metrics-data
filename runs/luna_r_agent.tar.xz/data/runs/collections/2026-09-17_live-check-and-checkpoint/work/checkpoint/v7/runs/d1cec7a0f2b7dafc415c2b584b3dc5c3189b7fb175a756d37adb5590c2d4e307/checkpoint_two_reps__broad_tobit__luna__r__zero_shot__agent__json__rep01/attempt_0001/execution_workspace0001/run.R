dat <- read.csv("input.csv", stringsAsFactors = FALSE)
stopifnot(all(c("id", "y", "x", "z") %in% names(dat)), nrow(dat) == 400)
X <- cbind(1, dat$x, dat$z)
y <- dat$y
if (any(y < 0) || any(!is.finite(y))) stop("Invalid outcome")
cens <- y == 0

ll <- function(par) {
  b <- par[1:3]
  sig <- exp(par[4])
  eta <- drop(X %*% b)
  out <- numeric(length(y))
  out[!cens] <- dnorm((y[!cens] - eta[!cens]) / sig, log = TRUE) - log(sig)
  out[cens] <- pnorm(-eta[cens] / sig, log.p = TRUE)
  sum(out)
}
obj <- function(par) -ll(par)
start <- c(coef(lm(y ~ x + z, data = dat)), log(sd(y)))
fit <- optim(start, obj, method = "BFGS", hessian = TRUE,
             control = list(reltol = 1e-12, maxit = 10000))
if (fit$convergence != 0) stop("optim did not converge")

# Refine with nlminb and use its solution for the reported estimates.
fit2 <- nlminb(fit$par, obj, control = list(eval.max = 10000, iter.max = 10000,
                                             rel.tol = 1e-12, x.tol = 1e-12))
par <- fit2$par
H <- optimHess(par, obj)
V <- solve(H)
if (any(!is.finite(V))) stop("Non-finite observed information inverse")
separ <- sqrt(pmax(0, diag(V)))
beta <- par[1:3]
sigma <- exp(par[4])
ses <- c(separ[1:3], sigma * separ[4])

est <- data.frame(term = c("const", "x", "z", "sigma"),
                  estimate = c(beta, sigma), se = c(ses[1:3], NA_real_),
                  n_obs = nrow(dat))
json_num <- function(x) ifelse(is.na(x), "null", formatC(x, digits = 17, format = "fg", flag = "#"))
lines <- c('{', '  "task_id": "broad_tobit",', '  "platform": "r",', '  "estimates": [')
for (i in seq_len(nrow(est))) {
  comma <- if (i < nrow(est)) "," else ""
  lines <- c(lines, sprintf('    {"term": "%s", "estimate": %s, "se": %s, "n_obs": %d}%s',
                            est$term[i], json_num(est$estimate[i]), json_num(est$se[i]), est$n_obs[i], comma))
}
lines <- c(lines, '  ],',
           '  "method_metadata": {"estimator": "homoskedastic Gaussian Tobit MLE, left censoring at 0", "vcov": "inverse joint observed information"},',
           '  "diagnostics": {}', '}')
writeLines(lines, "result.json")

# Independent checks: alternate optimizer and numerical score at the solution.
fit_alt <- optim(par, obj, method = "Nelder-Mead", control = list(maxit = 50000, reltol = 1e-11))
eps <- 1e-5
score <- sapply(seq_along(par), function(j) {
  d <- numeric(length(par)); d[j] <- eps
  (ll(par + d) - ll(par - d)) / (2 * eps)
})
zeros <- sum(cens)
sink("verification.txt")
cat("Tobit verification checks\n")
cat(sprintf("Rows read: %d; zero-censored rows: %d; positive rows: %d\n", nrow(dat), zeros, sum(!cens)))
cat(sprintf("Regressors: intercept, x, z; all rows included: %s\n", nrow(dat) == 400))
cat(sprintf("Primary nlminb objective: %.15f; alternate Nelder-Mead objective: %.15f; difference: %.3e\n", fit2$objective, fit_alt$value, abs(fit2$objective-fit_alt$value)))
cat(sprintf("Maximum absolute finite-difference score at solution: %.3e\n", max(abs(score))))
cat(sprintf("Sigma positivity identity check: sigma=exp(logsigma)=%.15f\n", sigma))
cat("Observed-information covariance: inverse of numerical Hessian of the joint negative log likelihood.\n")
sink()
