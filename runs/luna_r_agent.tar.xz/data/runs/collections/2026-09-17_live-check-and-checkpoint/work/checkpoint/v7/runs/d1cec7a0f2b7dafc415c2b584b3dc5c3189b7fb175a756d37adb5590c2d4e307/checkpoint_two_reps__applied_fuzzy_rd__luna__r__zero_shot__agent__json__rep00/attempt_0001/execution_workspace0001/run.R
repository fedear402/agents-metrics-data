dat <- read.csv("input.csv", stringsAsFactors = FALSE)
keep <- abs(dat$score) < 1
d <- dat[keep, ]
n <- nrow(d)
side <- as.integer(d$score >= 0)
w <- 1 - abs(d$score)
Z <- cbind(left_int = 1 - side, left_score = d$score * (1 - side),
           right_int = side, right_score = d$score * side)
WZ <- Z * w
A <- solve(crossprod(Z, WZ))

fit_cov <- function(y, other) {
  bh <- A %*% crossprod(Z, w * y)
  e <- as.numeric(y - Z %*% bh)
  eo <- as.numeric(other - Z %*% (A %*% crossprod(Z, w * other)))
  meat <- matrix(0, 4, 4)
  cross <- matrix(0, 4, 4)
  for (i in seq_len(n)) {
    zz <- Z[i, , drop = FALSE]
    meat <- meat + (w[i]^2 * e[i]^2) * crossprod(zz)
    cross <- cross + (w[i]^2 * e[i] * eo[i]) * crossprod(zz)
  }
  list(beta = as.numeric(bh), vc = A %*% meat %*% A,
       cross = A %*% cross %*% A, resid = e)
}

fy <- fit_cov(d$earnings, d$participated)
fp <- fit_cov(d$participated, d$earnings)
c <- c(-1, 0, 1, 0)
rf <- sum(c * fy$beta)
fs <- sum(c * fp$beta)
vrf <- as.numeric(t(c) %*% fy$vc %*% c)
vfs <- as.numeric(t(c) %*% fp$vc %*% c)
covrf_fs <- as.numeric(t(c) %*% fy$cross %*% c)
te <- rf / fs
vte <- vrf / fs^2 + rf^2 * vfs / fs^4 - 2 * rf * covrf_fs / fs^3

out <- list(task_id = "applied_fuzzy_rd", platform = "r",
            estimates = list(
              list(term = "treatment_effect", estimate = te, se = sqrt(vte), n_obs = n),
              list(term = "reduced_form", estimate = rf, se = sqrt(vrf), n_obs = n),
              list(term = "first_stage", estimate = fs, se = sqrt(vfs), n_obs = n)),
            method_metadata = list(estimator = "fuzzy local-linear RD, triangular weights, bandwidth 1",
                                   vcov = "HC0 sandwich, joint delta method with cross-covariance"),
            diagnostics = list(covariance_reduced_first_stage = covrf_fs,
                               n_left = sum(side == 0), n_right = sum(side == 1)))
json_escape <- function(x) {
  if (requireNamespace("jsonlite", quietly = TRUE)) jsonlite::toJSON(x, auto_unbox = TRUE, digits = 17) else stop("jsonlite required")
}
writeLines(json_escape(out), "result.json")

# Independent checks: direct weighted regressions and the ratio identity.
lm_left_y <- lm(earnings ~ score, data = d[d$score < 0, ], weights = 1 - abs(d$score[d$score < 0]))
lm_right_y <- lm(earnings ~ score, data = d[d$score >= 0, ], weights = 1 - abs(d$score[d$score >= 0]))
direct_rf <- coef(lm_right_y)[1] - coef(lm_left_y)[1]
lm_left_p <- lm(participated ~ score, data = d[d$score < 0, ], weights = 1 - abs(d$score[d$score < 0]))
lm_right_p <- lm(participated ~ score, data = d[d$score >= 0, ], weights = 1 - abs(d$score[d$score >= 0]))
direct_fs <- coef(lm_right_p)[1] - coef(lm_left_p)[1]
writeLines(c(sprintf("Sample check: abs(score) < 1 gives n_obs=%d, left=%d, right=%d.", n, sum(side == 0), sum(side == 1)),
  sprintf("Independent weighted lm check: reduced_form difference = %.15g (script = %.15g), absolute difference = %.3g.", direct_rf, rf, abs(direct_rf-rf)),
  sprintf("Independent weighted lm check: first_stage difference = %.15g (script = %.15g), absolute difference = %.3g.", direct_fs, fs, abs(direct_fs-fs)),
  sprintf("Ratio identity check: treatment_effect = reduced_form / first_stage = %.15g.", rf/fs),
  sprintf("HC0 joint check: covariance(reduced_form, first_stage) = %.15g; delta-method SE = %.15g.", covrf_fs, sqrt(vte))), "verification.txt")
