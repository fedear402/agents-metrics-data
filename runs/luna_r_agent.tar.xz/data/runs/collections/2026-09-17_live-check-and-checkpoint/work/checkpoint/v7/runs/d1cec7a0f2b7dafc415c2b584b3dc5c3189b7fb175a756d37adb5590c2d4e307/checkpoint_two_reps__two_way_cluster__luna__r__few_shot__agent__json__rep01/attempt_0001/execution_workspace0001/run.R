#!/usr/bin/env Rscript

options(stringsAsFactors = FALSE)
suppressPackageStartupMessages(library(jsonlite))

df <- read.csv("input.csv", check.names = FALSE)
needed <- c("firm", "year", "x", "y_twocluster")
if (!all(needed %in% names(df))) stop("Required columns are missing")
ok <- complete.cases(df[, needed])
d <- df[ok, needed]
if (nrow(d) == 0L) stop("Empty estimation sample")

X <- cbind(const = 1, x = d$x)
y <- d$y_twocluster
beta <- solve(crossprod(X), crossprod(X, y))
u <- as.vector(y - X %*% beta)
scores <- X * u

cluster_meat <- function(g) {
  sums <- rowsum(scores, g, reorder = FALSE)
  crossprod(sums)
}

# Cameron-Gelbach-Miller two-way clustered meat:
# firm clusters + year clusters - firm-by-year intersection clusters.
M <- cluster_meat(d$firm) + cluster_meat(d$year) -
  cluster_meat(interaction(d$firm, d$year, drop = TRUE, lex.order = TRUE))
B <- solve(crossprod(X))
V <- B %*% M %*% B
se <- sqrt(pmax(diag(V), 0))

out <- list(
  task_id = "two_way_cluster",
  platform = "r",
  estimates = list(
    list(term = "const", estimate = unname(beta[1]), se = unname(se[1]), n_obs = nrow(d)),
    list(term = "x", estimate = unname(beta[2]), se = unname(se[2]), n_obs = nrow(d))
  ),
  method_metadata = list(estimator = "OLS", vcov = "Cameron-Gelbach-Miller two-way cluster (firm and year)"),
  diagnostics = structure(list(), names = character(0))
)
write_json(out, "result.json", auto_unbox = TRUE, digits = 17)
