#!/usr/bin/env Rscript

options(stringsAsFactors = FALSE)
suppressPackageStartupMessages({
  library(ivreg)
  library(sandwich)
})

dat <- read.csv("input.csv", check.names = FALSE)
vars <- c("y_iv", "x1_iv", "z")
dat <- dat[complete.cases(dat[, vars]), , drop = FALSE]

fit <- ivreg(y_iv ~ x1_iv | z, data = dat)
V <- vcovHC(fit, type = "HC1")
b <- coef(fit)
se <- sqrt(diag(V))
n <- nobs(fit)

out <- list(
  task_id = "iv2sls_robust",
  platform = "r",
  estimates = list(
    list(term = "const", estimate = unname(b["(Intercept)"]), se = unname(se["(Intercept)"]), n_obs = as.integer(n)),
    list(term = "x1_iv", estimate = unname(b["x1_iv"]), se = unname(se["x1_iv"]), n_obs = as.integer(n))
  ),
  method_metadata = list(estimator = "2SLS (ivreg)", vcov = "HC1 heteroskedasticity-robust"),
  diagnostics = list()
)

json_escape <- function(x) {
  x <- gsub("\\\\", "\\\\\\\\", x)
  x <- gsub('"', '\\"', x, fixed = TRUE)
  x
}
fmt <- function(x) formatC(x, digits = 15, format = "fg", flag = "#")
json <- paste0(
  '{\n',
  '  "task_id": "iv2sls_robust",\n',
  '  "platform": "r",\n',
  '  "estimates": [\n',
  '    {"term": "const", "estimate": ', fmt(out$estimates[[1]]$estimate), ', "se": ', fmt(out$estimates[[1]]$se), ', "n_obs": ', n, '},\n',
  '    {"term": "x1_iv", "estimate": ', fmt(out$estimates[[2]]$estimate), ', "se": ', fmt(out$estimates[[2]]$se), ', "n_obs": ', n, '}\n',
  '  ],\n',
  '  "method_metadata": {"estimator": "2SLS (ivreg)", "vcov": "HC1 heteroskedasticity-robust"},\n',
  '  "diagnostics": {}\n',
  '}\n'
)
writeLines(json, "result.json", useBytes = TRUE)
