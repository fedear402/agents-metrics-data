options(stringsAsFactors = FALSE)
dat <- read.csv("input.csv", check.names = FALSE)
stopifnot(all(c("region_id","industry_id","share","shock","region_weight","x","y") %in% names(dat)))

## Collapse to one observation per region and normalize weights once.
regions <- unique(dat[, c("region_id", "region_weight", "x", "y")])
stopifnot(nrow(regions) == length(unique(dat$region_id)))
regions$e <- regions$region_weight / sum(regions$region_weight)
sharemat <- xtabs(share ~ region_id + industry_id, dat)
shock_by_ind <- tapply(dat$shock, dat$industry_id, function(v) { stopifnot(max(abs(v-v[1])) < 1e-12); v[1] })
sharemat <- sharemat[as.character(regions$region_id), names(shock_by_ind), drop=FALSE]
stopifnot(max(abs(rowSums(sharemat)-1)) < 1e-8)
z <- drop(sharemat %*% shock_by_ind)

weighted_mean <- function(a, w) sum(w*a)
y0 <- regions$y - weighted_mean(regions$y, regions$e)
x0 <- regions$x - weighted_mean(regions$x, regions$e)
z0 <- z - weighted_mean(z, regions$e)
s <- drop(crossprod(regions$e, sharemat))
keep <- s > 0
s <- s[keep]; shocks <- shock_by_ind[keep]
aggregate0 <- function(v0) drop(crossprod(sharemat[,keep,drop=FALSE], regions$e*v0))/s
ybar <- aggregate0(y0); xbar <- aggregate0(x0); zbar <- aggregate0(z0)

iv_hc1 <- function(y, x, q, w, independent_n) {
  X <- cbind(1, x); Z <- cbind(1, q)
  cross <- crossprod(Z, w * X)
  beta <- solve(cross, crossprod(Z, w * y))
  resid <- drop(y - X %*% beta)
  scores <- Z * (w * resid)
  inv <- solve(cross)
  vc <- independent_n/(independent_n-2) * inv %*% crossprod(scores) %*% t(inv)
  c(estimate=beta[2], se=sqrt(vc[2,2]))
}
N <- length(s)
eff <- iv_hc1(ybar, xbar, shocks, s, N)
fs <- iv_hc1(xbar, zbar, shocks, s, N)

## Independent checks: direct regional weighted 2SLS slopes must match aggregation.
regional_iv <- function(y, x, q, w) {
  solve(crossprod(cbind(1,q), w*cbind(1,x)), crossprod(cbind(1,q),w*y))[2]
}
direct_effect <- regional_iv(regions$y, regions$x, z, regions$e)
direct_first <- lm.wfit(cbind(1,z), regions$x, w=regions$e)$coefficients[2]
stopifnot(abs(direct_effect-eff["estimate"]) < 1e-8)
stopifnot(abs(direct_first-regional_iv(regions$x,z, z, regions$e)) < 1e-6)
stopifnot(abs(sum(s)-1) < 1e-8)

json_row <- function(term, estimate, se, n) list(term=term, estimate=unname(as.numeric(estimate)), se=if(is.null(se)) NULL else unname(as.numeric(se)), n_obs=as.integer(n))
out <- list(task_id="applied_shift_share", platform="r",
            estimates=list(json_row("effect",eff["estimate"],eff["se"],N),
                           json_row("first_stage",fs["estimate"],fs["se"],N),
                           json_row("effective_shocks",1/sum(s^2),NULL,N)),
            method_metadata=list(estimator="weighted shock-level IV with regional intercept and exposure aggregation", vcov="shock-level HC1, N/(N-2), structural IV residuals"),
            diagnostics=list(n_regions=nrow(regions), n_industries=N, direct_effect=direct_effect, direct_first_stage=direct_first))
jsonlite::write_json(out, "result.json", auto_unbox=TRUE, null="null", digits=16, pretty=TRUE)
writeLines(c(
  paste("Regions:", nrow(regions), "unique regional observations."),
  paste("Industries used:", N, "with positive aggregate exposure; sum(s)=", format(sum(s), digits=16)),
  paste("Independent identity check, direct regional IV effect minus shock-level effect:", format(direct_effect-eff["estimate"], digits=16)),
  paste("Independent first-stage check, direct weighted OLS slope minus equivalent regional IV slope:", format(direct_first-regional_iv(regions$x,z,z,regions$e), digits=16)),
  paste("Effective shocks:", format(1/sum(s^2), digits=16))
), "verification.txt")
