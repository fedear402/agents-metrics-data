library(ivreg)
library(sandwich)
library(jsonlite)

df <- read.csv("input.csv", stringsAsFactors = FALSE)
vars <- c("y_iv", "x1_iv", "z")
est <- df[complete.cases(df[, vars]), vars]

fit <- ivreg(y_iv ~ x1_iv | z, data = est)
V <- vcovHC(fit, type = "HC1")
b <- coef(fit)
terms <- c("const", "x1_iv")
coef_names <- c("(Intercept)", "x1_iv")
estimates <- lapply(seq_along(terms), function(i) {
  list(term = terms[i], estimate = unname(b[coef_names[i]]),
       se = unname(sqrt(V[coef_names[i], coef_names[i]])), n_obs = nrow(est))
})

out <- list(
  task_id = "iv2sls_robust",
  platform = "r",
  estimates = estimates,
  method_metadata = list(estimator = "2SLS via ivreg", vcov = "HC1 heteroskedasticity-robust"),
  diagnostics = structure(list(), names = character(0))
)
write_json(out, "result.json", auto_unbox = TRUE, digits = 17)
