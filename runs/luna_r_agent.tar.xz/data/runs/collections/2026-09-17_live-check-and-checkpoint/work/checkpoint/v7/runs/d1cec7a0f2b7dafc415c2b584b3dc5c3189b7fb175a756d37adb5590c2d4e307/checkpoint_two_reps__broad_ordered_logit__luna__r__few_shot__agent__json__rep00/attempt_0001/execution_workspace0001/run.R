d <- read.csv("input.csv")
stopifnot(nrow(d) == 420L, all(c("id", "y", "x", "z") %in% names(d)))
stopifnot(all(d$y %in% 1:3), all(is.finite(d$x)), all(is.finite(d$z)))
d$y <- ordered(d$y, levels = 1:3)

fit <- MASS::polr(y ~ x + z, data = d, method = "logistic", Hess = TRUE,
                  control = list(reltol = 1e-12, maxit = 1000))
V <- vcov(fit)
co <- coef(fit)
se <- sqrt(diag(V)[c("x", "z")])
eta <- unname(co["x"] * 1 + co["z"] * 0)
prob_high <- 1 - plogis(unname(fit$zeta[2]) - eta)

# Independent checks: direct category probabilities sum to one, and the
# category-3 probability equals the stated logistic-CDF identity.
cuts <- unname(fit$zeta)
p <- c(plogis(cuts[1] - eta),
       plogis(cuts[2] - eta) - plogis(cuts[1] - eta),
       1 - plogis(cuts[2] - eta))
stopifnot(abs(sum(p) - 1) < 1e-12, abs(p[3] - prob_high) < 1e-12)

rows <- list(
  list(term = "x", estimate = unname(co["x"]), se = unname(se["x"]), n_obs = nrow(d)),
  list(term = "z", estimate = unname(co["z"]), se = unname(se["z"]), n_obs = nrow(d)),
  list(term = "prob_high", estimate = prob_high, se = NULL, n_obs = nrow(d))
)
jsonlite::write_json(list(task_id = "broad_ordered_logit", platform = "r",
                           estimates = rows,
                           method_metadata = list(estimator = "maximum-likelihood ordered logit with two free cutpoints",
                                                  vcov = "conventional observed information"),
                           diagnostics = structure(list(), names = character(0))),
                     "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)

writeLines(c(
  "Checks and results",
  paste("Rows read:", nrow(d)),
  paste("Complete estimation rows:", nrow(d)),
  paste("Categories:", paste(levels(d$y), collapse = ", ")), 
  paste("Cutpoints ordered:", cuts[1] < cuts[2]),
  paste("Category probabilities at x=1,z=0:", paste(format(p, digits=16), collapse=", ")),
  paste("Probability sum:", format(sum(p), digits=16)),
  paste("Independent identity check absolute difference:", format(abs(p[3] - prob_high), digits=16)),
  "The slope standard errors use the inverse Hessian returned by polr.",
  "The high-category probability uses 1 - logistic CDF(second cutpoint - linear predictor)."
), "verification.txt")
