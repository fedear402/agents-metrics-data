dat <- read.csv("input.csv", stringsAsFactors = FALSE)

keep <- abs(dat$score) < 1
d <- dat[keep, , drop = FALSE]
n <- nrow(d)
right <- as.numeric(d$score >= 0)
w <- 1 - abs(d$score)

# Common local-linear regression design. The coefficient on right is the jump.
X <- cbind(1, d$score, right, right * d$score)
W <- diag(w, nrow = n)
bread <- solve(crossprod(X, W %*% X))

fit_one <- function(y) {
  beta <- drop(bread %*% crossprod(X, w * y))
  e <- y - drop(X %*% beta)
  list(beta = beta, e = e)
}

fy <- fit_one(d$earnings)
fp <- fit_one(d$participated)
cvec <- c(0, 0, 1, 0)
rf <- sum(cvec * fy$beta)
fs <- sum(cvec * fp$beta)

# Joint HC0 covariance for the two jumps, including cross-outcome covariance.
meat <- function(e1, e2) crossprod(X * (w * e1), X * (w * e2))
Vyy <- bread %*% meat(fy$e, fy$e) %*% bread
Vpp <- bread %*% meat(fp$e, fp$e) %*% bread
Vyp <- bread %*% meat(fy$e, fp$e) %*% bread
joint <- matrix(c(
  drop(cvec %*% Vyy %*% cvec), drop(cvec %*% Vyp %*% cvec),
  drop(cvec %*% Vyp %*% cvec), drop(cvec %*% Vpp %*% cvec)
), 2, 2, byrow = TRUE)

te <- rf / fs
grad <- c(1 / fs, -rf / fs^2)
te_var <- drop(t(grad) %*% joint %*% grad)

# Independent identity check: recover the same jump from two weighted side fits.
side_jump <- function(y) {
  b0 <- coef(lm(y ~ d$score, subset = right == 0, weights = w))
  b1 <- coef(lm(y ~ d$score, subset = right == 1, weights = w))
  unname(b1[1] - b0[1])
}
stopifnot(n == sum(keep), abs(rf - side_jump(d$earnings)) < 1e-10,
          abs(fs - side_jump(d$participated)) < 1e-10)

row <- function(term, estimate, se) list(term = term, estimate = unname(as.numeric(estimate)),
  se = unname(as.numeric(se)), n_obs = as.integer(n))
out <- list(task_id = "applied_fuzzy_rd", platform = "r",
  estimates = list(row("treatment_effect", te, sqrt(te_var)),
                   row("reduced_form", rf, sqrt(joint[1,1])),
                   row("first_stage", fs, sqrt(joint[2,2]))),
  method_metadata = list(estimator = "weighted local-linear fuzzy RD, triangular kernel, cutoff 0, bandwidth 1",
                         vcov = "HC0 with joint cross-outcome covariance and delta method"),
  diagnostics = list(n_obs = n, n_left = sum(right == 0), n_right = sum(right == 1),
                     covariance_reduced_first = joint[1,2],
                     independent_side_fit_check = TRUE))
jsonlite::write_json(out, "result.json", auto_unbox = TRUE, digits = 16, pretty = TRUE)

writeLines(c(
  paste0("Sample check: n_obs = ", n, "; left = ", sum(right == 0), "; right = ", sum(right == 1), "."),
  paste0("Weight check: minimum = ", format(min(w), digits=16), "; maximum = ", format(max(w), digits=16), "."),
  paste0("Independent side-fit identity: reduced_form difference = ", format(rf - side_jump(d$earnings), digits=16), "; first_stage difference = ", format(fs - side_jump(d$participated), digits=16), "."),
  paste0("Joint HC0 check: covariance(reduced_form, first_stage) = ", format(joint[1,2], digits=16), "."),
  paste0("Delta-method check: treatment_effect = ", format(te, digits=16), "; SE = ", format(sqrt(te_var), digits=16), ".")
), "verification.txt")
