library(survival)
library(jsonlite)

df <- read.csv("input.csv", stringsAsFactors = FALSE)
vars <- c("treat", "x", "t_obs", "event")
df <- df[complete.cases(df[, vars]), vars]
fit <- coxph(Surv(t_obs, event) ~ treat + x, data = df,
             ties = "efron", model = TRUE)
co <- coef(fit)
se <- sqrt(diag(vcov(fit)))
n <- nrow(model.frame(fit))

out <- list(
  task_id = "cox_hazard",
  platform = "r",
  estimates = list(
    list(term = "treat", estimate = unname(co["treat"]),
         se = unname(se["treat"]), n_obs = n),
    list(term = "x", estimate = unname(co["x"]),
         se = unname(se["x"]), n_obs = n)
  ),
  method_metadata = list(estimator = "Cox proportional-hazards regression",
                         vcov = "model-based asymptotic information matrix"),
  diagnostics = structure(list(), names = character(0))
)
write_json(out, "result.json", auto_unbox = TRUE, digits = 17)
