dat <- read.csv("input.csv", check.names = FALSE)
v <- dat[, c("y", "endog", "x", "z1", "z2")]
n <- nrow(v)
stopifnot(n == 240, all(complete.cases(v)))

# Conventional homoskedastic excluded-instrument F statistic.
Xr <- cbind(1, v$x)
Xu <- cbind(1, v$x, v$z1, v$z2)
qr <- qr(Xr)
qu <- qr(Xu)
f_stat <- function(beta) {
  w <- v$y - beta * v$endog
  ssr_r <- sum((w - Xr %*% qr.coef(qr, w))^2)
  ssr_u <- sum((w - Xu %*% qr.coef(qu, w))^2)
  ((ssr_r - ssr_u) / 2) / (ssr_u / (n - 4))
}
crit <- qf(0.95, 2, n - 4)

# The numerator and denominator are quadratic functions of beta. Obtain
# exact polynomial coefficients from three evaluations, then solve F=crit.
poly_from_three <- function(fun) {
  vals <- sapply(c(-1, 0, 1), fun)
  # Values at -1, 0, 1 identify a + b*beta + c*beta^2.
  c(vals[2], (vals[3] - vals[1]) / 2, (vals[3] + vals[1] - 2*vals[2]) / 2)
}
num <- function(beta) {
  w <- v$y - beta * v$endog
  sum((w - Xr %*% qr.coef(qr, w))^2) - sum((w - Xu %*% qr.coef(qu, w))^2)
}
den <- function(beta) {
  w <- v$y - beta * v$endog
  sum((w - Xu %*% qr.coef(qu, w))^2)
}
pn <- poly_from_three(num)
pd <- poly_from_three(den)
peq <- pn - (2 * crit / (n - 4)) * pd
roots <- polyroot(peq)
roots <- sort(Re(roots[abs(Im(roots)) < 1e-7]))
stopifnot(length(roots) == 2)

accepts_zero <- as.numeric(f_stat(0) <= crit)
unbounded <- as.numeric(f_stat(1e8) <= crit || f_stat(-1e8) <= crit)
f_one <- f_stat(1)

esc <- function(x) if (is.null(x)) "null" else formatC(x, digits=17, format="fg", flag="#")
entry <- function(term, estimate) paste0('{"term":"', term, '","estimate":', esc(estimate), ',"se":null,"n_obs":', n, '}')
json <- paste0('{"task_id":"broad_ar_confidence_set","platform":"r","estimates":[',
  paste(c(entry("boundary_low", roots[1]), entry("boundary_high", roots[2]),
          entry("accepts_zero", accepts_zero), entry("unbounded", unbounded),
          entry("ar_f_at_one", f_one)), collapse=","),
  '],"method_metadata":{"estimator":"Anderson-Rubin inverted homoskedastic joint F test","vcov":"conventional homoskedastic OLS F statistic"},"diagnostics":{}}')
writeLines(json, "result.json")

# Independent checks: direct lm() residual sums and quadratic-root membership.
lm_f <- function(beta) {
  w <- v$y - beta*v$endog
  a <- lm(w ~ x, data=v)
  b <- lm(w ~ x + z1 + z2, data=v)
  ((deviance(a)-deviance(b))/2)/(deviance(b)/(n-4))
}
check <- c(
  sprintf("n_obs=%d; complete_cases=%s", n, all(complete.cases(v))),
  sprintf("F(1) matrix=%.15g; F(1) lm=%.15g; abs_diff=%.3g", f_one, lm_f(1), abs(f_one-lm_f(1))),
  sprintf("critical_F=%.15g; roots=(%.15g, %.15g)", crit, roots[1], roots[2]),
  sprintf("boundary_tests=(%.15g, %.15g); zero_accept=%d; unbounded=%d", f_stat(roots[1]), f_stat(roots[2]), accepts_zero, unbounded),
  sprintf("quadratic_identity_at_1=%.15g", polyval <- sum(peq * c(1,1,1)))
)
writeLines(check, "verification.txt")
