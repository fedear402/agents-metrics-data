dat <- read.csv("input.csv", stringsAsFactors = FALSE)
vars <- c("y_lin", "x1", "x2")
keep <- complete.cases(dat[, vars])
d <- dat[keep, vars]
n <- nrow(d)
X <- cbind(const = 1, x1 = d$x1, x2 = d$x2)
y <- d$y_lin
k <- ncol(X)

# OLS and HC1 covariance, computed directly from the estimation sample.
beta <- as.numeric(solve(crossprod(X), crossprod(X, y)))
names(beta) <- colnames(X)
resid <- as.vector(y - X %*% beta)
meat <- crossprod(X, X * resid^2)
vcov_hc1 <- solve(crossprod(X)) %*% meat %*% solve(crossprod(X)) * n / (n - k)
se <- sqrt(diag(vcov_hc1))

if (any(!is.finite(beta)) || any(!is.finite(se))) stop("Non-finite estimate or standard error")

if (!requireNamespace("jsonlite", quietly = TRUE)) stop("jsonlite is required")
estimates <- lapply(seq_along(beta), function(i) list(
  term = names(beta)[i], estimate = unname(beta[i]),
  se = unname(se[i]), n_obs = as.integer(n)
))
out <- list(
  task_id = "ols_robust", platform = "r", estimates = estimates,
  method_metadata = list(estimator = "OLS with intercept", vcov = "HC1 heteroskedasticity-robust")
)
json <- jsonlite::toJSON(out, auto_unbox = TRUE, digits = 17, pretty = TRUE)
json <- paste0(substr(json, 1, nchar(json) - 2),
               ",\n  \"diagnostics\": {}\n}\n")
writeLines(json, "result.json", useBytes = TRUE)
