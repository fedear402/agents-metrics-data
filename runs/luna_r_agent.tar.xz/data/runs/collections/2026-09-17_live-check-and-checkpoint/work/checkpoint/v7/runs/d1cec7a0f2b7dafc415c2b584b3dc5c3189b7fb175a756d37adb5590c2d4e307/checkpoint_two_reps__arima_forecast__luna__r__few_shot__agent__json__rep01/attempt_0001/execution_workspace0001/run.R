library(forecast)
library(jsonlite)

dat <- read.csv("input.csv", stringsAsFactors = FALSE)
stopifnot(all(c("t", "y") %in% names(dat)))
dat <- dat[order(dat$t), ]
y <- as.numeric(dat$y)
if (length(y) != 250L || any(!is.finite(y))) stop("Unexpected input series")

# Fit ARIMA(1,1,1) by exact maximum likelihood, with no mean or drift.
fit <- forecast::Arima(y, order = c(1, 1, 1), include.drift = FALSE,
                       include.mean = FALSE, method = "ML")
pr <- predict(fit, n.ahead = 1)
iv <- forecast::forecast(fit, h = 1, level = 95)
fc <- as.numeric(pr$pred[1])
lo <- as.numeric(iv$lower[1, 1])
hi <- as.numeric(iv$upper[1, 1])

out <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = list(
    list(term = "forecast", estimate = fc, se = NA, n_obs = length(y)),
    list(term = "lower_95", estimate = lo, se = NA, n_obs = length(y)),
    list(term = "upper_95", estimate = hi, se = NA, n_obs = length(y))
  ),
  method_metadata = list(estimator = "ARIMA(1,1,1) by maximum likelihood, no constant or drift",
                         vcov = "model-based Gaussian prediction interval"),
  diagnostics = structure(list(), names = character(0))
)
write_json(out, "result.json", auto_unbox = TRUE, na = "null", digits = 15)
