d <- read.csv("input.csv")
stopifnot(identical(names(d), c("y", "endog", "x", "z1", "z2")))
n <- nrow(d)
q <- 2L
df <- n - 4L
Xr <- cbind(1, d$x)
Xu <- cbind(1, d$x, d$z1, d$z2)
resid_ssr <- function(v, X) {
  e <- v - X %*% qr.solve(crossprod(X), crossprod(X, v))
  sum(e^2)
}
ry <- d$y - Xr %*% qr.solve(crossprod(Xr), crossprod(Xr, d$y))
rd <- d$endog - Xr %*% qr.solve(crossprod(Xr), crossprod(Xr, d$endog))
uy <- d$y - Xu %*% qr.solve(crossprod(Xu), crossprod(Xu, d$y))
ud <- d$endog - Xu %*% qr.solve(crossprod(Xu), crossprod(Xu, d$endog))
critical <- qf(0.95, q, df)
k <- q * critical / df
A <- sum(rd^2) - (1 + k) * sum(ud^2)
B <- -2 * (sum(ry * rd) - (1 + k) * sum(uy * ud))
C <- sum(ry^2) - (1 + k) * sum(uy^2)
disc <- B^2 - 4 * A * C
stopifnot(disc > 0, abs(A) > 1e-12)
bounds <- sort(Re(polyroot(c(C, B, A))))
accepts <- function(beta) A * beta^2 + B * beta + C <= 0
ar_f <- function(beta) {
  w <- d$y - beta * d$endog
  ((resid_ssr(w, Xr) - resid_ssr(w, Xu)) / q) /
    (resid_ssr(w, Xu) / df)
}
rows <- list(
  list(term="boundary_low", estimate=unname(bounds[1]), se=NULL, n_obs=n),
  list(term="boundary_high", estimate=unname(bounds[2]), se=NULL, n_obs=n),
  list(term="accepts_zero", estimate=as.numeric(accepts(0)), se=NULL, n_obs=n),
  list(term="unbounded", estimate=as.numeric(A < 0), se=NULL, n_obs=n),
  list(term="ar_f_at_one", estimate=unname(ar_f(1)), se=NULL, n_obs=n)
)
jsonlite::write_json(list(task_id="broad_ar_confidence_set", platform="r",
  estimates=rows, method_metadata=list(estimator="Anderson-Rubin homoskedastic joint F inversion", vcov="homoskedastic"),
  diagnostics=list(n=n, q=q, df=df, critical=critical, quadratic=c(A=A,B=B,C=C))
  ), "result.json", auto_unbox=TRUE, null="null", digits=16, pretty=TRUE)

# Independent check: direct lm residual sums of squares at beta=1.
direct_r <- deviance(lm(I(y - endog) ~ x, data=d))
direct_u <- deviance(lm(I(y - endog) ~ x + z1 + z2, data=d))
stopifnot(abs(ar_f(1) - ((direct_r-direct_u)/q)/(direct_u/df)) < 1e-10)
writeLines(c(
  paste0("n=", n, ", df=", df, ", q=", q),
  paste0("critical_F=", format(critical, digits=16)),
  paste0("quadratic_roots=", paste(format(bounds, digits=16), collapse=", ")),
  paste0("A_sign=", sign(A), ", accepts_zero=", as.numeric(accepts(0)), ", unbounded=", as.numeric(A < 0)),
  paste0("AR_F_at_1_matrix=", format(ar_f(1), digits=16)),
  paste0("AR_F_at_1_direct_lm=", format(((direct_r-direct_u)/q)/(direct_u/df), digits=16)),
  "Independent check passed: direct lm SSR calculation equals matrix calculation."
), "verification.txt")
