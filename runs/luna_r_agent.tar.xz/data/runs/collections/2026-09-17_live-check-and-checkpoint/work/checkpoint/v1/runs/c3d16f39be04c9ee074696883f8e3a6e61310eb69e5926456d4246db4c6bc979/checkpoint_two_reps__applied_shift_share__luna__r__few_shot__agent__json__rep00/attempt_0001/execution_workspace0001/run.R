options(stringsAsFactors = FALSE)
dat <- read.csv("input.csv", check.names = FALSE)
regions <- unique(dat$region_id)
reg <- do.call(rbind, lapply(regions, function(r) {
  d <- dat[dat$region_id == r, ]
  c(region_id=as.character(r), region_weight=d$region_weight[1], x=d$x[1], y=d$y[1])
}))
reg <- as.data.frame(reg); reg$region_weight <- as.numeric(reg$region_weight)
reg$x <- as.numeric(reg$x); reg$y <- as.numeric(reg$y)
e <- reg$region_weight / sum(reg$region_weight)
reg$z <- sapply(seq_len(nrow(reg)), function(i) {
  sum(dat$share[dat$region_id == reg$region_id[i]] * dat$shock[dat$region_id == reg$region_id[i]])
})
center <- function(a) a - sum(e*a)
y0 <- center(reg$y); x0 <- center(reg$x); z0 <- center(reg$z)
industries <- sort(unique(dat$industry_id))
shock_n <- sapply(industries, function(n) dat$shock[match(n, dat$industry_id)])
shares <- sapply(industries, function(n) sapply(reg$region_id, function(r) {
  d <- dat[dat$region_id == r & dat$industry_id == n, ]; if (nrow(d)) d$share[1] else 0
}))
s <- drop(crossprod(e, shares))
bar <- function(v) drop(crossprod(e*v, shares))/s
ybar <- bar(y0); xbar <- bar(x0); zbar <- bar(z0)
keep <- s > 0 & is.finite(s)
s <- s[keep]; shock_n <- shock_n[keep]; ybar <- ybar[keep]; xbar <- xbar[keep]; zbar <- zbar[keep]
N <- length(s)
shock_iv <- function(dep, endog, instr) {
  X <- cbind(1, endog); Z <- cbind(1, instr)
  cross <- crossprod(Z, s*X); inv <- solve(cross)
  beta <- drop(inv %*% crossprod(Z, s*dep))
  resid <- drop(dep - X %*% beta)
  scores <- Z * (s*resid)
  V <- N/(N-2) * inv %*% crossprod(scores) %*% t(inv)
  c(beta[2], sqrt(V[2,2]))
}
eff <- shock_iv(ybar, xbar, shock_n); fst <- shock_iv(xbar, zbar, shock_n)
regional_effect <- sum(e*z0*y0)/sum(e*z0*x0)
regional_first <- sum(e*z0*x0)/sum(e*z0*z0)
stopifnot(abs(eff[1]-regional_effect)<1e-8, abs(fst[1]-regional_first)<1e-8,
          abs(sum(s)-1)<1e-10)
out <- list(task_id="applied_shift_share", platform="r", estimates=list(
  list(term="effect", estimate=unname(eff[1]), se=unname(eff[2]), n_obs=as.integer(N)),
  list(term="first_stage", estimate=unname(fst[1]), se=unname(fst[2]), n_obs=as.integer(N)),
  list(term="effective_shocks", estimate=1/sum(s^2), se=NULL, n_obs=as.integer(N))),
  method_metadata=list(estimator="shock-level weighted IV (regional 2SLS)",
                       vcov="shock-level HC1, N/(N-2), structural IV residuals"),
  diagnostics=list(n_regions=nrow(reg), n_industries=N))
jsonlite::write_json(out, "result.json", auto_unbox=TRUE, null="null", digits=16, pretty=TRUE)
share_error <- max(abs(sapply(reg$region_id, function(r) {
  sum(dat$share[dat$region_id == r]) - 1
})))
stopifnot(share_error < 1e-8)
writeLines(c(paste("Regions:",nrow(reg),"Industries:",N),
 paste("Maximum within-region share-sum error:",format(share_error,digits=16)),
 paste("sum(s):",format(sum(s),digits=16)),
 paste("Identity errors:",format(max(abs(c(eff[1]-regional_effect,fst[1]-regional_first))),digits=16)),
 paste("Effect:",format(eff[1],digits=16),"SE:",format(eff[2],digits=16)),
 paste("First stage:",format(fst[1],digits=16),"SE:",format(fst[2],digits=16)),
 paste("Effective shocks:",format(1/sum(s^2),digits=16))), "verification.txt")
