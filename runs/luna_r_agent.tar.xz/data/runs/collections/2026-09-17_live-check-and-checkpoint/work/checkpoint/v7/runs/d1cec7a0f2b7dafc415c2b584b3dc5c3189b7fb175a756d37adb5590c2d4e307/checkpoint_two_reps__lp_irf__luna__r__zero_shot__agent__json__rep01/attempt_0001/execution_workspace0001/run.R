dat <- read.csv("input.csv", stringsAsFactors = FALSE)
n <- nrow(dat)
dat$y_h4 <- c(dat$y[5:n], rep(NA_real_, 4))
dat$y_lag1 <- c(NA_real_, dat$y[1:(n - 1)])
sample <- dat[complete.cases(dat[, c("y_h4", "shock", "y_lag1")]), ]
fit <- lm(y_h4 ~ shock + y_lag1, data = sample)
nw <- sandwich::NeweyWest(fit, lag = 4, prewhite = FALSE, adjust = FALSE)
estimate <- unname(coef(fit)["shock"])
se <- unname(sqrt(nw["shock", "shock"]))
out <- list(task_id = "lp_irf", platform = "r",
  estimates = list(list(term = "irf_h4", estimate = as.numeric(estimate),
                         se = as.numeric(se), n_obs = nrow(sample))),
  method_metadata = list(estimator = "OLS local projection with intercept",
    vcov = "Newey-West HAC, lag 4, no prewhitening, no finite-sample adjustment"),
  diagnostics = list())
jsonlite::write_json(out, "result.json", auto_unbox = TRUE, digits = 17)
