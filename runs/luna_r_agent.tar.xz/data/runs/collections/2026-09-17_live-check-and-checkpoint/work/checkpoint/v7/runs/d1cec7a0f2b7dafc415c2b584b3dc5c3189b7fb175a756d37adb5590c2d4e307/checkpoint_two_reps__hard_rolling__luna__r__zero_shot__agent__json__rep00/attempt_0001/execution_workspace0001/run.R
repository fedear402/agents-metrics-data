dat <- read.csv("input.csv", stringsAsFactors = FALSE)
dat <- dat[order(dat$time), ]
stopifnot(nrow(dat) == 250, identical(as.integer(dat$time), 1:250))
y <- dat$y
fdates <- 101:250
fc <- numeric(length(fdates))
for (i in seq_along(fdates)) {
  f <- fdates[i]
  levels <- y[(f - 100):(f - 1)]
  response <- levels[2:100]
  lagged <- levels[1:99]
  fit <- lm(response ~ lagged)
  fc[i] <- unname(coef(fit)[1] + coef(fit)[2] * y[f - 1])
}
errors <- y[fdates] - fc
rmse <- sqrt(sum(errors^2) / length(errors))

fmt <- function(x) formatC(x, digits = 17, format = "fg", flag = "#")
lines <- c(
  '{',
  '  "task_id": "hard_rolling",',
  '  "platform": "r",',
  '  "estimates": [',
  sprintf('    {"term": "rmse", "estimate": %s, "se": null, "n_obs": 150},', fmt(rmse)),
  sprintf('    {"term": "forecast_101", "estimate": %s, "se": null, "n_obs": 99},', fmt(fc[1])),
  sprintf('    {"term": "forecast_150", "estimate": %s, "se": null, "n_obs": 99},', fmt(fc[50])),
  sprintf('    {"term": "forecast_200", "estimate": %s, "se": null, "n_obs": 99},', fmt(fc[100])),
  sprintf('    {"term": "forecast_250", "estimate": %s, "se": null, "n_obs": 99}', fmt(fc[150])),
  '  ],',
  '  "method_metadata": {"estimator": "rolling OLS AR(1) with intercept", "vcov": "none (forecast point estimates)"},',
  '  "diagnostics": {}',
  '}'
)
writeLines(lines, "result.json")

# Independent checks: closed-form OLS coefficients and direct RMSE identity.
closed_fc <- numeric(length(fdates))
for (i in seq_along(fdates)) {
  f <- fdates[i]
  z <- y[(f - 100):(f - 1)]
  x <- z[1:99]; yy <- z[2:100]
  b <- sum((x - mean(x)) * (yy - mean(yy))) / sum((x - mean(x))^2)
  a <- mean(yy) - b * mean(x)
  closed_fc[i] <- a + b * y[f - 1]
}
verification <- c(
  sprintf("Rows sorted and checked: %d observations, times 1 through 250.", nrow(dat)),
  sprintf("Each forecast used levels y_(f-100) through y_(f-1), with 99 response-lag pairs; checked at all %d dates.", length(fdates)),
  sprintf("Independent closed-form OLS check: max absolute forecast difference = %.17g.", max(abs(fc - closed_fc))),
  sprintf("Independent RMSE check: sqrt(sum(errors^2)/150) = %.17g.", sqrt(sum((y[fdates] - fc)^2) / 150)),
  sprintf("Reported RMSE = %.17g.", rmse),
  sprintf("Reported forecasts: f101=%.17g, f150=%.17g, f200=%.17g, f250=%.17g.", fc[1], fc[50], fc[100], fc[150])
)
writeLines(verification, "verification.txt")
