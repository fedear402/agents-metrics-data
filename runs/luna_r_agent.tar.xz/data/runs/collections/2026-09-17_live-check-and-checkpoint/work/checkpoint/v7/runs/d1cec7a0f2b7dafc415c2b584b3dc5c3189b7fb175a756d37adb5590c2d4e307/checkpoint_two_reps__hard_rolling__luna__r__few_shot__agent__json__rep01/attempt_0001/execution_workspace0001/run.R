dat <- read.csv("input.csv", stringsAsFactors = FALSE)
dat <- dat[order(dat$time), , drop = FALSE]
stopifnot(nrow(dat) == 250L, identical(as.integer(dat$time), 1:250))
y <- as.numeric(dat$y)
forecast_times <- 101:250
fc <- numeric(length(forecast_times))

for (i in seq_along(forecast_times)) {
  f <- forecast_times[i]
  levels <- y[(f - 100):(f - 1)]
  stopifnot(length(levels) == 100L)
  lagged <- levels[1:99]
  current <- levels[2:100]
  fit <- lm(current ~ lagged)
  stopifnot(nobs(fit) == 99L)
  fc[i] <- unname(coef(fit)[1] + coef(fit)[2] * levels[100])
}

rmse <- sqrt(mean((y[forecast_times] - fc)^2))
wanted <- c(101L, 150L, 200L, 250L)
wanted_fc <- fc[match(wanted, forecast_times)]
row <- function(term, estimate, n_obs) {
  list(term = term, estimate = as.numeric(estimate), se = NULL, n_obs = as.integer(n_obs))
}
estimates <- list(row("rmse", rmse, 150L))
for (i in seq_along(wanted)) estimates[[i + 1L]] <- row(paste0("forecast_", wanted[i]), wanted_fc[i], 99L)

result <- list(
  task_id = "hard_rolling",
  platform = "r",
  estimates = estimates,
  method_metadata = list(estimator = "rolling OLS AR(1) with intercept", vcov = "not applicable; se=null"),
  diagnostics = list()
)
jsonlite::write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
