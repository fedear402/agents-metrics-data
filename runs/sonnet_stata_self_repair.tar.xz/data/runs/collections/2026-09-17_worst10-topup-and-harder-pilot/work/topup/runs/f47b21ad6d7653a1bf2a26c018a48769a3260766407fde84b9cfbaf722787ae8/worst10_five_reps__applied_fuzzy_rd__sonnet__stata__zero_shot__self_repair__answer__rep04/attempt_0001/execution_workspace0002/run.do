set linesize 255
import delimited "./input.csv", clear

keep if abs(score) < 1
count
scalar n_obs = r(N)

gen double weight = 1 - abs(score)
gen byte right = (score >= 0)
gen double score_right = score * right
gen double score_left  = score * (1 - right)

mata:
    n = st_nobs()
    ones       = J(n, 1, 1)
    right      = st_data(., "right")
    sl         = st_data(., "score_left")
    sr         = st_data(., "score_right")
    w          = st_data(., "weight")
    y_earn     = st_data(., "earnings")
    y_part     = st_data(., "participated")

    X = (ones, right, sl, sr)           // n x 4

    // WLS: beta = (X'WX)^{-1} X'Wy  where W = diag(w)
    XW  = X :* w                        // n x 4
    XWX = XW' * X                       // 4 x 4
    XWX_inv = invsym(XWX)

    beta_earn = XWX_inv * (XW' * y_earn)
    beta_part = XWX_inv * (XW' * y_part)

    rf_est = beta_earn[2]
    fs_est = beta_part[2]

    // Residuals
    e_earn = y_earn - X * beta_earn
    e_part = y_part - X * beta_part

    // HC0 sandwich: V = (X'WX)^{-1} meat (X'WX)^{-1}
    // meat_yy = sum_i w_i^2 e_i^2 x_i x_i' = (X :* (w.*e))' * (X :* (w.*e))
    Xwe_earn = X :* (w :* e_earn)       // n x 4
    Xwe_part = X :* (w :* e_part)

    meat_earn  = Xwe_earn' * Xwe_earn
    meat_part  = Xwe_part' * Xwe_part
    meat_cross = Xwe_earn' * Xwe_part

    V_earn  = XWX_inv * meat_earn  * XWX_inv
    V_part  = XWX_inv * meat_part  * XWX_inv
    V_cross = XWX_inv * meat_cross * XWX_inv

    rf_var    = V_earn[2,2]
    fs_var    = V_part[2,2]
    cov_rf_fs = V_cross[2,2]

    rf_se = sqrt(rf_var)
    fs_se = sqrt(fs_var)

    te_est = rf_est / fs_est
    te_var = (1/fs_est)^2 * rf_var + (rf_est/fs_est^2)^2 * fs_var ///
             - 2*(1/fs_est)*(rf_est/fs_est^2)*cov_rf_fs
    te_se  = sqrt(te_var)

    st_numscalar("rf_est", rf_est)
    st_numscalar("rf_se",  rf_se)
    st_numscalar("fs_est", fs_est)
    st_numscalar("fs_se",  fs_se)
    st_numscalar("te_est", te_est)
    st_numscalar("te_se",  te_se)
end

display "ANSWER: treatment_effect estimate=" %21.12f te_est " se=" %21.12f te_se " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate="     %21.12f rf_est " se=" %21.12f rf_se " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate="      %21.12f fs_est " se=" %21.12f fs_se " n_obs=" %12.0f n_obs
