clear all
set more off
set linesize 255
set type double

import delimited ./input.csv, clear

quietly regress y x z1 z2
scalar n = e(N)
scalar df = n - 4
scalar q = 2
scalar critical = invFtail(q, df, .05)
scalar k = q * critical / df

// Partial out intercept and x from y, endog, z1, z2
foreach v of varlist y endog z1 z2 {
    quietly regress `v' x
    predict double r_`v', residuals
}

// For AR inversion: at candidate beta, regress (y - beta*endog) on x, z1, z2
// Restricted: only intercept and x (no z1, z2)
// Unrestricted: intercept, x, z1, z2
// After partialling out intercept and x:
// SSR_U = sum(r_y - beta*r_endog - alpha1*r_z1 - alpha2*r_z2)^2 minimized over alpha1,alpha2
// SSR_R = sum(r_y - beta*r_endog)^2

// Let ry = r_y, rd = r_endog, rz1 = r_z1, rz2 = r_z2
// SSR_R(beta) = (ry - beta*rd)'(ry - beta*rd)
// SSR_U(beta) = SSR_R(beta) - (ry-beta*rd)'Pz(ry-beta*rd)
// where Pz = rz*(rz'rz)^{-1}*rz'

// F(beta) = ((SSR_R - SSR_U)/q) / (SSR_U/df)
// Accept when F <= critical, i.e. SSR_R - SSR_U <= k * SSR_U
// i.e. SSR_R <= (1+k)*SSR_U

// SSR_U = (ry-beta*rd)'M_z(ry-beta*rd) where M_z = I - Pz
// Let e = ry - beta*rd
// SSR_R = e'e
// SSR_U = e'M_z*e = e'e - e'Pz*e

// Acceptance: e'e - e'Pz*e <= k*(e'e - e'Pz*e) is wrong
// Acceptance: SSR_R - (SSR_R - SSR_U) <= k*(SSR_R - SSR_U)... no
// F = ((SSR_R - SSR_U)/q)/(SSR_U/df) <= critical
// SSR_R - SSR_U <= (q*critical/df)*SSR_U = k*SSR_U
// SSR_R <= (1+k)*SSR_U
// e'e <= (1+k)*(e'M_z*e)
// e'e <= (1+k)*(e'e - e'Pz*e)
// e'Pz*e*(1+k) <= k*e'e ... rearranging
// Actually: e'e - (1+k)*e'M_z*e <= 0
// = e'e - (1+k)*(e'e - e'Pz*e) <= 0
// = -k*e'e + (1+k)*e'Pz*e <= 0

// With e = ry - beta*rd:
// e'e = (ry - beta*rd)'(ry - beta*rd) = A0 - 2*B0*beta + C0*beta^2
// where A0=ry'ry, B0=ry'rd, C0=rd'rd

// e'Pz*e: let fz1 = projection of ry on rz, etc.
// Pz*e = rz*(rz'rz)^{-1}*rz'*e
// e'Pz*e = e'rz*(rz'rz)^{-1}*rz'*e

// Let pry = rz*(rz'rz)^{-1}*rz'*ry and prd = rz*(rz'rz)^{-1}*rz'*rd
// e'Pz*e = (ry - beta*rd)'Pz*(ry - beta*rd)
//        = pry'ry - 2*beta*pry'rd + beta^2*prd'rd ... no
//        = ry'Pz*ry - 2*beta*rd'Pz*ry + beta^2*rd'Pz*rd

// Acceptance condition: -k*e'e + (1+k)*e'Pz*e <= 0
// = (-k*C0 + (1+k)*rd'Pz*rd)*beta^2 + (2*k*B0 - 2*(1+k)*ry'Pz*rd)*beta + (-k*A0 + (1+k)*ry'Pz*ry) <= 0
// = A_coef*beta^2 + B_coef*beta + C_coef <= 0

mata:
ry = st_data(., "r_y")
rd = st_data(., "r_endog")
rz1 = st_data(., "r_z1")
rz2 = st_data(., "r_z2")
k = st_numscalar("k")
n = rows(ry)

// Cross products
A0 = quadcross(ry, ry)
B0 = quadcross(ry, rd)
C0 = quadcross(rd, rd)

// Pz components
RZ = (rz1, rz2)
ZZ = quadcross(RZ, RZ)
Zry = quadcross(RZ, ry)
Zrd = quadcross(RZ, rd)

ryPzry = quadcross(Zry, luinv(ZZ), Zry)
rdPzrd = quadcross(Zrd, luinv(ZZ), Zrd)
ryPzrd = quadcross(Zry, luinv(ZZ), Zrd)

// Coefficients of quadratic in beta: A_coef*beta^2 + B_coef*beta + C_coef <= 0
A_coef = -k*C0 + (1+k)*rdPzrd
B_coef = 2*k*B0 - 2*(1+k)*ryPzrd
C_coef = -k*A0 + (1+k)*ryPzry

disc = B_coef^2 - 4*A_coef*C_coef

// Compute bounds
low = (-B_coef - sqrt(disc)) / (2*A_coef)
high = (-B_coef + sqrt(disc)) / (2*A_coef)
if (low > high) {
    tmp = low; low = high; high = tmp
}

// unbounded: A_coef < 0 means parabola opens downward, acceptance is OUTSIDE roots
unbounded = (A_coef < 0)

// accepts_zero: C_coef <= 0
accepts_zero = (C_coef <= 0)

// ar_f_at_one
beta1 = 1
e1 = ry - beta1*rd
Ze1 = quadcross(RZ, e1)
e1Pze1 = quadcross(Ze1, luinv(ZZ), Ze1)
e1e1 = quadcross(e1, e1)
SSR_R1 = e1e1
SSR_U1 = e1e1 - e1Pze1
df_r = st_numscalar("df")
q_r = st_numscalar("q")
ar_f1 = ((SSR_R1 - SSR_U1)/q_r) / (SSR_U1/df_r)

st_numscalar("low", low)
st_numscalar("high", high)
st_numscalar("unbounded", unbounded)
st_numscalar("accepts_zero", accepts_zero)
st_numscalar("ar_f_at_one", ar_f1)
end

display "ANSWER: boundary_low estimate=" %21.12f low " se=" %21.12f . " n_obs=" %12.0f n
display "ANSWER: boundary_high estimate=" %21.12f high " se=" %21.12f . " n_obs=" %12.0f n
display "ANSWER: accepts_zero estimate=" %21.12f accepts_zero " se=" %21.12f . " n_obs=" %12.0f n
display "ANSWER: unbounded estimate=" %21.12f unbounded " se=" %21.12f . " n_obs=" %12.0f n
display "ANSWER: ar_f_at_one estimate=" %21.12f ar_f_at_one " se=" %21.12f . " n_obs=" %12.0f n
