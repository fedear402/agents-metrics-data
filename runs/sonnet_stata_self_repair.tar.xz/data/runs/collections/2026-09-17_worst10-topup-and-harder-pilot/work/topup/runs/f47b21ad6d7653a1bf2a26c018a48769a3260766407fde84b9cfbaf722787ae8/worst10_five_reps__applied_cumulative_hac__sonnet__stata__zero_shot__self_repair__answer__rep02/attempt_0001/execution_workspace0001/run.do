set linesize 255
import delimited "./input.csv", clear

gen log_sales = log(sales)
gen log_vix = log(vix)
sort date
gen d_log_vix = log_vix - log_vix[_n-1]

forvalues k = 1/15 {
    gen d_log_vix_lag`k' = d_log_vix[_n-`k']
}

reg log_sales d_log_vix_lag1-d_log_vix_lag15

scalar N = e(N)

* Newey-West with max lag 15, manual Bartlett weights, multiplied by N/(N-16)
* We'll use newey with lag(15) and then scale the VCV

newey log_sales d_log_vix_lag1-d_log_vix_lag15, lag(15)

* Get the VCV and scale it
matrix V = e(V)
scalar N = e(N)
matrix V_adj = V * (N / (N - 16))

* Extract individual SEs
scalar b1 = _b[d_log_vix_lag1]
scalar b15 = _b[d_log_vix_lag15]

* SE for lag_1 and lag_15
scalar se1 = sqrt(V_adj[1,1])
scalar se15 = sqrt(V_adj[15,15])

* Cumulative response: sum of all 15 coefficients
scalar cum_resp = 0
forvalues k = 1/15 {
    scalar cum_resp = cum_resp + _b[d_log_vix_lag`k']
}

* SE for cumulative response using full VCV
* sum of all elements of V_adj
scalar var_cum = 0
forvalues i = 1/15 {
    forvalues j = 1/15 {
        scalar var_cum = var_cum + V_adj[`i', `j']
    }
}
scalar se_cum = sqrt(var_cum)

display "ANSWER: cumulative_response estimate=" %21.12f cum_resp " se=" %21.12f se_cum " n_obs=" %12.0f N
display "ANSWER: lag_1 estimate=" %21.12f b1 " se=" %21.12f se1 " n_obs=" %12.0f N
display "ANSWER: lag_15 estimate=" %21.12f b15 " se=" %21.12f se15 " n_obs=" %12.0f N
