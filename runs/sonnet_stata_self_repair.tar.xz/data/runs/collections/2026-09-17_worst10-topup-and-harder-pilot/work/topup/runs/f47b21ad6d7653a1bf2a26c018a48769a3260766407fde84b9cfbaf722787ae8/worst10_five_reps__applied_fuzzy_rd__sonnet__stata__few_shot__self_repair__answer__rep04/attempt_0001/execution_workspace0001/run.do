version 16
clear all
set more off
set linesize 255

import delimited "./input.csv", clear

keep if abs(score) < 1
gen w = 1 - abs(score)
gen above = (score >= 0)

mata:
    st_view(Y=., ., ("earnings","participated"))
    st_view(X=., ., ("score","above"))
    st_view(w=., ., "w")
    n = rows(Y)
    
    // Build design matrix: intercept, score, above, score*above
    Xd = J(n,1,1), X[.,1], X[.,2], X[.,1]:*X[.,2]
    
    bread = invsym(Xd'*(w:*Xd))
    coef = bread*Xd'*(w:*Y)
    resid = Y - Xd*coef
    
    // Contrast for right-minus-left limit at score=0
    // At score=0: right limit = intercept + above=1 -> coef row 3
    // left limit = intercept + above=0 -> just intercept
    // So contrast picks coefficient on "above" (index 3)
    contrast = (0\0\1\0)
    
    jumps = contrast'*coef
    loading = w:*(Xd*bread*contrast)
    influence = loading:*resid
    
    joint = influence'*influence
    
    rf = jumps[1,1]
    fs = jumps[1,2]
    te = rf/fs
    
    rf_se = sqrt(joint[1,1])
    fs_se = sqrt(joint[2,2])
    
    grad = (1/fs \ -rf/fs^2)
    te_se = sqrt(grad'*joint*grad)
    
    st_numscalar("rf_est", rf)
    st_numscalar("rf_se", rf_se)
    st_numscalar("fs_est", fs)
    st_numscalar("fs_se", fs_se)
    st_numscalar("te_est", te)
    st_numscalar("te_se", te_se)
    st_numscalar("nobs", n)
end

display "ANSWER: treatment_effect estimate=" %21.12f te_est " se=" %21.12f te_se " n_obs=" %12.0f nobs
display "ANSWER: reduced_form estimate=" %21.12f rf_est " se=" %21.12f rf_se " n_obs=" %12.0f nobs
display "ANSWER: first_stage estimate=" %21.12f fs_est " se=" %21.12f fs_se " n_obs=" %12.0f nobs
