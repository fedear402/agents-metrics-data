set linesize 255
import delimited "./input.csv", clear

sort date

gen log_sales = ln(sales)
gen log_vix = ln(vix)

* Generate first difference of log_vix manually (no time series declaration needed)
gen d_log_vix = log_vix - log_vix[_n-1]

* Generate lags manually
forvalues k = 1/15 {
    gen d_log_vix_lag`k' = d_log_vix[_n-`k']
}

* Run newey with lag(15) - Stata uses Bartlett weights 1-j/(lag+1) = 1-j/16
newey log_sales d_log_vix_lag1-d_log_vix_lag15, lag(15) force

scalar N2 = e(N)

* Extract VCE and scale by N/(N-16)
matrix V_nw = e(V)
scalar scale = N2 / (N2 - 16)
matrix V_scaled = scale * V_nw

* Get coefficients
matrix b = e(b)

* Sum of lag1 through lag15 coefficients
scalar cum_resp = 0
forvalues k = 1/15 {
    scalar cum_resp = cum_resp + b[1, `k']
}

* SE for cumulative response using full covariance matrix
matrix c = J(1, 16, 0)
forvalues k = 1/15 {
    matrix c[1, `k'] = 1
}
matrix var_cum = c * V_scaled * c'
scalar se_cum = sqrt(var_cum[1,1])

* SE for lag_1 and lag_15
scalar se_lag1 = sqrt(V_scaled[1,1])
scalar se_lag15 = sqrt(V_scaled[15,15])

* Individual coefficients
scalar b_lag1 = b[1,1]
scalar b_lag15 = b[1,15]

display "ANSWER: cumulative_response estimate=" %21.12f cum_resp " se=" %21.12f se_cum " n_obs=" %12.0f N2
display "ANSWER: lag_1 estimate=" %21.12f b_lag1 " se=" %21.12f se_lag1 " n_obs=" %12.0f N2
display "ANSWER: lag_15 estimate=" %21.12f b_lag15 " se=" %21.12f se_lag15 " n_obs=" %12.0f N2
