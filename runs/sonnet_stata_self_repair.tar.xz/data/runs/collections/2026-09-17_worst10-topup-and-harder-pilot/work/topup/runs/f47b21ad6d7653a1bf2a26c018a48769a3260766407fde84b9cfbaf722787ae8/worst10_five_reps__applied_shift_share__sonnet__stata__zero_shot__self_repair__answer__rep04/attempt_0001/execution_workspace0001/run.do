set linesize 255
clear all

import delimited "./input.csv", varnames(1)

* Get one obs per region for weights
bysort region_id: keep if _n == 1
tempfile region_data
keep region_id region_weight x y
save `region_data'

import delimited "./input.csv", varnames(1) clear

* Normalize regional weights using one obs per region
bysort region_id: gen region_obs = _n
preserve
keep if region_obs == 1
egen total_weight = total(region_weight)
gen e_r = region_weight / total_weight
keep region_id e_r
tempfile eweights
save `eweights'
restore

merge m:1 region_id using `eweights', nogen

* Construct shift-share instrument z_r = sum_n share_rn * shock_n
gen share_shock = share * shock
bysort region_id: egen z_r = total(share_shock)

* Get region-level data (one obs per region)
preserve
keep if region_obs == 1
keep region_id e_r x y z_r
tempfile region_level
save `region_level'
restore

* Count industries
quietly levelsof industry_id, local(industries)
local N_industries = r(r)

* Compute s_n = sum_r e_r * share_rn
bysort industry_id: gen sn_part = e_r * share

* Need weighted regional means
* e_r-weighted mean of y, x, z
* First get region-level dataset
use `region_level', clear
egen wt_sum = total(e_r)
* Weighted means
gen ey = e_r * y
gen ex_val = e_r * x
gen ez = e_r * z_r
egen mean_y = total(ey)
egen mean_x = total(ex_val)
egen mean_z = total(ez)

* Demeaned variables
gen y0 = y - mean_y
gen x0 = x - mean_x
gen z0 = z_r - mean_z

save `region_level', replace

* Now merge back to full dataset to compute shock-level aggregates
use `region_level', clear
* Need share data - reload full data
import delimited "./input.csv", varnames(1) clear
bysort region_id: gen region_obs2 = _n
merge m:1 region_id using `eweights', nogen
merge m:1 region_id using `region_level', keepusing(y0 x0 z0) nogen

* Compute s_n and shock-level aggregates
gen e_share = e_r * share
bysort industry_id: egen s_n = total(e_share)

gen e_share_y0 = e_r * share * y0
gen e_share_x0 = e_r * share * x0
gen e_share_z0 = e_r * share * z0

bysort industry_id: egen num_ybar = total(e_share_y0)
bysort industry_id: egen num_xbar = total(e_share_x0)
bysort industry_id: egen num_zbar = total(e_share_z0)

gen ybar_n = num_ybar / s_n
gen xbar_n = num_xbar / s_n
gen zbar_n = num_zbar / s_n

* Keep one obs per industry
bysort industry_id: keep if _n == 1
keep industry_id shock s_n ybar_n xbar_n zbar_n

* Number of industries
count
local N = r(N)

* Compute effective shocks = 1 / sum_n s_n^2
gen sn_sq = s_n^2
egen sum_sn_sq = total(sn_sq)
scalar effective_shocks = 1 / sum_sn_sq[1]

* Shock-level IV for effect: y on x, instrument x with shock, weight by s_n
* Manual 2SLS
* First stage: xbar on zbar ~ shock
* Weighted regression
gen w = s_n

* First stage for EFFECT regression: regress xbar_n on intercept, instrument shock
* Actually the shock-level IV: ybar on xbar, instrument xbar with shock, weight s_n
* First stage of this: xbar on shock (weighted by s_n)
reg xbar_n shock [aw=w]
scalar fs_coef_effect = _b[shock]

* Predict xhat for 2SLS
predict xhat_effect, xb

* Second stage (2SLS slope): ybar on xhat
reg ybar_n xhat_effect [aw=w]
scalar beta_2sls = _b[xhat_effect]

* Compute structural IV residuals for HC1 SE
* residual = ybar_n - beta_2sls * xbar_n - intercept
* Need intercept from second stage but using original xbar (structural)
* The intercept: from weighted means, since demeaned, intercept should be ~0
* Structural residual: u_n = ybar_n - alpha - beta*xbar_n
* where alpha and beta are 2SLS estimates
scalar alpha_2sls = _b[_cons] - beta_2sls * (_b[xhat_effect] - beta_2sls)
* Actually recompute properly
* In shock-level IV: ybar = alpha + beta*xbar + u
* 2SLS gives beta. The intercept from second stage using xhat is not the structural intercept
* Structural: u_n = ybar_n - alpha_struct - beta_2sls * xbar_n
* Since weighted mean of ybar and xbar may not be zero (they are aggregates of demeaned regional vars)
* Compute weighted means of ybar and xbar
egen wy = total(w * ybar_n)
egen wx = total(w * xbar_n)
egen wsum = total(w)
gen mean_ybar = wy / wsum
gen mean_xbar = wx / wsum

scalar alpha_struct = mean_ybar[1] - beta_2sls * mean_xbar[1]
gen u_struct = ybar_n - alpha_struct - beta_2sls * xbar_n

* HC1 variance for beta_2sls
* Var(beta) = [sum w_n * zhat_n^2]^{-2} * sum w_n^2 * zhat_n^2 * u_n^2 * (N/(N-2))
* where zhat_n = shock_n - weighted mean of shock (first stage residual concept)
* Actually for IV with instrument shock:
* beta = [sum w*z*x]^{-1} * sum w*z*y  (after demeaning by weighted mean)
* HC1 sandwich:
* First demean shock by weighted mean
gen w_shock = w * shock
egen wshock_sum = total(w_shock)
gen mean_shock = wshock_sum / wsum
gen shock_dm = shock - mean_shock

gen wz_x = w * shock_dm * xbar_n
egen sum_wzx = total(wz_x)
scalar denom_iv = sum_wzx[1]

gen wz_u = w * shock_dm * u_struct
gen wz_u_sq = (w * shock_dm * u_struct)^2
egen sum_wzu_sq = total(wz_u_sq)

* HC1: multiply by N/(N-2)
scalar var_beta = (1/denom_iv^2) * sum_wzu_sq[1] * (`N'/(`N'-2))
scalar se_effect = sqrt(var_beta)

* First-stage regression: x_r on z_r, weighted by e_r, get slope
* Equivalent shock-level: xbar_n on zbar_n, instrument zbar_n with shock_n, weight s_n
* First stage of this instrument regression: zbar on shock
reg zbar_n shock [aw=w]
scalar fs_zbar_coef = _b[shock]
predict zhat_fs, xb

* Second stage: xbar on zhat_fs
reg xbar_n zhat_fs [aw=w]
scalar beta_fs = _b[zhat_fs]

* Structural residual for first stage
scalar alpha_fs_struct = mean_xbar[1] - beta_fs * mean_ybar[1]
* Actually first stage is xbar on zbar
* alpha_fs = mean_xbar - beta_fs * mean_zbar
egen wz_bar = total(w * zbar_n)
gen mean_zbar = wz_bar / wsum

scalar alpha_fs_struct2 = mean_xbar[1] - beta_fs * mean_zbar[1]
gen u_fs = xbar_n - alpha_fs_struct2 - beta_fs * zbar_n

* HC1 for first stage
* Instrument is shock, endogenous is zbar
gen wz_zbar = w * shock_dm * zbar_n
egen sum_wz_zbar = total(wz_zbar)
scalar denom_fs = sum_wz_zbar[1]

gen wz_ufs = w * shock_dm * u_fs
gen wz_ufs_sq = (w * shock_dm * u_fs)^2
egen sum_wz_ufs_sq = total(wz_ufs_sq)

scalar var_fs = (1/denom_fs^2) * sum_wz_ufs_sq[1] * (`N'/(`N'-2))
scalar se_fs = sqrt(var_fs)

* Report results
display "ANSWER: effect estimate=" %21.12f beta_2sls " se=" %21.12f se_effect " n_obs=" %12.0f `N'
display "ANSWER: first_stage estimate=" %21.12f beta_fs " se=" %21.12f se_fs " n_obs=" %12.0f `N'
display "ANSWER: effective_shocks estimate=" %21.12f effective_shocks " se=" %21.12f . " n_obs=" %12.0f `N'
