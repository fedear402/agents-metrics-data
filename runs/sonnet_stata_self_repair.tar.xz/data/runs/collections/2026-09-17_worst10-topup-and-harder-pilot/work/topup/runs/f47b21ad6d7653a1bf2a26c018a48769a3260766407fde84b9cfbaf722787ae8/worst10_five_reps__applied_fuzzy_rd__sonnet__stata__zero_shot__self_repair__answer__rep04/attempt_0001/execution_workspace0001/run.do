set linesize 255
import delimited "./input.csv", clear

// Keep observations within bandwidth
keep if abs(score) < 1

// Count observations
count
scalar n_obs = r(N)

// Triangular weights
gen weight = 1 - abs(score)

// Indicator for right side
gen right = (score >= 0)

// Interaction terms for local linear
gen score_right = score * right
gen score_left = score * (1 - right)

// WLS regression for earnings (reduced form)
reg earnings right score_left score_right [aw=weight], vce(hc0)
scalar rf_est = _b[right]
scalar rf_se = _se[right]

// WLS regression for participation (first stage)
reg participated right score_left score_right [aw=weight], vce(hc0)
scalar fs_est = _b[right]
scalar fs_se = _se[right]

// Delta method for treatment effect
// te = rf / fs
// Var(te) = (1/fs)^2 * Var(rf) + (rf/fs^2)^2 * Var(fs) - 2*(rf/fs^3)*Cov(rf,fs)
// Need joint covariance of rf and fs estimates

// Stack both regressions using sureg to get joint covariance
sureg (earnings right score_left score_right) (participated right score_left score_right), isure

// Get the covariance between the two "right" coefficients
// In sureg, equations are named by depvar
scalar rf_est2 = _b[earnings:right]
scalar fs_est2 = _b[participated:right]
scalar rf_var = ((_se[earnings:right])^2)
scalar fs_var = ((_se[participated:right])^2)

// Get covariance - need vcov matrix
matrix V = e(V)
// Find position of earnings:right and participated:right
local rf_pos = colnumb(V, "earnings:right")
local fs_pos = colnumb(V, "participated:right")
scalar cov_rf_fs = V[`rf_pos', `fs_pos']

// But sureg uses GLS not HC0 - we need to use separate HC0 regressions and get covariance manually
// Use seemingly unrelated approach manually via stacked regression with HC0

// We'll compute the covariance manually using the influence functions
// From HC0: V = (X'WX)^{-1} * (X'W diag(e^2) W X) * (X'WX)^{-1}
// The cross-covariance between rf and fs uses cross-products of residuals

// Get residuals from both regressions
reg earnings right score_left score_right [aw=weight], vce(hc0)
predict double e_earn, residuals
matrix V_earn = e(V)
matrix XWX_earn_inv = invsym(e(V) * e(N)) // Not quite right

// Better approach: compute manually
// Let X be the design matrix, W diagonal weight matrix
// beta_rf = (X'WX)^{-1} X'W y_earn
// beta_fs = (X'WX)^{-1} X'W y_part
// Since same X and W:
// Cov(beta_rf[j], beta_fs[k]) = [(X'WX)^{-1} X'W diag(e_earn * e_part) W X (X'WX)^{-1}]_{jk}

// Get residuals from earnings regression
reg earnings right score_left score_right [aw=weight], vce(hc0)
scalar rf_est = _b[right]
scalar rf_se = _se[right]
predict double resid_earn, residuals
matrix XWX_inv = e(V) // This is HC0 V without meat, we need (X'WX)^{-1}

// Get (X'WX)^{-1}: from OLS, V_ols = s^2 * (X'WX)^{-1}, but we want exact
// Use: e(V) from vce(hc0) = (X'WX)^{-1} * meat * (X'WX)^{-1}
// Instead, get (X'WX)^{-1} from the OLS (no robust) result
reg earnings right score_left score_right [aw=weight]
matrix XWX_inv = e(V) / e(rmse)^2  // V_ols = sigma^2 * (X'WX)^{-1}, so (X'WX)^{-1} = V_ols/sigma^2
// Actually e(V) = s^2*(X'WX)^{-1} where s^2 = RSS/(n-k)
// So (X'WX)^{-1} = e(V) * (n-k) / RSS
scalar n_k = e(df_r)
scalar rss = e(rss)
matrix XWX_inv = e(V) * n_k / rss

reg participated right score_left score_right [aw=weight], vce(hc0)
scalar fs_est = _b[right]
scalar fs_se = _se[right]
predict double resid_part, residuals

// Compute cross-product meat: sum w_i^2 * e_earn_i * e_part_i * x_i x_i'
// We need the (right, right) element of XWX_inv * cross_meat * XWX_inv
// where cross_meat = X' W diag(e_earn*e_part) W X

// Generate weighted cross-residuals
gen double cross_resid = resid_earn * resid_part * weight^2

// We need x_i vectors: (1, right_i, score_left_i, score_right_i)
// The element of cross_meat corresponding to "right" regressor:
// cross_meat[j,k] = sum_i w_i^2 * e_earn_i * e_part_i * x_ij * x_ik

// Create x variables weighted by sqrt(w) * e_earn and sqrt(w) * e_part
// For the HC0 cross-covariance of the "right" coefficient:
// Cov = e_j' * cross_meat * e_k where e_j selects the right coefficient row
// = sum over all (j,k) pairs of XWX_inv[right,j] * cross_meat[j,k] * XWX_inv[k,right]

// Let h_i = (XWX_inv %*% x_i)[right_row] * w_i = "hat" vector for right coeff
// Then cov = sum_i h_i^2_earn_entry * ... 
// Actually: let a_i = row of X corresponding to "right" dotted with XWX_inv[right,:]
// a_i = x_i' * XWX_inv[*, right_col] (the right column of XWX_inv)
// Then cov(beta_rf[right], beta_fs[right]) = sum_i a_i * w_i * e_earn_i * a_i * w_i * e_part_i
// = sum_i (a_i * w_i)^2 * e_earn_i * e_part_i

// Extract the "right" column of XWX_inv (column 1, since right is first regressor after intercept, col 2)
// Order: _cons, right, score_left, score_right -> right is column 2
matrix xwx_col_right = XWX_inv[1..4, 2]

// Compute a_i = x_i' * xwx_col_right for each obs
gen double a_i = _cons * xwx_col_right[1,1] + right * xwx_col_right[2,1] + score_left * xwx_col_right[3,1] + score_right * xwx_col_right[4,1]
// _cons is always 1
replace a_i = xwx_col_right[1,1] + right * xwx_col_right[2,1] + score_left * xwx_col_right[3,1] + score_right * xwx_col_right[4,1]

gen double sandwich_cross = (a_i * weight)^2 * resid_earn * resid_part
quietly summarize sandwich_cross
scalar cov_rf_fs = r(sum)

// Delta method
scalar te_est = rf_est / fs_est
scalar rf_var = rf_se^2
scalar fs_var = fs_se^2
scalar te_var = (1/fs_est)^2 * rf_var + (rf_est/fs_est^2)^2 * fs_var - 2*(rf_est/fs_est^3)*cov_rf_fs
// Wait: d(rf/fs)/d(rf) = 1/fs, d(rf/fs)/d(fs) = -rf/fs^2
// Var(te) = (1/fs)^2*Var(rf) + (rf/fs^2)^2*Var(fs) - 2*(1/fs)*(rf/fs^2)*Cov(rf,fs)
scalar te_var = (1/fs_est)^2 * rf_var + (rf_est/fs_est^2)^2 * fs_var - 2*(1/fs_est)*(rf_est/fs_est^2)*cov_rf_fs
scalar te_se = sqrt(te_var)

display "ANSWER: treatment_effect estimate=" %21.12f te_est " se=" %21.12f te_se " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f rf_est " se=" %21.12f rf_se " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f fs_est " se=" %21.12f fs_se " n_obs=" %12.0f n_obs
