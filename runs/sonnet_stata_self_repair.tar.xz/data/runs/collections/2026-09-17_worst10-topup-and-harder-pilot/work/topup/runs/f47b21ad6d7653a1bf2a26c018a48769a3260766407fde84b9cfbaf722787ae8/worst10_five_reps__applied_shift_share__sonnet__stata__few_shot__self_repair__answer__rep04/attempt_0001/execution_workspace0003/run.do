version 17.0
clear all
set more off
set linesize 255

import delimited "./input.csv", clear

// Normalize regional weights (one obs per region)
bysort region_id: gen region_tag = (_n == 1)
su region_weight if region_tag == 1, meanonly
scalar total_weight = r(sum)
gen e_r = region_weight / total_weight

// Construct shift-share instrument z_r = sum_n share_rn * shock_n
bysort region_id: egen z_r = total(share * shock)

// Compute s_n = sum_r e_r * share_rn (industry exposure mass)
bysort industry_id: egen s_n = total(e_r * share)

// Compute e_r-weighted regional means of y, x, z (one obs per region)
su y [aw=e_r] if region_tag==1, meanonly
scalar mean_y = r(mean)
su x [aw=e_r] if region_tag==1, meanonly
scalar mean_x = r(mean)
su z_r [aw=e_r] if region_tag==1, meanonly
scalar mean_z = r(mean)

// Demeaned variables
gen y0 = y - mean_y
gen x0 = x - mean_x
gen z0 = z_r - mean_z

// Aggregate to shock level: vbar_n = sum_r e_r * share_rn * v0_r / s_n
bysort industry_id: egen ybar_n_num = total(e_r * share * y0)
bysort industry_id: egen xbar_n_num = total(e_r * share * x0)
bysort industry_id: egen zbar_n_num = total(e_r * share * z0)

gen ybar_n = ybar_n_num / s_n
gen xbar_n = xbar_n_num / s_n
gen zbar_n = zbar_n_num / s_n

// Keep one observation per industry
bysort industry_id: gen ind_tag = (_n == 1)
keep if ind_tag == 1

// Number of industries
count
scalar N_ind = r(N)

mata:
    ybar = st_data(., "ybar_n")
    xbar = st_data(., "xbar_n")
    zbar = st_data(., "zbar_n")
    shk  = st_data(., "shock")
    sn   = st_data(., "s_n")

    N = rows(ybar)

    // Instruments matrix: [1, shock]
    Zinst = (J(N,1,1), shk)

    // --- Effect regression: ybar_n on (1, xbar_n), instrument shock ---
    Xreg = (J(N,1,1), xbar)
    ZWX = cross(Zinst, sn, Xreg)
    ZWy = cross(Zinst, sn, ybar)
    beta_eff = luinv(ZWX) * ZWy

    resid_eff = ybar - Xreg * beta_eff
    scores_eff = Zinst :* (sn :* resid_eff)
    meat_eff = cross(scores_eff, scores_eff)
    bread_eff = luinv(ZWX)
    V_eff = (N/(N-2)) * bread_eff * meat_eff * bread_eff'

    // --- First stage: xbar_n on (1, zbar_n), instrument shock ---
    Xreg2 = (J(N,1,1), zbar)
    ZWX2 = cross(Zinst, sn, Xreg2)
    ZWy2 = cross(Zinst, sn, xbar)
    beta_fs_v = luinv(ZWX2) * ZWy2

    resid_fs_v = xbar - Xreg2 * beta_fs_v
    scores_fs_v = Zinst :* (sn :* resid_fs_v)
    meat_fs_v = cross(scores_fs_v, scores_fs_v)
    bread_fs_v = luinv(ZWX2)
    V_fs_v = (N/(N-2)) * bread_fs_v * meat_fs_v * bread_fs_v'

    // Effective shocks = 1 / sum_n s_n^2
    eff_shocks_v = 1 / sum(sn:^2)

    st_numscalar("beta_effect", beta_eff[2])
    st_numscalar("se_effect",   sqrt(V_eff[2,2]))
    st_numscalar("beta_fs",     beta_fs_v[2])
    st_numscalar("se_fs",       sqrt(V_fs_v[2,2]))
    st_numscalar("eff_shocks",  eff_shocks_v)
end

display "ANSWER: effect estimate=" %21.12f beta_effect " se=" %21.12f se_effect " n_obs=" %12.0f N_ind
display "ANSWER: first_stage estimate=" %21.12f beta_fs " se=" %21.12f se_fs " n_obs=" %12.0f N_ind
display "ANSWER: effective_shocks estimate=" %21.12f eff_shocks " se=. n_obs=" %12.0f N_ind
