clear all
set more off
set linesize 255
set type double

import delimited "./input.csv", clear

tobit y x z, ll(0) tolerance(1e-10) nrtolerance(1e-10)

scalar n = e(N)

display "ANSWER: const estimate=" %21.12f _b[_cons] " se=" %21.12f _se[_cons] " n_obs=" %12.0f n
display "ANSWER: x estimate=" %21.12f _b[x] " se=" %21.12f _se[x] " n_obs=" %12.0f n
display "ANSWER: z estimate=" %21.12f _b[z] " se=" %21.12f _se[z] " n_obs=" %12.0f n
display "ANSWER: sigma estimate=" %21.12f sqrt(_b[/var(e.y)]) " se=" %21.12f . " n_obs=" %12.0f n
