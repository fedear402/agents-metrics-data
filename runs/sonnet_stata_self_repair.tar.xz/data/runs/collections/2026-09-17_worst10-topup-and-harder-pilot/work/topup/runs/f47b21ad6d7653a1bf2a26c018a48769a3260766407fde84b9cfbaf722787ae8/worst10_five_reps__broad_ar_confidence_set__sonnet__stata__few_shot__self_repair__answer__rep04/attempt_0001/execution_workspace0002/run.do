clear all
set more off
set linesize 255
set type double

import delimited "./input.csv", clear

quietly regress y
predict double ry, residuals
quietly regress endog
predict double rd, residuals
quietly regress y x z1 z2
predict double uy, residuals
scalar df = e(df_r)
quietly regress endog x z1 z2
predict double ud, residuals

scalar n = _N
scalar q_val = 2
scalar critical = invFtail(q_val, df, .05)
scalar k = q_val * critical / df

mata:
ry = st_data(., "ry")
rd = st_data(., "rd")
uy = st_data(., "uy")
ud = st_data(., "ud")
k = st_numscalar("k")
q2 = st_numscalar("q_val")
df_val = st_numscalar("df")

A = quadcross(rd,rd) - (1+k)*quadcross(ud,ud)
B = -2*(quadcross(ry,rd) - (1+k)*quadcross(uy,ud))
C = quadcross(ry,ry) - (1+k)*quadcross(uy,uy)

disc = B^2 - 4*A*C

if (abs(A) > 1e-10 & disc > 0) {
    b1 = (-B - sqrt(disc)) / (2*A)
    b2 = (-B + sqrt(disc)) / (2*A)
    bounds = sort((b1 \ b2), 1)
    st_numscalar("low", bounds[1])
    st_numscalar("high", bounds[2])
    st_numscalar("unbounded", A < 0)
    st_numscalar("accepts_zero", C <= 0)
} else {
    st_numscalar("low", .)
    st_numscalar("high", .)
    st_numscalar("unbounded", .)
    st_numscalar("accepts_zero", .)
}

beta1 = 1
SSR_R1 = quadcross(ry - beta1*rd, ry - beta1*rd)
SSR_U1 = quadcross(uy - beta1*ud, uy - beta1*ud)
F1 = ((SSR_R1 - SSR_U1)/q2) / (SSR_U1/df_val)
st_numscalar("F_at_one", F1)
end

display "ANSWER: boundary_low estimate=" %21.12f low " se=" %21.12f . " n_obs=" %12.0f n
display "ANSWER: boundary_high estimate=" %21.12f high " se=" %21.12f . " n_obs=" %12.0f n
display "ANSWER: accepts_zero estimate=" %21.12f accepts_zero " se=" %21.12f . " n_obs=" %12.0f n
display "ANSWER: unbounded estimate=" %21.12f unbounded " se=" %21.12f . " n_obs=" %12.0f n
display "ANSWER: ar_f_at_one estimate=" %21.12f F_at_one " se=" %21.12f . " n_obs=" %12.0f n
