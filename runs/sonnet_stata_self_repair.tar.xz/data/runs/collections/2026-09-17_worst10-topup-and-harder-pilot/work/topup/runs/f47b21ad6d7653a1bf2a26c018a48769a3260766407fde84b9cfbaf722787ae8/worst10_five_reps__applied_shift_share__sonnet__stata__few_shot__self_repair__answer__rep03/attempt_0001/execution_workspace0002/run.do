version 17.0
clear all
set more off
set linesize 255

import delimited "./input.csv", clear

// Normalize regional weights (one obs per region)
bysort region_id: gen region_tag = (_n == 1)
egen total_weight = total(region_weight * region_tag)
gen e_r = region_weight / total_weight

// Construct shift-share instrument z_r = sum_n share_rn * shock_n
gen z_r_contrib = share * shock
bysort region_id: egen z_r = total(z_r_contrib)

// Compute e_r-weighted regional means (summing over one obs per region)
egen mean_y = total(e_r * y * region_tag)
egen mean_x = total(e_r * x * region_tag)
egen mean_z = total(e_r * z_r * region_tag)

gen y0 = y - mean_y
gen x0 = x - mean_x
gen z0 = z_r - mean_z

// Compute s_n = sum_r e_r * share_rn
bysort industry_id: egen s_n = total(e_r * share)

// Aggregate residuals to shock level
bysort industry_id: egen ybar_num = total(e_r * share * y0)
bysort industry_id: egen xbar_num = total(e_r * share * x0)
bysort industry_id: egen zbar_num = total(e_r * share * z0)

gen ybar_n = ybar_num / s_n
gen xbar_n = xbar_num / s_n
gen zbar_n = zbar_num / s_n

// Keep one obs per industry
bysort industry_id: gen industry_tag = (_n == 1)
keep if industry_tag == 1

sort industry_id

mata:
    // Read data using st_data
    data = st_data(., ("ybar_n", "xbar_n", "zbar_n", "shock", "s_n"))
    
    m_ybar  = data[,1]
    m_xbar  = data[,2]
    m_zbar  = data[,3]
    m_shock = data[,4]
    m_sn    = data[,5]
    
    M = rows(m_ybar)
    
    // Effect regression: ybar on (1, xbar), IV (1, shock), weight = s_n
    Ye = m_ybar
    Xe = J(M,1,1), m_xbar
    Ze = J(M,1,1), m_shock
    W  = m_sn
    
    ZtWXe = Ze' * (W :* Xe)
    ZtWYe = Ze' * (W :* Ye)
    beta_e = luinv(ZtWXe) * ZtWYe
    
    resid_e  = Ye - Xe * beta_e
    scores_e = Ze :* (W :* resid_e)
    meat_e   = scores_e' * scores_e
    iZtWXe   = luinv(ZtWXe)
    V_e      = (M / (M - 2)) * iZtWXe * meat_e * iZtWXe'
    
    est_e = beta_e[2]
    se_e  = sqrt(V_e[2,2])
    
    // First-stage regression: xbar on (1, zbar), IV (1, shock), weight = s_n
    Yf = m_xbar
    Xf = J(M,1,1), m_zbar
    Zf = J(M,1,1), m_shock
    
    ZtWXf = Zf' * (W :* Xf)
    ZtWYf = Zf' * (W :* Yf)
    beta_f = luinv(ZtWXf) * ZtWYf
    
    resid_f  = Yf - Xf * beta_f
    scores_f = Zf :* (W :* resid_f)
    meat_f   = scores_f' * scores_f
    iZtWXf   = luinv(ZtWXf)
    V_f      = (M / (M - 2)) * iZtWXf * meat_f * iZtWXf'
    
    est_f = beta_f[2]
    se_f  = sqrt(V_f[2,2])
    
    // Effective shocks = 1 / sum_n s_n^2
    eff = 1 / sum(m_sn :^ 2)
    
    st_numscalar("est_effect",    est_e)
    st_numscalar("se_effect",     se_e)
    st_numscalar("est_fs",        est_f)
    st_numscalar("se_fs",         se_f)
    st_numscalar("eff_shocks",    eff)
    st_numscalar("N_ind",         M)
end

display "ANSWER: effect estimate=" %21.12f est_effect " se=" %21.12f se_effect " n_obs=" %12.0f N_ind
display "ANSWER: first_stage estimate=" %21.12f est_fs " se=" %21.12f se_fs " n_obs=" %12.0f N_ind
display "ANSWER: effective_shocks estimate=" %21.12f eff_shocks " se=" . " n_obs=" %12.0f N_ind
