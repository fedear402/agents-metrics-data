set linesize 255
import delimited "./input.csv", clear

keep if abs(score) < 1
scalar n_obs = _N

gen weight = 1 - abs(score)
gen right = (score >= 0)
gen score_right = score * right
gen score_left  = score * (1 - right)

* Build design matrix and outcomes in Mata, compute everything there
mkmat weight right score_left score_right earnings participated, matrix(DATA)

mata:
    data   = st_matrix("DATA")
    w      = data[., 1]
    X      = data[., 2..4]   // right, score_left, score_right
    cons   = J(rows(X), 1, 1)
    X      = cons, X          // intercept, right, score_left, score_right
    y_earn = data[., 5]
    y_part = data[., 6]

    // WLS: beta = (X'WX)^-1 X'Wy
    W      = diag(w)
    XtWX   = X' * W * X
    XtWX_i = invsym(XtWX)

    b_rf   = XtWX_i * (X' * (w :* y_earn))
    b_fs   = XtWX_i * (X' * (w :* y_part))

    e_rf   = y_earn - X * b_rf
    e_fs   = y_part - X * b_fs

    // HC0 meat for each equation and cross
    // score_i = w_i * x_i * e_i  (column vectors stacked as rows)
    S_rf   = X :* (w :* e_rf)   // n x 4
    S_fs   = X :* (w :* e_fs)   // n x 4

    meat_rf    = S_rf' * S_rf
    meat_fs    = S_fs' * S_fs
    meat_cross = S_rf' * S_fs

    V_rf    = XtWX_i * meat_rf    * XtWX_i
    V_fs    = XtWX_i * meat_fs    * XtWX_i
    V_cross = XtWX_i * meat_cross * XtWX_i

    // Discontinuity = coefficient on "right" = position 2
    rf_est  = b_rf[2]
    fs_est  = b_fs[2]
    var_rf  = V_rf[2, 2]
    var_fs  = V_fs[2, 2]
    cov_rfs = V_cross[2, 2]

    te_est  = rf_est / fs_est
    var_te  = (1/fs_est)^2 * var_rf - 2*(rf_est/fs_est^2)*cov_rfs + (rf_est/fs_est^2)^2 * var_fs

    st_numscalar("rf_est",  rf_est)
    st_numscalar("fs_est",  fs_est)
    st_numscalar("te_est",  te_est)
    st_numscalar("rf_se",   sqrt(var_rf))
    st_numscalar("fs_se",   sqrt(var_fs))
    st_numscalar("te_se",   sqrt(var_te))
end

display "ANSWER: treatment_effect estimate=" %21.12f te_est " se=" %21.12f te_se " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate="     %21.12f rf_est " se=" %21.12f rf_se " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate="      %21.12f fs_est " se=" %21.12f fs_se " n_obs=" %12.0f n_obs
