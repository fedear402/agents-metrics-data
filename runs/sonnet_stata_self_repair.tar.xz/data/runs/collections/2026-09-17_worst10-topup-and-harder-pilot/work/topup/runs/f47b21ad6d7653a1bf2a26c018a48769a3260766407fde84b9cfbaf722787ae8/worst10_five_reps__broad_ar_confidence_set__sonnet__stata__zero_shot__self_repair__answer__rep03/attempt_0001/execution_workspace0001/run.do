set linesize 255
clear all

import delimited "./input.csv", varnames(1) case(preserve)

quietly summarize y
local n = r(N)

* Anderson-Rubin test: for each beta, regress (y - beta*endog) on intercept, x, z1, z2
* F test of joint significance of z1 and z2 coefficients
* Accept beta if F <= F_critical(2, n-4, 0.95)

local n_obs = `n'
local df1 = 2
local df2 = `n' - 4
local F_crit = invFtail(`df1', `df2', 0.05)

* The AR F statistic as a function of beta is a quadratic in beta
* F(beta) = [RSS_restricted(beta) - RSS_unrestricted(beta)] / (2 * s^2_unrestricted)
* where restricted means z1,z2 coefficients = 0
* unrestricted means full regression of (y-beta*endog) on intercept, x, z1, z2

* Let's derive analytically. Define w = y - beta*endog
* Full model: w = a0 + a1*x + a2*z1 + a3*z2 + e
* Restricted model: w = b0 + b1*x + e

* The F stat is quadratic in beta. Find roots of F(beta) = F_crit

* Compute necessary projections
* Let M_xc = annihilator of [1, x]
* Let M_full = annihilator of [1, x, z1, z2]

* First, get residuals from regressing everything on [1, x]
tempvar e_y e_endog e_z1 e_z2

quietly regress y x
predict double `e_y', resid

quietly regress endog x
predict double `e_endog', resid

quietly regress z1 x
predict double `e_z1', resid

quietly regress z2 x
predict double `e_z2', resid

* Now the F statistic for beta:
* w_tilde = e_y - beta*e_endog (residuals after projecting out [1,x])
* Full residuals: project w_tilde on [e_z1, e_z2]
* RSS_R = w_tilde'w_tilde
* RSS_U = RSS from regressing w_tilde on e_z1, e_z2

* Let A = [e_z1, e_z2], a 2-column matrix
* Let P_A = A(A'A)^{-1}A' projection onto A
* RSS_U = w_tilde'(I - P_A)w_tilde
* RSS_R - RSS_U = w_tilde'P_A w_tilde

* F = (w_tilde'P_A w_tilde / 2) / (w_tilde'(I-P_A)w_tilde / (n-4))

* Let's compute needed dot products
* w_tilde = e_y - beta*e_endog

* Compute: A = [e_z1, e_z2], (A'A)^{-1}
* and A'w_tilde = A'e_y - beta*A'e_endog

* Precompute scalar products
quietly {
    * Sums of squares and cross products
    generate double tmp1 = `e_z1'^2
    generate double tmp2 = `e_z2'^2
    generate double tmp3 = `e_z1'*`e_z2'
    
    summarize tmp1, meanonly
    scalar sz1z1 = r(sum)
    summarize tmp2, meanonly
    scalar sz2z2 = r(sum)
    summarize tmp3, meanonly
    scalar sz1z2 = r(sum)
    
    drop tmp1 tmp2 tmp3
    
    generate double tmp1 = `e_z1'*`e_y'
    generate double tmp2 = `e_z2'*`e_y'
    summarize tmp1, meanonly
    scalar sz1ey = r(sum)
    summarize tmp2, meanonly
    scalar sz2ey = r(sum)
    drop tmp1 tmp2
    
    generate double tmp1 = `e_z1'*`e_endog'
    generate double tmp2 = `e_z2'*`e_endog'
    summarize tmp1, meanonly
    scalar sz1ee = r(sum)
    summarize tmp2, meanonly
    scalar sz2ee = r(sum)
    drop tmp1 tmp2
    
    generate double tmp1 = `e_y'^2
    summarize tmp1, meanonly
    scalar seyey = r(sum)
    drop tmp1
    
    generate double tmp1 = `e_endog'^2
    summarize tmp1, meanonly
    scalar seeee = r(sum)
    drop tmp1
    
    generate double tmp1 = `e_y'*`e_endog'
    summarize tmp1, meanonly
    scalar seyee = r(sum)
    drop tmp1
}

* (A'A) = [sz1z1 sz1z2; sz1z2 sz2z2]
* det = sz1z1*sz2z2 - sz1z2^2
scalar det_AA = sz1z1*sz2z2 - sz1z2^2

* (A'A)^{-1} = (1/det)*[sz2z2 -sz1z2; -sz1z2 sz1z1]

* A'w = [sz1ey - beta*sz1ee; sz2ey - beta*sz2ee]
* Let c1 = sz1ey - beta*sz1ee, c2 = sz2ey - beta*sz2ee

* w'P_A w = c'(A'A)^{-1}c = (1/det)*(c1^2*sz2z2 - 2*c1*c2*sz1z2 + c2^2*sz1z1)

* w'w = seyey - 2*beta*seyee + beta^2*seeee

* F(beta) = (w'P_A w / 2) / ((w'w - w'P_A w) / (n-4))

* Let's expand numerator w'P_A w as quadratic in beta:
* c1 = sz1ey - beta*sz1ee
* c2 = sz2ey - beta*sz2ee
* c1^2 = sz1ey^2 - 2*beta*sz1ey*sz1ee + beta^2*sz1ee^2
* c2^2 = sz2ey^2 - 2*beta*sz2ey*sz2ee + beta^2*sz2ee^2
* c1*c2 = sz1ey*sz2ey - beta*(sz1ey*sz2ee+sz2ey*sz1ee) + beta^2*sz1ee*sz2ee

* w'P_A w = (1/det)*[sz2z2*c1^2 - 2*sz1z2*c1*c2 + sz1z1*c2^2]

* Numerator of F: w'P_A w / 2
* Denominator of F: (w'w - w'P_A w)/(n-4)
* F = c_crit means: (n-4)*w'P_A w = 2*F_crit*(w'w - w'P_A w)
* (n-4)*w'P_A w = 2*F_crit*w'w - 2*F_crit*w'P_A w
* w'P_A w * [(n-4) + 2*F_crit] = 2*F_crit*w'w
* w'P_A w * (n-4+2*F_crit) - 2*F_crit*w'w = 0

* This is a quadratic in beta. Let's solve it.

* Precompute coefficients of w'P_A w (quadratic in beta)
* numer_coeff = coefficient in (1/det)*[sz2z2*c1^2 - 2*sz1z2*c1*c2 + sz1z1*c2^2]

* Coefficient of beta^2 in numerator (before 1/det):
scalar pA_b2 = sz2z2*sz1ee^2 - 2*sz1z2*sz1ee*sz2ee + sz1z1*sz2ee^2
* Coefficient of beta^1:
scalar pA_b1 = sz2z2*(-2*sz1ey*sz1ee) - 2*sz1z2*(-(sz1ey*sz2ee+sz2ey*sz1ee)) + sz1z1*(-2*sz2ey*sz2ee)
* = -2*sz2z2*sz1ey*sz1ee + 2*sz1z2*(sz1ey*sz2ee+sz2ey*sz1ee) - 2*sz1z1*sz2ey*sz2ee
* Coefficient of beta^0:
scalar pA_b0 = sz2z2*sz1ey^2 - 2*sz1z2*sz1ey*sz2ey + sz1z1*sz2ey^2

* So w'P_A w = (1/det)*(pA_b2*beta^2 + pA_b1*beta + pA_b0)

* w'w = seeee*beta^2 - 2*seyee*beta + seyey

* Equation: w'P_A w*(n-4+2*F_crit) - 2*F_crit*w'w = 0
* (1/det)*(pA_b2*beta^2 + pA_b1*beta + pA_b0)*(n-4+2*F_crit) - 2*F_crit*(seeee*beta^2 - 2*seyee*beta + seyey) = 0

scalar k = `df2' + 2*`F_crit'

scalar QA = pA_b2*k/det_AA - 2*`F_crit'*seeee
scalar QB = pA_b1*k/det_AA + 4*`F_crit'*seyee
scalar QC = pA_b0*k/det_AA - 2*`F_crit'*seyey

* Solve QA*beta^2 + QB*beta + QC = 0
scalar disc = QB^2 - 4*QA*QC

display "QA=" QA " QB=" QB " QC=" QC " disc=" disc

* If disc > 0 and QA > 0: two roots, finite interval
* If disc > 0 and QA < 0: two roots, union of two rays (unbounded)
* If disc < 0 and QA > 0: no solution, empty set (never accept)
* If disc < 0 and QA < 0: no solution, always accept (unbounded)

scalar root1 = (-QB - sqrt(disc))/(2*QA)
scalar root2 = (-QB + sqrt(disc))/(2*QA)

* root1 < root2 since we subtract/add sqrt(disc) and divide by 2*QA
* If QA > 0: roots are correct as lower/upper bounds
* If QA < 0: the set is outside [root1, root2], so unbounded

scalar boundary_low = min(root1, root2)
scalar boundary_high = max(root1, root2)

* Compute AR F at beta=1
scalar c1_at1 = sz1ey - sz1ee
scalar c2_at1 = sz2ey - sz2ee
scalar pAw_at1 = (sz2z2*c1_at1^2 - 2*sz1z2*c1_at1*c2_at1 + sz1z1*c2_at1^2)/det_AA
scalar ww_at1 = seyey - 2*seyee + seeee
scalar ar_f_at_one = (pAw_at1/2)/((ww_at1 - pAw_at1)/`df2')

* accepts_zero: F(0) <= F_crit?
scalar pAw_at0 = (sz2z2*sz1ey^2 - 2*sz1z2*sz1ey*sz2ey + sz1z1*sz2ey^2)/det_AA
scalar ww_at0 = seyey
scalar ar_f_at0 = (pAw_at0/2)/((ww_at0 - pAw_at0)/`df2')
scalar accepts_zero = (ar_f_at0 <= `F_crit')

* unbounded: if QA < 0, set is unbounded (two rays)
scalar unbounded = (QA < 0)

display "F_crit=" `F_crit'
display "disc=" disc
display "QA=" QA
display "AR F at 0=" ar_f_at0
display "AR F at 1=" ar_f_at_one

display "ANSWER: boundary_low estimate=" %21.12f boundary_low " se=" %21.12f . " n_obs=" %12.0f `n_obs'
display "ANSWER: boundary_high estimate=" %21.12f boundary_high " se=" %21.12f . " n_obs=" %12.0f `n_obs'
display "ANSWER: accepts_zero estimate=" %21.12f accepts_zero " se=" %21.12f . " n_obs=" %12.0f `n_obs'
display "ANSWER: unbounded estimate=" %21.12f unbounded " se=" %21.12f . " n_obs=" %12.0f `n_obs'
display "ANSWER: ar_f_at_one estimate=" %21.12f ar_f_at_one " se=" %21.12f . " n_obs=" %12.0f `n_obs'
