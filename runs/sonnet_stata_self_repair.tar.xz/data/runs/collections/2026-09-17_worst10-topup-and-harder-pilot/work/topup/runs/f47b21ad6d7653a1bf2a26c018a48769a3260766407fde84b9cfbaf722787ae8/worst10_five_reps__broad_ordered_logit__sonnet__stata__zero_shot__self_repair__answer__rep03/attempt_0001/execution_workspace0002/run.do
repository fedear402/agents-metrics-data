set linesize 255
import delimited "./input.csv", clear

ologit y x z

scalar b_x = _b[x]
scalar b_z = _b[z]
scalar se_x = _se[x]
scalar se_z = _se[z]
scalar n = e(N)

margins, at(x=1 z=0) predict(outcome(3))
scalar prob_high = r(b)[1,1]

display "ANSWER: x estimate=" %21.12f b_x " se=" %21.12f se_x " n_obs=" %12.0f n
display "ANSWER: z estimate=" %21.12f b_z " se=" %21.12f se_z " n_obs=" %12.0f n
display "ANSWER: prob_high estimate=" %21.12f prob_high " se=." " n_obs=" %12.0f n
