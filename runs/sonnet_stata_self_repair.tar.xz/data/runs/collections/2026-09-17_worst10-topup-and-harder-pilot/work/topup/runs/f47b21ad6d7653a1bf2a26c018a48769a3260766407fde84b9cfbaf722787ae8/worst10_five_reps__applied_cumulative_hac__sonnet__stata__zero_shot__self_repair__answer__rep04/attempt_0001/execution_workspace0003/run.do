set linesize 255
import delimited "./input.csv", clear

sort date

gen log_sales = ln(sales)
gen log_vix = ln(vix)

gen obs = _n
tsset obs

gen d_log_vix = log_vix - log_vix[_n-1]

forvalues k = 1/15 {
    gen d_log_vix_lag`k' = d_log_vix[_n-`k']
}

newey log_sales d_log_vix_lag1-d_log_vix_lag15, lag(15)

scalar N2 = e(N)

matrix V_nw = e(V)
scalar scale = N2 / (N2 - 16)
matrix V_scaled = scale * V_nw

matrix b = e(b)

scalar cum_resp = 0
forvalues k = 1/15 {
    scalar cum_resp = cum_resp + b[1, `k']
}

matrix c = J(1, 16, 0)
forvalues k = 1/15 {
    matrix c[1, `k'] = 1
}
matrix var_cum = c * V_scaled * c'
scalar se_cum = sqrt(var_cum[1,1])

scalar se_lag1 = sqrt(V_scaled[1,1])
scalar se_lag15 = sqrt(V_scaled[15,15])

scalar b_lag1 = b[1,1]
scalar b_lag15 = b[1,15]

display "ANSWER: cumulative_response estimate=" %21.12f cum_resp " se=" %21.12f se_cum " n_obs=" %12.0f N2
display "ANSWER: lag_1 estimate=" %21.12f b_lag1 " se=" %21.12f se_lag1 " n_obs=" %12.0f N2
display "ANSWER: lag_15 estimate=" %21.12f b_lag15 " se=" %21.12f se_lag15 " n_obs=" %12.0f N2
