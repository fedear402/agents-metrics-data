clear all
set more off
set linesize 255
set type double

import delimited ./input.csv, clear

quietly regress y x
scalar n = e(N)
scalar df = n - 4
scalar q = 2
scalar critical = invFtail(q, df, .05)
scalar k = q * critical / df

foreach v of varlist y endog z1 z2 {
    quietly regress `v' x
    predict double r_`v', residuals
}

mata:
ry  = st_data(., "r_y")
rd  = st_data(., "r_endog")
rz1 = st_data(., "r_z1")
rz2 = st_data(., "r_z2")
k   = st_numscalar("k")

A0 = quadcross(ry, ry)
B0 = quadcross(ry, rd)
C0 = quadcross(rd, rd)

RZ    = (rz1, rz2)
ZZ    = quadcross(RZ, RZ)
ZZinv = luinv(ZZ)
Zry   = quadcross(RZ, ry)
Zrd   = quadcross(RZ, rd)

ryPzry = (Zry' * ZZinv * Zry)[1,1]
rdPzrd = (Zrd' * ZZinv * Zrd)[1,1]
ryPzrd = (Zry' * ZZinv * Zrd)[1,1]

A_coef = -k*C0 + (1+k)*rdPzrd
B_coef =  2*k*B0 - 2*(1+k)*ryPzrd
C_coef = -k*A0 + (1+k)*ryPzry

disc = B_coef^2 - 4*A_coef*C_coef

r1 = (-B_coef - sqrt(disc)) / (2*A_coef)
r2 = (-B_coef + sqrt(disc)) / (2*A_coef)
bounds = sort((r1 \ r2), 1)
r1 = bounds[1]
r2 = bounds[2]

unbounded    = (A_coef < 0)
accepts_zero = (C_coef <= 0)

beta1  = 1
e1     = ry - beta1*rd
Ze1    = quadcross(RZ, e1)
e1Pze1 = (Ze1' * ZZinv * Ze1)[1,1]
e1e1   = quadcross(e1, e1)
SSR_R1 = e1e1
SSR_U1 = e1e1 - e1Pze1
df_r   = st_numscalar("df")
q_r    = st_numscalar("q")
ar_f1  = ((SSR_R1 - SSR_U1)/q_r) / (SSR_U1/df_r)

st_numscalar("low",          r1)
st_numscalar("high",         r2)
st_numscalar("unbounded",    unbounded)
st_numscalar("accepts_zero", accepts_zero)
st_numscalar("ar_f_at_one",  ar_f1)
end

display "ANSWER: boundary_low estimate="  %21.12f low          " se=" %21.12f . " n_obs=" %12.0f n
display "ANSWER: boundary_high estimate=" %21.12f high         " se=" %21.12f . " n_obs=" %12.0f n
display "ANSWER: accepts_zero estimate="  %21.12f accepts_zero " se=" %21.12f . " n_obs=" %12.0f n
display "ANSWER: unbounded estimate="     %21.12f unbounded    " se=" %21.12f . " n_obs=" %12.0f n
display "ANSWER: ar_f_at_one estimate="   %21.12f ar_f_at_one  " se=" %21.12f . " n_obs=" %12.0f n
