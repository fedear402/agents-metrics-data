version 17.0
clear all
set more off
set linesize 255

import delimited "./input.csv", clear

// Normalize regional weights (one obs per region)
bysort region_id: gen region_tag = (_n == 1)
egen total_weight = total(region_weight * region_tag)
gen e_r = region_weight / total_weight

// Construct shift-share instrument z_r = sum_n share_rn * shock_n
bysort region_id: gen z_r_contrib = share * shock
bysort region_id: egen z_r = total(z_r_contrib)

// Keep one obs per region for regional-level calculations
// but first compute e_r-weighted means of y, x, z
egen mean_y = total(e_r * y * region_tag)
egen mean_x = total(e_r * x * region_tag)
egen mean_z = total(e_r * z_r * region_tag)

gen y0 = y - mean_y
gen x0 = x - mean_x
gen z0 = z_r - mean_z

// Compute s_n = sum_r e_r * share_rn (industry exposure mass)
bysort industry_id: egen s_n = total(e_r * share)

// Aggregate residuals to shock level:
// vbar_n = sum_r e_r * share_rn * v0_r / s_n
bysort industry_id: egen ybar_n_num = total(e_r * share * y0)
bysort industry_id: egen xbar_n_num = total(e_r * share * x0)
bysort industry_id: egen zbar_n_num = total(e_r * share * z0)

gen ybar_n = ybar_n_num / s_n
gen xbar_n = xbar_n_num / s_n
gen zbar_n = zbar_n_num / s_n

// Keep one obs per industry
bysort industry_id: gen industry_tag = (_n == 1)
keep if industry_tag == 1

// Number of industries
count
local N = r(N)

// Shock-level IV regression: ybar_n on intercept + xbar_n, IV = shock_n, weight = s_n
// Manual IV computation using mata

mata:
    st_view(ybar, ., "ybar_n")
    st_view(xbar, ., "xbar_n")
    st_view(zbar, ., "zbar_n")
    st_view(shock_v, ., "shock")
    st_view(sn, ., "s_n")
    
    N = rows(ybar)
    
    // Matrices for IV: endogenous = xbar, instrument = shock
    // Effect regression: y on (1, x), IV (1, shock)
    Y = ybar
    X = J(N,1,1), xbar
    Z = J(N,1,1), shock_v
    W = sn
    
    // Weighted IV: beta = (Z'WX)^{-1} Z'WY
    ZtWX = Z' * (W :* X)
    ZtWY = Z' * (W :* Y)
    beta_effect = luinv(ZtWX) * ZtWY
    
    // Structural residuals
    resid_effect = Y - X * beta_effect
    
    // Scores: Z_i * W_i * resid_i
    scores_effect = Z :* (W :* resid_effect)
    
    // HC1 variance: N/(N-2) * (Z'WX)^{-1} * (scores'scores) * (Z'WX)^{-T}
    meat_effect = scores_effect' * scores_effect
    inv_ZtWX = luinv(ZtWX)
    V_effect = (N / (N-2)) * inv_ZtWX * meat_effect * inv_ZtWX'
    
    se_effect = sqrt(V_effect[2,2])
    est_effect = beta_effect[2]
    
    // First-stage regression: xbar on (1, zbar), IV (1, shock), weight = s_n
    // Endogenous regressor is zbar_n
    Y2 = xbar
    X2 = J(N,1,1), zbar
    Z2 = J(N,1,1), shock_v
    
    ZtWX2 = Z2' * (W :* X2)
    ZtWY2 = Z2' * (W :* Y2)
    beta_fs = luinv(ZtWX2) * ZtWY2
    
    resid_fs = Y2 - X2 * beta_fs
    scores_fs = Z2 :* (W :* resid_fs)
    meat_fs = scores_fs' * scores_fs
    inv_ZtWX2 = luinv(ZtWX2)
    V_fs = (N / (N-2)) * inv_ZtWX2 * meat_fs * inv_ZtWX2'
    
    se_fs = sqrt(V_fs[2,2])
    est_fs = beta_fs[2]
    
    // Effective shocks = 1 / sum_n s_n^2
    eff_shocks = 1 / sum(sn:^2)
    
    st_numscalar("est_effect", est_effect)
    st_numscalar("se_effect", se_effect)
    st_numscalar("est_fs", est_fs)
    st_numscalar("se_fs", se_fs)
    st_numscalar("eff_shocks", eff_shocks)
    st_numscalar("N_ind", N)
end

display "ANSWER: effect estimate=" %21.12f est_effect " se=" %21.12f se_effect " n_obs=" %12.0f N_ind
display "ANSWER: first_stage estimate=" %21.12f est_fs " se=" %21.12f se_fs " n_obs=" %12.0f N_ind
display "ANSWER: effective_shocks estimate=" %21.12f eff_shocks " se=" %21.12f . " n_obs=" %12.0f N_ind
