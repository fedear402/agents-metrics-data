set linesize 255
clear all

import delimited "./input.csv", varnames(1)

// Step 1: Collapse to region level (one obs per region)
// Keep region_id, x, y, region_weight and compute z_r = sum_n share_rn * shock_n

// First compute z_r at region level
bysort region_id: egen z = sum(share * shock)

// Collapse to region level
collapse (first) x y region_weight z, by(region_id)

// Normalize weights
quietly sum region_weight
gen e = region_weight / r(sum)

// Step 2: Weighted demean y, x, z using e weights
foreach v in y x z {
    quietly sum `v' [aw=e]
    gen `v'0 = `v' - r(mean)
}

// Save region-level data
tempfile region_data
save `region_data'

// Step 3: Load original data again for shock-level aggregation
import delimited "./input.csv", varnames(1) clear

// Merge region-level demeaned variables back
bysort region_id: egen z_reg = sum(share * shock)
collapse (first) x y region_weight z_reg, by(region_id)
quietly sum region_weight
gen e = region_weight / r(sum)
foreach v in y x z_reg {
    quietly sum `v' [aw=e]
    gen `v'0 = `v' - r(mean)
}
rename z_reg0 z0
rename x0 x0_r
rename y0 y0_r
tempfile region_demean
save `region_demean'

// Reload original data
import delimited "./input.csv", varnames(1) clear

// Merge region-level e and demeaned vars
merge m:1 region_id using `region_demean', keepusing(e x0_r y0_r z0)
drop _merge

// Step 4: Compute s_n = sum_r e_r * share_rn
bysort industry_id: egen s_n = sum(e * share)

// Compute shock-level aggregated residuals
// ybar_n = sum_r e_r * share_rn * y0_r / s_n
bysort industry_id: egen ybar_num = sum(e * share * y0_r)
gen ybar_n = ybar_num / s_n

bysort industry_id: egen xbar_num = sum(e * share * x0_r)
gen xbar_n = xbar_num / s_n

bysort industry_id: egen zbar_num = sum(e * share * z0)
gen zbar_n = zbar_num / s_n

// Collapse to industry level
collapse (first) shock s_n ybar_n xbar_n zbar_n, by(industry_id)

// Number of industries
count
local N = r(N)

// Step 5: Shock-level IV regression: ybar_n on xbar_n, instrument = shock, weights = s_n
// 2SLS manually for HC1 robust SE

// First stage of shock-level IV: regress xbar_n on shock (weighted by s_n)
// We need to instrument xbar_n with shock_n

// Weighted means
quietly sum shock [aw=s_n]
local shock_mean = r(mean)
quietly sum xbar_n [aw=s_n]
local xbar_mean = r(mean)
quietly sum ybar_n [aw=s_n]
local ybar_mean = r(mean)
quietly sum zbar_n [aw=s_n]
local zbar_mean = r(mean)

gen shock_dm = shock - `shock_mean'
gen xbar_dm = xbar_n - `xbar_mean'
gen ybar_dm = ybar_n - `ybar_mean'
gen zbar_dm = zbar_n - `zbar_mean'

// 2SLS slope for effect: beta = cov_w(shock, ybar) / cov_w(shock, xbar)
quietly sum shock_dm [aw=s_n]  // just to normalize
gen w_shock_ybar = s_n * shock_dm * ybar_dm
gen w_shock_xbar = s_n * shock_dm * xbar_dm

quietly sum w_shock_ybar
local cov_sy = r(sum)
quietly sum w_shock_xbar
local cov_sx = r(sum)

local beta_effect = `cov_sy' / `cov_sx'

// 2SLS residuals for effect: u_n = ybar_n - beta * xbar_n (no intercept after demeaning)
// Actually with intercept: alpha = ybar_mean - beta * xbar_mean (both are 0 after demeaning... wait)
// After demeaning ybar and xbar (weighted), the intercept in the demeaned regression is 0
// But the original regression has intercept, so residuals = ybar_dm - beta * xbar_dm
gen u_effect = ybar_dm - `beta_effect' * xbar_dm

// HC1 SE for beta_effect
// Var(beta) = (sum_n s_n * shock_dm_n * u_n)^2 / (sum_n s_n * shock_dm_n * xbar_dm_n)^2 * N/(N-2)
// Actually HC1: V = [sum_n s_n^2 * shock_dm_n^2 * u_n^2] * N/(N-2) / (sum_n s_n * shock_dm_n * xbar_dm_n)^2

gen score_effect = s_n * shock_dm * u_effect
quietly sum score_effect
gen score_sq_effect = score_effect^2
quietly sum score_sq_effect
local meat_effect = r(sum)

local se_effect = sqrt(`meat_effect' * `N' / (`N' - 2)) / abs(`cov_sx')

// Step 6: First stage slope: regress xbar_n on zbar_n, instrument = shock, weights = s_n
// beta_fs = cov_w(shock, xbar) / cov_w(shock, zbar)
gen w_shock_zbar = s_n * shock_dm * zbar_dm
quietly sum w_shock_zbar
local cov_sz = r(sum)

local beta_fs = `cov_sx' / `cov_sz'

// First stage residuals: xbar_dm - beta_fs * zbar_dm
gen u_fs = xbar_dm - `beta_fs' * zbar_dm

// HC1 SE for first stage
gen score_fs = s_n * shock_dm * u_fs
gen score_sq_fs = score_fs^2
quietly sum score_sq_fs
local meat_fs = r(sum)

local se_fs = sqrt(`meat_fs' * `N' / (`N' - 2)) / abs(`cov_sz')

// Step 7: Effective shocks = 1 / sum_n s_n^2
gen s_n_sq = s_n^2
quietly sum s_n_sq
local eff_shocks = 1 / r(sum)

// Report
display "ANSWER: effect estimate=" %21.12f `beta_effect' " se=" %21.12f `se_effect' " n_obs=" %12.0f `N'
display "ANSWER: first_stage estimate=" %21.12f `beta_fs' " se=" %21.12f `se_fs' " n_obs=" %12.0f `N'
display "ANSWER: effective_shocks estimate=" %21.12f `eff_shocks' " se=" %21.12f . " n_obs=" %12.0f `N'
