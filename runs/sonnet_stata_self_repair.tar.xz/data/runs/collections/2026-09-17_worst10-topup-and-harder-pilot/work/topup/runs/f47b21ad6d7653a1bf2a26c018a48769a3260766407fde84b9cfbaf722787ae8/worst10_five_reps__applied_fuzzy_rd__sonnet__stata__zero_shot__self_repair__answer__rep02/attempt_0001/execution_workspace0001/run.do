set linesize 255
import delimited "./input.csv", clear

* Keep observations within bandwidth
keep if abs(score) < 1

* Count observations
scalar n_obs = _N

* Generate triangular weights
gen weight = 1 - abs(score)

* Generate right-side indicator
gen right = (score >= 0)

* Generate interaction terms for local linear regression
gen score_right = score * right
gen score_left = score * (1 - right)

* Stack system: run WLS for earnings (reduced form) and participated (first stage)
* For reduced form: earnings ~ right + score_left + score_right (with intercept)
* The coefficient on "right" is the discontinuity

* Reduced form: earnings
reg earnings right score_left score_right [aw=weight], vce(hc0)
scalar rf_est = _b[right]
scalar rf_se = _se[right]

* First stage: participated
reg participated right score_left score_right [aw=weight], vce(hc0)
scalar fs_est = _b[right]
scalar fs_se = _se[right]

* For delta method on treatment_effect = rf_est / fs_est
* Var(rf/fs) = (1/fs)^2 * Var(rf) - 2*(rf/fs^2)*Cov(rf,fs) + (rf/fs^2)^2 * Var(fs)
* Need joint covariance from same observations

* Use seemingly unrelated regression (sureg) to get joint covariance
sureg (earnings right score_left score_right) (participated right score_left score_right) [aw=weight], isure

* Extract estimates
scalar rf_est2 = _b[earnings:right]
scalar fs_est2 = _b[participated:right]

* Get variance-covariance
scalar var_rf = e(V)[1,1]
scalar var_fs = e(V)[5,5]
scalar cov_rf_fs = e(V)[1,5]

* However sureg doesn't use HC0 by default
* We need HC0 robust standard errors
* Let's do it manually using the sandwich estimator

* Re-run individual regressions to confirm estimates match
* Then compute joint sandwich manually

* Generate design matrix variables
* We need X = [1, right, score_left, score_right] for both equations

* Get HC0 joint covariance manually
* Stack the moment conditions and compute sandwich

* Create weighted variables for manual computation
* X matrix columns: intercept, right, score_left, score_right

gen x0 = 1
gen x1 = right
gen x2 = score_left
gen x3 = score_right

* Get OLS estimates from individual regressions (same as WLS with analytic weights)
* Already have from individual regs above

* Rerun to get residuals
reg earnings x0 x1 x2 x3 [aw=weight], nocons vce(hc0)
scalar rf_est = _b[x1]
scalar rf_se = _se[x1]
predict double resid_y, resid

reg participated x0 x1 x2 x3 [aw=weight], nocons vce(hc0)
scalar fs_est = _b[x1]
scalar fs_se = _se[x1]
predict double resid_d, resid

* For delta method we need Cov(rf_est, fs_est)
* Using HC0 sandwich: Cov = (X'WX)^{-1} * (X'W diag(e_y * e_d) WX) * (X'WX)^{-1}
* We need the [2,2] element of cross term (position of x1 coefficient = index 2, 0-indexed)

* Compute weighted X variables
gen wx0 = weight * x0
gen wx1 = weight * x1
gen wx2 = weight * x2
gen wx3 = weight * x3

* Compute meat cross products: sum of w^2 * xi * xj * resid_y * resid_d
* For HC0: meat_ij = sum_k (w_k * x_ki * resid_yk) * (w_k * x_kj * resid_dk)

* We need the (X'WX)^{-1} matrix
* Let's use matrix operations

mkmat x0 x1 x2 x3 weight resid_y resid_d, matrix(DATA)

mata:
    data = st_matrix("DATA")
    n = rows(data)
    X = data[.,1..4]
    w = data[.,5]
    ey = data[.,6]
    ed = data[.,7]
    
    // WLS: X'WX
    W = diag(w)
    XtWX = X' * W * X
    XtWX_inv = invsym(XtWX)
    
    // Meat for HC0 covariance between rf and fs
    // score vector for rf: w * X * resid_y
    // score vector for fs: w * X * resid_d
    
    score_y = X :* (w :* ey)  // n x 4 matrix
    score_d = X :* (w :* ed)  // n x 4 matrix
    
    // Bread * Meat_cross * Bread
    meat_cross = score_y' * score_d  // 4x4
    
    cov_mat = XtWX_inv * meat_cross * XtWX_inv
    
    // Coefficient for x1 is in position 2 (1-indexed)
    cov_rf_fs = cov_mat[2,2]
    
    st_numscalar("cov_rf_fs", cov_rf_fs)
end

* Treatment effect and delta method SE
scalar te_est = rf_est / fs_est

* delta method: Var(rf/fs) = (1/fs)^2*Var(rf) - 2*(rf/fs^2)*Cov(rf,fs) + (rf^2/fs^4)*Var(fs)
scalar var_rf_hc0 = rf_se^2
scalar var_fs_hc0 = fs_se^2

scalar var_te = (1/fs_est)^2 * var_rf_hc0 - 2*(rf_est/fs_est^2)*cov_rf_fs + (rf_est/fs_est^2)^2 * var_fs_hc0
scalar te_se = sqrt(var_te)

* Display results
display "ANSWER: treatment_effect estimate=" %21.12f te_est " se=" %21.12f te_se " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f rf_est " se=" %21.12f rf_se " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f fs_est " se=" %21.12f fs_se " n_obs=" %12.0f n_obs
