version 17.0
clear all
set more off
set linesize 255

import delimited "./input.csv", clear

// Normalize regional weights (one obs per region)
bysort region_id: gen region_tag = (_n == 1)
su region_weight if region_tag == 1, meanonly
scalar total_weight = r(sum)
gen e_r = region_weight / total_weight

// Construct shift-share instrument z_r = sum_n share_rn * shock_n
bysort region_id: egen z_r = total(share * shock)

// Keep one obs per region for regional-level variables
// but first compute s_n and aggregated shock-level vars

// Compute s_n = sum_r e_r * share_rn (industry exposure mass)
bysort industry_id: egen s_n = total(e_r * share)

// Compute e_r-weighted regional means of y, x, z
su y [aw=e_r] if region_tag==1, meanonly
scalar mean_y = r(mean)
su x [aw=e_r] if region_tag==1, meanonly
scalar mean_x = r(mean)
su z_r [aw=e_r] if region_tag==1, meanonly
scalar mean_z = r(mean)

// Demeaned variables
gen y0 = y - mean_y
gen x0 = x - mean_x
gen z0 = z_r - mean_z

// Aggregate to shock level: vbar_n = sum_r e_r * share_rn * v0_r / s_n
bysort industry_id: egen ybar_n_num = total(e_r * share * y0)
bysort industry_id: egen xbar_n_num = total(e_r * share * x0)
bysort industry_id: egen zbar_n_num = total(e_r * share * z0)

gen ybar_n = ybar_n_num / s_n
gen xbar_n = xbar_n_num / s_n
gen zbar_n = zbar_n_num / s_n

// Keep one observation per industry
bysort industry_id: gen ind_tag = (_n == 1)
keep if ind_tag == 1

// Number of industries
count
scalar N_ind = r(N)

// Shock-level IV regression for effect:
// Regress ybar_n on intercept + xbar_n, instrument = shock, weights = s_n
// Manual 2SLS / IV computation

// Step 1: First stage of shock-level IV for effect regression
// Project xbar_n on (1, shock) weighted by s_n
// Then use fitted values as instrument

// Matrices for IV: endogenous = xbar_n, instrument = shock, dep = ybar_n
// Z matrix (instruments): [1, shock]
// X matrix (regressors): [1, xbar_n]

mata:
    st_view(ybar, ., "ybar_n")
    st_view(xbar, ., "xbar_n")
    st_view(zbar, ., "zbar_n")
    st_view(shk,  ., "shock")
    st_view(sn,   ., "s_n")
    
    N = rows(ybar)
    
    // Weight matrices
    W = diag(sn)
    
    // Instruments matrix: [1, shock]
    Zinst = (J(N,1,1), shk)
    // Regressors matrix: [1, xbar]
    Xreg  = (J(N,1,1), xbar)
    
    // IV estimator: beta = (Z'WX)^{-1} Z'Wy
    ZWX = Zinst' * W * Xreg
    ZWy = Zinst' * W * ybar
    beta_effect = luinv(ZWX) * ZWy
    
    // Structural residuals
    resid_effect = ybar - Xreg * beta_effect
    
    // HC1 variance: N/(N-2) * (Z'WX)^{-1} * (sum_n s_n^2 * z_n * z_n' * resid_n^2) * (Z'WX)^{-1}'
    // Scores = Z_n * s_n * resid_n  (analytic weights: one weight in score)
    scores_effect = Zinst :* (sn :* resid_effect)
    meat_effect = scores_effect' * scores_effect
    bread_effect = luinv(ZWX)
    V_effect = (N/(N-2)) * bread_effect * meat_effect * bread_effect'
    se_effect = sqrt(V_effect[2,2])
    
    // For first_stage: regress xbar_n on intercept + zbar_n, instrument = shock
    // Instruments: [1, shock], Regressors: [1, zbar_n], Dependent: xbar_n
    Xreg2 = (J(N,1,1), zbar)
    ZWX2 = Zinst' * W * Xreg2
    ZWy2 = Zinst' * W * xbar
    beta_fs = luinv(ZWX2) * ZWy2
    
    resid_fs = xbar - Xreg2 * beta_fs
    
    scores_fs = Zinst :* (sn :* resid_fs)
    meat_fs = scores_fs' * scores_fs
    bread_fs = luinv(ZWX2)
    V_fs = (N/(N-2)) * bread_fs * meat_fs * bread_fs'
    se_fs = sqrt(V_fs[2,2])
    
    // Effective shocks = 1 / sum_n s_n^2
    eff_shocks = 1 / sum(sn:^2)
    
    st_numscalar("beta_effect", beta_effect[2])
    st_numscalar("se_effect",   se_effect)
    st_numscalar("beta_fs",     beta_fs[2])
    st_numscalar("se_fs",       se_fs)
    st_numscalar("eff_shocks",  eff_shocks)
end

display "ANSWER: effect estimate=" %21.12f beta_effect " se=" %21.12f se_effect " n_obs=" %12.0f N_ind
display "ANSWER: first_stage estimate=" %21.12f beta_fs " se=" %21.12f se_fs " n_obs=" %12.0f N_ind
display "ANSWER: effective_shocks estimate=" %21.12f eff_shocks " se=" %21.12f . " n_obs=" %12.0f N_ind
