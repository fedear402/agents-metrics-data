set linesize 255
clear all

import delimited "./input.csv", varnames(1) case(lower)

* Step 1: Normalize regional weights (one obs per region)
bysort region_id: gen first_in_region = (_n == 1)
egen total_weight = total(region_weight * first_in_region)
gen e_r = region_weight / total_weight

* Step 2: Construct shift-share instrument z_r = sum_n share_rn * shock_n
bysort region_id: gen z_contrib = share * shock
bysort region_id: egen z_r = total(z_contrib)

* Step 3: Get one observation per region
* (x, y, z, e_r are all constant within region)
preserve
keep if first_in_region

* Step 4: Weighted 2SLS of y on x, instrument z, weight e_r
* First, demean y, x, z by e_r-weighted mean
egen double sum_e = total(e_r)
gen double mean_y = 0
gen double mean_x = 0
gen double mean_z = 0
quietly sum y [aw=e_r]
scalar wmean_y = r(mean)
quietly sum x [aw=e_r]
scalar wmean_x = r(mean)
quietly sum z_r [aw=e_r]
scalar wmean_z = r(mean)

gen double y0 = y - wmean_y
gen double x0 = x - wmean_x
gen double z0 = z_r - wmean_z

save region_data.dta, replace
restore

* Step 5: Shock-level aggregation
* s_n = sum_r e_r * share_rn
bysort industry_id: gen s_n_contrib = e_r * share
bysort industry_id: egen s_n = total(s_n_contrib)

* Merge region-level demeaned residuals back
merge m:1 region_id using region_data.dta, keepusing(y0 x0 z0 e_r) nogen

* Aggregate residuals: vbar_n = sum_r e_r * share_rn * v0_r / s_n
gen ybar_contrib = e_r * share * y0
gen xbar_contrib = e_r * share * x0
gen zbar_contrib = e_r * share * z0

bysort industry_id: egen ybar_num = total(ybar_contrib)
bysort industry_id: egen xbar_num = total(xbar_contrib)
bysort industry_id: egen zbar_num = total(zbar_contrib)

gen ybar_n = ybar_num / s_n
gen xbar_n = xbar_num / s_n
gen zbar_n = zbar_num / s_n

* Keep one obs per industry
bysort industry_id: gen first_in_industry = (_n == 1)
keep if first_in_industry

* Get shock (constant within industry)
* shock is already at industry level here

* Number of industries
count
scalar N_ind = r(N)

* Step 6: Shock-level IV for effect
* Regress ybar_n on xbar_n, instrument with shock, weight by s_n
* 2SLS: slope = Cov_w(shock, ybar_n) / Cov_w(shock, xbar_n)
* where Cov_w is s_n-weighted

quietly sum shock [aw=s_n]
scalar wmean_shock = r(mean)
quietly sum ybar_n [aw=s_n]
scalar wmean_ybar = r(mean)
quietly sum xbar_n [aw=s_n]
scalar wmean_xbar = r(mean)

gen shock_dm = shock - wmean_shock
gen ybar_dm = ybar_n - wmean_ybar
gen xbar_dm = xbar_n - wmean_xbar

* 2SLS slope for effect
gen sw_shock_xbar = s_n * shock_dm * xbar_dm
gen sw_shock_ybar = s_n * shock_dm * ybar_dm
quietly sum sw_shock_xbar
scalar cov_sz_x = r(sum)
quietly sum sw_shock_ybar
scalar cov_sz_y = r(sum)

scalar beta_effect = cov_sz_y / cov_sz_x

* IV residuals for effect: u_n = ybar_n - beta * xbar_n (structural, demeaned)
gen u_effect = ybar_dm - beta_effect * xbar_dm

* HC1 SE for effect
* Var(beta) = (sum s_n * shock_dm * u_n)^2 ... using sandwich
* Score: s_n * shock_dm * u_n
gen score_effect = s_n * shock_dm * u_effect
gen score_effect_sq = score_effect^2

quietly sum score_effect_sq
scalar meat_effect = r(sum)

* Bread: cov_sz_x
* HC1 multiplier: N/(N-2)
scalar hc1_mult = N_ind / (N_ind - 2)
scalar var_beta_effect = hc1_mult * meat_effect / (cov_sz_x^2)
scalar se_effect = sqrt(var_beta_effect)

* Step 7: First stage - regress xbar_n on zbar_n, instrument with shock, weight by s_n
* Here zbar_n is the endogenous regressor, shock is the instrument
quietly sum zbar_n [aw=s_n]
scalar wmean_zbar = r(mean)

gen zbar_dm = zbar_n - wmean_zbar

gen sw_shock_zbar = s_n * shock_dm * zbar_dm
quietly sum sw_shock_zbar
scalar cov_sz_z = r(sum)

scalar beta_fs = cov_sz_x / cov_sz_z

* IV residuals for first stage: xbar_n - beta_fs * zbar_n
gen u_fs = xbar_dm - beta_fs * zbar_dm

gen score_fs = s_n * shock_dm * u_fs
gen score_fs_sq = score_fs^2

quietly sum score_fs_sq
scalar meat_fs = r(sum)

scalar var_beta_fs = hc1_mult * meat_fs / (cov_sz_z^2)
scalar se_fs = sqrt(var_beta_fs)

* Step 8: Effective shocks = 1 / sum_n s_n^2
gen s_n_sq = s_n^2
quietly sum s_n_sq
scalar eff_shocks = 1 / r(sum)

* Report results
display "ANSWER: effect estimate=" %21.12f beta_effect " se=" %21.12f se_effect " n_obs=" %12.0f N_ind
display "ANSWER: first_stage estimate=" %21.12f beta_fs " se=" %21.12f se_fs " n_obs=" %12.0f N_ind
display "ANSWER: effective_shocks estimate=" %21.12f eff_shocks " se=" %21.12f . " n_obs=" %12.0f N_ind
