version 17.0
clear all
set more off
set linesize 255

import delimited "./input.csv", clear varnames(1)

// Normalize regional weights (one obs per region)
bysort region_id: keep if _n == 1
egen total_weight = total(region_weight)
gen e_r = region_weight / total_weight
keep region_id e_r
tempfile weights
save `weights'

import delimited "./input.csv", clear varnames(1)
merge m:1 region_id using `weights', nogen

// Compute regional means (weighted by e_r)
// Since x, y are repeated within region, get one obs per region first
bysort region_id: gen first_obs = (_n == 1)

// Weighted means of y, x, z at regional level
// First compute z_r = sum_n share_rn * shock_n
bysort region_id: egen z_r = total(share * shock)

// Get weighted means using one obs per region
quietly summarize y [aw=e_r] if first_obs == 1
scalar mean_y = r(mean)
quietly summarize x [aw=e_r] if first_obs == 1
scalar mean_x = r(mean)
quietly summarize z_r [aw=e_r] if first_obs == 1
scalar mean_z = r(mean)

// Demeaned variables at region level
gen y0_r = y - mean_y
gen x0_r = x - mean_x
gen z0_r = z_r - mean_z

// Industry-level aggregation: s_n = sum_r e_r * share_rn
// vbar_n = sum_r e_r * share_rn * v0_r / s_n
// Aggregate to industry level
bysort industry_id: egen s_n = total(e_r * share)
gen ey_contrib = e_r * share * y0_r
gen ex_contrib = e_r * share * x0_r
gen ez_contrib = e_r * share * z0_r

bysort industry_id: egen ybar_n_num = total(ey_contrib)
bysort industry_id: egen xbar_n_num = total(ex_contrib)
bysort industry_id: egen zbar_n_num = total(ez_contrib)

gen ybar_n = ybar_n_num / s_n
gen xbar_n = xbar_n_num / s_n
gen zbar_n = zbar_n_num / s_n

// Keep one obs per industry
bysort industry_id: keep if _n == 1

// Number of industries
count
scalar N_ind = r(N)

// shock is constant within industry - already have it
// Rename for clarity
rename shock shock_n

//------------------------------------------------------
// EFFECT: Shock-level IV regression
// Dependent: ybar_n, Endogenous: xbar_n, Instrument: shock_n, Weight: s_n
// HC1 with N/(N-2) multiplier
//------------------------------------------------------

// Weighted IV by hand
// Step 1: Weighted means (intercept included, so demean within weighted framework)
// With intercept, we can use Frisch-Waugh: partial out constant
// i.e., demean by weighted mean

quietly summarize ybar_n [aw=s_n]
scalar my_ybar = r(mean)
quietly summarize xbar_n [aw=s_n]
scalar mx_xbar = r(mean)
quietly summarize zbar_n [aw=s_n]
scalar mz_zbar = r(mean)
quietly summarize shock_n [aw=s_n]
scalar ms_shock = r(mean)

gen ybar_dm = ybar_n - my_ybar
gen xbar_dm = xbar_n - mx_xbar
gen zbar_dm = zbar_n - mz_zbar
gen shock_dm = shock_n - ms_shock

// IV slope: sum(s_n * shock_dm * ybar_dm) / sum(s_n * shock_dm * xbar_dm)
gen swy = s_n * shock_dm * ybar_dm
gen swx = s_n * shock_dm * xbar_dm
gen swx2 = s_n * shock_dm * xbar_dm  // same as swx

quietly summarize swy
scalar num_effect = r(sum)
quietly summarize swx
scalar den_effect = r(sum)

scalar beta_effect = num_effect / den_effect

// Structural residuals: ybar_dm - beta_effect * xbar_dm
gen resid_effect = ybar_dm - beta_effect * xbar_dm

// Scores: instrument * weight * residual (with weight appearing once in score)
// score_n = shock_dm * s_n * resid_effect
// But for the sandwich: scores'*scores where score_n = shock_dm_n * s_n * resid_effect_n
// Denominator of beta: D = sum(s_n * shock_dm * xbar_dm)
// Variance = N/(N-2) * (1/D^2) * sum(score_n^2)
// where score_n = s_n * shock_dm * resid_effect

gen score_effect = s_n * shock_dm * resid_effect
gen score_effect_sq = score_effect^2

quietly summarize score_effect_sq
scalar ss_effect = r(sum)

scalar var_effect = (N_ind / (N_ind - 2)) * ss_effect / (den_effect^2)
scalar se_effect = sqrt(var_effect)

//------------------------------------------------------
// FIRST STAGE: Shock-level IV regression
// Dependent: xbar_n, Endogenous: zbar_n, Instrument: shock_n, Weight: s_n
//------------------------------------------------------

// IV slope: sum(s_n * shock_dm * xbar_dm) / sum(s_n * shock_dm * zbar_dm)
gen swz = s_n * shock_dm * zbar_dm

quietly summarize swz
scalar den_fs = r(sum)
// num_fs = den_effect (sum s_n * shock_dm * xbar_dm)

scalar beta_fs = den_effect / den_fs

// Structural residuals for first stage: xbar_dm - beta_fs * zbar_dm
gen resid_fs = xbar_dm - beta_fs * zbar_dm

gen score_fs = s_n * shock_dm * resid_fs
gen score_fs_sq = score_fs^2

quietly summarize score_fs_sq
scalar ss_fs = r(sum)

scalar var_fs = (N_ind / (N_ind - 2)) * ss_fs / (den_fs^2)
scalar se_fs = sqrt(var_fs)

//------------------------------------------------------
// EFFECTIVE SHOCKS = 1 / sum(s_n^2)
//------------------------------------------------------

gen s_n_sq = s_n^2
quietly summarize s_n_sq
scalar eff_shocks = 1 / r(sum)

//------------------------------------------------------
// REPORT
//------------------------------------------------------

display "ANSWER: effect estimate=" %21.12f beta_effect " se=" %21.12f se_effect " n_obs=" %12.0f N_ind
display "ANSWER: first_stage estimate=" %21.12f beta_fs " se=" %21.12f se_fs " n_obs=" %12.0f N_ind
display "ANSWER: effective_shocks estimate=" %21.12f eff_shocks " se=" %21.12f . " n_obs=" %12.0f N_ind
