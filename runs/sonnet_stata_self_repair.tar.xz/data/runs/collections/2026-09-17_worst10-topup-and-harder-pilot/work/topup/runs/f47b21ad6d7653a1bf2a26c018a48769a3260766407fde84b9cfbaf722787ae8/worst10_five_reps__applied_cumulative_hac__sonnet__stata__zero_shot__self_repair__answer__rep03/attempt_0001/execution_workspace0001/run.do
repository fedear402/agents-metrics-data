set linesize 255
import delimited "./input.csv", clear

sort date

gen log_sales = ln(sales)
gen log_vix = ln(vix)
gen d_log_vix = log_vix - log_vix[_n-1]

forvalues k = 1/15 {
    gen lag_dvix_`k' = d_log_vix[_n-`k']
}

regress log_sales lag_dvix_1 lag_dvix_2 lag_dvix_3 lag_dvix_4 lag_dvix_5 lag_dvix_6 lag_dvix_7 lag_dvix_8 lag_dvix_9 lag_dvix_10 lag_dvix_11 lag_dvix_12 lag_dvix_13 lag_dvix_14 lag_dvix_15

scalar N = e(N)

* Newey-West with max lag 15, manual Bartlett weights, multiplied by N/(N-16)
* We need to compute the NW covariance matrix manually
* Use newey command with lag(15) then scale

newey log_sales lag_dvix_1 lag_dvix_2 lag_dvix_3 lag_dvix_4 lag_dvix_5 lag_dvix_6 lag_dvix_7 lag_dvix_8 lag_dvix_9 lag_dvix_10 lag_dvix_11 lag_dvix_12 lag_dvix_13 lag_dvix_14 lag_dvix_15, lag(15)

scalar N = e(N)

* Get coefficient estimates
matrix b = e(b)
matrix V = e(V)

* Scale V by N/(N-16)
matrix V_scaled = V * (N / (N - 16))

* Extract individual coefficients
scalar b_lag1 = b[1,1]
scalar b_lag15 = b[1,15]

* Cumulative response = sum of lag_1 through lag_15 coefficients
scalar cum_resp = 0
forvalues k = 1/15 {
    scalar cum_resp = cum_resp + b[1,`k']
}

* SE for lag_1
scalar se_lag1 = sqrt(V_scaled[1,1])

* SE for lag_15
scalar se_lag15 = sqrt(V_scaled[15,15])

* SE for cumulative response using full covariance matrix
* Var(sum of coefs) = sum of all elements of sub-matrix [1..15, 1..15]
scalar var_cum = 0
forvalues i = 1/15 {
    forvalues j = 1/15 {
        scalar var_cum = var_cum + V_scaled[`i',`j']
    }
}
scalar se_cum = sqrt(var_cum)

display "ANSWER: cumulative_response estimate=" %21.12f cum_resp " se=" %21.12f se_cum " n_obs=" %12.0f N
display "ANSWER: lag_1 estimate=" %21.12f b_lag1 " se=" %21.12f se_lag1 " n_obs=" %12.0f N
display "ANSWER: lag_15 estimate=" %21.12f b_lag15 " se=" %21.12f se_lag15 " n_obs=" %12.0f N
