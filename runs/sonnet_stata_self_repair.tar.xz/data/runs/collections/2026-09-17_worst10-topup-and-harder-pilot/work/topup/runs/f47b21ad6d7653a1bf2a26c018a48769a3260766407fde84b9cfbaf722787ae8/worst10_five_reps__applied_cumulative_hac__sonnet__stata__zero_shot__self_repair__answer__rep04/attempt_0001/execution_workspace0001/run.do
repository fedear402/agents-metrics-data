set linesize 255
import delimited "./input.csv", clear

sort date

gen log_sales = ln(sales)
gen log_vix = ln(vix)
gen d_log_vix = d.log_vix

forvalues k = 1/15 {
    gen d_log_vix_lag`k' = l`k'.d_log_vix
}

regress log_sales d_log_vix_lag1-d_log_vix_lag15

scalar N = e(N)

* Newey-West with manual Bartlett weights, max lag 15, multiplied by N/(N-16)
* We implement this using newey with lag(15), then scale the VCE

* Get residuals and X matrix
quietly regress log_sales d_log_vix_lag1-d_log_vix_lag15
scalar N_obs = e(N)
predict double resid, residuals

* Use newey command with lag(15)
newey log_sales d_log_vix_lag1-d_log_vix_lag15, lag(15) force

scalar N2 = e(N)

* Newey-West VCE from Stata uses (1/N) normalization; we need to scale by N/(N-16)
* Stata's newey uses small-sample adjustment: VCE = (N/(N-k)) * NW_meat * (X'X)^{-1}
* We want: VCE scaled by N/(N-16) instead
* Stata newey with bw=lag+1 uses Bartlett kernel 1-j/(lag+1) = 1-j/16

* Extract the VCE from newey
matrix V_nw = e(V)

* Stata newey already applies a degrees-of-freedom adjustment: multiplies by N/(N-k)
* where k=16 (intercept + 15 lags). So we need to check if adjustment is already done.
* Stata's newey does NOT apply df adjustment by default - it uses 1/N sandwich.
* So we need to multiply by N/(N-16).

scalar scale = N2 / (N2 - 16)
matrix V_scaled = scale * V_nw

* Get coefficients
matrix b = e(b)

* Coefficient indices: b[1,1]=lag1, ..., b[1,15]=lag15, b[1,16]=_cons
* Sum of lag1 through lag15
scalar cum_resp = 0
forvalues k = 1/15 {
    scalar cum_resp = cum_resp + b[1, `k']
}

* SE for cumulative response using full covariance matrix
* sum of all lag coefficients: c'Vc where c is vector of ones for lags 1-15
matrix c = J(1, 16, 0)
forvalues k = 1/15 {
    matrix c[1, `k'] = 1
}
matrix var_cum = c * V_scaled * c'
scalar se_cum = sqrt(var_cum[1,1])

* SE for lag_1
scalar se_lag1 = sqrt(V_scaled[1,1])

* SE for lag_15
scalar se_lag15 = sqrt(V_scaled[15,15])

* Individual coefficients
scalar b_lag1 = b[1,1]
scalar b_lag15 = b[1,15]

display "ANSWER: cumulative_response estimate=" %21.12f cum_resp " se=" %21.12f se_cum " n_obs=" %12.0f N2
display "ANSWER: lag_1 estimate=" %21.12f b_lag1 " se=" %21.12f se_lag1 " n_obs=" %12.0f N2
display "ANSWER: lag_15 estimate=" %21.12f b_lag15 " se=" %21.12f se_lag15 " n_obs=" %12.0f N2
