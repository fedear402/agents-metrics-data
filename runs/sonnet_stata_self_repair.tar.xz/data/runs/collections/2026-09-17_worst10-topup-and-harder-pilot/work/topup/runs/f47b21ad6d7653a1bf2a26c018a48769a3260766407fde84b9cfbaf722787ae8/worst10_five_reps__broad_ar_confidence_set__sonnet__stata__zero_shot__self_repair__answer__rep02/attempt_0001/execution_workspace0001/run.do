set linesize 255
import delimited "./input.csv", clear

* Number of observations
quietly count
local n = r(N)

* Critical value from F(2, n-4) at 95th percentile
local df1 = 2
local df2 = `n' - 4
local fcrit = invFtail(`df1', `df2', 0.05)

* Anderson-Rubin test: for each beta, regress (y - beta*endog) on intercept, x, z1, z2
* Then test joint significance of z1 and z2 coefficients
* F statistic is function of beta - find the two roots of F(beta) = fcrit

* The F statistic as a function of beta is a ratio of quadratic forms
* F(beta) = [RSS_restricted - RSS_unrestricted] / 2 / [RSS_unrestricted / (n-4)]
* where restricted model excludes z1, z2 (only intercept and x)
* and unrestricted model includes intercept, x, z1, z2

* Let w = y - beta*endog
* Unrestricted: w = a0 + a1*x + a2*z1 + a3*z2 + e  -> RSS_u(beta)
* Restricted:   w = b0 + b1*x + e                   -> RSS_r(beta)
* F(beta) = [(RSS_r - RSS_u)/2] / [RSS_u/(n-4)]

* RSS_u(beta) and RSS_r(beta) are quadratic functions of beta
* So F(beta) = fcrit is a quadratic equation in beta

* Compute projection matrices
* Let Y = y, E = endog, X1 = [1, x, z1, z2] (unrestricted), X2 = [1, x] (restricted)

* Precompute needed quantities using matrix algebra
quietly {
    * Create variables
    gen ones = 1
    
    * Get matrices
    mkmat ones x z1 z2, matrix(X1)
    mkmat ones x, matrix(X2)
    mkmat y, matrix(Y)
    mkmat endog, matrix(E)
    
    local n_val = `n'
    
    * Projection matrices: M1 = I - X1(X1'X1)^-1 X1', M2 = I - X2(X2'X2)^-1 X2'
    * RSS_u(beta) = (Y - beta*E)' M1 (Y - beta*E)
    *             = Y'M1Y - 2*beta*E'M1Y + beta^2 * E'M1E
    * RSS_r(beta) = Y'M2Y - 2*beta*E'M2Y + beta^2 * E'M2E
    
    * Compute M1*Y, M1*E, M2*Y, M2*E
    matrix XtX1 = X1'*X1
    matrix XtX1inv = inv(XtX1)
    matrix P1Y = X1 * XtX1inv * X1' * Y
    matrix P1E = X1 * XtX1inv * X1' * E
    matrix M1Y = Y - P1Y
    matrix M1E = E - P1E
    
    matrix XtX2 = X2'*X2
    matrix XtX2inv = inv(XtX2)
    matrix P2Y = X2 * XtX2inv * X2' * Y
    matrix P2E = X2 * XtX2inv * X2' * E
    matrix M2Y = Y - P2Y
    matrix M2E = E - P2E
    
    * Scalars for quadratic forms
    matrix tmp = Y'*M1Y
    scalar a0 = tmp[1,1]
    matrix tmp = E'*M1Y
    scalar a1 = tmp[1,1]
    matrix tmp = E'*M1E
    scalar a2 = tmp[1,1]
    
    matrix tmp = Y'*M2Y
    scalar b0 = tmp[1,1]
    matrix tmp = E'*M2Y
    scalar b1 = tmp[1,1]
    matrix tmp = E'*M2E
    scalar b2 = tmp[1,1]
    
    * RSS_u(beta) = a0 - 2*a1*beta + a2*beta^2
    * RSS_r(beta) = b0 - 2*b1*beta + b2*beta^2
    * RSS_r - RSS_u = (b0-a0) - 2*(b1-a1)*beta + (b2-a2)*beta^2
    
    scalar c0 = b0 - a0
    scalar c1 = b1 - a1
    scalar c2 = b2 - a2
    
    * F(beta) = [(c0 - 2*c1*beta + c2*beta^2)/2] / [(a0 - 2*a1*beta + a2*beta^2)/(n-4)]
    * F(beta) = fcrit
    * => (c0 - 2*c1*beta + c2*beta^2)/2 = fcrit * (a0 - 2*a1*beta + a2*beta^2)/(n-4)
    * => (n-4)/2 * (c0 - 2*c1*beta + c2*beta^2) = fcrit * (a0 - 2*a1*beta + a2*beta^2)
    * => [(n-4)/2 * c2 - fcrit*a2] * beta^2 
    *    + [-2*(n-4)/2*c1 + 2*fcrit*a1] * beta 
    *    + [(n-4)/2*c0 - fcrit*a0] = 0
    
    local df2_val = `n' - 4
    scalar A_coef = (`df2_val'/2)*c2 - `fcrit'*a2
    scalar B_coef = -(`df2_val')*c1 + 2*`fcrit'*a1
    scalar C_coef = (`df2_val'/2)*c0 - `fcrit'*a0
    
    scalar disc = B_coef^2 - 4*A_coef*C_coef
    
    * F at beta=1
    scalar rss_u_1 = a0 - 2*a1 + a2
    scalar rss_r_1 = b0 - 2*b1 + b2
    scalar ar_f_1 = ((rss_r_1 - rss_u_1)/2) / (rss_u_1/`df2_val')
    
    * Roots
    if disc >= 0 {
        scalar root1 = (-B_coef - sqrt(disc)) / (2*A_coef)
        scalar root2 = (-B_coef + sqrt(disc)) / (2*A_coef)
        
        if root1 < root2 {
            scalar bnd_low = root1
            scalar bnd_high = root2
        }
        else {
            scalar bnd_low = root2
            scalar bnd_high = root1
        }
    }
    
    * Check if zero is in the confidence set: F(0) <= fcrit
    scalar f_at_zero = (c0/2) / (a0/`df2_val')
    scalar zero_in = (f_at_zero <= `fcrit')
    
    * Check if set is unbounded
    * If A_coef < 0, parabola opens downward -> F(beta) >= fcrit between roots -> outside is accepted
    * Actually: F(beta) <= fcrit is the acceptance region
    * F(beta) = [quadratic in beta (numerator)] / [quadratic in beta (denominator)]
    * The denominator a0-2a1*beta+a2*beta^2 = RSS_u(beta) > 0 always (it's a sum of squares)
    * The inequality F <= fcrit becomes:
    *   A_coef*beta^2 + B_coef*beta + C_coef <= 0
    * If A_coef > 0: parabola opens up, so the region between roots is <= 0 -> bounded interval
    * If A_coef < 0: parabola opens down, so region outside roots is <= 0 -> unbounded
    * If A_coef = 0: linear, one root
    
    scalar unbounded_flag = (A_coef < 0)
}

display "ANSWER: boundary_low estimate=" %21.12f bnd_low " se=" %21.12f . " n_obs=" %12.0f `n'
display "ANSWER: boundary_high estimate=" %21.12f bnd_high " se=" %21.12f . " n_obs=" %12.0f `n'
display "ANSWER: accepts_zero estimate=" %21.12f zero_in " se=" %21.12f . " n_obs=" %12.0f `n'
display "ANSWER: unbounded estimate=" %21.12f unbounded_flag " se=" %21.12f . " n_obs=" %12.0f `n'
display "ANSWER: ar_f_at_one estimate=" %21.12f ar_f_1 " se=" %21.12f . " n_obs=" %12.0f `n'
