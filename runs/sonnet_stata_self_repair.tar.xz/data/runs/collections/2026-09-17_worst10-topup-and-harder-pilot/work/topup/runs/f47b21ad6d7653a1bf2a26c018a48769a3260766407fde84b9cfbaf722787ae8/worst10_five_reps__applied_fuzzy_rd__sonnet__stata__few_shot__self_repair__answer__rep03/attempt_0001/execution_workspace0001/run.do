version 16
clear all
set more off
set linesize 255

import delimited "./input.csv", clear

keep if abs(score) < 1

gen w = 1 - abs(score)
gen above = (score >= 0)
gen score_above = score * above
gen score_below = score * (1 - above)

mata:
    st_view(Y=., ., ("earnings","participated"))
    st_view(X=., ., ("w","above","score_below","score_above"))
    w = X[.,1]
    above = X[.,2]
    score_below = X[.,3]
    score_above = X[.,4]
    
    Xmat = (J(rows(Y),1,1), above, score_below, score_above)
    Yw = w :* Xmat
    bread = invsym(Xmat' * Yw)
    
    coef = bread * (Yw' * Y)
    
    resid = Y - Xmat * coef
    
    // contrast for right minus left limit at cutoff (above indicator)
    contrast = (0\1\0\0)
    
    jumps = contrast' * coef
    
    loading = w :* (Xmat * bread * contrast)
    influence = loading :* resid
    
    joint = influence' * influence
    
    gradient = (1/jumps[2] \ -jumps[1]/jumps[2]^2)
    ratio_se = sqrt(gradient' * joint * gradient)
    
    n_obs = rows(Y)
    
    st_numscalar("rf_est", jumps[1])
    st_numscalar("rf_se", sqrt(joint[1,1]))
    st_numscalar("fs_est", jumps[2])
    st_numscalar("fs_se", sqrt(joint[2,2]))
    st_numscalar("te_est", jumps[1]/jumps[2])
    st_numscalar("te_se", ratio_se)
    st_numscalar("n_obs", n_obs)
end

display "ANSWER: treatment_effect estimate=" %21.12f te_est " se=" %21.12f te_se " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f rf_est " se=" %21.12f rf_se " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f fs_est " se=" %21.12f fs_se " n_obs=" %12.0f n_obs
