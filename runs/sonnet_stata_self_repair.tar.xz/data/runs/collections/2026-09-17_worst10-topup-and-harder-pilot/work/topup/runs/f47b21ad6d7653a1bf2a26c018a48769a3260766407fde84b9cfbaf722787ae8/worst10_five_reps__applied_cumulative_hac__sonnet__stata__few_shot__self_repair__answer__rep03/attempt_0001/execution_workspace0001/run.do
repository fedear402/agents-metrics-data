version 17
clear all
set more off
set linesize 255

import delimited "./input.csv", clear varnames(1)

generate double day = date(date, "YMD")
sort day
generate int observation = _n
tsset observation

generate double log_sales = log(sales)
generate double log_vix = log(vix)
generate double dvix = D.log_vix

forvalues k = 1/15 {
    generate double dvix_lag`k' = L`k'.dvix
}

keep if !missing(log_sales, dvix_lag1, dvix_lag2, dvix_lag3, dvix_lag4, dvix_lag5, dvix_lag6, dvix_lag7, dvix_lag8, dvix_lag9, dvix_lag10, dvix_lag11, dvix_lag12, dvix_lag13, dvix_lag14, dvix_lag15)

mata:
    varlist = ("dvix_lag1","dvix_lag2","dvix_lag3","dvix_lag4","dvix_lag5","dvix_lag6","dvix_lag7","dvix_lag8","dvix_lag9","dvix_lag10","dvix_lag11","dvix_lag12","dvix_lag13","dvix_lag14","dvix_lag15")
    X = J(st_nobs(), 1, 1), st_data(., varlist)
    y = st_data(., "log_sales")
    
    b = qrsolve(X, y)
    resid = y - X * b
    
    N = rows(X)
    p = cols(X)
    
    scores = X :* resid
    hac_lags = 15
    meat = scores' * scores
    for (j = 1; j <= hac_lags; j++) {
        w = 1 - j / (hac_lags + 1)
        lp = scores[|j+1,1 \ N,p|]' * scores[|1,1 \ N-j,p|]
        meat = meat + w * (lp + lp')
    }
    bread = invsym(X'X)
    V = (N / (N - p)) * bread * meat * bread
    
    // cumulative_response: sum of lag 1..15 coefficients (indices 2..16)
    contrast = J(p, 1, 0)
    for (k = 2; k <= p; k++) contrast[k] = 1
    
    cumulative = contrast' * b
    cumulative_se = sqrt(contrast' * V * contrast)
    
    lag1_est = b[2]
    lag1_se = sqrt(V[2,2])
    lag15_est = b[16]
    lag15_se = sqrt(V[16,16])
    
    printf("ANSWER: cumulative_response estimate=%21.12f se=%21.12f n_obs=%12.0f\n", cumulative, cumulative_se, N)
    printf("ANSWER: lag_1 estimate=%21.12f se=%21.12f n_obs=%12.0f\n", lag1_est, lag1_se, N)
    printf("ANSWER: lag_15 estimate=%21.12f se=%21.12f n_obs=%12.0f\n", lag15_est, lag15_se, N)
end
