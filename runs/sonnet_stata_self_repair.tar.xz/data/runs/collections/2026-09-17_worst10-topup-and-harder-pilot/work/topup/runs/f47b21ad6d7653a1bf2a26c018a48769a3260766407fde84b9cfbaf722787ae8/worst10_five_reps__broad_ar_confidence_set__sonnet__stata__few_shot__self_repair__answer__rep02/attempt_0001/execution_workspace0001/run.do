clear all
set more off
set linesize 255
set type double

import delimited "./input.csv", clear

quietly regress y
predict double ry, residuals
quietly regress endog
predict double rd, residuals
quietly regress y x z1 z2
predict double uy, residuals
scalar df = e(df_r)
quietly regress endog x z1 z2
predict double ud, residuals

scalar q = 2
scalar n_obs = _N
scalar critical = invFtail(q, df, .05)
scalar k = q * critical / df

mata:
ry = st_data(., "ry")
rd = st_data(., "rd")
uy = st_data(., "uy")
ud = st_data(., "ud")
k = st_numscalar("k")
df = st_numscalar("df")
q = st_numscalar("q")
critical = st_numscalar("critical")

A = quadcross(rd,rd) - (1+k)*quadcross(ud,ud)
B = -2*(quadcross(ry,rd) - (1+k)*quadcross(uy,ud))
C = quadcross(ry,ry) - (1+k)*quadcross(uy,uy)

disc = B^2 - 4*A*C

if (abs(A) > 1e-10 & disc > 0) {
    r1 = (-B - sqrt(disc)) / (2*A)
    r2 = (-B + sqrt(disc)) / (2*A)
    bounds = sort((r1 \ r2), 1)
    st_numscalar("low", bounds[1])
    st_numscalar("high", bounds[2])
    st_numscalar("unbounded", A < 0)
    st_numscalar("accepts_zero", C <= 0)
} else {
    st_numscalar("low", .)
    st_numscalar("high", .)
    st_numscalar("unbounded", .)
    st_numscalar("accepts_zero", .)
}

// F statistic at beta=1
beta1 = 1
ry1 = st_data(., "y") - beta1 * st_data(., "endog")
// partial out x, intercept for restricted
X_full = J(rows(ry1),1,1), st_data(., "x"), st_data(., "z1"), st_data(., "z2")
X_restr = J(rows(ry1),1,1), st_data(., "x")
n = rows(ry1)
p_full = cols(X_full)
p_restr = cols(X_restr)

// SSR unrestricted (with z1,z2)
b_full = invsym(quadcross(X_full,X_full)) * quadcross(X_full, ry1)
res_full = ry1 - X_full * b_full
SSR_U = quadcross(res_full, res_full)

// SSR restricted (without z1,z2)
b_restr = invsym(quadcross(X_restr,X_restr)) * quadcross(X_restr, ry1)
res_restr = ry1 - X_restr * b_restr
SSR_R = quadcross(res_restr, res_restr)

df_num = q
df_den = n - p_full
F_at_one = ((SSR_R - SSR_U) / df_num) / (SSR_U / df_den)
st_numscalar("ar_f_at_one", F_at_one)
end

display "ANSWER: boundary_low estimate=" %21.12f low " se=" %21.12f . " n_obs=" %12.0f n_obs
display "ANSWER: boundary_high estimate=" %21.12f high " se=" %21.12f . " n_obs=" %12.0f n_obs
display "ANSWER: accepts_zero estimate=" %21.12f accepts_zero " se=" %21.12f . " n_obs=" %12.0f n_obs
display "ANSWER: unbounded estimate=" %21.12f unbounded " se=" %21.12f . " n_obs=" %12.0f n_obs
display "ANSWER: ar_f_at_one estimate=" %21.12f ar_f_at_one " se=" %21.12f . " n_obs=" %12.0f n_obs
