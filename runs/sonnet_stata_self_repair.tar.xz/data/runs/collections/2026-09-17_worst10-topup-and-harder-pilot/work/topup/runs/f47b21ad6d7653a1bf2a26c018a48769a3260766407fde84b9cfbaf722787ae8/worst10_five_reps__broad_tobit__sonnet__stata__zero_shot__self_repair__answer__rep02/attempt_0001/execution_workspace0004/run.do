set linesize 255
import delimited "./input.csv", clear

tobit y x z, ll(0)

scalar b_const = _b[_cons]
scalar b_x = _b[x]
scalar b_z = _b[z]

scalar se_const = _se[_cons]
scalar se_x = _se[x]
scalar se_z = _se[z]

scalar n = e(N)

scalar b_sigma = sqrt(_b[var(e.y):_cons])

display "ANSWER: const estimate=" %21.12f b_const " se=" %21.12f se_const " n_obs=" %12.0f n
display "ANSWER: x estimate=" %21.12f b_x " se=" %21.12f se_x " n_obs=" %12.0f n
display "ANSWER: z estimate=" %21.12f b_z " se=" %21.12f se_z " n_obs=" %12.0f n
display "ANSWER: sigma estimate=" %21.12f b_sigma " se=" . " n_obs=" %12.0f n
