version 17.0
clear all
set more off
set linesize 255

import delimited "./input.csv", clear

keep if abs(score) < 1
gen w = 1 - abs(score)
gen above = (score >= 0)
gen score_above = score * above
gen score_below = score * (1 - above)

mata:
    st_view(Y=., ., ("earnings","participated"))
    st_view(X=., ., ("w",))
    above = st_data(., "above")
    score = st_data(., "score")
    w = st_data(., "w")
    n = rows(Y)
    
    // Design matrix: intercept, above indicator, score*below, score*above
    Xmat = J(n,1,1), above, score:*(1:-above), score:*above
    
    // WLS
    Xw = w :* Xmat
    XwX = Xw' * Xmat
    XwY = Xw' * Y
    b = invsym(XwX) * XwY
    
    // Residuals
    resid = Y - Xmat * b
    
    // Contrast for right-minus-left limit at cutoff (intercept jumps)
    // At cutoff: right limit = b[1]+b[2], left limit = b[1]
    // Difference = b[2] = second coefficient
    contrast = (0 \ 1 \ 0 \ 0)
    
    jumps = contrast' * b  // 1x2: [earnings_jump, participated_jump]
    
    // Influence functions for HC0
    bread = invsym(XwX)
    loading = w :* (Xmat * bread * contrast)  // nx1
    influence = loading :* resid  // nx2
    
    // Joint covariance
    joint = influence' * influence  // 2x2
    
    // SE for each discontinuity
    se_rf = sqrt(joint[1,1])
    se_fs = sqrt(joint[2,2])
    
    // Delta method for ratio
    rf = jumps[1,1]
    fs = jumps[1,2]
    te = rf / fs
    
    grad = (1/fs \ -rf/fs^2)
    se_te = sqrt(grad' * joint * grad)
    
    n_obs = n
    
    st_numscalar("te", te)
    st_numscalar("se_te", se_te)
    st_numscalar("rf", rf)
    st_numscalar("se_rf", se_rf)
    st_numscalar("fs", fs)
    st_numscalar("se_fs", se_fs)
    st_numscalar("n_obs", n_obs)
end

display "ANSWER: treatment_effect estimate=" %21.12f te " se=" %21.12f se_te " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f rf " se=" %21.12f se_rf " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f fs " se=" %21.12f se_fs " n_obs=" %12.0f n_obs
