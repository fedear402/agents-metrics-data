set linesize 255
import delimited "./input.csv", clear

gen byte in_bw = (abs(score) < 1)
keep if in_bw

gen double w = 1 - abs(score)
gen byte right = (score >= 0)

gen double score_r = score * right
gen double score_l = score * (1 - right)

scalar n_obs = _N

// WLS via manual transform: multiply all variables by sqrt(w)
gen double sw = sqrt(w)
gen double y_w  = earnings * sw
gen double d_w  = participated * sw
gen double r_w  = right * sw
gen double sr_w = score_r * sw
gen double sl_w = score_l * sw
gen double one_w = sw

// OLS on transformed data (no constant, since intercept is absorbed into one_w)
// Regressors: one_w (left intercept), r_w (right intercept shift), sl_w (left slope), sr_w (right slope)

// Earnings equation (reduced form)
reg y_w one_w r_w sl_w sr_w, nocons vce(hc0)
scalar rf_est = _b[r_w]
scalar rf_se  = _se[r_w]

// Participation equation (first stage)
reg d_w one_w r_w sl_w sr_w, nocons vce(hc0)
scalar fs_est = _b[r_w]
scalar fs_se  = _se[r_w]

// For delta method, need joint covariance of rf and fs estimates of r_w
// Stack both equations and get joint covariance via seemingly unrelated approach
// Use sureg for joint estimation
quietly {
    // Generate untransformed variables for sureg with aweights
    // sureg with aweights and robust
    sureg (earnings right score_r score_l) (participated right score_r score_l) [aw=w], nocons
}
// Wait - sureg doesn't support nocons with this setup properly
// Instead, manually compute covariance from the two separate HC0 sandwich estimators
// The cross-equation covariance: cov(b_rf, b_fs) for the r_w coefficient
// Using: cov = (X'WX)^{-1} * (X'W * e_rf * e_fs * W * X) * (X'WX)^{-1} evaluated at r_w position

// Refit to get residuals
reg y_w one_w r_w sl_w sr_w, nocons
predict double erf, resid

reg d_w one_w r_w sl_w sr_w, nocons
predict double efs, resid

// Now compute cross-equation sandwich for covariance of r_w coefficients
// Need (X'X)^{-1} * (X' * erf*efs) * (X'X)^{-1} for r_w position
// We'll use matrix operations

mkmat one_w r_w sl_w sr_w, matrix(X)
mkmat erf, matrix(Erf)
mkmat efs, matrix(Efs)

matrix XtX = X' * X
matrix XtX_inv = inv(XtX)

// Meat for cross-equation: X' * diag(erf*efs) * X
gen double cross_e = erf * efs
mkmat cross_e, matrix(CE)

// Compute X' diag(cross_e) X
matrix Meat = J(4,4,0)
local nobs = _N
forvalues i = 1/`nobs' {
    matrix xi = X[`i', 1...]'
    scalar cei = CE[`i',1]
    matrix Meat = Meat + cei * xi * xi'
}

matrix COV_cross = XtX_inv * Meat * XtX_inv

// r_w is column 2, so covariance is element (2,2)
scalar cov_rf_fs = COV_cross[2,2]

// Delta method: treatment_effect = rf / fs
// var(te) = (1/fs)^2 * var(rf) + (rf/fs^2)^2 * var(fs) - 2*(rf/fs^3)*cov(rf,fs)
scalar te_est = rf_est / fs_est
scalar te_var = (rf_se^2) / (fs_est^2) + (rf_est^2 * fs_se^2) / (fs_est^4) - 2 * (rf_est / (fs_est^3)) * cov_rf_fs
scalar te_se  = sqrt(te_var)

display "ANSWER: treatment_effect estimate=" %21.12f te_est " se=" %21.12f te_se " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f rf_est " se=" %21.12f rf_se " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f fs_est " se=" %21.12f fs_se " n_obs=" %12.0f n_obs
