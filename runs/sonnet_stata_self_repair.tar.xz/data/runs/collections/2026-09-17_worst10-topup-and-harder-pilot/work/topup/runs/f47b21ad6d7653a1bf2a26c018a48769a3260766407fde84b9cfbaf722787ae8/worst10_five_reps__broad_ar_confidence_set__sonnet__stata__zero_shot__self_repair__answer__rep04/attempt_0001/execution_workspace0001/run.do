set linesize 255
clear all

import delimited "./input.csv", varnames(1)

* Number of observations
local n = _N

* Critical value from F(2, n-4) at 95th percentile
local df1 = 2
local df2 = `n' - 4
local fcrit = invFtail(`df1', `df2', 0.05)

* For the AR confidence set, we need to find the boundary points
* For each beta, regress (y - beta*endog) on intercept, x, z1, z2
* and test joint significance of z1, z2 coefficients

* The F statistic as a function of beta is quadratic in beta
* F(beta) = [RSS_r(beta) - RSS_u(beta)] / 2 / [RSS_u(beta)/(n-4)]
* where RSS_u = residuals from full regression on intercept, x, z1, z2
* and RSS_r = residuals from restricted regression on intercept, x (z1,z2 excluded)

* Let's compute this analytically
* y - beta*endog = a + b*x + c*z1 + d*z2 + e
* The F statistic is quadratic in beta, so we can solve analytically

* Generate variables needed
gen double y_adj = y  // placeholder

* First, get the projection matrices
* Full model: regress on intercept, x, z1, z2
* Restricted model: regress on intercept, x

* Compute key quantities using residuals
* Let W = (y - beta*endog), we need F(beta)

* Partial out x and intercept from all variables
* Residuals after projecting out intercept and x
quietly reg y x
predict double r_y, resid

quietly reg endog x
predict double r_endog, resid

quietly reg z1 x
predict double r_z1, resid

quietly reg z2 x
predict double r_z2, resid

* Now we work in the partial regression space
* w(beta) = r_y - beta * r_endog
* F test of z1, z2 in regression of w(beta) on z1, z2 (already partialed out x, intercept)

* In partial space:
* RSS_restricted(beta) = sum(w_i^2) - [projection of w on nothing after x removed] 
* Actually RSS_restricted = sum((r_y - beta*r_endog)^2) because restricted model only has intercept+x
* RSS_unrestricted = RSS from regressing (r_y - beta*r_endog) on r_z1, r_z2

* Let's define:
* A = r_y - beta*r_endog
* RSS_r = sum(A^2)  [since A is already residual from intercept+x]
* RSS_u = RSS_r - (A'Z(Z'Z)^{-1}Z'A) where Z=[r_z1, r_z2]

* The F statistic:
* F = [(RSS_r - RSS_u)/2] / [RSS_u/(n-4)]

* Need: Z'Z, Z'A, A'A as functions of beta
* A = r_y - beta*r_endog
* A'A = r_y'r_y - 2*beta*(r_y'r_endog) + beta^2*(r_endog'r_endog)
* Z'A = Z'r_y - beta*(Z'r_endog)

* Compute cross products
quietly summarize r_y
local n2 = r(N)

* Cross products
gen double temp = r_y * r_y
quietly summarize temp
local yy = r(sum)

gen double temp2 = r_y * r_endog
quietly summarize temp2
local ye = r(sum)

gen double temp3 = r_endog * r_endog
quietly summarize temp3
local ee = r(sum)

gen double temp4 = r_y * r_z1
quietly summarize temp4
local yz1 = r(sum)

gen double temp5 = r_y * r_z2
quietly summarize temp5
local yz2 = r(sum)

gen double temp6 = r_endog * r_z1
quietly summarize temp6
local ez1 = r(sum)

gen double temp7 = r_endog * r_z2
quietly summarize temp7
local ez2 = r(sum)

gen double temp8 = r_z1 * r_z1
quietly summarize temp8
local z1z1 = r(sum)

gen double temp9 = r_z2 * r_z2
quietly summarize temp9
local z2z2 = r(sum)

gen double temp10 = r_z1 * r_z2
quietly summarize temp10
local z1z2 = r(sum)

drop temp temp2 temp3 temp4 temp5 temp6 temp7 temp8 temp9 temp10

* Z'Z matrix (2x2)
* [z1z1, z1z2]
* [z1z2, z2z2]
local det_ZZ = `z1z1'*`z2z2' - `z1z2'^2

* Z'A = [yz1 - beta*ez1, yz2 - beta*ez2]

* A'Z(Z'Z)^{-1}Z'A = [Z'A]' (Z'Z)^{-1} [Z'A]
* = (1/det) * [yz1-b*ez1, yz2-b*ez2] * [z2z2, -z1z2; -z1z2, z1z1] * [yz1-b*ez1; yz2-b*ez2]
* = (1/det) * {z2z2*(yz1-b*ez1)^2 - 2*z1z2*(yz1-b*ez1)*(yz2-b*ez2) + z1z1*(yz2-b*ez2)^2}

* RSS_r = yy - 2*b*ye + b^2*ee
* RSS_u = RSS_r - A'Z(Z'Z)^{-1}Z'A
* = RSS_r - Q(b)/det_ZZ where Q(b) is the quadratic form above

* F = [Q(b)/det_ZZ / 2] / [RSS_u/(n-4)]
* Accept when F <= fcrit
* F <= fcrit iff Q(b)/(2*det_ZZ) <= fcrit * RSS_u/(n-4)
* iff (n-4)*Q(b) <= 2*fcrit*det_ZZ*RSS_u

* Let's expand Q(b) and RSS_u as functions of b
* Q(b) = z2z2*(yz1 - b*ez1)^2 - 2*z1z2*(yz1-b*ez1)*(yz2-b*ez2) + z1z1*(yz2-b*ez2)^2

* Expand:
* = z2z2*(yz1^2 - 2b*yz1*ez1 + b^2*ez1^2) 
*   - 2*z1z2*(yz1*yz2 - b*yz1*ez2 - b*yz2*ez1 + b^2*ez1*ez2)
*   + z1z1*(yz2^2 - 2b*yz2*ez2 + b^2*ez2^2)

* Coefficients of Q(b) = q0 + q1*b + q2*b^2
local q0 = `z2z2'*`yz1'^2 - 2*`z1z2'*`yz1'*`yz2' + `z1z1'*`yz2'^2
local q1 = `z2z2'*(-2*`yz1'*`ez1') - 2*`z1z2'*(-`yz1'*`ez2' - `yz2'*`ez1') + `z1z1'*(-2*`yz2'*`ez2')
local q2 = `z2z2'*`ez1'^2 - 2*`z1z2'*`ez1'*`ez2' + `z1z1'*`ez2'^2

* RSS_r(b) = yy - 2*b*ye + b^2*ee
* RSS_u(b) = RSS_r(b) - Q(b)/det_ZZ
*           = yy - 2b*ye + b^2*ee - (q0 + q1*b + q2*b^2)/det_ZZ

* F(b) = [Q(b)/det_ZZ/2] / [RSS_u(b)/(n-4)]
* F(b) <= fcrit
* (n-4)*Q(b) <= 2*fcrit*det_ZZ*RSS_u(b)
* (n-4)*Q(b) <= 2*fcrit*det_ZZ*(RSS_r(b) - Q(b)/det_ZZ)
* (n-4)*Q(b) <= 2*fcrit*det_ZZ*RSS_r(b) - 2*fcrit*Q(b)
* (n-4)*Q(b) + 2*fcrit*Q(b) <= 2*fcrit*det_ZZ*RSS_r(b)
* (n-4+2*fcrit)*Q(b) <= 2*fcrit*det_ZZ*RSS_r(b)

* Substituting:
* (n-4+2*fcrit)*(q0+q1*b+q2*b^2) <= 2*fcrit*det_ZZ*(yy - 2b*ye + b^2*ee)

* Rearranging:
* [(n-4+2*fcrit)*q2 - 2*fcrit*det_ZZ*ee]*b^2 
* + [(n-4+2*fcrit)*q1 + 4*fcrit*det_ZZ*ye]*b
* + [(n-4+2*fcrit)*q0 - 2*fcrit*det_ZZ*yy] <= 0

local k = `n' - 4 + 2*`fcrit'
local A_coef = `k'*`q2' - 2*`fcrit'*`det_ZZ'*`ee'
local B_coef = `k'*`q1' + 4*`fcrit'*`det_ZZ'*`ye'
local C_coef = `k'*`q0' - 2*`fcrit'*`det_ZZ'*`yy'

* The confidence set is: A_coef*b^2 + B_coef*b + C_coef <= 0

* Discriminant
local disc = `B_coef'^2 - 4*`A_coef'*`C_coef'

* Compute F at beta=1
local beta1 = 1
local Q1 = `q0' + `q1'*`beta1' + `q2'*`beta1'^2
local RSS_r1 = `yy' - 2*`beta1'*`ye' + `beta1'^2*`ee'
local RSS_u1 = `RSS_r1' - `Q1'/`det_ZZ'
local F1 = (`Q1'/`det_ZZ'/2) / (`RSS_u1'/(`n'-4))

* Determine boundary points and set type
* If A_coef > 0: parabola opens up, set is interval [b1, b2] if disc > 0
* If A_coef < 0: parabola opens down, set is union of (-inf, b1] U [b2, inf) if disc > 0
* If A_coef = 0: linear, etc.

local unbounded = 0
local accepts_zero = 0

if `disc' > 0 {
    local b_low = (-`B_coef' - sqrt(`disc'))/(2*`A_coef')
    local b_high = (-`B_coef' + sqrt(`disc'))/(2*`A_coef')
    
    if `A_coef' > 0 {
        * Confidence set is [b_low, b_high] - bounded interval
        local unbounded = 0
        * Check if 0 is in the set
        if 0 >= `b_low' & 0 <= `b_high' {
            local accepts_zero = 1
        }
        else {
            local accepts_zero = 0
        }
    }
    else if `A_coef' < 0 {
        * Confidence set is (-inf, b_low] U [b_high, inf) - unbounded
        local unbounded = 1
        * 0 is accepted if 0 <= b_low or 0 >= b_high
        if 0 <= `b_low' | 0 >= `b_high' {
            local accepts_zero = 1
        }
        else {
            local accepts_zero = 0
        }
    }
}
else if `disc' == 0 {
    local b_low = -`B_coef'/(2*`A_coef')
    local b_high = `b_low'
    local unbounded = 0
    if 0 == `b_low' {
        local accepts_zero = 1
    }
}
else {
    * No real roots
    if `A_coef' < 0 {
        * Always <= 0, entire real line is confidence set
        local unbounded = 1
        local accepts_zero = 1
        local b_low = .
        local b_high = .
    }
    else {
        * Never <= 0, empty set
        local unbounded = 0
        local accepts_zero = 0
        local b_low = .
        local b_high = .
    }
}

display "ANSWER: boundary_low estimate=" %21.12f `b_low' " se=" %21.12f . " n_obs=" %12.0f `n'
display "ANSWER: boundary_high estimate=" %21.12f `b_high' " se=" %21.12f . " n_obs=" %12.0f `n'
display "ANSWER: accepts_zero estimate=" %21.12f `accepts_zero' " se=" %21.12f . " n_obs=" %12.0f `n'
display "ANSWER: unbounded estimate=" %21.12f `unbounded' " se=" %21.12f . " n_obs=" %12.0f `n'
display "ANSWER: ar_f_at_one estimate=" %21.12f `F1' " se=" %21.12f . " n_obs=" %12.0f `n'
