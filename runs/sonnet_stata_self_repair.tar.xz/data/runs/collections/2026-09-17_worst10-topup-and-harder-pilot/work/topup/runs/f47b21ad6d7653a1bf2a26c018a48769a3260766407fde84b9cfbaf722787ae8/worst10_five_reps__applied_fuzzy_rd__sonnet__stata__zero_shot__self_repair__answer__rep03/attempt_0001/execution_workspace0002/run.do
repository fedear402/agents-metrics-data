set linesize 255
import delimited "./input.csv", clear

gen byte in_bw = (abs(score) < 1)
keep if in_bw

gen double w = 1 - abs(score)
gen byte right = (score >= 0)
gen double score_r = score * right
gen double score_l = score * (1 - right)
gen double sw = sqrt(w)
gen double y_w  = earnings    * sw
gen double d_w  = participated * sw
gen double r_w  = right        * sw
gen double sr_w = score_r      * sw
gen double sl_w = score_l      * sw
gen double one_w = sw

scalar n_obs = _N
local n = _N

// Reduced form (earnings discontinuity)
reg y_w one_w r_w sl_w sr_w, nocons vce(robust)
scalar rf_est = _b[r_w]
// vce(robust) gives HC1; convert to HC0: se_hc0 = se_hc1 * sqrt((N-k)/N), k=4
scalar rf_se  = _se[r_w] * sqrt((`n' - 4.0) / `n')
predict double erf_w, resid

// First stage (participation discontinuity)
reg d_w one_w r_w sl_w sr_w, nocons vce(robust)
scalar fs_est = _b[r_w]
scalar fs_se  = _se[r_w] * sqrt((`n' - 4.0) / `n')
predict double efs_w, resid

// Cross-equation HC0 sandwich for cov(b_rf[r_w], b_fs[r_w])
// Meat = Zstar' * Xstar  where Zstar[i,j] = erf_w_i * efs_w_i * Xstar[i,j]
gen double ce     = erf_w * efs_w
gen double ce_one = ce * one_w
gen double ce_r   = ce * r_w
gen double ce_sl  = ce * sl_w
gen double ce_sr  = ce * sr_w

mkmat one_w r_w sl_w sr_w, matrix(Xstar)
mkmat ce_one ce_r ce_sl ce_sr, matrix(Zstar)

matrix XtX     = Xstar' * Xstar
matrix XtX_inv = inv(XtX)
matrix Meat    = Zstar' * Xstar
matrix COV_cross = XtX_inv * Meat * XtX_inv

scalar cov_rf_fs = COV_cross[2,2]

// Delta method: te = rf/fs
// d(te)/d(rf) = 1/fs,  d(te)/d(fs) = -rf/fs^2
scalar te_est = rf_est / fs_est
scalar te_var = (rf_se^2) / (fs_est^2) ///
              + (rf_est^2 * fs_se^2) / (fs_est^4) ///
              - 2 * (rf_est / (fs_est^3)) * cov_rf_fs
scalar te_se  = sqrt(te_var)

display "ANSWER: treatment_effect estimate=" %21.12f te_est " se=" %21.12f te_se  " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate="     %21.12f rf_est " se=" %21.12f rf_se  " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate="      %21.12f fs_est " se=" %21.12f fs_se  " n_obs=" %12.0f n_obs
