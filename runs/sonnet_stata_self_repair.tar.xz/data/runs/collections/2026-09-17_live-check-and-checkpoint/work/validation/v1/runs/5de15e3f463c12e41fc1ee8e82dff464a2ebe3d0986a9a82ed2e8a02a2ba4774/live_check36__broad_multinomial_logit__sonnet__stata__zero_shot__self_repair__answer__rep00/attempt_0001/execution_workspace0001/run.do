set linesize 255
import delimited "./input.csv", clear

mlogit y x z, base(0)

scalar n = e(N)

// x_cat1: coefficient on x for outcome 1
scalar x_cat1_est = _b[1:x]
scalar x_cat1_se  = _se[1:x]

// z_cat1: coefficient on z for outcome 1
scalar z_cat1_est = _b[1:z]
scalar z_cat1_se  = _se[1:z]

// x_cat2: coefficient on x for outcome 2
scalar x_cat2_est = _b[2:x]
scalar x_cat2_se  = _se[2:x]

// z_cat2: coefficient on z for outcome 2
scalar z_cat2_est = _b[2:z]
scalar z_cat2_se  = _se[2:z]

// prob_cat2_zero: fitted probability of outcome 2 at x=0, z=0
scalar b0_1 = _b[1:_cons]
scalar b0_2 = _b[2:_cons]
scalar denom = 1 + exp(b0_1) + exp(b0_2)
scalar prob_cat2_zero_est = exp(b0_2) / denom

display "ANSWER: x_cat1 estimate=" %21.12f x_cat1_est " se=" %21.12f x_cat1_se " n_obs=" %12.0f n
display "ANSWER: z_cat1 estimate=" %21.12f z_cat1_est " se=" %21.12f z_cat1_se " n_obs=" %12.0f n
display "ANSWER: x_cat2 estimate=" %21.12f x_cat2_est " se=" %21.12f x_cat2_se " n_obs=" %12.0f n
display "ANSWER: z_cat2 estimate=" %21.12f z_cat2_est " se=" %21.12f z_cat2_se " n_obs=" %12.0f n
display "ANSWER: prob_cat2_zero estimate=" %21.12f prob_cat2_zero_est " se=" %21.12f . " n_obs=" %12.0f n
