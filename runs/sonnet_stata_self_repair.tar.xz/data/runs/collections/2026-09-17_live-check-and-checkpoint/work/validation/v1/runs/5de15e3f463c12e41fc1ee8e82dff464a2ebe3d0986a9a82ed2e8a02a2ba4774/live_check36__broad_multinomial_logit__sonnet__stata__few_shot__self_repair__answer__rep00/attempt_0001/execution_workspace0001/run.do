clear all
set more off
set linesize 255
set type double

import delimited "./input.csv", clear

mlogit y x z, baseoutcome(0) tolerance(1e-10) nrtolerance(1e-10)

scalar n = e(N)

scalar x_cat1_est = _b[1:x]
scalar x_cat1_se  = _se[1:x]
scalar z_cat1_est = _b[1:z]
scalar z_cat1_se  = _se[1:z]
scalar x_cat2_est = _b[2:x]
scalar x_cat2_se  = _se[2:x]
scalar z_cat2_est = _b[2:z]
scalar z_cat2_se  = _se[2:z]

scalar prob_cat2_zero = exp(_b[2:_cons]) / (1 + exp(_b[1:_cons]) + exp(_b[2:_cons]))

display "ANSWER: x_cat1 estimate=" %21.12f x_cat1_est " se=" %21.12f x_cat1_se " n_obs=" %12.0f n
display "ANSWER: z_cat1 estimate=" %21.12f z_cat1_est " se=" %21.12f z_cat1_se " n_obs=" %12.0f n
display "ANSWER: x_cat2 estimate=" %21.12f x_cat2_est " se=" %21.12f x_cat2_se " n_obs=" %12.0f n
display "ANSWER: z_cat2 estimate=" %21.12f z_cat2_est " se=" %21.12f z_cat2_se " n_obs=" %12.0f n
display "ANSWER: prob_cat2_zero estimate=" %21.12f prob_cat2_zero " se=" %21.12f . " n_obs=" %12.0f n
