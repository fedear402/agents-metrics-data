version 16
clear all
set more off
set linesize 255

import delimited "./input.csv", clear

keep if abs(score) < 1
gen w = 1 - abs(score)
gen above = (score >= 0)
gen score_above = score * above
gen score_below = score * (1 - above)

mata:
    st_view(Y=., ., ("earnings","participated"))
    st_view(X=., ., ("w","above","score_below","score_above"))
    
    n = rows(Y)
    w = X[.,1]
    
    Xmat = J(n, 4, 0)
    Xmat[.,1] = J(n,1,1)
    Xmat[.,2] = X[.,2]
    Xmat[.,3] = X[.,3]
    Xmat[.,4] = X[.,4]
    
    WXmat = w :* Xmat
    bread = invsym(Xmat' * WXmat)
    
    coef = bread * (WXmat' * Y)
    
    resid = Y - Xmat * coef
    
    // contrast for right minus left limit (jump in intercept = coef on above indicator)
    contrast = (0 \ 1 \ 0 \ 0)
    
    jumps = contrast' * coef
    
    loading = w :* (Xmat * bread * contrast)
    influence = loading :* resid
    
    joint = influence' * influence
    
    rf_est = jumps[1,1]
    fs_est = jumps[1,2]
    
    rf_se = sqrt(joint[1,1])
    fs_se = sqrt(joint[2,2])
    cov12 = joint[1,2]
    
    gradient = (1/fs_est \ -rf_est/fs_est^2)
    te_se = sqrt(gradient' * joint * gradient)
    te_est = rf_est / fs_est
    
    st_numscalar("rf_est", rf_est)
    st_numscalar("fs_est", fs_est)
    st_numscalar("te_est", te_est)
    st_numscalar("rf_se", rf_se)
    st_numscalar("fs_se", fs_se)
    st_numscalar("te_se", te_se)
    st_numscalar("n_obs", n)
end

display "ANSWER: treatment_effect estimate=" %21.12f te_est " se=" %21.12f te_se " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f rf_est " se=" %21.12f rf_se " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f fs_est " se=" %21.12f fs_se " n_obs=" %12.0f n_obs
