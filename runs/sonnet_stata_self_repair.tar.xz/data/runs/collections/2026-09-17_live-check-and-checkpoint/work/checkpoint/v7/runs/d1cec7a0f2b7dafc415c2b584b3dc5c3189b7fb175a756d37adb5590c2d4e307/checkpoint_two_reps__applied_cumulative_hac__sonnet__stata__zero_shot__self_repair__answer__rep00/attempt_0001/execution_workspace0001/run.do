set linesize 255
import delimited "./input.csv", clear

gen log_sales = log(sales)
gen log_vix = log(vix)

sort date

gen d_log_vix = log_vix - log_vix[_n-1]

forvalues k = 1/15 {
    gen d_log_vix_lag`k' = d_log_vix[_n-`k']
}

regress log_sales d_log_vix_lag1-d_log_vix_lag15

scalar N = e(N)

* Newey-West with max lag 15, Bartlett weights, multiplied by N/(N-16)
newey log_sales d_log_vix_lag1-d_log_vix_lag15, lag(15)

scalar N = e(N)

* Get coefficient matrix
matrix b = e(b)
matrix V = e(V)

* Multiply V by N/(N-16)
matrix V = V * (N / (N - 16))

* Cumulative response: sum of 15 lag coefficients
scalar cum_resp = 0
forvalues k = 1/15 {
    scalar cum_resp = cum_resp + _b[d_log_vix_lag`k']
}

* SE for cumulative response using full covariance matrix
* sum of all elements in the 15x15 submatrix (rows/cols 1-15)
scalar var_cum = 0
forvalues i = 1/15 {
    forvalues j = 1/15 {
        scalar var_cum = var_cum + V[`i', `j']
    }
}
scalar se_cum = sqrt(var_cum)

* lag_1 se
scalar se_lag1 = sqrt(V[1,1])

* lag_15 se
scalar se_lag15 = sqrt(V[15,15])

display "ANSWER: cumulative_response estimate=" %21.12f cum_resp " se=" %21.12f se_cum " n_obs=" %12.0f N
display "ANSWER: lag_1 estimate=" %21.12f _b[d_log_vix_lag1] " se=" %21.12f se_lag1 " n_obs=" %12.0f N
display "ANSWER: lag_15 estimate=" %21.12f _b[d_log_vix_lag15] " se=" %21.12f se_lag15 " n_obs=" %12.0f N
