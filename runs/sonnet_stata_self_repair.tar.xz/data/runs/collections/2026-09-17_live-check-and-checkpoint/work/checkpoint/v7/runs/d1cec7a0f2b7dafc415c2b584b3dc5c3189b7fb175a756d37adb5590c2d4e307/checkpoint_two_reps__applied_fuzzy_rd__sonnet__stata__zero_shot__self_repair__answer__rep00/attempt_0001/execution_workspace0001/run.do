set linesize 255
import delimited "./input.csv", clear

keep if abs(score) < 1

gen weight = 1 - abs(score)
gen right = (score >= 0)
gen score_right = score * right
gen score_left = score * (1 - right)

scalar n_obs = _N

* Stack regressions using Zellner's SUR approach via mata for joint covariance

* We need to estimate two WLS regressions with same X matrix:
* Y1 = earnings, Y2 = participated
* X = [1_left, 1_right, score_left, score_right] with triangular weights
* Discontinuity = coef on 1_right minus coef on 1_left = coef on "right" indicator
* 
* Rewrite: let X = [1, right, score_left, score_right]
* Then intercept = left limit, coef on right = discontinuity

gen intercept = 1

* Build design matrix columns: intercept, right, score_left, score_right
* Use mata for WLS and HC0 SEs

mata:
    st_view(Y1=., ., "earnings")
    st_view(Y2=., ., "participated")
    st_view(X=., ., ("intercept","right","score_left","score_right"))
    st_view(w=., ., "weight")
    
    n = rows(X)
    k = cols(X)
    
    // WLS: weight rows
    W = diag(w)
    XtW = X' * W
    XtWX = XtW * X
    XtWXinv = invsym(XtWX)
    
    b1 = XtWXinv * XtW * Y1
    b2 = XtWXinv * XtW * Y2
    
    e1 = Y1 - X * b1
    e2 = Y2 - X * b2
    
    // HC0 robust variance for b1
    // V(b1) = (XtWX)^{-1} * [sum w_i^2 * e1_i^2 * x_i x_i'] * (XtWX)^{-1}
    meat11 = J(k, k, 0)
    meat22 = J(k, k, 0)
    meat12 = J(k, k, 0)
    
    for (i=1; i<=n; i++) {
        xi = X[i,]'
        wi = w[i,1]
        e1i = e1[i,1]
        e2i = e2[i,1]
        meat11 = meat11 + wi^2 * e1i^2 * xi * xi'
        meat22 = meat22 + wi^2 * e2i^2 * xi * xi'
        meat12 = meat12 + wi^2 * e1i * e2i * xi * xi'
    }
    
    V11 = XtWXinv * meat11 * XtWXinv
    V22 = XtWXinv * meat22 * XtWXinv
    V12 = XtWXinv * meat12 * XtWXinv
    
    // Discontinuity estimates: coefficient on "right" (index 2, 0-based = row 2 in 1-based)
    rf_est = b1[2,1]
    fs_est = b2[2,1]
    
    rf_var = V11[2,2]
    fs_var = V22[2,2]
    rf_fs_cov = V12[2,2]
    
    rf_se = sqrt(rf_var)
    fs_se = sqrt(fs_var)
    
    // Delta method for treatment_effect = rf / fs
    te_est = rf_est / fs_est
    te_var = (1/fs_est)^2 * rf_var - 2*(rf_est/fs_est^2)*rf_fs_cov + (rf_est/fs_est^2)^2 * fs_var
    te_se = sqrt(te_var)
    
    st_numscalar("rf_est", rf_est)
    st_numscalar("rf_se", rf_se)
    st_numscalar("fs_est", fs_est)
    st_numscalar("fs_se", fs_se)
    st_numscalar("te_est", te_est)
    st_numscalar("te_se", te_se)
end

display "ANSWER: treatment_effect estimate=" %21.12f te_est " se=" %21.12f te_se " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f rf_est " se=" %21.12f rf_se " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f fs_est " se=" %21.12f fs_se " n_obs=" %12.0f n_obs
