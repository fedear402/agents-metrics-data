set linesize 255
import delimited "./input.csv", clear

tobit y x z, ll(0)

scalar b_const = _b[_cons]
scalar b_x = _b[x]
scalar b_z = _b[z]

scalar se_const = _se[_cons]
scalar se_x = _se[x]
scalar se_z = _se[z]

scalar n = e(N)

* sigma is reported as var(e.y) in Stata 19 tobit; get it from e(Sigma) or via e(b)
* Try auxiliary parameter via e(b) matrix
matrix eb = e(b)
matrix eV = e(V)

* The variance parameter is stored; sigma = sqrt(var)
* Check parameter names
scalar b_var = eb[1, colnumb(eb, "var(e.y):_cons")]
scalar b_sigma = sqrt(b_var)

display "ANSWER: const estimate=" %21.12f b_const " se=" %21.12f se_const " n_obs=" %12.0f n
display "ANSWER: x estimate=" %21.12f b_x " se=" %21.12f se_x " n_obs=" %12.0f n
display "ANSWER: z estimate=" %21.12f b_z " se=" %21.12f se_z " n_obs=" %12.0f n
display "ANSWER: sigma estimate=" %21.12f b_sigma " se=" %21.12f . " n_obs=" %12.0f n
