version 17.0
clear all
set more off
set linesize 255

import delimited "./input.csv", varnames(1) clear

generate double day = date(date, "YMD")
sort day
generate int observation = _n
tsset observation

generate double log_sales = log(sales)
generate double log_vix = log(vix)
generate double dvix = D.log_vix

forvalues k = 1/15 {
    generate double dvix_lag`k' = L`k'.dvix
}

keep if !missing(log_sales, dvix_lag1, dvix_lag2, dvix_lag3, dvix_lag4, dvix_lag5, dvix_lag6, dvix_lag7, dvix_lag8, dvix_lag9, dvix_lag10, dvix_lag11, dvix_lag12, dvix_lag13, dvix_lag14, dvix_lag15)

mata:
    y = st_data(., "log_sales")
    X = J(rows(y), 1, 1)
    for (k = 1; k <= 15; k++) {
        X = X, st_data(., "dvix_lag" + strofreal(k))
    }
    N = rows(X)
    p = cols(X)
    
    b = qrsolve(X, y)
    e = y - X * b
    
    scores = X :* e
    
    hac_lags = 15
    meat = scores' * scores
    for (j = 1; j <= hac_lags; j++) {
        w = 1 - j / (hac_lags + 1)
        Gamma = scores[|j+1,1 \ N,p|]' * scores[|1,1 \ N-j,p|]
        meat = meat + w * (Gamma + Gamma')
    }
    
    bread = invsym(X' * X)
    V = (N / (N - p)) * bread * meat * bread
    
    // cumulative response: sum of lag 1 through lag 15 coefficients (indices 2..16)
    contrast = J(p, 1, 0)
    for (k = 2; k <= 16; k++) {
        contrast[k] = 1
    }
    
    cumulative = contrast' * b
    cumulative_se = sqrt(contrast' * V * contrast)
    
    lag1_est = b[2]
    lag1_se = sqrt(V[2,2])
    
    lag15_est = b[16]
    lag15_se = sqrt(V[16,16])
    
    st_numscalar("cumulative_est", cumulative)
    st_numscalar("cumulative_se", cumulative_se)
    st_numscalar("lag1_est", lag1_est)
    st_numscalar("lag1_se", lag1_se)
    st_numscalar("lag15_est", lag15_est)
    st_numscalar("lag15_se", lag15_se)
    st_numscalar("N_obs", N)
end

display "ANSWER: cumulative_response estimate=" %21.12f cumulative_est " se=" %21.12f cumulative_se " n_obs=" %12.0f N_obs
display "ANSWER: lag_1 estimate=" %21.12f lag1_est " se=" %21.12f lag1_se " n_obs=" %12.0f N_obs
display "ANSWER: lag_15 estimate=" %21.12f lag15_est " se=" %21.12f lag15_se " n_obs=" %12.0f N_obs
