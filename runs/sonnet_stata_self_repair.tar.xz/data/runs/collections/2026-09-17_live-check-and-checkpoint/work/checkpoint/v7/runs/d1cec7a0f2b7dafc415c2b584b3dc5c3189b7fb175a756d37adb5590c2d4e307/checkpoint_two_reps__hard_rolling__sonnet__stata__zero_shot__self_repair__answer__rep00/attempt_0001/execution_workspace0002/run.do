set linesize 255
import delimited "./input.csv", clear
sort time

* Store y values and do all rolling OLS in a single mata block
gen forecast = .

mata:
y = st_data(., "y")
fc_col = st_varindex("forecast")

for (f = 101; f <= 250; f++) {
    reg_s = f - 98
    reg_e = f - 1
    
    dep = y[reg_s..reg_e, 1]
    lag = y[(reg_s-1)..(reg_e-1), 1]
    
    X = J(rows(dep), 1, 1), lag
    b_hat = invsym(X'*X) * X' * dep
    
    a_hat = b_hat[1,1]
    b_hat1 = b_hat[2,1]
    
    y_prev = y[f-1, 1]
    fc = a_hat + b_hat1 * y_prev
    
    st_store(f, fc_col, fc)
}
end

* Compute RMSE
gen sq_err = (y - forecast)^2 if time >= 101 & time <= 250
summarize sq_err if time >= 101 & time <= 250
scalar rmse_val = sqrt(r(sum)/150)

* Extract specific forecasts
summarize forecast if time == 101
scalar fc101 = r(mean)
summarize forecast if time == 150
scalar fc150 = r(mean)
summarize forecast if time == 200
scalar fc200 = r(mean)
summarize forecast if time == 250
scalar fc250 = r(mean)

* Report results
display "ANSWER: rmse estimate=" %21.12f rmse_val " se=" %21.12f . " n_obs=" %12.0f 150
display "ANSWER: forecast_101 estimate=" %21.12f fc101 " se=" %21.12f . " n_obs=" %12.0f 99
display "ANSWER: forecast_150 estimate=" %21.12f fc150 " se=" %21.12f . " n_obs=" %12.0f 99
display "ANSWER: forecast_200 estimate=" %21.12f fc200 " se=" %21.12f . " n_obs=" %12.0f 99
display "ANSWER: forecast_250 estimate=" %21.12f fc250 " se=" %21.12f . " n_obs=" %12.0f 99
