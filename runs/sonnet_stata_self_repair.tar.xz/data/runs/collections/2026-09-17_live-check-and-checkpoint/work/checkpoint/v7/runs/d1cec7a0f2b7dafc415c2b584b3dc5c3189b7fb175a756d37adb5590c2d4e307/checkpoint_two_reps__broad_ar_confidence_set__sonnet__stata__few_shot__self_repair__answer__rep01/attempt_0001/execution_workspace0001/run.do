clear all
set more off
set linesize 255
set type double

import delimited "./input.csv", clear

quietly regress y
predict double ry, residuals
quietly regress endog
predict double rd, residuals
quietly regress y x z1 z2
predict double uy, residuals
scalar df = e(df_r)
quietly regress endog x z1 z2
predict double ud, residuals

scalar q = 2
scalar n_obs = _N
scalar critical = invFtail(q, df, .05)
scalar k = q * critical / df

mata:
ry = st_data(., "ry")
rd = st_data(., "rd")
uy = st_data(., "uy")
ud = st_data(., "ud")
k = st_numscalar("k")
df = st_numscalar("df")
q = st_numscalar("q")

A = quadcross(rd,rd) - (1+k)*quadcross(ud,ud)
B = -2*(quadcross(ry,rd) - (1+k)*quadcross(uy,ud))
C = quadcross(ry,ry) - (1+k)*quadcross(uy,uy)

disc = B^2 - 4*A*C
bounds = sort(((-B - sqrt(disc))/(2*A) \ (-B + sqrt(disc))/(2*A)), 1)
st_numscalar("low", bounds[1])
st_numscalar("high", bounds[2])
st_numscalar("unbounded", A < 0)
st_numscalar("accepts_zero", C <= 0)

// F at beta=1
beta1 = 1
ry1 = ry - beta1*rd
uy1 = uy - beta1*ud
SSR_R1 = quadcross(ry1,ry1)
SSR_U1 = quadcross(uy1,uy1)
F1 = ((SSR_R1 - SSR_U1)/q) / (SSR_U1/df)
st_numscalar("ar_f_at_one", F1)
end

display "ANSWER: boundary_low estimate=" %21.12f (low) " se=" %21.12f (.) " n_obs=" %12.0f (n_obs)
display "ANSWER: boundary_high estimate=" %21.12f (high) " se=" %21.12f (.) " n_obs=" %12.0f (n_obs)
display "ANSWER: accepts_zero estimate=" %21.12f (accepts_zero) " se=" %21.12f (.) " n_obs=" %12.0f (n_obs)
display "ANSWER: unbounded estimate=" %21.12f (unbounded) " se=" %21.12f (.) " n_obs=" %12.0f (n_obs)
display "ANSWER: ar_f_at_one estimate=" %21.12f (ar_f_at_one) " se=" %21.12f (.) " n_obs=" %12.0f (n_obs)
