set linesize 255
import delimited "./input.csv", clear

mlogit y x z, base(0)

scalar n = e(N)

* Extract coefficients and SEs for category 1
scalar x_cat1_est = _b[1:x]
scalar x_cat1_se  = _se[1:x]
scalar z_cat1_est = _b[1:z]
scalar z_cat1_se  = _se[1:z]

* Extract coefficients and SEs for category 2
scalar x_cat2_est = _b[2:x]
scalar x_cat2_se  = _se[2:x]
scalar z_cat2_est = _b[2:z]
scalar z_cat2_se  = _se[2:z]

* Fitted probability of outcome 2 at x=0, z=0
* P(y=2|x=0,z=0) = exp(b20) / (1 + exp(b10) + exp(b20))
scalar b10 = _b[1:_cons]
scalar b20 = _b[2:_cons]
scalar prob_cat2_zero = exp(b20) / (1 + exp(b10) + exp(b20))

display "ANSWER: x_cat1 estimate=" %21.12f x_cat1_est " se=" %21.12f x_cat1_se " n_obs=" %12.0f n
display "ANSWER: z_cat1 estimate=" %21.12f z_cat1_est " se=" %21.12f z_cat1_se " n_obs=" %12.0f n
display "ANSWER: x_cat2 estimate=" %21.12f x_cat2_est " se=" %21.12f x_cat2_se " n_obs=" %12.0f n
display "ANSWER: z_cat2 estimate=" %21.12f z_cat2_est " se=" %21.12f z_cat2_se " n_obs=" %12.0f n
display "ANSWER: prob_cat2_zero estimate=" %21.12f prob_cat2_zero " se=." " n_obs=" %12.0f n
