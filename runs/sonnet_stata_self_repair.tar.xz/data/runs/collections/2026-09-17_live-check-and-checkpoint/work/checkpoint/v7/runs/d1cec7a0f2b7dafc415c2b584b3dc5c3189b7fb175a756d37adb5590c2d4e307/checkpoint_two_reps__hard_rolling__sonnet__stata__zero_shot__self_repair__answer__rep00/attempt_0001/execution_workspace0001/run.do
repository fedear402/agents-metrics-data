set linesize 255
import delimited "./input.csv", clear
sort time

* Store y values in a mata matrix for easy access
mata: y = st_data(., "y")

* Initialize forecast storage
gen forecast = .

local n_fore = 150
local f_start = 101

* Rolling OLS AR(1) forecasts
forvalues f = 101/250 {
    * Window: observations f-100 to f-1 (100 obs)
    * Regression pairs: s = f-99 to f-1 (99 pairs)
    * y_s = a + b*y_(s-1), s = f-99,...,f-1
    
    local win_start = `f' - 100
    local win_end   = `f' - 1
    local reg_start = `f' - 99
    local reg_end   = `f' - 1
    
    * Extract y values for regression
    * dep: y[reg_start..reg_end], indep: y[reg_start-1..reg_end-1]
    mata: {
        f = `f'
        reg_s = `reg_start'
        reg_e = `reg_end'
        
        // dependent variable: y at times reg_start to reg_end
        dep = y[reg_s..reg_e, 1]
        // lagged: y at times reg_start-1 to reg_end-1
        lag = y[(reg_s-1)..(reg_e-1), 1]
        
        // OLS with intercept: [1, lag] * [a; b] = dep
        X = J(rows(dep), 1, 1), lag
        b_hat = invsym(X'*X) * X' * dep
        
        a_hat = b_hat[1,1]
        b_hat1 = b_hat[2,1]
        
        // forecast y_f using y_(f-1)
        y_prev = y[f-1, 1]
        fc = a_hat + b_hat1 * y_prev
        
        st_store(`f', "forecast", fc)
    }
}

* Compute RMSE
gen sq_err = (y - forecast)^2 if time >= 101 & time <= 250
summarize sq_err if time >= 101 & time <= 250
scalar rmse_val = sqrt(r(sum)/150)

* Extract specific forecasts
summarize forecast if time == 101
scalar fc101 = r(mean)
summarize forecast if time == 150
scalar fc150 = r(mean)
summarize forecast if time == 200
scalar fc200 = r(mean)
summarize forecast if time == 250
scalar fc250 = r(mean)

* Report results
display "ANSWER: rmse estimate=" %21.12f rmse_val " se=" %21.12f . " n_obs=" %12.0f 150
display "ANSWER: forecast_101 estimate=" %21.12f fc101 " se=" %21.12f . " n_obs=" %12.0f 99
display "ANSWER: forecast_150 estimate=" %21.12f fc150 " se=" %21.12f . " n_obs=" %12.0f 99
display "ANSWER: forecast_200 estimate=" %21.12f fc200 " se=" %21.12f . " n_obs=" %12.0f 99
display "ANSWER: forecast_250 estimate=" %21.12f fc250 " se=" %21.12f . " n_obs=" %12.0f 99
