clear all
set linesize 255

import delimited "./input.csv"

local n = _N
local ddf = `n' - 4

* Residuals from regressing each variable on [intercept, x]
reg y x
predict double ry, resid

reg endog x
predict double rd, resid

reg y x z1 z2
predict double my, resid

reg endog x z1 z2
predict double md, resid

* For beta candidate, y* = y - beta*endog
* RSS_restricted(beta) = ||ry - beta*rd||^2 = Ar - 2*Brh*beta + Cr*beta^2
* RSS_unrestricted(beta) = ||my - beta*md||^2 = Au - 2*Buh*beta + Cu*beta^2

gen double ry2   = ry^2
gen double ryrd  = ry*rd
gen double rd2   = rd^2
gen double my2   = my^2
gen double mymd  = my*md
gen double md2   = md^2

sum ry2,  meanonly; local Ar  = r(sum)
sum ryrd, meanonly; local Brh = r(sum)
sum rd2,  meanonly; local Cr  = r(sum)
sum my2,  meanonly; local Au  = r(sum)
sum mymd, meanonly; local Buh = r(sum)
sum md2,  meanonly; local Cu  = r(sum)

* Critical value F_{2, n-4, 0.95}
local Fc = invFtail(2, `ddf', 0.05)

* Condition F(beta) <= Fc is equivalent to AA*beta^2 + BB*beta + CC <= 0
* where:
local AA = (`Cr'-`Cu')*`ddf' - 2*`Fc'*`Cu'
local BB = -2*(`Brh'-`Buh')*`ddf' + 4*`Fc'*`Buh'
local CC = (`Ar'-`Au')*`ddf' - 2*`Fc'*`Au'

local disc = `BB'^2 - 4*`AA'*`CC'

local boundary_low  = .
local boundary_high = .
local unbounded     = 0
local accepts_zero  = 0

if `disc' >= 0 & abs(`AA') > 1e-15 {
    local r1 = (-`BB' - sqrt(`disc')) / (2*`AA')
    local r2 = (-`BB' + sqrt(`disc')) / (2*`AA')
    local boundary_low  = min(`r1',`r2')
    local boundary_high = max(`r1',`r2')

    if `AA' > 0 {
        * CS = [boundary_low, boundary_high]  (bounded)
        local unbounded = 0
        if 0 >= `boundary_low' & 0 <= `boundary_high' {
            local accepts_zero = 1
        }
    }
    else {
        * AA < 0: CS = (-inf, boundary_low] union [boundary_high, inf)
        local unbounded = 1
        if 0 <= `boundary_low' | 0 >= `boundary_high' {
            local accepts_zero = 1
        }
    }
}
else if `disc' < 0 {
    * No real roots
    if `AA' < 0 {
        * Always <= 0: CS = all reals
        local unbounded    = 1
        local accepts_zero = 1
    }
    * else AA > 0: always > 0, CS = empty
}

* F statistic at beta = 1
local RSSr1 = `Ar' - 2*`Brh' + `Cr'
local RSSu1 = `Au' - 2*`Buh' + `Cu'
local ar_f_at_one = (`RSSr1' - `RSSu1') * `ddf' / (2 * `RSSu1')

display "ANSWER: boundary_low estimate="  %21.12f `boundary_low'    " se=" %21.12f . " n_obs=" %12.0f `n'
display "ANSWER: boundary_high estimate=" %21.12f `boundary_high'   " se=" %21.12f . " n_obs=" %12.0f `n'
display "ANSWER: accepts_zero estimate="  %21.12f `accepts_zero'    " se=" %21.12f . " n_obs=" %12.0f `n'
display "ANSWER: unbounded estimate="     %21.12f `unbounded'       " se=" %21.12f . " n_obs=" %12.0f `n'
display "ANSWER: ar_f_at_one estimate="   %21.12f `ar_f_at_one'     " se=" %21.12f . " n_obs=" %12.0f `n'
