set more off
set linesize 255
import delimited "./input.csv", clear

quietly count
local n = r(N)
local df2 = `n' - 4

* 95th percentile of F(2, n-4)
local Fc = invF(2, `df2', 0.95)

* Residuals of y and endog on [1, x]
quietly reg y x
predict double ey, resid
quietly reg endog x
predict double ef, resid

* Residuals of y and endog on [1, x, z1, z2]
quietly reg y x z1 z2
predict double gy, resid
quietly reg endog x z1 z2
predict double gf, resid

* Dot products for RSS_0(b) = Ayy - 2b*Ayf + b^2*Aff
quietly {
    gen double tmp = ey^2
    sum tmp, meanonly
    scalar Ayy = r(sum)
    replace tmp = ey*ef
    sum tmp, meanonly
    scalar Ayf = r(sum)
    replace tmp = ef^2
    sum tmp, meanonly
    scalar Aff = r(sum)

    replace tmp = gy^2
    sum tmp, meanonly
    scalar Byy = r(sum)
    replace tmp = gy*gf
    sum tmp, meanonly
    scalar Byf = r(sum)
    replace tmp = gf^2
    sum tmp, meanonly
    scalar Bff = r(sum)
    drop tmp
}

* Q(b) = (n-4)*RSS0(b) - (n-4+2Fc)*RSS1(b) <= 0 defines the confidence set
* Q(b) = c2*b^2 + c1*b + c0
scalar kk = `df2' + 2*`Fc'
scalar c2 = `df2'*Aff - kk*Bff
scalar c1 = -2*(`df2'*Ayf - kk*Byf)
scalar c0 = `df2'*Ayy - kk*Byy

scalar disc = c1^2 - 4*c2*c0

* F at beta=0
scalar F0 = (`df2'/2) * (Ayy - Byy) / Byy

* F at beta=1
scalar RSS0_1 = Ayy - 2*Ayf + Aff
scalar RSS1_1 = Byy - 2*Byf + Bff
scalar F1 = (`df2'/2) * (RSS0_1 - RSS1_1) / RSS1_1

* Determine boundaries and flags
if disc < 0 {
    if c2 < 0 {
        scalar blo = .
        scalar bhi = .
        scalar unbounded = 1
        scalar accepts_zero = 1
    }
    else {
        scalar blo = .
        scalar bhi = .
        scalar unbounded = 0
        scalar accepts_zero = 0
    }
}
else {
    scalar r1 = (-c1 - sqrt(disc)) / (2*c2)
    scalar r2 = (-c1 + sqrt(disc)) / (2*c2)
    scalar blo = min(r1, r2)
    scalar bhi = max(r1, r2)
    if c2 > 0 {
        scalar unbounded = 0
    }
    else {
        scalar unbounded = 1
    }
    scalar accepts_zero = (F0 <= `Fc')
}

display "ANSWER: boundary_low estimate=" %21.12f blo " se=" %21.12f . " n_obs=" %12.0f `n'
display "ANSWER: boundary_high estimate=" %21.12f bhi " se=" %21.12f . " n_obs=" %12.0f `n'
display "ANSWER: accepts_zero estimate=" %21.12f accepts_zero " se=" %21.12f . " n_obs=" %12.0f `n'
display "ANSWER: unbounded estimate=" %21.12f unbounded " se=" %21.12f . " n_obs=" %12.0f `n'
display "ANSWER: ar_f_at_one estimate=" %21.12f F1 " se=" %21.12f . " n_obs=" %12.0f `n'
