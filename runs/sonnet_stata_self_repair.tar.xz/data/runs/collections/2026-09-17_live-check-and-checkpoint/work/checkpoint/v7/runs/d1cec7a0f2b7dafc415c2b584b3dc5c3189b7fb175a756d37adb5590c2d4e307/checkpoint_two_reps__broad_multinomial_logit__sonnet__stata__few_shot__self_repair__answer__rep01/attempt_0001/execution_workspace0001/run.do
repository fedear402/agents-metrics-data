clear all
set more off
set linesize 255
set type double

import delimited "./input.csv", clear

mlogit y x z, baseoutcome(0) tolerance(1e-10) nrtolerance(1e-10)

scalar n = e(N)

scalar x1 = _b[1:x]
scalar x1se = _se[1:x]
scalar z1 = _b[1:z]
scalar z1se = _se[1:z]
scalar x2 = _b[2:x]
scalar x2se = _se[2:x]
scalar z2 = _b[2:z]
scalar z2se = _se[2:z]

scalar cons1 = _b[1:_cons]
scalar cons2 = _b[2:_cons]
scalar prob2 = exp(cons2) / (1 + exp(cons1) + exp(cons2))

display "ANSWER: x_cat1 estimate=" %21.12f x1 " se=" %21.12f x1se " n_obs=" %12.0f n
display "ANSWER: z_cat1 estimate=" %21.12f z1 " se=" %21.12f z1se " n_obs=" %12.0f n
display "ANSWER: x_cat2 estimate=" %21.12f x2 " se=" %21.12f x2se " n_obs=" %12.0f n
display "ANSWER: z_cat2 estimate=" %21.12f z2 " se=" %21.12f z2se " n_obs=" %12.0f n
display "ANSWER: prob_cat2_zero estimate=" %21.12f prob2 " se=" %21.12f . " n_obs=" %12.0f n
