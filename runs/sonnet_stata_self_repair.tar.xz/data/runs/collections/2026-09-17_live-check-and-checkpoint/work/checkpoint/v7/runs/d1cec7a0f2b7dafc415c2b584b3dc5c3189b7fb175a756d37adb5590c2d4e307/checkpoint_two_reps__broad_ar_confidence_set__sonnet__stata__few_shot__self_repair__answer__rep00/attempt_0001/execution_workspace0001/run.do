clear all
set more off
set linesize 255
set type double

import delimited "./input.csv", clear

quietly regress y
predict double ry, residuals
quietly regress endog
predict double rd, residuals
quietly regress y x z1 z2
predict double uy, residuals
scalar df = e(df_r)
quietly regress endog x z1 z2
predict double ud, residuals

scalar q = 2
scalar n_obs = _N
scalar critical = invFtail(q, df, .05)
scalar k = q * critical / df

mata:
ry = st_data(., "ry")
rd = st_data(., "rd")
uy = st_data(., "uy")
ud = st_data(., "ud")
k = st_numscalar("k")

A = quadcross(rd,rd) - (1+k)*quadcross(ud,ud)
B = -2*(quadcross(ry,rd) - (1+k)*quadcross(uy,ud))
C = quadcross(ry,ry) - (1+k)*quadcross(uy,uy)

disc = B^2 - 4*A*C
assert(abs(A) > 1e-10 & disc > 0)

bounds = sort(((-B - sqrt(disc))/(2*A) \ (-B + sqrt(disc))/(2*A)), 1)
st_numscalar("low", bounds[1])
st_numscalar("high", bounds[2])
st_numscalar("unbounded", A < 0)
st_numscalar("accepts_zero", C <= 0)

// F statistic at beta=1
// SSR_R(1) = quadcross(ry-rd, ry-rd) ... but we need partial-out version
// Actually use the quadratic form: F = (A*1 + B + C) / (q/df * SSR_U)
// Wait, SSR_R(beta) = quadcross(ry-beta*rd, ry-beta*rd)
// SSR_U(beta) = quadcross(uy-beta*ud, uy-beta*ud)
// F(beta) = ((SSR_R - SSR_U)/q) / (SSR_U/df)

beta1 = 1
SSR_R1 = quadcross(ry - beta1*rd, ry - beta1*rd)
SSR_U1 = quadcross(uy - beta1*ud, uy - beta1*ud)
q_val = st_numscalar("q")
df_val = st_numscalar("df")
F1 = ((SSR_R1 - SSR_U1)/q_val) / (SSR_U1/df_val)
st_numscalar("ar_f_at_one", F1)
end

display "ANSWER: boundary_low estimate=" %21.12f (low) " se=" %21.12f (.) " n_obs=" %12.0f (n_obs)
display "ANSWER: boundary_high estimate=" %21.12f (high) " se=" %21.12f (.) " n_obs=" %12.0f (n_obs)
display "ANSWER: accepts_zero estimate=" %21.12f (accepts_zero) " se=" %21.12f (.) " n_obs=" %12.0f (n_obs)
display "ANSWER: unbounded estimate=" %21.12f (unbounded) " se=" %21.12f (.) " n_obs=" %12.0f (n_obs)
display "ANSWER: ar_f_at_one estimate=" %21.12f (ar_f_at_one) " se=" %21.12f (.) " n_obs=" %12.0f (n_obs)
