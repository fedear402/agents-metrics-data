version 16
clear all
set more off
set linesize 255

import delimited "./input.csv", clear
sort time
tsset time

generate double lagged_y = L.y
generate double forecast = .

forvalues f = 101/250 {
    local first_response = `f' - 99
    local last_response = `f' - 1
    quietly regress y lagged_y if inrange(time, `first_response', `last_response')
    quietly replace forecast = _b[_cons] + _b[lagged_y] * lagged_y if time == `f'
}

generate double sq_err = (y - forecast)^2 if inrange(time, 101, 250)
quietly summarize sq_err, meanonly
scalar rmse = sqrt(r(mean))

display "ANSWER: rmse estimate=" %21.12f rmse " se=" %21.12f . " n_obs=" %12.0f 150

foreach f in 101 150 200 250 {
    quietly summarize forecast if time == `f', meanonly
    display "ANSWER: forecast_`f' estimate=" %21.12f r(mean) " se=" %21.12f . " n_obs=" %12.0f 99
}
