set linesize 255
import delimited "./input.csv", clear

// Keep observations within bandwidth
gen double absscore = abs(score)
keep if absscore < 1

// Triangular weights
gen double w = 1 - absscore

// Right side indicator
gen byte right = (score >= 0)

// Interaction terms for local linear regression
gen double score_left  = score * (1 - right)
gen double score_right = score * right

// Number of observations
count
scalar n_obs = r(N)

// Stack two outcomes: earnings and participated
// We need joint estimation to get covariance between reduced_form and first_stage
// Use seemingly unrelated regression approach via stacked system

// First, estimate reduced form (earnings) via WLS
// y = a0 + a1*right + a2*score_left + a3*score_right + e
// reduced_form = a1

// Matrix approach for HC0 robust SEs
// X matrix: intercept, right, score_left, score_right

mkmat score, matrix(S)
mkmat right, matrix(R)
mkmat score_left, matrix(SL)
mkmat score_right, matrix(SR)
mkmat w, matrix(W)
mkmat earnings, matrix(Y)
mkmat participated, matrix(P)

quietly {
    // Build X matrix
    gen double x0 = 1
    gen double x1 = right
    gen double x2 = score_left
    gen double x3 = score_right

    mkmat x0 x1 x2 x3, matrix(X)
    
    // Weighted X'X
    mata:
    X = st_matrix("X")
    Y = st_matrix("Y")
    P = st_matrix("P")
    W = st_matrix("W")
    n = rows(X)
    k = cols(X)
    
    // Weight matrix (diagonal)
    Wvec = W[.,1]
    
    // Weighted X'WX
    XtW = X' :* Wvec'
    XtWX = XtW * X
    XtWXinv = invsym(XtWX)
    
    // Weighted X'WY (earnings)
    XtWY = XtW * Y[.,1]
    
    // Weighted X'WP (participated)
    XtWP = XtW * P[.,1]
    
    // Coefficients
    beta_y = XtWXinv * XtWY
    beta_p = XtWXinv * XtWP
    
    // Residuals
    ehat_y = Y[.,1] - X * beta_y
    ehat_p = P[.,1] - X * beta_p
    
    // HC0 sandwich: sum_i w_i^2 * e_i^2 * x_i x_i'
    // Meat for earnings
    We_y = Wvec :* ehat_y
    meat_y = (X :* We_y)' * (X :* We_y)
    
    // Meat for participated
    We_p = Wvec :* ehat_p
    meat_p = (X :* We_p)' * (X :* We_p)
    
    // Cross meat (for delta method covariance)
    meat_yp = (X :* We_y)' * (X :* We_p)
    
    // Variance of beta_y
    V_y = XtWXinv * meat_y * XtWXinv
    
    // Variance of beta_p
    V_p = XtWXinv * meat_p * XtWXinv
    
    // Cross covariance
    V_yp = XtWXinv * meat_yp * XtWXinv
    
    // reduced_form = beta_y[2] (index 2, coefficient on right)
    // first_stage  = beta_p[2]
    
    rf_est = beta_y[2,1]
    fs_est = beta_p[2,1]
    
    rf_var = V_y[2,2]
    fs_var = V_p[2,2]
    rf_fs_cov = V_yp[2,2]
    
    rf_se = sqrt(rf_var)
    fs_se = sqrt(fs_var)
    
    // treatment_effect = rf / fs
    te_est = rf_est / fs_est
    
    // Delta method: Var(rf/fs) = (1/fs)^2 * Var(rf) + (rf/fs^2)^2 * Var(fs) - 2*(rf/fs^3)*Cov(rf,fs)
    te_var = (1/fs_est)^2 * rf_var + (rf_est/fs_est^2)^2 * fs_var - 2*(rf_est/fs_est^3)*rf_fs_cov
    te_se = sqrt(te_var)
    
    st_numscalar("rf_est", rf_est)
    st_numscalar("fs_est", fs_est)
    st_numscalar("te_est", te_est)
    st_numscalar("rf_se", rf_se)
    st_numscalar("fs_se", fs_se)
    st_numscalar("te_se", te_se)
    end
}

display "ANSWER: treatment_effect estimate=" %21.12f te_est " se=" %21.12f te_se " n_obs=" %12.0f n_obs
display "ANSWER: reduced_form estimate=" %21.12f rf_est " se=" %21.12f rf_se " n_obs=" %12.0f n_obs
display "ANSWER: first_stage estimate=" %21.12f fs_est " se=" %21.12f fs_se " n_obs=" %12.0f n_obs
