set linesize 255
import delimited "./input.csv", clear
sort time

* Store y values in a matrix for easy access
mkmat y, matrix(Y)

* Initialize storage for forecasts
local n_forecasts = 150
matrix forecasts = J(150, 2, .)

forvalues f = 101/250 {
    * Window: observations f-100 to f-1 (indices in dataset)
    * Regression pairs: s = f-99 to f-1, using y_s and y_{s-1}
    * That's 99 pairs
    
    local start = `f' - 100
    local end = `f' - 1
    
    * Create temporary variables for regression
    preserve
    keep if time >= `start' & time <= `end'
    
    * Create lagged y
    gen y_lag = y[_n-1] if _n > 1
    * Actually need to be careful - sort is already done
    * y_lag for observation at position n should be y at position n-1 within this window
    sort time
    gen y_lag2 = y[_n-1]
    * First obs in window has no lag from within window, but we need y_{s-1}
    * For s = f-99, y_{s-1} = y_{f-100} which is in our window (start = f-100)
    * So within the kept data (time >= f-100), for time = f-99, lag is time = f-100
    
    drop y_lag
    * Regenerate properly
    sort time
    gen y_lag = y[_n-1]
    
    * Drop first observation (time = f-100) since it has no lag within window
    drop if time == `start'
    
    * Now we have 99 observations with y and y_lag
    reg y y_lag
    
    scalar a_hat = _b[_cons]
    scalar b_hat = _b[y_lag]
    
    restore
    
    * Get y_{f-1}
    scalar y_prev = Y[`end', 1]
    
    * Forecast
    scalar fc = a_hat + b_hat * y_prev
    
    local idx = `f' - 100
    matrix forecasts[`idx', 1] = `f'
    matrix forecasts[`idx', 2] = fc
}

* Now compute RMSE
* Get actual y values for f=101 to 250
scalar sse = 0
forvalues f = 101/250 {
    local idx = `f' - 100
    scalar fc_val = forecasts[`idx', 2]
    scalar actual = Y[`f', 1]
    scalar sse = sse + (actual - fc_val)^2
}
scalar rmse_val = sqrt(sse / 150)

* Extract specific forecasts
scalar fc101 = forecasts[1, 2]
scalar fc150 = forecasts[50, 2]
scalar fc200 = forecasts[100, 2]
scalar fc250 = forecasts[150, 2]

* Report results
display "ANSWER: rmse estimate=" %21.12f rmse_val " se=" %21.12f . " n_obs=" %12.0f 150
display "ANSWER: forecast_101 estimate=" %21.12f fc101 " se=" %21.12f . " n_obs=" %12.0f 99
display "ANSWER: forecast_150 estimate=" %21.12f fc150 " se=" %21.12f . " n_obs=" %12.0f 99
display "ANSWER: forecast_200 estimate=" %21.12f fc200 " se=" %21.12f . " n_obs=" %12.0f 99
display "ANSWER: forecast_250 estimate=" %21.12f fc250 " se=" %21.12f . " n_obs=" %12.0f 99
