clear all
set more off
set linesize 255
set type double

import delimited "./input.csv", clear

ologit y x z, tolerance(1e-10) nrtolerance(1e-10)

scalar n = e(N)
scalar b_x = _b[x]
scalar se_x = _se[x]
scalar b_z = _b[z]
scalar se_z = _se[z]
scalar cut2 = _b[/cut2]
scalar xb_at = 1*b_x + 0*b_z
scalar prob_high = 1 - invlogit(cut2 - xb_at)

display "ANSWER: x estimate=" %21.12f b_x " se=" %21.12f se_x " n_obs=" %12.0f n
display "ANSWER: z estimate=" %21.12f b_z " se=" %21.12f se_z " n_obs=" %12.0f n
display "ANSWER: prob_high estimate=" %21.12f prob_high " se=" %21.12f . " n_obs=" %12.0f n
