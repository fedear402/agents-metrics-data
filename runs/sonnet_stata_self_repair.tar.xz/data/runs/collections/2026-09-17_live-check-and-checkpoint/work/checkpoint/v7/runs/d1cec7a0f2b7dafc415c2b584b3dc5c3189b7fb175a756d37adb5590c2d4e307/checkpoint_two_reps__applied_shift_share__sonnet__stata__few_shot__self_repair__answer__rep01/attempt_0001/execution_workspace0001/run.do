version 17.0
clear all
set more off
set linesize 255

import delimited "./input.csv", clear

// Normalize regional weights (one obs per region)
bysort region_id: gen first_obs = (_n == 1)
quietly sum region_weight if first_obs == 1
local total_weight = r(sum)
gen e_r = region_weight / `total_weight'

// Construct shift-share instrument z_r = sum_n share_rn * shock_n
bysort region_id: gen z_r_contrib = share * shock
bysort region_id: egen z_r = sum(z_r_contrib)

// Keep one obs per region for regional-level variables
// We'll work at region level for means
// Compute e_r-weighted means of y, x, z (one obs per region)
quietly sum y [aw=e_r] if first_obs == 1
local mean_y = r(mean)
quietly sum x [aw=e_r] if first_obs == 1
local mean_x = r(mean)
quietly sum z_r [aw=e_r] if first_obs == 1
local mean_z = r(mean)

// Demeaned residuals
gen y0 = y - `mean_y'
gen x0 = x - `mean_x'
gen z0 = z_r - `mean_z'

// Industry-level aggregation
// s_n = sum_r e_r * share_rn
// vbar_n = sum_r e_r * share_rn * v0_r / s_n

gen e_share = e_r * share

bysort industry_id: egen s_n = sum(e_share)

gen ey_contrib = e_r * share * y0
gen ex_contrib = e_r * share * x0
gen ez_contrib = e_r * share * z0

bysort industry_id: egen sum_ey = sum(ey_contrib)
bysort industry_id: egen sum_ex = sum(ex_contrib)
bysort industry_id: egen sum_ez = sum(ez_contrib)

gen ybar_n = sum_ey / s_n
gen xbar_n = sum_ex / s_n
gen zbar_n = sum_ez / s_n

// Keep one obs per industry
bysort industry_id: gen first_ind = (_n == 1)
keep if first_ind == 1

// Number of industries
count
local N = r(N)

// Shock-level IV regression: ybar_n ~ intercept + xbar_n, instrument=shock, weight=s_n
// Manual IV estimation

// Step 1: Effect estimate (2SLS slope)
// Instruments: (1, shock_n), Regressors: (1, xbar_n), Dependent: ybar_n, weights: s_n

// Matrices for IV
mkmat s_n ybar_n xbar_n zbar_n shock, matrix(M)

mata:
    M = st_matrix("M")
    s_n = M[,1]
    ybar = M[,2]
    xbar = M[,3]
    zbar = M[,4]
    shock_n = M[,5]
    
    N = rows(M)
    
    // ===== Effect: ybar on xbar, instrument=shock =====
    Z = (J(N,1,1), shock_n)
    X = (J(N,1,1), xbar)
    Y = ybar
    w = s_n
    
    ZtWX = Z' * (w :* X)
    ZtWY = Z' * (w :* Y)
    beta_eff = luinv(ZtWX) * ZtWY
    
    resid_eff = Y - X * beta_eff
    
    scores_eff = Z :* (w :* resid_eff)
    meat_eff = scores_eff' * scores_eff
    bread_eff = luinv(ZtWX)
    
    // HC1 multiplier: N/(N-2)
    hc1 = N / (N - 2)
    V_eff = hc1 * bread_eff * meat_eff * bread_eff'
    
    se_eff = sqrt(V_eff[2,2])
    est_eff = beta_eff[2]
    
    // ===== First stage: xbar on zbar, instrument=shock =====
    // Endogenous: zbar_n, instrument: shock_n
    Z2 = (J(N,1,1), shock_n)
    X2 = (J(N,1,1), zbar)
    Y2 = xbar
    
    ZtWX2 = Z2' * (w :* X2)
    ZtWY2 = Z2' * (w :* Y2)
    beta_fs = luinv(ZtWX2) * ZtWY2
    
    resid_fs = Y2 - X2 * beta_fs
    
    scores_fs = Z2 :* (w :* resid_fs)
    meat_fs = scores_fs' * scores_fs
    bread_fs = luinv(ZtWX2)
    
    V_fs = hc1 * bread_fs * meat_fs * bread_fs'
    
    se_fs = sqrt(V_fs[2,2])
    est_fs = beta_fs[2]
    
    // ===== Effective shocks =====
    eff_shocks = 1 / sum(s_n :^ 2)
    
    st_numscalar("est_eff", est_eff)
    st_numscalar("se_eff", se_eff)
    st_numscalar("est_fs", est_fs)
    st_numscalar("se_fs", se_fs)
    st_numscalar("eff_shocks", eff_shocks)
    st_numscalar("N_ind", N)
end

display "ANSWER: effect estimate=" %21.12f est_eff " se=" %21.12f se_eff " n_obs=" %12.0f N_ind
display "ANSWER: first_stage estimate=" %21.12f est_fs " se=" %21.12f se_fs " n_obs=" %12.0f N_ind
display "ANSWER: effective_shocks estimate=" %21.12f eff_shocks " se=" %21.12f . " n_obs=" %12.0f N_ind
