version 16
clear all
set more off
set linesize 255

import delimited "./input.csv", clear

keep if abs(score) < 1
gen w = 1 - abs(score)
gen above = (score >= 0)
gen score_above = score * above
gen score_below = score * (1 - above)

mata:
    st_view(Y=., ., ("earnings", "participated"))
    st_view(X=., ., ("w",))
    
    above = st_data(., "above")
    score = st_data(., "score")
    score_above = st_data(., "score_above")
    score_below = st_data(., "score_below")
    w = st_data(., "w")
    
    n = rows(Y)
    
    // Design matrix: intercept, score_below, above, score_above
    Xmat = (J(n,1,1), score_below, above, score_above)
    
    // Weighted WLS
    Xw = w :* Xmat
    bread = invsym(Xmat' * Xw)
    coef = bread * (Xw' * Y)
    
    resid = Y - Xmat * coef
    
    // Contrast for discontinuity: coefficient on "above"
    contrast = (0 \ 0 \ 1 \ 0)
    
    jumps = contrast' * coef
    
    // HC0 sandwich
    loading = w :* (Xmat * bread * contrast)
    influence = loading :* resid
    
    joint = influence' * influence
    
    // Delta method for ratio
    rf = jumps[1]
    fs = jumps[2]
    gradient = (1/fs \ -rf/fs^2)
    ratio_se = sqrt(gradient' * joint * gradient)
    
    printf("ANSWER: reduced_form estimate=%21.15g se=%21.15g n_obs=%g\n", rf, sqrt(joint[1,1]), n)
    printf("ANSWER: first_stage estimate=%21.15g se=%21.15g n_obs=%g\n", fs, sqrt(joint[2,2]), n)
    printf("ANSWER: treatment_effect estimate=%21.15g se=%21.15g n_obs=%g\n", rf/fs, ratio_se, n)
end
