set linesize 255
clear all

import delimited "./input.csv", varnames(1)

* Step 1: Normalize regional weights (one obs per region)
bysort region_id: gen first_in_region = (_n == 1)
egen total_weight = total(region_weight * first_in_region)
gen e_r = region_weight / total_weight

* Step 2: Construct shift-share instrument z_r = sum_n share_rn * shock_n
bysort region_id: gen z_contrib = share * shock
bysort region_id: egen z_r = total(z_contrib)

* Step 3: Compute exposure-weighted means for demeaning
* e_r-weighted mean of y, x, z (using one obs per region)
egen sum_e = total(e_r * first_in_region)
egen mean_y = total(e_r * y * first_in_region)
egen mean_x = total(e_r * x * first_in_region)
egen mean_z = total(e_r * z_r * first_in_region)
replace mean_y = mean_y / sum_e
replace mean_x = mean_x / sum_e
replace mean_z = mean_z / sum_e

gen y0_r = y - mean_y
gen x0_r = x - mean_x
gen z0_r = z_r - mean_z

* Step 4: Construct industry-level aggregates
* s_n = sum_r e_r * share_rn
bysort industry_id: gen s_n_contrib = e_r * share
bysort industry_id: egen s_n = total(s_n_contrib)

* ybar_n = sum_r e_r * share_rn * y0_r / s_n
bysort industry_id: gen ybar_contrib = e_r * share * y0_r
bysort industry_id: gen xbar_contrib = e_r * share * x0_r
bysort industry_id: gen zbar_contrib = e_r * share * z0_r

bysort industry_id: egen ybar_n_num = total(ybar_contrib)
bysort industry_id: egen xbar_n_num = total(xbar_contrib)
bysort industry_id: egen zbar_n_num = total(zbar_contrib)

gen ybar_n = ybar_n_num / s_n
gen xbar_n = xbar_n_num / s_n
gen zbar_n = zbar_n_num / s_n

* Keep one obs per industry
bysort industry_id: gen first_in_industry = (_n == 1)
keep if first_in_industry

* shock is constant within industry
count
local N_industries = r(N)

* Step 5: Shock-level IV regression for EFFECT
* Regress ybar_n on intercept and xbar_n, instrument xbar_n with shock, weight by s_n
* 2SLS: first stage xbar_n on shock (weighted), then use fitted values

* Manual 2SLS for effect
* First stage: xbar_n = a + b*shock_n, weighted by s_n
reg xbar_n shock [aw=s_n]
scalar fs_effect_a = _b[_cons]
scalar fs_effect_b = _b[shock]
gen xhat_n = fs_effect_a + fs_effect_b * shock

* Second stage: ybar_n on xhat_n (weighted by s_n)
reg ybar_n xhat_n [aw=s_n]
scalar effect_slope = _b[xhat_n]

* Structural IV residuals: e_n = ybar_n - effect_slope * xbar_n - intercept
* Need intercept from IV
* IV intercept: mean(ybar_n) - effect_slope * mean(xbar_n) [weighted]
summarize ybar_n [aw=s_n]
scalar wmean_ybar = r(mean)
summarize xbar_n [aw=s_n]
scalar wmean_xbar = r(mean)
scalar effect_intercept = wmean_ybar - effect_slope * wmean_xbar

gen iv_resid_effect = ybar_n - effect_intercept - effect_slope * xbar_n

* HC1 SE for effect: variance of slope from shock-level IV
* Var(beta_IV) = [sum s_n * shock_n * xbar_n]^{-2} * sum s_n^2 * shock_n^2 * iv_resid_effect^2 * (N/(N-2))
* But with analytic weights (s_n), we need:
* beta_IV = [sum s_n * zbar_shock_n * xbar_n]^{-1} * sum s_n * shock_n * ybar_n
* where instrument is shock_n (demeaned or not - shock_n is the instrument directly)

* For HC1 robust SE in IV with instrument z=shock, endogenous=xbar, outcome=ybar, weights=s_n:
* The moment condition is: sum_n s_n * shock_n * (ybar_n - alpha - beta*xbar_n) = 0
* And: sum_n s_n * (ybar_n - alpha - beta*xbar_n) = 0
* 
* In matrix form with X=[1, xbar], Z=[1, shock], W=diag(s_n):
* beta_IV = (Z'WX)^{-1} Z'Wy
* Sandwich: V = (Z'WX)^{-1} * (Z'W * diag(e^2) * WZ) * (X'WZ)^{-1} * N/(N-2)

* Let me compute this manually
* Weighted means for demeaning in shock-level regression
summarize shock [aw=s_n]
scalar mean_shock_w = r(mean)

* Demeaned variables for the shock-level regression
gen shock_dm = shock - mean_shock_w
gen xbar_dm = xbar_n - wmean_xbar
gen ybar_dm = ybar_n - wmean_ybar

* Sum for IV slope (demeaned version): sum s_n * shock_dm * xbar_dm / sum s_n * shock_dm^2
* Wait, the IV slope with instrument shock on xbar (both demeaned) is:
* sum s_n * shock_dm * ybar_dm / sum s_n * shock_dm * xbar_dm

gen s_shockdm_xbardm = s_n * shock_dm * xbar_dm
gen s_shockdm_ybardm = s_n * shock_dm * ybar_dm
gen s_shockdm2 = s_n * shock_dm^2

summarize s_shockdm_xbardm
scalar denom_iv = r(sum) * r(N)  // total (aw gives mean)
* Actually with [aw], summarize gives sum/N * N_eff... let me just sum directly

egen sum_s_shockdm_xbardm = total(s_n * shock_dm * xbar_dm)
egen sum_s_shockdm_ybardm = total(s_n * shock_dm * ybar_dm)
egen sum_s_shockdm2 = total(s_n * shock_dm^2)

scalar iv_slope_check = sum_s_shockdm_ybardm / sum_s_shockdm_xbardm
* This should equal effect_slope

* HC1 SE for effect slope:
* Score for each obs: s_n * shock_dm * iv_resid_effect
gen score_effect = s_n * shock_dm * iv_resid_effect
egen sum_score2_effect = total(score_effect^2)

* Var = (1/sum_s_shockdm_xbardm)^2 * sum_score2_effect * N/(N-2)
local N = `N_industries'
scalar var_effect = (1/sum_s_shockdm_xbardm)^2 * sum_score2_effect * `N' / (`N' - 2)
scalar se_effect = sqrt(var_effect)

* Step 6: First-stage slope
* Regress xbar_n on intercept and zbar_n, instrument zbar_n with shock_n, weight by s_n
* This is IV: outcome=xbar, endogenous=zbar, instrument=shock

summarize zbar_n [aw=s_n]
scalar wmean_zbar = r(mean)
gen zbar_dm = zbar_n - wmean_zbar

* IV slope: sum s_n * shock_dm * xbar_dm / sum s_n * shock_dm * zbar_dm
egen sum_s_shockdm_zbardm = total(s_n * shock_dm * zbar_dm)

scalar fs_slope = sum_s_shockdm_xbardm / sum_s_shockdm_zbardm

* Intercept for first stage IV
scalar fs_intercept = wmean_xbar - fs_slope * wmean_zbar

* Structural residuals for first stage
gen iv_resid_fs = xbar_n - fs_intercept - fs_slope * zbar_n

* HC1 SE for first stage
gen score_fs = s_n * shock_dm * iv_resid_fs
egen sum_score2_fs = total(score_fs^2)

scalar var_fs = (1/sum_s_shockdm_zbardm)^2 * sum_score2_fs * `N' / (`N' - 2)
scalar se_fs = sqrt(var_fs)

* Step 7: Effective shocks
egen sum_sn2 = total(s_n^2)
scalar eff_shocks = 1 / sum_sn2

* Report results
display "ANSWER: effect estimate=" %21.12f effect_slope " se=" %21.12f se_effect " n_obs=" %12.0f `N'
display "ANSWER: first_stage estimate=" %21.12f fs_slope " se=" %21.12f se_fs " n_obs=" %12.0f `N'
display "ANSWER: effective_shocks estimate=" %21.12f eff_shocks " se=" %21.12f . " n_obs=" %12.0f `N'
