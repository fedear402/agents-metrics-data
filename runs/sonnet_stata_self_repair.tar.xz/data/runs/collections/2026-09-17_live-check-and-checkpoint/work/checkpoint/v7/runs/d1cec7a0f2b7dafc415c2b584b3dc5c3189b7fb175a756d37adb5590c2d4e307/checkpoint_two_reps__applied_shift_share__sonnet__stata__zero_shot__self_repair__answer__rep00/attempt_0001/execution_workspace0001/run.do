set linesize 255
clear all

import delimited "./input.csv", varnames(1)

* Step 1: Get one obs per region for weights, x, y
bysort region_id: keep if _n == 1
* Actually need all obs, so do this properly

clear
import delimited "./input.csv", varnames(1)

* Normalize regional weights using one obs per region
bysort region_id (industry_id): gen first_in_region = (_n == 1)
quietly summ region_weight if first_in_region == 1
* sum of all region weights
egen total_weight = total(region_weight * first_in_region)
gen e_r = region_weight / total_weight

* Construct shift-share instrument z_r = sum_n share_rn * shock_n
bysort region_id: gen z_contrib = share * shock
bysort region_id: egen z_r = total(z_contrib)

* Get region-level dataset (one obs per region)
* Keep x, y, z_r, e_r at region level
bysort region_id (industry_id): gen region_obs = (_n == 1)

* Compute weighted means for demeaning
* We need e_r-weighted means of y, x, z
quietly {
    * sum e_r should = 1 (already normalized)
    * weighted mean of y: sum(e_r * y) / sum(e_r) but e_r sum to 1 for regions
    * Use only one obs per region
    gen e_r_reg = e_r * region_obs
    
    egen sum_er = total(e_r_reg)
    egen mean_y = total(e_r_reg * y)
    egen mean_x = total(e_r_reg * x)
    egen mean_z = total(e_r_reg * z_r)
    
    replace mean_y = mean_y / sum_er
    replace mean_x = mean_x / sum_er
    replace mean_z = mean_z / sum_er
    
    gen y0_r = y - mean_y
    gen x0_r = x - mean_x
    gen z0_r = z_r - mean_z
}

* Step 2: Construct industry-level aggregates
* s_n = sum_r e_r * share_rn
* vbar_n = sum_r e_r * share_rn * v0_r / s_n

bysort industry_id: gen s_n = .
bysort industry_id: gen ybar_n = .
bysort industry_id: gen xbar_n = .
bysort industry_id: gen zbar_n = .

* For each industry, aggregate over regions
* s_n = sum_r e_r * share_rn
bysort industry_id: egen s_n2 = total(e_r * share)

* Weighted aggregates (numerator)
bysort industry_id: egen num_y = total(e_r * share * y0_r)
bysort industry_id: egen num_x = total(e_r * share * x0_r)
bysort industry_id: egen num_z = total(e_r * share * z0_r)

replace s_n = s_n2
replace ybar_n = num_y / s_n
replace xbar_n = num_x / s_n
replace zbar_n = num_z / s_n

* Get shock at industry level (constant within industry)
bysort industry_id (region_id): gen industry_obs = (_n == 1)

* Keep industry-level dataset
preserve
keep if industry_obs == 1
keep industry_id shock s_n ybar_n xbar_n zbar_n

* Number of industries
count
local N = r(N)

* Step 3: Shock-level IV for effect (2SLS slope)
* Regress ybar_n on intercept + xbar_n, instrument xbar_n with shock_n, weight by s_n
* HC1 variance multiplier: N/(N-2)

* Manual 2SLS at shock level
* First stage: xbar_n on intercept + shock_n, weighted by s_n
* Then use fitted values

* Weighted means
egen sw = total(s_n)
egen s_shock_mean = total(s_n * shock / sw)  // not needed directly

* Use ivregress for 2SLS
ivregress 2sls ybar_n (xbar_n = shock) [aw=s_n], robust

* Extract slope
scalar beta_effect = _b[xbar_n]

* Now compute HC1 SE manually from structural residuals
* Get 2SLS fitted values and residuals
* beta = _b[xbar_n], alpha = _b[_cons]
scalar alpha_effect = _b[_cons]

* First stage fitted values
reg xbar_n shock [aw=s_n]
predict xhat_n, xb

* Structural residuals: u_n = ybar_n - alpha - beta * xbar_n
gen u_n = ybar_n - alpha_effect - beta_effect * xbar_n

* For HC1 2SLS variance: V = (X'Z(Z'Z)^-1 Z'X)^-1 * (sum s_n * z_n_tilde * u_n^2) * (X'Z(Z'Z)^-1 Z'X)^-1 * N/(N-2)
* With instrument = shock, regressor = xbar_n
* Demeaned (weighted) versions

* Weighted demeaning of shock and xhat
gen s_w = s_n / sw  // normalized weights sum to 1 over sw... actually sw = sum(s_n)

* For weighted regression, need weighted demeaning
quietly summ shock [aw=s_n]
scalar mean_shock = r(mean)
quietly summ xhat_n [aw=s_n]  
scalar mean_xhat = r(mean)

gen shock_dm = shock - mean_shock
gen xhat_dm = xhat_n - mean_xhat

* X'Z(Z'Z)^-1 Z'X = (sum s_n * xhat_dm * shock_dm)^2 / (sum s_n * shock_dm^2)
* But since instrument=shock and first stage uses shock, xhat_dm is projection of xbar on shock
* Simpler: the 2SLS sandwich variance

* score = s_n * shock_dm * u_n (the meat contribution)
gen score_n = s_n * shock_dm * u_n

* Meat = (sum score_n)^2 = (sum s_n * shock_dm * u_n)^2
quietly summ score_n
scalar meat_sum = r(sum)  // = sum_n s_n * shock_dm * u_n

* For HC1, each obs contributes score_n^2 to the meat (heteroskedastic)
gen score_n_sq = score_n^2
quietly summ score_n_sq
scalar meat_hc = r(sum)  // sum of squared scores

* Bread = sum s_n * xhat_dm * shock_dm (= sum s_n * xhat_dm^2 since xhat is linear in shock)
* Actually bread = sum s_n * shock_dm * xhat_dm
gen bread_contrib = s_n * shock_dm * xhat_dm
quietly summ bread_contrib
scalar bread_val = r(sum)

* Variance of beta: HC1 = N/(N-2) * meat_hc / bread_val^2
scalar var_effect = (`N' / (`N' - 2)) * meat_hc / (bread_val^2)
scalar se_effect = sqrt(var_effect)

* Step 4: First stage - regional x_r on intercept + z_r, weighted by e_r
* Shock-level equivalent: xbar_n on intercept + zbar_n, instrument zbar_n with shock_n, weight s_n

ivregress 2sls xbar_n (zbar_n = shock) [aw=s_n], robust
scalar beta_fs = _b[zbar_n]
scalar alpha_fs = _b[_cons]

* First stage of this IV: zbar_n on shock
reg zbar_n shock [aw=s_n]
predict zhat_n, xb

* Structural residuals for first stage IV
gen u_fs_n = xbar_n - alpha_fs - beta_fs * zbar_n

* Weighted demeaning
quietly summ zhat_n [aw=s_n]
scalar mean_zhat = r(mean)
gen zhat_dm = zhat_n - mean_zhat

* HC1 SE for first stage
gen score_fs_n = s_n * shock_dm * u_fs_n
gen score_fs_sq = score_fs_n^2

quietly summ score_fs_sq
scalar meat_fs = r(sum)

gen bread_fs_contrib = s_n * shock_dm * zhat_dm
quietly summ bread_fs_contrib
scalar bread_fs = r(sum)

scalar var_fs = (`N' / (`N' - 2)) * meat_fs / (bread_fs^2)
scalar se_fs = sqrt(var_fs)

* Step 5: Effective shocks = 1 / sum_n s_n^2
gen s_n_sq = s_n^2
quietly summ s_n_sq
scalar eff_shocks = 1 / r(sum)

* Report results
display "ANSWER: effect estimate=" %21.12f beta_effect " se=" %21.12f se_effect " n_obs=" %12.0f `N'
display "ANSWER: first_stage estimate=" %21.12f beta_fs " se=" %21.12f se_fs " n_obs=" %12.0f `N'
display "ANSWER: effective_shocks estimate=" %21.12f eff_shocks " se=" %21.12f . " n_obs=" %12.0f `N'

restore
