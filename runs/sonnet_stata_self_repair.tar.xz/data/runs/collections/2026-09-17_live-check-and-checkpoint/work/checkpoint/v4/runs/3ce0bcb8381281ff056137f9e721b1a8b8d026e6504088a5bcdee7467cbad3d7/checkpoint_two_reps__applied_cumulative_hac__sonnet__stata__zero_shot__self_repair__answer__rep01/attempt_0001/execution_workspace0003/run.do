set linesize 255
import delimited "./input.csv", clear

gen log_sales = ln(sales)
gen log_vix = ln(vix)
sort date
gen d_log_vix = log_vix - log_vix[_n-1]

forvalues j = 1/15 {
    gen lag`j'_d_log_vix = d_log_vix[_n-`j']
}

* Need tsset for newey - use observation number as time variable
gen t = _n
tsset t

newey log_sales lag1_d_log_vix lag2_d_log_vix lag3_d_log_vix lag4_d_log_vix lag5_d_log_vix lag6_d_log_vix lag7_d_log_vix lag8_d_log_vix lag9_d_log_vix lag10_d_log_vix lag11_d_log_vix lag12_d_log_vix lag13_d_log_vix lag14_d_log_vix lag15_d_log_vix, lag(15)

scalar N = e(N)

* Extract coefficients and variance matrix
matrix b = e(b)
matrix V = e(V)

* Scale V by N/(N-16)
matrix V_scaled = V * (N / (N - 16))

* Coefficient indices: lag1..lag15 are columns 1..15, _cons is 16
scalar b_lag1 = b[1,1]
scalar b_lag15 = b[1,15]

* Cumulative response = sum of lag1 through lag15
scalar cum_resp = 0
forvalues j = 1/15 {
    scalar cum_resp = cum_resp + b[1,`j']
}

* SE for individual lags
scalar se_lag1 = sqrt(V_scaled[1,1])
scalar se_lag15 = sqrt(V_scaled[15,15])

* SE for cumulative response using full covariance submatrix
matrix V_sub = V_scaled[1..15, 1..15]
matrix ones = J(15,1,1)
matrix var_cum = ones' * V_sub * ones
scalar se_cum = sqrt(var_cum[1,1])

display "ANSWER: cumulative_response estimate=" %21.12f cum_resp " se=" %21.12f se_cum " n_obs=" %12.0f N
display "ANSWER: lag_1 estimate=" %21.12f b_lag1 " se=" %21.12f se_lag1 " n_obs=" %12.0f N
display "ANSWER: lag_15 estimate=" %21.12f b_lag15 " se=" %21.12f se_lag15 " n_obs=" %12.0f N
