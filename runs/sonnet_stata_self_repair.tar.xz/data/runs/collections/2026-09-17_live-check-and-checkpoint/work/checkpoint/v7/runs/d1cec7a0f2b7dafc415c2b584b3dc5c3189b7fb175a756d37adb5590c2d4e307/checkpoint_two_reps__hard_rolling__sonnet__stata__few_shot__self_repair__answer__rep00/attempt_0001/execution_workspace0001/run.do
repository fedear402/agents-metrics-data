version 19.0
clear all
set more off
set linesize 255

import delimited "./input.csv", clear varnames(1)
sort time
tsset time

generate double lagged_y = L.y
generate double forecast = .

local window_levels = 100

forvalues f = 101/250 {
    local first_response = `f' - `window_levels' + 1
    local last_response = `f' - 1
    quietly regress y lagged_y if inrange(time, `first_response', `last_response')
    quietly replace forecast = _b[_cons] + _b[lagged_y] * lagged_y if time == `f'
}

generate double squared_error = (y - forecast)^2 if inrange(time, 101, 250)
quietly summarize squared_error, meanonly
scalar rmse = sqrt(r(mean))

display "ANSWER: rmse estimate=" %21.12f rmse " se=" %21.12f . " n_obs=" %12.0f 150

foreach f in 101 150 200 250 {
    quietly summarize forecast if time == `f', meanonly
    display "ANSWER: forecast_`f' estimate=" %21.12f r(mean) " se=" %21.12f . " n_obs=" %12.0f 99
}
