version 17.0
clear all
set more off
set linesize 255

import delimited "./input.csv", clear

// Normalize regional weights (one obs per region)
bysort region_id: gen first_in_region = (_n == 1)
summarize region_weight if first_in_region == 1, meanonly
local sum_weights = r(sum)
gen e_r = region_weight / `sum_weights'

// Construct shift-share instrument z_r = sum_n share_rn * shock_n
bysort region_id: gen z_contrib = share * shock
bysort region_id: egen z_r = sum(z_contrib)

// Keep one obs per region for regional-level variables
// but first compute industry-level aggregates

// Step 1: Compute e_r-weighted means of y, x, z (one per region, weighted by e_r)
// We need sum_r e_r * v_r for v in {y, x, z}
// Since e_r, x, y, z are constant within region, just sum over unique regions

// Get unique region data
bysort region_id (industry_id): gen region_obs = (_n == 1)

// Weighted means
gen e_r_y = e_r * y
gen e_r_x = e_r * x
gen e_r_z = e_r * z_r

summarize e_r_y if region_obs == 1, meanonly
local mean_y = r(sum)
summarize e_r_x if region_obs == 1, meanonly
local mean_x = r(sum)
summarize e_r_z if region_obs == 1, meanonly
local mean_z = r(sum)

// Demeaned regional variables
gen y0 = y - `mean_y'
gen x0 = x - `mean_x'
gen z0 = z_r - `mean_z'

// Step 2: Compute industry exposure masses s_n = sum_r e_r * share_rn
gen e_r_share = e_r * share
bysort industry_id: egen s_n = sum(e_r_share)

// Step 3: Aggregate residuals to shock level
// vbar_n = sum_r e_r * share_rn * v0_r / s_n
gen e_r_share_y0 = e_r * share * y0
gen e_r_share_x0 = e_r * share * x0
gen e_r_share_z0 = e_r * share * z0

bysort industry_id: egen num_ybar = sum(e_r_share_y0)
bysort industry_id: egen num_xbar = sum(e_r_share_x0)
bysort industry_id: egen num_zbar = sum(e_r_share_z0)

gen ybar = num_ybar / s_n
gen xbar = num_xbar / s_n
gen zbar = num_zbar / s_n

// Keep one obs per industry
bysort industry_id (region_id): gen industry_obs = (_n == 1)
keep if industry_obs == 1

// Number of industries
count
local N_industries = r(N)

// Step 4: Shock-level IV regression for effect
// Regress ybar on intercept + xbar, instrumenting xbar with shock, weights s_n
// Manual IV to get HC1 SEs

// We need: beta_IV = (Z'WX)^{-1} Z'Wy where Z=(1,shock), X=(1,xbar), y=ybar, W=diag(s_n)

// Means weighted by s_n
summarize s_n, meanonly
local sum_s = r(sum)

gen s_n_ybar = s_n * ybar
gen s_n_xbar = s_n * xbar
gen s_n_shock = s_n * shock
gen s_n_shock2 = s_n * shock^2
gen s_n_shock_xbar = s_n * shock * xbar
gen s_n_shock_ybar = s_n * shock * ybar

summarize s_n_ybar, meanonly
local sw_ybar = r(sum)
summarize s_n_xbar, meanonly
local sw_xbar = r(sum)
summarize s_n_shock, meanonly
local sw_shock = r(sum)
summarize s_n_shock2, meanonly
local sw_shock2 = r(sum)
summarize s_n_shock_xbar, meanonly
local sw_shock_xbar = r(sum)
summarize s_n_shock_ybar, meanonly
local sw_shock_ybar = r(sum)

// Z'WX matrix (2x2): rows=instruments (1,shock), cols=regressors (1,xbar)
// [sum(s_n), sum(s_n*xbar); sum(s_n*shock), sum(s_n*shock*xbar)]
local ZWX_11 = `sum_s'
local ZWX_12 = `sw_xbar'
local ZWX_21 = `sw_shock'
local ZWX_22 = `sw_shock_xbar'

// Z'Wy vector
local ZWy_1 = `sw_ybar'
local ZWy_2 = `sw_shock_ybar'

// Inverse of Z'WX
local det = `ZWX_11'*`ZWX_22' - `ZWX_12'*`ZWX_21'
local inv_11 =  `ZWX_22' / `det'
local inv_12 = -`ZWX_12' / `det'
local inv_21 = -`ZWX_21' / `det'
local inv_22 =  `ZWX_11' / `det'

// beta = inv(Z'WX) * Z'Wy
local beta0_effect = `inv_11'*`ZWy_1' + `inv_12'*`ZWy_2'
local beta1_effect = `inv_21'*`ZWy_1' + `inv_22'*`ZWy_2'

// Structural residuals: e_n = ybar - beta0 - beta1*xbar
gen resid_effect = ybar - `beta0_effect' - `beta1_effect'*xbar

// Scores: score_k_n = z_kn * s_n * resid_n
// z_1n = 1, z_2n = shock_n
gen score1_effect = 1 * s_n * resid_effect
gen score2_effect = shock * s_n * resid_effect

// Meat = scores' * scores (sum over n)
gen sc1_sq = score1_effect^2
gen sc2_sq = score2_effect^2
gen sc1_sc2 = score1_effect * score2_effect

summarize sc1_sq, meanonly
local meat_11 = r(sum)
summarize sc2_sq, meanonly
local meat_22 = r(sum)
summarize sc1_sc2, meanonly
local meat_12 = r(sum)

// HC1 multiplier: N/(N-2)
local hc1 = `N_industries' / (`N_industries' - 2)

// Variance = hc1 * inv(Z'WX) * meat * inv(Z'WX)'
// We want Var[beta1] = hc1 * [inv row2] * meat * [inv row2]'
// inv row2 = (inv_21, inv_22)
local var_beta1_effect = `hc1' * (`inv_21'^2 * `meat_11' + 2*`inv_21'*`inv_22'*`meat_12' + `inv_22'^2 * `meat_22')
local se_beta1_effect = sqrt(`var_beta1_effect')

// Step 5: First-stage - regress xbar on intercept + zbar, instrumenting zbar with shock
// Z=(1,shock), X=(1,zbar), y=xbar

gen s_n_zbar = s_n * zbar
gen s_n_shock_zbar = s_n * shock * zbar
gen s_n_zbar_xbar = s_n * zbar * xbar  // not needed
gen s_n_shock_xbar2 = s_n * shock * xbar  // already have sw_shock_xbar

summarize s_n_zbar, meanonly
local sw_zbar = r(sum)
summarize s_n_shock_zbar, meanonly
local sw_shock_zbar = r(sum)

// Z'WX for first stage: X=(1,zbar)
local FS_ZWX_11 = `sum_s'
local FS_ZWX_12 = `sw_zbar'
local FS_ZWX_21 = `sw_shock'
local FS_ZWX_22 = `sw_shock_zbar'

// Z'Wy for first stage: y=xbar
local FS_ZWy_1 = `sw_xbar'
local FS_ZWy_2 = `sw_shock_xbar'

local FS_det = `FS_ZWX_11'*`FS_ZWX_22' - `FS_ZWX_12'*`FS_ZWX_21'
local FS_inv_11 =  `FS_ZWX_22' / `FS_det'
local FS_inv_12 = -`FS_ZWX_12' / `FS_det'
local FS_inv_21 = -`FS_ZWX_21' / `FS_det'
local FS_inv_22 =  `FS_ZWX_11' / `FS_det'

local beta0_fs = `FS_inv_11'*`FS_ZWy_1' + `FS_inv_12'*`FS_ZWy_2'
local beta1_fs = `FS_inv_21'*`FS_ZWy_1' + `FS_inv_22'*`FS_ZWy_2'

gen resid_fs = xbar - `beta0_fs' - `beta1_fs'*zbar

gen score1_fs = 1 * s_n * resid_fs
gen score2_fs = shock * s_n * resid_fs

gen fs_sc1_sq = score1_fs^2
gen fs_sc2_sq = score2_fs^2
gen fs_sc1_sc2 = score1_fs * score2_fs

summarize fs_sc1_sq, meanonly
local fs_meat_11 = r(sum)
summarize fs_sc2_sq, meanonly
local fs_meat_22 = r(sum)
summarize fs_sc1_sc2, meanonly
local fs_meat_12 = r(sum)

local var_beta1_fs = `hc1' * (`FS_inv_21'^2 * `fs_meat_11' + 2*`FS_inv_21'*`FS_inv_22'*`fs_meat_12' + `FS_inv_22'^2 * `fs_meat_22')
local se_beta1_fs = sqrt(`var_beta1_fs')

// Step 6: Effective shocks = 1/sum(s_n^2)
gen s_n_sq = s_n^2
summarize s_n_sq, meanonly
local eff_shocks = 1 / r(sum)

// Report results
display "ANSWER: effect estimate=" %21.12f `beta1_effect' " se=" %21.12f `se_beta1_effect' " n_obs=" %12.0f `N_industries'
display "ANSWER: first_stage estimate=" %21.12f `beta1_fs' " se=" %21.12f `se_beta1_fs' " n_obs=" %12.0f `N_industries'
display "ANSWER: effective_shocks estimate=" %21.12f `eff_shocks' " se=" %21.12f . " n_obs=" %12.0f `N_industries'
