options(stringsAsFactors = FALSE)
library(jsonlite)
crosswalk <- read.csv('crosswalk.csv')
trade <- read.csv('trade.csv')
areas <- read.csv('areas.csv')
employment <- read.csv('employment.csv')
outcomes <- read.csv('outcomes.csv')
stopifnot(nrow(outcomes) == 72L, nrow(areas) == 144L,
          !anyDuplicated(crosswalk$code),
          !anyDuplicated(trade[c('period', 'code')]),
          !anyDuplicated(areas[c('area', 'period', 'vintage')]),
          !anyDuplicated(employment[c('area', 'period', 'vintage', 'industry')]),
          !anyDuplicated(outcomes[c('area', 'period')]))
t <- merge(trade, crosswalk, by='code', sort=FALSE)
stopifnot(nrow(t) == nrow(trade), all(table(t$period) == 4L))
national <- aggregate(employment$employment,
                      employment[c('period','vintage','industry')], sum)
names(national)[4] <- 'national_employment'
# Expand missing area-industry cells to zero before calculating each share.
grid <- merge(areas, unique(crosswalk['industry']), by=NULL)
grid <- merge(grid, employment, by=c('area','period','vintage','industry'),
              all.x=TRUE, sort=FALSE)
grid$employment[is.na(grid$employment)] <- 0
grid <- merge(grid, national, by=c('period','vintage','industry'), sort=FALSE)
stopifnot(nrow(grid) == 144L*4L, all(grid$national_employment > 0),
          all(grid$total_employment > 0))
grid <- merge(grid, t[c('period','industry','us_change','other_change',
                         'price_index','years')], by=c('period','industry'), sort=FALSE)
stopifnot(nrow(grid) == 144L*4L, all(grid$price_index > 0), all(grid$years > 0))
grid$change <- ifelse(grid$vintage == 'base', grid$us_change, grid$other_change)
grid$contribution <- (grid$employment/grid$total_employment) *
  (grid$change/grid$national_employment) / (grid$price_index/100) / 1000 *
  (10/grid$years)
exposures <- aggregate(grid$contribution, grid[c('area','period','vintage')], sum)
names(exposures)[4] <- 'exposure'
base <- merge(areas[areas$vintage == 'base',c('area','period','population')],
              exposures[exposures$vintage == 'base',c('area','period','exposure')],
              by=c('area','period'))
names(base)[4] <- 'x'
early <- exposures[exposures$vintage == 'early',c('area','period','exposure')]
names(early)[3] <- 'z'
d <- merge(merge(outcomes, base, by=c('area','period')),
           early, by=c('area','period'))
d <- d[order(d$period,d$area),]
stopifnot(nrow(d) == 72L, !anyNA(d), all(d$population > 0),
          all(table(d$period) == 36L))
X <- cbind(intercept=1, period=d$period, control=d$control, x=d$x)
Z <- cbind(intercept=1, period=d$period, control=d$control, z=d$z)
w <- d$population
# Weighted 2SLS via projection of every regressor on the instrument space.
Xw <- X*sqrt(w); Zw <- Z*sqrt(w); yw <- d$change_pp*sqrt(w)
Xhat <- qr.fitted(qr(Zw), Xw)
beta <- qr.coef(qr(Xhat), yw)
stopifnot(qr(Xhat)$rank == 4L, all(is.finite(beta)))
fetch <- function(a,p,v) {
  value <- exposures$exposure[exposures$area==a & exposures$period==p & exposures$vintage==v]
  stopifnot(length(value)==1L)
  unname(value)
}
values <- c(iv_slope=unname(beta['x']),
            exposure_area0_period0=fetch(0,0,'base'),
            exposure_area0_period1=fetch(0,1,'base'),
            instrument_area0_period0=fetch(0,0,'early'))
estimates <- lapply(names(values), function(term)
  list(term=term, estimate=unname(values[[term]]), se=NULL, n_obs=72L))
result <- list(task_id='applied_multivintage_trade_iv', platform='r',
               estimates=estimates,
               method_metadata=list(estimator='population-weighted 2SLS',
                 outcome='change_pp', endogenous='x', instrument='z',
                 exogenous=c('intercept','period','control'),
                 exposure_unit='thousands of real dollars per worker per decade',
                 national_denominator='all supplied areas within period and vintage'),
               diagnostics=list(estimation_rows=nrow(d), periods=sort(unique(d$period)),
                 industries=length(unique(crosswalk$industry)),
                 complete_area_industry_rows=nrow(grid)))
write_json(result, 'result.json', pretty=TRUE, auto_unbox=TRUE, digits=16, null='null')
cat(toJSON(as.list(values), auto_unbox=TRUE, digits=16), '\n')
