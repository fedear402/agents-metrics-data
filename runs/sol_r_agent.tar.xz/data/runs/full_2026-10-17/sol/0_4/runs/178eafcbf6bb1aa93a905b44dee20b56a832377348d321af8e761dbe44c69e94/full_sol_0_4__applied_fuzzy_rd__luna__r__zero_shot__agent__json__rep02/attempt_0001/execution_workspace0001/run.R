dat <- read.csv("input.csv")
required <- c("score", "participated", "earnings")
stopifnot(all(required %in% names(dat)))
dat <- dat[!is.na(dat$score) & abs(dat$score) < 1, ]
stopifnot(nrow(dat) > 0, all(complete.cases(dat[, required])))

x <- dat$score
right <- as.numeric(x >= 0)
w <- 1 - abs(x)
X <- cbind(intercept = 1, score = x, right = right, right_score = right * x)
Y <- cbind(earnings = dat$earnings, participated = dat$participated)
A <- crossprod(X, w * X)
B <- solve(A, crossprod(X, w * Y))
U <- Y - X %*% B
influence <- solve(A, t(X * w))
rf_influence <- influence[3, ] * U[, 1]
fs_influence <- influence[3, ] * U[, 2]
rf <- unname(B[3, 1])
fs <- unname(B[3, 2])
stopifnot(is.finite(fs), fs != 0)
te <- rf / fs
rf_var <- sum(rf_influence^2)
fs_var <- sum(fs_influence^2)
rf_fs_cov <- sum(rf_influence * fs_influence)
te_var <- rf_var / fs^2 + rf^2 * fs_var / fs^4 - 2 * rf * rf_fs_cov / fs^3
stopifnot(te_var >= 0)

item <- function(term, estimate, se) {
  list(term = term, estimate = estimate, se = se, n_obs = nrow(dat))
}
result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    item("treatment_effect", te, sqrt(te_var)),
    item("reduced_form", rf, sqrt(rf_var)),
    item("first_stage", fs, sqrt(fs_var))
  ),
  method_metadata = list(
    estimator = "Fuzzy RD ratio of triangular-weighted local-linear discontinuities, separate slopes",
    vcov = "HC0 sandwich with joint outcome-participation covariance; fixed bandwidth and weights"
  ),
  diagnostics = jsonlite::fromJSON("{}", simplifyVector = FALSE)
)
writeLines(jsonlite::toJSON(result, auto_unbox = TRUE, digits = NA, pretty = TRUE), "result.json")
