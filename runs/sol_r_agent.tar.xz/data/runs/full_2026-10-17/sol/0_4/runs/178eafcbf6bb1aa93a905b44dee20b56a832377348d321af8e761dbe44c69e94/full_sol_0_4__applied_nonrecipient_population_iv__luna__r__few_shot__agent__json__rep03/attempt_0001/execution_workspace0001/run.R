households <- read.csv("households.csv")
census <- read.csv("census.csv")
d <- households[households$recipient == 0, ]
stopifnot(nrow(d) > 0, all(d$eligible %in% 0:1), all(d$weight > 0),
          !anyNA(d), setequal(census$eligible, 0:1),
          all(census$nonrecipient_population > 0))

g0 <- 1 - d$eligible
g1 <- d$eligible
C <- cbind(g0, g1, d$baseline * g0, d$baseline * g1)
D <- cbind(d$dose * g0, d$dose * g1)
Q <- cbind(d$instrument * g0, d$instrument * g1)
X <- cbind(C, D)
Z <- cbind(C, Q)
w <- d$weight

# Weighted 2SLS: beta = (X' W P_Z X)^-1 X' W P_Z y.
ZX <- crossprod(Z, w * X)
Zy <- crossprod(Z, w * d$outcome)
ZZ <- crossprod(Z, w * Z)
beta <- solve(crossprod(ZX, solve(ZZ, ZX)),
              crossprod(ZX, solve(ZZ, Zy)))
slopes <- as.numeric(beta[5:6])
mean_dose <- vapply(0:1, function(g) {
  a <- d$eligible == g
  weighted.mean(d$dose[a], w[a])
}, numeric(1))
effects <- slopes * mean_dose
population <- census$nonrecipient_population[match(0:1, census$eligible)]
population_effect <- weighted.mean(effects, population)
n <- nrow(d)

result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = list(
    list(term = "ineligible_effect", estimate = effects[1], se = NA_real_, n_obs = n),
    list(term = "eligible_nonrecipient_effect", estimate = effects[2], se = NA_real_, n_obs = n),
    list(term = "population_effect", estimate = population_effect, se = NA_real_, n_obs = n)
  ),
  method_metadata = list(
    estimator = "weighted 2SLS",
    sample = "recipient == 0",
    exogenous_columns = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"),
    endogenous_columns = c("dose*(1-eligible)", "dose*eligible"),
    excluded_instruments = c("instrument*(1-eligible)", "instrument*eligible"),
    counterfactual = "dose = 0 for every retained household; synthetic attribution convention",
    within_group_average = "household-weighted mean dose",
    between_group_average = "census nonrecipient population"
  ),
  diagnostics = list(
    n_obs = n,
    group_n_obs = as.integer(table(factor(d$eligible, levels = 0:1))),
    design_rank = qr(X)$rank,
    instrument_rank = qr(Z)$rank,
    dose_slopes = slopes,
    group_weighted_mean_dose = mean_dose
  )
)
jsonlite::write_json(result, "result.json", pretty = TRUE, auto_unbox = TRUE,
                     digits = 16, na = "null")
