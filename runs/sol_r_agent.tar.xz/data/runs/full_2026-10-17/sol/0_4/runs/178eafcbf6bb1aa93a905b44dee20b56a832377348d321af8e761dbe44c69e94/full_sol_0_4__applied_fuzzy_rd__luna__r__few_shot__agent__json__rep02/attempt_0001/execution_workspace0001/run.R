library(jsonlite)

data <- read.csv("input.csv")
required <- c("id", "score", "participated", "earnings")
stopifnot(all(required %in% names(data)))
sample <- data[!is.na(data$score) & abs(data$score) < 1, ]
stopifnot(nrow(sample) > 4, all(complete.cases(sample[, required])))

right <- as.numeric(sample$score >= 0)
weights <- 1 - abs(sample$score)
X <- cbind(intercept = 1, right = right, score = sample$score,
           right_score = right * sample$score)
Y <- cbind(earnings = sample$earnings, participated = sample$participated)
bread <- solve(crossprod(X, weights * X))
beta <- bread %*% crossprod(X, weights * Y)
residual <- Y - X %*% beta
contrast <- c(0, 1, 0, 0)
jump <- drop(contrast %*% beta)
loading <- weights * drop(X %*% bread %*% contrast)
influence <- loading * residual
joint <- crossprod(influence)
gradient <- c(1 / jump[2], -jump[1] / jump[2]^2)
ratio <- jump[1] / jump[2]
ratio_se <- sqrt(drop(t(gradient) %*% joint %*% gradient))
n <- nrow(sample)

row <- function(term, estimate, se) {
  list(term = term, estimate = unname(as.numeric(estimate)),
       se = unname(as.numeric(se)), n_obs = as.integer(n))
}
result <- list(
  task_id = "applied_fuzzy_rd", platform = "r",
  estimates = list(
    row("treatment_effect", ratio, ratio_se),
    row("reduced_form", jump[1], sqrt(joint[1, 1])),
    row("first_stage", jump[2], sqrt(joint[2, 2]))
  ),
  method_metadata = list(
    estimator = "triangular-weighted local linear fuzzy regression discontinuity",
    vcov = "joint heteroskedasticity-robust HC0; delta method for ratio"
  ),
  diagnostics = setNames(list(), character())
)
write_json(result, "result.json", auto_unbox = TRUE, digits = 16, pretty = TRUE)
