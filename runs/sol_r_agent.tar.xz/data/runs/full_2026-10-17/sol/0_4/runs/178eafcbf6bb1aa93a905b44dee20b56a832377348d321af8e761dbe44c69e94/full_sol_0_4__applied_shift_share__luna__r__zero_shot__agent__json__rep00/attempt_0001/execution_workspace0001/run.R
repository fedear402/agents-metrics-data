data <- read.csv("input.csv")
required <- c("region_id", "industry_id", "share", "shock", "region_weight", "x", "y")
stopifnot(all(required %in% names(data)), !anyNA(data[required]))
stopifnot(all(data$share >= 0), all(data$region_weight > 0))
stopifnot(!anyDuplicated(data[c("region_id", "industry_id")]))

regions <- data[!duplicated(data$region_id), c("region_id", "region_weight", "x", "y")]
industries <- data[!duplicated(data$industry_id), c("industry_id", "shock")]
region_index <- match(data$region_id, regions$region_id)
industry_index <- match(data$industry_id, industries$industry_id)
stopifnot(all(data$region_weight == regions$region_weight[region_index]))
stopifnot(all(data$x == regions$x[region_index]), all(data$y == regions$y[region_index]))
stopifnot(all(data$shock == industries$shock[industry_index]))
stopifnot(max(abs(rowsum(data$share, region_index, reorder = TRUE) - 1)) < 1e-10)

regions$e <- regions$region_weight / sum(regions$region_weight)
regions$z <- as.numeric(rowsum(data$share * data$shock, region_index, reorder = TRUE))
center <- function(v) v - sum(regions$e * v)
y0 <- center(regions$y)
x0 <- center(regions$x)
z0 <- center(regions$z)
exposure <- regions$e[region_index] * data$share
s <- as.numeric(rowsum(exposure, industry_index, reorder = TRUE))
stopifnot(all(s > 0), abs(sum(s) - 1) < 1e-12)
aggregate_residual <- function(v) {
  as.numeric(rowsum(exposure * v[region_index], industry_index, reorder = TRUE)) / s
}
ybar <- aggregate_residual(y0)
xbar <- aggregate_residual(x0)
zbar <- aggregate_residual(z0)
shock <- industries$shock
N <- length(shock)
stopifnot(N > 2)

# The two-equation weighted IV sandwich uses structural residuals. In this
# just-identified model its slope variance reduces to the expression below.
weighted_iv <- function(outcome, endogenous, instrument, weight) {
  mean_w <- function(v) sum(weight * v) / sum(weight)
  xc <- endogenous - mean_w(endogenous)
  gc <- instrument - mean_w(instrument)
  slope <- sum(weight * gc * (outcome - mean_w(outcome))) / sum(weight * gc * xc)
  intercept <- mean_w(outcome) - slope * mean_w(endogenous)
  residual <- outcome - intercept - slope * endogenous
  se <- sqrt((N / (N - 2)) * sum((weight * gc * residual)^2) /
             sum(weight * gc * xc)^2)
  c(estimate = slope, se = se)
}
effect <- weighted_iv(ybar, xbar, shock, s)
first_stage <- weighted_iv(xbar, zbar, shock, s)
effective_shocks <- 1 / sum(s^2)

output <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = unname(effect["estimate"]), se = unname(effect["se"]), n_obs = N),
    list(term = "first_stage", estimate = unname(first_stage["estimate"]), se = unname(first_stage["se"]), n_obs = N),
    list(term = "effective_shocks", estimate = effective_shocks, se = NA_real_, n_obs = N)
  ),
  method_metadata = list(
    estimator = "Weighted regional 2SLS via BHJ shock-level IV aggregation",
    vcov = "Shock-level heteroskedasticity-robust HC1, structural IV residuals, N/(N-2)"
  ),
  diagnostics = list()
)
json <- as.character(jsonlite::toJSON(output, auto_unbox = TRUE, digits = NA,
                                      pretty = TRUE, na = "null"))
json <- sub('"diagnostics": \\[\\]', '"diagnostics": {}', json)
writeLines(json, "result.json")
