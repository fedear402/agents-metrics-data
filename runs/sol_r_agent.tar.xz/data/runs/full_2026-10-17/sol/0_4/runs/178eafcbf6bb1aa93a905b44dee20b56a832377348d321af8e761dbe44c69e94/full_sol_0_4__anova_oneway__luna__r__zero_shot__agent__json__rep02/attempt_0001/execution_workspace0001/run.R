data <- read.csv("input.csv", stringsAsFactors = FALSE)
stopifnot(identical(names(data), c("group", "y")))
stopifnot(is.numeric(data$y))

sample <- data[complete.cases(data[, c("group", "y")]), , drop = FALSE]
stopifnot(nrow(sample) > 0L, all(is.finite(sample$y)))
sample$group <- factor(sample$group)
stopifnot(nlevels(sample$group) >= 2L)

fit <- aov(y ~ group, data = sample)
table <- summary(fit)[[1L]]
f_stat <- unname(table["group", "F value"])
df_num <- unname(table["group", "Df"])
df_den <- unname(table["Residuals", "Df"])
p_value <- pf(f_stat, df_num, df_den, lower.tail = FALSE)
n_obs <- nobs(fit)

# Independent ANOVA calculation from group means and within-group deviations.
groups <- split(sample$y, sample$group)
grand_mean <- mean(sample$y)
ss_between <- sum(vapply(groups, function(x) length(x) * (mean(x) - grand_mean)^2, numeric(1)))
ss_within <- sum(vapply(groups, function(x) sum((x - mean(x))^2), numeric(1)))
f_manual <- (ss_between / (length(groups) - 1L)) /
  (ss_within / (nrow(sample) - length(groups)))
stopifnot(isTRUE(all.equal(f_stat, f_manual, tolerance = 1e-12)))
stopifnot(isTRUE(all.equal(p_value, unname(table["group", "Pr(>F)"]), tolerance = 1e-12)))

row <- function(term, value) list(term = term, estimate = as.numeric(value), se = NULL, n_obs = as.integer(n_obs))
result <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = list(row("F", f_stat), row("df_num", df_num), row("df_den", df_den), row("p_value", p_value)),
  method_metadata = list(estimator = "one-way ANOVA", vcov = "classical pooled within-group variance"),
  diagnostics = list()
)
jsonlite::write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = NA, pretty = TRUE)

lines <- c(
  sprintf("Input rows: %d; complete-case estimation rows: %d; excluded rows: %d.", nrow(data), n_obs, nrow(data) - n_obs),
  sprintf("Groups: %d; group counts: %s.", length(groups), paste(sprintf("%s=%d", names(groups), lengths(groups)), collapse = ", ")),
  sprintf("ANOVA: F=%.15g, df_num=%d, df_den=%d, p_value=%.15g.", f_stat, df_num, df_den, p_value),
  sprintf("Independent sums-of-squares check: SS_between=%.15g, SS_within=%.15g, manual F=%.15g.", ss_between, ss_within, f_manual),
  "The manual F agrees with aov within relative tolerance 1e-12; pf agrees with the ANOVA p-value."
)
writeLines(lines, "verification.txt")
