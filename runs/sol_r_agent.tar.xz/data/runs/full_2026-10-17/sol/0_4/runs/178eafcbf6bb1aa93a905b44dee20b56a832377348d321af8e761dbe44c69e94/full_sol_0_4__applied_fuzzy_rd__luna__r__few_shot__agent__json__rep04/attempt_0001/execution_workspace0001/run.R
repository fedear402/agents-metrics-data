library(jsonlite)

data <- read.csv("input.csv")
required <- c("id", "score", "participated", "earnings")
stopifnot(all(required %in% names(data)))
sample <- data[is.finite(data$score) & abs(data$score) < 1 &
                 is.finite(data$participated) & is.finite(data$earnings), ]
stopifnot(nrow(sample) > 0, all(sample$participated %in% c(0, 1)))

x <- sample$score
right <- as.numeric(x >= 0)
w <- 1 - abs(x)
X <- cbind(left_intercept = 1 - right, left_slope = x * (1 - right),
           right_intercept = right, right_slope = x * right)
Y <- cbind(earnings = sample$earnings, participated = sample$participated)
bread <- solve(crossprod(X, w * X))
beta <- bread %*% crossprod(X, w * Y)
residuals <- Y - X %*% beta
contrast <- c(-1, 0, 1, 0)
jumps <- drop(contrast %*% beta)
loading <- w * drop(X %*% bread %*% contrast)
contributions <- loading * residuals
joint <- crossprod(contributions)
gradient <- c(1 / jumps[2], -jumps[1] / jumps[2]^2)
effect <- jumps[1] / jumps[2]
effect_se <- sqrt(drop(t(gradient) %*% joint %*% gradient))

row <- function(term, estimate, se) {
  list(term = term, estimate = unname(as.numeric(estimate)),
       se = unname(as.numeric(se)), n_obs = as.integer(nrow(sample)))
}
output <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    row("treatment_effect", effect, effect_se),
    row("reduced_form", jumps[1], sqrt(joint[1, 1])),
    row("first_stage", jumps[2], sqrt(joint[2, 2]))
  ),
  method_metadata = list(
    estimator = "Triangular-weighted local linear fuzzy regression discontinuity, bandwidth 1",
    vcov = "Joint heteroskedasticity-robust HC0 sandwich; delta method for ratio"
  ),
  diagnostics = list(n_left = as.integer(sum(right == 0)),
                     n_right = as.integer(sum(right == 1)))
)
write_json(output, "result.json", auto_unbox = TRUE, pretty = TRUE,
           digits = 16, null = "null")
