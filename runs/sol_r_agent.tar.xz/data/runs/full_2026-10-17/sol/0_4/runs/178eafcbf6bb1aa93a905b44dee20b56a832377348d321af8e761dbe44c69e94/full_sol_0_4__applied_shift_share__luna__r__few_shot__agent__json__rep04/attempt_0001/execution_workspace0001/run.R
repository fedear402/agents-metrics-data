library(jsonlite)

d <- read.csv("input.csv")
required <- c("region_id", "industry_id", "share", "shock", "region_weight", "x", "y")
stopifnot(identical(names(d), required), all(complete.cases(d)))
regions <- sort(unique(d$region_id))
industries <- sort(unique(d$industry_id))
R <- length(regions)
N <- length(industries)
stopifnot(nrow(d) == R * N, !anyDuplicated(d[c("region_id", "industry_id")]))
ri <- match(d$region_id, regions)
ni <- match(d$industry_id, industries)
share <- matrix(NA_real_, R, N)
share[cbind(ri, ni)] <- d$share
stopifnot(all(is.finite(share)), max(abs(rowSums(share) - 1)) < 1e-10)

regional <- function(name) {
  values <- split(d[[name]], factor(ri, levels = seq_len(R)))
  stopifnot(all(vapply(values, function(a) max(a) - min(a) < 1e-12, logical(1))))
  vapply(values, function(a) a[1], numeric(1))
}
industry <- function(name) {
  values <- split(d[[name]], factor(ni, levels = seq_len(N)))
  stopifnot(all(vapply(values, function(a) max(a) - min(a) < 1e-12, logical(1))))
  vapply(values, function(a) a[1], numeric(1))
}
shock <- industry("shock")
e <- regional("region_weight")
stopifnot(all(e > 0), all(share >= 0))
e <- e / sum(e)
x <- regional("x")
y <- regional("y")
z <- drop(share %*% shock)
center <- function(v) v - sum(e * v)
regional0 <- cbind(y = center(y), x = center(x), z = center(z))
s <- drop(crossprod(e, share))
stopifnot(all(s > 0), abs(sum(s) - 1) < 1e-12)
aggregate <- function(v) drop(crossprod(share, e * v)) / s
bars <- apply(regional0, 2, aggregate)
stopifnot(max(abs(drop(crossprod(s, bars)))) < 1e-12)

shock_iv <- function(dependent, endogenous) {
  X <- cbind(1, endogenous)
  Z <- cbind(1, shock)
  cross <- crossprod(Z, s * X)
  beta <- drop(solve(cross, crossprod(Z, s * dependent)))
  residual <- drop(dependent - X %*% beta)
  scores <- Z * (s * residual)
  inverse <- solve(cross)
  vcov <- N / (N - 2) * inverse %*% crossprod(scores) %*% t(inverse)
  c(estimate = unname(beta[2]), se = unname(sqrt(vcov[2, 2])))
}
effect <- shock_iv(bars[, "y"], bars[, "x"])
first_stage <- shock_iv(bars[, "x"], bars[, "z"])
effective <- 1 / sum(s^2)

regional_effect <- sum(e * regional0[, "z"] * regional0[, "y"]) /
  sum(e * regional0[, "z"] * regional0[, "x"])
regional_first_stage <- sum(e * regional0[, "z"] * regional0[, "x"]) /
  sum(e * regional0[, "z"]^2)
stopifnot(abs(effect["estimate"] - regional_effect) < 1e-10,
          abs(first_stage["estimate"] - regional_first_stage) < 1e-10)

row <- function(term, value, se) {
  list(term = term, estimate = unname(as.numeric(value)),
       se = if (is.null(se)) NULL else unname(as.numeric(se)), n_obs = N)
}
out <- list(
  task_id = "applied_shift_share", platform = "r",
  estimates = list(row("effect", effect["estimate"], effect["se"]),
                   row("first_stage", first_stage["estimate"], first_stage["se"]),
                   row("effective_shocks", effective, NULL)),
  method_metadata = list(estimator = "Weighted regional 2SLS via shock-level IV",
                         vcov = "Shock-level heteroskedastic HC1, N/(N-2), analytic weights"),
  diagnostics = structure(list(), names = character(0))
)
write_json(out, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
cat(sprintf("regions=%d industries=%d rows=%d\n", R, N, nrow(d)))
cat(sprintf("effect: shock=%.12g regional=%.12g se=%.12g\n", effect[1], regional_effect, effect[2]))
cat(sprintf("first_stage: shock=%.12g regional=%.12g se=%.12g\n", first_stage[1], regional_first_stage, first_stage[2]))
cat(sprintf("effective_shocks=%.12g\n", effective))
