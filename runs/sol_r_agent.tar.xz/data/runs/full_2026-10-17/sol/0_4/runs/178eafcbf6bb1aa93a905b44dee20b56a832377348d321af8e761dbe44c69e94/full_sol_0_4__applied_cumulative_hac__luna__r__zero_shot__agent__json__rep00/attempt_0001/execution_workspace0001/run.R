dat <- read.csv("input.csv", stringsAsFactors = FALSE)
stopifnot(identical(names(dat), c("date", "sales", "vix")))
dat$date <- as.Date(dat$date)
stopifnot(!anyNA(dat), !anyDuplicated(dat$date), all(dat$sales > 0), all(dat$vix > 0))
dat <- dat[order(dat$date), ]

n <- nrow(dat)
dlog_vix <- c(NA_real_, diff(log(dat$vix)))
lagged <- sapply(1:15, function(k) c(rep(NA_real_, k), dlog_vix[seq_len(n - k)]))
colnames(lagged) <- paste0("lag_", 1:15)
sample <- complete.cases(lagged)
X <- cbind("(Intercept)" = 1, lagged[sample, , drop = FALSE])
y <- log(dat$sales[sample])
N <- length(y)
stopifnot(N > 16, ncol(X) == 16, qr(X)$rank == 16)

beta <- as.vector(qr.solve(X, y))
names(beta) <- colnames(X)
resid <- as.vector(y - X %*% beta)
scores <- X * resid
meat <- crossprod(scores)
for (j in 1:15) {
  cross <- crossprod(scores[(j + 1):N, , drop = FALSE], scores[1:(N - j), , drop = FALSE])
  meat <- meat + (1 - j / 16) * (cross + t(cross))
}
bread <- solve(crossprod(X))
V <- (N / (N - 16)) * bread %*% meat %*% bread
dimnames(V) <- list(colnames(X), colnames(X))

w <- c(0, rep(1, 15))
terms <- c("cumulative_response", "lag_1", "lag_15")
est <- c(sum(beta[-1]), beta["lag_1"], beta["lag_15"])
se <- c(sqrt(as.numeric(t(w) %*% V %*% w)), sqrt(V["lag_1", "lag_1"]), sqrt(V["lag_15", "lag_15"]))
out <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = lapply(seq_along(terms), function(i) list(term = terms[i], estimate = unname(est[i]), se = unname(se[i]), n_obs = N)),
  method_metadata = list(estimator = "OLS with intercept and 15 lagged log VIX changes", vcov = "Newey-West Bartlett HAC, lag 15, N/(N-16) correction"),
  diagnostics = structure(list(), names = character())
)
if (!requireNamespace("jsonlite", quietly = TRUE)) stop("jsonlite is required")
writeLines(jsonlite::toJSON(out, auto_unbox = TRUE, digits = NA, pretty = TRUE), "result.json")
