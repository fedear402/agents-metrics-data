d <- read.csv("input.csv", stringsAsFactors = FALSE)
stopifnot(identical(names(d), c("date", "sales", "vix")))
d$date <- as.Date(d$date)
stopifnot(!anyNA(d), !anyDuplicated(d$date), all(d$sales > 0), all(d$vix > 0))
d <- d[order(d$date), ]
N_all <- nrow(d)
change <- c(NA_real_, diff(log(d$vix)))
lag_count <- 15L
X_all <- matrix(NA_real_, N_all, lag_count + 1L)
X_all[, 1L] <- 1
for (k in seq_len(lag_count)) {
  if (N_all > k) X_all[(k + 1L):N_all, k + 1L] <- change[1L:(N_all - k)]
}
colnames(X_all) <- c("intercept", paste0("lag_", seq_len(lag_count)))
usable <- complete.cases(X_all) & is.finite(log(d$sales))
X <- X_all[usable, , drop = FALSE]
y <- log(d$sales[usable])
N <- nrow(X)
p <- ncol(X)
stopifnot(N > p, N == N_all - 16L, all(which(usable) == seq.int(17L, N_all)))
fit <- lm.fit(X, y)
stopifnot(fit$rank == p)
b <- as.numeric(fit$coefficients)
u <- as.numeric(fit$residuals)
scores <- X * u
meat <- crossprod(scores)
for (j in seq_len(lag_count)) {
  cross_lag <- crossprod(scores[(j + 1L):N, , drop = FALSE], scores[1L:(N - j), , drop = FALSE])
  meat <- meat + (1 - j / 16) * (cross_lag + t(cross_lag))
}
bread <- solve(crossprod(X))
V <- (N / (N - p)) * bread %*% meat %*% bread
contrast <- c(0, rep(1, lag_count))
rows <- list(
  list(term = "cumulative_response", estimate = unname(sum(b[-1L])), se = unname(sqrt(drop(t(contrast) %*% V %*% contrast))), n_obs = N),
  list(term = "lag_1", estimate = unname(b[2L]), se = unname(sqrt(V[2L, 2L])), n_obs = N),
  list(term = "lag_15", estimate = unname(b[16L]), se = unname(sqrt(V[16L, 16L])), n_obs = N)
)
result <- list(task_id = "applied_cumulative_hac", platform = "r", estimates = rows,
               method_metadata = list(estimator = "OLS with intercept and 15 trading-observation lags of log VIX changes",
                                      vcov = "Bartlett Newey-West HAC, max lag 15, N/(N-16) correction"),
               diagnostics = list())
jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = 16, pretty = TRUE)
