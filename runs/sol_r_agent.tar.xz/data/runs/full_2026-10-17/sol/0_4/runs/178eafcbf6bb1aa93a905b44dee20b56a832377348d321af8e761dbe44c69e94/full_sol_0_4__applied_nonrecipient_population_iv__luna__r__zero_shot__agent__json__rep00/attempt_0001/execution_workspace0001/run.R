library(jsonlite)

h <- read.csv('households.csv')
census <- read.csv('census.csv')
s <- h[h$recipient == 0, , drop = FALSE]
stopifnot(nrow(s) > 0L, all(s$eligible %in% c(0, 1)), all(s$weight > 0),
          all(is.finite(as.matrix(s[c('dose', 'baseline', 'instrument', 'weight', 'outcome')]))),
          setequal(census$eligible, c(0, 1)), all(census$nonrecipient_population > 0),
          !anyDuplicated(census$eligible))

g0 <- 1 - s$eligible
g1 <- s$eligible
X <- cbind(g0, g1, s$baseline * g0, s$baseline * g1,
           s$dose * g0, s$dose * g1)
Z <- cbind(g0, g1, s$baseline * g0, s$baseline * g1,
           s$instrument * g0, s$instrument * g1)
w <- s$weight
y <- s$outcome
ZWZ <- crossprod(Z, w * Z)
ZWX <- crossprod(Z, w * X)
ZWy <- crossprod(Z, w * y)
stopifnot(qr(ZWZ)$rank == ncol(Z), qr(ZWX)$rank == ncol(X))
beta <- as.vector(solve(t(ZWX) %*% solve(ZWZ, ZWX),
                        t(ZWX) %*% solve(ZWZ, ZWy)))
mean_dose <- c(sum(w * g0 * s$dose) / sum(w * g0),
               sum(w * g1 * s$dose) / sum(w * g1))
effects <- beta[5:6] * mean_dose
pop <- census$nonrecipient_population[match(c(0, 1), census$eligible)]
pop_effect <- sum(effects * pop) / sum(pop)
n <- nrow(s)
terms <- c('ineligible_effect', 'eligible_nonrecipient_effect', 'population_effect')
values <- c(effects, pop_effect)
estimates <- lapply(seq_along(terms), function(i) list(term = terms[i], estimate = unname(values[i]), se = NULL, n_obs = as.integer(n)))
result <- list(task_id = 'applied_nonrecipient_population_iv', platform = 'r',
               estimates = estimates,
               method_metadata = list(estimator = 'weighted 2SLS', sample = 'recipient == 0',
                 endogenous = c('dose*(1-eligible)', 'dose*eligible'),
                 exogenous = c('1-eligible', 'eligible', 'baseline*(1-eligible)', 'baseline*eligible'),
                 excluded_instruments = c('instrument*(1-eligible)', 'instrument*eligible'),
                 intercept = 'group indicators only',
                 group_dose_mean = 'household-weighted within retained group',
                 counterfactual = 'dose set to zero for every retained household; synthetic attribution convention',
                 population_weights = 'census nonrecipient_population; final aggregation only'),
               diagnostics = list(n_obs = as.integer(n), group_n_obs = as.integer(c(sum(g0), sum(g1))),
                 group_weighted_mean_dose = unname(mean_dose), dose_slopes = unname(beta[5:6]),
                 group_population = as.integer(pop), instrument_rank = as.integer(qr(ZWZ)$rank)))
write_json(result, 'result.json', auto_unbox = TRUE, pretty = TRUE, digits = 16, null = 'null')
