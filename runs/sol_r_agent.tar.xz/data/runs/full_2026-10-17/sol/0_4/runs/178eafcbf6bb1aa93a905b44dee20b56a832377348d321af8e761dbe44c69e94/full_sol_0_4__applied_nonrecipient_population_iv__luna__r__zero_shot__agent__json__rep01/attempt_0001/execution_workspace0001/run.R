options(digits = 17)
library(jsonlite)
h <- read.csv('households.csv')
census <- read.csv('census.csv')
stopifnot(all(c('eligible','recipient','instrument','dose','baseline','weight','outcome','treated') %in% names(h)))
stopifnot(all(h$eligible %in% 0:1), all(h$recipient %in% 0:1), all(h$weight > 0))
stopifnot(identical(sort(census$eligible), 0:1), all(census$nonrecipient_population > 0))
s <- h[h$recipient == 0, ]
n <- nrow(s)
g0 <- 1 - s$eligible
g1 <- s$eligible
X <- cbind(g0, g1, s$baseline*g0, s$baseline*g1, s$dose*g0, s$dose*g1)
Z <- cbind(g0, g1, s$baseline*g0, s$baseline*g1, s$instrument*g0, s$instrument*g1)
w <- s$weight
stopifnot(qr(X)$rank == 6L, qr(Z)$rank == 6L)
# Weighted two-stage least squares, with no separate intercept.
ZWZ <- crossprod(Z, w*Z)
ZWX <- crossprod(Z, w*X)
ZWy <- crossprod(Z, w*s$outcome)
PXX <- crossprod(ZWX, solve(ZWZ, ZWX))
PXy <- crossprod(ZWX, solve(ZWZ, ZWy))
beta <- drop(solve(PXX, PXy))
mean_dose <- vapply(0:1, function(g) weighted.mean(s$dose[s$eligible == g], w[s$eligible == g]), numeric(1))
effects <- beta[5:6] * mean_dose
population <- census$nonrecipient_population[match(0:1, census$eligible)]
population_effect <- sum(population*effects)/sum(population)
# Independent check: groupwise, exactly identified IV after weighted residualization.
group_slopes <- vapply(0:1, function(g) {
  d <- s[s$eligible == g, ]
  control <- cbind(1, d$baseline)
  residual <- function(v) drop(v - control %*% solve(crossprod(control, d$weight*control), crossprod(control, d$weight*v)))
  zr <- residual(d$instrument)
  sum(d$weight*zr*residual(d$outcome))/sum(d$weight*zr*residual(d$dose))
}, numeric(1))
stopifnot(max(abs(group_slopes - beta[5:6])) < 1e-9)
terms <- c('ineligible_effect','eligible_nonrecipient_effect','population_effect')
values <- c(effects, population_effect)
estimates <- lapply(seq_along(terms), function(i) list(term=terms[i], estimate=unname(values[i]), se=NA_real_, n_obs=as.integer(n)))
result <- list(task_id='applied_nonrecipient_population_iv', platform='r', estimates=estimates,
  method_metadata=list(estimator='weighted 2SLS', sample='recipient == 0', counterfactual='Set dose to zero for every retained household; attribution uses this synthetic convention.', within_group_mean='Household weight weighted mean dose among retained observations.', population_aggregation='Census nonrecipient_population used only for final between-group weights.', standard_errors='Not requested; null.'),
  diagnostics=list(n_obs=as.integer(n), group_n_obs=as.integer(table(factor(s$eligible, levels=0:1))), group_treatment_status=as.integer(table(factor(s$treated, levels=0:1))), dose_slopes=unname(beta[5:6]), independent_group_slopes=unname(group_slopes), weighted_mean_dose=unname(mean_dose), census_nonrecipient_population=as.integer(population), x_rank=as.integer(qr(X)$rank), z_rank=as.integer(qr(Z)$rank)))
write_json(result, 'result.json', pretty=TRUE, auto_unbox=TRUE, na='null', digits=16)
cat(sprintf('n=%d; slopes=%.12f, %.12f; means=%.12f, %.12f; effects=%.12f, %.12f, %.12f\n', n, beta[5], beta[6], mean_dose[1], mean_dose[2], values[1], values[2], values[3]))
