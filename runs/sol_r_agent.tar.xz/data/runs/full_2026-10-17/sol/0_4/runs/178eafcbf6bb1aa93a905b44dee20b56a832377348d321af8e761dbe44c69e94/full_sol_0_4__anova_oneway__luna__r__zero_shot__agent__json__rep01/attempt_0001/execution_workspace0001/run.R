data <- read.csv("input.csv", stringsAsFactors = FALSE)
if (!all(c("group", "y") %in% names(data))) stop("Required columns are missing")
sample <- data[!is.na(data$group) & is.finite(data$y), c("group", "y")]
sample$group <- factor(sample$group)
if (nlevels(sample$group) < 2L) stop("At least two groups are required")

fit <- aov(y ~ group, data = sample)
anova_table <- summary(fit)[[1L]]
values <- c(
  F = unname(anova_table[1L, "F value"]),
  df_num = unname(anova_table[1L, "Df"]),
  df_den = unname(anova_table[2L, "Df"]),
  p_value = unname(anova_table[1L, "Pr(>F)"])
)
n_obs <- nrow(sample)
result <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = lapply(names(values), function(term) {
    list(term = term, estimate = unname(values[[term]]), se = NULL, n_obs = n_obs)
  }),
  method_metadata = list(estimator = "one-way ANOVA", vcov = "classical pooled within-group variance"),
  diagnostics = jsonlite::fromJSON("{}", simplifyVector = FALSE)
)
writeLines(jsonlite::toJSON(result, auto_unbox = TRUE, null = "null", digits = NA), "result.json")
