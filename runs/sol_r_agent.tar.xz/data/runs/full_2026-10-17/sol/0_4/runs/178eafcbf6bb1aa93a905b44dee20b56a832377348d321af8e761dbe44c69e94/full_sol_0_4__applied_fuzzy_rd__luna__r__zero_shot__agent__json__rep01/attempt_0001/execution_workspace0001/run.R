dat <- read.csv("input.csv")
keep <- !is.na(dat$score) & !is.na(dat$earnings) &
  !is.na(dat$participated) & abs(dat$score) < 1
d <- dat[keep, ]
x <- d$score
w <- 1 - abs(x)
right <- as.numeric(x >= 0)
X <- cbind(intercept = 1, score = x, right = right,
           right_score = right * x)

# Weighted least squares with fixed triangular weights.
Ainv <- solve(crossprod(X, w * X))
fit <- function(y) as.vector(Ainv %*% crossprod(X, w * y))
by <- fit(d$earnings)
bd <- fit(d$participated)
uy <- as.vector(d$earnings - X %*% by)
ud <- as.vector(d$participated - X %*% bd)

# HC0 joint sandwich covariance of the two cutoff jumps.
joint_cov <- function(u, v) {
  meat <- crossprod(X, (w^2 * u * v) * X)
  (Ainv %*% meat %*% Ainv)[3, 3]
}
rf <- unname(by[3])
fs <- unname(bd[3])
vrf <- joint_cov(uy, uy)
vfs <- joint_cov(ud, ud)
crf_fs <- joint_cov(uy, ud)
te <- rf / fs
vte <- vrf / fs^2 + rf^2 * vfs / fs^4 - 2 * rf * crf_fs / fs^3
n <- nrow(d)

result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = te, se = sqrt(vte), n_obs = n),
    list(term = "reduced_form", estimate = rf, se = sqrt(vrf), n_obs = n),
    list(term = "first_stage", estimate = fs, se = sqrt(vfs), n_obs = n)
  ),
  method_metadata = list(
    estimator = "Weighted local-linear fuzzy RD, separate slopes by side, Wald ratio",
    vcov = "Fixed-weight joint HC0 sandwich; delta method for Wald ratio"
  ),
  diagnostics = list()
)
jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = 16)
