crosswalk <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
trade <- read.csv("trade.csv", stringsAsFactors = FALSE)
areas <- read.csv("areas.csv", stringsAsFactors = FALSE)
employment <- read.csv("employment.csv", stringsAsFactors = FALSE)
outcomes <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

trade <- merge(trade, crosswalk, by = "code", sort = FALSE)
stopifnot(nrow(trade) == 8L, length(unique(crosswalk$industry)) == 4L)
grid <- merge(areas, data.frame(industry = unique(crosswalk$industry)), by = NULL)
cells <- merge(grid, employment, by = c("area", "period", "vintage", "industry"),
               all.x = TRUE, sort = FALSE)
cells$employment[is.na(cells$employment)] <- 0
national <- aggregate(employment ~ period + vintage + industry, data = cells, sum)
names(national)[4] <- "national_employment"
cells <- merge(cells, national, by = c("period", "vintage", "industry"), sort = FALSE)
cells <- merge(cells, trade, by = c("period", "industry"), sort = FALSE)
stopifnot(nrow(cells) == nrow(areas) * 4L, all(cells$national_employment > 0))
cells$change <- ifelse(cells$vintage == "base", cells$us_change, cells$other_change)
cells$component <- (cells$employment / cells$total_employment) *
  (cells$change / cells$national_employment) /
  (cells$price_index / 100) / 1000 * (10 / cells$years)
exposure <- aggregate(component ~ area + period + vintage, data = cells, sum)
base <- subset(exposure, vintage == "base", select = c(area, period, component))
early <- subset(exposure, vintage == "early", select = c(area, period, component))
names(base)[3] <- "x"
names(early)[3] <- "z"
d <- merge(outcomes, base, by = c("area", "period"))
d <- merge(d, early, by = c("area", "period"))
base_areas <- subset(areas, vintage == "base", select = c(area, period, population))
d <- merge(d, base_areas, by = c("area", "period"))
d <- d[order(d$period, d$area), ]
stopifnot(nrow(d) == 72L, !anyNA(d), !anyDuplicated(d[c("area", "period")]))

X <- cbind(intercept = 1, period = d$period, control = d$control, x = d$x)
Z <- cbind(intercept = 1, period = d$period, control = d$control, z = d$z)
w <- d$population
# Exactly identified weighted IV: solve Z' W X beta = Z' W y.
beta <- solve(crossprod(Z, X * w), crossprod(Z, d$change_pp * w))
get_value <- function(variable, area, period) {
  value <- d[d$area == area & d$period == period, variable]
  stopifnot(length(value) == 1L)
  unname(value)
}
estimates <- list(
  list(term = "iv_slope", estimate = unname(beta["x", 1]), se = NULL, n_obs = 72L),
  list(term = "exposure_area0_period0", estimate = get_value("x", 0, 0), se = NULL, n_obs = 72L),
  list(term = "exposure_area0_period1", estimate = get_value("x", 0, 1), se = NULL, n_obs = 72L),
  list(term = "instrument_area0_period0", estimate = get_value("z", 0, 0), se = NULL, n_obs = 72L)
)
result <- list(
  task_id = "applied_multivintage_trade_iv", platform = "r", estimates = estimates,
  method_metadata = list(estimator = "weighted exactly identified 2SLS",
                         regressors = c("intercept", "period", "control", "x"),
                         instruments = c("intercept", "period", "control", "z"),
                         weight = "base-vintage population",
                         exposure_unit = "thousands of real dollars per worker per decade"),
  diagnostics = list(n_obs = 72L, n_industries = 4L,
                     max_weighted_moment = max(abs(crossprod(Z, w * (d$change_pp - X %*% beta)))))
)
jsonlite::write_json(result, "result.json", auto_unbox = TRUE, pretty = TRUE, digits = 16,
                     null = "null")
cat(paste(vapply(estimates, function(e) sprintf("%s = %.12f", e$term, e$estimate), ""), collapse = "\n"), "\n")
