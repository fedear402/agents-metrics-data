library(jsonlite)

dat <- read.csv("input.csv")
stopifnot(identical(names(dat), c("t", "y")),
          nrow(dat) == 250L,
          identical(as.integer(dat$t), seq_len(250L)),
          all(is.finite(dat$y)))

y <- as.numeric(dat$y)
fit <- stats::arima(y, order = c(1L, 1L, 1L),
                    include.mean = FALSE, method = "ML")
pred <- stats::predict(fit, n.ahead = 1L)
point <- as.numeric(pred$pred[1L])
forecast_se <- as.numeric(pred$se[1L])
critical <- stats::qnorm(0.975)

out <- list(
  task_id = "arima_forecast",
  platform = "r",
  estimates = list(
    list(term = "forecast", estimate = point, se = forecast_se,
         n_obs = length(y)),
    list(term = "lower_95", estimate = point - critical * forecast_se,
         se = NULL, n_obs = length(y)),
    list(term = "upper_95", estimate = point + critical * forecast_se,
         se = NULL, n_obs = length(y))
  ),
  method_metadata = list(estimator = "ARIMA(1,1,1) maximum likelihood, no drift",
                         vcov = "Gaussian model-based forecast variance"),
  diagnostics = structure(list(), names = character(0))
)
write_json(out, "result.json", auto_unbox = TRUE, digits = NA, null = "null")
