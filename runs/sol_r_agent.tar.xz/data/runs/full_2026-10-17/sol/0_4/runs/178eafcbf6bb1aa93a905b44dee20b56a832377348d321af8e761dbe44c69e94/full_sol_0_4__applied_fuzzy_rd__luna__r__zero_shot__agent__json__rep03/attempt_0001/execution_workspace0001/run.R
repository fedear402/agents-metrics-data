dat <- read.csv("input.csv")
required <- c("score", "participated", "earnings")
stopifnot(all(required %in% names(dat)))
keep <- is.finite(dat$score) & abs(dat$score) < 1 &
  is.finite(dat$participated) & is.finite(dat$earnings)
d <- dat[keep, , drop = FALSE]
n <- nrow(d)
stopifnot(n > 4, all(d$participated %in% c(0, 1)))
w <- 1 - abs(d$score)
right <- as.numeric(d$score >= 0)
X <- cbind(left_intercept = 1 - right, left_slope = d$score * (1 - right),
           right_intercept = right, right_slope = d$score * right)
Y <- as.matrix(d[, c("earnings", "participated")])
bread <- solve(crossprod(X, w * X))
beta <- bread %*% crossprod(X, w * Y)
resid <- Y - X %*% beta
cvec <- c(-1, 0, 1, 0)
jump <- as.numeric(cvec %*% beta)
influence <- (w * resid) * as.vector(X %*% bread %*% cvec)
cov_jump <- crossprod(influence)
rf <- jump[1]
fs <- jump[2]
effect <- rf / fs
gradient <- c(1 / fs, -rf / fs^2)
se <- c(sqrt(as.numeric(t(gradient) %*% cov_jump %*% gradient)),
        sqrt(cov_jump[1, 1]), sqrt(cov_jump[2, 2]))
stopifnot(all(is.finite(c(effect, rf, fs, se))), fs != 0)
terms <- c("treatment_effect", "reduced_form", "first_stage")
values <- c(effect, rf, fs)
fmt <- function(x) format(x, digits = 17, scientific = TRUE, trim = TRUE)
rows <- vapply(seq_along(terms), function(i) {
  sprintf('{"term":"%s","estimate":%s,"se":%s,"n_obs":%d}',
          terms[i], fmt(values[i]), fmt(se[i]), n)
}, character(1))
out <- paste0('{"task_id":"applied_fuzzy_rd","platform":"r","estimates":[',
              paste(rows, collapse = ","),
              '],"method_metadata":{"estimator":"triangular-weighted local linear fuzzy RD Wald ratio","vcov":"joint HC0 sandwich, fixed weights; delta method for ratio"},"diagnostics":{}}')
writeLines(out, "result.json")
