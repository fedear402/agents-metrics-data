dat <- read.csv("input.csv", stringsAsFactors = FALSE)
required <- c("region_id", "industry_id", "share", "shock", "region_weight", "x", "y")
stopifnot(all(required %in% names(dat)), all(complete.cases(dat[required])))
stopifnot(!anyDuplicated(dat[c("region_id", "industry_id")]))

regions <- sort(unique(dat$region_id))
industries <- sort(unique(dat$industry_id))
R <- length(regions)
N <- length(industries)
stopifnot(N > 2L, R > 2L)
ri <- match(dat$region_id, regions)
ni <- match(dat$industry_id, industries)
constant_within <- function(v, group) {
  all(v == v[match(group, group)])
}
stopifnot(constant_within(dat$region_weight, dat$region_id),
          constant_within(dat$x, dat$region_id),
          constant_within(dat$y, dat$region_id),
          constant_within(dat$shock, dat$industry_id))

S <- matrix(0, R, N)
S[cbind(ri, ni)] <- dat$share
stopifnot(all(dat$share >= 0), max(abs(rowSums(S) - 1)) < 1e-9)
first_region <- match(regions, dat$region_id)
first_industry <- match(industries, dat$industry_id)
e <- dat$region_weight[first_region]
stopifnot(all(e > 0))
e <- e / sum(e)
x <- dat$x[first_region]
y <- dat$y[first_region]
shock <- dat$shock[first_industry]
z <- drop(S %*% shock)

regional <- cbind(y = y, x = x, z = z)
centered <- sweep(regional, 2, drop(crossprod(e, regional)))
mass <- drop(crossprod(e, S))
stopifnot(all(mass > 0), abs(sum(mass) - 1) < 1e-10)
aggregated <- sweep(crossprod(S, e * centered), 1, mass, "/")
stopifnot(max(abs(drop(crossprod(mass, aggregated)))) < 1e-10)

shock_iv <- function(dependent, endogenous) {
  X <- cbind(intercept = 1, endogenous = endogenous)
  Z <- cbind(intercept = 1, shock = shock)
  cross <- crossprod(Z, mass * X)
  inverse <- solve(cross)
  beta <- drop(inverse %*% crossprod(Z, mass * dependent))
  residual <- drop(dependent - X %*% beta)
  scores <- Z * as.vector(mass * residual)
  vcov <- (N / (N - 2)) * inverse %*% crossprod(scores) %*% t(inverse)
  c(estimate = beta[2], se = sqrt(vcov[2, 2]))
}

effect <- shock_iv(aggregated[, "y"], aggregated[, "x"])
first_stage <- shock_iv(aggregated[, "x"], aggregated[, "z"])
regional_effect <- sum(e * centered[, "z"] * centered[, "y"]) /
  sum(e * centered[, "z"] * centered[, "x"])
regional_first_stage <- sum(e * centered[, "z"] * centered[, "x"]) /
  sum(e * centered[, "z"]^2)
stopifnot(max(abs(c(effect[1] - regional_effect,
                    first_stage[1] - regional_first_stage))) < 1e-9)

row <- function(term, estimate, se = NULL) {
  list(term = term, estimate = unname(as.numeric(estimate)),
       se = if (is.null(se)) NULL else unname(as.numeric(se)), n_obs = N)
}
result <- list(
  task_id = "applied_shift_share", platform = "r",
  estimates = list(row("effect", effect[1], effect[2]),
                   row("first_stage", first_stage[1], first_stage[2]),
                   row("effective_shocks", 1 / sum(mass^2))),
  method_metadata = list(
    estimator = "Regional weighted just-identified 2SLS; BHJ shock-level weighted IV",
    vcov = "Shock-level heteroskedasticity-robust HC1, structural IV scores, N/(N-2)"),
  diagnostics = jsonlite::parse_json("{}")
)
jsonlite::write_json(result, "result.json", auto_unbox = TRUE,
                     null = "null", digits = 16, pretty = TRUE)
