crosswalk <- read.csv('crosswalk.csv', stringsAsFactors = FALSE)
trade <- read.csv('trade.csv', stringsAsFactors = FALSE)
areas <- read.csv('areas.csv', stringsAsFactors = FALSE)
employment <- read.csv('employment.csv', stringsAsFactors = FALSE)
outcomes <- read.csv('outcomes.csv', stringsAsFactors = FALSE)

stopifnot(nrow(outcomes) == 72L, length(unique(crosswalk$industry)) == 4L)
trade <- merge(trade, crosswalk, by = 'code', sort = FALSE)
stopifnot(nrow(trade) == 4L * length(unique(trade$period)))

grid <- merge(areas, data.frame(industry = sort(unique(crosswalk$industry))), by = NULL)
cells <- merge(grid, employment, by = c('area','period','vintage','industry'),
               all.x = TRUE, sort = FALSE)
stopifnot(nrow(cells) == nrow(grid))
cells$employment[is.na(cells$employment)] <- 0
national <- aggregate(employment ~ period + vintage + industry, cells, sum)
names(national)[4] <- 'national_employment'
cells <- merge(cells, national, by = c('period','vintage','industry'), sort = FALSE)
stopifnot(all(cells$national_employment > 0))
cells <- merge(cells, trade[c('period','industry','us_change','other_change',
                              'price_index','years')], by = c('period','industry'), sort = FALSE)
cells$amount <- ifelse(cells$vintage == 'base', cells$us_change, cells$other_change)
cells$contribution <- (cells$employment / cells$total_employment) *
  (cells$amount / cells$national_employment) /
  (cells$price_index / 100) / 1000 * (10 / cells$years)
exposure <- aggregate(contribution ~ area + period + vintage, cells, sum)
base <- subset(exposure, vintage == 'base', select = c(area,period,contribution))
early <- subset(exposure, vintage == 'early', select = c(area,period,contribution))
names(base)[3] <- 'x'
names(early)[3] <- 'z'
sample <- merge(merge(outcomes, base, by = c('area','period')),
                early, by = c('area','period'))
weights <- subset(areas, vintage == 'base', select = c(area,period,population))
sample <- merge(sample, weights, by = c('area','period'))
stopifnot(nrow(sample) == 72L, !anyNA(sample), all(sample$population > 0))

C <- cbind(intercept = 1, period = sample$period, control = sample$control)
X <- cbind(C, x = sample$x) * sqrt(sample$population)
Z <- cbind(C, z = sample$z) * sqrt(sample$population)
y <- sample$change_pp * sqrt(sample$population)
fitted_X <- qr.fitted(qr(Z), X)
slope <- unname(qr.coef(qr(fitted_X), y)['x'])

# Independent exactly identified IV check after weighted partialling-out.
wc <- C * sqrt(sample$population)
rx <- qr.resid(qr(wc), sample$x * sqrt(sample$population))
rz <- qr.resid(qr(wc), sample$z * sqrt(sample$population))
ry <- qr.resid(qr(wc), y)
check_slope <- sum(rz * ry) / sum(rz * rx)
stopifnot(is.finite(slope), abs(slope - check_slope) < 1e-9)

value <- function(a, p, column) sample[sample$area == a & sample$period == p, column]
stopifnot(length(value(0,0,'x')) == 1L, length(value(0,1,'x')) == 1L)
terms <- c('iv_slope','exposure_area0_period0','exposure_area0_period1',
           'instrument_area0_period0')
values <- c(slope, value(0,0,'x'), value(0,1,'x'), value(0,0,'z'))
estimates <- lapply(seq_along(terms), function(i) list(
  term = terms[i], estimate = unname(values[i]), se = NULL, n_obs = 72L))
result <- list(task_id = 'applied_multivintage_trade_iv', platform = 'r',
               estimates = estimates,
               method_metadata = list(estimator = 'weighted 2SLS',
                 regressors = c('intercept','period','control','x'),
                 instruments = c('intercept','period','control','z'),
                 weight = 'base-vintage population',
                 exposure_units = 'thousands of real dollars per worker per decade'),
               diagnostics = list(n_obs = 72L,
                 independent_iv_slope = check_slope,
                 slope_check_absolute_difference = abs(slope - check_slope),
                 missing_employment_cells = sum(is.na(merge(grid, employment,
                   by = c('area','period','vintage','industry'), all.x = TRUE)$employment))))
jsonlite::write_json(result, 'result.json', auto_unbox = TRUE, pretty = TRUE, digits = 15,
                     null = 'null')
