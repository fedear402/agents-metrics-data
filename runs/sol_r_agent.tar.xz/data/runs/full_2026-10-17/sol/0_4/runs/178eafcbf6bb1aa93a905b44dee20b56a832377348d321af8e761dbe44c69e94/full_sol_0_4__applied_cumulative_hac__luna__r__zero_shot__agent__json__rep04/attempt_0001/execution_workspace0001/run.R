dat <- read.csv("input.csv", stringsAsFactors = FALSE)
stopifnot(identical(names(dat), c("date", "sales", "vix")))
stopifnot(all(is.finite(dat$sales)), all(dat$sales > 0),
          all(is.finite(dat$vix)), all(dat$vix > 0))
dat <- dat[order(as.Date(dat$date)), ]
stopifnot(!anyDuplicated(dat$date))

T <- nrow(dat)
dv <- c(NA_real_, diff(log(dat$vix)))
lagged <- sapply(1:15, function(k) {
  z <- rep(NA_real_, T)
  z[(k + 1):T] <- dv[1:(T - k)]
  z
})
colnames(lagged) <- paste0("lag_", 1:15)
complete <- complete.cases(lagged)
X <- cbind("(Intercept)" = 1, lagged[complete, , drop = FALSE])
y <- log(dat$sales[complete])
N <- length(y)
p <- ncol(X)
stopifnot(p == 16L, N > p, identical(which(complete), 17:T))

# OLS and the requested finite-sample adjusted Bartlett HAC covariance.
beta <- as.vector(qr.solve(X, y))
names(beta) <- colnames(X)
resid <- as.vector(y - X %*% beta)
scores <- X * resid
meat <- crossprod(scores)
for (j in 1:15) {
  cross_j <- crossprod(scores[(j + 1):N, , drop = FALSE],
                       scores[1:(N - j), , drop = FALSE])
  meat <- meat + (1 - j / 16) * (cross_j + t(cross_j))
}
bread <- solve(crossprod(X))
V <- (N / (N - 16)) * bread %*% meat %*% bread
sel <- 2:16
cum_est <- sum(beta[sel])
cum_se <- sqrt(sum(V[sel, sel]))

# An independent package implementation checks the full coefficient covariance.
fit <- lm.fit(X, y)
stopifnot(max(abs(fit$coefficients - beta)) < 1e-9)
if (requireNamespace("sandwich", quietly = TRUE)) {
  check_fit <- lm(y ~ lagged[complete, , drop = FALSE])
  V_check <- sandwich::NeweyWest(check_fit, lag = 15, prewhite = FALSE,
                                 adjust = TRUE)
  covariance_error <- max(abs(unname(V) - unname(V_check)))
  stopifnot(covariance_error < 1e-8)
  check_text <- sprintf("Independent sandwich::NeweyWest covariance maximum absolute difference: %.12g", covariance_error)
} else {
  # Direct linear-model normal equations are independent of qr.solve.
  beta_check <- solve(crossprod(X), crossprod(X, y))
  check_error <- max(abs(beta - beta_check))
  stopifnot(check_error < 1e-9)
  check_text <- sprintf("Independent normal-equation coefficient maximum absolute difference: %.12g", check_error)
}

fmt <- function(x) sprintf("%.15g", x)
record <- function(term, estimate, se) {
  sprintf('{"term":"%s","estimate":%s,"se":%s,"n_obs":%d}',
          term, fmt(estimate), fmt(se), N)
}
records <- c(record("cumulative_response", cum_est, cum_se),
             record("lag_1", beta["lag_1"], sqrt(V[2, 2])),
             record("lag_15", beta["lag_15"], sqrt(V[16, 16])))
json <- paste0('{"task_id":"applied_cumulative_hac","platform":"r",',
               '"estimates":[', paste(records, collapse = ","), '],',
               '"method_metadata":{"estimator":"OLS with intercept and 15 lagged log VIX changes",',
               '"vcov":"Newey-West Bartlett HAC, max lag 15, N/(N-16) adjustment"},',
               '"diagnostics":{}}')
writeLines(json, "result.json")
writeLines(c(
  sprintf("Input rows: %d. Date order checked and sorted; dates are unique.", T),
  sprintf("Change at row t is log(vix[t]) - log(vix[t-1]); lag k at row t uses change at row t-k."),
  sprintf("Complete regression rows: 17 through %d; N = %d; regressors including intercept = %d.", T, N, p),
  "OLS uses log(sales) and all 15 lagged changes.",
  "HAC uses Bartlett weights 1-j/16 for j=1,...,15 and multiplies covariance by N/(N-16).",
  sprintf("Cumulative estimate: %s; standard error from all 15 by 15 covariance entries: %s.",
          fmt(cum_est), fmt(cum_se)),
  sprintf("Independent QR versus lm.fit coefficient maximum absolute difference: %.12g.",
          max(abs(fit$coefficients - beta))),
  check_text
), "verification.txt")
