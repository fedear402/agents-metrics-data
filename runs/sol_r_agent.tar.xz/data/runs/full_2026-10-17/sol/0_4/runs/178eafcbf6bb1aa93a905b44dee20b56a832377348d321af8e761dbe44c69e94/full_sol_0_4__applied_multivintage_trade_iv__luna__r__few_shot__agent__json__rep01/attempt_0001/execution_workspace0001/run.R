crosswalk <- read.csv('crosswalk.csv')
trade <- read.csv('trade.csv')
areas <- read.csv('areas.csv')
employment <- read.csv('employment.csv')
outcomes <- read.csv('outcomes.csv')

stopifnot(length(unique(crosswalk$industry)) == 4L,
          !anyDuplicated(crosswalk$code))
trade <- merge(trade, crosswalk, by = 'code', sort = FALSE)
stopifnot(nrow(trade) == 8L, !anyDuplicated(trade[c('period', 'industry')]))
stopifnot(!anyDuplicated(areas[c('area', 'period', 'vintage')]))
stopifnot(!anyDuplicated(employment[c('area', 'period', 'vintage', 'industry')]))

grid <- merge(areas, trade, by = 'period', sort = FALSE)
cells <- merge(grid, employment,
               by = c('area', 'period', 'vintage', 'industry'),
               all.x = TRUE, sort = FALSE)
stopifnot(nrow(cells) == nrow(grid))
cells$employment[is.na(cells$employment)] <- 0
national <- aggregate(employment ~ period + vintage + industry,
                      data = cells, FUN = sum)
names(national)[4] <- 'national_employment'
cells <- merge(cells, national,
               by = c('period', 'vintage', 'industry'), sort = FALSE)
stopifnot(all(cells$national_employment > 0), all(cells$total_employment > 0))
cells$exposure_part <- with(cells,
  employment / total_employment *
  ifelse(vintage == 'base', us_change, other_change) /
  national_employment / (price_index / 100) / 1000 * (10 / years))
exposure <- aggregate(exposure_part ~ area + period + vintage,
                      data = cells, FUN = sum)
wide <- reshape(exposure, idvar = c('area', 'period'),
                timevar = 'vintage', direction = 'wide')
names(wide)[names(wide) == 'exposure_part.base'] <- 'x'
names(wide)[names(wide) == 'exposure_part.early'] <- 'z'
base_areas <- areas[areas$vintage == 'base', c('area', 'period', 'population')]
d <- merge(outcomes, base_areas, by = c('area', 'period'))
d <- merge(d, wide, by = c('area', 'period'))
stopifnot(nrow(d) == 72L, !anyNA(d), all(d$population > 0))

X <- cbind(intercept = 1, period = d$period, control = d$control, x = d$x)
Z <- cbind(intercept = 1, period = d$period, control = d$control, z = d$z)
sw <- sqrt(d$population)
Xw <- X * sw
Zw <- Z * sw
yw <- d$change_pp * sw
beta <- solve(crossprod(Zw, Xw), crossprod(Zw, yw))

value <- function(area, period, column) {
  row <- d[d$area == area & d$period == period, ]
  stopifnot(nrow(row) == 1L)
  row[[column]]
}
terms <- c('iv_slope', 'exposure_area0_period0',
           'exposure_area0_period1', 'instrument_area0_period0')
values <- c(unname(beta['x', 1]), value(0, 0, 'x'),
            value(0, 1, 'x'), value(0, 0, 'z'))
estimates <- lapply(seq_along(terms), function(i)
  list(term = terms[i], estimate = values[i], se = NULL, n_obs = 72L))
result <- list(
  task_id = 'applied_multivintage_trade_iv', platform = 'r',
  estimates = estimates,
  method_metadata = list(estimator = 'weighted 2SLS',
    outcome = 'change_pp', endogenous = 'x', excluded_instrument = 'z',
    exogenous = c('intercept', 'period', 'control'),
    weight = 'base-vintage population',
    exposure_unit = 'thousands of real dollars per worker per decade'),
  diagnostics = list(estimation_rows = nrow(d),
    industries = length(unique(crosswalk$industry)),
    missing_employment_cells_filled = sum(is.na(merge(grid, employment,
      by = c('area', 'period', 'vintage', 'industry'), all.x = TRUE)$employment))))
jsonlite::write_json(result, 'result.json', auto_unbox = TRUE,
                     pretty = TRUE, digits = 16, null = 'null')
cat(sprintf('iv_slope=%.12f; x00=%.12f; x01=%.12f; z00=%.12f\n',
            values[1], values[2], values[3], values[4]))
