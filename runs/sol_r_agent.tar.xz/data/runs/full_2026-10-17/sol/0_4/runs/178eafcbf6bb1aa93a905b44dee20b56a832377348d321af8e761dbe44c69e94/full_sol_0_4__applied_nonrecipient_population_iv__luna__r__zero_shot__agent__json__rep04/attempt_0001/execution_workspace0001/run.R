library(jsonlite)

h <- read.csv("households.csv")
census <- read.csv("census.csv")
s <- h[h$recipient == 0, ]
stopifnot(nrow(s) > 0, all(s$eligible %in% 0:1), all(s$weight > 0),
          setequal(census$eligible, 0:1), !anyNA(s[, c("eligible", "dose", "instrument", "baseline", "weight", "outcome")]))

g0 <- 1 - s$eligible
g1 <- s$eligible
X <- cbind(g0, g1, s$baseline * g0, s$baseline * g1,
           s$dose * g0, s$dose * g1)
Z <- cbind(X[, 1:4, drop = FALSE], s$instrument * g0,
           s$instrument * g1)
w <- s$weight
ZX <- crossprod(Z, X * w)
ZZ <- crossprod(Z, Z * w)
Zy <- crossprod(Z, s$outcome * w)
beta <- as.vector(solve(t(ZX) %*% solve(ZZ, ZX),
                        t(ZX) %*% solve(ZZ, Zy)))

mean_dose <- vapply(0:1, function(g) {
  rows <- s$eligible == g
  weighted.mean(s$dose[rows], s$weight[rows])
}, numeric(1))
effects <- beta[5:6] * mean_dose
pop <- census$nonrecipient_population[match(0:1, census$eligible)]
stopifnot(all(is.finite(beta)), all(pop >= 0), sum(pop) > 0)
population_effect <- sum(effects * pop) / sum(pop)

terms <- c("ineligible_effect", "eligible_nonrecipient_effect", "population_effect")
values <- c(effects, population_effect)
estimates <- lapply(seq_along(terms), function(i) {
  list(term = terms[i], estimate = unname(values[i]), se = NA_real_,
       n_obs = as.integer(nrow(s)))
})
result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "weighted 2SLS",
    sample = "recipient == 0",
    counterfactual = "dose set to zero for every retained household",
    group_effect = "group dose slope times household-weighted mean dose",
    population_aggregation = "nonrecipient_population census weights"
  ),
  diagnostics = list(
    n_obs = as.integer(nrow(s)),
    n_ineligible = as.integer(sum(g0)),
    n_eligible = as.integer(sum(g1)),
    n_ineligible_treated = as.integer(sum(g0 == 1 & s$treated == 1)),
    n_ineligible_untreated = as.integer(sum(g0 == 1 & s$treated == 0)),
    group_mean_dose = unname(mean_dose),
    group_dose_slope = unname(beta[5:6]),
    matrix_rank_X = as.integer(qr(X)$rank),
    matrix_rank_Z = as.integer(qr(Z)$rank)
  )
)
write_json(result, "result.json", pretty = TRUE, auto_unbox = TRUE, na = "null", digits = 15)
