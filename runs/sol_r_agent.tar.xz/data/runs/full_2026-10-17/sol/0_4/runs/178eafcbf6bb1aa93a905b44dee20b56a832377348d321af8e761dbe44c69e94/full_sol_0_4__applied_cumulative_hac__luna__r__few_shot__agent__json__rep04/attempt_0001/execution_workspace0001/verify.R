library(sandwich)
library(jsonlite)
d <- read.csv("input.csv")
d <- d[order(as.Date(d$date)), ]
m <- nrow(d)
idx <- 17:m
z <- diff(log(d$vix))
lags <- as.data.frame(sapply(1:15, function(k) z[idx - k - 1]))
names(lags) <- paste0("lag_", 1:15)
dat <- data.frame(y = log(d$sales[idx]), lags)
fit <- lm(y ~ ., data = dat)
V <- NeweyWest(fit, lag = 15, prewhite = FALSE, adjust = TRUE)
out <- fromJSON("result.json")$estimates
contrast <- c(0, rep(1, 15))
checks <- c(
  n_obs = nobs(fit) == 704 && all(out$n_obs == 704),
  first_lag = isTRUE(all.equal(lags$lag_1[1], log(d$vix[16]) - log(d$vix[15]))),
  last_lag = isTRUE(all.equal(lags$lag_15[1], log(d$vix[2]) - log(d$vix[1]))),
  cumulative = abs(sum(coef(fit)[-1]) - out$estimate[1]) < 1e-10,
  cumulative_se = abs(sqrt(drop(t(contrast) %*% V %*% contrast)) - out$se[1]) < 1e-10,
  lag_1 = abs(coef(fit)[2] - out$estimate[2]) < 1e-10,
  lag_1_se = abs(sqrt(V[2, 2]) - out$se[2]) < 1e-10,
  lag_15 = abs(coef(fit)[16] - out$estimate[3]) < 1e-10,
  lag_15_se = abs(sqrt(V[16, 16]) - out$se[3]) < 1e-10
)
print(checks)
stopifnot(all(checks))
