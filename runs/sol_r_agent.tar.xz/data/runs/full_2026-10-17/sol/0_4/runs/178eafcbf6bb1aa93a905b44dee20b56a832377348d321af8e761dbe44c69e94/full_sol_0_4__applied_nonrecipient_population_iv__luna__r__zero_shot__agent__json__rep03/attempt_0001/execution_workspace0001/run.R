h <- read.csv('households.csv')
census <- read.csv('census.csv')
stopifnot(all(c('eligible','recipient','instrument','dose','baseline','weight','outcome') %in% names(h)))
stopifnot(all(c('eligible','nonrecipient_population') %in% names(census)))
d <- h[h$recipient == 0 & complete.cases(h[,c('eligible','recipient','instrument','dose','baseline','weight','outcome')]), ]
stopifnot(all(d$eligible %in% 0:1), all(d$weight > 0), identical(sort(census$eligible), 0:1), nrow(d) > 0)
g0 <- 1 - d$eligible
g1 <- d$eligible
X <- cbind(g0, g1, d$baseline*g0, d$baseline*g1, d$dose*g0, d$dose*g1)
Z <- cbind(g0, g1, d$baseline*g0, d$baseline*g1, d$instrument*g0, d$instrument*g1)
w <- d$weight
y <- d$outcome
# Exactly identified weighted 2SLS: solve the weighted instrument normal equations.
stopifnot(qr(Z * sqrt(w))$rank == ncol(Z), qr(X * sqrt(w))$rank == ncol(X))
beta <- as.vector(solve(crossprod(Z, X*w), crossprod(Z, y*w)))
means <- c(weighted.mean(d$dose[g0 == 1], w[g0 == 1]), weighted.mean(d$dose[g1 == 1], w[g1 == 1]))
effects <- beta[5:6] * means
pop <- census$nonrecipient_population[match(0:1, census$eligible)]
stopifnot(all(pop > 0))
pop_effect <- sum(effects * pop)/sum(pop)
# Independent numerical check: separate weighted first stages and second stages.
fit_group <- function(group) {
  s <- d$eligible == group
  first <- lm(d$dose[s] ~ d$baseline[s] + d$instrument[s], weights=w[s])
  predicted <- fitted(first)
  second <- lm(d$outcome[s] ~ d$baseline[s] + predicted, weights=w[s])
  unname(coef(second)[3])
}
check_slopes <- vapply(0:1, fit_group, numeric(1))
stopifnot(isTRUE(all.equal(beta[5:6], check_slopes, tolerance=1e-10)))
stopifnot(max(abs(as.vector(crossprod(Z, w*(y-X%*%beta))))) < 1e-7)
terms <- c('ineligible_effect','eligible_nonrecipient_effect','population_effect')
values <- c(effects, pop_effect)
estimates <- lapply(seq_along(terms), function(i) list(term=terms[i], estimate=unname(values[i]), se=NULL, n_obs=as.integer(nrow(d))))
result <- list(task_id='applied_nonrecipient_population_iv', platform='r', estimates=estimates,
  method_metadata=list(estimator='weighted 2SLS', sample='recipient=0, complete required variables', counterfactual='dose=0 for each retained household; synthetic attribution convention', group_average='household-weighted mean dose within retained eligibility group', population_average='census nonrecipient_population weights', standard_error='not requested'),
  diagnostics=list(n_obs=as.integer(nrow(d)), group_n_obs=as.integer(c(sum(g0),sum(g1))), group_weighted_mean_dose=unname(means), group_dose_slopes=unname(beta[5:6]), independent_slope_check=unname(check_slopes), max_weighted_moment_residual=max(abs(as.vector(crossprod(Z, w*(y-X%*%beta)))))))
jsonlite::write_json(result, 'result.json', auto_unbox=TRUE, pretty=TRUE, digits=16, null='null')
cat(sprintf('n=%d; slopes=%.12f, %.12f; means=%.12f, %.12f; effects=%.12f, %.12f, %.12f\n', nrow(d), beta[5], beta[6], means[1], means[2], values[1], values[2], values[3]))
