library(jsonlite)

h <- read.csv("households.csv")
census <- read.csv("census.csv")
d <- h[h$recipient == 0, , drop = FALSE]
stopifnot(nrow(d) > 0L, all(d$eligible %in% 0:1),
          all(d$weight > 0), all(0:1 %in% census$eligible),
          !anyNA(d[, c("eligible", "dose", "instrument", "baseline", "weight", "outcome")]))

g0 <- as.numeric(d$eligible == 0)
g1 <- as.numeric(d$eligible == 1)
C <- cbind(g0, g1, d$baseline * g0, d$baseline * g1)
X <- cbind(C, d$dose * g0, d$dose * g1)
Z <- cbind(C, d$instrument * g0, d$instrument * g1)
sw <- sqrt(d$weight)
Xw <- X * sw
Zw <- Z * sw
yw <- d$outcome * sw
first_stage <- qr.fitted(qr(Zw), Xw)
beta <- as.numeric(qr.coef(qr(first_stage), yw))
stopifnot(length(beta) == 6L, all(is.finite(beta)))

mean_dose <- vapply(0:1, function(g) {
  i <- d$eligible == g
  weighted.mean(d$dose[i], d$weight[i])
}, numeric(1))
effects <- beta[5:6] * mean_dose
pop <- census$nonrecipient_population[match(0:1, census$eligible)]
population_effect <- weighted.mean(effects, pop)

# Independent, exactly identified weighted IV moment calculation.
beta_moments <- as.numeric(solve(crossprod(Zw, Xw), crossprod(Zw, yw)))
check_difference <- max(abs(beta - beta_moments))
stopifnot(check_difference < 1e-9)

terms <- c("ineligible_effect", "eligible_nonrecipient_effect", "population_effect")
values <- c(effects, population_effect)
estimates <- lapply(seq_along(terms), function(i) {
  list(term = terms[i], estimate = unname(values[i]), se = NULL, n_obs = nrow(d))
})
result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "weighted 2SLS",
    sample = "recipient == 0",
    endogenous = c("dose*(1-eligible)", "dose*eligible"),
    exogenous = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"),
    excluded_instruments = c("instrument*(1-eligible)", "instrument*eligible"),
    counterfactual_dose = 0,
    group_mean_weight = "household weight",
    population_weight = "nonrecipient_population"
  ),
  diagnostics = list(
    n_obs = nrow(d),
    group_n_obs = as.integer(table(factor(d$eligible, levels = 0:1))),
    dose_slopes = unname(beta[5:6]),
    weighted_mean_dose = unname(mean_dose),
    census_weights = unname(pop),
    maximum_coefficient_difference_from_weighted_iv_moments = check_difference
  )
)
write_json(result, "result.json", auto_unbox = TRUE, pretty = TRUE, digits = 16, null = "null")
