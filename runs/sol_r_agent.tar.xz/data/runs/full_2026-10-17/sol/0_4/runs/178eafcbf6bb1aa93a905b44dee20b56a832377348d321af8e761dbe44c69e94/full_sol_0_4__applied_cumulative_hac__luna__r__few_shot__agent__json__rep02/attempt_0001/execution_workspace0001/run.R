data <- read.csv("input.csv", stringsAsFactors = FALSE)
stopifnot(identical(names(data), c("date", "sales", "vix")))
data$date <- as.Date(data$date)
stopifnot(!anyNA(data$date), !anyDuplicated(data$date),
          all(is.finite(data$sales)), all(data$sales > 0),
          all(is.finite(data$vix)), all(data$vix > 0))
data <- data[order(data$date), ]
n_total <- nrow(data)
change <- c(NA_real_, diff(log(data$vix)))
lagged <- sapply(1:15, function(k) c(rep(NA_real_, k), head(change, -k)))
colnames(lagged) <- paste0("lag_", 1:15)
usable <- complete.cases(lagged)
stopifnot(identical(which(usable), seq.int(17L, n_total)))
y <- log(data$sales[usable])
X <- cbind("(Intercept)" = 1, lagged[usable, , drop = FALSE])
N <- nrow(X)
p <- ncol(X)
stopifnot(p == 16L, N == n_total - 16L, N > p)
fit <- lm.fit(X, y)
beta <- fit$coefficients
stopifnot(!anyNA(beta), fit$rank == p)
scores <- X * as.vector(fit$residuals)
meat <- crossprod(scores)
for (j in 1:15) {
  cross_lag <- crossprod(scores[(j + 1):N, , drop = FALSE],
                         scores[1:(N - j), , drop = FALSE])
  meat <- meat + (1 - j / 16) * (cross_lag + t(cross_lag))
}
bread <- solve(crossprod(X))
V <- (N / (N - p)) * bread %*% meat %*% bread
contrast <- c(0, rep(1, 15))
est <- sum(beta[-1])
se <- sqrt(drop(t(contrast) %*% V %*% contrast))

# Independent checks: explicit date-index construction, OLS normal equations,
# and scalar Bartlett covariance for the cumulative contrast.
X_check <- cbind(1, vapply(1:15, function(k) {
  log(data$vix[17:n_total - k]) - log(data$vix[16:(n_total - 1) - k])
}, numeric(N)))
stopifnot(isTRUE(all.equal(unname(X), unname(X_check), tolerance = 1e-12)))
beta_check <- solve(crossprod(X_check), crossprod(X_check, y))
stopifnot(max(abs(beta - beta_check)) < 1e-8)
influence <- as.vector(scores %*% (bread %*% contrast))
variance_check <- sum(influence^2)
for (j in 1:15) {
  variance_check <- variance_check + 2 * (1 - j / 16) *
    sum(influence[(j + 1):N] * influence[1:(N - j)])
}
variance_check <- variance_check * N / (N - p)
stopifnot(isTRUE(all.equal(se^2, variance_check, tolerance = 1e-9)))

row <- function(term, estimate, standard_error) {
  list(term = term, estimate = unname(as.numeric(estimate)),
       se = unname(as.numeric(standard_error)), n_obs = as.integer(N))
}
result <- list(
  task_id = "applied_cumulative_hac", platform = "r",
  estimates = list(
    row("cumulative_response", est, se),
    row("lag_1", beta[2], sqrt(V[2, 2])),
    row("lag_15", beta[16], sqrt(V[16, 16]))),
  method_metadata = list(estimator = "OLS with intercept and 15 observed-row lags of log VIX change",
                         vcov = "Bartlett Newey-West, maximum lag 15, N/(N-16) correction"),
  diagnostics = structure(list(), names = character(0)))
jsonlite::write_json(result, "result.json", auto_unbox = TRUE,
                     digits = 16, pretty = TRUE)
cat(sprintf("total=%d usable=%d first=%s last=%s max_X_diff=%.3g max_beta_diff=%.3g variance_diff=%.3g\n",
            n_total, N, as.character(min(data$date[usable])),
            as.character(max(data$date[usable])),
            max(abs(X - X_check)), max(abs(beta - beta_check)),
            abs(se^2 - variance_check)))
