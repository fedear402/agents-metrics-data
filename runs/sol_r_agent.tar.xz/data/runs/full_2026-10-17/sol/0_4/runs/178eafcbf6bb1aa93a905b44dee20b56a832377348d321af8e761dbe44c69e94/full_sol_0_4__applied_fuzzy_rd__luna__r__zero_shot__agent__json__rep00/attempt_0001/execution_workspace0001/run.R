data <- read.csv("input.csv")
required <- c("score", "participated", "earnings")
stopifnot(all(required %in% names(data)))
sample <- data[!is.na(data$score) & abs(data$score) < 1, ]
stopifnot(nrow(sample) > 0, all(complete.cases(sample[, required])))
x <- sample$score
right <- as.numeric(x >= 0)
w <- 1 - abs(x)
X <- cbind(left_intercept = 1 - right, left_slope = x * (1 - right),
           right_intercept = right, right_slope = x * right)
Y <- as.matrix(sample[, c("earnings", "participated")])
XWX_inv <- solve(crossprod(X, w * X))
B <- XWX_inv %*% crossprod(X, w * Y)
U <- Y - X %*% B
contrast <- c(-1, 0, 1, 0)
discontinuities <- as.numeric(contrast %*% B)
influence <- as.numeric(X %*% XWX_inv %*% contrast) * w
scores <- U * influence
V <- crossprod(scores)
rf <- discontinuities[1]
fs <- discontinuities[2]
stopifnot(abs(fs) > .Machine$double.eps)
effect <- rf / fs
gradient <- c(1 / fs, -rf / fs^2)
se <- c(sqrt(as.numeric(t(gradient) %*% V %*% gradient)),
        sqrt(V[1, 1]), sqrt(V[2, 2]))
stopifnot(all(is.finite(c(effect, rf, fs, se))))
n <- nrow(sample)
results <- list(
  list(term = "treatment_effect", estimate = effect, se = se[1], n_obs = n),
  list(term = "reduced_form", estimate = rf, se = se[2], n_obs = n),
  list(term = "first_stage", estimate = fs, se = se[3], n_obs = n)
)
output <- list(task_id = "applied_fuzzy_rd", platform = "r",
               estimates = results,
               method_metadata = list(estimator = "fuzzy local-linear RD, triangular kernel, bandwidth 1",
                                      vcov = "joint fixed-weight HC0 sandwich; delta method"),
               diagnostics = list())
if (!requireNamespace("jsonlite", quietly = TRUE)) stop("jsonlite is required")
json <- jsonlite::toJSON(output, auto_unbox = TRUE, digits = 16, pretty = TRUE)
json <- sub('"diagnostics": []', '"diagnostics": {}', json, fixed = TRUE)
writeLines(json, "result.json")
