dat <- read.csv("input.csv", stringsAsFactors = FALSE)
stopifnot(identical(names(dat), c("date", "sales", "vix")),
          all(is.finite(dat$sales) & dat$sales > 0),
          all(is.finite(dat$vix) & dat$vix > 0))
dat <- dat[order(as.Date(dat$date)), ]
stopifnot(!anyDuplicated(dat$date))

change <- c(NA_real_, diff(log(dat$vix)))
lags <- sapply(1:15, function(k) {
  c(rep(NA_real_, k), head(change, -k))
})
colnames(lags) <- paste0("lag_", 1:15)
complete <- complete.cases(lags, dat$sales)
X <- cbind("(Intercept)" = 1, lags[complete, , drop = FALSE])
y <- log(dat$sales[complete])
N <- length(y)
p <- ncol(X)
stopifnot(N == nrow(dat) - 16L, p == 16L)

fit <- lm.fit(X, y)
b <- fit$coefficients
u <- fit$residuals
bread <- solve(crossprod(X))
scores <- X * as.numeric(u)
meat <- crossprod(scores)
for (j in 1:15) {
  cross_j <- crossprod(scores[(j + 1):N, , drop = FALSE],
                       scores[1:(N - j), , drop = FALSE])
  meat <- meat + (1 - j / 16) * (cross_j + t(cross_j))
}
V <- (N / (N - 16)) * bread %*% meat %*% bread
terms <- paste0("lag_", 1:15)
sum_est <- sum(b[terms])
sum_se <- sqrt(sum(V[terms, terms]))

output <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(term = "cumulative_response", estimate = unname(sum_est), se = unname(sum_se), n_obs = N),
    list(term = "lag_1", estimate = unname(b["lag_1"]), se = unname(sqrt(V["lag_1", "lag_1"])), n_obs = N),
    list(term = "lag_15", estimate = unname(b["lag_15"]), se = unname(sqrt(V["lag_15", "lag_15"])), n_obs = N)
  ),
  method_metadata = list(estimator = "OLS with intercept and 15 lagged log VIX changes",
                         vcov = "Newey-West HAC, Bartlett lag 15, multiplied by N/(N-16)"),
  diagnostics = list()
)
jsonlite::write_json(output, "result.json", auto_unbox = TRUE, digits = 16, pretty = TRUE)

# Independent package calculation for verification.
lm_check <- lm(y ~ lags[complete, , drop = FALSE])
V_check <- sandwich::NeweyWest(lm_check, lag = 15, prewhite = FALSE, adjust = FALSE)
V_check <- V_check * N / (N - 16)
stopifnot(max(abs(unname(coef(lm_check)) - unname(b))) < 1e-10,
          max(abs(unname(V_check) - unname(V))) < 1e-10)
cat(sprintf("rows=%d, first_date=%s, last_date=%s\n", N,
            dat$date[which(complete)[1]], tail(dat$date, 1)))
cat(sprintf("max coefficient difference=%.3g; max covariance difference=%.3g\n",
            max(abs(unname(coef(lm_check)) - unname(b))),
            max(abs(unname(V_check) - unname(V)))))
