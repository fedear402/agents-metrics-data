# Weighted two-stage least squares for nonrecipient households.
suppressPackageStartupMessages(library(jsonlite))
d <- read.csv("households.csv")
census <- read.csv("census.csv")
stopifnot(all(c("eligible", "recipient", "instrument", "dose", "baseline", "weight", "outcome") %in% names(d)))
stopifnot(all(c("eligible", "nonrecipient_population") %in% names(census)))
d <- d[d$recipient == 0, , drop = FALSE]
stopifnot(nrow(d) > 0L, !anyNA(d[, c("eligible", "instrument", "dose", "baseline", "weight", "outcome")]))
stopifnot(all(d$eligible %in% 0:1), all(d$weight > 0), all(0:1 %in% d$eligible))
stopifnot(nrow(census) == 2L, setequal(census$eligible, 0:1), all(census$nonrecipient_population > 0))
g0 <- 1 - d$eligible
g1 <- d$eligible
C <- cbind(g0, g1, d$baseline * g0, d$baseline * g1)
X <- cbind(C, d$dose * g0, d$dose * g1)
Z <- cbind(C, d$instrument * g0, d$instrument * g1)
sw <- sqrt(d$weight)
Xw <- X * sw
Zw <- Z * sw
yw <- d$outcome * sw
stopifnot(qr(Zw)$rank == ncol(Zw))
Xhat <- qr.fitted(qr(Zw), Xw)
stopifnot(qr(Xhat)$rank == ncol(Xhat))
beta <- as.numeric(qr.coef(qr(Xhat), yw))
mean_dose <- vapply(0:1, function(g) weighted.mean(d$dose[d$eligible == g], d$weight[d$eligible == g]), numeric(1))
effect <- beta[5:6] * mean_dose
pop <- census$nonrecipient_population[match(0:1, census$eligible)]
values <- c(ineligible_effect = effect[1], eligible_nonrecipient_effect = effect[2], population_effect = weighted.mean(effect, pop))
n <- nrow(d)
estimates <- lapply(names(values), function(term) list(term = term, estimate = unname(values[[term]]), se = NULL, n_obs = as.integer(n)))
output <- list(task_id = "applied_nonrecipient_population_iv", platform = "r", estimates = estimates,
  method_metadata = list(estimator = "weighted 2SLS", sample = "recipient == 0", counterfactual = "dose set to zero for every retained household", group_aggregation = "census nonrecipient_population; within-group mean dose uses household weights", standard_errors = "not requested; null"),
  diagnostics = list(n_obs = as.integer(n), group_n_obs = as.list(setNames(as.integer(table(factor(d$eligible, levels = 0:1))), c("ineligible", "eligible"))), dose_slopes = as.list(setNames(beta[5:6], c("ineligible", "eligible"))), weighted_mean_dose = as.list(setNames(mean_dose, c("ineligible", "eligible"))), instrument_rank = as.integer(qr(Zw)$rank)))
write_json(output, "result.json", pretty = TRUE, auto_unbox = TRUE, digits = NA, null = "null")
