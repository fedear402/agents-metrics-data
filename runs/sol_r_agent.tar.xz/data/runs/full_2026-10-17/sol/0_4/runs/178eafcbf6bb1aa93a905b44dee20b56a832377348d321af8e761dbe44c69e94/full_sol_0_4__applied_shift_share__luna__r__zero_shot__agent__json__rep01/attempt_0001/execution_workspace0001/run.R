d <- read.csv("input.csv", stringsAsFactors = FALSE)
stopifnot(nrow(d) > 0L, !anyNA(d), !anyDuplicated(d[c("region_id", "industry_id")]))
regions <- unique(d$region_id)
industries <- unique(d$industry_id)
R <- length(regions)
N <- length(industries)
stopifnot(nrow(d) == R * N, N > 2L)
ri <- match(d$region_id, regions)
ni <- match(d$industry_id, industries)
constant_by <- function(value, group) all(vapply(split(value, group), function(v) max(v) == min(v), logical(1)))
stopifnot(constant_by(d$region_weight, ri), constant_by(d$x, ri),
          constant_by(d$y, ri), constant_by(d$shock, ni))
share <- matrix(0, R, N)
share[cbind(ri, ni)] <- d$share
stopifnot(max(abs(rowSums(share) - 1)) < 1e-9)
w <- d$region_weight[match(regions, d$region_id)]
stopifnot(all(w > 0))
e <- w / sum(w)
x <- d$x[match(regions, d$region_id)]
y <- d$y[match(regions, d$region_id)]
shock <- d$shock[match(industries, d$industry_id)]
z <- as.vector(share %*% shock)
center <- function(v, weights) v - sum(weights * v) / sum(weights)
y0 <- center(y, e)
x0 <- center(x, e)
z0 <- center(z, e)
s <- as.vector(crossprod(e, share))
stopifnot(all(s > 0), abs(sum(s) - 1) < 1e-10)
aggregate_residual <- function(v) as.vector(crossprod(share, e * v)) / s
ybar <- aggregate_residual(y0)
xbar <- aggregate_residual(x0)
zbar <- aggregate_residual(z0)

# Just-identified weighted IV with an intercept. The analytic-weight sandwich
# uses squared weights in each industry's score contribution.
shock_iv <- function(response, endogenous) {
  q <- center(shock, s)
  a <- center(response, s)
  b <- center(endogenous, s)
  denominator <- sum(s * q * b)
  stopifnot(abs(denominator) > 1e-12)
  slope <- sum(s * q * a) / denominator
  intercept <- sum(s * response) / sum(s) - slope * sum(s * endogenous) / sum(s)
  residual <- response - intercept - slope * endogenous
  se <- sqrt((N / (N - 2)) * sum((s * q * residual)^2) / denominator^2)
  c(estimate = slope, se = se)
}
effect <- shock_iv(ybar, xbar)
first_stage <- shock_iv(xbar, zbar)
effective_shocks <- 1 / sum(s^2)

# Independent regional moment checks, including the first stage.
effect_regional <- sum(e * z0 * y0) / sum(e * z0 * x0)
first_regional <- sum(e * z0 * x0) / sum(e * z0^2)
stopifnot(isTRUE(all.equal(unname(effect["estimate"]), effect_regional, tolerance = 1e-10)),
          isTRUE(all.equal(unname(first_stage["estimate"]), first_regional, tolerance = 1e-10)))

stopifnot(requireNamespace("jsonlite", quietly = TRUE))
result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = unname(effect["estimate"]), se = unname(effect["se"]), n_obs = N),
    list(term = "first_stage", estimate = unname(first_stage["estimate"]), se = unname(first_stage["se"]), n_obs = N),
    list(term = "effective_shocks", estimate = effective_shocks, se = NULL, n_obs = N)
  ),
  method_metadata = list(estimator = "Weighted regional 2SLS via BHJ shock-level IV", vcov = "Shock-level analytic-weight HC1, N/(N-2)"),
  diagnostics = structure(list(), names = character())
)
writeLines(jsonlite::toJSON(result, auto_unbox = TRUE, digits = 16, null = "null", pretty = TRUE), "result.json")
notes <- c(
  sprintf("Sample: %d unique regions, %d unique industries, %d region-industry rows; complete balanced grid; no missing values.", R, N, nrow(d)),
  sprintf("Construction: max regional share-sum error %.3g; normalized regional weights sum %.16g; industry exposure weights sum %.16g.", max(abs(rowSums(share)-1)), sum(e), sum(s)),
  sprintf("Effect: shock-level IV %.12g; independent regional weighted IV moment %.12g; difference %.3g.", effect["estimate"], effect_regional, effect["estimate"]-effect_regional),
  sprintf("First stage: shock-level IV %.12g; independent regional weighted OLS moment %.12g; difference %.3g.", first_stage["estimate"], first_regional, first_stage["estimate"]-first_regional),
  sprintf("SEs: structural shock-level residuals, squared analytic weights in the sandwich, HC1 multiplier %d/(%d-2). Effect SE %.12g; first-stage SE %.12g.", N, N, effect["se"], first_stage["se"]),
  sprintf("Effective shocks: %.12g from 1/sum(s_n^2).", effective_shocks)
)
writeLines(notes, "verification.txt")
