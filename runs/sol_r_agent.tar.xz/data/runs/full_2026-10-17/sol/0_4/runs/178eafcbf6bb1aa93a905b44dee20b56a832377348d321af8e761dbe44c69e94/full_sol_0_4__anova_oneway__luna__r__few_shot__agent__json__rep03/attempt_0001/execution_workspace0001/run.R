library(jsonlite)

dat <- read.csv("input.csv", stringsAsFactors = FALSE)
stopifnot(all(c("group", "y") %in% names(dat)))
dat <- dat[!is.na(dat$group) & !is.na(dat$y), c("group", "y")]
dat$y <- as.numeric(dat$y)
stopifnot(nrow(dat) > 0L, all(is.finite(dat$y)))
dat$group <- factor(dat$group)
stopifnot(nlevels(dat$group) >= 2L, nrow(dat) > nlevels(dat$group))

fit <- aov(y ~ group, data = dat)
tab <- summary(fit)[[1L]]
values <- c(F = tab[1L, "F value"],
            df_num = tab[1L, "Df"],
            df_den = tab[2L, "Df"],
            p_value = tab[1L, "Pr(>F)"])
stopifnot(all(is.finite(values)))

out <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = lapply(names(values), function(term) {
    list(term = term, estimate = unname(as.numeric(values[[term]])),
         se = NA_real_, n_obs = nrow(dat))
  }),
  method_metadata = list(estimator = "One-way ANOVA", vcov = "classical"),
  diagnostics = structure(list(), names = character(0))
)
write_json(out, "result.json", auto_unbox = TRUE, digits = NA, na = "null")
