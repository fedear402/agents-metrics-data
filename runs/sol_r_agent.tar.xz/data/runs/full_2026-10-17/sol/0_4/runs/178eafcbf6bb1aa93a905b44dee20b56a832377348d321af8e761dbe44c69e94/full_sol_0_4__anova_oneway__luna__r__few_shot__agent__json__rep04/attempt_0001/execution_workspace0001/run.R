library(jsonlite)

data <- read.csv("input.csv")
stopifnot(all(c("group", "y") %in% names(data)))
sample <- data[complete.cases(data[c("group", "y")]), c("group", "y")]
sample$group <- factor(sample$group)
stopifnot(nrow(sample) > nlevels(sample$group), nlevels(sample$group) > 1L)

fit <- aov(y ~ group, data = sample)
anova_table <- summary(fit)[[1L]]
n <- nobs(fit)

row <- function(term, value) {
  list(term = term, estimate = unname(as.numeric(value)), se = NA_real_, n_obs = as.integer(n))
}
out <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = list(
    row("F", anova_table[1L, "F value"]),
    row("df_num", anova_table[1L, "Df"]),
    row("df_den", anova_table[2L, "Df"]),
    row("p_value", anova_table[1L, "Pr(>F)"])
  ),
  method_metadata = list(estimator = "One-way ANOVA", vcov = "classical pooled residual variance"),
  diagnostics = structure(list(), names = character(0))
)
write_json(out, "result.json", auto_unbox = TRUE, digits = NA, na = "null")
