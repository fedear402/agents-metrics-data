crosswalk <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
trade <- read.csv("trade.csv", stringsAsFactors = FALSE)
areas <- read.csv("areas.csv", stringsAsFactors = FALSE)
employment <- read.csv("employment.csv", stringsAsFactors = FALSE)
outcomes <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

stopifnot(!anyDuplicated(crosswalk$code),
          !anyDuplicated(trade[c("period", "code")]),
          !anyDuplicated(areas[c("area", "period", "vintage")]),
          !anyDuplicated(employment[c("area", "period", "vintage", "industry")]),
          !anyDuplicated(outcomes[c("area", "period")]))
trade <- merge(trade, crosswalk, by = "code", all.x = TRUE, sort = FALSE)
stopifnot(!anyNA(trade$industry),
          !anyDuplicated(trade[c("period", "industry")]),
          length(unique(crosswalk$industry)) == 4L)

# Complete the supplied area-period-vintage cells with all four industries.
cells <- merge(areas, data.frame(industry = unique(crosswalk$industry)))
cells <- merge(cells, employment, by = c("area", "period", "vintage", "industry"),
               all.x = TRUE, sort = FALSE)
cells$employment[is.na(cells$employment)] <- 0
national <- aggregate(employment ~ period + vintage + industry, cells, sum)
names(national)[4] <- "national_employment"
cells <- merge(cells, national, by = c("period", "vintage", "industry"), sort = FALSE)
stopifnot(all(cells$national_employment > 0))
cells <- merge(cells, trade, by = c("period", "industry"), sort = FALSE)
stopifnot(nrow(cells) == nrow(areas) * 4L, !anyNA(cells$us_change))

cells$exposure_piece <- with(cells,
  (employment / total_employment) *
  (ifelse(vintage == "base", us_change, other_change) / national_employment) /
  (price_index / 100) / 1000 * (10 / years))
exposure <- aggregate(exposure_piece ~ area + period + vintage, cells, sum)
base <- subset(exposure, vintage == "base", c("area", "period", "exposure_piece"))
early <- subset(exposure, vintage == "early", c("area", "period", "exposure_piece"))
names(base)[3] <- "x"
names(early)[3] <- "z"
sample <- merge(merge(outcomes, base, by = c("area", "period")),
                early, by = c("area", "period"))
weights <- subset(areas, vintage == "base", c("area", "period", "population"))
sample <- merge(sample, weights, by = c("area", "period"))
stopifnot(nrow(sample) == 72L, !anyNA(sample), all(sample$population > 0))

# Weighted two-stage least squares, with the same three exogenous columns
# in both the regressor matrix and the instrument matrix.
X <- model.matrix(~ period + control + x, sample)
Z <- model.matrix(~ period + control + z, sample)
w <- sample$population
ZX <- crossprod(Z, X * w)
Zy <- crossprod(Z, sample$change_pp * w)
beta <- solve(ZX, Zy)
iv_slope <- unname(beta["x", 1])

get_exposure <- function(column, area, period) {
  value <- sample[sample$area == area & sample$period == period, column]
  stopifnot(length(value) == 1L)
  unname(value)
}
estimates <- list(
  list(term = "iv_slope", estimate = iv_slope, se = NULL, n_obs = 72L),
  list(term = "exposure_area0_period0", estimate = get_exposure("x", 0, 0), se = NULL, n_obs = 72L),
  list(term = "exposure_area0_period1", estimate = get_exposure("x", 0, 1), se = NULL, n_obs = 72L),
  list(term = "instrument_area0_period0", estimate = get_exposure("z", 0, 0), se = NULL, n_obs = 72L)
)
result <- list(
  task_id = "applied_multivintage_trade_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(estimator = "weighted 2SLS", weights = "base-vintage population",
                         regressors = c("intercept", "period", "control", "x"),
                         instruments = c("intercept", "period", "control", "z"),
                         exposure_units = "thousands of real dollars per worker per decade"),
  diagnostics = list(n_areas = length(unique(sample$area)),
                     n_periods = length(unique(sample$period)),
                     n_obs = nrow(sample),
                     completed_employment_cells = sum(is.na(merge(
                       merge(areas, data.frame(industry = unique(crosswalk$industry))),
                       employment, by = c("area", "period", "vintage", "industry"),
                       all.x = TRUE)$employment)))
)
jsonlite::write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)

# Independent checks: residualized IV ratio and direct four-industry sums.
C <- model.matrix(~ period + control, sample)
residualize <- function(v) {
  v - C %*% solve(crossprod(C, C * w), crossprod(C, v * w))
}
iv_check <- sum(w * residualize(sample$z) * residualize(sample$change_pp)) /
  sum(w * residualize(sample$z) * residualize(sample$x))
stopifnot(isTRUE(all.equal(iv_slope, as.numeric(iv_check), tolerance = 1e-10)))
for (p in sort(unique(sample$period))) {
  for (v in c("base", "early")) {
    a <- subset(areas, area == 0 & period == p & vintage == v)
    t <- subset(trade, period == p)
    direct <- 0
    for (j in unique(crosswalk$industry)) {
      e <- subset(employment, area == 0 & period == p & vintage == v & industry == j)$employment
      if (length(e) == 0L) e <- 0
      nj <- sum(subset(employment, period == p & vintage == v & industry == j)$employment)
      tj <- subset(t, industry == j)
      change <- if (v == "base") tj$us_change else tj$other_change
      direct <- direct + (e / a$total_employment) * (change / nj) /
        (tj$price_index / 100) / 1000 * (10 / tj$years)
    }
    computed <- get_exposure(if (v == "base") "x" else "z", 0, p)
    stopifnot(isTRUE(all.equal(direct, computed, tolerance = 1e-12)))
  }
}
cat(sprintf("n_obs=%d; iv_slope=%.16g; residualized_iv=%.16g\n",
            nrow(sample), iv_slope, iv_check))
