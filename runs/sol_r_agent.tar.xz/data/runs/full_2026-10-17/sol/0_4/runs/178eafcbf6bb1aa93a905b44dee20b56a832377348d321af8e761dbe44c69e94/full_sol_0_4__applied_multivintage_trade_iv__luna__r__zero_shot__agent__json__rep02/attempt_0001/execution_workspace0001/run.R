library(jsonlite)

crosswalk <- read.csv("crosswalk.csv")
trade <- read.csv("trade.csv")
areas <- read.csv("areas.csv")
employment <- read.csv("employment.csv")
outcomes <- read.csv("outcomes.csv")
# The additional supplied CSV repeats the crosswalk. Read and validate it.
input <- read.csv("input.csv")
stopifnot(isTRUE(all.equal(input, crosswalk, check.attributes = FALSE)))

trade <- merge(trade, crosswalk, by = "code", sort = FALSE)
stopifnot(nrow(trade) == 8L, all(table(trade$period, trade$industry) == 1L))
stopifnot(all(table(areas$area, areas$period, areas$vintage) == 1L))

# Complete the four industry cells for every area, period, and vintage.
grid <- merge(areas[c("area", "period", "vintage", "total_employment", "population")],
              unique(trade[c("period", "industry")]), by = "period")
cells <- merge(grid, employment, by = c("area", "period", "vintage", "industry"),
               all.x = TRUE, sort = FALSE)
cells$employment[is.na(cells$employment)] <- 0
national <- aggregate(employment ~ period + vintage + industry, cells, sum)
names(national)[4] <- "national_employment"
cells <- merge(cells, national, by = c("period", "vintage", "industry"))
cells <- merge(cells, trade, by = c("period", "industry"))
stopifnot(all(cells$national_employment > 0), nrow(cells) == 576L)

cells$component <- ifelse(cells$vintage == "base", cells$us_change,
                          cells$other_change) *
  (cells$employment / cells$total_employment) /
  cells$national_employment / (cells$price_index / 100) / 1000 *
  (10 / cells$years)
exposures <- aggregate(component ~ area + period + vintage, cells, sum)
wide <- reshape(exposures, idvar = c("area", "period"), timevar = "vintage",
                direction = "wide")
names(wide)[names(wide) == "component.base"] <- "x"
names(wide)[names(wide) == "component.early"] <- "z"
weights <- areas[areas$vintage == "base", c("area", "period", "population")]
sample <- merge(merge(outcomes, wide, by = c("area", "period")), weights,
                by = c("area", "period"))
sample <- sample[order(sample$period, sample$area), ]
stopifnot(nrow(sample) == 72L, all(complete.cases(sample)),
          all(sample$population > 0))

X <- model.matrix(~ period + control + x, sample)
Z <- model.matrix(~ period + control + z, sample)
y <- sample$change_pp
w <- sample$population
# Exactly identified weighted 2SLS: Z' W (y - X beta) = 0.
beta <- solve(crossprod(Z, w * X), crossprod(Z, w * y))
iv_slope <- unname(beta["x", 1])

# Independent Frisch-Waugh-Lovell calculation of the same IV slope.
C <- model.matrix(~ period + control, sample)
residualize <- function(v) as.vector(v - C %*% solve(crossprod(C, w * C),
                                                       crossprod(C, w * v)))
xr <- residualize(sample$x)
zr <- residualize(sample$z)
yr <- residualize(y)
iv_check <- sum(w * zr * yr) / sum(w * zr * xr)
stopifnot(isTRUE(all.equal(iv_slope, iv_check, tolerance = 1e-10)))

get_value <- function(variable, area_id, period_id) {
  row <- sample[sample$area == area_id & sample$period == period_id, ]
  stopifnot(nrow(row) == 1L)
  unname(row[[variable]])
}
terms <- c("iv_slope", "exposure_area0_period0", "exposure_area0_period1",
           "instrument_area0_period0")
values <- c(iv_slope, get_value("x", 0, 0), get_value("x", 0, 1),
            get_value("z", 0, 0))
estimates <- lapply(seq_along(terms), function(i)
  list(term = terms[i], estimate = values[i], se = NULL, n_obs = 72L))
result <- list(task_id = "applied_multivintage_trade_iv", platform = "r",
               estimates = estimates,
               method_metadata = list(estimator = "weighted 2SLS",
                                      endogenous = "x", instrument = "z",
                                      exogenous = c("intercept", "period", "control"),
                                      weight = "base-vintage population",
                                      exposure_unit = "thousands of real dollars per worker per decade"),
               diagnostics = list(sample_rows = nrow(sample),
                                  employment_cells = nrow(cells),
                                  independent_iv_slope = iv_check,
                                  iv_check_absolute_difference = abs(iv_slope - iv_check)))
write_json(result, "result.json", pretty = TRUE, auto_unbox = TRUE, digits = 16,
           null = "null")
