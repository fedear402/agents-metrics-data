d <- read.csv("input.csv")
stopifnot(identical(names(d), c("region_id", "industry_id", "share", "shock", "region_weight", "x", "y")))
stopifnot(!anyNA(d), !anyDuplicated(d[c("region_id", "industry_id")]))

regions <- sort(unique(d$region_id))
industries <- sort(unique(d$industry_id))
R <- length(regions)
N <- length(industries)
stopifnot(nrow(d) == R * N)
ri <- match(d$region_id, regions)
ni <- match(d$industry_id, industries)

regional <- d[match(regions, d$region_id), c("region_weight", "x", "y")]
shocks <- d$shock[match(industries, d$industry_id)]
stopifnot(all(d$region_weight == regional$region_weight[ri]),
          all(d$x == regional$x[ri]), all(d$y == regional$y[ri]),
          all(d$shock == shocks[ni]))

shares <- matrix(0, R, N)
shares[cbind(ri, ni)] <- d$share
stopifnot(max(abs(rowSums(shares) - 1)) < 1e-10)
e <- regional$region_weight / sum(regional$region_weight)
stopifnot(all(e > 0))
z <- as.vector(shares %*% shocks)
y0 <- regional$y - sum(e * regional$y)
x0 <- regional$x - sum(e * regional$x)
z0 <- z - sum(e * z)
s <- colSums(shares * e)
stopifnot(all(s > 0), abs(sum(s) - 1) < 1e-10)
aggregate_residual <- function(v) colSums(shares * (e * v)) / s
ybar <- aggregate_residual(y0)
xbar <- aggregate_residual(x0)
zbar <- aggregate_residual(z0)

# Just-identified weighted IV with structural residual HC1 by industry.
shock_iv <- function(response, endogenous) {
  X <- cbind(1, endogenous)
  Z <- cbind(1, shocks)
  A <- crossprod(Z, s * X)
  beta <- solve(A, crossprod(Z, s * response))
  residual <- as.vector(response - X %*% beta)
  scores <- Z * (s * residual)
  meat <- crossprod(scores)
  variance <- solve(A) %*% meat %*% t(solve(A)) * N / (N - 2)
  list(estimate = unname(beta[2]), se = sqrt(variance[2, 2]))
}

effect <- shock_iv(ybar, xbar)
first_stage <- shock_iv(xbar, zbar)
output <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = effect$estimate, se = effect$se, n_obs = N),
    list(term = "first_stage", estimate = first_stage$estimate, se = first_stage$se, n_obs = N),
    list(term = "effective_shocks", estimate = unname(1 / sum(s^2)), se = NULL, n_obs = N)
  ),
  method_metadata = list(
    estimator = "Weighted regional 2SLS via BHJ shock-level IV aggregation",
    vcov = "Shock-level structural-residual HC1; analytic weights s_n; N/(N-2); no clustering"
  ),
  diagnostics = jsonlite::fromJSON("{}", simplifyVector = FALSE)
)
jsonlite::write_json(output, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE, null = "null")
