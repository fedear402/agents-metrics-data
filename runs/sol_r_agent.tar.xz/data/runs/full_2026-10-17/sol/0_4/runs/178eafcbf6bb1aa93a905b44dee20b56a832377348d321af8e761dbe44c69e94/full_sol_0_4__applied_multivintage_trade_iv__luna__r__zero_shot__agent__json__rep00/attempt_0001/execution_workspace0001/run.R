crosswalk <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
trade <- read.csv("trade.csv", stringsAsFactors = FALSE)
areas <- read.csv("areas.csv", stringsAsFactors = FALSE)
employment <- read.csv("employment.csv", stringsAsFactors = FALSE)
outcomes <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

stopifnot(length(unique(crosswalk$industry)) == 4L, !anyDuplicated(crosswalk$code))
trade <- merge(trade, crosswalk, by = "code", all.x = TRUE, sort = FALSE)
stopifnot(!anyNA(trade$industry), !anyDuplicated(trade[c("period", "industry")]))
stopifnot(all(table(trade$period) == 4L))

# Complete omitted area-industry cells with zero employment.
grid <- merge(areas[c("area", "period", "vintage")],
              unique(trade[c("period", "industry")]), by = "period")
cells <- merge(grid, employment, by = c("area", "period", "vintage", "industry"),
               all.x = TRUE, sort = FALSE)
cells$employment[is.na(cells$employment)] <- 0
stopifnot(nrow(cells) == nrow(grid), !anyDuplicated(cells[c("area", "period", "vintage", "industry")]))

national <- aggregate(employment ~ period + vintage + industry, cells, sum)
names(national)[4] <- "national_employment"
cells <- merge(cells, national, by = c("period", "vintage", "industry"))
cells <- merge(cells, areas, by = c("area", "period", "vintage"))
cells <- merge(cells, trade, by = c("period", "industry"))
stopifnot(all(cells$national_employment > 0), all(cells$total_employment > 0))

cells$component <- with(cells,
  (employment / total_employment) *
  (ifelse(vintage == "base", us_change, other_change) / national_employment) /
  (price_index / 100) / 1000 * (10 / years))
exposures <- aggregate(component ~ area + period + vintage, cells, sum)
wide <- reshape(exposures, idvar = c("area", "period"), timevar = "vintage", direction = "wide")
names(wide)[names(wide) == "component.base"] <- "x"
names(wide)[names(wide) == "component.early"] <- "z"
sample <- merge(outcomes, wide, by = c("area", "period"))
weights <- areas[areas$vintage == "base", c("area", "period", "population")]
sample <- merge(sample, weights, by = c("area", "period"))
sample <- sample[order(sample$period, sample$area), ]
stopifnot(nrow(sample) == 72L, !anyNA(sample), all(sample$population > 0))

# Weighted 2SLS: beta = (X' W P_Z X)^(-1) X' W P_Z y.
X <- cbind(intercept = 1, period = sample$period, control = sample$control, x = sample$x)
Z <- cbind(intercept = 1, period = sample$period, control = sample$control, z = sample$z)
sqrt_w <- sqrt(sample$population)
Xw <- X * sqrt_w
Zw <- Z * sqrt_w
yw <- sample$change_pp * sqrt_w
projected_X <- Zw %*% solve(crossprod(Zw), crossprod(Zw, Xw))
beta <- solve(crossprod(projected_X, Xw), crossprod(projected_X, yw))

get_value <- function(column, area, period) {
  value <- sample[sample$area == area & sample$period == period, column]
  stopifnot(length(value) == 1L)
  unname(value)
}
estimates <- list(
  list(term = "iv_slope", estimate = unname(beta["x", 1]), se = NA_real_, n_obs = 72L),
  list(term = "exposure_area0_period0", estimate = get_value("x", 0, 0), se = NA_real_, n_obs = 72L),
  list(term = "exposure_area0_period1", estimate = get_value("x", 0, 1), se = NA_real_, n_obs = 72L),
  list(term = "instrument_area0_period0", estimate = get_value("z", 0, 0), se = NA_real_, n_obs = 72L)
)
result <- list(
  task_id = "applied_multivintage_trade_iv", platform = "r", estimates = estimates,
  method_metadata = list(estimator = "weighted 2SLS", endogenous = "x", instrument = "z",
                         exogenous = c("intercept", "period", "control"),
                         weight = "base-vintage population"),
  diagnostics = list(estimation_rows = nrow(sample), industries = length(unique(crosswalk$industry)),
                     periods = sort(unique(sample$period)), complete_cells = nrow(grid),
                     omitted_employment_cells_filled = sum(is.na(merge(grid, employment,
                       by = c("area", "period", "vintage", "industry"), all.x = TRUE)$employment)))
)
jsonlite::write_json(result, "result.json", auto_unbox = TRUE, pretty = TRUE, digits = 16,
                     na = "null")

# Independent weighted Frisch-Waugh-Lovell IV check.
Cw <- cbind(1, sample$period, sample$control) * sqrt_w
residualize <- function(v) v - Cw %*% solve(crossprod(Cw), crossprod(Cw, v))
rx <- residualize(sample$x * sqrt_w)
rz <- residualize(sample$z * sqrt_w)
ry <- residualize(yw)
iv_fwl <- as.numeric(crossprod(rz, ry) / crossprod(rz, rx))
stopifnot(isTRUE(all.equal(iv_fwl, unname(beta["x", 1]), tolerance = 1e-10)))
cat(sprintf("rows=%d; IV slope=%.12f; FWL slope=%.12f\n", nrow(sample), beta["x", 1], iv_fwl))
