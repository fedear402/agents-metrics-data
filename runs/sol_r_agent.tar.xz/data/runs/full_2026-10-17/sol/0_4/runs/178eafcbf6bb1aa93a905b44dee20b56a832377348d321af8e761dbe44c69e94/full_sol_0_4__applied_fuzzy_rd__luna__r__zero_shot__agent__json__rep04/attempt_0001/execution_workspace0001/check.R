d <- read.csv("input.csv")
ok <- is.finite(d$score) & is.finite(d$earnings) &
  is.finite(d$participated) & abs(d$score) < 1
d <- d[ok, ]
w <- 1 - abs(d$score)
side <- d$score >= 0
out <- matrix(NA_real_, length(d$score), 2)
jump <- numeric(2)
for (k in 1:2) {
  y <- d[[c("earnings", "participated")[k]]]
  fits <- lapply(c(FALSE, TRUE), function(s) {
    idx <- which(side == s)
    fit <- lm(y[idx] ~ d$score[idx], weights = w[idx])
    Z <- cbind(1, d$score[idx])
    a <- solve(crossprod(Z, w[idx] * Z))
    infl <- as.vector(w[idx] * (Z %*% a[, 1])) * residuals(fit)
    list(intercept = unname(coef(fit)[1]), idx = idx, infl = infl)
  })
  jump[k] <- fits[[2]]$intercept - fits[[1]]$intercept
  out[fits[[1]]$idx, k] <- -fits[[1]]$infl
  out[fits[[2]]$idx, k] <- fits[[2]]$infl
}
V <- crossprod(out)
g <- c(1 / jump[2], -jump[1] / jump[2]^2)
check <- c(jump[1] / jump[2], jump, sqrt(as.numeric(t(g) %*% V %*% g)),
           sqrt(diag(V)), nrow(d), sum(!side), sum(side))
names(check) <- c("treatment_effect", "reduced_form", "first_stage",
                  "te_se", "rf_se", "fs_se", "n", "n_left", "n_right")
print(check, digits = 16)
cat("cross_outcome_covariance", format(V[1, 2], digits = 16), "\n")
