d <- read.csv("input.csv", stringsAsFactors = FALSE)
stopifnot(identical(names(d), c("region_id", "industry_id", "share", "shock", "region_weight", "x", "y")))
stopifnot(!anyNA(d), !anyDuplicated(d[c("region_id", "industry_id")]))
regions <- unique(d$region_id)
industries <- unique(d$industry_id)
R <- length(regions); N <- length(industries)
stopifnot(nrow(d) == R*N)
ri <- match(d$region_id, regions)
ni <- match(d$industry_id, industries)
check_constant <- function(v, group) all(v == v[match(group, group)])
stopifnot(check_constant(d$region_weight, d$region_id),
          check_constant(d$x, d$region_id),
          check_constant(d$y, d$region_id),
          check_constant(d$shock, d$industry_id))
share <- matrix(0, R, N)
share[cbind(ri, ni)] <- d$share
stopifnot(max(abs(rowSums(share) - 1)) < 1e-10)
reg <- d[match(regions, d$region_id), ]
g <- d$shock[match(industries, d$industry_id)]
e <- reg$region_weight / sum(reg$region_weight)
stopifnot(all(e > 0), all(share >= 0))
z <- as.vector(share %*% g)
y0 <- reg$y - sum(e*reg$y)
x0 <- reg$x - sum(e*reg$x)
z0 <- z - sum(e*z)
s <- as.vector(crossprod(e, share))
stopifnot(all(s > 0), abs(sum(s)-1) < 1e-10)
aggregate <- function(v) as.vector(crossprod(e*v, share))/s
ybar <- aggregate(y0)
xbar <- aggregate(x0)
zbar <- aggregate(z0)
iv_fit <- function(y, x, instrument, weights) {
  X <- cbind(1, x)
  Z <- cbind(1, instrument)
  A <- crossprod(Z, weights*X)
  beta <- as.vector(solve(A, crossprod(Z, weights*y)))
  u <- as.vector(y-X%*%beta)
  B <- crossprod(Z, (weights^2*u^2)*Z)
  Ai <- solve(A)
  V <- (length(y)/(length(y)-ncol(X))) * Ai %*% B %*% t(Ai)
  list(beta=beta, se=sqrt(diag(V)), residual=u)
}
effect <- iv_fit(ybar, xbar, g, s)
first_stage <- iv_fit(xbar, zbar, g, s)
stopifnot(all(is.finite(c(effect$beta, effect$se, first_stage$beta, first_stage$se))))
if (!requireNamespace("jsonlite", quietly=TRUE)) stop("jsonlite is required")
result <- list(task_id="applied_shift_share", platform="r",
  estimates=list(
    list(term="effect", estimate=unname(effect$beta[2]), se=unname(effect$se[2]), n_obs=N),
    list(term="first_stage", estimate=unname(first_stage$beta[2]), se=unname(first_stage$se[2]), n_obs=N),
    list(term="effective_shocks", estimate=unname(1/sum(s^2)), se=NULL, n_obs=N)),
  method_metadata=list(estimator="Weighted 2SLS with BHJ shock-level aggregation", vcov="Shock-level heteroskedasticity-robust HC1, N/(N-2), analytic weights"),
  diagnostics=structure(list(), names=character(0)))
jsonlite::write_json(result, "result.json", auto_unbox=TRUE, pretty=TRUE, digits=16, null="null")
cat(sprintf("R=%d N=%d; effect=%.12g SE=%.12g; first_stage=%.12g SE=%.12g; effective_shocks=%.12g\n", R,N,effect$beta[2],effect$se[2],first_stage$beta[2],first_stage$se[2],1/sum(s^2)))
