library(jsonlite)

d <- read.csv("households.csv")
census <- read.csv("census.csv")
d <- d[d$recipient == 0, , drop = FALSE]
stopifnot(nrow(d) > 0L, all(complete.cases(d)), all(d$weight > 0),
          setequal(unique(d$eligible), c(0, 1)),
          setequal(census$eligible, c(0, 1)))

g0 <- 1 - d$eligible
g1 <- d$eligible
C <- cbind(g0, g1, d$baseline * g0, d$baseline * g1)
X <- cbind(C, d$dose * g0, d$dose * g1)
Z <- cbind(C, d$instrument * g0, d$instrument * g1)
sw <- sqrt(d$weight)
Xw <- X * sw
Zw <- Z * sw
yw <- d$outcome * sw
stopifnot(qr(Xw)$rank == 6L, qr(Zw)$rank == 6L)
PZX <- qr.fitted(qr(Zw), Xw)
beta <- as.vector(qr.coef(qr(PZX), yw))
stopifnot(all(is.finite(beta)))

mean_dose <- vapply(0:1, function(g) {
  a <- d[d$eligible == g, , drop = FALSE]
  weighted.mean(a$dose, a$weight)
}, numeric(1))
effects <- beta[5:6] * mean_dose
pop <- census$nonrecipient_population[match(0:1, census$eligible)]
stopifnot(all(is.finite(pop)), all(pop > 0))
values <- c(ineligible_effect = effects[1],
            eligible_nonrecipient_effect = effects[2],
            population_effect = weighted.mean(effects, pop))

# Separate just-identified IV calculation after removing each group's
# weighted intercept and weighted baseline projection.
check_slope <- vapply(0:1, function(g) {
  a <- d[d$eligible == g, , drop = FALSE]
  cg <- cbind(1, a$baseline)
  residual <- function(v) {
    fit <- lm.wfit(cg, v, a$weight)
    v - as.vector(cg %*% fit$coefficients)
  }
  zr <- residual(a$instrument)
  sum(a$weight * zr * residual(a$outcome)) /
    sum(a$weight * zr * residual(a$dose))
}, numeric(1))
max_slope_difference <- max(abs(check_slope - beta[5:6]))
stopifnot(max_slope_difference < 1e-9)

estimates <- lapply(seq_along(values), function(i) {
  list(term = names(values)[i], estimate = unname(values[i]),
       se = NA_real_, n_obs = as.integer(nrow(d)))
})
result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "weighted 2SLS",
    sample = "recipient == 0",
    counterfactual = "dose set to zero for every retained household",
    group_effect = "group dose slope times household-weighted mean dose",
    population_aggregation = "census nonrecipient_population weights"),
  diagnostics = list(n_obs = as.integer(nrow(d)),
                     group_n_obs = as.list(setNames(as.integer(table(factor(d$eligible, levels = 0:1))), c("0", "1"))),
                     x_rank = as.integer(qr(Xw)$rank), z_rank = as.integer(qr(Zw)$rank),
                     independent_slope_max_abs_difference = max_slope_difference)
)
write_json(result, "result.json", auto_unbox = TRUE, digits = 16, na = "null", pretty = TRUE)
cat(toJSON(values, auto_unbox = TRUE, digits = 16), "\n")
