library(jsonlite)

h <- read.csv("households.csv")
census <- read.csv("census.csv")
stopifnot(all(c("eligible", "recipient", "instrument", "dose", "baseline", "weight", "outcome") %in% names(h)))
stopifnot(all(h$eligible %in% c(0, 1)), all(h$recipient %in% c(0, 1)))
stopifnot(all(is.finite(h$weight)), all(h$weight > 0))
s <- h[h$recipient == 0, ]
stopifnot(nrow(s) > 0, all(complete.cases(s[, c("eligible", "instrument", "dose", "baseline", "weight", "outcome")])))
g0 <- 1 - s$eligible
g1 <- s$eligible
X <- cbind(g0, g1, s$baseline * g0, s$baseline * g1,
           s$dose * g0, s$dose * g1)
Z <- cbind(g0, g1, s$baseline * g0, s$baseline * g1,
           s$instrument * g0, s$instrument * g1)
sqrt_w <- sqrt(s$weight)
Xw <- X * sqrt_w
Zw <- Z * sqrt_w
yw <- s$outcome * sqrt_w
stopifnot(qr(Xw)$rank == 6L, qr(Zw)$rank == 6L)
projected_X <- qr.fitted(qr(Zw), Xw)
beta <- as.vector(solve(crossprod(projected_X, Xw), crossprod(projected_X, yw)))
mean_dose <- vapply(0:1, function(group) {
  i <- s$eligible == group
  stopifnot(any(i))
  weighted.mean(s$dose[i], s$weight[i])
}, numeric(1))
effects <- beta[5:6] * mean_dose
stopifnot(identical(sort(census$eligible), 0:1),
          all(is.finite(census$nonrecipient_population)),
          all(census$nonrecipient_population >= 0))
pop <- census$nonrecipient_population[match(0:1, census$eligible)]
population_effect <- weighted.mean(effects, pop)
n <- nrow(s)
estimates <- list(
  list(term = "ineligible_effect", estimate = unname(effects[1]), se = NA_real_, n_obs = n),
  list(term = "eligible_nonrecipient_effect", estimate = unname(effects[2]), se = NA_real_, n_obs = n),
  list(term = "population_effect", estimate = unname(population_effect), se = NA_real_, n_obs = n)
)
result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(estimator = "weighted 2SLS", sample = "recipient == 0",
                         intercept = "none beyond eligibility columns",
                         counterfactual = "dose zero for every retained household",
                         attribution = "synthetic convention"),
  diagnostics = list(n_obs = n, group_n_obs = as.integer(tabulate(s$eligible + 1L, nbins = 2L)),
                     x_rank = qr(Xw)$rank, z_rank = qr(Zw)$rank,
                     dose_slopes = unname(beta[5:6]), weighted_mean_dose = unname(mean_dose),
                     census_nonrecipient_population = unname(pop))
)
write_json(result, "result.json", pretty = TRUE, auto_unbox = TRUE, na = "null", digits = NA)
