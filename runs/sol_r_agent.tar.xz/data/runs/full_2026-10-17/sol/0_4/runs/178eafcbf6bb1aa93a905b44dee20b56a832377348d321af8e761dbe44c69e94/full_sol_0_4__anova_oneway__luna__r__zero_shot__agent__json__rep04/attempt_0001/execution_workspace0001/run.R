data <- read.csv("input.csv", stringsAsFactors = FALSE)
stopifnot(identical(names(data), c("group", "y")))

sample <- data[!is.na(data$group) & is.finite(data$y), , drop = FALSE]
sample$group <- factor(sample$group)
n <- nrow(sample)
k <- nlevels(sample$group)
stopifnot(n > k, k > 1L)

fit <- aov(y ~ group, data = sample)
tab <- summary(fit)[[1L]]
f_stat <- unname(tab["group", "F value"])
df_num <- unname(tab["group", "Df"])
df_den <- unname(tab["Residuals", "Df"])
p_value <- unname(tab["group", "Pr(>F)"])

# Independent check: form between-group and within-group sums of squares.
counts <- as.numeric(table(sample$group))
means <- as.numeric(tapply(sample$y, sample$group, mean))
grand_mean <- mean(sample$y)
ss_between <- sum(counts * (means - grand_mean)^2)
ss_within <- sum((sample$y - means[as.integer(sample$group)])^2)
f_manual <- (ss_between / (k - 1L)) / (ss_within / (n - k))
p_manual <- pf(f_manual, k - 1L, n - k, lower.tail = FALSE)
stopifnot(isTRUE(all.equal(f_stat, f_manual, tolerance = 1e-10)),
          identical(as.integer(df_num), as.integer(k - 1L)),
          identical(as.integer(df_den), as.integer(n - k)),
          isTRUE(all.equal(p_value, p_manual, tolerance = 1e-10)))

result <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = unname(Map(function(term, value) {
    list(term = term, estimate = as.numeric(value), se = NULL, n_obs = n)
  }, c("F", "df_num", "df_den", "p_value"),
  list(f_stat, df_num, df_den, p_value))),
  method_metadata = list(estimator = "one-way ANOVA", vcov = "classical pooled within-group variance")
)
json <- jsonlite::toJSON(result, auto_unbox = TRUE, null = "null", digits = 16)
json <- sub("}$", ',"diagnostics":{}}', json)
writeLines(json, "result.json")

checks <- c(
  sprintf("Input rows: %d; complete finite analysis rows: %d; omitted rows: %d.", nrow(data), n, nrow(data) - n),
  sprintf("Groups: %d; group counts: %s.", k, paste(sprintf("%s=%d", levels(sample$group), counts), collapse = ", ")),
  sprintf("ANOVA: F=%.16g, df_num=%d, df_den=%d, p_value=%.16g.", f_stat, df_num, df_den, p_value),
  sprintf("Independent sums-of-squares check: SS_between=%.16g, SS_within=%.16g, F=%.16g, p_value=%.16g.", ss_between, ss_within, f_manual, p_manual),
  "The ANOVA and independent calculations agree within relative tolerance 1e-10."
)
writeLines(checks, "verification.txt")
