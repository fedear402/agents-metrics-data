data <- read.csv("input.csv", stringsAsFactors = FALSE)
stopifnot(identical(names(data), c("date", "sales", "vix")))
data$date <- as.Date(data$date)
stopifnot(!anyNA(data), all(data$sales > 0), all(data$vix > 0),
          !anyDuplicated(data$date))
data <- data[order(data$date), ]

n_total <- nrow(data)
change <- c(NA_real_, diff(log(data$vix)))
rows <- seq.int(17L, n_total)
X <- cbind("(Intercept)" = 1,
           sapply(seq_len(15L), function(k) change[rows - k]))
colnames(X)[-1L] <- paste0("lag_", seq_len(15L))
y <- log(data$sales[rows])
stopifnot(all(is.finite(X)), all(is.finite(y)))
N <- length(y)
p <- ncol(X)
stopifnot(p == 16L, N > p, qr(X)$rank == p)

fit <- lm.fit(X, y)
b <- as.vector(fit$coefficients)
names(b) <- colnames(X)
u <- as.vector(fit$residuals)
z <- X * u
meat <- crossprod(z)
for (j in seq_len(15L)) {
  cross <- crossprod(z[(j + 1L):N, , drop = FALSE],
                     z[seq_len(N - j), , drop = FALSE])
  meat <- meat + (1 - j / 16) * (cross + t(cross))
}
bread <- solve(crossprod(X))
V <- (N / (N - 16L)) * bread %*% meat %*% bread
lag_indices <- 2:16
cumulative <- sum(b[lag_indices])
cumulative_se <- sqrt(sum(V[lag_indices, lag_indices]))

# An independent implementation checks the complete Bartlett covariance matrix.
model <- lm(y ~ X[, -1L])
V_check <- sandwich::NeweyWest(model, lag = 15L, prewhite = FALSE,
                                adjust = TRUE)
stopifnot(max(abs(unname(V) - unname(V_check))) < 1e-9,
          abs(cumulative - sum(coef(model)[-1L])) < 1e-10,
          N == n_total - 16L)

result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    list(term = "cumulative_response", estimate = unname(cumulative),
         se = unname(cumulative_se), n_obs = N),
    list(term = "lag_1", estimate = unname(b["lag_1"]),
         se = unname(sqrt(V["lag_1", "lag_1"])), n_obs = N),
    list(term = "lag_15", estimate = unname(b["lag_15"]),
         se = unname(sqrt(V["lag_15", "lag_15"])), n_obs = N)
  ),
  method_metadata = list(estimator = "OLS with intercept and 15 lagged log-vix changes",
                         vcov = "Newey-West Bartlett HAC, lag 15, N/(N-16) correction"),
  diagnostics = list()
)
writeLines(jsonlite::toJSON(result, auto_unbox = TRUE, digits = 16,
                            pretty = TRUE), "result.json")
writeLines(c(
  sprintf("Sorted %d unique dates. The first complete row is date %s (source row 17).", n_total, data$date[rows[1L]]),
  sprintf("Regression sample: N = %d = %d total rows - 16; 16 regressors including intercept.", N, n_total),
  "Change at row t = log(vix[t]) - log(vix[t-1]); lag k at row t uses change[t-k].",
  "OLS fit has full column rank. HAC uses Bartlett weights 1-j/16 for j=1,...,15 and factor N/(N-16).",
  sprintf("Independent sandwich::NeweyWest covariance check: maximum absolute matrix difference %.3g.", max(abs(unname(V) - unname(V_check)))),
  sprintf("Independent lm coefficient-sum difference: %.3g.", abs(cumulative - sum(coef(model)[-1L]))),
  sprintf("Cumulative response %.12g, standard error %.12g; lag 1 %.12g; lag 15 %.12g.", cumulative, cumulative_se, b["lag_1"], b["lag_15"])
), "verification.txt")
