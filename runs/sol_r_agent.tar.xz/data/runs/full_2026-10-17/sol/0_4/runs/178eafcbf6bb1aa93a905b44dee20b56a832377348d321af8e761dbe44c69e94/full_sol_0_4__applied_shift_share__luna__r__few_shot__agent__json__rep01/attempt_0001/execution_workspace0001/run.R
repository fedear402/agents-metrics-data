library(jsonlite)

d <- read.csv("input.csv", stringsAsFactors = FALSE)
stopifnot(identical(names(d), c("region_id", "industry_id", "share", "shock", "region_weight", "x", "y")))
stopifnot(!anyNA(d), all(is.finite(as.matrix(d))), !anyDuplicated(d[c("region_id", "industry_id")]))

regions <- sort(unique(d$region_id))
industries <- sort(unique(d$industry_id))
R <- length(regions)
N <- length(industries)
stopifnot(nrow(d) == R * N, N > 2)
ri <- match(d$region_id, regions)
ni <- match(d$industry_id, industries)
shares <- matrix(0, R, N)
shares[cbind(ri, ni)] <- d$share
stopifnot(all(shares >= 0), max(abs(rowSums(shares) - 1)) < 1e-8)

regional <- unique(d[c("region_id", "region_weight", "x", "y")])
stopifnot(nrow(regional) == R)
regional <- regional[match(regions, regional$region_id), ]
shock_data <- unique(d[c("industry_id", "shock")])
stopifnot(nrow(shock_data) == N)
shock <- shock_data$shock[match(industries, shock_data$industry_id)]
e <- regional$region_weight / sum(regional$region_weight)
stopifnot(all(e > 0))
z <- drop(shares %*% shock)
center <- function(v) v - sum(e * v)
y0 <- center(regional$y)
x0 <- center(regional$x)
z0 <- center(z)
s <- drop(crossprod(e, shares))
stopifnot(all(s > 0), abs(sum(s) - 1) < 1e-10)
aggregate_shock <- function(v) drop(crossprod(shares, e * v)) / s
ybar <- aggregate_shock(y0)
xbar <- aggregate_shock(x0)
zbar <- aggregate_shock(z0)

shock_iv <- function(dependent, endogenous) {
  X <- cbind(1, endogenous)
  Z <- cbind(1, shock)
  A <- crossprod(Z, s * X)
  Ainv <- solve(A)
  beta <- drop(Ainv %*% crossprod(Z, s * dependent))

  residual <- drop(dependent - X %*% beta)
  scores <- Z * (s * residual)
  V <- (N / (N - 2)) * Ainv %*% crossprod(scores) %*% t(Ainv)
  c(estimate = unname(beta[2]), se = unname(sqrt(V[2, 2])))
}

effect <- shock_iv(ybar, xbar)
first_stage <- shock_iv(xbar, zbar)
effective <- 1 / sum(s^2)

# Independent regional moment identities check both shock-level IV slopes.
effect_regional <- sum(e * z0 * y0) / sum(e * z0 * x0)
first_stage_regional <- sum(e * z0 * x0) / sum(e * z0^2)
effect_difference <- abs(effect["estimate"] - effect_regional)
stage_difference <- abs(first_stage["estimate"] - first_stage_regional)

stopifnot(effect_difference < 1e-8, stage_difference < 1e-8)

row <- function(term, estimate, se) {
  list(term = term, estimate = unname(as.numeric(estimate)),
       se = if (is.null(se)) NULL else unname(as.numeric(se)), n_obs = N)
}
result <- list(
  task_id = "applied_shift_share", platform = "r",
  estimates = list(row("effect", effect["estimate"], effect["se"]),
                   row("first_stage", first_stage["estimate"], first_stage["se"]),
                   row("effective_shocks", effective, NULL)),
  method_metadata = list(estimator = "Weighted 2SLS via BHJ shock-level IV",
                         vcov = "Shock-level heteroskedastic HC1, N/(N-2), structural IV residuals"),
  diagnostics = list()
)
write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
json_text <- readLines("result.json", warn = FALSE)
json_text <- sub('"diagnostics": []', '"diagnostics": {}', json_text, fixed = TRUE)
writeLines(json_text, "result.json")


checks <- c(
  sprintf("Sample: %d unique regions, %d unique industries, %d complete region-industry rows.", R, N, nrow(d)),
  sprintf("Shares: maximum regional sum error %.3g; shock constant within industry; regional variables constant within region.", max(abs(rowSums(shares) - 1))),
  sprintf("Weights: normalized once across regions; sum(e)=%.16g; sum(s)=%.16g.", sum(e), sum(s)),
  "Estimation: weighted shock-level IV includes intercept. HC1 uses structural residuals, squared weighted scores, and N/(N-2).",
  sprintf("Independent regional IV identity: effect %.12g versus shock slope %.12g; absolute difference %.3g.", effect_regional, effect["estimate"], effect_difference),
  sprintf("Independent regional first-stage identity: slope %.12g versus shock slope %.12g; absolute difference %.3g.", first_stage_regional, first_stage["estimate"], stage_difference),
  sprintf("Output: each row uses n_obs=%d; effective shocks %.12g.", N, effective)
)
writeLines(checks, "verification.txt")
