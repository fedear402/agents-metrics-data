library(jsonlite)

dat <- read.csv("input.csv", stringsAsFactors = FALSE)
stopifnot(all(c("group", "y") %in% names(dat)))
dat <- dat[complete.cases(dat[, c("group", "y")]), c("group", "y")]
dat$group <- factor(dat$group)
stopifnot(nrow(dat) > nlevels(dat$group), nlevels(dat$group) >= 2)

fit <- aov(y ~ group, data = dat)
tab <- summary(fit)[[1]]
n <- nrow(dat)
row <- function(term, value) {
  list(term = term, estimate = unname(as.numeric(value)), se = NA_real_, n_obs = n)
}
out <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = list(
    row("F", tab["group", "F value"]),
    row("df_num", tab["group", "Df"]),
    row("df_den", tab["Residuals", "Df"]),
    row("p_value", tab["group", "Pr(>F)"])
  ),
  method_metadata = list(estimator = "One-way ANOVA", vcov = "classical homoskedastic"),
  diagnostics = structure(list(), names = character(0))
)
write_json(out, "result.json", auto_unbox = TRUE, digits = NA, na = "null")
