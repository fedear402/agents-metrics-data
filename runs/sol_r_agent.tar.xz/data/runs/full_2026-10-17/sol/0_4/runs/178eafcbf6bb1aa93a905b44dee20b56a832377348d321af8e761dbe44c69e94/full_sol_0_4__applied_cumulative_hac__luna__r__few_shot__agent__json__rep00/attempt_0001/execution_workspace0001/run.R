data <- read.csv("input.csv", stringsAsFactors = FALSE)
stopifnot(identical(names(data), c("date", "sales", "vix")))
data$date <- as.Date(data$date)
stopifnot(!anyNA(data), !anyDuplicated(data$date), all(data$sales > 0), all(data$vix > 0))
data <- data[order(data$date), ]
T <- nrow(data)
change <- c(NA_real_, diff(log(data$vix)))
lags <- sapply(1:15, function(k) c(rep(NA_real_, k), head(change, -k)))
colnames(lags) <- paste0("lag_", 1:15)
keep <- complete.cases(lags)
X <- cbind("(Intercept)" = 1, lags[keep, , drop = FALSE])
y <- log(data$sales[keep])
N <- length(y)
p <- ncol(X)
stopifnot(N == T - 16L, p == 16L, all(which(keep) == 17:T))

fit <- lm.fit(X, y)
b <- fit$coefficients
stopifnot(!anyNA(b), fit$rank == p)
scores <- X * as.vector(fit$residuals)
meat <- crossprod(scores)
for (j in 1:15) {
  product <- crossprod(scores[(j + 1):N, , drop = FALSE],
                       scores[1:(N - j), , drop = FALSE])
  meat <- meat + (1 - j / 16) * (product + t(product))
}
bread <- solve(crossprod(X))
V <- N / (N - p) * bread %*% meat %*% bread
contrast <- c(0, rep(1, 15))
estimate <- sum(contrast * b)
se <- sqrt(drop(crossprod(contrast, V %*% contrast)))

# Independent checks use lm and sandwich's HAC implementation.
check_fit <- lm(y ~ X[, -1, drop = FALSE])
stopifnot(max(abs(unname(coef(check_fit)) - unname(b))) < 1e-9)
if (requireNamespace("sandwich", quietly = TRUE)) {
  V_check <- sandwich::NeweyWest(check_fit, lag = 15, prewhite = FALSE,
                                 adjust = TRUE)
  vcov_error <- max(abs(unname(V_check) - unname(V)))
  stopifnot(vcov_error < 1e-8)
  vcov_check <- paste("sandwich::NeweyWest covariance maximum absolute difference:",
                      format(vcov_error, digits = 8))
} else {
  # Matrix identity: the contrast variance equals the weighted score variance.
  projected <- as.vector(scores %*% (bread %*% contrast))
  scalar_meat <- sum(projected^2)
  for (j in 1:15)
    scalar_meat <- scalar_meat + 2 * (1 - j / 16) *
      sum(projected[(j + 1):N] * projected[1:(N - j)])
  scalar_se <- sqrt(N / (N - p) * scalar_meat)
  stopifnot(abs(scalar_se - se) < 1e-9)
  vcov_check <- paste("Independent scalar score variance difference:",
                      format(abs(scalar_se - se), digits = 8))
}

row <- function(term, value, uncertainty)
  list(term = term, estimate = unname(value), se = unname(uncertainty),
       n_obs = as.integer(N))
result <- list(
  task_id = "applied_cumulative_hac", platform = "r",
  estimates = list(
    row("cumulative_response", estimate, se),
    row("lag_1", b[2], sqrt(V[2, 2])),
    row("lag_15", b[16], sqrt(V[16, 16]))),
  method_metadata = list(estimator = "OLS with intercept and 15 trading-observation lags of log VIX change",
                         vcov = "Newey-West Bartlett HAC, maximum lag 15, N/(N-16) correction"),
  diagnostics = jsonlite::parse_json("{}"))
jsonlite::write_json(result, "result.json", auto_unbox = TRUE,
                     digits = 16, pretty = TRUE)
writeLines(c(
  paste("Input rows:", T, "; usable rows:", N, "; expected usable rows:", T - 16L),
  paste("Usable dates:", as.character(data$date[17]), "through", as.character(data$date[T])),
  "Lag construction checked: row t uses log(vix[t-k])-log(vix[t-k-1]), k=1,...,15.",
  "OLS coefficients checked against a separate lm fit; maximum difference below 1e-9.",
  vcov_check,
  "Covariance uses chronological scores, Bartlett weights 1-j/16, and N/(N-16).",
  paste("Cumulative estimate:", format(estimate, digits = 16),
        "; standard error:", format(se, digits = 16))
), "verification.txt")
