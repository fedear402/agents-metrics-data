data <- read.csv("input.csv")
stopifnot(identical(names(data), c("id", "score", "participated", "earnings")))
stopifnot(all(complete.cases(data)), all(data$participated %in% c(0, 1)))

sample <- data[abs(data$score) < 1, ]
score <- sample$score
right <- as.numeric(score >= 0)
weights <- 1 - abs(score)
X <- cbind(intercept = 1, right = right, score = score,
           right_score = right * score)
Y <- as.matrix(sample[, c("earnings", "participated")])

bread <- solve(crossprod(X, weights * X))
coefficients <- bread %*% crossprod(X, weights * Y)
residuals <- Y - X %*% coefficients
contrast <- c(0, 1, 0, 0)
jumps <- drop(contrast %*% coefficients)
loading <- weights * drop(X %*% bread %*% contrast)
influence <- residuals * loading
joint <- crossprod(influence)

gradient <- c(1 / jumps[2], -jumps[1] / jumps[2]^2)
effect <- jumps[1] / jumps[2]
effect_se <- sqrt(drop(t(gradient) %*% joint %*% gradient))
n_obs <- nrow(sample)

row <- function(term, estimate, se) {
  list(term = term, estimate = unname(as.numeric(estimate)),
       se = unname(as.numeric(se)), n_obs = as.integer(n_obs))
}
result <- list(
  task_id = "applied_fuzzy_rd",
  platform = "r",
  estimates = list(
    row("treatment_effect", effect, effect_se),
    row("reduced_form", jumps[1], sqrt(joint[1, 1])),
    row("first_stage", jumps[2], sqrt(joint[2, 2]))
  ),
  method_metadata = list(
    estimator = "Triangular-weighted local linear fuzzy RD, separate slopes",
    vcov = "Joint empirical HC0 sandwich; fixed bandwidth and weights"
  ),
  diagnostics = list(n_left = sum(right == 0), n_right = sum(right == 1))
)
jsonlite::write_json(result, "result.json", auto_unbox = TRUE,
                     digits = 16, pretty = TRUE)
