crosswalk <- read.csv('crosswalk.csv', stringsAsFactors = FALSE)
trade <- read.csv('trade.csv', stringsAsFactors = FALSE)
areas <- read.csv('areas.csv', stringsAsFactors = FALSE)
employment <- read.csv('employment.csv', stringsAsFactors = FALSE)
outcomes <- read.csv('outcomes.csv', stringsAsFactors = FALSE)

trade <- merge(trade, crosswalk, by = 'code', sort = FALSE)
stopifnot(nrow(trade) == 8L, !anyDuplicated(trade[c('period', 'industry')]))
keys <- areas[c('area', 'period', 'vintage')]
industries <- sort(unique(crosswalk$industry))
grid <- merge(keys, data.frame(industry = industries), sort = FALSE)
cells <- merge(grid, employment, by = c('area', 'period', 'vintage', 'industry'),
               all.x = TRUE, sort = FALSE)
cells$employment[is.na(cells$employment)] <- 0
cells <- merge(cells, areas, by = c('area', 'period', 'vintage'), sort = FALSE)
national <- aggregate(employment ~ period + vintage + industry, cells, sum)
names(national)[names(national) == 'employment'] <- 'national_employment'
cells <- merge(cells, national, by = c('period', 'vintage', 'industry'), sort = FALSE)
cells <- merge(cells, trade[c('period', 'industry', 'us_change', 'other_change',
                              'price_index', 'years')],
               by = c('period', 'industry'), sort = FALSE)
stopifnot(nrow(cells) == nrow(areas) * length(industries),
          all(cells$national_employment > 0))
cells$change <- ifelse(cells$vintage == 'base', cells$us_change, cells$other_change)
cells$contribution <- cells$employment / cells$total_employment *
  (cells$change / cells$national_employment) /
  (cells$price_index / 100) / 1000 * (10 / cells$years)
exposures <- aggregate(contribution ~ area + period + vintage, cells, sum)
wide <- reshape(exposures, idvar = c('area', 'period'), timevar = 'vintage',
                direction = 'wide')
names(wide)[names(wide) == 'contribution.base'] <- 'x'
names(wide)[names(wide) == 'contribution.early'] <- 'z'
sample <- merge(outcomes, wide, by = c('area', 'period'), sort = FALSE)
weights <- areas[areas$vintage == 'base', c('area', 'period', 'population')]
sample <- merge(sample, weights, by = c('area', 'period'), sort = FALSE)
sample <- sample[order(sample$period, sample$area), ]
stopifnot(nrow(sample) == 72L, !anyNA(sample), all(sample$population > 0))

C <- cbind(intercept = 1, period = sample$period, control = sample$control)
X <- cbind(C, x = sample$x)
Z <- cbind(C, z = sample$z)
sw <- sqrt(sample$population)
Xw <- X * sw
Zw <- Z * sw
yw <- sample$change_pp * sw
Xhat <- qr.fitted(qr(Zw), Xw)
beta <- qr.coef(qr(Xhat), yw)
stopifnot(!anyNA(beta), qr(Xhat)$rank == 4L)

get_value <- function(column, area, period) {
  value <- sample[sample$area == area & sample$period == period, column]
  stopifnot(length(value) == 1L)
  unname(value)
}
values <- c(iv_slope = unname(beta['x']),
            exposure_area0_period0 = get_value('x', 0, 0),
            exposure_area0_period1 = get_value('x', 0, 1),
            instrument_area0_period0 = get_value('z', 0, 0))
estimates <- lapply(names(values), function(term) {
  list(term = term, estimate = unname(values[[term]]), se = NULL,
       n_obs = as.integer(nrow(sample)))
})
result <- list(task_id = 'applied_multivintage_trade_iv', platform = 'r',
               estimates = estimates,
               method_metadata = list(estimator = 'weighted 2SLS',
                 outcome = 'change_pp', endogenous = 'x', instrument = 'z',
                 exogenous = c('intercept', 'period', 'control'),
                 weight = 'base-vintage population'),
               diagnostics = list(n_obs = as.integer(nrow(sample)),
                 n_areas = as.integer(length(unique(sample$area))),
                 n_periods = as.integer(length(unique(sample$period))),
                 first_stage_rank = as.integer(qr(Zw)$rank)))
jsonlite::write_json(result, 'result.json', auto_unbox = TRUE, pretty = TRUE,
                     digits = 16, null = 'null')
