dat <- read.csv("input.csv")
stopifnot(all(c("score", "participated", "earnings") %in% names(dat)))
keep <- is.finite(dat$score) & is.finite(dat$participated) &
  is.finite(dat$earnings) & abs(dat$score) < 1
d <- dat[keep, , drop = FALSE]
n <- nrow(d)
stopifnot(n > 4, all(d$participated %in% c(0, 1)))

right <- as.numeric(d$score >= 0)
X <- cbind(intercept = 1, right = right, score = d$score,
           right_score = right * d$score)
w <- 1 - abs(d$score)
Y <- cbind(earnings = d$earnings, participated = d$participated)
A <- solve(crossprod(X, w * X))
B <- A %*% crossprod(X, w * Y)
U <- Y - X %*% B
cvec <- c(0, 1, 0, 0)
influence_scale <- as.vector(w * (X %*% (A %*% cvec)))
influence <- U * influence_scale
V <- crossprod(influence)  # Joint HC0 covariance, with fixed weights.
rf <- unname(cvec %*% B[, 1])
fs <- unname(cvec %*% B[, 2])
stopifnot(is.finite(fs), fs != 0)
te <- rf / fs
grad <- c(1 / fs, -rf / fs^2)
se <- sqrt(c(as.numeric(t(grad) %*% V %*% grad), V[1, 1], V[2, 2]))
est <- c(te, rf, fs)
terms <- c("treatment_effect", "reduced_form", "first_stage")
rows <- vapply(seq_along(est), function(i) {
  sprintf('{"term":"%s","estimate":%.17g,"se":%.17g,"n_obs":%d}',
          terms[i], est[i], se[i], n)
}, character(1))
json <- paste0('{"task_id":"applied_fuzzy_rd","platform":"r",',
               '"estimates":[', paste(rows, collapse = ","), '],',
               '"method_metadata":{"estimator":"weighted local-linear fuzzy RD Wald ratio",',
               '"vcov":"joint heteroskedasticity-robust HC0 delta method"},',
               '"diagnostics":{}}')
writeLines(json, "result.json")
