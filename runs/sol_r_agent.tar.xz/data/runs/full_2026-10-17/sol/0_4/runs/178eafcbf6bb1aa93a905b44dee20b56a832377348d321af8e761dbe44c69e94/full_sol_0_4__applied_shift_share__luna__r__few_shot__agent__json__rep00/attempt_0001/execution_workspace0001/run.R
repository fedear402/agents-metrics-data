library(jsonlite)

d <- read.csv("input.csv", stringsAsFactors = FALSE)
required <- c("region_id", "industry_id", "share", "shock", "region_weight", "x", "y")
stopifnot(all(required %in% names(d)), all(complete.cases(d)),
          !anyDuplicated(d[c("region_id", "industry_id")]))

regions <- sort(unique(d$region_id))
industries <- sort(unique(d$industry_id))
R <- length(regions)
N <- length(industries)
ri <- match(d$region_id, regions)
ni <- match(d$industry_id, industries)
S <- matrix(0, R, N)
S[cbind(ri, ni)] <- d$share
stopifnot(all(d$share >= 0), max(abs(rowSums(S) - 1)) < 1e-10)

regional <- function(name) {
  values <- split(d[[name]], ri)
  stopifnot(all(vapply(values, function(v) max(v) - min(v) < 1e-10, logical(1))))
  vapply(values, `[`, numeric(1), 1)
}
shock_values <- split(d$shock, ni)
stopifnot(all(vapply(shock_values, function(v) max(v) - min(v) < 1e-10, logical(1))))
g <- vapply(shock_values, `[`, numeric(1), 1)
w <- regional("region_weight")
stopifnot(all(w > 0))
e <- w / sum(w)
x <- regional("x")
y <- regional("y")
z <- drop(S %*% g)

center <- function(v) v - sum(e * v)
y0 <- center(y)
x0 <- center(x)
z0 <- center(z)
s <- drop(crossprod(e, S))
stopifnot(all(s > 0), abs(sum(s) - 1) < 1e-10)
aggregate_exposure <- function(v) drop(crossprod(S, e * v)) / s
yb <- aggregate_exposure(y0)
xb <- aggregate_exposure(x0)
zb <- aggregate_exposure(z0)

shock_iv <- function(dependent, endogenous) {
  X <- cbind(1, endogenous)
  Z <- cbind(1, g)
  A <- crossprod(Z, s * X)
  beta <- drop(solve(A, crossprod(Z, s * dependent)))
  u <- drop(dependent - X %*% beta)
  scores <- Z * as.vector(s * u)
  Ainv <- solve(A)
  V <- N / (N - 2) * Ainv %*% crossprod(scores) %*% t(Ainv)
  c(estimate = beta[2], se = sqrt(V[2, 2]))
}
effect <- shock_iv(yb, xb)
first_stage <- shock_iv(xb, zb)

# Independent regional identities verify both shock-level slopes.
regional_effect <- sum(e * z0 * y0) / sum(e * z0 * x0)
regional_first_stage <- sum(e * z0 * x0) / sum(e * z0^2)
stopifnot(abs(effect[1] - regional_effect) < 1e-10,
          abs(first_stage[1] - regional_first_stage) < 1e-10,
          max(abs(c(sum(s * yb), sum(s * xb), sum(s * zb)))) < 1e-10)

row <- function(term, estimate, se) {
  list(term = term, estimate = unname(as.numeric(estimate)),
       se = if (is.null(se)) NULL else unname(as.numeric(se)), n_obs = N)
}
result <- list(
  task_id = "applied_shift_share", platform = "r",
  estimates = list(row("effect", effect[1], effect[2]),
                   row("first_stage", first_stage[1], first_stage[2]),
                   row("effective_shocks", 1 / sum(s^2), NULL)),
  method_metadata = list(estimator = "Weighted regional 2SLS; equivalent exposure-weighted shock-level IV",
                         vcov = "Shock-level structural-score HC1, N/(N-2), no clustering"),
  diagnostics = list()
)
write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
