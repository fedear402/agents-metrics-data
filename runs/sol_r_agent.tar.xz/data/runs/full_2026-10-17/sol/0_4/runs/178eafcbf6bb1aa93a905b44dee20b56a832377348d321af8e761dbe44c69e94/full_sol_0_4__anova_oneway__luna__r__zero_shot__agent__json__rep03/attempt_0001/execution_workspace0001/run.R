data <- read.csv("input.csv", stringsAsFactors = FALSE)
stopifnot(identical(names(data), c("group", "y")))
data <- data[complete.cases(data[, c("group", "y")]), , drop = FALSE]
data$group <- factor(data$group)
stopifnot(is.numeric(data$y), nlevels(data$group) >= 2L)

fit <- aov(y ~ group, data = data)
tab <- summary(fit)[[1L]]
n <- nrow(data)
values <- c(F = tab[1L, "F value"],
            df_num = tab[1L, "Df"],
            df_den = tab[2L, "Df"],
            p_value = tab[1L, "Pr(>F)"])
stopifnot(all(is.finite(values)), n == sum(!is.na(fit$residuals)))

entry <- function(term) {
  sprintf('{"term":"%s","estimate":%.17g,"se":null,"n_obs":%d}',
          term, unname(values[term]), n)
}
json <- paste0(
  '{"task_id":"anova_oneway","platform":"r","estimates":[',
  paste(vapply(names(values), entry, character(1L)), collapse = ","),
  '],"method_metadata":{"estimator":"one-way ANOVA","vcov":"classical pooled within-group variance"},"diagnostics":{}}'
)
writeLines(json, "result.json")
