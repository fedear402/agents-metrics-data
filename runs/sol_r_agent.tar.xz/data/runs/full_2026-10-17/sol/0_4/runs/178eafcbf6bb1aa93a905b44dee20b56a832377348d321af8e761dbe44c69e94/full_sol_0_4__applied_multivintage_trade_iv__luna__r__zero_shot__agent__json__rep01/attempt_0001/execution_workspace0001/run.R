library(jsonlite)

crosswalk <- read.csv("crosswalk.csv", stringsAsFactors = FALSE)
trade <- read.csv("trade.csv", stringsAsFactors = FALSE)
areas <- read.csv("areas.csv", stringsAsFactors = FALSE)
employment <- read.csv("employment.csv", stringsAsFactors = FALSE)
outcomes <- read.csv("outcomes.csv", stringsAsFactors = FALSE)

stopifnot(length(unique(crosswalk$industry)) == 4L, !anyDuplicated(crosswalk$code))
trade <- merge(trade, crosswalk, by = "code", all.x = TRUE, sort = FALSE)
stopifnot(!anyNA(trade$industry), !anyDuplicated(trade[c("period", "industry")]))

grid <- merge(areas[c("area", "period", "vintage", "total_employment", "population")],
              unique(crosswalk["industry"]), by = NULL)
cells <- merge(grid, employment, by = c("area", "period", "vintage", "industry"),
               all.x = TRUE, sort = FALSE)
cells$employment[is.na(cells$employment)] <- 0
stopifnot(nrow(cells) == nrow(areas) * 4L,
          !anyDuplicated(cells[c("area", "period", "vintage", "industry")]))
national <- aggregate(employment ~ period + vintage + industry, cells, sum)
names(national)[4] <- "national_employment"
cells <- merge(cells, national, by = c("period", "vintage", "industry"))
cells <- merge(cells, trade, by = c("period", "industry"))
stopifnot(nrow(cells) == nrow(grid), all(cells$national_employment > 0))

cells$component <- with(cells,
  (employment / total_employment) *
  (ifelse(vintage == "base", us_change, other_change) / national_employment) /
  (price_index / 100) / 1000 * (10 / years))
exposure <- aggregate(component ~ area + period + vintage, cells, sum)
wide <- reshape(exposure, idvar = c("area", "period"), timevar = "vintage",
                direction = "wide")
names(wide)[names(wide) == "component.base"] <- "x"
names(wide)[names(wide) == "component.early"] <- "z"
base_areas <- areas[areas$vintage == "base", c("area", "period", "population")]
sample <- merge(outcomes, wide, by = c("area", "period"))
sample <- merge(sample, base_areas, by = c("area", "period"))
sample <- sample[order(sample$period, sample$area), ]
stopifnot(nrow(sample) == 72L, !anyNA(sample), all(sample$population > 0))

X <- model.matrix(~ period + control + x, sample)
Z <- model.matrix(~ period + control + z, sample)
w <- sample$population
y <- sample$change_pp
ZWZ <- crossprod(Z, w * Z)
ZWX <- crossprod(Z, w * X)
ZWy <- crossprod(Z, w * y)
beta <- solve(crossprod(ZWX, solve(ZWZ, ZWX)),
              crossprod(ZWX, solve(ZWZ, ZWy)))
iv_slope <- unname(beta["x", 1])

get_value <- function(column, area, period) {
  value <- sample[sample$area == area & sample$period == period, column]
  stopifnot(length(value) == 1L)
  unname(value)
}
estimates <- list(
  list(term = "iv_slope", estimate = iv_slope, se = NULL, n_obs = 72L),
  list(term = "exposure_area0_period0", estimate = get_value("x", 0, 0), se = NULL, n_obs = 72L),
  list(term = "exposure_area0_period1", estimate = get_value("x", 0, 1), se = NULL, n_obs = 72L),
  list(term = "instrument_area0_period0", estimate = get_value("z", 0, 0), se = NULL, n_obs = 72L)
)
result <- list(
  task_id = "applied_multivintage_trade_iv", platform = "r", estimates = estimates,
  method_metadata = list(estimator = "population-weighted 2SLS",
                         endogenous = "x", instrument = "z",
                         exogenous = c("intercept", "period", "control"),
                         exposure_unit = "thousands of real dollars per worker per decade"),
  diagnostics = list(estimation_rows = nrow(sample),
                     areas = length(unique(sample$area)),
                     periods = length(unique(sample$period)),
                     industries = length(unique(crosswalk$industry)),
                     moment_max_abs = max(abs(crossprod(Z, w * (y - X %*% beta)))))
)
write_json(result, "result.json", auto_unbox = TRUE, pretty = TRUE, digits = 15,
           null = "null")
