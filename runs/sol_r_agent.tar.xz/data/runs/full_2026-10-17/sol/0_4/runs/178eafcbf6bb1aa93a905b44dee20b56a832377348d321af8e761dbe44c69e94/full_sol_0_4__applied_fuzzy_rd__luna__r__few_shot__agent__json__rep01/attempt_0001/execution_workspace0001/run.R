library(jsonlite)

dat <- read.csv("input.csv")
stopifnot(all(c("id", "score", "participated", "earnings") %in% names(dat)))
stopifnot(!anyNA(dat[, c("score", "participated", "earnings")]))
keep <- abs(dat$score) < 1
d <- dat[keep, ]
n <- nrow(d)
stopifnot(n > 4, all(d$participated %in% c(0, 1)))
w <- 1 - abs(d$score)
right <- as.numeric(d$score >= 0)
X <- cbind(intercept = 1, right = right, score = d$score,
           right_score = right * d$score)
Y <- cbind(earnings = d$earnings, participated = d$participated)
bread <- solve(crossprod(X, w * X))
beta <- bread %*% crossprod(X, w * Y)
resid <- Y - X %*% beta
contrast <- c(0, 1, 0, 0)
jumps <- drop(contrast %*% beta)
loading <- w * drop(X %*% bread %*% contrast)
influence <- resid * loading
joint <- crossprod(influence)
gradient <- c(1 / jumps[2], -jumps[1] / jumps[2]^2)
ratio <- jumps[1] / jumps[2]
ratio_var <- drop(t(gradient) %*% joint %*% gradient)
stopifnot(is.finite(ratio), ratio_var >= 0)
row <- function(term, estimate, se) {
  list(term = term, estimate = unname(as.numeric(estimate)),
       se = unname(as.numeric(se)), n_obs = as.integer(n))
}
result <- list(
  task_id = "applied_fuzzy_rd", platform = "r",
  estimates = list(
    row("treatment_effect", ratio, sqrt(ratio_var)),
    row("reduced_form", jumps[1], sqrt(joint[1, 1])),
    row("first_stage", jumps[2], sqrt(joint[2, 2]))
  ),
  method_metadata = list(
    estimator = "Weighted local-linear fuzzy RD Wald ratio, separate slopes at cutoff zero, triangular kernel, bandwidth one",
    vcov = "Joint empirical HC0 sandwich for reduced form and first stage; delta method for ratio; no degrees-of-freedom correction"
  ),
  diagnostics = list()
)
write_json(result, "result.json", auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
