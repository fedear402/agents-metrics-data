d <- read.csv("input.csv", stringsAsFactors = FALSE)
stopifnot(all(c("region_id", "industry_id", "share", "shock", "region_weight", "x", "y") %in% names(d)), !anyNA(d))
regions <- unique(d$region_id)
industries <- unique(d$industry_id)
R <- length(regions)
N <- length(industries)
stopifnot(nrow(d) == R * N, !anyDuplicated(d[c("region_id", "industry_id")]))
ri <- match(d$region_id, regions)
ni <- match(d$industry_id, industries)
S <- matrix(0, R, N)
S[cbind(ri, ni)] <- d$share
stopifnot(max(abs(rowSums(S) - 1)) < 1e-8)
get_region <- function(col) {
  out <- d[[col]][match(regions, d$region_id)]
  stopifnot(all(abs(d[[col]] - out[ri]) < 1e-10))
  out
}
w <- get_region("region_weight")
x <- get_region("x")
y <- get_region("y")
g <- d$shock[match(industries, d$industry_id)]
stopifnot(all(abs(d$shock - g[ni]) < 1e-10), all(w > 0), all(d$share >= 0))
e <- w / sum(w)
z <- as.vector(S %*% g)
center <- function(v) v - sum(e * v)
y0 <- center(y)
x0 <- center(x)
z0 <- center(z)
s <- as.vector(crossprod(S, e))
stopifnot(all(s > 0), abs(sum(s) - 1) < 1e-10)
aggregate_residual <- function(v) as.vector(crossprod(S, e * v)) / s
ybar <- aggregate_residual(y0)
xbar <- aggregate_residual(x0)
zbar <- aggregate_residual(z0)
shock_data <- data.frame(ybar, xbar, zbar, g, s)
effect_fit <- ivreg::ivreg(ybar ~ xbar | g, data = shock_data, weights = s)
first_fit <- ivreg::ivreg(xbar ~ zbar | g, data = shock_data, weights = s)
effect <- unname(coef(effect_fit)["xbar"])
first_stage <- unname(coef(first_fit)["zbar"])
effect_se <- unname(sqrt(diag(sandwich::vcovHC(effect_fit, type = "HC1")))["xbar"])
first_se <- unname(sqrt(diag(sandwich::vcovHC(first_fit, type = "HC1")))["zbar"])
# The weighted regional IV moment has the same slope as the shock-level moment.
regional_effect <- sum(e * z0 * y0) / sum(e * z0 * x0)
regional_first <- sum(e * z0 * x0) / sum(e * z0 * z0)
stopifnot(abs(effect - regional_effect) < 1e-9, abs(first_stage - regional_first) < 1e-9)
result <- list(
  task_id = "applied_shift_share",
  platform = "r",
  estimates = list(
    list(term = "effect", estimate = effect, se = effect_se, n_obs = N),
    list(term = "first_stage", estimate = first_stage, se = first_se, n_obs = N),
    list(term = "effective_shocks", estimate = 1 / sum(s^2), se = NULL, n_obs = N)
  ),
  method_metadata = list(estimator = "Weighted regional 2SLS via BHJ shock-level IV", vcov = "Shock-level heteroskedasticity-robust HC1, N/(N-2), analytic weights"),
  diagnostics = jsonlite::parse_json("{}")
)
jsonlite::write_json(result, "result.json", pretty = TRUE, auto_unbox = TRUE, digits = NA, null = "null")
cat(sprintf("R=%d N=%d effect=%.12g SE=%.12g first=%.12g SE=%.12g\n", R, N, effect, effect_se, first_stage, first_se))
