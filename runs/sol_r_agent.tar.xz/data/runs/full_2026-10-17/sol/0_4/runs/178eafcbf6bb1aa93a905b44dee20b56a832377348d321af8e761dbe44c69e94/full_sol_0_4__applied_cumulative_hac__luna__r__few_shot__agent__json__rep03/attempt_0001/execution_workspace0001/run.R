options(digits = 16)
data <- read.csv("input.csv", stringsAsFactors = FALSE)
stopifnot(identical(names(data), c("date", "sales", "vix")))
data$date <- as.Date(data$date)
stopifnot(!anyNA(data), all(data$sales > 0), all(data$vix > 0))
data <- data[order(data$date), ]
stopifnot(!anyDuplicated(data$date))

log_vix <- log(data$vix)
change <- c(NA_real_, diff(log_vix))
lags <- 1:15
lagged <- sapply(lags, function(k) c(rep(NA_real_, k), head(change, -k)))
colnames(lagged) <- paste0("lag_", lags)
keep <- complete.cases(lagged)
stopifnot(identical(which(keep), seq.int(17L, nrow(data))))
y <- log(data$sales[keep])
X <- cbind("(Intercept)" = 1, lagged[keep, , drop = FALSE])
N <- nrow(X)
p <- ncol(X)
stopifnot(p == 16L, N > p)

fit <- lm.fit(X, y)
beta <- fit$coefficients
scores <- X * as.vector(fit$residuals)
meat <- crossprod(scores)
for (j in 1:15) {
  product <- crossprod(scores[(j + 1):N, , drop = FALSE],
                       scores[1:(N - j), , drop = FALSE])
  meat <- meat + (1 - j / 16) * (product + t(product))
}
bread <- solve(crossprod(X))
V <- (N / (N - p)) * bread %*% meat %*% bread
contrast <- c(0, rep(1, 15))
cumulative <- sum(contrast * beta)
cumulative_se <- sqrt(drop(t(contrast) %*% V %*% contrast))

# Independent calculation: explicit time-weight matrix and QR coefficients.
weights <- outer(seq_len(N), seq_len(N), function(a, b) {
  distance <- abs(a - b)
  ifelse(distance <= 15, 1 - distance / 16, 0)
})
V_check <- (N / (N - p)) * bread %*%
  crossprod(scores, weights %*% scores) %*% bread
beta_check <- qr.solve(X, y)
stopifnot(max(abs(beta - beta_check)) < 1e-9,
          max(abs(V - V_check)) < 1e-9,
          abs(cumulative - sum(beta[-1])) < 1e-12,
          abs(cumulative_se^2 - sum(V[-1, -1])) < 1e-9)

row <- function(term, estimate, se) {
  list(term = term, estimate = unname(as.numeric(estimate)),
       se = unname(as.numeric(se)), n_obs = as.integer(N))
}
result <- list(
  task_id = "applied_cumulative_hac",
  platform = "r",
  estimates = list(
    row("cumulative_response", cumulative, cumulative_se),
    row("lag_1", beta[2], sqrt(V[2, 2])),
    row("lag_15", beta[16], sqrt(V[16, 16]))
  ),
  method_metadata = list(estimator = "OLS with intercept and 15 lagged log VIX changes",
                         vcov = "Newey-West Bartlett HAC, maximum lag 15, N/(N-16) correction"),
  diagnostics = jsonlite::fromJSON("{}", simplifyVector = FALSE)
)
jsonlite::write_json(result, "result.json", auto_unbox = TRUE,
                     digits = 16, pretty = TRUE)

checks <- c(
  sprintf("Input rows: %d; sorted dates: %s to %s.", nrow(data),
          min(data$date), max(data$date)),
  sprintf("Complete sample: rows 17 through %d; N = %d; parameters = %d.",
          nrow(data), N, p),
  "Lag k at row t equals log(vix[t-k]) minus log(vix[t-k-1]); weekends use the next observed row.",
  "OLS coefficients agree with independent QR solve within 1e-9.",
  "HAC covariance agrees with an explicit Bartlett time-weight matrix within 1e-9.",
  "Cumulative coefficient equals the sum of lags 1 through 15 within 1e-12.",
  "Cumulative variance equals the sum of all slope covariance entries within 1e-9.",
  sprintf("Cumulative estimate: %.12g; standard error: %.12g.", cumulative, cumulative_se)
)
writeLines(checks, "verification.txt")
