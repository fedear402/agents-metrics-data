crosswalk <- read.csv('crosswalk.csv', stringsAsFactors = FALSE)
trade <- read.csv('trade.csv', stringsAsFactors = FALSE)
areas <- read.csv('areas.csv', stringsAsFactors = FALSE)
employment <- read.csv('employment.csv', stringsAsFactors = FALSE)
outcomes <- read.csv('outcomes.csv', stringsAsFactors = FALSE)

stopifnot(nrow(outcomes) == 72L, nrow(crosswalk) == nrow(trade),
          !anyDuplicated(crosswalk$code),
          !anyDuplicated(trade[c('period','code')]),
          !anyDuplicated(areas[c('area','period','vintage')]),
          !anyDuplicated(employment[c('area','period','vintage','industry')]),
          !anyDuplicated(outcomes[c('area','period')]))
shocks <- merge(trade, crosswalk, by = 'code', sort = FALSE)
stopifnot(nrow(shocks) == nrow(trade), all(table(shocks$period) == 4L),
          !anyDuplicated(shocks[c('period','industry')]))
industries <- unique(shocks[c('period','industry')])
cells <- merge(areas, industries, by = 'period', sort = FALSE)
cells <- merge(cells, employment, by = c('area','period','vintage','industry'),
               all.x = TRUE, sort = FALSE)
stopifnot(nrow(cells) == 4L * nrow(areas))
cells$employment[is.na(cells$employment)] <- 0
national <- aggregate(employment ~ period + vintage + industry, cells, sum)
names(national)[4] <- 'national_employment'
cells <- merge(cells, national, by = c('period','vintage','industry'), sort = FALSE)
cells <- merge(cells, shocks, by = c('period','industry'), sort = FALSE)
stopifnot(nrow(cells) == 4L * nrow(areas), all(cells$national_employment > 0),
          all(cells$total_employment > 0), all(cells$price_index > 0),
          all(cells$years > 0))
cells$shock <- ifelse(cells$vintage == 'base', cells$us_change, cells$other_change)
cells$contribution <- (cells$employment / cells$total_employment) *
  (cells$shock / cells$national_employment) / (cells$price_index / 100) /
  1000 * (10 / cells$years)
exposure <- aggregate(contribution ~ area + period + vintage, cells, sum)
wide <- reshape(exposure, idvar = c('area','period'), timevar = 'vintage', direction = 'wide')
names(wide)[names(wide) == 'contribution.base'] <- 'x'
names(wide)[names(wide) == 'contribution.early'] <- 'z'
base <- areas[areas$vintage == 'base', c('area','period','population')]
d <- merge(outcomes, wide, by = c('area','period'), sort = FALSE)
d <- merge(d, base, by = c('area','period'), sort = FALSE)
d <- d[order(d$period,d$area), ]
stopifnot(nrow(d) == 72L, !anyNA(d), all(d$population > 0))

# Weighted 2SLS: both stages use the base-vintage population weight.
X <- cbind(intercept = 1, period = d$period, control = d$control, x = d$x)
Z <- cbind(intercept = 1, period = d$period, control = d$control, z = d$z)
w <- d$population
ZX <- crossprod(Z, w * X)
ZZ <- crossprod(Z, w * Z)
Zy <- crossprod(Z, w * d$change_pp)
beta <- solve(t(ZX) %*% solve(ZZ, ZX), t(ZX) %*% solve(ZZ, Zy))
iv_slope <- unname(beta[4,1])
get_value <- function(col, area, period) {
  v <- d[d$area == area & d$period == period, col]
  stopifnot(length(v) == 1L)
  unname(v)
}
vals <- c(iv_slope = iv_slope,
          exposure_area0_period0 = get_value('x',0,0),
          exposure_area0_period1 = get_value('x',0,1),
          instrument_area0_period0 = get_value('z',0,0))

# Independent check: partial out exogenous columns, then use the scalar IV ratio.
Q <- X[,1:3]
weighted_residual <- function(v) as.vector(v - Q %*% solve(crossprod(Q,w*Q), crossprod(Q,w*v)))
rx <- weighted_residual(d$x)
rz <- weighted_residual(d$z)
ry <- weighted_residual(d$change_pp)
iv_fwl <- sum(w * rz * ry) / sum(w * rz * rx)
stopifnot(isTRUE(all.equal(iv_slope, iv_fwl, tolerance = 1e-10)))
# Check area 0 contributions directly from its four industry rows.
manual <- vapply(0:1, function(p) {
  a <- cells[cells$area == 0 & cells$period == p & cells$vintage == 'base', ]
  sum((a$employment/a$total_employment) * (a$us_change/a$national_employment) /
      (a$price_index/100)/1000*(10/a$years))
}, numeric(1))
stopifnot(isTRUE(all.equal(unname(vals[c('exposure_area0_period0','exposure_area0_period1')]),
                           unname(manual), tolerance = 1e-12)))

estimates <- lapply(names(vals), function(term) list(term = term,
  estimate = unname(vals[[term]]), se = NULL, n_obs = 72L))
result <- list(task_id = 'applied_multivintage_trade_iv', platform = 'r',
  estimates = estimates,
  method_metadata = list(estimator = 'population-weighted 2SLS',
    endogenous = 'x', instrument = 'z',
    exogenous = c('intercept','period','control'),
    exposure_units = 'thousands of real dollars per worker per decade',
    missing_employment_cells = 'zero',
    national_employment = 'sum across all supplied areas by period, vintage, industry'),
  diagnostics = list(estimation_rows = nrow(d), industries = 4L,
    missing_employment_cells_filled = sum(is.na(merge(
      merge(areas, industries, by = 'period'), employment,
      by = c('area','period','vintage','industry'), all.x = TRUE)$employment)),
    weighted_fwl_iv_slope = iv_fwl,
    max_area0_exposure_check_error = max(abs(manual - vals[c('exposure_area0_period0','exposure_area0_period1')]))))
jsonlite::write_json(result, 'result.json', auto_unbox = TRUE, pretty = TRUE,
                     digits = 16, null = 'null')
writeLines(c(
  'Inputs: all five specified CSV files were read. Trade codes joined one-to-one to industries.',
  sprintf('Sample: %d area-period rows; %d industries per period; %d missing employment cells filled with zero.',
    nrow(d), 4L, result$diagnostics$missing_employment_cells_filled),
  'Construction: national employment sums completed area cells by period, vintage, and industry.',
  'Estimator: population-weighted 2SLS with intercept, period, and control in both matrices.',
  sprintf('Independent weighted residual IV slope: %.16g; matrix 2SLS slope: %.16g; absolute difference: %.3g.',
    iv_fwl, iv_slope, abs(iv_fwl-iv_slope)),
  sprintf('Independent direct area 0 exposure sums: period 0 %.16g; period 1 %.16g; maximum difference: %.3g.',
    manual[1], manual[2], result$diagnostics$max_area0_exposure_check_error),
  'Uncertainty: no uncertainty measure was requested; se is null for each estimate.'
), 'verification.txt')
print(vals, digits = 16)
