library(jsonlite)

dat <- read.csv("input.csv", stringsAsFactors = FALSE)
stopifnot(all(c("group", "y") %in% names(dat)))
dat <- dat[complete.cases(dat[, c("group", "y")]), c("group", "y")]
dat$group <- factor(dat$group)
stopifnot(is.numeric(dat$y), nlevels(dat$group) >= 2L)

fit <- aov(y ~ group, data = dat)
tab <- summary(fit)[[1L]]
n <- nobs(fit)
values <- c(
  F = tab[1L, "F value"],
  df_num = tab[1L, "Df"],
  df_den = tab[2L, "Df"],
  p_value = tab[1L, "Pr(>F)"]
)
out <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = lapply(names(values), function(term) {
    list(term = term, estimate = unname(as.numeric(values[[term]])),
         se = NA_real_, n_obs = as.integer(n))
  }),
  method_metadata = list(estimator = "One-way ANOVA", vcov = "classical pooled within-group variance"),
  diagnostics = structure(list(), names = character(0))
)
write_json(out, "result.json", auto_unbox = TRUE, digits = 16, na = "null")
