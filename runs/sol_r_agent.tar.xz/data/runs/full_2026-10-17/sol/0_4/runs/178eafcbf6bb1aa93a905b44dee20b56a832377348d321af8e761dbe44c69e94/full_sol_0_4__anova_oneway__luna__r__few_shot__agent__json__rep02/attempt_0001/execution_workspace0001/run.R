library(jsonlite)

data <- read.csv("input.csv", stringsAsFactors = FALSE)
stopifnot(all(c("group", "y") %in% names(data)))
sample <- data[complete.cases(data[c("group", "y")]), c("group", "y")]
sample$group <- factor(sample$group)
stopifnot(is.numeric(sample$y), nlevels(sample$group) >= 2L)

fit <- aov(y ~ group, data = sample)
table <- summary(fit)[[1L]]
n <- nrow(sample)
value <- function(term, estimate) {
  list(term = term, estimate = unname(as.numeric(estimate)), se = NA_real_, n_obs = n)
}
out <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = list(
    value("F", table["group", "F value"]),
    value("df_num", table["group", "Df"]),
    value("df_den", table["Residuals", "Df"]),
    value("p_value", table["group", "Pr(>F)"])
  ),
  method_metadata = list(estimator = "One-way ANOVA", vcov = "classical pooled residual variance"),
  diagnostics = structure(list(), names = character(0))
)
write_json(out, "result.json", auto_unbox = TRUE, digits = NA, na = "null")
