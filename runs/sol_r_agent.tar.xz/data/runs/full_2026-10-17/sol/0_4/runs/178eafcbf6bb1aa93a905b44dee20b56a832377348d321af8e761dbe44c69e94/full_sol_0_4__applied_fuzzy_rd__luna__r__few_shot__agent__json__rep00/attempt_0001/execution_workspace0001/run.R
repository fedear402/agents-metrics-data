data <- read.csv("input.csv")
stopifnot(all(c("id", "score", "participated", "earnings") %in% names(data)))
sample <- data[is.finite(data$score) & abs(data$score) < 1, ]
stopifnot(nrow(sample) > 0, all(is.finite(sample$earnings)),
          all(is.finite(sample$participated)))

right <- as.numeric(sample$score >= 0)
weight <- 1 - abs(sample$score)
X <- cbind(intercept = 1, right = right, score = sample$score,
           right_score = right * sample$score)
Y <- cbind(earnings = sample$earnings, participated = sample$participated)
bread <- solve(crossprod(X, weight * X))
beta <- bread %*% crossprod(X, weight * Y)
residual <- Y - X %*% beta
contrast <- c(0, 1, 0, 0)
jump <- drop(contrast %*% beta)
loading <- weight * drop(X %*% bread %*% contrast)
influence <- loading * residual
joint <- crossprod(influence)
effect <- jump[1] / jump[2]
gradient <- c(1 / jump[2], -jump[1] / jump[2]^2)
effect_se <- sqrt(drop(t(gradient) %*% joint %*% gradient))

row <- function(term, estimate, se, n) {
  list(term = term, estimate = unname(as.numeric(estimate)),
       se = unname(as.numeric(se)), n_obs = as.integer(n))
}
result <- list(
  task_id = "applied_fuzzy_rd", platform = "r",
  estimates = list(
    row("treatment_effect", effect, effect_se, nrow(sample)),
    row("reduced_form", jump[1], sqrt(joint[1, 1]), nrow(sample)),
    row("first_stage", jump[2], sqrt(joint[2, 2]), nrow(sample))
  ),
  method_metadata = list(estimator = "Triangular-weighted local-linear fuzzy RD, separate slopes by side",
                         vcov = "Joint observation-level HC0 sandwich; delta method for ratio"),
  diagnostics = list()
)
jsonlite::write_json(result, "result.json", auto_unbox = TRUE,
                     digits = 16, pretty = TRUE, empty = "object")
output <- readLines("result.json", warn = FALSE)
output <- sub('"diagnostics": \\[\\]', '"diagnostics": {}', output)
writeLines(output, "result.json")
