library(jsonlite)

d <- read.csv("input.csv", check.names = FALSE)
stopifnot(identical(names(d), c("region_id", "industry_id", "share", "shock", "region_weight", "x", "y")))
stopifnot(!anyNA(d), all(is.finite(as.matrix(d))), all(d$share >= 0), all(d$region_weight > 0))
regions <- sort(unique(d$region_id))
industries <- sort(unique(d$industry_id))
R <- length(regions)
N <- length(industries)
stopifnot(N > 2L, nrow(d) == R * N,
          !anyDuplicated(d[c("region_id", "industry_id")]))
ri <- match(d$region_id, regions)
ni <- match(d$industry_id, industries)
shares <- matrix(0, R, N)
shares[cbind(ri, ni)] <- d$share
stopifnot(max(abs(rowSums(shares) - 1)) < 1e-9)

regional <- function(column) {
  v <- d[[column]]
  stopifnot(all(abs(v - v[match(d$region_id, d$region_id)]) < 1e-10))
  v[match(regions, d$region_id)]
}
industry <- function(column) {
  v <- d[[column]]
  stopifnot(all(abs(v - v[match(d$industry_id, d$industry_id)]) < 1e-10))
  v[match(industries, d$industry_id)]
}
g <- industry("shock")
e <- regional("region_weight")
e <- e / sum(e)
x <- regional("x")
y <- regional("y")
z <- drop(shares %*% g)
s <- drop(crossprod(e, shares))
stopifnot(all(s > 0), abs(sum(s) - 1) < 1e-10)

center <- function(v) v - sum(e * v)
y0 <- center(y)
x0 <- center(x)
z0 <- center(z)
aggregate_shock <- function(v0) drop(crossprod(shares, e * v0)) / s
yb <- aggregate_shock(y0)
xb <- aggregate_shock(x0)
zb <- aggregate_shock(z0)
stopifnot(max(abs(c(sum(s * yb), sum(s * xb), sum(s * zb)))) < 1e-10)

shock_iv <- function(dependent, endogenous) {
  X <- cbind(1, endogenous)
  Z <- cbind(1, g)
  cross <- crossprod(Z, s * X)
  inverse <- solve(cross)
  beta <- drop(inverse %*% crossprod(Z, s * dependent))
  residual <- drop(dependent - X %*% beta)
  scores <- Z * (s * residual)
  covariance <- N / (N - 2) * inverse %*% crossprod(scores) %*% t(inverse)
  c(estimate = beta[2], se = sqrt(covariance[2, 2]))
}
effect <- shock_iv(yb, xb)
first_stage <- shock_iv(xb, zb)
effective_shocks <- 1 / sum(s^2)

# Independent check: compute both slopes directly from regional weighted moments.
regional_effect <- sum(e * z0 * y0) / sum(e * z0 * x0)
regional_first_stage <- sum(e * z0 * x0) / sum(e * z0^2)
stopifnot(abs(effect[1] - regional_effect) < 1e-9,
          abs(first_stage[1] - regional_first_stage) < 1e-9)

entry <- function(term, estimate, se) {
  list(term = term, estimate = unname(estimate), se = if (is.null(se)) NULL else unname(se), n_obs = N)
}
output <- list(
  task_id = "applied_shift_share", platform = "r",
  estimates = list(entry("effect", effect[1], effect[2]),
                   entry("first_stage", first_stage[1], first_stage[2]),
                   entry("effective_shocks", effective_shocks, NULL)),
  method_metadata = list(estimator = "Weighted regional 2SLS; equivalent weighted shock-level IV",
                         vcov = "Shock-level heteroskedastic HC1, structural IV residuals, N/(N-2)"),
  diagnostics = list()
)
json <- toJSON(output, auto_unbox = TRUE, null = "null", digits = 16, pretty = TRUE)
json <- sub('"diagnostics": \\[\\]', '"diagnostics": {}', json)
writeLines(json, "result.json")
checks <- c(
  sprintf("Sample: %d rows, %d regions, %d industries; complete region-industry grid; no missing values.", nrow(d), R, N),
  sprintf("Shares sum to one per region (maximum absolute error %.3g); regional weights normalized to %.16g.", max(abs(rowSums(shares) - 1)), sum(e)),
  "Within-region weight, x, and y and within-industry shock consistency passed.",
  "Centered y, x, and z before exposure aggregation; weighted shock-level means are zero.",
  sprintf("Effect: shock IV %.12g; independent regional IV %.12g; difference %.3g.", effect[1], regional_effect, abs(effect[1] - regional_effect)),
  sprintf("First stage: shock IV %.12g; independent regional WLS %.12g; difference %.3g.", first_stage[1], regional_first_stage, abs(first_stage[1] - regional_first_stage)),
  sprintf("HC1 uses %d independent industries, structural IV residuals, squared analytic weights, and multiplier %.12g.", N, N / (N - 2)),
  sprintf("Shock-level standard errors: effect %.12g; first stage %.12g. Effective shocks %.12g.", effect[2], first_stage[2], effective_shocks)
)
writeLines(checks, "verification.txt")
