library(jsonlite)

d <- read.csv("input.csv", stringsAsFactors = FALSE)
stopifnot(identical(names(d), c("date", "sales", "vix")))
d$date <- as.Date(d$date)
stopifnot(!anyNA(d), !anyDuplicated(d$date), all(d$sales > 0), all(d$vix > 0))
d <- d[order(d$date), ]

change <- c(NA_real_, diff(log(d$vix)))
lagged <- sapply(1:15, function(k) {
  if (k == 1) c(NA_real_, head(change, -1))
  else c(rep(NA_real_, k), head(change, -k))
})
colnames(lagged) <- paste0("lag_", 1:15)
keep <- complete.cases(lagged)
X <- cbind("(Intercept)" = 1, lagged[keep, , drop = FALSE])
y <- log(d$sales[keep])
N <- length(y)
p <- ncol(X)
stopifnot(N > p, N == nrow(d) - 16L)

fit <- lm.fit(X, y)
stopifnot(fit$rank == p)
b <- fit$coefficients
scores <- X * as.numeric(fit$residuals)
meat <- crossprod(scores)
for (j in 1:15) {
  cross <- crossprod(scores[(j + 1):N, , drop = FALSE],
                     scores[1:(N - j), , drop = FALSE])
  meat <- meat + (1 - j / 16) * (cross + t(cross))
}
bread <- solve(crossprod(X))
V <- N / (N - p) * bread %*% meat %*% bread
contrast <- c(0, rep(1, 15))

row <- function(term, estimate, se) {
  list(term = term, estimate = unname(as.numeric(estimate)),
       se = unname(as.numeric(se)), n_obs = as.integer(N))
}
result <- list(
  task_id = "applied_cumulative_hac", platform = "r",
  estimates = list(
    row("cumulative_response", sum(b[-1]),
        sqrt(drop(t(contrast) %*% V %*% contrast))),
    row("lag_1", b[2], sqrt(V[2, 2])),
    row("lag_15", b[16], sqrt(V[16, 16]))),
  method_metadata = list(estimator = "OLS with intercept and 15 trading-observation lags of log VIX changes",
                         vcov = "Newey-West Bartlett HAC, maximum lag 15, multiplied by N/(N-16)"),
  diagnostics = list())
json <- toJSON(result, auto_unbox = TRUE, digits = 16, pretty = TRUE)
json <- sub('"diagnostics": \\[\\]', '"diagnostics": {}', json)
writeLines(json, "result.json")
