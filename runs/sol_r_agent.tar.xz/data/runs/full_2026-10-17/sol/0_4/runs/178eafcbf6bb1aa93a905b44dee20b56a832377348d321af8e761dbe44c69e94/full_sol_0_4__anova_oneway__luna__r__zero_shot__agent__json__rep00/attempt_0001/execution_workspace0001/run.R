data <- read.csv("input.csv", stringsAsFactors = FALSE)
stopifnot(all(c("group", "y") %in% names(data)))

sample <- data[complete.cases(data[c("group", "y")]), c("group", "y")]
sample$group <- factor(sample$group)
stopifnot(is.numeric(sample$y), nlevels(sample$group) >= 2L)

fit <- lm(y ~ group, data = sample)
table <- anova(fit)
values <- c(
  F = unname(table[1L, "F value"]),
  df_num = unname(table[1L, "Df"]),
  df_den = unname(table[2L, "Df"]),
  p_value = unname(table[1L, "Pr(>F)"])
)
stopifnot(all(is.finite(values)), nobs(fit) == nrow(sample))

estimates <- lapply(names(values), function(term) {
  list(term = term, estimate = as.numeric(values[[term]]),
       se = NULL, n_obs = as.integer(nobs(fit)))
})
result <- list(
  task_id = "anova_oneway",
  platform = "r",
  estimates = estimates,
  method_metadata = list(estimator = "one-way ANOVA (ordinary least squares)",
                         vcov = "classical homoskedastic ANOVA"),
  diagnostics = jsonlite::fromJSON("{}")
)
writeLines(jsonlite::toJSON(result, auto_unbox = TRUE, null = "null",
                            digits = 16, pretty = TRUE), "result.json")
