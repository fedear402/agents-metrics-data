data <- read.csv("input.csv", stringsAsFactors = FALSE)
stopifnot(identical(names(data), c("date", "sales", "vix")))
data$date <- as.Date(data$date)
stopifnot(!anyNA(data), all(data$sales > 0), all(data$vix > 0))
data <- data[order(data$date), ]
stopifnot(!anyDuplicated(data$date))

change <- c(NA_real_, diff(log(data$vix)))
lags <- setNames(lapply(1:15, function(k) c(rep(NA_real_, k), head(change, -k))),
                 paste0("lag_", 1:15))
reg <- data.frame(log_sales = log(data$sales), lags, check.names = FALSE)
reg <- reg[complete.cases(reg), ]
n <- nrow(reg)
stopifnot(n > 16, n == nrow(data) - 16)

fit <- lm(log_sales ~ ., data = reg)
beta <- coef(fit)
vcov_hac <- sandwich::NeweyWest(fit, lag = 15, prewhite = FALSE,
                                adjust = FALSE) * n / (n - 16)
idx <- paste0("lag_", 1:15)
sum_var <- sum(vcov_hac[idx, idx])
stopifnot(sum_var >= 0)

estimates <- list(
  list(term = "cumulative_response", estimate = unname(sum(beta[idx])),
       se = unname(sqrt(sum_var)), n_obs = n),
  list(term = "lag_1", estimate = unname(beta["lag_1"]),
       se = unname(sqrt(vcov_hac["lag_1", "lag_1"])), n_obs = n),
  list(term = "lag_15", estimate = unname(beta["lag_15"]),
       se = unname(sqrt(vcov_hac["lag_15", "lag_15"])), n_obs = n)
)
result <- list(task_id = "applied_cumulative_hac", platform = "r",
               estimates = estimates,
               method_metadata = list(estimator = "OLS with intercept and 15 lagged log-vix changes",
                                      vcov = "Newey-West, Bartlett lag 15, multiplied by N/(N-16)"),
               diagnostics = structure(list(), names = character(0)))
jsonlite::write_json(result, "result.json", auto_unbox = TRUE, digits = 15,
                     pretty = TRUE)
