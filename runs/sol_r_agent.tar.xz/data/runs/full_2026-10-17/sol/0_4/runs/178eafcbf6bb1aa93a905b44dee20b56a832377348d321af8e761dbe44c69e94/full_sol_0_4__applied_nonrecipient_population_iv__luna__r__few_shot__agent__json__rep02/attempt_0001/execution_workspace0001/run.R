library(jsonlite)

households <- read.csv("households.csv")
census <- read.csv("census.csv")
d <- households[households$recipient == 0, , drop = FALSE]
stopifnot(nrow(d) > 0L, all(d$eligible %in% 0:1),
          all(is.finite(d$weight)), all(d$weight > 0),
          identical(sort(census$eligible), 0:1))

g0 <- 1 - d$eligible
g1 <- d$eligible
C <- cbind(g0, g1, d$baseline * g0, d$baseline * g1)
X <- cbind(C, d$dose * g0, d$dose * g1)
Z <- cbind(C, d$instrument * g0, d$instrument * g1)
sw <- sqrt(d$weight)
Xw <- X * sw
Zw <- Z * sw
yw <- d$outcome * sw
stopifnot(qr(Zw)$rank == ncol(Z), qr(Xw)$rank == ncol(X))
Xhat <- qr.fitted(qr(Zw), Xw)
beta <- as.numeric(qr.coef(qr(Xhat), yw))
stopifnot(all(is.finite(beta)))

mean_dose <- vapply(0:1, function(g) {
  a <- d[d$eligible == g, , drop = FALSE]
  weighted.mean(a$dose, a$weight)
}, numeric(1))
effects <- beta[5:6] * mean_dose
population <- census$nonrecipient_population[match(0:1, census$eligible)]
stopifnot(all(is.finite(population)), all(population >= 0), sum(population) > 0)
values <- c(ineligible_effect = effects[1],
            eligible_nonrecipient_effect = effects[2],
            population_effect = weighted.mean(effects, population))
n <- nrow(d)
estimates <- lapply(names(values), function(term) {
  list(term = term, estimate = unname(values[[term]]), se = NULL, n_obs = as.integer(n))
})
result <- list(
  task_id = "applied_nonrecipient_population_iv",
  platform = "r",
  estimates = estimates,
  method_metadata = list(
    estimator = "Weighted 2SLS",
    sample = "recipient == 0",
    endogenous_columns = c("dose*(1-eligible)", "dose*eligible"),
    exogenous_columns = c("1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"),
    excluded_instruments = c("instrument*(1-eligible)", "instrument*eligible"),
    counterfactual = "dose set to zero for every retained household; synthetic attribution convention",
    group_effect = "dose slope times household-weighted mean dose",
    population_aggregation = "nonrecipient_population counts from census.csv"
  ),
  diagnostics = list(n_obs = as.integer(n),
                     n_ineligible = as.integer(sum(g0)),
                     n_eligible = as.integer(sum(g1)),
                     instrument_rank = as.integer(qr(Zw)$rank),
                     mean_dose = unname(mean_dose),
                     dose_slopes = unname(beta[5:6]))
)
write_json(result, "result.json", auto_unbox = TRUE, pretty = TRUE, digits = NA, null = "null")
