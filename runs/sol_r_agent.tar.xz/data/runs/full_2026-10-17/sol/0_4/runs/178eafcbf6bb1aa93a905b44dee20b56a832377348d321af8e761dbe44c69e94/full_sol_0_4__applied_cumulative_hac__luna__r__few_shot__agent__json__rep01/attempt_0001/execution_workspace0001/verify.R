d <- read.csv("input.csv")
d$date <- as.Date(d$date)
d <- d[order(d$date), ]
t <- 17:nrow(d)
lv <- log(d$vix)
Z <- sapply(1:15, function(k) lv[t-k] - lv[t-k-1])
colnames(Z) <- paste0("lag_", 1:15)
y <- log(d$sales[t])
fit <- lm(y ~ Z)
V <- sandwich::NeweyWest(fit, lag = 15, prewhite = FALSE, adjust = TRUE)
b <- coef(fit)
cvec <- c(0, rep(1, 15))
se_sum <- sqrt(drop(crossprod(cvec, V %*% cvec)))
r <- jsonlite::read_json("result.json", simplifyVector = TRUE)
a <- r$estimates
stopifnot(nrow(d) == 720, length(t) == 704,
          max(abs(Z[,1] - (lv[t-1] - lv[t-2]))) < 1e-14,
          max(abs(Z[,15] - (lv[t-15] - lv[t-16]))) < 1e-14,
          abs(sum(b[-1]) - a$estimate[1]) < 1e-10,
          abs(b[2] - a$estimate[2]) < 1e-10,
          abs(b[16] - a$estimate[3]) < 1e-10,
          abs(se_sum - a$se[1]) < 1e-10,
          abs(sqrt(V[2,2]) - a$se[2]) < 1e-10,
          abs(sqrt(V[16,16]) - a$se[3]) < 1e-10)
cat(sprintf("rows=%d; first=%s; last=%s; cumulative=%.12f; cumulative_se=%.12f; max_checked_difference<1e-10\n", length(t), d$date[t[1]], d$date[t[length(t)]], sum(b[-1]), se_sum))
