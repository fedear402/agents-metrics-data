version 19.0
clear all
set more off
set linesize 255
import delimited using "./input.csv", clear
keep if abs(score)<1 & !missing(score,participated,earnings)
gen double w=1-abs(score)
gen double above=score>=0
gen double sa=score*above
mata:
w=st_data(.,"w")
Y=st_data(.,("earnings","participated"))
s=st_data(.,"score")
a=st_data(.,"above")
X=(J(rows(Y),1,1),s,a,s:*a)
bread=invsym(X'*(w:*X))
b=bread*X'*(w:*Y)
r=Y-X*b
c=(0\0\1\0)
j=c'*b
inf=(w:*(X*bread*c)):*r
V=inf'*inf
g=(1/j[2]\-j[1]/j[2]^2)
st_numscalar("rf",j[1]); st_numscalar("fs",j[2]); st_numscalar("te",j[1]/j[2])
st_numscalar("serf",sqrt(V[1,1])); st_numscalar("sefs",sqrt(V[2,2])); st_numscalar("sete",sqrt(g'*V*g))
st_numscalar("n",rows(Y))
end
display "ANSWER: treatment_effect estimate=" %21.12f te " se=" %21.12f sete " n_obs=" %12.0f n
display "ANSWER: reduced_form estimate=" %21.12f rf " se=" %21.12f serf " n_obs=" %12.0f n
display "ANSWER: first_stage estimate=" %21.12f fs " se=" %21.12f sefs " n_obs=" %12.0f n
* check: ivregress with same weights
ivregress 2sls earnings score sa (participated=above) [pw=w]
reg earnings score above sa [pw=w]
