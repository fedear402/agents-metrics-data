set linesize 255
import delimited using "./input.csv", clear
gen d = date(date,"YMD")
sort d
gen t=_n
tsset t
gen ls=ln(sales)
gen lv=ln(vix)
gen dv=D.lv
newey ls L(1/15).dv, lag(15)
local N=e(N)
matrix V=e(V) /* newey already applies N/(N-k), k=16 */
matrix b=e(b)
matrix w=J(1,16,1)
matrix w[1,16]=0
matrix c=w*V*w'
scalar cum=0
forvalues k=1/15 {
 scalar cum=cum+_b[L`k'.dv]
}
display "ANSWER: cumulative_response estimate=" %21.12f cum " se=" %21.12f sqrt(c[1,1]) " n_obs=" %12.0f `N'
display "ANSWER: lag_1 estimate=" %21.12f _b[L1.dv] " se=" %21.12f sqrt(V[1,1]) " n_obs=" %12.0f `N'
display "ANSWER: lag_15 estimate=" %21.12f _b[L15.dv] " se=" %21.12f sqrt(V[15,15]) " n_obs=" %12.0f `N'
