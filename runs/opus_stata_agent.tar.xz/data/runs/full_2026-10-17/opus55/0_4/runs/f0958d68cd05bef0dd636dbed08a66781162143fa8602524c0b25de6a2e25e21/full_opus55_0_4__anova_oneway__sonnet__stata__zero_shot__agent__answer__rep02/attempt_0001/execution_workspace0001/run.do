set linesize 255
import delimited using input.csv, clear
oneway y group
scalar F=r(F)
scalar d1=r(df_m)
scalar d2=r(df_r)
scalar p=Ftail(d1,d2,F)
scalar n=r(N)
* independent check via regress
quietly regress y i.group
display "check regress F=" e(F) " df=" e(df_m) "," e(df_r)
display "ANSWER: F estimate=" %21.12f F " se=. n_obs=" %12.0f n
display "ANSWER: df_num estimate=" %21.12f d1 " se=. n_obs=" %12.0f n
display "ANSWER: df_den estimate=" %21.12f d2 " se=. n_obs=" %12.0f n
display "ANSWER: p_value estimate=" %21.12f p " se=. n_obs=" %12.0f n
