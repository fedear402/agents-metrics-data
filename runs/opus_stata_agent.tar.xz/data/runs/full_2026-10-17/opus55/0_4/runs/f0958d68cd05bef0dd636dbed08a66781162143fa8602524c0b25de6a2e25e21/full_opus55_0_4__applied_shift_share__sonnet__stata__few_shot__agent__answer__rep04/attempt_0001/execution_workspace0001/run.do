version 19.0
clear all
set more off
set linesize 255
import delimited using input.csv, clear
egen r=group(region_id)
egen n=group(industry_id)
sort r n
mata:
D=st_data(.,("r","n","share","shock","region_weight","x","y"))
R=max(D[,1]); N=max(D[,2])
S=J(R,N,0); shock=J(N,1,.); w=J(R,1,.); X=J(R,1,.); Y=J(R,1,.)
for(i=1;i<=rows(D);i++){
 S[D[i,1],D[i,2]]=S[D[i,1],D[i,2]]+D[i,3]; shock[D[i,2]]=D[i,4]
 w[D[i,1]]=D[i,5]; X[D[i,1]]=D[i,6]; Y[D[i,1]]=D[i,7]
}
assert(max(abs(rowsum(S):-1))<1e-8)
e=w/sum(w)
z=S*shock
V=(Y,X,z); C=V:-e'*V
s=S'*e
A=(S'*(e:*C)):/s
est=J(2,2,.)
for(k=1;k<=2;k++){
 d=A[,k]; Xr=(J(N,1,1),A[,k+1]); Zi=(J(N,1,1),shock)
 inv=luinv(Zi'*(s:*Xr)); b=inv*Zi'*(s:*d)
 u=d-Xr*b; sc=Zi:*(s:*u)
 Vc=N/(N-2)*inv*(sc'*sc)*inv'
 est[k,]=(b[2],sqrt(Vc[2,2]))
}
reg_eff=sum(e:*C[,3]:*C[,1])/sum(e:*C[,3]:*C[,2])
reg_fs=sum(e:*C[,3]:*C[,2])/sum(e:*C[,3]:^2)
printf("check: regional effect %f fs %f  R=%f N=%f\n",reg_eff,reg_fs,R,N)
assert(max(abs(est[,1]-(reg_eff\reg_fs)))<1e-8)
st_numscalar("b1",est[1,1]);st_numscalar("s1",est[1,2])
st_numscalar("b2",est[2,1]);st_numscalar("s2",est[2,2])
st_numscalar("eff",1/sum(s:^2)); st_numscalar("NN",N)
end
* independent check: regional 2SLS slope via ivregress
preserve
gen double zz=share*shock
bysort region_id: egen double z=total(zz)
bysort region_id: keep if _n==1
ivregress 2sls y (x=z) [aw=region_weight]
restore
display "ANSWER: effect estimate=" %21.12f b1 " se=" %21.12f s1 " n_obs=" %12.0f NN
display "ANSWER: first_stage estimate=" %21.12f b2 " se=" %21.12f s2 " n_obs=" %12.0f NN
display "ANSWER: effective_shocks estimate=" %21.12f eff " se=" %21.12f . " n_obs=" %12.0f NN
