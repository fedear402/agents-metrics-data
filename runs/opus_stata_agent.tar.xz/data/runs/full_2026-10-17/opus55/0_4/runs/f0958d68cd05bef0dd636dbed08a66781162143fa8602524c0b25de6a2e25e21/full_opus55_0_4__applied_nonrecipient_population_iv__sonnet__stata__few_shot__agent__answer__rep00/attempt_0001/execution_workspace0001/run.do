clear all
set type double
import delimited census.csv, clear
summarize nonrecipient_population if eligible==0, meanonly
scalar n0=r(mean)
summarize nonrecipient_population if eligible==1, meanonly
scalar n1=r(mean)
import delimited households.csv, clear
keep if recipient==0
gen ie=1-eligible
gen d0=dose*ie
gen d1=dose*eligible
gen b0=baseline*ie
gen b1=baseline*eligible
gen z0=instrument*ie
gen z1=instrument*eligible
ivregress 2sls outcome ie eligible b0 b1 (d0 d1 = z0 z1) [aw=weight], noconstant
scalar s0=_b[d0]
scalar s1=_b[d1]
count if eligible==0
scalar N0=r(N)
count if eligible==1
scalar N1=r(N)
scalar N=e(N)
summarize dose [aw=weight] if eligible==0, meanonly
scalar e0=s0*r(mean)
summarize dose [aw=weight] if eligible==1, meanonly
scalar e1=s1*r(mean)
* check: separate regressions
ivregress 2sls outcome baseline (dose=instrument) [aw=weight] if eligible==0
display "CHECK slope0 diff " _b[dose]-s0
ivregress 2sls outcome baseline (dose=instrument) [aw=weight] if eligible==1
display "CHECK slope1 diff " _b[dose]-s1
display "ANSWER: ineligible_effect estimate=" %20.12g e0 " se=NA n_obs=" N
display "ANSWER: eligible_nonrecipient_effect estimate=" %20.12g e1 " se=NA n_obs=" N
display "ANSWER: population_effect estimate=" %20.12g (e0*n0+e1*n1)/(n0+n1) " se=NA n_obs=" N
