set linesize 255
import delimited using "./input.csv", clear varnames(1)
gen d = date(date,"YMD")
sort d
gen t=_n
tsset t
gen ly=ln(sales)
gen lv=ln(vix)
gen dl=D.lv
newey ly L(1/15).dl, lag(15)
local N=e(N)
display "ANSWER: lag_1 estimate=" %21.12f _b[L1.dl] " se=" %21.12f _se[L1.dl] " n_obs=" %12.0f `N'
display "ANSWER: lag_15 estimate=" %21.12f _b[L15.dl] " se=" %21.12f _se[L15.dl] " n_obs=" %12.0f `N'
lincom L1.dl+L2.dl+L3.dl+L4.dl+L5.dl+L6.dl+L7.dl+L8.dl+L9.dl+L10.dl+L11.dl+L12.dl+L13.dl+L14.dl+L15.dl
display "ANSWER: cumulative_response estimate=" %21.12f r(estimate) " se=" %21.12f r(se) " n_obs=" %12.0f `N'
