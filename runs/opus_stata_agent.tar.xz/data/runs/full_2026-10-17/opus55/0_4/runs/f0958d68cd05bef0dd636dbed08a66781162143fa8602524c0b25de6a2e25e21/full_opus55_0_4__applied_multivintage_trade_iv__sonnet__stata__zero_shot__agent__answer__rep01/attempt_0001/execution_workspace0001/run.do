tempfile cw tr ar oc
import delimited outcomes.csv, clear varnames(1)
save `oc'
import delimited crosswalk.csv, clear varnames(1) stringcols(1)
save `cw'
import delimited trade.csv, clear varnames(1) stringcols(2)
merge m:1 code using `cw', assert(match) nogen
save `tr'
import delimited areas.csv, clear varnames(1)
save `ar'
import delimited employment.csv, clear varnames(1)
fillin area period vintage industry
replace employment=0 if _fillin
drop _fillin
bys period vintage industry: egen double nat=total(employment)
merge m:1 area period vintage using `ar', assert(match) nogen
merge m:1 period industry using `tr', assert(match) nogen
gen double ch = cond(vintage=="base",us_change,other_change)
gen double t = employment/total_employment*ch/nat/(price_index/100)/1000*(10/years)
collapse (sum) t (first) population, by(area period vintage)
reshape wide t population, i(area period) j(vintage) string
rename tbase x
rename tearly z
merge 1:1 area period using `oc', assert(match) nogen
ivregress 2sls change_pp period control (x=z) [aw=populationbase]
local b=_b[x]
local n=e(N)
* check: manual 2SLS via first stage fitted values
regress x z period control [aw=populationbase]
predict double xh
regress change_pp xh period control [aw=populationbase]
di "manual check " %20.12g _b[xh]
sort area period
di "ANSWER: iv_slope estimate=" %20.12g `b' " se=NA n_obs=" `n'
di "ANSWER: exposure_area0_period0 estimate=" %20.12g x[1] " se=NA n_obs=" `n'
di "ANSWER: exposure_area0_period1 estimate=" %20.12g x[2] " se=NA n_obs=" `n'
di "ANSWER: instrument_area0_period0 estimate=" %20.12g z[1] " se=NA n_obs=" `n'
