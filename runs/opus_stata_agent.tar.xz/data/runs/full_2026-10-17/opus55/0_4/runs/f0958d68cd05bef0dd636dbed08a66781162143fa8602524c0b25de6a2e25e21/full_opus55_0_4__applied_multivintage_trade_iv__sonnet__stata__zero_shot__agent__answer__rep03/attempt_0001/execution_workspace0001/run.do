clear all
set more off
import delimited crosswalk.csv, clear stringcols(1)
tempfile cw tr ar em oc
import delimited employment.csv, clear
save `em'
import delimited outcomes.csv, clear
save `oc'
import delimited crosswalk.csv, clear stringcols(1)
save `cw'
import delimited trade.csv, clear stringcols(2)
merge 1:1 code using `cw', assert(match) nogen
save `tr'
import delimited areas.csv, clear
save `ar'
* full grid area x period x vintage x industry
keep area period vintage
expand 4
bys area period vintage: gen industry=_n-1
merge 1:1 area period vintage industry using `em', keep(master match) nogen
replace employment=0 if missing(employment)
merge m:1 area period vintage using `ar', assert(match) nogen
bys period vintage industry: egen nat=total(employment)
merge m:1 period industry using `tr', assert(match) nogen
gen chg = cond(vintage=="base", us_change, other_change)
gen term=(employment/total_employment)*(chg/nat)/(price_index/100)/1000*(10/years)
collapse (sum) e=term, by(area period vintage)
reshape wide e, i(area period) j(vintage) string
rename ebase x
rename eearly z
preserve
use `ar', clear
keep if vintage=="base"
tempfile pop
save `pop'
restore
merge 1:1 area period using `pop', assert(match) nogen
merge 1:1 area period using `oc', assert(match) nogen
ivregress 2sls change_pp period control (x=z) [aw=population]
local b=_b[x]
local n=e(N)
* check: manual 2SLS
reg x z period control [aw=population]
predict xh
reg change_pp xh period control [aw=population]
di "manual check slope: " %20.12g _b[xh]
sort period area
su x if area==0 & period==0
local x0=r(mean)
su x if area==0 & period==1
local x1=r(mean)
su z if area==0 & period==0
local z0=r(mean)
di "ANSWER: iv_slope estimate=" %20.12g `b' " se=NA n_obs=" `n'
di "ANSWER: exposure_area0_period0 estimate=" %20.12g `x0' " se=NA n_obs=" `n'
di "ANSWER: exposure_area0_period1 estimate=" %20.12g `x1' " se=NA n_obs=" `n'
di "ANSWER: instrument_area0_period0 estimate=" %20.12g `z0' " se=NA n_obs=" `n'
