import delimited census.csv, clear
su nonrecipient_population if eligible==0, meanonly
scalar P0=r(mean)
su nonrecipient_population if eligible==1, meanonly
scalar P1=r(mean)
import delimited households.csv, clear
keep if recipient==0
gen e0=1-eligible
gen e1=eligible
gen b0=baseline*e0
gen b1=baseline*e1
gen d0=dose*e0
gen d1=dose*e1
gen z0=instrument*e0
gen z1=instrument*e1
ivregress 2sls outcome e0 e1 b0 b1 (d0 d1 = z0 z1) [aw=weight], noconstant
scalar s0=_b[d0]
scalar s1=_b[d1]
local N=e(N)
su dose [aw=weight] if eligible==0
scalar m0=r(mean)
su dose [aw=weight] if eligible==1
scalar m1=r(mean)
scalar E0=s0*m0
scalar E1=s1*m1
scalar EP=(P0*E0+P1*E1)/(P0+P1)
* check: manual 2SLS via matrices
gen one=1
mata: st_view(y=.,.,"outcome"); st_view(X=.,.,"d0 d1 e0 e1 b0 b1"); st_view(Z=.,.,"z0 z1 e0 e1 b0 b1"); st_view(w=.,.,"weight"); Xh=Z*invsym(Z'(w:*Z))*Z'(w:*X); b=invsym(Xh'(w:*X))*Xh'(w:*y); b'
di "ANSWER: ineligible_effect estimate=" %18.10g E0 " se=NA n_obs=`N'"
di "ANSWER: eligible_nonrecipient_effect estimate=" %18.10g E1 " se=NA n_obs=`N'"
di "ANSWER: population_effect estimate=" %18.10g EP " se=NA n_obs=`N'"
