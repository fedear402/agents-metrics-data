version 19.0
clear all
set more off
set linesize 255
import delimited using "./input.csv", clear varnames(1)
generate double day=date(date,"YMD")
sort day
generate int t=_n
tsset t
generate double lv=ln(vix)
generate double dlv=D.lv
generate double ls=ln(sales)
forvalues k=1/15 {
generate double l`k'=L`k'.dlv
}
keep if !missing(ls,l1,l15)
mata:
X=(J(st_nobs(),1,1),st_data(.,"l1-l15"))
y=st_data(.,"ls")
b=qrsolve(X,y)
e=y-X*b
N=rows(X)
p=cols(X)
s=X:*e
m=s'*s
for (j=1;j<=15;j++) {
 g=s[|j+1,1\N,p|]'*s[|1,1\N-j,p|]
 m=m+(1-j/16)*(g+g')
}
B=invsym(X'*X)
V=N/(N-p)*B*m*B
c=(0\J(15,1,1))
printf("ANSWER: cumulative_response estimate=%21.15g se=%21.15g n_obs=%9.0f\n",c'*b,sqrt(c'*V*c),N)
printf("ANSWER: lag_1 estimate=%21.15g se=%21.15g n_obs=%9.0f\n",b[2],sqrt(V[2,2]),N)
printf("ANSWER: lag_15 estimate=%21.15g se=%21.15g n_obs=%9.0f\n",b[16],sqrt(V[16,16]),N)
end
* check with newey
quietly newey ls l1-l15, lag(15)
lincom l1+l2+l3+l4+l5+l6+l7+l8+l9+l10+l11+l12+l13+l14+l15
