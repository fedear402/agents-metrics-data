version 19.0
clear all
set more off
set linesize 255
import delimited using "./input.csv", clear
egen r = group(region_id)
egen n = group(industry_id)
sort r n
mata:
r=st_data(.,"r"); n=st_data(.,"n"); sh=st_data(.,"share"); k=st_data(.,"shock")
R=max(r); N=max(n)
S=J(R,N,0); shock=J(N,1,.); w=J(R,1,.); X=J(R,1,.); Y=J(R,1,.)
xv=st_data(.,"x"); yv=st_data(.,"y"); wv=st_data(.,"region_weight")
for(i=1;i<=rows(r);i++){
  S[r[i],n[i]]=S[r[i],n[i]]+sh[i]; shock[n[i]]=k[i]
  w[r[i]]=wv[i]; X[r[i]]=xv[i]; Y[r[i]]=yv[i]
}
printf("max share-sum dev %g\n",max(abs(rowsum(S):-1)))
e=w/sum(w)
Z=S*shock
reg=(Y,X,Z)
c=reg:-e'*reg
s=S'*e
agg=(S'*(e:*c)):/s
est=J(2,2,.)
for(q=1;q<=2;q++){
  d=agg[,q]; en=agg[,q+1]
  Rg=(J(N,1,1),en); In=(J(N,1,1),shock)
  inv=luinv(In'*(s:*Rg))
  b=inv*In'*(s:*d)
  u=d-Rg*b
  sc=In:*(s:*u)
  V=N/(N-2)*inv*(sc'*sc)*inv'
  est[q,]=(b[2],sqrt(V[2,2]))
}
re=sum(e:*c[,3]:*c[,1])/sum(e:*c[,3]:*c[,2])
rf=sum(e:*c[,3]:*c[,2])/sum(e:*c[,3]:^2)
printf("check regional: %g %g  diff %g %g\n",re,rf,est[1,1]-re,est[2,1]-rf)
printf("R=%g N=%g\n",R,N)
st_numscalar("b1",est[1,1]); st_numscalar("s1",est[1,2])
st_numscalar("b2",est[2,1]); st_numscalar("s2",est[2,2])
st_numscalar("eff",1/sum(s:^2)); st_numscalar("NN",N)
end
display "ANSWER: effect estimate=" %21.12f b1 " se=" %21.12f s1 " n_obs=" %12.0f NN
display "ANSWER: first_stage estimate=" %21.12f b2 " se=" %21.12f s2 " n_obs=" %12.0f NN
display "ANSWER: effective_shocks estimate=" %21.12f eff " se=. n_obs=" %12.0f NN
* independent check: regional weighted ivregress slope
collapse (first) x y region_weight, by(r)
