clear all
set type double
import delimited crosswalk.csv, clear stringcols(1)
tempfile cw
save `cw'
import delimited trade.csv, clear stringcols(2)
merge m:1 code using `cw', assert(match) nogen
tempfile tr
save `tr'
import delimited employment.csv, clear
tempfile em
save `em'
import delimited areas.csv, clear
keep area period vintage total_employment
expand 4
bys area period vintage: gen industry=_n-1
merge 1:1 area period vintage industry using `em', assert(master match) nogen
replace employment=0 if missing(employment)
bys period vintage industry: egen nat=total(employment)
merge m:1 period industry using `tr', assert(match) nogen
gen chg=cond(vintage=="base",us_change,other_change)
gen term=(employment/total_employment)*(chg/nat)/(price_index/100)/1000*(10/years)
collapse (sum) term, by(area period vintage)
reshape wide term, i(area period) j(vintage) string
rename termbase x
rename termearly z
tempfile w
save `w'
import delimited outcomes.csv, clear
merge 1:1 area period using `w', assert(match) nogen
tempfile d
save `d'
import delimited areas.csv, clear
keep if vintage=="base"
keep area period population
merge 1:1 area period using `d', assert(match) nogen
ivregress 2sls change_pp period control (x=z) [aw=population]
local n=e(N)
* check: manual 2SLS
regress x z period control [aw=population]
predict xh
regress change_pp xh period control [aw=population]
di "CHECK manual slope " %20.12g _b[xh]
sort period area
su x if area==0 & period==0
local x0=r(mean)
su x if area==0 & period==1
local x1=r(mean)
su z if area==0 & period==0
local z0=r(mean)
qui ivregress 2sls change_pp period control (x=z) [aw=population]
di "ANSWER: iv_slope estimate=" %20.12g _b[x] " se=NA n_obs=" `n'
di "ANSWER: exposure_area0_period0 estimate=" %20.12g `x0' " se=NA n_obs=" `n'
di "ANSWER: exposure_area0_period1 estimate=" %20.12g `x1' " se=NA n_obs=" `n'
di "ANSWER: instrument_area0_period0 estimate=" %20.12g `z0' " se=NA n_obs=" `n'
