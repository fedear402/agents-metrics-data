clear all
set type double
import delimited crosswalk.csv, clear stringcols(1)
tempfile cw emp tr pop
save `cw'
import delimited employment.csv, clear
save `emp'
import delimited outcomes.csv, clear
tempfile out
save `out'
import delimited trade.csv, clear stringcols(2)
merge m:1 code using `cw', assert(match) nogen
keep period industry us_change other_change price_index years
save `tr'
import delimited areas.csv, clear
preserve
keep if vintage=="base"
keep area period population
save `pop'
restore
keep area period vintage total_employment
expand 4
bysort area period vintage: gen industry=_n-1
merge 1:1 area period vintage industry using `emp', keep(master match) nogen
replace employment=0 if missing(employment)
bysort period vintage industry: egen double nat=total(employment)
merge m:1 period industry using `tr', assert(match) nogen
gen double chg=cond(vintage=="base",us_change,other_change)
gen double term=(employment/total_employment)*(chg/nat)/(price_index/100)/1000*(10/years)
collapse (sum) term, by(area period vintage)
reshape wide term, i(area period) j(vintage) string
rename (termbase termearly) (x z)
merge 1:1 area period using `out', assert(match) nogen
merge 1:1 area period using `pop', assert(match) nogen
ivregress 2sls change_pp period control (x=z) [aw=population]
local n=e(N)
local b=_b[x]
sort period area
su x if area==0&period==0, meanonly
local x0=r(mean)
su x if area==0&period==1, meanonly
local x1=r(mean)
su z if area==0&period==0, meanonly
local z0=r(mean)
* check: manual IV via projection
regress x z period control [aw=population]
predict xh
regress change_pp xh period control [aw=population]
di "CHECK manual 2sls " %20.12g _b[xh]
di "ANSWER: iv_slope estimate=" %20.12g `b' " se=NA n_obs=" `n'
di "ANSWER: exposure_area0_period0 estimate=" %20.12g `x0' " se=NA n_obs=" `n'
di "ANSWER: exposure_area0_period1 estimate=" %20.12g `x1' " se=NA n_obs=" `n'
di "ANSWER: instrument_area0_period0 estimate=" %20.12g `z0' " se=NA n_obs=" `n'
