clear all
set more off
set type double
import delimited crosswalk.csv, clear stringcols(1)
tempfile cw tr ar em
save `cw'
import delimited trade.csv, clear stringcols(2)
merge m:1 code using `cw', keep(match) nogen
save `tr'
import delimited areas.csv, clear
save `ar'
* full grid of area-period-vintage-industry, missing = 0
import delimited employment.csv, clear
save `em'
use `ar', clear
keep area period vintage
expand 4
bysort area period vintage: gen industry=_n-1
merge 1:1 area period vintage industry using `em', keep(master match) nogen
replace employment=0 if missing(employment)
bysort period vintage industry: egen natemp=total(employment)
merge m:1 area period vintage using `ar', keep(match) nogen
merge m:1 period industry using `tr', keep(match) nogen
gen chg = cond(vintage=="base", us_change, other_change)
gen term = (employment/total_employment)*(chg/natemp)/(price_index/100)/1000*(10/years)
collapse (sum) term, by(area period vintage)
reshape wide term, i(area period) j(vintage) string
rename termbase x
rename termearly z
* population from base vintage rows only
preserve
use `ar', clear
keep if vintage=="base"
keep area period population
tempfile pop
save `pop'
restore
merge 1:1 area period using `pop', keep(match) nogen

preserve
import delimited outcomes.csv, clear
tempfile out
save `out'
restore
merge 1:1 area period using `out', assert(match) nogen
ivregress 2sls change_pp period control (x = z) [aw=population]
local b = _b[x]
local n = e(N)
su x if area==0 & period==0
local x0=r(mean)
su x if area==0 & period==1
local x1=r(mean)
su z if area==0 & period==0
local z0=r(mean)
* check: manual IV via first stage
reg x z period control [aw=population]
predict xh
reg change_pp xh period control [aw=population]
di "check slope " %20.12g _b[xh]
di "ANSWER: iv_slope estimate=" %20.12g `b' " se=NA n_obs=" `n'
di "ANSWER: exposure_area0_period0 estimate=" %20.12g `x0' " se=NA n_obs=" `n'
di "ANSWER: exposure_area0_period1 estimate=" %20.12g `x1' " se=NA n_obs=" `n'
di "ANSWER: instrument_area0_period0 estimate=" %20.12g `z0' " se=NA n_obs=" `n'
