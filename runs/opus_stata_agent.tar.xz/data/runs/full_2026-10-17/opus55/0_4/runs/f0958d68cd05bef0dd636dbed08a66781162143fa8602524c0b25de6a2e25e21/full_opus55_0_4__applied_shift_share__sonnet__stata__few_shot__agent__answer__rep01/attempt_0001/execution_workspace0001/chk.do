import delimited using "./input.csv", clear
bys region_id: gen one=_n==1
qui su region_weight if one
gen e=region_weight/r(sum)
gen z_c=share*shock
bys region_id: egen z=total(z_c)
foreach v in x y z {
 qui su `v' [aw=e] if one
 gen `v'0=`v'-r(mean)
 gen `v'w=e*share*`v'0
}
gen es=e*share
collapse (sum) s=es xw yw zw (first) shock, by(industry_id)
foreach v in x y z {
 gen `v'b=`v'w/s
}
ivregress 2sls yb (xb=shock) [aw=s], vce(robust)
ivregress 2sls xb (zb=shock) [aw=s], vce(robust)
