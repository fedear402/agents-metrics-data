clear all
set type double
import delimited crosswalk.csv, clear stringcols(1)
tempfile cw tr emp ar
save `cw'
import delimited trade.csv, clear stringcols(2)
merge m:1 code using `cw', assert(match) nogen
keep period industry us_change other_change price_index years
save `tr'
* full grid of area-period-vintage-industry, zero fill
import delimited areas.csv, clear
keep area period vintage
expand 4
bysort area period vintage: gen industry=_n-1
tempfile grid
save `grid'
import delimited employment.csv, clear
merge 1:1 area period vintage industry using `grid', nogen
replace employment=0 if missing(employment)
bysort period vintage industry: egen double nat=total(employment)
save `emp'
import delimited areas.csv, clear
save `ar'
import delimited outcomes.csv, clear
tempfile out
save `out'
use `emp', clear
merge m:1 area period vintage using `ar', assert(match) nogen
merge m:1 period industry using `tr', assert(match) nogen
gen double cx=(employment/total_employment)*(us_change/nat)/(price_index/100)/1000*(10/years) if vintage=="base"
gen double cz=(employment/total_employment)*(other_change/nat)/(price_index/100)/1000*(10/years) if vintage=="early"
gen double popb=population if vintage=="base"
collapse (sum) x=cx z=cz (max) popb, by(area period)
merge 1:1 area period using `out', nogen
assert _N==72
ivregress 2sls change_pp period control (x=z) [aw=popb]
local n=e(N)
di "ANSWER: iv_slope estimate=" %20.12g _b[x] " se=NA n_obs=" `n'
sum x if area==0 & period==0, meanonly
di "ANSWER: exposure_area0_period0 estimate=" %20.12g r(mean) " se=NA n_obs=" `n'
sum x if area==0 & period==1, meanonly
di "ANSWER: exposure_area0_period1 estimate=" %20.12g r(mean) " se=NA n_obs=" `n'
sum z if area==0 & period==0, meanonly
di "ANSWER: instrument_area0_period0 estimate=" %20.12g r(mean) " se=NA n_obs=" `n'
* check: manual IV via two-stage
regress x z period control [aw=popb]
predict xh
regress change_pp xh period control [aw=popb]
