clear all
set more off
import delimited crosswalk.csv, clear stringcols(1)
tempfile cw tr ar em
save `cw'
import delimited trade.csv, clear stringcols(2)
merge m:1 code using `cw', assert(match) nogen
save `tr'
import delimited areas.csv, clear
save `ar'
import delimited employment.csv, clear
tempfile emp
save `emp'
import delimited outcomes.csv, clear
tempfile out
save `out'
use `ar', clear
* full grid area x period x vintage x industry
keep area period vintage
expand 4
bys area period vintage: gen industry=_n-1
merge 1:1 area period vintage industry using `emp', keep(master match) nogen
replace employment=0 if missing(employment)
merge m:1 area period vintage using `ar', assert(match) nogen
bys period vintage industry: egen nat=total(employment)
merge m:1 period industry using `tr', assert(match) nogen
gen chg = cond(vintage=="base", us_change, other_change)
gen term = (employment/total_employment)*(chg/nat)/(price_index/100)/1000*(10/years)
collapse (sum) e=term, by(area period vintage)
reshape wide e, i(area period) j(vintage) string
rename ebase x
rename eearly z
merge 1:1 area period using `out', assert(match) nogen
* population from base vintage
preserve
import delimited areas.csv, clear
keep if vintage=="base"
keep area period population
rename population popb
save `em'
restore
merge 1:1 area period using `em', assert(match) nogen
ivregress 2sls change_pp period control (x=z) [aweight=popb]
local b=_b[x]
local n=e(N)
su x if area==0 & period==0, meanonly
local x0=r(mean)
su x if area==0 & period==1, meanonly
local x1=r(mean)
su z if area==0 & period==0, meanonly
local z0=r(mean)
* check: manual IV via Wald-type formula with FWL
qui reg x z period control [aw=popb]
predict xh
qui reg change_pp xh period control [aw=popb]
di "check 2-step slope: " %20.12g _b[xh]
di "ANSWER: iv_slope estimate=" %20.12g `b' " se=NA n_obs=" `n'
di "ANSWER: exposure_area0_period0 estimate=" %20.12g `x0' " se=NA n_obs=" `n'
di "ANSWER: exposure_area0_period1 estimate=" %20.12g `x1' " se=NA n_obs=" `n'
di "ANSWER: instrument_area0_period0 estimate=" %20.12g `z0' " se=NA n_obs=" `n'
