version 19.0
clear all
set more off
set linesize 255
import delimited using "./input.csv", clear
fillin region_id industry_id
replace share=0 if _fillin
bysort industry_id (shock): replace shock=shock[1]
foreach v in region_weight x y {
    bysort region_id (`v'): replace `v'=`v'[1]
}
sort region_id industry_id
mata:
st_view(D=., ., ("region_id","industry_id","share","shock","region_weight","x","y"))
R=rows(uniqrows(D[,1])); N=rows(uniqrows(D[,2]))
S=colshape(D[,3],N)
shock=colshape(D[,4],N)[1,]'
w=colshape(D[,5],N)[,1]; w=w/sum(w)
x=colshape(D[,6],N)[,1]; y=colshape(D[,7],N)[,1]
z=S*shock
V=(y,x,z); C=V:-w'*V
s=S'*w
A=(S'*(w:*C)):/s
est=J(2,2,.)
for (k=1;k<=2;k++) {
    dep=A[,k]; X=(J(N,1,1),A[,k+1]); Z=(J(N,1,1),shock)
    inv=luinv(Z'*(s:*X)); b=inv*Z'*(s:*dep)
    u=dep-X*b; sc=Z:*(s:*u)
    Vc=N/(N-2)*inv*(sc'*sc)*inv'
    est[k,]=(b[2],sqrt(Vc[2,2]))
}
reff=sum(w:*C[,3]:*C[,1])/sum(w:*C[,3]:*C[,2])
rfs=sum(w:*C[,3]:*C[,2])/sum(w:*C[,3]:^2)
printf("check: R=%g N=%g diff=%g %g rowsum maxdev=%g\n",R,N,est[1,1]-reff,est[2,1]-rfs,max(abs(rowsum(S):-1)))
st_numscalar("b1",est[1,1]); st_numscalar("s1",est[1,2])
st_numscalar("b2",est[2,1]); st_numscalar("s2",est[2,2])
st_numscalar("es",1/sum(s:^2)); st_numscalar("N",N)
end
display "ANSWER: effect estimate=" %21.12f b1 " se=" %21.12f s1 " n_obs=" %12.0f N
display "ANSWER: first_stage estimate=" %21.12f b2 " se=" %21.12f s2 " n_obs=" %12.0f N
display "ANSWER: effective_shocks estimate=" %21.12f es " se=. n_obs=" %12.0f N
* independent check: regional weighted ivregress slope
preserve
bysort region_id: gen z=sum(share*shock)
by region_id: keep if _n==_N
ivregress 2sls y (x=z) [aw=region_weight]
regress x z [aw=region_weight]
restore
