version 19.0
clear all
set more off
set linesize 255
import delimited using "input.csv", clear varnames(1)
capture confirm numeric variable date
if _rc generate double day=date(date,"YMD")
else generate double day=date
sort day
generate int t=_n
tsset t
generate double lv=ln(vix)
generate double dlv=D.lv
generate double ls=ln(sales)
forvalues j=1/15 {
    generate double L`j'=L`j'.dlv
}
keep if !missing(ls,L1,L15)
mata:
X=(J(st_nobs(),1,1),st_data(.,"L1-L15"))
y=st_data(.,"ls")
b=qrsolve(X,y)
e=y-X*b
N=rows(X)
p=cols(X)
s=X:*e
m=s'*s
for (j=1;j<=15;j++) {
    g=s[|j+1,1\N,p|]'*s[|1,1\N-j,p|]
    m=m+(1-j/16)*(g+g')
}
B=invsym(X'*X)
V=N/(N-p)*B*m*B
c=(0\J(15,1,1))
printf("ANSWER: cumulative_response estimate=%21.15g se=%21.15g n_obs=%9.0f\n",c'*b,sqrt(c'*V*c),N)
printf("ANSWER: lag_1 estimate=%21.15g se=%21.15g n_obs=%9.0f\n",b[2],sqrt(V[2,2]),N)
printf("ANSWER: lag_15 estimate=%21.15g se=%21.15g n_obs=%9.0f\n",b[16],sqrt(V[16,16]),N)
end
* check with newey (no small-sample N/(N-k) by default)
regress ls L1-L15
newey ls L1-L15, lag(15)
lincom L1+L2+L3+L4+L5+L6+L7+L8+L9+L10+L11+L12+L13+L14+L15
