clear
set linesize 255
import delimited using "./input.csv", clear
drop if missing(y) | missing(group)
oneway y group
scalar F = r(F)
scalar dfn = r(df_m)
scalar dfd = r(df_r)
scalar N = r(N)
scalar p = Ftail(dfn, dfd, F)
* independent check via regress
quietly regress y i.group
display "check regress F=" %21.12f e(F) " p=" %21.12f Ftail(e(df_m),e(df_r),e(F))
display "ANSWER: F estimate=" %21.12f F " se=. n_obs=" %12.0f N
display "ANSWER: df_num estimate=" %21.12f dfn " se=. n_obs=" %12.0f N
display "ANSWER: df_den estimate=" %21.12f dfd " se=. n_obs=" %12.0f N
display "ANSWER: p_value estimate=" %21.12f p " se=. n_obs=" %12.0f N
