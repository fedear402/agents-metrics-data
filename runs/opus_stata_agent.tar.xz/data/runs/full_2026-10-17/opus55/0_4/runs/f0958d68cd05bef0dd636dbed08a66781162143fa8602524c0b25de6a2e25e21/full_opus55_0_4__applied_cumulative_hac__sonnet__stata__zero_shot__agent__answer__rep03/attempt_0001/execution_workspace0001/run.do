clear all
set linesize 255
import delimited using "./input.csv", clear
gen d = date(date,"YMD")
sort d
gen t = _n
tsset t
gen ly = ln(sales)
gen lv = ln(vix)
gen dlv = D.lv
newey ly L(1/15).dlv, lag(15)
scalar N = e(N)
matrix V = e(V)
matrix b = e(b)
matrix g = J(1,16,1)
matrix g[1,16]=0
matrix s = b*g'
matrix vs = g*V*g'
display "ANSWER: cumulative_response estimate=" %21.12f s[1,1] " se=" %21.12f sqrt(vs[1,1]) " n_obs=" %12.0f N
display "ANSWER: lag_1 estimate=" %21.12f b[1,1] " se=" %21.12f sqrt(V[1,1]) " n_obs=" %12.0f N
display "ANSWER: lag_15 estimate=" %21.12f b[1,15] " se=" %21.12f sqrt(V[15,15]) " n_obs=" %12.0f N
