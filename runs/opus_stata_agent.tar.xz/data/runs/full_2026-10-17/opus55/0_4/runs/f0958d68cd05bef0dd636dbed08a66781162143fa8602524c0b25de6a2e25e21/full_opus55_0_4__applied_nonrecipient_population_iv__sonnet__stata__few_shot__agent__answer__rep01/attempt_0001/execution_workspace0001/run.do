clear all
set type double
import delimited using census.csv, clear
summarize nonrecipient_population if eligible==0, meanonly
scalar n0=r(mean)
summarize nonrecipient_population if eligible==1, meanonly
scalar n1=r(mean)
import delimited using households.csv, clear
keep if recipient==0
gen double g0=1-eligible
gen double g1=eligible
gen double d0=dose*g0
gen double d1=dose*g1
gen double b0x=baseline*g0
gen double b1x=baseline*g1
gen double z0=instrument*g0
gen double z1=instrument*g1
ivregress 2sls outcome g0 g1 b0x b1x (d0 d1 = z0 z1) [aw=weight], noconstant
scalar s0=_b[d0]
scalar s1=_b[d1]
local N=e(N)
summarize dose [aw=weight] if eligible==0, meanonly
scalar e0=s0*r(mean)
summarize dose [aw=weight] if eligible==1, meanonly
scalar e1=s1*r(mean)
* check: separate regressions
ivregress 2sls outcome baseline (dose=instrument) [aw=weight] if eligible==0
display "CHECK diff0 " _b[dose]-s0
ivregress 2sls outcome baseline (dose=instrument) [aw=weight] if eligible==1
display "CHECK diff1 " _b[dose]-s1
display "ANSWER: ineligible_effect estimate=" %20.12g e0 " se=NA n_obs=`N'"
display "ANSWER: eligible_nonrecipient_effect estimate=" %20.12g e1 " se=NA n_obs=`N'"
display "ANSWER: population_effect estimate=" %20.12g (e0*n0+e1*n1)/(n0+n1) " se=NA n_obs=`N'"
