clear all
set type double
import delimited census.csv, clear
summarize nonrecipient_population if eligible==0, meanonly
scalar n0=r(mean)
summarize nonrecipient_population if eligible==1, meanonly
scalar n1=r(mean)
import delimited households.csv, clear
keep if recipient==0
gen g0=1-eligible
gen g1=eligible
gen d0=dose*g0
gen d1=dose*g1
gen b0=baseline*g0
gen b1=baseline*g1
gen z0=instrument*g0
gen z1=instrument*g1
ivregress 2sls outcome g0 g1 b0 b1 (d0 d1 = z0 z1) [aw=weight], noconstant
scalar s0=_b[d0]
scalar s1=_b[d1]
scalar N=e(N)
summarize dose [aw=weight] if eligible==0, meanonly
scalar e0=s0*r(mean)
summarize dose [aw=weight] if eligible==1, meanonly
scalar e1=s1*r(mean)
* check: separate regressions
ivregress 2sls outcome baseline (dose=instrument) [aw=weight] if eligible==0
display "CHECK slope0 diff " _b[dose]-s0
ivregress 2sls outcome baseline (dose=instrument) [aw=weight] if eligible==1
display "CHECK slope1 diff " _b[dose]-s1
display "ANSWER: ineligible_effect estimate=" %20.12g e0 " se=NA n_obs=" N
display "ANSWER: eligible_nonrecipient_effect estimate=" %20.12g e1 " se=NA n_obs=" N
display "ANSWER: population_effect estimate=" %20.12g ((e0*n0+e1*n1)/(n0+n1)) " se=NA n_obs=" N
