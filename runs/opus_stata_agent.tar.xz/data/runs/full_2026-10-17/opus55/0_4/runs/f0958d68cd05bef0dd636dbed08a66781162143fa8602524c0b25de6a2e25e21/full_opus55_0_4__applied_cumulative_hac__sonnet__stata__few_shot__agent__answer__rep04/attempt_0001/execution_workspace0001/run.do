version 19.0
clear all
set more off
set linesize 255
import delimited using "./input.csv", clear varnames(1)
capture confirm numeric variable date
if _rc generate double day=date(date,"YMD")
else generate double day=date
sort day
generate int obs=_n
tsset obs
generate double lv=ln(vix)
generate double dlv=D.lv
generate double ly=ln(sales)
forvalues k=1/15 {
    generate double L`k'd=L`k'.dlv
}
keep if !missing(ly,L1d,L15d)
mata:
X=(J(st_nobs(),1,1),st_data(.,"L1d-L15d"))
y=st_data(.,"ly")
b=qrsolve(X,y)
e=y-X*b
N=rows(X); p=cols(X)
s=X:*e
m=s'*s
for (j=1;j<=15;j++) {
    g=s[|j+1,1\N,p|]'*s[|1,1\N-j,p|]
    m=m+(1-j/16)*(g+g')
}
B=invsym(X'*X)
V=N/(N-p)*B*m*B
c=(0\J(15,1,1))
printf("ANSWER: cumulative_response estimate=%21.15g se=%21.15g n_obs=%9.0f\n",c'*b,sqrt(c'*V*c),N)
printf("ANSWER: lag_1 estimate=%21.15g se=%21.15g n_obs=%9.0f\n",b[2],sqrt(V[2,2]),N)
printf("ANSWER: lag_15 estimate=%21.15g se=%21.15g n_obs=%9.0f\n",b[16],sqrt(V[16,16]),N)
end
* independent check: newey + lincom (newey uses N/(N-k) scaling)
regress ly L1d-L15d
newey ly L1d-L15d, lag(15)
lincom L1d+L2d+L3d+L4d+L5d+L6d+L7d+L8d+L9d+L10d+L11d+L12d+L13d+L14d+L15d
