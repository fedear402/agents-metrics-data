clear all
set linesize 255
import delimited "./input.csv", clear
keep if abs(score)<1 & !missing(score,participated,earnings)
gen double w = 1-abs(score)
gen double d = score>=0
gen double ds = d*score
mata:
X=st_data(.,("d","score","ds")); X=X,J(rows(X),1,1)
w=st_data(.,"w"); y=st_data(.,"earnings"); t=st_data(.,"participated")
A=invsym(cross(X,w,X)); by=A*cross(X,w,y); bt=A*cross(X,w,t)
uy=w:*(y-X*by):*X; ut=w:*(t-X*bt):*X
IFy=uy*A; IFt=ut*A
gy=IFy[,1]; gt=IFt[,1]
vy=cross(gy,gy); vt=cross(gt,gt); c=cross(gy,gt)
rf=by[1]; fs=bt[1]; te=rf/fs
vte=(vy - 2*te*c + te^2*vt)/fs^2
st_numscalar("rf",rf); st_numscalar("fs",fs); st_numscalar("te",te)
st_numscalar("sry",sqrt(vy)); st_numscalar("st",sqrt(vt)); st_numscalar("ste",sqrt(vte))
end
local n=_N
display "ANSWER: treatment_effect estimate=" %21.12f te " se=" %21.12f ste " n_obs=" %12.0f `n'
display "ANSWER: reduced_form estimate=" %21.12f rf " se=" %21.12f sry " n_obs=" %12.0f `n'
display "ANSWER: first_stage estimate=" %21.12f fs " se=" %21.12f st " n_obs=" %12.0f `n'
* check: IV with robust (HC1) scaled to HC0
gen double dt=d*participated
qui ivregress 2sls earnings score ds (participated = d) [pw=w], vce(robust)
display "CHECK iv b=" %21.12f _b[participated] " se_hc0=" %21.12f _se[participated]*sqrt((_N-4)/_N)
qui regress earnings d score ds [pw=w], vce(robust)
display "CHECK rf b=" %21.12f _b[d] " se_hc0=" %21.12f _se[d]*sqrt((_N-4)/_N)
