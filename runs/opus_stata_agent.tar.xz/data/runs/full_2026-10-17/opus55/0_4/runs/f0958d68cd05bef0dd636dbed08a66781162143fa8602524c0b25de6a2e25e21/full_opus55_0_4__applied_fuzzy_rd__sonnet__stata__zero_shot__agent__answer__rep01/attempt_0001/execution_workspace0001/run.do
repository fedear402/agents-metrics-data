clear all
set linesize 255
import delimited ./input.csv
keep if abs(score)<1 & !missing(score,participated,earnings)
gen double w=1-abs(score)
gen r=score>=0
gen double rs=r*score
qui count
scalar N=r(N)
qui regress earnings r score rs [aw=w]
scalar rf=_b[r]
predict double eY, resid
qui regress participated r score rs [aw=w]
scalar fs=_b[r]
predict double eD, resid
* bread
matrix accum XWX = r score rs [iw=w]
matrix A=invsym(XWX)
* row 1 of A gives influence for coefficient on r: psi_i = a1*x_i * w_i * e_i
matrix a=A[1,1...]
gen double xa = a[1,1]*r + a[1,2]*score + a[1,3]*rs + a[1,4]
gen double pY = xa*w*eY
gen double pD = xa*w*eD
gen double pYY=pY^2
gen double pDD=pD^2
gen double pYD=pY*pD
foreach v in pYY pDD pYD {
 qui summarize `v'
 scalar s_`v'=r(sum)
}
scalar te=rf/fs
scalar se_rf=sqrt(s_pYY)
scalar se_fs=sqrt(s_pDD)
scalar se_te=sqrt(s_pYY/fs^2 + rf^2*s_pDD/fs^4 - 2*rf*s_pYD/fs^3)
* check: rf SE vs regress robust (HC1 scaled back)
qui regress earnings r score rs [pw=w]
di "check rf se HC0 from regress: " _se[r]*sqrt((N-4)/(N-1))
* check TE via ivregress
qui ivregress 2sls earnings score rs (participated=r) [pw=w], vce(robust)
di "check ivregress te: " _b[participated] " se " _se[participated]
display "ANSWER: treatment_effect estimate=" %21.12f te " se=" %21.12f se_te " n_obs=" %12.0f N
display "ANSWER: reduced_form estimate=" %21.12f rf " se=" %21.12f se_rf " n_obs=" %12.0f N
display "ANSWER: first_stage estimate=" %21.12f fs " se=" %21.12f se_fs " n_obs=" %12.0f N
