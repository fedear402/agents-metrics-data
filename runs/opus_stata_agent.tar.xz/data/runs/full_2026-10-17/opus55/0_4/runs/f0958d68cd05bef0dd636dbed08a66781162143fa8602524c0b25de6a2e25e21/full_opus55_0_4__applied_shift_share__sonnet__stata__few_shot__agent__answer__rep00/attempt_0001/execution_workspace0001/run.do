version 19.0
clear all
set more off
set linesize 255
import delimited using "input.csv", clear asdouble
egen r = group(region_id)
egen n = group(industry_id)
sort r n
mata:
r=st_data(.,"r"); n=st_data(.,"n"); sh=st_data(.,"share"); k=st_data(.,"shock")
w=st_data(.,"region_weight"); x=st_data(.,"x"); y=st_data(.,"y")
R=max(r); N=max(n)
S=J(R,N,0); shock=J(N,1,.); e=J(R,1,.); X=J(R,1,.); Y=J(R,1,.)
for(i=1;i<=rows(r);i++){
 S[r[i],n[i]]=S[r[i],n[i]]+sh[i]; shock[n[i]]=k[i]; e[r[i]]=w[i]; X[r[i]]=x[i]; Y[r[i]]=y[i]
}
assert(max(abs(rowsum(S):-1))<1e-8)
e=e/sum(e)
Z=S*shock
V=(Y,X,Z); V0=V:-e'*V
s=S'*e
agg=(S'*(e:*V0)):/s
est=J(2,2,.)
for(j=1;j<=2;j++){
 d=agg[,j]; en=agg[,j+1]
 Rg=(J(N,1,1),en); I=(J(N,1,1),shock)
 inv=luinv(I'*(s:*Rg)); b=inv*I'*(s:*d)
 u=d-Rg*b; sc=I:*(s:*u)
 Vc=N/(N-2)*inv*(sc'*sc)*inv'
 est[j,]=(b[2],sqrt(Vc[2,2]))
}
reff=sum(e:*V0[,3]:*V0[,1])/sum(e:*V0[,3]:*V0[,2])
rfs=sum(e:*V0[,3]:*V0[,2])/sum(e:*V0[,3]:^2)
printf("check regional: %g %g diffs %g %g\n",reff,rfs,est[1,1]-reff,est[2,1]-rfs)
printf("R=%g N=%g rows=%g\n",R,N,rows(r))
st_numscalar("b1",est[1,1]); st_numscalar("s1",est[1,2])
st_numscalar("b2",est[2,1]); st_numscalar("s2",est[2,2])
st_numscalar("es",1/sum(s:^2)); st_numscalar("N",N)
end
* independent check: regional weighted ivregress / regress
preserve
bysort r: keep if _n==1
quietly summarize region_weight
gen e = region_weight/r(sum)
restore
display "ANSWER: effect estimate=" %21.12f b1 " se=" %21.12f s1 " n_obs=" %12.0f N
display "ANSWER: first_stage estimate=" %21.12f b2 " se=" %21.12f s2 " n_obs=" %12.0f N
display "ANSWER: effective_shocks estimate=" %21.12f es " se=. n_obs=" %12.0f N
gen double zc = share*shock
bysort r: egen double z = total(zc)
bysort r: keep if _n==1
ivregress 2sls y (x=z) [aw=region_weight]
regress x z [aw=region_weight]
