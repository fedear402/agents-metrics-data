clear all
set more off
import delimited census.csv, clear
sort eligible
local P0 = nonrecipient_population[1]
local P1 = nonrecipient_population[2]
import delimited households.csv, clear
keep if recipient==0
local N = _N
gen e0 = 1-eligible
gen e1 = eligible
gen d0 = dose*e0
gen d1 = dose*e1
gen b0 = baseline*e0
gen b1 = baseline*e1
gen z0 = instrument*e0
gen z1 = instrument*e1
ivregress 2sls outcome e0 e1 b0 b1 (d0 d1 = z0 z1) [aw=weight], noconstant
local s0 = _b[d0]
local s1 = _b[d1]
sum dose [aw=weight] if eligible==0
local m0 = r(mean)
sum dose [aw=weight] if eligible==1
local m1 = r(mean)
local E0 = `s0'*`m0'
local E1 = `s1'*`m1'
local EP = (`P0'*`E0' + `P1'*`E1')/(`P0'+`P1')
* check: manual 2SLS matrix
gen sw = sqrt(weight)
foreach v in outcome e0 e1 b0 b1 d0 d1 z0 z1 {
 gen w_`v' = `v'*sw
}
mata: X=st_data(.,"w_d0 w_d1 w_e0 w_e1 w_b0 w_b1"); Z=st_data(.,"w_z0 w_z1 w_e0 w_e1 w_b0 w_b1"); y=st_data(.,"w_outcome"); PX=Z*invsym(Z'Z)*Z'X; b=invsym(PX'X)*PX'y; b[1..2]'
di "ivreg slopes: `s0' `s1'"
di "ANSWER: ineligible_effect estimate=" %18.10g `E0' " se=NA n_obs=`N'"
di "ANSWER: eligible_nonrecipient_effect estimate=" %18.10g `E1' " se=NA n_obs=`N'"
di "ANSWER: population_effect estimate=" %18.10g `EP' " se=NA n_obs=`N'"
