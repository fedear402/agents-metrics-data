clear all
set linesize 255
import delimited using "./input.csv", clear
keep if abs(score)<1 & !missing(score,participated,earnings)
gen double w = 1-abs(score)
gen byte r = score>=0
gen double rs = r*score
gen double ls = (1-r)*score
gen double one = 1
mata:
X = st_data(., ("r","rs","ls","one")); w = st_data(.,"w")
Y = st_data(., ("earnings","participated"))
B = invsym(X'*(w:*X))*X'*(w:*Y)
E = Y - X*B
n = rows(X)
A = invsym(X'*(w:*X))
G = (w:*X:*E[,1]), (w:*X:*E[,2])
M = G'*G
V = (A,J(4,4,0)\J(4,4,0),A)*M*(A,J(4,4,0)\J(4,4,0),A)
rf = B[1,1]; fs = B[1,2]; te = rf/fs
vrf = V[1,1]; vfs = V[5,5]; c = V[1,5]
g = (1/fs, -rf/fs^2)
vte = g*(vrf,c\c,vfs)*g'
st_numscalar("te",te); st_numscalar("rf",rf); st_numscalar("fs",fs)
st_numscalar("ste",sqrt(vte)); st_numscalar("srf",sqrt(vrf)); st_numscalar("sfs",sqrt(vfs)); st_numscalar("n",n)
end
display "ANSWER: treatment_effect estimate=" %21.12f te " se=" %21.12f ste " n_obs=" %12.0f n
display "ANSWER: reduced_form estimate=" %21.12f rf " se=" %21.12f srf " n_obs=" %12.0f n
display "ANSWER: first_stage estimate=" %21.12f fs " se=" %21.12f sfs " n_obs=" %12.0f n
* check: regress HC0 equivalence
regress earnings r rs ls [pw=w]
di "check rf se HC0 = " _se[r]*sqrt((e(N)-4)/e(N))
ivregress 2sls earnings rs ls (participated = r) [pw=w], vce(robust) small
di "check te se HC0 = " _se[participated]*sqrt((e(N)-4)/e(N))
