import delimited census.csv, clear
tempfile c
save `c'
import delimited households.csv, clear
keep if recipient==0
gen e0=1-eligible
gen e1=eligible
gen d0=dose*e0
gen d1=dose*e1
gen b0=baseline*e0
gen b1=baseline*e1
gen z0=instrument*e0
gen z1=instrument*e1
ivregress 2sls outcome e0 e1 b0 b1 (d0 d1 = z0 z1) [aw=weight], nocons
local s0=_b[d0]
local s1=_b[d1]
local N=e(N)
* check via matrices
mata: y=st_data(.,"outcome"); X=st_data(.,("d0","d1","e0","e1","b0","b1")); Z=st_data(.,("z0","z1","e0","e1","b0","b1")); w=st_data(.,"weight"); P=X'(w:*Z)*invsym(Z'(w:*Z)); b=invsym(P*Z'(w:*X))*P*Z'(w:*y); b'
sum dose [aw=weight] if e1==0
local m0=r(mean)
sum dose [aw=weight] if e1==1
local m1=r(mean)
local f0=`s0'*`m0'
local f1=`s1'*`m1'
use `c', clear
sum nonrecipient_population if eligible==0
local p0=r(sum)
sum nonrecipient_population if eligible==1
local p1=r(sum)
local pe=(`p0'*`f0'+`p1'*`f1')/(`p0'+`p1')
di "ANSWER: ineligible_effect estimate=" %18.10g `f0' " se=NA n_obs=" `N'
di "ANSWER: eligible_nonrecipient_effect estimate=" %18.10g `f1' " se=NA n_obs=" `N'
di "ANSWER: population_effect estimate=" %18.10g `pe' " se=NA n_obs=" `N'
