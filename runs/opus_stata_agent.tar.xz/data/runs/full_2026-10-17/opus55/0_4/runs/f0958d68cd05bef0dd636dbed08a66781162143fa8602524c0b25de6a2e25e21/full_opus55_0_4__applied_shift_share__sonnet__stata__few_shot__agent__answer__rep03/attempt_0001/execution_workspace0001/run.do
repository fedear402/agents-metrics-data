version 19.0
clear all
set more off
set linesize 255
import delimited using "input.csv", clear
sort region_id industry_id
egen r = group(region_id)
egen n = group(industry_id)
quietly summarize r
local R = r(max)
quietly summarize n
local N = r(max)
display "regions=`R' industries=`N' rows=" _N
mata:
d=st_data(.,("r","n","share","shock","region_weight","x","y"))
R=max(d[,1]); N=max(d[,2])
S=J(R,N,0); shock=J(N,1,.); w=J(R,1,.); X=J(R,1,.); Y=J(R,1,.)
for(i=1;i<=rows(d);i++){
  S[d[i,1],d[i,2]]=S[d[i,1],d[i,2]]+d[i,3]
  shock[d[i,2]]=d[i,4]; w[d[i,1]]=d[i,5]; X[d[i,1]]=d[i,6]; Y[d[i,1]]=d[i,7]
}
assert(max(abs(rowsum(S):-1))<1e-8)
e=w/sum(w)
Z=S*shock
reg=(Y,X,Z)
c=reg:-e'*reg
s=S'*e
agg=(S'*(e:*c)):/s
est=J(2,2,.)
for(k=1;k<=2;k++){
  dep=agg[,k]; en=agg[,k+1]
  Xm=(J(N,1,1),en); Zm=(J(N,1,1),shock)
  inv=luinv(Zm'*(s:*Xm))
  b=inv*Zm'*(s:*dep)
  u=dep-Xm*b
  sc=Zm:*(s:*u)
  V=N/(N-2)*inv*(sc'*sc)*inv'
  est[k,]=(b[2],sqrt(V[2,2]))
}
reff=sum(e:*c[,3]:*c[,1])/sum(e:*c[,3]:*c[,2])
rfs=sum(e:*c[,3]:*c[,2])/sum(e:*c[,3]:^2)
printf("regional checks: %g %g\n", est[1,1]-reff, est[2,1]-rfs)
st_numscalar("b1",est[1,1]); st_numscalar("se1",est[1,2])
st_numscalar("b2",est[2,1]); st_numscalar("se2",est[2,2])
st_numscalar("eff",1/sum(s:^2)); st_numscalar("NN",N)
end
* independent check: regional weighted ivregress / regress
preserve
bysort region_id: gen z = sum(share*shock)
by region_id: keep if _n==_N
ivregress 2sls y (x=z) [aw=region_weight]
regress x z [aw=region_weight]
restore
display "ANSWER: effect estimate=" %21.12f b1 " se=" %21.12f se1 " n_obs=" %12.0f NN
display "ANSWER: first_stage estimate=" %21.12f b2 " se=" %21.12f se2 " n_obs=" %12.0f NN
display "ANSWER: effective_shocks estimate=" %21.12f eff " se=. n_obs=" %12.0f NN
