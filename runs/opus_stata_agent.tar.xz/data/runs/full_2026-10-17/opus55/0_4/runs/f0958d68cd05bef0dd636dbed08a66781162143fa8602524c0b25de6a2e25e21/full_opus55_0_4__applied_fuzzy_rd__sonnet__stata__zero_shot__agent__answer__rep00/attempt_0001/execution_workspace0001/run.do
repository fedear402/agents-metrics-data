set linesize 255
import delimited using input.csv, clear
keep if abs(score)<1 & !missing(score,participated,earnings)
gen double w = 1-abs(score)
gen double r = score>=0
gen double rs = r*score
gen double cons = 1
mata:
X = st_data(., ("r","score","rs","cons")); w = st_data(.,"w")
y = st_data(.,"earnings"); d = st_data(.,"participated")
A = invsym(cross(X,w,X))
by = A*cross(X,w,y); bd = A*cross(X,w,d)
ey = y-X*by; ed = d-X*bd
U = (X:*(w:*ey), X:*(w:*ed))
M = blockdiag(A,A)
V = M*cross(U,U)*M
rf = by[1]; fs = bd[1]
vrf = V[1,1]; vfs = V[5,5]; c = V[1,5]
te = rf/fs
g = (1/fs, -rf/fs^2)
vte = g*(vrf,c\c,vfs)*g'
st_numscalar("te",te); st_numscalar("sete",sqrt(vte))
st_numscalar("rf",rf); st_numscalar("serf",sqrt(vrf))
st_numscalar("fs",fs); st_numscalar("sefs",sqrt(vfs))
st_numscalar("n",rows(X))
end
display "ANSWER: treatment_effect estimate=" %21.12f te " se=" %21.12f sete " n_obs=" %12.0f n
display "ANSWER: reduced_form estimate=" %21.12f rf " se=" %21.12f serf " n_obs=" %12.0f n
display "ANSWER: first_stage estimate=" %21.12f fs " se=" %21.12f sefs " n_obs=" %12.0f n
* check: built-in regress HC0 equivalents and ivregress
regress earnings r score rs [aw=w], vce(robust)
di _se[r]*sqrt((e(N)-e(df_m)-1)/e(N))
ivregress 2sls earnings score rs (participated = r) [aw=w], vce(robust)
