set linesize 255
import delimited using "./input.csv", clear
gen d = date(date,"YMD")
sort d
gen t=_n
tsset t
gen ly=ln(sales)
gen lv=ln(vix)
gen dv=D.lv
newey ly L(1/15).dv, lag(15)
local N=e(N)
lincom L1.dv+L2.dv+L3.dv+L4.dv+L5.dv+L6.dv+L7.dv+L8.dv+L9.dv+L10.dv+L11.dv+L12.dv+L13.dv+L14.dv+L15.dv
display "ANSWER: cumulative_response estimate=" %21.12f r(estimate) " se=" %21.12f r(se) " n_obs=" %12.0f `N'
display "ANSWER: lag_1 estimate=" %21.12f _b[L1.dv] " se=" %21.12f _se[L1.dv] " n_obs=" %12.0f `N'
display "ANSWER: lag_15 estimate=" %21.12f _b[L15.dv] " se=" %21.12f _se[L15.dv] " n_obs=" %12.0f `N'
