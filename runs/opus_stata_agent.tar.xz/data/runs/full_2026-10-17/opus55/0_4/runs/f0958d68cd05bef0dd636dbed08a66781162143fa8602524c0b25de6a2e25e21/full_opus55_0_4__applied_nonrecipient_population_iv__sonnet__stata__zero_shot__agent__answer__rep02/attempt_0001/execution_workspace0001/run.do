clear all
set more off
import delimited census.csv, clear
tempfile c
save `c'
import delimited households.csv, clear
keep if recipient==0
gen e0=1-eligible
gen e1=eligible
gen d0=dose*e0
gen d1=dose*e1
gen b0=baseline*e0
gen b1=baseline*e1
gen z0=instrument*e0
gen z1=instrument*e1
ivregress 2sls outcome e0 e1 b0 b1 (d0 d1 = z0 z1) [aw=weight], noconstant
local N=e(N)
scalar s0=_b[d0]
scalar s1=_b[d1]
sum dose [aw=weight] if eligible==0
scalar m0=r(mean)
sum dose [aw=weight] if eligible==1
scalar m1=r(mean)
* check via manual 2SLS
reg d0 e0 e1 b0 b1 z0 z1 [aw=weight], nocons
predict h0
reg d1 e0 e1 b0 b1 z0 z1 [aw=weight], nocons
predict h1
reg outcome e0 e1 b0 b1 h0 h1 [aw=weight], nocons
di "manual check: " _b[h0] " vs " s0 ", " _b[h1] " vs " s1
scalar ef0=s0*m0
scalar ef1=s1*m1
use `c', clear
sum nonrecipient_population if eligible==0
scalar p0=r(mean)
sum nonrecipient_population if eligible==1
scalar p1=r(mean)
scalar pe=(p0*ef0+p1*ef1)/(p0+p1)
di "ANSWER: ineligible_effect estimate=" %18.10g ef0 " se=NA n_obs=`N'"
di "ANSWER: eligible_nonrecipient_effect estimate=" %18.10g ef1 " se=NA n_obs=`N'"
di "ANSWER: population_effect estimate=" %18.10g pe " se=NA n_obs=`N'"
