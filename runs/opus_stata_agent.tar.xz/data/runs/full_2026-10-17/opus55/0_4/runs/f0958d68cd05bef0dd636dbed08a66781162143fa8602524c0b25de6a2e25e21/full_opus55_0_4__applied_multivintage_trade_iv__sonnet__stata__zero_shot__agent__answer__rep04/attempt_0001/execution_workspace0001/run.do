clear all
set more off
import delimited crosswalk.csv, clear stringcols(1)
tempfile cw emp ar tr
save `cw'
import delimited trade.csv, clear stringcols(2)
merge m:1 code using `cw', assert(match) nogen
save `tr'
import delimited areas.csv, clear
save `ar'
import delimited outcomes.csv, clear
tempfile out
save `out'
import delimited employment.csv, clear
save `emp'
use `ar', clear
* full grid of area x period x vintage x industry (missing = 0)
keep area period vintage
expand 4
bysort area period vintage: gen industry=_n-1
merge 1:1 area period vintage industry using `emp', keep(master match) nogen
replace employment=0 if missing(employment)
bysort period vintage industry: egen natemp=total(employment)
merge m:1 area period vintage using `ar', assert(match) nogen
merge m:1 period industry using `tr', assert(match) nogen
gen term = cond(vintage=="base", us_change, other_change)
replace term = (employment/total_employment)*(term/natemp)/(price_index/100)/1000*(10/years)
gen pop_b = population if vintage=="base"
collapse (sum) term (max) pop_b, by(area period vintage)
reshape wide term pop_b, i(area period) j(vintage) string
rename termbase x
rename termearly z
rename pop_bbase pop
merge 1:1 area period using `out', assert(match) nogen
* note: outcomes merged directly
ivregress 2sls change_pp period control (x = z) [aw=pop]
local b = _b[x]
local n = e(N)
su x if area==0 & period==0, meanonly
local x0 = r(mean)
su x if area==0 & period==1, meanonly
local x1 = r(mean)
su z if area==0 & period==0, meanonly
local z0 = r(mean)
di "ANSWER: iv_slope estimate=" %-18.12g `b' "se=NA n_obs=" `n'
di "ANSWER: exposure_area0_period0 estimate=" %-18.12g `x0' "se=NA n_obs=" `n'
di "ANSWER: exposure_area0_period1 estimate=" %-18.12g `x1' "se=NA n_obs=" `n'
di "ANSWER: instrument_area0_period0 estimate=" %-18.12g `z0' "se=NA n_obs=" `n'
* check: manual IV with weights
gen one=1
mata: y=st_data(.,"change_pp"); X=st_data(.,("one","period","control","x")); Z=st_data(.,("one","period","control","z")); w=st_data(.,"pop"); b=lusolve(Z'(w:*X),Z'(w:*y)); b'
