clear all
set type double
tempfile cw tr emp
import delimited crosswalk.csv, clear stringcols(1)
save `cw'
import delimited trade.csv, clear stringcols(2)
merge m:1 code using `cw', assert(match) nogen
keep period industry us_change other_change price_index years
save `tr'
import delimited employment.csv, clear
save `emp'
tempfile out
import delimited outcomes.csv, clear
save `out'
import delimited areas.csv, clear
expand 4
bysort area period vintage: gen industry=_n-1
merge 1:1 area period vintage industry using `emp', assert(master match) nogen
replace employment=0 if missing(employment)
bysort period vintage industry: egen double nat=total(employment)
merge m:1 period industry using `tr', assert(match) nogen
gen double chg=cond(vintage=="base",us_change,other_change)
gen double term=(employment/total_employment)*(chg/nat)/(price_index/100)/1000*(10/years)
collapse (sum) e=term (first) population, by(area period vintage)
reshape wide e population, i(area period) j(vintage) string
rename ebase x
rename eearly z
rename populationbase pop
merge 1:1 area period using `out', nogen assert(match)
ivregress 2sls change_pp period control (x=z) [aw=pop]
local n=e(N)
di "ANSWER: iv_slope estimate=" %20.12g _b[x] " se=NA n_obs=" `n'
sort area period
di "ANSWER: exposure_area0_period0 estimate=" %20.12g x[1] " se=NA n_obs=" `n'
di "ANSWER: exposure_area0_period1 estimate=" %20.12g x[2] " se=NA n_obs=" `n'
di "ANSWER: instrument_area0_period0 estimate=" %20.12g z[1] " se=NA n_obs=" `n'
reg x z period control [aw=pop]
predict xh
reg change_pp xh period control [aw=pop]
