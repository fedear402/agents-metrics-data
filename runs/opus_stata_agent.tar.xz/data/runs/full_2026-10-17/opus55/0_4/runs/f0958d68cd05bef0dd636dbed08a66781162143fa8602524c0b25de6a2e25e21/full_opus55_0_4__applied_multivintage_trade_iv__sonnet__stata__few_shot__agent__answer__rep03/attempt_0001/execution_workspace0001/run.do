clear all
set type double
tempfile cw tr ar em
import delimited crosswalk.csv, clear stringcols(1)
save `cw'
import delimited trade.csv, clear stringcols(2)
merge 1:1 code using `cw', assert(match) nogen
save `tr'
import delimited employment.csv, clear
save `em'
import delimited areas.csv, clear
save `ar'
keep area period vintage
expand 4
bys area period vintage: gen industry=_n-1
merge 1:1 area period vintage industry using `em', assert(1 3) nogen
replace employment=0 if missing(employment)
bys period vintage industry: egen double nat=total(employment)
merge m:1 area period vintage using `ar', assert(3) nogen
merge m:1 period industry using `tr', assert(3) nogen
gen double chg=cond(vintage=="base",us_change,other_change)
gen double term=(employment/total_employment)*(chg/nat)/(price_index/100)/1000*(10/years)
collapse (sum) term, by(area period vintage)
reshape wide term, i(area period) j(vintage) string
rename (termbase termearly) (x z)
preserve
import delimited areas.csv, clear
keep if vintage=="base"
keep area period population
save `ar', replace
restore
merge 1:1 area period using `ar', assert(3) nogen

tempfile main
save `main'
import delimited outcomes.csv, clear
merge 1:1 area period using `main', assert(3) nogen
ivregress 2sls change_pp period control (x=z) [aw=population]
local n=e(N)
di "ANSWER: iv_slope estimate=" %20.12g _b[x] " se=NA n_obs=`n'"
sum x if area==0 & period==0, meanonly
di "ANSWER: exposure_area0_period0 estimate=" %20.12g r(mean) " se=NA n_obs=`n'"
sum x if area==0 & period==1, meanonly
di "ANSWER: exposure_area0_period1 estimate=" %20.12g r(mean) " se=NA n_obs=`n'"
sum z if area==0 & period==0, meanonly
di "ANSWER: instrument_area0_period0 estimate=" %20.12g r(mean) " se=NA n_obs=`n'"
* check: manual 2SLS via first stage fitted values
qui reg x z period control [aw=population]
predict xh
qui reg change_pp xh period control [aw=population]
di "CHECK manual 2sls slope " %20.12g _b[xh]
