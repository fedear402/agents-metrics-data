set linesize 255
import delimited using input.csv, clear
keep if abs(score)<1 & !missing(score,participated,earnings)
gen double w=1-abs(score)
gen byte r=score>=0
gen double rs=r*score
mata:
X=st_data(.,("r","score","rs")); X=X,J(rows(X),1,1)
w=st_data(.,"w"); y=st_data(.,"earnings"); d=st_data(.,"participated")
B=invsym(cross(X,w,X))
by=B*cross(X,w,y); bd=B*cross(X,w,d)
ey=y-X*by; ed=d-X*bd
IFy=(X:*(w:*ey))*B; IFd=(X:*(w:*ed))*B
G=IFy[.,1],IFd[.,1]
V=cross(G,G)
rf=by[1]; fs=bd[1]; te=rf/fs
g=(1/fs)\(-rf/fs^2)
st_numscalar("rf",rf); st_numscalar("fs",fs); st_numscalar("te",te)
st_numscalar("serf",sqrt(V[1,1])); st_numscalar("sefs",sqrt(V[2,2])); st_numscalar("sete",sqrt(g'*V*g))
st_numscalar("n",rows(X))
end
reg earnings r score rs [pw=w], vce(robust)
reg participated r score rs [pw=w], vce(robust)
display "ANSWER: treatment_effect estimate=" %21.12f te " se=" %21.12f sete " n_obs=" %12.0f n
display "ANSWER: reduced_form estimate=" %21.12f rf " se=" %21.12f serf " n_obs=" %12.0f n
display "ANSWER: first_stage estimate=" %21.12f fs " se=" %21.12f sefs " n_obs=" %12.0f n
* check: weighted IV, HC0
gen double zr=r
ivregress 2sls earnings score rs (participated=zr) [pw=w], vce(robust)
