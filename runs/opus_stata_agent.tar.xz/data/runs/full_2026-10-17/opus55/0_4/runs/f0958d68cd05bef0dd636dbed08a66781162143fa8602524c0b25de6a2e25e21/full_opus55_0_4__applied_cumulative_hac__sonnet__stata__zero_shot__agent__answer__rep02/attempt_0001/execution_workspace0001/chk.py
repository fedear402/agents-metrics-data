import pandas as pd,numpy as np
d=pd.read_csv('input.csv').sort_values('date');y=np.log(d.sales.values);x=np.diff(np.log(d.vix.values),prepend=np.nan)
X=np.column_stack([np.ones(len(y))]+[np.roll(x,k) for k in range(1,16)])[16:];y=y[16:]
N=len(y);b=np.linalg.lstsq(X,y,rcond=None)[0];u=y-X@b;g=X*u[:,None];S=g.T@g
for j in range(1,16):G=g[j:].T@g[:-j];S+=(1-j/16)*(G+G.T)
B=np.linalg.inv(X.T@X);V=B@S@B*N/(N-16);w=np.r_[0,np.ones(15)]
print(N,w@b,np.sqrt(w@V@w),b[1],np.sqrt(V[1,1]),b[15],np.sqrt(V[15,15]))
