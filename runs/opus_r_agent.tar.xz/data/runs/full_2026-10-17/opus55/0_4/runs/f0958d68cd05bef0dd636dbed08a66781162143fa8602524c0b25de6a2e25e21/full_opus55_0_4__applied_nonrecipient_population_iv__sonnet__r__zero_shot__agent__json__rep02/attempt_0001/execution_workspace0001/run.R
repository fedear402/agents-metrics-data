library(jsonlite)
h <- read.csv("households.csv"); cen <- read.csv("census.csv")
d <- h[h$recipient == 0, ]; n <- nrow(d)
e <- d$eligible; ne <- 1 - e; w <- d$weight
X <- cbind(d$dose*ne, d$dose*e, ne, e, d$baseline*ne, d$baseline*e)
Z <- cbind(ne, e, d$baseline*ne, d$baseline*e, d$instrument*ne, d$instrument*e)
W <- diag(w)
Pz <- Z %*% solve(t(Z) %*% W %*% Z, t(Z) %*% W)
Xh <- Pz %*% X
b <- solve(t(Xh) %*% W %*% X, t(Xh) %*% W %*% d$outcome)
# check: two-stage via lm
Xhat <- apply(X[,1:2], 2, function(v) fitted(lm(v ~ Z - 1, weights = w)))
b2 <- coef(lm(d$outcome ~ Xhat + X[,3:6] - 1, weights = w))
stopifnot(max(abs(b2 - b)) < 1e-8)
m0 <- weighted.mean(d$dose[e==0], w[e==0]); m1 <- weighted.mean(d$dose[e==1], w[e==1])
ie <- b[1]*m0; ee <- b[2]*m1
p0 <- cen$nonrecipient_population[cen$eligible==0]; p1 <- cen$nonrecipient_population[cen$eligible==1]
pe <- (p0*ie + p1*ee)/(p0+p1)
est <- lapply(list(c("ineligible_effect",ie), c("eligible_nonrecipient_effect",ee), c("population_effect",pe)),
  function(x) list(term=x[1], estimate=as.numeric(x[2]), se=NULL, n_obs=n))
write_json(list(task_id="applied_nonrecipient_population_iv", platform="r", estimates=est,
  method_metadata=list(estimator="weighted 2SLS, group-interacted, no extra intercept", weights="weight"),
  diagnostics=list(n_ineligible=sum(e==0), n_eligible=sum(e==1), slope_ineligible=b[1], slope_eligible=b[2],
    mean_dose_ineligible=m0, mean_dose_eligible=m1, twostage_check_maxdiff=max(abs(b2-b)))),
  "result.json", auto_unbox=TRUE, digits=NA, null="null", pretty=TRUE)
