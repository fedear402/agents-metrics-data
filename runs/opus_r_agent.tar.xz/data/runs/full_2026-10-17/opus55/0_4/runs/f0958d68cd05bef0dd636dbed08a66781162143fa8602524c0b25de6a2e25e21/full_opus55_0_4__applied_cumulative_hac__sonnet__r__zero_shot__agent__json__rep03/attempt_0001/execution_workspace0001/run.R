library(sandwich); library(jsonlite)
d <- read.csv("input.csv"); d <- d[order(as.Date(d$date)),]
y <- log(d$sales); dv <- c(NA, diff(log(d$vix))); n <- length(y)
X <- sapply(1:15, function(k) c(rep(NA,k), dv[1:(n-k)])); colnames(X) <- paste0("L",1:15)
df <- data.frame(y=y, X); df <- df[complete.cases(df),]
m <- lm(y ~ ., data=df); N <- nobs(m)
V <- NeweyWest(m, lag=15, prewhite=FALSE, adjust=FALSE) * N/(N-16)
b <- coef(m)[-1]; w <- c(0, rep(1,15))
# independent manual HAC check
Xm <- model.matrix(m); u <- resid(m); S <- crossprod(Xm*u)
for (j in 1:15) { G <- crossprod(Xm[(j+1):N,]*u[(j+1):N], Xm[1:(N-j),]*u[1:(N-j)]); S <- S + (1-j/16)*(G+t(G)) }
B <- solve(crossprod(Xm)); V2 <- B %*% S %*% B * N/(N-16)
chk <- max(abs(V-V2)); cat("maxdiff", chk, "N", N, "\n")
cs <- sqrt(drop(t(w)%*%V%*%w))
est <- list(list(term="cumulative_response",estimate=sum(b),se=cs,n_obs=N),
 list(term="lag_1",estimate=b[[1]],se=sqrt(V[2,2]),n_obs=N),
 list(term="lag_15",estimate=b[[15]],se=sqrt(V[16,16]),n_obs=N))
write(toJSON(list(task_id="applied_cumulative_hac",platform="r",estimates=est,
 method_metadata=list(estimator="OLS distributed lag",vcov="Newey-West Bartlett lag 15, x N/(N-16)"),
 diagnostics=list(manual_hac_maxdiff=chk, rows=n)),auto_unbox=TRUE,digits=NA),"result.json")
writeLines(c(sprintf("Rows %d; regression N=%d (= rows-16).",n,N),
 sprintf("Manual Bartlett HAC vs sandwich::NeweyWest max abs diff: %g",chk),
 "Cumulative SE from w'Vw with full covariance."),"verification.txt")
