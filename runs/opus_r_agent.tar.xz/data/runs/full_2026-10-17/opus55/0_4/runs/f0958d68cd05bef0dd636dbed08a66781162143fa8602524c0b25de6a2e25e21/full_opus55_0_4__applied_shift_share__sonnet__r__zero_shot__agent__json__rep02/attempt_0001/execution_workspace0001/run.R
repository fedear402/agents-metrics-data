library(jsonlite)
d <- read.csv("input.csv")
d <- d[order(d$region_id, d$industry_id), ]
R <- d[!duplicated(d$region_id), c("region_id","region_weight","x","y")]
R$e <- R$region_weight / sum(R$region_weight)
z <- tapply(d$share*d$shock, d$region_id, sum)
R$z <- as.numeric(z[as.character(R$region_id)])
wiv <- function(y, x, z, w) {  # weighted IV, intercept, HC1 for slope
  X <- cbind(1, x); Z <- cbind(1, z); W <- w
  b <- solve(t(Z) %*% (W*X), t(Z) %*% (W*y))
  u <- as.numeric(y - X %*% b); n <- length(y)
  A <- solve(t(Z) %*% (W*X))
  M <- t(Z) %*% ((W*u)^2 * Z)
  V <- A %*% M %*% t(A) * n/(n-2)
  c(b[2], sqrt(V[2,2]))
}
reg_iv <- wiv(R$y, R$x, R$z, R$e)
reg_fs <- wiv(R$x, R$z, R$z, R$e)
m <- function(v) v - sum(R$e*v)
R$y0 <- m(R$y); R$x0 <- m(R$x); R$z0 <- m(R$z)
d <- merge(d, R[, c("region_id","e","y0","x0","z0")], by="region_id")
d$w <- d$e*d$share
s <- c(tapply(d$w, d$industry_id, sum))
agg <- function(v) c(tapply(d$w*v, d$industry_id, sum))/s
yb <- agg(d$y0); xb <- agg(d$x0); zb <- agg(d$z0)
g <- c(tapply(d$shock, d$industry_id, function(v) v[1]))
N <- length(s)
ef <- wiv(yb, xb, g, s); fs <- wiv(xb, zb, g, s)
# cross-check with ivreg+sandwich
library(AER)
chk <- ivreg(yb ~ xb | g, weights = s); se2 <- sqrt(sandwich::vcovHC(chk, type="HC1")[2,2])
eff <- 1/sum(s^2)
cat("regional IV", reg_iv[1], "shock IV", ef, "ivreg", coef(chk)[2], se2, "\n")
cat("regional FS", reg_fs[1], "shock FS", fs, "\nN", N, "regions", nrow(R), "sum s", sum(s), "eff", eff, "\n")
writeLines(sprintf("Checks:\nRegional 2SLS slope %.10g equals shock-level slope %.10g.\nRegional FS slope %.10g equals shock-level slope %.10g.\nManual HC1 SE %.10g vs AER::ivreg+sandwich HC1 SE %.10g.\nN industries=%d, regions=%d, sum s_n=%.10g (should be 1). effective_shocks=%.10g.",
  reg_iv[1], ef[1], reg_fs[1], fs[1], ef[2], se2, N, nrow(R), sum(s), eff), "verification.txt")
out <- list(task_id="applied_shift_share", platform="r",
  estimates=list(list(term="effect",estimate=ef[1],se=ef[2],n_obs=N),
    list(term="first_stage",estimate=fs[1],se=fs[2],n_obs=N),
    list(term="effective_shocks",estimate=eff,se=NULL,n_obs=N)),
  method_metadata=list(estimator="weighted 2SLS, shift-share IV", vcov="BHJ shock-level HC1, N/(N-2)"),
  diagnostics=list(regions=nrow(R)))
write(toJSON(out, auto_unbox=TRUE, digits=12, null="null"), "result.json")
