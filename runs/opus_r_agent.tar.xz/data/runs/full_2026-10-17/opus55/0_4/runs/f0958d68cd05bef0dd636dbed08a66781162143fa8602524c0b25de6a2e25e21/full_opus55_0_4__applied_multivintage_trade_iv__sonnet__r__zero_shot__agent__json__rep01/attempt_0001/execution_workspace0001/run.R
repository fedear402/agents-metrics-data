library(jsonlite)
cw <- read.csv("crosswalk.csv", colClasses=c(code="character"))
tr <- merge(read.csv("trade.csv"), cw, by="code")
ar <- read.csv("areas.csv"); em <- read.csv("employment.csv"); oc <- read.csv("outcomes.csv")
# complete grid, missing = 0
g <- expand.grid(area=unique(ar$area), period=unique(ar$period), vintage=c("base","early"), industry=0:3, stringsAsFactors=FALSE)
g <- merge(g, em, all.x=TRUE); g$employment[is.na(g$employment)] <- 0
nat <- aggregate(employment~period+vintage+industry, g, sum); names(nat)[4] <- "nat"
g <- merge(merge(g, nat), ar[,c("area","period","vintage","total_employment")])
g <- merge(g, tr[,c("period","industry","us_change","other_change","price_index","years")])
g$chg <- ifelse(g$vintage=="base", g$us_change, g$other_change)
g$term <- g$employment/g$total_employment*g$chg/g$nat/(g$price_index/100)/1000*(10/g$years)
ex <- aggregate(term~area+period+vintage, g, sum)
d <- merge(oc, setNames(ex[ex$vintage=="base",c(1,2,4)], c("area","period","x")))
d <- merge(d, setNames(ex[ex$vintage=="early",c(1,2,4)], c("area","period","z")))
d <- merge(d, ar[ar$vintage=="base", c("area","period","population")])
stopifnot(nrow(d)==72)
X <- cbind(1, d$period, d$control, d$x); Z <- cbind(1, d$period, d$control, d$z); w <- d$population
Xh <- Z %*% solve(t(Z)%*%(w*Z), t(Z)%*%(w*X))
b <- solve(t(Xh)%*%(w*X), t(Xh)%*%(w*d$change_pp))
# check: indirect least squares (just identified)
b2 <- solve(t(Z)%*%(w*X), t(Z)%*%(w*d$change_pp))
cat("2SLS:", b, "\nILS:", b2, "\n")
v <- function(a,p,col) d[d$area==a & d$period==p, col]
est <- list(iv_slope=b[4], exposure_area0_period0=v(0,0,"x"), exposure_area0_period1=v(0,1,"x"), instrument_area0_period0=v(0,0,"z"))
print(est)
write_json(list(task_id="applied_multivintage_trade_iv", platform="r",
  estimates=lapply(names(est), function(n) list(term=n, estimate=unname(est[[n]]), se=NULL, n_obs=72L)),
  method_metadata=list(estimator="weighted 2SLS", weight="base population", instruments="intercept, period, control, z"),
  diagnostics=list(n_obs=72L, ils_slope=b2[4])), "result.json", auto_unbox=TRUE, digits=NA, null="null")
