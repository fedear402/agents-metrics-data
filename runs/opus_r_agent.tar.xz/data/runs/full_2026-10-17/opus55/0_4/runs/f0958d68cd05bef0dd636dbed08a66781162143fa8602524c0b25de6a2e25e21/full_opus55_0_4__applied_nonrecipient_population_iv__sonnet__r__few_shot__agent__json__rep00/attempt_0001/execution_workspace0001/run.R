d <- subset(read.csv("households.csv"), recipient==0); census <- read.csv("census.csv")
e <- d$eligible; ne <- 1-e; w <- d$weight
C <- cbind(ne, e, d$baseline*ne, d$baseline*e)
X <- cbind(C, d$dose*ne, d$dose*e); Z <- cbind(C, d$instrument*ne, d$instrument*e)
sw <- sqrt(w); Xw <- X*sw; Zw <- Z*sw; yw <- d$outcome*sw
Xh <- qr.fitted(qr(Zw), Xw)
b <- as.numeric(qr.coef(qr(Xh), yw))
md <- c(weighted.mean(d$dose[e==0], w[e==0]), weighted.mean(d$dose[e==1], w[e==1]))
eff <- b[5:6]*md
pw <- census$nonrecipient_population[match(0:1, census$eligible)]
pop <- sum(eff*pw)/sum(pw)
n <- nrow(d)
est <- lapply(list(c("ineligible_effect",eff[1]),c("eligible_nonrecipient_effect",eff[2]),c("population_effect",pop)),
  function(v) list(term=v[1], estimate=as.numeric(v[2]), se=NA, n_obs=n))
jsonlite::write_json(list(task_id="applied_nonrecipient_population_iv", platform="r", estimates=est,
  method_metadata=list(estimator="weighted 2SLS, fully interacted by eligibility, no extra intercept"),
  diagnostics=list(n_obs=n, n_ineligible=sum(e==0), n_eligible=sum(e==1), slopes=b[5:6], mean_dose=md, pop_weights=pw)),
  "result.json", auto_unbox=TRUE, digits=NA, na="null")
# check: interacted model == separate per-group weighted IV
chk <- sapply(0:1, function(g){a<-d[e==g,]; s<-sqrt(a$weight)
 Xa<-cbind(1,a$baseline,a$dose)*s; Za<-cbind(1,a$baseline,a$instrument)*s
 qr.coef(qr(qr.fitted(qr(Za),Xa)),a$outcome*s)[3]})
cat("slopes", b[5:6], "sep", chk, "maxdiff", max(abs(chk-b[5:6])), "\n")
