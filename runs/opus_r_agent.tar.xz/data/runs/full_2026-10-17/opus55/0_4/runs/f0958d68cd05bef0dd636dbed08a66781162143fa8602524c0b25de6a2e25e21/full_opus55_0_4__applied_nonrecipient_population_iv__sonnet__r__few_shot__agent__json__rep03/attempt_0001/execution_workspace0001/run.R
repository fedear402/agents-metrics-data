d <- read.csv("households.csv"); d <- d[d$recipient==0,]
census <- read.csv("census.csv")
e <- d$eligible; ne <- 1-e; w <- d$weight; sw <- sqrt(w)
C <- cbind(ne, e, d$baseline*ne, d$baseline*e)
X <- cbind(C, d$dose*ne, d$dose*e); Z <- cbind(C, d$instrument*ne, d$instrument*e)
Xh <- qr.fitted(qr(Z*sw), X*sw)
b <- qr.coef(qr(Xh), d$outcome*sw)
mdose <- sapply(0:1, function(g) weighted.mean(d$dose[e==g], w[e==g]))
eff <- b[5:6]*mdose
pop <- census$nonrecipient_population[match(0:1, census$eligible)]
pe <- sum(eff*pop)/sum(pop)
# check: separate per-group IV equals pooled interacted fit
chk <- sapply(0:1, function(g){a<-d[e==g,];s<-sqrt(a$weight)
 Xg<-cbind(1,a$baseline,a$dose)*s; Zg<-cbind(1,a$baseline,a$instrument)*s
 qr.coef(qr(qr.fitted(qr(Zg),Xg)),a$outcome*s)[3]})
n <- nrow(d)
est <- data.frame(term=c("ineligible_effect","eligible_nonrecipient_effect","population_effect"),
 estimate=c(eff,pe), se=NA, n_obs=as.integer(n))
jsonlite::write_json(list(task_id="applied_nonrecipient_population_iv", platform="r", estimates=est,
 method_metadata=list(estimator="weighted 2SLS, group-interacted, no common intercept", weights="weight"),
 diagnostics=list(slopes=unname(b[5:6]), mean_dose=mdose, n_by_group=as.integer(table(e)), census_weights=pop,
   separate_group_iv_slopes=unname(chk))),
 "result.json", auto_unbox=TRUE, digits=NA, na="null", pretty=TRUE)
print(b); print(chk)
