library(sandwich); library(jsonlite)
d <- read.csv("input.csv"); d$date <- as.Date(d$date); d <- d[order(d$date),]
dv <- c(NA, diff(log(d$vix))); T <- nrow(d)
X <- sapply(1:15, function(k) c(rep(NA,k), dv[1:(T-k)]))
colnames(X) <- paste0("lag_",1:15)
df <- data.frame(y=log(d$sales), X); df <- df[complete.cases(df),]
m <- lm(y ~ ., data=df); N <- nobs(m)
V <- NeweyWest(m, lag=15, prewhite=FALSE, adjust=FALSE) * N/(N-16)
# independent manual HAC check
Xm <- model.matrix(m); u <- resid(m); S <- crossprod(Xm*u)
for (j in 1:15) { G <- crossprod(Xm[(j+1):N,]*u[(j+1):N], Xm[1:(N-j),]*u[1:(N-j)]); S <- S + (1-j/16)*(G+t(G)) }
B <- solve(crossprod(Xm)); V2 <- B%*%S%*%B*N/(N-16)
cat("max diff V:", max(abs(V-V2)), "\n")
w <- c(0, rep(1,15)); b <- coef(m)
cs <- sum(b[-1]); cse <- sqrt(drop(t(w)%*%V%*%w))
est <- list(list(term="cumulative_response",estimate=cs,se=cse,n_obs=N),
 list(term="lag_1",estimate=unname(b["lag_1"]),se=sqrt(V["lag_1","lag_1"]),n_obs=N),
 list(term="lag_15",estimate=unname(b["lag_15"]),se=sqrt(V["lag_15","lag_15"]),n_obs=N))
print(est)
write_json(list(task_id="applied_cumulative_hac",platform="r",estimates=est,
 method_metadata=list(estimator="OLS distributed lag",vcov="Newey-West Bartlett lag 15, scaled N/(N-16)"),
 diagnostics=list(max_vcov_diff_manual=max(abs(V-V2)))), "result.json", auto_unbox=TRUE, digits=12)
