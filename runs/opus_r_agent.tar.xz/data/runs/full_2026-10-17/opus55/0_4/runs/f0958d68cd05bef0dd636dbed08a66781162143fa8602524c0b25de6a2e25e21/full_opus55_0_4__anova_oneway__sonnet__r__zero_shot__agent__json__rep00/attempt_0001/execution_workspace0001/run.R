d <- read.csv("input.csv")
d <- d[complete.cases(d[, c("group", "y")]), ]
d$group <- factor(d$group)  # group is numeric code; treat as categorical
fit <- aov(y ~ group, data = d)
tab <- summary(fit)[[1]]
F <- tab[["F value"]][1]; df1 <- tab[["Df"]][1]; df2 <- tab[["Df"]][2]
p <- tab[["Pr(>F)"]][1]; n <- nrow(d)
mk <- function(t, e) list(term = t, estimate = unname(e), se = NULL, n_obs = n)
res <- list(task_id = "anova_oneway", platform = "r",
  estimates = list(mk("F", F), mk("df_num", df1), mk("df_den", df2), mk("p_value", p)),
  method_metadata = list(estimator = "one-way ANOVA (aov, group as factor, equal variances)", vcov = "classical OLS"),
  diagnostics = list(n_groups = nlevels(d$group)))
jsonlite::write_json(res, "result.json", auto_unbox = TRUE, digits = NA, null = "null", pretty = TRUE)
