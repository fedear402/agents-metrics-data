library(sandwich); library(jsonlite)
d <- read.csv("input.csv"); d <- d[order(as.Date(d$date)),]
y <- log(d$sales); dv <- c(NA, diff(log(d$vix))); T <- length(y)
X <- sapply(1:15, function(k) c(rep(NA,k), dv[1:(T-k)]))
colnames(X) <- paste0("lag_",1:15)
df <- na.omit(data.frame(y=y, X)); N <- nrow(df)
m <- lm(y ~ ., data=df)
V <- NeweyWest(m, lag=15, prewhite=FALSE, adjust=FALSE) * N/(N-16)
# manual check
Xm <- model.matrix(m); u <- resid(m); S <- crossprod(Xm*u)
for (j in 1:15) { G <- crossprod(Xm[(j+1):N,]*u[(j+1):N], Xm[1:(N-j),]*u[1:(N-j)]); S <- S + (1-j/16)*(G+t(G)) }
B <- solve(crossprod(Xm)); V2 <- B %*% S %*% B * N/(N-16)
w <- c(0, rep(1,15)); b <- coef(m)
cs <- sum(b[-1]); cse <- sqrt(drop(t(w)%*%V%*%w))
cat("N",N,"maxdiff",max(abs(V-V2)),"cs",cs,cse,"\n")
se <- sqrt(diag(V))
r <- list(task_id="applied_cumulative_hac", platform="r",
 estimates=list(list(term="cumulative_response",estimate=cs,se=cse,n_obs=N),
  list(term="lag_1",estimate=b[["lag_1"]],se=se[["lag_1"]],n_obs=N),
  list(term="lag_15",estimate=b[["lag_15"]],se=se[["lag_15"]],n_obs=N)),
 method_metadata=list(estimator="OLS distributed lag", vcov="Newey-West Bartlett lag 15, x N/(N-16)"),
 diagnostics=list(manual_vcov_maxdiff=max(abs(V-V2))))
write_json(r,"result.json",auto_unbox=TRUE,digits=10)
