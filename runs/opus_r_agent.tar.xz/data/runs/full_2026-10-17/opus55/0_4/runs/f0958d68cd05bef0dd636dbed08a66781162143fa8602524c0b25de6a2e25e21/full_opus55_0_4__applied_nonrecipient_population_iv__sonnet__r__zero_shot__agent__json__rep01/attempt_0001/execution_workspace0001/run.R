d <- read.csv("households.csv"); cen <- read.csv("census.csv")
d <- d[d$recipient == 0, ]
e <- d$eligible; ne <- 1 - e; w <- d$weight
X <- cbind(d0=d$dose*ne, d1=d$dose*e, ne, e, b0=d$baseline*ne, b1=d$baseline*e)
Z <- cbind(z0=d$instrument*ne, z1=d$instrument*e, ne, e, b0=d$baseline*ne, b1=d$baseline*e)
y <- d$outcome
ZW <- Z*w
Xh <- Z %*% solve(crossprod(Z, ZW), crossprod(ZW, X))
b <- solve(crossprod(Xh, X*w), crossprod(Xh*w, y))[,1]
m0 <- weighted.mean(d$dose[e==0], w[e==0]); m1 <- weighted.mean(d$dose[e==1], w[e==1])
ie <- b[1]*m0; ee <- b[2]*m1
p0 <- cen$nonrecipient_population[cen$eligible==0]; p1 <- cen$nonrecipient_population[cen$eligible==1]
pe <- (p0*ie + p1*ee)/(p0+p1)
n <- nrow(d)
# check: just-identified style via standard form solve(Z'WX) not applicable (overid); compare to ivreg-free manual 2-stage lm
fs <- lm.fit(Z*sqrt(w), X*sqrt(w)); Xh2 <- Z %*% fs$coefficients
b2 <- lm.wfit(Xh2, y, w)$coefficients
cat("diff", max(abs(b-b2)), "\n"); print(b); cat(n, sum(e==0), sum(e==1), m0, m1, ie, ee, pe, "\n")
est <- data.frame(term=c("ineligible_effect","eligible_nonrecipient_effect","population_effect"),
  estimate=unname(c(ie,ee,pe)), se=NA, n_obs=as.integer(n))
jsonlite::write_json(list(task_id="applied_nonrecipient_population_iv", platform="r", estimates=est,
  method_metadata=list(estimator="weighted 2SLS, group-interacted, no extra intercept", weights="weight",
    sample="recipient==0", counterfactual="dose=0 (synthetic convention)"),
  diagnostics=list(slope_ineligible=unname(b[1]), slope_eligible=unname(b[2]), mean_dose_ineligible=m0,
    mean_dose_eligible=m1, n_ineligible=sum(e==0), n_eligible=sum(e==1), check_max_coef_diff=max(abs(b-b2)))),
  "result.json", auto_unbox=TRUE, digits=NA, na="null", pretty=TRUE)
