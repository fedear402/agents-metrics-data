library(jsonlite)
d <- read.csv("input.csv")
d <- d[abs(d$score) < 1, ]
n <- nrow(d)
w <- 1 - abs(d$score)
a <- as.numeric(d$score >= 0)
X <- cbind(1, a, d$score, a*d$score)
Y <- cbind(d$earnings, d$participated)
bread <- solve(crossprod(X, w*X))
B <- bread %*% crossprod(X, w*Y)
R <- Y - X %*% B
cc <- c(0,1,0,0)
j <- drop(cc %*% B)
inf <- (w * drop(X %*% bread %*% cc)) * R
V <- crossprod(inf)
g <- c(1/j[2], -j[1]/j[2]^2)
te <- j[1]/j[2]; tse <- sqrt(drop(t(g)%*%V%*%g))
# independent check: per-side lm and sandwich
library(sandwich)
f1 <- lm(earnings ~ a*score, data=cbind(d,a=a), weights=w)
stopifnot(abs(coef(f1)["a"]-j[1])<1e-8, abs(sqrt(vcovHC(f1,type="HC0")["a","a"])-sqrt(V[1,1]))<1e-8)
row <- function(t,e,s) list(term=t,estimate=e,se=s,n_obs=n)
write_json(list(task_id="applied_fuzzy_rd", platform="r",
  estimates=list(row("treatment_effect",te,tse),row("reduced_form",j[1],sqrt(V[1,1])),row("first_stage",j[2],sqrt(V[2,2]))),
  method_metadata=list(estimator="local linear fuzzy RD, triangular kernel, h=1, Wald ratio",vcov="HC0 joint, delta method"),
  diagnostics=list(cov_rf_fs=V[1,2])), "result.json", auto_unbox=TRUE, digits=16, pretty=TRUE)
