library(jsonlite)
d <- read.csv("input.csv")
regs <- sort(unique(d$region_id)); inds <- sort(unique(d$industry_id))
S <- matrix(0,length(regs),length(inds))
S[cbind(match(d$region_id,regs),match(d$industry_id,inds))] <- d$share
rd <- d[!duplicated(d$region_id),]; rd <- rd[match(regs,rd$region_id),]
id <- d[!duplicated(d$industry_id),]; shock <- id$shock[match(inds,id$industry_id)]
stopifnot(all(tapply(d$shock,d$industry_id,function(v) diff(range(v)))<1e-12))
e <- rd$region_weight/sum(rd$region_weight)
z <- drop(S%*%shock)
R <- cbind(y=rd$y,x=rd$x,z=z)
C <- sweep(R,2,drop(e%*%R))
s <- drop(e%*%S); A <- (t(S)%*%(e*C))/s
N <- length(inds)
siv <- function(dep,endo){
  X <- cbind(1,endo); Z <- cbind(1,shock)
  cr <- crossprod(Z,s*X); b <- solve(cr,crossprod(Z,s*dep))
  u <- drop(dep-X%*%b); sc <- Z*(s*u); inv <- solve(cr)
  V <- N/(N-2)*inv%*%crossprod(sc)%*%t(inv); c(b[2],sqrt(V[2,2]))}
ef <- siv(A[,1],A[,2]); fs <- siv(A[,2],A[,3])
reg_ef <- sum(e*C[,3]*C[,1])/sum(e*C[,3]*C[,2])
reg_fs <- sum(e*C[,3]*C[,2])/sum(e*C[,3]^2)
library(AER); iv <- ivreg(y~x|z,data=data.frame(rd,z=z),weights=e)
cat("check", ef[1]-reg_ef, fs[1]-reg_fs, coef(iv)[2]-ef[1], max(abs(s%*%A)), range(rowSums(S)),"\n")
r <- function(t,est,se) list(term=t,estimate=est,se=se,n_obs=N)
write_json(list(task_id="applied_shift_share",platform="r",
 estimates=list(r("effect",ef[1],ef[2]),r("first_stage",fs[1],fs[2]),r("effective_shocks",1/sum(s^2),NULL)),
 method_metadata=list(estimator="weighted 2SLS; BHJ shock-level IV",vcov="shock-level HC1 N/(N-2), structural residuals"),
 diagnostics=list(n_regions=length(regs))),"result.json",auto_unbox=TRUE,null="null",digits=16,pretty=TRUE)
