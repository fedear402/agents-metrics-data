library(jsonlite)
cw <- read.csv("crosswalk.csv", colClasses=c(code="character"))
inp <- read.csv("input.csv", colClasses=c(code="character"))
stopifnot(identical(cw, inp))
tr <- merge(read.csv("trade.csv", colClasses=c(code="character")), cw, by="code")
ar <- read.csv("areas.csv"); em <- read.csv("employment.csv"); out <- read.csv("outcomes.csv")
# complete grid, missing = 0
g <- expand.grid(area=unique(ar$area), period=unique(ar$period), vintage=c("base","early"), industry=0:3, stringsAsFactors=FALSE)
g <- merge(g, em, all.x=TRUE); g$employment[is.na(g$employment)] <- 0
nat <- aggregate(employment~period+vintage+industry, g, sum); names(nat)[4] <- "nat"
g <- merge(merge(g, nat), ar[,c("area","period","vintage","total_employment")])
g <- merge(g, tr[,c("period","industry","us_change","other_change","price_index","years")])
g$chg <- ifelse(g$vintage=="base", g$us_change, g$other_change)
g$term <- g$employment/g$total_employment*g$chg/g$nat/(g$price_index/100)/1000*(10/g$years)
ex <- aggregate(term~area+period+vintage, g, sum)
x <- setNames(ex[ex$vintage=="base",c("area","period","term")], c("area","period","x"))
z <- setNames(ex[ex$vintage=="early",c("area","period","term")], c("area","period","z"))
pop <- ar[ar$vintage=="base", c("area","period","population")]
d <- merge(merge(merge(out, x), z), pop); stopifnot(nrow(d)==72)
X <- cbind(1, d$period, d$control, d$x); Z <- cbind(1, d$period, d$control, d$z); w <- d$population
W <- diag(w)
Xh <- Z %*% solve(t(Z)%*%W%*%Z, t(Z)%*%W%*%X)
b <- solve(t(Xh)%*%W%*%X, t(Xh)%*%W%*%d$change_pp)
# check: just-identified IV formula
b2 <- solve(t(Z)%*%W%*%X, t(Z)%*%W%*%d$change_pp)
cat("2SLS:", b, "\nIV check:", b2, "\n")
g0 <- function(df,p,v) df[df$area==0 & df$period==p, v]
est <- list(iv_slope=b[4], exposure_area0_period0=g0(d,0,"x"), exposure_area0_period1=g0(d,1,"x"), instrument_area0_period0=g0(d,0,"z"))
print(est, digits=12)
write_json(list(task_id="applied_multivintage_trade_iv", platform="r",
  estimates=lapply(names(est), function(n) list(term=n, estimate=unname(est[[n]]), se=NULL, n_obs=nrow(d))),
  method_metadata=list(estimator="weighted 2SLS", weights="base population", instruments="intercept, period, control, z"),
  diagnostics=list(n_obs=nrow(d), max_abs_diff_iv_check=max(abs(b-b2)))),
  "result.json", auto_unbox=TRUE, digits=NA, null="null", pretty=TRUE)
