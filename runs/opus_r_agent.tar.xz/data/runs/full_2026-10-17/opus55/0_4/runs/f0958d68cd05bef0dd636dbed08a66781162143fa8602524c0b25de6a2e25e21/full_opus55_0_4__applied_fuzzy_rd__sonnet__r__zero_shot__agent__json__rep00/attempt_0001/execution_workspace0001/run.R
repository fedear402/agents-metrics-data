library(jsonlite); library(sandwich)
d <- read.csv("input.csv")
d <- d[!is.na(d$score) & !is.na(d$participated) & !is.na(d$earnings) & abs(d$score) < 1, ]
w <- 1 - abs(d$score); R <- as.numeric(d$score >= 0)
X <- cbind(1, R, d$score, R * d$score)
A <- solve(crossprod(X, X * w))
inf <- function(y) { b <- A %*% crossprod(X, w * y); e <- as.vector(y - X %*% b)
  list(b = b, psi = (X * (w * e)) %*% A) }
ry <- inf(d$earnings); rd <- inf(d$participated)
P <- cbind(ry$psi[, 2], rd$psi[, 2]); V <- crossprod(P)
rf <- ry$b[2]; fs <- rd$b[2]; te <- rf / fs
g <- c(1 / fs, -rf / fs^2); se_te <- sqrt(drop(t(g) %*% V %*% g))
# check against sandwich
m1 <- lm(earnings ~ R * score, data = cbind(d, R = R), weights = w)
chk <- sqrt(vcovHC(m1, type = "HC0")["R", "R"])
cat("rf", rf, "se", sqrt(V[1,1]), "sandwich", chk, "\nfs", fs, sqrt(V[2,2]), "te", te, se_te, "n", nrow(d), "\n")
n <- nrow(d)
out <- list(task_id = "applied_fuzzy_rd", platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = te, se = se_te, n_obs = n),
    list(term = "reduced_form", estimate = rf, se = sqrt(V[1,1]), n_obs = n),
    list(term = "first_stage", estimate = fs, se = sqrt(V[2,2]), n_obs = n)),
  method_metadata = list(estimator = "fuzzy RD, local linear, triangular kernel h=1, ratio of WLS discontinuities",
                         vcov = "HC0 joint sandwich, delta method"),
  diagnostics = list(cov_rf_fs = V[1,2], sandwich_check_se_rf = chk))
write_json(out, "result.json", auto_unbox = TRUE, digits = 12, pretty = TRUE)
