library(jsonlite)
d <- read.csv("input.csv"); d <- d[order(d$t),]
y <- d$y
fit <- arima(y, order=c(1,1,1), method="ML")
p <- predict(fit, n.ahead=1)
f <- as.numeric(p$pred); s <- as.numeric(p$se); z <- qnorm(0.975)
n <- length(y)
out <- list(task_id="arima_forecast", platform="r",
 estimates=list(
  list(term="forecast", estimate=f, se=s, n_obs=n),
  list(term="lower_95", estimate=f-z*s, se=NA, n_obs=n),
  list(term="upper_95", estimate=f+z*s, se=NA, n_obs=n)),
 method_metadata=list(estimator="ARIMA(1,1,1) exact ML, no constant (stats::arima)", vcov="Hessian; forecast se from Kalman filter"),
 diagnostics=list(ar1=unname(coef(fit)[1]), ma1=unname(coef(fit)[2]), sigma2=fit$sigma2, loglik=fit$loglik))
write_json(out, "result.json", auto_unbox=TRUE, digits=NA)
