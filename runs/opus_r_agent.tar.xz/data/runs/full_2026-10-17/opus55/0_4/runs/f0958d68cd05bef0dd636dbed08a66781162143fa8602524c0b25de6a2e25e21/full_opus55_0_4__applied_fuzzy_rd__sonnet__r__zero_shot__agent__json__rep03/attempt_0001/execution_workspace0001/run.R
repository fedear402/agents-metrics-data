library(sandwich); library(jsonlite)
d <- read.csv("input.csv")
d <- d[!is.na(d$score) & abs(d$score) < 1, ]
d <- d[complete.cases(d[, c("score","participated","earnings")]), ]
d$D <- as.numeric(d$score >= 0); d$w <- 1 - abs(d$score)
X <- cbind(1, d$D, d$score, d$D * d$score); n <- nrow(d)
A <- solve(crossprod(X, X * d$w))
fit <- function(y) { b <- A %*% crossprod(X, d$w * y); e <- y - X %*% b
  list(b = b, psi = (X * as.vector(d$w * e)) %*% A) }
ry <- fit(d$earnings); rt <- fit(d$participated)
P <- cbind(ry$psi[, 2], rt$psi[, 2]); V <- crossprod(P)
rf <- ry$b[2]; fs <- rt$b[2]; te <- rf / fs
g <- c(1 / fs, -rf / fs^2); se_te <- sqrt(drop(t(g) %*% V %*% g))
# check vs sandwich
m <- lm(earnings ~ D * score, data = d, weights = w)
chk <- sqrt(vcovHC(m, type = "HC0")["D", "D"])
cat("n", n, "rf", rf, sqrt(V[1,1]), "chk", chk, "fs", fs, sqrt(V[2,2]), "te", te, se_te, "cov", V[1,2], "\n")
# 2SLS check
iv <- AER::ivreg(earnings ~ participated + score + D:score | D + score + D:score, data = d, weights = w)
cat("ivreg te", coef(iv)["participated"], sqrt(vcovHC(iv, type="HC0")["participated","participated"]), "\n")
res <- list(task_id = "applied_fuzzy_rd", platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = te, se = se_te, n_obs = n),
    list(term = "reduced_form", estimate = rf, se = sqrt(V[1,1]), n_obs = n),
    list(term = "first_stage", estimate = fs, se = sqrt(V[2,2]), n_obs = n)),
  method_metadata = list(estimator = "fuzzy RD, local linear, triangular kernel, h=1, ratio of WLS discontinuities",
                         vcov = "HC0 joint (stacked influence), delta method"),
  diagnostics = list(cov_rf_fs = V[1,2]))
write_json(res, "result.json", auto_unbox = TRUE, digits = 12, pretty = TRUE)
