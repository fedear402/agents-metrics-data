d <- read.csv("input.csv")
d <- d[complete.cases(d[, c("group", "y")]), ]
d$group <- factor(d$group)  # group is numeric code; treat as categorical
fit <- aov(y ~ group, data = d)
tab <- summary(fit)[[1]]
Fv <- tab[1, "F value"]; df1 <- tab[1, "Df"]; df2 <- tab[2, "Df"]; p <- tab[1, "Pr(>F)"]
n <- nrow(d)
est <- function(t, v) list(term = t, estimate = v, se = NULL, n_obs = n)
res <- list(task_id = "anova_oneway", platform = "r",
  estimates = list(est("F", Fv), est("df_num", df1), est("df_den", df2), est("p_value", p)),
  method_metadata = list(estimator = "one-way ANOVA (aov, group as factor)", vcov = "classical OLS (homoskedastic)"),
  diagnostics = list(n_groups = nlevels(d$group)))
jsonlite::write_json(res, "result.json", auto_unbox = TRUE, digits = NA, null = "null", pretty = TRUE)
