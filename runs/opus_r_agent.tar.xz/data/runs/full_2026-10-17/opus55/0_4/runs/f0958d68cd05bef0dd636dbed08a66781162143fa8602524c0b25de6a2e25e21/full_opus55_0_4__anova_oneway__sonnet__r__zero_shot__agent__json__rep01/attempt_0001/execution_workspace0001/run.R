library(jsonlite)
d <- read.csv("input.csv")
d <- d[complete.cases(d), ]
d$group <- factor(d$group)
a <- anova(lm(y ~ group, data = d))
Fv <- a[1, "F value"]; df1 <- a[1, "Df"]; df2 <- a[2, "Df"]; p <- a[1, "Pr(>F)"]
n <- nrow(d)
# independent check: manual sums of squares
gm <- ave(d$y, d$group); ssb <- sum((gm - mean(d$y))^2); ssw <- sum((d$y - gm)^2)
k <- nlevels(d$group); Fm <- (ssb/(k-1))/(ssw/(n-k))
stopifnot(abs(Fm - Fv) < 1e-8, abs(oneway.test(y ~ group, d, var.equal=TRUE)$p.value - p) < 1e-12)
e <- function(t, v) list(term=t, estimate=v, se=NULL, n_obs=n)
out <- list(task_id="anova_oneway", platform="r",
  estimates=list(e("F",Fv), e("df_num",df1), e("df_den",df2), e("p_value",p)),
  method_metadata=list(estimator="one-way ANOVA (OLS, group as factor)", vcov="classical homoskedastic"),
  diagnostics=list(n_groups=k, F_manual=Fm))
write(toJSON(out, auto_unbox=TRUE, digits=NA, null="null"), "result.json")
