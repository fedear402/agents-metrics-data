d <- read.csv("input.csv")
d <- d[abs(d$score) < 1 & complete.cases(d[,c("score","participated","earnings")]),]
w <- 1 - abs(d$score); R <- as.numeric(d$score >= 0)
X <- cbind(1, R, d$score, R*d$score)
n <- nrow(d)
B <- solve(crossprod(X, X*w))
fit <- function(y){ b <- B %*% crossprod(X, w*y); list(b=b, e=as.vector(y - X%*%b)) }
fy <- fit(d$earnings); fd <- fit(d$participated)
# influence for coefficient 2 (jump)
iy <- (X*(w*fy$e)) %*% B[,2]; id <- (X*(w*fd$e)) %*% B[,2]
V <- crossprod(cbind(iy, id))
rf <- fy$b[2]; fs <- fd$b[2]; te <- rf/fs
g <- c(1/fs, -rf/fs^2); sete <- sqrt(drop(t(g)%*%V%*%g))
# check vs sandwich
library(sandwich)
m <- lm(earnings ~ R*score, data=cbind(d,R=R), weights=w)
chk <- sqrt(vcovHC(m, type="HC0")["R","R"])
cat("rf se", sqrt(V[1,1]), "sandwich", chk, "\n")
res <- list(task_id="applied_fuzzy_rd", platform="r",
 estimates=list(
  list(term="treatment_effect", estimate=te, se=sete, n_obs=n),
  list(term="reduced_form", estimate=rf, se=sqrt(V[1,1]), n_obs=n),
  list(term="first_stage", estimate=fs, se=sqrt(V[2,2]), n_obs=n)),
 method_metadata=list(estimator="fuzzy RD local linear, triangular kernel, h=1, ratio of WLS jumps", vcov="HC0 joint influence-function covariance, delta method"),
 diagnostics=list(cov_rf_fs=V[1,2], sandwich_rf_se=chk))
jsonlite::write_json(res, "result.json", auto_unbox=TRUE, digits=12, pretty=TRUE)
# independent check: IV with weights gives same point estimate
iv <- AER::ivreg(earnings ~ participated + score + R:score | R + score + R:score, data=cbind(d,R=R), weights=w)
cat("ivreg TE", coef(iv)[2], "mine", te, "ivreg HC0 se", sqrt(vcovHC(iv,type="HC0")[2,2]), "mine", sete, "\n")
