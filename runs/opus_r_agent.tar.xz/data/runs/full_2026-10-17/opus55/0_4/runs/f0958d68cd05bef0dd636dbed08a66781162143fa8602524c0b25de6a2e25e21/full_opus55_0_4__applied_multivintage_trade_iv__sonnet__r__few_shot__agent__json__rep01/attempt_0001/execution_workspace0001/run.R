cw <- read.csv("crosswalk.csv"); inp <- read.csv("input.csv"); stopifnot(identical(cw, inp))
tr <- merge(read.csv("trade.csv"), cw, by="code")
ar <- read.csv("areas.csv"); em <- read.csv("employment.csv"); oc <- read.csv("outcomes.csv")
# complete grid, missing = 0
g <- expand.grid(area=unique(ar$area), period=unique(ar$period), vintage=c("base","early"), industry=0:3, stringsAsFactors=FALSE)
g <- merge(g, em, all.x=TRUE); g$employment[is.na(g$employment)] <- 0
nat <- aggregate(employment~period+vintage+industry, g, sum); names(nat)[4] <- "nat"
g <- merge(merge(g, nat), tr[c("period","industry","us_change","other_change","price_index","years")])
g <- merge(g, ar[c("area","period","vintage","total_employment")])
g$chg <- ifelse(g$vintage=="base", g$us_change, g$other_change)
g$term <- g$employment/g$total_employment*g$chg/g$nat/(g$price_index/100)/1000*(10/g$years)
s <- aggregate(term~area+period+vintage, g, sum)
d <- merge(oc, setNames(s[s$vintage=="base",c(1,2,4)],c("area","period","x")))
d <- merge(d, setNames(s[s$vintage=="early",c(1,2,4)],c("area","period","z")))
d <- merge(d, setNames(ar[ar$vintage=="base",c("area","period","population")],c("area","period","w")))
stopifnot(nrow(d)==72)
X <- cbind(1,d$period,d$control,d$x); Z <- cbind(1,d$period,d$control,d$z); W <- d$w
b <- solve(t(Z*W)%*%X, t(Z*W)%*%d$change_pp)  # just-identified IV
sw <- sqrt(W); Xh <- qr.fitted(qr(Z*sw), X*sw); b2 <- qr.coef(qr(Xh), d$change_pp*sw)
cat("check diff:", max(abs(b-b2)), "\n")
f <- function(a,p,v) d[d$area==a&d$period==p,v]
est <- list(iv_slope=b[4], exposure_area0_period0=f(0,0,"x"), exposure_area0_period1=f(0,1,"x"), instrument_area0_period0=f(0,0,"z"))
print(unlist(est))
jsonlite::write_json(list(task_id="applied_multivintage_trade_iv", platform="r",
  estimates=lapply(names(est), function(n) list(term=n, estimate=unname(est[[n]]), se=NA, n_obs=72L)),
  method_metadata=list(estimator="weighted 2SLS", weight="base population", instruments="intercept, period, control, z"),
  diagnostics=list(check_max_abs_diff=max(abs(b-b2)))), "result.json", auto_unbox=TRUE, digits=15, na="null")
