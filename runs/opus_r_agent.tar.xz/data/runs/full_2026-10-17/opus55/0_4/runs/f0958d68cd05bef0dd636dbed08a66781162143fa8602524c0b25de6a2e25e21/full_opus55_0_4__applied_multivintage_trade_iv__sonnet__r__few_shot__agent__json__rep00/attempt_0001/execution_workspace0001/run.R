library(jsonlite)
cw <- read.csv("crosswalk.csv",colClasses=c(code="character")); inp <- read.csv("input.csv")  # input.csv identical to crosswalk
tr <- merge(read.csv("trade.csv"), cw, by="code")
ar <- read.csv("areas.csv"); em <- read.csv("employment.csv"); oc <- read.csv("outcomes.csv")
# complete grid: missing cells = 0
g <- expand.grid(area=unique(ar$area), period=unique(ar$period), vintage=c("base","early"), industry=0:3, stringsAsFactors=FALSE)
em <- merge(g, em, all.x=TRUE); em$employment[is.na(em$employment)] <- 0
nat <- aggregate(employment~period+vintage+industry, em, sum); names(nat)[4] <- "nat"
em <- merge(merge(em, nat), ar[c("area","period","vintage","total_employment")])
em <- merge(em, tr[c("period","industry","us_change","other_change","price_index","years")])
em$chg <- ifelse(em$vintage=="base", em$us_change, em$other_change)
em$c <- em$employment/em$total_employment*em$chg/em$nat/(em$price_index/100)/1000*(10/em$years)
ex <- aggregate(c~area+period+vintage, em, sum)
d <- merge(oc, setNames(ex[ex$vintage=="base",c(1,2,4)],c("area","period","x")))
d <- merge(d, setNames(ex[ex$vintage=="early",c(1,2,4)],c("area","period","z")))
d <- merge(d, setNames(ar[ar$vintage=="base",c("area","period","population")],c("area","period","w")))
stopifnot(nrow(d)==72)
sw <- sqrt(d$w); X <- cbind(1,d$period,d$control,d$x)*sw; Z <- cbind(1,d$period,d$control,d$z)*sw
b <- qr.coef(qr(qr.fitted(qr(Z),X)), d$change_pp*sw); iv <- b[4]
g0 <- function(v,p) d[[v]][d$area==0 & d$period==p]
est <- c(iv_slope=iv, exposure_area0_period0=g0("x",0), exposure_area0_period1=g0("x",1), instrument_area0_period0=g0("z",0))
print(est, digits=12)
write_json(list(task_id="applied_multivintage_trade_iv", platform="r",
  estimates=lapply(names(est), function(n) list(term=n, estimate=unname(est[n]), se=NA, n_obs=72L)),
  method_metadata=list(estimator="weighted 2SLS", weight="base population", instruments=c("intercept","period","control","z")),
  diagnostics=list(n_obs=72L, first_stage_cor_xz=cor(d$x,d$z))),
  "result.json", auto_unbox=TRUE, digits=NA, na="null")
# check: just-identified IV = solve(Z'WX, Z'Wy)
chk <- solve(crossprod(Z,X), crossprod(Z,d$change_pp*sw))[4]
cat("check", chk - iv, "\n")
