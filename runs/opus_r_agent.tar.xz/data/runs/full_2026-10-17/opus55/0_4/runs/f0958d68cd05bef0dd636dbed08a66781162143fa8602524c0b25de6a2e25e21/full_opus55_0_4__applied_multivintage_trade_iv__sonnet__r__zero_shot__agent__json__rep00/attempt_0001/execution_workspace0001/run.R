library(jsonlite)
cw <- read.csv("crosswalk.csv", colClasses=c(code="character"))
tr <- read.csv("trade.csv", colClasses=c(code="character"))
ar <- read.csv("areas.csv"); em <- read.csv("employment.csv"); oc <- read.csv("outcomes.csv")
tr <- merge(tr, cw, by="code"); stopifnot(nrow(tr)==8)
grid <- expand.grid(area=unique(ar$area), period=0:1, vintage=c("base","early"), industry=0:3, stringsAsFactors=FALSE)
e <- merge(grid, em, all.x=TRUE); e$employment[is.na(e$employment)] <- 0
nat <- aggregate(employment~period+vintage+industry, e, sum); names(nat)[4] <- "nat"
e <- merge(merge(e, nat), ar[,c("area","period","vintage","total_employment")])
e <- merge(e, tr[,c("period","industry","us_change","other_change","price_index","years")])
e$chg <- ifelse(e$vintage=="base", e$us_change, e$other_change)
e$term <- e$employment/e$total_employment*e$chg/e$nat/(e$price_index/100)/1000*(10/e$years)
ex <- aggregate(term~area+period+vintage, e, sum)
d <- merge(oc, setNames(ex[ex$vintage=="base",c(1,2,4)], c("area","period","x")))
d <- merge(d, setNames(ex[ex$vintage=="early",c(1,2,4)], c("area","period","z")))
d <- merge(d, ar[ar$vintage=="base", c("area","period","population")])
stopifnot(nrow(d)==72, !anyNA(d))
X <- cbind(1, d$period, d$control, d$x); Z <- cbind(1, d$period, d$control, d$z); w <- d$population; y <- d$change_pp
Xh <- Z %*% solve(crossprod(Z, w*Z), crossprod(Z, w*X))
b <- solve(crossprod(Xh, w*X), crossprod(Xh, w*y))
# check: just-identified closed form
b2 <- solve(crossprod(Z, w*X), crossprod(Z, w*y)); stopifnot(max(abs(b-b2))<1e-8)
g <- function(a,p,v) d[d$area==a & d$period==p, v]
est <- list(iv_slope=b[4], exposure_area0_period0=g(0,0,"x"), exposure_area0_period1=g(0,1,"x"), instrument_area0_period0=g(0,0,"z"))
print(est)
write_json(list(task_id="applied_multivintage_trade_iv", platform="r",
  estimates=lapply(names(est), function(n) list(term=n, estimate=unname(est[[n]]), se=NA, n_obs=72L)),
  method_metadata=list(estimator="weighted 2SLS", weight="base population", instruments="intercept, period, control, z"),
  diagnostics=list(n_obs=72L, first_stage_z_coef=unname(solve(crossprod(Z,w*Z),crossprod(Z,w*d$x))[4]), closed_form_diff=max(abs(b-b2)))),
  "result.json", auto_unbox=TRUE, digits=NA, na="null")
