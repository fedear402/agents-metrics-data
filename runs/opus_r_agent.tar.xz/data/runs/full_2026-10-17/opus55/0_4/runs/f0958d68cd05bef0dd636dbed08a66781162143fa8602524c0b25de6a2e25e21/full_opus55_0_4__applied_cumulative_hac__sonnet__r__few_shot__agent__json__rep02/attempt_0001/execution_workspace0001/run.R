library(jsonlite); library(sandwich)
d <- read.csv("input.csv"); d$date <- as.Date(d$date); d <- d[order(d$date),]
dv <- c(NA, diff(log(d$vix))); n <- nrow(d)
L <- sapply(1:15, function(k) c(rep(NA,k), head(dv,-k))); colnames(L) <- paste0("lag_",1:15)
s <- data.frame(y=log(d$sales), L); s <- s[complete.cases(s),]
fit <- lm(y ~ ., data=s); X <- model.matrix(fit); N <- nrow(X); p <- ncol(X)
sc <- X*residuals(fit); meat <- crossprod(sc)
for (j in 1:15) { G <- crossprod(sc[(j+1):N,,drop=FALSE], sc[1:(N-j),,drop=FALSE]); meat <- meat + (1-j/16)*(G+t(G)) }
B <- solve(crossprod(X)); V <- N/(N-p)*B%*%meat%*%B
V2 <- NeweyWest(fit, lag=15, prewhite=FALSE, adjust=TRUE)
cat("max diff vs sandwich:", max(abs(V-V2)), "\n")
cc <- c(0, rep(1,15)); b <- coef(fit)
cum <- sum(cc*b); cse <- sqrt(drop(t(cc)%*%V%*%cc))
cat("N", N, "cum", cum, cse, "sum check", sum(b[-1]), "\n")
r <- function(t,e,se) list(term=t, estimate=unname(e), se=unname(se), n_obs=N)
write_json(list(task_id="applied_cumulative_hac", platform="r",
  estimates=list(r("cumulative_response",cum,cse), r("lag_1",b[2],sqrt(V[2,2])), r("lag_15",b[16],sqrt(V[16,16]))),
  method_metadata=list(estimator="OLS distributed lag", vcov="Newey-West Bartlett lag 15, N/(N-16)"),
  diagnostics=setNames(list(),character(0))), "result.json", auto_unbox=TRUE, digits=16, pretty=TRUE)
