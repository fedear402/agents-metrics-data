h <- read.csv("households.csv"); census <- read.csv("census.csv")
d <- subset(h, recipient==0); e <- d$eligible; ne <- 1-e; w <- d$weight
C <- cbind(ne, e, d$baseline*ne, d$baseline*e)
X <- cbind(C, d$dose*ne, d$dose*e); Z <- cbind(C, d$instrument*ne, d$instrument*e)
sw <- sqrt(w); Xw <- X*sw; Zw <- Z*sw
fit <- qr.fitted(qr(Zw), Xw)
b <- qr.coef(qr(fit), d$outcome*sw)
md <- sapply(0:1, function(g) weighted.mean(d$dose[e==g], w[e==g]))
eff <- b[5:6]*md
pop <- census$nonrecipient_population[match(0:1, census$eligible)]
pe <- sum(eff*pop)/sum(pop)
n <- nrow(d)
est <- data.frame(term=c("ineligible_effect","eligible_nonrecipient_effect","population_effect"),
  estimate=c(eff,pe), se=NA, n_obs=as.integer(n))
jsonlite::write_json(list(task_id="applied_nonrecipient_population_iv", platform="r", estimates=est,
  method_metadata=list(estimator="weighted 2SLS, fully interacted by eligibility", weights="weight"),
  diagnostics=list(n_ineligible=sum(e==0), n_eligible=sum(e==1), dose_slopes=unname(b[5:6]), mean_dose=md, census_pop=pop)),
  "result.json", auto_unbox=TRUE, digits=NA, na="null", pretty=TRUE)
# check: separate per-group 2SLS
iv <- function(y,C,x,z,w){X<-cbind(C,x)*sqrt(w);Z<-cbind(C,z)*sqrt(w);f<-qr.fitted(qr(Z),X);qr.coef(qr(f),y*sqrt(w))[ncol(X)]}
chk <- sapply(0:1,function(g){a<-d[e==g,];iv(a$outcome,cbind(1,a$baseline),a$dose,a$instrument,a$weight)})
cat("joint slopes", b[5:6], "separate", chk, "maxdiff", max(abs(b[5:6]-chk)), "\n")
