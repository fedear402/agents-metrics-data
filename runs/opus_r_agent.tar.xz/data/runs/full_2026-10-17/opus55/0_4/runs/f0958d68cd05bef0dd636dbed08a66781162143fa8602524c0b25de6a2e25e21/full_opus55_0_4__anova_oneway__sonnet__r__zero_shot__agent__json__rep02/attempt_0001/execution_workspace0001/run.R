library(jsonlite)
d <- read.csv("input.csv")
d <- d[complete.cases(d), ]
d$group <- factor(d$group)
fit <- aov(y ~ group, data = d)
s <- summary(fit)[[1]]
Fv <- s[["F value"]][1]; df1 <- s[["Df"]][1]; df2 <- s[["Df"]][2]; p <- s[["Pr(>F)"]][1]
n <- nrow(d)
# independent check: manual sums of squares
gm <- tapply(d$y, d$group, mean); gn <- tapply(d$y, d$group, length)
ssb <- sum(gn * (gm - mean(d$y))^2); ssw <- sum((d$y - gm[d$group])^2)
k <- nlevels(d$group); Fm <- (ssb/(k-1)) / (ssw/(n-k))
stopifnot(abs(Fm - Fv) < 1e-8)
e <- function(t, v) list(term = t, estimate = v, se = NULL, n_obs = n)
res <- list(task_id = "anova_oneway", platform = "r",
  estimates = list(e("F", Fv), e("df_num", df1), e("df_den", df2), e("p_value", p)),
  method_metadata = list(estimator = "one-way ANOVA (aov, group as factor)", vcov = "classical homoskedastic"),
  diagnostics = list(manual_F = Fm, oneway_test_F = unname(oneway.test(y ~ group, d, var.equal = TRUE)$statistic), k = k))
write(toJSON(res, auto_unbox = TRUE, digits = NA, null = "null", pretty = TRUE), "result.json")
