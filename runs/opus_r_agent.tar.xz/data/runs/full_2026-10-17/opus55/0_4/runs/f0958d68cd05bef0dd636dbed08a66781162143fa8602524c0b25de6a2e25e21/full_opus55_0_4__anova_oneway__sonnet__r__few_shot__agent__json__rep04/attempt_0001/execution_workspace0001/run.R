library(jsonlite)
d <- read.csv("input.csv")
d <- d[complete.cases(d[, c("group", "y")]), ]
d$group <- factor(d$group)
tab <- anova(lm(y ~ group, data = d))
Fv <- tab[1, "F value"]; df1 <- tab[1, "Df"]; df2 <- tab[2, "Df"]; p <- tab[1, "Pr(>F)"]
n <- nrow(d)
row <- function(t, v) list(term = t, estimate = v, se = NA, n_obs = n)
out <- list(task_id = "anova_oneway", platform = "r",
  estimates = list(row("F", Fv), row("df_num", df1), row("df_den", df2), row("p_value", p)),
  method_metadata = list(estimator = "One-way ANOVA (OLS, group as factor)", vcov = "classical"),
  diagnostics = structure(list(), names = character(0)))
write_json(out, "result.json", auto_unbox = TRUE, digits = NA)
