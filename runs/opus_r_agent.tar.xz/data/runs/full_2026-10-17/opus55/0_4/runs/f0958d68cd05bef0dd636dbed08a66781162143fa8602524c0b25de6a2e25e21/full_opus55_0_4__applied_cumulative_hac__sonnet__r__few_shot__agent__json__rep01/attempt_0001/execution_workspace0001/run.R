library(jsonlite); library(sandwich)
d <- read.csv("input.csv"); d$date <- as.Date(d$date); d <- d[order(d$date),]
dv <- c(NA, diff(log(d$vix))); n <- nrow(d); L <- 15
X <- sapply(1:L, function(k) c(rep(NA,k), head(dv,-k))); colnames(X) <- paste0("lag_",1:L)
df <- data.frame(y=log(d$sales), X); df <- df[complete.cases(df),]
fit <- lm(y ~ ., data=df); N <- nobs(fit); Xm <- model.matrix(fit); p <- ncol(Xm)
S <- Xm*residuals(fit); meat <- crossprod(S)
for (j in 1:L) { G <- crossprod(S[(j+1):N,,drop=FALSE], S[1:(N-j),,drop=FALSE]); meat <- meat+(1-j/(L+1))*(G+t(G)) }
B <- solve(crossprod(Xm)); V <- N/(N-p)*B%*%meat%*%B
V2 <- NeweyWest(fit, lag=L, prewhite=FALSE, adjust=FALSE)*N/(N-p)
cat("max diff vs sandwich:", max(abs(V-V2)), "N=",N,"\n")
a <- c(0,rep(1,L)); b <- coef(fit)
r <- function(t,e,s) list(term=t,estimate=unname(e),se=unname(s),n_obs=N)
write_json(list(task_id="applied_cumulative_hac", platform="r", estimates=list(
 r("cumulative_response",sum(a*b),sqrt(drop(a%*%V%*%a))),
 r("lag_1",b[2],sqrt(V[2,2])), r("lag_15",b[16],sqrt(V[16,16]))),
 method_metadata=list(estimator="OLS distributed lag", vcov="Newey-West Bartlett lag 15, N/(N-16)"),
 diagnostics=setNames(list(),character(0))), "result.json", auto_unbox=TRUE, digits=16, pretty=TRUE)
