library(sandwich); library(jsonlite)
d <- read.csv("input.csv"); d <- d[order(as.Date(d$date)),]
y <- log(d$sales); dv <- c(NA, diff(log(d$vix))); n <- length(y)
X <- sapply(1:15, function(k) c(rep(NA,k), dv[1:(n-k)]))
colnames(X) <- paste0("L",1:15)
df <- na.omit(data.frame(y=y, X))
m <- lm(y ~ ., data=df); N <- nobs(m)
V <- NeweyWest(m, lag=15, prewhite=FALSE, adjust=FALSE) * N/(N-16)
# independent manual HAC
Xm <- model.matrix(m); u <- resid(m); S <- crossprod(Xm*u)
for (j in 1:15) { G <- crossprod(Xm[(j+1):N,]*u[(j+1):N], Xm[1:(N-j),]*u[1:(N-j)]); S <- S + (1-j/16)*(G+t(G)) }
B <- solve(crossprod(Xm)); V2 <- B %*% S %*% B * N/(N-16)
cat("maxdiff", max(abs(V-V2)), "N", N, "rows", n, "\n")
b <- coef(m); w <- c(0, rep(1,15))
est <- data.frame(term=c("cumulative_response","lag_1","lag_15"),
  estimate=c(sum(b[-1]), b[2], b[16]),
  se=c(sqrt(drop(t(w)%*%V%*%w)), sqrt(V[2,2]), sqrt(V[16,16])), n_obs=N)
print(est)
write_json(list(task_id="applied_cumulative_hac", platform="r", estimates=est,
  method_metadata=list(estimator="OLS distributed lag", vcov="Newey-West Bartlett lag 15, scaled N/(N-16)"),
  diagnostics=list(manual_hac_maxdiff=max(abs(V-V2)))), "result.json", auto_unbox=TRUE, digits=NA)
