library(jsonlite)
h <- read.csv("households.csv"); cen <- read.csv("census.csv")
d <- h[h$recipient==0,]; e <- d$eligible; ne <- 1-e
X <- cbind(d$dose*ne, d$dose*e, ne, e, d$baseline*ne, d$baseline*e)
Z <- cbind(ne, e, d$baseline*ne, d$baseline*e, d$instrument*ne, d$instrument*e)
w <- d$weight; y <- d$outcome
ZW <- Z*w; Pz <- Z %*% solve(crossprod(Z,ZW), crossprod(ZW,X))
b <- solve(crossprod(Pz*w, X), crossprod(Pz*w, y))
# check: explicit two-stage via lm
Xh <- fitted(lm(X ~ Z - 1, weights=w)); b2 <- coef(lm(y ~ Xh - 1, weights=w))
stopifnot(max(abs(b-b2))<1e-8)
md0 <- weighted.mean(d$dose[e==0], w[e==0]); md1 <- weighted.mean(d$dose[e==1], w[e==1])
ie <- b[1]*md0; ee <- b[2]*md1
p0 <- cen$nonrecipient_population[cen$eligible==0]; p1 <- cen$nonrecipient_population[cen$eligible==1]
pe <- (p0*ie+p1*ee)/(p0+p1); n <- nrow(d)
cat(sprintf("%.10f\n", c(b[1:2], md0, md1, ie, ee, pe)), n, sum(e==0), sum(e==1), "\n")
est <- lapply(list(c("ineligible_effect",ie),c("eligible_nonrecipient_effect",ee),c("population_effect",pe)),
  function(v) list(term=v[1], estimate=as.numeric(v[2]), se=NULL, n_obs=n))
write_json(list(task_id="applied_nonrecipient_population_iv", platform="r", estimates=est,
  method_metadata=list(estimator="weighted 2SLS, group-interacted, no extra intercept", weights="weight"),
  diagnostics=list(slope_ineligible=b[1], slope_eligible=b[2], mean_dose_ineligible=md0, mean_dose_eligible=md1,
    n_ineligible=sum(e==0), n_eligible=sum(e==1), max_diff_twostage=max(abs(b-b2)))),
  "result.json", auto_unbox=TRUE, digits=NA, null="null", pretty=TRUE)
