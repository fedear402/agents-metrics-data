library(jsonlite)
d <- read.csv("input.csv")
d <- d[complete.cases(d[, c("group", "y")]), ]
d$group <- factor(d$group)
tab <- anova(lm(y ~ group, data = d))
Fv <- tab$`F value`[1]; df1 <- tab$Df[1]; df2 <- tab$Df[2]; p <- tab$`Pr(>F)`[1]
n <- nrow(d)
row <- function(t, e) list(term = t, estimate = e, se = NA, n_obs = n)
out <- list(task_id = "anova_oneway", platform = "r",
  estimates = list(row("F", Fv), row("df_num", df1), row("df_den", df2), row("p_value", p)),
  method_metadata = list(estimator = "One-way ANOVA (OLS, group as factor)", vcov = "classical"),
  diagnostics = structure(list(), names = character(0)))
write_json(out, "result.json", auto_unbox = TRUE, digits = NA)
