suppressMessages({library(AER);library(sandwich);library(jsonlite)})
d <- read.csv("input.csv")
stopifnot(!anyNA(d))
R <- d[!duplicated(d$region_id), c("region_id","region_weight","x","y")]
R$e <- R$region_weight/sum(R$region_weight)
z <- tapply(d$share*d$shock, d$region_id, sum)
R$z <- as.numeric(z[as.character(R$region_id)])
reg <- ivreg(y ~ x | z, data=R, weights=e)
fs <- lm(x ~ z, data=R, weights=e)
wm <- function(v) v - sum(R$e*v)
R$y0 <- wm(R$y); R$x0 <- wm(R$x); R$z0 <- wm(R$z)
m <- match(d$region_id, R$region_id)
d$w <- R$e[m]*d$share
S <- aggregate(cbind(s=w, yb=w*R$y0[m], xb=w*R$x0[m], zb=w*R$z0[m]) ~ industry_id, d, sum)
S$yb <- S$yb/S$s; S$xb <- S$xb/S$s; S$zb <- S$zb/S$s
S$shock <- d$shock[match(S$industry_id, d$industry_id)]
N <- nrow(S)
iv1 <- ivreg(yb ~ xb | shock, data=S, weights=s)
iv2 <- ivreg(xb ~ zb | shock, data=S, weights=s)
se1 <- sqrt(vcovHC(iv1, type="HC1")[2,2]); se2 <- sqrt(vcovHC(iv2, type="HC1")[2,2])
# manual HC1 check
man <- function(yv, xv, zv, w){X<-cbind(1,xv);Z<-cbind(1,zv)
  b<-solve(t(Z)%*%(w*X), t(Z)%*%(w*yv)); u<-yv-X%*%b
  A<-solve(t(Z)%*%(w*X)); M<-t(Z)%*%(Z*as.vector(w*u)^2)
  c(b[2], sqrt((A%*%M%*%t(A))[2,2]*N/(N-2)))}
c1 <- man(S$yb,S$xb,S$shock,S$s); c2 <- man(S$xb,S$zb,S$shock,S$s)
eff <- 1/sum(S$s^2)
chk <- sprintf("Regions=%d industries=%d rows=%d\nshare sums range: %s\nsum s_n=%.12f\nregional 2SLS slope %.10f vs shock-level %.10f\nregional FS slope %.10f vs shock-level %.10f\nHC1 SE effect sandwich %.10f manual %.10f\nHC1 SE FS sandwich %.10f manual %.10f\neffective_shocks %.6f\n",
 nrow(R),N,nrow(d),paste(range(tapply(d$share,d$region_id,sum)),collapse=" "),sum(S$s),
 coef(reg)[2],coef(iv1)[2],coef(fs)[2],coef(iv2)[2],se1,c1[2],se2,c2[2],eff)
cat(chk); writeLines(chk,"verification.txt")
out <- list(task_id="applied_shift_share", platform="r",
 estimates=list(list(term="effect",estimate=unname(coef(reg)[2]),se=se1,n_obs=N),
  list(term="first_stage",estimate=unname(coef(fs)[2]),se=se2,n_obs=N),
  list(term="effective_shocks",estimate=eff,se=NULL,n_obs=N)),
 method_metadata=list(estimator="weighted 2SLS with BHJ shock-level aggregation",vcov="shock-level HC1, N/(N-2)"),
 diagnostics=list(n_regions=nrow(R)))
write(toJSON(out,auto_unbox=TRUE,digits=NA,null="null",pretty=TRUE),"result.json")
