library(jsonlite)
d <- read.csv("input.csv")
d <- d[order(d$region_id,d$industry_id),]
regs <- sort(unique(d$region_id)); inds <- sort(unique(d$industry_id))
S <- matrix(0,length(regs),length(inds))
S[cbind(match(d$region_id,regs),match(d$industry_id,inds))] <- d$share
R <- d[!duplicated(d$region_id),]; R <- R[match(regs,R$region_id),]
shock <- tapply(d$shock,d$industry_id,function(v){stopifnot(diff(range(v))<1e-12);v[1]})[as.character(inds)]
e <- R$region_weight/sum(R$region_weight)
z <- drop(S%*%shock)
V <- cbind(y=R$y,x=R$x,z=z)
C <- sweep(V,2,drop(e%*%V))
s <- drop(e%*%S)
A <- (t(S)%*%(e*C))/s
N <- length(inds)
siv <- function(dep,endo){
  X <- cbind(1,endo); Z <- cbind(1,shock)
  cr <- crossprod(Z,s*X); b <- solve(cr,crossprod(Z,s*dep))
  u <- drop(dep-X%*%b); sc <- Z*(s*u); inv <- solve(cr)
  V <- N/(N-2)*inv%*%crossprod(sc)%*%t(inv); c(b[2],sqrt(V[2,2]))}
ef <- siv(A[,"y"],A[,"x"]); fs <- siv(A[,"x"],A[,"z"])
reg_ef <- sum(e*C[,3]*C[,1])/sum(e*C[,3]*C[,2])
reg_fs <- sum(e*C[,3]*C[,2])/sum(e*C[,3]^2)
library(AER)
iv <- ivreg(y~x|z,data=data.frame(y=R$y,x=R$x,z=z),weights=e)
chk <- c(ef[1]-reg_ef, fs[1]-reg_fs, ef[1]-coef(iv)[2], max(abs(s%*%A)), sum(s)-1)
print(chk); stopifnot(max(abs(chk))<1e-9)
row <- function(t,est,se) list(term=t,estimate=unname(est),se=se,n_obs=N)
write_json(list(task_id="applied_shift_share",platform="r",
 estimates=list(row("effect",ef[1],ef[2]),row("first_stage",fs[1],fs[2]),row("effective_shocks",1/sum(s^2),NULL)),
 method_metadata=list(estimator="weighted 2SLS; BHJ shock-level IV",vcov="shock-level HC1 N/(N-2), structural residuals"),
 diagnostics=list(n_regions=length(regs),n_industries=N,check_diffs=unname(chk))),
 "result.json",auto_unbox=TRUE,null="null",digits=15,pretty=TRUE)
