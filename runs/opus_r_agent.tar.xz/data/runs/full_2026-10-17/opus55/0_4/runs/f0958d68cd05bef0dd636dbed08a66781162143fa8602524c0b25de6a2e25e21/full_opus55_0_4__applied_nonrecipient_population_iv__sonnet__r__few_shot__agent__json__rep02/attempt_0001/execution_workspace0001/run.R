library(jsonlite)
h <- read.csv("households.csv"); census <- read.csv("census.csv")
d <- subset(h, recipient==0)
e <- d$eligible; ne <- 1-e; w <- d$weight
C <- cbind(ne, e, d$baseline*ne, d$baseline*e)
X <- cbind(C, d$dose*ne, d$dose*e)
Z <- cbind(C, d$instrument*ne, d$instrument*e)
sw <- sqrt(w)
Xh <- qr.fitted(qr(Z*sw), X*sw)
b <- qr.coef(qr(Xh), d$outcome*sw)
md <- c(weighted.mean(d$dose[e==0], w[e==0]), weighted.mean(d$dose[e==1], w[e==1]))
eff <- b[5:6]*md
pw <- census$nonrecipient_population[match(0:1, census$eligible)]
pop <- sum(eff*pw)/sum(pw)
# check: closed-form weighted 2SLS
W <- diag(w); P <- Z %*% solve(t(Z)%*%W%*%Z) %*% t(Z) %*% W
b2 <- solve(t(X)%*%W%*%P%*%X, t(X)%*%W%*%P%*%d$outcome)
n <- nrow(d)
est <- data.frame(term=c("ineligible_effect","eligible_nonrecipient_effect","population_effect"),
  estimate=c(eff,pop), se=NA, n_obs=as.integer(rep(n,3)))
write_json(list(task_id="applied_nonrecipient_population_iv", platform="r", estimates=est,
  method_metadata=list(estimator="weighted 2SLS, fully interacted by eligibility", counterfactual="dose=0"),
  diagnostics=list(slopes=unname(b[5:6]), mean_dose=md, n_retained=n, census_weights=pw, closed_form_maxdiff=max(abs(b-b2)))),
  "result.json", auto_unbox=TRUE, digits=NA, na="null", pretty=TRUE)
