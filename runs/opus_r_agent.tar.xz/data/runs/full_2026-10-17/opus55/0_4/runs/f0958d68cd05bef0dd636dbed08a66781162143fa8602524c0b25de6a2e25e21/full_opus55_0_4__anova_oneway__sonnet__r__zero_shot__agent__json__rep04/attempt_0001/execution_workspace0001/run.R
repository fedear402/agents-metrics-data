library(jsonlite)
d <- read.csv("input.csv")
d <- d[complete.cases(d[, c("group", "y")]), ]
d$group <- factor(d$group)
fit <- aov(y ~ group, data = d)
tab <- summary(fit)[[1]]
Fv <- tab[1, "F value"]; df1 <- tab[1, "Df"]; df2 <- tab[2, "Df"]; p <- tab[1, "Pr(>F)"]
n <- nrow(d)
# independent check: manual sums of squares
gm <- ave(d$y, d$group); ssb <- sum((gm - mean(d$y))^2); ssw <- sum((d$y - gm)^2)
k <- nlevels(d$group); Fm <- (ssb/(k-1))/(ssw/(n-k))
ow <- oneway.test(y ~ group, data = d, var.equal = TRUE)
stopifnot(abs(Fm - Fv) < 1e-9, abs(ow$statistic - Fv) < 1e-9)
est <- function(t, v) list(term = t, estimate = unname(v), se = NULL, n_obs = n)
res <- list(task_id = "anova_oneway", platform = "r",
  estimates = list(est("F", Fv), est("df_num", df1), est("df_den", df2), est("p_value", p)),
  method_metadata = list(estimator = "one-way ANOVA (aov, group as factor)", vcov = "classical (homoskedastic)"),
  diagnostics = list(k_groups = k, manual_F = Fm, oneway_test_F = unname(ow$statistic)))
write_json(res, "result.json", auto_unbox = TRUE, digits = NA, null = "null", pretty = TRUE)
cat(sprintf("F=%.8g df=%d,%d p=%.8g manualF=%.8g n=%d\n", Fv, df1, df2, p, Fm, n))
