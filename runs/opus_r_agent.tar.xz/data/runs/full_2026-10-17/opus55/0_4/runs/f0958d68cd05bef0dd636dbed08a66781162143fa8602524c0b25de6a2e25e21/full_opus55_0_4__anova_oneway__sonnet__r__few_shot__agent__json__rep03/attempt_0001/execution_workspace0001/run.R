library(jsonlite)
d <- read.csv("input.csv")
d <- d[complete.cases(d[, c("group", "y")]), ]
d$group <- factor(d$group)
a <- anova(lm(y ~ group, data = d))
n <- nrow(d)
Fv <- a$`F value`[1]; df1 <- a$Df[1]; df2 <- a$Df[2]; p <- a$`Pr(>F)`[1]
row <- function(t, v) list(term = t, estimate = unname(v), se = NA, n_obs = n)
out <- list(task_id = "anova_oneway", platform = "r",
  estimates = list(row("F", Fv), row("df_num", df1), row("df_den", df2), row("p_value", p)),
  method_metadata = list(estimator = "one-way ANOVA (OLS, group as factor)", vcov = "classical"),
  diagnostics = structure(list(), names = character(0)))
write_json(out, "result.json", auto_unbox = TRUE, digits = NA)
