cw <- read.csv("crosswalk.csv", colClasses=c(code="character"))
tr <- read.csv("trade.csv", colClasses=c(code="character"))
ar <- read.csv("areas.csv"); em <- read.csv("employment.csv"); oc <- read.csv("outcomes.csv")
tr <- merge(tr, cw, by="code")
stopifnot(nrow(tr)==8)
# full grid with zeros for missing cells
g <- expand.grid(area=unique(ar$area), period=unique(ar$period), vintage=c("base","early"), industry=0:3, stringsAsFactors=FALSE)
g <- merge(g, em, all.x=TRUE); g$employment[is.na(g$employment)] <- 0
nat <- aggregate(employment~period+vintage+industry, g, sum); names(nat)[4] <- "nat"
g <- merge(merge(g, nat), ar[c("area","period","vintage","total_employment")])
g <- merge(g, tr[c("period","industry","us_change","other_change","price_index","years")])
g$chg <- ifelse(g$vintage=="base", g$us_change, g$other_change)
g$term <- g$employment/g$total_employment*g$chg/g$nat/(g$price_index/100)/1000*(10/g$years)
ex <- aggregate(term~area+period+vintage, g, sum)
d <- merge(oc, setNames(ex[ex$vintage=="base",c(1,2,4)], c("area","period","x")))
d <- merge(d, setNames(ex[ex$vintage=="early",c(1,2,4)], c("area","period","z")))
d <- merge(d, setNames(ar[ar$vintage=="base",c("area","period","population")], c("area","period","w")))
stopifnot(nrow(d)==72)
X <- cbind(1,d$period,d$control,d$x); Z <- cbind(1,d$period,d$control,d$z); sw <- sqrt(d$w)
Xh <- qr.fitted(qr(Z*sw), X*sw)
b <- qr.coef(qr(Xh), d$change_pp*sw)
# check: closed-form weighted IV (Z'WX)^-1 Z'Wy
b2 <- solve(t(Z)%*%(d$w*X), t(Z)%*%(d$w*d$change_pp))
cat("iv check diff", max(abs(b-b2)), "\n")
gx <- function(a,p,col) d[[col]][d$area==a & d$period==p]
est <- c(iv_slope=b[4], exposure_area0_period0=gx(0,0,"x"), exposure_area0_period1=gx(0,1,"x"), instrument_area0_period0=gx(0,0,"z"))
print(est, digits=12)
jsonlite::write_json(list(task_id="applied_multivintage_trade_iv", platform="r",
  estimates=lapply(names(est), function(n) list(term=n, estimate=unname(est[n]), se=NULL, n_obs=72L)),
  method_metadata=list(estimator="weighted 2SLS", weights="base population", instruments="intercept, period, control, z"),
  diagnostics=list(iv_closed_form_maxdiff=max(abs(b-b2)), n_obs=72L)),
  "result.json", auto_unbox=TRUE, digits=NA, null="null")
