library(jsonlite)
d <- read.csv("input.csv"); d <- d[order(d$t),]
y <- d$y
fit <- arima(y, order=c(1,1,1), method="ML")
p <- predict(fit, n.ahead=1)
f <- as.numeric(p$pred); s <- as.numeric(p$se)
z <- qnorm(0.975); n <- length(y)
e <- function(term, est, se) list(term=term, estimate=est, se=se, n_obs=n)
out <- list(task_id="arima_forecast", platform="r",
  estimates=list(e("forecast",f,s), e("lower_95",f-z*s,NA), e("upper_95",f+z*s,NA)),
  method_metadata=list(estimator="ARIMA(1,1,1) exact ML via stats::arima, no constant", vcov="forecast MSE from Kalman filter"),
  diagnostics=structure(list(), names=character(0)))
write_json(out, "result.json", auto_unbox=TRUE, digits=NA)
print(fit); print(c(f,s))
# check: manual forecast from residuals
cf <- coef(fit); r <- residuals(fit)
man <- y[n] + cf["ar1"]*(y[n]-y[n-1]) + cf["ma1"]*r[n]
cat("manual:", man, " sigma:", sqrt(fit$sigma2), "\n")
