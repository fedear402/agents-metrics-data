h <- read.csv("households.csv"); census <- read.csv("census.csv")
d <- subset(h, recipient==0); e <- d$eligible; w <- d$weight
C <- cbind(1-e, e, d$baseline*(1-e), d$baseline*e)
X <- cbind(C, d$dose*(1-e), d$dose*e); Z <- cbind(C, d$instrument*(1-e), d$instrument*e)
sw <- sqrt(w); Xh <- qr.fitted(qr(Z*sw), X*sw)
b <- qr.coef(qr(Xh), d$outcome*sw)
md <- sapply(0:1, function(g) weighted.mean(d$dose[e==g], w[e==g]))
eff <- b[5:6]*md
pw <- census$nonrecipient_population[match(0:1, census$eligible)]
pop <- sum(eff*pw)/sum(pw)
n <- nrow(d)
est <- data.frame(term=c("ineligible_effect","eligible_nonrecipient_effect","population_effect"),
  estimate=c(eff,pop), se=NA, n_obs=as.integer(n))
jsonlite::write_json(list(task_id="applied_nonrecipient_population_iv", platform="r", estimates=est,
  method_metadata=list(estimator="weighted 2SLS, group-interacted", slopes=unname(b[5:6]), mean_dose=md, pop_weights=pw),
  diagnostics=list(n_obs=n, n_by_group=as.integer(table(factor(e,0:1))))),
  "result.json", auto_unbox=TRUE, digits=NA, na="null", pretty=TRUE)
# check: separate per-group IV equals interacted
chk <- sapply(0:1,function(g){a<-d[e==g,];s<-sqrt(a$weight);Zg<-cbind(1,a$baseline,a$instrument)*s;Xg<-cbind(1,a$baseline,a$dose)*s
 qr.coef(qr(qr.fitted(qr(Zg),Xg)),a$outcome*s)[3]})
cat("check diff:", max(abs(chk-b[5:6])), "\n")
