suppressMessages({library(AER); library(sandwich); library(jsonlite)})
d <- read.csv("input.csv")
R <- d[!duplicated(d$region_id), c("region_id","region_weight","x","y")]
R$e <- R$region_weight/sum(R$region_weight)
d$z_c <- d$share*d$shock
zr <- tapply(d$z_c, d$region_id, sum); R$z <- as.numeric(zr[as.character(R$region_id)])
wm <- function(v) sum(R$e*v)
R$y0 <- R$y-wm(R$y); R$x0 <- R$x-wm(R$x); R$z0 <- R$z-wm(R$z)
d <- merge(d, R[,c("region_id","e","y0","x0","z0")], by="region_id")
d$w <- d$e*d$share
S <- aggregate(cbind(w, wy=w*y0, wx=w*x0, wz=w*z0) ~ industry_id, d, sum)
S$shock <- d$shock[match(S$industry_id, d$industry_id)]
S$s <- S$w; S$ybar <- S$wy/S$s; S$xbar <- S$wx/S$s; S$zbar <- S$wz/S$s
N <- nrow(S)
reg <- ivreg(y ~ x | z, weights=e, data=R)
fs <- lm(x ~ z, weights=e, data=R)
m1 <- ivreg(ybar ~ xbar | shock, weights=s, data=S)
m2 <- ivreg(xbar ~ zbar | shock, weights=s, data=S)
se1 <- sqrt(vcovHC(m1, type="HC1")[2,2]); se2 <- sqrt(vcovHC(m2, type="HC1")[2,2])
# manual HC1 check
man <- function(yv, xv, zv, w){X<-cbind(1,xv);Z<-cbind(1,zv)
  b<-solve(t(Z)%*%(w*X), t(Z)%*%(w*yv)); u<-as.numeric(yv-X%*%b)
  A<-solve(t(Z)%*%(w*X)); M<-t(Z)%*%((w*u)^2*Z); V<-A%*%M%*%t(A)*N/(N-2); c(b[2],sqrt(V[2,2]))}
c1 <- man(S$ybar,S$xbar,S$shock,S$s); c2 <- man(S$xbar,S$zbar,S$shock,S$s)
eff <- 1/sum(S$s^2)
chk <- sprintf("N_regions=%d N_industries=%d sum_e=%.6f sum_s=%.6f\nregional 2SLS slope=%.10f shock-level slope=%.10f manual=%.10f\nregional FS slope=%.10f shock-level=%.10f manual=%.10f\nSE effect sandwich=%.10f manual=%.10f\nSE FS sandwich=%.10f manual=%.10f\neffective_shocks=%.6f\n",
  nrow(R),N,sum(R$e),sum(S$s),coef(reg)[2],coef(m1)[2],c1[1],coef(fs)[2],coef(m2)[2],c2[1],se1,c1[2],se2,c2[2],eff)
cat(chk)
out <- list(task_id="applied_shift_share", platform="r",
 estimates=list(list(term="effect",estimate=unname(coef(reg)[2]),se=se1,n_obs=N),
  list(term="first_stage",estimate=unname(coef(fs)[2]),se=se2,n_obs=N),
  list(term="effective_shocks",estimate=eff,se=NULL,n_obs=N)),
 method_metadata=list(estimator="weighted 2SLS with shift-share instrument; BHJ shock-level IV", vcov="HC1 shock-level, analytic weights s_n, N/(N-2)"),
 diagnostics=list(n_regions=nrow(R)))
write(toJSON(out, auto_unbox=TRUE, digits=NA, null="null"), "result.json")
writeLines(c("Checks:", chk, "Regional slopes match shock-level slopes (BHJ identity); sandwich HC1 matches manual sandwich computation."), "verification.txt")
