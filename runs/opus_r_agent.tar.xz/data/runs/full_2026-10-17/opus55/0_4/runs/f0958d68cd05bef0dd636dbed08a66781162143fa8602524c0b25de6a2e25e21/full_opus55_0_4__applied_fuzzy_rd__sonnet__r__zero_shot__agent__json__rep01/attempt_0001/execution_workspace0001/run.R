library(sandwich); library(jsonlite)
d <- read.csv("input.csv")
d <- d[!is.na(d$score) & abs(d$score) < 1 & !is.na(d$earnings) & !is.na(d$participated), ]
d$r <- as.numeric(d$score >= 0); d$w <- 1 - abs(d$score)
n <- nrow(d)
X <- cbind(1, d$r, d$score, d$r * d$score)
my <- lm(earnings ~ r * score, d, weights = w); md <- lm(participated ~ r * score, d, weights = w)
# joint HC0 sandwich for the two "r" coefficients
B <- solve(crossprod(X, X * d$w))
iy <- (X * d$w * resid(my)) %*% B; id <- (X * d$w * resid(md)) %*% B
IF <- cbind(iy[, 2], id[, 2])
V <- crossprod(IF)
rf <- coef(my)["r"]; fs <- coef(md)["r"]; te <- rf / fs
g <- c(1 / fs, -rf / fs^2); se_te <- sqrt(drop(t(g) %*% V %*% g))
stopifnot(abs(V[1,1] - vcovHC(my, type = "HC0")["r","r"]) < 1e-10)
res <- list(task_id = "applied_fuzzy_rd", platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = unname(te), se = se_te, n_obs = n),
    list(term = "reduced_form", estimate = unname(rf), se = sqrt(V[1,1]), n_obs = n),
    list(term = "first_stage", estimate = unname(fs), se = sqrt(V[2,2]), n_obs = n)),
  method_metadata = list(estimator = "fuzzy RD local linear, triangular kernel, h=1, Wald ratio",
                         vcov = "HC0 joint sandwich, delta method"),
  diagnostics = list(cov_rf_fs = V[1,2], n_left = sum(d$r == 0), n_right = sum(d$r == 1)))
write_json(res, "result.json", auto_unbox = TRUE, digits = 12, pretty = TRUE)
