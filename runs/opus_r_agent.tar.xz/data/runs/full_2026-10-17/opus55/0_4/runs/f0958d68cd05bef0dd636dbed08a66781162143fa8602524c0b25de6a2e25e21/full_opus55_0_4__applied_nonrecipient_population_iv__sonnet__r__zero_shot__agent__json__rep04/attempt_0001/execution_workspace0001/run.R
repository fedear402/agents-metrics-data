d <- read.csv("households.csv"); cen <- read.csv("census.csv")
d <- d[d$recipient==0,]; e <- d$eligible; ne <- 1-e; w <- d$weight
X <- cbind(d$dose*ne, d$dose*e, ne, e, d$baseline*ne, d$baseline*e)
Z <- cbind(ne, e, d$baseline*ne, d$baseline*e, d$instrument*ne, d$instrument*e)
W <- diag(w); y <- d$outcome
Xh <- Z %*% solve(t(Z)%*%W%*%Z, t(Z)%*%W%*%X)
b <- solve(t(Xh)%*%W%*%X, t(Xh)%*%W%*%y)
m0 <- weighted.mean(d$dose[e==0], w[e==0]); m1 <- weighted.mean(d$dose[e==1], w[e==1])
e0 <- b[1]*m0; e1 <- b[2]*m1
p0 <- cen$nonrecipient_population[cen$eligible==0]; p1 <- cen$nonrecipient_population[cen$eligible==1]
pe <- (p0*e0+p1*e1)/(p0+p1); n <- nrow(d)
# check: just-identified per-group IV equals pooled
g <- d[e==0,]; zz <- cbind(1,g$baseline,g$instrument); xx <- cbind(g$dose,1,g$baseline)
chk <- solve(t(zz)%*%(g$weight*xx), t(zz)%*%(g$weight*g$outcome))[1]
cat(b[1],b[2],chk,m0,m1,e0,e1,pe,n,sum(e==0),"\n")
est <- lapply(list(c("ineligible_effect",e0),c("eligible_nonrecipient_effect",e1),c("population_effect",pe)),
  function(x) list(term=x[1], estimate=as.numeric(x[2]), se=NA, n_obs=n))
jsonlite::write_json(list(task_id="applied_nonrecipient_population_iv", platform="r", estimates=est,
  method_metadata=list(estimator="weighted 2SLS, group-specific slopes, no common intercept", weights="weight"),
  diagnostics=list(slope_ineligible=b[1], slope_eligible=b[2], mean_dose_ineligible=m0, mean_dose_eligible=m1,
  n_ineligible=sum(e==0), n_eligible=sum(e==1), check_slope_ineligible_separate=chk)),
  "result.json", auto_unbox=TRUE, digits=NA, na="null", pretty=TRUE)
