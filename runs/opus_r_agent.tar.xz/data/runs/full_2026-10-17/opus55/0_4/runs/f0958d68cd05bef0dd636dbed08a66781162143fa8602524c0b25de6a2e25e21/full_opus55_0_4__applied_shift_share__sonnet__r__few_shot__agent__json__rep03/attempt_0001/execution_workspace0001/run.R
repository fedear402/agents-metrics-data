library(jsonlite)
d <- read.csv("input.csv")
d <- d[order(d$region_id,d$industry_id),]
R <- sort(unique(d$region_id)); I <- sort(unique(d$industry_id))
S <- matrix(0,length(R),length(I)); S[cbind(match(d$region_id,R),match(d$industry_id,I))] <- d$share
reg <- d[!duplicated(d$region_id),]; reg <- reg[match(R,reg$region_id),]
shock <- tapply(d$shock,d$industry_id,function(v){stopifnot(diff(range(v))<1e-12);v[1]})[as.character(I)]
e <- reg$region_weight/sum(reg$region_weight)
z <- drop(S%*%shock)
V <- cbind(y=reg$y,x=reg$x,z=z)
C <- sweep(V,2,drop(e%*%V))
s <- drop(e%*%S)
A <- (t(S)%*%(e*C))/s
N <- length(I)
siv <- function(dep,endo){
  X <- cbind(1,endo); Z <- cbind(1,shock)
  cr <- crossprod(Z,s*X); b <- solve(cr,crossprod(Z,s*dep))
  u <- drop(dep-X%*%b); sc <- Z*(s*u); iv <- solve(cr)
  vc <- N/(N-2)*iv%*%crossprod(sc)%*%t(iv); c(b[2],sqrt(vc[2,2]))}
ef <- siv(A[,"y"],A[,"x"]); fs <- siv(A[,"x"],A[,"z"])
# regional checks
reff <- sum(e*C[,3]*C[,1])/sum(e*C[,3]*C[,2]); rfs <- sum(e*C[,3]*C[,2])/sum(e*C[,3]^2)
library(AER); m <- ivreg(y~x|z,weights=e,data=data.frame(reg,z=z))
cat("checks:",ef[1]-reff,fs[1]-rfs,coef(m)[2]-ef[1],max(abs(s%*%A)),sum(s),"\n")
stopifnot(abs(ef[1]-reff)<1e-9,abs(fs[1]-rfs)<1e-9,abs(coef(m)[2]-ef[1])<1e-9)
row <- function(t,est,se) list(term=t,estimate=unname(est),se=if(is.null(se)) NULL else unname(se),n_obs=N)
out <- list(task_id="applied_shift_share",platform="r",estimates=list(
 row("effect",ef[1],ef[2]),row("first_stage",fs[1],fs[2]),row("effective_shocks",1/sum(s^2),NULL)),
 method_metadata=list(estimator="weighted 2SLS, BHJ shock-level IV",vcov="shock-level HC1 N/(N-2), structural residuals"),
 diagnostics=list(n_regions=length(R),n_industries=N))
write_json(out,"result.json",auto_unbox=TRUE,null="null",digits=16,pretty=TRUE)
print(out$estimates)
