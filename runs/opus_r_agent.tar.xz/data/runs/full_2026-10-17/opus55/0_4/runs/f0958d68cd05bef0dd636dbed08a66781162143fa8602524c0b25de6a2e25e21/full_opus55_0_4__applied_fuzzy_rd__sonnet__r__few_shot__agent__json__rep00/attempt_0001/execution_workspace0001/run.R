library(jsonlite)
d <- read.csv("input.csv")
s <- d[abs(d$score) < 1, ]
n <- nrow(s); w <- 1 - abs(s$score); r <- as.numeric(s$score >= 0)
X <- cbind(1, r, s$score, r * s$score)
Y <- cbind(s$earnings, s$participated)
bread <- solve(crossprod(X, w * X))
b <- bread %*% crossprod(X, w * Y)
e <- Y - X %*% b
cc <- c(0, 1, 0, 0)
j <- drop(cc %*% b)
inf <- (w * drop(X %*% bread %*% cc)) * e
V <- crossprod(inf)
g <- c(1 / j[2], -j[1] / j[2]^2)
te <- j[1] / j[2]; te_se <- sqrt(drop(t(g) %*% V %*% g))
# check: lm + sandwich
f1 <- lm(earnings ~ r * score, data = cbind(s, r = r), weights = w)
chk <- sqrt(sandwich::vcovHC(f1, type = "HC0")["r", "r"])
cat("check rf se", chk, sqrt(V[1,1]), "\n")
row <- function(t, e, se) list(term = t, estimate = e, se = se, n_obs = n)
write_json(list(task_id = "applied_fuzzy_rd", platform = "r",
  estimates = list(row("treatment_effect", te, te_se), row("reduced_form", j[1], sqrt(V[1,1])),
                   row("first_stage", j[2], sqrt(V[2,2]))),
  method_metadata = list(estimator = "local-linear fuzzy RD, triangular kernel, h=1", vcov = "HC0 joint, delta method"),
  diagnostics = list(cov_rf_fs = V[1,2])), "result.json", auto_unbox = TRUE, digits = 15, pretty = TRUE)
