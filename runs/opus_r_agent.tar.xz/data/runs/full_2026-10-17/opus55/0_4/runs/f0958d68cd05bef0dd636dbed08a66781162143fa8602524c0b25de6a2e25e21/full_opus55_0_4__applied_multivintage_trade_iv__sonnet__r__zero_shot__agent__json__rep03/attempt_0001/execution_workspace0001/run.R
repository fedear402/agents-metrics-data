library(jsonlite)
cw <- read.csv("crosswalk.csv", colClasses=c(code="character"))
inp <- read.csv("input.csv", colClasses=c(code="character"))
stopifnot(identical(cw, inp))
tr <- merge(read.csv("trade.csv", colClasses=c(code="character")), cw, by="code")
ar <- read.csv("areas.csv"); em <- read.csv("employment.csv"); oc <- read.csv("outcomes.csv")
inds <- sort(unique(cw$industry)); stopifnot(length(inds)==4)
full <- expand.grid(area=unique(ar$area), period=unique(ar$period), vintage=c("base","early"), industry=inds, stringsAsFactors=FALSE)
em <- merge(full, em, all.x=TRUE); em$employment[is.na(em$employment)] <- 0
nat <- aggregate(employment~period+vintage+industry, em, sum); names(nat)[4] <- "nat"
d <- merge(merge(merge(em, nat), tr), ar[,c("area","period","vintage","total_employment")])
d$chg <- ifelse(d$vintage=="base", d$us_change, d$other_change)
d$term <- d$employment/d$total_employment*d$chg/d$nat/(d$price_index/100)/1000*(10/d$years)
ex <- aggregate(term~area+period+vintage, d, sum)
X <- merge(setNames(ex[ex$vintage=="base",c(1,2,4)],c("area","period","x")),
           setNames(ex[ex$vintage=="early",c(1,2,4)],c("area","period","z")))
pop <- ar[ar$vintage=="base",c("area","period","population")]
D <- merge(merge(oc, X), pop); stopifnot(nrow(D)==72)
Xm <- cbind(1, D$period, D$control, D$x); Zm <- cbind(1, D$period, D$control, D$z); w <- D$population
b <- solve(t(Zm)%*%(w*Xm), t(Zm)%*%(w*D$change_pp))
# check: two-stage via lm
xh <- fitted(lm(x~period+control+z, D, weights=population))
b2 <- coef(lm(D$change_pp~D$period+D$control+xh, weights=w))
cat("2SLS:", b, "\ncheck:", b2, "\n")
g <- function(a,p,v) X[X$area==a & X$period==p, v]
est <- list(iv_slope=b[4], exposure_area0_period0=g(0,0,"x"), exposure_area0_period1=g(0,1,"x"), instrument_area0_period0=g(0,0,"z"))
print(est)
write_json(list(task_id="applied_multivintage_trade_iv", platform="r",
  estimates=lapply(names(est), function(n) list(term=n, estimate=unname(est[[n]]), se=NULL, n_obs=72L)),
  method_metadata=list(estimator="weighted 2SLS", weight="base population", instruments=c("const","period","control","z")),
  diagnostics=list(n_obs=72L, check_two_stage_slope=unname(b2[4]))),
  "result.json", auto_unbox=TRUE, digits=NA, null="null")
