library(sandwich); library(jsonlite)
d <- read.csv("input.csv")
d <- d[!is.na(d$score) & abs(d$score) < 1, ]
d <- d[complete.cases(d[, c("participated","earnings")]), ]
d$D <- as.numeric(d$score >= 0); d$w <- 1 - abs(d$score)
n <- nrow(d)
X <- cbind(1, d$D, d$score, d$D * d$score)
W <- d$w
A <- solve(crossprod(X, X * W))
fit <- function(y) { b <- A %*% crossprod(X, W * y); list(b = b, psi = (X * (W * as.vector(y - X %*% b))) %*% A) }
ry <- fit(d$earnings); rd <- fit(d$participated)
rf <- ry$b[2]; fs <- rd$b[2]
P <- cbind(ry$psi[, 2], rd$psi[, 2]); V <- crossprod(P)
te <- rf / fs; g <- c(1 / fs, -rf / fs^2)
se_te <- sqrt(drop(t(g) %*% V %*% g))
# check against sandwich HC0
m1 <- lm(earnings ~ D * score, d, weights = w); m2 <- lm(participated ~ D * score, d, weights = w)
chk <- c(coef(m1)["D"] - rf, sqrt(vcovHC(m1, "HC0")["D","D"]) - sqrt(V[1,1]), sqrt(vcovHC(m2, "HC0")["D","D"]) - sqrt(V[2,2]))
# independent check: weighted IV with HC0
library(AER); iv <- ivreg(earnings ~ participated + score + D:score | D + score + D:score, data = d, weights = w)
chk_iv <- c(coef(iv)["participated"] - te, sqrt(vcovHC(iv, "HC0")["participated","participated"]) - se_te)
print(c(chk, chk_iv))
out <- list(task_id = "applied_fuzzy_rd", platform = "r",
  estimates = list(
    list(term = "treatment_effect", estimate = te, se = se_te, n_obs = n),
    list(term = "reduced_form", estimate = rf, se = sqrt(V[1,1]), n_obs = n),
    list(term = "first_stage", estimate = fs, se = sqrt(V[2,2]), n_obs = n)),
  method_metadata = list(estimator = "fuzzy RD local linear, triangular kernel, h=1, ratio of discontinuities", vcov = "HC0 joint influence-function covariance, delta method"),
  diagnostics = list(cov_rf_fs = V[1,2], n_left = sum(d$D == 0), n_right = sum(d$D == 1)))
write_json(out, "result.json", auto_unbox = TRUE, digits = NA, pretty = TRUE)
