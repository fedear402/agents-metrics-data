library(jsonlite)
d <- read.csv("input.csv")
stopifnot(!anyNA(d))
d <- d[order(d$region_id,d$industry_id),]
regs <- sort(unique(d$region_id)); inds <- sort(unique(d$industry_id))
S <- matrix(0,length(regs),length(inds))
S[cbind(match(d$region_id,regs),match(d$industry_id,inds))] <- d$share
reg <- d[!duplicated(d$region_id),]; reg <- reg[match(regs,reg$region_id),]
shock <- tapply(d$shock,d$industry_id,function(v){stopifnot(diff(range(v))<1e-12);v[1]})[as.character(inds)]
shock <- as.numeric(shock)
e <- reg$region_weight/sum(reg$region_weight)
z <- drop(S%*%shock)
V <- cbind(y=reg$y,x=reg$x,z=z)
C <- sweep(V,2,drop(e%*%V))
s <- drop(e%*%S)
A <- (t(S)%*%(e*C))/s
N <- length(inds)
siv <- function(dep,endo){
  X <- cbind(1,endo); Z <- cbind(1,shock)
  cr <- crossprod(Z,s*X); b <- solve(cr,crossprod(Z,s*dep))
  u <- drop(dep-X%*%b); sc <- Z*(s*u); iv <- solve(cr)
  V <- N/(N-2)*iv%*%crossprod(sc)%*%t(iv); c(b[2],sqrt(V[2,2]))}
ef <- siv(A[,"y"],A[,"x"]); fs <- siv(A[,"x"],A[,"z"])
# regional checks
r_ef <- sum(e*C[,3]*C[,1])/sum(e*C[,3]*C[,2]); r_fs <- sum(e*C[,3]*C[,2])/sum(e*C[,3]^2)
library(AER)
iv2 <- ivreg(y~x|z,weights=e,data=data.frame(V,e=e))
fsl <- lm(x~z,weights=e,data=data.frame(V,e=e))
chk <- c(ef[1]-r_ef,fs[1]-r_fs,ef[1]-coef(iv2)[2],fs[1]-coef(fsl)[2])
print(chk); stopifnot(max(abs(chk))<1e-8)
cat("regions",length(regs),"industries",N,"rowsums range",range(rowSums(S)),"\n")
print(rbind(ef,fs)); print(1/sum(s^2))
row <- function(t,est,se) list(term=t,estimate=unname(est),se=if(is.null(se)) NULL else unname(se),n_obs=N)
write_json(list(task_id="applied_shift_share",platform="r",
  estimates=list(row("effect",ef[1],ef[2]),row("first_stage",fs[1],fs[2]),row("effective_shocks",1/sum(s^2),NULL)),
  method_metadata=list(estimator="weighted 2SLS; BHJ shock-level IV",vcov="shock-level HC1 N/(N-2), structural residuals"),
  diagnostics=list(n_regions=length(regs),max_slope_check_diff=max(abs(chk)))),
  "result.json",auto_unbox=TRUE,null="null",digits=16,pretty=TRUE)
