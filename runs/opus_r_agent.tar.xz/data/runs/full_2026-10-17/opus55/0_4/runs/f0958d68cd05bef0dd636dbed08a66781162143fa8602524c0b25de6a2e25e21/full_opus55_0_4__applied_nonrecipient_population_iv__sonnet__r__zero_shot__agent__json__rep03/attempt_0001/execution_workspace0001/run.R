d <- read.csv("households.csv"); cen <- read.csv("census.csv")
d <- d[d$recipient==0,]; e <- d$eligible; w <- d$weight
X <- cbind(1-e, e, d$baseline*(1-e), d$baseline*e, d$dose*(1-e), d$dose*e)
Z <- cbind(X[,1:4], d$instrument*(1-e), d$instrument*e)
W <- diag(w)
Xh <- Z %*% solve(t(Z)%*%W%*%Z, t(Z)%*%W%*%X)
b <- solve(t(Xh)%*%W%*%X, t(Xh)%*%W%*%d$outcome)
m0 <- weighted.mean(d$dose[e==0], w[e==0]); m1 <- weighted.mean(d$dose[e==1], w[e==1])
e0 <- b[5]*m0; e1 <- b[6]*m1
p0 <- cen$nonrecipient_population[cen$eligible==0]; p1 <- cen$nonrecipient_population[cen$eligible==1]
pe <- (p0*e0+p1*e1)/(p0+p1)
# check: 2-stage via lm
f1 <- lm(cbind(X[,5],X[,6]) ~ Z-1, weights=w)
chk <- coef(lm(d$outcome ~ X[,1:4] + fitted(f1) - 1, weights=w))[5:6]
n <- nrow(d)
est <- lapply(list(c("ineligible_effect",e0),c("eligible_nonrecipient_effect",e1),c("population_effect",pe)),
  function(x) list(term=x[1], estimate=as.numeric(x[2]), se=NA, n_obs=n))
jsonlite::write_json(list(task_id="applied_nonrecipient_population_iv", platform="r", estimates=est,
  method_metadata=list(estimator="weighted 2SLS, group-interacted, no extra intercept", weights="weight"),
  diagnostics=list(slope_ineligible=b[5], slope_eligible=b[6], mean_dose_ineligible=m0, mean_dose_eligible=m1,
    n_ineligible=sum(e==0), n_eligible=sum(e==1), lm_check_diff=max(abs(chk-b[5:6])))),
  "result.json", auto_unbox=TRUE, digits=NA, na="null")
