library(jsonlite)
d <- read.csv("input.csv")
d <- d[abs(d$score) < 1, ]
n <- nrow(d)
w <- 1 - abs(d$score)
a <- as.numeric(d$score >= 0)
X <- cbind(1, a, d$score, a*d$score)
Y <- cbind(d$earnings, d$participated)
bread <- solve(crossprod(X, w*X))
B <- bread %*% crossprod(X, w*Y)
R <- Y - X %*% B
ct <- c(0,1,0,0)
j <- drop(ct %*% B)
inf <- w * drop(X %*% bread %*% ct) * R
V <- crossprod(inf)
g <- c(1/j[2], -j[1]/j[2]^2)
te <- j[1]/j[2]; tse <- sqrt(drop(t(g)%*%V%*%g))
# check: lm + sandwich HC0
library(sandwich)
m1 <- lm(earnings ~ a*score, d, weights=w); m2 <- lm(participated ~ a*score, d, weights=w)
chk <- c(coef(m1)["a"]-j[1], sqrt(vcovHC(m1,type="HC0")["a","a"])-sqrt(V[1,1]),
         sqrt(vcovHC(m2,type="HC0")["a","a"])-sqrt(V[2,2]))
print(chk); print(c(n=n, j, te, sqrt(diag(V)), tse))
r <- function(t,e,s) list(term=t,estimate=unname(e),se=unname(s),n_obs=n)
write_json(list(task_id="applied_fuzzy_rd", platform="r",
  estimates=list(r("treatment_effect",te,tse), r("reduced_form",j[1],sqrt(V[1,1])), r("first_stage",j[2],sqrt(V[2,2]))),
  method_metadata=list(estimator="local linear fuzzy RD, triangular kernel, h=1, Wald ratio", vcov="HC0 joint, delta method"),
  diagnostics=list(cov_rf_fs=V[1,2])), "result.json", auto_unbox=TRUE, digits=16, pretty=TRUE)
