library(sandwich); library(jsonlite)
d <- read.csv("input.csv"); d <- d[order(as.Date(d$date)),]
y <- log(d$sales); dv <- c(NA, diff(log(d$vix)))
X <- sapply(1:15, function(k) c(rep(NA,k), head(dv, -k)))
colnames(X) <- paste0("L",1:15)
ok <- complete.cases(X); df <- data.frame(y=y[ok], X[ok,])
m <- lm(y ~ ., data=df); N <- nobs(m)
V <- NeweyWest(m, lag=15, prewhite=FALSE, adjust=FALSE) * N/(N-16)
# manual check
Z <- model.matrix(m); u <- resid(m); S <- crossprod(Z*u)
for (j in 1:15) { G <- crossprod(Z[(j+1):N,]*u[(j+1):N], Z[1:(N-j),]*u[1:(N-j)]); S <- S + (1-j/16)*(G+t(G)) }
B <- solve(crossprod(Z)); V2 <- B %*% S %*% B * N/(N-16)
cat("max diff", max(abs(V-V2)), "\n")
w <- c(0, rep(1,15)); b <- coef(m)
cs <- sum(b[-1]); cse <- sqrt(drop(t(w)%*%V%*%w))
# check identity: reparameterized regression
cat("N", N, "cum", cs, cse, "\n")
est <- list(list(term="cumulative_response", estimate=cs, se=cse, n_obs=N),
 list(term="lag_1", estimate=unname(b[2]), se=sqrt(V[2,2]), n_obs=N),
 list(term="lag_15", estimate=unname(b[16]), se=sqrt(V[16,16]), n_obs=N))
write(toJSON(list(task_id="applied_cumulative_hac", platform="r", estimates=est,
 method_metadata=list(estimator="OLS distributed lag", vcov="Newey-West Bartlett lag 15, scaled N/(N-16)"),
 diagnostics=setNames(list(),character(0))), auto_unbox=TRUE, digits=12, pretty=TRUE), "result.json")
