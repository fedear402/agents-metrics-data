suppressMessages({library(AER); library(sandwich); library(jsonlite)})
d <- read.csv("input.csv")
R <- d[!duplicated(d$region_id), c("region_id","region_weight","x","y")]
R$e <- R$region_weight/sum(R$region_weight)
z <- tapply(d$share*d$shock, d$region_id, sum); R$z <- z[as.character(R$region_id)]
for (v in c("x","y","z")) R[[paste0(v,"0")]] <- R[[v]] - sum(R$e*R[[v]])
d <- merge(d, R[,c("region_id","e","x0","y0","z0")], by="region_id")
d$w <- d$e*d$share
I <- aggregate(cbind(w, wx=w*x0, wy=w*y0, wz=w*z0) ~ industry_id, d, sum)
I$shock <- d$shock[match(I$industry_id, d$industry_id)]
I$s <- I$w; I$xbar <- I$wx/I$s; I$ybar <- I$wy/I$s; I$zbar <- I$wz/I$s
I <- I[I$s > 0,]; N <- nrow(I)
reg <- ivreg(y ~ x | z, data=R, weights=e)
fs  <- lm(x ~ z, data=R, weights=e)
m1 <- ivreg(ybar ~ xbar | shock, data=I, weights=s)
m2 <- ivreg(xbar ~ zbar | shock, data=I, weights=s)
se1 <- sqrt(vcovHC(m1, type="HC1")[2,2]); se2 <- sqrt(vcovHC(m2, type="HC1")[2,2])
# manual HC1 check
man <- function(Y,X,Z,w){Xm<-cbind(1,X);Zm<-cbind(1,Z);b<-solve(t(Zm)%*%(w*Xm),t(Zm)%*%(w*Y));u<-Y-Xm%*%b
 A<-solve(t(Zm)%*%(w*Xm)); M<-t(Zm*(w*u)[,1])%*%(Zm*(w*u)[,1]); c(b[2],sqrt((A%*%M%*%t(A))[2,2]*N/(N-2)))}
cat("regional 2SLS", coef(reg)[2], "shock-level", coef(m1)[2], "\nmanual", man(I$ybar,I$xbar,I$shock,I$s), "sandwich", se1,
    "\nFS", coef(fs)[2], coef(m2)[2], "manual", man(I$xbar,I$zbar,I$shock,I$s), se2, "\nN", N, "sum s", sum(I$s), "\n")
eff <- 1/sum(I$s^2)
out <- list(task_id="applied_shift_share", platform="r",
 estimates=list(list(term="effect",estimate=unname(coef(reg)[2]),se=se1,n_obs=N),
  list(term="first_stage",estimate=unname(coef(fs)[2]),se=se2,n_obs=N),
  list(term="effective_shocks",estimate=eff,se=NULL,n_obs=N)),
 method_metadata=list(estimator="weighted 2SLS, shift-share IV", vcov="BHJ shock-level HC1"),
 diagnostics=list(n_regions=nrow(R)))
write(toJSON(out, auto_unbox=TRUE, digits=12, null="null"), "result.json")
