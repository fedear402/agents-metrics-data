library(jsonlite)
d <- read.csv("input.csv")
d <- d[abs(d$score) < 1, ]
n <- nrow(d)
w <- 1 - abs(d$score)
r <- as.numeric(d$score >= 0)
X <- cbind(1, r, d$score, r*d$score)
Y <- cbind(d$earnings, d$participated)
bread <- solve(crossprod(X, w*X))
b <- bread %*% crossprod(X, w*Y)
e <- Y - X %*% b
ct <- c(0,1,0,0)
j <- drop(ct %*% b)
inf <- (w * drop(X %*% bread %*% ct)) * e
V <- crossprod(inf)
g <- c(1/j[2], -j[1]/j[2]^2)
te <- j[1]/j[2]; tse <- sqrt(drop(t(g) %*% V %*% g))
# check: lm + sandwich
f1 <- lm(earnings ~ r*score, data=cbind(d,r=r), weights=w)
chk <- c(coef(f1)["r"], sqrt(sandwich::vcovHC(f1,type="HC0")["r","r"]))
print(c(j, sqrt(diag(V)), te, tse)); print(chk)
row <- function(t,e,s) list(term=t,estimate=e,se=s,n_obs=n)
write_json(list(task_id="applied_fuzzy_rd", platform="r",
  estimates=list(row("treatment_effect",te,tse),row("reduced_form",j[1],sqrt(V[1,1])),row("first_stage",j[2],sqrt(V[2,2]))),
  method_metadata=list(estimator="fuzzy RD local linear triangular h=1, Wald ratio", vcov="HC0 joint, delta method"),
  diagnostics=list(cov_rf_fs=V[1,2])), "result.json", auto_unbox=TRUE, digits=16, pretty=TRUE)
