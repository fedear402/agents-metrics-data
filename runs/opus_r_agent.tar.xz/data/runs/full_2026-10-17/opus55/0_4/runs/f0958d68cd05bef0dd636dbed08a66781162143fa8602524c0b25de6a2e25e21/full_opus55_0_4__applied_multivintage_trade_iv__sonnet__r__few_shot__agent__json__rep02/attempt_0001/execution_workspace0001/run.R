cw <- read.csv("crosswalk.csv", colClasses=c("character","integer"))
inp <- read.csv("input.csv", colClasses=c("character","integer"))  # identical copy of crosswalk
stopifnot(identical(cw, inp))
tr <- merge(read.csv("trade.csv", colClasses=c(code="character")), cw, by="code")
ar <- read.csv("areas.csv"); em <- read.csv("employment.csv"); oc <- read.csv("outcomes.csv")
# complete grid with zeros
g <- expand.grid(area=unique(ar$area), period=unique(ar$period), vintage=c("base","early"), industry=0:3, stringsAsFactors=FALSE)
em <- merge(g, em, all.x=TRUE); em$employment[is.na(em$employment)] <- 0
nat <- aggregate(employment~period+vintage+industry, em, sum); names(nat)[4] <- "nat"
em <- merge(merge(em, nat), ar[c("area","period","vintage","total_employment")])
em <- merge(em, tr[c("period","industry","us_change","other_change","price_index","years")])
em$chg <- ifelse(em$vintage=="base", em$us_change, em$other_change)
em$term <- em$employment/em$total_employment*em$chg/em$nat/(em$price_index/100)/1000*(10/em$years)
ex <- aggregate(term~area+period+vintage, em, sum)
d <- merge(oc, setNames(ex[ex$vintage=="base",c("area","period","term")], c("area","period","x")))
d <- merge(d, setNames(ex[ex$vintage=="early",c("area","period","term")], c("area","period","z")))
d <- merge(d, ar[ar$vintage=="base", c("area","period","population")])
stopifnot(nrow(d)==72)
w <- d$population; X <- cbind(1,d$period,d$control,d$x); Z <- cbind(1,d$period,d$control,d$z)
sw <- sqrt(w); Xh <- qr.fitted(qr(Z*sw), X*sw)
b <- qr.coef(qr(Xh), d$change_pp*sw)
# check: just-identified closed form (Z'WX)^-1 Z'Wy
b2 <- solve(t(Z*w)%*%X, t(Z*w)%*%d$change_pp)
stopifnot(max(abs(b-b2))<1e-8)
est <- c(iv_slope=b[4], exposure_area0_period0=d$x[d$area==0&d$period==0],
  exposure_area0_period1=d$x[d$area==0&d$period==1], instrument_area0_period0=d$z[d$area==0&d$period==0])
print(est, digits=12)
jsonlite::write_json(list(task_id="applied_multivintage_trade_iv", platform="r",
  estimates=lapply(names(est), function(n) list(term=n, estimate=unname(est[n]), se=NULL, n_obs=72L)),
  method_metadata=list(estimator="weighted 2SLS", weight="base population", instruments="intercept, period, control, z"),
  diagnostics=list(n_obs=72L, closed_form_max_diff=max(abs(b-b2)))),
  "result.json", auto_unbox=TRUE, digits=NA, null="null")
