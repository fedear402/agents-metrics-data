library(jsonlite)
cw <- read.csv("crosswalk.csv", colClasses=c(code="character"))
inp <- read.csv("input.csv", colClasses=c(code="character")); stopifnot(identical(inp, cw))
tr <- read.csv("trade.csv", colClasses=c(code="character"))
ar <- read.csv("areas.csv"); em <- read.csv("employment.csv"); out <- read.csv("outcomes.csv")
tr <- merge(tr, cw, by="code"); stopifnot(nrow(tr)==8)
# complete grid with zeros
g <- expand.grid(area=unique(ar$area), period=unique(ar$period), vintage=c("base","early"), industry=0:3, stringsAsFactors=FALSE)
em <- merge(g, em, all.x=TRUE); em$employment[is.na(em$employment)] <- 0
nat <- aggregate(employment~period+vintage+industry, em, sum); names(nat)[4] <- "nat"
em <- merge(merge(em, nat), ar[,c("area","period","vintage","total_employment")])
em <- merge(em, tr[,c("period","industry","us_change","other_change","price_index","years")])
em$chg <- ifelse(em$vintage=="base", em$us_change, em$other_change)
em$term <- em$employment/em$total_employment*em$chg/em$nat/(em$price_index/100)/1000*(10/em$years)
ex <- aggregate(term~area+period+vintage, em, sum)
d <- merge(out, setNames(ex[ex$vintage=="base",c(1,2,4)],c("area","period","x")))
d <- merge(d, setNames(ex[ex$vintage=="early",c(1,2,4)],c("area","period","z")))
d <- merge(d, ar[ar$vintage=="base",c("area","period","population")])
stopifnot(nrow(d)==72)
X <- cbind(1, d$period, d$control, d$x); Z <- cbind(1, d$period, d$control, d$z); w <- d$population
Xh <- Z %*% solve(t(Z)%*%(w*Z), t(Z)%*%(w*X))
b <- solve(t(Xh)%*%(w*X), t(Xh)%*%(w*d$change_pp))
# check: Wald/ratio via FWL-like just-identified formula
b2 <- solve(t(Z)%*%(w*X), t(Z)%*%(w*d$change_pp))
cat("iv", b[4], "check", b2[4], "\n")
g0 <- function(p,v) d[d$area==0&d$period==p, v]
est <- data.frame(term=c("iv_slope","exposure_area0_period0","exposure_area0_period1","instrument_area0_period0"),
  estimate=c(b[4], g0(0,"x"), g0(1,"x"), g0(0,"z")), se=NA, n_obs=72L)
print(est, digits=12)
write_json(list(task_id="applied_multivintage_trade_iv", platform="r", estimates=est,
  method_metadata=list(estimator="weighted 2SLS", weight="base population", instruments="intercept, period, control, z"),
  diagnostics=list(n_obs=72L, first_stage_coef_z=unname(solve(t(Z)%*%(w*Z), t(Z)%*%(w*d$x))[4]))),
  "result.json", auto_unbox=TRUE, digits=NA, na="null")
