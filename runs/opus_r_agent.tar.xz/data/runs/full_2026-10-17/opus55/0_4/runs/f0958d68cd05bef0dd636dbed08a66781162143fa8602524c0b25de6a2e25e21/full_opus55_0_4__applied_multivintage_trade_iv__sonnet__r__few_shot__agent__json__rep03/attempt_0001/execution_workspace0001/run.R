cw <- read.csv("crosswalk.csv", colClasses=c("character","integer"))
inp <- read.csv("input.csv", colClasses=c("character","integer"))
stopifnot(identical(cw, inp))
tr <- merge(read.csv("trade.csv"), cw, by="code")
ar <- read.csv("areas.csv"); em <- read.csv("employment.csv"); oc <- read.csv("outcomes.csv")
g <- expand.grid(area=unique(ar$area), period=0:1, vintage=c("base","early"), industry=0:3, stringsAsFactors=FALSE)
g <- merge(g, em, all.x=TRUE); g$employment[is.na(g$employment)] <- 0
nat <- aggregate(employment~period+vintage+industry, g, sum); names(nat)[4] <- "nat"
g <- merge(merge(g, nat), ar[c("area","period","vintage","total_employment")])
g <- merge(g, tr[c("period","industry","us_change","other_change","price_index","years")])
g$chg <- ifelse(g$vintage=="base", g$us_change, g$other_change)
g$term <- g$employment/g$total_employment*g$chg/g$nat/(g$price_index/100)/1000*(10/g$years)
ex <- aggregate(term~area+period+vintage, g, sum)
d <- merge(oc, setNames(ex[ex$vintage=="base",c(1,2,4)],c("area","period","x")))
d <- merge(d, setNames(ex[ex$vintage=="early",c(1,2,4)],c("area","period","z")))
d <- merge(d, ar[ar$vintage=="base",c("area","period","population")])
stopifnot(nrow(d)==72, !anyNA(d))
w <- d$population; X <- cbind(1,d$period,d$control,d$x); Z <- cbind(1,d$period,d$control,d$z)
sw <- sqrt(w); Xh <- qr.fitted(qr(Z*sw), X*sw)
b <- qr.coef(qr(Xh), d$change_pp*sw)
# check: just-identified IV identity b = (Z'WX)^-1 Z'Wy
b2 <- solve(t(Z)%*%(w*X), t(Z)%*%(w*d$change_pp))
cat("IV check diff:", max(abs(b-b2)), "\n")
gx <- function(a,p,v) ex$term[ex$area==a&ex$period==p&ex$vintage==v]
vals <- c(iv_slope=b[4], exposure_area0_period0=gx(0,0,"base"), exposure_area0_period1=gx(0,1,"base"), instrument_area0_period0=gx(0,0,"early"))
print(vals, digits=12)
est <- lapply(names(vals), function(n) list(term=n, estimate=unname(vals[n]), se=NA, n_obs=72L))
jsonlite::write_json(list(task_id="applied_multivintage_trade_iv", platform="r", estimates=est,
  method_metadata=list(estimator="weighted 2SLS", weights="base population", instruments="intercept, period, control, z"),
  diagnostics=list(iv_identity_check=max(abs(b-b2)), n_obs=72L)), "result.json", auto_unbox=TRUE, digits=NA, na="null")
