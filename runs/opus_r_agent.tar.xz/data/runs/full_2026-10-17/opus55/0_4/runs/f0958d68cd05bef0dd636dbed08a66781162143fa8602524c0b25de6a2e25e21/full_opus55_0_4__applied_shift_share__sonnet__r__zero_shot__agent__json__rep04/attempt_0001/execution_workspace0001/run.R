suppressMessages({library(AER);library(sandwich);library(jsonlite)})
d <- read.csv("input.csv")
d <- d[complete.cases(d),]
reg <- d[!duplicated(d$region_id), c("region_id","region_weight","x","y")]
reg$e <- reg$region_weight/sum(reg$region_weight)
z <- tapply(d$share*d$shock, d$region_id, sum)
reg$z <- as.numeric(z[as.character(reg$region_id)])
m2 <- ivreg(y~x|z, data=reg, weights=e)
fs <- lm(x~z, data=reg, weights=e)
for (v in c("y","x","z")) reg[[paste0(v,"0")]] <- reg[[v]]-sum(reg$e*reg[[v]])
d <- merge(d[,c("region_id","industry_id","share","shock")], reg[,c("region_id","e","y0","x0","z0")], by="region_id")
d$w <- d$e*d$share
ind <- do.call(rbind, lapply(split(d, d$industry_id), function(g){ s<-sum(g$w)
  data.frame(industry_id=g$industry_id[1], s=s, shock=g$shock[1],
   yb=sum(g$w*g$y0)/s, xb=sum(g$w*g$x0)/s, zb=sum(g$w*g$z0)/s)}))
ind <- ind[ind$s>0,]; N <- nrow(ind)
se1 <- ivreg(yb~xb|shock, data=ind, weights=s)
se2 <- ivreg(xb~zb|shock, data=ind, weights=s)
SE <- function(m) sqrt(vcovHC(m,type="HC1")[2,2])
cat("regional:",coef(m2)[2],coef(fs)[2]," shock-level:",coef(se1)[2],coef(se2)[2],"N",N,"R",nrow(reg),"\n")
eff <- 1/sum(ind$s^2)
res <- list(task_id="applied_shift_share", platform="r",
 estimates=list(list(term="effect",estimate=unname(coef(m2)[2]),se=SE(se1),n_obs=N),
  list(term="first_stage",estimate=unname(coef(fs)[2]),se=SE(se2),n_obs=N),
  list(term="effective_shocks",estimate=eff,se=NULL,n_obs=N)),
 method_metadata=list(estimator="weighted 2SLS, shift-share IV",vcov="BHJ shock-level HC1"),
 diagnostics=list(n_regions=nrow(reg),sum_s=sum(ind$s)))
write(toJSON(res,auto_unbox=TRUE,digits=10,null="null",pretty=TRUE),"result.json")
# manual check of HC1
X<-cbind(1,ind$xb);Z<-cbind(1,ind$shock);W<-ind$s
b<-solve(t(Z*W)%*%X,t(Z*W)%*%ind$yb);u<-ind$yb-X%*%b
A<-solve(t(Z*W)%*%X);M<-t(Z*(W*u)[,1])%*%(Z*(W*u)[,1])
cat("manual se:",sqrt((A%*%M%*%t(A))[2,2]*N/(N-2)),SE(se1),"\n")
