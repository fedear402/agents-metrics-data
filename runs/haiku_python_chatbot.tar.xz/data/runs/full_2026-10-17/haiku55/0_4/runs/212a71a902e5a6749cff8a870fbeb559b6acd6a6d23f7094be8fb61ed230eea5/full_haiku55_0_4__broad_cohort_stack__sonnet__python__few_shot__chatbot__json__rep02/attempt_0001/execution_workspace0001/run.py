import json

import numpy as np
import pandas as pd


def cohort_att(df, c):
    lo, hi = c - 2, c + 2
    window = df[(df['time'] >= lo) & (df['time'] <= hi)]
    eligible = window[(window['g'] == c) | (window['g'] == 0) | (window['g'] > c + 2)]
    times_per_unit = eligible.groupby('id')['time'].nunique()
    balanced_ids = times_per_unit[times_per_unit == hi - lo + 1].index
    sample = eligible[eligible['id'].isin(balanced_ids)].copy()

    n_treated = int(sample.loc[sample['g'] == c, 'id'].nunique())
    did = ((sample['g'] == c) & (sample['time'] >= c)).astype(float).values

    unit_dummies = pd.get_dummies(sample['id'].astype(str), drop_first=True, dtype=float).values
    time_dummies = pd.get_dummies(sample['time'].astype(str), drop_first=True, dtype=float).values
    design = np.column_stack([np.ones(len(sample)), did, unit_dummies, time_dummies])
    beta = np.linalg.lstsq(design, sample['y'].values.astype(float), rcond=None)[0]
    return float(beta[1]), n_treated, int(len(sample))


df = pd.read_csv('input.csv')
df = df[['id', 'time', 'g', 'y']]

estimates = []
weights = []
att_values = []
total_rows = 0

for c in (3, 5, 7):
    att, n_treated, n_rows = cohort_att(df, c)
    att_values.append(att)
    weights.append(n_treated)
    total_rows += n_rows
    estimates.append({
        'term': f'att_g{c}',
        'estimate': att,
        'se': None,
        'n_obs': n_rows,
    })

weights_arr = np.asarray(weights, dtype=float)
att_weighted = float(np.sum(weights_arr * np.asarray(att_values)) / np.sum(weights_arr))
estimates.append({
    'term': 'att_weighted',
    'estimate': att_weighted,
    'se': None,
    'n_obs': int(total_rows),
})

output = {
    'task_id': 'broad_cohort_stack',
    'platform': 'python',
    'estimates': estimates,
    'method_metadata': {},
    'diagnostics': {},
}

with open('result.json', 'w') as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
