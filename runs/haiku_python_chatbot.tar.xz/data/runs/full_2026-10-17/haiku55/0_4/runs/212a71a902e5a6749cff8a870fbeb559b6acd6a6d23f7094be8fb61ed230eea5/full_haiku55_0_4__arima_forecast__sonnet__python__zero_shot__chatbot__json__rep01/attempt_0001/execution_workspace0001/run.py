import json

import numpy as np
import pandas as pd
from statsmodels.tsa.arima.model import ARIMA

df = pd.read_csv("./input.csv")
df = df.dropna(subset=["t", "y"]).sort_values("t")
df = df[df["t"] <= 250]
y = df["y"].astype(float).reset_index(drop=True)
n_obs = int(len(y))
last_t = int(df["t"].iloc[-1])
steps = 251 - last_t

res = ARIMA(y, order=(1, 1, 1), trend="n").fit()

fc = res.get_forecast(steps=steps)
forecast = float(np.asarray(fc.predicted_mean)[-1])
se = float(np.sqrt(np.asarray(fc.var_pred_mean)[-1]))
ci = np.asarray(fc.conf_int(alpha=0.05))[-1]
lower_95 = float(ci[0])
upper_95 = float(ci[1])

mle = getattr(res, "mle_retvals", None)
converged = bool(mle.get("converged", True)) if isinstance(mle, dict) else True

result = {
    "task_id": "arima_forecast",
    "platform": "python",
    "estimates": [
        {"term": "forecast", "estimate": forecast, "se": se, "n_obs": n_obs},
        {"term": "lower_95", "estimate": lower_95, "se": None, "n_obs": n_obs},
        {"term": "upper_95", "estimate": upper_95, "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "ARIMA(1,1,1) exact maximum likelihood via statsmodels, no constant",
        "vcov": "outer product of gradients (statsmodels default for ARIMA MLE)",
    },
    "diagnostics": {
        "converged": converged,
        "aic": float(res.aic),
        "bic": float(res.bic),
        "loglikelihood": float(res.llf),
        "ar1": float(res.params.get("ar.L1", np.nan)),
        "ma1": float(res.params.get("ma.L1", np.nan)),
        "sigma2": float(res.params.get("sigma2", np.nan)),
        "forecast_steps": int(steps),
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
