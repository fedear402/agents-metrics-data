import json

import numpy as np
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("input.csv")
n_obs = int(len(df))

X = sm.add_constant(df[["x", "z"]].astype(float))
model = sm.MNLogit(df["y"].astype(int), X)
res = model.fit(method="newton", maxiter=500, disp=0, tol=1e-10)

P = res.params.values  # rows: const, x, z; columns: outcome 1, outcome 2
V = np.asarray(res.cov_params().values, dtype=float)  # equation-major: [1:const,x,z, 2:const,x,z]

b_x1, b_z1 = P[1, 0], P[2, 0]
b_x2, b_z2 = P[1, 1], P[2, 1]
se_x1, se_z1 = np.sqrt(V[1, 1]), np.sqrt(V[2, 2])
se_x2, se_z2 = np.sqrt(V[4, 4]), np.sqrt(V[5, 5])

e1 = np.exp(P[0, 0])
e2 = np.exp(P[0, 1])
D = 1.0 + e1 + e2
p1 = e1 / D
p2 = e2 / D
prob_cat2_zero = p2

g = np.zeros(V.shape[0])
g[0] = -p2 * p1
g[3] = p2 * (1.0 - p2)
se_prob = float(np.sqrt(g @ V @ g))

result = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": [
        {"term": "x_cat1", "estimate": float(b_x1), "se": float(se_x1), "n_obs": n_obs},
        {"term": "z_cat1", "estimate": float(b_z1), "se": float(se_z1), "n_obs": n_obs},
        {"term": "x_cat2", "estimate": float(b_x2), "se": float(se_x2), "n_obs": n_obs},
        {"term": "z_cat2", "estimate": float(b_z2), "se": float(se_z2), "n_obs": n_obs},
        {"term": "prob_cat2_zero", "estimate": float(prob_cat2_zero), "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "multinomial logit maximum likelihood (statsmodels MNLogit, base outcome 0)",
        "vcov": "conventional observed-information (inverse of negative Hessian)",
    },
    "diagnostics": {
        "converged": bool(res.mle_retvals.get("converged", True)) if getattr(res, "mle_retvals", None) else True,
        "log_likelihood": float(res.llf),
        "prob_cat2_zero_se_delta_method": se_prob,
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
