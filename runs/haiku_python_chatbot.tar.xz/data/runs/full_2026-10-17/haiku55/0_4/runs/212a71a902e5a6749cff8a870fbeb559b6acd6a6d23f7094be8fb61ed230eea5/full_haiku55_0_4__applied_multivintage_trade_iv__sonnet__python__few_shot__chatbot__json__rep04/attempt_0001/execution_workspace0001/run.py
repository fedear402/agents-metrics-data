import json

import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS

crosswalk = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv")
areas = pd.read_csv("areas.csv")
emp = pd.read_csv("employment.csv")
outcomes = pd.read_csv("outcomes.csv")

tr = trade.merge(crosswalk, on="code", how="inner")
tr = tr.drop_duplicates(["period", "industry"])
periods = sorted(tr["period"].unique())
inds = sorted(tr["industry"].unique())

areas_idx = pd.MultiIndex.from_frame(areas[["area", "period", "vintage"]])
emp_w = (
    emp.groupby(["area", "period", "vintage", "industry"])["employment"]
    .sum()
    .unstack("industry", fill_value=0)
    .reindex(columns=inds, fill_value=0)
    .reindex(areas_idx, fill_value=0)
)
nat_emp = emp_w.groupby(level=["period", "vintage"]).sum()


def exposure(vintage, col):
    parts = []
    for p in periods:
        t = tr[tr["period"] == p].set_index("industry")
        chg = t.loc[inds, col].to_numpy(float)
        nat = nat_emp.loc[(p, vintage), inds].to_numpy(float)
        price = float(t["price_index"].iloc[0])
        years = float(t["years"].iloc[0])
        shock = chg / nat / (price / 100) / 1000 * (10 / years)
        E = emp_w.xs((p, vintage), level=["period", "vintage"])
        tot = (
            areas[(areas["period"] == p) & (areas["vintage"] == vintage)]
            .set_index("area")["total_employment"]
            .reindex(E.index)
            .to_numpy(float)
        )
        x = E[inds].to_numpy(float) @ shock / tot
        parts.append(pd.DataFrame({"area": E.index, "period": p, "val": x}))
    return pd.concat(parts, ignore_index=True)


x_df = exposure("base", "us_change").rename(columns={"val": "x"})
z_df = exposure("early", "other_change").rename(columns={"val": "z"})
pop = areas[areas["vintage"] == "base"][["area", "period", "population"]]

panel = (
    outcomes.merge(pop, on=["area", "period"])
    .merge(x_df, on=["area", "period"])
    .merge(z_df, on=["area", "period"])
    .reset_index(drop=True)
)
n_obs = int(len(panel))

dep = panel["change_pp"].astype(float)
exog = pd.DataFrame(
    {
        "const": 1.0,
        "period": pd.to_numeric(panel["period"]).astype(float),
        "control": panel["control"].astype(float),
    },
    index=panel.index,
)
endog = panel[["x"]].astype(float)
instruments = panel[["z"]].astype(float)
weights = panel["population"].astype(float)

fit = IV2SLS(dep, exog, endog, instruments, weights=weights).fit()
iv_slope = float(fit.params["x"])

area0 = panel["area"].astype(str) == "0"
ex0 = panel.loc[area0 & (panel["period"] == periods[0]), "x"].iloc[0]
ex1 = panel.loc[area0 & (panel["period"] == periods[1]), "x"].iloc[0]
iv0 = panel.loc[area0 & (panel["period"] == periods[0]), "z"].iloc[0]

estimates = [
    {"term": "iv_slope", "estimate": iv_slope, "se": None, "n_obs": n_obs},
    {"term": "exposure_area0_period0", "estimate": float(ex0), "se": None, "n_obs": n_obs},
    {"term": "exposure_area0_period1", "estimate": float(ex1), "se": None, "n_obs": n_obs},
    {"term": "instrument_area0_period0", "estimate": float(iv0), "se": None, "n_obs": n_obs},
]

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "dependent": "change_pp",
        "exogenous": ["intercept", "period", "control"],
        "endogenous": ["x"],
        "instruments": ["z"] + ["intercept", "period", "control"],
        "weights": "base-vintage population",
        "exposure_denominator": "base or early total_employment by vintage",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "n_industries": int(len(inds)),
        "n_periods": int(len(periods)),
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
