import json

import numpy as np
import pandas as pd


def estimate_cohort(df, c):
    lo, hi = c - 2, c + 2
    n_window = hi - lo + 1

    sub = df[(df["time"] >= lo) & (df["time"] <= hi)]
    eligible = (sub["g"] == c) | (sub["g"] == 0) | (sub["g"] > c + 2)
    sub = sub[eligible]

    times_per_unit = sub.groupby("id")["time"].nunique()
    full_ids = times_per_unit[times_per_unit == n_window].index
    sub = sub[sub["id"].isin(full_ids)].copy()

    sub["did"] = ((sub["g"] == c) & (sub["time"] >= c)).astype(float)
    n_treated = int(sub.loc[sub["g"] == c, "id"].nunique())

    uid = pd.Categorical(sub["id"]).codes
    tid = pd.Categorical(sub["time"]).codes
    n_units = uid.max() + 1
    n_times = tid.max() + 1

    unit_dummies = np.eye(n_units)[uid][:, 1:]
    time_dummies = np.eye(n_times)[tid][:, 1:]
    X = np.column_stack(
        [np.ones(len(sub)), sub["did"].values, unit_dummies, time_dummies]
    )
    y = sub["y"].values.astype(float)

    beta = np.linalg.lstsq(X, y, rcond=None)[0]
    return float(beta[1]), int(len(sub)), n_treated


def main():
    df = pd.read_csv("input.csv")
    df = df[["id", "time", "g", "y"]]

    estimates = []
    cohort_results = {}
    for c in (3, 5, 7):
        att, n_obs, n_treated = estimate_cohort(df, c)
        cohort_results[c] = (att, n_obs, n_treated)
        estimates.append(
            {"term": f"att_g{c}", "estimate": att, "se": None, "n_obs": n_obs}
        )

    total_weight = sum(v[2] for v in cohort_results.values())
    att_weighted = (
        sum(v[0] * v[2] for v in cohort_results.values()) / total_weight
    )
    total_obs = sum(v[1] for v in cohort_results.values())

    estimates.append(
        {
            "term": "att_weighted",
            "estimate": float(att_weighted),
            "se": None,
            "n_obs": int(total_obs),
        }
    )

    result = {
        "task_id": "broad_cohort_stack",
        "platform": "python",
        "estimates": estimates,
        "method_metadata": {},
        "diagnostics": {},
    }

    with open("result.json", "w") as f:
        json.dump(result, f, indent=2)


if __name__ == "__main__":
    main()
