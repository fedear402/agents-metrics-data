import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df = df[np.abs(df["score"]) < 1].copy()

s = df["score"].to_numpy(dtype=float)
w = 1.0 - np.abs(s)
y_e = df["earnings"].to_numpy(dtype=float)
d = df["participated"].to_numpy(dtype=float)
right = (s >= 0).astype(float)
left = 1.0 - right

X = np.column_stack([
    right,
    left,
    right * s,
    left * s,
])

XtWX = X.T @ (w[:, None] * X)
bread = np.linalg.inv(XtWX)

Y = np.column_stack([y_e, d])
B = bread @ X.T @ (w[:, None] * Y)
resid = Y - X @ B

contrast = np.array([1.0, -1.0, 0.0, 0.0])
jumps = contrast @ B
reduced_form, first_stage = jumps[0], jumps[1]

loading = w * (X @ bread @ contrast)
influence = loading[:, None] * resid
V = influence.T @ influence

se_rf = float(np.sqrt(V[0, 0]))
se_fs = float(np.sqrt(V[1, 1]))

treatment_effect = reduced_form / first_stage
grad = np.array([1.0 / first_stage, -reduced_form / first_stage**2])
se_te = float(np.sqrt(grad @ V @ grad))

n_obs = int(len(df))

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": float(treatment_effect), "se": se_te, "n_obs": n_obs},
        {"term": "reduced_form", "estimate": float(reduced_form), "se": se_rf, "n_obs": n_obs},
        {"term": "first_stage", "estimate": float(first_stage), "se": se_fs, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "Fuzzy RD, local linear with separate slopes per side, triangular kernel, bandwidth 1, cutoff 0",
        "vcov": "HC0 sandwich, no degrees-of-freedom correction, delta method for ratio",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2, allow_nan=False)
