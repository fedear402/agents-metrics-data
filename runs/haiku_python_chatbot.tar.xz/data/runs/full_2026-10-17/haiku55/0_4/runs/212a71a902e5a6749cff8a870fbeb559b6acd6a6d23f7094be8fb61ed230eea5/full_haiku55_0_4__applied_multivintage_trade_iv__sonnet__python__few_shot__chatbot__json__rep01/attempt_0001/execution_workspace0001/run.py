import json

import numpy as np
import pandas as pd

crosswalk = pd.read_csv("crosswalk.csv", dtype={"code": str, "industry": str})
trade = pd.read_csv("trade.csv", dtype={"code": str})
areas = pd.read_csv("areas.csv", dtype={"vintage": str})
employment = pd.read_csv("employment.csv", dtype={"vintage": str, "industry": str})
outcomes = pd.read_csv("outcomes.csv")

trade = trade.merge(crosswalk, on="code", how="inner")
industries = sorted(trade["industry"].unique())
periods = sorted(areas["period"].unique())

emp = employment[employment["industry"].isin(industries)]
emp = emp.groupby(["area", "period", "vintage", "industry"], as_index=False)["employment"].sum()

grid = areas[["area", "period", "vintage"]].drop_duplicates().merge(
    pd.DataFrame({"industry": industries}), how="cross"
)
emp_full = grid.merge(emp, on=["area", "period", "vintage", "industry"], how="left")
emp_full["employment"] = emp_full["employment"].fillna(0.0)

national = (
    emp_full.groupby(["period", "vintage", "industry"], as_index=False)["employment"].sum()
    .rename(columns={"employment": "national"})
)


def exposure(vintage, change_col):
    e = emp_full[emp_full["vintage"] == vintage]
    e = e.merge(national[national["vintage"] == vintage], on=["period", "vintage", "industry"])
    e = e.merge(
        areas.loc[areas["vintage"] == vintage, ["area", "period", "total_employment"]],
        on=["area", "period"],
    )
    e = e.merge(
        trade[["period", "industry", change_col, "price_index", "years"]],
        on=["period", "industry"],
    )
    e["term"] = (
        e["employment"] / e["total_employment"]
        * e[change_col] / e["national"]
        / (e["price_index"] / 100) / 1000 * (10 / e["years"])
    )
    return e.groupby(["area", "period"])["term"].sum()


x = exposure("base", "us_change").rename("x")
z = exposure("early", "other_change").rename("z")
population = areas.loc[areas["vintage"] == "base", ["area", "period", "population"]]

df = (
    outcomes.merge(x.reset_index(), on=["area", "period"])
    .merge(z.reset_index(), on=["area", "period"])
    .merge(population, on=["area", "period"])
    .sort_values(["area", "period"])
    .reset_index(drop=True)
)

n_obs = int(len(df))
y = df["change_pp"].to_numpy(float)
exog = np.column_stack([
    np.ones(n_obs),
    df["period"].to_numpy(float),
    df["control"].to_numpy(float),
])
endog = df["x"].to_numpy(float)[:, None]
instr = np.column_stack([exog, df["z"].to_numpy(float)])

sw = np.sqrt(df["population"].to_numpy(float))
X = np.column_stack([exog, endog]) * sw[:, None]
Z = instr * sw[:, None]
yw = y * sw

fitted = Z @ np.linalg.lstsq(Z, X, rcond=None)[0]
beta = np.linalg.lstsq(fitted, yw, rcond=None)[0]
iv_slope = float(beta[-1])

area0 = next(a for a in areas["area"].unique() if str(a) == "0")
p0, p1 = periods[0], periods[1]
exposure_area0_period0 = float(x.loc[(area0, p0)])
exposure_area0_period1 = float(x.loc[(area0, p1)])
instrument_area0_period0 = float(z.loc[(area0, p0)])

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [
        {"term": "iv_slope", "estimate": iv_slope, "se": None, "n_obs": n_obs},
        {"term": "exposure_area0_period0", "estimate": exposure_area0_period0, "se": None, "n_obs": n_obs},
        {"term": "exposure_area0_period1", "estimate": exposure_area0_period1, "se": None, "n_obs": n_obs},
        {"term": "instrument_area0_period0", "estimate": instrument_area0_period0, "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "population-weighted 2SLS",
        "outcome": "change_pp",
        "exogenous_regressors": ["intercept", "period", "control"],
        "endogenous_regressor": "x",
        "instruments": ["intercept", "period", "control", "z"],
        "regression_weight": "base-vintage population",
        "exposure_units": "thousands of real dollars per worker per decade",
        "standard_errors": "not computed",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "n_areas": int(areas["area"].nunique()),
        "n_periods": int(len(periods)),
        "n_industries": int(len(industries)),
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
