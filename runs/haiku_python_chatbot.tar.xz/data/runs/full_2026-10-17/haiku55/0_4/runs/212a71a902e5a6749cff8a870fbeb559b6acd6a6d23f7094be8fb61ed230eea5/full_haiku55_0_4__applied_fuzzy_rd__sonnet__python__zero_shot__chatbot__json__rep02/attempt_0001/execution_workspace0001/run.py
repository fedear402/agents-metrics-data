import numpy as np
import pandas as pd
import json

df = pd.read_csv("input.csv")
s = df["score"].to_numpy(dtype=float)
d = df["participated"].to_numpy(dtype=float)
y = df["earnings"].to_numpy(dtype=float)

m = np.abs(s) < 1
s, d, y = s[m], d[m], y[m]
n = int(len(s))

w = 1.0 - np.abs(s)
R = (s >= 0).astype(float)
L = 1.0 - R
X = np.column_stack([L, R, s * L, s * R])

XtWX = X.T @ (X * w[:, None])
M = np.linalg.inv(XtWX)
bY = M @ (X.T @ (w * y))
bD = M @ (X.T @ (w * d))
eY = y - X @ bY
eD = d - X @ bD

c = np.array([-1.0, 1.0, 0.0, 0.0])
u = w * (X @ (M @ c))

RF = float(c @ bY)
FS = float(c @ bD)
varRF = float(np.sum(u**2 * eY**2))
varFS = float(np.sum(u**2 * eD**2))
covRF_FS = float(np.sum(u**2 * eY * eD))

TE = RF / FS
g = np.array([1.0 / FS, -RF / FS**2])
V = np.array([[varRF, covRF_FS], [covRF_FS, varFS]])
seTE = float(np.sqrt(g @ V @ g))

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": float(TE), "se": seTE, "n_obs": n},
        {"term": "reduced_form", "estimate": RF, "se": float(np.sqrt(varRF)), "n_obs": n},
        {"term": "first_stage", "estimate": FS, "se": float(np.sqrt(varFS)), "n_obs": n},
    ],
    "method_metadata": {
        "estimator": "Fuzzy RD, local linear with separate slopes per side, triangular kernel, cutoff 0, bandwidth 1, ratio of discontinuities (delta method)",
        "vcov": "HC0 heteroskedasticity-robust sandwich, no dof correction, joint covariance of reduced form and first stage, delta method for ratio",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
