import json

import numpy as np
import pandas as pd


def side_fit(sub, y):
    X = np.column_stack([np.ones(len(sub)), sub["score"].to_numpy()])
    w = sub["w"].to_numpy()
    yv = sub[y].to_numpy(dtype=float)
    bread = np.linalg.inv(X.T @ (X * w[:, None]))
    beta = bread @ (X.T @ (w * yv))
    e = yv - X @ beta
    if_intercept = (X @ bread[:, 0]) * w * e
    return beta[0], if_intercept


df = pd.read_csv("input.csv")
d = df[df["score"].abs() < 1].copy()
d["w"] = 1 - d["score"].abs()
n = len(d)

is_right = (d["score"] >= 0).to_numpy()
right = d[is_right]
left = d[~is_right]

influence = {}
intercepts = {}
for y in ["earnings", "participated"]:
    bR, ifR = side_fit(right, y)
    bL, ifL = side_fit(left, y)
    g = np.zeros(n)
    g[is_right] = ifR
    g[~is_right] = -ifL
    influence[y] = g
    intercepts[y] = bR - bL

G = np.column_stack([influence["earnings"], influence["participated"]])
V = G.T @ G

rf = intercepts["earnings"]
fs = intercepts["participated"]
se_rf = float(np.sqrt(V[0, 0]))
se_fs = float(np.sqrt(V[1, 1]))

tau = rf / fs
grad = np.array([1.0 / fs, -rf / fs**2])
se_tau = float(np.sqrt(grad @ V @ grad))

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": float(tau), "se": se_tau, "n_obs": int(n)},
        {"term": "reduced_form", "estimate": float(rf), "se": se_rf, "n_obs": int(n)},
        {"term": "first_stage", "estimate": float(fs), "se": se_fs, "n_obs": int(n)},
    ],
    "method_metadata": {
        "estimator": "Fuzzy RD, local linear, triangular kernel, bandwidth 1, cutoff 0",
        "vcov": "HC0 sandwich per side, delta method for ratio with joint covariance",
    },
    "diagnostics": {
        "bandwidth": 1.0,
        "cutoff": 0.0,
        "n_left": int(len(left)),
        "n_right": int(len(right)),
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
