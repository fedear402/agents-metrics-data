import json

import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
d = df[np.abs(df["score"]) < 1].copy()

s = d["score"].to_numpy(dtype=float)
w = 1.0 - np.abs(s)
right = (s >= 0).astype(float)
left = 1.0 - right
X = np.column_stack([left, s * left, right, s * right])
n_obs = int(len(d))

y_earn = d["earnings"].to_numpy(dtype=float)
y_part = d["participated"].to_numpy(dtype=float)

XtWX = X.T @ (X * w[:, None])
B = np.linalg.inv(XtWX)


def wls(y):
    beta = B @ (X.T @ (w * y))
    resid = y - X @ beta
    return beta, resid


b_e, e_e = wls(y_earn)
b_p, e_p = wls(y_part)

g = np.array([-1.0, 0.0, 1.0, 0.0])

meat_ee = X.T @ (X * (w**2 * e_e * e_e)[:, None])
meat_pp = X.T @ (X * (w**2 * e_p * e_p)[:, None])
meat_ep = X.T @ (X * (w**2 * e_e * e_p)[:, None])

rf = float(g @ b_e)
fs = float(g @ b_p)

var_rf = float(g @ B @ meat_ee @ B @ g)
var_fs = float(g @ B @ meat_pp @ B @ g)
cov_rf_fs = float(g @ B @ meat_ep @ B @ g)

tau = rf / fs
var_tau = (
    (1.0 / fs**2) * var_rf
    + (rf**2 / fs**4) * var_fs
    - 2.0 * rf / fs**3 * cov_rf_fs
)
se_tau = float(np.sqrt(max(var_tau, 0.0)))
se_rf = float(np.sqrt(max(var_rf, 0.0)))
se_fs = float(np.sqrt(max(var_fs, 0.0)))

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": float(tau), "se": se_tau, "n_obs": n_obs},
        {"term": "reduced_form", "estimate": rf, "se": se_rf, "n_obs": n_obs},
        {"term": "first_stage", "estimate": fs, "se": se_fs, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "Fuzzy RD, local linear with separate slopes and intercepts, triangular kernel, cutoff 0, bandwidth 1, Wald ratio of discontinuities",
        "vcov": "HC0 heteroskedasticity-robust sandwich (no dof correction), joint covariance across outcomes with delta method for treatment_effect",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
