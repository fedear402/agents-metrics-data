import json

import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS

households = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

d = households[households["recipient"] == 0].copy()
e = d["eligible"].astype(float)
ne = 1.0 - e

d["one_ne"] = ne
d["one_e"] = e
d["base_ne"] = d["baseline"] * ne
d["base_e"] = d["baseline"] * e
d["dose_ne"] = d["dose"] * ne
d["dose_e"] = d["dose"] * e
d["inst_ne"] = d["instrument"] * ne
d["inst_e"] = d["instrument"] * e

y = d["outcome"]
exog = d[["one_ne", "one_e", "base_ne", "base_e"]]
endog = d[["dose_ne", "dose_e"]]
instruments = d[["one_ne", "one_e", "base_ne", "base_e", "inst_ne", "inst_e"]]

fit = IV2SLS(y, exog, endog, instruments, weights=d["weight"]).fit()

mask_ne = d["eligible"].values == 0
mask_e = d["eligible"].values == 1

mean_dose_ne = np.average(d.loc[mask_ne, "dose"], weights=d.loc[mask_ne, "weight"])
mean_dose_e = np.average(d.loc[mask_e, "dose"], weights=d.loc[mask_e, "weight"])

slope_ne = float(fit.params["dose_ne"])
slope_e = float(fit.params["dose_e"])

ineligible_effect = float(slope_ne * mean_dose_ne)
eligible_nonrecipient_effect = float(slope_e * mean_dose_e)

pop = census.set_index("eligible")["nonrecipient_population"]
pop_weights = [float(pop.loc[0]), float(pop.loc[1])]
population_effect = float(
    np.average([ineligible_effect, eligible_nonrecipient_effect], weights=pop_weights)
)

n_obs = int(len(d))

estimates = [
    {"term": "ineligible_effect", "estimate": ineligible_effect, "se": None, "n_obs": n_obs},
    {
        "term": "eligible_nonrecipient_effect",
        "estimate": eligible_nonrecipient_effect,
        "se": None,
        "n_obs": n_obs,
    },
    {"term": "population_effect", "estimate": population_effect, "se": None, "n_obs": n_obs},
]

method_metadata = {
    "estimator": "weighted two-stage least squares",
    "software": "linearmodels.iv.IV2SLS",
    "sample": "households with recipient == 0, both village treatment statuses",
    "endogenous": ["dose*(1-eligible)", "dose*eligible"],
    "exogenous": ["1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"],
    "instruments": [
        "1-eligible",
        "eligible",
        "baseline*(1-eligible)",
        "baseline*eligible",
        "instrument*(1-eligible)",
        "instrument*eligible",
    ],
    "regression_weight": "weight",
    "group_effect": "fitted dose slope times household-weighted mean dose in group",
    "population_aggregation": "nonrecipient_population from census.csv",
    "counterfactual": "dose set to zero for every retained household (synthetic convention)",
}

diagnostics = {
    "n_obs": n_obs,
    "n_ineligible_obs": int(mask_ne.sum()),
    "n_eligible_obs": int(mask_e.sum()),
    "dose_slope_ineligible": slope_ne,
    "dose_slope_eligible": slope_e,
    "weighted_mean_dose_ineligible": float(mean_dose_ne),
    "weighted_mean_dose_eligible": float(mean_dose_e),
    "population_weights": pop_weights,
}

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": method_metadata,
    "diagnostics": diagnostics,
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
