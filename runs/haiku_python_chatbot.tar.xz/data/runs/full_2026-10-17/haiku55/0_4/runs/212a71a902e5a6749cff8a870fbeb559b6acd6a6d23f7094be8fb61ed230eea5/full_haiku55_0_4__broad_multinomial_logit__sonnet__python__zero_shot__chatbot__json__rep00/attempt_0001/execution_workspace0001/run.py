import json

import numpy as np
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("input.csv")
df["y"] = df["y"].astype(int)
n_obs = int(len(df))

X = sm.add_constant(df[["x", "z"]].astype(float))
model = sm.MNLogit(df["y"], X)
res = model.fit(method="newton", maxiter=500, disp=0, full_output=True)

params = res.params
bse = res.bse

a1 = float(params.loc["const", 1])
a2 = float(params.loc["const", 2])
denom = 1.0 + np.exp(a1) + np.exp(a2)
prob_cat2_zero = float(np.exp(a2) / denom)

result = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": [
        {
            "term": "x_cat1",
            "estimate": float(params.loc["x", 1]),
            "se": float(bse.loc["x", 1]),
            "n_obs": n_obs,
        },
        {
            "term": "z_cat1",
            "estimate": float(params.loc["z", 1]),
            "se": float(bse.loc["z", 1]),
            "n_obs": n_obs,
        },
        {
            "term": "x_cat2",
            "estimate": float(params.loc["x", 2]),
            "se": float(bse.loc["x", 2]),
            "n_obs": n_obs,
        },
        {
            "term": "z_cat2",
            "estimate": float(params.loc["z", 2]),
            "se": float(bse.loc["z", 2]),
            "n_obs": n_obs,
        },
        {
            "term": "prob_cat2_zero",
            "estimate": prob_cat2_zero,
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "Multinomial logit (maximum likelihood, base outcome 0, statsmodels MNLogit)",
        "vcov": "Conventional observed-information (inverse negative Hessian)",
    },
    "diagnostics": {
        "converged": bool(res.mle_retvals.get("converged", True)),
        "log_likelihood": float(res.llf),
        "pseudo_r2_mcfadden": float(res.prsquared),
        "n_obs": n_obs,
        "outcome_levels": [int(c) for c in params.columns],
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
