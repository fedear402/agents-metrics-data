import json

import numpy as np
import pandas as pd


def read(name):
    df = pd.read_csv(name, dtype=str)
    for c in df.columns:
        df[c] = df[c].str.strip()
    return df


cw = read("crosswalk.csv")
tr = read("trade.csv")
ar = read("areas.csv")
em = read("employment.csv")
oc = read("outcomes.csv")

for c in ["us_change", "other_change", "price_index", "years"]:
    tr[c] = tr[c].astype(float)
tr = tr.merge(cw[["code", "industry"]], on="code", how="inner")

ar["total_employment"] = ar["total_employment"].astype(float)
ar["population"] = ar["population"].astype(float)
em["employment"] = em["employment"].astype(float)
oc["change_pp"] = oc["change_pp"].astype(float)
oc["control"] = oc["control"].astype(float)

industries = sorted(cw["industry"].unique())
periods = sorted(oc["period"].unique())
pidx = {p: i for i, p in enumerate(periods)}

trp = tr.groupby("period").agg(price=("price_index", "first"), years=("years", "first"))
uschg = {(r.period, r.industry): r.us_change for r in tr.itertuples()}
othchg = {(r.period, r.industry): r.other_change for r in tr.itertuples()}

emp = em.groupby(["vintage", "area", "period", "industry"])["employment"].sum().to_dict()
natd = em.groupby(["vintage", "period", "industry"])["employment"].sum().to_dict()
tot = ar.groupby(["vintage", "area", "period"])["total_employment"].sum().to_dict()
popdf = (
    ar[ar["vintage"] == "base"]
    .groupby(["area", "period"])["population"]
    .sum()
    .reset_index()
)

est = oc.merge(popdf, on=["area", "period"], how="inner").reset_index(drop=True)
n = len(est)


def expo(vint, chg, a, p):
    total = tot[(vint, a, p)]
    price = trp.loc[p, "price"]
    yrs = trp.loc[p, "years"]
    s = 0.0
    for j in industries:
        e = emp.get((vint, a, p, j), 0.0)
        nat = natd.get((vint, p, j), 0.0)
        s += (e / total) * (chg[(p, j)] / nat)
    return s / (price / 100.0) / 1000.0 * (10.0 / yrs)


x = np.array([expo("base", uschg, a, p) for a, p in zip(est["area"], est["period"])])
z = np.array([expo("early", othchg, a, p) for a, p in zip(est["area"], est["period"])])

y = est["change_pp"].values
w = est["population"].values
period_idx = np.array([pidx[p] for p in est["period"]], dtype=float)
control = est["control"].values

X = np.column_stack([np.ones(n), period_idx, control, x])
Z = np.column_stack([np.ones(n), period_idx, control, z])

sw = np.sqrt(w)
Xw = X * sw[:, None]
Zw = Z * sw[:, None]
yw = y * sw

gamma = np.linalg.lstsq(Zw, Xw, rcond=None)[0]
Xhat = Zw @ gamma
beta = np.linalg.lstsq(Xhat, yw, rcond=None)[0]
iv_slope = float(beta[3])

areas_set = set(est["area"])
a0 = "0" if "0" in areas_set else sorted(areas_set)[0]
p0, p1 = periods[0], periods[1]

exposure_area0_period0 = expo("base", uschg, a0, p0)
exposure_area0_period1 = expo("base", uschg, a0, p1)
instrument_area0_period0 = expo("early", othchg, a0, p0)

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [
        {"term": "iv_slope", "estimate": iv_slope, "se": None, "n_obs": int(n)},
        {"term": "exposure_area0_period0", "estimate": float(exposure_area0_period0), "se": None, "n_obs": int(n)},
        {"term": "exposure_area0_period1", "estimate": float(exposure_area0_period1), "se": None, "n_obs": int(n)},
        {"term": "instrument_area0_period0", "estimate": float(instrument_area0_period0), "se": None, "n_obs": int(n)},
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "outcome": "change_pp",
        "endogenous": "x",
        "instrument": "z",
        "exogenous": ["intercept", "period", "control"],
        "weight": "base-vintage population",
        "weighting_transform": "sqrt(weight) pre-multiplication",
    },
    "diagnostics": {
        "n_obs": int(n),
        "periods": periods,
        "industries": industries,
        "area0": a0,
        "sum_weights": float(np.sum(w)),
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
