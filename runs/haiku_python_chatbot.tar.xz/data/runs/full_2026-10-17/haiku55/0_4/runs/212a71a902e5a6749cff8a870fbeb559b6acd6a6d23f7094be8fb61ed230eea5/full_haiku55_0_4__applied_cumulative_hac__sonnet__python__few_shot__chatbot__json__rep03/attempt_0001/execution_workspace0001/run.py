import json

import numpy as np
import pandas as pd

LAGS = 15

df = pd.read_csv("input.csv")
df["date"] = pd.to_datetime(df["date"])
df = df.sort_values("date").reset_index(drop=True)

df["vol_change"] = np.log(df["vix"]).diff()
lag_cols = [f"lag_{k}" for k in range(1, LAGS + 1)]
for k, col in enumerate(lag_cols, start=1):
    df[col] = df["vol_change"].shift(k)
df["log_sales"] = np.log(df["sales"])

sample = df.dropna(subset=["log_sales"] + lag_cols)
N = len(sample)
X = np.column_stack([np.ones(N), sample[lag_cols].to_numpy()])
y = sample["log_sales"].to_numpy()

beta = np.linalg.lstsq(X, y, rcond=None)[0]
resid = y - X @ beta

scores = X * resid[:, None]
meat = scores.T @ scores
for j in range(1, LAGS + 1):
    weight = 1 - j / (LAGS + 1)
    gamma = scores[j:].T @ scores[:-j]
    meat += weight * (gamma + gamma.T)

bread = np.linalg.inv(X.T @ X)
p = X.shape[1]
V = (N / (N - p)) * bread @ meat @ bread

contrast = np.zeros(p)
contrast[1:] = 1.0
cumulative = float(contrast @ beta)
cumulative_se = float(np.sqrt(contrast @ V @ contrast))


def finite_or_none(value):
    value = float(value)
    return value if np.isfinite(value) else None


rows = [
    {
        "term": "cumulative_response",
        "estimate": finite_or_none(cumulative),
        "se": finite_or_none(cumulative_se),
        "n_obs": int(N),
    },
    {
        "term": "lag_1",
        "estimate": finite_or_none(beta[1]),
        "se": finite_or_none(np.sqrt(V[1, 1])),
        "n_obs": int(N),
    },
    {
        "term": "lag_15",
        "estimate": finite_or_none(beta[LAGS]),
        "se": finite_or_none(np.sqrt(V[LAGS, LAGS])),
        "n_obs": int(N),
    },
]

output = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": rows,
    "method_metadata": {
        "estimator": "OLS of log(sales) on intercept and 15 lags of log(vix) first differences",
        "vcov": "Newey-West HAC, max lag 15, Bartlett weights 1-j/16, scaled by N/(N-16)",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
