import json

import numpy as np
import pandas as pd


def load(name, key_cols=()):
    df = pd.read_csv(name)
    df.columns = [c.strip() for c in df.columns]
    for c in df.columns:
        if df[c].dtype == object:
            df[c] = df[c].astype(str).str.strip()
    for c in key_cols:
        df[c] = df[c].astype(str).str.strip()
    return df


cw = load("crosswalk.csv", ["code", "industry"])
trade = load("trade.csv", ["period", "code"])
areas = load("areas.csv", ["area", "period", "vintage"])
emp = load("employment.csv", ["area", "period", "vintage", "industry"])
out = load("outcomes.csv", ["area", "period"])

for c in ["us_change", "other_change", "price_index", "years"]:
    trade[c] = pd.to_numeric(trade[c])
for c in ["total_employment", "population"]:
    areas[c] = pd.to_numeric(areas[c])
emp["employment"] = pd.to_numeric(emp["employment"])
out["control"] = pd.to_numeric(out["control"])
out["change_pp"] = pd.to_numeric(out["change_pp"])

tr = trade.merge(cw[["code", "industry"]], on="code", how="inner")

periods = sorted(areas["period"].unique())
area_list = sorted(areas["area"].unique())
industries = sorted(cw["industry"].unique())
pidx = {p: i for i, p in enumerate(periods)}

price = tr.groupby("period")["price_index"].first().to_dict()
years = tr.groupby("period")["years"].first().to_dict()
us_d = tr.set_index(["period", "industry"])["us_change"].to_dict()
oth_d = tr.set_index(["period", "industry"])["other_change"].to_dict()

idx = pd.MultiIndex.from_product(
    [["base", "early"], periods, area_list, industries],
    names=["vintage", "period", "area", "industry"],
)
E_s = (
    emp.groupby(["vintage", "period", "area", "industry"])["employment"]
    .sum()
    .reindex(idx, fill_value=0.0)
)
E = E_s.to_dict()
Nat = E_s.groupby(level=["vintage", "period", "industry"]).sum().to_dict()

TE = (
    areas.groupby(["vintage", "period", "area"])["total_employment"].sum().to_dict()
)
pop = areas[areas["vintage"] == "base"].set_index(["area", "period"])["population"].to_dict()
ctrl = out.set_index(["area", "period"])["control"].to_dict()
ychg = out.set_index(["area", "period"])["change_pp"].to_dict()


def exposure(vint, shock, p, a):
    total = 0.0
    te = TE[(vint, p, a)]
    for j in industries:
        share = E[(vint, p, a, j)] / te
        total += share * shock[(p, j)] / Nat[(vint, p, j)]
    return total / (price[p] / 100) / 1000 * (10 / years[p])


rows = []
for p in periods:
    for a in area_list:
        rows.append(
            {
                "area": a,
                "period": p,
                "pidx": float(pidx[p]),
                "y": ychg[(a, p)],
                "control": ctrl[(a, p)],
                "w": pop[(a, p)],
                "x": exposure("base", us_d, p, a),
                "z": exposure("early", oth_d, p, a),
            }
        )
D = pd.DataFrame(rows)
n_obs = int(len(D))

y = D["y"].to_numpy(dtype=float)
w = D["w"].to_numpy(dtype=float)
X = np.column_stack([np.ones(n_obs), D["pidx"], D["control"], D["x"]]).astype(float)
Z = np.column_stack([np.ones(n_obs), D["pidx"], D["control"], D["z"]]).astype(float)

ZW = Z * w[:, None]
ZtWZ_inv = np.linalg.inv(Z.T @ ZW)
XPX = X.T @ ZW @ ZtWZ_inv @ ZW.T @ X
XPy = X.T @ ZW @ ZtWZ_inv @ (Z.T @ (w * y))
beta = np.linalg.solve(XPX, XPy)

p0, p1 = periods[0], periods[1]
is_area0 = D["area"] == "0"
x_a0_p0 = float(D.loc[is_area0 & (D["period"] == p0), "x"].iloc[0])
x_a0_p1 = float(D.loc[is_area0 & (D["period"] == p1), "x"].iloc[0])
z_a0_p0 = float(D.loc[is_area0 & (D["period"] == p0), "z"].iloc[0])

estimates = [
    {"term": "iv_slope", "estimate": float(beta[3]), "se": None, "n_obs": n_obs},
    {"term": "exposure_area0_period0", "estimate": x_a0_p0, "se": None, "n_obs": n_obs},
    {"term": "exposure_area0_period1", "estimate": x_a0_p1, "se": None, "n_obs": n_obs},
    {"term": "instrument_area0_period0", "estimate": z_a0_p0, "se": None, "n_obs": n_obs},
]

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "weighted_2sls",
        "weights": "base_vintage_population",
        "endogenous": ["x"],
        "instruments": ["intercept", "period", "control", "z"],
        "exogenous_controls": ["intercept", "period", "control"],
        "se": "not_reported",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "n_areas": int(len(area_list)),
        "n_periods": int(len(periods)),
        "industries": [str(i) for i in industries],
        "coefficients": {
            "intercept": float(beta[0]),
            "period": float(beta[1]),
            "control": float(beta[2]),
            "x": float(beta[3]),
        },
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
