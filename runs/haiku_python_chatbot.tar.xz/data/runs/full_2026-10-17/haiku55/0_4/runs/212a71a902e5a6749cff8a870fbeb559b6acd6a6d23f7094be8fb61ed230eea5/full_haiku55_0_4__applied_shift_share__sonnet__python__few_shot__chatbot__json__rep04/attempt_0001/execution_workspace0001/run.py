import json

import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df["_sx"] = df["share"] * df["shock"]

reg = df.groupby("region_id").agg(
    region_weight=("region_weight", "first"),
    x=("x", "first"),
    y=("y", "first"),
)
reg["z"] = df.groupby("region_id")["_sx"].sum()
reg = reg.sort_index()

e = reg["region_weight"].to_numpy(float)
e = e / e.sum()

def wc(v):
    return v - e @ v

y0 = wc(reg["y"].to_numpy(float))
x0 = wc(reg["x"].to_numpy(float))
z0 = wc(reg["z"].to_numpy(float))

S = (
    df.pivot_table(index="region_id", columns="industry_id", values="share", aggfunc="sum")
    .reindex(index=reg.index)
    .fillna(0.0)
)
M = S.to_numpy(float)
industries = S.columns
shock = df.groupby("industry_id")["shock"].first().reindex(industries).to_numpy(float)

s = e @ M

def aggregate(v0):
    return (M.T @ (e * v0)) / s

ybar = aggregate(y0)
xbar = aggregate(x0)
zbar = aggregate(z0)

N = len(s)

def shock_iv(dep, endo):
    regressors = np.column_stack([np.ones(N), endo])
    instruments = np.column_stack([np.ones(N), shock])
    cross = instruments.T @ (s[:, None] * regressors)
    beta = np.linalg.solve(cross, instruments.T @ (s * dep))
    resid = dep - regressors @ beta
    scores = instruments * (s * resid)[:, None]
    inv = np.linalg.inv(cross)
    hc1 = N / (N - 2)
    cov = hc1 * inv @ (scores.T @ scores) @ inv.T
    return float(beta[1]), float(np.sqrt(cov[1, 1]))

effect, effect_se = shock_iv(ybar, xbar)

first_stage_est = float(np.sum(e * z0 * x0) / np.sum(e * z0 * z0))
_, first_stage_se = shock_iv(xbar, zbar)

effective_shocks = float(1.0 / np.sum(s ** 2))

output = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": effect, "se": effect_se, "n_obs": int(N)},
        {"term": "first_stage", "estimate": first_stage_est, "se": first_stage_se, "n_obs": int(N)},
        {"term": "effective_shocks", "estimate": effective_shocks, "se": None, "n_obs": int(N)},
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS with shift-share instrument; shock-level weighted IV aggregation",
        "vcov": "shock-level HC1 robust (N/(N-2)), structural residuals, analytic weights, no clustering",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
