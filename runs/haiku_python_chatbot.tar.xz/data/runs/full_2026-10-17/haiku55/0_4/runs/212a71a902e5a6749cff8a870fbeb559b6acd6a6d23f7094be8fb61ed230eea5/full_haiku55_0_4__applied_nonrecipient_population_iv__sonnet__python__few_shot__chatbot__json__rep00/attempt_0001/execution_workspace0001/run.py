import json

import numpy as np
import pandas as pd

hh = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

d = hh[hh["recipient"] == 0].copy()
e = d["eligible"].to_numpy(dtype=float)
ne = 1.0 - e
w = d["weight"].to_numpy(dtype=float)
dose = d["dose"].to_numpy(dtype=float)
base = d["baseline"].to_numpy(dtype=float)
inst = d["instrument"].to_numpy(dtype=float)
y = d["outcome"].to_numpy(dtype=float)

X_exog = np.column_stack([ne, e, base * ne, base * e])
X = np.column_stack([dose * ne, dose * e, X_exog])
Z = np.column_stack([X_exog, inst * ne, inst * e])

sw = np.sqrt(w)
Xw = X * sw[:, None]
Zw = Z * sw[:, None]
yw = y * sw

ZtZ_inv = np.linalg.pinv(Zw.T @ Zw)
Xhat = Zw @ (ZtZ_inv @ (Zw.T @ Xw))
beta = np.linalg.lstsq(Xhat, yw, rcond=None)[0]

slope_inel = float(beta[0])
slope_el = float(beta[1])

m0 = float(np.average(dose[e == 0], weights=w[e == 0]))
m1 = float(np.average(dose[e == 1], weights=w[e == 1]))

ineligible_effect = slope_inel * m0
eligible_nonrecipient_effect = slope_el * m1

pop0 = float(census.loc[census["eligible"] == 0, "nonrecipient_population"].iloc[0])
pop1 = float(census.loc[census["eligible"] == 1, "nonrecipient_population"].iloc[0])
population_effect = (pop0 * ineligible_effect + pop1 * eligible_nonrecipient_effect) / (pop0 + pop1)

n_obs = int(len(d))
n_ineligible = int(np.sum(e == 0))
n_eligible = int(np.sum(e == 1))

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "ineligible_effect",
            "estimate": float(ineligible_effect),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "eligible_nonrecipient_effect",
            "estimate": float(eligible_nonrecipient_effect),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "population_effect",
            "estimate": float(population_effect),
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "weighted_2sls",
        "regression_weight": "weight",
        "sample": "recipient == 0, all village treatment statuses",
        "endogenous": ["dose*(1-eligible)", "dose*eligible"],
        "exogenous": ["1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"],
        "instruments_excluded": ["instrument*(1-eligible)", "instrument*eligible"],
        "intercept": "none added; indicators span the constant",
        "group_effect": "dose slope times household-weighted mean dose within eligibility group",
        "counterfactual": "dose set to zero for every retained household (synthetic convention)",
        "population_weights": {"eligible_0": pop0, "eligible_1": pop1},
    },
    "diagnostics": {
        "n_obs": n_obs,
        "n_ineligible": n_ineligible,
        "n_eligible": n_eligible,
        "n_columns_regressors": int(X.shape[1]),
        "n_columns_instruments": int(Z.shape[1]),
        "instrument_matrix_rank": int(np.linalg.matrix_rank(Zw)),
        "slope_ineligible": slope_inel,
        "slope_eligible": slope_el,
        "weighted_mean_dose_ineligible": m0,
        "weighted_mean_dose_eligible": m1,
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
