import json

import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")

regions = df.groupby("region_id", sort=True).agg(
    region_weight=("region_weight", "first"),
    x=("x", "first"),
    y=("y", "first"),
)
df["z_part"] = df["share"] * df["shock"]
regions["z"] = df.groupby("region_id")["z_part"].sum().loc[regions.index]

shock_by_ind = df.groupby("industry_id")["shock"].first().sort_index()
industries = shock_by_ind.index
shock = shock_by_ind.values

S = (
    df.pivot(index="region_id", columns="industry_id", values="share")
    .loc[regions.index, industries]
    .fillna(0.0)
    .values
)

e = regions["region_weight"].values.astype(float)
e = e / e.sum()

y = regions["y"].values.astype(float)
x = regions["x"].values.astype(float)
z = regions["z"].values.astype(float)

y0 = y - e @ y
x0 = x - e @ x
z0 = z - e @ z

s = e @ S
ybar = (S.T @ (e * y0)) / s
xbar = (S.T @ (e * x0)) / s
zbar = (S.T @ (e * z0)) / s

N = len(industries)


def shock_iv(dep, endog, instr, w):
    regressors = np.column_stack([np.ones(N), endog])
    instruments = np.column_stack([np.ones(N), instr])
    cross = instruments.T @ (w[:, None] * regressors)
    beta = np.linalg.solve(cross, instruments.T @ (w * dep))
    resid = dep - regressors @ beta
    scores = instruments * (w * resid)[:, None]
    inv = np.linalg.inv(cross)
    hc1 = N / (N - 2)
    cov = hc1 * inv @ (scores.T @ scores) @ inv.T
    return float(beta[1]), float(np.sqrt(cov[1, 1]))


effect_shock, effect_se = shock_iv(ybar, xbar, shock, s)
first_shock, first_se = shock_iv(xbar, zbar, shock, s)

effect_regional = float(np.sum(e * z0 * y0) / np.sum(e * z0 * x0))
first_regional = float(np.sum(e * z0 * x0) / np.sum(e * z0 ** 2))
effective_shocks = float(1.0 / np.sum(s ** 2))

output = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": effect_regional, "se": effect_se, "n_obs": int(N)},
        {"term": "first_stage", "estimate": first_regional, "se": first_se, "n_obs": int(N)},
        {"term": "effective_shocks", "estimate": effective_shocks, "se": None, "n_obs": int(N)},
    ],
    "method_metadata": {
        "estimator": "Region-weighted 2SLS of y on x instrumented by shift-share z, with Borusyak-Hull-Jaravel shock-level weighted IV for inference",
        "vcov": "Shock-level structural-residual HC1 robust variance with N/(N-2) multiplier, analytic weights, no clustering",
    },
    "diagnostics": {
        "n_regions": int(len(regions)),
        "n_industries": int(N),
        "shock_level_effect_estimate": effect_shock,
        "shock_level_first_stage_estimate": first_shock,
        "regional_minus_shock_effect": effect_regional - effect_shock,
        "regional_minus_shock_first_stage": first_regional - first_shock,
    },
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
