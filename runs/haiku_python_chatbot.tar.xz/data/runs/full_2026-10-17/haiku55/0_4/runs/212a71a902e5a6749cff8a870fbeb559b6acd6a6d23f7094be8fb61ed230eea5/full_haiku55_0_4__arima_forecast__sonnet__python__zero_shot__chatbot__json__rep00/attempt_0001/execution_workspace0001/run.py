import json
import math

import numpy as np
import pandas as pd
from statsmodels.tsa.arima.model import ARIMA

df = pd.read_csv("./input.csv")
y = df["y"].astype(float).reset_index(drop=True)
n_obs = int(y.notna().sum())

model = ARIMA(y, order=(1, 1, 1), trend="n")
res = model.fit()

last_t = int(df["t"].max())
steps = max(1, 251 - last_t)
fc = res.get_forecast(steps=steps)

mean = float(fc.predicted_mean.iloc[-1])
var = float(fc.var_pred_mean.iloc[-1])
se = math.sqrt(var) if var >= 0 else None
ci = fc.conf_int(alpha=0.05).iloc[-1]
lower = float(ci.iloc[0])
upper = float(ci.iloc[1])

out = {
    "task_id": "arima_forecast",
    "platform": "python",
    "estimates": [
        {"term": "forecast", "estimate": mean, "se": se, "n_obs": n_obs},
        {"term": "lower_95", "estimate": lower, "se": None, "n_obs": n_obs},
        {"term": "upper_95", "estimate": upper, "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "ARIMA(1,1,1) exact maximum likelihood, no constant (statsmodels ARIMA, trend='n')",
        "vcov": str(res.cov_type),
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(out, f, indent=2)
