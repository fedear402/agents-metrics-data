import json

import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
h = 1.0
d = df[np.abs(df["score"]) < h].copy()


def side_fit(sub):
    s = sub["score"].to_numpy(float)
    w = 1.0 - np.abs(s)
    X = np.column_stack([np.ones_like(s), s])
    Y = np.column_stack([
        sub["earnings"].to_numpy(float),
        sub["participated"].to_numpy(float),
    ])
    B = np.linalg.inv(X.T @ (w[:, None] * X))
    beta = B @ X.T @ (w[:, None] * Y)
    E = Y - X @ beta
    c = w * (X @ B[:, 0])
    intercept = beta[0, :]
    cov = (c[:, None] * E).T @ (c[:, None] * E)
    return intercept, cov, len(s)


right = side_fit(d[d["score"] >= 0])
left = side_fit(d[d["score"] < 0])

a_r, cov_r, n_r = right
a_l, cov_l, n_l = left

jumps = a_r - a_l
V = cov_r + cov_l

rf = float(jumps[0])
fs = float(jumps[1])
tau = rf / fs

grad = np.array([1.0 / fs, -rf / fs**2])
tau_var = float(grad @ V @ grad)

n_total = int(len(d))

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {
            "term": "treatment_effect",
            "estimate": float(tau),
            "se": float(np.sqrt(max(tau_var, 0.0))),
            "n_obs": n_total,
        },
        {
            "term": "reduced_form",
            "estimate": rf,
            "se": float(np.sqrt(max(V[0, 0], 0.0))),
            "n_obs": n_total,
        },
        {
            "term": "first_stage",
            "estimate": fs,
            "se": float(np.sqrt(max(V[1, 1], 0.0))),
            "n_obs": n_total,
        },
    ],
    "method_metadata": {
        "estimator": "fuzzy RD local linear, triangular kernel, bandwidth 1, separate slopes per side, ratio of discontinuities",
        "vcov": "HC0 sandwich, no degrees-of-freedom correction, fixed weights, delta method with cross-covariance",
    },
    "diagnostics": {
        "n_right": int(n_r),
        "n_left": int(n_l),
        "covariance_reduced_form_first_stage": float(V[0, 1]),
    },
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
