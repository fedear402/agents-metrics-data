import json

import numpy as np
import pandas as pd
from scipy import stats

df = pd.read_csv("input.csv")
n = len(df)
y = df["y"].to_numpy(dtype=float)
endog = df["endog"].to_numpy(dtype=float)
x = df["x"].to_numpy(dtype=float)
z1 = df["z1"].to_numpy(dtype=float)
z2 = df["z2"].to_numpy(dtype=float)

const = np.ones(n)
X0 = np.column_stack([const, x])
X1 = np.column_stack([const, x, z1, z2])
df_den = n - 4
f_crit = stats.f.ppf(0.95, 2, df_den)


def rss(M, v):
    coef, *_ = np.linalg.lstsq(M, v, rcond=None)
    r = v - M @ coef
    return float(r @ r)


def quad_coeffs(M):
    r0 = rss(M, y)
    rp = rss(M, y - endog)
    rm = rss(M, y + endog)
    c = r0
    b = (rp - rm) / 2.0
    a = (rp + rm) / 2.0 - r0
    return a, b, c


a0, b0, c0 = quad_coeffs(X0)
a1, b1, c1 = quad_coeffs(X1)


def f_stat(beta):
    v = y - beta * endog
    r0 = rss(X0, v)
    r1 = rss(X1, v)
    return ((r0 - r1) / 2.0) / (r1 / df_den)


k = 1.0 + 2.0 * f_crit / df_den
qa = a0 - k * a1
qb = b0 - k * b1
qc = c0 - k * c1

disc = qb * qb - 4.0 * qa * qc
sqrt_disc = np.sqrt(disc)
root1 = (-qb - sqrt_disc) / (2.0 * qa)
root2 = (-qb + sqrt_disc) / (2.0 * qa)
boundary_low, boundary_high = sorted([root1, root2])

accepts_zero = int(qc <= 0.0)
unbounded = int(qa <= 0.0)
ar_f_at_one = f_stat(1.0)

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": [
        {"term": "boundary_low", "estimate": float(boundary_low), "se": None, "n_obs": int(n)},
        {"term": "boundary_high", "estimate": float(boundary_high), "se": None, "n_obs": int(n)},
        {"term": "accepts_zero", "estimate": float(accepts_zero), "se": None, "n_obs": int(n)},
        {"term": "unbounded", "estimate": float(unbounded), "se": None, "n_obs": int(n)},
        {"term": "ar_f_at_one", "estimate": float(ar_f_at_one), "se": None, "n_obs": int(n)},
    ],
    "method_metadata": {
        "estimator": "Anderson-Rubin test inversion over the full real line",
        "vcov": "homoskedastic",
    },
    "diagnostics": {
        "critical_value_f_95": float(f_crit),
        "quadratic_leading_coefficient": float(qa),
        "numerator_df": 2,
        "denominator_df": int(df_den),
    },
}

with open("result.json", "w") as fh:
    json.dump(result, fh, indent=2)
