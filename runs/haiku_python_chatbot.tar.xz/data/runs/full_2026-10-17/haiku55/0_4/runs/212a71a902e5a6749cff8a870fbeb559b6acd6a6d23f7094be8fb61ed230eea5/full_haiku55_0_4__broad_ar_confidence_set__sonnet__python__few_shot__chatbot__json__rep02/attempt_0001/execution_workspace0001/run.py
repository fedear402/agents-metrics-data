import json

import numpy as np
import pandas as pd
from scipy.stats import f

data = pd.read_csv("input.csv")
y = data["y"].to_numpy(dtype=float)
endog = data["endog"].to_numpy(dtype=float)
x = data["x"].to_numpy(dtype=float)
excluded = data[["z1", "z2"]].to_numpy(dtype=float)

n = len(y)
q = excluded.shape[1]
controls = np.column_stack([np.ones(n), x])
full = np.column_stack([controls, excluded])
dof = n - full.shape[1]
critical = f.ppf(0.95, q, dof)


def residual(v, design):
    return v - design @ np.linalg.lstsq(design, v, rcond=None)[0]


ry = residual(y, controls)
rd = residual(endog, controls)
uy = residual(y, full)
ue = residual(endog, full)

k = q * critical / dof
A = rd @ rd - (1 + k) * (ue @ ue)
B = -2 * (ry @ rd - (1 + k) * (uy @ ue))
C = ry @ ry - (1 + k) * (uy @ uy)
discriminant = B * B - 4 * A * C


def accepts(beta):
    return A * beta * beta + B * beta + C <= 0


def f_stat(beta):
    yb = y - beta * endog
    r = residual(yb, controls)
    u = residual(yb, full)
    return ((r @ r - u @ u) / q) / ((u @ u) / dof)


if A != 0 and discriminant > 0:
    roots = np.sort(np.roots([A, B, C]).real)
    boundary_low = float(roots[0])
    boundary_high = float(roots[1])
else:
    boundary_low = None
    boundary_high = None

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": [
        {"term": "boundary_low", "estimate": boundary_low, "se": None, "n_obs": int(n)},
        {"term": "boundary_high", "estimate": boundary_high, "se": None, "n_obs": int(n)},
        {"term": "accepts_zero", "estimate": int(accepts(0.0)), "se": None, "n_obs": int(n)},
        {"term": "unbounded", "estimate": int(A < 0), "se": None, "n_obs": int(n)},
        {"term": "ar_f_at_one", "estimate": float(f_stat(1.0)), "se": None, "n_obs": int(n)},
    ],
    "method_metadata": {
        "estimator": "Anderson-Rubin confidence set by inverting homoskedastic joint F test",
        "vcov": "homoskedastic",
    },
    "diagnostics": {
        "critical_value": float(critical),
        "numerator_df": int(q),
        "denominator_df": int(dof),
        "quadratic_A": float(A),
        "quadratic_B": float(B),
        "quadratic_C": float(C),
        "discriminant": float(discriminant),
    },
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
