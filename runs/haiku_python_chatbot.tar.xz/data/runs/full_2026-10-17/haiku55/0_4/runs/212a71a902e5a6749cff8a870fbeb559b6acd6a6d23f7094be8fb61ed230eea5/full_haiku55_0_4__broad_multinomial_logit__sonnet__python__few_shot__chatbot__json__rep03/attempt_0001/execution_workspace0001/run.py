import json

import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy.special import softmax

df = pd.read_csv("input.csv")
X = sm.add_constant(df[["x", "z"]].astype(float), has_constant="add")
y = df["y"].astype(int)
n_obs = int(len(df))

fit = sm.MNLogit(y, X).fit(method="newton", maxiter=500, tol=1e-10, disp=False)

outcomes_nonbase = [1, 2]
params = fit.params.copy()
params.columns = outcomes_nonbase
bse = fit.bse.copy()
bse.columns = outcomes_nonbase

x_cat1 = float(params.loc["x", 1])
x_cat1_se = float(bse.loc["x", 1])
z_cat1 = float(params.loc["z", 1])
z_cat1_se = float(bse.loc["z", 1])
x_cat2 = float(params.loc["x", 2])
x_cat2_se = float(bse.loc["x", 2])
z_cat2 = float(params.loc["z", 2])
z_cat2_se = float(bse.loc["z", 2])

c1 = float(params.loc["const", 1])
c2 = float(params.loc["const", 2])
p = softmax(np.array([0.0, c1, c2]))
prob_cat2_zero = float(p[2])

# Delta method on the intercept-only probability; eq-major ordering: index = eq * K + var
K = X.shape[1]
cov = np.asarray(fit.cov_params())
idx = [0 * K + list(X.columns).index("const"), 1 * K + list(X.columns).index("const")]
V = cov[np.ix_(idx, idx)]
p1 = float(p[1])
p2 = float(p[2])
grad = np.array([-p1 * p2, p2 * (1.0 - p2)])
prob_cat2_zero_se = float(np.sqrt(grad @ V @ grad))

output = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": [
        {"term": "x_cat1", "estimate": x_cat1, "se": x_cat1_se, "n_obs": n_obs},
        {"term": "z_cat1", "estimate": z_cat1, "se": z_cat1_se, "n_obs": n_obs},
        {"term": "x_cat2", "estimate": x_cat2, "se": x_cat2_se, "n_obs": n_obs},
        {"term": "z_cat2", "estimate": z_cat2, "se": z_cat2_se, "n_obs": n_obs},
        {"term": "prob_cat2_zero", "estimate": prob_cat2_zero, "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "multinomial logit maximum likelihood, base outcome 0",
        "vcov": "conventional observed-information (inverse Hessian)",
    },
    "diagnostics": {
        "converged": bool(fit.mle_retvals.get("converged", True)),
        "llf": float(fit.llf),
        "prob_cat2_zero_se_delta_method": prob_cat2_zero_se,
    },
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
