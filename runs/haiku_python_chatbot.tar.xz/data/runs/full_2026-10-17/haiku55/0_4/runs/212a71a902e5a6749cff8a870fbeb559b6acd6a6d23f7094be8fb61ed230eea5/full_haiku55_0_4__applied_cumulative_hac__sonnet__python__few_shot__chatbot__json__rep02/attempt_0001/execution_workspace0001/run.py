import json
import numpy as np
import pandas as pd

data = pd.read_csv("input.csv")
data["date"] = pd.to_datetime(data["date"])
data = data.sort_values("date").reset_index(drop=True)

data["vix_change"] = np.log(data["vix"]).diff()
data["log_sales"] = np.log(data["sales"])

L = 15
for k in range(1, L + 1):
    data[f"lag_{k}"] = data["vix_change"].shift(k)

sample = data.dropna(subset=["log_sales"] + [f"lag_{k}" for k in range(1, L + 1)])
N = len(sample)

X = np.column_stack([np.ones(N)] + [sample[f"lag_{k}"].to_numpy() for k in range(1, L + 1)])
y = sample["log_sales"].to_numpy()

coefficients = np.linalg.lstsq(X, y, rcond=None)[0]
residuals = y - X @ coefficients

scores = X * residuals[:, None]
meat = scores.T @ scores
for j in range(1, L + 1):
    weight = 1 - j / (L + 1)
    lag_product = scores[j:].T @ scores[:-j]
    meat += weight * (lag_product + lag_product.T)

bread = np.linalg.inv(X.T @ X)
p = X.shape[1]
covariance = (N / (N - p)) * bread @ meat @ bread

contrast = np.zeros(p)
contrast[1:] = 1.0
cumulative = float(contrast @ coefficients)
cumulative_se = float(np.sqrt(contrast @ covariance @ contrast))

output = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {"term": "cumulative_response", "estimate": cumulative, "se": cumulative_se, "n_obs": int(N)},
        {"term": "lag_1", "estimate": float(coefficients[1]), "se": float(np.sqrt(covariance[1, 1])), "n_obs": int(N)},
        {"term": "lag_15", "estimate": float(coefficients[L]), "se": float(np.sqrt(covariance[L, L])), "n_obs": int(N)},
    ],
    "method_metadata": {
        "estimator": "OLS regression of log(sales) on intercept and 15 lags of first difference of log(vix)",
        "vcov": "Newey-West HAC, max lag 15, Bartlett weights, scaled by N/(N-16)",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
