import json

import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")

cohorts = [3, 5, 7]
estimates = []
att_vals = []
weights = []
row_counts = []

for c in cohorts:
    lo, hi = c - 2, c + 2
    win = df[(df["time"] >= lo) & (df["time"] <= hi)]
    elig = win[(win["g"] == c) | (win["g"] == 0) | (win["g"] > c + 2)]

    n_times = elig.groupby("id")["time"].nunique()
    keep_ids = n_times[n_times == hi - lo + 1].index
    sub = elig[elig["id"].isin(keep_ids)].copy()

    sub["did"] = ((sub["g"] == c) & (sub["time"] >= c)).astype(float)

    units = sorted(sub["id"].unique())
    times = sorted(sub["time"].unique())
    n = len(sub)

    X = np.zeros((n, 2 + (len(units) - 1) + (len(times) - 1)))
    X[:, 0] = 1.0
    X[:, 1] = sub["did"].to_numpy()

    uidx = {u: i for i, u in enumerate(units)}
    tidx = {t: i for i, t in enumerate(times)}
    rows = np.arange(n)
    ids = sub["id"].map(uidx).to_numpy()
    tms = sub["time"].map(tidx).to_numpy()

    for j in range(1, len(units)):
        X[:, 1 + j] = (ids == j).astype(float)
    off = 1 + len(units) - 1
    for k in range(1, len(times)):
        X[:, off + k] = (tms == k).astype(float)

    y = sub["y"].to_numpy(dtype=float)
    beta = np.linalg.lstsq(X, y, rcond=None)[0]
    att = float(beta[1])

    n_treated = int(sub.loc[sub["g"] == c, "id"].nunique())

    att_vals.append(att)
    weights.append(n_treated)
    row_counts.append(n)
    estimates.append({
        "term": f"att_g{c}",
        "estimate": att,
        "se": None,
        "n_obs": n,
    })

w = np.array(weights, dtype=float)
a = np.array(att_vals, dtype=float)
att_weighted = float(np.sum(w * a) / np.sum(w))

estimates.append({
    "term": "att_weighted",
    "estimate": att_weighted,
    "se": None,
    "n_obs": int(sum(row_counts)),
})

result = {
    "task_id": "broad_cohort_stack",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {},
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
