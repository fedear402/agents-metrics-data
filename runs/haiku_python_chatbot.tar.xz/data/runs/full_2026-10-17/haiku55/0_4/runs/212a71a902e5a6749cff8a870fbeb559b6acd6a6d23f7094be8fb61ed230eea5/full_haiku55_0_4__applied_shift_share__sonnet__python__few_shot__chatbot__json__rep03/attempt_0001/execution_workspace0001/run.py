import json

import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")

regions = df.groupby("region_id", sort=True).agg(
    region_weight=("region_weight", "first"),
    x=("x", "first"),
    y=("y", "first"),
)
df["z_part"] = df["share"] * df["shock"]
regions["z"] = df.groupby("region_id", sort=True)["z_part"].sum()

e = (regions["region_weight"] / regions["region_weight"].sum()).to_numpy(dtype=float)
y = regions["y"].to_numpy(dtype=float)
x = regions["x"].to_numpy(dtype=float)
z = regions["z"].to_numpy(dtype=float)

y0 = y - np.sum(e * y)
x0 = x - np.sum(e * x)
z0 = z - np.sum(e * z)

share_wide = df.pivot_table(
    index="region_id", columns="industry_id", values="share", aggfunc="sum", fill_value=0.0
).loc[regions.index]
S = share_wide.to_numpy(dtype=float)
shock = (
    df.groupby("industry_id")["shock"].first().loc[share_wide.columns].to_numpy(dtype=float)
)

s = e @ S


def aggregate(v0):
    return (S.T @ (e * v0)) / s


ybar = aggregate(y0)
xbar = aggregate(x0)
zbar = aggregate(z0)


def shock_iv(dep, endog, instr, w):
    n = len(dep)
    X = np.column_stack([np.ones(n), endog])
    Z = np.column_stack([np.ones(n), instr])
    cross = Z.T @ (w[:, None] * X)
    beta = np.linalg.solve(cross, Z.T @ (w * dep))
    resid = dep - X @ beta
    scores = Z * (w * resid)[:, None]
    inv = np.linalg.inv(cross)
    hc1 = n / (n - 2)
    cov = hc1 * inv @ (scores.T @ scores) @ inv.T
    return float(beta[1]), float(np.sqrt(cov[1, 1]))


effect_shock, effect_se = shock_iv(ybar, xbar, shock, s)
first_shock, first_se = shock_iv(xbar, zbar, shock, s)

effect = float(np.sum(e * z0 * y0) / np.sum(e * z0 * x0))
first_stage = float(np.sum(e * z0 * x0) / np.sum(e * z0 * z0))
effective_shocks = float(1.0 / np.sum(s ** 2))

n_industries = int(len(shock))

output = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": effect, "se": effect_se, "n_obs": n_industries},
        {"term": "first_stage", "estimate": first_stage, "se": first_se, "n_obs": n_industries},
        {"term": "effective_shocks", "estimate": effective_shocks, "se": None, "n_obs": n_industries},
    ],
    "method_metadata": {
        "estimator": "Weighted 2SLS of y on x instrumented by shift-share z, with Borusyak-Hull-Jaravel shock-level IV aggregation weighted by industry exposure mass",
        "vcov": "Shock-level structural-residual HC1 robust sandwich, N/(N-2) multiplier, no clustering",
    },
    "diagnostics": {
        "shock_level_effect_estimate": effect_shock,
        "shock_level_first_stage_estimate": first_shock,
        "effect_shock_vs_regional_abs_diff": abs(effect_shock - effect),
        "first_stage_shock_vs_regional_abs_diff": abs(first_shock - first_stage),
        "n_regions": int(len(e)),
        "n_industries": n_industries,
    },
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
