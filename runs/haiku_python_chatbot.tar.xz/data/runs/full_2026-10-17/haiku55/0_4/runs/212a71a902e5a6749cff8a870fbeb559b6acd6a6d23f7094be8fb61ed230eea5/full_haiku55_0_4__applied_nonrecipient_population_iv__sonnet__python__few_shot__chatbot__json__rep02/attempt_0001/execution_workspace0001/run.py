import json

import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS

households = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

d = households[households["recipient"] == 0].copy()
e = d["eligible"].astype(float)
ne = 1.0 - e

d["const_inel"] = ne
d["const_el"] = e
d["base_inel"] = d["baseline"] * ne
d["base_el"] = d["baseline"] * e
d["dose_inel"] = d["dose"] * ne
d["dose_el"] = d["dose"] * e
d["inst_inel"] = d["instrument"] * ne
d["inst_el"] = d["instrument"] * e

exog = d[["const_inel", "const_el", "base_inel", "base_el"]]
endog = d[["dose_inel", "dose_el"]]
instr = d[["const_inel", "const_el", "base_inel", "base_el", "inst_inel", "inst_el"]]

fit = IV2SLS(d["outcome"], exog, endog, instr, weights=d["weight"]).fit()

slope_inel = float(fit.params["dose_inel"])
slope_el = float(fit.params["dose_el"])

g0 = d[d["eligible"] == 0]
g1 = d[d["eligible"] == 1]
mean_dose_inel = float(np.average(g0["dose"], weights=g0["weight"]))
mean_dose_el = float(np.average(g1["dose"], weights=g1["weight"]))

ineligible_effect = slope_inel * mean_dose_inel
eligible_nonrecipient_effect = slope_el * mean_dose_el

pop = census.assign(eligible=census["eligible"].astype(int)).set_index("eligible")["nonrecipient_population"]
pop0 = float(pop.loc[0])
pop1 = float(pop.loc[1])
population_effect = float(
    np.average(
        [ineligible_effect, eligible_nonrecipient_effect],
        weights=[pop0, pop1],
    )
)

n_obs = int(len(d))

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "ineligible_effect",
            "estimate": float(ineligible_effect),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "eligible_nonrecipient_effect",
            "estimate": float(eligible_nonrecipient_effect),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "population_effect",
            "estimate": float(population_effect),
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "method": "weighted 2SLS with group-specific dose slopes",
        "endogenous": ["dose_inel", "dose_el"],
        "exogenous": ["const_inel", "const_el", "base_inel", "base_el"],
        "instruments": [
            "const_inel", "const_el", "base_inel", "base_el",
            "inst_inel", "inst_el",
        ],
        "regression_weight": "weight",
        "sample": "recipient == 0",
        "counterfactual": "dose set to zero for every retained household",
        "aggregation_weights": "census nonrecipient_population by eligibility group",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "n_ineligible": int(len(g0)),
        "n_eligible": int(len(g1)),
        "slope_ineligible": slope_inel,
        "slope_eligible": slope_el,
        "weighted_mean_dose_ineligible": mean_dose_inel,
        "weighted_mean_dose_eligible": mean_dose_el,
        "nonrecipient_population_ineligible": pop0,
        "nonrecipient_population_eligible": pop1,
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
