import json
import pandas as pd
from scipy import stats

df = pd.read_csv("./input.csv")
groups = [g["y"].dropna().values for _, g in df.groupby("group")]
k = len(groups)
n_obs = int(df["y"].notna().sum())

f_stat, p_val = stats.f_oneway(*groups)
df_num = k - 1
df_den = n_obs - k

out = {
    "task_id": "anova_oneway",
    "platform": "python",
    "estimates": [
        {"term": "F", "estimate": float(f_stat), "se": None, "n_obs": n_obs},
        {"term": "df_num", "estimate": float(df_num), "se": None, "n_obs": n_obs},
        {"term": "df_den", "estimate": float(df_den), "se": None, "n_obs": n_obs},
        {"term": "p_value", "estimate": float(p_val), "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {"estimator": "One-way ANOVA (F test)", "vcov": "none"},
    "diagnostics": {},
}
with open("result.json", "w") as f:
    json.dump(out, f)
