import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("input.csv")
df["date"] = pd.to_datetime(df["date"])
df = df.sort_values("date").reset_index(drop=True)

df["dlvix"] = np.log(df["vix"]).diff()
df["lnsales"] = np.log(df["sales"])

L = 15
for k in range(1, L + 1):
    df[f"lag_{k}"] = df["dlvix"].shift(k)

df = df.dropna(subset=["lnsales"] + [f"lag_{k}" for k in range(1, L + 1)]).reset_index(drop=True)

y = df["lnsales"].values
X = sm.add_constant(df[[f"lag_{k}" for k in range(1, L + 1)]].values)
N = len(y)

model = sm.OLS(y, X).fit(
    cov_type="HAC",
    cov_kwds={"maxlags": L, "use_correction": False, "kernel": "bartlett"},
)

V = model.cov_params() * N / (N - (L + 1))
beta = model.params

w = np.zeros(L + 1)
w[1:] = 1.0
cum_vec = np.zeros(L + 1)
cum_vec[1:] = 1.0
cum_est = float(cum_vec @ beta)
cum_se = float(np.sqrt(cum_vec @ V @ cum_vec))

lag1_est = float(beta[1])
lag1_se = float(np.sqrt(V[1, 1]))
lag15_est = float(beta[L])
lag15_se = float(np.sqrt(V[L, L]))

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {"term": "cumulative_response", "estimate": cum_est, "se": cum_se, "n_obs": int(N)},
        {"term": "lag_1", "estimate": lag1_est, "se": lag1_se, "n_obs": int(N)},
        {"term": "lag_15", "estimate": lag15_est, "se": lag15_se, "n_obs": int(N)},
    ],
    "method_metadata": {
        "estimator": "OLS regression of log(sales) on intercept and 15 lags of diff log(vix)",
        "vcov": "Newey-West HAC, maxlags=15, Bartlett weights, scaled by N/(N-16)",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
