import json

import numpy as np
import pandas as pd


def wmean(v, w):
    return np.sum(w * v) / np.sum(w)


def iv_hc1(y, x, z, w):
    y = np.asarray(y, dtype=float)
    x = np.asarray(x, dtype=float)
    z = np.asarray(z, dtype=float)
    w = np.asarray(w, dtype=float)
    yc = y - wmean(y, w)
    xc = x - wmean(x, w)
    zc = z - wmean(z, w)
    beta = np.sum(w * zc * yc) / np.sum(w * zc * xc)
    u = yc - beta * xc
    n = len(y)
    var = (n / (n - 2)) * np.sum((w * zc) ** 2 * u ** 2) / np.sum(w * zc * xc) ** 2
    return float(beta), float(np.sqrt(var))


df = pd.read_csv("input.csv")

reg = df.groupby("region_id").agg(
    w=("region_weight", "first"),
    x=("x", "first"),
    y=("y", "first"),
)
reg["z"] = (df["share"] * df["shock"]).groupby(df["region_id"]).sum()
reg["e"] = reg["w"] / reg["w"].sum()
for v in ["y", "x", "z"]:
    reg[v + "0"] = reg[v] - wmean(reg[v], reg["e"])

e = reg["e"].values
y0 = reg["y0"].values
x0 = reg["x0"].values
z0 = reg["z0"].values

effect_est = np.sum(e * z0 * y0) / np.sum(e * z0 * x0)
first_est = np.sum(e * z0 * x0) / np.sum(e * z0 * z0)

d = df[["region_id", "industry_id", "share", "shock"]].merge(
    reg[["e", "y0", "x0", "z0"]], left_on="region_id", right_index=True
)
d["w"] = d["e"] * d["share"]
s = d.groupby("industry_id")["w"].sum()


def agg(col):
    return (d["w"] * d[col]).groupby(d["industry_id"]).sum().reindex(s.index) / s


ybar = agg("y0")
xbar = agg("x0")
zbar = agg("z0")
sh = d.groupby("industry_id")["shock"].first().reindex(s.index)
sw = s.values

effect_shock_beta, effect_se = iv_hc1(ybar.values, xbar.values, sh.values, sw)
first_shock_beta, first_se = iv_hc1(xbar.values, zbar.values, sh.values, sw)

effective_shocks = 1.0 / np.sum(sw ** 2)
n_ind = int(len(s))

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": float(effect_est), "se": effect_se, "n_obs": n_ind},
        {"term": "first_stage", "estimate": float(first_est), "se": first_se, "n_obs": n_ind},
        {"term": "effective_shocks", "estimate": float(effective_shocks), "se": None, "n_obs": n_ind},
    ],
    "method_metadata": {
        "estimator": "Weighted 2SLS shift-share with BHJ shock-level aggregation (just-identified IV)",
        "vcov": "Shock-level heteroskedasticity-robust HC1 (N/(N-2)), structural residuals, analytic weights, no clustering",
    },
    "diagnostics": {
        "n_regions": int(len(reg)),
        "n_industries": n_ind,
        "effect_shock_level_slope": effect_shock_beta,
        "first_stage_shock_level_slope": first_shock_beta,
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
