import json
import numpy as np
import pandas as pd

df = pd.read_csv("./input.csv")
df["id"] = df["id"].astype(int)
df["time"] = df["time"].astype(int)
df["g"] = df["g"].astype(int)
df["y"] = df["y"].astype(float)

cohorts = [3, 5, 7]
results = {}

for c in cohorts:
    lo, hi = c - 2, c + 2
    window = df[(df["time"] >= lo) & (df["time"] <= hi)].copy()

    eligible_mask = (window["g"] == c) | (window["g"] == 0) | (window["g"] > c + 2)
    sub = window[eligible_mask].copy()

    times_per_unit = sub.groupby("id")["time"].nunique()
    full_units = times_per_unit[times_per_unit == (hi - lo + 1)].index
    sub = sub[sub["id"].isin(full_units)].copy()

    sub["did"] = ((sub["g"] == c) & (sub["time"] >= c)).astype(float)

    unit_ids = sorted(sub["id"].unique())
    time_ids = sorted(sub["time"].unique())

    uid_idx = {u: i for i, u in enumerate(unit_ids)}
    tid_idx = {t: i for i, t in enumerate(time_ids)}

    n = len(sub)
    k_units = len(unit_ids)
    k_times = len(time_ids)

    X = np.zeros((n, 1 + (k_units - 1) + (k_times - 1)))
    X[:, 0] = sub["did"].values
    ui = sub["id"].map(uid_idx).values
    ti = sub["time"].map(tid_idx).values
    for r in range(n):
        if ui[r] > 0:
            X[r, ui[r]] = 1.0
        if ti[r] > 0:
            X[r, k_units - 1 + ti[r]] = 1.0

    y = sub["y"].values
    beta, *_ = np.linalg.lstsq(X, y, rcond=None)
    att = float(beta[0])

    n_treated = sub.loc[sub["g"] == c, "id"].nunique()
    results[c] = {"att": att, "n_obs": int(n), "n_treated": int(n_treated)}

estimates = []
for c in cohorts:
    estimates.append({
        "term": f"att_g{c}",
        "estimate": f"{results[c]['att']:.10f}",
        "se": None,
        "n_obs": results[c]["n_obs"],
    })

weights = np.array([results[c]["n_treated"] for c in cohorts], dtype=float)
atts = np.array([results[c]["att"] for c in cohorts], dtype=float)
w_total = weights.sum()
att_weighted = float(np.sum(weights * atts) / w_total) if w_total > 0 else float("nan")
total_rows = sum(results[c]["n_obs"] for c in cohorts)

estimates.append({
    "term": "att_weighted",
    "estimate": f"{att_weighted:.10f}",
    "se": None,
    "n_obs": int(total_rows),
})

output = {
    "task_id": "broad_cohort_stack",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {},
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(output, f, indent=2)
