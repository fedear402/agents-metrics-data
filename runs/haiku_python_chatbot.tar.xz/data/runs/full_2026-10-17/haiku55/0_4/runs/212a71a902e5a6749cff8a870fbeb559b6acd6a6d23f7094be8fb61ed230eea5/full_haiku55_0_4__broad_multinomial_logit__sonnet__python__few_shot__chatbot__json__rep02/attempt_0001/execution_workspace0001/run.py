import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("input.csv")
n = len(df)

X = sm.add_constant(df[["x", "z"]].astype(float), has_constant="add")
fit = sm.MNLogit(df["y"].astype(int).to_numpy(), X).fit(method="newton", maxiter=500, disp=False, tol=1e-10)

outcomes = [0, 1, 2]
nonbase = outcomes[1:]
params = fit.params.copy()
bse = fit.bse.copy()
params.columns = nonbase
bse.columns = nonbase

x_cat1 = float(params.loc["x", 1])
z_cat1 = float(params.loc["z", 1])
x_cat2 = float(params.loc["x", 2])
z_cat2 = float(params.loc["z", 2])

se_x_cat1 = float(bse.loc["x", 1])
se_z_cat1 = float(bse.loc["z", 1])
se_x_cat2 = float(bse.loc["x", 2])
se_z_cat2 = float(bse.loc["z", 2])

pred_input = pd.DataFrame({"const": [1.0], "x": [0.0], "z": [0.0]})
probs = np.asarray(fit.predict(pred_input))[0]
prob_cat2_zero = float(probs[2])

output = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": [
        {"term": "x_cat1", "estimate": x_cat1, "se": se_x_cat1, "n_obs": int(n)},
        {"term": "z_cat1", "estimate": z_cat1, "se": se_z_cat1, "n_obs": int(n)},
        {"term": "x_cat2", "estimate": x_cat2, "se": se_x_cat2, "n_obs": int(n)},
        {"term": "z_cat2", "estimate": z_cat2, "se": se_z_cat2, "n_obs": int(n)},
        {"term": "prob_cat2_zero", "estimate": prob_cat2_zero, "se": None, "n_obs": int(n)},
    ],
    "method_metadata": {
        "estimator": "multinomial logit (maximum likelihood, base outcome 0)",
        "vcov": "observed information (inverse Hessian)",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
