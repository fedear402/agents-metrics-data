import json
import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
h = 1.0
d = df[np.abs(df["score"]) < h].copy()
s = d["score"].to_numpy(dtype=float)
w = 1.0 - np.abs(s)
right = (s >= 0).astype(float)
X = np.column_stack([np.ones(len(s)), right, s * (1 - right), s * right])
n = len(s)


def wls(y):
    XtWX = X.T @ (w[:, None] * X)
    bread = np.linalg.inv(XtWX)
    beta = bread @ (X.T @ (w * y))
    resid = y - X @ beta
    return beta, bread, resid


def contributions(bread, resid, y_dummy_idx=1):
    c = np.zeros(4)
    c[y_dummy_idx] = 1.0
    loading = w * (X @ bread @ c)
    return loading * resid


y_earn = d["earnings"].to_numpy(dtype=float)
y_part = d["participated"].to_numpy(dtype=float)

b_e, bread, r_e = wls(y_earn)
b_p, _, r_p = wls(y_part)

c = np.array([0.0, 1.0, 0.0, 0.0])
loading = w * (X @ bread @ c)
infl_e = loading * r_e
infl_p = loading * r_p
infl = np.column_stack([infl_e, infl_p])
joint = infl.T @ infl

rf = float(b_e[1])
fs = float(b_p[1])
te = rf / fs

grad = np.array([1.0 / fs, -rf / fs**2])
te_se = float(np.sqrt(grad @ joint @ grad))

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": te, "se": te_se, "n_obs": int(n)},
        {"term": "reduced_form", "estimate": rf, "se": float(np.sqrt(joint[0, 0])), "n_obs": int(n)},
        {"term": "first_stage", "estimate": fs, "se": float(np.sqrt(joint[1, 1])), "n_obs": int(n)},
    ],
    "method_metadata": {
        "estimator": "fuzzy RD, local linear with separate slopes per side, triangular kernel, bandwidth 1",
        "vcov": "HC0 delta method, no degrees-of-freedom correction",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2, allow_nan=False)
