import json

import numpy as np
import pandas as pd
from scipy.stats import f

data = pd.read_csv("input.csv")
y = data["y"].to_numpy(dtype=float)
endog = data["endog"].to_numpy(dtype=float)
x = data["x"].to_numpy(dtype=float)
z1 = data["z1"].to_numpy(dtype=float)
z2 = data["z2"].to_numpy(dtype=float)

n = len(y)
ctrl = np.column_stack([np.ones(n), x])
full = np.column_stack([ctrl, z1, z2])
q = 2
df_den = n - full.shape[1]
crit = f.ppf(0.95, q, df_den)


def resid(v, X):
    coef = np.linalg.lstsq(X, v, rcond=None)[0]
    return v - X @ coef


rc_y = resid(y, ctrl)
rc_e = resid(endog, ctrl)
rf_y = resid(y, full)
rf_e = resid(endog, full)

k = q * crit / df_den
A = rc_e @ rc_e - (1 + k) * (rf_e @ rf_e)
B = -2.0 * (rc_y @ rc_e - (1 + k) * (rf_y @ rf_e))
C = rc_y @ rc_y - (1 + k) * (rf_y @ rf_y)

disc = B * B - 4.0 * A * C
assert abs(A) > 1e-12 and disc > 0
sqrt_disc = np.sqrt(disc)
roots = np.sort([(-B - sqrt_disc) / (2.0 * A), (-B + sqrt_disc) / (2.0 * A)])
boundary_low, boundary_high = float(roots[0]), float(roots[1])


def accepts(beta):
    return A * beta * beta + B * beta + C <= 0


def ar_f(beta):
    yb = y - beta * endog
    ssr_r = resid(yb, ctrl)
    ssr_r = ssr_r @ ssr_r
    ssr_u = resid(yb, full)
    ssr_u = ssr_u @ ssr_u
    return ((ssr_r - ssr_u) / q) / (ssr_u / df_den)


for boundary in (boundary_low, boundary_high):
    assert np.isclose(ar_f(boundary), crit, atol=1e-6)

accepts_zero = int(accepts(0.0))
unbounded = int(A < 0)
ar_f_at_one = float(ar_f(1.0))

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": [
        {"term": "boundary_low", "estimate": boundary_low, "se": None, "n_obs": int(n)},
        {"term": "boundary_high", "estimate": boundary_high, "se": None, "n_obs": int(n)},
        {"term": "accepts_zero", "estimate": float(accepts_zero), "se": None, "n_obs": int(n)},
        {"term": "unbounded", "estimate": float(unbounded), "se": None, "n_obs": int(n)},
        {"term": "ar_f_at_one", "estimate": ar_f_at_one, "se": None, "n_obs": int(n)},
    ],
    "method_metadata": {
        "estimator": "Anderson-Rubin test inversion (joint F test of excluded instruments z1, z2)",
        "vcov": "homoskedastic",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
