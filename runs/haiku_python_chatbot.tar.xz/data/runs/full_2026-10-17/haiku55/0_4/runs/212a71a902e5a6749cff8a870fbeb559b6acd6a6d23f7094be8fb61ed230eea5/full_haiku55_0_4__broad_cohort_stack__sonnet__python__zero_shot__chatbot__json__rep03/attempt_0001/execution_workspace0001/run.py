import json

import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")[["id", "time", "g", "y"]]
df["y"] = df["y"].astype(float)

cohorts = [3, 5, 7]
estimates = []
diag = {}
weights = []
atts = []
total_rows = 0

for c in cohorts:
    window = list(range(c - 2, c + 3))
    sub = df[df["time"].isin(window)]
    elig = sub[(sub["g"] == c) | (sub["g"] == 0) | (sub["g"] > c + 2)]

    n_times = elig.groupby("id")["time"].nunique()
    keep_ids = n_times[n_times == len(window)].index
    d = elig[elig["id"].isin(keep_ids)].copy()

    d["did"] = ((d["g"] == c) & (d["time"] >= c)).astype(float)

    uid = pd.Categorical(d["id"]).codes
    tid = pd.Categorical(d["time"]).codes
    n = len(d)
    nu = int(uid.max()) + 1
    nt = int(tid.max()) + 1

    U = np.eye(nu)[uid][:, 1:]
    T = np.eye(nt)[tid][:, 1:]
    X = np.column_stack([np.ones(n), d["did"].to_numpy(), U, T])
    yv = d["y"].to_numpy()

    beta = np.linalg.lstsq(X, yv, rcond=None)[0]
    att = float(beta[1])

    n_treated = int(d.loc[d["g"] == c, "id"].nunique())
    n_control = int(d.loc[d["g"] != c, "id"].nunique())

    estimates.append({
        "term": f"att_g{c}",
        "estimate": att,
        "se": None,
        "n_obs": int(n),
    })

    atts.append(att)
    weights.append(n_treated)
    total_rows += n
    diag[f"g{c}"] = {
        "window_times": window,
        "eligible_units_before_balance": int(elig["id"].nunique()),
        "units_retained_after_balance": int(d["id"].nunique()),
        "treated_units": n_treated,
        "control_units": n_control,
        "rows": int(n),
    }

w = np.array(weights, dtype=float)
a = np.array(atts, dtype=float)
att_weighted = float(np.sum(w * a) / np.sum(w))

estimates.append({
    "term": "att_weighted",
    "estimate": att_weighted,
    "se": None,
    "n_obs": int(total_rows),
})

out = {
    "task_id": "broad_cohort_stack",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "cohort-specific two-way fixed effects DiD via OLS",
        "cohorts": cohorts,
        "weighting": "number of retained treated units per cohort comparison",
        "balance": "units observed at all five window times within each cohort comparison",
    },
    "diagnostics": diag,
}

with open("result.json", "w") as f:
    json.dump(out, f, indent=2)
