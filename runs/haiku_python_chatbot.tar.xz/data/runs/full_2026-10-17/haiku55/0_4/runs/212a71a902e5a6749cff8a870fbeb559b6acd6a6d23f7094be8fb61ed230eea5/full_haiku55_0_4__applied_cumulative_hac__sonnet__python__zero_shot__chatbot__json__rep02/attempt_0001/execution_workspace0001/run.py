import json

import numpy as np
import pandas as pd
import statsmodels.api as sm

LAGS = 15

df = pd.read_csv("input.csv")
df["date"] = pd.to_datetime(df["date"])
df = df.sort_values("date").reset_index(drop=True)

df["dlog_vix"] = np.log(df["vix"]).diff()
df["log_sales"] = np.log(df["sales"])
lag_cols = [f"lag_{k}" for k in range(1, LAGS + 1)]
for k in range(1, LAGS + 1):
    df[f"lag_{k}"] = df["dlog_vix"].shift(k)

d = df.dropna(subset=["log_sales"] + lag_cols).reset_index(drop=True)
N = len(d)

X = sm.add_constant(d[lag_cols], has_constant="add")
y = d["log_sales"]

res = sm.OLS(y, X).fit(
    cov_type="HAC",
    cov_kwds={"maxlags": LAGS, "use_correction": False},
)

beta = np.asarray(res.params, dtype=float)
V = np.asarray(res.cov_params(), dtype=float) * N / (N - (LAGS + 1))

c = np.zeros(LAGS + 1)
c[1:] = 1.0
cum_est = float(c @ beta)
cum_se = float(np.sqrt(c @ V @ c))

lag1_est = float(beta[1])
lag1_se = float(np.sqrt(V[1, 1]))
lag15_est = float(beta[LAGS])
lag15_se = float(np.sqrt(V[LAGS, LAGS]))

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {"term": "cumulative_response", "estimate": cum_est, "se": cum_se, "n_obs": int(N)},
        {"term": "lag_1", "estimate": lag1_est, "se": lag1_se, "n_obs": int(N)},
        {"term": "lag_15", "estimate": lag15_est, "se": lag15_se, "n_obs": int(N)},
    ],
    "method_metadata": {
        "estimator": "OLS regression of log(sales) on intercept and 15 lags of first difference of log(vix)",
        "vcov": "Newey-West HAC, maxlags=15, Bartlett weights 1-j/16, scaled by N/(N-16)",
    },
    "diagnostics": {
        "n_obs": int(N),
        "hac_maxlags": LAGS,
        "small_sample_scale": float(N / (N - (LAGS + 1))),
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
