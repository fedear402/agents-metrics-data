import json

import numpy as np
import pandas as pd

df = pd.read_csv('input.csv')

estimates = []
diagnostics = {}
att_values = {}
treated_counts = {}
row_counts = {}

for c in [3, 5, 7]:
    times = list(range(c - 2, c + 3))
    window = df[df['time'].isin(times)]
    eligible = window[(window['g'] == c) | (window['g'] == 0) | (window['g'] > c + 2)]
    counts = eligible.groupby('id')['time'].nunique()
    keep_ids = counts[counts == len(times)].index
    sub = eligible[eligible['id'].isin(keep_ids)].copy()

    did = ((sub['g'] == c) & (sub['time'] >= c)).astype(float).to_numpy()
    unit_fe = pd.get_dummies(sub['id'], drop_first=True, dtype=float).to_numpy()
    time_fe = pd.get_dummies(sub['time'], drop_first=True, dtype=float).to_numpy()
    design = np.column_stack([np.ones(len(sub)), did, unit_fe, time_fe])
    y = sub['y'].to_numpy(dtype=float)

    beta = np.linalg.lstsq(design, y, rcond=None)[0]
    att = float(beta[1])

    n_treated = int(sub.loc[sub['g'] == c, 'id'].nunique())
    n_rows = int(len(sub))
    rank = int(np.linalg.matrix_rank(design))

    att_values[c] = att
    treated_counts[c] = n_treated
    row_counts[c] = n_rows

    estimates.append({
        'term': f'att_g{c}',
        'estimate': att,
        'se': None,
        'n_obs': n_rows,
    })
    diagnostics[f'g{c}'] = {
        'window_times': times,
        'retained_treated_units': n_treated,
        'retained_control_units': int(sub.loc[sub['g'] != c, 'id'].nunique()),
        'retained_rows': n_rows,
        'design_rank': rank,
        'design_columns': int(design.shape[1]),
    }

total_treated = sum(treated_counts.values())
att_weighted = sum(treated_counts[c] * att_values[c] for c in [3, 5, 7]) / total_treated

estimates.append({
    'term': 'att_weighted',
    'estimate': float(att_weighted),
    'se': None,
    'n_obs': int(sum(row_counts.values())),
})

output = {
    'task_id': 'broad_cohort_stack',
    'platform': 'python',
    'estimates': estimates,
    'method_metadata': {},
    'diagnostics': diagnostics,
}

with open('result.json', 'w') as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
