import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy.special import softmax

df = pd.read_csv("input.csv")
n = len(df)

X = sm.add_constant(df[["x", "z"]].astype(float), has_constant="add")
y = df["y"].astype(int).to_numpy()
fit = sm.MNLogit(y, X).fit(method="newton", maxiter=500, tol=1e-10, disp=False)

params = fit.params.copy()
bse = fit.bse.copy()
params.columns = [1, 2]
bse.columns = [1, 2]

x_cat1, z_cat1 = params.loc["x", 1], params.loc["z", 1]
x_cat2, z_cat2 = params.loc["x", 2], params.loc["z", 2]
se_x1, se_z1 = bse.loc["x", 1], bse.loc["z", 1]
se_x2, se_z2 = bse.loc["x", 2], bse.loc["z", 2]

pred_in = pd.DataFrame({"const": [1.0], "x": [0.0], "z": [0.0]})
probs = np.asarray(fit.predict(pred_in))[0]
prob_cat2_zero = float(probs[2])

# Delta-method SE for P(y=2) at x=0, z=0
beta_full = np.r_[0.0, params[1].to_numpy()[0], params[1].to_numpy()[1]]
eta = np.array([0.0, params.loc["const", 1], params.loc["const", 2]])
p = softmax(eta)
cov = fit.cov_params()
idx2 = [i for i, name in enumerate(cov.index) if name.startswith("const")]
cov_const = cov.loc[[f"const" if False else c for c in cov.index if c.startswith("const")],
                    [c for c in cov.columns if c.startswith("const")]].to_numpy()
var_eta = np.zeros((3, 3))
var_eta[1:, 1:] = cov_const
grad = p[2] * (np.array([0.0, 1.0, 0.0]) - p) if False else None
g = np.zeros(3)
g[2] = p[2]
g = g - p[2] * p
var_p2 = float(g @ var_eta @ g)
se_prob = float(np.sqrt(max(var_p2, 0.0)))

def fin(v):
    v = float(v)
    if not np.isfinite(v):
        raise ValueError("non-finite estimate")
    return v

rows = [
    {"term": "x_cat1", "estimate": fin(x_cat1), "se": fin(se_x1), "n_obs": int(n)},
    {"term": "z_cat1", "estimate": fin(z_cat1), "se": fin(se_z1), "n_obs": int(n)},
    {"term": "x_cat2", "estimate": fin(x_cat2), "se": fin(se_x2), "n_obs": int(n)},
    {"term": "z_cat2", "estimate": fin(z_cat2), "se": fin(se_z2), "n_obs": int(n)},
    {"term": "prob_cat2_zero", "estimate": fin(prob_cat2_zero), "se": fin(se_prob), "n_obs": int(n)},
]

output = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": rows,
    "method_metadata": {
        "estimator": "multinomial logit, maximum likelihood, base outcome 0",
        "vcov": "observed information (inverse Hessian)",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
