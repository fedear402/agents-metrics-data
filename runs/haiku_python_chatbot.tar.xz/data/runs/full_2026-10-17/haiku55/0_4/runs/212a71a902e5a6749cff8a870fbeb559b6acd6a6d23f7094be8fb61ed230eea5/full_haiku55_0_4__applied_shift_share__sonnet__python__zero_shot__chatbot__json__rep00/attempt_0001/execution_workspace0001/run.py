import json

import numpy as np
import pandas as pd


def wiv(y, X, Z, w):
    N = len(y)
    ZW = Z * w[:, None]
    ZWZinv = np.linalg.inv(Z.T @ ZW)
    M = X.T @ ZW @ ZWZinv
    A = M @ (ZW.T @ X)
    b = np.linalg.solve(A, M @ (ZW.T @ y))
    u = y - X @ b
    Zm = Z @ M.T
    sc = (w * u)[:, None] * Zm
    meat = sc.T @ sc
    Ainv = np.linalg.inv(A)
    V = Ainv @ meat @ Ainv.T * N / (N - 2)
    return b, np.sqrt(np.diag(V))


df = pd.read_csv("input.csv")

z_reg = (df.assign(sz=df["share"] * df["shock"])
           .groupby("region_id")["sz"].sum())
reg = df.groupby("region_id").agg(
    region_weight=("region_weight", "first"),
    x=("x", "first"),
    y=("y", "first"),
)
reg["z"] = z_reg
reg["e"] = reg["region_weight"] / reg["region_weight"].sum()
for v in ["y", "x", "z"]:
    reg[v + "0"] = reg[v] - np.sum(reg["e"] * reg[v])

effect_reg = np.sum(reg["e"] * reg["z0"] * reg["y0"]) / np.sum(reg["e"] * reg["z0"] * reg["x0"])
first_reg = np.sum(reg["e"] * reg["z0"] * reg["x0"]) / np.sum(reg["e"] * reg["z0"] ** 2)

df = df.join(reg[["e", "y0", "x0", "z0"]], on="region_id")
df["ew"] = df["e"] * df["share"]
s = df.groupby("industry_id")["ew"].sum()


def agg(col):
    t = df.assign(t=df["ew"] * df[col]).groupby("industry_id")["t"].sum()
    return t / s


ybar = agg("y0")
xbar = agg("x0")
zbar = agg("z0")
shock = df.groupby("industry_id")["shock"].first()

N = len(s)
one = np.ones(N)
w = s.values

X_eff = np.column_stack([one, xbar.values])
Z_eff = np.column_stack([one, shock.values])
b_eff, se_eff = wiv(ybar.values, X_eff, Z_eff, w)

X_fs = np.column_stack([one, zbar.values])
b_fs, se_fs = wiv(xbar.values, X_fs, Z_eff, w)

eff_shocks = 1.0 / np.sum(s.values ** 2)

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": float(effect_reg), "se": float(se_eff[1]), "n_obs": int(N)},
        {"term": "first_stage", "estimate": float(first_reg), "se": float(se_fs[1]), "n_obs": int(N)},
        {"term": "effective_shocks", "estimate": float(eff_shocks), "se": None, "n_obs": int(N)},
    ],
    "method_metadata": {
        "estimator": "Weighted 2SLS of y on x instrumenting x with shift-share z (regional weights e_r), with BHJ shock-level weighted IV aggregation",
        "vcov": "BHJ shock-level HC1 heteroskedasticity-robust, N/(N-2) multiplier, structural residuals, analytic weights, no clustering",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
