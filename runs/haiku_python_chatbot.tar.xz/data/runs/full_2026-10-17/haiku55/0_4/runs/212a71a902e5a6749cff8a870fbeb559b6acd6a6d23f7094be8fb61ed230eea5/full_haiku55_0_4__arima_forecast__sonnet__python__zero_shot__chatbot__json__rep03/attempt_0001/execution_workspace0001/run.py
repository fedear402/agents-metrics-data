import json

import numpy as np
import pandas as pd
from scipy.stats import norm
from statsmodels.tsa.arima.model import ARIMA

df = pd.read_csv("./input.csv")
df = df.dropna(subset=["t", "y"]).sort_values("t").reset_index(drop=True)
y = df["y"].astype(float)
n_obs = int(len(y))

model = ARIMA(y, order=(1, 1, 1), trend="n")
res = model.fit()

fc = res.get_forecast(steps=1)
mean = float(np.asarray(fc.predicted_mean)[0])
se = float(np.sqrt(np.asarray(fc.var_pred_mean)[0]))
z = float(norm.ppf(0.975))
lower = mean - z * se
upper = mean + z * se

params = res.params
diagnostics = {
    "ar1": float(params.get("ar.L1", np.nan)),
    "ma1": float(params.get("ma.L1", np.nan)),
    "sigma2": float(params.get("sigma2", np.nan)),
    "loglikelihood": float(res.llf),
    "aic": float(res.aic),
    "bic": float(res.bic),
    "converged": bool(res.mle_retvals.get("converged", True)) if getattr(res, "mle_retvals", None) else True,
}

output = {
    "task_id": "arima_forecast",
    "platform": "python",
    "estimates": [
        {"term": "forecast", "estimate": mean, "se": se, "n_obs": n_obs},
        {"term": "lower_95", "estimate": lower, "se": None, "n_obs": n_obs},
        {"term": "upper_95", "estimate": upper, "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "ARIMA(1,1,1) exact maximum likelihood, no constant (statsmodels state space)",
        "vcov": "opg",
    },
    "diagnostics": diagnostics,
}

with open("result.json", "w") as f:
    json.dump(output, f, indent=2)
