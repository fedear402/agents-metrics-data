import json

import numpy as np
import pandas as pd
from scipy.stats import f

df_in = pd.read_csv("input.csv")
y = df_in["y"].to_numpy(dtype=float)
endog = df_in["endog"].to_numpy(dtype=float)
x = df_in["x"].to_numpy(dtype=float)
z1 = df_in["z1"].to_numpy(dtype=float)
z2 = df_in["z2"].to_numpy(dtype=float)
n = len(y)

controls = np.column_stack([np.ones(n), x])
full = np.column_stack([controls, z1, z2])
q = 2
dfree = n - full.shape[1]
critical = f.ppf(0.95, q, dfree)


def residual(v, design):
    return v - design @ np.linalg.lstsq(design, v, rcond=None)[0]


def ar_f(beta):
    yb = y - beta * endog
    r = residual(yb, controls)
    u = residual(yb, full)
    ssr_r = r @ r
    ssr_u = u @ u
    return ((ssr_r - ssr_u) / q) / (ssr_u / dfree)


# Quadratic form of acceptance: SSR_R(b) - (1 + k) * SSR_U(b) <= 0
ry = residual(y, controls)
rd = residual(endog, controls)
uy = residual(y, full)
ud = residual(endog, full)
k = q * critical / dfree

A = rd @ rd - (1 + k) * (ud @ ud)
B = -2 * (ry @ rd - (1 + k) * (uy @ ud))
C = ry @ ry - (1 + k) * (uy @ uy)

discriminant = B * B - 4 * A * C
assert abs(A) > 1e-10 and discriminant > 0

roots = np.sort(np.roots([A, B, C]).real)
boundary_low, boundary_high = float(roots[0]), float(roots[1])


def accepts(beta):
    return A * beta * beta + B * beta + C <= 0


unbounded = int(A < 0)
accepts_zero = int(accepts(0.0))
ar_at_one = float(ar_f(1.0))

for b in (boundary_low, boundary_high):
    assert np.isclose(ar_f(b), critical, atol=1e-6)

rows = [
    {"term": "boundary_low", "estimate": boundary_low, "se": None, "n_obs": n},
    {"term": "boundary_high", "estimate": boundary_high, "se": None, "n_obs": n},
    {"term": "accepts_zero", "estimate": accepts_zero, "se": None, "n_obs": n},
    {"term": "unbounded", "estimate": unbounded, "se": None, "n_obs": n},
    {"term": "ar_f_at_one", "estimate": ar_at_one, "se": None, "n_obs": n},
]

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": rows,
    "method_metadata": {
        "estimator": "Anderson-Rubin confidence set inversion of homoskedastic joint F test",
        "vcov": "homoskedastic",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
