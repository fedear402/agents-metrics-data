import json

import numpy as np
import pandas as pd

df = pd.read_csv('input.csv')[['id', 'time', 'g', 'y']]

cohorts = [3, 5, 7]
att = {}
row_counts = {}
treated_counts = {}
control_counts = {}

for c in cohorts:
    lo, hi = c - 2, c + 2
    window = df[(df['time'] >= lo) & (df['time'] <= hi)]
    eligible = window[(window['g'] == c) | (window['g'] == 0) | (window['g'] > c + 2)]
    n_times = eligible.groupby('id')['time'].nunique()
    keep_ids = n_times[n_times == hi - lo + 1].index
    sub = eligible[eligible['id'].isin(keep_ids)].sort_values(['id', 'time']).reset_index(drop=True)

    did = ((sub['g'] == c) & (sub['time'] >= c)).astype(float).to_numpy()
    unit_dummies = pd.get_dummies(sub['id'].astype(str), drop_first=True, dtype=float).to_numpy()
    time_dummies = pd.get_dummies(sub['time'].astype(str), drop_first=True, dtype=float).to_numpy()
    design = np.column_stack([np.ones(len(sub)), did, unit_dummies, time_dummies])
    beta = np.linalg.lstsq(design, sub['y'].to_numpy(dtype=float), rcond=None)[0]

    att[c] = float(beta[1])
    row_counts[c] = int(len(sub))
    treated_counts[c] = int(sub.loc[sub['g'] == c, 'id'].nunique())
    control_counts[c] = int(sub.loc[sub['g'] != c, 'id'].nunique())

total_treated = sum(treated_counts.values())
att_weighted = float(sum(treated_counts[c] * att[c] for c in cohorts) / total_treated)
total_rows = int(sum(row_counts.values()))

estimates = [
    {'term': 'att_g3', 'estimate': att[3], 'se': None, 'n_obs': row_counts[3]},
    {'term': 'att_g5', 'estimate': att[5], 'se': None, 'n_obs': row_counts[5]},
    {'term': 'att_g7', 'estimate': att[7], 'se': None, 'n_obs': row_counts[7]},
    {'term': 'att_weighted', 'estimate': att_weighted, 'se': None, 'n_obs': total_rows},
]

output = {
    'task_id': 'broad_cohort_stack',
    'platform': 'python',
    'estimates': estimates,
    'method_metadata': {
        'estimator': 'cohort-specific stacked difference-in-differences with unit and calendar-time fixed effects',
        'cohorts': cohorts,
        'windows': {str(c): [c - 2, c + 2] for c in cohorts},
        'weighting': 'number of retained treated units per cohort',
    },
    'diagnostics': {
        'retained_treated_units': {str(c): treated_counts[c] for c in cohorts},
        'retained_control_units': {str(c): control_counts[c] for c in cohorts},
        'retained_rows': {str(c): row_counts[c] for c in cohorts},
    },
}

with open('result.json', 'w') as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
