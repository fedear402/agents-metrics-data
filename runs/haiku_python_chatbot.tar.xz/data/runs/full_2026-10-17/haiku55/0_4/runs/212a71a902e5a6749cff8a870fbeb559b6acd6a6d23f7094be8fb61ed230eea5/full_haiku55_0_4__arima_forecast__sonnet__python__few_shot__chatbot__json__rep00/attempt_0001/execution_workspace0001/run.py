import json

import numpy as np
import pandas as pd
from statsmodels.tsa.arima.model import ARIMA

df = pd.read_csv("input.csv").sort_values("t").dropna(subset=["y"])
y = df["y"].astype(float).to_numpy()

fit = ARIMA(y, order=(1, 1, 1), trend="n").fit()
fc = fit.get_forecast(steps=1)

mean = float(np.asarray(fc.predicted_mean)[0])
lower, upper = (float(v) for v in np.asarray(fc.conf_int(alpha=0.05))[0])
se = float((upper - lower) / (2 * 1.959963984540054))
n_obs = int(fit.nobs)

out = {
    "task_id": "arima_forecast",
    "platform": "python",
    "estimates": [
        {"term": "forecast", "estimate": mean, "se": se, "n_obs": n_obs},
        {"term": "lower_95", "estimate": lower, "se": None, "n_obs": n_obs},
        {"term": "upper_95", "estimate": upper, "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "ARIMA(1,1,1) no constant, MLE",
        "vcov": "statespace information matrix",
    },
    "diagnostics": {"aic": float(fit.aic)},
}

with open("result.json", "w") as f:
    json.dump(out, f)
