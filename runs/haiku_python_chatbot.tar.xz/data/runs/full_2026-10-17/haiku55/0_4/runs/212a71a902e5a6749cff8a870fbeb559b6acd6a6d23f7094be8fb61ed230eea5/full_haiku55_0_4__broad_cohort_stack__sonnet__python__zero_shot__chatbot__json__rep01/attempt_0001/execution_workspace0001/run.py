import json

import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
df["id"] = df["id"].astype(int)
df["time"] = df["time"].astype(int)
df["g"] = df["g"].astype(int)
df["y"] = df["y"].astype(float)

cohorts = [3, 5, 7]
comparisons = {}

for c in cohorts:
    window = list(range(c - 2, c + 3))
    sub = df[df["time"].isin(window)]
    elig = sub[(sub["g"] == c) | (sub["g"] == 0) | (sub["g"] > c + 2)]

    obs_counts = elig.groupby("id")["time"].nunique()
    full_ids = obs_counts[obs_counts == len(window)].index
    comp = elig[elig["id"].isin(full_ids)].copy()

    comp["did"] = ((comp["g"] == c) & (comp["time"] >= c)).astype(float)
    n_treated = int(comp.loc[comp["g"] == c, "id"].nunique())

    unit_dum = pd.get_dummies(comp["id"], drop_first=True).astype(float).values
    time_dum = pd.get_dummies(comp["time"], drop_first=True).astype(float).values
    X = np.column_stack([
        np.ones(len(comp)),
        comp["did"].values,
        unit_dum,
        time_dum,
    ])
    y = comp["y"].values

    beta = np.linalg.lstsq(X, y, rcond=None)[0]
    comparisons[c] = {
        "att": float(beta[1]),
        "n_obs": int(len(comp)),
        "n_treated": n_treated,
    }

estimates = []
for c in cohorts:
    estimates.append({
        "term": f"att_g{c}",
        "estimate": repr(comparisons[c]["att"]),
        "se": None,
        "n_obs": comparisons[c]["n_obs"],
    })

total_w = sum(comparisons[c]["n_treated"] for c in cohorts)
att_weighted = sum(comparisons[c]["n_treated"] * comparisons[c]["att"] for c in cohorts) / total_w
total_obs = sum(comparisons[c]["n_obs"] for c in cohorts)

estimates.append({
    "term": "att_weighted",
    "estimate": repr(float(att_weighted)),
    "se": None,
    "n_obs": total_obs,
})

result = {
    "task_id": "broad_cohort_stack",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {},
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
