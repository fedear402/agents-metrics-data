import json

import numpy as np
import pandas as pd
from scipy.stats import f

data = pd.read_csv("input.csv")
n = len(data)
y = data["y"].to_numpy(dtype=float)
endog = data["endog"].to_numpy(dtype=float)
x = data["x"].to_numpy(dtype=float)
z = data[["z1", "z2"]].to_numpy(dtype=float)

ones = np.ones((n, 1))
X_restricted = np.column_stack([ones, x])
X_full = np.column_stack([ones, x, z])
q = z.shape[1]
df_resid = n - X_full.shape[1]


def residual(v, X):
    return v - X @ np.linalg.lstsq(X, v, rcond=None)[0]


def ssr_coefficients(X):
    r0 = residual(y, X)
    r1 = residual(endog, X)
    c0 = r0 @ r0
    c1 = -2.0 * (r0 @ r1)
    c2 = r1 @ r1
    return np.array([c0, c1, c2])


def f_stat(beta):
    rr = residual(y - beta * endog, X_restricted)
    ru = residual(y - beta * endog, X_full)
    ssr_r = rr @ rr
    ssr_u = ru @ ru
    return ((ssr_r - ssr_u) / q) / (ssr_u / df_resid)


critical = f.ppf(0.95, q, df_resid)
k = q * critical / df_resid

cR = ssr_coefficients(X_restricted)
cU = ssr_coefficients(X_full)
coef = cR - (1.0 + k) * cU
C, B, A = coef[0], coef[1], coef[2]

assert abs(A) > 1e-12
discriminant = B * B - 4.0 * A * C
assert discriminant > 0
boundaries = np.sort(np.roots([A, B, C]).real)


def accepts(beta):
    return A * beta * beta + B * beta + C <= 0


unbounded = int(A < 0)
accepts_zero = int(accepts(0.0))
ar_f_at_one = float(f_stat(1.0))

for boundary in boundaries:
    assert np.isclose(f_stat(boundary), critical, atol=1e-8)

rows = [
    {"term": "boundary_low", "estimate": float(boundaries[0]), "se": None, "n_obs": int(n)},
    {"term": "boundary_high", "estimate": float(boundaries[1]), "se": None, "n_obs": int(n)},
    {"term": "accepts_zero", "estimate": float(accepts_zero), "se": None, "n_obs": int(n)},
    {"term": "unbounded", "estimate": float(unbounded), "se": None, "n_obs": int(n)},
    {"term": "ar_f_at_one", "estimate": ar_f_at_one, "se": None, "n_obs": int(n)},
]

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": rows,
    "method_metadata": {
        "estimator": "Anderson-Rubin confidence set by test inversion",
        "vcov": "homoskedastic",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
