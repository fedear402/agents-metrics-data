import json

import numpy as np
import pandas as pd

hh = pd.read_csv("households.csv")
cen = pd.read_csv("census.csv")

df = hh[hh["recipient"] == 0].copy()
n_obs = int(len(df))

e = df["eligible"].astype(float).to_numpy()
ne = 1.0 - e
dose = df["dose"].astype(float).to_numpy()
base = df["baseline"].astype(float).to_numpy()
inst = df["instrument"].astype(float).to_numpy()
w = df["weight"].astype(float).to_numpy()
y = df["outcome"].astype(float).to_numpy()

X = np.column_stack([
    dose * ne,
    dose * e,
    ne,
    e,
    base * ne,
    base * e,
])

Z = np.column_stack([
    ne,
    e,
    base * ne,
    base * e,
    inst * ne,
    inst * e,
])

ZtW = Z.T * w
ZtWZ = ZtW @ Z
ZtWX = ZtW @ X
PX = Z @ np.linalg.solve(ZtWZ, ZtWX)
PXtW = PX.T * w
beta = np.linalg.solve(PXtW @ X, PXtW @ y)

sum_w0 = np.sum(w * ne)
sum_w1 = np.sum(w * e)
m0 = np.sum(w * dose * ne) / sum_w0
m1 = np.sum(w * dose * e) / sum_w1

ineligible_effect = float(beta[0] * m0)
eligible_nonrecipient_effect = float(beta[1] * m1)

N0 = float(cen.loc[cen["eligible"] == 0, "nonrecipient_population"].sum())
N1 = float(cen.loc[cen["eligible"] == 1, "nonrecipient_population"].sum())
p0 = N0 / (N0 + N1)
p1 = N1 / (N0 + N1)

population_effect = float(p0 * ineligible_effect + p1 * eligible_nonrecipient_effect)

n_ineligible = int(np.sum(ne == 1))
n_eligible = int(np.sum(e == 1))

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "ineligible_effect",
            "estimate": ineligible_effect,
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "eligible_nonrecipient_effect",
            "estimate": eligible_nonrecipient_effect,
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "population_effect",
            "estimate": population_effect,
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "method": "weighted two-stage least squares",
        "regression_weight": "weight",
        "endogenous_columns": ["dose*(1-eligible)", "dose*eligible"],
        "exogenous_columns": ["1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"],
        "instrument_columns": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
            "instrument*(1-eligible)",
            "instrument*eligible",
        ],
        "intercept": False,
        "sample": "households with recipient == 0, both treatment statuses retained",
        "group_effect_definition": "dose slope times weighted mean dose among retained group observations",
        "population_weights_source": "nonrecipient_population from census.csv",
        "counterfactual": "dose set to zero for every retained household",
        "attribution_note": "zero-dose counterfactual attribution is a stated synthetic convention",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "n_ineligible": n_ineligible,
        "n_eligible": n_eligible,
        "dose_slope_ineligible": float(beta[0]),
        "dose_slope_eligible": float(beta[1]),
        "weighted_mean_dose_ineligible": float(m0),
        "weighted_mean_dose_eligible": float(m1),
        "census_nonrecipient_population_ineligible": N0,
        "census_nonrecipient_population_eligible": N1,
        "population_weight_ineligible": float(p0),
        "population_weight_eligible": float(p1),
        "instrument_rank": int(np.linalg.matrix_rank(Z * np.sqrt(w)[:, None])),
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
