import json

import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS

households = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

d = households[households["recipient"] == 0].copy()
d["ex_ineligible"] = 1 - d["eligible"]
d["ex_eligible"] = d["eligible"]
d["baseline_ineligible"] = d["baseline"] * (1 - d["eligible"])
d["baseline_eligible"] = d["baseline"] * d["eligible"]
d["dose_ineligible"] = d["dose"] * (1 - d["eligible"])
d["dose_eligible"] = d["dose"] * d["eligible"]
d["instrument_ineligible"] = d["instrument"] * (1 - d["eligible"])
d["instrument_eligible"] = d["instrument"] * d["eligible"]

exog_cols = ["ex_ineligible", "ex_eligible", "baseline_ineligible", "baseline_eligible"]
endog_cols = ["dose_ineligible", "dose_eligible"]
instrument_cols = exog_cols + ["instrument_ineligible", "instrument_eligible"]

fit = IV2SLS(
    d["outcome"],
    d[exog_cols],
    d[endog_cols],
    d[instrument_cols],
    weights=d["weight"],
).fit()

slope_ineligible = float(fit.params["dose_ineligible"])
slope_eligible = float(fit.params["dose_eligible"])

ineligible = d[d["eligible"] == 0]
eligible = d[d["eligible"] == 1]

mean_dose_ineligible = float(np.average(ineligible["dose"], weights=ineligible["weight"]))
mean_dose_eligible = float(np.average(eligible["dose"], weights=eligible["weight"]))

ineligible_effect = slope_ineligible * mean_dose_ineligible
eligible_nonrecipient_effect = slope_eligible * mean_dose_eligible

pop = census.set_index("eligible")["nonrecipient_population"]
between_group_weights = [float(pop.loc[0]), float(pop.loc[1])]
population_effect = float(
    np.average([ineligible_effect, eligible_nonrecipient_effect], weights=between_group_weights)
)

n_obs = int(len(d))

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "ineligible_effect",
            "estimate": float(ineligible_effect),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "eligible_nonrecipient_effect",
            "estimate": float(eligible_nonrecipient_effect),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "population_effect",
            "estimate": float(population_effect),
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "endogenous": endog_cols,
        "exogenous": exog_cols,
        "instruments": instrument_cols,
        "regression_weight": "weight",
        "sample": "recipient == 0",
        "counterfactual": "dose set to zero for every retained household (synthetic attribution convention)",
        "between_group_weights": "census nonrecipient_population by eligibility group",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "slope_ineligible": slope_ineligible,
        "slope_eligible": slope_eligible,
        "weighted_mean_dose_ineligible": mean_dose_ineligible,
        "weighted_mean_dose_eligible": mean_dose_eligible,
        "census_weights": between_group_weights,
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
