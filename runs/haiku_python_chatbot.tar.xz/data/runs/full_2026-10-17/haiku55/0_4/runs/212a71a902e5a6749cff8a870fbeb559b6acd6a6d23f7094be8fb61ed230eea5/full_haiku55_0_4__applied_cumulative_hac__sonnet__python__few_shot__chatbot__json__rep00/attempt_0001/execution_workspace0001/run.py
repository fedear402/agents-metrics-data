import json

import numpy as np
import pandas as pd

LAGS = 15

data = pd.read_csv("input.csv")
data["date"] = pd.to_datetime(data["date"])
data = data.sort_values("date").reset_index(drop=True)

data["log_sales"] = np.log(data["sales"])
data["vol_change"] = np.log(data["vix"]).diff()
lag_cols = [f"lag_{j}" for j in range(1, LAGS + 1)]
for j, col in enumerate(lag_cols, start=1):
    data[col] = data["vol_change"].shift(j)

sample = data.dropna(subset=["log_sales"] + lag_cols).reset_index(drop=True)
N = len(sample)

X = np.column_stack([np.ones(N), sample[lag_cols].to_numpy()])
y = sample["log_sales"].to_numpy()
beta = np.linalg.lstsq(X, y, rcond=None)[0]
resid = y - X @ beta

scores = X * resid[:, None]
meat = scores.T @ scores
for j in range(1, LAGS + 1):
    weight = 1 - j / (LAGS + 1)
    gamma = scores[j:].T @ scores[:-j]
    meat += weight * (gamma + gamma.T)

bread = np.linalg.inv(X.T @ X)
p = X.shape[1]
cov = (N / (N - p)) * bread @ meat @ bread

contrast = np.zeros(p)
contrast[1:] = 1.0
cumulative = float(contrast @ beta)
cumulative_se = float(np.sqrt(contrast @ cov @ contrast))

rows = [
    {
        "term": "cumulative_response",
        "estimate": cumulative,
        "se": cumulative_se,
        "n_obs": int(N),
    },
    {
        "term": "lag_1",
        "estimate": float(beta[1]),
        "se": float(np.sqrt(cov[1, 1])),
        "n_obs": int(N),
    },
    {
        "term": "lag_15",
        "estimate": float(beta[LAGS]),
        "se": float(np.sqrt(cov[LAGS, LAGS])),
        "n_obs": int(N),
    },
]

output = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": rows,
    "method_metadata": {
        "estimator": "OLS regression of log(sales) on intercept and lags 1-15 of diff(log(vix))",
        "vcov": "Newey-West HAC, max lag 15, Bartlett weights 1-j/16, scaled by N/(N-16)",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
