import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy.special import softmax

df = pd.read_csv("input.csv")
n = len(df)

X = sm.add_constant(df[["x", "z"]].astype(float), has_constant="add")
y = df["y"].astype(int).to_numpy()
fit = sm.MNLogit(y, X).fit(disp=False, method="newton", maxiter=500, tol=1e-10)

params = fit.params.copy()
bse = fit.bse.copy()
params.columns = [1, 2]
bse.columns = [1, 2]

x_cat1, z_cat1 = params.loc["x", 1], params.loc["z", 1]
se_x_cat1, se_z_cat1 = bse.loc["x", 1], bse.loc["z", 1]
x_cat2, z_cat2 = params.loc["x", 2], params.loc["z", 2]
se_x_cat2, se_z_cat2 = bse.loc["x", 2], bse.loc["z", 2]

pred_in = pd.DataFrame({"const": [1.0], "x": [0.0], "z": [0.0]})
p_all = np.asarray(fit.predict(pred_in))[0]
prob_cat2_zero = float(p_all[2])

# Delta-method SE for P(y=2) at x=0, z=0
beta = np.column_stack([np.zeros(3), np.r_[params.loc["const", 1], params.loc["x", 1], params.loc["z", 1]],
                        np.r_[params.loc["const", 2], params.loc["x", 2], params.loc["z", 2]]])
vcov = fit.cov_params()
names = list(fit.params.index)
idx = {}
for k, eq in enumerate([1, 2]):
    for j, nm in enumerate(["const", "x", "z"]):
        idx[(nm, eq)] = names.index(nm) if False else None

k_per_eq = len(X.columns)
cov = np.asarray(vcov)
eta = np.array([0.0, float(params.loc["const", 1]), float(params.loc["const", 2])])
v = np.array([1.0, 0.0, 0.0])
grad_eta = np.zeros((3, 2 * k_per_eq))
p = p_all
for j in range(3):
    for m in range(2 * k_per_eq):
        pass
g = np.zeros(2 * k_per_eq)
for eq_i, eq in enumerate([1, 2]):
    dp_deta = p[2] * ((1.0 if eq == 2 else 0.0) - p[eq])
    g[eq_i * k_per_eq + 0] = dp_deta * 1.0
se_prob = float(np.sqrt(max(g @ cov @ g, 0.0)))

out = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": [
        {"term": "x_cat1", "estimate": float(x_cat1), "se": float(se_x_cat1), "n_obs": int(n)},
        {"term": "z_cat1", "estimate": float(z_cat1), "se": float(se_z_cat1), "n_obs": int(n)},
        {"term": "x_cat2", "estimate": float(x_cat2), "se": float(se_x_cat2), "n_obs": int(n)},
        {"term": "z_cat2", "estimate": float(z_cat2), "se": float(se_z_cat2), "n_obs": int(n)},
        {"term": "prob_cat2_zero", "estimate": prob_cat2_zero, "se": None, "n_obs": int(n)},
    ],
    "method_metadata": {
        "estimator": "multinomial logit maximum likelihood",
        "vcov": "conventional observed-information (inverse Hessian)",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(out, stream, indent=2, allow_nan=False)
