import json

import numpy as np
import pandas as pd

hh = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

numeric_cols = ["eligible", "treated", "recipient", "instrument", "dose", "baseline", "weight", "outcome"]
for col in numeric_cols:
    hh[col] = pd.to_numeric(hh[col])

df = hh[hh["recipient"] == 0].copy()

e = df["eligible"].to_numpy(dtype=float)
n0 = 1.0 - e
dose = df["dose"].to_numpy(dtype=float)
base = df["baseline"].to_numpy(dtype=float)
inst = df["instrument"].to_numpy(dtype=float)
w = df["weight"].to_numpy(dtype=float)
y = df["outcome"].to_numpy(dtype=float)

endog = np.column_stack([dose * n0, dose * e])
exog = np.column_stack([n0, e, base * n0, base * e])
excl = np.column_stack([inst * n0, inst * e])

R = np.column_stack([endog, exog])
Z = np.column_stack([exog, excl])

sw = np.sqrt(w)
Rw = R * sw[:, None]
Zw = Z * sw[:, None]
yw = y * sw

Zw_coef = np.linalg.lstsq(Zw, Rw, rcond=None)[0]
Rhat = Zw @ Zw_coef
Pz_y = Zw @ np.linalg.lstsq(Zw, yw, rcond=None)[0]
beta = np.linalg.lstsq(Rhat, Pz_y, rcond=None)[0]

slope_ineligible = float(beta[0])
slope_eligible = float(beta[1])

mask0 = n0 == 1.0
mask1 = e == 1.0
mean_dose_0 = float(np.sum(w[mask0] * dose[mask0]) / np.sum(w[mask0]))
mean_dose_1 = float(np.sum(w[mask1] * dose[mask1]) / np.sum(w[mask1]))

ineligible_effect = slope_ineligible * mean_dose_0
eligible_nonrecipient_effect = slope_eligible * mean_dose_1

census_totals = census.groupby("eligible")["nonrecipient_population"].sum()
N0 = float(census_totals.loc[0])
N1 = float(census_totals.loc[1])
population_effect = (N0 * ineligible_effect + N1 * eligible_nonrecipient_effect) / (N0 + N1)

n_obs = int(len(df))
n_ineligible = int(mask0.sum())
n_eligible = int(mask1.sum())

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "ineligible_effect",
            "estimate": float(ineligible_effect),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "eligible_nonrecipient_effect",
            "estimate": float(eligible_nonrecipient_effect),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "population_effect",
            "estimate": float(population_effect),
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "weighted two-stage least squares",
        "regression_weight": "weight",
        "endogenous_columns": ["dose*(1-eligible)", "dose*eligible"],
        "exogenous_columns": ["1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"],
        "instrument_columns": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
            "instrument*(1-eligible)",
            "instrument*eligible",
        ],
        "intercept": False,
        "sample": "households with recipient == 0, all treatment statuses retained",
        "group_effect_definition": "fitted dose slope times weighted mean dose within eligibility group",
        "population_weights": "census nonrecipient_population by eligibility group",
        "counterfactual": "dose set to zero for every retained household (synthetic attribution convention)",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "n_obs_ineligible": n_ineligible,
        "n_obs_eligible": n_eligible,
        "slope_dose_ineligible": slope_ineligible,
        "slope_dose_eligible": slope_eligible,
        "weighted_mean_dose_ineligible": mean_dose_0,
        "weighted_mean_dose_eligible": mean_dose_1,
        "census_nonrecipient_population_ineligible": N0,
        "census_nonrecipient_population_eligible": N1,
        "instrument_matrix_rank": int(np.linalg.matrix_rank(Zw)),
        "regressor_matrix_columns": int(R.shape[1]),
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
