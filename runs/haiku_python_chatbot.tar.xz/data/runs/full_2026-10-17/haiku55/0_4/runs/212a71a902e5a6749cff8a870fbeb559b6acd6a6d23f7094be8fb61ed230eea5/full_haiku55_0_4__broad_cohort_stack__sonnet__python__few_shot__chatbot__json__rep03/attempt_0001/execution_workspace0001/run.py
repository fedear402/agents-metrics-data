import json

import numpy as np
import pandas as pd

df = pd.read_csv('input.csv')

cohorts = [3, 5, 7]
att = {}
n_treated = {}
n_rows = {}
for c in cohorts:
    lo, hi = c - 2, c + 2
    win = df[(df['time'] >= lo) & (df['time'] <= hi)]
    elig = win[(win['g'] == c) | (win['g'] == 0) | (win['g'] > c + 2)]
    counts = elig.groupby('id')['time'].nunique()
    keep_ids = counts[counts == hi - lo + 1].index
    sub = elig[elig['id'].isin(keep_ids)].copy()
    sub['did'] = ((sub['g'] == c) & (sub['time'] >= c)).astype(float)

    X = np.column_stack([
        np.ones(len(sub)),
        sub['did'].to_numpy(dtype=float),
        pd.get_dummies(sub['id'].astype(str), drop_first=True, dtype=float).to_numpy(),
        pd.get_dummies(sub['time'].astype(str), drop_first=True, dtype=float).to_numpy(),
    ])
    y = sub['y'].to_numpy(dtype=float)
    beta = np.linalg.lstsq(X, y, rcond=None)[0]

    att[c] = float(beta[1])
    n_treated[c] = int(sub.loc[sub['g'] == c, 'id'].nunique())
    n_rows[c] = int(len(sub))

total_w = sum(n_treated[c] for c in cohorts)
att_weighted = float(sum(n_treated[c] * att[c] for c in cohorts) / total_w)
total_rows = sum(n_rows[c] for c in cohorts)

output = {
    'task_id': 'broad_cohort_stack',
    'platform': 'python',
    'estimates': [
        {'term': 'att_g3', 'estimate': att[3], 'se': None, 'n_obs': n_rows[3]},
        {'term': 'att_g5', 'estimate': att[5], 'se': None, 'n_obs': n_rows[5]},
        {'term': 'att_g7', 'estimate': att[7], 'se': None, 'n_obs': n_rows[7]},
        {'term': 'att_weighted', 'estimate': att_weighted, 'se': None, 'n_obs': total_rows},
    ],
    'method_metadata': {
        'design': 'cohort-specific stacked DiD with unit and calendar-time fixed effects',
        'window': 'calendar times c-2 through c+2 for each cohort c',
        'eligible_controls': 'g=0 or g>c+2',
        'weighting': 'retained treated unit counts per cohort',
    },
    'diagnostics': {
        'retained_treated_units': {f'g{c}': n_treated[c] for c in cohorts},
        'retained_rows': {f'g{c}': n_rows[c] for c in cohorts},
        'total_weight': int(total_w),
    },
}

with open('result.json', 'w') as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
