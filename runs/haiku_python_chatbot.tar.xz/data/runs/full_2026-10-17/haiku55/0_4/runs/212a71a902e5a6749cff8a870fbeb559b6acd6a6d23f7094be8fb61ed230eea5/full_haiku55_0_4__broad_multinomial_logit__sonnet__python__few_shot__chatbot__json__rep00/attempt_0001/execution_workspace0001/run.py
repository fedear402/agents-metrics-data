import json

import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy.special import softmax

df = pd.read_csv("input.csv")
n = len(df)

X = sm.add_constant(df[["x", "z"]].astype(float), has_constant="add")
y = df["y"].astype(int).to_numpy()
fit = sm.MNLogit(y, X).fit(disp=False, tol=1e-10, method="newton", maxiter=500)

coefficients = fit.params.copy()
errors = fit.bse.copy()
coefficients.columns = [1, 2]
errors.columns = [1, 2]

pred_input = pd.DataFrame({"const": [1.0], "x": [0.0], "z": [0.0]})
probs = np.asarray(fit.predict(pred_input))[0]
prob_cat2_zero = float(probs[2])

def get(term, outcome):
    return float(coefficients.loc[term, outcome]), float(errors.loc[term, outcome])

x_cat1, _ = get("x", 1)
z_cat1, _ = get("z", 1)
x_cat2, _ = get("x", 2)
z_cat2, _ = get("z", 2)

_, x_cat1_se = get("x", 1)
_, z_cat1_se = get("z", 1)
_, x_cat2_se = get("x", 2)
_, z_cat2_se = get("z", 2)

result = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": [
        {"term": "x_cat1", "estimate": x_cat1, "se": x_cat1_se, "n_obs": int(n)},
        {"term": "z_cat1", "estimate": z_cat1, "se": z_cat1_se, "n_obs": int(n)},
        {"term": "x_cat2", "estimate": x_cat2, "se": x_cat2_se, "n_obs": int(n)},
        {"term": "z_cat2", "estimate": z_cat2, "se": z_cat2_se, "n_obs": int(n)},
        {"term": "prob_cat2_zero", "estimate": prob_cat2_zero, "se": None, "n_obs": int(n)},
    ],
    "method_metadata": {
        "estimator": "multinomial logit (maximum likelihood, base outcome 0)",
        "vcov": "observed information (inverse Hessian)",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
