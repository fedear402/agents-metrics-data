import json

import pandas as pd
import statsmodels.api as sm
from statsmodels.formula.api import ols
from statsmodels.stats.anova import anova_lm

df = pd.read_csv("./input.csv")
df = df.dropna(subset=["group", "y"])
df["group"] = df["group"].astype("category")

model = ols("y ~ C(group)", data=df).fit()
anova = anova_lm(model, typ=1)

row = anova.loc["C(group)"]
f_stat = float(row["F"])
df_num = float(row["df"])
df_den = float(anova.loc["Residual", "df"])
p_value = float(row["PR(>F)"])
n_obs = int(model.nobs)

result = {
    "task_id": "anova_oneway",
    "platform": "python",
    "estimates": [
        {"term": "F", "estimate": f_stat, "se": None, "n_obs": n_obs},
        {"term": "df_num", "estimate": df_num, "se": None, "n_obs": n_obs},
        {"term": "df_den", "estimate": df_den, "se": None, "n_obs": n_obs},
        {"term": "p_value", "estimate": p_value, "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "one-way ANOVA (OLS with categorical group, Type I sums of squares)",
        "vcov": "nonrobust",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
