import json

import numpy as np
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("input.csv")
n_obs = int(len(df))

X = sm.add_constant(df[["x", "z"]].astype(float), has_constant="add")
y = df["y"].astype(int)

model = sm.MNLogit(y, X)
res = model.fit(method="newton", maxiter=500, tol=1e-10, disp=0)

params = res.params
bse = res.bse

x_cat1 = float(params.loc["x", 1])
z_cat1 = float(params.loc["z", 1])
x_cat2 = float(params.loc["x", 2])
z_cat2 = float(params.loc["z", 2])
se_x_cat1 = float(bse.loc["x", 1])
se_z_cat1 = float(bse.loc["z", 1])
se_x_cat2 = float(bse.loc["x", 2])
se_z_cat2 = float(bse.loc["z", 2])

const1 = float(params.loc["const", 1])
const2 = float(params.loc["const", 2])
denom = 1.0 + np.exp(const1) + np.exp(const2)
prob_cat2_zero = float(np.exp(const2) / denom)

converged = bool(res.mle_retvals.get("converged", True)) if getattr(res, "mle_retvals", None) else True

result = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": [
        {"term": "x_cat1", "estimate": x_cat1, "se": se_x_cat1, "n_obs": n_obs},
        {"term": "z_cat1", "estimate": z_cat1, "se": se_z_cat1, "n_obs": n_obs},
        {"term": "x_cat2", "estimate": x_cat2, "se": se_x_cat2, "n_obs": n_obs},
        {"term": "z_cat2", "estimate": z_cat2, "se": se_z_cat2, "n_obs": n_obs},
        {"term": "prob_cat2_zero", "estimate": prob_cat2_zero, "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "multinomial logit maximum likelihood (statsmodels MNLogit, base outcome 0)",
        "vcov": "conventional observed-information (inverse negative Hessian at MLE)",
    },
    "diagnostics": {
        "converged": converged,
        "log_likelihood": float(res.llf),
        "n_obs": n_obs,
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
