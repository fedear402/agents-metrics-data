import json
import numpy as np
import pandas as pd
from scipy import stats

df = pd.read_csv("input.csv")
y = df["y"].to_numpy(dtype=float)
endog = df["endog"].to_numpy(dtype=float)
x = df["x"].to_numpy(dtype=float)
z1 = df["z1"].to_numpy(dtype=float)
z2 = df["z2"].to_numpy(dtype=float)

n = len(y)
k_excl = 2
dfd = n - 4
crit = stats.f.ppf(0.95, k_excl, dfd)

ones = np.ones(n)
W0 = np.column_stack([ones, x])
W1 = np.column_stack([ones, x, z1, z2])


def rss(v, W):
    coef, *_ = np.linalg.lstsq(W, v, rcond=None)
    r = v - W @ coef
    return float(r @ r)


def ar_f(beta):
    v = y - beta * endog
    r0 = rss(v, W0)
    r1 = rss(v, W1)
    return ((r0 - r1) / k_excl) / (r1 / dfd)


def q(beta):
    v = y - beta * endog
    r0 = rss(v, W0)
    r1 = rss(v, W1)
    return (dfd * (r0 - r1)) / k_excl - crit * r1


# q(beta) is an exact quadratic in beta; accept set is {q <= 0}
A = q(0.0)
Qp = q(1.0)
Qm = q(-1.0)
C = (Qp + Qm) / 2.0 - A
B = (Qp - Qm) / 2.0
disc = B * B - 4.0 * C * A

if C > 0 and disc >= 0:
    roots = sorted([(-B - np.sqrt(disc)) / (2 * C), (-B + np.sqrt(disc)) / (2 * C)])
    boundary_low, boundary_high = float(roots[0]), float(roots[1])
    unbounded = 0
elif C < 0 and disc >= 0:
    roots = sorted([(-B - np.sqrt(disc)) / (2 * C), (-B + np.sqrt(disc)) / (2 * C)])
    boundary_low, boundary_high = float(roots[0]), float(roots[1])
    unbounded = 1
else:
    boundary_low, boundary_high = float("nan"), float("nan")
    unbounded = 1 if C < 0 else 0

accepts_zero = int(A <= 0)
ar_f_at_one = float(ar_f(1.0))

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": [
        {"term": "boundary_low", "estimate": boundary_low, "se": None, "n_obs": int(n)},
        {"term": "boundary_high", "estimate": boundary_high, "se": None, "n_obs": int(n)},
        {"term": "accepts_zero", "estimate": float(accepts_zero), "se": None, "n_obs": int(n)},
        {"term": "unbounded", "estimate": float(unbounded), "se": None, "n_obs": int(n)},
        {"term": "ar_f_at_one", "estimate": ar_f_at_one, "se": None, "n_obs": int(n)},
    ],
    "method_metadata": {
        "estimator": "Anderson-Rubin test inversion (homoskedastic joint F test of excluded instruments)",
        "vcov": "homoskedastic",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
