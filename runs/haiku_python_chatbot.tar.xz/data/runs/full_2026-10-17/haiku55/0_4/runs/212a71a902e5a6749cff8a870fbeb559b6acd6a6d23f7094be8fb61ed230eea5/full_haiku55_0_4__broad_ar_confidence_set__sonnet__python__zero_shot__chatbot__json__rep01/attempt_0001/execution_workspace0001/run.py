import json

import numpy as np
import pandas as pd
from scipy import stats

df = pd.read_csv("input.csv")
y = df["y"].to_numpy(dtype=float)
e = df["endog"].to_numpy(dtype=float)
x = df["x"].to_numpy(dtype=float)
z1 = df["z1"].to_numpy(dtype=float)
z2 = df["z2"].to_numpy(dtype=float)
n = len(y)

ones = np.ones(n)
W = np.column_stack([ones, x])
Wz = np.column_stack([ones, x, z1, z2])
c = stats.f.ppf(0.95, 2, n - 4)


def resid(M, v):
    beta = np.linalg.lstsq(M, v, rcond=None)[0]
    return v - M @ beta


def quad_coefs(M):
    My = resid(M, y)
    Me = resid(M, e)
    return My @ My, Me @ My, Me @ Me


def ar_f(b):
    yb = y - b * e
    rr = resid(W, yb)
    ru = resid(Wz, yb)
    rss_r = rr @ rr
    rss_u = ru @ ru
    return ((rss_r - rss_u) / 2.0) / (rss_u / (n - 4))


a0r, a1r, a2r = quad_coefs(W)
a0u, a1u, a2u = quad_coefs(Wz)

C0 = (n - 4) * (a0r - a0u) - 2 * c * a0u
C1 = -2.0 * ((n - 4) * (a1r - a1u) - 2 * c * a1u)
C2 = (n - 4) * (a2r - a2u) - 2 * c * a2u

disc = C1 ** 2 - 4 * C2 * C0

if C2 > 0 and disc >= 0:
    r1 = (-C1 - np.sqrt(disc)) / (2 * C2)
    r2 = (-C1 + np.sqrt(disc)) / (2 * C2)
    boundary_low, boundary_high = sorted([float(r1), float(r2)])
    unbounded = 0
elif C2 < 0 and disc >= 0:
    r1 = (-C1 - np.sqrt(disc)) / (2 * C2)
    r2 = (-C1 + np.sqrt(disc)) / (2 * C2)
    boundary_low, boundary_high = sorted([float(r1), float(r2)])
    unbounded = 1
else:
    boundary_low = float("nan")
    boundary_high = float("nan")
    unbounded = 1 if C2 < 0 else 0

accepts_zero = int(C0 <= 0)
ar_f_at_one = float(ar_f(1.0))

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": [
        {"term": "boundary_low", "estimate": boundary_low, "se": None, "n_obs": int(n)},
        {"term": "boundary_high", "estimate": boundary_high, "se": None, "n_obs": int(n)},
        {"term": "accepts_zero", "estimate": float(accepts_zero), "se": None, "n_obs": int(n)},
        {"term": "unbounded", "estimate": float(unbounded), "se": None, "n_obs": int(n)},
        {"term": "ar_f_at_one", "estimate": ar_f_at_one, "se": None, "n_obs": int(n)},
    ],
    "method_metadata": {
        "estimator": "Anderson-Rubin test inversion with homoskedastic joint F test of excluded instruments z1, z2",
        "vcov": "homoskedastic",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
