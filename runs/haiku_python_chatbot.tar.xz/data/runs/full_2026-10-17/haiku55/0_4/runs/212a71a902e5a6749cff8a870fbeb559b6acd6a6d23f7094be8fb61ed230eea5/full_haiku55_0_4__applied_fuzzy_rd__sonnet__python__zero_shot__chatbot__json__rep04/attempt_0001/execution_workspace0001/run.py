import json

import numpy as np
import pandas as pd

H = 1.0
OUTCOMES = ["earnings", "participated"]

df = pd.read_csv("input.csv")
d = df[np.abs(df["score"].to_numpy(float)) < H].copy()
n_obs = int(len(d))


def side_fit(sub):
    s = sub["score"].to_numpy(float)
    w = 1.0 - np.abs(s)
    X = np.column_stack([np.ones_like(s), s])
    Y = sub[OUTCOMES].to_numpy(float)

    bread = np.linalg.inv(X.T @ (X * w[:, None]))
    B = bread @ (X.T @ (w[:, None] * Y))
    E = Y - X @ B

    C = np.zeros((2, 2))
    for k in range(2):
        for l in range(2):
            meat = (X * (w ** 2 * E[:, k] * E[:, l])[:, None]).T @ X
            V = bread @ meat @ bread
            C[k, l] = V[0, 0]
    return B[0, :], C


right = d[d["score"] >= 0]
left = d[d["score"] < 0]

aR, CR = side_fit(right)
aL, CL = side_fit(left)

disc = aR - aL
Sigma = CR + CL

reduced_form = float(disc[0])
first_stage = float(disc[1])
rf_var = float(Sigma[0, 0])
fs_var = float(Sigma[1, 1])
rf_fs_cov = float(Sigma[0, 1])

treatment_effect = reduced_form / first_stage
grad = np.array([1.0 / first_stage, -reduced_form / first_stage ** 2])
te_var = float(grad @ Sigma @ grad)

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {
            "term": "treatment_effect",
            "estimate": float(treatment_effect),
            "se": float(np.sqrt(te_var)),
            "n_obs": n_obs,
        },
        {
            "term": "reduced_form",
            "estimate": reduced_form,
            "se": float(np.sqrt(rf_var)),
            "n_obs": n_obs,
        },
        {
            "term": "first_stage",
            "estimate": first_stage,
            "se": float(np.sqrt(fs_var)),
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "Fuzzy RD, cutoff 0, bandwidth 1, triangular weights, local linear with separate slopes per side, Wald ratio",
        "vcov": "HC0 sandwich (no df correction), joint across outcomes, delta method for treatment_effect",
    },
    "diagnostics": {
        "bandwidth": H,
        "cutoff": 0.0,
        "n_right": int(len(right)),
        "n_left": int(len(left)),
        "reduced_form_first_stage_cov": rf_fs_cov,
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
