import json

import numpy as np
import pandas as pd

crosswalk = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv")
areas = pd.read_csv("areas.csv")
employment = pd.read_csv("employment.csv")
outcomes = pd.read_csv("outcomes.csv")

employment["employment"] = employment["employment"].fillna(0.0)

trade = trade.merge(crosswalk, on="code", how="inner")
trade = trade[["period", "industry", "us_change", "other_change", "price_index", "years"]]
trade = trade.drop_duplicates(["period", "industry"])

total = areas[["area", "period", "vintage", "total_employment"]]
emp_cell = employment.groupby(["area", "period", "vintage", "industry"], as_index=False)["employment"].sum()
national = (
    employment.groupby(["period", "vintage", "industry"], as_index=False)["employment"].sum()
    .rename(columns={"employment": "national"})
)


def exposure(vintage, change_col):
    e = emp_cell[emp_cell["vintage"] == vintage].merge(
        total[total["vintage"] == vintage][["area", "period", "total_employment"]],
        on=["area", "period"],
        how="left",
    )
    e = e.merge(
        national[national["vintage"] == vintage][["period", "industry", "national"]],
        on=["period", "industry"],
        how="left",
    )
    e = e.merge(
        trade[["period", "industry", change_col, "price_index", "years"]],
        on=["period", "industry"],
        how="inner",
    )
    e["term"] = (
        (e["employment"] / e["total_employment"])
        * (e[change_col] / e["national"])
        / (e["price_index"] / 100)
        / 1000
        * (10 / e["years"])
    )
    return e.groupby(["area", "period"], as_index=False)["term"].sum()


x = exposure("base", "us_change").rename(columns={"term": "x"})
z = exposure("early", "other_change").rename(columns={"term": "z"})
pop = areas[areas["vintage"] == "base"][["area", "period", "population"]]

df = (
    outcomes.merge(x, on=["area", "period"], how="left")
    .merge(z, on=["area", "period"], how="left")
    .merge(pop, on=["area", "period"], how="left")
)

y = df["change_pp"].to_numpy(float)
ones = np.ones(len(df))
X = np.column_stack([ones, df["period"].to_numpy(float), df["control"].to_numpy(float), df["x"].to_numpy(float)])
Z = np.column_stack([ones, df["period"].to_numpy(float), df["control"].to_numpy(float), df["z"].to_numpy(float)])
w = df["population"].to_numpy(float)
sw = np.sqrt(w)

Xw = X * sw[:, None]
Zw = Z * sw[:, None]
yw = y * sw

G = Zw.T @ Zw
A = Zw.T @ Xw
b = Zw.T @ yw
beta = np.linalg.solve(A.T @ np.linalg.solve(G, A), A.T @ np.linalg.solve(G, b))

periods = sorted(df["period"].unique())
p0, p1 = periods[0], periods[1]

exposure_area0_period0 = float(df.loc[(df["area"] == 0) & (df["period"] == p0), "x"].iloc[0])
exposure_area0_period1 = float(df.loc[(df["area"] == 0) & (df["period"] == p1), "x"].iloc[0])
instrument_area0_period0 = float(df.loc[(df["area"] == 0) & (df["period"] == p0), "z"].iloc[0])
n_obs = int(len(df))

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [
        {"term": "iv_slope", "estimate": float(beta[3]), "se": None, "n_obs": n_obs},
        {"term": "exposure_area0_period0", "estimate": exposure_area0_period0, "se": None, "n_obs": n_obs},
        {"term": "exposure_area0_period1", "estimate": exposure_area0_period1, "se": None, "n_obs": n_obs},
        {"term": "instrument_area0_period0", "estimate": instrument_area0_period0, "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "method": "weighted_2sls",
        "dependent": "change_pp",
        "endogenous": ["x"],
        "instruments": ["z"],
        "exogenous": ["intercept", "period", "control"],
        "weights": "base_vintage_population",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "n_areas": int(df["area"].nunique()),
        "n_periods": int(len(periods)),
        "missing_exposure_rows": int(df[["x", "z"]].isna().any(axis=1).sum()),
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
