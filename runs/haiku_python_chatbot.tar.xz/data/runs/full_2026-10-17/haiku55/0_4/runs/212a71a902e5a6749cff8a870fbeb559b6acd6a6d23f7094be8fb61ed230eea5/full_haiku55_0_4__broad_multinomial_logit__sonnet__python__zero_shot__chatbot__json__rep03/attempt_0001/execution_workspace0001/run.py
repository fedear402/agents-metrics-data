import json

import numpy as np
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("input.csv")
n_obs = int(len(df))

X = sm.add_constant(df[["x", "z"]].astype(float), has_constant="add")
y = df["y"].astype(int)

model = sm.MNLogit(y, X)
res = model.fit(method="newton", maxiter=200, disp=0)

params = res.params
bse = res.bse

c1 = float(params.loc["const", 1])
c2 = float(params.loc["const", 2])
denom = 1.0 + np.exp(c1) + np.exp(c2)
prob_cat2_zero = float(np.exp(c2) / denom)

estimates = [
    {"term": "x_cat1", "estimate": float(params.loc["x", 1]),
     "se": float(bse.loc["x", 1]), "n_obs": n_obs},
    {"term": "z_cat1", "estimate": float(params.loc["z", 1]),
     "se": float(bse.loc["z", 1]), "n_obs": n_obs},
    {"term": "x_cat2", "estimate": float(params.loc["x", 2]),
     "se": float(bse.loc["x", 2]), "n_obs": n_obs},
    {"term": "z_cat2", "estimate": float(params.loc["z", 2]),
     "se": float(bse.loc["z", 2]), "n_obs": n_obs},
    {"term": "prob_cat2_zero", "estimate": prob_cat2_zero,
     "se": None, "n_obs": n_obs},
]

result = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "multinomial logit (maximum likelihood, base outcome 0)",
        "vcov": "observed information (inverse negative Hessian)",
    },
    "diagnostics": {
        "converged": bool(res.mle_retvals.get("converged", True)),
        "log_likelihood": float(res.llf),
        "n_obs": n_obs,
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
