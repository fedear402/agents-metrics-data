import json

import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")

reg = df.groupby("region_id").agg(
    region_weight=("region_weight", "first"),
    x=("x", "first"),
    y=("y", "first"),
)
e = reg["region_weight"].to_numpy(float)
e = e / e.sum()

shares = (
    df.pivot_table(index="region_id", columns="industry_id", values="share", aggfunc="sum")
    .loc[reg.index]
)
S = shares.to_numpy(float)
sh = df.groupby("industry_id")["shock"].first().loc[shares.columns].to_numpy(float)

x_r = reg["x"].to_numpy(float)
y_r = reg["y"].to_numpy(float)
z_r = S @ sh


def demean(v):
    return v - e @ v


y0 = demean(y_r)
x0 = demean(x_r)
z0 = demean(z_r)

s = e @ S


def aggregate(v0):
    return (S.T @ (e * v0)) / s


ybar = aggregate(y0)
xbar = aggregate(x0)
zbar = aggregate(z0)


def shock_iv(dep, endog, instr, w):
    n = len(dep)
    X = np.column_stack([np.ones(n), endog])
    Z = np.column_stack([np.ones(n), instr])
    cross = Z.T @ (w[:, None] * X)
    beta = np.linalg.solve(cross, Z.T @ (w * dep))
    resid = dep - X @ beta
    scores = Z * (w * resid)[:, None]
    inv = np.linalg.inv(cross)
    hc1 = n / (n - 2)
    cov = hc1 * inv @ (scores.T @ scores) @ inv.T
    return float(beta[1]), float(np.sqrt(cov[1, 1]))


effect, effect_se = shock_iv(ybar, xbar, sh, s)
_, first_stage_se = shock_iv(xbar, zbar, sh, s)
first_stage = float(np.sum(e * z0 * x0) / np.sum(e * z0 ** 2))
effective_shocks = float(1.0 / np.sum(s ** 2))
n_industries = int(len(sh))

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": effect, "se": effect_se, "n_obs": n_industries},
        {"term": "first_stage", "estimate": first_stage, "se": first_stage_se, "n_obs": n_industries},
        {"term": "effective_shocks", "estimate": effective_shocks, "se": None, "n_obs": n_industries},
    ],
    "method_metadata": {
        "estimator": "Regional weighted 2SLS via Borusyak-Hull-Jaravel shock-level weighted IV",
        "vcov": "Shock-level HC1 robust sandwich (N/(N-2)), structural residuals, analytic weights, no clustering",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
