import json
import numpy as np
import pandas as pd

crosswalk = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv")
areas = pd.read_csv("areas.csv")
employment = pd.read_csv("employment.csv")
outcomes = pd.read_csv("outcomes.csv")

tr = trade.merge(crosswalk, on="code", how="inner")
tr = tr[["period", "industry", "us_change", "other_change", "price_index", "years"]]


def exposure(vintage, change_col):
    e = employment[employment["vintage"] == vintage]
    e = e.groupby(["area", "period", "industry"], as_index=False)["employment"].sum()
    nat = (
        e.groupby(["period", "industry"], as_index=False)["employment"]
        .sum()
        .rename(columns={"employment": "nat"})
    )
    tot = areas.loc[areas["vintage"] == vintage, ["area", "period", "total_employment"]]
    t = tr[["period", "industry", change_col, "price_index", "years"]]
    m = (
        e.merge(nat, on=["period", "industry"])
        .merge(t, on=["period", "industry"])
        .merge(tot, on=["area", "period"])
    )
    m["term"] = (
        (m["employment"] / m["total_employment"])
        * (m[change_col] / m["nat"])
        / (m["price_index"] / 100.0)
        / 1000.0
        * (10.0 / m["years"])
    )
    return m.groupby(["area", "period"])["term"].sum()


x_s = exposure("base", "us_change")
z_s = exposure("early", "other_change")

base_pop = areas.loc[areas["vintage"] == "base", ["area", "period", "population"]]
df = outcomes.merge(base_pop, on=["area", "period"], how="inner")

keys = pd.MultiIndex.from_arrays([df["area"], df["period"]])
df["x"] = x_s.reindex(keys).fillna(0.0).to_numpy(dtype=float)
df["z"] = z_s.reindex(keys).fillna(0.0).to_numpy(dtype=float)

n = len(df)
const = np.ones(n)
X = np.column_stack([const, df["period"], df["control"], df["x"]]).astype(float)
Z = np.column_stack([const, df["period"], df["control"], df["z"]]).astype(float)
y = df["change_pp"].to_numpy(dtype=float)
w = df["population"].to_numpy(dtype=float)
sw = np.sqrt(w)

Xw = X * sw[:, None]
Zw = Z * sw[:, None]
yw = y * sw

A = Zw.T @ Zw
Xhat = Zw @ np.linalg.solve(A, Zw.T @ Xw)
beta = np.linalg.solve(Xhat.T @ Xw, Xhat.T @ yw)
iv_slope = float(beta[3])


def pick(col, period):
    sel = df.loc[(df["area"] == 0) & (df["period"] == period), col]
    return float(sel.iloc[0])


exposure_area0_period0 = pick("x", 0)
exposure_area0_period1 = pick("x", 1)
instrument_area0_period0 = pick("z", 0)

n_obs = int(n)

estimates = [
    {"term": "iv_slope", "estimate": iv_slope, "se": None, "n_obs": n_obs},
    {"term": "exposure_area0_period0", "estimate": exposure_area0_period0, "se": None, "n_obs": n_obs},
    {"term": "exposure_area0_period1", "estimate": exposure_area0_period1, "se": None, "n_obs": n_obs},
    {"term": "instrument_area0_period0", "estimate": instrument_area0_period0, "se": None, "n_obs": n_obs},
]

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "method": "weighted_2sls",
        "dependent": "change_pp",
        "endogenous": ["x"],
        "instruments": ["z"],
        "exogenous": ["intercept", "period", "control"],
        "weight": "base_vintage_population",
        "n_obs": n_obs,
    },
    "diagnostics": {
        "n_obs": n_obs,
        "weight_sum": float(w.sum()),
        "instrument_rank": int(np.linalg.matrix_rank(Zw)),
        "regressor_rank": int(np.linalg.matrix_rank(Xw)),
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
