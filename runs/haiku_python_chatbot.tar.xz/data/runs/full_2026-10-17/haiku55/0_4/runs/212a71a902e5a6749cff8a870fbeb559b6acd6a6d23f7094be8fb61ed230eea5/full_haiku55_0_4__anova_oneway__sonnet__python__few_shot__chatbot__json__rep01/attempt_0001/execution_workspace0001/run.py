import json
import pandas as pd
from scipy import stats

df = pd.read_csv("./input.csv")
groups = [g["y"].to_numpy(dtype=float) for _, g in df.groupby("group")]
k = len(groups)
n = len(df)

f_stat, p_val = stats.f_oneway(*groups)
df_num = k - 1
df_den = n - k

out = {
    "task_id": "anova_oneway",
    "platform": "python",
    "estimates": [
        {"term": "F", "estimate": float(f_stat), "se": None, "n_obs": n},
        {"term": "df_num", "estimate": float(df_num), "se": None, "n_obs": n},
        {"term": "df_den", "estimate": float(df_den), "se": None, "n_obs": n},
        {"term": "p_value", "estimate": float(p_val), "se": None, "n_obs": n},
    ],
    "method_metadata": {"estimator": "One-way ANOVA (F test)", "vcov": "none"},
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(out, f)
