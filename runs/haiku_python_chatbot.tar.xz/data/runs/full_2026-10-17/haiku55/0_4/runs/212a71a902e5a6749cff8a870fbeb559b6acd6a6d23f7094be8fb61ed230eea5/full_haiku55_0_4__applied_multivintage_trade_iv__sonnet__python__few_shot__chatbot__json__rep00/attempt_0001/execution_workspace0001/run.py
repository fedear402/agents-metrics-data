import json

import numpy as np
import pandas as pd


def load(name):
    df = pd.read_csv(name)
    for c in df.select_dtypes(include="object").columns:
        df[c] = df[c].str.strip()
    return df


crosswalk = load("crosswalk.csv")
trade = load("trade.csv")
areas = load("areas.csv")
employment = load("employment.csv")
outcomes = load("outcomes.csv")

trade_ind = trade.merge(crosswalk, on="code")[
    ["period", "industry", "us_change", "other_change", "price_index", "years"]
]
industries = pd.DataFrame({"industry": sorted(trade_ind["industry"].unique())})

cells = (
    areas[["area", "period", "vintage", "total_employment"]]
    .drop_duplicates()
    .merge(industries, how="cross")
)
emp = employment.groupby(["area", "period", "vintage", "industry"], as_index=False)[
    "employment"
].sum()
grid = cells.merge(emp, on=["area", "period", "vintage", "industry"], how="left")
grid["employment"] = grid["employment"].fillna(0.0)
grid = grid.merge(trade_ind, on=["period", "industry"], how="left")


def exposure(vintage, change_col, name):
    g = grid[grid["vintage"] == vintage].copy()
    national = g.groupby(["period", "industry"])["employment"].transform("sum")
    shock = (
        g[change_col]
        / national
        / (g["price_index"] / 100)
        / 1000
        * (10 / g["years"])
    )
    g["term"] = g["employment"] / g["total_employment"] * shock
    return g.groupby(["area", "period"], as_index=False)["term"].sum().rename(
        columns={"term": name}
    )


x = exposure("base", "us_change", "x_exp")
z = exposure("early", "other_change", "z_exp")
pop = areas.loc[areas["vintage"] == "base", ["area", "period", "population"]]

panel = (
    outcomes.merge(x, on=["area", "period"])
    .merge(z, on=["area", "period"])
    .merge(pop, on=["area", "period"])
    .sort_values(["area", "period"])
    .reset_index(drop=True)
)
n_obs = int(len(panel))

ones = np.ones(n_obs)
period = panel["period"].astype(float).to_numpy()
control = panel["control"].astype(float).to_numpy()
y = panel["change_pp"].astype(float).to_numpy()
X = np.column_stack([ones, period, control, panel["x_exp"].astype(float).to_numpy()])
Z = np.column_stack([ones, period, control, panel["z_exp"].astype(float).to_numpy()])
sw = np.sqrt(panel["population"].astype(float).to_numpy())

Xw = X * sw[:, None]
Zw = Z * sw[:, None]
yw = y * sw

Q, _ = np.linalg.qr(Zw)
Xhat = Q @ (Q.T @ Xw)
beta = np.linalg.lstsq(Xhat, yw, rcond=None)[0]
pi = np.linalg.lstsq(Zw, Xw[:, 3], rcond=None)[0]

periods = sorted(panel["period"].unique())
a0 = panel[panel["area"].astype(str) == "0"].set_index("period")
exposure_area0_period0 = float(a0.loc[periods[0], "x_exp"])
exposure_area0_period1 = float(a0.loc[periods[1], "x_exp"])
instrument_area0_period0 = float(a0.loc[periods[0], "z_exp"])

estimates = [
    {"term": "iv_slope", "estimate": float(beta[3]), "se": None, "n_obs": n_obs},
    {
        "term": "exposure_area0_period0",
        "estimate": exposure_area0_period0,
        "se": None,
        "n_obs": n_obs,
    },
    {
        "term": "exposure_area0_period1",
        "estimate": exposure_area0_period1,
        "se": None,
        "n_obs": n_obs,
    },
    {
        "term": "instrument_area0_period0",
        "estimate": instrument_area0_period0,
        "se": None,
        "n_obs": n_obs,
    },
]

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "weights": "base-vintage population",
        "endogenous": ["x"],
        "instruments": ["z"],
        "exogenous": ["intercept", "period", "control"],
        "standard_errors": "not reported",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "n_industries": int(len(industries)),
        "first_stage_coef_z": float(pi[3]),
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
