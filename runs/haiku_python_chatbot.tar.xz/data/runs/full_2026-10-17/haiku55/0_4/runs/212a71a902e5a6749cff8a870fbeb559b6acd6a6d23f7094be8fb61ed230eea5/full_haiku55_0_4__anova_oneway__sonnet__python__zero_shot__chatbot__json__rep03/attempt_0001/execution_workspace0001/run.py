import json

import pandas as pd
from scipy import stats

df = pd.read_csv("./input.csv")
df = df.dropna(subset=["group", "y"])
df["y"] = pd.to_numeric(df["y"], errors="coerce")
df = df.dropna(subset=["y"])

groups = [g["y"].values for _, g in df.groupby("group")]
k = len(groups)
n = len(df)

f_stat, p_val = stats.f_oneway(*groups)
df_num = k - 1
df_den = n - k

result = {
    "task_id": "anova_oneway",
    "platform": "python",
    "estimates": [
        {"term": "F", "estimate": float(f_stat), "se": None, "n_obs": int(n)},
        {"term": "df_num", "estimate": float(df_num), "se": None, "n_obs": int(n)},
        {"term": "df_den", "estimate": float(df_den), "se": None, "n_obs": int(n)},
        {"term": "p_value", "estimate": float(p_val), "se": None, "n_obs": int(n)},
    ],
    "method_metadata": {
        "estimator": "one-way ANOVA (scipy.stats.f_oneway)",
        "vcov": "not applicable",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
