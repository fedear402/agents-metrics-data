import json

import numpy as np
import pandas as pd
from statsmodels.tsa.arima.model import ARIMA

Z95 = 1.959963984540054

df = pd.read_csv("./input.csv")
df = df.sort_values("t").reset_index(drop=True)
fit_df = df[df["t"] < 251]
y = fit_df["y"].astype(float).reset_index(drop=True)
n_obs = int(len(y))

steps = int(251 - fit_df["t"].max())
if steps < 1:
    steps = 1

res = ARIMA(y, order=(1, 1, 1), trend="n").fit()
fc = res.get_forecast(steps=steps)
frame = fc.summary_frame(alpha=0.05)

mean_val = float(frame["mean"].iloc[-1])
lower_val = float(frame["mean_ci_lower"].iloc[-1])
upper_val = float(frame["mean_ci_upper"].iloc[-1])

se_fc = float(np.sqrt(fc.var_pred_mean[-1]))
se_lower = (mean_val - lower_val) / Z95
se_upper = (upper_val - mean_val) / Z95

out = {
    "task_id": "arima_forecast",
    "platform": "python",
    "estimates": [
        {"term": "forecast", "estimate": mean_val, "se": se_fc, "n_obs": n_obs},
        {"term": "lower_95", "estimate": lower_val, "se": se_lower, "n_obs": n_obs},
        {"term": "upper_95", "estimate": upper_val, "se": se_upper, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "ARIMA(1,1,1) by maximum likelihood, no constant",
        "vcov": "statsmodels default (outer product / approximate Hessian)",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(out, f)
