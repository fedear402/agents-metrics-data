import json

import numpy as np
import pandas as pd
from statsmodels.tsa.arima.model import ARIMA

df = pd.read_csv("./input.csv")
df = df.sort_values("t").reset_index(drop=True)
fit_df = df[df["t"] < 251]
y = fit_df["y"].astype(float).reset_index(drop=True)
n_obs = int(y.shape[0])

model = ARIMA(y, order=(1, 1, 1), trend="n")
res = model.fit()

fc = res.get_forecast(steps=1)
mean = float(np.asarray(fc.predicted_mean)[0])
se = float(np.sqrt(np.asarray(fc.var_pred_mean)[0]))
ci = np.asarray(fc.conf_int(alpha=0.05))[0]
lower = float(ci[0])
upper = float(ci[1])

result = {
    "task_id": "arima_forecast",
    "platform": "python",
    "estimates": [
        {"term": "forecast", "estimate": mean, "se": se, "n_obs": n_obs},
        {"term": "lower_95", "estimate": lower, "se": None, "n_obs": n_obs},
        {"term": "upper_95", "estimate": upper, "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "ARIMA(1,1,1) on levels, no constant, maximum likelihood (statsmodels state-space)",
        "vcov": "statsmodels default approximate covariance (Hessian-based)",
    },
    "diagnostics": {
        "forecast_origin_t": int(fit_df["t"].max()),
        "forecast_horizon_t": 251,
        "aic": float(res.aic),
        "bic": float(res.bic),
        "loglik": float(res.llf),
        "ar1": float(res.params.iloc[0]),
        "ma1": float(res.params.iloc[1]),
        "sigma2": float(res.params.iloc[2]),
        "converged": bool(res.mle_retvals.get("converged", True)) if getattr(res, "mle_retvals", None) else True,
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
