import json

import numpy as np
import pandas as pd

h = 1.0
df = pd.read_csv("input.csv")
d = df[df["score"].abs() < h].copy()

s = d["score"].to_numpy(dtype=float)
w = 1.0 - np.abs(s)
R = (s >= 0).astype(float)
L = 1.0 - R
X = np.column_stack([L, R, s * L, s * R])
Y = np.column_stack([
    d["earnings"].to_numpy(dtype=float),
    d["participated"].to_numpy(dtype=float),
])

B = np.linalg.inv(X.T @ (w[:, None] * X))
beta = B @ X.T @ (w[:, None] * Y)
E = Y - X @ beta

c = np.array([-1.0, 1.0, 0.0, 0.0])
jumps = c @ beta
loading = w * (X @ B @ c)
influence = loading[:, None] * E
V = influence.T @ influence

rf, fs = float(jumps[0]), float(jumps[1])
te = rf / fs
g = np.array([1.0 / fs, -rf / fs**2])
te_se = float(np.sqrt(g @ V @ g))

n_obs = int(len(d))

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": te, "se": te_se, "n_obs": n_obs},
        {"term": "reduced_form", "estimate": rf, "se": float(np.sqrt(V[0, 0])), "n_obs": n_obs},
        {"term": "first_stage", "estimate": fs, "se": float(np.sqrt(V[1, 1])), "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "fuzzy regression discontinuity, local linear, triangular kernel, cutoff 0, bandwidth 1",
        "vcov": "HC0 sandwich with delta method for treatment_effect",
    },
    "diagnostics": {
        "bandwidth": h,
        "n_left": int(L.sum()),
        "n_right": int(R.sum()),
    },
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
