import json

import numpy as np
import pandas as pd
import statsmodels.api as sm

L = 15
N_CORR = 16

df = pd.read_csv("input.csv")
df["date"] = pd.to_datetime(df["date"])
df = df.sort_values("date").reset_index(drop=True)

df["lsales"] = np.log(df["sales"])
df["dlvix"] = np.log(df["vix"]).diff()
lag_cols = [f"lag_{j}" for j in range(1, L + 1)]
for j in range(1, L + 1):
    df[f"lag_{j}"] = df["dlvix"].shift(j)

d = df.dropna(subset=["lsales"] + lag_cols).reset_index(drop=True)
N = len(d)

X = sm.add_constant(d[lag_cols])
y = d["lsales"]

res = sm.OLS(y, X).fit(
    cov_type="HAC",
    cov_kwds={"maxlags": L, "kernel": "bartlett", "use_correction": False},
)

V = np.asarray(res.cov_params()) * N / (N - N_CORR)
params = np.asarray(res.params)
b = params[1:]

c = np.r_[0.0, np.ones(L)]
cum_est = float(c[1:] @ b)
cum_var = float(c @ V @ c)
cum_se = float(np.sqrt(cum_var))

lag1_est = float(b[0])
lag1_se = float(np.sqrt(V[1, 1]))
lag15_est = float(b[L - 1])
lag15_se = float(np.sqrt(V[L, L]))

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {"term": "cumulative_response", "estimate": cum_est, "se": cum_se, "n_obs": int(N)},
        {"term": "lag_1", "estimate": lag1_est, "se": lag1_se, "n_obs": int(N)},
        {"term": "lag_15", "estimate": lag15_est, "se": lag15_se, "n_obs": int(N)},
    ],
    "method_metadata": {
        "estimator": "OLS regression of log(sales) on intercept and 15 lags of diff(log(vix))",
        "vcov": "Newey-West HAC, maxlags=15, Bartlett weights 1-j/16, scaled by N/(N-16)",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
