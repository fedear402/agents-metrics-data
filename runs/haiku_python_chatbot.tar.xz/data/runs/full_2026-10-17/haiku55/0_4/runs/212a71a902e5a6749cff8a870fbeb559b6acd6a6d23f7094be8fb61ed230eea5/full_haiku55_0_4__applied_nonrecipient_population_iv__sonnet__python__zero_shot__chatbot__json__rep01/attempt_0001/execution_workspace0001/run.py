import json

import numpy as np
import pandas as pd

hh = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

numeric_cols = ["eligible", "treated", "recipient", "instrument", "dose", "baseline", "weight", "outcome"]
for col in numeric_cols:
    hh[col] = pd.to_numeric(hh[col])
census["eligible"] = pd.to_numeric(census["eligible"])
census["nonrecipient_population"] = pd.to_numeric(census["nonrecipient_population"])

hh = hh[hh["recipient"] == 0].copy()

e = hh["eligible"].to_numpy(dtype=float)
ne = 1.0 - e
d = hh["dose"].to_numpy(dtype=float)
b = hh["baseline"].to_numpy(dtype=float)
z = hh["instrument"].to_numpy(dtype=float)
w = hh["weight"].to_numpy(dtype=float)
y = hh["outcome"].to_numpy(dtype=float)

X = np.column_stack([d * ne, d * e, ne, e, b * ne, b * e])
Z = np.column_stack([ne, e, b * ne, b * e, z * ne, z * e])

sw = np.sqrt(w)
Xs = X * sw[:, None]
Zs = Z * sw[:, None]
ys = y * sw

first_stage_coef = np.linalg.lstsq(Zs, Xs, rcond=None)[0]
Xs_hat = Zs @ first_stage_coef
beta = np.linalg.lstsq(Xs_hat, ys, rcond=None)[0]

slope_ineligible = beta[0]
slope_eligible = beta[1]

mask_ne = ne == 1.0
mask_e = e == 1.0

mean_dose_ineligible = np.sum(w[mask_ne] * d[mask_ne]) / np.sum(w[mask_ne])
mean_dose_eligible = np.sum(w[mask_e] * d[mask_e]) / np.sum(w[mask_e])

ineligible_effect = float(slope_ineligible * mean_dose_ineligible)
eligible_nonrecipient_effect = float(slope_eligible * mean_dose_eligible)

n0 = float(census.loc[census["eligible"] == 0, "nonrecipient_population"].sum())
n1 = float(census.loc[census["eligible"] == 1, "nonrecipient_population"].sum())
population_effect = float(
    (n0 * ineligible_effect + n1 * eligible_nonrecipient_effect) / (n0 + n1)
)

n_obs = int(len(hh))

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "ineligible_effect",
            "estimate": ineligible_effect,
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "eligible_nonrecipient_effect",
            "estimate": eligible_nonrecipient_effect,
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "population_effect",
            "estimate": population_effect,
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "weighted two-stage least squares",
        "regression_weight": "weight",
        "intercept": False,
        "endogenous_columns": ["dose*(1-eligible)", "dose*eligible"],
        "exogenous_columns": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
        ],
        "instrument_columns": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
            "instrument*(1-eligible)",
            "instrument*eligible",
        ],
        "sample": "households with recipient == 0, all treatment statuses retained",
        "effect_definition": "group dose slope times household-weighted mean dose in group",
        "counterfactual": "dose set to zero for every retained household",
        "aggregation_weights": "census nonrecipient_population by eligibility group",
        "synthetic_convention": "attribution to a zero-dose counterfactual is a stated synthetic convention",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "n_ineligible_obs": int(mask_ne.sum()),
        "n_eligible_obs": int(mask_e.sum()),
        "rank_instruments": int(np.linalg.matrix_rank(Zs)),
        "rank_regressors": int(np.linalg.matrix_rank(Xs)),
        "slope_dose_times_ineligible": float(slope_ineligible),
        "slope_dose_times_eligible": float(slope_eligible),
        "weighted_mean_dose_ineligible": float(mean_dose_ineligible),
        "weighted_mean_dose_eligible": float(mean_dose_eligible),
        "census_population_ineligible": n0,
        "census_population_eligible": n1,
    },
}

with open("result.json", "w") as fh:
    json.dump(result, fh, indent=2)
