import json

import numpy as np
import pandas as pd


def read(name):
    df = pd.read_csv(name, dtype=str, keep_default_na=False)
    for c in df.columns:
        df[c] = df[c].str.strip()
    return df


def sort_key(v):
    try:
        return (0, float(v))
    except ValueError:
        return (1, v)


crosswalk = read("crosswalk.csv")
trade = read("trade.csv")
areas = read("areas.csv")
employment = read("employment.csv")
outcomes = read("outcomes.csv")

for col in ["us_change", "other_change", "price_index", "years"]:
    trade[col] = pd.to_numeric(trade[col])
for col in ["total_employment", "population"]:
    areas[col] = pd.to_numeric(areas[col])
employment["employment"] = pd.to_numeric(employment["employment"])
outcomes["control"] = pd.to_numeric(outcomes["control"])
outcomes["change_pp"] = pd.to_numeric(outcomes["change_pp"])

crosswalk = crosswalk.drop_duplicates(subset=["code"])
trade = trade.merge(crosswalk, on="code", how="inner")

industries = sorted(trade["industry"].unique(), key=sort_key)
periods = sorted(areas["period"].unique(), key=sort_key)
areas_list = sorted(areas["area"].unique(), key=sort_key)
pmap = {p: i for i, p in enumerate(periods)}

emp_g = employment.groupby(["area", "period", "vintage", "industry"])["employment"].sum()
idx = pd.MultiIndex.from_product(
    [areas_list, periods, ["base", "early"], industries],
    names=["area", "period", "vintage", "industry"],
)
emp_full = emp_g.reindex(idx, fill_value=0.0).reset_index()

tot = (
    areas.groupby(["area", "period", "vintage"], as_index=False)["total_employment"]
    .sum()
)
emp_t = emp_full.merge(tot, on=["area", "period", "vintage"], how="left")
emp_t["share"] = emp_t["employment"] / emp_t["total_employment"]

nat = (
    emp_full.groupby(["period", "vintage", "industry"], as_index=False)["employment"]
    .sum()
    .rename(columns={"employment": "nat"})
)

trade_t = trade[
    ["period", "industry", "us_change", "other_change", "price_index", "years"]
]


def exposure(vint, change_col):
    nat_v = nat[nat["vintage"] == vint][["period", "industry", "nat"]]
    d = (
        emp_t[emp_t["vintage"] == vint]
        .merge(nat_v, on=["period", "industry"])
        .merge(trade_t, on=["period", "industry"])
    )
    d["term"] = (
        d["share"]
        * d[change_col]
        / d["nat"]
        / (d["price_index"] / 100.0)
        / 1000.0
        * (10.0 / d["years"])
    )
    out = d.groupby(["area", "period"], as_index=False)["term"].sum()
    return out


x_df = exposure("base", "us_change").rename(columns={"term": "x"})
z_df = exposure("early", "other_change").rename(columns={"term": "z"})
pop_df = (
    areas[areas["vintage"] == "base"][["area", "period", "population"]]
    .drop_duplicates(subset=["area", "period"])
)

est = (
    outcomes[["area", "period", "control", "change_pp"]]
    .merge(x_df, on=["area", "period"])
    .merge(z_df, on=["area", "period"])
    .merge(pop_df, on=["area", "period"])
)
est["pidx"] = est["period"].map(pmap).astype(float)

n_obs = int(len(est))

ones = np.ones(n_obs)
X = np.column_stack([ones, est["pidx"].values, est["control"].values, est["x"].values])
Z = np.column_stack([ones, est["pidx"].values, est["control"].values, est["z"].values])
sw = np.sqrt(est["population"].values.astype(float))
Xw = X * sw[:, None]
Zw = Z * sw[:, None]
yw = est["change_pp"].values * sw

X_hat = Zw @ np.linalg.lstsq(Zw, Xw, rcond=None)[0]
beta = np.linalg.lstsq(X_hat, yw, rcond=None)[0]
iv_slope = float(beta[3])


def lookup(col, area, pidx):
    row = est[(est["area"] == area) & (est["pidx"] == float(pidx))]
    return float(row[col].iloc[0])


exposure_area0_period0 = lookup("x", "0", 0)
exposure_area0_period1 = lookup("x", "0", 1)
instrument_area0_period0 = lookup("z", "0", 0)

estimates = [
    {"term": "iv_slope", "estimate": iv_slope, "se": None, "n_obs": n_obs},
    {"term": "exposure_area0_period0", "estimate": exposure_area0_period0, "se": None, "n_obs": n_obs},
    {"term": "exposure_area0_period1", "estimate": exposure_area0_period1, "se": None, "n_obs": n_obs},
    {"term": "instrument_area0_period0", "estimate": instrument_area0_period0, "se": None, "n_obs": n_obs},
]

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "weighted 2SLS",
        "dependent": "change_pp",
        "endogenous": ["x"],
        "instruments": ["z"],
        "exogenous": ["intercept", "period", "control"],
        "weight": "base-vintage population",
        "period_coding": {str(p): int(i) for p, i in pmap.items()},
        "industries": [str(i) for i in industries],
    },
    "diagnostics": {
        "n_area_periods": n_obs,
        "n_areas": int(len(areas_list)),
        "n_periods": int(len(periods)),
        "n_industries": int(len(industries)),
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
