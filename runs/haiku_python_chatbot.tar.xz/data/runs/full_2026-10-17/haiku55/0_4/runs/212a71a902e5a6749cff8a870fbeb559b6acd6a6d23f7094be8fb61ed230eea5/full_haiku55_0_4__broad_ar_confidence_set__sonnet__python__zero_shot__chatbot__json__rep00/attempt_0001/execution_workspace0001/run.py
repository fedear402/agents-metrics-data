import json

import numpy as np
import pandas as pd
from scipy import stats

df = pd.read_csv("input.csv")
n = len(df)

y = df["y"].to_numpy(dtype=float)
en = df["endog"].to_numpy(dtype=float)
x = df["x"].to_numpy(dtype=float)
z1 = df["z1"].to_numpy(dtype=float)
z2 = df["z2"].to_numpy(dtype=float)

X_u = np.column_stack([np.ones(n), x, z1, z2])
X_r = np.column_stack([np.ones(n), x])

M_u = np.eye(n) - X_u @ np.linalg.pinv(X_u)
M_r = np.eye(n) - X_r @ np.linalg.pinv(X_r)

def quad_coeffs(M):
    c0 = y @ M @ y
    c1 = -2.0 * (y @ M @ en)
    c2 = en @ M @ en
    return np.array([c0, c1, c2])

qu = quad_coeffs(M_u)
qr = quad_coeffs(M_r)

df_den = n - 4
crit = stats.f.ppf(0.95, 2, df_den)
k = 2.0 * crit / df_den

def ssr(q, b):
    return q[0] + q[1] * b + q[2] * b * b

def ar_f(b):
    su = ssr(qu, b)
    sr = ssr(qr, b)
    return ((sr - su) / 2.0) / (su / df_den)

A = qr[2] - (1.0 + k) * qu[2]
B = qr[1] - (1.0 + k) * qu[1]
C = qr[0] - (1.0 + k) * qu[0]

disc = B * B - 4.0 * A * C
if A != 0.0 and disc >= 0:
    sq = np.sqrt(disc)
    roots = sorted([(-B - sq) / (2.0 * A), (-B + sq) / (2.0 * A)])
elif A == 0.0 and B != 0.0:
    roots = [-C / B, -C / B]
else:
    roots = [float("nan"), float("nan")]

unbounded = int(A < 0 or (A == 0.0 and B != 0.0))
accepts_zero = int(C <= 0.0)
ar_f_at_one = float(ar_f(1.0))

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": [
        {"term": "boundary_low", "estimate": float(roots[0]), "se": None, "n_obs": int(n)},
        {"term": "boundary_high", "estimate": float(roots[1]), "se": None, "n_obs": int(n)},
        {"term": "accepts_zero", "estimate": float(accepts_zero), "se": None, "n_obs": int(n)},
        {"term": "unbounded", "estimate": float(unbounded), "se": None, "n_obs": int(n)},
        {"term": "ar_f_at_one", "estimate": ar_f_at_one, "se": None, "n_obs": int(n)},
    ],
    "method_metadata": {
        "estimator": "Anderson-Rubin confidence set by inverting homoskedastic joint F test of excluded instruments z1, z2",
        "vcov": "homoskedastic",
    },
    "diagnostics": {
        "critical_value_f_95": float(crit),
        "quadratic_A": float(A),
        "quadratic_B": float(B),
        "quadratic_C": float(C),
        "discriminant": float(disc),
        "denominator_df": int(df_den),
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
