import json

import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")

regions = df.groupby("region_id")[["region_weight", "x", "y"]].first()
share_wide = df.pivot_table(index="region_id", columns="industry_id", values="share",
                            aggfunc="sum", fill_value=0.0)
regions = regions.loc[share_wide.index]
shock_by_industry = df.groupby("industry_id")["shock"].first().loc[share_wide.columns]

S = share_wide.to_numpy(float)
shock = shock_by_industry.to_numpy(float)
weight_raw = regions["region_weight"].to_numpy(float)
e = weight_raw / weight_raw.sum()
x = regions["x"].to_numpy(float)
y = regions["y"].to_numpy(float)
z = S @ shock

y0 = y - e @ y
x0 = x - e @ x
z0 = z - e @ z

mass = e @ S
N = len(shock)


def aggregate(v0):
    return (S.T @ (e * v0)) / mass


ybar = aggregate(y0)
xbar = aggregate(x0)
zbar = aggregate(z0)


def shock_iv(dependent, endogenous):
    regressors = np.column_stack([np.ones(N), endogenous])
    instruments = np.column_stack([np.ones(N), shock])
    cross = instruments.T @ (mass[:, None] * regressors)
    beta = np.linalg.solve(cross, instruments.T @ (mass * dependent))
    residual = dependent - regressors @ beta
    scores = instruments * (mass * residual)[:, None]
    inverse = np.linalg.inv(cross)
    hc1 = N / (N - 2)
    covariance = hc1 * inverse @ (scores.T @ scores) @ inverse.T
    return float(beta[1]), float(np.sqrt(covariance[1, 1]))


effect, effect_se = shock_iv(ybar, xbar)
first_stage, first_stage_se = shock_iv(xbar, zbar)
effective_shocks = float(1.0 / np.sum(mass ** 2))

regional_effect = float(np.sum(e * z0 * y0) / np.sum(e * z0 * x0))
regional_first_stage = float(np.sum(e * z0 * x0) / np.sum(e * z0 ** 2))

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": effect, "se": effect_se, "n_obs": int(N)},
        {"term": "first_stage", "estimate": first_stage, "se": first_stage_se, "n_obs": int(N)},
        {"term": "effective_shocks", "estimate": effective_shocks, "se": None, "n_obs": int(N)},
    ],
    "method_metadata": {
        "estimator": "Regional weighted 2SLS with BHJ shock-level weighted IV aggregation",
        "vcov": "Shock-level structural IV HC1 with N/(N-2) multiplier, no clustering",
    },
    "diagnostics": {
        "n_regions": int(len(e)),
        "n_industries": int(N),
        "regional_effect_check": regional_effect,
        "regional_first_stage_check": regional_first_stage,
    },
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2)
