import json

import numpy as np
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("input.csv")
df["date"] = pd.to_datetime(df["date"])
df = df.sort_values("date").reset_index(drop=True)

df["dlvix"] = np.log(df["vix"]).diff()
df["lsales"] = np.log(df["sales"])

L = 15
for k in range(1, L + 1):
    df[f"lag_{k}"] = df["dlvix"].shift(k)

model_df = df.dropna(subset=["lsales"] + [f"lag_{k}" for k in range(1, L + 1)]).copy()

y = model_df["lsales"].values
X = sm.add_constant(model_df[[f"lag_{k}" for k in range(1, L + 1)]].values)
N = len(y)

ols = sm.OLS(y, X).fit()
cov_nw = sm.stats.sandwich_covariance.cov_hac(ols, nlags=L, weights_func=None)
cov_nw = ols.cov_HC0  # placeholder replaced below
