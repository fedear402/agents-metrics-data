import json

import pandas as pd
from statsmodels.tsa.arima.model import ARIMA

df = pd.read_csv("./input.csv").sort_values("t").reset_index(drop=True)
y = df["y"].astype(float).reset_index(drop=True)

model = ARIMA(y, order=(1, 1, 1), trend="n")
res = model.fit()

fc = res.get_forecast(steps=1)
mean = float(fc.predicted_mean.iloc[0])
se = float(fc.se_mean.iloc[0])
ci = fc.conf_int(alpha=0.05)
lower = float(ci.iloc[0, 0])
upper = float(ci.iloc[0, 1])
n_obs = int(res.nobs)

out = {
    "task_id": "arima_forecast",
    "platform": "python",
    "estimates": [
        {"term": "forecast", "estimate": mean, "se": se, "n_obs": n_obs},
        {"term": "lower_95", "estimate": lower, "se": None, "n_obs": n_obs},
        {"term": "upper_95", "estimate": upper, "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "ARIMA(1,1,1) by maximum likelihood, no constant",
        "vcov": "outer product of gradients (statsmodels default)",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(out, f)
