import json

import numpy as np
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("input.csv")
df["date"] = pd.to_datetime(df["date"])
df = df.sort_values("date").reset_index(drop=True)

df["dlog_vix"] = np.log(df["vix"]).diff()
df["log_sales"] = np.log(df["sales"])

L = 15
for k in range(1, L + 1):
    df[f"lag_{k}"] = df["dlog_vix"].shift(k)

df = df.dropna(subset=["log_sales"] + [f"lag_{k}" for k in range(1, L + 1)]).reset_index(drop=True)

y = df["log_sales"].values
X = sm.add_constant(df[[f"lag_{k}" for k in range(1, L + 1)]].values)
N = len(y)

model = sm.OLS(y, X).fit(
    cov_type="HAC",
    cov_kwds={"maxlags": L, "kernel": "bartlett", "use_correction": False},
)

scale = N / (N - (L + 1))
vcov = model.cov_params() * scale

beta = model.params[1:]
V = vcov[1:, 1:]

w = np.ones(L)
cum_est = float(beta.sum())
cum_var = float(w @ V @ w)
cum_se = float(np.sqrt(cum_var))

lag1_est = float(beta[0])
lag1_se = float(np.sqrt(V[0, 0]))
lag15_est = float(beta[L - 1])
lag15_se = float(np.sqrt(V[L - 1, L - 1]))

result = {
    "task_id": "applied_cumulative_hac",
    "platform": "python",
    "estimates": [
        {"term": "cumulative_response", "estimate": cum_est, "se": cum_se, "n_obs": int(N)},
        {"term": "lag_1", "estimate": lag1_est, "se": lag1_se, "n_obs": int(N)},
        {"term": "lag_15", "estimate": lag15_est, "se": lag15_se, "n_obs": int(N)},
    ],
    "method_metadata": {
        "estimator": "OLS regression of log(sales) on intercept and 15 lags of first difference of log(vix)",
        "vcov": "Newey-West HAC, maxlags=15, Bartlett weights 1-j/16, scaled by N/(N-16)",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
