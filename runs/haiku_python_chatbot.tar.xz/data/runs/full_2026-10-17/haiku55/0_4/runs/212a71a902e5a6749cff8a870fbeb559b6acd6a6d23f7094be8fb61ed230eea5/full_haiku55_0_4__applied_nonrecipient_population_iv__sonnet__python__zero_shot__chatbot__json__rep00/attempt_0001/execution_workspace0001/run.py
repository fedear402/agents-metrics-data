import json

import numpy as np
import pandas as pd

hh = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

df = hh[hh["recipient"] == 0].copy()
for col in ["eligible", "treated", "recipient", "instrument", "dose", "baseline", "weight", "outcome"]:
    df[col] = pd.to_numeric(df[col]).astype(float)

e = df["eligible"].to_numpy()
ne = 1.0 - e
dose = df["dose"].to_numpy()
base = df["baseline"].to_numpy()
inst = df["instrument"].to_numpy()
w = df["weight"].to_numpy()
y = df["outcome"].to_numpy()

R = np.column_stack([dose * ne, dose * e, ne, e, base * ne, base * e])
Z = np.column_stack([ne, e, base * ne, base * e, inst * ne, inst * e])

A = Z.T @ (w[:, None] * R)
b = Z.T @ (w * y)
beta = np.linalg.solve(A, b)
slope0, slope1 = beta[0], beta[1]

m0 = np.sum(w * dose * ne) / np.sum(w * ne)
m1 = np.sum(w * dose * e) / np.sum(w * e)

ineligible_effect = slope0 * m0
eligible_nonrecipient_effect = slope1 * m1

pop = census.groupby("eligible")["nonrecipient_population"].sum().astype(float)
pop0 = float(pop.loc[0.0])
pop1 = float(pop.loc[1.0])
population_effect = (pop0 * ineligible_effect + pop1 * eligible_nonrecipient_effect) / (pop0 + pop1)

n_obs = int(len(df))

estimates = [
    {"term": "ineligible_effect", "estimate": float(ineligible_effect), "se": None, "n_obs": n_obs},
    {"term": "eligible_nonrecipient_effect", "estimate": float(eligible_nonrecipient_effect), "se": None, "n_obs": n_obs},
    {"term": "population_effect", "estimate": float(population_effect), "se": None, "n_obs": n_obs},
]

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "method": "weighted 2SLS, exactly identified, no added intercept",
        "estimator_weight": "weight",
        "endogenous": ["dose*(1-eligible)", "dose*eligible"],
        "exogenous": ["1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"],
        "instruments": [
            "1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible",
            "instrument*(1-eligible)", "instrument*eligible",
        ],
        "sample": "households with recipient == 0, all treated statuses and eligibility groups",
        "group_effect": "dose slope times household-weighted mean dose within eligibility group",
        "population_weights": "census nonrecipient_population by eligible group",
        "counterfactual": "dose set to zero for every retained household (synthetic attribution convention)",
        "standard_errors": "not computed; se reported as null",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "n_ineligible_obs": int(np.sum(ne)),
        "n_eligible_obs": int(np.sum(e)),
        "dose_slope_ineligible": float(slope0),
        "dose_slope_eligible": float(slope1),
        "weighted_mean_dose_ineligible": float(m0),
        "weighted_mean_dose_eligible": float(m1),
        "census_population_ineligible": pop0,
        "census_population_eligible": pop1,
        "instrument_matrix_rank": int(np.linalg.matrix_rank(A)),
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
