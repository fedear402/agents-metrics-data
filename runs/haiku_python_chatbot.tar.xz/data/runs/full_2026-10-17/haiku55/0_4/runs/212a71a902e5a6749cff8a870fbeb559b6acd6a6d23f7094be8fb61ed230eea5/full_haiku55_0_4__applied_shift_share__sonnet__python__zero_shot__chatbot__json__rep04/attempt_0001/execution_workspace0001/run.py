import json

import numpy as np
import pandas as pd


def wiv(y, X, Z, w):
    A = Z.T @ (w[:, None] * X)
    b = np.linalg.solve(A, Z.T @ (w * y))
    u = y - X @ b
    return b, u, A


def hc1_se_slope(A, Z, u, w, n):
    scores = Z * (w * u)[:, None]
    meat = scores.T @ scores
    A_inv = np.linalg.inv(A)
    V = A_inv @ meat @ A_inv.T * n / (n - 2)
    return float(np.sqrt(V[1, 1]))


df = pd.read_csv("input.csv")

reg = df.groupby("region_id").agg(
    w=("region_weight", "first"),
    x=("x", "first"),
    y=("y", "first"),
)
reg["z"] = (df.assign(sz=df.share * df.shock).groupby("region_id")["sz"].sum())
reg["e"] = reg["w"] / reg["w"].sum()
e = reg["e"].values

for v in ["x", "y", "z"]:
    reg[v + "0"] = reg[v] - (e * reg[v]).sum()

ones_r = np.ones(len(reg))
X_iv = np.column_stack([ones_r, reg["x"].values])
Z_iv = np.column_stack([ones_r, reg["z"].values])
b_eff_reg, _, _ = wiv(reg["y"].values, X_iv, Z_iv, e)
effect_est = float(b_eff_reg[1])

X_fs = np.column_stack([ones_r, reg["z"].values])
A_fs = X_fs.T @ (e[:, None] * X_fs)
b_fs_reg = np.linalg.solve(A_fs, X_fs.T @ (e * reg["x"].values))
first_stage_est = float(b_fs_reg[1])

d = df.merge(reg[["e", "x0", "y0", "z0"]], left_on="region_id", right_index=True)
d["sw"] = d["e"] * d["share"]
d["ew_y"] = d["sw"] * d["y0"]
d["ew_x"] = d["sw"] * d["x0"]
d["ew_z"] = d["sw"] * d["z0"]

ind = d.groupby("industry_id").agg(
    s=("sw", "sum"),
    shock=("shock", "first"),
    ys=("ew_y", "sum"),
    xs=("ew_x", "sum"),
    zs=("ew_z", "sum"),
)
ind["ybar"] = ind["ys"] / ind["s"]
ind["xbar"] = ind["xs"] / ind["s"]
ind["zbar"] = ind["zs"] / ind["s"]

N = len(ind)
s = ind["s"].values
shock = ind["shock"].values
ones_n = np.ones(N)

Z_s = np.column_stack([ones_n, shock])

X_s_eff = np.column_stack([ones_n, ind["xbar"].values])
b_eff_s, u_eff, A_eff = wiv(ind["ybar"].values, X_s_eff, Z_s, s)
effect_se = hc1_se_slope(A_eff, Z_s, u_eff, s, N)

X_s_fs = np.column_stack([ones_n, ind["zbar"].values])
b_fs_s, u_fs, A_fs_s = wiv(ind["xbar"].values, X_s_fs, Z_s, s)
first_stage_se = hc1_se_slope(A_fs_s, Z_s, u_fs, s, N)

effective_shocks = float(1.0 / np.sum(s ** 2))

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": effect_est, "se": effect_se, "n_obs": int(N)},
        {"term": "first_stage", "estimate": first_stage_est, "se": first_stage_se, "n_obs": int(N)},
        {"term": "effective_shocks", "estimate": effective_shocks, "se": None, "n_obs": int(N)},
    ],
    "method_metadata": {
        "estimator": "Weighted 2SLS shift-share with BHJ shock-level weighted IV inference",
        "vcov": "Shock-level HC1 robust (N/(N-2)), structural IV residuals, analytic weights, no clustering",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
