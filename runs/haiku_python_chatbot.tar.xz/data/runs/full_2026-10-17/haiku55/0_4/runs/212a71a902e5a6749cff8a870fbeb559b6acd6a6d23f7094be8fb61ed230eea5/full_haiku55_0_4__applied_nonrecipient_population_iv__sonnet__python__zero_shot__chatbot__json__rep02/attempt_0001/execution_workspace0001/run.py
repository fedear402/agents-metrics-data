import json

import numpy as np
import pandas as pd

hh = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

hh = hh[pd.to_numeric(hh["recipient"]) == 0].copy()
for col in ["eligible", "instrument", "dose", "baseline", "weight", "outcome"]:
    hh[col] = pd.to_numeric(hh[col])

e1 = hh["eligible"].to_numpy(dtype=float)
e0 = 1.0 - e1
dose = hh["dose"].to_numpy(dtype=float)
base = hh["baseline"].to_numpy(dtype=float)
inst = hh["instrument"].to_numpy(dtype=float)
w = hh["weight"].to_numpy(dtype=float)
y = hh["outcome"].to_numpy(dtype=float)

X = np.column_stack([dose * e0, dose * e1, e0, e1, base * e0, base * e1])
Z = np.column_stack([e0, e1, base * e0, base * e1, inst * e0, inst * e1])

sw = np.sqrt(w)
Xs = X * sw[:, None]
Zs = Z * sw[:, None]
ys = y * sw

Xhat = Zs @ np.linalg.lstsq(Zs, Xs, rcond=None)[0]
beta = np.linalg.lstsq(Xhat, ys, rcond=None)[0]
slope0 = float(beta[0])
slope1 = float(beta[1])

n_total = int(len(hh))
n_inelig = int(np.sum(e0))
n_elig = int(np.sum(e1))

mean_dose0 = float(np.sum(w * dose * e0) / np.sum(w * e0))
mean_dose1 = float(np.sum(w * dose * e1) / np.sum(w * e1))

ineligible_effect = slope0 * mean_dose0
eligible_nonrecipient_effect = slope1 * mean_dose1

census_elig = census["eligible"].astype(int)
n_pop0 = float(census.loc[census_elig == 0, "nonrecipient_population"].sum())
n_pop1 = float(census.loc[census_elig == 1, "nonrecipient_population"].sum())
population_effect = (
    n_pop0 * ineligible_effect + n_pop1 * eligible_nonrecipient_effect
) / (n_pop0 + n_pop1)

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "ineligible_effect",
            "estimate": float(ineligible_effect),
            "se": None,
            "n_obs": n_total,
        },
        {
            "term": "eligible_nonrecipient_effect",
            "estimate": float(eligible_nonrecipient_effect),
            "se": None,
            "n_obs": n_total,
        },
        {
            "term": "population_effect",
            "estimate": float(population_effect),
            "se": None,
            "n_obs": n_total,
        },
    ],
    "method_metadata": {
        "estimator": "weighted two-stage least squares",
        "regression_weight": "weight",
        "intercept": False,
        "endogenous_columns": ["dose*(1-eligible)", "dose*eligible"],
        "exogenous_columns": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
        ],
        "instrument_columns": [
            "1-eligible",
            "eligible",
            "baseline*(1-eligible)",
            "baseline*eligible",
            "instrument*(1-eligible)",
            "instrument*eligible",
        ],
        "group_effect_definition": "fitted dose slope times weighted mean dose within eligibility group",
        "population_weights": "census nonrecipient_population by eligibility group",
        "counterfactual": "dose set to zero for every retained household (synthetic attribution convention)",
    },
    "diagnostics": {
        "n_retained_rows": n_total,
        "n_ineligible_rows": n_inelig,
        "n_eligible_rows": n_elig,
        "slope_dose_ineligible": slope0,
        "slope_dose_eligible": slope1,
        "weighted_mean_dose_ineligible": mean_dose0,
        "weighted_mean_dose_eligible": mean_dose1,
        "census_nonrecipient_population_ineligible": n_pop0,
        "census_nonrecipient_population_eligible": n_pop1,
        "instrument_matrix_rank": int(np.linalg.matrix_rank(Zs)),
        "regressor_matrix_rank": int(np.linalg.matrix_rank(Xs)),
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
