import json

import numpy as np
import pandas as pd
from scipy import stats

df = pd.read_csv("input.csv")
n = len(df)
y = df["y"].to_numpy(dtype=float)
endog = df["endog"].to_numpy(dtype=float)
x = df["x"].to_numpy(dtype=float)
z = df[["z1", "z2"]].to_numpy(dtype=float)

const = np.ones(n)
W_r = np.column_stack([const, x])
W_u = np.column_stack([const, x, z])

df_den = n - 4
crit = stats.f.ppf(0.95, 2, df_den)


def rss(v, W):
    coef, _, _, _ = np.linalg.lstsq(W, v, rcond=None)
    r = v - W @ coef
    return float(r @ r)


def f_stat(beta):
    v = y - beta * endog
    rss_r = rss(v, W_r)
    rss_u = rss(v, W_u)
    return ((rss_r - rss_u) / 2.0) / (rss_u / df_den)


# Accept iff RSS_r(b) - k * RSS_u(b) <= 0, where k = 1 + 2*crit/(n-4).
# Both RSS terms are exactly quadratic in beta, so the criterion is a quadratic.
k = 1.0 + 2.0 * crit / df_den


def aux(beta):
    v = y - beta * endog
    return rss(v, W_r) - k * rss(v, W_u)


c0 = aux(0.0)
ap = aux(1.0)
am = aux(-1.0)
qa = (ap + am) / 2.0 - c0
qb = (ap - am) / 2.0
qc = c0

tol = 1e-12
boundary_low = float("nan")
boundary_high = float("nan")
unbounded = 0

if abs(qa) <= tol:
    if abs(qb) > tol:
        root = -qc / qb
        boundary_low = root
        if qb > 0:
            unbounded = 1
            boundary_high = float("nan")
        else:
            unbounded = 1
            boundary_high = float("nan")
    else:
        unbounded = 1 if qc <= 0 else 0
else:
    disc = qb * qb - 4.0 * qa * qc
    if disc < 0:
        if qa < 0:
            unbounded = 1
    else:
        r1, r2 = sorted([(-qb - np.sqrt(disc)) / (2.0 * qa),
                         (-qb + np.sqrt(disc)) / (2.0 * qa)])
        boundary_low = float(r1)
        boundary_high = float(r2)
        if qa < 0:
            unbounded = 1

accepts_zero = 1 if f_stat(0.0) <= crit else 0
ar_f_at_one = f_stat(1.0)

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": [
        {"term": "boundary_low", "estimate": float(boundary_low), "se": None, "n_obs": int(n)},
        {"term": "boundary_high", "estimate": float(boundary_high), "se": None, "n_obs": int(n)},
        {"term": "accepts_zero", "estimate": float(accepts_zero), "se": None, "n_obs": int(n)},
        {"term": "unbounded", "estimate": float(unbounded), "se": None, "n_obs": int(n)},
        {"term": "ar_f_at_one", "estimate": float(ar_f_at_one), "se": None, "n_obs": int(n)},
    ],
    "method_metadata": {
        "estimator": "Anderson-Rubin test inversion, homoskedastic joint F test of excluded instruments",
        "vcov": "homoskedastic",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
