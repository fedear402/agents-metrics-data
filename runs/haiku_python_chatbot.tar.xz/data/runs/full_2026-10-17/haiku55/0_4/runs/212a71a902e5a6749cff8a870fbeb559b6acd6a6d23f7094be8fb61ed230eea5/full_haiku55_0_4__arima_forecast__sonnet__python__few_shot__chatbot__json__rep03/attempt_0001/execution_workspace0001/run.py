import json

import pandas as pd
from statsmodels.tsa.arima.model import ARIMA

df = pd.read_csv("./input.csv")
y = df["y"].astype(float).reset_index(drop=True)

fit = ARIMA(y, order=(1, 1, 1), trend="n").fit()

steps = int(251 - df["t"].max())
fc = fit.get_forecast(steps=steps)
frame = fc.summary_frame(alpha=0.05).iloc[-1]

n_obs = int(len(y))
out = {
    "task_id": "arima_forecast",
    "platform": "python",
    "estimates": [
        {"term": "forecast", "estimate": float(frame["mean"]),
         "se": float(fc.se_mean.iloc[-1]), "n_obs": n_obs},
        {"term": "lower_95", "estimate": float(frame["mean_ci_lower"]),
         "se": None, "n_obs": n_obs},
        {"term": "upper_95", "estimate": float(frame["mean_ci_upper"]),
         "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "ARIMA(1,1,1) no constant by maximum likelihood",
        "vcov": "statsmodels default (outer product / observed information)",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(out, f)
