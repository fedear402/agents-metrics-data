import json

import numpy as np
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("input.csv")
n = len(df)

X = sm.add_constant(df[["x", "z"]].astype(float))
y = df["y"].astype(int)

model = sm.MNLogit(y, X)
res = model.fit(method="newton", maxiter=500, tol=1e-10, disp=False)

params = np.asarray(res.params, dtype=float)
bse = np.asarray(res.bse, dtype=float)

const1, const2 = params[0, 0], params[0, 1]
p2_zero = np.exp(const2) / (1.0 + np.exp(const1) + np.exp(const2))

converged = bool(getattr(res, "mle_retvals", {}).get("converged", True))

estimates = [
    {"term": "x_cat1", "estimate": float(params[1, 0]), "se": float(bse[1, 0]), "n_obs": n},
    {"term": "z_cat1", "estimate": float(params[2, 0]), "se": float(bse[2, 0]), "n_obs": n},
    {"term": "x_cat2", "estimate": float(params[1, 1]), "se": float(bse[1, 1]), "n_obs": n},
    {"term": "z_cat2", "estimate": float(params[2, 1]), "se": float(bse[2, 1]), "n_obs": n},
    {"term": "prob_cat2_zero", "estimate": float(p2_zero), "se": None, "n_obs": n},
]

result = {
    "task_id": "broad_multinomial_logit",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "multinomial logit, maximum likelihood (statsmodels MNLogit), base outcome 0",
        "vcov": "conventional observed-information (inverse negative Hessian at MLE)",
    },
    "diagnostics": {
        "converged": converged,
        "log_likelihood": float(res.llf),
        "n_obs": n,
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
