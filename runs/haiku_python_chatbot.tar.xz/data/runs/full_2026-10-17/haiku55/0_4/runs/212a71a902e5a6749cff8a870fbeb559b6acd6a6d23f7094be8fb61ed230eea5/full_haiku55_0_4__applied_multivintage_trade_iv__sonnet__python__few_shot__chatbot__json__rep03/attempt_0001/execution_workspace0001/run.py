import json

import numpy as np
import pandas as pd

crosswalk = pd.read_csv("crosswalk.csv")
trade = pd.read_csv("trade.csv")
areas = pd.read_csv("areas.csv")
employment = pd.read_csv("employment.csv")
outcomes = pd.read_csv("outcomes.csv")

crosswalk["code"] = crosswalk["code"].astype(str)
trade["code"] = trade["code"].astype(str)
trade = trade.merge(crosswalk, on="code", how="left")

periods = sorted(areas["period"].unique())
area_ids = sorted(areas["area"].unique())
industries = sorted(trade["industry"].dropna().unique())


def exposure(period, vintage, change_col):
    t = trade[trade["period"] == period].set_index("industry")
    price_index = t["price_index"].iloc[0]
    years = t["years"].iloc[0]
    emp = (
        employment[(employment["period"] == period) & (employment["vintage"] == vintage)]
        .groupby(["area", "industry"])["employment"]
        .sum()
        .unstack(fill_value=0.0)
        .reindex(index=area_ids, columns=industries, fill_value=0.0)
    )
    total = (
        areas[(areas["period"] == period) & (areas["vintage"] == vintage)]
        .set_index("area")["total_employment"]
        .reindex(area_ids)
        .to_numpy(float)
    )
    national = emp.sum(axis=0).to_numpy(float)
    change = t.loc[industries, change_col].to_numpy(float)
    shock = change / national / (price_index / 100) / 1000 * (10 / years)
    return (emp.to_numpy(float) * shock).sum(axis=1) / total


records = []
for k, p in enumerate(periods):
    x = exposure(p, "base", "us_change")
    z = exposure(p, "early", "other_change")
    for i, a in enumerate(area_ids):
        records.append({"area": a, "period": p, "period_idx": k, "x": x[i], "z": z[i]})

df = pd.DataFrame(records)
df = df.merge(outcomes, on=["area", "period"], how="inner")
base_pop = areas[areas["vintage"] == "base"][["area", "period", "population"]]
df = df.merge(base_pop, on=["area", "period"], how="inner")

n_obs = int(len(df))
ones = np.ones(n_obs)
period_idx = df["period_idx"].to_numpy(float)
control = df["control"].to_numpy(float)
x = df["x"].to_numpy(float)
z = df["z"].to_numpy(float)
y = df["change_pp"].to_numpy(float)
w = np.sqrt(df["population"].to_numpy(float))

X = np.column_stack([ones, period_idx, control, x])
Z = np.column_stack([ones, period_idx, control, z])

Xw = X * w[:, None]
Zw = Z * w[:, None]
yw = y * w

Q, _ = np.linalg.qr(Zw)
Xh = Q @ (Q.T @ Xw)
beta = np.linalg.lstsq(Xh, yw, rcond=None)[0]

area0 = area_ids[0]
row_p0 = df[(df["area"] == area0) & (df["period_idx"] == 0)].iloc[0]
row_p1 = df[(df["area"] == area0) & (df["period_idx"] == 1)].iloc[0]

estimates = [
    {"term": "iv_slope", "estimate": float(beta[3]), "se": None, "n_obs": n_obs},
    {"term": "exposure_area0_period0", "estimate": float(row_p0["x"]), "se": None, "n_obs": n_obs},
    {"term": "exposure_area0_period1", "estimate": float(row_p1["x"]), "se": None, "n_obs": n_obs},
    {"term": "instrument_area0_period0", "estimate": float(row_p0["z"]), "se": None, "n_obs": n_obs},
]

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": estimates,
    "method_metadata": {
        "estimator": "weighted_2sls",
        "dependent": "change_pp",
        "regressors": ["intercept", "period", "control", "x"],
        "instruments": ["intercept", "period", "control", "z"],
        "weights": "base_vintage_population",
        "exposure_denominator": "total_employment by vintage",
        "interval_convention": "10/years scaling, price_index/100 deflator",
    },
    "diagnostics": {
        "n_obs": n_obs,
        "n_areas": int(len(area_ids)),
        "n_periods": int(len(periods)),
        "n_industries": int(len(industries)),
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
