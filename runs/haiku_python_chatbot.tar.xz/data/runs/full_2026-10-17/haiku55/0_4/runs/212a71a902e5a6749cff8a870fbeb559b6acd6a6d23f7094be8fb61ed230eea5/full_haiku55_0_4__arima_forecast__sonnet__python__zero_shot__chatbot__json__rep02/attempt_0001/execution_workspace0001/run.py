import json
import numpy as np
import pandas as pd
from statsmodels.tsa.arima.model import ARIMA

df = pd.read_csv("./input.csv")
df = df.dropna(subset=["t", "y"]).sort_values("t").reset_index(drop=True)

train = df[df["t"] < 251]
y = train["y"].astype(float).to_numpy()

model = ARIMA(y, order=(1, 1, 1), trend="n")
res = model.fit()

fc = res.get_forecast(steps=1)
forecast_mean = float(np.asarray(fc.predicted_mean)[0])
forecast_se = float(np.sqrt(np.asarray(fc.var_pred_mean)[0]))
ci = np.asarray(fc.conf_int(alpha=0.05))[0]
lower_95 = float(ci[0])
upper_95 = float(ci[1])

n_obs = int(len(y))
converged = bool(getattr(res.mle_retvals, "converged", True)) if getattr(res, "mle_retvals", None) is not None else True

result = {
    "task_id": "arima_forecast",
    "platform": "python",
    "estimates": [
        {"term": "forecast", "estimate": forecast_mean, "se": forecast_se, "n_obs": n_obs},
        {"term": "lower_95", "estimate": lower_95, "se": None, "n_obs": n_obs},
        {"term": "upper_95", "estimate": upper_95, "se": None, "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "ARIMA(1,1,1) maximum likelihood, no constant (statsmodels ARIMA, trend='n')",
        "vcov": "numerical Hessian (statsmodels default)",
    },
    "diagnostics": {
        "forecast_target_t": 251,
        "train_last_t": int(train["t"].iloc[-1]),
        "log_likelihood": float(res.llf),
        "aic": float(res.aic),
        "bic": float(res.bic),
        "converged": converged,
        "ar1_coef": float(res.params[0]),
        "ma1_coef": float(res.params[1]),
        "sigma2": float(res.params[2]),
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
