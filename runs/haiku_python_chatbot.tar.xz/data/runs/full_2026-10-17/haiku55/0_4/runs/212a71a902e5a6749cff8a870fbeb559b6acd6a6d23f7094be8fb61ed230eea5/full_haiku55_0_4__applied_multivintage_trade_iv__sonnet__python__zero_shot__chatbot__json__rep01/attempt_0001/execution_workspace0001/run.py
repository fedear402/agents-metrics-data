import json

import numpy as np
import pandas as pd


def period_sort_key(value):
    try:
        return (0, float(value))
    except ValueError:
        return (1, str(value))


crosswalk = pd.read_csv("crosswalk.csv", dtype=str)
trade = pd.read_csv("trade.csv", dtype={"period": str, "code": str})
areas = pd.read_csv("areas.csv", dtype={"area": str, "period": str, "vintage": str})
employment = pd.read_csv(
    "employment.csv",
    dtype={"area": str, "period": str, "vintage": str, "industry": str},
)
outcomes = pd.read_csv("outcomes.csv", dtype={"area": str, "period": str})

trade = trade.merge(crosswalk, on="code", how="inner")

periods = sorted(areas["period"].unique(), key=period_sort_key)
period_index = {p: i for i, p in enumerate(periods)}
industries = sorted(trade["industry"].unique())

trade_pi = trade.drop_duplicates(["period", "industry"]).set_index(["period", "industry"])
price = trade.groupby("period")["price_index"].first().to_dict()
years = trade.groupby("period")["years"].first().to_dict()

emp_dict = (
    employment.groupby(["area", "period", "vintage", "industry"])["employment"]
    .sum()
    .to_dict()
)
nat = (
    employment.groupby(["period", "vintage", "industry"])["employment"]
    .sum()
    .to_dict()
)
total = (
    areas.groupby(["area", "period", "vintage"])["total_employment"].sum().to_dict()
)
pop = (
    areas[areas["vintage"] == "base"]
    .groupby(["area", "period"])["population"]
    .sum()
    .reset_index()
)


def exposure(area, period, vintage, shock):
    t_total = total[(area, period, vintage)]
    p = price[period] / 100.0
    interval = years[period]
    s = 0.0
    for ind in industries:
        e_ij = emp_dict.get((area, period, vintage, ind), 0.0)
        n_j = nat[(period, vintage, ind)]
        d_j = trade_pi.loc[(period, ind), shock]
        s += (e_ij / t_total) * (d_j / n_j) / p / 1000.0 * (10.0 / interval)
    return s


est = outcomes.merge(pop, on=["area", "period"], how="left")
n_obs = int(len(est))

x = np.array(
    [exposure(a, p, "base", "us_change") for a, p in zip(est["area"], est["period"])]
)
z = np.array(
    [exposure(a, p, "early", "other_change") for a, p in zip(est["area"], est["period"])]
)

pidx = est["period"].map(period_index).astype(float).values
control = est["control"].astype(float).values
y = est["change_pp"].astype(float).values
w = est["population"].astype(float).values

X = np.column_stack([np.ones(n_obs), pidx, control, x])
Z = np.column_stack([np.ones(n_obs), pidx, control, z])

sw = np.sqrt(w)
Xw = X * sw[:, None]
Zw = Z * sw[:, None]
yw = y * sw

first_stage = np.linalg.lstsq(Zw, Xw, rcond=None)[0]
Xhat = Zw @ first_stage
beta = np.linalg.lstsq(Xhat, yw, rcond=None)[0]

iv_slope = float(beta[3])
exposure_area0_period0 = float(exposure("0", periods[0], "base", "us_change"))
exposure_area0_period1 = float(exposure("0", periods[1], "base", "us_change"))
instrument_area0_period0 = float(exposure("0", periods[0], "early", "other_change"))

result = {
    "task_id": "applied_multivintage_trade_iv",
    "platform": "python",
    "estimates": [
        {"term": "iv_slope", "estimate": iv_slope, "se": None, "n_obs": n_obs},
        {
            "term": "exposure_area0_period0",
            "estimate": exposure_area0_period0,
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "exposure_area0_period1",
            "estimate": exposure_area0_period1,
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "instrument_area0_period0",
            "estimate": instrument_area0_period0,
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "weighted two-stage least squares",
        "endogenous": ["x"],
        "instruments": ["z"],
        "exogenous_controls": ["intercept", "period", "control"],
        "outcome": "change_pp",
        "weights": "base-vintage population",
        "periods": [str(p) for p in periods],
        "industries": [str(i) for i in industries],
    },
    "diagnostics": {
        "n_obs": n_obs,
        "n_areas": int(est["area"].nunique()),
        "n_periods": int(len(periods)),
        "n_industries": int(len(industries)),
        "first_stage_z_coefficient": float(first_stage[3, 3]),
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
