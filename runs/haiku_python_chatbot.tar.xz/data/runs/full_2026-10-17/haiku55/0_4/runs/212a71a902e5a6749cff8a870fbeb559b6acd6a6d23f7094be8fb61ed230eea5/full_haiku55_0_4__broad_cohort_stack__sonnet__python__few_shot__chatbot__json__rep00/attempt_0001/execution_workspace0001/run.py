import json

import numpy as np
import pandas as pd

df = pd.read_csv('input.csv')[['id', 'time', 'g', 'y']]
df['id'] = df['id'].astype(int)
df['time'] = df['time'].astype(int)
df['g'] = df['g'].astype(int)
df['y'] = df['y'].astype(float)

estimates = []
atts = []
treated_counts = []
row_counts = []
diagnostics = {}

for c in [3, 5, 7]:
    window = df[(df['time'] >= c - 2) & (df['time'] <= c + 2)]
    eligible = window[(window['g'] == c) | (window['g'] == 0) | (window['g'] > c + 2)]
    times_per_unit = eligible.groupby('id')['time'].nunique()
    keep_ids = times_per_unit[times_per_unit == 5].index
    d = eligible[eligible['id'].isin(keep_ids)].sort_values(['id', 'time']).reset_index(drop=True)

    did = ((d['g'] == c) & (d['time'] >= c)).astype(float).to_numpy()
    unit_fe = pd.get_dummies(d['id'].astype(str), drop_first=True, dtype=float).to_numpy()
    time_fe = pd.get_dummies(d['time'].astype(str), drop_first=True, dtype=float).to_numpy()
    X = np.column_stack([np.ones(len(d)), did, unit_fe, time_fe])
    beta = np.linalg.lstsq(X, d['y'].to_numpy(), rcond=None)[0]
    att = float(beta[1])

    n_treated = int(d.loc[d['g'] == c, 'id'].nunique())
    n_control = int(d.loc[d['g'] != c, 'id'].nunique())
    n_rows = int(len(d))

    atts.append(att)
    treated_counts.append(n_treated)
    row_counts.append(n_rows)
    estimates.append({'term': f'att_g{c}', 'estimate': att, 'se': None, 'n_obs': n_rows})
    diagnostics[f'g{c}'] = {'retained_treated': n_treated, 'retained_controls': n_control}

weights = np.array(treated_counts, dtype=float)
att_weighted = float(np.sum(weights * np.array(atts)) / np.sum(weights))
estimates.append({'term': 'att_weighted', 'estimate': att_weighted, 'se': None, 'n_obs': int(sum(row_counts))})

output = {
    'task_id': 'broad_cohort_stack',
    'platform': 'python',
    'estimates': estimates,
    'method_metadata': {},
    'diagnostics': diagnostics,
}

with open('result.json', 'w') as stream:
    json.dump(output, stream, indent=2, allow_nan=False)
