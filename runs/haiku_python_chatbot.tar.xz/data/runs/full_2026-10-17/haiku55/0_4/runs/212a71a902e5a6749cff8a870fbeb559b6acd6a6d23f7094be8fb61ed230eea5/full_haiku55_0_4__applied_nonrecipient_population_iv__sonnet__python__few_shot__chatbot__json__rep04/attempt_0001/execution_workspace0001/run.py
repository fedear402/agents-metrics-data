import json

import numpy as np
import pandas as pd
from linearmodels.iv import IV2SLS

hh = pd.read_csv("households.csv")
census = pd.read_csv("census.csv")

d = hh[hh["recipient"] == 0].copy()
e = d["eligible"].astype(float)
ne = 1.0 - e
w = d["weight"].astype(float)
y = d["outcome"].astype(float)

X = pd.DataFrame(
    {
        "ineligible": ne,
        "eligible": e,
        "baseline_ineligible": d["baseline"] * ne,
        "baseline_eligible": d["baseline"] * e,
    },
    index=d.index,
)
endog = pd.DataFrame(
    {
        "dose_ineligible": d["dose"] * ne,
        "dose_eligible": d["dose"] * e,
    },
    index=d.index,
)
Z = pd.DataFrame(
    {
        "instrument_ineligible": d["instrument"] * ne,
        "instrument_eligible": d["instrument"] * e,
    },
    index=d.index,
)

fit = IV2SLS(y, X, endog, Z, weights=w).fit()

b_ineligible = float(fit.params["dose_ineligible"])
b_eligible = float(fit.params["dose_eligible"])

mask0 = e == 0
mask1 = e == 1
mean_dose_0 = float(np.average(d.loc[mask0, "dose"], weights=w[mask0]))
mean_dose_1 = float(np.average(d.loc[mask1, "dose"], weights=w[mask1]))

ineligible_effect = b_ineligible * mean_dose_0
eligible_nonrecipient_effect = b_eligible * mean_dose_1

pop = census.set_index("eligible")["nonrecipient_population"].astype(float)
pop0 = float(pop.loc[0])
pop1 = float(pop.loc[1])
population_effect = float(
    np.average(
        [ineligible_effect, eligible_nonrecipient_effect],
        weights=[pop0, pop1],
    )
)

n_obs = int(len(d))
n_ineligible = int(mask0.sum())
n_eligible = int(mask1.sum())

result = {
    "task_id": "applied_nonrecipient_population_iv",
    "platform": "python",
    "estimates": [
        {
            "term": "ineligible_effect",
            "estimate": float(ineligible_effect),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "eligible_nonrecipient_effect",
            "estimate": float(eligible_nonrecipient_effect),
            "se": None,
            "n_obs": n_obs,
        },
        {
            "term": "population_effect",
            "estimate": float(population_effect),
            "se": None,
            "n_obs": n_obs,
        },
    ],
    "method_metadata": {
        "estimator": "weighted two-stage least squares (linearmodels IV2SLS)",
        "sample": "households with recipient == 0, all village treatment statuses",
        "endogenous": ["dose*(1-eligible)", "dose*eligible"],
        "exogenous": ["1-eligible", "eligible", "baseline*(1-eligible)", "baseline*eligible"],
        "excluded_instruments": ["instrument*(1-eligible)", "instrument*eligible"],
        "regression_weight": "weight",
        "group_effect": "dose slope times household-weighted mean dose within eligibility group",
        "counterfactual": "dose set to zero for every retained household (synthetic convention)",
        "population_weights": "nonrecipient_population from census.csv by eligibility group",
        "no_additional_intercept": True,
    },
    "diagnostics": {
        "n_obs": n_obs,
        "n_ineligible": n_ineligible,
        "n_eligible": n_eligible,
        "slope_dose_ineligible": b_ineligible,
        "slope_dose_eligible": b_eligible,
        "weighted_mean_dose_ineligible": mean_dose_0,
        "weighted_mean_dose_eligible": mean_dose_1,
        "census_nonrecipient_population_ineligible": pop0,
        "census_nonrecipient_population_eligible": pop1,
    },
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
