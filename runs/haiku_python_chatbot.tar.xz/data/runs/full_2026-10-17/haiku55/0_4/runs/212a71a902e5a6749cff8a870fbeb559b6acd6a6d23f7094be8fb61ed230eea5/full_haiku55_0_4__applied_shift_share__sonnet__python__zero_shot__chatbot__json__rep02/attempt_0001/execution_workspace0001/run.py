import json

import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")

regions = df.groupby("region_id").agg(
    region_weight=("region_weight", "first"),
    x=("x", "first"),
    y=("y", "first"),
)
regions["e"] = regions["region_weight"] / regions["region_weight"].sum()
df["e"] = df["region_id"].map(regions["e"])
df["sz"] = df["share"] * df["shock"]
regions["z"] = df.groupby("region_id")["sz"].sum()

e_r = regions["e"].values
for v in ["y", "x", "z"]:
    regions[v + "0"] = regions[v] - np.sum(e_r * regions[v].values)

y0 = regions["y0"].values
x0 = regions["x0"].values
z0 = regions["z0"].values

beta_reg = np.sum(e_r * z0 * y0) / np.sum(e_r * z0 * x0)
pi_reg = np.sum(e_r * z0 * x0) / np.sum(e_r * z0 * z0)

for v in ["y0", "x0", "z0"]:
    df[v] = df["region_id"].map(regions[v])
    df["w_" + v] = df["e"] * df["share"] * df[v]
df["ws"] = df["e"] * df["share"]

agg = df.groupby("industry_id").agg(
    s=("ws", "sum"),
    shock=("shock", "first"),
    wy=("w_y0", "sum"),
    wx=("w_x0", "sum"),
    wz=("w_z0", "sum"),
)
s = agg["s"].values
shock = agg["shock"].values
ybar = agg["wy"].values / s
xbar = agg["wx"].values / s
zbar = agg["wz"].values / s
N = len(agg)
ones = np.ones(N)


def iv_hc1(y, X, Z, w):
    n = len(y)
    ZW = Z * w[:, None]
    ZWZ_inv = np.linalg.inv(Z.T @ ZW)
    XWZ = X.T @ ZW
    M = XWZ @ ZWZ_inv @ XWZ.T
    H = np.linalg.solve(M, XWZ @ ZWZ_inv)
    beta = H @ (ZW.T @ y)
    u = y - X @ beta
    S = ZW * u[:, None]
    meat = S.T @ S
    V = H @ meat @ H.T * n / (n - 2)
    return beta, np.sqrt(np.diag(V))


_, se_effect_all = iv_hc1(
    ybar,
    np.column_stack([ones, xbar]),
    np.column_stack([ones, shock]),
    s,
)
_, se_fs_all = iv_hc1(
    xbar,
    np.column_stack([ones, zbar]),
    np.column_stack([ones, shock]),
    s,
)

effective_shocks = 1.0 / np.sum(s ** 2)

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": float(beta_reg), "se": float(se_effect_all[1]), "n_obs": int(N)},
        {"term": "first_stage", "estimate": float(pi_reg), "se": float(se_fs_all[1]), "n_obs": int(N)},
        {"term": "effective_shocks", "estimate": float(effective_shocks), "se": None, "n_obs": int(N)},
    ],
    "method_metadata": {
        "estimator": "Weighted 2SLS of y on intercept and x, instrumented by shift-share z; BHJ shock-level weighted IV",
        "vcov": "Shock-level HC1 robust (N/(N-2)), analytic weights, no clustering",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
