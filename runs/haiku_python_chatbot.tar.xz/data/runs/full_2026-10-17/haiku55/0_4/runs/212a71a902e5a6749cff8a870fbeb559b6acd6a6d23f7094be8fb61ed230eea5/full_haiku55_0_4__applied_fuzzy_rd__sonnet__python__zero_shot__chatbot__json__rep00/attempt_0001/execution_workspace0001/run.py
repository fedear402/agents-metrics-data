import json

import numpy as np
import pandas as pd
import statsmodels.api as sm

df = pd.read_csv("input.csv")
df = df[np.abs(df["score"]) < 1].copy()

h = 1.0
df["w"] = 1.0 - np.abs(df["score"])
df["right"] = (df["score"] >= 0).astype(float)
df["x"] = df["score"]

def design(d):
    x = d["x"].values
    r = d["right"].values
    return np.column_stack([
        np.ones(len(d)),
        r,
        x * (1 - r),
        x * r,
    ])

X = design(df)
w = df["w"].values
Y = df["earnings"].values
D = df["participated"].values

def wls_fit(y):
    model = sm.WLS(y, X, weights=w).fit()
    beta = model.params
    XtWX_inv = np.linalg.inv(X.T @ (X * w[:, None]))
    resid = y - X @ beta
    meat = (X * (w * resid)[:, None]).T @ (X * (w * resid)[:, None])
    V = XtWX_inv @ meat @ XtWX_inv
    return beta, V

beta_y, V_y = wls_fit(Y)
beta_d, V_d = wls_fit(D)

rf = beta_y[1]
fs = beta_d[1]

# Joint covariance of the two discontinuities (same obs, same weights)
XtWX_inv = np.linalg.inv(X.T @ (X * w[:, None]))
ry = Y - X @ beta_y
rd = D - X @ beta_d
meat_cross = (X * (w * ry)[:, None]).T @ (X * (w * rd)[:, None])
V_cross = XtWX_inv @ meat_cross @ XtWX_inv

var_rf = V_y[1, 1]
var_fs = V_d[1, 1]
cov_rf_fs = V_cross[1, 1]

tau = rf / fs
grad = np.array([1.0 / fs, -rf / fs**2])
cov_mat = np.array([[var_rf, cov_rf_fs], [cov_rf_fs, var_fs]])
var_tau = grad @ cov_mat @ grad
se_tau = float(np.sqrt(var_tau))

n_obs = int(len(df))

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": float(tau), "se": se_tau, "n_obs": n_obs},
        {"term": "reduced_form", "estimate": float(rf), "se": float(np.sqrt(var_rf)), "n_obs": n_obs},
        {"term": "first_stage", "estimate": float(fs), "se": float(np.sqrt(var_fs)), "n_obs": n_obs},
    ],
    "method_metadata": {
        "estimator": "fuzzy regression discontinuity, local linear, triangular kernel, bandwidth 1, cutoff 0, separate slopes and intercepts per side",
        "vcov": "HC0 heteroskedasticity-robust sandwich, delta method for ratio with joint covariance",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
