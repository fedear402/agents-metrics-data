import json

import numpy as np
import pandas as pd
from scipy.stats import f

data = pd.read_csv("input.csv")
y = data["y"].to_numpy(float)
endog = data["endog"].to_numpy(float)
x = data["x"].to_numpy(float)
z1 = data["z1"].to_numpy(float)
z2 = data["z2"].to_numpy(float)
n = len(y)

W = np.column_stack([np.ones(n), x])
Z = np.column_stack([np.ones(n), x, z1, z2])
q = 2
dfd = n - Z.shape[1]
crit = f.ppf(0.95, q, dfd)


def resid(v, design):
    return v - design @ np.linalg.lstsq(design, v, rcond=None)[0]


ry = resid(y, W)
rd = resid(endog, W)
uy = resid(y, Z)
ud = resid(endog, Z)

k = 1 + q * crit / dfd
A = rd @ rd - k * (ud @ ud)
B = -2 * (ry @ rd - k * (uy @ ud))
C = ry @ ry - k * (uy @ uy)
disc = B * B - 4 * A * C

low = high = None
unbounded = 0

if abs(A) > 1e-12:
    if disc > 0:
        r1, r2 = sorted([(-B - np.sqrt(disc)) / (2 * A), (-B + np.sqrt(disc)) / (2 * A)])
        low, high = float(r1), float(r2)
        unbounded = int(A < 0)
    elif disc == 0 and A > 0:
        low = high = float(-B / (2 * A))
    elif A < 0:
        unbounded = 1
elif abs(B) > 1e-12:
    root = float(-C / B)
    unbounded = 1
    if B > 0:
        high = root
    else:
        low = root
elif C > 0:
    unbounded = 0
else:
    unbounded = 1

accepts_zero = int(C <= 0)


def f_stat(beta):
    yb = y - beta * endog
    ssr_r = resid(yb, W) @ resid(yb, W)
    ssr_u = resid(yb, Z) @ resid(yb, Z)
    return ((ssr_r - ssr_u) / q) / (ssr_u / dfd)


ar_f_at_one = float(f_stat(1.0))

rows = [
    {"term": "boundary_low", "estimate": low, "se": None, "n_obs": n},
    {"term": "boundary_high", "estimate": high, "se": None, "n_obs": n},
    {"term": "accepts_zero", "estimate": accepts_zero, "se": None, "n_obs": n},
    {"term": "unbounded", "estimate": unbounded, "se": None, "n_obs": n},
    {"term": "ar_f_at_one", "estimate": ar_f_at_one, "se": None, "n_obs": n},
]

result = {
    "task_id": "broad_ar_confidence_set",
    "platform": "python",
    "estimates": rows,
    "method_metadata": {
        "estimator": "Anderson-Rubin test inversion with joint F test of excluded instruments",
        "vcov": "homoskedastic",
    },
    "diagnostics": {
        "critical_value": float(crit),
        "quadratic_A": float(A),
        "quadratic_B": float(B),
        "quadratic_C": float(C),
        "discriminant": float(disc),
    },
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
