import json

import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")

reg = df.groupby("region_id").agg(
    w=("region_weight", "first"),
    x=("x", "first"),
    y=("y", "first"),
)
reg["e"] = reg["w"] / reg["w"].sum()
df["sz"] = df["share"] * df["shock"]
reg["z"] = df.groupby("region_id")["sz"].sum()

e = reg["e"].to_numpy()
esum = e.sum()


def demean(v):
    return v - np.sum(e * v) / esum


reg["y0"] = demean(reg["y"].to_numpy())
reg["x0"] = demean(reg["x"].to_numpy())
reg["z0"] = demean(reg["z"].to_numpy())

beta_2sls = np.sum(e * reg["z0"] * reg["y0"]) / np.sum(e * reg["z0"] * reg["x0"])
pi_fs = np.sum(e * reg["z0"] * reg["x0"]) / np.sum(e * reg["z0"] ** 2)

d = df[["region_id", "industry_id", "share", "shock"]].copy()
for col in ["e", "y0", "x0", "z0"]:
    d[col] = d["region_id"].map(reg[col])
d["w"] = d["e"] * d["share"]
d["wy"] = d["w"] * d["y0"]
d["wx"] = d["w"] * d["x0"]
d["wz"] = d["w"] * d["z0"]

ind = d.groupby("industry_id").agg(
    s=("w", "sum"),
    sy=("wy", "sum"),
    sx=("wx", "sum"),
    sz=("wz", "sum"),
    shock=("shock", "first"),
)
ind["ybar"] = ind["sy"] / ind["s"]
ind["xbar"] = ind["sx"] / ind["s"]
ind["zbar"] = ind["sz"] / ind["s"]

s = ind["s"].to_numpy()
shock = ind["shock"].to_numpy()
ybar = ind["ybar"].to_numpy()
xbar = ind["xbar"].to_numpy()
zbar = ind["zbar"].to_numpy()
N = len(s)


def iv_fit(y, endog, instr, w):
    n = len(y)
    X = np.column_stack([np.ones(n), endog])
    Z = np.column_stack([np.ones(n), instr])
    A = Z.T @ (w[:, None] * X)
    A_inv = np.linalg.inv(A)
    b = A_inv @ (Z.T @ (w * y))
    u = y - X @ b
    meat = (Z * ((w ** 2) * (u ** 2))[:, None]).T @ Z
    V = A_inv @ meat @ A_inv.T * (n / (n - 2))
    return b, float(np.sqrt(V[1, 1]))


_, se_effect = iv_fit(ybar, xbar, shock, s)
_, se_first = iv_fit(xbar, zbar, shock, s)

effective_shocks = float(1.0 / np.sum(s ** 2))

result = {
    "task_id": "applied_shift_share",
    "platform": "python",
    "estimates": [
        {"term": "effect", "estimate": float(beta_2sls), "se": se_effect, "n_obs": int(N)},
        {"term": "first_stage", "estimate": float(pi_fs), "se": se_first, "n_obs": int(N)},
        {"term": "effective_shocks", "estimate": effective_shocks, "se": None, "n_obs": int(N)},
    ],
    "method_metadata": {
        "estimator": "Weighted 2SLS shift-share with shock-level weighted IV (Borusyak-Hull-Jaravel aggregation)",
        "vcov": "Shock-level heteroskedasticity-robust HC1 (N/(N-2)), analytic weights, no clustering",
    },
    "diagnostics": {},
}

with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
