import json

import numpy as np
import pandas as pd

df = pd.read_csv("input.csv")
score = df["score"].to_numpy(dtype=float)
part = df["participated"].to_numpy(dtype=float)
earn = df["earnings"].to_numpy(dtype=float)

inside = np.abs(score) < 1
score, part, earn = score[inside], part[inside], earn[inside]
w = 1.0 - np.abs(score)
n = len(score)

right = score >= 0
left = ~right

infl = np.zeros((n, 2))
intercepts = {}

for side_mask, sign, side_key in ((right, 1.0, "right"), (left, -1.0, "left")):
    X = np.column_stack([np.ones(side_mask.sum()), score[side_mask]])
    ws = w[side_mask]
    bread = np.linalg.inv(X.T @ (ws[:, None] * X))
    loading = ws * (X @ bread[:, 0])
    for k, outcome in enumerate((earn, part)):
        yy = outcome[side_mask]
        beta = bread @ X.T @ (ws * yy)
        resid = yy - X @ beta
        intercepts[(side_key, k)] = beta[0]
        infl[np.where(side_mask)[0], k] = sign * loading * resid

reduced_form = intercepts[("right", 0)] - intercepts[("left", 0)]
first_stage = intercepts[("right", 1)] - intercepts[("left", 1)]
treatment_effect = reduced_form / first_stage

cov = infl.T @ infl
se_rf = float(np.sqrt(cov[0, 0]))
se_fs = float(np.sqrt(cov[1, 1]))

gradient = np.array([1.0 / first_stage, -reduced_form / first_stage**2])
se_te = float(np.sqrt(gradient @ cov @ gradient))

result = {
    "task_id": "applied_fuzzy_rd",
    "platform": "python",
    "estimates": [
        {"term": "treatment_effect", "estimate": float(treatment_effect), "se": se_te, "n_obs": int(n)},
        {"term": "reduced_form", "estimate": float(reduced_form), "se": se_rf, "n_obs": int(n)},
        {"term": "first_stage", "estimate": float(first_stage), "se": se_fs, "n_obs": int(n)},
    ],
    "method_metadata": {
        "estimator": "Fuzzy RD, local linear WLS with triangular kernel, bandwidth 1, separate slopes and intercepts per side",
        "vcov": "HC0 sandwich per side, joint delta-method covariance, no degrees-of-freedom correction",
    },
    "diagnostics": {},
}

with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
