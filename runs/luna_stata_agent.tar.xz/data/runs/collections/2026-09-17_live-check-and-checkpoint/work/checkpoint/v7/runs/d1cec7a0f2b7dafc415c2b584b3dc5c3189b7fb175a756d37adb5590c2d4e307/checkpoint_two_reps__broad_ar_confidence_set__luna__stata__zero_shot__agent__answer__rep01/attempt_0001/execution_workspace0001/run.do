clear all
set more off
set linesize 255
import delimited using "./input.csv", clear
count
scalar N = r(N)

* Construct the Anderson-Rubin quadratic in beta by projection matrices.
mata:
    vv = st_data(., 1)
    uu = st_data(., 2)
    xx = st_data(., 3)
    zz = st_data(., (4,5))
    nn = rows(vv)
    C = J(nn,1,1), xx
    X = C, zz
    M0 = I(nn) - C*invsym(C'*C)*C'
    M1 = I(nn) - X*invsym(X'*X)*X'
    A = zz'*M0*zz
    Pz = M0*zz*invsym(A)*zz'*M0
    Fc = invFtail(2, nn-4, .05)
    q0 = (nn-4)*(vv' * Pz * vv) - 2*Fc*(vv' * M1 * vv)
    q1 = -2*(nn-4)*(vv' * Pz * uu) + 4*Fc*(vv' * M1 * uu)
    q2 = (nn-4)*(uu' * Pz * uu) - 2*Fc*(uu' * M1 * uu)
    disc = sqrt(q1^2-4*q2*q0)
    br1 = (-q1 - disc)/(2*q2)
    br2 = (-q1 + disc)/(2*q2)
    b0 = min((br1, br2))
    b1 = max((br1, br2))
    printf("CHECK q0=%18.12f q1=%18.12f q2=%18.12f roots=%18.12f %18.12f\\n", q0, q1, q2, br1, br2)
    st_numscalar("boundary_low", b0)
    st_numscalar("boundary_high", b1)
    st_numscalar("accepts_zero", q0 <= 0)
    st_numscalar("unbounded", q2 <= 0)
end

* Direct conventional homoskedastic joint F statistic at beta=1.
generate double ar_y = y - endog
quietly regress ar_y x z1 z2
quietly test z1 z2
scalar arf1 = r(F)

display "ANSWER: boundary_low estimate=" %21.12f boundary_low " se=. n_obs=" %12.0f N
display "ANSWER: boundary_high estimate=" %21.12f boundary_high " se=. n_obs=" %12.0f N
display "ANSWER: accepts_zero estimate=" %21.12f accepts_zero " se=. n_obs=" %12.0f N
display "ANSWER: unbounded estimate=" %21.12f unbounded " se=. n_obs=" %12.0f N
display "ANSWER: ar_f_at_one estimate=" %21.12f arf1 " se=. n_obs=" %12.0f N
exit, clear
