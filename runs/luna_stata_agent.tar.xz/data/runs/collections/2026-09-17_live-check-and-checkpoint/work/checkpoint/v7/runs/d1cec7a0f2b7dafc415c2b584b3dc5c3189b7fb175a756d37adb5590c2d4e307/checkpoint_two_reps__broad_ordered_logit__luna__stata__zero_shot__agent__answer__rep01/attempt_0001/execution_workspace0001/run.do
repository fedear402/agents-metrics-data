version 18.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear
count
local n_obs = r(N)

ologit y x z, vce(oim)

scalar estimate_x = _b[x]
scalar se_x = _se[x]
scalar estimate_z = _b[z]
scalar se_z = _se[z]

* For category 3, P(y=3|x,z) = 1 - Phi(cut2 - xb).
scalar xb_high = _b[x]*1 + _b[z]*0
scalar prob_high = 1 - normal(_b[/cut2] - xb_high)

display "ANSWER: x estimate=" %21.12f estimate_x " se=" %21.12f se_x " n_obs=" %12.0f `n_obs'
display "ANSWER: z estimate=" %21.12f estimate_z " se=" %21.12f se_z " n_obs=" %12.0f `n_obs'
display "ANSWER: prob_high estimate=" %21.12f prob_high " se=. n_obs=" %12.0f `n_obs'

* Independent numerical check using the equivalent normal-CDF identity.
scalar prob_high_alt = normal(xb_high - _b[/cut2])
display "CHECK: probability_identity_difference=" %21.12e (prob_high-prob_high_alt)
