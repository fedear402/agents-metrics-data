clear all
set more off
set linesize 255
set type double

import delimited using "./input.csv", clear

count
local n_obs = r(N)
assert `n_obs' == 2000
assert year >= 0 & year <= 9
assert inlist(cohort, -1, 4, 6, 8)

scalar total = 0
scalar n_cells = 0
foreach g of numlist 4 6 8 {
    quietly summarize y_did if cohort == `g' & year == `=`g'-1', meanonly
    assert r(N) > 0
    local base_g = r(mean)

    quietly summarize y_did if cohort == -1 & year == `=`g'-1', meanonly
    assert r(N) > 0
    local base_c = r(mean)

    forvalues t = `g'/9 {
        quietly summarize y_did if cohort == `g' & year == `t', meanonly
        assert r(N) > 0
        local post_g = r(mean)

        quietly summarize y_did if cohort == -1 & year == `t', meanonly
        assert r(N) > 0
        local post_c = r(mean)

        scalar cell = (`post_g' - `base_g') - (`post_c' - `base_c')
        scalar total = total + cell
        scalar n_cells = n_cells + 1
    }
}

display "DEBUG cells=" n_cells
assert n_cells == 12
scalar att = total / n_cells
display "ANSWER: att estimate=" %21.12f att " se=. n_obs=" %12.0f `n_obs'
