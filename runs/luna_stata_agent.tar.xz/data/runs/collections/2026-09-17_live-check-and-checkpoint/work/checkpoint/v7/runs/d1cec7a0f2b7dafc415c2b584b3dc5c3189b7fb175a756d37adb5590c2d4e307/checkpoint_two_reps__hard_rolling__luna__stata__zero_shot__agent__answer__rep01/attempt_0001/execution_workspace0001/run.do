clear all
set more off
set linesize 255

import delimited using "./input.csv", clear asdouble
sort time
isid time
count
assert r(N) == 250
assert time[1] == 1
assert time[_N] == 250

tempfile forecasts
postfile results int f double actual forecast using `forecasts', replace

forvalues f = 101/250 {
    quietly summarize y if time == `f', meanonly
    scalar actual_f = r(mean)
    quietly summarize y if time == `=`f'-1', meanonly
    scalar lag_f = r(mean)

    preserve
        keep if inrange(time, `=`f'-100', `=`f'-1')
        sort time
        gen double ylag = y[_n-1]
        quietly regress y ylag in 2/100
        scalar forecast_f = _b[_cons] + _b[ylag] * lag_f
    restore
    post results (`f') (actual_f) (forecast_f)
}
postclose results

use `forecasts', clear
gen double sqerr = (actual - forecast)^2
quietly summarize sqerr, meanonly
scalar rmse = sqrt(r(sum) / 150)

quietly summarize forecast if f == 101, meanonly
scalar forecast_101 = r(mean)
quietly summarize forecast if f == 150, meanonly
scalar forecast_150 = r(mean)
quietly summarize forecast if f == 200, meanonly
scalar forecast_200 = r(mean)
quietly summarize forecast if f == 250, meanonly
scalar forecast_250 = r(mean)
scalar se_missing = .

display "ANSWER: rmse estimate=" %21.12f rmse " se=" %21.12f se_missing " n_obs=" %12.0f 150
display "ANSWER: forecast_101 estimate=" %21.12f forecast_101 " se=" %21.12f se_missing " n_obs=" %12.0f 99
display "ANSWER: forecast_150 estimate=" %21.12f forecast_150 " se=" %21.12f se_missing " n_obs=" %12.0f 99
display "ANSWER: forecast_200 estimate=" %21.12f forecast_200 " se=" %21.12f se_missing " n_obs=" %12.0f 99
display "ANSWER: forecast_250 estimate=" %21.12f forecast_250 " se=" %21.12f se_missing " n_obs=" %12.0f 99
