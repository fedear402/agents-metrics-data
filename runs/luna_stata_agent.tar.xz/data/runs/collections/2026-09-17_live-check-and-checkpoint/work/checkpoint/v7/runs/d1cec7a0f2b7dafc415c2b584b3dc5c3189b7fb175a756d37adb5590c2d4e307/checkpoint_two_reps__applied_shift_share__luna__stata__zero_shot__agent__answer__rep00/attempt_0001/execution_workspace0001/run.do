clear all
set more off
set linesize 255
import delimited using "./input.csv", clear

* Construct the regional instrument.
sort region_id industry_id
by region_id: egen z = total(share*shock)
by region_id: gen byte region_tag = (_n==1)
quietly summarize region_weight if region_tag, meanonly
scalar W = r(sum)
gen double e = region_weight/W if region_tag
by region_id: replace e = e[1]

* Regional weighted means and residuals.
quietly summarize y [aw=e] if region_tag, meanonly
scalar my = r(mean)
quietly summarize x [aw=e] if region_tag, meanonly
scalar mx = r(mean)
quietly summarize z [aw=e] if region_tag, meanonly
scalar mz = r(mean)
gen double y0 = y-my
gen double x0 = x-mx
gen double z0 = z-mz

* Shock-level exposure aggregates.
preserve
gen double eshare = e*share
gen double yn = eshare*y0
gen double xn = eshare*x0
gen double zn = eshare*z0
collapse (sum) s=eshare yn xn zn, by(industry_id shock)
drop if s<=0
gen double ybar = yn/s
gen double xbar = xn/s
gen double zbar = zn/s
count
scalar N = r(N)

* Main shock-level IV regression and first-stage equivalent.
ivregress 2sls ybar (xbar=shock) [aw=s], vce(robust)
scalar b_effect = _b[xbar]
scalar se_effect = _se[xbar]
ivregress 2sls xbar (zbar=shock) [aw=s], vce(robust)
scalar b_first = _b[zbar]
scalar se_first = _se[zbar]
gen double s2 = s^2
quietly summarize s2, meanonly
scalar eff = 1/r(sum)
display "ANSWER: effect estimate=" %21.12f b_effect " se=" %21.12f se_effect " n_obs=" %12.0f N
display "ANSWER: first_stage estimate=" %21.12f b_first " se=" %21.12f se_first " n_obs=" %12.0f N
display "ANSWER: effective_shocks estimate=" %21.12f eff " se=. n_obs=" %12.0f N
restore
