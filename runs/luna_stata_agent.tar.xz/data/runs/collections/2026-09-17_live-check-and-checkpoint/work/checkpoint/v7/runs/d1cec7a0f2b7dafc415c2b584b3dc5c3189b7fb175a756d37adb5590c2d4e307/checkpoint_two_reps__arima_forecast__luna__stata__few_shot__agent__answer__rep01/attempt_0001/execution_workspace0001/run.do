clear all
set more off
set linesize 255
import delimited using "./input.csv", clear
sort t
tsset t
set obs 251
replace t = 251 in 251
sort t

arima y, arima(1,1,1) noconstant

predict double yhat, y dynamic(250)
predict double ymse, mse dynamic(250)
quietly summarize yhat if t == 251
scalar fcast = r(mean)
quietly summarize ymse if t == 251
scalar fse = sqrt(r(mean))
scalar lo = fcast - invnormal(.975)*fse
scalar hi = fcast + invnormal(.975)*fse
local n = e(N)

display "ANSWER: forecast estimate=" %21.12f fcast " se=. n_obs=" %12.0f `n'
display "ANSWER: lower_95 estimate=" %21.12f lo " se=. n_obs=" %12.0f `n'
display "ANSWER: upper_95 estimate=" %21.12f hi " se=. n_obs=" %12.0f `n'
