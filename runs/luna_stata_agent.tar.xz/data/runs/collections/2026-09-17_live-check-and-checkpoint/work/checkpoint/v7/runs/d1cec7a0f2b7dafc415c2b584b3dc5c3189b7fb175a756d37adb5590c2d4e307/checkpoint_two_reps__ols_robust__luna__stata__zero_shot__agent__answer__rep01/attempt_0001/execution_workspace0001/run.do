clear all
set more off
set linesize 255

import delimited using "input.csv", clear
regress y_lin x1 x2, vce(robust)

scalar n_obs = e(N)
display "ANSWER: const estimate=" %21.12f _b[_cons] " se=" %21.12f _se[_cons] " n_obs=" %12.0f n_obs
display "ANSWER: x1 estimate=" %21.12f _b[x1] " se=" %21.12f _se[x1] " n_obs=" %12.0f n_obs
display "ANSWER: x2 estimate=" %21.12f _b[x2] " se=" %21.12f _se[x2] " n_obs=" %12.0f n_obs
