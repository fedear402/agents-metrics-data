version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear
recast double share shock region_weight x y
gen double z_component = share*shock

preserve
    keep region_id region_weight x y
    bysort region_id: keep if _n==1
    quietly summarize region_weight, meanonly
    scalar total_weight = r(sum)
    gen double e = region_weight/total_weight
    tempfile regions
    save `regions'
restore

merge m:1 region_id using `regions', nogen keepusing(e)
gen double z = z_component
preserve
    collapse (sum) z (firstnm) e x y, by(region_id)
    quietly summarize e, meanonly
    scalar e_total = r(sum)
    quietly summarize y [aw=e]
    scalar ymean = r(mean)
    quietly summarize x [aw=e]
    scalar xmean = r(mean)
    quietly summarize z [aw=e]
    scalar zmean = r(mean)
    gen double y0 = y-ymean
    gen double x0 = x-xmean
    gen double z0 = z-zmean
    gen double yz = e*y0*z0
    gen double xz = e*x0*z0
    gen double zz = e*z0*z0
    quietly summarize yz, meanonly
    scalar regional_yz = r(sum)
    quietly summarize xz, meanonly
    scalar regional_xz = r(sum)
    quietly summarize zz, meanonly
    scalar regional_zz = r(sum)
    scalar regional_effect = regional_yz/regional_xz
    scalar regional_first = regional_xz/regional_zz
    tempfile regional_values
    save `regional_values'
restore

drop z
merge m:1 region_id using `regional_values', nogen keepusing(z y0 x0 z0)
gen double eshare = e*share
gen double ynum = eshare*y0
gen double xnum = eshare*x0
gen double znum = eshare*z0
collapse (sum) eshare ynum xnum znum (firstnm) shock, by(industry_id)
rename eshare s
gen double ybar = ynum/s
gen double xbar = xnum/s
gen double zbar = znum/s

mata:
    s = st_data(., "s")
    sh = st_data(., "shock")
    y = st_data(., "ybar")
    x = st_data(., "xbar")
    z = st_data(., "zbar")
    N = rows(s)
    one = J(N,1,1)
    // Generic weighted just-identified IV with intercept and HC1 shock variance.
    function ivhc(dependent, endogenous, instrument, weight, N) {
        X = (J(rows(weight),1,1), endogenous)
        Z = (J(rows(weight),1,1), instrument)
        A = Z'*(weight:*X)
        b = luinv(A)*(Z'*(weight:*dependent))
        u = dependent-X*b
        score = Z:*(weight:*u)
        V = N/(N-2)*luinv(A)*(score'*score)*luinv(A)'
        return((b[2], sqrt(V[2,2])))
    }
    a = ivhc(y, x, sh, s, N)
    b = ivhc(x, z, sh, s, N)
    st_numscalar("effect", a[1])
    st_numscalar("effect_se", a[2])
    st_numscalar("first_stage", b[1])
    st_numscalar("first_stage_se", b[2])
    st_numscalar("effective_shocks", 1/sum(s:^2))
    st_numscalar("n_industries", N)
end

display "ANSWER: effect estimate=" %21.12f scalar(effect) " se=" %21.12f scalar(effect_se) " n_obs=" %12.0f scalar(n_industries)
display "ANSWER: first_stage estimate=" %21.12f scalar(first_stage) " se=" %21.12f scalar(first_stage_se) " n_obs=" %12.0f scalar(n_industries)
display "ANSWER: effective_shocks estimate=" %21.12f scalar(effective_shocks) " se=. n_obs=" %12.0f scalar(n_industries)
