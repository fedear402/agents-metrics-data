clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

local h = 0.5
generate double tri_w = 1 - abs(z)/`h' if abs(z) <= `h'

quietly regress y z [aw=tri_w] if z < 0 & abs(z) <= `h'
scalar b_left = _b[_cons]

quietly regress y z [aw=tri_w] if z >= 0 & abs(z) <= `h'
scalar b_right = _b[_cons]

quietly count if abs(z) <= `h'
scalar n_obs = r(N)
scalar late = b_right - b_left

display "ANSWER: late estimate=" %21.12f late " se=" %21.12f . " n_obs=" %12.0f n_obs
