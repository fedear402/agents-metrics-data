version 18.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear
count
local n = r(N)
assert `n' == 400
assert !missing(y, x, z)
assert y >= 0

tobit y x z, ll(0)
ereturn list
matrix list e(b)

scalar b_const = _b[_cons]
scalar se_const = _se[_cons]
scalar b_x = _b[x]
scalar se_x = _se[x]
scalar b_z = _b[z]
scalar se_z = _se[z]
scalar b_sigma = sqrt(_b[/var(e.y)])

display "ANSWER: const estimate=" %21.12f b_const " se=" %21.12f se_const " n_obs=" %12.0f `n'
display "ANSWER: x estimate=" %21.12f b_x " se=" %21.12f se_x " n_obs=" %12.0f `n'
display "ANSWER: z estimate=" %21.12f b_z " se=" %21.12f se_z " n_obs=" %12.0f `n'
display "ANSWER: sigma estimate=" %21.12f b_sigma " se=. n_obs=" %12.0f `n'

* Independent check: evaluate the Tobit log likelihood at the reported estimates.
scalar ll_check = 0
generate double xb_check = b_const + b_x*x + b_z*z
* The density for uncensored observations must be combined with the censoring CDF.
generate double ll_i_check = cond(y==0, ln(normal((0-xb_check)/b_sigma)), ln(normalden(y, xb_check, b_sigma)))
quietly summarize ll_i_check, meanonly
scalar ll_check = r(sum)
count if y==0
local nz = r(N)
display "CHECK: n=" %12.0f `n' " zeros=" %12.0f `nz' " loglik_at_estimates=" %21.12f ll_check
assert abs(ll_check - e(ll)) < 1e-6
