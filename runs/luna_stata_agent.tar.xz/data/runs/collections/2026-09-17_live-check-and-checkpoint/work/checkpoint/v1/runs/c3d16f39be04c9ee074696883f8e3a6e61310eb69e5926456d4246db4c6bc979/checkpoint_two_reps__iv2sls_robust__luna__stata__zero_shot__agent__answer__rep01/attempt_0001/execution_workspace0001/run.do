clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

ivregress 2sls y_iv (x1_iv = z), vce(robust)

matrix b = e(b)
matrix V = e(V)
scalar n_obs = e(N)
scalar const_estimate = _b[_cons]
scalar const_se = _se[_cons]
scalar x1_iv_estimate = _b[x1_iv]
scalar x1_iv_se = _se[x1_iv]

display "ANSWER: const estimate=" %21.12f const_estimate " se=" %21.12f const_se " n_obs=" %12.0f n_obs
display "ANSWER: x1_iv estimate=" %21.12f x1_iv_estimate " se=" %21.12f x1_iv_se " n_obs=" %12.0f n_obs
