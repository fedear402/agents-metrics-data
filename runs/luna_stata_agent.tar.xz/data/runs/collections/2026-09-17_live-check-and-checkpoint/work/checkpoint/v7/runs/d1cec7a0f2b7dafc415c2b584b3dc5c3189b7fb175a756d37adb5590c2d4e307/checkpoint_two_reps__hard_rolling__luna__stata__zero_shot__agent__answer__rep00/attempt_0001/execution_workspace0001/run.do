clear all
set more off
set linesize 255

import delimited using "./input.csv", clear
sort time
tsset time

scalar sse = 0
scalar forecast_101 = .
scalar forecast_150 = .
scalar forecast_200 = .
scalar forecast_250 = .

forvalues f = 101/250 {
    quietly regress y L.y if inrange(time, `f'-99, `f'-1)
    scalar fc = _b[_cons] + _b[L.y]*y[`f'-1]
    scalar err = y[`f'] - fc
    scalar sse = sse + err^2
    if `f' == 101 scalar forecast_101 = fc
    if `f' == 150 scalar forecast_150 = fc
    if `f' == 200 scalar forecast_200 = fc
    if `f' == 250 scalar forecast_250 = fc
}

scalar rmse = sqrt(sse/150)
scalar missing_se = .

display "ANSWER: rmse estimate=" %21.12f rmse " se=" %21.12f missing_se " n_obs=" %12.0f 150
display "ANSWER: forecast_101 estimate=" %21.12f forecast_101 " se=" %21.12f missing_se " n_obs=" %12.0f 99
display "ANSWER: forecast_150 estimate=" %21.12f forecast_150 " se=" %21.12f missing_se " n_obs=" %12.0f 99
display "ANSWER: forecast_200 estimate=" %21.12f forecast_200 " se=" %21.12f missing_se " n_obs=" %12.0f 99
display "ANSWER: forecast_250 estimate=" %21.12f forecast_250 " se=" %21.12f missing_se " n_obs=" %12.0f 99
