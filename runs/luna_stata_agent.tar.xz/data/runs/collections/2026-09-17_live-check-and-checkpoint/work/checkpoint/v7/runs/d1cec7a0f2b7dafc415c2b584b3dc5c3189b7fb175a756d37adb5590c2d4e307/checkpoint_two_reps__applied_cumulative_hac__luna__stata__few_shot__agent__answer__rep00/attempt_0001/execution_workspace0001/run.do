version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear
generate double day = date(date, "YMD")
format day %td
sort day
generate long observation = _n
tsset observation

generate double log_sales = log(sales)
generate double log_vix = log(vix)
generate double vix_change = D.log_vix
generate double lag_1 = L1.vix_change
generate double lag_2 = L2.vix_change
generate double lag_3 = L3.vix_change
generate double lag_4 = L4.vix_change
generate double lag_5 = L5.vix_change
generate double lag_6 = L6.vix_change
generate double lag_7 = L7.vix_change
generate double lag_8 = L8.vix_change
generate double lag_9 = L9.vix_change
generate double lag_10 = L10.vix_change
generate double lag_11 = L11.vix_change
generate double lag_12 = L12.vix_change
generate double lag_13 = L13.vix_change
generate double lag_14 = L14.vix_change
generate double lag_15 = L15.vix_change
keep if !missing(log_sales, lag_1, lag_2, lag_3, lag_4, lag_5, lag_6, lag_7, lag_8, lag_9, lag_10, lag_11, lag_12, lag_13, lag_14, lag_15)

mata:
X = (J(st_nobs(), 1, 1), st_data(., ("lag_1", "lag_2", "lag_3", "lag_4", "lag_5", "lag_6", "lag_7", "lag_8", "lag_9", "lag_10", "lag_11", "lag_12", "lag_13", "lag_14", "lag_15")))
y = st_data(., "log_sales")
b = qrsolve(X, y)
e = y - X*b
N = rows(X)
p = cols(X)
scores = X:*e
meat = scores' * scores
for (j = 1; j <= 15; j++) {
    cross = scores[|j+1,1\N,p|]' * scores[|1,1\N-j,p|]
    meat = meat + (1 - j/16) * (cross + cross')
}
V = (N/(N-16)) * invsym(X'*X) * meat * invsym(X'*X)
contrast = (0\J(15,1,1))
cumulative = contrast' * b
cumulative_se = sqrt(contrast' * V * contrast)
lag1_se = sqrt(V[2,2])
lag15_se = sqrt(V[16,16])

printf("ANSWER: cumulative_response estimate=%21.12f se=%21.12f n_obs=%12.0f\n", cumulative, cumulative_se, N)
printf("ANSWER: lag_1 estimate=%21.12f se=%21.12f n_obs=%12.0f\n", b[2], lag1_se, N)
printf("ANSWER: lag_15 estimate=%21.12f se=%21.12f n_obs=%12.0f\n", b[16], lag15_se, N)
end
