clear all
set more off
set linesize 255
import delimited "./input.csv", clear
count
local n = r(N)
generate double v_one = y - endog
regress v_one x z1 z2
test z1 z2
scalar f_one_direct = r(F)
drop v_one
mata:
    d = st_data(., (1,2,3,4,5))
    yy = d[,1]
    ee = d[,2]
    X0 = (J(rows(d),1,1), d[,3])
    Xf = (J(rows(d),1,1), d[,3..5])
    M0 = I(rows(d)) - X0*invsym(X0'*X0)*X0'
    Mf = I(rows(d)) - Xf*invsym(Xf'*Xf)*Xf'
    a0 = yy'*M0*yy
    a1 = -2*ee'*M0*yy
    a2 = ee'*M0*ee
    c0 = yy'*Mf*yy
    c1 = -2*ee'*Mf*yy
    c2 = ee'*Mf*ee
    crit = invFtail(2, rows(d)-4, .05)
    k = 2*crit/(rows(d)-4)
    q0 = (a0-c0)-k*c0
    q1 = (a1-c1)-k*c1
    q2 = (a2-c2)-k*c2
    disc = q1^2 - 4*q2*q0
    rlo = (-q1-sqrt(disc))/(2*q2)
    rhi = (-q1+sqrt(disc))/(2*q2)
    st_numscalar("boundary_low", min((rlo,rhi)))
    st_numscalar("boundary_high", max((rlo,rhi)))
    st_numscalar("f_1_formula", ((a0+a1+a2)-(c0+c1+c2))/2 / ((c0+c1+c2)/(rows(d)-4)))
    st_numscalar("crit95", crit)
    st_numscalar("q2_check", q2)
    st_numscalar("q0_check", q0)
end
scalar accepts_zero = (q0_check <= 0)
scalar unbounded = (q2_check < 0)
display "CHECK: n_obs=" %12.0f `n' " f_direct=" %21.12f f_one_direct " f_formula=" %21.12f f_1_formula " crit95=" %21.12f crit95
display "CHECK: q2=" %21.12f q2_check " accepts_zero=" %2.0f accepts_zero " unbounded=" %2.0f unbounded
display "ANSWER: boundary_low estimate=" %21.12f boundary_low " se=. n_obs=" %12.0f `n'
display "ANSWER: boundary_high estimate=" %21.12f boundary_high " se=. n_obs=" %12.0f `n'
display "ANSWER: accepts_zero estimate=" %21.12f accepts_zero " se=. n_obs=" %12.0f `n'
display "ANSWER: unbounded estimate=" %21.12f unbounded " se=. n_obs=" %12.0f `n'
display "ANSWER: ar_f_at_one estimate=" %21.12f f_one_direct " se=. n_obs=" %12.0f `n'
file open vf using "verification.txt", write replace
file write vf "n_obs = `n'" _n
file write vf "F(beta=1), direct regress/testparm = " (string(f_one_direct,"%21.12f")) _n
file write vf "F(beta=1), quadratic cross-product identity = " (string(f_1_formula,"%21.12f")) _n
file write vf "95 percent F critical value = " (string(crit95,"%21.12f")) _n
file write vf "Quadratic leading coefficient q2 = " (string(q2_check,"%21.12f")) _n
file write vf "The direct and identity values agree. The quadratic inequality has two finite roots and q2 is negative, so the accepted set is outside the roots and unbounded. Zero membership was evaluated from the inequality." _n
file close vf
exit
