clear all
set more off
set linesize 255
import delimited using "./input.csv", clear
ivregress 2sls y_iv (x1_iv = z), vce(robust)
scalar b_const = _b[_cons]
scalar se_const = _se[_cons]
scalar b_x1_iv = _b[x1_iv]
scalar se_x1_iv = _se[x1_iv]
scalar n_est = e(N)
display "ANSWER: const estimate=" %21.12f b_const " se=" %21.12f se_const " n_obs=" %12.0f n_est
display "ANSWER: x1_iv estimate=" %21.12f b_x1_iv " se=" %21.12f se_x1_iv " n_obs=" %12.0f n_est
