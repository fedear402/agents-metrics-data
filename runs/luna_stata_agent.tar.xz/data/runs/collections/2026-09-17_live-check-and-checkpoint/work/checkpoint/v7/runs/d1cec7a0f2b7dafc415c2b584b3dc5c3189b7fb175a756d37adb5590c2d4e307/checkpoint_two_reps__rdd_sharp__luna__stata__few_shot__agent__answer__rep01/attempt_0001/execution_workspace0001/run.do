clear all
set linesize 255

import delimited using "./input.csv", clear

gen double absz = abs(z)
gen double tw = 1 - absz/0.5
keep if absz < 0.5
drop if tw <= 0

regress y z [aw=tw] if z < 0
scalar b_left = _b[_cons]

regress y z [aw=tw] if z >= 0
scalar b_right = _b[_cons]

scalar late = b_right - b_left
display "ANSWER: late estimate=" %21.12f late " se=. n_obs=" %12.0f _N
