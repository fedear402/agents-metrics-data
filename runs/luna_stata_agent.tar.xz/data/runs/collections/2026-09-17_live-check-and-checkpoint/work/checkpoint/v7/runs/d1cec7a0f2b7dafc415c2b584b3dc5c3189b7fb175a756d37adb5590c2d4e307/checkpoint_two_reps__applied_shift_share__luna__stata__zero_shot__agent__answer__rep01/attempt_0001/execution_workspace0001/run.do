clear all
set more off
set linesize 255

import delimited using "./input.csv", clear
confirm variable region_id
confirm variable industry_id

* Construct the regional shift-share instrument from all region-industry rows.
gen double zterm = share * shock
collapse (sum) z=zterm (firstnm) region_weight x y, by(region_id)
egen double wsum = total(region_weight)
gen double e = region_weight/wsum
egen double ymean = total(e*y)
egen double xmean = total(e*x)
egen double zmean = total(e*z)
gen double y0 = y-ymean
gen double x0 = x-xmean
gen double z0 = z-zmean
tempfile regions
save `regions', replace

* Re-read the row-level data and attach regional residuals and weights.
import delimited using "./input.csv", clear
merge m:1 region_id using `regions', nogen keepusing(e y0 x0 z0)
gen double eshare = e*share
gen double sy = eshare*y0
gen double sx = eshare*x0
gen double sz = eshare*z0
collapse (sum) s=eshare ynum=sy xnum=sx znum=sz, by(industry_id shock)
drop if s<=0
gen double ybar = ynum/s
gen double xbar = xnum/s
gen double zbar = znum/s
count
local N = r(N)

* BHJ shock-level IV regression for the effect.
ivregress 2sls ybar (xbar=shock) [aw=s], vce(robust)
scalar effect = _b[xbar]
scalar effect_se = _se[xbar]

* Equivalent shock-level IV regression for the regional first stage.
ivregress 2sls xbar (zbar=shock) [aw=s], vce(robust)
scalar first_stage = _b[zbar]
scalar first_stage_se = _se[zbar]

gen double s2 = s^2
egen double s2sum = total(s2)
scalar effective_shocks = 1/s2sum

display "ANSWER: effect estimate=" %21.12f effect " se=" %21.12f effect_se " n_obs=" %12.0f `N'
display "ANSWER: first_stage estimate=" %21.12f first_stage " se=" %21.12f first_stage_se " n_obs=" %12.0f `N'
display "ANSWER: effective_shocks estimate=" %21.12f effective_shocks " se=. n_obs=" %12.0f `N'
