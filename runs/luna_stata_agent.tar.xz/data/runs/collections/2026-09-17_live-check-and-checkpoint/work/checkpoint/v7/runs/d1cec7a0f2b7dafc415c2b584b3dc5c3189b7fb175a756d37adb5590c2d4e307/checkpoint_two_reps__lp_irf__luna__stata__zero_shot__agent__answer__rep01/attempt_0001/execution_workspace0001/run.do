clear all
set linesize 255
import delimited "./input.csv", varnames(1) clear
tsset t
gen y_h4 = F4.y
quietly newey y_h4 shock L.y, lag(4)
scalar irf_h4_estimate = _b[shock]
scalar irf_h4_se = _se[shock]
scalar irf_h4_n_obs = e(N)
display "ANSWER: irf_h4 estimate=" %21.12f irf_h4_estimate " se=" %21.12f irf_h4_se " n_obs=" %12.0f irf_h4_n_obs
