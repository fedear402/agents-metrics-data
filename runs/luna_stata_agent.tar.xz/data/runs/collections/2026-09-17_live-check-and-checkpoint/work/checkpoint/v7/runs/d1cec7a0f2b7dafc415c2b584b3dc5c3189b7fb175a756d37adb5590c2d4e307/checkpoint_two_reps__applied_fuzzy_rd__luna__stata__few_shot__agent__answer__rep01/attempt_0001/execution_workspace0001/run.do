version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear
keep if abs(score) < 1
gen double right = score >= 0
gen double triweight = 1 - abs(score)
gen double right_score = right * score
gen double constant = 1

mata:
    X = st_data(., ("constant", "score", "right", "right_score"))
    w = st_data(., "triweight")
    Y = st_data(., ("earnings", "participated"))
    n = rows(X)
    bread = invsym(X' * (w :* X))
    b = bread * X' * (w :* Y)
    e = Y - X*b
    // The right-limit minus left-limit contrast is the coefficient on right.
    c = (0\0\1\0)
    jumps = c' * b
    loading = w :* (X * bread * c)
    influence = loading :* e
    joint = influence' * influence
    g = (1/jumps[1,2]\-jumps[1,1]/jumps[1,2]^2)
    ratio = jumps[1,1] / jumps[1,2]
    ratio_se = sqrt(g' * joint * g)
    earnings_se = sqrt(joint[1,1])
    participation_se = sqrt(joint[2,2])
    st_numscalar("reduced_form", jumps[1,1])
    st_numscalar("reduced_form_se", earnings_se)
    st_numscalar("first_stage", jumps[1,2])
    st_numscalar("first_stage_se", participation_se)
    st_numscalar("treatment_effect", ratio)
    st_numscalar("treatment_effect_se", ratio_se)
    st_numscalar("n_obs", n)
end

display "ANSWER: treatment_effect estimate=" %21.12f scalar(treatment_effect) " se=" %21.12f scalar(treatment_effect_se) " n_obs=" %12.0f scalar(n_obs)
display "ANSWER: reduced_form estimate=" %21.12f scalar(reduced_form) " se=" %21.12f scalar(reduced_form_se) " n_obs=" %12.0f scalar(n_obs)
display "ANSWER: first_stage estimate=" %21.12f scalar(first_stage) " se=" %21.12f scalar(first_stage_se) " n_obs=" %12.0f scalar(n_obs)
