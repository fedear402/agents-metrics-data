clear all
set more off
set linesize 255

import delimited using "./input.csv", clear
keep if abs(score) < 1
gen byte right = (score >= 0)
gen double tri_w = 1 - abs(score)
gen double score_right = score * right
count
scalar n_obs = r(N)

mata:
    X = (J(st_nobs(),1,1), st_data(.,"right"), st_data(.,"score"), st_data(.,"score_right"))
    y = st_data(.,"earnings")
    p = st_data(.,"participated")
    w = st_data(.,"tri_w")
    A = invsym(X' * diag(w) * X)
    by = A * X' * (w :* y)
    bp = A * X' * (w :* p)
    ey = y - X*by
    ep = p - X*bp
    meat_y = J(4,4,0)
    meat_p = J(4,4,0)
    meat_yp = J(4,4,0)
    for (i=1; i<=rows(X); i++) {
        d = X[i,.]'
        meat_y = meat_y + (w[i]^2 * ey[i]^2) * (d*d')
        meat_p = meat_p + (w[i]^2 * ep[i]^2) * (d*d')
        meat_yp = meat_yp + (w[i]^2 * ey[i]*ep[i]) * (d*d')
    }
    V_y = A * meat_y * A
    V_p = A * meat_p * A
    C_yp = A * meat_yp * A
    st_numscalar("rf", by[2])
    st_numscalar("fs", bp[2])
    st_numscalar("se_rf", sqrt(V_y[2,2]))
    st_numscalar("se_fs", sqrt(V_p[2,2]))
    st_numscalar("cov_rf_fs", C_yp[2,2])
    st_numscalar("te", by[2]/bp[2])
    var_te = V_y[2,2]/bp[2]^2 + by[2]^2*V_p[2,2]/bp[2]^4 - 2*by[2]*C_yp[2,2]/bp[2]^3
    st_numscalar("var_te", var_te)
    st_numscalar("se_te", sqrt(var_te))
end

display "ANSWER: treatment_effect estimate=" %21.12f (te) " se=" %21.12f (se_te) " n_obs=" %12.0f (n_obs)
display "ANSWER: reduced_form estimate=" %21.12f (rf) " se=" %21.12f (se_rf) " n_obs=" %12.0f (n_obs)
display "ANSWER: first_stage estimate=" %21.12f (fs) " se=" %21.12f (se_fs) " n_obs=" %12.0f (n_obs)
