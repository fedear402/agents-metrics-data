clear all
set more off
set linesize 255

import delimited using "input.csv", varnames(1) clear
sort t
tsset t

arima y, arima(1,1,1) noconstant

local n_obs = e(N)
local last = _N
set obs `=`last'+1'
replace t = `=`last'+1' in `=`last'+1'
predict double yhat, y dynamic(`=`last'+1')
predict double ymse, mse dynamic(`=`last'+1')

scalar forecast_value = yhat[`=`last'+1']
scalar forecast_se = sqrt(ymse[`=`last'+1'])
scalar lower_value = forecast_value - invnormal(.975)*forecast_se
scalar upper_value = forecast_value + invnormal(.975)*forecast_se

display "ANSWER: forecast estimate=" %21.12f forecast_value " se=. n_obs=" %12.0f `n_obs'
display "ANSWER: lower_95 estimate=" %21.12f lower_value " se=. n_obs=" %12.0f `n_obs'
display "ANSWER: upper_95 estimate=" %21.12f upper_value " se=. n_obs=" %12.0f `n_obs'
