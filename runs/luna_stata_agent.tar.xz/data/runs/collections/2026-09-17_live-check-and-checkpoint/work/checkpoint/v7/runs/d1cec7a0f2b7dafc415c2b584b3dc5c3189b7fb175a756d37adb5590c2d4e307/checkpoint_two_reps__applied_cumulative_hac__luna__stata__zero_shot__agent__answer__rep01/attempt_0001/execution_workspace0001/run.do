clear all
set more off
set linesize 255

import delimited using "./input.csv", clear
sort date
gen double lnvix = ln(vix)
gen double dlnvix = lnvix - lnvix[_n-1]
forvalues j = 1/15 {
    gen double lag_`j' = dlnvix[_n-`j']
}
gen double lnsales = ln(sales)
drop if missing(lnsales, lag_1, lag_2, lag_3, lag_4, lag_5, lag_6, lag_7, lag_8, lag_9, lag_10, lag_11, lag_12, lag_13, lag_14, lag_15)

local N = _N
regress lnsales lag_1-lag_15
matrix b = e(b)'
predict double resid, residuals

mata:
    X = (J(st_nobs(),1,1), st_data(., "lag_1 lag_2 lag_3 lag_4 lag_5 lag_6 lag_7 lag_8 lag_9 lag_10 lag_11 lag_12 lag_13 lag_14 lag_15"))
    u = st_data(., "resid")
    n = rows(X)
    k = cols(X)
    XXi = invsym(cross(X,X))
    S = J(k,k,0)
    for (j=0; j<=15; j++) {
        w = 1 - j/16
        if (j==0) {
            z = X :* u
            S = S + cross(z,z)
        }
        else {
            S = S + w * (cross(X[(j+1)..n,.] :* u[(j+1)..n], X[1..(n-j),.] :* u[1..(n-j)]) + cross(X[1..(n-j),.] :* u[1..(n-j)], X[(j+1)..n,.] :* u[(j+1)..n]))
        }
    }
    V = XXi * S * XXi * n/(n-16)
    st_matrix("Vnw", V)
    st_numscalar("cum_b", sum(st_matrix("b")[1..15,1]))
    st_numscalar("cum_se", sqrt(sum(V[2..16,2..16])))
    st_numscalar("lag1_b", st_matrix("b")[1,1])
    st_numscalar("lag1_se", sqrt(V[2,2]))
    st_numscalar("lag15_b", st_matrix("b")[15,1])
    st_numscalar("lag15_se", sqrt(V[16,16]))
end

display "ANSWER: cumulative_response estimate=" %21.12f scalar(cum_b) " se=" %21.12f scalar(cum_se) " n_obs=" %12.0f `N'
display "ANSWER: lag_1 estimate=" %21.12f scalar(lag1_b) " se=" %21.12f scalar(lag1_se) " n_obs=" %12.0f `N'
display "ANSWER: lag_15 estimate=" %21.12f scalar(lag15_b) " se=" %21.12f scalar(lag15_se) " n_obs=" %12.0f `N'
