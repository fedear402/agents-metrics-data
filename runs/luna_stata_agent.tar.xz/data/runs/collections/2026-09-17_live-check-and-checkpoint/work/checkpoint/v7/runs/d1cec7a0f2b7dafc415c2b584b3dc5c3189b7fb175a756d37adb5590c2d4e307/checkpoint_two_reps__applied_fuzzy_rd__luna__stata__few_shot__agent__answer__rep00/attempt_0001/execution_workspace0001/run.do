version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear asdouble
keep if abs(score) < 1
generate double triweight = 1 - abs(score)
generate double left = score < 0
generate double right = score >= 0
count
local n_obs = r(N)

mata:
S = st_data(., "score")
W = st_data(., "triweight")
Y = st_data(., ("earnings", "participated"))
n = rows(S)
X = (S:<0, (S:<0):*S, S:>=0, (S:>=0):*S)
bread = invsym(X' * (W:*X))
B = bread * X' * (W:*Y)
E = Y - X*B
// Contrast is the right-limit intercept minus the left-limit intercept.
c = (-1\0\1\0)
d = c' * B
// Joint HC0 covariance of both discontinuities.
L = W :* (X * bread * c)
V = (L:*E)' * (L:*E)
g = (-d[2]/d[1]^2\1/d[1])
ratio = d[1]/d[2]
ratio_se = sqrt(g' * V * g)
printf("ANSWER: treatment_effect estimate=%21.12f se=%21.12f n_obs=%12.0f\n", ratio, ratio_se, n)
printf("ANSWER: reduced_form estimate=%21.12f se=%21.12f n_obs=%12.0f\n", d[1], sqrt(V[1,1]), n)
printf("ANSWER: first_stage estimate=%21.12f se=%21.12f n_obs=%12.0f\n", d[2], sqrt(V[2,2]), n)
end
