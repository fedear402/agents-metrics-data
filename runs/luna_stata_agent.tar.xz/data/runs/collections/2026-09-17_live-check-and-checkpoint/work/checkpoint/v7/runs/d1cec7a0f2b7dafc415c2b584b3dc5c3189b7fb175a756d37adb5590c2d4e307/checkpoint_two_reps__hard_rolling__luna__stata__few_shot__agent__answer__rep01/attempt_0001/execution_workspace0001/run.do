version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear
sort time
assert _N==250
assert time==_n
tsset time

generate double lag_y=L.y
generate double forecast=.
generate double squared_error=.

forvalues f=101/250 {
    quietly regress y lag_y if inrange(time,`f'-99,`f'-1)
    assert e(N)==99
    quietly replace forecast=_b[_cons]+_b[lag_y]*lag_y if time==`f'
    quietly replace squared_error=(y-forecast)^2 if time==`f'
}

quietly summarize squared_error if inrange(time,101,250), meanonly
scalar rmse=sqrt(r(sum)/150)
scalar missing_se=.

quietly summarize forecast if time==101, meanonly
scalar forecast_101=r(mean)
quietly summarize forecast if time==150, meanonly
scalar forecast_150=r(mean)
quietly summarize forecast if time==200, meanonly
scalar forecast_200=r(mean)
quietly summarize forecast if time==250, meanonly
scalar forecast_250=r(mean)

display "ANSWER: rmse estimate=" %21.12f rmse " se=" %21.12f missing_se " n_obs=" %12.0f 150
display "ANSWER: forecast_101 estimate=" %21.12f forecast_101 " se=" %21.12f missing_se " n_obs=" %12.0f 99
display "ANSWER: forecast_150 estimate=" %21.12f forecast_150 " se=" %21.12f missing_se " n_obs=" %12.0f 99
display "ANSWER: forecast_200 estimate=" %21.12f forecast_200 " se=" %21.12f missing_se " n_obs=" %12.0f 99
display "ANSWER: forecast_250 estimate=" %21.12f forecast_250 " se=" %21.12f missing_se " n_obs=" %12.0f 99
