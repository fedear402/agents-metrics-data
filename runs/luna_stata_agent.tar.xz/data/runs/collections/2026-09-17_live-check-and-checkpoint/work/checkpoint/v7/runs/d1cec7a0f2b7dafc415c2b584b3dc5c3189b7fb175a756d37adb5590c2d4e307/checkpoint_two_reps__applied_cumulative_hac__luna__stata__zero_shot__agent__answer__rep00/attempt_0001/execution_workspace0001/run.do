clear all
set more off
set linesize 255

import delimited using "./input.csv", clear
sort date
gen double l_vix = ln(vix)
gen double d_l_vix = l_vix - l_vix[_n-1]
forvalues j = 1/15 {
    gen double lag_`j' = d_l_vix[_n-`j']
}
gen double l_sales = ln(sales)
gen double cons = 1

regress l_sales lag_1-lag_15
scalar N = e(N)
gen byte sample = e(sample)

mata:
    X = st_data(., "lag_1 lag_2 lag_3 lag_4 lag_5 lag_6 lag_7 lag_8 lag_9 lag_10 lag_11 lag_12 lag_13 lag_14 lag_15 cons", "sample")
    y = st_data(., "l_sales", "sample")
    b = st_matrix("e(b)")'
    u = y - X*b
    n = rows(X)
    k = cols(X)
    XXi = invsym(X'X)
    S = J(k,k,0)
    for (j=0; j<=15; j++) {
        w = 1 - j/16
        for (t=j+1; t<=n; t++) {
            S = S + w * u[t] * u[t-j] * (X[t,.]'*X[t-j,.] + (j>0 ? X[t-j,.]'*X[t,.] : J(k,k,0)))
        }
    }
    V = (n/(n-16))*XXi*S*XXi
    st_matrix("Vnw", V)
    q = J(k,1,0)
    for (j=1; j<=15; j++) q[j] = 1
    st_numscalar("cum", (q'b)[1])
    st_numscalar("secum", sqrt((q'V*q)[1]))
    st_numscalar("se1", sqrt(V[1,1]))
    st_numscalar("se15", sqrt(V[15,15]))
end

display "ANSWER: cumulative_response estimate=" %21.12f scalar(cum) " se=" %21.12f scalar(secum) " n_obs=" %12.0f scalar(N)
display "ANSWER: lag_1 estimate=" %21.12f _b[lag_1] " se=" %21.12f scalar(se1) " n_obs=" %12.0f scalar(N)
display "ANSWER: lag_15 estimate=" %21.12f _b[lag_15] " se=" %21.12f scalar(se15) " n_obs=" %12.0f scalar(N)
