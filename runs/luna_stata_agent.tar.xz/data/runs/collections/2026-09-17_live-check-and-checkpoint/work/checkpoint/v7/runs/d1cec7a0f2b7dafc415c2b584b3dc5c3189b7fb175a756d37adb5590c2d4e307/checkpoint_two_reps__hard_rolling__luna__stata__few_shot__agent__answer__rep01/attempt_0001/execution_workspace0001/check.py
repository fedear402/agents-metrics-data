import csv, math

with open('input.csv', newline='') as file:
    rows = sorted((int(r['time']), float(r['y'])) for r in csv.DictReader(file))
y = [value for _, value in rows]

forecasts = {}
errors = []
for f in range(101, 251):
    response = y[f-100:f-1]
    predictor = y[f-101:f-2]
    n = len(predictor)
    xbar = sum(predictor) / n
    ybar = sum(response) / n
    slope = sum((x-xbar)*(v-ybar) for x, v in zip(predictor, response)) / sum((x-xbar)**2 for x in predictor)
    intercept = ybar - slope*xbar
    forecast = intercept + slope*y[f-2]
    forecasts[f] = forecast
    errors.append((y[f-1]-forecast)**2)

rmse = math.sqrt(sum(errors) / len(errors))
print(f'Independent direct OLS calculation: rmse={rmse:.12f}')
for f in (101, 150, 200, 250):
    print(f'forecast_{f}={forecasts[f]:.12f}, pairs=99')
print(f'scored_dates={len(errors)}, first_window_levels=100, first_pairs=99')
