clear all
set more off
set linesize 255
set type double

import delimited using "./input.csv", clear
count
local n = r(N)

* Residualize y and endog on the included regressors.
local df = `n' - 4
scalar df = `df'
scalar q = 2
scalar critical = invFtail(q, `df', .05)
scalar k = q*critical/`df'

quietly regress y x
predict double ry, residuals
quietly regress endog x
predict double re, residuals
quietly regress y x z1 z2
predict double uy, residuals
quietly regress endog x z1 z2
predict double ue, residuals

mata:
ry = st_data(., "ry"); re = st_data(., "re")
uy = st_data(., "uy"); ue = st_data(., "ue")
k = st_numscalar("k")
A = quadcross(re,re) - (1+k)*quadcross(ue,ue)
B = -2*(quadcross(ry,re) - (1+k)*quadcross(uy,ue))
C = quadcross(ry,ry) - (1+k)*quadcross(uy,uy)
D = B^2 - 4*A*C
assert(D > 0)
r1 = (-B-sqrt(D))/(2*A)
r2 = (-B+sqrt(D))/(2*A)
st_numscalar("boundary_low", min((r1,r2)))
st_numscalar("boundary_high", max((r1,r2)))
st_numscalar("accepts_zero", C <= 0)
st_numscalar("unbounded", A < 0)
end

display "CHECK: df=" %12.0f df " critical=" %21.12f critical " k=" %21.12f k
mata:
ssrr1 = quadcross(ry-re, ry-re)
ssru1 = quadcross(uy-ue, uy-ue)
st_numscalar("ar_f_at_one", ((ssrr1-ssru1)/st_numscalar("q"))/(ssru1/st_numscalar("df")))
end
scalar missing_se = .

display "ANSWER: boundary_low estimate=" %21.12f boundary_low " se=" %21.12f missing_se " n_obs=" %12.0f `n'
display "ANSWER: boundary_high estimate=" %21.12f boundary_high " se=" %21.12f missing_se " n_obs=" %12.0f `n'
display "ANSWER: accepts_zero estimate=" %21.12f accepts_zero " se=" %21.12f missing_se " n_obs=" %12.0f `n'
display "ANSWER: unbounded estimate=" %21.12f unbounded " se=" %21.12f missing_se " n_obs=" %12.0f `n'
display "ANSWER: ar_f_at_one estimate=" %21.12f ar_f_at_one " se=" %21.12f missing_se " n_obs=" %12.0f `n'
