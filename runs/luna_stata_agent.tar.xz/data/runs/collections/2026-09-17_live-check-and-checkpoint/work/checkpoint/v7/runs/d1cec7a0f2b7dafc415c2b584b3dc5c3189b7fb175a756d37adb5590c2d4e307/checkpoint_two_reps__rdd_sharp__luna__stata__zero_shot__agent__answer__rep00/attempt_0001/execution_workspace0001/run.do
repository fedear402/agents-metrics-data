clear all
set more off
set linesize 255

import delimited using "input.csv", clear

local h = 0.5
generate double tri_w = 1 - abs(z)/`h' if abs(z) <= `h'
generate byte left_sample = z < 0 & abs(z) <= `h'
generate byte right_sample = z >= 0 & abs(z) <= `h'

quietly regress y z [aw=tri_w] if left_sample
scalar left_intercept = _b[_cons]

quietly regress y z [aw=tri_w] if right_sample
scalar right_intercept = _b[_cons]

scalar late_estimate = right_intercept - left_intercept
count if left_sample | right_sample
scalar n_obs = r(N)

display "ANSWER: late estimate=" %21.12f late_estimate " se=" %21.12f . " n_obs=" %12.0f n_obs
