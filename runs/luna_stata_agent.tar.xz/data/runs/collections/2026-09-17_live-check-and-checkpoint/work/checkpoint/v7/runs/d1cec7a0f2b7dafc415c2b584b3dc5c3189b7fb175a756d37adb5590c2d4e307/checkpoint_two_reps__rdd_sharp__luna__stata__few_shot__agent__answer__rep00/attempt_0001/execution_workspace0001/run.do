clear all
set linesize 255

import delimited using "./input.csv", clear

local h = 0.5
gen byte inbw = abs(z) <= `h' if !missing(z, y)
gen double tw = 1 - abs(z)/`h' if inbw
gen byte left = z < 0 if inbw
gen byte right = z >= 0 if inbw

quietly regress y z [aw=tw] if left == 1
scalar b_left = _b[_cons]

quietly regress y z [aw=tw] if right == 1
scalar b_right = _b[_cons]

scalar late = b_right - b_left
quietly count if inbw == 1
scalar n_obs = r(N)

display "ANSWER: late estimate=" %21.12f late " se=. n_obs=" %12.0f n_obs
