clear all
set more off
set linesize 255

import delimited "./input.csv", clear
count
local n = r(N)

mlogit y x z, baseoutcome(0)

scalar bx1 = _b[1:x]
scalar bz1 = _b[1:z]
scalar bx2 = _b[2:x]
scalar bz2 = _b[2:z]
scalar a1  = _b[1:_cons]
scalar a2  = _b[2:_cons]
scalar p2zero = exp(a2)/(1 + exp(a1) + exp(a2))

display "ANSWER: x_cat1 estimate=" %21.12f bx1 " se=" %21.12f _se[1:x] " n_obs=" %12.0f `n'
display "ANSWER: z_cat1 estimate=" %21.12f bz1 " se=" %21.12f _se[1:z] " n_obs=" %12.0f `n'
display "ANSWER: x_cat2 estimate=" %21.12f bx2 " se=" %21.12f _se[2:x] " n_obs=" %12.0f `n'
display "ANSWER: z_cat2 estimate=" %21.12f bz2 " se=" %21.12f _se[2:z] " n_obs=" %12.0f `n'
display "ANSWER: prob_cat2_zero estimate=" %21.12f p2zero " se=. n_obs=" %12.0f `n'
