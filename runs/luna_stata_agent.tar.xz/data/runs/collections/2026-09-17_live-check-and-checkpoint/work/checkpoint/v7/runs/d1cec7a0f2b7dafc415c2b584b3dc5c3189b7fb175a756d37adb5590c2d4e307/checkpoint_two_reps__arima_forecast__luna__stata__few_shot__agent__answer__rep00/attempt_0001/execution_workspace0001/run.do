clear all
set more off
set linesize 255

import delimited using "./input.csv", clear
sort t
tsset t

arima y, arima(1,1,1) noconstant
local n = e(N)

* Add the forecast date as a missing observation.
set obs `=_N+1'
replace t = 251 in `=_N'
replace y = . in `=_N'
tsset t
predict double yhat, y dynamic(251)
predict double ymse, mse dynamic(251)

scalar fc = yhat[_N]
scalar se = sqrt(ymse[_N])
scalar z = invnormal(.975)
scalar lo = fc - z*se
scalar hi = fc + z*se

display "ANSWER: forecast estimate=" %21.12f fc " se=. n_obs=" %12.0f `n'
display "ANSWER: lower_95 estimate=" %21.12f lo " se=. n_obs=" %12.0f `n'
display "ANSWER: upper_95 estimate=" %21.12f hi " se=. n_obs=" %12.0f `n'
