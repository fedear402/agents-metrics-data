version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear
sort region_id industry_id
egen byte rtag = tag(region_id)
egen double total_rw = total(cond(rtag, region_weight, 0))
gen double e = region_weight/total_rw if rtag
bysort region_id: egen double z = total(share*shock)

preserve
keep if rtag
keep region_id e x y z
quietly summarize y [aw=e]
scalar my = r(mean)
quietly summarize x [aw=e]
scalar mx = r(mean)
quietly summarize z [aw=e]
scalar mz = r(mean)
gen double y0 = y-my
gen double x0 = x-mx
gen double z0 = z-mz
tempfile regional
save `regional'
quietly ivregress 2sls y (x=z) [aw=e]
scalar regional_iv = _b[x]
quietly regress x z [aw=e]
scalar regional_fs = _b[z]
restore

drop e
merge m:1 region_id using `regional', nogen keepusing(e y0 x0 z0)
gen double eshare = e*share
gen double esy = eshare*y0
gen double esx = eshare*x0
gen double esz = eshare*z0
collapse (sum) s=eshare sy=esy sx=esx sz=esz (firstnm) shock, by(industry_id)
gen double ybar = sy/s
gen double xbar = sx/s
gen double zbar = sz/s
drop if missing(s) | missing(shock) | missing(ybar) | missing(xbar) | missing(zbar)

mata:
    real rowvector ivcalc(real colvector dep, real colvector endog, real colvector instr,
                          real colvector wt, real scalar N, real scalar want_se)
    {
        real matrix X, Z, A, V
        real colvector b, resid, score
        X = (J(N,1,1), endog)
        Z = (J(N,1,1), instr)
        A = invsym(Z'*(wt:*X))
        b = A*(Z'*(wt:*dep))
        resid = dep-X*b
        score = instr:*(wt:*resid)
        V = (N/(N-2))*A*(score'*score)*A'
        if (want_se) return((b[2],sqrt(V[2,2])))
        return((b[2],.))
    }
    s = st_data(., "s")
    yb = st_data(., "ybar")
    xb = st_data(., "xbar")
    zb = st_data(., "zbar")
    sh = st_data(., "shock")
    N = rows(s)
    ans1 = ivcalc(yb, xb, sh, s, N, 1)
    ans2 = ivcalc(xb, zb, sh, s, N, 1)
    eff = 1/sum(s:^2)
    st_numscalar("effect_est", ans1[1])
    st_numscalar("effect_se", ans1[2])
    st_numscalar("first_est", ans2[1])
    st_numscalar("first_se", ans2[2])
    st_numscalar("eff_est", eff)
    st_numscalar("n_ind", N)
end

display "ANSWER: effect estimate=" %21.12f scalar(effect_est) " se=" %21.12f scalar(effect_se) " n_obs=" %12.0f scalar(n_ind)
display "ANSWER: first_stage estimate=" %21.12f scalar(first_est) " se=" %21.12f scalar(first_se) " n_obs=" %12.0f scalar(n_ind)
display "ANSWER: effective_shocks estimate=" %21.12f scalar(eff_est) " se=. n_obs=" %12.0f scalar(n_ind)
display "CHECK: regional_iv_difference=" %21.12g scalar(effect_est-regional_iv)
display "CHECK: regional_first_stage_difference=" %21.12g scalar(first_est-regional_fs)
