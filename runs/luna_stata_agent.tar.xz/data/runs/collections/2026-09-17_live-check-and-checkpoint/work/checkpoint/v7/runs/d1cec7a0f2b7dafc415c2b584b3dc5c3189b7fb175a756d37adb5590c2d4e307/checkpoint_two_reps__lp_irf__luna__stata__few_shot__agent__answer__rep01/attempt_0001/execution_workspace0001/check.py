import csv
import numpy as np

with open("input.csv", newline="") as f:
    rows = list(csv.DictReader(f))
y = np.array([float(r["y"]) for r in rows])
shock = np.array([float(r["shock"]) for r in rows])
X = np.column_stack((np.ones(len(y) - 5), shock[1:-4], y[:-5]))
target = y[5:]
beta = np.linalg.solve(X.T @ X, X.T @ target)
resid = target - X @ beta
n, k = X.shape
S = X.T @ X * 0.0
for lag in range(5):
    weight = 1.0 if lag == 0 else 1.0 - lag / 5.0
    if lag == 0:
        S += X.T @ (X * resid[:, None] ** 2)
    else:
        left = X[lag:] * resid[lag:, None]
        right = X[:-lag] * resid[:-lag, None]
        S += weight * (left.T @ right + right.T @ left)
V = np.linalg.inv(X.T @ X) @ S @ np.linalg.inv(X.T @ X)
V *= n / (n - k)
print(f"independent_ols_shock={beta[1]:.12f}")
print(f"independent_nw_se_shock={np.sqrt(V[1,1]):.12f}")
print(f"independent_n={n}")
