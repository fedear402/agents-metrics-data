clear all
set linesize 255

import delimited using "input.csv", clear
sort t
tsset t

gen y_lead4 = F4.y
gen y_lag1 = L1.y

newey y_lead4 shock y_lag1, lag(4)

scalar irf_h4 = _b[shock]
scalar se_h4 = _se[shock]
scalar n_h4 = e(N)

display "ANSWER: irf_h4 estimate=" %21.12f irf_h4 " se=" %21.12f se_h4 " n_obs=" %12.0f n_h4
