clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

ivregress 2sls y_iv (x1_iv = z), vce(robust)

local n_obs = e(N)
local b_const = _b[_cons]
local se_const = _se[_cons]
local b_x1 = _b[x1_iv]
local se_x1 = _se[x1_iv]

display "ANSWER: const estimate=" %21.12f `b_const' " se=" %21.12f `se_const' " n_obs=" %12.0f `n_obs'
display "ANSWER: x1_iv estimate=" %21.12f `b_x1' " se=" %21.12f `se_x1' " n_obs=" %12.0f `n_obs'
