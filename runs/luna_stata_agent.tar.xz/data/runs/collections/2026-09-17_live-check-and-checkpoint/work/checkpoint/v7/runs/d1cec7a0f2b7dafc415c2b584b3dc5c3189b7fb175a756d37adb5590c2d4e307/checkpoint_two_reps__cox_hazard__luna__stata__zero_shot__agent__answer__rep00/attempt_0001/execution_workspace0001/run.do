clear all
set more off
set linesize 255

import delimited using "input.csv", clear
stset t_obs, failure(event == 1)
stcox treat x

scalar b_treat = _b[treat]
scalar se_treat = _se[treat]
scalar b_x = _b[x]
scalar se_x = _se[x]
scalar n_obs = e(N)

display "ANSWER: treat estimate=" %21.12f b_treat " se=" %21.12f se_treat " n_obs=" %12.0f n_obs
display "ANSWER: x estimate=" %21.12f b_x " se=" %21.12f se_x " n_obs=" %12.0f n_obs
