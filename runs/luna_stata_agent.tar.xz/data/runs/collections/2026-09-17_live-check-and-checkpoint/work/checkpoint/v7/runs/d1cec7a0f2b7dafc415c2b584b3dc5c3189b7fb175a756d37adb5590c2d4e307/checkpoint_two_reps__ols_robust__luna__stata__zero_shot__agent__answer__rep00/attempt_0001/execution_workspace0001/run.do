clear all
set more off
set linesize 255

import delimited using "input.csv", clear
regress y_lin x1 x2, vce(robust)

scalar b_const = _b[_cons]
scalar se_const = _se[_cons]
scalar b_x1 = _b[x1]
scalar se_x1 = _se[x1]
scalar b_x2 = _b[x2]
scalar se_x2 = _se[x2]
scalar n_obs = e(N)

display "ANSWER: const estimate=" %21.12f b_const " se=" %21.12f se_const " n_obs=" %12.0f n_obs
display "ANSWER: x1 estimate=" %21.12f b_x1 " se=" %21.12f se_x1 " n_obs=" %12.0f n_obs
display "ANSWER: x2 estimate=" %21.12f b_x2 " se=" %21.12f se_x2 " n_obs=" %12.0f n_obs
