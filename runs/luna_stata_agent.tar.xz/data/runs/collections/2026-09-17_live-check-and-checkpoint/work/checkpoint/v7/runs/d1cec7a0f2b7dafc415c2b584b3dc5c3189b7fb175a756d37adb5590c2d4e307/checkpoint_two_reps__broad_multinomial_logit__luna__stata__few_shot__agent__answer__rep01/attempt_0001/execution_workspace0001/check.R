d <- read.csv("input.csv")
y <- d$y
X <- cbind(1, d$x, d$z)
negll <- function(theta) {
  B <- rbind(c(0, 0, 0), theta[1:3], theta[4:6])
  eta <- X %*% t(B)
  lse <- apply(eta, 1, function(v) log(sum(exp(v - max(v)))) + max(v))
  -sum(eta[cbind(seq_len(nrow(X)), y + 1)] - lse)
}
fit <- optim(rep(0, 6), negll, method="BFGS", hessian=TRUE, control=list(reltol=1e-12, maxit=10000))
theta <- fit$par
eta0 <- c(0, theta[1], theta[4])
p2 <- exp(eta0[3]) / sum(exp(eta0))
cat(sprintf("R optim convergence=%d n=%d\n", fit$convergence, nrow(d)))
cat(sprintf("R coefficients cat1 x,z = %.12f %.12f\n", theta[2], theta[3]))
cat(sprintf("R coefficients cat2 x,z = %.12f %.12f\n", theta[5], theta[6]))
cat(sprintf("R probability cat2 at zero = %.12f\n", p2))
