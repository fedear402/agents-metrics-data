clear all
set more off
set linesize 255
set type double

import delimited using "./input.csv", clear
count
scalar n_obs = r(N)

quietly regress y endog x z1 z2
scalar df = e(df_r)
scalar q = 2
scalar critical = invFtail(q, df, .05)
scalar k = q*critical/df

quietly regress y x
predict double ry0, residuals
quietly regress endog x
predict double re0, residuals
quietly regress y x z1 z2
predict double ryu, residuals
quietly regress endog x z1 z2
predict double reu, residuals

mata:
    y0 = st_data(., "ry0")
    e0 = st_data(., "re0")
    yu = st_data(., "ryu")
    eu = st_data(., "reu")
    k = st_numscalar("k")
    A = quadcross(e0,e0) - (1+k)*quadcross(eu,eu)
    B = -2*(quadcross(y0,e0) - (1+k)*quadcross(yu,eu))
    C = quadcross(y0,y0) - (1+k)*quadcross(yu,yu)
    disc = B^2 - 4*A*C
    roots = sort(((-B-sqrt(disc))/(2*A) \ (-B+sqrt(disc))/(2*A)), 1)
    st_numscalar("boundary_low", roots[1])
    st_numscalar("boundary_high", roots[2])
    st_numscalar("accepts_zero", C <= 0)
    st_numscalar("unbounded", A < 0)
    b = 1
    ssu = quadcross(yu :- b*eu, yu :- b*eu)
    ssr = quadcross(y0 :- b*e0, y0 :- b*e0)
    st_numscalar("ar_f_at_one", ((ssr-ssu)/2)/(ssu/st_numscalar("df")))
end

generate double ar_y_one = y - endog
quietly regress ar_y_one x
scalar ssr_check_r = e(rss)
quietly regress ar_y_one x z1 z2
scalar ssr_check_u = e(rss)
scalar f_check = ((ssr_check_r-ssr_check_u)/2)/(ssr_check_u/e(df_r))
display "CHECK: direct_f=" %21.12f ar_f_at_one " stata_ssr_f=" %21.12f f_check
scalar ar_f_at_one = f_check
assert n_obs == 240
assert e(df_r) == 236
drop ar_y_one

display "ANSWER: boundary_low estimate=" %21.12f boundary_low " se=" %21.12f . " n_obs=" %12.0f n_obs
display "ANSWER: boundary_high estimate=" %21.12f boundary_high " se=" %21.12f . " n_obs=" %12.0f n_obs
display "ANSWER: accepts_zero estimate=" %21.12f accepts_zero " se=" %21.12f . " n_obs=" %12.0f n_obs
display "ANSWER: unbounded estimate=" %21.12f unbounded " se=" %21.12f . " n_obs=" %12.0f n_obs
display "ANSWER: ar_f_at_one estimate=" %21.12f ar_f_at_one " se=" %21.12f . " n_obs=" %12.0f n_obs
