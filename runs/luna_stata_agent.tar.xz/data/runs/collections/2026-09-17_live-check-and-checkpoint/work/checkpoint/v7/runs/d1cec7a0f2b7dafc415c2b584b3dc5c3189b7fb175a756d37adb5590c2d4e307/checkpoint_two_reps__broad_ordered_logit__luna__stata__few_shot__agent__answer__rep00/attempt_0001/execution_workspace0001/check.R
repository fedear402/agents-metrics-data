d <- read.csv("input.csv")
logistic <- function(a) 1 / (1 + exp(-a))
negll <- function(p) {
  b <- p[1:2]
  c1 <- p[3]
  c2 <- c1 + exp(p[4])
  eta <- as.matrix(d[, c("x", "z")]) %*% b
  p1 <- logistic(c1 - eta)
  p2 <- logistic(c2 - eta)
  pr <- ifelse(d$y == 1, p1, ifelse(d$y == 2, p2 - p1, 1 - p2))
  if (any(pr <= 0)) return(1e100)
  -sum(log(pr))
}
fit <- optim(c(0.6, -0.4, -0.7, log(1.36)), negll,
             method = "BFGS", control = list(reltol = 1e-12))
b <- fit$par[1:2]
c1 <- fit$par[3]
c2 <- c1 + exp(fit$par[4])
ph <- 1 - logistic(c2 - b[1])
cat(sprintf("R independent check: N=%d x=%.12f z=%.12f cut2=%.12f prob_high=%.12f convergence=%d\n",
            nrow(d), b[1], b[2], c2, ph, fit$convergence))
