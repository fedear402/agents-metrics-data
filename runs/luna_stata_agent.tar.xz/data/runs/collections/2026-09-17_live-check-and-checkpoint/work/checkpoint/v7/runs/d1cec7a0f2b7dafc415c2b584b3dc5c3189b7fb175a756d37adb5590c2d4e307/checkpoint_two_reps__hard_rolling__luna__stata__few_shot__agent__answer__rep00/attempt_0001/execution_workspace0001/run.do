version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear
sort time
tsset time
generate double lag_y = L.y
generate double forecast = .

forvalues f = 101/250 {
    local first_response = `f' - 99
    local last_response = `f' - 1
    quietly regress y lag_y if inrange(time, `first_response', `last_response')
    assert e(N) == 99
    quietly replace forecast = _b[_cons] + _b[lag_y] * lag_y if time == `f'
}

generate double squared_error = (y - forecast)^2 if inrange(time, 101, 250)
quietly summarize squared_error if inrange(time, 101, 250), meanonly
scalar rmse = sqrt(r(sum) / 150)

quietly summarize forecast if time == 101, meanonly
scalar forecast_101 = r(mean)
quietly summarize forecast if time == 150, meanonly
scalar forecast_150 = r(mean)
quietly summarize forecast if time == 200, meanonly
scalar forecast_200 = r(mean)
quietly summarize forecast if time == 250, meanonly
scalar forecast_250 = r(mean)

display "ANSWER: rmse estimate=" %21.12f rmse " se=. n_obs=" %12.0f 150
display "ANSWER: forecast_101 estimate=" %21.12f forecast_101 " se=. n_obs=" %12.0f 99
display "ANSWER: forecast_150 estimate=" %21.12f forecast_150 " se=. n_obs=" %12.0f 99
display "ANSWER: forecast_200 estimate=" %21.12f forecast_200 " se=. n_obs=" %12.0f 99
display "ANSWER: forecast_250 estimate=" %21.12f forecast_250 " se=. n_obs=" %12.0f 99
