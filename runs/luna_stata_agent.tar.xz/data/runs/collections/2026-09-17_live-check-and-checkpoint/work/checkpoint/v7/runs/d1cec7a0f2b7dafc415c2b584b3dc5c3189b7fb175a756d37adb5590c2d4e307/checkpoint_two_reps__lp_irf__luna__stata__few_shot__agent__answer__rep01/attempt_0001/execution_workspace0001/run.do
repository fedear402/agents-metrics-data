clear all
set more off
set linesize 255

import delimited using "./input.csv", clear
sort t
tsset t
gen y_h4 = y[_n+4]
gen y_l1 = y[_n-1]

newey y_h4 shock y_l1 if !missing(y_h4, shock, y_l1), lag(4)

local b = _b[shock]
local se = _se[shock]
local n = e(N)
display "ANSWER: irf_h4 estimate=" %21.12f `b' " se=" %21.12f `se' " n_obs=" %12.0f `n'
