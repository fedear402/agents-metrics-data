version 18.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", varnames(1) clear
sort t
tsset t
arima y, arima(1,1,1) noconstant
local nobs = e(N)

tsappend, add(1)
predict double forecast, y dynamic(251)
scalar forecast_value = forecast[_N]
scalar forecast_se_value = e(sigma)
scalar lower_value = forecast_value - invnormal(.975)*forecast_se_value
scalar upper_value = forecast_value + invnormal(.975)*forecast_se_value

display "ANSWER: forecast estimate=" %21.12f forecast_value " se=" %21.12f forecast_se_value " n_obs=" %12.0f `nobs'
display "ANSWER: lower_95 estimate=" %21.12f lower_value " se=. n_obs=" %12.0f `nobs'
display "ANSWER: upper_95 estimate=" %21.12f upper_value " se=. n_obs=" %12.0f `nobs'
