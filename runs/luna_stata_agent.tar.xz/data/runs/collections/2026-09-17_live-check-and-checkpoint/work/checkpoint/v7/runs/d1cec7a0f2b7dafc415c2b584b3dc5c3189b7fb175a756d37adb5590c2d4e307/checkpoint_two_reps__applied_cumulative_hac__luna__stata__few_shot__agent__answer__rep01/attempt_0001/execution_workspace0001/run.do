version 19.0
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear
generate double trading_day = date(date, "YMD")
format trading_day %td
sort trading_day
generate long observation = _n
tsset observation

generate double log_vix = log(vix)
generate double vix_change = D.log_vix
generate double log_sales = log(sales)
forvalues j = 1/15 {
    generate double lag_`j' = L`j'.vix_change
}
keep if !missing(log_sales, lag_1, lag_2, lag_3, lag_4, lag_5, lag_6, lag_7, lag_8, lag_9, lag_10, lag_11, lag_12, lag_13, lag_14, lag_15)

mata:
    X = (J(st_nobs(), 1, 1), st_data(., ("lag_1", "lag_2", "lag_3", "lag_4", "lag_5", "lag_6", "lag_7", "lag_8", "lag_9", "lag_10", "lag_11", "lag_12", "lag_13", "lag_14", "lag_15")))
    y = st_data(., "log_sales")
    b = qrsolve(X, y)
    e = y - X*b
    N = rows(X)
    p = cols(X)
    scores = X:*e
    meat = scores'*scores
    for (j = 1; j <= 15; j++) {
        cross = scores[|j+1,1\N,p|]' * scores[|1,1\N-j,p|]
        meat = meat + (1-j/16) * (cross + cross')
    }
    bread = invsym(X'*X)
    V = (N/(N-16)) * bread * meat * bread
    contrast = (0\J(15,1,1))
    cumulative = contrast' * b
    cumulative_se = sqrt(contrast' * V * contrast)
    st_numscalar("cumulative_value", cumulative)
    st_numscalar("cumulative_se_value", cumulative_se)
    st_numscalar("lag1_value", b[2])
    st_numscalar("lag1_se_value", sqrt(V[2,2]))
    st_numscalar("lag15_value", b[16])
    st_numscalar("lag15_se_value", sqrt(V[16,16]))
    st_numscalar("sample_N", N)
end

display "ANSWER: cumulative_response estimate=" %21.12f scalar(cumulative_value) " se=" %21.12f scalar(cumulative_se_value) " n_obs=" %12.0f scalar(sample_N)
display "ANSWER: lag_1 estimate=" %21.12f scalar(lag1_value) " se=" %21.12f scalar(lag1_se_value) " n_obs=" %12.0f scalar(sample_N)
display "ANSWER: lag_15 estimate=" %21.12f scalar(lag15_value) " se=" %21.12f scalar(lag15_se_value) " n_obs=" %12.0f scalar(sample_N)
