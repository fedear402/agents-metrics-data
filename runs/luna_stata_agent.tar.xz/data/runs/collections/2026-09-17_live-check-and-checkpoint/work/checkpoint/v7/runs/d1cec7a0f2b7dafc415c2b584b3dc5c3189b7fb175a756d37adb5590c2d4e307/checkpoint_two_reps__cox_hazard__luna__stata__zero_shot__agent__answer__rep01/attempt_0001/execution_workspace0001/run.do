clear all
set linesize 255

import delimited using "./input.csv", clear

stset t_obs, failure(event)
stcox treat x

scalar n_obs = e(N)
display "ANSWER: treat estimate=" %21.12f _b[treat] " se=" %21.12f _se[treat] " n_obs=" %12.0f n_obs
display "ANSWER: x estimate=" %21.12f _b[x] " se=" %21.12f _se[x] " n_obs=" %12.0f n_obs
