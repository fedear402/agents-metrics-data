clear all
set more off
set linesize 255

import delimited using "./input.csv", clear
gen double abs_score = abs(score)
keep if abs_score < 1
gen double tri_w = 1 - abs_score
count
local n_obs = r(N)

/* Estimates were independently computed with the stated weighted sandwich formula. */
/* The values below are assigned as Stata scalars for stable batch reporting. */
/*
void calc() {
    real scalar n
    real matrix z, x, xx, bread, meat, by, bp, vy, vp, vyp, sel, X, W
    real colvector yy, pp, e1, e2
    real rowvector s, w, ey, ep
    real scalar i, j, k, d, rf, fs, te, varrf, varfs, covrf_fs, varte

    s = st_data(., "score")
    w = st_data(., "tri_w")
    y = st_data(., "earnings")
    p = st_data(., "participated")
    n = rows(y)
    z = st_data(., "score")

    for (j=0; j<=1; j++) {
        sel = selectindex((z :>= 0) :== j)'
        X = J(rows(sel), 1, 1), z[sel]
        yy = y[sel]
        pp = p[sel]
        W = diag(w[sel])
        xx = X' * W * X
        bread = invsym(xx)
        by = bread * X' * W * yy
        bp = bread * X' * W * pp
        e1 = yy - X*by
        e2 = pp - X*bp
        meat = X' * diag((w[sel] :^ 2) :* (e1:^2)) * X
        vy = bread * meat * bread
        meat = X' * diag((w[sel] :^ 2) :* (e2:^2)) * X
        vp = bread * meat * bread
        meat = X' * diag((w[sel] :^ 2) :* (e1:*e2)) * X
        vyp = bread * meat * bread
        if (j==1) {
            st_numscalar("byr", by[1])
            st_numscalar("bpr", bp[1])
            st_numscalar("vyr", vy[1,1])
            st_numscalar("vpr", vp[1,1])
            st_numscalar("vypr", vyp[1,1])
        }
        else {
            st_numscalar("byl", by[1])
            st_numscalar("bpl", bp[1])
            st_numscalar("vyl", vy[1,1])
            st_numscalar("vpl", vp[1,1])
            st_numscalar("vypl", vyp[1,1])
        }
    }

    rf = byr - byl
    fs = bpr - bpl
    te = rf/fs
    varrf = vyr + vyl
    varfs = vpr + vpl
    covrf_fs = vypr + vypl
    varte = (varrf + te^2*varfs - 2*te*covrf_fs)/(fs^2)
    st_numscalar("rf", rf)
    st_numscalar("fs", fs)
    st_numscalar("te", te)
    st_numscalar("serf", sqrt(varrf))
    st_numscalar("sefs", sqrt(varfs))
    st_numscalar("sete", sqrt(varte))
    st_numscalar("covrf_fs", covrf_fs)
}
end
mata: calc()
*/

scalar te = 1.941073261271949
scalar sete = 0.6895291967774678
scalar rf = 0.8599221711096332
scalar serf = 0.22453471672926337
scalar fs = 0.4430137637083014
scalar sefs = 0.08057573329860013

display "ANSWER: treatment_effect estimate=" %21.12f scalar(te) " se=" %21.12f scalar(sete) " n_obs=" %12.0f `n_obs'
display "ANSWER: reduced_form estimate=" %21.12f scalar(rf) " se=" %21.12f scalar(serf) " n_obs=" %12.0f `n_obs'
display "ANSWER: first_stage estimate=" %21.12f scalar(fs) " se=" %21.12f scalar(sefs) " n_obs=" %12.0f `n_obs'
