clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

ologit y x z

scalar b_x = _b[x]
scalar b_z = _b[z]
scalar se_x = _se[x]
scalar se_z = _se[z]
scalar c2 = _b[/cut2]
scalar prob_high = normal(b_x - c2)
scalar n_obs = e(N)

display "ANSWER: x estimate=" %21.12f b_x " se=" %21.12f se_x " n_obs=" %12.0f n_obs
display "ANSWER: z estimate=" %21.12f b_z " se=" %21.12f se_z " n_obs=" %12.0f n_obs
display "ANSWER: prob_high estimate=" %21.12f prob_high " se=. n_obs=" %12.0f n_obs

log close _all
