clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

ivregress 2sls y_iv (x1_iv = z), vce(robust)
count if e(sample)
local n = r(N)

display "ANSWER: const estimate=" %21.12f _b[_cons] " se=" %21.12f _se[_cons] " n_obs=" %12.0f `n'
display "ANSWER: x1_iv estimate=" %21.12f _b[x1_iv] " se=" %21.12f _se[x1_iv] " n_obs=" %12.0f `n'
