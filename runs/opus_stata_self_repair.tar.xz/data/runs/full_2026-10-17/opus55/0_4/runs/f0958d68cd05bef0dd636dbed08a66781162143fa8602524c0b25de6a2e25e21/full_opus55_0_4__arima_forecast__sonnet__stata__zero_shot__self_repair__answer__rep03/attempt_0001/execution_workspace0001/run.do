clear all
set more off
set linesize 255

import delimited using "./input.csv", clear varnames(1)
sort t
tsset t

* ARIMA(1,1,1) on levels, no constant/drift, exact ML
arima y, arima(1,1,1) noconstant
scalar nobs = e(N)

* Extend the time index by one period to forecast t = 251
tsappend, add(1)

* One-step-ahead forecast in levels and its MSE
predict double yhat, y
predict double yvar, mse

quietly summarize t
scalar tlast = r(max)
quietly summarize yhat if t == tlast
scalar fc = r(mean)
quietly summarize yvar if t == tlast
scalar fse = sqrt(r(mean))

scalar z = invnormal(0.975)
scalar lo = fc - z*fse
scalar hi = fc + z*fse

display "Forecast period t = " tlast
display "ANSWER: forecast estimate=" %21.12f fc " se=" %21.12f fse " n_obs=" %12.0f nobs
display "ANSWER: lower_95 estimate=" %21.12f lo " se=." " n_obs=" %12.0f nobs
display "ANSWER: upper_95 estimate=" %21.12f hi " se=." " n_obs=" %12.0f nobs
