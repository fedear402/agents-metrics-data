clear all
set more off
set linesize 255

import delimited using "./input.csv", clear
sort t
tsset t

arima y, arima(1,1,1) noconstant
local nobs = e(N)

tsappend, add(1)
predict double yhat, y
predict double ymse, mse

quietly summarize t
local tmax = r(max)
quietly levelsof t if t == 251, local(has251)
if "`has251'" == "" {
    local target = `tmax'
}
else {
    local target = 251
}

quietly summarize yhat if t == `target'
scalar fc = r(mean)
quietly summarize ymse if t == `target'
scalar fse = sqrt(r(mean))
scalar z = invnormal(0.975)
scalar lo = fc - z*fse
scalar hi = fc + z*fse

display "ANSWER: forecast estimate=" %21.12f fc " se=" %21.12f fse " n_obs=" %12.0f `nobs'
display "ANSWER: lower_95 estimate=" %21.12f lo " se=. n_obs=" %12.0f `nobs'
display "ANSWER: upper_95 estimate=" %21.12f hi " se=. n_obs=" %12.0f `nobs'
