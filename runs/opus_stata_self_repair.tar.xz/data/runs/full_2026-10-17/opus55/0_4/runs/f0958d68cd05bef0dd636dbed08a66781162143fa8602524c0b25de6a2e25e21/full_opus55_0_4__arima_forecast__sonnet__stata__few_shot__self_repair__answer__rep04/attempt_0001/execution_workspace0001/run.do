clear all
set more off
set linesize 255

import delimited using "./input.csv", clear
sort t
tsset t

arima y, arima(1,1,1) noconstant
local nobs = e(N)

tsappend, add(1)

predict double yhat, y
predict double mse_f, mse

summarize t, meanonly
local tmax = r(max)
quietly summarize yhat if t == `tmax'
scalar fc = r(mean)
quietly summarize mse_f if t == `tmax'
scalar sefc = sqrt(r(mean))

scalar z = invnormal(0.975)
scalar lo = fc - z*sefc
scalar hi = fc + z*sefc

display "ANSWER: forecast estimate=" %21.12f fc " se=" %21.12f sefc " n_obs=" %12.0f `nobs'
display "ANSWER: lower_95 estimate=" %21.12f lo " se=. n_obs=" %12.0f `nobs'
display "ANSWER: upper_95 estimate=" %21.12f hi " se=. n_obs=" %12.0f `nobs'
