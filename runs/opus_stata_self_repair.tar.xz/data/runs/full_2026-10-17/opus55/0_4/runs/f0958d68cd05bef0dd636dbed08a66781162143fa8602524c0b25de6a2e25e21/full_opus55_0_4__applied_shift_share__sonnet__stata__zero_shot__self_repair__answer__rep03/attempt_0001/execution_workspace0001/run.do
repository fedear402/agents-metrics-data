version 16
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear varnames(1)

* Regional shift-share instrument
gen double ss = share*shock
bysort region_id: egen double z = total(ss)

* Normalize regional weights once (one observation per region)
egen byte rtag = tag(region_id)
quietly summarize region_weight if rtag
scalar Wsum = r(sum)
gen double e = region_weight/Wsum

* e-weighted regional demeaning
foreach v in y x z {
    quietly summarize `v' [aw=e] if rtag
    gen double `v'0 = `v' - r(mean)
}

* Shock-level aggregation
gen double es  = e*share
gen double esy = es*y0
gen double esx = es*x0
gen double esz = es*z0

collapse (sum) s=es sy=esy sx=esx sz=esz (first) shock, by(industry_id)

gen double ybar = cond(s>0, sy/s, 0)
gen double xbar = cond(s>0, sx/s, 0)
gen double zbar = cond(s>0, sz/s, 0)

quietly count
scalar N = r(N)

gen double s2 = s^2
quietly summarize s2
scalar eff_shocks = 1/r(sum)

mata:
void ivhc1(string scalar yv, string scalar xv, string scalar gv, string scalar wv, string scalar bn, string scalar sn)
{
    real colvector y, x, g, w, u, b
    real matrix X, Z, A, Ai, M, V
    real scalar n
    y = st_data(., yv)
    x = st_data(., xv)
    g = st_data(., gv)
    w = st_data(., wv)
    n = rows(y)
    X = J(n,1,1), x
    Z = J(n,1,1), g
    A = Z' * (w :* X)
    Ai = luinv(A)
    b = Ai * (Z' * (w :* y))
    u = y - X*b
    M = (Z :* (w:*u))' * (Z :* (w:*u))
    V = (n/(n-2)) * Ai * M * Ai'
    st_numscalar(bn, b[2])
    st_numscalar(sn, sqrt(V[2,2]))
}
ivhc1("ybar", "xbar", "shock", "s", "b_eff", "se_eff")
ivhc1("xbar", "zbar", "shock", "s", "b_fs", "se_fs")
end

display "ANSWER: effect estimate=" %21.12f b_eff " se=" %21.12f se_eff " n_obs=" %12.0f N
display "ANSWER: first_stage estimate=" %21.12f b_fs " se=" %21.12f se_fs " n_obs=" %12.0f N
display "ANSWER: effective_shocks estimate=" %21.12f eff_shocks " se=." " n_obs=" %12.0f N
