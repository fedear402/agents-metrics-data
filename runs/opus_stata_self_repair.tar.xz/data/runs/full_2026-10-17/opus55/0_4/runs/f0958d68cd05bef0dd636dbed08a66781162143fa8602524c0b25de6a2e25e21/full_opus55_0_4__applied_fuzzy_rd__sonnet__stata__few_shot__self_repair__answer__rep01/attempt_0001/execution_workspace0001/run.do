version 19.0
clear all
set more off
set linesize 255
import delimited using "./input.csv", clear varnames(1)
keep if abs(score) < 1 & !missing(score, participated, earnings)
gen double above = (score >= 0)
gen double w = 1 - abs(score)
gen double above_score = above*score
mata:
above=st_data(.,"above")
s=st_data(.,"score")
as=st_data(.,"above_score")
w=st_data(.,"w")
Y=st_data(.,("earnings","participated"))
X=(J(rows(Y),1,1),above,s,as)
bread=invsym(X'*(w:*X))
coefficients=bread*X'*(w:*Y)
residuals=Y-X*coefficients
contrast=(0\1\0\0)
jumps=contrast'*coefficients
loading=w:*(X*bread*contrast)
influence=loading:*residuals
joint=influence'*influence
gradient=(1/jumps[2]\-jumps[1]/jumps[2]^2)
st_numscalar("rf",jumps[1])
st_numscalar("fs",jumps[2])
st_numscalar("rf_se",sqrt(joint[1,1]))
st_numscalar("fs_se",sqrt(joint[2,2]))
st_numscalar("te",jumps[1]/jumps[2])
st_numscalar("te_se",sqrt(gradient'*joint*gradient))
st_numscalar("nobs",rows(Y))
end
display "ANSWER: treatment_effect estimate=" %21.12f te " se=" %21.12f te_se " n_obs=" %12.0f nobs
display "ANSWER: reduced_form estimate=" %21.12f rf " se=" %21.12f rf_se " n_obs=" %12.0f nobs
display "ANSWER: first_stage estimate=" %21.12f fs " se=" %21.12f fs_se " n_obs=" %12.0f nobs
