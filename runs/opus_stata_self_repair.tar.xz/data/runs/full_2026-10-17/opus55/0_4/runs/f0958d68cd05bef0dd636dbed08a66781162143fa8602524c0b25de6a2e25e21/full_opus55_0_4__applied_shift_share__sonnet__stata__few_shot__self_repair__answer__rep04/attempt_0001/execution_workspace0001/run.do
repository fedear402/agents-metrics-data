version 19.0
clear all
set more off
set linesize 255
import delimited using "./input.csv", clear varnames(1)
egen long rgrp = group(region_id)
egen long igrp = group(industry_id)
sort rgrp igrp
mata:
D = st_data(., ("rgrp","igrp","share","shock","region_weight","x","y"))
R = max(D[,1])
N = max(D[,2])
S = J(R,N,0)
shock = J(N,1,.)
w = J(R,1,.)
x = J(R,1,.)
y = J(R,1,.)
for (i=1;i<=rows(D);i++) {
    r = D[i,1]
    n = D[i,2]
    S[r,n] = S[r,n] + D[i,3]
    shock[n] = D[i,4]
    w[r] = D[i,5]
    x[r] = D[i,6]
    y[r] = D[i,7]
}
e = w/sum(w)
z = S*shock
V = (y,x,z)
C = V :- e'*V
mass = S'*e
A = (S'*(e:*C)):/mass
est = J(2,2,.)
for (eq=1;eq<=2;eq++) {
    dep = A[,eq]
    endo = A[,eq+1]
    X = (J(N,1,1),endo)
    Z = (J(N,1,1),shock)
    cross = Z'*(mass:*X)
    inv = luinv(cross)
    b = inv*Z'*(mass:*dep)
    u = dep - X*b
    sc = Z:*(mass:*u)
    V2 = N/(N-2)*inv*(sc'*sc)*inv'
    est[eq,] = (b[2], sqrt(V2[2,2]))
}
st_numscalar("b1", est[1,1])
st_numscalar("se1", est[1,2])
st_numscalar("b2", est[2,1])
st_numscalar("se2", est[2,2])
st_numscalar("eff", 1/sum(mass:^2))
st_numscalar("NN", N)
end
display "ANSWER: effect estimate=" %21.12f b1 " se=" %21.12f se1 " n_obs=" %12.0f NN
display "ANSWER: first_stage estimate=" %21.12f b2 " se=" %21.12f se2 " n_obs=" %12.0f NN
display "ANSWER: effective_shocks estimate=" %21.12f eff " se=. n_obs=" %12.0f NN
