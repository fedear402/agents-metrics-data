clear all
set more off
set type double
scalar wsum=0
scalar wtot=0
scalar ntot=0
foreach c in 3 5 7 {
    import delimited using "./input.csv", clear varnames(1)
    keep if time>=`c'-2 & time<=`c'+2
    keep if g==`c' | g==0 | g>`c'+2
    keep if !missing(y)
    bysort id: gen int nt=_N
    keep if nt==5
    gen byte did=(g==`c' & time>=`c')
    quietly regress y did i.id i.time
    scalar att`c'=_b[did]
    scalar n`c'=e(N)
    egen byte tag=tag(id)
    quietly count if tag & g==`c'
    scalar w`c'=r(N)
    scalar wsum=wsum+w`c'*att`c'
    scalar wtot=wtot+w`c'
    scalar ntot=ntot+n`c'
}
scalar attw=wsum/wtot
foreach c in 3 5 7 {
    local e=strtrim(string(att`c',"%24.16g"))
    local n=strtrim(string(n`c',"%12.0f"))
    display "ANSWER: att_g`c' estimate=`e' se=null n_obs=`n'"
}
local e=strtrim(string(attw,"%24.16g"))
local n=strtrim(string(ntot,"%12.0f"))
display "ANSWER: att_weighted estimate=`e' se=null n_obs=`n'"
exit, clear
