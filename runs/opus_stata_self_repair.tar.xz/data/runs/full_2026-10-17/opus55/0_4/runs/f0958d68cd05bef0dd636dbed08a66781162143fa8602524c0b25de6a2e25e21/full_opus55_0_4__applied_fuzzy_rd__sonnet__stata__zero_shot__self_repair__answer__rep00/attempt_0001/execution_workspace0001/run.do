clear all
set more off
set linesize 255

import delimited using "./input.csv", clear varnames(1)

keep if abs(score) < 1 & !missing(score, participated, earnings)
gen double w = 1 - abs(score)
gen double d = (score >= 0)
gen double ds = d*score
gen double one = 1

mata:
    X  = st_data(., ("one","d","score","ds"))
    y1 = st_data(., "earnings")
    y2 = st_data(., "participated")
    w  = st_data(., "w")
    n  = rows(X)
    A  = cross(X, w, X)
    Ai = invsym(A)
    b1 = Ai*cross(X, w, y1)
    b2 = Ai*cross(X, w, y2)
    e1 = y1 - X*b1
    e2 = y2 - X*b2
    S1 = X :* (w:*e1)
    S2 = X :* (w:*e2)
    V11 = Ai*(S1'S1)*Ai
    V22 = Ai*(S2'S2)*Ai
    V12 = Ai*(S1'S2)*Ai
    rf = b1[2]
    fs = b2[2]
    vrf = V11[2,2]
    vfs = V22[2,2]
    crf = V12[2,2]
    te = rf/fs
    g1 = 1/fs
    g2 = -rf/(fs^2)
    vte = g1^2*vrf + g2^2*vfs + 2*g1*g2*crf
    st_numscalar("rf", rf)
    st_numscalar("fs", fs)
    st_numscalar("te", te)
    st_numscalar("se_rf", sqrt(vrf))
    st_numscalar("se_fs", sqrt(vfs))
    st_numscalar("se_te", sqrt(vte))
    st_numscalar("nobs", n)
end

display "ANSWER: treatment_effect estimate=" %21.12f te " se=" %21.12f se_te " n_obs=" %12.0f nobs
display "ANSWER: reduced_form estimate=" %21.12f rf " se=" %21.12f se_rf " n_obs=" %12.0f nobs
display "ANSWER: first_stage estimate=" %21.12f fs " se=" %21.12f se_fs " n_obs=" %12.0f nobs
