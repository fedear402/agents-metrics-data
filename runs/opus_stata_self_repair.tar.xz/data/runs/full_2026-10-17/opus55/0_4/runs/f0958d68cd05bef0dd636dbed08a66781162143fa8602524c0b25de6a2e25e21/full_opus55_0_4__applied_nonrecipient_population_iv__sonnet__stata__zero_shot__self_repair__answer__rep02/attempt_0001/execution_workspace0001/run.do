clear all
set more off
import delimited using "census.csv", clear varnames(1)
tempfile cen
keep eligible nonrecipient_population
save `cen'
import delimited using "households.csv", clear varnames(1)
keep if recipient==0
gen double inel = 1-eligible
gen double el = eligible
gen double d0 = dose*inel
gen double d1 = dose*el
gen double b0 = baseline*inel
gen double b1 = baseline*el
gen double z0 = instrument*inel
gen double z1 = instrument*el
ivregress 2sls outcome inel el b0 b1 (d0 d1 = z0 z1) [aweight=weight], noconstant
scalar s0 = _b[d0]
scalar s1 = _b[d1]
local N = e(N)
quietly summarize dose [aweight=weight] if eligible==0 & e(sample)
scalar m0 = r(mean)
quietly summarize dose [aweight=weight] if eligible==1 & e(sample)
scalar m1 = r(mean)
scalar e0 = s0*m0
scalar e1 = s1*m1
use `cen', clear
quietly summarize nonrecipient_population if eligible==0
scalar p0 = r(sum)
quietly summarize nonrecipient_population if eligible==1
scalar p1 = r(sum)
scalar pe = (p0*e0 + p1*e1)/(p0+p1)
di "ANSWER: ineligible_effect estimate=" %20.12g e0 " se=NA n_obs=" `N'
di "ANSWER: eligible_nonrecipient_effect estimate=" %20.12g e1 " se=NA n_obs=" `N'
di "ANSWER: population_effect estimate=" %20.12g pe " se=NA n_obs=" `N'
