clear all
set more off
set linesize 255

import delimited using "./input.csv", clear varnames(1)

* Regional shift-share instrument
gen double sz = share*shock
bysort region_id: egen double z = total(sz)

* Region-level data
preserve
bysort region_id: keep if _n==1
keep region_id region_weight x y z
quietly summarize region_weight
gen double e = region_weight/r(sum)

* Regional weighted 2SLS
ivregress 2sls y (x = z) [aweight=e]
scalar b_reg = _b[x]
regress x z [aweight=e]
scalar fs_reg = _b[z]

* Demean with e-weighted means
foreach v in y x z {
    quietly summarize `v' [aweight=e]
    gen double `v'0 = `v' - r(mean)
}
keep region_id e y0 x0 z0
tempfile reg
save `reg'
restore

merge m:1 region_id using `reg', nogenerate

* Shock-level aggregation
gen double w  = e*share
gen double wy = w*y0
gen double wx = w*x0
gen double wz = w*z0
collapse (sum) s=w wy wx wz (first) shock, by(industry_id)
drop if s<=0 | missing(s)
gen double ybar = wy/s
gen double xbar = wx/s
gen double zbar = wz/s

quietly count
scalar N = r(N)

* Effect: shock-level IV, HC1 with N/(N-2)
ivregress 2sls ybar (xbar = shock) [aweight=s], vce(robust) small
scalar b_eff  = _b[xbar]
scalar se_eff = _se[xbar]

* First stage: shock-level IV of xbar on zbar instrumented by shock
ivregress 2sls xbar (zbar = shock) [aweight=s], vce(robust) small
scalar b_fs  = _b[zbar]
scalar se_fs = _se[zbar]

* Effective number of shocks
gen double s2 = s^2
quietly summarize s2
scalar eff = 1/r(sum)

display "Regional 2SLS slope check: " %21.12f b_reg "  first-stage check: " %21.12f fs_reg
display "ANSWER: effect estimate=" %21.12f b_eff " se=" %21.12f se_eff " n_obs=" %12.0f N
display "ANSWER: first_stage estimate=" %21.12f b_fs " se=" %21.12f se_fs " n_obs=" %12.0f N
display "ANSWER: effective_shocks estimate=" %21.12f eff " se=. n_obs=" %12.0f N
