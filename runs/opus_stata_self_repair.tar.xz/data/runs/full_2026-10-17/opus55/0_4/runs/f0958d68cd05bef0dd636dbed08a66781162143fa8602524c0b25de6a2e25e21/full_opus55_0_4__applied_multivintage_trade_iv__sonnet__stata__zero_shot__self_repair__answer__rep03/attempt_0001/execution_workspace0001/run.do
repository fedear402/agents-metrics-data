clear all
set more off

* National industry employment by period-vintage-industry (all supplied areas)
import delimited using "employment.csv", clear varnames(1)
collapse (sum) nat=employment, by(period vintage industry)
tempfile nat
save `nat'

import delimited using "employment.csv", clear varnames(1)
collapse (sum) employment, by(area period vintage industry)
tempfile emp
save `emp'

import delimited using "crosswalk.csv", clear varnames(1)
tempfile cw
save `cw'
keep industry
duplicates drop
tempfile inds
save `inds'

import delimited using "trade.csv", clear varnames(1)
merge m:1 code using `cw', keep(match) nogenerate
keep period industry us_change other_change price_index years
tempfile tr
save `tr'

import delimited using "areas.csv", clear varnames(1)
tempfile areas
save `areas'
keep if vintage=="base"
keep area period population
tempfile pop
save `pop'

* Full grid area x period x vintage x industry
use `areas', clear
keep area period vintage total_employment
cross using `inds'
merge 1:1 area period vintage industry using `emp', keep(master match) nogenerate
replace employment = 0 if missing(employment)
merge m:1 period vintage industry using `nat', keep(master match) nogenerate
merge m:1 period industry using `tr', keep(master match) nogenerate

gen double sh = employment/total_employment
gen double defl = (price_index/100)*1000*(years/10)
gen double xt = cond(vintage=="base", sh*us_change/nat/defl, 0)
gen double zt = cond(vintage=="early", sh*other_change/nat/defl, 0)
collapse (sum) x=xt z=zt, by(area period)

merge 1:1 area period using `pop', keep(match) nogenerate
tempfile ex
save `ex'
import delimited using "outcomes.csv", clear varnames(1)
merge 1:1 area period using `ex', keep(match) nogenerate

ivregress 2sls change_pp period control (x = z) [aweight=population]
local b = _b[x]
local n = e(N)

sum x if area==0 & period==0, meanonly
local x0 = r(mean)
sum x if area==0 & period==1, meanonly
local x1 = r(mean)
sum z if area==0 & period==0, meanonly
local z0 = r(mean)

di "ANSWER: iv_slope estimate=" %20.12g `b' " se=NA n_obs=" `n'
di "ANSWER: exposure_area0_period0 estimate=" %20.12g `x0' " se=NA n_obs=" `n'
di "ANSWER: exposure_area0_period1 estimate=" %20.12g `x1' " se=NA n_obs=" `n'
di "ANSWER: instrument_area0_period0 estimate=" %20.12g `z0' " se=NA n_obs=" `n'
