clear all
set more off
set linesize 255

import delimited "./input.csv", clear varnames(1)

keep if abs(score) < 1 & !missing(score, participated, earnings)
gen double w = 1 - abs(score)
gen double d = (score >= 0)
gen double ds = d*score
gen double one = 1

mata:
    X = st_data(., ("one","d","score","ds"))
    y = st_data(., "earnings")
    t = st_data(., "participated")
    w = st_data(., "w")
    n = rows(X)
    XWX = cross(X, w, X)
    A = invsym(XWX)
    by = A*cross(X, w, y)
    bt = A*cross(X, w, t)
    ey = y - X*by
    et = t - X*bt
    Sy = X :* (w:*ey)
    St = X :* (w:*et)
    Vyy = A*(Sy'Sy)*A
    Vtt = A*(St'St)*A
    Vyt = A*(Sy'St)*A
    rf = by[2]
    fs = bt[2]
    vrf = Vyy[2,2]
    vfs = Vtt[2,2]
    cov = Vyt[2,2]
    te = rf/fs
    g1 = 1/fs
    g2 = -rf/(fs^2)
    vte = g1^2*vrf + g2^2*vfs + 2*g1*g2*cov
    st_numscalar("rf", rf)
    st_numscalar("fs", fs)
    st_numscalar("te", te)
    st_numscalar("se_rf", sqrt(vrf))
    st_numscalar("se_fs", sqrt(vfs))
    st_numscalar("se_te", sqrt(vte))
    st_numscalar("nobs", n)
end

display "ANSWER: treatment_effect estimate=" %21.12f te " se=" %21.12f se_te " n_obs=" %12.0f nobs
display "ANSWER: reduced_form estimate=" %21.12f rf " se=" %21.12f se_rf " n_obs=" %12.0f nobs
display "ANSWER: first_stage estimate=" %21.12f fs " se=" %21.12f se_fs " n_obs=" %12.0f nobs
