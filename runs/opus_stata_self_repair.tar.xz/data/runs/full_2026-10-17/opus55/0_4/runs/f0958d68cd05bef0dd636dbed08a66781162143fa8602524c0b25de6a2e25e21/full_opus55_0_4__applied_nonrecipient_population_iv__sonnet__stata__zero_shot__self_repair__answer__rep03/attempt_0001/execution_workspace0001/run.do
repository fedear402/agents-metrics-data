clear all
set more off

import delimited using "census.csv", clear varnames(1)
keep eligible nonrecipient_population
collapse (sum) nonrecipient_population, by(eligible)
tempfile cen
save `cen'
quietly summarize nonrecipient_population if eligible==0
scalar pop0 = r(sum)
quietly summarize nonrecipient_population if eligible==1
scalar pop1 = r(sum)

import delimited using "households.csv", clear varnames(1)
keep if recipient==0
drop if missing(outcome, dose, instrument, baseline, weight, eligible)

gen double c0 = 1 - eligible
gen double c1 = eligible
gen double d0 = dose*c0
gen double d1 = dose*c1
gen double b0 = baseline*c0
gen double b1 = baseline*c1
gen double z0 = instrument*c0
gen double z1 = instrument*c1

ivregress 2sls outcome c0 c1 b0 b1 (d0 d1 = z0 z1) [aweight=weight], noconstant
scalar s0 = _b[d0]
scalar s1 = _b[d1]
scalar N = e(N)

quietly summarize dose [aweight=weight] if eligible==0 & e(sample)
scalar m0 = r(mean)
quietly summarize dose [aweight=weight] if eligible==1 & e(sample)
scalar m1 = r(mean)

scalar e0 = s0*m0
scalar e1 = s1*m1
scalar ep = (pop0*e0 + pop1*e1)/(pop0 + pop1)

display "ANSWER: ineligible_effect estimate=" %21.12g e0 " se=NA n_obs=" %12.0f N
display "ANSWER: eligible_nonrecipient_effect estimate=" %21.12g e1 " se=NA n_obs=" %12.0f N
display "ANSWER: population_effect estimate=" %21.12g ep " se=NA n_obs=" %12.0f N
