version 19.0
clear all
set more off
set linesize 255
import delimited using "./input.csv", clear varnames(1)
sort region_id industry_id
mata:
rid=st_data(.,"region_id")
iid=st_data(.,"industry_id")
sh=st_data(.,"share")
shk=st_data(.,"shock")
w=st_data(.,"region_weight")
xv=st_data(.,"x")
yv=st_data(.,"y")
ur=uniqrows(rid)
ui=uniqrows(iid)
R=rows(ur)
N=rows(ui)
S=J(R,N,0)
shock=J(N,1,.)
e=J(R,1,.)
x=J(R,1,.)
y=J(R,1,.)
for (k=1;k<=rows(rid);k++) {
    r=selectindex(ur:==rid[k])
    n=selectindex(ui:==iid[k])
    S[r,n]=S[r,n]+sh[k]
    shock[n]=shk[k]
    e[r]=w[k]
    x[r]=xv[k]
    y[r]=yv[k]
}
e=e/sum(e)
z=S*shock
regional=(y,x,z)
centered=regional:-e'*regional
mass=S'*e
aggregated=(S'*(e:*centered)):/mass
estimates=J(2,2,.)
for (eq=1;eq<=2;eq++) {
    dep=aggregated[,eq]
    endo=aggregated[,eq+1]
    X=(J(N,1,1),endo)
    Z=(J(N,1,1),shock)
    inv=luinv(Z'*(mass:*X))
    b=inv*Z'*(mass:*dep)
    u=dep-X*b
    sc=Z:*(mass:*u)
    V=N/(N-2)*inv*(sc'*sc)*inv'
    estimates[eq,]=(b[2],sqrt(V[2,2]))
}
st_numscalar("b1",estimates[1,1])
st_numscalar("s1",estimates[1,2])
st_numscalar("b2",estimates[2,1])
st_numscalar("s2",estimates[2,2])
st_numscalar("eff",1/sum(mass:^2))
st_numscalar("nn",N)
end
display "ANSWER: effect estimate=" %21.12f b1 " se=" %21.12f s1 " n_obs=" %12.0f nn
display "ANSWER: first_stage estimate=" %21.12f b2 " se=" %21.12f s2 " n_obs=" %12.0f nn
display "ANSWER: effective_shocks estimate=" %21.12f eff " se=. n_obs=" %12.0f nn
