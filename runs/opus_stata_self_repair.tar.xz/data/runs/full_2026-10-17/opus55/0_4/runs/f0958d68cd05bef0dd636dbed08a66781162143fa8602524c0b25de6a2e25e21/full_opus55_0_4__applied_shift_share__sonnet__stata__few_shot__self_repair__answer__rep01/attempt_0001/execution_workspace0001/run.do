version 19.0
clear all
set more off
set linesize 255
import delimited using "./input.csv", clear varnames(1)
sort region_id industry_id
mata:
D = st_data(., ("region_id","industry_id","share","shock","region_weight","x","y"))
rid = D[,1]; iid = D[,2]
ur = uniqrows(rid); ui = uniqrows(iid)
R = rows(ur); N = rows(ui)
S = J(R,N,0); shock = J(N,1,.); w = J(R,1,.); X = J(R,1,.); Y = J(R,1,.)
for (k=1;k<=rows(D);k++) {
    r = selectindex(ur:==rid[k])[1]
    n = selectindex(ui:==iid[k])[1]
    S[r,n] = S[r,n] + D[k,3]
    shock[n] = D[k,4]
    w[r] = D[k,5]; X[r] = D[k,6]; Y[r] = D[k,7]
}
e = w/sum(w)
z = S*shock
reg = (Y, X, z)
cen = reg :- e'*reg
s = S'*e
agg = (S'*(e:*cen)):/s
est = J(2,2,.)
for (q=1;q<=2;q++) {
    dep = agg[,q]
    en = agg[,q+1]
    Xm = (J(N,1,1), en)
    Zm = (J(N,1,1), shock)
    inv = luinv(Zm'*(s:*Xm))
    b = inv*Zm'*(s:*dep)
    u = dep - Xm*b
    sc = Zm:*(s:*u)
    V = N/(N-2)*inv*(sc'*sc)*inv'
    est[q,] = (b[2], sqrt(V[2,2]))
}
st_numscalar("b1",est[1,1]); st_numscalar("se1",est[1,2])
st_numscalar("b2",est[2,1]); st_numscalar("se2",est[2,2])
st_numscalar("eff",1/sum(s:^2)); st_numscalar("nn",N)
end
display "ANSWER: effect estimate=" %21.12f b1 " se=" %21.12f se1 " n_obs=" %12.0f nn
display "ANSWER: first_stage estimate=" %21.12f b2 " se=" %21.12f se2 " n_obs=" %12.0f nn
display "ANSWER: effective_shocks estimate=" %21.12f eff " se=. n_obs=" %12.0f nn
