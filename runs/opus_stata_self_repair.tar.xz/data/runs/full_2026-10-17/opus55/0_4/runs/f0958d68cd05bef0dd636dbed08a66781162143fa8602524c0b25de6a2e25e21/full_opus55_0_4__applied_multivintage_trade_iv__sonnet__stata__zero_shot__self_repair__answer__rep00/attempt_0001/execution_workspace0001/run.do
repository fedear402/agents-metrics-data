clear all
set more off

* Crosswalk
import delimited using "crosswalk.csv", clear varnames(1)
keep code industry
duplicates drop
tempfile cw
save `cw'

* Industry list
keep industry
duplicates drop
tempfile inds
save `inds'

* Trade
import delimited using "trade.csv", clear varnames(1)
merge m:1 code using `cw', keep(match) nogenerate
keep period industry us_change other_change price_index years
tempfile tr
save `tr'

* Areas
import delimited using "areas.csv", clear varnames(1)
capture confirm string variable vintage
if _rc tostring vintage, replace
replace vintage = lower(strtrim(vintage))
tempfile ar
save `ar'

preserve
keep if vintage == "base"
keep area period population
duplicates drop area period, force
tempfile pop
save `pop'
restore

* Full area-period-vintage-industry grid
keep area period vintage total_employment
cross using `inds'
tempfile grid
save `grid'

* Employment
import delimited using "employment.csv", clear varnames(1)
capture confirm string variable vintage
if _rc tostring vintage, replace
replace vintage = lower(strtrim(vintage))
collapse (sum) employment, by(area period vintage industry)
tempfile emp
save `emp'

use `grid', clear
merge 1:1 area period vintage industry using `emp', keep(master match) nogenerate
replace employment = 0 if missing(employment)

bysort period vintage industry: egen double nat = total(employment)

merge m:1 period industry using `tr', keep(match) nogenerate

gen double chg = cond(vintage == "base", us_change, other_change)
gen double term = (employment/total_employment) * (chg/nat) / (price_index/100) / 1000 * (10/years)

collapse (sum) term, by(area period vintage)
gen str5 v = cond(vintage == "base", "x", "z")
drop vintage
reshape wide term, i(area period) j(v) string
rename termx x
rename termz z

merge 1:1 area period using `pop', keep(match) nogenerate
tempfile expo
save `expo'

import delimited using "outcomes.csv", clear varnames(1)
merge 1:1 area period using `expo', keep(match) nogenerate

ivregress 2sls change_pp period control (x = z) [aw=population]
scalar b = _b[x]
scalar n = e(N)

summarize x if area == 0 & period == 0, meanonly
scalar x00 = r(mean)
summarize x if area == 0 & period == 1, meanonly
scalar x01 = r(mean)
summarize z if area == 0 & period == 0, meanonly
scalar z00 = r(mean)

display "ANSWER: iv_slope estimate=" %20.12g b " se=NA n_obs=" n
display "ANSWER: exposure_area0_period0 estimate=" %20.12g x00 " se=NA n_obs=" n
display "ANSWER: exposure_area0_period1 estimate=" %20.12g x01 " se=NA n_obs=" n
display "ANSWER: instrument_area0_period0 estimate=" %20.12g z00 " se=NA n_obs=" n
