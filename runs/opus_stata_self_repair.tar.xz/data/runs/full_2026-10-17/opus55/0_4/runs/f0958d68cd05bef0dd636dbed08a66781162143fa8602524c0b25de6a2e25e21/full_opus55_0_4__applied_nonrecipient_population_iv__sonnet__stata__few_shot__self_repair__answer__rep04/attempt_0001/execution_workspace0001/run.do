clear all
set more off
set type double
import delimited using "households.csv", clear case(preserve)
keep if recipient==0
gen double ie = 1-eligible
gen double el = eligible
gen double d0 = dose*ie
gen double d1 = dose*el
gen double b0x = baseline*ie
gen double b1x = baseline*el
gen double z0 = instrument*ie
gen double z1 = instrument*el
ivregress 2sls outcome ie el b0x b1x (d0 d1 = z0 z1) [aw=weight], noconstant
scalar s0=_b[d0]
scalar s1=_b[d1]
quietly count if e(sample)
scalar N=r(N)
quietly count if e(sample) & eligible==0
scalar N0=r(N)
quietly count if e(sample) & eligible==1
scalar N1=r(N)
summarize dose [aw=weight] if e(sample) & eligible==0, meanonly
scalar e0=s0*r(mean)
summarize dose [aw=weight] if e(sample) & eligible==1, meanonly
scalar e1=s1*r(mean)
import delimited using "census.csv", clear case(preserve)
summarize nonrecipient_population if eligible==0, meanonly
scalar n0=r(sum)
summarize nonrecipient_population if eligible==1, meanonly
scalar n1=r(sum)
scalar ep=(e0*n0+e1*n1)/(n0+n1)
display "ANSWER: ineligible_effect estimate=" %24.16g e0 " se=NA n_obs=" %12.0f N0
display "ANSWER: eligible_nonrecipient_effect estimate=" %24.16g e1 " se=NA n_obs=" %12.0f N1
display "ANSWER: population_effect estimate=" %24.16g ep " se=NA n_obs=" %12.0f N
exit, clear
