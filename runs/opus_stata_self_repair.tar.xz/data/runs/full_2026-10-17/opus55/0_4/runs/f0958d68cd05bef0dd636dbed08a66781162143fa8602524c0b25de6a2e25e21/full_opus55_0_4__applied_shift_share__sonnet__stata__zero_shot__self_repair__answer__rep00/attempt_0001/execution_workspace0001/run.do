clear all
set more off
set linesize 255

import delimited using "./input.csv", clear varnames(1)

* region-level normalized weights
bysort region_id: gen byte rtag = (_n == 1)
quietly summarize region_weight if rtag
scalar sumw = r(sum)
gen double e = region_weight / sumw

* shift-share instrument
gen double sg = share * shock
bysort region_id: egen double z = total(sg)

* e-weighted regional means (one obs per region)
foreach v in y x z {
    quietly summarize `v' [aw=e] if rtag
    gen double `v'0 = `v' - r(mean)
}

* shock-level aggregation
gen double es = e * share
gen double esy = es * y0
gen double esx = es * x0
gen double esz = es * z0
collapse (sum) s=es sy=esy sx=esx sz=esz (mean) shock, by(industry_id)
drop if s <= 0 | missing(s)
gen double ybar = sy / s
gen double xbar = sx / s
gen double zbar = sz / s

gen double s2 = s^2
quietly summarize s2
scalar eff = 1 / r(sum)

mata:
real rowvector ivhc1(string scalar yv, string scalar xv, string scalar gv, string scalar wv)
{
    real colvector y, x, g, w, u, b
    real matrix X, Z, A, Ai, M, V
    real scalar N
    y = st_data(., yv); x = st_data(., xv); g = st_data(., gv); w = st_data(., wv)
    N = rows(y)
    w = w * N / sum(w)
    X = J(N,1,1), x
    Z = J(N,1,1), g
    A = Z' * (w :* X)
    Ai = luinv(A)
    b = Ai * (Z' * (w :* y))
    u = y - X * b
    M = (Z :* (w :* u))' * (Z :* (w :* u))
    V = Ai * M * Ai' * N / (N - 2)
    return((b[2], sqrt(V[2,2]), N))
}
r = ivhc1("ybar", "xbar", "shock", "s")
st_numscalar("b_eff", r[1]); st_numscalar("se_eff", r[2]); st_numscalar("N", r[3])
r = ivhc1("xbar", "zbar", "shock", "s")
st_numscalar("b_fs", r[1]); st_numscalar("se_fs", r[2])
end

display "ANSWER: effect estimate=" %21.12f b_eff " se=" %21.12f se_eff " n_obs=" %12.0f N
display "ANSWER: first_stage estimate=" %21.12f b_fs " se=" %21.12f se_fs " n_obs=" %12.0f N
display "ANSWER: effective_shocks estimate=" %21.12f eff " se=" "." " n_obs=" %12.0f N
