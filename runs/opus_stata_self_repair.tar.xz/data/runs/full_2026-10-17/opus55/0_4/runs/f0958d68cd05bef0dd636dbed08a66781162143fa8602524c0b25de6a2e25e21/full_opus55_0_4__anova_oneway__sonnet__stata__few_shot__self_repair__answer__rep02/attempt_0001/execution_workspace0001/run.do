clear all
set more off
set linesize 255
import delimited using "./input.csv", clear varnames(1)
capture confirm string variable group
if !_rc {
    encode group, gen(group_id)
}
else {
    gen group_id = group
}
capture confirm string variable y
if !_rc {
    destring y, replace force
}
keep if !missing(y) & !missing(group_id)
oneway y group_id
scalar Fs = r(F)
scalar dfm = r(df_m)
scalar dfr = r(df_r)
scalar nn = r(N)
scalar pv = Ftail(dfm, dfr, Fs)
display "ANSWER: F estimate=" %21.12f Fs " se=. n_obs=" %12.0f nn
display "ANSWER: df_num estimate=" %21.12f dfm " se=. n_obs=" %12.0f nn
display "ANSWER: df_den estimate=" %21.12f dfr " se=. n_obs=" %12.0f nn
display "ANSWER: p_value estimate=" %21.12f pv " se=. n_obs=" %12.0f nn
