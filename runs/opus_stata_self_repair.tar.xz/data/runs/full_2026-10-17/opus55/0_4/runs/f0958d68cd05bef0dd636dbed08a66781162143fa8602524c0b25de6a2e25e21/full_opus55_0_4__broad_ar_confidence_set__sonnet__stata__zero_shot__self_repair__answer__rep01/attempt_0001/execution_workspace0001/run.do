clear all
set more off
set linesize 255

import delimited "./input.csv", clear
count
local n = r(N)

* Restricted residuals (intercept, x)
quietly regress y x
predict double ry, residuals
quietly regress endog x
predict double rd, residuals

* Unrestricted residuals (intercept, x, z1, z2)
quietly regress y x z1 z2
predict double uy, residuals
quietly regress endog x z1 z2
predict double ud, residuals

generate double ryy = ry*ry
generate double ryd = ry*rd
generate double rdd = rd*rd
generate double uyy = uy*uy
generate double uyd = uy*ud
generate double udd = ud*ud

foreach v in ryy ryd rdd uyy uyd udd {
    quietly summarize `v'
    scalar S_`v' = r(sum)
}

scalar dfd = `n' - 4
scalar cval = invFtail(2, dfd, 0.05)
scalar kk = 2*cval/dfd

* RSS_r(b) - (1+k) RSS_u(b) <= 0  <=>  a2 b^2 + a1 b + a0 <= 0
scalar a2 = S_rdd - (1+kk)*S_udd
scalar a1 = -2*(S_ryd - (1+kk)*S_uyd)
scalar a0 = S_ryy - (1+kk)*S_uyy

scalar disc = a1^2 - 4*a2*a0
scalar r1 = (-a1 - sqrt(disc))/(2*a2)
scalar r2 = (-a1 + sqrt(disc))/(2*a2)
scalar blow = min(r1, r2)
scalar bhigh = max(r1, r2)

* Membership from inequality
scalar acc0 = (a0 <= 0)
scalar unb = (a2 < 0) | (a2 == 0 & a1 != 0)

* AR F at beta = 1
generate double ytil = y - 1*endog
quietly regress ytil x z1 z2
quietly test z1 z2
scalar f1 = r(F)

display "ANSWER: boundary_low estimate=" %21.12f blow " se=." " n_obs=" %12.0f `n'
display "ANSWER: boundary_high estimate=" %21.12f bhigh " se=." " n_obs=" %12.0f `n'
display "ANSWER: accepts_zero estimate=" %21.12f acc0 " se=." " n_obs=" %12.0f `n'
display "ANSWER: unbounded estimate=" %21.12f unb " se=." " n_obs=" %12.0f `n'
display "ANSWER: ar_f_at_one estimate=" %21.12f f1 " se=." " n_obs=" %12.0f `n'
