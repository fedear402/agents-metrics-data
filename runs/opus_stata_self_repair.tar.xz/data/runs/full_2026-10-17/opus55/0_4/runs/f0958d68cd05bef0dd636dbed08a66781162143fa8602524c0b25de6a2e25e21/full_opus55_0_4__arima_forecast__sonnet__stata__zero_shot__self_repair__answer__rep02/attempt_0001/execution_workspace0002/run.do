clear all
set more off
set linesize 255

import delimited using "./input.csv", clear
sort t
tsset t

arima y, arima(1,1,1) noconstant
scalar nobs = e(N)
scalar sig = [sigma]_b[_cons]

tsappend, add(1)

predict double yf, y
predict double dmse, mse

quietly summarize t
scalar tmax = r(max)
quietly summarize yf if t == tmax
scalar fc = r(mean)
quietly summarize dmse if t == tmax
scalar fmse = r(mean)
if missing(fmse) scalar fmse = sig^2
scalar fse = sqrt(fmse)

scalar z = invnormal(0.975)
scalar lo = fc - z*fse
scalar hi = fc + z*fse

display "Forecast t=" tmax
display "ANSWER: forecast estimate=" %21.12f fc " se=" %21.12f fse " n_obs=" %12.0f nobs
display "ANSWER: lower_95 estimate=" %21.12f lo " se=. n_obs=" %12.0f nobs
display "ANSWER: upper_95 estimate=" %21.12f hi " se=. n_obs=" %12.0f nobs
