clear all
set more off
set linesize 255
import delimited using "./input.csv", clear
local n = _N

quietly regress y x
predict double ry_r, resid
quietly regress endog x
predict double re_r, resid
quietly regress y x z1 z2
predict double ry_u, resid
quietly regress endog x z1 z2
predict double re_u, resid

gen double yy_r = ry_r^2
gen double ye_r = ry_r*re_r
gen double ee_r = re_r^2
gen double yy_u = ry_u^2
gen double ye_u = ry_u*re_u
gen double ee_u = re_u^2
foreach v in yy_r ye_r ee_r yy_u ye_u ee_u {
    quietly summarize `v', meanonly
    scalar S_`v' = r(sum)
}

scalar Pyy = S_yy_r - S_yy_u
scalar Pye = S_ye_r - S_ye_u
scalar Pee = S_ee_r - S_ee_u
scalar Myy = S_yy_u
scalar Mye = S_ye_u
scalar Mee = S_ee_u

scalar dfd = `n' - 4
scalar crit = invFtail(2, dfd, 0.05)
scalar k = 2*crit/dfd

scalar qa = Pee - k*Mee
scalar qb = -2*(Pye - k*Mye)
scalar qc = Pyy - k*Myy
scalar disc = qb^2 - 4*qa*qc

scalar r1 = (-qb - sqrt(disc))/(2*qa)
scalar r2 = (-qb + sqrt(disc))/(2*qa)
scalar blow = min(r1, r2)
scalar bhigh = max(r1, r2)

scalar unbounded = (qa < 0)
scalar acc0 = (qc <= 0)

* F at beta = 1
scalar N1 = Pyy - 2*Pye + Pee
scalar D1 = Myy - 2*Mye + Mee
scalar F1 = (N1/2)/(D1/dfd)

display "ANSWER: boundary_low estimate=" %21.12f blow " se=. n_obs=" %12.0f `n'
display "ANSWER: boundary_high estimate=" %21.12f bhigh " se=. n_obs=" %12.0f `n'
display "ANSWER: accepts_zero estimate=" %21.12f acc0 " se=. n_obs=" %12.0f `n'
display "ANSWER: unbounded estimate=" %21.12f unbounded " se=. n_obs=" %12.0f `n'
display "ANSWER: ar_f_at_one estimate=" %21.12f F1 " se=. n_obs=" %12.0f `n'
