clear all
set more off
set linesize 255
set type double
import delimited using "./input.csv", clear case(lower)
keep if !missing(y, endog, x, z1, z2)
quietly count
scalar nobs = r(N)

* Restricted model: intercept and x only
quietly regress y x
predict double ry, residuals
quietly regress endog x
predict double rd, residuals

* Unrestricted model: intercept, x, z1, z2
quietly regress y x z1 z2
predict double uy, residuals
scalar df = e(df_r)
quietly regress endog x z1 z2
predict double ud, residuals

scalar q = 2
scalar critical = invFtail(q, df, .05)
scalar k = q*critical/df

mata:
ry = st_data(., "ry"); rd = st_data(., "rd")
uy = st_data(., "uy"); ud = st_data(., "ud")
k  = st_numscalar("k")
q  = st_numscalar("q"); df = st_numscalar("df")
A = quadcross(rd,rd) - (1+k)*quadcross(ud,ud)
B = -2*(quadcross(ry,rd) - (1+k)*quadcross(uy,ud))
C = quadcross(ry,ry) - (1+k)*quadcross(uy,uy)
disc = B^2 - 4*A*C
if (abs(A) > 1e-12 & disc > 0) {
    bounds = sort(((-B - sqrt(disc))/(2*A) \ (-B + sqrt(disc))/(2*A)), 1)
    lo = bounds[1]; hi = bounds[2]
}
else {
    lo = .; hi = .
}
// A>0: accepted set is [lo,hi]; A<0: accepted set is (-inf,lo] U [hi,inf)
unb = (A < 0) | (abs(A) <= 1e-12 & abs(B) <= 1e-12 & C <= 0) | (abs(A) <= 1e-12 & abs(B) > 1e-12)
acc0 = (C <= 0)
// AR F at beta = 1
e_r = ry - 1*rd
e_u = uy - 1*ud
ssr_r = quadcross(e_r, e_r)
ssr_u = quadcross(e_u, e_u)
f1 = ((ssr_r - ssr_u)/q) / (ssr_u/df)
st_numscalar("low", lo)
st_numscalar("high", hi)
st_numscalar("unbounded", unb)
st_numscalar("accepts_zero", acc0)
st_numscalar("f1", f1)
end

display "ANSWER: boundary_low estimate=" %21.12f (low) " se=" "." " n_obs=" %12.0f (nobs)
display "ANSWER: boundary_high estimate=" %21.12f (high) " se=" "." " n_obs=" %12.0f (nobs)
display "ANSWER: accepts_zero estimate=" %21.12f (accepts_zero) " se=" "." " n_obs=" %12.0f (nobs)
display "ANSWER: unbounded estimate=" %21.12f (unbounded) " se=" "." " n_obs=" %12.0f (nobs)
display "ANSWER: ar_f_at_one estimate=" %21.12f (f1) " se=" "." " n_obs=" %12.0f (nobs)
