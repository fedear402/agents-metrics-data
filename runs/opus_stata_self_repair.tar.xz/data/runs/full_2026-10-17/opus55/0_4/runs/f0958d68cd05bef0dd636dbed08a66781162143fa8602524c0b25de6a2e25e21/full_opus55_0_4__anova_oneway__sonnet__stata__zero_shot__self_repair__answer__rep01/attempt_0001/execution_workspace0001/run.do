version 14
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear varnames(1) case(lower)

capture confirm string variable y
if !_rc {
    destring y, replace force
}

capture confirm string variable group
if !_rc {
    replace group = strtrim(group)
    replace group = "" if inlist(lower(group), "na", "nan", ".", "null")
    encode group, gen(group_id)
}
else {
    gen group_id = group
}

drop if missing(y) | missing(group_id)

oneway y group_id

scalar F_stat = r(F)
scalar df_num = r(df_m)
scalar df_den = r(df_r)
scalar n_obs  = r(N)
scalar p_val  = Ftail(df_num, df_den, F_stat)

display "ANSWER: F estimate=" %21.12f F_stat " se=. n_obs=" %12.0f n_obs
display "ANSWER: df_num estimate=" %21.12f df_num " se=. n_obs=" %12.0f n_obs
display "ANSWER: df_den estimate=" %21.12f df_den " se=. n_obs=" %12.0f n_obs
display "ANSWER: p_value estimate=" %21.12f p_val " se=. n_obs=" %12.0f n_obs
