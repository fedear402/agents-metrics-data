clear all
set more off
set linesize 255
import delimited using "./input.csv", clear
keep if !missing(y, endog, x, z1, z2)
local n = _N

quietly regress y x
predict double ry, resid
quietly regress endog x
predict double re, resid
quietly regress y x z1 z2
predict double uy, resid
quietly regress endog x z1 z2
predict double ue, resid

foreach v in ryy ree rye uyy uee uye {
    tempvar t`v'
}
gen double p_ryy = ry*ry
gen double p_ree = re*re
gen double p_rye = ry*re
gen double p_uyy = uy*uy
gen double p_uee = ue*ue
gen double p_uye = uy*ue
foreach v in ryy ree rye uyy uee uye {
    quietly summarize p_`v', meanonly
    scalar s_`v' = r(sum)
}

scalar dfd = `n' - 4
scalar k = dfd/2
scalar cv = invFtail(2, dfd, 0.05)

* accept b iff A b^2 + B b + C <= 0
scalar A = k*(s_ree - s_uee) - cv*s_uee
scalar B = -2*(k*(s_rye - s_uye) - cv*s_uye)
scalar C = k*(s_ryy - s_uyy) - cv*s_uyy
scalar disc = B^2 - 4*A*C

scalar r1 = (-B - sqrt(disc))/(2*A)
scalar r2 = (-B + sqrt(disc))/(2*A)
scalar blow = min(r1, r2)
scalar bhigh = max(r1, r2)

scalar acc0 = (C <= 0)
scalar unb = (A < 0)

* F at beta = 1
scalar Rr1 = s_ryy - 2*s_rye + s_ree
scalar Ru1 = s_uyy - 2*s_uye + s_uee
scalar f1 = ((Rr1 - Ru1)/2)/(Ru1/dfd)

* cross-check F at beta=1 via regression
gen double ytil = y - endog
quietly regress ytil x z1 z2
quietly test z1 z2
display "check F(1) = " r(F) "  analytic = " f1

display "ANSWER: boundary_low estimate=" %21.12f blow " se=. n_obs=" %12.0f `n'
display "ANSWER: boundary_high estimate=" %21.12f bhigh " se=. n_obs=" %12.0f `n'
display "ANSWER: accepts_zero estimate=" %21.12f acc0 " se=. n_obs=" %12.0f `n'
display "ANSWER: unbounded estimate=" %21.12f unb " se=. n_obs=" %12.0f `n'
display "ANSWER: ar_f_at_one estimate=" %21.12f f1 " se=. n_obs=" %12.0f `n'
