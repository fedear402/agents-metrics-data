clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

keep if abs(score) < 1 & !missing(score, participated, earnings)

gen double w   = 1 - abs(score)
gen double rt  = (score >= 0)
gen double rts = rt * score
gen double cons = 1

mata:
    X = st_data(., ("cons", "rt", "score", "rts"))
    y = st_data(., "earnings")
    d = st_data(., "participated")
    w = st_data(., "w")
    n = rows(X)

    XWX = cross(X, w, X)
    B   = invsym(XWX)
    by  = B * cross(X, w, y)
    bd  = B * cross(X, w, d)
    ey  = y - X*by
    ed  = d - X*bd

    Myy = cross(X, (w:^2):*(ey:^2), X)
    Mdd = cross(X, (w:^2):*(ed:^2), X)
    Myd = cross(X, (w:^2):*(ey:*ed), X)

    Vyy = B*Myy*B
    Vdd = B*Mdd*B
    Vyd = B*Myd*B

    rf  = by[2]
    fs  = bd[2]
    vrf = Vyy[2,2]
    vfs = Vdd[2,2]
    cov = Vyd[2,2]

    te  = rf/fs
    g1  = 1/fs
    g2  = -rf/(fs^2)
    vte = g1^2*vrf + g2^2*vfs + 2*g1*g2*cov

    st_numscalar("rf", rf)
    st_numscalar("fs", fs)
    st_numscalar("te", te)
    st_numscalar("se_rf", sqrt(vrf))
    st_numscalar("se_fs", sqrt(vfs))
    st_numscalar("se_te", sqrt(vte))
    st_numscalar("nobs", n)
end

display "ANSWER: treatment_effect estimate=" %21.12f te " se=" %21.12f se_te " n_obs=" %12.0f nobs
display "ANSWER: reduced_form estimate=" %21.12f rf " se=" %21.12f se_rf " n_obs=" %12.0f nobs
display "ANSWER: first_stage estimate=" %21.12f fs " se=" %21.12f se_fs " n_obs=" %12.0f nobs
