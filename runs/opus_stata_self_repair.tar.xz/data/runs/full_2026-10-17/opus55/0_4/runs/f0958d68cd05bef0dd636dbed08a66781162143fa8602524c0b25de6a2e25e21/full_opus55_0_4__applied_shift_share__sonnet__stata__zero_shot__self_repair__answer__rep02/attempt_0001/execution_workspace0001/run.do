version 16
clear all
set more off
set linesize 255

import delimited using "./input.csv", clear varnames(1)

* Regional shift-share instrument
gen double sz = share*shock
bysort region_id: egen double z = total(sz)
bysort region_id: gen byte first = (_n==1)

* Normalize regional weights once (one obs per region)
quietly summarize region_weight if first
gen double e = region_weight/r(sum)

* Weighted demeaning at the regional level
foreach v in y x z {
    quietly summarize `v' [aw=e] if first
    gen double `v'0 = `v' - r(mean)
}

* Shock-level aggregation
gen double es  = e*share
gen double esy = es*y0
gen double esx = es*x0
gen double esz = es*z0

collapse (sum) s=es sy=esy sx=esx sz2=esz (first) shock, by(industry_id)
gen double ybar = sy/s
gen double xbar = sx/s
gen double zbar = sz2/s

mata:
void ivhc1(string scalar yv, string scalar xv, string scalar zv, string scalar wv, string scalar bname, string scalar sename)
{
    real colvector y, x, z, w, u, b
    real matrix X, Z, A, Ai, M, V
    real scalar N
    y = st_data(., yv); x = st_data(., xv); z = st_data(., zv); w = st_data(., wv)
    N = rows(y)
    X = (J(N,1,1), x)
    Z = (J(N,1,1), z)
    A = Z' * (w :* X)
    Ai = luinv(A)
    b = Ai * (Z' * (w :* y))
    u = y - X*b
    M = (Z :* (w:*u))' * (Z :* (w:*u))
    V = (N/(N-2)) * Ai * M * Ai'
    st_numscalar(bname, b[2])
    st_numscalar(sename, sqrt(V[2,2]))
}
end

mata: ivhc1("ybar", "xbar", "shock", "s", "b_eff", "se_eff")
mata: ivhc1("xbar", "zbar", "shock", "s", "b_fs", "se_fs")

quietly count
scalar nind = r(N)
gen double s2 = s^2
quietly summarize s2
scalar effsh = 1/r(sum)

display "ANSWER: effect estimate=" %21.12f b_eff " se=" %21.12f se_eff " n_obs=" %12.0f nind
display "ANSWER: first_stage estimate=" %21.12f b_fs " se=" %21.12f se_fs " n_obs=" %12.0f nind
display "ANSWER: effective_shocks estimate=" %21.12f effsh " se=. n_obs=" %12.0f nind
