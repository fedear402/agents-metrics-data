clear all
set more off
set linesize 255

import delimited using "./input.csv", clear varnames(1)

capture confirm string variable date
if !_rc {
    gen double __d = date(date, "YMD")
    if missing(__d[1]) replace __d = date(date, "MDY")
    if missing(__d[1]) replace __d = date(date, "DMY")
    drop date
    rename __d date
    format date %td
}

sort date
gen long t = _n
tsset t

gen double lsales = ln(sales)
gen double lvix = ln(vix)
gen double dlvix = D.lvix

newey lsales L(1/15).dlvix, lag(15)
scalar nobs = e(N)

scalar b1 = _b[L1.dlvix]
scalar se1 = _se[L1.dlvix]
scalar b15 = _b[L15.dlvix]
scalar se15 = _se[L15.dlvix]

lincom L1.dlvix + L2.dlvix + L3.dlvix + L4.dlvix + L5.dlvix + L6.dlvix + L7.dlvix + L8.dlvix + L9.dlvix + L10.dlvix + L11.dlvix + L12.dlvix + L13.dlvix + L14.dlvix + L15.dlvix
scalar bc = r(estimate)
scalar sec = r(se)

display "ANSWER: cumulative_response estimate=" %21.12f bc " se=" %21.12f sec " n_obs=" %12.0f nobs
display "ANSWER: lag_1 estimate=" %21.12f b1 " se=" %21.12f se1 " n_obs=" %12.0f nobs
display "ANSWER: lag_15 estimate=" %21.12f b15 " se=" %21.12f se15 " n_obs=" %12.0f nobs
