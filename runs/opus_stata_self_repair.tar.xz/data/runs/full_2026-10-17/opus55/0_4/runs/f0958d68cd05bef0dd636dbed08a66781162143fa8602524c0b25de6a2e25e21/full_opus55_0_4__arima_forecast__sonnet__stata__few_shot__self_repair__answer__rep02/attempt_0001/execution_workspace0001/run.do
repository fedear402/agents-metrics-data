clear all
set more off
set linesize 255

import delimited using "./input.csv", clear varnames(1)
sort t
tsset t

arima y, arima(1,1,1) noconstant
local nobs = e(N)

tsappend, add(1)

predict double yf, y
predict double mse_d, mse

quietly summarize t
local tmax = r(max)
quietly levelsof t if t == `tmax'
local fc = yf[_N]
local se = sqrt(mse_d[_N])
local z = invnormal(0.975)
local lo = `fc' - `z'*`se'
local hi = `fc' + `z'*`se'

display "ANSWER: forecast estimate=" %21.12f `fc' " se=" %21.12f `se' " n_obs=" %12.0f `nobs'
display "ANSWER: lower_95 estimate=" %21.12f `lo' " se=." " n_obs=" %12.0f `nobs'
display "ANSWER: upper_95 estimate=" %21.12f `hi' " se=." " n_obs=" %12.0f `nobs'
