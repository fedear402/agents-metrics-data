clear all
set more off
set linesize 255
import delimited using "./input.csv", clear
keep if !missing(y, endog, x, z1, z2)
local n = _N

quietly regress y x
predict double ey, resid
quietly regress endog x
predict double ee, resid

quietly regress ey x z1 z2
predict double py, xb
predict double ry, resid
quietly regress ee x z1 z2
predict double pe, xb
predict double re, resid

foreach v in yy ye ee {
    local a = substr("`v'",1,1)
    local b = substr("`v'",2,1)
    gen double tp = p`a' * p`b'
    quietly summarize tp
    scalar P`v' = r(sum)
    gen double tr = r`a' * r`b'
    quietly summarize tr
    scalar R`v' = r(sum)
    drop tp tr
}

scalar df2 = `n' - 4
scalar fcrit = invFtail(2, df2, 0.05)
scalar cc = 2*fcrit/df2

scalar qa = Pee - cc*Ree
scalar qb = -2*(Pye - cc*Rye)
scalar qc = Pyy - cc*Ryy
scalar disc = qb^2 - 4*qa*qc

scalar r1 = (-qb - sqrt(disc))/(2*qa)
scalar r2 = (-qb + sqrt(disc))/(2*qa)
scalar blow = min(r1, r2)
scalar bhigh = max(r1, r2)

program define arf, rclass
    args b
    scalar _N_ = Pyy - 2*`b'*Pye + (`b')^2*Pee
    scalar _D_ = Ryy - 2*`b'*Rye + (`b')^2*Ree
    return scalar F = (_N_/2)/(_D_/df2)
end

arf 0
scalar f0 = r(F)
scalar acc0 = (f0 <= fcrit)
arf 1
scalar f1 = r(F)
scalar unb = (qa < 0)

display "ANSWER: boundary_low estimate=" %21.12f blow " se=" "." " n_obs=" %12.0f `n'
display "ANSWER: boundary_high estimate=" %21.12f bhigh " se=" "." " n_obs=" %12.0f `n'
display "ANSWER: accepts_zero estimate=" %21.12f acc0 " se=" "." " n_obs=" %12.0f `n'
display "ANSWER: unbounded estimate=" %21.12f unb " se=" "." " n_obs=" %12.0f `n'
display "ANSWER: ar_f_at_one estimate=" %21.12f f1 " se=" "." " n_obs=" %12.0f `n'
