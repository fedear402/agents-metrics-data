version 19.0
clear all
set more off
set linesize 255
import delimited using "./input.csv", clear
keep if abs(score)<1 & !missing(score, participated, earnings)
gen double above = score>=0
gen double w = 1-abs(score)
gen double sxa = score*above
mata:
above=st_data(.,"above")
s=st_data(.,"score")
sa=st_data(.,"sxa")
w=st_data(.,"w")
Y=st_data(.,("earnings","participated"))
X=(J(rows(Y),1,1),s,above,sa)
bread=invsym(X'*(w:*X))
b=bread*X'*(w:*Y)
r=Y-X*b
c=(0\0\1\0)
j=c'*b
load=w:*(X*bread*c)
inf=load:*r
V=inf'*inf
g=(1/j[2]\-j[1]/j[2]^2)
st_numscalar("rf",j[1])
st_numscalar("fs",j[2])
st_numscalar("rfse",sqrt(V[1,1]))
st_numscalar("fsse",sqrt(V[2,2]))
st_numscalar("te",j[1]/j[2])
st_numscalar("tese",sqrt(g'*V*g))
st_numscalar("nn",rows(Y))
end
display "ANSWER: treatment_effect estimate=" %21.12f te " se=" %21.12f tese " n_obs=" %12.0f nn
display "ANSWER: reduced_form estimate=" %21.12f rf " se=" %21.12f rfse " n_obs=" %12.0f nn
display "ANSWER: first_stage estimate=" %21.12f fs " se=" %21.12f fsse " n_obs=" %12.0f nn
