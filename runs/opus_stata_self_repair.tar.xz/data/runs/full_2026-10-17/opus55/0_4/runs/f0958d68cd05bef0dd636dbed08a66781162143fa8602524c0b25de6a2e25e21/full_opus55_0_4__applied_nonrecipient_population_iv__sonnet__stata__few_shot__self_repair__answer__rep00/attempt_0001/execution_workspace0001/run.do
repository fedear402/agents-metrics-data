clear all
set more off
set type double

import delimited using "census.csv", clear varnames(1)
summarize nonrecipient_population if eligible==0, meanonly
scalar n0 = r(mean)
summarize nonrecipient_population if eligible==1, meanonly
scalar n1 = r(mean)

import delimited using "households.csv", clear varnames(1)
keep if recipient==0
drop if missing(outcome, dose, instrument, baseline, weight, eligible)

gen double ine = 1 - eligible
gen double eli = eligible
gen double d0 = dose*ine
gen double d1 = dose*eli
gen double b0x = baseline*ine
gen double b1x = baseline*eli
gen double z0 = instrument*ine
gen double z1 = instrument*eli

ivregress 2sls outcome ine eli b0x b1x (d0 d1 = z0 z1) [aw=weight], noconstant
scalar N = e(N)
scalar s0 = _b[d0]
scalar s1 = _b[d1]

summarize dose [aw=weight] if eligible==0 & e(sample), meanonly
scalar e0 = s0*r(mean)
summarize dose [aw=weight] if eligible==1 & e(sample), meanonly
scalar e1 = s1*r(mean)

scalar pe = (e0*n0 + e1*n1)/(n0 + n1)

display "ANSWER: ineligible_effect estimate=" %24.16g e0 " se=NA n_obs=" %12.0f N
display "ANSWER: eligible_nonrecipient_effect estimate=" %24.16g e1 " se=NA n_obs=" %12.0f N
display "ANSWER: population_effect estimate=" %24.16g pe " se=NA n_obs=" %12.0f N
