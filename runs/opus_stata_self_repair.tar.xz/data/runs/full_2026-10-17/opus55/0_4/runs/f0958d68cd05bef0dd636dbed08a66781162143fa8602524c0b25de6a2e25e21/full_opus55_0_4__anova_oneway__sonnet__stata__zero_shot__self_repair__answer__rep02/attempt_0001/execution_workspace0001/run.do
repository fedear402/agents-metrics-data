clear all
set more off
set linesize 255

import delimited using "./input.csv", clear varnames(1)

capture confirm string variable group
if !_rc {
    encode group, gen(group_n)
}
else {
    gen group_n = group
}

capture confirm string variable y
if !_rc {
    destring y, replace force
}

keep if !missing(y) & !missing(group_n)

oneway y group_n

scalar F_stat = r(F)
scalar dfn = r(df_m)
scalar dfd = r(df_r)
scalar nobs = r(N)
scalar pval = Ftail(dfn, dfd, F_stat)

display "ANSWER: F estimate=" %21.12f F_stat " se=." " n_obs=" %12.0f nobs
display "ANSWER: df_num estimate=" %21.12f dfn " se=." " n_obs=" %12.0f nobs
display "ANSWER: df_den estimate=" %21.12f dfd " se=." " n_obs=" %12.0f nobs
display "ANSWER: p_value estimate=" %21.12f pval " se=." " n_obs=" %12.0f nobs
