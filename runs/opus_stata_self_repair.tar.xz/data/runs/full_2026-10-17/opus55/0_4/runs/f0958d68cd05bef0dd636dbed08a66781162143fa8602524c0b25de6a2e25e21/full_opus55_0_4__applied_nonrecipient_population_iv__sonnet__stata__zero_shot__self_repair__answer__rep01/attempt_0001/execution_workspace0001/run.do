clear all
set more off
import delimited using "census.csv", clear varnames(1)
keep eligible nonrecipient_population
tempfile cen
save `cen'
import delimited using "households.csv", clear varnames(1)
keep if recipient==0
gen double e0 = 1-eligible
gen double e1 = eligible
gen double d0 = dose*e0
gen double d1 = dose*e1
gen double b0 = baseline*e0
gen double b1 = baseline*e1
gen double z0 = instrument*e0
gen double z1 = instrument*e1
ivregress 2sls outcome e0 e1 b0 b1 (d0 d1 = z0 z1) [aweight=weight], noconstant
scalar s0 = _b[d0]
scalar s1 = _b[d1]
local N = e(N)
quietly summarize dose [aweight=weight] if eligible==0 & e(sample)
scalar m0 = r(mean)
quietly summarize dose [aweight=weight] if eligible==1 & e(sample)
scalar m1 = r(mean)
scalar eff0 = s0*m0
scalar eff1 = s1*m1
use `cen', clear
quietly summarize nonrecipient_population if eligible==0
scalar p0 = r(sum)
quietly summarize nonrecipient_population if eligible==1
scalar p1 = r(sum)
scalar popeff = (p0*eff0 + p1*eff1)/(p0+p1)
display "ANSWER: ineligible_effect estimate=" %20.12g eff0 " se=NA n_obs=" `N'
display "ANSWER: eligible_nonrecipient_effect estimate=" %20.12g eff1 " se=NA n_obs=" `N'
display "ANSWER: population_effect estimate=" %20.12g popeff " se=NA n_obs=" `N'
