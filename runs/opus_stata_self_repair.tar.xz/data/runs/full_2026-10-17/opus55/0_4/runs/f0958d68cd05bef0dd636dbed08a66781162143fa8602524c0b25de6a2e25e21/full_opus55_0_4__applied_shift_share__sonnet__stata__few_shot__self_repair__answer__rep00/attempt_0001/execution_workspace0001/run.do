version 19.0
clear all
set more off
set linesize 255
import delimited using "./input.csv", clear varnames(1)
egen long rgrp = group(region_id)
egen long ngrp = group(industry_id)
mata:
D = st_data(., ("rgrp","ngrp","share","shock","region_weight","x","y"))
R = max(D[,1])
N = max(D[,2])
S = J(R,N,0)
shk = J(N,1,.)
w = J(R,1,.)
xr = J(R,1,.)
yr = J(R,1,.)
for (i=1;i<=rows(D);i++) {
    r = D[i,1]
    n = D[i,2]
    S[r,n] = S[r,n] + D[i,3]
    shk[n] = D[i,4]
    w[r] = D[i,5]
    xr[r] = D[i,6]
    yr[r] = D[i,7]
}
e = w/sum(w)
z = S*shk
reg = (yr,xr,z)
c = reg :- e'*reg
s = S'*e
agg = (S'*(e:*c)):/s
est = J(2,2,.)
for (eq=1;eq<=2;eq++) {
    dep = agg[,eq]
    endo = agg[,eq+1]
    X = (J(N,1,1),endo)
    Z = (J(N,1,1),shk)
    inv = luinv(Z'*(s:*X))
    b = inv*Z'*(s:*dep)
    u = dep - X*b
    sc = Z:*(s:*u)
    V = N/(N-2)*inv*(sc'*sc)*inv'
    est[eq,] = (b[2], sqrt(V[2,2]))
}
st_numscalar("b1",est[1,1])
st_numscalar("se1",est[1,2])
st_numscalar("b2",est[2,1])
st_numscalar("se2",est[2,2])
st_numscalar("effs",1/sum(s:^2))
st_numscalar("nind",N)
end
display "ANSWER: effect estimate=" %21.12f b1 " se=" %21.12f se1 " n_obs=" %12.0f nind
display "ANSWER: first_stage estimate=" %21.12f b2 " se=" %21.12f se2 " n_obs=" %12.0f nind
display "ANSWER: effective_shocks estimate=" %21.12f effs " se=. n_obs=" %12.0f nind
