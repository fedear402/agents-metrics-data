clear all
set more off
set linesize 255

import delimited using "./input.csv", clear varnames(1)
sort t
tsset t

arima y, arima(1,1,1) noconstant
local nobs = e(N)

tsappend, add(1)
predict double yf, y
predict double fmse, mse

local fc = yf[_N]
local fse = sqrt(fmse[_N])
local lo = `fc' - invnormal(0.975)*`fse'
local hi = `fc' + invnormal(0.975)*`fse'

display "ANSWER: forecast estimate=" %21.12f `fc' " se=" %21.12f `fse' " n_obs=" %12.0f `nobs'
display "ANSWER: lower_95 estimate=" %21.12f `lo' " se=. n_obs=" %12.0f `nobs'
display "ANSWER: upper_95 estimate=" %21.12f `hi' " se=. n_obs=" %12.0f `nobs'
