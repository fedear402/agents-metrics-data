clear all
set more off

* Outcomes
import delimited using "outcomes.csv", clear varnames(1)
tempfile outc cw inds trd emp
save `outc'

* Crosswalk and industry list
import delimited using "crosswalk.csv", clear varnames(1)
duplicates drop code, force
save `cw'
keep industry
duplicates drop
save `inds'

* Trade with industry
import delimited using "trade.csv", clear varnames(1)
merge m:1 code using `cw', keep(match) nogenerate
collapse (sum) us_change other_change (mean) price_index years, by(period industry)
save `trd'

* Employment
import delimited using "employment.csv", clear varnames(1)
collapse (sum) employment, by(area period vintage industry)
save `emp'

* Full area x period x vintage x industry grid
import delimited using "areas.csv", clear varnames(1)
keep area period vintage total_employment population
cross using `inds'
merge 1:1 area period vintage industry using `emp', keep(master match) nogenerate
replace employment = 0 if missing(employment)

bysort period vintage industry: egen double nat = total(employment)
merge m:1 period industry using `trd', keep(master match) nogenerate

gen double share = employment/total_employment
gen double scale = 1/(price_index/100)/1000*(10/years)
gen double tx = share*(us_change/nat)*scale if vintage=="base"
gen double tz = share*(other_change/nat)*scale if vintage=="early"
gen double popb = population if vintage=="base"

collapse (sum) x=tx z=tz (max) popb, by(area period)

merge 1:1 area period using `outc', nogenerate keep(match)

ivregress 2sls change_pp period control (x = z) [aweight=popb]
local b = _b[x]
local n = e(N)

quietly summarize x if area==0 & period==0
local x0 = r(mean)
quietly summarize x if area==0 & period==1
local x1 = r(mean)
quietly summarize z if area==0 & period==0
local z0 = r(mean)

display "ANSWER: iv_slope estimate=" %20.12g `b' " se=NA n_obs=" `n'
display "ANSWER: exposure_area0_period0 estimate=" %20.12g `x0' " se=NA n_obs=" `n'
display "ANSWER: exposure_area0_period1 estimate=" %20.12g `x1' " se=NA n_obs=" `n'
display "ANSWER: instrument_area0_period0 estimate=" %20.12g `z0' " se=NA n_obs=" `n'
