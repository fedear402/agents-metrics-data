clear all
set linesize 255
import delimited using "./input.csv", clear varnames(1)
capture confirm string variable group
if _rc == 0 {
    encode group, gen(grp_id)
}
else {
    gen grp_id = group
}
capture confirm string variable y
if _rc == 0 {
    destring y, replace force
}
keep if !missing(y) & !missing(grp_id)
oneway y grp_id
local F = r(F)
local dfn = r(df_m)
local dfd = r(df_r)
local n = r(N)
local p = Ftail(`dfn', `dfd', `F')
display "ANSWER: F estimate=" %21.12f `F' " se=. n_obs=" %12.0f `n'
display "ANSWER: df_num estimate=" %21.12f `dfn' " se=. n_obs=" %12.0f `n'
display "ANSWER: df_den estimate=" %21.12f `dfd' " se=. n_obs=" %12.0f `n'
display "ANSWER: p_value estimate=" %21.12f `p' " se=. n_obs=" %12.0f `n'
