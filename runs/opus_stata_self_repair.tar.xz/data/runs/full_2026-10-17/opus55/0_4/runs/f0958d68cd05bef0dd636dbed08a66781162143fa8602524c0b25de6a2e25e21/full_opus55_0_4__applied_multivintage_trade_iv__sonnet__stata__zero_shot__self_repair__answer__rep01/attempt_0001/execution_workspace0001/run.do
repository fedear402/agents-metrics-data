clear all
set more off

* Crosswalk
import delimited using "crosswalk.csv", clear varnames(1)
duplicates drop code industry, force
tempfile cw
save `cw'

* Trade merged to industry
import delimited using "trade.csv", clear varnames(1)
merge m:1 code using `cw', keep(match) nogenerate
collapse (sum) us_change other_change (mean) price_index years, by(period industry)
tempfile tr
save `tr'

* Industry list
use `cw', clear
keep industry
duplicates drop
tempfile inds
save `inds'

* Areas
import delimited using "areas.csv", clear varnames(1)
capture tostring vintage, replace
replace vintage = lower(strtrim(vintage))
tempfile ar
save `ar'

preserve
keep if vintage=="base"
keep area period population
collapse (mean) population, by(area period)
tempfile pop
save `pop'
restore

* Full grid area x period x vintage x industry
keep area period vintage total_employment
cross using `inds'
tempfile grid
save `grid'

import delimited using "employment.csv", clear varnames(1)
capture tostring vintage, replace
replace vintage = lower(strtrim(vintage))
collapse (sum) employment, by(area period vintage industry)
tempfile emp
save `emp'

use `grid', clear
merge 1:1 area period vintage industry using `emp', keep(master match) nogenerate
replace employment = 0 if missing(employment)

bysort period vintage industry: egen double nat = total(employment)

merge m:1 period industry using `tr', keep(master match) nogenerate

gen double chg = cond(vintage=="base", us_change, other_change)
gen double term = (employment/total_employment)*(chg/nat)/(price_index/100)/1000*(10/years)
replace term = 0 if missing(term) & employment==0

collapse (sum) term, by(area period vintage)
gen str5 v = cond(vintage=="base","x","z")
drop vintage
reshape wide term, i(area period) j(v) string
rename termx x
rename termz z

merge 1:1 area period using `pop', keep(master match) nogenerate

tempfile expo
save `expo'

import delimited using "outcomes.csv", clear varnames(1)
merge 1:1 area period using `expo', keep(match) nogenerate

ivregress 2sls change_pp period control (x = z) [aw=population]
scalar b = _b[x]
scalar n = e(N)

quietly summarize x if area==0 & period==0
scalar x00 = r(mean)
quietly summarize x if area==0 & period==1
scalar x01 = r(mean)
quietly summarize z if area==0 & period==0
scalar z00 = r(mean)

di "ANSWER: iv_slope estimate=" %20.12g b " se=NA n_obs=" %9.0f n
di "ANSWER: exposure_area0_period0 estimate=" %20.12g x00 " se=NA n_obs=" %9.0f n
di "ANSWER: exposure_area0_period1 estimate=" %20.12g x01 " se=NA n_obs=" %9.0f n
di "ANSWER: instrument_area0_period0 estimate=" %20.12g z00 " se=NA n_obs=" %9.0f n
