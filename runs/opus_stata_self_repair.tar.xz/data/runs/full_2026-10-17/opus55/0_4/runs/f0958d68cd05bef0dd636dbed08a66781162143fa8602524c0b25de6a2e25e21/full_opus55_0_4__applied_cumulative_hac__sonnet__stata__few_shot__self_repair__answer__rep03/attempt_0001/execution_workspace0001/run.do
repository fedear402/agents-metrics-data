version 19.0
clear all
set more off
set linesize 255
import delimited using "./input.csv", clear varnames(1)
capture confirm string variable date
if _rc==0 {
    generate double day=date(date,"YMD")
    replace day=date(date,"MDY") if missing(day)
}
else {
    generate double day=date
}
sort day
generate long observation=_n
tsset observation
generate double log_vix=log(vix)
generate double vix_change=D.log_vix
generate double log_sales=log(sales)
local lagvars ""
forvalues k=1/15 {
    generate double change_lag`k'=L`k'.vix_change
    local lagvars "`lagvars' change_lag`k'"
}
keep if !missing(log_sales)
foreach v of local lagvars {
    drop if missing(`v')
}
sort observation
mata:
X=(J(st_nobs(),1,1),st_data(.,tokens(st_local("lagvars"))))
y=st_data(.,"log_sales")
coefficients=qrsolve(X,y)
residuals=y-X*coefficients
N=rows(X)
p=cols(X)
scores=X:*residuals
hac_lags=15
meat=scores'*scores
for (j=1;j<=hac_lags;j++) {
    lag_product=scores[|j+1,1\N,p|]'*scores[|1,1\N-j,p|]
    meat=meat+(1-j/(hac_lags+1))*(lag_product+lag_product')
}
bread=invsym(X'*X)
covariance=N/(N-p)*bread*meat*bread
contrast=(0\J(15,1,1))
cumulative=contrast'*coefficients
cumulative_se=sqrt(contrast'*covariance*contrast)
printf("ANSWER: cumulative_response estimate=%21.15g se=%21.15g n_obs=%12.0f\n",cumulative,cumulative_se,N)
printf("ANSWER: lag_1 estimate=%21.15g se=%21.15g n_obs=%12.0f\n",coefficients[2],sqrt(covariance[2,2]),N)
printf("ANSWER: lag_15 estimate=%21.15g se=%21.15g n_obs=%12.0f\n",coefficients[16],sqrt(covariance[16,16]),N)
end
