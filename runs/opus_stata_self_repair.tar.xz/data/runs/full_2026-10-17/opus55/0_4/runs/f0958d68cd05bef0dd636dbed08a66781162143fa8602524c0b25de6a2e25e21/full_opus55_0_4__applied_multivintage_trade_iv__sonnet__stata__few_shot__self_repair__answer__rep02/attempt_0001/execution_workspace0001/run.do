clear all
set more off
set type double

* crosswalk
import delimited using "crosswalk.csv", clear varnames(1) stringcols(_all)
replace code = strtrim(code)
replace industry = strtrim(industry)
duplicates drop code, force
tempfile cw inds trade areas emp pop
save `cw'
keep industry
duplicates drop
save `inds'

* trade
import delimited using "trade.csv", clear varnames(1) stringcols(2)
replace code = strtrim(code)
merge m:1 code using `cw', keep(match) nogenerate
keep period industry us_change other_change price_index years
save `trade'

* areas
import delimited using "areas.csv", clear varnames(1)
capture confirm string variable vintage
if _rc tostring vintage, replace
replace vintage = lower(strtrim(vintage))
preserve
keep if vintage=="base"
keep area period population
duplicates drop area period, force
save `pop'
restore
keep area period vintage total_employment
duplicates drop area period vintage, force
save `areas'

* employment
import delimited using "employment.csv", clear varnames(1) stringcols(4)
capture confirm string variable vintage
if _rc tostring vintage, replace
replace vintage = lower(strtrim(vintage))
replace industry = strtrim(industry)
collapse (sum) employment, by(area period vintage industry)
save `emp'

* full grid
use `areas', clear
cross using `inds'
merge 1:1 area period vintage industry using `emp', keep(master match) nogenerate
replace employment = 0 if missing(employment)

bysort period vintage industry: egen double nat = total(employment)
merge m:1 period industry using `trade', keep(match) nogenerate

gen double chg = cond(vintage=="base", us_change, other_change)
gen double term = (employment/total_employment)*(chg/nat)/(price_index/100)/1000*(10/years)
gen double tx = cond(vintage=="base", term, 0)
gen double tz = cond(vintage=="early", term, 0)
collapse (sum) x=tx z=tz, by(area period)

merge 1:1 area period using `pop', keep(match) nogenerate
tempfile ex
save `ex'
import delimited using "outcomes.csv", clear varnames(1)
merge 1:1 area period using `ex', keep(match) nogenerate

ivregress 2sls change_pp period control (x = z) [aw=population]
local b = _b[x]
local n = e(N)

sum x if area==0 & period==0, meanonly
local x0 = r(mean)
sum x if area==0 & period==1, meanonly
local x1 = r(mean)
sum z if area==0 & period==0, meanonly
local z0 = r(mean)

display "ANSWER: iv_slope estimate=" %24.16g `b' " se=NA n_obs=" `n'
display "ANSWER: exposure_area0_period0 estimate=" %24.16g `x0' " se=NA n_obs=" `n'
display "ANSWER: exposure_area0_period1 estimate=" %24.16g `x1' " se=NA n_obs=" `n'
display "ANSWER: instrument_area0_period0 estimate=" %24.16g `z0' " se=NA n_obs=" `n'
