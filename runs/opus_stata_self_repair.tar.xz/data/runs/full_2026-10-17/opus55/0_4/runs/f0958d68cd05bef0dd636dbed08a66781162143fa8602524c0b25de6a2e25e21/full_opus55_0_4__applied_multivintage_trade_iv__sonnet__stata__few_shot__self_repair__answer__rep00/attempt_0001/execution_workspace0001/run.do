clear all
set more off
set type double

* crosswalk
import delimited using "crosswalk.csv", clear varnames(1) stringcols(1)
replace code = trim(code)
duplicates drop code, force
tempfile cw ind trade emp areas pop
save `cw'
keep industry
duplicates drop
save `ind'

* trade
import delimited using "trade.csv", clear varnames(1) stringcols(2)
replace code = trim(code)
merge m:1 code using `cw', keep(match) nogenerate
collapse (sum) us_change other_change (mean) price_index years, by(period industry)
save `trade'

* areas
import delimited using "areas.csv", clear varnames(1)
capture confirm string variable vintage
if _rc tostring vintage, replace
replace vintage = lower(trim(vintage))
save `areas'
keep if vintage=="base"
keep area period population
duplicates drop area period, force
save `pop'

* employment
import delimited using "employment.csv", clear varnames(1)
capture confirm string variable vintage
if _rc tostring vintage, replace
replace vintage = lower(trim(vintage))
collapse (sum) employment, by(area period vintage industry)
save `emp'

* full grid: area-period-vintage x industry
use `areas', clear
keep area period vintage
duplicates drop
cross using `ind'
merge 1:1 area period vintage industry using `emp', keep(master match) nogenerate
replace employment = 0 if missing(employment)

bysort period vintage industry: egen double nat = total(employment)
merge m:1 area period vintage using `areas', keepusing(total_employment) keep(match) nogenerate
merge m:1 period industry using `trade', keep(match) nogenerate

gen double chg = cond(vintage=="base", us_change, other_change)
gen double term = (employment/total_employment)*(chg/nat)/(price_index/100)/1000*(10/years)
collapse (sum) term, by(area period vintage)
gen str5 v = cond(vintage=="base","x","z")
drop vintage
reshape wide term, i(area period) j(v) string
rename termx x
rename termz z

merge 1:1 area period using `pop', keep(match) nogenerate
tempfile ex
save `ex'
import delimited using "outcomes.csv", clear varnames(1)
merge 1:1 area period using `ex', keep(match) nogenerate

ivregress 2sls change_pp period control (x = z) [aw=population]
local b = _b[x]
local n = e(N)

sort area period
quietly summarize x if area==0 & period==0
local e0 = r(mean)
quietly summarize x if area==0 & period==1
local e1 = r(mean)
quietly summarize z if area==0 & period==0
local i0 = r(mean)

display "ANSWER: iv_slope estimate=" %24.16g `b' " se=NA n_obs=" `n'
display "ANSWER: exposure_area0_period0 estimate=" %24.16g `e0' " se=NA n_obs=" `n'
display "ANSWER: exposure_area0_period1 estimate=" %24.16g `e1' " se=NA n_obs=" `n'
display "ANSWER: instrument_area0_period0 estimate=" %24.16g `i0' " se=NA n_obs=" `n'
