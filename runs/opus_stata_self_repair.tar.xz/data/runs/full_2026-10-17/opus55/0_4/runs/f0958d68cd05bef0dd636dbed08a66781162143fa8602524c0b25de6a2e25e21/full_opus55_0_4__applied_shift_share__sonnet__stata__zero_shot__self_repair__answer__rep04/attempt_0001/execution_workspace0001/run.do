clear all
set more off
set linesize 255

import delimited using "./input.csv", clear

* Regional shift-share instrument
gen double sz = share*shock
bysort region_id: egen double z = total(sz)
bysort region_id: gen byte first = (_n==1)

* Normalize regional weights once, one obs per region
quietly summarize region_weight if first
gen double e = region_weight/r(sum)

* Demean y, x, z with e-weighted regional means
foreach v in y x z {
    quietly summarize `v' [aw=e] if first
    gen double `v'0 = `v' - r(mean)
}

* Regional weighted 2SLS and first stage
ivregress 2sls y (x = z) [aw=e] if first
scalar b_effect = _b[x]
regress x z [aw=e] if first
scalar b_fs = _b[z]

* Shock-level aggregation
gen double w = e*share
foreach v in y x z {
    gen double w`v' = w*`v'0
}
collapse (sum) s=w wy wx wz (mean) shock, by(industry_id)
gen double ybar = wy/s
gen double xbar = wx/s
gen double zbar = wz/s

* Shock-level IV for effect (HC1, N/(N-2))
ivregress 2sls ybar (xbar = shock) [aw=s], vce(robust) small
scalar b_effect_s = _b[xbar]
scalar se_effect = _se[xbar]
scalar n_ind = e(N)

* Shock-level IV for first stage
ivregress 2sls xbar (zbar = shock) [aw=s], vce(robust) small
scalar b_fs_s = _b[zbar]
scalar se_fs = _se[zbar]

* Effective number of shocks
gen double s2 = s^2
quietly summarize s2
scalar eff_shocks = 1/r(sum)

display "Regional effect slope: " %21.12f b_effect "  shock-level: " %21.12f b_effect_s
display "Regional first-stage slope: " %21.12f b_fs "  shock-level: " %21.12f b_fs_s

display "ANSWER: effect estimate=" %21.12f b_effect " se=" %21.12f se_effect " n_obs=" %12.0f n_ind
display "ANSWER: first_stage estimate=" %21.12f b_fs " se=" %21.12f se_fs " n_obs=" %12.0f n_ind
display "ANSWER: effective_shocks estimate=" %21.12f eff_shocks " se=. n_obs=" %12.0f n_ind
