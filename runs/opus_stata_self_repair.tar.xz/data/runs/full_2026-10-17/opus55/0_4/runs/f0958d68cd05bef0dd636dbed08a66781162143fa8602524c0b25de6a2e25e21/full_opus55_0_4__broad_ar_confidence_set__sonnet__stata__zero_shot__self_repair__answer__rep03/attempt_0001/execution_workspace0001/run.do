clear all
set more off
set linesize 255
import delimited using "./input.csv", clear
keep if !missing(y, endog, x, z1, z2)
local n = _N

* residuals on restricted (const, x) and full (const, x, z1, z2)
quietly regress y x
predict double ur, resid
quietly regress endog x
predict double vr, resid
quietly regress y x z1 z2
predict double uf, resid
quietly regress endog x z1 z2
predict double vf, resid

gen double p_uu_r = ur*ur
gen double p_vv_r = vr*vr
gen double p_uv_r = ur*vr
gen double p_uu_f = uf*uf
gen double p_vv_f = vf*vf
gen double p_uv_f = uf*vf
foreach v in uu_r vv_r uv_r uu_f vv_f uv_f {
    quietly summarize p_`v', meanonly
    scalar S_`v' = r(sum)
}

scalar df2 = `n' - 4
scalar cval = invFtail(2, df2, 0.05)
scalar k = 2*cval/df2

* A = Pz - k*M ; Pz quadratic = restricted SS - full SS
scalar Auu = (S_uu_r - S_uu_f) - k*S_uu_f
scalar Avv = (S_vv_r - S_vv_f) - k*S_vv_f
scalar Auv = (S_uv_r - S_uv_f) - k*S_uv_f

* q(b) = Avv*b^2 - 2*Auv*b + Auu <= 0  accepts
scalar disc = Auv^2 - Avv*Auu
scalar r1 = (Auv - sqrt(disc))/Avv
scalar r2 = (Auv + sqrt(disc))/Avv
scalar blow = min(r1, r2)
scalar bhigh = max(r1, r2)
scalar unb = (Avv < 0)
scalar acc0 = (Auu <= 0)

* AR F at beta = 1
gen double ytil = y - 1*endog
quietly regress ytil x z1 z2
quietly test z1 z2
scalar f1 = r(F)

display "ANSWER: boundary_low estimate=" %21.12f blow " se=. n_obs=" %12.0f `n'
display "ANSWER: boundary_high estimate=" %21.12f bhigh " se=. n_obs=" %12.0f `n'
display "ANSWER: accepts_zero estimate=" %21.12f acc0 " se=. n_obs=" %12.0f `n'
display "ANSWER: unbounded estimate=" %21.12f unb " se=. n_obs=" %12.0f `n'
display "ANSWER: ar_f_at_one estimate=" %21.12f f1 " se=. n_obs=" %12.0f `n'
