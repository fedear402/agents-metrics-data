version 19.0
clear all
set more off
set linesize 255
import delimited using "./input.csv", clear varnames(1)
sort region_id industry_id
egen rgrp = group(region_id)
egen igrp = group(industry_id)
quietly summarize rgrp
local R = r(max)
quietly summarize igrp
local N = r(max)
mata:
rg = st_data(., "rgrp")
ig = st_data(., "igrp")
sh = st_data(., "share")
shk = st_data(., "shock")
rw = st_data(., "region_weight")
xv = st_data(., "x")
yv = st_data(., "y")
R = strtoreal(st_local("R"))
N = strtoreal(st_local("N"))
S = J(R, N, 0)
shock = J(N, 1, .)
w = J(R, 1, .)
x = J(R, 1, .)
y = J(R, 1, .)
for (i=1; i<=rows(rg); i++) {
    S[rg[i], ig[i]] = S[rg[i], ig[i]] + sh[i]
    shock[ig[i]] = shk[i]
    w[rg[i]] = rw[i]
    x[rg[i]] = xv[i]
    y[rg[i]] = yv[i]
}
e = w / sum(w)
z = S * shock
regional = (y, x, z)
centered = regional :- e' * regional
mass = S' * e
aggregated = (S' * (e :* centered)) :/ mass
est = J(2, 2, .)
for (eq=1; eq<=2; eq++) {
    dep = aggregated[., eq]
    endo = aggregated[., eq+1]
    X = (J(N,1,1), endo)
    Z = (J(N,1,1), shock)
    inv = luinv(Z' * (mass :* X))
    b = inv * Z' * (mass :* dep)
    u = dep - X * b
    sc = Z :* (mass :* u)
    V = N/(N-2) * inv * (sc' * sc) * inv'
    est[eq, .] = (b[2], sqrt(V[2,2]))
}
reg_eff = sum(e :* centered[.,3] :* centered[.,1]) / sum(e :* centered[.,3] :* centered[.,2])
reg_fs = sum(e :* centered[.,3] :* centered[.,2]) / sum(e :* centered[.,3] :^ 2)
est[1,1] = reg_eff
est[2,1] = reg_fs
st_numscalar("b_eff", est[1,1])
st_numscalar("se_eff", est[1,2])
st_numscalar("b_fs", est[2,1])
st_numscalar("se_fs", est[2,2])
st_numscalar("effn", 1/sum(mass:^2))
st_numscalar("nind", N)
end
display "ANSWER: effect estimate=" %21.12f b_eff " se=" %21.12f se_eff " n_obs=" %12.0f nind
display "ANSWER: first_stage estimate=" %21.12f b_fs " se=" %21.12f se_fs " n_obs=" %12.0f nind
display "ANSWER: effective_shocks estimate=" %21.12f effn " se=. n_obs=" %12.0f nind
