clear all
set more off
set type double

* crosswalk
import delimited using "crosswalk.csv", clear varnames(1) case(lower)
keep code industry
duplicates drop
tempfile cw ind
save `cw'
keep industry
duplicates drop
save `ind'

* trade
import delimited using "trade.csv", clear varnames(1) case(lower)
merge m:1 code using `cw', keep(match) nogen
keep period industry us_change other_change price_index years
tempfile tr
save `tr'

* areas
import delimited using "areas.csv", clear varnames(1) case(lower)
capture confirm string variable vintage
if _rc tostring vintage, replace
replace vintage = lower(strtrim(vintage))
tempfile ar
save `ar'
keep if vintage=="base"
keep area period population
duplicates drop area period, force
tempfile pop
save `pop'

* employment
import delimited using "employment.csv", clear varnames(1) case(lower)
capture confirm string variable vintage
if _rc tostring vintage, replace
replace vintage = lower(strtrim(vintage))
collapse (sum) employment, by(area period vintage industry)
tempfile em
save `em'

* full grid
use `ar', clear
keep area period vintage total_employment
duplicates drop area period vintage, force
cross using `ind'
merge 1:1 area period vintage industry using `em', keep(master match) nogen
replace employment = 0 if missing(employment)

bysort period vintage industry: egen double nat = total(employment)
merge m:1 period industry using `tr', keep(match) nogen

gen double term = .
replace term = (employment/total_employment)*(us_change/nat)/(price_index/100)/1000*(10/years) if vintage=="base"
replace term = (employment/total_employment)*(other_change/nat)/(price_index/100)/1000*(10/years) if vintage=="early"
collapse (sum) term, by(area period vintage)
gen v = cond(vintage=="base","x","z")
drop vintage
reshape wide term, i(area period) j(v) string
rename termx x
rename termz z

tempfile ex
save `ex'

import delimited using "outcomes.csv", clear varnames(1) case(lower)
merge 1:1 area period using `ex', keep(match) nogen
merge 1:1 area period using `pop', keep(match) nogen

ivregress 2sls change_pp period control (x = z) [aw=population]
local n = e(N)
local b = _b[x]

sum x if area==0 & period==0, meanonly
local x0 = r(mean)
sum x if area==0 & period==1, meanonly
local x1 = r(mean)
sum z if area==0 & period==0, meanonly
local z0 = r(mean)

display "ANSWER: iv_slope estimate=" %24.16g `b' " se=NA n_obs=" `n'
display "ANSWER: exposure_area0_period0 estimate=" %24.16g `x0' " se=NA n_obs=" `n'
display "ANSWER: exposure_area0_period1 estimate=" %24.16g `x1' " se=NA n_obs=" `n'
display "ANSWER: instrument_area0_period0 estimate=" %24.16g `z0' " se=NA n_obs=" `n'
