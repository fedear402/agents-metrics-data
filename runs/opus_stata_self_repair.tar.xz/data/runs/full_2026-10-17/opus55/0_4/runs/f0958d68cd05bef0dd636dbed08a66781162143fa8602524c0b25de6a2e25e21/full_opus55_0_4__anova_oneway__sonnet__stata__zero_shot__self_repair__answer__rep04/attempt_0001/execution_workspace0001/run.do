clear all
set more off
set linesize 255

import delimited using "./input.csv", clear varnames(1) case(lower)

capture confirm string variable y
if !_rc {
    destring y, replace force
}

capture confirm string variable group
if !_rc {
    encode group, gen(grp)
}
else {
    gen grp = group
}

drop if missing(y) | missing(grp)

anova y grp

scalar F_stat = e(F)
scalar dfn = e(df_m)
scalar dfd = e(df_r)
scalar pval = Ftail(dfn, dfd, F_stat)
scalar nobs = e(N)

display "ANSWER: F estimate=" %21.12f F_stat " se=. n_obs=" %12.0f nobs
display "ANSWER: df_num estimate=" %21.12f dfn " se=. n_obs=" %12.0f nobs
display "ANSWER: df_den estimate=" %21.12f dfd " se=. n_obs=" %12.0f nobs
display "ANSWER: p_value estimate=" %21.12f pval " se=. n_obs=" %12.0f nobs
