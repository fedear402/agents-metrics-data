clear all
set more off
set type double

* Crosswalk
import delimited using "crosswalk.csv", clear varnames(1) stringcols(_all)
replace code = strtrim(code)
replace industry = strtrim(industry)
keep code industry
duplicates drop
tempfile cw
save `cw'

* Trade
import delimited using "trade.csv", clear varnames(1) stringcols(2)
replace code = strtrim(code)
merge m:1 code using `cw', keep(match) nogenerate
keep period industry us_change other_change price_index years
tempfile tr
save `tr'

* Areas
import delimited using "areas.csv", clear varnames(1)
capture confirm string variable vintage
if _rc tostring vintage, replace
replace vintage = lower(strtrim(vintage))
keep area period vintage total_employment population
tempfile ar
save `ar'

* Employment
import delimited using "employment.csv", clear varnames(1) stringcols(4)
capture confirm string variable vintage
if _rc tostring vintage, replace
replace vintage = lower(strtrim(vintage))
replace industry = strtrim(industry)
replace employment = 0 if missing(employment)
collapse (sum) employment, by(area period vintage industry)
bysort period vintage industry: egen double nat = total(employment)
merge m:1 period industry using `tr', keep(match) nogenerate
gen double chg = cond(vintage=="base", us_change, other_change)
gen double term = employment*chg/nat/(price_index/100)/1000*(10/years)
collapse (sum) term, by(area period vintage)

merge 1:1 area period vintage using `ar', keep(using match) nogenerate
replace term = 0 if missing(term)
gen double expo = term/total_employment
gen double pop_b = population if vintage=="base"
bysort area period: egen double pop = max(pop_b)
gen double xb = expo if vintage=="base"
gen double zb = expo if vintage=="early"
collapse (max) x=xb z=zb pop, by(area period)
tempfile ex
save `ex'

* Outcomes
import delimited using "outcomes.csv", clear varnames(1)
keep area period control change_pp
merge 1:1 area period using `ex', keep(match) nogenerate

ivregress 2sls change_pp period control (x = z) [aw=pop]
local b = _b[x]
local n = e(N)

sort area period
quietly summarize x if area==0 & period==0, meanonly
local x0 = r(mean)
quietly summarize x if area==0 & period==1, meanonly
local x1 = r(mean)
quietly summarize z if area==0 & period==0, meanonly
local z0 = r(mean)

display "ANSWER: iv_slope estimate=" %24.16g `b' " se=NA n_obs=" `n'
display "ANSWER: exposure_area0_period0 estimate=" %24.16g `x0' " se=NA n_obs=" `n'
display "ANSWER: exposure_area0_period1 estimate=" %24.16g `x1' " se=NA n_obs=" `n'
display "ANSWER: instrument_area0_period0 estimate=" %24.16g `z0' " se=NA n_obs=" `n'
