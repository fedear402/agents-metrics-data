clear all
set more off
import delimited using "census.csv", clear
keep eligible nonrecipient_population
tempfile cen
save `cen'
import delimited using "households.csv", clear
keep if recipient==0
gen double in0 = 1-eligible
gen double in1 = eligible
gen double d0 = dose*in0
gen double d1 = dose*in1
gen double b0 = baseline*in0
gen double b1 = baseline*in1
gen double z0 = instrument*in0
gen double z1 = instrument*in1
ivregress 2sls outcome in0 in1 b0 b1 (d0 d1 = z0 z1) [aweight=weight], noconstant
local n = e(N)
scalar s0 = _b[d0]
scalar s1 = _b[d1]
quietly summarize dose [aweight=weight] if eligible==0 & e(sample)
scalar m0 = r(mean)
quietly summarize dose [aweight=weight] if eligible==1 & e(sample)
scalar m1 = r(mean)
scalar e0 = s0*m0
scalar e1 = s1*m1
preserve
use `cen', clear
quietly summarize nonrecipient_population if eligible==0
scalar p0 = r(sum)
quietly summarize nonrecipient_population if eligible==1
scalar p1 = r(sum)
restore
scalar pe = (p0*e0 + p1*e1)/(p0+p1)
di "ANSWER: ineligible_effect estimate=" %20.12g e0 " se=NA n_obs=" `n'
di "ANSWER: eligible_nonrecipient_effect estimate=" %20.12g e1 " se=NA n_obs=" `n'
di "ANSWER: population_effect estimate=" %20.12g pe " se=NA n_obs=" `n'
