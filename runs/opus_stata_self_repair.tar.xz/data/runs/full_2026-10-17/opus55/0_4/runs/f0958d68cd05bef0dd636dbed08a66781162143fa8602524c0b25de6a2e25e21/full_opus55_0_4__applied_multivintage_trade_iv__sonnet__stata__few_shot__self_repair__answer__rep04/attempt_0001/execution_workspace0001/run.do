clear all
set more off
set type double

* crosswalk and trade
import delimited using crosswalk.csv, clear varnames(1) case(lower)
keep code industry
duplicates drop
tempfile cw ind trade areas
save `cw'
keep industry
duplicates drop
save `ind'

import delimited using trade.csv, clear varnames(1) case(lower)
merge m:1 code using `cw', keep(match) nogen
keep period industry us_change other_change price_index years
save `trade'

* areas
import delimited using areas.csv, clear varnames(1) case(lower)
capture tostring vintage, replace
replace vintage = lower(strtrim(vintage))
save `areas'

* full grid area x period x vintage x industry
keep area period vintage
duplicates drop
cross using `ind'
tempfile grid
save `grid'

import delimited using employment.csv, clear varnames(1) case(lower)
capture tostring vintage, replace
replace vintage = lower(strtrim(vintage))
collapse (sum) employment, by(area period vintage industry)
merge 1:1 area period vintage industry using `grid', nogen
replace employment = 0 if missing(employment)

bysort period vintage industry: egen double nat = total(employment)

merge m:1 area period vintage using `areas', keep(match) nogen keepusing(total_employment)
merge m:1 period industry using `trade', keep(match) nogen

gen double cx = cond(vintage=="base", ///
    (employment/total_employment)*(us_change/nat)/(price_index/100)/1000*(10/years), 0)
gen double cz = cond(vintage=="early", ///
    (employment/total_employment)*(other_change/nat)/(price_index/100)/1000*(10/years), 0)
collapse (sum) x=cx z=cz, by(area period)
tempfile expo
save `expo'

use `areas', clear
keep if vintage=="base"
keep area period population
merge 1:1 area period using `expo', keep(match) nogen

tempfile dat
save `dat'
import delimited using outcomes.csv, clear varnames(1) case(lower)
merge 1:1 area period using `dat', keep(match) nogen

ivregress 2sls change_pp period control (x = z) [aw=population]
local b = _b[x]
local n = e(N)

sort area period
quietly summarize x if area==0 & period==0
local x0 = r(mean)
quietly summarize x if area==0 & period==1
local x1 = r(mean)
quietly summarize z if area==0 & period==0
local z0 = r(mean)

display "ANSWER: iv_slope estimate=" %24.16g `b' " se=NA n_obs=" `n'
display "ANSWER: exposure_area0_period0 estimate=" %24.16g `x0' " se=NA n_obs=" `n'
display "ANSWER: exposure_area0_period1 estimate=" %24.16g `x1' " se=NA n_obs=" `n'
display "ANSWER: instrument_area0_period0 estimate=" %24.16g `z0' " se=NA n_obs=" `n'
