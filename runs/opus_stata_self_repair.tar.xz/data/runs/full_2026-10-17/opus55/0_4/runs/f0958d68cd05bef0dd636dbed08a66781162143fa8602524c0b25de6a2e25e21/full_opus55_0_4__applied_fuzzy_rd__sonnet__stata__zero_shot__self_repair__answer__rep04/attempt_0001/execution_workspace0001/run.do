clear all
set more off
set linesize 255
import delimited using "./input.csv", clear
keep if abs(score) < 1 & !missing(score, participated, earnings)
gen double w = 1 - abs(score)
gen double d = (score >= 0)
gen double ds = d*score
gen double one = 1

mata:
X = st_data(., ("one","d","score","ds"))
w = st_data(., "w")
y = st_data(., "earnings")
t = st_data(., "participated")
n = rows(X)
A = invsym(cross(X, w, X))
by = A*cross(X, w, y)
bt = A*cross(X, w, t)
ey = y - X*by
et = t - X*bt
Py = (X :* (w:*ey)) * A
Pt = (X :* (w:*et)) * A
iy = Py[.,2]
it = Pt[.,2]
rf = by[2]
fs = bt[2]
vy = cross(iy, iy)
vt = cross(it, it)
cyt = cross(iy, it)
te = rf/fs
g = (1/fs, -rf/(fs^2))
V = (vy, cyt \ cyt, vt)
vte = g*V*g'
st_numscalar("rf", rf)
st_numscalar("fs", fs)
st_numscalar("te", te)
st_numscalar("se_rf", sqrt(vy))
st_numscalar("se_fs", sqrt(vt))
st_numscalar("se_te", sqrt(vte))
st_numscalar("nobs", n)
end

display "ANSWER: treatment_effect estimate=" %21.12f te " se=" %21.12f se_te " n_obs=" %12.0f nobs
display "ANSWER: reduced_form estimate=" %21.12f rf " se=" %21.12f se_rf " n_obs=" %12.0f nobs
display "ANSWER: first_stage estimate=" %21.12f fs " se=" %21.12f se_fs " n_obs=" %12.0f nobs
